<?php
/** Real WordPress option/cache/hook functions, with a disposable SQLite SQL adapter.
 * php native-options.php /path/wordpress /path/plugin /tmp/options.sqlite
 * No HTTP, site installation, real Google credentials, or MySQL compatibility claim.
 */
declare(strict_types=1);
$wp = rtrim( $argv[1], '/' ) . '/'; $plugin = $argv[2]; $database = $argv[3];
define( 'ABSPATH', $wp ); define( 'WPINC', 'wp-includes' ); define( 'WP_DEBUG', false );
define( 'OBJECT', 'OBJECT' ); define( 'ARRAY_A', 'ARRAY_A' ); define( 'ARRAY_N', 'ARRAY_N' );
require $wp . 'wp-includes/compat.php'; require $wp . 'wp-includes/load.php'; require $wp . 'wp-includes/plugin.php';
require $wp . 'wp-includes/class-wp-error.php'; require $wp . 'wp-includes/cache.php'; wp_cache_init();
require $wp . 'wp-includes/formatting.php'; require $wp . 'wp-includes/functions.php';
function __( $text, $domain = null ) { return $text; }
function wp_salt( $scheme = 'auth' ) { return 'disposable-native-test-salt-' . $scheme; }
function current_user_can( $cap ) { return true; }
final class SqliteOptions {
    public string $options = 'wp_options'; public string $last_error = ''; public string $fail_option = ''; public string $fail_read_option = ''; public PDO $db;
    public function __construct( string $file ) { $this->db = new PDO( 'sqlite:' . $file ); $this->db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION ); $this->db->exec( 'PRAGMA busy_timeout=3000' ); $this->db->exec( 'CREATE TABLE IF NOT EXISTS wp_options (option_id INTEGER PRIMARY KEY, option_name TEXT UNIQUE, option_value TEXT, autoload TEXT)' ); }
    public function prepare( $sql, ...$args ) { $i = 0; return preg_replace_callback( '/%[sd]/', function( $m ) use ( &$i, $args ) { $v = $args[ $i++ ]; return '%d' === $m[0] ? (string) (int) $v : $this->db->quote( (string) $v ); }, $sql ); }
    public function _escape( $v ) { return is_array( $v ) ? array_map( array( $this, '_escape' ), $v ) : substr( $this->db->quote( (string) $v ), 1, -1 ); }
    public function esc_like( $s ) { return addcslashes( $s, '_%\\' ); }
    private function translate( string $sql ): string {
        $sql = str_replace( 'INSERT IGNORE', 'INSERT OR IGNORE', $sql );
        $sql = preg_replace( '/ON DUPLICATE KEY UPDATE.*$/s', 'ON CONFLICT(option_name) DO UPDATE SET option_value=excluded.option_value, autoload=excluded.autoload', $sql );
        return preg_replace( "/(LIKE '(?:[^']|'')*')/", "$1 ESCAPE '\\'", $sql );
    }
    public function query( $sql ) { $this->last_error = ''; if ( $this->fail_option && str_starts_with( $sql, 'INSERT INTO' ) && str_contains( $sql, $this->db->quote( $this->fail_option ) ) ) { $this->last_error = 'simulated insert failure'; return false; } try { return $this->db->exec( $this->translate( $sql ) ); } catch ( Throwable $e ) { $this->last_error = $e->getMessage(); return false; } }
    public function get_results( $sql ) { $this->last_error = ''; return $this->db->query( $this->translate( $sql ) )->fetchAll( PDO::FETCH_OBJ ); }
    public function get_row( $sql, $format = OBJECT ) {
        $this->last_error = '';
        if ( $this->fail_read_option && str_contains( $sql, $this->fail_read_option ) ) { $this->last_error = 'simulated read failure'; return null; }
        $row = $this->db->query( $this->translate( $sql ) )->fetch( ARRAY_A === $format ? PDO::FETCH_ASSOC : PDO::FETCH_OBJ ); return false === $row ? null : $row;
    }
    public function get_col( $sql ) { return $this->db->query( $this->translate( $sql ) )->fetchAll( PDO::FETCH_COLUMN ); }
    public function get_var( $sql ) { $v = $this->db->query( $this->translate( $sql ) )->fetchColumn(); return false === $v ? null : $v; }
    public function update( $table, $values, $where ) {
        if ( ( $where['option_name'] ?? '' ) === $this->fail_option ) { $this->last_error = 'simulated write failure'; return false; }
        $sets = array(); foreach ( $values as $k => $v ) { $sets[] = "$k=" . $this->db->quote( (string) $v ); }
        return $this->query( 'UPDATE ' . $table . ' SET ' . implode( ',', $sets ) . ' WHERE option_name=' . $this->db->quote( $where['option_name'] ) );
    }
    public function delete( $table, $where ) { return $this->query( "DELETE FROM $table WHERE option_name=" . $this->db->quote( $where['option_name'] ) ); }
    public function suppress_errors( $v = true ) { return false; }
}
$GLOBALS['wpdb'] = new SqliteOptions( $database );
foreach ( array( 'Options', 'Connections', 'Crypto', 'Lock', 'Records' ) as $file ) { require $plugin . '/includes/' . $file . '.php'; }
use Fator3\McpGoogle\{Options, Connections, Crypto, Lock, Records};
Options::init();
$checks = array();
function verify( string $name, bool $ok ): void { global $checks; $checks[ $name ] = $ok; if ( ! $ok ) { throw new RuntimeException( 'Failed: ' . $name ); } }
if ( ( $argv[4] ?? '' ) === 'contend' ) { verify( 'other_process_cannot_acquire', null === Lock::acquire( 'native-shared' ) ); echo json_encode( $checks ); exit; }
$first_false = Options::set( Options::GA_ENABLED, false );
if ( ! $first_false['persisted'] ) { fwrite( STDERR, json_encode( $first_false ) . "\n" ); }
verify( 'first_false_creates_row', $first_false['success'] && $first_false['persisted'] && $first_false['changed'] && Options::stored( Options::GA_ENABLED )['exists'] );
verify( 'repeated_false_is_unchanged', ! Options::set( Options::GA_ENABLED, false )['changed'] );
$GLOBALS['wpdb']->fail_option = Options::ADS_ENABLED;
$refused_false = Options::set( Options::ADS_ENABLED, false );
verify( 'first_false_refused_insert', ! $refused_false['success'] && ! $refused_false['persisted'] && 'f3_google_option_persistence' === $refused_false['error_code'] && ! Options::stored( Options::ADS_ENABLED )['exists'] );
$GLOBALS['wpdb']->fail_option = '';
$batch_false = Options::batch_verified( array( Options::ADS_ENABLED => false ) );
verify( 'first_false_in_batch', $batch_false['success'] && $batch_false['persisted'] && Options::stored( Options::ADS_ENABLED )['exists'] );
$initial = Options::set( Options::ENABLED, true ); if ( ! $initial['persisted'] ) { fwrite( STDERR, json_encode( $initial ) . $GLOBALS['wpdb']->last_error ); } verify( 'initial_write', $initial['persisted'] );
$bool = Options::set( Options::ENABLED, false ); if ( ! $bool['persisted'] ) { fwrite( STDERR, json_encode( $bool ) ); } verify( 'bool_round_trip', $bool['persisted'] );
verify( 'unchanged_is_success', Options::set( Options::ENABLED, false )['success'] );
verify( 'unchanged_not_changed', ! Options::set( Options::ENABLED, false )['changed'] );
Options::set( Options::ENABLED, true ); $GLOBALS['wpdb']->fail_option = Options::ENABLED;
verify( 'write_refusal', 'f3_google_option_persistence' === Options::set( Options::ENABLED, false )['error_code'] );
add_filter( 'pre_option_' . Options::ENABLED, '__return_true' );
verify( 'read_filter_not_proof', ! Options::set( Options::ENABLED, false )['persisted'] );
remove_filter( 'pre_option_' . Options::ENABLED, '__return_true' ); $GLOBALS['wpdb']->fail_option = '';
verify( 'secret_persisted', Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'dummy-native-secret' )['persisted'] );
verify( 'secret_unchanged', ! Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'dummy-native-secret' )['changed'] );
verify( 'secret_hidden', '' === get_option( Options::OAUTH_CLIENT_SECRET ) );
verify( 'secret_round_trip', 'dummy-native-secret' === Options::get_secret( Options::OAUTH_CLIENT_SECRET ) );
verify( 'secret_no_autoload', 'off' === $GLOBALS['wpdb']->get_var( $GLOBALS['wpdb']->prepare( 'SELECT autoload FROM wp_options WHERE option_name=%s', Options::OAUTH_CLIENT_SECRET ) ) );
$before = Options::get_secret( Options::OAUTH_CLIENT_SECRET ); $GLOBALS['wpdb']->fail_option = Options::ENABLED;
$r = Options::batch_verified( array( Options::OAUTH_EMAIL => 'new@example.test', Options::ENABLED => false ), array( Options::OAUTH_CLIENT_SECRET => 'dummy-new' ) );
verify( 'batch_failure', ! $r['success'] ); verify( 'batch_compensation', null === Options::get( Options::OAUTH_EMAIL ) && $before === Options::get_secret( Options::OAUTH_CLIENT_SECRET ) ); $GLOBALS['wpdb']->fail_option = '';
$lock = Lock::acquire( 'native-shared' ); verify( 'lease_acquired', null !== $lock );
// Simulate another process's stale negative cache: add_option would allow an upsert.
wp_cache_set( 'notoptions', array( $lock['key'] => true ), 'options' ); wp_cache_delete( $lock['key'], 'options' );
verify( 'stale_cache_cannot_replace_lease', null === Lock::acquire( 'native-shared' ) );
$command = array( PHP_BINARY, '-n', '-d', 'extension_dir=' . ini_get( 'extension_dir' ), '-d', 'extension=pdo', '-d', 'extension=pdo_sqlite', '-d', 'extension=ctype', __FILE__, $wp, $plugin, $database, 'contend' );
$proc = proc_open( $command, array( 1 => array( 'pipe', 'w' ), 2 => array( 'pipe', 'w' ) ), $pipes ); $stdout = stream_get_contents( $pipes[1] ); $stderr = stream_get_contents( $pipes[2] ); fclose( $pipes[1] ); fclose( $pipes[2] ); $exit = proc_close( $proc );
verify( 'cross_process_lease', 0 === $exit && true === ( json_decode( $stdout, true )['other_process_cannot_acquire'] ?? false ) );
Lock::release( $lock ); $second = Lock::acquire( 'native-shared' ); verify( 'lease_reacquired_after_release', null !== $second ); Lock::release( $second );
verify( 'record_initial_insert', Records::insert( 'job', 'unique', array( 'value' => 1 ) ) );
wp_cache_set( 'notoptions', array( Records::key( 'job', 'unique' ) => true ), 'options' );
verify( 'record_never_upserts', ! Records::insert( 'job', 'unique', array( 'value' => 2 ) ) );
wp_cache_delete( 'notoptions', 'options' ); verify( 'original_record_preserved', 1 === Records::get( 'job', 'unique' )['value'] );
verify( 'records_list', 1 === count( Records::list( 'job' ) ) );
echo json_encode( array( 'passed' => true, 'wordpress' => '6.9.4', 'php' => PHP_VERSION, 'database' => 'SQLite adapter, real WordPress option/cache/hooks functions', 'checks' => $checks ), JSON_PRETTY_PRINT ) . "\n";
