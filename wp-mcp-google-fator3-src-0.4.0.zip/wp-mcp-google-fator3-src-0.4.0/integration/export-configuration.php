<?php
/** Reproducible safe fixture; no production configuration or Google requests. */
require $argv[1] . '/tests/bootstrap.php';
\Fator3\McpGoogle\Plugin::register_abilities();
\Fator3\McpGoogle\Options::set( \Fator3\McpGoogle\Options::ENABLED, true );
$result = \Fator3\McpGoogle\Configuration::read( array( 'include_values' => ! in_array( '--definitions-only', $argv, true ) ) );
echo json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n";
exit( $result['success'] ? 0 : 1 );
