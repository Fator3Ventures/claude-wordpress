<?php
/**
 * Regressões da revisão adversarial (fase 4).
 *
 * Cada teste aqui corresponde a um item de `RELATORIO-REVISAO.md`: uma entrada
 * torta que o agente manda por engano, ou um caminho que só um atacante
 * tentaria. O critério é sempre o mesmo — a rota devolve `success: false` com
 * uma mensagem em português que diz o que corrigir, e nunca uma exceção, um
 * aviso do PHP ou, pior, uma resposta bem-sucedida com o número errado.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Ads\Abilities as AdsAbilities;
use Fator3\McpGoogle\Ads\Gaql;
use Fator3\McpGoogle\Analytics\Abilities as AnalyticsAbilities;
use Fator3\McpGoogle\Analytics\PropertyId;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Auth\OAuthFlow;
use Fator3\McpGoogle\Crypto;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Unified\Abilities as UnifiedAbilities;
use Fator3\McpGoogle\Unified\Catalog;
use Fator3\McpGoogle\Unified\Filters;
use Fator3\McpGoogle\Unified\Query;
use PHPUnit\Framework\TestCase;

final class RevisaoTest extends TestCase {

	private const SA_EMAIL = 'robo-revisao@projeto-teste.iam.gserviceaccount.com';

	/** @var array{private:string,public:string}|null */
	private static ?array $keys = null;

	/** @var bool */
	private static bool $registered = false;

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;
		$GLOBALS['f3_test_user_caps']  = array();
		$GLOBALS['f3_test_redirects']  = array();

		FakeHttp::reset();
		Catalog::flush();

		if ( ! self::$registered ) {
			AnalyticsAbilities::register();
			AdsAbilities::register();
			UnifiedAbilities::register();
			self::$registered = true;
		}

		$this->enable_all();
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	private static function keys(): array {
		if ( null === self::$keys ) {
			$pair = openssl_pkey_new(
				array(
					'private_key_bits' => 2048,
					'private_key_type' => OPENSSL_KEYTYPE_RSA,
				)
			);

			$private = '';
			openssl_pkey_export( $pair, $private );
			$details = openssl_pkey_get_details( $pair );

			self::$keys = array(
				'private' => $private,
				'public'  => (string) $details['key'],
			);
		}

		return self::$keys;
	}

	private function enable_all(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set( Options::GA_DEFAULT_PROPERTY, '123456' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'DEVTOKEN-REVISAO' );
		Options::set_secret(
			Options::SA_JSON,
			(string) wp_json_encode(
				array(
					'type'         => 'service_account',
					'project_id'   => 'projeto-teste',
					'private_key'  => self::keys()['private'],
					'client_email' => self::SA_EMAIL,
					'token_uri'    => 'https://oauth2.googleapis.com/token',
				)
			)
		);

		foreach ( array( 'ga', 'ads', 'any' ) as $connector ) {
			Credentials::remember(
				Credentials::cache_key( Credentials::scopes_for( $connector ), self::SA_EMAIL ),
				'tok-revisao',
				3600
			);
		}
	}

	/**
	 * @param int $how Respostas de sucesso a enfileirar.
	 */
	private function queue_ok( int $how = 20 ): void {
		for ( $i = 0; $i < $how; $i++ ) {
			FakeHttp::push(
				'*',
				200,
				array(
					'dimensionHeaders' => array( array( 'name' => 'date' ) ),
					'metricHeaders'    => array(
						array(
							'name' => 'sessions',
							'type' => 'TYPE_INTEGER',
						),
					),
					'rows'             => array(),
					'rowCount'         => 0,
					'results'          => array(),
					'resourceNames'    => array(),
					'accountSummaries' => array(),
					'dimensions'       => array(),
					'metrics'          => array(),
				)
			);
		}
	}

	/**
	 * @param string $name  Rota.
	 * @param array  $input Entrada.
	 */
	private function chamar( string $name, array $input ): array {
		$ability = wp_get_ability( $name );
		$this->assertNotNull( $ability, $name );

		$result = $ability->execute( $input );

		$this->assertIsArray( $result, $name . ': execute() nunca pode estourar' );
		$this->assertArrayHasKey( 'success', $result, $name );

		return $result;
	}

	/**
	 * @param array  $result Resposta.
	 * @param string $code   error_code esperado.
	 * @param string $label  Rótulo para a mensagem de falha.
	 */
	private function assert_falha( array $result, string $code, string $label ): void {
		$this->assertFalse( $result['success'], $label . ': deveria falhar' );
		$this->assertSame( $code, $result['error_code'] ?? '', $label );
		$this->assertNotSame( '', trim( (string) $result['message'] ), $label . ': mensagem vazia não ajuda ninguém' );
	}

	// =========================================================================
	// Item 8 — robustez de entrada
	// =========================================================================

	/**
	 * @dataProvider limites_invalidos
	 *
	 * @param mixed $limit Valor de limit.
	 */
	public function test_limit_invalido_e_recusado_nas_tres_camadas( $limit ): void {
		$this->queue_ok();

		$ga = $this->chamar(
			'ga/run-report',
			array(
				'date_ranges' => array(
					array(
						'startDate' => '7daysAgo',
						'endDate'   => 'yesterday',
					),
				),
				'dimensions'  => array( 'date' ),
				'metrics'     => array( 'sessions' ),
				'limit'       => $limit,
			)
		);
		$this->assert_falha( $ga, 'f3_google_bad_limit', 'ga/run-report' );

		$ads = $this->chamar(
			'ads/search',
			array(
				'customer_id' => '1234567890',
				'query'       => 'SELECT campaign.id FROM campaign',
				'limit'       => $limit,
			)
		);
		$this->assert_falha( $ads, 'f3_google_bad_limit', 'ads/search' );

		$unified = $this->chamar(
			'google/query',
			array(
				'connector'  => 'ga4',
				'accounts'   => array( 'properties/123456' ),
				'metrics'    => array( 'sessions' ),
				'date_range' => 'yesterday',
				'limit'      => $limit,
			)
		);
		$this->assert_falha( $unified, 'f3_google_bad_limit', 'google/query' );

		$this->assertSame( 0, FakeHttp::count(), 'um limite inválido não pode gastar chamada à Google' );
	}

	/**
	 * @return array<string,array{0:mixed}>
	 */
	public static function limites_invalidos(): array {
		return array(
			'zero'     => array( 0 ),
			'negativo' => array( -5 ),
			'fracao'   => array( 1.9 ),
			'texto'    => array( 'muitas' ),
		);
	}

	public function test_limit_acima_do_teto_continua_sendo_cortado_e_nao_recusado(): void {
		$this->queue_ok();

		$result = $this->chamar(
			'ga/run-report',
			array(
				'date_ranges' => array(
					array(
						'startDate' => '7daysAgo',
						'endDate'   => 'yesterday',
					),
				),
				'dimensions'  => array( 'date' ),
				'metrics'     => array( 'sessions' ),
				'limit'       => 999999,
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertTrue( $result['truncated'] );
	}

	public function test_dimensao_como_string_unica_nao_e_descartada_em_silencio(): void {
		$this->queue_ok();

		$result = $this->chamar(
			'ga/run-report',
			array(
				'date_ranges' => array(
					array(
						'startDate' => '7daysAgo',
						'endDate'   => 'yesterday',
					),
				),
				'dimensions'  => 'date',
				'metrics'     => 'sessions,activeUsers',
			)
		);

		$this->assertTrue( $result['success'], (string) $result['message'] );

		$body = json_decode( (string) FakeHttp::last()['body'], true );

		$this->assertSame( array( array( 'name' => 'date' ) ), $body['dimensions'] );
		$this->assertSame(
			array( array( 'name' => 'sessions' ), array( 'name' => 'activeUsers' ) ),
			$body['metrics'],
			'uma lista em texto separado por vírgula precisa virar duas métricas, não uma com vírgula no nome'
		);
	}

	public function test_property_id_zero_e_recusado_em_vez_de_virar_properties_0(): void {
		$this->assertTrue( is_wp_error( PropertyId::normalize( 0 ) ) );
		$this->assertTrue( is_wp_error( PropertyId::normalize( '0' ) ) );
		$this->assertTrue( is_wp_error( PropertyId::normalize( 'properties/0' ) ) );

		$this->queue_ok();
		$result = $this->chamar( 'ga/get-property-details', array( 'property_id' => 0 ) );

		$this->assert_falha( $result, 'f3_google_bad_property_id', 'property_id 0' );
		$this->assertSame( 0, FakeHttp::count(), 'não pode ter saído para a rede' );
	}

	/**
	 * @dataProvider entradas_tortas
	 *
	 * @param string $name  Rota.
	 * @param array  $input Entrada.
	 * @param string $code  error_code esperado.
	 */
	public function test_entrada_torta_devolve_erro_util_sem_estourar( string $name, array $input, string $code ): void {
		$this->queue_ok();

		$result = $this->chamar( $name, $input );

		$this->assert_falha( $result, $code, $name );
	}

	/**
	 * @return array<string,array{0:string,1:array,2:string}>
	 */
	public static function entradas_tortas(): array {
		return array(
			'customer_id com letras'      => array(
				'ads/get-customer',
				array( 'customer_id' => 'abc-def-ghij' ),
				'f3_google_account_not_found',
			),
			'funnel_steps vazio'          => array(
				'ga/run-funnel-report',
				array( 'funnel_steps' => array() ),
				'f3_google_funnel_steps_required',
			),
			'accounts vazio'              => array(
				'google/query',
				array(
					'connector'  => 'ga4',
					'accounts'   => array(),
					'metrics'    => array( 'sessions' ),
					'date_range' => 'today',
				),
				'f3_google_query_accounts',
			),
			'date_range ausente'          => array(
				'google/query',
				array(
					'connector' => 'ga4',
					'accounts'  => array( 'properties/1' ),
					'metrics'   => array( 'sessions' ),
				),
				'f3_google_date_range',
			),
			'operador desconhecido'       => array(
				'google/query',
				array(
					'connector'  => 'ga4',
					'accounts'   => array( 'properties/1' ),
					'metrics'    => array( 'sessions' ),
					'date_range' => 'today',
					'filters'    => array(
						array(
							'field'    => 'country',
							'operator' => 'starts',
							'value'    => 'BR',
						),
					),
				),
				'f3_google_filter',
			),
			'in com lista vazia'          => array(
				'google/query',
				array(
					'connector'  => 'ga4',
					'accounts'   => array( 'properties/1' ),
					'metrics'    => array( 'sessions' ),
					'date_range' => 'today',
					'filters'    => array(
						array(
							'field'    => 'country',
							'operator' => 'in',
							'value'    => array(),
						),
					),
				),
				'f3_google_filter',
			),
			'ordenação sem direção certa' => array(
				'google/query',
				array(
					'connector'  => 'ga4',
					'accounts'   => array( 'properties/1' ),
					'metrics'    => array( 'sessions' ),
					'date_range' => 'today',
					'order_by'   => array(
						array(
							'field'     => 'sessions',
							'direction' => 'crescente',
						),
					),
				),
				'f3_google_order_by',
			),
			'recurso GAQL inválido'       => array(
				'ads/get-resource-metadata',
				array( 'resource_name' => 'campaign; DROP' ),
				'f3_google_ads_resource_invalid',
			),
		);
	}

	public function test_filtros_como_null_ou_lista_vazia_nao_atrapalham(): void {
		$this->queue_ok();

		foreach ( array( null, array(), '' ) as $filters ) {
			FakeHttp::reset();
			$this->queue_ok();

			$result = $this->chamar(
				'google/query',
				array(
					'connector'  => 'ga4',
					'accounts'   => array( 'properties/123456' ),
					'metrics'    => array( 'sessions' ),
					'date_range' => 'today',
					'filters'    => $filters,
				)
			);

			$this->assertTrue( $result['success'], (string) $result['message'] );
		}
	}

	// =========================================================================
	// Item 5 — GAQL
	// =========================================================================

	public function test_gaql_recusa_caractere_de_controle(): void {
		$this->assertTrue( is_wp_error( Gaql::validate( "SELECT campaign.id FROM campaign\0 X" ) ) );
		$this->assertTrue( is_wp_error( Gaql::validate( "SELECT campaign.id\x1F FROM campaign" ) ) );

		// Espaço em branco de verdade continua valendo.
		$this->assertTrue( Gaql::validate( "SELECT campaign.id\n FROM campaign" ) );
	}

	public function test_gaql_recusa_limit_sem_numero(): void {
		foreach ( array( 'LIMIT -5', 'LIMIT abc', 'LIMIT' ) as $clausula ) {
			$this->assertTrue(
				is_wp_error( Gaql::validate( 'SELECT campaign.id FROM campaign ' . $clausula ) ),
				$clausula
			);
		}

		$this->assertTrue( Gaql::validate( 'SELECT campaign.id FROM campaign LIMIT 10' ) );
	}

	public function test_identificador_com_quebra_de_linha_no_fim_e_recusado(): void {
		// `$` do PCRE casa antes de uma quebra final; com ela, "campaign.id\n"
		// passaria pela validação e a quebra entraria na consulta montada.
		$this->assertFalse( Gaql::identifier_ok( "campaign.id\n" ) );
		$this->assertFalse( Gaql::ordering_ok( "metrics.clicks\nDESC" ) );
		$this->assertFalse( Gaql::ordering_ok( "metrics\n.clicks" ) );

		$this->assertTrue( Gaql::identifier_ok( 'campaign.id' ) );
		$this->assertTrue( Gaql::ordering_ok( 'metrics.clicks DESC' ) );
	}

	public function test_campo_com_quebra_de_linha_nao_chega_a_consulta_montada(): void {
		$this->queue_ok();

		$result = $this->chamar(
			'ads/search',
			array(
				'customer_id' => '1234567890',
				'resource'    => 'campaign',
				'fields'      => array( "campaign.id\n" ),
			)
		);

		$this->assert_falha( $result, 'f3_google_ads_bad_field', 'campo com quebra' );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_valor_de_enum_com_lixo_e_recusado_em_vez_de_limpo(): void {
		$condicoes = Filters::to_gaql(
			array(
				array(
					'field'    => 'campaign_status',
					'operator' => 'eq',
					'value'    => 'ENABLED; DELETE',
				),
			),
			array( Catalog::class, 'ads_resolve' )
		);

		$this->assertTrue( is_wp_error( $condicoes ), 'limpar por dentro produziria ENABLEDDELETE em silêncio' );
		$this->assertSame( 'f3_google_filter', $condicoes->get_error_code() );

		// E com espaço no meio, que é o engano honesto.
		$com_espaco = Filters::to_gaql(
			array(
				array(
					'field'    => 'campaign_status',
					'operator' => 'in',
					'value'    => array( 'ENABLED', 'PAUSED ATIVO' ),
				),
			),
			array( Catalog::class, 'ads_resolve' )
		);
		$this->assertTrue( is_wp_error( $com_espaco ) );

		// O caminho normal continua funcionando, inclusive em minúsculas.
		$ok = Filters::to_gaql(
			array(
				array(
					'field'    => 'campaign_status',
					'operator' => 'eq',
					'value'    => 'enabled',
				),
			),
			array( Catalog::class, 'ads_resolve' )
		);
		$this->assertSame( array( 'campaign.status = ENABLED' ), $ok );
	}

	// =========================================================================
	// Item 9 — teto de chamadas em laço
	// =========================================================================

	public function test_google_query_limita_o_numero_de_contas_por_chamada(): void {
		$this->queue_ok( 120 );

		$contas = array();
		for ( $i = 1; $i <= Query::MAX_ACCOUNTS + 7; $i++ ) {
			$contas[] = 'properties/' . ( 100000 + $i );
		}

		$result = $this->chamar(
			'google/query',
			array(
				'connector'  => 'ga4',
				'accounts'   => $contas,
				'metrics'    => array( 'sessions' ),
				'date_range' => 'today',
			)
		);

		$this->assertTrue( $result['success'], (string) $result['message'] );
		$this->assertCount( Query::MAX_ACCOUNTS, $result['accounts'] );
		$this->assertNotEmpty( $result['warnings'], 'cortar em silêncio faria o agente reportar um total que não é o pedido' );
		$this->assertSame(
			Query::MAX_ACCOUNTS,
			FakeHttp::count(),
			'uma requisição por conta consultada, e nenhuma além do teto'
		);
	}

	// =========================================================================
	// Itens 2 e 3 — OAuth e cifra
	// =========================================================================

	public function test_callback_do_oauth_com_parametro_em_array_nao_gera_aviso(): void {
		$request = new \WP_REST_Request(
			array(
				'state' => array( 'a', 'b' ),
				'code'  => 'x',
			)
		);

		$capturado = null;

		try {
			OAuthFlow::handle_callback( $request );
		} catch ( \F3_Test_Redirect $redirect ) {
			$capturado = $redirect->location;
		}

		$this->assertIsString( $capturado, 'o callback precisa redirecionar, não estourar' );
		$this->assertStringContainsString( 'f3_status=oauth_state', $capturado );
	}

	public function test_state_de_usuario_sem_capacidade_e_recusado(): void {
		$state = str_repeat( 'ab', 32 );
		$record = OAuthFlow::state_record(); $record['user'] = 7;
        set_transient( 'f3_mcp_google_oauth_state_' . $state, $record, 600 );

		// O usuário 7 perdeu manage_options entre o clique e o retorno.
		$GLOBALS['f3_test_user_caps'] = array( 7 => false );

		$request = new \WP_REST_Request(
			array(
				'state' => $state,
				'code'  => 'codigo-qualquer',
			)
		);

		$capturado = null;

		try {
			OAuthFlow::handle_callback( $request );
		} catch ( \F3_Test_Redirect $redirect ) {
			$capturado = $redirect->location;
		}

		$this->assertStringContainsString( 'f3_status=oauth_state', (string) $capturado );
		$this->assertSame( 0, FakeHttp::count(), 'nenhuma troca de código pode ter acontecido' );
		$this->assertFalse( get_transient( 'f3_mcp_google_oauth_state_' . $state ), 'o state é de uso único mesmo quando recusado' );
	}

	public function test_decrypt_com_iv_adulterado_nao_dispara_aviso_do_php(): void {
		if ( 'openssl' !== Crypto::backend() ) {
			add_filter( 'f3_mcp_google_crypto_backend', static fn(): string => 'openssl' );
		}

		if ( 'openssl' !== Crypto::backend() ) {
			$this->markTestSkipped( 'sem backend openssl neste servidor' );
		}

		$cipher = Crypto::encrypt( 'segredo-de-teste' );
		$parts  = explode( ':', $cipher, 4 );

		// IV de 32 bytes no lugar dos 12 que o AES-GCM espera: sem a checagem
		// de tamanho, openssl_decrypt() emite um aviso antes de devolver false.
		$parts[2] = base64_encode( random_bytes( 32 ) );

		$erros = array();
		set_error_handler(
			static function ( $no, $str ) use ( &$erros ): bool {
				$erros[] = $str;

				return true;
			}
		);

		$plain = Crypto::decrypt( implode( ':', $parts ) );

		restore_error_handler();

		$this->assertTrue( is_wp_error( $plain ) );
		$this->assertSame( array(), $erros, 'um blob adulterado não pode virar aviso do PHP no log do site' );
	}

	public function test_a_trava_dos_segredos_sobrevive_a_leitura_aninhada_e_a_excecao(): void {
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'refresh-aninhado' );

		// Leitura de um segredo DENTRO da leitura de outro: a trava é um
		// contador, não um booleano — se fosse booleano, a leitura interna
		// fecharia a trava que a externa abriu e a externa devolveria ''.
		$interno = '';
		$espiao  = static function ( $pre ) use ( &$interno ) {
			$interno = Options::get_secret( Options::OAUTH_REFRESH_TOKEN );

			return $pre;
		};

		add_filter( 'pre_option_' . Options::ADS_DEVELOPER_TOKEN, $espiao );
		$externo = Options::get_secret( Options::ADS_DEVELOPER_TOKEN );
		remove_filter( 'pre_option_' . Options::ADS_DEVELOPER_TOKEN, $espiao );

		$this->assertSame( 'refresh-aninhado', $interno, 'a leitura aninhada precisa enxergar o segredo' );
		$this->assertSame( 'DEVTOKEN-REVISAO', $externo, 'a leitura externa não pode ser fechada pela interna' );

		// E uma exceção no meio não pode deixar a trava aberta para sempre: se
		// deixasse, um `get_option()` de terceiro passaria a ver o blob cifrado.
		$estourou = false;
		$bomba    = static function () {
			throw new \RuntimeException( 'estouro no meio da leitura' );
		};

		add_filter( 'pre_option_' . Options::SA_JSON, $bomba );

		try {
			Options::get_secret( Options::SA_JSON );
		} catch ( \RuntimeException $e ) {
			$estourou = true;
		} finally {
			remove_filter( 'pre_option_' . Options::SA_JSON, $bomba );
		}

		$this->assertTrue( $estourou );
		$this->assertSame(
			'',
			get_option( Options::OAUTH_REFRESH_TOKEN, '' ),
			'depois da exceção a trava precisa estar fechada de novo'
		);
	}

	// =========================================================================
	// Item 10 — bootstrap
	// =========================================================================

	public function test_bootstrap_carrega_todos_os_modulos_sem_file_exists(): void {
		$bootstrap = (string) file_get_contents( dirname( __DIR__ ) . '/wp-mcp-google-fator3.php' );

		$this->assertStringNotContainsString(
			'file_exists(',
			$bootstrap,
			'todos os módulos existem: um require condicional esconde um arquivo faltando até a primeira chamada'
		);

		foreach (
			array(
				'Analytics/PropertyId',
				'Analytics/AdminApi',
				'Analytics/DataApi',
				'Analytics/Abilities',
				'Ads/CustomerId',
				'Ads/Gaql',
				'Ads/AdsApi',
				'Ads/Resources',
				'Ads/Abilities',
				'Unified/DateRange',
				'Unified/Catalog',
				'Unified/Filters',
				'Unified/Query',
				'Unified/Abilities',
			) as $module
		) {
			$this->assertStringContainsString( "includes/$module.php", $bootstrap, $module );
			$this->assertFileExists( dirname( __DIR__ ) . "/includes/$module.php" );
		}
	}
}
