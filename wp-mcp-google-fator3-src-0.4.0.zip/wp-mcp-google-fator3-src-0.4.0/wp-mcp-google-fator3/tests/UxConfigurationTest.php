<?php
/** 0.4 behavior: preparation, activation, stale requests, semantic saves and scoped UI. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options, Settings, Connections, Admin, Configuration, Plugin, Setup, SetupAdmin, Lock};
use Fator3\McpGoogle\Admin\{Resources, Fields};
use Fator3\McpGoogle\Auth\{Configuration as Auth, Credentials, OAuthFlow};
final class UxConfigurationTest extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = $GLOBALS['f3_test_user_caps'] = array();
        $GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_user'] = 1; $_POST = $_GET = $_FILES = array();
        FakeHttp::reset(); Plugin::register_abilities(); Options::set( Options::ENABLED, true );
    }
    protected function tearDown(): void { $GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_write_fail'] = array(); $_POST = $_GET = $_FILES = array(); FakeHttp::reset(); }
    private static function key( string $email = 'robot@example.iam.gserviceaccount.com' ): string {
        static $private;
        if ( null === $private ) { $key = openssl_pkey_new( array( 'private_key_bits' => 2048 ) ); openssl_pkey_export( $key, $private ); }
        return (string) json_encode( array( 'type' => 'service_account', 'project_id' => 'synthetic-ux-test', 'private_key_id' => 'synthetic-id', 'client_email' => $email, 'private_key' => $private, 'token_uri' => 'https://oauth2.googleapis.com/token' ) );
    }
    private function oauth(): void {
        Options::batch_verified( array( Options::AUTH_MODE => 'oauth', Options::OAUTH_CLIENT_ID => 'test.apps.googleusercontent.com', Connections::SERVICES => array( 'gsc' => 'write' ) ), array( Options::OAUTH_CLIENT_SECRET => 'synthetic-secret', Options::OAUTH_REFRESH_TOKEN => 'synthetic-refresh' ) );
    }
    private function token(): void { FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'synthetic-access', 'expires_in' => 3600 ) ); }
    private function html( string $section = 'connection', string $method = 'service_account' ): string {
        $_GET = array( 'section' => $section, 'method' => $method, 'connection_id' => Connections::id() );
        ob_start(); Admin::render(); return (string) ob_get_clean();
    }
    public function test_import_prepares_alternative_without_switching_oauth(): void {
        $this->oauth(); $revision = Settings::revision();
        $r = Auth::import( self::key(), 'service_account', false, $revision );
        $this->assertTrue( $r['success'] ); $this->assertSame( 'oauth', Options::auth_mode() );
        $this->assertSame( 'synthetic-refresh', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
        $this->assertSame( hash( 'sha256', wp_json_encode( json_decode( self::key(), true ) ) ), hash( 'sha256', Options::get_secret( Options::SA_JSON ) ) ); $this->assertCount( 0, FakeHttp::$requests );
    }
    public function test_first_save_is_pending_until_explicit_activation(): void {
        $r = Auth::save_sa( self::key() ); $this->assertTrue( $r['success'] );
        $this->assertSame( 'f3_google_auth_not_active', Credentials::current()->get_error_code() );
        $this->token(); $r = Auth::activate( 'service_account', Settings::revision() );
        $this->assertTrue( $r['success'] ); $this->assertTrue( $r['authentication_validated'] );
        $this->assertFalse( $r['resource_access_validated'] ); $this->assertFalse( is_wp_error( Credentials::current() ) );
        $this->assertStringNotContainsString( 'synthetic-access', json_encode( $r ) );
    }
    public function test_explicit_activation_switches_only_selected_connection(): void {
        $this->oauth(); Connections::create( 'other', 'Other' );
        Connections::run( 'other', static fn() => Auth::save_sa( self::key() ) );
        $this->token();
        $r = Connections::run( 'other', static fn() => Auth::activate( 'service_account', Settings::revision() ) );
        $this->assertTrue( $r['success'] ); $this->assertSame( 'oauth', Options::auth_mode() );
        $this->assertSame( '', Options::get_secret( Options::SA_JSON ) );
    }
    public function test_failed_activation_preserves_previous_mode_and_credentials(): void {
        $this->oauth(); $before = Settings::revision();
        FakeHttp::push( 'oauth2.googleapis.com/token', 400, array( 'error' => 'invalid_grant' ) );
        $r = Auth::save_sa( self::key(), '', true, $before );
        $this->assertFalse( $r['success'] ); $this->assertSame( 'oauth', Options::auth_mode() );
        $this->assertSame( '', Options::get_secret( Options::SA_JSON ) ); $this->assertSame( $before, Settings::revision() );
    }
    public function test_refused_secret_write_rolls_back_mode_and_subject(): void {
        $this->oauth(); $before = Settings::revision(); $this->token();
        $GLOBALS['f3_test_write_fail'][ Options::SA_JSON ] = true;
        $r = Auth::save_sa( self::key(), 'person@example.test', true, $before );
        $this->assertFalse( $r['success'] ); $this->assertSame( $before, Settings::revision() );
        $this->assertSame( 'oauth', Options::auth_mode() ); $this->assertSame( 'synthetic-refresh', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
    }
    public function test_stale_activation_after_network_validation_returns_conflict(): void {
        $this->oauth(); Auth::save_sa( self::key() ); $this->token();
        $hook = static function( $pre ) { Settings::save( array( Connections::BINDINGS => array( 'gsc_site_url' => 'https://new.example/' ) ) ); return $pre; };
        add_filter( 'pre_http_request', $hook, 20 );
        try { $r = Auth::activate( 'service_account', Settings::revision() ); } finally { remove_filter( 'pre_http_request', $hook, 20 ); }
        $this->assertSame( 'f3_google_configuration_conflict', $r['error_code'] ); $this->assertSame( 'oauth', Options::auth_mode() );
    }
    public function test_opening_other_tab_is_read_only_and_exclusive(): void {
        $this->oauth(); $before = Settings::revision();
        $sa = $this->html();
        $this->assertStringContainsString( 'name="sa_json"', $sa ); $this->assertStringNotContainsString( 'name="oauth_client_secret"', $sa );
        $oauth = $this->html( 'connection', 'oauth' );
        $this->assertStringContainsString( 'name="oauth_client_secret"', $oauth ); $this->assertStringNotContainsString( 'name="sa_json"', $oauth );
        $this->assertSame( $before, Settings::revision() ); $this->assertCount( 0, FakeHttp::$requests );
    }
    public function test_equal_secret_save_is_unchanged_and_keeps_ciphertext(): void {
        Auth::save_sa( self::key(), '' ); $cipher = Options::stored( Options::SA_JSON )['value']; $before = Settings::revision();
        $r = Auth::save_sa( self::key(), '' );
        $this->assertTrue( $r['success'] ); $this->assertFalse( $r['changed'] );
        $this->assertSame( $cipher, Options::stored( Options::SA_JSON )['value'] ); $this->assertSame( $before, Settings::revision() );
    }
    public function test_empty_json_preserves_key_and_omitted_subject(): void {
        Auth::save_sa( self::key(), 'delegate@example.test' );
        $r = Auth::save_sa( '' ); $this->assertTrue( $r['success'] ); $this->assertFalse( $r['changed'] );
        $this->assertSame( 'delegate@example.test', Options::get( Options::SA_SUBJECT ) );
    }
    public function test_oversize_and_wrong_type_never_clear_existing_key(): void {
        Auth::save_sa( self::key(), 'delegate@example.test' ); $before = Settings::revision();
        $this->assertSame( 'f3_google_credential_size', Auth::save_sa( str_repeat( 'a', Auth::JSON_MAX_BYTES + 1 ) )['error_code'] );
        $this->assertSame( 'f3_google_credential_type', Auth::import( self::key(), 'oauth' )['error_code'] );
        $this->assertSame( 'f3_google_credential_json', Auth::import( '{' )['error_code'] );
        $this->assertSame( $before, Settings::revision() );
    }
    public function test_invalid_key_has_no_partial_subject_write(): void {
        Auth::save_sa( self::key(), 'old@example.test' ); $before = Settings::revision();
        $r = Auth::save_sa( '{"type":"service_account"}', 'new@example.test' );
        $this->assertFalse( $r['success'] ); $this->assertSame( $before, Settings::revision() );
    }
    public function test_first_false_and_unchanged_use_verified_settings(): void {
        Options::delete( Options::GA_ENABLED );
        $r = Settings::save( array( Options::GA_ENABLED => false ) ); $this->assertTrue( $r['changed'] );
        $this->assertTrue( Options::stored( Options::GA_ENABLED )['exists'] );
        $r = Settings::save( array( Options::GA_ENABLED => false ) ); $this->assertTrue( $r['persisted'] ); $this->assertFalse( $r['changed'] );
    }
    public function test_stale_configure_returns_conflict_without_changes(): void {
        $old = Settings::revision(); Settings::save( array( Options::SA_SUBJECT => 'someone@example.test' ) ); $latest = Settings::revision();
        $r = Setup::apply( array( 'services' => array( 'gsc' => 'write' ), 'expected_revision' => $old ) );
        $this->assertSame( 'f3_google_configuration_conflict', $r['error_code'] ); $this->assertSame( $latest, Settings::revision() );
    }
    public function test_shared_connection_lock_blocks_other_writers(): void {
        $lock = Lock::acquire( 'configuration:default' );
        try { $r = Auth::save_sa( self::key() ); } finally { Lock::release( $lock ); }
        $this->assertSame( 'f3_google_configuration_busy', $r['error_code'] ); $this->assertSame( '', Options::get_secret( Options::SA_JSON ) );
    }
    public function test_legacy_credentials_remain_active_without_readiness_option(): void {
        $this->oauth(); $this->assertFalse( is_wp_error( Credentials::current() ) );
        $this->html( 'connection', 'oauth' ); $this->assertSame( 'oauth', Options::auth_mode() );
    }
    public function test_new_oauth_client_invalidates_tokens_without_changing_mode(): void {
        $this->oauth(); Options::set( Options::AUTH_MODE, 'service_account' );
        $r = Auth::save_oauth( 'other.apps.googleusercontent.com', 'other-secret' );
        $this->assertTrue( $r['success'] ); $this->assertSame( 'service_account', Options::auth_mode() );
        $this->assertSame( '', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
    }
    private function callback_request(): array {
        $state = bin2hex( random_bytes( 32 ) );
        set_transient( 'f3_mcp_google_oauth_state_' . $state, OAuthFlow::state_record(), 600 );
        return array( $state, new \WP_REST_Request( array( 'state' => $state, 'code' => 'synthetic-code' ) ) );
    }
    public function test_oauth_callback_prepares_and_does_not_activate(): void {
        $this->oauth(); Options::set( Options::AUTH_MODE, 'service_account' );
        list( $state, $request ) = $this->callback_request();
        FakeHttp::push( '/token', 200, array( 'refresh_token' => 'new-refresh', 'scope' => Credentials::SCOPE_GA ) );
        $r = OAuthFlow::complete( $request );
        $this->assertTrue( $r['success'] ); $this->assertFalse( $r['activated'] ); $this->assertSame( 'service_account', Options::auth_mode() );
        $this->assertSame( 'new-refresh', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
        $this->assertFalse( OAuthFlow::complete( $request )['success'] ); $this->assertCount( 1, FakeHttp::$requests );
    }
    public function test_stale_callback_is_rejected_before_http(): void {
        $this->oauth(); list( $state, $request ) = $this->callback_request();
        Settings::save( array( Options::SA_SUBJECT => 'new@example.test' ) );
        $r = OAuthFlow::complete( $request ); $this->assertSame( 'f3_google_configuration_conflict', $r['error_code'] );
        $this->assertSame( 'synthetic-refresh', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) ); $this->assertCount( 0, FakeHttp::$requests );
    }
    public function test_callback_with_changes_during_exchange_preserves_newer_tokens(): void {
        $this->oauth(); list( $state, $request ) = $this->callback_request();
        FakeHttp::push( '/token', 200, array( 'refresh_token' => 'stale-refresh' ) );
        $hook = static function( $pre ) { Settings::save( array(), array( Options::OAUTH_REFRESH_TOKEN => 'newer-refresh' ) ); return $pre; };
        add_filter( 'pre_http_request', $hook, 20 );
        try { $r = OAuthFlow::complete( $request ); } finally { remove_filter( 'pre_http_request', $hook, 20 ); }
        $this->assertSame( 'f3_google_configuration_conflict', $r['error_code'] ); $this->assertSame( 'newer-refresh', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
    }
    public function test_callback_survives_logged_out_rest_but_checks_starter(): void {
        $this->oauth(); list( $state, $request ) = $this->callback_request();
        $GLOBALS['f3_test_caps'] = false; $GLOBALS['f3_test_user'] = 0; $GLOBALS['f3_test_user_caps'] = array( 1 => true );
        FakeHttp::push( '/token', 200, array( 'refresh_token' => 'consented-refresh' ) );
        $this->assertTrue( OAuthFlow::complete( $request )['success'] );
    }
    public function test_oauth_activation_failure_does_not_delete_active_refresh(): void {
        $this->oauth(); $before = Settings::revision(); FakeHttp::push( '/token', 400, array( 'error' => 'invalid_grant' ) );
        $r = Auth::activate( 'oauth' ); $this->assertFalse( $r['success'] ); $this->assertSame( $before, Settings::revision() );
    }
    public function test_callback_failure_is_visible_to_initiator_after_rest_redirect(): void {
        $this->oauth(); list( $state, $request ) = $this->callback_request();
        Settings::save( array( Options::HTTP_TIMEOUT => 31 ) );
        $GLOBALS['f3_test_caps'] = false; $GLOBALS['f3_test_user'] = 0; $GLOBALS['f3_test_user_caps'] = array( 1 => true );
        try { OAuthFlow::handle_callback( $request ); $this->fail( 'redirect expected' ); } catch ( \F3_Test_Redirect $e ) { $this->assertStringContainsString( 'save_failed', $e->location ); }
        $this->assertSame( 'f3_google_configuration_conflict', get_transient( Admin::feedback_key( 'failure', 1 ) )['code'] );
        $this->assertFalse( get_transient( Admin::feedback_key( 'failure', 0 ) ) );
    }
    public function test_clear_uses_verified_batch_and_preserves_other_method(): void {
        $this->oauth(); Auth::save_sa( self::key() ); $before = Settings::revision();
        $GLOBALS['f3_test_write_fail'][ Options::OAUTH_CLIENT_SECRET ] = true;
        $r = Auth::clear( 'oauth' ); $this->assertFalse( $r['success'] ); $this->assertSame( $before, Settings::revision() );
        $GLOBALS['f3_test_write_fail'] = array();
        $this->assertTrue( Auth::clear( 'oauth' )['success'] ); $this->assertSame( hash( 'sha256', wp_json_encode( json_decode( self::key(), true ) ) ), hash( 'sha256', Options::get_secret( Options::SA_JSON ) ) );
    }
    public function test_catalog_versions_and_metadata_share_limits(): void {
        $new = Configuration::read(); $old = Configuration::read( array( 'contract_version' => '1.0.0' ) );
        $this->assertSame( '1.1.0', $new['contract_version'] ); $this->assertSame( '1.0.0', $old['contract_version'] );
        foreach ( Fields::metadata() as $id => $meta ) { $this->assertSame( $meta['label'], $new['options'][ $id ]['ui']['label'] ); $this->assertArrayNotHasKey( 'ui', $old['options'][ $id ] ); }
        $this->assertSame( Auth::JSON_MAX_BYTES, $new['options']['sa_json']['input_max_bytes'] );
        $this->assertContains( 'panel:save-limits', $new['options']['inspection_budget']['allowed_operations'] );
        $hash = $new['definition_sha256']; Auth::save_sa( self::key() ); $next = Configuration::read();
        $this->assertSame( $hash, $next['definition_sha256'] ); $this->assertNotSame( $new['configuration_revision'], $next['configuration_revision'] );
        $this->assertStringNotContainsString( 'PRIVATE KEY', json_encode( $next ) );
    }
    public function test_agents_can_read_legacy_contract_when_no_google_credentials(): void {
        $this->assertTrue( wp_get_ability( 'google/configuration-schema' )->execute( array( 'contract_version' => '1.0.0' ) )['success'] );
        $this->assertCount( 0, FakeHttp::$requests );
    }
    public function test_admin_catalog_is_available_with_closed_channel_and_capability(): void {
        Options::set( Options::ENABLED, false ); $this->assertTrue( Configuration::read_for_admin()['success'] );
        $this->assertFalse( Configuration::read()['success'] );
        $GLOBALS['f3_test_caps'] = false; $this->assertFalse( Configuration::read_for_admin()['success'] );
    }
    public function test_resource_normalization_and_validation(): void {
        $this->assertSame( '1234567890', Resources::normalize( 'ads_customer_id', '123-456-7890' ) );
        $this->assertSame( 'abc_123', Resources::normalize( 'spreadsheet_id', 'https://docs.google.com/spreadsheets/d/abc_123/edit#gid=0' ) );
        $this->assertTrue( is_wp_error( Resources::normalize( 'spreadsheet_id', 'https://evil.test/spreadsheets/d/abc/edit' ) ) );
        $this->assertTrue( is_wp_error( Resources::normalize( 'ga_property_id', 'G-ABC123' ) ) );
        $this->assertSame( '', Resources::normalize( 'ga_property_id', '' ) );
    }
    public function test_sheet_discovery_preserves_incomplete_and_pagination(): void {
        $this->oauth(); Options::set( Connections::SERVICES, array( 'sheets' => 'write' ) ); $this->token();
        FakeHttp::push( '/drive/v3/files', 200, array( 'files' => array( array( 'id' => 'first', 'name' => 'First' ) ), 'nextPageToken' => 'next-token', 'incompleteSearch' => true ) );
        $r = Resources::discover( 'sheets' ); $this->assertTrue( $r['success'] ); $this->assertFalse( $r['complete'] );
        $this->assertSame( 'next-token', $r['next_page_token'] ); $this->assertNotEmpty( $r['warnings'] );
        FakeHttp::push( '/drive/v3/files', 200, array( 'files' => array() ) );
        $next = Resources::discover( 'sheets', $r['next_page_token'] );
        $this->assertSame( array(), $next['items'] ); $this->assertStringContainsString( 'pageToken=next-token', FakeHttp::last()['url'] );
    }
    public function test_discovery_error_is_not_a_successful_empty_list(): void {
        $this->oauth(); Options::set( Connections::SERVICES, array( 'sheets' => 'write' ) ); $this->token();
        FakeHttp::push( '/drive/v3/files', 403, array( 'error' => array( 'code' => 403, 'message' => 'No permission' ) ) );
        $r = Resources::discover( 'sheets' ); $this->assertFalse( $r['success'] ); $this->assertNotEmpty( $r['error_code'] );
    }
    public function test_stale_discovery_not_used_for_other_connection_or_revision(): void {
        set_transient( Admin::feedback_key( 'discovery_ga' ), array( 'revision' => Settings::revision(), 'items' => array( array( 'id' => '123', 'name' => 'Old' ) ) ), 600 );
        $this->assertNotNull( Resources::cached( 'ga' ) ); Settings::save( array( Options::SA_SUBJECT => 'different@example.test' ) );
        $this->assertNull( Resources::cached( 'ga' ) );
    }
    public function test_diagnostics_keys_are_isolated_by_user_and_connection(): void {
        $first = Admin::diagnostic_key(); $GLOBALS['f3_test_user'] = 2; $this->assertNotSame( $first, Admin::diagnostic_key() );
        $GLOBALS['f3_test_user'] = 1; Connections::create( 'second', 'Second' ); Connections::select( 'second' ); $this->assertNotSame( $first, Admin::diagnostic_key() );
    }
    public function test_diagnostics_show_stale_state_and_do_not_run_on_open(): void {
        $record = array( 'revision' => Settings::revision(), 'checks' => array( array( 'name' => 'live_gsc', 'status' => 'passed', 'detail' => 'Read succeeded' ) ) );
        set_transient( Admin::diagnostic_key(), $record, 600 ); Settings::save( array( Options::HTTP_TIMEOUT => 31 ) );
        $html = $this->html( 'diagnostics' ); $this->assertStringContainsString( 'Resultado desatualizado', $html ); $this->assertCount( 0, FakeHttp::$requests );
        $this->assertStringNotContainsString( 'nada as expõe', $html );
    }
    public function test_option_controls_have_help_and_no_duplicate_service_switches(): void {
        Options::set( Options::GA_ENABLED, true ); Options::set( Options::ADS_ENABLED, true );
        $html = $this->html( 'services' ); $this->assertStringNotContainsString( 'f3_mcp_google_toggle_ga', $html ); $this->assertStringNotContainsString( 'f3_mcp_google_toggle_ads', $html );
        $doc = new \DOMDocument(); @$doc->loadHTML( '<?xml encoding="UTF-8">' . $html ); $xpath = new \DOMXPath( $doc );
        foreach ( $xpath->query( '//input[not(@type="hidden") and not(@type="checkbox")]' ) as $input ) {
            if ( 'connection_id' === $input->getAttribute( 'name' ) ) { continue; }
            $id = $input->getAttribute( 'id' );
            $this->assertNotSame( '', $id ); $this->assertGreaterThan( 0, $xpath->query( '//label[@for="' . $id . '"]' )->length );
            $this->assertNotSame( '', $input->getAttribute( 'aria-describedby' ) );
        }
    }
    public function test_service_save_synchronizes_legacy_defaults_and_explicit_clear(): void {
        $r = Setup::apply( array( 'services' => array( 'ga' => 'read' ), 'bindings' => array( 'ga_property_id' => 'properties/12345' ), 'validate_access' => false ) );
        $this->assertTrue( $r['success'] ); $this->assertTrue( Options::ga_enabled() ); $this->assertFalse( Options::ads_enabled() );
        $this->assertSame( '12345', Options::get( Options::GA_DEFAULT_PROPERTY ) );
        Setup::apply( array( 'bindings' => array( 'ga_property_id' => '' ), 'validate_access' => false ) );
        $this->assertSame( '', Options::get( Options::GA_DEFAULT_PROPERTY ) );
    }
    public function test_admin_rejects_out_of_range_limit_instead_of_silent_clamp(): void {
        $_POST = array( 'http_timeout' => '999' ); $before = Settings::revision();
        try { Admin::handle_save_limits(); $this->fail( 'redirect expected' ); } catch ( \F3_Test_Redirect $e ) { $this->assertStringContainsString( 'save_failed', $e->location ); }
        $this->assertSame( $before, Settings::revision() );
    }
    public function test_capability_is_required_for_authentication_changes(): void {
        $this->oauth(); $before = Settings::revision(); $GLOBALS['f3_test_caps'] = false;
        $this->assertFalse( Auth::save_sa( self::key() )['success'] ); $this->assertFalse( Auth::clear( 'oauth' )['success'] );
        $this->assertFalse( Auth::activate( 'oauth' )['success'] ); $this->assertSame( $before, Settings::revision() );
    }
    public function test_mcp_route_detection_accepts_transport_aliases_without_confusing_google_callback(): void {
        $method = new \ReflectionMethod( Plugin::class, 'has_mcp_route' ); $method->setAccessible( true );
        foreach ( array( '/mcp/wp-mcp-fator3', '/mcp/wp-mcp-ultimate', '/mcp/wp-mcp-ultimate/tools', '/wp-mcp-fator3/v1/tools', '/mcp/v1/server' ) as $route ) { $this->assertTrue( $method->invoke( null, array( $route ) ), $route ); }
        foreach ( array( '/wp-mcp-google-fator3/v1/oauth/callback', '/mcp/wp-mcp-fator3-other', '/wp/v2/posts' ) as $route ) { $this->assertFalse( $method->invoke( null, array( $route ) ), $route ); }
    }
}
