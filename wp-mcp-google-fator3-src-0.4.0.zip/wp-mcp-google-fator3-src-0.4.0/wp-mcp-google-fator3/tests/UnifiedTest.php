<?php
/**
 * Testes da camada unificada `google/*`.
 *
 * O que se procura aqui é o que quebra em silêncio quando a camada é usada de
 * verdade: um preset de data que desliza um dia, um filtro que vira LIKE sem
 * escape, um custo que sai em micros e vira um relatório com valores um milhão
 * de vezes maiores, uma conta que falha e leva as outras junto, um segredo que
 * escapa pelo `google/status`.
 *
 * As datas usam 05/09/2026 (um sábado) como "hoje" fixo: sem um dia fixo não há
 * como afirmar nada sobre `last_30_days` sem esperar o relógio.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\SelfTest;
use Fator3\McpGoogle\Unified\Abilities;
use Fator3\McpGoogle\Unified\Catalog;
use Fator3\McpGoogle\Unified\DateRange;
use Fator3\McpGoogle\Unified\Filters;
use Fator3\McpGoogle\Unified\Query;
use PHPUnit\Framework\TestCase;

final class UnifiedTest extends TestCase {

	private const SA_EMAIL = 'robo@projeto-teste.iam.gserviceaccount.com';

	private const DEV_TOKEN = 'developer-token-supersecreto';

	/** @var array{private:string,public:string}|null */
	private static ?array $keys = null;

	/** @var bool As habilidades só precisam ser registradas uma vez. */
	private static bool $registered = false;

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;

		FakeHttp::reset();
		Catalog::flush();

		if ( ! self::$registered ) {
			\Fator3\McpGoogle\Plugin::register_abilities();
			self::$registered = true;
		}
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	private static function today(): \DateTimeImmutable {
		return new \DateTimeImmutable( '2026-09-05' );
	}

	private static function keys(): array {
		if ( null === self::$keys ) {
			$pair = openssl_pkey_new(
				array(
					'private_key_bits' => 2048,
					'private_key_type' => OPENSSL_KEYTYPE_RSA,
				)
			);

			$private = '';
			openssl_pkey_export( $pair, $private );
			$details = openssl_pkey_get_details( $pair );

			self::$keys = array(
				'private' => $private,
				'public'  => (string) $details['key'],
			);
		}

		return self::$keys;
	}

	/**
	 * Liga tudo e deixa um access token já em cache, para os testes de rota não
	 * precisarem enfileirar a troca de token antes de cada chamada.
	 */
	private function enable_all(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set( Options::ADS_LOGIN_CUSTOMER_ID, '1234567890' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, self::DEV_TOKEN );
		Options::set_secret(
			Options::SA_JSON,
			(string) wp_json_encode(
				array(
					'type'         => 'service_account',
					'project_id'   => 'projeto-teste',
					'private_key'  => self::keys()['private'],
					'client_email' => self::SA_EMAIL,
					'token_uri'    => 'https://oauth2.googleapis.com/token',
				)
			)
		);

		// Fixture 0.2: esta credencial não possui propriedades Search Console.
		set_transient( Query::ACCOUNTS_CACHE . 'gsc_' . Credentials::identity_key(), array(), 600 );

		foreach ( array( 'ga', 'ads', 'any', 'gsc', 'siteverification', 'sheets', 'drive' ) as $connector ) {
			Credentials::remember(
				Credentials::cache_key( Credentials::scopes_for( $connector ), self::SA_EMAIL ),
				'tok-de-teste',
				3600
			);
		}
	}

	/**
	 * @param string $name Nome da habilidade.
	 * @param array  $args Entrada.
	 */
	private function execute( string $name, array $args ): array {
		$ability = wp_get_ability( $name );
		$this->assertNotNull( $ability, 'habilidade ausente: ' . $name );

		return $ability->execute( $args );
	}

	/**
	 * Corpo JSON da última requisição feita.
	 */
	private static function last_body(): array {
		$last = FakeHttp::last();

		return is_array( $last ) && is_string( $last['body'] ) ? (array) json_decode( $last['body'], true ) : array();
	}

	// =========================================================================
	// DateRange
	// =========================================================================

	/**
	 * @dataProvider presets
	 */
	public function test_presets_de_data( string $preset, string $from, string $to ): void {
		$range = DateRange::resolve( $preset, self::today() );

		$this->assertIsArray( $range, $preset );
		$this->assertSame( $from, $range['from'], $preset . ' (from)' );
		$this->assertSame( $to, $range['to'], $preset . ' (to)' );
		$this->assertSame( $preset, $range['name'] );
	}

	/**
	 * @return array<string,array{0:string,1:string,2:string}>
	 */
	public static function presets(): array {
		return array(
			// 05/09/2026 é um sábado.
			'today'        => array( 'today', '2026-09-05', '2026-09-05' ),
			'yesterday'    => array( 'yesterday', '2026-09-04', '2026-09-04' ),
			'last_7_days'  => array( 'last_7_days', '2026-08-29', '2026-09-04' ),
			'last_14_days' => array( 'last_14_days', '2026-08-22', '2026-09-04' ),
			'last_28_days' => array( 'last_28_days', '2026-08-08', '2026-09-04' ),
			'last_30_days' => array( 'last_30_days', '2026-08-06', '2026-09-04' ),
			'last_90_days' => array( 'last_90_days', '2026-06-07', '2026-09-04' ),
			'this_week'    => array( 'this_week', '2026-08-31', '2026-09-05' ),
			'last_week'    => array( 'last_week', '2026-08-24', '2026-08-30' ),
			'this_month'   => array( 'this_month', '2026-09-01', '2026-09-05' ),
			'last_month'   => array( 'last_month', '2026-08-01', '2026-08-31' ),
			'this_quarter' => array( 'this_quarter', '2026-07-01', '2026-09-05' ),
			'last_quarter' => array( 'last_quarter', '2026-04-01', '2026-06-30' ),
			'this_year'    => array( 'this_year', '2026-01-01', '2026-09-05' ),
			'last_year'    => array( 'last_year', '2025-01-01', '2025-12-31' ),
		);
	}

	public function test_todo_preset_documentado_tem_teste(): void {
		$tested = array();
		foreach ( self::presets() as $row ) {
			$tested[] = $row[0];
		}

		$this->assertSame( array(), array_diff( DateRange::presets(), $tested ) );
	}

	public function test_preset_tambem_aceita_objeto_e_recusa_desconhecido(): void {
		$range = DateRange::resolve( array( 'preset' => 'last_7_days' ), self::today() );
		$this->assertSame( '2026-08-29', $range['from'] );

		$this->assertTrue( is_wp_error( DateRange::resolve( 'ultimos_7_dias', self::today() ) ) );
		$this->assertTrue( is_wp_error( DateRange::resolve( '', self::today() ) ) );
		$this->assertTrue( is_wp_error( DateRange::resolve( null, self::today() ) ) );
	}

	public function test_periodo_personalizado_valido_e_invalido(): void {
		$range = DateRange::resolve(
			array(
				'from' => '2026-08-01',
				'to'   => '2026-08-31',
			),
			self::today()
		);

		$this->assertSame( '2026-08-01', $range['from'] );
		$this->assertSame( '2026-08-31', $range['to'] );
		$this->assertSame( 'custom', $range['name'] );

		// Fora do formato.
		$this->assertTrue( is_wp_error( DateRange::resolve( array( 'from' => '01/08/2026', 'to' => '2026-08-31' ), self::today() ) ) );

		// Dia que não existe: o PHP aceitaria e viraria 3 de março.
		$this->assertTrue( is_wp_error( DateRange::resolve( array( 'from' => '2026-02-31', 'to' => '2026-03-05' ), self::today() ) ) );

		// Invertido.
		$this->assertTrue( is_wp_error( DateRange::resolve( array( 'from' => '2026-08-31', 'to' => '2026-08-01' ), self::today() ) ) );

		// Só uma das pontas.
		$this->assertTrue( is_wp_error( DateRange::resolve( array( 'from' => '2026-08-01' ), self::today() ) ) );
	}

	public function test_comparacao_periodo_anterior_e_ano_anterior(): void {
		$base = DateRange::resolve( 'last_30_days', self::today() );

		$previous = DateRange::compare( $base, 'previous_period', self::today() );
		$this->assertSame( '2026-07-07', $previous['from'] );
		$this->assertSame( '2026-08-05', $previous['to'] );
		$this->assertSame( 'previous_period', $previous['name'] );

		$year = DateRange::compare( $base, 'previous_year', self::today() );
		$this->assertSame( '2025-08-06', $year['from'] );
		$this->assertSame( '2025-09-04', $year['to'] );

		// O período anterior tem exatamente o mesmo número de dias.
		$dias = static function ( array $range ): int {
			$from = new \DateTimeImmutable( $range['from'] );
			$to   = new \DateTimeImmutable( $range['to'] );

			return (int) $from->diff( $to )->days + 1;
		};

		$this->assertSame( $dias( $base ), $dias( $previous ) );

		$custom = DateRange::compare(
			$base,
			array(
				'from' => '2025-01-01',
				'to'   => '2025-01-31',
			),
			self::today()
		);
		$this->assertSame( 'custom', $custom['name'] );
		$this->assertSame( '2025-01-31', $custom['to'] );

		$this->assertTrue( is_wp_error( DateRange::compare( $base, 'periodo_anterior', self::today() ) ) );
	}

	public function test_comparacao_de_mes_inteiro_nao_desliza(): void {
		$base = DateRange::resolve( 'last_month', self::today() );
		$this->assertSame( array( '2026-08-01', '2026-08-31' ), array( $base['from'], $base['to'] ) );

		$previous = DateRange::compare( $base, 'previous_period', self::today() );
		$this->assertSame( '2026-07-01', $previous['from'] );
		$this->assertSame( '2026-07-31', $previous['to'] );
	}

	// =========================================================================
	// Filters — GA4
	// =========================================================================

	public function test_filtro_de_dimensao_vira_string_filter(): void {
		$out = Filters::to_ga(
			array(
				array(
					'field'    => 'channel',
					'operator' => 'eq',
					'value'    => 'Organic Search',
				),
			),
			array( 'sessionDefaultChannelGroup' ),
			array( 'sessions' )
		);

		$this->assertArrayNotHasKey( 'metricFilter', $out );
		$this->assertSame( 'sessionDefaultChannelGroup', $out['dimensionFilter']['filter']['fieldName'] );
		$this->assertSame( 'EXACT', $out['dimensionFilter']['filter']['stringFilter']['matchType'] );
		$this->assertSame( 'Organic Search', $out['dimensionFilter']['filter']['stringFilter']['value'] );
		$this->assertFalse( $out['dimensionFilter']['filter']['stringFilter']['caseSensitive'] );
	}

	public function test_filtro_de_metrica_vira_numeric_filter(): void {
		$inteiro = Filters::to_ga(
			array(
				array(
					'field'    => 'sessions',
					'operator' => 'gt',
					'value'    => 100,
				),
			),
			array(),
			array( 'sessions' )
		);

		$this->assertArrayNotHasKey( 'dimensionFilter', $inteiro );
		$this->assertSame( 'GREATER_THAN', $inteiro['metricFilter']['filter']['numericFilter']['operation'] );
		$this->assertSame( array( 'int64Value' => '100' ), $inteiro['metricFilter']['filter']['numericFilter']['value'] );

		$decimal = Filters::to_ga(
			array(
				array(
					'field'    => 'bounceRate',
					'operator' => 'lte',
					'value'    => 0.5,
				),
			),
			array(),
			array( 'bounceRate' )
		);

		$this->assertSame( array( 'doubleValue' => 0.5 ), $decimal['metricFilter']['filter']['numericFilter']['value'] );

		// Métrica com valor de texto é erro, não um filtro que não filtra nada.
		$this->assertTrue(
			is_wp_error(
				Filters::to_ga(
					array(
						array(
							'field'    => 'sessions',
							'operator' => 'gt',
							'value'    => 'muitas',
						),
					),
					array(),
					array( 'sessions' )
				)
			)
		);
	}

	public function test_filtros_ga_in_null_regex_e_negacao(): void {
		$out = Filters::to_ga(
			array(
				array(
					'field'    => 'country',
					'operator' => 'in',
					'value'    => array( 'Brazil', 'Portugal' ),
				),
			),
			array( 'country' ),
			array()
		);
		$this->assertSame( array( 'Brazil', 'Portugal' ), $out['dimensionFilter']['filter']['inListFilter']['values'] );

		$vazio = Filters::to_ga(
			array(
				array(
					'field'    => 'landing_page',
					'operator' => 'null',
				),
			),
			array( 'landingPage' ),
			array()
		);
		$this->assertArrayHasKey( 'emptyFilter', $vazio['dimensionFilter']['filter'] );

		$nao_vazio = Filters::to_ga(
			array(
				array(
					'field'    => 'landing_page',
					'operator' => 'notnull',
				),
			),
			array( 'landingPage' ),
			array()
		);
		$this->assertArrayHasKey( 'emptyFilter', $nao_vazio['dimensionFilter']['notExpression']['filter'] );

		$regex = Filters::to_ga(
			array(
				array(
					'field'    => 'page',
					'operator' => 'regex',
					'value'    => '^/blog/.*',
				),
			),
			array( 'pagePath' ),
			array()
		);
		$this->assertSame( 'FULL_REGEXP', $regex['dimensionFilter']['filter']['stringFilter']['matchType'] );
		$this->assertSame( 'pagePath', $regex['dimensionFilter']['filter']['fieldName'] );

		$negado = Filters::to_ga(
			array(
				array(
					'field'    => 'country',
					'operator' => 'ncontains',
					'value'    => 'Bra',
				),
			),
			array( 'country' ),
			array()
		);
		$this->assertSame( 'CONTAINS', $negado['dimensionFilter']['notExpression']['filter']['stringFilter']['matchType'] );
	}

	public function test_varios_filtros_ga_viram_and_group(): void {
		$out = Filters::to_ga(
			array(
				array(
					'field'    => 'country',
					'operator' => 'eq',
					'value'    => 'Brazil',
				),
				array(
					'field'    => 'device',
					'operator' => 'eq',
					'value'    => 'mobile',
				),
				array(
					'field'    => 'sessions',
					'operator' => 'gte',
					'value'    => 10,
				),
			),
			array( 'country', 'deviceCategory' ),
			array( 'sessions' )
		);

		$this->assertCount( 2, $out['dimensionFilter']['andGroup']['expressions'] );
		$this->assertSame( 'deviceCategory', $out['dimensionFilter']['andGroup']['expressions'][1]['filter']['fieldName'] );

		// Uma condição só de métrica não ganha andGroup.
		$this->assertArrayNotHasKey( 'andGroup', $out['metricFilter'] );
	}

	public function test_operador_invalido_e_recusado(): void {
		$this->assertTrue(
			is_wp_error(
				Filters::to_ga(
					array(
						array(
							'field'    => 'country',
							'operator' => 'like',
							'value'    => 'Bra',
						),
					),
					array( 'country' ),
					array()
				)
			)
		);
	}

	// =========================================================================
	// Filters — GAQL
	// =========================================================================

	/**
	 * @param array  $filter    Filtro a traduzir.
	 * @param string $esperado  Condição esperada.
	 *
	 * @dataProvider condicoes_gaql
	 */
	public function test_filtros_viram_condicoes_gaql( array $filter, string $esperado ): void {
		$conditions = Filters::to_gaql( array( $filter ), array( Catalog::class, 'ads_resolve' ) );

		$this->assertIsArray( $conditions, is_wp_error( $conditions ) ? $conditions->get_error_message() : '' );
		$this->assertSame( $esperado, $conditions[0] );
	}

	/**
	 * @return array<string,array{0:array,1:string}>
	 */
	public static function condicoes_gaql(): array {
		return array(
			'enum sem aspas'      => array(
				array(
					'field'    => 'campaign_status',
					'operator' => 'eq',
					'value'    => 'enabled',
				),
				'campaign.status = ENABLED',
			),
			'enum de tipo'        => array(
				array(
					'field'    => 'campaign_type',
					'operator' => 'neq',
					'value'    => 'search',
				),
				'campaign.advertising_channel_type != SEARCH',
			),
			'string escapada'     => array(
				array(
					'field'    => 'campaign_name',
					'operator' => 'eq',
					'value'    => "O'Reilly",
				),
				"campaign.name = 'O\\'Reilly'",
			),
			'like com curinga'    => array(
				array(
					'field'    => 'campaign_name',
					'operator' => 'contains',
					'value'    => 'Black Friday',
				),
				"campaign.name LIKE '%Black Friday%'",
			),
			'like negado'         => array(
				array(
					'field'    => 'campaign_name',
					'operator' => 'ncontains',
					'value'    => 'teste',
				),
				"campaign.name NOT LIKE '%teste%'",
			),
			'comeca com'          => array(
				array(
					'field'    => 'campaign_name',
					'operator' => 'begins_with',
					'value'    => 'BR - ',
				),
				"campaign.name LIKE 'BR - %'",
			),
			'termina com'         => array(
				array(
					'field'    => 'campaign_name',
					'operator' => 'ends_with',
					'value'    => '2026',
				),
				"campaign.name LIKE '%2026'",
			),
			'porcento é literal'  => array(
				array(
					'field'    => 'campaign_name',
					'operator' => 'contains',
					'value'    => '50% off',
				),
				"campaign.name LIKE '%50\\% off%'",
			),
			'numero sem aspas'    => array(
				array(
					'field'    => 'clicks',
					'operator' => 'gte',
					'value'    => 10,
				),
				'metrics.clicks >= 10',
			),
			'moeda vira micros'   => array(
				array(
					'field'    => 'cost',
					'operator' => 'gt',
					'value'    => 12.5,
				),
				'metrics.cost_micros > 12500000',
			),
			'in de enum'          => array(
				array(
					'field'    => 'campaign_status',
					'operator' => 'in',
					'value'    => array( 'ENABLED', 'paused' ),
				),
				'campaign.status IN (ENABLED, PAUSED)',
			),
			'in de string'        => array(
				array(
					'field'    => 'campaign_name',
					'operator' => 'in',
					'value'    => 'Marca,Genérico',
				),
				"campaign.name IN ('Marca', 'Genérico')",
			),
			'id vai sem aspas'    => array(
				array(
					'field'    => 'campaign_id',
					'operator' => 'eq',
					'value'    => '112233',
				),
				'campaign.id = 112233',
			),
			'regex'               => array(
				array(
					'field'    => 'search_term',
					'operator' => 'regex',
					'value'    => '^comprar .*',
				),
				"REGEXP_MATCH(search_term_view.search_term, '^comprar .*')",
			),
			'nulo'                => array(
				array(
					'field'    => 'ad_name',
					'operator' => 'null',
				),
				'ad_group_ad.ad.name IS NULL',
			),
			'nao nulo'            => array(
				array(
					'field'    => 'ad_name',
					'operator' => 'notnull',
				),
				'ad_group_ad.ad.name IS NOT NULL',
			),
			'nativo desconhecido' => array(
				array(
					'field'    => 'metrics.video_quartile_p75_rate',
					'operator' => 'gt',
					'value'    => 0.5,
				),
				'metrics.video_quartile_p75_rate > 0.5',
			),
		);
	}

	public function test_gaql_nao_aceita_fechar_a_string_com_barra(): void {
		$conditions = Filters::to_gaql(
			array(
				array(
					'field'    => 'campaign_name',
					'operator' => 'eq',
					// A barra final tentaria escapar a aspa de fechamento.
					'value'    => "fim\\",
				),
			),
			array( Catalog::class, 'ads_resolve' )
		);

		$this->assertSame( "campaign.name = 'fim\\\\'", $conditions[0] );
	}

	public function test_campo_derivado_nao_pode_ser_filtrado(): void {
		$this->assertTrue(
			is_wp_error(
				Filters::to_gaql(
					array(
						array(
							'field'    => 'roas',
							'operator' => 'gt',
							'value'    => 2,
						),
					),
					array( Catalog::class, 'ads_resolve' )
				)
			)
		);
	}

	// =========================================================================
	// Catalog
	// =========================================================================

	public function test_catalogo_tem_ids_unicos_e_campos_completos(): void {
		$fields = Catalog::ads_fields();
		$ids    = array();

		$this->assertGreaterThan( 40, count( $fields ) );

		foreach ( $fields as $field ) {
			foreach ( array( 'id', 'native', 'type', 'label', 'kind' ) as $key ) {
				$this->assertArrayHasKey( $key, $field );
			}

			$this->assertArrayNotHasKey( $field['id'], $ids, 'id repetido: ' . $field['id'] );
			$ids[ $field['id'] ] = true;

			$this->assertContains( $field['type'], array( 'metric', 'dimension' ) );
			$this->assertContains( $field['kind'], array( 'integer', 'float', 'currency', 'percent', 'string', 'date' ) );

			if ( '' === $field['native'] ) {
				$this->assertNotEmpty( $field['derived'] ?? false, $field['id'] . ' sem nativo deveria ser derivado' );
				continue;
			}

			$this->assertMatchesRegularExpression(
				'/^(metrics|segments|campaign|campaign_budget|ad_group|ad_group_ad|ad_group_criterion|search_term_view|geographic_view|customer)\./',
				$field['native'],
				$field['id']
			);
		}

		// As métricas que a fase 2c prometeu entregar.
		foreach ( array( 'impressions', 'clicks', 'cost', 'ctr', 'average_cpc', 'average_cpm', 'conversions', 'conversions_value', 'cost_per_conversion', 'conversion_rate', 'all_conversions', 'all_conversions_value', 'search_impression_share', 'search_top_impression_share', 'absolute_top_impression_percentage', 'interactions', 'interaction_rate', 'video_views', 'view_through_conversions', 'roas' ) as $id ) {
			$this->assertArrayHasKey( $id, $ids, 'métrica ausente do catálogo: ' . $id );
		}

		foreach ( array( 'date', 'week', 'month', 'quarter', 'year', 'day_of_week', 'device', 'ad_network_type', 'campaign_id', 'campaign_name', 'campaign_status', 'campaign_type', 'campaign_bidding_strategy_type', 'campaign_budget', 'ad_group_id', 'ad_group_name', 'ad_group_status', 'ad_id', 'ad_name', 'ad_type', 'ad_status', 'keyword', 'keyword_match_type', 'search_term', 'account_id', 'account_name', 'currency', 'conversion_action_name', 'geo_country' ) as $id ) {
			$this->assertArrayHasKey( $id, $ids, 'dimensão ausente do catálogo: ' . $id );
		}
	}

	public function test_resolucao_por_id_por_nativo_e_sintetizada(): void {
		$por_id = Catalog::ads_resolve( 'cost' );
		$this->assertSame( 'metrics.cost_micros', $por_id['native'] );
		$this->assertSame( 'metric', $por_id['type'] );
		$this->assertTrue( $por_id['micros'] );

		$por_nativo = Catalog::ads_resolve( 'metrics.clicks' );
		$this->assertSame( 'clicks', $por_nativo['id'] );

		$dimensao_nativa = Catalog::ads_resolve( 'campaign.name' );
		$this->assertSame( 'campaign_name', $dimensao_nativa['id'] );

		$metrica_nova = Catalog::ads_resolve( 'metrics.video_quartile_p75_rate' );
		$this->assertSame( 'metric', $metrica_nova['type'] );
		$this->assertSame( 'metrics.video_quartile_p75_rate', $metrica_nova['native'] );

		$dimensao_nova = Catalog::ads_resolve( 'asset.name' );
		$this->assertSame( 'dimension', $dimensao_nova['type'] );

		$micros_novo = Catalog::ads_resolve( 'metrics.something_micros' );
		$this->assertTrue( $micros_novo['micros'] );

		foreach ( array( '', 'clique', 'metrics clicks', 'drop table', '1metrics.x', 'metrics.clicks; drop' ) as $invalido ) {
			$this->assertTrue( is_wp_error( Catalog::ads_resolve( $invalido ) ), 'aceitou: ' . $invalido );
		}

		// Identificador GAQL é sempre minúsculo; aceitar a variação de caixa e
		// normalizar é mais útil do que recusar.
		$this->assertSame( 'campaign_name', Catalog::ads_resolve( 'Campaign.Name' )['id'] );
	}

	public function test_apelidos_do_ga_traduzem_o_que_precisa(): void {
		$this->assertSame( 'activeUsers', Catalog::ga_resolve( 'users' ) );
		$this->assertSame( 'screenPageViews', Catalog::ga_resolve( 'pageviews' ) );
		$this->assertSame( 'sessionDefaultChannelGroup', Catalog::ga_resolve( 'channel' ) );
		$this->assertSame( 'advertiserAdCost', Catalog::ga_resolve( 'cost' ) );

		// Um nome que a API já entende passa direto.
		$this->assertSame( 'sessions', Catalog::ga_resolve( 'sessions' ) );
		$this->assertSame( 'customEvent:plano', Catalog::ga_resolve( 'customEvent:plano' ) );
	}

	// =========================================================================
	// Escolha de recurso no Google Ads
	// =========================================================================

	/**
	 * @param array  $natives  Campos nativos envolvidos.
	 * @param string $esperado Recurso esperado.
	 *
	 * @dataProvider recursos
	 */
	public function test_escolha_de_recurso( array $natives, string $esperado ): void {
		$this->assertSame( $esperado, Query::ads_resource( $natives ) );
	}

	/**
	 * @return array<string,array{0:array,1:string}>
	 */
	public static function recursos(): array {
		return array(
			'só métricas'      => array( array( 'metrics.clicks', 'segments.date' ), 'customer' ),
			'campanha'         => array( array( 'campaign.name', 'metrics.clicks' ), 'campaign' ),
			'orçamento'        => array( array( 'campaign_budget.amount_micros' ), 'campaign' ),
			'grupo'            => array( array( 'ad_group.name', 'campaign.name' ), 'ad_group' ),
			'anúncio'          => array( array( 'ad_group_ad.ad.id', 'ad_group.name' ), 'ad_group_ad' ),
			'palavra-chave'    => array( array( 'ad_group_criterion.keyword.text', 'ad_group.name' ), 'keyword_view' ),
			'termo de busca'   => array( array( 'search_term_view.search_term', 'campaign.name' ), 'search_term_view' ),
			'geográfico'       => array( array( 'geographic_view.country_criterion_id' ), 'geographic_view' ),
			'conta'            => array( array( 'customer.descriptive_name' ), 'customer' ),
		);
	}

	public function test_recurso_explicito_vence_a_deducao(): void {
		$this->enable_all();

		$preview = Query::preview(
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '1234567890' ),
				'metrics'    => array( 'clicks' ),
				'dimensions' => array( 'campaign_name' ),
				'resource'   => 'ad_group',
				'date_range' => array(
					'from' => '2026-08-01',
					'to'   => '2026-08-31',
				),
			)
		);

		$this->assertSame( 'ad_group', $preview['resource'] );
		$this->assertStringContainsString( ' FROM ad_group ', $preview['gaql'] );

		$invalido = Query::preview(
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '1234567890' ),
				'metrics'    => array( 'clicks' ),
				'resource'   => 'campaign; drop',
				'date_range' => 'last_7_days',
			)
		);

		$this->assertTrue( is_wp_error( $invalido ) );
	}

	// =========================================================================
	// google/query — GA4
	// =========================================================================

	public function test_query_ga4_ponta_a_ponta_com_comparacao(): void {
		$this->enable_all();

		FakeHttp::push(
			'analyticsdata.googleapis.com',
			200,
			array(
				'dimensionHeaders' => array(
					array( 'name' => 'dateRange' ),
					array( 'name' => 'sessionDefaultChannelGroup' ),
				),
				'metricHeaders'    => array(
					array(
						'name' => 'sessions',
						'type' => 'TYPE_INTEGER',
					),
				),
				'rows'             => array(
					array(
						'dimensionValues' => array( array( 'value' => 'current' ), array( 'value' => 'Organic Search' ) ),
						'metricValues'    => array( array( 'value' => '1500' ) ),
					),
					array(
						'dimensionValues' => array( array( 'value' => 'previous' ), array( 'value' => 'Organic Search' ) ),
						'metricValues'    => array( array( 'value' => '1200' ) ),
					),
				),
				'rowCount'         => 2,
			)
		);

		$result = $this->execute(
			'google/query',
			array(
				'connector'          => 'ga4',
				'accounts'           => array( 'properties/123456' ),
				'metrics'            => array( 'sessions' ),
				'dimensions'         => array( 'channel' ),
				'date_range'         => array(
					'from' => '2026-08-06',
					'to'   => '2026-09-04',
				),
				'compare_date_range' => 'previous_period',
				'filters'            => array(
					array(
						'field'    => 'country',
						'operator' => 'eq',
						'value'    => 'Brazil',
					),
				),
				'order_by'           => array(
					array(
						'field'     => 'sessions',
						'direction' => 'desc',
					),
				),
				'limit'              => 100,
			)
		);

		$this->assertTrue( $result['success'], (string) ( $result['message'] ?? '' ) );

		// ---- o que foi enviado
		$request = FakeHttp::last();
		$this->assertSame( 'https://analyticsdata.googleapis.com/v1beta/properties/123456:runReport', $request['url'] );

		$body = self::last_body();
		$this->assertSame(
			array(
				array(
					'startDate' => '2026-08-06',
					'endDate'   => '2026-09-04',
					'name'      => 'current',
				),
				array(
					'startDate' => '2026-07-07',
					'endDate'   => '2026-08-05',
					'name'      => 'previous',
				),
			),
			$body['dateRanges']
		);
		$this->assertSame( array( array( 'name' => 'sessionDefaultChannelGroup' ) ), $body['dimensions'] );
		$this->assertSame( array( array( 'name' => 'sessions' ) ), $body['metrics'] );
		$this->assertSame( 'country', $body['dimensionFilter']['filter']['fieldName'] );
		$this->assertSame( 'EXACT', $body['dimensionFilter']['filter']['stringFilter']['matchType'] );
		$this->assertArrayNotHasKey( 'metricFilter', $body );
		$this->assertSame( array( array( 'metric' => array( 'metricName' => 'sessions' ), 'desc' => true ) ), $body['orderBys'] );
		$this->assertSame( 100, $body['limit'] );

		// ---- o que voltou
		$this->assertSame(
			array( 'date_range_name', 'channel', 'sessions' ),
			array_column( $result['columns'], 'id' )
		);
		$this->assertSame(
			array(
				array( 'current', 'Organic Search', 1500 ),
				array( 'previous', 'Organic Search', 1200 ),
			),
			$result['rows']
		);
		$this->assertSame( 2, $result['row_count'] );
		$this->assertFalse( $result['truncated'] );
		$this->assertSame( array( 'from' => '2026-08-06', 'to' => '2026-09-04', 'name' => 'custom' ), $result['date_range'] );
		$this->assertSame( 'previous_period', $result['compare_date_range']['name'] );
		$this->assertSame( array( array( 'account_id' => 'properties/123456', 'name' => '' ) ), $result['accounts'] );
		$this->assertSame( array(), $result['warnings'] );
		$this->assertSame( 'ga4', $result['request']['connector'] );
		$this->assertSame( 100, $result['request']['ga_body']['limit'] );

		// O valor da métrica é número, não texto — senão o agente soma strings.
		$this->assertIsInt( $result['rows'][0][2] );
	}

	public function test_query_ga4_normaliza_a_data_e_sem_comparacao_nao_tem_coluna_de_periodo(): void {
		$this->enable_all();

		FakeHttp::push(
			'analyticsdata.googleapis.com',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'date' ) ),
				'metricHeaders'    => array(
					array(
						'name' => 'activeUsers',
						'type' => 'TYPE_INTEGER',
					),
				),
				'rows'             => array(
					array(
						'dimensionValues' => array( array( 'value' => '20260904' ) ),
						'metricValues'    => array( array( 'value' => '42' ) ),
					),
				),
				'rowCount'         => 1,
			)
		);

		$result = $this->execute(
			'google/query',
			array(
				'connector'  => 'ga4',
				'accounts'   => array( '123456' ),
				'metrics'    => array( 'users' ),
				'dimensions' => array( 'date' ),
				'date_range' => 'yesterday',
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertSame( array( 'date', 'users' ), array_column( $result['columns'], 'id' ) );
		$this->assertSame( array( array( '2026-09-04', 42 ) ), $result['rows'] );
		$this->assertSame( array( array( 'name' => 'activeUsers' ) ), self::last_body()['metrics'] );
	}

	public function test_query_ga4_marca_truncated_quando_a_api_diz_que_ha_mais(): void {
		$this->enable_all();

		FakeHttp::push(
			'analyticsdata.googleapis.com',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'country' ) ),
				'metricHeaders'    => array( array( 'name' => 'sessions', 'type' => 'TYPE_INTEGER' ) ),
				'rows'             => array(
					array(
						'dimensionValues' => array( array( 'value' => 'Brazil' ) ),
						'metricValues'    => array( array( 'value' => '10' ) ),
					),
				),
				'rowCount'         => 900,
			)
		);

		$result = $this->execute(
			'google/query',
			array(
				'connector'  => 'ga4',
				'accounts'   => array( 'properties/1' ),
				'metrics'    => array( 'sessions' ),
				'dimensions' => array( 'country' ),
				'date_range' => 'last_7_days',
				'limit'      => 1,
			)
		);

		$this->assertTrue( $result['truncated'] );
	}

	// =========================================================================
	// google/query — Google Ads
	// =========================================================================

	public function test_query_ads_ponta_a_ponta_com_custo_em_moeda_e_roas(): void {
		$this->enable_all();

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'fieldMask' => 'campaign.name,segments.date,metrics.cost_micros,metrics.clicks,metrics.conversions,metrics.conversions_value',
				'results'   => array(
					array(
						'campaign' => array( 'name' => 'BR - Marca' ),
						'segments' => array( 'date' => '2026-08-01' ),
						'metrics'  => array(
							'costMicros'       => '12500000',
							'clicks'           => '340',
							'conversions'      => 12.5,
							'conversionsValue' => 50000.0,
						),
					),
				),
			)
		);

		$result = $this->execute(
			'google/query',
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '123-456-7890' ),
				'metrics'    => array( 'cost', 'clicks', 'conversions', 'roas' ),
				'dimensions' => array( 'campaign_name', 'date' ),
				'date_range' => array(
					'from' => '2026-08-01',
					'to'   => '2026-08-31',
				),
				'filters'    => array(
					array(
						'field'    => 'campaign_status',
						'operator' => 'eq',
						'value'    => 'ENABLED',
					),
				),
				'order_by'   => array(
					array(
						'field'     => 'cost',
						'direction' => 'desc',
					),
				),
				'limit'      => 500,
			)
		);

		$this->assertTrue( $result['success'], (string) ( $result['message'] ?? '' ) );

		// ---- a GAQL exata
		$request = FakeHttp::last();
		$this->assertSame( 'https://googleads.googleapis.com/v25/customers/1234567890/googleAds:search', $request['url'] );
		$this->assertSame( self::DEV_TOKEN, $request['headers']['developer-token'] );

		$this->assertSame(
			'SELECT campaign.name, segments.date, metrics.cost_micros, metrics.clicks, metrics.conversions, metrics.conversions_value'
				. ' FROM campaign'
				. " WHERE campaign.status = ENABLED AND segments.date BETWEEN '2026-08-01' AND '2026-08-31'"
				. ' ORDER BY metrics.cost_micros DESC'
				. ' LIMIT 500 PARAMETERS omit_unselected_resource_names=true',
			self::last_body()['query']
		);
		$this->assertSame( 'campaign', $result['request']['resource'] );

		// ---- a tabela
		$this->assertSame(
			array( 'campaign_name', 'date', 'cost', 'clicks', 'conversions', 'roas' ),
			array_column( $result['columns'], 'id' )
		);

		$row = $result['rows'][0];
		$this->assertSame( 'BR - Marca', $row[0] );
		$this->assertSame( '2026-08-01', $row[1] );
		$this->assertSame( 12.5, $row[2], 'custo em micros deveria virar moeda' );
		$this->assertSame( 340, $row[3] );
		$this->assertSame( 12.5, $row[4] );
		$this->assertSame( 4000.0, $row[5], 'roas = 50000 / 12,5' );
	}

	public function test_query_ads_com_comparacao_faz_duas_consultas(): void {
		$this->enable_all();

		foreach ( array( '100', '80' ) as $clicks ) {
			FakeHttp::push(
				'googleAds:search',
				200,
				array(
					'fieldMask' => 'metrics.clicks',
					'results'   => array( array( 'metrics' => array( 'clicks' => $clicks ) ) ),
				)
			);
		}

		$result = $this->execute(
			'google/query',
			array(
				'connector'          => 'google-ads',
				'accounts'           => array( '1234567890' ),
				'metrics'            => array( 'clicks' ),
				'date_range'         => array(
					'from' => '2026-08-01',
					'to'   => '2026-08-31',
				),
				'compare_date_range' => 'previous_year',
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertSame( array( 'date_range_name', 'clicks' ), array_column( $result['columns'], 'id' ) );
		$this->assertSame(
			array(
				array( 'current', 100 ),
				array( 'previous', 80 ),
			),
			$result['rows']
		);

		// Sem dimensão de entidade, o recurso é `customer`.
		$this->assertSame( 'customer', $result['request']['resource'] );
		$this->assertStringContainsString( "BETWEEN '2025-08-01' AND '2025-08-31'", (string) self::last_body()['query'] );
		$this->assertSame( 2, FakeHttp::count() );
	}

	public function test_query_ads_conta_que_falha_vira_aviso_e_as_outras_seguem(): void {
		$this->enable_all();

		FakeHttp::push(
			'customers/1111111111/googleAds:search',
			403,
			array(
				'error' => array(
					'code'    => 403,
					'message' => 'sem permissão',
					'status'  => 'PERMISSION_DENIED',
					'details' => array(
						array(
							'requestId' => 'req-1',
							'errors'    => array(
								array(
									'message'   => 'O usuário não tem permissão nesta conta.',
									'errorCode' => array( 'authorizationError' => 'USER_PERMISSION_DENIED' ),
								),
							),
						),
					),
				),
			)
		);

		FakeHttp::push(
			'customers/2222222222/googleAds:search',
			200,
			array(
				'fieldMask' => 'metrics.clicks',
				'results'   => array( array( 'metrics' => array( 'clicks' => '7' ) ) ),
			)
		);

		$result = $this->execute(
			'google/query',
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '1111111111', '2222222222' ),
				'metrics'    => array( 'clicks' ),
				'date_range' => 'last_7_days',
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertCount( 1, $result['warnings'] );
		$this->assertStringContainsString( '1111111111', $result['warnings'][0] );
		$this->assertStringContainsString( 'permissão', $result['warnings'][0] );

		// Duas contas pedidas: as colunas de conta aparecem, e só a que
		// respondeu entra em `accounts`.
		$this->assertSame( array( 'account_id', 'account_name', 'clicks' ), array_column( $result['columns'], 'id' ) );
		$this->assertSame( array( array( '2222222222', '', 7 ) ), $result['rows'] );
		$this->assertSame( array( array( 'account_id' => '2222222222', 'name' => '' ) ), $result['accounts'] );
	}

	public function test_query_com_todas_as_contas_falhando_e_erro(): void {
		$this->enable_all();

		FakeHttp::push(
			'googleAds:search',
			500,
			array( 'error' => array( 'code' => 500, 'message' => 'caiu', 'status' => 'INTERNAL' ) )
		);

		$result = $this->execute(
			'google/query',
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '1234567890' ),
				'metrics'    => array( 'clicks' ),
				'date_range' => 'today',
			)
		);

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_query_failed', $result['error_code'] );
	}

	public function test_query_recusa_entrada_incompleta_ou_incoerente(): void {
		$this->enable_all();

		$sem_metrica = $this->execute(
			'google/query',
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '1234567890' ),
				'metrics'    => array(),
				'date_range' => 'today',
			)
		);
		$this->assertSame( 'f3_google_query_metrics', $sem_metrica['error_code'] );

		$sem_conta = $this->execute(
			'google/query',
			array(
				'connector'  => 'ga4',
				'accounts'   => array(),
				'metrics'    => array( 'sessions' ),
				'date_range' => 'today',
			)
		);
		$this->assertSame( 'f3_google_query_accounts', $sem_conta['error_code'] );

		$dois_conectores = $this->execute(
			'google/query',
			array(
				'connector'  => 'all',
				'accounts'   => array( '1234567890' ),
				'metrics'    => array( 'clicks' ),
				'date_range' => 'today',
			)
		);
		$this->assertSame( 'f3_google_query_connector', $dois_conectores['error_code'] );

		$dimensao_como_metrica = $this->execute(
			'google/query',
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '1234567890' ),
				'metrics'    => array( 'campaign_name' ),
				'date_range' => 'today',
			)
		);
		$this->assertSame( 'f3_google_field_type', $dimensao_como_metrica['error_code'] );

		// Nenhuma delas pode ter chegado à rede.
		$this->assertSame( 0, FakeHttp::count() );
	}

	// =========================================================================
	// google/list-accounts
	// =========================================================================

	public function test_list_accounts_junta_os_dois_conectores_e_usa_cache(): void {
		$this->enable_all();

		FakeHttp::push(
			'analyticsadmin.googleapis.com',
			200,
			array(
				'accountSummaries' => array(
					array(
						'name'              => 'accountSummaries/1',
						'account'           => 'accounts/1',
						'displayName'       => 'Fator3',
						'propertySummaries' => array(
							array(
								'property'     => 'properties/123456',
								'displayName'  => 'Site institucional',
								'propertyType' => 'PROPERTY_TYPE_ORDINARY',
								'parent'       => 'accounts/1',
							),
						),
					),
				),
			)
		);

		FakeHttp::push(
			'customers:listAccessibleCustomers',
			200,
			array( 'resourceNames' => array( 'customers/1234567890' ) )
		);

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'fieldMask' => 'customer.id,customer.descriptive_name,customer.currency_code,customer.time_zone,customer.manager,customer.status,customer.test_account',
				'results'   => array(
					array(
						'customer' => array(
							'id'              => '1234567890',
							'descriptiveName' => 'Fator3 Ads',
							'currencyCode'    => 'BRL',
							'timeZone'        => 'America/Sao_Paulo',
							'manager'         => false,
							'status'          => 'ENABLED',
							'testAccount'     => false,
						),
					),
				),
			)
		);

		$result = $this->execute( 'google/list-accounts', array() );

		$this->assertTrue( $result['success'], (string) ( $result['message'] ?? '' ) );
		$this->assertSame( 2, $result['count'] );
		$this->assertSame( array(), $result['warnings'] );

		$ga = $result['accounts'][0];
		$this->assertSame( 'ga4', $ga['connector'] );
		$this->assertSame( 'properties/123456', $ga['account_id'] );
		$this->assertSame( '123456', $ga['native_account_id'] );
		$this->assertSame( 'Site institucional', $ga['name'] );
		$this->assertSame( 'Fator3', $ga['parent'] );
		$this->assertSame( 'PROPERTY_TYPE_ORDINARY', $ga['property_type'] );

		$ads = $result['accounts'][1];
		$this->assertSame( 'google-ads', $ads['connector'] );
		$this->assertSame( '1234567890', $ads['account_id'] );
		$this->assertSame( 'Fator3 Ads', $ads['name'] );
		$this->assertSame( 'BRL', $ads['currency'] );
		$this->assertSame( 'America/Sao_Paulo', $ads['timezone'] );
		$this->assertFalse( $ads['is_manager'] );

		// Segunda chamada: nada de rede.
		$chamadas = FakeHttp::count();
		$segunda  = $this->execute( 'google/list-accounts', array() );

		$this->assertSame( $chamadas, FakeHttp::count(), 'a segunda chamada deveria vir do cache' );
		$this->assertSame( 2, $segunda['count'] );

		// E o filtro por texto usa o cache também.
		$filtrada = $this->execute( 'google/list-accounts', array( 'query' => 'institucional' ) );
		$this->assertSame( 1, $filtrada['count'] );
		$this->assertSame( 'properties/123456', $filtrada['accounts'][0]['account_id'] );

		// `refresh` volta a pedir.
		FakeHttp::push( 'analyticsadmin.googleapis.com', 200, array( 'accountSummaries' => array() ) );
		FakeHttp::push( 'customers:listAccessibleCustomers', 200, array( 'resourceNames' => array() ) );

		$recarregada = $this->execute(
			'google/list-accounts',
			array(
				'connector' => 'all',
				'refresh'   => true,
			)
		);

		$this->assertGreaterThan( $chamadas, FakeHttp::count() );
		$this->assertSame( 0, $recarregada['count'] );
	}

	public function test_list_accounts_com_ads_desligado_devolve_o_resto_e_um_aviso(): void {
		$this->enable_all();
		Options::set( Options::ADS_ENABLED, false );

		FakeHttp::push(
			'analyticsadmin.googleapis.com',
			200,
			array(
				'accountSummaries' => array(
					array(
						'displayName'       => 'Fator3',
						'propertySummaries' => array(
							array(
								'property'    => 'properties/999',
								'displayName' => 'Loja',
							),
						),
					),
				),
			)
		);

		$result = $this->execute( 'google/list-accounts', array( 'connector' => 'all' ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 1, $result['count'] );
		$this->assertCount( 1, $result['warnings'] );
		$this->assertStringContainsString( 'Google Ads', $result['warnings'][0] );
	}

	public function test_list_accounts_expande_gerenciadora(): void {
		$this->enable_all();
		Options::set( Options::GA_ENABLED, false );

		FakeHttp::push( 'customers:listAccessibleCustomers', 200, array( 'resourceNames' => array( 'customers/1111111111' ) ) );

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'fieldMask' => 'customer.id,customer.descriptive_name,customer.manager',
				'results'   => array(
					array(
						'customer' => array(
							'id'              => '1111111111',
							'descriptiveName' => 'MCC Fator3',
							'manager'         => true,
						),
					),
				),
			)
		);

		FakeHttp::push(
			'googleAds:search',
			200,
			array(
				'fieldMask' => 'customer_client.id,customer_client.descriptive_name,customer_client.currency_code',
				'results'   => array(
					array(
						'customerClient' => array(
							'id'              => '2222222222',
							'descriptiveName' => 'Cliente A',
							'currencyCode'    => 'BRL',
						),
					),
				),
			)
		);

		$result = $this->execute(
			'google/list-accounts',
			array(
				'connector'       => 'google-ads',
				'expand_managers' => true,
			)
		);

		$this->assertSame( 2, $result['count'] );
		$this->assertTrue( $result['accounts'][0]['is_manager'] );
		$this->assertSame( '2222222222', $result['accounts'][1]['account_id'] );
		$this->assertSame( 'Cliente A', $result['accounts'][1]['name'] );
		$this->assertSame( '1111111111', $result['accounts'][1]['parent'] );
	}

	public function test_nome_da_conta_entra_na_tabela_quando_ja_esta_em_cache(): void {
		$this->enable_all();

		set_transient(
			Query::ACCOUNTS_CACHE . 'ads_' . Credentials::identity_key(),
			array(
				array(
					'connector'         => 'google-ads',
					'account_id'        => '1234567890',
					'native_account_id' => '1234567890',
					'name'              => 'Fator3 Ads',
				),
				array(
					'connector'         => 'google-ads',
					'account_id'        => '9999999999',
					'native_account_id' => '9999999999',
					'name'              => 'Outra',
				),
			),
			600
		);

		$this->assertSame( 'Fator3 Ads', Query::account_name( 'ads', '1234567890' ) );
		$this->assertSame( '', Query::account_name( 'ads', '5555555555' ) );
		$this->assertSame( '', Query::account_name( 'ga', 'properties/1' ) );
	}

	// =========================================================================
	// google/list-fields
	// =========================================================================

	public function test_list_fields_ga_universal_e_com_propriedade(): void {
		$this->enable_all();

		FakeHttp::push(
			'properties/0/metadata',
			200,
			array(
				'dimensions' => array(
					array(
						'apiName'     => 'country',
						'uiName'      => 'Country',
						'description' => 'País',
					),
				),
				'metrics'    => array(
					array(
						'apiName' => 'sessions',
						'uiName'  => 'Sessions',
						'type'    => 'TYPE_INTEGER',
					),
				),
			)
		);

		$universal = $this->execute(
			'google/list-fields',
			array(
				'connector'  => 'ga4',
				'field_type' => 'metric',
			)
		);

		$this->assertTrue( $universal['success'], (string) ( $universal['message'] ?? '' ) );
		$this->assertSame( 'https://analyticsdata.googleapis.com/v1beta/properties/0/metadata', FakeHttp::last()['url'] );

		$ids = array_column( $universal['fields'], 'id' );
		$this->assertContains( 'sessions', $ids );
		$this->assertNotContains( 'country', $ids, 'field_type=metric não devolve dimensão' );

		foreach ( $universal['fields'] as $field ) {
			if ( 'sessions' === $field['id'] ) {
				$this->assertSame( 'integer', $field['kind'] );
				$this->assertFalse( $field['custom'] );
			}
		}

		// Com propriedade: entram as personalizadas.
		FakeHttp::push(
			'properties/123456/metadata',
			200,
			array(
				'dimensions' => array(
					array(
						'apiName'          => 'customEvent:plano',
						'uiName'           => 'Plano',
						'customDefinition' => true,
					),
				),
				'metrics'    => array(),
			)
		);

		$da_propriedade = $this->execute(
			'google/list-fields',
			array(
				'connector'  => 'ga4',
				'account_id' => 'properties/123456',
				'query'      => 'customEvent:plano',
			)
		);

		$this->assertSame( 'https://analyticsdata.googleapis.com/v1beta/properties/123456/metadata', FakeHttp::last()['url'] );
		$this->assertSame( 1, $da_propriedade['count'] );
		$this->assertTrue( $da_propriedade['fields'][0]['custom'] );
		$this->assertSame( 'customEvent:plano', $da_propriedade['exact_match']['id'] );
	}

	public function test_list_fields_ga_traz_os_apelidos_da_casa(): void {
		$this->enable_all();

		FakeHttp::push(
			'metadata',
			200,
			array(
				'dimensions' => array(),
				'metrics'    => array(
					array(
						'apiName' => 'activeUsers',
						'uiName'  => 'Active users',
						'type'    => 'TYPE_INTEGER',
					),
				),
			)
		);

		$result = $this->execute(
			'google/list-fields',
			array(
				'connector' => 'ga4',
				'query'     => 'users',
			)
		);

		$ids = array_column( $result['fields'], 'id' );
		$this->assertContains( 'users', $ids, 'o apelido users deveria ser descobrível' );
		$this->assertContains( 'activeUsers', $ids );
		$this->assertSame( 'users', $result['exact_match']['id'] );
		$this->assertSame( 'activeUsers', $result['exact_match']['native'] );
		$this->assertSame( 'metric', $result['exact_match']['type'] );
	}

	public function test_list_fields_ads_junta_catalogo_e_recurso(): void {
		$this->enable_all();

		$somente_catalogo = $this->execute(
			'google/list-fields',
			array(
				'connector' => 'google-ads',
				'query'     => 'cost',
			)
		);

		$this->assertSame( 0, FakeHttp::count(), 'o catálogo curado não custa rede' );
		$ids = array_column( $somente_catalogo['fields'], 'id' );
		$this->assertContains( 'cost', $ids );
		$this->assertContains( 'cost_per_conversion', $ids );
		$this->assertSame( 'metrics.cost_micros', $somente_catalogo['exact_match']['native'] );

		// Com recurso: os campos vivos entram.
		FakeHttp::push(
			'googleAdsFields:search',
			200,
			array(
				'results' => array(
					array(
						'name'       => 'campaign.serving_status',
						'selectable' => true,
						'filterable' => true,
						'sortable'   => true,
					),
				),
			)
		);
		FakeHttp::push( 'googleAdsFields:search', 200, array( 'results' => array() ) );

		$com_recurso = $this->execute(
			'google/list-fields',
			array(
				'connector' => 'google-ads',
				'resource'  => 'campaign',
				'query'     => 'serving_status',
			)
		);

		$this->assertTrue( $com_recurso['success'], (string) ( $com_recurso['message'] ?? '' ) );
		$this->assertSame( 1, $com_recurso['count'] );
		$this->assertSame( 'campaign.serving_status', $com_recurso['fields'][0]['id'] );
		$this->assertSame( 'dimension', $com_recurso['fields'][0]['type'] );
	}

	public function test_list_fields_exige_conector(): void {
		$this->enable_all();

		$result = $this->execute( 'google/list-fields', array( 'field_type' => 'metric' ) );

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_connector', $result['error_code'] );
	}

	// =========================================================================
	// google/status e google/selftest
	// =========================================================================

	public function test_status_nao_deixa_escapar_nenhum_segredo(): void {
		$this->enable_all();

		$result = $this->execute( 'google/status', array() );

		$this->assertTrue( $result['success'] );
		$this->assertTrue( $result['enabled'] );
		$this->assertTrue( $result['ga_enabled'] );
		$this->assertTrue( $result['ads_enabled'] );
		$this->assertTrue( $result['ads_developer_token_configured'] );
		$this->assertSame( '123-***-7890', $result['ads_login_customer_id'] );
		$this->assertSame( 'v25', $result['ads_api_version'] );
		$this->assertSame( self::SA_EMAIL, $result['auth']['identity'] );
		$this->assertSame( 26, $result['abilities_registered']['google'] );
		$this->assertSame( '0.4.0', $result['plugin_version'] );

		// Varredura: nenhum valor secreto configurado pode aparecer no JSON.
		$json = (string) wp_json_encode( $result );

		foreach ( Options::secret_names() as $name ) {
			$secret = Options::get_secret( $name );

			if ( '' === $secret ) {
				continue;
			}

			$this->assertStringNotContainsString( $secret, $json, 'segredo vazou: ' . $name );
		}

		$this->assertStringNotContainsString( self::DEV_TOKEN, $json );
		$this->assertStringNotContainsString( 'PRIVATE KEY', $json );
		$this->assertStringNotContainsString( 'tok-de-teste', $json );
		$this->assertStringNotContainsString( '1234567890', $json, 'o ID da gerenciadora deveria sair mascarado' );
	}

	public function test_status_live_diz_se_o_token_veio_sem_mostrar_o_token(): void {
		$this->enable_all();

		$result = $this->execute( 'google/status', array( 'live' => true ) );

		$this->assertSame(
			array(
				'ga'  => true,
				'ads' => true,
				'gsc' => true,
				'siteverification' => true,
				'sheets' => true,
				'drive' => true,
			),
			$result['token_ok']
		);
		$this->assertStringNotContainsString( 'tok-de-teste', (string) wp_json_encode( $result ) );
	}

	/**
	 * Sem credencial, `google/status` PRECISA rodar pela rota e dizer que ela
	 * falta (`auth.configured: false`) — é a rota de diagnóstico. O portão
	 * 'any' não exige credencial; quem exige é o portão do conector, chamado
	 * por dentro das rotas que de fato falam com a Google.
	 */
	public function test_sem_credencial_a_rota_explica_o_que_falta(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );

		$pela_rota = $this->execute( 'google/status', array() );

		$this->assertTrue( $pela_rota['success'] );
		$this->assertFalse( $pela_rota['auth']['configured'] );

		$consulta = $this->execute(
			'google/query',
			array(
				'connector'  => 'ga4',
				'accounts'   => array( '123' ),
				'metrics'    => array( 'sessions' ),
				'date_range' => 'last_7_days',
			)
		);

		$this->assertFalse( $consulta['success'] );
		$this->assertSame( 'f3_google_not_configured', $consulta['error_code'] );

		$direto = Abilities::status( array() );

		$this->assertTrue( $direto['success'] );
		$this->assertFalse( $direto['auth']['configured'] );
		$this->assertSame( 'service_account', $direto['auth']['mode'] );
		$this->assertFalse( $direto['ads_developer_token_configured'] );
		$this->assertSame( '', $direto['ads_login_customer_id'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_selftest_offline_passa_inteiro(): void {
		$this->enable_all();

		$result = $this->execute( 'google/selftest', array() );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 0, $result['failed'], (string) wp_json_encode( $result['checks'] ) );
		$this->assertGreaterThanOrEqual( 11, $result['passed'] );
		$this->assertSame( 0, FakeHttp::count(), 'o autoteste offline não pode sair para a rede' );

		$nomes = array_column( $result['checks'], 'name' );
		foreach ( array( 'date_presets', 'date_compare', 'catalog', 'filters_ga', 'filters_gaql', 'query_build' ) as $esperado ) {
			$this->assertContains( $esperado, $nomes );
		}
	}

	public function test_selftest_live_consulta_os_dois_conectores(): void {
		Options::set( \Fator3\McpGoogle\Connections::SERVICES, array( 'ga' => 'admin', 'ads' => 'write' ) );
		$this->enable_all();

		FakeHttp::push( 'analyticsadmin.googleapis.com', 200, array( 'accountSummaries' => array( array( 'propertySummaries' => array( array( 'property' => 'properties/1' ) ) ) ) ) );
		FakeHttp::push( 'customers:listAccessibleCustomers', 200, array( 'resourceNames' => array( 'customers/1234567890' ) ) );

		$result = $this->execute( 'google/selftest', array( 'live' => true ) );

		$checks = array_column( $result['checks'], 'ok', 'name' );

		$this->assertTrue( $checks['live_ga'], (string) wp_json_encode( $result['checks'] ) );
		$this->assertTrue( $checks['live_ads'] );
		$this->assertSame( 0, $result['failed'] );
		$this->assertStringNotContainsString( 'tok-de-teste', (string) wp_json_encode( $result ) );
	}

	public function test_selftest_live_pula_o_conector_quando_o_token_nao_vem(): void {
		$this->enable_all();
		$GLOBALS['f3_test_transients'] = array();

		// Sem token em cache e sem resposta enfileirada: a falha é do endpoint
		// de token, e quem reporta isso é a checagem `token`.
		$result = SelfTest::run( array( 'live' => true ) );
		$checks = array();

		foreach ( $result['checks'] as $check ) {
			$checks[ $check['name'] ] = $check;
		}

		$this->assertTrue( $result['execution_success'] );
		$this->assertFalse( $result['checks_passed'] );
		$this->assertSame( 'failed', $checks['live_ga']['status'] );
		$this->assertSame( 'failed', $checks['live_ads']['status'] );
	}

	public function test_selftest_direto_tem_o_mesmo_formato(): void {
		$this->enable_all();

		$result = SelfTest::run();

		$this->assertArrayHasKey( 'checks', $result );
		$this->assertSame( count( $result['checks'] ), $result['passed'] + $result['failed'] );
	}

	// =========================================================================
	// Registro das habilidades
	// =========================================================================

	/**
	 * @dataProvider rotas
	 */
	public function test_habilidade_registrada_com_os_padroes( string $name, array $required ): void {
		$ability = wp_get_ability( $name );

		$this->assertNotNull( $ability, 'rota ausente: ' . $name );

		$meta = $ability->get_meta();
		$this->assertTrue( $meta['mcp']['public'] );
		$this->assertSame( 'tool', $meta['mcp']['type'] );
		$this->assertTrue( $meta['annotations']['readonly'] );
		$this->assertFalse( $meta['annotations']['destructive'] );
		$this->assertSame( 'google', $ability->get_category() );

		$this->assertNotSame( '', $ability->get_label() );

		$description = $ability->get_description();
		$this->assertNotSame( '', $description );
		$this->assertLessThanOrEqual( 400, mb_strlen( $description ), $name . ': descrição longa demais' );

		$schema = $ability->get_input_schema();
		$this->assertSame( 'object', $schema['type'] );
		$this->assertFalse( $schema['additionalProperties'], $name . ': o esquema precisa ser fechado' );
		$this->assertSame( $required, $schema['required'] ?? array() );

		foreach ( $schema['required'] ?? array() as $property ) {
			$this->assertArrayHasKey( $property, $schema['properties'], $name . ': required fora de properties' );
		}

		// Toda propriedade documentada: é a descrição delas que carrega presets,
		// operadores e catálogo.
		foreach ( $schema['properties'] as $property => $definition ) {
			$this->assertNotEmpty( $definition['description'] ?? '', $name . '.' . $property . ' sem descrição' );
		}
	}

	/**
	 * @return array<string,array{0:string,1:array}>
	 */
	public static function rotas(): array {
		return array(
			'status'        => array( 'google/status', array() ),
			'selftest'      => array( 'google/selftest', array() ),
			'list-accounts' => array( 'google/list-accounts', array() ),
			'list-fields'   => array( 'google/list-fields', array( 'connector' ) ),
			// `accounts` não está em `required` de propósito: `account_id` é um
			// sinônimo aceito e o núcleo não sabe disso — quem cobra a presença
			// de um dos dois é Query::plan(). Ver
			// test_query_sem_conta_recusa_com_mensagem_util.
			'query'         => array( 'google/query', array( 'connector', 'metrics', 'date_range' ) ),
		);
	}

	public function test_as_cinco_rotas_respondem_ao_conector_any(): void {
		$this->enable_all();
		Options::set( Options::ADS_ENABLED, false );

		// Só o GA ligado: as rotas google/* continuam alcançáveis.
		foreach ( array_column( self::rotas(), 0 ) as $name ) {
			$this->assertTrue( wp_get_ability( $name )->check_permissions( array() ), $name );
		}

		// Canal fechado: nenhuma responde.
		Options::set( Options::ENABLED, false );

		foreach ( array_column( self::rotas(), 0 ) as $name ) {
			$this->assertFalse( wp_get_ability( $name )->check_permissions( array() ), $name );
		}
	}

	public function test_query_recusa_o_conector_desligado_com_o_portao_certo(): void {
		$this->enable_all();
		Options::set( Options::ADS_ENABLED, false );

		$result = $this->execute(
			'google/query',
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '1234567890' ),
				'metrics'    => array( 'clicks' ),
				'date_range' => 'today',
			)
		);

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_connector_off', $result['error_code'] );
		$this->assertSame( 0, FakeHttp::count() );
	}
}
