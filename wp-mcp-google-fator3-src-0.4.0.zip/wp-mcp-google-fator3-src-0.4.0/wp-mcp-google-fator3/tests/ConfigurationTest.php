<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Admin, Configuration, Connections, Options, Plugin, Setup};
use PHPUnit\Framework\TestCase;

/** Read-only direct storage adapter: filters never prove persisted state. */
final class ConfigurationReadDb extends \F3_Test_Wpdb {
    public string $last_error = '';
    public string $fail = '';
    public int $reads = 0;
    public function get_row( $sql, $format ) {
        ++$this->reads; $this->last_error = '';
        preg_match( "/option_name = '([^']+)'/", $sql, $match ); $name = stripslashes( $match[1] );
        if ( $name === $this->fail ) { $this->last_error = 'test database unavailable'; return null; }
        return array_key_exists( $name, $GLOBALS['f3_test_options'] ) ? array( 'option_value' => maybe_serialize( $GLOBALS['f3_test_options'][ $name ] ) ) : null;
    }
}

final class ConfigurationTest extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = $GLOBALS['f3_test_user_caps'] = array();
        $GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_user'] = 1;
        $_POST = $_GET = array(); FakeHttp::reset(); Plugin::register_abilities(); Options::set( Options::ENABLED, true );
    }
    protected function tearDown(): void { $GLOBALS['f3_test_write_fail'] = array(); $_POST = $_GET = array(); FakeHttp::reset(); }

    public function test_first_false_creates_row_and_repeat_is_successful_without_change(): void {
        $this->assertFalse( update_option( Options::GA_ENABLED, false ) );
        $this->assertArrayNotHasKey( Options::GA_ENABLED, $GLOBALS['f3_test_options'] );
        $first = Options::set( Options::GA_ENABLED, false ); $repeat = Options::set( Options::GA_ENABLED, false );
        $this->assertTrue( $first['success'] ); $this->assertTrue( $first['persisted'] ); $this->assertTrue( $first['changed'] );
        $this->assertArrayHasKey( Options::GA_ENABLED, $GLOBALS['f3_test_options'] );
        $this->assertTrue( $repeat['success'] ); $this->assertTrue( $repeat['persisted'] ); $this->assertFalse( $repeat['changed'] );
        $this->assertNull( $repeat['error_code'] );
    }
    public function test_refused_first_false_remains_absent_and_reports_persistence_failure(): void {
        $GLOBALS['f3_test_write_fail'][ Options::ADS_ENABLED ] = true;
        $r = Options::set( Options::ADS_ENABLED, false );
        $this->assertFalse( $r['success'] ); $this->assertFalse( $r['persisted'] ); $this->assertFalse( $r['changed'] );
        $this->assertSame( 'f3_google_option_persistence', $r['error_code'] );
        $this->assertFalse( Options::stored( Options::ADS_ENABLED )['exists'] );
    }
    public function test_first_false_in_batch_and_new_connection(): void {
        $this->assertTrue( Connections::create( 'second', 'Second' )['success'] );
        $r = Connections::run( 'second', static fn() => Options::batch_verified( array( Options::GA_ENABLED => false, Options::ADS_ENABLED => false ) ) );
        $this->assertTrue( $r['success'] ); $this->assertTrue( $r['persisted'] );
        $this->assertArrayHasKey( 'f3_mcp_google_conn_second_ga_enabled', $GLOBALS['f3_test_options'] );
        $this->assertArrayNotHasKey( Options::GA_ENABLED, $GLOBALS['f3_test_options'] );
    }
    public function test_panel_confirms_first_false_and_repeat(): void {
        $_POST = array( 'enable' => '0' );
        foreach ( array( 1, 2 ) as $attempt ) {
            try { Admin::handle_toggle_ga(); $this->fail( 'redirect expected' ); }
            catch ( \F3_Test_Redirect $e ) { $this->assertMatchesRegularExpression( '/f3_status=(saved|unchanged)/', $e->location ); $this->assertStringNotContainsString( 'save_failed', $e->location ); }
        }
        $this->assertTrue( Options::stored( Options::GA_ENABLED )['exists'] ); $this->assertFalse( Options::ga_enabled() );
    }
    public function test_contract_exposes_defaults_limits_operations_without_google_calls(): void {
        $r = wp_get_ability( 'google/configuration-schema' )->execute( array() );
        $this->assertTrue( $r['success'] ); $this->assertSame( '1.1.0', $r['contract_version'] );
        $this->assertTrue( $r['values_complete'] ); $this->assertFalse( $r['google_checks_performed'] );
        $this->assertSame( array(), FakeHttp::$requests );
        $this->assertSame( 'wp-mcp-google-fator3', $r['plugin']['id'] );
        $this->assertSame( 22, count( $r['options'] ) );
        $this->assertSame( Options::LIMITS[ Options::MAX_ROWS ], $r['options']['max_rows']['schema'] );
        $this->assertSame( 1000, $r['options']['max_rows']['state']['effective_value'] );
        $this->assertFalse( $r['options']['ga_enabled']['state']['exists'] );
        $this->assertFalse( $r['options']['ga_enabled']['state']['effective_value'] );
        $this->assertTrue( $r['options']['ga_enabled']['activation_default'] );
        $this->assertFalse( $r['options']['enabled']['mcp_mutable'] );
        $this->assertSame( 'not_checked', $r['runtime_prerequisites']['google_access']['status'] );
        $this->assertSame( 'panel:oauth-start', $r['runtime_prerequisites']['credentials']['modes']['oauth']['consent_operation'] );
        foreach ( $r['options'] as $definition ) {
            foreach ( $definition['allowed_operations'] as $operation ) { $this->assertArrayHasKey( $operation, $r['operations'] ); }
        }
        $this->assertSame( wp_get_ability( 'google/configure' )->get_input_schema(), $r['operations']['google/configure']['input_schema'] );
        $schema = $r['operations']['google/configure']['input_schema']['properties']['bindings'];
        unset( $schema['description'] );
        $this->assertSame( Setup::bindings_schema(), $schema );
    }
    public function test_contract_distinguishes_absent_from_persisted_false(): void {
        $before = Configuration::read(); Options::set( Options::GA_ENABLED, false ); $after = Configuration::read();
        $this->assertTrue( $before['options']['ga_enabled']['state']['using_default'] );
        $this->assertFalse( $after['options']['ga_enabled']['state']['using_default'] );
        $this->assertTrue( $after['options']['ga_enabled']['state']['exists'] );
        $this->assertFalse( $after['options']['ga_enabled']['state']['effective_value'] );
        $this->assertSame( $before['definition_sha256'], $after['definition_sha256'] );
    }
    public function test_effective_filters_and_clamps_are_distinct_from_persisted_value(): void {
        Options::set( Options::HTTP_TIMEOUT, 20 ); $GLOBALS['wpdb'] = new ConfigurationReadDb();
        $filter = static fn() => 999; add_filter( 'f3_mcp_google_http_timeout', $filter );
        try { $r = Configuration::read(); } finally { remove_filter( 'f3_mcp_google_http_timeout', $filter ); }
        $this->assertSame( 20, $r['options']['http_timeout']['state']['persisted_value'] );
        $this->assertSame( 120, $r['options']['http_timeout']['state']['effective_value'] );
        $this->assertSame( 120, $r['options']['http_timeout']['schema']['maximum'] );
    }
    public function test_all_secrets_are_redacted_including_cipher_and_hash(): void {
        foreach ( Options::secret_names() as $name ) { Options::set_secret( $name, 'secret-' . $name ); }
        $r = Configuration::read(); $json = json_encode( $r );
        foreach ( Options::secret_names() as $name ) {
            $state = $r['options'][ substr( $name, strlen( 'f3_mcp_google_' ) ) ]['state'];
            $this->assertTrue( $state['configured'] ); $this->assertTrue( $state['readable'] ); $this->assertTrue( $state['redacted'] );
            $this->assertArrayNotHasKey( 'persisted_value', $state ); $this->assertArrayNotHasKey( 'effective_value', $state );
            $this->assertStringNotContainsString( 'secret-' . $name, $json );
            $this->assertStringNotContainsString( $GLOBALS['f3_test_options'][ $name ], $json );
            $this->assertStringNotContainsString( hash( 'sha256', 'secret-' . $name ), $json );
        }
    }
    public function test_corrupt_secret_returns_machine_readable_partial_failure(): void {
        $GLOBALS['f3_test_options'][ Options::OAUTH_CLIENT_SECRET ] = 'broken-cipher-private';
        $r = Configuration::read();
        $this->assertFalse( $r['success'] ); $this->assertFalse( $r['values_complete'] );
        $this->assertSame( 'f3_google_configuration_read', $r['error_code'] );
        $this->assertTrue( $r['options']['oauth_client_secret']['state']['exists'] );
        $this->assertFalse( $r['options']['oauth_client_secret']['state']['readable'] );
        $this->assertSame( 'f3_google_crypto_decrypt', $r['options']['oauth_client_secret']['state']['error_code'] );
        $this->assertStringNotContainsString( 'broken-cipher-private', json_encode( $r ) );
    }
    public function test_storage_read_failure_is_not_reported_as_absence(): void {
        $db = new ConfigurationReadDb(); $db->fail = Options::GA_ENABLED; $GLOBALS['wpdb'] = $db;
        $r = Configuration::read();
        $this->assertFalse( $r['success'] ); $this->assertNull( $r['options']['ga_enabled']['state']['exists'] );
        $this->assertSame( 'f3_google_option_read', $r['options']['ga_enabled']['state']['error_code'] );
        $this->assertArrayNotHasKey( 'persisted_value', $r['options']['ga_enabled']['state'] );
    }
    public function test_definitions_only_skip_value_reads_and_keep_same_hash(): void {
        $first = Configuration::read(); $db = new ConfigurationReadDb(); $db->fail = Options::GA_ENABLED; $GLOBALS['wpdb'] = $db;
        $r = Configuration::read( array( 'include_values' => false ) );
        $this->assertTrue( $r['success'] ); $this->assertNull( $r['values_complete'] );
        $this->assertFalse( $r['values_included'] ); $this->assertSame( 0, $db->reads );
        $this->assertSame( $first['definition_sha256'], $r['definition_sha256'] );
        foreach ( $r['options'] as $definition ) { $this->assertArrayNotHasKey( 'state', $definition ); }
    }
    public function test_connection_context_is_isolated_and_restored(): void {
        Connections::create( 'second', 'Second' );
        Options::set( Options::OAUTH_CLIENT_ID, 'default-client' );
        Connections::run( 'second', static fn() => Options::set( Options::OAUTH_CLIENT_ID, 'second-client' ) );
        $r = wp_get_ability( 'google/configuration-schema' )->execute( array( 'connection_id' => 'second' ) );
        $this->assertSame( 'second', $r['connection_id'] );
        $this->assertSame( 'second-client', $r['options']['oauth_client_id']['state']['effective_value'] );
        $this->assertSame( 'connection', $r['options']['oauth_client_id']['scope'] );
        $this->assertSame( 'site', $r['options']['http_timeout']['scope'] );
        $this->assertSame( 'default', Connections::id() );
        $this->assertStringNotContainsString( 'default-client', json_encode( $r ) );
    }
    public function test_unsupported_version_has_explicit_error(): void {
        $r = wp_get_ability( 'google/configuration-schema' )->execute( array( 'contract_version' => '2.0.0' ) );
        $this->assertFalse( $r['success'] ); $this->assertSame( 'f3_google_contract_version', $r['error_code'] );
        $this->assertSame( array( '1.0.0', '1.1.0' ), $r['supported_contract_versions'] );
        $this->assertArrayNotHasKey( 'options', $r );
    }
    public function test_existing_gate_blocks_unauthorized_and_disabled_reads(): void {
        $ability = wp_get_ability( 'google/configuration-schema' );
        $GLOBALS['f3_test_caps'] = false;
        $this->assertFalse( $ability->check_permissions() ); $this->assertSame( 'f3_google_forbidden', $ability->execute()['error_code'] );
        $GLOBALS['f3_test_caps'] = true; Options::set( Options::ENABLED, false );
        $this->assertFalse( $ability->check_permissions() ); $this->assertSame( 'f3_google_disabled', Configuration::read()['error_code'] );
    }
    public function test_catalog_is_read_only_and_does_not_mutate_configuration(): void {
        $before = $GLOBALS['f3_test_options']; Configuration::read();
        $this->assertSame( $before, $GLOBALS['f3_test_options'] );
        $this->assertTrue( wp_get_ability( 'google/configuration-schema' )->get_meta()['annotations']['readonly'] );
        $this->assertFalse( wp_get_ability( 'google/configuration-schema' )->get_meta()['annotations']['destructive'] );
    }
    public function test_shared_setup_rules_validate_valid_empty_and_invalid_bindings(): void {
        foreach ( array( '123', 'properties/123', '' ) as $value ) { $this->assertTrue( Setup::plan( array( 'bindings' => array( 'ga_property_id' => $value ) ) )['success'] ); }
        $this->assertFalse( Setup::plan( array( 'bindings' => array( 'ga_property_id' => 'bogus' ) ) )['success'] );
        $this->assertFalse( Setup::plan( array( 'bindings' => array( 'unknown' => '123' ) ) )['success'] );
        $this->assertFalse( Setup::plan( array( 'services' => array( 'gsc' => 'admin' ) ) )['success'] );
        $this->assertTrue( Setup::plan( array( 'services' => array( 'gsc' => 'read' ) ) )['success'] );
    }
}
