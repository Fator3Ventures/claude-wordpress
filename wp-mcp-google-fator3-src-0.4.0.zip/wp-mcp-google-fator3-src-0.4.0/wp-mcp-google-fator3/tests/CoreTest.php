<?php
/**
 * Testes do núcleo: cifra, opções, credenciais, cliente HTTP, portão,
 * registrador de habilidades, resposta, auditoria e fluxo OAuth.
 *
 * O que se procura aqui é o que quebra em silêncio em produção: segredo
 * vazando por `get_option`, token pedido duas vezes, erro do Google virando
 * mensagem inútil, host fora da lista sendo alcançado, exceção derrubando a
 * sessão MCP inteira.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Auth\OAuthFlow;
use Fator3\McpGoogle\Auth\OAuthUser;
use Fator3\McpGoogle\Auth\ServiceAccount;
use Fator3\McpGoogle\Crypto;
use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;
use Fator3\McpGoogle\SelfTest;
use PHPUnit\Framework\TestCase;

final class CoreTest extends TestCase {

	private const SA_EMAIL = 'robo@projeto-teste.iam.gserviceaccount.com';

	/** @var array{private:string,public:string}|null Par de chaves gerado uma vez. */
	private static ?array $keys = null;

	protected function setUp(): void {
		// Só o estado: os hooks ficam, senão a trava dos segredos registrada
		// no carregamento do plugin sumiria.
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;
		$GLOBALS['f3_test_redirects']  = array();

		FakeHttp::reset();
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	private static function keys(): array {
		if ( null === self::$keys ) {
			$pair = openssl_pkey_new(
				array(
					'private_key_bits' => 2048,
					'private_key_type' => OPENSSL_KEYTYPE_RSA,
				)
			);

			$private = '';
			openssl_pkey_export( $pair, $private );
			$details = openssl_pkey_get_details( $pair );

			self::$keys = array(
				'private' => $private,
				'public'  => (string) $details['key'],
			);
		}

		return self::$keys;
	}

	private static function sa_key_array(): array {
		return array(
			'type'         => 'service_account',
			'project_id'   => 'projeto-teste',
			'private_key'  => self::keys()['private'],
			'client_email' => self::SA_EMAIL,
			'token_uri'    => 'https://oauth2.googleapis.com/token',
		);
	}

	private function enable_all(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'dev-token-1234' );
		Options::set_secret( Options::SA_JSON, (string) wp_json_encode( self::sa_key_array() ) );
	}

	/**
	 * JWT de mentira, só com o payload — é assim que o id_token chega.
	 */
	private static function fake_id_token( array $claims ): string {
		$part = static function ( array $data ): string {
			return rtrim( strtr( base64_encode( (string) wp_json_encode( $data ) ), '+/', '-_' ), '=' );
		};

		return $part( array( 'alg' => 'RS256' ) ) . '.' . $part( $claims ) . '.assinatura';
	}

	// =========================================================================
	// Crypto e Options
	// =========================================================================

	public function test_crypto_faz_o_ciclo_nos_dois_backends(): void {
		$sample = 'chave-privada-de-mentira-1234567890';

		foreach ( array( 'sodium', 'openssl' ) as $backend ) {
			$force = static function () use ( $backend ): string {
				return $backend;
			};

			add_filter( 'f3_mcp_google_crypto_backend', $force );

			$this->assertSame( $backend, Crypto::backend(), 'backend forçado deveria valer' );

			$cipher = Crypto::encrypt( $sample );

			$this->assertStringStartsWith( 'v1:' . $backend . ':', $cipher );
			$this->assertStringNotContainsString( $sample, $cipher );
			$this->assertSame( $sample, Crypto::decrypt( $cipher ) );

			remove_filter( 'f3_mcp_google_crypto_backend', $force );
		}
	}

	public function test_cifra_de_um_backend_e_lida_pelo_prefixo(): void {
		$forca_sodium = static function (): string {
			return 'sodium';
		};

		add_filter( 'f3_mcp_google_crypto_backend', $forca_sodium );
		$cipher = Crypto::encrypt( 'valor' );
		remove_filter( 'f3_mcp_google_crypto_backend', $forca_sodium );

		$forca_openssl = static function (): string {
			return 'openssl';
		};

		add_filter( 'f3_mcp_google_crypto_backend', $forca_openssl );
		$plain = Crypto::decrypt( $cipher );
		remove_filter( 'f3_mcp_google_crypto_backend', $forca_openssl );

		$this->assertSame( 'valor', $plain );
	}

	public function test_decrypt_recusa_texto_corrompido(): void {
		$this->assertTrue( is_wp_error( Crypto::decrypt( 'lixo' ) ) );
		$this->assertTrue( is_wp_error( Crypto::decrypt( 'v1:sodium:AAAA:BBBB' ) ) );
	}

	public function test_segredo_e_ilegivel_por_get_option_e_legivel_pelo_plugin(): void {
		$secret = 'refresh-token-secretissimo';

		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, $secret );

		// É o que um options/get ou um db/query enxergaria.
		$this->assertSame( '', get_option( Options::OAUTH_REFRESH_TOKEN, 'padrao' ) );

		$raw = $GLOBALS['f3_test_options'][ Options::OAUTH_REFRESH_TOKEN ];
		$this->assertStringStartsWith( 'v1:', $raw );
		$this->assertStringNotContainsString( $secret, $raw );

		$this->assertSame( $secret, Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
		$this->assertTrue( Options::has_secret( Options::OAUTH_REFRESH_TOKEN ) );

		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, '' );
		$this->assertSame( '', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
		$this->assertFalse( Options::has_secret( Options::OAUTH_REFRESH_TOKEN ) );
	}

	public function test_limites_das_opcoes(): void {
		Options::set( Options::MAX_ROWS, 999999 );
		$this->assertSame( 10000, Options::max_rows() );

		Options::set( Options::HTTP_TIMEOUT, 1 );
		$this->assertSame( 5, Options::http_timeout() );

		Options::set( Options::ADS_API_VERSION, 'nada-disso' );
		$this->assertSame( 'v25', Options::ads_api_version() );

		Options::set( Options::ADS_LOGIN_CUSTOMER_ID, '123-456-7890' );
		$this->assertSame( '1234567890', Options::ads_login_customer_id() );
	}

	// =========================================================================
	// Service account
	// =========================================================================

	public function test_build_jwt_assina_e_traz_as_claims_certas(): void {
		$now = 1780000000;
		$jwt = ServiceAccount::build_jwt(
			self::sa_key_array(),
			array( Credentials::SCOPE_GA, Credentials::SCOPE_ADS ),
			$now
		);

		$parts = explode( '.', $jwt );
		$this->assertCount( 3, $parts );

		$header    = json_decode( (string) base64_decode( strtr( $parts[0], '-_', '+/' ) ), true );
		$claims    = json_decode( (string) base64_decode( strtr( $parts[1], '-_', '+/' ) ), true );
		$signature = (string) base64_decode( strtr( $parts[2], '-_', '+/' ) );

		$this->assertSame( 'RS256', $header['alg'] );
		$this->assertSame( 'JWT', $header['typ'] );

		$this->assertSame( self::SA_EMAIL, $claims['iss'] );
		$this->assertSame( Credentials::SCOPE_GA . ' ' . Credentials::SCOPE_ADS, $claims['scope'] );
		$this->assertSame( 'https://oauth2.googleapis.com/token', $claims['aud'] );
		$this->assertSame( $now, $claims['iat'] );
		$this->assertSame( $now + 3600, $claims['exp'] );
		$this->assertArrayNotHasKey( 'sub', $claims, 'sem delegação de domínio não pode haver sub' );

		$this->assertSame(
			1,
			openssl_verify( $parts[0] . '.' . $parts[1], $signature, self::keys()['public'], OPENSSL_ALGO_SHA256 )
		);
	}

	public function test_build_jwt_inclui_sub_quando_ha_impersonacao(): void {
		$jwt    = ServiceAccount::build_jwt( self::sa_key_array(), array( Credentials::SCOPE_GA ), time(), 'chefe@exemplo.com' );
		$claims = json_decode( (string) base64_decode( strtr( explode( '.', $jwt )[1], '-_', '+/' ) ), true );

		$this->assertSame( 'chefe@exemplo.com', $claims['sub'] );
	}

	public function test_validate_key_recusa_json_que_nao_e_service_account(): void {
		$this->assertTrue( is_wp_error( ServiceAccount::validate_key( 'nem json' ) ) );
		$this->assertTrue( is_wp_error( ServiceAccount::validate_key( '{"type":"authorized_user"}' ) ) );

		$sem_token_uri = self::sa_key_array();
		unset( $sem_token_uri['token_uri'] );
		$this->assertTrue( is_wp_error( ServiceAccount::validate_key( (string) wp_json_encode( $sem_token_uri ) ) ) );

		$token_uri_de_terceiro              = self::sa_key_array();
		$token_uri_de_terceiro['token_uri'] = 'https://token.exemplo.mal/token';
		$this->assertTrue( is_wp_error( ServiceAccount::validate_key( (string) wp_json_encode( $token_uri_de_terceiro ) ) ) );

		$this->assertIsArray( ServiceAccount::validate_key( (string) wp_json_encode( self::sa_key_array() ) ) );
	}

	public function test_access_token_vai_por_formulario_e_fica_em_cache(): void {
		$this->enable_all();

		FakeHttp::push(
			'oauth2.googleapis.com/token',
			200,
			array(
				'access_token' => 'tok-abc',
				'expires_in'   => 3600,
				'token_type'   => 'Bearer',
			)
		);

		$credentials = ServiceAccount::from_options();
		$this->assertInstanceOf( ServiceAccount::class, $credentials );

		$token = $credentials->get_access_token( array( Credentials::SCOPE_GA ) );
		$this->assertSame( 'tok-abc', $token );

		$request = FakeHttp::last();
		$this->assertSame( 'POST', $request['method'] );
		$this->assertSame( 'https://oauth2.googleapis.com/token', $request['url'] );
		$this->assertSame( 'application/x-www-form-urlencoded', $request['headers']['Content-Type'] );
		$this->assertIsArray( $request['body'] );
		$this->assertSame( 'urn:ietf:params:oauth:grant-type:jwt-bearer', $request['body']['grant_type'] );
		$this->assertArrayHasKey( 'assertion', $request['body'] );
		$this->assertArrayNotHasKey( 'Authorization', $request['headers'] );

		// Cache: a segunda chamada não pode tocar a rede.
		$chamadas = FakeHttp::count();
		$this->assertSame( 'tok-abc', $credentials->get_access_token( array( Credentials::SCOPE_GA ) ) );
		$this->assertSame( $chamadas, FakeHttp::count() );

		$this->assertSame(
			'tok-abc',
			Credentials::cached( Credentials::cache_key( array( Credentials::SCOPE_GA ), self::SA_EMAIL ) )
		);
	}

	public function test_erro_do_endpoint_de_token_vira_mensagem_explicada(): void {
		$this->enable_all();

		FakeHttp::push(
			'oauth2.googleapis.com/token',
			400,
			array(
				'error'             => 'invalid_grant',
				'error_description' => 'Invalid JWT Signature.',
			)
		);

		$credentials = ServiceAccount::from_options();
		$error       = $credentials->get_access_token( array( Credentials::SCOPE_GA ) );

		$this->assertTrue( is_wp_error( $error ) );
		$this->assertSame( 'f3_google_sa_grant', $error->get_error_code() );
	}

	// =========================================================================
	// OAuth de usuário
	// =========================================================================

	private function configure_oauth(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'oauth' );
		Options::set( Options::OAUTH_CLIENT_ID, 'cliente.apps.googleusercontent.com' );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'segredo-do-cliente' );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'refresh-1' );
		Options::set( Options::OAUTH_EMAIL, 'pessoa@exemplo.com' );
	}

	public function test_oauth_renova_token_com_refresh_token(): void {
		$this->configure_oauth();

		FakeHttp::push(
			'oauth2.googleapis.com/token',
			200,
			array(
				'access_token' => 'tok-oauth',
				'expires_in'   => 3599,
			)
		);

		$credentials = OAuthUser::from_options();
		$this->assertInstanceOf( OAuthUser::class, $credentials );

		$this->assertSame( 'tok-oauth', $credentials->get_access_token( array( Credentials::SCOPE_GA ) ) );

		$body = FakeHttp::last()['body'];
		$this->assertSame( 'refresh_token', $body['grant_type'] );
		$this->assertSame( 'refresh-1', $body['refresh_token'] );
		$this->assertSame( 'cliente.apps.googleusercontent.com', $body['client_id'] );
	}

	public function test_oauth_invalid_grant_apaga_o_refresh_token(): void {
		$this->configure_oauth();

		FakeHttp::push(
			'oauth2.googleapis.com/token',
			400,
			array(
				'error'             => 'invalid_grant',
				'error_description' => 'Token has been expired or revoked.',
			)
		);

		$credentials = OAuthUser::from_options();
		$error       = $credentials->get_access_token( array( Credentials::SCOPE_GA ) );

		$this->assertTrue( is_wp_error( $error ) );
		$this->assertSame( 'f3_google_oauth_revoked', $error->get_error_code() );
		$this->assertSame( '', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
		$this->assertSame( '', (string) Options::get( Options::OAUTH_EMAIL, '' ) );
		$this->assertTrue( is_wp_error( OAuthUser::from_options() ) );
	}

	// =========================================================================
	// GoogleClient
	// =========================================================================

	public function test_resposta_2xx_vira_array(): void {
		FakeHttp::push( 'analyticsdata', 200, array( 'dimensionHeaders' => array(), 'rowCount' => 3 ) );

		$response = GoogleClient::get(
			GoogleClient::HOST_GA_DATA . '/v1beta/properties/1/metadata',
			array(),
			array( 'auth' => false )
		);

		$this->assertIsArray( $response );
		$this->assertSame( 3, $response['rowCount'] );
		$this->assertSame( 'GET', FakeHttp::last()['method'] );
		$this->assertSame( 'application/json', FakeHttp::last()['headers']['Accept'] );
	}

	public function test_403_vira_wp_error_com_status_e_reason(): void {
		FakeHttp::push(
			'analyticsadmin',
			403,
			array(
				'error' => array(
					'code'    => 403,
					'message' => 'User does not have sufficient permissions for this property.',
					'status'  => 'PERMISSION_DENIED',
				),
			)
		);

		$error = GoogleClient::get(
			GoogleClient::HOST_GA_ADMIN . '/v1beta/properties/123',
			array(),
			array( 'auth' => false )
		);

		$this->assertTrue( is_wp_error( $error ) );
		$this->assertSame( 'f3_google_http', $error->get_error_code() );

		$data = $error->get_error_data();
		$this->assertSame( 403, $data['status'] );
		$this->assertSame( 'PERMISSION_DENIED', $data['reason'] );
		$this->assertStringContainsString( 'sufficient permissions', $data['message'] );

		// A URL guardada não pode carregar query.
		$this->assertSame( GoogleClient::HOST_GA_ADMIN . '/v1beta/properties/123', $data['url'] );

		$fail = Response::fail( $error );
		$this->assertFalse( $fail['success'] );
		$this->assertSame( 'f3_google_http', $fail['error_code'] );
		$this->assertSame( 403, $fail['details']['status'] );
		$this->assertSame( 'PERMISSION_DENIED', $fail['details']['reason'] );
	}

	/**
	 * Bug encontrado na fase 3: `sanitize_details()` só tira campos com nome
	 * de credencial (`authorization`, `access_token`...), mas o texto livre de
	 * `error.message` ia para a resposta sem passar por nenhuma filtragem. A
	 * Google nunca ecoa o Authorization de volta, mas um proxy ou uma API mal
	 * comportada que devolvesse a própria requisição no corpo do erro faria o
	 * access token vazar pela mensagem — corrigido em
	 * `GoogleClient::error_from()`/`redact_token()`.
	 */
	public function test_access_token_ecoado_no_corpo_do_erro_nao_vaza(): void {
		$this->enable_all();

		$token = 'tok-vazamento-teste-12345678';
		Credentials::remember(
			Credentials::cache_key( array( Credentials::SCOPE_GA ), self::SA_EMAIL ),
			$token,
			3600
		);

		FakeHttp::push(
			'analyticsadmin',
			403,
			array(
				'error' => array(
					'code'    => 403,
					'message' => 'Request rejected. Received headers: Authorization: Bearer ' . $token,
					'status'  => 'PERMISSION_DENIED',
					'details' => array(
						array(
							'@type'  => 'debug',
							'errors' => array(
								array( 'message' => 'echo: Authorization=Bearer ' . $token ),
							),
						),
					),
				),
			)
		);

		$error = GoogleClient::get(
			GoogleClient::HOST_GA_ADMIN . '/v1beta/properties/123',
			array(),
			array( 'scopes' => array( Credentials::SCOPE_GA ) )
		);

		$this->assertTrue( is_wp_error( $error ) );

		$json = (string) wp_json_encode(
			array(
				'message' => $error->get_error_message(),
				'data'    => $error->get_error_data(),
			)
		);

		$this->assertStringNotContainsString( $token, $json );
		$this->assertStringContainsString( '[token redigido]', $json );

		$fail = Response::fail( $error );
		$this->assertStringNotContainsString( $token, (string) wp_json_encode( $fail ) );
	}

	public function test_429_e_retentado_e_depois_sucede(): void {
		FakeHttp::push( 'googleads', 429, array( 'error' => array( 'code' => 429, 'message' => 'Too many requests', 'status' => 'RESOURCE_EXHAUSTED' ) ) );
		FakeHttp::push( 'googleads', 200, array( 'results' => array( array( 'campaign' => array( 'id' => '1' ) ) ) ) );

		$response = GoogleClient::post(
			GoogleClient::HOST_ADS . '/v25/customers/1234567890/googleAds:search',
			array( 'query' => 'SELECT campaign.id FROM campaign' ),
			array( 'auth' => false )
		);

		$this->assertIsArray( $response );
		$this->assertCount( 1, $response['results'] );
		$this->assertSame( 2, FakeHttp::count(), 'deveria ter tentado duas vezes' );
	}

	public function test_erro_do_google_ads_vira_mensagem_legivel(): void {
		FakeHttp::push(
			'googleads',
			400,
			array(
				'error' => array(
					'code'    => 400,
					'message' => 'Request contains an invalid argument.',
					'status'  => 'INVALID_ARGUMENT',
					'details' => array(
						array(
							'@type'     => 'type.googleapis.com/google.ads.googleads.v25.errors.GoogleAdsFailure',
							'errors'    => array(
								array(
									'errorCode' => array( 'queryError' => 'BAD_FIELD_NAME' ),
									'message'   => "Error in query: unexpected field 'campaign.nome'.",
								),
							),
							'requestId' => 'AbC-123',
						),
					),
				),
			)
		);

		$error = GoogleClient::post(
			GoogleClient::HOST_ADS . '/v25/customers/1234567890/googleAds:search',
			array( 'query' => 'SELECT campaign.nome FROM campaign' ),
			array(
				'auth'    => false,
				'retries' => 0,
			)
		);

		$this->assertTrue( is_wp_error( $error ) );
		$this->assertStringContainsString( "unexpected field 'campaign.nome'", $error->get_error_message() );
		$this->assertStringContainsString( 'AbC-123', $error->get_error_message() );
		$this->assertSame( 'queryError:BAD_FIELD_NAME', $error->get_error_data()['reason'] );
	}

	public function test_host_fora_da_lista_e_recusado_sem_http(): void {
		$antes = FakeHttp::count();

		foreach (
			array(
				'https://evil.example/v1beta/properties/1',
				'http://analyticsdata.googleapis.com/v1beta',
				'https://analyticsdata.googleapis.com.evil.example/v1beta',
				'https://googleads.googleapis.com:8443/v25',
			) as $url
		) {
			$error = GoogleClient::get( $url, array(), array( 'auth' => false ) );

			$this->assertTrue( is_wp_error( $error ), $url );
			$this->assertSame( 'f3_google_host', $error->get_error_code(), $url );
		}

		$this->assertSame( $antes, FakeHttp::count(), 'nenhuma requisição pode ter saído' );
		$this->assertTrue( GoogleClient::assert_allowed_host( GoogleClient::HOST_GA_DATA . '/v1beta' ) );
	}

	public function test_get_all_pages_junta_as_paginas(): void {
		FakeHttp::push(
			'accountSummaries',
			200,
			array(
				'accountSummaries' => array( array( 'account' => 'accounts/1' ), array( 'account' => 'accounts/2' ) ),
				'nextPageToken'    => 'pagina-2',
			)
		);
		FakeHttp::push(
			'accountSummaries',
			200,
			array( 'accountSummaries' => array( array( 'account' => 'accounts/3' ) ) )
		);

		$items = GoogleClient::get_all_pages(
			GoogleClient::HOST_GA_ADMIN . '/v1beta/accountSummaries',
			array( 'pageSize' => 200 ),
			'accountSummaries',
			array( 'auth' => false )
		);

		$this->assertIsArray( $items );
		$this->assertCount( 3, $items );
		$this->assertSame( 'accounts/3', $items[2]['account'] );
		$this->assertStringContainsString( 'pageToken=pagina-2', FakeHttp::last()['url'] );
	}

	public function test_get_all_pages_respeita_o_teto(): void {
		FakeHttp::push(
			'accountSummaries',
			200,
			array(
				'accountSummaries' => array( array( 'a' => 1 ), array( 'a' => 2 ), array( 'a' => 3 ) ),
				'nextPageToken'    => 'x',
			)
		);

		$items = GoogleClient::get_all_pages(
			GoogleClient::HOST_GA_ADMIN . '/v1beta/accountSummaries',
			array(),
			'accountSummaries',
			array( 'auth' => false ),
			2
		);

		$this->assertCount( 2, $items );
		$this->assertSame( 1, FakeHttp::count() );
	}

	// =========================================================================
	// Gate
	// =========================================================================

	public function test_gate_recusa_canal_fechado(): void {
		$this->enable_all();
		Options::set( Options::ENABLED, false );

		$result = Gate::check( 'ga' );

		$this->assertIsArray( $result );
		$this->assertSame( 'f3_google_disabled', $result['error_code'] );
		$this->assertFalse( Gate::permission( 'ga' ) );
	}

	public function test_gate_recusa_sem_capacidade(): void {
		$this->enable_all();
		$GLOBALS['f3_test_caps'] = array( 'edit_posts' => true );

		$result = Gate::check( 'ga' );

		$this->assertIsArray( $result );
		$this->assertSame( 'f3_google_forbidden', $result['error_code'] );
		$this->assertFalse( Gate::permission( 'ga' ) );
	}

	public function test_gate_recusa_conector_desligado(): void {
		$this->enable_all();
		Options::set( Options::GA_ENABLED, false );

		$result = Gate::check( 'ga' );

		$this->assertIsArray( $result );
		$this->assertSame( 'f3_google_connector_off', $result['error_code'] );
		$this->assertFalse( Gate::permission( 'ga' ) );
	}

	public function test_gate_recusa_sem_credencial(): void {
		$this->enable_all();
		Options::set_secret( Options::SA_JSON, '' );

		$result = Gate::check( 'ga' );

		$this->assertIsArray( $result );
		$this->assertSame( 'f3_google_not_configured', $result['error_code'] );

		// A permissão continua verdadeira de propósito: é o que deixa a rota
		// explicar o que falta em vez de devolver "permission denied".
		$this->assertTrue( Gate::permission( 'ga' ) );
	}

	public function test_gate_recusa_ads_sem_developer_token(): void {
		$this->enable_all();
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, '' );

		$result = Gate::check( 'ads' );

		$this->assertIsArray( $result );
		$this->assertSame( 'f3_google_ads_no_developer_token', $result['error_code'] );
		$this->assertNull( Gate::check( 'ga' ), 'o GA não depende do developer token' );
	}

	// =========================================================================
	// Ability
	// =========================================================================

	public function test_register_injeta_os_padroes_da_casa(): void {
		$this->enable_all();

		Ability::register(
			'ga/teste-padroes',
			'ga',
			array(
				'label'        => 'Teste',
				'description'  => 'Rota de teste.',
				'input_schema' => array(
					'properties' => array( 'property_id' => array( 'type' => 'string' ) ),
				),
				'callback'     => static function ( array $input ): array {
					return Response::ok(
						array(
							'rows'      => array( array( 1 ), array( 2 ) ),
							'row_count' => 2,
						),
						'pronto'
					);
				},
			)
		);

		$ability = wp_get_ability( 'ga/teste-padroes' );
		$this->assertNotNull( $ability );

		$meta = $ability->get_meta();
		$this->assertTrue( $meta['mcp']['public'] );
		$this->assertSame( 'tool', $meta['mcp']['type'] );
		$this->assertTrue( $meta['annotations']['readonly'] );
		$this->assertFalse( $meta['annotations']['destructive'] );
		$this->assertSame( 'google', $ability->get_category() );

		$schema = $ability->get_input_schema();
		$this->assertSame( 'object', $schema['type'] );
		$this->assertFalse( $schema['additionalProperties'] );

		$this->assertTrue( $ability->check_permissions( array() ) );

		$result = $ability->execute( array( 'property_id' => '987654' ) );
		$this->assertTrue( $result['success'] );
		$this->assertSame( 'pronto', $result['message'] );

		$log = Audit::recent( 1 );
		$this->assertSame( 'ga/teste-padroes', $log[0]['action'] );
		$this->assertSame( '987654', $log[0]['target'] );
		$this->assertSame( 2, $log[0]['extra']['rows'] );
		$this->assertSame( 'ok', $log[0]['extra']['status'] );
		$this->assertArrayHasKey( 'ms', $log[0]['extra'] );
	}

	public function test_excecao_na_habilidade_vira_resposta_de_erro(): void {
		$this->enable_all();

		Ability::register(
			'ga/teste-excecao',
			'ga',
			array(
				'label'    => 'Explode',
				'callback' => static function ( array $input ): array {
					throw new \RuntimeException( 'estourou por dentro' );
				},
			)
		);

		$result = wp_get_ability( 'ga/teste-excecao' )->execute( array() );

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_exception', $result['error_code'] );
		$this->assertStringContainsString( 'estourou por dentro', $result['message'] );

		$log = Audit::recent( 1 );
		$this->assertSame( 'ga/teste-excecao', $log[0]['action'] );
		$this->assertSame( 'erro', $log[0]['extra']['status'] );
	}

	public function test_habilidade_recusa_quando_o_portao_fecha(): void {
		$this->enable_all();
		Options::set( Options::ENABLED, false );

		Ability::register(
			'ga/teste-portao',
			'ga',
			array(
				'label'    => 'Portão',
				'callback' => static function ( array $input ): array {
					return Response::ok( array( 'nunca' => true ) );
				},
			)
		);

		$ability = wp_get_ability( 'ga/teste-portao' );

		$this->assertFalse( $ability->check_permissions( array() ) );

		$result = $ability->execute( array() );
		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_disabled', $result['error_code'] );
		$this->assertArrayNotHasKey( 'nunca', $result );
	}

	public function test_entrada_como_string_json_e_aceita(): void {
		$this->enable_all();

		// O `execute()` do WP_Ability já descarta uma entrada que não seja
		// array, então o teste pega o execute_callback no registro e o chama
		// direto — é esse caminho que precisa aguentar a string JSON que alguns
		// clientes MCP mandam.
		$capturado = null;
		$captura   = static function ( $args ) use ( &$capturado ) {
			$capturado = $args;

			return $args;
		};

		add_filter( 'wp_register_ability_args', $captura );

		Ability::register(
			'ga/teste-string',
			'ga',
			array(
				'label'    => 'String',
				'callback' => static function ( array $input ): array {
					return Response::ok( array( 'recebido' => $input['property_id'] ?? '' ) );
				},
			)
		);

		remove_filter( 'wp_register_ability_args', $captura );

		$this->assertIsArray( $capturado );

		$result = call_user_func( $capturado['execute_callback'], '{"property_id":"111"}' );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 'properties/111', $result['recebido'], '0.2.0 resolve seletores para IDs canônicos após decodificar o JSON' );

		// E uma entrada sem sentido não derruba nada.
		$this->assertTrue( call_user_func( $capturado['execute_callback'], 'nem json' )['success'] );
	}

	public function test_scrub_remove_segredo_de_um_texto(): void {
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'token-do-desenvolvedor' );

		$this->assertSame(
			'falhou com [redigido] no meio',
			Ability::scrub( 'falhou com token-do-desenvolvedor no meio' )
		);
	}

	// =========================================================================
	// Response e Audit
	// =========================================================================

	public function test_response_ok_e_fail(): void {
		$ok = Response::ok( array( 'rows' => array( 1, 2 ), 'success' => false ), 'tudo certo' );

		$this->assertTrue( $ok['success'], 'os dados não podem sobrescrever success' );
		$this->assertSame( 'tudo certo', $ok['message'] );
		$this->assertSame( array( 1, 2 ), $ok['rows'] );

		$fail = Response::fail( 'deu ruim', array( 'rows' => array() ) );
		$this->assertFalse( $fail['success'] );
		$this->assertSame( 'deu ruim', $fail['message'] );
		$this->assertSame( 'f3_google_error', $fail['error_code'] );
		$this->assertNull( $fail['details'] );
		$this->assertSame( array(), $fail['rows'] );

		$fail_wp = Response::fail( new \WP_Error( 'meu_codigo', 'mensagem do erro' ) );
		$this->assertSame( 'meu_codigo', $fail_wp['error_code'] );
		$this->assertSame( 'mensagem do erro', $fail_wp['message'] );
	}

	public function test_audit_e_circular(): void {
		Options::set( 'f3_mcp_google_audit_retention', Audit::MAX );
		for ( $i = 1; $i <= Audit::MAX + 5; $i++ ) {
			Audit::log( 'ga/teste', 'alvo-' . $i, array( 'rows' => $i, 'objeto' => array( 'nao', 'entra' ) ) );
		}

		$log = array_reverse( Audit::recent( 0 ) );
		$this->assertCount( Audit::MAX, $log );
		$this->assertSame( 'alvo-6', $log[0]['target'], 'as mais antigas saem primeiro' );

		$recent = Audit::recent( 3 );
		$this->assertCount( 3, $recent );
		$this->assertSame( 'alvo-105', $recent[0]['target'], 'a mais recente vem primeiro' );
		$this->assertSame( 105, $recent[0]['extra']['rows'] );
		$this->assertArrayNotHasKey( 'objeto', $recent[0]['extra'], 'só escalares vão para o log' );
		$this->assertSame( 1, $recent[0]['user'] );

		Audit::clear();
		$this->assertSame( array(), Audit::recent() );
	}

	// =========================================================================
	// OAuthFlow
	// =========================================================================

	public function test_callback_com_state_invalido_e_recusado(): void {
		$this->configure_oauth();
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, '' );

		$request = new \WP_REST_Request(
			array(
				'state' => str_repeat( 'ab', 16 ),
				'code'  => 'codigo-qualquer',
			)
		);

		try {
			OAuthFlow::handle_callback( $request );
			$this->fail( 'deveria ter redirecionado' );
		} catch ( \F3_Test_Redirect $redirect ) {
			$this->assertStringContainsString( 'f3_status=oauth_state', $redirect->location );
		}

		$this->assertSame( 0, FakeHttp::count(), 'sem state válido nada é trocado com a Google' );
		$this->assertSame( '', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
	}

	public function test_callback_com_state_valido_grava_o_refresh_token_cifrado(): void {
		$this->configure_oauth();
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, '' );
		Options::delete( Options::OAUTH_EMAIL );

		$state = str_repeat( 'f3', 16 );
		set_transient( 'f3_mcp_google_oauth_state_' . $state, OAuthFlow::state_record(), 600 );

		FakeHttp::push(
			'oauth2.googleapis.com/token',
			200,
			array(
				'access_token'  => 'tok-novo',
				'refresh_token' => 'refresh-novinho',
				'expires_in'    => 3599,
				'scope'         => Credentials::SCOPE_GA . ' openid email',
				'id_token'      => self::fake_id_token( array( 'email' => 'dono@exemplo.com' ) ),
			)
		);

		$request = new \WP_REST_Request(
			array(
				'state' => $state,
				'code'  => 'codigo-de-troca',
			)
		);

		try {
			OAuthFlow::handle_callback( $request );
			$this->fail( 'deveria ter redirecionado' );
		} catch ( \F3_Test_Redirect $redirect ) {
			$this->assertStringContainsString( 'f3_status=oauth_ok', $redirect->location );
		}

		$body = FakeHttp::last()['body'];
		$this->assertSame( 'authorization_code', $body['grant_type'] );
		$this->assertSame( 'codigo-de-troca', $body['code'] );
		$this->assertSame( OAuthFlow::redirect_uri(), $body['redirect_uri'] );

		$this->assertSame( 'refresh-novinho', Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) );
		$this->assertStringStartsWith( 'v1:', $GLOBALS['f3_test_options'][ Options::OAUTH_REFRESH_TOKEN ] );
		$this->assertStringNotContainsString(
			'refresh-novinho',
			$GLOBALS['f3_test_options'][ Options::OAUTH_REFRESH_TOKEN ]
		);

		$this->assertSame( 'dono@exemplo.com', Options::get( Options::OAUTH_EMAIL ) );
		$this->assertSame( 'oauth', Options::auth_mode() );

		// State de uso único: o mesmo retorno não vale de novo.
		$this->assertFalse( get_transient( 'f3_mcp_google_oauth_state_' . $state ) );
	}

	public function test_authorize_url_pede_offline_e_consentimento(): void {
		$this->configure_oauth();

		$url = OAuthFlow::authorize_url( 'estado-1', array( Credentials::SCOPE_GA ) );

		$this->assertStringStartsWith( 'https://accounts.google.com/o/oauth2/v2/auth?', $url );
		$this->assertStringContainsString( 'access_type=offline', $url );
		$this->assertStringContainsString( 'prompt=consent', $url );
		$this->assertStringContainsString( 'state=estado-1', $url );
		$this->assertStringContainsString( rawurlencode( Credentials::SCOPE_GA ), $url );
		$this->assertStringContainsString( rawurlencode( OAuthFlow::redirect_uri() ), $url );
	}

	// =========================================================================
	// Tela de administração
	// =========================================================================

	public function test_a_tela_nao_imprime_nenhum_segredo(): void {
		$this->enable_all();
		Options::set( Options::OAUTH_CLIENT_ID, 'cliente.apps.googleusercontent.com' );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'segredo-do-cliente-9876' );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'refresh-token-secreto' );

		ob_start();
		Admin::render();
		$html = (string) ob_get_clean();

		foreach (
			array(
				'segredo-do-cliente-9876',
				'refresh-token-secreto',
				'dev-token-1234',
				'BEGIN PRIVATE KEY',
				self::keys()['private'],
			) as $secret
		) {
			$this->assertStringNotContainsString( $secret, $html );
		}

        $this->assertStringContainsString( self::SA_EMAIL, $html );
        $this->assertStringContainsString( 'Salvo e cifrado', $html );
        $this->assertStringNotContainsString( 'name="oauth_client_secret"', $html, 'O formulário OAuth só aparece na aba OAuth.' );
        foreach ( array( array( 'section' => 'connection', 'method' => 'oauth' ), array( 'section' => 'services' ), array( 'section' => 'advanced' ) ) as $screen ) {
            $_GET = $screen; ob_start(); Admin::render(); $other = (string) ob_get_clean();
            foreach ( array( 'segredo-do-cliente-9876', 'refresh-token-secreto', 'dev-token-1234', 'BEGIN PRIVATE KEY', self::keys()['private'] ) as $secret ) { $this->assertFalse( strpos( $other, $secret ), 'O painel nunca devolve segredos.' ); }
        }
        $_GET = array();

	}

	public function test_handler_salva_a_chave_e_recusa_json_invalido(): void {
		Options::set( Options::ENABLED, true );

		// $_POST chega escapado no WordPress (wp_magic_quotes); o handler
		// desfaz isso com wp_unslash. Sem essa ida e volta o "\n" de dentro da
		// chave privada viraria "n" e o JSON quebraria.
		$json = (string) wp_json_encode( self::sa_key_array() );

		$_POST = array(
			'sa_json'    => addslashes( $json ),
			'sa_subject' => '',
		);

		try {
			Admin::handle_save_sa();
			$this->fail( 'deveria ter redirecionado' );
		} catch ( \F3_Test_Redirect $redirect ) {
			$this->assertStringContainsString( 'f3_status=sa_saved', $redirect->location );
		}

		$guardado = json_decode( Options::get_secret( Options::SA_JSON ), true );
		$this->assertIsArray( $guardado );
		$this->assertSame( self::SA_EMAIL, $guardado['client_email'] );
		$this->assertSame( self::keys()['private'], $guardado['private_key'] );
		$this->assertSame( 'service_account', Options::auth_mode() );

		// Agora um JSON que não é de service account.
		$_POST = array( 'sa_json' => addslashes( '{"type":"authorized_user"}' ) );

		try {
			Admin::handle_save_sa();
			$this->fail( 'deveria ter redirecionado' );
		} catch ( \F3_Test_Redirect $redirect ) {
			$this->assertStringContainsString( 'f3_status=save_failed', $redirect->location );
		}

		// A chave boa continua lá: uma tentativa ruim não pode apagá-la.
		$this->assertSame( self::SA_EMAIL, json_decode( Options::get_secret( Options::SA_JSON ), true )['client_email'] );

		$_POST = array();
	}

	// =========================================================================
	// SelfTest
	// =========================================================================

	public function test_selftest_offline_passa(): void {
		$this->enable_all();

		$result = SelfTest::run();

		$this->assertTrue( $result['success'], (string) wp_json_encode( $result['checks'] ) );
		$this->assertSame( 0, $result['failed'] );
		$this->assertGreaterThanOrEqual( 5, $result['passed'] );

		$nomes = array_column( $result['checks'], 'name' );
		$this->assertContains( 'crypto', $nomes );
		$this->assertContains( 'jwt', $nomes );
		$this->assertContains( 'hosts', $nomes );
		$this->assertContains( 'gate', $nomes );
	}

	public function test_selftest_live_pede_token_e_nao_mostra_segredo(): void {
		$this->enable_all();
		Options::set( \Fator3\McpGoogle\Connections::SERVICES, array( 'ga' => 'read' ) );
		FakeHttp::push( 'analyticsadmin.googleapis.com', 200, array( 'accountSummaries' => array() ) );

		FakeHttp::push(
			'oauth2.googleapis.com/token',
			200,
			array(
				'access_token' => 'tok-secreto-do-selftest',
				'expires_in'   => 3600,
			)
		);

		$result = SelfTest::run( array( 'live' => true ) );
		$json   = (string) wp_json_encode( $result );

		$this->assertTrue( $result['success'], $json );
		$this->assertStringNotContainsString( 'tok-secreto-do-selftest', $json );
		$this->assertTrue( $result['execution_success'] );
	}
}
