(() => {
  'use strict';
  const root = document.querySelector('.f3-google');
  if (!root) return;
  root.classList.add('f3-js');
  const status = root.querySelector('#f3-live');
  root.querySelectorAll('[data-copy-target]').forEach(button => {
    button.addEventListener('click', async () => {
      const node = document.getElementById(button.dataset.copyTarget);
      if (!node) return;
      try {
        if (!navigator.clipboard) throw new Error('clipboard unavailable');
        await navigator.clipboard.writeText(node.textContent);
        status.textContent = 'Conteúdo copiado.';
        const label = button.textContent;
        button.textContent = 'Copiado';
        setTimeout(() => { button.textContent = label; }, 1800);
      } catch {
        const range = document.createRange();
        range.selectNodeContents(node);
        const selection = window.getSelection();
        selection.removeAllRanges(); selection.addRange(range);
        status.textContent = 'Conteúdo selecionado. Use o comando de copiar do navegador.';
      }
    });
  });
  root.querySelectorAll('[data-service-select]').forEach(select => {
    select.addEventListener('change', () => {
      const target = root.querySelector(`[data-service-fields="${select.dataset.serviceSelect}"]`);
      if (!target) return;
      target.hidden = !select.value;
      target.querySelectorAll('input,select,textarea').forEach(input => { input.disabled = !select.value; });
    });
  });
  const dirty = new Set();
  root.querySelectorAll('form.f3-form:not([data-no-dirty])').forEach(form => {
    form.addEventListener('input', () => dirty.add(form));
    form.addEventListener('change', () => dirty.add(form));
    form.addEventListener('submit', event => {
      const others = [...dirty].filter(item => item !== form);
      if (others.length && !window.confirm('Há alterações não salvas em outra seção. Continuar descarta essas alterações.')) { event.preventDefault(); return; }
      dirty.clear();
    });
  });
  window.addEventListener('beforeunload', event => {
    if (!dirty.size) return;
    event.preventDefault(); event.returnValue = '';
  });
})();
