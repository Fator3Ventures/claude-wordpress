# Contratos atuais — 0.4.0

A especificação de configuração vigente está em [GUIA-0.4.0.md](docs/GUIA-0.4.0.md) e no contrato `google/configuration-schema` 1.1.0; consultas de 1.0.0 continuam disponíveis. A preparação de credenciais não troca o método ativo, e a ativação é explícita. Os handlers públicos usam `Settings::save()` com gravação verificada e revisão de configuração.

O conteúdo abaixo documenta decisões históricas da implementação original. As divisões de trabalho nele descritas são registros daquela entrega.

---

# Contratos de implementação — referência histórica 0.2.0

Para a versão 0.3.1, consulte [Guia 0.3.1](docs/GUIA-0.3.1.md) e a habilidade `google/configuration-schema` (contrato `1.0.0`). Os contratos de workflows e selftest estão no [Guia 0.3.0](docs/GUIA-0.3.0.md). O texto abaixo registra o planejamento da base e não substitui esses contratos.

O plano enviado é a especificação funcional. Este documento fixa as interfaces compartilhadas antes das fases paralelas previstas no plano. Preservar as 21 habilidades e as opções da versão 0.1.0. PHP 8.0+, namespace `Fator3\McpGoogle`. Todos os arquivos de produção verificam ABSPATH.

## Núcleo

- `Ability::register(string $name, string $connector, array $args): void`: contrato anterior, acrescido de `mode` = `read` (padrão) ou `write`. `callback(array $input)` devolve `Response::ok/fail` ou WP_Error. `mode=write` configura annotations readonly=false, destructive=true, idempotent=false. Uma chamada não exige confirmação adicional no plugin.
- Conectores do Gate: `ga`, `ads`, `gsc`, `siteverification`, `sheets`, `drive`, `any`. O portão geral e manage_options continuam obrigatórios. `any` permite diagnóstico sem credencial. Mantêm-se as opções existentes GA_ENABLED e ADS_ENABLED; os novos serviços usam o portão geral.
- `Audit::before($value): void` e `Audit::after($value): void` capturam estado no contexto da habilidade corrente. Chamar antes/depois nas implementações que conseguem obter estado real. Para criação, before pode ser `{exists:false}`; operação sem snapshot deve declarar `{available:false,reason:...}`. Não confundir parâmetros enviados com estado anterior. Núcleo sempre grava before/after limitados e redigidos, dry_run e status nas escritas, inclusive erros. `Audit::redact($value)` higieniza recursivamente segredos e dados de Customer Match antes de persistir.
- `Http\GoogleClient::request($method,$url,?array $body=null,array $opts=[])` devolve resultado JSON cru ou WP_Error. É a única fronteira HTTP. Usar `opts['mode']='write'` ou `opts['retries']=0` nas mutações, evitando repetição de operações não idempotentes. MP é a única API nomeada que precisa montar URL fixa fora da descoberta. `Credentials::scopes_for($connector)` expande escopos por serviço.
- `Unified\Accounts::resolve_many(string $connector,array $selectors)` devolve lista de IDs ou WP_Error. Aceita IDs, nomes únicos e `*`; erro de ambiguidade inclui candidatos. `resolve_one` devolve um ID ou WP_Error. Conectores aceitam aliases ga/ga4, ads/google-ads, gsc/search-console. Núcleo resolve property_id/customer_id/site_url das rotas nomeadas antes do callback, incluindo fanout explícito `*`. Não duplicar essa resolução nos módulos, exceto consultas internas (Blend/Query).

## Descoberta e execução genérica

- API keys: `analytics-admin-v1alpha`, `analytics-admin-v1beta`, `analytics-data-v1beta`, `analytics-data-v1alpha`, `google-ads`, `search-console`, `site-verification`, `sheets`, `drive`. Aceitar aliases analytics-admin (alpha), analytics-data (beta), ads, ga-admin, ga-data, gsc, siteverification. Google Ads usa Options::ads_api_version().
- `Generic\Discovery::document(string $api)` => documento ou WP_Error; `method(string $api,string $method)` => metadados ou WP_Error. Métodos usam ID completo da descoberta real (ex.: analyticsadmin.properties.create). Catálogo obtido das URLs fixas dos nove documentos, cache 24h. Fixtures originais em `tests/fixtures/discovery`; fontes SHA256 em sources.json. Não usar allowlist de métodos; expor catálogo integral com paginação. Não usar URL fornecida pelo cliente.
- `Generic\ExecuteAction::call(string $api,string $method,array $path_params=[],array $query=[],?array $body=null,array $opts=[])` => resposta crua ou WP_Error. Aplica Gate do serviço, descobre método, valida parâmetros, monta URL exata, autentica com escopos aceitos pelo método, cabeçalhos Ads quando necessário, e chama GoogleClient. `opts['mode']` identifica leitura/escrita, write por padrão. `opts['dry_run']` opcional só quando API aceita validateOnly, sem simulação de sucesso.
- `Generic\Abilities::register()` registra list-actions, execute-action (write) e google/audit (read). O módulo Ads registra ads/mutate.
- Audit before/after em escrita genérica: recuperar recurso via método GET irmão quando identificável; caso impossível marcar explicitamente indisponível. Não guardar request como before. Rejeitar path/query desconhecidos, traversal e URL externa mesmo com host permitido.

## Módulos e registro

- `SearchConsole\Abilities::register()` e `SiteVerification\Abilities::register()` registram todas as rotas nomeadas do plano.
- `SearchConsole\Api::accounts(): array|WP_Error` devolve linhas `{connector:'search-console',account_id:<siteUrl>,native_account_id:<siteUrl>,name:<siteUrl>,...}`.
- `SearchConsole\Api::fields(): array` devolve campos `{id,label,type:'metric'|'dimension',kind:'number'|'string'}`.
- `SearchConsole\Api::unified(array $input): array` implementa google/query para GSC com a mesma tabela normalizada de Query: Response success, columns (objetos id,label,type,kind), rows (arrays posicionais), row_count, accounts, warnings, truncated, date_range, compare_date_range quando aplicável. Reutiliza Unified\DateRange/Filters e Accounts. `Query::run` fará despacho para esse método.
- `Analytics\AdminWrite::register()` e `Analytics\MeasurementProtocol::register()` registram GA4 novas. Args principais property_id/customer_id/site_url mantêm compatibilidade com resolução pelo núcleo. Campos resource/name/parent seguem nomes oficiais; documentar esquemas reais. Atualizações aceitam update_mask explícita ou calculada dos campos enviados.
- `Ads\Mutate::register()` e `Ads\WriteAbilities::register()` registram Ads novas. `Ads\Conversions::fields(string $account)` => array de campos conversions:<nome> e conversions_value:<nome> ou WP_Error. `Ads\Conversions::query(array $input): array` atende consultas unificadas com métricas customizadas (inclusive combinação com métricas comuns sem duplicar totais); Query::run fará despacho quando houver essas métricas. Deve aceitar aliases, nomes e * via Accounts. Dry run Ads usa validateOnly real; caminhos que não o suportam recusam explicitamente antes de gravar.
- `Unified\Blend::register()` / `run(array $input):array` e `Sheets\Export::register()` / `run(array $input):array`. Blend aceita queries[], on=['date'] (com campaign/page opcionais) e normaliza formatos de data e page URL/path. Não gerar fanout many-to-many silencioso nem agregar médias como somas; duplicata ambígua exige identificação mais precisa. Prefixar colunas e preservar avisos, períodos comparados e contas. Export aceita query ou blend ou queries[], spreadsheet_id opcional, title, tab_name, mode replace/append, share_with[], shared_drive_folder_id opcional.

## Correções factuais e limites

Service accounts não possuem quota para criar arquivos próprios no Meu Drive. Criar planilha nova exige OAuth de usuário/delegação ou pasta de Drive compartilhado via Drive files.create (mimeType planilha). Caso contrário pedir spreadsheet_id compartilhada ou shared_drive_folder_id. Não prometer criação na conta da SA. O plano conta algumas rotas de forma inexata; reportar o registro efetivamente executado.

Os escopos listados no plano não cobrem todos os métodos: leitura Analytics, gerenciamento de usuários têm escopos próprios. Usar documentos reais para seleção. Status separa escopos solicitados, escopos OAuth registrados e APIs observadas; token válido não prova permissão ou API habilitada.

## Propriedade de arquivos nas fases paralelas

Núcleo/integração: agente principal (Ability, Audit, Gate, Credentials, GoogleClient, Options, Query, Abilities unificadas, Accounts, bootstrap principal, Plugin, testes integrais e documentação). Fase genérica: apenas includes/Generic e testes Generic novos. Fase GA: somente AdminWrite.php, MeasurementProtocol.php e testes GA novos. Fase Ads: Mutate.php, WriteAbilities.php, Conversions.php e testes Ads novos. Fase GSC: includes/SearchConsole, includes/SiteVerification e testes próprios. Fase blend/export: Unified/Blend.php, includes/Sheets e testes próprios. Não editar bootstrap, Query ou módulos de outro agente; enviar pedidos de integração ao principal.

Os testes PHPUnit existentes ficam preservados e ampliados. Novos módulos podem acrescentar classes de teste com nomes exclusivos; o principal liga o bootstrap. Não alterar testes para aceitar regressões. HTTP Google simulado nos testes locais; testes reais WordPress 6.9 verificam registro e schemas. Ensaio vivo depende de credenciais e destinos de teste que não foram fornecidos nesta sessão.
