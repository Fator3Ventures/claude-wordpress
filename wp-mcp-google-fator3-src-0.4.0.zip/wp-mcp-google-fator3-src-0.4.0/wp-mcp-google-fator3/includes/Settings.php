<?php
/** Serialized, verified configuration changes with optimistic revision checks. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Settings {
    public const AUTH_READY = 'f3_mcp_google_auth_ready';
    public const REVISION = 'f3_mcp_google_configuration_revision';

    /** A digest of stored settings catches stale forms, including writes by older code. */
    public static function revision() {
        $names = array_merge( Connections::scoped_names(), array( self::REVISION, Options::ENABLED ), array_keys( Options::LIMITS ) );
        $snapshot = array();
        foreach ( array_unique( $names ) as $name ) {
            if ( Options::TOKEN_INDEX === $name ) { continue; }
            $state = Options::stored( Options::storage_name( $name ) );
            if ( ! $state['success'] ) { return new \WP_Error( 'f3_google_option_read', 'Não foi possível ler a revisão da configuração.' ); }
            $snapshot[ $name ] = array( $state['exists'], $state['value'] );
        }
        return hash( 'sha256', Connections::id() . '|' . serialize( $snapshot ) );
    }

    public static function conflict(): array {
        return Response::fail( new \WP_Error( 'f3_google_configuration_conflict', 'A configuração mudou desde que esta tela foi aberta. Recarregue e confira os valores antes de salvar.' ), array( 'persisted' => false, 'changed' => false ) );
    }

    public static function save( array $values, array $secrets = array(), array $deletes = array(), ?string $expected = null ): array {
        // The common lock also serializes site-wide settings across connections.
        $global = Lock::acquire( 'configuration:site' );
        if ( null === $global ) { return self::busy(); }
        $lock = Lock::acquire( 'configuration:' . Connections::id() );
        if ( null === $lock ) { Lock::release( $global ); return self::busy(); }
        try {
            $revision = self::revision();
            if ( is_wp_error( $revision ) ) { return Response::fail( $revision ); }
            if ( null !== $expected && ! hash_equals( $revision, $expected ) ) { return self::conflict(); }
            // Avoid re-encrypting equal secrets: "no change" is an observable outcome.
            foreach ( $secrets as $name => $plain ) {
                $state = Options::stored( Options::storage_name( $name ) );
                if ( ! $state['success'] ) { return Response::fail( new \WP_Error( 'f3_google_option_read', 'Falha ao ler a credencial existente.' ) ); }
                if ( '' === $plain ) { $deletes[] = $name; unset( $secrets[ $name ] ); continue; }
                if ( $state['exists'] && null === Options::secret_problem( $name ) && hash_equals( Options::get_secret( $name ), $plain ) ) { unset( $secrets[ $name ] ); }
            }
            foreach ( $values as $name => $value ) {
                $state = Options::stored( Options::storage_name( $name ) );
                if ( ! $state['success'] ) { return Response::fail( new \WP_Error( 'f3_google_option_read', 'Falha ao ler a configuração existente.' ) ); }
                if ( $state['exists'] && self::equal( $state['value'], $value ) ) { unset( $values[ $name ] ); }
            }
            foreach ( $deletes as $i => $name ) {
                $state = Options::stored( Options::storage_name( $name ) );
                if ( ! $state['success'] ) { return Response::fail( new \WP_Error( 'f3_google_option_read', 'Falha ao ler o valor a remover.' ) ); }
                if ( ! $state['exists'] ) { unset( $deletes[ $i ] ); }
            }
            if ( ! $values && ! $secrets && ! $deletes ) { return array( 'success' => true, 'persisted' => true, 'changed' => false, 'revision' => $revision, 'message' => 'Nenhuma alteração necessária.' ); }
            $values[ self::REVISION ] = bin2hex( random_bytes( 16 ) );
            $result = Options::batch_verified( $values, $secrets, array_values( array_unique( $deletes ) ) );
            if ( ! $result['success'] ) { return $result; }
            Auth\Credentials::invalidate_cache();
            $result['changed'] = true;
            $result['revision'] = self::revision();
            if ( is_wp_error( $result['revision'] ) ) { return Response::fail( $result['revision'], array( 'persisted' => true, 'changed' => true ) ); }
            Audit::log( 'configuration:saved', Connections::id(), array( 'status' => 'ok' ) );
            return $result;
        } finally { Lock::release( $lock ); Lock::release( $global ); }
    }
    private static function equal( $a, $b ): bool {
        return is_scalar( $a ) && is_scalar( $b ) ? (string) $a === (string) $b : $a === $b;
    }
    private static function busy(): array { return Response::fail( new \WP_Error( 'f3_google_configuration_busy', 'Outra configuração está sendo salva. Aguarde e tente novamente.' ), array( 'persisted' => false, 'changed' => false ) ); }
}
