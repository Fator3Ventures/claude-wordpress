<?php
/** Versioned configuration discovery. Configuration remains owned by this plugin. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Configuration {
	public const CONTRACT_VERSION = '1.1.0';
    public const SUPPORTED_VERSIONS = array( '1.0.0', '1.1.0' );

	/** Metadata references the same limits and validators used by the writers. */
	public static function definitions(): array {
		$boolean = array( 'type' => 'boolean', 'default' => false );
		$string = array( 'type' => 'string', 'default' => '' );
		$rules = array(
			Options::ENABLED => $boolean,
			Options::GA_ENABLED => $boolean,
			Options::ADS_ENABLED => $boolean,
			Options::AUTH_MODE => array( 'type' => 'string', 'enum' => Options::AUTH_MODES, 'default' => 'service_account' ),
			Options::SA_JSON => array( 'type' => 'string', 'writeOnly' => true ),
			Options::SA_SUBJECT => $string,
			Options::OAUTH_CLIENT_ID => $string,
			Options::OAUTH_CLIENT_SECRET => array( 'type' => 'string', 'writeOnly' => true ),
			Options::OAUTH_REFRESH_TOKEN => array( 'type' => 'string', 'writeOnly' => true ),
			Options::OAUTH_EMAIL => $string + array( 'readOnly' => true ),
			Options::OAUTH_SCOPES => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'default' => array(), 'readOnly' => true ),
			Options::ADS_DEVELOPER_TOKEN => array( 'type' => 'string', 'writeOnly' => true ),
			Options::ADS_LOGIN_CUSTOMER_ID => $string,
			Options::ADS_API_VERSION => array( 'type' => 'string', 'pattern' => self::pattern( Options::ADS_VERSION_PATTERN ), 'default' => Options::ADS_VERSION_DEFAULT ),
			Options::GA_DEFAULT_PROPERTY => $string,
			Connections::SERVICES => array( 'anyOf' => array( Setup::services_schema(), array( 'type' => 'null' ) ), 'default' => null ),
			Connections::BINDINGS => Setup::bindings_schema() + array( 'default' => new \stdClass() ),
			Connections::REGISTRY => array( 'type' => 'object', 'maxProperties' => Connections::MAX_CONNECTIONS, 'readOnly' => true ),
		) + Options::LIMITS;
		$writes = array(
			Options::ENABLED => array( 'panel:toggle' ),
			Options::GA_ENABLED => array( 'google/configure', 'panel:toggle-ga' ),
			Options::ADS_ENABLED => array( 'google/configure', 'panel:toggle-ads' ),
			Options::AUTH_MODE => array( 'panel:save-mode', 'panel:save-sa', 'panel:import' ),
			Options::SA_JSON => array( 'panel:save-sa', 'panel:import' ),
			Options::SA_SUBJECT => array( 'panel:save-sa', 'panel:import' ),
			Options::OAUTH_CLIENT_ID => array( 'panel:save-oauth', 'panel:import' ),
			Options::OAUTH_CLIENT_SECRET => array( 'panel:save-oauth', 'panel:import' ),
			Options::OAUTH_REFRESH_TOKEN => array( 'google/disconnect', 'panel:save-oauth' ),
			Options::OAUTH_EMAIL => array( 'google/disconnect', 'panel:save-oauth' ),
			Options::OAUTH_SCOPES => array( 'google/disconnect', 'panel:save-oauth' ),
			Options::ADS_DEVELOPER_TOKEN => array( 'panel:save-ads' ),
			Options::ADS_LOGIN_CUSTOMER_ID => array( 'panel:save-ads' ),
			Options::ADS_API_VERSION => array( 'panel:save-ads' ),
			Options::GA_DEFAULT_PROPERTY => array( 'google/configure', 'panel:save-ga' ),
			Options::MAX_ROWS => array( 'panel:save-limits' ),
			Options::HTTP_TIMEOUT => array( 'panel:save-limits' ),
            Options::AUDIT_RETENTION => array( 'panel:save-limits' ),
            Options::INSPECTION_BUDGET => array( 'panel:save-limits' ),
			Connections::SERVICES => array( 'google/configure', 'panel:setup' ),
			Connections::BINDINGS => array( 'google/configure', 'panel:setup' ),
			Connections::REGISTRY => array( 'google/create-connection', 'panel:create' ),
		);
		$out = array();
		foreach ( $rules as $name => $schema ) {
			$id = substr( $name, strlen( 'f3_mcp_google_' ) );
			$operations = $writes[ $name ] ?? array();
			$dependencies = array();
			if ( in_array( $name, array( Options::SA_JSON, Options::SA_SUBJECT ), true ) ) { $dependencies[] = array( 'option' => 'auth_mode', 'equals' => 'service_account', 'applies_to' => 'use' ); }
			if ( 0 === strpos( $id, 'oauth_' ) ) { $dependencies[] = array( 'option' => 'auth_mode', 'equals' => 'oauth', 'applies_to' => 'use' ); }
			if ( 0 === strpos( $id, 'ads_' ) ) { $dependencies[] = array( 'option' => 'services', 'property_present' => 'ads', 'missing_option' => 'legacy_enabled', 'applies_to' => 'use' ); }
			if ( 0 === strpos( $id, 'ga_' ) ) { $dependencies[] = array( 'option' => 'services', 'property_present' => 'ga', 'missing_option' => 'legacy_enabled', 'applies_to' => 'use' ); }
			$out[ $id ] = array( 'option_name' => $name, 'scope' => in_array( $name, Connections::scoped_names(), true ) ? 'connection' : 'site', 'schema' => $schema, 'secret' => in_array( $name, Options::secret_names(), true ), 'dependencies' => $dependencies, 'allowed_operations' => array_merge( array( 'google/configuration-schema' ), $operations ), 'mcp_mutable' => count( array_filter( $operations, static fn( $op ) => 0 === strpos( $op, 'google/' ) ) ) > 0 );
		}
		foreach ( array( 'enabled', 'ga_enabled', 'ads_enabled' ) as $id ) { $out[ $id ]['activation_default'] = true; }
		$out['services']['write_semantics'] = 'replace_selection; omitted_keeps_current; empty_object_disables_all';
		$out['bindings']['write_semantics'] = 'merge_fields; omitted_keeps_current; empty_string_clears_field';
		$out['bindings']['field_rules'] = Setup::BINDING_RULES;
		$out['ga_enabled']['mcp_parameter'] = 'services.ga';
		$out['ads_enabled']['mcp_parameter'] = 'services.ads';
		$out['ga_default_property']['mcp_parameter'] = 'bindings.ga_property_id';
		$out['sa_json']['validator'] = 'Auth\\ServiceAccount::validate_key';
		$out['sa_subject']['validator'] = 'empty_or_wordpress_is_email';
		foreach ( array( 'oauth_refresh_token', 'oauth_email', 'oauth_scopes' ) as $id ) { $out[ $id ]['write_semantics'] = 'oauth_callback_sets; listed_operations_can_clear'; }
		foreach ( array( 'audit_retention', 'inspection_budget' ) as $id ) { $out[ $id ]['write_semantics'] = 'verified_panel_write; site_wide'; }
		foreach ( array( 'oauth_refresh_token', 'oauth_email', 'oauth_scopes' ) as $id ) { $out[ $id ]['allowed_operations'][] = 'panel:oauth-start'; }
        foreach ( Admin\Fields::metadata() as $id => $meta ) { if ( isset( $out[ $id ] ) ) { $out[ $id ]['ui'] = $meta; } }
        $out['bindings']['ui']['fields'] = Admin\Fields::resources();
        $out['auth_mode']['write_semantics'] = 'explicit_activation_validates_authentication; preparing_credentials_preserves_active_mode; one_mode_per_connection';
        $out['sa_json']['schema']['maxLength'] = Auth\Configuration::JSON_MAX_BYTES;
        $out['sa_json']['input_max_bytes'] = Auth\Configuration::JSON_MAX_BYTES;
		return $out;
	}

	private static function pattern( string $pcre ): string { return substr( $pcre, 1, strrpos( $pcre, $pcre[0] ) - 1 ); }

	/** Enumerate existing operations; their input schemas come from the live registry. */
	private static function operations(): array {
		$out = array();
		foreach ( array( 'configuration-schema', 'plan-configuration', 'configure', 'list-connections', 'create-connection', 'disconnect', 'preflight' ) as $route ) {
			$name = 'google/' . $route; $ability = wp_get_ability( $name );
			$out[ $name ] = array( 'transport' => 'ability', 'available' => null !== $ability, 'input_schema' => $ability ? $ability->get_input_schema() : null );
		}
		foreach ( array( 'toggle', 'toggle-ga', 'toggle-ads', 'save-mode', 'save-sa', 'save-oauth', 'save-ads', 'save-ga', 'save-limits' ) as $action ) {
			$out[ 'panel:' . $action ] = array( 'transport' => 'wp_admin', 'action' => 'f3_mcp_google_' . str_replace( '-', '_', $action ), 'requires_nonce' => true );
		}
		foreach ( array( 'setup' => 'save', 'create' => 'create', 'import' => 'import' ) as $id => $action ) { $out[ 'panel:' . $id ] = array( 'transport' => 'wp_admin', 'action' => 'f3_google_setup_' . $action, 'requires_nonce' => true ); }
		$out['panel:oauth-start'] = array( 'transport' => 'wp_admin', 'action' => 'f3_mcp_google_oauth_start', 'requires_nonce' => true, 'requires_human_consent' => true );
		$out['panel:import']['semantics'] = array( 'prepares_only_by_default' => true, 'activate_parameter' => 'explicit_service_account_activation', 'maximum_json_bytes' => Auth\Configuration::JSON_MAX_BYTES );
        $out['panel:save-mode']['semantics'] = array( 'validates_authentication' => true, 'expected_revision' => true, 'resource_access_validated' => false );
        $out['panel:oauth-start']['semantics'] = array( 'callback_prepares_only' => true, 'stale_callback_rejected' => true );
        $out['google/configure']['semantics'] = array( 'verified_write' => true, 'validate_access_default' => true, 'scope_expansion_requires_oauth_consent' => true );
		$out['google/create-connection']['limits'] = array( 'maximum_connections_including_default' => Connections::MAX_CONNECTIONS, 'id_pattern' => self::pattern( Connections::ID_PATTERN ), 'label_max_bytes' => Connections::LABEL_MAX_LENGTH );
		return $out;
	}

	private static function prerequisites(): array {
		$services = array();
		foreach ( Setup::LEVELS as $service => $levels ) {
			$services[ $service ] = array( 'selection_option' => 'services', 'selection_property' => $service, 'missing_selection' => 'legacy_enabled', 'profiles' => $levels, 'required_options' => 'ads' === $service ? array( 'ads_developer_token' ) : array() );
			if ( in_array( $service, array( 'ga', 'ads' ), true ) ) { $services[ $service ]['enabled_option'] = $service . '_enabled'; }
		}
		return array(
			'channel' => array( 'option' => 'enabled', 'equals' => true ),
			'credentials' => array( 'selector_option' => 'auth_mode', 'modes' => array(
				'service_account' => array( 'required_options' => array( 'sa_json' ), 'validator' => 'Auth\\ServiceAccount::validate_key' ),
				'oauth' => array( 'required_options' => array( 'oauth_client_id', 'oauth_client_secret', 'oauth_refresh_token' ), 'consent_operation' => 'panel:oauth-start' ),
			) ),
			'services' => $services,
			'google_access' => array( 'status' => 'not_checked', 'check_operation' => 'google/preflight', 'requires_api_enabled_and_resource_permission' => true ),
		);
	}

	private static function effective( string $name, array $schema ) {
		$methods = array( Options::ENABLED => 'is_enabled', Options::GA_ENABLED => 'ga_enabled', Options::ADS_ENABLED => 'ads_enabled', Options::AUTH_MODE => 'auth_mode', Options::ADS_API_VERSION => 'ads_api_version', Options::ADS_LOGIN_CUSTOMER_ID => 'ads_login_customer_id', Options::MAX_ROWS => 'max_rows', Options::HTTP_TIMEOUT => 'http_timeout' );
		if ( isset( $methods[ $name ] ) ) { return Options::{$methods[ $name ]}(); }
		if ( isset( Options::LIMITS[ $name ] ) ) { return Options::limit( $name ); }
		if ( Connections::REGISTRY === $name ) { return (object) Connections::registry(); }
		$value = Options::get( $name, $schema['default'] ?? null );
		if ( in_array( $name, array( Connections::SERVICES, Connections::BINDINGS ), true ) ) { return is_array( $value ) ? (object) $value : $value; }
		return 'string' === ( $schema['type'] ?? '' ) ? (string) $value : $value;
	}

	private static function state( array $definition ): array {
		$name = $definition['option_name'];
		$stored = Options::stored( Options::storage_name( $name ) );
		$state = array( 'read_success' => $stored['success'], 'exists' => $stored['success'] ? $stored['exists'] : null, 'error_code' => $stored['success'] ? null : 'f3_google_option_read' );
		if ( $definition['secret'] ) {
			$state += array( 'redacted' => true, 'configured' => null, 'readable' => null );
			if ( ! $stored['success'] ) { return $state; }
			$state['configured'] = $stored['exists'] && '' !== $stored['value'];
			if ( ! $state['configured'] ) { return $state; }
			try { $plain = is_string( $stored['value'] ) ? Crypto::decrypt( $stored['value'] ) : new \WP_Error( 'invalid' ); }
			catch ( \Throwable $error ) { $plain = new \WP_Error( 'invalid' ); }
			$state['readable'] = ! is_wp_error( $plain );
			$state['error_code'] = $state['readable'] ? null : 'f3_google_crypto_decrypt';
			unset( $plain );
			return $state;
		}
		if ( $stored['success'] ) {
			$state['persisted_value'] = $stored['value'];
			$state['effective_value'] = self::effective( $name, $definition['schema'] );
			$state['using_default'] = ! $stored['exists'];
		}
		return $state;
	}

    public static function read( array $input = array() ): array {
        $gate = Gate::check( 'any' );
        return null !== $gate ? $gate : self::build( $input );
    }
    public static function read_for_admin(): array {
        if ( ! current_user_can( Options::capability() ) ) { return Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão insuficiente.' ) ); }
        return self::build( array() );
    }
    private static function build( array $input ): array {
        $version = $input['contract_version'] ?? self::CONTRACT_VERSION;
        if ( ! in_array( $version, self::SUPPORTED_VERSIONS, true ) ) { return Response::fail( new \WP_Error( 'f3_google_contract_version', 'Versão de contrato não suportada.' ), array( 'supported_contract_versions' => self::SUPPORTED_VERSIONS ) ); }
		$definitions = self::definitions(); $operations = self::operations(); $prerequisites = self::prerequisites();
		if ( '1.0.0' === $version ) { foreach ( $definitions as &$definition ) { unset( $definition['ui'] ); } unset( $definition ); }
		$hash = hash( 'sha256', (string) wp_json_encode( array( 'options' => $definitions, 'operations' => $operations, 'runtime_prerequisites' => $prerequisites ) ) );
		$include = $input['include_values'] ?? true; $complete = true;
		if ( $include ) {
			foreach ( $definitions as &$definition ) {
				$definition['state'] = self::state( $definition );
				if ( null !== $definition['state']['error_code'] ) { $complete = false; }
			} unset( $definition );
		}
		$data = array( 'contract_version' => $version, 'plugin' => array( 'id' => 'wp-mcp-google-fator3', 'version' => F3_MCP_GOOGLE_VERSION ), 'connection_id' => Connections::id(), 'definition_sha256' => $hash, 'values_included' => (bool) $include, 'values_complete' => $include ? $complete : null, 'google_checks_performed' => false, 'authorization' => array( 'required_capability' => Options::capability(), 'channel_must_be_enabled' => true, 'generic_option_write_allowed' => false ), 'options' => $definitions, 'operations' => $operations, 'runtime_prerequisites' => $prerequisites );
        if ( '1.1.0' === $version ) {
            $revision = $include ? Settings::revision() : null;
            if ( is_wp_error( $revision ) ) { $complete = false; }
            $data['configuration_revision'] = is_string( $revision ) ? $revision : null;
            if ( $include ) { $data['authentication'] = array( 'selected_method' => Options::auth_mode(), 'activation_pending' => ! (bool) Options::get( Settings::AUTH_READY, true ), 'configured' => Auth\Credentials::is_configured(), 'one_active_method_per_connection' => true ); }
            $data['supported_contract_versions'] = self::SUPPORTED_VERSIONS;
            $data['values_complete'] = $include ? $complete : null;
        }
		return $complete ? Response::ok( $data ) : Response::fail( new \WP_Error( 'f3_google_configuration_read', 'Contrato disponível; há valores cuja leitura não foi confirmada.' ), $data );
	}

	public static function register(): void {
		Ability::register( 'google/configuration-schema', 'any', array(
			'label' => 'Google: contrato de configuração',
			'description' => 'Contrato versionado de opções, tipos, limites, dependências, operações e valores atuais. Segredos são sempre ocultos. Não consulta o Google.',
			'input_schema' => array( 'properties' => array(
				'contract_version' => array( 'type' => 'string', 'default' => self::CONTRACT_VERSION ),
				'include_values' => array( 'type' => 'boolean', 'default' => true ),
			) ),
			'output_schema' => array( 'type' => 'object', 'required' => array( 'success' ), 'properties' => array(
				'success' => array( 'type' => 'boolean' ),
				'error_code' => array( 'type' => array( 'string', 'null' ) ),
				'contract_version' => array( 'type' => 'string' ),
				'plugin' => array( 'type' => 'object' ),
				'connection_id' => array( 'type' => 'string' ),
                'configuration_revision' => array( 'type' => array( 'string', 'null' ) ),
                'authentication' => array( 'type' => 'object' ),
                'supported_contract_versions' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'definition_sha256' => array( 'type' => 'string' ),
				'values_included' => array( 'type' => 'boolean' ),
				'values_complete' => array( 'type' => array( 'boolean', 'null' ) ),
				'google_checks_performed' => array( 'type' => 'boolean' ),
				'authorization' => array( 'type' => 'object' ),
				'options' => array( 'type' => 'object', 'additionalProperties' => array( 'type' => 'object' ) ),
				'operations' => array( 'type' => 'object', 'additionalProperties' => array( 'type' => 'object' ) ),
				'runtime_prerequisites' => array( 'type' => 'object' ),
			) ),
			'callback' => array( self::class, 'read' ),
		) );
	}
}
