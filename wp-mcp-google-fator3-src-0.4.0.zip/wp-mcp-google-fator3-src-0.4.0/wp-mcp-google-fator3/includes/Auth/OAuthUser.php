<?php
/**
 * Credencial por conta de usuário: refresh token trocado por access token.
 *
 * Alternativa para quem não pode criar service account no projeto do Google
 * Cloud. Custa uma armadilha conhecida: enquanto o app OAuth estiver em modo
 * "Testing" na tela de consentimento, a Google invalida o refresh token em 7
 * dias e o canal para de funcionar sozinho. Publicar o app (ou usar service
 * account) resolve — está escrito no README e na tela de administração.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Auth;

use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class OAuthUser implements CredentialsInterface {

	private string $client_id;

	private string $client_secret;

	private string $refresh_token;

	private string $email;

	public function __construct( string $client_id, string $client_secret, string $refresh_token, string $email = '' ) {
		$this->client_id     = $client_id;
		$this->client_secret = $client_secret;
		$this->refresh_token = $refresh_token;
		$this->email         = $email;
	}

	/**
	 * @return self|\WP_Error
	 */
	public static function from_options() {
		$client_id     = trim( (string) Options::get( Options::OAUTH_CLIENT_ID, '' ) );
		$client_secret = Options::get_secret( Options::OAUTH_CLIENT_SECRET );
		$refresh_token = Options::get_secret( Options::OAUTH_REFRESH_TOKEN );

		if ( '' === $client_id || '' === $client_secret ) {
			return new \WP_Error(
				'f3_google_not_configured',
				__( 'O client ID e o client secret do OAuth ainda não foram informados.', 'wp-mcp-google-fator3' )
			);
		}

		if ( '' === $refresh_token ) {
			return new \WP_Error(
				'f3_google_not_configured',
				__( 'Nenhuma conta Google conectada. Use o botão "Conectar com Google" em Ferramentas > MCP Google.', 'wp-mcp-google-fator3' )
			);
		}

		return new self(
			$client_id,
			$client_secret,
			$refresh_token,
			(string) Options::get( Options::OAUTH_EMAIL, '' )
		);
	}

	/**
	 * @param array $scopes Escopos pedidos.
	 * @return string|\WP_Error
	 */
	public function get_access_token( array $scopes ) {
		$scopes = array_values( array_unique( array_filter( array_map( 'strval', $scopes ) ) ) );
		sort( $scopes );

		$cache_key = Credentials::cache_key( $scopes, $this->identity(), '', hash( 'sha256', $this->refresh_token ) );
		$cached    = Credentials::cached( $cache_key );

		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$lock = \Fator3\McpGoogle\Lock::acquire( 'token:' . $cache_key, 180 );
		if ( null === $lock ) { return new \WP_Error( 'f3_google_token_busy', 'Renovação de token em andamento.', array( 'retryable' => true, 'retry_after' => 2 ) ); }
		try {
			$cached = Credentials::cached( $cache_key );
			if ( '' !== $cached ) { return $cached; }

		$response = GoogleClient::post(
			GoogleClient::HOST_TOKEN . '/token',
			array(
				'grant_type'    => 'refresh_token',
				'refresh_token' => $this->refresh_token,
				'client_id'     => $this->client_id,
				'client_secret' => $this->client_secret,
			),
			array(
				'auth' => false,
				'form' => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $this->handle_error( $response );
		}

		$token = (string) ( $response['access_token'] ?? '' );
		if ( '' === $token ) {
			return new \WP_Error(
				'f3_google_token',
				__( 'A Google não devolveu um access token.', 'wp-mcp-google-fator3' )
			);
		}

		$expires = (int) ( $response['expires_in'] ?? 3600 );
		Credentials::remember( $cache_key, $token, max( 1, $expires - 60 ) );

		return $token;
		} finally { \Fator3\McpGoogle\Lock::release( $lock ); }
	}

	/**
	 * @return array{mode:string,identity:string,configured:bool}
	 */
	public function describe(): array {
		return array(
			'mode'       => 'oauth',
			'identity'   => $this->identity(),
			'configured' => '' !== $this->refresh_token,
		);
	}

	/**
	 * Identidade estável para a chave de cache.
	 *
	 * O e-mail é o ideal, mas ele só existe se o consentimento incluiu o escopo
	 * `email`; sem ele, um hash do client ID basta — nunca o token em si.
	 */
	public function identity(): string {
		return '' !== $this->email ? $this->email : 'client:' . substr( md5( $this->client_id ), 0, 12 );
	}

	/**
	 * Refresh token revogado ou expirado: apaga o que não serve mais.
	 *
	 * Sem isso o site tentaria o mesmo token morto a cada chamada e a tela
	 * continuaria dizendo "conectado", escondendo a única ação que resolve —
	 * reconectar a conta.
	 *
	 * @param \WP_Error $error Erro devolvido pelo GoogleClient.
	 * @return \WP_Error
	 */
	private function handle_error( \WP_Error $error ): \WP_Error {
		$data   = $error->get_error_data();
		$reason = is_array( $data ) ? (string) ( $data['reason'] ?? '' ) : '';

		if ( 'invalid_grant' !== $reason ) {
			return $error;
		}

		$revision = \Fator3\McpGoogle\Settings::revision();
		if ( is_wp_error( $revision ) || ! hash_equals( $this->refresh_token, Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) ) ) { return $error; }
		$saved = \Fator3\McpGoogle\Settings::save( array(), array(), array( Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES ), $revision );
		if ( ! $saved['success'] ) { return new \WP_Error( $saved['error_code'], $saved['message'] ); }

		return new \WP_Error(
			'f3_google_oauth_revoked',
			__( 'A Google recusou o refresh token (invalid_grant): ele foi revogado ou expirou. Se o app OAuth está em modo "Testing", isso acontece a cada 7 dias — publique o app ou use uma service account. Reconecte a conta em Ferramentas > MCP Google.', 'wp-mcp-google-fator3' ),
			is_array( $data ) ? $data : array()
		);
	}
}
