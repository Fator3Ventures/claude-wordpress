<?php
/** Credential preparation and explicit activation shared by every admin entry point. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Auth;
use Fator3\McpGoogle\{Options, Settings, Connections, Response};
use Fator3\McpGoogle\Http\GoogleClient;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Configuration {
    public const JSON_MAX_BYTES = 1048576;
    private static function fail( string $code, string $message ): array { return Response::fail( new \WP_Error( $code, $message ), array( 'persisted' => false, 'changed' => false ) ); }
    public static function import( string $json, ?string $method = null, bool $activate = false, ?string $expected = null ): array {
        if ( strlen( $json ) > self::JSON_MAX_BYTES ) { return self::fail( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' ); }
        $data = json_decode( $json, true );
        if ( ! is_array( $data ) ) { return self::fail( 'f3_google_credential_json', 'JSON inválido. Envie o arquivo de credenciais completo.' ); }
        $detected = ( $data['type'] ?? '' ) === 'service_account' ? 'service_account' : ( isset( $data['web'] ) ? 'oauth' : '' );
        if ( '' === $detected || ( null !== $method && $method !== $detected ) ) { return self::fail( 'f3_google_credential_type', 'O tipo do JSON não corresponde ao método selecionado. Abra a aba correspondente ao arquivo.' ); }
        if ( 'service_account' === $detected ) { return self::save_sa( $json, null, $activate, $expected ); }
        $web = $data['web'];
        if ( ! is_array( $web ) || ! is_string( $web['client_id'] ?? null ) || ! is_string( $web['client_secret'] ?? null ) || '' === $web['client_id'] || '' === $web['client_secret'] ) { return self::fail( 'f3_google_oauth_client_json', 'Envie o JSON de um cliente OAuth do tipo aplicativo Web.' ); }
        if ( ! in_array( OAuthFlow::redirect_uri(), (array) ( $web['redirect_uris'] ?? array() ), true ) ) { return self::fail( 'f3_google_oauth_redirect', 'Cadastre o callback exibido na aba OAuth no cliente Web e baixe o JSON atualizado.' ); }
        return self::save_oauth( $web['client_id'], $web['client_secret'], $expected );
    }
    public static function save_sa( string $json, ?string $subject = null, bool $activate = false, ?string $expected = null ): array {
        if ( ! current_user_can( Options::capability() ) ) { return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' ); }
        $revision = $expected ?? Settings::revision();
        if ( is_wp_error( $revision ) ) { return Response::fail( $revision ); }
        if ( strlen( $json ) > self::JSON_MAX_BYTES ) { return self::fail( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' ); }
        $values = array(); $secrets = array();
        if ( ! $activate && 'service_account' === Options::auth_mode() && ! Options::has_secret( Options::SA_JSON ) ) { $values[ Settings::AUTH_READY ] = false; }
        if ( null !== $subject ) {
            if ( '' !== $subject && ! is_email( $subject ) ) { return self::fail( 'f3_google_sa_subject', 'Informe um e-mail válido para o usuário do Workspace representado.' ); }
            $values[ Options::SA_SUBJECT ] = $subject;
        }
        if ( '' !== trim( $json ) ) {
            $key = ServiceAccount::validate_key( $json );
            if ( is_wp_error( $key ) ) { return Response::fail( $key ); }
            $secrets[ Options::SA_JSON ] = (string) wp_json_encode( $key );
        }
        if ( $activate ) { return self::activate( 'service_account', $revision, $values, $secrets ); }
        return Settings::save( $values, $secrets, array(), $revision );
    }
    public static function save_oauth( string $id, string $secret, ?string $expected = null ): array {
        if ( ! current_user_can( Options::capability() ) ) { return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' ); }
        $revision = $expected ?? Settings::revision();
        if ( is_wp_error( $revision ) ) { return Response::fail( $revision ); }
        if ( '' === trim( $id ) ) { return self::fail( 'f3_google_oauth_client', 'Informe o Client ID do aplicativo Web.' ); }
        $deletes = $id !== Options::get( Options::OAUTH_CLIENT_ID, '' ) || ( '' !== $secret && ! hash_equals( Options::get_secret( Options::OAUTH_CLIENT_SECRET ), $secret ) ) ? array( Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES ) : array();
        return Settings::save( array( Options::OAUTH_CLIENT_ID => $id ), '' !== $secret ? array( Options::OAUTH_CLIENT_SECRET => $secret ) : array(), $deletes, $revision );
    }
    public static function activate( string $mode, ?string $expected = null, array $values = array(), array $secrets = array() ): array {
        if ( ! current_user_can( Options::capability() ) ) { return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' ); }
        if ( ! in_array( $mode, Options::AUTH_MODES, true ) ) { return self::fail( 'f3_google_auth_mode', 'Método de autenticação inválido.' ); }
        if ( apply_filters( 'f3_mcp_google_auth_mode', $mode ) !== $mode ) { return self::fail( 'f3_google_auth_override', 'O método é controlado por código neste site. Ajuste o filtro antes de trocar.' ); }
        $revision = $expected ?? Settings::revision();
        if ( is_wp_error( $revision ) ) { return Response::fail( $revision ); }
        $current = Settings::revision();
        if ( is_wp_error( $current ) ) { return Response::fail( $current ); }
        if ( ! hash_equals( $revision, $current ) ) { return Settings::conflict(); }
        foreach ( 'oauth' === $mode ? array( Options::OAUTH_CLIENT_SECRET, Options::OAUTH_REFRESH_TOKEN ) : array( Options::SA_JSON ) as $name ) {
            if ( ! isset( $secrets[ $name ] ) && null !== ( $error = Options::secret_problem( $name ) ) ) { return Response::fail( $error ); }
        }
        $token = Connections::preview( $values + array( Options::AUTH_MODE => $mode ), static function() use ( $mode, $values, $secrets ) {
            $scopes = Credentials::scopes_for( 'any' );
            if ( 'service_account' === $mode ) {
                $key = ServiceAccount::validate_key( $secrets[ Options::SA_JSON ] ?? Options::get_secret( Options::SA_JSON ) );
                if ( is_wp_error( $key ) ) { return $key; }
                return ( new ServiceAccount( $key, (string) ( $values[ Options::SA_SUBJECT ] ?? Options::get( Options::SA_SUBJECT, '' ) ) ) )->get_access_token( $scopes ?: array( 'https://www.googleapis.com/auth/userinfo.email' ) );
            }
            $provider = OAuthUser::from_options();
            if ( is_wp_error( $provider ) ) { return $provider; }
            // Validation never deletes an active refresh token on invalid_grant.
            $result = GoogleClient::post( GoogleClient::HOST_TOKEN . '/token', array( 'grant_type' => 'refresh_token', 'client_id' => Options::get( Options::OAUTH_CLIENT_ID, '' ), 'client_secret' => Options::get_secret( Options::OAUTH_CLIENT_SECRET ), 'refresh_token' => Options::get_secret( Options::OAUTH_REFRESH_TOKEN ) ), array( 'auth' => false, 'form' => true, 'retries' => 0 ) );
            return is_wp_error( $result ) ? $result : ( $result['access_token'] ?? '' );
        } );
        if ( is_wp_error( $token ) ) { return Response::fail( $token, array( 'persisted' => false, 'authentication_validated' => false ) ); }
        if ( ! is_string( $token ) || '' === $token ) { return self::fail( 'f3_google_token', 'O Google não devolveu um token válido. O método anterior foi preservado.' ); }
        unset( $token );
        $values[ Options::AUTH_MODE ] = $mode;
        $values[ Settings::AUTH_READY ] = true;
        $result = Settings::save( $values, $secrets, array(), $revision );
        return $result + array( 'authentication_validated' => true, 'resource_access_validated' => false, 'auth_mode' => $mode );
    }
    public static function clear( string $mode, ?string $expected = null ): array {
        if ( ! current_user_can( Options::capability() ) ) { return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' ); }
        if ( ! in_array( $mode, Options::AUTH_MODES, true ) ) { return self::fail( 'f3_google_auth_mode', 'Método inválido.' ); }
        $names = 'service_account' === $mode ? array( Options::SA_JSON, Options::SA_SUBJECT ) : array( Options::OAUTH_CLIENT_ID, Options::OAUTH_CLIENT_SECRET, Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES );
        return Settings::save( array(), array(), $names, $expected );
    }
}
