<?php
/**
 * Fluxo de consentimento OAuth do administrador.
 *
 * Três passos: a tela manda o navegador para a Google com um `state` de uso
 * único; a Google devolve um `code` na rota REST de callback; o plugin troca o
 * `code` por um refresh token e o guarda cifrado.
 *
 * O `state` é o que impede um terceiro de forjar o retorno e plantar a conta
 * Google dele no site: é um valor aleatório gravado em transient por 10
 * minutos, apagado no primeiro uso. A rota de callback é necessariamente
 * pública (quem chega nela é o navegador redirecionado pela Google, sem nonce
 * do WordPress), então o `state` é a única prova de que aquele retorno
 * corresponde a um pedido feito daqui.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Auth;

use Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Connections;
use Fator3\McpGoogle\Settings;
use Fator3\McpGoogle\Lock;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class OAuthFlow {

    /** Initiator is recovered only from the validated server-owned state. */
    private static ?int $callback_user = null;

	public const NAMESPACE_REST = 'wp-mcp-google-fator3/v1';
	public const ROUTE_CALLBACK = '/oauth/callback';

	/** Prefixo do transient que guarda o state. */
	private const STATE_PREFIX = 'f3_mcp_google_oauth_state_';

	/** Validade do state, em segundos. */
	private const STATE_TTL = 600;

	private const AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';

	public static function init(): void {
		add_action( 'admin_post_f3_mcp_google_oauth_start', array( self::class, 'handle_start' ) );
		add_action( 'admin_post_f3_mcp_google_oauth_disconnect', array( self::class, 'handle_disconnect' ) );
		add_action( 'rest_api_init', array( self::class, 'register_route' ) );
	}

	public static function register_route(): void {
		if ( ! function_exists( 'register_rest_route' ) ) {
			return;
		}

		register_rest_route(
			self::NAMESPACE_REST,
			self::ROUTE_CALLBACK,
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'handle_callback' ),
				// Pública por construção: quem chega aqui é o navegador vindo da
				// Google, sem cookie de REST nem nonce. A autorização real é o
				// `state` de uso único conferido dentro do callback.
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * URI que precisa estar cadastrada no cliente OAuth do Google Cloud.
	 */
	public static function redirect_uri(): string {
		return rest_url( self::NAMESPACE_REST . self::ROUTE_CALLBACK );
	}

	/**
	 * @param string $state  Valor aleatório de uso único.
	 * @param array  $scopes Escopos a pedir.
	 */
	public static function authorize_url( string $state, array $scopes ): string {
		// `openid email` entra sempre para que a tela consiga mostrar QUAL conta
		// foi conectada; o e-mail sai do id_token, sem uma chamada a mais.
		$scopes = array_values( array_unique( array_merge( array( 'openid', 'email' ), $scopes ) ) );

		return add_query_arg(
			array(
				'client_id'              => rawurlencode( (string) Options::get( Options::OAUTH_CLIENT_ID, '' ) ),
				'redirect_uri'           => rawurlencode( self::redirect_uri() ),
				'response_type'          => 'code',
				'scope'                  => rawurlencode( implode( ' ', $scopes ) ),
				// offline + consent é o que faz a Google devolver refresh token;
				// sem `prompt=consent` uma segunda autorização volta sem ele.
				'access_type'            => 'offline',
				'prompt'                 => 'consent',
				'include_granted_scopes' => 'true',
				'state'                  => rawurlencode( $state ),
			),
			self::AUTH_ENDPOINT
		);
	}

    public static function handle_start(): void {
        if ( ! current_user_can( Options::capability() ) ) { wp_die( 'Permissão insuficiente.' ); }
        check_admin_referer( 'f3_mcp_google_oauth_start' );
        if ( is_wp_error( Connections::select( self::posted_connection() ) ) ) { self::back( 'oauth_state' ); return; }
        $revision = Settings::revision();
        if ( is_wp_error( $revision ) ) { Admin::require_saved( Response::fail( $revision ) ); return; }
        if ( null !== Admin::posted_revision() && ! hash_equals( $revision, Admin::posted_revision() ) ) { Admin::require_saved( Settings::conflict() ); return; }
        if ( '' === trim( (string) Options::get( Options::OAUTH_CLIENT_ID, '' ) ) || '' === Options::get_secret( Options::OAUTH_CLIENT_SECRET ) ) { self::back( 'oauth_missing_client' ); return; }
        $state = bin2hex( random_bytes( 32 ) );
        if ( ! set_transient( self::STATE_PREFIX . $state, self::state_record(), self::STATE_TTL ) ) { Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_oauth_state_write', 'Não foi possível iniciar a autorização. Tente novamente.' ) ) ); return; }
        wp_redirect( self::authorize_url( $state, Credentials::scopes_for( 'any' ) ) );
        exit;
    }

    /** Record is server-owned; no credential is put into the OAuth URL. */
    public static function state_record(): array {
        $revision = Settings::revision();
        return array( 'user' => get_current_user_id(), 'connection_id' => Connections::id(), 'client_id' => Options::get( Options::OAUTH_CLIENT_ID, '' ), 'revision' => is_string( $revision ) ? $revision : '', 'intent' => 'prepare' );
    }

    public static function handle_callback( \WP_REST_Request $request ) {
        $result = self::complete( $request );
        if ( empty( $result['success'] ) && ! isset( $result['oauth_status'] ) ) { Admin::require_saved( $result, self::$callback_user ); return; }
        self::back( $result['oauth_status'] ?? 'oauth_ok' );
    }

    public static function complete( \WP_REST_Request $request ): array {
        self::$callback_user = null;
        $invalid = static fn( string $status ) => Response::fail( new \WP_Error( 'f3_google_' . $status, 'A autorização não foi concluída. Inicie a conexão novamente.' ), array( 'oauth_status' => $status ) );
        $state = self::param( $request, 'state' );
        if ( ! preg_match( '/^[a-f0-9]{16,128}\z/', $state ) ) { return $invalid( 'oauth_state' ); }
        $lock = Lock::acquire( 'oauth-state:' . $state );
        if ( null === $lock ) { return $invalid( 'oauth_state' ); }
        try {
            $stored = get_transient( self::STATE_PREFIX . $state );
            if ( ! is_array( $stored ) || ( $stored['intent'] ?? '' ) !== 'prepare' || ! is_string( $stored['revision'] ?? null ) || '' === $stored['revision'] ) { delete_transient( self::STATE_PREFIX . $state ); return $invalid( 'oauth_state' ); }
            if ( ! delete_transient( self::STATE_PREFIX . $state ) ) { return $invalid( 'oauth_state' ); }
        } finally { Lock::release( $lock ); }
        if ( is_wp_error( Connections::select( (string) ( $stored['connection_id'] ?? '' ) ) ) ) { return $invalid( 'oauth_state' ); }
        $starter = (int) ( $stored['user'] ?? 0 );
        if ( ! user_can( $starter, Options::capability() ) || ( $stored['client_id'] ?? '' ) !== Options::get( Options::OAUTH_CLIENT_ID, '' ) ) { return $invalid( 'oauth_state' ); }
        self::$callback_user = $starter;
        $revision = Settings::revision();
        if ( is_wp_error( $revision ) ) { return Response::fail( $revision ); }
        if ( ! hash_equals( $revision, $stored['revision'] ) ) { return Settings::conflict(); }
        if ( '' !== self::param( $request, 'error' ) ) { return $invalid( 'oauth_denied' ); }
        $code = self::param( $request, 'code' );
        if ( '' === $code ) { return $invalid( 'oauth_state' ); }
        $secret = Options::get_secret( Options::OAUTH_CLIENT_SECRET );
        if ( '' === $secret ) { return $invalid( 'oauth_missing_client' ); }
        $response = GoogleClient::post( GoogleClient::HOST_TOKEN . '/token', array( 'grant_type' => 'authorization_code', 'code' => $code, 'client_id' => $stored['client_id'], 'client_secret' => $secret, 'redirect_uri' => self::redirect_uri() ), array( 'auth' => false, 'form' => true, 'retries' => 0, 'mode' => 'write' ) );
        if ( is_wp_error( $response ) ) { return Response::fail( $response ); }
        $refresh = $response['refresh_token'] ?? '';
        if ( ! is_string( $refresh ) || '' === $refresh ) { return $invalid( 'oauth_no_refresh' ); }
        if ( ! user_can( $starter, Options::capability() ) ) { return $invalid( 'oauth_state' ); }
        $granted = trim( (string) ( $response['scope'] ?? '' ) );
        $email = self::email_from_id_token( (string) ( $response['id_token'] ?? '' ) );
        $saved = Settings::save( array( Options::OAUTH_SCOPES => '' !== $granted ? explode( ' ', $granted ) : array(), Options::OAUTH_EMAIL => $email ), array( Options::OAUTH_REFRESH_TOKEN => $refresh ), array(), $stored['revision'] );
        if ( ! $saved['success'] ) { return $saved; }
        Audit::log( 'oauth:prepared', Connections::id(), array( 'status' => 'ok' ) );
        return $saved + array( 'oauth_status' => 'oauth_ok', 'activated' => false );
    }

    public static function handle_disconnect(): void {
        if ( ! current_user_can( Options::capability() ) ) { wp_die( 'Permissão insuficiente.' ); }
        check_admin_referer( 'f3_mcp_google_oauth_disconnect' );
        if ( is_wp_error( Connections::select( self::posted_connection() ) ) ) { self::back( 'oauth_state' ); return; }
        $revoke = isset( $_POST['revoke'] ) && '1' === $_POST['revoke'];
        $result = self::disconnect( $revoke, Admin::posted_revision() );
        if ( empty( $result['success'] ) ) {
            if ( ! empty( $result['local_disconnected'] ) ) { self::back( 'oauth_revoke_failed' ); return; }
            Admin::require_saved( $result ); return;
        }
        self::back( $revoke ? 'oauth_revoked' : 'oauth_disconnected' );
    }

    public static function disconnect( bool $revoke = false, ?string $expected = null ): array {
        if ( ! current_user_can( Options::capability() ) ) { return Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão insuficiente.' ) ); }
        $revision = Settings::revision();
        if ( is_wp_error( $revision ) ) { return Response::fail( $revision ); }
        if ( null !== $expected && ! hash_equals( $revision, $expected ) ) { return Settings::conflict(); }
        $refresh = Options::get_secret( Options::OAUTH_REFRESH_TOKEN );
        $remote = null;
        if ( $revoke && '' !== $refresh ) { $remote = GoogleClient::post( GoogleClient::HOST_TOKEN . '/revoke', array( 'token' => $refresh ), array( 'auth' => false, 'form' => true, 'retries' => 0, 'mode' => 'write' ) ); }
        $local = Settings::save( array(), array(), array( Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES ), $revision );
        if ( ! $local['success'] ) { return $local + array( 'remote_revoked' => $revoke && null !== $remote && ! is_wp_error( $remote ) ); }
        Audit::log( $revoke ? 'oauth:revoke' : 'oauth:disconnect', Connections::id(), array( 'status' => is_wp_error( $remote ) ? 'error' : 'ok' ) );
        $state = array( 'local_disconnected' => true, 'remote_revoked' => $revoke ? ( null !== $remote && ! is_wp_error( $remote ) ) : null, 'revocation_requested' => $revoke );
        return is_wp_error( $remote ) ? Response::fail( $remote, $state ) : Response::ok( $state, 'Desconexão local concluída.' );
    }

	private static function posted_connection(): string {
		return isset( $_POST['connection_id'] ) && is_string( $_POST['connection_id'] ) ? sanitize_key( $_POST['connection_id'] ) : 'default';
	}

	/**
	 * Um parâmetro da requisição como string, ou '' quando não for escalar.
	 *
	 * @param \WP_REST_Request $request Requisição.
	 * @param string           $key     Nome do parâmetro.
	 */
	private static function param( \WP_REST_Request $request, string $key ): string {
		$value = $request->get_param( $key );

		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	/**
	 * O `id_token` vem pelo canal TLS direto do endpoint de token da Google, em
	 * resposta a uma troca autenticada com o client secret — por isso o payload
	 * pode ser lido sem verificar a assinatura. Só o e-mail é aproveitado, e ele
	 * serve apenas para exibição.
	 */
	private static function email_from_id_token( string $id_token ): string {
		$parts = explode( '.', $id_token );
		if ( 3 !== count( $parts ) ) {
			return '';
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
		$json = base64_decode( strtr( $parts[1], '-_', '+/' ), false );
		if ( ! is_string( $json ) ) {
			return '';
		}

		$claims = json_decode( $json, true );
		if ( ! is_array( $claims ) || empty( $claims['email'] ) ) {
			return '';
		}

		$email = sanitize_email( (string) $claims['email'] );

		return is_email( $email ) ? $email : '';
	}

	/**
	 * Volta para a tela de administração com um código de estado.
	 *
	 * Código, não mensagem: o texto sai da tabela do Admin, para não haver
	 * conteúdo controlado por terceiro na query string.
	 */
	private static function back( string $status ): void {
		// `Admin::url()` é o único lugar que monta esta URL, e `wp_safe_redirect`
		// só aceita destinos do próprio host: não há como um parâmetro do
		// callback virar redirecionamento para fora.
		wp_safe_redirect( Admin::url( $status, 'connection', 'oauth' ) );
		exit;
	}
}
