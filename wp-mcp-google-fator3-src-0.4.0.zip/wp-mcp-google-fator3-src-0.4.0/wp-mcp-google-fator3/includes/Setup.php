<?php
/** Connection setup and repeatable local resource bindings for deployment agents. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Setup {
	public const LEVELS = array( 'ga' => array( 'read', 'write', 'admin' ), 'ads' => array( 'read', 'write' ), 'gsc' => array( 'read', 'write' ), 'siteverification' => array( 'write' ), 'sheets' => array( 'read', 'write' ), 'drive' => array( 'write' ) );
	public const BINDING_RULES = array(
		'ga_property_id' => array( 'pattern' => '~^(properties/)?[0-9]+$~D', 'service' => 'ga' ),
		'ads_customer_id' => array( 'pattern' => '/^[0-9]{10}$/D', 'service' => 'ads' ),
		'gsc_site_url' => array( 'validator' => 'SearchConsole\\Api::site', 'service' => 'gsc' ),
		'spreadsheet_id' => array( 'pattern' => '/^[A-Za-z0-9_-]+$/D', 'service' => 'sheets' ),
		'sitemap_url' => array( 'validator' => 'https_url_without_credentials_or_fragment', 'service' => 'gsc' ),
	);
	public static function services_schema(): array {
		$properties = array();
		foreach ( self::LEVELS as $service => $levels ) { $properties[ $service ] = array( 'type' => 'string', 'enum' => $levels ); }
		return array( 'type' => 'object', 'properties' => $properties, 'additionalProperties' => false );
	}
	public static function bindings_schema(): array {
		$properties = array();
		foreach ( self::BINDING_RULES as $key => $rule ) {
			$schema = array( 'type' => 'string', 'description' => 'Identificador existente; string vazia limpa o vínculo.' );
			if ( isset( $rule['pattern'] ) ) { $schema['anyOf'] = array( array( 'type' => 'string', 'enum' => array( '' ) ), array( 'type' => 'string', 'pattern' => substr( $rule['pattern'], 1, strrpos( $rule['pattern'], $rule['pattern'][0] ) - 1 ) ) ); }
			$properties[ $key ] = $schema;
		}
		return array( 'type' => 'object', 'properties' => $properties, 'additionalProperties' => false );
	}

	public static function schema(): array {
		return array( 'expected_revision' => array( 'type' => 'string', 'description' => 'Revisão consultada no contrato. Divergência recusa a gravação.' ), 'services' => self::services_schema() + array( 'description' => 'Seleção completa de serviços/perfis; omitir mantém a seleção.' ), 'bindings' => self::bindings_schema() + array( 'description' => 'IDs existentes; campos omitidos são preservados.' ), 'discover' => array( 'type' => 'boolean' ), 'validate_access' => array( 'type' => 'boolean', 'description' => 'Padrão true: testa recursos indicados antes de salvar. false permite preparar configuração antes do consentimento.' ) );
	}
	public static function plan( array $input ): array {
		$values = array();
		if ( isset( $input['services'] ) ) {
			if ( ! is_array( $input['services'] ) ) { return self::invalid( 'services deve ser objeto.' ); }
			foreach ( $input['services'] as $service => $level ) {
				if ( ! is_string( $level ) || ! in_array( $level, self::LEVELS[ $service ] ?? array(), true ) ) { return self::invalid( 'Serviço ou perfil inválido: ' . (string) $service ); }
			}
			$values[ Connections::SERVICES ] = $input['services'];
			$values[ Options::GA_ENABLED ] = isset( $input['services']['ga'] );
			$values[ Options::ADS_ENABLED ] = isset( $input['services']['ads'] );
		}
		if ( isset( $input['bindings'] ) ) {
			if ( ! is_array( $input['bindings'] ) ) { return self::invalid( 'bindings deve ser objeto.' ); }
			$bindings = array();
			foreach ( $input['bindings'] as $key => $value ) {
				if ( ! is_string( $value ) || ! array_key_exists( $key, self::BINDING_RULES ) ) { return self::invalid( 'Vínculo inválido: ' . (string) $key ); }
				$value = trim( $value );
				if ( '' !== $value ) {
					if ( isset( self::BINDING_RULES[ $key ]['pattern'] ) && ! preg_match( self::BINDING_RULES[ $key ]['pattern'], $value ) ) { return self::invalid( $key . ' inválido.' ); }
					if ( 'gsc_site_url' === $key && is_wp_error( SearchConsole\Api::site( $value ) ) ) { return self::invalid( 'gsc_site_url inválido.' ); }
					if ( 'sitemap_url' === $key && ( ! filter_var( $value, FILTER_VALIDATE_URL ) || 'https' !== wp_parse_url( $value, PHP_URL_SCHEME ) || wp_parse_url( $value, PHP_URL_USER ) || wp_parse_url( $value, PHP_URL_FRAGMENT ) ) ) { return self::invalid( 'sitemap_url exige HTTPS sem credenciais ou fragmento.' ); }
				}
				$bindings[ $key ] = $value;
			}
			$values[ Connections::BINDINGS ] = array_merge( (array) Options::get( Connections::BINDINGS, array() ), $bindings );
			if ( isset( $bindings['ga_property_id'] ) ) { $values[ Options::GA_DEFAULT_PROPERTY ] = preg_replace( '~^properties/~', '', $bindings['ga_property_id'] ); }
		}
		$changes = array();
		foreach ( $values as $key => $value ) {
			$old = Options::get( $key, null );
			$changes[] = array( 'option' => $key, 'before' => $old, 'after' => $value, 'changed' => $old !== $value );
		}
		$out = Response::ok( array( 'connection_id' => Connections::id(), 'changes' => $changes, 'values' => $values, 'redirect_uri' => Auth\OAuthFlow::redirect_uri(), 'resource_creation' => false, 'access_validated' => false ), 'Plano de configuração local; usa IDs de recursos existentes.' );
		if ( ! empty( $input['discover'] ) ) { $out['discovery'] = Unified\Query::accounts( array( 'connector' => 'all', 'refresh' => true ) ); }
		return $out;
	}
	public static function apply( array $input ): array {
		$revision = Settings::revision();
		if ( is_wp_error( $revision ) ) { return Response::fail( $revision ); }
		if ( isset( $input['expected_revision'] ) && $input['expected_revision'] !== $revision ) { return Settings::conflict(); }
		$plan = self::plan( $input );
		if ( ! $plan['success'] ) { return $plan; }
		$bindings = $plan['values'][ Connections::BINDINGS ] ?? array();
		$probe = null;
		if ( ! empty( $bindings ) && ( $input['validate_access'] ?? true ) ) {
			$services = array();
			foreach ( array( 'ga_property_id' => 'ga', 'ads_customer_id' => 'ads', 'gsc_site_url' => 'gsc', 'spreadsheet_id' => 'sheets' ) as $key => $service ) { if ( ! empty( $bindings[ $key ] ) ) { $services[] = $service; } }
			if ( $services ) {
				$probe = Connections::preview( $plan['values'], static fn() => Preflight::run( array( 'bindings' => $bindings, 'services' => $services ) ) );
				if ( ! $probe['success'] || ! $probe['all_checks_passed'] ) { return Response::fail( new \WP_Error( 'f3_google_setup_access', 'Acesso aos recursos não confirmado; configuração não aplicada.' ), array( 'preflight' => $probe ) ); }
			}
		}
		$saved = Settings::save( $plan['values'], array(), array(), $revision );
		if ( ! $saved['success'] ) { return $saved; }
		Auth\Credentials::invalidate_cache();
		return Response::ok( array( 'persisted' => true, 'changed' => $saved['changed'] ?? true, 'revision' => $saved['revision'] ?? null, 'changes' => $plan['changes'], 'access_validated' => null !== $probe && $probe['all_checks_passed'], 'preflight' => $probe, 'scopes_requested' => Auth\Credentials::scopes_for( 'any' ) ), 'oauth' === Options::auth_mode() ? 'Configuração persistida. Novos escopos exigem autorização da conta Google.' : 'Configuração persistida. Confira os acessos da Service Account aos recursos selecionados.' );
	}
	private static function invalid( string $message ): array { return Response::fail( new \WP_Error( 'f3_google_setup_input', $message ) ); }
	public static function register(): void {
		foreach ( array( 'plan-configuration' => 'plan', 'configure' => 'apply' ) as $route => $method ) {
			Ability::register( 'google/' . $route, 'any', array( 'label' => 'Google: ' . $route, 'description' => 'Planeja ou aplica configuração local verificada com serviços e recursos existentes; não cria propriedades Google.', 'mode' => 'apply' === $method ? 'write' : 'read', 'input_schema' => array( 'properties' => self::schema() ), 'callback' => array( self::class, $method ) ) );
		}
		Ability::register( 'google/preflight', 'any', array( 'label' => 'Google: testar acessos', 'description' => 'Leituras reais por serviço e recurso. Distingue passed, failed, skipped e not_configured.', 'input_schema' => array( 'properties' => array( 'bindings' => array( 'type' => 'object' ), 'services' => array( 'type' => 'array', 'items' => array( 'type' => 'string', 'enum' => array_keys( self::LEVELS ) ) ) ) ), 'callback' => static function( array $input ): array { $r = Preflight::run( $input ); return $r['success'] ? Response::ok( $r ) : Response::fail( new \WP_Error( 'f3_google_preflight_failed', 'Há acessos não confirmados.' ), $r ); } ) );
		Ability::register( 'google/list-connections', 'any', array( 'label' => 'Google: conexões', 'description' => 'Lista conexões e vínculos sem segredos.', 'callback' => static function(): array { $out = array(); foreach ( Connections::registry() as $id => $meta ) { $out[] = Connections::run( $id, static fn() => array( 'connection_id' => $id, 'label' => $meta['label'], 'configured' => Auth\Credentials::is_configured(), 'services' => Options::get( Connections::SERVICES, null ), 'bindings' => Options::get( Connections::BINDINGS, array() ) ) ); } return Response::ok( array( 'connections' => $out ) ); } ) );
		Ability::register( 'google/create-connection', 'any', array( 'label' => 'Google: criar conexão', 'description' => 'Cria uma conexão local vazia para configuração no painel.', 'mode' => 'write', 'input_schema' => array( 'properties' => array( 'id' => array( 'type' => 'string' ), 'label' => array( 'type' => 'string' ) ), 'required' => array( 'id', 'label' ) ), 'callback' => static fn( array $input ) => Connections::create( (string) ( $input['id'] ?? '' ), (string) ( $input['label'] ?? '' ) ) ) );
		Ability::register( 'google/disconnect', 'any', array( 'label' => 'Google: desconectar OAuth', 'description' => 'Remove tokens locais mantendo o cliente. revoke=true revoga também a autorização do usuário no projeto Google, afetando outros sites.', 'mode' => 'write', 'input_schema' => array( 'properties' => array( 'revoke' => array( 'type' => 'boolean', 'default' => false ) ) ), 'callback' => static fn( array $input ) => Auth\OAuthFlow::disconnect( ! empty( $input['revoke'] ) ) ) );
	}
}
