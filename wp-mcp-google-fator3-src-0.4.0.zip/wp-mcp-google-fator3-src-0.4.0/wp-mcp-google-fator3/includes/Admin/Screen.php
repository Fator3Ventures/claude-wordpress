<?php
/** Server-rendered admin screens; progressive enhancement is optional. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{Admin, Options, Settings, Connections, Configuration, Setup, Plugin, Crypto, Audit};
use Fator3\McpGoogle\Auth\{Credentials, OAuthFlow, ServiceAccount};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Screen {
    private static array $failed_values = array();
    private static int $counter = 0;
    public static function render(): void {
        self::$failed_values = array();
        echo '<div class="wrap f3-google"><header class="f3-heading"><div><p class="f3-eyebrow">FATOR3 · INTEGRAÇÕES</p><h1>Google</h1><p>Configure a identidade, os serviços e os recursos utilizados por esta conexão.</p></div><span class="f3-version">' . esc_html( F3_MCP_GOOGLE_VERSION ) . '</span></header>';
        self::notice();
        $registry = Connections::registry();
        echo '<div class="f3-context"><form method="get" action="' . esc_url( admin_url( 'tools.php' ) ) . '"><input type="hidden" name="page" value="' . esc_attr( Admin::SLUG ) . '"><input type="hidden" name="section" value="' . esc_attr( Admin::section() ) . '"><label for="f3-connection"><strong>Conexão</strong></label> <select id="f3-connection" name="connection_id">';
        foreach ( $registry as $id => $meta ) { echo '<option value="' . esc_attr( $id ) . '"' . selected( Connections::id(), $id, false ) . '>' . esc_html( $meta['label'] . ' (' . $id . ')' ) . '</option>'; }
        echo '</select> <button class="button">Abrir</button></form><span>As configurações de autenticação e recursos pertencem à conexão selecionada.</span></div>';
        $provider = Credentials::current();
        $identity = is_wp_error( $provider ) ? ( 'f3_google_auth_not_active' === $provider->get_error_code() ? 'Credencial salva; ativação pendente' : 'Configure a credencial na área Conexão' ) : (string) ( $provider->describe()['identity'] ?? 'Credencial salva' );
        echo '<dl class="f3-summary"><div><dt>Método selecionado</dt><dd>' . esc_html( self::method_label( Options::auth_mode() ) ) . '</dd></div><div><dt>Identidade</dt><dd>' . esc_html( $identity ) . '</dd></div><div><dt>Chamadas Google</dt><dd>' . ( Options::is_enabled() ? 'Permitidas' : 'Bloqueadas neste site' ) . '</dd></div></dl>';
        echo '<nav class="f3-navigation" aria-label="Configuração Google">';
        foreach ( Admin::SECTIONS as $id => $label ) { echo '<a href="' . esc_url( Admin::url( '', $id ) ) . '"' . ( $id === Admin::section() ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>'; }
        echo '</nav><main id="f3-main">';
        switch ( Admin::section() ) { case 'services': self::services(); break; case 'diagnostics': self::diagnostics(); break; case 'advanced': self::advanced(); break; default: self::connection(); }
        echo '</main><p id="f3-live" class="screen-reader-text" role="status" aria-live="polite"></p></div>';
    }
    private static function method_label( string $mode ): string { return 'oauth' === $mode ? 'Conta Google · OAuth' : 'Service Account'; }
    private static function notice(): void {
        $status = isset( $_GET['f3_status'] ) && is_string( $_GET['f3_status'] ) ? sanitize_key( $_GET['f3_status'] ) : '';
        $messages = array( 'saved' => 'Configuração salva.', 'unchanged' => 'Nenhuma alteração necessária.', 'sa_saved' => 'Chave salva e cifrada.', 'sa_cleared' => 'Chave removida.', 'activated' => 'Método ativado. Confira o acesso aos recursos em Diagnóstico.', 'created' => 'Conexão criada. Configure a Service Account para começar.', 'tested' => 'Verificação concluída. Confira o resultado de cada item abaixo.', 'discovered' => 'Consulta de recursos concluída. Confira os resultados antes de selecionar.', 'log_cleared' => 'Auditoria limpa.', 'oauth_ok' => 'Autorização OAuth salva. Use a ação “Usar OAuth” para ativá-la quando necessário.', 'oauth_disconnected' => 'Autorização OAuth removida desta conexão.', 'oauth_revoked' => 'Autorização removida desta conexão e revogada no Google.', 'oauth_revoke_failed' => 'A desconexão local foi concluída; a revogação no Google falhou.', 'oauth_denied' => 'O consentimento não foi concedido. O método anterior foi preservado.', 'oauth_state' => 'Esta autorização expirou ou não corresponde à configuração atual. Inicie a conexão novamente.', 'oauth_missing_client' => 'Salve o Client ID e o Client secret antes de conectar.', 'oauth_no_refresh' => 'O Google não devolveu autorização para acesso contínuo. Inicie a autorização novamente e confira o aplicativo OAuth.' );
        if ( 'save_failed' === $status ) {
            $data = get_transient( Admin::feedback_key( 'failure' ) );
            if ( is_array( $data ) ) {
                self::$failed_values = (array) ( $data['values'] ?? array() );
                echo '<div class="notice notice-error" role="alert"><p><strong>Não foi possível salvar.</strong> ' . esc_html( $data['message'] ?? '' ) . '</p><p><code>' . esc_html( $data['code'] ?? '' ) . '</code></p>';
                if ( ! empty( $data['rollback_failed'] ) ) { echo '<p>A restauração não foi concluída. Confira os valores persistidos em Avançado antes de repetir a operação.</p>'; }
                echo '</div>';
            } else { echo '<div class="notice notice-error"><p>Não foi possível salvar. Recarregue e tente novamente.</p></div>'; }
        } elseif ( isset( $messages[ $status ] ) ) {
            $error = in_array( $status, array( 'oauth_revoke_failed', 'oauth_denied', 'oauth_state', 'oauth_missing_client', 'oauth_no_refresh' ), true );
            echo '<div class="notice notice-' . ( $error ? 'error' : 'success' ) . ' is-dismissible" role="status"><p>' . esc_html( $messages[ $status ] ) . '</p></div>';
        }
    }
    public static function form( string $action, string $extra = '' ): void {
        echo '<form class="f3-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" ' . $extra . '>';
        foreach ( array( 'action' => $action, 'connection_id' => Connections::id(), 'section' => Admin::section(), 'method' => Admin::method() ) as $name => $value ) { self::hidden( $name, $value ); }
        $revision = Settings::revision();
        self::hidden( 'expected_revision', is_string( $revision ) ? $revision : 'unreadable' );
        wp_nonce_field( $action );
    }
    private static function hidden( string $name, string $value ): void { echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">'; }
    private static function button( string $label = 'Salvar', string $name = '', string $value = '', bool $primary = true ): void {
        echo '<button type="submit" class="button' . ( $primary ? ' button-primary' : '' ) . '"' . ( '' !== $name ? ' name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' : '' ) . '>' . esc_html( $label ) . '</button>';
    }
    private static function field( string $name, string $label, string $value, string $help, string $type = 'text', string $attributes = '' ): void {
        if ( isset( self::$failed_values[ $name ] ) && is_scalar( self::$failed_values[ $name ] ) && 'password' !== $type ) { $value = wp_unslash( (string) self::$failed_values[ $name ] ); }
        $id = 'f3-field-' . $name;
        echo '<div class="f3-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><input id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( 'password' === $type ? '' : $value ) . '" aria-describedby="' . esc_attr( $id ) . '-help" ' . $attributes . '><p class="description" id="' . esc_attr( $id ) . '-help">' . esc_html( $help ) . '</p></div>';
    }
    private static function option( string $id, string $type = 'text', string $attributes = '' ): void {
        $meta = Fields::metadata()[ $id ];
        self::field( $id, $meta['label'], (string) Options::get( 'f3_mcp_google_' . $id, '' ), $meta['description'], $type, $attributes );
    }
    private static function secret_status( string $name ): string {
        $state = Options::stored( Options::storage_name( $name ) );
        if ( ! $state['success'] ) { return 'Falha de leitura'; }
        if ( ! $state['exists'] || '' === $state['value'] ) { return 'Não configurado'; }
        return null === Options::secret_problem( $name ) ? 'Salvo e cifrado' : 'Salvo, mas ilegível';
    }
    private static function copy( string $text, string $label = 'Copiar' ): void {
        $id = 'f3-copy-' . ++self::$counter;
        echo '<span class="f3-copy"><code id="' . esc_attr( $id ) . '">' . esc_html( $text ) . '</code><button type="button" class="button f3-copy-button" data-copy-target="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</button></span>';
    }
    private static function details( string $label, array $data ): void {
        $id = 'f3-json-' . ++self::$counter;
        echo '<details class="f3-details"><summary>' . esc_html( $label ) . '</summary><button type="button" class="button f3-copy-button" data-copy-target="' . esc_attr( $id ) . '">Copiar JSON</button><pre id="' . esc_attr( $id ) . '">' . esc_html( wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details>';
    }
    private static function connection(): void {
        echo '<section class="f3-card"><h2>Autenticação</h2><p>Escolha uma forma de autenticação para esta conexão. Service Account é a opção padrão. Configure e ative o método escolhido. Todos os serviços desta conexão utilizarão essa identidade.</p><nav class="f3-methods" aria-label="Método de autenticação">';
        foreach ( array( 'service_account' => 'Service Account · padrão', 'oauth' => 'Conta Google · OAuth' ) as $mode => $label ) {
            echo '<a href="' . esc_url( Admin::url( '', 'connection', $mode ) ) . '"' . ( Admin::method() === $mode ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . ( Options::auth_mode() === $mode && ! is_wp_error( Credentials::current() ) ? ' <span class="f3-badge">Em uso</span>' : '' ) . '</a>';
        }
        echo '</nav><p class="description">Abrir uma aba permite preparar as credenciais desse método. A ativação tem uma ação própria.</p>';
        if ( ! Crypto::available() ) { echo '<div class="notice notice-error inline"><p>O servidor precisa de libsodium ou OpenSSL com AES-256-GCM para cifrar as credenciais. Nenhum segredo será salvo até corrigir este requisito.</p></div>'; }
        if ( 'service_account' === Admin::method() ) { self::service_account(); } else { self::oauth(); }
        echo '</section><details class="f3-card"><summary>Adicionar conexão</summary><p>' . esc_html( Fields::metadata()['connections']['description'] ) . '</p>';
        self::form( 'f3_google_setup_create' );
        self::field( 'new_id', 'ID da conexão', '', 'Identificador estável: começa com letra minúscula e aceita letras, números, hífen e sublinhado. Até 40 caracteres.', 'text', 'required pattern="[a-z][a-z0-9_-]{0,39}" maxlength="40"' );
        self::field( 'label', 'Nome da conexão', '', 'Nome exibido no seletor. Exemplo: Operação Fator3. Até 100 bytes.', 'text', 'required maxlength="100"' );
        self::button( 'Criar conexão' ); echo '</form></details>';
    }
    private static function service_account(): void {
        echo '<ol class="f3-steps"><li>Importar chave</li><li>Conceder acesso</li><li>Selecionar recursos</li><li>Testar</li></ol>';
        echo '<p><strong>Chave:</strong> ' . esc_html( self::secret_status( Options::SA_JSON ) ) . '</p>';
        $key = ServiceAccount::validate_key( Options::get_secret( Options::SA_JSON ) );
        if ( ! is_wp_error( $key ) ) {
            echo '<div class="f3-identity"><p><strong>E-mail para conceder acesso</strong></p>'; self::copy( (string) $key['client_email'], 'Copiar e-mail' );
            echo '<p class="description">Projeto: ' . esc_html( (string) ( $key['project_id'] ?? 'não informado' ) ) . ' · ID da chave: ' . esc_html( (string) ( $key['private_key_id'] ?? 'não informado' ) ) . '</p></div>';
            if ( 'service_account' !== Options::auth_mode() ) { echo '<p><span class="f3-badge">Salva, fora de uso</span></p>'; }
        }
        echo '<details class="f3-details"><summary>Como criar o projeto e a chave no Google Cloud</summary><p>Crie ou reutilize uma Service Account no projeto, habilite as APIs dos serviços utilizados e baixe uma chave JSON. Depois conceda acesso ao e-mail dessa conta nos recursos Google.</p><p><a href="https://console.cloud.google.com/iam-admin/serviceaccounts" target="_blank" rel="noopener noreferrer">Abrir contas de serviço no Google Cloud</a></p><p>O script de referência acompanha este plugin e deve ser executado no Google Cloud Shell. Leia as variáveis antes de executar; a execução pode criar recursos e uma chave. A versão revisada permite reutilização e separa criação de rotação. O original permanece no pacote como referência histórica.</p>';
        self::form( 'f3_mcp_google_script', 'data-no-dirty="true"' ); self::button( 'Baixar script de referência', '', '', false ); echo '</form></details>';
        self::import_form( 'service_account' );
        echo '<details class="f3-details"><summary>Colar JSON ou ajustar delegação</summary>';
        self::form( 'f3_mcp_google_save_sa' );
        echo '<div class="f3-field"><label for="f3-sa-json">Chave JSON</label><textarea id="f3-sa-json" name="sa_json" rows="7" spellcheck="false" autocomplete="off" aria-describedby="f3-sa-json-help"></textarea><p id="f3-sa-json-help" class="description">' . esc_html( Fields::metadata()['sa_json']['description'] ) . '</p></div>';
        echo '<details class="f3-details"' . ( '' !== Options::get( Options::SA_SUBJECT, '' ) ? ' open' : '' ) . '><summary>Delegação avançada do Workspace</summary>';
        self::option( 'sa_subject', 'email' ); echo '</details><div class="f3-actions">'; self::button(); self::button( 'Salvar e usar Service Account', 'activate', '1', false ); echo '</div></form></details>';
        if ( ! is_wp_error( $key ) ) { self::activation( 'service_account' ); }
        echo '<h3>Conceder acesso aos serviços</h3><p>O e-mail da conta de serviço precisa receber acesso em cada conta, propriedade ou arquivo utilizado. As permissões do projeto Cloud não concedem esse acesso automaticamente.</p>';
        foreach ( Fields::effective_services() as $id => $level ) {
            $meta = Fields::services()[ $id ] ?? null; if ( ! $meta ) { continue; }
            echo '<details class="f3-details"><summary>' . esc_html( $meta['label'] ) . '</summary><p>' . esc_html( $meta['help'] ) . '</p><a href="' . esc_url( $meta['url'] ) . '" target="_blank" rel="noopener noreferrer">Abrir ' . esc_html( $meta['label'] ) . '</a></details>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( Admin::url( '', 'services' ) ) . '">Selecionar serviços e recursos</a></p>';
        self::remove_form( 'service_account' );
    }
    private static function import_form( string $mode ): void {
        self::form( 'f3_google_setup_import' );
        echo '<div class="f3-field"><label for="f3-file">' . ( 'oauth' === $mode ? 'JSON do cliente OAuth Web' : 'Importar chave JSON' ) . '</label><input type="file" name="credential" id="f3-file" accept="application/json,.json" required aria-describedby="f3-file-help"><p class="description" id="f3-file-help">Arquivo de até 1 MiB. O conteúdo é validado e cifrado; o arquivo não é publicado na biblioteca de mídia. Importar preserva o método selecionado para execução.</p></div><div class="f3-actions">';
        $first = 'service_account' === $mode && ! Credentials::is_configured();
        self::button( 'Salvar', '', '', ! $first );
        if ( 'service_account' === $mode ) { self::button( 'Salvar e usar Service Account', 'activate', '1', $first ); }
        echo '</div></form>';
    }
    private static function activation( string $mode ): void {
        self::form( 'f3_mcp_google_save_mode' ); self::hidden( 'auth_mode', $mode );
        echo '<div class="f3-actions">'; self::button( 'oauth' === $mode ? 'Usar OAuth' : 'Usar Service Account' );
        echo '<span>A ativação verifica a autenticação. O acesso às propriedades e arquivos é verificado em Diagnóstico.</span></div></form>';
    }
    private static function remove_form( string $mode ): void {
        echo '<details class="f3-details f3-danger"><summary>Remover credenciais ' . esc_html( self::method_label( $mode ) ) . '</summary><p>Se este método estiver em uso, as chamadas desta conexão ficarão sem autenticação. A remoção afeta somente esta conexão.</p>';
        self::form( 'service_account' === $mode ? 'f3_mcp_google_save_sa' : 'f3_mcp_google_save_oauth' );
        self::button( 'Remover credenciais', 'service_account' === $mode ? 'clear_sa' : 'clear_oauth', '1', false ); echo '</form></details>';
    }
    private static function oauth(): void {
        echo '<p>Autorize uma conta Google que tenha acesso aos recursos utilizados. Configure um aplicativo OAuth Web antes de conectar.</p><div class="f3-identity"><p><strong>Callback OAuth</strong></p>';
        self::copy( OAuthFlow::redirect_uri() );
        echo '<p class="description">Cadastre exatamente esta URL nas URIs de redirecionamento autorizadas do aplicativo Web em Google Cloud → APIs e serviços → Credenciais.</p></div>';
        self::import_form( 'oauth' );
        echo '<details class="f3-details"><summary>Informar Client ID e Client secret manualmente</summary>';
        self::form( 'f3_mcp_google_save_oauth' ); self::option( 'oauth_client_id', 'text', 'autocomplete="off" required' ); self::option( 'oauth_client_secret', 'password', 'autocomplete="new-password"' ); self::button(); echo '</form></details>';
        echo '<p><strong>Client secret:</strong> ' . esc_html( self::secret_status( Options::OAUTH_CLIENT_SECRET ) ) . '</p><p><strong>Autorização:</strong> ' . esc_html( self::secret_status( Options::OAUTH_REFRESH_TOKEN ) ) . '</p>';
        if ( Options::has_secret( Options::OAUTH_REFRESH_TOKEN ) ) {
            echo '<p><strong>Conta autorizada:</strong> ' . esc_html( (string) Options::get( Options::OAUTH_EMAIL, 'E-mail não retornado pelo Google' ) ) . '</p>';
            if ( 'oauth' !== Options::auth_mode() ) { echo '<p><span class="f3-badge">Salva, fora de uso</span></p>'; }
            self::activation( 'oauth' );
        }
        $requested = Credentials::scopes_for( 'any' ); $granted = (array) Options::get( Options::OAUTH_SCOPES, array() );
        if ( Options::has_secret( Options::OAUTH_REFRESH_TOKEN ) && array_diff( $requested, $granted ) ) { echo '<div class="notice notice-warning inline"><p>Há permissões selecionadas ainda não registradas na autorização. Autorize novamente para utilizar essas funções.</p></div>'; }
        self::form( 'f3_mcp_google_oauth_start' ); self::button( Options::has_secret( Options::OAUTH_REFRESH_TOKEN ) ? 'Autorizar novamente com Google' : 'Conectar com Google' ); echo '</form>';
        echo '<p class="description">Escolha os serviços em <a href="' . esc_url( Admin::url( '', 'services' ) ) . '">Serviços e recursos</a> antes de autorizar. Em aplicativos externos no modo Testing, autorizações com estes escopos expiram em sete dias. Confira a publicação do aplicativo para operação contínua.</p>';
        self::details( 'Permissões solicitadas e concedidas', array( 'requested' => $requested, 'granted' => $granted ) );
        if ( Options::has_secret( Options::OAUTH_REFRESH_TOKEN ) ) {
            echo '<details class="f3-details f3-danger"><summary>Desconectar ou revogar OAuth</summary><p>Desconectar remove a autorização desta conexão e mantém o aplicativo configurado.</p>';
            self::form( 'f3_mcp_google_oauth_disconnect' ); self::button( 'Desconectar esta conexão', '', '', false ); echo '</form><p>A revogação também remove o acesso no Google e pode afetar outros sites que utilizam o mesmo usuário e projeto.</p>';
            self::form( 'f3_mcp_google_oauth_disconnect' ); self::button( 'Desconectar e revogar no Google', 'revoke', '1', false ); echo '</form></details>';
        }
        self::remove_form( 'oauth' );
    }
    public static function services(): void {
        $services = Fields::effective_services();
        if ( isset( self::$failed_values['services'] ) && is_array( self::$failed_values['services'] ) ) { $services = self::$failed_values['services']; }
        $bindings = (array) Options::get( Connections::BINDINGS, array() );
        $legacy = (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' );
        if ( ! array_key_exists( 'ga_property_id', $bindings ) ) { $bindings['ga_property_id'] = $legacy; }
        if ( preg_replace( '~^properties/~', '', (string) $bindings['ga_property_id'] ) !== $legacy ) { echo '<div class="notice notice-warning inline"><p>Há duas propriedades GA4 salvas. Opção legada usada por operações GA: <code>' . esc_html( $legacy ) . '</code>; vínculo usado pelo fluxo de configuração: <code>' . esc_html( $bindings['ga_property_id'] ) . '</code>. Confira o campo abaixo. Ao salvar, ele será utilizado nas duas representações.</p></div>'; }
        echo '<section class="f3-card"><h2>Serviços e recursos</h2><p>' . esc_html( Fields::metadata()['services']['description'] ) . '</p>';
        self::form( 'f3_google_setup_save' ); self::hidden( 'services_present', '1' );
        foreach ( Fields::services() as $service => $meta ) {
            $level = $services[ $service ] ?? '';
            echo '<fieldset class="f3-service"><legend>' . esc_html( $meta['label'] ) . '</legend><div class="f3-service-choice"><label for="f3-service-' . esc_attr( $service ) . '">Nível de operação</label><select name="services[' . esc_attr( $service ) . ']" id="f3-service-' . esc_attr( $service ) . '" data-service-select="' . esc_attr( $service ) . '">';
            foreach ( array_merge( array( '' ), Setup::LEVELS[ $service ] ) as $value ) { echo '<option value="' . esc_attr( $value ) . '"' . selected( $level, $value, false ) . '>' . esc_html( array( '' => 'Desativado', 'read' => 'Leitura', 'write' => 'Leitura e escrita', 'admin' => 'Administração, incluindo usuários' )[ $value ] ) . '</option>'; }
            echo '</select></div><p class="description">' . esc_html( $meta['help'] ) . '</p><div data-service-fields="' . esc_attr( $service ) . '"' . ( '' === $level ? ' hidden' : '' ) . '>';
            foreach ( Fields::resources() as $field => $info ) {
                if ( $info['service'] !== $service ) { continue; }
                $data = Resources::cached( 'spreadsheet_id' === $field ? 'sheets' : $service );
                $list = 'f3-list-' . $field;
                self::field( $field, $info['label'], (string) ( $bindings[ $field ] ?? '' ), $info['description'], 'text', 'list="' . esc_attr( $list ) . '" placeholder="' . esc_attr( $info['placeholder'] ) . '"' . ( '' === $level ? ' disabled' : '' ) );
                echo '<datalist id="' . esc_attr( $list ) . '">';
                if ( 'sitemap_url' !== $field ) { foreach ( $data['items'] ?? array() as $row ) { echo '<option value="' . esc_attr( $row['id'] ) . '">' . esc_html( $row['name'] . ' · ' . $row['id'] ) . '</option>'; } }
                echo '</datalist>';
                if ( 'sitemap_url' === $field && '' !== ( $suggestion = Resources::sitemap_suggestion() ) ) { echo '<p class="description">Sugestão do site (confira a publicação): '; self::copy( $suggestion ); echo '</p>'; }
            }
            echo '</div></fieldset>';
        }
        echo '<p><label><input type="checkbox" name="validate_access" value="1"> Testar acesso aos recursos antes de salvar</label></p><p class="description">Deixe desmarcado para preparar a configuração antes de conceder acesso ou autorizar OAuth. Salvar uma seleção não comprova acesso ao Google.</p>';
        self::button(); echo '</form></section>';
        self::discovery();
        if ( isset( $services['ads'] ) ) {
            echo '<section class="f3-card"><h2>Acesso ao Google Ads</h2><p><strong>Developer token:</strong> ' . esc_html( self::secret_status( Options::ADS_DEVELOPER_TOKEN ) ) . '</p>';
            self::form( 'f3_mcp_google_save_ads' ); self::option( 'ads_developer_token', 'password', 'autocomplete="new-password"' ); self::option( 'ads_login_customer_id', 'text', 'placeholder="123-456-7890"' );
            echo '<details class="f3-details"><summary>Versão da API e remoção do token</summary>';
            self::field( 'ads_api_version', Fields::metadata()['ads_api_version']['label'], Options::ads_api_version(), Fields::metadata()['ads_api_version']['description'], 'text', 'pattern="v[0-9]{1,3}"' );
            echo '<label><input type="checkbox" name="clear_developer_token" value="1"> Remover o developer token desta conexão</label></details>';
            self::button(); echo '</form></section>';
        }
        echo '<p><a class="button" href="' . esc_url( Admin::url( '', 'diagnostics' ) ) . '">Verificar acessos em Diagnóstico</a></p>';
    }
    private static function discovery(): void {
        echo '<section class="f3-card"><h2>Consultar recursos acessíveis</h2><p>Salve a seleção de serviços antes de consultar. Os resultados alimentam as sugestões dos campos acima. Nenhum recurso será selecionado automaticamente.</p>';
        foreach ( array( 'ga', 'ads', 'gsc', 'sheets' ) as $service ) {
            if ( ! isset( Fields::effective_services()[ $service ] ) ) { continue; }
            $data = Resources::cached( $service );
            echo '<div class="f3-discovery"><h3>' . esc_html( Fields::services()[ $service ]['label'] ) . '</h3>';
            self::form( 'f3_mcp_google_discover' ); self::hidden( 'service', $service ); self::button( 'Consultar recursos', '', '', false ); echo '</form>';
            if ( is_array( $data ) ) {
                echo '<p>' . ( empty( $data['success'] ) ? 'Consulta falhou.' : ( empty( $data['items'] ) ? 'Nenhum recurso encontrado nesta consulta.' : count( $data['items'] ) . ' recurso(s) disponível(is) nas sugestões.' ) ) . ( empty( $data['complete'] ) ? ' A listagem não está completa.' : '' ) . '</p>';
                foreach ( $data['warnings'] ?? array() as $warning ) { echo '<p>' . esc_html( $warning ) . '</p>'; }
                if ( ! empty( $data['message'] ) ) { echo '<p>' . esc_html( $data['message'] ) . '</p>'; }
                if ( ! empty( $data['next_page_token'] ) ) { self::form( 'f3_mcp_google_discover' ); self::hidden( 'service', $service ); self::hidden( 'page_token', $data['next_page_token'] ); self::button( 'Consultar próxima página', '', '', false ); echo '</form>'; }
                self::details( 'Ver recursos e detalhes da consulta', $data );
            }
            echo '</div>';
        }
        echo '<p class="description">A descoberta de planilhas depende das permissões do Drive incluídas na conexão. Se a planilha não aparecer, informe o ID ou a URL conhecida e teste o acesso ao arquivo.</p></section>';
    }
    private static function diagnostics(): void {
        echo '<section class="f3-card"><h2>Verificar a conexão</h2><p>As verificações consultam os serviços e recursos configurados. Uma leitura aprovada confirma o acesso de leitura daquele recurso; permissões de escrita e administração dependem da operação.</p>';
        self::form( 'f3_mcp_google_test' ); self::button( 'Testar acessos agora' ); echo '</form>';
        $result = get_transient( Admin::diagnostic_key() ); $revision = Settings::revision();
        if ( ! is_array( $result ) ) { echo '<p class="f3-empty">Não testado. Execute a verificação para conferir esta conexão.</p>'; }
        else {
            $stale = ! is_string( $revision ) || ( $result['revision'] ?? '' ) !== $revision;
            echo '<p><strong>' . ( $stale ? 'Resultado desatualizado: a configuração foi alterada.' : 'Resultado da última verificação' ) . '</strong></p><p>Conexão: ' . esc_html( $result['connection_id'] ?? '' ) . ' · Método: ' . esc_html( self::method_label( $result['auth_mode'] ?? '' ) ) . ' · ' . esc_html( $result['checked_at'] ?? '' ) . ' (UTC)</p>';
            echo '<div class="f3-table-wrap"><table class="widefat striped"><thead><tr><th>Verificação</th><th>Resultado</th><th>Detalhe e próxima ação</th></tr></thead><tbody>';
            $labels = array( 'passed' => 'Aprovado', 'failed' => 'Falhou', 'skipped' => 'Ignorado', 'not_configured' => 'Não configurado', 'not_tested' => 'Não testado' );
            foreach ( $result['checks'] ?? array() as $check ) {
                $status = $check['status'] ?? 'not_tested'; $name = $check['name'] ?? '';
                $service = preg_replace( '/^live_/', '', $name ); $label = Fields::services()[ $service ]['label'] ?? $name;
                echo '<tr><td>' . esc_html( $label ) . '</td><td><span class="f3-state f3-state-' . esc_attr( $stale ? 'skipped' : $status ) . '">' . esc_html( $labels[ $status ] ?? $status ) . ( $stale ? ' (anterior)' : '' ) . '</span></td><td>' . esc_html( $check['detail'] ?? '' );
                if ( ! empty( $check['target'] ) ) { echo '<br><code>' . esc_html( $check['target'] ) . '</code>'; }
                if ( in_array( $status, array( 'failed', 'not_configured' ), true ) ) { echo '<br>' . esc_html( self::next_action( $check ) ); }
                echo '</td></tr>';
            }
            echo '</tbody></table></div>'; self::details( 'Detalhes técnicos da verificação', $result );
        }
        echo '</section><section class="f3-card"><h2>Capacidades do servidor</h2><dl class="f3-definition"><dt>Abilities API</dt><dd>' . ( Plugin::abilities_api_available() ? 'Disponível' : 'Ausente. Instale o provedor da Abilities API compatível com este WordPress.' ) . '</dd><dt>Servidor MCP</dt><dd>' . ( Plugin::mcp_server_detected() ? 'Integração detectada localmente. O acesso externo depende do transporte e da autenticação do conector.' : 'Detecção local inconclusiva. Isso não comprova ausência de servidor MCP. Confira o teste de conexão no cliente.' ) . '</dd><dt>Criptografia dos segredos</dt><dd>' . esc_html( Crypto::backend() ) . '</dd>';
        if ( 'service_account' === Options::auth_mode() ) { echo '<dt>Assinatura da Service Account</dt><dd>' . ( function_exists( 'openssl_sign' ) ? 'OpenSSL disponível' : 'OpenSSL ausente. Habilite a extensão para utilizar Service Account.' ) . '</dd>'; }
        echo '</dl></section>';
    }
    private static function next_action( array $check ): string {
        $code = $check['error_code'] ?? '';
        if ( false !== strpos( $code, 'crypto' ) ) { return 'Confira as salts do WordPress e a extensão de cifra; se necessário, reimporte a credencial.'; }
        if ( false !== strpos( $code, 'quota' ) || false !== strpos( $code, 'rate' ) ) { return 'Confira a cota e o intervalo de nova tentativa nos detalhes técnicos.'; }
        if ( false !== strpos( $code, 'token' ) || false !== strpos( $code, 'oauth' ) ) { return 'Confira a autenticação na aba Conexão e repita o teste.'; }
        return 'Confira o recurso, a API habilitada e a permissão da identidade em Serviços e recursos. O detalhe técnico informa a causa devolvida pelo serviço.';
    }
    private static function advanced(): void {
        echo '<section class="f3-card"><h2>Controle do site</h2><p>' . esc_html( Fields::metadata()['enabled']['description'] ) . '</p>';
        if ( Admin::forced_by_filter() ) { echo '<p>Esta opção também é controlada pelo filtro <code>f3_mcp_google_enabled</code>. O valor efetivo pode diferir do valor salvo.</p>'; }
        self::form( 'f3_mcp_google_toggle' ); self::hidden( 'enable', Options::is_enabled() ? '0' : '1' ); self::button( Options::is_enabled() ? 'Bloquear chamadas Google' : 'Permitir chamadas Google' ); echo '</form></section><section class="f3-card"><h2>Limites do site</h2><p>Aplicados a todas as conexões deste WordPress.</p>';
        self::form( 'f3_mcp_google_save_limits' );
        foreach ( Options::LIMITS as $name => $rule ) {
            $id = substr( $name, strlen( 'f3_mcp_google_' ) ); $meta = Fields::metadata()[ $id ];
            self::field( $id, $meta['label'], (string) Options::limit( $name ), $meta['description'] . ' Padrão: ' . $rule['default'] . '. Intervalo: ' . $rule['minimum'] . '–' . $rule['maximum'] . '.', 'number', 'min="' . $rule['minimum'] . '" max="' . $rule['maximum'] . '" step="1" required' );
        }
        self::button(); echo '</form></section><section class="f3-card"><h2>Auditoria</h2><p>Últimas 30 operações de todas as conexões, em UTC.</p>';
        $log = Audit::recent( 30 );
        if ( ! $log ) { echo '<p>Nenhuma operação registrada.</p>'; }
        else { echo '<div class="f3-table-wrap"><table class="widefat striped"><thead><tr><th>Quando</th><th>Ação</th><th>Alvo</th></tr></thead><tbody>'; foreach ( $log as $row ) { echo '<tr><td>' . esc_html( $row['time'] ?? '' ) . '</td><td>' . esc_html( $row['action'] ?? '' ) . '</td><td>' . esc_html( $row['target'] ?? '' ) . '</td></tr>'; } echo '</tbody></table></div>'; }
        echo '<details class="f3-details f3-danger"><summary>Limpar auditoria</summary><p>Remove o histórico de operações de todas as conexões deste site.</p>'; self::form( 'f3_mcp_google_clear_log' ); self::button( 'Limpar auditoria', '', '', false ); echo '</form></details></section><section class="f3-card"><h2>Informações técnicas</h2><p>WordPress: ' . esc_html( get_bloginfo( 'version' ) ) . ' · Plugin: ' . esc_html( F3_MCP_GOOGLE_VERSION ) . '</p>';
        // Direct definitions remain available in wp-admin while the MCP channel is closed.
        self::details( 'Contrato de configuração para agentes', Configuration::read_for_admin() );
        echo '<p>Agendamentos utilizam WP-Cron. Para execução independente de visitas, configure o cron do servidor para acionar wp-cron.php. Acompanhe os resultados em google/list-jobs.</p></section>';
    }
}
