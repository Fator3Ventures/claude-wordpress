<?php
/** Resource suggestions never implicitly select, create or submit a resource. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{Admin, Settings, Options, Connections, Gate, Response, Unified\Query, Auth\Credentials, Http\GoogleClient};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Resources {
    public static function normalize( string $field, string $value ) {
        $value = trim( $value );
        if ( '' === $value ) { return ''; }
        if ( 'ads_customer_id' === $field ) { return \Fator3\McpGoogle\Ads\CustomerId::normalize( $value ); }
        if ( 'ga_property_id' === $field ) { $id = \Fator3\McpGoogle\Analytics\PropertyId::normalize( $value ); return is_wp_error( $id ) ? $id : preg_replace( '~^properties/~', '', $id ); }
        if ( 'spreadsheet_id' === $field && false !== strpos( $value, '://' ) ) {
            $parts = wp_parse_url( $value );
            if ( ! is_array( $parts ) || ( $parts['scheme'] ?? '' ) !== 'https' || ( $parts['host'] ?? '' ) !== 'docs.google.com' || isset( $parts['user'] ) || isset( $parts['port'] ) || ! preg_match( '~^/spreadsheets/d/([A-Za-z0-9_-]+)(?:/|$)~D', $parts['path'] ?? '', $m ) ) { return new \WP_Error( 'f3_google_sheet_url', 'Informe o ID ou uma URL HTTPS de planilha em docs.google.com.' ); }
            return $m[1];
        }
        return $value;
    }
    public static function discover( string $service, string $page = '' ): array {
        if ( ! in_array( $service, array( 'ga', 'ads', 'gsc', 'sheets' ), true ) ) { return Response::fail( new \WP_Error( 'f3_google_discovery_service', 'Serviço inválido para descoberta.' ) ); }
        $revision = Settings::revision();
        if ( is_wp_error( $revision ) ) { return Response::fail( $revision ); }
        $result = array( 'success' => true, 'items' => array(), 'warnings' => array(), 'next_page_token' => '', 'complete' => true, 'revision' => $revision, 'connection_id' => Connections::id(), 'checked_at' => gmdate( 'c' ) );
        if ( 'sheets' === $service ) {
            $gate = Gate::check( 'sheets' ); if ( null !== $gate ) { return $gate + array( 'complete' => false ) + $result; }
            $query = array( 'q' => "mimeType='application/vnd.google-apps.spreadsheet' and trashed=false", 'fields' => 'files(id,name),nextPageToken,incompleteSearch', 'pageSize' => 100, 'supportsAllDrives' => true, 'includeItemsFromAllDrives' => true );
            if ( '' !== $page ) { $query['pageToken'] = $page; }
            $data = GoogleClient::get( GoogleClient::HOST_GOOGLE . '/drive/v3/files', $query, array( 'scopes' => Credentials::scopes_for( 'sheets' ), 'connector' => 'sheets', 'mode' => 'read', 'retries' => 0 ) );
            if ( is_wp_error( $data ) ) { return Response::fail( $data ) + array( 'complete' => false ) + $result; }
            foreach ( $data['files'] ?? array() as $row ) { $result['items'][] = array( 'id' => (string) $row['id'], 'name' => (string) ( $row['name'] ?? $row['id'] ) ); }
            $result['next_page_token'] = (string) ( $data['nextPageToken'] ?? '' );
            $result['complete'] = '' === $result['next_page_token'] && empty( $data['incompleteSearch'] );
            if ( ! empty( $data['incompleteSearch'] ) ) { $result['warnings'][] = 'O Google retornou uma busca incompleta. Informe o ID conhecido se o arquivo não aparecer.'; }
        } else {
            $data = Query::accounts( array( 'connector' => array( 'ga' => 'ga4', 'ads' => 'google-ads', 'gsc' => 'search-console' )[ $service ], 'refresh' => true, 'expand_managers' => true ) );
            $result['warnings'] = $data['warnings'] ?? array();
            $result['success'] = ! empty( $data['success'] ) && ( ! $result['warnings'] || ! empty( $data['accounts'] ) );
            $result['complete'] = ! empty( $data['success'] ) && ! $result['warnings'];
            foreach ( $data['accounts'] ?? array() as $row ) {
                $id = self::normalize( array( 'ga' => 'ga_property_id', 'ads' => 'ads_customer_id', 'gsc' => 'gsc_site_url' )[ $service ], (string) ( $row['native_account_id'] ?? $row['account_id'] ?? '' ) );
                if ( ! is_wp_error( $id ) && '' !== $id ) { $result['items'][] = array( 'id' => $id, 'name' => (string) ( $row['name'] ?? $id ) . ( ! empty( $row['parent'] ) ? ' · ' . $row['parent'] : '' ) ); }
            }
        }
        return $result;
    }
    public static function cached( string $service ): ?array {
        $data = get_transient( Admin::feedback_key( 'discovery_' . $service ) );
        $revision = Settings::revision();
        return is_array( $data ) && is_string( $revision ) && ( $data['revision'] ?? '' ) === $revision ? $data : null;
    }
    public static function sitemap_suggestion(): string {
        if ( defined( 'WPSEO_VERSION' ) && ( ! class_exists( '\WPSEO_Options' ) || \WPSEO_Options::get( 'enable_xml_sitemap', true ) ) ) { return home_url( '/sitemap_index.xml' ); }
        if ( function_exists( 'wp_sitemaps_get_server' ) ) { $s = wp_sitemaps_get_server(); if ( $s && $s->sitemaps_enabled() ) { return $s->index->get_index_url(); } }
        return '';
    }
}
