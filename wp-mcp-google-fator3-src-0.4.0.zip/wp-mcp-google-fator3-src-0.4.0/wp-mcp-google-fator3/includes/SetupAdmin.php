<?php
/** Guided forms share the same writers used by agents and manual configuration. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class SetupAdmin {
    public static function init(): void {
        foreach ( array( 'save', 'import', 'create' ) as $action ) { add_action( 'admin_post_f3_google_setup_' . $action, static fn() => self::handle( $action ) ); }
    }
    public static function handle( string $action ): void {
        Admin::guard( 'f3_google_setup_' . $action );
        if ( 'create' === $action ) {
            $id = Admin::posted( 'new_id' );
            $result = Connections::create( $id, Admin::posted( 'label' ) );
            Admin::require_saved( $result ); Connections::select( $id );
            wp_safe_redirect( Admin::url( 'created', 'connection', 'service_account' ) ); exit;
        }
        if ( 'import' === $action ) {
            $file = $_FILES['credential'] ?? array();
            $max = Auth\Configuration::JSON_MAX_BYTES;
            if ( ! is_array( $file ) || ( $file['error'] ?? 1 ) !== UPLOAD_ERR_OK || ! is_string( $file['tmp_name'] ?? null ) || ! is_uploaded_file( $file['tmp_name'] ) ) { Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_credential_upload', 'Envie um arquivo JSON de até 1 MiB. Confira também o limite de upload do servidor.' ) ) ); return; }
            if ( filesize( $file['tmp_name'] ) > $max ) { Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' ) ) ); return; }
            $json = file_get_contents( $file['tmp_name'], false, null, 0, $max + 1 );
            $result = Auth\Configuration::import( is_string( $json ) ? $json : '', Admin::method(), '1' === Admin::posted( 'activate' ), Admin::posted_revision() );
            Admin::saved( $result, '1' === Admin::posted( 'activate' ) ? 'activated' : 'saved' ); return;
        }
        $input = array( 'bindings' => array(), 'validate_access' => '1' === Admin::posted( 'validate_access' ) );
        if ( isset( $_POST['services_present'] ) || isset( $_POST['services'] ) ) {
            $input['services'] = array();
            foreach ( (array) ( $_POST['services'] ?? array() ) as $service => $level ) {
                if ( ! is_string( $level ) ) { Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_setup_input', 'Perfil de serviço inválido.' ) ) ); return; }
                if ( '' !== $level ) { $input['services'][ $service ] = $level; }
            }
        }
        foreach ( array_keys( Setup::BINDING_RULES ) as $key ) {
            if ( ! isset( $_POST[ $key ] ) ) { continue; }
            $value = Admin\Resources::normalize( $key, Admin::posted( $key ) );
            if ( is_wp_error( $value ) ) { Admin::require_saved( Response::fail( $value ) ); return; }
            $input['bindings'][ $key ] = $value;
        }
        if ( null !== Admin::posted_revision() ) { $input['expected_revision'] = Admin::posted_revision(); }
        Admin::saved( Setup::apply( $input ) );
    }
    /** Compatibility entry point now prepares credentials without activating another method. */
    public static function import( string $json ): array { return Auth\Configuration::import( $json ); }
    public static function render(): void { Admin\Screen::services(); }
}
