<?php
/**
 * Ligações do plugin com o WordPress.
 *
 * Nada aqui faz trabalho: só decide quando as outras classes entram em cena. O
 * registro das habilidades acontece em `wp_abilities_api_init`, que dispara
 * tanto no WordPress 6.9+ nativo quanto no polyfill que o servidor MCP carrega.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	public static function init(): void {
		Options::init();

		add_action( 'wp_abilities_api_categories_init', array( self::class, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( self::class, 'register_abilities' ) );

		Admin::init();
		SetupAdmin::init();
		Automation\Jobs::init();
		Auth\OAuthFlow::init();
	}

	/**
	 * A categoria precisa existir antes das habilidades; se outro plugin já
	 * registrou 'google', a dele vale — duas categorias com o mesmo slug seriam
	 * a segunda sobrescrevendo a primeira sem aviso.
	 */
	public static function register_category(): void {
		if ( ! function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		if ( function_exists( 'wp_has_ability_category' ) && wp_has_ability_category( 'google' ) ) {
			return;
		}

		wp_register_ability_category(
			'google',
			array(
				'label'       => __( 'Google', 'wp-mcp-google-fator3' ),
				'description' => __( 'Leitura e escrita de Analytics, Ads, Search Console, Site Verification, Sheets e Drive.', 'wp-mcp-google-fator3' ),
			)
		);
	}

	/**
	 * Registra as três famílias de habilidades.
	 *
	 * Cada uma vem de uma fase de desenvolvimento diferente e os arquivos podem
	 * não estar todos presentes; o `class_exists` deixa o plugin funcionar com o
	 * que houver, em vez de cair inteiro por causa de um arquivo ausente.
	 */
	public static function register_abilities(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		if ( class_exists( __NAMESPACE__ . '\\Analytics\\Abilities' ) ) {
			Analytics\Abilities::register();
		}

		if ( class_exists( __NAMESPACE__ . '\\Ads\\Abilities' ) ) {
			Ads\Abilities::register();
		}

		if ( class_exists( __NAMESPACE__ . '\\Unified\\Abilities' ) ) {
			Unified\Abilities::register();
		}
		Generic\Abilities::register();
		Analytics\AdminWrite::register();
		Analytics\MeasurementProtocol::register();
		Ads\Mutate::register();
		Ads\WriteAbilities::register();
		SearchConsole\Abilities::register();
		SiteVerification\Abilities::register();
		Unified\Blend::register();
		Sheets\Export::register();
		Setup::register();
		Configuration::register();
		Automation\Reports::register();
		Automation\Jobs::register();
		SearchConsole\Workflow::register();
	}

	/**
	 * Existe algum servidor MCP para expor as rotas para fora?
	 *
	 * Registrar habilidades não basta: elas ficam no WordPress e ninguém de fora
	 * as alcança sem um servidor MCP. A checagem é por capacidade, não por
	 * marca — qualquer plugin que exponha a Abilities API por MCP serve.
	 */
    public static function mcp_server_detected(): bool {
        if ( class_exists( '\\WpMcpUltimate\\Server\\McpAdapter' ) || defined( 'WP_MCP_ULTIMATE_DIR' ) || defined( 'WP_MCP_FATOR3_DIR' ) || (bool) apply_filters( 'f3_mcp_google_servidor_mcp_detectado', false ) ) { return true; }
        if ( function_exists( 'rest_get_server' ) ) {
            return self::has_mcp_route( array_keys( rest_get_server()->get_routes() ) );
        }
        return false;
    }

    private static function has_mcp_route( array $routes ): bool {
        foreach ( $routes as $route ) {
            if ( preg_match( '~^/(?:mcp/wp-mcp-(?:fator3|ultimate)|(?:wp-mcp-(?:fator3|ultimate)|mcp)/v[0-9]+)(?:/|$)~', $route ) ) { return true; }
        }
        return false;
    }

	/**
	 * A Abilities API existe nesta instalação?
	 *
	 * Vem do núcleo no WordPress 6.9+, ou de um polyfill carregado por um plugin
	 * de servidor MCP. Sem ela, `wp_abilities_api_init` nunca dispara e este
	 * plugin não registra rota nenhuma.
	 */
	public static function abilities_api_available(): bool {
		return function_exists( 'wp_register_ability' );
	}
}
