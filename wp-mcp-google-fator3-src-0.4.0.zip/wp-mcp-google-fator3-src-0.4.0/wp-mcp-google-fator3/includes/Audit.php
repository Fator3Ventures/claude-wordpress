<?php
/**
 * Log circular das operações.
 *
 * Guarda o que aconteceu: nome da habilidade, conta
 * alvo, usuário, duração e número de linhas. Escritas acrescentam snapshots before/after limitados e redigidos.
 * Consultas de leitura registram somente metadados.
 *
 * Circular em 100 entradas para a option não crescer sem limite.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Audit {

	public const MAX = 100;

	/** Teto de campos extras por registro — evita despejar a entrada inteira. */
	private const MAX_EXTRA = 12;

	private static array $contexts = array();

	/**
	 * @param string $action Nome da habilidade ou evento ('channel:disable').
	 * @param string $target Propriedade GA ou conta Ads envolvida.
	 * @param array  $extra  Só escalares curtos: rows, ms, status.
	 */
	public static function log( string $action, string $target = '-', array $extra = array() ): void {
		$id = Records::id();
		$entry = array( 'id' => $id, 'time' => gmdate( 'Y-m-d H:i:s' ), 'action' => self::trim( $action, 80 ), 'target' => '' === $target ? '-' : self::trim( $target, 200 ), 'user' => get_current_user_id(), 'connection_id' => Connections::id(), 'plugin_version' => F3_MCP_GOOGLE_VERSION, 'extra' => self::clean_extra( $extra ) );
		if ( ! Records::insert( 'audit', $id, $entry ) ) { return; }
		$retention = Options::limit( Options::AUDIT_RETENTION );
		$records = Records::list( 'audit', $retention + 100 );
		foreach ( array_slice( array_keys( $records ), $retention ) as $old ) { Records::remove( 'audit', $old ); }
	}

	/**
	 * @return array<int,array> Mais recente primeiro.
	 */
	public static function recent( int $limit = 30 ): array {
		$log = array_values( Records::list( 'audit', 5000 ) );
		$legacy = Options::get( self::option(), array() );
		if ( is_array( $legacy ) ) { $log = array_merge( $log, array_reverse( $legacy ) ); }
		return $limit > 0 ? array_slice( $log, 0, $limit ) : $log;
	}

	public static function clear(): array {
		foreach ( Records::list( 'audit', 10000 ) as $id => $record ) {
			$result = Records::remove( 'audit', $id );
			if ( ! $result['success'] ) { return $result; }
		}
		return Options::set( self::option(), array() );
	}

	private static function option(): string {
		return Options::AUDIT;
	}

	/** Inicia um contexto isolado, inclusive para execução aninhada. */
	public static function begin(): void {
		self::$contexts[] = array(
			'before' => array(
				'available' => false,
				'reason'    => 'Estado anterior não disponível para este método.',
			),
			'after'  => array(
				'available' => false,
				'reason'    => 'Estado posterior não disponível para este método.',
			),
		);
	}

	public static function before( $value ): void {
		if ( self::$contexts ) {
			self::$contexts[ count( self::$contexts ) - 1 ]['before'] = self::snapshot( $value );
		}
	}

	public static function after( $value ): void {
		if ( self::$contexts ) {
			self::$contexts[ count( self::$contexts ) - 1 ]['after'] = self::snapshot( $value );
		}
	}

	public static function finish(): array {
		return self::$contexts ? array_pop( self::$contexts ) : array();
	}

	/** Redação recursiva de segredos e identificadores de Customer Match. */
	public static function redact( $value, int $depth = 0 ) {
		if ( $depth > 8 ) {
			return '[limite de profundidade]';
		}
		if ( is_object( $value ) ) {
			$value = is_wp_error( $value ) ? array( 'error' => $value->get_error_message() ) : (array) $value;
		}
		if ( is_array( $value ) ) {
			$out = array();
			foreach ( $value as $key => $item ) {
				$normalized = strtolower( (string) preg_replace( '/[^a-z0-9]/i', '', (string) $key ) );
				if ( preg_match( '/secret|password|privatekey|accesstoken|refreshtoken|idtoken|developertoken|authorization|assertion|hashedemail|hashedphone|useridentifiers|addressinfo|clientid|userid/', $normalized ) ) {
					$out[ $key ] = '[redigido]';
				} else {
					$out[ $key ] = self::redact( $item, $depth + 1 );
				}
			}
			return $out;
		}
		return is_string( $value ) ? Ability::scrub( $value ) : $value;
	}

	/** Limite em bytes sem produzir JSON ou UTF-8 parcial. */
	private static function snapshot( $value ) {
		$clean = self::redact( $value );
		$json  = (string) wp_json_encode( $clean );
		if ( strlen( $json ) <= 4096 ) {
			return $clean;
		}
		$out = array(
			'truncated'      => true,
			'original_bytes' => strlen( $json ),
			'sha256'         => hash( 'sha256', $json ),
			'fields'         => array(),
		);
		foreach ( (array) $clean as $key => $item ) {
			$candidate                   = $out;
			$candidate['fields'][ $key ] = $item;
			if ( strlen( (string) wp_json_encode( $candidate ) ) <= 4096 ) {
				$out = $candidate;
			}
		}
		return $out;
	}

	private static function clean_extra( array $extra ): array {
		$clean = array();
		foreach ( $extra as $key => $value ) {
			if ( count( $clean ) >= self::MAX_EXTRA ) {
				break;
			}
			$name = sanitize_key( (string) $key );
			if ( '' === $name ) {
				continue;
			}
			if ( in_array( $name, array( 'before', 'after', 'result' ), true ) ) {
				$clean[ $name ] = self::snapshot( $value );
			} elseif ( is_scalar( $value ) || null === $value ) {
				$clean[ $name ] = is_string( $value ) ? self::trim( Ability::scrub( $value ), 60 ) : $value;
			}
		}
		return $clean;
	}

	private static function trim( string $text, int $max ): string {
		$text = trim( $text );

		return strlen( $text ) > $max ? substr( $text, 0, $max ) : $text;
	}
}
