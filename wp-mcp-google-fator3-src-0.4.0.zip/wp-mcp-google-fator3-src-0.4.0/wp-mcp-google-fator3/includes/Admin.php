<?php
/** Administrative actions: capability + nonce, verified saves and scoped feedback. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
use Fator3\McpGoogle\Auth\{Credentials, Configuration as AuthConfiguration};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Admin {
    public const SLUG = 'wp-mcp-google-fator3';
    public const SECTIONS = array( 'connection' => 'Conexão', 'services' => 'Serviços e recursos', 'diagnostics' => 'Diagnóstico', 'advanced' => 'Avançado' );
    public static function init(): void {
        add_action( 'admin_menu', array( self::class, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( self::class, 'assets' ) );
        foreach ( array( 'toggle', 'toggle_ga', 'toggle_ads', 'save_mode', 'save_sa', 'save_oauth', 'save_ads', 'save_ga', 'save_limits', 'test', 'clear_log', 'discover', 'script' ) as $action ) {
            add_action( 'admin_post_f3_mcp_google_' . $action, array( self::class, 'handle_' . $action ) );
        }
    }
    public static function menu(): void { add_management_page( 'WP MCP Google Fator3', 'MCP Google', Options::capability(), self::SLUG, array( self::class, 'render' ) ); }
    public static function assets( string $hook ): void {
        if ( 'tools_page_' . self::SLUG !== $hook ) { return; }
        wp_enqueue_style( 'f3-google-admin', plugins_url( 'assets/admin.css', F3_MCP_GOOGLE_FILE ), array(), F3_MCP_GOOGLE_VERSION );
        wp_enqueue_script( 'f3-google-admin', plugins_url( 'assets/admin.js', F3_MCP_GOOGLE_FILE ), array(), F3_MCP_GOOGLE_VERSION, true );
    }
    public static function section(): string { $s = self::request( 'section' ); return isset( self::SECTIONS[ $s ] ) ? $s : 'connection'; }
    public static function method(): string { $s = self::request( 'method' ); return in_array( $s, Options::AUTH_MODES, true ) ? $s : Options::auth_mode(); }
    private static function request( string $name ): string {
        $v = $_POST[ $name ] ?? $_GET[ $name ] ?? '';
        return is_string( $v ) ? sanitize_key( wp_unslash( $v ) ) : '';
    }
    public static function url( string $status = '', ?string $section = null, ?string $method = null ): string {
        $args = array( 'page' => self::SLUG, 'connection_id' => Connections::id(), 'section' => $section ?? self::section(), 'method' => $method ?? self::method() );
        if ( '' !== $status ) { $args['f3_status'] = $status; }
        return add_query_arg( $args, admin_url( 'tools.php' ) );
    }
    public static function posted( string $field ): string {
        return isset( $_POST[ $field ] ) && is_scalar( $_POST[ $field ] ) ? trim( sanitize_text_field( wp_unslash( (string) $_POST[ $field ] ) ) ) : '';
    }
    public static function posted_revision(): ?string { return isset( $_POST['expected_revision'] ) ? self::posted( 'expected_revision' ) : null; }
    public static function guard( string $nonce ): void {
        if ( ! current_user_can( Options::capability() ) ) { wp_die( 'Permissão insuficiente.' ); }
        check_admin_referer( $nonce );
        if ( is_wp_error( Connections::select( self::posted( 'connection_id' ) ?: 'default' ) ) ) { wp_die( 'Conexão inválida.' ); }
    }
    public static function feedback_key( string $kind, ?int $user_id = null ): string {
        return 'f3_mcp_google_ui_' . $kind . '_' . ( $user_id ?? get_current_user_id() ) . '_' . Connections::id();
    }
    public static function require_saved( array $result, ?int $user_id = null ): void {
        if ( ! empty( $result['success'] ) ) { return; }
        Audit::log( 'configuration:rejected', Connections::id(), array( 'status' => 'error', 'error_code' => $result['error_code'] ?? 'f3_google_option_write' ) );
        $safe = array_intersect_key( $_POST, array_flip( array( 'sa_subject', 'oauth_client_id', 'ads_login_customer_id', 'ads_api_version', 'ga_default_property', 'ga_property_id', 'ads_customer_id', 'gsc_site_url', 'spreadsheet_id', 'sitemap_url', 'max_rows', 'http_timeout', 'audit_retention', 'inspection_budget', 'services' ) ) );
        // Whitelist only non-secret editable values; arbitrary response details are excluded.
        set_transient( self::feedback_key( 'failure', $user_id ), array( 'code' => $result['error_code'] ?? 'f3_google_option_write', 'message' => $result['message'] ?? 'Falha ao salvar configuração.', 'values' => $safe, 'rollback_failed' => ! empty( array_filter( $result['rollback'] ?? array(), static fn( $r ) => empty( $r['success'] ) ) ) ), 300 );
        self::back( 'save_failed' );
    }
    public static function saved( array $result, string $status = 'saved' ): void {
        self::require_saved( $result );
        $changed = $result['changed'] ?? null;
        if ( null === $changed && isset( $result['operations'] ) ) { $changed = (bool) array_filter( $result['operations'], static fn( $r ) => ! empty( $r['changed'] ) ); }
        self::back( false === $changed ? 'unchanged' : $status );
    }
    public static function back( string $status ): void { wp_safe_redirect( self::url( $status ) ); exit; }
    private static function save( array $values, array $secrets = array(), array $deletes = array() ): array { return Settings::save( $values, $secrets, $deletes, self::posted_revision() ); }
    public static function handle_toggle(): void {
        self::guard( 'f3_mcp_google_toggle' ); self::saved( self::save( array( Options::ENABLED => '1' === self::posted( 'enable' ) ) ) );
    }
    public static function handle_toggle_ga(): void { self::toggle_service( 'ga' ); }
    public static function handle_toggle_ads(): void { self::toggle_service( 'ads' ); }
    private static function toggle_service( string $service ): void {
        self::guard( 'f3_mcp_google_toggle_' . $service );
        $services = Admin\Fields::effective_services();
        if ( '1' === self::posted( 'enable' ) ) { $services[ $service ] = $services[ $service ] ?? 'read'; } else { unset( $services[ $service ] ); }
        $input = array( 'services' => $services, 'validate_access' => false );
        if ( null !== self::posted_revision() ) { $input['expected_revision'] = self::posted_revision(); }
        self::saved( Setup::apply( $input ) );
    }
    public static function handle_save_mode(): void {
        self::guard( 'f3_mcp_google_save_mode' );
        self::saved( AuthConfiguration::activate( self::posted( 'auth_mode' ), self::posted_revision() ), 'activated' );
    }
    public static function handle_save_sa(): void {
        self::guard( 'f3_mcp_google_save_sa' );
        if ( '1' === self::posted( 'clear_sa' ) ) { self::saved( AuthConfiguration::clear( 'service_account', self::posted_revision() ), 'sa_cleared' ); return; }
        $json = isset( $_POST['sa_json'] ) && is_string( $_POST['sa_json'] ) ? trim( wp_unslash( $_POST['sa_json'] ) ) : '';
        $result = AuthConfiguration::save_sa( $json, isset( $_POST['sa_subject'] ) ? self::posted( 'sa_subject' ) : null, '1' === self::posted( 'activate' ), self::posted_revision() );
        self::saved( $result, '1' === self::posted( 'activate' ) ? 'activated' : 'sa_saved' );
    }
    public static function handle_save_oauth(): void {
        self::guard( 'f3_mcp_google_save_oauth' );
        if ( '1' === self::posted( 'clear_oauth' ) ) { self::saved( AuthConfiguration::clear( 'oauth', self::posted_revision() ) ); return; }
        self::saved( AuthConfiguration::save_oauth( self::posted( 'oauth_client_id' ), self::posted( 'oauth_client_secret' ), self::posted_revision() ) );
    }
    public static function handle_save_ads(): void {
        self::guard( 'f3_mcp_google_save_ads' );
        $values = array(); $secrets = array(); $deletes = array();
        if ( isset( $_POST['ads_login_customer_id'] ) ) {
            $raw = self::posted( 'ads_login_customer_id' );
            $id = '' === $raw ? '' : Ads\CustomerId::normalize( $raw );
            if ( is_wp_error( $id ) ) { self::require_saved( Response::fail( $id ) ); return; }
            $values[ Options::ADS_LOGIN_CUSTOMER_ID ] = $id;
        }
        if ( isset( $_POST['ads_api_version'] ) ) {
            $version = self::posted( 'ads_api_version' );
            if ( ! preg_match( Options::ADS_VERSION_PATTERN, $version ) ) { self::require_saved( Response::fail( new \WP_Error( 'f3_google_ads_version', 'Informe uma versão no formato v25.' ) ) ); return; }
            $values[ Options::ADS_API_VERSION ] = $version;
        }
        if ( '1' === self::posted( 'clear_developer_token' ) ) { $deletes[] = Options::ADS_DEVELOPER_TOKEN; }
        elseif ( '' !== self::posted( 'ads_developer_token' ) ) { $secrets[ Options::ADS_DEVELOPER_TOKEN ] = self::posted( 'ads_developer_token' ); }
        self::saved( self::save( $values, $secrets, $deletes ) );
    }
    public static function handle_save_ga(): void {
        self::guard( 'f3_mcp_google_save_ga' );
        $input = array( 'bindings' => array( 'ga_property_id' => self::posted( 'ga_default_property' ) ), 'validate_access' => false );
        if ( null !== self::posted_revision() ) { $input['expected_revision'] = self::posted_revision(); }
        self::saved( Setup::apply( $input ) );
    }
    public static function handle_save_limits(): void {
        self::guard( 'f3_mcp_google_save_limits' ); $values = array();
        foreach ( Options::LIMITS as $name => $rule ) {
            $id = substr( $name, strlen( 'f3_mcp_google_' ) );
            if ( ! isset( $_POST[ $id ] ) ) { continue; }
            $raw = self::posted( $id );
            if ( ! preg_match( '/^[0-9]+$/D', $raw ) || (int) $raw < $rule['minimum'] || (int) $raw > $rule['maximum'] ) {
                self::require_saved( Response::fail( new \WP_Error( 'f3_google_limit', Admin\Fields::metadata()[ $id ]['label'] . ': informe um inteiro de ' . $rule['minimum'] . ' a ' . $rule['maximum'] . '.' ) ) ); return;
            }
            $values[ $name ] = (int) $raw;
        }
        self::saved( self::save( $values ) );
    }
    public static function diagnostic_key(): string { return self::feedback_key( 'test' ); }
    public static function handle_test(): void {
        self::guard( 'f3_mcp_google_test' );
        $revision = Settings::revision();
        if ( is_wp_error( $revision ) ) { self::require_saved( Response::fail( $revision ) ); return; }
        $result = SelfTest::run( array( 'live' => true ) );
        $result += array( 'connection_id' => Connections::id(), 'auth_mode' => Options::auth_mode(), 'checked_at' => gmdate( 'c' ), 'revision' => $revision );
        set_transient( self::diagnostic_key(), $result, 3600 );
        Audit::log( 'selftest', Connections::id() ); self::back( 'tested' );
    }
    public static function handle_discover(): void {
        self::guard( 'f3_mcp_google_discover' );
        $service = self::posted( 'service' );
        $result = Admin\Resources::discover( $service, self::posted( 'page_token' ) );
        set_transient( self::feedback_key( 'discovery_' . $service ), $result, 600 );
        self::back( 'discovered' );
    }
    public static function handle_clear_log(): void { self::guard( 'f3_mcp_google_clear_log' ); self::saved( Audit::clear(), 'log_cleared' ); }
    public static function handle_script(): void {
        self::guard( 'f3_mcp_google_script' );
        header( 'Content-Type: text/plain; charset=UTF-8' );
        header( 'Content-Disposition: attachment; filename="googlecloudscript.txt"' );
        header( 'Cache-Control: no-store' );
        readfile( F3_MCP_GOOGLE_DIR . 'reference/googlecloudscript.txt' ); exit;
    }
    public static function forced_by_filter(): bool { return (bool) has_filter( 'f3_mcp_google_enabled' ); }
    public static function render(): void {
        if ( ! current_user_can( Options::capability() ) ) { return; }
        $id = isset( $_GET['connection_id'] ) && is_string( $_GET['connection_id'] ) ? sanitize_key( $_GET['connection_id'] ) : 'default';
        if ( is_wp_error( Connections::select( $id ) ) ) { echo '<div class="notice notice-error"><p>Conexão inválida.</p></div>'; return; }
        Admin\Screen::render();
    }
}
