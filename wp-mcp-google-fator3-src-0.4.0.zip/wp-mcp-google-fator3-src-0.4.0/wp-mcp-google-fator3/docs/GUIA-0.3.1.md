# WP MCP Google Fator3 0.3.1

Esta atualização corrige a primeira gravação de `false` e oferece um contrato de configuração consultável pelos agentes. Preserva as funcionalidades da 0.3.0 e a correção do HTTP 411 no envio de sitemap. O escopo desta entrega é o plugin Google; o plugin Core não foi alterado.

## Instalação

No WordPress, envie **wp-mcp-google-fator3-0.3.1.zip** em Plugins → Adicionar plugin → Enviar plugin e substitua a versão instalada. Não desinstale antes: a desinstalação remove as configurações. A pasta do plugin, o callback OAuth e a URL do servidor MCP são preservados. Atualize a descoberta de habilidades no cliente para enxergar `google/configuration-schema`.

O pacote **src** contém código de desenvolvimento, testes, evidências e histórico Git. Ambos os pacotes incluem o script Google Cloud revisado e o original em `reference/`. As orientações de conexão, OAuth, service account, selftest, jobs e sitemap continuam em [GUIA-0.3.0.md](GUIA-0.3.0.md).

## Primeira gravação de false

`update_option()` pode devolver `false` sem criar uma opção ausente quando o valor solicitado também é `false`. O plugin agora consulta a existência da linha e usa `add_option()` para criar uma opção cuja ausência foi confirmada. Atualizações de linhas existentes continuam usando `update_option()`. As duas operações permanecem protegidas pela mesma trava e pela leitura de confirmação diretamente no banco.

| Situação | success | persisted | changed | error_code |
|---|---|---|---|---|
| Primeira gravação de `false`, linha criada e confirmada | true | true | true | null |
| Valor `false` já persistido | true | true | false | null |
| Inserção recusada, linha continua ausente | false | false | false | f3_google_option_persistence |
| Atualização recusada, valor esperado não confirmado | false | false | false | f3_google_option_persistence |

`changed:false` em uma falha significa que a mudança solicitada não foi confirmada; não é garantia de ausência de efeitos externos. `success` e `persisted` precisam ser conferidos primeiro. Exceções e falhas de leitura/criptografia conservam seus códigos específicos, descritos no guia anterior. Segredos continuam cifrados, verificados por decifra e ausentes dos resultados de gravação. O painel confere o resultado antes de informar que salvou.

## Consulta pelos agentes

Execute a habilidade **google/configuration-schema** pelas metatools já utilizadas no conector:

```json
{
  "contract_version": "1.0.0",
  "connection_id": "default",
  "include_values": true
}
```

Todos os campos de entrada são opcionais e têm os valores do exemplo como padrão. `connection_id` segue a regra geral do executor: usa a conexão ativa, que normalmente é `default`. Com `include_values:false`, a resposta contém apenas definições e operações, sem ler os valores das opções catalogadas. As leituras necessárias para autorização e seleção da conexão continuam ocorrendo.

A habilidade exige canal Google aberto e a capacidade administrativa configurada pelo plugin (`manage_options` por padrão). Não depende de credencial Google e não faz chamadas às APIs Google. Fechar o canal continua bloqueando a consulta. A consulta não altera configurações; sua execução pelo wrapper comum pode gerar auditoria.

### Campos da resposta

| Campo | Contrato |
|---|---|
| `success` | Consulta concluída e, quando solicitados, estados de valores sem falha de leitura/decifra. Não comprova acesso ao Google. |
| `contract_version` | Versão da interface, independente da versão do plugin: `1.0.0`. |
| `plugin.id`, `plugin.version` | Plugin responsável e versão em execução. |
| `connection_id` | Contexto dos valores específicos de uma conexão. |
| `definition_sha256` | SHA-256 das definições, operações e pré-requisitos; não inclui valores nem segredos. Serve para invalidar o cache das regras. |
| `values_included` | Informa se estados atuais foram solicitados. |
| `values_complete` | `true` se todos os estados foram obtidos; `false` se há falha; `null` quando os valores não foram solicitados. |
| `google_checks_performed` | Sempre `false` nesta habilidade. |
| `authorization` | Capacidade exigida, exigência de canal aberto e proibição de escrita genérica das opções. |
| `options` | Mapa dos 22 itens configuráveis ou derivados da configuração. Não inclui logs, locks, jobs, tokens de acesso ou caches. |
| `operations` | Operações existentes de consulta, configuração e painel, com schemas das habilidades obtidos do registro ativo. |
| `runtime_prerequisites` | Dependências para uso: canal, credenciais por modo, serviços, consentimento e acesso externo ainda não testado. |

### Cada opção

| Campo | Significado |
|---|---|
| Chave do mapa, como `ga_enabled` | Identificador estável dentro deste contrato. |
| `option_name` | Nome lógico da opção no plugin; não autoriza escrita direta por outro conector. |
| `scope` | `site` para configuração comum; `connection` para configuração da conexão selecionada. |
| `schema` | Tipo, valores permitidos, padrões e limites quando aplicáveis. Descreve o valor efetivo, não a representação serializada do WordPress. |
| `secret` | Conteúdo confidencial; nunca retornado. |
| `dependencies` | Condições locais para uso da opção; `applies_to:"use"` não proíbe preparar uma credencial antes de selecioná-la. |
| `allowed_operations` | Referências a `operations`. Operações do painel exigem capacidade e nonce; OAuth exige consentimento humano. |
| `mcp_mutable` | Alguma habilidade listada pode afetar este item. Não significa que exista atribuição genérica de um novo valor. |
| `write_semantics` | Semântica específica de substituição, mesclagem, limpeza ou produção por callback. |
| `activation_default` | Valor criado na ativação, quando diferente do fallback de leitura de uma opção ausente. |
| `state` | Estado atual, presente somente com `include_values:true`. |

Os limites numéricos são publicados a partir de `Options::LIMITS`, também usado pelo painel e pelo runtime. Os perfis e campos de configuração são derivados de `Setup::LEVELS` e `Setup::BINDING_RULES`, usados pelo planejamento e pela aplicação. Limites de conexão são compartilhados com `Connections`. O catálogo não cria um segundo validador no implantador: use os schemas retornados e `google/plan-configuration` para validar a proposta com as regras do plugin.

`schema.default` é o fallback quando a opção está ausente. Os três interruptores têm fallback `false`, mas a ativação inicial grava `true`; `activation_default` deixa essa diferença explícita. Filtros e normalização podem alterar o valor efetivo. Limites ausentes no schema não devem ser inventados pelo implantador; validadores de domínio e operações específicas continuam sendo a autoridade.

### Valores e segredos

Para opções comuns, `state` contém `read_success`, `exists`, `error_code`, `persisted_value`, `effective_value` e `using_default`. O valor persistido vem da leitura direta do banco; o efetivo usa os getters e filtros do plugin. O WordPress pode representar booleanos e números persistidos como strings. Uma opção ausente possui `exists:false`, `persisted_value:null` e `using_default:true`; uma linha existente com valor falso possui `exists:true`.

Em falha de leitura, `exists:null` representa existência desconhecida. Os campos de valor são omitidos e `error_code` identifica a falha. A resposta mantém as definições e os demais estados disponíveis.

Para segredos, há apenas `read_success`, `exists`, `error_code`, `redacted:true`, `configured` e `readable`. `configured:true` indica conteúdo armazenado não vazio; não comprova validade da credencial. `readable:true` indica decifra local bem-sucedida. Se ausente/vazio, `readable:null`; se a leitura do banco falhar, `configured:null`. Não são retornados texto puro, cifra, tamanho ou hash do segredo.

| Código | Situação |
|---|---|
| `f3_google_contract_version` | Versão não suportada; resposta inclui `supported_contract_versions`. |
| `f3_google_configuration_read` | Falha em algum estado; `values_complete:false`. |
| `state.error_code:f3_google_option_read` | Não foi possível consultar a linha. |
| `state.error_code:f3_google_crypto_decrypt` | Há segredo armazenado que não pôde ser decifrado. |
| `f3_google_disabled` / `f3_google_forbidden` | Canal fechado ou capacidade insuficiente. |
| `f3_google_connection` | Conexão inexistente. |

### Operações de escrita

`google/configure` continua aceitando apenas `services`, `bindings` e os controles do setup. Não aceita segredos, ativação geral ou opções arbitrárias. `services` substitui toda a seleção: omitir mantém, `{}` desativa todos os serviços. `bindings` mescla os campos: omitir mantém, string vazia limpa o campo. A configuração reflete também os interruptores GA/Ads e a propriedade GA padrão. `validate_access` tem padrão `true`; `false` permite preparar os vínculos antes de obter acesso.

As credenciais são importadas/configuradas no painel. Tokens e metadados OAuth são produzidos pelo callback; operações listadas podem limpá-los. Retenção da auditoria e orçamento de inspeções são opções internas de configuração do proprietário: o contrato informa seus limites/valores e a ausência de uma operação pública de escrita. Nenhuma rota `options/update` é liberada por esta entrega.

### Fluxo recomendado no implantador

1. Descobrir a habilidade no plugin e consultar o contrato com a versão suportada.
2. Conferir `success`, `values_complete`, estados e dependências; tratar erros por código.
3. Preparar a proposta usando as opções e operações anunciadas.
4. Enviar a proposta a `google/plan-configuration` e depois a `google/configure` quando a ação estiver autorizada.
5. Consultar novamente o contrato para conferir o estado efetivo e executar `google/preflight` para verificar acesso Google.

As definições podem ser cacheadas por plugin, versão do contrato e `definition_sha256`. Os valores devem ser consultados novamente por site/conexão após uma alteração. Não trate a resposta como um snapshot transacional: cada opção é lida separadamente.

A implementação cobre o Google. Para outros plugins, o mesmo padrão deve expor o catálogo do próprio plugin e suas operações existentes. O Core mencionado não foi modificado, pois seus fontes não fazem parte deste pacote.

## Evidências

Passaram 821 testes e 8.943 asserções, a sintaxe de 55 PHP de produção, 25 verificações WordPress/SQLite, três PUTs locais e nove cenários do script. A suíte completa e os resultados adicionais acompanham o pacote de fontes em `evidence/0.3.1/`. O teste `false-before.txt` registra a reprodução do defeito antes da correção; `native-options.json` registra o resultado corrigido, incluindo criação de linha, no-op, inserção recusada, lote, segredo e concorrência.

Os testes de opções usam funções reais do WordPress 6.9.4 para opções/cache/hooks com um adaptador SQLite descartável. Os testes da habilidade usam o suporte de testes do projeto. Não houve implantação em site, ensaio completo com MySQL/MariaDB ou chamada a contas Google reais. Os três caminhos de PUT vazio foram conferidos em HTTP local com Requests/Fsockopen, e o script foi exercitado com gcloud simulado.

[configuration-example.json](configuration-example.json) é uma resposta integral gerada com configuração fictícia sem credenciais. [configuration-definitions.json](configuration-definitions.json) é a mesma consulta sem valores. São referências reproduzíveis; o contrato do site deve ser consultado pela habilidade.
