# WP MCP Google Fator3 0.4.0 — configuração e atualização

Esta versão organiza a configuração em torno de **Service Account**, com OAuth de usuário em um painel separado. Cada conexão tem um método selecionado para execução; conexões diferentes podem usar métodos diferentes. Credenciais e métodos ativos da versão anterior são preservados na atualização.

## Atualizar

1. Envie **wp-mcp-google-fator3-0.4.0.zip** em Plugins → Adicionar plugin → Enviar plugin e escolha substituir a versão instalada.
2. Abra **Ferramentas → MCP Google**, ou o link **Configurações** na lista de plugins.
3. Confira a conexão, a identidade e os recursos existentes. Uma conexão OAuth existente abre seu próprio painel; Service Account permanece como primeira opção da interface.
4. Em **Diagnóstico**, execute **Testar acessos agora** e confira cada resultado. Essa ação consulta os serviços configurados; a atualização e a simples abertura das telas não executam consultas Google.

Atualize por substituição, sem desinstalar: o desinstalador remove credenciais e configurações. O ZIP `src` contém fontes, testes e evidências e não é o instalador.

A pasta e o arquivo principal permanecem `wp-mcp-google-fator3/wp-mcp-google-fator3.php`. O callback continua `/wp-json/wp-mcp-google-fator3/v1/oauth/callback`. Este complemento utiliza o servidor MCP já instalado; a mudança de URL do transporte pertence ao WP MCP Fator3 e não faz parte desta entrega Google.

Autorizações OAuth iniciadas antes da atualização devem ser reiniciadas: seus estados antigos não possuem a revisão de configuração exigida na 0.4.0. Tokens já gravados são preservados.

## As quatro áreas

| Área | O que configurar |
|---|---|
| Conexão | Selecionar conexão, importar chave, conceder acesso e ativar Service Account. OAuth de usuário fica em uma aba própria. |
| Serviços e recursos | Escolher serviços e níveis de operação, selecionar propriedades/contas/planilha e preencher credenciais adicionais do Ads. |
| Diagnóstico | Testar autenticação e recursos; consultar data, conexão, resultado e próxima ação. |
| Avançado | Permitir/bloquear chamadas no site, ajustar limites, consultar auditoria e expandir o contrato técnico. |

As opções têm explicações junto aos campos. Ajuda extensa, JSON, delegação Workspace, informações técnicas e ações de remoção ficam em áreas expansíveis. A chave privada, Client secret, developer token, refresh token e access token não são reexibidos no HTML. O contrato também oculta segredos.

A navegação e os formulários funcionam sem JavaScript. Os botões Copiar, os campos condicionais sem recarregamento e o aviso de alterações pendentes usam JavaScript como complemento. Se a área de transferência estiver indisponível, o conteúdo é selecionado para cópia manual.

## Configurar com Service Account

1. Na conexão desejada, abra **Service Account · padrão**.
2. Em **Como criar o projeto e a chave no Google Cloud**, consulte a orientação e baixe o script de referência, se necessário. O download não o executa. O script revisado e o original histórico continuam incluídos no pacote.
3. Importe o JSON da conta de serviço. O limite é **1 MiB**, tanto no upload quanto na opção **Colar JSON**. O arquivo é validado e cifrado; não é publicado na biblioteca de mídia.
4. Use **Salvar** para preparar e retomar depois, ou **Salvar e usar Service Account** para validar a autenticação e ativar. Uma primeira chave apenas salva permanece com ativação pendente.
5. Copie o e-mail exibido e conceda acesso nos recursos Google. As permissões do projeto Cloud não concedem automaticamente acesso ao Analytics, Ads, Search Console ou planilhas.
6. Escolha serviços e recursos e execute o diagnóstico. A emissão de token confirma autenticação; o acesso a cada recurso é verificado separadamente.

Se a chave já foi salva, **Usar Service Account** ativa essa credencial após validar a autenticação. Campo de segredo vazio preserva o valor existente. Para remoção, use a ação explícita na seção correspondente.

A delegação do Workspace continua opcional e recolhida. No uso direto, deixe o usuário representado vazio. Para delegação, configure também as autorizações administrativas necessárias no Workspace.

### O que acontece ao trocar de método

- Abrir a outra aba apenas muda o formulário exibido.
- Preparar credenciais do método alternativo preserva o método selecionado para execução.
- **Usar Service Account** e **Usar OAuth** efetuam a troca explicitamente, após validação de autenticação.
- Falha de validação ou gravação impede a troca; erros de compensação de gravação são apresentados quando houver restauração incompleta.
- Não existe fallback automático entre identidades.
- A troca invalida o uso dos caches anteriores. Os IDs de recursos são preservados, e verificações anteriores ficam desatualizadas.
- Salvar uma substituição da credencial do método que já está em uso atualiza essa credencial. Para testar a candidata antes de gravar, use **Salvar e usar Service Account**.

## Serviços, permissões e recursos

Cada serviço tem um único seletor de nível. Desativado bloqueia o serviço; leitura, escrita e administração seguem os perfis disponíveis. A seleção local não concede permissões no Google. Os interruptores legados de GA4 e Ads são sincronizados com esses cartões.

| Recurso | Como preencher |
|---|---|
| Propriedade GA4 | Selecione uma sugestão ou informe o ID numérico. Não use o Measurement ID `G-…`. O campo sincroniza o vínculo e a opção legada. |
| Conta Google Ads | Informe a conta de anúncios consultada. IDs com hífens são normalizados. O ID da administradora/MCC fica em campo separado. |
| Search Console | Use a propriedade exata, como `sc-domain:exemplo.com.br` ou `https://exemplo.com.br/`. Os dois formatos não são intercambiáveis. |
| Planilha | Informe o ID ou cole uma URL HTTPS de planilha em `docs.google.com`; o painel extrai o ID. |
| Sitemap | Informe a URL completa. Quando disponível, o painel sugere o sitemap do WordPress/Yoast; salvar a seleção não envia o sitemap. |

**Consultar recursos acessíveis** alimenta as sugestões com nome e ID. Não seleciona o primeiro resultado nem cria recursos. Lista vazia, erro e consulta incompleta têm mensagens distintas. A descoberta de planilhas oferece próxima página quando retornada pelo Google; a página consultada alimenta as sugestões atuais. A entrada manual continua disponível.

Os resultados de descoberta são associados ao usuário, conexão e revisão da configuração. Mudanças invalidam sua utilização como sugestões atuais. Configurações GA4 legadas divergentes aparecem com orientação para conciliação explícita.

No Ads, o developer token continua sendo uma credencial adicional, aplicável aos dois métodos de autenticação. A versão da API fica em detalhes avançados. O padrão `v25` foi mantido após consulta à [tabela oficial de versões e descontinuação](https://developers.google.com/google-ads/api/docs/sunset-dates), em 14/09/2026. O painel valida o formato da versão; isso não comprova disponibilidade de uma versão arbitrária.

Para Sheets/Drive, compartilhe uma planilha existente com a identidade usada. Uma Service Account direta não pode ser proprietária de arquivos nem possui cota de armazenamento; criação exige destino adequado em Drive compartilhado ou outro fluxo já suportado. Uma pasta comum compartilhada do Meu Drive não equivale a um Drive compartilhado. [Orientação oficial do Drive](https://developers.google.com/workspace/drive/api/guides/handle-errors#storagequotaexceeded).

## OAuth de usuário

O painel próprio reúne importação do cliente Web, entrada manual de Client ID/secret, callback copiável, autorização e permissões solicitadas/concedidas. A importação exige que o JSON corresponda ao método e contenha o callback exato desta instalação.

Salve a seleção de serviços antes de autorizar. **Conectar com Google** prepara a autorização. Ao retornar, use **Usar OAuth** para ativar quando necessário. O callback não altera o método selecionado; um retorno antigo ou concorrente é recusado.

Alterar Client ID ou Client secret remove a autorização anterior vinculada a esse cliente, exigindo nova conexão. Deixar o segredo vazio preserva o valor salvo. A desconexão local mantém os dados do aplicativo; a revogação no Google é uma ação separada, com seu alcance explicado na tela.

## Salvamento e concorrência

O painel utiliza confirmação de persistência e informa resultados diferentes para configuração salva, valor já igual e falha. O caso de primeira gravação de `false` em opção ausente continua corrigido. Segredos iguais não são recifrados desnecessariamente.

A revisão de configuração acompanha os formulários. Se outro administrador, aba ou agente alterar a configuração antes do envio, a gravação pode ser recusada com `f3_google_configuration_conflict`. Recarregue, confira os valores persistidos e reaplique a intenção. Isso evita substituir uma alteração mais recente silenciosamente.

As gravações públicas compartilham uma trava de configuração do site e da conexão. A validação de token ocorre fora da trava e confere novamente a revisão antes de gravar. Códigos de falha de persistência, cifra e leitura permanecem estruturados; o painel não anuncia sucesso nesses casos. Valores editáveis não sigilosos são preservados para correção quando possível.

## Diagnóstico e limites

Os resultados do painel são isolados por usuário e conexão, com data e revisão. Após mudança, a tela identifica o resultado anterior como desatualizado. Os estados incluem aprovado, falhou, ignorado e não configurado. Sem execução, aparece a orientação para testar.

O contrato de `google/selftest` preserva a separação entre execução e aprovação: uma reprovação permanece reconhecível por máquina, sem depender do texto da mensagem. Uma leitura aprovada não comprova todas as permissões administrativas.

A detecção local do servidor MCP agora considera identificadores Fator3/legados e rotas reconhecidas. Sem evidência suficiente, informa **Detecção local inconclusiva**. Isso não afirma que o acesso externo está quebrado. Confirme o transporte pelo cliente MCP. A versão do WordPress aparece somente em informações técnicas.

| Limite do site | Padrão | Intervalo |
|---|---:|---:|
| Linhas por relatório | 1.000 | 1–10.000 |
| Tempo limite HTTP | 30 segundos | 5–120 segundos |
| Eventos de auditoria | 1.000 | 100–5.000 |
| Inspeções por propriedade em janela móvel de 24 h | 1.800 | 1–2.000 |

Os limites valem para todas as conexões do site. A inspeção mantém também o teto local de 500 por minuto; alterar o orçamento local não amplia a cota do Google. Reduzir a retenção permite o descarte de eventos antigos na próxima limpeza automática.

## Contrato consultável pelos agentes

`google/configuration-schema` passa a responder **1.1.0** por padrão, com as mesmas 22 opções, metadados de interface (`ui`), limites compartilhados com os validadores, operações e valores seguros. A consulta explícita de **1.0.0** continua aceita e omite os novos metadados visuais.

```json
{"contract_version":"1.1.0","include_values":true,"connection_id":"default"}
```

A resposta inclui `configuration_revision`, lista de versões suportadas e `authentication` com método selecionado, `configured`, `activation_pending` e exclusividade por conexão. `activation_pending` identifica a credencial cuja ativação foi adiada; configurações legadas não passam a exigir ativação novamente. `configured` não representa homologação ao vivo dos recursos.

Para agentes que apenas precisam das definições:

```json
{"contract_version":"1.1.0","include_values":false}
```

Nesse caso não são lidos valores, e `configuration_revision` é `null`. Segredos retornam somente estado de presença/legibilidade quando os valores são solicitados.

`google/configure` aceita `expected_revision` opcional. Consulte o contrato e envie a revisão concreta ao aplicar a alteração. Se `validate_access` for omitido, continua `true`; `false` permite preparar vínculos antes do acesso Google. Campos omitidos preservam valores; string vazia limpa um vínculo. A seleção `services` enviada substitui o conjunto selecionado.

As credenciais continuam configuradas pelo painel e pelo fluxo OAuth; não foi aberta uma operação genérica de escrita de opções. A consulta MCP mantém a capacidade exigida e o canal habilitado. O administrador autorizado pode consultar o contrato em Avançado mesmo com as chamadas Google bloqueadas.

Exemplos integrais, gerados sem credenciais reais: `docs/configuration-example.json` e `docs/configuration-definitions.json` no pacote.

## Validação desta entrega

- **858 testes PHPUnit e 9.173 asserções** em PHP 8.3.6/PHPUnit 9.6.17, incluindo 37 testes novos de autenticação, concorrência, UX e contrato.
- **34 verificações de persistência/configuração** com funções reais de opções, cache e hooks do WordPress 6.9.4 e adaptador SQLite. Incluem as 25 verificações anteriores, `false` inicial, segredos iguais, revisão obsoleta, restauração de lote e isolamento de conexão.
- **Três PUTs vazios** pelo transporte Requests 2.0.11 real contra servidor local: `gsc/submit-sitemap`, `gsc/add-site` e `google/execute-action` mantiveram corpo vazio, `Content-Length: 0` e HTTP 204.
- **92 arquivos PHP** aprovados na verificação sintática, sendo 60 de produção.
- **12 combinações de tela/largura** em Chrome for Testing 151: seis telas a 1.360 e 390 px, sem transbordamento, IDs repetidos, formulários aninhados ou erros JavaScript. Sete verificações interativas cobrem isolamento dos métodos, cópia, expansão, campos de serviço, contexto da conexão, ausência de JavaScript e teclado.

A verificação de UI usou os renderizadores, CSS e JavaScript de produção com dados sintéticos e CSS real do WordPress; não foi uma instalação completa de wp-admin. As APIs Google foram simuladas. Não houve implantação em produção, acesso a contas Google reais, homologação com MySQL/MariaDB, leitores de tela ou outros navegadores. O pacote-fonte inclui runners, evidências, HTMLs e capturas; não inclui credenciais reais.
