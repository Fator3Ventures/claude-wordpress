# Histórico

## 0.4.0 — 2026-09-14

- Reorganiza configuração em quatro áreas com ajuda contextual, navegação responsiva e formulários utilizáveis sem JavaScript.
- Prioriza Service Account em conexões novas; preserva OAuth existente e separa os métodos por painel.
- Separa preparação e ativação explícita, com validação de token e revisão contra alterações concorrentes.
- Impede callback OAuth antigo de sobrescrever configuração recente; preserva feedback ao administrador após retorno REST.
- Centraliza gravações verificadas; valor igual, falha, restauração e campo omitido possuem tratamento distinto.
- Unifica controles de serviço e GA4 padrão; oferece sugestões de recursos, entrada manual e detecção de sitemap.
- Isola diagnóstico e descoberta por usuário, conexão e revisão. Corrige afirmação indevida de ausência de servidor MCP.
- Expõe edição dos quatro limites e contrato 1.1.0 com metadados de interface; mantém consulta explícita 1.0.0.
- Preserva criptografia, múltiplas conexões, selftest e correção do PUT vazio.
- Validação: 858 testes e 9.173 asserções; 34 verificações WordPress/SQLite; três PUTs HTTP; 12 combinações de tela/largura em Chrome, com sete verificações interativas. Google simulado; sem implantação em produção.

## 0.3.1 — 2026-09-14

- Corrige primeira gravação de `false` em opção ausente: usa `add_option()` após leitura de existência, sob trava, com confirmação direta no banco.
- Preserva sucesso sem alteração para valores já iguais; inserção recusada continua retornando `f3_google_option_persistence`.
- Acrescenta `google/configuration-schema`, contrato `1.0.0` com 22 opções/itens derivados, escopo, tipos, limites, valores atuais seguros, dependências e operações permitidas.
- Reutiliza limites de `Options`, perfis e validadores de `Setup`, limites de `Connections` e schemas do registro ativo de habilidades.
- Distingue valor ausente, valor efetivo, leitura não confirmada e segredo indecifrável. Não expõe segredos, cifras ou hashes de credenciais.
- Total: 132 habilidades (47 leituras, 85 escritas). Não modifica o Core nem libera escrita genérica de opções.
- Validação: 821 testes, 8.943 asserções; 25 verificações WordPress/SQLite, três PUTs em HTTP local e nove cenários Cloud Shell simulados.

## 0.3.0 — 2026-09-13

- Corrige selftest: execução, aprovação e verificações puladas têm campos distintos; reprovação não é sobrescrita por Response::ok().
- Adiciona gravações verificadas, confirmação direta no banco, resultados por operação, erros de cifra e compensação de lotes; painel e OAuth conferem persistência.
- Cifra access tokens no cache, invalida cache legado e serializa renovação.
- Separa desconexão local e revogação OAuth explícita; preserva configuração do cliente.
- Adiciona seleção de serviços/perfis, importação de credenciais, configuração assistida e até 20 conexões locais.
- Acrescenta diagnóstico por recurso, telemetria HTTP sem corpos/segredos, Retry-After, classificação de quota e orçamento de tentativas.
- Substitui auditoria em lista única por registros independentes com inserção exclusiva e retenção configurável.
- Acrescenta sitemap acompanhado, inspeção em lote com cache/cota/prioridade, jobs persistentes, agendas e seis modelos de relatório.
- Preserva PUT vazio com Content-Length: 0 e todas as habilidades anteriores. Total: 131 habilidades (46 leituras, 85 escritas).
- Inclui script Cloud Shell revisado e original de referência; projeto explícito, reuso de chaves e rotação opt-in.
- Validação: 805 testes, 8.730 asserções; 20 verificações com funções WordPress/SQLite, três PUTs por HTTP local e nove cenários Cloud Shell simulados.

## 0.2.1 — 2026-09-09

- Corrige HTTP 411 em `gsc/submit-sitemap`: o cliente HTTP envia `Content-Length: 0` em PUT com corpo vazio.
- Aplica a correção também a `gsc/add-site` e a métodos PUT sem corpo executados por `google/execute-action`.
- Preserva corpos JSON, formulários e uploads com conteúdo; mantém o contrato sem corpo da Search Console.
- Inclui testes de regressão e reprodução HTTP local com o transporte Requests/Fsockopen do WordPress.

## 0.2.0 — 2026-09-08

- Preserva as 21 habilidades e configurações da 0.1.0; acrescenta 93 habilidades.
- Adiciona Search Console, Site Verification, GA Admin em escrita, Ads em escrita, Measurement Protocol, blend e exportação para Sheets/Drive.
- Expõe catálogo e executor baseados em nove documentos oficiais, com 521 métodos no conjunto validado.
- Acrescenta anotações de escrita, auditoria before/after redigida, validateOnly Ads, erros acionáveis e diagnóstico de APIs/escopos.
- Resolve contas por nome e wildcard; inclui conversões customizadas Ads, catálogos completos e isolamento de caches por credencial/delegação.
- Corrige colisão de IDs numéricos em fanout, paginação incompleta/cíclica, repetição indevida de gravações e codificação de objetos JSON vazios.
- Conserva integração com as três metatools e URL do servidor WP MCP Fator3.

## 0.1.0 — base recebida

21 habilidades de leitura Analytics/Ads/camada unificada, service account e OAuth de usuário, cifra, configuração administrativa, portão geral e auditoria de metadados.
