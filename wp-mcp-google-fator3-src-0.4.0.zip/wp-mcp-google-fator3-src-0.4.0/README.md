# WP MCP Google Fator3 — fontes 0.4.0

Use **wp-mcp-google-fator3-0.4.0.zip** para atualizar pelo painel WordPress. Este pacote `src` contém desenvolvimento, documentação e evidências; não é o ZIP de instalação.

- `wp-mcp-google-fator3/`: plugin e testes. O guia atual está em `docs/GUIA-0.4.0.md`.
- `docs/configuration-example.json` e `configuration-definitions.json`, dentro do plugin: contrato 1.1.0 gerado sem credenciais reais. A consulta explícita de 1.0.0 continua suportada.
- `googlecloudscript.txt`: script Cloud Shell revisado. Original em `reference/googlecloudscript-original.txt`; ambos também acompanham o instalador em `reference/`.
- `abilities-manifest.json` e `CATALOGO-HABILIDADES.md`: 132 habilidades e contratos.
- `evidence/0.4.0/`: evidências atuais, incluindo HTMLs e capturas das telas. As pastas de outras versões são históricas.
- `integration/`: runners reproduzíveis. Não usam credenciais Google reais.
- `skill/`: orientação legada recebida com a base; não foi instalada nem modificada. Os schemas e o guia 0.4.0 descrevem o contrato atual.
- `source-history.bundle`: histórico Git local da importação da base 0.3.1 e da entrega 0.4.0, com tag `v0.4.0`. Não houve push nem implantação remota.
- `PROVENANCE.json`: origem, versão, validação e hashes dos arquivos de produção e do instalador.

## Reprodução

Plugin requer PHP 8.0+. Suíte executada em PHP 8.3.6/PHPUnit 9.6.17. Com as dependências de desenvolvimento instaladas:

```bash
cd wp-mcp-google-fator3
composer install
composer test
```

Na raiz do pacote:

```bash
php integration/native-configuration.php /caminho/wordpress /caminho/wp-mcp-google-fator3 /tmp/google-options-unico.sqlite
python3 integration/empty-put-wire.py --php /caminho/php --plugin /caminho/wp-mcp-google-fator3 --requests /caminho/wordpress/wp-includes/Requests
php integration/export-manifest.php /caminho/wp-mcp-google-fator3
php integration/export-configuration.php /caminho/wp-mcp-google-fator3
php integration/render-admin.php /caminho/wp-mcp-google-fator3 /caminho/wordpress /tmp/google-ui
```

`native-configuration.php` inclui as verificações de `native-options.php` e requer PDO SQLite, OpenSSL e uma base descartável nova em cada execução. Usa funções reais do WordPress de opções/cache/hooks e um adaptador SQL SQLite; não substitui uma instalação completa com MySQL/MariaDB. O runner HTTP usa Requests real contra localhost, com Google simulado.

Para os testes de navegador, instale Playwright, aponte `CODEX_PRIMARY_RUNTIME_NODE_MODULES` para o diretório `node_modules` e execute `node integration/check-admin.cjs /tmp/google-ui`. Use `F3_CHROMIUM` se desejar um executável Chromium/Chrome externo. A suíte desta entrega usou Chrome for Testing 151.0.7922.34. As prévias utilizam renderizadores e assets de produção com dados fictícios e CSS do WordPress; o ambiente externo de wp-admin é simplificado.

Validação 0.4.0: **858 testes, 9.173 asserções; 34 verificações WordPress/SQLite; três PUTs em HTTP local; 92 PHP com sintaxe válida (60 de produção); 12 combinações de tela/largura e sete verificações interativas no navegador**. O script Cloud Shell é idêntico ao já validado na 0.3.1. Nenhuma conta Google real foi acessada. Veja o guia para comportamento, migração e limites.
