# Fator3 Site Core 1.92.0 — leia primeiro

Versão 1.92.0. A agenda própria cobre todos os ganchos f3base_ e preserva vetos com WP Activity Log 5.7.0. O catálogo usa nomes comerciais de outros modelos do mesmo Device e famílias regionais comprovadas. Consulte RELEASE-1.92.0.md.

Instalação nova ou atualização da 1.91.0. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.44.0.

