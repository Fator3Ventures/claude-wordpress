<?php
/**
 * Public, versioned Search Console reader for registered local plugins.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;

use Fator3\McpGoogle\{
	Ability, Audit, Auth\Credentials, Automation\Execution, Connections, Crypto, Gate, Http\GoogleClient, Options, Policy, Records, Response, Settings, Storage\Admission, Storage\Migration
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class ServiceApi {
	public const CONTRACT           = 'search-console-reader/1.0.0';
	public const VERSION            = '1.0.0';
	public const CAPABILITY         = 'gsc.page-day.read';
	public const GRANTS             = 'f3_mcp_google_consumer_grants';
	public const MAX_LIMIT          = 5000;
	public const MAX_BUDGET_MS      = 20000;
	private static array $consumers = array();
	public static function init(): void {
		add_action( 'plugins_loaded', array( self::class, 'discover' ), 30 );
	}
	public static function discover(): void {
		do_action( 'f3_mcp_google_register_consumers', new self(), self::CONTRACT );
	}
	public static function capabilities(): array {
		return array(
			'contract'            => self::CONTRACT,
			'contract_version'    => self::VERSION,
			'plugin_version'      => F3_MCP_GOOGLE_VERSION,
			'registration_hook'   => 'f3_mcp_google_register_consumers',
			'client_methods'      => array( 'query', 'status', 'effective_status' ),
			'capabilities'        => array( self::CAPABILITY ),
			'input_schema'        => self::schema(),
			'max_budget_ms'       => self::MAX_BUDGET_MS,
			'return_margin_ms'    => 2000,
			'limit_max'           => min( self::MAX_LIMIT, Options::max_rows() ),
			'calendar'            => 'America/Los_Angeles',
			'all_rows_guaranteed' => false,
		);
	}
	public static function schema(): array {
		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'required'             => array( 'contract_version', 'property', 'consumer_revision', 'date', 'run_id', 'trigger', 'budget_ms' ),
			'properties'           => array(
				'contract_version'  => array(
					'type' => 'string',
					'enum' => array( self::VERSION ),
				),
				'property'          => array(
					'type'      => 'string',
					'minLength' => 1,
					'maxLength' => 512,
				),
				'consumer_revision' => array(
					'type'      => 'string',
					'minLength' => 1,
					'maxLength' => 128,
				),
				'date'              => array(
					'type'    => 'string',
					'pattern' => '^\\d{4}-\\d{2}-\\d{2}$',
				),
				'limit'             => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => min( self::MAX_LIMIT, Options::max_rows() ),
					'default' => min( 1000, Options::max_rows() ),
				),
				'cursor'            => array(
					'type'      => array( 'string', 'null' ),
					'maxLength' => 4096,
				),
				'run_id'            => array(
					'type'      => 'string',
					'minLength' => 1,
					'maxLength' => 100,
					'pattern'   => '^[A-Za-z0-9._:-]+$',
				),
				'trigger'           => array(
					'type' => 'string',
					'enum' => array( 'cli', 'http_cron', 'manual' ),
				),
				'budget_ms'         => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => self::MAX_BUDGET_MS,
				),
			),
		);
	}
	/** $configuration returns {property:string,revision:string,ready:bool}. */
	public static function register_consumer( string $id, string $version, string $contract, callable $configuration ) {
		if ( ! preg_match( '/^[a-z][a-z0-9-]{1,79}$/D', $id ) || ! preg_match( '/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/D', $version ) ) {
			return new \WP_Error( 'f3_google_consumer_input', 'Identidade/versão do consumidor inválida.' );
		}
		if ( self::CONTRACT !== $contract ) {
			return new \WP_Error( 'f3_google_consumer_contract', 'Contrato de consumidor incompatível.' );
		}
		if ( isset( self::$consumers[ $id ] ) ) {
			return new \WP_Error( 'f3_google_consumer_duplicate', 'Consumidor já registrado.' );
		}
		$client                 = new ConsumerClient();
		self::$consumers[ $id ] = array(
			'id'            => $id,
			'version'       => $version,
			'configuration' => $configuration,
			'client'        => $client,
		);
		return $client;
	}
	private static function find( ConsumerClient $client ): ?array {
		foreach ( self::$consumers as $consumer ) {
			if ( $consumer['client'] === $client ) {
				return $consumer;
			}
		}
		return null;
	}
	private static function config( array $consumer ) {
		try {
			$c = ( $consumer['configuration'] )();
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'f3_google_consumer_configuration', 'Consumidor não forneceu configuração válida.' );
		}
		if ( ! is_array( $c ) || ! is_bool( $c['ready'] ?? null ) ) {
			return new \WP_Error( 'f3_google_consumer_configuration', 'Callback exige propriedade, revisão e prontidão.' );
		}
		if ( ! $c['ready'] ) {
			return new \WP_Error(
				'f3_google_consumer_not_ready',
				'Estrutura/configuração do consumidor ainda não está pronta.',
				array(
					'retryable'      => true,
					'retry_after_ms' => 15000,
				)
			);
		}
		if ( ! is_string( $c['property'] ?? null ) || ! self::valid_property( $c['property'] ) || ! is_string( $c['revision'] ?? null ) || strlen( $c['revision'] ) < 1 || strlen( $c['revision'] ) > 128 ) {
			return new \WP_Error( 'f3_google_consumer_configuration', 'Propriedade ou revisão inválida no consumidor.' );
		}
		return array_intersect_key( $c, array_flip( array( 'property', 'revision', 'ready' ) ) );
	}
	public static function valid_property( string $p ): bool {
		if ( strlen( $p ) > 512 || preg_match( '/[\x00-\x20]/', $p ) ) {
			return false;
		}
		if ( str_starts_with( $p, 'sc-domain:' ) ) {
			return (bool) preg_match( '/^sc-domain:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9-]{2,63}$/Di', $p );
		}
		$url = wp_parse_url( $p );
		return is_array( $url ) && in_array( $url['scheme'] ?? '', array( 'http', 'https' ), true ) && ! empty( $url['host'] ) && ! isset( $url['user'] ) && ! isset( $url['pass'] ) && ! isset( $url['query'] ) && ! isset( $url['fragment'] );
	}
	private static function grants() {
		$r = Options::stored( Options::storage_name( self::GRANTS ) );
		if ( ! $r['success'] || ( $r['exists'] && ! is_array( $r['value'] ) ) ) {
			return new \WP_Error( 'f3_google_consumer_grants_read', 'Autorizações ilegíveis.' );
		}
		return $r['value'] ?? array();
	}
	private static function guard( array $consumer, array $configuration, string $revision, array $grant ): ?\WP_Error {
		$recovery = \Fator3\McpGoogle\Recovery::guard();
		if ( $recovery ) {
			return $recovery;
		}
		if ( ! Options::is_enabled() ) {
			return new \WP_Error( 'f3_google_disabled', 'Google desativado.' );
		}
		if ( Migration::paused() || ( Transition::status()['state'] ?? '' ) !== 'completed' ) {
			return new \WP_Error(
				'f3_google_consumer_transition',
				'Transição/armazenamento pendente.',
				array(
					'retryable'      => true,
					'retry_after_ms' => 15000,
				)
			);
		}
		if ( ! Connections::enabled( 'gsc' ) ) {
			return new \WP_Error( 'f3_google_connector_off', 'Search Console desativado.' );
		}
		$grants = self::grants();
		if ( is_wp_error( $grants ) ) {
			return $grants;
		}
		if ( ( $grants[ $consumer['id'] ] ?? null ) !== $grant || empty( $grant['enabled'] ) || ( $grant['capability'] ?? '' ) !== self::CAPABILITY ) {
			return new \WP_Error( 'f3_google_consumer_unauthorized', 'Consumidor sem concessão vigente nesta conexão.' );
		}
		$now = self::config( $consumer );
		if ( is_wp_error( $now ) ) {
			return $now;
		}
		if ( $now !== $configuration ) {
			return new \WP_Error( 'f3_google_consumer_changed', 'Configuração do consumidor mudou; reinicie a página.' );
		}
		$current = Settings::execution_revision();
		if ( is_wp_error( $current ) ) {
			return $current;
		}
		if ( ! hash_equals( $revision, $current ) ) {
			return new \WP_Error( 'f3_google_context_changed', 'Credencial ou política mudou durante a consulta.' );
		}
		if ( ! Policy::permitted( 'gsc', $configuration['property'] ) ) {
			return new \WP_Error( 'f3_google_policy', 'Propriedade fora da política da conexão.' );
		}
		$credentials = Credentials::current();
		return is_wp_error( $credentials ) ? $credentials : null;
	}
	public static function query( ConsumerClient $client, array $input ): array {
		$consumer = self::find( $client );
		if ( ! $consumer ) {
			return self::failure( new \WP_Error( 'f3_google_consumer_unregistered', 'Cliente não registrado.' ) );
		}
		$error = self::validate_input( $input );
		if ( $error ) {
			return self::failure( $error );
		}
		return Execution::run( static fn()=>self::authorized_query( $consumer, $input ), $input['budget_ms'] / 1000 );
	}
	private static function authorized_query( array $consumer, array $input ): array {
		$cfg = self::config( $consumer );
		if ( is_wp_error( $cfg ) ) {
			return self::failure( $cfg );
		}
		if ( $input['property'] !== $cfg['property'] || $input['consumer_revision'] !== $cfg['revision'] ) {
			return self::failure( new \WP_Error( 'f3_google_consumer_property', 'Consulta deve usar propriedade e revisão atuais do consumidor.' ) );
		}
		$resolved = self::resolve_grant( $consumer['id'] );
		if ( is_wp_error( $resolved ) ) {
			return self::failure( $resolved ); }
		if ( 'resolved' !== $resolved['resolution'] ) {
			return self::failure( new \WP_Error( 'f3_google_consumer_unauthorized', 'Autorize o consumidor em exatamente uma conexão.' ) );
		}
		$cid   = $resolved['connection_id'];
		$grant = $resolved['grant'];
		return Connections::run(
			$cid,
			static function () use ( $consumer, $cfg, $input, $grant ): array {
				$revision = Settings::execution_revision();
				if ( is_wp_error( $revision ) ) {
					return self::failure( $revision );
				}
				$guard = static fn()=>self::guard( $consumer, $cfg, $revision, $grant );
				$error = $guard();
				if ( $error ) {
					return self::failure( $error );
				}
				return Admission::run(
					'plugin:gsc.page-day.read',
					static fn()=>Execution::run(
						static fn()=>self::page( $consumer, $cfg, $input, $revision, $grant, $guard ),
						$input['budget_ms'] / 1000,
						$guard
					)
				);
			}
		);
	}
	private static function validate_input( array $i ): ?\WP_Error {
		$schema = self::schema();
		if ( array_diff( array_keys( $i ), array_keys( $schema['properties'] ) ) || array_diff( $schema['required'], array_keys( $i ) ) ) {
			return new \WP_Error( 'f3_google_consumer_input', 'Parâmetros ausentes ou não permitidos.' );
		}
		if ( ( $i['contract_version'] ?? '' ) !== self::VERSION ) {
			return new \WP_Error( 'f3_google_consumer_contract', 'Versão de contrato incompatível.' );
		}
		foreach ( array( 'property', 'consumer_revision', 'date', 'run_id', 'trigger' ) as $k ) {
			if ( ! is_string( $i[ $k ] ) ) {
				return new \WP_Error( 'f3_google_consumer_input', 'Tipo inválido: ' . $k );
			}
		}
		if ( ! in_array( $i['trigger'], array( 'cli', 'http_cron', 'manual' ), true ) || ! preg_match( '/^[A-Za-z0-9._:-]{1,100}$/D', $i['run_id'] ) || ! is_int( $i['budget_ms'] ) || $i['budget_ms'] < 1 || $i['budget_ms'] > self::MAX_BUDGET_MS || ( isset( $i['limit'] ) && ( ! is_int( $i['limit'] ) || $i['limit'] < 1 || $i['limit'] > min( self::MAX_LIMIT, Options::max_rows() ) ) ) || ( isset( $i['cursor'] ) && ( ! is_string( $i['cursor'] ) || strlen( $i['cursor'] ) > 4096 ) ) ) {
			return new \WP_Error( 'f3_google_consumer_input', 'Origem, prazo, limite ou cursor inválido.' );
		}
		$d = \DateTimeImmutable::createFromFormat( '!Y-m-d', $i['date'], new \DateTimeZone( 'America/Los_Angeles' ) );
		if ( ! $d || $d->format( 'Y-m-d' ) !== $i['date'] || $d >= new \DateTimeImmutable( 'today', new \DateTimeZone( 'America/Los_Angeles' ) ) ) {
			return new \WP_Error( 'f3_google_consumer_date', 'Informe um dia passado válido no calendário Search Console.' );
		}
		return null;
	}
	private static function page( array $consumer, array $cfg, array $i, string $revision, array $grant, callable $guard ): array {
		$limit   = $i['limit'] ?? min( 1000, Options::max_rows() );
		$start   = 0;
		$binding = array( $consumer['id'], Connections::id(), $cfg['property'], $cfg['revision'], $i['date'], $limit, $revision, $grant['revision'] );
		if ( ! empty( $i['cursor'] ) ) {
			$plain = Crypto::decrypt( $i['cursor'] );
			$c     = is_string( $plain ) ? json_decode( $plain, true ) : null;
			if ( ! is_array( $c ) || ( $c['binding'] ?? null ) !== $binding || ( $c['expires'] ?? 0 ) < time() || ! is_int( $c['start'] ?? null ) || $c['start'] < 0 ) {
				return self::failure( new \WP_Error( 'f3_google_consumer_cursor', 'Cursor inválido, expirado ou de outro contexto.' ) );
			}
			$start = $c['start'];
		}
		$body    = array(
			'startDate'       => $i['date'],
			'endDate'         => $i['date'],
			'dimensions'      => array( 'date', 'page' ),
			'type'            => 'web',
			'dataState'       => 'final',
			'aggregationType' => 'auto',
			'rowLimit'        => $limit,
			'startRow'        => $start,
		);
		$request = Records::id();
		$ctx     = array(
			'actor'             => array(
				'type'    => 'plugin',
				'id'      => $consumer['id'],
				'version' => $consumer['version'],
			),
			'run_id'            => $i['run_id'],
			'trigger'           => $i['trigger'],
			'request_id'        => $request,
			'property'          => $cfg['property'],
			'consumer_revision' => $cfg['revision'],
			'body'              => $body,
			'http_attempts'     => 0,
			'query_dispatched'  => false,
		);
		return Context::run(
			$ctx,
			static function () use ( $cfg, $i, $body, $request, $binding, $start, $limit, $guard ): array {
				$common   = array(
					'contract_version'  => self::VERSION,
					'request_id'        => $request,
					'connection_id'     => Connections::id(),
					'property'          => $cfg['property'],
					'consumer_revision' => $cfg['revision'],
					'date'              => $i['date'],
					'run_id'            => $i['run_id'],
				);
				$deadline = Execution::check();
				if ( $deadline ) {
					return self::failure( $deadline, $common );
				}
				$before = Audit::append(
					'plugin:gsc.page-day.begin',
					$cfg['property'],
					array(
						'mode'   => 'read',
						'status' => 'started',
					)
				);
				if ( ! $before['success'] ) {
					return self::failure( new \WP_Error( 'f3_google_audit_persistence', 'Consulta suspensa: auditoria indisponível.' ), $common );
				}
				$raw                         = GoogleClient::post(
					GoogleClient::HOST_GOOGLE . '/webmasters/v3/sites/' . rawurlencode( $cfg['property'] ) . '/searchAnalytics/query',
					$body,
					array(
						'connector'    => 'gsc',
						'mode'         => 'read',
						'operation_id' => 'webmasters.searchanalytics.query',
						'scopes'       => array( 'https://www.googleapis.com/auth/webmasters.readonly' ),
						'retries'      => 0,
					)
				);
				$context                     = Context::current();
				$common['remote_dispatched'] = ! empty( $context['query_dispatched'] );
				$common['http_attempts']     = $context['http_attempts'];
				$error                       = is_wp_error( $raw ) ? $raw : $guard();
				$rows                        = array();
				if ( ! $error ) {
					if ( ( array_key_exists( 'responseAggregationType', $raw ) || ! empty( $raw['rows'] ) ) && ( $raw['responseAggregationType'] ?? null ) !== 'byPage' ) {
						$error = new \WP_Error( 'f3_google_consumer_response', 'Agregação inesperada; esperado por página.' );
					}
					if ( array_key_exists( 'rows', $raw ) && ! is_array( $raw['rows'] ) ) {
						$error = new \WP_Error( 'f3_google_consumer_response', 'Linhas inválidas.' );
					}
					foreach ( is_array( $raw['rows'] ?? null ) ? $raw['rows'] : array() as $r ) {
						if ( ! is_array( $r ) || ! is_array( $r['keys'] ?? null ) || count( $r['keys'] ) !== 2 || $r['keys'][0] !== $i['date'] || ! is_string( $r['keys'][1] ) || ( ! filter_var( $r['keys'][1], FILTER_VALIDATE_URL ) || ! in_array( wp_parse_url( $r['keys'][1], PHP_URL_SCHEME ), array( 'https', 'http' ), true ) ) ) {
							$error = new \WP_Error( 'f3_google_consumer_response', 'Dimensões inválidas.' );
							break;
						}
						foreach ( array( 'clicks', 'impressions', 'ctr', 'position' ) as $n ) {
							if ( ! isset( $r[ $n ] ) || ! is_numeric( $r[ $n ] ) || ! is_finite( (float) $r[ $n ] ) || $r[ $n ] < 0 ) {
								$error = new \WP_Error( 'f3_google_consumer_response', 'Métricas inválidas.' );
								break 2;
							}
						}
						$rows[] = array(
							'date'        => $r['keys'][0],
							'page'        => $r['keys'][1],
							'clicks'      => (float) $r['clicks'],
							'impressions' => (float) $r['impressions'],
							'ctr'         => (float) $r['ctr'],
							'position'    => (float) $r['position'],
						);
					}
					if ( count( $rows ) > $limit ) {
						$error = new \WP_Error( 'f3_google_consumer_response', 'Resposta excedeu o limite solicitado.' );
					}
				}
				$next    = null;
				$full    = count( $rows ) === $limit;
				$ceiling = $start + count( $rows ) >= 50000;
				if ( ! $error && $full && ! $ceiling ) {
					$next = Crypto::encrypt(
						wp_json_encode(
							array(
								'binding' => $binding,
								'start'   => $start + count( $rows ),
								'expires' => time() + 86400,
							)
						)
					);
					if ( ! $next ) {
						$error = new \WP_Error( 'f3_google_crypto_encrypt', 'Não foi possível criar cursor.' );
					}
				}
				$result = $error ? self::failure( $error, $common ) : Response::ok(
					$common + array(
						'extracted_at' => time(),
						'rows'         => $rows,
						'next_cursor'  => $next,
						'coverage'     => array(
							'limit'               => $limit,
							'returned_rows'       => count( $rows ),
							'pagination_complete' => ! $full,
							'truncated'           => $full,
							'truncation_reason'   => $full ? ( $ceiling ? 'api_daily_row_limit' : 'page_pending' ) : null,
							'all_rows_guaranteed' => false,
							'calendar'            => 'America/Los_Angeles',
							'data_state'          => 'final',
							'dimensions'          => array( 'date', 'page' ),
							'type'                => 'web',
							'aggregation'         => 'byPage',
							'start_row'           => $start,
							'filters'             => array(),
						),
					)
				);
				$after  = Audit::append(
					'plugin:gsc.page-day.end',
					$cfg['property'],
					array(
						'mode'       => 'read',
						'status'     => $result['success'] ? 'completed' : 'failed',
						'rows'       => count( $rows ),
						'error_code' => $result['error_code'] ?? null,
					)
				);
				if ( ! $after['success'] ) {
					return self::failure(
						new \WP_Error( 'f3_google_audit_incomplete', 'Consulta concluída; registro final não confirmado. Não avance o cursor.' ),
						$common + array(
							'query_result'  => $result,
							'audit_success' => false,
						)
					);
				}
				$result['audit_success'] = true;
				$saved                   = Options::set(
					'f3_mcp_google_consumer_last_' . Connections::id() . '_' . hash( 'sha256', Context::current()['actor']['id'] ),
					array(
						'at'         => time(),
						'success'    => $result['success'],
						'error_code' => $result['error_code'] ?? null,
						'request_id' => $request,
						'run_id'     => $i['run_id'],
						'rows'       => count( $rows ),
					)
				);
				if ( ! $saved['success'] ) {
					return self::failure( new \WP_Error( 'f3_google_consumer_state', 'Último atendimento não confirmado.' ), $common + array( 'query_result' => $result ) );
				}
				return $result;
			}
		);
	}
	private static function failure( \WP_Error $e, array $extra = array() ): array {
		$d      = (array) $e->get_error_data();
		$result = Response::fail(
			$e,
			$extra + array(
				'contract_version'  => self::VERSION,
				'retryable'         => (bool) ( $d['retryable'] ?? false ),
				'retry_after_ms'    => $d['retry_after_ms'] ?? ( isset( $d['retry_after'] ) ? (int) $d['retry_after'] * 1000 : null ),
				'next_eligible_at'  => $d['next_eligible_at'] ?? null,
				'remote_dispatched' => false,
			)
		);
		// Preserve the service correlation; an HTTP request id remains in details.
		if ( isset( $extra['request_id'] ) ) {
			$result['request_id'] = $extra['request_id'];
		}
		return $result;
	}
	/** Internal resolution reused by query and the optional local diagnostic. */
	private static function resolve_grant( string $id ) {
		$registry = Connections::registry_verified();
		if ( is_wp_error( $registry ) ) {
			return $registry; }
		$matches = array();
		foreach ( array_keys( $registry ) as $cid ) {
			$g = Connections::run( $cid, static fn()=>self::grants() );
			if ( is_wp_error( $g ) ) {
				return $g; }
			if ( ! is_array( $g ) || isset( $g['error_code'] ) || ( isset( $g[ $id ] ) && ( ! is_array( $g[ $id ] ) || ! is_bool( $g[ $id ]['enabled'] ?? null ) ) ) ) {
				return new \WP_Error( 'f3_google_consumer_grants_read', 'Autorizações ilegíveis.' );
			}
			if ( ! empty( $g[ $id ]['enabled'] ) ) {
				$matches[ $cid ] = $g[ $id ]; }
		}
		$resolution = count( $matches ) === 1 ? 'resolved' : ( $matches ? 'ambiguous' : 'not_granted' );
		return array(
			'resolution'    => $resolution,
			'connection_id' => 'resolved' === $resolution ? key( $matches ) : null,
			'grant'         => 'resolved' === $resolution ? current( $matches ) : null,
		);
	}
	public static function effective_status( ConsumerClient $client ): array {
		$consumer = self::find( $client );
		if ( ! $consumer ) {
			return self::failure( new \WP_Error( 'f3_google_consumer_unregistered', 'Cliente não registrado.' ) ); }
		$resolved = self::resolve_grant( $consumer['id'] );
		$out      = array(
			'contract'      => self::CONTRACT,
			'consumer_id'   => $consumer['id'],
			'resolution'    => 'unreadable',
			'connection_id' => null,
			'reason_codes'  => array(),
			'local_status'  => null,
			'checked_at'    => time(),
		);
		if ( is_wp_error( $resolved ) ) {
			$out['reason_codes'] = array( $resolved->get_error_code() );
			return $out;
		}
		$out['resolution']    = $resolved['resolution'];
		$out['connection_id'] = $resolved['connection_id'];
		if ( 'resolved' !== $out['resolution'] ) {
			$out['reason_codes'] = array( 'ambiguous' === $out['resolution'] ? 'f3_google_consumer_ambiguous' : 'f3_google_consumer_unauthorized' );
			return $out;
		}
		$out['local_status'] = Connections::run( $out['connection_id'], static fn()=>self::local_status( $consumer, $resolved['grant'] ) );
		return $out;
	}
	/** Explicit nested projections: stored arrays never pass through to another plugin. */
	private static function local_status( array $consumer, array $grant ): array {
		$cfg          = self::config( $consumer );
		$last         = Options::stored( 'f3_mcp_google_consumer_last_' . Connections::id() . '_' . hash( 'sha256', $consumer['id'] ) );
		$transition   = Transition::status();
		$recovery     = \Fator3\McpGoogle\Recovery::status();
		$last_service = null;
		$last_error   = null;
		if ( ! $last['success'] || ( $last['exists'] && ! is_array( $last['value'] ) ) ) {
			$last_error = 'f3_google_consumer_state_read';
		} elseif ( $last['exists'] ) {
			$v            = $last['value'];
			$last_service = array(
				'at'      => is_int( $v['at'] ?? null ) ? $v['at'] : null,
				'success' => is_bool( $v['success'] ?? null ) ? $v['success'] : null,
				'rows'    => is_int( $v['rows'] ?? null ) ? max( 0, $v['rows'] ) : null,
			);
			foreach ( array( 'run_id', 'request_id' ) as $k ) {
				$last_service[ $k ] = is_string( $v[ $k ] ?? null ) && preg_match( '/^[A-Za-z0-9._:-]{1,100}$/D', $v[ $k ] ) ? $v[ $k ] : null;
			}
			$last_service['error_code'] = self::diagnostic_code( $v['error_code'] ?? null );
		}
		$states   = Options::snapshot( array( Options::ENABLED, Options::storage_name( Connections::SERVICES ) ) );
		$revision = Settings::revision();
		$read_ok  = ! is_wp_error( $revision ) && ! in_array( false, array_column( $states, 'success' ), true );
		return array(
			'configuration'            => is_wp_error( $cfg ) ? array(
				'ready'      => false,
				'error_code' => $cfg->get_error_code(),
			) : $cfg,
			'grant'                    => array(
				'enabled'    => ( $grant['enabled'] ?? null ) === true,
				'capability' => ( $grant['capability'] ?? null ) === self::CAPABILITY ? self::CAPABILITY : null,
			),
			'transition'               => array(
				'state'      => in_array( $transition['state'] ?? null, array( 'pending', 'completed', 'failed', 'waiting_for_drain' ), true ) ? $transition['state'] : 'failed',
				'error_code' => self::diagnostic_code( $transition['error_code'] ?? null ),
			),
			'google_enabled'           => $read_ok ? Options::is_enabled() : null,
			'gsc_enabled'              => $read_ok ? Connections::enabled( 'gsc' ) : null,
			'configuration_error'      => $read_ok ? null : 'f3_google_option_read',
			'configured'               => $read_ok ? Credentials::is_configured() : null,
			'policy_allowed'           => $read_ok && ! is_wp_error( $cfg ) ? Policy::permitted( 'gsc', $cfg['property'] ) : null,
			'recovery'                 => array(
				'paused'     => is_bool( $recovery['paused'] ?? null ) ? $recovery['paused'] : null,
				'error_code' => self::diagnostic_code( $recovery['error_code'] ?? null ),
			),
			'last_service'             => $last_service,
			'last_service_error'       => $last_error,
			'remote_access_verified'   => false,
			'consumer_commit_verified' => false,
		);
	}
	private static function diagnostic_code( $value ): ?string {
		return is_string( $value ) && preg_match( '/^f3_[a-z0-9_]{1,95}$/D', $value ) ? $value : null;
	}
	public static function administrative_status( array $input = array() ): array {
		$revision = Settings::revision();
		if ( is_wp_error( $revision ) ) {
			return Response::fail(
				$revision,
				array(
					'contract'               => self::CONTRACT,
					'connection_id'          => Connections::id(),
					'configuration_revision' => null,
					'read_success'           => false,
				)
			);
		}
		if ( ! empty( $input['compact'] ) ) {
			return Response::ok(
				array(
					'contract'               => self::CONTRACT,
					'connection_id'          => Connections::id(),
					'configuration_revision' => $revision,
					'read_success'           => true,
					'compact'                => true,
				)
			);
		}
		return Response::ok(
			self::status() + array(
				'configuration_revision' => $revision,
				'read_success'           => true,
			)
		);
	}
	public static function client_status( ConsumerClient $client ): array {
		$c = self::find( $client );
		return $c ? self::status( $c['id'] ) : self::failure( new \WP_Error( 'f3_google_consumer_unregistered', 'Cliente não registrado.' ) );
	}
	public static function status( ?string $only = null ): array {
		$g     = self::grants();
		$items = array();
		foreach ( self::$consumers as $id => $c ) {
			if ( null !== $only && $id !== $only ) {
				continue;
			}
			$cfg     = self::config( $c );
			$items[] = array(
				'effective_status' => null === $only ? self::effective_status( $c['client'] ) : null,
				'id'               => $id,
				'version'          => $c['version'],
				'configuration'    => is_wp_error( $cfg ) ? array(
					'ready'      => false,
					'error_code' => $cfg->get_error_code(),
				) : $cfg,
				'grant'            => is_wp_error( $g ) ? null : ( $g[ $id ] ?? null ),
				'last_service'     => Options::get( 'f3_mcp_google_consumer_last_' . Connections::id() . '_' . hash( 'sha256', $id ), null ),
			);
		}
		return array(
			'contract'       => self::CONTRACT,
			'connection_id'  => Connections::id(),
			'consumers'      => $items,
			'grants_error'   => is_wp_error( $g ) ? $g->get_error_code() : null,
			'transition'     => Transition::status(),
			'google_enabled' => Options::is_enabled(),
			'configured'     => Credentials::is_configured(),
		);
	}
	public static function configure( array $input ): array {
		if ( ! current_user_can( 'manage_options' ) || ! current_user_can( Options::capability() ) ) {
			return self::failure( new \WP_Error( 'f3_google_forbidden', 'Permissão administrativa exigida.' ) );
		}
		$id      = $input['consumer_id'] ?? '';
		$enabled = $input['enabled'] ?? null;
		if ( ! is_string( $id ) || ! isset( self::$consumers[ $id ] ) || ! is_bool( $enabled ) || ! is_string( $input['expected_revision'] ?? null ) ) {
			return self::failure( new \WP_Error( 'f3_google_consumer_input', 'Consumidor, enabled e expected_revision são obrigatórios.' ) );
		}
		// Single site lock prevents two simultaneous grants on different connections.
		$lock = \Fator3\McpGoogle\Lock::acquire( 'consumer-grants', 30 );
		if ( ! $lock ) {
			return self::failure( new \WP_Error( 'f3_google_consumer_busy', 'Concessão em atualização.' ) );
		}
		try {
			if ( $enabled ) {
				foreach ( array_keys( Connections::registry() ) as $cid ) {
					if ( Connections::id() === $cid ) {
						continue;
					}
					$other = Connections::run( $cid, static fn()=>self::grants() );
					if ( is_wp_error( $other ) ) {
						return self::failure( $other );
					}
					if ( ! empty( $other[ $id ]['enabled'] ) ) {
						return self::failure( new \WP_Error( 'f3_google_consumer_connection', 'Revogue a concessão na outra conexão antes de transferir.' ) );
					}
				}
			}
			$grants = self::grants();
			if ( is_wp_error( $grants ) ) {
				return self::failure( $grants );
			}
			if ( ! isset( $grants[ $id ] ) || $grants[ $id ]['enabled'] !== $enabled ) {
				$grants[ $id ] = array(
					'enabled'    => $enabled,
					'capability' => self::CAPABILITY,
					'revision'   => bin2hex( random_bytes( 16 ) ),
					'at'         => time(),
				);
			}
			return Settings::save( array( self::GRANTS => $grants ), array(), array(), $input['expected_revision'] ) + array( 'integration' => self::status() );
		} finally {
			\Fator3\McpGoogle\Lock::release( $lock );
		}
	}
	public static function register(): void {
		Ability::register(
			'google/integration-status',
			'any',
			array(
				'label'         => 'Google: integração com plugins',
				'description'   => 'Contrato, revisão da conexão selecionada e consumidores. compact:true permite ler a revisão em uma resposta pequena, sem credenciais ou chamadas Google.',
				'input_schema'  => array(
					'properties' => array(
						'compact' => array(
							'type'    => 'boolean',
							'default' => false,
						),
					),
				),
				'output_schema' => array(
					'type'       => 'object',
					'properties' => array(
						'success'                => array( 'type' => 'boolean' ),
						'message'                => array( 'type' => 'string' ),
						'contract'               => array( 'type' => 'string' ),
						'connection_id'          => array( 'type' => 'string' ),
						'configuration_revision' => array( 'type' => array( 'string', 'null' ) ),
						'read_success'           => array( 'type' => 'boolean' ),
						'compact'                => array( 'type' => 'boolean' ),
						'consumers'              => array(
							'type'  => 'array',
							'items' => array( 'type' => 'object' ),
						),
					),
				),
				'callback'      => array( self::class, 'administrative_status' ),
			)
		);
		Ability::register(
			'google/configure-consumer',
			'any',
			array(
				'label'        => 'Google: autorizar consumidor',
				'description'  => 'Concede ou revoga leitura Search Console para plugin registrado nesta conexão. A propriedade é mantida pelo consumidor.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'consumer_id', 'enabled', 'expected_revision' ),
					'properties' => array(
						'consumer_id'       => array( 'type' => 'string' ),
						'enabled'           => array( 'type' => 'boolean' ),
						'expected_revision' => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'configure' ),
			)
		);
		Ability::register(
			'google/complete-transition',
			'any',
			array(
				'label'        => 'Google: concluir transição 0.6.0',
				'description'  => 'Desliga a importação antiga e preserva seu checkpoint; confirmação de drenagem não executa coleta.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => array(
						'acknowledge_drained' => array(
							'type'    => 'boolean',
							'default' => false,
						),
					),
				),
				'callback'     => static fn( $i )=>current_user_can( 'manage_options' ) ? Transition::advance( ! empty( $i['acknowledge_drained'] ) ) : self::failure( new \WP_Error( 'f3_google_forbidden', 'Permissão administrativa exigida.' ) ),
			)
		);
	}
}
