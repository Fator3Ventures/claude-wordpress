<?php
/**
 * Accessible operational forms backed by the same services exposed to agents.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;

use Fator3\McpGoogle\{
	Admin, Analytics\Profile, Audit, Automation\Alerts, Automation\Executor, Automation\Operations, Catalog, Confirmation, Connections, Crypto, Options, Policy, Response, Settings, Template, Updater
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class OperationsScreen {
	private const ACTION             = 'f3_google_operation';
	private static ?string $revision = null;
	private static int $field_number = 0;
	public static function init(): void {
		add_action( 'admin_post_' . self::ACTION, array( self::class, 'handle' ) );
	}
	private static function key(): string {
		return Admin::feedback_key( 'operation' );
	}
	private static function state(): array {
		$cipher = get_transient( self::key() );
		if ( ! is_string( $cipher ) ) {
			return array();
		}
		$plain = Crypto::decrypt( $cipher );
		return is_wp_error( $plain ) ? array() : ( json_decode( $plain, true ) ?? array() );
	}
	private static function form( string $operation ): void {
		if ( null === self::$revision ) {
			$revision       = Settings::revision();
			self::$revision = is_wp_error( $revision ) ? '' : $revision;
		}
		echo '<form class="f3-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		self::hidden( '_wpnonce', wp_create_nonce( self::ACTION ) );
		wp_referer_field();
		foreach ( array(
			'action'            => self::ACTION,
			'operation'         => $operation,
			'connection_id'     => Connections::id(),
			'section'           => Admin::section(),
			'expected_revision' => self::$revision,
		) as $name => $value ) {
			self::hidden( $name, $value );
		}
	}
	private static function hidden( string $name, string $value ): void {
		echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	private static function field( string $name, string $label, string $value, string $help, string $type = 'text' ): void {
		$id = 'f3-op-' . sanitize_key( $name ) . '-' . ( ++self::$field_number );
		echo '<div class="f3-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
		if ( 'textarea' === $type ) {
			echo '<textarea rows="5" name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" aria-describedby="' . esc_attr( $id ) . '-help">' . esc_textarea( $value ) . '</textarea>';
		} else {
			echo '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '" aria-describedby="' . esc_attr( $id ) . '-help">';
		}
		echo '<p class="description" id="' . esc_attr( $id ) . '-help">' . esc_html( $help ) . '</p></div>';
	}
	private static function check( string $name, string $label, bool $value, string $help ): void {
		echo '<p><label><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( $value, true, false ) . '> ' . esc_html( $label ) . '</label><br><span class="description">' . esc_html( $help ) . '</span></p>';
	}
	private static function button( string $label ): void {
		echo '<p><button class="button button-primary">' . esc_html( $label ) . '</button></p></form>';
	}
	private static function json( string $label, array $data ): void {
		$id = 'f3-operation-json-' . ( ++self::$field_number );
		echo '<details class="f3-details"><summary>' . esc_html( $label ) . '</summary><button type="button" class="button" data-copy-target="' . esc_attr( $id ) . '">Copiar JSON</button><pre id="' . esc_attr( $id ) . '" tabindex="0">' . esc_html( wp_json_encode( Audit::redact( $data ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details>';
	}
	/** A readable result is available without expanding the technical JSON. */
	private static function job_details( array $job ): void {
		$status = (string) ( $job['status'] ?? '' );
		$labels = array(
			'approval_required' => 'Aguardando aprovação',
			'pending'           => 'Pendente',
			'running'           => 'Em execução',
			'dispatching'       => 'Envio iniciado',
			'blocked'           => 'Bloqueado',
			'unknown'           => 'Resultado incerto',
			'failed'            => 'Falhou',
			'completed'         => 'Concluído',
			'cancelled'         => 'Cancelado',
			'reconciled'        => 'Reconciliado',
		);
		$label  = $labels[ $status ] ?? $status;
		if ( 'completed' === $status && ( ! empty( $job['summary']['failed'] ) || false === ( $job['result']['checks_passed'] ?? true ) ) ) {
			$label = 'Concluído, com verificações reprovadas';
		}
		$done  = (int) ( $job['summary']['processed'] ?? $job['cursor'] ?? 0 );
		$total = (int) ( $job['summary']['total'] ?? ( 'inspect-urls' === ( $job['task'] ?? '' ) ? count( $job['parameters']['urls'] ?? array() ) : 1 ) );
		echo '<h3>Tarefa ' . esc_html( (string) ( $job['id'] ?? '' ) ) . '</h3><p><strong>' . esc_html( $label ) . '</strong> · ' . esc_html( (string) ( $job['task'] ?? '' ) ) . '</p>';
		if ( $total > 0 ) {
			echo '<p>Progresso: ' . esc_html( (string) $done ) . ' de ' . esc_html( (string) $total ) . ' itens.</p><progress aria-label="Progresso da tarefa" max="' . esc_attr( (string) $total ) . '" value="' . esc_attr( (string) min( $done, $total ) ) . '"></progress>';
		}
		if ( isset( $job['summary']['passed'], $job['summary']['failed'] ) ) {
			echo '<p>Consultas aprovadas: ' . esc_html( (string) $job['summary']['passed'] ) . ' · Reprovadas: ' . esc_html( (string) $job['summary']['failed'] ) . '.</p>';
		}
		foreach ( array(
			'updated_at' => 'Última atualização',
			'run_after'  => 'Próxima execução elegível',
		) as $key => $title ) {
			if ( ! empty( $job[ $key ] ) ) {
				echo '<p>' . esc_html( $title ) . ': ' . esc_html( gmdate( 'Y-m-d H:i:s', (int) $job[ $key ] ) ) . ' UTC.</p>';
			}
		}
		$targets = array();
		$walk    = static function ( array $parameters ) use ( &$targets, &$walk ): void {
			foreach ( $parameters as $key => $value ) {
				if ( in_array( $key, array( 'property_id', 'customer_id', 'site_url', 'sitemap_url', 'spreadsheet_id', 'stream_id', 'accounts' ), true ) ) {
					foreach ( (array) $value as $target ) {
						if ( is_scalar( $target ) ) {
							$targets[] = (string) $target;
						}
					}
				} elseif ( is_array( $value ) && ! in_array( $key, array( 'rows', 'urls' ), true ) ) {
					$walk( $value );
				}
			}
		};
		$walk( $job['parameters'] ?? array() );
		if ( $targets ) {
			echo '<p>Destinos fixados: ' . esc_html( implode( ' · ', array_slice( array_unique( $targets ), 0, 20 ) ) ) . '.</p>';
		}
		if ( ! empty( $job['blocked_reason'] ) ) {
			echo '<p>Motivo do bloqueio: <code>' . esc_html( $job['blocked_reason'] ) . '</code>. Confira a identidade, as permissões e os destinos antes de criar uma nova intenção.</p>';
		}
		if ( 'unknown' === $status ) {
			echo '<p>Confira o destino no Google e registre a reconciliação. Uma execução incerta não é repetida automaticamente.</p>';
		}
		if ( ! empty( $job['result']['message'] ) ) {
			echo '<p>' . esc_html( $job['result']['message'] ) . '</p>';
		}
	}
	public static function render(): void {
		self::$revision     = null;
		self::$field_number = 0;
		$state              = self::state();
		if ( isset( $state['result'] ) ) {
			$result = $state['result'];
			echo '<section class="f3-card" role="status"><h2>Resultado da ação</h2><p>' . esc_html( $result['message'] ?? '' ) . '</p>';
			if ( empty( $result['success'] ) ) {
				echo '<p><strong>' . esc_html( $result['error_code'] ?? 'Falha' ) . '</strong></p>';
			}
			if ( isset( $result['job_id'] ) ) {
				echo '<p>Tarefa: <code>' . esc_html( $result['job_id'] ) . '</code> · ' . esc_html( $result['status'] ?? '' ) . '</p>';
			}
			if ( isset( $result['job'] ) && is_array( $result['job'] ) ) {
				self::job_details( $result['job'] );
			}
			if ( ! empty( $state['confirm'] ) ) {
				echo '<p>Confira os alvos e os efeitos previstos antes de confirmar. A confirmação vale para esta intenção e expira em dez minutos.</p>';
				self::json( 'Ver os efeitos e os parâmetros preparados', $result );
				self::form( 'confirm' );
				self::hidden( 'reference', $state['reference'] );
				self::button( 'Confirmar esta operação' );
			} elseif ( ! empty( $state['approve_job'] ) ) {
				echo '<p>A aprovação vale apenas para esta tarefa e para os destinos preparados. O executor conferirá novamente o acesso e o estado remoto.</p>';
				self::json( 'Conferir efeitos da exportação', $result );
				self::form( 'approve-job' );
				self::hidden( 'reference', $state['reference'] );
				self::button( 'Aprovar esta tarefa' );
			} elseif ( ! empty( $state['apply_cleanup'] ) ) {
				echo '<p>A limpeza revalida os candidatos e remove até 100 registros por passagem. Tarefas ativas e resultados incertos são preservados.</p>';
				self::json( 'Conferir candidatos à limpeza', $result );
				self::form( 'apply-cleanup' );
				self::hidden( 'reference', $state['reference'] );
				self::button( 'Executar limpeza vencida' );
			} elseif ( ! empty( $state['edit_schedule'] ) ) {
				self::schedule_form( $result['schedule'] );
			} elseif ( ! empty( $state['apply_policy'] ) ) {
				echo '<p>Contextos a revisar: ' . esc_html( (string) $result['contexts_invalidated']['jobs'] ) . ' tarefas e ' . esc_html( (string) $result['contexts_invalidated']['schedules'] ) . ' agendas. Padrões fora do novo alcance: ' . esc_html( (string) count( $result['defaults_outside_policy'] ) ) . '.</p>';
				self::json( 'Conferir política e impacto', $result );
				self::form( 'apply-policy' );
				self::hidden( 'reference', $state['reference'] );
				self::button( 'Aplicar esta política' );
			} elseif ( isset( $result['content_base64'], $result['filename'] ) ) {
				echo '<p>Arquivo desta página: ' . esc_html( $result['filename'] ) . ' · ' . esc_html( (string) $result['bytes'] ) . ' bytes.</p>';
				self::form( 'download-audit' );
				self::hidden( 'reference', $state['reference'] );
				self::button( 'Baixar arquivo autenticado' );
				if ( ! empty( $result['next_cursor'] ) ) {
					self::form( 'audit-next' );
					self::hidden( 'reference', $state['reference'] );
					self::button( 'Preparar próxima página' );
				}
				self::json( 'Ver cobertura da exportação', array_diff_key( $result, array( 'content_base64' => true ) ) );
			} elseif ( ! empty( $state['apply_template'] ) ) {
				self::json( 'Ver diferenças do modelo', $result );
				self::form( 'apply-template' );
				self::hidden( 'reference', $state['reference'] );
				self::button( 'Aplicar estas diferenças' );
			} elseif ( ! empty( $state['prepare_profile'] ) ) {
				self::json( 'Ver diferenças do perfil', $result );
				self::form( 'prepare-profile' );
				self::hidden( 'reference', $state['reference'] );
				self::button( 'Preparar aplicação deste perfil' );
			} else {
				self::json( 'Ver resultado técnico', $result );
			}
			echo '</section>';
		}
		if ( 'profiles' === Admin::section() ) {
			self::profiles();
			return;
		}
		if ( 'controls' === Admin::section() ) {
			self::controls();
			return;
		}
		self::operations();
	}
	private static function operations(): void {
		$integration = \Fator3\McpGoogle\Integration\ServiceApi::status();
		echo '<section class="f3-card"><h2>Integração com plugins</h2><p>Autorize a leitura Search Console para um consumidor registrado. A propriedade, agenda e persistência das métricas são configuradas pelo plugin consumidor. A conta Google e sua política continuam nesta conexão.</p>';
		if ( ! $integration['consumers'] ) {
			echo '<p>Nenhum consumidor compatível registrado. O plugin consumidor precisa registrar-se pelo contrato search-console-reader/1.0.0.</p>'; }
		foreach ( $integration['consumers'] as $consumer ) {
			echo '<h3>' . esc_html( $consumer['id'] ) . '</h3><p>Propriedade informada pelo consumidor: <strong>' . esc_html( $consumer['configuration']['property'] ?? 'Ainda não configurada' ) . '</strong>. Prontidão: ' . esc_html( ! empty( $consumer['configuration']['ready'] ) ? 'Pronto' : 'Pendente' ) . '.</p>';
			if ( ! empty( $consumer['configuration']['error_code'] ) ) {
				echo '<p>Configuração pendente: <code>' . esc_html( $consumer['configuration']['error_code'] ) . '</code>.</p>'; }
			$effective         = $consumer['effective_status'];
			$resolution_labels = array(
				'resolved'    => 'Concessão única localizada',
				'not_granted' => 'Sem concessão ativa',
				'ambiguous'   => 'Concessões conflitantes',
				'unreadable'  => 'Não foi possível verificar as concessões',
			);
			echo '<p>Conexão selecionada: <strong>' . esc_html( $integration['connection_id'] ) . '</strong>. Conexão efetiva: <strong>' . esc_html( $effective['connection_id'] ?? 'Não determinada' ) . '</strong>. ' . esc_html( $resolution_labels[ $effective['resolution'] ] ?? 'Diagnóstico indisponível' ) . '. A configuração pronta é declarada pelo consumidor; acesso remoto e gravação das métricas dependem da execução.</p>';
			$last = $effective['local_status']['last_service'] ?? null;
			if ( ! empty( $effective['local_status']['last_service_error'] ) ) {
				echo '<p>Último atendimento ilegível: <code>' . esc_html( $effective['local_status']['last_service_error'] ) . '</code>.</p>'; }

			echo '<p>Último atendimento: ' . esc_html( $last ? gmdate( 'Y-m-d H:i:s', (int) $last['at'] ) . ' UTC · ' . ( $last['success'] ? 'consulta concluída' : 'falhou: ' . ( $last['error_code'] ?? 'resultado não confirmado' ) ) . ' · ' . (int) ( $last['rows'] ?? 0 ) . ' linhas' : 'Ainda não observado' ) . '. A persistência das métricas é confirmada pelo consumidor.</p>';
			self::form( 'save-consumer' );
			self::hidden( 'consumer_id', $consumer['id'] );
			self::check( 'consumer_enabled', 'Autorizar leitura nesta conexão', ! empty( $consumer['grant']['enabled'] ), 'Permite somente Search Analytics por página e dia. Não concede escrita nem copia a credencial para o outro plugin. Revogue aqui antes de transferir a outra conexão.' );
			self::button( 'Salvar autorização' );
		}
		self::json( 'Ver contrato e atendimento', $integration );
		if ( ( $integration['transition']['state'] ?? '' ) !== 'completed' ) {
			self::form( 'complete-transition' );
			self::check( 'acknowledge_drained', 'Confirmei que o processo da versão antiga encerrou', false, 'Confira os processos em execução antes de confirmar. Lease expirado não comprova que o processo parou.' );
			self::button( 'Concluir transição da 0.6.0' );
		}
		echo '</section>';
		$cron = Executor::status();
		echo '<section class="f3-card"><h2>Execução das tarefas</h2><p>Executor observado: <strong>' . esc_html( $cron['executor'] ) . '</strong>. ' . esc_html( $cron['cron_servidor_ativo'] ? 'Passagem CLI observada nas últimas 2 horas.' : 'Nenhuma passagem CLI recente confirmada.' ) . '</p><p>Uma chamada manual no terminal também conta como CLI. O indicador não verifica o agendamento do servidor nem a aprovação dos trabalhos.</p>';
		foreach ( array(
			'ultima_cli'    => 'Última CLI',
			'ultima_http'   => 'Último cron HTTP',
			'ultima_manual' => 'Última chamada manual',
		) as $key => $label ) {
			$pass = $cron[ $key ];
			echo '<p><strong>' . esc_html( $label ) . ':</strong> ' . esc_html( $pass ? gmdate( 'Y-m-d H:i:s', $pass['at'] ) . ' UTC · ' . ( true === $pass['success'] ? 'concluída' : ( false === $pass['success'] ? 'reprovada' : 'resultado não confirmado' ) ) . ' · ' . $pass['items'] . ' itens' : 'Não observada' ) . '</p>';
		}
		self::json( 'Ver diagnóstico do executor', $cron );
		echo '</section>';
		$recovery = \Fator3\McpGoogle\Recovery::status();
		echo '<section class="f3-card"><h2>Restauração e recuperação</h2><p>Prepare a pausa antes de restaurar o banco. Ela permanece fora do snapshot. Depois, confira conexões, credenciais e efeitos remotos dos trabalhos antes de retomar. Trabalhos restaurados exigem revisão de contexto.</p>';
		self::form( 'recovery' );
		self::hidden( 'recovery_action', ! empty( $recovery['paused'] ) ? 'resume' : 'prepare' );
		self::hidden( 'recovery_generation', $recovery['generation'] ?? '' );
		if ( ! empty( $recovery['paused'] ) ) {
			self::check( 'acknowledge_reconciled', 'Conferi o snapshot e reconciliei os efeitos remotos', false, 'A restauração do banco não desfaz alterações no Google. Confira a auditoria e os recursos afetados antes de retomar.' ); }
		self::button( ! empty( $recovery['paused'] ) ? 'Retomar após reconciliação' : 'Preparar pausa para restore' );
		if ( ! empty( $recovery['paused'] ) && empty( $recovery['drained'] ) ) {
			self::form( 'recovery' );
			self::hidden( 'recovery_action', 'prepare' );
			self::button( 'Conferir drenagem' ); }
		self::json( 'Ver estado de recuperação', $recovery );
		echo '</section>';
		echo '<section class="f3-card"><h2>Tarefas e agendas</h2><p>Uma execução concluída pode conter verificações reprovadas. Consulte o resultado antes de tomar uma ação. Cancelar interrompe etapas futuras e preserva as já concluídas.</p>';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
		$status = isset( $_GET['job_status'] ) ? sanitize_key( wp_unslash( $_GET['job_status'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
		$task = isset( $_GET['job_task'] ) ? sanitize_key( wp_unslash( $_GET['job_task'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
		$from = isset( $_GET['job_from'] ) && is_string( $_GET['job_from'] ) ? sanitize_text_field( wp_unslash( $_GET['job_from'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
		$to = isset( $_GET['job_to'] ) && is_string( $_GET['job_to'] ) ? sanitize_text_field( wp_unslash( $_GET['job_to'] ) ) : '';
		echo '<form class="f3-job-filters" method="get" action="' . esc_url( admin_url( 'tools.php' ) ) . '">';
		foreach ( array(
			'page'          => Admin::SLUG,
			'section'       => 'operations',
			'connection_id' => Connections::id(),
		) as $key => $value ) {
			self::hidden( $key, $value );
		}
		echo '<div><label for="f3-job-filter">Estado</label> <select id="f3-job-filter" name="job_status">';
		foreach ( array(
			''                  => 'Todos',
			'approval_required' => 'Aguardando aprovação',
			'pending'           => 'Pendente',
			'running'           => 'Em execução',
			'blocked'           => 'Bloqueado',
			'unknown'           => 'Resultado incerto',
			'failed'            => 'Falhou',
			'completed'         => 'Concluído',
			'cancelled'         => 'Cancelado',
			'reconciled'        => 'Reconciliado',
		) as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $status, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></div><div><label for="f3-task-filter">Tarefa</label> <select id="f3-task-filter" name="job_task"><option value="">Todas</option>';
		foreach ( \Fator3\McpGoogle\Automation\Jobs::TASKS as $name ) {
			echo '<option value="' . esc_attr( $name ) . '" ' . selected( $task, $name, false ) . '>' . esc_html( $name ) . '</option>';
		}
		echo '</select></div><div><label for="f3-job-from">Criada desde (UTC)</label> <input type="date" id="f3-job-from" name="job_from" value="' . esc_attr( $from ) . '"> </div><div><label for="f3-job-to">Até (UTC)</label> <input type="date" id="f3-job-to" name="job_to" value="' . esc_attr( $to ) . '"> </div><button class="button">Filtrar</button></form>';
		$input = $status ? array( 'status' => $status ) : array();
		foreach ( array(
			'task' => $task,
			'from' => $from,
			'to'   => $to,
		) as $key => $value ) {
			if ( '' !== $value ) {
				$input[ $key ] = $value;
			}
		}
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
		$input['offset'] = isset( $_GET['offset'] ) ? absint( wp_unslash( $_GET['offset'] ) ) : 0;
		$page            = Operations::listing( $input );
		if ( empty( $page['success'] ) ) {
			echo '<p>' . esc_html( $page['message'] ) . '</p></section>';
			return;
		}
		echo '<table class="widefat striped f3-job-table"><thead><tr><th>Tarefa</th><th>Estado</th><th>Próximo passo</th></tr></thead><tbody>';
		foreach ( $page['jobs'] as $job ) {
			echo '<tr><td data-label="Tarefa"><strong>' . esc_html( $job['task'] ) . '</strong><br><code>' . esc_html( $job['id'] ) . '</code></td><td data-label="Estado">' . esc_html( $job['status'] ) . '</td><td data-label="Próximo passo">';
			self::form( 'get-job' );
			self::hidden( 'job_id', $job['id'] );
			self::button( 'Consultar resultado' );
			if ( 'approval_required' === $job['status'] ) {
				self::form( 'prepare-job' );
				self::hidden( 'job_id', $job['id'] );
				self::button( 'Conferir exportação para aprovação' );
			}
			if ( 'pending' === $job['status'] ) {
				self::form( 'run-job' );
				self::hidden( 'job_id', $job['id'] );
				self::button( 'Executar próxima passagem' );
			}
			if ( in_array( $job['status'], array( 'pending', 'blocked', 'approval_required' ), true ) ) {
				self::form( 'cancel-job' );
				self::hidden( 'job_id', $job['id'] );
				self::button( 'Cancelar etapas pendentes' );
			}
			if ( 'unknown' === $job['status'] ) {
				echo '<p>Confira o destino no Google. Esta tarefa não será repetida automaticamente.</p><details><summary>Registrar reconciliação</summary>';
				self::form( 'reconcile-job' );
				self::hidden( 'job_id', $job['id'] );
				echo '<label>Estado conferido <select name="observed_outcome"><option value="applied">Aplicado</option><option value="not_applied">Não aplicado</option><option value="partial">Aplicado parcialmente</option></select></label>';
				self::field( 'evidence', 'Evidência da conferência', '', 'Descreva como conferiu o destino, sem credenciais. Entre 10 e 2.000 caracteres.', 'textarea' );
				self::button( 'Registrar sem repetir a escrita' );
				echo '</details>';
			}
			echo '</td></tr>';
		}
		if ( ! $page['jobs'] ) {
			echo '<tr><td colspan="3">Nenhuma tarefa neste filtro.</td></tr>';
		}
		echo '</tbody></table>';
		if ( null !== $page['next_offset'] ) {
			echo '<p><a class="button" href="' . esc_url(
				add_query_arg(
					array(
						'offset'     => $page['next_offset'],
						'job_status' => $status,
						'job_task'   => $task,
						'job_from'   => $from,
						'job_to'     => $to,
					),
					Admin::url( '', 'operations' )
				)
			) . '">Próxima página</a></p>';
		}
		echo '<h3>Agendas</h3>';
		foreach ( $page['schedules'] as $schedule ) {
			echo '<p>' . esc_html( $schedule['id'] . ' · ' . $schedule['task'] . ' · ' . ( ! empty( $schedule['enabled'] ) ? 'Ativa' : 'Pausada' ) ) . '</p>';
			self::form( 'get-schedule' );
			self::hidden( 'schedule_id', $schedule['id'] );
			self::button( 'Consultar, editar ou pausar' );
		}
		echo '<details class="f3-details"><summary>Criar agenda de leitura</summary>';
		self::schedule_form();
		echo '</details>';
		self::form( 'run-due' );
		self::button( 'Executar tarefas e agendas vencidas' );
		self::json( 'Ver estado do executor', Executor::status() );
		echo '</section>';
		echo '<section class="f3-card"><h2>Histórico e incidentes</h2>';
		self::json( 'Consultar incidentes', Alerts::state() );
		self::form( 'audit-export' );
		echo '<label>Formato <select name="format"><option value="json">JSON</option><option value="csv">CSV</option></select></label>';
		self::field( 'desde_revisao', 'Depois da revisão', '0', 'Hash de configuração, marcador event: ou cursor decimal exclusivo; até 100 eventos por página.' );
		self::button( 'Consultar página de exportação' );
		self::form( 'cleanup' );
		self::button( 'Conferir limpeza vencida' );
		echo '</section>';
	}
	private static function schedule_form( ?array $schedule = null ): void {
		self::form( 'save-schedule' );
		if ( null !== $schedule ) {
			self::hidden( 'schedule_id', $schedule['id'] );
			self::hidden( 'schedule_revision', $schedule['revision'] );
		}
		echo '<p><label>Tipo de tarefa <select name="task">';
		foreach ( array(
			'report'    => 'Relatório por modelo',
			'query'     => 'Consulta de métricas',
			'preflight' => 'Verificação de acesso',
		) as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $schedule['task'] ?? 'report', $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></label></p>';
		self::field( 'interval_seconds', 'Intervalo em segundos', (string) ( $schedule['interval_seconds'] ?? 86400 ), 'De 3.600 (uma hora) a 2.592.000 (30 dias). A agenda precisa de WP-Cron ou de um disparador externo.', 'number' );
		self::check( 'schedule_enabled', 'Agenda ativa', (bool) ( $schedule['enabled'] ?? true ), 'Desmarque para pausar novas ocorrências; tarefas já criadas permanecem disponíveis.' );
		echo '<details class="f3-details"><summary>Parâmetros da consulta</summary>';
		self::field( 'parameters_json', 'Parâmetros JSON', wp_json_encode( $schedule['parameters'] ?? array( 'template' => 'traffic' ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ), 'Relatório: template e date_range; consulta: connector, accounts e metrics; verificação: opções de google/preflight. Períodos relativos são recalculados em cada ocorrência.', 'textarea' );
		echo '</details>';
		self::button( null === $schedule ? 'Criar agenda' : 'Salvar esta revisão da agenda' );
	}
	private static function profiles(): void {
		echo '<section class="f3-card"><h2>Perfis GA4</h2><p>Um perfil descreve somente os valores que você quer administrar. Campos omitidos e definições extras permanecem como estão. A aplicação usa uma propriedade existente e começa pela retenção.</p>';
		self::form( 'plan-profile' );
		self::field( 'profile_id', 'Perfil salvo', '', 'Identificador do perfil configurável desta conexão.' );
		self::field( 'property_id', 'Propriedade GA4', (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' ), 'ID numérico de uma propriedade existente.' );
		self::field( 'stream_id', 'Stream Web', (string) ( Options::get( Connections::BINDINGS, array() )['ga_stream_id'] ?? '' ), 'Obrigatório para medição otimizada e redação de dados.' );
		self::button( 'Comparar sem alterar o Google' );
		$profiles = wp_get_ability( 'ga/list-profiles' );
		if ( $profiles ) {
			self::json( 'Ver perfis salvos', \Fator3\McpGoogle\Gate::administrative( 'ga/list-profiles', static fn () => \Fator3\McpGoogle\Ability::execute_admin( 'ga/list-profiles', array( 'connection_id' => Connections::id() ) ) ) );
		}
		echo '<details class="f3-details"><summary>Criar ou atualizar definição de perfil</summary><p>Seções disponíveis: retenção, medição otimizada, Google Signals, redação de dados, atribuição, dimensões e métricas personalizadas. O contrato abaixo explica campos, tipos e valores aceitos.</p>';
		self::form( 'save-profile' );
		self::field( 'profile_id', 'Identificador do perfil', '', 'Letras minúsculas, números, hífen ou sublinhado; comece por uma letra.' );
		self::field( 'profile_revision', 'Revisão atual do perfil', '', 'Deixe vazio apenas para criar; ao atualizar, copie a revisão do perfil salvo.' );
		self::field( 'profile_json', 'Definição JSON', '{"schema_version":"1.0.0","custom_dimensions":[]}', 'Informe somente as seções desejadas. Nenhum padrão de agência é presumido.', 'textarea' );
		self::button( 'Salvar definição local' );
		self::json( 'Consultar schema do perfil', Profile::schema() );
		echo '</details></section>';
	}
	private static function controls(): void {
		$policy = Policy::current();
		echo '<section class="f3-card"><h2>Permissões por recurso</h2><p>Recursos padrão ajudam a selecionar o destino; a política determina quais destinos podem ser usados. Novas conexões começam restritas. Uma instalação anterior mantém o acesso da identidade até você definir restrições.</p>';
		self::form( 'save-policy' );
		echo '<label>Alcance <select name="policy_mode">';
		foreach ( array(
			'restricted' => 'Somente recursos autorizados',
			'identity'   => 'Recursos acessíveis à identidade Google',
		) as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $policy['mode'] ?? 'identity', $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></label>';
		foreach ( array(
			'ga'               => 'Analytics',
			'ads'              => 'Google Ads',
			'gsc'              => 'Search Console',
			'sheets'           => 'Sheets',
			'drive'            => 'Drive',
			'siteverification' => 'Verificação de sites',
		) as $key => $label ) {
			$rule = $policy['services'][ $key ] ?? array();
			echo '<details class="f3-details"><summary>' . esc_html( $label ) . '</summary>';
			self::field( $key . '_resources', 'Recursos autorizados', implode( "\n", $rule['resources'] ?? array() ), 'Um identificador por linha. Analytics: properties/123; Ads: ID da conta; GSC: URL exata ou sc-domain; Sheets/Drive: ID do arquivo ou pasta. Lista vazia não autoriza recursos.', 'textarea' );
			self::field( $key . '_operations', 'Operações permitidas', implode( "\n", $rule['operations'] ?? array() ), 'Métodos oficiais, um por linha. Vazio permite os métodos cobertos que atuam nos recursos autorizados.', 'textarea' );
			self::check( $key . '_create', 'Permitir criação sob um contexto autorizado', ! empty( $rule['allow_create'] ), 'Não concede acesso a outros pais ou destinos.' );
			self::field( $key . '_recipients', 'Destinatários de compartilhamento', implode( "\n", $rule['recipients'] ?? array() ), 'Um e-mail por linha. Permissões exigem preparação e confirmação adicionais.', 'textarea' );
			echo '</details>';
		}
		self::button( 'Conferir impacto antes de salvar' );
		self::form( 'discover-policy' );
		self::button( 'Consultar recursos disponíveis para definir a política' );
		echo '</section>';
		$alerts = Alerts::config();
		echo '<section class="f3-card"><h2>Alertas operacionais</h2><p>Alertas começam desativados. O painel acompanha incidentes de acesso, executor, sitemap e verificações agendadas. A aceitação pelo serviço de e-mail não confirma entrega.</p>';
		self::form( 'save-alerts' );
		self::check( 'alerts_enabled', 'Ativar registro de incidentes', $alerts['enabled'], 'Habilita observações e eventos de recuperação.' );
		self::check( 'email_enabled', 'Enviar notificações por e-mail', $alerts['email_enabled'], 'Envio optativo aos destinatários informados, sem credenciais nem relatórios completos.' );
		self::field( 'recipients', 'Destinatários', implode( "\n", $alerts['recipients'] ), 'Até dez e-mails, um por linha.', 'textarea' );
		self::field( 'minimum_interval', 'Intervalo mínimo em segundos', (string) $alerts['minimum_interval'], 'Entre 60 e 604800; eventos dentro do intervalo aguardam a próxima execução.', 'number' );
		foreach ( Alerts::EVENTS as $event ) {
			self::check( 'event_' . $event, $event, in_array( $event, $alerts['events'], true ), 'Incluir este tipo de incidente e a sua recuperação.' );
		}
		self::button( 'Salvar preferências de alerta' );
		echo '</section>';
		echo '<section class="f3-card"><h2>Modelos de configuração</h2><p>Modelos transportam serviços, vínculos, limites e política. Credenciais e destinatários não são exportados. Os recursos são parametrizados para você mapear na instalação de destino.</p>';
		self::form( 'export-template' );
		self::button( 'Gerar modelo sem segredos' );
		echo '<details class="f3-details"><summary>Importar modelo e mapear recursos</summary>';
		self::form( 'plan-template' );
		self::field( 'template_json', 'Modelo JSON', '', 'Use o objeto template exportado.', 'textarea' );
		self::field( 'mapping_json', 'Mapa de recursos', '{}', 'Objeto com os parâmetros declarados no modelo e os IDs de destino.', 'textarea' );
		self::button( 'Ver diferenças antes de aplicar' );
		echo '</details></section>';
		$origin = Options::get( Updater::OPTION, array() );
		echo '<section class="f3-card"><h2>Distribuição e manutenção</h2>';
		self::form( 'save-updates' );
		self::check( 'updates_enabled', 'Consultar atualizações nesta origem', ! empty( $origin['enabled'] ), 'O manifesto deve vir de um distribuidor em quem você confia. Esta opção não ativa atualizações automáticas.' );
		self::field( 'manifest_url', 'URL HTTPS do manifesto', (string) ( $origin['manifest_url'] ?? '' ), 'O manifesto informa versão, requisitos, URL e hash do pacote.' );
		self::field( 'allowed_hosts', 'Hosts de distribuição', implode( "\n", $origin['allowed_hosts'] ?? array() ), 'Até cinco hosts exatos, um por linha; os redirecionamentos e o pacote devem permanecer nessa lista.', 'textarea' );
		self::button( 'Salvar origem' );
		self::form( 'save-local' );
		self::check( 'audit_local_reads', 'Auditar consultas locais bem-sucedidas', (bool) Options::get( Options::AUDIT_LOCAL_READS, false ), 'Falhas, recusas e alterações continuam auditadas independentemente desta opção.' );
		self::check( 'purge_on_uninstall', 'Excluir também configurações públicas e histórico ao desinstalar', (bool) Options::get( 'f3_mcp_google_purge_on_uninstall', false ), 'Credenciais são sempre removidas. O padrão preserva configurações públicas e histórico para recuperação.' );
		self::button( 'Salvar manutenção' );
		echo '</section>';
	}
	private static function lines( string $name ): array {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
		$text  = isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $name ] ) ) : '';
		$lines = preg_split( '/[\r\n,]+/', $text );
		return array_values( array_unique( array_filter( array_map( 'trim', is_array( $lines ) ? $lines : array() ) ) ) );
	}
	private static function decoded( string $name ): array {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper. Structured input is validated by the shared schema/credential writer; text sanitization would corrupt JSON or the key.
		$text = isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : '';
		if ( strlen( $text ) > 262144 ) {
			throw new \InvalidArgumentException( 'JSON excede 256 KiB.' );
		}
		$value = json_decode( $text, true );
		if ( ! is_array( $value ) ) {
            // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception carries a structured internal error; renderers escape it at the output boundary.
			throw new \InvalidArgumentException( 'JSON inválido: ' . $name );
		}
		return $value;
	}
	public static function handle(): void {
		Admin::guard( self::ACTION );
		$operation  = Admin::posted( 'operation' );
		$parameters = array();
		$ability    = '';
		$state      = array();
		try {
			switch ( $operation ) {
				case 'save-consumer':
					$ability    = 'google/configure-consumer';
					$parameters = array(
						'consumer_id'       => Admin::posted( 'consumer_id' ),
						'enabled'           => '1' === Admin::posted( 'consumer_enabled' ),
						'expected_revision' => Admin::posted( 'expected_revision' ),
					);
					break;
				case 'complete-transition':
					$ability    = 'google/complete-transition';
					$parameters = array( 'acknowledge_drained' => '1' === Admin::posted( 'acknowledge_drained' ) );
					break;
				case 'recovery':
					$ability    = 'google/recovery';
					$parameters = array(
						'action'                 => Admin::posted( 'recovery_action' ),
						'expected_generation'    => Admin::posted( 'recovery_generation' ),
						'acknowledge_reconciled' => '1' === Admin::posted( 'acknowledge_reconciled' ),
					);
					break;
				case 'get-schedule':
					$ability                = 'google/get-schedule';
					$parameters             = array( 'schedule_id' => Admin::posted( 'schedule_id' ) );
					$state['edit_schedule'] = true;
					break;
				case 'save-schedule':
					$ability    = 'google/schedule-report';
					$parameters = array(
						'task'             => Admin::posted( 'task' ),
						'parameters'       => self::decoded( 'parameters_json' ),
						'interval_seconds' => (int) Admin::posted( 'interval_seconds' ),
						'enabled'          => '1' === Admin::posted( 'schedule_enabled' ),
					);
					if ( '' !== Admin::posted( 'schedule_id' ) ) {
						$parameters['schedule_id']       = Admin::posted( 'schedule_id' );
						$parameters['expected_revision'] = Admin::posted( 'schedule_revision' );
					}
					break;
				case 'prepare-job':
					$ability              = 'google/prepare-job';
					$parameters           = array( 'job_id' => Admin::posted( 'job_id' ) );
					$state['approve_job'] = true;
					break;
				case 'get-job':
				case 'run-job':
				case 'cancel-job':
				case 'reconcile-job':
					$ability    = 'google/' . $operation;
					$parameters = array( 'job_id' => Admin::posted( 'job_id' ) );
					if ( 'get-job' === $operation ) {
						$parameters['include_input'] = true;
					}
					if ( 'reconcile-job' === $operation ) {
						$parameters += array(
							'observed_outcome' => Admin::posted( 'observed_outcome' ),
							'evidence'         => Admin::posted( 'evidence' ),
						);
					}
					break;
				case 'run-due':
					$ability = 'google/executar-vencidos';
					break;
				case 'cleanup':
					$ability                = 'google/cleanup-jobs';
					$state['apply_cleanup'] = true;
					break;
				case 'audit-export':
					$ability    = 'google/audit-export';
					$parameters = array(
						'format'        => Admin::posted( 'format' ),
						'desde_revisao' => Admin::posted( 'desde_revisao' ),
						'limit'         => 100,
					);
					break;
				case 'save-policy':
					$ability               = 'google/plan-policy';
					$state['apply_policy'] = true;
					$policy                = array(
						'mode'     => Admin::posted( 'policy_mode' ),
						'services' => array(),
					);
					foreach ( array( 'ga', 'ads', 'gsc', 'sheets', 'drive', 'siteverification' ) as $service ) {
						$policy['services'][ $service ] = array(
							'resources'    => self::lines( $service . '_resources' ),
							'operations'   => self::lines( $service . '_operations' ),
							'allow_create' => '1' === Admin::posted( $service . '_create' ),
							'recipients'   => self::lines( $service . '_recipients' ),
						);
					}
					$parameters = array( 'policy' => $policy );
					break;
				case 'discover-policy':
					$ability = 'google/policy-discover-resources';
					break;
				case 'save-alerts':
					$ability    = 'google/configure-alerts';
					$events     = array_values( array_filter( Alerts::EVENTS, static fn ( $event ) => '1' === Admin::posted( 'event_' . $event ) ) );
					$parameters = array(
						'expected_revision' => Admin::posted_revision(),
						'configuration'     => array(
							'enabled'          => '1' === Admin::posted( 'alerts_enabled' ),
							'email_enabled'    => '1' === Admin::posted( 'email_enabled' ),
							'recipients'       => self::lines( 'recipients' ),
							'events'           => $events,
							'minimum_interval' => (int) Admin::posted( 'minimum_interval' ),
						),
					);
					break;
				case 'save-updates':
					$ability    = 'google/configure-update-origin';
					$parameters = array(
						'expected_revision' => Admin::posted_revision(),
						'origin'            => array(
							'enabled'       => '1' === Admin::posted( 'updates_enabled' ),
							'manifest_url'  => Admin::posted( 'manifest_url' ),
							'allowed_hosts' => self::lines( 'allowed_hosts' ),
						),
					);
					break;
				case 'save-local':
					$ability    = 'google/configure-local';
					$parameters = array(
						'expected_revision'  => Admin::posted_revision(),
						'audit_local_reads'  => '1' === Admin::posted( 'audit_local_reads' ),
						'purge_on_uninstall' => '1' === Admin::posted( 'purge_on_uninstall' ),
					);
					break;
				case 'save-profile':
					$ability    = 'ga/save-profile';
					$parameters = array(
						'profile_id'        => Admin::posted( 'profile_id' ),
						'expected_revision' => Admin::posted( 'profile_revision' ),
						'profile'           => self::decoded( 'profile_json' ),
					);
					break;
				case 'plan-profile':
					$ability                  = 'ga/conformidade';
					$parameters               = array(
						'profile_id'  => Admin::posted( 'profile_id' ),
						'property_id' => Admin::posted( 'property_id' ),
						'stream_id'   => Admin::posted( 'stream_id' ),
					);
					$state['prepare_profile'] = true;
					break;
				case 'export-template':
					$ability = 'google/export-template';
					break;
				case 'plan-template':
					$ability                 = 'google/plan-template';
					$parameters              = array(
						'template' => self::decoded( 'template_json' ),
						'mapping'  => self::decoded( 'mapping_json' ),
					);
					$state['apply_template'] = true;
					break;
				case 'apply-cleanup':
				case 'apply-policy':
				case 'approve-job':
				case 'download-audit':
				case 'audit-next':
				case 'apply-template':
				case 'prepare-profile':
				case 'confirm':
					$prior = self::state();
					if ( ! isset( $prior['reference'] ) || ! hash_equals( $prior['reference'], Admin::posted( 'reference' ) ) ) {
						throw new \InvalidArgumentException( 'Prévia expirada. Refaça a consulta.' );
					}
					if ( 'download-audit' === $operation ) {
						$result = $prior['result'];
						// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Data transport encoding for a signed cursor or authenticated download; never executable PHP.
						$content = base64_decode( $result['content_base64'] ?? '', true );
						if ( ! is_string( $content ) || ! hash_equals( $result['sha256'] ?? '', hash( 'sha256', $content ) ) ) {
							throw new \InvalidArgumentException( 'Arquivo temporário inválido.' );
						}
						nocache_headers();
						header( 'Content-Type: ' . ( 'csv' === $result['format'] ? 'text/csv' : 'application/json' ) . '; charset=utf-8' );
						header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $result['filename'] ) . '"' );
						header( 'X-Content-Type-Options: nosniff' );
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Authenticated file attachment, verified by hash; escaping would corrupt the CSV/JSON bytes.
						echo $content;
						exit;
					} elseif ( 'audit-next' === $operation ) {
						$ability    = 'google/audit-export';
						$parameters = array(
							'cursor' => $prior['result']['next_cursor'],
							'format' => $prior['result']['format'],
							'limit'  => 100,
						);
					} elseif ( 'apply-cleanup' === $operation ) {
						$ability    = 'google/cleanup-jobs';
						$parameters = array( 'dry_run' => false );
					} elseif ( 'apply-policy' === $operation ) {
						$ability    = 'google/configure-policy';
						$parameters = array(
							'policy'             => $prior['result']['policy'],
							'expected_revision'  => $prior['result']['revision'],
							'expected_plan_hash' => $prior['result']['plan_hash'],
						);
					} elseif ( 'approve-job' === $operation ) {
						$ability    = 'google/approve-job';
						$parameters = array(
							'job_id'         => $prior['result']['job_id'],
							'approval_token' => $prior['result']['confirmation_token'],
						);
						delete_transient( self::key() );
					} elseif ( 'confirm' === $operation ) {
						$ability                          = $prior['result']['ability'];
						$parameters                       = $prior['result']['parameters'];
						$parameters['confirmation_token'] = $prior['result']['confirmation_token'];
						delete_transient( self::key() );
					} elseif ( 'apply-template' === $operation ) {
						$ability    = 'google/apply-template';
						$parameters = $prior['parameters'] + array(
							'expected_revision'  => $prior['result']['revision'],
							'expected_plan_hash' => $prior['result']['plan_hash'],
						);
					} else {
						$ability          = 'google/prepare-operation';
						$parameters       = array(
							'ability'    => 'ga/aplicar-perfil',
							'parameters' => $prior['parameters'] + array(
								'dry_run'            => false,
								'expected_plan_hash' => $prior['result']['plan_hash'],
							),
						);
						$state['confirm'] = true;
					}
					break;
				case 'prepare-revoke':
					$ability          = 'google/prepare-operation';
					$parameters       = array(
						'ability'    => 'google/disconnect',
						'parameters' => array( 'revoke' => true ),
					);
					$state['confirm'] = true;
					break;
				default:
					throw new \InvalidArgumentException( 'Ação desconhecida.' );
			}
			$entry  = wp_get_ability( $ability );
			$result = $entry ? \Fator3\McpGoogle\Gate::administrative( $ability, static fn () => \Fator3\McpGoogle\Ability::execute_admin( $ability, $parameters + array( 'connection_id' => Connections::id() ) ) ) : Response::fail( 'Habilidade indisponível.' );
			if ( is_wp_error( $result ) ) {
				$result = Response::fail( $result );
			}
			if ( empty( $result['success'] ) ) {
				$state = array();
			}
			$state += array(
				'reference'  => bin2hex( random_bytes( 16 ) ),
				'parameters' => $parameters,
				'result'     => $result,
			);
		} catch ( \Throwable $e ) {
			$state = array( 'result' => Response::fail( new \WP_Error( 'f3_google_operation_input', Audit::redact( $e->getMessage() ) ) ) );
		}
		$cipher = Crypto::encrypt( wp_json_encode( $state ) );
		if ( '' === $cipher ) {
			Admin::require_saved( Response::fail( 'Não foi possível cifrar o resultado temporário.' ) );
		}
		set_transient( self::key(), $cipher, 600 );
		Admin::back( 'operation_result' );
	}
}
