<?php
/** Contrato de anúncios v1. IDs permanecem strings; nomes não são identidade. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Atribuicao {
    const CAMPOS=array('oppref','utm_source','utm_medium','utm_campaign','utm_content','utm_term','utm_id','utm_source_platform','gclid','gbraid','wbraid','fbclid','li_fat_id','f3_ads_v','f3_ads_account_id','f3_ads_group_id','f3_ads_group_type','f3_ads_placement','f3_ads_group_name','f3_ads_ad_name');
    public static function catalogo(array $c): array {
        $schema=array('type'=>'array','maxItems'=>500,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('plataforma','conta','campanha','nome'),'properties'=>array('plataforma'=>array('type'=>'string','enum'=>array('meta_ads','google_ads','linkedin_ads','openai_ads')),'conta'=>array('type'=>'string','minLength'=>1,'maxLength'=>100),'campanha'=>array('type'=>'string','minLength'=>1,'maxLength'=>100),'nome'=>array('type'=>'string','minLength'=>1,'maxLength'=>300))));
        $c['f3base_campanhas_nomes']=array('rotulo'=>'Nomes de campanhas por conta','descricao'=>'Complementa o nome quando o link traz apenas o ID da campanha. Cada linha exige plataforma, conta, campanha e nome. IDs iguais de contas diferentes permanecem separados; nomes recebidos do link são preservados.','operavel'=>true,'secao'=>'medicao','campo'=>'campanhas','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'schema_config'=>$schema,'schema_entrada'=>$schema,'recusa'=>static function($v)use($schema){if(is_wp_error(rest_validate_value_from_schema($v,$schema))){return 'Informe lista de plataforma, conta, campanha e nome.';}$seen=array();foreach($v as $r){$k=$r['plataforma'].'|'.$r['conta'].'|'.$r['campanha'];if(isset($seen[$k])){return 'Campanha repetida na mesma conta e plataforma.';}$seen[$k]=true;}return '';},'exemplo'=>'[{"plataforma":"meta_ads","conta":"123","campanha":"456","nome":"Campanha de exemplo"}]','impacto'=>'Afeta capturas novas. Não renomeia mensagens já enviadas ou snapshots históricos. Evita inferir nomes por anúncio, e-mail ou data.');return $c;
    }
    public static function normalizar($v, bool $snapshots=true): array {
        $v=is_array($v)?$v:array();$out=array();$alias=array('utm_source'=>'fonte','utm_medium'=>'meio','utm_campaign'=>'campanha','utm_content'=>'conteudo','utm_term'=>'termo');
        foreach(self::CAMPOS as $k){$x=$v[$k]??$v[$alias[$k]??'']??'';$out[$k]=$k==='oppref'?(is_string($x)&&strlen($x)<=8192&&!preg_match('/[\x00-\x1f\x7f]/',$x)?$x:''):(is_string($x)?(function_exists('mb_substr')?mb_substr(sanitize_text_field($x),0,500):substr(sanitize_text_field($x),0,500)):'');}
        if(isset($v['oppref'])&&is_string($v['oppref'])&&strlen($v['oppref'])>8192){$out['oppref_estado']='omitido_excede_8192_bytes';}
        if(is_string($v['msclkid']??null)){$out['msclkid']=substr(sanitize_text_field($v['msclkid']),0,500);}
        foreach(array('fbc','fbp') as $k){$cookie=$v[$k]??'';$out[$k]=is_string($cookie)&&strlen($cookie)<=500&&preg_match('/^fb\\.[0-9]{1,3}\\.[0-9]{10,13}\\.[A-Za-z0-9_-]+$/D',$cookie)?$cookie:'';}
        $ref=is_string($v['referrer']??null)?$v['referrer']:'';$host=wp_parse_url($ref,PHP_URL_HOST);
        $out['referrer']=$host?strtolower($host):(preg_match('/^[a-z0-9.-]+$/i',$ref)?strtolower($ref):'');
        $out['modelo']=in_array($v['modelo']??'',array('sessao','primeiro-toque','ultimo-toque'),true)?$v['modelo']:'informado';
        foreach(array('primeiro_toque_em','ultimo_toque_em') as $k){$out[$k]=is_string($v[$k]??null)&&preg_match('/^[0-9]{1,12}$/D',$v[$k])?$v[$k]:'';}
        $out['superficie_anuncio']=array('ig'=>'instagram','instagram'=>'instagram','fb'=>'facebook','facebook'=>'facebook','an'=>'audience_network','msg'=>'messenger')[strtolower($out['utm_source'])]??'';
        $out['entrada']=is_string($v['entrada']??null)?F3Base_Analise::caminho($v['entrada']):'';$out['inicio_em']=is_string($v['inicio_em']??null)&&preg_match('/^[0-9]{1,12}$/D',$v['inicio_em'])?$v['inicio_em']:'';$out['inicio_conhecido']=($v['inicio_conhecido']??'')==='1'?'1':'';
        $hasSource=$out['utm_source']!==''||$out['referrer']!==''||$out['utm_campaign']!==''||$out['utm_id']!==''||$out['gclid']!==''||$out['gbraid']!==''||$out['wbraid']!==''||$out['fbclid']!==''||$out['fbc']!==''||$out['oppref']!=='';$out['origem_tipo']=in_array(strtolower($out['utm_source']),array('direto','direct'),true)||(!$hasSource&&$out['inicio_conhecido']==='1'&&$out['entrada']!=='')?'direto':($hasSource?'identificada':'nao_identificada');
        $signals=array();if($out['gclid']!==''||$out['gbraid']!==''||$out['wbraid']!==''){$signals[]='google_ads';}if($out['fbclid']!==''||$out['fbc']!==''){$signals[]='meta';}if($out['oppref']!==''){$signals[]='openai_ads';}$out['plataforma_fonte']=$out['utm_source_platform']!==''?'declarada':($signals?'identificador_de_clique':'nao_identificada');if(count($signals)>1){$out['conflito_plataforma']='identificadores_de_plataformas_distintas';}
        $out['contrato']='1';$out['plataforma']=self::plataforma($out);$out['origem_ia']=F3Base_Audiencia::ia($out);if(!empty($out['oppref'])&&in_array(strtolower($out['utm_source_platform']),array('meta','meta_ads','google','google_ads','linkedin','linkedin_ads'),true)){$out['conflito_plataforma']='oppref_e_plataforma_divergente';}
        // IDs Meta numéricos também são aceitos nos parâmetros dinâmicos tradicionais.
        $out['campanha_id']=$out['utm_id'];$out['anuncio_id']=$out['f3_ads_v']==='1'?$out['utm_content']:'';
        if($out['plataforma']==='meta_ads'){if($out['plataforma_fonte']==='nao_identificada'||$out['plataforma_fonte']==='identificador_de_clique'){$out['plataforma_fonte']='inferida_superficie_paga';}if($out['campanha_id']===''&&preg_match('/^[0-9]+$/D',$out['utm_campaign'])){$out['campanha_id']=$out['utm_campaign'];}if($out['anuncio_id']===''&&preg_match('/^[0-9]+$/D',$out['utm_content'])){$out['anuncio_id']=$out['utm_content'];}if($out['f3_ads_group_id']===''&&preg_match('/^[0-9]+$/D',$out['utm_term'])){$out['f3_ads_group_id']=$out['utm_term'];}$out['ids_origem']=$out['f3_ads_v']==='1'?'contrato_v1':'parametros_meta_numericos';}
        $out['conta_id']=$out['f3_ads_account_id'];$out['grupo_id']=$out['f3_ads_group_id'];
        self::mapas($out,$v);
        if(($out['utm_campaign']===''||$out['utm_campaign']===$out['campanha_id'])&&$out['conta_id']!==''&&$out['campanha_id']!==''){foreach((array)F3Base_Options::ler('f3base_campanhas_nomes') as $row){if(($row['plataforma']??'')===$out['plataforma']&&($row['conta']??'')===$out['conta_id']&&($row['campanha']??'')===$out['campanha_id']){$out['utm_campaign']=$row['nome'];$out['nome_campanha_origem']='mapa_do_site';break;}}}
        foreach(array('campanha_id','anuncio_id','conta_id','grupo_id') as $id){if(preg_match('/[{}]/',$out[$id])){$out[$id]='';$out['cobertura']='macro_nao_substituida';}}
        $out['cobertura']=$out['cobertura']??($out['anuncio_id']!==''&&$out['conta_id']!==''&&$out['plataforma']!=='nao_identificada'?'anuncio':($out['campanha_id']!==''?'campanha':'parcial'));
        if($snapshots){foreach(array('sessao_origem','primeiro_toque','ultimo_toque') as $k){if(isset($v[$k])&&is_array($v[$k])){$out[$k]=self::normalizar($v[$k],false);}}}
        return $out;
    }
    /** Policy for collection, shared by forms and clicks; never reinterprets a saved touch as the current navigation. */
    public static function para_captura($valor, bool $medicao, bool $publicidade): array {
        $v=is_array($valor)?$valor:array();
        if(!$medicao){
            // Without a current-navigation snapshot, an attributed root cannot prove current source.
            $v=is_array($v['sessao_origem']??null)?$v['sessao_origem']:(in_array($v['modelo']??'sessao',array('sessao','informado'),true)?$v:array());
            unset($v['primeiro_toque'],$v['ultimo_toque'],$v['sessao_origem'],$v['primeiro_toque_em'],$v['ultimo_toque_em']);$v['modelo']='sessao';
        }
        $out=self::normalizar($v,$medicao);
        if(!$medicao){unset($out['primeiro_toque_em'],$out['ultimo_toque_em']);$out['modelo']='sessao';}
        if(!$publicidade){
            $limpar=static function(array $a)use(&$limpar):array{
                foreach(array('utm_campaign_original','ids_origem','conta_origem','fbc','fbp','gclid','gbraid','wbraid','fbclid','li_fat_id','msclkid','oppref','campanha_id','anuncio_id','conta_id','grupo_id','f3_ads_account_id','f3_ads_group_id','f3_ads_group_name','f3_ads_ad_name','utm_id','utm_content') as $k){unset($a[$k]);}
                foreach(array('sessao_origem','primeiro_toque','ultimo_toque') as $k){if(is_array($a[$k]??null)){$a[$k]=$limpar($a[$k]);}}
                return $a;
            };$out=$limpar($out);
        }
        return $out;
    }
    public static function plataforma(array $v): string {
        if(!empty($v['oppref'])){return 'openai_ads';}
        $src=strtolower($v['utm_source']??'');$medium=strtolower($v['utm_medium']??'');$platform=strtolower($v['utm_source_platform']??'');
        if(in_array($src,array('openai','chatgpt','openai_ads'),true)&&in_array($medium,array('paid','cpc','ppc','paid_social','paid_search','paidsocial','paid-search','cpm','display'),true)){return 'openai_ads';}
        if($platform==='openai_ads'&&in_array($medium,array('paid','cpc','ppc','paid_social','paid_search','paidsocial','paid-search','cpm','display'),true)){return 'openai_ads';}
        $x=strtolower($v['utm_source_platform']??'');$map=array('meta'=>'meta_ads','meta_ads'=>'meta_ads','google'=>'google_ads','google_ads'=>'google_ads','linkedin'=>'linkedin_ads','linkedin_ads'=>'linkedin_ads');
        if(isset($map[$x])){return $map[$x];}if(!empty($v['gclid'])||!empty($v['gbraid'])||!empty($v['wbraid'])){return 'google_ads';}if(in_array($src,array('ig','instagram','fb','facebook','an','msg','meta'),true)&&in_array($medium,array('paid','cpc','ppc','paid_social','paidsocial','paid-social','cpm','display'),true)){return 'meta_ads';}if(!empty($v['fbclid'])||!empty($v['fbc'])){return 'meta';}return 'nao_identificada';
    }
    /** Mapas são restritos à origem e à conta; nunca alteram o parâmetro original. */
    private static function mapas(array &$out,array $entrada): void {
        $out['utm_campaign_original']=is_string($entrada['utm_campaign_original']??null)?substr(sanitize_text_field($entrada['utm_campaign_original']),0,500):$out['utm_campaign'];
        foreach(array('nome_campanha_origem','nome_anuncio_origem','conta_origem') as $k){if(is_string($entrada[$k]??null)){$out[$k]=substr(sanitize_text_field($entrada[$k]),0,100);}}
        $origem=array('meta_ads'=>'meta','google_ads'=>'google')[$out['plataforma']]??'';if($origem===''){return;}
        $cfg=F3Base_Options::ler('f3base_anuncios_'.$origem);$conta=(string)($cfg['conta_id']??'');
        if($conta===''||($out['conta_id']!==''&&$out['conta_id']!==$conta)){return;}
        $map=(array)($cfg['mapeamento']??array());$id=$out['campanha_id'];
        // A conta configurada só é usada quando há correspondência explícita no mapa.
        $nome=$map['campanhas'][$id]??null;
        if($id!==''&&is_string($nome)&&$nome!==''&&($out['utm_campaign']===''||$out['utm_campaign']===$id)){$out['utm_campaign']=substr(sanitize_text_field($nome),0,500);$out['nome_campanha_origem']='mapa_da_origem';if($out['conta_id']===''){$out['conta_id']=$conta;$out['f3_ads_account_id']=$conta;$out['conta_origem']='mapa_da_origem';}}
        $anuncio=$map['anuncios'][$out['anuncio_id']]??null;
        if($out['conta_id']===$conta&&$out['f3_ads_ad_name']===''&&is_string($anuncio)&&$anuncio!==''){$out['f3_ads_ad_name']=substr(sanitize_text_field($anuncio),0,500);$out['nome_anuncio_origem']='mapa_da_origem';}
    }
    public static function validar($v,bool $snapshots=true): bool {
        $permitidos=array_merge(self::CAMPOS,array('origem_tipo','plataforma_fonte','utm_campaign_original','nome_campanha_origem','nome_anuncio_origem','conta_origem','ids_origem','referrer','modelo','contrato','plataforma','campanha_id','anuncio_id','conta_id','grupo_id','cobertura','fonte','meio','campanha','conteudo','termo','fbc','fbp','msclkid','primeiro_toque_em','ultimo_toque_em','superficie_anuncio','oppref_estado','conflito_plataforma','origem_ia','entrada','inicio_em','inicio_conhecido'));
        if(!is_array($v)){return false;}
        foreach($v as $k=>$x){if($snapshots&&in_array($k,array('sessao_origem','primeiro_toque','ultimo_toque'),true)){if(!self::validar($x,false)){return false;}continue;}if(!in_array($k,$permitidos,true)||!is_string($x)||($k!=='oppref'&&strlen($x)>2000)){return false;}}
        return true;
    }
    public static function chave(array $v): string {
        $a=self::normalizar($v);
        return wp_json_encode(array($a['plataforma'],$a['conta_id'],$a['campanha_id'],$a['grupo_id'],$a['anuncio_id'],$a['anuncio_id']?'':$a['utm_source'],$a['campanha_id']?'':$a['utm_campaign'],$a['anuncio_id']?'':$a['utm_content']));
    }
    public static function enfileirar(): void {
        if(wp_script_is('f3base-contexto','registered')){return;}
        wp_register_script('f3base-contexto',F3BASE_PLUGIN_URL.'assets/f3base-contexto.min.js',array('f3base-consentimento'),F3BASE_PLUGIN_VERSAO,array('in_footer'=>true,'strategy'=>'defer'));
        $t=F3Base_Testes::config();unset($t['capi_test_event_code'],$t['email_destinatarios']);
        wp_localize_script('f3base-contexto','f3baseContextoDados',array('diagnosticoUrl'=>rest_url(F3BASE_REST_NAMESPACE.'/contexto-diagnostico'),'contextoUrl'=>rest_url(F3BASE_REST_NAMESPACE.'/contexto-publico'),'audienciaExcluida'=>F3Base_Audiencia::pagina_excluida(),'campos'=>self::CAMPOS,'testes'=>$t,'atribuicao'=>F3Base_Options::ler('f3base_atribuicao'),'carregamento'=>F3Base_Options::ler('f3base_carregamento_destinos')));
    }
}
