## Release atual 1.31.0

- [Mudanças e pedidos 194–208](RELEASE-1.31.0.md)
- [Cron](CRON-DIAGNOSTICO-1.31.md)
- [Impactos nos companheiros](IMPACTO-1.31.0.md)

# Documentação instalada — Core 1.30.0

Caminho: `wp-content/plugins/base-site-core-fator3/docs/`. Use `f3base/documentacao-ler` com arquivo, linha e limite até 200; a resposta informa hash e continuação. Requer `manage_options`, inclusive em recuperação.

| Documento | Uso |
|---|---|
| RELEASE-1.30.0.md | Alterações, rastreabilidade e implantação |
| CONFIGURACOES-1.29.md | Entrada única, localização dos controles e escolhas |
| QUALIDADE-META-1.29.md | Mapa genérico CRM/Meta, fila, credenciais e limites |
| AGENTES-1.30.0.md / INSTRUCOES-DO-PLUGIN.md | Operação, testes, leitura e backup conjunto |
| FORMULARIOS-1.29.md | Etapas, diálogo, CTA real e tratamento de falhas |
| HISTORICO-1.29.md | Origem, conversão, retenção, limites e relatórios |
| VALIDACAO.md | Ensaios locais e o que exige conta real |
| IMPACTO-1.30.0.md | Encaminhamento a MCP, Google e implantação/tema |
| AJUDA-OPCOES.md / dados/ajuda-opcoes.json | Ajuda gerada do código, sem valores do site |
| CONTRACTS.md / dados/configuracao-schema.json / dados/abilities-*.json | Contratos executáveis atuais |
| DICIONARIO-DADOS.md / dados/contrato.json | Estruturas e relacionamentos |
| ../dados/estado-inventario.json | Propriedade, backup, retenção e uninstall |
| PIPEDRIVE.md / ORIGENS-ANUNCIOS.md | Contratos de entrega e captação preservados |

Os guias 1.28 de Slack, Meta Acesso e formulários continuam descrevendo contratos preservados. Os complementos 1.29 prevalecem em localização, limites, novas opções e comportamento. Documentação não ativa integração nem comprova autorização remota.

## Complementos vigentes da 1.30

- SLACK-1.30.md: manutenção e testes registrados.
- PUBLICIDADE-1.30.md: política, negativa e medição.
- QUALIDADE-CATALOGO-1.30.md: catálogo pelo MCP.
- CRON-DIAGNOSTICO-1.30.md: prova de estado e limites.

Esses complementos prevalecem sobre orientações anteriores nos tópicos modificados.
