
# Dicionário de dados — Core 1.31.0


Contrato 6.7.0. Gerado do inventário executável e de SHOW COLUMNS em instalação atualizada. 54 tabelas.


O prefixo WordPress substitui `wp_`. Campos UTC e Unix não devem ser interpretados no fuso do site sem conversão. Valores configurados, segredos e registros de pessoas não integram este documento.


O JSON complementar em `docs/dados/contrato.json` contém metadados de retenção, granularidade e vínculos. Leia também `docs/RELEASE-1.31.0.md`.


## f3base_acessos


**granularidade**: Uma combinação de dia, classificação de agente/caminho, caminho, HTTP e método.


**indices**: `{"agregado": {"unico": true, "colunas": ["dia", "agente", "classe_caminho", "caminho", "status", "metodo", "dimensao"]}, "dia_classe": {"unico": false, "colunas": ["dia", "classe_caminho"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| dia | date | não | null | PRI |
| agente | varchar(64) | não | null | PRI |
| classe_caminho | varchar(16) | não | null | PRI |
| dimensao | char(64) | não | "" | PRI |
| post_id | bigint unsigned | não | "0" | — |
| tipo_conteudo | varchar(32) | não | "" | — |
| representacao | varchar(20) | não | "nao_resolvida" | — |
| resolucao | varchar(32) | não | "historico_sem_identidade" | — |
| rede_estado | varchar(24) | não | "nao_verificada" | — |
| rede_lista | char(64) | não | "" | — |
| rede_data | bigint unsigned | não | "0" | — |
| rede_versao | varchar(64) | não | "" | — |
| assinatura_ua | varchar(80) | não | "historico_desconhecido" | — |
| assinatura_regra | varchar(24) | não | "" | — |
| caminho | varchar(191) | não | null | PRI |
| status | smallint unsigned | não | null | PRI |
| metodo | varchar(5) | não | null | PRI |
| contagem | bigint unsigned | não | null | — |
| primeiro_em | datetime | sim | null | — |
| ultimo_em | datetime | sim | null | — |
| instantes_validos | bigint unsigned | não | "0" | — |

## f3base_acessos_contribuicoes


**granularidade**: Contribuição por arquivo/fonte e chave agregada, com versão de regra.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["fonte", "chave"]}, "dia_regra": {"unico": false, "colunas": ["dia", "regra"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| fonte | char(64) | não | null | PRI |
| chave | char(64) | não | null | PRI |
| regra | char(64) | não | null | — |
| dia | date | não | null | MUL |
| agente | varchar(64) | não | null | — |
| classe_caminho | varchar(16) | não | null | — |
| dimensao | char(64) | não | "" | — |
| post_id | bigint unsigned | não | "0" | — |
| tipo_conteudo | varchar(32) | não | "" | — |
| representacao | varchar(20) | não | "nao_resolvida" | — |
| resolucao | varchar(32) | não | "historico_sem_identidade" | — |
| rede_estado | varchar(24) | não | "nao_verificada" | — |
| rede_lista | char(64) | não | "" | — |
| rede_data | bigint unsigned | não | "0" | — |
| rede_versao | varchar(64) | não | "" | — |
| assinatura_ua | varchar(80) | não | "historico_desconhecido" | — |
| assinatura_regra | varchar(24) | não | "" | — |
| caminho | varchar(191) | não | null | — |
| status | smallint unsigned | não | null | — |
| metodo | varchar(5) | não | null | — |
| contagem | bigint unsigned | não | null | — |
| primeiro_em | datetime | sim | null | — |
| ultimo_em | datetime | sim | null | — |
| instantes_validos | bigint unsigned | não | "0" | — |

## f3base_analise


**granularidade**: Um evento por evento; vital conserva a última sequência dessa identidade.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "evento": {"unico": true, "colunas": ["evento"]}, "periodo": {"unico": false, "colunas": ["criado_em", "tipo"]}, "trafego_periodo": {"unico": false, "colunas": ["classe_trafego", "criado_em", "tipo"]}, "sessao": {"unico": false, "colunas": ["sessao", "criado_em"]}, "navegacao": {"unico": false, "colunas": ["navegacao", "tipo"]}, "conteudo_periodo": {"unico": false, "colunas": ["post_id", "criado_em"]}, "inicio_sessao": {"unico": false, "colunas": ["inicio_sessao", "sessao"]}, "tipo_periodo": {"unico": false, "colunas": ["tipo_conteudo", "criado_em"]}, "visitante": {"unico": false, "colunas": ["visitante"]}, "correlacao": {"unico": false, "colunas": ["correlacao"]}}`


**cliques_nomeados**: `{"tipo": "clique_interno", "rotulo": "clique_rotulo, até 160 caracteres", "destino": "clique_destino, caminho local até 190 bytes, sem query/fragmento/arquivo privado", "desde": "1.29.0"}`


**consentimento_1280**: decisao_ref e publicidade são resolvidos no servidor na captura; não copiar autorização enviada pelo navegador.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| evento | char(32) | não | null | UNI |
| visitante | char(32) | não | null | MUL |
| sessao | char(32) | não | null | MUL |
| classe_trafego | varchar(16) | não | "nao_marcado" | MUL |
| navegacao | char(32) | não | null | MUL |
| navegacao_anterior | char(32) | não | "" | — |
| automacao | varchar(20) | não | "nao_identificada" | — |
| automacao_motivos | varchar(190) | não | "" | — |
| automacao_regra | varchar(40) | não | "" | — |
| post_id | bigint unsigned | não | "0" | MUL |
| tipo_conteudo | varchar(32) | não | "" | MUL |
| representacao | varchar(20) | não | "html" | — |
| aquisicao_regra | varchar(40) | não | "" | — |
| aquisicao_evidencia | varchar(64) | não | "" | — |
| aquisicao_conflitos | varchar(190) | não | "" | — |
| canal | varchar(32) | não | "direto_desconhecido" | — |
| origem_ia | varchar(24) | não | "" | — |
| entrada | varchar(190) | não | "" | — |
| inicio_sessao | bigint unsigned | não | "0" | MUL |
| tipo | varchar(20) | não | null | — |
| caminho | varchar(190) | não | null | — |
| formulario | varchar(80) | não | "" | — |
| formulario_revisao | varchar(64) | não | "" | — |
| correlacao | varchar(64) | não | "" | MUL |
| dispositivo | varchar(16) | não | null | — |
| largura_faixa | varchar(12) | não | "" | — |
| navegador | varchar(16) | não | "" | — |
| sistema | varchar(12) | não | "" | — |
| retorno | varchar(10) | não | "" | — |
| aparelho | varchar(16) | não | "" | — |
| criado_em | bigint unsigned | não | null | MUL |
| recebido_em | bigint unsigned | não | null | — |
| qualidade | varchar(16) | não | null | — |
| oferta_id | varchar(80) | não | "" | — |
| oferta_tipo | varchar(16) | não | "" | — |
| oferta_instancia | char(32) | não | "" | — |
| detalhe | varchar(64) | não | "" | — |
| clique_rotulo | varchar(160) | não | "" | — |
| clique_destino | varchar(190) | não | "" | — |
| valor | double | não | "0" | — |
| sequencia | int unsigned | não | "1" | — |
| decisao_ref | char(64) | não | "" | — |
| publicidade | tinyint | não | "0" | — |
| atribuicao | text | não | null | — |
| payload_hash | char(64) | não | null | — |

## f3base_arquivos_leads


**granularidade**: Um arquivo físico privado identificado por ID/hash.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "dono": {"unico": false, "colunas": ["dono"]}, "estado": {"unico": false, "colunas": ["estado", "criado_em"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | varchar(32) | não | null | PRI |
| dono | varchar(32) | não | "" | MUL |
| finalidade | varchar(20) | não | null | — |
| nome | text | não | null | — |
| mime | varchar(120) | não | null | — |
| mime_alerta | varchar(80) | não | "" | — |
| blob_id | varchar(32) | não | "" | — |
| atualizado_em | bigint | não | "0" | — |
| midia_id | bigint | não | "0" | — |
| bytes | bigint unsigned | não | null | — |
| sha256 | varchar(64) | não | null | — |
| criado_em | bigint | não | null | — |
| estado | varchar(20) | não | "preparado" | MUL |

## f3base_atendimento_historico


**granularidade**: Uma mudança operacional por record_id e revisão.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "alteracao": {"unico": true, "colunas": ["record_id", "revisao"]}, "periodo": {"unico": false, "colunas": ["em"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| record_id | char(32) | não | null | MUL |
| revisao | bigint unsigned | não | null | — |
| anterior | varchar(20) | não | null | — |
| atual | varchar(20) | não | null | — |
| em | bigint unsigned | não | null | MUL |
| operador | bigint unsigned | não | null | — |

## f3base_capi_fila


**granularidade**: Uma entrega durável por chave idempotente (Lead ou PageView); vínculo de captura por evento_hash.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["record_id"]}, "pendentes": {"unico": false, "colunas": ["estado", "proxima"]}, "expiracao": {"unico": false, "colunas": ["expira"]}}`


**documentacao**: docs/META-TRANSPORTE-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| record_id | varchar(128) | não | null | PRI |
| payload | longtext | não | null | — |
| estado | varchar(16) | não | null | MUL |
| tentativas | int unsigned | não | "0" | — |
| proxima | bigint unsigned | não | "0" | — |
| expira | bigint unsigned | não | null | MUL |
| atualizado | bigint unsigned | não | null | — |
| reserva | varchar(64) | não | "" | — |
| http | int | não | "0" | — |
| pixel_id | varchar(64) | não | "" | — |
| decisao_ref | varchar(64) | não | "" | — |
| politica_versao | varchar(64) | não | "" | — |
| iniciado | bigint unsigned | não | "0" | — |
| cancelado | bigint unsigned | não | "0" | — |
| lead_id | bigint unsigned | não | "0" | — |
| eliminar_lead | int | não | "0" | — |
| limpeza_pendente | int | não | "0" | — |
| motivo | varchar(64) | não | "" | — |
| agendamento_falhou | int | não | "0" | — |
| schema_versao | int | não | "3" | — |
| evento_hash | char(64) | não | "" | — |
| classe_trafego | varchar(16) | não | "nao_marcado" | — |
| evento_nome | varchar(32) | não | "Lead" | — |
| evento_em | bigint | não | "0" | — |
| rota | varchar(20) | não | "ambos" | — |
| prazo_regra | varchar(100) | não | "legado_1h" | — |

## f3base_comportamento


**granularidade**: Uma combinação de dia, caminho, métrica, detalhe, classe e regra/fuso.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}, "classe_dia": {"unico": false, "colunas": ["classe_trafego", "dia"]}, "dia": {"unico": false, "colunas": ["dia"]}, "dia_metrica": {"unico": false, "colunas": ["dia", "metrica"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| classe_trafego | varchar(16) | não | "nao_marcado" | MUL |
| dia | char(10) | não | null | MUL |
| caminho | varchar(190) | não | null | — |
| metrica | varchar(64) | não | null | — |
| detalhe | varchar(160) | não | "" | — |
| contagem | bigint unsigned | não | "0" | — |
| soma | double | não | "0" | — |
| regra | varchar(64) | não | "legado" | — |
| fuso | varchar(64) | não | "UTC" | — |
| qualidade | varchar(16) | não | "legado" | — |
| atualizado_em | bigint unsigned | não | "0" | — |

## f3base_concessoes


**granularidade**: Uma concessão de material/versão para um lead, com quota e validade.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "dedup": {"unico": true, "colunas": ["dedup"]}, "lead_record_id": {"unico": false, "colunas": ["lead_record_id"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | varchar(32) | não | null | PRI |
| lead_record_id | varchar(32) | não | null | MUL |
| ativo | varchar(32) | não | null | — |
| versao | varchar(64) | não | null | — |
| dedup | varchar(64) | sim | null | UNI |
| expira | bigint | não | null | — |
| quota | int | não | null | — |
| usados | int | não | "0" | — |
| revogada | tinyint(1) | não | "0" | — |
| primeira | bigint | não | "0" | — |
| ultima | bigint | não | "0" | — |

## f3base_consentimento_decisoes


**granularidade**: Uma referência de decisão de consentimento e validade.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["ref"]}, "expira_em": {"unico": false, "colunas": ["expira_em"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| ref | varchar(64) | não | null | PRI |
| politica_versao | varchar(64) | não | null | — |
| medicao | tinyint | não | "0" | — |
| publicidade | tinyint | não | "0" | — |
| revogada | tinyint | não | "0" | — |
| expira_em | bigint | não | null | MUL |

## f3base_contatos_legados


**granularidade**: Registro histórico preservado; nenhum importador é executado nesta release.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "origem_chave": {"unico": true, "colunas": ["origem_chave"]}, "email": {"unico": false, "colunas": ["email"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| origem_chave | varchar(190) | não | null | UNI |
| email | varchar(254) | não | "" | MUL |
| dados | longtext | não | null | — |
| origem_hash | varchar(64) | não | null | — |
| eliminado | tinyint(1) | não | "0" | — |

## f3base_eventos


**granularidade**: Uma ocorrência detalhada da sessão/caminho/métrica; qualidade temporal por linha.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "classe_dia": {"unico": false, "colunas": ["classe_trafego", "dia"]}, "dia": {"unico": false, "colunas": ["dia"]}, "dia_caminho": {"unico": false, "colunas": ["dia", "caminho"]}, "instante": {"unico": false, "colunas": ["criado_em", "id"]}, "sessao": {"unico": false, "colunas": ["sessao"]}, "visitante": {"unico": false, "colunas": ["visitante"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| classe_trafego | varchar(16) | não | "nao_marcado" | MUL |
| visitante | char(32) | não | null | MUL |
| sessao | char(32) | não | null | MUL |
| navegacao | char(32) | não | "" | — |
| automacao | varchar(20) | não | "nao_identificada" | — |
| automacao_motivos | varchar(190) | não | "" | — |
| automacao_regra | varchar(40) | não | "" | — |
| dia | char(10) | não | null | MUL |
| caminho | varchar(190) | não | null | — |
| metrica | varchar(64) | não | null | — |
| detalhe | varchar(160) | não | "" | — |
| valor | double | não | "0" | — |
| ocorrencia | int unsigned | não | "1" | — |
| ms | bigint unsigned | não | "0" | — |
| criado_em | bigint unsigned | não | "0" | MUL |
| recebido_em | bigint unsigned | não | "0" | — |
| ancora | varchar(16) | não | "" | — |

## f3base_leads


**granularidade**: Um contato ou intenção registrada. Cliques não são formulários aceitos.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "record_id": {"unico": true, "colunas": ["record_id"]}, "idempotencia": {"unico": true, "colunas": ["idempotencia"]}, "origem_chave": {"unico": true, "colunas": ["origem_chave"]}, "cronologia": {"unico": false, "colunas": ["criado_em", "id"]}, "aparelho_periodo": {"unico": false, "colunas": ["aparelho", "criado_em", "id"]}, "trafego_periodo": {"unico": false, "colunas": ["classe_trafego", "criado_em", "id"]}, "sessao": {"unico": false, "colunas": ["sessao"]}, "post_id": {"unico": false, "colunas": ["post_id"]}, "email": {"unico": false, "colunas": ["email"]}, "aviso": {"unico": false, "colunas": ["aviso", "aviso_em"]}}`


**comunicacao_envio**: `{"caminho": "dados.comunicacao_envio", "versao": 3, "desde": "1.29.0", "apresentacao_atual": 4, "complementada_em": "1.29.0", "cifra": "sodium secretbox f3com:v1, derivada de secure_auth", "hash": "SHA-256 das seções canônicas", "corte": "ocorrência <= captura; recebido <= captura+10s", "retencao": "acompanha contato; não depende da retenção bruta de eventos", "consulta": "lead-jornada-ler visao aviso, com permissão de leads", "eliminacao": "dados é limpo na eliminação; fila cancelada", "decisoes_refs": "Hashes das decisões históricas; impedem expurgar referência ainda vinculada ao snapshot e permitem redução posterior."}`


**contador_visitas**: `{"caminho": "dados.contexto.audiencia", "campos": ["visitas", "visitas_minimo", "visitas_desde", "visitas_fonte"], "desde": "1.29.0", "fonte": "contador local por sessão/navegador e classe; não identidade pessoal"}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| record_id | varchar(32) | não | null | UNI |
| correlacao | varchar(64) | sim | null | — |
| sessao | char(32) | sim | null | MUL |
| decisao_ref | char(64) | sim | null | MUL |
| aparelho | varchar(20) | não | "nao_identificado" | MUL |
| classe_trafego | varchar(16) | não | "nao_marcado" | MUL |
| post_id | bigint unsigned | sim | null | MUL |
| resposta | varchar(30) | não | "desligada" | — |
| resposta_em | bigint | não | "0" | — |
| resposta_erro | varchar(100) | não | "" | — |
| formulario | varchar(80) | não | "" | — |
| metodo | varchar(40) | não | null | — |
| captura | varchar(20) | não | "aceito" | — |
| atendimento | varchar(20) | não | "novo" | — |
| lixeira | tinyint(1) | não | "0" | — |
| criado_em | datetime | não | null | MUL |
| atualizado_em | datetime | não | null | — |
| email | varchar(254) | não | "" | MUL |
| nome | varchar(250) | não | "" | — |
| pagina | text | não | null | — |
| dados | longtext | não | null | — |
| entrega | longtext | sim | null | — |
| anexos | longtext | não | null | — |
| idempotencia | varchar(64) | sim | null | UNI |
| payload_hash | varchar(64) | não | null | — |
| origem_chave | varchar(190) | sim | null | UNI |
| origem_hash | varchar(64) | não | "" | — |
| importado_hash | varchar(64) | não | "" | — |
| revisao | bigint unsigned | não | "1" | — |
| aviso | varchar(30) | não | "desligado" | MUL |
| aviso_em | bigint | não | "0" | — |
| aviso_erro | varchar(100) | não | "" | — |
| eliminacao_pendente | tinyint(1) | não | "0" | — |

## f3base_leads_dedup


**granularidade**: Uma reserva/chave técnica de deduplicação, sem valor comercial isolado.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}, "criado_em": {"unico": false, "colunas": ["criado_em"]}, "tipo_expira": {"unico": false, "colunas": ["tipo", "expira_em"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| tipo | varchar(12) | não | "dedup" | MUL |
| estado | varchar(10) | não | "pendente" | — |
| record_id | char(32) | não | "" | — |
| contador | int unsigned | não | "0" | — |
| expira_em | bigint unsigned | não | "0" | — |
| criado_em | bigint unsigned | não | null | MUL |

## f3base_leads_janelas


**granularidade**: Uma quota técnica com prazo de expiração.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}, "expira": {"unico": false, "colunas": ["expira"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | varchar(190) | não | null | PRI |
| total | bigint | não | "0" | — |
| expira | bigint | não | null | MUL |

## f3base_leads_recusas


**granularidade**: Um total de recusas por motivo e dia, sem dados pessoais.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["dia", "motivo"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| dia | date | não | null | PRI |
| motivo | varchar(40) | não | null | PRI |
| total | bigint unsigned | não | "0" | — |
| primeiro | bigint unsigned | não | null | — |
| ultimo | bigint unsigned | não | null | — |

## f3base_vitais


**granularidade**: Uma amostra de vital atualizada por sequência; sem sessão vinculável.


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["amostra"]}, "periodo": {"unico": false, "colunas": ["dia", "metrica", "dispositivo"]}, "classe_dia": {"unico": false, "colunas": ["classe_trafego", "dia"]}, "pagina": {"unico": false, "colunas": ["caminho"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| amostra | char(64) | não | null | PRI |
| classe_trafego | varchar(16) | não | "nao_marcado" | MUL |
| dia | date | não | null | MUL |
| caminho | varchar(760) | não | null | MUL |
| metrica | varchar(8) | não | null | — |
| dispositivo | varchar(16) | não | null | — |
| sequencia | int unsigned | não | null | — |
| valor | double | não | null | — |

## f3base_acessos_horas


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["dia", "hora_utc", "agente", "classe_caminho", "status_grupo", "dimensao"]}, "hora_agente": {"unico": false, "colunas": ["hora_utc", "agente"]}, "conteudo": {"unico": false, "colunas": ["post_id", "hora_utc"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| dia | date | não | null | PRI |
| hora_utc | datetime | não | null | PRI |
| agente | varchar(64) | não | null | PRI |
| classe_caminho | varchar(16) | não | null | PRI |
| status_grupo | varchar(16) | não | null | PRI |
| caminho | varchar(191) | não | "" | — |
| metodo | varchar(5) | não | "" | — |
| status | smallint unsigned | não | "0" | — |
| dimensao | char(64) | não | "" | PRI |
| post_id | bigint unsigned | não | "0" | MUL |
| tipo_conteudo | varchar(32) | não | "" | — |
| representacao | varchar(20) | não | "nao_resolvida" | — |
| resolucao | varchar(32) | não | "historico_sem_identidade" | — |
| rede_estado | varchar(24) | não | "nao_verificada" | — |
| rede_lista | char(64) | não | "" | — |
| rede_data | bigint unsigned | não | "0" | — |
| rede_versao | varchar(64) | não | "" | — |
| assinatura_ua | varchar(80) | não | "historico_desconhecido" | — |
| assinatura_regra | varchar(24) | não | "" | — |
| contagem | bigint unsigned | não | null | — |

## f3base_acessos_horas_fontes


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["fonte", "dia", "hora_utc", "agente", "classe_caminho", "status_grupo", "dimensao"]}, "hora_agente": {"unico": false, "colunas": ["hora_utc", "agente"]}, "conteudo": {"unico": false, "colunas": ["post_id", "hora_utc"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| fonte | char(64) | não | null | PRI |
| regra | char(64) | não | null | — |
| dia | date | não | null | PRI |
| hora_utc | datetime | não | null | PRI |
| agente | varchar(64) | não | null | PRI |
| classe_caminho | varchar(16) | não | null | PRI |
| status_grupo | varchar(16) | não | null | PRI |
| caminho | varchar(191) | não | "" | — |
| metodo | varchar(5) | não | "" | — |
| status | smallint unsigned | não | "0" | — |
| dimensao | char(64) | não | "" | PRI |
| post_id | bigint unsigned | não | "0" | MUL |
| tipo_conteudo | varchar(32) | não | "" | — |
| representacao | varchar(20) | não | "nao_resolvida" | — |
| resolucao | varchar(32) | não | "historico_sem_identidade" | — |
| rede_estado | varchar(24) | não | "nao_verificada" | — |
| rede_lista | char(64) | não | "" | — |
| rede_data | bigint unsigned | não | "0" | — |
| rede_versao | varchar(64) | não | "" | — |
| assinatura_ua | varchar(80) | não | "historico_desconhecido" | — |
| assinatura_regra | varchar(24) | não | "" | — |
| contagem | bigint unsigned | não | null | — |

## f3base_anuncios_recibos


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}, "registro": {"unico": false, "colunas": ["record_id"]}, "recebido": {"unico": false, "colunas": ["recebido_em"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| origem | varchar(16) | não | null | — |
| conta | varchar(100) | não | null | — |
| formulario | varchar(100) | não | null | — |
| nativo_id | varchar(191) | não | null | — |
| record_id | char(32) | não | null | MUL |
| projecao | char(64) | não | null | — |
| nativo_em | bigint unsigned | não | null | — |
| recebido_em | bigint unsigned | não | null | MUL |
| via | varchar(24) | não | null | — |
| eliminado | tinyint | não | "0" | — |

## f3base_pipedrive_fila


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}, "agenda": {"unico": false, "colunas": ["estado", "proxima"]}, "registro": {"unico": false, "colunas": ["record_id"]}, "historico": {"unico": false, "colunas": ["concluido_em"]}}`

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| record_id | char(32) | não | null | MUL |
| conta | varchar(191) | não | null | — |
| estado | varchar(20) | não | "pendente" | MUL |
| etapa | varchar(24) | não | "" | — |
| journal | longtext | não | null | — |
| tentativas | smallint unsigned | não | "0" | — |
| proxima | bigint unsigned | não | null | — |
| lease | char(36) | não | "" | — |
| lease_ate | bigint unsigned | não | "0" | — |
| capturado_em | bigint unsigned | não | null | — |
| primeira_tentativa | bigint unsigned | não | "0" | — |
| concluido_em | bigint unsigned | não | "0" | MUL |
| atualizado_em | bigint unsigned | não | null | — |
| codigo | varchar(100) | não | "" | — |

## f3base_conteudo_rotas


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "rota": {"unico": false, "colunas": ["rota_hash", "inicio", "fim"]}, "post_id": {"unico": false, "colunas": ["post_id", "fim"]}, "recurso": {"unico": false, "colunas": ["recurso", "fim"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| rota_hash | char(64) | não | null | MUL |
| caminho | varchar(190) | não | null | — |
| post_id | bigint unsigned | não | "0" | MUL |
| tipo | varchar(32) | não | null | — |
| representacao | varchar(20) | não | null | — |
| inicio | bigint unsigned | não | null | — |
| fim | bigint unsigned | não | "0" | — |
| proveniencia | varchar(32) | não | null | — |
| recurso | varchar(64) | não | "" | MUL |

## f3base_conteudos


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["post_id"]}, "tipo": {"unico": false, "colunas": ["tipo", "publico"]}, "caminho": {"unico": false, "colunas": ["caminho"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| post_id | bigint unsigned | não | null | PRI |
| tipo | varchar(32) | não | null | MUL |
| titulo | varchar(250) | não | null | — |
| url | text | não | null | — |
| caminho | varchar(190) | não | null | MUL |
| publico | tinyint | não | null | — |
| atualizado_em | bigint unsigned | não | null | — |

## f3base_editorial_diario


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}, "periodo": {"unico": false, "colunas": ["dia", "metrica"]}, "conteudo": {"unico": false, "colunas": ["post_id", "dia"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| dia | date | não | null | MUL |
| post_id | bigint unsigned | não | "0" | MUL |
| caminho | varchar(190) | não | null | — |
| tipo | varchar(32) | não | null | — |
| canal | varchar(32) | não | null | — |
| origem_ia | varchar(24) | não | null | — |
| classe_trafego | varchar(16) | não | null | — |
| automacao | varchar(20) | não | null | — |
| metrica | varchar(32) | não | null | — |
| contagem | bigint unsigned | não | "0" | — |
| soma | double | não | "0" | — |
| atualizado_em | bigint unsigned | não | null | — |

## f3base_editorial_dias


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["dia"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| dia | date | não | null | PRI |
| fechado | tinyint | não | "0" | — |
| atualizado_em | bigint unsigned | não | null | — |
| qualidade | varchar(24) | não | null | — |

## f3base_gsc_diario


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}, "periodo": {"unico": false, "colunas": ["dia", "pesquisa", "escopo"]}, "conteudo": {"unico": false, "colunas": ["post_id", "dia"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| universo | char(64) | não | null | — |
| propriedade | varchar(250) | não | null | — |
| dia | date | não | null | MUL |
| pesquisa | varchar(16) | não | null | — |
| escopo | varchar(16) | não | null | — |
| post_id | bigint unsigned | não | "0" | MUL |
| url | text | não | null | — |
| cliques | double | não | null | — |
| impressoes | double | não | null | — |
| posicao | double | não | null | — |
| estado | varchar(16) | não | null | — |
| extraido_em | bigint unsigned | não | null | — |
| fonte | varchar(128) | não | null | — |
| cobertura | text | não | null | — |
| filtros | text | não | null | — |

## f3base_inteligencia_auditoria


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "registro": {"unico": false, "colunas": ["chave_sha256", "em"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| acao | varchar(40) | não | null | — |
| chave_sha256 | char(64) | não | null | MUL |
| revisao | bigint unsigned | não | null | — |
| operador | bigint unsigned | não | null | — |
| em | bigint unsigned | não | null | — |

## f3base_medicao_anotacoes


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "chave": {"unico": true, "colunas": ["chave"]}, "periodo": {"unico": false, "colunas": ["inicio", "fim"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| chave | varchar(128) | não | null | UNI |
| inicio | date | não | null | MUL |
| fim | date | não | null | — |
| motivo | varchar(500) | não | null | — |
| excluir | tinyint | não | "0" | — |
| revisao | bigint unsigned | não | "1" | — |
| atualizado_em | bigint unsigned | não | null | — |
| operador | bigint unsigned | não | null | — |

## f3base_referencias_ia


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "chave": {"unico": true, "colunas": ["chave"]}, "conteudo": {"unico": false, "colunas": ["post_id", "observado_em"]}, "provedor": {"unico": false, "colunas": ["provedor", "observado_em"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| chave | varchar(128) | não | null | UNI |
| provedor | varchar(24) | não | null | MUL |
| observado_em | bigint unsigned | não | null | — |
| tipo | varchar(24) | não | null | — |
| post_id | bigint unsigned | não | "0" | MUL |
| url | text | não | null | — |
| topico | varchar(250) | não | null | — |
| contexto | text | não | null | — |
| evidencia | text | não | null | — |
| evidencia_tipo | varchar(16) | não | null | — |
| origem | varchar(16) | não | null | — |
| revisao_estado | varchar(16) | não | null | — |
| revisao | bigint unsigned | não | "1" | — |
| criado_em | bigint unsigned | não | null | — |
| atualizado_em | bigint unsigned | não | null | — |
| operador | bigint unsigned | não | null | — |

## f3base_acessos_legado


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}, "periodo": {"unico": false, "colunas": ["dia", "origem"]}}`


**documentacao**: docs/MEDICAO-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| dia | date | não | null | MUL |
| regra | varchar(64) | não | null | — |
| origem | varchar(16) | não | null | — |
| contagem | bigint unsigned | não | null | — |
| arquivado_em | bigint unsigned | não | null | — |
| dados | longtext | não | null | — |

## f3base_arquivos_blobs


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["blob_id"]}, "limpeza": {"unico": false, "colunas": ["estado", "retirar_em"]}}`


**documentacao**: docs/ARQUIVOS-PRIVADOS-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| blob_id | char(32) | não | null | PRI |
| ativo | char(32) | não | null | — |
| estado | varchar(20) | não | null | MUL |
| criado_em | bigint | não | null | — |
| retirar_em | bigint | não | "0" | — |

## f3base_arquivos_operacoes


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["chave"]}}`


**documentacao**: docs/ARQUIVOS-PRIVADOS-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| payload_hash | char(64) | não | null | — |
| resultado | longtext | não | null | — |
| criado_em | bigint | não | null | — |

## f3base_clarity


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["coleta", "parser", "bloco", "linha"]}, "conteudo": {"unico": false, "colunas": ["post_id", "coleta"]}, "metrica": {"unico": false, "colunas": ["metrica", "coleta"]}}`


**documentacao**: docs/CLARITY-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| coleta | char(32) | não | null | PRI |
| parser | int | não | null | PRI |
| bloco | int | não | null | PRI |
| linha | int | não | null | PRI |
| metrica | varchar(160) | não | null | MUL |
| dimensoes | text | não | null | — |
| valores | longtext | não | null | — |
| post_id | bigint | não | "0" | MUL |
| caminho | varchar(190) | não | "" | — |
| estado | varchar(40) | não | null | — |

## f3base_clarity_coletas


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "execucao": {"unico": true, "colunas": ["projeto", "chave"]}, "periodo": {"unico": false, "colunas": ["projeto", "solicitado_em", "id"]}, "qualidade": {"unico": false, "colunas": ["estado", "solicitado_em"]}}`


**documentacao**: docs/CLARITY-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | char(32) | não | null | PRI |
| projeto | varchar(32) | não | null | MUL |
| chave | char(64) | não | null | — |
| parametros | text | não | null | — |
| origem | varchar(16) | não | null | — |
| solicitado_em | bigint | não | null | — |
| recebido_em | bigint | não | "0" | — |
| duracao_ms | bigint | não | "0" | — |
| janela_dias | smallint | não | null | — |
| inicio_nominal | bigint | não | null | — |
| fim_nominal | bigint | não | null | — |
| estado | varchar(40) | não | null | MUL |
| http | int | não | "0" | — |
| motivo | varchar(80) | não | "" | — |
| resposta | longblob | sim | null | — |
| sha256 | char(64) | não | "" | — |
| saneamento | int | não | "1" | — |
| parser | int | não | "0" | — |
| bytes_brutos | bigint | não | "0" | — |
| bytes_comprimidos | bigint | não | "0" | — |
| cobertura | longtext | não | null | — |

## f3base_meta_eventos


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["evento"]}, "periodo": {"unico": false, "colunas": ["criado_em", "nome", "rota"]}}`


**documentacao**: docs/META-TRANSPORTE-1.19.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| evento | char(64) | não | null | PRI |
| nome | varchar(32) | não | null | — |
| criado_em | bigint | não | null | MUL |
| rota | varchar(20) | não | null | — |
| navegador_observado | tinyint | não | "0" | — |
| classe_trafego | varchar(16) | não | null | — |
| atualizado_em | bigint | não | null | — |

## f3base_execucoes


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "run_id": {"unico": true, "colunas": ["run_id"]}, "ocorrencia": {"unico": true, "colunas": ["ocorrencia"]}, "origem_janela": {"unico": false, "colunas": ["parent_run_id", "origem", "inicio"]}, "tarefas": {"unico": false, "colunas": ["tarefa", "inicio"]}}`


**documentacao**: docs/OPERACAO-GSC-1.20.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| run_id | varchar(64) | não | null | UNI |
| parent_run_id | varchar(64) | não | "" | MUL |
| origem | varchar(16) | não | null | — |
| entrada | varchar(24) | não | null | — |
| tarefa | varchar(64) | não | "" | MUL |
| hook | varchar(100) | não | "" | — |
| ocorrencia | char(64) | sim | null | UNI |
| inicio | bigint unsigned | não | null | — |
| fim | bigint unsigned | não | "0" | — |
| sucesso | tinyint | sim | null | — |
| codigo | varchar(100) | não | "" | — |
| core_examinado | tinyint | não | "0" | — |
| dados | longtext | não | null | — |

## f3base_gsc_coletas


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["id"]}, "universo_dia": {"unico": false, "colunas": ["universo", "dia", "publicado"]}, "fila": {"unico": false, "colunas": ["estado", "proxima_tentativa", "criado_em"]}, "historico": {"unico": false, "colunas": ["propriedade", "dia", "criado_em"]}}`


**documentacao**: docs/OPERACAO-GSC-1.20.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | char(32) | não | null | PRI |
| universo | char(64) | não | null | MUL |
| propriedade | varchar(250) | não | null | MUL |
| revision | varchar(128) | não | "" | — |
| dia | date | não | null | — |
| origem | varchar(24) | não | null | — |
| pesquisa | varchar(16) | não | "web" | — |
| escopo | varchar(16) | não | "paginas" | — |
| filtros | text | não | null | — |
| estado | varchar(32) | não | null | MUL |
| criado_em | bigint unsigned | não | null | — |
| atualizado_em | bigint unsigned | não | null | — |
| extraido_em | bigint unsigned | não | "0" | — |
| publicado | tinyint | não | "0" | — |
| cursor | text | não | null | — |
| limite | int unsigned | não | "1000" | — |
| paginas | int unsigned | não | "0" | — |
| linhas | int unsigned | não | "0" | — |
| cobertura | longtext | não | null | — |
| recibos | longtext | não | null | — |
| run_id | varchar(100) | não | "" | — |
| connection_id | varchar(100) | não | "" | — |
| codigo | varchar(100) | não | "" | — |
| proxima_tentativa | bigint unsigned | não | "0" | — |

## f3base_gsc_linhas


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["coleta_id", "chave"]}, "conteudo": {"unico": false, "colunas": ["post_id", "coleta_id"]}}`


**documentacao**: docs/OPERACAO-GSC-1.20.md

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| coleta_id | char(32) | não | null | PRI |
| chave | char(64) | não | null | PRI |
| url | text | não | null | — |
| post_id | bigint unsigned | não | "0" | MUL |
| classe | varchar(24) | não | "fora_do_site" | — |
| cliques | double | não | null | — |
| impressoes | double | não | null | — |
| posicao | double | não | null | — |

## f3base_gsc_lacunas


**indices**: `{"PRIMARY": {"unico": true, "colunas": ["universo", "dia"]}, "estado_dia": {"unico": false, "colunas": ["universo", "estado", "dia"]}}`


**documentacao**: docs/RELEASE-1.21.md


**granularidade**: Um estado de cobertura por universo/dia. Consulta sem linhas resolve a lacuna sem inferir visitas zero.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| universo | char(64) | não | null | PRI |
| propriedade | varchar(250) | não | null | — |
| dia | date | não | null | PRI |
| estado | varchar(24) | não | "pendente" | — |
| primeira_observacao | bigint unsigned | não | null | — |
| ultima_observacao | bigint unsigned | não | null | — |
| motivo | varchar(100) | não | "nao_coletado" | — |
| coleta | char(32) | não | "" | — |
| resolvida_em | bigint unsigned | não | "0" | — |

## f3base_operacao_intencoes


**granularidade**: Uma intenção durável por ocorrência; estados concluída/esgotada não apagam histórico.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| escopo | char(64) | não | null | MUL |
| tarefa | varchar(64) | não | null | MUL |
| hook | varchar(100) | não | null | — |
| argumentos | longtext | não | null | — |
| ocorrencia_em | bigint | não | null | — |
| recorrencia | varchar(64) | não | "" | — |
| estado | varchar(24) | não | "pendente" | MUL |
| falhas | tinyint unsigned | não | "0" | — |
| quota_adiamentos | smallint unsigned | não | "0" | — |
| tentar_em | bigint | não | "0" | — |
| cobertura_ate | bigint | não | "0" | — |
| codigo | varchar(64) | não | "" | — |
| criada_em | bigint | não | null | — |
| atualizada_em | bigint | não | null | — |
| reserva | char(36) | não | "" | — |
| reserva_ate | bigint | não | "0" | — |
| reativada_por | bigint | não | "0" | — |
| reativada_origem | varchar(24) | não | "" | — |

## f3base_consentimento_reparos


**granularidade**: Pendência de projeção da referência por lead; após três conflitos exige revisão.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| lead_id | bigint unsigned | não | null | PRI |
| tentativas | tinyint unsigned | não | "0" | — |
| codigo | varchar(64) | não | null | — |
| atualizado_em | bigint | não | null | — |

## f3base_audiencia_404


**estimativa**: contagem histórica exata + 100 × amostras da 1.25; sorteio 1:100 antes de acesso à tabela, retenção 90 dias.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| dia | date | não | null | PRI |
| caminho | varchar(190) | não | null | PRI |
| contagem | bigint unsigned | não | "0" | — |
| amostras | bigint unsigned | não | "0" | — |
| ultimo_em | bigint unsigned | não | "0" | — |

## f3base_avisos_fila


**granularidade**: Uma intenção externa (Slack ou JSON HMAC) por contato e ciclo; transporte/revisão congelados em dados.aviso_intencao; payload cifrado não integra relatórios públicos.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| record_id | char(32) | não | null | MUL |
| destino | char(64) | não | null | MUL |
| ciclo | int unsigned | não | "1" | — |
| estado | varchar(16) | não | "pendente" | MUL |
| codigo | varchar(64) | não | "" | — |
| payload | longtext | não | null | — |
| tentativas | smallint unsigned | não | "0" | — |
| proxima | bigint unsigned | não | "0" | — |
| criada_em | bigint unsigned | não | null | — |
| atualizada_em | bigint unsigned | não | null | — |
| enviada_em | bigint unsigned | não | "0" | — |
| reserva | char(36) | não | "" | — |
| reserva_ate | bigint unsigned | não | "0" | — |
| lote | char(36) | não | "" | — |
| contingencia | varchar(32) | não | "" | — |
| classe | varchar(16) | não | "nao_marcado" | — |
| autor | bigint unsigned | não | "0" | — |

## f3base_sondas_http


**granularidade**: Agregado por dia, caminho saneado, método GET/HEAD, status HTTP, classe e origem explicitamente declarada. Sem IP, user agent ou query string.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| dia | date | não | null | PRI |
| chave | char(64) | não | null | PRI |
| caminho | varchar(190) | não | null | MUL |
| metodo | varchar(8) | não | null | — |
| status | smallint unsigned | não | "0" | — |
| classe | varchar(16) | não | null | — |
| fonte | varchar(32) | não | null | — |
| quantidade | bigint unsigned | não | "0" | — |
| primeiro_em | bigint unsigned | não | null | — |
| ultimo_em | bigint unsigned | não | null | — |

## f3base_avisos_partes


**granularidade**: Uma principal/resposta/atualização Slack com identidade durável.


**payload**: Secretbox f3av:v1; não integra relatórios públicos. ts é STRING, nunca número. principal aponta chave local; canal/destino vinculam a intenção original.


**entrega**: Uma parte por passagem; lease/reserva_ate e proxima em Unix UTC; confirmação exige HTTP e ok:true.


**retencao**: Payload terminal até 90 dias; vínculos essenciais e pendências preservados; restore/uninstall suspendem; eliminação cancela e limpa payload.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| aviso | char(64) | não | null | MUL |
| record_id | char(32) | não | null | MUL |
| revisao | char(64) | não | "" | — |
| sequencia | int | não | null | — |
| tipo | varchar(24) | não | null | — |
| principal | char(64) | não | null | MUL |
| destino | char(64) | não | null | — |
| canal | varchar(64) | não | null | — |
| ts | varchar(32) | não | "" | — |
| payload | longtext | não | null | — |
| estado | varchar(16) | não | "pendente" | MUL |
| codigo | varchar(64) | não | "" | — |
| tentativas | smallint | não | "0" | — |
| proxima | bigint | não | null | — |
| reserva_ate | bigint | não | "0" | — |
| criada_em | bigint | não | null | — |
| atualizada_em | bigint | não | null | — |

## f3base_complementos


**granularidade**: Uma revisão de complemento por contato/submissão, com hash para idempotência.


**payload**: Secretbox f3com:v1; campos complementares, papéis, metadados dos anexos e decisão de incorporação. Não guarda referência de continuação em texto.


**entrega**: Estados email/slack/crm independentes; journal guarda confirmação, etapa incerta, IDs e decisão administrativa; proxima é Unix UTC.


**retencao**: Histórico comercial acompanha contato; pendências não expiram silenciosamente; restore/uninstall suspendem. Eliminação remove.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| record_id | char(32) | não | null | MUL |
| submissao | char(32) | não | null | — |
| recebido_em | bigint | não | null | — |
| hash | char(64) | não | null | — |
| payload | longtext | não | null | — |
| estado | varchar(24) | não | null | MUL |
| email | varchar(16) | não | "pendente" | — |
| slack | varchar(16) | não | "pendente" | — |
| crm | varchar(16) | não | "pendente" | — |
| journal | longtext | não | null | — |
| proxima | bigint | não | null | — |
| atualizado_em | bigint | não | null | — |

## f3base_contato_campanhas


**granularidade**: Um contato/campanha observada. Campanhas não são aditivas: total usa COUNT DISTINCT record_id.


**vinculos**: campanha SHA-256 de plataforma/conta/ID ou origem/meio/nome; datas 0 significam desconhecidas; sessoes NULL significa sem contagem comprovada.


**privacidade**: decisoes_refs contém hashes de decisões usadas; consultas aplicam revogação conhecida.


**retencao**: Acompanha contato; derivado e reconstruível. Removido na eliminação local.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| record_id | char(32) | não | null | PRI |
| campanha | char(64) | não | null | PRI |
| rotulo | varchar(191) | não | null | MUL |
| plataforma | varchar(32) | não | null | — |
| primeira | bigint | não | null | — |
| ultima | bigint | não | null | — |
| sessoes | int unsigned | sim | null | — |
| decisoes_refs | longtext | não | null | — |

## f3base_sessoes


**granularidade**: Uma sessão por classe de tráfego. Índice derivado; não é fonte adicional de pageviews.


**vinculos**: visitante pseudônimo; origem do primeiro evento elegível em sessao_origem; conflitos impedem associação.


**retencao**: Mesma janela dos eventos brutos; cursor de reconstrução em f3base_sessoes_indice.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| classe | varchar(16) | não | null | PRI |
| sessao | char(32) | não | null | PRI |
| visitante | char(32) | não | null | MUL |
| inicio | bigint | não | null | — |
| primeira | bigint | não | null | — |
| ultima | bigint | não | null | MUL |
| origem | longtext | não | null | — |
| decisao_ref | char(64) | não | "" | — |
| conflito | tinyint | não | "0" | — |
| atualizado_em | bigint | não | null | — |

## f3base_aquisicoes


**granularidade**: Reserva de aquisição por sessão/classe/identidade HMAC; não é outro lead.


**retencao**: 1 dia; elimina junto ao contato.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| sessao | char(32) | não | null | PRI |
| classe | varchar(16) | não | null | PRI |
| identidade | char(64) | não | "" | PRI |
| record_id | char(32) | não | null | MUL |
| event_id | varchar(100) | não | null | — |
| em | bigint unsigned | não | null | MUL |

## f3base_qualidade_atual


**granularidade**: Etapa atual por contato com revisão e precedência manual.


**retencao**: Acompanha contato.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| record_id | char(32) | não | null | PRI |
| evento_id | bigint unsigned | não | null | — |
| etapa | varchar(60) | não | null | MUL |
| origem | varchar(20) | não | null | — |
| ocorreu_em | bigint unsigned | não | null | — |
| manual_fixo | tinyint | não | "0" | — |
| revisao | char(64) | não | null | — |

## f3base_qualidade_eventos


**granularidade**: Ocorrência comercial por contato, com origem, horários, autor e revisão.


**dados**: Payload auxiliar cifrado f3capi:v1; motivo livre não vai à Meta.


**retencao**: Acompanha contato; exclusão local remove.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | bigint unsigned | não | null | PRI |
| chave | char(64) | não | null | UNI |
| record_id | char(32) | não | null | MUL |
| etapa | varchar(60) | não | null | MUL |
| origem | varchar(20) | não | null | — |
| ocorreu_em | bigint unsigned | não | null | — |
| recebido_em | bigint unsigned | não | null | — |
| autor | bigint unsigned | não | "0" | — |
| config_revisao | char(64) | não | null | — |
| dados | longtext | não | null | — |

## f3base_qualidade_fila


**granularidade**: Uma intenção por site/contato/dataset/código de etapa.


**payload**: Cifrado; identidade e conteúdo preservados na repetição. Nunca contém IP/UA do servidor.


**retencao**: Terminais entregues, cancelados e falhos perdem payload após 30 dias. Demais pendências e identidade permanecem até eliminação do contato.


**restore**: Suspender e reconciliar antes de retomar.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| record_id | char(32) | não | null | MUL |
| etapa | varchar(60) | não | null | — |
| evento_id | bigint unsigned | não | null | — |
| dataset | varchar(40) | não | null | — |
| credencial_revisao | char(64) | não | null | — |
| config_revisao | char(64) | não | null | — |
| payload | longtext | não | null | — |
| estado | varchar(20) | não | null | MUL |
| codigo | varchar(80) | não | "" | — |
| proxima | bigint unsigned | não | null | — |
| tentativas | smallint unsigned | não | "0" | — |
| expira | bigint unsigned | não | null | — |
| http | smallint | não | "0" | — |
| atualizado_em | bigint unsigned | não | null | — |

## f3base_qualidade_recibos


**granularidade**: Recibo autenticado de evento Pipedrive antes de ACK.


**retencao**: Processados sem payload; limpeza de processados/revisão após 30 dias.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| chave | char(64) | não | null | PRI |
| record_id | char(32) | não | null | MUL |
| conta | varchar(40) | não | null | — |
| recebido_em | bigint unsigned | não | null | — |
| payload | longtext | não | null | — |
| estado | varchar(20) | não | "pendente" | MUL |
| codigo | varchar(80) | não | "" | — |

## f3base_contexto_diagnostico

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| dia | date | não | null | PRI |
| classe | varchar(20) | não | null | PRI |
| estado | varchar(40) | não | null | PRI |
| total | bigint unsigned | não | "0" | — |

## f3base_slack_manutencao


**granularidade**: Parte Slack, teste de conexão ou operação administrativa registrada nesta instalação.


**identidade**: IDs locais e ts textual; site, destino, workspace, bot e usuário comprovados. teste é classificação da emissão, imutável pelo operador.


**payload**: Secretbox do Core; mensagem e auditoria. Não guarda conversas humanas lidas na thread.


**retencao**: Conteúdo terminal até 90 dias; identidades mínimas permanecem para idempotência. Contato eliminado perde conteúdo relacionado. Sem reenvio automático.


**backup**: Incluir junto ao banco e guarda operacional.


**uninstall**: Preservar histórico; operações são somente sob demanda.

| Coluna | Tipo MySQL | Nulo | Padrão | Chave |
|---|---|---|---|---|
| id | char(64) | não | null | PRI |
| tipo | varchar(16) | não | null | MUL |
| alvo | char(64) | não | "" | — |
| record_id | char(32) | não | "" | MUL |
| teste | tinyint | não | "0" | — |
| site | char(64) | não | null | — |
| destino | char(64) | não | null | — |
| canal | varchar(64) | não | "" | MUL |
| ts | varchar(32) | não | "" | — |
| principal | char(64) | não | "" | MUL |
| team_id | varchar(64) | não | "" | — |
| bot_id | varchar(64) | não | "" | — |
| user_id | varchar(64) | não | "" | — |
| estado | varchar(32) | não | null | — |
| revisao | char(64) | não | null | — |
| payload | longtext | não | null | — |
| criado_em | bigint | não | null | — |
| atualizado_em | bigint | não | null | — |
