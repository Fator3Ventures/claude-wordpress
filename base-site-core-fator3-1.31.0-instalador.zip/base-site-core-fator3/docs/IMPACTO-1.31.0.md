# Encaminhamento aos plugins MCP e MCP Google — Core 1.31.0

Matriz: Core 1.31.0, MCP 0.21.0 e MCP Google 0.8.4. Não foram modificados os fontes dos companheiros.

Não há mudança obrigatória nas APIs dos companheiros: permanecem `server-integration/1.0.0`, política 1 e `search-console-reader/1.0.0`. Core publica contrato 6.7.0 com diagnóstico mais detalhado e eventos de formulário; consumidores devem descobrir schemas e não fixar contagens de abilities.

O apontamento anterior sobre fallback histórico do marcador MCP 0.20.0 foi atendido na versão 0.21.0 recebida. Não deve ser encaminhado novamente como defeito aberto. A prova cron `2.0.0` do Google e a prova própria do Core distinguem confirmação atual, histórico e execução.

Para agentes que configuram serviços Google: o contrato de configuração 4.0.0 aceita `merge:true` para acrescentar GTM mantendo GSC. Redução de concessões exige confirmação/revisão previstas pelo Google. Core não faz essa configuração nem pode conceder GSC a si próprio. Pausa/recuperação, quota e cursores de coleta continuam pertencendo a cada consumidor/plugin.

Para automação de navegador, usar cookie `/f3base-teste/` ou `X-F3Base-Teste: 1` em todas as requisições do site. O Core agora obtém essa marca pelo contexto público sem cache. A marca permanece na navegação antiga ao desativar o cookie, evitando contaminação da audiência pelos eventos de saída. Agente HTTP continua declarando o cabeçalho no próprio pedido.

A manutenção Slack permanece restrita a mensagens registradas pelo Core, sem transformar o WordPress em cliente Slack genérico. A API informa cobertura quando uma thread não pôde ser lida; não declarar que o canal ficou vazio quando há respostas desconhecidas.

Tema e implantador não fazem parte desta entrega. Adaptadores de diálogo customizados podem informar fechamento com `f3baseFormularios.fechar(form)`; isso é contrato opcional de instrumentação, não mudança automática no tema.
