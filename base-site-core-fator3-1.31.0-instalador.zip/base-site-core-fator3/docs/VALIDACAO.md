# Validação — Site Core 1.31.0

Concluída em 12/10/2026. WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46 e Chromium 138; instalação local descartável, dados sintéticos, APIs externas simuladas ou bloqueadas. Nenhum site da frota foi alterado. Não houve teste em korvena.net.br.

**546 verificações aprovadas**, mais lint dos 197 arquivos PHP do plugin. O resumo legível por máquina e os testes acompanham o ZIP de fontes. A contagem corresponde a asserções executadas, não a requisitos distintos.

| Grupo | Verificações |
|---|---:|
| browser-banco-1310 | 10 |
| cron-1310 | 17 |
| pedidos-1310 | 25 |
| integracoes-1310 | 17 |
| crm-1310 | 6 |
| slack-manutencao | 44 |
| slack-app | 16 |
| publicidade | 25 |
| complementos | 12 |
| comunicacao | 82 |
| historico | 27 |
| avisos | 30 |
| qualidade | 18 |
| crm-complemento | 8 |
| operacao-1290 | 16 |
| diagnostico-1290 | 6 |
| telas | 9 |
| funcional | 28 |
| novidades | 27 |
| webhook | 29 |
| browser-1310 | 9 |
| cron-falhas-1310 | 4 |
| cron-nativo-1310 | 3 |
| operacao | 18 |
| estatica-1310 | 8 |
| instalacao-nova | 5 |
| atualizacao-1300-1310 | 11 |
| google-sdk | 20 |
| companheiros-reais | 16 |

## Evidência relevante

- Navegador com minificados e endpoints WordPress reais: cinco eventos do formulário observados no GA4 simulado e gravados em `f3base_eventos`; ID/código corretos; nenhum falso link externo WhatsApp antes da conversa. Visita só com cabeçalho marcada corretamente. Remoção do cookie preserva sessão e marca da saída; consulta SQL confirma somente `teste` nas duas sessões verificadas.
- Clarity: primeira tentativa retorna timeout; o mesmo recorte é repetido e os oito terminam respondidos no mesmo dia, em nove chamadas contabilizadas. Passagem curta não inicia HTTP. Limite total, reserva compartilhada, 429 e espera preservados.
- Pipedrive: fluxo completo simulado cria organização/pessoa/lead; pessoa já existente fornece sua organização. `organization_id` enviado e relido em ambos. Projeção de campanha/parceiro/canal/anúncio cobre valores vazios e leads nativos.
- Captação: formulário inválido no meio da lista não impede o posterior; problema e alerta têm ID; cobertura completa anterior é preservada. Cron CLI horário não gera alerta no intervalo normal; passagem perdida e erro geram estados distintos.
- Slack: leitura por query, normalização rich_text, thread paginada, autoria, idempotência, limites, timeout e exclusão da raiz com thread indisponível. Mensagens humanas e de produção preservadas.
- Cron: intervalo, argumentos e grade; divergência SQL/leitura efetiva; SQL real recusado; diagnóstico não persistido; limite de tentativas; leitura sem reparo; nenhuma mutação de hook estranho. Entrada real `wp-cron.php` com falha injetada registra o erro e executa um callback. Dois processos concorrentes executam uma única ocorrência.
- Companheiros reais: duas ordens de carregamento, registro SDK, conexão não padrão, consulta GSC com HTTP simulado, restrições e pausa/retomada independentes. A consulta SDK não fabrica passagem cron nem usuário humano.
- Instalação nova e atualização **1.30.0 → 1.31.0** por `plugins/upload-base64` do MCP 0.21.0. Primeiro GET bem-sucedido, tags e captura disponíveis antes da finalização; opções, listas vazias e procedência preservadas. A composição usa apenas tema sintético local.
- Referências geradas: 54 tabelas, 17 eventos declarados, dez destinos de teste no perfil 3.5, catálogo completo de opções e nomes. Nove pares fonte/minificado com hashes conferidos.

## Limites da validação

Entrega real em Slack/Pipedrive/Meta/Google/Clarity não foi realizada. A prova de contas, permissões e recebimento nas plataformas, bem como os períodos de observação na frota, permanece com a implantação. As falhas de banco são injetadas deliberadamente e geram erros esperados no log do laboratório; não são apresentadas como falhas espontâneas do pacote.

A execução não amplia o escopo para tema ou implantador, nem altera os plugins MCP e MCP Google. Veja `IMPACTO-1.31.0.md` para o encaminhamento. Runtimes, banco, cookies, tokens de laboratório, logs intermediários e screenshots não integram os arquivos distribuídos.
