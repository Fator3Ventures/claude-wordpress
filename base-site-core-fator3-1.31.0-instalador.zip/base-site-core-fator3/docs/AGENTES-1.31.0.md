# Guia de agentes — Core 1.31.0

Leia primeiro a release 1.31.0 e o contrato 6.7.0. MCP 0.21.0 e Google 0.8.4 são a matriz de referência desta entrega. Abilities, opções e tabelas devem ser descobertas pelos contratos instalados, não por contagens fixas ou por guia de versão anterior.

## Visitas e testes

Ative `/f3base-teste/` no navegador antes de cada sessão de testes; o cookie continua válido por um ano. Alternativa para automação: aplicar `X-F3Base-Teste: 1` a todas as requisições do site, incluindo fetch e beacon. Não propague a marca a fornecedores externos. O contexto público sem cache resolve a marca antes de coletar ou carregar os destinos.

Sair por `/f3base-teste/?sair=1` afeta navegações seguintes. Eventos de saída, tempo e vitais da página anterior preservam a sessão e a marca com que ela foi medida. Destinos externos continuam suprimidos por padrão; GA4 só recebe testes quando houver destino de homologação explicitamente configurado.

## Relatórios e formulários

O funil por formulário está em `f3base/relatorios-integrados-ler`, visão formulários. Cruze a sessão e o ID do formulário; detalhe de recusa contém código, nunca o texto preenchido. Não some fechado como abandono definitivo se a mesma instância depois foi aceita. A base detalhada `f3base_eventos` inclui os cinco eventos nativos; `f3base_analise` mantém as observações de jornada.

No contrato de atribuição, conjunto de anúncio se chama `grupo_id`. A plataforma inferida de `ig/paid` é `meta_ads` com `plataforma_fonte=inferida_superficie_paga`. O nome mapeado de campanha conserva `utm_campaign_original` e procedência; não misture contas só porque o nome coincide. IDs da Meta permanecem strings.

## Integrações e operação

Consulta manual de lead nativo não transforma a pessoa em editor ou teste do operador. O nome de formulário vem do catálogo autorizado. Uma lista parcialmente inválida de formulários gera alerta com ID, mas não bloqueia os formulários posteriores.

Clarity informa os oito recortes e os que continuam sem resposta; timeout conta no teto conhecido de dez. As duas consultas de reserva são compartilhadas por retentativas e operações manuais. Não consumir a reserva em testes repetidos se a coleta diária estiver incompleta.

A marca de cron CLI é evidência de passagem observada, não inspeção do crontab. Diagnóstico de agenda atual, histórico e execução são provas diferentes. MCP, Google e Core mantêm guardas próprias; retomada de um não retoma os outros.

No Slack, operar apenas IDs locais registrados pelo Core. Após limpeza, conferir `alvos_restantes`, `respostas_restantes_observadas`, `threads_nao_verificadas` e `cobertura_threads`. Uma leitura incompleta não permite afirmar que a thread ou o canal ficou vazio.

## Referências instaladas

- `docs/AJUDA-OPCOES.md` e `docs/dados/configuracao-schema.json` — efeito, padrão e vazio por campo.
- `docs/DICIONARIO-DADOS.md` e `docs/dados/contrato.json` — as 54 tabelas e suas colunas.
- `dados/contrato-de-nomes.tsv` — opções, eventos e marcas de página usadas pelo pacote.
- `dados/eventos-comportamento.tsv` — eventos, limites e significado.
- `docs/perfis/piso-padrao-3.5.json` — dez destinos de teste.
- `docs/CRON-DIAGNOSTICO-1.31.md` e `docs/IMPACTO-1.31.0.md` — operação e interfaces com companheiros.
