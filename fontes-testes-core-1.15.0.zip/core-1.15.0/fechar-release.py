from pathlib import Path
import json,hashlib,statistics,urllib.parse,zipfile,shutil,re
root=Path(__file__).resolve().parent;ev=root/'suite/versao-1150/evidencias';dest=Path('/workspace/scratch/351cd9518840/deliverables/1.15.0')
def read(n):return json.loads((ev/n).read_text())
sets={}
for name in ['regressoes','capi','bordas','llms','http','redirects-bordas','consentimento','transporte','cache-browser']:
 p=ev/(name+'.json');p=p if p.exists() else ev/('exec-'+name+'.php.json');d=json.loads(p.read_text());checks=d.get('checks',{});fail=d.get('falhas',[]) or [k for k,v in checks.items() if not v];assert not fail,(name,fail);sets[name]={'total':len(checks) or d.get('total'),'falhas':fail}
up=read('upgrade.json');assert all(r['exit']==0 for r in up);sets['instalacao']={'etapas':len(up),'checks':sum(len(r['resultado']['checks']) for r in up)}
conc=json.loads((ev/'exec-concorrencia.py.log').read_text());assert not conc['falhas'];sets['concorrencia']={'total':len(conc['checks'])}
syntax=read('sintaxe.json');assert not syntax['falhas'];checks=read('site-teste-http.json')['checks'];assert all(checks.values());sets['site-teste-http']={'total':len(checks)}
profile=json.loads((ev/'final-contratos.log').read_text());assert profile['profile_errors']==[]
perf=read('performance/resumo.json');assert perf['execucoes']==60;assert all(r['eventos']==r['confirmados'] and r['runtimeErrors']==0 for r in perf['grupos'])
psi=read('psi.json');assert len(psi)==6;psiout=[]
for r in psi:
 q=urllib.parse.parse_qs(urllib.parse.urlparse(r['calculadora']).fragment);row={'rodada':r['rodada'],'modo':r['modo'],'url':r['url'],'versao':q['version'][0],'score':int(re.search(r'link "(\d+) Desempenho',r['snapshot']).group(1))}|{k:float(q[k][0]) for k in ['FCP','LCP','TBT','CLS','SI']};psiout.append(row)
(ev/'psi-resumo.json').write_text(json.dumps(psiout,ensure_ascii=False,indent=2))
zip_path=dest/'base-site-core-fator3-1.15.0.zip';sha=hashlib.sha256(zip_path.read_bytes()).hexdigest();manifest=json.loads((dest/'manifesto-1.15.0.json').read_text())
with zipfile.ZipFile(zip_path) as z:
 assert len(z.namelist())==172 and not z.testzip()
 for x in manifest['arquivos']:
  body=z.read('base-site-core-fator3/'+x['arquivo']);assert hashlib.sha256(body).hexdigest()==x['sha256'];assert body==(root/'fontes/plugin'/x['arquivo']).read_bytes()
old={r['option_name']:r['option_value'] for r in json.loads(Path('/workspace/scratch/351cd9518840/site-teste-1150-antes-privado.json').read_text())['data']['rows']};new={r['option_name']:r['option_value'] for r in read('site-teste-1150-estado.json')['data']['rows']};preserved={k:old[k]==new[k] for k in ['f3base_operaveis','f3base_politica_canal','f3base_seo_entidade']};assert all(preserved.values())
a=next(r['resultado']['evidencias'] for r in up if r['origem']=='1.14.0' and r['passo']=='semear');b=next(r['resultado']['evidencias'] for r in up if r['origem']=='1.14.0' and r['passo']=='atualizar');delta={k:a[k]==b[k] for k in b};assert all(delta.values())
proof=read('site-teste-1150-cache-detalhe.json')['data'];assert proof['evidencia']['status']=='verified' and proof['evidencia']['artefato_cache']['bytes']==0
assert read('site-teste-lead-aviso-depois.json')['data']['rows'][0]['aviso']=='suprimido_teste'
report=f'''# Base Site Core Fator3 1.15.0 — entrega e validação

28/09/2026. Implementação do plano aprovado, revisão 3, com o recorte final do dono: **instalação nova ou atualização exclusiva de 1.14.0 concluída**. Implantador e tema ficam fora do plugin. O instalador entregue é o mesmo aplicado e observado no Site-Teste; a frota não foi atualizada.

## Arquivos e instalação

- Instalador: `base-site-core-fator3-1.15.0.zip`, {zip_path.stat().st_size:,} bytes, 172 arquivos.
- SHA-256 do instalador: `{sha}`.
- `fontes-testes-core-1.15.0.zip`: código editável, documentação, build determinístico, plano e harnesses/evidências, incluindo os 60 conjuntos Lighthouse e as seis observações PSI. A referência 1.14.0 incluída serve exclusivamente ao ensaio de atualização/reversão.
- `manifesto-1.15.0.json`: tamanho e SHA-256 de cada arquivo instalado.
- `SHA256SUMS-1.15.0.txt`: hashes dos artefatos finais.

Faça backup dirigido de arquivos e banco, confirme a base 1.14.0 concluída e envie o ZIP pelo instalador WordPress, substituindo a versão existente. Instalação nova usa defaults do catálogo, administração como destinatário inicial e pasta privada provisionada. Na atualização, os valores gravados, inclusive falso/zero/lista vazia, permanecem. Não fabricar marcador de versão nem editar SQL para contornar recusa.

Após atualizar, confira `f3base/saude-ler`, documentação e `f3base/config-core-contrato-v1` (conteúdo 3.0.0). Aplique configurações somente por revisão/simulação. O ZIP contém documentação em `docs/`; `f3base/documentacao-ler` lista os caminhos canônicos. Exemplo: `{{"arquivo":"docs/AGENTES-1.15.md","linha":1,"limite":120}}`.

## O que foi implementado

| Aceite | Resultado do código |
|---|---|
| R30 | Query original antes da remoção pelo cache; veto por par; destino prevalece; parâmetros repetidos/escapados; query inválida descartada sem perder redirect válido; recuperação limitada à atribuição nos fluxos nativos; no-store nos 3xx com query. |
| R54 | Provas por execução/configuração/contexto e variante, CAS sobre estado recente, cursor retomável, expiração individual e persistência explícita. `verified`/cobertura integral exigem todas as provas aprovadas. Estado sem escopo/contrato fica pendente. |
| A32 | Normalização comum de clique/formulário; consentimento confirmado; fbc/fbp válidos; envelope CAPI a partir do lead persistido; snapshot, teste, URL/horário/correlação preservados; revalidação no despacho; nenhuma recomposição histórica. |
| C53 | Mescla de objetos por campos tocados e dependências; listas substituídas quando enviadas; preservação do bruto independente; serviços/ofertas fechados na escrita; erros por caminho e migração conservadora. |
| C57 | Simulação distingue `alteraria` de gravação, informa remoções e não executa efeitos. |
| C56 | Vocabulário comum reconhece origem `ability`; classificação de leitura não inventa autoria nem regrava histórico. |
| C42 | Navegação identifica referência e uso observado no cabeçalho; ausência de evidência permanece indeterminada. |
| C46 | Piso integral `piso-padrao-3.1` por ID/revisão ou objeto, condições tipadas, presença explícita, exceções com vínculo/expiração e avaliação somente leitura. |
| C58/D09-T | Resposta compacta, evidência por SHA e detalhe sem sonda; conjuntos de tokens desduplicados em saúde/contrato/verificação/ajuda. |
| S41/S55 | Múltiplas ofertas por serviço com ID estável; preço canônico; fixo/recorrente/mínimo/grátis/sob consulta; prova do conteúdo antes da emissão; conflito de emissor e invalidação; quadro agrupado no admin e documentação. |
| D09-P | Recursos Person/sameAs vinculados aos nós e consulta desduplicada; erro/desafio externo não vira confirmação de identidade. |
| M38 | Prazo absoluto inicial de 5000 ms após load, fila imediata, saídas antecipadas, confirmação por evento/sequência e recuperação de 503 durante lote em voo. |
| M37 | TTL configurado distinto da idade efetiva, dependência de cron e vínculo de mtime com HIT exato; renovação antes de POST. |
| F25 | Resposta real sem JS com 303; confirmação noindex/nofollow em meta e cabeçalho, sem diretivas conflitantes e sem cache. |
| U45 | Paleta/fonte do tema com pares acessíveis de reserva; contraste computado, rodapé/hover/foco/zoom e escopo restrito ao componente. |
| D48 | Cadência documentada como último demonstrativo local; não envia mensagens, não corrige configurações e não acrescenta histórico. |

## Cinco declarações de mudança

1. **Cache:** delta de requisitos/exclusões/rastreamento **vazio** para esta release, comparado sob a mesma configuração nos binários reais 1.14.0/1.15.0. TTL/provedor não são reconfigurados. As invalidações já necessárias para mudança de regras/conteúdo permanecem. No Site-Teste, requisitos antes/depois também coincidiram e a sonda posterior comprovou HIT e corpo vazio do artefato PHP.
2. **Bloco managed do servidor:** conteúdo gerado igual para configurações iguais. Hash completo do bloco habilitado de referência: `3063d224ddf335ed29980504818f2c149930f1c2baa3342f9b33fd6b7ea0b94c`. Com a fixture LLMS explicitamente desligada, ambos geraram bloco vazio (`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`). Nenhuma aplicação de regras no Site-Teste nesta rodada; revisão observada permanece `8c496185f7f2b2f4042ab3d845f892b728e22df05f6f8adc9fc7a454fa4de1ba` e preferência aplicada.
3. **Options/defaults:** nova lista `f3base_seo_entidade.servicos[].ofertas`, padrão vazio, com campos/condições em OFERTAS.md e schema instalado. Novos estados internos `f3base_release_1150`, trava 1150, `f3base_ofertas_evidencia_v2` e `f3base_redirects_evidencia_v2`; não são preferências de usuário. Removido uso da trava 1140 e encadeamento de versões anteriores; marcador concluído 1140 é somente a base admitida. Sem novo ajuste público para o prazo M38. Demais defaults 1.14.0 e valores explícitos preservados; dados antigos não são apagados.
4. **Migração:** snapshot privado JSON 0600, hash conferido, checkpoint e comparação condicional antes da troca da option. Fixture de atualização: duas ofertas antigas encontradas; uma convertida; uma ambígua preservada como pendência; `publico:false` e lista explícita vazia preservados. Interrupção após escrita retomada sem reconverter. Site-Teste: zero encontradas/convertidas/pendentes, configuração SEO sem alteração. Não extrapolar essa contagem para a frota. O backup real citado de ctooffice não foi fornecido.
5. **Contrato:** conteúdo **2.0.0 → 3.0.0**, nome da ability mantido. Escrita fecha `servicos[]` e ofertas, retira `oferta` antiga da entrada e exige enviar lista válida ao substituí-la. Leitura preserva dados extras existentes e os diagnostica. Mescla, simulação, erros/herança, perfil por ID, exceções, compacto/ID de prova e projeção `contrato_evidencias:2` possuem schemas/exemplos atualizados. Consumidores devem consultar o contrato instalado antes de escrever.

## Ensaios e limites da bancada

Conferências finais: {json.dumps(sets,ensure_ascii=False)}. Sintaxe: 112 PHP e 21 JS; sete assets recompostos com Terser fixado. A inspeção do ZIP comparou todos os bytes ao código final e ao manifesto. Instalação/repetição/rollback usaram binários reais, preservando leads capturados após a atualização. A versão 1.14.0 reproduziu perda de query inválida, perda de fbc no formulário e marca de teste ausente na fila comercial; a nova passou esses cenários.

O teste inicial de 410 tinha `para:""`, entrada recusada; corrigido para omitir destino e comprovado 410/`410 Gone` no reteste isolado. O teste de cache corrigiu expectativa de sucesso para 201 nos endpoints de criação. Esses ajustes são de fixture, não mudanças para mascarar falhas. Logs iniciais e retestes ficam nas fontes.

O cache envelhecido foi realmente servido pelo ramo PHP com 3900 s e token vencido, com corpo HTTP igual ao arquivo. O navegador reproduziu esses bytes e usou endpoints reais: token renovado antes dos POSTs de clique, formulário e análise, sem 403. Não se afirma HIT direto do navegador nessa prova combinada. `pageshow.persisted` foi um evento controlado; não equivale a comprovar elegibilidade real para bfcache em todos os navegadores.

## Matriz M38 e decisão

Lighthouse 13.5.0, Chrome 151.0.7922.34, WordPress 7.1.2, WP Super Cache 3.1.3. Sessenta medições com ordem rotacionada e cache de servidor aquecido. Gtag oficial foi servido localmente e os coletores ficaram locais; não mede a latência real do Google. O processo retomou após a medição 44. O aquecimento Playwright usa contexto separado, portanto não se afirma cache uniforme de navegador. Desktop: CPU 1×/10 Mbps/RTT 40 ms; mobile: CPU 4×/1,6 Mbps/RTT 150 ms, simulação Lighthouse.

Cada célula tem cinco repetições. LCP/TBT em ms, valores medianos [Q1–Q3]; requisição de análise em ms após início da navegação.

| Política | Google | Formato | Nota mediana | LCP | TBT | Primeiro envio |
|---|---|---|---:|---:|---:|---:|
'''
for r in perf['grupos']:
 def stat(k):return f"{r[k]['mediana']:.0f} [{r[k]['q1']:.0f}–{r[k]['q3']:.0f}]"
 report+=f"| {r['arm']} | {r['google']} | {r['formFactor']} | {r['score']['mediana']*100:.0f} | {stat('lcp')} | {stat('tbt')} | {r['firstAnalysisMs']['mediana']:.0f} |\n"
report+='''
Escolha: 5 s, com prazo absoluto e descarga antecipada. +10 s não demonstrou vantagem consistente entre modos e aumenta a latência. A baseline teve métricas melhores em algumas células; **não há demonstração de ganho causal de nota**. A versão adia rede inicial com prazo limitado e corrige postergação indefinida/recuperação, mantendo todos os eventos enviados confirmados no ensaio. A variabilidade e os limites impedem atribuir diferenças isoladas ao POST. O cenário contínuo e as saídas curtas foram exercitados no navegador; encerramento abrupto continua podendo perder itens sem confirmação.

## Site-Teste e PageSpeed externo

Aplicado somente em `fator3-teste-mcp-1.dreamhosters.com`. Antes: 167 arquivos conferidos contra o ZIP oficial 1.14.0, todos iguais. Depois: versão 1.15.0, instalação concluída com origem 1.14.0, arquivo principal/manifesto conferidos, SEO e política preservados byte a byte. Documentação canônica lida via MCP com SHA; acesso HTTP anônimo ao documento retornou 404 sem seu conteúdo.

Prova pública: `verified`, HIT real wp-cache; arquivo `.php` específico retornou HTTP 200, **zero bytes**. Sem cabeçalhos faltantes. Consulta compacta preserva revisão/escopos e recupera prova exata por ID sem novo HTTP. Resposta de consulta 1.14.0: 14.787 caracteres JSON; compacto 1.15.0 com prova: 935 (redução aproximada 93,7%). Saúde: 59.282 → 57.166 caracteres; a comparação é entre observações sucessivas e inclui mudanças normais de estado, não é um benchmark de payload idêntico.

Piso instalado: 76 condições conformes, zero divergências e uma indeterminada — navegação 23 publicada, sem prova de uso no cabeçalho. O diagnóstico não altera tema/navegação para fabricar conformidade. A configuração não foi regravada pelo avaliador.

Submissão sem JS: 303 → confirmação 200, meta/cabeçalho noindex/nofollow e no-store. Registro confirmado como método/formulário `formulario`/`contato`, classe `teste`, captura `aceito`, aviso `suprimido_teste`. CAPI permaneceu sem token/pixel e com apenas uma linha cancelada; sem fila pendente e sem envio comercial. Nenhum e-mail foi enviado pela homologação.

Foram concluídas **três análises mobile e três desktop em pagespeed.web.dev**, todas com nota de desempenho 100. Serviço declarou Lighthouse 13.5.0 e HeadlessChromium 153.0.8010.36: Lighthouse coincide com a bancada; navegador difere. Valores abaixo vêm dos links de calculadora do relatório, sem arredondamento da apresentação visual.

| Rodada | Formato | Nota | LCP (ms) | TBT (ms) | CLS | Relatório |
|---|---|---:|---:|---:|---:|---|
'''
for r in psiout:report+=f"| {r['rodada']} | {r['modo']} | {r['score']} | {r['LCP']:.0f} | {r['TBT']:.0f} | {r['CLS']} | [PSI]({r['url']}) |\n"
for mode in ['mobile','desktop']:
 rows=[r for r in psiout if r['modo']==mode];vals=[r['LCP'] for r in rows];report+=f"\n{mode}: LCP mediano {statistics.median(vals):.0f} ms; mínimo–máximo {min(vals):.0f}–{max(vals):.0f} ms. Nota mediana 100, amplitude 0; CLS 0."
report+='''

Isso confirma o estado atual do Site-Teste; não demonstra melhoria sobre uma medição PSI anterior nem garante a nota de outros sites. Sem dados CrUX disponíveis nessa consulta. Acessibilidade 96 observada no site, com apontamento de listas; nenhuma correção de tema foi incluída.

## Reversão e pendências externas

Retornar ao binário 1.14.0 foi ensaiado na base originalmente concluída em 1.14.0, inclusive leitura/captura após rollback. O binário antigo preserva mas não emite as novas ofertas e volta a ter os defeitos corrigidos de query/CAPI. Não é reversão funcional equivalente. Suspenda despacho externo se habilitado antes de reverter, preserve fila e capturas, use snapshot dirigido para a configuração se necessário; não restaure banco inteiro sobre novos contatos. Evidências v2 ficam separadas das antigas e não autorizam reutilização de `verified` obsoleto.

Aguardam operação própria: piloto do dono em korvena.net.br; acompanhamento de sete dias; listas reais/queries específicas da frota; backup de ofertas de ctooffice e decisão sobre `publico`; remoções de compensações de tema em Twinia/Conselar pelos respectivos projetos. Prova de preço no HTML não calcula CSS arbitrário externo. Test Events real é obrigatório se a CAPI for ativada; simulação não substitui recepção na Meta. Não foram alterados implantador, tema, CRM/Pipedrive, webhook ou documentos externos da frota. A causa histórica dos cinco 503 não foi demonstrada; testes induzidos comprovam o tratamento atual.

O pacote está entregue para o piloto do dono, com limites de aceite explicitados. Não houve instalação em korvena.net.br nem atualização geral da frota.
'''
(root/'RELATORIO-1.15.0.md').write_text(report);shutil.copy2(root/'RELATORIO-1.15.0.md',dest/'RELATORIO-1.15.0.md');shutil.copy2(root/'PLANO-APROVADO.md',dest/'PLANO-APROVADO-1.15.0.md');shutil.copy2(ev/'psi-mobile-3.jpg',dest/'PSI-Site-Teste-1.15.0.jpg')
(ev/'fechamento.json').write_text(json.dumps({'instalador_sha256':sha,'conjuntos':sets,'sintaxe':syntax,'opcoes_site_teste_preservadas':preserved,'requisitos_bloco_iguais':delta,'arquivos_instalador':172,'matriz_lighthouse':60,'psi':6,'fixtures_corrigidas':['410 sem destino em branco','HTTP 201 válido na criação','replay do HTML de cache envelhecido']},ensure_ascii=False,indent=2))
with zipfile.ZipFile(dest/'fontes-testes-core-1.15.0.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or '.git' in rel.parts or 'versao-1140' in rel.parts or '__pycache__' in rel.parts or p.suffix=='.tmp':continue
  z.write(p,'core-1.15.0/'+str(rel))
 z.write('/workspace/scratch/351cd9518840/deliverables/base-site-core-fator3-1.14.0.zip','core-1.15.0/referencias/base-site-core-fator3-1.14.0.zip')
files=[p for p in sorted(dest.iterdir()) if p.is_file() and p.name!='SHA256SUMS-1.15.0.txt'];(dest/'SHA256SUMS-1.15.0.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files));print(json.dumps({'instalador_sha256':sha,'arquivos':[{'nome':p.name,'bytes':p.stat().st_size} for p in files]},ensure_ascii=False))
