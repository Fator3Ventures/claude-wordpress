# Plano da próxima versão — Base Site Core Fator3 1.15.0

Data: 28/09/2026. Revisão 3 — escopo de implementação ajustado pelo dono: instalação nova ou atualização exclusiva da 1.14.0; implantador/tema fora da responsabilidade do Core.

## 1. Decisão de escopo

Incorporar as **17 pendências de ação do Core** descritas no anexo, com os ajustes técnicos abaixo. Acrescentar uma correção diretamente relacionada ao item 32: a passagem de atribuição e da marca de teste do formulário para a CAPI. Manter três itens em acompanhamento de aceite, dez itens encerrados e CRM/Pipedrive fora da versão.

**Versão proposta: 1.15.0.** Além de correções, haverá evolução do contrato de ofertas, consulta de perfis por identificador e respostas compactas. A numeração minor explicita essa evolução. A entrega será um único pacote completo, acompanhado de fontes, documentação instalada, relatório de validação, manifesto e checksums.

Os únicos caminhos suportados são instalação nova e atualização 1.14.0 → 1.15.0. Não há compatibilidade nem migrações encadeadas de versões anteriores. Dados antigos ainda presentes na 1.14.0 recebem o saneamento descrito neste plano. Implantador e tema são pacotes externos, sem implementação ou gate de entrega neste plugin.

### Base examinada e limites

- Anexo **Pendências do site-core após a 1.14.0.md**, de 28/09/2026, e relatório **analise-plano-1.15.md**, lidos integralmente. O Anexo A deste relatório fornece o piso do Padrão §3.1, revisão 48, e a regra de presença explícita do §2.2.
- Instalador `base-site-core-fator3-1.14.0.zip`, SHA-256 conferido: `c9338c2fe8b55fe80ddfcafbd149db43fca99cbe68085b85b317bc4ee918f479`.
- Fontes, `PLANO-APROVADO.md`, `RELATORIO-1.14.0.md`, contratos instalados e evidência `suite/versao-1140/evidencias/transporte.json`.
- Referências oficiais de WordPress, WP Super Cache, Schema.org, MDN, W3C e Lighthouse, listadas na seção 11.

A inspeção desta rodada foi estática. As leituras nos 14 sites e seus horários são evidência fornecida pelo revisor; não foram repetidas aqui. O código público consultado do WP Super Cache confirma o mecanismo de remoção da query, mas a cópia exata da versão 3.1.3 instalada não foi obtida nesta rodada. Reproduzir com esse binário continua sendo um aceite obrigatório.

O relatório informa **Pedidos ao pacote core**, revisão 41, e **Padrão único da frota**, revisão 48. Foram usados o trecho do piso fornecido no Anexo A e as regras reproduzidas no relatório; não se afirma leitura dos documentos integrais. A falta de fonte para o piso está resolvida. O backup real de ofertas de ctooffice citado pelo revisor não foi fornecido. As oito especificações do implantador/tema-modelo pertencem a outros pacotes e não são dependência desta entrega.

### Correções na interpretação do anexo

1. **Há defeitos e ampliações de escopo.** O plano anterior especificava uma oferta por serviço e permitia um piso explicitamente parcial. Múltiplos planos e o piso integral são evoluções pertinentes; não representam, por si sós, descumprimento dessas duas especificações anteriores. Outros aceites, como descarte de query por par, permaneceram incompletos de fato.
2. **Aparecer na janela do PSI não demonstra prejuízo na nota.** É preciso medir o efeito em rede, CPU e métricas, além da integridade da coleta. O ensaio local entregue não mediu PageSpeed e declara essa limitação.
3. **No item 25, a divergência de robots é pertinente; a saída exata precisa ser medida.** O código público do WordPress acrescenta `follow` sem remover `nofollow`. A combinação pode conter ambas as diretivas, em vez de apenas `noindex, follow` como prevê o anexo. O aceite será o HTML efetivamente servido.
4. **Um perfil HTTP 200 não comprova a identidade de uma pessoa.** A verificação de `sameAs` comprova presença no grafo e disponibilidade HTTP, mantendo a origem configurada e os limites da observação.

## 2. Rastreabilidade das 17 pendências

Prioridades organizam a execução interna, sem dividir a entrega: P1 = integridade de dados, conversões e escrita; P2 = contratos, medição e diagnóstico; P3 = apresentação e documentação.

| Item | Parecer | Entrega prevista | Prioridade / aceite |
|---|---|---|---|
| 30 — redirects | Incluir integralmente | Query original, opção por par, descarte seguro de query inválida e sondas de rastreamento puro | P1 / R30 |
| 32 — atribuição | Incluir e ampliar pelo achado de código | Política comum de consentimento, `fbc`/`fbp` e passagem correta para CAPI, incluindo marca de teste | P1 / A32 |
| 53 — mescla e oferta antiga | Incluir com ajuste | Corrigir bloqueio de alterações independentes, validar dependências, diagnosticar caminhos inválidos e unificar chaves extras | P1 / C53 |
| 56 — procedência `ability` | Incluir | Vocabulário compartilhado e reclassificação dos registros existentes sem inventar autoria | P1 / C56 |
| 42 — navegação | Incluir | Diagnóstico do valor gravado e do vínculo observável com o cabeçalho | P2 / C42 |
| 46 — herança e piso | Incluir integralmente com o Anexo A recebido | Piso `piso-padrao-3.1` completo, presença explícita, cinco tipos de regra e consulta por ID | P2 / C46 |
| 57 — simulação | Incluir | Mensagem e estados próprios de simulação | P3 / C57 |
| 58 — resposta compacta | Incluir | Projeção compacta, ID de evidência e consulta detalhada sob demanda | P2 / C58 |
| 9 — tokens e `sameAs` | Incluir as partes abertas | Desduplicação das evidências e cobertura de Person | P2 / D09 |
| 54 — verificação paginada | Incluir | Evidências acumuladas, persistidas e associadas ao mesmo contexto válido | P1 / R54 |
| 41 — múltiplas ofertas | Incluir como evolução | Vários planos/períodos, identidade estável e prova no HTML público | P2 / S41 |
| 55 — preço brasileiro | Incluir com semântica explícita | Decimal canônico, milhar/vírgula, mínimo, gratuito e sob consulta | P2 / S55 |
| 38 — transporte de análise | Incluir com decisão baseada em medida | Agendamento sem postergação indefinida; comparar políticas preservando cobertura | P2 / M38 |
| 37 — TTL | Incluir | Diagnóstico do TTL conhecido e renovação testada em HTML envelhecido | P2 / M37 |
| 25 — confirmação sem JS | Incluir a parte aberta | Meta e cabeçalho coerentes, sem diretivas conflitantes | P3 / F25 |
| 45 — consentimento | Incluir com limite de garantia definido | Integração com paleta do tema e pares acessíveis de reserva | P2 / U45 |
| 48 — cadência | Incluir documentação | Mesmo contrato em saúde, ajuda e documentos instalados | P3 / D48 |

## 3. Dados, redirects e conversões

### 3.1 R30 — preservar atribuição no redirecionamento

**Evidência:** `F3Base_Modulo_Redirects::casar_declarado()` não devolve `preservar_query`; `executar()` sempre chama `preservar_query()` e abandona o redirect se ela retorna `null`. A sonda inclui `f3base_probe`, que impede reproduzir rastreamento puro. O relatório descreve a leitura da versão 3.1.3: o WP Super Cache remove rastreamento de `$_GET` e de `REQUEST_URI`, preservando `QUERY_STRING`. O mecanismo também aparece no código público [S1]. A perda em redirects nativos foi inferida por leitura; o aceite deve medi-la.

Implementação:

1. Centralizar a recuperação da query: `QUERY_STRING` bruto primeiro, query de `REQUEST_URI` como reserva. Criar fixture com `$_GET` e `REQUEST_URI` já limpos e `QUERY_STRING` íntegro, além do teste com o binário 3.1.3. Evitar `$_GET`/`parse_str` como fonte canônica: podem perder parâmetros repetidos, nomes e escaping.
2. Separar caminho de casamento e query de montagem. Não reconstruir host/destino a partir de cabeçalhos não confiáveis. Se todas as fontes foram removidas antes do PHP, declarar a limitação; não inventar atribuição. Cobrir instalação em subdiretório.
3. Propagar `preservar_query` por toda a execução do par. Ausência mantém `true`; `false` descarta a query de origem em todos os pontos de montagem. Query e fragmento declarados no destino permanecem. Destino declarado prevalece por nome; preservar ordem, repetições, valores vazios e codificação dos pares admitidos, com fragmento no fim.
4. Estender a recuperação aos caminhos `_f3base_old_slug`/`_f3base_old_path` do Core e aos redirects nativos canônico e de slug antigo. Nos nativos, restaurar **somente parâmetros de atribuição do registro compartilhado** — UTMs, IDs de clique e chaves de anúncio já documentadas pelo Core — ausentes no destino. Usar os filtros específicos `redirect_canonical` e `old_slug_redirect_url` e um helper comum [S9–S10]. Não reinserir parâmetros funcionais, preview, autenticação ou outros que o WordPress tenha removido intencionalmente. Não sobrescrever o destino nem produzir redirects em situações em que o WordPress os recusou.
5. Essa ampliação vale para GET/HEAD público, destino HTTP(S) local validado e status 301/302/307/308; excluir admin, REST e login. Comparar host normalizado, esquema e porta, permitindo a canonicalização legítima de HTTP para HTTPS local, sem restaurar atribuição em destino externo. Um filtro global `wp_redirect`, se necessário, precisa identificar esses fluxos e respeitar o veto explícito do par; não aplicar reposição genérica em todo redirect. Nos pares declarados, preservar o contrato existente e a autorização de hosts externos, sem ampliar sua lista.
6. Manter validação e limite defensivo de 8192 bytes. Query inválida/acima do limite será descartada, mantendo o redirect para destino válido; destino inválido continua recusado. Registrar motivo e contagem, sem arquivar a query bruta. Não mudar 301 para 404 por falha somente na query. Erros 400/414 anteriores ao PHP pertencem ao servidor/proxy.
7. Emitir `Cache-Control: no-store, private` no 3xx que transporte query da origem, como proteção de cache intermediário. **R30 não cria exclusões nem requisitos novos do WP Super Cache e não exige uma purga adicional por visitante/query.** O cache 3.1.3 observado já recusa redirects. Conservar a invalidação existente ao alterar regras/conteúdo: um HTML 200 antigo ainda pode ocultar uma regra nova. Registrar o delta de requisitos, mesmo vazio, no relatório de release.
8. Sondas separadas para somente `utm_source`, somente `gclid`, demais IDs, query mista, `preservar_query=false` e destino com query/fragmento. Usar `X-F3Base-Teste: 1` nas sondas locais, sem cookie de bypass nem parâmetro auxiliar fora do conjunto de rastreamento. A marca exclui testes; não pode alterar o comportamento de cache sob avaliação.

**Aceite R30:** WP Super Cache 3.1.3 no perfil real, cache frio/aquecido e dois visitantes com IDs distintos; nenhum recebe ID do outro. Cobrir `gclid`, `fbclid`, `gbraid`, `wbraid`, `li_fat_id`, UTMs, nomes repetidos, espaços codificados e query malformada que alcance o PHP. Conferir `Location`, status, destino final, 410, veto por par e ausência de laço. Repetir somente `gclid` e somente `utm_source` em endereço sem barra final, slug antigo nativo e caminhos antigos do Core. Incluir query com parâmetros que o WordPress deve retirar e comprovar que a correção não os recoloca. Reproduzir `/pagina-inicial/quem-somos` de fator3capital. Evidência HTTP por variante; helper isolado não encerra o aceite.

### 3.2 R54 — consolidação da verificação paginada

**Evidência:** há acumulação de `provas`, porém ela depende de `evidencia().atual`. O contexto usa o estado inteiro do cache e a revisão LLMS; mudanças auxiliares podem invalidar lotes. A gravação usa um snapshot anterior e seu resultado não é apresentado ao consumidor. O anexo não traz a reprodução detalhada citada no item original. Esses são riscos identificados no código; a causa exata do relato permanece por reproduzir.

Implementar execução identificada por `execucao_id`, revisão da configuração, conjunto ordenado de origens e versão do contrato de verificação. O contexto deve refletir mudanças que invalidam a prova: regras, hosts permitidos, URL base, permalinks e geração relevante de cache. Horários, contadores e consultas de diagnóstico não devem reiniciar o trabalho.

- Acumular resultados por origem **e variante de query**, incluindo regras removidas. A visão consolidada é calculada sobre o escopo inteiro.
- Mesclar sobre o estado mais recente com controle de concorrência; não substituir provas de outro lote por um snapshot antigo.
- Avançar o cursor pelo trabalho realmente executado, respeitando orçamento e retomada. Uma chamada repetida deve ser idempotente.
- Mudança relevante invalida com motivo explícito; não misturar provas de revisões diferentes. Expiração é avaliada por evidência, sem renovar silenciosamente provas antigas a cada lote novo.
- `verified` exige cobertura integral válida; subconjunto completo não significa lista inteira verificada. Expor total, concluídas, pendentes, falhas e próximo cursor.
- Informar se a evidência foi persistida. `ok` não substitui `verification.status` nem confirmação de persistência.

**Aceite R54:** reproduzir listas de 13 pares de korvena.com.br e 30 de ctooffice, conforme os casos fornecidos, com três lotes ou mais, interrupção/retomada, consulta entre lotes, repetição, concorrência, falha de escrita, mudança real de configuração e expiração. A consulta final recupera as provas persistidas; retorna `verified` e `cobertura_lista=true` somente se todas as provas exigidas passarem e permanecerem válidas. Timeout ou falha pública não pode virar sucesso para atingir esse resultado. Um teste deve falhar na versão anterior antes de comprovar a correção.

### 3.3 A32 — atribuição, consentimento e CAPI no mesmo contrato

**Evidência:** clique e formulário já usam `F3Base_Atribuicao`; o formulário remove snapshots de toque quando não autorizado, mas o clique não aplica a mesma regra. O normalizador descarta `fbc`/`fbp`; o clique os recoloca e o formulário não. Formulários já chamam `F3Base_Modulo_Meta_Capi::agendar()`.

**Achado adicional desta análise:** o formulário monta `$dados_capi` com `+ $atrib`, colocando a atribuição na raiz; `montar_payload()` procura `$dados['atribuicao']`. Além disso, a chamada omite `contexto_teste`, enquanto `agendar()` usa esse campo para aplicar a política de supressão/marcação. A inspeção demonstra a falha de passagem. O relatório informa CAPI inativa na frota em 28/09, com leitura explícita de korvena.com.br sem fila pendente. Isso reduz a exposição atual e torna a correção preventiva antes da ativação; **não comprova ausência de impacto histórico**. Não houve medição histórica nesta revisão.

Implementação:

1. Criar uma única política de normalização no servidor, consumida por clique, formulário e saída CAPI. Aplicá-la antes da gravação/expansão em campos de relatório. Normalização sintática e permissão de uso são passos distintos.
2. Medição permitida admite sessão, navegação e snapshots primeiro/último toque conforme o modelo. Sem permissão, remover snapshots, seus horários e identificadores persistentes; usar somente a origem da navegação corrente e `modelo=sessao`, conforme a política já adotada pelo pacote. Não apenas renomear como sessão uma atribuição antiga recebida na raiz.
3. Um `true` enviado pelo cliente não amplia a permissão medida no servidor. Recusa/revogação prevalece. Registrar o motivo de redução da atribuição sem impedir o registro funcional do contato.
4. Admitir `fbc` e `fbp` no contrato comum, validar formato/tamanho e mantê-los apenas quando a política de publicidade permitir. Reaproveitar valores legítimos disponíveis; não fabricar `fbp` nem associar cookies de outro navegador. Unificar também os campos adicionais já aceitos, documentando quais são consumidos por cada destino.
5. Criar **um montador do envelope CAPI**, compartilhado por clique e formulário, a partir do lead persistido obtido por `F3Base_Leads_Repositorio::obter(record_id)`. Mapear explicitamente colunas e `dados` já decodificados para `atribuicao` aninhada, `contexto_teste`, correlação/event ID, contato e contexto capturado. Preservar o identificador usado na deduplicação do navegador, horário real do evento e URL de origem; cron/reenvio não substituem esses dados pelo contexto da execução. Sem registro confirmado, não agendar conversão. Marca de teste ou permissão ausente/inconsistente não pode ser interpretada como liberação comercial. Testes suprimidos não entram na fila comercial; testes autorizados usam o destino de testes existente.
6. Preservar marca e snapshot de consentimento na fila, no reenvio e na recuperação; revalidar a autorização vigente antes do despacho. Permissão de teste não autoriza envio sem consentimento. Não reenviar contatos históricos para preencher campos não capturados.
7. Atualizar documentação de captura, retenção, exportação e origem dos identificadores. Os campos de integração não precisam virar colunas visíveis na lista operacional de leads.

**Aceite A32:** visita com UTM → navegação interna → clique e formulário, com análise local ligada/desligada, primeiro/último toque, medição/publicidade permitidas ou recusadas, revogação e payload adverso. Verificar valores reais no banco e payload persistido da CAPI. Testar cookie, cabeçalho e contexto MCP com supressão padrão; teste marcado só é enviado ao destino de testes configurado. Confirmar que repetição não produz outra conversão. Na bancada, configurar um destino simulado e demonstrar dois testes que falham na 1.14.0: `_fbc` válido ausente no payload do formulário e formulário de teste elegível para envio comercial. O relatório pode registrar aceite Meta real como **não aplicável à configuração da frota informada em 28/09**, após reconsulta no pré-voo. Se algum site ativar CAPI, comprovar Test Events e deduplicação antes de liberar produção; o estado atual não dispensa esse aceite futuro.

## 4. Escrita, migração, auditoria e leitura

### 4.1 C53 — alterações parciais sem bloqueio indevido

**Evidência:** a mescla produz um objeto completo e depois valida o objeto inteiro; o campo inválido antigo bloqueia uma alteração independente. Mescla e substituição integral divergem no tratamento de chaves extras em itens de listas. A leitura informa apenas `valor_bruto_valido`, sem caminhos de erro.

**Ajuste ao pedido:** não basta validar somente o delta. Um novo país, por exemplo, pode tornar o CNPJ mantido incompatível. Validar os campos enviados, os campos relacionados por regras de domínio e o resultado dessas relações. Erros preexistentes independentes devem ser relatados, preservados e não impedir a correção de outro campo.

Regras:

- Ler valor bruto e revisão antes de normalizar. Preservar campos não tocados, incluindo dados antigos e chaves extras existentes; não substituí-los por defaults na passagem pela sanitização.
- Listas continuam com substituição integral quando enviadas. Enviar `servicos` significa validar toda a lista enviada. Não introduzir uma mescla por posição ou ID sem contrato explícito.
- Adotar schema fechado de forma consistente para **entradas escritas de `servicos[]` e das novas ofertas**, nos dois modos. Não fechar outras estruturas abertas sem uma mudança de contrato identificada. O contrato atual aceita `servicos.items.additionalProperties=true`: fechá-lo é uma mudança incompatível. Elevar `F3Base_Config_Contrato::VERSAO` de **2.0.0 para 3.0.0**, versionar os demais schemas afetados e atualizar a ajuda. Chave desconhecida enviada, como `servicos[0].publico`, gera erro com caminho e a explicação “a lista é substituída integralmente; omitir esta chave remove o dado”. Não tornar uma chave funcional só porque foi aceita antes. Separar schema de escrita fechada da representação de leitura de dados brutos antigos, que continua capaz de expor chaves extras com diagnóstico.
- Chaves desconhecidas já armazenadas e fora do delta são preservadas e diagnosticadas. A leitura permite exportar/revisar o valor, sem descartá-lo. Troca integral que omite dados deve ter o descarte evidente na simulação.
- Separar validade do dado, efeito em cache e verificação pública. Falha de prova HTTP de uma oferta não bloqueia editar nome, telefone ou outra parte independente da entidade.
- Retornar `erros[]` e `avisos[]` com caminho, código e orientação, incluindo índices das listas. Mascarar valores sensíveis em todas as projeções. Distinguir leitura bem-sucedida de configuração válida.
- Preservar revisão esperada, concorrência, simulação, leitura de confirmação e auditoria. Campos antigos inválidos não devem passar a ser emitidos no HTML só porque outra alteração foi aceita.

**Saída para ctooffice:** antes da publicação na frota, o projeto responsável faz inventário somente de leitura por `config-core-ler` nos 14 hosts confirmados, listando chaves extras e revisão. Preservar os três `servicos[].publico` enquanto o responsável não escolher o saneamento; alterações independentes continuam permitidas. Para remover, exportar snapshot privado nomeado, apresentar na simulação exatamente os caminhos/valores que sairão e efetuar uma escrita dirigida sob revisão esperada. A atualização e a primeira edição não autorizam apagamento automático. Recomenda-se a remoção por não haver consumidor relatado; ampliar o contrato com `Service.audience` é uma demanda separada. Essa decisão operacional não bloqueia desenvolvimento nem instalação, mas antecede a primeira substituição da lista afetada.

**Migração das ofertas:** integrar ao modelo da seção 5. Converter uma oferta válida da 1.14.0 para a lista nova, sem perda de preço, moeda, período e página. `preco_minimo` corresponde a mínimo somente quando essa semântica está inequívoca. `duracao_minima_meses` representa duração mínima contratual; não inferir dela o período de cobrança. Se faltar dado para migrar, manter o bruto em snapshot privado, apontar o caminho e a pendência; não zerar o grupo nem publicar uma oferta inventada.

Migrações devem ser versionadas, idempotentes e retomáveis, com antes/depois e resultado por registro. A opção não fica inteira indisponível por uma oferta que precisa de revisão. Não criar adaptadores permanentes anteriores à base suportada.

O relatório informa zero `servicos[].oferta` ativos em 28/09. Recontar no pré-voo e registrar o total real, inclusive zero; não anunciar migrações de produção inexistentes. O backup `options-f3base_seo_entidade-mcp-20260928-1104.txt` foi citado, mas seu conteúdo não foi fornecido. Solicitá-lo ao projeto de ctooffice e usá-lo como fixture privada real, sem dados sensíveis no pacote distribuído. Fixtures sintéticas cobrem o contrato desde já; não substituem nem comprovam a validação desse backup.

**Aceite C53:** opção com oferta antiga e chave extra; editar campo independente; editar campo relacionado que tornaria o conjunto inválido; lista inteira inválida; substituição integral; conflito; simulação; interrupção e repetição de migração. Provar preservação de dados não tocados e de `false`, `0`, `''` e `[]`.

### 4.2 C56 — procedência coerente

Centralizar o vocabulário de origem usado por escritor e auditoria e incluir `ability`. A classificação deve continuar exigindo vínculo com a revisão para declarar confirmação.

**Regularização proposta:** reconhecer os registros válidos que já contêm `ability`. Isso reclassifica corretamente a evidência existente e dispensa regravar sua autoria/data. Recalcular eventual projeção derivada; não alterar um registro divergente para fazê-lo coincidir com a revisão atual. Registros sem vínculo ou malformados mantêm diagnóstico apropriado.

**Aceite C56:** incluir o caso fornecido de fator3.com.br, `f3base_redirects` com `registro_invalido` e revisão iniciada por `c3ada449`, confirmando o identificador completo no inventário; esperar `revisao_confirmada` apenas com vínculo íntegro, sem regravar pares. Cobrir escrita nova por `redirects-escrever`, registro 1.14.0 com revisão compatível, revisão divergente, origem desconhecida e falha de auditoria. Conferir leitura normal, compacta e painel. Não atribuir usuário humano a uma execução apenas por ter vindo de uma ability.

### 4.3 C42 — diagnóstico de navegação

Na leitura de `f3base_nav_id`, verificar o valor bruto contra o contrato: 0 = navegação administrada pelo tema; ID positivo = `wp_navigation` publicado. Informar ID observado, tipo/estado encontrado e validade. `ok` da consulta não pode ser interpretado como prova de validade da navegação.

Separar `referencia_valida` de `uso_no_cabecalho`. Inspecionar templates, partes e blocos referenciados quando o vínculo é determinável. Menu inline, renderização dinâmica e tema clássico admitem resultado `nao_confirmado`/`nao_aplicavel`. Não regravar ID inválido para 0 na leitura nem declarar erro em um menu dinâmico apenas por não conseguir provar seu uso.

**Aceite C42:** 0, ID inexistente, página/revisão, navegação em rascunho, navegação publicada usada/não usada e cabeçalho dinâmico. Reproduzir os IDs 92 de fator3.com.br, 3 de korvena.com.br e 4 de fator3grupo, relatados sem `wp_navigation`. Ler não altera opção, revisão ou cache. A regularização para 0 segue nas ações dos sites e não depende da release.

### 4.4 C46 — piso completo, herança e perfis por ID

O **Anexo A recebido resolve a falta de fonte do piso**. Implementar integralmente o Padrão §3.1, revisão 48, com a regra do §2.2: configuração do piso escrita, nunca apenas herdada. A seção 12 contém sua matriz de cobertura. `completo=true` significa cobertura integral dessa referência delimitada, não conformidade automática de um site nem cobertura de todo o Padrão.

Padronizar todos os ramos: `heranca_status` e `chaves_herdadas`; lista vazia somente para ausência comprovada de herança, `null` com motivo quando não se consegue ler. Evidência HTTP tem herança `nao_aplicavel`. Não omitir nos resultados inválidos, não suportados ou indeterminados. Diferenciar ausência de `false`, `0`, `''` e `[]` gravados.

Distribuir o perfil local **`piso-padrao-3.1`**, com `revisao_fonte=2026-09-28-core-1.14.0`, fonte Padrão §3.1 rev 48 e revisão de implementação **`2026-09-28-core-1.15.0`**. Substituir o piso parcial como referência ativa; não mudar silenciosamente o conteúdo sob sua revisão antiga. Declarar plugin mínimo, escopo, regras cobertas e exceções. Alterações posteriores de contrato exigem revisão nova do perfil e matriz correspondente.

`config-core-perfil-avaliar` recebe identificador/revisão do perfil distribuído **ou** objeto explícito. Entradas conflitantes, ID desconhecido e revisão incompatível têm erros próprios. Consulta não baixa código, executa PHP nem aplica diferenças. Preservar as comparações já suportadas `configurado` e `verificado`; acrescentar os tipos abaixo ao contrato e ao avaliador, mantendo limites de tamanho/profundidade adequados à matriz completa.

| Regra | Semântica e aceite |
|---|---|
| `igual` | Valor gravado e tipo iguais ao valor da regra; não aceitar default herdado como prova de gravação |
| `presente` | Chave existe no valor bruto, mesmo vazia/falsa; validar o tipo e os requisitos condicionais. Para grupos, verificar as chaves do contrato aplicáveis e os itens existentes, sem criar itens de listas vazias |
| `derivado_do_host` | Derivação determinística a partir da URL canônica confiável, como domínio sem `www` no padrão do log; sem usar Host arbitrário nem testar existência de arquivo como substituto de presença da configuração |
| `contem` | Conjunto contém os elementos exigidos, preservando extras válidos específicos do site |
| `referencia_valida` | Referência atende tipo/estado e vínculo exigidos; uso não demonstrável permanece indeterminado, conforme C42 |

Toda configuração do contrato entra na regra de não herança, **exceto `f3base_consentimento`**; excluir estado de execução e segredos. Para segredos, expor somente existência, tipo e tamanho. Exceções vêm do chamador, vinculadas à referência do estado do site (§20), condição, responsável, motivo, prazo e revisão do perfil. Exceção reconhecida aparece no resultado; não apaga divergência nem aprova uma condição desconhecida.

O piso oficial é uma referência da frota, separada dos defaults de instalação. Atualizar os dois documentos quando surgirem chaves novas; a rodada de implantação grava as chaves necessárias de forma explícita, com simulação e revisão, preservando escolhas existentes e exceções. O plugin não impõe todos os valores do piso ao ler ou atualizar um site.

**Aceite C46:** matriz completa da seção 12 coberta por regras executáveis e exemplos, sem condição silenciosamente ignorada; todos os cinco tipos; ramos conforme/divergente/indeterminado/exceção; opção ausente, falha de leitura, segredo, vazio explícito; avaliação por ID e por objeto equivalente. Emitir `completo=true` somente após fechar essa cobertura. Um site com herança ou falta de prova continua divergente/indeterminado mesmo com perfil completo.

### 4.5 C57 — simulação inequívoca

Separar a mensagem de normalização da mensagem de persistência. Simulação usa “Simulação concluída; nenhuma configuração foi gravada”, mostra antes/depois e avisos e informa `simulado=true`, `persisted=false`, `changed=false`. Se houver diferença proposta, usar um campo próprio, como `alteraria=true`.

**Aceite C57:** reproduzir a simulação de ctooffice cujo `motivo` começa por “Gravado”, além de simular valor já normalizado e valor que seria ajustado; opção, auditoria, cron, arquivos, revisão e cache devem permanecer inalterados. Não reutilizar “Gravado” nem afirmar que a tela representa um valor já persistido.

## 5. Ofertas, preços e dados estruturados

### 5.1 S41/S55 — contrato de várias ofertas

Adotar `servicos[].ofertas[]`, com lista vazia como padrão para serviço sem ofertas. Na atualização, uma oferta antiga segue a migração C53; não preencher `[]` sobre dado antigo pendente nem sobre lista explícita existente. Cada alternativa de contratação contém:

| Campo | Regra proposta |
|---|---|
| `id` | Identificador estável e único no serviço; não derivar apenas da posição na lista |
| `nome` | Nome do plano, como Starter, Operação ou Escala |
| `pagina` | Página pública que apresenta a oferta |
| `descricao` | Texto opcional coerente com a oferta pública; preservar quando disponível na migração |
| `modalidade` | `fixo`, `a_partir_de` ou `sob_consulta` |
| `preco` | Decimal canônico em string, com ponto e sem milhar; obrigatório para fixo/mínimo; ausente em sob consulta |
| `moeda` | Código ISO de três letras para preço numérico |
| `periodo` | `unico`, `dia`, `semana`, `mes` ou `ano`, conforme a cobrança declarada |

A interface agrupa pelo plano, mas cada combinação de plano e período tem identidade própria. **Decisão técnica:** emitir uma `Offer` por alternativa de contratação, com `PriceSpecification`/`UnitPriceSpecification` coerente. Isso evita representar mensalidade e anuidade alternativas como componentes cumulativos do mesmo preço. A quantidade de nós não precisa ser igual à quantidade de planos.

Fixture baseada no anexo, sem transformar esses preços em padrão de instalação:

| Plano | Alternativa | Valor canônico | Representação |
|---|---|---|---|
| Starter | Mensal | `239.00` BRL/mês | Oferta fixa recorrente |
| Starter | Anual | `2390.00` BRL/ano | Oferta fixa recorrente |
| Operação | Mensal | `399.00` BRL/mês | Oferta fixa recorrente |
| Operação | Anual | `3990.00` BRL/ano | Oferta fixa recorrente |
| Escala | Sob consulta | Sem preço numérico | Oferta sem `price`, com nome, URL e descrição pública |

Fixar a representação no contrato e nos testes, sem duplicar preços contraditórios [S2–S3, S11]:

| Modalidade / período | Representação JSON-LD |
|---|---|
| `fixo` / `unico` | `Offer.price` e `Offer.priceCurrency` |
| `fixo` / recorrente | `Offer.priceSpecification` → `UnitPriceSpecification.price`, `priceCurrency` e `referenceQuantity` do tipo `QuantitativeValue`, com `value: 1` e unidade do período |
| `a_partir_de` / `unico` | `PriceSpecification.minPrice` e `priceCurrency`; sem `Offer.price` nem preço exato concorrente |
| `a_partir_de` / recorrente | `UnitPriceSpecification.minPrice`, `priceCurrency` e `referenceQuantity`; sem `price` |
| `sob_consulta` | Nome, URL e descrição quando configurada e confirmada publicamente, sem preço numérico |
| Gratuito explícito | Modalidade `fixo` com preço zero, no campo correspondente ao período; manter a unidade quando recorrente. Mínimo zero continua mínimo e não equivale a oferta gratuita |

Mapeamento fechado de `periodo`: `dia` → `DAY`, `semana` → `WEE`, `mes` → `MON`, `ano` → `ANN`. Preço fixo pode usar a string decimal canônica; `minPrice` deve sair como número JSON, conforme seu tipo Schema.org, mantendo centavos sem arredondamento indevido. Nunca apresentar mínimo como preço exato nem dividir anuidade por 12 para inventar mensalidade.

`billingDuration` descreve a duração pela qual o componente de preço é cobrado; não é a unidade do preço recorrente. **Não mapear automaticamente `duracao_minima_meses` para `billingDuration`:** compromisso mínimo e duração de aplicação do preço não são necessariamente a mesma coisa. Preservar o dado antigo no snapshot e apontar a revisão semântica quando não representável; esta versão não acrescenta um campo de duração por inferência. O grafo atual da Twinia descrito pelo revisor mistura mensalidade/anuidade e usa 12 com unidade ANN. A comparação de migração confere planos, valores, períodos e URLs, sem exigir igualdade literal com esse grafo [S11].

Preço gratuito deve ser configurado explicitamente como zero e confirmado na mesma oferta por “gratuito”, “gratuita”, “grátis” ou valor numérico zero. “Diagnóstico grátis” ou “teste grátis” em outra parte da página não torna gratuito um plano pago. Trial não será convertido em preço permanente.

### 5.2 Conferência do preço público

Separar a validade estrutural da configuração da comprovação do conteúdo servido. A escrita valida o contrato; uma verificação limitada lê o HTML público da página, incluindo tema, blocos e shortcodes. Não fazer um GET recursivo ao site em cada renderização nem em cada consulta de configuração.

- Confirmar nome do plano, valor, moeda, modalidade e período na mesma região de conteúdo. Evitar casar o número de um plano com o período de outro.
- Interpretar `R$ 5.000`, `R$ 5.000,00`, `5.000,50`, espaços inseparáveis e símbolo separado por marcação. Manter decimal canônico na API; não aplicar heurística pt-BR a uma string de entrada já declarada canônica.
- Excluir scripts/JSON-LD e metadados gerados pelo próprio plugin da prova: o grafo não pode comprovar a si mesmo. Conservar URL, região/trecho, horário e resumo/hash do conteúdo relevante.
- Preferir âncora/região identificável do plano. Se a associação não for comprovável, responder inconclusivo, com motivo. Conteúdo que só aparece após JavaScript requer evidência de navegador na homologação; não chamar `post_content` de HTML renderizado.
- Guardar evidência associada à revisão da oferta e ao contexto da página. Mudança de conteúdo/tema invalida a prova pertinente e agenda revisão. Nova oferta ou alteração sem prova não passa a publicar preço; eventual versão anteriormente comprovada tem identidade e validade próprias, sem apresentar candidato como aprovado. A sonda local lê o HTML servido pelo cache ao visitante após `atualizar_cache`, com `X-F3Base-Teste: 1`, sem cookie de bypass nem query artificial que contorne o cache.
- Exibir Configurada / Verificação pendente / Publicada / Divergente e **`ocupado_por_outro_emissor`**, com detalhe por oferta. O último identifica o `@id`, nome e origem conhecida/desconhecida do Service concorrente. Não expandir a tela geral inteira para acomodar a lista.
- O código do Core evita acrescentar Service cujo nome já existe; segundo o relatório, o tema Twinia o emite na prioridade 9 e o Core atua na 999. Conteúdo configurado e nó semelhante no HTML não comprovam emissão pelo Core. Definir IDs estáveis e uma evidência da participação efetiva do emissor, vinculada à revisão/hash esperados; cruzá-la com o grafo servido. **“Publicada” exige a oferta atual emitida pelo Core e observada publicamente.** Prova antiga, cache de outro grafo e identidade de emissor inconclusiva não satisfazem esse estado.
- Não retirar automaticamente a exceção da Twinia. Após estabilidade da 1.15.0 na frota, o projeto do site salva backup nomeado e retira somente a emissão Service do tema, conservando outros nós. A sequência é configurar ofertas → comprovar conflito → retirar exceção → invalidar cache → comprovar preços, períodos, URLs e ausência de duplicação. Guardar caminho de reversão do tema.

**Aceites S41/S55:** reproduzir a home da Twinia em ambiente controlado; cobrir ofertas fixas, mensais/anuais, mínimo, zero e sob consulta; HTML vindo do tema; preços em outra região; preço não visível; nomes repetidos; alteração de página; grafo concorrente. Validar JSON-LD servido e coerência da prova. Dados Schema.org válidos não garantem resultado destacado no Google; não forçar `Product` ou preço fictício para satisfazer um teste de rich results.

### 5.3 D09 — `sameAs` de Person

Ampliar a extração de recursos para Person observado no grafo, incluindo `pessoas[].same_as`. Associar cada URL a todos os nós que a referenciam, com página, `@id`, tipo e origem configurada. A mesma URL é requisitada uma vez e pode ter várias relações de origem.

Manter a política existente de 200 direto para o aceite HTTP; cadeia de redirect é explicitada. Login, CAPTCHA, 403/429, 999 e timeout são inconclusivos quando impedem observação. Preservar limites de requisição, proteção contra destinos internos e distinção entre origem conhecida e não identificada. Não apagar perfis por falha transitória.

**Aceite D09-P:** Person na página em que foi declarado, Organization e Person compartilhando URL, origem Core/Yoast/desconhecida, redirect, erro e desafio. Reproduzir o LinkedIn de Person de ctooffice, relatado com 999/login: resultado inconclusivo com origem configurada, sem apagar o vínculo. Confirmação do dono sobre identidade é evidência independente e não transforma 999 em 200. Conferir recurso e vínculos, não apenas logo. Marcar as sondas ao próprio site com `X-F3Base-Teste: 1`; não encaminhar cabeçalhos internos ou credenciais a LinkedIn/outros hosts externos.

## 6. Medição, cache e respostas para agentes

### 6.1 M38 — política de transporte medida

**Evidência:** `emit()` e `load` agendam em 500 ms; `schedule()` cancela o temporizador anterior. Eventos frequentes podem prorrogar continuamente o primeiro envio. `pagehide` e `visibilitychange` já existem; corrigir agendamento e saída sem anunciar esses ouvintes como novidade.

Separar captura imediata em fila de envio HTTP em lote. Adotar prazo absoluto a partir do início elegível, sem reiniciá-lo por evento. Requisições funcionais de lead/formulário continuam imediatas.

**Experimento obrigatório:** política atual, +5 s e +10 s após `load`, com descarga antecipada ao ocultar/sair. Exercitar cada braço com Google carregado **imediatamente** e **após interação, teto de 5 s**. São os modos informados para fator3.com.br e os demais sites; +5 s pode coincidir com a entrada do `gtag.js`. “Somente ao sair” pode ser uma referência diagnóstica adicional, sem substituir a descarga periódica nem integrar a contagem mínima [S6].

Executar em bancada própria com WordPress/tema e perfil real do WP Super Cache: **3 braços × 2 modos × 2 formatos (mobile/desktop) × 5 execuções = 60 medições principais**, com cache aquecido. Distribuir a ordem dos braços e manter condições comparáveis. Fazer também regressões com cache frio; se os dois estados forem comparados estatisticamente em toda a matriz, o mínimo passa a 120 e deve ser declarado. Não apresentar 60 como cobertura completa de ambos.

Registrar versões, rede/CPU, estado do cache, traces/HAR/JSON, primeira requisição, bytes, tarefas longas, LCP, CLS, TBT, latência e cobertura dos eventos. Usar a versão do Lighthouse declarada pelo PSI na data do ensaio e registrar divergências; **13.5.0 é a referência informada para 23/09, não uma versão presumida como atual**. A hospedagem pode responder 429 a ferramentas headless: manter a matriz em bancada e confirmar a política escolhida no Site-Teste via pagespeed.web.dev, com três execuções mobile e três desktop, apresentando medianas e dispersão. Se houver bloqueio, registrar aceite externo pendente; não contornar controles da hospedagem nem simular um resultado PSI.

**Escolha:** preservar cobertura/deduplicação, reduzir trabalho relevante na renderização inicial e, entre opções equivalentes, preferir menor atraso. Comparar distribuições por modo. Não exigir que a ordenação dos braços seja idêntica: uma diferença pode mostrar interação com o carregador. A política única precisa atender os aceites nos dois modos; se nenhum prazo passar, ajustar a implementação e repetir os casos que falharam. Correlação entre fim do POST e fim da medição, mesmo alta, não comprova causalidade [S7].

Fixar o prazo escolhido em constante antes de gerar o ZIP. Variações do experimento ficam no harness de bancada, sem nova option nem ajuste público por site. Não mudar o modo Google da frota como efeito colateral; essa escolha permanece com o dono. Não condicionar o comportamento ao user agent do Lighthouse nem prometer uma janela universal fora do PSI.

**Aceite M38:** visitas inferiores a um segundo, página longa sem gesto, eventos contínuos, aba oculta antes do load, volta do bfcache, offline/online, consentimento tardio/revogado, token prestes a vencer, lote em voo e últimas métricas Web Vitals. Preservar horário, classe de tráfego, IDs e confirmação por evento. `sendBeacon` enfileirado não confirma gravação; documentar perda possível em encerramento abrupto. A decisão técnica e suas evidências entram no relatório antes do empacotamento final.

### 6.2 M37 — TTL configurado, idade observada e renovação

O relatório descreve o WP Super Cache 3.1.3 da frota com `$super_cache_enabled=false` e `$wpsc_save_headers=1`: o ramo wp-cache entrega o arquivo sem checar sua idade, dependendo da coleta `wp_cache_gc`. Nesse modo, `$cache_max_time=3600` **não garante HTML de no máximo 3600 segundos**. Confirmar com esse binário na bancada; não concluir “compatível” apenas porque cache e token declaram o mesmo TTL.

Expor separadamente:

| Campo / grupo | Significado |
|---|---|
| `ttl_configurado_segundos`, `ttl_token_segundos` | Valores lidos do provedor e de `ttl_token()`; não duplicar 3600 no código |
| Comparação dos valores configurados | Igual/inferior/superior/desconhecida; não equivale a garantia da entrega |
| `teto_de_idade` | `nao_garantido` no modo wp-cache descrito; só afirmar teto quando o mecanismo de entrega efetivamente o aplica |
| `depende_de`, próxima coleta, coleta atrasada | `wp_cache_gc`, `wp_next_scheduled`, instante de observação e estado ausente/atrasado; cron agendado não prova execução pontual |
| Idade observada | Epoch de `filemtime` do arquivo exato associado ao HIT demonstrado, instante da sonda e idade calculada; não inferir da data escrita no HTML |
| Provedor / modo / limites | Origem de cada informação; cache desligado não aplicável; proxy/CDN não observado desconhecido |

Só atribuir a idade do arquivo ao HTML público quando houver vínculo comprovado entre esse artefato e a resposta. Sem vínculo, mtime futuro/inválido ou leitura impossível, declarar indeterminado. Diagnóstico pode distinguir “valores configurados iguais” de “idade de entrega sem teto garantido”. TTL zero segue a semântica do provedor, nunca uma suposição de expiração instantânea.

Emitir aviso acionável para teto não garantido ou TTL superior ao token; informar a dependência do cron e a renovação pelo cliente. Não afirmar perda de lead nem degradar automaticamente todos os cabeçalhos por esse diagnóstico. Manter a configuração de cache da frota, inclusive 3600 onde já gravado; não alterar cache/token silenciosamente. O controle efetivo é renovar o token antes do POST.

**Aceite M37:** HTML originalmente assinado há mais de 60 minutos servido pelo ramo real wp-cache; usar relógio/artefato controlado na bancada, sem espera manual. Cobrir coleta atrasada/ausente e valores configurados iguais. Primeiro envio renova antes do POST sem 403 evitável; chamadas concorrentes compartilham a renovação. Incluir falha da rota de token, ausência de cache, proxy desconhecido e prova de idade inconclusiva. Retestar clique, formulário e análise que usam o serviço comum.

### 6.3 C58/D09-T — respostas compactas e evidência única

Acrescentar `compacto` a `config-core-verificar`, preservando ações e controles existentes. Resposta compacta deve conter `ok`, código, nome/revisão pertinente, `efeito_cache`, `verification`, `evidencia_id`, situação de persistência e indicação de como consultar o detalhe. `ok=true` indica que a operação foi atendida; não equivale a prova pública aprovada.

Organizar o detalhamento por evidências identificadas. Na mesma resposta, cada conjunto de resultados de tokens aparece uma vez; projeções de `cache`, `sonda`, `ultima_tentativa` e `ultimo_sucesso` referenciam o ID em vez de repetir o corpo inteiro. Tentativa e sucesso diferentes continuam preservados como evidências distintas. Não fundir provas só porque o resumo textual coincide.

Aplicar a mesma projeção a `saude-ler`, atualizar output schemas e consumidores internos. Versionar o contrato alterado; exemplos para agentes mostram consulta curta e recuperação do detalhe. Consulta por ID não dispara novas sondas e informa expiração/ausência de forma explícita.

**Aceites C58/D09-T:** primeira consulta sem prova, sucesso, falha após sucesso, prova expirada, atualização de cache e erro de persistência. Comparar compacto e detalhado: mesmo status/revisão/efeito, sem perder motivo. Verificar a resposta serializada para impedir repetição do mesmo conjunto de tokens; medir redução de bytes contra a 1.14.0, sem usar tamanho como substituto da integridade do conteúdo.

## 7. Formulários, consentimento e documentação

### 7.1 F25 — confirmação sem JavaScript

Fixar a política da confirmação em `noindex, nofollow`, tanto no cabeçalho quanto na meta. Aplicar a regra no ponto final de composição da resposta dessa rota, removendo `index`/`follow` conflitantes. Se mantido `wp_die`, considerar o filtro que o WordPress adiciona durante o próprio manipulador [S4–S5]. Evitar filtro global que altere as páginas normais.

**Aceite F25:** submissão HTTP real sem JS, redirecionamento 303 e GET da confirmação; sucesso, erro e referência expirada, site público e privado. Conferir meta/cabeçalho, status, `no-store`, expiração e ausência de dado sensível em URL. Depois da bancada, homologar um envio sem JS em site com formulário nativo do pacote, marcado como teste e com e-mails/integrações suprimidos. Conservar labels e limpeza que já funcionam; não reabrir sem regressão.

### 7.2 U45 — aparência do consentimento

Usar fonte e paleta disponíveis no tema, por variáveis do componente e presets efetivamente identificados. Resolver fundo/texto e fundo/texto das ações como pares. Uma variável isolada não será tratada como garantia de contraste.

O componente deve aferir os pares resolvidos e aplicar um par acessível de reserva quando insuficientes ou indeterminados. Fazer isso no próprio fluxo de abertura/atualização do consentimento, com leituras agrupadas, sem biblioteca adicional, varredura contínua do DOM ou reestilização de outros botões. Incluir rodapé, hover, foco, links e controles. Reavaliar quando o modo claro/escuro suportado mudar.

Aceite de texto normal ≥ 4,5:1, sem arredondamento para aprovar valor inferior; foco visível e interação por teclado [S8]. A garantia cobre o componente e o contrato de personalização suportado. CSS externo que impõe cores conflitantes fora desse contrato precisa ser corrigido na integração; não prometer acessibilidade para qualquer sobrescrita arbitrária.

**Aceite U45:** tema claro/escuro em 360 e 1440 px, zoom, texto longo, foco, hover, banner recolhido/aberto, rodapé e alteração de só uma variável. Validar cores computadas e aparência. Reproduzir em bancada o caso Conselar. Depois da troca de versão, o projeto do site salva backup nomeado e retira a compensação de CSS (especificidade 0,2,0), conferindo novamente 360 e 1440 px; restaura o trecho se o aceite falhar. O Core não altera o tema automaticamente.

### 7.3 D48 — cadência e documentação instalada

Documentar o comportamento já exposto em `saude.cadencia`: destino `registro_local_de_atividade`; `envia_mensagens=false`; não corrige configurações; mede módulos, relê options e faz censo demonstrativo; armazena o último resultado, não um histórico completo. Explicar periodicidade, gatilho por quantidade de ajustes, horários, duração, erros e próxima execução.

Atualizar conjuntamente `docs/CONTRACTS.md`, `docs/dados/contrato.json`, `f3base/como-usar`, índice documental, ajuda da tela e notas da versão. Exemplos devem consultar o resultado existente e distinguir isso de executar a cadência.

**Aceite D48:** todos os pontos de entrada descrevem o mesmo destino, conteúdo, consulta e retenção. Não acrescentar e-mail, histórico novo ou correção automática a uma demanda de documentação.

Toda mudança de contrato desta release deve chegar à documentação **dentro do plugin instalado**, legível por arquivo e canal autenticado. Manter a proteção HTTP vigente. Acrescentar exemplos de ofertas, migração, mescla, respostas compactas, perfis, atribuição/CAPI e procedimentos de teste.

## 8. O que fica fora e por quê

| Grupo | Tratamento | Justificativa |
|---|---|---|
| 36 — LLMS durante lote | Acompanhamento e teste de regressão | Código de preservação já existe. Exercitar atualização de cache, salvamento e execução de pendentes. Verificar especificamente o gancho `f3base_llms_regenerar`; se a reprodução revelar caminho sem execução, corrigir como falha do mesmo item. Sem geração anterior, indisponibilidade inicial deve ser distinguida de regressão durante regeneração. |
| 50 — slug longo | Acompanhamento da soma e regressão do parser | A regra já foi corrigida. Aceite operacional citado é a soma de 28/09 processada em 29/09. Reprocessar somente logs ainda disponíveis; não fabricar histórico de logs eliminados. |
| 52 — duplicata/503 | Acompanhamento de sete dias e regressão concorrente | Há tratamento no código. Conservar testes de duplicação e falha real do banco; não atribuir retrospectivamente os cinco 503 a uma causa não comprovada. Ausência de duplicatas no log precisa ser acompanhada de volume e contadores de falha, para evitar “aprovação” sem tráfego. |
| 31, 34, 35, 39, 40, 43, 44, 47, 49 e 51 | Encerrados; regressão apenas onde houver alteração relacionada | O anexo os dá como resolvidos. Não cobrar sua implementação novamente. |
| 17 — Pipedrive/CRM e webhook | Continuam adiados | Decisão expressa do dono; as correções de CAPI usam uma integração existente e não retomam CRM. |
| URL própria de confirmação | Backlog separado | Não é pré-requisito para corrigir robots da confirmação nativa. O anexo não detalha um novo contrato dessa URL. Não confundir o adiamento de CRM com uma decisão expressa sobre essa funcionalidade independente. |
| Itens 1–8 do implantador/tema-modelo | Plano do pacote responsável; dependência documental | O anexo só os referencia e não apresenta as oito especificações. Não há base para estimar ou prometer implementação. O item 7 deve apontar para a versão vigente na publicação, sem congelar 1.14.0. Exigir o documento original para discriminar todos os itens. |
| Atributos/compensações específicos dos temas | Operação por site após aceite | `data-f3base-destino` ausente no tema, exceção de ofertas da Twinia e compensação de CSS da Conselar não são removidos por atualização cega do Core. |
| Mudança automática de escolhas da frota | Fora | Preservar destinatários vazios, listas vazias, preferências desligadas e opções explícitas. Diagnóstico não autoriza impor um perfil. |

Não acrescentar detecção de agente por IP/horário, credencial temporária para testes, envio novo de relatórios por e-mail, importação de leads nativos, sincronização de custos ou exclusão retroativa de registros. Nenhum desses itens é necessário para resolver as pendências desta revisão.

## 9. Ordem de implementação e critérios de entrega

### Ordem interna

1. Reproduzir defeitos a partir do ZIP 1.14.0, registrar falha por ID e obter o backup real de ofertas. Fixar contrato 3.0.0, modelo de ofertas, regras do piso e semântica das migrações antes de alterar consumidores.
2. Corrigir redirects nativos/declarados e consolidação de evidência; atribuição/consentimento e envelope CAPI; mescla/auditoria e diagnósticos de leitura.
3. Implementar ofertas e prova pública, conflitos de emissor e Person; concluir piso integral e projeções compactas sobre os contratos estabilizados.
4. Medir o transporte nos dois modos Google; concluir diagnóstico de TTL, confirmação sem JS e consentimento visual.
5. Atualizar documentos, exemplos e notas de atualização; executar aceites integrados e reversão; gerar o pacote único e comparar com o código homologado.

### Ambientes e sequência de publicação

- Bancada com WordPress, MySQL/InnoDB, PHP, navegador e WP Super Cache 3.1.3. Registrar versões exatas e reproduzir o perfil da frota. Fixtures puras complementam HTTP/cache/navegador; não os substituem.
- Homologar o pacote no Site-Teste. **Entregar os arquivos ao dono; o teste em korvena.net.br é feito por ele**, conforme sua instrução, e constitui o piloto. Não exigir teste do agente nesse domínio para entregar o pacote.
- **A expansão para os demais sites espera o aceite do dono no piloto.** Sequência documentada: Site-Teste → korvena.net.br → fator3.com.br e korvena.com.br → demais sites. Confirmar inventário/aliases antes da rodada; não repetir a contagem “outros 11” do relatório, incompatível com 14 hosts e essas etapas. Todos recebem o mesmo pacote homologado; isso não divide a release.
- Exercitar instalação nova, atualização exclusiva 1.14.0 → 1.15.0. Não executar nem testar caminhos de versões anteriores.
- Contas externas e temas reais têm aceite próprio. “Fixture passou” não equivale a produção validada. Os sete dias do item 52 são acompanhamento operacional com volume de eventos e contadores de falha; não declarar o período cumprido antes de transcorrer.
- Ensaios mantêm marca de teste e supressão externa. Nas sondas de cache público usar cabeçalho local, sem bypass; validações com navegador preservam sua classe de teste e não geram notificações comerciais.

### Condições para fechar a versão

Cada ID deve ter estado, cenário, ambiente, hash/versão, esperado/observado e caminho da evidência. Estados distintos: **implementado**, **validado em bancada**, **validado no Site-Teste**, **validado no piloto**, **aceite externo pendente**, **não aplicável com justificativa** e **bloqueado por fonte**. Registrar separadamente aprovação técnica do pacote, aceite do piloto e execução da frota.

Nenhum defeito P1 conhecido fica aberto em um pacote apresentado como concluído. Piso completo é obrigatório com a fonte agora recebida; não há mais justificativa documental para entregar o antigo perfil parcial. Aceites externos e a fixture real ausente são identificados individualmente; não declarar “17 de 17 concluídos” se faltar a prova exigida de algum item. Dependências do implantador ficam em seu pacote responsável.

Entregar **ZIP instalável, fontes/testes, documentação integrada, relatório de validação, manifesto e SHA-256**, com links funcionais para todos. Relatório e manifesto identificam a mesma versão/hash homologados e a sequência de publicação. A aprovação do piloto ocorre depois dessa entrega e antes da expansão.

### Configuração exposta e escolhas internas

| Configurável | Local / padrão |
|---|---|
| Preservar query | Por par em `f3base_redirects`; ausência equivale a `true`, `false` explícito permanece |
| Ofertas | `servicos[].ofertas[]`; lista vazia quando não há oferta, com tratamento de migração separado |
| Perfil e exceções | Parâmetros da avaliação, informados pelo chamador; não são uma option que reconfigura o site |

Prazo de análise, regra de aviso de TTL, pares de cores de reserva e limite defensivo da query são decisões internas documentadas. Não criar novas options para cada detalhe técnico.

### Cinco declarações obrigatórias no relatório da release

| Declaração | Evidência e operação correspondente |
|---|---|
| Delta de cache | Comparar `exclusoes_requeridas` e `configuracao_requerida` com a 1.14.0, inclusive delta vazio. R30 não cria delta. Se outro item exigir alteração, fornecer patch exato de `wp-cache-config.php`, motivo e `atualizar_cache` para cada site afetado |
| Bloco `F3BASE MANAGED` | Informar se muda e hashes completos anterior/proposto. O prefixo `3063d224…` citado não substitui hash/revisão de pré-voo. Se mudar, preparar aplicação pelo projeto de cada site com `servidor-aplicar` e `revisao_esperada`; não presumir acesso de escrita nem revisão global |
| Chaves novas por option | Nome, tipo, default, diferença entre instalação e atualização, tratamento de vazio/falso e condição do piso. Escrever explicitamente na rodada somente após simular diferenças, respeitando dados já gravados e exceções |
| Migrações e prova | Versão, pré-condições, total encontrado/migrado/pendente, antes/depois privado e consulta de confirmação. `config-core-ler` apresenta `erros[]`/`avisos[]`; leitura bem-sucedida não significa migração válida |
| Contrato | `contract_version` **2.0.0 → 3.0.0**, mudanças de cada input/output schema, paths recusados, consumidores afetados e exemplos atualizados. Versão do contrato é independente do nome da ability |

## 10. Atualização, reversão, operações e dependências

### Efeitos da atualização

| Mudança | Efeito ao atualizar | Cuidado operacional |
|---|---|---|
| Query em redirects | Recupera atribuição, cobre redirects nativos e respeita veto por par | Sem exclusão nova de cache por R30; manter invalidação já necessária ao alterar regras/conteúdo e testar cache real |
| Política de atribuição | Restringe armazenamento/envio conforme consentimento | Não reconstruir cookies/toques ausentes de contatos históricos |
| CAPI do formulário | Usa registro persistido, envelope e marca corretos | Reconsultar ativação/fila e comprovar destino de teste antes de liberar envio externo |
| Schema fechado e ofertas em lista | Novo contrato de escrita; migra formato inequívoco e diagnostica ambiguidades | Inventário de chaves extras, snapshot privado, simulação de descarte e prova pública antes de trocar o grafo |
| Auditoria `ability` | Reconhece procedência já existente | Cálculo de leitura; não forjar revisão, autor ou data |
| Perfis e projeções | Piso integral, cinco tipos de regra, diagnóstico e resposta compacta | Atualizar consumidores/schemas/docs; avaliação não aplica perfil |
| CSS/robots/transporte | Altera resposta pública e comportamento do navegador | Invalidar cache quando pertinente e conferir HTML/assets finais |

### Reversão ensaiada para a 1.14.0

Antes da atualização, registrar revisões, opções afetadas, evidências e snapshots privados. O retorno do binário não equivale a retorno funcional completo.

| Mudança | Com a 1.14.0 de volta | Ensaio / recuperação |
|---|---|---|
| `servicos[].ofertas` | A chave extra é aceita/preservada pelo caminho inspecionado, mas não recebe emissão das novas ofertas | Testar leitura e escrita de ida/volta com dados reais de bancada; manter cópia das ofertas novas. Se a exceção Twinia já foi retirada, restaurar o Service do tema pelo backup nomeado, invalidar cache e conferir sem duplicação |
| Evidências R54/S55 | Formato novo não é interpretado pela versão anterior | Gravar em armazenamento próprio versionado, sem substituir estruturas 1.14.0. Invalidar provas antigas pelos mecanismos compatíveis e iniciar consulta como pendente; nunca reaproveitar um `verified` obsoleto |
| C56 | Reclassificação deixa de ser feita | Não há autoria/revisão regravada para desfazer |
| `preservar_query=false` | A 1.14.0 volta a ignorar o veto | Declarar a regressão e confirmar efeito nos pares afetados; retorno não pode ser apresentado como equivalente |
| CAPI | Voltam os defeitos de envelope/teste | CAPI inativa em 28/09 não garante inatividade na data do rollback. Se ativada depois, suspender despacho externo pelo controle existente e preservar a fila antes de reverter; não enviar itens de teste comercialmente |

Não restaurar banco inteiro sobre capturas novas. Restauração dirigida só remove/transforma dados com simulação e sem perda de registros posteriores. Não fabricar marcadores de migração. A retirada da exceção Twinia espera estabilidade da 1.15.0 na frota para reduzir a necessidade de recuperação combinada do tema.

### Operações dos projetos de site após atualização

Na ordem da seção 9, registrar antes/depois, revisão e aceite. Esta revisão do plano não executa escritas nos sites.

| Site / conjunto | Operação prevista |
|---|---|
| Todos os hosts confirmados | Inventário de configuração, chaves extras e CAPI antes da publicação; aplicar deltas efetivamente declarados; conferir contrato/perfil e resultado das migrações |
| korvena.net.br | Piloto do dono e autorização da expansão; acompanhamento de sete dias do item 52 com volume e falhas |
| fator3.com.br | Conferir `f3base_redirects` em `revisao_confirmada`, sem regravar pares para fabricar a prova |
| korvena.com.br e ctooffice | Repetir verificação paginada R54; cobertura integral e `verified` apenas com todas as variantes aprovadas |
| ctooffice | Decisão operacional sobre `servicos[].publico`, backup e escrita dirigida se aprovada; fornecer fixture antiga; comprovar simulação e Person inconclusivo quando houver bloqueio externo |
| fator3capital | Repetir `/pagina-inicial/quem-somos` só com `gclid` e só com `utm_source` |
| Twinia | Configurar ofertas, observar conflito de emissor e, após estabilidade da frota, retirar apenas Service do tema com backup; conferir publicação real do Core |
| Conselar | Retirar compensação CSS após troca de versão, com backup e validação em 360/1440 px |
| Site com formulário nativo | Aceite F25 sem JS, marcado como teste e sem notificações comerciais |

Regularizar `f3base_nav_id` de fator3.com.br, korvena.com.br e fator3grupo é operação independente já aberta; não aguarda esta release nem ocorre automaticamente no diagnóstico.

**Documentos externos da frota:** o projeto responsável atualiza Padrão §§3.1, 3.7, 10.3, 10.4 e 16.1; Conector WP MCP §3.4; e o quadro Pedidos ao pacote core com evidências de encerramento. Isso acompanha a rodada e não substitui a documentação entregue dentro do plugin. Não se afirma aqui edição de nenhum desses documentos externos.

### Decisões e fontes ainda necessárias

- **Piso:** fonte suficiente recebida no Anexo A; requisito integral incluído, sem depender de nova decisão do dono.
- **`servicos[].publico`:** uma decisão operacional antes de substituir a lista de ctooffice. Recomendar remover com backup e simulação, por não haver consumidor relatado. Até a escolha, preservar o bruto e permitir edições independentes. Não remover automaticamente nem incluir `Service.audience` sem novo escopo.
- **Fixture real de ofertas:** obter o conteúdo de `options-f3base_seo_entidade-mcp-20260928-1104.txt`. O relatório cita o arquivo, mas não o anexa; a busca pelo nome também não o localizou. A implementação começa com fixtures de contrato; o aceite desse caso real fica pendente de fonte e não pode ser anunciado como executado.
- **Implantador/tema:** fora da responsabilidade deste plugin por decisão expressa do dono; suas especificações e operações não bloqueiam implementação, testes ou entrega do Core.
- **Sem bloqueio de produto para iniciar:** prazo M38 é decisão técnica experimental. Modo Google de fator3.com.br e `bloquear_listagem` continuam decisões independentes já abertas, sem alteração implícita nesta release. CRM e confirmação personalizada permanecem fora do escopo atual.

## 11. Referências e pontos de código

Fontes fornecidas: anexo de pendências; `analise-plano-1.15.md`, incluindo o Anexo A do piso; plano aprovado e relatório 1.14.0; instalador/fontes com hash identificado na seção 1. O Padrão integral e a revisão 41 de Pedidos ao pacote core não foram usados como se tivessem sido lidos: as constatações de produção e trechos ausentes do código local são atribuídos ao relatório.

Pontos principais do instalador, caminhos relativos à pasta `base-site-core-fator3/`:

| Assunto | Arquivos / símbolos conferidos |
|---|---|
| R30/R54 | `includes/class-f3base-modulo-redirects.php`: `casar_declarado`, `executar`; `includes/class-f3base-redirects-servico.php`: `preservar_query`, `contexto`, `evidencia`, `verificar` |
| A32 | `includes/class-f3base-formularios.php`: `receber`; `includes/class-f3base-modulo-endpoint-leads.php`: `validar_atribuicao`; `includes/class-f3base-atribuicao.php`; `includes/class-f3base-leads-contexto.php`; `includes/class-f3base-modulo-meta-capi.php`: `montar_payload`, `agendar` |
| C53/C57 | `includes/class-f3base-core-config-mcp.php`: `ler`, `escrever`; `includes/class-f3base-config-mescla.php`; `includes/class-f3base-config-consultas.php`: `heranca`; `includes/class-f3base-options.php`: `aviso_de_normalizacao` |
| C56/C42/C46 | `includes/class-f3base-auditoria.php`: `classificar`; `includes/class-f3base-options.php`: `procedencia`; `includes/class-f3base-servicos.php`: `recusar`; `includes/class-f3base-config-perfil.php`; perfil parcial `docs/perfis/piso-core-1140.json`; `includes/trait-f3base-options-catalogo.php` e `includes/class-f3base-vocabulario.php` |
| S41/S55/D09-P | `includes/class-f3base-seo-entidade.php`: `schema_oferta`, `oferta_publica`; `includes/class-f3base-schema-verificacao.php`; `includes/class-f3base-modulo-schema-extensao.php` |
| M37/M38/C58/D09-T | `assets/f3base-analise.js`; `assets/f3base-contexto.js`; `includes/class-f3base-cache-pagina.php`: `perfil`, `resumo`; registro de `config-core-verificar` em `includes/class-f3base-core-config-mcp.php` |
| F25/U45/D48 | `includes/class-f3base-formularios.php`: `confirmacao`; `assets/f3base-consentimento.css`; `includes/class-f3base-modulo-cadencia-relatorio.php`: `consultar` |

Referências técnicas externas consultadas em 28/09/2026:

- **S1:** [WP Super Cache — `wpsc_remove_tracking_params_from_uri`](https://github.com/Automattic/wp-super-cache/blob/trunk/wp-cache-phase2.php). Código público da branch consultada; homologação deve fixar a versão efetivamente instalada.
- **S2:** [Schema.org — UnitPriceSpecification](https://schema.org/UnitPriceSpecification).
- **S3:** [Schema.org — minPrice](https://schema.org/minPrice).
- **S4:** [WordPress — `_default_wp_die_handler`](https://developer.wordpress.org/reference/functions/_default_wp_die_handler/).
- **S5:** [WordPress — `wp_robots_no_robots`](https://developer.wordpress.org/reference/functions/wp_robots_no_robots/) e [`wp_robots`](https://developer.wordpress.org/reference/functions/wp_robots/).
- **S6:** [MDN — visibilitychange](https://developer.mozilla.org/en-US/docs/Web/API/Document/visibilitychange_event).
- **S7:** [Chrome — Lighthouse performance scoring](https://developer.chrome.com/docs/lighthouse/performance/performance-scoring).
- **S8:** [W3C — WCAG, Contrast Minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html).
- **S9:** [WordPress — redirect_canonical](https://developer.wordpress.org/reference/functions/redirect_canonical/), incluindo remoção intencional de parâmetros e filtro específico.
- **S10:** [WordPress — wp_old_slug_redirect](https://developer.wordpress.org/reference/functions/wp_old_slug_redirect/), com `old_slug_redirect_url`.
- **S11:** [Schema.org — referenceQuantity](https://schema.org/referenceQuantity) e [billingDuration](https://schema.org/billingDuration).

## 12. Matriz do piso recebido — Padrão §3.1, rev 48

Fonte: Anexo A de `analise-plano-1.15.md`; referência `piso-padrao-3.1`, revisão-fonte `2026-09-28-core-1.14.0`. A implementação 1.15.0 mantém rastreabilidade por linha e acrescenta as chaves de seu contrato no manifesto de atualização.

**Regra transversal P00:** nenhuma chave de configuração aplicável herdada, para todas as options do contrato salvo `f3base_consentimento`. Estado de execução fica fora. Segredos `f3base_endpoint_segredo` e `f3base_meta_capi_token` não entram como valores do perfil; somente existência/tipo/tamanho no diagnóstico protegido. Chaves sem valor fixo no quadro devem estar gravadas com o valor do site. Vazio é valor, não ausência. Regras condicionais só se aplicam quando a condição e o item existem.

| ID | Option / chaves | Regra | Exigência do piso |
|---|---|---|---|
| P01 | `f3base_comportamento.ligado`, `.retencao_dias`, `.retencao_eventos_dias`, `.dias_no_painel`, `.tempo_ativo` | `igual` | `true`, `90`, `30`, `28`, `false`, respectivamente; ligar tempo ativo depende do dono |
| P02 | `f3base_origem_confiavel.cabecalho`, `.saltos`, `.redes_confiaveis` | `igual` | `''`, `1`, `[]`; cabeçalho diferente somente com exceção de proxy nomeado |
| P03 | `f3base_retencao_meses` | `igual` | `12` |
| P04 | `f3base_acessos.ligado`, `.retencao_meses`, `.padroes_hospedagem` | `igual` | `true`, `25`, `[]` |
| P05 | `f3base_acessos.padrao_do_log` | `derivado_do_host` | `~/logs/<domínio sem www>/https/access.log.*` |
| P06 | `f3base_acessos.caminhos_excluidos` | `contem` | `/wp-json/mcp/`, `/wp-json/f3base/`, `/wp-admin/`, `/wp-login.php`, `/xmlrpc.php`, `/wp-cron.php`, `/wp-content/`, `/wp-includes/`, além das rotas privadas declaradas do site |
| P07 | `f3base_sessao.ligado`, `.dias`, `.modo` | `igual` | `true`, `90`, `legado` |
| P08 | `f3base_sessao.regras` | `igual` | Capacidades `manage_options` e `edit_others_posts`: 14 dias; papéis `author` e `subscriber`: 90 dias; estrutura de cada regra conforme contrato, com `nucleo=true` em `manage_options` e `false` nos demais, como no catálogo inspecionado |
| P09 | `f3base_atribuicao` | `igual` | `{modelo: first-touch, ttl_dias: 30}` |
| P10 | `f3base_robots.ligado` | `igual` | `true` |
| P11 | `f3base_cabecalhos` — seis cabeçalhos e HSTS | `igual` | `x_content_type_options=true`; `x_frame_options=SAMEORIGIN`; `csp_frame_ancestors="'self'"`; `referrer_policy=strict-origin-when-cross-origin`; `coop=same-origin-allow-popups`; `permissions_policy="geolocation=(), camera=(), microphone=()"`; `hsts=false` |
| P12 | `f3base_llms.ligado` | `igual` | `true`; exceção documentada para produtor de terceiro |
| P13 | `f3base_llms.markdown`, `.full`, `.indexavel`, `.cabecalhos_servidor` | `igual` | Todos `true` |
| P14 | `f3base_llms.modo`, `.tipos`, `.entrega` | `igual` | `curada-mais-automatica`, `["page","post"]`, `arquivo_gerado` |
| P15 | `f3base_llms.blocos_interface` | `presente` | Blocos interativos do tema do site |
| P16 | `f3base_llms.introducao`, `.apresentacao`, `.politica_privacidade`, `.livres` | `presente` | Valores do site; vazio permitido; cada item existente de `livres` exige `id` |
| P17 | `f3base_contato.avisar_por_clique`, `.avisar_por_formulario` | `igual` | Ambos `true` |
| P18 | `f3base_contato.whatsapp_e164` | `presente` | Preenchido quando o regime de lead é WhatsApp; não inventar número |
| P19 | `f3base_contato.flutuante`, `.mensagem_padrao`, `.email_leads`, `.classes_cta` | `presente` | Valores do site; classes `[]` ou classes do CTA do tema |
| P20 | `f3base_seo_entidade` | `presente` | Todas as chaves aplicáveis do contrato, inclusive vazias; listas vazias não exigem itens fictícios. Exceção documentada para outro emissor de identidade |
| P21 | `f3base_nav_id` | `referencia_valida` | `0`, ou `wp_navigation` publicado e comprovadamente usado no cabeçalho; falta de prova é indeterminada |
| P22 | `f3base_protecao.usuarios_rest_restritos`, `.xmlrpc_desativado`, `.login_generico` | `igual` | Todos `true`; exceção para publicador que depende de XML-RPC |
| P23 | `f3base_testes.habilitado`, `.excluir_relatorios` | `igual` | Ambos `true` |
| P24 | `f3base_testes.destinos` | `igual` | `gtm`, `ga4`, `google_ads`, `meta`, `linkedin`, `capi`, `email`: todos `suprimir` |
| P25 | `f3base_testes.ga4_ids`, `.gtm_homologado`, `.capi_test_event_code`, `.email_destinatarios` | `igual` | `[]`, `false`, `''`, `[]`, respectivamente |
| P26 | `f3base_servidor.bloquear_listagem` | `igual` | `false`; ligar é decisão do dono |
| P27 | `f3base_carregamento_destinos` | `igual` | `{ativo: true, meta: herdar, linkedin: herdar}`; o valor literal `herdar` é gravado e não equivale a chave ausente |
| P28 | `f3base_redirects_hosts` | `igual` | `[]`; exceção para redirect entre sites decidido pelo dono |
| P29 | `f3base_classificacao_acessos` | `igual` | `{ativo: true, repeticao: true}` |
| P30 | `f3base_formularios` — cada campo de arquivo existente | `igual` | `max_bytes: 0`, `extensoes: []`; lista de formulários vazia não cria campos |

Os nomes/valores dos seis cabeçalhos, os sete destinos e a estrutura das regras de sessão foram expandidos com o catálogo 1.14.0, sem trocar a regra recebida por defaults genéricos. Outras chaves, como `hsts_max_age`, continuam sujeitas à presença explícita P00; o Anexo A não fixa outro valor para elas.

Na implementação, cada Pxx aponta para suas condições executáveis e testes. A enumeração de chaves considera contrato/condições de domínio, com tratamento explícito de campos opcionais e condicionais; não exigir preço em oferta `sob_consulta` nem item em lista vazia para satisfazer “presente”. Rotas privadas adicionais vêm do inventário fornecido pelo chamador e do contrato do site; desconhecimento dessa parte é indeterminado, sem apagar a cobertura dos oito caminhos fixos.

## 13. Parecer sobre as recomendações do relatório

| Recomendação | Decisão nesta revisão | Justificativa / ajuste |
|---|---|---|
| Piso completo pelo Anexo A | Incorporada | Fonte suficiente para §3.1; cinco tipos de regra, matriz integral, versão e presença explícita |
| Piloto em korvena.net.br | Incorporada com ajuste de responsabilidade | O dono testa após receber os arquivos; a frota aguarda seu aceite. Mantida a instrução de não exigir teste do agente nesse domínio |
| Query nos redirects do WordPress | Incorporada com limite | Restaurar atribuição por fluxos conhecidos; não repor toda a query em filtro global, o que desfaria a limpeza intencional do WordPress |
| Nenhuma exclusão nova por R30 | Incorporada | Delta vazio para o item; `no-store, private`. Mantida a invalidação já necessária quando regras/conteúdo mudam, evitando HTML 200 antigo ocultando redirect |
| TTL não garantido no modo wp-cache | Incorporada | Diagnóstico distingue valor configurado, cron e idade efetivamente observada; renovação é o controle de envio |
| Schema fechado e saída de ctooffice | Incorporada com proteção dos dados | Contrato 3.0.0, inventário, erro por caminho, backup e simulação. Não adotado apagamento automático na primeira edição |
| Montador CAPI a partir do lead | Incorporada | Um envelope para clique/formulário, teste/consentimento/ID preservados; não reprocessar histórico |
| “Nenhuma conversão contaminada pode existir” | Não adotada como conclusão histórica | Inatividade e fila vazia atuais não demonstram todo o passado; registrar apenas exposição atual informada e revalidar antes de ativar |
| Fixture real de ofertas e casos de produção | Incorporada, com dependência explícita | Casos adicionados aos aceites; backup ainda precisa ser fornecido; zero migrações na frota só após recontagem |
| Mapeamento de preços/períodos e conflito de emissor | Incorporada com correção semântica | Preço gratuito mantém período; mínimo usa tipo numérico; duração mínima não vira `billingDuration` automaticamente; “Publicada” exige emissão do Core observada |
| M38 nos dois modos de Google | Incorporada com ajuste experimental | 60 medições principais; não exigir ordenação idêntica entre braços, mas política válida nos dois modos |
| Lighthouse em bancada e confirmação PSI | Incorporada | Registrar versão atual da medição; bloqueio externo é pendência, não resultado simulado |
| Sondas marcadas, Person, F25 e U45 | Incorporada | Marca local sem bypass; 999/login inconclusivo; confirmação real sem JS; CSS do tema retirado pelo projeto do site com reversão |
| Armazenamento versionado e rollback | Incorporada com ressalvas | Testar preservação efetiva; não reutilizar prova antiga nem supor CAPI sempre desligada |
| Cinco declarações e operações/documentos por site | Incorporada | Relatório obrigatório e responsabilidade de cada rodada explicitados, sem afirmar execução nesta análise |
| Oito itens do implantador/tema e nova audience | Não acrescentados à implementação do Core | Especificações dos oito itens não vieram; audience amplia produto sem necessidade para corrigir a preservação do dado |
