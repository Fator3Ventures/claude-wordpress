# Base Site Core Fator3 1.15.0 — entrega e validação

28/09/2026. Implementação do plano aprovado, revisão 3, com o recorte final do dono: **instalação nova ou atualização exclusiva de 1.14.0 concluída**. Implantador e tema ficam fora do plugin. O instalador entregue é o mesmo aplicado e observado no Site-Teste; a frota não foi atualizada.

## Arquivos e instalação

- Instalador: `base-site-core-fator3-1.15.0.zip`, 832,920 bytes, 172 arquivos.
- SHA-256 do instalador: `23a047da1873d9cc4372f672423e4536596cc06dcd24266209443384847cf05b`.
- `fontes-testes-core-1.15.0.zip`: código editável, documentação, build determinístico, plano e harnesses/evidências, incluindo os 60 conjuntos Lighthouse e as seis observações PSI. A referência 1.14.0 incluída serve exclusivamente ao ensaio de atualização/reversão.
- `manifesto-1.15.0.json`: tamanho e SHA-256 de cada arquivo instalado.
- `SHA256SUMS-1.15.0.txt`: hashes dos artefatos finais.

Faça backup dirigido de arquivos e banco, confirme a base 1.14.0 concluída e envie o ZIP pelo instalador WordPress, substituindo a versão existente. Instalação nova usa defaults do catálogo, administração como destinatário inicial e pasta privada provisionada. Na atualização, os valores gravados, inclusive falso/zero/lista vazia, permanecem. Não fabricar marcador de versão nem editar SQL para contornar recusa.

Após atualizar, confira `f3base/saude-ler`, documentação e `f3base/config-core-contrato-v1` (conteúdo 3.0.0). Aplique configurações somente por revisão/simulação. O ZIP contém documentação em `docs/`; `f3base/documentacao-ler` lista os caminhos canônicos. Exemplo: `{"arquivo":"docs/AGENTES-1.15.md","linha":1,"limite":120}`.

## O que foi implementado

| Aceite | Resultado do código |
|---|---|
| R30 | Query original antes da remoção pelo cache; veto por par; destino prevalece; parâmetros repetidos/escapados; query inválida descartada sem perder redirect válido; recuperação limitada à atribuição nos fluxos nativos; no-store nos 3xx com query. |
| R54 | Provas por execução/configuração/contexto e variante, CAS sobre estado recente, cursor retomável, expiração individual e persistência explícita. `verified`/cobertura integral exigem todas as provas aprovadas. Estado sem escopo/contrato fica pendente. |
| A32 | Normalização comum de clique/formulário; consentimento confirmado; fbc/fbp válidos; envelope CAPI a partir do lead persistido; snapshot, teste, URL/horário/correlação preservados; revalidação no despacho; nenhuma recomposição histórica. |
| C53 | Mescla de objetos por campos tocados e dependências; listas substituídas quando enviadas; preservação do bruto independente; serviços/ofertas fechados na escrita; erros por caminho e migração conservadora. |
| C57 | Simulação distingue `alteraria` de gravação, informa remoções e não executa efeitos. |
| C56 | Vocabulário comum reconhece origem `ability`; classificação de leitura não inventa autoria nem regrava histórico. |
| C42 | Navegação identifica referência e uso observado no cabeçalho; ausência de evidência permanece indeterminada. |
| C46 | Piso integral `piso-padrao-3.1` por ID/revisão ou objeto, condições tipadas, presença explícita, exceções com vínculo/expiração e avaliação somente leitura. |
| C58/D09-T | Resposta compacta, evidência por SHA e detalhe sem sonda; conjuntos de tokens desduplicados em saúde/contrato/verificação/ajuda. |
| S41/S55 | Múltiplas ofertas por serviço com ID estável; preço canônico; fixo/recorrente/mínimo/grátis/sob consulta; prova do conteúdo antes da emissão; conflito de emissor e invalidação; quadro agrupado no admin e documentação. |
| D09-P | Recursos Person/sameAs vinculados aos nós e consulta desduplicada; erro/desafio externo não vira confirmação de identidade. |
| M38 | Prazo absoluto inicial de 5000 ms após load, fila imediata, saídas antecipadas, confirmação por evento/sequência e recuperação de 503 durante lote em voo. |
| M37 | TTL configurado distinto da idade efetiva, dependência de cron e vínculo de mtime com HIT exato; renovação antes de POST. |
| F25 | Resposta real sem JS com 303; confirmação noindex/nofollow em meta e cabeçalho, sem diretivas conflitantes e sem cache. |
| U45 | Paleta/fonte do tema com pares acessíveis de reserva; contraste computado, rodapé/hover/foco/zoom e escopo restrito ao componente. |
| D48 | Cadência documentada como último demonstrativo local; não envia mensagens, não corrige configurações e não acrescenta histórico. |

## Cinco declarações de mudança

1. **Cache:** delta de requisitos/exclusões/rastreamento **vazio** para esta release, comparado sob a mesma configuração nos binários reais 1.14.0/1.15.0. TTL/provedor não são reconfigurados. As invalidações já necessárias para mudança de regras/conteúdo permanecem. No Site-Teste, requisitos antes/depois também coincidiram e a sonda posterior comprovou HIT e corpo vazio do artefato PHP.
2. **Bloco managed do servidor:** conteúdo gerado igual para configurações iguais. Hash completo do bloco habilitado de referência: `3063d224ddf335ed29980504818f2c149930f1c2baa3342f9b33fd6b7ea0b94c`. Com a fixture LLMS explicitamente desligada, ambos geraram bloco vazio (`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`). Nenhuma aplicação de regras no Site-Teste nesta rodada; revisão observada permanece `8c496185f7f2b2f4042ab3d845f892b728e22df05f6f8adc9fc7a454fa4de1ba` e preferência aplicada.
3. **Options/defaults:** nova lista `f3base_seo_entidade.servicos[].ofertas`, padrão vazio, com campos/condições em OFERTAS.md e schema instalado. Novos estados internos `f3base_release_1150`, trava 1150, `f3base_ofertas_evidencia_v2` e `f3base_redirects_evidencia_v2`; não são preferências de usuário. Removido uso da trava 1140 e encadeamento de versões anteriores; marcador concluído 1140 é somente a base admitida. Sem novo ajuste público para o prazo M38. Demais defaults 1.14.0 e valores explícitos preservados; dados antigos não são apagados.
4. **Migração:** snapshot privado JSON 0600, hash conferido, checkpoint e comparação condicional antes da troca da option. Fixture de atualização: duas ofertas antigas encontradas; uma convertida; uma ambígua preservada como pendência; `publico:false` e lista explícita vazia preservados. Interrupção após escrita retomada sem reconverter. Site-Teste: zero encontradas/convertidas/pendentes, configuração SEO sem alteração. Não extrapolar essa contagem para a frota. O backup real citado de ctooffice não foi fornecido.
5. **Contrato:** conteúdo **2.0.0 → 3.0.0**, nome da ability mantido. Escrita fecha `servicos[]` e ofertas, retira `oferta` antiga da entrada e exige enviar lista válida ao substituí-la. Leitura preserva dados extras existentes e os diagnostica. Mescla, simulação, erros/herança, perfil por ID, exceções, compacto/ID de prova e projeção `contrato_evidencias:2` possuem schemas/exemplos atualizados. Consumidores devem consultar o contrato instalado antes de escrever.

## Ensaios e limites da bancada

Conferências finais: {"regressoes": {"total": 78, "falhas": []}, "capi": {"total": 10, "falhas": []}, "bordas": {"total": 17, "falhas": []}, "llms": {"total": 23, "falhas": []}, "http": {"total": 22, "falhas": []}, "redirects-bordas": {"total": 21, "falhas": []}, "consentimento": {"total": 104, "falhas": []}, "transporte": {"total": 22, "falhas": []}, "cache-browser": {"total": 7, "falhas": []}, "instalacao": {"etapas": 10, "checks": 67}, "concorrencia": {"total": 9}, "site-teste-http": {"total": 7}}. Sintaxe: 112 PHP e 21 JS; sete assets recompostos com Terser fixado. A inspeção do ZIP comparou todos os bytes ao código final e ao manifesto. Instalação/repetição/rollback usaram binários reais, preservando leads capturados após a atualização. A versão 1.14.0 reproduziu perda de query inválida, perda de fbc no formulário e marca de teste ausente na fila comercial; a nova passou esses cenários.

O teste inicial de 410 tinha `para:""`, entrada recusada; corrigido para omitir destino e comprovado 410/`410 Gone` no reteste isolado. O teste de cache corrigiu expectativa de sucesso para 201 nos endpoints de criação. Esses ajustes são de fixture, não mudanças para mascarar falhas. Logs iniciais e retestes ficam nas fontes.

O cache envelhecido foi realmente servido pelo ramo PHP com 3900 s e token vencido, com corpo HTTP igual ao arquivo. O navegador reproduziu esses bytes e usou endpoints reais: token renovado antes dos POSTs de clique, formulário e análise, sem 403. Não se afirma HIT direto do navegador nessa prova combinada. `pageshow.persisted` foi um evento controlado; não equivale a comprovar elegibilidade real para bfcache em todos os navegadores.

## Matriz M38 e decisão

Lighthouse 13.5.0, Chrome 151.0.7922.34, WordPress 7.1.2, WP Super Cache 3.1.3. Sessenta medições com ordem rotacionada e cache de servidor aquecido. Gtag oficial foi servido localmente e os coletores ficaram locais; não mede a latência real do Google. O processo retomou após a medição 44. O aquecimento Playwright usa contexto separado, portanto não se afirma cache uniforme de navegador. Desktop: CPU 1×/10 Mbps/RTT 40 ms; mobile: CPU 4×/1,6 Mbps/RTT 150 ms, simulação Lighthouse.

Cada célula tem cinco repetições. LCP/TBT em ms, valores medianos [Q1–Q3]; requisição de análise em ms após início da navegação.

| Política | Google | Formato | Nota mediana | LCP | TBT | Primeiro envio |
|---|---|---|---:|---:|---:|---:|
| 10 | imediato | desktop | 87 | 961 [943–1020] | 295 [0–329] | 10405 |
| 10 | imediato | mobile | 75 | 4531 [4524–4658] | 214 [210–340] | 10250 |
| 10 | interacao_5s | desktop | 100 | 570 [563–744] | 0 [0–0] | 10188 |
| 10 | interacao_5s | mobile | 96 | 2333 [2333–2421] | 143 [141–234] | 10154 |
| 5 | imediato | desktop | 99 | 932 [926–962] | 31 [20–144] | 5559 |
| 5 | imediato | mobile | 83 | 3637 [2358–4513] | 264 [162–284] | 5242 |
| 5 | interacao_5s | desktop | 100 | 595 [574–760] | 0 [0–0] | 5163 |
| 5 | interacao_5s | mobile | 85 | 2412 [2270–3442] | 213 [184–293] | 5148 |
| base | imediato | desktop | 99 | 1030 [951–1902] | 0 [0–0] | 758 |
| base | imediato | mobile | 94 | 2432 [2418–4891] | 193 [178–196] | 880 |
| base | interacao_5s | desktop | 100 | 536 [535–1325] | 0 [0–0] | 718 |
| base | interacao_5s | mobile | 92 | 2373 [2363–2502] | 280 [189–280] | 767 |

Escolha: 5 s, com prazo absoluto e descarga antecipada. +10 s não demonstrou vantagem consistente entre modos e aumenta a latência. A baseline teve métricas melhores em algumas células; **não há demonstração de ganho causal de nota**. A versão adia rede inicial com prazo limitado e corrige postergação indefinida/recuperação, mantendo todos os eventos enviados confirmados no ensaio. A variabilidade e os limites impedem atribuir diferenças isoladas ao POST. O cenário contínuo e as saídas curtas foram exercitados no navegador; encerramento abrupto continua podendo perder itens sem confirmação.

## Site-Teste e PageSpeed externo

Aplicado somente em `fator3-teste-mcp-1.dreamhosters.com`. Antes: 167 arquivos conferidos contra o ZIP oficial 1.14.0, todos iguais. Depois: versão 1.15.0, instalação concluída com origem 1.14.0, arquivo principal/manifesto conferidos, SEO e política preservados byte a byte. Documentação canônica lida via MCP com SHA; acesso HTTP anônimo ao documento retornou 404 sem seu conteúdo.

Prova pública: `verified`, HIT real wp-cache; arquivo `.php` específico retornou HTTP 200, **zero bytes**. Sem cabeçalhos faltantes. Consulta compacta preserva revisão/escopos e recupera prova exata por ID sem novo HTTP. Resposta de consulta 1.14.0: 14.787 caracteres JSON; compacto 1.15.0 com prova: 935 (redução aproximada 93,7%). Saúde: 59.282 → 57.166 caracteres; a comparação é entre observações sucessivas e inclui mudanças normais de estado, não é um benchmark de payload idêntico.

Piso instalado: 76 condições conformes, zero divergências e uma indeterminada — navegação 23 publicada, sem prova de uso no cabeçalho. O diagnóstico não altera tema/navegação para fabricar conformidade. A configuração não foi regravada pelo avaliador.

Submissão sem JS: 303 → confirmação 200, meta/cabeçalho noindex/nofollow e no-store. Registro confirmado como método/formulário `formulario`/`contato`, classe `teste`, captura `aceito`, aviso `suprimido_teste`. CAPI permaneceu sem token/pixel e com apenas uma linha cancelada; sem fila pendente e sem envio comercial. Nenhum e-mail foi enviado pela homologação.

Foram concluídas **três análises mobile e três desktop em pagespeed.web.dev**, todas com nota de desempenho 100. Serviço declarou Lighthouse 13.5.0 e HeadlessChromium 153.0.8010.36: Lighthouse coincide com a bancada; navegador difere. Valores abaixo vêm dos links de calculadora do relatório, sem arredondamento da apresentação visual.

| Rodada | Formato | Nota | LCP (ms) | TBT (ms) | CLS | Relatório |
|---|---|---:|---:|---:|---:|---|
| 1 | mobile | 100 | 1255 | 4 | 0.0 | [PSI](https://pagespeed.web.dev/analysis/https-fator3-teste-mcp-1-dreamhosters-com/l2bv821ii4?form_factor=mobile) |
| 1 | desktop | 100 | 301 | 0 | 0.0 | [PSI](https://pagespeed.web.dev/analysis/https-fator3-teste-mcp-1-dreamhosters-com/l2bv821ii4?form_factor=desktop) |
| 2 | mobile | 100 | 1088 | 0 | 0.0 | [PSI](https://pagespeed.web.dev/analysis/https-fator3-teste-mcp-1-dreamhosters-com/3sqs2s475p?form_factor=mobile) |
| 2 | desktop | 100 | 328 | 0 | 0.0 | [PSI](https://pagespeed.web.dev/analysis/https-fator3-teste-mcp-1-dreamhosters-com/3sqs2s475p?form_factor=desktop) |
| 3 | mobile | 100 | 1263 | 0 | 0.0 | [PSI](https://pagespeed.web.dev/analysis/https-fator3-teste-mcp-1-dreamhosters-com/a5hvf8mfrh?form_factor=mobile) |
| 3 | desktop | 100 | 307 | 0 | 0.0 | [PSI](https://pagespeed.web.dev/analysis/https-fator3-teste-mcp-1-dreamhosters-com/a5hvf8mfrh?form_factor=desktop) |

mobile: LCP mediano 1255 ms; mínimo–máximo 1088–1263 ms. Nota mediana 100, amplitude 0; CLS 0.
desktop: LCP mediano 307 ms; mínimo–máximo 301–328 ms. Nota mediana 100, amplitude 0; CLS 0.

Isso confirma o estado atual do Site-Teste; não demonstra melhoria sobre uma medição PSI anterior nem garante a nota de outros sites. Sem dados CrUX disponíveis nessa consulta. Acessibilidade 96 observada no site, com apontamento de listas; nenhuma correção de tema foi incluída.

## Reversão e pendências externas

Retornar ao binário 1.14.0 foi ensaiado na base originalmente concluída em 1.14.0, inclusive leitura/captura após rollback. O binário antigo preserva mas não emite as novas ofertas e volta a ter os defeitos corrigidos de query/CAPI. Não é reversão funcional equivalente. Suspenda despacho externo se habilitado antes de reverter, preserve fila e capturas, use snapshot dirigido para a configuração se necessário; não restaure banco inteiro sobre novos contatos. Evidências v2 ficam separadas das antigas e não autorizam reutilização de `verified` obsoleto.

Aguardam operação própria: piloto do dono em korvena.net.br; acompanhamento de sete dias; listas reais/queries específicas da frota; backup de ofertas de ctooffice e decisão sobre `publico`; remoções de compensações de tema em Twinia/Conselar pelos respectivos projetos. Prova de preço no HTML não calcula CSS arbitrário externo. Test Events real é obrigatório se a CAPI for ativada; simulação não substitui recepção na Meta. Não foram alterados implantador, tema, CRM/Pipedrive, webhook ou documentos externos da frota. A causa histórica dos cinco 503 não foi demonstrada; testes induzidos comprovam o tratamento atual.

O pacote está entregue para o piloto do dono, com limites de aceite explicitados. Não houve instalação em korvena.net.br nem atualização geral da frota.
