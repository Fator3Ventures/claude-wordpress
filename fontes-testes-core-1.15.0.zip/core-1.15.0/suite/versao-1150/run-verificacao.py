from pathlib import Path
import subprocess,os,json,sys
root=Path(os.environ['F3BASE_TEST_WORKSPACE']);suite=Path(__file__).parent;php=str(root/'runtime1150/php');records=[]
commands=[['regressoes.php'],['capi.php'],['bordas.php'],['llms.php'],['http.php'],['redirects-bordas.php']]
for command in commands:
 run=subprocess.run([php,str(suite/command[0])],capture_output=True,text=True);text=run.stdout
 try:result=json.loads(text)
 except:result={'stdout':text[-3000:]}
 if run.stderr:result['stderr']=run.stderr[-2000:]
 (suite/'evidencias'/('exec-'+command[0]+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2));records.append({'teste':command[0],'exit':run.returncode,'falhas':result.get('falhas'),'total':result.get('total',len(result.get('checks',[])))});print(json.dumps(records[-1]),flush=True)
# Real concurrent DB operations and two installation paths.
for name in ['concorrencia.py','upgrade.py']:
 run=subprocess.run(['python3',str(suite/name)],capture_output=True,text=True);records.append({'teste':name,'exit':run.returncode});(suite/'evidencias'/('exec-'+name+'.log')).write_text(run.stdout+'\n'+run.stderr);print(json.dumps(records[-1]),flush=True)
(suite/'evidencias/execucoes.json').write_text(json.dumps(records,indent=2));sys.exit(any(x['exit'] for x in records))
