from pathlib import Path
import subprocess,os
root=Path(os.environ['F3BASE_TEST_WORKSPACE']);suite=Path(__file__).parent
subprocess.run([str(root/'runtime1150/php'),str(suite/'perf-preparar.php')],check=True)
subprocess.run(['node',str(suite/'performance.mjs')],check=True)
