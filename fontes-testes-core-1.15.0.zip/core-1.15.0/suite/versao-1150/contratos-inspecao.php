<?php
require __DIR__.'/bootstrap.php';
$errors=array();$profile=F3Base_Config_Perfil::distribuido();
foreach($profile['perfil']['condicoes'] as $c){if(empty($c['nome'])){continue;}$d=F3Base_Options::declaracao($c['nome']);if(!$d){$errors[]=$c['nome'];continue;}$s=F3Base_Config_Contrato::schema_valor($d);foreach($c['campo']??array() as $key){if($key==='*'){$s=$s['items']??array();}else{$s=$s['properties'][$key]??array();}if(!$s){$errors[]=$c['nome'].'.'.implode('.',$c['campo']);break;}}}
echo json_encode(array('profile_errors'=>$errors,'origem'=>F3Base_Instalacao::origem(),'servicos'=>F3Base_Config_Contrato::schema_entrada(F3Base_Options::declaracao('f3base_seo_entidade'))['properties']['servicos'],'catalogo'=>array_map(static fn($n)=>array('nome'=>$n,'padrao'=>F3Base_Options::declaracao($n)['padrao']??null),array('f3base_acessos','f3base_sessao','f3base_llms','f3base_cabecalhos'))),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
