from pathlib import Path
import subprocess,os
s=Path(__file__).parent;r=Path(os.environ['F3BASE_TEST_WORKSPACE'])
subprocess.run([str(r/'runtime1150/php'),str(s/'cache-envelhecido.php')],check=True)
subprocess.run(['node',str(s/'cache-browser.cjs')],check=True)
