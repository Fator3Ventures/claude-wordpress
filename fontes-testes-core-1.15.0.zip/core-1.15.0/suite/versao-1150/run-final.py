from pathlib import Path
import subprocess,os,json,sys
root=Path(os.environ['F3BASE_TEST_WORKSPACE']);suite=Path(__file__).parent;php=str(root/'runtime1150/php');results=[]
for name,cmd in [('redirects-bordas',[php,str(suite/'redirects-bordas.php')]),('cache-browser',['python3',str(suite/'cache-browser.py')]),('contratos',[php,str(suite/'contratos-inspecao.php')])]:
 r=subprocess.run(cmd,capture_output=True,text=True);(suite/'evidencias'/('final-'+name+'.log')).write_text(r.stdout+'\n'+r.stderr);results.append({'teste':name,'exit':r.returncode});print(json.dumps(results[-1]),flush=True)
r=subprocess.run([php,str(suite/'documentar-catalogo.php')],capture_output=True,text=True)
if r.returncode==0: (root/'work/core-1.15.0/fontes/plugin/docs/REFERENCIA-CATALOGO.md').write_text(r.stdout)
else:print(r.stderr)
results.append({'teste':'catalogo','exit':r.returncode});(suite/'evidencias/final.json').write_text(json.dumps(results));sys.exit(any(r['exit'] for r in results))
