<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
add_filter('pre_wp_mail',static fn()=>true);
update_option('blog_public','1');
update_option('permalink_structure','/%postname%/');flush_rewrite_rules(false);
$form=['id'=>'fixture-1150','titulo'=>'Contato da bancada','ligado'=>true,'regime'=>'registro','campos'=>[['nome'=>'nome','rotulo'=>'Nome','tipo'=>'text','papel'=>'nome','obrigatorio'=>true],['nome'=>'email','rotulo'=>'E-mail','tipo'=>'email','papel'=>'email','obrigatorio'=>true]],'destinatarios'=>[]];
$decl=F3Base_Options::declaracao('f3base_formularios');$form=F3Base_Options::sanitizar('f3base_formularios',[$form]);update_option('f3base_formularios',$form);update_option('f3base_contato',array_replace(F3Base_Options::ler('f3base_contato'),['email_leads'=>[],'avisar_por_clique'=>false,'avisar_por_formulario'=>false]));
update_option('f3base_consentimento',array_replace(F3Base_Options::ler('f3base_consentimento'),['modo'=>'legado']));
$ids=[];foreach(['bancada-1150'=>'<!-- wp:heading --><h2>Serviços da bancada</h2><!-- /wp:heading --><!-- wp:paragraph --><p>'.str_repeat('Conteúdo público de teste com renderização real. ',50).'</p><!-- /wp:paragraph --><!-- wp:f3base/formulario {"id":"fixture-1150"} /-->','destino-1150'=>'<!-- wp:paragraph --><p>Destino público para comprovar redirects.</p><!-- /wp:paragraph -->'] as $slug=>$content){$p=get_page_by_path($slug);$ids[$slug]=wp_insert_post(['ID'=>$p?$p->ID:0,'post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>ucwords(str_replace('-',' ',$slug)),'post_content'=>$content]);}
update_option('show_on_front','page');update_option('page_on_front',$ids['bancada-1150']);
// Local fixture only: avoid any mail and allow loopback HTTP tests in this isolated lab.
$mu=WP_CONTENT_DIR.'/mu-plugins';wp_mkdir_p($mu);file_put_contents($mu.'/fixture-1150.php',"<?php\nadd_filter('pre_wp_mail',static fn()=>true);\nadd_filter('http_request_host_is_external',static fn(\$external,\$host)=>\$host==='127.0.0.1'?true:\$external,10,2);\n");
wp_mkdir_p(WP_CONTENT_DIR.'/cache');$source=WP_CONTENT_DIR.'/plugins/wp-super-cache/';$cfg=file_get_contents($source.'wp-cache-config-sample.php');
$cfg=str_replace('?>','',$cfg);$cfg.="\n\$cache_enabled=true;\n\$super_cache_enabled=false;\n\$wpsc_save_headers=1;\n\$cache_max_time=3600;\n\$wp_cache_not_logged_in=true;\n\$wpsc_ignore_tracking_parameters=true;\n\$wpsc_tracking_parameters=".var_export(F3Base_Cache_Pagina::parametros_rastreio(),true).";\n\$cache_path=".var_export(WP_CONTENT_DIR.'/cache/',true).";\n\$cache_rejected_uri=".var_export(F3Base_Cache_Pagina::exclusoes(),true).";\n";
file_put_contents(WP_CONTENT_DIR.'/wp-cache-config.php',$cfg);copy($source.'advanced-cache.php',WP_CONTENT_DIR.'/advanced-cache.php');$config=ABSPATH.'wp-config.php';$text=file_get_contents($config);if(!str_contains($text,"define('WP_CACHE'")){$text=str_replace('<?php',"<?php\ndefine('WP_CACHE',true);define('WPCACHEHOME',".var_export($source,true).");",$text);file_put_contents($config,$text);}
$r=activate_plugin('wp-super-cache/wp-cache.php');
file_put_contents(ABSPATH.'.htaccess',"RewriteEngine On\nRewriteBase /\nRewriteCond %{REQUEST_FILENAME} !-f\nRewriteCond %{REQUEST_FILENAME} !-d\nRewriteRule . /index.php [L]\n");
echo json_encode(['paginas'=>$ids,'cache_ativado'=>!is_wp_error($r),'erro_cache'=>is_wp_error($r)?$r->get_error_message():null,'formulario'=>$form],JSON_UNESCAPED_UNICODE)."\n";
