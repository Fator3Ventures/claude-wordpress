from pathlib import Path
import json,statistics,datetime,collections
base=Path(__file__).parent/'evidencias/performance'
def headers(h):return [{'name':str(k),'value':str(v)} for k,v in (h or {}).items()]
# Derive HAR methods, timestamps and responses from actual DevTools events.
for file in base.glob('*.devtools.json'):
 records={};entries=[]
 for event in json.loads(file.read_text()):
  p=event.get('params',{});rid=p.get('requestId');method=event.get('method')
  if method=='Network.requestWillBeSent':
   if rid in records and 'redirectResponse' in p:
    old=records.pop(rid);old['response']=p['redirectResponse'];old['end']=p['timestamp'];entries.append(old)
   records[rid]={'request':p['request'],'wallTime':p['wallTime'],'start':p['timestamp']}
  elif rid in records:
   if method=='Network.responseReceived':records[rid].update(response=p['response'],responseTime=p['timestamp'])
   elif method in ('Network.loadingFinished','Network.loadingFailed'):
    r=records.pop(rid);r.update(end=p['timestamp'],bytes=p.get('encodedDataLength',-1),error=p.get('errorText'));entries.append(r)
 entries.extend(records.values());har=[]
 for r in entries:
  q=r['request'];s=r.get('response',{});total=max(0,(r.get('end',r['start'])-r['start'])*1000);wait=max(0,min(total,(r.get('responseTime',r.get('end',r['start']))-r['start'])*1000))
  request={'method':q['method'],'url':q['url'],'httpVersion':s.get('protocol',''),'headers':headers(q.get('headers')),'queryString':[],'cookies':[],'headersSize':-1,'bodySize':len(q.get('postData','').encode()) if q.get('postData') else -1}
  if q.get('postData'):request['postData']={'mimeType':q.get('headers',{}).get('Content-Type',''),'text':q['postData']}
  har.append({'startedDateTime':datetime.datetime.fromtimestamp(r['wallTime'],datetime.timezone.utc).isoformat(),'time':total,'request':request,'response':{'status':s.get('status',0),'statusText':s.get('statusText',''),'httpVersion':s.get('protocol',''),'headers':headers(s.get('headers')),'cookies':[],'content':{'size':-1,'mimeType':s.get('mimeType','')},'redirectURL':s.get('headers',{}).get('Location',''),'headersSize':-1,'bodySize':r.get('bytes',-1)},'cache':{},'timings':{'send':0,'wait':wait,'receive':total-wait},'_error':r.get('error'),'_note':'Derivado de DevTools; tamanhos de corpo descomprimido e cookies não capturados.'})
 file.with_name(file.name.replace('.devtools.json','.har.json')).write_text(json.dumps({'log':{'version':'1.2','creator':{'name':'F3Base DevTools export','version':'1.15.0'},'entries':har}},ensure_ascii=False))
m=json.loads((base/'matriz.json').read_text());groups=collections.defaultdict(list)
for r in m['rows']:groups[(r['arm'],r['google'],r['formFactor'])].append(r)
out=[]
for key,rows in sorted(groups.items()):
 item={'arm':key[0],'google':key[1],'formFactor':key[2],'n':len(rows),'runtimeErrors':sum(bool(r['runtimeError']) for r in rows),'eventos':sum(r['analysisEvents'] for r in rows),'confirmados':sum(r['analysisConfirmed'] for r in rows),'statuses':sorted({s for r in rows for s in r['analysisStatuses']})}
 for metric in ('score','lcp','cls','tbt','firstAnalysisMs','bytes','requests'):
  vals=sorted(r[metric] for r in rows if r[metric] is not None);quartiles=statistics.quantiles(vals,n=4,method='inclusive') if len(vals)>1 else vals*3
  item[metric]={'mediana':statistics.median(vals),'q1':quartiles[0],'q3':quartiles[2],'min':min(vals),'max':max(vals)}
 out.append(item)
(base/'resumo.json').write_text(json.dumps({'environment':m['environment'],'execucoes':len(m['rows']),'retomada':'Processo reiniciado após medição 44; mesma fixture/cache de servidor, novo navegador.','grupos':out},ensure_ascii=False,indent=2))
print(json.dumps({'execucoes':len(m['rows']),'grupos':len(groups)}))
