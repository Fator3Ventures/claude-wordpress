"""Only supported paths: clean install and real 1.14.0 -> 1.15.0. Local disposable DBs."""
from pathlib import Path
import os,subprocess,json,shutil,uuid,re
root=Path(os.environ['F3BASE_TEST_WORKSPACE']);base=Path(os.environ['F3BASE_SITE']);php=root/'runtime1150/php';suite=Path(__file__).parent;out=[]
for origin in ['nova','1.14.0']:
 target=root/'lab1150'/('upgrade-'+origin);target.mkdir(exist_ok=True)
 for p in base.iterdir():
  if p.name in ['wp-config.php','wp-content','llms.txt','robots.txt','.htaccess'] or p.name.startswith('.'):continue
  dest=target/p.name
  if not dest.exists():dest.symlink_to(p,target_is_directory=p.is_dir())
 (target/'.f3base-bancada-110').touch();wc=target/'wp-content';(wc/'plugins').mkdir(parents=True,exist_ok=True);(wc/'mu-plugins').mkdir(exist_ok=True)
 (wc/'mu-plugins/fixture.php').write_text("<?php add_filter('pre_wp_mail',static fn()=>true); add_filter('pre_http_request',static fn()=>new WP_Error('fixture_sem_rede','Integrações externas bloqueadas pela bancada')); ")
 if not (wc/'themes').exists():(wc/'themes').symlink_to(base/'wp-content/themes')
 db='f3base_upgrade1150_'+uuid.uuid4().hex[:10];config=(base/'wp-config.php').read_text().replace("'f3base1150'",repr(db));config=re.sub(r"define\('WP_CACHE',true\);define\('WPCACHEHOME',[^;]+;", "define('WP_CACHE',false);",config);(target/'wp-config.php').write_text(config)
 mysql=[str(root/'runtime1150/root/usr/bin/mysql'),'--no-defaults','--protocol=TCP','-h','127.0.0.1','-P','3316','-u','root'];subprocess.run(mysql+['-e',f'CREATE DATABASE {db} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;'],check=True)
 link=wc/'plugins/base-site-core-fator3'
 def install(version):
  if link.exists():shutil.rmtree(link)
  source=root/'review-1140/base-site-core-fator3' if version=='1.14.0' else root/'work/core-1.15.0/fontes/plugin';shutil.copytree(source,link)
 install('1.15.0' if origin=='nova' else origin);env=os.environ|{'F3BASE_SITE':str(target),'F3BASE_ORIGEM':origin}
 steps=['instalar','semear','atualizar','repetir']+(['reverter','retornar'] if origin=='1.14.0' else [])
 for step in steps:
  if step in ['atualizar','retornar']:install('1.15.0')
  if step=='reverter':install('1.14.0')
  run=subprocess.run([str(php),str(suite/'upgrade.php'),step],env=env,capture_output=True,text=True)
  try:result=json.loads(run.stdout)
  except:result={'stdout':run.stdout[-3000:],'stderr':run.stderr[-1000:]}
  out.append({'origem':origin,'passo':step,'exit':run.returncode,'resultado':result});print(origin,step,run.returncode,result.get('falhas',result))
  if run.returncode:break
(suite/'evidencias/upgrade.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(any(x['exit'] for x in out))
