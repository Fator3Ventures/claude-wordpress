"""Isolated Apache/mod_php fixture: invoked inside lab.py's MySQL namespace."""
from pathlib import Path
import os,sys,subprocess,time,urllib.request,uuid
ROOT=Path(os.environ.get('F3BASE_TEST_WORKSPACE',str(Path(__file__).resolve().parents[4]))); LAB=ROOT/'lab1150'; RT=ROOT/'runtime1150'; AP=LAB/'apache';AP.mkdir(exist_ok=True)
site=Path(os.environ['F3BASE_SITE']);env=os.environ.copy();env['F3BASE_LAB_HTTP']='1';env['PHP_INI_SCAN_DIR']='';env['PHPRC']=str(AP/'php.ini')
mods=['mpm_prefork','authz_core','authz_host','mime','dir','autoindex','rewrite','headers','expires','filter','deflate','env']
phpmods=['mysqlnd','mysqli','pdo','pdo_mysql','mbstring','ctype','dom','xml','xmlreader','xmlwriter','simplexml','tokenizer','fileinfo','curl']
(AP/'php.ini').write_text('extension_dir="'+str(RT/'root/usr/lib/php/20230831')+'"\n'+''.join('extension='+x+'\n' for x in phpmods)+'date.timezone=UTC\ndisplay_errors=Off\nlog_errors=On\nmemory_limit=256M\n')
config='ServerRoot "'+str(AP)+'"\nPidFile "'+str(AP/('apache-'+uuid.uuid4().hex+'.pid'))+'"\nListen 127.0.0.1:8150\nServerName 127.0.0.1\nUser www-data\nGroup www-data\nServerLimit 8\nStartServers 2\nMinSpareServers 2\nMaxSpareServers 4\nMaxRequestWorkers 8\nMutex pthread default\n'
config+=''.join('LoadModule '+m+'_module "'+str(RT/'root/usr/lib/apache2/modules'/('mod_'+m+'.so'))+'"\n' for m in mods)
config+='LoadModule php_module "'+str(RT/'root/usr/lib/apache2/modules/libphp8.3.so')+'"\nPHPIniDir "'+str(AP)+'"\n'
config+='TypesConfig /etc/mime.types\nDirectoryIndex index.php index.html\nDocumentRoot "'+str(site)+'"\nErrorLog "'+str(AP/'error.log')+'"\nLogLevel warn\n'
config+='<Directory "'+str(ROOT)+'">\nAllowOverride All\nRequire all granted\nOptions FollowSymLinks Indexes\n</Directory>\n<FilesMatch "\\.php$">\nSetHandler application/x-httpd-php\n</FilesMatch>\nAddOutputFilterByType DEFLATE text/plain text/html application/json\nSetEnv F3BASE_LAB_HTTP 1\n'
if os.environ.get('F3BASE_APACHE_DENY_FORCE')=='1':config=config.replace('AllowOverride All','AllowOverride None\nAllowOverrideList RewriteEngine RewriteCond RewriteRule Require Header ExpiresActive')
(AP/'httpd.conf').write_text(config)
# Preserve the fixture's root rules. Managed-block tests use the real file and restore it.
ht=site/'.htaccess';before=ht.read_bytes() if ht.exists() else None
if not ht.exists():ht.write_text('# Fixture WordPress\nRewriteEngine On\nRewriteCond %{REQUEST_FILENAME} !-f\nRewriteCond %{REQUEST_FILENAME} !-d\nRewriteRule . /index.php [L]\n')
cmd=[str(RT/'root/usr/sbin/apache2'),'-f',str(AP/'httpd.conf'),'-DFOREGROUND']
log=open(AP/'startup.log','w');proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=log,start_new_session=True)
try:
 for _ in range(60):
  if proc.poll() is not None:raise RuntimeError((AP/'startup.log').read_text())
  try:
   with urllib.request.urlopen('http://127.0.0.1:8150/wp-login.php',timeout=1) as r:
    if r.status==200:break
  except Exception:time.sleep(.1)
 else:raise RuntimeError('Apache unavailable: '+(AP/'error.log').read_text()[-2000:])
 run=[str(RT/'php') if x=='php' else x for x in sys.argv[1:]];result=subprocess.run(run,env=env);sys.exit(result.returncode)
finally:
 proc.terminate()
 try:proc.wait(timeout=10)
 except subprocess.TimeoutExpired:proc.kill();proc.wait()
 log.close()
 if before is None:ht.unlink(missing_ok=True)
 else:ht.write_bytes(before)
