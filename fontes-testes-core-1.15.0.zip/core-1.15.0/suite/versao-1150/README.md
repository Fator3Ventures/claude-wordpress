# Bancada da release 1.15.0

Execute somente em WordPress descartável. Os scripts PHP exigem o marcador `.f3base-bancada-110`; os ensaios de atualização também exigem caminho `lab1150/upgrade-*`. Nenhum comando desta suíte deve apontar para um site de produção.

Ambiente observado: PHP 8.3.6 (mysqli/curl/DOM/mbstring), MySQL 8.0.46, WordPress 7.1.2, WP Super Cache 3.1.3, Node 22+, Playwright, Chrome Headless Shell 151.0.7922.34 e Lighthouse 13.5.0. Terser está fixado no lock de `../build-assets/`. Os binários e bancos descartáveis não integram o instalador ou este pacote de fontes.

Defina `F3BASE_TEST_WORKSPACE` com a raiz de uma bancada contendo `runtime1150/php`, MySQL em `runtime1150/root/usr`, Chromium em `runtime1150/headless`, WordPress em `lab1150/wordpress` e a cópia original 1.14.0 em `review-1140/base-site-core-fator3`. O código em teste fica em `work/core-1.15.0/fontes/plugin`. Instale o plugin nessa cópia descartável. Configure MySQL local porta 3316, WordPress em `http://127.0.0.1:8150` e o marcador acima. `preparar.php` instala/ativa; `http-preparar.php` cria conteúdo/formulário sintético e configura o cache. Este último grava somente o `.htaccess` da bancada e bloqueia e-mails externos por MU-plugin.

Exemplo de execução, a partir da raiz de fontes:

```sh
python3 suite/versao-1150/lab.py python3 suite/versao-1150/http-server.py python3 suite/versao-1150/run-verificacao.py
node suite/versao-1150/transporte.cjs
node suite/versao-1150/consentimento.cjs
python3 suite/versao-1150/lab.py python3 suite/versao-1150/http-server.py python3 suite/versao-1150/cache-browser.py
node suite/build-assets/build.cjs fontes/plugin --check
python3 montar-release.py --saida dist
```

`lab.py` inicia MySQL e encerra no final. `http-server.py` usa oito workers do servidor PHP. Não executar duas instâncias no mesmo datadir. O ensaio Apache foi impedido pelo mapeamento de usuários do ambiente; não há evidência de HTTP Apache local nesta release. O arquivo `apache.py` é uma alternativa de infraestrutura, sem resultado de aceite.

## Desempenho

`run-perf.py` prepara HTML real de HIT do WP Super Cache. `performance.mjs` conserva um checkpoint em `evidencias/performance/matriz.json`: remove-lo inicia nova matriz; mantê-lo retoma somente nomes ausentes. São 3 políticas × 2 modos Google × 2 viewports × 5 repetições, em ordem rotacionada. Rode sem testes concorrentes no navegador/banco. `performance-resumir.py` calcula medianas e quartis e produz HAR derivados dos eventos DevTools (campos não capturados são sinalizados).

O gtag oficial capturado deve estar em `lab1150/downloads/gtag-fixture.js`; Lighthouse em `lab1150/downloads/node_modules/lighthouse`. DNS externo é bloqueado no navegador e os coletores são locais. Portanto não se mede a latência real do Google nem se reproduz um resultado PSI. O HTML é público por HTTP na bancada, com noindex para a fixture; não significa que o site descartável seja indexável. O cache de servidor é aquecido. O aquecimento Playwright usa contexto separado do Lighthouse, cujo armazenamento é preservado dentro de cada processo; não se afirma cache uniforme de navegador.

Consulte `RELATORIO-1.15.0.md` e `fontes/plugin/docs/VALIDACAO.md` para resultados finais e limites. Evidências são de dados sintéticos, salvo leituras/observações do Site-Teste identificadas pelo nome do arquivo. Nenhuma evidência daqui comprova alteração de tema, serviços comerciais ou homologação da frota.
