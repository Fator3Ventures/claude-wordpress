from pathlib import Path
import subprocess,os
s=Path(__file__).parent;r=Path(os.environ['F3BASE_TEST_WORKSPACE'])
subprocess.run([str(r/'runtime1150/php'),str(s/'redirect410.php')],check=True)
subprocess.run(['python3',str(s/'cache-browser.py')],check=True)
