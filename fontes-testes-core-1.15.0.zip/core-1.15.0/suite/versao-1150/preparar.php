<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110'))exit(2);
$_SERVER['HTTP_HOST']='127.0.0.1:8150';$_SERVER['SERVER_NAME']='127.0.0.1';$_SERVER['REMOTE_ADDR']='192.0.2.114';$_SERVER['REQUEST_URI']='/';define('WP_INSTALLING',true);require $site.'/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
if(!is_blog_installed()){wp_install('F3 Base 1.15 Bancada','fixture1150','fixture@example.test',false,'','fixture-1150-only');}
wp_set_current_user(1);$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');if(is_wp_error($r)){echo $r->get_error_message();exit(1);}global $wpdb;echo json_encode(['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'mysql'=>$wpdb->get_var('SELECT VERSION()'),'activated'=>true])."\n";
