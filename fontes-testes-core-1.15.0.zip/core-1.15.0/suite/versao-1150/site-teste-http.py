from pathlib import Path
import urllib.request,urllib.parse,urllib.error,http.cookiejar,json,re,time
from html.parser import HTMLParser
root='https://fator3-teste-mcp-1.dreamhosters.com';out=Path(__file__).parent/'evidencias';checks={};evidence={}
class Inputs(HTMLParser):
 def __init__(self):super().__init__();self.forms=[];self.f=None
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='form':self.f={'attrs':a,'inputs':{}};self.forms.append(self.f)
  elif tag=='input' and self.f is not None and a.get('name'):self.f['inputs'][a['name']]=a.get('value','')
 def handle_endtag(self,tag):
  if tag=='form':self.f=None
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):return None
op=urllib.request.build_opener(NoRedirect(),urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def request(path,data=None):
 q=urllib.request.Request(path if path.startswith('http') else root+path,data=urllib.parse.urlencode(data).encode() if data is not None else None,headers={'User-Agent':'F3Base release verification 1.15.0','X-F3Base-Teste':'1'})
 try:r=op.open(q,timeout=35)
 except urllib.error.HTTPError as e:r=e
 body=r.read();return r.code,dict(r.headers),body
code,h,b=request('/contato/');parser=Inputs();parser.feed(b.decode());form=next(f for f in parser.forms if 'data-f3base-formulario' in f['attrs']);data=form['inputs']|{'contexto_teste':'1','campos[seu-nome]':'Teste release 1.15.0 (sem JS)','campos[seu-email]':'fixture-1150@example.test','campos[sua-mensagem]':'Homologação autorizada do pacote; tráfego de teste, sem e-mails ou integrações comerciais.'}
code,h,b=request(form['attrs']['action'],data);loc=h.get('Location',h.get('location',''));checks['post_303']=code==303;checks['url_sem_contato']='fixture-' not in loc and 'f3base_confirmacao' in loc;evidence['post']={'status':code,'location':loc}
if loc:
 code,h,b=request(loc);text=b.decode();meta=re.findall(r'<meta\b[^>]*name=[\"\']robots[\"\'][^>]*>',text,re.I);checks['confirmacao_200']=code==200;checks['sucesso']='registrad' in text.lower() or 'mensagem enviada' in text.lower();checks['robots_noindex_nofollow']=any('noindex' in x and 'nofollow' in x for x in meta) and h.get('X-Robots-Tag',h.get('x-robots-tag','')).lower()=='noindex, nofollow';checks['sem_cache']='no-store' in h.get('Cache-Control',h.get('cache-control',''));evidence['confirmacao']={'status':code,'headers':h,'robots':meta,'corpo_bytes':len(b),'texto_final':re.sub('<[^>]+>','',text)[-350:]}
code,h,b=request('/wp-content/plugins/base-site-core-fator3/docs/AGENTES-1.15.md');checks['docs_http_bloqueado']=code in (403,404);evidence['docs']={'status':code,'bytes':len(b)}
result={'em':time.time(),'checks':checks,'evidencias':evidence};(out/'site-teste-http.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False));raise SystemExit(not all(checks.values()))
