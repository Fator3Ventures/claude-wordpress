<?php
require __DIR__.'/bootstrap.php';
update_option('blog_public',1);wp_clear_scheduled_hook('wp_cache_gc');if(function_exists('wp_cache_clear_cache')){wp_cache_clear_cache();}
for($i=0;$i<3;$i++){$r=wp_remote_get(home_url('/'),['headers'=>['X-F3Base-Teste'=>'1','Accept-Encoding'=>'identity','Accept'=>'text/html']]);}
$body=wp_remote_retrieve_body($r);$base=F3Base_Publicacao_Sonda::base_cache();$paths=glob($base.'/wp-cache-*.php');$path='';foreach($paths as $p){$raw=file_get_contents($p);if(str_contains($raw,'f3baseAnaliseDados')){$path=$p;break;}}
if(!$path){fwrite(STDERR,'Cache real da home não encontrado');exit(1);}
$old=time()-3900;$expiry=$old+F3Base_Modulo_Endpoint_Leads::ttl_token();$sign=new ReflectionMethod(F3Base_Modulo_Endpoint_Leads::class,'assinar');$token=$expiry.'.'.$sign->invoke(null,$expiry.'|'.F3Base_Modulo_Endpoint_Leads::escopo_do_token(''));
$raw=preg_replace('/[0-9]{10}\.[a-f0-9]{64}/',$token,$raw);
$raw=str_replace('</body>','<a class="f3base-acao-contato" id="cta-cache-antigo" href="'.esc_url(home_url('/destino-1150/')).'" target="_blank">Falar com a equipe</a></body>',$raw);file_put_contents($path,$raw);touch($path,$old);clearstatcache(true,$path);
$r=wp_remote_get(home_url('/'),['headers'=>['X-F3Base-Teste'=>'1','Accept-Encoding'=>'identity','Accept'=>'text/html']]);$delivered=wp_remote_retrieve_body($r);file_put_contents(__DIR__.'/evidencias/cache-envelhecido.html',$delivered);$hit=F3Base_Cache_Pagina::hit_comprovado($r,$delivered);$prop=new ReflectionProperty(F3Base_Cache_Pagina::class,'idade_hit');$age=$prop->getValue();
$out=['cache_php_real'=>basename($path),'assinado_em_controlado'=>$old,'expiracao'=>$expiry,'agora'=>time(),'mtime'=>filemtime($path),'hit'=>$hit,'token_expirado_servido'=>str_contains($delivered,$token),'idade_comprovada'=>$age,'ttl'=>F3Base_Cache_Pagina::ttl()];
file_put_contents(__DIR__.'/evidencias/cache-envelhecido.json',json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo json_encode($out);exit($hit&&$out['token_expirado_servido']&&time()-filemtime($path)>3600?0:1);
