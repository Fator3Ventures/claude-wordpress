<?php
use Fator3\McpGoogle\{Admin,Options};
if (wp_parse_url(home_url(),PHP_URL_HOST)!=='127.0.0.1') throw new RuntimeException('Loopback required');
require __DIR__.'/rpc.php';
wp_set_current_user(1);
wp_get_abilities();
$credential=rpc_identityLab();
$GLOBALS['auth']=$credential['auth'];
$results=array();
try {
    $r=rpcLab('google/status');
    if (empty($r['success']) || $r['plugin_version']!=='0.40.0' || ($r['abilities_registered']['total']??null)!==311) throw new RuntimeException('Status');
    $results['abilities_registered']=$r['abilities_registered'];
    $r=rpcLab('google/integration-status',array('compact'=>true));
    if (empty($r['read_success'])) throw new RuntimeException('Integration');
    $results['read_success']=true;
    $r=rpcLab('google/storage-status');
    if (empty($r['storage']['ready'])) throw new RuntimeException('Storage');
    $results['storage_ready']=true;
    $user=wp_insert_user(array('user_login'=>'lab40-sub','user_pass'=>wp_generate_password(),'role'=>'subscriber'));
    if (is_wp_error($user)) throw new RuntimeException('Subscriber');
    wp_set_current_user($user);
    foreach (array('google/audit','google/list-jobs','google/conversion-delivery-status','google/configure-local') as $id) {
        $ability=wp_get_ability($id);
        if (!$ability || $ability->check_permissions(array())===true) throw new RuntimeException($id);
        $results['denied'][]=$id;
    }
    ob_start(); Admin::render(); $body=ob_get_clean();
    if (Options::authorized() || $body!=='') throw new RuntimeException('Subscriber can view panel');
    $results['subscriber_panel_denied']=true;
} finally {
    wp_set_current_user(1);
    WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
    if (isset($user) && is_int($user)) wp_delete_user($user);
}
file_put_contents(getenv('F3_ACCESS40'),wp_json_encode($results,JSON_PRETTY_PRINT));
