# Contratos

Este documento define as interfaces públicas do plugin: transportes, envelope, códigos de erro, permissões, revisões, idempotência, continuações, contratos de relatório, SDKs locais e a leitura da documentação. O catálogo das 47 operações, com parâmetros e efeitos, está em REFERENCE.md. Os schemas exatos estão em input-schemas.json e output-schema.json.

## Transportes

| Transporte | Forma |
|---|---|
| REST | `POST /wp-json/f3-meta/v1/<operação>`, corpo JSON. Sessão de administrador com nonce REST, ou credencial aceita pelo WordPress. Respostas com `Cache-Control: private, no-store`. |
| Abilities API | Habilidades `meta/<operação>` na categoria `meta`, com rótulos e descrições de abilities-pt-br.json. |
| MCP | Pelo Fator3 MCP, que publica as mesmas habilidades. O plugin aplica também a política do transporte (perfil e operações autorizadas). |
| Painel | Ferramentas → Fator3 MCP Meta; usa a mesma REST. |

Na REST, `not_authorized` responde HTTP 403. Os demais resultados, de sucesso ou de falha, respondem HTTP 200 com o envelope abaixo.

Os metadados de cada habilidade trazem `mode`, `local_effect`, `remote_effect` e as anotações `readonly`, `destructive` e `idempotent`. SPECIFICATION.md explica o significado; REFERENCE.md lista os valores por operação.

## Envelope

Sucesso:

```json
{"success":true,"code":"ok","provider":"wp-mcp-meta-fator3","version":"…","data":{}}
```

Falha:

```json
{"success":false,"code":"revision_conflict","error_code":"revision_conflict","provider":"wp-mcp-meta-fator3","message":"…","conflict":true,"retryable":false,"data":null,"details":{}}
```

- `message` é em português e nunca reproduz o corpo bruto da Meta, URL ou token.
- `conflict` é `true` só para `revision_conflict`.
- `retryable` é `true` só para `rate_limited`, `busy`, `upstream_error` e `budget_exhausted`. Ele indica que repetir pode dar certo; não prova que a primeira tentativa não teve efeito.
- `avisos` aparece nas respostas de `meta/save-connection`, `meta/rotate-token` e `meta/switch-identity` (CONFIGURATION.md).
- `audit_warning=audit_write_failed` indica que a linha de auditoria não foi gravada; o resultado da operação vale mesmo assim.
- Se `data` passar de 900.000 bytes de JSON, a resposta é substituída por `response_limit`.

## Validação de entrada

Todos os objetos de entrada são fechados: parâmetro desconhecido é recusado. IDs remotos são strings numéricas, nunca números. Datas usam `AAAA-MM-DD`.

Uma recusa de schema devolve `invalid_input` com uma mensagem que nomeia o parâmetro e `details` com:

| Campo | Conteúdo |
|---|---|
| `schema` | Operação cujo schema recusou a entrada |
| `validation_code` | Código de validação do WordPress |
| `field` | Parâmetro recusado, em notação de ponto para objetos aninhados (`query.report`); vazio quando não há parâmetro identificável |
| `problem` | `unknown_parameter`, `missing_required`, `invalid_type`, `invalid_value`, `invalid_format`, `out_of_range` ou `invalid` |

O valor enviado nunca aparece na resposta. Validações posteriores ao schema (por exemplo, “Informe as duas datas.”) mantêm suas mensagens próprias.

## Códigos de erro

| Código | Causa | Ação |
|---|---|---|
| `invalid_input` | Entrada fora do schema ou regra local | Corrigir o parâmetro indicado em `details` |
| `not_authorized` | Sem `manage_options`, política do transporte recusou, concessão revogada; com `auth_scope=connection`, a Meta também recusou em `/me` | Restaurar o acesso; se for a conexão, renovar o token ou as permissões do aplicativo |
| `revision_conflict` | Revisão enviada diferente da atual, ou registro alterado durante a operação | Reler e repetir com a revisão atual |
| `idempotency_conflict` | Chave já usada para outra intenção | Conferir o recibo da chave anterior; usar outra chave só para outra intenção |
| `busy` | Outra operação segura a mesma trava | Repetir depois |
| `not_found`, `not_configured` | Registro, coleta, documento ou conexão inexistente | Conferir o identificador |
| `connection_paused` | Conexão com `enabled=false` | Reativar a conexão, se for o caso |
| `connection_limit`, `schedule_limit` | Limite de 100 conexões ou 100 agendas | Remover ou reaproveitar registros |
| `asset_access_denied` | Ativo não selecionado na conexão, ou recusado pela Meta | Conferir a seleção e as permissões do ativo |
| `token_expired`, `token_rejected` | Token vencido ou recusado pela Meta | Renovar a credencial |
| `credential_revalidation_required` | Credencial mudou sem validação | Validar a conexão de novo |
| `invalid_credential_input`, `invalid_token_format`, `app_proof_required` | Credencial vazia, longa demais, com caractere de controle, ou sem par de aplicativo | Corrigir o campo indicado |
| `credential_app_mismatch`, `credential_identity_mismatch`, `credential_scopes_reduced` | Token de outro aplicativo, outra identidade ou com menos escopos | Gerar o token correto, ou usar a troca de identidade |
| `confirmation_mismatch` | Algo mudou entre a simulação e a execução da troca de identidade | Simular de novo |
| `validation_limit` | Mais de 12 ativos para conferir numa conexão | Dividir a seleção |
| `ads_read_required` | Token sem `ads_read` para a conta de anúncios | Gerar token com `ads_read` |
| `rate_limited` | Quota da Meta; `details.retry_after` em segundos | Aguardar a janela |
| `budget_exhausted` | Orçamento local da execução esgotado | Repetir na próxima execução (EXECUTION-BUDGET.md) |
| `upstream_error`, `upstream_validation`, `upstream_invalid`, `resource_not_found` | Falha, recusa ou resposta inválida da Meta | Ler `details` (abaixo) |
| `coverage_incomplete` | A Meta indicou continuação sem cursor seguro | Tratar o resultado como incompleto |
| `unsupported`, `unsupported_field`, `unsupported_timeframe`, `unsupported_breakdown` | Relatório, campo ou combinação fora do catálogo | Consultar `meta/list-fields` |
| `invalid_cursor`, `cursor_expired` | Continuação de outro site, adulterada ou vencida | Recomeçar sem cursor |
| `history_changed` | O histórico mudou durante a paginação | Recomeçar a leitura ou exportação |
| `explicit_start_required` | Carga retroativa sem `date_from` | Informar o início |
| `job_terminal` | Coleta já encerrada | Criar outra coleta |
| `result_unavailable`, `export_unavailable`, `incomplete_collection`, `export_limit` | Página ou exportação ausente, incompleta ou grande demais | Conferir o estado; dividir o período |
| `response_limit` | Resposta acima do limite | Reduzir `limit` ou campos; não tratar como completa |
| `storage_unavailable`, `persistence_unconfirmed` | Banco indisponível ou gravação sem confirmação | Reler o estado antes de repetir |
| `cipher_unreadable`, `storage_corrupt`, `crypto_unavailable` | Registro que a chave atual não abre | Conferir os salts; não regravar por cima |
| `documentation_unavailable` | Arquivo de documentação ausente ou fora da pasta | Reinstalar a versão |
| `internal_error` | Exceção não prevista | Consultar `meta/health` e a auditoria |

Códigos próprios de recursos específicos estão nos guias: conversas em INSTAGRAM-MESSAGING.md, eliminação em MESSAGE-PRIVACY.md, consumidores em SDK-PHP.md, Stories em STORY-ARCHIVE.md e diagnóstico das coletas em COLLECTION-DIAGNOSTICS.md.

## Diagnóstico da Meta em `details`

Falhas vindas da Meta trazem, quando existem: `http_status`, `provider_code`, `provider_subcode`, `provider_is_transient`, `provider_message` (sanitizada), `provider_type`, `fbtrace_id`, `provider_call`, `request_stage`, `provider_api_version` e `diagnostic_action`. Campos desconhecidos ficam `null` ou ausentes. Os códigos 4, 17, 32 e 613 e o HTTP 429 viram `rate_limited`; 190 e 102 viram `token_rejected`; 10 e 200 viram `asset_access_denied`. COLLECTION-DIAGNOSTICS.md descreve a sanitização.

## Permissões

- Todas as operações exigem usuário autenticado com `manage_options`, inclusive as de leitura e a documentação. A lista `users` da conexão não concede acesso a ninguém.
- Pelo MCP, a política do transporte é conferida antes da execução. Operações de escrita exigem perfil que as autorize; `meta/health` é leitura.
- Coletas e agendas guardam o principal de origem (usuário e, se houver, concessão do transporte). Antes de cada chamada, o plugin confere que esse usuário ainda tem `manage_options` e que a concessão continua ativa.
- Consumidores SDK concedidos operam sem usuário WordPress na sessão, mas a concessão guarda e revalida a origem administrativa.

## Revisões e concorrência

Configuração, agendas, concessões e controle de coletas usam revisão otimista: envie `expected_revision` igual à revisão lida (`0` para criar). Revisão divergente devolve `revision_conflict` sem gravar. Travas nomeadas do banco serializam gravações concorrentes; se a trava estiver ocupada, a resposta é `busy`.

## Idempotência

`meta/create-job`, `meta/create-backfill`, `meta/export` e `meta/history-export` exigem `idempotency_key` (até 64 caracteres). A mesma chave com a mesma intenção devolve o mesmo registro; com outra intenção, `idempotency_conflict`. A chave é vinculada ao principal. Não troque a chave para contornar um resultado incerto: confira o estado primeiro (AGENTS.md).

## Continuações

`next_cursor` e `cursor` são valores cifrados e vinculados à seleção, ao principal, à revisão de autorização e, no histórico, à geração do conjunto. Não edite nem reaproveite um cursor em outra seleção. Listagens administrativas (`meta/list-connections`, `meta/list-jobs`, `meta/audit`) usam `offset` e `next_offset`, com até 50 itens por página. `meta/list-jobs` mostra só as coletas do mesmo principal, então uma página pode vir menor ou vazia e ainda ter continuação. A falta de uma página não prova que os registros não existem.

## Contrato de relatório

As respostas de relatório seguem `social-reporting/1.0.0`; o Meta estende para `social-reporting/1.1.0` com linhas diárias e disponibilidade por métrica. `coverage.complete=true` exige fim do plano sem indisponibilidade registrada. `all_rows_guaranteed` pode ser `null`. Zero é valor válido; ausência é `null` com diagnóstico em `rows[].diagnostic` ou `coverage.errors[]` (amostra limitada a 50). Mais de um bucket diário aparece como `multiple_source_buckets`, sem soma nem escolha.

## Opções dos formulários

`meta/admin-options` serve aos formulários do painel e exige administrador em qualquer transporte. Listar nomes não altera a seleção.

| `kind` | Devolve |
|---|---|
| `users` | Usuários locais pelo nome (50 por página, `search` por nome ou login, ou até 100 `ids`); sem e-mail nem credencial |
| `assets` | Descoberta de ativos com continuação cifrada, como `meta/list-accounts` |
| `selected` | Nomes de até 10 ativos já selecionados por página; falha de nome dá `name=null` e `name_status=unavailable` |
| `objects` | Nome e ID de mídias, Stories, publicações ou vídeos de uma conta |

`forms` e `journal` pertencem ao plugin LinkedIn e são recusados aqui. `connection_revision` identifica a revisão lida.

## Operações de descoberta

| Operação | Devolve |
|---|---|
| `meta/capabilities` | Versão, canais, relatórios, contratos de relatório, versão padrão da API, documentação, capacidade humana exigida, formatos de exportação e contratos dos SDKs locais |
| `meta/contracts` | Schemas de entrada, formato do envelope e as capacidades |
| `meta/configuration-schema` | Schema de `save-connection` e regras de credencial e revisão |
| `meta/documentation` | Índice e leitura da documentação (abaixo) |

## SDKs locais e ganchos

Outros plugins do mesmo site podem ler dados locais por três contratos PHP. Cada um exige registro no gancho e concessão explícita do administrador. SDK-PHP.md descreve o conjunto; os guias específicos detalham cada contrato.

| Gancho | Contrato | Guia |
|---|---|---|
| `f3_meta_register_ads_consumers` | `meta-ads-reader/1.0.0` | META-ADS-READER.md |
| `f3_meta_register_monitoring_consumers` | `meta-ads-monitoring/1.0.0` | MONITORING.md, CORE-MONITORING.md |
| `f3_meta_register_messaging_consumers` | `instagram-first-message/1.0.0` e `instagram-message-erasure/1.0.0` | INSTAGRAM-MESSAGING.md, MESSAGE-PRIVACY.md |

O webhook de mensagens usa a rota `GET|POST /wp-json/f3-meta/v1/messaging-webhook/<conexão>/<conta>` (INSTAGRAM-MESSAGING.md).

## Leitura da documentação

`meta/documentation` lê os arquivos instalados em `docs/`. Não consulta a Meta, não grava auditoria e só aceita IDs do índice fixado no build.

1. **Índice.** `{"document":"index"}` devolve `slug`, `plugin_version`, `origin=local`, `documents[]` e `topics`. Cada entrada de `documents[]` tem `document`, `bytes`, `sha256`, `title`, `summary` e `topic`; a ordem é a ordem de leitura recomendada. `topics` mapeia o ID do tema para o rótulo.
2. **Primeira página.** `{"document":"README.md","offset":0,"limit_bytes":16384}`. `limit_bytes` vai de 256 a 65.536 (padrão 16.384). A resposta traz `title`, `content`, `revision` (igual ao `sha256`), `total_bytes`, `next_offset` e `has_more`.
3. **Continuação.** Repita com `offset=next_offset` e `expected_revision` igual à `revision` da primeira página, até `next_offset=null`.
4. **Conferência.** Concatene `content` sem separadores e confira o SHA-256 integral.

Offsets contam bytes UTF-8; o fim de cada página nunca corta um caractere, e um offset no meio de um caractere é recusado.

| Situação | Resposta |
|---|---|
| `offset` maior que zero sem `expected_revision` | `invalid_input` com `details.field=expected_revision` e `details.problem=missing_required` |
| `expected_revision` diferente da revisão instalada | `revision_conflict`: recomece pelo índice |
| ID fora do índice ou caminho arbitrário | `not_found` |
| Arquivo ausente, ilegível ou link simbólico para fora da pasta | `documentation_unavailable` |
| Bytes do arquivo diferentes do índice | `revision_conflict`: compare a instalação com o manifesto da versão e reinstale |

## Tipo de corpo na REST administrativa

Use um objeto JSON e `Content-Type: application/json`. Para operações sem parâmetros, o painel envia `{}`; corpo ausente ou lista vazia também representam a chamada sem argumentos. Um escalar, `null`, uma lista com itens ou dados de formulário no corpo recebem `invalid_input` antes de executar a operação. A autorização administrativa continua obrigatória. Na auditoria, a recusa de entrada mantém o código e o evento, com `connection_id: null`; os dados recusados não são copiados para esse campo. A regra vale para novos registros.
