# Integração de monitoramento com o Site Core

O Meta coleta e guarda atividades de anúncios, contagens de eventos e EMQ (MONITORING.md). O Fator3 Site Core lê esse acervo pelo contrato `meta-ads-monitoring/1.0.0` e decide sobre avisos ao responsável. Na integração observada, o consumidor do Core usa o ID `base-site-core-fator3`. Confira o consumidor presente no site com `meta/monitoring-consumers`. Não há concessão automática, alteração de anúncios nem compartilhamento de token.

As operações `f3base/…` citadas abaixo pertencem ao Core; seus nomes e campos foram observados na integração e devem ser conferidos na documentação do Core instalado.

## Configurar e autorizar

1. **No Meta:** confira a conexão na identidade atual com `ads_read`. Autorize a conta de anúncios e cada dataset, e confira o vínculo entre eles.
2. **No Core:** leia `f3base/config-core-ler` com `nome=f3base_meta_monitoramento` e guarde a revisão. Grave com `f3base/config-core-escrever`, primeiro em simulação, com `revisao_esperada` e o valor completo: `ativo`, `conexao`, `conta_id`, `revisao`, `reports`, `dataset_ids`, `avisar`, `canal` e `operador` conforme o schema do Core. Use a mesma conexão e conta, e os relatórios e datasets que serão concedidos (até 12 datasets). Aumente `revisao` ao mudar a configuração. Ativar a leitura não autoriza envio de avisos.
3. **No Meta:** leia `meta/monitoring-consumers`. O consumidor precisa estar registrado, com configuração pronta e recuperação do Core pronta e não pausada. `consumer_not_ready` indica que falta uma dessas condições.
4. **No Meta:** leia `meta/get-monitoring-grant` para consumidor, conexão e conta. Grave `meta/save-monitoring-grant` com a revisão devolvida, `enabled=true`, `reports` e `dataset_ids` idênticos à configuração do consumidor. Pelo MCP, a gravação exige perfil de escrita.
5. **Conferir:** veja o estado no Core (`f3base/meta-monitoramento-status`) e a concessão no Meta. Crie ou revise as coletas e agendas no Meta para preencher o histórico. Concessão pronta não significa dados já coletados.
6. **Avisos:** habilite `avisar` só com autorização para o canal escolhido e depois de conferir as provas.

Qualquer mudança na configuração do Core, inclusive `avisar`, `canal` ou `revisao`, muda a revisão vista pelo SDK. Confira e grave a concessão de novo para a configuração nova antes de esperar avisos, e comece novas leituras sem cursor antigo. Não restaure valores antigos para tentar reautorizar.

## Identificadores

| Entrada | Conta e dataset | Período e página |
| --- | --- | --- |
| Coleta Meta `ads_activity` | `channel=ads`; `account_id` é a conta | `date_from`, `date_to` |
| Coleta Meta `dataset_quality` | `channel=dataset`; `account_id` é o dataset; `ads_account_id` é a conta | `date_from`, `date_to` |
| SDK de monitoramento | `account_id` é sempre a conta; `dataset_id` escolhe o dataset | `date_from`, `date_to`, `limit`, `cursor` |
| Core `f3base/meta-monitoramento-ler` | Usa a seleção configurada; `report` e `dataset_id` para qualidade | `de`, `ate`, `limite`, `cursor` |

## Leitura pelo Core

O SDK lê só o armazenamento local cifrado do Meta, sem Graph API e sem avisos. Com o Fator3 MCP ativo, a chamada pública de `meta/health` feita pelo Core passa pela política do transporte: confira a permissão de leitura da identidade usada pelo job do Core. Uma concessão SDK válida não substitui essa política. Não amplie permissões automaticamente nem contorne o transporte.

Navegador e servidor podem descrever o mesmo evento e não devem ser somados. EMQ é uma observação datada, não a nota histórica do dia das contagens. Ausência, erro, limite ou cobertura incompleta permanecem desconhecidos. O acervo de monitoramento não expira.

## Condições do aviso

O Meta mostra `dataset_optimized_event_zero` em `meta/health` apenas nas condições descritas em MONITORING.md. O Core revalida a prova pelo SDK, a concessão, o operador e a recuperação, e exige também emissão local no pixel, evento e dia exatos, ou gasto positivo autorizado. Pixel do navegador e destino CAPI diferentes não são intercambiáveis; prova desconhecida impede o aviso. Deduplicação, recibos e canal de envio são responsabilidade do Core.

## Diagnóstico

| Situação | Conduta |
|---|---|
| `consumer_not_ready` | Conferir a seleção e a recuperação no Core |
| `grant_revoked` | Obter concessão explícita atual |
| `revision_conflict` | Reler configuração e concessão, reautorizar o escopo aprovado e recomeçar a paginação |
| Leitura vazia | Conferir coleta, datas, cobertura e continuação, sem presumir zero |

Nenhum desses estados admite recorrer a token, principal ou configuração antigos.

## Validação com ativos reais

Confira identidade e permissões, conta e dataset, coletas de dia completo, alteração com detalhes, contagens separadas, EMQ datada, concessão e revogação. Teste o envio só para canal autorizado e confira uma única notificação por incidente elegível. Fixtures de laboratório validam integração e controles, não a disponibilidade remota.
