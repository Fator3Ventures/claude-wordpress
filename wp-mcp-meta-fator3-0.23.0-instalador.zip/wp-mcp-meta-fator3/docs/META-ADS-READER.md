# SDK local do acervo de Meta Ads

O contrato `meta-ads-reader/1.0.0` permite que outro plugin do mesmo site leia o acervo local de Meta Ads, sem Graph API e sem token. O consumidor mantém sua própria seleção, regras comerciais, associação de campanhas a parceiros e contatos, e deduplicação. Ele não deve ler tabelas ou opções privadas do Meta nem chamar o MCP para ler o próprio site. Ter o leitor disponível não autoriza nenhum consumidor.

## Registro

Registre o consumidor no gancho abaixo e guarde o objeto devolvido. Esse objeto é o cliente registrado; um cliente fabricado de outra forma é recusado. Cada ID só pode ser registrado uma vez por processo.

```php
add_action('f3_meta_register_ads_consumers', static function ($sdk, $contract) {
    if ($contract !== 'meta-ads-reader/1.0.0') return;
    MeuConsumidor::$metaAds = $sdk::register_consumer(
        'meu-consumidor', '1.0.0', $contract,
        static fn() => MeuConsumidor::configuracaoMetaAds(),
        'Meu consumidor de anúncios'
    );
}, 10, 2);
```

O callback de configuração devolve `{connection_id, account_id, revision, ready:true}`; `revision` tem até 128 caracteres e só muda quando a configuração muda. O callback não deve fazer HTTP nem alterar estado. Enquanto a configuração estiver incompleta, devolva `ready=false`.

## Concessão

O administrador autoriza em **Ferramentas → Fator3 MCP Meta → Consumidores de anúncios**, ou pelas operações:

| Operação | Uso |
|---|---|
| `meta/ads-consumers` | Lista consumidores registrados e concessões |
| `meta/get-ads-grant` | Lê `revision` e `enabled` para `consumer_id`, `connection_id` e `account_id` |
| `meta/save-ads-grant` | Grava `enabled` com `expected_revision` (`0` ao criar) |

Não presuma a revisão: leia antes de gravar. É possível revogar mesmo depois que o consumidor ou a conexão foram removidos. Pelo MCP, gravar exige perfil de escrita. Uma recusa da política remota nunca vira sessão administrativa local.

## Leitura

- `$client->status(['connection_id'=>…, 'account_id'=>…])` informa `ready`, as versões da concessão, da autorização e da configuração, e o contrato.
- `$client->query([...])` aceita só `connection_id`, `account_id`, `ads_level` opcional, `date_from` e `date_to` juntas, `limit` (1 a 100, padrão 100) e `cursor`. Não aceita conexão ou conta diferente da configuração registrada.

A resposta usa o envelope do Meta (`success`, `code`, `provider`, `version`, `data`); falhas têm `data` nulo e código e mensagem sanitizados. Trate o envelope antes de usar as linhas.

`data` contém `contract`, `rows`, `next_cursor`, `generation`, `retention` e `grant_revision`. Cada linha traz `row_id`, `row`, `data_day`, `first_seen`, `last_seen`, `observations`, fuso, moeda, `selection` e `coverage`. Os campos de cada linha estão em META-ADS.md. O cursor inclui identidade do consumidor, revisões da concessão e da configuração, autorização da conexão e geração do acervo. `history_changed` ou `revision_conflict` exigem recomeçar a leitura, sem juntar conjuntos de gerações diferentes.

## Condições

- A origem administrativa da concessão precisa continuar existindo, com `manage_options` e, se usada, concessão de transporte ativa.
- A conexão precisa estar ativa e a conta, selecionada. Mudança de identidade ou de ativos exige revisão da concessão.
- Token vencido não impede leitura local concedida.
- O cliente registrado e concedido pode operar no cron sem usuário na sessão; o SDK revalida origem, concessão e configuração antes e depois de ler.
- Revogar e reautorizar não revive cursores antigos.
- Leituras e falhas geram auditoria local, sem dados de anúncios nem credenciais.

## Erros

`consumer_unavailable`, `consumer_not_ready`, `contract_mismatch`, `consumer_conflict`, `consumer_scope_mismatch`, `grant_revoked`, `not_authorized`, `asset_access_denied`, `connection_paused`, `revision_conflict`, `history_changed`, `invalid_input`, `invalid_cursor`, `cursor_expired`, `storage_unavailable` e `response_limit`. Erro ou ausência nunca é zero. SDK-PHP.md resume o significado dos códigos de consumidor.

## Integração com o Site Core

Na integração observada, o Site Core registra-se como `base-site-core-fator3`, guarda sua seleção na própria configuração e exige revisão e concessão explícita no Meta. Instalar os dois plugins não concede acesso. Confira o consumidor presente no site com `meta/ads-consumers`; a configuração do lado do Core está na documentação do Core instalado.
