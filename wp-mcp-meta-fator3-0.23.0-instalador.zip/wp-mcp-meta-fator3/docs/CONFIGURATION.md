# Configuração

Este documento cobre pré-requisitos, campos da conexão, obtenção da credencial, conferência na Meta, renovação, troca de identidade, ativos, retenção e remoção de credenciais. A sequência guiada da primeira conexão está em USAGE.md; o passo a passo na tela está em ADMINISTRATION.md.

## Pré-requisitos

1. Usuário WordPress com `manage_options`. Painel, REST, Abilities API e MCP recusam qualquer outro perfil.
2. Um aplicativo na Meta for Developers, com App ID e App Secret.
3. Um token de usuário do sistema do Meta Business Suite, gerado para esse aplicativo, com os escopos dos recursos que serão usados.
4. Ativos (contas Instagram profissionais, Páginas, contas de anúncios, datasets) acessíveis a esse token.
5. Para coletas agendadas, cron do WordPress funcionando (OPERATIONS.md).

## Campos da conexão

`meta/configuration-schema` devolve o schema de gravação e as regras gerais (credencial informada manualmente, segredo vazio preserva o atual, ativos vazios não concedem acesso, revisão obrigatória). Os campos de `meta/save-connection` são:

| Campo | Uso |
|---|---|
| `connection_id` | Identificador local, até 64 caracteres; não muda depois de criado |
| `expected_revision` | Revisão lida antes de gravar; `0` para criar |
| `label` | Nome exibido, até 120 caracteres |
| `client_id`, `client_secret` | App ID e App Secret do aplicativo |
| `token` | Token de acesso; até 16384 bytes |
| `expires_at` | Validade informada em Unix UTC; `0` quando não expira por prazo |
| `assets` | Listas de IDs numéricos (strings) por canal: `instagram`, `facebook`, `ads`, `dataset` |
| `users` | IDs de usuários WordPress associados; não concede permissão a ninguém |
| `enabled` | Pausa ou ativa a conexão |
| `api_version` | Versão da Graph API (padrão `v24.0`) |
| `retention_mode`, `retention_days` | `unlimited` (padrão) ou `finite` com 1 a 3650 dias |
| `clear_token`, `clear_client_secret` | Remoção explícita de um segredo salvo |

Campos omitidos preservam o valor salvo. Um segredo enviado vazio também preserva o valor salvo; para apagá-lo use `clear_token` ou `clear_client_secret`.

## Como obter a credencial

1. Em **Meta for Developers → Meus apps → seu app → Configurações do app → Básico**, copie o ID do aplicativo e, em **Mostrar**, a chave secreta.
2. Em **Meta Business Suite → Configurações → Usuários → Usuários do sistema**, escolha o usuário e use **Gerar token**.
3. Escolha o mesmo aplicativo e a expiração **Nunca**.
4. Marque os escopos de leitura: `pages_show_list`, `pages_read_engagement`, `read_insights`, `instagram_basic` e `instagram_manage_insights`. Para Meta Ads e datasets, acrescente `ads_read`. Para conversas, veja os escopos em INSTAGRAM-MESSAGING.md.
5. Copie o token na janela **Token criado** antes de fechá-la.

Não use **Anular tokens** na Meta para trocar a credencial: a revogação pode derrubar outros usos da mesma credencial, inclusive no Site Core. O plugin não grava nem revoga credenciais de outros plugins.

## Conferência antes de gravar

Quando a gravação traz um token novo ou muda o par de aplicativo, o plugin consulta a Meta antes de persistir: `debug_token` autenticado com o próprio aplicativo e `/me?fields=id,name`. Confere validade, aplicativo, identidade, expiração e acesso a cada ativo selecionado. Se algo falhar, nada é gravado: conexão e agendas permanecem como estavam.

A conferência local só bloqueia três casos: valor indispensável vazio, valor acima de 16384 bytes ou caractere de controle (`invalid_credential_input`). Formatos incomuns geram avisos e seguem para a Meta decidir. Os avisos chegam no campo `avisos` da resposta, em sucesso e em erro, com `campo`, `codigo` e `motivo`:

| `codigo` | Situação |
|---|---|
| `outer_spaces_trimmed` | Espaços externos foram removidos |
| `internal_spaces` | Há espaços internos |
| `short_token` | Token com menos de 100 bytes |
| `possible_app_secret` | O valor do token parece uma chave secreta |
| `unusual_app_id` | App ID fora do padrão usual de 15 a 17 dígitos |
| `unusual_app_secret` | Chave fora do padrão usual de 32 caracteres hexadecimais |

A conferência faz no máximo 40 chamadas em 25 segundos e confere até 12 ativos por conexão. Tempo ou chamadas insuficientes recusam a candidata sem gravar. A conferência pode gerar linha de auditoria mesmo quando recusada.

## Identidade da credencial

A resposta pública da conexão traz `connection.identity` com `subject_id`, `subject_name` (de `/me`), `application_id`, `application_name` (de `debug_token`), `remote_expires_at`, `scopes`, `extra_scopes` e o instante da conferência. O campo `token_identity` traz os mesmos metadados. Pelo MCP, o transporte pode ocultar `token_identity` pelo nome; use `identity`. Nomes que a Meta não informou aparecem como indisponíveis; o plugin não os deduz do nome digitado.

A validade informada é substituída pela validade devolvida por `debug_token`; `0` significa que não expira por prazo, mas o token ainda pode ser revogado. Escopos além dos necessários aparecem em `extra_scopes` como aviso, sem revogação automática. A identidade é uma observação datada: abrir o painel não consulta a Meta de novo.

## Renovar o token

`meta/rotate-token` recebe `connection_id`, `expected_revision`, `token` e, opcionalmente, `expires_at`. Usa o mesmo validador da gravação. Aplicativo, principal e identidade precisam coincidir com os salvos, sem perder escopos. Uma credencial expirada pode ser substituída se a identidade anterior estava comprovada. Sem essa prova, a renovação tenta inspecionar a credencial salva; se não conseguir comprovar a continuidade, exige a troca de identidade. A renovação preserva as agendas e não exige revogar o token anterior.

## Trocar de identidade

Quando a gravação recusa com `credential_identity_mismatch`, a troca de identidade é feita em duas chamadas a `meta/switch-identity`:

1. **Simulação** com `dry_run=true`: devolve `persisted=false`, a identidade nova, as agendas afetadas, `connection_revision`, `confirmation` e `confirmation_expires_in` (600 segundos). A simulação consulta a Meta e grava auditoria, mas não grava conexão nem agenda.
2. **Execução** com `dry_run=false`, a mesma candidata, a mesma revisão e o `confirmation` recebido, em até dez minutos.

A confirmação vincula credencial, aplicativo, identidade, `label`, escopos, validade, site, ator, revisão da conexão e revisões das agendas. Qualquer mudança em um desses itens exige nova simulação. A execução confere a Meta outra vez e grava credencial, identidade, aplicativo, nome e agendas numa só transação. Sem `label`, o nome salvo é preservado. Nenhuma seleção de ativos é ampliada. O comprovante é cifrado, específico do site e nunca contém o token em claro.

## Revisões e agendas

A conexão tem três contadores distintos: a revisão de configuração (usada como `expected_revision`), `authorization_revision` e `credential_generation`. Conexão, agendas e evento de auditoria são gravados numa única transação InnoDB; uma falha desfaz o conjunto.

Mudanças de nome, validade, retenção, aplicativo verificado e a renovação da mesma identidade regravam as agendas compatíveis na revisão atual. A resposta traz `schedules_rebased` (quantidade) e `schedules_requiring_review` (IDs). Uma agenda que já estava incompatível com a seleção ou a autorização fica na lista de revisão, sem reautorização silenciosa.

Mudanças de ativos, usuários associados, versão da API ou `enabled` invalidam os planos anteriores. Revise e salve as agendas afetadas com a revisão atual. Coletas iniciadas sob outra identidade ficam intactas e não passam a valer para a nova.

## Ativos

Os ativos são escolhidos depois de salvar a conexão. `meta/list-accounts` descobre contas e Páginas acessíveis ao token, com continuação; `meta/admin-options` com `kind=assets` faz o mesmo para o painel, com os nomes. A descoberta nunca concede acesso nem marca a seleção. Só os IDs gravados em `assets` pela gravação da conexão são autorizados; uma lista vazia significa nenhum ativo autorizado.

| Canal | Ativo | Observação |
|---|---|---|
| `instagram` | Conta profissional | Acessada pelo Facebook Login, exige Página vinculada; conferida diretamente na Meta |
| `facebook` | Página | O token da Página é derivado só de Página selecionada, guardado cifrado e ligado à geração da credencial |
| `ads` | Conta de anúncios | ID numérico sem o prefixo `act_`; exige `ads_read` |
| `dataset` | Dataset (pixel) | Descoberto a partir de uma conta de anúncios já selecionada (`ads_account_id`) |

Acesso a metadados de um ativo não prova que todas as métricas estejam disponíveis. Valide o relatório desejado com a conta real.

## Retenção

O padrão é `retention_mode=unlimited`: resultados e histórico sem expiração automática. `finite` com `retention_days` de 1 a 3650 vale apenas para métricas orgânicas; Meta Ads e monitoramento continuam sem prazo. Mudar a retenção não recupera dados já apagados. RETENTION.md descreve a política completa.

## Versão da Graph API

A versão padrão é `v24.0`. Ela pode ser trocada por conexão na aba Conexão, em **Configuração avançada da versão da API**, ou pelo campo `api_version`. Trocar a versão exige rever coletas e concessões, porque a disponibilidade de métricas muda entre versões.

## Remover credenciais e desconectar

- Para apagar o token ou a chave salvos, use `clear_token` ou `clear_client_secret` (no painel, **Remover credenciais salvas**).
- Para suspender a conexão sem perder nada, grave `enabled=false`. As coletas dessa conexão param com `connection_paused`.
- Para revogar o acesso do aplicativo, use as configurações da própria Meta. O plugin não revoga tokens.

## Como verificar

1. Leia a conexão com `meta/get-connection` e confira `identity`, validade, escopos e ativos.
2. Valide cada ativo com `meta/validate-connection` (consulta a Meta e grava o diagnóstico).
3. Faça uma consulta pequena com `meta/query` (USAGE.md, sequência 3).
4. Confira `meta/health` para o estado local.
