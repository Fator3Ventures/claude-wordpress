<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Api {
    public static function writes(string $op): bool {return in_array($op,['status','save-connection','validate-connection','create-job','run-job','control-job','save-schedule','export','save-grant','lead-create-subscription','lead-delete-subscription','lead-reconcile-subscription','rotate-token','switch-identity','history-migrate','create-backfill','history-export','history-export-step','save-messaging-settings','process-messages','save-ads-grant','save-monitoring-grant'],true);}
    public static function adminOnly(string $op): bool {return true;}
    /** Pure effect classification of one operation: used by the ability registry and by the generated REFERENCE.md. */
    public static function effects(string $op): array {
        $write=self::writes($op);
        return ['mode'=>$write?'write':'read','local_effect'=>$write?'write':'none','remote_effect'=>$op==='process-messages'?'write':(str_starts_with($op,'lead-')&&$write?'write':(in_array($op,['query','list-accounts','validate-connection','run-job','admin-options','save-connection','rotate-token','switch-identity','conversations','save-messaging-settings','process-messages','save-ads-grant'],true)||str_starts_with($op,'lead-')?'read':'none')),'readonly'=>!$write,'destructive'=>in_array($op,['lead-delete-subscription','save-connection','save-grant','save-ads-grant','save-monitoring-grant','switch-identity'],true),'idempotent'=>!$write];
    }
    public static function capabilities(): array {
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'contract'=>'social-reporting/1.0.0','reporting_contracts'=>Config::KEY==='f3_meta'?['social-reporting/1.0.0','social-reporting/1.1.0']:['social-reporting/1.0.0'],'channels'=>Config::CHANNELS,'reports'=>Adapter::reports(),'independent'=>true,'mcp_optional'=>true,'api_version_default'=>Config::API_VERSION,'documentation'=>['operation'=>Config::PREFIX.'/documentation','entry'=>'index','max_bytes'=>65536],'human_capability'=>'manage_options','remote_homologation'=>'requires_authorized_credentials','exports'=>['csv','json'],'commercial_ingestion'=>false,'instagram_first_message_contract'=>Config::KEY==='f3_meta'?Messaging::CONTRACT:null,'story_archive'=>Config::KEY==='f3_meta'?StoryArchive::policy():null,'monitoring_sdk'=>Config::KEY==='f3_meta'?MonitoringReader::contract():null,'local_sdk'=>Config::KEY==='f3_linkedin'?PublicApi::capabilities():AdsReader::contract()];
    }
    public static function dispatch(string $op,array $i=[],bool $channel=false): array {
        $avisos=[];
        $result=Result::run(static function()use($op,$i,$channel,&$avisos){
            Access::human();Schemas::validate($op,$i);if(self::adminOnly($op))Access::admin();
            if($channel&&class_exists('\\Fator3\\McpFiles\\AuthorizationPolicy')){$check=\Fator3\McpFiles\AuthorizationPolicy::check(Config::PREFIX.'/'.$op,$i,!self::writes($op));if($check!==true)throw new Fault('not_authorized','Política do transporte recusou esta habilidade.');}
            if(Config::KEY==='f3_meta'&&in_array($op,['save-connection','rotate-token','switch-identity'],true))$avisos=Credentials::warnings($i);
            Http::budget(Config::KEY==='f3_meta'?40:15,25);
            if(str_starts_with($op,'lead-')){
                if($op==='lead-discover-forms'){$c=Connections::get($i['connection_id']);Access::connection($c,'leads',$i['account_id']);Connections::usable($c);$start=$i['offset']??0;$r=Http::request($c,'leadForms',['q'=>'owner','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'start'=>$start,'count'=>50])['body'];$rows=Adapter::elements($r);foreach($rows as $row)if(($row['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$i['account_id'])throw new Fault('upstream_invalid','Proprietário divergente.');return ['forms'=>$rows,'next_offset'=>Adapter::more($r,$start,count($rows),50)?$start+count($rows):null,'selection_required'=>true];}
                $method=str_replace('-','_',substr($op,5));$r=PublicApi::lead_reader('')->$method($i);if(!$r['success'])throw new Fault($r['code'],$r['message'],$r['details']);return $r['data'];
            }
            return match($op){
                'capabilities'=>self::capabilities(),
                'status'=>Worker::status(),
                'health'=>(static function(){$h=Worker::observe();$m=Monitoring::health();$h['issues']=array_merge($h['issues'],$m['issues']);$h['state']=$h['issues']?'degraded':'ok';return $h+['messaging'=>Messaging::health(),'datasets'=>$m];})(),
                'selftest'=>SelfTest::run(),
                'configuration-schema'=>['contract'=>'social-configuration/1.0.0','schema'=>Schemas::all()['save-connection'],'credential_input'=>'manual_token','empty_secret_keeps_existing'=>true,'scope_empty_means_none'=>true,'revision_required'=>true],
                'contracts'=>['input'=>Schemas::all(),'output'=>['envelope'=>['success'=>'boolean','code'=>'string','data'=>'object on success; null on failure','error_code'=>'stable failure code','conflict'=>'true for revision_conflict'],'report'=>'social-reporting/1.0.0'],'capabilities'=>self::capabilities()],
                'documentation'=>Documentation::read($i),
                'admin-options'=>Admin::options($i),
                'list-connections'=>(static function()use($i){$at=$i['offset']??0;$rows=Connections::list($at,51);return ['connections'=>array_slice($rows,0,50),'next_offset'=>count($rows)>50?$at+50:null];})(),
                'get-connection'=>['connection'=>Connections::public(Connections::get($i['connection_id']))],
                'audit'=>Audit::list($i),
                'save-connection'=>Connections::save($i),
                'validate-connection'=>Query::validate($i),
                'list-accounts'=>Query::accounts($i),
                'list-fields'=>Config::KEY==='f3_meta'?Catalog::metrics($i):['report'=>$i['report'],'fields'=>Adapter::fields($i['report'])],
                'rotate-token'=>Credentials::rotate($i),
                'switch-identity'=>ConnectionChanges::switchIdentity($i),
                'messaging-status'=>Messaging::status($i),
                'save-messaging-settings'=>Messaging::save($i),
                'conversations'=>Messaging::conversations($i),
                'process-messages'=>Messaging::process($i),
                'story-archive'=>StoryArchive::read($i),
                'story-archive-thumbnail'=>StoryArchive::read($i,true),
                'monitoring-consumers'=>MonitoringReader::consumers(),
                'get-monitoring-grant'=>MonitoringReader::grant($i),
                'save-monitoring-grant'=>MonitoringReader::save($i),
                'ads-consumers'=>AdsReader::consumers(),
                'get-ads-grant'=>AdsReader::grant($i),
                'save-ads-grant'=>AdsReader::save($i),
                'history-status'=>History::status(),
                'history-migrate'=>History::migrate(),
                'history-query'=>History::query($i),
                'create-backfill'=>History::backfill($i),
                'history-export'=>HistoryExport::create($i),
                'history-export-step'=>HistoryExport::step($i),
                'history-export-read'=>HistoryExport::read($i),
                'query'=>Query::execute($i),
                'create-job'=>Jobs::create($i),
                'list-jobs'=>Jobs::list($i),
                'job-status'=>Jobs::status($i['job_id']),
                'run-job'=>Jobs::run($i['job_id']),
                'control-job'=>Jobs::control($i),
                'job-results'=>Jobs::results($i),
                'save-schedule'=>Schedules::save($i),
                'list-schedules'=>['schedules'=>Schedules::list()],
                'export'=>Export::create($i),
                'export-read'=>Export::read($i),
                'save-grant'=>PublicApi::grant($i),
                'list-grants'=>PublicApi::grantsPage($i),
                'get-grant'=>PublicApi::grantProjection($i),
                default=>throw new Fault('unsupported','Operação não implementada.')
            };
        });
        if(isset($result['data'])&&strlen(Util::json($result['data']))>900000)$result=Result::fail(new Fault('response_limit','Resposta excedeu o orçamento.'));
        if(Config::KEY==='f3_meta'&&in_array($op,['save-connection','rotate-token','switch-identity'],true))$result['avisos']=$avisos;
        if($op!=='documentation')Audit::record($op,$i,$result,null,$channel?'ability':'rest_or_local');
        return $result;
    }
    private static function connections(): array {return array_values(array_filter(Connections::list(),static fn($c)=>current_user_can('manage_options')||in_array(get_current_user_id(),$c['users'],true)));}
        public static function abilities(): void {
        if(!function_exists('wp_register_ability'))return;
        $labels=AbilityLabels::all();
        foreach(Schemas::all() as $op=>$schema){$e=self::effects($op);wp_register_ability(Config::PREFIX.'/'.$op,['label'=>$labels[$op]['label'],'description'=>$labels[$op]['description'],'category'=>Config::PREFIX,'input_schema'=>$schema,'output_schema'=>['type'=>'object','properties'=>['success'=>['type'=>'boolean'],'code'=>['type'=>'string'],'data'=>['type'=>['object','null']],'avisos'=>['type'=>'array','items'=>['type'=>'object']]]],'permission_callback'=>static fn()=>is_user_logged_in()&&current_user_can(self::adminOnly($op)?'manage_options':'read'),'execute_callback'=>static fn($i=[])=>self::dispatch($op,(array)$i,true),'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>$e['readonly'],'destructive'=>$e['destructive'],'idempotent'=>$e['idempotent']],'fator3'=>['provider'=>Config::SLUG,'version'=>Config::VERSION,'policy_contract'=>1,'mode'=>$e['mode'],'remote_effect'=>$e['remote_effect'],'local_effect'=>$e['local_effect'],'execution_contract_version'=>'1.0.0']]]);}
    }
    /** Keep the authorized empty request, but never convert a refused payload into a command. */
    private static function restCall(string $op,\WP_REST_Request $request): array {
        $input=$request->get_json_params();
        $body=$request->get_body();
        if($body==='')return self::dispatch($op,[]);
        // WordPress decodes JSON objects to associative arrays. [] is the established empty PHP client form.
        if(is_array($input)&&(!array_is_list($input)||$input===[]))return self::dispatch($op,$input);
        $result=Result::fail(new Fault('invalid_input','Envie um objeto JSON com os parâmetros da operação.',['field'=>'','problem'=>'invalid_type']));
        if($op!=='documentation')Audit::record($op,[],$result,null,'rest_or_local');
        return $result;
    }
    public static function routes(): void {
        if(Config::KEY==='f3_meta')Messaging::routes();
        foreach(Schemas::all() as $op=>$schema)register_rest_route(Config::REST,'/'.$op,['methods'=>'POST','permission_callback'=>static fn()=>current_user_can(self::adminOnly($op)?'manage_options':'read'),'callback'=>static function($r)use($op){$v=self::restCall($op,$r);$response=new \WP_REST_Response($v,($v['code']??'')==='not_authorized'?403:200);$response->header('Cache-Control','private, no-store');return $response;}]);
    }
}
final class SelfTest {
    public static function run(): array {
        $checks=[];$test=static function($name,$fn)use(&$checks){try{$ok=$fn();$checks[]=['name'=>$name,'state'=>$ok?'ok':'failed'];}catch(\Throwable $e){$checks[]=['name'=>$name,'state'=>'failed'];}};
        $test('storage',static fn()=>Store::ready());$test('authenticated_encryption',static fn()=>Crypto::open(Crypto::seal('f3-selftest'))==='f3-selftest');
        $test('cursor_roundtrip',static fn()=>Util::uncursor(Util::cursor(['expires'=>time()+30,'value'=>'x']))['value']==='x');
        $test('endpoint_allowlist',static fn()=>!Adapter::allowed('https://example.com/','GET')&&!Adapter::allowed('../secrets','GET'));
        $test('closed_schema',static function(){try{Schemas::validate('status',['unknown'=>1]);return false;}catch(Fault $e){return $e->reason==='invalid_input';}});
        $test('empty_scope_denied',static function(){try{Access::asset(['assets'=>[]],Config::CHANNELS[0],'123');return false;}catch(Fault $e){return $e->reason==='asset_access_denied';}});
        $test('csv_formula_protection',static fn()=>Export::safeCell('=1+1')==="'=1+1");
        $test('schema_catalog',static fn()=>count(Schemas::all())>=20);
        $failed=count(array_filter($checks,static fn($x)=>$x['state']!=='ok'));
        if($failed)throw new Fault('selftest_failed','Diagnóstico local reprovado.',['checks'=>$checks]);
        return ['execution_success'=>true,'local_checks_ok'=>true,'checks'=>$checks,'external_checks'=>'not_run','remote_homologated'=>false];
    }
}

final class Audit {
    public static function record(string $op,array $i,array &$result,?string $consumer=null,string $transport='local_sdk'): void {
        $id=$i['connection_id']??null;
        if(($result['code']??'')==='invalid_input'||!is_string($id)||!preg_match('/^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/D',$id))$id=null;
        try {if(Store::ready()){Store::put('audit',wp_generate_uuid4(),['operation'=>$op,'actor'=>['type'=>$consumer?'plugin':'user','id'=>$consumer?:get_current_user_id()],'transport'=>$transport,'connection_id'=>$id,'code'=>$result['code']??'unknown','at'=>time()],0,Config::KEY==='f3_meta'?0:time()+30*86400);update_option(Config::KEY.'_audit_health','ok',false);}}
        catch(\Throwable $e){$result['audit_warning']='audit_write_failed';update_option(Config::KEY.'_audit_health','failed',false);}
    }
    public static function list(array $i): array {Access::admin();$offset=$i['offset']??0;$since=$i['since']??0;$rows=Store::recent('audit',$offset,51,$since);$page=array_slice($rows,0,50);return ['events'=>array_map(static fn($r)=>['event_id'=>$r['key']]+$r['value'],$page),'next_offset'=>count($rows)>50?$offset+50:null,'order'=>'newest_first','since'=>$since?:null,'retention_days'=>Config::KEY==='f3_meta'?null:30,'retention_mode'=>Config::KEY==='f3_meta'?'unlimited':'finite'];}
}
