# Fator3 Site Core 1.86.0

Versão 1.86.0. Contatos, navegação administrativa e esperas de GA4 e Pipedrive. Consulte docs/RELEASE-1.86.0.md.

Instalação nova ou atualização da 1.85.1. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.41.0.

Índice de operação em docs/DOCUMENTACAO.md.
