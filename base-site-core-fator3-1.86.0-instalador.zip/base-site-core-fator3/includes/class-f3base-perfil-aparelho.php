<?php
/** Perfil de medição privado, observado uma vez por classe, sessão e visitante. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Perfil_Aparelho {
    public const ROTULOS = ['modelo'=>'Modelo','versao_sistema'=>'Versão principal do sistema','memoria_gb'=>'Memória (GB)',
        'nucleos'=>'Núcleos lógicos','tela'=>'Tela e DPR','rede'=>'Rede efetiva','faixa_aparelho'=>'Faixa do aparelho'];
    public const FAIXAS = ['entrada','intermediário','topo','desconhecido'];
    public const CATALOGO = ['Galaxy A07 4G=entrada','Galaxy A06=entrada','Moto G05=entrada','Galaxy A03 Core=entrada'];
    public static function tabela(): string { global $wpdb; return $wpdb->prefix.'f3base_aparelhos'; }
    public static function instalar(string $collate): bool {
        global $wpdb;
        $t=self::tabela();
        dbDelta("CREATE TABLE $t (
 classe varchar(16) NOT NULL,
 sessao char(32) NOT NULL,
 visitante char(32) NOT NULL,
 observado_em bigint NOT NULL,
 perfil text NOT NULL,
 PRIMARY KEY  (classe,sessao,visitante),
 KEY validade (observado_em),
 KEY visitante (visitante),
 KEY sessao (sessao)
) $collate;");
        return !$wpdb->last_error;
    }
    public static function validar_catalogo($rows): bool {
        if (!is_array($rows) || !array_is_list($rows) || count($rows)>500) { return false; }
        $seen=[];
        foreach ($rows as $row) {
            if (!is_string($row) || !preg_match('/^([\pL\pN][\pL\pN ._()+\/-]{0,79})=(entrada|intermediário|topo)$/uD',$row,$m)) { return false; }
            $k=mb_strtolower(trim($m[1])); if (isset($seen[$k])) { return false; } $seen[$k]=true;
        }
        return true;
    }
    public static function normalizar($v,string $ua,array $catalogo): array {
        if (!is_array($v)||!$v||array_diff(array_keys($v),['modelo','versao_sistema','memoria_gb','nucleos','largura','altura','dpr','rede'])) { return []; }
        $iphone=stripos($ua,'iPhone')!==false;
        $model=$v['modelo']??''; $model=!$iphone&&is_string($model)&&preg_match('/^[\pL\pN][\pL\pN ._()+\/-]{0,79}$/uD',$model)?trim($model):'';
        $major=$v['versao_sistema']??''; $major=is_string($major)&&preg_match('/^[1-9][0-9]{0,2}$/D',$major)?$major:'';
        if ($iphone && $major==='' && preg_match('/iPhone OS ([1-9][0-9]{0,2})[_ ]/i',$ua,$m)) { $major=$m[1]; }
        $memory=$v['memoria_gb']??null; $mem=in_array($memory,[0.25,0.5,1,2,4,8,16,32],true)?(string)$memory:'';
        $integer=static fn($n,$max)=>is_int($n)&&$n>=1&&$n<=$max?$n:0;
        $cores=$integer($v['nucleos']??null,256); $width=$integer($v['largura']??null,20000); $height=$integer($v['altura']??null,20000);
        $dpr=$v['dpr']??null; $dpr=(is_float($dpr)||is_int($dpr))&&$dpr>=0.1&&$dpr<=16?round($dpr,2):0;
        $screen=$width&&$height&&$dpr?$width.'×'.$height.' @'.$dpr.'x':'';
        $network=in_array($v['rede']??'', ['slow-2g','2g','3g','4g'],true)?$v['rede']:'';
        if ($model===''&&$major===''&&$mem===''&&!$cores&&!$screen&&!$network) { return []; }
        $tier='desconhecido'; $basis='sem_base';
        if ($iphone && $screen) {
            $tier=$dpr>=3 && max($width,$height)>=844?'topo':(max($width,$height)<=667?'entrada':'intermediário'); $basis='estimativa_tela_iphone';
        } elseif ($model!=='') {
            foreach ($catalogo as $row) {
                [$name,$value]=array_pad(explode('=',(string)$row,2),2,'');
                if (mb_strtolower(trim($name))===mb_strtolower($model) && in_array($value,self::FAIXAS,true)) { $tier=$value; $basis='catalogo'; break; }
            }
        } elseif (!$iphone && $mem!=='' && $cores) {
            $tier=(float)$mem<=2||$cores<=4?'entrada':((float)$mem>=8&&$cores>=8?'topo':'intermediário'); $basis='estimativa_capacidade';
        }
        return ['modelo'=>$model,'versao_sistema'=>$major,'memoria_gb'=>$mem,'nucleos'=>$cores?(string)$cores:'',
            'tela'=>$screen,'rede'=>$network,'faixa_aparelho'=>$tier,'faixa_fonte'=>$basis];
    }
    public static function gravar(string $classe,string $sessao,string $visitante,int $em,array $perfil): bool {
        global $wpdb;
        if (!$perfil || !F3Base_Leads_Contexto::sessao($sessao) || !F3Base_Leads_Contexto::sessao($visitante)) { return true; }
        return $wpdb->query($wpdb->prepare('INSERT INTO %i (classe,sessao,visitante,observado_em,perfil) VALUES (%s,%s,%s,%d,%s) ON DUPLICATE KEY UPDATE sessao=VALUES(sessao)',self::tabela(),$classe,$sessao,$visitante,$em,wp_json_encode($perfil)))!==false;
    }
    public static function sinais($v): array {
        $c=F3Base_Options::ler('f3base_medicao_editorial');
        return self::normalizar($v,(string)($_SERVER['HTTP_USER_AGENT']??''),$c['catalogo_aparelhos']??self::CATALOGO);
    }
    /** A reference in contact data resolves to the same retained observation used in reports. */
    public static function ler(array $ref): array {
        global $wpdb;
        if (empty($ref['sessao']) || empty($ref['visitante'])) { return []; }
        $raw=$wpdb->get_var($wpdb->prepare('SELECT perfil FROM %i WHERE classe=%s AND sessao=%s AND visitante=%s AND observado_em>=%d',self::tabela(),$ref['classe']??'',$ref['sessao'],$ref['visitante'],F3Base_Editorial::corte_retencao()));
        return json_decode((string)$raw,true)?:[];
    }
    public static function sql(): string {
        global $wpdb;
        return $wpdb->prepare('(SELECT p.perfil FROM %i p WHERE p.classe=ev.classe_trafego AND p.sessao=ev.sessao AND p.visitante=ev.visitante AND p.observado_em>=%d) AS perfil_aparelho',self::tabela(),F3Base_Editorial::corte_retencao());
    }
    public static function apresentar(array $ctx): array {
        $ref=$ctx['perfil_aparelho_ref']??[];
        $p=self::ler($ref); $out=[];
        foreach (self::ROTULOS as $k=>$label) { if (($p[$k]??'')!=='') { $out[$label]=$p[$k]; } }
        if (str_starts_with($p['faixa_fonte']??'','estimativa')) { $out['Faixa do aparelho'].=' (estimativa)'; }
        return $out;
    }
}
