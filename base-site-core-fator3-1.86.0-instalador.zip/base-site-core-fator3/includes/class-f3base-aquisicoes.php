<?php
/** Reserva de aquisição anterior aos destinos; GA4 não depende de deduplicação remota. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Aquisicoes {
    public const ESQUEMA_VERSAO=16400;
    public static function limpar(): void {global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE em<%d',self::tabela(),time()-DAY_IN_SECONDS));}
    public static function eliminar(string $id): bool {global $wpdb;return $wpdb->delete(self::tabela(),array('record_id'=>$id))!==false;}
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_aquisicoes';}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE {$t} (\nsessao char(32) NOT NULL,\nclasse varchar(16) NOT NULL,\nidentidade char(64) NOT NULL DEFAULT '',\nrecord_id char(32) NOT NULL,\nevent_id varchar(100) NOT NULL,\nem bigint unsigned NOT NULL,\nPRIMARY KEY  (sessao,classe,identidade),\nKEY registro (record_id),\nKEY retencao (em)\n) ENGINE=InnoDB {$wpdb->get_charset_collate()};");return !$wpdb->last_error;}
    public static function catalogo(array $c): array {$c['f3base_conversoes']=array('rotulo'=>'Contagem de conversões','descricao'=>'Uma aquisição por continuidade do contato na sessão evita somar formulário e clique no WhatsApp. Todas as ações permanecem no histórico de comportamento.','operavel'=>true,'secao'=>'medicao','campo'=>'grupo','autoload'=>false,'padrao'=>array('modo'=>'contato_sessao'),'subcampos'=>array('modo'=>array('tipo'=>'select','rotulo'=>'Quando contar nova conversão','opcoes'=>array('contato_sessao'=>'Uma por contato na sessão','por_acao'=>'Cada ação elegível'))),'schema_config'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('modo'=>array('type'=>'string','enum'=>array('contato_sessao','por_acao')))),'schema_entrada'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('modo'=>array('type'=>'string','enum'=>array('contato_sessao','por_acao')))),'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>static fn($v)=>is_array($v)&&in_array($v['modo']??'',array('contato_sessao','por_acao'),true)?'':'Escolha uma regra de contagem.');return F3Base_Conversoes_Conteudo::catalogo($c);}
    public static function reservar(array $lead): array {
        if (F3Base_Telefone::clique_sem_formulario($lead)) {
            return ['elegivel'=>false, 'codigo'=>'clique_sem_formulario', 'supressoes'=>[]];
        }
        $r=self::reservar_interno($lead);$r['supressoes']=array();if(F3Base_Meta_Lead::modo($lead)==='agente'){$r['supressoes']['meta']='aguardando_marcacao_agente';}foreach(array('ga4','google_ads','meta','linkedin') as $target){$code=F3Base_Contato_Identidade::bloqueio($lead,$target);if($code!==''){$r['supressoes'][$target]=$code;}}if(!empty($r['elegivel'])&&empty($r['supressoes']['meta'])){$matching=F3Base_Meta_Correspondencia::dados($lead);if($matching){$r['meta_correspondencia']=$matching;$r['meta_correspondencia_revisao']=F3Base_Options::revisao(F3Base_Meta_Correspondencia::OPTION);}}return $r;
    }
    public static function event_id(array $lead): string {return (string)($lead['dados']['meta_lead_event_id']??$lead['dados']['linkedin_conversao']['event_id']??(!empty($lead['correlacao'])?$lead['correlacao']:$lead['record_id']));}
    private static function reservar_interno(array $lead): array {
        $automation=F3Base_Audiencia::automacao((array)($lead['dados']['sinais_navegador']??$lead['dados']['sinais']??[]),(string)($lead['dados']['contexto']['user_agent']??$_SERVER['HTTP_USER_AGENT']??''));if(($automation['automacao']??'nao_identificada')!=='nao_identificada'||!empty($lead['dados']['audiencia_excluida'])){return ['elegivel'=>false,'codigo'=>'audiencia_excluida'];}
        if(!F3Base_Telefone::converter($lead)){return array('elegivel'=>false,'codigo'=>'contato_sem_identificador_suprimido');}
        $id=$lead['record_id'];$event=self::event_id($lead);$session=$lead['sessao']??'';$class=$lead['classe_trafego'];if(($lead['metodo']??'')==='conteudo'&&$session!==''){$session=F3Base_Conversoes_Conteudo::sessao($session,(string)($lead['formulario']??''));}
        if(!in_array($class,array('nao_marcado','teste'),true)||!in_array($lead['captura'],array('clique','aceito'),true)||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])){return array('elegivel'=>false,'codigo'=>'contato_inelegivel');}
        $cons=F3Base_Contato_Apresentacao::consentimento($lead['dados']);if(empty($cons['medicao'])&&empty($cons['publicidade'])){return array('elegivel'=>false,'codigo'=>'medicao_nao_permitida');}
        if(($lead['dados']['classificacao_contexto']??'')==='pendente'){return array('elegivel'=>false,'codigo'=>'classificacao_pendente','finalizacao'=>F3Base_Captura_Contexto::prova($lead));}if(in_array($lead['dados']['classificacao_contexto']??'',array('falha','excluida','saida_sem_classificacao','consentimento_negado'),true)){return array('elegivel'=>false,'codigo'=>'classificacao_ou_consentimento_nao_permite');}if($lead['captura']==='aceito'&&in_array($lead['metodo'],array('formulario','whatsapp_formulario'),true)&&empty($lead['dados']['audiencia_excluida'])){return array('elegivel'=>true,'event_id'=>$event,'codigo'=>'registro_aceito');}
        if($session===''||(F3Base_Options::ler('f3base_conversoes')['modo']??'contato_sessao')==='por_acao'){return array('elegivel'=>true,'event_id'=>$event,'codigo'=>$session===''?'sem_sessao_para_vincular':'por_acao');}
        $email=strtolower(trim($lead['email']??''));$phone=F3Base_Pipedrive_Api::telefone($lead['dados']['telefone']??'');$identity=is_email($email)?'email:'.$email:($phone?'telefone:'.$phone:'');$identity=$identity!==''?hash_hmac('sha256',$identity,wp_salt('auth')):'';
        $lock=F3Base_Trava::adquirir('aquisicao-'.$class.'-'.$session,15);if(!$lock){return array('elegivel'=>false,'codigo'=>'reserva_pendente');}global $wpdb;
        try{$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE sessao=%s AND classe=%s ORDER BY em DESC',self::tabela(),$session,$class),ARRAY_A);if($wpdb->last_error){return array('elegivel'=>false,'codigo'=>'reserva_indisponivel');}$found=null;$anon=null;foreach($rows as $r){if($r['identidade']===$identity){$found=$r;break;}if($r['identidade']===''){$anon=$r;}}
            if(!$found&&$identity===''&&$rows){$found=$rows[0];}
            if(!$found&&$anon&&$identity!==''){$found=$anon;if($wpdb->update(self::tabela(),array('identidade'=>$identity),array('sessao'=>$session,'classe'=>$class,'identidade'=>''))===false){return array('elegivel'=>false,'codigo'=>'reserva_indisponivel');}}
            if(!$found){$found=array('sessao'=>$session,'classe'=>$class,'identidade'=>$identity,'record_id'=>$id,'event_id'=>$event,'em'=>time());if($wpdb->insert(self::tabela(),$found)!==1){return array('elegivel'=>false,'codigo'=>'reserva_indisponivel');}}
            return array('elegivel'=>$found['record_id']===$id,'event_id'=>$found['event_id'],'codigo'=>$found['record_id']===$id?'aquisicao':'continuidade_mesma_sessao');
        }finally{F3Base_Trava::liberar($lock);}
    }
}
