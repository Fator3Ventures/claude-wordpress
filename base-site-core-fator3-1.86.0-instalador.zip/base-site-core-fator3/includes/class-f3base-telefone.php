<?php
/** A permissividade é do campo declarado no servidor; a marca não concede identidade. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Telefone {
    const OPTION='f3base_converter_contato_sem_identificador';
    private const DDD = [11,12,13,14,15,16,17,18,19,21,22,24,27,28,31,32,33,34,35,37,38,41,42,43,44,45,46,47,48,49,51,53,54,55,61,62,63,64,65,66,67,68,69,71,73,74,75,77,79,81,82,83,84,85,86,87,88,89,91,92,93,94,95,96,97,98,99];
    public static function analisar(string $valor, string $pais): array {
        $n = preg_replace('/[\s().-]+/u', '', trim($valor)) ?? '';
        if (!preg_match('/^\+?[0-9]*$/D', $n)) { return ['', 'caracteres_invalidos']; }
        if (str_starts_with($n, '+55')) {
            $pais = 'BR';
            $n = substr($n, 3);
        } elseif (str_starts_with($n, '+')) {
            return preg_match('/^\+[1-9][0-9]{6,14}$/D', $n) ? [$n, ''] : ['', 'formato_internacional'];
        } elseif ($pais === 'BR') {
            if (str_starts_with($n, '55') && in_array(strlen($n), [12,13], true)) { $n = substr($n, 2); }
            elseif (str_starts_with($n, '0')) { $n = substr($n, 1); }
        }
        if ($pais === 'BR') {
            $tamanho = strlen($n);
            if ($tamanho === 8 || $tamanho === 9) { return ['', 'sem_ddd']; }
            if ($tamanho !== 10 && $tamanho !== 11) { return ['', 'quantidade_digitos']; }
            if (!in_array((int)substr($n, 0, 2), self::DDD, true)) { return ['', 'ddd_invalido']; }
            if ($tamanho === 11 && $n[2] !== '9') { return ['', 'quantidade_digitos']; }
            if ($tamanho === 10 && $n[2] < '2') { return ['', 'prefixo_invalido']; }
            return ['+55'.$n, ''];
        }
        if ($pais === 'PT' && preg_match('/^[2-9][0-9]{8}$/D', $n)) { return ['+351'.$n, '']; }
        if (in_array($pais, ['US','CA'], true) && preg_match('/^[2-9][0-9]{9}$/D', $n)) { return ['+1'.$n, '']; }
        return ['', 'formato_pais'];
    }
    public static function classificacao(string $v,string $pais='BR'): array {
        $n=F3Base_Pipedrive_Api::telefone($v,$pais);$tipo='nao_classificado';$regra='telefone-internacional-sintatico';
        if(str_starts_with($n,'+55')&&F3Base_Pipedrive_Api::telefone(substr($n,3),'BR')===$n){$s=substr($n,5);$tipo=preg_match('/^(?:[6-9][0-9]{7}|9[0-9]{8})$/D',$s)?'celular':'fixo';$regra=$tipo==='fixo'?'br-fixo-8-prefixo-2-5':(strlen($s)===8?'br-celular-8-prefixo-6-9':'br-celular-9-prefixo-9');}
        elseif(str_starts_with($n,'+351')){$tipo=preg_match('/^\+3519[0-9]{8}$/D',$n)?'celular':'fixo';$regra='pt-prefixo-9';}
        elseif($n!==''){$tipo=str_starts_with($n,'+55')?'nao_classificado':'internacional';}
        return array('tipo'=>$tipo,'regra'=>$regra,'versao_regra'=>'1.85.0','nono_digito_inserido'=>false);
    }
    public static function livre(array $c): bool {return F3Base_Formularios::telefone_livre($c);}
    public static function diagnostico(string $v,string $pais,bool $livre=false): array {
        [$normal, $motivo] = self::analisar($v, $pais);
        $n = preg_replace('/\D/', '', $v);
        $classe=$normal!==''?'valido':($motivo==='sem_ddd'?'sem_ddd':($motivo==='quantidade_digitos'&&strlen($n)<($pais==='BR'?11:($pais==='PT'?9:10))?'incompleto':'outro'));
        return array('digitado'=>$v,'classe'=>$classe,'motivo'=>$motivo,'pais'=>$pais,'normalizado'=>$normal,'formato_livre'=>$livre,'regra'=>self::classificacao($v,$pais)['regra'],'classificacao'=>self::classificacao($v,$pais));
    }
    /** The single contact field accepts presence; only a valid normalized identity leaves this boundary. */
    public static function contato(string $digitado): array {
        $v=trim($digitado);
        if (str_contains($v, '@')) {
            $email = F3Base_Email_Contato::analisar($digitado);
            return $email + ['tipo'=>'email','telefone'=>'','email_normalizacao'=>$email];
        }
        $out=['digitado'=>$digitado,'tipo'=>'telefone','email'=>'','telefone'=>'','regra'=>'contato-1.85.0'];
        $d=self::diagnostico($v,F3Base_Options::ler('f3base_pipedrive')['pais_telefone']??'BR',true);
        $d['classe']=in_array($d['classe'],array('valido','sem_ddd'),true)?$d['classe']:'invalido';
        return array_replace($out,array('classe'=>$d['classe'],'telefone'=>$d['normalizado'],'diagnostico'=>$d));
    }
    public static function nao_normalizado(array $d): bool {
        $m=$d['telefone_normalizacao']??[];
        return !empty($m['formato_livre']) && ($m['classe']??'valido')!=='valido';
    }
    public static function sem_identificador(array $lead): bool {
        $d=$lead['dados']??$lead;
        if (is_email((string)($lead['email']??$d['email']??''))) { return false; }
        if (($d['email_normalizacao']['classe']??'') === 'invalido') {
            return F3Base_Pipedrive_Api::telefone((string)($d['telefone']??''),$d['telefone_normalizacao']['pais']??null)==='';
        }
        return self::nao_normalizado($d);
    }
    public static function clique_sem_formulario(array $lead): bool {
        return ($lead['captura'] ?? '') === 'clique'
            || in_array($lead['metodo'] ?? $lead['dados']['metodo'] ?? '', ['whatsapp_cta', 'contato_cta'], true);
    }
    public static function converter(array $lead): bool {
        return !self::clique_sem_formulario($lead)
            && (!self::sem_identificador($lead) || F3Base_Options::ler(self::OPTION) !== false);
    }
    public static function marca(array $lead): string {$d=$lead['dados']??$lead;return (string)($d['telefone_normalizacao']['classe']??'nao_observado');}
    public static function catalogo(array $c): array {
        $c[self::OPTION]=array('rotulo'=>'Contar contato sem telefone normalizado e sem e-mail válido','descricao'=>'Aplica-se ao telefone livre sem normalização ou ao e-mail inválido quando falta outro telefone ou e-mail válido. O padrão é desligado. Cliques em botões de contato sempre ficam fora das conversões. O registro e os avisos seguem as configurações do site.','operavel'=>true,'secao'=>'medicao','campo'=>'booleano','padrao'=>false,'schema_config'=>array('type'=>'boolean'),'schema_entrada'=>array('type'=>'boolean'),'sanitiza'=>static fn($v)=>(bool)filter_var($v,FILTER_VALIDATE_BOOLEAN),'recusa'=>static fn($v)=>in_array($v,array(true,false,0,1,'0','1'),true)?'':'Escolha ligado ou desligado.');return F3Base_Email_Contato::catalogo($c);
    }
}
