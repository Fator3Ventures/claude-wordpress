<?php
/** Finalização curta de contexto: prova vinculada à captura, origem e consentimento reconferidos. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Captura_Contexto {
    public const ESQUEMA_VERSAO=16400;
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_contexto_diagnostico';}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();$cc=$wpdb->get_charset_collate();dbDelta("CREATE TABLE {$t} (\ndia date NOT NULL,\nclasse varchar(20) NOT NULL,\nestado varchar(40) NOT NULL,\ntotal bigint unsigned NOT NULL DEFAULT 0,\nPRIMARY KEY  (dia,classe,estado)\n) {$cc};");return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
    }
    public static function diagnostico_publico(WP_REST_Request $req): WP_REST_Response {
        $origin=rtrim((string)$req->get_header('origin'),'/');$h=wp_parse_url(home_url());$expected=$h['scheme'].'://'.$h['host'].(isset($h['port'])?':'.$h['port']:'');$e=$req->get_json_params();$allowed=array('pendente','liberada','consentimento_negado','teste_destinos_restritos','excluida','falha_classificacao','saida_sem_classificacao');
        if($origin!==$expected||strlen($req->get_body())>1024||!is_array($e)||array_diff(array_keys($e),array('pagina','estados'))||!preg_match('/^[a-f0-9]{32}$/D',(string)($e['pagina']??''))||!is_array($e['estados']??null)||count($e['estados'])>7||array_filter($e['estados'],static fn($v)=>!is_string($v)||!in_array($v,$allowed,true))){return new WP_REST_Response(array('ok'=>false),400);}
        $guard=F3Base_Recuperacao::executar(static function()use($e){global $wpdb;if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like(self::tabela())))!==self::tabela()){return false;}
            if(!F3Base_Leads_Repositorio::quota('contexto-diag:'.floor(time()/60),5000,time()+120)){return false;}
            $class=F3Base_Audiencia::editor()?'editor':(($_COOKIE[F3Base_Testes::COOKIE]??'')==='1'?'teste':'nao_marcado');global $wpdb;
            foreach(array_unique($e['estados']) as $state){$key='contexto-diag:'.hash_hmac('sha256',$e['pagina'].'|'.$class.'|'.$state,wp_salt('nonce'));if(!F3Base_Leads_Repositorio::quota($key,1,time()+900)){continue;}if(false===$wpdb->query($wpdb->prepare('INSERT INTO %i (dia,classe,estado,total) VALUES (%s,%s,%s,1) ON DUPLICATE KEY UPDATE total=total+1',self::tabela(),gmdate('Y-m-d'),$class,$state))){return false;}}return true;
        });$r=new WP_REST_Response(array('ok'=>$guard===true),$guard===true?200:503);$r->header('Cache-Control','private, no-store, max-age=0');return $r;
    }
    public static function limpar_diagnostico(): void {global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE dia<%s',self::tabela(),gmdate('Y-m-d',F3Base_Retencao_Prazos::tecnico('diagnostico'))));}
    public static function iniciar(): void {
        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/contexto-diagnostico',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array(__CLASS__,'diagnostico_publico'))));
        add_action(F3Base_Leads_Notificacoes::EVENTO,array(__CLASS__,'limpar_diagnostico'));
        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/leads/contexto',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array(__CLASS__,'finalizar'))));
    }
    public static function resumo(): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT classe_trafego,COALESCE(JSON_UNQUOTE(JSON_EXTRACT(dados,'$.classificacao_contexto')),'nao_informada') classificacao,COUNT(*) quantidade FROM %i WHERE criado_em>=%s AND eliminacao_pendente=0 AND captura<>'eliminado' GROUP BY classe_trafego,classificacao",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s',time()-DAY_IN_SECONDS)),ARRAY_A);
        $pages=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like(self::tabela())))===self::tabela()?$wpdb->get_results($wpdb->prepare('SELECT dia,classe,estado,total FROM %i WHERE dia>=%s ORDER BY dia,classe,estado',self::tabela(),gmdate('Y-m-d',time()-DAY_IN_SECONDS)),ARRAY_A):array();return array('paginas_classificacao'=>$pages?:array(),'paginas_unidade'=>'Transições observadas por página e classe; não são confirmações de entrega ao destino. Estados não são somáveis como visitas. Sem URL, IP, UA ou identificador de visitante; silêncio não é falha comprovada.','ultimas_24h'=>$rows?:array(),'prazo_finalizacao_segundos'=>300,'cobertura'=>'Contatos confirmados pelo servidor. Pendência sem retorno não comprova falha remota nem recusa; PageViews não recebidos não são inventados.');
    }
    public static function prova(array $lead): array {
        $until=(strtotime($lead['criado_em'].' UTC')?:time())+300;$text=$lead['record_id'].'|'.$until;
        return array('url'=>rest_url(F3BASE_REST_NAMESPACE.'/leads/contexto'),'record_id'=>$lead['record_id'],'ate'=>$until,'prova'=>hash_hmac('sha256',$text,wp_salt('auth')));
    }
    public static function finalizar(WP_REST_Request $req): WP_REST_Response {
        $r=F3Base_Recuperacao::executar(static fn()=>self::finalizar_interno($req));if($r instanceof WP_REST_Response){return $r;}return new WP_REST_Response(array('ok'=>false,'codigo'=>'core_em_recuperacao'),503);
    }
    private static function finalizar_interno(WP_REST_Request $req): WP_REST_Response {
        $reply=static function(array $data,int $status=200){$r=new WP_REST_Response($data,$status);$r->header('Cache-Control','private, no-store, max-age=0');return $r;};
        $origin=rtrim((string)$req->get_header('origin'),'/');$home=wp_parse_url(home_url());$expected=$home['scheme'].'://'.$home['host'].(isset($home['port'])?':'.$home['port']:'');
        if(!hash_equals($expected,$origin)||strlen($req->get_body())>16384){return $reply(array('ok'=>false,'codigo'=>'origem_ou_corpo_invalido'),403);}
        $e=$req->get_json_params();if(!is_array($e)||array_diff(array_keys($e),array('record_id','ate','prova','sessao','visitante','navegacao','atribuicao','perfil_aparelho','largura_janela','max_touch_points','retorno','visitas','visitas_desde','visitas_minimo','estado'))){return $reply(array('ok'=>false,'codigo'=>'campos_invalidos'),400);}
        $id=(string)($e['record_id']??'');$at=(int)($e['ate']??0);$signature=(string)($e['prova']??'');if(!preg_match('/^[a-f0-9]{32}$/D',$id)||$at<time()||$at>time()+300||!hash_equals(hash_hmac('sha256',$id.'|'.$at,wp_salt('auth')),$signature)){return $reply(array('ok'=>false,'codigo'=>'prova_invalida_ou_vencida'),403);}
        $lock=F3Base_Trava::adquirir('contexto-captura-'.$id,15);if(!$lock){return $reply(array('ok'=>false,'codigo'=>'captura_ocupada'),409);}
        try{
            $l=F3Base_Leads_Repositorio::obter($id);if(!$l||$l['lixeira']||$l['eliminacao_pendente']||$l['captura']==='eliminado'){return $reply(array('ok'=>false,'codigo'=>'captura_indisponivel'),404);}
            if(($l['dados']['classificacao_contexto']??'')!=='pendente'){return $reply(array('ok'=>true,'codigo'=>'contexto_ja_finalizado','conversao'=>F3Base_Aquisicoes::reservar($l)));}
            $d=$l['dados'];$state=(string)($e['estado']??'permitida');if(!in_array($state,array('permitida','excluida','falha','saida'),true)){return $reply(array('ok'=>false,'codigo'=>'estado_invalido'),400);}
            $cons=F3Base_Contato_Apresentacao::consentimento($d);$med=!empty($cons['medicao'])&&F3Base_Modulo_Consentimento::permite_categoria('medicao');$allowed=!F3Base_Audiencia::editor()&&$state==='permitida'&&empty($d['audiencia_excluida'])&&($med||(!empty($cons['publicidade'])&&F3Base_Modulo_Consentimento::permite_categoria('publicidade')));
            $d['classificacao_contexto']=$allowed?'permitida':(F3Base_Audiencia::editor()||$state==='excluida'?'excluida':($state==='saida'?'saida_sem_classificacao':($state==='falha'?'falha':'consentimento_negado')));$d['classificacao_finalizada_em']=time();
            if($allowed){
                foreach(array('sessao','visitante','navegacao') as $key){if(!empty($e[$key])&&!F3Base_Leads_Contexto::sessao($e[$key])){return $reply(array('ok'=>false,'codigo'=>'identificador_invalido'),400);}}
                $attrs=$e['atribuicao']??array();if(!F3Base_Atribuicao::validar($attrs)){return $reply(array('ok'=>false,'codigo'=>'atribuicao_invalida'),400);}
                $new=F3Base_Leads_Contexto::capturar(array_merge($d,array_intersect_key($e,array_flip(array('sessao','visitante','navegacao','atribuicao','perfil_aparelho','largura_janela','max_touch_points','retorno','visitas','visitas_desde','visitas_minimo')))),$med);
                foreach(array('sessao','navegacao','atribuicao','atribuicao_reducao') as $k){$d[$k]=$new[$k]??null;}if(isset($new['contexto']['perfil_aparelho_ref'])){$d['contexto']['perfil_aparelho_ref']=$new['contexto']['perfil_aparelho_ref'];}$d['contexto']['audiencia']=$new['contexto']['audiencia']??array();$d['contexto']['sessao_motivo']='finalizada_apos_classificacao';
            }
            global $wpdb;$n=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d),'sessao'=>$d['sessao']??null,'revisao'=>(int)$l['revisao']+1,'atualizado_em'=>gmdate('Y-m-d H:i:s')),array('record_id'=>$id,'revisao'=>$l['revisao'],'eliminacao_pendente'=>0));if($n!==1){return $reply(array('ok'=>false,'codigo'=>'conflito_ou_persistencia'),409);}
            $l=F3Base_Leads_Repositorio::obter($id);$conversion=F3Base_Aquisicoes::reservar($l);if($allowed){F3Base_Modulo_Meta_Capi::agendar_registro($id,F3Base_Modulo_Consentimento::permite_categoria('publicidade'));}
            return $reply(array('ok'=>true,'codigo'=>'contexto_finalizado','classificacao'=>$d['classificacao_contexto'],'conversao'=>$conversion));
        }finally{F3Base_Trava::liberar($lock);}
    }
}
