<?php
/** Complementos idempotentes para destinos confirmados do mesmo contato. */
declare(strict_types=1);
defined('ABSPATH') || exit;
final class F3Base_Anuncio_Entrega {
    private const HOOK='f3base_anuncio_entrega';
    private static function key(string $id): string {return 'f3base_anuncio_entrega_'.$id;}
    public static function agendar(string $id,int $delay=5): void {
        if(preg_match('/^[a-f0-9]{32}$/D',$id) && !wp_next_scheduled(self::HOOK,[$id])){wp_schedule_single_event(time()+$delay,self::HOOK,[$id]);}
    }
    public static function eliminar(string $id): void {
        global $wpdb;
        wp_clear_scheduled_hook(self::HOOK,[$id]);
        delete_option(self::key($id));
        $wpdb->update(F3Base_Leads_Repositorio::tabela(),['anuncio_entrega'=>null],['record_id'=>$id]);
    }
    private static function salvar(string $id,array $s): void {
        global $wpdb;
        $json=wp_json_encode($s,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if ($json===false) { throw new RuntimeException('recibo_anuncio_invalido'); }
        $table=F3Base_Leads_Repositorio::tabela();
        $where=['record_id'=>$id,'lixeira'=>0,'eliminacao_pendente'=>0];
        $changed=$wpdb->update($table,['anuncio_entrega'=>$json],$where);
        if ($changed===false || ($changed===0 && $json!==$wpdb->get_var($wpdb->prepare(
            'SELECT anuncio_entrega FROM %i WHERE record_id=%s AND lixeira=0 AND eliminacao_pendente=0',$table,$id
        )))) { throw new RuntimeException('recibo_anuncio_nao_persistido'); }
    }
    private static function estado(array $lead): array {
        $json=$lead['anuncio_entrega']??null;
        if ($json===null) { return []; }
        return json_decode($json,true,512,JSON_THROW_ON_ERROR);
    }
    public static function detalhe(array $lead): array {
        if (!empty($lead['lixeira']) || !empty($lead['eliminacao_pendente'])) { return []; }
        $s=self::estado($lead);
        if (!$s) { return []; }
        $base=F3Base_Anuncio_Origem::base(F3Base_Contato_Apresentacao::montar($lead,false));
        if (!$base || ($s['vinculo']??'')!==self::vinculo($base)) { return []; }
        return array_intersect_key($s,array_flip(['trabalho','tentativas','consulta_em','codigo','fields','slack_estado',
            'slack_file','slack_canal','slack_thread','slack_share_ts','texto_ts','nota_estado','arquivo_estado','encerrado_em']));
    }
    /** Caller holds the per-contact lock. A failed copy leaves the option intact. */
    private static function importar(string $id,?array $lead): array {
        $s=$lead ? self::estado($lead) : [];
        $old=get_option(self::key($id),null);
        if ($old===null) { return $s; }
        if ($lead && !$lead['lixeira'] && !$lead['eliminacao_pendente'] && is_array($old) && !$s) {
            $s=$old;
            // 1.81.1 completed files privately and never checked shares.
            unset($s['slack_file'],$s['slack_bloqueado']);
            if (isset($s['slack_estado'])) { $s['slack_estado']='Compartilhamento aguardando conferência'; }
            $s['trabalho']='pendente';
            self::salvar($id,$s);
        }
        if ($s && !isset($s['encerrado_em'])) {
            self::agendar($id);
            if (!wp_next_scheduled(self::HOOK,[$id])) { return $s; }
        }
        delete_option(self::key($id));
        return $s;
    }
    public static function migrar(): void {
        global $wpdb;
        if (!F3Base_Leads_Repositorio::pronto()) { return; }
        $names=$wpdb->get_col($wpdb->prepare(
            'SELECT option_name FROM %i WHERE option_name LIKE %s AND option_name REGEXP %s ORDER BY option_id LIMIT 50',
            $wpdb->options,$wpdb->esc_like(self::key('')).'%','^f3base_anuncio_entrega_[0-9a-f]{32}$'
        ));
        foreach ($names as $name) {
            $id=substr($name,-32); $lock=F3Base_Trava::adquirir('anuncio-entrega-'.$id,180);
            if (!$lock) { continue; }
            try {
                $lead=F3Base_Leads_Repositorio::obter($id);
                if (!$wpdb->last_error) { self::importar($id,$lead); }
            } catch (RuntimeException $e) {
                // Keep this option intact for the next scheduled pass.
                continue;
            } finally { F3Base_Trava::liberar($lock); }
        }
        if (count($names)===50 && !wp_next_scheduled('f3base_anuncio_migrar')) {
            wp_schedule_single_event(time()+60,'f3base_anuncio_migrar');
        }
    }
    private static function encerrar(string $id,array &$s,string $status): void {
        $s['trabalho']=$status; $s['encerrado_em']=time();
        unset($s['inicio'],$s['tentativas']);
        self::salvar($id,$s);
        wp_clear_scheduled_hook(self::HOOK,[$id]);
    }
    public static function crm(array $lead,string $job=''): array {
        global $wpdb;$cfg=F3Base_Options::ler('f3base_pipedrive');
        if(empty($cfg['ativo']) || ($lead['classe_trafego']==='teste' && empty($cfg['homologacao']))){return [];}
        $where=$job?' AND chave=%s':'';
        $params=[F3Base_Pipedrive_Fila::tabela(),$lead['record_id']];if($job){$params[]=$job;}
        $r=$wpdb->get_row($wpdb->prepare("SELECT conta,journal,chave FROM %i WHERE record_id=%s AND estado='entregue' ".$where." ORDER BY atualizado_em DESC LIMIT 1",$params),ARRAY_A);
        $state=F3Base_Options::fotografia_bruta('f3base_pipedrive_estado')['valor']??[];
        $account=($state['dominio']??'').'|'.($state['conta_id']??'').'|'.($state['instalacao']??'');
        if(!$r || !$state || $r['conta']!==$account || ($state['dominio']??'')!==$cfg['dominio'] || !F3Base_Integracoes::pipedrive_verificado($state)){return [];}
        $opp=json_decode($r['journal'],true)['oportunidade']??[];$url=F3Base_Pipedrive_Comercial::link($opp,$cfg);
        return $url?['url'=>$url,'opp'=>$opp,'job'=>$r['chave']]:[];
    }
    public static function html(array $fields): string {
        $html='<p><strong>[IA] Anúncio de origem</strong></p>';
        foreach($fields as $key=>$v){
            $value=esc_html((string)$v);if(preg_match('~^https?://~i',$v)){$value='<a href="'.esc_url($v).'">'.$value.'</a>';}
            $html.='<p><strong>'.esc_html($key).'</strong> '.nl2br($value).'</p>';
        }return $html;
    }
    public static function consultar_ficha(): void {
        if(!current_user_can('manage_options') || !current_user_can('f3base_ler_leads')){wp_die('Sem permissão.','',['response'=>403]);}
        $id=sanitize_key(wp_unslash($_POST['record_id']??''));check_admin_referer('f3base-anuncio-'.$id);
        $lead=preg_match('/^[a-f0-9]{32}$/D',$id)?F3Base_Leads_Repositorio::obter($id):null;
        if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){wp_die('Contato indisponível.','',['response'=>404]);}
        $base=F3Base_Anuncio_Origem::base(F3Base_Contato_Apresentacao::montar($lead,false));
        if($base){
            $r=F3Base_Anuncio_Origem::resolver($base,$lead);
            set_transient('f3base_origem_ficha_'.get_current_user_id(),['id'=>$id,'vinculo'=>self::vinculo($base),'fields'=>$r['fields'],'consulta_em'=>time(),'codigo'=>$r['codigo']],300);
        }
        wp_safe_redirect(add_query_arg(['page'=>'f3base-leads','record_id'=>$id],admin_url('admin.php')).'#f3base-anuncio-origem');exit;
    }
    public static function ficha(array $a): void {
        $base=F3Base_Anuncio_Origem::base($a);if(!$base){return;}
        $s=self::detalhe(F3Base_Leads_Repositorio::obter($a['record_id'])??[]);
        $fields=$s['fields']??$base['fields'];
        $view=get_transient('f3base_origem_ficha_'.get_current_user_id());
        if(is_array($view) && $view['id']===$a['record_id'] && $view['vinculo']===self::vinculo($base)){
            $fields=$view['fields'];$s['consulta_em']=$view['consulta_em'];$s['codigo']=$view['codigo'];
        }
        echo '<div id="f3base-anuncio-origem">'.wp_kses_post(self::html($fields)).'</div>';
        if(!empty($s['consulta_em'])){
            echo '<p>Última consulta em '.esc_html(wp_date('d/m/Y H:i:s P',$s['consulta_em'])).'. ';
            echo ($s['codigo']??'')==='origem_consultada'?'Criativo consultado.':'Dados parciais. Confira a conta selecionada e a concessão de leitura no plugin da plataforma. Código: '.esc_html($s['codigo']??'origem_parcial').'.';
            echo '</p>';
        }
        if(current_user_can('manage_options')){
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_anuncio_consultar"><input type="hidden" name="record_id" value="'.esc_attr($a['record_id']).'">';
            wp_nonce_field('f3base-anuncio-'.$a['record_id']);echo '<button class="button">Consultar anúncio na plataforma</button></form>';
        }
        foreach(['slack_estado'=>'Arquivo no Slack','nota_estado'=>'Nota no Pipedrive','arquivo_estado'=>'Arquivo no Pipedrive'] as $key=>$label){
            if(!empty($s[$key])){echo '<p>'.esc_html($label.' · '.$s[$key]).'</p>';}
        }
    }
    private static function vinculo(array $b): string {return hash('sha256',wp_json_encode([$b['platform'],$b['account'],$b['campaign'],$b['ad']]));}
    private static function slack(array $lead): ?array {
        global $wpdb;
        if ($lead['classe_trafego']==='teste' && F3Base_Testes::politica('slack','teste')==='suprimir') { return null; }
        $table=F3Base_Slack::tabela();
        $p=$wpdb->get_row($wpdb->prepare(
            "SELECT o.*,p.ts AS thread_ts FROM %i o INNER JOIN %i p ON p.chave=o.principal AND p.aviso=o.aviso
             AND p.record_id=o.record_id AND p.destino=o.destino AND p.canal=o.canal AND p.tipo='principal' AND p.estado='entregue'
             WHERE o.record_id=%s AND o.tipo='origem' AND o.estado='entregue' AND o.destino=%s ORDER BY o.criada_em LIMIT 1",
            $table,$table,$lead['record_id'],F3Base_Slack::destino()
        ),ARRAY_A);
        return $p && preg_match('/^[CGD][A-Z0-9]+$/D',$p['canal']) && preg_match('/^[0-9]+\.[0-9]+$/D',$p['thread_ts'])
            && !F3Base_Slack_Manutencao::limpo($lead['record_id']) ? $p : null;
    }
    private static function arquivo_api(string $method,string $token,array $params): array {
        $url='https://slack.com/api/'.$method;
        $args=['headers'=>['Authorization'=>'Bearer '.$token],'timeout'=>8,'redirection'=>0,'limit_response_size'=>1048576];
        if ($method==='files.info') {
            $r=wp_remote_get(add_query_arg($params,$url),$args);
        } else {
            $r=wp_remote_post($url,$args+['body'=>$params]);
        }
        if (is_wp_error($r) || (int)wp_remote_retrieve_response_code($r)!==200) { return []; }
        return json_decode(wp_remote_retrieve_body($r),true)?:[];
    }
    private static function conferir_arquivo(string $id,array &$s,string $token): void {
        $fid=$s['slack_bloqueado']; $canal=$s['slack_canal']; $parent=$s['slack_thread'];
        $res=self::arquivo_api('files.info',$token,['file'=>$fid]);
        $file=$res['file']??[];
        $s['slack_estado']=($res['error']??'')==='missing_scope'?'Conferência requer files:read':'Compartilhamento na thread pendente';
        if (empty($res['ok']) || ($file['id']??'')!==$fid) { return; }
        foreach (['public','private'] as $visibility) {
            foreach ($file['shares'][$visibility][$canal]??[] as $share) {
                $ts=$share['ts']??'';
                if (!preg_match('/^[0-9]+\.[0-9]+$/D',$ts) || $ts===$parent) { continue; }
                $thread=$share['thread_ts']??'';
                if ($thread==='') {
                    $reply=F3Base_Slack::api('conversations.replies',$token,['channel'=>$canal,'ts'=>$parent,
                        'oldest'=>$ts,'latest'=>$ts,'inclusive'=>'true','limit'=>15]);
                    foreach ($reply['messages']??[] as $message) {
                        if (($message['ts']??'')===$ts && in_array($fid,array_column($message['files']??[],'id'),true)) {
                            $thread=$message['thread_ts']??''; break;
                        }
                    }
                }
                if ($thread!==$parent) { continue; }
                $s['slack_file']=$fid; $s['slack_share_ts']=$ts;
                $s['slack_estado']='Arquivo confirmado no canal e na thread';
                unset($s['slack_bloqueado']);
                self::salvar($id,$s);
                return;
            }
        }
    }
    private static function arquivo_slack(string $id,array &$s,?array $img,string $token,string $comment): void {
        if (!empty($s['slack_file'])) { return; }
        if (!empty($s['slack_bloqueado'])) { self::conferir_arquivo($id,$s,$token); return; }
        if (!$img) { return; }
        $ticket=self::arquivo_api('files.getUploadURLExternal',$token,['filename'=>$img['name'],'length'=>strlen($img['bytes'])]);
        if (empty($ticket['ok'])) {
            $s['slack_estado']=($ticket['error']??'')==='missing_scope'?'Permissão files:write ausente':'Reserva de arquivo pendente'; return;
        }
        $url=$ticket['upload_url']??''; $fid=$ticket['file_id']??'';
        if (!preg_match('~^https://files\.slack\.com/upload/v1/[^\s]+$~D',$url) || !preg_match('/^F[A-Z0-9]+$/D',$fid)) { return; }
        $r=wp_safe_remote_post($url,['timeout'=>8,'redirection'=>0,'headers'=>['Content-Type'=>'application/octet-stream'],'body'=>$img['bytes']]);
        if (is_wp_error($r) || wp_remote_retrieve_response_code($r)!==200) { return; }
        $s['slack_bloqueado']=$fid; $s['slack_estado']='Compartilhamento na thread pendente';
        if ($comment!=='') { $s['arquivo_texto_hash']=hash('sha256',$comment); }
        self::salvar($id,$s);
        $params=['files'=>wp_json_encode([['id'=>$fid,'title'=>'Anúncio de origem']]),'channel_id'=>$s['slack_canal'],'thread_ts'=>$s['slack_thread']];
        if ($comment!=='') { $params['initial_comment']=$comment; }
        $done=self::arquivo_api('files.completeUploadExternal',$token,$params);
        if (($done['ok']??null)===false && in_array($done['error']??'',['missing_scope','not_in_channel','channel_not_found','invalid_arguments'],true)) {
            unset($s['slack_bloqueado'],$s['arquivo_texto_hash']);
            $s['slack_estado']='Compartilhamento recusado pelo Slack · '.$done['error'];
        } else {
            self::conferir_arquivo($id,$s,$token);
        }
        self::salvar($id,$s);
    }
    private static function texto_slack(string $id,array &$s,string $token,array $msg,string $hash): bool {
        if (($s['texto_hash']??'')===$hash && !empty($s['texto_ts'])) { return true; }
        $body=$msg+['channel'=>$s['slack_canal']];
        if (!empty($s['texto_ts'])) {
            $r=F3Base_Slack::api('chat.update',$token,$body+['ts'=>$s['texto_ts']]);
        } elseif (!empty($s['texto_pendente'])) {
            // Recover an accepted message after a timeout without posting it again.
            $page=F3Base_Slack::api('conversations.replies',$token,['channel'=>$s['slack_canal'],'ts'=>$s['slack_thread'],'limit'=>15]
                +(!empty($s['texto_cursor'])?['cursor'=>$s['texto_cursor']]:[]));
            if (empty($page['ok'])) { return false; }
            foreach ($page['messages'] as $row) {
                if (($row['thread_ts']??'')===$s['slack_thread'] && ($row['client_msg_id']??'')===$s['texto_pendente']
                    && preg_match('/^[0-9]+\.[0-9]+$/D',$row['ts']??'')) {
                    $s['texto_ts']=$row['ts']; $s['texto_hash']=$s['texto_envio_hash'];
                    unset($s['texto_pendente'],$s['texto_envio_hash'],$s['texto_cursor']);
                    self::salvar($id,$s);
                    return self::texto_slack($id,$s,$token,$msg,$hash);
                }
            }
            $s['texto_cursor']=$page['cursor']??''; return false;
        } else {
            $s['texto_pendente']=wp_generate_uuid4(); $s['texto_envio_hash']=$hash; self::salvar($id,$s);
            $r=F3Base_Slack::api('chat.postMessage',$token,$body+['thread_ts'=>$s['slack_thread'],'client_msg_id'=>$s['texto_pendente']]);
        }
        if (!empty($r['ok'])) { $s['texto_ts']=$r['ts']; $s['texto_hash']=$hash; }
        if (!empty($r['ok']) || !empty($r['recusado']) || isset($r['retry_after'])) {
            unset($s['texto_pendente'],$s['texto_envio_hash'],$s['texto_cursor']);
        }
        self::salvar($id,$s);
        return !empty($r['ok']);
    }
    private static function complementar(string $id,array &$s,array $part,array $fields,?array $img,bool $enriched): bool {
        if (isset($s['slack_destino']) && $s['slack_destino']!==$part['destino']) { return false; }
        if (isset($s['slack_thread']) && ($s['slack_thread']!==$part['thread_ts'] || $s['slack_canal']!==$part['canal'])) { return false; }
        $s['slack_destino']=$part['destino']; $s['slack_thread']=$part['thread_ts']; $s['slack_canal']=$part['canal'];
        $token=F3Base_Segredos::abrir(F3Base_Slack::SEGREDO);
        if (!$token) { return false; }
        $msg=F3Base_Slack_Thread::mensagem('Anúncio de origem',$fields);
        $comment=F3Base_Avisos::texto($msg['text']); $hash=hash('sha256',$comment);
        self::arquivo_slack($id,$s,$img,$token,isset($s['texto_ts'])||isset($s['texto_pendente'])?'':$comment);
        if (($s['arquivo_texto_hash']??'')===$hash) { return !empty($s['slack_file']); }
        if (!$enriched) { return true; }
        return self::texto_slack($id,$s,$token,$msg,$hash);
    }
    private static function criar(string $id,array &$s,string $type,string $path,array $body): void {
        if(!empty($s[$type.'_id'])||!empty($s[$type.'_incerto'])){return;}
        $s[$type.'_incerto']=true;$s[$type.'_estado']='Escrita sem confirmação';self::salvar($id,$s);
        $r=F3Base_Pipedrive_Api::pedir('POST',$path,$body);
        if(!empty($r['ok']) && ctype_digit((string)($r['data']['id']??'')) && (int)$r['data']['id']>0){$s[$type.'_id']=(int)$r['data']['id'];unset($s[$type.'_incerto']);$s[$type.'_estado']='Confirmado';}
        elseif(empty($r['incerto']) && empty($r['ok'])){unset($s[$type.'_incerto']);$s[$type.'_estado']=$r['codigo'];}
        self::salvar($id,$s);
    }
    private static function pipedrive(string $id,array &$s,array $crm,array $fields,?array $image): void {
        if(isset($s['crm_job']) && $s['crm_job']!==$crm['job']){return;}
        $s['crm_job']=$crm['job'];$opp=$crm['opp'];$object=$opp['tipo']==='lead'?'lead':'deal';$target=[$object.'_id'=>$opp['id']];
        $body=['content'=>self::html($fields),'pinned_to_'.$object.'_flag'=>1]+$target;
        $hash=hash('sha256',$body['content']);F3Base_Pipedrive_Api::iniciar_lote();
        $cfg=F3Base_Pipedrive_Api::configuracao_lote();
        if(F3Base_Pipedrive_Comercial::link($opp,$cfg)!==$crm['url']){return;}
        if(empty($s['nota_id'])){
            self::criar($id,$s,'nota','v1/notes',$body);
            if(!empty($s['nota_id'])){$s['nota_hash']=$hash;}
        }elseif(($s['nota_hash']??'')!==$hash){
            $r=F3Base_Pipedrive_Api::pedir('PUT','v1/notes/'.$s['nota_id'],['content'=>$body['content'],'pinned_to_'.$object.'_flag'=>1]);
            if(!empty($r['ok']) && (int)($r['data']['id']??0)===$s['nota_id']){$s['nota_hash']=$hash;}
        }
        if($image && !empty($s['nota_id'])){self::criar($id,$s,'arquivo','v1/files',$target+['file'=>$image]);}
    }
    public static function executar(string $id): void {
        if(!preg_match('/^[a-f0-9]{32}$/D',$id)){return;}
        if(!F3Base_Recuperacao::entrar()){self::agendar($id,3600);return;}
        $lock=F3Base_Trava::adquirir('anuncio-entrega-'.$id,180);if(!$lock){F3Base_Recuperacao::sair();self::agendar($id,210);return;}
        try{
            $recovery=F3Base_Recuperacao::ler();if(empty($recovery['ok'])||!empty($recovery['pausado'])){self::agendar($id,3600);return;}
            $lead=F3Base_Leads_Repositorio::obter($id);
            global $wpdb;
            if ($wpdb->last_error) { self::agendar($id,300); return; }
            if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||F3Base_Formulario_Antispam::aviso_barrado($lead)){self::eliminar($id);return;}
            $a=F3Base_Contato_Apresentacao::montar($lead,false);$base=F3Base_Anuncio_Origem::base($a);
            $s=self::importar($id,$lead);
            if (!$base) { if ($s) { self::eliminar($id); } return; }
            if (($s['trabalho']??'')==='expirado') { return; }
            if (isset($s['inicio']) && time() >= $s['inicio']+30*DAY_IN_SECONDS) {
                self::encerrar($id,$s,'expirado'); return;
            }
            $p=self::slack($lead);$crm=self::crm($lead);if(!$p && !$crm){if ($s && empty($s['encerrado_em'])) { self::encerrar($id,$s,'sem_destino'); }return;}
            $binding=self::vinculo($base);
            if(isset($s['vinculo']) && $s['vinculo']!==$binding){self::encerrar($id,$s,'origem_alterada');return;}$s['vinculo']=$binding;
            if(isset($s['geracao']) && $s['geracao']!==($recovery['geracao']??0)){self::encerrar($id,$s,'geracao_alterada');return;}
            $destinos=hash('sha256',wp_json_encode([$p['chave']??null,$crm['job']??null]));
            if (($s['trabalho']??'')==='concluido' && ($s['destinos']??'')===$destinos) { return; }
            $s['destinos']=$destinos; $s['trabalho']='pendente'; unset($s['encerrado_em']);
            $s['geracao']=$recovery['geracao']??0;
            $s['inicio']??=time();$s['tentativas']=($s['tentativas']??0)+1;
            // Próxima passagem também recupera a interrupção entre escrita remota e recibo.
            if(time()-$s['inicio']<30*DAY_IN_SECONDS){self::agendar($id,min(DAY_IN_SECONDS,300*2**min(8,$s['tentativas']-1)));}
            $r=F3Base_Anuncio_Origem::resolver($base,$lead);
            $fields=array_replace($s['fields']??[],$r['fields']);$s['fields']=$fields;$s['consulta_em']=time();$s['codigo']=$r['codigo'];
            $needImage=($p && empty($s['slack_file']) && empty($s['slack_bloqueado'])) || ($crm && empty($s['arquivo_id']));
            $img=$needImage?F3Base_Anuncio_Origem::imagem($r['media']):null;
            // Revalidar o contato e os destinos após a leitura do fornecedor.
            $lead=F3Base_Leads_Repositorio::obter($id);
            if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||F3Base_Formulario_Antispam::aviso_barrado($lead)){return;}
            $fresh=F3Base_Contato_Apresentacao::montar($lead,false);$updated=F3Base_Anuncio_Origem::base($fresh);
            $now=F3Base_Recuperacao::ler();
            if(!$updated || self::vinculo($updated)!==$binding || empty($now['ok']) || !empty($now['pausado']) || ($now['geracao']??0)!==$s['geracao']){return;}
            $p=self::slack($lead);$crm=self::crm($lead);$edited=true;
            if ($p) {
                $enriched=$r['complete'] || $fields!==$base['fields'];
                $headerOk=!$enriched || F3Base_Slack_Thread::corrigir_titulo($p,$fresh,$fields);
                $delivered=self::complementar($id,$s,$p,$fields,$img,$enriched);
                if (!$delivered && $enriched && !empty($s['slack_bloqueado'])) {
                    $copy=F3Base_Slack_Thread::mensagens($fresh,[],$fields,null,$s['slack_estado']??'');
                    if (isset($copy[2])) { F3Base_Slack_Thread::editar($p,$copy[2]); }
                }
                $edited=$delivered && $headerOk;
            }
            if($crm){self::pipedrive($id,$s,$crm,$fields,$img);}
            self::salvar($id,$s);
            $noteOk=!$crm || (!empty($s['nota_id']) && ($s['nota_hash']??'')===hash('sha256',self::html($fields)));
            if($r['complete'] && empty($s['slack_bloqueado']) && $edited && $noteOk && (!$r['media'] || ((!$p||!empty($s['slack_file'])) && (!$crm||!empty($s['arquivo_id']))))){self::encerrar($id,$s,'concluido');}
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
}
