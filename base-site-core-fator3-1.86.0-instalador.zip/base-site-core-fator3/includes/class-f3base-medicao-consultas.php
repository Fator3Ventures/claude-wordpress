<?php
/** Consultas administrativas limitadas; não migram, não coletam e não expõem corpos de leads. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Medicao_Consultas {
	public const LIMITE   = 200;
	public const MAX_DIAS = 90;
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		foreach ( array( 'comportamento', 'eventos', 'leads' ) as $tipo ) {
			F3Base_Servicos::registrar_ability(
				'f3base/' . $tipo . '-ler',
				array(
					'label'               => 'Ler ' . $tipo,
					'description'         => 'Consulta administrativa de medição, limitada e paginada. Não executa coleta nem altera dados. Contagens independentes não representam funil por coorte.',
					'category'            => F3BASE_PREFIXO,
					'input_schema'        => array(
						'type'                 => 'object',
						'additionalProperties' => false,
						'properties'           => ($tipo==='eventos'?['agrupar_por'=>['type'=>'string','enum'=>['destino','secao','alvo']]]:[]) + array(
							'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'segmento'=>array('type'=>'string','enum'=>F3Base_Testes::SEGMENTOS),
                            'formulario'=>array('type'=>'string','pattern'=>'^[a-z0-9_-]{1,80}$'),
                            'dias'    => array(
								'type'    => 'integer',
								'minimum' => 1,
								'maximum' => self::MAX_DIAS,
								'default' => 30,
							),
							'caminho' => array(
								'type'      => 'string',
								'maxLength' => 190,
							),
							'metrica' => array(
								'type'      => 'string',
								'maxLength' => 64,
							),
							'sessao'  => array(
								'type'    => 'string',
								'pattern' => '^[a-f0-9]{32}$',
							),
							'limite'  => array(
								'type'    => 'integer',
								'minimum' => 1,
								'maximum' => self::LIMITE,
								'default' => self::LIMITE,
							),
							'cursor'  => array(
								'type'      => 'string',
								'maxLength' => 2048,
							),
						),
					),
					'output_schema'       => self::schema(),
					'permission_callback' => static fn() => current_user_can( 'manage_options' ),
					'execute_callback'    => static fn( $e = null ) => self::consultar( $tipo, is_array( $e ) ? $e : array() ),
					'meta'                => array(
						'show_in_rest' => true,
						'mcp'          => array( 'public' => true ),
						'annotations'  => array(
							'readonly'    => true,
							'destructive' => false,
							'idempotent'  => true,
						),
					),
				)
			);
		}
	}
	private static function schema(): array {
		$linha = ['nova_aba'=>['type'=>'boolean']];
		foreach ( array( 'tipo','destino','secao','alvo','classe','texto','dia', 'caminho', 'metrica', 'detalhe', 'origem', 'sessao', 'regra', 'fuso', 'qualidade', 'ancora', 'classe_trafego' ) as $k ) {
			$linha[ $k ] = array( 'type' => 'string' ); }
		foreach ( array( 'id', 'contagem', 'ocorrencia', 'ms', 'criado_em', 'maior_ocorrencia' ) as $k ) {
			$linha[ $k ] = array( 'type' => 'integer' ); }
		foreach ( array( 'soma', 'valor' ) as $k ) {
			$linha[ $k ] = array( 'type' => 'number' ); }
		return array(
			'type'       => 'object',
			'properties' => array(
				'recusas_por_campo'=>array('type'=>'object'),
                'segmento'=>array('type'=>'string','enum'=>F3Base_Testes::SEGMENTOS),
                'inicio'           => array( 'type' => 'string' ),
				'fim'              => array( 'type' => 'string' ),
				'fuso'             => array( 'type' => 'string' ),
				'regra'            => array( 'type' => 'string' ),
				'fotografia_em'    => array( 'type' => 'integer' ),
				'cursor_base_em'   => array( 'type' => 'integer' ),
				'limite'           => array( 'type' => 'integer' ),
				'proximo_cursor'   => array( 'type' => 'string' ),
				'corte'            => array( 'type' => 'boolean' ),
				'fonte_disponivel' => array( 'type' => 'boolean' ),
				'contagens_exatas' => array( 'type' => 'boolean' ),
				'retencao_dias'    => array( 'type' => 'integer' ),
				'retencao_meses'   => array( 'type' => 'integer' ),
				'corte_retencao'   => array( 'type' => 'string' ),
				'linhas'           => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => $linha,
					),
				),
				'totais'           => array(
					'type'       => 'object',
					'properties' => array(
						'eventos'    => array( 'type' => 'integer' ),
						'visitantes' => array( 'type' => 'integer' ),
						'sessoes'    => array( 'type' => 'integer' ),
						'cortadas'   => array( 'type' => 'integer' ),
						'erro_js'    => array( 'type' => 'integer' ),
						'leads'      => array( 'type' => 'integer' ),
					),
				),
				'cobertura'        => array(
					'type'       => 'object',
					'properties' => array(
						'primeiro_registro' => array( 'type' => 'string' ),
						'ultimo_registro'   => array( 'type' => 'string' ),
						'motivo'            => array( 'type' => 'string' ),
					),
				),
				'recusas'          => array( 'type' => 'object' ),
				'avisos'           => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
			),
		);
	}
	public static function janela( int $dias, bool $hoje = true ): array {
		$d = new DateTimeImmutable( 'today', wp_timezone() );
		if ( ! $hoje ) {
			$d = $d->modify( '-1 day' ); }
		$a = $d->modify( '-' . ( max( 1, min( self::MAX_DIAS, $dias ) ) - 1 ) . ' days' );
		$b = $d->modify( '+1 day' );
		return array(
			'inicio'     => $a->format( 'Y-m-d' ),
			'fim'        => $d->format( 'Y-m-d' ),
			'inicio_utc' => $a->getTimestamp(),
			'fim_utc'    => $b->getTimestamp(),
		);
	}
	private static function cursor( array $dados ): string {
		$j = base64_encode( wp_json_encode( $dados ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Cursor JSON autenticado por HMAC; não executa nem desserializa código.
		return $j . '.' . hash_hmac( 'sha256', $j, wp_salt( 'nonce' ) ); }
	private static function abrir_cursor( string $cursor ): ?array {
		$v = explode( '.', $cursor );
		if ( count( $v ) !== 2 || ! hash_equals( hash_hmac( 'sha256', $v[0], wp_salt( 'nonce' ) ), $v[1] ) ) {
			return null; }
		$d = json_decode( (string) base64_decode( $v[0], true ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Cursor JSON autenticado por HMAC; não executa nem desserializa código.
		return is_array( $d ) ? $d : null;
	}
	public static function consultar( string $tipo, array $e = array() ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'f3base_medicao_sem_permissao', 'Sem permissão.', array( 'status' => 403 ) ); }
		if ( ! in_array( $tipo, array( 'comportamento', 'eventos', 'leads' ), true ) ) {
			return new WP_Error( 'f3base_medicao_tipo', 'Consulta não permitida.' ); }
		global $wpdb;
		$dias   = max( 1, min( self::MAX_DIAS, (int) ( $e['dias'] ?? 30 ) ) );
		$limite = max( 1, min( self::LIMITE, (int) ( $e['limite'] ?? self::LIMITE ) ) );
		$j      = self::janela( $dias );
        if(isset($e['de'])||isset($e['ate'])){try{$a=F3Base_Relatorios::janela($e);$j=array('inicio'=>$a['de'],'fim'=>$a['ate'],'inicio_utc'=>$a['inicio'],'fim_utc'=>$a['fim']);$dias=$a['dias'];}catch(Throwable $x){return new WP_Error('periodo_invalido','Período inválido.');}}
		try{$segmento=F3Base_Testes::segmento($e['segmento']??null);}catch(Throwable $ex){return new WP_Error('segmento_invalido','Segmento inválido.');}
        $grupo=$e['agrupar_por'] ?? '';
        if ($grupo!=='') {
            if ($tipo!=='eventos' || !in_array($grupo,['destino','secao','alvo'],true) || ($e['metrica'] ?? F3Base_Clique_Link::METRICA)!==F3Base_Clique_Link::METRICA) {
                return new WP_Error('agrupamento_invalido','Agrupe cliques por destino, seção ou alvo.');
            }
            $e['metrica']=F3Base_Clique_Link::METRICA;
        }
        $filtro = array( $j['inicio'], $j['fim'], $segmento, $tipo, $dias, (string) ( $e['caminho'] ?? '' ), (string) ( $e['metrica'] ?? '' ), (string) ( $e['sessao'] ?? '' ), wp_timezone_string() );
		$filtro[]=(string)($e['formulario']??'');if ($grupo!=='') { $filtro[]=$grupo; } $hash   = hash( 'sha256', wp_json_encode( $filtro ) );
		$cursor = empty( $e['cursor'] ) ? array() : self::abrir_cursor( (string) $e['cursor'] );
		if ( null === $cursor || ( $cursor && ( ( $cursor['filtro'] ?? '' ) !== $hash || (int) ( $cursor['ate'] ?? 0 ) < time() - HOUR_IN_SECONDS ) ) ) {
			return new WP_Error( 'f3base_medicao_cursor', 'Cursor inválido, vencido ou de outro filtro.' ); }
		$foto    = (int) ( $cursor['ate'] ?? time() );
		$config  = F3Base_Options::ler( 'f3base_comportamento' );
		$r       = array(
			'segmento' => $segmento,
            'inicio'           => $j['inicio'],
			'fim'              => $j['fim'],
			'fuso'             => wp_timezone_string(),
			'regra'            => F3Base_Modulo_Comportamento::regra_calendario(),
			'fotografia_em'    => time(),
			'cursor_base_em'   => $foto,
			'limite'           => $limite,
			'proximo_cursor'   => '',
			'corte'            => false,
			'fonte_disponivel' => false,
			'contagens_exatas' => true,
			'retencao_dias'    => 'comportamento' === $tipo ? F3Base_Modulo_Comportamento::retencao_dias() : F3Base_Modulo_Comportamento::retencao_eventos_dias(),
			'linhas'           => array(),
			'totais'           => (object) array(),
			'cobertura'        => array(
				'primeiro_registro' => '',
				'ultimo_registro'   => '',
				'motivo'            => 'Ausência de registros não comprova zero acessos. Dados sujeitos a consentimento, retenção e limites.',
			),
			'recusas'          => (object) array(),
			'avisos'           => array(),
		);
		if($tipo==='comportamento'){$r['recusas_por_campo']=F3Base_Formulario_Tentativas::resumo(array_intersect_key($e,array_flip(array('de','ate','dias','segmento','formulario','sessao','caminho'))));if(!empty($e['formulario'])||!empty($e['sessao'])){$r['avisos'][]='Os filtros formulário e sessão delimitam recusas_por_campo; as linhas agregadas de comportamento não têm essas dimensões.';}}
        $eventos = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA_EVENTOS;
		if ( 'leads' === $tipo ) {
			if ( ! empty( $e['caminho'] ) || ! empty( $e['metrica'] ) || ! empty( $e['sessao'] ) ) {
				return new WP_Error( 'f3base_medicao_filtro', 'A consulta de leads aceita somente janela e paginação.' );
			} return self::leads( $r, $j, $dias, $limite, $cursor, $hash ); }
		$pronta = 'eventos' === $tipo ? F3Base_Modulo_Comportamento::eventos_prontos() : F3Base_Modulo_Comportamento::tabela_pronta();
		if ( ! $pronta ) {
			return $r;
		} $r['fonte_disponivel'] = true;
		$t                       = 'eventos' === $tipo ? $eventos : $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA;
		$where                   = 'eventos' === $tipo ? $wpdb->prepare( 'criado_em >= %d AND criado_em < %d', $j['inicio_utc'], $j['fim_utc'] ) : $wpdb->prepare( 'dia >= %s AND dia <= %s', $j['inicio'], $j['fim'] );
		$where .= F3Base_Testes::sql($segmento);
        foreach ( array( 'caminho', 'metrica' ) as $campo ) {
			if ( ! empty( $e[ $campo ] ) ) {
				$where .= $wpdb->prepare( " AND {$campo} = %s", (string) $e[ $campo ] ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
		}
		if ( ! empty( $e['sessao'] ) && $tipo!=='comportamento' ) {
			if ( 'eventos' !== $tipo || ! preg_match( '/^[a-f0-9]{32}$/D', (string) $e['sessao'] ) ) {
				return new WP_Error( 'f3base_medicao_sessao', 'Sessão permitida apenas na consulta de eventos.' );
			} $where .= $wpdb->prepare( ' AND sessao = %s', $e['sessao'] ); }
		$wpdb->query( 'START TRANSACTION WITH CONSISTENT SNAPSHOT' );
		try {
			if ( 'eventos' === $tipo ) {
				$max                                 = (int) ( $cursor['max'] ?? $wpdb->get_var( "SELECT COALESCE(MAX(id),0) FROM {$t}" ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
				$where                              .= $wpdb->prepare( ' AND id <= %d', $max );
				$tot                                 = $wpdb->get_row( "SELECT COUNT(*) AS eventos,COUNT(DISTINCT NULLIF(visitante,'')) AS visitantes,COUNT(DISTINCT NULLIF(sessao,'')) AS sessoes,MIN(criado_em) AS primeiro,MAX(criado_em) AS ultimo FROM {$t} WHERE {$where}", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
				$r['totais']                         = array_map( 'intval', array_intersect_key( $tot ? $tot : array(), array_flip( array( 'eventos', 'visitantes', 'sessoes' ) ) ) );
				$r['cobertura']['primeiro_registro'] = empty( $tot['primeiro'] ) ? '' : wp_date( DATE_ATOM, (int) $tot['primeiro'] );
				$r['cobertura']['ultimo_registro']   = empty( $tot['ultimo'] ) ? '' : wp_date( DATE_ATOM, (int) $tot['ultimo'] );
                if ($grupo!=='') {
                    // O menor ID de cada grupo é único e cabe em um cursor curto mesmo para URLs extensas.
                    $coluna='link_'.$grupo;
                    $depois=(int)($cursor['grupo_id'] ?? 0);
                    $sql="SELECT MIN(id) AS grupo_id,BINARY {$coluna} AS {$grupo},COUNT(*) AS contagem FROM {$t} WHERE {$where} GROUP BY BINARY {$coluna},SHA2({$coluna},256) HAVING MIN(id)>%d ORDER BY MIN(id) LIMIT %d";
                    $linhas=$wpdb->get_results($wpdb->prepare($sql,$depois,$limite+1),ARRAY_A);
                    if ($wpdb->last_error) { return new WP_Error('consulta_falhou','Falha ao agrupar cliques.'); }
                    $r['corte']=count($linhas)>$limite;
                    foreach (array_slice($linhas,0,$limite) as $linha) { $r['linhas'][]=[$grupo=>$linha[$grupo],'contagem'=>(int)$linha['contagem']]; $depois=(int)$linha['grupo_id']; }
                    if ($r['corte']) { $r['proximo_cursor']=self::cursor(['filtro'=>$hash,'ate'=>$foto,'max'=>$max,'grupo_id'=>$depois]); }
                    return $r;
                }
				if ( ! empty( $cursor['ultimo'] ) ) {
					$a      = $cursor['ultimo'];
					$where .= $wpdb->prepare( ' AND (criado_em > %d OR (criado_em = %d AND ms > %d) OR (criado_em = %d AND ms = %d AND id > %d))', $a[0], $a[0], $a[1], $a[0], $a[1], $a[2] ); }
				$r['linhas'] = (array) $wpdb->get_results( $wpdb->prepare( "SELECT classe_trafego,id,sessao,dia,caminho,metrica,detalhe,valor,ocorrencia,ms,criado_em,ancora,link_tipo,link_destino,link_secao,link_alvo,link_classe,link_texto,link_nova_aba FROM {$t} WHERE {$where} ORDER BY criado_em,ms,id LIMIT %d", $limite + 1 ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
				$r['corte']  = count( $r['linhas'] ) > $limite;
				$r['linhas'] = array_slice( $r['linhas'], 0, $limite );
				if ( $r['corte'] ) {
					$u                   = end( $r['linhas'] );
					$r['proximo_cursor'] = self::cursor(
						array(
							'filtro' => $hash,
							'ate'    => $foto,
							'max'    => $max,
							'ultimo' => array( (int) $u['criado_em'], (int) $u['ms'], (int) $u['id'] ),
						)
					); }
				$r['avisos'][] = 'Cursor fixa o maior ID da fotografia; retenção ou exclusão posterior pode retirar eventos. Identificador de visitante não é retornado.';
			} else {
				$tot                                 = $wpdb->get_row( "SELECT SUM(CASE WHEN metrica='f3base_cortadas' THEN 0 ELSE contagem END) AS eventos,SUM(CASE WHEN metrica='f3base_cortadas' THEN contagem ELSE 0 END) AS cortadas,SUM(CASE WHEN metrica='f3base_erro_js' THEN contagem ELSE 0 END) AS erro_js,MIN(dia) AS primeiro,MAX(dia) AS ultimo FROM {$t} WHERE {$where}", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
				$r['totais']                         = array_map( 'intval', array_intersect_key( $tot ? $tot : array(), array_flip( array( 'eventos', 'cortadas', 'erro_js' ) ) ) );
				$r['cobertura']['primeiro_registro'] = (string) ( $tot['primeiro'] ?? '' );
				$r['cobertura']['ultimo_registro']   = (string) ( $tot['ultimo'] ?? '' );
				if ( ! empty( $cursor['ultimo'] ) ) {
					$where .= $wpdb->prepare( ' AND chave > %s', $cursor['ultimo'] ); }
				$r['linhas'] = (array) $wpdb->get_results( $wpdb->prepare( "SELECT classe_trafego,chave,dia,caminho,metrica,detalhe,contagem,soma,regra,fuso,qualidade FROM {$t} WHERE {$where} ORDER BY chave LIMIT %d", $limite + 1 ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
				$r['corte']  = count( $r['linhas'] ) > $limite;
				$r['linhas'] = array_slice( $r['linhas'], 0, $limite );
				if ( $r['corte'] ) {
					$u                   = end( $r['linhas'] );
					$r['proximo_cursor'] = self::cursor(
						array(
							'filtro' => $hash,
							'ate'    => $foto,
							'ultimo' => $u['chave'],
						)
					); }
				foreach ( $r['linhas'] as &$l ) {
					unset( $l['chave'] );
				} unset( $l );
				if ( F3Base_Modulo_Comportamento::eventos_prontos() ) {
					$ew = $wpdb->prepare( 'criado_em >= %d AND criado_em < %d', $j['inicio_utc'], $j['fim_utc'] ) . F3Base_Testes::sql($segmento);
					foreach ( array( 'caminho', 'metrica' ) as $c ) {
						if ( ! empty( $e[ $c ] ) ) {
							$ew .= $wpdb->prepare( " AND {$c} = %s", $e[ $c ] ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
					}
					$dist         = $wpdb->get_row( "SELECT COUNT(DISTINCT NULLIF(visitante,'')) AS visitantes,COUNT(DISTINCT NULLIF(sessao,'')) AS sessoes FROM {$eventos} WHERE {$ew}", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
					$r['totais'] += array_map( 'intval', $dist ? $dist : array() );

					$ocorrencias = array();
					foreach ( (array) $wpdb->get_results( "SELECT caminho,metrica,detalhe,MAX(ocorrencia) AS maior FROM {$eventos} WHERE {$ew} GROUP BY caminho,metrica,detalhe LIMIT 10001", ARRAY_A ) as $o ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
						$ocorrencias[ $o['caminho'] . '|' . $o['metrica'] . '|' . $o['detalhe'] ] = (int) $o['maior']; }
					foreach ( $r['linhas'] as &$l ) {
						$k = $l['caminho'] . '|' . $l['metrica'] . '|' . $l['detalhe'];
						if ( isset( $ocorrencias[ $k ] ) ) {
							$l['maior_ocorrencia'] = $ocorrencias[ $k ];
						}
					} unset( $l );
					if ( count( $ocorrencias ) > 10000 ) {
						$r['avisos'][] = 'Máximos de ocorrência limitados aos primeiros 10000 grupos; ausência não significa zero.'; }
				}
				$r['avisos'][] = 'Totais conciliam na fotografia desta chamada. Agregados são mutáveis; páginas posteriores podem refletir novas coletas. Distintos usam o registro detalhado e sua retenção.';
			}
		} finally {
			$wpdb->query( 'COMMIT' ); }
		foreach ( $r['linhas'] as &$l ) {
			foreach ( array( 'id', 'contagem', 'ocorrencia', 'ms', 'criado_em', 'maior_ocorrencia' ) as $k ) {
				if ( isset( $l[ $k ] ) ) {
					$l[ $k ] = (int) $l[ $k ];
				}
			} foreach ( array( 'soma', 'valor' ) as $k ) {
				if ( isset( $l[ $k ] ) ) {
					$l[ $k ] = (float) $l[ $k ];
				}
			} if ( 'eventos' === $tipo ) {
				foreach (['tipo','destino','secao','alvo','classe','texto','nova_aba'] as $campo) {
                    if ($l['metrica']===F3Base_Clique_Link::METRICA) { $l[$campo]=$campo==='nova_aba'?(bool)$l['link_'.$campo]:$l['link_'.$campo]; }
                    unset($l['link_'.$campo]);
                }
                $l['dia'] = wp_date( 'Y-m-d', $l['criado_em'] );
			}
		} unset( $l );
		return $r;
	}
	private static function leads( array $r, array $j, int $dias, int $limite, array $cursor, string $hash ): array {
		global $wpdb;
        $t=F3Base_Leads_Repositorio::tabela();
        $max=(int)($cursor['max']??$wpdb->get_var("SELECT COALESCE(MAX(id),0) FROM {$t}"));
        $r['fonte_disponivel']=true;$r['retencao_dias']=0;$r['retencao_meses']=(int)F3Base_Options::ler('f3base_retencao_meses');
        $r['corte_retencao']=F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao($r['retencao_meses']);
        $r['avisos'][]='Fonte: f3base_leads. Leads são envios aceitos; cliques, suspeitos, spam e outros aparecem separadamente.';
        $casos=array();
        for($d=new DateTimeImmutable($j['inicio'],wp_timezone());$d->getTimestamp()<$j['fim_utc'];$d=$d->modify('+1 day')){
            $casos[]=$wpdb->prepare('WHEN criado_em >= %s AND criado_em < %s THEN %s',gmdate('Y-m-d H:i:s',$d->getTimestamp()),gmdate('Y-m-d H:i:s',$d->modify('+1 day')->getTimestamp()),$d->format('Y-m-d'));
        }
        $day='CASE '.implode(' ',$casos)." ELSE '' END";
        $seg=F3Base_Testes::sql($r['segmento']??null);
        $approval=F3Base_Contato_Entregas::aprovacao_sql();
        $classe="CASE WHEN captura='suspeito' THEN 'suspeitos' WHEN atendimento='spam' THEN 'spam' WHEN metodo IN ('whatsapp_cta','contato_cta') THEN 'cliques' WHEN captura='aceito' AND metodo IN ('formulario','whatsapp_formulario','conteudo','anuncio_meta','anuncio_google','anuncio_linkedin') THEN 'leads' ELSE 'outros' END";
        $rows=$wpdb->get_results($wpdb->prepare("SELECT {$day} AS dia,{$classe} AS origem,COUNT(*) AS contagem,SUM(CASE WHEN {$approval} THEN 1 ELSE 0 END) AS aprovados_sem_entrega FROM %i WHERE criado_em>=%s AND criado_em<%s AND id<=%d AND lixeira=0 AND eliminacao_pendente=0 {$seg} GROUP BY dia,origem ORDER BY dia,origem",$t,gmdate('Y-m-d H:i:s',$j['inicio_utc']),gmdate('Y-m-d H:i:s',$j['fim_utc']),$max),ARRAY_A);
        if($wpdb->last_error){$r['ok']=false;$r['fonte_disponivel']=false;$r['codigo']='leitura_falhou';return $r;}
        $r['totais']=array_fill_keys(array('leads','cliques','suspeitos','spam','outros'),0);foreach($rows as $row){$r['totais'][$row['origem']]+=(int)$row['contagem'];}$r['aprovados_sem_entrega']=array_sum(array_map('intval',array_column($rows,'aprovados_sem_entrega')));

		$offset      = (int) ( $cursor['offset'] ?? 0 );
		$r['corte']  = count( $rows ) > $offset + $limite;
		$r['linhas'] = array_slice( $rows, $offset, $limite );
		foreach ( $r['linhas'] as &$row ) {
			$row['contagem'] = (int) $row['contagem'];
		} unset( $row );
		if ( $r['corte'] ) {
			$r['proximo_cursor'] = self::cursor(
				array(
					'filtro' => $hash,
					'ate'    => $r['cursor_base_em'],
					'offset' => $offset + $limite,
					'max'    => $max,
				)
			); }
		if ( method_exists( 'F3Base_Modulo_Endpoint_Leads', 'resumo_recusas' ) ) {
			$v            = F3Base_Modulo_Endpoint_Leads::resumo_recusas( $dias );
			$r['recusas'] = $v ? $v : (object) array(); }
		return $r;
	}
	/** Comparação de agregados por página/evento; dias sem registro não viram zero. */
	public static function comparar_comportamento( int $dias, string $caminho = '', string $metrica = '', bool $incluir_hoje = false, ?string $segmento=null ): array {
		global $wpdb;
		$dias   = max( 1, min( self::MAX_DIAS, $dias ) );
		$j      = self::janela( $dias, $incluir_hoje );
		$a      = new DateTimeImmutable( $j['inicio'], wp_timezone() );
		$inicio = $a->modify( '-' . $dias . ' days' )->format( 'Y-m-d' );
		$r      = array(
			'inicio'          => $j['inicio'],
			'fim'             => $j['fim'],
			'anterior_inicio' => $inicio,
			'hoje_incluido'   => $incluir_hoje,
			'periodo_parcial' => $incluir_hoje,
			'anterior_fim'    => $a->modify( '-1 day' )->format( 'Y-m-d' ),
			'fuso'            => wp_timezone_string(),
			'regra'           => F3Base_Modulo_Comportamento::regra_calendario(),
			'extraido_em'     => time(),
			'dias_comparados' => 0,
			'pares_excluidos' => array(),
			'linhas'          => array(),
			'agregados'       => array(),
			'corte'           => false,
			'caminho'         => $caminho,
			'metrica'         => $metrica,
		);
		if ( ! F3Base_Modulo_Comportamento::tabela_pronta() ) {
			return $r; }
		$t         = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA;
		$w         = $wpdb->prepare( 'dia >= %s AND dia <= %s', $inicio, $j['fim'] ) . F3Base_Testes::sql($segmento);
		$diag      = (array) $wpdb->get_results( $wpdb->prepare( "SELECT dia,MIN(regra) AS menor,MAX(regra) AS maior,MIN(fuso) AS fuso_menor,MAX(fuso) AS fuso_maior,SUM(CASE WHEN metrica=%s THEN contagem ELSE 0 END) AS cortadas FROM {$t} WHERE {$w} GROUP BY dia", F3Base_Modulo_Comportamento::METRICA_CORTADAS ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
		$mapa      = array_column( $diag, null, 'dia' );
		$validos_a = array();
		$validos_b = array();
		for ( $i = 0; $i < $dias; ++$i ) {
			$d1 = $a->modify( '+' . $i . ' days' )->format( 'Y-m-d' );
			$d2 = $a->modify( '-' . ( $dias - $i ) . ' days' )->format( 'Y-m-d' );
			$x  = $mapa[ $d1 ] ?? array();
			$y  = $mapa[ $d2 ] ?? array();
			$v  = $x && $y && $x['menor'] === $r['regra'] && $x['maior'] === $r['regra'] && $y['menor'] === $r['regra'] && $y['maior'] === $r['regra'] && $x['fuso_menor'] === $r['fuso'] && $x['fuso_maior'] === $r['fuso'] && $y['fuso_menor'] === $r['fuso'] && $y['fuso_maior'] === $r['fuso'] && 0 === (int) $x['cortadas'] && 0 === (int) $y['cortadas'];
			if ( $v ) {
				$validos_a[] = $d1;
				$validos_b[] = $d2;
			} else {
				$r['pares_excluidos'][] = array(
					'atual'    => $d1,
					'anterior' => $d2,
					'motivo'   => 'Ausência de registro, corte informado ou regra incompatível.',
				); }
		}
		$r['dias_comparados'] = count( $validos_a );
		if ( '' !== $caminho ) {
			$w .= $wpdb->prepare( ' AND caminho=%s', $caminho );
		} if ( '' !== $metrica ) {
			$w .= $wpdb->prepare( ' AND metrica=%s', $metrica ); }
		$rows       = (array) $wpdb->get_results( $wpdb->prepare( "SELECT dia,caminho,metrica,detalhe,contagem,soma,regra,fuso,qualidade FROM {$t} WHERE {$w} ORDER BY dia,caminho,metrica,detalhe,regra LIMIT %d", 10001 ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
		$r['corte'] = count( $rows ) > 10000;
		$rows       = array_slice( $rows, 0, 10000 );
		$totais     = array(); foreach ( $rows as $row ) {
			if ( $row['dia'] >= $j['inicio'] ) {
				$r['agregados'][] = $row; }
			$lado = in_array( $row['dia'], $validos_a, true ) ? 'atual' : ( in_array( $row['dia'], $validos_b, true ) ? 'anterior' : '' );
			if ( '' === $lado || F3Base_Modulo_Comportamento::METRICA_CORTADAS === $row['metrica'] ) {
				continue; }
			$k = $row['caminho'] . '|' . $row['metrica'];
			if ( ! isset( $totais[ $k ] ) ) {
				$totais[ $k ] = array(
					'caminho'  => $row['caminho'],
					'metrica'  => $row['metrica'],
					'atual'    => 0,
					'anterior' => 0,
				);
			} $totais[ $k ][ $lado ] += (int) $row['contagem'];
		}
		if ( ! $r['corte'] ) {
			foreach ( $totais as $row ) {
				$row['diferenca'] = $row['atual'] - $row['anterior'];
				$row['variacao']  = $row['anterior'] > 0 ? round( $row['diferenca'] / $row['anterior'] * 100, 2 ) : null;
				$r['linhas'][]    = $row; }
		}
		if ( count( $r['linhas'] ) > 300 ) {
			$r['linhas'] = array_slice( $r['linhas'], 0, 300 );
			$r['corte']  = true; }
		return $r;
	}
}
