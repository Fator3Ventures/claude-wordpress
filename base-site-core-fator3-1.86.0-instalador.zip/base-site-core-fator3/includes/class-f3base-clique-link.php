<?php
/** Registro próprio dos links. A classificação usa o host configurado no WordPress. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Clique_Link {
    public const METRICA = 'f3base_clique_link';
    public static function normalizar($entrada): ?array {
        if (!is_array($entrada) || !is_bool($entrada['nova_aba'] ?? null)) { return null; }
        foreach (['destino','secao','alvo','classe','texto'] as $campo) {
            if (!is_string($entrada[$campo] ?? null)) { return null; }
        }
        if (!preg_match('/^[a-z0-9._-]{1,80}$/Di', $entrada['secao'])
            || !str_starts_with($entrada['alvo'], $entrada['secao'].'~')
            || !preg_match('/^[a-z0-9._-]+~[a-z0-9._:-]{1,80}$/Di', $entrada['alvo'])
            || ($entrada['classe'] !== '' && !preg_match('/^f3base-clique-[a-z0-9_-]{1,64}$/D', $entrada['classe']))) { return null; }
        $url = wp_parse_url(preg_split('/[?#]/', $entrada['destino'], 2)[0]);
        if (!$url || empty($url['scheme'])) { return null; }
        $esquema = strtolower($url['scheme']);
        $caminho = preg_replace('~(/f3base/(?:arquivo|download))(?:/.*)?$~i', '$1/', $url['path'] ?? '');
        $tipo = 'externo';
        $destino = $esquema.':';
        if (in_array($esquema, ['http','https'], true)) {
            if (empty($url['host']) || preg_match('/[\s\\\\]/', $url['host'])) { return null; }
            $host = strtolower($url['host']);
            $tipo = $host === strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST)) ? 'interno' : 'externo';
            $destino .= '//'.$host.(isset($url['port']) ? ':'.$url['port'] : '').($caminho ?: '/');
        } elseif ($esquema === 'mailto' || $esquema === 'tel') {
            $tipo = $esquema === 'mailto' ? 'e-mail' : 'telefone';
            $destino .= $caminho;
        }
        return ['tipo'=>$tipo, 'destino'=>mb_substr($destino,0,2048), 'secao'=>$entrada['secao'],
            'alvo'=>$entrada['alvo'], 'classe'=>$entrada['classe'], 'texto'=>mb_substr(sanitize_text_field($entrada['texto']),0,80),
            'nova_aba'=>(int)$entrada['nova_aba']];
    }

    public static function gravar(array $evento, array $link): bool {
        global $wpdb;
        $linha = array_intersect_key($evento,array_flip(['visitante','sessao','navegacao','classe_trafego','caminho','automacao','automacao_motivos','automacao_regra','criado_em','recebido_em']));
        $linha += ['dia'=>wp_date('Y-m-d',$evento['criado_em']), 'metrica'=>self::METRICA,
            'detalhe'=>mb_substr($link['alvo'],0,160), 'valor'=>1, 'ancora'=>$evento['qualidade']==='cliente'?'visitante':'servidor'];
        foreach ($link as $campo=>$valor) { $linha['link_'.$campo]=$valor; }
        return false !== $wpdb->insert(F3Base_Modulo_Comportamento::nome_tabela_eventos(),$linha);
    }
}
