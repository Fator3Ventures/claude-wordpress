<?php
/** Validação da identidade de e-mail na captura. O DNS recebe somente o domínio. */
declare(strict_types=1);
defined('ABSPATH') || exit;
final class F3Base_Email_Contato {
    public const OPTION = 'f3base_email_correcoes';
    public const CLASSES = ['valido','corrigido','nao_verificado','invalido'];
    private const PADRAO = [
        'gmial.com=gmail.com','gmai.com=gmail.com','gmal.com=gmail.com','gnail.com=gmail.com',
        'hotmial.com=hotmail.com','hotmai.com=hotmail.com','outlok.com=outlook.com','outllook.com=outlook.com',
        'lvei.com=live.com','yhaoo.com=yahoo.com','yaho.com=yahoo.com','iclod.com=icloud.com',
        'uol.cmo.br=uol.com.br','bol.cmo.br=bol.com.br','tera.com.br=terra.com.br',
    ];
    private const SCHEMA = ['type'=>'array','maxItems'=>100,'items'=>['type'=>'string','maxLength'=>507]];
    public static function catalogo(array $catalogo): array {
        $catalogo[self::OPTION] = [
            'rotulo'=>'Correções de domínios de e-mail','descricao'=>'Informe um par por linha, no formato erro=domínio. A lista troca o domínio antes da consulta DNS. Use o simulador abaixo para experimentar a lista antes de salvar.',
            'operavel'=>true,'secao'=>'contato','campo'=>'linhas','autoload'=>false,'padrao'=>self::PADRAO,
            'schema_config'=>self::SCHEMA,'schema_entrada'=>self::SCHEMA,
            'sanitiza'=>[self::class,'linhas'],'recusa'=>[self::class,'recusa'],
            'impacto'=>'Aplica-se aos próximos contatos. Use uma lista vazia para desativar as trocas por provedor.',
            'exemplo'=>'gmial.com=gmail.com',
        ];
        return $catalogo;
    }
    public static function linhas($entrada): array {
        $linhas=is_array($entrada)?$entrada:explode("\n",is_string($entrada)?$entrada:'');
        return array_values(array_filter(array_map(static fn($v)=>is_string($v)?strtolower(trim($v)):'', $linhas),'strlen'));
    }
    private static function dominio(string $v): bool {
        return strlen($v)<=253 && (bool)preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/D',$v);
    }
    public static function recusa($entrada): string {
        if (!is_string($entrada) && !is_array($entrada)) { return 'Informe uma lista de domínios.'; }
        if (is_array($entrada) && count(array_filter($entrada,'is_string'))!==count($entrada)) {return 'Cada linha deve ser texto.';}
        $linhas=self::linhas($entrada);
        if(count($linhas)>100){return 'Use até 100 pares.';}
        $mapa=[];
        foreach($linhas as $linha){
            [$de,$para]=array_pad(explode('=',$linha,2),2,'');
            if(!self::dominio($de)||!self::dominio($para)||isset($mapa[$de])||$de===$para){return 'Use domínios distintos, no formato erro=domínio, com uma regra por origem.';}
            $mapa[$de]=$para;
        }
        return array_intersect(array_keys($mapa),array_values($mapa))?'Use um destino final para cada correção.':'';
    }
    public static function registrar(): void {
        F3Base_Servicos::ability('email-contato-simular','Simula limpeza, correção e DNS do e-mail sem gravar contato.',
            [self::class,'simular'],['valor'=>['type'=>'string','maxLength'=>1024],'correcoes'=>self::SCHEMA],['valor']);
    }
    public static function simular_painel(): void {
        check_ajax_referer('f3base_email_simular');
        if(!current_user_can('manage_options')){wp_send_json_error(['mensagem'=>'Permissão insuficiente.'],403);}
        $valor=wp_unslash($_POST['valor']??'');
        $lista=wp_unslash($_POST['correcoes']??'');
        if(!is_string($valor)||strlen($valor)>1024||!is_string($lista)||strlen($lista)>51000){
            wp_send_json_error(['mensagem'=>'Entrada acima do limite ou inválida.'],400);
        }
        wp_send_json(self::simular(['valor'=>$valor,'correcoes'=>self::linhas($lista)]));
    }
    public static function simular(array $entrada): array {
        $lista=$entrada['correcoes']??null;
        if ($lista!==null && ($erro=self::recusa($lista))!=='') {return ['ok'=>false,'codigo'=>'lista_invalida','mensagem'=>$erro];}
        return ['ok'=>true]+self::analisar((string)$entrada['valor'],$lista,false);
    }
    /** Bounded cache. Only definitive answers are shared across requests. */
    private static function dns(string $dominio,float $limite,bool $cache): string {
        $hash=hash('sha256',$dominio);
        $chave='f3base_dns185_'.substr($hash,0,2);
        $bucket=$cache?(array)get_transient($chave):[];
        if(($bucket[$hash][1]??0)>time()){return $bucket[$hash][0];}
        $estado='ausente'; $ttl=300;
        foreach(['MX'=>15,'A'=>1] as $tipo=>$numero){
            $restante=$limite-microtime(true);
            if($restante<0.05){return 'incerto';}
            $r=wp_remote_get(add_query_arg(['name'=>$dominio,'type'=>$tipo],'https://cloudflare-dns.com/dns-query'),[
                'timeout'=>$restante,'redirection'=>0,'limit_response_size'=>32768,'headers'=>['Accept'=>'application/dns-json'],
            ]);
            if(microtime(true)>$limite || is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200){return 'incerto';}
            $d=json_decode(wp_remote_retrieve_body($r),true);
            if(!is_array($d)||!empty($d['TC'])||!in_array($d['Status']??null,[0,3],true)){return 'incerto';}
            if($d['Status']===3){break;}
            foreach($d['Answer']??[] as $rr){
                if(($rr['type']??null)!==$numero){continue;}
                $valor=trim((string)($rr['data']??''));
                if($tipo==='MX' && preg_match('/^0\s+\.$/D',$valor)){break 2;}
                if($tipo==='MX'?preg_match('/^[0-9]+\s+[a-z0-9._-]+\.?$/iD',$valor):filter_var($valor,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)){
                    $estado='recebe';$ttl=max(1,min(3600,(int)($rr['TTL']??300)));break 2;
                }
                return 'incerto';
            }
        }
        if($cache){
            $bucket=array_filter($bucket,static fn($e)=>is_array($e)&&($e[1]??0)>time());
            $bucket[$hash]=[$estado,time()+$ttl];
            set_transient($chave,array_slice($bucket,-8,null,true),3600);
        }
        return $estado;
    }
    public static function analisar(string $entrada,?array $lista=null,bool $cache=true): array {
        $texto=strtolower(preg_replace('/[\p{Z}\t]+/u','',$entrada)??'');
        $r=['digitado'=>wp_check_invalid_utf8($entrada),'corrigido'=>$texto,'classe'=>'invalido','motivo'=>'escrita','email'=>'','dominio_corrigido'=>false];
        if(substr_count($texto,'@')!==1 || str_contains($texto,'..')){return $r;}
        [$local,$dominio]=explode('@',$texto,2);
        $dominio=str_replace(',','.',$dominio);
        if(str_contains($dominio,'..')){return $r;}
        $dominio=preg_replace('/\.$/D','',$dominio);
        $r['corrigido']=$local.'@'.$dominio;
        if(strlen($r['corrigido'])>254 || strlen($local)>64 || str_starts_with($local,'.') || str_ends_with($local,'.') || !self::dominio($dominio) || !is_email($r['corrigido'])){return $r;}
        $limite=microtime(true)+2;
        $mapa=[];
        foreach(self::linhas($lista??F3Base_Options::ler(self::OPTION)) as $linha){
            [$de,$para]=array_pad(explode('=',$linha,2),2,'');
            if(self::dominio($para)){$mapa[$de]=$para;}
        }
        $alvo=$mapa[$dominio]??$dominio;
        $estado=self::dns($alvo,$limite,$cache);
        if($alvo===$dominio && $estado==='ausente'){
            $candidato=preg_replace(['/\.con$/D','/\.com\.(?:bt|brr)$/D','/\.cmo$/D'],['.com','.com.br','.com'],$dominio);
            if($candidato!==$dominio){
                $teste=self::dns($candidato,$limite,$cache);
                if($teste==='recebe'){$alvo=$candidato;$estado='recebe';}
                elseif($teste==='incerto'){$estado='incerto';}
            }
        }
        $r['corrigido']=$local.'@'.$alvo;
        $r['dominio_corrigido']=$alvo!==$dominio;
        $r['motivo']=match($estado){'recebe'=>'dns_confirmado','ausente'=>'dominio_sem_entrega',default=>'dns_indisponivel'};
        if($estado!=='ausente' && strlen($r['corrigido'])<=254){
            $r['classe']=$estado==='incerto'?'nao_verificado':($r['dominio_corrigido']?'corrigido':'valido');
            $r['email']=$r['corrigido'];
        }
        return $r;
    }
}
