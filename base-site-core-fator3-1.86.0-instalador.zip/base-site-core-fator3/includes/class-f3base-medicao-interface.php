<?php
/** Um ponto de entrada, uma análise por vez. Consultas compartilhadas com o canal. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Medicao_Interface {
    const AREAS=F3Base_Medicao_Editorial_UI::AREAS;
    const VISOES=array('geral'=>array('resultados'=>'Resumo do período'),'aquisicao'=>array('campanhas'=>'Plataformas, campanhas e anúncios'),'conversao'=>array('resultados'=>'Páginas','formularios'=>'Funil de formulários','ofertas'=>'Ofertas','metodos'=>'Métodos de contato','superficies'=>'Superfícies de contato','materiais'=>'Materiais protegidos','demanda'=>'Perfil da demanda','operacao'=>'Atendimento','emails_normalizacao'=>'Normalização dos e-mails','telefones_normalizacao'=>'Normalização dos telefones'),'comportamento'=>array('blocos'=>'Seções e conversão','paginas'=>'Páginas vistas','tempo'=>'Tempo ativo','profundidade'=>'Profundidade','saidas'=>'Saídas','eventos'=>'Acionamentos por sessão'),'agentes'=>array('resumo'=>'Resumo','conteudo'=>'Conteúdo','frequencia'=>'Frequência','horas'=>'Horas'),'tecnico'=>array('qualidade'=>'Web Vitals','vitais'=>'Web Vitals por versão','erros'=>'Erros de JavaScript','friccao'=>'Fricção','sondas'=>'Sondas e requisições técnicas','acessos'=>'Acessos do servidor','coleta'=>'Estado da coleta'));
    public static function filtros(array $raw): array {
        $e=array();foreach(array('de','ate','segmento','caminho','formulario','metodo','plataforma','conta_id','campanha_id','grupo_id','anuncio_id','sessao','canal','tipo','automacao','largura_faixa','navegador','sistema','retorno','aparelho',...array_keys(F3Base_Perfil_Aparelho::ROTULOS),'agrupamento','superficie','escopo_campanhas','campanha_historica','google_ads_cursor','google_ads_dataset','meta_ads_cursor') as $k){if(isset($raw[$k])&&is_string($raw[$k])&&$raw[$k]!==''){$e[$k]=sanitize_text_field(wp_unslash($raw[$k]));}}
        if(isset($raw['anotacoes'])){$e['anotacoes']=in_array($raw['anotacoes'],array(true,'1','true'),true);}
        $e['comparar']=!empty($raw['comparar']);$e['pagina']=max(1,(int)($raw['pagina']??1));$e['limite']=100;return $e;
    }
    public static function estoque(string $segmento): array {
        global $wpdb;$seg=F3Base_Testes::sql($segmento);$n=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE lixeira=0 AND eliminacao_pendente=0 AND captura='aceito' AND atendimento='novo' {$seg}",F3Base_Leads_Repositorio::tabela()));return array('quantidade'=>$wpdb->last_error?null:(int)$n,'em'=>gmdate('c'),'unidade'=>'Contatos aceitos aguardando resposta agora; inclui registros de outros períodos.');
    }
    public static function render(): void {
        if(F3Base_Medicao_Editorial_UI::render()){return;}
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}
        $area=($_GET['area']??'')==='comportamento'?'comportamento':(isset(self::AREAS[$_GET['area']??''])?$_GET['area']:'geral');if(($_GET['aba']??'')==='acessos'){$area='tecnico';$_GET['visao']='acessos';}
        $views=self::VISOES[$area];$view=isset($views[$_GET['visao']??''])?$_GET['visao']:array_key_first($views);$e=self::filtros($_GET);
        try{$j=F3Base_Relatorios::janela($e);$seg=F3Base_Testes::segmento($e['segmento']??null);}catch(Throwable $x){echo '<div class="wrap"><h1>Medição</h1><p role="alert">Período ou segmento inválido.</p></div>';return;}
        $e['segmento']=$seg;$e['de']=$j['de'];$e['ate']=$j['ate'];
        echo '<div class="wrap f3base-tela f3base-tela--medicao f3c-painel">';F3Base_Interface::cabecalho('Relatórios','Consulte a medição do site, a aquisição e as conversões no período selecionado.');echo '<nav class="nav-tab-wrapper f3c-grupos" aria-label="Áreas de medição">';
        foreach(self::AREAS as $k=>$label){$url=add_query_arg(array('page'=>'f3base-medicao','area'=>$k,'de'=>$e['de'],'ate'=>$e['ate'],'segmento'=>$seg,'comparar'=>$e['comparar']?1:0),admin_url('admin.php'));echo '<a class="nav-tab '.(($area==='comportamento'?'sessoes':$area)===$k?'nav-tab-active':'').'" '.(($area==='comportamento'?'sessoes':$area)===$k?'aria-current="page"':'').' href="'.esc_url($url).'">'.esc_html($label).'</a>';}
        echo '</nav><p><a href="'.esc_url(admin_url('admin.php?page=base-site-core-fator3&secao=medicao')).'">Configurar coleta e anúncios</a> · <a href="'.esc_url(admin_url('admin.php?page=f3base-medicao&area=ga4')).'">Acervo GA4</a></p>';
        echo '<nav class="f3c-subnav" aria-label="Análises">';
        foreach ($views as $slug=>$rotulo) {
            $url=add_query_arg(['page'=>'f3base-medicao','area'=>$area,'visao'=>$slug]+array_intersect_key($e,array_flip(['de','ate','segmento'])),admin_url('admin.php'));
            echo '<a '.($view===$slug?'aria-current="page"':'').' href="'.esc_url($url).'">'.esc_html($rotulo).'</a>';
        }
        echo '</nav>';
        if($area==='agentes'){F3Base_Agentes::render();echo '</div>';return;}
        if(!F3Base_Modulo_Comportamento::ligado()){echo '<p role="status">A coleta de comportamento está desligada. Registros antigos disponíveis respeitam a retenção.</p>';}
        echo '<form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="'.esc_attr($area).'"><input type="hidden" name="visao" value="'.esc_attr($view).'">';
        $tecnico=in_array($view,array('acessos','coleta'),true);if(!$tecnico){
        foreach(array('de'=>'De','ate'=>'Até') as $k=>$label){echo '<label>'.esc_html($label).' <input type="date" name="'.$k.'" value="'.esc_attr($e[$k]).'"></label> ';}F3Base_Testes::seletor($seg);
        $extras=$area==='aquisicao'?array('plataforma'=>'Plataforma','conta_id'=>'Conta','campanha_id'=>'Campanha ID','grupo_id'=>'Grupo ID','anuncio_id'=>'Anúncio ID'):array('caminho'=>'Página');
        if($view==='campanhas'){$extras['campanha_historica']='Campanha observada (nome ou chave)';}if($area==='conversao'){$extras['formulario']='Formulário';}if($area==='comportamento'){$extras['sessao']='ID completo da sessão';}
        foreach($extras as $k=>$label){if($k==='plataforma'){echo '<label>Plataforma <select name="plataforma"><option value="">Todas</option>';foreach(array('meta_ads'=>'Meta Ads','google_ads'=>'Google Ads','linkedin_ads'=>'LinkedIn Ads','openai_ads'=>'OpenAI Ads','nao_identificada'=>'Não identificada') as $value=>$title){echo '<option value="'.$value.'" '.selected($e[$k]??'',$value,false).'>'.esc_html($title).'</option>';}echo '</select></label> ';continue;}if($k==='formulario'){echo '<label>Formulário <select name="formulario"><option value="">Todos</option>';foreach(F3Base_Options::ler('f3base_formularios') as $form){echo '<option value="'.esc_attr($form['id']).'" '.selected($e[$k]??'',$form['id'],false).'>'.esc_html($form['titulo']).'</option>';}echo '</select></label> ';continue;}echo '<label>'.esc_html($label).' <input name="'.$k.'" value="'.esc_attr($e[$k]??'').'"></label> ';}
        if(in_array($area,array('aquisicao','conversao'),true)){
            $selects=array('superficie'=>array('Superfície do contato',array(''=>'Todas','conteudo'=>'Conteúdo','menu'=>'Menu','flutuante'=>'Flutuante','elementor'=>'Elementor','cabecalho'=>'Cabeçalho','barra_fixa'=>'Barra fixa','nao_informada'=>'Não informada')),'canal'=>array('Canal',array(''=>'Todos')+F3Base_Audiencia::canais()),'tipo'=>array('Conteúdo',array(''=>'Todos','pagina'=>'Páginas','artigo'=>'Artigos','outro'=>'Outros')),'automacao'=>array('Automação',array('audiencia'=>'Excluir sinais de automação','todas'=>'Incluir todas','declarada'=>'Somente declarada','provavel'=>'Somente provável')));
            foreach(F3Base_Audiencia::dimensoes_schema() as $dim=>$spec){if(!isset($spec['enum'])){echo '<label>'.esc_html(F3Base_Audiencia::rotulos_dimensoes()[$dim]).' <input maxlength="80" name="'.esc_attr($dim).'" value="'.esc_attr($e[$dim]??'').'"></label> ';continue;}$vals=array(''=>'Todos');foreach($spec['enum'] as $v){$vals[$v]=F3Base_Audiencia::rotulo_dimensao($dim,$v);}$selects[$dim]=array(F3Base_Audiencia::rotulos_dimensoes()[$dim],$vals);}if($view==='campanhas'){$selects['escopo_campanhas']=array('Campanhas',array('atribuicao'=>'Atribuição da captura','historico'=>'Todas as campanhas observadas'));$selects['agrupamento']=array('Agrupar',array('anuncio'=>'Por anúncio','campanha'=>'Por campanha'));}
            foreach($selects as $k=>$def){echo '<label>'.esc_html($def[0]).' <select name="'.esc_attr($k).'">';foreach($def[1] as $value=>$label){echo '<option value="'.esc_attr($value).'" '.selected($e[$k]??($k==='automacao'?'audiencia':''),$value,false).'>'.esc_html($label).'</option>';}echo '</select></label> ';}
            echo '<input type="hidden" name="anotacoes" value="0"><label><input type="checkbox" name="anotacoes" value="1" '.checked($e['anotacoes']??!empty(F3Base_Options::ler('f3base_medicao_editorial')['aplicar_anotacoes']),true,false).'> Aplicar exclusões anotadas</label> ';
        }
        if($view==='vitais'){F3Base_Vitais::campos_filtro();}else {
        echo '<label><input type="checkbox" name="comparar" value="1" '.checked($e['comparar'],true,false).'> Comparar período anterior</label> ';}}echo '<button class="button button-primary">Atualizar relatório</button></form>';
        if(!$tecnico){echo '<p>'.esc_html($j['de'].' a '.$j['ate'].' · '.$j['fuso'].' · Atualizado '.wp_date('d/m/Y H:i:s').' · '.($j['parcial']?'Período em andamento':'Período encerrado')).'</p><h2>'.esc_html($views[$view]).'</h2>';}else{echo '<h2>'.esc_html($views[$view]).'</h2><p>Este diagnóstico usa a janela e o estado indicados abaixo.</p>';}
        if ($view === 'vitais') {
            F3Base_Vitais::render($j['dias'], $e);
            echo '</div>';
            return;
        }
        if ($view === 'qualidade') {
            $url = add_query_arg(array('page'=>'f3base-medicao','area'=>'tecnico','visao'=>'vitais') +
                array_intersect_key($e,array_flip(array('de','ate','segmento','caminho'))), admin_url('admin.php'));
            echo '<p>Para consultar o p75 das amostras por edição do Core, abra <a href="' . esc_url($url) . '">Web Vitals por versão</a>.</p>';
        }
        if($view==='sondas'){F3Base_Sondas_Http::render(array_intersect_key($e,array_flip(array('de','ate','pagina','caminho','metodo','status','classe'))));echo '</div>';return;}
        if($view==='acessos'){echo '<p>Logs do servidor não contêm a marca de cookie/cabeçalho de cada requisição. Este quadro mostra totais brutos classificados, sem aplicar o segmento escolhido às linhas de log.</p>';F3Base_Admin_Acessos::render();echo '</div>';return;}
        if($view==='coleta'){F3Base_Medicao_Saude::render();echo '<p>Estado da coleta e dos destinos. A fila de navegador só é conhecida no navegador correspondente.</p><details open><summary>Últimos resultados do endpoint de análise</summary><pre>'.esc_html(wp_json_encode(get_option('f3base_analise_saude',array()),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details>';echo '<a class="button" href="'.esc_url(admin_url('admin.php?page=base-site-core-fator3&aba=tecnica')).'">Diagnóstico completo</a></div>';return;}
        if(in_array($view,F3Base_Relatorios::VISOES,true)){
            $e['visao']=$view;$r=F3Base_Relatorios::consultar($e);if(empty($r['ok'])){echo '<p role="alert">'.esc_html($r['codigo']??'Consulta indisponível').'. Ajuste o período ou confira Técnico.</p></div>';return;}
            if($area==='geral'){$stock=self::estoque($seg);$t=$r['totais'];$cards=array('Sessões observadas'=>$t['sessoes_observadas'],'Cliques de contato'=>$t['cliques'],'Envios aceitos'=>$t['envios'],'Taxa de envio do site'=>isset($t['taxa_envio_site_pct'])?$t['taxa_envio_site_pct'].'%':'Indisponível','Aguardando resposta agora'=>$stock['quantidade']??'Indisponível');echo '<dl style="display:flex;flex-wrap:wrap;gap:24px">';foreach($cards as $k=>$v){echo '<div><dt>'.esc_html($k).'</dt><dd style="font-size:1.7em;margin:0">'.esc_html((string)$v).'</dd></div>';}echo '</dl><p>'.esc_html($stock['unidade']).'</p>';}
            if($area==='aquisicao'){echo '<p>Atribuição declarada nas URLs. IDs identificam anúncios; nomes são rótulos. Os contatos capturados pelo Core são pareados quando há vínculo. Custos e vendas dependem das integrações e da cobertura disponível.</p>';}
            if(($r['escopo_campanhas']??'')==='historico'){echo '<p>'.(int)$r['totais']['contatos'].' contatos distintos. '.esc_html($r['regra']).'</p>';}elseif($view==='ofertas'){echo '<p>Instâncias observadas: '.(int)$r['totais']['instancias_observadas'].'. Envios sem instância observada: '.(int)$r['totais']['envios_sem_instancia_observada'].'. Etapas únicas por apresentação; envio confirmado no servidor.</p>';}else{echo '<p>'.(int)$r['testes_excluidos'].' registros de teste excluídos deste recorte. O seletor permite consultá-los.</p>';
            echo '<p>Cobertura: '.(int)$r['cobertura']['com_pagina_vista'].' de '.(int)$r['cobertura']['elegiveis'].' contatos elegíveis vinculados a página vista na sessão. Histórico sem marca continua como não marcado.</p>';}
            if(isset($r['comparacao'])){echo '<p>Envios no período anterior: '.esc_html((string)($r['comparacao']['anterior']['envios']??'Indisponível')).'. Variação: '.esc_html(isset($r['comparacao']['variacao_envios'])?$r['comparacao']['variacao_envios'].'%':'Indisponível').'.</p>';}
            if($view==='campanhas')F3Base_Google_Acervo::render_relatorios($r);
            F3Base_Relatorios::tabela($r['linhas']);if($r['proxima_pagina']){echo '<a class="button" href="'.esc_url(add_query_arg('pagina',$r['proxima_pagina'])).'">Próxima página</a>';}
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_relatorio_csv">';wp_nonce_field('f3base-relatorio');foreach($e as $k=>$v){echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr((string)$v).'">';}echo '<button class="button">Exportar todas as linhas filtradas</button></form><details><summary>Como é calculado</summary><ul>';foreach($r['avisos'] as $v){echo '<li>'.esc_html($v).'</li>';}echo '</ul></details>';
        }else{
            $map=array('paginas'=>'pagina','tempo'=>'tempo-ativo','profundidade'=>'rolagem','saidas'=>'clique-externo','erros'=>'erro','friccao'=>'clique-repetido');$q=array('de'=>$e['de'],'ate'=>$e['ate'],'segmento'=>$seg,'limite'=>100,'caminho'=>$e['caminho']??'');if(!empty($e['sessao'])){$q['sessao']=$e['sessao'];}if(isset($map[$view])){$q['metrica']=F3Base_Modulo_Comportamento::evento_do_gatilho($map[$view]);}if(isset($_GET['cursor'])){$q['cursor']=sanitize_text_field(wp_unslash($_GET['cursor']));}$r=F3Base_Medicao_Consultas::consultar($view==='eventos'?'eventos':'comportamento',$q);
            if(is_wp_error($r)){echo '<p role="alert">'.esc_html($r->get_error_message()).'</p>';}else{echo '<p>Contagens de eventos observados. Somatórios não representam visitantes únicos. Colunas de soma seguem a unidade da métrica; tempo ativo é uma estimativa em milissegundos.</p>';F3Base_Relatorios::tabela($r['linhas']);
                if($e['comparar']){$all=self::legado($view==='eventos'?'eventos':'comportamento',$q);$prev=$q;$d=new DateTimeImmutable($e['de'],wp_timezone());$ate=new DateTimeImmutable($e['ate'],wp_timezone());$dias=(int)$d->diff($ate)->days+1;$prev['ate']=$d->modify('-1 day')->format('Y-m-d');$prev['de']=$d->modify('-'.$dias.' days')->format('Y-m-d');$old=self::legado($view==='eventos'?'eventos':'comportamento',$prev);if(!is_wp_error($all)&&!is_wp_error($old)){echo '<p>Ocorrências no período: '.esc_html((string)($view==='eventos'?count($all):array_sum(array_column($all,'contagem')))).'; período anterior: '.esc_html((string)($view==='eventos'?count($old):array_sum(array_column($old,'contagem')))).'. A comparação é de eventos, não de pessoas.</p>';}else{echo '<p>Comparação indisponível: reduza o período.</p>';}}
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_medicao_csv"><input type="hidden" name="tipo" value="'.($view==='eventos'?'eventos':'comportamento').'">';wp_nonce_field('f3base-medicao-csv');foreach($q as $k=>$v){if($k!=='cursor'){echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr((string)$v).'">';}}echo '<button class="button">Exportar todas as linhas filtradas</button></form>';
                if($r['proximo_cursor']){echo '<a class="button" href="'.esc_url(add_query_arg('cursor',$r['proximo_cursor'])).'">Próxima página</a>';}}
        }
        echo '</div>';
    }
    /** Mesma consulta paginada, conjunto completo limitado, nunca amostra parcial. */
    public static function legado(string $tipo,array $q) {
        global $wpdb;unset($q['cursor']);$q['limite']=200;$rows=array();$fim=microtime(true)+20;
        if(false===$wpdb->query('START TRANSACTION WITH CONSISTENT SNAPSHOT')){return new WP_Error('leitura_falhou','Não foi possível iniciar a leitura.');}
        try{do{$r=F3Base_Medicao_Consultas::consultar($tipo,$q);if(is_wp_error($r)){return $r;}$rows=array_merge($rows,$r['linhas']);if(count($rows)>30000||microtime(true)>$fim){return new WP_Error('reduza_periodo','Reduza o período para exportar o conjunto completo.');}$q['cursor']=$r['proximo_cursor'];}while($q['cursor']);return $rows;}
        finally{$wpdb->query('ROLLBACK');}
    }
    public static function csv(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-medicao-csv');$tipo=sanitize_key($_POST['tipo']??'');if(!in_array($tipo,array('eventos','comportamento'),true)){wp_die('Tipo inválido.',400);}
        $q=array();foreach(array('de','ate','segmento','caminho','metrica','sessao') as $k){if(isset($_POST[$k])){$q[$k]=sanitize_text_field(wp_unslash((string)$_POST[$k]));}}$rows=self::legado($tipo,$q);if(is_wp_error($rows)){wp_die(esc_html($rows->get_error_message()),400);}
        foreach($rows as &$line){foreach(array('criado_em','atualizado_em','em') as $key){if(isset($line[$key])&&is_numeric($line[$key])&&(int)$line[$key]>1000000000){$line[$key.'_utc']=gmdate('c',(int)$line[$key]);$line[$key.'_local']=wp_date('d/m/Y H:i:s P',(int)$line[$key]);}}}unset($line);
        nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="f3base-medicao.csv"');$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,array('Regra','core-1.17.0','Fonte',$tipo,'Extraído UTC',gmdate('c'),'Fuso',wp_timezone_string()));foreach($q as $k=>$v){fputcsv($out,array($k,F3Base_Acessos_Relatorio::celula_csv($v)));}if($rows){fputcsv($out,array_keys($rows[0]));foreach($rows as $line){fputcsv($out,array_map(static fn($v)=>F3Base_Acessos_Relatorio::celula_csv($v===null?'Indisponível':$v),$line));}}fclose($out);exit;
    }

}
