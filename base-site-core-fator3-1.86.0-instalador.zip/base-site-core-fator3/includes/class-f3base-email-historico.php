<?php
/** Individual Smart BCC reconciliation; SMTP acceptance is not CRM history proof. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Historico {
    const OPTION='f3base_email_historico';const HOOK='f3base_email_historico_conferir';
    public static function padroes(): array {return ['ativo'=>true,'janela_horas'=>48,'intervalo_minutos'=>60];}
    public static function config(): array {return array_replace(self::padroes(),(array)F3Base_Options::ler(self::OPTION));}
    public static function preparar(array $message,array $cfg,string $to): array {
        $host=(string)wp_parse_url(home_url('/'),PHP_URL_HOST);if(!preg_match('/^[a-z0-9.-]+$/Di',$host))$host='site.invalid';
        $message['message_id']=$message['message_id']??'<f3base.'.bin2hex(random_bytes(24)).'@'.$host.'>';
        $message['historico_contexto']=$message['historico_contexto']??['remetente'=>$cfg['remetente'],'destinatario'=>$to,'iniciado_em'=>time(),'politica'=>self::config(),'revisao'=>F3Base_Options::revisao(self::OPTION)];return $message;
    }
    public static function identidade(array $m,array $message,int $person): bool {
        $id=$m['mua_message_id']??null;$expected=$message['message_id']??null;if(!is_string($id)||!is_string($expected)||!hash_equals(trim($expected,'<>'),trim($id,'<>'))||!empty($m['draft_flag'])||!empty($m['deleted_flag']))return false;
        $ctx=$message['historico_contexto']??[];$from=false;$to=false;foreach($m['from']??[] as $v)if(strcasecmp($v['email_address']??'',$ctx['remetente']??'')===0&&($ctx['remetente']??'')!=='')$from=true;
        foreach($m['to']??[] as $v)if(strcasecmp($v['email_address']??'',$ctx['destinatario']??'')===0&&($ctx['destinatario']??'')!==''&&(int)($v['linked_person_id']??0)===$person)$to=true;return $from&&$to;
    }
    public static function conferir(array $row,array $payload): array {
        $message=$payload['message']??[];$ctx=$message['historico_contexto']??[];$person=(int)($payload['person_id']??0);$now=time();$prior=json_decode($row['historico']??'',true)?:[];
        $out=['estado'=>'nao_conferido','conferido_em'=>null,'tentado_em'=>$now,'motivo'=>'message_id_historico_indisponivel','final'=>true];if(empty($message['message_id'])||!$person||!$ctx)return $out;if(empty($ctx['politica']['ativo'])){$out['motivo']='politica_fotografada_desligada';return $out;}
        $deadline=(int)($row['enviado_em']??$ctx['iniciado_em'])+(int)$ctx['politica']['janela_horas']*3600;$binding=hash('sha256',wp_json_encode([$row['conta'],$row['lead_id'],$person,$message['message_id'],$ctx]));$start=($prior['contexto']??'')===$binding?(int)($prior['start']??0):0;
        $out+=['contexto'=>$binding,'prazo_em'=>$deadline,'revisao_politica'=>$ctx['revisao'],'message_id_sha256'=>hash('sha256',$message['message_id'])];$out['final']=$now>=$deadline;$out['proxima']=$now+(int)$ctx['politica']['intervalo_minutos']*60;
        $r=F3Base_Pipedrive_Api::pedir('GET','v1/persons/'.$person.'/mailMessages',['start'=>$start,'limit'=>100,'include_body'=>0]);
        if(empty($r['ok'])){$out['motivo']=$r['codigo']??'leitura_recusada';$out['start']=$start;return $out;}
        $rows=$r['data'];if(!is_array($rows)||!array_is_list($rows)){$out['motivo']='lista_invalida';return $out;}
        foreach($rows as $item){$m=$item['data']??$item;if(!is_array($m))continue;if(!self::identidade($m,$message,$person))continue;$thread=$m['mail_thread_id']??0;if(!is_int($thread)||$thread<1){$out['motivo']='thread_ausente';continue;}
            $t=F3Base_Pipedrive_Api::pedir('GET','v1/mailbox/mailThreads/'.$thread);if(empty($t['ok'])){$out['motivo']=$t['codigo']??'thread_indisponivel';return $out;}
            if(($t['data']['lead_id']??'')!==$row['lead_id']||!empty($t['data']['deleted_flag'])){$out['motivo']='mensagem_sem_vinculo_ao_lead';continue;}
            return array_replace($out,['estado'=>'confirmado','conferido_em'=>$now,'motivo'=>'message_id_remetente_destinatario_pessoa_e_lead','final'=>true,'mensagem_id'=>$m['id']??null,'thread_id'=>$thread]);
        }
        $page=$r['additional_data']['pagination']??null;if(!is_array($page)||!is_bool($page['more_items_in_collection']??null)){$out['motivo']='paginacao_nao_confirmada';return $out;}
        if($page['more_items_in_collection']){$next=$page['next_start']??null;if(!is_int($next)||$next<=$start){$out['motivo']='cursor_sem_progresso';return $out;}$out['start']=$next;$out['motivo']='paginacao_pendente';$out['final']=$now>=$deadline;$out['proxima']=$now+60;if($out['final'])$out['motivo']='prazo_encerrado_com_paginacao_incompleta';return $out;}
        $out['start']=0;$out['conferido_em']=$now;$out['motivo']='mensagem_nao_localizada_no_recorte_autorizado';if($now>=$deadline)$out['estado']='nao_confirmado_no_prazo';return $out;
    }
    public static function aplicavel(): bool {
        return !empty(self::config()['ativo'])
            && !empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])
            && !empty(F3Base_Options::ler(F3Base_Pipedrive_Operacao::OPTION)['ativo']);
    }
    public static function processar(): array {
        if (!self::aplicavel()) { return ['ok'=>true,'codigo'=>'nao_aplicavel','conferidos'=>0]; }
        if(!F3Base_Recuperacao::entrar())return ['ok'=>false,'codigo'=>'desligado_ou_em_recuperacao'];$lock=F3Base_Trava::adquirir('email-historico',120);if(!$lock){F3Base_Recuperacao::sair();return ['ok'=>false,'codigo'=>'ocupado'];}
        try{global $wpdb;$cfg=F3Base_Pipedrive_Api::iniciar_lote();$s=get_option('f3base_pipedrive_estado',[]);$account=($s['dominio']??'').'|'.($s['conta_id']??'').'|'.($s['instalacao']??'');$crm=F3Base_Pipedrive_Api::configuracao_lote();if(empty($crm['ativo']))return ['ok'=>true,'codigo'=>'nao_aplicavel','conferidos'=>0];if(!F3Base_Integracoes::pipedrive_verificado())return ['ok'=>false,'codigo'=>'crm_indisponivel'];
            $rows=$wpdb->get_results($wpdb->prepare("SELECT e.* FROM %i e JOIN %i l ON l.record_id=e.record_id WHERE e.enviado_em>0 AND e.historico_final=0 AND e.historico_proxima<=%d AND e.conta=%s AND e.payload<>'' AND l.lixeira=0 AND l.eliminacao_pendente=0 ORDER BY e.historico_proxima LIMIT 3",F3Base_Email_Novo_Lead::tabela(),F3Base_Leads_Repositorio::tabela(),time(),$account),ARRAY_A);$n=0;
            foreach($rows as $row){$lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||$row['conta']!==$account)continue;$p=F3Base_Contato_Comunicacao::abrir($row['payload']);if(!is_array($p))continue;
                $r=F3Base_Pipedrive_Api::com_consumidor('qualidade',static fn()=>self::conferir($row,$p));if(!F3Base_Pipedrive_Api::lote_atual())continue;$fresh=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$fresh||$fresh['lixeira']||$fresh['eliminacao_pendente'])continue;
                $where=['chave'=>$row['chave'],'payload'=>$row['payload'],'conta'=>$account,'historico_final'=>0];$out=$r;unset($out['proxima'],$out['final']);if(false!==$wpdb->update(F3Base_Email_Novo_Lead::tabela(),['historico'=>wp_json_encode($out),'historico_final'=>!empty($r['final'])?1:0,'historico_proxima'=>$r['proxima']??0],$where))$n++;
            }return ['ok'=>true,'conferidos'=>$n];
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function projecao(?string $json): array {$v=json_decode($json??'',true)?:['estado'=>'nao_conferido','conferido_em'=>null,'motivo'=>'ainda_nao_conferido'];unset($v['contexto'],$v['start']);return $v;}
    public static function iniciar(): void {
        /* Catalog declaration belongs to F3Base_Options. */
        add_filter('cron_schedules',static function($s){$s['f3base_email_historico_5m']=['interval'=>300,'display'=>'Conferência de e-mail a cada cinco minutos'];return $s;});add_action(self::HOOK,[__CLASS__,'processar']);add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),125);
    }
    public static function conferir_agenda_1(): void {
        if (self::aplicavel()) {
            if (!wp_next_scheduled(self::HOOK)) { wp_schedule_event(time()+180,'f3base_email_historico_5m',self::HOOK); }
            return;
        }
        self::encerrar_inativa();
    }
    public static function encerrar_inativa(): bool {
        $retirado = wp_clear_scheduled_hook(self::HOOK, [], true);
        return !is_wp_error($retirado) && $retirado !== false && F3Base_Operacao_Intencoes::encerrar_anteriores(
            'email_historico', self::HOOK, time(), 'nao_aplicavel'
        );
    }
}
