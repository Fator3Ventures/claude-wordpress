<?php
/** Métricas editoriais: uma fonte por fato e cobertura explícita. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Editorial_Consulta_Falha extends RuntimeException {
    public array $diagnostico;
    public function __construct(string $codigo,array $diagnostico){parent::__construct($codigo);$this->diagnostico=$diagnostico;}
}
final class F3Base_Editorial_Relatorios {
    const MAX_LINHAS=100000;
    private const LOTE=128;
    private const BYTES_LINHA=32768;
    private static array $memoria_inicio=array();
    private static array $memoria_fontes=array();
    public static function schema(): array {return array('gsc_escopo'=>array('type'=>'string','enum'=>array('paginas','consultas')),'consulta'=>array('type'=>'string','maxLength'=>2000),'pagina_url'=>array('type'=>'string','maxLength'=>2000))+F3Base_Audiencia::dimensoes_schema()+array('ip'=>array('type'=>'string','maxLength'=>45),'visitante'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'app'=>array('type'=>'string','pattern'=>'^[a-z][a-z0-9_]{0,63}$'),'tipo_atribuicao'=>array('type'=>'string','enum'=>array('todas','observada','atribuicao_manual'),'default'=>'todas'),'gsc_propriedade'=>array('type'=>'string','maxLength'=>250),'plataforma'=>array('type'=>'string'),'conta_id'=>array('type'=>'string'),'campanha_id'=>array('type'=>'string'),'grupo_id'=>array('type'=>'string'),'anuncio_id'=>array('type'=>'string'),'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'visao'=>array('type'=>'string','enum'=>array('resumo','conteudo','sessoes','sessao','aquisicao','origem_ia','qualidade','gsc','referencias')),'recorte'=>array('type'=>'string','enum'=>array('todos','organico','ia','sem_observacoes')),'tipo'=>array('type'=>'string','enum'=>array('','pagina','artigo','outro')),'post_id'=>array('type'=>'integer','minimum'=>0),'caminho'=>array('type'=>'string','maxLength'=>190),'sessao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'canal'=>array('type'=>'string','enum'=>array_keys(F3Base_Audiencia::canais())),'origem_ia'=>array('type'=>'string','enum'=>array_keys(F3Base_Audiencia::provedores())),'segmento'=>array('type'=>'string','enum'=>F3Base_Testes::SEGMENTOS),'automacao'=>array('type'=>'string','enum'=>array('audiencia','todas','declarada','provavel')),'anotacoes'=>array('type'=>'boolean'),'pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>10000),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>200),'ordenar'=>array('type'=>'string','enum'=>array('visualizacoes','sessoes','titulo','inicio','tempo_ativo_ms','requisicoes_ia','entradas_organicas','envios','cliques')),'direcao'=>array('type'=>'string','enum'=>array('asc','desc')),'comparar'=>array('type'=>'boolean'));}
    public static function abandono(array $row): array {
        $stage=(int)($row['etapa']??0);
        return array('instancia'=>$row['correlacao']??'','ultimo_campo'=>$stage&&($row['ultimo_campo']??'')!==''?$row['ultimo_campo']:'nao_observado','etapa'=>$stage?:'nao_observado','campos_preenchidos'=>$stage && isset($row['campos_preenchidos'])?(int)$row['campos_preenchidos']:'nao_observado');
    }
    public static function instante(int $stamp): array {return array('utc'=>gmdate('c',$stamp),'local'=>wp_date('d/m/Y H:i:s',$stamp),'fuso'=>wp_timezone_string(),'offset'=>wp_date('P',$stamp));}
    public static function duracao(?float $ms): string {if($ms===null){return 'Indisponível';}if($ms<1000){return (string)round($ms).' ms';}$s=(int)round($ms/1000);if($s<60){return $s.' s';}if($s<3600){return intdiv($s,60).' min '.($s%60).' s';}return intdiv($s,3600).' h '.str_pad((string)intdiv($s%3600,60),2,'0',STR_PAD_LEFT).' min';}
    public static function consultar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(is_wp_error(rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::schema())))){return array('ok'=>false,'codigo'=>'filtros_invalidos');}
        $e+=array('tipo_atribuicao'=>'todas','de'=>wp_date('Y-m-d',time()-29*DAY_IN_SECONDS),'ate'=>wp_date('Y-m-d'),'visao'=>'resumo','segmento'=>F3Base_Testes::segmento(),'automacao'=>!empty(F3Base_Options::ler('f3base_medicao_editorial')['excluir_automacao'])?'audiencia':'todas','anotacoes'=>!empty(F3Base_Options::ler('f3base_medicao_editorial')['aplicar_anotacoes']),'pagina'=>1,'limite'=>50,'ordenar'=>'sessoes','direcao'=>'desc');
        if(!empty($e['ip'])||!empty($e['visitante'])){if(!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao_dados_pessoais');}if(!empty($e['ip'])&&F3Base_Sessao_Contexto::ip($e['ip'])===''){return array('ok'=>false,'codigo'=>'ip_invalido');}}
        if(array_intersect_key($e,array_flip(array('ip','visitante','app')))&&!in_array($e['visao'],array('sessao','sessoes'),true)){return array('ok'=>false,'codigo'=>'filtro_exige_visao_sessoes');}
        if($e['tipo_atribuicao']!=='todas'&&in_array($e['visao'],array('gsc','referencias'),true)){return array('ok'=>false,'codigo'=>'tipo_atribuicao_nao_suportado_nesta_visao');}
        if($e['visao']==='origem_ia'){$e['canal']='ia';}if(($e['recorte']??'')==='organico'){$e['canal']='busca_organica';}
        try{[$de]=F3Base_Editorial::janela_dia($e['de']);[, $ate]=F3Base_Editorial::janela_dia($e['ate']);}catch(Throwable $x){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        if($de>=$ate||$ate-$de>397*DAY_IN_SECONDS){return array('ok'=>false,'codigo'=>'periodo_maximo_13_meses');}
        if($e['visao']==='gsc'){$gsc=($e['gsc_escopo']??'paginas')==='consultas'?F3Base_Gsc_Consultas_Acervo::consultar($e):F3Base_Inteligencia::gsc($e);if(!empty($e['comparar'])){$gsc['comparacao']=array('ok'=>false,'codigo'=>'comparacao_nao_suportada','totais'=>null,'motivo'=>'A visão Search Console não oferece comparação neste relatório. Consulte separadamente o período anterior.');}return $gsc;}if($e['visao']==='referencias'){return F3Base_Inteligencia::referencias($e);}
        if(function_exists('gc_mem_caches')){gc_mem_caches();}
        self::$memoria_inicio=array('viva'=>memory_get_usage(false),'arena'=>memory_get_usage(true));self::$memoria_fontes=array();
        try{$r=self::calcular($e,$de,$ate);}catch(Throwable $x){return self::falha($x,$e);}
        if(!empty($e['comparar'])&&!in_array($e['visao'],array('sessao','sessoes'),true)){
            $antes=$e;$antes['comparar']=false;$dias=(new DateTimeImmutable($e['de']))->diff(new DateTimeImmutable($e['ate']))->days+1;$start=new DateTimeImmutable($e['de'],wp_timezone());$antes['ate']=$start->modify('-1 day')->format('Y-m-d');$antes['de']=$start->modify('-'.$dias.' days')->format('Y-m-d');[$pde]=F3Base_Editorial::janela_dia($antes['de']);[, $pate]=F3Base_Editorial::janela_dia($antes['ate']);
            try{$old=self::calcular($antes,$pde,$pate);$retidos=self::dias_audiencia_retida($pde,$pate);$hasAudience=count($retidos)>0;$partial=count($retidos)<$dias;$r['comparacao']=array('dias_com_audiencia_retida'=>$retidos,'dias_retidos'=>count($retidos),'dias_periodo'=>$dias,'parcial'=>$partial,'ok'=>true,'de'=>$antes['de'],'ate'=>$antes['ate'],'totais'=>$hasAudience?$old['totais']:null,'codigo'=>$hasAudience?($partial?'anterior_parcial':'comparacao_disponivel'):'audiencia_nao_retida','motivo'=>$hasAudience?($partial?'Totais limitados aos dias com audiência retida; dias sem observações não representam zero.':''):'Não há observações de audiência retidas no período anterior; ausência não representa zero.','cobertura'=>$old['cobertura'],'ia_serie_semanal'=>$old['ia_serie_semanal']);}
            catch(Throwable $x){$r['comparacao']=self::falha($x,$antes)+array('de'=>$antes['de'],'ate'=>$antes['ate'],'totais'=>null);}
        }$r['definicoes_sessoes']=array('sessoes'=>'Sessões distintas com visualização observada no período.','sessoes_iniciadas'=>'Entradas cujo início de sessão está comprovado no período. Pode ser menor por sessões iniciadas antes da janela ou início sem cobertura.');return $r;
    }
    public static function dias_audiencia_retida(int $de,int $ate): array {
        global $wpdb;
        $case='CASE';$day=(new DateTimeImmutable('@'.$de))->setTimezone(wp_timezone());
        while($day->getTimestamp()<$ate){$next=$day->modify('+1 day');$case.=$wpdb->prepare(' WHEN criado_em<%d THEN %s',$next->getTimestamp(),$day->format('Y-m-d'));$day=$next;}$case.=' END';
        $dias=$wpdb->get_col($wpdb->prepare('SELECT DISTINCT '.$case.' AS dia FROM %i WHERE criado_em>=%d AND criado_em<%d AND tipo="pagina"',F3Base_Analise::tabela(),$de,$ate));
        if($wpdb->last_error){throw new RuntimeException('audiencia_indisponivel');}
        $agg=$wpdb->get_col($wpdb->prepare('SELECT DISTINCT dia FROM %i WHERE dia BETWEEN %s AND %s AND metrica IN ("sessoes_iniciadas","visualizacoes") AND contagem>0',F3Base_Editorial::tabela('editorial_diario'),wp_date('Y-m-d',$de),wp_date('Y-m-d',$ate-1)));
        if($wpdb->last_error){throw new RuntimeException('audiencia_indisponivel');}
        $dias=array_values(array_unique(array_merge($dias,$agg)));sort($dias);return $dias;
    }
    public static function audiencia_retida(int $de,int $ate): bool {
        global $wpdb;
        $raw=$wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE criado_em>=%d AND criado_em<%d AND tipo="pagina" LIMIT 1',F3Base_Analise::tabela(),$de,$ate));
        if($raw!==null){return true;}
        $agg=$wpdb->get_var($wpdb->prepare('SELECT dia FROM %i WHERE dia BETWEEN %s AND %s AND metrica IN ("sessoes_iniciadas","visualizacoes") AND contagem>0 LIMIT 1',F3Base_Editorial::tabela('editorial_diario'),wp_date('Y-m-d',$de),wp_date('Y-m-d',$ate-1)));
        return $agg!==null;
    }
    private static function falha(Throwable $x,array $e): array {
        $known=$x instanceof F3Base_Editorial_Consulta_Falha;$code=$known?$x->getMessage():'consulta_indisponivel';
        $diagnostico=$known?$x->diagnostico:array('etapa'=>'calculo','classe'=>get_class($x));
        if($code==='orcamento_memoria_editorial'){
            $largest=null;foreach(self::$memoria_fontes as $source){if($largest===null||$source['crescimento_vivo_bytes']>$largest['crescimento_vivo_bytes']){$largest=$source;}}
            $diagnostico['fonte_consulta_recusada']=$diagnostico['fonte']??null;
            $diagnostico['linhas_consulta_recusada']=$diagnostico['linhas']??null;
            $diagnostico['fonte_maior_crescimento']=$largest;
            if($largest&&$largest['crescimento_vivo_bytes']>0){$diagnostico['fonte']=$largest['fonte'];$diagnostico['linhas']=$largest['linhas'];}
        }
        return array('ok'=>false,'codigo'=>$code,'motivo'=>in_array($code,array('limite_linhas_editorial','orcamento_memoria_editorial'),true)?'A consulta alcançou o orçamento indicado. Filtre conteúdo ou reduza o período.':'A fonte não pôde ser consultada. Confira o diagnóstico técnico; falha não representa tráfego zero.','diagnostico'=>$diagnostico+array('periodo'=>array('de'=>$e['de'],'ate'=>$e['ate']),'visao'=>$e['visao']));
    }
    private static function planejar(string $sql,bool $stream): array {
        global $wpdb;if (!preg_match('/FROM\s+`?([a-zA-Z0-9_]+)`?\s+ev\s+WHERE/i',$sql,$m)) { preg_match('/FROM\s+`?([a-zA-Z0-9_]+)/i',$sql,$m); }$source=$m[1]??'acessos_agregados';
        $n=$wpdb->get_var('SELECT COUNT(*) FROM ('.$sql.') f3base_contagem');$d=array('fonte'=>$source,'limite_linhas'=>self::MAX_LINHAS,'linhas'=>is_numeric($n)?(int)$n:null,'contagem_minima'=>(int)$n>self::MAX_LINHAS,'processamento'=>$stream?'lotes_128':'conjunto_pareado');
        if($wpdb->last_error||$n===null){throw new F3Base_Editorial_Consulta_Falha('consulta_sql_falhou',$d+array('etapa'=>'contagem'));}
        $n=(int)$n;if($n>self::MAX_LINHAS){throw new F3Base_Editorial_Consulta_Falha('limite_linhas_editorial',$d);}
        $mem=self::memoria_atual();$free=$mem['memoria_disponivel_bytes'];
        $batch=$stream?max(1,min(self::LOTE,(int)floor(($free??0)/self::BYTES_LINHA))):$n;
        $estimate=($stream?min($batch,$n)*self::BYTES_LINHA:$n*5000);$d+=$mem+array('memoria_estimada_bytes'=>$estimate,'tamanho_lote'=>$batch,'estimativa'=>($stream?'32768 bytes por linha de lote, máximo 128; ':'5000 bytes por linha; ').'agregados retidos fiscalizados; reserva adaptativa até 20 MiB');
        if($n>0&&($free===null||$estimate>$free)){throw new F3Base_Editorial_Consulta_Falha('orcamento_memoria_editorial',$d);}return $d;
    }
    public static function orcamento_memoria($bruto,int $uso): array {
        $raw=is_string($bruto)?trim($bruto):null;$unlimited=$raw==='-1';$bytes=null;
        if($raw!==null&&preg_match('/^([0-9]+)\s*([KMGTP]?)(?:B)?$/iD',$raw,$m)){
            $factor=1024**(strpos(' KMGTP',strtoupper($m[2]))?:0);$value=(float)$m[1]*$factor;
            if($value<=PHP_INT_MAX){$bytes=(int)$value;}
        }
        $limit=$unlimited?null:$bytes;$headroom=max(0,($unlimited?384*1024*1024:($limit??0))-$uso);
        $reserve=min(20*1024*1024,max(256*1024,(int)floor($headroom/10)));
        $free=$unlimited?max(0,384*1024*1024-$uso-$reserve):($limit===null?null:max(0,$limit-$uso-$reserve));
        return array('memory_limit_bruto'=>$bruto,'memory_limit_bytes'=>$limit,'memory_limit_estado'=>$unlimited?'ilimitado':($bytes===null?'indisponivel':'limitado'),'orcamento_efetivo_bytes'=>$unlimited?384*1024*1024:$limit,'memoria_uso_bytes'=>$uso,'memoria_reserva_bytes'=>$reserve,'memoria_disponivel_bytes'=>$free,'orcamento_fonte'=>$unlimited?'teto_local_384_mib':'ini_get_memory_limit');
    }

    private static function memoria_atual(): array {
        $arena=memory_get_usage(true);$viva=memory_get_usage(false);
        $m=self::orcamento_memoria(ini_get('memory_limit'),$arena);
        return $m+array('memoria_uso_base'=>'memory_get_usage(true); base fiscalizada por memory_limit',
            'memoria_viva_bytes'=>$viva,'memoria_arena_livre_bytes'=>max(0,$arena-$viva),
            'memoria_pico_arena_bytes'=>memory_get_peak_usage(true),
            'memoria_antes_consulta'=>self::$memoria_inicio,
            'memoria_crescimento_arena_bytes'=>max(0,$arena-(self::$memoria_inicio['arena']??$arena)),
            'memoria_fontes_retidas'=>self::$memoria_fontes,
            'atribuicao_memoria'=>'A base inclui WordPress, plugins e transporte carregados antes desta consulta; bytes por plugin não medidos. Fontes registram crescimento observado, não atribuição exclusiva.');
    }
    private static function query(string $sql): array {
        global $wpdb;$d=self::planejar($sql,false);$before=memory_get_usage(false);$r=$wpdb->get_results($sql,ARRAY_A);if($wpdb->last_error){throw new F3Base_Editorial_Consulta_Falha('consulta_sql_falhou',$d+array('etapa'=>'leitura'));}$wpdb->last_result=array();self::$memoria_fontes[]=array('fonte'=>$d['fonte'],'linhas'=>count($r),'crescimento_vivo_bytes'=>max(0,memory_get_usage(false)-$before));return $r;
    }
    /** Bounded raw buffers; only compact indexes and aggregates survive each batch. */
    private static function iterar(string $sql): Generator {
        global $wpdb;$d=self::planejar($sql,true);$base=preg_replace('/\s+LIMIT\s+[0-9]+\s*$/i','',$sql);
        $index=count(self::$memoria_fontes);$before=memory_get_usage(false);$read=0;
        self::$memoria_fontes[$index]=array('fonte'=>$d['fonte'],'linhas'=>$d['linhas'],'linhas_lidas'=>0,'crescimento_vivo_bytes'=>0,'processamento'=>'lotes_128','maior_lote'=>0);
        try {
            for($offset=0;$offset<$d['linhas'];$offset+=$size){
                $mem=self::memoria_atual();$free=$mem['memoria_disponivel_bytes']??0;
                $size=max(1,min(self::LOTE,(int)floor($free/self::BYTES_LINHA)));
                if($free<self::BYTES_LINHA){throw new F3Base_Editorial_Consulta_Falha('orcamento_memoria_editorial',array_merge($d,$mem,array('etapa'=>'lote','offset'=>$offset,'memoria_estimada_bytes'=>self::BYTES_LINHA)));}
                $batch=$wpdb->get_results($base.' LIMIT '.$size.' OFFSET '.(int)$offset,ARRAY_A);
                if($wpdb->last_error){throw new F3Base_Editorial_Consulta_Falha('consulta_sql_falhou',$d+array('etapa'=>'lote','offset'=>$offset));}
                $wpdb->flush();self::$memoria_fontes[$index]['maior_lote']=max(self::$memoria_fontes[$index]['maior_lote'],count($batch));
                foreach($batch as $row){++$read;yield $row;}
                unset($batch,$row);
                self::$memoria_fontes[$index]['linhas_lidas']=$read;
                self::$memoria_fontes[$index]['crescimento_vivo_bytes']=max(0,memory_get_usage(false)-$before);
            }
        }finally{
            unset($batch,$row);self::$memoria_fontes[$index]['linhas_lidas']=$read;
            self::$memoria_fontes[$index]['crescimento_vivo_bytes']=max(0,memory_get_usage(false)-$before);
        }
    }

    public static function elegivel(array $r,array $e,array $anotacoes,?string &$motivo=null): bool {
        $motivo='';if(($e['automacao']??'audiencia')==='audiencia'&&isset($r['caminho'])&&in_array(F3Base_Editorial::base($r['caminho'])['classe'],array('operacional','asset','varredura','descoberta'),true)){$motivo='caminho_tecnico';return false;}if($e['segmento']==='sem_testes'&&($r['classe_trafego']??'nao_marcado')==='teste'){$motivo='teste';return false;}
        if($e['segmento']==='somente_testes'&&($r['classe_trafego']??'')!=='teste'){$motivo='fora_segmento';return false;}
        $auto=$r['automacao']??'nao_identificada';if($e['automacao']==='audiencia'&&in_array($auto,array('declarada','provavel'),true)){$motivo='automacao_'.$auto;return false;}
        if(in_array($e['automacao'],array('declarada','provavel'),true)&&$auto!==$e['automacao']){$motivo='fora_automacao';return false;}
        $dia=$r['dia']??wp_date('Y-m-d',(int)$r['criado_em']);if($e['anotacoes']){foreach($anotacoes as $a){if($a['excluir']&&$a['inicio']<=$dia&&$a['fim']>=$dia){$motivo='periodo_anotado';return false;}}}return true;
    }
    public static function corresponde(array $r,array $e): bool {
        if(!empty($e['post_id'])&&(int)($r['post_id']??0)!==$e['post_id']){return false;}
        if(!empty($e['caminho'])&&rtrim($r['caminho']??'','/')!==rtrim($e['caminho'],'/')){return false;}
        if(!F3Base_Relatorios::atribuicao_filtrada(F3Base_Atribuicao::normalizar(json_decode($r['atribuicao']??'{}',true)?:array()),$e)){return false;}
        $t=$r['tipo_conteudo']??$r['tipo']??'';if(!empty($e['tipo'])&&($e['tipo']==='outro'?in_array($t,array('pagina','artigo'),true):$t!==$e['tipo'])){return false;}
        foreach(array_merge(array('canal','origem_ia'),F3Base_Audiencia::DIMENSOES) as $k){if(isset($e[$k])&&($r[$k]??'')!==$e[$k]){return false;}}return true;
    }
    public static function observacoes(array $rows,array $e): array {
        $e+=array('segmento'=>F3Base_Testes::segmento(),'automacao'=>!empty(F3Base_Options::ler('f3base_medicao_editorial')['excluir_automacao'])?'audiencia':'todas','anotacoes'=>!empty(F3Base_Options::ler('f3base_medicao_editorial')['aplicar_anotacoes']));
        $ann=F3Base_Inteligencia::anotacoes($e['de'],$e['ate']);
        return array_values(array_filter($rows,static fn($r)=>self::elegivel($r,$e,$ann)&&self::corresponde($r,$e)));
    }
    private static function calcular(array $e,int $de,int $ate): array {
        global $wpdb;$ann=F3Base_Inteligencia::anotacoes($e['de'],$e['ate']);$snapshot=time();$limit=self::MAX_LINHAS+1;
        $w=$wpdb->prepare('criado_em>=%d AND criado_em<%d',$de,$ate);
        if(!empty($e['sessao'])){$w=$wpdb->prepare('sessao=%s',$e['sessao']);if($e['visao']!=='sessao'){$w.=$wpdb->prepare(' AND criado_em>=%d AND criado_em<%d',$de,$ate);}}
        $content='';if(!empty($e['post_id'])){$content.=$wpdb->prepare(' AND post_id=%d',$e['post_id']);}if(!empty($e['caminho'])){$content.=$wpdb->prepare(' AND caminho=%s',F3Base_Analise::caminho($e['caminho']));}if(!empty($e['tipo'])){$content.=$e['tipo']==='outro'?" AND tipo_conteudo NOT IN ('pagina','artigo')":$wpdb->prepare(' AND tipo_conteudo=%s',$e['tipo']);}
        if($content&&$e['visao']!=='sessao'){$w.=$wpdb->prepare(' AND sessao IN (SELECT sessao FROM %i WHERE criado_em>=%d AND criado_em<%d',F3Base_Analise::tabela(),$de,$ate).$content.')';}
        $w.=F3Base_Contatos_Sessoes::filtro_sql($e['tipo_atribuicao']);$w.=F3Base_Sessao_Contexto::filtro_sql($e);
        $perfilSql=F3Base_Perfil_Aparelho::sql();
        $analysis=self::iterar($wpdb->prepare("SELECT id,visitante,sessao,classe_trafego,navegacao,navegacao_anterior,automacao,automacao_regra,aquisicao_regra,aquisicao_evidencia,aquisicao_conflitos,post_id,tipo_conteudo,canal,origem_ia,entrada,inicio_sessao,tipo,caminho,formulario,ultimo_campo,etapa,campos_preenchidos,correlacao,criado_em,qualidade,detalhe,valor,atribuicao,largura_faixa,navegador,sistema,retorno,aparelho,{$perfilSql} FROM %i ev WHERE {$w} ORDER BY criado_em,id LIMIT {$limit}",F3Base_Analise::tabela()));
        $events=self::iterar($wpdb->prepare("SELECT id,sessao,navegacao,classe_trafego,automacao,caminho,criado_em,metrica,detalhe,valor,ms,ancora,link_tipo,link_destino FROM %i WHERE {$w} ORDER BY criado_em,id LIMIT {$limit}",F3Base_Modulo_Comportamento::nome_tabela_eventos()));
        $attributionFiltered=$e['tipo_atribuicao']!=='todas'||!empty($e['ip'])||!empty($e['visitante'])||!empty($e['app']);
        $agg=(!empty($e['sessao'])||$attributionFiltered)?array():self::query($wpdb->prepare('SELECT a.* FROM %i a JOIN %i d ON d.dia=a.dia WHERE a.dia BETWEEN %s AND %s AND d.qualidade=%s LIMIT '.$limit,F3Base_Editorial::tabela('editorial_diario'),F3Base_Editorial::tabela('editorial_dias'),$e['de'],$e['ate'],'bruto_expirado'));
        $logCoverage=F3Base_Acessos_Coleta::cobertura($e['de'],$e['ate']);$logComplete=$logCoverage&&!array_filter($logCoverage,static fn($c)=>$c['estado']!=='completo');
        $oldDays=array_fill_keys(array_column($agg,'dia'),true);$sessions=array();$pages=array();$navs=array();$daily=array();$channels=array();$excluded=array();$timeline=array();$technical=array();$history=0;
        $catalog=self::query($wpdb->prepare('SELECT post_id,titulo,caminho,tipo FROM %i WHERE publico=1 LIMIT '.$limit,F3Base_Editorial::tabela('conteudos')));$titles=array_column($catalog,'titulo','post_id');$cat=array_column($catalog,null,'post_id');
        $empty=static fn($id,$path,$type)=>array('post_id'=>(int)$id,'titulo'=>$titles[$id]??($path?:'Conteúdo sem referência'),'caminho'=>F3Base_Editorial::caminho($path),'tipo'=>$type,'visualizacoes'=>0,'sessoes_ids'=>array(),'visitantes_ids'=>array(),'sessoes_iniciadas'=>0,'entradas'=>0,'entradas_organicas'=>0,'anteriores'=>array(),'seguintes'=>array(),'form_inicios'=>0,'form_tentativas'=>0,'saidas'=>array(),'saltos'=>array(),'amostra_salto_agregada'=>0,'soma_salto_agregada'=>0,'saidas_agregadas'=>0,'visivel_agregado'=>0,'duracao_agregada'=>0,'entradas_com_ancora'=>0,'cliques_internos'=>array(),'cliques_inertes'=>array(),'amostra_tempo_agregada'=>0,'amostra_rolagem_agregada'=>0,'soma_rolagem_agregada'=>0,'secoes_vistas'=>0,'tempo_ativo_ms'=>0,'amostras_tempo'=>array(),'rolagem'=>array(),'secoes'=>array(),'cliques'=>0,'envios'=>0,'continuidades'=>0,'requisicoes_ia'=>0,'ia_rede_compativel'=>0,'ia_nao_verificada'=>0,'ia_html'=>0,'ia_markdown'=>0,'referencias_ia'=>0,'origens'=>array());
        $pageKey=static fn($r)=>!empty($r['post_id'])?'id:'.$r['post_id']:'path:'.F3Base_Editorial::caminho($r['caminho']??'');
        $allNav=array();$entries=array();$dimensions=array();
        foreach($analysis as $r){
            $r+=(json_decode((string)($r['perfil_aparelho']??''),true)?:[]);
            $sk=$r['classe_trafego'].'|'.$r['sessao'];
            // Normalize before exclusion, exactly as the former complete-array pass did.
            if(!empty($r['sessao'])){
                if(!isset($dimensions[$sk])){$dimensions[$sk]=array_intersect_key($r,F3Base_Audiencia::dimensoes_schema());}
                foreach(F3Base_Audiencia::DIMENSOES as $dimension){$r[$dimension]=$dimensions[$sk][$dimension]??'';}
            }
            if($r['tipo']==='pagina'&&self::elegivel($r,$e,$ann,$reason)){
                $key=$sk.'|'.$r['navegacao'];
                if(!isset($allNav[$key])){$allNav[$key]=array('post_id'=>$r['post_id'],'caminho'=>$r['caminho'],'criado_em'=>(int)$r['criado_em'],'anterior'=>$r['navegacao_anterior']!==''?$sk.'|'.$r['navegacao_anterior']:'');}
            }
            if(isset($oldDays[wp_date('Y-m-d',(int)$r['criado_em'])])&&$e['visao']!=='sessao'){continue;}
            if(!self::elegivel($r,$e,$ann,$reason)){$excluded[$reason]=($excluded[$reason]??0)+1;continue;}
            if(empty($r['automacao_regra'])){++$history;}
            $sk=$r['classe_trafego'].'|'.$r['sessao'];$source=json_decode($r['atribuicao'],true)?:array();$src=$source['sessao_origem']??$source;
            if(!isset($sessions[$sk])){$origin=F3Base_Audiencia::canal($src);$sessions[$sk]=array('sessao'=>$r['sessao'],'inicio'=>(int)$r['criado_em'],'inicio_sessao'=>(int)$r['inicio_sessao'],'ultimo'=>(int)$r['criado_em'],'entrada'=>$r['entrada']?:$r['caminho'],'inicio_coberto'=>(int)$r['inicio_sessao']>0,'canal'=>$r['automacao_regra']?$r['canal']:$origin['canal'],'origem_ia'=>$r['automacao_regra']?$r['origem_ia']:$origin['origem_ia'],'aquisicao_evidencia'=>$r['aquisicao_evidencia']??$origin['evidencia'],'aquisicao_conflitos'=>$r['aquisicao_conflitos']??$origin['conflitos'],'origem_reconstruida'=>empty($r['aquisicao_regra']),'automacao'=>$r['automacao'],'classe_trafego'=>$r['classe_trafego'],'visitante'=>$r['visitante'],'navegacoes'=>array(),'conteudos'=>array(),'visualizacoes'=>0,'tempo_ativo_ms'=>0,'cliques'=>0,'envios'=>0,'ultima_pagina'=>$r['caminho'],'incluida'=>false,'saidas'=>array())+array_intersect_key($r,F3Base_Audiencia::dimensoes_schema());}
            $s=&$sessions[$sk];if($r['canal']!==$s['canal']){$r['canal']=$s['canal'];}if($r['origem_ia']!==$s['origem_ia']){$r['origem_ia']=$s['origem_ia'];}$s['ultimo']=max($s['ultimo'],(int)$r['criado_em']);
            if(($e['visao']==='sessao'&&!self::corresponde($r,array_intersect_key($e,F3Base_Audiencia::dimensoes_schema())))||(!self::corresponde($r,$e)&&$e['visao']!=='sessao')){unset($s);continue;}$s['incluida']=true;
            $pk=$pageKey($r);if(!isset($pages[$pk])){$pages[$pk]=$empty($r['post_id'],$cat[$r['post_id']]['caminho']??$r['caminho'],$r['tipo_conteudo']);}$p=&$pages[$pk];
            $nk=$sk.'|'.($r['navegacao']?:'evento:'.$r['id']);$at=(int)$r['criado_em'];
            if($r['tipo']==='pagina'&&!isset($navs[$nk])){
                $navs[$nk]=array('post_id'=>$r['post_id'],'caminho'=>$r['caminho'],'criado_em'=>$r['criado_em'],'destacado'=>self::corresponde($r,$e));if(($r['detalhe']??'')==='ancora'){++$p['entradas_com_ancora'];}++$s['visualizacoes'];$s['navegacoes'][$r['navegacao']]=true;$s['conteudos'][$pk]=true;$s['ultima_pagina']=$r['caminho'];++$p['visualizacoes'];$p['sessoes_ids'][$sk]=true;$p['visitantes_ids'][$r['visitante']]=true;$p['origens'][$s['canal']]=($p['origens'][$s['canal']]??0)+1;
                if(!isset($entries[$sk])&&$s['inicio_coberto']&&$s['inicio_sessao']>=$de&&$s['inicio_sessao']<$ate&&rtrim($s['entrada'],'/')===rtrim($r['caminho'],'/')){$entries[$sk]=true;++$p['entradas'];++$p['sessoes_iniciadas'];if($s['canal']==='busca_organica'){++$p['entradas_organicas'];}}
                $day=wp_date('Y-m-d',$at);$daily[$day]=($daily[$day]??0)+1;
                
                if($e['visao']==='sessao')$timeline[]=array('em'=>$at,'navegacao'=>$r['navegacao'],'caminho'=>$r['caminho'],'acao'=>'Página vista','detalhe'=>'','qualidade'=>$r['qualidade'],'destacado'=>self::corresponde($r,$e));
            }elseif($r['tipo']==='vital'){if(in_array($e['visao'],array('qualidade','sessao'),true))$technical[]=array('modelo'=>$r['modelo']??'','faixa_aparelho'=>$r['faixa_aparelho']??'','em'=>$at,'navegacao'=>$r['navegacao'],'caminho'=>$r['caminho'],'metrica'=>$r['detalhe'],'valor'=>(float)$r['valor'],'unidade'=>$r['detalhe']==='CLS'?'indice':'ms','automacao'=>$r['automacao']);}
            elseif(!in_array($r['tipo'],['pagina','clique_link'],true)){if($r['tipo']==='form_inicio'){++$p['form_inicios'];}if($r['tipo']==='form_tentativa'){++$p['form_tentativas'];}if($e['visao']==='sessao')$timeline[]=array('em'=>$at,'navegacao'=>$r['navegacao'],'caminho'=>$r['caminho'],'acao'=>array('form_vista'=>'Formulário visto','form_inicio'=>'Formulário iniciado','form_tentativa'=>'Tentativa de envio','form_erro'=>'Erro no formulário')[$r['tipo']]??$r['tipo'],'detalhe'=>$r['formulario'].' '.$r['detalhe'],'qualidade'=>$r['qualidade'],'destacado'=>self::corresponde($r,$e))+($r['tipo']==='form_fechado'?self::abandono($r):array());}
            unset($s,$p);
        }
        unset($dimensions,$analysis,$r);
        foreach($allNav as $nav){if($nav['anterior']===''){continue;}$previous=$allNav[$nav['anterior']]??null;if(!$previous||(int)$previous['criado_em']>(int)$nav['criado_em']){continue;}$from=$pageKey($previous);$to=$pageKey($nav);if(isset($pages[$to])){++$pages[$to]['continuidades'];$pages[$to]['anteriores'][$previous['caminho']]=($pages[$to]['anteriores'][$previous['caminho']]??0)+1;}if(isset($pages[$from])){$pages[$from]['seguintes'][$nav['caminho']]=($pages[$from]['seguintes'][$nav['caminho']]??0)+1;}}
        unset($allNav,$nav,$previous);
        $metricTime=F3Base_Modulo_Comportamento::evento_do_gatilho('tempo-ativo');$metricScroll=F3Base_Modulo_Comportamento::evento_do_gatilho('rolagem');$metricSection=F3Base_Modulo_Comportamento::evento_do_gatilho('interseccao');$metricPage=F3Base_Modulo_Comportamento::evento_do_gatilho('pagina');
        $metricFormClosed = F3Base_Modulo_Comportamento::evento_do_gatilho('formulario-fechado');
        foreach($events as $r){
            if(isset($oldDays[wp_date('Y-m-d',(int)$r['criado_em'])])||!self::elegivel($r,$e,$ann,$reason)){continue;}$sk=$r['classe_trafego'].'|'.$r['sessao'];$nk=$sk.'|'.($r['navegacao']??'');$a=$navs[$nk]??null;
            // O evento de comportamento só traz formulário e motivo. O fechamento analítico guarda a observação por instância.
            $dadosEvento = ($r['metrica'] === $metricFormClosed || $r['metrica'] === 'f3base_form_fechado')
                ? self::abandono(array())
                : F3Base_Modulo_Comportamento::alvo_evento($r['metrica'], $r['detalhe']);
            if(!$a){if($e['visao']==='sessao'&&!empty($sessions[$sk]['incluida'])){if($e['visao']==='sessao')$timeline[]=array('em'=>(int)$r['criado_em'],'navegacao'=>$r['navegacao']?:'','caminho'=>$r['caminho'],'acao'=>'Comportamento sem navegação pareada','detalhe'=>$r['metrica'].' '.$r['detalhe'],'qualidade'=>'pareamento_indisponivel','destacado'=>rtrim($e['caminho']??'','/')===rtrim($r['caminho'],'/'))+$dadosEvento;}continue;}
            $pk=$pageKey($a);$p=&$pages[$pk];$s=&$sessions[$sk];$detail=$r['detalhe'];$action='';
            if($r['metrica']===F3Base_Clique_Link::METRICA){
                $detail=$r['link_destino'];$action='Clique em link';
                if($r['link_tipo']==='externo'){$p['seguintes'][$detail]=($p['seguintes'][$detail]??0)+1;}
            }
            elseif($r['metrica']===$metricTime){$ms=max(0,min(30000,(float)$r['valor']));$p['tempo_ativo_ms']+=$ms;$p['amostras_tempo'][$nk]=true;$s['tempo_ativo_ms']+=$ms;$action='Tempo ativo';$detail=self::duracao($ms).' · '.$detail;}
            elseif($r['metrica']===$metricScroll){$p['rolagem'][$nk]=max($p['rolagem'][$nk]??0,(int)$r['detalhe']);$action='Rolagem';$detail.='%';}
            elseif($r['metrica']===F3Base_Modulo_Comportamento::evento_do_gatilho('saida')){F3Base_Medicao_Consumo::ultima($p['saidas'],$nk,$r);F3Base_Medicao_Consumo::ultima($s['saidas'],$nk,$r);$action='Saída observada';$detail=self::duracao((float)$r['ms']).' decorridos · '.self::duracao((float)$r['valor']).' visíveis · '.$r['detalhe'].'% de profundidade';}
            elseif($r['metrica']===F3Base_Modulo_Comportamento::evento_do_gatilho('rolagem-salto')){$p['saltos'][$nk]=max($p['saltos'][$nk]??0,(int)$r['detalhe']);$action='Salto de rolagem';$detail.='%';}
            elseif($r['metrica']===F3Base_Modulo_Comportamento::evento_do_gatilho('clique-interno')){$p['cliques_internos'][$detail]=($p['cliques_internos'][$detail]??0)+1;$action='Clique interno';$detail.=' · origem '.(int)$r['valor'];}
            elseif($r['metrica']===F3Base_Modulo_Comportamento::evento_do_gatilho('clique-inerte')){$p['cliques_inertes'][$detail]=($p['cliques_inertes'][$detail]??0)+1;$action='Clique em área sem ação observada';}
            elseif($r['metrica']===$metricSection){$p['secoes'][$r['detalhe']]=true;++$p['secoes_vistas'];$action='Seção visível';}
            elseif($r['metrica']!==$metricPage){$action=$r['metrica'];}
            if($action){if($e['visao']==='sessao')$timeline[]=array('em'=>(int)$r['criado_em'],'navegacao'=>$r['navegacao'],'caminho'=>$r['caminho'],'acao'=>$action,'detalhe'=>$detail,'qualidade'=>$r['ancora'],'destacado'=>$a['destacado'])+$dadosEvento;}unset($p,$s);
        }
        $leadWhere=$wpdb->prepare('criado_em>=%s AND criado_em<%s',gmdate('Y-m-d H:i:s',$de),gmdate('Y-m-d H:i:s',$ate));if($e['visao']==='sessao'&&!empty($e['sessao'])){$leadWhere=$wpdb->prepare('sessao=%s',$e['sessao']);}
        $leads=self::iterar($wpdb->prepare("SELECT record_id,sessao,post_id,pagina,metodo,captura,classe_trafego,criado_em,dados FROM %i WHERE lixeira=0 AND eliminacao_pendente=0 AND {$leadWhere} ORDER BY criado_em LIMIT {$limit}",F3Base_Leads_Repositorio::tabela()));
        foreach($leads as $r){$d=F3Base_Leads_Repositorio::dados_relatorio($r['dados']);$at=strtotime($r['criado_em'].' UTC');$auto=$d['automacao']['automacao']??'nao_identificada';if(isset($oldDays[wp_date('Y-m-d',$at)])){continue;}$filter=array('classe_trafego'=>$r['classe_trafego'],'automacao'=>$auto,'criado_em'=>$at);if(!self::elegivel($filter,$e,$ann,$reason)){continue;}$sk=$r['classe_trafego'].'|'.$r['sessao'];$nk=$sk.'|'.($d['navegacao']??'');$a=$navs[$nk]??null;if(!$a){continue;}$pk=$pageKey($a);if(!isset($pages[$pk])){continue;}$isClick=str_ends_with($r['metodo'],'_cta');$metric=$isClick?'cliques':'envios';if(!$isClick&&$r['captura']!=='aceito'){continue;}++$pages[$pk][$metric];++$sessions[$sk][$metric];if($e['visao']==='sessao')$timeline[]=array('em'=>$at,'navegacao'=>$d['navegacao'],'caminho'=>$a['caminho'],'acao'=>$isClick?'Clique de contato':'Formulário aceito','detalhe'=>$r['metodo'],'qualidade'=>'registro_persistido','lead'=>$r['record_id'],'destacado'=>$a['destacado']);}
        foreach($agg as $r){if(!self::elegivel($r,$e,$ann,$reason)||!self::corresponde($r,$e)){continue;}$pk=$pageKey($r);if(!isset($pages[$pk])){$pages[$pk]=$empty($r['post_id'],$r['caminho'],$r['tipo']);}$p=&$pages[$pk];$m=$r['metrica'];$n=(int)$r['contagem'];
            if($m==='visualizacoes'){$p['visualizacoes']+=$n;$daily[$r['dia']]=($daily[$r['dia']]??0)+$n;$p['origens'][$r['canal']]=($p['origens'][$r['canal']]??0)+$n;}
            elseif($m==='sessoes_iniciadas'){$p['sessoes_iniciadas']+=$n;$p['entradas']+=$n;if($r['canal']==='busca_organica'){$p['entradas_organicas']+=$n;}}
            elseif(in_array($m,array('cliques','envios','secoes_vistas'),true)){$p[$m]+=$n;}
            elseif($m==='tempo_ativo_ms'){$p['tempo_ativo_ms']+=(float)$r['soma'];}elseif($m==='amostras_tempo'){$p['amostra_tempo_agregada']+=$n;}
            elseif($m==='rolagem'){$p['amostra_rolagem_agregada']+=$n;$p['soma_rolagem_agregada']+=(float)$r['soma'];}
            elseif($m==='saidas'){$p['saidas_agregadas']+=$n;$p['visivel_agregado']+=(float)$r['soma'];}elseif($m==='duracao_saida_ms'){$p['duracao_agregada']+=(float)$r['soma'];}elseif($m==='rolagem_salto'){$p['amostra_salto_agregada']+=$n;$p['soma_salto_agregada']+=(float)$r['soma'];}elseif($m==='entradas_com_ancora'){$p['entradas_com_ancora']+=$n;}
            elseif($m==='form_inicio'){$p['form_inicios']+=$n;}elseif($m==='form_tentativa'){$p['form_tentativas']+=$n;}unset($p);
        }
        $iaSeparada=array('descoberta'=>0,'sem_identidade_editorial'=>0,'automacao_suspeita'=>0);$pathsCatalogo=array_fill_keys(array_map(static fn($c)=>F3Base_Editorial::caminho($c['caminho']),$catalog),true);
        $fonteBots=F3Base_Agentes_Classificacao::fonte($wpdb->prefix.F3Base_Modulo_Acessos_Servidor::TABELA);$iaDetalhes=array();$iaSemanal=array();
        $botTotals=$attributionFiltered?array():((in_array($e['visao'],array('sessao','sessoes','qualidade'),true)&&($e['recorte']??'')!=='ia'?array():self::iterar($wpdb->prepare("SELECT dia,post_id,caminho,tipo_conteudo,representacao,classe_caminho,agente,agente_declarado,metodo,status,rede_estado,rede_lista,rede_data,rede_versao,SUM(contagem) requisicoes,MIN(primeiro_em) primeiro_em,MAX(ultimo_em) ultimo_em FROM {$fonteBots} WHERE dia BETWEEN %s AND %s AND classe_caminho IN ('pagina','descoberta') GROUP BY dia,post_id,caminho,tipo_conteudo,representacao,classe_caminho,agente,agente_declarado,metodo,status,rede_estado,rede_lista,rede_data,rede_versao LIMIT {$limit}",$e['de'],$e['ate']))));
        foreach($botTotals as $b){
            $b['caminho_bruto']=$b['caminho'];$b['caminho']=$cat[$b['post_id']]['caminho']??$b['caminho'];
            if(!F3Base_Agentes_Classificacao::ia($b['agente_declarado'])||!self::corresponde($b,array_diff_key($e,array_flip(array_merge(array('canal','origem_ia'),F3Base_Audiencia::DIMENSOES))))){continue;}
            $b['nome_agente']=F3Base_Agentes::nome($b['agente_declarado']);$b['finalidade']=F3Base_Modulo_Acessos_Servidor::classe_agente($b['agente_declarado']);$b['resposta']=$b['metodo']==='HEAD'?'sem_corpo_head':((int)$b['status']===304?'revalidacao_304':((int)$b['status']===200?'corpo_200':((int)$b['status']>=300&&(int)$b['status']<400?'redirecionamento':(in_array((int)$b['status'],array(403,429),true)?'bloqueio':'outra_resposta'))));
            $iaDetalhes[]=$b;
            if($b['agente']==='automacao-suspeita'){$iaSeparada['automacao_suspeita']+=(int)$b['requisicoes'];continue;}
            if($b['classe_caminho']==='descoberta'||F3Base_Editorial::base($b['caminho'])['classe']==='descoberta'){$iaSeparada['descoberta']+=(int)$b['requisicoes'];continue;}
            if(!$b['post_id']&&!isset($pathsCatalogo[F3Base_Editorial::caminho($b['caminho'])])){$iaSeparada['sem_identidade_editorial']+=(int)$b['requisicoes'];continue;}
            $pk=$pageKey($b);if(!isset($pages[$pk])){$pages[$pk]=$empty($b['post_id'],$cat[$b['post_id']]['caminho']??$b['caminho'],$b['tipo_conteudo']);}
            $p=&$pages[$pk];$p['requisicoes_ia']+=(int)$b['requisicoes'];$rede=$b['rede_estado']==='rede_compativel'?'ia_rede_compativel':'ia_nao_verificada';$p[$rede]=($p[$rede]??0)+(int)$b['requisicoes'];
            if($b['representacao']==='html'){$p['ia_html']+=(int)$b['requisicoes'];}if($b['representacao']==='markdown_core'){$p['ia_markdown']+=(int)$b['requisicoes'];}unset($p);
            $day=new DateTimeImmutable($b['dia'],wp_timezone());$week=$day->modify('monday this week')->format('Y-m-d');$key=$week.'|'.$pk.'|'.$b['agente'].'|'.$b['representacao'].'|'.$b['rede_estado'];
            $iaSemanal[$key]=$iaSemanal[$key]??array('semana'=>$week,'post_id'=>$b['post_id'],'caminho'=>$b['caminho'],'agente'=>$b['agente'],'representacao'=>$b['representacao'],'rede_estado'=>$b['rede_estado'],'requisicoes'=>0,'parcial'=>$week<$e['de']||$day->modify('sunday this week')->format('Y-m-d')>$e['ate']);$iaSemanal[$key]['requisicoes']+=(int)$b['requisicoes'];
        }
        $refs=self::iterar($wpdb->prepare("SELECT post_id,COUNT(*) n FROM %i WHERE observado_em>=%d AND observado_em<%d AND origem<>'teste' AND revisao_estado='conferida' GROUP BY post_id LIMIT {$limit}",F3Base_Editorial::tabela('referencias_ia'),$de,$ate));foreach($refs as $ref){if(isset($pages['id:'.$ref['post_id']])){$pages['id:'.$ref['post_id']]['referencias_ia']=(int)$ref['n'];}}
        unset($analysis,$events,$leads,$allNav);
        $recorte=$e['recorte']??'todos';if(in_array($recorte,array('ia','sem_observacoes'),true)){
            $pages=array_filter($pages,static fn($p)=>$recorte==='ia'?!empty($p['requisicoes_ia']):(empty($p['visualizacoes'])&&empty($p['requisicoes_ia'])));
            $coorte=array();foreach($pages as $p){$coorte+=$p['sessoes_ids'];}foreach($sessions as $k=>&$s){$s['incluida']=$s['incluida']&&isset($coorte[$k]);}unset($s);
            $daily=array();foreach($navs as $nav){if(isset($pages[$pageKey($nav)])){$d=wp_date('Y-m-d',(int)$nav['criado_em']);$daily[$d]=($daily[$d]??0)+1;}}
            foreach($agg as $g){if($g['metrica']==='visualizacoes'&&isset($pages[$pageKey($g)])&&self::elegivel($g,$e,$ann,$reason)&&self::corresponde($g,$e)){$daily[$g['dia']]=($daily[$g['dia']]??0)+(int)$g['contagem'];}}
        }
        $selected=array_filter($sessions,static fn($s)=>$s['incluida']&&$s['visualizacoes']>0);$visitors=array();$tot=array('visualizacoes'=>array_sum(array_column($pages,'visualizacoes')),'sessoes'=>$oldDays?null:count($selected),'visitantes'=>null,'sessoes_iniciadas'=>array_sum(array_column($pages,'sessoes_iniciadas')),'cliques'=>array_sum(array_column($pages,'cliques')),'envios'=>array_sum(array_column($pages,'envios')),'tempo_ativo_ms'=>array_sum(array_column($pages,'tempo_ativo_ms')));
        foreach($selected as $s){$visitors[$s['visitante']]=true;$k=$e['visao']==='origem_ia'?($s['origem_ia']?:'nao_identificada'):$s['canal'];if(!isset($channels[$k])){$channels[$k]=array('canal'=>$k,'sessoes'=>0,'visualizacoes'=>0,'tempo_ativo_ms'=>0,'cliques'=>0,'envios'=>0);}++$channels[$k]['sessoes'];foreach(array('visualizacoes','tempo_ativo_ms','cliques','envios') as $n){$channels[$k][$n]+=$s[$n];}}
        foreach($agg as $g){if(!isset($pages[$pageKey($g)])||!self::elegivel($g,$e,$ann,$reason)||!self::corresponde($g,$e)){continue;}$k=$e['visao']==='origem_ia'?($g['origem_ia']?:'nao_identificada'):$g['canal'];if(!isset($channels[$k])){$channels[$k]=array('canal'=>$k,'sessoes'=>null,'visualizacoes'=>0,'tempo_ativo_ms'=>0,'cliques'=>0,'envios'=>0,'sessoes_iniciadas'=>0);}$channels[$k]['sessoes']=null;if($g['metrica']==='visualizacoes'){$channels[$k]['visualizacoes']+=(int)$g['contagem'];}if(in_array($g['metrica'],array('cliques','envios'),true)){$channels[$k][$g['metrica']]+=(int)$g['contagem'];}if($g['metrica']==='tempo_ativo_ms'){$channels[$k]['tempo_ativo_ms']+=(float)$g['soma'];}if($g['metrica']==='sessoes_iniciadas'){$channels[$k]['sessoes_iniciadas']=($channels[$k]['sessoes_iniciadas']??0)+(int)$g['contagem'];}}
        foreach($channels as &$ch){$samples=array();$n=0;$visible=0;$elapsed=0;foreach($selected as $s){$key=$e['visao']==='origem_ia'?($s['origem_ia']?:'nao_identificada'):$s['canal'];if($key===$ch['canal']){$samples+=$s['saidas'];}}foreach($agg as $g){$key=$e['visao']==='origem_ia'?($g['origem_ia']?:'nao_identificada'):$g['canal'];if($key!==$ch['canal']||!isset($pages[$pageKey($g)])||!self::elegivel($g,$e,$ann,$reason)||!self::corresponde($g,$e)){continue;}if($g['metrica']==='saidas'){$n+=(int)$g['contagem'];$visible+=(float)$g['soma'];}elseif($g['metrica']==='duracao_saida_ms'){$elapsed+=(float)$g['soma'];}}$ch+=F3Base_Medicao_Consumo::resumo($samples,$n,$visible,$elapsed);}unset($ch);
        $tot['visitantes']=$oldDays?null:count($visitors);$tot['requisicoes_ia']=array_sum(array_column($pages,'requisicoes_ia'));
        $adsFiltered=(bool)array_filter(array_intersect_key($e,array_flip(array('plataforma','conta_id','campanha_id','grupo_id','anuncio_id'))));if($oldDays&&$adsFiltered){$tot['visualizacoes']=null;$tot['sessoes_iniciadas']=null;}
        $breakdowns=F3Base_Medicao_Consumo::quebras($selected);
        foreach($selected as &$s){$s+=F3Base_Medicao_Consumo::resumo($s['saidas']);unset($s['saidas']);}unset($s);
        $timeOn=!empty(F3Base_Options::ler('f3base_comportamento')['tempo_ativo']);
        foreach($pages as &$p){$p+=F3Base_Medicao_Consumo::resumo($p['saidas'],$p['saidas_agregadas'],$p['visivel_agregado'],$p['duracao_agregada']);$p['amostra_salto']=count($p['saltos'])+$p['amostra_salto_agregada'];$p['rolagem_salto_media_pct']=$p['amostra_salto']?(array_sum($p['saltos'])+$p['soma_salto_agregada'])/$p['amostra_salto']:null;$p['total_cliques_internos']=array_sum($p['cliques_internos']);$p['total_cliques_inertes']=array_sum($p['cliques_inertes']);unset($p['saidas'],$p['saltos']);$p['sessoes']=$oldDays?null:count($p['sessoes_ids']);$p['visitantes']=$oldDays?null:count($p['visitantes_ids']);$p['amostra_tempo']=count($p['amostras_tempo'])+$p['amostra_tempo_agregada'];$p['tempo_ativo_ms']=$p['amostra_tempo']?$p['tempo_ativo_ms']:null;$p['amostra_rolagem']=count($p['rolagem'])+$p['amostra_rolagem_agregada'];$p['rolagem_media_pct']=$p['amostra_rolagem']?(array_sum($p['rolagem'])+$p['soma_rolagem_agregada'])/$p['amostra_rolagem']:null;$p['secoes_observadas']=array_keys($p['secoes']);foreach(array('requisicoes_ia','ia_html','ia_markdown') as $m){if(!$p[$m]&&!$logComplete){$p[$m]=null;}}unset($p['sessoes_ids'],$p['visitantes_ids'],$p['amostras_tempo'],$p['rolagem'],$p['secoes']);}unset($p);
        if(($e['recorte']??'')==='sem_observacoes'){foreach($catalog as $c){$key='id:'.$c['post_id'];if(!isset($pages[$key])&&self::corresponde($c,$e)){$p=$empty($c['post_id'],$c['caminho'],$c['tipo']);foreach(array('visualizacoes','sessoes','visitantes','entradas','entradas_organicas','tempo_ativo_ms','requisicoes_ia','ia_html','ia_markdown','rolagem_media_pct') as $k){$p[$k]=null;}$p['estado']='sem_observacoes';$pages[$key]=$p;}}$pages=array_filter($pages,static fn($p)=>empty($p['visualizacoes'])&&empty($p['requisicoes_ia']));}
        if(($e['recorte']??'')==='ia'){$pages=array_filter($pages,static fn($p)=>!empty($p['requisicoes_ia']));}
        $tot['entradas_organicas']=array_sum(array_column($pages,'entradas_organicas'));$tot['conteudos_ia']=count(array_filter($pages,static fn($p)=>!empty($p['requisicoes_ia'])));$tot['amostras_tempo']=array_sum(array_column($pages,'amostra_tempo'));$tot['referencias_ia']=array_sum(array_column($pages,'referencias_ia'));$tot['sessoes_ia']=$oldDays?null:count(array_filter($selected,static fn($s)=>$s['canal']==='ia'));if(!$tot['conteudos_ia']&&!$logComplete){$tot['conteudos_ia']=null;$tot['requisicoes_ia']=null;}if(!array_sum(array_column($pages,'amostra_tempo'))){$tot['tempo_ativo_ms']=null;}
        $rows=array_values($pages);if(in_array($e['visao'],array('aquisicao','origem_ia'),true)){$rows=array_values($channels);if($e['visao']==='origem_ia'){$rows=array_values(array_filter($rows,static fn($r)=>$r['canal']!=='nao_identificada'));}}
        if($e['visao']==='sessoes'){$rows=array();foreach($selected as $s){unset($s['incluida'],$s['navegacoes']);$s['conteudos']=count($s['conteudos']);$s['inicio_local']=self::instante($s['inicio']);$s['ultimo_local']=self::instante($s['ultimo']);$rows[]=$s;}}
        if($e['visao']==='sessao'){usort($timeline,static fn($a,$b)=>$a['em']<=>$b['em']);$rows=$timeline;foreach($rows as &$r){$r['horario']=self::instante($r['em']);}unset($r);}
        if($e['visao']==='qualidade'){$rows=$technical;}
        if(!in_array($e['visao'],array('sessao','qualidade'),true)){$key=$e['ordenar'];usort($rows,static function($a,$b)use($key,$e){$x=$a[$key]??0;$y=$b[$key]??0;$cmp=is_string($x)&&is_string($y)?strnatcasecmp($x,$y):($x<=>$y);return ($e['direcao']==='asc'?$cmp:-$cmp)?:strcmp((string)($a['caminho']??$a['sessao']??$a['canal']??''),(string)($b['caminho']??$b['sessao']??$b['canal']??''));});}
        $entradas=array_values(array_filter($pages,static fn($p)=>!empty($p['entradas'])));usort($entradas,static fn($a,$b)=>$b['entradas']<=>$a['entradas']);$artigos=array_values(array_filter($pages,static fn($p)=>$p['tipo']==='artigo'));usort($artigos,static fn($a,$b)=>$b['visualizacoes']<=>$a['visualizacoes']);
        $total=count($rows);$offset=($e['pagina']-1)*$e['limite'];$out=array('ok'=>true,'regra'=>F3Base_Audiencia::REGRA.'-audiencia-1190','fonte_audiencia'=>'f3base_analise','periodo'=>array('de'=>$e['de'],'ate'=>$e['ate'],'fuso'=>wp_timezone_string()),'filtros'=>$e,'consultado_em'=>self::instante($snapshot),'totais'=>$tot,'audiencia_por_dimensao'=>$breakdowns,'exclusoes_404'=>F3Base_Audiencia_Exclusoes::relatorio($e['de'],$e['ate']),'linhas'=>array_slice($rows,$offset,$e['limite']),'total_linhas'=>$total,'proxima_pagina'=>$offset+$e['limite']<$total?$e['pagina']+1:null,'serie_diaria'=>$daily,'origens'=>array_values($channels),'excluidos'=>$excluded,'anotacoes'=>$ann,'ia_fora_conteudo'=>$iaSeparada,'ia_por_conteudo'=>array_slice($iaDetalhes,$offset,$e['limite']),'ia_total_linhas'=>count($iaDetalhes),'ia_serie_semanal'=>array_values($iaSemanal),'saude_coleta'=>F3Base_Medicao_Saude::consultar(),'principais_entradas'=>array_slice($entradas,0,10),'principais_artigos'=>array_slice($artigos,0,10),'dados_tecnicos'=>$e['visao']==='sessao'?$technical:array(),'cobertura'=>array('dimensoes_sessao'=>array('desde'=>'1.24.0','historico_sem_sinais'=>'indisponivel','agregados_sem_dimensoes_excluidos'=>!empty($oldDays)&&!empty(array_intersect_key($e,F3Base_Audiencia::dimensoes_schema()))),'saida'=>array('desde'=>'1.24.0','unidade'=>'ultima_saida_por_navegacao','visivel_nao_e_engajamento_ga4'=>true,'mediana_distribuicao'=>'somente_quando_todas_as_amostras_sao_brutas'),'anuncios_em_agregados'=>$oldDays&&$adsFiltered?'indisponivel; recorte apenas nos dados brutos':'nao_afetado','historico_sem_regra'=>$history,'dias_somente_agregados'=>array_keys($oldDays),'unicos_disponiveis'=>!$oldDays,'retencao_bruta_dias'=>F3Base_Modulo_Comportamento::retencao_eventos_dias(),'catalogo'=>F3Base_Options::ler('f3base_editorial_estado'),'logs'=>$logCoverage,'logs_completos'=>$logComplete,'tempo_ativo_habilitado'=>$timeOn,'coleta_habilitada'=>F3Base_Modulo_Comportamento::ligado()),'avisos'=>array('Sessões e pseudônimos não são pessoas verificadas. Ausência de sinal de automação não prova visita humana.','Visualizações são deduplicadas por sessão e navegação. Eventos antigos sem navegação têm pareamento limitado.','Entrada coberta exige registro do início; última página é a última observada, sem inferir abandono.','Saída observada usa a última marca cumulativa por navegação; não comprova abandono. Tempo visível inclui leitura sem gestos e difere de engajamento do GA4. Sem saída recebida, a duração permanece indisponível.','Novo ou recorrente descreve este navegador com consentimento, separando testes. Limpar o armazenamento reinicia o histórico; não identifica a pessoa.','Tempo ativo, rolagem e seções são sinais de consumo, não leitura comprovada.','Períodos com apenas agregados não fornecem visitantes nem sessões distintas; sessões iniciadas são uma medida diferente.','Recortes de conteúdo mostram eventos pareados. Sem pareamento, um contato permanece em Conversão e não recebe atribuição inventada.'));
        $out['atribuicao']=array('tipo'=>$e['tipo_atribuicao'],'regra'=>'observada: sessões sem vínculo manual ativo; atribuicao_manual: sessões com vínculo ativo. Os canais e conteúdos continuam sendo os observados.','agregados_sem_sessao_excluidos'=>$attributionFiltered);if($attributionFiltered){$out['avisos'][]='Este filtro exige sessões retidas: agregados expirados e requisições de robôs sem sessão não podem ser classificados.';}if($e['visao']==='sessao'&&!empty($e['sessao'])){$out['contatos_vinculados']=F3Base_Contatos_Sessoes::sessao($e['sessao']);}
        if($e['visao']==='sessoes'){$out['linhas']=F3Base_Sessao_Contexto::enriquecer($out['linhas']);}
        if($e['visao']==='sessao'){$items=array();foreach($selected as $s){$items[]=array_intersect_key($s,array_flip(array('sessao','classe_trafego','visitante')));}$out['sessoes']=F3Base_Sessao_Contexto::enriquecer($items);}
        return $out;
    }
}
