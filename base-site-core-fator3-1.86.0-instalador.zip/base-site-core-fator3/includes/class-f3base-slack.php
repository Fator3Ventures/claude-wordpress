<?php
/** Slack app: one durable part per subpass; unknown remote results never retry automatically. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/trait-f3base-slack-operacao.php';
final class F3Base_Slack {
    public const ESQUEMA_VERSAO=16400;
    use F3Base_Slack_Operacao;
    const SEGREDO='f3base_slack_bot_token';
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_avisos_partes';}
    public static function destino(): string {$c=F3Base_Options::ler('f3base_avisos');return hash('sha256',F3Base_Options::revisao(self::SEGREDO).'|'.($c['slack_canal_id']??''));}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE $t (
 chave char(64) NOT NULL,
 aviso char(64) NOT NULL,
 record_id char(32) NOT NULL,
 revisao char(64) NOT NULL DEFAULT '',
 sequencia int NOT NULL,
 tipo varchar(24) NOT NULL,
 principal char(64) NOT NULL,
 destino char(64) NOT NULL,
 canal varchar(64) NOT NULL,
 ts varchar(32) NOT NULL DEFAULT '',
 payload longtext NOT NULL,
 estado varchar(16) NOT NULL DEFAULT 'pendente',
 codigo varchar(64) NOT NULL DEFAULT '',
 tentativas smallint NOT NULL DEFAULT 0,
 proxima bigint NOT NULL,
 reserva_ate bigint NOT NULL DEFAULT 0,
 criada_em bigint NOT NULL,
 atualizada_em bigint NOT NULL,
 PRIMARY KEY  (chave),
 KEY aviso (aviso,sequencia),
 KEY contato (record_id,revisao),
 KEY vencidas (estado,proxima),
 KEY principal (principal)
) ".$wpdb->get_charset_collate().';');return !$wpdb->last_error&&F3Base_Slack_Manutencao::instalar();
    }
    public static function simples(string $title,array $sections,string $url,string $whatsapp=''): array {
        $blocks=array(array('type'=>'header','text'=>array('type'=>'plain_text','text'=>mb_substr($title,0,150))));$fallback=array($title);
        foreach($sections as $section=>$items){$text='*'.F3Base_Avisos::texto($section)."*\n";foreach($items as $label=>$values){$text.='*'.F3Base_Avisos::texto($label)."*\n".(($section==='Contato'&&$label==='Telefone'&&$whatsapp!=='')?'<'.F3Base_Avisos::texto($whatsapp).'|'.F3Base_Avisos::texto(implode("\n",(array)$values)).'>':(($section==='Contato'&&$label==='WhatsApp'&&count((array)$values)===1&&preg_match('~^https://wa\.me/[0-9]+(?:\?text=[A-Za-z0-9%_.\~-]*)?$~D',implode('',(array)$values)))?'<'.F3Base_Avisos::texto(implode('',(array)$values)).'|WhatsApp>':F3Base_Avisos::texto(implode("\n",(array)$values))))."\n";}$fallback[]=$section."\n".implode("\n",array_map(static fn($v)=>implode("\n",(array)$v),$items));
            while($text!==''){$part=mb_substr($text,0,2900);$text=mb_substr($text,2900);$blocks[]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>$part,'verbatim'=>true));}}
        if($url!==''){$blocks[]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>'<'.F3Base_Avisos::texto($url).'|'.F3Base_Avisos::texto(F3Base_Textos_Contato::ler('aviso_consultar')).'>','verbatim'=>true));$fallback[]=$url;}
        return array('text'=>mb_substr(implode("\n",$fallback),0,39000),'blocks'=>$blocks,'unfurl_links'=>false,'unfurl_media'=>false,'reply_broadcast'=>false,'parse'=>'none');
    }
    private static function texto_blocos(array $blocks,string $title): string {return mb_substr($title."\n".implode("\n",array_map(static fn($b)=>$b['text']['text']??'',$blocks)),0,39000);}
    public static function mensagens(array $a,string $format='thread'): array {
        if ($format === 'thread') { return F3Base_Slack_Thread::mensagens($a); }
        $sections=F3Base_Contato_Apresentacao::secoes($a);$whatsapp=implode('',(array)($sections['Contato']['WhatsApp']??''));$title=F3Base_Slack_Thread::titulo($a);
        if($format==='completo'){$result=array();$all=self::simples($title,$sections,$a['registro_url'],$whatsapp);foreach(array_chunk($all['blocks'],18) as $i=>$blocks){$result[]=array_merge($all,array('blocks'=>$blocks,'text'=>self::texto_blocos($blocks,$title.' · parte '.($i+1))));}return $result;}
        $main=array();$canonical=array('Nome'=>$a['nome']??'','E-mail'=>$a['email']??'','Telefone'=>$a['telefone']??'','Empresa'=>$a['empresa']??'');foreach($canonical as $label=>$value){if($value!==''){$main['Contato'][$label]=$value;unset($sections['Contato'][$label]);}}if(!empty($a['pagina_titulo'])){$main['Acontecimento']['Título da página']=$a['pagina_titulo'];unset($sections['Acontecimento']['Título da página']);}foreach(array('Contato'=>array('Nome','E-mail','Telefone','Empresa'),'Acontecimento'=>array('Formulário','Título da página','Página','Destino','Revisão','Aprovar')) as $section=>$labels){foreach($labels as $label){if(isset($sections[$section][$label])){$main[$section][$label]=$sections[$section][$label];unset($sections[$section][$label]);}}}
        if(!$main){$main=array('Contato'=>array('Nome'=>$a['nome']?:'Visitante','Identificador'=>$a['record_id']));}
        $result=array(self::simples($title,$main,$a['registro_url'],$whatsapp));if($format==='compacto'){return $result;}
        foreach($sections as $section=>$items){if(!$items){continue;}$m=self::simples($section,array($section=>$items),'');foreach(array_chunk($m['blocks'],18) as $i=>$blocks){$result[]=array_merge($m,array('text'=>self::texto_blocos($blocks,$section.' · parte '.($i+1)),'blocks'=>$blocks));}}return $result;
    }
    private static function parte(array $r,string $key,int $seq,string $type,string $parent,array $message,string $revision=''): bool {
        global $wpdb;$snapshot=F3Base_Avisos::abrir($r['payload']);$body=F3Base_Contato_Comunicacao::cifrar($message);
        $n=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO %i (chave,aviso,record_id,revisao,sequencia,tipo,principal,destino,canal,payload,proxima,criada_em,atualizada_em) VALUES (%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%d,%d,%d)",self::tabela(),$key,$r['chave'],$r['record_id'],$revision,$seq,$type,$parent,$r['destino'],$snapshot['canal']??'',$body,time(),time(),time()));return $n!==false;
    }
    private static function preparar(array $held): array {
        global $wpdb;$first=$held[0];$summary=$first['codigo']==='aguarda_resumo'||count($held)>1;$batch=$summary?hash('sha256',implode('|',array_column($held,'chave'))):$first['chave'];$parent=hash('sha256',$batch.'|principal');$planned=array();
        foreach($held as $row){$exists=$wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE aviso=%s LIMIT 1',self::tabela(),$row['chave']));if($wpdb->last_error){return array('ok'=>false,'codigo'=>'partes_leitura_falhou');}if($exists){continue;}
            $lead=F3Base_Leads_Repositorio::obter($row['record_id']);$prep=$lead?F3Base_Email_Entrega::preparar($lead,$row):array('ok'=>false,'codigo'=>'registro_nao_elegivel');if(empty($prep['ok'])){return $prep;}$a=$prep['apresentacao'];$meta=F3Base_Avisos::abrir($row['payload']);
            if($summary){$title=($lead['classe_trafego']==='teste'?'[TESTE] ':'').$a['site'].' · '.F3Base_Textos_Contato::ler('resumo_titulo',array('quantidade'=>count($held)));$planned[]=array($first,$parent,-1,'principal','',self::simples($title,array(),admin_url('admin.php?page=f3base-leads')));foreach(self::mensagens($a,'completo') as $i=>$message){$planned[]=array($row,hash('sha256',$row['chave'].'|resumo|'.$i),$i,'detalhe',$parent,$message);}}
            else{foreach(self::mensagens($a,$meta['formato']??'thread') as $i=>$message){$planned[]=array($row,$i===0?$parent:hash('sha256',$row['chave'].'|parte|'.$i),$i,$i===0?'principal':(($meta['formato']??'thread')==='thread'?F3Base_Slack_Thread::TIPOS[$i]:'detalhe'),$i===0?'':$parent,$message);}}
        }
        if(!$planned){return array('ok'=>true);}if($wpdb->query('START TRANSACTION')===false){return array('ok'=>false,'codigo'=>'partes_transacao_falhou');}
        foreach($planned as $args){if(!self::parte(...$args)){$wpdb->query('ROLLBACK');return array('ok'=>false,'codigo'=>'partes_nao_persistidas');}}
        if($wpdb->query('COMMIT')===false){$wpdb->query('ROLLBACK');return array('ok'=>false,'codigo'=>'partes_commit_incerto');}return array('ok'=>true);
    }
    public static function processar(array $held): array {
        global $wpdb;$r=$held[0];$exists=$wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE aviso=%s LIMIT 1',self::tabela(),$r['chave']));
        if(!$exists&&$r['codigo']!=='aguarda_resumo'){$hour=(int)floor(time()/HOUR_IN_SECONDS)*HOUR_IN_SECONDS;$used=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT lote) FROM %i WHERE destino=%s AND classe=%s AND enviada_em>=%d AND lote<>''",F3Base_Avisos::tabela(),$r['destino'],$r['classe'],$hour));if($used>=30){$formato=F3Base_Avisos::abrir($r['payload'])['formato']??'thread';
                $codigo=$formato==='thread'?'aguarda_cota_thread':'aguarda_resumo';
                F3Base_Avisos::terminar($held,'pendente',$codigo,$hour+HOUR_IN_SECONDS);return array('ok'=>true,'codigo'=>$codigo);}}
        $prep=self::preparar($held);if(empty($prep['ok'])){F3Base_Avisos::terminar($held,'pendente',$prep['codigo'],time()+60);return $prep;}
        // Release the parent queue; individual parts now own remote result evidence.
        F3Base_Avisos::terminar($held,'pendente','partes_pendentes',time()+2);
        $parts=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE aviso=%s ORDER BY sequencia,chave',self::tabela(),$r['chave']),ARRAY_A);
        $did=false;foreach($parts as $p){if($p['principal']){$parent=self::ler($p['principal']);if($parent&&$parent['estado']==='enviando'&&$parent['reserva_ate']<=time()){self::estado($parent,'incerto','resposta_nao_confirmada');$parent=self::ler($parent['chave']);}if($parent&&$parent['estado']==='pendente'&&$parent['proxima']<=time()){$result=self::enviar_parte($parent);$did=true;break;}if(!$parent||$parent['estado']!=='entregue'){if($parent&&in_array($parent['estado'],array('falhou','incerto','suspenso','cancelado','suprimido'),true)&&in_array($p['estado'],array('pendente','suspenso'),true)){self::estado($p,in_array($parent['estado'],array('cancelado','suprimido'),true)?$parent['estado']:'suspenso','principal_'.$parent['estado']);}continue;}}
            // Uma retentativa anterior mantém sua posição no thread individual.
            if (in_array($p['tipo'], F3Base_Slack_Thread::TIPOS, true) && $p['principal'] !== '' &&
                (($p['estado'] === 'pendente' && $p['proxima'] > time()) || ($p['estado'] === 'enviando' && $p['reserva_ate'] > time()))) {
                break;
            }
            if($p['estado']==='enviando'&&$p['reserva_ate']<=time()){self::estado($p,'incerto','resposta_nao_confirmada');continue;}if($p['estado']==='pendente'&&$p['proxima']<=time()){$result=self::enviar_parte($p);$did=true;break;}}
        self::sincronizar($r['chave']);return array('ok'=>true,'codigo'=>$did?($result['codigo']??'parte_processada'):'partes_aguardando');
    }
    private static function ler(string $key): ?array {global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$key),ARRAY_A);}
    private static function estado(array $p,string $state,string $code,int $next=0,array $extra=array()): bool {global $wpdb;return $wpdb->update(self::tabela(),array_merge(array('estado'=>$state,'codigo'=>$code,'proxima'=>$next,'reserva_ate'=>0,'atualizada_em'=>time()),$extra),array('chave'=>$p['chave'],'estado'=>$p['estado']))===1;}
    private static function enviar_parte(array $p): array {
        $lock=F3Base_Trava::adquirir('slack-transporte',30);if(!$lock){return array('ok'=>false,'codigo'=>'slack_transporte_ocupado');}try{return self::enviar_parte_interno($p);}finally{F3Base_Trava::liberar($lock);}
    }
    private static function enviar_parte_interno(array $p): array {
        global $wpdb;$lead=F3Base_Leads_Repositorio::obter($p['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||F3Base_Formulario_Antispam::aviso_barrado($lead)){self::estado($p,'cancelado','contato_eliminado');return array('ok'=>false,'codigo'=>'cancelado');}
        if($lead['classe_trafego']==='teste'&&F3Base_Testes::politica('slack','teste')==='suprimir'){self::estado($p,'suprimido','suprimido_teste');return array('ok'=>false,'codigo'=>'suprimido_teste');}
        $token=F3Base_Segredos::abrir(self::SEGREDO);if(!$token||!hash_equals($p['destino'],self::destino())){self::estado($p,'falhou',$token?'destino_alterado':'credencial_ausente');return array('ok'=>false,'codigo'=>'destino_alterado_ou_ausente');}
        $saved=F3Base_Contato_Comunicacao::ler($lead);$now=F3Base_Contato_Apresentacao::consentimento($lead['dados']);
        if($p['principal']!==''&&$saved&&(F3Base_Sessoes::revogacao($saved['historico']??array())||(!empty($saved['consentimento_historico']['medicao'])&&!$now['medicao'])||(!empty($saved['consentimento_historico']['publicidade'])&&!$now['publicidade']))){self::estado($p,'cancelado','consentimento_reduzido_apos_preparo');return array('ok'=>false,'codigo'=>'consentimento_reduzido_apos_preparo');}
        if ($p['tipo'] === 'links' && !F3Base_Slack_Thread::parte($p['aviso'], 'visitas') && !empty($lead['entrega']['pipedrive']['solicitado'])) {
            $crm = F3Base_Anuncio_Entrega::crm($lead);
            if ($crm) {
                $notice = F3Base_Avisos::linha($p['aviso']);
                $prep = F3Base_Contato_Comunicacao::preparar($lead, false);
                if ($notice && !empty($prep['ok'])) {
                    $msg = F3Base_Slack_Thread::mensagens($prep['apresentacao'], $crm['opp'] + ['url' => $crm['url']]);
                    if (isset($msg[3]) && self::inserir_visitas($notice, $p['principal'], $msg[3])) {
                        return ['ok' => true, 'codigo' => 'visitas_antes_dos_links'];
                    }
                }
                self::estado($p, 'pendente', 'aguarda_preparo_visitas', time() + 60);
                return ['ok' => true, 'codigo' => 'aguarda_preparo_visitas'];
            }
            $job = $wpdb->get_row($wpdb->prepare(
                'SELECT estado,proxima FROM %i WHERE record_id=%s ORDER BY atualizado_em DESC LIMIT 1',
                F3Base_Pipedrive_Fila::tabela(), $p['record_id']
            ), ARRAY_A);
            $aguardaFila = $job && in_array($job['estado'], ['pendente', 'enviando'], true);
            if (!$job) {
                $config = F3Base_Options::ler('f3base_pipedrive');
                $receipt = F3Base_Options::fotografia_bruta('f3base_pipedrive_estado')['valor'] ?? [];
                $aguardaFila = !empty($config['ativo']) && ($lead['entrega']['pipedrive']['dominio'] ?? '') === $config['dominio']
                    && ($receipt['dominio'] ?? '') === $config['dominio'] && F3Base_Integracoes::pipedrive_verificado($receipt);
            }
            if ($aguardaFila) {
                $next = max(time()+30, min(time()+300, (int)($job['proxima'] ?? 0)));
                self::estado($p, 'pendente', 'aguarda_oportunidade', $next);
                return ['ok' => true, 'codigo' => 'aguarda_oportunidade'];
            }
        }
        $backoff=(int)(get_option('f3base_slack_estado',array())['tentar_em']??0);$last=(int)$wpdb->get_var($wpdb->prepare("SELECT MAX(atualizada_em) FROM %i WHERE canal=%s AND estado='entregue'",self::tabela(),$p['canal']));
        if($backoff>time()||$last>=time()){self::estado($p,'pendente','cadencia_local',max(time()+1,$backoff));return array('ok'=>true,'codigo'=>'cadencia_local');}
        $message=F3Base_Contato_Comunicacao::abrir($p['payload']);if(!$message){self::estado($p,'falhou','payload_indisponivel');return array('ok'=>false,'codigo'=>'payload_indisponivel');}$notice = F3Base_Avisos::linha($p['aviso']);
        $config = $notice ? F3Base_Avisos::abrir($notice['payload']) : [];
        if ($p['tipo']==='acontecimento' || ($p['tipo']==='principal' && (int)$p['sequencia']===0 && ($config['formato']??'thread')!=='thread')) {
            if ($lead && F3Base_Contato_Apresentacao::consentimento($lead['dados'])['medicao']) {
                $perfil=F3Base_Perfil_Aparelho::apresentar($lead['dados']['contexto']??[]);
                $message=F3Base_Slack_Thread::com_perfil($message,$perfil);
            }
        }
        $message['channel']=$p['canal'];
        if($p['principal']){$parent=self::ler($p['principal']);if(!$parent||$parent['estado']!=='entregue'||$parent['ts']===''){return array('ok'=>false,'codigo'=>'principal_pendente');}$message['thread_ts']=$parent['ts'];}
        $notice=F3Base_Avisos::linha($p['aviso']);$reg=F3Base_Slack_Manutencao::preparar($p,$message,($notice['classe']??'')==='teste');if(empty($reg['ok'])){self::estado($p,'pendente',$reg['codigo'],time()+60);return $reg;}
        if($wpdb->update(self::tabela(),array('estado'=>'enviando','reserva_ate'=>time()+45,'tentativas'=>(int)$p['tentativas']+1,'atualizada_em'=>time()),array('chave'=>$p['chave'],'estado'=>'pendente'))!==1){return array('ok'=>false,'codigo'=>'parte_reserva_falhou');}$p['estado']='enviando';$p['tentativas']++;
        $res=self::api('chat.postMessage',$token,$message);$registered=F3Base_Slack_Manutencao::concluir($p['chave'],$res);$state='incerto';$code=$res['codigo'];$next=0;$extra=array();
        if(!empty($res['ok'])){$state='entregue';$extra=array('ts'=>$res['ts'],'canal'=>$res['canal']);}
        elseif(!empty($res['retry_after'])){$state='pendente';$next=time()+$res['retry_after']+random_int(0,3);$extra['tentativas']=max(0,$p['tentativas']-1);F3Base_Options::atualizar_estado('f3base_slack_estado',static fn($s)=>array_merge($s,array('tentar_em'=>$next,'codigo'=>$code)));}
        elseif(!empty($res['permanente'])){$state='falhou';}
        elseif(!empty($res['recusado'])){$state=$p['tentativas']>=5?'falhou':'pendente';$next=time()+min(3600,30*2**min(6,$p['tentativas']));}
        $ok=self::estado($p,$state,$code,$next,$extra);
        if($ok && $state==='entregue' && $p['tipo']==='origem'){F3Base_Anuncio_Entrega::agendar($p['record_id']);}
        return array('ok'=>$ok&&$state==='entregue','codigo'=>$ok?$code:'resultado_incerto_nao_persistido','estado'=>$state);
    }
    public static function api(string $method,string $token,array $body): array {
        if(!in_array($method,array('chat.postMessage','users.info','auth.test','conversations.history','conversations.replies','conversations.list','chat.update','chat.delete'),true)){return array('ok'=>false,'codigo'=>'metodo_recusado','permanente'=>true);}
        $rate=hash('sha256',self::destino().'|'.$method);$until=(int)(get_option('f3base_slack_estado',array())['limites'][$rate]??0);if($until>time()){return array('ok'=>false,'codigo'=>'slack_limite','retry_after'=>$until-time());}
        try{$args=array('timeout'=>8,'redirection'=>0,'sslverify'=>true,'headers'=>array('Authorization'=>'Bearer '.$token),'limit_response_size'=>1048576);$url='https://slack.com/api/'.$method;if(in_array($method,array('users.info','conversations.history','conversations.replies','conversations.list'),true)){$args['method']='GET';$url.='?'.http_build_query($body,'','&',PHP_QUERY_RFC3986);}else{$args['method']='POST';$args['headers']['Content-Type']='application/json; charset=utf-8';$args['body']=wp_json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}$r=wp_remote_request($url,$args);}catch(Throwable $e){$r=new WP_Error('transporte_incerto');}
        if(is_wp_error($r)){return array('ok'=>false,'codigo'=>'slack_resultado_incerto');}$http=(int)wp_remote_retrieve_response_code($r);$j=json_decode(wp_remote_retrieve_body($r),true);
        if($http===429){$retry=wp_remote_retrieve_header($r,'retry-after');$seconds=max(1,is_numeric($retry)?(int)$retry:(int)strtotime((string)$retry)-time());F3Base_Options::atualizar_estado('f3base_slack_estado',static function($s)use($rate,$seconds){$s['limites']=array_filter($s['limites']??array(),static fn($at)=>$at>time());$s['limites'][$rate]=time()+$seconds;return $s;});return array('ok'=>false,'codigo'=>'slack_limite','retry_after'=>$seconds);}
        if($http===200&&($j['ok']??null)===true){
            if($method==='conversations.list'){$channels=array();if(!is_array($j['channels']??null)){return array('ok'=>false,'codigo'=>'catalogo_incompleto');}foreach($j['channels'] as $c){if(preg_match('/^[CG][A-Z0-9]{8,63}$/D',(string)($c['id']??''))&&!empty($c['name'])){$channels[]=array('id'=>$c['id'],'name'=>sanitize_text_field($c['name']),'is_member'=>!empty($c['is_member']));}}return array('ok'=>true,'codigo'=>'canais_consultados','canais'=>$channels,'cursor'=>(string)($j['response_metadata']['next_cursor']??''));}
            if($method==='users.info'){if(!is_array($j['user']??null)||($j['user']['id']??'')!==($body['user']??'')){return array('ok'=>false,'codigo'=>'slack_usuario_nao_confirmado');}return array('ok'=>true,'codigo'=>'slack_usuario_confirmado','user'=>array_intersect_key($j['user'],array_flip(array('id','team_id','is_bot','is_app_user','deleted','is_restricted','is_ultra_restricted'))));}
            if($method==='auth.test'){return array('ok'=>true,'codigo'=>'slack_credencial_verificada','bot_id'=>sanitize_text_field($j['bot_id']??''),'team_id'=>sanitize_text_field($j['team_id']??''),'user_id'=>sanitize_text_field($j['user_id']??''));}
            if(in_array($method,array('conversations.history','conversations.replies'),true)){if(!is_array($j['messages']??null)||!array_is_list($j['messages'])){return array('ok'=>false,'codigo'=>'slack_historico_incompleto');}return array('ok'=>true,'codigo'=>'slack_historico_lido','messages'=>$j['messages'],'has_more'=>!empty($j['has_more']),'cursor'=>(string)($j['response_metadata']['next_cursor']??''));}
            if(is_string($j['ts']??null)&&preg_match('/^[0-9]+\.[0-9]+$/D',$j['ts'])&&is_string($j['channel']??null)&&$j['channel']===$body['channel']&&(!isset($body['ts'])||$j['ts']===$body['ts'])){return array('ok'=>true,'codigo'=>'slack_confirmou','ts'=>$j['ts'],'canal'=>$j['channel']);}return array('ok'=>false,'codigo'=>'slack_confirmacao_incompleta');
        }
        $error=is_string($j['error']??null)&&preg_match('/^[a-z_]{1,60}$/D',$j['error'])?$j['error']:'';$permanent=in_array($error,array('invalid_auth','not_authed','account_inactive','token_revoked','missing_scope','not_in_channel','channel_not_found','is_archived','no_permission'),true);
        return array('ok'=>false,'codigo'=>$error!==''?'slack_'.$error:'slack_resposta_invalida','permanente'=>$permanent,'recusado'=>($j['ok']??null)===false,'http'=>$http,'escopos_necessarios'=>array_values(array_filter(explode(',',(string)($j['needed']??'')),static fn($v)=>preg_match('/^[a-z_]+:[a-z_]+$/D',$v))));
    }
    private static function sincronizar(string $aviso): void {
        global $wpdb;$parts=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE aviso=%s',self::tabela(),$aviso),ARRAY_A);if(!$parts){return;}$parent=null;$pending=false;$broken=false;$next=PHP_INT_MAX;
        foreach($parts as $p){if($p['tipo']==='principal'){$parent=$p;}elseif($p['principal']){$parent=self::ler($p['principal']);}$pending=$pending||in_array($p['estado'],array('pendente','enviando'),true);$broken=$broken||in_array($p['estado'],array('falhou','incerto','cancelado'),true);if(in_array($p['estado'],array('pendente','enviando'),true)){$due=(int)($p['estado']==='enviando'?$p['reserva_ate']:$p['proxima']);if($p['estado']==='pendente'){$due=max($due,(int)(get_option('f3base_slack_estado',array())['tentar_em']??0));}if($p['principal']&&$parent&&in_array($parent['estado'],array('pendente','enviando'),true)){$due=max($due,(int)($parent['estado']==='enviando'?$parent['reserva_ate']:$parent['proxima']));}$next=min($next,max(time()+1,$due));}}
        if($parent&&in_array($parent['estado'],array('falhou','incerto','suprimido','cancelado','suspenso'),true)){$row=F3Base_Avisos::linha($aviso);if($row){F3Base_Avisos::terminar(array($row),$parent['estado'],$parent['codigo']);}return;}
        $state=$pending?'pendente':($broken?'falhou':'entregue');$code=$pending?'principal_entregue_detalhes_pendentes':($broken?'detalhes_incompletos':'slack_thread_completa');if($parent&&$parent['estado']!=='entregue'){$code='principal_pendente';}
        $wpdb->update(F3Base_Avisos::tabela(),array('estado'=>$state,'codigo'=>$code,'proxima'=>$pending?($next===PHP_INT_MAX?time()+60:$next):0,'enviada_em'=>$parent&&$parent['estado']==='entregue'?(int)$parent['atualizada_em']:0,'lote'=>substr($parent['chave']??'',0,36),'atualizada_em'=>time()),array('chave'=>$aviso));
        if($pending){F3Base_Avisos::agendar_proxima();}
    }
    public static function inserir_visitas(array $original,string $parent,array $message): bool {
        $key=hash('sha256',$original['chave'].'|parte|3');
        if(!self::parte($original,$key,3,'visitas',$parent,$message)){return false;}
        self::sincronizar($original['chave']);return true;
    }
    public static function retorno_pipedrive(array $lead,string $job,array $sections,string $url): array {
        if(F3Base_Slack_Manutencao::limpo($lead['record_id'])){return array('estado'=>'suprimido','codigo'=>'teste_limpo_sem_reenvio');}
        if($lead['classe_trafego']==='teste'&&F3Base_Testes::politica('slack','teste')==='suprimir'){return array('estado'=>'suprimido','codigo'=>'suprimido_teste');}
        global $wpdb;$original=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE record_id=%s ORDER BY ciclo LIMIT 1",F3Base_Avisos::tabela(),$lead['record_id']),ARRAY_A);
        if(!$original){return array('estado'=>'pendente','codigo'=>'aviso_inicial_pendente');}
        $meta=F3Base_Avisos::abrir($original['payload']);if(($meta['schema']??'')!=='f3base.slack.app.v1'){return array('estado'=>'indisponivel','codigo'=>'thread_exige_aplicativo_slack');}
        if(!hash_equals($original['destino'],self::destino())){return array('estado'=>'cancelado','codigo'=>'destino_alterado');}
        $part=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE aviso=%s ORDER BY sequencia LIMIT 1',self::tabela(),$original['chave']),ARRAY_A);
        if(!$part){return array('estado'=>'pendente','codigo'=>'thread_inicial_pendente');}
        $parent=$part['tipo']==='principal'?$part:self::ler($part['principal']);if(!$parent||$parent['estado']!=='entregue'){return array('estado'=>$parent&&in_array($parent['estado'],array('incerto','falhou','cancelado','suprimido'),true)?'indisponivel':'pendente','codigo'=>'principal_nao_confirmada');}
        if (($meta['formato']??'thread')==='thread' && F3Base_Slack_Thread::parte($original['chave'],'links')) {
            return F3Base_Slack_Thread::retorno($original,$lead,$job);
        }
        $key=hash('sha256',$job.'|pipedrive-retorno-v1');$message=self::simples('Pipedrive — contato entregue',$sections,'');
        if($url!==''){$message['blocks'][]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>'<'.F3Base_Avisos::texto($url).'|Abrir oportunidade no Pipedrive>','verbatim'=>true));}
        if(!self::parte($original,$key,2000,'complemento',$parent['chave'],$message)){return array('estado'=>'pendente','codigo'=>'parte_nao_persistida');}
        self::sincronizar($original['chave']);$part=self::ler($key);$state=$part['estado']??'pendente';
        return array('estado'=>in_array($state,array('entregue','incerto','falhou','cancelado','suprimido'),true)?$state:'enfileirado','codigo'=>$part['codigo']?:'retorno_pipedrive_enfileirado','parte'=>$key);
    }

    public static function complemento(array $lead,array $revision,array $a): array {
        if(F3Base_Slack_Manutencao::limpo($lead['record_id'])){return array('ok'=>true,'codigo'=>'teste_limpo_sem_reenvio');}
        global $wpdb;$original=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE record_id=%s ORDER BY ciclo LIMIT 1",F3Base_Avisos::tabela(),$lead['record_id']),ARRAY_A);if(!$original){return array('ok'=>false,'codigo'=>'aviso_inicial_pendente');}$meta=F3Base_Avisos::abrir($original['payload']);
        if(($meta['schema']??'')!=='f3base.slack.app.v1'){return self::complemento_webhook($original,$revision,$a);}
        $part=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE aviso=%s ORDER BY sequencia LIMIT 1',self::tabela(),$original['chave']),ARRAY_A);if(!$part){return array('ok'=>false,'codigo'=>'thread_inicial_pendente');}$parent=$part['tipo']==='principal'?$part:self::ler($part['principal']);if(!$parent||$parent['estado']!=='entregue'){return array('ok'=>false,'codigo'=>'principal_nao_confirmada');}
        $message=self::simples('Atualização do contato',F3Base_Contato_Apresentacao::secoes($a),$a['registro_url']);$key=hash('sha256',$revision['chave'].'|slack');if(!self::parte($original,$key,1000,'complemento',$parent['chave'],$message,$revision['chave'])){return array('ok'=>false,'codigo'=>'parte_nao_persistida');}
        $p=self::ler($key);if($p['estado']==='enviando'&&$p['reserva_ate']<=time()){self::estado($p,'incerto','resposta_nao_confirmada');$p=self::ler($key);}if($p['estado']==='entregue'){return array('ok'=>true,'codigo'=>'complemento_slack_entregue');}if(in_array($p['estado'],array('incerto','falhou'),true)){return array('ok'=>false,'codigo'=>$p['codigo'],'incerto'=>$p['estado']==='incerto','permanente'=>$p['estado']==='falhou');}
        if($p['estado']==='pendente'&&$p['proxima']<=time()){self::enviar_parte($p);}$p=self::ler($key);return array('ok'=>$p['estado']==='entregue','codigo'=>$p['codigo'],'incerto'=>$p['estado']==='incerto','permanente'=>$p['estado']==='falhou');
    }
    private static function complemento_webhook(array $original,array $revision,array $a): array {
        global $wpdb;$key=hash('sha256',$revision['chave'].'|slack-webhook');$p=self::ler($key);
        if(!$p){$meta=array('canal'=>'webhook');$row=$original;$row['payload']=F3Base_Avisos::cifrar($meta);if(!self::parte($row,$key,1000,'complemento','',self::simples('Atualização do contato',F3Base_Contato_Apresentacao::secoes($a),$a['registro_url']),$revision['chave'])){return array('ok'=>false,'codigo'=>'parte_nao_persistida');}$p=self::ler($key);}
        if($p['estado']==='entregue'){return array('ok'=>true);}if($p['estado']==='pendente'&&$p['proxima']>time()){return array('ok'=>false,'codigo'=>'slack_limite','retry_after'=>$p['proxima']-time());}if($p['estado']!=='pendente'){return array('ok'=>false,'codigo'=>'complemento_resultado_incerto','incerto'=>true);}
        if(!hash_equals($original['destino'],F3Base_Options::revisao(F3Base_Avisos::SEGREDO))){return array('ok'=>false,'codigo'=>'destino_alterado','permanente'=>true);}$url=F3Base_Segredos::abrir(F3Base_Avisos::SEGREDO);if(!F3Base_Avisos::url_valida($url)){return array('ok'=>false,'codigo'=>'webhook_ausente','permanente'=>true);}
        if(!self::estado($p,'enviando','enviando')){return array('ok'=>false,'codigo'=>'parte_reserva_falhou');}$res=wp_safe_remote_post($url,array('timeout'=>8,'redirection'=>0,'headers'=>array('Content-Type'=>'application/json'),'body'=>wp_json_encode(F3Base_Contato_Comunicacao::abrir($p['payload']))));$p['estado']='enviando';if(!is_wp_error($res)&&wp_remote_retrieve_response_code($res)===429){$delay=max(1,(int)wp_remote_retrieve_header($res,'retry-after'));self::estado($p,'pendente','slack_limite',time()+$delay);return array('ok'=>false,'codigo'=>'slack_limite','retry_after'=>$delay);}$ok=!is_wp_error($res)&&wp_remote_retrieve_response_code($res)===200&&trim(wp_remote_retrieve_body($res))==='ok';$p['estado']='enviando';self::estado($p,$ok?'entregue':'incerto',$ok?'slack_confirmou':'slack_resultado_incerto');return array('ok'=>$ok,'incerto'=>!$ok,'codigo'=>$ok?'slack_confirmou':'slack_resultado_incerto');
    }
    public static function iniciar(): void {self::iniciar_operacao();F3Base_Slack_Manutencao::iniciar();
        add_action('f3base_zelador',['F3Base_Anuncio_Entrega','migrar'],126);
        add_action('f3base_anuncio_migrar',['F3Base_Anuncio_Entrega','migrar']);
        add_action('f3base_anuncio_entrega',['F3Base_Anuncio_Entrega','executar']);
        add_action('admin_post_f3base_anuncio_consultar',['F3Base_Anuncio_Entrega','consultar_ficha']);
        add_action('wp_ajax_f3base_slack_canais',static function(){check_ajax_referer('f3base-slack-canais');wp_send_json(self::canais(array('revisao'=>sanitize_text_field($_POST['revisao']??''),'cursor'=>sanitize_text_field($_POST['cursor']??''))));});
        add_action('admin_post_f3base_slack_verificar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-slack-verificar');$r=self::verificar(array('simular'=>false,'postar_teste'=>!empty($_POST['postar_teste']),'revisao'=>sanitize_text_field($_POST['revisao']??'')));set_transient('f3base_slack_teste_'.get_current_user_id(),$r,300);wp_safe_redirect(admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=avisos'));exit;});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('slack-verificar','Verifica credencial; postar_teste envia mensagem marcada somente quando solicitado',array(__CLASS__,'verificar'),array('simular'=>array('type'=>'boolean','default'=>true),'postar_teste'=>array('type'=>'boolean','default'=>false),'revisao'=>array('type'=>'string')),array(),false);});
    }
    public static function verificar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$c=F3Base_Options::ler('f3base_avisos');$rev=self::destino();$post=!empty($e['postar_teste']);
        if($e['simular']??true){return array('ok'=>true,'simulado'=>true,'revisao'=>$rev,'metodo'=>$post?'chat.postMessage':'auth.test','canal'=>$c['slack_canal_id']??'');}
        if(!hash_equals($rev,(string)($e['revisao']??''))){return array('ok'=>false,'codigo'=>'conflito');}if(!F3Base_Leads_Repositorio::quota('slack-teste|'.floor(time()/60),2,time()+120)){return array('ok'=>false,'codigo'=>'limite_de_testes');}
        $token=F3Base_Segredos::abrir(self::SEGREDO);if(!$token){return array('ok'=>false,'codigo'=>'credencial_ausente');}if($post&&!preg_match('/^[CG][A-Z0-9]{8,63}$/D',$c['slack_canal_id']??'')){return array('ok'=>false,'codigo'=>'canal_invalido');}
        return $post?F3Base_Slack_Manutencao::teste():F3Base_Slack_Manutencao::identidade();
    }
    public static function canais(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $revision=F3Base_Options::revisao(self::SEGREDO);if(!hash_equals($revision,(string)($e['revisao']??''))){return array('ok'=>false,'codigo'=>'credencial_alterada');}
        $token=F3Base_Segredos::abrir(self::SEGREDO);if(!$token){return array('ok'=>false,'codigo'=>'credencial_ausente');}
        $cursor=(string)($e['cursor']??'');if(strlen($cursor)>2000){return array('ok'=>false,'codigo'=>'cursor_invalido');}
        $r=self::api('conversations.list',$token,array('types'=>'public_channel,private_channel','exclude_archived'=>'true','limit'=>200,'cursor'=>$cursor));
        if(!empty($r['ok'])){F3Base_Options::atualizar_estado('f3base_slack_estado',static function($s)use($r,$revision,$cursor){$old=$cursor!==''&&($s['canais_revisao']??'')===$revision?($s['canais']??array()):array();foreach($r['canais'] as $c){$old[$c['id']]=$c;}$s['canais']=array_slice($old,0,5000,true);$s['canais_revisao']=$revision;$s['canais_em']=time();return $s;});}return $r;
    }
    public static function campos_tela(array $c): void {
        foreach(array('slack_transporte'=>array('webhook'=>'Incoming Webhook','app'=>'Aplicativo com bot'),'slack_formato'=>array('completo'=>'Completo','compacto'=>'Compacto: identificação e link','thread'=>'Principal e respostas na thread')) as $name=>$options){echo '<p><label>'.esc_html($name==='slack_transporte'?'Transporte Slack':'Formato no Slack').' <select name="'.esc_attr($name).'">';foreach($options as $v=>$label){echo '<option value="'.esc_attr($v).'" '.selected($c[$name]??'', $v,false).'>'.esc_html($label).'</option>';}echo '</select></label></p>';}
        echo '<script>(function(){var t=document.querySelector("select[name=slack_transporte]"),f=document.querySelector("select[name=slack_formato]");if(t&&f){t.addEventListener("change",function(){if(t.value==="app"){f.value="thread";}else if(f.value==="thread"){f.value="completo";}});}})();</script>';
        $state=get_option('f3base_slack_estado',array());$channels=($state['canais_revisao']??'')===F3Base_Options::revisao(self::SEGREDO)?($state['canais']??array()):array();$selected=(string)($c['slack_canal_id']??'');
        echo '<div data-slack-app><p><label for="f3base-slack-canal">Canal do Slack</label> <select id="f3base-slack-canal" name="slack_canal_id"><option value="">Selecione um canal</option>';if($selected!==''&&!isset($channels[$selected])){echo '<option selected value="'.esc_attr($selected).'">Canal salvo — atualize a lista para ver o nome</option>';}foreach($channels as $ch){echo '<option value="'.esc_attr($ch['id']).'" '.selected($selected,$ch['id'],false).'>#'.esc_html($ch['name']).'</option>';}echo '</select> <button type="button" class="button" id="f3base-slack-listar" data-nonce="'.esc_attr(wp_create_nonce('f3base-slack-canais')).'" data-revision="'.esc_attr(F3Base_Options::revisao(self::SEGREDO)).'">Atualizar canais</button><span id="f3base-slack-canais-estado" role="status"></span></p><p>A lista usa as permissões de leitura de canais públicos e privados do aplicativo. Convide o bot ao canal antes do envio.</p><input type="hidden" name="slack_bot_revisao" value="'.esc_attr(F3Base_Options::revisao(self::SEGREDO)).'">';F3Base_Config_UI::segredo(self::SEGREDO,'slack_bot','apagar_slack_bot');echo '</div>';
    }
    public static function teste_tela(): void {$r=get_transient('f3base_slack_teste_'.get_current_user_id());if($r){echo '<p role="status">'.esc_html(F3Base_Config_UI::rotulo($r['codigo']??'verificacao_indisponivel')).'</p>';delete_transient('f3base_slack_teste_'.get_current_user_id());}echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_slack_verificar"><input type="hidden" name="revisao" value="'.esc_attr(self::destino()).'">';wp_nonce_field('f3base-slack-verificar');echo '<button class="button">Verificar credencial</button> <button class="button" name="postar_teste" value="1">Enviar mensagem marcada de teste</button><p>O envio de teste cria uma mensagem real no canal selecionado.</p></form>';}
    public static function consultar(string $aviso): array {global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT chave,record_id,revisao,sequencia,tipo,principal,canal,ts,estado,codigo,tentativas,proxima,atualizada_em FROM %i WHERE aviso=%s ORDER BY sequencia',self::tabela(),$aviso),ARRAY_A)?:array();foreach($rows as &$p){$p['revisao_operacao']=self::revisao_parte($p);}unset($p);return $rows;}
    public static function eliminar(string $id): void {F3Base_Anuncio_Entrega::eliminar($id);F3Base_Slack_Manutencao::eliminar($id);global $wpdb;$wpdb->query($wpdb->prepare("UPDATE %i SET estado='cancelado',payload='',codigo='contato_eliminado',atualizada_em=%d WHERE record_id=%s",self::tabela(),time(),$id));}
}
