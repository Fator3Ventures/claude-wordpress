# Fator3 Site Core 1.84.0

Instalação limpa ou atualização da 1.83.0. WordPress ≥ 7.1.4 e PHP ≥ 8.3 (64 bits). Contrato de configuração 8.40.0.

## 398 — Cliques em links

Com a medição autorizada, um clique primário ou do botão central em um elemento `a[href]` produz `f3base_clique_link` na coleta própria, inclusive dentro do diálogo de contato. A captura ocorre antes da navegação. Há um teto de 100 cliques por documento carregado. A fila local comporta 100 eventos pendentes de todos os tipos, com validade de 24 horas e reenvio por identificador. Repetir um evento confirmado preserva uma única linha. As regras de consentimento, tráfego e retenção da medição continuam aplicáveis.

| Campo | Conteúdo |
|---|---|
| tipo | interno ou externo para HTTP(S) conforme o host, e-mail para mailto e telefone para tel. Outros esquemas recebem externo e conservam apenas o esquema. |
| destino | Esquema, host, porta e caminho. A coleta descarta credenciais, query e fragmento. Links de arquivo protegido ocultam o segmento depois de arquivo/download. Limite de 2.048 caracteres. |
| secao e alvo | Seção marcada por f3base-secao- (ou prefixo configurado). Sem seção, fora. O alvo junta seção e identificador com ~. Exemplo: cabecalho~cabecalho:controle:1. Um alvo declarado usa o identificador do rastreador de cliques inertes. |
| classe e texto | Primeira classe f3base-clique-* no link ou ancestral e até 80 caracteres de texto visível. Ícone sem texto pode produzir texto vazio. |
| nova_aba | target _blank, botão central ou modificador Ctrl/Command no clique. |

Leia `f3base/eventos-ler` com `{"metrica":"f3base_clique_link","dias":7}`. Para contar, passe `{"agrupar_por":"destino","dias":7}`. Também são aceitos secao e alvo. Janela, segmento, caminho, sessão, limite e cursor restringem a mesma fotografia. Em `f3base/medicao-editorial`, a página de origem mostra em `seguintes` cada destino externo clicado na navegação observada. O clique comprova a saída solicitada. O carregamento do outro site requer evidência do destino.

As métricas legadas f3base_link_externo e f3base_clique_interno permanecem disponíveis. A coleta analítica detalhada clique_interno anterior pode continuar chegando da fila de uma página antiga. O histórico preserva o formato que foi coletado. Somar os eventos antigos ao novo pode duplicar um clique. O Core não encaminha a nova métrica como conversão publicitária.

## 399 — Separação de clique e conversão

O clique em WhatsApp ou outro CTA recebe o código `clique_sem_formulario` e permanece no histórico de contatos. A regra antecede a reserva de aquisição, a fila Meta e os disparos de navegador. As rotas de reprocessamento verificam novamente o registro. Slack segue o canal e a regra de aviso por clique configurados. Um envio aceito de formulário continua elegível conforme o consentimento, a identidade, a configuração dos destinos e a deduplicação.

A opção `f3base_converter_contato_sem_identificador` trata somente formulário com telefone digitado em formato livre, sem normalização e sem e-mail válido. A 1.84.0 traz o padrão desligado. Uma escolha explícita permanece válida para esse tipo de formulário. Mesmo ligada, nenhum clique de CTA vira lead no GA4, Google Ads, Meta, LinkedIn ou Clarity. A atualização atua sobre novos disparos e reprocessamentos. Eventos anteriormente aceitos por fornecedores permanecem nos relatórios históricos.
