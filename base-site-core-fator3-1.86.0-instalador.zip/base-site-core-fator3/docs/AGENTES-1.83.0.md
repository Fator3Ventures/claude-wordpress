# Operar o Core 1.83.0

Consulte RELEASE-1.83.0.md para as regras de faixa, mapeamento de CRM, consentimento e retenção. Para um contato, leia f3base/leads-registros-ler com record_id e confira registro.dados.contexto.perfil_aparelho. Nas visões de audiência, consulte audiencia_por_dimensao e compare o tamanho das amostras por modelo. No Site-Teste use contexto de teste e confira o descarte das amostras.

Após atualizar o WP Super Cache, confira cache.requisitos, o backup datado de wp-cache-config.php e a resposta anônima com parâmetros de campanha. A marcação do clique no navegador continua vinculada à decisão de publicidade.
