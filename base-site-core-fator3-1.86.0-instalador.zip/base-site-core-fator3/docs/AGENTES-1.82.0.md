# Operar Fator3 Site Core 1.82.0

Consulte f3base/como-usar e f3base/resumo-operacional-ler para verificar avisos do catálogo. Na ficha do contato ou via f3base/leads-registros-ler com record_id, confira registro.anuncio_entrega. Verifique o campo trabalho e os campos do anúncio. Na confirmação da imagem, slack_canal e slack_thread identificam o destino e slack_share_ts identifica a resposta. Confira as permissões do bot e a participação no canal quando a conferência ficar pendente. Veja docs/RELEASE-1.82.0.md e docs/REFERENCIA-ABILITIES.md.
