# Operar o Core 1.85.1

Execute f3base/email-contato-simular com {"valor":"qa@gmial.com"} para verificar o domínio da entrada. Para experimentar uma lista, acrescente {"correcoes":["gimal.com=gmail.com"]} aos argumentos. A simulação exige a permissão administrativa manage_options. Para medir os envios aceitos, leia f3base/relatorios-integrados-ler com visao=emails_normalizacao, de, ate e segmento e consulte linhas. Cada linha informa classe e contatos. Consulte RELEASE-1.85.1.md para as regras de telefone, correção, DNS e tratamento das classes.

Após a distribuição, confira o valor efetivo de f3base_converter_contato_sem_identificador em cada site da frota. Grave false com a revisão vigente. Releia a configuração e registre o valor e o recibo por site.

Na 1.85.1, o contato com e-mail inválido pode ser registrado, mas o acesso ao material privado exige e-mail utilizável. O Core informa a condição na resposta do formulário. A concessão é recusada antes da consulta ao arquivo e da criação de qualquer chave de download.
