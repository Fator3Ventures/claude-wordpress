# Operar o Core 1.84.0

Em f3base/eventos-ler, filtre metrica=f3base_clique_link e a sessão. Use agrupar_por=destino, secao ou alvo para contar. Na homologação, use segmento=somente_testes. Confira destino, tipo, secao, alvo, classe, texto e nova_aba em cada linha individual. Compare as saídas HTTP externas com seguintes na página de origem em f3base/medicao-editorial.

Para um CTA, confira o registro e a intenção de aviso por record_id. Confira que não há Lead em f3base/meta-entregas-ler nem item correspondente em f3base/conversoes-fila-ler. Para o controle positivo, envie o formulário com um celular válido e confira cada destino habilitado e a política de teste. As notas RELEASE-1.84.0.md detalham o teto e a opção de telefone livre.
