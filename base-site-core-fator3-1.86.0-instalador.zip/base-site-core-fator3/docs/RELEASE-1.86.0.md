# Fator3 Site Core 1.86.0

Instalação limpa ou atualização direta da 1.85.1. WordPress 7.1.4 e PHP 8.3 de 64 bits. Contrato de configuração 8.41.0.

## Pedidos core 402 e 403 · Contatos

A lista mostra o total filtrado e páginas de até 50 registros. As abas selecionam contatos, testes ou itens na lixeira. A busca aceita nome ou e-mail. Os filtros de campanha ficam abertos quando estão em uso. Os selos removem um filtro por vez. O detalhe conserva o estado de cada canal e a exportação conserva o recorte. Em telas pequenas, a tabela rola dentro da página.

O nome de uma campanha arquivada exige a mesma captura, conta, revisão e concessão do leitor Google. O Core lê JSON armazenado e estruturas já decodificadas. Falhas em dados históricos têm indicação na linha. A leitura dos relatórios normaliza os tipos esperados sem regravar contatos.

## Pedido core 404 · Painel

Configurações, operação, técnica, contatos, formulários, conteúdo privado, relatórios e recuperação usam título, orientação e versão. As abas quebram em linhas. A busca sobre tabelas já carregadas filtra as linhas daquela tabela. Os filtros do relatório consultam o período completo.

## Pedidos core 405 e 406 · Operação

Uma coleta GA4 automática completa ou a constatação de que não há dia elegível cobre continuações sem argumentos anteriores ao seu início. A gravação usa o escopo do gancho, a ocorrência, a cobertura e a reserva. A próxima continuação programada é preservada. Tentativas parciais, erros e consultas manuais não comprovam conclusão da fila automática.

Quando a política de histórico ou a integração Pipedrive está desativada, a conferência de e-mail retorna `nao_aplicavel`. O zelador remove o evento e encerra as esperas sem reserva ativa. A configuração ativa volta a agendar a conferência. Filas de mensagens e confirmações individuais são preservadas.
