# Fator3 Site Core 1.83.0

Base de atualização 1.82.0. WordPress 7.1.4 ou superior e PHP 8.3 de 64 bits ou superior. Contrato administrativo 8.39.0.

## Medição do aparelho e contato (396)

Com medição permitida, a análise consulta o modelo e a versão principal oferecidos pelo navegador, a memória aproximada em GB, os processadores lógicos, a tela em pixels CSS com DPR e a classe de conexão. A ausência de uma API deixa o campo indisponível. O HTML pode vir integralmente do cache. O navegador envia os sinais somente à coleta própria e à captura própria de contato. Nenhum destes campos é parâmetro de conversão de publicidade.

Em **Configurações → Medição e anúncios → Conteúdo, audiência e IA**, edite **Faixa por modelo de aparelho**. Use uma linha por correspondência exata, por exemplo `SM-A065M=entrada`. O catálogo inicial reconhece os quatro nomes do pedido do CTO Office. O código informado pelo navegador pode diferir do nome comercial exibido no GA4. Registre o identificador observado antes de segmentar a campanha.

Com modelo presente, a faixa depende de correspondência no catálogo. Sem modelo e com os dois sinais de capacidade, até 2 GB ou até 4 núcleos indicam entrada. Pelo menos 8 GB e 8 núcleos indicam topo. As demais combinações indicam intermediário. Sem base suficiente a faixa é desconhecida. No iPhone o modelo fica vazio. Com tela disponível, lado maior de até 667 px indica entrada, DPR a partir de 3 e lado maior a partir de 844 px indicam topo, e as demais telas indicam intermediário. A origem da faixa distingue catálogo, estimativa de capacidade, estimativa de tela do iPhone e ausência de base. Faixa é uma classificação operacional e depende dos limites adotados.

A primeira observação confirmada fixa os valores para a classe, a sessão e o visitante. A tabela privada `f3base_aparelhos` usa o mesmo corte de retenção de `f3base_analise`. O registro guarda a referência em `dados.contexto`. A leitura privada materializa `perfil_aparelho` enquanto a observação está retida e a medição do contato está permitida. A cópia interna congelada das comunicações guarda a referência. A nota do Pipedrive, o aviso no Slack e os campos externos já entregues seguem a retenção do destino.

Em Medição, filtre pelo valor observado. As abilities `f3base/medicao-editorial` e `f3base/relatorios-integrados-ler` aceitam modelo, versao_sistema, memoria_gb, nucleos, tela, rede e faixa_aparelho. A visão qualidade inclui o modelo no resultado dos vitais. Para cruzar com o Perfil no CRM, associe `modelo_aparelho` ou `faixa_aparelho` à chave de um campo de texto em `f3base_pipedrive.mapa_campos` (lead) ou `mapa_pessoa` (pessoa). A pessoa já cadastrada recebe o valor apenas em campo vazio.

## Cache e atribuição (397)

`F3Base_Atribuicao::CLIQUES`, `CAMPANHAS` e `SOMENTE_CACHE` definem os papéis. O cache consome a união de 47 nomes. A captura lê campanhas e cliques, e o navegador recebe as projeções do mesmo catálogo pelo WordPress. Os identificadores de clique exigem publicidade permitida. Na captura reduzida, o Core também retira gad_campaignid. igshid e _gl servem só ao cache. ref é funcional. Consulte `cache.requisitos.configuracao_requerida.wpsc_tracking_parameters` ao implantar. Preserve parâmetros adicionais aprovados do site e as exclusões de URLs. Com a lista antiga o diagnóstico informa nomes faltantes.
