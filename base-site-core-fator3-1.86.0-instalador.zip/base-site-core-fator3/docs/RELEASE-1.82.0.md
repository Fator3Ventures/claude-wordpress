# Fator3 Site Core 1.82.0

Versão de 13/11/2026. Instalação nova ou atualização direta da 1.81.1. WordPress 7.1.4+, PHP 8.3+ de 64 bits. O contrato de configuração permanece em 8.38.0.

## Entrega do anúncio (pedidos 392 e 394)

O Core grava o recibo em anuncio_entrega, na tabela de contatos. A migração recolhe até 50 options antigas por passagem, preserva os identificadores do CRM e reavalia os arquivos antigos do Slack. Para consultas, passe record_id a f3base/leads-registros-ler. O campo registro.anuncio_entrega informa o estado do trabalho e os campos do anúncio enquanto a origem continua elegível. A lista de contatos omite o recibo. A fila termina ao concluir ou após 30 dias. Os identificadores confirmados acompanham a retenção do contato.

O primeiro aviso pesquisa o nome da campanha Google na conta correspondente. Usa o nome capturado, a campanha de um clique arquivado e vinculado à captura, o mapa f3base_campanhas_nomes e o acervo local de campanhas do dia da captura e da véspera. O envio posterior usa uma resposta na conversa principal. Quando a imagem está disponível, os campos acompanham o próprio compartilhamento. Uma resposta textual anterior pode ser atualizada se o provedor completar os dados depois.

O bot requer chat:write, files:write e files:read. A leitura de histórico do canal também é necessária quando o Slack omite thread_ts do objeto shares. O Core confere canal, mensagem e arquivo antes de registrar a imagem como confirmada. Falha de leitura ou conclusão incerta mantém o arquivo pendente. O identificador reservado permite repetir a consulta sem enviar a imagem de novo.

## Primeira linha do aviso (pedido 395, substitui o 393)

A mensagem principal usa host, tipo de entrada e origem comercial. Exemplos: “www.ctooffice.com.br · Formulário Meta · Meta Ads”, “www.ctooffice.com.br · Clique para WhatsApp · Google Ads”, “exemplo.com.br · Formulário Site · Orgânico” e “www.fator3.com.br · Recebido por e-mail”. O prefixo [TESTE] continua nas entradas de teste. Formulários LinkedIn e Google identificam a plataforma na entrada. Para outra UTM com campanha, o cabeçalho usa a fonte. Uma origem resolvida depois corrige o título no ts original, mantendo os campos da mensagem já publicada.
