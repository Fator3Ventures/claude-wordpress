# Operar o Core 1.86.0

Leia RELEASE-1.86.0.md por f3base/documentacao-ler. Em Contatos, use a busca e os filtros de campanha. O selo de aviso abre caminho para conferir o detalhe de cada contato. Uma falha na apresentação pode ser verificada pelo ID no painel. A lista e os relatórios são leituras.

Para verificar a operação, consulte f3base/saude-ler e o estado das esperas. Observe a tarefa ga4 após uma coleta completa. Com Pipedrive inativo, confira a ausência de espera de email_historico e do gancho f3base_email_historico_conferir após o zelador. A habilitação de Pipedrive é uma decisão administrativa. O aceite de frota para GA4 exige dois ciclos de cron_24h nos seis sites do pedido 405.
