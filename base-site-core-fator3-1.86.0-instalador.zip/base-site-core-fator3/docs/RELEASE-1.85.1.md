# Fator3 Site Core 1.85.1

Instalação limpa ou atualização da 1.85.0. Requer WordPress 7.1.4 e PHP 8.3 de 64 bits. Contrato de configuração 8.41.0.

## Telefone de contato (pedido 400)

Com país BR, use DDD e número de oito dígitos iniciado em 2–9, ou nove dígitos iniciado em 9. Pode usar +55, 55 seguido do número completo ou o prefixo nacional 0. Com dez ou onze dígitos, um 55 inicial é DDD. Outros números internacionais exigem + e seguem a validação sintática E.164. O Core grava o diagnóstico na captura. O telefone livre preserva a entrada no registro mesmo quando a validação falha. O formulário estrito explica a recusa. Pipedrive, link de WhatsApp e Meta usam o telefone normalizado. Um número fixo válido continua sendo fixo para a seleção de canal de atendimento.

## E-mail de contato (pedido 401)

No painel, abra Configurações → Contato → Correções de domínios de e-mail. Preencha um par de domínios por linha, como gmial.com=gmail.com. Para experimentar inclusive uma lista ainda não salva, execute a ability administrativa f3base/email-contato-simular com valor e, opcionalmente, correcoes. A simulação retorna digitado, corrigido, classe e motivo, sem criar um lead.

A limpeza remove espaços, passa a minúsculas, troca vírgula no domínio e remove um ponto final. As classes são valido, corrigido, nao_verificado e invalido. O campo email contém a identidade utilizável. Para erro de escrita ou domínio sem entrega fica vazio. O registro privado preserva os campos digitado e corrigido em email_normalizacao. A correção de domínio aparece no Slack e na nota de CRM. O canal automático usa o endereço elegível da captura.

O Core consulta o domínio via DNS sobre HTTPS no resolvedor Cloudflare. Consulta MX e, na ausência de MX, A. MX nulo indica recusa explícita. Uma resposta DNS definitiva para o original e outra positiva para o destino são necessárias para trocar .con, .cmo, .com.bt ou .com.brr. O sufixo .co é preservado. A lista de erros explícitos de provedor aplica-se primeiro. Um erro ou tempo excedido no domínio em validação resulta em nao_verificado e permite o contato. A consulta tem orçamento compartilhado de dois segundos. A consulta transmite apenas o domínio. O cache local guarda resultados definitivos por hash, por até uma hora. A validação trata o domínio e a escrita. A entrega a uma caixa individual é confirmada pelo transporte.

A visão emails_normalizacao em f3base/relatorios-integrados-ler conta as quatro classes de envios aceitos no recorte. Os registros sem fotografia ficam fora da contagem. O Core conserva os registros anteriores. A opção f3base_converter_contato_sem_identificador controla a conversão de formulários com e-mail inválido e sem telefone válido. O padrão é false. A operação da frota aplica esse valor explícito após a distribuição. Sem canal utilizável, o CRM usa a atividade Conferir contato.

Na 1.85.1, o contato com e-mail inválido pode ser registrado, mas o acesso ao material privado exige e-mail utilizável. O Core informa a condição na resposta do formulário. A concessão é recusada antes da consulta ao arquivo e da criação de qualquer chave de download.
