/** F3 Base Core 1.19 — captura de CTA com destino explícito, consentimento e confirmação. */
(function (window, document) {
	'use strict';

	var dados = window.f3baseLeadsDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CAMPOS = ['nome', 'email', 'telefone', 'mensagem'];
	var LIMITES = dados.limites && typeof dados.limites === 'object' ? dados.limites : {};
	var ATRIBUICAO = dados.atribuicao && typeof dados.atribuicao === 'object' ? dados.atribuicao : {};
	var CHAVE_ATRIBUICAO = String(ATRIBUICAO.chave || 'f3base_atribuicao');
	var ATRIBUTO_NUMERO = String(dados.atributoNumero || 'data-f3base-numero');
	var GOOGLE_ADS = /* f3module:leads_ads */true;
	var META_PIXEL = /* f3module:leads_pixel */true;
	var MEDICAO = dados.medicao && typeof dados.medicao === 'object' ? dados.medicao : {};
	var ADS = MEDICAO.ads && typeof MEDICAO.ads === 'object' ? MEDICAO.ads : {};
	var CONTEUDO = MEDICAO.conteudo && typeof MEDICAO.conteudo === 'object' ? MEDICAO.conteudo : {};
	var META = MEDICAO.meta && typeof MEDICAO.meta === 'object' ? MEDICAO.meta : {};
	var LINKEDIN = MEDICAO.linkedin && typeof MEDICAO.linkedin === 'object' ? MEDICAO.linkedin : {};
	/*
	 * A JANELA DA CORRELAÇÃO CHEGA DO SERVIDOR, e o número não é escrito aqui.
	 * Ele valia cinco segundos, e cinco segundos é menos do que uma pessoa leva
	 * para clicar no botão, ler o que abriu, voltar e clicar de novo: dois
	 * cliques com seis segundos de intervalo viravam DOIS leads, duas reservas
	 * de deduplicação e duas conversões em todos os fornecedores. A janela
	 * declarada é de um minuto, e quem a muda é o filtro do servidor — número
	 * escrito no cliente é número que ninguém revisa junto com o do outro lado.
	 */
	var JANELA_CORRELACAO = parseInt(dados.janelaCorrelacao, 10) > 0 ? parseInt(dados.janelaCorrelacao, 10) : 60;

	var registrados = {};
	var iniciados = {};

	window.dataLayer = window.dataLayer || [];

	function correlationId() {
		var bytes = new Uint8Array(8);
		var saida = '';
		var i;

		if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
			window.crypto.getRandomValues(bytes);
		} else {
			for (i = 0; i < bytes.length; i++) {
				bytes[i] = Math.floor(Math.random() * 256);
			}
		}

		for (i = 0; i < bytes.length; i++) {
			saida += ('0' + bytes[i].toString(16)).slice(-2);
		}

		return saida;
	}

	/**
	 * Comprimento em CARACTERES, e não em unidades UTF-16.
	 *
	 * `'coração'.length` é 7 e `Array.from('coração').length` também — mas um
	 * emoji conta 2 pela primeira medida e 1 pela segunda. A unidade tem de ser
	 * a MESMA dos dois lados: o servidor mede caracteres, publica o limite em
	 * caracteres por `limites_publicos()` e recusa por caractere.
	 */
	function caracteres(texto) {
		return Array.from(texto);
	}

	/**
	 * Corta pelo limite publicado, na unidade publicada.
	 *
	 * O corte por `slice()` fatia unidades UTF-16: um limite alcançado no meio
	 * de um par substituto devolveria metade de um caractere, e o servidor
	 * receberia texto que ninguém escreveu.
	 */
	function limitar(nome, valor) {
		var limite = parseInt(LIMITES[nome], 10);
		var texto = String(valor == null ? '' : valor);
		var letras;

		if (limite > 0) {
			letras = caracteres(texto);

			if (letras.length > limite) {
				return letras.slice(0, limite).join('');
			}
		}

		return texto;
	}

	/** Somente links com marca de número podem ter o destino montado pelo Core. */
	function temDestinoProprio(gatilho) {
		// Apenas um destino explicitamente marcado pode ser atualizado pelo Core.
		// Preencher a opção global nunca promove links de menu ou conteúdo.
		return !gatilho.getAttribute(ATRIBUTO_NUMERO);
	}

	/**
	 * O que a URL desta visita carrega: campanha e IDENTIFICADOR DE CLIQUE.
	 *
	 * Os cinco UTMs dizem de onde a visita diz que veio; os identificadores de
	 * clique são o que cada plataforma reconhece como sendo o próprio clique
	 * pago, e sem eles o lead chega sem a campanha que o comprou — mesmo TTL,
	 * mesmo primeiro toque, mesma persistência.
	 */
	function atribuicaoDaUrl() {
		var busca = new URLSearchParams(window.location.search);
		var mapa = {
			fonte: 'utm_source',
			meio: 'utm_medium',
			campanha: 'utm_campaign',
			termo: 'utm_term',
			conteudo: 'utm_content',
			gclid: 'gclid',
			gbraid: 'gbraid',
			wbraid: 'wbraid',
			msclkid: 'msclkid',
			fbclid: 'fbclid',
			li_fat_id: 'li_fat_id'
		};
		var saida = {};
		var chave;
		var valor;

		for (chave in mapa) {
			if (Object.prototype.hasOwnProperty.call(mapa, chave)) {
				valor = busca.get(mapa[chave]);
				if (valor) {
					saida[chave] = String(valor);
				}
			}
		}

		if (document.referrer && document.referrer.indexOf(window.location.origin) !== 0) {
			saida.referrer = document.referrer;
		}

		return saida;
	}

	/**
	 * APAGA o que a atribuição guardou no navegador deste visitante.
	 *
	 * A recusa não desfazia nada: o `localStorage` continuava com a campanha e o
	 * `_fbc` continuava no navegador pelo prazo inteiro. Negar medição e ficar
	 * com o identificador de clique de anúncio guardado é a pior das duas
	 * posições — o dado continua lá, e quem o guardou disse que não guardaria.
	 */
	function esquecerAtribuicao() {
		try {
			window.localStorage.removeItem(CHAVE_ATRIBUICAO);
		} catch (erro) {
			// Armazenamento indisponível: não havia o que apagar.
		}

		try {
			document.cookie = '_fbc=; Max-Age=0; Path=/; SameSite=Lax' +
				(window.location.protocol === 'https:' ? '; Secure' : '');
		} catch (erro) {
			// Cookie indisponível: não havia o que expirar.
		}
	}

	function atribuicao() {
		if (window.f3baseContexto) {
			return window.f3baseContexto.atribuicaoContato();
		}

		// Sem contexto classificado, o CTA conserva apenas a origem desta URL.
		esquecerAtribuicao();
		var atual = atribuicaoDaUrl();
		atual.modelo = String(ATRIBUICAO.modelo || '');
		return atual;
	}

	function formularioDe(gatilho) {
		var seletor = gatilho.getAttribute('data-f3base-form');

		if (!seletor) {
			return null;
		}

		try {
			return document.querySelector(seletor);
		} catch (erro) {
			return null;
		}
	}

	function valorDoCampo(escopo, nome) {
		var elemento = escopo.querySelector('[data-f3base-campo="' + nome + '"]');

		if (!elemento) {
			elemento = escopo.querySelector('[name="' + nome + '"]');
		}

		return elemento && typeof elemento.value === 'string' ? elemento.value.trim() : '';
	}

	function honeypotDe(escopo) {
		var elemento = escopo.querySelector('[data-f3base-honeypot]');

		if (!elemento) {
			elemento = escopo.querySelector('[name="website"]');
		}

		return elemento && typeof elemento.value === 'string' ? elemento.value.trim() : '';
	}

	function coletar(gatilho) {
		var escopo = formularioDe(gatilho);
		var carga = {};
		var i;
		var nome;

		if (escopo) {
			for (i = 0; i < CAMPOS.length; i++) {
				nome = CAMPOS[i];
				carga[nome] = limitar(nome, valorDoCampo(escopo, nome));
			}
			carga.website = honeypotDe(escopo);
		}

		return carga;
	}

	function temContato(carga) {
		var i;

		for (i = 0; i < CAMPOS.length; i++) {
			if (carga[CAMPOS[i]]) {
				return true;
			}
		}

		return false;
	}

	/*
	 * A MENSAGEM É SÓ A MENSAGEM. Nenhum código de referência, id de sessão ou
	 * parâmetro de rastreio entra no texto que a pessoa vê ao abrir a conversa:
	 * quem recebe o WhatsApp lê um código que não significa nada para ela, e
	 * quem manda passa a explicar por que o site escreveu aquilo.
	 *
	 * A correlação entre o clique e a conversa é feita por DATA E HORA, fora do
	 * site: o registro do clique carrega o carimbo de tempo, e é por ele que
	 * alguém casa a conversa que chegou com o clique que a originou.
	 */
	function mensagemDe(gatilho) {
		var propria = gatilho.getAttribute('data-f3base-mensagem');

		return propria || String(dados.mensagem || '');
	}

	function urlWhatsapp(gatilho) {
		var numero = gatilho.getAttribute(ATRIBUTO_NUMERO) || String(dados.numero || '');
		var texto = mensagemDe(gatilho);

		if (!texto) {
			return 'https://wa.me/' + encodeURIComponent(numero);
		}

		return 'https://wa.me/' + encodeURIComponent(numero) + '?text=' + encodeURIComponent(texto);
	}

	/* Uma renovação em voo por consumidor. O prazo relativo também suporta relógio local divergente. */
	var tokenFila = [];
	var tokenEmCurso = false;
	var tokenValidoAte = 0;
	var tokenBloqueadoAte = 0;
	function tokenDisponivel() {
		var agora = Date.now();
		return tokenValidoAte > agora || parseInt(String(dados.token || '').split('.')[0], 10) * 1000 > agora + 30000;
	}
	function obterToken(aoTer, forcar) {
		if (!forcar && tokenDisponivel()) { aoTer(String(dados.token)); return; }
		if (!dados.rotaToken || typeof window.fetch !== 'function' || Date.now() < tokenBloqueadoAte) { aoTer(''); return; }
		if (tokenFila.length >= 32) { aoTer(''); return; }
		tokenFila.push(aoTer);
		if (tokenEmCurso) { return; }
		tokenEmCurso = true;
		var encerrado = false;
		var controle = typeof window.AbortController === 'function' ? new window.AbortController() : null;
		var temporizador = setTimeout(function () { if (controle) { controle.abort(); } terminar(''); }, 8000);
		function terminar(token) {
			if (encerrado) { return; }
			encerrado = true;
			clearTimeout(temporizador);
			tokenEmCurso = false;
			var fila = tokenFila; tokenFila = [];
			if (token) { dados.token = token; }
			for (var i = 0; i < fila.length; i++) { fila[i](token); }
		}
		var alvo = String(dados.rotaToken) + (String(dados.rotaToken).indexOf('?') === -1 ? '?' : '&') + 'pagina=' + encodeURIComponent(window.location.pathname);
		var opcoes = { method: 'GET', credentials: 'same-origin', cache: 'no-store' };
		if (controle) { opcoes.signal = controle.signal; }
		try {
			window.fetch(alvo, opcoes).then(function (resposta) {
				if (resposta && resposta.status === 429) {
					var espera = resposta.headers && resposta.headers.get ? parseInt(resposta.headers.get('Retry-After'), 10) : 60;
					tokenBloqueadoAte = Date.now() + Math.max(1, Math.min(3600, espera || 60)) * 1000;
				}
				return resposta && resposta.ok ? resposta.json() : null;
			}).then(function (corpo) {
				if (encerrado) { return; }
				var token = corpo && typeof corpo.token === 'string' ? corpo.token : '';
				if (token) { tokenValidoAte = Date.now() + Math.max(0, Math.min(86400, Number(corpo.ttl) || 0) - 30) * 1000; }
				terminar(token);
			})['catch'](function () { terminar(''); });
		} catch (erro) { terminar(''); }
	}
	function recusaDeToken(resposta, aoTer) {
		if (!resposta || resposta.status !== 403 || typeof resposta.json !== 'function') { aoTer(false); return; }
		resposta.json().then(function (corpo) { aoTer(!!corpo && corpo.codigo === 'f3base_token_invalido'); })['catch'](function () { aoTer(false); });
	}

	/* POST com confirmação quando disponível. Falha de rede não reenvia um sucesso desconhecido. */
	var leadBloqueadoAte = 0;
	function enviar(carga, jaRenovou) {
		if (Date.now() < leadBloqueadoAte) { return; }
		var perfil = window.f3baseAnalise && window.f3baseAnalise.perfilAparelho && window.f3baseAnalise.perfilAparelho();
        var corpo = JSON.stringify(perfil && carga.consentimento_medicao ? Object.assign({}, carga, {perfil_aparelho:JSON.stringify(perfil)}) : carga);
		if (typeof window.fetch === 'function') {
			try {
				window.fetch(String(dados.endpoint), {
					method: 'POST', headers: { 'Content-Type': 'application/json' }, body: corpo,
					keepalive: true, credentials: 'same-origin', cache: 'no-store'
				}).then(function (resposta) {
					if (resposta && resposta.status === 429) {
						var espera = resposta.headers && resposta.headers.get ? parseInt(resposta.headers.get('Retry-After'), 10) : 60;
						leadBloqueadoAte = Date.now() + Math.max(1, espera || 60) * 1000;
					}
					if (resposta && resposta.ok) { return; } if (jaRenovou) { return; }
					recusaDeToken(resposta, function (recusado) {
						if (!recusado) { return; }
						if (carga.token !== dados.token && tokenDisponivel()) { carga.token = String(dados.token); enviar(carga, true); return; }
						obterToken(function (token) { if (token) { carga.token = token; enviar(carga, true); } }, true);
					});
				})['catch'](function () { /* Resultado desconhecido: não duplicar o registro. */ });
				return;
			} catch (erro) { /* Falha síncrona de transporte: usar a reserva disponível. */ }
		}
		try {
			if (navigator && typeof navigator.sendBeacon === 'function') {
				navigator.sendBeacon(String(dados.endpoint), new Blob([corpo], { type: 'application/json' }));
			}
		} catch (erro) { /* Registro nunca interrompe o destino escolhido pelo visitante. */ }
	}
	function registrar(carga) {
		obterToken(function (token) { if (token) { carga.token = token; enviar(carga, false); } }, false);
	}

	/** GA4 recebe comando com send_to; GTM recebe um objeto por evento. */
	function googleEnviar(categoria, args, marcado) {
        if(window.f3baseContexto&&window.f3baseContexto.politica(categoria==='medicao'?'ga4':'google_ads',marcado)==='suprimir'){return;}
		if (typeof window.f3baseGoogleEnviar === 'function') { window.f3baseGoogleEnviar(categoria, args, marcado); }
		else if (permiteCategoria(categoria) && typeof window.gtag === 'function') { window.gtag.apply(window, args); }
	}

	function evento(nome,parametros,marcado){
        if(!permiteCategoria('medicao')){return;}
        if(window.f3baseTracking&&window.f3baseTracking.carregar){window.f3baseTracking.carregar();}
        if(MEDICAO.gtm&&(!window.f3baseContexto||window.f3baseContexto.politica('gtm',marcado)!=='suprimir')&&window.f3baseConsentimento&&window.f3baseConsentimento.permiteGtm()){
            var objeto=Object.assign({event:nome},parametros);if(marcado===true){objeto.f3base_contexto_teste=true;objeto.traffic_type='internal';objeto.debug_mode=true;}window.dataLayer.push(objeto);
        }
        if(MEDICAO.ga4&&typeof window.gtag==='function'){try{googleEnviar('medicao',['event',nome,Object.assign({},parametros,{send_to:String(MEDICAO.ga4)})],marcado);}catch(erro){/* Contato continua. */}}
    }

    window.f3baseOfertaEvento=function(nome,parametros,teste){if(['oferta_exibida','oferta_aberta','oferta_fechada'].indexOf(nome)>=0){evento(nome,parametros,teste);}};
    document.dispatchEvent(new CustomEvent('f3base-ofertas-destino-pronto'));
	/**
	 * Normalização de e-mail para Enhanced Conversions, pela regra do Google.
	 *
	 * Espaço fora, minúsculas, e — só para os domínios que o próprio Google
	 * nomeia — os pontos do usuário removidos. Nenhuma regra inventada para
	 * outros provedores: normalizar demais casa menos, não mais.
	 */
	function normalizarEmail(email) {
		var limpo = String(email || '').trim().toLowerCase();
		var partes = limpo.split('@');

		if (partes.length !== 2) {
			return '';
		}

		if (partes[1] === 'gmail.com' || partes[1] === 'googlemail.com') {
			partes[0] = partes[0].split('+')[0].replace(/\./g, '');
		}

		return partes[0] + '@' + partes[1];
	}

	/**
	 * Normalização de telefone para Enhanced Conversions: E.164, e só.
	 *
	 * Sem o `+` e o código do país não há E.164, e adivinhar o país a partir do
	 * idioma do site seria inventar um número. Sem prefixo, não vai nada.
	 */
	function normalizarTelefone(telefone) {
		var bruto = String(telefone || '').trim();

		if (bruto.indexOf('+') !== 0) {
			return '';
		}

		var digitos = bruto.replace(/[^0-9]/g, '');

		return digitos ? '+' + digitos : '';
	}

	function sha256(texto) {
		if (!window.crypto || !window.crypto.subtle || typeof window.crypto.subtle.digest !== 'function') {
			return null;
		}

		try {
			return window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(texto)).then(function (buffer) {
				var bytes = new Uint8Array(buffer);
				var saida = '';
				var i;

				for (i = 0; i < bytes.length; i++) {
					saida += ('0' + bytes[i].toString(16)).slice(-2);
				}

				return saida;
			});
		} catch (erro) {
			return null;
		}
	}

	/**
	 * Enhanced Conversions do Google — INERTE por desenho neste template.
	 *
	 * Ela só existe quando um formulário associado fornece e-mail ou telefone, e
	 * o template desta base não tem formulário nenhum: o ramo nasce sem uso, e
	 * está aqui declarado para o projeto que acrescentar um. O disparo do Ads
	 * espera o hash resolver quando há campos — quem navega é o link, não este
	 * código, e o atraso de um microtask não segura o visitante.
	 *
	 * @return {Promise|null} Promessa que resolve quando `user_data` foi setado.
	 */
	function dadosDoUsuario(carga) {
		/*
		 * O PORTÃO VEM PRIMEIRO, e ele é o que faltava. Esta função manda à
		 * conta do Google o SHA-256 do e-mail e do telefone do visitante, e
		 * rodava sem consultar o consentimento — a única guarda era
		 * `typeof window.gtag !== 'function'`, que o stub do Consent Mode torna
		 * verdadeira em TODA página, mesmo sem `gtag.js` carregado. Quem
		 * recusava a medição via Pixel e Insight Tag calarem e o `user_data`
		 * sair assim mesmo.
		 */
		if (!permiteTags()) {
			return null;
		}

		if (!ADS.id || typeof window.gtag !== 'function') {
			return null;
		}

		var email = normalizarEmail(carga.email);
		var telefone = normalizarTelefone(carga.telefone);

		if (!email && !telefone) {
			return null;
		}

		var pendentes = [];
		var chaves = [];

		if (email) {
			pendentes.push(sha256(email));
			chaves.push('sha256_email_address');
		}

		if (telefone) {
			pendentes.push(sha256(telefone));
			chaves.push('sha256_phone_number');
		}

		if (pendentes.indexOf(null) !== -1) {
			return null;
		}

		return Promise.all(pendentes).then(function (hashes) {
			if (!permiteTags()) { return; }
			var user = {};
			var i;

			for (i = 0; i < hashes.length; i++) {
				user[chaves[i]] = hashes[i];
			}

			googleEnviar('publicidade', ['set', 'user_data', user]);
		});
	}

	/**
	 * O portão do consentimento, do lado do navegador.
	 *
	 * Mesma semântica de `f3base-tracking.js`, e a igualdade é deliberada: sem o
	 * objeto do consentimento na página não há o que consultar, e a ausência
	 * dele não pode virar bloqueio silencioso — o servidor já decidiu uma vez, e
	 * ele é a decisão de reserva. O que este portão acrescenta é a NEGATIVA
	 * TARDIA: o objeto existe, o visitante recusou depois de as tags terem
	 * carregado, e a recusa precisa alcançar os disparos seguintes.
	 *
	 * @return {boolean} Verdadeiro quando o site pode mandar evento a terceiro.
	 */
	function permiteCategoria(categoria) {
        if (!window.f3baseContexto || !window.f3baseContexto.pronto || !window.f3baseContexto.pronto()) { return false; }
		var consentimento = window.f3baseConsentimento;
		if (consentimento && typeof consentimento.permiteCategoria === 'function') { return consentimento.permiteCategoria(categoria); }
		return consentimento && typeof consentimento.permiteTags === 'function' ? consentimento.permiteTags() : false;
	}
	function permiteTags() { return permiteCategoria('publicidade'); }

	/**
	 * A conversão do clique, nos quatro canais, de um lugar só.
	 *
	 * Conversões exigem captura elegível confirmada pelo servidor.
	 *
	 * Os disparos diretos respeitam cada slot; no contêiner, quem
	 * configura as tags deve conferir o objeto que `evento()` publica.
	 */
    var contextosCapturas=new Map();
    function confirmarConversao(formulario,conversao,carga){
        if (['whatsapp_cta','contato_cta'].includes(carga.method)) { return; }
        if(conversao.elegivel){carga.supressoes=conversao.supressoes||{};carga.meta_correspondencia=conversao.meta_correspondencia||{};converter(formulario,conversao.event_id,carga);return;}
        if(!conversao.finalizacao||contextosCapturas.size>=20){return;}
        var proof=conversao.finalizacao;if(!contextosCapturas.has(proof.record_id)){contextosCapturas.set(proof.record_id,{form:formulario,proof:proof,carga:carga,busy:false});}
        finalizarContextos();
    }
    function finalizarContextos(saida){
        var ctx=window.f3baseContexto;if(!ctx){return;}
        contextosCapturas.forEach(function(item,key){
            if(item.busy){return;}if(Date.now()/1000>item.proof.ate){contextosCapturas.delete(key);return;}
            var state=ctx.estado();if(!saida&&state==='pendente'){return;}item.busy=true;
            var body=Object.assign({},item.proof,{estado:saida&&state==='pendente'?'saida':state});delete body.url;
            if(state==='permitida'){
                var tr=window.f3baseTracking,aud=ctx.audiencia&&ctx.audiencia();if(tr){body.sessao=tr.sessao()||'';body.visitante=tr.visitante()||'';}
                var perfil=window.f3baseAnalise&&window.f3baseAnalise.perfilAparelho&&window.f3baseAnalise.perfilAparelho();if(perfil){body.perfil_aparelho=JSON.stringify(perfil);}
                body.atribuicao=ctx.atribuicao();var nav=ctx.navegacao&&ctx.navegacao();if(nav){body.navegacao=nav.navegacao;}
                if(aud){body.largura_janela=String(aud.largura);body.max_touch_points=String(aud.max_touch_points);body.retorno=aud.retorno;body.visitas=String(aud.visitas);body.visitas_desde=String(aud.visitas_desde);body.visitas_minimo=aud.visitas_minimo?'1':'0';}
            }
            fetch(item.proof.url,{method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(function(r){return r.json();}).then(function(r){if(r.ok){contextosCapturas.delete(key);if(r.conversao&&r.conversao.elegivel){item.carga.supressoes=r.conversao.supressoes||{};item.carga.meta_correspondencia=r.conversao.meta_correspondencia||{};converter(item.form,r.conversao.event_id,item.carga);}}}).catch(function(){}).finally(function(){item.busy=false;});
        });
    }
    document.addEventListener('f3base-contexto-pronto',function(){setTimeout(function(){finalizarContextos(false);},0);});
    window.addEventListener('pagehide',function(){finalizarContextos(true);});
	var conversoesPendentes=new Map(),conversoesLiberadas=new Set();
    function retomarConversoes(){if(!window.f3baseContexto||!window.f3baseContexto.pronto()){return;}var pendentes=Array.from(conversoesPendentes.values());conversoesPendentes.clear();pendentes.forEach(function(x){converter(x[0],x[1],x[2]);});}
    document.addEventListener('f3base-contexto-pronto',retomarConversoes);document.addEventListener('f3base-consentimento',retomarConversoes);
    function converter(formulario, id, carga) {
        if(conversoesLiberadas.has(id)){return;}
        carga=carga||{};
        var context=window.f3baseContexto;
        if(context&&context.pendente&&context.pendente()){if(conversoesPendentes.size<20){conversoesPendentes.set(id,[formulario,id,carga]);}return;}
        if(!context||!context.pronto||!context.pronto()){return;}
        var supressoes=carga.supressoes||{};
        var material=carga.method==='conteudo',transporte=carga.transporte||{},ga4=material?CONTEUDO.ga4===true:transporte.ga4==='navegador';
        var metaEvento=supressoes.meta?'':(material?(CONTEUDO.meta===true?'MaterialDownload':''):'Lead');
        var linkedinId=material?(CONTEUDO.linkedin===true?CONTEUDO.linkedinId:''):(typeof carga.linkedin_conversion_id==='string'?carga.linkedin_conversion_id:LINKEDIN.conversionId);
        if(supressoes.ga4){ga4=false;}if(supressoes.linkedin){linkedinId='';}
        var adsLabel=material?(CONTEUDO.google_ads===true?CONTEUDO.adsLabel:''):(transporte.google_ads==='navegador'?ADS.label:'');
        var teste=typeof carga.contexto_teste==='boolean'?carga.contexto_teste:!!context.teste();
        conversoesLiberadas.add(id);
        document.dispatchEvent(new CustomEvent('f3base-lead-confirmado',{detail:{id:id,teste:teste,metodo:carga.method||'formulario',meta_evento:metaEvento}}));
        var params={form_id:formulario,correlation_id:id,event_id:id,superficie:carga.superficie||'conteudo',method:carga.method||'formulario'};
        if(supressoes.google_ads){adsLabel='';}
        if(teste){params.traffic_type='internal';params.debug_mode=true;if(ga4){evento(material?'download_material':'generate_lead',params,true);}return;}
        if(window.f3baseTracking&&window.f3baseTracking.carregar){window.f3baseTracking.carregar();}
        if(ga4){evento(material?'download_material':'generate_lead',params,false);}
        if(window.f3baseClarityConversao){window.f3baseClarityConversao(formulario,carga.method||'formulario');}
        if(GOOGLE_ADS&&adsLabel&&ADS.id){
            var pendente=dadosDoUsuario(carga);
            if(pendente&&typeof pendente.then==='function'){pendente.then(function(){conversaoDoAds(id,adsLabel);}).catch(function(){conversaoDoAds(id,adsLabel);});}
            else{conversaoDoAds(id,adsLabel);}
        }
        if(!permiteTags()){return;}
        function metaEnviar(){if(typeof window.fbq==='function'&&permiteTags()&&context.pronto()&&!teste&&!context.teste()){var matching={};if(!material){['em','ph'].forEach(function(k){var v=(carga.meta_correspondencia||{})[k];if(typeof v==='string'&&/^[a-f0-9]{64}$/.test(v)){matching[k]=v;}});}if(Object.keys(matching).length){[String(META.pixelId)].concat(META.pixelsAdicionais||[]).forEach(function(id){window.fbq('init',id,matching);});}delete carga.meta_correspondencia;window.fbq(material?'trackCustom':'track',metaEvento,{}, {eventID:id});document.dispatchEvent(new CustomEvent('f3base-meta-pixel',{detail:{nome:metaEvento,id:id}}));}}
        if(META_PIXEL&&metaEvento&&META.modo!=='servidor'&&META.pixelId){try{if(window.f3baseDestinoEnviar){window.f3baseDestinoEnviar('meta',metaEnviar,teste,true);}else{metaEnviar();}}catch(erro){/* Medição não interrompe o visitante. */}}
        function linkedinEnviar(){if(typeof window.lintrk==='function'){window.lintrk('track',{conversion_id:Number(linkedinId),event_id:id});}}
        if(linkedinId){try{if(window.f3baseDestinoEnviar){window.f3baseDestinoEnviar('linkedin',linkedinEnviar,teste,true);}else{linkedinEnviar();}}catch(erro){/* Medição não interrompe o visitante. */}}
    }
    function conversaoDoAds(id,label) {
        if(!permiteTags()||!ADS.id||!label||typeof window.gtag!=='function'){return;}
        try{googleEnviar('publicidade',['event','conversion',{send_to:String(ADS.id)+'/'+String(label),transaction_id:id}]);}catch(erro){/* Medição não interrompe o visitante. */}
    }

	function marcarInicio(gatilho) {
		var id = gatilho.getAttribute('data-f3base-lead') || 'contato-whatsapp';

		if (iniciados[id]) {
			return;
		}

		iniciados[id] = true;
		evento('form_start', { form_id: id });
	}

	/**
	 * Correlação estável por CTA dentro da janela DECLARADA.
	 *
	 * O DEFEITO MEDIDO: a janela era de cinco segundos, escritos aqui dentro. É
	 * menos do que uma pessoa leva para clicar no botão, ver o que abriu, voltar
	 * e clicar de novo — e cada clique depois do quinto segundo nascia com uma
	 * correlação nova: dois leads na caixa, duas reservas de deduplicação, e a
	 * mesma conversão contada de novo em todos os fornecedores, com um
	 * `eventID` diferente que a deduplicação da Meta não podia casar.
	 *
	 * A janela declarada vem do servidor e é de um minuto. Dentro dela, o mesmo
	 * CTA devolve a MESMA chave enquanto a página viver: o carimbo é reescrito
	 * a cada clique reaproveitado, então uma sequência de cliques espaçados de
	 * menos de um minuto continua sendo a mesma interação. Passada a janela sem
	 * clique nenhum, o clique seguinte é uma interação nova — que é o caso que
	 * ainda precisa nascer com correlação própria.
	 */
	function correlacaoDo(gatilho) {
		var modo=window.f3baseContexto&&window.f3baseContexto.teste()?'1':'0';
        if(gatilho.getAttribute('data-f3base-correlation-teste')!==modo){gatilho.removeAttribute('data-f3base-correlation');gatilho.setAttribute('data-f3base-correlation-teste',modo);}
		var guardada = gatilho.getAttribute('data-f3base-correlation');
		var carimbo = parseInt(gatilho.getAttribute('data-f3base-correlation-em'), 10);
		var segundos = Math.floor(Date.now() / 1000);

		if (guardada && carimbo > 0 && (segundos - carimbo) <= JANELA_CORRELACAO) {
			gatilho.setAttribute('data-f3base-correlation-em', String(segundos));

			return guardada;
		}

		var nova = correlationId();

		gatilho.setAttribute('data-f3base-correlation', nova);
		gatilho.setAttribute('data-f3base-correlation-em', String(segundos));

		return nova;
	}

	function aoClicar(gatilho) {
        document.dispatchEvent(new CustomEvent('f3base:contato-capturado'));
		var id = correlacaoDo(gatilho);
		var formulario = gatilho.getAttribute('data-f3base-lead') || 'contato-whatsapp';
		var carga = coletar(gatilho);
		var numero = gatilho.getAttribute(ATRIBUTO_NUMERO) || String(dados.numero || '');

		/*
		 * O DESTINO DO AGENTE VENCE. Só um link com número explicitamente
		 * marcado no elemento recebe o `wa.me`, e ele abre em ABA
		 * NOVA: a conversa acontece fora do site, e levar a aba junto faz o
		 * visitante perder a página que estava lendo.
		 */
		if (numero && !temDestinoProprio(gatilho)) {
			gatilho.setAttribute('href', urlWhatsapp(gatilho));
			gatilho.setAttribute('target', '_blank');
			gatilho.setAttribute('rel', 'noopener');
		}

		if (registrados[id]) {
			return;
		}

		registrados[id] = true;

		carga.token = String(dados.token || '');
		carga.correlation_id = id;

		/*
		 * O CARIMBO DE TEMPO É A CHAVE DA CORRELAÇÃO, e por isso sai em duas
		 * formas: a legível, com o fuso explícito, para quem vai casar o clique
		 * com a conversa olhando as duas listas; e a de milissegundos, para
		 * quem faz esse casamento por programa. O `correlation_id` continua
		 * existindo só para deduplicar o evento entre navegador e servidor —
		 * ele nunca chega à mensagem nem ao link.
		 */
		carga.clicado_em = new Date().toISOString();
		carga.clicado_em_ms = Date.now();
		carga.formulario = limitar('formulario', formulario);
		carga.pagina = limitar('pagina', window.location.pathname + window.location.search);
		carga.classificacao_contexto=window.f3baseContexto&&window.f3baseContexto.estado?window.f3baseContexto.estado():'pendente';
		carga.consentimento = !!(window.f3baseConsentimento&&window.f3baseConsentimento.permiteCategoria('publicidade'));
		carga.atribuicao = atribuicao();
        carga.largura_janela=String(Math.min(20000,window.innerWidth||0));carga.max_touch_points=String(Math.min(20,navigator.maxTouchPoints||0));
        var aud=window.f3baseContexto&&window.f3baseContexto.audiencia&&window.f3baseContexto.audiencia();if(aud){carga.retorno=aud.retorno;carga.visitas=String(aud.visitas);carga.visitas_minimo=aud.visitas_minimo?'1':'0';carga.visitas_desde=String(aud.visitas_desde);carga.largura_janela=String(aud.largura);carga.max_touch_points=String(aud.max_touch_points);}
        carga.contexto_teste=!!(window.f3baseContexto&&window.f3baseContexto.teste());carga.audiencia_excluida=!!(window.f3baseContexto&&window.f3baseContexto.audienciaExcluida);
        var sup=null, node=gatilho, valid=['conteudo','menu','flutuante','elementor','cabecalho','barra_fixa'];
        while(node&&node.nodeType===1){var attr=node.getAttribute('data-f3base-superficie');var cls=valid.find(function(v){return node.classList.contains('f3base-superficie-'+v);});if(valid.indexOf(attr)>=0&&node.getAttribute('data-f3base-superficie-inferida')!=='1'){sup=attr;break;}if(cls){sup=cls;break;}node=node.parentElement;}
        carga.superficie=sup||gatilho.getAttribute('data-f3base-superficie')||'nao_informada';
        var contextoAnalise=window.f3baseAnalise&&window.f3baseAnalise.contexto();
        if(contextoAnalise){carga.navegacao=contextoAnalise.navegacao;carga.dispositivo=contextoAnalise.dispositivo;}
        carga.cta=limitar('cta',gatilho.getAttribute('data-f3base-cta')||gatilho.id||formulario);
		var sessaoAtual = window.f3baseTracking && typeof window.f3baseTracking.sessao === 'function' ? window.f3baseTracking.sessao() : null;
		carga.consentimento_medicao = !!(window.f3baseConsentimento&&window.f3baseConsentimento.permiteCategoria('medicao'));
		if (carga.consentimento_medicao && sessaoAtual) { carga.sessao = sessaoAtual; carga.visitante=window.f3baseTracking.visitante(); }
		carga.destino = gatilho.getAttribute('data-f3base-destino') || gatilho.href || gatilho.getAttribute('href') || '';
        var tipoDestino=window.f3baseContexto&&window.f3baseContexto.destino(carga.destino);if(!tipoDestino){return;}

		if (typeof carga.website === 'undefined') {
			carga.website = '';
		}

		registrar(carga);
		/* O endpoint confirma o registro do clique. */
	}

	function ligar() {
        document.addEventListener('f3base-formulario-aceito', function (ev) {
            var d = ev.detail || {}; if (!d.duplicado && d.conversao && d.correlacao && d.formulario) { confirmarConversao(d.formulario, d.conversao, {linkedin_conversion_id:d.linkedin_conversion_id,transporte:d.transporte,method:d.method,contexto_teste:d.contexto_teste,superficie:d.superficie||'conteudo'}); }
        });
        document.addEventListener('f3base-formulario-inicio', function (ev) { var d=ev.detail||{}; evento('form_start',{form_id:d.formulario,method:d.method||'formulario'}); });
		var seletor = String(dados.seletor || '[data-f3base-lead]');
        var classes = ['f3base-acao-contato'].concat(dados.classesCta || []);
        document.addEventListener('click', function (ev) {
            var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
            if (!a || a.closest('[data-f3base-formulario]') || a.hasAttribute('data-f3base-lead')) { return; }
            for (var c=0;c<classes.length;c++) { if (/^[a-zA-Z][a-zA-Z0-9_-]{0,79}$/.test(classes[c]) && a.closest('.'+classes[c])) { var tipo=window.f3baseContexto&&window.f3baseContexto.destino(a.getAttribute('href'));if(tipo){a.setAttribute('data-f3base-lead',tipo==='whatsapp'?'whatsapp':'contato');} break; } }
        }, true);

		/*
		 * A RECUSA ALCANÇA O QUE JÁ ESTAVA GUARDADO, na mesma navegação. Sem
		 * este ouvinte, quem desligava a medição no controle do rodapé saía da
		 * página com a campanha no `localStorage` e o `_fbc` no navegador,
		 * gravados antes da decisão — a negativa valeria só para o que viesse
		 * depois, e o que já estava lá ficaria pelo prazo inteiro.
		 */
		document.addEventListener('f3base-consentimento', function () {
			if (!permiteTags()) {
				esquecerAtribuicao();
				if (GOOGLE_ADS && ADS.id && typeof window.gtag === 'function') { window.gtag('set', 'user_data', null); }
			}
		});

		document.addEventListener('click', function (ev) {
			var alvo = ev.target;
            if (alvo && alvo.closest && (alvo.closest('[data-f3base-formulario]') || ev.f3baseFormularioInterceptado || alvo.closest('[aria-haspopup="dialog"]'))) { return; }

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && alvo.matches && alvo.matches(seletor)) {
					aoClicar(alvo);
					return;
				}
				alvo = alvo.parentNode;
			}
		}, true);

		document.addEventListener('input', function (ev) {
			var alvo = ev.target;

			if (!alvo || alvo.nodeType !== 1 || !alvo.closest) {
				return;
			}

			var formulario = alvo.closest('form');

			if (!formulario || formulario.hasAttribute('data-f3base-formulario')) {
				return;
			}

			var gatilhos = document.querySelectorAll(seletor);
			var i;

			for (i = 0; i < gatilhos.length; i++) {
				if (formularioDe(gatilhos[i]) === formulario) {
					marcarInicio(gatilhos[i]);
					return;
				}
			}
		}, true);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', ligar);
	} else {
		ligar();
	}
}(window, document));
