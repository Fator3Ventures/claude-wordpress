<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

final class F3Base_Contatos_Interface {
    private const CAMPOS = [
        'busca'=>'Nome ou e-mail','de'=>'De','ate'=>'Até','aparelho'=>'Aparelho','metodo'=>'Método',
        'formulario'=>'Formulário','captura'=>'Captura','atendimento'=>'Atendimento','plataforma'=>'Plataforma',
        'conta_id'=>'Conta','campanha_id'=>'Campanha','grupo_id'=>'Grupo','anuncio_id'=>'Anúncio',
        'campanha_historica'=>'Campanha no histórico','email'=>'E-mail','sessao'=>'Sessão',
        'correlacao'=>'Correlação','post_id'=>'Conteúdo',
    ];
    private const CAMPANHA = ['plataforma','conta_id','campanha_id','grupo_id','anuncio_id','campanha_historica'];
    private const ESCOLHAS = [
        'aparelho'=>['celular','tablet','computador','nao_identificado'],
        'metodo'=>['formulario','whatsapp_formulario','conteudo','whatsapp_cta','contato_cta','anuncio_meta','anuncio_google','anuncio_linkedin','email','contato_externo','legado_desconhecido'],
        'captura'=>['aceito','clique','suspeito'],'atendimento'=>['novo','respondido','spam'],
        'plataforma'=>['meta_ads','google_ads','linkedin_ads','openai_ads','nao_identificada'],
    ];
    private static function url(array $f): string {
        return add_query_arg(['page'=>'f3base-leads'] + $f, admin_url('admin.php'));
    }
    private static function campo(string $k, array $f): void {
        $atual = $f[$k] ?? '';
        echo '<label>'.esc_html(self::CAMPOS[$k]);
        if ($k==='formulario' || isset(self::ESCOLHAS[$k])) {
            $opcoes = [];
            if ($k==='formulario') {
                foreach ((array)F3Base_Options::ler('f3base_formularios') as $form) {
                    $opcoes[$form['id']] = $form['titulo'].' ('.$form['id'].')';
                }
                if ($atual!=='' && !isset($opcoes[$atual])) { $opcoes[$atual]=$atual.' (histórico)'; }
            } else {
                foreach (self::ESCOLHAS[$k] as $v) {
                    $opcoes[$v] = $k==='aparelho' ? F3Base_Contato_Apresentacao::rotulo_aparelho($v) : F3Base_Relatorios::rotulo($v);
                }
            }
            echo '<select name="'.esc_attr($k).'"><option value="">Todos</option>';
            foreach ($opcoes as $v=>$label) {
                echo '<option value="'.esc_attr((string)$v).'" '.selected($v,$atual,false).'>'.esc_html($label).'</option>';
            }
            echo '</select>';
        } else {
            $tipo = in_array($k,['de','ate'],true) ? 'date' : ($k==='busca' ? 'search' : 'text');
            echo '<input type="'.$tipo.'" name="'.esc_attr($k).'" value="'.esc_attr($atual).'">';
        }
        echo '</label>';
    }
    private static function filtros(array $f): void {
        $aba = array_intersect_key($f,array_flip(['segmento','lixeira']));
        $ativos = array_intersect_key($f,self::CAMPOS);
        echo '<form method="get" class="f3c-cartao"><h2>Filtrar contatos</h2><input type="hidden" name="page" value="f3base-leads">';
        foreach ($aba + array_intersect_key($ativos,array_flip(['email','sessao','correlacao','post_id'])) as $k=>$v) {
            if ($v!=='') { echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr((string)$v).'">'; }
        }
        foreach ([['busca','de','ate'],['aparelho','metodo','formulario','captura','atendimento']] as $grupo) {
            echo '<div class="f3c-grade">';
            foreach ($grupo as $k) { self::campo($k,$f); }
            echo '</div>';
        }
        echo '<details '.(array_intersect(self::CAMPANHA,array_keys($ativos))?'open':'').'><summary>Filtros de campanha</summary><div class="f3c-grade">';
        foreach (self::CAMPANHA as $k) { self::campo($k,$f); }
        echo '</div></details><p><button class="button button-primary">Filtrar</button> <a class="button" href="'.esc_url(self::url($aba)).'">Limpar</a></p>';
        foreach ($ativos as $k=>$v) {
            $resto = $aba + $ativos;
            unset($resto[$k]);
            $rotulo = self::CAMPOS[$k].' · '.$v;
            echo '<a class="f3c-selo is-info" aria-label="'.esc_attr('Remover filtro '.$rotulo).'" href="'.esc_url(self::url($resto)).'">'.esc_html($rotulo).' ×</a> ';
        }
        echo '</form>';
    }
    private static function selo(string $estado, string $prefixo=''): string {
        $ok = ['entregue','enviado','enviada','processado','resumo_processado','aceito','respondido','concluido'];
        $neutro = ['novo','nao_solicitado','desligado','desligada','nao_acionada','clique'];
        $classe = in_array($estado,$ok,true) ? 'is-ok' : (in_array($estado,$neutro,true) ? 'is-info' : 'is-warn');
        $rotulo = ['nao_enfileirado'=>'Não enfileirado','nao_solicitado'=>'Não solicitado',
            'nao_acionada'=>'Não acionada','desligada'=>'Desligada','desligado'=>'Desligado',
            'aprovado_sem_entrega_anterior_regra'=>'Aprovado sem entrega (regra anterior)'][$estado] ?? F3Base_Relatorios::rotulo($estado);
        return '<span class="f3c-selo '.$classe.'">'.esc_html($prefixo.$rotulo).'</span>';
    }
    private static function linha(array $l, array $f): string {
        $titulo = $l['nome'] ?: ($l['email'] ?: 'Clique de contato');
        $link = '<a href="'.esc_url(self::url(['record_id'=>$l['record_id']]+$f)).'">'.esc_html($titulo).'</a>';
        try {
            if (!empty($l['aviso_apresentacao'])) { throw new UnexpectedValueException(); }
            if (current_user_can('f3base_ler_leads')) { $l=F3Base_Contatos_Externos::projetar($l); }
            $avisos=[];
            $canais=['email'=>'E-mail','visitante'=>'Resposta','pipedrive'=>'Pipedrive','slack'=>'Slack','webhook'=>'Webhook'];
            foreach ($l['entregas']['canais'] ?? [] as $k=>$v) {
                $avisos[]=self::selo($v['estado'],($canais[$k] ?? $k).' · ');
            }
            $data = wp_date('d/m/Y H:i', strtotime($l['criado_em'].' UTC'));
            return '<tr><td class="f3c-data">'.esc_html($data).'</td><td>'.$link.($l['classe_trafego']==='teste'?' <strong>Teste</strong>':'').'</td><td>'.
                esc_html(F3Base_Relatorios::rotulo($l['metodo'])).'</td><td>'.self::selo($l['captura']).' '.self::selo($l['atendimento']).
                '</td><td>'.esc_html(F3Base_Contato_Apresentacao::rotulo_aparelho($l['aparelho'])).'</td><td>'.implode(' ',$avisos).'</td></tr>';
        } catch (Throwable $erro) {
            return '<tr><td>—</td><td>'.$link.'</td><td colspan="4"><span class="f3c-selo is-warn">Dados de apresentação indisponíveis</span></td></tr>';
        }
    }
    public static function lista(): void {
        $f=[];
        foreach (array_merge(array_keys(self::CAMPOS),['segmento','cursor']) as $k) {
            if (isset($_GET[$k]) && is_string($_GET[$k]) && $_GET[$k]!=='') { $f[$k]=sanitize_text_field(wp_unslash($_GET[$k])); }
        }
        if (!empty($_GET['lixeira'])) { $f['lixeira']=1; }
        $segmento = $f['segmento'] ?? 'sem_testes';
        // Keep the old cursor binding for previously issued links that omitted segmento.
        if (empty($f['cursor'])) { $f['segmento']=$segmento; }
        $ativa = !empty($f['lixeira']) ? 'Lixeira' : ($segmento==='somente_testes'?'Testes':'Contatos');
        echo '<nav class="f3c-subnav" aria-label="Contatos">';
        $filtros=array_intersect_key($f,self::CAMPOS);
        foreach (['Contatos'=>['segmento'=>'sem_testes'],'Testes'=>['segmento'=>'somente_testes'],'Lixeira'=>['lixeira'=>1,'segmento'=>'todos']] as $nome=>$alvo) {
            echo '<a '.($nome===$ativa?'aria-current="page"':'').' href="'.esc_url(self::url($alvo+$filtros)).'">'.esc_html($nome).'</a>';
        }
        echo '</nav>';
        self::filtros($f);
        $pagina = max(1,absint($_GET['paged'] ?? 1));
        $consulta=$f;
        if (isset($consulta['cursor'])) { $consulta['lixeira']=!empty($consulta['lixeira']); }
        $r=F3Base_Leads_Repositorio::consultar($consulta,isset($f['cursor'])?null:$pagina);
        if (empty($r['ok'])) { echo '<p role="alert">'.esc_html($r['codigo']).'</p>'; return; }
        echo '<section class="f3c-cartao"><h2>Resultados</h2>';
        if (isset($r['total'])) {
            echo '<div class="tablenav"><div class="tablenav-pages"><span class="displaying-num">'.esc_html(sprintf(_n('%s contato','%s contatos',$r['total'],'f3base'),number_format_i18n($r['total']))).'</span> ';
            echo wp_kses_post(paginate_links(['base'=>str_replace('999999','%#%',self::url(['paged'=>999999]+$f)),'format'=>'','current'=>$r['pagina'],'total'=>$r['paginas'],'prev_text'=>'← Anterior','next_text'=>'Próxima →','add_args'=>false]) ?: '');
            echo '</div></div>';
        }
        if (!$r['registros']) { echo '<p>Nenhum contato com estes filtros.</p>'; }
        else {
            F3Base_Qualidade::lote_ui($r['registros']);
            echo '<div class="f3c-rolagem" tabindex="0" role="region" aria-label="Lista de contatos"><table class="widefat striped"><thead><tr>';
            foreach (['Data local','Contato','Método','Estado','Aparelho','Aviso'] as $coluna) { echo '<th scope="col">'.esc_html($coluna).'</th>'; }
            echo '</tr></thead><tbody>';
            foreach ($r['registros'] as $l) { echo self::linha($l,['paged'=>$r['pagina']??1]+$f); }
            echo '</tbody></table></div>';
        }
        if (isset($f['cursor']) && $r['proximo_cursor']) { echo '<p><a href="'.esc_url(self::url(['cursor'=>$r['proximo_cursor']]+$f)).'">Próxima página</a></p>'; }
        if (F3Base_Leads_Admin::pode('f3base_exportar_leads')) {
            echo '<p><a href="'.esc_url(wp_nonce_url(add_query_arg(['action'=>'f3base_csv','cursor'=>false]+$f,admin_url('admin-post.php')),'f3base-csv')).'">Exportar CSV</a></p>';
        }
        echo '</section>';
    }
}
