# Operação e recuperação — 1.15.0

## Instalação e atualização

Instalação nova requer ausência de opções e tabelas anteriores do Core. Cria o esquema atual diretamente, aplica política Todas, habilita gestão por agentes e prepara a pasta privada. Configurações sem recursos associados, como navegação, permanecem com o padrão não configurado do catálogo.

Na atualização, confirme a base 1.14.0 concluída. O estado `f3base_release_1150` registra origem, fotografia e confirmação da política, checkpoint de ofertas e conclusão. Políticas Todas/Nenhuma/Selecionadas, listas vazias, interruptor desligado e destinatários existentes permanecem. Nenhum default é reaplicado sobre escolhas explícitas. Não há fluxo anterior à 1.14.0.

A trava evita duas atualizações concorrentes; checkpoints permitem retomar interrupções. Conflito de política impede sobrescrita. Versão anterior à base ou origem não comprovada interrompe o fluxo antes das transformações. Não há cadeia de instaladores/importadores históricos.

Confira estado concluído, pasta privada, um envio novo e saúde após instalar. Mantenha backup restaurável do banco, arquivos privados e código. Homologação de SMTP, infraestrutura e canal MCP deve ocorrer no ambiente de destino.

## Pasta privada

O caminho padrão é um diretório irmão da raiz WordPress: `f3-privado-` seguido de hash estável de ABSPATH. Instalações cujo pai também seja público precisam declarar `F3BASE_ARQUIVOS_PRIVADOS` no `wp-config.php`, apontando para uma pasta fora da raiz pública. O diretório pai deve existir e permitir criação/escrita. O caminho não depende do diretório de trabalho do CLI.

O teste de preparação cria um arquivo aleatório, grava, lê, confere, aplica permissão e remove. O diagnóstico distingue `pronto`, `ausente_criavel`, `sem_permissao`, `dentro_da_raiz_publica`, `caminho_invalido`, `espaco_insuficiente` e falha de teste. A leitura do diagnóstico não cria a pasta.

A exclusão das raízes públicas conhecidas não prova ausência de aliases configurados no Apache/Nginx/proxy. A verificação de alias da hospedagem permanece explicitamente pendente até conferência naquele ambiente. Não publique o diretório por alias. Use a ability de preparação após corrigir permissões/caminho.

## Cache

A rotina já usada para `cache.tokens` também pede por HTTP um artefato existente e elegível em `wp-content/cache/`: `index.html`, `index-https.html` e arquivos `wp-cache-<hash>.php` no diretório do site fornecido pelo WP Super Cache. Em modo com cabeçalhos preservados, os arquivos PHP têm preferência. Não executa PHP do cache, não segue redirecionamentos e não consulta corpos privados. A evidência fica em `artefato_cache`, junto da tentativa durável e do último sucesso.

Sucesso exige resposta completa de zero bytes com HTTP 200, 403, 404 ou 410. Corpo HTML de erro não atende esse aceite. Corpo igual ao hash do arquivo é exposição efetiva. Resposta 5xx, 429, redirecionamento, corpo truncado ou erro de rede deixa a prova pendente. Sem artefato elegível/WP Super Cache compatível não há prova de proteção; o diagnóstico permanece inconclusivo.

A sonda usa a cadência e a trava existentes. Leitura de saúde não faz uma nova requisição HTTP. Prova antiga sem o novo campo não certifica acesso direto. HIT por disco/cabeçalho continua uma prova separada da proteção do diretório.

## Métricas após load

A versão vendorizada conferida é Web Vitals 6.2.1, já minificada na 1.11.0 (11.093 bytes). O Core remove o enqueue antecipado e carrega a biblioteca assincronamente após `window.load`, respeitando a permissão de medição. Se o tracking for iniciado depois do load, agenda o carregamento imediatamente para a próxima tarefa.

Um observador mínimo guarda interações curtas antes da biblioteca ficar pronta; um patch local faz a transferência sem duplicar entradas do buffer nativo. O relógio do primeiro ocultamento é preservado e coletores iniciados numa página já oculta escoam entradas pendentes. A correção local de máximo de CLS entre janelas permanece. Inicialização duplicada é evitada.

A retenção antecipada é limitada a 2.000 entradas. Em excesso, INP não é relatado como valor parcial; a condição fica em `window.f3baseVitaisAntecipados.overflow`. Falha de rede marca `erro`. Navegação encerrada antes do load/carga da biblioteca pode não produzir métricas: não há como prometer coleta completa depois que o documento deixa de executar. Não são fabricados zeros. bfcache e cobertura em navegadores reais precisam do aceite específico descrito em VALIDACAO.md. Não se alega melhora na nota PageSpeed sem ensaio comparável.

## Publicação e regras do servidor

Uma geração LLMS é preparada em lotes limitados, com cursor, assinatura, trava e próxima tentativa. A geração publicada continua disponível durante edição/purga ordinária; só é substituída depois da preparação completa. Conteúdo privado, com senha, excluído ou noindex é retirado prioritariamente. Uma conversão incompleta retorna erro/pendência e preserva a publicação anterior. Sites de pouco tráfego precisam de cron efetivo.

`servidor-aplicar` consulta sem escrever; aplicar/remover exige revisão e capability. O bloco `F3BASE MANAGED` modifica apenas cabeçalhos de llms.txt e, se configurado, Options -Indexes. Backup privado contém bytes anteriores e hashes; arquivo de recuperação CLI é criado antes da escrita. Nada é aplicado na ativação. O teste compara home e sonda PHP dinâmica antes/depois, GET/HEAD identity/gzip, ETag ou Last-Modified/304, corpo e indexação. 500 após escrita tenta restauração somente sobre o hash aplicado. Conflito preserva evidência e exige recuperação dirigida. Nginx não recebe regras Apache.

Padrão de `bloquear_listagem`: false. A preferência ligada exige aplicar e confirmar o teste de um diretório aleatório com arquivo público de controle. O teste não lê arquivos privados. Documentos do plugin já têm proteção própria em docs/ e dados/, inclusive com plugin desativado. Arquivos oficiais antigos da raiz são retirados só quando o hash coincide; cópias locais modificadas são preservadas e diagnosticadas, exigindo mover/proteger antes de homologar aquela instalação.

O cache WP Super Cache precisa ignorar os parâmetros de publicidade declarados e excluir rotas técnicas/de teste. A leitura de saúde não altera wp-cache-config.php. Use a lista atual fornecida pelo diagnóstico, compare personalizações, aplique apenas o delta e prove HIT/MISS e proteção direta. Nunca use dados de visitante no HTML compartilhado.

## Retorno e recuperação

Priorize isolar o módulo afetado. Retornar o binário à 1.14.0 não restaura os contratos ou comportamentos anteriores automaticamente. Preserve banco atual, novos leads, anexos e filas; não restaure um banco inteiro antigo sobre novas capturas.

No downgrade da base atualizada, `ofertas[]` fica preservado como dado, mas a 1.14 não emite esse formato. Guarde as novas listas e o snapshot privado; uma restauração dirigida de `oferta` exige simulação e cuidado com alterações posteriores. Evidências v2 ficam em options próprias; não são reinterpretadas como prova 1.14. O veto `preservar_query=false` volta a ser ignorado no código antigo e a reclassificação de procedência `ability` deixa de ocorrer.

Se CAPI tiver sido ativada depois do pré-voo, suspenda o despacho pelo controle existente e preserve a fila antes de reverter: o binário 1.14 volta a ter os defeitos do envelope de formulário/teste. Não suponha que esteja desligada por uma leitura histórica. Purgue HTML/JS relevantes e confira abas antigas. Não fabrique marcadores de migração para permitir downgrade de instalação nova 1.15; recupere nessa própria versão.

Reativar a 1.15 é idempotente. Desinstalação preserva o acervo. Implantador, tema, exceções e compensações pertencem ao projeto do site e não são alterados pelo plugin.

## Antes da implantação em cada site

Registre host real, versões, UTC, snapshot e revisões. Confirme publicadores XML-RPC (incluindo Indexe, quando usado), acesso REST/MCP/editor, SMTP em caixa autorizada, raiz privada/aliases, WPSC, tema e exceções existentes. Teste envio com marca, atendimento, CSV, redirects com query, FAQ/autoria/oferta pública, menu/CTA, consentimento claro/escuro e HTTP dos documentos. Remova compensações do tema somente depois da prova equivalente. Não altere campanhas comerciais ou filtros GA4 definitivos implicitamente.

Mudanças de medição devem ter corte UTC por site, regra/versão, n e cobertura. Antes/depois da frota mede o conjunto de alterações, sem atribuir causalidade isolada a gtag.js. Os cinco 503 históricos precisam de HAR/log correlacionado para determinar a origem; o teste local de falha não prova a causa em produção.


## Migração de ofertas e retomada

A migração 1.14 → 1.15 converte apenas a antiga oferta inequívoca (preço, moeda, período e página pública válidos) para lista com ID estável. Lista `ofertas:[]` explícita não é substituída. Formatos ambíguos, chaves desconhecidas e `servicos[].publico` permanecem e são diagnosticados.

Antes da alteração, grava um JSON privado de permissão 0600, verifica SHA-256 e persiste checkpoint com hashes antes/depois e contagem. A escrita da option usa comparação dos bytes anteriores. Falha de snapshot/checkpoint/conflito impede a transformação; interrupção após a escrita pode retomar sem perder a contagem total. Consulte `f3base_release_1150.ofertas` e `ofertas_checkpoint`, `migradas`, `total_migradas`, `encontradas`, `pendencias`, snapshot e revisão. Não publique o snapshot: pode conter dados internos. Simule a substituição de listas antes de resolver pendências; a decisão sobre chaves extras é operacional.

## TTL e análise

`ttl_configurado_segundos` não é garantia de idade. No WP Super Cache em `wp-cache-cabecalhos`, a entrega depende da coleta `wp_cache_gc`; cron agendado pode atrasar. O diagnóstico distingue teto não garantido, coleta ausente/atrasada, relação com `ttl_token()` e proxy desconhecido. Idade observada exige `filemtime` do arquivo exato vinculado ao HIT; sem esse vínculo é indeterminada. A versão não altera o TTL do provedor.

Antes de POST, o cliente comum renova token vencido/próximo do vencimento; consumidores concorrentes compartilham a renovação. Análise captura imediatamente e inicia transporte regular 5 segundos após load, com prazo que não é adiado por novos eventos. Ocultar/sair antecipa a descarga; erro conserva IDs, sequência, horário e classe na fila limitada. Lead/formulário funcional não espera esse prazo. Fechamento abrupto, falta de rede e expiração da fila ainda podem causar perda. Não há promessa de coleta perfeita nem de ganho universal no PSI.

## Verificação de redirects

Retome `proximo_cursor` até cobrir todas as origens e variantes. Consultas, horários e contadores não alteram o contexto; mudanças de regras/hosts/permalinks/geração invalidam com motivo. Provas vencem individualmente. A execução guarda contexto e `execucao_id`; gravação usa o estado mais recente e revisão condicional. `verified` exige cobertura integral, sem substituir timeout por sucesso. Sondas locais são marcadas, sem parâmetro de bypass. R30 não muda exclusões do WP Super Cache nem exige purga por visitante.
