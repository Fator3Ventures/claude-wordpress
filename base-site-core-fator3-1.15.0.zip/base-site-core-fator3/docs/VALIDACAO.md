# Validação — 1.15.0

Release de 28/09/2026. Evidências e harnesses acompanham o pacote de fontes em `suite/versao-1150/evidencias/`. Os únicos caminhos de instalação suportados são site novo e base 1.14.0 concluída. Implantador, tema e piloto de korvena.net.br são externos a esta entrega.

## Ambiente e resultados do pacote

WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, WP Super Cache 3.1.3, servidor PHP com oito workers, Chrome Headless Shell 151.0.7922.34 e Lighthouse 13.5.0. Dados sintéticos; e-mails bloqueados por fixture. CAPI testada com transporte interceptado, sem comunicação comercial. Apache local não foi executado por restrição de mapeamento de usuário do ambiente; não se atribui a ele evidência desta bancada.

| Conjunto | Resultado |
|---|---|
| Regressões de contrato/dados | 78 verificações: query/veto, mescla/dependências, simulação sem efeitos, procedência, navegação, piso, provas compactas, ofertas/preços e migração retomável. |
| CAPI | 10 verificações: formulário real, marca por campo/cookie/cabeçalho, supressão, fbc/fbp, fila, ID/horário original, Test Events simulado, deduplicação e revogação. |
| Bordas | 17 verificações: CSV, filtros, neutralização, conflito de política, classificação/repetição e leitura de cadência. |
| LLMS | 23 verificações: arquivos/snapshots, purga, edição, hook real de regeneração, retirada pública, cabeçalhos e preservação do bloco externo. |
| HTTP | 22 verificações: HIT de cache PHP, 303 sem JS, robots final em site público/privado, referência expirada, 13 pares/52 variantes em lotes, repetição e evidência compacta recuperável. |
| Redirects adicionais | 21 verificações: 30 pares/120 variantes, estado incompleto, expiração, falha de banco, CAS concorrente, invalidação, slug antigo nativo/Core, veto e 410 mínimo. Fixture 410 corrigida para omitir destino; string vazia era recusada pelo contrato. Reteste isolado registrado. |
| Concorrência | 9 verificações com 12 processos e falhas reais induzidas de INSERT/quota: confirmação parcial, sequência, idempotência e recuperação. |
| Instalação/reversão | 10 etapas, 67 verificações, com binários reais de instalação nova e 1.14.0. Capturas posteriores e listas/falso/zero preservados. Três defeitos de baseline reproduzidos: query inválida, perda de fbc e teste do formulário elegível para fila comercial na 1.14.0. |
| Consentimento | 104 verificações, oito combinações de claro/escuro, 360/1440 px e variável isolada: cores computadas, contraste, fonte, hover/foco, texto longo, zoom, rodapé e escopo. Capturas incluídas. |
| Transporte | 22 verificações: saída curta/antes do load, prazo absoluto, fluxo contínuo, consentimento, offline, 503, retentativa em saída, token e sequência final em voo. `pageshow.persisted` exercitado por evento controlado; não comprova elegibilidade real para bfcache. |
| Cache envelhecido | Artefato PHP de 3900 s realmente servido, token vencido e vínculo exato corpo/arquivo. Navegador reproduz esses bytes; endpoints reais renovam antes dos POSTs de clique/formulário/análise, sem 403. Não se afirma HIT direto no navegador para essa prova combinada. |
| Sintaxe/assets | 112 PHP e 21 JS; sete assets recompostos com Terser fixado e conferência determinística. Biblioteca web-vitals preservada. |

## Decisão de transporte

Matriz de 60 execuções: baseline 1.14.0, +5 s e +10 s × Google imediato/por interação com teto de 5 s × mobile/desktop × cinco repetições rotacionadas. JSON, trace, DevTools, HAR derivado e medianas/quartis estão nas fontes. Todos os eventos enviados foram confirmados, sem erro de runtime Lighthouse. O processo foi retomado após a medição 44, conservando o checkpoint.

Foi escolhido prazo absoluto de **5000 ms após load** para o primeiro lote normal, sem reinício por evento. Saída/ocultação antecipam; captura e formulários continuam imediatos. +10 s não mostrou vantagem consistente entre modos e duplica a espera. As distribuições variaram e não demonstram ganho causal de nota; a escolha adia trabalho inicial de rede com prazo limitado e preserva cobertura nos cenários exercitados. O relatório externo contém a matriz numérica. Ajustes posteriores de recuperação de 503 não alteram o fluxo normal medido e foram verificados no harness de transporte final.

O HTML veio de HIT real wp-cache, com noindex da fixture; gtag oficial capturado foi servido localmente, coletores sem rede comercial e throttling simulado. Cache de navegador não foi uniformemente aquecido: o aquecimento usa contexto separado e Lighthouse conserva armazenamento dentro do processo. Não se mede latência real do Google, não se promete ganho PSI nem resultado idêntico na frota. Encerramento abrupto ainda pode perder eventos não confirmados.

## Limites e operações externas

O relatório `RELATORIO-1.15.0.md`, que acompanha a entrega, registra a homologação Site-Teste e o estado das tentativas PSI; este documento instalado registra o resultado reproduzível do pacote. A versão atual declarada pelo PSI deve ser conferida na medição externa, sem presumir que Lighthouse 13.5.0 corresponda ao serviço.

O backup real de ofertas de ctooffice citado no plano não foi fornecido; fixtures sintéticas não o substituem. O campo antigo `publico` permanece preservado e requer decisão operacional antes de substituir a lista. A prova de preço usa HTML público e filtros de visibilidade observáveis; não calcula todo CSS externo arbitrário. Conflito de outro emissor suspende emissão do Core e não modifica o tema.

Recepção real em Meta Test Events depende de ativação/autorização da conta; não foi simulada como aceite comercial. CAPI inativa no pré-voo Site-Teste não comprova ausência de impacto histórico ou estado de toda a frota. Não há migração de contatos para integrações, CRM/Pipedrive ou webhook nesta versão.

Publicação na frota aguarda piloto do dono, operações específicas de cada site e acompanhamento de sete dias. Os cinco 503 históricos continuam sem causa retrospectiva demonstrada. Os testes induzidos provam recuperação, não identificam esses episódios. Nenhuma edição de tema, implantador ou documentos externos da frota é declarada.
