<?php
/** Dois fluxos: instalação direta e atualização exclusiva da base 1.14.0. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Instalacao {
    const OPTION='f3base_release_1150';
    public static function origem(): string {
        global $wpdb;
        $s=get_option(self::OPTION,array());
        if (($s['versao']??'')==='1.15.0') { return !empty($s['concluido_em'])?'atual':($s['origem']??'indefinida'); }
        $base=get_option('f3base_release_1140',array());
        if (($base['versao']??'')==='1.14.0' && !empty($base['concluido_em'])) { return '1.14.0'; }
        $n=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name<>%s",$wpdb->esc_like('f3base_').'%','f3base_1150_trava'));
        $tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($wpdb->prefix.'f3base_').'%'));
        return !$wpdb->last_error && (int)$n===0 && !$tables?'nova':'indefinida';
    }
    public static function permitida(): bool { return in_array(self::origem(),array('atual','nova','1.14.0'),true); }
    public static function aviso(): void { if(current_user_can('manage_options')){echo '<div class="notice notice-error"><p>F3 Base: atualização bloqueada. A única versão de origem suportada é 1.14.0 concluída. Estado anterior sem versão confirmada exige recuperação; nenhum dado foi convertido.</p></div>';}}
    /** Só remove cópias oficiais obsoletas reconhecidas pelo hash. Arquivos locais divergentes permanecem e são diagnosticados. */
    public static function documentos_obsoletos(): array {
        $manifesto=json_decode((string)file_get_contents(F3BASE_PLUGIN_DIR.'docs/documentos-obsoletos.json'),true);$r=array('removidos'=>array(),'divergentes'=>array(),'falhas'=>array());
        foreach($manifesto['sha256']??array() as $nome=>$hashes){if(!preg_match('/^[A-Z0-9-]+\.md$/D',$nome)){continue;}$path=F3BASE_PLUGIN_DIR.$nome;if(!file_exists($path)){continue;}
            if(is_link($path)||!is_file($path)||!in_array(hash_file('sha256',$path),$hashes,true)){$r['divergentes'][]=$nome;continue;}
            if(unlink($path)){$r['removidos'][]=$nome;}else{$r['falhas'][]=$nome;}
        }return $r;
    }
    public static function atualizar(): array {
        $origem=self::origem();
        if($origem==='atual'){return array('ok'=>true,'codigo'=>'atual');}
        if(!self::permitida()){return array('ok'=>false,'codigo'=>'origem_nao_suportada');}
        global $wpdb;$lock=wp_generate_uuid4();$key='f3base_1150_trava';
        $old=get_option($key);if(is_array($old)&&($old['expira']??0)<time()){$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,maybe_serialize($old)));wp_cache_delete($key,'options');}
        $value=array('id'=>$lock,'expira'=>time()+120);if(!add_option($key,$value,'',false)){return array('ok'=>false,'codigo'=>'atualizacao_em_execucao');}
        try{
            $s=F3Base_Options::ler(self::OPTION);
            if(empty($s['versao'])){
                $foto=F3Base_Options::fotografia(F3Base_Options::OPTION_OPERAVEIS);
                $v=$foto['existe']?$foto['valor']:array();
                if($origem==='1.14.0'&&!F3Base_Politica::validar($v)){return array('ok'=>false,'codigo'=>'politica_origem_invalida');}
                $p=$origem==='nova'?array('schema'=>1,'modo'=>'todas','lista'=>array()):$v;
                $s=array('versao'=>'1.15.0','origem'=>$origem,'iniciado_em'=>time(),'politica_antes'=>$foto,'politica_depois'=>$p);
                $r=F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$s);if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'checkpoint_falhou');}
            }
            if(empty($s['politica_confirmada'])){
                $f=F3Base_Options::fotografia(F3Base_Options::OPTION_OPERAVEIS);
                if(!$f['existe'] || $f['valor']!==$s['politica_depois']){
                    if(!hash_equals($f['revisao'],$s['politica_antes']['revisao'])){return array('ok'=>false,'codigo'=>'conflito_politica');}
                    $r=F3Base_Options::gravar(F3Base_Options::OPTION_OPERAVEIS,$s['politica_depois'],F3Base_Options::ORIGEM_PADRAO,$f['revisao']);if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'politica_pendente');}
                }
                $r=F3Base_Options::atualizar_estado(self::OPTION,static function($v){$v['politica_confirmada']=true;return $v;});if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'checkpoint_falhou');}
            }
            if($s['origem']==='nova'){
                // Configurações ainda ausentes usam os padrões do catálogo. Não inventar IDs
                // de conteúdo (navegação, logo etc.) para semear um site sem esses recursos.
                $n='f3base_politica_canal';if(!F3Base_Options::fotografia($n)['existe']){
                    $r=F3Base_Options::gravar($n,true,F3Base_Options::ORIGEM_PADRAO,F3Base_Options::revisao($n));
                    if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'padroes_pendentes');}
                }
            }
            $n='f3base_contato';$foto=F3Base_Options::fotografia($n);$raw=get_option($n,null);
            if($s['origem']==='nova'&&($raw===null||(is_array($raw)&&!array_key_exists('email_leads',$raw)))){
                $v=is_array($raw)?$raw:array();$admin=(string)get_option('admin_email','');$v['email_leads']=is_email($admin)?array($admin):array();
                $r=F3Base_Options::gravar($n,$v,F3Base_Options::ORIGEM_PADRAO,$foto['revisao']);
                if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'destinatario_padrao_pendente');}
            }
            $documentos=self::documentos_obsoletos();if($documentos['falhas']){return array('ok'=>false,'codigo'=>'documentacao_obsoleta_pendente','documentos'=>$documentos);}
            F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($documentos){$v['documentos']=$documentos;return $v;});
            wp_clear_scheduled_hook(F3Base_Llms_Cobertura::EVENTO,array(0));
            $r=F3Base_Atualizacao::migrar();
            F3Base_Modulo_Comportamento::criar_tabela();F3Base_Vitais::instalar();
            if(empty($r['ok']) || !F3Base_Leads_Repositorio::instalar() || !F3Base_Analise::instalar()){return array('ok'=>false,'codigo'=>'schema_pendente');}
            $privado=F3Base_Arquivos_Privados::provisionar();if(empty($privado['ok'])){return array('ok'=>false,'codigo'=>'diretorio_privado_pendente');}
            $m=self::migrar_ofertas();if(empty($m['ok'])){return $m;}
            $r=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($m){$v['ofertas']=$m;$v['concluido_em']=time();return $v;});
            return array('ok'=>!empty($r['persisted']),'codigo'=>!empty($r['persisted'])?'concluido':'checkpoint_falhou');
        } finally{$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,maybe_serialize($value)));wp_cache_delete($key,'options');}
    }
    public static function migrar_ofertas(): array {
        global $wpdb;$n='f3base_seo_entidade';$f=F3Base_Options::fotografia_bruta($n);
        if($f['erro']){return array('ok'=>false,'codigo'=>'ofertas_leitura_falhou');}
        if(!$f['existe']||!is_array($f['valor'])){return array('ok'=>true,'migradas'=>0,'pendencias'=>array());}
        $raw=$f['valor'];$novo=$raw;$count=0;$pendentes=array();$encontradas=0;
        $hash=hash('sha256',maybe_serialize($raw));$checkpoint=get_option(self::OPTION,array())['ofertas_checkpoint']??array();
        if(($checkpoint['hash_depois']??'')===$hash){
            $result=$checkpoint['resultado'];$result['migradas']=0;$result['retomada']=true;
            $confirmed=F3Base_Options::atualizar_estado(self::OPTION,static function($v){$v['ofertas_checkpoint']['aplicado']=true;return $v;});
            if(empty($confirmed['persisted'])){return array('ok'=>false,'codigo'=>'ofertas_confirmacao_pendente');}
            F3Base_Cache_Pagina::solicitar();return $result;
        }
        if(!empty($checkpoint)&&empty($checkpoint['aplicado'])&&($checkpoint['hash_antes']??'')!==$hash){return array('ok'=>false,'codigo'=>'ofertas_checkpoint_conflitante');}
        foreach($raw['servicos']??array() as $i=>$s){
            if(!is_array($s)){continue;}if(array_key_exists('ofertas',$s)){continue;}
            if(!array_key_exists('oferta',$s)){$novo['servicos'][$i]['ofertas']=array();continue;}
            $o=$s['oferta'];++$encontradas;$schema=F3Base_Seo_Entidade::schema_oferta();$schema['properties']['descricao']=array('type'=>'string','maxLength'=>2000);$err=rest_validate_value_from_schema($o,$schema);
            if(!is_array($o)||is_wp_error($err)||array_diff(array_keys($o),array('preco','moeda','periodo','pagina','descricao'))){$pendentes[]='servicos['.$i.'].oferta';continue;}
            $oferta=array('id'=>'migrada-'.substr(hash('sha256',wp_json_encode($o)),0,16),'nome'=>$s['nome']??'','modalidade'=>'fixo')+$o;
            if(F3Base_Ofertas::validar(array(array('nome'=>$s['nome']??'','ofertas'=>array($oferta))))){$pendentes[]='servicos['.$i.'].oferta';continue;}
            $novo['servicos'][$i]['ofertas']=array($oferta);unset($novo['servicos'][$i]['oferta']);++$count;
        }
        $changed=!F3Base_Options::equivalente($raw,$novo);$snapshot=null;
        if($changed||$pendentes){
            $root=F3Base_Arquivos_Privados::raiz(true);if(!$root){return array('ok'=>false,'codigo'=>'snapshot_privado_indisponivel');}
            $name='seo-entidade-pre-1.15.0-'.substr($f['revisao'],0,24).'.json';$path=$root.'/'.$name;
            $body=wp_json_encode(array('versao_origem'=>'1.14.0','option'=>$n,'revisao'=>$f['revisao'],'valor'=>$raw),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            if(is_link($path)){return array('ok'=>false,'codigo'=>'snapshot_invalido');}
            if(!file_exists($path)){
                $tmp=$path.'.'.wp_generate_uuid4().'.tmp';$h=@fopen($tmp,'xb');if(!$h){return array('ok'=>false,'codigo'=>'snapshot_criacao_falhou');}
                $ok=@chmod($tmp,0600)&&fwrite($h,$body)===strlen($body)&&fflush($h);fclose($h);
                if(!$ok||!hash_equals(hash('sha256',$body),(string)hash_file('sha256',$tmp))||!@rename($tmp,$path)){@unlink($tmp);return array('ok'=>false,'codigo'=>'snapshot_gravacao_falhou');}
            }
            if(!hash_equals(hash('sha256',$body),(string)hash_file('sha256',$path))){return array('ok'=>false,'codigo'=>'snapshot_verificacao_falhou');}
            $snapshot=array('arquivo'=>$name,'sha256'=>hash('sha256',$body),'armazenamento'=>'pasta_privada');
        }
        $result=array('ok'=>true,'encontradas'=>$encontradas,'migradas'=>$count,'total_migradas'=>$count,'pendencias'=>$pendentes,'snapshot'=>$snapshot,'alterada'=>$changed,'revisao_antes'=>$f['revisao']);
        if($changed){
            $checkpoint=array('hash_antes'=>$hash,'hash_depois'=>hash('sha256',maybe_serialize($novo)),'resultado'=>$result,'aplicado'=>false);
            $saved=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($checkpoint){$v['ofertas_checkpoint']=$checkpoint;return $v;});
            if(empty($saved['persisted'])){return array('ok'=>false,'codigo'=>'ofertas_checkpoint_falhou');}
            $rows=$wpdb->query($wpdb->prepare("UPDATE {$wpdb->options} SET option_value=%s WHERE option_name=%s AND BINARY option_value=BINARY %s",maybe_serialize($novo),$n,maybe_serialize($raw)));
            wp_cache_delete($n,'options');wp_cache_delete('alloptions','options');
            if($rows!==1||!F3Base_Options::equivalente(get_option($n),$novo)){return array('ok'=>false,'codigo'=>'ofertas_conflito_ou_gravacao_falhou','snapshot'=>$snapshot);}
            F3Base_Cache_Pagina::solicitar();
            $saved=F3Base_Options::atualizar_estado(self::OPTION,static function($v){$v['ofertas_checkpoint']['aplicado']=true;return $v;});
            if(empty($saved['persisted'])){return array('ok'=>false,'codigo'=>'ofertas_confirmacao_pendente','snapshot'=>$snapshot);}
        }
        return $result;
    }

}
