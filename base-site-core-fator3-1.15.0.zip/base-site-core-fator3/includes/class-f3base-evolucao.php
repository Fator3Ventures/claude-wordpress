<?php
/** Contratos compartilhados da linha atual; sem efeitos ao consultar o catálogo. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Evolucao {
    public static function iniciar(): void {
        F3Base_Testes::iniciar();
        F3Base_Ofertas::iniciar();
        F3Base_Interface::iniciar();
        F3Base_Protecao::iniciar();
        F3Base_Servidor::iniciar();
        add_action('f3base_acessos_somar',array(F3Base_Acessos_Repeticao::class,'limpar'),1);
        add_action('wp_enqueue_scripts',array(F3Base_Atribuicao::class,'enfileirar'),5);
    }
    public static function sanitizar($v,array $p): array {
        $v=is_array($v)?$v:array();$out=array();
        foreach($p as $k=>$default){$x=array_key_exists($k,$v)?$v[$k]:$default;
            if(is_bool($default)){$out[$k]=in_array($x,array(true,1,'1'),true);}
            elseif(is_int($default)){$out[$k]=(int)$x;}
            elseif(is_array($default)){$out[$k]=array_is_list($default)?(is_array($x)?array_values($x):array()):self::sanitizar($x,$default);}
            else{$out[$k]=is_string($x)?sanitize_text_field($x):$default;}
        }return $out;
    }
    public static function recusar($v,array $d): string {
        if(!is_array($v)||array_diff(array_keys($v),array_keys($d['padrao']))){return 'Configuração contém campos desconhecidos.';}
        foreach($v as $k=>$x){$field=$d['subcampos'][$k]??array();$type=$field['tipo']??'';
            if($type==='booleano'&&!in_array($x,array(true,false,0,1,'0','1'),true)){return 'Booleano inválido: '.$k;}
            if($type==='enum'&&!array_key_exists((string)$x,$field['opcoes']??array())){return 'Escolha inválida: '.$k;}
            if($type==='grupo'){$err=self::recusar($x,array('padrao'=>$d['padrao'][$k],'subcampos'=>$field['subcampos']));if($err){return $k.': '.$err;}}
            if(in_array($type,array('emails','linhas'),true)&&(!is_array($x)||!array_is_list($x)||array_filter($x,static fn($i)=>!is_string($i)))){return 'Lista inválida: '.$k;}
            if($type==='emails'&&(count($x)>5||array_filter($x,static fn($i)=>!is_email($i)))){return 'Informe até cinco e-mails válidos.';}
            if($k==='ga4_ids'&&array_filter($x,static fn($i)=>!preg_match('/^G-[A-Z0-9]+$/D',$i))){return 'ID GA4 inválido.';}
            if($k==='capi_test_event_code'&&$x!==''&&(!is_string($x)||!preg_match('/^[A-Za-z0-9_-]{1,100}$/D',$x))){return 'Código Test Events inválido.';}
        }return '';
    }
    private static function campo($p,string $rotulo,string $descricao,array $opcoes=array()): array {
        $r=array('tipo'=>is_bool($p)?'booleano':(is_int($p)?'inteiro':(is_array($p)?'linhas':'texto')),'rotulo'=>$rotulo,'descricao'=>$descricao,'impacto'=>$descricao,'exemplo'=>$descricao);
        if($opcoes){$r['tipo']='enum';$r['opcoes']=$opcoes;}return $r;
    }
    private static function grupo(string $rotulo,string $secao,array $p,array $fields): array {
        return array('rotulo'=>$rotulo,'descricao'=>$rotulo,'operavel'=>true,'secao'=>$secao,'campo'=>'grupo','padrao'=>$p,'subcampos'=>$fields,'sanitiza'=>array(__CLASS__,'sanitizar'),'recusa'=>array(__CLASS__,'recusar'));
    }
    public static function catalogo(array $c): array {
        $admin=(string)get_option('admin_email','');
        $c['f3base_contato']['padrao']['email_leads']=is_email($admin)?array($admin):array();
        $c['f3base_llms']['padrao']['entrega']='arquivo_gerado';
        $c['f3base_llms']['padrao']['cabecalhos_servidor']=true;
        $c['f3base_llms']['subcampos']['cabecalhos_servidor']=self::campo(true,'Gerenciar cabeçalhos do arquivo','A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.');
        $c['f3base_seo_entidade']['padrao']['faq_schema']=true;
        $servicos=$c['f3base_seo_entidade']['schema_config']['properties']['servicos'];
        $service=&$servicos['items'];
        $service['additionalProperties']=false;$service['required']=array('nome');
        $service['properties']['nome']['minLength']=1;
        $service['properties']['ofertas']=array('type'=>'array','maxItems'=>100,'default'=>array(),'items'=>F3Base_Ofertas::schema());
        unset($service['properties']['oferta']);unset($service);
        $c['f3base_seo_entidade']['subcampos']['servicos']['schema_config']=$servicos;
        $c['f3base_seo_entidade']['schema_config']['properties']['servicos']=$servicos;
        $c['f3base_seo_entidade']['schema_config']['properties']['servicos']['items']['additionalProperties']=true;
        $c['f3base_seo_entidade']['subcampos']['servicos']['schema_entrada']=$c['f3base_seo_entidade']['subcampos']['servicos']['schema_config'];
        $p=F3Base_Testes::padrao();$f=array();
        $labels=array('habilitado'=>array('Identificar tráfego de teste','Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.'),'excluir_relatorios'=>array('Excluir testes dos relatórios por padrão','Os registros continuam disponíveis em Somente testes e Todos.'),'ga4_ids'=>array('IDs GA4 autorizados para homologação','Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.'),'gtm_homologado'=>array('Contêiner GTM verificado para testes','Só permita após provar que o contêiner suprime tags comerciais e separa destinos.'),'capi_test_event_code'=>array('Código Meta Test Events','Código do ambiente de teste da Meta. Não habilita o pixel no navegador.'),'email_destinatarios'=>array('Destinatários de homologação','Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.'));
        foreach($labels as $k=>$l){$f[$k]=self::campo($p[$k],$l[0],$l[1]);}
        $f['email_destinatarios']['tipo']='emails';$dest=array();
        foreach($p['destinos'] as $k=>$v){$choices=in_array($k,array('gtm','ga4','capi','email'),true)?array('suprimir'=>'Suprimir','marcar'=>'Marcar para homologação'):array('suprimir'=>'Suprimir (sem destino de teste homologado)');$dest[$k]=self::campo($v,strtoupper($k),'Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.',$choices);}
        $f['destinos']=array('tipo'=>'grupo','rotulo'=>'Envio de testes por destino','subcampos'=>$dest,'padrao'=>$p['destinos']);
        $c['f3base_testes']=self::grupo('Testes de agentes e operadores',F3Base_Options::SECAO_MEDICAO,$p,$f);
        $p=array('usuarios_rest_restritos'=>true,'xmlrpc_desativado'=>true,'login_generico'=>true);$f=array();
        foreach(array('usuarios_rest_restritos'=>'Restringir usuários na API pública','xmlrpc_desativado'=>'Desativar XML-RPC','login_generico'=>'Usar mensagem genérica no login') as $k=>$l){$f[$k]=self::campo(true,$l,'Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.');}
        $c['f3base_protecao']=self::grupo('Proteção pública',F3Base_Options::SECAO_PRIVACIDADE,$p,$f);
        $c['f3base_servidor']=self::grupo('Diretórios do servidor',F3Base_Options::SECAO_PRIVACIDADE,array('bloquear_listagem'=>false),array('bloquear_listagem'=>self::campo(false,'Bloquear listagem de diretórios da raiz','Ação explícita em Operação aplica Options -Indexes e verifica o resultado. Desligado até decisão do dono.')));
        $p=array('ativo'=>true,'meta'=>'herdar','linkedin'=>'herdar');$f=array('ativo'=>self::campo(true,'Política de carregamento por destino','Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.'));
        foreach(array('meta','linkedin') as $k){$f[$k]=self::campo('herdar',ucfirst($k),'Herdar acompanha a política Google; a exceção só afeta este destino.',array('herdar'=>'Herdar Google','imediato'=>'Após consentimento','apos_interacao'=>'Após interação'));}
        $c['f3base_carregamento_destinos']=self::grupo('Carregamento por destino',F3Base_Options::SECAO_MEDICAO,$p,$f);
        $c['f3base_redirects_hosts']=array('rotulo'=>'Hosts HTTPS permitidos nos redirects','descricao'=>'Lista vazia permite apenas destinos internos. Informe hosts exatos, sem caminhos ou curingas.','operavel'=>true,'campo'=>'linhas','padrao'=>array(),'sanitiza'=>static fn($v)=>is_array($v)?array_values(array_unique(array_map('strtolower',$v))):array(),'recusa'=>static fn($v)=>!is_array($v)||!array_is_list($v)||array_filter($v,static fn($h)=>!is_string($h)||!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/iD',$h))?'Informe hosts exatos válidos.':'');
        $p=array('ativo'=>true,'repeticao'=>true);$f=array('ativo'=>self::campo(true,'Classificação atual de acessos','Registra versão da regra, corrige slugs longos e separa evidência de automação.'),'repeticao'=>self::campo(true,'Analisar repetição em janela de 24 horas','Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.'));
        $c['f3base_classificacao_acessos']=self::grupo('Classificação de acessos',F3Base_Options::SECAO_MEDICAO,$p,$f);
        foreach(array('f3base_release_1140','f3base_release_1150','f3base_1150_trava','f3base_ofertas_evidencia_v2','f3base_analise_saude','f3base_servidor_estado','f3base_acessos_repeticao','f3base_llms_geracoes','f3base_llms_geracao_publicada','f3base_llms_trava') as $n){$c[$n]=array('rotulo'=>$n,'descricao'=>'Estado técnico, sem preferência de usuário.','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));}
        return $c;
    }
}
