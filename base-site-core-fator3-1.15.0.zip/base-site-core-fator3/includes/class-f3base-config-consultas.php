<?php
/** Projeções explícitas e histórico de configuração; nenhuma consulta executa efeitos. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Config_Consultas {
    public static function heranca(string $nome,array $d,?array $foto=null): array {
        $foto=$foto??F3Base_Options::fotografia($nome);$raw=F3Base_Options::fotografia_bruta($nome);
        $confirmada=!$foto['erro']&&!$raw['erro']&&hash_equals($foto['revisao'],$raw['revisao']);$paths=array();
        $walk=static function($padrao,$valor,bool $existe,string $path)use(&$walk,&$paths):void{
            if(!$existe){$paths[]=$path;}
            if(is_array($padrao)&&!array_is_list($padrao)){foreach($padrao as $k=>$v){$tem=$existe&&is_array($valor)&&array_key_exists($k,$valor);$walk($v,$tem?$valor[$k]:null,$tem,$path===''?(string)$k:$path.'.'.$k);}}
        };
        if($confirmada){$walk($d['padrao']??null,$raw['valor'],$raw['existe'],'');}
        $erros=$confirmada&&$raw['existe']?F3Base_Config_Mescla::erros_schema($raw['valor'],F3Base_Config_Contrato::schema_entrada($d)):array();
        if($confirmada&&$raw['existe']&&$nome==='f3base_seo_entidade'){
            foreach(F3Base_Seo_Entidade::validar($raw['valor']) as $e){$e['caminho']=$e['campo']??'';unset($e['campo']);$erros[]=$e;}
        }
        if(F3Base_Options::e_segredo($nome)){$erros=$erros?array(array('caminho'=>'','codigo'=>'segredo_invalido','motivo'=>'Valor secreto incompatível com o contrato.')):array();}
        $r=array('padrao_declarado'=>F3Base_Config_Contrato::visivel($nome,$d['padrao']??null),'valor_efetivo'=>F3Base_Config_Contrato::visivel($nome,$foto['valor']),'valor_bruto'=>$confirmada?F3Base_Config_Contrato::visivel($nome,$raw['valor']):null,'chaves_herdadas'=>$confirmada?array_values(array_unique($paths)):null,'heranca_status'=>$confirmada?($paths?'herdado':'explicito'):'indeterminado','valor_bruto_valido'=>$confirmada?!$erros:null,'origem_efetiva'=>$raw['existe']?($paths?'banco_com_heranca_por_chave':'banco'):'padrao','leitura_confirmada'=>$confirmada,'erros'=>$erros,'avisos'=>array());
        if(!$confirmada){$r['avisos'][]=array('codigo'=>'leitura_nao_confirmada','caminho'=>'','motivo'=>'Não foi possível vincular a leitura bruta à revisão.');}
        foreach($erros as $e){$r['avisos'][]=array('codigo'=>'dado_existente_invalido','caminho'=>$e['caminho'],'motivo'=>'Preservado até escrita explícita desse campo.');}
        if($nome==='f3base_nav_id'&&$confirmada){$r['navegacao']=self::navegacao($raw['existe']?$raw['valor']:null);}
        return $r;
    }
    public static function navegacao($id): array {
        $r=array('id_observado'=>$id,'referencia_valida'=>false,'uso_no_cabecalho'=>'nao_confirmado','referencias'=>array());
        if($id===0||$id==='0'){return array_replace($r,array('referencia_valida'=>true,'uso_no_cabecalho'=>'administrado_pelo_tema','codigo'=>'tema')) ;}
        if(!is_int($id)&&!(is_string($id)&&ctype_digit($id))){$r['codigo']='id_invalido';return $r;}
        $p=get_post((int)$id);$r['tipo_observado']=$p?$p->post_type:null;$r['estado_observado']=$p?$p->post_status:null;
        if(!$p||$p->post_type!=='wp_navigation'||$p->post_status!=='publish'){$r['codigo']='referencia_invalida';return $r;}
        $r['referencia_valida']=true;$r['codigo']='uso_nao_confirmado';
        if(!function_exists('wp_is_block_theme')||!wp_is_block_theme()){$r['uso_no_cabecalho']='nao_aplicavel';return $r;}
        $parts=array();$refs=array();$scan=static function(array $blocks,string $type)use(&$scan,&$refs,$id):void{
            foreach($blocks as $b){if($type==='parts'&&($b['blockName']??'')==='core/template-part'){$refs[]=$b['attrs']['slug']??'';}
                if($type==='nav'&&($b['blockName']??'')==='core/navigation'&&(int)($b['attrs']['ref']??0)===(int)$id){$refs[]='navigation';}
                $scan($b['innerBlocks']??array(),$type);
            }
        };
        foreach(get_block_templates(array(),'wp_template') as $t){$scan(parse_blocks($t->content),'parts');}$parts=array_unique($refs);
        foreach(get_block_templates(array(),'wp_template_part') as $part){
            if(($part->area??'')!=='header'||!in_array($part->slug,$parts,true)){continue;}$refs=array();$scan(parse_blocks($part->content),'nav');
            if($refs){$r['referencias'][]=$part->id;}
        }
        if($r['referencias']){$r['uso_no_cabecalho']='confirmado';$r['codigo']='navegacao_publicada_no_cabecalho';}
        return $r;
    }
	public const BLOCOS = array( 'integracoes', 'instrucoes', 'procedencia', 'mudancas', 'agenda', 'saude' );
	public static function propriedades(): array {
		return array(
			'compacto'     => array(
				'type'    => 'boolean',
				'default' => false,
			),
			'assuntos'     => array(
				'type'        => 'array',
				'items'       => array( 'type' => 'string' ),
				'uniqueItems' => true,
				'maxItems'    => 100,
			),
			'incluir'      => array(
				'type'        => 'array',
				'items'       => array(
					'type' => 'string',
					'enum' => self::BLOCOS,
				),
				'uniqueItems' => true,
			),
			'desde_versao' => array(
				'type'    => 'string',
				'pattern' => '^[0-9]+\\.[0-9]+\\.[0-9]+(?:-[A-Za-z0-9.-]+)?$',
			),
			'modulo'       => array(
				'type'      => 'string',
				'maxLength' => 80,
			),
			'tipo'         => array(
				'type' => 'string',
				'enum' => array( 'correcao', 'funcionalidade', 'manutencao' ),
			),
			'pagina'       => array(
				'type'    => 'integer',
				'minimum' => 1,
				'maximum' => 1000,
			),
			'limite'       => array(
				'type'    => 'integer',
				'minimum' => 1,
				'maximum' => 50,
			),
		);
	}
	public static function validar( $entrada, array $extras = array() ): string {
		if ( null === $entrada ) {
			return ''; }
		if ( ! is_array( $entrada ) ) {
			return 'entrada_invalida'; }
		if ( array_diff( array_keys( $entrada ), array_merge( array_keys( self::propriedades() ), $extras ) ) ) {
			return 'filtro_desconhecido'; }
		$r = rest_validate_value_from_schema(
			array_diff_key( $entrada, array_flip( $extras ) ),
			array(
				'type'                 => 'object',
				'properties'           => self::propriedades(),
				'additionalProperties' => false,
			)
		);
		if ( is_wp_error( $r ) ) {
			return 'filtro_invalido'; }
		$ids = array_map( static fn( $m ) => $m->id(), F3Base_Registro::modulos() );
		if ( isset( $entrada['modulo'] ) && ! in_array( $entrada['modulo'], array_merge( $ids, array( 'configuracao', 'operacao' ) ), true ) ) {
			return 'modulo_desconhecido'; }
		return array_diff( $entrada['assuntos'] ?? array(), $ids ) ? 'assunto_desconhecido' : '';
	}
	public static function incluir( array $entrada, string $bloco ): bool {
		return in_array( $bloco, $entrada['incluir'] ?? ( empty( $entrada['compacto'] ) ? array( 'integracoes', 'instrucoes' ) : array() ), true );
	}
	public static function nomes_por_assuntos( array $entrada ): ?array {
		if ( ! array_key_exists( 'assuntos', $entrada ) ) {
			return null; }
		$nomes = array();
		foreach ( F3Base_Registro::modulos() as $m ) {
			if ( in_array( $m->id(), $entrada['assuntos'], true ) ) {
				$nomes = array_merge( $nomes, $m->options_que_controlam() ); }
		}
		return array_values( array_unique( $nomes ) );
	}
	/** Histórico carregado somente por solicitação; a versão é comparada semanticamente. */
	public static function mudancas( array $entrada ): array {
		$arquivo = dirname( __DIR__ ) . '/dados/mudancas.json';
		$itens   = is_readable( $arquivo ) ? json_decode( (string) file_get_contents( $arquivo ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo local do pacote, sem origem remota.
		$itens   = is_array( $itens ) ? $itens : array();
		$desde   = $entrada['desde_versao'] ?? '0.0.0';
		$itens   = array_values( array_filter( $itens, static fn( $r ) => is_array( $r ) && version_compare( (string) ( $r['versao'] ?? '0.0.0' ), $desde, '>' ) && ( ! isset( $entrada['modulo'] ) || ( $r['modulo'] ?? '' ) === $entrada['modulo'] ) && ( ! isset( $entrada['tipo'] ) || ( $r['tipo'] ?? '' ) === $entrada['tipo'] ) && ( ! isset( $entrada['assuntos'] ) || in_array( $r['modulo'] ?? '', $entrada['assuntos'], true ) ) ) );
		usort( $itens, static fn( $a, $b ) => version_compare( $a['versao'], $b['versao'], '<' ) ? 1 : ( version_compare( $a['versao'], $b['versao'], '>' ) ? -1 : 0 ) );
		$pagina = (int) ( $entrada['pagina'] ?? 1 );
		$limite = (int) ( $entrada['limite'] ?? 20 );
		return array(
			'itens'          => array_slice( $itens, ( $pagina - 1 ) * $limite, $limite ),
			'total'          => count( $itens ),
			'pagina'         => $pagina,
			'limite'         => $limite,
			'proxima_pagina' => $pagina * $limite < count( $itens ) ? $pagina + 1 : null,
		);
	}
	/** Cópias são referências somente quando ID e geração coincidem. Estado atual é separado. */
    public static function integracoes(bool $compacto): array {
        return F3Base_Evidencias::projetar(array('cache'=>F3Base_Cache_Pagina::resumo(),'publicacao'=>F3Base_Llms::responsaveis()));
    }
}
