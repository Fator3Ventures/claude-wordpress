/*! F3 Base 1.15 — contexto de atribuição e teste compartilhado. GPL-2.0-or-later. */
(function (w,d) {
 'use strict';
 var cfg=w.f3baseContextoDados||{},fields=cfg.campos||[],pol=cfg.atribuicao||{},test=cfg.testes||{},last=null,renewals={},memory=null;
 var KEY='f3base_atribuicao_v1';
 function cookie(){return test.habilitado!==false&&d.cookie.split(';').some(function(v){return v.trim()==='f3base_teste=1';});}
 function marked(){var now=cookie();if(last!==null&&now!==last){memory=null;last=now;d.dispatchEvent(new CustomEvent('f3base-teste-alterado',{detail:{teste:now}}));}last=now;return now;}
 function consent(){return !!(w.f3baseConsentimento&&w.f3baseConsentimento.permiteCategoria('medicao'));}
 function read(){try{return JSON.parse(w.localStorage.getItem(KEY)||'null');}catch(e){return memory;}}
 function remove(){memory=null;try{w.localStorage.removeItem(KEY);w.localStorage.removeItem('f3base_atribuicao');}catch(e){}}
 function ads(){return consent()&&!!(w.f3baseConsentimento&&w.f3baseConsentimento.permiteCategoria('publicidade'));}
 function restrict(v){if(!v||typeof v!=='object'){return v;}if(!ads()){['fbc','fbp','gclid','gbraid','wbraid','fbclid','li_fat_id','msclkid'].forEach(function(k){delete v[k];});}return v;}
 function meta(v){
  if(!ads()||marked()){return v;}var cookies={};d.cookie.split(';').forEach(function(x){var a=x.trim().split('=');try{cookies[a[0]]=decodeURIComponent(a.slice(1).join('='));}catch(e){}});
  if(v.fbclid&&!cookies._fbc){cookies._fbc='fb.1.'+Date.now()+'.'+v.fbclid;d.cookie='_fbc='+encodeURIComponent(cookies._fbc)+'; Max-Age=7776000; Path=/; SameSite=Lax'+(location.protocol==='https:'?'; Secure':'');}
  ['fbc','fbp'].forEach(function(k){var x=cookies['_'+k];if(/^fb\.[0-9]{1,3}\.[0-9]{10,13}\.[A-Za-z0-9_-]+$/.test(x||'')){v[k]=x;}});return v;
 }
 function current(){var q=new URLSearchParams(w.location.search),v={};fields.forEach(function(k){var x=q.get(k);if(x){v[k]=x.slice(0,500);}});try{var ref=new URL(d.referrer);if(ref.hostname!==location.hostname){v.referrer=ref.hostname;}}catch(e){}return restrict(meta(v));}
 function attribution(){
  var value=current(),stamp=Math.floor(Date.now()/1000),isTest=marked(),stored=read();
  if(!consent()){remove();value.modelo='sessao';return value;}
  if(!stored||stored.expira<stamp||stored.teste!==isTest){stored=null;}
  if(stored){restrict(stored.primeiro);restrict(stored.ultimo);}
  var has=Object.keys(value).length>0;
  if(!stored){stored={primeiro:value,ultimo:value,primeiro_em:has?String(stamp):'',ultimo_em:has?String(stamp):'',expira:stamp+Math.max(1,Math.min(3650,Number(pol.ttl_dias)||30))*86400,teste:isTest};}
  else if(has){if(!Object.keys(stored.primeiro||{}).length){stored.primeiro=value;stored.primeiro_em=String(stamp);}if(JSON.stringify(stored.ultimo)!==JSON.stringify(value)){stored.ultimo=value;stored.ultimo_em=String(stamp);}}
  memory=stored;try{localStorage.setItem(KEY,JSON.stringify(stored));}catch(e){}
  var first=pol.modelo!=='last-touch',chosen=Object.assign({},first?stored.primeiro:stored.ultimo);chosen.primeiro_toque_em=stored.primeiro_em||'';chosen.ultimo_toque_em=stored.ultimo_em||'';chosen.modelo=first?'primeiro-toque':'ultimo-toque';chosen.primeiro_toque=Object.assign({},stored.primeiro);chosen.ultimo_toque=Object.assign({},stored.ultimo);chosen.sessao_origem=value;return chosen;
 }
 function policy(dest,wasTest){var yes=typeof wasTest==='boolean'?wasTest:marked();if(!yes){return 'normal';}var p=(test.destinos||{})[dest];if(p!=='marcar'){return 'suprimir';}if(dest==='gtm'&&test.gtm_homologado===true){return 'marcar';}if(dest==='ga4'&&Array.isArray(test.ga4_ids)&&test.ga4_ids.length){return 'marcar';}return 'suprimir';}
 function valid(token){var n=Number(String(token||'').split('.')[0]);return Number.isFinite(n)&&n>Math.floor(Date.now()/1000)+30;}
 function token(c,force){
  if(!force&&valid(c.token)){return Promise.resolve(c.token);}var url=new URL(c.rotaToken,location.href);if(c.caminhoToken){url.searchParams.set('caminho',c.caminhoToken);}url.searchParams.set('_f3',String(Date.now()));var key=c.rotaToken+'|'+(c.caminhoToken||'');
  if(!renewals[key]){var control=new AbortController(),deadline=setTimeout(function(){control.abort();},10000);renewals[key]=fetch(url.href,{credentials:'same-origin',cache:'no-store',signal:control.signal}).then(function(r){if(!r.ok){throw new Error('token_indisponivel');}return r.json();}).then(function(r){if(!valid(r.token)){throw new Error('token_invalido');}return r.token;}).finally(function(){clearTimeout(deadline);delete renewals[key];});}
  return renewals[key].then(function(v){c.token=v;return v;});
 }
 d.addEventListener('f3base-consentimento',function(){if(!consent()){remove();}else{attribution();}});
 w.f3baseContexto={teste:marked,atribuicao:attribution,politica:policy,token:token,tokenValido:valid,configTestes:test};
 marked();if(consent()){attribution();}
}(window,document));
