/*! F3 Base 1.15 — análise com confirmação por evento e retentativa limitada. GPL-2.0-or-later. */
(function () {
 'use strict';
 var cfg=window.f3baseAnaliseDados||{},nav='',current='',mode=false,queue=[],inflight=null,timer=0,pageSent=false,views=new WeakSet(),vitals={},retry=0,next=0,loaded=document.readyState==='complete',KEY='f3base_analise_fila';
 var ATRASO_INICIAL_MS=5000,initialDeadline=loaded?Date.now()+ATRASO_INICIAL_MS:0,timerDue=0,urgentPending=false;
 var counts={confirmados:0,recuperacoes:0,falhas:0,expirados:0,limite:0,rejeitados:0},dead=[];
 function permit(){return !!(window.f3baseTracking&&window.f3baseTracking.permiteTags()&&window.f3baseTracking.sessao());}
 function uuid(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(x){return ('0'+x.toString(16)).slice(-2);}).join('');}
 function read(){try{return JSON.parse(sessionStorage.getItem(KEY)||'null');}catch(e){return null;}}
 function persist(){if(permit()){try{sessionStorage.setItem(KEY,JSON.stringify({eventos:queue,contagens:counts,rejeitados:dead}));}catch(e){}}}
 function clear(){queue=[];nav='';current='';pageSent=false;views=new WeakSet();vitals={};clearTimeout(timer);timer=0;timerDue=0;urgentPending=false;retry=0;next=0;initialDeadline=loaded?Date.now()+ATRASO_INICIAL_MS:0;try{sessionStorage.removeItem(KEY);sessionStorage.removeItem('f3base_analise_origem');}catch(e){}}
 function context(){
  if(!permit()){return null;}var s=window.f3baseTracking.sessao(),test=!!(window.f3baseContexto&&window.f3baseContexto.teste());
  if(current!==s||mode!==test){current=s;mode=test;nav=uuid();pageSent=false;views=new WeakSet();vitals={};}
  return {sessao:s,visitante:window.f3baseTracking.visitante(),navegacao:nav,contexto_teste:test,dispositivo:matchMedia('(max-width: 767px)').matches?'movel':'desktop',atribuicao:window.f3baseContexto?window.f3baseContexto.atribuicao():{}};
 }
 function schedule(ms){
  if(!loaded){return;}if(!initialDeadline){initialDeadline=Date.now()+ATRASO_INICIAL_MS;}
  var due=Math.max(Date.now()+Math.max(ms||0,100),next,initialDeadline);
  if(timer&&timerDue<=due){return;}clearTimeout(timer);timerDue=due;
  timer=setTimeout(function(){timer=0;timerDue=0;flush(false);},Math.max(0,due-Date.now()));
 }
 function expire(){var cutoff=Math.floor(Date.now()/1000)-86400,n=queue.length;queue=queue.filter(function(e){return e.criado_em>=cutoff;});counts.expirados+=n-queue.length;}
 function reject(pack,code,id){var selected=id?pack.filter(function(e){return e.evento===id;}):pack.slice(0,1);selected.forEach(function(e){dead.push({evento:e.evento,sequencia:e.sequencia,codigo:code,em:Date.now()});queue=queue.filter(function(q){return q!==e;});counts.rejeitados++;});dead=dead.slice(-20);persist();}
 function flush(urgent,renewed){
  if(inflight&&urgent){urgentPending=true;}
  if(inflight||!queue.length||!permit()||(!urgent&&!loaded)||Date.now()<next){return;}if(!urgent&&Date.now()<initialDeadline){schedule(0);return;}expire();if(!queue.length){persist();return;}
  var pack=queue.filter(function(e){return e.contexto_teste===queue[0].contexto_teste;}).slice(0,20);
  while(pack.length>1&&new TextEncoder().encode(JSON.stringify(pack)).length>28000){pack.pop();}
  var control=new AbortController(),deadline=setTimeout(function(){control.abort();},20000);var run={pack:pack},again=false;inflight=run;
  var token=window.f3baseContexto?window.f3baseContexto.token(cfg,false):Promise.resolve(cfg.token);
  token.then(function(t){if(!permit()){throw new Error('consentimento_revogado');}return fetch(cfg.endpoint,{signal:control.signal,method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify({token:t,medicao:true,eventos:pack})});}).then(function(r){
   var header=r.headers.get('Retry-After'),wait=Number(header);if(!Number.isFinite(wait)&&header){wait=(Date.parse(header)-Date.now())/1000;}
   return r.text().then(function(text){var body;try{body=JSON.parse(text);}catch(e){body={codigo:'resposta_nao_json'};}return {status:r.status,data:body,wait:Number.isFinite(wait)?Math.max(0,wait):0};});
  }).then(function(r){
   if(!permit()){clear();return;}var body=r.data||{},acks=Array.isArray(body.confirmados)?body.confirmados:[];
   var before=queue.length;queue=queue.filter(function(e){return !acks.some(function(a){return a.evento===e.evento&&a.sequencia===e.sequencia&&pack.some(function(p){return p===e;});});});counts.confirmados+=before-queue.length;persist();
   if(body.ok){if(retry){counts.recuperacoes++;}retry=0;next=0;return;}
   if(r.status===403&&body.codigo==='token_invalido'&&!renewed&&window.f3baseContexto){return window.f3baseContexto.token(cfg,true).then(function(){again=true;});}
   if(body.codigo==='medicao_nao_permitida'){clear();return;}
   if(r.status===400||r.status===409||r.status===413){reject(pack,body.codigo||'rejeitado',body.evento);retry=0;return;}
   var ex=new Error(body.codigo||'envio_nao_confirmado');ex.wait=r.wait;throw ex;
  }).catch(function(e){
   if(!permit()){clear();return;}counts.falhas++;retry=Math.min(8,retry+1);next=Date.now()+Math.max(Number(e.wait||0)*1000,Math.min(300000,2000*Math.pow(2,retry))*(0.8+Math.random()*0.4));persist();
  }).finally(function(){clearTimeout(deadline);if(inflight===run){inflight=null;}if(again){flush(urgent,true);}else if(queue.length&&permit()){if(urgentPending&&Date.now()>=next){urgentPending=false;flush(true);}else{urgentPending=false;schedule(1000);}}else{urgentPending=false;}});
 }
 function emit(type,detail){var c=context();if(!c||!c.visitante){return;}expire();if(queue.length>=100){counts.limite++;persist();return;}
  var e=Object.assign({evento:uuid(),tipo:type,caminho:cfg.caminho,criado_em:Math.floor(Date.now()/1000),formulario:'',formulario_revisao:'',correlacao:'',detalhe:'',valor:0,sequencia:1},c,detail||{});queue.push(e);persist();schedule(500);
 }
 function formDetail(f,d){if(window.f3baseFormularioInstancia){window.f3baseFormularioInstancia(f);}return {formulario:f.dataset.f3baseFormulario,formulario_revisao:f.dataset.revisao||'',correlacao:(f.elements.submissao&&f.elements.submissao.value)||'',detalhe:(d&&d.codigo)||''};}
 function boot(){if(!permit()){clear();return;}context();if(!pageSent){pageSent=true;emit('pagina');}
  document.querySelectorAll('[data-f3base-formulario]').forEach(function(f){if(views.has(f)){return;}if(window.IntersectionObserver){var observer=new IntersectionObserver(function(entries){if(entries.some(function(e){return e.isIntersecting;})){if(permit()&&!views.has(f)){views.add(f);emit('form_vista',formDetail(f));}observer.disconnect();}},{threshold:0.1});observer.observe(f);}else{views.add(f);emit('form_vista',formDetail(f));}});
  if(loaded){schedule(500);}
 }
 var old=read();if(old&&Array.isArray(old.eventos)){queue=old.eventos.filter(function(e){return e&&typeof e.evento==='string';}).slice(-100).map(function(e){if(typeof e.contexto_teste!=='boolean'){e.contexto_teste=false;}return e;});expire();}
 ['inicio','tentativa','erro'].forEach(function(name){document.addEventListener('f3base-formulario-'+name,function(e){var f=e.target.closest('[data-f3base-formulario]');if(f){emit('form_'+name,formDetail(f,e.detail));}});});
 document.addEventListener('f3base-tracking-pronto',boot);document.addEventListener('f3base-consentimento',boot);document.addEventListener('f3base-teste-alterado',function(){current='';boot();});
 window.addEventListener('load',function(){loaded=true;if(!initialDeadline){initialDeadline=Date.now()+ATRASO_INICIAL_MS;}schedule(0);});window.addEventListener('online',function(){next=0;flush(false);});window.addEventListener('pageshow',function(e){if(e.persisted){current='';boot();}});
 window.addEventListener('pagehide',function(){flush(true);});document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden'){flush(true);}else{boot();}});
 window.f3baseAnalise={contexto:context,atribuicao:function(){return window.f3baseContexto?window.f3baseContexto.atribuicao():{};},diagnostico:function(){return {pendentes:queue.length,em_voo:!!inflight,proxima_tentativa:next,prazo_inicial:initialDeadline,atraso_inicial_ms:ATRASO_INICIAL_MS,contagens:Object.assign({},counts),rejeitados:dead.slice()};},vital:function(name,value,seq){var c=context();if(!c){return;}var id=vitals[name]||(vitals[name]=uuid());emit('vital',{evento:id,detalhe:name,valor:value,sequencia:seq});if(document.visibilityState==='hidden'){Promise.resolve().then(function(){flush(true);});}}};
 if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',boot);}else{boot();}
}());
