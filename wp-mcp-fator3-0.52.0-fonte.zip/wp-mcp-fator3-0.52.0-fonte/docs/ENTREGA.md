# Entrega 0.52.0

Pedidos MCP 89. Base direta 0.51.0. A operação e os critérios constam de RELEASE-0520.md. Os resultados estão em evidencias/0520.
