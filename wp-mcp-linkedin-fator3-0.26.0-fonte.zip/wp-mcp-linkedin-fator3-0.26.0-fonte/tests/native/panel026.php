<?php
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;
$_GET['tab']='connections';ob_start();L\Admin::screen();$html=ob_get_clean();
$d=new DOMDocument();libxml_use_internal_errors(true);assert17($d->loadHTML('<?xml encoding="UTF-8">'.$html));$x=new DOMXPath($d);
$n=$x->query('//details[.//input[@name="credential_notice_days"]]');assert17($n->length===1,'one section');$section=$n->item(0);
assert17(str_contains($section->textContent,'30, 14 e 3 dias')&&str_contains($section->textContent,'no painel'),'explanation not found');
$a=$x->query('.//input[@name="credential_notice_days"]',$section)->item(0);assert17($a->getAttribute('min')==='1'&&$a->getAttribute('max')==='365'&&$a->getAttribute('type')==='number','input range');
assert17(str_contains($section->textContent,'Indicador no painel (dias)')&&$x->query('.//input[@name="refresh_token" and @type="password"]',$section)->length===1,'visible label and protected credential');
echo wp_json_encode(['pass'=>'WordPress admin: grouping, explanatory text, label, limits and masked refresh credential'])."\n";
