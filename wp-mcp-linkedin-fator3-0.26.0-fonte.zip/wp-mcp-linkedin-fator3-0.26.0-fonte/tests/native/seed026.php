<?php
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;
use Fator3\McpFiles as M;
assert17(L\Config::VERSION==='0.25.0');
$a=wp_create_user('owner26','synthetic-only-26','owner26@example.invalid');(new WP_User($a))->set_role('administrator');wp_set_current_user($a);
if(class_exists(M\ConnectionContext::class)){
 $o=['user_id'=>$a,'grant_id'=>'qa26-a','client_id'=>'qa26','profile'=>'maintenance','status'=>'active'];
 assert17(M\Persistence::put('oauth-grants','qa26-a',$o,true));M\ConnectionContext::oauth($o);
}
setup17('site26','consumer26');
$page=['connection_id'=>'site26','account_id'=>'111','channel'=>'pages','report'=>'organization'];
add_filter('pre_http_request',static function($pre,$args,$url){return parse_url($url,PHP_URL_PATH)==='/rest/organizations/111'?result17(['id'=>111,'localizedName'=>'Org 26']):$pre;},PHP_INT_MAX,3);
$oldJob=L\Jobs::create(['query'=>$page,'idempotency_key'=>'normal26-job'])['job_id'];assert17(L\Jobs::run($oldJob)['status']==='complete');
$file=L\Export::create(['job_id'=>$oldJob,'idempotency_key'=>'normal26-export','format'=>'json']);
$revs=[];
foreach(['active26','revive26','manual26'] as $id){
 $t=L\Schedules::save(['schedule_id'=>$id,'query'=>$page,'enabled'=>$id!=='manual26','expected_revision'=>0,'interval_minutes'=>1440,'next_at'=>time()-60]);$revs[$id]=$t['revision'];
 if($id==='revive26'){$r=L\Store::get('schedule',$id);$v=$r['value'];$v['enabled']=false;$v['last_code']='not_authorized';$r=L\Store::put('schedule',$id,$v,$r['revision']);$revs[$id]=$r['revision'];}
}
$day=gmdate('Y-m-d',time()-86400*3);$dp=array_combine(['year','month','day'],array_map('intval',explode('-',$day)));
$ads=['connection_id'=>'site26','account_id'=>'222','channel'=>'ads','report'=>'ad_analytics'];
$q=$ads+['date_from'=>$day,'date_to'=>$day,'granularity'=>'DAILY','fields'=>['impressions']];
$bf=L\History::backfill(['query'=>$q,'idempotency_key'=>'baseline26-load']);
$stuck=L\History::backfill(['query'=>$q,'idempotency_key'=>'paused26-load'])['job_id'];$r=L\Store::get('job',$stuck);$v=$r['value'];$v['status']='paused';$v['last_code']='not_authorized';L\Store::put('job',$stuck,$v,$r['revision']);
$metric=['dateRange'=>['start'=>$dp,'end'=>$dp],'pivotValues'=>['urn:li:sponsoredAccount:222'],'impressions'=>17,'clicks'=>9];
$d=$ads+['selection'=>$q,'rows'=>[$metric],'currency'=>'BRL','fetched_at'=>gmdate('c'),'api_version'=>'202609','coverage'=>['complete'=>true,'errors'=>[]]];
$stored=L\History::ingest($d,L\Access::principal(),L\Connections::get('site26'),'old26');assert17($stored['stored_metrics']===2);
$e=L\HistoryExport::create(['query'=>$ads,'format'=>'json','idempotency_key'=>'baseline26-exp']);$pending=$e['export_id'];
$partial=L\HistoryExport::create(['query'=>$ads+['limit'=>1],'format'=>'json','idempotency_key'=>'baseline26-partial'])['export_id'];
assert17(L\HistoryExport::step(['export_id'=>$partial])['state']==='queued');
$e=L\HistoryExport::create(['query'=>$ads,'format'=>'json','idempotency_key'=>'baseline26-exp-complete']);$done=$e['export_id'];
assert17(L\HistoryExport::step(['export_id'=>$done])['state']==='complete');
global $wpdb;$digest=hash('sha256',serialize($wpdb->get_results('SELECT * FROM '.L\History::table().' ORDER BY row_key',ARRAY_A)));
file_put_contents(getenv('F3_LAB_ROOT').'/baseline026.json',wp_json_encode(compact('a','revs','q','ads','metric','pending','done','digest','stuck','oldJob','file','partial')+['job'=>$bf['job_id'],'job_revision'=>$bf['revision']]));
if(class_exists(M\ConnectionContext::class))M\Persistence::delete('oauth-grants','qa26-a');
(new WP_User($a))->set_role('subscriber');
