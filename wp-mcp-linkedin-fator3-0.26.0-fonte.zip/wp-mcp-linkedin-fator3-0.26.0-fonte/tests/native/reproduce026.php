<?php
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;use Fator3\McpFiles as M;
$old=L\Config::VERSION==='0.25.0';assert17($old||L\Config::VERSION==='0.26.0');
$id=wp_create_user('oldowner26','fixture-password','oldowner26@example.invalid');(new WP_User($id))->set_role('administrator');wp_set_current_user($id);
$oauth=static function($u,$g){$o=['user_id'=>$u,'grant_id'=>$g,'client_id'=>'qa26','profile'=>'maintenance','status'=>'active'];assert17(M\Persistence::put('oauth-grants',$g,$o,true));M\ConnectionContext::oauth($o);};
$oauth($id,'old26-a');setup17('rotation26','consumer26');$q=['connection_id'=>'rotation26','account_id'=>'111','channel'=>'pages','report'=>'organization'];
$created=L\Schedules::save(['schedule_id'=>'failed26','query'=>$q,'enabled'=>true,'expected_revision'=>0,'interval_minutes'=>1440,'next_at'=>time()-5]);
$job=L\Jobs::create(['query'=>$q,'idempotency_key'=>'oldcase-26']);
M\Persistence::delete('oauth-grants','old26-a');wp_set_current_user(1);$oauth(1,'old26-b');assert17(user_can($id,'manage_options'),'A still a WP administrator');
$r=L\Api::dispatch('job-status',['job_id'=>$job['job_id']]);
if($old){assert17(!$r['success']&&$r['code']==='not_authorized');echo '{"pass":"0.25.0 B blocked reading the job of A"}'."\n";}
else{assert17($r['success']&&$r['data']['revision']===$job['revision']);echo '{"pass":"0.26.0 B reads the original unchanged job"}'."\n";}
wp_set_current_user(0);L\Schedules::tick();$r=L\Store::get('schedule','failed26');
if($old){assert17(!$r['value']['enabled']&&$r['value']['last_code']==='not_authorized'&&$r['revision']>$created['revision']);echo '{"pass":"0.25.0 revoked MCP transport disables schedule and changes revision despite author retaining manage_options"}'."\n";}
else{add_filter('pre_http_request',static function($pre,$args,$url){return parse_url($url,PHP_URL_PATH)==='/rest/organizations/111'?result17(['id'=>111,'localizedName'=>'Org 26']):$pre;},PHP_INT_MAX,3);
 $run=L\Jobs::run($r['value']['last_job'],true);assert17($r['value']['enabled']&&$r['value']['last_code']===null&&$r['value']['edit_revision']===$created['revision']&&$run['status']==='complete');
 echo '{"pass":"0.26.0 same rotation keeps original admin valid, schedule enabled and revision stable, and collects successfully"}'."\n";}
