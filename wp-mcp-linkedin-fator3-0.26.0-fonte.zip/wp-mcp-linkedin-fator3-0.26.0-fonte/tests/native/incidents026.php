<?php
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;
$target='ops26@example.invalid';$mail=[];$slack=0;
function check26($ok,$name){assert17($ok,$name);echo wp_json_encode(['pass'=>$name])."\n";}
update_option('f3base_avisos_tecnicos',['email'=>$target,'antecedencia_dias'=>14]);
check26(F3Base_Alertas_Operacionais::destinatario()===$target,'Core technical recipient configured');
add_filter('pre_wp_mail',static function($pre,$args)use(&$mail){$mail[]=['to'=>$args['to'],'subject'=>$args['subject']];return true;},1,2);
add_filter('pre_http_request',static function($pre,$a,$url)use(&$slack){if(str_contains($url,'slack.com'))$slack++;return $pre;},1,3);
setup17('windows26','r26');$mail=[];
$raw=L\Store::get('connection','windows26');$v=$raw['value'];$v['refresh_token']='fixture26-refresh';L\Store::put('connection','windows26',$v,$raw['revision']);$proof=L\Store::get('token_proof','windows26');L\Store::remove('token_proof','windows26',$proof['revision']);
$observe=static function($days){$r=L\Store::get('connection','windows26');$v=$r['value'];$v['expires_at']=$v['refresh_expires_at']=$days?time()+DAY_IN_SECONDS*$days:0;L\Store::put('connection','windows26',$v,$r['revision']);
 for($n=0;$n<2;$n++){F3Base_Incidentes_Provedores::linkedin();L\SiteOperations::reminders(L\Connections::get('windows26'));}};
foreach([31=>0,29=>2,13=>4,2=>6,0=>6,35=>12] as $days=>$expected){$observe($days);check26(count($mail)===$expected,'Both real producers at '.$days.' days: expected '.$expected.' mail, captured '.count($mail));}
foreach($mail as $m)check26($m['to']===$target,'technical recipient only');
$before=count($mail);L\SiteOperations::incident('agenda_parada','agenda:qa26',true);L\SiteOperations::incident('agenda_parada','agenda:qa26',true);
L\SiteOperations::incident('agenda_parada','agenda:qa26',false);L\SiteOperations::incident('agenda_parada','agenda:qa26',false);
check26(count($mail)===$before+2&&str_contains($mail[$before]['subject'],'Incidente')&&str_contains($mail[$before+1]['subject'],'Recupera'),'one opening and one recovery per stopped schedule');
$hook=$GLOBALS['wp_filter']['f3base_incidente_publicar_v1'];unset($GLOBALS['wp_filter']['f3base_incidente_publicar_v1']);$before=count($mail);
try{L\SiteOperations::incident('agenda_parada','agenda:no-core26',true);L\SiteOperations::incident('agenda_parada','agenda:no-core26',false);check26(count($mail)===$before,'no alternative transport when Core unavailable');}finally{$GLOBALS['wp_filter']['f3base_incidente_publicar_v1']=$hook;}
L\SiteOperations::maintenance();L\SiteOperations::maintenance();check26(count($mail)===$before+2,'deferred events delivered once in order');check26($slack===0,'no Slack request');
