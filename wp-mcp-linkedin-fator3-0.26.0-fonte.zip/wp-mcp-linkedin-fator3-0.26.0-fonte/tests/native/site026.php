<?php
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;
use Fator3\McpFiles as M;
$b=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline026.json'),true,512,JSON_THROW_ON_ERROR);
function ok26($condition,$name){assert17($condition,$name);echo wp_json_encode(['pass'=>$name])."\n";}
if(class_exists(M\ConnectionContext::class)){
 $o=['user_id'=>1,'grant_id'=>'qa26-b','client_id'=>'qa26','profile'=>'maintenance','status'=>'active'];assert17(M\Persistence::put('oauth-grants','qa26-b',$o,true));M\ConnectionContext::oauth($o);
 ok26(!M\ConnectionContext::credential_active('grant:qa26-a',$b['a'])&&M\ConnectionContext::credential_active('grant:qa26-b',1),'A revoked, B active');
}
global $wpdb;
ok26(hash('sha256',serialize($wpdb->get_results('SELECT * FROM '.L\History::legacyTable().' ORDER BY row_key',ARRAY_A)))===$b['digest'],'original encrypted metrics and coverage unchanged');
$before=array_column(L\Schedules::list(),null,'schedule_id');
ok26($before['revive26']['enabled']&&$before['active26']['enabled']&&!$before['manual26']['enabled'],'automatic recovery excludes manual pause');
ok26(array_map(static fn($x)=>$x['revision'],$before)==$b['revs'],'public revisions unchanged at upgrade');
ok26(L\Jobs::status($b['job'])['revision']===$b['job_revision'],'old backfill visible unchanged');
$r=L\History::query($b['ads']);ok26(count($r['rows'])===2&&in_array(17,array_column(array_column($r['rows'],'row'),'value'),true)&&count($r['coverage']['recent_receipts'])===1,'B reads metric and coverage collected by A');
$blob=L\Export::read(['export_id'=>$b['file']['export_id']]);ok26(hash('sha256',base64_decode($blob['content_base64']))===$b['file']['sha256']&&L\Jobs::results(['job_id'=>$b['oldJob']])['job_status']==='complete','B reads original job result and verifies unchanged export bytes');
$exp=L\HistoryExport::step(['export_id'=>$b['partial']]);$all='';for($n=0;$n<$exp['parts'];$n++)$all.=base64_decode(L\HistoryExport::read(['export_id'=>$b['partial'],'part'=>$n])['content_base64']);
ok26($exp['state']==='complete'&&count(json_decode($all,true,512,JSON_THROW_ON_ERROR)['rows'])===2,'B resumes a historical export with a frozen A cursor and one existing part');
foreach(['done','pending'] as $type){$id=$b[$type];ok26(L\HistoryExport::step(['export_id'=>$id])['state']==='complete'&&str_contains(base64_decode(L\HistoryExport::read(['export_id'=>$id])['content_base64']),'"value":17'),'B reads old '.$type.' export');}
add_filter('pre_http_request',function($pre,$args,$url)use($b){$path=parse_url($url,PHP_URL_PATH);if($path==='/rest/organizations/111')return result17(['id'=>111,'localizedName'=>'Org 26']);if($path==='/rest/adAnalytics')return result17(['elements'=>[$b['metric']],'paging'=>['start'=>0,'total'=>1]]);if($path==='/rest/adAccounts/222')return result17(['id'=>222,'currency'=>'BRL','name'=>'QA']);return $pre;},PHP_INT_MAX,3);
wp_set_current_user(0);L\Schedules::tick();foreach(['active26','revive26'] as $id){$v=L\Store::get('schedule',$id)['value'];$result=L\Jobs::run($v['last_job'],true);ok26($result['status']==='complete'&&$result['rows']===1,'worker collects '.$id.' without signed-in user: '.$result['status'].' '.($result['last_code']??''));}
$resumed=L\Jobs::run($b['stuck'],true);ok26($resumed['status']==='complete'&&$resumed['rows']===1,'previously authorization-paused backfill resumes at its checkpoint');
$j=L\Jobs::run($b['job'],true);ok26($j['status']==='complete'&&$j['rows']===1,'backfill completed from original ID: '.$j['status'].' '.($j['last_code']??''));
L\PublicApi::register_consumer(['id'=>'consumer26','label'=>'Synthetic 26','contract'=>'linkedin-lead-reader/1.2.0']);$reader=L\PublicApi::lead_reader('consumer26');$req=['connection_id'=>'site26','account_id'=>'222','form_id'=>'8331','response_id'=>'lead17'];
$r=$reader->get_response($req);ok26($r['success'],'Lead Sync works after demotion of A: '.$r['code']);
wp_set_current_user(1);$after=array_column(L\Schedules::list(),null,'schedule_id');ok26($after['revive26']['revision']===$b['revs']['revive26']&&$after['active26']['revision']===$b['revs']['active26'],'successful attempts preserve edit revision');
$raw=L\Store::get('connection','site26');$c=$raw['value'];$c['enabled']=false;L\Store::put('connection','site26',$c,$raw['revision']);$r=L\Store::get('schedule','active26');$v=$r['value'];$v['next_at']=time()-1;L\Store::put('schedule','active26',$v,$r['revision']);wp_set_current_user(0);L\Schedules::tick();$a=L\Store::get('schedule','active26')['value'];ok26(!$a['enabled']&&$a['edit_revision']===$b['revs']['active26']&&$a['last_code']!==null,'real connection refusal stops schedule with unchanged edit revision');
ok26((L\Store::get('technical_incident',hash('sha256','agenda_parada|agenda:active26'))['value']['state']??'')==='aberto','technical incident retained for real failure');
ok26((L\Store::get('technical_incident',hash('sha256','autorizacao_recusada|administrador:'.$b['a']))['value']['state']??'')==='aberto','author demotion incident retained');
wp_set_current_user($b['a']);try{L\Jobs::status($b['job']);throw new RuntimeException('subscriber accepted');}catch(L\Fault $e){ok26($e->reason==='not_authorized','subscriber denied');}
