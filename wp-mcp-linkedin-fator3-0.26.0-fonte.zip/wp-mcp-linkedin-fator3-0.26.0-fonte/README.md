# Fonte — Fator3 MCP LinkedIn 0.26.0

Atualização a partir de 0.25.0: operação e acervo do site, revisão editorial das agendas, continuidade das concessões e avisos pelo Site Core. Consulte os documentos instalados RELEASE-0.26.0.md, MIGRATION.md, HISTORY.md e CREDENTIALS.md. Código editável: build/common, build/linkedin e build/docs/linkedin. A árvore plugin/wp-mcp-linkedin-fator3 corresponde ao instalador oficial.

## Reproduzir

Use WordPress 7.1.4 ou superior, PHP de 64 bits a partir de 8.3, Python 3 e MySQL/MariaDB descartável. Configure os caminhos e hashes reais em uma cópia de tools/lab-release0260.example.json. As dependências não são redistribuídas no ZIP. Testes de fornecedor usam respostas sintéticas.

```sh
F3_SOCIAL_PHP=/caminho/php python3 build/build.py
python3 tools/verify-installer026.py build/dist/wp-mcp-linkedin-fator3-0.26.0-instalador.zip plugin/wp-mcp-linkedin-fator3
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li26-isolado --order linkedin-only --tests suite.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li26-integrado --order linkedin-integrated --tests suite.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li26-troca --order linkedin-integrated --origin upgrade --tests site026.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li26-avisos --order linkedin-integrated --tests incidents026.php
```

Repita cada cenário com um diretório novo. O teste de cron cron025.php requer --activity-log com o sensor 5.7.0 identificado no manifesto. Os testes adicionais conversions023.php, rotation023.php, mcp-docs080.php e panel026.php cobrem contratos integrados. O instalador só contém runtime, manifestos e ajuda. Para fechar o fonte, coloque o relatório interno na raiz e use tools/package-source.py --output-dir com um diretório externo. A cópia interna antecede o cálculo do hash do próprio ZIP.
