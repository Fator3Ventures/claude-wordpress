# Entrega — Fator3 MCP 0.48.0

Revisão documental: 2 · Data: 18/11/2026 · Continuação: homologação, sem alteração dos ZIPs.
Situação: **implementado e instalado no Site-Teste; entrega com pendências operacionais**.
Responsável pelo pacote: Fator3 MCP. Slug/pasta: `wp-mcp-fator3`; basename: `wp-mcp-fator3/wp-mcp-fator3.php`.

Foram lidos integralmente `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, revisão 5 de 02/11/2026, além da regra comum, padrão do MCP, pedido `Fator3 MCP(20261118-135625).md`, relatório e impacto recebidos do Core 1.93.0. Prevaleceu o padrão completo. O checklist consta de `evidencias/0480/checklist.json` no fonte; as pendências abaixo impedem declarar conformidade integral sem ressalvas.

## 1. De onde esta versão entra

A rodada partiu da entrega 0.46.0 e implementou o pedido **84**, itens a–d. A 0.47.0 foi instalada no Site-Teste e executou a manutenção nativa. A conferência MCP revelou dois problemas de apresentação: rótulos em inglês e máscara de segurança sobre o nome da categoria OAuth. A correção foi publicada como **0.48.0**, sem regravar a versão instalada. O comportamento de retenção e incidentes da 0.47.0 foi preservado.

Base imediata da edição final: 0.47.0. Origem da rodada e base de produção informada: 0.46.0. Instalação limpa, avanço 0.47.0 → 0.48.0 e salto direto 0.46.0 → 0.48.0 têm cenários próprios; não há trava por versão de origem. A única edição final desta entrega é a 0.48.0.

Requisitos mantidos: **WordPress >= 7.1.4; PHP >= 8.3**. Validação efetiva: WordPress 7.1.4 com PHP 8.4.27 e MariaDB 11.8.6 no laboratório; WordPress 7.1.4 e PHP 8.3.36 no Site-Teste. O pacote contém 481 arquivos, incluindo 474 PHP, todos submetidos a lint no build final. Reconstrução determinística produziu os mesmos bytes.

Senhas de aplicação, identidade dos provedores, rotas OAuth/MCP, três metatools e descoberta sem limite explícito conservaram as decisões anteriores do usuário. Os pedidos 81–83 foram considerados aceitos conforme o material recebido; não foram reabertos.

## 2. Convivência e encaminhamentos

| Pacote | Versão examinada e carregada |
|---|---|
| Fator3 Site Core | 1.93.0 |
| Google | 0.36.0 |
| Meta | 0.28.0 |
| LinkedIn | 0.25.0 |
| Pipedrive | 0.11.1 |

A convivência foi conferida no laboratório e no Site-Teste por carregamento, catálogo e saúde. As APIs sociais não foram alteradas nem rehomologadas. Os acompanhantes ficaram nas versões acima durante a troca do MCP.

| Destinatário | Classificação / situação | Tickets | Documento |
|---|---|---|---|
| Core 1.93.0 | validação coordenada; contrato atendido, entrega externa pendente | MCP84 / Core430 | [wp-mcp-fator3-0.48.0-impacto-base-site-core-fator3.md](https://chatgpt.com/library?file_id=libfile_fde3_f-2e4d50d107f881918947c6dcbe0813ce_32706b9c47908191baafe72f89b6caee&account_id=personal), revisão 3 |

O contrato recebido `f3base_incidente_publicar_v1` / `incidentes/1` já estava implementado no Core 1.93.0. A cópia isolada do destinatário foi usada sem patch. A ausência do contrato, o retorno ocupado e o restabelecimento foram exercitados. O registro próprio de impacto começou na implementação, após a leitura do encaminhamento recebido; esse limite de rastreabilidade está explicitado no documento.

Não foi identificado outro impacto contratual nos acompanhantes no escopo alterado. A manutenção possui dados, agenda e trava próprios do MCP; o Core continua responsável pelo destino, deduplicação, fila e envio dos incidentes. Sem o Core, as observações aguardam localmente e a retenção própria segue disponível.

## 3. Mudanças e evidência

| Pedido exato | Problema | Implementação | Resultado |
|---|---|---|---|
| 84(a) — incidentes do canal pelo Core430 | Falhas relevantes ficavam apenas no estado local | `ChannelIncidents` observa canal, cron, manutenção, recuperação e OAuth e publica pelo contrato local do Core | WordPress real com Core 1.93.0: aviso, deduplicação, recuperação, contrato ausente e retentativa aprovados; zero chamadas Slack no coletor |
| 84(b) — retenção automática configurável e simulação | Limpeza dependia de intervenção do agente | `AutomaticMaintenance` agenda lotes a cada 15 minutos, com política, revisão, simulação, seleções congeladas e retomada | Cron nativo do Site-Teste processou 100 registros OAuth, 100 resultados de idempotência, 200 backups e 30 cópias SQL na primeira passagem observada |
| 84(c) — sentinela portátil | Carregador MU gravava caminho absoluto de hospedagem | Carregadores de arquivos e banco resolvem `F3_MCP_PRIVATE_DIR` ou `WP_CONTENT_DIR` em cada requisição; carregador antigo é atualizado | WordPress copiado para outra pasta leu o journal sintético do novo acervo; teste independente também cobriu constante externa |
| 84(d) — aviso antes da perda da concessão por inatividade | Refresh expirava após 30 dias sem aviso | Prazo registrado junto à emissão e observado em concessões ativas; concessões existentes derivam o prazo do acervo; renovação real encerra aviso | Emissão e rotação OAuth reais no laboratório, aviso antecipado e recuperação pelo Core aprovados |

A política padrão habilita exclusão; cópias e resultados operacionais são elegíveis após **1 dia/24 horas**; comprovantes OAuth usam 30 dias; auditoria fica preservada (`audit_days:0`); aviso de refresh tem antecedência de 14 dias; tolerância do cron é 3600 segundos. A tela fica em **Ferramentas → Fator3 MCP → Configurar → Arquivos e banco → Manutenção automática**.

Novas habilidades: `system/maintenance-policy`, `system/maintenance-configure` e `system/maintenance-preview`. Todas exigem `manage_options` e a autorização da conexão. A gravação usa revisão corrente; a simulação não exclui o acervo. O padrão totalizou 172 habilidades próprias registradas. Rótulos, descrições e campos da política foram conferidos na edição final.

A exclusão não ignora validade ou dependências. Tokens válidos, validade desconhecida, operações em andamento/incertas, pré-imagens referenciadas e controles de reutilização de refresh de concessões ativas são preservados. Resultados concluídos de idempotência migram transacionalmente para comprovantes mínimos fora da tabela operacional; a mesma chave continua impedida de repetir o efeito. Auditoria com prazo positivo é compactada como registro excluído; os controles mínimos permanecem. Não foi alterado o TTL: acesso de 1 hora e refresh de 30 dias sem renovação.

Cada passagem seleciona até 100 registros por categoria de estado e até 200 cópias. O orçamento de 15 segundos é verificado **entre categorias**; um componente/hash ou uma categoria pode ultrapassar esse orçamento. A primeira passagem remota levou aproximadamente 21 segundos. O fim de um lote não significa esgotamento do acervo: `has_more`, inventário e seleções pendentes orientam continuação. Mudança de critérios enquanto existe lote pendente é recusada até sua conclusão; política inválida pausa exclusões. WP-Cron depende da execução do WordPress ou da agenda da hospedagem.

A portabilidade cobre a localização do acervo. Journals de operações pendentes ainda contêm alvos assinados; devem ser reconciliados antes de migrar um site. Uma constante de diretório externo precisa acompanhar a configuração do novo destino.

## 4. Instalação e prova da troca

O instalador final foi enviado temporariamente ao próprio Site-Teste e instalado por `plugins/upload` com `expected_slug:wp-mcp-fator3`, `expected_sha256` da seção 8, `activate:true`, `overwrite:true`, chave de idempotência e sondas de 30 segundos. A troca final **0.47.0 → 0.48.0** retornou `applied:true`, `recovery_status:applied` e sondas anterior/posterior aprovadas, em PHP novo e sem cache. Operação: `95b9c34cc3c795aed365b5fbcde70434`.

URL raw pública final: **pendente da publicação da frota**. Os ZIPs temporários 0.47.0/0.48.0 foram removidos do Site-Teste após a verificação de hash. O envio temporário não é a publicação raw prevista na regra comum. A frota deve publicar o instalador e relatório finais, conferir os bytes e usar os mesmos parâmetros de identidade na instalação. Fonte permanece com o dono; não houve push nem publicação de código-fonte.

| ID | Ambiente | Cenário | Resultado e evidência | Limite |
|---|---|---|---|---|
| T01 | Laboratório, pacote final | Instalação limpa | 7 verificações aprovadas; `installation-fresh.json` | WordPress descartável |
| T02 | Laboratório, pacote final | Avanço 0.47.0 → 0.48.0 | 10 verificações, opções e conexão preservadas; `installation-migration.json` | Estado sintético |
| T03 | Laboratório | Retenção, OAuth e Core | 27 verificações; `automatic-maintenance.json` | Transporte de e-mail interceptado |
| T04 | Laboratório | Contrato ausente, ocupado, políticas, lotes, replay e autorização | 11 verificações; `adversarial.json` | Falhas controladas |
| T05 | Laboratório | Rótulos, schemas e segurança da projeção | 9 verificações; `presentation.json` | Não mede caixa postal |
| T06 | WordPress HTTP local | Login, nonce, simulação, gravação, conflito e CSRF | 8 verificações; `forms.json` | Sem prova visual do layout |
| T07 | WordPress copiado / runtime independente | Portabilidade da sentinela | `base0470/local/relocation-wordpress.json` e `relocation-*.json` | Motor e carregador sem mudança em 0.48.0; journal de teste |
| T08 | Site-Teste | Troca e contrato final 0.48.0 | `site-teste.json`; PHP 8.3.36, saúde e recuperação aprovadas | Produção não alterada |
| T09 | Site-Teste | Primeira passagem nativa | `base0470/site-teste.json`; execução como usuário 0; contagens também visíveis em 0.48.0 | Passagem ocorreu em 0.47.0; lógica de retenção igual na edição final |
| T10 | Build | Documentação e pacote | 200 verificações documentais; lint de 474 PHP, base verificada e reprodução exata | Lint em PHP 8.4.27 |
| T11 | Laboratório | Salto direto 0.46.0 → 0.48.0 | `installation-direct046.json` | Preservação de estado sintético; sem downgrade |

Os arquivos da coluna de evidência ficam em `evidencias/0480/` no fonte. Os cenários funcionais finais T01–T06 somam **72 verificações sem falha**; T11 e a preparação das bases são adicionais. Falhas de asserção durante a preparação do laboratório foram corrigidas nos testes e repetidas; não são apresentadas como prova aprovada. A restrição de inicialização do Chromium local impediu a prova visual inicial. Na continuação, o navegador remoto permitiu verificar o painel real na largura disponível; as três larguras exigidas continuam pendentes.

Documentação instalada: `system/guide` com `document:release-0480`, 8673 bytes, leitura completa (`has_more:false`), SHA-256 `449e8dec9b8682dabe7f5153df7895b83be3a7c03039bb9e911a9a1b3a04d859`. Os bytes recebidos coincidiram com `docs/RELEASE-0480.md`. Índice, allowlist e paginação existentes foram preservados.

Estado final: MCP 0.48.0 ativo, acompanhantes da seção 2 intactos, saúde `healthy:true`, sentinela `checked`, zero recuperações não resolvidas e agenda automática presente. A primeira passagem retirou 60.414.249 bytes de componentes de backup e 315.512.616 bytes de artefatos SQL. O índice de backups passou de 597 para 397; a tabela operacional de idempotência passou de 2888 para 2789, com novas chamadas ocorrendo durante a medição. A diferença líquida de contagem não é igual ao número de itens processados quando novas operações entram no acervo.

Não foram instaladas fixtures, coletores de e-mail ou ferramentas temporárias no Site-Teste. Journals e pré-imagens das atualizações foram mantidos para rastreabilidade e retenção nativa. Os laboratórios e credenciais descartáveis não integram os ZIPs.

### Continuação da homologação — 18/11/2026, 14:43–14:49 (São Paulo)

Não houve alteração de código, reinstalação ou renumeração. Instalador e fonte conservaram os bytes e hashes da seção 8. Foi relido integralmente o par de documentos centrais na revisão 5; as evidências novas ficam no complemento `wp-mcp-fator3-0.48.0-validacao.zip`, pois o fonte entregue é imutável.

| Verificação | Resultado observado | Alcance |
|---|---|---|
| Saúde e conjunto | MCP 0.48.0, Core 1.93.0 e acompanhantes da seção 2; `healthy:true`; sentinela `checked`; zero recuperações não resolvidas; marcador `active` | Leitura atual do Site-Teste |
| Manutenção nativa | Última passagem concluída às 14:43:27; idempotência: mais 100 registros processados; OAuth e backups: zero elegíveis restantes na seleção observada | Registro do cron, sem execução manual de limpeza nesta continuação |
| Inventário | Backups: 597 na base observada → 12; idempotência: 2888 → 1497 | Queda líquida observada; novas operações continuam entrando, e não se atribui toda variação exclusivamente a uma passagem |
| Simulação no painel real | Botão executado; OAuth 0, resultados de operações 100 com outros lotes, backups 0, cópias SQL 0 | Simulação criou somente seleções privadas; a política manteve a revisão `19c16ad696a41920ce5a27d15926169dc89e288d4d98edd013385b659298ca81`; não foi acionado Salvar |
| Apresentação | Seis campos numéricos com rótulos e ajuda associados; conteúdo legível; largura da janela 1363 px e documento 1348 px | Captura da nova seção; não equivale às capturas a 360, 768 e 1440 px |
| CTOOffice, somente leitura | MCP 0.46.0, Core 1.92.1, WordPress 7.1.5 e PHP 8.3.36; idempotência 892, backups 428; exclusão automática desabilitada | A combinação de destino ainda não foi instalada; medição de um dia permanece pendente |

A fila do Core apresentou alternância repetida de `canal_indisponivel` para o recurso de registro WordPress, apesar de as leituras atuais do canal estarem saudáveis. A leitura da fila às 14:45 continha 17 transições, desde 10:45:07, com a última abertura às 14:45:04. O primeiro episódio antecede a instalação MCP 0.47.0 às 11:23; isso não prova a causa nem exclui participação do MCP. Os diagnósticos locais em bootstrap anônimo, `DOING_CRON` e WP-CLI retornaram registro presente e erros vazios; não reproduziram a alternância remota. A frequência sugere investigar o contexto de execução dos observadores, hipótese ainda não demonstrada. Esse achado permanece aberto no impacto Core, revisão 3. Não houve descarte ou reconciliação artificial da fila.

A configuração de destino técnico continuou ausente. Nenhum aviso foi enviado por esta continuação. A simulação e os diagnósticos não comprovam entrega em caixa postal. As seleções privadas criadas pela simulação ficam sujeitas à retenção normal; nenhuma fixture de teste foi instalada no site.

## 5. Banco, migração e correção por nova versão

O esquema SQL continua na versão 2. Novos registros usam os mecanismos existentes: opção `f3_mcp_automatic_maintenance`; buckets de agenda/última passagem, observações e comprovantes mínimos; `last_refresh_at` e `refresh_expires_at` em concessões. As tabelas de outros provedores não são modificadas pelo MCP. A desativação limpa o próprio evento recorrente; a regra de preservação de dados na desinstalação continua válida e a opção nova integra o inventário de propriedade.

A movimentação dos resultados de idempotência grava o comprovante e retira a linha operacional na mesma transação. Seleções de arquivos são revalidadas, componentes passam por quarentena e os comprovantes de progresso permitem retomada. Os dados de autenticação ativos não são descartados pela migração. Efeitos externos de operações anteriores não são revertidos por uma troca de plugin.

Não há downgrade recomendado nem migração reversa. Uma correção posterior à instalação ou entrega final exige nova versão. A edição 0.47.0 instalada durante esta rodada permaneceu imutável, e a correção de apresentação recebeu 0.48.0.

## 6. O que permanece pendente

- **E-mail externo — frota/dono do destino:** o Core do Site-Teste retornou `destino_configurado:false`. Incidentes foram aceitos e aguardam destino. O coletor local provou o caminho Core → `wp_mail`, deduplicação e recuperação, com zero Slack; não comprovou recebimento em caixa postal. Configurar destino técnico autorizado e verificar entrega e recebimento separadamente.
- **CTOOffice por um dia — frota:** instalar a edição final com hash, registrar contagens antes/depois e confirmar execução de cron sem depender de um agente. CTOOffice não foi modificado nesta rodada. A queda imediata no Site-Teste não substitui a medição de um dia em produção.
- **Publicação raw — frota:** publicar somente instalador e relatório no fluxo previsto e remover a versão anterior de `main` quando fizer a troca; não houve publicação nesta tarefa.
- **Revisão visual — revisor:** a continuação verificou a nova seção e executou a simulação no painel real, com captura na janela de 1363 px. Permanecem pendentes as capturas a 360, 768 e 1440 px: o Chromium local não inicia por restrição de socket, e a API disponível do navegador remoto não expõe redimensionamento da janela. A prova atual não encerra essa matriz.
- **Alternância de avisos — MCP/Core/frota:** investigar as transições de `canal_indisponivel` em conjunto com os horários e o contexto do cron. Não foi reproduzida localmente nem comprovada uma indisponibilidade externa. Ao configurar destino, considerar a fila já acumulada; não apagar nem marcar mensagens como entregues sem prova.
- **Registro preliminar de impacto:** o contrato foi avaliado a partir do impacto recebido, mas o documento próprio foi aberto na implementação. Não se declara cumprimento retroativo da exigência de emissão própria na etapa de planejamento.

## 7. Credenciais e configuração do dono

Não são exigidas novas credenciais para a manutenção. Ajuste a política na tela indicada na seção 3 ou use as três habilidades administrativas. Para os avisos, configure o e-mail técnico no **Fator3 Site Core → Conexões → Avisos técnicos**; a fila é consultável por `f3base/incidentes-tecnicos-ler`. Não se utiliza o canal de contatos nem Slack.

O aviso de refresh exige ação do operador/cliente autorizado antes da expiração. O plugin não renova a credencial artificialmente. Nenhum token, senha de aplicação, cookie, chave privada ou segredo de assinatura está presente neste relatório ou nos artefatos de entrega. As chaves existentes do WordPress devem ser preservadas ao copiar o site para que os journals continuem verificáveis.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | [wp-mcp-fator3-0.48.0-instalador.zip](https://chatgpt.com/library?file_id=libfile_fde3_f-fc275081e51081919663deb489a53ebf_32706b9c47908191baafe72f89b6caee&account_id=personal) | 963457 | `3ace23b8e4405d0444048fcbddd51479ee63dee3c49d4373760151ef8b67d28f` |
| Fonte | [wp-mcp-fator3-0.48.0-fonte.zip](https://chatgpt.com/library?file_id=libfile_fde3_f-dad34873e9088191bb1fbc3b1149161f_32706b9c47908191baafe72f89b6caee&account_id=personal) | 3439360 | `c3db766e32f22fce1c0b263f4488083cc546562c3f1f56945cb9c4c8547413d9` |

Complemento: [wp-mcp-fator3-0.48.0-impacto-base-site-core-fator3.md](https://chatgpt.com/library?file_id=libfile_fde3_f-2e4d50d107f881918947c6dcbe0813ce_32706b9c47908191baafe72f89b6caee&account_id=personal), revisão 3. Os links para os quatro arquivos acompanham a entrega. Este é o relatório externo canônico. A cópia no ZIP fonte foi feita antes do fechamento e identifica essa condição; o tamanho e hash do próprio ZIP só são preenchidos neste relatório externo após o empacotamento.

Histórico documental: entrega inicial implementou MCP84; revisão 2 acrescenta a continuação nativa na 0.48.0, simulação e captura do painel, leitura de CTOOffice e pendência de diagnóstico dos avisos. A cópia interna congelada permanece anterior ao fechamento. Complemento de evidências: `wp-mcp-fator3-0.48.0-validacao.zip`.
Complemento: 79528 bytes, SHA-256 `3ca621e161307365760952b74b017cc7532e205eaeddfd1a1ea653ef100f69dc`. Contém observações sanitizadas, captura da simulação e checklist da continuação.
