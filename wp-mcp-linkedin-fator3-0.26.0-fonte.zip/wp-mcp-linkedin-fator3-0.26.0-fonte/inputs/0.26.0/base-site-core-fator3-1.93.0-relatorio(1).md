# Entrega — Fator3 Site Core 1.93.0

Revisão 1 · 18/11/2026 · Implementação dos pedidos Core 423(g), 429 e 430.
Status **com-pendencias**. A 1.93.0 está ativa no Site-Teste, com zero falhas de atualização. O aceite em produção e a entrega na caixa de e-mail dependem da frota. O impacto para Google identifica uma observação que a versão atual daquele produtor descarta.

## 1. De onde esta versão entra

Instalação limpa ou atualização direta do Core 1.92.1 para a 1.93.0. Slug e pasta `base-site-core-fator3`. A base veio dos ZIPs oficiais validados pelos digests do relatório 1.92.1. SHA-256 do instalador-base `1276d416b79a6f7ac2b0b7d87284aa150a71f9058836467d6886282d12f4a099`. O trabalho retomou a árvore, o instalador candidato e o ensaio da rodada interrompida. O candidato foi ajustado antes da primeira instalação da versão.

WordPress mínimo 7.1.4 e PHP mínimo 8.3 de 64 bits. Teste compartilhado em WordPress 7.1.4 / PHP 8.3.36. Laboratório WordPress 7.1.4 / PHP 8.4.27 / MariaDB 11.8.6. Documentos centrais do projeto lidos integralmente, ambos revisão 5 de 02/11/2026. Também conferidos a regra comum, o padrão do Site Core e a pauta de 18/11.

## 2. Convivência e encaminhamentos

Contrato administrativo **8.45.0**. Perfil `piso-padrao-3.6`, 104 opções no catálogo de configuração e 199 operações de domínio registradas no laboratório. Entram `f3base/incidentes-tecnicos-ler` e `f3base/incidente-entrega-reconciliar`. As duas exigem acesso administrativo. O plugin Meta 0.28.0, LinkedIn 0.25.0, Google 0.36.0, Pipedrive 0.11.1, MCP 0.46.0 e WP Activity Log 5.7.0 compõem o conjunto de teste. O Implantador não participa dos três fluxos alterados.

| Destinatário | Natureza | Documento individual |
|---|---|---|
| Canal MCP | Validação coordenada | [base-site-core-fator3-1.93.0-impacto-wp-mcp-fator3.md](base-site-core-fator3-1.93.0-impacto-wp-mcp-fator3.md) |
| Google | Ação necessária | [base-site-core-fator3-1.93.0-impacto-wp-mcp-google-fator3.md](base-site-core-fator3-1.93.0-impacto-wp-mcp-google-fator3.md) |
| LinkedIn | Validação coordenada | [base-site-core-fator3-1.93.0-impacto-wp-mcp-linkedin-fator3.md](base-site-core-fator3-1.93.0-impacto-wp-mcp-linkedin-fator3.md) |
| Meta | Validação coordenada | [base-site-core-fator3-1.93.0-impacto-wp-mcp-meta-fator3.md](base-site-core-fator3-1.93.0-impacto-wp-mcp-meta-fator3.md) |
| Pipedrive | Validação coordenada | [base-site-core-fator3-1.93.0-impacto-wp-mcp-pipedrive-fator3.md](base-site-core-fator3-1.93.0-impacto-wp-mcp-pipedrive-fator3.md) |

Revisão 2 dos encaminhamentos de entrega. Planejamento original em `reference/430/plano.md`. Os adaptadores do Core observam os estados publicados pelas versões examinadas. Com um pacote ausente, os demais produtores e o contrato local continuam disponíveis. O Core deve estar ativo e o destino preenchido para assumir os avisos.

**Google.** O vencimento de uma prova e sua renovação são verificados diretamente. Em outra trilha, com `google/alerts` desligado, a 0.36.0 retorna de `Alerts::observe()` antes de registrar ocorrências como `cron_late`. A cópia experimental emitiu uma abertura e uma recuperação usando o contrato já entregue. Reprodução, patch e resultado ficam no impacto e no fonte. A incorporação oficial cabe ao mantenedor do Google.

## 3. Mudanças e evidência

| Pedido | Implementação | Evidência |
|---|---|---|
| Core 423(g) | Após a gravação condicional do cron, o Core invalida cron, alloptions e notoptions antes dos observadores e novamente em finally depois dos callbacks. O histórico da passagem registra `dados.gravacoes_proprias_cron` para escritas confirmadas. Uma passagem histórica anterior à instrumentação pode não conter o campo. | No WP-CLI do laboratório, com o sensor ativo e cache deliberadamente defasado, 12 ganchos Core e quatro nativos executaram uma vez cada. Houve 24 escritas próprias, zero divergências de cache e zero remanescentes entre os 16 ganchos da prova. No ensaio isolado do histórico, o contador gravado foi 24. |
| Core 429 | Entre linhas divergentes do mesmo Model, a grafia do produto na própria fonte prevalece sobre marca isolada, rótulo genérico ou codinome que perde a variante. O índice continua local e recompilável. | Comparação das três versões nos 44.528 códigos. Os 19 nomes abaixo coincidem com a grafia da 1.91.0. As outras 272 diferenças de nome entre 1.91.0 e 1.92.1 foram preservadas, cobrindo o conjunto de 165 melhorias referido pela frota. |
| Core 430 | Central local de incidentes por pacote, código e recurso. Reserva antes do envio, fila para destino vazio, recuperação, resumo diário opcional, reconciliação administrativa e auditoria do resultado. Os avisos técnicos usam e-mail, inclusive no monitoramento Meta e nos e-mails nativos de atualização e recuperação. | No Site-Teste foram capturadas 14 mensagens de teste, zero chamadas HTTP externas, um destino e os três filtros nativos com o destinatário correto. No laboratório, o worker real da Meta e o cron geraram as quatro transições esperadas para os dois recursos. Exercitados ausência do endereço, recusa, envio incerto, reconciliação, repetição, permissão e resumo diário. |

### Comparação do catálogo

| Model | 1.91.0 | 1.92.1 | 1.93.0 |
|---|---|---|---|
| anexa android tv | ANEXA Android TV | Smart TV | ANEXA Android TV |
| blaupunkt 4k android tv | BLAUPUNKT 4K Android TV | Blaupunkt | BLAUPUNKT 4K Android TV |
| blaupunkt smart tv | BLAUPUNKT SMART TV | BLAUPUNKT | BLAUPUNKT SMART TV |
| cobia 2k android tv | Cobia 2K Android TV | Cobia | Cobia 2K Android TV |
| col 2k smart tv | COL 2K SMART TV | Hyundai | COL 2K SMART TV |
| epic android tv | EPIC Android TV | martin | EPIC Android TV |
| jvc 2k android tv | JVC 2K Android TV | JVC | JVC 2K Android TV |
| jvc 4k android tv | JVC 4K Android TV | JVC | JVC 4K Android TV |
| ok 4k android tv | OK 4K Android TV | OK | OK 4K Android TV |
| qbell 2k android tv | Qbell 2K Android TV | QBELL | Qbell 2K Android TV |
| qbell 4k android tv | Qbell 4K Android TV | QBELL | Qbell 4K Android TV |
| rca 4k smart tv | RCA 4K SMART TV | RCA | RCA 4K SMART TV |
| schneider 2k android tv | Schneider 2K Android TV | SCHNEIDER | Schneider 2K Android TV |
| svision 2k android tv | SVISION 2K Android TV | SVISION | SVISION 2K Android TV |
| svision 4k android tv | SVISION 4K Android TV | SVISION | SVISION 4K Android TV |
| tesla 4k android tv | Tesla 4K Android TV | TESLA | Tesla 4K Android TV |
| walton android tv | WALTON Android TV | EXPRESS | WALTON Android TV |
| zephir 2k android tv | Zephir 2K Android TV | ZEPHIR | Zephir 2K Android TV |
| zephir 4k android tv | Zephir 4K Android TV | ZEPHIR | Zephir 4K Android TV |

O critério geral corrigiu outros dez nomes que já apareciam abreviados tanto na 1.91.0 quanto na 1.92.1.

| Model | 1.92.1 | 1.93.0 |
|---|---|---|
| 2k pa smart tv | Smart TV | 2K PA Smart TV |
| atv r2 | Android TV | ATV R2 |
| htc one | One | HTC One |
| insignia delta 2 | Timovi | Insignia Delta 2 |
| io 3d | dingo | IO 3D |
| tadaam box | Tadaam | TADAAM Box |
| versity 9540 | Versity | Versity 9540 |
| versity 9553 | Versity | Versity 9553 |
| versity 9640 | Versity | Versity 9640 |
| versity 9653 | Versity | Versity 9653 |

A auditoria confrontou os 256 fragmentos com o CSV Google Play de 15/11, verificou 312 famílias e repetiu os 412 casos do pedido 428. Conservados os nomes de Motorola One Macro e as fichas brasileiras usadas nos testes. Referência dos dados `2026-11-18.1`. O gerador atualizado reproduziu os arquivos do instalador já fechado.

## 4. Instalação e prova da troca

O Site-Teste recebeu os bytes com `plugins/upload-base64` a partir do arquivo temporário de homologação, `expected_slug=base-site-core-fator3` e SHA-256 da seção 8. Sondas antes e depois aprovadas. `f3base/como-usar` com `compacto=true` confirmou 1.93.0, estado `concluida`, zero falhas e confirmação no executor em 18/11/2026 às 10:36:29, horário de Brasília.

| Verificação | Resultado |
|---|---|
| Instalação limpa e atualização direta | Dois bancos descartáveis, Plugin_Upgrader com o ZIP final e releitura em processos novos. Ambos os ciclos concluídos em 20 etapas, sem falhas. E-mail e atraso pré-existentes preservados. |
| Sintaxe e conteúdo | 611 arquivos PHP passaram no lint local e no analisador PHP 8.3.36 do site. Os 1.274 arquivos do ZIP coincidem com o runtime do fonte, com CRC e SHA-256 conferidos. |
| Documentação via MCP | Descoberta pelo índice, leitura de `docs/RELEASE-1.93.0.md` em três páginas, 35 linhas, hash estável igual ao arquivo do instalador. SHA-256 `64715d1f335922c14d6e53fdf9e15432434dbb6ba455e9ff8e707e01ef7a1d13`. |
| Autorização | No WordPress local, o visitante recebeu `ability_invalid_permissions` nas duas novas operações. Também testada a recusa do callback administrativo e de reserva obsoleta na reconciliação. |
| Destino e transporte | A configuração efetiva do Site-Teste continuou com e-mail vazio. Os coletores usaram endereço sintético e impediram tráfego externo. As duas novas configurações retornaram 14 dias e resumo desativado. |
| CLI compartilhada e limpeza | Em 18/11 às 10h45 (Brasília), a passagem real WP-CLI executou o ensaio isolado antes do histórico da passagem. O ensaio mediu 24 escritas e 16 ganchos executados uma vez, com zero remanescentes. Na sequência, o registro normal da mesma invocação terminou às 10h45min15s com 20 escritas próprias. A opção do ensaio foi apagada. A releitura confirmou a remoção do MU-plugin e a ausência do ZIP temporário. As sondas de página inicial e REST passaram após a limpeza. |

Na distribuição da frota, verificar os bytes no [raw previsto para o instalador](https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/base-site-core-fator3-1.93.0-instalador.zip) e usar `plugins/upload` com hash e slug esperados. A publicação desse endereço cabe à frota. A homologação do Site-Teste não instala o Core em produção.

## 5. Banco, migração e correção por nova versão

O contador usa o campo JSON já existente em `f3base_execucoes`. A central cria opções sob `f3base_incidente_v1_` com chave derivada de pacote, código e referência protegida. Não há nova tabela. Os incidentes usam trava por recurso, mantêm a ordem das transições e guardam o resultado do transporte. Uma reserva sem confirmação exige verificar o SMTP e informar a decisão em `f3base/incidente-entrega-reconciliar`. O conteúdo da mensagem de recuperação fatal e sua chave não vão para a central. A migração acrescenta os padrões aos valores existentes. Correção após instalação exige nova versão.

## 6. O que permanece pendente

- **Frota, pedido 423(g).** A janela iniciada em 17/11 já apresentou erros na versão anterior. Para aceitar a correção, verificar nas três instalações CTO Office, Korvena e Fator3 uma nova janela de 24 horas com contagem explícita de erros, e passagens CLI com ao menos dez ganchos Core seguidos de ganchos nativos. Conferir duplicação e consumo sem execução por ocorrência. A bancada demonstra o reparo sob divergência induzida de cache. Atribuir todos os erros históricos à mesma causa exigiria rastros adicionais.
- **Frota e responsável pelo e-mail.** Preencher o destino técnico autorizado em cada instalação e conferir recebimento real na caixa. Com destino vazio os novos incidentes aguardam no WordPress. Em e-mails nativos já gerados, a central guarda a ocorrência de falta de destino. A chave de recuperação fatal precisa de nova emissão pelo WordPress. É necessária execução de WordPress para observar e enviar avisos.
- **Google.** Aceitar ou incorporar o patch para ocorrências que o produtor deixa de registrar quando sua automação interna está desligada. As demais leituras implementadas no Core já estão disponíveis.
- **Contas externas.** Renovação real de credenciais, indisponibilidade real de provedor e incidentes comerciais não foram provocados. A prova de e-mail termina no coletor, antes do SMTP.

## 7. Credenciais e configuração do dono

Nenhuma nova credencial. No painel Site Core, abrir Avisos técnicos por e-mail e preencher `f3base_avisos_tecnicos.email`. Confirmar por releitura. `antecedencia_dias` aceita 1 a 365 dias, padrão 14. `resumo_diario` começa desativado. Token e refresh do LinkedIn são avaliados separadamente. A CAPI consulta o calendário da versão Graph efetiva quando a validade é conhecida. Referência usada para a versão v21.0 em [calendário público da Meta](https://developers.facebook.com/docs/graph-api/changelog/versions/).

## 8. Identidade dos arquivos

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| [base-site-core-fator3-1.93.0-instalador.zip](base-site-core-fator3-1.93.0-instalador.zip) | 5664727 | `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8` |
| [base-site-core-fator3-1.93.0-fonte.zip](base-site-core-fator3-1.93.0-fonte.zip) | 8012978 | `ee9d636c62774935a66b417653a2f1c0ff498fdf8e3df2e2d5a1e44e82bb1d65` |

Relatório externo canônico. O fonte contém a cópia anterior ao fechamento.
