<?php
/**
 * Autoteste — roda as travas do PathGuard contra o servidor real.
 *
 * Uma suíte que passa na máquina de desenvolvimento não prova nada sobre o
 * servidor de produção: `realpath()` se comporta diferente com `open_basedir`,
 * symlink pode estar desabilitado, e — o caso mais traiçoeiro — se
 * `token_get_all()` com `TOKEN_PARSE` não lançar `ParseError` naquele build do
 * PHP, a checagem de sintaxe passa a aprovar qualquer coisa **em silêncio**.
 *
 * Por isso o autoteste existe: ele afirma o modelo de segurança no ambiente
 * onde ele realmente precisa valer, sem abrir execução de código arbitrário.
 * Os casos são fixos e escritos aqui; nada vem da chamada.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class SelfTest {

	/**
	 * Executa a bateria e devolve o relatório.
	 *
	 * @return array<string,mixed>
	 */
	public static function run(): array {
		$checks = array();

		$checks = array_merge( $checks, self::check_environment() );
		$checks = array_merge( $checks, self::check_paths() );
		$checks = array_merge( $checks, self::check_extensions() );
		$checks = array_merge( $checks, self::check_syntax_guard() );
		$checks = array_merge( $checks, self::check_writability() );
		$checks = array_merge( $checks, self::check_sql_guard() );

		$passed = 0;
		$failed = 0;
		foreach ( $checks as $check ) {
			if ( $check['ok'] ) {
				++$passed;
			} else {
				++$failed;
			}
		}

		return array(
			'success'  => 0 === $failed,
			'passed'   => $passed,
			'failed'   => $failed,
			'checks'   => $checks,
			'message'  => 0 === $failed
				? sprintf(
					/* translators: %d: número de verificações. */
					esc_html__( 'As %d verificações passaram neste servidor.', 'wp-mcp-fator3' ),
					$passed
				)
				: sprintf(
					/* translators: 1: falhas, 2: total. */
					esc_html__( 'ATENÇÃO: %1$d de %2$d verificações falharam neste servidor. Veja a lista.', 'wp-mcp-fator3' ),
					$failed,
					$passed + $failed
				),
		);
	}

	private static function row( string $name, bool $ok, string $detail = '' ): array {
		return array(
			'check'  => $name,
			'ok'     => $ok,
			'detail' => $detail,
		);
	}

	/** Contexto: versões, raízes efetivas, constantes que fecham o canal. */
	private static function check_environment(): array {
		$roots = PathGuard::roots();

		return array(
			// Pré-requisito de tudo: sem a Abilities API nenhuma rota existe, e
			// a falha é silenciosa (o hook nunca dispara, ninguém reclama).
			self::row(
				'abilities_api_disponivel',
				function_exists( 'wp_register_ability' ),
				function_exists( 'wp_register_ability' ) ? 'sim' : 'NÃO — nenhuma rota registrada'
			),
			self::row( 'wordpress_version', true, get_bloginfo( 'version' ) ),
			self::row( 'php_version', version_compare( PHP_VERSION, '7.4', '>=' ), PHP_VERSION ),
			self::row( 'roots_configuradas', count( $roots ) > 0, implode( ' | ', $roots ) ),
			self::row(
				'realpath_funciona',
				false !== realpath( ABSPATH ),
				'ABSPATH => ' . var_export( realpath( ABSPATH ), true )
			),
			self::row(
				'open_basedir',
				true,
				'' === (string) ini_get( 'open_basedir' )
					? 'não definido'
					: 'definido: ' . (string) ini_get( 'open_basedir' )
			),
			self::row( 'canal_aberto', PathGuard::is_enabled(), PathGuard::is_enabled() ? 'sim' : 'não' ),
		);
	}

	/** Os vetores de caminho, contra o sistema de arquivos de verdade. */
	private static function check_paths(): array {
		$deny = array(
			'traversal_wp_config'   => 'wp-content/themes/../../wp-config.php',
			'traversal_etc_passwd'  => 'wp-content/themes/../../../../../../etc/passwd',
			'traversal_no_inicio'   => '../../../etc/passwd',
			'absoluto_unix'         => '/etc/passwd',
			'wp_config'             => 'wp-config.php',
			'htaccess_raiz'         => '.htaccess',
			'wp_settings'           => 'wp-settings.php',
			'core_wp_admin'         => 'wp-admin/admin.php',
			'core_wp_includes'      => 'wp-includes/version.php',
			'wrapper_php_filter'    => 'php://filter/resource=wp-config.php',
			'wrapper_phar'          => 'phar://x.phar/y.php',
			'null_byte'             => "wp-content/themes/x.css\0.php",
			'vazio'                 => '',
		);

		$rows = array();
		foreach ( $deny as $name => $path ) {
			$result = PathGuard::resolve( $path, false );
			$rows[] = self::row(
				'nega:' . $name,
				is_wp_error( $result ),
				is_wp_error( $result ) ? $result->get_error_code() : 'PASSOU INDEVIDAMENTE: ' . $result
			);
		}

		// Escrita em uploads — o vetor que vira backdoor se falhar.
		$uploads = wp_get_upload_dir();
		if ( ! empty( $uploads['basedir'] ) ) {
			$relative = PathGuard::to_relative( wp_normalize_path( $uploads['basedir'] ) ) . '/f3-teste.php';
			$result   = PathGuard::resolve( $relative, true );
			$rows[]   = self::row(
				'nega:escrita_em_uploads',
				is_wp_error( $result ),
				is_wp_error( $result ) ? $result->get_error_code() : 'PASSOU INDEVIDAMENTE: ' . $result
			);
		}

		// Autoproteção: o plugin não se edita.
		if ( defined( 'F3_MCP_FILES_DIR' ) ) {
			$self   = PathGuard::to_relative( wp_normalize_path( F3_MCP_FILES_DIR ) ) . '/includes/PathGuard.php';
			$result = PathGuard::resolve( $self, false );
			$rows[] = self::row(
				'nega:auto_edicao',
				is_wp_error( $result ),
				is_wp_error( $result ) ? $result->get_error_code() : 'PASSOU INDEVIDAMENTE'
			);
		}

		// Ataque de prefixo: uma pasta irmã cujo nome começa igual à raiz.
		$theme_root = untrailingslashit( wp_normalize_path( get_theme_root() ) );
		$sibling    = PathGuard::to_relative( $theme_root ) . '-f3-prefixo/x.php';
		$result     = PathGuard::resolve( $sibling, true );
		$rows[]     = self::row(
			'nega:ataque_de_prefixo',
			is_wp_error( $result ),
			is_wp_error( $result ) ? $result->get_error_code() : 'PASSOU INDEVIDAMENTE'
		);

		// O caminho legítimo precisa continuar funcionando — uma trava que
		// nega tudo "passaria" nos testes acima sem servir para nada.
		$theme  = get_stylesheet();
		$legit  = PathGuard::to_relative( $theme_root ) . '/' . $theme . '/style.css';
		$result = PathGuard::resolve( $legit, false );
		$rows[] = self::row(
			'aceita:style_css_do_tema_ativo',
			! is_wp_error( $result ),
			is_wp_error( $result ) ? $result->get_error_code() . ' (' . $legit . ')' : $legit
		);

		// Arquivo novo dentro do diretório de plugins, com extensão que a
		// allowlist antiga recusava. É o caso que a versão 0.8.0 promete.
		if ( defined( 'WP_PLUGIN_DIR' ) ) {
			$em_plugin = PathGuard::to_relative( wp_normalize_path( WP_PLUGIN_DIR ) ) . '/f3-teste-dados.tsv';
			$result    = PathGuard::resolve( $em_plugin, true );
			$rows[]    = self::row(
				'aceita:arquivo_tsv_em_plugins',
				! is_wp_error( $result ),
				is_wp_error( $result ) ? $result->get_error_code() . ' (' . $em_plugin . ')' : $em_plugin
			);
		}

		return $rows;
	}

	/**
	 * A política de extensões está aberta, como esperado?
	 *
	 * Desde a versão 0.8.0 a extensão não é mais o que contém o canal — a pasta
	 * é. Estes casos afirmam isso: formatos que a allowlist antiga recusava
	 * (`.tsv`, `.mo`, `.sql`) e arquivo sem extensão precisam passar, porque
	 * são arquivos normais de tema e de plugin.
	 */
	private static function check_extensions(): array {
		$rows = array();

		foreach ( array( 'php', 'css', 'png', 'woff2', 'tsv', 'mo', 'sql', 'map', 'lock' ) as $ext ) {
			$ok     = ( true === PathGuard::check_extension( '/x/arquivo.' . $ext ) );
			$rows[] = self::row( 'aceita_ext:' . $ext, $ok );
		}

		$rows[] = self::row(
			'aceita_sem_extensao:LICENSE',
			true === PathGuard::check_extension( '/x/LICENSE' )
		);

		// Um filtro ainda consegue voltar a restringir, se o site quiser.
		$restringe = static function () {
			return array( 'css' );
		};
		add_filter( 'f3_mcp_files_allowed_extensions', $restringe );
		$rows[] = self::row(
			'filtro_restringe_extensao',
			is_wp_error( PathGuard::check_extension( '/x/arquivo.php' ) )
				&& true === PathGuard::check_extension( '/x/arquivo.css' )
		);
		remove_filter( 'f3_mcp_files_allowed_extensions', $restringe );

		// O que de fato bloqueia é o nome protegido e a pasta — não a extensão.
		$rows[] = self::row(
			'nega_nome_protegido:.env',
			is_wp_error( PathGuard::resolve( 'wp-content/themes/.env', false ) )
		);

		return $rows;
	}

	/**
	 * A checagem de sintaxe funciona NESTE build do PHP?
	 *
	 * A falha aqui é silenciosa por natureza: se TOKEN_PARSE não lançar,
	 * `check_php_syntax()` devolve true para código quebrado e a trava some
	 * sem avisar. É a verificação mais importante da bateria.
	 */
	private static function check_syntax_guard(): array {
		$rows = array();

		$rows[] = self::row(
			'token_get_all_disponivel',
			function_exists( 'token_get_all' ) && defined( 'TOKEN_PARSE' ),
			function_exists( 'token_get_all' ) ? 'sim' : 'NÃO — a checagem de sintaxe está inerte'
		);

		$quebrado = PathGuard::check_php_syntax( "<?php\nfunction x() { return 1;\n" );
		$rows[]   = self::row(
			'detecta_php_quebrado',
			is_wp_error( $quebrado ),
			is_wp_error( $quebrado )
				? 'ok'
				: 'FALHA CRÍTICA: PHP inválido seria gravado sem aviso'
		);

		$valido = PathGuard::check_php_syntax( "<?php\nfunction x() { return 1; }\n" );
		$rows[] = self::row( 'aceita_php_valido', true === $valido );

		return $rows;
	}

	/**
	 * O guardião de SQL está de pé neste servidor?
	 *
	 * Estas checagens não tocam o banco: exercitam a validação, que é onde
	 * mora o risco. Um statement que passasse aqui indevidamente seria
	 * executado de verdade depois.
	 */
	private static function check_sql_guard(): array {
		$rows = array();

		$deve_negar = array(
			'sql:stacked'        => array( 'select', 'SELECT 1; DROP TABLE wp_posts' ),
			'sql:update_em_read' => array( 'select', 'UPDATE wp_posts SET post_title = "x" WHERE ID=1' ),
			'sql:into_outfile'   => array( 'select', "SELECT 1 INTO OUTFILE '/tmp/x'" ),
			'sql:load_file'      => array( 'select', "SELECT LOAD_FILE('/etc/passwd')" ),
			'sql:drop'           => array( 'write', 'DROP TABLE wp_posts' ),
			'sql:truncate'       => array( 'write', 'TRUNCATE TABLE wp_posts' ),
			'sql:alter'          => array( 'write', 'ALTER TABLE wp_posts ADD COLUMN x INT' ),
			'sql:update_sem_where' => array( 'write', "UPDATE wp_posts SET post_content=''" ),
			'sql:delete_sem_where' => array( 'write', 'DELETE FROM wp_posts' ),
			'sql:select_em_write'  => array( 'write', 'SELECT * FROM wp_posts' ),
		);

		foreach ( $deve_negar as $name => $case ) {
			$result = ( 'select' === $case[0] )
				? SqlGuard::validate_select( $case[1] )
				: SqlGuard::validate_write( $case[1] );

			$rows[] = self::row(
				'nega:' . $name,
				is_wp_error( $result ),
				is_wp_error( $result ) ? $result->get_error_code() : 'PASSOU INDEVIDAMENTE'
			);
		}

		// O caminho legítimo precisa continuar funcionando.
		$rows[] = self::row(
			'aceita:sql_select_simples',
			! is_wp_error( SqlGuard::validate_select( 'SELECT ID FROM ' . $GLOBALS['wpdb']->posts . ' LIMIT 1' ) )
		);
		$rows[] = self::row(
			'aceita:sql_update_com_where',
			! is_wp_error( SqlGuard::validate_write( 'UPDATE ' . $GLOBALS['wpdb']->posts . " SET post_status='draft' WHERE ID=0" ) )
		);

		// O scanner respeita literais? É a base de tudo acima.
		$scan   = SqlGuard::scan( "SELECT 'a;b' FROM t" );
		$rows[] = self::row( 'sql:scanner_respeita_string', 1 === $scan['statements'], 'statements=' . $scan['statements'] );

		// A redação de senha funciona?
		$red    = SqlGuard::redact( array( array( 'user_pass' => 'hash-secreto' ) ) );
		$rows[] = self::row( 'sql:redige_hash_de_senha', '[redigido]' === $red['rows'][0]['user_pass'] );

		$rows[] = self::row(
			'sql:escrita_no_banco',
			true,
			Database::writes_enabled() ? 'LIGADA' : 'desligada'
		);

		return $rows;
	}

	/** As pastas são graváveis e o diretório de backups fica protegido? */
	private static function check_writability(): array {
		$rows = array();

		foreach ( PathGuard::roots() as $root ) {
			$rows[] = self::row(
				'gravavel:' . basename( $root ),
				is_writable( $root ),
				is_writable( $root ) ? 'sim' : 'não — as gravações vão falhar'
			);
		}

		$dir = PathGuard::backup_dir();
		if ( is_wp_error( $dir ) ) {
			$rows[] = self::row( 'backup_dir', false, $dir->get_error_message() );
			return $rows;
		}

		$rows[] = self::row( 'backup_dir_existe', is_dir( $dir ), $dir );
		$rows[] = self::row( 'backup_dir_htaccess', is_file( $dir . '/.htaccess' ) );
		$rows[] = self::row( 'backup_dir_index', is_file( $dir . '/index.php' ) );

		// Ida e volta real no disco, dentro da nossa própria pasta.
		$probe = $dir . '/.selftest-' . bin2hex( random_bytes( 6 ) ) . '.tmp';
		$wrote = ( false !== file_put_contents( $probe, 'f3-selftest' ) );
		$read  = $wrote ? file_get_contents( $probe ) : false;
		if ( is_file( $probe ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			@unlink( $probe );
		}
		$rows[] = self::row( 'escrita_leitura_remocao', $wrote && 'f3-selftest' === $read && ! is_file( $probe ) );

		return $rows;
	}
}
