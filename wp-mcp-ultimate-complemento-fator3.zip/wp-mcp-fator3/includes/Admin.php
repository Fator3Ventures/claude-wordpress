<?php
/**
 * Tela de administração — Ferramentas > MCP Fator3.
 *
 * O canal já vem ligado ao ativar o plugin; esta tela existe para o que é
 * realmente útil no dia a dia: desligar rápido, ver o que foi gravado e
 * conferir a configuração efetiva sem abrir o código.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class Admin {

	private const SLUG  = 'wp-mcp-fator3';
	private const NONCE = 'f3_mcp_files_toggle';

	public static function init(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );
		add_action( 'admin_post_f3_mcp_files_toggle', array( self::class, 'handle_toggle' ) );
		add_action( 'admin_post_f3_mcp_db_toggle', array( self::class, 'handle_db_toggle' ) );
	}

	/** Liga/desliga apenas a ESCRITA no banco; a leitura segue o canal geral. */
	public static function handle_db_toggle(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'wp-mcp-fator3' ) );
		}

		check_admin_referer( 'f3_mcp_db_toggle' );

		$enable = isset( $_POST['enable'] ) && '1' === $_POST['enable'];
		update_option( Database::OPTION_WRITES, $enable, true );
		PathGuard::audit( $enable ? 'db:writes-on' : 'db:writes-off', '-' );

		wp_safe_redirect( add_query_arg( array( 'page' => self::SLUG, 'f3_status' => 'ok' ), admin_url( 'tools.php' ) ) );
		exit;
	}

	public static function menu(): void {
		add_management_page(
			__( 'WP MCP Fator3', 'wp-mcp-fator3' ),
			__( 'MCP Fator3', 'wp-mcp-fator3' ),
			'manage_options',
			self::SLUG,
			array( self::class, 'render' )
		);
	}

	/** Um filtro em código está forçando o estado, ignorando a opção? */
	public static function forced_by_filter(): bool {
		return has_filter( 'f3_mcp_files_enabled' );
	}

	public static function handle_toggle(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'wp-mcp-fator3' ) );
		}

		check_admin_referer( self::NONCE );

		$enable = isset( $_POST['enable'] ) && '1' === $_POST['enable'];

		update_option( PathGuard::OPTION_ENABLED, $enable, true );
		PathGuard::audit( $enable ? 'channel:enable' : 'channel:disable', '-' );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'           => self::SLUG,
					'f3_status' => 'ok',
				),
				admin_url( 'tools.php' )
			)
		);
		exit;
	}

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$enabled    = PathGuard::is_enabled();
		$hard_block = ( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT )
			|| ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS );
		$status     = isset( $_GET['f3_status'] ) ? sanitize_key( wp_unslash( $_GET['f3_status'] ) ) : '';

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'WP MCP Fator3 — canal de arquivos e banco', 'wp-mcp-fator3' ) . '</h1>';

		if ( 'ok' === $status ) {
			echo '<div class="notice notice-success is-dismissible"><p>'
				. esc_html__( 'Estado do canal atualizado.', 'wp-mcp-fator3' ) . '</p></div>';
		}

		// ---- Estado atual --------------------------------------------------
		echo '<h2>' . esc_html__( 'Estado', 'wp-mcp-fator3' ) . '</h2>';
		echo '<p style="font-size:16px">';
		if ( $enabled ) {
			echo '<span style="display:inline-block;padding:4px 10px;background:#00845a;color:#fff;border-radius:3px">'
				. esc_html__( 'ABERTO', 'wp-mcp-fator3' ) . '</span> '
				. esc_html__( 'As habilidades files/* estão disponíveis para contas com edit_themes + manage_options.', 'wp-mcp-fator3' );
		} else {
			echo '<span style="display:inline-block;padding:4px 10px;background:#646970;color:#fff;border-radius:3px">'
				. esc_html__( 'FECHADO', 'wp-mcp-fator3' ) . '</span> '
				. esc_html__( 'As habilidades files/* recusam qualquer chamada.', 'wp-mcp-fator3' );
		}
		echo '</p>';

		if ( $hard_block ) {
			echo '<div class="notice notice-warning inline"><p>'
				. esc_html__( 'O wp-config.php define DISALLOW_FILE_EDIT ou DISALLOW_FILE_MODS. Enquanto isso valer, o canal permanece fechado — o botão abaixo não reabre.', 'wp-mcp-fator3' )
				. '</p></div>';
		} elseif ( self::forced_by_filter() ) {
			echo '<div class="notice notice-info inline"><p>'
				. esc_html__( 'Há um filtro f3_mcp_files_enabled ativo em código. Ele tem a última palavra e pode sobrepor o botão abaixo.', 'wp-mcp-fator3' )
				. '</p></div>';
		}

		// ---- Botão ---------------------------------------------------------
		if ( ! $hard_block ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( self::NONCE );
			echo '<input type="hidden" name="action" value="f3_mcp_files_toggle">';
			echo '<input type="hidden" name="enable" value="' . ( $enabled ? '0' : '1' ) . '">';

			if ( $enabled ) {
				submit_button( __( 'Fechar o canal agora', 'wp-mcp-fator3' ), 'delete', 'submit', false );
				echo ' <span class="description">'
					. esc_html__( 'Efeito imediato. As leituras e gravações passam a ser recusadas.', 'wp-mcp-fator3' )
					. '</span>';
			} else {
				submit_button( __( 'Reabrir o canal', 'wp-mcp-fator3' ), 'primary', 'submit', false );
			}
			echo '</form>';
		}

		// ---- Banco de dados -------------------------------------------------
		$db_writes = Database::writes_enabled();

		echo '<h2>' . esc_html__( 'Banco de dados', 'wp-mcp-fator3' ) . '</h2>';
		echo '<p><code>db/schema</code> e <code>db/query</code> ' . esc_html__( '(somente leitura) seguem o canal geral acima.', 'wp-mcp-fator3' ) . '</p>';
		echo '<p>' . esc_html__( 'Escrita (db/execute):', 'wp-mcp-fator3' ) . ' ';
		echo $db_writes
			? '<strong style="color:#b32d2e">' . esc_html__( 'LIGADA', 'wp-mcp-fator3' ) . '</strong>'
			: '<strong>' . esc_html__( 'DESLIGADA', 'wp-mcp-fator3' ) . '</strong>';
		echo '</p>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'f3_mcp_db_toggle' );
		echo '<input type="hidden" name="action" value="f3_mcp_db_toggle">';
		echo '<input type="hidden" name="enable" value="' . ( $db_writes ? '0' : '1' ) . '">';
		submit_button(
			$db_writes ? __( 'Desligar escrita no banco', 'wp-mcp-fator3' ) : __( 'Ligar escrita no banco', 'wp-mcp-fator3' ),
			$db_writes ? 'delete' : 'primary',
			'submit',
			false
		);
		echo '</form>';

		echo '<p class="description" style="max-width:820px">'
			. esc_html__( 'Toda escrita passa obrigatoriamente por duas fases: a primeira chamada apenas mostra as linhas que seriam afetadas e devolve um token; sem esse token nada é gravado. UPDATE e DELETE sem WHERE são recusados, DDL (DROP, TRUNCATE, ALTER) é bloqueado, as linhas anteriores são copiadas antes da alteração, e tudo roda em transação — se o statement atingir mais linhas do que a pré-visualização mostrou, é feito rollback.', 'wp-mcp-fator3' )
			. '</p>';

		// ---- Escopo real ---------------------------------------------------
		echo '<h2>' . esc_html__( 'O que este canal alcança', 'wp-mcp-fator3' ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:820px"><tbody>';

		echo '<tr><th style="width:230px">' . esc_html__( 'Pastas graváveis', 'wp-mcp-fator3' ) . '</th><td>';
		$roots = PathGuard::roots();
		echo $roots
			? '<code>' . implode( '</code><br><code>', array_map( 'esc_html', $roots ) ) . '</code>'
			: esc_html__( 'nenhuma', 'wp-mcp-fator3' );
		echo '<br><span class="description">'
			. esc_html__( 'Qualquer arquivo dentro dessas pastas pode ser lido e gravado. Fora do alcance: wp-admin, wp-includes, raiz do site e o diretório de uploads.', 'wp-mcp-fator3' )
			. '</span></td></tr>';

		$ext_allow = PathGuard::allowed_extensions();
		$ext_deny  = PathGuard::denied_extensions();

		echo '<tr><th>' . esc_html__( 'Extensões permitidas', 'wp-mcp-fator3' ) . '</th><td>';
		if ( $ext_allow ) {
			echo '<code>' . esc_html( implode( ', ', $ext_allow ) ) . '</code><br><span class="description">'
				. esc_html__( 'Um filtro f3_mcp_files_allowed_extensions está restringindo as extensões neste site.', 'wp-mcp-fator3' )
				. '</span>';
		} else {
			echo esc_html__( 'todas', 'wp-mcp-fator3' ) . '<br><span class="description">'
				. esc_html__( 'Qualquer extensão (php, css, tsv, csv, mo, sql, map…) e também arquivos sem extensão, como LICENSE. O que limita o canal é a pasta, não o formato.', 'wp-mcp-fator3' )
				. '</span>';
		}
		if ( $ext_deny ) {
			echo '<br><span class="description">' . esc_html__( 'Bloqueadas por filtro:', 'wp-mcp-fator3' )
				. ' <code>' . esc_html( implode( ', ', $ext_deny ) ) . '</code></span>';
		}
		echo '</td></tr>';

		echo '<tr><th>' . esc_html__( 'Arquivos sempre bloqueados', 'wp-mcp-fator3' ) . '</th><td><code>'
			. esc_html( implode( ', ', PathGuard::denied_basenames() ) ) . '</code><br>'
			. '<span class="description">'
			. esc_html__( 'Bloqueados em qualquer pasta, inclusive dentro de um tema ou plugin. Somam-se a estes os arquivos do próprio WP MCP Fator3, que o canal não edita.', 'wp-mcp-fator3' )
			. '</span></td></tr>';

		echo '<tr><th>' . esc_html__( 'Capacidades exigidas', 'wp-mcp-fator3' )
			. '</th><td><code>edit_themes</code> + <code>manage_options</code></td></tr>';

		echo '<tr><th>' . esc_html__( 'Limite por arquivo', 'wp-mcp-fator3' ) . '</th><td>'
			. esc_html( size_format( PathGuard::max_bytes() ) ) . '</td></tr>';

		echo '<tr><th>' . esc_html__( 'Backups', 'wp-mcp-fator3' ) . '</th><td><code>'
			. esc_html( wp_normalize_path( WP_CONTENT_DIR ) . '/f3-mcp-backups' ) . '</code><br>'
			. '<span class="description">'
			. esc_html__( 'Toda sobrescrita gera backup. Reverta com a habilidade files/restore.', 'wp-mcp-fator3' )
			. '</span></td></tr>';

		echo '</tbody></table>';

		// ---- Pré-requisitos -------------------------------------------------
		echo '<h2>' . esc_html__( 'Pré-requisitos', 'wp-mcp-fator3' ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:820px"><tbody>';

		$api_ok = function_exists( 'wp_register_ability' );
		printf(
			'<tr><th style="width:230px">%s</th><td>%s</td></tr>',
			esc_html__( 'Abilities API', 'wp-mcp-fator3' ),
			$api_ok
				? esc_html__( 'disponível — as rotas estão registradas', 'wp-mcp-fator3' )
				: '<strong style="color:#b32d2e">' . esc_html__( 'AUSENTE — nenhuma rota registrada. Requer WordPress 6.9+ ou um plugin que traga o polyfill.', 'wp-mcp-fator3' ) . '</strong>'
		);

		$srv_ok = function_exists( 'f3_mcp_files_servidor_mcp_detectado' )
			&& f3_mcp_files_servidor_mcp_detectado();
		printf(
			'<tr><th>%s</th><td>%s</td></tr>',
			esc_html__( 'Servidor MCP', 'wp-mcp-fator3' ),
			$srv_ok
				? esc_html__( 'detectado — as rotas são alcançáveis de fora', 'wp-mcp-fator3' )
				: '<strong>' . esc_html__( 'não detectado — as rotas existem no WordPress mas nada as expõe por MCP', 'wp-mcp-fator3' ) . '</strong>'
		);

		printf(
			'<tr><th>%s</th><td><code>%s</code></td></tr>',
			esc_html__( 'Versão do WordPress', 'wp-mcp-fator3' ),
			esc_html( get_bloginfo( 'version' ) )
		);

		echo '</tbody></table>';

		// ---- Nota de contexto honesta --------------------------------------
		if ( $srv_ok ) {
			echo '<h2>' . esc_html__( 'Sobre o alcance real do conector', 'wp-mcp-fator3' ) . '</h2>';
			echo '<p style="max-width:820px">'
				. esc_html__( 'Fechar este canal reduz o risco de alteração acidental em arquivos de tema, mas provavelmente não isola o site: servidores MCP costumam expor instalação e ativação de plugin, o que já permite executar PHP arbitrário. Vale conferir quais rotas o seu servidor MCP expõe — se o objetivo for contenção de verdade, o ponto a restringir são aquelas, não esta tela.', 'wp-mcp-fator3' )
				. '</p>';
		}

		// ---- Auditoria ------------------------------------------------------
		$log = get_option( 'f3_mcp_files_audit', array() );
		$log = is_array( $log ) ? array_reverse( $log ) : array();

		echo '<h2>' . esc_html__( 'Últimas operações', 'wp-mcp-fator3' ) . '</h2>';

		if ( empty( $log ) ) {
			echo '<p>' . esc_html__( 'Nenhuma operação registrada ainda.', 'wp-mcp-fator3' ) . '</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:980px"><thead><tr>';
			echo '<th>' . esc_html__( 'Quando (UTC)', 'wp-mcp-fator3' ) . '</th>';
			echo '<th>' . esc_html__( 'Ação', 'wp-mcp-fator3' ) . '</th>';
			echo '<th>' . esc_html__( 'Arquivo', 'wp-mcp-fator3' ) . '</th>';
			echo '<th>' . esc_html__( 'Usuário', 'wp-mcp-fator3' ) . '</th>';
			echo '</tr></thead><tbody>';

			foreach ( array_slice( $log, 0, 30 ) as $row ) {
				$user = get_userdata( (int) ( $row['user'] ?? 0 ) );
				echo '<tr>';
				echo '<td>' . esc_html( (string) ( $row['time'] ?? '' ) ) . '</td>';
				echo '<td><code>' . esc_html( (string) ( $row['action'] ?? '' ) ) . '</code></td>';
				echo '<td><code>' . esc_html( (string) ( $row['path'] ?? '' ) ) . '</code></td>';
				echo '<td>' . esc_html( $user ? $user->user_login : (string) ( $row['user'] ?? '' ) ) . '</td>';
				echo '</tr>';
			}

			echo '</tbody></table>';
		}

		echo '</div>';
	}
}
