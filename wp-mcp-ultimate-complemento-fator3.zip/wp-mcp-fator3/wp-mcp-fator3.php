<?php
/**
 * Plugin Name:       WP MCP Fator3
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Acrescenta habilidades de arquivo (files/*) e de banco de dados (db/*) à Abilities API do WordPress, expostas por qualquer servidor MCP instalado. Alcança qualquer arquivo dentro dos diretórios de temas e de plugins; escrita no banco em duas fases, com pré-visualização obrigatória. Liga e desliga em Ferramentas > MCP Fator3.
 * Version:           0.8.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Fator3
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-mcp-fator3
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A versão anterior (pasta `f3-mcp-files`) ainda está ativa?
 *
 * Este plugin mudou de pasta ao ser renomeado, então o WordPress o trata como
 * instalação nova e as duas cópias podem ficar ativas ao mesmo tempo. Como
 * ambas declaram as mesmas classes, carregar as duas seria erro fatal e o site
 * cairia. O WordPress carrega os plugins em ordem alfabética, então a cópia
 * antiga vem primeiro: aqui, a nova percebe e sai de campo com um aviso em vez
 * de derrubar o site.
 */
if ( defined( 'F3_MCP_FILES_VERSION' ) || class_exists( __NAMESPACE__ . '\\PathGuard', false ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p><strong>WP MCP Fator3:</strong> %s</p></div>',
				esc_html__( 'a versão anterior deste plugin (Fator3 MCP Files, pasta f3-mcp-files) continua ativa. Desative e apague aquela cópia; enquanto isso, esta não carrega.', 'wp-mcp-fator3' )
			);
		}
	);
	return;
}

define( 'F3_MCP_FILES_VERSION', '0.8.0' );
define( 'F3_MCP_FILES_DIR', plugin_dir_path( __FILE__ ) );

require_once F3_MCP_FILES_DIR . 'includes/PathGuard.php';
require_once F3_MCP_FILES_DIR . 'includes/Http.php';
require_once F3_MCP_FILES_DIR . 'includes/SqlGuard.php';
require_once F3_MCP_FILES_DIR . 'includes/Database.php';
require_once F3_MCP_FILES_DIR . 'includes/SelfTest.php';
require_once F3_MCP_FILES_DIR . 'includes/Files.php';
require_once F3_MCP_FILES_DIR . 'includes/Admin.php';

/**
 * Registra as habilidades na Abilities API.
 *
 * `wp_abilities_api_init` é disparado tanto pelo WordPress 6.9+ nativo quanto
 * pelo polyfill que o WP MCP Ultimate carrega. Uma vez registradas, as
 * habilidades aparecem no `discover-abilities` e podem ser chamadas pelo
 * `execute-ability` do servidor MCP já existente — sem tocar naquele plugin.
 */
add_action(
	'wp_abilities_api_init',
	static function (): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		Files::register();
		Database::register();
	}
);

Admin::init();

/**
 * Protege as opções deste plugin contra a habilidade options/update.
 *
 * A lista de proteção padrão do WP MCP Ultimate cobre ~23 nomes fixos e
 * libera todo o resto. Sem isto, o agente poderia reabrir o canal depois de
 * você fechá-lo, ou apagar o próprio log de auditoria, com um options/update.
 *
 * Isto não é contenção contra um agente comprometido — quem tem
 * `install_plugins` já pode instalar PHP arbitrário. É para que o botão
 * "fechar o canal" signifique o que promete no uso normal.
 */
add_filter(
	'wp_mcp_ultimate_protected_options',
	static function ( $protected ) {
		if ( ! is_array( $protected ) ) {
			$protected = array();
		}
		$protected[] = PathGuard::OPTION_ENABLED;
		$protected[] = 'f3_mcp_files_audit';
		$protected[] = Database::OPTION_WRITES;
		return $protected;
	}
);

/**
 * Ativar o plugin abre o canal — ativar já é o ato humano explícito.
 */
register_activation_hook(
	__FILE__,
	static function (): void {
		add_option( PathGuard::OPTION_ENABLED, true, '', true );
		add_option( Database::OPTION_WRITES, true, '', true );
	}
);

/**
 * A Abilities API existe nesta instalação?
 *
 * Vem do núcleo no WordPress 6.9+, ou de um polyfill carregado por um plugin de
 * servidor MCP. Sem ela, `wp_abilities_api_init` nunca dispara e este plugin não
 * registra rota nenhuma.
 */
function f3_mcp_files_abilities_api_disponivel(): bool {
	return function_exists( 'wp_register_ability' );
}

/**
 * Existe algum servidor MCP para expor as rotas para fora?
 *
 * Registrar habilidades não basta: elas ficam no WordPress e ninguém de fora as
 * alcança sem um servidor MCP. Hoje quem cumpre esse papel aqui é o WP MCP
 * Ultimate, mas a checagem é por capacidade, não por marca — qualquer plugin
 * que exponha a Abilities API por MCP serve.
 */
function f3_mcp_files_servidor_mcp_detectado(): bool {
	return class_exists( '\WpMcpUltimate\Server\McpAdapter' )
		|| defined( 'WP_MCP_ULTIMATE_DIR' )
		|| (bool) apply_filters( 'f3_mcp_files_servidor_mcp_detectado', false );
}

/**
 * Avisos no admin — apenas pré-requisito ausente.
 *
 * Não há aviso de estado do canal: ele aparecia em toda visita à tela de
 * Plugins e não informava nada que a própria tela de controle não mostre. O que
 * sobra aqui é só falha silenciosa: sem a Abilities API o plugin ativa, a tela
 * diz "ABERTO" e nada funciona — isso precisa gritar.
 */
add_action(
	'admin_notices',
	static function (): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! f3_mcp_files_abilities_api_disponivel() ) {
			printf(
				'<div class="notice notice-error"><p><strong>WP MCP Fator3:</strong> %s</p></div>',
				esc_html__( 'a Abilities API do WordPress não está disponível, então NENHUMA rota foi registrada e o plugin não faz nada. Ela vem no WordPress 6.9 ou superior; em versões anteriores, é preciso um plugin de servidor MCP que traga o polyfill.', 'wp-mcp-fator3' )
			);
			return;
		}

		if ( ! f3_mcp_files_servidor_mcp_detectado() ) {
			printf(
				'<div class="notice notice-warning"><p><strong>WP MCP Fator3:</strong> %s</p></div>',
				esc_html__( 'as rotas foram registradas, mas nenhum servidor MCP foi detectado neste site. Sem ele as rotas existem no WordPress e não são alcançáveis de fora — instale um plugin de servidor MCP (por exemplo o WP MCP Ultimate) para expô-las.', 'wp-mcp-fator3' )
			);
		}
	}
);

/**
 * Atalho "Configurar" na linha do plugin.
 */
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	static function ( array $links ): array {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'tools.php?page=wp-mcp-fator3' ) ) . '">'
				. esc_html__( 'Configurar', 'wp-mcp-fator3' ) . '</a>'
		);
		return $links;
	}
);

/**
 * Desativar o plugin já remove as habilidades do registro; nada a limpar.
 *
 * Os backups são preservados de propósito — desativar não deve destruir a
 * única cópia de um arquivo que alguém pode precisar restaurar.
 */
register_deactivation_hook(
	__FILE__,
	static function (): void {
		// Intencionalmente vazio, e documentado para deixar claro que a
		// preservação dos backups é decisão, não esquecimento.
	}
);
