# WP MCP Fator3 — canal de arquivos e banco para agentes

Complemento do servidor MCP do WordPress. Registra **12 rotas** na Abilities API
— nove de arquivo e três de banco — que qualquer servidor MCP instalado expõe
para fora. Não substitui o servidor MCP: soma-se a ele.

Versão 0.8.0 · GPL-2.0-or-later · Fator3

---

## O que ele resolve

O WP MCP Ultimate cobre conteúdo, options, mídia, usuários, menus e plugins.
Não cobre **arquivo de tema/plugin** nem **SQL**. Sem isso, o agente de
manutenção não edita `theme.json`, `style.css`, `parts/header.html` nem
diagnostica estado que só existe no banco — e a manutenção pós-entrega descrita
no prompt de construção fica dependente de FTP humano.

## Pré-requisitos

| | |
|---|---|
| WordPress | 6.4+ |
| PHP | 7.4+ |
| Abilities API | nativa no WordPress 6.9+; abaixo disso vem do polyfill que o plugin de servidor MCP carrega |
| Servidor MCP | qualquer um que exponha a Abilities API (validado com **WP MCP Ultimate 2.1.0**) |

Sem a Abilities API o plugin ativa, a tela diz "ABERTO" e **nenhuma rota é
registrada** — falha silenciosa. Por isso ele avisa no admin nos dois casos: API
ausente (erro) e servidor MCP não detectado (aviso). Não há mais aviso de estado
do canal na tela de Plugins.

## Instalação

1. **Desative e apague** a versão anterior (Fator3 MCP Files, pasta `f3-mcp-files`).
   O plugin mudou de pasta ao ser renomeado, então o WordPress o trata como
   instalação nova; as duas cópias ativas ao mesmo tempo declarariam as mesmas
   classes. A nova detecta a antiga e se recusa a carregar em vez de derrubar o
   site, mas quem funciona nesse cenário é a antiga.
2. Plugins → Adicionar novo → Enviar plugin → `wp-mcp-fator3.0.8.0.zip` → Ativar.
   As options são as mesmas (`f3_mcp_files_*`), então o estado do canal, o log de
   auditoria e os backups sobrevivem à troca.
3. Ativar **abre o canal** — ativar já é o ato humano explícito.
4. Rodar `files/selftest` pelo canal (sem parâmetros). A bateria roda contra o
   sistema de arquivos e o guardião de SQL **reais** deste servidor; o que
   importa é `failed: 0`.
   O item para olhar primeiro é `detecta_php_quebrado`: se ele falhar, a checagem
   de sintaxe está inerte e gravar PHP passa a ser perigoso.
5. Repetir o `files/selftest` depois de toda atualização de PHP da hospedagem e
   ao trocar de host.

Rota nova não exige reabrir a conversa com o conector: a descoberta acontece no
servidor a cada chamada.

## As 12 rotas

Chamadas pelo `execute-ability` do servidor MCP, com o nome em barra:

```json
{ "ability_name": "files/read", "parameters": { "path": "wp-content/themes/x/style.css" } }
```

Arquivo: `files/list` · `files/read` · `files/write` · `files/patch` ·
`files/delete` · `files/fetch` · `files/backups` · `files/restore` ·
`files/selftest`
Banco: `db/schema` · `db/query` · `db/execute`

Duas convenções que economizam uma ida e volta:

- **Caminhos são sempre relativos à raiz do WordPress.** `wp-content/themes/…`
  passa; `/home/usuario/site/wp-content/…` é recusado.
- **Toda resposta vem embrulhada.** O `success` externo diz se a chamada chegou;
  o `success` de dentro de `data` diz se a operação deu certo. Recusa por trava
  volta com externo `true` e interno `false` — é o de dentro que importa.

### Gravação segura

`files/read` devolve `sha256`. Passe-o como `expected_sha256` no `files/write`
seguinte: se outra pessoa alterou o arquivo nesse intervalo, a gravação é
recusada em vez de sobrescrever. A resposta traz `backup_id` — guarde-o; é o
argumento do `files/restore`.

Para edição pontual, `files/patch` (find/replace com trecho único) custa muito
menos que reenviar o arquivo inteiro.

### Escrita no banco em duas fases

Chamada 1 sem `confirm_token`: **não grava nada**, devolve `affected_rows`,
`preview_rows` e um token. Chamada 2 com o mesmo SQL e o token: aplica. Se o
statement ou o número de linhas mudou no intervalo, o token não confere e nada é
gravado. Se o statement atingir mais linhas do que a pré-visualização mostrou, a
transação é desfeita.

## O que o canal recusa

**Arquivos** — `wp-config.php`, `wp-settings.php`, `.htaccess`, `.htpasswd`,
`.user.ini`, `php.ini`, `.env`, `.git`, `.svn`, `.ssh`, `id_rsa`, `.npmrc`,
`.netrc` (verificados **por segmento** do caminho, então `.git/config` cai
junto); qualquer coisa fora das raízes permitidas; o **próprio diretório deste
plugin** (o canal não se edita); `..`, caminho absoluto, `php://`, byte nulo;
**PHP com erro de sintaxe — nada é gravado**; apagar diretório.

**Extensões: sem restrição.** Desde a 0.8.0 a extensão não é mais o que contém o
canal — a pasta é. Dentro dos diretórios de temas, de plugins e de mu-plugins
qualquer arquivo pode ser lido e gravado: `.php`, `.css`, `.js`, `.csv`, `.tsv`,
`.json`, `.mo`, `.sql`, `.map`, `.lock`, e também arquivos sem extensão como
`LICENSE` ou `Makefile`. A allowlist antiga não removia poder nenhum — `.php` já
estava liberada — só recusava trabalho legítimo, um formato por vez. Quem quiser
restringir devolve um array não vazio em `f3_mcp_files_allowed_extensions`, ou
lista formatos em `f3_mcp_files_denied_extensions`.

**Raízes permitidas** — todos os diretórios de temas registrados,
`wp-content/plugins/` e `wp-content/mu-plugins/`. Nunca `wp-admin/`,
`wp-includes/`, a raiz do site ou `wp-content/uploads/` (é servido pela web: um
`.php` lá seria backdoor; para mídia existe `media/upload`).

**Banco** — dois statements numa chamada; `DROP`, `TRUNCATE`, `ALTER`, `CREATE`,
`GRANT`, `SET`; `INTO OUTFILE`, `INTO DUMPFILE`, `LOAD_FILE()`; `UPDATE`/`DELETE`
sem `WHERE` (se for a intenção, escreva `WHERE 1=1`) ou com `JOIN`; escrita sem
`confirm_token`. `user_pass` e `user_activation_key` voltam sempre como
`[redigido]`.

## Limites

| | |
|---|---|
| Leitura e escrita direta de arquivo | 16 MiB — filtro `f3_mcp_files_max_bytes` (era 2 MiB até a 0.7.0) |
| `files/fetch` (o servidor baixa da URL) | 32 MiB — filtro `f3_mcp_files_max_fetch_bytes` |
| Linhas por consulta | 200 padrão, 2000 máximo |
| Linhas na pré-visualização | 20 padrão, 200 máximo |
| Log de auditoria | buffer circular das últimas 100 operações, na option `f3_mcp_files_audit` |

## Controle

**Ferramentas → MCP Fator3** no wp-admin: fechar ou reabrir o canal inteiro
(efeito imediato); ligar ou desligar **só a escrita no banco**, mantendo a
leitura; ver o escopo efetivo e as últimas operações auditadas.

Backups em `wp-content/f3-mcp-backups/`, protegidos contra acesso web por
`.htaccess` e `index.php`. **Não são apagados ao desativar o plugin.**

Travar por código, num mu-plugin fora do alcance do próprio canal:

```php
add_filter( 'f3_mcp_files_enabled', '__return_false' );
```

`DISALLOW_FILE_EDIT` e `DISALLOW_FILE_MODS` no `wp-config.php` têm precedência
sobre tudo e não são reabertos pela tela.

### Filtros

| Filtro | Para quê |
|---|---|
| `f3_mcp_files_enabled` | kill switch do canal inteiro |
| `f3_mcp_files_roots` | raízes onde as rotas operam — ampliar aumenta o raio de destruição |
| `f3_mcp_files_denied_basenames` | rede de segurança por segmento de caminho |
| `f3_mcp_files_allowed_extensions` | vazio = sem restrição; array não vazio volta a restringir |
| `f3_mcp_files_denied_extensions` | bloquear formatos específicos sem montar allowlist |
| `f3_mcp_files_max_bytes` | teto por arquivo na leitura e na escrita direta |
| `f3_mcp_files_max_fetch_bytes` | teto do `files/fetch` |
| `f3_mcp_files_servidor_mcp_detectado` | declarar outro servidor MCP como presente |

As três options do plugin (`f3_mcp_files_enabled`, `f3_mcp_db_writes`,
`f3_mcp_files_audit`) são acrescentadas à lista protegida do WP MCP Ultimate
(`wp_mcp_ultimate_protected_options`) — sem isso o agente reabriria o canal, ou
apagaria o próprio log de auditoria, com um `options/update`.

## Quando NÃO usar estas rotas

Ferramenta de último recurso. O que tem rota tipada usa a rota tipada, que cuida
de cache, serialização, revisões e hooks:

| Tarefa | Use | Não use |
|---|---|---|
| Editar post ou página | `content/update-post` | `db/execute` |
| Alterar uma option | `options/update` | `db/execute` |
| Criar ou editar usuário | `users/create` / `users/update` | `db/execute` |
| Subir imagem para a mídia | `media/upload` | `files/fetch` |
| Instalar plugin de terceiro | `plugins/upload` | `files/write` |
| Moderar comentário | `comments/update-status` | `db/execute` |

O caso mais perigoso é `options.option_value` e `*meta.meta_value`: guardam PHP
serializado, e alterar por SQL cru corrompe o valor — o prefixo de tamanho de
cada string deixa de bater e o WordPress passa a desserializar `false` em
silêncio. O canal avisa quando detecta isso; o certo é `options/update`.

## Nota honesta sobre contenção

Fechar este canal reduz o risco de **alteração acidental**, que é o modo de falha
provável. Não isola o site: o servidor MCP já expõe `plugins/upload-base64` e
`plugins/activate`, que instalam e ativam PHP arbitrário. Quem alcança este canal
já alcançava aquele.

A fronteira real é o **usuário dedicado + Application Password** com o papel
dimensionado, mais as travas do canal. Se o objetivo for contenção de verdade, o
ponto a restringir são aquelas rotas do servidor MCP — não esta tela.

## Procedência e evidência

Este pacote descende do `korvena-mcp-files` **0.7.0**, em produção em
korvena.net.br, com os identificadores renomeados de `korvena`/`KORVENA` para
`f3`/`F3` (`Fator3\McpFiles`) para servir a qualquer projeto. A **0.8.0** renomeia
o plugin para WP MCP Fator3 e abre a política de extensões; as options, os nomes
das rotas (`files/*`, `db/*`) e os filtros não mudaram.

Verificado em laboratório — WordPress 7.0.4, PHP 8.4, SQLite, WP MCP Ultimate
2.1.0 — com 28 checagens nomeadas, casos positivos e negativos, **0 falhas**:
registro das 12 rotas; ciclo real write → read → write com `expected_sha256` →
patch → restore; recusa de hash velho; oito recusas de caminho (`wp-config.php`,
`.htaccess`, travessia, absoluto, uploads, wp-admin, o próprio plugin, extensão
— este último substituído na 0.8.0, que aceita qualquer extensão) com
**controle positivo** de que outro plugin continua legível;
recusa de PHP com sintaxe quebrada; `db/schema`, `SELECT`, recusa de `DROP`,
recusa de dois statements, recusa de `UPDATE` sem `WHERE`, ciclo de duas fases
aplicando de fato; extensão da lista de options protegidas; kill switch por
filtro. O `files/selftest` do próprio plugin fechou **57/57** naquela versão.

A bateria de verificação em laboratório acima é da 0.7.0. A 0.8.0 altera a
política de extensões, o teto por arquivo e as raízes — **rode o `files/selftest`
depois de instalar** e confira `failed: 0` antes de confiar no canal.

## Mudanças na 0.8.0

- Nome: **Fator3 MCP Files** → **WP MCP Fator3**; pasta `f3-mcp-files` →
  `wp-mcp-fator3`; menu **Ferramentas → MCP Files** → **MCP Fator3**.
- Removido o aviso de estado do canal na tela de Plugins (as duas variantes,
  aberto e fechado). Os avisos de pré-requisito ausente continuam.
- Extensões: allowlist substituída por política aberta. `.tsv` passa, e qualquer
  outro formato de tema ou plugin também, inclusive arquivo sem extensão.
- Raízes: além do diretório do tema ativo, entram **todos** os diretórios de
  temas registrados e o de **mu-plugins**.
- Teto por arquivo: 2 MiB → **16 MiB**, agora com filtro `f3_mcp_files_max_bytes`.
- Novo filtro `f3_mcp_files_denied_extensions`.
- Guarda contra as duas versões ativas ao mesmo tempo: a nova detecta a antiga,
  avisa e não carrega, em vez de derrubar o site com erro fatal.

Não medido aqui: comportamento sob MySQL (o laboratório usou SQLite) e o
`files/fetch` com rede real. Ambos rodam em produção no korvena.net.br desde
18/08/2026.

**Não é caminho de atualização** sobre uma instalação do `korvena-mcp-files`: as
options e o diretório de backups mudam de nome. Num site que já roda o
`korvena-mcp-files`, mantenha aquele. Este é para projetos novos.
