# Fator3 MCP Files — canal de arquivos e banco para agentes

Complemento do servidor MCP do WordPress. Registra **12 rotas** na Abilities API
— nove de arquivo e três de banco — que qualquer servidor MCP instalado expõe
para fora. Não substitui o servidor MCP: soma-se a ele.

Versão 0.7.0 · GPL-2.0-or-later · Fator3

---

## O que ele resolve

O WP MCP Ultimate cobre conteúdo, options, mídia, usuários, menus e plugins.
Não cobre **arquivo de tema/plugin** nem **SQL**. Sem isso, o agente de
manutenção não edita `theme.json`, `style.css`, `parts/header.html` nem
diagnostica estado que só existe no banco — e a manutenção pós-entrega descrita
no prompt de construção fica dependente de FTP humano.

## Pré-requisitos

| | |
|---|---|
| WordPress | 6.4+ |
| PHP | 7.4+ |
| Abilities API | nativa no WordPress 6.9+; abaixo disso vem do polyfill que o plugin de servidor MCP carrega |
| Servidor MCP | qualquer um que exponha a Abilities API (validado com **WP MCP Ultimate 2.1.0**) |

Sem a Abilities API o plugin ativa, a tela diz "ABERTO" e **nenhuma rota é
registrada** — falha silenciosa. Por isso ele grita na tela de Plugins nos dois
casos: API ausente (erro) e servidor MCP não detectado (aviso).

## Instalação

1. Plugins → Adicionar novo → Enviar plugin → `f3-mcp-files.0.7.0.zip` → Ativar.
2. Ativar **abre o canal** — ativar já é o ato humano explícito.
3. Rodar `files/selftest` pelo canal (sem parâmetros). São 57 verificações contra
   o sistema de arquivos e o guardião de SQL **reais** deste servidor.
   O item para olhar primeiro é `detecta_php_quebrado`: se ele falhar, a checagem
   de sintaxe está inerte e gravar PHP passa a ser perigoso.
4. Repetir o `files/selftest` depois de toda atualização de PHP da hospedagem e
   ao trocar de host.

Rota nova não exige reabrir a conversa com o conector: a descoberta acontece no
servidor a cada chamada.

## As 12 rotas

Chamadas pelo `execute-ability` do servidor MCP, com o nome em barra:

```json
{ "ability_name": "files/read", "parameters": { "path": "wp-content/themes/x/style.css" } }
```

Arquivo: `files/list` · `files/read` · `files/write` · `files/patch` ·
`files/delete` · `files/fetch` · `files/backups` · `files/restore` ·
`files/selftest`
Banco: `db/schema` · `db/query` · `db/execute`

Duas convenções que economizam uma ida e volta:

- **Caminhos são sempre relativos à raiz do WordPress.** `wp-content/themes/…`
  passa; `/home/usuario/site/wp-content/…` é recusado.
- **Toda resposta vem embrulhada.** O `success` externo diz se a chamada chegou;
  o `success` de dentro de `data` diz se a operação deu certo. Recusa por trava
  volta com externo `true` e interno `false` — é o de dentro que importa.

### Gravação segura

`files/read` devolve `sha256`. Passe-o como `expected_sha256` no `files/write`
seguinte: se outra pessoa alterou o arquivo nesse intervalo, a gravação é
recusada em vez de sobrescrever. A resposta traz `backup_id` — guarde-o; é o
argumento do `files/restore`.

Para edição pontual, `files/patch` (find/replace com trecho único) custa muito
menos que reenviar o arquivo inteiro.

### Escrita no banco em duas fases

Chamada 1 sem `confirm_token`: **não grava nada**, devolve `affected_rows`,
`preview_rows` e um token. Chamada 2 com o mesmo SQL e o token: aplica. Se o
statement ou o número de linhas mudou no intervalo, o token não confere e nada é
gravado. Se o statement atingir mais linhas do que a pré-visualização mostrou, a
transação é desfeita.

## O que o canal recusa

**Arquivos** — `wp-config.php`, `wp-settings.php`, `.htaccess`, `.htpasswd`,
`.user.ini`, `php.ini`, `.env`, `.git`, `.svn`, `.ssh`, `id_rsa`, `.npmrc`,
`.netrc` (verificados **por segmento** do caminho, então `.git/config` cai
junto); qualquer coisa fora das raízes permitidas (por padrão temas e plugins —
nunca `wp-admin/`, `wp-includes/`, a raiz ou `wp-content/uploads/`); o **próprio
diretório deste plugin** (o canal não se edita); `..`, caminho absoluto,
`php://`, byte nulo; extensão fora da allowlist; **PHP com erro de sintaxe —
nada é gravado**; apagar diretório.

Extensões aceitas: `php css js json txt md html htm twig po pot xml yml yaml
scss less csv png jpg jpeg gif webp avif ico svg woff woff2 ttf otf eot`.

**Banco** — dois statements numa chamada; `DROP`, `TRUNCATE`, `ALTER`, `CREATE`,
`GRANT`, `SET`; `INTO OUTFILE`, `INTO DUMPFILE`, `LOAD_FILE()`; `UPDATE`/`DELETE`
sem `WHERE` (se for a intenção, escreva `WHERE 1=1`) ou com `JOIN`; escrita sem
`confirm_token`. `user_pass` e `user_activation_key` voltam sempre como
`[redigido]`.

## Limites

| | |
|---|---|
| Leitura e escrita direta de arquivo | 2 MiB (constante `PathGuard::MAX_BYTES`, sem filtro) |
| `files/fetch` (o servidor baixa da URL) | 32 MiB — filtro `f3_mcp_files_max_fetch_bytes` |
| Linhas por consulta | 200 padrão, 2000 máximo |
| Linhas na pré-visualização | 20 padrão, 200 máximo |
| Log de auditoria | buffer circular das últimas 100 operações, na option `f3_mcp_files_audit` |

## Controle

**Ferramentas → MCP Files** no wp-admin: fechar ou reabrir o canal inteiro
(efeito imediato); ligar ou desligar **só a escrita no banco**, mantendo a
leitura; ver o escopo efetivo e as últimas operações auditadas.

Backups em `wp-content/f3-mcp-backups/`, protegidos contra acesso web por
`.htaccess` e `index.php`. **Não são apagados ao desativar o plugin.**

Travar por código, num mu-plugin fora do alcance do próprio canal:

```php
add_filter( 'f3_mcp_files_enabled', '__return_false' );
```

`DISALLOW_FILE_EDIT` e `DISALLOW_FILE_MODS` no `wp-config.php` têm precedência
sobre tudo e não são reabertos pela tela.

### Filtros

| Filtro | Para quê |
|---|---|
| `f3_mcp_files_enabled` | kill switch do canal inteiro |
| `f3_mcp_files_roots` | raízes onde as rotas operam — ampliar aumenta o raio de destruição |
| `f3_mcp_files_denied_basenames` | rede de segurança por segmento de caminho |
| `f3_mcp_files_allowed_extensions` | allowlist de extensões |
| `f3_mcp_files_max_fetch_bytes` | teto do `files/fetch` |
| `f3_mcp_files_servidor_mcp_detectado` | declarar outro servidor MCP como presente |

As três options do plugin (`f3_mcp_files_enabled`, `f3_mcp_db_writes`,
`f3_mcp_files_audit`) são acrescentadas à lista protegida do WP MCP Ultimate
(`wp_mcp_ultimate_protected_options`) — sem isso o agente reabriria o canal, ou
apagaria o próprio log de auditoria, com um `options/update`.

## Quando NÃO usar estas rotas

Ferramenta de último recurso. O que tem rota tipada usa a rota tipada, que cuida
de cache, serialização, revisões e hooks:

| Tarefa | Use | Não use |
|---|---|---|
| Editar post ou página | `content/update-post` | `db/execute` |
| Alterar uma option | `options/update` | `db/execute` |
| Criar ou editar usuário | `users/create` / `users/update` | `db/execute` |
| Subir imagem para a mídia | `media/upload` | `files/fetch` |
| Instalar plugin de terceiro | `plugins/upload` | `files/write` |
| Moderar comentário | `comments/update-status` | `db/execute` |

O caso mais perigoso é `options.option_value` e `*meta.meta_value`: guardam PHP
serializado, e alterar por SQL cru corrompe o valor — o prefixo de tamanho de
cada string deixa de bater e o WordPress passa a desserializar `false` em
silêncio. O canal avisa quando detecta isso; o certo é `options/update`.

## Nota honesta sobre contenção

Fechar este canal reduz o risco de **alteração acidental**, que é o modo de falha
provável. Não isola o site: o servidor MCP já expõe `plugins/upload-base64` e
`plugins/activate`, que instalam e ativam PHP arbitrário. Quem alcança este canal
já alcançava aquele.

A fronteira real é o **usuário dedicado + Application Password** com o papel
dimensionado, mais as travas do canal. Se o objetivo for contenção de verdade, o
ponto a restringir são aquelas rotas do servidor MCP — não esta tela.

## Procedência e evidência

Este pacote é o código do `korvena-mcp-files` **0.7.0**, em produção em
korvena.net.br, com os identificadores renomeados de `korvena`/`KORVENA` para
`f3`/`F3` (`Fator3\McpFiles`) para servir a qualquer projeto. A renomeação é
comprovadamente **sem perda**: aplicando o mapa inverso, o diff contra o original
fica reduzido às duas linhas de cabeçalho `Plugin Name` e `Plugin URI`.

Verificado em laboratório — WordPress 7.0.4, PHP 8.4, SQLite, WP MCP Ultimate
2.1.0 — com 28 checagens nomeadas, casos positivos e negativos, **0 falhas**:
registro das 12 rotas; ciclo real write → read → write com `expected_sha256` →
patch → restore; recusa de hash velho; oito recusas de caminho (`wp-config.php`,
`.htaccess`, travessia, absoluto, uploads, wp-admin, o próprio plugin, extensão
fora da lista) com **controle positivo** de que outro plugin continua legível;
recusa de PHP com sintaxe quebrada; `db/schema`, `SELECT`, recusa de `DROP`,
recusa de dois statements, recusa de `UPDATE` sem `WHERE`, ciclo de duas fases
aplicando de fato; extensão da lista de options protegidas; kill switch por
filtro. O `files/selftest` do próprio plugin fechou **57/57**.

Não medido aqui: comportamento sob MySQL (o laboratório usou SQLite) e o
`files/fetch` com rede real. Ambos rodam em produção no korvena.net.br desde
18/08/2026.

**Não é caminho de atualização** sobre uma instalação do `korvena-mcp-files`: as
options e o diretório de backups mudam de nome. Num site que já roda o
`korvena-mcp-files`, mantenha aquele. Este é para projetos novos.
