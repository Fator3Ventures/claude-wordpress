<?php
/**
 * Tela de administração — Ferramentas > MCP Files.
 *
 * O canal já vem ligado ao ativar o plugin; esta tela existe para o que é
 * realmente útil no dia a dia: desligar rápido, ver o que foi gravado e
 * conferir a configuração efetiva sem abrir o código.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class Admin {

	private const SLUG  = 'f3-mcp-files';
	private const NONCE = 'f3_mcp_files_toggle';

	public static function init(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );
		add_action( 'admin_post_f3_mcp_files_toggle', array( self::class, 'handle_toggle' ) );
		add_action( 'admin_post_f3_mcp_db_toggle', array( self::class, 'handle_db_toggle' ) );
	}

	/** Liga/desliga apenas a ESCRITA no banco; a leitura segue o canal geral. */
	public static function handle_db_toggle(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'f3-mcp-files' ) );
		}

		check_admin_referer( 'f3_mcp_db_toggle' );

		$enable = isset( $_POST['enable'] ) && '1' === $_POST['enable'];
		update_option( Database::OPTION_WRITES, $enable, true );
		PathGuard::audit( $enable ? 'db:writes-on' : 'db:writes-off', '-' );

		wp_safe_redirect( add_query_arg( array( 'page' => self::SLUG, 'f3_status' => 'ok' ), admin_url( 'tools.php' ) ) );
		exit;
	}

	public static function menu(): void {
		add_management_page(
			__( 'MCP Files', 'f3-mcp-files' ),
			__( 'MCP Files', 'f3-mcp-files' ),
			'manage_options',
			self::SLUG,
			array( self::class, 'render' )
		);
	}

	/** Um filtro em código está forçando o estado, ignorando a opção? */
	public static function forced_by_filter(): bool {
		return has_filter( 'f3_mcp_files_enabled' );
	}

	public static function handle_toggle(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'f3-mcp-files' ) );
		}

		check_admin_referer( self::NONCE );

		$enable = isset( $_POST['enable'] ) && '1' === $_POST['enable'];

		update_option( PathGuard::OPTION_ENABLED, $enable, true );
		PathGuard::audit( $enable ? 'channel:enable' : 'channel:disable', '-' );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'           => self::SLUG,
					'f3_status' => 'ok',
				),
				admin_url( 'tools.php' )
			)
		);
		exit;
	}

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$enabled    = PathGuard::is_enabled();
		$hard_block = ( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT )
			|| ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS );
		$status     = isset( $_GET['f3_status'] ) ? sanitize_key( wp_unslash( $_GET['f3_status'] ) ) : '';

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'MCP Files — canal de arquivos', 'f3-mcp-files' ) . '</h1>';

		if ( 'ok' === $status ) {
			echo '<div class="notice notice-success is-dismissible"><p>'
				. esc_html__( 'Estado do canal atualizado.', 'f3-mcp-files' ) . '</p></div>';
		}

		// ---- Estado atual --------------------------------------------------
		echo '<h2>' . esc_html__( 'Estado', 'f3-mcp-files' ) . '</h2>';
		echo '<p style="font-size:16px">';
		if ( $enabled ) {
			echo '<span style="display:inline-block;padding:4px 10px;background:#00845a;color:#fff;border-radius:3px">'
				. esc_html__( 'ABERTO', 'f3-mcp-files' ) . '</span> '
				. esc_html__( 'As habilidades files/* estão disponíveis para contas com edit_themes + manage_options.', 'f3-mcp-files' );
		} else {
			echo '<span style="display:inline-block;padding:4px 10px;background:#646970;color:#fff;border-radius:3px">'
				. esc_html__( 'FECHADO', 'f3-mcp-files' ) . '</span> '
				. esc_html__( 'As habilidades files/* recusam qualquer chamada.', 'f3-mcp-files' );
		}
		echo '</p>';

		if ( $hard_block ) {
			echo '<div class="notice notice-warning inline"><p>'
				. esc_html__( 'O wp-config.php define DISALLOW_FILE_EDIT ou DISALLOW_FILE_MODS. Enquanto isso valer, o canal permanece fechado — o botão abaixo não reabre.', 'f3-mcp-files' )
				. '</p></div>';
		} elseif ( self::forced_by_filter() ) {
			echo '<div class="notice notice-info inline"><p>'
				. esc_html__( 'Há um filtro f3_mcp_files_enabled ativo em código. Ele tem a última palavra e pode sobrepor o botão abaixo.', 'f3-mcp-files' )
				. '</p></div>';
		}

		// ---- Botão ---------------------------------------------------------
		if ( ! $hard_block ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( self::NONCE );
			echo '<input type="hidden" name="action" value="f3_mcp_files_toggle">';
			echo '<input type="hidden" name="enable" value="' . ( $enabled ? '0' : '1' ) . '">';

			if ( $enabled ) {
				submit_button( __( 'Fechar o canal agora', 'f3-mcp-files' ), 'delete', 'submit', false );
				echo ' <span class="description">'
					. esc_html__( 'Efeito imediato. As leituras e gravações passam a ser recusadas.', 'f3-mcp-files' )
					. '</span>';
			} else {
				submit_button( __( 'Reabrir o canal', 'f3-mcp-files' ), 'primary', 'submit', false );
			}
			echo '</form>';
		}

		// ---- Banco de dados -------------------------------------------------
		$db_writes = Database::writes_enabled();

		echo '<h2>' . esc_html__( 'Banco de dados', 'f3-mcp-files' ) . '</h2>';
		echo '<p><code>db/schema</code> e <code>db/query</code> ' . esc_html__( '(somente leitura) seguem o canal geral acima.', 'f3-mcp-files' ) . '</p>';
		echo '<p>' . esc_html__( 'Escrita (db/execute):', 'f3-mcp-files' ) . ' ';
		echo $db_writes
			? '<strong style="color:#b32d2e">' . esc_html__( 'LIGADA', 'f3-mcp-files' ) . '</strong>'
			: '<strong>' . esc_html__( 'DESLIGADA', 'f3-mcp-files' ) . '</strong>';
		echo '</p>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'f3_mcp_db_toggle' );
		echo '<input type="hidden" name="action" value="f3_mcp_db_toggle">';
		echo '<input type="hidden" name="enable" value="' . ( $db_writes ? '0' : '1' ) . '">';
		submit_button(
			$db_writes ? __( 'Desligar escrita no banco', 'f3-mcp-files' ) : __( 'Ligar escrita no banco', 'f3-mcp-files' ),
			$db_writes ? 'delete' : 'primary',
			'submit',
			false
		);
		echo '</form>';

		echo '<p class="description" style="max-width:820px">'
			. esc_html__( 'Toda escrita passa obrigatoriamente por duas fases: a primeira chamada apenas mostra as linhas que seriam afetadas e devolve um token; sem esse token nada é gravado. UPDATE e DELETE sem WHERE são recusados, DDL (DROP, TRUNCATE, ALTER) é bloqueado, as linhas anteriores são copiadas antes da alteração, e tudo roda em transação — se o statement atingir mais linhas do que a pré-visualização mostrou, é feito rollback.', 'f3-mcp-files' )
			. '</p>';

		// ---- Escopo real ---------------------------------------------------
		echo '<h2>' . esc_html__( 'O que este canal alcança', 'f3-mcp-files' ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:820px"><tbody>';

		echo '<tr><th style="width:230px">' . esc_html__( 'Pastas graváveis', 'f3-mcp-files' ) . '</th><td>';
		$roots = PathGuard::roots();
		echo $roots
			? '<code>' . implode( '</code><br><code>', array_map( 'esc_html', $roots ) ) . '</code>'
			: esc_html__( 'nenhuma', 'f3-mcp-files' );
		echo '<br><span class="description">'
			. esc_html__( 'Fora do alcance: wp-admin, wp-includes, raiz do site, diretório de plugins e uploads.', 'f3-mcp-files' )
			. '</span></td></tr>';

		echo '<tr><th>' . esc_html__( 'Extensões permitidas', 'f3-mcp-files' ) . '</th><td><code>'
			. esc_html( implode( ', ', PathGuard::allowed_extensions() ) ) . '</code></td></tr>';

		echo '<tr><th>' . esc_html__( 'Arquivos sempre bloqueados', 'f3-mcp-files' ) . '</th><td><code>'
			. esc_html( implode( ', ', array_slice( PathGuard::denied_basenames(), 0, 8 ) ) ) . ', …</code></td></tr>';

		echo '<tr><th>' . esc_html__( 'Capacidades exigidas', 'f3-mcp-files' )
			. '</th><td><code>edit_themes</code> + <code>manage_options</code></td></tr>';

		echo '<tr><th>' . esc_html__( 'Limite por arquivo', 'f3-mcp-files' ) . '</th><td>'
			. esc_html( size_format( PathGuard::MAX_BYTES ) ) . '</td></tr>';

		echo '<tr><th>' . esc_html__( 'Backups', 'f3-mcp-files' ) . '</th><td><code>'
			. esc_html( wp_normalize_path( WP_CONTENT_DIR ) . '/f3-mcp-backups' ) . '</code><br>'
			. '<span class="description">'
			. esc_html__( 'Toda sobrescrita gera backup. Reverta com a habilidade files/restore.', 'f3-mcp-files' )
			. '</span></td></tr>';

		echo '</tbody></table>';

		// ---- Pré-requisitos -------------------------------------------------
		echo '<h2>' . esc_html__( 'Pré-requisitos', 'f3-mcp-files' ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:820px"><tbody>';

		$api_ok = function_exists( 'wp_register_ability' );
		printf(
			'<tr><th style="width:230px">%s</th><td>%s</td></tr>',
			esc_html__( 'Abilities API', 'f3-mcp-files' ),
			$api_ok
				? esc_html__( 'disponível — as rotas estão registradas', 'f3-mcp-files' )
				: '<strong style="color:#b32d2e">' . esc_html__( 'AUSENTE — nenhuma rota registrada. Requer WordPress 6.9+ ou um plugin que traga o polyfill.', 'f3-mcp-files' ) . '</strong>'
		);

		$srv_ok = function_exists( 'f3_mcp_files_servidor_mcp_detectado' )
			&& f3_mcp_files_servidor_mcp_detectado();
		printf(
			'<tr><th>%s</th><td>%s</td></tr>',
			esc_html__( 'Servidor MCP', 'f3-mcp-files' ),
			$srv_ok
				? esc_html__( 'detectado — as rotas são alcançáveis de fora', 'f3-mcp-files' )
				: '<strong>' . esc_html__( 'não detectado — as rotas existem no WordPress mas nada as expõe por MCP', 'f3-mcp-files' ) . '</strong>'
		);

		printf(
			'<tr><th>%s</th><td><code>%s</code></td></tr>',
			esc_html__( 'Versão do WordPress', 'f3-mcp-files' ),
			esc_html( get_bloginfo( 'version' ) )
		);

		echo '</tbody></table>';

		// ---- Nota de contexto honesta --------------------------------------
		if ( $srv_ok ) {
			echo '<h2>' . esc_html__( 'Sobre o alcance real do conector', 'f3-mcp-files' ) . '</h2>';
			echo '<p style="max-width:820px">'
				. esc_html__( 'Fechar este canal reduz o risco de alteração acidental em arquivos de tema, mas provavelmente não isola o site: servidores MCP costumam expor instalação e ativação de plugin, o que já permite executar PHP arbitrário. Vale conferir quais rotas o seu servidor MCP expõe — se o objetivo for contenção de verdade, o ponto a restringir são aquelas, não esta tela.', 'f3-mcp-files' )
				. '</p>';
		}

		// ---- Auditoria ------------------------------------------------------
		$log = get_option( 'f3_mcp_files_audit', array() );
		$log = is_array( $log ) ? array_reverse( $log ) : array();

		echo '<h2>' . esc_html__( 'Últimas operações', 'f3-mcp-files' ) . '</h2>';

		if ( empty( $log ) ) {
			echo '<p>' . esc_html__( 'Nenhuma operação registrada ainda.', 'f3-mcp-files' ) . '</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:980px"><thead><tr>';
			echo '<th>' . esc_html__( 'Quando (UTC)', 'f3-mcp-files' ) . '</th>';
			echo '<th>' . esc_html__( 'Ação', 'f3-mcp-files' ) . '</th>';
			echo '<th>' . esc_html__( 'Arquivo', 'f3-mcp-files' ) . '</th>';
			echo '<th>' . esc_html__( 'Usuário', 'f3-mcp-files' ) . '</th>';
			echo '</tr></thead><tbody>';

			foreach ( array_slice( $log, 0, 30 ) as $row ) {
				$user = get_userdata( (int) ( $row['user'] ?? 0 ) );
				echo '<tr>';
				echo '<td>' . esc_html( (string) ( $row['time'] ?? '' ) ) . '</td>';
				echo '<td><code>' . esc_html( (string) ( $row['action'] ?? '' ) ) . '</code></td>';
				echo '<td><code>' . esc_html( (string) ( $row['path'] ?? '' ) ) . '</code></td>';
				echo '<td>' . esc_html( $user ? $user->user_login : (string) ( $row['user'] ?? '' ) ) . '</td>';
				echo '</tr>';
			}

			echo '</tbody></table>';
		}

		echo '</div>';
	}
}
