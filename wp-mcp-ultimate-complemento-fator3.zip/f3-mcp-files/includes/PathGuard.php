<?php
/**
 * PathGuard — o guardião de caminhos das habilidades files/*.
 *
 * Toda habilidade de arquivo passa obrigatoriamente por aqui antes de tocar
 * o disco. Se este arquivo estiver correto, o resto é seguro; se estiver
 * errado, nada mais importa. É deliberadamente pequeno e sem dependências
 * para poder ser lido inteiro numa sentada.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class PathGuard {

	/** Teto de bytes para leitura e escrita (2 MiB). */
	public const MAX_BYTES = 2097152;

	/** Nome da opção que guarda o estado do canal. */
	public const OPTION_ENABLED = 'f3_mcp_files_enabled';

	/**
	 * O canal está ligado?
	 *
	 * **Ligado ao ativar o plugin**, como qualquer plugin de WordPress: ativar
	 * já é o ato humano explícito. Uma segunda confirmação seria teatro de
	 * segurança neste site específico, porque o conector MCP existente já
	 * expõe `plugins/upload-base64` + `plugins/activate` (capacidades
	 * `install_plugins` e `activate_plugins`) — ou seja, quem alcança este
	 * canal já consegue instalar e ativar PHP arbitrário no servidor. Uma
	 * trava aqui não conteria um agente comprometido; só atrapalharia o uso
	 * legítimo.
	 *
	 * O que a tela de controle oferece de útil é o contrário: desligar rápido,
	 * ver o log e conferir a configuração efetiva.
	 *
	 * Precedência: DISALLOW_FILE_EDIT / DISALLOW_FILE_MODS fecham o canal e
	 * não podem ser reabertos por filtro nem pela tela.
	 */
	public static function is_enabled(): bool {
		if ( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT ) {
			return false;
		}
		if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
			return false;
		}

		$enabled = (bool) get_option( self::OPTION_ENABLED, true );

		/**
		 * Permite forçar o estado do canal por código.
		 *
		 * Use `__return_false` num mu-plugin para travar o canal fechado de
		 * um jeito que a tela de administração não reabre.
		 *
		 * @param bool $enabled Estado vindo da opção.
		 */
		return (bool) apply_filters( 'f3_mcp_files_enabled', $enabled );
	}

	/**
	 * Capacidade exigida.
	 *
	 * `edit_themes` é a capacidade que o próprio WordPress usa no editor de
	 * arquivos de tema (Aparência > Editor). `manage_options` é exigido junto
	 * para que um Editor de conteúdo nunca alcance o canal.
	 */
	public static function can_edit(): bool {
		return current_user_can( 'edit_themes' ) && current_user_can( 'manage_options' );
	}

	/**
	 * Raízes permitidas (allowlist).
	 *
	 * Padrão: apenas o diretório de temas. Nada de wp-admin, wp-includes,
	 * raiz do site ou uploads. Uploads fica de fora de propósito: é servido
	 * pela web, então escrever .php lá seria execução remota de código.
	 *
	 * @return string[] Caminhos absolutos já resolvidos por realpath().
	 */
	public static function roots(): array {
		$defaults = array( get_theme_root() );

		// O diretório de plugins entra porque é onde código legítimo mora e
		// era um pedido explícito. Não amplia o poder já concedido: o
		// conector expõe `plugins/upload-base64`, que substitui qualquer
		// plugin. Uploads continua **fora** — é servido pela web e um .php
		// lá é o padrão clássico de backdoor; para mídia existe `media/upload`.
		if ( defined( 'WP_PLUGIN_DIR' ) ) {
			$defaults[] = WP_PLUGIN_DIR;
		}

		/**
		 * Filtra as raízes onde as habilidades files/* podem operar.
		 *
		 * Acrescentar raízes amplia o raio de destruição do canal.
		 * Nunca inclua ABSPATH, wp-admin, wp-includes ou o diretório
		 * de uploads.
		 *
		 * @param string[] $defaults Caminhos absolutos.
		 */
		$roots = (array) apply_filters( 'f3_mcp_files_roots', $defaults );

		$out = array();
		foreach ( $roots as $root ) {
			$real = realpath( (string) $root );
			if ( false !== $real && is_dir( $real ) ) {
				$out[] = untrailingslashit( wp_normalize_path( $real ) );
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Nomes que nunca são lidos nem escritos, morem onde morarem.
	 *
	 * Rede de segurança: mesmo que alguém amplie as raízes por engano,
	 * estes continuam bloqueados. A checagem é por segmento do caminho,
	 * então `.git/config` cai junto com `.git`.
	 *
	 * @return string[]
	 */
	public static function denied_basenames(): array {
		return (array) apply_filters(
			'f3_mcp_files_denied_basenames',
			array(
				'wp-config.php',
				'wp-config-sample.php',
				'wp-settings.php',
				'.htaccess',
				'.htpasswd',
				'.user.ini',
				'php.ini',
				'.env',
				'.git',
				'.svn',
				'.ssh',
				'authorized_keys',
				'id_rsa',
				'id_ed25519',
				'.npmrc',
				'.netrc',
			)
		);
	}

	/**
	 * Extensões permitidas (allowlist, não blocklist).
	 *
	 * `php` está na lista porque editar template de tema é justamente o caso
	 * de uso — é o mesmo que o editor nativo do WordPress faz. O que protege
	 * não é proibir php, é a raiz restrita + a checagem de sintaxe antes de
	 * gravar.
	 *
	 * @return string[]
	 */
	public static function allowed_extensions(): array {
		return (array) apply_filters(
			'f3_mcp_files_allowed_extensions',
			array(
				// Código e texto.
				'php', 'css', 'js', 'json', 'txt', 'md', 'html', 'htm',
				'twig', 'po', 'pot', 'xml', 'yml', 'yaml', 'scss', 'less', 'csv',
				// Ativos de tema/plugin: imagens e fontes. Não são executáveis
				// e são o que de fato se "sobe" para um tema.
				'png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'ico',
				'svg', 'woff', 'woff2', 'ttf', 'otf', 'eot',
			)
		);
	}

	/**
	 * Extensões que só fazem sentido em bytes crus (nunca como texto).
	 *
	 * Usado para avisar quando alguém tenta gravar binário via `content`.
	 *
	 * @return string[]
	 */
	public static function binary_extensions(): array {
		return array( 'png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'ico', 'woff', 'woff2', 'ttf', 'otf', 'eot' );
	}

	/** Teto para download por URL — maior que o de escrita direta. */
	public static function max_fetch_bytes(): int {
		$max = (int) apply_filters( 'f3_mcp_files_max_fetch_bytes', 33554432 ); // 32 MiB
		return $max > 0 ? $max : 33554432;
	}

	/**
	 * Resolve um caminho relativo à raiz do WordPress e valida tudo.
	 *
	 * Caminhos são SEMPRE relativos a ABSPATH (ex.: "wp-content/themes/x/style.css").
	 * Caminho absoluto é rejeitado de saída — não há ambiguidade sobre a base.
	 *
	 * A defesa contra `../` e contra symlink que aponta para fora é a mesma:
	 * realpath() resolve os dois, e o resultado é comparado com a raiz
	 * permitida usando a barra como fronteira (senão "/themes-malicioso"
	 * passaria pelo prefixo "/themes").
	 *
	 * @param string $relative  Caminho relativo a ABSPATH.
	 * @param bool   $for_write true quando o arquivo pode ainda não existir.
	 * @return string|\WP_Error Caminho absoluto validado, ou erro.
	 */
	public static function resolve( string $relative, bool $for_write ) {
		$relative = trim( $relative );

		if ( '' === $relative ) {
			return new \WP_Error( 'f3_files_empty_path', __( 'O caminho é obrigatório.', 'f3-mcp-files' ) );
		}

		// Null byte trunca a string em chamadas de sistema do PHP: clássico
		// para burlar checagem de extensão ("x.php\0.txt").
		if ( false !== strpos( $relative, "\0" ) ) {
			return new \WP_Error( 'f3_files_null_byte', __( 'Caminho inválido.', 'f3-mcp-files' ) );
		}

		$normalized = wp_normalize_path( $relative );

		// Wrappers de stream (php://, phar://, http://) nunca são caminho de arquivo.
		if ( preg_match( '#^[a-zA-Z][a-zA-Z0-9+.\-]*://#', $normalized ) ) {
			return new \WP_Error( 'f3_files_scheme', __( 'Caminho inválido: use um caminho relativo à raiz do WordPress.', 'f3-mcp-files' ) );
		}

		// Absoluto (unix ou windows) é rejeitado: a base é sempre ABSPATH.
		if ( 0 === strpos( $normalized, '/' ) || preg_match( '#^[A-Za-z]:/#', $normalized ) ) {
			return new \WP_Error(
				'f3_files_absolute',
				__( 'Use um caminho relativo à raiz do WordPress, por exemplo wp-content/themes/meu-tema/functions.php', 'f3-mcp-files' )
			);
		}

		$segments = explode( '/', $normalized );
		$denied   = array_map( 'strtolower', self::denied_basenames() );

		foreach ( $segments as $segment ) {
			if ( '' === $segment || '.' === $segment ) {
				continue;
			}
			// Rejeita traversal antes mesmo do realpath, para dar mensagem clara.
			if ( '..' === $segment ) {
				return new \WP_Error( 'f3_files_traversal', __( 'Caminho inválido: ".." não é permitido.', 'f3-mcp-files' ) );
			}
			if ( in_array( strtolower( $segment ), $denied, true ) ) {
				return new \WP_Error(
					'f3_files_denied',
					sprintf(
						/* translators: %s: nome do arquivo bloqueado. */
						__( 'Bloqueado: "%s" está na lista de arquivos protegidos.', 'f3-mcp-files' ),
						$segment
					)
				);
			}
		}

		$base = realpath( ABSPATH );
		if ( false === $base ) {
			return new \WP_Error( 'f3_files_no_base', __( 'Não foi possível resolver a raiz do WordPress.', 'f3-mcp-files' ) );
		}
		$base      = untrailingslashit( wp_normalize_path( $base ) );
		$candidate = $base . '/' . ltrim( $normalized, '/' );

		// realpath() só funciona no que existe. Para escrita de arquivo novo,
		// resolvemos o diretório-pai (que precisa existir) e recolamos o nome.
		if ( $for_write && ! file_exists( $candidate ) ) {
			$parent      = dirname( $candidate );
			$real_parent = realpath( $parent );
			if ( false === $real_parent || ! is_dir( $real_parent ) ) {
				return new \WP_Error(
					'f3_files_no_parent',
					__( 'O diretório de destino não existe. Crie-o antes de gravar o arquivo.', 'f3-mcp-files' )
				);
			}
			$resolved = untrailingslashit( wp_normalize_path( $real_parent ) ) . '/' . basename( $candidate );
		} else {
			$real = realpath( $candidate );
			if ( false === $real ) {
				return new \WP_Error( 'f3_files_not_found', __( 'Arquivo ou diretório não encontrado.', 'f3-mcp-files' ) );
			}
			$resolved = untrailingslashit( wp_normalize_path( $real ) );
		}

		// O plugin não se edita. Isto não contém um agente mal-intencionado
		// (plugins/upload-base64 substituiria o arquivo de qualquer jeito),
		// mas evita o acidente que importa: uma tentativa de "melhorar" o
		// próprio guardião que o deixa quebrado ou permissivo.
		if ( defined( 'F3_MCP_FILES_DIR' ) ) {
			$self = untrailingslashit( wp_normalize_path( realpath( F3_MCP_FILES_DIR ) ?: F3_MCP_FILES_DIR ) );
			if ( $resolved === $self || 0 === strpos( $resolved, $self . '/' ) ) {
				return new \WP_Error(
					'f3_files_self',
					__( 'Este canal não edita os próprios arquivos. Atualize o plugin pelo painel.', 'f3-mcp-files' )
				);
			}
		}

		foreach ( self::roots() as $root ) {
			if ( $resolved === $root || 0 === strpos( $resolved, $root . '/' ) ) {
				return $resolved;
			}
		}

		return new \WP_Error(
			'f3_files_outside_root',
			__( 'Caminho fora das pastas permitidas. Este canal opera nos diretórios de temas e de plugins.', 'f3-mcp-files' )
		);
	}

	/**
	 * Cria os diretórios que faltam para um caminho, validando cada nível.
	 *
	 * Necessário para criar um plugin ou tema novo, cuja pasta ainda não
	 * existe — `resolve()` com `for_write` exige o diretório-pai pronto.
	 *
	 * A validação não pode ser feita só no fim: `realpath()` do ancestral mais
	 * profundo que existe é comparado com as raízes ANTES de criar qualquer
	 * coisa, senão um symlink no meio do caminho abriria escrita fora.
	 *
	 * @param string $relative Caminho de arquivo relativo a ABSPATH.
	 * @return true|\WP_Error
	 */
	public static function prepare_parent( string $relative ) {
		if ( false !== strpos( $relative, "\0" ) ) {
			return new \WP_Error( 'f3_files_null_byte', __( 'Caminho inválido.', 'f3-mcp-files' ) );
		}

		$normalized = ltrim( wp_normalize_path( trim( $relative ) ), '/' );
		$segments   = array_values(
			array_filter(
				explode( '/', $normalized ),
				static function ( $s ) {
					return '' !== $s && '.' !== $s;
				}
			)
		);

		if ( count( $segments ) < 2 ) {
			return new \WP_Error( 'f3_files_no_parent', __( 'Caminho sem diretório-pai.', 'f3-mcp-files' ) );
		}

		$denied = array_map( 'strtolower', self::denied_basenames() );
		foreach ( $segments as $segment ) {
			if ( '..' === $segment ) {
				return new \WP_Error( 'f3_files_traversal', __( 'Caminho inválido: ".." não é permitido.', 'f3-mcp-files' ) );
			}
			if ( in_array( strtolower( $segment ), $denied, true ) ) {
				return new \WP_Error( 'f3_files_denied', __( 'Caminho contém um nome protegido.', 'f3-mcp-files' ) );
			}
		}

		array_pop( $segments ); // Remove o nome do arquivo; sobra o diretório.

		$base = realpath( ABSPATH );
		if ( false === $base ) {
			return new \WP_Error( 'f3_files_no_base', __( 'Não foi possível resolver a raiz do WordPress.', 'f3-mcp-files' ) );
		}
		$base = untrailingslashit( wp_normalize_path( $base ) );

		// Desce enquanto existir, guardando o que falta criar.
		$existing = $base;
		$to_make  = array();
		foreach ( $segments as $segment ) {
			$next = $existing . '/' . $segment;
			if ( is_dir( $next ) && empty( $to_make ) ) {
				$existing = $next;
			} else {
				$to_make[] = $segment;
			}
		}

		$real_existing = realpath( $existing );
		if ( false === $real_existing ) {
			return new \WP_Error( 'f3_files_no_parent', __( 'Diretório base inválido.', 'f3-mcp-files' ) );
		}
		$real_existing = untrailingslashit( wp_normalize_path( $real_existing ) );

		if ( empty( $to_make ) ) {
			// O pai já existe: valida direto contra as raízes.
			foreach ( self::roots() as $root ) {
				if ( $real_existing === $root || 0 === strpos( $real_existing, $root . '/' ) ) {
					return true;
				}
			}
			return new \WP_Error( 'f3_files_outside_root', __( 'Caminho fora das pastas permitidas.', 'f3-mcp-files' ) );
		}

		// Vai criar diretório: o ancestral existente precisa estar DENTRO de
		// uma raiz — não basta ser a própria raiz-pai por acaso.
		$inside = false;
		foreach ( self::roots() as $root ) {
			if ( $real_existing === $root || 0 === strpos( $real_existing, $root . '/' ) ) {
				$inside = true;
				break;
			}
		}
		if ( ! $inside ) {
			return new \WP_Error( 'f3_files_outside_root', __( 'Não é possível criar diretórios fora das pastas permitidas.', 'f3-mcp-files' ) );
		}

		$target = $real_existing . '/' . implode( '/', $to_make );
		if ( ! wp_mkdir_p( $target ) ) {
			return new \WP_Error( 'f3_files_mkdir', __( 'Falha ao criar o diretório de destino.', 'f3-mcp-files' ) );
		}

		return true;
	}

	/**
	 * A extensão é permitida?
	 *
	 * @param string $path Caminho absoluto já resolvido.
	 * @return true|\WP_Error
	 */
	public static function check_extension( string $path ) {
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

		if ( '' === $ext ) {
			return new \WP_Error( 'f3_files_no_extension', __( 'Arquivos sem extensão não são permitidos.', 'f3-mcp-files' ) );
		}

		if ( ! in_array( $ext, array_map( 'strtolower', self::allowed_extensions() ), true ) ) {
			return new \WP_Error(
				'f3_files_bad_extension',
				sprintf(
					/* translators: %s: extensão do arquivo. */
					__( 'Extensão ".%s" não permitida neste canal.', 'f3-mcp-files' ),
					$ext
				),
			);
		}

		return true;
	}

	/**
	 * Checagem de sintaxe PHP sem executar o código e sem shell.
	 *
	 * token_get_all() com TOKEN_PARSE lança ParseError em código inválido —
	 * é um "php -l" em processo. Isso existe por um motivo específico: gravar
	 * PHP quebrado em functions.php derruba o site inteiro, inclusive o
	 * endpoint MCP usado para consertar. Sem esta checagem, um erro de sintaxe
	 * fecharia o próprio canal de correção.
	 *
	 * @param string $code Conteúdo a gravar.
	 * @return true|\WP_Error
	 */
	public static function check_php_syntax( string $code ) {
		if ( ! function_exists( 'token_get_all' ) || ! defined( 'TOKEN_PARSE' ) ) {
			return true;
		}

		try {
			// @phpcs:ignore Generic.PHP.NoSilencedErrors -- avisos de token não interessam; só o ParseError.
			@token_get_all( $code, TOKEN_PARSE );
		} catch ( \ParseError $e ) {
			return new \WP_Error(
				'f3_files_php_syntax',
				sprintf(
					/* translators: %s: mensagem do erro de sintaxe. */
					__( 'Erro de sintaxe PHP — nada foi gravado: %s', 'f3-mcp-files' ),
					$e->getMessage()
				)
			);
		} catch ( \Throwable $e ) {
			return true;
		}

		return true;
	}

	/**
	 * Diretório de backups, criado sob demanda e protegido contra acesso web.
	 *
	 * @return string|\WP_Error
	 */
	public static function backup_dir() {
		$dir = untrailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ) . '/f3-mcp-backups';

		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return new \WP_Error( 'f3_files_backup_dir', __( 'Não foi possível criar o diretório de backups.', 'f3-mcp-files' ) );
		}

		// Backups de functions.php são código-fonte; não podem ser servidos pela web.
		$htaccess = $dir . '/.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
		}
		$index = $dir . '/index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" );
		}

		return $dir;
	}

	/**
	 * Caminho relativo a ABSPATH, para exibir ao usuário sem vazar o layout do servidor.
	 */
	public static function to_relative( string $absolute ): string {
		$base = realpath( ABSPATH );
		if ( false === $base ) {
			return $absolute;
		}
		$base = untrailingslashit( wp_normalize_path( $base ) ) . '/';
		if ( 0 === strpos( $absolute, $base ) ) {
			return substr( $absolute, strlen( $base ) );
		}
		return $absolute;
	}

	/**
	 * Registra a operação num buffer circular, para auditoria posterior.
	 *
	 * @param string $action Ação executada.
	 * @param string $path   Caminho relativo.
	 * @param array  $extra  Dados adicionais.
	 */
	public static function audit( string $action, string $path, array $extra = array() ): void {
		$log   = get_option( 'f3_mcp_files_audit', array() );
		$log   = is_array( $log ) ? $log : array();
		$log[] = array_merge(
			array(
				'time'   => gmdate( 'c' ),
				'user'   => get_current_user_id(),
				'action' => $action,
				'path'   => $path,
			),
			$extra
		);

		if ( count( $log ) > 100 ) {
			$log = array_slice( $log, -100 );
		}

		update_option( 'f3_mcp_files_audit', $log, false );
	}
}
