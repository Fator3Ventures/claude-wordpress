<?php
/**
 * Busca de conteúdo por URL, com proteção contra SSRF.
 *
 * Existe para a habilidade `files/fetch`: o servidor baixa o arquivo sozinho,
 * em vez de o agente serializar os bytes na chamada. É o que torna viável
 * subir um zip de plugin ou uma imagem sem gastar a janela de contexto
 * inteira.
 *
 * O risco que isso introduz é conhecido: uma URL controlada pelo agente faz o
 * servidor emitir requisições. Sem trava, `http://169.254.169.254/` leria
 * credenciais de metadados da nuvem, e `http://127.0.0.1:3306/` alcançaria
 * serviços internos. Por isso toda URL — inclusive cada salto de redirecionamento —
 * é resolvida e checada contra faixas de IP privadas antes de qualquer conexão.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class Http {

	private const MAX_REDIRECTS = 3;
	private const TIMEOUT       = 20;

	/**
	 * Baixa uma URL pública, seguindo redirecionamentos à mão.
	 *
	 * `wp_remote_get` segue redirecionamento sozinho, e é justamente aí que a
	 * checagem de IP escaparia: a primeira URL passa, e o 302 aponta para
	 * 127.0.0.1. Por isso `redirection => 0` e o laço abaixo.
	 *
	 * @param string $url       URL inicial.
	 * @param int    $max_bytes Teto de tamanho.
	 * @return array|\WP_Error  {body, url_final, content_type, bytes}
	 */
	public static function fetch( string $url, int $max_bytes ) {
		$current = $url;

		for ( $hop = 0; $hop <= self::MAX_REDIRECTS; $hop++ ) {
			$check = self::validate_public_url( $current );
			if ( is_wp_error( $check ) ) {
				return $check;
			}

			$response = wp_remote_get(
				$current,
				array(
					'timeout'     => self::TIMEOUT,
					'redirection' => 0,
					'sslverify'   => true,
					'headers'     => array( 'Accept' => '*/*' ),
					'user-agent'  => 'MCP-Files/1.0; ' . home_url(),
					// Corta no transporte, não depois. Sem isto, uma URL que
					// devolve gigabytes seria inteiramente carregada em
					// memória para só então ser rejeitada pelo teto — que é
					// esgotamento de memória disfarçado de checagem de
					// tamanho. A folga de 1 byte existe para o corte ser
					// detectável pela comparação abaixo.
					'limit_response_size' => $max_bytes + 1,
				)
			);

			if ( is_wp_error( $response ) ) {
				return new \WP_Error(
					'f3_files_fetch_failed',
					sprintf(
						/* translators: %s: mensagem do erro de rede. */
						__( 'Falha ao baixar: %s', 'f3-mcp-files' ),
						$response->get_error_message()
					)
				);
			}

			$code = (int) wp_remote_retrieve_response_code( $response );

			if ( in_array( $code, array( 301, 302, 303, 307, 308 ), true ) ) {
				$location = wp_remote_retrieve_header( $response, 'location' );
				if ( empty( $location ) ) {
					return new \WP_Error( 'f3_files_fetch_redirect', __( 'Redirecionamento sem destino.', 'f3-mcp-files' ) );
				}
				// Revalida no topo do laço — inclusive o IP do novo destino.
				$current = self::absolutize( (string) $location, $current );
				continue;
			}

			if ( $code < 200 || $code >= 300 ) {
				return new \WP_Error(
					'f3_files_fetch_status',
					sprintf(
						/* translators: %d: código HTTP. */
						__( 'A origem respondeu HTTP %d.', 'f3-mcp-files' ),
						$code
					)
				);
			}

			$body = wp_remote_retrieve_body( $response );

			if ( strlen( $body ) > $max_bytes ) {
				return new \WP_Error(
					'f3_files_fetch_too_big',
					sprintf(
						/* translators: 1: tamanho baixado, 2: limite. */
						__( 'Arquivo baixado tem %1$s, acima do limite de %2$s.', 'f3-mcp-files' ),
						size_format( strlen( $body ) ),
						size_format( $max_bytes )
					)
				);
			}

			return array(
				'body'         => $body,
				'url_final'    => $current,
				'content_type' => (string) wp_remote_retrieve_header( $response, 'content-type' ),
				'bytes'        => strlen( $body ),
			);
		}

		return new \WP_Error( 'f3_files_fetch_loop', __( 'Redirecionamentos demais.', 'f3-mcp-files' ) );
	}

	/**
	 * A URL é http(s) e aponta para um IP público?
	 *
	 * @return true|\WP_Error
	 */
	public static function validate_public_url( string $url ) {
		$parts = wp_parse_url( $url );

		if ( ! is_array( $parts ) || empty( $parts['host'] ) || empty( $parts['scheme'] ) ) {
			return new \WP_Error( 'f3_files_url_invalid', __( 'URL inválida.', 'f3-mcp-files' ) );
		}

		if ( ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return new \WP_Error( 'f3_files_url_scheme', __( 'Só http e https são aceitos.', 'f3-mcp-files' ) );
		}

		if ( ! empty( $parts['port'] ) && ! in_array( (int) $parts['port'], array( 80, 443 ), true ) ) {
			return new \WP_Error( 'f3_files_url_port', __( 'Só as portas 80 e 443 são aceitas.', 'f3-mcp-files' ) );
		}

		$host = strtolower( $parts['host'] );

		// "localhost" e afins não chegam a resolver em alguns ambientes.
		if ( in_array( $host, array( 'localhost', 'localhost.localdomain', '127.0.0.1', '::1', '[::1]' ), true ) ) {
			return new \WP_Error( 'f3_files_url_private', __( 'Destino local não é permitido.', 'f3-mcp-files' ) );
		}

		foreach ( self::resolve_ips( $host ) as $ip ) {
			if ( ! self::ip_is_public( $ip ) ) {
				return new \WP_Error(
					'f3_files_url_private',
					sprintf(
						/* translators: %s: endereço IP. */
						__( 'O destino resolve para um endereço não público (%s). Bloqueado para evitar que o servidor alcance a rede interna.', 'f3-mcp-files' ),
						$ip
					)
				);
			}
		}

		return true;
	}

	/**
	 * Todos os IPs (v4 e v6) para os quais o host resolve.
	 *
	 * @return string[]
	 */
	private static function resolve_ips( string $host ): array {
		// Host já é um IP literal.
		$literal = trim( $host, '[]' );
		if ( filter_var( $literal, FILTER_VALIDATE_IP ) ) {
			return array( $literal );
		}

		$ips = array();

		$v4 = gethostbynamel( $host );
		if ( is_array( $v4 ) ) {
			$ips = array_merge( $ips, $v4 );
		}

		if ( function_exists( 'dns_get_record' ) ) {
			$records = @dns_get_record( $host, DNS_AAAA );
			if ( is_array( $records ) ) {
				foreach ( $records as $record ) {
					if ( ! empty( $record['ipv6'] ) ) {
						$ips[] = $record['ipv6'];
					}
				}
			}
		}

		// Não resolveu: trata como suspeito, não como liberado.
		if ( empty( $ips ) ) {
			return array( '0.0.0.0' );
		}

		return array_unique( $ips );
	}

	/**
	 * O IP está fora das faixas privadas, reservadas e de loopback?
	 */
	public static function ip_is_public( string $ip ): bool {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		// FILTER_FLAG_NO_RES_RANGE cobre loopback, link-local (169.254/16,
		// onde ficam os metadados de nuvem) e demais faixas reservadas.
		$public = filter_var(
			$ip,
			FILTER_VALIDATE_IP,
			FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
		);

		if ( false === $public ) {
			return false;
		}

		// Rede compartilhada de operadora (100.64.0.0/10) não é coberta acima.
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			$long = ip2long( $ip );
			if ( false !== $long && ( $long & 0xFFC00000 ) === ( ip2long( '100.64.0.0' ) & 0xFFC00000 ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Resolve um Location relativo contra a URL de origem.
	 */
	private static function absolutize( string $location, string $base ): string {
		if ( preg_match( '#^https?://#i', $location ) ) {
			return $location;
		}

		$parts = wp_parse_url( $base );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return $location;
		}

		$origin = $parts['scheme'] . '://' . $parts['host'];
		if ( ! empty( $parts['port'] ) ) {
			$origin .= ':' . $parts['port'];
		}

		if ( 0 === strpos( $location, '/' ) ) {
			return $origin . $location;
		}

		$dir = isset( $parts['path'] ) ? rtrim( dirname( $parts['path'] ), '/' ) : '';

		return $origin . $dir . '/' . $location;
	}
}
