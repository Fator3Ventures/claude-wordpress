<?php
/**
 * SqlGuard — o guardião das habilidades db/*.
 *
 * Mesma filosofia do PathGuard: pequeno, sem dependências, auditável numa
 * sentada. Se este arquivo estiver certo, o resto é seguro.
 *
 * O risco do canal de banco é de natureza diferente do canal de arquivos.
 * Um arquivo gravado errado tem backup e se restaura. Um `UPDATE wp_posts SET
 * post_content = ''` sem WHERE apaga o site inteiro em milissegundos, e não há
 * o que restaurar. Por isso aqui a trava principal não é "quem pode", é
 * **"mostre antes o que vai acontecer"**.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class SqlGuard {

	/** Palavras que iniciam statements de escrita permitidos. */
	private const WRITE_VERBS = array( 'update', 'delete', 'insert', 'replace' );

	/**
	 * Verbos proibidos em qualquer posição inicial.
	 *
	 * DDL destrói estrutura de forma irreversível e não tem caso de uso
	 * legítimo por este canal — criar tabela é trabalho de plugin, com
	 * dbDelta e migração versionada.
	 */
	private const FORBIDDEN_VERBS = array(
		'drop', 'truncate', 'alter', 'create', 'rename', 'grant', 'revoke',
		'set', 'lock', 'unlock', 'call', 'do', 'handler', 'load', 'flush',
		'shutdown', 'kill', 'reset', 'purge', 'install', 'uninstall', 'begin',
		'start', 'commit', 'rollback', 'savepoint', 'use', 'prepare', 'execute',
		'deallocate', 'analyze', 'optimize', 'repair', 'check',
	);

	/**
	 * Construções que leem ou escrevem arquivos do servidor via SQL.
	 *
	 * `SELECT ... INTO OUTFILE` transforma uma consulta de leitura numa
	 * gravação de arquivo arbitrário — inclusive um .php dentro do docroot.
	 * É o caminho clássico de SQL para execução remota de código, e passa
	 * despercebido por qualquer checagem que só olhe o verbo inicial.
	 */
	private const FORBIDDEN_PATTERNS = array(
		'/\binto\s+outfile\b/i'   => 'INTO OUTFILE',
		'/\binto\s+dumpfile\b/i'  => 'INTO DUMPFILE',
		'/\bload_file\s*\(/i'     => 'LOAD_FILE()',
		'/\bload\s+data\b/i'      => 'LOAD DATA',
		'/\bsys_exec\b/i'         => 'sys_exec',
		'/\binformation_schema\.\s*user_privileges\b/i' => 'information_schema.user_privileges',
		'/\bmysql\s*\.\s*user\b/i' => 'mysql.user',
	);

	/**
	 * Colunas que nunca saem daqui, em nenhuma circunstância.
	 *
	 * Hash de senha e chave de ativação permitem sequestro de conta offline.
	 * Não há pedido legítimo que precise deles vindo por um canal de agente.
	 */
	private const NEVER_RETURN = array(
		'user_pass',
		'user_activation_key',
	);

	/** Teto absoluto de linhas devolvidas. */
	public const MAX_ROWS = 2000;

	/** Padrão de linhas quando o chamador não especifica. */
	public const DEFAULT_ROWS = 200;

	/**
	 * Percorre o SQL respeitando literais, e devolve a versão sem comentários
	 * mais a contagem de statements.
	 *
	 * Fazer isso com regex é o erro clássico: `SELECT '--'` tem um comentário
	 * dentro de uma string, e `SELECT 'a;b'` tem um ponto e vírgula que não
	 * separa statement nenhum. Só um scanner que rastreia o estado das aspas
	 * acerta os dois casos.
	 *
	 * @return array{sql:string, statements:int}
	 */
	public static function scan( string $sql ): array {
		$out        = '';
		$len        = strlen( $sql );
		$statements = 0;
		$has_content = false;

		$in_single = false;
		$in_double = false;
		$in_tick   = false;

		for ( $i = 0; $i < $len; $i++ ) {
			$ch   = $sql[ $i ];
			$next = ( $i + 1 < $len ) ? $sql[ $i + 1 ] : '';

			if ( $in_single || $in_double || $in_tick ) {
				$out .= $ch;

				// Barra invertida escapa o próximo caractere (modo MySQL padrão).
				if ( '\\' === $ch && ( $in_single || $in_double ) && '' !== $next ) {
					$out .= $next;
					$i++;
					continue;
				}

				if ( $in_single && "'" === $ch ) {
					// '' dentro de string é uma aspa literal, não o fim dela.
					if ( "'" === $next ) {
						$out .= $next;
						$i++;
						continue;
					}
					$in_single = false;
				} elseif ( $in_double && '"' === $ch ) {
					if ( '"' === $next ) {
						$out .= $next;
						$i++;
						continue;
					}
					$in_double = false;
				} elseif ( $in_tick && '`' === $ch ) {
					$in_tick = false;
				}

				continue;
			}

			// Fora de literal: comentários.
			if ( '-' === $ch && '-' === $next ) {
				// `--` só inicia comentário se vier espaço/fim depois (MySQL).
				$after = ( $i + 2 < $len ) ? $sql[ $i + 2 ] : "\n";
				if ( ' ' === $after || "\t" === $after || "\n" === $after || "\r" === $after || "\n" === $after ) {
					while ( $i < $len && "\n" !== $sql[ $i ] ) {
						$i++;
					}
					$out .= ' ';
					continue;
				}
			}

			if ( '#' === $ch ) {
				while ( $i < $len && "\n" !== $sql[ $i ] ) {
					$i++;
				}
				$out .= ' ';
				continue;
			}

			if ( '/' === $ch && '*' === $next ) {
				$i += 2;
				while ( $i < $len && ! ( '*' === $sql[ $i ] && ( $i + 1 < $len ) && '/' === $sql[ $i + 1 ] ) ) {
					$i++;
				}
				$i++; // consome o '/'
				// Espaço no lugar: /*!*/ não pode colar dois tokens.
				$out .= ' ';
				continue;
			}

			if ( ';' === $ch ) {
				if ( $has_content ) {
					$statements++;
					$has_content = false;
				}
				$out .= ' ';
				continue;
			}

			if ( "'" === $ch ) {
				$in_single = true;
			} elseif ( '"' === $ch ) {
				$in_double = true;
			} elseif ( '`' === $ch ) {
				$in_tick = true;
			}

			if ( '' !== trim( $ch ) ) {
				$has_content = true;
			}

			$out .= $ch;
		}

		if ( $has_content ) {
			$statements++;
		}

		return array(
			'sql'        => trim( preg_replace( '/\s+/', ' ', $out ) ),
			'statements' => $statements,
		);
	}

	/** O primeiro verbo do statement, em minúsculas. */
	public static function verb( string $clean_sql ): string {
		if ( preg_match( '/^\s*\(*\s*([a-zA-Z_]+)/', $clean_sql, $m ) ) {
			return strtolower( $m[1] );
		}
		return '';
	}

	/**
	 * Validações comuns a leitura e escrita.
	 *
	 * @return array{sql:string}|\WP_Error
	 */
	private static function common( string $sql ) {
		if ( '' === trim( $sql ) ) {
			return new \WP_Error( 'f3_sql_empty', __( 'A consulta está vazia.', 'f3-mcp-files' ) );
		}

		if ( false !== strpos( $sql, "\0" ) ) {
			return new \WP_Error( 'f3_sql_null_byte', __( 'Consulta inválida.', 'f3-mcp-files' ) );
		}

		$scan = self::scan( $sql );

		if ( $scan['statements'] > 1 ) {
			return new \WP_Error(
				'f3_sql_multiple',
				__( 'Envie um statement por vez. Vários statements numa chamada é o padrão de injeção clássico e não é aceito aqui.', 'f3-mcp-files' )
			);
		}

		if ( '' === $scan['sql'] ) {
			return new \WP_Error( 'f3_sql_empty', __( 'A consulta ficou vazia depois de remover comentários.', 'f3-mcp-files' ) );
		}

		// Padrões proibidos são checados no SQL JÁ sem comentários — senão
		// `INTO /*x*/ OUTFILE` escaparia da checagem.
		foreach ( self::FORBIDDEN_PATTERNS as $pattern => $label ) {
			if ( preg_match( $pattern, $scan['sql'] ) ) {
				return new \WP_Error(
					'f3_sql_forbidden_construct',
					sprintf(
						/* translators: %s: construção SQL bloqueada. */
						__( 'Construção bloqueada: %s. Ela permite ler ou gravar arquivos do servidor por SQL.', 'f3-mcp-files' ),
						$label
					)
				);
			}
		}

		return array( 'sql' => $scan['sql'] );
	}

	/**
	 * Valida uma consulta de leitura.
	 *
	 * @return string|\WP_Error SQL limpo.
	 */
	public static function validate_select( string $sql ) {
		$common = self::common( $sql );
		if ( is_wp_error( $common ) ) {
			return $common;
		}

		$clean = $common['sql'];
		$verb  = self::verb( $clean );

		// A redação por nome de coluna sozinha tem um furo: `SELECT user_pass
		// AS senha` devolve a coluna com outro nome e escapa da lista. Em vez
		// de tentar rastrear apelidos, o statement que MENCIONA a coluna é
		// recusado inteiro — não existe pedido legítimo de hash de senha por
		// este canal, então recusar não custa nada e fecha o furo de vez.
		foreach ( self::NEVER_RETURN as $column ) {
			if ( preg_match( '/\b' . preg_quote( $column, '/' ) . '\b/i', $clean ) ) {
				return new \WP_Error(
					'f3_sql_sensitive_column',
					sprintf(
						/* translators: %s: nome da coluna. */
						__( 'A coluna %s não pode ser consultada por este canal, nem com apelido. Ela permite sequestro de conta offline.', 'f3-mcp-files' ),
						$column
					)
				);
			}
		}

		if ( ! in_array( $verb, array( 'select', 'show', 'describe', 'desc', 'explain' ), true ) ) {
			return new \WP_Error(
				'f3_sql_not_select',
				sprintf(
					/* translators: %s: verbo encontrado. */
					__( 'db/query só aceita leitura (SELECT, SHOW, DESCRIBE, EXPLAIN). Encontrado: %s. Para alterar dados use db/execute.', 'f3-mcp-files' ),
					strtoupper( $verb )
				)
			);
		}

		return $clean;
	}

	/**
	 * Valida um statement de escrita.
	 *
	 * @return string|\WP_Error SQL limpo.
	 */
	public static function validate_write( string $sql ) {
		$common = self::common( $sql );
		if ( is_wp_error( $common ) ) {
			return $common;
		}

		$clean = $common['sql'];
		$verb  = self::verb( $clean );

		if ( in_array( $verb, self::FORBIDDEN_VERBS, true ) ) {
			return new \WP_Error(
				'f3_sql_forbidden_verb',
				sprintf(
					/* translators: %s: verbo bloqueado. */
					__( '%s é bloqueado neste canal: altera a estrutura do banco de forma irreversível. Mudança de esquema é trabalho de plugin, com migração versionada.', 'f3-mcp-files' ),
					strtoupper( $verb )
				)
			);
		}

		if ( ! in_array( $verb, self::WRITE_VERBS, true ) ) {
			return new \WP_Error(
				'f3_sql_not_write',
				sprintf(
					/* translators: %s: verbo encontrado. */
					__( 'db/execute aceita apenas UPDATE, DELETE, INSERT e REPLACE. Encontrado: %s.', 'f3-mcp-files' ),
					strtoupper( $verb )
				)
			);
		}

		// UPDATE e DELETE sem WHERE atingem a tabela inteira. Quase sempre é
		// engano; quando não é, dá para escrever `WHERE 1=1` de propósito e
		// assumir a intenção explicitamente.
		if ( in_array( $verb, array( 'update', 'delete' ), true ) && ! preg_match( '/\bwhere\b/i', $clean ) ) {
			return new \WP_Error(
				'f3_sql_no_where',
				sprintf(
					/* translators: %s: verbo. */
					__( '%s sem WHERE atingiria a tabela inteira. Se a intenção for essa mesmo, escreva WHERE 1=1 explicitamente.', 'f3-mcp-files' ),
					strtoupper( $verb )
				)
			);
		}

		return $clean;
	}

	/**
	 * Deriva a consulta que mostra as linhas que serão afetadas.
	 *
	 * É o coração do dry-run: sem isto, "mostrar antes" seria adivinhação.
	 * Só formas simples e inequívocas são aceitas — UPDATE/DELETE com JOIN
	 * ou multi-tabela são recusados de propósito, porque uma pré-imagem
	 * errada é pior que nenhuma: daria confiança falsa.
	 *
	 * @return array{select:string, table:string}|\WP_Error
	 */
	public static function preimage( string $clean_sql ) {
		$verb = self::verb( $clean_sql );

		if ( 'delete' === $verb ) {
			if ( preg_match( '/^\s*delete\s+from\s+([`\w.]+)\s+(where\b.*)$/is', $clean_sql, $m ) ) {
				$table = trim( $m[1], '` ' );
				if ( false !== strpos( $m[2], ' join ' ) ) {
					return new \WP_Error( 'f3_sql_complex', __( 'DELETE com JOIN não é aceito: a pré-visualização não seria confiável.', 'f3-mcp-files' ) );
				}
				return array(
					'select' => 'SELECT * FROM `' . str_replace( '`', '', $table ) . '` ' . $m[2],
					'table'  => $table,
				);
			}
			return new \WP_Error( 'f3_sql_unparsed', __( 'Não consegui derivar a pré-visualização deste DELETE. Use a forma DELETE FROM tabela WHERE ...', 'f3-mcp-files' ) );
		}

		if ( 'update' === $verb ) {
			if ( preg_match( '/^\s*update\s+([`\w.]+)\s+set\s+(.*?)\s+(where\b.*)$/is', $clean_sql, $m ) ) {
				$table = trim( $m[1], '` ' );
				if ( preg_match( '/\bjoin\b/i', $m[2] ) || preg_match( '/,/', $m[1] ) ) {
					return new \WP_Error( 'f3_sql_complex', __( 'UPDATE multi-tabela ou com JOIN não é aceito: a pré-visualização não seria confiável.', 'f3-mcp-files' ) );
				}
				return array(
					'select' => 'SELECT * FROM `' . str_replace( '`', '', $table ) . '` ' . $m[3],
					'table'  => $table,
				);
			}
			return new \WP_Error( 'f3_sql_unparsed', __( 'Não consegui derivar a pré-visualização deste UPDATE. Use a forma UPDATE tabela SET ... WHERE ...', 'f3-mcp-files' ) );
		}

		// INSERT e REPLACE não têm linhas anteriores para preservar.
		if ( preg_match( '/^\s*(insert|replace)\s+(?:\w+\s+)*?into\s+([`\w.]+)/is', $clean_sql, $m ) ) {
			return array(
				'select' => '',
				'table'  => trim( $m[2], '` ' ),
			);
		}

		return new \WP_Error( 'f3_sql_unparsed', __( 'Não consegui identificar a tabela alvo.', 'f3-mcp-files' ) );
	}

	/**
	 * Remove colunas que não podem sair daqui.
	 *
	 * @param array $rows Linhas como arrays associativos.
	 * @return array{rows:array, redacted:string[]}
	 */
	public static function redact( array $rows ): array {
		$redacted = array();

		foreach ( $rows as $i => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			foreach ( $row as $col => $value ) {
				if ( in_array( strtolower( (string) $col ), self::NEVER_RETURN, true ) ) {
					$rows[ $i ][ $col ] = '[redigido]';
					$redacted[]         = (string) $col;
				}
			}
		}

		return array(
			'rows'     => $rows,
			'redacted' => array_values( array_unique( $redacted ) ),
		);
	}

	/**
	 * O statement mexe em coluna que guarda PHP serializado?
	 *
	 * Editar `a:1:{s:3:"foo";s:3:"bar";}` por SQL cru quase sempre corrompe o
	 * valor, porque o prefixo de tamanho de cada string deixa de bater e o
	 * WordPress passa a desserializar `false` em silêncio. As habilidades
	 * tipadas (options/update, content/update-post) fazem a serialização
	 * corretamente.
	 *
	 * @return string|null Aviso, ou null.
	 */
	public static function serialized_warning( string $clean_sql, string $table ): ?string {
		$suspect = array( 'options' => 'option_value', 'postmeta' => 'meta_value', 'usermeta' => 'meta_value', 'termmeta' => 'meta_value', 'commentmeta' => 'meta_value' );

		foreach ( $suspect as $suffix => $column ) {
			if ( preg_match( '/' . preg_quote( $suffix, '/' ) . '$/i', $table ) && preg_match( '/\b' . preg_quote( $column, '/' ) . '\b/i', $clean_sql ) ) {
				return sprintf(
					/* translators: 1: tabela, 2: coluna. */
					__( 'ATENÇÃO: %1$s.%2$s costuma guardar PHP serializado. Alterar por SQL cru corrompe o valor (o prefixo de tamanho deixa de bater) e o WordPress passa a ler false em silêncio. Prefira options/update ou a habilidade tipada equivalente.', 'f3-mcp-files' ),
					$table,
					$column
				);
			}
		}

		return null;
	}

	/**
	 * Acrescenta LIMIT quando o SELECT não traz um.
	 */
	public static function enforce_limit( string $clean_sql, int $limit ): string {
		if ( preg_match( '/\blimit\s+\d+/i', $clean_sql ) ) {
			return $clean_sql;
		}
		if ( ! preg_match( '/^\s*select\b/i', $clean_sql ) ) {
			return $clean_sql;
		}
		return rtrim( $clean_sql, '; ' ) . ' LIMIT ' . max( 1, $limit );
	}
}
