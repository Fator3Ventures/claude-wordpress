<?php
/**
 * Habilidades files/* — leitura, escrita, exclusão e download de arquivos
 * de temas e plugins, via Abilities API.
 *
 * Registradas na Abilities API global; o WP MCP Ultimate as expõe
 * automaticamente como ferramentas MCP (o `discover-abilities` dele varre
 * wp_get_abilities(), sem filtrar por plugin de origem).
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class Files {

	/**
	 * Portão comum a todas as habilidades.
	 *
	 * @return array|null Array de erro pronto para devolver, ou null se liberado.
	 */
	private static function gate(): ?array {
		if ( ! PathGuard::is_enabled() ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'O canal de arquivos está fechado. Reabra em Ferramentas > MCP Files no wp-admin (ou remova DISALLOW_FILE_EDIT do wp-config.php, se for o caso).', 'f3-mcp-files' ),
			);
		}

		if ( ! PathGuard::can_edit() ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'Permissão insuficiente: são exigidas as capacidades edit_themes e manage_options.', 'f3-mcp-files' ),
			);
		}

		return null;
	}

	/**
	 * Converte um WP_Error no formato de resposta das habilidades.
	 */
	private static function fail( \WP_Error $error ): array {
		return array(
			'success' => false,
			'message' => esc_html( $error->get_error_message() ),
		);
	}

	/**
	 * Callback de permissão compartilhado.
	 */
	private static function permission(): bool {
		return PathGuard::is_enabled() && PathGuard::can_edit();
	}

	public static function register(): void {

		// =====================================================================
		// FILES — List
		// =====================================================================
		wp_register_ability(
			'files/list',
			array(
				'label'               => 'List Theme Files',
				'description'         => 'Lista arquivos e pastas dentro das raízes permitidas (por padrão, o diretório de temas). Params: path (opcional, relativo à raiz do WordPress), recursive (opcional), max_depth (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'      => array(
							'type'        => 'string',
							'description' => 'Caminho relativo à raiz do WordPress. Vazio lista a raiz de temas.',
						),
						'recursive' => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Percorrer subdiretórios.',
						),
						'max_depth' => array(
							'type'        => 'integer',
							'default'     => 3,
							'minimum'     => 1,
							'maximum'     => 10,
							'description' => 'Profundidade máxima quando recursive=true.',
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'path'    => array( 'type' => 'string' ),
						'entries' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();
					$roots = PathGuard::roots();

					if ( empty( $roots ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Nenhuma raiz permitida está configurada.', 'f3-mcp-files' ), 'entries' => array() );
					}

					$requested = isset( $input['path'] ) ? (string) $input['path'] : '';
					if ( '' === trim( $requested ) ) {
						$dir = $roots[0];
					} else {
						$dir = PathGuard::resolve( $requested, false );
						if ( is_wp_error( $dir ) ) {
							return self::fail( $dir ) + array( 'entries' => array() );
						}
					}

					if ( ! is_dir( $dir ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'O caminho não é um diretório.', 'f3-mcp-files' ), 'entries' => array() );
					}

					$recursive = ! empty( $input['recursive'] );
					$max_depth = isset( $input['max_depth'] ) ? min( 10, max( 1, (int) $input['max_depth'] ) ) : 3;
					$entries   = self::scan( $dir, $recursive, $max_depth, 0 );

					return array(
						'success' => true,
						'message' => esc_html(
							sprintf(
								/* translators: %d: número de itens. */
								_n( '%d item encontrado.', '%d itens encontrados.', count( $entries ), 'f3-mcp-files' ),
								count( $entries )
							)
						),
						'path'    => PathGuard::to_relative( $dir ),
						'entries' => $entries,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		// =====================================================================
		// FILES — Read
		// =====================================================================
		wp_register_ability(
			'files/read',
			array(
				'label'               => 'Read Theme File',
				'description'         => 'Lê o conteúdo de um arquivo dentro das raízes permitidas. Params: path (required, relativo à raiz do WordPress).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'Caminho relativo à raiz do WordPress, ex.: wp-content/themes/meu-tema/functions.php',
						),
					),
					'required'             => array( 'path' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'path'    => array( 'type' => 'string' ),
						'content' => array( 'type' => 'string' ),
						'bytes'   => array( 'type' => 'integer' ),
						'sha256'  => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: path', 'f3-mcp-files' ) );
					}

					$path = PathGuard::resolve( (string) $input['path'], false );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					if ( ! is_file( $path ) || ! is_readable( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Arquivo não encontrado ou sem permissão de leitura.', 'f3-mcp-files' ) );
					}

					$size = (int) filesize( $path );
					if ( $size > PathGuard::MAX_BYTES ) {
						return array(
							'success' => false,
							'message' => esc_html(
								sprintf(
									/* translators: 1: tamanho do arquivo, 2: limite. */
									__( 'Arquivo grande demais (%1$s); o limite deste canal é %2$s.', 'f3-mcp-files' ),
									size_format( $size ),
									size_format( PathGuard::MAX_BYTES )
								)
							),
						);
					}

					$content = file_get_contents( $path );
					if ( false === $content ) {
						return array( 'success' => false, 'message' => esc_html__( 'Falha ao ler o arquivo.', 'f3-mcp-files' ) );
					}

					return array(
						'success' => true,
						'message' => esc_html__( 'Arquivo lido com sucesso.', 'f3-mcp-files' ),
						'path'    => PathGuard::to_relative( $path ),
						'content' => $content,
						'bytes'   => $size,
						'sha256'  => hash( 'sha256', $content ),
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		// =====================================================================
		// FILES — Write
		// =====================================================================
		wp_register_ability(
			'files/write',
			array(
				'label'               => 'Write Theme File',
				'description'         => 'Cria ou sobrescreve um arquivo dentro das raízes permitidas. Faz backup automático, valida sintaxe PHP antes de gravar e grava de forma atômica. Params: path (required), content ou content_base64 (required), expected_sha256 (opcional), backup (opcional, padrão true).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'            => array(
							'type'        => 'string',
							'description' => 'Caminho relativo à raiz do WordPress.',
						),
						'content'         => array(
							'type'        => 'string',
							'description' => 'Conteúdo do arquivo em texto.',
						),
						'content_base64'  => array(
							'type'        => 'string',
							'description' => 'Conteúdo em base64, quando os bytes exatos importam. Tem precedência sobre content.',
						),
						'expected_sha256' => array(
							'type'        => 'string',
							'description' => 'SHA-256 do conteúdo atual. Se informado e não bater, a gravação é abortada — evita sobrescrever alteração feita por outra pessoa.',
						),
						'backup'          => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => 'Guardar cópia do conteúdo anterior antes de sobrescrever.',
						),
						'append'          => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Acrescentar ao final em vez de substituir. Use para enviar um arquivo grande em pedaços, um por chamada.',
						),
						'create_dirs'     => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Criar os diretórios que faltarem no caminho. Necessário para começar um tema ou plugin novo.',
						),
					),
					'required'             => array( 'path' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'   => array( 'type' => 'boolean' ),
						'message'   => array( 'type' => 'string' ),
						'path'      => array( 'type' => 'string' ),
						'bytes'     => array( 'type' => 'integer' ),
						'sha256'    => array( 'type' => 'string' ),
						'backup_id' => array( 'type' => 'string' ),
						'created'   => array( 'type' => 'boolean' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: path', 'f3-mcp-files' ) );
					}

					if ( ! isset( $input['content'] ) && ! isset( $input['content_base64'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Informe content ou content_base64.', 'f3-mcp-files' ) );
					}

					if ( isset( $input['content_base64'] ) ) {
						$content = base64_decode( (string) $input['content_base64'], true );
						if ( false === $content ) {
							return array( 'success' => false, 'message' => esc_html__( 'content_base64 não é base64 válido.', 'f3-mcp-files' ) );
						}
					} else {
						$content = (string) $input['content'];
					}

					if ( strlen( $content ) > PathGuard::MAX_BYTES ) {
						return array(
							'success' => false,
							'message' => esc_html(
								sprintf(
									/* translators: %s: limite de tamanho. */
									__( 'Conteúdo maior que o limite deste canal (%s).', 'f3-mcp-files' ),
									size_format( PathGuard::MAX_BYTES )
								)
							),
						);
					}

					if ( ! empty( $input['create_dirs'] ) ) {
						$prepared = PathGuard::prepare_parent( (string) $input['path'] );
						if ( is_wp_error( $prepared ) ) {
							return self::fail( $prepared );
						}
					}

					$path = PathGuard::resolve( (string) $input['path'], true );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					$exists = is_file( $path );
					$append = ! empty( $input['append'] );

					// No modo append o conteúdo final é o que já existe mais o
					// pedaço novo — e é ele que precisa passar pela checagem de
					// sintaxe, não só o pedaço.
					if ( $append && $exists ) {
						$previous = file_get_contents( $path );
						if ( false === $previous ) {
							return array( 'success' => false, 'message' => esc_html__( 'Falha ao ler o conteúdo atual para acrescentar.', 'f3-mcp-files' ) );
						}
						$content = $previous . $content;

						if ( strlen( $content ) > PathGuard::MAX_BYTES ) {
							return array(
								'success' => false,
								'message' => esc_html(
									sprintf(
										/* translators: %s: limite de tamanho. */
										__( 'O arquivo passaria do limite deste canal (%s) com este acréscimo.', 'f3-mcp-files' ),
										size_format( PathGuard::MAX_BYTES )
									)
								),
							);
						}
					}

					// Concorrência otimista: só grava se o conteúdo atual for o esperado.
					if ( ! empty( $input['expected_sha256'] ) ) {
						$current = $exists ? file_get_contents( $path ) : '';
						$actual  = hash( 'sha256', false === $current ? '' : $current );
						if ( ! hash_equals( $actual, strtolower( (string) $input['expected_sha256'] ) ) ) {
							return array(
								'success' => false,
								'message' => esc_html__( 'O arquivo mudou desde a última leitura. Leia de novo antes de gravar.', 'f3-mcp-files' ),
								'sha256'  => $actual,
							);
						}
					}

					// A checagem de sintaxe vem antes de qualquer escrita: PHP
					// quebrado em functions.php derruba o site e, com ele, o
					// próprio endpoint MCP usado para consertar.
					if ( 'php' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
						$syntax = PathGuard::check_php_syntax( $content );
						if ( is_wp_error( $syntax ) ) {
							return self::fail( $syntax );
						}
					}

					if ( $exists && ! is_writable( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'O arquivo existe mas não tem permissão de escrita.', 'f3-mcp-files' ) );
					}
					if ( ! $exists && ! is_writable( dirname( $path ) ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'O diretório de destino não tem permissão de escrita.', 'f3-mcp-files' ) );
					}

					$backup_id = '';
					$do_backup = ! isset( $input['backup'] ) || ! empty( $input['backup'] );
					if ( $exists && $do_backup ) {
						$backup_id = self::make_backup( $path );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					$written = self::atomic_write( $path, $content );
					if ( is_wp_error( $written ) ) {
						return self::fail( $written );
					}

					$sha = hash( 'sha256', $content );

					PathGuard::audit(
						$exists ? 'write:overwrite' : 'write:create',
						PathGuard::to_relative( $path ),
						array(
							'bytes'     => strlen( $content ),
							'sha256'    => $sha,
							'backup_id' => $backup_id,
						)
					);

					return array(
						'success'   => true,
						'message'   => esc_html(
							$exists
								? __( 'Arquivo atualizado. Backup guardado; use files/restore para reverter.', 'f3-mcp-files' )
								: __( 'Arquivo criado.', 'f3-mcp-files' )
						),
						'path'      => PathGuard::to_relative( $path ),
						'bytes'     => strlen( $content ),
						'sha256'    => $sha,
						'backup_id' => $backup_id,
						'created'   => ! $exists,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);

		// =====================================================================
		// FILES — List Backups
		// =====================================================================
		wp_register_ability(
			'files/backups',
			array(
				'label'               => 'List File Backups',
				'description'         => 'Lista os backups criados automaticamente pelo files/write. Params: path (opcional, filtra por arquivo), per_page (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'     => array(
							'type'        => 'string',
							'description' => 'Filtra backups de um arquivo específico (caminho relativo).',
						),
						'per_page' => array(
							'type'        => 'integer',
							'default'     => 20,
							'minimum'     => 1,
							'maximum'     => 100,
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'backups' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					$dir = PathGuard::backup_dir();
					if ( is_wp_error( $dir ) ) {
						return self::fail( $dir );
					}

					$filter   = isset( $input['path'] ) ? wp_normalize_path( trim( (string) $input['path'] ) ) : '';
					$per_page = isset( $input['per_page'] ) ? min( 100, max( 1, (int) $input['per_page'] ) ) : 20;

					$backups = array();
					foreach ( (array) glob( $dir . '/*.json' ) as $meta_file ) {
						$raw = file_get_contents( $meta_file );
						if ( false === $raw ) {
							continue;
						}
						$meta = json_decode( $raw, true );
						if ( ! is_array( $meta ) || empty( $meta['id'] ) ) {
							continue;
						}
						if ( '' !== $filter && ( ! isset( $meta['path'] ) || $meta['path'] !== $filter ) ) {
							continue;
						}
						$backups[] = $meta;
					}

					usort(
						$backups,
						static function ( $a, $b ) {
							return strcmp( (string) ( $b['time'] ?? '' ), (string) ( $a['time'] ?? '' ) );
						}
					);

					$backups = array_slice( $backups, 0, $per_page );

					return array(
						'success' => true,
						'message' => esc_html(
							sprintf(
								/* translators: %d: número de backups. */
								_n( '%d backup encontrado.', '%d backups encontrados.', count( $backups ), 'f3-mcp-files' ),
								count( $backups )
							)
						),
						'backups' => $backups,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		// =====================================================================
		// FILES — Restore
		// =====================================================================
		wp_register_ability(
			'files/restore',
			array(
				'label'               => 'Restore File Backup',
				'description'         => 'Restaura um arquivo a partir de um backup criado pelo files/write. Params: backup_id (required).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'backup_id' => array(
							'type'        => 'string',
							'description' => 'Identificador devolvido por files/write ou files/backups.',
						),
					),
					'required'             => array( 'backup_id' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'path'    => array( 'type' => 'string' ),
						'bytes'   => array( 'type' => 'integer' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['backup_id'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: backup_id', 'f3-mcp-files' ) );
					}

					// O id é usado para montar nome de arquivo: aceita só hex.
					$id = (string) $input['backup_id'];
					if ( ! preg_match( '/^[a-f0-9]{16,64}$/i', $id ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'backup_id inválido.', 'f3-mcp-files' ) );
					}

					$dir = PathGuard::backup_dir();
					if ( is_wp_error( $dir ) ) {
						return self::fail( $dir );
					}

					$meta_file = $dir . '/' . $id . '.json';
					$data_file = $dir . '/' . $id . '.bak';

					if ( ! is_file( $meta_file ) || ! is_file( $data_file ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Backup não encontrado.', 'f3-mcp-files' ) );
					}

					$meta = json_decode( (string) file_get_contents( $meta_file ), true );
					if ( ! is_array( $meta ) || empty( $meta['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Metadados do backup ilegíveis.', 'f3-mcp-files' ) );
					}

					// O caminho gravado no backup passa pelo guardião de novo:
					// o backup não é uma via para escrever fora das raízes.
					$path = PathGuard::resolve( (string) $meta['path'], true );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					$content = file_get_contents( $data_file );
					if ( false === $content ) {
						return array( 'success' => false, 'message' => esc_html__( 'Falha ao ler o backup.', 'f3-mcp-files' ) );
					}

					$written = self::atomic_write( $path, $content );
					if ( is_wp_error( $written ) ) {
						return self::fail( $written );
					}

					PathGuard::audit( 'restore', PathGuard::to_relative( $path ), array( 'backup_id' => $id ) );

					return array(
						'success' => true,
						'message' => esc_html__( 'Arquivo restaurado a partir do backup.', 'f3-mcp-files' ),
						'path'    => PathGuard::to_relative( $path ),
						'bytes'   => strlen( $content ),
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);

		self::register_transfer();
		self::register_patch();
		self::register_selftest();
	}

	/**
	 * Registra `files/patch` — edição por trecho, não por arquivo inteiro.
	 *
	 * Existe por economia, e a economia é grande: mudar quatro linhas de um CSS
	 * de 28 KB com `files/write` custa o arquivo inteiro na leitura MAIS o
	 * arquivo inteiro na escrita. Com `patch`, custa o tamanho do trecho — na
	 * prática duas ordens de grandeza a menos.
	 *
	 * A disciplina que faz isso ser seguro: **o trecho procurado precisa ser
	 * único**. Substituição que casa em vários lugares sem o autor saber é a
	 * forma clássica de estragar um arquivo achando que se fez uma correção
	 * cirúrgica. Quem quiser trocar todas as ocorrências pede `all: true` por
	 * escrito.
	 */
	private static function register_patch(): void {
		wp_register_ability(
			'files/patch',
			array(
				'label'               => 'Patch File',
				'description'         => 'Substitui um trecho dentro de um arquivo, sem reenviar o arquivo inteiro. Muito mais barato que files/write para edições pontuais. O trecho procurado precisa ser único, a menos que all=true. Params: path (required), find (required), replace (required), all, regex, expected_sha256, backup.',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'            => array(
							'type'        => 'string',
							'description' => 'Caminho relativo à raiz do WordPress.',
						),
						'find'            => array(
							'type'        => 'string',
							'description' => 'Trecho a procurar. Inclua contexto suficiente para ser único no arquivo.',
						),
						'replace'         => array(
							'type'        => 'string',
							'description' => 'Texto que entra no lugar. String vazia remove o trecho.',
						),
						'all'             => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Substituir todas as ocorrências. Sem isto, mais de uma ocorrência é recusada.',
						),
						'regex'           => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Tratar find como expressão regular (PCRE, sem delimitadores).',
						),
						'expected_sha256' => array(
							'type'        => 'string',
							'description' => 'SHA-256 do conteúdo atual. Se informado e não bater, a edição é abortada.',
						),
						'backup'          => array(
							'type'    => 'boolean',
							'default' => true,
						),
					),
					'required'             => array( 'path', 'find', 'replace' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'      => array( 'type' => 'boolean' ),
						'message'      => array( 'type' => 'string' ),
						'path'         => array( 'type' => 'string' ),
						'replacements' => array( 'type' => 'integer' ),
						'bytes'        => array( 'type' => 'integer' ),
						'sha256'       => array( 'type' => 'string' ),
						'backup_id'    => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['path'] ) || ! isset( $input['find'] ) || ! isset( $input['replace'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetros obrigatórios: path, find e replace.', 'f3-mcp-files' ) );
					}

					if ( '' === (string) $input['find'] ) {
						return array( 'success' => false, 'message' => esc_html__( 'O parâmetro find não pode ser vazio.', 'f3-mcp-files' ) );
					}

					$path = PathGuard::resolve( (string) $input['path'], false );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					if ( ! is_file( $path ) || ! is_readable( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Arquivo não encontrado ou sem permissão de leitura.', 'f3-mcp-files' ) );
					}

					$original = file_get_contents( $path );
					if ( false === $original ) {
						return array( 'success' => false, 'message' => esc_html__( 'Falha ao ler o arquivo.', 'f3-mcp-files' ) );
					}

					if ( ! empty( $input['expected_sha256'] ) ) {
						$actual = hash( 'sha256', $original );
						if ( ! hash_equals( $actual, strtolower( (string) $input['expected_sha256'] ) ) ) {
							return array(
								'success' => false,
								'message' => esc_html__( 'O arquivo mudou desde a última leitura. Leia de novo antes de editar.', 'f3-mcp-files' ),
								'sha256'  => $actual,
							);
						}
					}

					$find    = (string) $input['find'];
					$replace = (string) $input['replace'];
					$all     = ! empty( $input['all'] );
					$regex   = ! empty( $input['regex'] );
					$pattern = '/' . str_replace( '/', '\/', $find ) . '/';

					// Conta antes de substituir. Zero ocorrências é ERRO, não
					// sucesso silencioso: quem pediu a edição precisa saber que
					// ela não aconteceu, senão segue confiando num arquivo que
					// não mudou.
					if ( $regex ) {
						// phpcs:ignore Generic.PHP.NoSilencedErrors -- padrão inválido é erro do chamador, tratado na linha seguinte.
						$count = @preg_match_all( $pattern, $original );
						if ( false === $count ) {
							return array( 'success' => false, 'message' => esc_html__( 'Expressão regular inválida.', 'f3-mcp-files' ) );
						}
					} else {
						$count = substr_count( $original, $find );
					}

					if ( 0 === $count ) {
						return array(
							'success'      => false,
							'message'      => esc_html__( 'O trecho procurado não existe no arquivo. Nada foi alterado — confira o texto exato, inclusive espaços e quebras de linha.', 'f3-mcp-files' ),
							'replacements' => 0,
						);
					}

					if ( $count > 1 && ! $all ) {
						return array(
							'success'      => false,
							'message'      => esc_html(
								sprintf(
									/* translators: %d: número de ocorrências. */
									__( 'O trecho aparece %d vezes no arquivo. Acrescente contexto para torná-lo único, ou passe all=true se a intenção for trocar todas.', 'f3-mcp-files' ),
									$count
								)
							),
							'replacements' => 0,
						);
					}

					if ( $regex ) {
						$novo = preg_replace( $pattern, $replace, $original, $all ? -1 : 1 );
						if ( null === $novo ) {
							return array( 'success' => false, 'message' => esc_html__( 'Falha ao aplicar a expressão regular.', 'f3-mcp-files' ) );
						}
					} else {
						$novo = $all
							? str_replace( $find, $replace, $original )
							: self::replace_first( $original, $find, $replace );
					}

					if ( $novo === $original ) {
						return array(
							'success'      => false,
							'message'      => esc_html__( 'A substituição não mudou nada — find e replace produzem o mesmo texto.', 'f3-mcp-files' ),
							'replacements' => 0,
						);
					}

					if ( strlen( $novo ) > PathGuard::MAX_BYTES ) {
						return array(
							'success' => false,
							'message' => esc_html(
								sprintf(
									/* translators: %s: limite. */
									__( 'O resultado passaria do limite deste canal (%s).', 'f3-mcp-files' ),
									size_format( PathGuard::MAX_BYTES )
								)
							),
						);
					}

					// A sintaxe conferida é a do RESULTADO. Um patch pequeno e
					// aparentemente inocente pode desbalancear uma chave.
					if ( 'php' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
						$syntax = PathGuard::check_php_syntax( $novo );
						if ( is_wp_error( $syntax ) ) {
							return self::fail( $syntax );
						}
					}

					if ( ! is_writable( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'O arquivo não tem permissão de escrita.', 'f3-mcp-files' ) );
					}

					$backup_id = '';
					if ( ! isset( $input['backup'] ) || ! empty( $input['backup'] ) ) {
						$backup_id = self::make_backup( $path );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					$written = self::atomic_write( $path, $novo );
					if ( is_wp_error( $written ) ) {
						return self::fail( $written );
					}

					$aplicadas = $all ? $count : 1;
					$relative  = PathGuard::to_relative( $path );

					PathGuard::audit(
						'patch',
						$relative,
						array(
							'replacements' => $aplicadas,
							'bytes'        => strlen( $novo ),
							'backup_id'    => $backup_id,
						)
					);

					return array(
						'success'      => true,
						'message'      => esc_html(
							sprintf(
								/* translators: 1: substituições, 2: id do backup. */
								_n( '%1$d substituição aplicada. Backup: %2$s', '%1$d substituições aplicadas. Backup: %2$s', $aplicadas, 'f3-mcp-files' ),
								$aplicadas,
								'' !== $backup_id ? $backup_id : '—'
							)
						),
						'path'         => $relative,
						'replacements' => $aplicadas,
						'bytes'        => strlen( $novo ),
						'sha256'       => hash( 'sha256', $novo ),
						'backup_id'    => $backup_id,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/** Substitui apenas a primeira ocorrência literal. */
	private static function replace_first( string $haystack, string $find, string $replace ): string {
		$pos = strpos( $haystack, $find );
		if ( false === $pos ) {
			return $haystack;
		}
		return substr_replace( $haystack, $replace, $pos, strlen( $find ) );
	}

	/**
	 * Registra `files/selftest`.
	 */
	private static function register_selftest(): void {
		wp_register_ability(
			'files/selftest',
			array(
				'label'               => 'Self-Test File Guard',
				'description'         => 'Roda as travas de segurança do canal contra o sistema de arquivos REAL deste servidor e devolve o relatório. Sem parâmetros. Use depois de instalar, atualizar o PHP ou mudar a hospedagem.',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'passed'  => array( 'type' => 'integer' ),
						'failed'  => array( 'type' => 'integer' ),
						'checks'  => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					if ( ! PathGuard::can_edit() ) {
						return array(
							'success' => false,
							'message' => esc_html__( 'Permissão insuficiente: são exigidas as capacidades edit_themes e manage_options.', 'f3-mcp-files' ),
						);
					}

					// Roda mesmo com o canal fechado: saber que as travas
					// funcionam é justamente o que se quer antes de abrir.
					$report = SelfTest::run();
					PathGuard::audit( 'selftest', '-', array( 'passed' => $report['passed'], 'failed' => $report['failed'] ) );

					return $report;
				},
				'permission_callback' => function (): bool {
					return PathGuard::can_edit();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	/**
	 * Registra `files/delete` e `files/fetch`.
	 *
	 * Separado de register() só para manter os métodos legíveis.
	 */
	private static function register_transfer(): void {

		// =====================================================================
		// FILES — Delete
		// =====================================================================
		wp_register_ability(
			'files/delete',
			array(
				'label'               => 'Delete File',
				'description'         => 'Apaga um arquivo dentro das raízes permitidas. Faz backup antes, então a exclusão é reversível por files/restore. Params: path (required), expected_sha256 (opcional), backup (opcional, padrão true).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'path'            => array(
							'type'        => 'string',
							'description' => 'Caminho relativo à raiz do WordPress.',
						),
						'expected_sha256' => array(
							'type'        => 'string',
							'description' => 'SHA-256 do conteúdo atual. Se informado e não bater, a exclusão é abortada.',
						),
						'backup'          => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => 'Guardar cópia antes de apagar. Desligar torna a exclusão irreversível.',
						),
					),
					'required'             => array( 'path' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'   => array( 'type' => 'boolean' ),
						'message'   => array( 'type' => 'string' ),
						'path'      => array( 'type' => 'string' ),
						'backup_id' => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: path', 'f3-mcp-files' ) );
					}

					$path = PathGuard::resolve( (string) $input['path'], false );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					// Só arquivo. Apagar diretório recursivamente é o tipo de
					// operação em que um caminho errado vira desastre; e não é
					// necessário para o caso de uso.
					if ( is_dir( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Este canal não apaga diretórios, apenas arquivos.', 'f3-mcp-files' ) );
					}

					if ( ! is_file( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Arquivo não encontrado.', 'f3-mcp-files' ) );
					}

					if ( ! empty( $input['expected_sha256'] ) ) {
						$current = file_get_contents( $path );
						$actual  = hash( 'sha256', false === $current ? '' : $current );
						if ( ! hash_equals( $actual, strtolower( (string) $input['expected_sha256'] ) ) ) {
							return array(
								'success' => false,
								'message' => esc_html__( 'O arquivo mudou desde a última leitura. Leia de novo antes de apagar.', 'f3-mcp-files' ),
							);
						}
					}

					$backup_id = '';
					if ( ! isset( $input['backup'] ) || ! empty( $input['backup'] ) ) {
						$backup_id = self::make_backup( $path );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
					if ( ! @unlink( $path ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Falha ao apagar o arquivo (verifique as permissões).', 'f3-mcp-files' ) );
					}

					if ( function_exists( 'opcache_invalidate' ) ) {
						@opcache_invalidate( $path, true );
					}

					$relative = PathGuard::to_relative( $path );
					PathGuard::audit( 'delete', $relative, array( 'backup_id' => $backup_id ) );

					return array(
						'success'   => true,
						'message'   => esc_html(
							$backup_id
								? __( 'Arquivo apagado. Backup guardado; use files/restore para trazer de volta.', 'f3-mcp-files' )
								: __( 'Arquivo apagado sem backup — esta exclusão não é reversível por este canal.', 'f3-mcp-files' )
						),
						'path'      => $relative,
						'backup_id' => $backup_id,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);

		// =====================================================================
		// FILES — Fetch (o servidor baixa; o agente não transporta os bytes)
		// =====================================================================
		wp_register_ability(
			'files/fetch',
			array(
				'label'               => 'Fetch File From URL',
				'description'         => 'Baixa um arquivo de uma URL pública direto para o servidor, sem passar o conteúdo pela conversa. Use para imagens, fontes e arquivos grandes. Params: url (required), path (required), overwrite (opcional), create_dirs (opcional), backup (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'url'         => array(
							'type'        => 'string',
							'description' => 'URL pública http/https do arquivo de origem.',
						),
						'path'        => array(
							'type'        => 'string',
							'description' => 'Destino, relativo à raiz do WordPress.',
						),
						'overwrite'   => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Permitir substituir um arquivo existente.',
						),
						'create_dirs' => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Criar os diretórios que faltarem no caminho de destino.',
						),
						'backup'      => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => 'Guardar cópia do conteúdo anterior ao substituir.',
						),
					),
					'required'             => array( 'url', 'path' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'   => array( 'type' => 'boolean' ),
						'message'   => array( 'type' => 'string' ),
						'path'      => array( 'type' => 'string' ),
						'bytes'     => array( 'type' => 'integer' ),
						'sha256'    => array( 'type' => 'string' ),
						'source'    => array( 'type' => 'string' ),
						'backup_id' => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['url'] ) || empty( $input['path'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetros obrigatórios: url e path', 'f3-mcp-files' ) );
					}

					if ( ! empty( $input['create_dirs'] ) ) {
						$prepared = PathGuard::prepare_parent( (string) $input['path'] );
						if ( is_wp_error( $prepared ) ) {
							return self::fail( $prepared );
						}
					}

					// O destino é validado ANTES de sair baixando: não faz
					// sentido buscar megabytes para descobrir depois que o
					// caminho era proibido.
					$path = PathGuard::resolve( (string) $input['path'], true );
					if ( is_wp_error( $path ) ) {
						return self::fail( $path );
					}

					$ext_ok = PathGuard::check_extension( $path );
					if ( is_wp_error( $ext_ok ) ) {
						return self::fail( $ext_ok );
					}

					$exists = is_file( $path );
					if ( $exists && empty( $input['overwrite'] ) ) {
						return array(
							'success' => false,
							'message' => esc_html__( 'O arquivo já existe. Passe overwrite=true para substituir.', 'f3-mcp-files' ),
						);
					}

					$result = Http::fetch( (string) $input['url'], PathGuard::max_fetch_bytes() );
					if ( is_wp_error( $result ) ) {
						return self::fail( $result );
					}

					$content = $result['body'];

					// Conteúdo vindo de fora passa pelas mesmas travas de
					// conteúdo gerado aqui — inclusive a de sintaxe.
					if ( 'php' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
						$syntax = PathGuard::check_php_syntax( $content );
						if ( is_wp_error( $syntax ) ) {
							return self::fail( $syntax );
						}
					}

					$backup_id = '';
					if ( $exists && ( ! isset( $input['backup'] ) || ! empty( $input['backup'] ) ) ) {
						$backup_id = self::make_backup( $path );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					$written = self::atomic_write( $path, $content );
					if ( is_wp_error( $written ) ) {
						return self::fail( $written );
					}

					$relative = PathGuard::to_relative( $path );
					PathGuard::audit(
						'fetch',
						$relative,
						array(
							'bytes'  => $result['bytes'],
							'source' => $result['url_final'],
						)
					);

					return array(
						'success'   => true,
						'message'   => esc_html(
							sprintf(
								/* translators: %s: tamanho baixado. */
								__( 'Baixado e gravado (%s).', 'f3-mcp-files' ),
								size_format( $result['bytes'] )
							)
						),
						'path'      => $relative,
						'bytes'     => $result['bytes'],
						'sha256'    => hash( 'sha256', $content ),
						'source'    => $result['url_final'],
						'backup_id' => $backup_id,
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	/**
	 * Varre um diretório, respeitando raízes e profundidade.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function scan( string $dir, bool $recursive, int $max_depth, int $depth ): array {
		$out   = array();
		$items = @scandir( $dir );

		if ( false === $items ) {
			return $out;
		}

		$denied = array_map( 'strtolower', PathGuard::denied_basenames() );

		foreach ( $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}
			if ( in_array( strtolower( $item ), $denied, true ) ) {
				continue;
			}

			$full = $dir . '/' . $item;
			$is_dir = is_dir( $full );

			$out[] = array(
				'name'     => $item,
				'path'     => PathGuard::to_relative( $full ),
				'type'     => $is_dir ? 'dir' : 'file',
				'size'     => $is_dir ? null : (int) filesize( $full ),
				'modified' => gmdate( 'c', (int) filemtime( $full ) ),
				'writable' => is_writable( $full ),
			);

			if ( $is_dir && $recursive && $depth + 1 < $max_depth ) {
				$out = array_merge( $out, self::scan( $full, true, $max_depth, $depth + 1 ) );
			}
		}

		return $out;
	}

	/**
	 * Guarda o conteúdo atual do arquivo antes de sobrescrever.
	 *
	 * @return string|\WP_Error Identificador do backup.
	 */
	private static function make_backup( string $path ) {
		$dir = PathGuard::backup_dir();
		if ( is_wp_error( $dir ) ) {
			return $dir;
		}

		$content = file_get_contents( $path );
		if ( false === $content ) {
			return new \WP_Error( 'f3_files_backup_read', __( 'Falha ao ler o arquivo para backup.', 'f3-mcp-files' ) );
		}

		$id = bin2hex( random_bytes( 12 ) );

		if ( false === file_put_contents( $dir . '/' . $id . '.bak', $content ) ) {
			return new \WP_Error( 'f3_files_backup_write', __( 'Falha ao gravar o backup.', 'f3-mcp-files' ) );
		}

		$meta = array(
			'id'     => $id,
			'path'   => PathGuard::to_relative( $path ),
			'time'   => gmdate( 'c' ),
			'user'   => get_current_user_id(),
			'bytes'  => strlen( $content ),
			'sha256' => hash( 'sha256', $content ),
		);

		file_put_contents( $dir . '/' . $id . '.json', wp_json_encode( $meta ) );

		return $id;
	}

	/**
	 * Escrita atômica: grava num temporário e renomeia por cima.
	 *
	 * Evita deixar um functions.php pela metade se o processo morrer no meio
	 * da escrita. Preserva as permissões do arquivo original — rename() herda
	 * as do temporário, o que alargaria silenciosamente um arquivo restrito.
	 *
	 * @return true|\WP_Error
	 */
	private static function atomic_write( string $path, string $content ) {
		$temp = $path . '.f3-' . bin2hex( random_bytes( 6 ) ) . '.tmp';

		$cleanup = static function () use ( $temp ) {
			if ( is_file( $temp ) ) {
				@unlink( $temp );
			}
		};
		add_action( 'shutdown', $cleanup );

		if ( false === file_put_contents( $temp, $content ) ) {
			return new \WP_Error( 'f3_files_stage', __( 'Falha ao preparar a gravação.', 'f3-mcp-files' ) );
		}

		if ( is_file( $path ) ) {
			$perms = @fileperms( $path );
			if ( false !== $perms ) {
				@chmod( $temp, $perms & 0777 );
			}
		} else {
			@chmod( $temp, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644 );
		}

		if ( ! @rename( $temp, $path ) ) {
			@unlink( $temp );
			return new \WP_Error( 'f3_files_rename', __( 'Falha ao gravar o arquivo.', 'f3-mcp-files' ) );
		}

		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $path, true );
		}

		return true;
	}
}
