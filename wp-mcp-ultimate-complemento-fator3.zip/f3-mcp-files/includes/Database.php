<?php
/**
 * Habilidades db/* — consulta e alteração do banco do WordPress.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class Database {

	/** Opção que liga/desliga especificamente a ESCRITA no banco. */
	public const OPTION_WRITES = 'f3_mcp_db_writes';

	/** Tabelas que costumam guardar dados pessoais de terceiros. */
	private const PII_HINTS = array( 'users', 'usermeta', 'comments', 'flamingo', 'cf7', 'contact', 'leads', 'orders', 'postmeta' );

	private static function gate(): ?array {
		if ( ! PathGuard::is_enabled() ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'O canal está fechado. Reabra em Ferramentas > MCP Files no wp-admin.', 'f3-mcp-files' ),
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'Permissão insuficiente: é exigida a capacidade manage_options.', 'f3-mcp-files' ),
			);
		}

		return null;
	}

	private static function permission(): bool {
		return PathGuard::is_enabled() && current_user_can( 'manage_options' );
	}

	public static function writes_enabled(): bool {
		return (bool) apply_filters( 'f3_mcp_db_writes_enabled', (bool) get_option( self::OPTION_WRITES, true ) );
	}

	private static function fail( \WP_Error $e ): array {
		return array( 'success' => false, 'message' => esc_html( $e->get_error_message() ) );
	}

	/** Aviso quando o resultado provavelmente contém dados pessoais. */
	private static function pii_note( string $sql ): string {
		foreach ( self::PII_HINTS as $hint ) {
			if ( false !== stripos( $sql, $hint ) ) {
				return ' ' . esc_html__( 'Este resultado pode conter dados pessoais de terceiros — trate como tal e não o repasse adiante sem necessidade.', 'f3-mcp-files' );
			}
		}
		return '';
	}

	public static function register(): void {

		// =====================================================================
		// DB — Schema
		// =====================================================================
		wp_register_ability(
			'db/schema',
			array(
				'label'               => 'Database Schema',
				'description'         => 'Lista as tabelas do banco do WordPress com contagem de linhas, e opcionalmente as colunas de uma tabela. Params: table (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'table' => array(
							'type'        => 'string',
							'description' => 'Nome da tabela para detalhar as colunas. Vazio lista todas as tabelas.',
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success' => array( 'type' => 'boolean' ),
						'message' => array( 'type' => 'string' ),
						'prefix'  => array( 'type' => 'string' ),
						'tables'  => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
						'columns' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					global $wpdb;
					$input = is_array( $input ) ? $input : array();

					if ( ! empty( $input['table'] ) ) {
						$table = preg_replace( '/[^A-Za-z0-9_]/', '', (string) $input['table'] );
						if ( '' === $table ) {
							return array( 'success' => false, 'message' => esc_html__( 'Nome de tabela inválido.', 'f3-mcp-files' ) );
						}

						$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
						if ( ! $exists ) {
							return array( 'success' => false, 'message' => esc_html__( 'Tabela não encontrada.', 'f3-mcp-files' ) );
						}

						// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nome saneado para [A-Za-z0-9_] e confirmado por SHOW TABLES.
						$columns = $wpdb->get_results( "DESCRIBE `{$table}`", ARRAY_A );

						return array(
							'success' => true,
							'message' => esc_html__( 'Colunas listadas.', 'f3-mcp-files' ),
							'prefix'  => $wpdb->prefix,
							'tables'  => array(),
							'columns' => is_array( $columns ) ? $columns : array(),
						);
					}

					$rows   = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A );
					$tables = array();
					foreach ( (array) $rows as $row ) {
						$tables[] = array(
							'name'      => $row['Name'] ?? '',
							'rows'      => isset( $row['Rows'] ) ? (int) $row['Rows'] : null,
							'engine'    => $row['Engine'] ?? '',
							'data_size' => isset( $row['Data_length'] ) ? size_format( (int) $row['Data_length'] ) : null,
						);
					}

					return array(
						'success' => true,
						'message' => esc_html(
							sprintf(
								/* translators: %d: número de tabelas. */
								_n( '%d tabela.', '%d tabelas.', count( $tables ), 'f3-mcp-files' ),
								count( $tables )
							)
						),
						'prefix'  => $wpdb->prefix,
						'tables'  => $tables,
						'columns' => array(),
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ),
				),
			)
		);

		// =====================================================================
		// DB — Query (somente leitura)
		// =====================================================================
		wp_register_ability(
			'db/query',
			array(
				'label'               => 'Query Database (read-only)',
				'description'         => 'Executa uma consulta de LEITURA (SELECT/SHOW/DESCRIBE/EXPLAIN) no banco do WordPress. Um statement por chamada. Hash de senha nunca é devolvido. Params: sql (required), limit (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'sql'   => array(
							'type'        => 'string',
							'description' => 'Um único statement de leitura.',
						),
						'limit' => array(
							'type'        => 'integer',
							'default'     => 200,
							'minimum'     => 1,
							'maximum'     => 2000,
							'description' => 'Máximo de linhas. Aplicado automaticamente se o SELECT não tiver LIMIT.',
						),
					),
					'required'             => array( 'sql' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'   => array( 'type' => 'boolean' ),
						'message'   => array( 'type' => 'string' ),
						'sql'       => array( 'type' => 'string' ),
						'rows'      => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
						'row_count' => array( 'type' => 'integer' ),
						'redacted'  => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					global $wpdb;
					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['sql'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: sql', 'f3-mcp-files' ) );
					}

					$clean = SqlGuard::validate_select( (string) $input['sql'] );
					if ( is_wp_error( $clean ) ) {
						return self::fail( $clean );
					}

					$limit = isset( $input['limit'] )
						? min( SqlGuard::MAX_ROWS, max( 1, (int) $input['limit'] ) )
						: SqlGuard::DEFAULT_ROWS;

					$final = SqlGuard::enforce_limit( $clean, $limit );

					$suppress = $wpdb->suppress_errors( true );
					// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- statement validado por SqlGuard::validate_select(); é a função desta habilidade.
					$rows = $wpdb->get_results( $final, ARRAY_A );
					$error = $wpdb->last_error;
					$wpdb->suppress_errors( $suppress );

					if ( ! empty( $error ) ) {
						return array(
							'success' => false,
							'message' => esc_html(
								sprintf(
									/* translators: %s: erro do MySQL. */
									__( 'Erro do MySQL: %s', 'f3-mcp-files' ),
									$error
								)
							),
							'sql'     => $final,
						);
					}

					$rows   = is_array( $rows ) ? $rows : array();
					$safe   = SqlGuard::redact( $rows );
					$note   = self::pii_note( $final );

					PathGuard::audit( 'db:query', substr( $final, 0, 200 ), array( 'rows' => count( $safe['rows'] ) ) );

					return array(
						'success'   => true,
						'message'   => esc_html(
							sprintf(
								/* translators: %d: número de linhas. */
								_n( '%d linha.', '%d linhas.', count( $safe['rows'] ), 'f3-mcp-files' ),
								count( $safe['rows'] )
							)
						) . $note,
						'sql'       => $final,
						'rows'      => $safe['rows'],
						'row_count' => count( $safe['rows'] ),
						'redacted'  => $safe['redacted'],
					);
				},
				'permission_callback' => function (): bool {
					return self::permission();
				},
				'meta'                => array(
					'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ),
				),
			)
		);

		// =====================================================================
		// DB — Execute (escrita, em duas fases)
		// =====================================================================
		wp_register_ability(
			'db/execute',
			array(
				'label'               => 'Execute Database Write (two-phase)',
				'description'         => 'Executa UPDATE, DELETE, INSERT ou REPLACE. Por padrão faz apenas a PRÉ-VISUALIZAÇÃO: mostra as linhas que seriam afetadas e devolve um confirm_token. Repita a chamada com o mesmo sql e o token para aplicar de verdade. Params: sql (required), confirm_token (opcional), limit_preview (opcional).',
				'category'            => 'site',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'sql'            => array(
							'type'        => 'string',
							'description' => 'Um único statement de escrita. UPDATE e DELETE exigem WHERE.',
						),
						'confirm_token'  => array(
							'type'        => 'string',
							'description' => 'Token devolvido pela pré-visualização. Sem ele, nada é gravado.',
						),
						'limit_preview'  => array(
							'type'        => 'integer',
							'default'     => 20,
							'minimum'     => 1,
							'maximum'     => 200,
							'description' => 'Quantas linhas afetadas mostrar na pré-visualização.',
						),
					),
					'required'             => array( 'sql' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'       => 'object',
					'properties' => array(
						'success'        => array( 'type' => 'boolean' ),
						'message'        => array( 'type' => 'string' ),
						'applied'        => array( 'type' => 'boolean' ),
						'affected_rows'  => array( 'type' => 'integer' ),
						'preview_rows'   => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
						'confirm_token'  => array( 'type' => 'string' ),
						'backup_id'      => array( 'type' => 'string' ),
						'warning'        => array( 'type' => 'string' ),
						'table'          => array( 'type' => 'string' ),
					),
				),
				'execute_callback'    => function ( $input = array() ): array {
					$gate = self::gate();
					if ( null !== $gate ) {
						return $gate;
					}

					if ( ! self::writes_enabled() ) {
						return array(
							'success' => false,
							'message' => esc_html__( 'A escrita no banco está desligada. Ligue em Ferramentas > MCP Files. A leitura (db/query) continua disponível.', 'f3-mcp-files' ),
						);
					}

					global $wpdb;
					$input = is_array( $input ) ? $input : array();

					if ( empty( $input['sql'] ) ) {
						return array( 'success' => false, 'message' => esc_html__( 'Parâmetro obrigatório ausente: sql', 'f3-mcp-files' ) );
					}

					$clean = SqlGuard::validate_write( (string) $input['sql'] );
					if ( is_wp_error( $clean ) ) {
						return self::fail( $clean );
					}

					$pre = SqlGuard::preimage( $clean );
					if ( is_wp_error( $pre ) ) {
						return self::fail( $pre );
					}

					$warning = (string) SqlGuard::serialized_warning( $clean, $pre['table'] );

					// A transação com rollback é a rede que segura um statement
					// que atinja mais linhas do que a pré-visualização mostrou.
					// Ela só existe em engines transacionais: numa tabela
					// MyISAM o START TRANSACTION é aceito e ignorado, o COMMIT
					// não faz nada e o ROLLBACK também não — a proteção some
					// sem erro nenhum. Quem vai aplicar precisa saber disso
					// ANTES de confirmar, não descobrir depois.
					$engine = self::table_engine( $pre['table'] );
					if ( '' !== $engine && 0 !== strcasecmp( $engine, 'InnoDB' ) ) {
						$aviso_engine = sprintf(
							/* translators: 1: tabela, 2: engine. */
							__( 'ATENÇÃO: %1$s usa o engine %2$s, que não é transacional. O rollback automático NÃO vai funcionar nesta tabela — se o statement atingir mais linhas que o previsto, não há como desfazer. Só o backup das linhas anteriores protege aqui.', 'f3-mcp-files' ),
							$pre['table'],
							$engine
						);
						$warning = '' === $warning ? $aviso_engine : $warning . ' ' . $aviso_engine;
					}

					// ---- levanta as linhas que serão afetadas ------------------
					$affected_rows = array();
					$expected      = 0;

					if ( '' !== $pre['select'] ) {
						$suppress = $wpdb->suppress_errors( true );
						// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- derivado do statement já validado.
						$affected_rows = $wpdb->get_results( $pre['select'], ARRAY_A );
						$error         = $wpdb->last_error;
						$wpdb->suppress_errors( $suppress );

						if ( ! empty( $error ) ) {
							return array(
								'success' => false,
								'message' => esc_html(
									sprintf(
										/* translators: %s: erro do MySQL. */
										__( 'A pré-visualização falhou (nada foi alterado). Erro do MySQL: %s', 'f3-mcp-files' ),
										$error
									)
								),
							);
						}

						$affected_rows = is_array( $affected_rows ) ? $affected_rows : array();
						$expected      = count( $affected_rows );
					}

					$token = hash( 'sha256', $clean . '|' . $expected . '|' . wp_salt( 'nonce' ) );

					// ---- fase 1: só mostra --------------------------------------
					if ( empty( $input['confirm_token'] ) ) {
						$limit   = isset( $input['limit_preview'] ) ? min( 200, max( 1, (int) $input['limit_preview'] ) ) : 20;
						$shown   = SqlGuard::redact( array_slice( $affected_rows, 0, $limit ) );

						return array(
							'success'       => true,
							'applied'       => false,
							'affected_rows' => $expected,
							'preview_rows'  => $shown['rows'],
							'confirm_token' => $token,
							'table'         => $pre['table'],
							'warning'       => $warning,
							'message'       => esc_html(
								0 === $expected && '' !== $pre['select']
									? __( 'PRÉ-VISUALIZAÇÃO: nenhuma linha corresponde. Nada foi alterado — reveja o WHERE antes de confirmar.', 'f3-mcp-files' )
									: sprintf(
										/* translators: %d: linhas que seriam afetadas. */
										__( 'PRÉ-VISUALIZAÇÃO: %d linha(s) seriam afetadas. Nada foi alterado ainda. Repita a chamada com o confirm_token para aplicar.', 'f3-mcp-files' ),
										$expected
									)
							) . ( '' !== $warning ? ' ' . esc_html( $warning ) : '' ) . self::pii_note( $clean ),
						);
					}

					// ---- fase 2: aplica -----------------------------------------
					if ( ! hash_equals( $token, (string) $input['confirm_token'] ) ) {
						return array(
							'success' => false,
							'applied' => false,
							'message' => esc_html__( 'confirm_token não confere. O statement ou o número de linhas afetadas mudou desde a pré-visualização — refaça a pré-visualização e confira antes de aplicar.', 'f3-mcp-files' ),
						);
					}

					// Backup das linhas anteriores, para poder desfazer.
					$backup_id = '';
					if ( ! empty( $affected_rows ) ) {
						$backup_id = self::backup_rows( $pre['table'], $clean, $affected_rows );
						if ( is_wp_error( $backup_id ) ) {
							return self::fail( $backup_id );
						}
					}

					// A transação é a rede de segurança contra a pré-imagem ter
					// mentido: se o statement atingir mais linhas do que foi
					// mostrado, desfaz tudo em vez de confiar na análise.
					$wpdb->query( 'START TRANSACTION' );

					$suppress = $wpdb->suppress_errors( true );
					// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- statement validado por SqlGuard::validate_write().
					$result = $wpdb->query( $clean );
					$error  = $wpdb->last_error;
					$wpdb->suppress_errors( $suppress );

					if ( false === $result || ! empty( $error ) ) {
						$wpdb->query( 'ROLLBACK' );
						return array(
							'success' => false,
							'applied' => false,
							'message' => esc_html(
								sprintf(
									/* translators: %s: erro do MySQL. */
									__( 'Nada foi alterado (rollback). Erro do MySQL: %s', 'f3-mcp-files' ),
									$error
								)
							),
						);
					}

					$actual = (int) $result;

					if ( '' !== $pre['select'] && $actual > $expected ) {
						$wpdb->query( 'ROLLBACK' );
						return array(
							'success'       => false,
							'applied'       => false,
							'affected_rows' => 0,
							'message'       => esc_html(
								sprintf(
									/* translators: 1: linhas atingidas, 2: linhas previstas. */
									__( 'ROLLBACK: o statement atingiu %1$d linhas, mais que as %2$d previstas na pré-visualização. Nada foi alterado.', 'f3-mcp-files' ),
									$actual,
									$expected
								)
							),
						);
					}

					$wpdb->query( 'COMMIT' );

					// Caches do WordPress guardam options e meta; sem limpar, o
					// site continuaria servindo o valor antigo até expirar.
					wp_cache_flush();

					PathGuard::audit(
						'db:execute',
						$pre['table'],
						array(
							'sql'       => substr( $clean, 0, 200 ),
							'rows'      => $actual,
							'backup_id' => $backup_id,
						)
					);

					return array(
						'success'       => true,
						'applied'       => true,
						'affected_rows' => $actual,
						'preview_rows'  => array(),
						'confirm_token' => '',
						'backup_id'     => $backup_id,
						'table'         => $pre['table'],
						'warning'       => $warning,
						'message'       => esc_html(
							sprintf(
								/* translators: 1: linhas afetadas, 2: id do backup. */
								__( 'Aplicado: %1$d linha(s). Cópia das linhas anteriores guardada em %2$s.', 'f3-mcp-files' ),
								$actual,
								'' !== $backup_id ? $backup_id : '—'
							)
						),
					);
				},
				'permission_callback' => function (): bool {
					return self::permission() && self::writes_enabled();
				},
				'meta'                => array(
					'annotations' => array( 'readonly' => false, 'destructive' => true, 'idempotent' => false ),
				),
			)
		);
	}

	/**
	 * Engine de armazenamento de uma tabela, ou string vazia se indeterminado.
	 *
	 * @param string $table Nome da tabela.
	 */
	private static function table_engine( string $table ): string {
		global $wpdb;

		$safe = preg_replace( '/[^A-Za-z0-9_]/', '', $table );
		if ( '' === $safe ) {
			return '';
		}

		$suppress = $wpdb->suppress_errors( true );
		$engine   = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s',
				$safe
			)
		);
		$wpdb->suppress_errors( $suppress );

		return is_string( $engine ) ? $engine : '';
	}

	/**
	 * Guarda as linhas anteriores como JSON no diretório de backups.
	 *
	 * Não restaura sozinho — reinserir linhas arbitrárias sem saber a chave
	 * primária daria falsa segurança. Serve para você ver exatamente o que
	 * havia antes e reconstruir com conhecimento de causa.
	 *
	 * @return string|\WP_Error
	 */
	private static function backup_rows( string $table, string $sql, array $rows ) {
		$dir = PathGuard::backup_dir();
		if ( is_wp_error( $dir ) ) {
			return $dir;
		}

		$id      = 'db' . bin2hex( random_bytes( 11 ) );
		$payload = array(
			'id'    => $id,
			'table' => $table,
			'sql'   => $sql,
			'time'  => gmdate( 'c' ),
			'user'  => get_current_user_id(),
			'count' => count( $rows ),
			'rows'  => $rows,
		);

		if ( false === file_put_contents( $dir . '/' . $id . '.json', wp_json_encode( $payload ) ) ) {
			return new \WP_Error( 'f3_sql_backup', __( 'Falha ao guardar a cópia das linhas. Nada foi alterado.', 'f3-mcp-files' ) );
		}

		return $id;
	}
}
