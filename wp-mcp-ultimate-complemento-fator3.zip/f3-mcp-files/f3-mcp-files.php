<?php
/**
 * Plugin Name:       Fator3 MCP Files
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Acrescenta habilidades de arquivo (files/*) e de banco de dados (db/*) à Abilities API do WordPress, expostas por qualquer servidor MCP instalado. Arquivos restritos a temas e plugins; escrita no banco em duas fases, com pré-visualização obrigatória. Liga e desliga em Ferramentas > MCP Files.
 * Version:           0.7.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Fator3
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       f3-mcp-files
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'F3_MCP_FILES_VERSION', '0.7.0' );
define( 'F3_MCP_FILES_DIR', plugin_dir_path( __FILE__ ) );

require_once F3_MCP_FILES_DIR . 'includes/PathGuard.php';
require_once F3_MCP_FILES_DIR . 'includes/Http.php';
require_once F3_MCP_FILES_DIR . 'includes/SqlGuard.php';
require_once F3_MCP_FILES_DIR . 'includes/Database.php';
require_once F3_MCP_FILES_DIR . 'includes/SelfTest.php';
require_once F3_MCP_FILES_DIR . 'includes/Files.php';
require_once F3_MCP_FILES_DIR . 'includes/Admin.php';

/**
 * Registra as habilidades na Abilities API.
 *
 * `wp_abilities_api_init` é disparado tanto pelo WordPress 6.9+ nativo quanto
 * pelo polyfill que o WP MCP Ultimate carrega. Uma vez registradas, as
 * habilidades aparecem no `discover-abilities` e podem ser chamadas pelo
 * `execute-ability` do servidor MCP já existente — sem tocar naquele plugin.
 */
add_action(
	'wp_abilities_api_init',
	static function (): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		Files::register();
		Database::register();
	}
);

Admin::init();

/**
 * Protege as opções deste plugin contra a habilidade options/update.
 *
 * A lista de proteção padrão do WP MCP Ultimate cobre ~23 nomes fixos e
 * libera todo o resto. Sem isto, o agente poderia reabrir o canal depois de
 * você fechá-lo, ou apagar o próprio log de auditoria, com um options/update.
 *
 * Isto não é contenção contra um agente comprometido — quem tem
 * `install_plugins` já pode instalar PHP arbitrário. É para que o botão
 * "fechar o canal" signifique o que promete no uso normal.
 */
add_filter(
	'wp_mcp_ultimate_protected_options',
	static function ( $protected ) {
		if ( ! is_array( $protected ) ) {
			$protected = array();
		}
		$protected[] = PathGuard::OPTION_ENABLED;
		$protected[] = 'f3_mcp_files_audit';
		$protected[] = Database::OPTION_WRITES;
		return $protected;
	}
);

/**
 * Ativar o plugin abre o canal — ativar já é o ato humano explícito.
 */
register_activation_hook(
	__FILE__,
	static function (): void {
		add_option( PathGuard::OPTION_ENABLED, true, '', true );
		add_option( Database::OPTION_WRITES, true, '', true );
	}
);

/**
 * A Abilities API existe nesta instalação?
 *
 * Vem do núcleo no WordPress 6.9+, ou de um polyfill carregado por um plugin de
 * servidor MCP. Sem ela, `wp_abilities_api_init` nunca dispara e este plugin não
 * registra rota nenhuma.
 */
function f3_mcp_files_abilities_api_disponivel(): bool {
	return function_exists( 'wp_register_ability' );
}

/**
 * Existe algum servidor MCP para expor as rotas para fora?
 *
 * Registrar habilidades não basta: elas ficam no WordPress e ninguém de fora as
 * alcança sem um servidor MCP. Hoje quem cumpre esse papel aqui é o WP MCP
 * Ultimate, mas a checagem é por capacidade, não por marca — qualquer plugin
 * que exponha a Abilities API por MCP serve.
 */
function f3_mcp_files_servidor_mcp_detectado(): bool {
	return class_exists( '\WpMcpUltimate\Server\McpAdapter' )
		|| defined( 'WP_MCP_ULTIMATE_DIR' )
		|| (bool) apply_filters( 'f3_mcp_files_servidor_mcp_detectado', false );
}

/**
 * Avisos no admin.
 *
 * O primeiro aviso é o que importa para instalação nova: sem a Abilities API o
 * plugin ativa, a tela de controle diz "ABERTO" e nada funciona — falha
 * silenciosa, que é a pior forma de falhar. Melhor gritar na tela de Plugins.
 */
add_action(
	'admin_notices',
	static function (): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$id     = $screen ? $screen->id : '';

		// O aviso de pré-requisito ausente aparece em qualquer tela do admin:
		// é bloqueante e quem instalou precisa ver.
		if ( ! f3_mcp_files_abilities_api_disponivel() ) {
			printf(
				'<div class="notice notice-error"><p><strong>MCP Files:</strong> %s</p></div>',
				esc_html__( 'a Abilities API do WordPress não está disponível, então NENHUMA rota foi registrada e o plugin não faz nada. Ela vem no WordPress 6.9 ou superior; em versões anteriores, é preciso um plugin de servidor MCP que traga o polyfill.', 'f3-mcp-files' )
			);
			return;
		}

		if ( ! f3_mcp_files_servidor_mcp_detectado() ) {
			printf(
				'<div class="notice notice-warning"><p><strong>MCP Files:</strong> %s</p></div>',
				esc_html__( 'as rotas foram registradas, mas nenhum servidor MCP foi detectado neste site. Sem ele as rotas existem no WordPress e não são alcançáveis de fora — instale um plugin de servidor MCP (por exemplo o WP MCP Ultimate) para expô-las.', 'f3-mcp-files' )
			);
		}

		if ( 'plugins' !== $id ) {
			return;
		}

		$link = '<a href="' . esc_url( admin_url( 'tools.php?page=f3-mcp-files' ) ) . '">'
			. esc_html__( 'Ferramentas > MCP Files', 'f3-mcp-files' ) . '</a>';

		if ( PathGuard::is_enabled() ) {
			printf(
				'<div class="notice notice-warning"><p><strong>MCP Files:</strong> %s %s</p></div>',
				esc_html__( 'o canal de escrita de arquivos está ABERTO.', 'f3-mcp-files' ),
				wp_kses_post( $link )
			);
			return;
		}

		printf(
			'<div class="notice notice-info"><p><strong>MCP Files:</strong> %s %s</p></div>',
			esc_html__( 'instalado e fechado. Para abrir o canal, vá em', 'f3-mcp-files' ),
			wp_kses_post( $link )
		);
	}
);

/**
 * Atalho "Configurar" na linha do plugin.
 */
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	static function ( array $links ): array {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'tools.php?page=f3-mcp-files' ) ) . '">'
				. esc_html__( 'Configurar', 'f3-mcp-files' ) . '</a>'
		);
		return $links;
	}
);

/**
 * Desativar o plugin já remove as habilidades do registro; nada a limpar.
 *
 * Os backups são preservados de propósito — desativar não deve destruir a
 * única cópia de um arquivo que alguém pode precisar restaurar.
 */
register_deactivation_hook(
	__FILE__,
	static function (): void {
		// Intencionalmente vazio, e documentado para deixar claro que a
		// preservação dos backups é decisão, não esquecimento.
	}
);
