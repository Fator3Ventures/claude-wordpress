# Plano da 1.84.0

Base 1.83.0. Pedidos 398 e 399 do anexo de 13/11. Provar sete superfícies de link, privacidade e paginação, clique sem conversão com opção ligada e desligada, preservação dos avisos e controle positivo do formulário. Migração direta e instalação limpa antes da homologação do ZIP em Site-Teste. A decisão de conversão e ambas as consultas são do Core. Os clientes MCP já descobrem o esquema da ability em execução. Nenhuma alteração de implementação solicitada aos pacotes acompanhantes.
