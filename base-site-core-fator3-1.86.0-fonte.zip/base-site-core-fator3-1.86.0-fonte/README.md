# Fonte do Fator3 Site Core 1.86.0

O código instalado fica em `work/plugin/base-site-core-fator3/`. As instruções operacionais estão em `docs/RELEASE-1.86.0.md` e `docs/AGENTES-1.86.0.md` dentro dessa árvore. Os pedidos originais estão em `reference/pedidos-402-406.md`. O plano desta rodada é `PLANO-1.86.0.md`. A cópia interna do relatório é anterior ao fechamento do fonte.

## Reconstruir o instalador

Na raiz desta pasta, com Python 3 e PHP CLI 8.3 ou superior, execute os comandos abaixo. O instalador oficial foi produzido com zlib 1.3.2. O verificador confere os bytes de todos os arquivos independentemente da versão do compressor.

```sh
python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.86.0-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.86.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.86.0-fonte.zip
```

O manifesto lista os arquivos e hashes do fonte. A base extraída do instalador 1.85.1 fica em `history/1.85.1-runtime/`. O inventário com as diferenças fica em `evidence/1860/alteracoes.json`. Os diretórios de releases anteriores conservam as datas e os resultados de seus próprios testes.

## Reproduzir a homologação

Use duas instalações WordPress 7.1.4 descartáveis, com WP-CLI, `WP_ENVIRONMENT_TYPE=local`, administrador de ID 1 e bancos exclusivos `core186` e `fresh186`. A suíte usa identificadores determinísticos de contatos e altera opções e agenda no laboratório. Utilize um diretório privado gravável e desative HTTP externo na homologação. O PHP 8.3 precisa de mysqli e mbstring. A evidência visual usa Chromium e Playwright para Node.

1. No primeiro ambiente, instale e ative a 1.85.1, semeie os 55 contatos com `wp eval-file tests/contatos-1860-fixture.php` e rode a fase de navegador `antes`. Instale o ZIP 1.86.0 com `wp plugin install /caminho/instalador.zip --force --activate`. No segundo ambiente, instale o ZIP em WordPress limpo e semeie os mesmos contatos. Use `wp --path=/caminho/do/wordpress` e caminhos absolutos para os scripts quando os diretórios de trabalho diferirem.
2. Rode `wp --user=1 eval-file tests/402-406.php` em ambos. Rode os testes de coleta `tests/ga4-1860.php` e de leitura `tests/campanha-1860.php` em instalação limpa sem plugin Google ativo. Para repetir o cenário de publicação GA4, restaure a fotografia inicial do banco descartável. A coleta publica um dia no acervo local.
3. No primeiro ambiente, ative Google 0.35.0, Meta 0.26.0 e LinkedIn 0.23.0 e rode `wp --user=1 eval-file tests/leitores-1860.php`.
4. Defina `F3BASE_QA_USUARIO`, `F3BASE_QA_SENHA`, `F3BASE_QA_URL` (HTTP de loopback) e `CHROMIUM_BIN`. Rode `node tests/painel-1860.cjs depois`, `subabas` e `interacoes` em invocações separadas. Para a fase `recuperacao`, prepare o modo de recuperação no laboratório, execute a captura e retome o Core. A fase `antes` corre na base 1.85.1. O script grava em `evidence/1860/ui-<fase>`.
5. Compare os resultados com `evidence/1860/`. As provas do Site-Teste estão em `site-teste.json`. A reprodução de laboratório usa somente identidades e respostas sintéticas. O aceite de frota do pedido 405 está descrito no relatório externo.
