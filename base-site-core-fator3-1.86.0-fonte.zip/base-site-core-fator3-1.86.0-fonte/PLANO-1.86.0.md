# Fator3 Site Core 1.86.0

Retomada em 14/11/2026 da rodada iniciada sobre a 1.85.1. O documento de origem dos pedidos 402 a 406 está em `reference/pedidos-402-406.md`. Fontes centrais lidas em revisão 5. Os ZIPs recuperados da 1.85.1 identificam a base reproduzível. O último relato do chat localizou a segunda falha nos relatórios. Nesta retomada, as mudanças do candidato foram reconstruídas e testadas.

| Pedido | Decisão | Prova prevista e executada |
|---|---|---|
| 402 | Tratar JSON, array e tipos inesperados na origem, proteger a apresentação de cada linha e preservar o vínculo da campanha à captura. | Reproduzir o TypeError na base. Conferir os dois formatos, as negativas, a linha legível, o detalhe, o CSV e três relatórios com dados malformados. |
| 403 | Reutilizar os filtros existentes, preservar os cursores e calcular total e paginação no banco para a tela administrativa. | Exercitar busca, selos removíveis, segunda página e abas. Comparar antes/depois, com e sem filtro, nas três larguras. |
| 404 | Aplicar cabeçalho, navegação e tabelas responsivas às áreas do Core. | Abrir as áreas e subabas em navegador autenticado a 360, 768 e 1440 px, inclusive recuperação. |
| 405 | Registrar até qual ocorrência a coleta automática concluiu o trabalho e encerrar somente esperas compatíveis. | Provar coleta completa no banco e distinguir passado, futuro, argumentos distintos e reserva ativa. Acompanhamento de dois ciclos nos seis domínios cabe à frota. |
| 406 | Avaliar as três chaves de ativação antes de processar ou agendar o histórico. | Conferir resultado não aplicável, remoção da espera antiga e retomada do agendamento ao reativar. |

Google, Meta, LinkedIn, Pipedrive e o transporte MCP foram avaliados quanto a efeitos nos contratos. As correções são de responsabilidade do Core. O conjunto homologado e os limites dos testes estão no relatório. A instalação autorizada é a do Site-Teste.
