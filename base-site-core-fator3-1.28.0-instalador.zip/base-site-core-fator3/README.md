# Fator3 Site Core 1.28.0

Formulários em duas etapas com um único contato; histórico de visitas e campanhas; comunicação canônica por e-mail, Slack e Pipedrive; Slack em threads; recuperação durável do executor e verificação Meta separada da importação.

Referência: instalação nova ou 1.27.0, sem gate. Contrato 6.4.0. Matriz MCP 0.19.0 / MCP Google 0.8.2. Não modifica companheiros ou tema.

[Documentação instalada](docs/DOCUMENTACAO.md) · [Release](docs/RELEASE-1.28.0.md) · [Agentes](docs/AGENTES-1.28.0.md) · [Validação](docs/VALIDACAO.md).

Documentação e schemas acompanham o ZIP. Agentes autorizados podem lê-los por `f3base/documentacao-ler`, inclusive em recuperação. Segredos são cadastrados pelo dono na tela. Guias anteriores são históricos e não sobrepõem a instrução vigente.
