# Verificação Meta — 1.28.0

A tela de Integrações Meta e `f3base/anuncios-meta-acesso-verificar` verificam acesso mesmo com a importação desligada. A chamada exige a revisão atual da configuração; `simular` é true por padrão. Cada aplicação avança uma etapa: permissões da credencial, conta de anúncios, catálogo paginado de uma página e conferência dos formulários autorizados. Repita enquanto `completa:false`. Limite local: 120 etapas/dia UTC. Esse teste não importa leads, não liga a integração e não move seus cursores/janelas.

O catálogo completo prova quais formulários foram encontrados nas páginas configuradas. Não é prova de que o aplicativo pode ler todos os leads reais: permissões/tarefas/atribuição de Leads Access e o contrato da versão Graph também precisam ser conferidos. A importação continua aplicando suas próprias exigências de acesso e propriedade exclusiva.

Para cada página autorizada, o Core resolve o token apropriado a partir da credencial configurada e consulta formulários/leads com esse token de página. Não persiste o token derivado e não o inclui no diagnóstico. A configuração deve usar credencial apta a resolver as páginas — não cole um token de página em um campo que depende da descoberta de conta/permissões sem homologar esse contrato.

O diagnóstico informa etapa, ID alvo, versão Graph, tipo de token, status HTTP e códigos/subcódigo/tipo de erro. Mensagem bruta do fornecedor e segredos não são retornados. Catálogo incompleto permanece incompleto. IDs fora das páginas permitidas são recusados. Um catálogo já armazenado conserva a associação página→formulário na atualização.

Não se declarou uma causa única para a recusa observada em korvena nem foram executadas consultas nessa conta. A validação local prova seleção/uso do token derivado e ausência de persistência, por respostas simuladas. O aceite real requer credencial do dono inserida na tela, páginas e formulários autorizados e conferência com a versão Graph configurada.

Referência oficial de resolução de token: https://www.postman.com/meta/facebook/request/tass6hw/get-specific-page-access-token . Catálogo geral: https://www.postman.com/meta/facebook/ . Acesso às páginas de documentação Lead Ads esteve indisponível na consulta; não se elevou teste simulado à prova do contrato real da conta.
