# Formulários — 1.28.0

## Configurar

No editor de formulários, escolha os campos que compõem o grupo “ao menos um” e indique a etapa de cada campo. O preset comercial mantém Nome obrigatório, Empresa opcional e E-mail/WhatsApp como alternativas. O preset não reescreve formulários já publicados.

Exemplo de fragmento em `f3base_formularios` (mesclar com a definição real):

```json
{"exigir_um_de":["seu_email","seu_telefone"],"mensagem_exigir_um_de":"Informe e-mail ou WhatsApp.","whatsapp_nova_aba":true,"whatsapp_campos":["mensagem"],"campos":[{"nome":"nome","rotulo":"Nome","tipo":"text","papel":"nome","obrigatorio":true},{"nome":"seu_email","rotulo":"E-mail","tipo":"email","papel":"email"},{"nome":"seu_telefone","rotulo":"WhatsApp","tipo":"tel","papel":"telefone"},{"nome":"mensagem","rotulo":"Mensagem","tipo":"textarea","papel":"mensagem","etapa":2}]}
```

Os nomes são os campos reais do formulário. O grupo não pode apontar para campo ausente, obrigatório individualmente ou etapa 2. Um e-mail inválido não é ignorado porque o telefone é válido. Telefone nacional usa o país configurado no Pipedrive (BR padrão) e exige número completo; máscara vazia não conta. Nome/e-mail/telefone identificadores ficam na primeira etapa. Conteúdo privado continua em uma etapa; nova aba não altera download.

## Duas etapas e entregas

A primeira etapa persiste um `record_id` e dispara a conversão somente uma vez. A segunda usa POST `/wp-json/f3base/v1/formularios/complementar` com `continuacao`, `formulario`, `revisao`, `submissao`, `campos` e `pular`. A referência vale 30 minutos e autoriza somente aquele contato/formulário/revisão; fica na memória do cliente, nunca em URL. O banco guarda o hash, prazo e definição. Ela não autentica consultas administrativas.

Mesmo ID + mesmo conteúdo retorna confirmação anterior; conteúdo diferente dá conflito. A primeira etapa permanece salva em expiração/recusa/abandono. “Pular e continuar” registra ausência voluntária, sem respostas fictícias. Anexos continuam privados e seguem as mesmas regras de validação. Alteração da revisão do formulário impede usar uma continuação desatualizada.

Até captura + 10 segundos, antes do preparo, o complemento entra no aviso inicial. Depois do corte ou do preparo, preserva-se o resumo inicial e cria-se uma revisão com atualização curta nos destinos elegíveis. O Pipedrive atualiza somente campos complementares mapeados na oportunidade já vinculada e acrescenta nota; não cria outra pessoa/lead. A fila guarda confirmação por destino e resultado incerto não é reenviado automaticamente.

`f3base/contato-complemento-reconciliar` permite simular e reagendar uma atualização após revisão externa: `chave`, `destino`, depois `revisao`, `simular:false`, `confirmar:true`, `aceitar_duplicacao:true`. Isso pode repetir uma atualização já recebida quando a resposta original se perdeu. Não muda o destino original; mapa/conta divergentes continuam suspensos. Para Slack, reconciliar a parte primeiro.

## WhatsApp e tema

`whatsapp_nova_aba` ausente significa true. O Core reserva a janela no gesto final, após validação local e antes da requisição. Abre o destino somente depois da confirmação. Recusa fecha a reserva; bloqueio usa a própria aba ou o botão manual; janela fechada voluntariamente não é reaberta automaticamente. O texto do CTA tem precedência e os campos incluídos na conversa exigem lista explícita `whatsapp_campos`. Segredos, caminhos privados e dados técnicos não são incluídos automaticamente.

O CTA usa `data-f3base-abrir-formulario="ID"` e conserva um `href` WhatsApp válido. Se o formulário/adaptador estiver disponível, o Core captura a origem e suprime o lead de clique duplicado. Caso contrário, o link segue seu comportamento direto. O tema mantém o desenho do diálogo; pode registrar `window.f3baseFormularios.registrarAdaptador(id, callback)`. O callback recebe `{formulario: elementoDOM, gatilho: elementoDOM}` e abre/apresenta o formulário disponível; `false` recusa a interceptação e preserva o link. Sem adaptador, há o fluxo em linha acessível.

Eventos públicos: `f3base-formulario-aceito` somente na captura inicial; `f3base-formulario-complemento-aceito` na conclusão adicional; os eventos de diálogo, etapa pulada e conversa alimentam apenas o funil. O payload analítico não inclui referência de continuação nem respostas livres. Consulte o JS distribuído para os detalhes exatos dos eventos do adaptador.

Antes de remover os remendos `contato-obrigatorio.js` / `whatsapp-nova-aba.js`, confira o fluxo nativo. O Core não apaga arquivos do tema. Coexistência pode gerar duas interceptações: a implantação deve retirar o remendo depois de homologar.
