# Histórico de contatos — 1.28.0

Histórico significa observações do mesmo pseudônimo de navegador e classe de tráfego. Não prova identidade pessoal, uso entre dispositivos, atenção exclusiva ou causalidade comercial. A fonte de audiência continua `f3base_analise`; `f3base_sessoes` é um índice derivado, reconstruído em lotes de até 250 eventos. Até cinco contatos por passagem recompõem o índice de campanhas, sem reenviar avisos.

## Recorte e origem

O preparo usa eventos ocorridos até a captura e recebidos até captura + 10 s. A visão `aviso` preserva esse resumo cifrado; `atual` usa o que está retido hoje e pode ter cobertura diferente. Uma visita anterior começa antes da sessão da captura. Empates, sobreposição e início inferido não provam ordem entre abas.

A origem vem de `sessao_origem` do primeiro evento elegível da sessão. Não se copia o primeiro toque global para uma visita direta intermediária. Eventos sem origem comprovada recebem “Origem desconhecida”. Contatos antigos com toques, sem sessões associadas, mostram “Origem histórica registrada no contato”, datas existentes e contagem de visitas indisponível.

O recorte limita-se à retenção bruta configurada (30 dias no padrão), até 500 sessões e 10.000 eventos de origem. Excesso é explicitamente incompleto. A lista retorna 20 visitas por página; cinco têm detalhamento de até 12 páginas e as demais são resumidas. O resumo dos canais ainda tem orçamento textual e informa cortes. Não confundir contador do navegador com número de sessões observadas no servidor. Ausência de histórico não comprova primeira visita.

## Consultas

- `f3base/lead-jornada-ler`: `record_id`, `visao: "atual"|"aviso"`, `historico_pagina` (a paginação se aplica à visão atual).
- `f3base/leads-registros-ler`: filtro `campanha_historica` pelo nome exato ou chave SHA-256; exige permissão de leitura de leads. O detalhe inclui histórico e revisões complementares.
- `f3base/relatorios-integrados-ler`: `visao:"campanhas"`, `escopo_campanhas:"historico"`, período, classe, formulário/método e filtro histórico. `comparar:true` compara contatos distintos do período anterior. Filtros incompatíveis retornam código explícito, não são ignorados.
- wp-admin: Contatos/Relatórios oferece escopo de campanhas; a tela do contato mostra histórico paginado. CSV inclui resumo de campanhas, cobertura e visitas, com proteção de células contra fórmulas.

A chave de campanha inclui plataforma, conta e ID quando disponíveis; sem IDs, usa plataforma/conta/origem/meio/nome e marca identidade incompleta. Um contato associado a A e B aparece em ambas as linhas. O total global é distinto e não soma as linhas; não representa atribuição causal. O escopo padrão de atribuição permanece separado. No Pipedrive, `mapa_campos.campanhas` pode apontar a um campo textual existente, além da nota.

## Consentimento, retenção e eliminação

Medição negada/exclusão de audiência impede construir histórico. Publicidade negada reduz IDs e detalhes publicitários, sem apagar a medição autorizada. Referências de decisões relacionadas ficam no snapshot para que uma revogação conhecida continue restringindo futuras consultas/envios, mesmo após o preparo. Esses marcadores não são credenciais e não autorizam o visitante.

Os índices de sessões expiram com os eventos; o resumo comercial congelado acompanha o contato. O índice contato→campanha também acompanha o contato e é reconstruível. A eliminação do contato remove suas relações e complementos, cancela partes Slack e limpa payloads. Não apaga automaticamente as cópias já entregues aos fornecedores.

Tabelas: `f3base_sessoes` (classe/sessão), `f3base_contato_campanhas` (contato/campanha), `f3base_complementos` (revisão), `f3base_avisos_partes` (parte). Tipos e colunas estão em `dados/contrato.json`; propriedade/backup em `../dados/estado-inventario.json`.
