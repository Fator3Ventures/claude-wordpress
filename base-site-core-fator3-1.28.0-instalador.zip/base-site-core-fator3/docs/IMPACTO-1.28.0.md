# Impactos da entrega 1.28.0

## MCP 0.19.0

Nenhum arquivo do MCP foi alterado. Upload pela ability de plugins, recibo e operação pendente permanecem. Novas abilities administrativas do provider Core: `anuncios-meta-acesso-verificar`, `avisos-parte-reconciliar`, `contato-complemento-reconciliar`. Consultas de leads/jornada/relatórios ganharam histórico/campanhas; seus schemas acompanham o pacote. Política do conector e capabilities WordPress continuam cumulativas.

O backup do Core inclui as quatro tabelas novas, segredo do bot, estados de índice/acesso e referências do snapshot. Em restauração, drenar cada plugin e reconciliar as filas; as partes/complementos externos são suspensos, nunca reproduzidos silenciosamente de um backup. Não é necessário implementar mudança no MCP para esta release.

## MCP Google 0.8.2

Nenhum arquivo ou contrato do Google foi alterado. `search-console-reader/1.0.0`, grants, `effective_status`, commits e guarda de recuperação permanecem independentes. O Core não consome outra cota Google para gerar o histórico local. Preservar `f3_google_cron` e `f3-google-state` no backup conjunto, conforme o inventário do proprietário. Não é necessária mudança no MCP Google.

## Tema/implantador

O Core não edita tema, templates, menus ou arquivos de remendo. Aplicar `exigir_um_de` e etapas somente aos formulários escolhidos. Um diálogo pode usar o adaptador público; CTA conserva href de reserva e informa ID do formulário. No Site-Teste, trocar a composição de três formulários independentes por um único registro com complemento, preservando o layout do tema. Em ctooffice, retirar `contato-obrigatorio.js` e `whatsapp-nova-aba.js` somente após homologar o fluxo nativo, evitando interceptação duplicada.

Habilitar aplicativo Slack requer token/canal do dono e convite do bot; a instalação não troca webhooks nem reenvia contatos. Cadência do cron e sete dias de observação dos 14 sites são tarefas operacionais. Testes em produção e aparelhos físicos não foram realizados nesta entrega.
