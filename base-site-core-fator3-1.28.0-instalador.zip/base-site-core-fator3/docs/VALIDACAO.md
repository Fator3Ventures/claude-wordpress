# Validação — Core 1.28.0

Ensaios locais com dados sintéticos. WordPress 7.1.2, PHP 8.3, MariaDB e Chromium 138. Não houve envio a contas reais, mensagens a terceiros ou teste nos sites da frota. Transportes Slack/Meta/Pipedrive/e-mail foram bloqueados e substituídos por respostas controladas nos testes comerciais. O percurso do formulário no navegador usou os assets minificados e REST/banco reais por HTTP local.

| Evidência | Verificações | Resultado |
|---|---:|---|
| instalacao-nova.json | 10 | Passou |
| ciclo-instalacao.json | 11 | Passou |
| novidades.json | 27 | Passou |
| comunicacao.json | 82 | Passou |
| historico.json | 27 | Passou |
| complementos.json | 12 | Passou |
| crm-complemento.json | 8 | Passou |
| slack-app.json | 16 | Passou |
| avisos.json | 30 | Passou |
| webhook.json | 29 | Passou |
| operacao.json | 18 | Passou |
| funcional.json | 28 | Passou |
| telas.json | 9 | Passou |
| browser-http.json | 9 | Passou |
| browser-banco.json | 10 | Passou |
| visual-email.json | 2 | Passou |
| lint.json | 1 | Passou |
| companheiros-integridade.json | 2 | Passou |

Os números são asserções da suíte, não porcentagem de cobertura ou número de itens homologados na frota. Falhas de banco, timeout e 429 são injetados intencionalmente; a evidência distingue comportamento esperado e falha real. A suíte inclui geração de schemas, manifesto dos assets e testes de integridade do pacote. Além da tabela acima, as duas ordens de inicialização dos companheiros, guardas independentes de recuperação e 20 verificações do SDK Google real passaram (HTTP Google simulado).

## O que os ensaios demonstram

- Instalação nova e atualização 1.27→1.28 pelo MCP: primeiro GET leve, captura antes da migração, procedência/listas vazias preservadas e novo padrão de formulário completado.
- Grupo e-mail/telefone; primeiro envio idempotente, complemento no mesmo registro, recusa de conflito e mudança de revisão; Pular conserva o contato. Complemento tardio gera só a atualização, sem mudar o snapshot inicial.
- Navegador real: FAQ por mouse/teclado, rolagem com `detalhe` 25/50/75/90 chegando ao banco e ao aviso como 90%; ausência de conversão extra no CTA interceptado; uma requisição por etapa, upload multipart real na segunda etapa e reserva de janela com opener removido.
- Histórico com sete sessões, cinco detalhadas, sessão direta sem herdar campanha, A/B sem total duplicado, autorização publicitária reduzida e revogação restringindo o snapshot. Filtro exercitado também pela ability sob concessão explícita do MCP no laboratório.
- Slack: principal única, resposta 429 retomável, timeout sem reenvio cego, HTTP200 recusado, resumo de 50 contatos, complemento na mesma thread e troca de destino bloqueada. Webhook anterior continua operando.
- Pipedrive: leitura da oportunidade vinculada, PATCH somente dos campos complementares e uma nota com a revisão; sem criação de pessoa/oportunidade. Uma etapa incerta permanece parada até reconciliação explícita.
- Executor: bootstrap repara agenda futura mesmo sem checkpoint, não posterga quota, identifica falha de escrita/agenda e dois processos não repetem callback.
- Três abas administrativas com prova de tokens; prévia canônica; relatório histórico sem warnings. E-mail renderizado em 1.100 e 390 px sem estouro horizontal.

## Homologação externa restante

1. No Site-Teste, conferir permissões reais do bot, canal privado, mensagem principal, respostas, resumo e atualização, sem habilitar testes na frota indiscriminadamente.
2. Em Pipedrive de homologação, conferir tipos/chaves dos campos e renderização da nota. Respostas simuladas não provam o catálogo da conta real.
3. Meta: executar a verificação com integração desligada e credencial do dono na tela; confirmar catálogo completo e permissões/tarefas da conta. Depois validar a leitura do formulário autorizado sob a versão Graph configurada, sem mudar janelas de importação apenas para testar.
4. Safari iOS e navegador interno do Instagram em aparelhos físicos: envio, botão Pular, popup bloqueado, janela fechada e erro na etapa final. Chromium local não substitui esses aceites.
5. Formulário com anexo na hospedagem real: conferir os limites do PHP/proxy e a proteção HTTP da pasta privada. O upload multipart local e o vínculo ao mesmo registro, sem contaminar o aviso inicial, passaram; isso não prova as regras do servidor de produção.
6. Durante sete dias nos 14 sites, observar intenção elegível há mais de 900 s, causa, reserva, quota e origem/cadência do cron. Não foi realizada essa observação nesta entrega.

Aceite externo pendente não deve ser descrito como falha corrigida e comprovada na frota. O relatório de impactos lista o trabalho do tema/implantador; nenhum deles foi alterado pelo Core.
