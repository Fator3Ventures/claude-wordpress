# Slack — 1.28.0

## Configuração humana

Em Contatos → Integrações → Avisos, escolha Aplicativo com bot, informe o ID do canal e cole o token do bot. Cadastre o app no Slack com `chat:write` e convide-o para o canal. O Core não pede permissões de leitura do histórico para encontrar mensagens enviadas. Ao selecionar aplicativo, a tela propõe “Principal e respostas na thread”; você pode escolher Completo ou Compacto. Webhooks existentes mantêm formato/destino; thread exige aplicativo.

O segredo é cifrado, nunca reapresentado. “Verificar credencial” chama `auth.test`; isso não comprova acesso ao canal. “Enviar mensagem marcada de teste” cria uma mensagem real somente quando solicitado. Testes comuns continuam respeitando a política de destino do Core. A configuração não ativa envios da frota por conta própria.

## Formatos e confirmação

Thread: principal curta com identidade, contexto e link autorizado; respostas trazem as seções canônicas. Completo mantém todas as seções, com divisão apenas quando necessária. Compacto omite detalhes e oferece link — exceção explícita à paridade integral com e-mail/Pipedrive. A mensagem tem texto alternativo legível para notificações/leitores de tela.

Cada parte tem estado, payload cifrado, tentativa, próximo horário, canal, `ts` como string e vínculo à principal. Até 18 blocos por divisão e texto de bloco abaixo de 3.000 caracteres. O worker envia uma parte por execução e respeita o limitador local de uma mensagem por segundo/canal, além de `Retry-After` externo. Até 30 principais individuais por hora/classe/destino; excesso aguarda resumo, com principal de contagem e resposta(s) por contato. Complementos usam a thread original, inclusive em resumo.

HTTP200 com `ok:false` é falha. Recusas transitórias confirmadas têm retry limitado; `invalid_auth`, `missing_scope`, `not_in_channel` e `channel_not_found` exigem corrigir acesso. Timeout/resposta perdida fica `incerto`, sem repetição automática. Falha/incerteza da principal pode acionar e-mail de contingência uma vez; falha só do detalhe não repete a principal nem o e-mail já processado.

## Reconciliação e backup

Use a tela de partes ou `f3base/avisos-parte-reconciliar`, começando com simulação. A ação pode confirmar entrega com `ts` conhecido ou reagendar a parte, com revisão e aceite de possível duplicação. Confira o schema atual antes de aplicar. Não há promessa de exactly-once remoto com `chat:write`. Token/canal alterados não redirecionam intenções antigas.

O restore suspende filas/partes/complementos; reativação exige reconciliação. Payload terminal de partes pode ser limpo após 90 dias, preservando os vínculos essenciais; pendências permanecem. Desinstalar conserva as filas comerciais suspensas e os segredos de configuração. Eliminação local não significa remoção da mensagem externa.

Fontes do contrato: https://docs.slack.dev/reference/methods/chat.postmessage/ e https://docs.slack.dev/apis/web-api/rate-limits/. Permissões reais, canal privado e renderização final no workspace precisam de homologação do dono.
