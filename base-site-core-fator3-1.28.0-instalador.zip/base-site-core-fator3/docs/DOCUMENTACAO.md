# Documentação instalada — Core 1.28.0

Caminho: wp-content/plugins/base-site-core-fator3/docs/DOCUMENTACAO.md. Canal: `f3base/documentacao-ler`, com arquivo/linha/limite (até 200), hash e continuação. Requer manage_options, inclusive em recuperação.

| Documento | Conteúdo |
|---|---|
| RELEASE-1.28.0.md | Pedidos 167–175, implantação e limites da comprovação |
| AGENTES-1.28.0.md / INSTRUCOES-DO-PLUGIN.md | Instrução corrente e backup conjunto |
| FORMULARIOS-1.28.md | Grupo, etapas, nova aba e integração com o tema |
| HISTORICO-CONTATOS-1.28.md | Sessões, campanhas, relatórios e consentimento |
| SLACK-1.28.md / META-ACESSO-1.28.md | Configuração e diagnóstico das integrações |
| VALIDACAO.md | Evidências locais e roteiro de homologação |
| IMPACTO-1.28.0.md | Relatório para companheiros e implantação |
| COMUNICACAO-CONTATOS-1.27.md | Contrato canônico, com os complementos da 1.28 acima |
| AJUDA-OPCOES.md / dados/ajuda-opcoes.json | Ajuda gerada do catálogo executável |
| CONTRACTS.md / dados/configuracao-schema.json / dados/abilities-*.json | Contratos atuais |
| DICIONARIO-DADOS.md / dados/contrato.json | Tabelas e semântica |
| ../dados/estado-inventario.json | Propriedade fechada, backup, retenção e marcadores |
| PIPEDRIVE.md / ORIGENS-ANUNCIOS.md | Integrações e atribuição |
| MEDICAO-1.25.md / ESTADO-1.25.md | Recursos anteriores, com complementos/substituições descritos na release atual |

Guias de outras versões são históricos e não sobrepõem as instruções atuais. Documentação não implica ativação de serviço. Não contém credenciais reais.
