# Instruções aos agentes — Core 1.28.0

1. Ler DOCUMENTACAO.md, RELEASE-1.28.0.md e contrato 6.4.0. Base de referência: novo/1.27; sem gate. MCP 0.19.0 e Google 0.8.2 compõem a matriz validada; mínimos estáveis continuam 0.16.0/0.7.1.
2. Usar operation_id/applied/backup_id/recovery_status do MCP; verification_pending pede consulta da operação, não outro upload. Primeira visita agenda; executor migra e finaliza depois. Rollback é de arquivos, não de banco/entregas.
3. Antes de visitar para teste, abrir /f3base-teste/ no mesmo navegador e origem. Cookie dura 365 dias. Cliente HTTP técnico usa X-F3Base-Teste: 1. MCP não marca automaticamente outro navegador. Marca de teste não autentica.
4. Segredos são colados pelo dono na tela. Não pedir credencial em conversa ou contornar política de testes. Destinos suprimidos por padrão para testes; habilitar envio real somente por ordem operacional correspondente.
5. Resumo dos três canais: ler COMUNICACAO-CONTATOS-1.27.md. Para comparar aviso usar lead-jornada-ler com visao: aviso. Visão atual tem outro recorte de recepção. Não confundir entrega aceita, entrega incerta e atendimento do contato.
6. Tarefa parada: consultar esperas; simular executar-pendentes com reconciliar_esperas e uma tarefa. Aplicar com revisão correspondente; executar vencidas; conferir migração/finalização/prova do servidor. Nunca editar options por SQL para destravar. Quotas, suspensão e guardas continuam valendo.
7. Consolidação só de nomes exatos, com recibo/revisão e prova. Marcadores históricos são preservados conforme o inventário; não há promessa de downgrade nesta release. Não apagar por prefixo nem tocar opções de tema/implantador.
8. Auditoria por URL: paginar todo catálogo e conferir cobertura. Link operacional de salto fica à parte; mensagens WhatsApp usam query text decodificada uma vez, preservando caixa/pontuação. Tema não instrumentado continua responsabilidade do tema.
9. Google: SDK search-console-reader/1.0.0, grants, effective_status e commit permanecem independentes. Ausência não é zero. Não redefinir cota ou trocar concessão para fazer teste passar.
10. Backup conjunto: preparar/drenar cada plugin, incluir f3_google_cron e acervos, reconciliar e retomar cada guarda com sua geração. Cache Google é descartável; estado não. Não sobrepor sentinela ativa por snapshot antigo.
11. IA: requisição/Markdown medem acesso; referrer mede encaminhamento. Não inferir citação/recomendação. Relatórios devem declarar classe, recorte, retenção, cobertura e dimensões ausentes.

12. Formularios em etapas: leia FORMULARIOS-1.28.md; não registre segundo contato ao complementar, não logue a referência e não invente evento de conversão extra.
13. Histórico: leia HISTORICO-CONTATOS-1.28.md. Use origem da sessão e cobertura; campanhas históricas não são uma nova atribuição. Respeite o escopo e a classe de tráfego nas consultas.
14. Slack: leia SLACK-1.28.md. Tokens na tela, aplicação convidada ao canal, teste de envio explícito. Partes incertas requerem reconciliação; não reenviar o lote para recuperar uma resposta.
15. Meta: leia META-ACESSO-1.28.md. Verificar acesso não é ativar nem importar. Preserve revisão, paginação, quotas e diagnóstico seguro.
16. Depois da implantação, observar sete dias de esperas nos 14 sites com executor e cadência documentados. Não declarar aceite de frota a partir dos testes locais. Safari iOS, Instagram e contas reais são homologações separadas.
