> Complementos da 1.28: FORMULARIOS-1.28.md, HISTORICO-CONTATOS-1.28.md, SLACK-1.28.md e META-ACESSO-1.28.md. Novas abilities: anúncios Meta acesso, parte Slack e complemento de contato. Schemas gerados são a referência para parâmetros.

> Instrução vigente: Core **1.28.0**, contrato **6.4.0**. Consulte RELEASE-1.28.0.md e COMUNICACAO-CONTATOS-1.27.md; seções antigas abaixo documentam também o histórico.

# Contratos — Core 1.28.0

A referência gerada está em `dados/configuracao-schema.json`, `dados/abilities-*.json` e `dados/contrato.json`. Configuração 6.4.0, schema de leads 7, política MCP 1 e SDK Google search-console-reader/1.0.0 são dimensões diferentes. Provider `base-site-core-fator3` é preservado.

Configuração: revisão opaca do valor, simulação por padrão, segredo mascarado, mescla parcial tipada quando explicitada. `persisted` confirma gravação; `audit` confirma procedência; `effect` descreve efeitos síncronos; `verification` descreve evidência. Não converter `ok` em prova de HTTP público, recebimento de e-mail ou commit remoto.

`procedencia.composicao`, `complementacoes` e `reparo` seguem PROCEDENCIA-1.22.md. Valor complementado muda revisão; reparo só de metadados não muda. Escrita concorrente exige releitura; falha de auditoria não apaga a prova de que um valor já persistiu.

Simulação de token Pipedrive candidato pode consultar users/me sem persistência local/comercial e devolve `verificacao_remota`. Recusa e indisponibilidade impedem substituir o segredo atual. Campos intocados não provocam essa consulta.

Abilities novas: `config-complementacoes-ler`, `config-procedencia-reparar`, `redirects-historico-ler`, `redirects-historico-escrever`, `pipedrive-reconciliar`, `pipedrive-atividade-reparar`. Consulte parâmetros no registro; não infira pelo rótulo. Reconciliação pode ler dados remotos na prévia e só altera com confirmação/provas atuais. Documentação estável por `documentacao`, A chave estável é `documentacao`; aliases antigos foram removidos.

Operação: mesma ocorrência nas retomadas, origens separadas e orçamento limitado. Ocupada/já processada não é falha de banco. Resultado incerto exige releitura antes de repetir criação/envio. Core pausado mantém documentação administrativa sem liberar negócio. `manter_pausado` na recriação não significa pronto para restore.

Permissões de leitura de jornada: f3base_ler_leads OU manage_options; gestão isolada não concede leitura. Configuração/CRM administrativo/redirects continuam exigindo administração, e redirects também edição do post. Conector soma sua política à autorização nativa.

Os exemplos das documentações são ilustrativos. Domínios, hashes, IDs e referências devem vir de leitura atual; não copiar IDs comerciais de outro site nem gravar diretamente no banco para contornar validação.

Clarity: cadastro humano no wp-admin, teste POST com nonce/permissão, revisão de projeto/token e cota compartilhada. GET da tela nunca chama o fornecedor. O vínculo local não é verificação independente da identidade do projeto. Consulte CLARITY-1.22.md. Não há nova ability ou mudança de schema de tabelas.

Google: o consumidor Core exige `effective_status` anunciado em `capabilities.client_methods` e chamável. Sem ele, registrar diagnóstico explícito e não usar fallback para a conexão corrente. Se anunciado mas não chamável, retornar diagnóstico `unreadable/diagnostico_sdk_indisponivel`, sem fallback silencioso. Retorno inválido e exceção também degradam o diagnóstico. Nenhum desses estados concede acesso ou veta globalmente a consulta; `query()` revalida seus controles.

## Códigos de recuperação

A guarda usa `wp-content/f3-core-state/`: `site-N.php` é a sentinela, `site-N-state.php` registra a barreira, `site-N-workers.php` coordena entradas e `site-N-task-<tarefa>.php` reserva cada tarefa. A resposta deve ser interpretada pelo código, estado e precondição atuais. Números de linha são apenas referência histórica da especificação.

| Grupo | Código | Linha | Significado | Ação |
| --- | --- | --- | --- | --- |
| Estado da guarda | `core_operacional` | 20 | Sentinela válida, sem pausa e sem falha de trava | Nenhuma |
| Estado da guarda | `core_pausado` | 20 | Sentinela com `pausado: true`; tarefas e mutações paradas | Reconciliar e chamar `retomar` |
| Estado da guarda | `trava_inacessivel` | 20, 78–79 | `site-N-workers.php` é link ou não abre para escrita | Corrigir dono e permissão; se persistir, `recriar` |
| Estado da guarda | `trava_ocupada` | 20, 80 | Outra operação segura a trava exclusiva | Aguardar e repetir |
| Estado da guarda | `trava_falhou` | 20, 80 | `flock` falhou sem indicar bloqueio | Conferir o sistema de arquivos; depois `recriar` |
| Estado da guarda | `sentinela_ausente` | 16 | `site-N.php` não existe | `recriar` com `precondicao_esperada` e as confirmações |
| Estado da guarda | `sentinela_ilegivel` | 16, 18 | Não é arquivo regular ou a leitura falhou | Corrigir tipo e permissão; depois `recriar` |
| Estado da guarda | `sentinela_invalida` | 18 | Conteúdo sem o cabeçalho ou sem `geracao` e `pausado` | `recriar` |
| Estado da guarda | `sentinela_link_recusado` | 16 | `site-N.php` é link simbólico | Remover o link; depois `recriar` |
| Estado da guarda | `diretorio_sentinela_link_recusado` | 15, 28 | A pasta é link simbólico | Trocar por pasta real |
| Estado da guarda | `diretorio_sentinela_indisponivel` | 15, 29, 43, 67 | Pasta ausente, ilegível ou impossível de criar | Criar a pasta ou corrigir a permissão |
| Estado da guarda | `indice_protetor_link_recusado` | 15, 30, 43 | `index.php` da pasta é link simbólico | Remover o link; a provisão recria o índice |
| Proteção em disco | `indice_protetor_confirmado` | 27 | `index.php` com o conteúdo esperado | Nenhuma |
| Proteção em disco | `indice_protetor_indisponivel` | 31 | `index.php` ausente ou ilegível; não pausa | Corrigir a permissão |
| Proteção em disco | `indice_protetor_divergente` | 32 | Conteúdo diferente; não é sobrescrito e não pausa | Repor o conteúdo esperado |
| Entrada da requisição | `nao_tentada` | 9 | Nenhuma tarefa protegida tentou entrar | Nenhuma |
| Entrada da requisição | `entrada_confirmada` | atual | Entrada aceita com trava compartilhada | Nenhuma |
| Respostas da operação | `core_em_recuperacao` | 85 | Chamada protegida recusada pela guarda | Ler `recuperacao` na resposta |
| Respostas da operação | `sem_permissao` | 87 | Sem `manage_options` e fora do WP-CLI | Usar conta administradora |
| Respostas da operação | `geracao_invalida` | 88 | `geracao_esperada` ausente ou não inteira | Ler o estado e enviar `geracao` |
| Respostas da operação | `geracao_divergente` | 93 | Geração diferente da enviada | Reler e repetir |
| Respostas da operação | `acao_invalida` | 94 | `acao` fora de `preparar`, `retomar`, `recriar` | Corrigir a chamada |
| Respostas da operação | `reconciliacao_externa_nao_confirmada` | 95 | `retomar` sem `reconciliacao_confirmada` | Reconciliar e confirmar |
| Respostas da operação | `barreira_ocupada` | 46, 91 | Outra operação de recuperação em curso | Aguardar e repetir |
| Respostas da operação | `barreira_nao_persistida` | 96 | `preparar` não gravou a pausa | Conferir escrita na pasta |
| Respostas da operação | `aguardando_drenagem` | 40, 49, 97 | Há trabalho em voo | Repetir a mesma chamada até `core_drenado` |
| Respostas da operação | `core_drenado` | 104 | Pausado, sem trabalho em voo | Restaurar preservando a pasta |
| Respostas da operação | `core_retomado` | 104 | Geração incrementada, filas invalidadas | Reconciliar os itens suspensos e incertos |
| Respostas da operação | `ja_retomado` | 100 | O Core já estava sem pausa | Nenhuma |
| Respostas da operação | `trava_link_recusado` | 44, 89 | Arquivo de estado ou de workers é link | Remover o link |
| Respostas da operação | `sentinela_gravacao_falhou` | 51, 58, 104 | A sentinela não foi gravada | Conferir escrita e espaço em disco |
| Respostas da operação | `sentinela_existente` | 40 | `recriar` recusado: a sentinela é válida | Usar `preparar` ou `retomar` |
| Respostas da operação | `confirmacao_recriacao_necessaria` | 41 | Falta `reconciliacao_confirmada` ou `copia_outro_host` | Enviar os dois campos |
| Respostas da operação | `precondicao_divergente` | 42, 48 | A sentinela mudou desde a leitura | Reler `precondicao` e repetir |
| Respostas da operação | `identidade_nao_persistida` | 55 | Identidade nova do Pipedrive não gravou | Repetir `recriar` |
| Respostas da operação | `sentinela_recriada` | 58 | Nova geração gravada; filas suspensas | Reconciliar; com `manter_pausado`, `retomar` depois |
| Invalidação de filas | `inventario_recuperacao_falhou` | 115 | Contagem prévia de uma fila falhou | Corrigir o banco e repetir a ação |
| Invalidação de filas | `fila_nao_suspensa` | 124 | Fila da Meta ou do Pipedrive não foi suspensa | Idem |
| Invalidação de filas | `avisos_nao_suspensos` | 128 | Avisos de contato não foram marcados | Idem |
| Invalidação de filas | `intencoes_nao_suspensas` | 129 | Marca das entregas ao Pipedrive não gravou | Idem |
| Invalidação de filas | `eliminacoes_nao_suspensas` | 131 | Eliminações remotas não foram suspensas | Idem |
| Invalidação de filas | `alertas_nao_suspensos` | 133, 134 | Alertas de entrega não foram marcados | Idem |
| Invalidação de filas | `alerta_conta_nao_suspenso` | 137 | Alerta de conta não foi marcado | Idem |
| Invalidação de filas | `cursor_nao_invalidado` | 138 | Cursor do Search Console não foi invalidado | Idem |
| Invalidação de filas | `reservas_nao_invalidadas` | 139 | Reservas do executor não foram zeradas | Idem |
| Invalidação de filas | `intencoes_nao_invalidadas` | 140 | Intenções pendentes não passaram a `suspensa` | Idem |
| Reserva de tarefa | `reserva_indisponivel` | 142, 145 | Arquivo de tarefa como link simbólico | Conferir o arquivo de tarefa |
| Reserva de tarefa | `trava_arquivo_inacessivel` | 145 | Arquivo de tarefa não abre para escrita | Corrigir a permissão |
| Reserva de tarefa | `reserva_ocupada` | 145 | Outra execução da mesma tarefa em curso | Aguardar |
| Reserva de tarefa | `trava_arquivo_falhou` | 145 | `flock` do arquivo de tarefa falhou | Conferir o sistema de arquivos |
| Marcas nos dados | `restauracao_requer_reconciliacao` | 124–137 | Item suspenso ou incerto por retomada ou recriação | Reconciliar no módulo dono antes de reenviar |
| Marcas nos dados | `copia_requer_verificacao` | 54 | Site copiado de outro host | Verificar a integração |
| Entrada da requisição | `protecao_degradada` | atual | Módulos de atendimento subiram, mas tarefas e gravações protegidas estão bloqueadas | Corrigir dono, permissão e arquivo de coordenação |
| Retirada de URL | `caminho_nao_retirado` | atual | Foi solicitada restauração de um caminho sem retirada prévia; nenhuma escrita ocorreu | Confira a operação desejada e o histórico do caminho |


## Acréscimos 1.25

Matriz homologada local: MCP 0.19.0 / Google 0.8.2. Contratos estáveis preservados. Abilities novas: medicao-sondas-ler, conteudo-instrumentacao-ler, estado-inventario-ler, avisos-fila-ler, avisos-reenviar. Schemas efetivos nos arquivos dados/abilities-*.json. Ver AGENTES-1.26.0.md e MEDICAO-1.25.md.

## Complementos 1.26

Versões de companheiros seguem `X.Y.Z` estável, com três componentes numéricos. Qualquer sufixo (`-rc1`, `-beta`, `+build`) é recusado por desenho; não inferir compatibilidade com pre-release por comparação numérica. Mínimos de contrato: MCP 0.16.0 e Google 0.7.1; matriz exercitada: 0.19.0 / 0.8.2.

Como-usar aceita assunto avisos. Canais de f3base_avisos: email, slack, ambos, webhook, email_webhook; transporte e revisão congelados na intenção. HMAC e semântica de entrega em AVISOS-WEBHOOK-1.26.md. Estrutura compartilhada permanece 1.25.0; produto e marcador são 1.26.0/1260. A âncora 1250 é preservada.

Conteudo-instrumentacao-ler usa HTML público e por_url. Limite atual: 5 URLs por chamada; veja INSTRUMENTACAO-1.26.md para paginação e cobertura. Zero pendências sem cobertura completa não é aprovação.

## Complementos 1.27

Produto/marcador: 1.28.0/1270; contrato de configuração 6.4.0. Âncoras 1260 e 1250 preservadas. `f3base_analise` recebe `clique_rotulo` e `clique_destino`; `f3base_leads.dados.comunicacao_envio` contém o resumo cifrado comum aos três canais.

`lead-jornada-ler`: `visao` aceita `atual` (padrão) e `aviso`. A segunda lê o resumo já preparado, não cria snapshot nem consulta rede. `executar-pendentes`: `reconciliar_esperas`, `simular` e `revisao` permitem reparar uma intenção por vez, preservando prazo/guardas. Leia RELEASE-1.28.0.md antes de aplicar. Schemas efetivos estão nos três arquivos dados/abilities-*.json.
