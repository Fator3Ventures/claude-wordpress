# Fator3 Site Core 1.28.0 — 10/10/2026

Esta versão implementa os pedidos 167–175 do plano aprovado. Referência de manutenção: WordPress novo ou Core 1.27.0; não há bloqueio por versão. A matriz local usa MCP 0.19.0 e MCP Google 0.8.2. Os outros plugins e os temas não são modificados.

## Entrega

| Pedido | Comportamento entregue |
|---|---|
| 167 | Rolagem lê o percentual de `detalhe`; salto e profundidade de saída ficam separados. Nomes e tempos não viram referências “Ver …” dentro da jornada. |
| 168 | Grupo `exigir_um_de` exige pelo menos um e-mail/telefone válido, sem tornar ambos obrigatórios. Todos os valores preenchidos são validados. |
| 169 | WhatsApp em nova aba por padrão; reserva no gesto final, fechamento em erro e alternativa acessível quando o navegador bloqueia. |
| 170 | Intenção durável rearma o executor mesmo sem checkpoint; agenda futura inadequada é corrigida. Prazo, reserva, quota e ocorrências são preservados. |
| 171 | Histórico do mesmo navegador/classe, campanhas observadas por sessão, filtros e total distinto de contatos; cobertura e ausência de dados explícitas. |
| 172 | Detalhes/FAQ mede somente abertura humana confirmada, por mouse ou teclado; não envia a pergunta nem gera conversão. |
| 173 | Duas etapas opcionais, mesmo contato, complemento idempotente e botão Pular. Aviso inicial + atualização quando o complemento chega depois do corte. |
| 174 | Aplicativo Slack com principal/respostas, partes duráveis, resumo horário e complemento na thread original. Webhook preservado. |
| 175 | Verificação de acesso Meta independente da importação, catálogo paginado e token da página somente em memória durante a chamada. |

E-mail, Slack completo/thread e nota do Pipedrive partem das mesmas seções canônicas, com títulos, campos, quebras de linha e limites de tamanho explícitos. O formato Slack Compacto é uma escolha explícita de identificação + link, e por isso não tem paridade integral de conteúdo. Nenhuma mensagem antiga é reenviada pela atualização.

## Instalação e operação

1. Faça backup conjunto de banco, arquivos privados e estados dos três plugins, seguindo as guardas de recuperação de cada proprietário.
2. Instale o ZIP com a pasta `base-site-core-fator3`. No MCP, use a operação de upload e acompanhe o recibo; não repita um upload com resultado ainda pendente.
3. A troca agenda migração fora do primeiro GET público. A captura existente continua disponível; recursos novos exigem suas estruturas prontas.
4. Execute pendências e confira saúde, versão, migração concluída e inventário. Uma agenda WP-Cron não prova que o cron do servidor está sendo executado.
5. Recomenda-se executor do servidor a cada minuto; uma cadência de até cinco minutos permite acompanhar o limite operacional de 900 segundos. Preserve a exclusão mútua dos processos. O pacote não configura o cron do servidor.

A nova configuração `whatsapp_nova_aba: true` é acrescentada somente quando ausente, preservando origem/canal/data e anotando a complementação. `false` explícito e listas vazias permanecem. Não são ativados aplicativos externos nem alterados grupos/etapas dos formulários publicados automaticamente. A implantação escolhe onde aplicar o novo fluxo.

## Documentação corrente

- `FORMULARIOS-1.28.md`: grupo, etapas, contrato com o tema, eventos e continuação.
- `HISTORICO-CONTATOS-1.28.md`: origem por sessão, consulta, privacidade e limites.
- `SLACK-1.28.md`: aplicativo, formatos, contingência e reconciliação.
- `META-ACESSO-1.28.md`: verificação e separação da importação.
- `AGENTES-1.28.0.md`: operação, segredos, testes e responsabilidades.
- `VALIDACAO.md`: evidências locais e homologação que depende do ambiente real.

## Limites da comprovação

Os testes locais usam WordPress, banco, REST e navegador reais; respostas comerciais externas são simuladas. Isso não comprova permissões das contas Slack/Meta/Pipedrive da frota, entrega real de e-mail, comportamento de Safari iOS/Instagram em aparelhos físicos ou sete dias de operação nos 14 sites. Esses aceites permanecem de homologação após instalar, com os roteiros em `VALIDACAO.md`. Não foram realizados testes nos sites de produção.
