<?php
/** Reconciliação explícita da atualização; nunca repete o contato inicial. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Complementos_Operacao {
    private static function revisao_entrega(array $row): string {return hash('sha256',wp_json_encode(array_intersect_key($row,array_flip(array('chave','estado','email','slack','crm','journal','atualizado_em')))));}
    public static function reconciliar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $dest=$e['destino']??'';if(!in_array($dest,array('email','crm','slack'),true)||!preg_match('/^[a-f0-9]{64}$/D',$e['chave']??'')){return array('ok'=>false,'codigo'=>'entrada_invalida');}
        global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$e['chave']),ARRAY_A);if(!$row){return array('ok'=>false,'codigo'=>'complemento_ausente');}$rev=self::revisao_entrega($row);
        if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'revisao'=>$rev,'estado'=>$row[$dest],'aviso'=>'Reagenda somente esta atualização. Confira o resultado no destino; reenvio de resultado incerto pode duplicar a atualização. Partes Slack exigem reconciliação individual antes.');}
        if(!hash_equals($rev,(string)($e['revisao']??''))){return array('ok'=>false,'codigo'=>'conflito');}if(($e['confirmar']??false)!==true||($e['aceitar_duplicacao']??false)!==true){return array('ok'=>false,'codigo'=>'confirmacao_necessaria');}
        if(!in_array($row[$dest],array('falhou','incerto','pendente','enviando'),true)){return array('ok'=>false,'codigo'=>'destino_nao_reagendavel');}
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}$lock=F3Base_Trava::adquirir('complementos-entrega',60);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>false,'codigo'=>'reserva_ocupada');}
        try{
            $lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){return array('ok'=>false,'codigo'=>'registro_nao_elegivel');}
            $journal=json_decode($row['journal'],true)?:array();if($dest==='crm'&&isset($journal['crm_operacoes'])){$journal['crm_operacoes']['estado']='pendente';}
            $journal['reconciliacao']=array('destino'=>$dest,'em'=>time(),'autor'=>get_current_user_id(),'estado_anterior'=>$row[$dest],'aceitar_duplicacao'=>true);
            $ok=$wpdb->update(self::tabela(),array($dest=>'pendente','estado'=>'pendente','journal'=>wp_json_encode($journal),'proxima'=>time()+1,'atualizado_em'=>time()),array('chave'=>$row['chave'],'estado'=>$row['estado'],'journal'=>$row['journal'],'atualizado_em'=>$row['atualizado_em']))===1;
            if($ok){F3Base_Fila::agendar(self::EVENTO,time()+1);}return array('ok'=>$ok,'persisted'=>$ok,'codigo'=>$ok?'atualizacao_reagendada':'conflito_ou_falha_gravacao','execucao_realizada'=>false);
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
}
