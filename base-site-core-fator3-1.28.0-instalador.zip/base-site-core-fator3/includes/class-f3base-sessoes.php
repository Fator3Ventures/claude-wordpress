<?php
/** Índice derivado, reconstruível e limitado pela retenção dos eventos. Não mede outra visita. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/trait-f3base-sessoes-relatorios.php';
final class F3Base_Sessoes {
    use F3Base_Sessoes_Relatorios;
    const EVENTO='f3base_sessoes_indexar';
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_sessoes';}
    public static function campanhas_tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_contato_campanhas';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();$c=self::campanhas_tabela();$cc=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $t (
 classe varchar(16) NOT NULL,
 sessao char(32) NOT NULL,
 visitante char(32) NOT NULL,
 inicio bigint NOT NULL,
 primeira bigint NOT NULL,
 ultima bigint NOT NULL,
 origem longtext NOT NULL,
 decisao_ref char(64) NOT NULL DEFAULT '',
 conflito tinyint NOT NULL DEFAULT 0,
 atualizado_em bigint NOT NULL,
 PRIMARY KEY  (classe,sessao),
 KEY visitante (visitante,classe,inicio),
 KEY retencao (ultima)
) $cc;");if($wpdb->last_error){return false;}
        dbDelta("CREATE TABLE $c (
 record_id char(32) NOT NULL,
 campanha char(64) NOT NULL,
 rotulo varchar(191) NOT NULL,
 plataforma varchar(32) NOT NULL,
 primeira bigint NOT NULL,
 ultima bigint NOT NULL,
 sessoes int unsigned NULL,
 decisoes_refs longtext NOT NULL,
 PRIMARY KEY  (record_id,campanha),
 KEY campanha (campanha,record_id),
 KEY rotulo (rotulo,record_id)
) $cc;");return !$wpdb->last_error;
    }
    public static function iniciar(): void {
        add_action(self::EVENTO,array(__CLASS__,'indexar'));
        add_action('f3base_retencao_limpeza',array(__CLASS__,'reter'));
        add_action('f3base_lead_eliminando',array(__CLASS__,'eliminar'));
    }
    public static function disponivel(): bool {global $wpdb;return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like(self::tabela())))===self::tabela();}
    public static function indexar(): array {
        if(!self::disponivel()){return array('ok'=>false,'codigo'=>'estrutura_sessoes_pendente');}
        $lock=F3Base_Trava::adquirir('sessoes-indexar',45);if(!$lock){return array('ok'=>true,'codigo'=>'reserva_ocupada');}
        global $wpdb;try{
            self::reter();$state=get_option('f3base_sessoes_indice',array());$cursor=(int)($state['cursor']??0);
            $rows=$wpdb->get_results($wpdb->prepare('SELECT id,sessao,classe_trafego FROM %i WHERE id>%d AND criado_em>=%d ORDER BY id LIMIT 250',F3Base_Analise::tabela(),$cursor,F3Base_Editorial::corte_retencao()),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'sessoes_leitura_falhou');}$seen=array();
            foreach($rows as $r){$key=$r['sessao'].'|'.$r['classe_trafego'];if(!isset($seen[$key])){if(!self::atualizar($r['sessao'],$r['classe_trafego'])){return array('ok'=>false,'codigo'=>'sessoes_gravacao_falhou');}$seen[$key]=true;}$cursor=(int)$r['id'];}
            $saved=F3Base_Options::atualizar_estado('f3base_sessoes_indice',static fn($s)=>array_merge($s,array('cursor'=>$cursor,'em'=>time())));
            self::indexar_contatos($state);F3Base_Fila::agendar(self::EVENTO,time()+(count($rows)===250?5:300));
            return array('ok'=>!empty($saved['persisted']),'processados'=>count($rows),'parcial'=>count($rows)===250);
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function atualizar(string $sessao,string $classe): bool {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT visitante,inicio_sessao,criado_em,atribuicao,decisao_ref,publicidade FROM %i WHERE sessao=%s AND classe_trafego=%s AND criado_em>=%d ORDER BY criado_em,evento LIMIT 1001',F3Base_Analise::tabela(),$sessao,$classe,F3Base_Editorial::corte_retencao()),ARRAY_A);
        if($wpdb->last_error){return false;}if(!$rows){return $wpdb->delete(self::tabela(),array('sessao'=>$sessao,'classe'=>$classe))!==false;}
        $first=$rows[0];$ids=array_unique(array_column($rows,'visitante'));$a=json_decode($first['atribuicao'],true)?:array();$a=is_array($a['sessao_origem']??null)?$a['sessao_origem']:array();
        $v=array('classe'=>$classe,'sessao'=>$sessao,'visitante'=>count($ids)===1?$first['visitante']:'','inicio'=>(int)($first['inicio_sessao']?:$first['criado_em']),'primeira'=>(int)$first['criado_em'],'ultima'=>max(array_column($rows,'criado_em')),'origem'=>wp_json_encode(F3Base_Contato_Apresentacao::atribuicao($a,!empty($first['publicidade']))),'decisao_ref'=>$first['decisao_ref']??'','conflito'=>count($ids)!==1?1:0,'atualizado_em'=>time());
        return $wpdb->replace(self::tabela(),$v)!==false;
    }
    /** Rebuild just the contact's bounded slice, off the public collection path. */
    public static function historico(array $lead,?int $recebimento=null,int $pagina=1): array {
        $out=array('ok'=>true,'codigo'=>'historico_indisponivel','visitas'=>array(),'campanhas'=>array(),'retencao_dias'=>F3Base_Modulo_Comportamento::retencao_eventos_dias(),'pagina'=>max(1,$pagina));
        $permit=F3Base_Contato_Apresentacao::consentimento($lead['dados']);
        if(!$permit['medicao']||!empty($lead['dados']['audiencia_excluida'])){$out['codigo']='medicao_nao_permitida_ou_revogada';return $out;}
        if(empty($lead['sessao'])){$out['codigo']='sessao_indisponivel';$out['campanhas']=self::origens_contato($lead);return $out;}
        if(!self::disponivel()){$out['codigo']='estrutura_sessoes_pendente';return $out;}
        global $wpdb;$end=strtotime($lead['criado_em'].' UTC');$from=F3Base_Editorial::corte_retencao();$receipt=$recebimento??time();
        $rows=$wpdb->get_results($wpdb->prepare('SELECT DISTINCT visitante FROM %i WHERE sessao=%s AND classe_trafego=%s AND criado_em BETWEEN %d AND %d AND recebido_em>0 AND recebido_em<=%d',F3Base_Analise::tabela(),$lead['sessao'],$lead['classe_trafego'],$from,$end,$receipt),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'sessoes_leitura_falhou');}
        $declared=$lead['dados']['contexto']['audiencia']['visitante']??'';$ids=array_column($rows,'visitante');
        if(count($ids)!==1||($declared!==''&&!in_array($declared,$ids,true))){$out['codigo']=$ids?'vinculo_visitante_conflitante':'visitante_sem_evidencia_retida';if(!$ids){$out['campanhas']=self::origens_contato($lead);}return $out;}$visitor=$ids[0];
        $sessions=$wpdb->get_results($wpdb->prepare('SELECT sessao,MIN(criado_em) primeira,MAX(criado_em) ultima,MIN(NULLIF(inicio_sessao,0)) inicio FROM %i WHERE visitante=%s AND classe_trafego=%s AND criado_em BETWEEN %d AND %d AND recebido_em>0 AND recebido_em<=%d GROUP BY sessao ORDER BY primeira DESC,sessao LIMIT 501',F3Base_Analise::tabela(),$visitor,$lead['classe_trafego'],$from,$end,$receipt),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'sessoes_leitura_falhou');}
        $current=null;foreach($sessions as $v){if($v['sessao']===$lead['sessao']){$current=$v;break;}}if(!$current){$out['codigo']='sessao_sem_eventos_retidos';return $out;}
        $start=(int)($current['inicio']?:$current['primeira']);$out['observadas_servidor']=count($sessions);$out['corte']=count($sessions)>500;$out['cobertura_desde']=$from;$out['visitante']=$visitor;$out['contador_navegador']=$lead['dados']['contexto']['audiencia']['visitas']??$lead['dados']['contexto']['audiencia']['contador_visitas']??null;$visits=array();$campaigns=array();
        $origins=array();$all=$wpdb->get_results($wpdb->prepare('SELECT sessao,atribuicao,decisao_ref,publicidade FROM %i WHERE visitante=%s AND classe_trafego=%s AND criado_em BETWEEN %d AND %d AND recebido_em>0 AND recebido_em<=%d ORDER BY criado_em,evento LIMIT 10001',F3Base_Analise::tabela(),$visitor,$lead['classe_trafego'],$from,$end,$receipt),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'sessoes_leitura_falhou');}if(count($all)>10000){$out['codigo']='historico_excede_orcamento';$out['corte']=true;return $out;}
        foreach($all as $item){if(!isset($origins[$item['sessao']])){$origins[$item['sessao']]=$item;}}
        $keys=array_column($sessions,'sessao');$qs=implode(',',array_fill(0,count($keys),'%s'));$conflicts=$wpdb->get_col($wpdb->prepare('SELECT DISTINCT sessao FROM %i WHERE visitante<>%s AND classe_trafego=%s AND criado_em BETWEEN %d AND %d AND recebido_em<=%d AND sessao IN ('.$qs.')',F3Base_Analise::tabela(),$visitor,$lead['classe_trafego'],$from,$end,$receipt,...$keys));
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'sessoes_leitura_falhou');}$conflicts=array_flip($conflicts);
        $refs=array_values(array_unique(array_filter(array_column($origins,'decisao_ref'))));$decisions=array();
        if($refs){$qs=implode(',',array_fill(0,count($refs),'%s'));$decisions=$wpdb->get_results($wpdb->prepare('SELECT ref,medicao,publicidade,revogada FROM %i WHERE ref IN ('.$qs.')',$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA,...$refs),OBJECT_K);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consentimento_leitura_falhou');}}
        $out['decisoes_refs']=$refs;
        // Origin comes from the earliest eligible event, never from attributed root/first touch.
        foreach(array_slice($sessions,0,500) as $v){
            if(isset($conflicts[$v['sessao']])){$out['vinculos_conflitantes_omitidos']=($out['vinculos_conflitantes_omitidos']??0)+1;continue;}
            $first=$origins[$v['sessao']]??null;if(!$first){continue;}$raw=json_decode($first['atribuicao'],true)?:array();$origin=$raw['sessao_origem']??array();$allowed=$permit['publicidade']&&!empty($first['publicidade']);
            $dec=isset($decisions[$first['decisao_ref']])?(array)$decisions[$first['decisao_ref']]:null;
            if($dec&&(!empty($dec['revogada'])||empty($dec['medicao']))){continue;}$allowed=$allowed&&(!$dec||!empty($dec['publicidade']));
            $origin=F3Base_Contato_Apresentacao::atribuicao(is_array($origin)?$origin:array(),$allowed);$v['origem']=$origin;$v['origem_codigo']=$origin?'origem_da_sessao':'origem_desconhecida';$v['publicidade_reduzida']=!$allowed;$v['inicio']=(int)($v['inicio']?:$v['primeira']);$v['primeira']=(int)$v['primeira'];$v['ultima']=(int)$v['ultima'];$v['intervalo_observado_segundos']=$v['ultima']-$v['primeira'];
            if(!empty($origin['utm_campaign'])||!empty($origin['campanha_id'])){$key=self::campanha_chave($origin);if(!isset($campaigns[$key])){$campaigns[$key]=array('chave'=>$key,'nome'=>$origin['utm_campaign']??'','plataforma'=>$origin['plataforma']??'','conta_id'=>$origin['conta_id']??'','campanha_id'=>$origin['campanha_id']??'','identidade_incompleta'=>empty($origin['conta_id'])||empty($origin['campanha_id']),'primeira_em'=>$v['primeira'],'ultima_em'=>$v['primeira'],'sessoes'=>0);}++$campaigns[$key]['sessoes'];$campaigns[$key]['primeira_em']=min($campaigns[$key]['primeira_em'],$v['primeira']);$campaigns[$key]['ultima_em']=max($campaigns[$key]['ultima_em'],$v['primeira']);}
            if($v['sessao']===$lead['sessao']){$out['origem_atual']=$origin;continue;}
            if($v['inicio']>=$start){$out['ordem_ambigua']=true;continue;}$v['sobreposta']=$v['ultima']>=$start;$visits[]=$v;
        }
        $out['anteriores_total']=count($visits);$offset=(max(1,$pagina)-1)*20;$selected=array_slice($visits,$offset,20);$out['proxima_pagina']=count($visits)>$offset+20?$pagina+1:null;
        foreach($selected as $idx=>&$v){$fake=$lead;$fake['sessao']=$v['sessao'];$fake['criado_em']=gmdate('Y-m-d H:i:s',min($v['ultima'],$end));$j=F3Base_Contato_Apresentacao::jornada($fake,$receipt);if(empty($j['ok'])){return $j;}$v['paginas_distintas']=$j['paginas_distintas']??null;$v['tempo_ativo_ms']=$j['tempo_ativo_total_ms']??null;$v['sobreposta']=$v['sobreposta']||!empty($j['simultaneidade_observada']);$v['paginas']=$idx<5?array_slice($j['paginas']??array(),0,12):array();$v['paginas_omitidas']=max(0,count($j['paginas']??array())-count($v['paginas']));$v['detalhada']=$idx<5;}unset($v);
        usort($campaigns,static fn($a,$b)=>[$b['ultima_em'],$a['chave']]<=>[$a['ultima_em'],$b['chave']]);$out['campanhas']=array_values($campaigns);$out['visitas']=$selected;$out['codigo']='historico_observado';return $out;
    }
    public static function campanha_chave(array $a): string {return hash('sha256',wp_json_encode(!empty($a['campanha_id'])?array($a['plataforma']??'', $a['conta_id']??'', $a['campanha_id']):array($a['plataforma']??'',$a['conta_id']??'',mb_strtolower($a['utm_source']??''),mb_strtolower($a['utm_medium']??''),mb_strtolower($a['utm_campaign']??''))));}
    public static function gravar_campanhas(string $id,array $list,array $refs=array()): bool {global $wpdb;if($wpdb->query('START TRANSACTION')===false){return false;}$ok=$wpdb->delete(self::campanhas_tabela(),array('record_id'=>$id))!==false;foreach($list as $c){$ok=$wpdb->replace(self::campanhas_tabela(),array('record_id'=>$id,'campanha'=>$c['chave'],'rotulo'=>mb_substr($c['nome'],0,191),'plataforma'=>$c['plataforma'],'primeira'=>$c['primeira_em']??0,'ultima'=>$c['ultima_em']??0,'sessoes'=>$c['sessoes'],'decisoes_refs'=>wp_json_encode($refs)))!==false&&$ok;}if(!$ok){$wpdb->query('ROLLBACK');return false;}return $wpdb->query('COMMIT')!==false;}
    public static function linhas(array $h): array {
        $out=array('Histórico de visitas'=>($h['codigo']??'')==='historico_observado'?'Visitas do mesmo navegador e classe de tráfego dentro da retenção.':F3Base_Contato_Apresentacao::rotulo($h['codigo']??'historico_indisponivel'));
        if(($h['codigo']??'')!=='historico_observado'){return $out;}
        if(isset($h['contador_navegador'])){$out['Contagem do navegador']=(string)$h['contador_navegador'];}$out['Sessões observadas no servidor']=(string)$h['observadas_servidor'];$out['Cobertura histórica']='Eventos disponíveis desde '.wp_date('d/m/Y H:i:s P',$h['cobertura_desde']).'; '.$h['retencao_dias'].' dias de retenção. A ausência de sessão anterior não comprova primeira visita.';
        foreach($h['visitas'] as $i=>$v){$lines=array(wp_date('d/m/Y H:i:s P',$v['inicio']).' · '.F3Base_Contato_Comunicacao::tempo($v['intervalo_observado_segundos']).' de intervalo observado · '.($v['paginas_distintas']??'?').' página(s)',isset($v['tempo_ativo_ms'])?F3Base_Contato_Comunicacao::tempo($v['tempo_ativo_ms']/1000).' ativos':'Tempo ativo não observado');$origin=F3Base_Contato_Apresentacao::linhas_atribuicao($v['origem']);$lines[]=implode(' · ',$origin)?:'Origem desconhecida';if($v['publicidade_reduzida']){$lines[]='Detalhes publicitários reduzidos pela autorização.';}if($v['sobreposta']){$lines[]='Há sobreposição de visitas/abas; os tempos não representam atenção exclusiva.';}
            if($v['detalhada']){foreach($v['paginas'] as $p){$lines[]=wp_date('H:i:s',$p['primeiro_em']).' · '.$p['pagina'];}}if($v['paginas_omitidas']){$lines[]=$v['paginas_omitidas'].' página(s) sem detalhamento neste resumo.';}$out['Visita anterior '.($i+1)]=$v['detalhada']?$lines:implode(' · ',array_slice($lines,0,3));}
        if($h['proxima_pagina']){$out['Visitas mais antigas']=max(0,$h['anteriores_total']-count($h['visitas'])).' visita(s) adicional(is); consulte o histórico paginado no WordPress.';}
        return $out;
    }
    public static function campanhas_texto(array $list): string {$r=array();foreach($list as $c){$line=($c['nome']?:$c['campanha_id']).' · '.$c['plataforma'];if(!empty($c['origem_historica_contato'])){$line.=' · Origem histórica registrada no contato; contagem de visitas indisponível.'.(!empty($c['primeira_em'])?' Toque registrado: '.wp_date('d/m/Y H:i:s P',$c['primeira_em']).(!empty($c['ultima_em'])&&$c['ultima_em']!==$c['primeira_em']?' → '.wp_date('d/m/Y H:i:s P',$c['ultima_em']):''):' Datas indisponíveis.');}else{$line.=' · '.wp_date('d/m/Y H:i:s',$c['primeira_em']).' → '.wp_date('d/m/Y H:i:s',$c['ultima_em']).' · '.$c['sessoes'].' sessão(ões)';}$r[]=$line.($c['identidade_incompleta']?' · identidade incompleta':'');}return implode("\n",$r);}

    public static function reter(): void {global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE ultima<%d LIMIT 1000',self::tabela(),F3Base_Editorial::corte_retencao()));}
    public static function esquecer(string $visitor): void {global $wpdb;$wpdb->delete(self::tabela(),array('visitante'=>$visitor));}
    public static function eliminar(string $record): void {global $wpdb;$wpdb->delete(self::campanhas_tabela(),array('record_id'=>$record));$lead=F3Base_Leads_Repositorio::obter($record);if($lead&&!empty($lead['sessao'])){$wpdb->delete(self::tabela(),array('sessao'=>$lead['sessao']));}}
}
