<?php
/** Graph: tokens de página apenas em memória; diagnóstico sem mensagem bruta. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Meta_Acesso {
    private static array $config=array(),$prova=array(),$paginas=array(),$erro=array();private static string $token='';
    public static function preparar(): void {$c=F3Base_Options::fotografia('f3base_anuncios_meta');$s=F3Base_Options::fotografia_bruta('f3base_anuncios_meta_token');self::$config=$c['valor'];self::$prova=array('revisao'=>$c['revisao'],'credencial_revisao'=>$s['revisao']);self::$token=$s['erro']?'':F3Base_Segredos::abrir('f3base_anuncios_meta_token',is_string($s['valor'])?$s['valor']:'');self::$paginas=array();self::$erro=array();}
    public static function atual(): bool {return F3Base_Integracoes::revisoes_atuais(self::$prova,'f3base_anuncios_meta','f3base_anuncios_meta_token');}
    public static function ultimo_erro(): array {return self::$erro;}
    public static function limpar(): void {self::$token='';self::$paginas=array();}
    private static function etapa(string $path,array $q): string {if($path==='me/permissions'){return 'permissoes';}if(str_starts_with($path,'act_')){return 'conta';}if(str_ends_with($path,'/leadgen_forms')){return 'formularios_da_pagina';}if(str_ends_with($path,'/leads')){return 'leads_do_formulario';}return str_contains($q['fields']??'','access_token')?'resolver_token_pagina':'formulario';}
    private static function falha(string $code,string $path,array $q,string $kind,int $http=0,array $remote=array()): array {
        self::$erro=array('codigo'=>$code,'etapa'=>self::etapa($path,$q),'identificador'=>preg_match('/^(?:act_)?([0-9]+)/',$path,$m)?$m[1]:null,'http'=>$http,'graph_code'=>is_numeric($remote['code']??null)?(int)$remote['code']:null,'graph_subcode'=>is_numeric($remote['error_subcode']??null)?(int)$remote['error_subcode']:null,'graph_type'=>is_string($remote['type']??null)&&preg_match('/^[A-Za-z_]{1,80}$/D',$remote['type'])?$remote['type']:null,'versao_api'=>self::$config['versao_api']??'','tipo_token'=>$kind,'em'=>time());
        return array('ok'=>false,'codigo'=>$code,'diagnostico'=>self::$erro);
    }
    public static function graph(string $path,array $query=array(),string $page=''): array {
        if(!self::$prova){self::preparar();}$kind=$page!==''?'pagina':'configurado';
        if(!self::atual()){return self::falha('configuracao_ou_credencial_alterada',$path,$query,$kind);}
        if(!self::$token||!preg_match('#^(?:act_[0-9]+|me/permissions|[0-9]+(?:/(?:leadgen_forms|leads))?)$#D',$path)){return self::falha('credencial_ou_rota_indisponivel',$path,$query,$kind);}
        $token=self::$token;
        if($page!==''){
            if(!in_array($page,array_map('strval',self::$config['paginas']??array()),true)){return self::falha('pagina_nao_autorizada',$path,$query,$kind);}
            if(!isset(self::$paginas[$page])){$r=self::graph($page,array('fields'=>'id,access_token'));if(empty($r['ok'])){return $r;}$v=$r['json'];if((string)($v['id']??'')!==$page||!is_string($v['access_token']??null)||$v['access_token']===''){return self::falha('token_pagina_nao_resolvido',$page,array('fields'=>'access_token'),'configurado');}self::$paginas[$page]=$v['access_token'];unset($v,$r);}$token=self::$paginas[$page];
        }
        $r=wp_remote_get('https://graph.facebook.com/'.self::$config['versao_api'].'/'.$path.'?'.http_build_query($query,'','&',PHP_QUERY_RFC3986),array('timeout'=>5,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>1048576,'headers'=>array('Authorization'=>'Bearer '.$token)));unset($token);
        if(!self::atual()){return self::falha('configuracao_ou_credencial_alterada',$path,$query,$kind);}
        if(is_wp_error($r)){return self::falha('graph_transporte_indisponivel',$path,$query,$kind);}$http=(int)wp_remote_retrieve_response_code($r);$j=json_decode(wp_remote_retrieve_body($r),true,64,JSON_BIGINT_AS_STRING);
        if($http!==200||!is_array($j)||isset($j['error'])){return self::falha('graph_acesso_recusado',$path,$query,$kind,$http,is_array($j['error']??null)?$j['error']:array());}
        return array('ok'=>true,'json'=>$j);
    }
    public static function verificar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}self::preparar();
        if(!hash_equals(self::$prova['revisao'],(string)($e['revisao']??''))){self::limpar();return array('ok'=>false,'codigo'=>'revisao_divergente');}
        if(($e['simular']??true)!==false){self::limpar();return array('ok'=>true,'simular'=>true,'efeito'=>'Consulta credencial, conta, páginas e formulários. Não lê leads, ativa integração nem altera cursores de importação.');}
        if(!F3Base_Recuperacao::entrar()){self::limpar();return array('ok'=>false,'codigo'=>'core_em_recuperacao');}$lock=F3Base_Trava::adquirir('meta-acesso',30);if(!$lock){F3Base_Recuperacao::sair();self::limpar();return array('ok'=>false,'codigo'=>'verificacao_em_execucao');}
        try{
            if(!F3Base_Leads_Repositorio::quota(hash('sha256','meta-acesso|'.gmdate('Y-m-d')),120,strtotime('tomorrow UTC'))){return array('ok'=>false,'codigo'=>'limite_verificacao_diario');}
            $cfg=self::$config;$state=get_option('f3base_meta_acesso',array());$context=hash('sha256',wp_json_encode(self::$prova));
            if(($state['contexto']??'')!==$context||!empty($state['completa'])){$state=array('contexto'=>$context,'passo'=>0,'pagina_indice'=>0,'paginas'=>array(),'completa'=>false)+self::$prova;}
            $step=(int)$state['passo'];$r=array('ok'=>true);$code='verificacao_em_continuacao';
            if($step===0){$r=self::graph('me/permissions');if(!empty($r['ok'])){$perms=array();foreach($r['json']['data']??array() as $p){if(($p['status']??'')==='granted'){$perms[]=sanitize_key($p['permission']??'');}}$state['permissoes']=$perms;$state['passo']=1;}}
            elseif($step===1){if(!preg_match('/^[0-9]+$/D',$cfg['conta_id'])){$r=array('ok'=>false,'codigo'=>'conta_nao_configurada');}else{$r=self::graph('act_'.$cfg['conta_id'],array('fields'=>'account_id'));if(!empty($r['ok'])){if((string)($r['json']['account_id']??'')!==$cfg['conta_id']){$r=array('ok'=>false,'codigo'=>'conta_divergente');}else{$state['conta_confirmada']=true;$state['passo']=2;}}}}
            else{
                $page=(string)($cfg['paginas'][$state['pagina_indice']]??'');if($page===''){$authorized=array();foreach($state['paginas'] as $v){$authorized=array_merge($authorized,array_keys($v['formularios']??array()));}$missing=array_diff(array_map('strval',$cfg['formularios']),array_map('strval',$authorized));$state['formularios_ausentes']=array_values($missing);$state['completa']=true;$r=array('ok'=>!$missing&&!!$cfg['paginas']&&!!$cfg['formularios'],'codigo'=>$missing?'formulario_fora_das_paginas':(!$cfg['paginas']||!$cfg['formularios']?'configuracao_incompleta':'meta_acesso_verificado'));}
                else{$q=array('fields'=>'id,name,status','limit'=>100);if(!empty($state['cursor'])){$q['after']=$state['cursor'];}$r=self::graph($page.'/leadgen_forms',$q,$page);
                    if(!empty($r['ok'])){foreach($r['json']['data']??array() as $form){if(preg_match('/^[0-9]+$/D',(string)($form['id']??''))){$state['paginas'][$page]['formularios'][(string)$form['id']]=mb_substr(sanitize_text_field($form['name']??''),0,200);}}$next=!empty($r['json']['paging']['next'])?($r['json']['paging']['cursors']['after']??''):'';if(!empty($r['json']['paging']['next'])&&(!$next||$next===($state['cursor']??''))){$r=array('ok'=>false,'codigo'=>'catalogo_cursor_invalido');}else{$state['cursor']=$next;if(!$next){$state['paginas'][$page]['completa']=true;$state['pagina_indice']++;}}}
                }
            }
            $state['em']=time();$state['ok']=!empty($r['ok']);$state['codigo']=$r['codigo']??$code;$state['diagnostico']=self::$erro;
            $saved=F3Base_Options::atualizar_estado('f3base_meta_acesso',static fn($s)=>self::atual()?$state:null);return array('ok'=>$state['ok']&&!empty($saved['persisted']),'codigo'=>$state['codigo'],'persisted'=>!empty($saved['persisted']),'completa'=>$state['completa'],'estado'=>$state);
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();self::limpar();}
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('anuncios-meta-acesso-verificar','Verificar acesso Meta sem ativar importação; repetir para continuar catálogo',array(__CLASS__,'verificar'),array('revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array('revisao'),false));
        add_action('admin_post_f3base_meta_acesso',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-meta-acesso');self::verificar(array('simular'=>false,'revisao'=>sanitize_text_field($_POST['revisao']??'')));wp_safe_redirect(admin_url('admin.php?page=f3base-integracoes&integracao=f3base_anuncios_meta'));exit;});
    }
    public static function tela(): void {echo '<h2>Verificação de acesso Meta</h2><p>Funciona com a integração desligada. Consulta uma etapa por ação; repita para continuar. Não importa contatos nem altera a janela de importação. Limite local: 120 etapas por dia.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_meta_acesso"><input type="hidden" name="revisao" value="'.esc_attr(F3Base_Options::revisao('f3base_anuncios_meta')).'">';wp_nonce_field('f3base-meta-acesso');submit_button('Verificar / continuar acesso','secondary');echo '</form><pre>'.esc_html(wp_json_encode(get_option('f3base_meta_acesso',array()),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre>';}
}
