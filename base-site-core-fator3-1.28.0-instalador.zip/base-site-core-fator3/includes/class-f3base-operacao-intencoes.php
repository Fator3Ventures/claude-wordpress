<?php
/** Intenções duráveis e pagináveis. Ocorrência original e recuo não mudam por uma leitura. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Operacao_Intencoes {
    const SCHEMA=2;
    const ADIAMENTOS_LIMITADOS=array('reserva_ocupada','orcamento_esgotado','core_em_recuperacao','ocorrencia_ocupada');
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_operacao_intencoes';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();
        dbDelta("CREATE TABLE {$t} (
            chave char(64) NOT NULL,
escopo char(64) NOT NULL,
tarefa varchar(64) NOT NULL,
hook varchar(100) NOT NULL,
            argumentos longtext NOT NULL,
ocorrencia_em bigint NOT NULL,
recorrencia varchar(64) NOT NULL DEFAULT '',
            estado varchar(24) NOT NULL DEFAULT 'pendente',
falhas tinyint unsigned NOT NULL DEFAULT 0,
quota_adiamentos smallint unsigned NOT NULL DEFAULT 0,
            tentar_em bigint NOT NULL DEFAULT 0,
cobertura_ate bigint NOT NULL DEFAULT 0,
codigo varchar(64) NOT NULL DEFAULT '',
            criada_em bigint NOT NULL,
atualizada_em bigint NOT NULL,
reserva char(36) NOT NULL DEFAULT '',
reserva_ate bigint NOT NULL DEFAULT 0,
reativada_por bigint NOT NULL DEFAULT 0,
reativada_origem varchar(24) NOT NULL DEFAULT '',
            PRIMARY KEY  (chave),
KEY vencidas (estado,tentar_em),
KEY escopo (escopo,estado),
KEY tarefa (tarefa,estado)
        ) {$wpdb->get_charset_collate()};");
        return !$wpdb->last_error&&$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
    }
    public static function chave(array $e): string {return hash('sha256',$e['hook'].'|'.serialize($e['args']).'|'.($e['timestamp']??''));}
    public static function escopo(array $e): string {return hash('sha256',$e['hook'].'|'.serialize($e['args']));}
    private static function evento(array $r): array {return array('id'=>$r['tarefa'],'hook'=>$r['hook'],'args'=>json_decode($r['argumentos'],true)?:array(),'timestamp'=>(int)$r['ocorrencia_em'],'schedule'=>$r['recorrencia']?:false,'tentar_em'=>(int)$r['tentar_em'],'intencao'=>$r['chave'],'escopo'=>$r['escopo'],'estado'=>$r['estado'],'codigo'=>$r['codigo'],'atualizada_em'=>(int)$r['atualizada_em'],'falhas'=>(int)$r['falhas'],'quota_adiamentos'=>(int)($r['quota_adiamentos']??0),'criada_em'=>(int)$r['criada_em'],'reserva_ate'=>(int)$r['reserva_ate'],'em_execucao'=>(int)$r['reserva_ate']>time(),'cobertura_ate'=>(int)$r['cobertura_ate']);}
    public static function obter(array $e): array {
        global $wpdb;$r=!empty($e['intencao'])?$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s AND escopo=%s',self::tabela(),$e['intencao'],self::escopo($e)),ARRAY_A):$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE escopo=%s AND estado IN ('pendente','esgotada','suspensa') ORDER BY ocorrencia_em LIMIT 1",self::tabela(),self::escopo($e)),ARRAY_A);
        if($wpdb->last_error){throw new RuntimeException('intencoes_leitura_falhou');}return $r?self::evento($r):array();
    }
    public static function listar(int $pagina=1,bool $vencidas=false): array {
        global $wpdb;$where=$vencidas?"estado='pendente' AND tentar_em<=".time():"estado<>'concluida'";
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY tentar_em,ocorrencia_em,chave LIMIT 100 OFFSET %d",self::tabela(),max(0,$pagina-1)*100),ARRAY_A);if($wpdb->last_error){throw new RuntimeException('intencoes_leitura_falhou');}return array_map(array(__CLASS__,'evento'),$rows);
    }
    public static function resumo(int $pagina=1): array {global $wpdb;$counts=$wpdb->get_results($wpdb->prepare('SELECT estado,COUNT(*) AS quantidade FROM %i GROUP BY estado',self::tabela()),ARRAY_A);$ok=!$wpdb->last_error;return array('ok'=>$ok,'schema'=>self::SCHEMA,'contagens'=>$counts,'por_tarefa'=>$wpdb->get_results($wpdb->prepare("SELECT tarefa,estado,COUNT(*) AS quantidade FROM %i WHERE estado<>'concluida' GROUP BY tarefa,estado",self::tabela()),ARRAY_A),'pagina'=>max(1,$pagina),'por_pagina'=>100,'itens'=>$ok?self::listar($pagina):array());}
    public static function registrar(array $e,int $quando=0): bool {
        global $wpdb;if(!F3Base_Operacao::identificar_hook($e['hook'])||!is_array($e['args'])){return false;}
        $e['timestamp']=$e['timestamp']??time();$t=self::tabela();$n=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO %i (chave,escopo,tarefa,hook,argumentos,ocorrencia_em,recorrencia,tentar_em,cobertura_ate,criada_em,atualizada_em) VALUES (%s,%s,%s,%s,%s,%d,%s,%d,%d,%d,%d)",$t,self::chave($e),self::escopo($e),$e['id'],$e['hook'],wp_json_encode($e['args'],JSON_PRESERVE_ZERO_FRACTION),$e['timestamp'],$e['schedule']??'', $quando?:time(),$e['timestamp'],time(),time()));return $n!==false;
    }
    public static function adiar(array $e,string $codigo,bool $falha=false,int $minimo=0): array {
        global $wpdb;$old=self::obter($e);if($old){if((int)($e['timestamp']??0)>$old['timestamp']){self::cobrir($old,(int)$e['timestamp']);}$e=array_merge($e,$old);}
        if(!self::registrar($e,$minimo)){return array('ok'=>false,'codigo'=>'intencao_nao_persistida');}
        if($old&&($old['estado']!=='pendente'||$old['tentar_em']>time()||!empty($old['em_execucao']))){return array('ok'=>true,'codigo'=>'retomada_preservada','status'=>$old['estado'],'intencao'=>$old['intencao'],'tentar_em'=>$old['tentar_em']);}
        $fails=min(255,($old['falhas']??0)+($falha?1:0));$limitado=!$falha&&in_array($codigo,self::ADIAMENTOS_LIMITADOS,true);
        $idade=$old?max(0,time()-(int)$old['criada_em']):0;$expirou=$limitado&&$idade>=DAY_IN_SECONDS;
        $state=($fails>=8||$expirou)?'esgotada':'pendente';$delay=$falha?min(3600,60*2**min(6,max(0,$fails-1))):($limitado?min(3600,max(60,intdiv($idade,4))):60);
        if($state==='esgotada'){$delay=3600;}if($expirou){$codigo='adiamento_expirado';}$next=max($minimo,time()+$delay);
        $quota=$codigo==='quota_aguardando'?min(65535,(int)($old['quota_adiamentos']??0)+1):0;
        $prolongada=$quota>=20; if($prolongada){$codigo='quota_espera_prolongada';$next=max($next,$minimo?:self::proxima_recorrencia($e));}
        $n=$wpdb->update(self::tabela(),array('estado'=>$state,'falhas'=>$fails,'quota_adiamentos'=>$quota,'tentar_em'=>$next,'codigo'=>sanitize_key($codigo),'reserva'=>'','reserva_ate'=>0,'atualizada_em'=>time()),array('chave'=>self::chave($e),'estado'=>'pendente'));
        if($n===false){return array('ok'=>false,'codigo'=>'intencao_nao_persistida');}
        $scheduled=(!$prolongada||$minimo>time())?self::agendar($next):false;
        return array('id'=>$e['id'],'ok'=>!$falha,'status'=>$state==='pendente'?'aguardando':$state,'codigo'=>$codigo,'intencao_persistida'=>true,'intencao'=>self::chave($e),'falhas'=>$fails,'quota_adiamentos'=>$quota,'espera_prolongada'=>$prolongada,'tentar_em'=>$next,'reagendado'=>$scheduled,'ocorrencia_original_em'=>$e['timestamp']);
    }
    private static function proxima_recorrencia(array $e): int {$s=wp_get_schedules();$seconds=(int)($s[$e['schedule']??'']['interval']??HOUR_IN_SECONDS);return time()+max(60,$seconds);}
    public static function limpeza(): array {$n=self::podar();if($n===500){F3Base_Fila::agendar('f3base_intencoes_podar',time()+60);}return array('ok'=>true,'removidas'=>$n,'saldo'=>$n===500?1:0);}
    /** Repair only the wake-up: durable deadlines, quotas and attempts are never changed here. */
    public static function recuperar(): array {
        global $wpdb;
        $at=$wpdb->get_var($wpdb->prepare("SELECT MIN(GREATEST(tentar_em,reserva_ate)) FROM %i WHERE estado='pendente'",self::tabela()));
        if($wpdb->last_error){throw new RuntimeException('intencoes_leitura_falhou');}
        if($at===null){return array('ok'=>true,'codigo'=>'sem_intencoes_pendentes');}
        $ok=self::agendar(max(time()+1,(int)$at));
        return array('ok'=>$ok,'codigo'=>$ok?'despertador_confirmado':'agenda_nao_confirmada','tentar_em'=>(int)$at,'despertador_em'=>wp_next_scheduled('f3base_operacao_retomar'));
    }
    public static function da_tarefa(string $id): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE tarefa=%s AND estado<>'concluida' ORDER BY ocorrencia_em,chave LIMIT 101",self::tabela(),$id),ARRAY_A);
        if($wpdb->last_error){throw new RuntimeException('intencoes_leitura_falhou');}return array_map(array(__CLASS__,'evento'),$rows);
    }
    public static function agendar(int $at): bool {
        $lock=F3Base_Trava::adquirir('operacao-despertador',10);if(!$lock){return false;}
        try{
            $at=max(time()+1,$at);$next=wp_next_scheduled('f3base_operacao_retomar');if($next!==false&&$next<=$at){return true;}
            // WP refuses a new single event within 10 minutes of an existing future event.
            if($next!==false&&wp_unschedule_event($next,'f3base_operacao_retomar',array(),true)!==true){return false;}
            $result=wp_schedule_single_event($at,'f3base_operacao_retomar',array(),true);$actual=wp_next_scheduled('f3base_operacao_retomar');
            if((is_wp_error($result)||$actual===false)&&$next!==false){wp_schedule_single_event($next,'f3base_operacao_retomar');}
            return !is_wp_error($result)&&$actual!==false&&$actual<=$at;
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function reservar(array $e,string $token): bool {global $wpdb;return $wpdb->query($wpdb->prepare("UPDATE %i SET reserva=%s,reserva_ate=%d,atualizada_em=%d WHERE chave=%s AND estado='pendente' AND (reserva='' OR reserva_ate<=%d)",self::tabela(),$token,time()+180,time(),self::chave($e),time()))===1;}
    public static function liberar_reserva(array $e,string $token): bool {global $wpdb;return $wpdb->update(self::tabela(),array('reserva'=>'','reserva_ate'=>0),array('chave'=>self::chave($e),'reserva'=>$token))!==false;}
    public static function cobrir(array $original,int $ate): void {global $wpdb;$wpdb->query($wpdb->prepare('UPDATE %i SET cobertura_ate=GREATEST(cobertura_ate,%d) WHERE chave=%s',self::tabela(),$ate,self::chave($original)));}
    public static function concluir(array $e): bool {global $wpdb;return $wpdb->update(self::tabela(),array('estado'=>'concluida','codigo'=>'concluida','reserva'=>'','reserva_ate'=>0,'atualizada_em'=>time()),array('chave'=>self::chave($e),'estado'=>'pendente'))!==false;}
    public static function reativar(string $chave,string $tarefa): array {
        global $wpdb;if(!preg_match('/^[a-f0-9]{64}$/D',$chave)||!isset(F3Base_Operacao::tarefas()[$tarefa])){return array('ok'=>false,'codigo'=>'intencao_invalida');}
        $n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='pendente',falhas=0,tentar_em=%d,atualizada_em=%d,reativada_por=%d,reativada_origem=%s,codigo='reativada_explicitamente' WHERE chave=%s AND tarefa=%s AND estado='esgotada'",self::tabela(),time(),time(),get_current_user_id(),F3Base_Execucoes::origem(),$chave,$tarefa));
        return array('ok'=>$n===1,'persisted'=>$n===1,'codigo'=>$n===1?'intencao_reativada':'intencao_nao_esgotada','reagendado'=>$n===1&&self::agendar(time()+1));
    }
    public static function sondar(string $chave): bool {global $wpdb;return $wpdb->query($wpdb->prepare("UPDATE %i SET estado='pendente',falhas=7,codigo='sonda_apos_esgotamento',reserva='',reserva_ate=0,atualizada_em=%d WHERE chave=%s AND estado='esgotada' AND tentar_em<=%d AND reserva_ate<=%d",self::tabela(),time(),$chave,time(),time()))===1;}
    public static function retomar(): int {global $wpdb;$n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='pendente',falhas=0,tentar_em=%d,reserva='',reserva_ate=0,codigo='retomada_apos_reconciliacao',atualizada_em=%d WHERE estado='suspensa'",self::tabela(),time()+60,time()));if($n){self::agendar(time()+60);}return (int)$n;}
    public static function podar(int $dias=7,int $limite=500): int {global $wpdb;return (int)$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE estado='concluida' AND atualizada_em<%d ORDER BY atualizada_em LIMIT %d",self::tabela(),time()-max(1,$dias)*DAY_IN_SECONDS,max(1,min(500,$limite))));}
    public static function suspender(): bool {global $wpdb;return $wpdb->query($wpdb->prepare("UPDATE %i SET estado='suspensa',codigo='restauracao_pendente',atualizada_em=%d WHERE estado='pendente'",self::tabela(),time()))!==false;}
    private static function motivo_descarte($e): string {
        if(!is_array($e)){return 'entrada_nao_e_objeto';}
        if(!isset($e['hook'],$e['args'],$e['timestamp'])){return 'campo_obrigatorio_ausente';}
        if(!is_string($e['hook'])||!F3Base_Operacao::identificar_hook($e['hook'])){return 'hook_desconhecido';}
        if(!is_array($e['args'])){return 'argumentos_invalidos';}
        if(!is_numeric($e['timestamp'])||(int)$e['timestamp']<0){return 'ocorrencia_invalida';}
        $json=wp_json_encode($e['args'],JSON_PRESERVE_ZERO_FRACTION);
        return is_string($json)&&json_decode($json,true)===$e['args']?'':'argumentos_nao_reproduziveis';
    }
    public static function importar(): array {
        global $wpdb;$raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,'f3base_operacao_intencoes'));
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'intencoes_origem_ilegivel');}
        if($raw===null){return array('ok'=>true,'concluido'=>true);}
        $rows=maybe_unserialize($raw);$hash=hash('sha256',$raw);$release=get_option(F3Base_Instalacao::OPTION,array());$transfer=$release['transferencia_intencoes']??array();$same=($transfer['origem_sha256']??'')===$hash;
        $offset=$same?(int)($transfer['cursor']??0):0;$descartadas=$same?(array)($transfer['descartadas']??array()):array();$total=$same?(int)($transfer['descartadas_total']??0):0;
        if(!is_array($rows)){$rows=array();$total=1;$descartadas=array(array('indice'=>-1,'motivo'=>'origem_nao_e_lista','hook'=>'','sha256'=>$hash));}
        $rows=array_values($rows);$n=0;
        foreach(array_slice($rows,$offset,100) as $i=>$e){
            $motivo=self::motivo_descarte($e);
            if($motivo!==''){
                if($motivo==='argumentos_nao_reproduziveis'&&$wpdb->delete(self::tabela(),array('chave'=>self::chave($e),'estado'=>'pendente','falhas'=>0))===false){return array('ok'=>false,'codigo'=>'intencao_descarte_falhou');}
                if(count($descartadas)<200){$descartadas[]=array('indice'=>$offset+$i,'motivo'=>$motivo,'hook'=>is_array($e)&&is_string($e['hook']??null)?substr(sanitize_key($e['hook']),0,100):'','sha256'=>hash('sha256',serialize($e)));}$total++;$n++;continue;
            }
            $e['id']=F3Base_Operacao::identificar_hook($e['hook']);$e['schedule']=is_string($e['schedule']??null)?$e['schedule']:'';
            if(!self::registrar($e,(int)($e['tentar_em']??0))){return array('ok'=>false,'codigo'=>'intencao_nao_persistida');}
            $saved=$wpdb->get_row($wpdb->prepare('SELECT hook,argumentos,ocorrencia_em FROM %i WHERE chave=%s',self::tabela(),self::chave($e)),ARRAY_A);
            if(!$saved||$saved['hook']!==$e['hook']||json_decode($saved['argumentos'],true)!==$e['args']||(int)$saved['ocorrencia_em']!==(int)$e['timestamp']){return array('ok'=>false,'codigo'=>'intencao_importacao_divergente');}$n++;
        }
        $again=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,'f3base_operacao_intencoes'));if($wpdb->last_error||$again!==$raw){return array('ok'=>false,'codigo'=>'intencoes_origem_alterada');}
        $cursor=$offset+$n;$save=F3Base_Options::atualizar_estado(F3Base_Instalacao::OPTION,static function($v)use($cursor,$hash,$rows,$descartadas,$total){$v['transferencia_intencoes']=array('cursor'=>$cursor,'total'=>count($rows),'origem_sha256'=>$hash,'descartadas'=>$descartadas,'descartadas_total'=>$total);return $v;});
        if(empty($save['persisted'])){return array('ok'=>false,'codigo'=>'intencoes_checkpoint_falhou');}if($cursor<count($rows)){return array('ok'=>true,'concluido'=>false,'cursor'=>$cursor);}
        $arq=self::arquivar_origem($raw);if(empty($arq['ok'])){return $arq;}
        return array('ok'=>true,'concluido'=>true,'importadas'=>max(0,count($rows)-$total),'descartadas_total'=>$total,'origem_sha256'=>$hash,'origem_arquivada'=>$arq['arquivo']);
    }
    private static function arquivar_origem(string $raw): array {
        global $wpdb;$novo='f3base_intencoes_origem_'.substr(hash('sha256',$raw),0,12);
        $existe=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,$novo));
        if($wpdb->last_error||($existe!==null&&!hash_equals($raw,$existe))){return array('ok'=>false,'codigo'=>'intencoes_arquivo_divergente');}
        $n=$existe!==null?$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE option_name=%s AND BINARY option_value=BINARY %s',$wpdb->options,'f3base_operacao_intencoes',$raw)):$wpdb->query($wpdb->prepare("UPDATE %i SET option_name=%s,autoload='no' WHERE option_name=%s AND BINARY option_value=BINARY %s",$wpdb->options,$novo,'f3base_operacao_intencoes',$raw));
        foreach(array('f3base_operacao_intencoes',$novo,'alloptions','notoptions') as $k){wp_cache_delete($k,'options');}
        return $n===1?array('ok'=>true,'arquivo'=>$novo):array('ok'=>false,'codigo'=>'intencoes_origem_alterada');
    }
}
