<?php
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Slack_Operacao {
    private static function revisao_parte(array $p): string {return hash('sha256',implode('|',array($p['chave'],$p['estado'],$p['ts'],$p['tentativas'],$p['atualizada_em'])));}
    public static function reconciliar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$p=self::ler((string)($e['chave']??''));if(!$p){return array('ok'=>false,'codigo'=>'parte_indisponivel');}
        $rev=self::revisao_parte($p);if(!hash_equals($rev,(string)($e['revisao']??''))){return array('ok'=>false,'codigo'=>'revisao_divergente','revisao'=>$rev);}
        if(!in_array($p['estado'],array('falhou','incerto','suspenso'),true)){return array('ok'=>false,'codigo'=>'estado_nao_reconciliavel');}
        if(($e['simular']??true)!==false){return array('ok'=>true,'simular'=>true,'exige_confirmacao'=>$p['estado']!=='falhou','revisao'=>$rev);}
        if(empty($e['confirmar'])){return array('ok'=>false,'codigo'=>'confirmacao_exigida');}
        if(!hash_equals($p['destino'],self::destino())){return array('ok'=>false,'codigo'=>'destino_original_divergente');}
        $lead=F3Base_Leads_Repositorio::obter($p['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){return array('ok'=>false,'codigo'=>'contato_indisponivel');}
        $acao=$e['acao']??'';if(!in_array($acao,array('reenviar','confirmar_entrega'),true)){return array('ok'=>false,'codigo'=>'acao_invalida');}
        if($acao==='confirmar_entrega'&&(!is_string($e['ts']??null)||!preg_match('/^[0-9]+\.[0-9]+$/D',$e['ts']))){return array('ok'=>false,'codigo'=>'ts_invalido');}
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}$lock=F3Base_Trava::adquirir('slack-transporte',30);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>false,'codigo'=>'slack_transporte_ocupado');}
        try{$fresh=self::ler($p['chave']);if(!$fresh||!hash_equals($rev,self::revisao_parte($fresh))){return array('ok'=>false,'codigo'=>'revisao_divergente');}
            $ok=self::estado($p,$acao==='reenviar'?'pendente':'entregue','reconciliacao_manual_'.get_current_user_id(),$acao==='reenviar'?time()+1:0,$acao==='confirmar_entrega'?array('ts'=>$e['ts']):array('tentativas'=>0));
            if($ok){self::sincronizar($p['aviso']);F3Base_Fila::agendar(F3Base_Avisos::EVENTO,time()+1);if($p['revisao']!==''){global $wpdb;$wpdb->update(F3Base_Formulario_Complementos::tabela(),array('slack'=>'pendente','estado'=>'pendente','proxima'=>time()+1),array('chave'=>$p['revisao']));F3Base_Fila::agendar(F3Base_Formulario_Complementos::EVENTO,time()+1);}}
            return array('ok'=>$ok,'persisted'=>$ok,'codigo'=>$ok?'parte_reconciliada':'parte_nao_reconciliada','aviso'=>$acao==='reenviar'?'Reenvio de parte incerta pode duplicar somente essa parte.':'Confirmação declarada pelo operador; chat:write não permite comprovar histórico remoto.');
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function iniciar_operacao(): void {
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('avisos-parte-reconciliar','Reconciliar uma parte da thread; principal confirmada não é reenviada',array(__CLASS__,'reconciliar'),array('chave'=>array('type'=>'string'),'revisao'=>array('type'=>'string'),'acao'=>array('type'=>'string','enum'=>array('reenviar','confirmar_entrega')),'ts'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true),'confirmar'=>array('type'=>'boolean','default'=>false)),array('chave','revisao','acao'),false));
        add_action('admin_post_f3base_slack_parte',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-slack-parte');$e=array('simular'=>false,'confirmar'=>!empty($_POST['confirmar']));foreach(array('chave','revisao','acao','ts') as $k){$e[$k]=sanitize_text_field($_POST[$k]??'');}$r=self::reconciliar($e);set_transient('f3base_avisos_resultado_'.get_current_user_id(),$r,300);wp_safe_redirect(admin_url('admin.php?page=f3base-integracoes&integracao=avisos'));exit;});
        add_action(F3Base_Leads_Notificacoes::EVENTO,static function(){global $wpdb;$wpdb->query($wpdb->prepare("UPDATE %i SET payload='' WHERE estado IN ('entregue','cancelado','suprimido') AND atualizada_em<%d AND payload<>''",self::tabela(),time()-90*DAY_IN_SECONDS));});
    }
    public static function partes_tela(string $aviso): void {
        foreach(self::consultar($aviso) as $p){echo '<details><summary>'.esc_html($p['tipo'].' '.(string)$p['sequencia'].' — '.$p['estado'].' · '.$p['codigo']).'</summary><p>Canal: '.esc_html($p['canal']).' · ts: '.esc_html($p['ts']?:'não confirmado').'</p>';
            if(in_array($p['estado'],array('falhou','incerto','suspenso'),true)){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_slack_parte"><input type="hidden" name="chave" value="'.esc_attr($p['chave']).'"><input type="hidden" name="revisao" value="'.esc_attr($p['revisao_operacao']).'">';wp_nonce_field('f3base-slack-parte');echo '<label>Ação <select name="acao"><option value="reenviar">Reenviar somente esta parte</option><option value="confirmar_entrega">Confirmar entrega observada no Slack</option></select></label><label>ts observado <input name="ts"></label><label><input type="checkbox" name="confirmar" value="1" required> Conferi esta parte; aceito possível duplicação no reenvio de resultado incerto.</label><button class="button">Aplicar à parte</button></form>';}
            echo '</details>';
        }
    }
}
