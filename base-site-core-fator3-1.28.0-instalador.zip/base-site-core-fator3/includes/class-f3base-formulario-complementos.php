<?php
/** Etapa comercial adicional: mesma identidade, revisão imutável e outbox por destino. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/trait-f3base-complementos-operacao.php';
final class F3Base_Formulario_Complementos {
    use F3Base_Complementos_Operacao;
    const EVENTO='f3base_complementos_processar';
    const VALIDADE=1800;
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_complementos';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE $t (
 chave char(64) NOT NULL,
 record_id char(32) NOT NULL,
 submissao char(32) NOT NULL,
 recebido_em bigint NOT NULL,
 hash char(64) NOT NULL,
 payload longtext NOT NULL,
 estado varchar(24) NOT NULL,
 email varchar(16) NOT NULL DEFAULT 'pendente',
 slack varchar(16) NOT NULL DEFAULT 'pendente',
 crm varchar(16) NOT NULL DEFAULT 'pendente',
 journal longtext NOT NULL,
 proxima bigint NOT NULL,
 atualizado_em bigint NOT NULL,
 PRIMARY KEY  (chave),
 UNIQUE KEY submissao (record_id,submissao),
 KEY vencidas (estado,proxima),
 KEY contato (record_id)
) ENGINE=InnoDB ".$wpdb->get_charset_collate().';');return !$wpdb->last_error;
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('contato-complemento-reconciliar','Reagendar somente uma atualização após conferir o destino; não repete a captura inicial',array(__CLASS__,'reconciliar'),array('chave'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'destino'=>array('type'=>'string','enum'=>array('email','slack','crm')),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'confirmar'=>array('type'=>'boolean'),'aceitar_duplicacao'=>array('type'=>'boolean')),array('chave','destino'),false));
        add_action(self::EVENTO,array(__CLASS__,'processar'));
        add_action('f3base_lead_eliminando',array(__CLASS__,'eliminar'));
        add_action('f3base_leads_resumo',static function(){global $wpdb;$n=$wpdb->get_var($wpdb->prepare("SELECT MIN(proxima) FROM %i WHERE estado IN ('pendente','enviando')",self::tabela()));if($n!==null){F3Base_Fila::agendar(self::EVENTO,max(time()+1,(int)$n));}});
    }
    private static function referencia(string $id,int $exp,string $rev): string {return $id.'.'.hash_hmac('sha256',$id.'|'.$exp.'|'.$rev,wp_salt('secure_auth').'|complemento128');}
    public static function permissao(string $id,array $f): array {$exp=time()+self::VALIDADE;$rev=F3Base_Formularios::revisao($f);return array('hash'=>hash('sha256',self::referencia($id,$exp,$rev)),'expira_em'=>$exp,'revisao'=>$rev,'definicao'=>$f);}
    public static function continuacao(array $lead): array {
        $p=$lead['dados']['complemento_permissao']??array();if(!$p||($p['expira_em']??0)<time()){return array('etapa_pendente'=>false,'continuacao_expirada'=>true);}
        return array('continuacao'=>self::referencia($lead['record_id'],(int)$p['expira_em'],$p['revisao']),'continuacao_expira_em'=>$p['expira_em'],'revisao'=>$p['revisao'],'etapa_pendente'=>empty($lead['dados']['complemento_concluido']),'etapas_restantes'=>empty($lead['dados']['complemento_concluido'])?array(2):array());
    }
    private static function erro(string $code,int $http=400): array {return array('ok'=>false,'codigo'=>$code,'http'=>$http,'mensagem'=>array('continuacao_expirada'=>'O contato inicial está salvo. O prazo para complementar terminou.','complemento_conflitante'=>'Esta etapa já foi concluída com outros dados.','origem_invalida'=>'Origem do envio não autorizada.','resumo_em_preparo'=>'Seu contato está em processamento. Tente complementar novamente.')[$code]??'Não foi possível complementar. O contato inicial permanece salvo.');}
    public static function receber(array $e,array $files=array()): array {
        if(!F3Base_Recuperacao::entrar()){return self::erro('core_em_recuperacao',503);}
        try{return self::receber_interno($e,$files);}finally{F3Base_Recuperacao::sair();}
    }
    private static function receber_interno(array $e,array $files): array {
        if(!F3Base_Formularios::limite('complemento',30)){return self::erro('limite_de_envios',429);}
        $origin=$_SERVER['HTTP_ORIGIN']??'';if($origin&&strtolower((string)wp_parse_url($origin,PHP_URL_HOST))!==strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST))){return self::erro('origem_invalida',403);}
        if(array_diff(array_keys($e),array('continuacao','submissao','revisao','formulario','campos','website','pular'))||array_diff(array_keys($files),array('campos'))||!empty($e['website'])){return self::erro('entrada_invalida');}
        if(!is_string($e['continuacao']??null)||!preg_match('/^([a-f0-9]{32})\.[a-f0-9]{64}$/D',$e['continuacao'],$match)||!is_string($e['submissao']??null)||!preg_match('/^[a-f0-9]{32}$/D',$e['submissao'])){return self::erro('continuacao_invalida',403);}
        $id=$match[1];$lock=F3Base_Trava::adquirir('contato-resumo-'.$id,45);if(!$lock){return self::erro('resumo_em_preparo',409);}
        global $wpdb;$anexos=array();$committed=false;
        try{
            $lead=F3Base_Leads_Repositorio::obter($id);$p=$lead['dados']['complemento_permissao']??array();
            if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||$lead['captura']!=='aceito'||!$p||!hash_equals($p['hash'],hash('sha256',$e['continuacao']))){return self::erro('continuacao_invalida',403);}
            $f=$p['definicao'];$current=F3Base_Formularios::obter($lead['formulario']);
            if(($e['formulario']??'')!==$lead['formulario']||($e['revisao']??'')!==$p['revisao']||!$current||!hash_equals($p['revisao'],F3Base_Formularios::revisao($current))){return self::erro('formulario_alterado',409);}
            if(!in_array($e['pular']??'0',array('0','1'),true)){return self::erro('entrada_invalida');}$skip=($e['pular']??'0')==='1';
            if($skip&&(!empty($e['campos'])||$files)){return self::erro('entrada_invalida');}
            $valid=$skip?array('ok'=>true,'limpos'=>array(),'papeis'=>array(),'uploads'=>array()):F3Base_Formularios::validar_campos(F3Base_Formularios::etapa($f,2),$e['campos']??array(),$files);if(empty($valid['ok'])){return $valid;}
            $hashFiles=array();foreach($valid['uploads'] as [$file,$campo]){$hashFiles[]=array('campo'=>$campo['nome'],'sha256'=>is_uploaded_file($file['tmp_name'])?hash_file('sha256',$file['tmp_name']):'invalido','nome'=>sanitize_file_name($file['name']));}
            $hash=F3Base_Leads_Repositorio::hash(array('campos'=>$valid['limpos'],'arquivos'=>$hashFiles,'pular'=>$skip));$key=hash('sha256',$id.'|'.$e['submissao']);
            $old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$key),ARRAY_A);if($wpdb->last_error){return self::erro('complemento_leitura_falhou',503);}
            if($old){return hash_equals($old['hash'],$hash)?self::resposta($lead,$f,true,$old['chave'],$skip):self::erro('complemento_conflitante',409);}
            if($p['expira_em']<time()){return self::erro('continuacao_expirada',410);}if(!empty($lead['dados']['complemento_concluido'])){return self::erro('complemento_conflitante',409);}
            foreach($valid['uploads'] as [$file,$campo]){$r=F3Base_Arquivos_Privados::receber($file,'anexo',$campo);if(empty($r['ok'])){return self::erro($r['codigo'],503);}$a=$r['arquivo'];$a['campo']=$campo['nome'];$anexos[]=$a;}
            if(!F3Base_Arquivos_Privados::vincular($anexos,$id)){return self::erro('vinculo_de_anexo_falhou',503);}
            $d=$lead['dados'];$integrated=!isset($d['comunicacao_envio'])&&time()<=F3Base_Contato_Comunicacao::prazo($lead);
            $base=array_intersect_key($d,array_flip(array('campos','empresa','cargo','linkedin','servicos')));
            if(!$integrated&&!isset($d['comunicacao_envio'])){$base['_anexos_iniciais']=$lead['anexos'];$d['complemento_base']=F3Base_Contato_Comunicacao::cifrar($base);}
            $d['campos']=array_replace($d['campos']??array(),$valid['limpos']);foreach(array('empresa','cargo','linkedin') as $role){if(isset($valid['papeis'][$role])){$d[$role]=$valid['papeis'][$role];}}if(isset($valid['papeis']['servico'])){$d['servicos']=(array)$valid['papeis']['servico'];}
            $d['complemento_concluido']=array('revisao'=>$key,'em'=>time(),'pulado'=>$skip,'incorporado_inicial'=>$integrated);
            $payload=array('versao'=>1,'record_id'=>$id,'revisao'=>$key,'em'=>time(),'campos'=>$valid['limpos'],'papeis'=>$valid['papeis'],'anexos'=>array_map(static fn($a)=>array_intersect_key($a,array_flip(array('campo','nome','bytes'))),$anexos),'pulado'=>$skip,'incorporado_inicial'=>$integrated);
            $intent=$d['aviso_intencao']??array();$eligible=!empty($intent['elegivel'])&&!$integrated&&!$skip;$canal=$intent['canal']??'email';
            $outbox=array('chave'=>$key,'record_id'=>$id,'submissao'=>$e['submissao'],'recebido_em'=>time(),'hash'=>$hash,'payload'=>F3Base_Contato_Comunicacao::cifrar($payload),'estado'=>($integrated||$skip)?'incorporado':'pendente','email'=>$eligible&&in_array($canal,array('email','ambos','email_webhook'),true)?'pendente':'dispensado','slack'=>$eligible&&in_array($canal,array('slack','ambos'),true)?'pendente':'dispensado','crm'=>!$integrated&&!$skip&&!empty($lead['entrega']['pipedrive']['solicitado'])?'pendente':'dispensado','journal'=>'{}','proxima'=>max(time()+1,F3Base_Contato_Comunicacao::prazo($lead)),'atualizado_em'=>time());
            if($wpdb->query('START TRANSACTION')===false){return self::erro('transacao_indisponivel',503);}
            $raw=$wpdb->get_var($wpdb->prepare('SELECT dados FROM %i WHERE record_id=%s',F3Base_Leads_Repositorio::tabela(),$id));
            // Optimistic equality catches unrelated lead mutations while files were being received.
            if(json_decode((string)$raw,true)!==$lead['dados']){$wpdb->query('ROLLBACK');return self::erro('contato_alterado',409);}
            $saved=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'anexos'=>wp_json_encode(array_merge($lead['anexos'],$anexos)),'atualizado_em'=>gmdate('Y-m-d H:i:s'),'revisao'=>(int)$lead['revisao']+1),array('record_id'=>$id,'dados'=>$raw,'lixeira'=>0,'eliminacao_pendente'=>0));
            if($saved!==1||$wpdb->insert(self::tabela(),$outbox)!==1){$wpdb->query('ROLLBACK');return self::erro('complemento_nao_persistido',503);}
            if($wpdb->query('COMMIT')===false){$wpdb->query('ROLLBACK');return self::erro('commit_nao_confirmado',503);}$committed=true;
            F3Base_Fila::agendar(self::EVENTO,$outbox['proxima']);$lead['dados']=$d;
            return self::resposta($lead,$f,false,$key,$skip);
        }finally{if(!$committed){foreach($anexos as $a){F3Base_Arquivos_Privados::eliminar($a['id']);}}F3Base_Trava::liberar($lock);}
    }
    private static function resposta(array $lead,array $f,bool $duplicate,string $rev,bool $skip): array {
        $out=array('ok'=>true,'persisted'=>true,'aceito'=>true,'duplicado'=>$duplicate,'record_id'=>$lead['record_id'],'revisao_complemento'=>$rev,'etapa_pendente'=>false,'pulado'=>$skip,'method'=>$lead['metodo'],'mensagem'=>$skip?'Contato registrado. Você pode continuar.':'Informações adicionais registradas.');
        if(($f['regime']??'')==='whatsapp'){$cfg=F3Base_Options::ler('f3base_contato');$f['mensagem_whatsapp']=$lead['dados']['cta_origem']['texto']??$f['mensagem_whatsapp']??'';$out['url']='https://wa.me/'.($f['whatsapp']??$cfg['whatsapp_e164']).'?text='.rawurlencode(F3Base_Formularios::texto_whatsapp($f,$lead['dados']['campos']??array(),$cfg));}
        return F3Base_Confirmacao::preparar($out,$f);
    }
    public static function apresentacao(array $lead,array $payload): array {
        $a=F3Base_Contato_Comunicacao::previa($lead);$sections=array('Registro relacionado'=>array('Nome'=>$lead['nome'],'Contato'=>$lead['record_id'],'Recebido em'=>wp_date('d/m/Y H:i:s P',$payload['em'])),'Informações adicionais'=>array());$defs=array_column($lead['dados']['campos_snapshot']??array(),null,'nome');
        foreach($payload['campos'] as $n=>$v){$sections['Informações adicionais'][$defs[$n]['rotulo']??$n]=$v;}
        foreach($payload['anexos']??array() as $file){$sections['Informações adicionais']['Anexo: '.$file['campo']]=$file['nome'].' · '.size_format($file['bytes']);}
        $a['titulo_mensagem']='Atualização do contato';$a['secoes_comunicacao']=F3Base_Contato_Comunicacao::compactar($sections);return $a;
    }
    public static function processar(): array {
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}$lock=F3Base_Trava::adquirir('complementos-entrega',60);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>true,'codigo'=>'reserva_ocupada');}
        global $wpdb;try{
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE estado IN ('pendente','enviando') AND proxima<=%d ORDER BY recebido_em LIMIT 1",self::tabela(),time()),ARRAY_A);if(!$row){return array('ok'=>!$wpdb->last_error,'processados'=>0);}
            $lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){self::eliminar($row['record_id']);return array('ok'=>true,'codigo'=>'cancelado');}
            $payload=F3Base_Contato_Comunicacao::abrir($row['payload']);if(!$payload){return array('ok'=>false,'codigo'=>'complemento_cifra_indisponivel');}$a=self::apresentacao($lead,$payload);$journal=json_decode($row['journal'],true)?:array();
            foreach(array('email','slack','crm') as $dest){
                if($row[$dest]==='enviando'){$row[$dest]='incerto';$wpdb->update(self::tabela(),array($dest=>'incerto'),array('chave'=>$row['chave']));continue;}
                if($row[$dest]!=='pendente'){continue;}
                if($lead['classe_trafego']==='teste'&&($dest==='crm'?empty(F3Base_Options::ler('f3base_pipedrive')['homologacao']):F3Base_Testes::politica($dest,'teste')==='suprimir')){$row[$dest]='suprimido';$wpdb->update(self::tabela(),array($dest=>'suprimido'),array('chave'=>$row['chave']));continue;}
                if($dest==='slack'){$r=F3Base_Slack::complemento($lead,$row,$a);$row[$dest]=!empty($r['ok'])?'entregue':(!empty($r['incerto'])?'incerto':(!empty($r['permanente'])?'falhou':'pendente'));}
                elseif($dest==='crm'){$r=F3Base_Pipedrive_Fila::complementar($lead,$row,$a);$row[$dest]=!empty($r['ok'])?'entregue':(!empty($r['incerto'])?'incerto':(!empty($r['permanente'])?'falhou':'pendente'));}
                else{
                    $to=$lead['classe_trafego']==='teste'?F3Base_Leads_Notificacoes::destinatarios(F3Base_Testes::config()['email_destinatarios']):F3Base_Leads_Notificacoes::destinatarios_do_contato($lead);
                    if(!$to){$row[$dest]='falhou';$r=array('codigo'=>'destinatario_ausente');}
                    else{if($wpdb->update(self::tabela(),array('email'=>'enviando','estado'=>'enviando','proxima'=>time()+120),array('chave'=>$row['chave'],'email'=>'pendente'))!==1){return array('ok'=>false,'codigo'=>'complemento_reserva_falhou');}
                        $ok=F3Base_Email::enviar($to,F3Base_Leads_Notificacoes::assunto('Atualização do contato {nome}',$lead['metodo'],$lead['classe_trafego']==='teste',$lead['nome']),F3Base_Email::html($a),F3Base_Contato_Apresentacao::texto($a),array());$row[$dest]=$ok?'entregue':'incerto';$r=array('codigo'=>$ok?'email_processado':'email_nao_confirmado');}
                }
                $journal=json_decode((string)$wpdb->get_var($wpdb->prepare('SELECT journal FROM %i WHERE chave=%s',self::tabela(),$row['chave'])),true)?:$journal;$journal[$dest]=array('codigo'=>$r['codigo']??$row[$dest],'em'=>time());$wpdb->update(self::tabela(),array($dest=>$row[$dest],'journal'=>wp_json_encode($journal),'atualizado_em'=>time()),array('chave'=>$row['chave']));break;
            }
            $pending=in_array('pendente',array($row['email'],$row['slack'],$row['crm']),true);$wpdb->update(self::tabela(),array('estado'=>$pending?'pendente':(in_array('incerto',array($row['email'],$row['slack'],$row['crm']),true)?'incerto':'concluido'),'proxima'=>time()+30,'atualizado_em'=>time()),array('chave'=>$row['chave']));F3Base_Fila::agendar(self::EVENTO,time()+30);
            return array('ok'=>true,'processados'=>1,'codigo'=>$pending?'complemento_pendente':'complemento_processado');
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function listar(string $id): array {global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT chave,recebido_em,estado,email,slack,crm,journal,atualizado_em FROM %i WHERE record_id=%s ORDER BY recebido_em',self::tabela(),$id),ARRAY_A)?:array();foreach($rows as &$r){$r['revisao_operacao']=self::revisao_entrega($r);$r['journal']=json_decode($r['journal'],true)?:array();}unset($r);return $rows;}
    public static function eliminar(string $id): void {global $wpdb;$wpdb->delete(self::tabela(),array('record_id'=>$id));}
}
