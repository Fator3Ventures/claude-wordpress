<?php
/** Contrato de anúncios v1. IDs permanecem strings; nomes não são identidade. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Atribuicao {
    const CAMPOS=array('oppref','utm_source','utm_medium','utm_campaign','utm_content','utm_term','utm_id','utm_source_platform','gclid','gbraid','wbraid','fbclid','li_fat_id','f3_ads_v','f3_ads_account_id','f3_ads_group_id','f3_ads_group_type','f3_ads_placement','f3_ads_group_name','f3_ads_ad_name');
    public static function normalizar($v, bool $snapshots=true): array {
        $v=is_array($v)?$v:array();$out=array();$alias=array('utm_source'=>'fonte','utm_medium'=>'meio','utm_campaign'=>'campanha','utm_content'=>'conteudo','utm_term'=>'termo');
        foreach(self::CAMPOS as $k){$x=$v[$k]??$v[$alias[$k]??'']??'';$out[$k]=$k==='oppref'?(is_string($x)&&strlen($x)<=8192&&!preg_match('/[\x00-\x1f\x7f]/',$x)?$x:''):(is_string($x)?(function_exists('mb_substr')?mb_substr(sanitize_text_field($x),0,500):substr(sanitize_text_field($x),0,500)):'');}
        if(isset($v['oppref'])&&is_string($v['oppref'])&&strlen($v['oppref'])>8192){$out['oppref_estado']='omitido_excede_8192_bytes';}
        if(is_string($v['msclkid']??null)){$out['msclkid']=substr(sanitize_text_field($v['msclkid']),0,500);}
        foreach(array('fbc','fbp') as $k){$cookie=$v[$k]??'';$out[$k]=is_string($cookie)&&strlen($cookie)<=500&&preg_match('/^fb\\.[0-9]{1,3}\\.[0-9]{10,13}\\.[A-Za-z0-9_-]+$/D',$cookie)?$cookie:'';}
        $ref=is_string($v['referrer']??null)?$v['referrer']:'';$host=wp_parse_url($ref,PHP_URL_HOST);
        $out['referrer']=$host?strtolower($host):(preg_match('/^[a-z0-9.-]+$/i',$ref)?strtolower($ref):'');
        $out['modelo']=in_array($v['modelo']??'',array('sessao','primeiro-toque','ultimo-toque'),true)?$v['modelo']:'informado';
        foreach(array('primeiro_toque_em','ultimo_toque_em') as $k){$out[$k]=is_string($v[$k]??null)&&preg_match('/^[0-9]{1,12}$/D',$v[$k])?$v[$k]:'';}
        $out['superficie_anuncio']=array('ig'=>'instagram','instagram'=>'instagram','fb'=>'facebook','facebook'=>'facebook','an'=>'audience_network','msg'=>'messenger')[strtolower($out['utm_source'])]??'';
        $out['entrada']=is_string($v['entrada']??null)?F3Base_Analise::caminho($v['entrada']):'';$out['inicio_em']=is_string($v['inicio_em']??null)&&preg_match('/^[0-9]{1,12}$/D',$v['inicio_em'])?$v['inicio_em']:'';$out['inicio_conhecido']=($v['inicio_conhecido']??'')==='1'?'1':'';
        $out['contrato']='1';$out['plataforma']=self::plataforma($out);$out['origem_ia']=F3Base_Audiencia::ia($out);if(!empty($out['oppref'])&&in_array(strtolower($out['utm_source_platform']),array('meta','meta_ads','google','google_ads','linkedin','linkedin_ads'),true)){$out['conflito_plataforma']='oppref_e_plataforma_divergente';}
        // utm_content histórico pode ser um rótulo. Somente o molde v1 afirma ID.
        $out['campanha_id']=$out['utm_id'];$out['anuncio_id']=$out['f3_ads_v']==='1'?$out['utm_content']:'';
        $out['conta_id']=$out['f3_ads_account_id'];$out['grupo_id']=$out['f3_ads_group_id'];
        foreach(array('campanha_id','anuncio_id','conta_id','grupo_id') as $id){if(preg_match('/[{}]/',$out[$id])){$out[$id]='';$out['cobertura']='macro_nao_substituida';}}
        $out['cobertura']=$out['cobertura']??($out['anuncio_id']!==''&&$out['conta_id']!==''&&$out['plataforma']!=='nao_identificada'?'anuncio':($out['campanha_id']!==''?'campanha':'parcial'));
        if($snapshots){foreach(array('sessao_origem','primeiro_toque','ultimo_toque') as $k){if(isset($v[$k])&&is_array($v[$k])){$out[$k]=self::normalizar($v[$k],false);}}}
        return $out;
    }
    /** Policy for collection, shared by forms and clicks; never reinterprets a saved touch as the current navigation. */
    public static function para_captura($valor, bool $medicao, bool $publicidade): array {
        $v=is_array($valor)?$valor:array();
        if(!$medicao){
            // Without a current-navigation snapshot, an attributed root cannot prove current source.
            $v=is_array($v['sessao_origem']??null)?$v['sessao_origem']:(in_array($v['modelo']??'sessao',array('sessao','informado'),true)?$v:array());
            unset($v['primeiro_toque'],$v['ultimo_toque'],$v['sessao_origem'],$v['primeiro_toque_em'],$v['ultimo_toque_em']);$v['modelo']='sessao';
        }
        $out=self::normalizar($v,$medicao);
        if(!$medicao){unset($out['primeiro_toque_em'],$out['ultimo_toque_em']);$out['modelo']='sessao';}
        if(!$publicidade || !$medicao){
            $limpar=static function(array $a)use(&$limpar):array{
                foreach(array('fbc','fbp','gclid','gbraid','wbraid','fbclid','li_fat_id','msclkid','oppref','campanha_id','anuncio_id','conta_id','grupo_id','f3_ads_account_id','f3_ads_group_id','f3_ads_group_name','f3_ads_ad_name','utm_id','utm_content') as $k){unset($a[$k]);}
                foreach(array('sessao_origem','primeiro_toque','ultimo_toque') as $k){if(is_array($a[$k]??null)){$a[$k]=$limpar($a[$k]);}}
                return $a;
            };$out=$limpar($out);
        }
        return $out;
    }
    public static function plataforma(array $v): string {
        if(!empty($v['oppref'])){return 'openai_ads';}
        $src=strtolower($v['utm_source']??'');$medium=strtolower($v['utm_medium']??'');$platform=strtolower($v['utm_source_platform']??'');
        if(in_array($src,array('openai','chatgpt','openai_ads'),true)&&in_array($medium,array('paid','cpc','ppc','paid_social','paid_search','paidsocial','paid-search','cpm','display'),true)){return 'openai_ads';}
        if($platform==='openai_ads'&&in_array($medium,array('paid','cpc','ppc','paid_social','paid_search','paidsocial','paid-search','cpm','display'),true)){return 'openai_ads';}
        $x=strtolower($v['utm_source_platform']??'');$map=array('meta'=>'meta_ads','meta_ads'=>'meta_ads','google'=>'google_ads','google_ads'=>'google_ads','linkedin'=>'linkedin_ads','linkedin_ads'=>'linkedin_ads');
        return $map[$x]??'nao_identificada';
    }
    public static function validar($v,bool $snapshots=true): bool {
        $permitidos=array_merge(self::CAMPOS,array('referrer','modelo','contrato','plataforma','campanha_id','anuncio_id','conta_id','grupo_id','cobertura','fonte','meio','campanha','conteudo','termo','fbc','fbp','msclkid','primeiro_toque_em','ultimo_toque_em','superficie_anuncio','oppref_estado','conflito_plataforma','origem_ia','entrada','inicio_em','inicio_conhecido'));
        if(!is_array($v)){return false;}
        foreach($v as $k=>$x){if($snapshots&&in_array($k,array('sessao_origem','primeiro_toque','ultimo_toque'),true)){if(!self::validar($x,false)){return false;}continue;}if(!in_array($k,$permitidos,true)||!is_string($x)||($k!=='oppref'&&strlen($x)>2000)){return false;}}
        return true;
    }
    public static function chave(array $v): string {
        $a=self::normalizar($v);
        return wp_json_encode(array($a['plataforma'],$a['conta_id'],$a['campanha_id'],$a['grupo_id'],$a['anuncio_id'],$a['anuncio_id']?'':$a['utm_source'],$a['campanha_id']?'':$a['utm_campaign'],$a['anuncio_id']?'':$a['utm_content']));
    }
    public static function enfileirar(): void {
        if(wp_script_is('f3base-contexto','registered')){return;}
        wp_register_script('f3base-contexto',F3BASE_PLUGIN_URL.'assets/f3base-contexto.min.js',array('f3base-consentimento'),F3BASE_PLUGIN_VERSAO,array('in_footer'=>true,'strategy'=>'defer'));
        $t=F3Base_Testes::config();unset($t['capi_test_event_code'],$t['email_destinatarios']);
        wp_localize_script('f3base-contexto','f3baseContextoDados',array('contextoUrl'=>rest_url(F3BASE_REST_NAMESPACE.'/contexto-publico'),'audienciaExcluida'=>F3Base_Audiencia::pagina_excluida(),'campos'=>self::CAMPOS,'testes'=>$t,'atribuicao'=>F3Base_Options::ler('f3base_atribuicao'),'carregamento'=>F3Base_Options::ler('f3base_carregamento_destinos')));
    }
}
