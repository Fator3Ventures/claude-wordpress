<?php
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Sessoes_Relatorios {
    public static function origens_contato(array $lead): array {
        $permit=F3Base_Contato_Apresentacao::consentimento($lead['dados']);if(!$permit['medicao']){return array();}$raw=$lead['dados']['atribuicao']??array();$all=array();
        foreach(array('sessao_origem','primeiro_toque','ultimo_toque','captura') as $kind){
            $touch=$kind==='captura'?$raw:($raw[$kind]??array());if(!is_array($touch)){continue;}$a=F3Base_Contato_Apresentacao::atribuicao($touch,$permit['publicidade']);if(empty($a['utm_campaign'])&&empty($a['campanha_id'])){continue;}$key=self::campanha_chave($a);
            $date=$kind==='primeiro_toque'?($raw['primeiro_toque_em']??null):($kind==='ultimo_toque'?($raw['ultimo_toque_em']??null):($kind==='sessao_origem'?($touch['inicio_em']??null):null));$date=is_numeric($date)&&(int)$date>0&&(int)$date<=time()?(int)$date:null;
            if(!isset($all[$key])){$all[$key]=array('chave'=>$key,'nome'=>$a['utm_campaign']??'','plataforma'=>$a['plataforma']??'','conta_id'=>$a['conta_id']??'','campanha_id'=>$a['campanha_id']??'','identidade_incompleta'=>empty($a['conta_id'])||empty($a['campanha_id']),'primeira_em'=>$date,'ultima_em'=>$date,'sessoes'=>null,'origem_historica_contato'=>true);}
            elseif($date){$all[$key]['primeira_em']=min($date,$all[$key]['primeira_em']??$date);$all[$key]['ultima_em']=max($date,$all[$key]['ultima_em']??$date);}
        }
        return array_values($all);
    }

    public static function revogacao(array $h,bool $publicidade=false): bool {
        global $wpdb;$refs=array_values(array_filter($h['decisoes_refs']??array(),static fn($v)=>is_string($v)&&preg_match('/^[a-f0-9]{64}$/D',$v)));if(!$refs){return false;}
        $qs=implode(',',array_fill(0,count($refs),'%s'));$n=$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE ref IN ('.$qs.') AND (revogada=1 OR medicao=0'.($publicidade?' OR publicidade=0':'').')',$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA,...$refs));return (bool)$wpdb->last_error||(int)$n>0;
    }
    public static function projecao(array $lead): array {$r=F3Base_Contato_Comunicacao::preparar($lead,false);if(empty($r['ok'])){return array('ok'=>false,'codigo'=>$r['codigo']??'resumo_indisponivel');}return $r['apresentacao']['historico']??self::historico($lead);}
    private static function indexar_contatos(array $state): void {
        global $wpdb;$cursor=(int)($state['contato_cursor']??0);$rows=$wpdb->get_results($wpdb->prepare('SELECT id,record_id FROM %i WHERE id>%d AND lixeira=0 AND eliminacao_pendente=0 ORDER BY id LIMIT 5',F3Base_Leads_Repositorio::tabela(),$cursor),ARRAY_A);if($wpdb->last_error){return;}
        foreach($rows as $row){$lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead){continue;}$h=self::projecao($lead);if(empty($h['ok'])&&isset($h['ok'])){return;}if(!self::gravar_campanhas($lead['record_id'],$h['campanhas']??array(),$h['decisoes_refs']??array())){return;}$cursor=(int)$row['id'];}
        F3Base_Options::atualizar_estado('f3base_sessoes_indice',static fn($s)=>array_merge($s,array('contato_cursor'=>$rows?$cursor:0,'contatos_em'=>time())));
    }
    public static function filtro_sql(array $e,string $coluna): string {
        global $wpdb;if(!preg_match('/^[a-zA-Z0-9_.]+$/D',$coluna)){throw new InvalidArgumentException('coluna_invalida');}$v=$e['campanha_historica']??'';if($v===''){return '';}
        if(!is_string($v)||mb_strlen($v)>191){throw new InvalidArgumentException('campanha_historica_invalida');}
        return $wpdb->prepare(" AND EXISTS (SELECT 1 FROM %i hc WHERE hc.record_id={$coluna} AND (hc.campanha=%s OR BINARY hc.rotulo=BINARY %s) AND NOT EXISTS (SELECT 1 FROM %i hd WHERE (hd.revogada=1 OR hd.medicao=0) AND JSON_CONTAINS(hc.decisoes_refs,JSON_QUOTE(hd.ref))))",self::campanhas_tabela(),$v,$v,$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA);
    }
    public static function relatorio(array $periodo,array $e,bool $complete=false): array {
        if(($e['visao']??'campanhas')!=='campanhas'){return array('ok'=>false,'codigo'=>'historico_exige_visao_campanhas');}
        foreach(array('caminho','canal','tipo','largura_faixa','navegador','sistema','retorno','aparelho','superficie','grupo_id','anuncio_id','conta_id','campanha_id','plataforma') as $k){if(!empty($e[$k])){return array('ok'=>false,'codigo'=>'filtro_nao_disponivel_no_historico','campo'=>$k);}}
        global $wpdb;$lf=F3Base_Testes::sql($e['segmento']??null,'l.classe_trafego');
        foreach(array('formulario','metodo') as $k){if(!empty($e[$k])){$lf.=$wpdb->prepare(" AND l.{$k}=%s",$e[$k]);}}
        $auto=$e['automacao']??'todas';if($auto!=='todas'){$expr="COALESCE(JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.automacao.automacao')),'nao_identificada')";$lf.=$auto==='audiencia'?" AND {$expr} NOT IN ('declarada','provavel')":$wpdb->prepare(" AND {$expr}=%s",$auto);}$lf.=self::filtro_sql($e,'l.record_id');$lf.=F3Base_Inteligencia::exclusoes_sql('l.criado_em','datetime',$e['anotacoes']??null);
        $common=$wpdb->prepare(" FROM %i l JOIN %i hc ON hc.record_id=l.record_id WHERE l.criado_em>=%s AND l.criado_em<%s AND l.lixeira=0 AND l.eliminacao_pendente=0 AND l.captura='aceito' {$lf} AND NOT EXISTS (SELECT 1 FROM %i hd WHERE (hd.revogada=1 OR hd.medicao=0) AND (hd.ref=l.decisao_ref OR JSON_CONTAINS(hc.decisoes_refs,JSON_QUOTE(hd.ref))))",F3Base_Leads_Repositorio::tabela(),self::campanhas_tabela(),gmdate('Y-m-d H:i:s',$periodo['inicio']),gmdate('Y-m-d H:i:s',$periodo['fim']),$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA);
        $rows=$wpdb->get_results('SELECT hc.campanha,hc.rotulo,hc.plataforma,COUNT(DISTINCT l.record_id) contatos,MIN(NULLIF(hc.primeira,0)) primeira_chegada,MAX(NULLIF(hc.ultima,0)) ultima_chegada'.$common.' GROUP BY hc.campanha,hc.rotulo,hc.plataforma ORDER BY contatos DESC,hc.campanha LIMIT 2001',ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'campanhas_leitura_falhou');}
        if(count($rows)>2000){return array('ok'=>false,'codigo'=>'reduza_periodo');}$total=(int)$wpdb->get_var('SELECT COUNT(DISTINCT l.record_id)'.$common);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'campanhas_leitura_falhou');}
        $page=max(1,(int)($e['pagina']??1));$limit=min(200,max(1,(int)($e['limite']??100)));$rule='Campanhas observadas no histórico: um contato pode aparecer em A e B. Quebra não aditiva; o total global conta cada contato uma vez. Não representa atribuição causal.';
        return array('ok'=>true,'visao'=>'campanhas','escopo_campanhas'=>'historico','periodo'=>$periodo,'linhas'=>$complete?$rows:array_slice($rows,($page-1)*$limit,$limit),'total_linhas'=>count($rows),'pagina'=>$page,'proxima_pagina'=>$page*$limit<count($rows)?$page+1:null,'totais'=>array('contatos'=>$total),'filtros_aplicados'=>$e,'regra'=>$rule,'avisos'=>array($rule,'Índice reconstruído em lotes; não reenvia avisos antigos.','Campanhas dependem de autorização e evidência da origem de cada sessão.'),'indice'=>get_option('f3base_sessoes_indice',array()));
    }
}
