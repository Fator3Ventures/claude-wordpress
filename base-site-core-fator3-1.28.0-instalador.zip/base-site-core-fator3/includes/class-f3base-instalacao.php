<?php
/** Instalação nova ou atualização estrutural, com base de referência 1.27.0, com checkpoints e recuo. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Instalacao {
    const OPTION='f3base_release_1280';
    private static ?string $origem_memo=null;
    public static function origem(): string {if(self::$origem_memo!==null){return self::$origem_memo;}$o=self::origem_lida();if($o!=='leitura_indisponivel'){self::$origem_memo=$o;}return $o;}
    private static function origem_lida(): string {
        global $wpdb;
        $raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,self::OPTION));
        if($wpdb->last_error){return 'leitura_indisponivel';}
        $state=$raw!==null?maybe_unserialize($raw):array();
        if(is_array($state)&&!empty($state['concluido_em'])&&($state['versao']??'')===F3BASE_PLUGIN_VERSAO){return 'atual';}
        if(is_array($state)&&!empty($state['iniciado_em'])){return $state['origem']??'existente';}
        $tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($wpdb->prefix.'f3base_').'%'));
        if($wpdb->last_error){return 'leitura_indisponivel';}
        $names=array('f3base_estrutura','f3base_leads_estrutura','f3base_contato','f3base_servidor');
        $n=$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE option_name IN (%s,%s,%s,%s)',$wpdb->options,...$names));
        if($wpdb->last_error){return 'leitura_indisponivel';}
        return !$tables&&!(int)$n?'nova':'existente';
    }
    public static function permitida(): bool {return self::origem()!=='leitura_indisponivel';}
    public static function aviso(): void {if(current_user_can('manage_options')){echo '<div class="notice notice-error"><p>Site Core: leitura de instalação indisponível. Confira o banco e a Saúde; nenhum dado foi redefinido.</p></div>';}}
    public static function resumo(): array {$s=get_option(self::OPTION,array());$s=is_array($s)?$s:array();if(!empty($s['concluido_em'])){$s['ultima_falha']=null;$s['proxima_tentativa']=0;$s['etapa_atual']='concluida';}return $s+array('versao'=>'1.28.0','concluido_em'=>0,'proxima_tentativa'=>0,'origem'=>self::origem());}
    private static function salvar(array $s): bool {self::$origem_memo=null;$r=F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$s);return !empty($r['persisted']);}
    public static function documentos_obsoletos(): array {return array('removidos'=>array(),'divergentes'=>array(),'falhas'=>array());}
    public static function atualizar(): array {
        $origem=self::origem();if($origem==='atual'){return self::finalizar();}if(!self::permitida()){return array('ok'=>false,'codigo'=>'leitura_indisponivel');}
        $s=get_option(self::OPTION,array());if((int)($s['proxima_tentativa']??0)>time()){return array('ok'=>true,'status'=>'aguardando','codigo'=>'atualizacao_em_recuo','proxima_tentativa'=>$s['proxima_tentativa']);}
        if(!F3Base_Recuperacao::provisionar()||!F3Base_Recuperacao::entrar()){$guard=F3Base_Recuperacao::ler();return array('ok'=>false,'codigo'=>'core_em_recuperacao','ultima_falha'=>array('etapa'=>'recuperacao','codigo'=>$guard['codigo']??'recuperacao_indisponivel'),'recuperacao'=>$guard);}
        $lock=F3Base_Trava::adquirir('atualizacao-1280',180);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>false,'codigo'=>'atualizacao_em_execucao');}
        $etapa='inicio';try{
            if(empty($s['versao'])){$s=array('versao'=>'1.28.0','origem'=>$origem,'iniciado_em'=>time(),'etapas'=>array(),'falhas'=>0);if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}}
            $steps=array(
                'padroes'=>static function()use($origem){
                    if($origem==='nova'){
                        foreach(array(F3Base_Options::OPTION_OPERAVEIS=>array('schema'=>1,'modo'=>'todas','lista'=>array()),'f3base_politica_canal'=>true,'f3base_contato'=>array('email_leads'=>is_email(get_option('admin_email'))?array(get_option('admin_email')):array())) as $n=>$v){if(!F3Base_Options::fotografia_bruta($n)['existe']){$r=F3Base_Options::gravar($n,$v,F3Base_Options::ORIGEM_PADRAO,F3Base_Options::revisao($n));if(empty($r['persisted'])){return false;}}}
                    }
                    $defaults=F3Base_Configuracao_Medicao::materializar_padroes();if(!empty($defaults['preservadas_com_diagnostico'])){$state=get_option(self::OPTION,array());$state['avisos_padroes']=$defaults['preservadas_com_diagnostico'];if(!self::salvar($state)){return false;}}return !empty($defaults['ok']);
                },
                'consentimento_capi'=>static function(){F3Base_Consentimento_Decisoes::instalar();F3Base_Modulo_Endpoint_Leads::instalar_recusas();return F3Base_Capi_Fila::instalar()&&F3Base_Atualizacao::verificar_estrutura();},
                'leads_analise'=>static function(){F3Base_Modulo_Comportamento::criar_tabela();F3Base_Vitais::instalar();return F3Base_Leads_Repositorio::instalar()&&F3Base_Analise::instalar()&&F3Base_Audiencia_Exclusoes::instalar()&&F3Base_Sondas_Http::instalar()&&F3Base_Clarity_Acervo::instalar()&&F3Base_Meta_Transporte::instalar();},
                'integracoes'=>static fn()=>F3Base_Slack::instalar()&&F3Base_Formulario_Complementos::instalar()&&F3Base_Sessoes::instalar()&&F3Base_Avisos::instalar()&&F3Base_Pipedrive_Fila::instalar()&&F3Base_Anuncios::instalar(),
                'editorial'=>static function(){F3Base_Acessos_Coleta::instalar();F3Base_Agentes::instalar();return F3Base_Acessos_Legado::instalar()&&F3Base_Editorial::instalar()&&F3Base_Inteligencia::instalar();},
                'acervos_1200'=>static fn()=>F3Base_Execucoes::instalar()&&F3Base_Gsc::instalar(),
                'intencoes_estrutura'=>static fn()=>F3Base_Operacao_Intencoes::instalar()&&F3Base_Leads_Consentimento::instalar(),
                'diagnosticos_anteriores'=>static fn()=>F3Base_Configuracao_Medicao::importar_avisos(),
                'intencoes_transferencia'=>static fn()=>true,
                'manutencao_local'=>static fn()=>!empty(F3Base_Cache_Orcamento::limpar()['ok']),
                'pasta_privada'=>static fn()=>!empty(F3Base_Arquivos_Privados::provisionar()['ok']),
                'verificacao'=>static fn()=>self::verificar(),
                'agendas'=>static fn()=>self::agendas(),
            );
            $order=array('intencoes_estrutura','consentimento_capi','leads_analise','integracoes','editorial','acervos_1200','padroes','diagnosticos_anteriores','intencoes_transferencia','manutencao_local','pasta_privada','verificacao','agendas');$steps=array_replace(array_fill_keys($order,null),$steps);
            foreach($steps as $etapa=>$callback){if(!empty($s['etapas'][$etapa]['concluido_em'])){continue;}$s['etapa_atual']=$etapa;$s['tentativa_em']=time();if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}
                $result=$callback();$saved=get_option(self::OPTION,array());foreach(array('avisos_padroes','transferencia_intencoes') as $extra){if(isset($saved[$extra])){$s[$extra]=$saved[$extra];}}if(is_array($result)&&isset($result['cursor'])){$s['cursores'][$etapa]=$result['cursor'];if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}}
                if($result===false||(is_array($result)&&empty($result['ok']))){throw new RuntimeException(is_array($result)?($result['codigo']??'etapa_nao_confirmada'):'etapa_nao_confirmada');}
                if(is_array($result)&&empty($result['concluido'])){$s['proxima_tentativa']=time()+5;$s['ultima_falha']=null;if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}return array('ok'=>true,'parcial'=>true,'codigo'=>'atualizacao_em_lotes','etapa'=>$etapa,'proxima_tentativa'=>$s['proxima_tentativa']);}
                $s['etapas'][$etapa]=array('concluido_em'=>time());if(!self::salvar($s)){throw new RuntimeException('checkpoint_falhou');}}
            $etapa='conclusao';$structure=F3Base_Options::atualizar_estado(F3Base_Atualizacao::OPTION,static fn($v)=>array_merge($v,array('versao'=>F3Base_Atualizacao::VERSAO,'confirmada_em'=>time(),'codigo'=>'estrutura_confirmada')));if(empty($structure['persisted'])||(F3Base_Options::ler(F3Base_Atualizacao::OPTION)['versao']??'')!==F3Base_Atualizacao::VERSAO){throw new RuntimeException('estrutura_nao_persistida');}
            $fim=array_merge($s,array('concluido_em'=>time(),'proxima_tentativa'=>0,'ultima_falha'=>null,'etapa_atual'=>'concluida'));if(!self::salvar($fim)){throw new RuntimeException('checkpoint_falhou');}$s=$fim;
            wp_clear_scheduled_hook(F3Base_Atualizacao::EVENTO);F3Base_Fila::agendar(F3Base_Atualizacao::EVENTO,time()+60);
            return array('ok'=>true,'persisted'=>true,'codigo'=>'atualizacao_concluida');
        }catch(Throwable $e){$s['falhas']=(int)($s['falhas']??0)+1;$s['ultima_falha']=array('etapa'=>$etapa,'codigo'=>sanitize_key($e->getMessage()),'em'=>time());$s['proxima_tentativa']=time()+min(3600,300*2**min(4,$s['falhas']-1));self::salvar($s);return array('ok'=>false,'codigo'=>'atualizacao_pendente','etapa'=>$etapa,'proxima_tentativa'=>$s['proxima_tentativa']);}
        finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    /** Public bootstrap never performs migration, network reconciliation or consolidation. */
    public static function observar(): void {
        $s=get_option(self::OPTION,array());
        if(empty($s['concluido_em'])||empty($s['finalizacao_em'])){F3Base_Atualizacao::agendar();}
    }
    private static function finalizar(): array {
        $s=self::resumo();if(!empty($s['finalizacao_em'])){return array('ok'=>true,'codigo'=>'atual');}
        // A subsequent executor pass is proof of a new runtime invocation, not a successful remote deployment probe.
        if(time()<(int)$s['concluido_em']+60){F3Base_Fila::agendar(F3Base_Atualizacao::EVENTO,(int)$s['concluido_em']+60);return array('ok'=>true,'codigo'=>'aguarda_confirmacao_executor');}
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}
        $lock=F3Base_Trava::adquirir('finalizar-1280',180);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>false,'codigo'=>'finalizacao_ocupada');}
        try{
            $s=self::resumo();$s['confirmada_no_executor_em']=time();if(!self::salvar($s)){return array('ok'=>false,'codigo'=>'checkpoint_falhou');}
            if(empty($s['servidor_reconciliado_em'])){$server=F3Base_Servidor::reconciliar_instalacao();$s=self::resumo();$s['servidor_reconciliado_em']=time();$s['servidor_resultado']=array('ok'=>!empty($server['ok']),'codigo'=>$server['codigo']??$server['status']??'consultar_servidor','verificacao'=>'Consulte f3base/servidor-aplicar com acao consultar para a prova vigente.');if(!self::salvar($s)){return array('ok'=>false,'codigo'=>'checkpoint_falhou');}}
            if(!F3Base_Estado_Consolidacao::concluir()){F3Base_Fila::agendar(F3Base_Atualizacao::EVENTO,time()+60);return array('ok'=>false,'codigo'=>'consolidacao_pendente');}
            $s=self::resumo();$s['finalizacao_em']=time();return array('ok'=>self::salvar($s),'codigo'=>'finalizacao_concluida');
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    private static function agendas(): bool {
        foreach(array(F3Base_Sessoes::EVENTO,F3Base_Formulario_Complementos::EVENTO,'f3base_consentimento_indexar','f3base_aparelhos_historico') as $hook){if(!wp_next_scheduled($hook)){if(!wp_schedule_single_event(time()+60,$hook)){return false;}}if(!wp_next_scheduled($hook)){return false;}}
        F3Base_Navegacao::agendar();F3Base_Editorial::agendar();F3Base_Llms_Cobertura::agendar();foreach(array(F3Base_Navegacao::EVENTO,F3Base_Editorial::EVENTO) as $hook){if(!wp_next_scheduled($hook)){return false;}}return true;
    }
    public static function verificar(): bool {
        global $wpdb;if(!F3Base_Atualizacao::verificar_estrutura()){return false;}
        $required=array('f3base_sessoes'=>array('classe','sessao','visitante','inicio','origem'),'f3base_contato_campanhas'=>array('record_id','campanha','sessoes'),'f3base_complementos'=>array('chave','record_id','payload','estado'),'f3base_avisos_partes'=>array('chave','principal','canal','ts','payload'),'f3base_sondas_http'=>array('dia','chave','caminho','metodo','status','classe','quantidade'),'f3base_avisos_fila'=>array('chave','record_id','estado','payload','reserva','reserva_ate','contingencia'),'f3base_audiencia_404'=>array('dia','caminho','contagem','amostras','ultimo_em'),'f3base_operacao_intencoes'=>array('chave','escopo','estado','falhas','quota_adiamentos','tentar_em','reserva','reserva_ate'),'f3base_consentimento_reparos'=>array('lead_id','tentativas','codigo'),'f3base_leads'=>array('decisao_ref'),'f3base_eventos'=>array('recebido_em'),'f3base_gsc_lacunas'=>array('universo','dia','estado'),'f3base_analise'=>array('publicidade','decisao_ref','clique_rotulo','clique_destino','oferta_id','oferta_tipo','oferta_instancia','largura_faixa','navegador','sistema','retorno','aparelho'),'f3base_execucoes'=>array('run_id','origem','parent_run_id','ocorrencia'),'f3base_gsc_coletas'=>array('id','propriedade','dia','estado','cursor','revision'),'f3base_gsc_linhas'=>array('coleta_id','chave','url'),'f3base_clarity_coletas'=>array('id','estado','recebido_em'),'f3base_clarity'=>array('coleta','metrica'),'f3base_meta_eventos'=>array('evento','rota','classe_trafego'));
        foreach($required as $suffix=>$cols){$t=$wpdb->prefix.$suffix;$actual=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t));if($wpdb->last_error||array_diff($cols,$actual)){return false;}}return true;
    }
}
