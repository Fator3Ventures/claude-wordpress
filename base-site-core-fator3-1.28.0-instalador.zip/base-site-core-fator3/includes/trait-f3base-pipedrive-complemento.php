<?php
/** Complemento comercial: somente campos mapeados e nota na oportunidade vinculada. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Pipedrive_Complemento {
    public static function complementar(array $lead,array $revision,array $a): array {
        global $wpdb;$key=$wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE record_id=%s ORDER BY atualizado_em DESC LIMIT 1',self::tabela(),$lead['record_id']));
        if(!$key){return array('ok'=>false,'codigo'=>'crm_inicial_pendente');}
        return self::coordenar($key,static function()use($key,$lead,$revision,$a,$wpdb){
            $job=self::ler($key);$opp=$job['journal']['oportunidade']??array();
            if(!$opp||empty($job['journal']['nota'])){return array('ok'=>false,'codigo'=>'crm_inicial_pendente');}
            F3Base_Pipedrive_Api::iniciar_lote();$cfg=F3Base_Pipedrive_Api::configuracao_lote();$state=get_option('f3base_pipedrive_estado',array());
            if(empty($cfg['ativo'])||!F3Base_Integracoes::pipedrive_verificado()||$job['conta']!==($state['dominio']??'').'|'.($state['conta_id']??'').'|'.($state['instalacao']??'')){return array('ok'=>false,'codigo'=>'crm_destino_suspenso','permanente'=>true);}
            if(($opp['tipo']??'')!=='lead'){return array('ok'=>false,'codigo'=>'crm_oportunidade_exige_revisao','permanente'=>true);}
            $payload=F3Base_Contato_Comunicacao::abrir($revision['payload']);if(!$payload){return array('ok'=>false,'codigo'=>'complemento_indisponivel','permanente'=>true);}
            $journal=json_decode($revision['journal'],true)?:array();$ops=$journal['crm_operacoes']??array();if(isset($ops['config_revisao'])&&!hash_equals($ops['config_revisao'],F3Base_Options::revisao('f3base_pipedrive'))){return array('ok'=>false,'codigo'=>'crm_mapa_alterado_reconciliar','permanente'=>true);}$ops['config_revisao']=F3Base_Options::revisao('f3base_pipedrive');
            if(($ops['estado']??'')==='enviando'){return array('ok'=>false,'codigo'=>'crm_complemento_resultado_incerto','incerto'=>true);}
            $save=static function(array $value)use($wpdb,$revision){$raw=$wpdb->get_var($wpdb->prepare('SELECT journal FROM %i WHERE chave=%s',F3Base_Formulario_Complementos::tabela(),$revision['chave']));if(!is_string($raw)){return false;}$j=json_decode($raw,true)?:array();$j['crm_operacoes']=$value;return $wpdb->update(F3Base_Formulario_Complementos::tabela(),array('journal'=>wp_json_encode($j),'atualizado_em'=>time()),array('chave'=>$revision['chave'],'journal'=>$raw))!==false;};
            F3Base_Pipedrive_Api::definir_guarda(static function()use($lead){$r=F3Base_Leads_Repositorio::obter($lead['record_id']);return $r&&!$r['lixeira']&&!$r['eliminacao_pendente']&&$r['captura']==='aceito';});
            if(empty($ops['campos'])){
                // Keep exactly the complementary answers. No initial identifiers or attribution get patched.
                $current=F3Base_Contato_Apresentacao::montar($lead,false);$current['campos']=$payload['campos'];$current['respostas']=$payload['campos'];
                foreach(array('empresa','cargo','linkedin') as $role){$current[$role]=$payload['papeis'][$role]??'';}$current['servicos']=(array)($payload['papeis']['servico']??array());
                $restricted=$cfg;$restricted['mapa_campos']=array_intersect_key($cfg['mapa_campos'],array_flip(array('servico','cargo')));$restricted['mapa_respostas']=array($lead['formulario']=>array_intersect_key($cfg['mapa_respostas'][$lead['formulario']]??array(),$payload['campos']));$restricted['mapa_pessoa']=array();
                $fields=self::campos($current,$restricted);
                if($fields){$read=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.$opp['id']);if(empty($read['ok'])){return $read;}if((int)($read['data']['person_id']??0)!==(int)$job['journal']['pessoa']){return array('ok'=>false,'codigo'=>'crm_identidade_divergente','permanente'=>true);}
                    $ops['estado']='enviando';$ops['etapa']='campos';if(!$save($ops)){return array('ok'=>false,'codigo'=>'complemento_checkpoint_falhou');}
                    $r=F3Base_Pipedrive_Api::pedir('PATCH','v1/leads/'.$opp['id'],$fields);if(empty($r['ok'])){if(empty($r['incerto'])){$ops['estado']='pendente';$save($ops);}return $r;}
                }$ops['campos']=true;$ops['estado']='pendente';if(!$save($ops)){return array('ok'=>false,'codigo'=>'complemento_checkpoint_incerto','incerto'=>true);}return array('ok'=>false,'codigo'=>'crm_nota_complementar_pendente');
            }
            if(!empty($ops['nota'])){return array('ok'=>true,'codigo'=>'crm_complemento_entregue');}
            $ops['estado']='enviando';$ops['etapa']='nota';if(!$save($ops)){return array('ok'=>false,'codigo'=>'complemento_checkpoint_falhou');}
            $mark='f3base:'.$key.':complemento:'.$revision['chave'];$r=F3Base_Pipedrive_Api::pedir('POST','v1/notes',array('content'=>F3Base_Contato_Apresentacao::nota($a,$mark),'person_id'=>(int)$job['journal']['pessoa'],'lead_id'=>$opp['id']));
            if(empty($r['ok'])){if(empty($r['incerto'])){$ops['estado']='pendente';$save($ops);}return $r;}$ops['nota']=$r['data']['id'];$ops['estado']='entregue';if(!$save($ops)){return array('ok'=>false,'codigo'=>'complemento_checkpoint_incerto','incerto'=>true);}return array('ok'=>true,'codigo'=>'crm_complemento_entregue');
        });
    }
}
