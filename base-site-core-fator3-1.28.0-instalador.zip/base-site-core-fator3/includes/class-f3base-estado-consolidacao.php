<?php
/** Retire exact release markers only after the current installation has committed. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Estado_Consolidacao {
    const RETIRADOS=array('f3base_release_1120','f3base_1120_trava','f3base_reparo_1120','f3base_migracao_1110','f3base_release_1130','f3base_release_1140','f3base_release_1150','f3base_release_1160','f3base_release_1170','f3base_release_1180','f3base_release_1190','f3base_release_1200','f3base_release_1210','f3base_release_1220','f3base_release_1221','f3base_release_1230','f3base_release_1240','f3base_1130_trava','f3base_1190_trava','f3base_agenda_1200','f3base_agenda_1210');
    private static function versao(string $name): string {return array('f3base_release_1120'=>'1.12.0','f3base_release_1130'=>'1.13.0','f3base_release_1140'=>'1.14.0','f3base_release_1150'=>'1.15.0','f3base_release_1160'=>'1.16.0','f3base_release_1170'=>'1.17.0','f3base_release_1180'=>'1.18.0','f3base_release_1190'=>'1.19.0','f3base_release_1200'=>'1.20.0','f3base_release_1210'=>'1.21.0','f3base_release_1220'=>'1.22.0','f3base_release_1221'=>'1.22.1','f3base_release_1230'=>'1.23.0','f3base_release_1240'=>'1.24.0')[$name]??'999.0.0';}
    public static function concluir(): bool {
        $s=get_option(F3Base_Instalacao::OPTION,array());if(empty($s['concluido_em'])||empty($s['confirmada_no_executor_em'])){return false;}if(!empty($s['consolidacao']['concluido_em'])){return true;}
        if(!F3Base_Recuperacao::entrar()){return false;}
        try{
            $receipt=$s['consolidacao']??array();$receipt['versao']='1.28.0';$receipt['marcos']=$receipt['marcos']??array();$previous=get_option('f3base_release_1250',array());$initial=$s['coleta_adicional_desde']??$previous['coleta_adicional_desde']??$previous['concluido_em']??null;
            foreach(self::RETIRADOS as $n){$f=F3Base_Options::fotografia_bruta($n);if($f['erro']){return false;}if(!$f['existe']){continue;}$v=$f['valor'];
                if($n==='f3base_release_1140'&&is_array($v)&&!empty($v['concluido_em'])){$initial=$v['concluido_em'];}
                $meta=is_array($v)?array_intersect_key($v,array_flip(array('versao','origem','iniciado_em','concluido_em','concluida_em','codigo','etapa','etapa_atual','estado','falhas','cursor','cursor_verificacao','transferencia_intencoes'))):array();
                $receipt['marcos'][$n]=$meta+array('sha256'=>hash('sha256',maybe_serialize($v)),'revisao'=>$f['revisao']);
                $incomplete=is_array($v)&&empty($v['concluido_em'])&&(!empty($v['iniciado_em'])||in_array($n,array('f3base_release_1120','f3base_reparo_1120','f3base_migracao_1110'),true));
                $oldDone=$n==='f3base_migracao_1110'&&is_array($v)&&($v['codigo']??'')==='concluida_uma_vez'&&is_numeric($v['concluida_em']??null)&&$v['concluida_em']>0&&(!isset($v['cursor'],$v['cursor_verificacao'])||(string)$v['cursor']===(string)$v['cursor_verificacao']);
                $superseded=$incomplete&&str_starts_with($n,'f3base_release_')&&($s['versao']??'')===F3BASE_PLUGIN_VERSAO&&version_compare((string)($v['versao']??self::versao($n)),F3BASE_PLUGIN_VERSAO,'<');
                if($incomplete&&!$oldDone&&!$superseded){$receipt['marcos'][$n]['preservado']='progresso_incompleto_sem_prova_de_superacao';}
                else{unset($receipt['marcos'][$n]['preservado']);$receipt['marcos'][$n]['motivo']=$oldDone?'concluido_formato_1110':($superseded?'superado_por_release_concluida':'marcador_concluido_ou_operacional');$receipt['marcos'][$n]['comprovado_por']=F3Base_Instalacao::OPTION;$receipt['marcos'][$n]['retirada_prevista_em']=time();}
            }
            $save=F3Base_Options::atualizar_estado(F3Base_Instalacao::OPTION,static function($v)use($receipt,$initial){$v['consolidacao']=$receipt;$v['coleta_adicional_desde']=$initial??$v['concluido_em'];return $v;});if(empty($save['persisted'])){return false;}
            foreach($receipt['marcos'] as $n=>$m){if(!in_array($n,self::RETIRADOS,true)||!empty($m['preservado'])){continue;}$f=F3Base_Options::fotografia_bruta($n);if($f['erro']){return false;}if(!$f['existe']){continue;}if(!hash_equals($m['revisao'],$f['revisao'])||!F3Base_Options::retirar_marcador($n,$m['revisao'])){return false;}}
            return !empty(F3Base_Options::atualizar_estado(F3Base_Instalacao::OPTION,static function($v){$v['consolidacao']['concluido_em']=time();return $v;})['persisted']);
        }finally{F3Base_Recuperacao::sair();}
    }
}
