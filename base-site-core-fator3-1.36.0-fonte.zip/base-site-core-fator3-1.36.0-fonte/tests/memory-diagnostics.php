<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$period=array('de'=>'2026-09-16','ate'=>'2026-10-13','visao'=>'resumo','segmento'=>'sem_testes','automacao'=>'audiencia','anotacoes'=>true,'limite'=>5);
$original=ini_get('memory_limit');$forced=false;
$filter=static function($sql)use(&$forced){if(!$forced&&str_starts_with($sql,'SELECT COUNT(*) FROM (SELECT id,sessao,navegacao')){$forced=true;ini_set('memory_limit',(string)memory_get_usage(true));}return $sql;};
add_filter('query',$filter);$r=F3Base_Editorial_Relatorios::consultar($period);remove_filter('query',$filter);ini_set('memory_limit',$original);
check(!$r['ok']&&$r['codigo']==='orcamento_memoria_editorial','genuine_request_budget_refusal');
check($r['diagnostico']['fonte']===F3Base_Analise::tabela()&&$r['diagnostico']['linhas']===5872,'largest_source_analysis_count');
check($r['diagnostico']['fonte_consulta_recusada']===F3Base_Modulo_Comportamento::nome_tabela_eventos(),'current_query_retained_separately');
file_put_contents(getenv('F3BASE_ROOT').'/evidence/memory-refusal.json',wp_json_encode($r,JSON_PRETTY_PRINT));
$filter=static fn($sql)=>str_starts_with($sql,'SELECT COUNT(*) FROM (SELECT id,visitante')?'SELECT 100001':$sql;add_filter('query',$filter);$r=F3Base_Editorial_Relatorios::consultar($period);remove_filter('query',$filter);check(!$r['ok']&&$r['codigo']==='limite_linhas_editorial'&&$r['diagnostico']['linhas']===100001&&$r['diagnostico']['limite_linhas']===100000,'row_cap_unchanged');
evidence('memory-diagnostics');
