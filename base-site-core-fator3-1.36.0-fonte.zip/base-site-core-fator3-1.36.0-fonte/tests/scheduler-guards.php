<?php
require __DIR__.'/bootstrap.php';global $wpdb;F3Base_Instalacao::atualizar();
$mode='429';$posts=0;$http=static function($pre,$args,$url)use(&$mode,&$posts){if($url==='https://slack.com/api/auth.test')return array('headers'=>array(),'response'=>array('code'=>200),'body'=>wp_json_encode(array('ok'=>true,'bot_id'=>'B12345678','team_id'=>'T12345678','user_id'=>'U12345678')),'cookies'=>array());if($url!=='https://slack.com/api/chat.postMessage')return $pre;++$posts;return $mode==='429'?array('headers'=>array('retry-after'=>'30'),'response'=>array('code'=>429),'body'=>'{}','cookies'=>array()):new WP_Error('synthetic_timeout');};add_filter('pre_http_request',$http,PHP_INT_MAX,3);
foreach(array('429','uncertain','suppressed') as $scenario){
 $mode=$scenario;$posts=0;delete_option('f3base_slack_estado');wp_cache_delete('f3base_slack_estado','options');
 foreach(array(F3Base_Avisos::tabela(),F3Base_Slack::tabela()) as $table)$wpdb->query('DELETE FROM '.$table);
 $t=F3Base_Options::ler('f3base_testes');$t['destinos']['slack']=$scenario==='suppressed'?'suprimir':'marcar';raw('f3base_testes',$t);
 $r=F3Base_Leads_Repositorio::guardar(array('nome'=>'[TESTE F3BASE] QA1360 guard','email'=>'guard@example.test','metodo'=>'formulario','captura'=>'aceito','notificar'=>true,'contexto_teste'=>true,'criado_em'=>gmdate('Y-m-d H:i:s',time()-15)));
 $out=F3Base_Avisos::executar();$q=F3Base_Avisos::consultar(array('record_id'=>$r['record_id']));$row=$q['linhas'][0];
 if($scenario==='429'){check($posts===1,'rate_limit_only_one_attempt');check($row['estado']==='pendente'&&(int)$row['proxima']>=time()+28,'parent_backoff_propagated_to_thread');}
 elseif($scenario==='uncertain'){check($posts===1&&$row['estado']==='incerto','uncertain_not_retried_in_burst');F3Base_Avisos::executar();check($posts===1,'uncertain_not_retried_later');}
 else{check($posts===0&&$row['estado']==='suprimido','suppression_preserved');}
}
remove_filter('pre_http_request',$http,PHP_INT_MAX);evidence('scheduler-guards');
