<?php
require __DIR__.'/bootstrap.php';$mode=$argv[1]??'state';global $wpdb;
if($mode==='prepare'){
 F3Base_Instalacao::atualizar();raw('cron',array('version'=>2));
 foreach(array(F3Base_Avisos::tabela(),F3Base_Slack::tabela()) as $table)$wpdb->query('DELETE FROM '.$table);
 $cfg=F3Base_Options::ler('f3base_avisos');$cfg['canal']='slack';$cfg['slack_transporte']='app';$cfg['slack_formato']='thread';$cfg['slack_canal_id']='C12345678';check(save('f3base_avisos',$cfg)['ok'],'notice_config');check(save(F3Base_Slack::SEGREDO,'xoxb-synthetic-1360-not-a-token')['ok'],'synthetic_token');
 $t=F3Base_Options::ler('f3base_testes');$t['destinos']['slack']='marcar';raw('f3base_testes',$t);delete_option('qa1360_slack_calls');
 $r=F3Base_Leads_Repositorio::guardar(array('nome'=>'[TESTE F3BASE] QA1360','email'=>'qa1360@example.test','metodo'=>'formulario','formulario'=>'contato','captura'=>'aceito','notificar'=>true,'contexto_teste'=>true,'pagina'=>home_url('/qa1360/')));
 check($r['persisted'],'capture');$next=wp_next_scheduled(F3Base_Avisos::EVENTO);check($next&&$next<=time()+11&&$next>=time()+1,'intention_schedules_due_time');
 update_option('qa1360_notice_record',$r['record_id'],false);update_option('qa1360_notice_start',time(),false);
 wp_clear_scheduled_hook(F3Base_Avisos::EVENTO);F3Base_Avisos::capturado(F3Base_Leads_Repositorio::obter($r['record_id']));check((bool)wp_next_scheduled(F3Base_Avisos::EVENTO),'idempotent_enqueue_repairs_missing_event');
 // Deliberately remove it again: native wp-cron must recover from persisted work.
 wp_clear_scheduled_hook(F3Base_Avisos::EVENTO);check(!wp_next_scheduled(F3Base_Avisos::EVENTO),'lost_event_reproduced');
 evidence('scheduler-enqueue');echo wp_json_encode(array('prepared'=>true,'started'=>time()))."\n";exit;
}
$q=F3Base_Avisos::consultar(array('record_id'=>get_option('qa1360_notice_record')));$r=$q['linhas'][0]??array();
$parts=array();foreach($r['partes']??array() as $p){$parts[]=array_intersect_key($p,array_flip(array('estado','codigo','sequencia','atualizada_em')));}
echo wp_json_encode(array('state'=>$r['estado']??null,'code'=>$r['codigo']??null,'parts'=>$parts,'next'=>$q['saude']['proxima_execucao'],'elapsed'=>time()-(int)get_option('qa1360_notice_start'),'calls'=>get_option('qa1360_slack_calls',array())))."\n";
