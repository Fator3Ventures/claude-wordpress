<?php
require __DIR__.'/bootstrap.php';
$prefix=getenv('QA_MEMORY_LABEL')?:'candidate';$limit=getenv('QA_MEMORY_LIMIT')?:'128M';ini_set('memory_limit',$limit);
$padding=array();while(memory_get_usage(false)<65*1024*1024){$padding[]=str_repeat('P',32768);}gc_mem_caches();$before=array('viva'=>memory_get_usage(false),'arena'=>memory_get_usage(true));
$period=array('de'=>'2026-09-16','ate'=>'2026-10-13','segmento'=>'sem_testes','automacao'=>'audiencia','anotacoes'=>true,'limite'=>5);
$inputs=array();foreach(array('resumo','aquisicao','conteudo','sessoes','origem_ia','qualidade') as $view){$inputs[$view]=$period+array('visao'=>$view);}
$inputs['session']=$period+array('visao'=>'sessao','sessao'=>md5('qa1360-session-1'));
$inputs['filtered']=$period+array('post_id'=>(int)get_option('qa1360_memory_ids')[2],'navegador'=>'safari');
$inputs['compare']=$period+array('visao'=>'resumo','comparar'=>true);
$inputs['tests']=$period;$inputs['tests']['segmento']='somente_testes';$inputs['tests']['automacao']='todas';
$results=array();$memory=array();foreach($inputs as $name=>$input){
 if(function_exists('memory_reset_peak_usage'))memory_reset_peak_usage();$start=microtime(true);$r=F3Base_Editorial_Relatorios::consultar($input);
 $memory[$name]=array('ok'=>$r['ok'],'codigo'=>$r['codigo']??null,'segundos'=>microtime(true)-$start,'peak'=>memory_get_peak_usage(true),'live'=>memory_get_usage(false),'diagnostico'=>$r['diagnostico']??null);
 if(!$r['ok']){file_put_contents(getenv('F3BASE_ROOT').'/evidence/memory-'.$prefix.'.json',wp_json_encode(array('limit'=>$limit,'before'=>$before,'queries'=>$memory),JSON_PRETTY_PRINT));throw new RuntimeException('memory '.$name.' '.wp_json_encode($r));}
 unset($r['consultado_em'],$r['saude_coleta']);$results[$name]=$r;
}
file_put_contents(getenv('F3BASE_ROOT').'/lab/memory-'.$prefix.'-outputs.json',wp_json_encode($results,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
file_put_contents(getenv('F3BASE_ROOT').'/evidence/memory-'.$prefix.'.json',wp_json_encode(array('limit'=>$limit,'before'=>$before,'queries'=>$memory),JSON_PRETTY_PRINT));
echo $prefix.' '.count($inputs)." consultas OK\n";
