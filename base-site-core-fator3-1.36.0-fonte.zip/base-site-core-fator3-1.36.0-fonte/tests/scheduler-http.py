from pathlib import Path
import subprocess,os,json,time,urllib.request
root=Path(__file__).resolve().parents[1];php=str(root/'build/php');env=dict(os.environ,F3BASE_CRON='1')
mu=root/'lab/wordpress/wp-content/mu-plugins/qa-slack.php'
mu.write_text('''<?php
add_filter('pre_http_request',static function($pre,$args,$url){
 if($url==='https://slack.com/api/auth.test')return array('headers'=>array(),'response'=>array('code'=>200),'body'=>wp_json_encode(array('ok'=>true,'bot_id'=>'B12345678','team_id'=>'T12345678','user_id'=>'U12345678')),'cookies'=>array());
 if($url!=='https://slack.com/api/chat.postMessage')return $pre;
 $body=json_decode($args['body'],true);$calls=get_option('qa1360_slack_calls',array());$calls[]=array('at'=>time(),'thread'=>isset($body['thread_ts']),'cron'=>wp_doing_cron());update_option('qa1360_slack_calls',$calls,false);
 return array('headers'=>array(),'response'=>array('code'=>200,'message'=>'OK'),'body'=>wp_json_encode(array('ok'=>true,'channel'=>$body['channel'],'ts'=>time().'.'.str_pad((string)count($calls),6,'0',STR_PAD_LEFT))),'cookies'=>array());
},100,3);
''')
def call(mode):
 r=subprocess.run([php,str(root/'tests/scheduler-cycle.php'),mode],env=os.environ,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stdout+r.stderr)
 return json.loads(r.stdout.splitlines()[-1])
server=None
try:
 out={'prepare':call('prepare')};log=open(root/'lab/http.log','a');server=subprocess.Popen([php,'-S','127.0.0.1:8136','-t',str(root/'lab/wordpress')],env=env,stdout=log,stderr=log)
 started=time.monotonic();history=[]
 while time.monotonic()-started<115:
  try:
   with urllib.request.urlopen('http://127.0.0.1:8136/wp-cron.php',timeout=30) as response:response.read()
  except urllib.error.URLError:time.sleep(.2);continue
  state=call('state');history.append({k:v for k,v in state.items() if k!='calls'});
  if state['state']=='entregue':break
  time.sleep(2)
 out['final']=state;out['history']=history;out['wordpress_cron_only']=all(c['cron'] for c in state['calls']);out['ok']=state['state']=='entregue' and len(state['calls'])>=6 and state['elapsed']<=120 and out['wordpress_cron_only']
 (root/'evidence/scheduler-http.json').write_text(json.dumps(out,indent=2));print(json.dumps({'ok':out['ok'],'seconds':state['elapsed'],'parts':len(state['calls']),'native_cron':out['wordpress_cron_only']}));assert out['ok']
finally:
 if server:server.terminate();server.wait(timeout=15)
 mu.unlink(missing_ok=True)
