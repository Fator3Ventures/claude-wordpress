<?php
/** Temporary, administrator-only homologation fixture. Never included in installer. */
defined('ABSPATH') || exit;
add_action('wp_abilities_api_init',static function(){
 if(!class_exists('F3Base_Servicos')||F3BASE_PLUGIN_VERSAO!=='1.36.0'||wp_parse_url(home_url(),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||time()>1792263600)return;
 F3Base_Servicos::ability('qa1360-contato','Fixture temporária do aceite 224; contato sintético e leitura de sua execução',static function($input){
  if(!current_user_can('manage_options'))return array('ok'=>false,'codigo'=>'sem_permissao');
  $state=get_option('f3base_qa1360_fixture',array());
  if(($input['acao']??'')==='limpar'){
   if(!empty($state['record_id'])&&F3Base_Leads_Repositorio::obter($state['record_id']))return array('ok'=>false,'codigo'=>'remove_fixture_contact_first');
   delete_option('f3base_qa1360_fixture');return array('ok'=>true,'removed'=>true);
  }
  if(($input['acao']??'estado')==='capturar'&&!isset($state['record_id'])){
   $test=F3Base_Options::ler('f3base_testes');$notice=F3Base_Options::ler('f3base_avisos');
   if(empty($test['habilitado'])||($test['destinos']['slack']??'')!=='marcar'||($notice['canal']??'')!=='slack'||($notice['slack_formato']??'')!=='thread'||($notice['slack_canal_id']??'')!=='C0C7GLV8RGF')return array('ok'=>false,'codigo'=>'fixture_policy_changed');
   foreach($test['destinos'] as $dest=>$policy){if($dest!=='slack'&&$policy!=='suprimir')return array('ok'=>false,'codigo'=>'fixture_other_destination_enabled');}
   $crm=F3Base_Options::ler('f3base_pipedrive');if(!empty($crm['ativo'])&&!empty($crm['homologacao']))return array('ok'=>false,'codigo'=>'fixture_crm_enabled');
   $f=F3Base_Formularios::obter('contato');if(!$f)return array('ok'=>false,'codigo'=>'fixture_form_absent');
   $sid=md5('core1360-acceptance-224-20261017');$start=time();
   $request=new WP_REST_Request('POST','/'.F3BASE_REST_NAMESPACE.'/formularios/enviar');
   $request->set_body_params(array('formulario'=>'contato','token'=>F3Base_Formularios::emitir($f,$sid,0),'submissao'=>$sid,'contexto_teste'=>true,'campos'=>array('seu-nome'=>'[TESTE F3BASE] Aceite Core 1.36.0 item 224','sua-empresa'=>'Homologação descartável','seu-email'=>'core1360@example.test')));
   $response=rest_do_request($request);$result=$response->get_data();
   if(empty($result['persisted'])||empty($result['record_id']))return array('ok'=>false,'http'=>$response->get_status(),'codigo'=>$result['codigo']??'fixture_capture_failed');
   $state=array('record_id'=>$result['record_id'],'started_at'=>$start,'http'=>$response->get_status(),'classe_trafego'=>$result['classe_trafego'],'next_after_capture'=>wp_next_scheduled(F3Base_Avisos::EVENTO),'cron_passes'=>array());update_option('f3base_qa1360_fixture',$state,false);
  }
  if(!$state)return array('ok'=>true,'created'=>false);
  $q=F3Base_Avisos::consultar(array('record_id'=>$state['record_id']));$state['native_executions']=$state['cron_passes'];unset($state['cron_passes']);return array('ok'=>true,'fixture'=>$state,'elapsed'=>time()-$state['started_at'],'queue'=>$q);
 },array('acao'=>array('type'=>'string','enum'=>array('capturar','estado','limpar'))),array(),false);
},99);
add_action('f3base_avisos_processar',static function(){
 $s=get_option('f3base_qa1360_fixture',array());if(!$s||time()-($s['started_at']??0)>180)return;
 $s['cron_passes'][]=array('at'=>time(),'wp_doing_cron'=>wp_doing_cron());update_option('f3base_qa1360_fixture',$s,false);
},1);
