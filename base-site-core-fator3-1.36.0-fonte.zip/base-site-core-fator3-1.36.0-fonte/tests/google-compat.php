<?php
require __DIR__.'/bootstrap.php';$base=getenv('F3BASE_ROOT').'/companions/wp-mcp-google-fator3/includes/';require $base.'ContractSchema.php';require $base.'CoreContext.php';
use Fator3\McpGoogle\CoreContext;
wp_set_current_user(0);$cap=CoreContext::capabilities();$snap=CoreContext::snapshot();$events=CoreContext::events($snap,20,3);check($cap['ok']&&$snap['ok']&&$events['ok'],'Google011_consumidor_real');check(count($snap['data']['slots'])===6&&$events['data']['total']===count($events['data']['items']),'Google011_paginas_e_slots');check(!in_array('download_material',array_column($events['data']['items'],'name')),'SDK10_enumeracao_preservada');evidence('google-compat');
