<?php
require __DIR__.'/bootstrap.php';
F3Base_Instalacao::atualizar();
$contract=F3Base_Conversoes_Contexto::CONTRATO;$input=array('contract'=>$contract);
$cap=F3Base_Conversoes_Contexto::capabilities();check(!is_wp_error(rest_validate_value_from_schema($cap,F3Base_Conversoes_Contexto::schema('capabilities'))),'descriptor_schema');
check(F3Base_Conversoes_Contexto::snapshot()['code']==='invalid_input','explicit_negotiation');
check(F3Base_Conversoes_Contexto::snapshot(array('contract'=>'site-conversion-purposes/2.0.0'))['code']==='unsupported','unsupported_version');
check(F3Base_Conversoes_Contexto::snapshot($input+array('expected_revision'=>null))['code']==='invalid_input','null_revision_rejected');
check(F3Base_Conversoes_Contexto::snapshot($input+array('offset'=>0))['code']==='invalid_input','pagination_not_supported');
raw('f3base_ga4_measurement_id','G-ABC1234567');raw('f3base_google_ads',array('conversion_id'=>'AW-123456789','conversion_label'=>'contact-label','conteudo_conversion_label'=>''));raw('f3base_linkedin_partner_id','123456');raw('f3base_linkedin_conversion_id','123456789');raw('f3base_linkedin_conteudo_conversion_id','');raw('f3base_meta_pixel_id','123456789012345');
raw('f3base_conversoes_conteudo',array_fill_keys(array('ga4','meta','google_ads','linkedin'),true));
wp_set_current_user(0);$a=F3Base_Conversoes_Contexto::snapshot($input);check($a['ok'],'sdk_without_user');
check($a['data']['purposes'][0]['ga4_event']==='generate_lead'&&$a['data']['purposes'][1]['ga4_event']==='download_material','event_separation');
$contact=$a['data']['purposes'][0]['destinations'];$material=$a['data']['purposes'][1]['destinations'];
check($contact['google_ads']['configured']&&!$material['google_ads']['configured']&&$material['google_ads']['identifiers']['conversion_label']==='','ads_no_contact_fallback');
check($contact['linkedin']['configured']&&!$material['linkedin']['configured']&&$material['linkedin']['identifiers']['conversion_id']==='','linkedin_no_contact_fallback');
check($material['ga4']['enabled']&&$material['ga4']['configured'],'material_enabled');
check(F3Base_Conversoes_Contexto::snapshot($input+array('expected_revision'=>$a['data']['revision']))['ok'],'stable_revision');
$ability=wp_get_ability('f3base/conversoes-contexto-ler');check(is_wp_error($ability->execute($input)),'ability_denies_anonymous');
$editor=wp_insert_user(array('user_login'=>'sdk-editor-1360','user_pass'=>'synthetic-only','role'=>'editor'));if(is_wp_error($editor)){$editor=get_user_by('login','sdk-editor-1360')->ID;}wp_set_current_user($editor);check(is_wp_error($ability->execute($input)),'ability_denies_editor');
wp_set_current_user(1);check(!is_wp_error($ability->execute($input)),'ability_admin');
$old=F3Base_Medicao_Contexto::snapshot();raw('f3base_linkedin_conteudo_conversion_id','987654321');$b=F3Base_Conversoes_Contexto::snapshot($input);check($b['ok']&&$b['data']['revision']!==$a['data']['revision'],'material_revision_changes');check(F3Base_Conversoes_Contexto::snapshot($input+array('expected_revision'=>$a['data']['revision']))['code']==='revision_conflict','obsolete_revision_rejected');
$toggle=0;$filter=static function($v)use(&$toggle){$v['ga4']=(++$toggle%2)===0;return $v;};add_filter('option_f3base_conversoes_conteudo',$filter);$unstable=F3Base_Conversoes_Contexto::snapshot($input);remove_filter('option_f3base_conversoes_conteudo',$filter);check($unstable['code']==='revision_conflict','unstable_filter_rejected');
$filter=static fn($v)=>'malformed secret synthetic';add_filter('option_f3base_linkedin_conteudo_conversion_id',$filter);$invalid=F3Base_Conversoes_Contexto::snapshot($input);remove_filter('option_f3base_linkedin_conteudo_conversion_id',$filter);check(!str_contains(wp_json_encode($invalid),'malformed secret'),'invalid_id_not_leaked');
global $wpdb;$writes=0;$network=0;$query=static function($sql)use(&$writes){if(preg_match('/^\s*(INSERT|UPDATE|DELETE|REPLACE|ALTER|CREATE|DROP)/i',$sql))++$writes;return $sql;};$http=static function($pre)use(&$network){++$network;return new WP_Error('unexpected_network');};add_filter('query',$query);add_filter('pre_http_request',$http);$last=F3Base_Conversoes_Contexto::snapshot($input);remove_filter('query',$query);remove_filter('pre_http_request',$http);check($last['ok']&&$writes===0&&$network===0,'read_only_no_network');
$dir=F3BASE_PLUGIN_DIR.'docs/fixtures/conversion/';wp_mkdir_p($dir);foreach(array('capabilities'=>$cap,'material-enabled-ids-empty'=>$a,'material-own-id'=>$b,'unsupported'=>F3Base_Conversoes_Contexto::snapshot(array('contract'=>'2.0.0')),'revision-conflict'=>F3Base_Conversoes_Contexto::snapshot($input+array('expected_revision'=>str_repeat('0',64)))) as $name=>$example){file_put_contents($dir.$name.'.json',wp_json_encode($example,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));}
evidence('conversion-sdk');
