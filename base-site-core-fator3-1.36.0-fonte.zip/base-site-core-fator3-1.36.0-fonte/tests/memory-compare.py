from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
a=json.loads((root/'lab/memory-baseline-outputs.json').read_text())
b=json.loads((root/'lab/memory-candidate-outputs.json').read_text())
differences=[key for key in set(a)|set(b) if a.get(key)!=b.get(key)]
result={'exact_domain_output':not differences,'queries':len(a),'differences':differences}
(root/'evidence/memory-parity.json').write_text(json.dumps(result,indent=2))
assert not differences,result
print('memory parity: 10 queries identical')
