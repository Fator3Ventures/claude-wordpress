<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$wpdb->query('DELETE FROM '.F3Base_Editorial::tabela('conteudos'));
$ids=array();for($i=0;$i<24;$i++){$id=wp_insert_post(array('post_title'=>'QA1360 Conteúdo '.$i,'post_status'=>'publish','post_type'=>$i%2?'post':'page','post_name'=>'qa1360-'.$i));F3Base_Editorial::catalogar($id);$ids[]=$id;}
foreach(array(F3Base_Analise::tabela(),F3Base_Modulo_Comportamento::nome_tabela_eventos(),F3Base_Editorial::tabela('editorial_diario'),F3Base_Editorial::tabela('editorial_dias')) as $table){$wpdb->query('DELETE FROM '.$table);}
$start=(new DateTimeImmutable('2026-09-16',wp_timezone()))->getTimestamp();$sources=array(array('utm_source'=>'google','utm_medium'=>'organic'),array('utm_source'=>'chatgpt','utm_medium'=>'referral'),array('utm_source'=>'newsletter','utm_medium'=>'email'),array('utm_source'=>'google','utm_medium'=>'cpc'),array());
for($i=0;$i<5872;$i++){
 $day=$i%28;$sid=md5('qa1360-session-'.intdiv($i,4));$nav=md5('qa1360-nav-'.$i);$kind=$i%9===0?'vital':($i%11===0?'form_inicio':'pagina');$at=$start+$day*DAY_IN_SECONDS+3600+$i;
 $attr=F3Base_Atribuicao::normalizar($sources[$i%5]);$attr['fixture_padding']=str_repeat('synthetic.',440);
 $row=array('evento'=>md5('qa1360-'.$i),'visitante'=>md5('qa1360-visitor-'.intdiv($i,8)),'sessao'=>$sid,'classe_trafego'=>$i%31===0?'teste':'nao_marcado','navegacao'=>$nav,'navegacao_anterior'=>$i%4?md5('qa1360-nav-'.($i-1)):'','tipo'=>$kind,'post_id'=>$ids[$i%24],'caminho'=>'/qa1360-'.($i%24).'/','tipo_conteudo'=>$i%2?'artigo':'pagina','dispositivo'=>'movel','largura_faixa'=>$i%2?'360_479':'768_1023','sistema'=>'Android','navegador'=>$i%2?'chrome':'safari','retorno'=>$i%3?'novo':'recorrente','aparelho'=>'celular','automacao'=>$i%37===0?'provavel':'nao_identificada','automacao_regra'=>$i%2?'qa1360':'','canal'=>'direto','origem_ia'=>'','inicio_sessao'=>$at,'entrada'=>'/qa1360-'.($i%24).'/','criado_em'=>$at,'recebido_em'=>$at,'qualidade'=>'completa','detalhe'=>$kind==='vital'?'LCP':($i%5===0?'ancora':''),'valor'=>100,'atribuicao'=>wp_json_encode($attr),'payload_hash'=>hash('sha256','qa1360-'.$i));
 if(!$wpdb->insert(F3Base_Analise::tabela(),$row)){throw new RuntimeException('seed analysis '.$i.' '.$wpdb->last_error);}
 if($i<1931){$metric=F3Base_Modulo_Comportamento::evento_do_gatilho($i%2?'tempo-ativo':'rolagem');$event=array('evento'=>md5('consume'.$i),'sessao'=>$sid,'navegacao'=>$nav,'classe_trafego'=>$row['classe_trafego'],'caminho'=>$row['caminho'],'criado_em'=>$at+30,'recebido_em'=>$at+30,'metrica'=>$metric,'detalhe'=>$i%2?'heartbeat':'50','valor'=>$i%2?1000:0,'ms'=>2000,'ancora'=>'pareada');
  $cols=$cols??$wpdb->get_col('SHOW COLUMNS FROM '.F3Base_Modulo_Comportamento::nome_tabela_eventos());$event=array_intersect_key($event,array_flip($cols));if(!$wpdb->insert(F3Base_Modulo_Comportamento::nome_tabela_eventos(),$event)){throw new RuntimeException('seed events '.$wpdb->last_error);}
 }
}
update_option('qa1360_memory_ids',$ids,false);
echo wp_json_encode(array('analysis'=>(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Analise::tabela()),'events'=>(int)$wpdb->get_var('SELECT COUNT(*) FROM '.F3Base_Modulo_Comportamento::nome_tabela_eventos()),'contents'=>count($ids)))."\n";
