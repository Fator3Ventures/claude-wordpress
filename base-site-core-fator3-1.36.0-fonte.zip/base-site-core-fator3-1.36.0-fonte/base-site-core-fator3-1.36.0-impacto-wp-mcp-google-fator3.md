# Impacto de Fator3 Site Core 1.36.0 em Fator3 MCP Google

Data: 2026-10-17 · Revisão 2 · Etapa: entrega · Situação: aberto para adoção pelo consumidor

## Contrato entregue e ação atual

Instalador emissor: **base-site-core-fator3-1.36.0-instalador.zip**, 1.967.841 bytes, SHA-256 **eeec2a765d7e004aab1046fd59a25e455b6b5651d4468368fdf220b3e23d811b**. Alvo 1.36.0 entregue e instalado no Site-Teste; base direta 1.35.0. Referência: impacto Google 0.11.0 revisão 2 e Pedidos core 222.

Implementada a alternativa separada proposta abaixo: `site-conversion-purposes/1.0.0`, classe `F3Base_Conversoes_Contexto`, `capabilities()` e `snapshot(array)`. Descritor próprio com contract_version 1.0.0, schema_revision 1, métodos, capability conversion.purposes.read e schemas. O SDK `site-measurement-context/1.0.0`, seus seis slots, descritor, schemas e catálogo fechado permanecem inalterados.

Entrada obrigatória: `{"contract":"site-conversion-purposes/1.0.0"}`. `expected_revision` é opcional; revisão obsoleta ou leitura instável retorna revision_conflict/data:null. Contrato desconhecido retorna unsupported; entrada inválida, invalid_input. Sem paginação; offset/limit são recusados.

O snapshot separa contact/material, eventos GA4 generate_lead/download_material e Meta Lead/MaterialDownload, com enabled/configured, IDs públicos e procedência por destino. Material Ads usa conteudo_conversion_label e LinkedIn seu ID próprio. Vazio nunca herda contato. Os quatro interruptores true com IDs vazios são preservados; enabled:true/configured:false é um estado válido. runtime_verified e remote_access_verified são false: não comprovam emissão nem acesso à conta. Não há tokens, PII ou consentimento individual.

**Responsável Google:** adotar descoberta opcional por classe/método/descritor exato, validar resposta e manter o caminho antigo. Testar ausência do produtor, versão não suportada, revisão concorrente, permissões administrativas e material habilitado com IDs vazios/próprios. Não ampliar enums do SDK antigo, ler options privadas nem criar automaticamente eventos-chave, ações, tags, campanhas ou assinaturas. Google 0.11.0 ainda não consome este contrato; este trabalho não está declarado concluído.

O PHP interno projeta configuração pública sem exigir usuário. O consumidor mantém sua própria autorização administrativa; `f3base/conversoes-contexto-ler` exige manage_options na permissão e no callback. Ausência/recusa suspende somente a descoberta adicional. Core pode ser atualizado antes do futuro consumidor, sem nova dependência obrigatória.

## Evidência da implementação e entrega

- 19 verificações nativas do produtor: schemas, versão, revisão, permissões, IDs separados, sanitização e zero escrita/rede no snapshot.
- Três verificações com classes reais do consumidor Google 0.11.0 no SDK anterior, preservando os seis slots e o catálogo fechado.
- Instalação limpa e upgrade 1.35.0→1.36.0 em WordPress 7.1.2/PHP 8.3.6; quatro interruptores true e IDs vazios preservados.
- Site-Teste WordPress 7.1.3/PHP 8.3.30: Core 1.36.0 com MCP 0.24.0, Google 0.11.0, Meta/LinkedIn 0.3.0. Acompanhantes inalterados. Snapshot opcional retornou contact/material; material habilitado e IDs vazios.
- Documentação `docs/CONVERSOES-SDK-1.36.md` lida pelo MCP em cinco páginas com SHA-256 estável `efdf3c93c39290a43939b84a0b8f7665708ce9e51f74b7ef00a8656565a2ab6c` e versão 1.36.0.

Quatro schemas instalados em `docs/schemas/conversion-{capabilities,snapshot-input,snapshot,ability-snapshot}.json`; cinco exemplos em `docs/fixtures/conversion/`. Evidências no fonte: conversion-sdk.json, google-compat.json, native-cycles.json e site-teste.json. Não houve homologação comercial Google nesta rodada.

**Resposta esperada:** responsável Google informa versão consumidora e evidência do aceite, ou impedimento concreto. Lado produtor entregue; encaminhamento aberto para adoção/validação do consumidor. Dono/frota configuram ações próprias de material quando disponíveis.

## Histórico preservado — revisão 1, planejamento anterior ao código

O texto abaixo registra a proposta inicial; os estados planejados são históricos. A entrega acima prevalece.

Natureza: contrato · Classificação: acao-necessaria (adoção opcional pelo consumidor).
Base Core 1.35.0, SHA-256 1368395e6c5842c21e822010310c1d544000ed7d72b2f6ee234491d18c686f20; alvo previsto 1.36.0, instalador ainda não gerado.
Google examinado 0.11.0, SHA-256 d181deaeee8ef365ac4d6a08884d9fa3d3a3164b21f0538d8ed5d56722536bf9.

## Mudança e consequência

Resposta ao impacto Google 0.11.0 revisão 2 e Core 222: aceite da alternativa de contrato adicional separado. Planejado SDK site-conversion-purposes/1.0.0, classe pública F3Base_Conversoes_Contexto, capabilities() e snapshot(array). Descritor próprio anuncia versão exata, método e schemas. Não acrescentar campos, slots ou nomes ao SDK site-measurement-context/1.0.0.

Snapshot distingue contato e material, evento GA4 efetivo, identificadores públicos de cada destino, habilitação/configuração, procedência e revisão. Sem tokens, PII ou consentimento individual. Labels Ads e IDs LinkedIn de material nunca herdam contato.

## Ação ou decisão do responsável

Core publica contrato, schemas e fixtures nesta rodada. Google poderá implementar descoberta optativa verificando classe/métodos e versão exata; ausência ou recusa afeta somente descoberta adicional. Não criar eventos-chave, ações de conversão ou tags automaticamente. Aceite Google deve cobrir versão não suportada, revisão concorrente, autorização administrativa e ausência de mapeamento material→contato.

## Compatibilidade e sequência

Contrato atual preservado integralmente; consumidor Google 0.11.0 continua no SDK anterior. Core pode ser atualizado antes de um futuro consumidor. Nenhuma dependência obrigatória nova. Não está sendo implementado código no Google nem alegado aceite de seu responsável.

## Validação e evidência

Planejados: schema estrito, leitura sem escrita/rede, projeção sem segredos, permissões, revisão estável, teste do consumidor Google atual e preservação de configuração na atualização.

## Resposta esperada

Responsável Google: incorporar os schemas publicados e retornar evidência de negociação/consumo na sua próxima rodada, ou impedimento concreto. A proposta não bloqueia o SDK antigo.

## Evolução e encerramento

r1: aceita alternativa separada solicitada; nomes exatos propostos acima antes da implementação. Ainda não há prova de execução nem instalador alvo.
