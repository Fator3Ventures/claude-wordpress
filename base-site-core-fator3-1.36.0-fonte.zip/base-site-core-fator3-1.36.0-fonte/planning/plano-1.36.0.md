# Plano — Fator3 Site Core 1.36.0

2026-10-17 · Implementação. Base imutável 1.35.0, instalador SHA-256 1368395e6c5842c21e822010310c1d544000ed7d72b2f6ee234491d18c686f20; alvo minor 1.36.0.

Pedidos core 212(a) e 224; itens 219–223 aceitos pela frota não são reabertos. Preservar todos os interruptores de material, inclusive true com identificadores vazios. Nenhuma mudança de mínimos, configuração administrativa, tabelas ou transporte MCP está planejada.

212(a): percorrer análise por lotes; normalizar dimensões da primeira observação por sessão; reter somente agregados e referências compactas necessárias a deduplicação, pareamento e continuidade. Comparar saída completa com a base, incluindo filtros e dados históricos, sob volume de 5.872 linhas, 24 conteúdos e 1.931 eventos; limite PHP real 128 MiB e base aproximada de 65 MiB. Recusa deve identificar consulta recusada e maior crescimento observado por fonte.

224: reproduzir ausência de cron, reparar registro inicial/continuação com evento único próprio, preservar recuo e incerteza externa; observar próxima execução real. Validar WP-Cron nativo e realizar teste marcado no Site-Teste se o destino e a política de homologação estiverem configurados. Não criar evento manual para suprir defeito do candidato.

Contrato Google: aceitar a alternativa opcional separada, sem modificar site-measurement-context/1.0.0. Encaminhamento antes de implementar: ../docs/base-site-core-fator3-1.36.0-impacto-wp-mcp-google-fator3.md. A classe e o schema novos constituem oferta do Core; adoção do consumidor Google permanece responsabilidade daquele pacote. Não há conflito com a interface fechada existente.

Demais fronteiras: alterações internas de relatório/avisos não exigem adaptação MCP, Meta, LinkedIn ou Implantador. Nenhuma interface nova obrigatória ou campo de configuração. Implantador atual não recebido e não será alegado como testado.

Entrega: fonte, instalador, relatório canônico e impacto Google. Instalação limpa e upgrade direto locais; identidade do instalador final e atualização autorizada somente no Site-Teste, precedida de backup e releitura da versão. Publicação e distribuição da frota ficam com o dono.
