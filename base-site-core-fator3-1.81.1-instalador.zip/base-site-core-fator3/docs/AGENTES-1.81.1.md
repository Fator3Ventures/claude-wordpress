# Operação do Site Core 1.81.1

Leia docs/RELEASE-1.81.1.md em f3base/documentacao-ler. Confira o recibo de f3base/servidor-aplicar com acao consultar depois da execução horária. Para os canais comerciais, confira na ficha do contato a conta e o anúncio. Compare a mesma resposta Origem e o mesmo objeto no CRM antes e depois do complemento. Verifique o escopo files:write do bot e a concessão específica da integração caso o texto chegue sem a imagem. Em um resultado de criação incerto, confira o destino pelo identificador da oportunidade antes de qualquer ação manual.
