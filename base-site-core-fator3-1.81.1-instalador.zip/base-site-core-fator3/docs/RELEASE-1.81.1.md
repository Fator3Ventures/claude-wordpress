# Fator3 Site Core 1.81.1

Bases de migração verificadas na rodada: 1.80.0 e 1.81.0. PHP 8.3 de 64 bits e WordPress 7.1.4. Contrato de configuração 8.38.0.

## Sonda do servidor

A reverificação horária consulta o caminho instalado de wp-content/upgrade/ com o esquema, host e porta de home_url. O diretório precisa responder 404 diretamente. O Core confere também o arquivo de controle e a negativa de listagem em outro diretório. Consulte o resultado na operação de consulta de f3base/servidor-aplicar.

## Aviso individual no Slack

Configure um aplicativo com bot, canal e formato thread em Site Core → Configurações → Conexões e entregas. O aviso contém identificação, Acontecimento, Origem, Visitas e Links. Campos sem valor são omitidos. Os links comerciais e a classificação vêm da oportunidade confirmada no CRM. Ao atingir a cota horária, os threads individuais aguardam a próxima janela. Os formatos completo e compacto conservam a contingência por resumo.

## Anúncio de origem

O Core consulta Meta 0.24.1 pela extensão meta-ad-origin/1.0.0, LinkedIn 0.21.0 pela linkedin-ad-source/1.0.0 e Google 0.34.0 pela google-ads-origin/1.0.0. Configure a conta e conceda leitura no respectivo pacote. Para LinkedIn habilite ad_source e responses para o formulário nativo. Para Google habilite clicks e origin_ad. O método f3base/google-ads-anuncio-origem aceita ad_id ou o par gclid e date (dia da conta). Exige manage_options e f3base_ler_leads. O Google pode devolver campanha sem identificar anúncio ou variante.

O Core usa o WP-Cron para enriquecer contatos pagos com destino confirmado. A resposta Origem recebe texto e imagem por ID de arquivo do próprio Slack. O app precisa de files:write para copiar imagens. O Pipedrive recebe uma nota fixada e um arquivo vinculado à mesma oportunidade, inclusive quando for um negócio existente. Para vídeo usa miniatura e link estável de reprodução. O código aceita JPEG, PNG e GIF de até 4 MiB. A URL temporária de download não integra a nota, a resposta nem o recibo.

A ficha do contato mostra a referência disponível, a data da consulta e o estado de entrega. Em um contato anterior à atualização, use Consultar anúncio na plataforma para conferir o criativo com a concessão vigente. Essa consulta manual não publica no Slack nem cria uma nota no CRM. O worker reage à entrega inicial e ao retorno comercial. O cron tenta novamente em intervalos crescentes, por até 30 dias. Após interrupção durante uma criação remota, a ficha indica escrita sem confirmação e o Core conserva a reserva para evitar duplicação.

Quando a classificação comercial é o único dado possível de Visitas, o envio de Links aguarda a fila comercial em andamento. Em threads antigos ou retomados nos quais Links já foi publicado sem Visitas, o Core insere o bloco Visitas antes do bloco Links na mesma resposta. Falhas definitivas do CRM liberam o link do contato.
