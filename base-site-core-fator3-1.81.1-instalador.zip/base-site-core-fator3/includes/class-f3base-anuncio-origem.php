<?php
/** Seleção de origem por contato. Somente a projeção estável chega aos destinos. */
declare(strict_types=1);
defined('ABSPATH') || exit;
final class F3Base_Anuncio_Origem {
    public static function base(array $a): array {
        $n=$a['origem_nativa']??[];
        $t=$a['atribuicao']??[];
        if(!empty($n['is_organic']) || ($t['utm_medium']??'')==='organic' || !empty($t['conflito_plataforma'])){return [];}
        $platform=$n['origem']??(['meta_ads'=>'meta','google_ads'=>'google','linkedin_ads'=>'linkedin'][$t['plataforma']??'']??'');
        if(!in_array($platform,['meta','google','linkedin'],true) || (!$n && empty($a['consentimento_historico']['publicidade']))){return [];}
        $id=static fn($v)=>is_scalar($v)&&preg_match('/^[0-9]{1,40}$/D',(string)$v)?(string)$v:'';
        $account=$id($n['conta_id']??$t['conta_id']??'');
        $campaign=$id($n['campanha_id']??$t['campanha_id']??'');
        $ad=$id($n['anuncio_id']??$t['anuncio_id']??'');
        $group=$id($t['grupo_id']??'');
        $fields=['Plataforma'=>['meta'=>'Meta','google'=>'Google Ads','linkedin'=>'LinkedIn'][$platform],
            'Conta'=>$account,'ID da campanha'=>$campaign,'Campanha'=>$t['nome_campanha_origem']??$t['utm_campaign']??'',
            'ID do anúncio'=>$ad,'Anúncio'=>$t['nome_anuncio_origem']??''];
        $cfg=F3Base_Options::ler('f3base_pipedrive');
        $partner=F3Base_Pipedrive_Configuracao::aquisicao($a,$cfg)['parceiro'];
        $label=array_search((string)$partner,array_map('strval',$cfg['mapa_parceiros']??[]),true);
        if($label!==false && $partner!==null){$fields['Parceiro']=ucfirst($label);}
        if(in_array($platform,['google','meta'],true)){
            $map=$platform==='meta'?F3Base_Meta_Ads::opcoes():F3Base_Google_Acervo::opcoes();
            if($account!=='' && $map['conta_id']===$account){
                $match=array_column($map['parceiros'],null,'campanha_id')[$campaign]??$map['parceiro_padrao'];
                if(!empty($match['rotulo'])){$fields['Parceiro']=$match['rotulo'];}
            }
        }
        if($platform==='meta' && $account){
            $manager='https://adsmanager.facebook.com/adsmanager/manage/';
            if($ad){$fields['Abrir anúncio']=$manager.'ads?act='.$account.'&selected_ad_ids='.$ad;}
            if($campaign){$fields['Abrir campanha']=$manager.'campaigns?act='.$account.'&selected_campaign_ids='.$campaign;}
        }elseif($platform==='linkedin' && $campaign && $account){
            $fields['Abrir campanha']='https://www.linkedin.com/campaignmanager/accounts/'.$account.'/campaigns/'.$campaign.'/creatives';
            if($ad){$fields['Abrir anúncio']='https://www.linkedin.com/ad-library/detail/'.$ad;}
        }elseif($platform==='google' && $campaign){
            $fields['Abrir campanha']='https://ads.google.com/aw/campaigns?campaignId='.$campaign;
            if($group){$fields['Abrir grupo']='https://ads.google.com/aw/ads?campaignId='.$campaign.'&adGroupId='.$group;}
        }
        return ['platform'=>$platform,'account'=>$account,'ad'=>$ad,'campaign'=>$campaign,'fields'=>array_filter($fields,'strlen')];
    }
    /** O endereço de mídia existe apenas durante esta tentativa. */
    public static function resolver(array $base,array $lead): array {
        $p=$base['platform'];$account=$base['account'];$ad=$base['ad'];$n=$lead['dados']['origem_nativa']??[];
        $fail=['fields'=>$base['fields'],'media'=>'','complete'=>false,'codigo'=>'selecao_ou_identidade_pendente'];
        if($p==='meta'){
            $r=F3Base_Meta_Ads::anuncio_origem($account,$ad);
        }elseif($p==='linkedin'){
            $configs=array_filter(F3Base_Linkedin_Integracoes::colecao(),static fn($v)=>!empty($v['ativo']) && $v['conta_id']===$account && $v['cliente']==='linkedin_plugin');
            $key=$n['integracao_id']??(count($configs)===1?array_key_first($configs):null);
            if($key===null || !isset($configs[$key])){return $fail;}
            $query=$n?['form_id'=>$n['formulario_id'],'response_id'=>$n['lead_id']]:['creative_id'=>$ad];
            $r=F3Base_Linkedin_Integracoes::executar($key,static fn()=>F3Base_Linkedin_Cliente::origem_anuncio($query));
        }else{
            $attr=$lead['dados']['atribuicao']??[];
            $click=$attr['gclid']??'';
            if(!$click && ($attr['sessao_origem']['plataforma']??'')==='google_ads' && empty($attr['sessao_origem']['conflito_plataforma'])){$click=$attr['sessao_origem']['gclid']??'';}
            $saved=$lead['google_ads']??[];if(is_string($saved)){$saved=json_decode($saved,true)?:[];}
            $row=($saved['codigo']??'')==='encontrado'?($saved['clique']??[]):[];
            if(!$ad && !$click){return $fail;}
            if(!$account && $click){$account=(string)($row['account_id']??F3Base_Google_Acervo::opcoes()['conta_id']);}
            $date=$row['date']??wp_date('Y-m-d',strtotime($lead['criado_em'].' UTC'));
            $r=F3Base_Google_Acervo::origem_conta($account,$ad?['ad_id'=>$ad]:['gclid'=>$click,'date'=>$date]);
            if(empty($r['success']) || ($r['contract']??'')!=='google-ads-origin/1.0.0' || ($r['account_id']??'')!==$account || !in_array($r['state']??'',['found','campaign_only'],true)){$fail['codigo']=sanitize_key($r['state']??$r['error_code']??$r['codigo']??'origem_indisponivel');return $fail;}
            $r=['ok'=>true,'origem'=>$r];
        }
        if(empty($r['ok'])){$fail['codigo']=sanitize_key($r['codigo']??'origem_indisponivel');return $fail;}
        $d=$r['origem'];$actual=$d['ad_id']??$d['ad']['id']??$d['creative_id']??'';
        $campaign=$d['campaign']['id']??$d['campaign_id']??'';
        if(($d['account_id']??'')!==$account || ($ad && $actual!==$ad) || ($base['campaign'] && $campaign && $base['campaign']!==$campaign)){return $fail;}
        return self::projetar($base,$d,$r['midia_temporaria']??[]);
    }
    public static function projetar(array $base,array $d,array $links=[]): array {
        $fields=$base['fields'];$p=$base['platform'];$media='';$complete=true;
        if($p==='meta'){
            $c=$d['creative'];$story=$c['effective_object_story_id']??'';
            $publication=$c['instagram_permalink_url']??($story?'https://www.facebook.com/'.$story:'');
            $new=['Campanha'=>$d['campaign']['name'],'ID da campanha'=>$d['campaign']['id'],'Anúncio'=>$d['ad']['name'],'Conjunto'=>$d['adset']['name']??'','ID do conjunto'=>$d['adset']['id']??'','Abrir anúncio'=>$d['ads_manager_url'],'Publicação'=>$publication,'Texto'=>$c['primary_text'],'Título'=>$c['title'],'Descrição'=>$c['description'],'Botão'=>$c['button'],'Destino'=>$c['destination']];
            if($d['campaign']['id']){$new['Abrir campanha']='https://adsmanager.facebook.com/adsmanager/manage/campaigns?act='.$d['account_id'].'&selected_campaign_ids='.$d['campaign']['id'];}
            $media=$c['thumbnail_url']??'';if(empty($c['video_id'])){$media=$c['image_url']??$media;}elseif($publication){$new['Assistir']=$publication;}
            if(!$media){
                foreach(array_merge($c['cards']??[],$c['media_variants']??[]) as $variant){
                    $candidate=!empty($variant['video_id'])?($variant['thumbnail_url']??''):($variant['image_url']??$variant['thumbnail_url']??'');
                    if($candidate){$media=$candidate;$new['Mídia']='Referência de uma variante do criativo';break;}
                }
            }
            $complete=empty($d['notices']);
        }elseif($p==='linkedin'){
            $new=['Campanha'=>$d['campaign_name'],'ID da campanha'=>$d['campaign_id'],'ID do anúncio'=>$d['creative_id'],'Anúncio'=>$d['creative_name'],'Abrir campanha'=>$d['campaign_manager_url'],'Publicação'=>$d['post_url'],'Texto'=>$d['text'],'Título'=>$d['title'],'Descrição'=>$d['description'],'Botão'=>$d['button'],'Destino'=>$d['destination_url']];
            $media=$links['thumbnail']['url']??'';if(($d['media_type']??'')==='video'){$new['Assistir']=$d['post_url'];}
        }else{
            $items=$d['media']??[];
            $videos=array_values(array_filter($items,static fn($v)=>($v['type']??'')==='youtube' && !empty($v['watch_url'])));
            $images=array_values(array_filter($items,static fn($v)=>($v['type']??'')==='image' && !empty($v['download_url'])));
            $m=$videos[0]??$images[0]??[];$media=$m['thumbnail_url']??'';if(($m['type']??'')==='image'){$media=$m['download_url']??$media;}
            $new=['Conta'=>$d['account_id'],'Campanha'=>$d['campaign']['name']??'','ID da campanha'=>$d['campaign']['id']??'','ID do anúncio'=>$d['ad_id']??'','Abrir campanha'=>$d['campaign']['ads_url']??'','Abrir grupo'=>$d['ad_group']['ads_url']??'','Título'=>implode(' · ',$d['headlines']??[]),'Descrição'=>implode(' · ',$d['descriptions']??[]),'Destino'=>$d['final_urls'][0]??'','Assistir'=>$m['watch_url']??''];
            $complete=!empty($d['assets_complete']) && $d['state']==='found';
        }
        return ['fields'=>array_replace($fields,array_filter($new,static fn($v)=>is_scalar($v) && (string)$v!=='')),'media'=>$media,'complete'=>$complete,'codigo'=>$complete?'origem_consultada':'origem_parcial'];
    }
    public static function imagem(string $url): ?array {
        if($url==='' || wp_parse_url($url,PHP_URL_SCHEME)!=='https'){return null;}
        $res=wp_safe_remote_get($url,['timeout'=>6,'redirection'=>0,'limit_response_size'=>4194305]);
        if(is_wp_error($res)||wp_remote_retrieve_response_code($res)!==200){return null;}
        $bytes=wp_remote_retrieve_body($res);if(strlen($bytes)>4194304){return null;}
        $info=$bytes!==''?@getimagesizefromstring($bytes):false;
        $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif'][$info['mime']??'']??'';
        if(!$ext){return null;}
        return ['bytes'=>$bytes,'mime'=>$info['mime'],'name'=>'anuncio-'.substr(hash('sha256',$bytes),0,16).'.'.$ext];
    }
}
