<?php
/** Complementos idempotentes para destinos confirmados do mesmo contato. */
declare(strict_types=1);
defined('ABSPATH') || exit;
final class F3Base_Anuncio_Entrega {
    private const HOOK='f3base_anuncio_entrega';
    private static function key(string $id): string {return 'f3base_anuncio_entrega_'.$id;}
    public static function agendar(string $id,int $delay=5): void {
        if(preg_match('/^[a-f0-9]{32}$/D',$id) && !wp_next_scheduled(self::HOOK,[$id])){wp_schedule_single_event(time()+$delay,self::HOOK,[$id]);}
    }
    public static function eliminar(string $id): void {wp_clear_scheduled_hook(self::HOOK,[$id]);delete_option(self::key($id));}
    private static function salvar(string $id,array $s): void {
        if(!update_option(self::key($id),$s,false) && get_option(self::key($id),null)!==$s){throw new RuntimeException('recibo_anuncio_nao_persistido');}
    }
    public static function crm(array $lead,string $job=''): array {
        global $wpdb;$cfg=F3Base_Options::ler('f3base_pipedrive');
        if(empty($cfg['ativo']) || ($lead['classe_trafego']==='teste' && empty($cfg['homologacao']))){return [];}
        $where=$job?' AND chave=%s':'';
        $params=[F3Base_Pipedrive_Fila::tabela(),$lead['record_id']];if($job){$params[]=$job;}
        $r=$wpdb->get_row($wpdb->prepare("SELECT conta,journal,chave FROM %i WHERE record_id=%s AND estado='entregue' ".$where." ORDER BY atualizado_em DESC LIMIT 1",$params),ARRAY_A);
        $state=F3Base_Options::fotografia_bruta('f3base_pipedrive_estado')['valor']??[];
        $account=($state['dominio']??'').'|'.($state['conta_id']??'').'|'.($state['instalacao']??'');
        if(!$r || !$state || $r['conta']!==$account || ($state['dominio']??'')!==$cfg['dominio'] || !F3Base_Integracoes::pipedrive_verificado($state)){return [];}
        $opp=json_decode($r['journal'],true)['oportunidade']??[];$url=F3Base_Pipedrive_Comercial::link($opp,$cfg);
        return $url?['url'=>$url,'opp'=>$opp,'job'=>$r['chave']]:[];
    }
    public static function html(array $fields): string {
        $html='<p><strong>[IA] Anúncio de origem</strong></p>';
        foreach($fields as $key=>$v){
            $value=esc_html((string)$v);if(preg_match('~^https?://~i',$v)){$value='<a href="'.esc_url($v).'">'.$value.'</a>';}
            $html.='<p><strong>'.esc_html($key).'</strong> '.nl2br($value).'</p>';
        }return $html;
    }
    public static function consultar_ficha(): void {
        if(!current_user_can('manage_options') || !current_user_can('f3base_ler_leads')){wp_die('Sem permissão.','',['response'=>403]);}
        $id=sanitize_key(wp_unslash($_POST['record_id']??''));check_admin_referer('f3base-anuncio-'.$id);
        $lead=preg_match('/^[a-f0-9]{32}$/D',$id)?F3Base_Leads_Repositorio::obter($id):null;
        if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){wp_die('Contato indisponível.','',['response'=>404]);}
        $base=F3Base_Anuncio_Origem::base(F3Base_Contato_Apresentacao::montar($lead,false));
        if($base){
            $r=F3Base_Anuncio_Origem::resolver($base,$lead);
            set_transient('f3base_origem_ficha_'.get_current_user_id(),['id'=>$id,'vinculo'=>self::vinculo($base),'fields'=>$r['fields'],'consulta_em'=>time(),'codigo'=>$r['codigo']],300);
        }
        wp_safe_redirect(add_query_arg(['page'=>'f3base-leads','record_id'=>$id],admin_url('admin.php')).'#f3base-anuncio-origem');exit;
    }
    public static function ficha(array $a): void {
        $base=F3Base_Anuncio_Origem::base($a);if(!$base){return;}
        $s=get_option(self::key($a['record_id']),[]);
        $fields=($s['vinculo']??'')===self::vinculo($base)?($s['fields']??$base['fields']):$base['fields'];
        $view=get_transient('f3base_origem_ficha_'.get_current_user_id());
        if(is_array($view) && $view['id']===$a['record_id'] && $view['vinculo']===self::vinculo($base)){
            $fields=$view['fields'];$s['consulta_em']=$view['consulta_em'];$s['codigo']=$view['codigo'];
        }
        echo '<div id="f3base-anuncio-origem">'.wp_kses_post(self::html($fields)).'</div>';
        if(!empty($s['consulta_em'])){
            echo '<p>Última consulta em '.esc_html(wp_date('d/m/Y H:i:s P',$s['consulta_em'])).'. ';
            echo ($s['codigo']??'')==='origem_consultada'?'Criativo consultado.':'Dados parciais. Confira a conta selecionada e a concessão de leitura no plugin da plataforma. Código: '.esc_html($s['codigo']??'origem_parcial').'.';
            echo '</p>';
        }
        if(current_user_can('manage_options')){
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_anuncio_consultar"><input type="hidden" name="record_id" value="'.esc_attr($a['record_id']).'">';
            wp_nonce_field('f3base-anuncio-'.$a['record_id']);echo '<button class="button">Consultar anúncio na plataforma</button></form>';
        }
        foreach(['slack_estado'=>'Arquivo no Slack','nota_estado'=>'Nota no Pipedrive','arquivo_estado'=>'Arquivo no Pipedrive'] as $key=>$label){
            if(!empty($s[$key])){echo '<p>'.esc_html($label.' · '.$s[$key]).'</p>';}
        }
    }
    private static function vinculo(array $b): string {return hash('sha256',wp_json_encode([$b['platform'],$b['account'],$b['campaign'],$b['ad']]));}
    private static function slack(array $lead): ?array {
        global $wpdb;if($lead['classe_trafego']==='teste' && F3Base_Testes::politica('slack','teste')==='suprimir'){return null;}
        $p=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE record_id=%s AND tipo='origem' AND estado='entregue' AND destino=%s ORDER BY criada_em LIMIT 1",F3Base_Slack::tabela(),$lead['record_id'],F3Base_Slack::destino()),ARRAY_A);
        return $p && !F3Base_Slack_Manutencao::limpo($lead['record_id'])?$p:null;
    }
    private static function arquivo_slack(string $id,array &$s,array $img,string $token): void {
        if(!empty($s['slack_file'])||!empty($s['slack_bloqueado'])){return;}
        $api=static function($method,$args)use($token){
            $r=wp_remote_post('https://slack.com/api/'.$method,['timeout'=>7,'redirection'=>0,'headers'=>['Authorization'=>'Bearer '.$token],'body'=>$args]);
            return is_wp_error($r)?[]:(json_decode(wp_remote_retrieve_body($r),true)?:[]);
        };
        $ticket=$api('files.getUploadURLExternal',['filename'=>$img['name'],'length'=>strlen($img['bytes'])]);
        if(empty($ticket['ok'])){$s['slack_estado']=($ticket['error']??'')==='missing_scope'?'Permissão files:write ausente':'Reserva de arquivo pendente';return;}
        $url=$ticket['upload_url']??'';$fid=$ticket['file_id']??'';
        if(!preg_match('~^https://files\.slack\.com/upload/v1/[^\s]+$~D',$url)||!preg_match('/^F[A-Z0-9]+$/D',$fid)){return;}
        $r=wp_safe_remote_post($url,['timeout'=>8,'redirection'=>0,'headers'=>['Content-Type'=>'application/octet-stream'],'body'=>$img['bytes']]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200){return;}
        $s['slack_bloqueado']=$fid;$s['slack_estado']='Conclusão do arquivo pendente de confirmação';self::salvar($id,$s);
        $done=$api('files.completeUploadExternal',['files'=>wp_json_encode([['id'=>$fid,'title'=>'Anúncio de origem']])]);
        if(!empty($done['ok']) && in_array($fid,array_column($done['files']??[],'id'),true)){$s['slack_file']=$fid;$s['slack_estado']='Arquivo confirmado';unset($s['slack_bloqueado']);}
        elseif(isset($done['error'])){unset($s['slack_bloqueado']);$s['slack_estado']=$done['error']==='missing_scope'?'Permissão files:write ausente':'Arquivo recusado';}
        self::salvar($id,$s);
    }
    private static function criar(string $id,array &$s,string $type,string $path,array $body): void {
        if(!empty($s[$type.'_id'])||!empty($s[$type.'_incerto'])){return;}
        $s[$type.'_incerto']=true;$s[$type.'_estado']='Escrita sem confirmação';self::salvar($id,$s);
        $r=F3Base_Pipedrive_Api::pedir('POST',$path,$body);
        if(!empty($r['ok']) && ctype_digit((string)($r['data']['id']??'')) && (int)$r['data']['id']>0){$s[$type.'_id']=(int)$r['data']['id'];unset($s[$type.'_incerto']);$s[$type.'_estado']='Confirmado';}
        elseif(empty($r['incerto']) && empty($r['ok'])){unset($s[$type.'_incerto']);$s[$type.'_estado']=$r['codigo'];}
        self::salvar($id,$s);
    }
    private static function pipedrive(string $id,array &$s,array $crm,array $fields,?array $image): void {
        if(isset($s['crm_job']) && $s['crm_job']!==$crm['job']){return;}
        $s['crm_job']=$crm['job'];$opp=$crm['opp'];$object=$opp['tipo']==='lead'?'lead':'deal';$target=[$object.'_id'=>$opp['id']];
        $body=['content'=>self::html($fields),'pinned_to_'.$object.'_flag'=>1]+$target;
        $hash=hash('sha256',$body['content']);F3Base_Pipedrive_Api::iniciar_lote();
        $cfg=F3Base_Pipedrive_Api::configuracao_lote();
        if(F3Base_Pipedrive_Comercial::link($opp,$cfg)!==$crm['url']){return;}
        if(empty($s['nota_id'])){
            self::criar($id,$s,'nota','v1/notes',$body);
            if(!empty($s['nota_id'])){$s['nota_hash']=$hash;}
        }elseif(($s['nota_hash']??'')!==$hash){
            $r=F3Base_Pipedrive_Api::pedir('PUT','v1/notes/'.$s['nota_id'],['content'=>$body['content'],'pinned_to_'.$object.'_flag'=>1]);
            if(!empty($r['ok']) && (int)($r['data']['id']??0)===$s['nota_id']){$s['nota_hash']=$hash;}
        }
        if($image && !empty($s['nota_id'])){self::criar($id,$s,'arquivo','v1/files',$target+['file'=>$image]);}
    }
    public static function executar(string $id): void {
        if(!preg_match('/^[a-f0-9]{32}$/D',$id)){return;}
        if(!F3Base_Recuperacao::entrar()){self::agendar($id,3600);return;}
        $lock=F3Base_Trava::adquirir('anuncio-entrega-'.$id,180);if(!$lock){F3Base_Recuperacao::sair();self::agendar($id,210);return;}
        try{
            $recovery=F3Base_Recuperacao::ler();if(empty($recovery['ok'])||!empty($recovery['pausado'])){self::agendar($id,3600);return;}
            $lead=F3Base_Leads_Repositorio::obter($id);
            if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||F3Base_Formulario_Antispam::aviso_barrado($lead)){self::eliminar($id);return;}
            $a=F3Base_Contato_Apresentacao::montar($lead,false);$base=F3Base_Anuncio_Origem::base($a);
            if(!$base){return;}
            $p=self::slack($lead);$crm=self::crm($lead);if(!$p && !$crm){return;}
            $s=get_option(self::key($id),[]);$binding=self::vinculo($base);
            if(isset($s['vinculo']) && $s['vinculo']!==$binding){return;}$s['vinculo']=$binding;
            if(isset($s['geracao']) && $s['geracao']!==($recovery['geracao']??0)){return;}
            $s['geracao']=$recovery['geracao']??0;
            $s['inicio']??=time();$s['tentativas']=($s['tentativas']??0)+1;
            // Próxima passagem também recupera a interrupção entre escrita remota e recibo.
            if(time()-$s['inicio']<30*DAY_IN_SECONDS){self::agendar($id,min(DAY_IN_SECONDS,300*2**min(8,$s['tentativas']-1)));}
            $r=F3Base_Anuncio_Origem::resolver($base,$lead);
            $fields=array_replace($s['fields']??[],$r['fields']);$s['fields']=$fields;$s['consulta_em']=time();$s['codigo']=$r['codigo'];
            $needImage=($p && empty($s['slack_file'])) || ($crm && empty($s['arquivo_id']));
            $img=$needImage?F3Base_Anuncio_Origem::imagem($r['media']):null;
            // Revalidar o contato e os destinos após a leitura do fornecedor.
            $lead=F3Base_Leads_Repositorio::obter($id);
            if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||F3Base_Formulario_Antispam::aviso_barrado($lead)){return;}
            $fresh=F3Base_Contato_Apresentacao::montar($lead,false);$updated=F3Base_Anuncio_Origem::base($fresh);
            if(!$updated || self::vinculo($updated)!==$binding || !empty(F3Base_Recuperacao::ler()['pausado'])){return;}
            $p=self::slack($lead);$crm=self::crm($lead);$edited=true;
            if($p && (!isset($s['slack_destino'])||$s['slack_destino']===$p['destino'])){
                $s['slack_destino']=$p['destino'];$token=F3Base_Segredos::abrir(F3Base_Slack::SEGREDO);
                if($img && $token){self::arquivo_slack($id,$s,$img,$token);}
                $m=F3Base_Slack_Thread::mensagens($fresh,[],$fields,$s['slack_file']??null,empty($s['slack_file'])?($s['slack_estado']??''):'');
                $edited=isset($m[2])&&F3Base_Slack_Thread::editar($p,$m[2]);
            }
            if($crm){self::pipedrive($id,$s,$crm,$fields,$img);}
            self::salvar($id,$s);
            $noteOk=!$crm || (!empty($s['nota_id']) && ($s['nota_hash']??'')===hash('sha256',self::html($fields)));
            if($r['complete'] && $edited && $noteOk && (!$r['media'] || ((!$p||!empty($s['slack_file'])) && (!$crm||!empty($s['arquivo_id']))))){wp_clear_scheduled_hook(self::HOOK,[$id]);}
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
}
