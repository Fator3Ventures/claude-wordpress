<?php
/** Outbox do retorno comercial. Usa a thread já autorizada; não cria canal/destino. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Pipedrive_Retorno {
    public static function processar(): array {
        global $wpdb;$table=F3Base_Pipedrive_Fila::tabela();$cfg=F3Base_Options::ler('f3base_pipedrive');
        if(empty($cfg['ativo'])){return array('ok'=>true,'processados'=>0);}
        $scope=F3Base_Caminho_Lead::filtro_fila($table);$rows=$wpdb->get_col($wpdb->prepare("SELECT chave FROM %i WHERE estado='entregue' AND lease='' AND JSON_UNQUOTE(JSON_EXTRACT(journal,'$.comercial_versao'))='1.37.0' AND (JSON_EXTRACT(journal,'$.retorno_slack') IS NULL OR JSON_UNQUOTE(JSON_EXTRACT(journal,'$.retorno_slack.estado')) IN ('pendente','enfileirado')) AND (JSON_EXTRACT(journal,'$.retorno_slack.proxima') IS NULL OR CAST(JSON_UNQUOTE(JSON_EXTRACT(journal,'$.retorno_slack.proxima')) AS UNSIGNED)<=%d) {$scope} ORDER BY atualizado_em,chave LIMIT 10",$table,time()));$n=0;
        foreach($rows?:array() as $key){if(!F3Base_Pipedrive_Fila::travar_linha($key)){continue;}
            try{$j=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',$table,$key),ARRAY_A);if(!$j||$j['lease']!==''||$j['estado']!=='entregue'){continue;}$raw=$j['journal'];$x=json_decode($raw,true)?:array();$lead=F3Base_Leads_Repositorio::obter($j['record_id']);$old=$x['retorno_slack']??array();$tries=(int)($old['tentativas']??0)+1;
                $account=explode('|',$j['conta'])[0];$activity=$x['atividade_estado']??array();
                if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){$r=array('estado'=>'cancelado','codigo'=>'contato_eliminado');}
                elseif($account!==($cfg['dominio']??'')){$r=array('estado'=>'cancelado','codigo'=>'conta_alterada');}
                elseif($lead['classe_trafego']==='teste'&&empty($cfg['homologacao'])){$r=array('estado'=>'suprimido','codigo'=>'teste_sem_homologacao');}
                elseif(in_array($activity['estado']??'',array('pendente','incerta'),true)&&(int)($activity['tentativas']??0)<3){$r=array('estado'=>'pendente','codigo'=>'aguarda_atividade');}
                else{$opp=$x['oportunidade'];$url=F3Base_Pipedrive_Comercial::link($opp,$cfg);$plan=$x['atividade_plano']??array();$confirmed=($activity['estado']??'')==='confirmada';
                    $deadline=$plan?($plan['prazo_local'].' — '.$plan['fuso'].($confirmed?' (confirmada no CRM)':' (prevista; atividade não confirmada)')):'Não criada para este envio: '.(($activity['codigo']??'')==='atividade_desligada'?'atividade desabilitada':'oportunidade existente; atividade anterior preservada');
                    $sections=array('Entrega comercial'=>array($opp['tipo']==='lead'?'Lead no Pipedrive':'Negócio no Pipedrive'=>$url,'Atividade'=>$plan['subject']??'Sem nova primeira atividade do lead','Prazo da primeira atividade do lead / atividade'=>$deadline));
                    $ctx=F3Base_Pipedrive_Fila::contexto($lead);$service=F3Base_Pipedrive_Comercial::servico($ctx,$cfg);if($service['aviso']!==''){$sections['Qualidade']=array('Serviço'=>$service['aviso']);}
                    F3Base_Anuncio_Entrega::agendar($lead['record_id']);
                    $r=F3Base_Slack::retorno_pipedrive($lead,$key,$sections,$url);
                }
                $state=$r['estado'];if($state==='pendente'&&$tries>=144){$state='esgotado';}
                $x['retorno_slack']=array('estado'=>$state,'codigo'=>$r['codigo'],'tentativas'=>$tries,'em'=>time(),'proxima'=>time()+60,'parte'=>$r['parte']??'');
                $wpdb->update($table,array('journal'=>wp_json_encode($x),'atualizado_em'=>time()),array('chave'=>$key,'journal'=>$raw,'lease'=>'','estado'=>'entregue'));$n++;
            }finally{F3Base_Pipedrive_Fila::liberar_linha($key);}
        }return array('ok'=>!$wpdb->last_error,'processados'=>$n);
    }
}
