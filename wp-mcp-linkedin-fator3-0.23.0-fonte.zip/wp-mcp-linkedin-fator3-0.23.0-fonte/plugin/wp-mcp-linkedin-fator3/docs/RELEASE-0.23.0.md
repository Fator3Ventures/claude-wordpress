# Notas da versão 0.23.0
Pedidos MCP LinkedIn 25. Trocar ou revogar a credencial MCP usada para configurar o consumidor não interrompe uma concessão ativa do site. A regra vale também para concessões gravadas na 0.22.0, sem regravação. O administrador concedente precisa conservar manage_options. Consulte CONCESSOES.md para o diagnóstico e as condições de parada. A política do transporte continua aplicada a cada chamada humana.

Migração direta de 0.22.0, sem alterar banco, revisão, destino nem diário. WordPress 7.1.4+, PHP 8.3+ 64 bits. Referências da rodada: Site Core 1.85.1, MCP 0.45.0, Google 0.34.0, Meta 0.25.0 e Pipedrive 0.10.0. Nenhuma nova credencial, assinatura ou ingestão é ativada.
