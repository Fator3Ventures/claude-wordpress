# Release 0.17.1 — coerência documental

A validação documental no Site-Teste da intermediária 0.17.0 encontrou a versão corrente antiga no README e cabeçalhos antigos em manuais correntes. Este patch corrige essas referências; as funcionalidades e os contratos dos pedidos 18, 21, 22 e 23 descritos em RELEASE-0.17.0.md permanecem iguais.

Atualize diretamente da base aceita 0.16.0 ou da intermediária 0.17.0. Não é necessário instalar a intermediária. Não há migração SQL nova, ampliação de permissões ou mudança em outros pacotes. O instalador da 0.17.0 usado no Site-Teste permanece imutável; esta entrega tem nova identidade. As provas de fornecedor real seguem pendentes e distintas das fixtures.
