# Administração pelo painel — 0.23.0

Abra Ferramentas → Fator3 MCP LinkedIn com uma conta administrativa. As seis seções agrupam as tarefas abaixo. Endereços antigos que já usavam `tab=` continuam abrindo o painel correspondente.

| Seção | Tarefa e resultado |
|---|---|
| Conexões | Busque por nome ou identificador e percorra a lista em páginas de 20. Abra uma conexão para editar, ou crie um rascunho. Em Ativos, selecione Páginas, contas e formulários que a conexão pode usar. |
| Concessões | Configure separadamente o acesso do consumidor aos formulários, às conversões de aquisição e às etapas comerciais. O consumidor só recebe a seleção autorizada. |
| Dados | Relatórios, Coletas e Histórico compartilham a seleção de conexão, canal, ativo e datas. Consultar uma página não cria uma agenda; criar uma agenda guarda a consulta selecionada. |
| Anúncios e publicações | Escolha o destino, prepare os campos e confira a prévia antes de confirmar. A operação final pode alterar o LinkedIn. Use o diário para reconciliar efeitos incertos. |
| Manutenção | Diagnóstico consulta o estado local, a retenção controla o prazo da auditoria e a validação de ativo consulta o fornecedor quando solicitada. Alterar a versão da API exige revisar as concessões. |
| Ajuda | Escolha um manual, um schema ou o histórico. O texto é local. Pelo MCP, o índice também informa tamanho e SHA-256. |

## Editar uma conexão

Use **Nova conexão** para começar. Para OAuth, confira o endereço de retorno e cadastre-o no aplicativo; para token manual, informe Client ID, segredo e token. Um campo secreto vazio preserva o valor salvo. Para excluir um valor use a ação específica. Guarde datas e horas em UTC. Para preparar o cadastro sem token, salve pausado.

A simulação informa o efeito da mudança. Ela também é necessária para alterar o prazo de aviso, a seleção automática de formulários ou a identidade sem agenda nem concessão. Use **Simular alterações**, confira a prévia e use **Confirmar alterações**. Depois de mudar o rascunho, simule de novo. Confira o resultado ao lado da ação e volte à lista quando terminar.

## Fluxo de consulta e recuperação

Em Dados, escolha a conexão e o canal antes do ativo; a seleção de uma Página tem significado diferente da seleção de uma conta de anúncios. Em Coletas, confira estado, cursor e próxima execução antes de retomar. Em Manutenção, diagnosticar e verificar acesso ao fornecedor são ações distintas. Uma mensagem de recusa identifica o próximo ajuste; não repita uma gravação com resultado externo incerto. Veja OPERATIONS.md e TROUBLESHOOTING.md.

## Permissão para ler o anúncio de origem

Em Concessões → Formulários, selecione o consumidor e a conta permitida, marque a permissão de origem dos anúncios e confirme a simulação. Para partir de um lead, conceda também leitura de respostas e selecione o formulário. AD-SOURCE.md explica a abrangência por conta.
