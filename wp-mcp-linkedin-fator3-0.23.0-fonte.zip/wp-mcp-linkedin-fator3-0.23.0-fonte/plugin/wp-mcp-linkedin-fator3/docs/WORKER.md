# Coletas e worker — 0.23.0

O worker avança coletas agendadas; o diagnóstico informa o estado sem acionar o processamento.

## Fila indexada (schema 2)

A tabela `wp_f3_linkedin_records` recebe as colunas `queue_state` e `queue_next` e o índice `runnable(bucket,queue_state,queue_next,record_key)`. A mesma instrução CAS grava o payload cifrado e a projeção técnica. O worker seleciona até 20 coletas `queued`/`retry` vencidas por duas buscas indexadas; coletas concluídas não são percorridas. Antes da 0.8.0 o worker lia 20 registros históricos por passagem a partir de um cursor: com milhares de coletas concluídas, uma coleta nova esperava dezenas de passagens.

Migração: registros da 0.7.0 são projetados em lotes de 100 no bootstrap (`plugins_loaded`, prioridade 11) e nas passagens do worker, sem alterar ciphertext, revisão, datas ou retenção. Depois de confirmada, a marca `f3_linkedin_queue_settled=2` (autoload) dispensa a consulta; `f3_linkedin_schema` passa ao autoload na primeira requisição. Resultado: nenhuma consulta SQL própria do pacote no carregamento de uma requisição comum. Registro que a chave atual do site não abre recebe `queue_state=unreadable`: não é executado nem apagado, não bloqueia os demais, sai da seleção da retenção e aparece como `queue_record_unreadable`.

## Retentativa da mesma ocorrência

Ao preparar uma ocorrência, `busy` ou `storage_unavailable` mantém a agenda habilitada e o horário original (`next_at`). A próxima tentativa é permitida a partir de cinco minutos após a falha (`retry_not_before`), na próxima passagem efetiva do worker. A chave de coleta é calculada com o horário original: se a coleta já existe, a retomada a reutiliza. Ao concluir a preparação, o worker limpa a espera e calcula a próxima ocorrência. Falha de autorização continua exigindo revisão da concessão e pode desabilitar a agenda. `linkedin/status` informa o ocorrido; consultá-lo não força uma tentativa.

## Recuperação

- A passagem do worker pré-agenda a próxima, roda sob trava de banco (`worker-pass`) e confere o evento de novo em `finally`, inclusive após exceção. Antes da 0.8.0 uma exceção na retenção ou nas agendas encerrava a cadeia sem novo evento.
- A manutenção horária `f3_linkedin_maintenance` rearma o worker antes e depois de renovar credenciais (`Credentials::tick`), migrar e aplicar retenção.
- Se a manutenção horária sumir do cron, ela é reagendada na requisição seguinte (`init`, prioridade 20, sob trava) e `f3_linkedin_maintenance_rearmed` guarda o último reagendamento.
- Tentativa e falha de agendamento ficam em `cron_worker.last_schedule_attempt/last_schedule_failure`.

WP-Cron depende de tráfego ou do cron do servidor; a recuperação acontece na próxima passagem efetiva.

## Diagnóstico em `linkedin/status`

`linkedin/status` continua de leitura (mode=read, perfil read do MCP); como toda operação despachada, grava só a linha de auditoria local. Mantém os campos da 0.7.0 e acrescenta: `state` (ok/degraded), `observed_at`, `issues[]`, `active_schedules`, `worker_required`, `queue` (`oldest_due_at`, `oldest_due_lag_seconds`, `migration_pending`, `unreadable_jobs`, `migration`), `cron_worker`, `maintenance` e `repair=not_attempted`. Não rearma eventos nem envia e-mail.

| Código | Significado e ação |
|---|---|
| `worker_missing` | Há agenda ativa ou coleta pendente sem evento do worker. A manutenção horária rearma; confira o cron do servidor. |
| `schedule_retry_pending` | Uma trava ocupada (`busy`) ou falha transitória de banco (`storage_unavailable`) adiou a preparação da ocorrência. A agenda continua habilitada. Verifique `last_code`, `retry_not_before` e o banco se o aviso persistir. |
| `schedule_overdue` | Agenda vencida há mais de dois intervalos. Confira o cron e a autorização. |
| `schedule_authorization_failed` | A última coleta da agenda foi recusada por autorização. Salve a agenda novamente com a concessão atual. |
| `queue_migration_pending` | Migração da fila em andamento. |
| `queue_record_unreadable` | Coleta cifrada ilegível com a chave atual; confira os salts do wp-config. |
| `connection_without_token` | A conexão está ativa e sem token. Configure o acesso ou pause-a; o diagnóstico preserva os dados. |
| `maintenance_missing` | Manutenção horária ausente; é recriada na próxima requisição. |

## Operação e recuperação

A atualização preserva a fila indexada, agendas e recibos. Em falha, confira o estado local, pause o fluxo afetado e conserve o checkpoint para retomada na versão corretiva.

## Coleta ilegível depois da migração

Uma coleta já indexada pode tornar-se ilegível depois da migração. Ao detectar `cipher_unreadable` ou `storage_corrupt` na leitura da própria coleta, o worker a isola como `unreadable`, sob a trava `job:<id>`, antes de continuar. Somente queue_state/queue_next mudam: payload, revisão, datas e retenção ficam intactos. Ela deixa as primeiras posições da fila e libera as coletas válidas. Falha de conexão, armazenamento ou resultado filho não classifica o pai como ilegível. Uma coleta válida com resultado filho ilegível mantém a pausa normal de execução.

O status relata `schedule_job_unreadable` quando o último job de uma agenda não pode ser lido, e continua retornando o restante do diagnóstico. A leitura não marca nem corrige o registro. `schedule_authorization_failed` continua visível quando a falha de autorização desabilitou a agenda; não conta como agenda ativa nem a reativa. A ação permanece conferir a conexão e salvar a agenda com autorização válida.

## Isolamento concorrente

Worker, migração e retenção usam `Queue::isolateUnreadable`. A rotina obtém `job:<id>`, relê e decodifica o mesmo snapshot cifrado e somente marca `unreadable` por UPDATE condicionado à revisão e à igualdade binária do payload. A trava é consultiva; o CAS também protege contra gravadores que não a utilizam. Registro legível, ausente, já isolado ou alterado durante a verificação não é reescrito. Na migração/retenção, trava ocupada adia o registro; erro SQL propaga `storage_unavailable`. O isolamento preserva ciphertext, revisão, datas e expiração e altera apenas `queue_state` e `queue_next`. Não reativa registros antigos automaticamente.
