# Instalação e atualização — 0.23.0

Instale em WordPress 7.1.4 ou superior, PHP 8.3 ou superior. Para migrar da 0.22.0, atualize o mesmo plugin preservando banco, sais e configurações. O schema físico permanece 2. Conexões sem token já existentes são mantidas e sinalizadas. Concessões, agendas, cursores e resultados incertos não são reativados nem apagados.

Confirme `linkedin/status`, `linkedin/selftest` e a versão da documentação em uma nova requisição. Leia RELEASE-0.23.0.md. Consulte um registro de cada tipo já usado, respeitando a seleção e os escopos. Só execute uma validação remota com credencial e ativo autorizados. Se uma falha afetar um fluxo, contenha-o, preserve estado e recibos e aplique a correção em nova versão. Não repita efeitos incertos antes da reconciliação.
