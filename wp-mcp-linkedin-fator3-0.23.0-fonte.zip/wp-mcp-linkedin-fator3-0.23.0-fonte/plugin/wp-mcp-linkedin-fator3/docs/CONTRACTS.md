# Contratos públicos — 0.23.0

## Leitura pelo transporte MCP

O LinkedIn mantém os campos do SDK e do REST. Quando o transporte filtrar nomes sensíveis, use as projeções públicas abaixo, dentro de `data`. Nenhuma delas contém um segredo ou texto livre do fornecedor.

| Operação | Campo público | Tipo e significado |
|---|---|---|
| `configuration-schema` | `input_method`, `blank_keeps_existing` | Texto fixo `manual_token` e booleano `true`: o campo vazio conserva o segredo existente. |
| `status` | `maintenance.last.renewal_result` | Ausente antes da primeira manutenção ou nulo sem resultado. Valores publicados: `ok`, `busy`, `storage_unavailable`, `storage_corrupt`, `cipher_unreadable`, `internal_error`, `other_failure`. |
| `capabilities` | `local_sdk.features.dispatch_checks_access` | Booleano: o despachante local verifica acesso. |
| Conexão pública e `status.access_lifecycle.connections[]` | `notice_days` | Antecedência de aviso em dias, inteiro entre 1 e 365. |

## Entradas e respostas

Namespace REST preservado: `/wp-json/f3-linkedin/v1/{operation}`, POST JSON autenticado. Cookie administrativo exige nonce REST; credenciais MCP também passam pela política do transporte. Abilities preservam prefixo `linkedin/`. Consulte `contracts` e `input-schemas.json`; todos os objetos de entrada são fechados e parâmetros desconhecidos são recusados. IDs remotos são strings, não números de ponto flutuante.

Envelope: `success`, `code`, `provider`, `version` e `data` em sucesso. Falha: `error_code`, `message`, `conflict`, `retryable`, `details`, `data=null`. Um sucesso local não implica homologação externa. `not_authorized` é HTTP 403 em REST; os demais códigos de domínio usam envelope estruturado.

Relatórios mantêm contrato social-reporting/1.0.0; Meta estende para social-reporting/1.1.0 com linhas diárias e disponibilidade. Nenhum campo anterior é removido. Preserve seleção e next_cursor até esgotar. `coverage.complete` exige fim do plano e nenhuma indisponibilidade registrada; `all_rows_guaranteed` pode ser null. Inventário completo da resposta não comprova todo o histórico remoto.

Revisões são obrigatórias para configuração, agendas, concessões e controle de tarefas. Chaves idempotentes locais têm no máximo 64 caracteres; o transporte pode ter limites próprios. Não reutilize uma chave para outra intenção. Listagens administrativas usam `offset` e `next_offset`; get-connection/get-grant permitem releitura de uma configuração precisa. A falta de uma página não autoriza inferir que os outros registros não existem.

Na 0.19.0, `validate-connection` conserva a entrada, o envelope e os campos de sucesso. `data.revision` identifica a configuração lida; a validação bem-sucedida grava a prova do ativo sem incrementar essa revisão. O contador não serve para contar validações. Em mudança concorrente de configuração/credencial, releia a conexão após `revision_conflict`. As 99 operações e contratos dos consumidores permanecem os mesmos.

Erros estáveis incluem invalid_input, not_authorized, asset_access_denied, revision_conflict, credential_revalidation_required, rate_limited, upstream_error, operation_uncertain, history_changed, response_limit, storage_unavailable e persistence_unconfirmed. Não trate resultado incerto como autorização para reenviar uma mutação.

## Opções administrativas (`admin-options`)

`linkedin/admin-options` exige administrador em painel, REST e MCP. `kind=users` lista nomes locais (50 por página, `offset/next_offset`, busca por nome/login ou até 100 IDs selecionados). Não retorna e-mail nem credencial. Os demais tipos exigem conexão e canal: `assets` usa descoberta com cursor assinado; `selected` resolve nomes de até 10 ativos já permitidos por página; `objects` projeta nome/ID de mídias, publicações, vídeos (Meta) ou campanhas (LinkedIn); `forms` e `journal` são exclusivos do LinkedIn. Formulários exigem conta selecionada e proprietário remoto idêntico. Diário mostra somente operações administrativas locais comprovadas pelo SDK; não adota recibos de consumidores.

Listas de nomes não alteram seleção. Falha de obtenção de nome deixa `name=null`, `name_status=unavailable` e motivo; resposta bem-sucedida de metadados não homologa relatórios. `connection_revision` identifica a revisão lida; alterações concorrentes invalidam a resposta. Os esquemas instalados enumeram todas as entradas. O limite por requisição continua Meta 40 / LinkedIn 15 e 25 segundos; descoberta LinkedIn pede 10 contas para comportar leitura de nomes.

`save-schedule` aceita `label` (até 120 caracteres) e `next_at` (Unix UTC) opcionais. Sem `next_at`, preserva o valor anterior; agenda nova usa agora + 60 segundos. Mantém último job e código. A interface não altera a consulta ao editar agenda: para consulta diferente, crie outra agenda. Contratos públicos de relatórios e Lead Reader não mudaram.

## Gestão e ciclo de credenciais

Gestão usa linkedin-management/1.0.0 e schemas exatos de input-schemas.json. Leia MANAGEMENT.md para request_key/confirm_token, revisões e fases. O limite de 15 chamadas citado para leituras permanece; novas mutações dispõem de 30 chamadas REST, 25 segundos. Credenciais usam access_lifecycle no status; consent_url é o endereço público da autorização. Esses nomes não removem filtros de segredo do transporte.

O evento linkedin-mutation/1.0.0 integra o contrato público mutation-audit/1.0.0 do MCP por descritor explícito. O MCP guarda referência e lê snapshots autorizados pelo leitor do LinkedIn. Não há alteração do SDK Lead Reader 1.0/1.1.

## Conversions API e auditoria central
Seis operações descritas em CONVERSIONS.md e schemas completos gerados em input-schemas.json. O descritor mutation-audit/1.0.0 é registrado pelo hook f3_mcp_register_mutation_audit. central_audit informa registered/unavailable/not_registered; serviço CAPI informa service_principal_unsupported. O erro do fornecedor mantém código estável e acrescenta details.provider_message sanitizada e details.serviceErrorCode. Total de seguidores usa o enum vigente COMPANY_FOLLOWED_BY_MEMBER.

## Auditoria de serviço
Leitor linkedin/get-service-write-operation com identidade fechada de cinco campos; funções PHP f3_linkedin_service_audit_descriptor e f3_linkedin_introspect_service_grant; evento linkedin-service-mutation/1.0.0. Contrato de domínio mutation-service-audit/1.0.0 implementado; handshake central ainda proposto ao MCP, sem consumidor no 0.27.0. Introspecção/leitura são locais e sem escrita. Veja SERVICE-AUDIT.md para schemas semânticos, hash canônico, revogação e exemplos.

## Diagnóstico e estado (`status`, `diagnose-conversions`)

- Nova `linkedin/diagnose-conversions` (entrada fechada com `conversion_id` opcional, string numérica): ver CONVERSIONS.md. mode=read, local_effect=none, remote_effect=none.
- `linkedin/status` acrescenta `state`, `observed_at`, `issues`, `active_schedules`, `worker_required`, `queue`, `cron_worker`, `maintenance` e `repair`; os campos da 0.7.0 permanecem. Continua somente leitura.
- `linkedin/audit` aceita `since` opcional (inteiro ≥ 0, Unix em segundos) e devolve `order=newest_first` e `since`.
- Hook `f3_linkedin_register_consumers`: mesmo nome e argumento; disparo em `init` (1).
- Schema SQL 2 (colunas `queue_state`, `queue_next`, índice `runnable`). Demais operações, schemas e envelopes iguais aos da 0.7.0.
- `linkedin/documentation`: o teto de `offset` passa de 100000 para 16777216 bytes. Antes, um documento maior que 100 KB (o `input-schemas.json` do LinkedIn tem cerca de 117 KB) não podia ser lido até o fim em páginas pequenas pela operação.
- Auditoria e efeitos: toda operação despachada pelo painel, REST, ability ou MCP grava uma linha no registro de auditoria local (bucket `audit`, retenção configurável, padrão sem prazo desde 0.11.0 (HISTORY.md)) e atualiza `f3_linkedin_audit_health` quando muda; `documentation` e `get-service-write-operation` são as exceções. `local_effect` descreve o estado operacional (configuração, concessões, credenciais, fila, agendas, diários) e não conta essa linha: `none` significa que nada disso muda. Vale para `status` e `diagnose-conversions`.

## Aviso de vencimento e escopos OAuth

Histórico: 0.14.0 mantinha 93 operações. save-connection adiciona credential_notice_days; mudança de política requer dry_run/confirmation. oauth-start admite até 11 escopos conhecidos. audit/status acrescentam diagnóstico/ação/recibos descritos em CREDENTIALS.md. Naquela entrega, os contratos comerciais/Lead Reader e descritores MCP não mudaram.

Lead Reader 1.2 é aditivo; seleção automática, eventos e webhook estão em LEAD-DISCOVERY.md. Normalização compartilhada de textos e efeito de preflight estão em SDK-PHP.md. Encerramento explícito e estado rejected em MANAGEMENT.md. `close-write-operation` é escrita local sem efeito remoto; descoberta automática pode criar webhook, sem contato ou conversão comercial.

## Anúncio vinculado à origem

A extensão linkedin-ad-source/1.0.0 está disponível pelo SDK e por linkedin/lead-resolve-ad-source. Consulte AD-SOURCE.md para o schema de saída, os modos de entrada e o tratamento dos endereços temporários.

A resposta paginada de linkedin/status está descrita em CONCESSOES.md.
