# Alterações

## 0.23.0

Pedido 25: autorização local de consumidores e diagnóstico paginado das concessões. Veja CONCESSOES.md.

## 0.22.0

Vínculo do formulário e validade de mídia no anúncio de origem. Leia RELEASE-0.22.0.md.

## 0.21.0

Leitura do anúncio de origem, com mídia temporária e integração de formulários nativos.

## 0.20.0

Conexões, auditoria, autorização de escrita, navegação e ajuda: consulte RELEASE-0.20.0.md.

## 0.19.0

- O diagnóstico distingue leitura local de validação no provedor, resume o resultado atual e ignora respostas atrasadas. O estado das credenciais é lido em lote.
- Validar um ativo registra a prova local sem alterar a revisão de configuração nem invalidar concessões vigentes.
- A prévia de gestão conserva o rascunho, só habilita a ação para o destino e os dados revisados e apresenta o efeito da confirmação. A leitura explícita volta a preencher orçamentos e lance na moeda da conta.
- A agenda preserva a ocorrência após falha transitória de banco ou trava. Veja WORKER.md, MIGRATION.md e RELEASE-0.19.0.md.

## 0.18.0

Configuração reorganizada e acessível; paginação completa e consultas de conexões em lote; confirmações ligadas ao estado revisado; guias e requisitos vigentes. Consulte RELEASE-0.18.0.md.

## 0.17.1

- Corrige referência à versão corrente no README e cabeçalhos dos manuais instalados.
- Preserva integralmente o comportamento funcional da intermediária 0.17.0 validada.

## 0.17.0

Pedidos 18(g/h), 21(d/e/f), 22 e 23: listagem local de intenções, adoção de assinaturas confirmadas, descoberta de até cinco formulários por tarefa, concessões por domínio e retry GET específico sem projeção. Veja RELEASE-0.17.0.md.

## 0.16.0

- Projeção dos metadados opcionais e vínculo validado de campanha nas respostas do Lead Sync.
- Extensão pública linkedin-lead-campaign/1.0.0, resolve_campaign, 98 operações e permissão opcional campaign_lookup com prévia.
- Ausência, inconsistência, autorização e falha transitória distinguíveis; leitura de lead preservada.
- Integração Core 1.68.0 e atualização direta da 0.15.0; sem migração ou ampliação de grants.

## 0.15.0

- Pedido 18: rejeição terminal 4xx de criação sem recibo, diagnóstico, agenda obrigatória e encerramento explícito de intenção incerta; migração conservadora.
- Pedido 19: finder leadNotifications criteria/owner.value; efeito none em falhas anteriores ao POST.
- Pedido 20: trim compartilhado de respostas textuais entre getter/finder.
- Pedido 21: seleção automática opcional, contrato Lead Reader 1.2, descoberta retomável, eventos duráveis e assinatura de webhook no mesmo processamento; Core precisa adotar o consumidor.


## 0.14.0 — 31/10/2026

- Pedido 16: diagnóstico sanitizado do retorno OAuth na auditoria e tela; motivos específicos e vínculo do aplicativo/URI, com escopos existentes selecionáveis.
- Pedido 17: confirmação da primeira renovação manual visível; aviso por incidente dentro de prazo configurável, com simulação/revisão e reserva anterior ao correio.
- Base direta 0.13.0, mesmas 93 operações, sem alteração dos pacotes acompanhantes. Aceite de OAuth real depende do dono da conta.

## 0.13.0

Pedido MCP LinkedIn 15: espaços externos normalizados, internos preservados, formato como aviso junto dos campos e na resposta; controles/limites e confirmação remota mantidos. Auditoria comercial confirmada com MCP 0.36.0; sem mudança nos contratos SDK.

## 0.12.0 — 28/10/2026

Contrato comercial 1.2.0, concessões por ação, painel e três operações administrativas, diário/auditoria de serviço por consumidor. Compatibilidade 1.0.0 preservada. Leia RELEASE-0.12.0.md e STAGE-CONVERSIONS.md.

## 0.11.0 — 26/10/2026

- Pedido 14: auditoria configurável e padrão sem prazo; modo unlimited por conexão preservando escolhas finitas.
- Acervo diário cifrado para estatísticas da Página e Ads por campanha, criativo e conversão; migração, backfill limitado pela disponibilidade, consulta e exportação MCP.
- Novas abas Histórico/Retenção, prévia da política e projeção de identidade temporal.
- Conservado o isolamento concorrente de jobs ilegíveis do pedido 12. Sem alterações em outros pacotes ou documentos centrais.

## 0.10.1 — 23/10/2026

Renovação com Refresh Token manual e identidade não comprovável exige candidata e confirmação; não troca silenciosamente o membro ativo.

## 0.10.0 — 23/10/2026

Pedido 13: conferir credenciais antes de gravar; identidade salva com origem; troca guiada; agendas e concessões vigentes rebaseadas atomicamente, preservação de identidade de auditoria em alteração da mesma autorização. Ver RELEASE-0.10.0.md e CREDENTIALS.md.

## Bloco histórico: Alterações — 0.10.0

## 0.9.0 — pedido 12

- Isolamento de jobs ilegíveis centralizado para worker, migração e retenção.
- Releitura sob `job:<id>` e UPDATE condicionado à revisão e ao ciphertext exato, protegendo reparos concorrentes.
- Bloqueio ocupado adia o registro; falhas de armazenamento permanecem explícitas. Payload, revisão, datas e expiração são preservados.
- Schema 2, 81 abilities e contratos SDK mantidos. Atualização direta da 0.8.1.

## 0.8.1 — revisão independente

- Coletas ilegíveis já indexadas deixam de bloquear a fila; isolamento sob trava sem alterar conteúdo cifrado.
- Diagnóstico conserva resposta e aviso quando a última coleta está ilegível ou a agenda foi desabilitada por autorização.
- Prontidão CAPI recusa prova vigente conhecida inativa/expirada, sem rede ou reparo.
- Sete verificações de regressão e proteção, atualização direta 0.8.0 e preservação de schema 2.

- M1: fila de coletas indexada (schema 2), worker com trava, rearme garantido e recuperação horária; `linkedin/status` com `state`, `issues`, `queue`, `cron_worker` e `maintenance`, somente leitura.
- M2: registro de consumidores em `init` (1), antes do WP-Cron; elimina o carregamento antecipado de traduções do Site Core.
- M3: manutenção horária recriada quando ausente.
- M4: `linkedin/diagnose-conversions`, diagnóstico local de requisitos do envio de conversões (sem HTTP; grava só a linha de auditoria, como toda operação despachada).
- M5: `linkedin/audit` do mais recente com `since`; `list-connections` com uma leitura; retenção exclui registro ilegível da seleção; marcas de bootstrap em autoload (nenhuma consulta SQL própria por requisição).
- Leitura documental: teto de `offset` de `linkedin/documentation` elevado a 16 MiB; documentos acima de 100 KB passam a ser lidos até o fim com páginas pequenas.
- M6: testes com acompanhantes atuais e matriz mínima WordPress 6.4/PHP 8.1.2.

## Histórico 0.7.0


- Pedido 8(d): descritor/introspector PHP, leitor administrativo e evento separados para serviço.
- Referências opacas por concessão/revisão, conferência antes do POST, gates atuais e recibo central por hash.
- Replay preserva identidade sem reenvio/novo evento; falha central não altera entrega confirmada.
- MCP 0.27.0 não implementa o consumidor; integração conjunta permanece pendente.

## Histórico 0.6.0

## Bloco histórico: Alterações — 0.6.0
- Pedidos 8–11: CAPI com concessão site-core-conversions, regra API, leitura local de prontidão, envio unitário/lote, prévia humana e diário sem PII.
- follower_total usa COMPANY_FOLLOWED_BY_MEMBER; recusas trazem provider_message sanitizada e serviceErrorCode.
- Registro explícito mutation-audit/1.0.0 no MCP 0.26.1; estado detectado.
- Campos com nomes do LinkedIn, caminhos, links e retorno OAuth pronto para copiar; erros distinguem Access Token do par Client ID / Primary Client Secret.
- Limites: regra única browser/API exigida pelo Core 1.47.0 diverge da orientação do fornecedor; serviço background sem identidade humana não é admitido pelo Registro central atual. Nenhuma regra externa é transformada automaticamente.

## Histórico anterior (não representa limites atuais)

## Bloco histórico: Alterações — 0.5.0

- Pedido 5: rótulos e descrições em português para todas as abilities; 42 IDs originais preservados.
- Pedido 6: gestão Ads/Páginas, prévia, confirmação, revisão, chave idempotente, trava e diário/reconciliação. Criação Ads DRAFT; ativação separada; pesquisa de segmentação por nome; nova aba administrativa sem JSON.
- Pedido 7: refresh cifrado, manutenção automática, incidentes/avisos, introspecção e OAuth opcional com retorno local. Renovação preserva revisão de autorização; reautorização exige reconfirmação.
- Contratos aditivos linkedin-management/1.0.0 e linkedin-mutation/1.0.0. MCP central mantém resumo até implementação do contrato de antes/depois.

## Histórico anterior, recebido com a base

## Bloco histórico: Alterações — 0.4.1

- Tradução dos rótulos e estados de diagnóstico, cobertura e concessões; campos técnicos não catalogados usam rótulo em português e conservam a chave em dica técnica. Códigos de API continuam íntegros nos contratos.
- A 0.4.0 foi um marco intermediário instalado no Site-Teste. Seus ZIPs não foram reescritos. O patch 0.4.1 segue a orientação do dono para revisões dentro do mesmo ciclo. Esta entrega atualiza diretamente 0.3.0 e 0.4.0.

## Implementação da 0.4.0

## Bloco histórico: Alterações — 0.4.0

Atualização direta da 0.3.0, sem migração de tabela ou mudança de identidade.

- LinkedIn 4: abas por assunto com URL própria; conexões locais na abertura; usuários, contas, objetos e formulários selecionados pelo nome; carregamento e falhas por seção; versão da API em Diagnóstico > configuração avançada.
- Agendas: nome, próxima execução em UTC e edição com revisão; edição preserva consulta, horário exato e último recibo quando não alterados.
- Nova operação administrativa `admin-options`, com seleção explícita e revalidação de autorização/revisão. Contratos de relatórios e SDK preservados.
- Formulários e concessões por seletores e caixas; paginação de descobertas; contas e campanhas com nomes; pivôs em português. Não muda o SDK Lead Reader 1.0/1.1 nem o cliente comercial do Core.

## Histórico da 0.3.0

## Bloco histórico: Alterações — 0.3.0

Atualização direta da 0.2.0; nenhuma migração de banco, seleção ou autorização.

- Pedido MCP LinkedIn 1: Description exata com responsabilidade do Core e local de configuração. APIs, SDK, assinaturas, autorização e armazenamento permanecem byte a byte iguais à 0.2.0.

## Histórico da 0.2.0

## 0.2.0

- Administração humana restrita a manage_options; SDK com grant explícito preservado para usuário zero.
- Índice e documentação completa paginada com SHA-256, UTF-8 e revisão.
- R3-LI-01: bloqueio persistido por recurso entre chaves, consumidores e conexões; migração de intenções 0.1.
- R3-LI-02: guarda junto ao despacho de POST/DELETE e preservação de recibo em revogação durante o envio.
- R3-LI-03: SDK 1.1, consulta/reconciliação do diário, efeito remoto e reatrelamento explícito de contexto conhecido.
- Paginação de concessões, projeções diretas e painel de consulta administrativa.
- Desinstalação conserva dados. Pages, Ads e ingestão comercial mantêm suas fronteiras.

Operação real de Lead Sync e migração do Core dependem de homologação autorizada; nenhuma assinatura real foi criada pelos testes locais.

## Notas de versões anteriores que estavam repetidas nos manuais

Os parágrafos abaixo apareciam, com o mesmo texto, em vários manuais correntes. Ficam registrados aqui uma única vez, como histórico. Contagens de operações e versões de outros pacotes citadas neles valem para a época de cada versão.

### Nota da 0.10.0

Consulte RELEASE-0.10.0.md e CREDENTIALS.md: candidata conferida antes de persistir, identidade guiada, nomes com origem explícita e agendas rebaseadas no mesmo salvamento. A configuração recebe revisão a cada gravação; authorization_revision e credential_generation distinguem autorização e credencial. Uma alteração benigna mantém o vínculo das identidades de serviço CAPI já emitidas; uma nova concessão ou identidade continua revogando o vínculo anterior. Não editar documentos recebidos de outros pacotes para responder a pedidos.

### Nota da 0.11.0

Consulte HISTORY.md: auditoria local configurável com padrão unlimited; conexões existentes preservam a política finita; o acervo diário independe da retenção dos resultados. Nove operações novas, total 90. A consulta local mantém as permissões e a partição da identidade/concessão de origem. A coleta retroativa usa janelas publicadas e não garante integralidade remota. Não alterar documentos de outros pacotes ao entregar esta versão.

### Nota da 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.35.0 passou a admitir esse consumidor; a integração foi repetida com MCP 0.36.0 e recibo central recorded. Em MCP 0.34.0 a limitação histórica permanece. Não repetir evento por falta de recibo central.

### Nota da 0.13.0

Pedido MCP LinkedIn 15: espaços externos aparados com aviso; espaços internos e heurísticas de formato são avisos por campo, com decisão remota. Controles, limites máximos, escopos, identidade, CAS e confirmação permanecem. Leia CREDENTIALS.md e RELEASE-0.13.0.md. Sucesso/prévia retornam data.warnings; erros de validação remota retornam details.warnings. Nenhum segredo aparece no aviso.

### Nota da 0.17.0

Leia RELEASE-0.17.0.md: diário de intenções com filtro/IDs completos (MANAGEMENT.md), recuperação limitada de projeção de leads (CAMPAIGN-METADATA.md), descoberta em lote e adoção de recibos próprios (LEAD-DISCOVERY.md), preservação/reconfirmação por domínio (CREDENTIALS.md). 99 operações. Falha de enriquecimento opcional não autoriza ignorar erros de acesso, quota ou identidade. Não alterar documentos centrais de outros pacotes.

