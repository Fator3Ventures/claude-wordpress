# Operação — 0.23.0

Rotina de uso, execução agendada, dados gravados, desativação e recuperação. Instalação e atualização estão em MIGRATION.md; códigos de erro, em TROUBLESHOOTING.md.

## Relatórios, coletas e exportação

- `list-fields` publica o catálogo fechado de campos de cada relatório.
- `query` lê uma página, vinculada à seleção, ao administrador e à revisão da conexão. Siga `next_cursor` até acabar. Ausência de resultado não equivale a zero.
- As estatísticas diárias de Página são percorridas em janelas de até sete dias e mantêm os campos de data e identidade mesmo quando se pedem só algumas métricas.
- `create-job`, `run-job`, `job-status`, `control-job` e `job-results` gerenciam a coleta durável. Cada passo tem orçamento de chamadas e de tempo; coletas grandes exigem várias execuções.
- As agendas criam coletas de leitura. Não ingerem respostas de formulários.
- `export` e `export-read` geram CSV ou JSON local, lido somente por chamada autenticada.

Relatórios, granularidades, agrupamentos e limites estão em `input-schemas.json`.

## Execução agendada

| Gancho de cron | Função |
|---|---|
| `f3_linkedin_worker` | Avança coletas e prepara as ocorrências das agendas. |
| `f3_linkedin_maintenance` | A cada hora: retenção, avisos e renovação de credenciais, rearmar o worker. |
| `f3_linkedin_lead_discovery` | Descoberta dos formulários de contas com seleção automática. |

Sem agendador do servidor, o WP-Cron depende de visitas ao site. Com WP-CLI, `wp f3-linkedin run` executa uma passagem do worker e `wp f3-linkedin selftest` executa o autoteste. `linkedin/status` mostra a próxima execução, a última e as pendências; a leitura de `issues` está em WORKER.md.

## Formulários de contato (Lead Sync)

O plugin oferece metadados, respostas, verificação de assinatura e gerenciamento das assinaturas próprias. As respostas preservam o conteúdo original e `submitted_at_ms` com 13 dígitos; o plugin não converte milissegundos nem cadastra contatos. Receber a notificação, persistir antes de confirmar o recebimento, deduplicar e ingerir pertencem ao consumidor. A validação do HMAC não grava recibo de entrega.

### Diário de assinaturas

O bloqueio persistido considera owner, leadType e formulário versionado. Callback é preservado na intenção, mas não permite contornar bloqueio do mesmo recurso. Conexão, consumidor, revisão ou nova chave idempotente não liberam uma intenção pendente. Um bloqueio nomeado de banco serializa todos os escritores de assinaturas deste site. Registros 0.1 são indexados em lotes antes de qualquer novo POST.

Estados: prepared, dispatching, uncertain, confirmed, deleting, deleted e rejected_before_dispatch; registros legados creating/rejected são tratados conservadoramente. A transição dispatching é gravada antes do POST. Timeout ou queda deixa bloqueio persistido. Recibo remoto com ID é gravado antes de nova leitura ou checagem de acesso. Revogação durante o envio retorna erro com remote_effect conhecido e ownership_key; não apaga o recibo.

As concessões, seleção, callback, usuário humano quando aplicável e revisões são revalidados imediatamente antes de POST/DELETE. A pré-consulta pode revogar acesso; nesse caso nenhuma mutação posterior é enviada. Uma assinatura externa equivalente nunca é adotada como própria.

get_subscription_operation lê o diário do próprio consumidor. reconcile_subscription exige ownership_key e expected_operation_revision. Intenção sem recibo remoto nunca é liberada por listagem vazia: a origem pode estar atrasada. Um prepared comprovadamente sem despacho pode ser marcado rejected_before_dispatch. Com recibo conhecido, GET do ID deve confirmar o mesmo objeto; mudança de credencial exige authorize_current_context, mesma identidade de aplicativo configurada e nova concessão válida. Registros antigos sem application_id não são reatrelados automaticamente; preserve o contexto anterior e use revisão administrativa com evidência do fornecedor.

DELETE exige autoria local, estado confirmado e contexto vigente. Falha de confirmação mantém estado deleting para reconciliação; não é reenviado automaticamente. delivery_verified permanece false: criar assinatura não comprova challenge nem entrega real.

## Conversões pelo servidor

O registro de serviço é emitido no próprio envio, depois do recibo local, sem cron de auditoria. Falha no registro central não permite reenviar um evento entregue ou incerto. O leitor e o introspector são locais e não escrevem. `service_audit`, em `status` e `capabilities`, distingue a capacidade do domínio da admissão central. Códigos de retorno e recuperação em SERVICE-AUDIT.md.

## Depois de autorizar pelo navegador

O retorno OAuth grava o evento `oauth-finish` na auditoria, com o diagnóstico das etapas, e mostra a mensagem na aba **Conexão**. Quando a resposta for `identity_change_required`, use **Renovar agora**, marque a autorização candidata, use **Simular alterações** e **Confirmar alterações**. Detalhes em CREDENTIALS.md.

## Dados que o plugin grava

| Onde | O que |
|---|---|
| Tabela `{prefixo}f3_linkedin_records` | Conexões, concessões, agendas, coletas, resultados, diários, provas e auditoria, com os campos sensíveis cifrados. |
| Tabela `{prefixo}f3_linkedin_history` | Métricas diárias do histórico. |
| Opções com prefixo `f3_linkedin_` | Versões de schema, estado da fila, saúde da auditoria, política de retenção e marcas do worker e da manutenção. |
| Transientes `f3_linkedin_oauth_notice_<usuário>` | Aviso do retorno OAuth, lido uma vez. |
| Ganchos de cron | Os três da seção «Execução agendada». |

Os registros cifrados dependem das chaves e salts do `wp-config.php`. Trocar as salts torna esses registros ilegíveis (`cipher_unreadable`).

## Desativar e desinstalar

Desativar remove os três ganchos de cron e conserva todos os dados. Reativar recria os ganchos.

Desinstalar pelo WordPress também remove só os ganchos. As duas tabelas e as opções permanecem, para que uma reinstalação encontre as conexões. O plugin não oferece operação de limpeza. Apagar os dados em definitivo é uma decisão do dono do site e exige remover manualmente as duas tabelas e as opções listadas acima, com backup anterior. Antes disso, revogue no LinkedIn as assinaturas de notificação criadas pelo site; elas não são removidas pela desinstalação.

## Cópia de segurança e recuperação

- Antes de atualizar, guarde o banco e as salts. O backup serve para recuperar dados, não para voltar à versão anterior.
- Falha observada depois de uma instalação é corrigida em versão nova. Não há procedimento de retorno à versão anterior.
- Depois de restaurar um banco, consulte `linkedin/status` e reconcilie operações com efeito incerto antes de retomar escritas.
- Escritas, recusas observadas e consultas ao fornecedor geram eventos de auditoria. Defina um prazo na aba **Retenção** quando o volume importar.

Se um consumidor parar, confira seu estado local em CONCESSOES.md.
