# Release 0.19.0 — diagnóstico e revisão de alterações

Base: 0.18.0. Requisitos: WordPress 7.1.4+ e PHP 8.3+. Atualização direta conforme MIGRATION.md.

**Diagnóstico.** O painel separa estado/autoteste locais da validação de um ativo no LinkedIn. Mostra primeiro um resumo e permite consultar os detalhes; uma resposta que chega atrasada não substitui a consulta atual. O diagnóstico de credenciais reúne, em uma leitura SQL limitada às 100 conexões admitidas, validade, escopos já conhecidos e avisos, sem chamar o provedor ou renovar tokens.

**Prova de acesso ao ativo.** A validação continua exigindo acesso administrativo e seleção autorizada. Uma leitura bem-sucedida guarda a prova separadamente da configuração, vinculada à revisão e à credencial. Repetir a validação não incrementa a revisão nem torna concessões vigentes obsoletas. A prova se refere aos metadados do ativo consultado. Não atesta acesso a métricas, leads ou mutações.

Se uma prova armazenada estiver ilegível, a conexão continua visível com `remote_proof:null` e `remote_proof_error`. Uma nova validação autorizada pode substituir a prova pela revisão lida; uma alteração concorrente exige releitura. Falha de banco continua sendo erro e não vira ausência de prova.

**Anúncios e publicações.** A tela separa destino, dados e revisão. Ao alterar um objeto, a leitura explícita recupera orçamento total, diário e lance quando fornecidos; a leitura que a própria prévia faz para obter a revisão mantém os valores digitados. Editar os dados ou trocar de alvo exige nova prévia, mesmo que a resposta anterior chegue depois. A troca de campanha descarta a audiência da campanha anterior. Editar uma data conserva a precisão da outra. O botão final informa o efeito correspondente à ação. Veja MANAGEMENT.md para as duas fases e seus efeitos.

**Agendas.** Em falha transitória de banco ou trava ao preparar uma ocorrência, a agenda continua habilitada, conserva o horário original e só tenta novamente após cinco minutos, em passagem efetiva do worker. O estado informa `schedule_retry_pending`. A retomada usa a chave da mesma ocorrência.

Continuam iguais as 99 operações, os contratos SDK e o schema físico 2. Nenhuma etapa da instalação exige ativar anúncio, publicar, gerar contato ou enviar conversão. As condições e a matriz de testes efetivamente executados estão no relatório desta versão.
