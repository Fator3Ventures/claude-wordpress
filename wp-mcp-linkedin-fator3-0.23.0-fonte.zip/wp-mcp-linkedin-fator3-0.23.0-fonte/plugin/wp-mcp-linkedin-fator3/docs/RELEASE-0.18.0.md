# Release 0.18.0 — configuração e leitura administrativa

Base 0.17.1; PHP mínimo 8.3 e WordPress mínimo 7.1.4. A administração reúne identificação, credenciais, renovação, usuários, guarda e remoção em grupos próprios; os campos com ajuda separam nome e descrição acessível. A busca local encontra conexões por nome ou identificador, inclusive fora dos oito cartões iniciais. As listas de conexão das telas CAPI e gestão percorrem todas as páginas. A simulação de retenção descarta respostas atrasadas; após editar ou confirmar é necessário obter nova prévia. A versão da API da conexão também apresenta prévia de impacto e confirmação.

A listagem de conexões obtém a página e seus vínculos cifrados por uma consulta SQL delimitada, com o mesmo filtro, revisão e projeção pública do leitor individual. Enviar um novo valor e solicitar remoção do mesmo segredo na mesma gravação é recusado. A ajuda usa índice pré-calculado e decodifica apenas o documento solicitado; os formatos e as verificações de revisão/bytes continuam iguais.

Sem alteração de schema do banco, nomes de operações ou contratos SDK. O consumidor Core 1.69.0 utiliza o contrato de descoberta, recibo canônico e lookup de campanha. A prova de fornecedor real é separada da validação do pacote. Leia PRIMEIROS-PASSOS.md, MIGRATION.md e o relatório externo para a matriz executada.
