# Fator3 MCP LinkedIn 0.20.0

Atualização direta da 0.19.0 ou instalação limpa. Requisitos: WordPress 7.1.4 e PHP 8.3. Preserva schema físico 2 e contratos públicos. O conjunto de referência desta rodada usa Site Core 1.78.0, MCP 0.43.0, Google 0.31.0, Meta 0.21.0 e Pipedrive 0.8.0; as provas e limitações estão no relatório de entrega.

Conexões ativas exigem token, enquanto rascunhos pausados permitem preparar OAuth. Registros antigos inválidos permanecem detectáveis. Operações locais de consulta não acumulam auditoria no caminho de sucesso. O agente pode consultar regras de entrada, antecedência e resultado de manutenção sem receber segredos. O índice de documentação classifica manuais, schemas e histórico e fornece metadados de leitura.

O painel organiza os destinos existentes em seis seções. A busca global mantém a edição de conexões além da primeira página; efeitos de alteração podem ser simulados mesmo sem vínculos. A versão não acrescenta uma fase a contratos de escrita. Testes locais e consultas de prontidão não atestam concessões, entregas CAPI, leitura de leads nem campanhas em uma conta real.
