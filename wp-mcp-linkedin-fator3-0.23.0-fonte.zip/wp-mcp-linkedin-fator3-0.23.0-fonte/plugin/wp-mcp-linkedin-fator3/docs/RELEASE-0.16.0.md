# Release 0.16.0 — nome da campanha nos leads

Base aceita 0.15.0; evolução minor pelo contrato opcional de consulta de campanha. Responde ao impacto Core 1.68.0 revisão 2, item 369(d), mantendo os pedidos LinkedIn 18–21 e a descoberta 1.2.

Getter/finder passam a solicitar os metadados opcionais do Lead Sync. Nome e ID são vinculados à resposta/conta autorizada, com diagnóstico aditivo `campaign`. Ausência ou decoração inválida não descarta lead válido; nome inválido não é usado. Não muda a normalização de respostas ou a deduplicação do Core.

Nova extensão `linkedin-lead-campaign/1.0.0`, método `resolve_campaign` e ability `linkedin/lead-resolve-campaign`, total 98 operações. Fallback de leitura limitado à campanha referenciada pelo lead, mediante permissão `campaign_lookup` explícita, conta Ads selecionada, escopo introspectado e revisões atuais. O painel apresenta a nova permissão e confirma a prévia. Leia CAMPAIGN-METADATA.md e lead-campaign-schema.json.

Não há migração de schema nem ampliação de concessões. Atualização direta: 0.15.0 → 0.16.0. Core 1.68.0 já adota a descoberta 1.2; aproveita a decoração normal, mas o novo fallback requer adoção pelo consumidor. Pacotes examinados: MCP 0.38.0, Google 0.26.0, Meta 0.19.0, Pipedrive 0.5.0 e Core 1.68.0. Mínimos próprios permanecem WordPress 6.4/PHP 8.1.2 de 64 bits. Evidências, limitações de bancada e situação do Site-Teste constam do relatório externo da entrega.
