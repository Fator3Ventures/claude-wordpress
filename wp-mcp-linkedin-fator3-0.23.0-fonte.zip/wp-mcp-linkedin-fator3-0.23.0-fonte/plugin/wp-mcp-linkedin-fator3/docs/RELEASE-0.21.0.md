# Notas da versão 0.21.0

Pedido MCP LinkedIn 24 / Pedidos core 390. A operação de leitura reúne o anúncio, sua campanha, publicação e endereços temporários da mídia. A partir de um formulário nativo, o leitor verifica a resposta e resolve somente o criativo associado. A concessão explícita de origem não é herdada de permissões anteriores. Não há alteração do schema físico nem escrita em contas de anúncios. Leia AD-SOURCE.md.
