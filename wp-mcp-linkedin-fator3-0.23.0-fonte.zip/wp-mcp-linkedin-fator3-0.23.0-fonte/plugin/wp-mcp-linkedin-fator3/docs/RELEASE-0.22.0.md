# Notas da versão 0.22.0

Pedidos MCP LinkedIn 24 / Core 390: o leitor interrompe consultas por resposta quando o destino do criativo aponta para outro formulário. Na mídia, usa o menor vencimento verificável mesmo quando a URL contém parâmetros repetidos. O contrato linkedin-ad-source/1.0.0 e as concessões continuam os mesmos. O Core 1.81.1 já separa links temporários dos campos estáveis. Veja AD-SOURCE.md e MIGRATION.md.

Migração direta da 0.21.0, sem alteração do banco, em WordPress 7.1.4+ e PHP 8.3+ de 64 bits. Conjunto de referência: Core 1.81.1, MCP 0.44.0, Google 0.34.0, Meta 0.24.1 e Pipedrive 0.9.0. Os passos de verificação do download estão em AD-SOURCE.md.
