# Configuração — 0.23.0

O que pode ser configurado, onde, com que limites e o que cada mudança provoca. A sequência de tela para a primeira conexão está em PRIMEIROS-PASSOS.md; o significado de cada campo, em FIELD-HELP.md; o ciclo das credenciais, em CREDENTIALS.md.

## Onde configurar

Pelo painel, em **Ferramentas → Fator3 MCP LinkedIn**, ou pelas operações `save-connection`, `save-grant`, `save-conversion-grant`, `save-stage-conversion-grant`, `save-retention` e `save-schedule`. As duas vias gravam os mesmos registros e exigem administrador. Toda gravação confere a revisão lida (`expected_revision`); se o registro mudou no intervalo, a resposta é `revision_conflict` e nada é gravado.

## Conexão

Uma conexão reúne um aplicativo do LinkedIn, o token de um membro e a seleção de ativos que esse token pode usar no site.

- **Credenciais.** Access Token, Client ID e Primary Client Secret são guardados cifrados. Uma credencial nova é conferida no LinkedIn antes da gravação e exige os três valores. O segredo do aplicativo também é usado para verificar notificações de formulários. Client ID e número do aplicativo configurados servem à rastreabilidade; não comprovam, sozinhos, a titularidade do aplicativo.
- **Manter ou remover um segredo.** Campo ausente ou vazio mantém o valor salvo. Para apagar, use a remoção explícita (`clear_token`, `clear_client_secret`, `clear_refresh_token`). Informar o valor e a remoção do mesmo segredo na mesma gravação é recusado com `invalid_input`.
- **Ativa ou pausada.** Uma conexão pausada não é usada em consultas, coletas nem concessões. Para preparar a autorização pelo navegador sem token, salve a conexão pausada. Só ative a conexão quando o token estiver configurado.
- **Usuários associados.** Lista de usuários do WordPress ligados à conexão. Não concede `manage_options`; quem não é administrador continua sem acesso.
- **Revisão.** Cada gravação incrementa a revisão da conexão. Mudanças da mesma identidade atualizam agendas e concessões vigentes para a nova revisão. Troca de identidade exige simulação e confirmação. A renovação automática do token muda apenas a geração da credencial e conserva revisão e concessões.
- **Aviso de vencimento.** A antecedência do aviso é definida por conexão. Alterá-la exige simulação e confirmação na mesma revisão.

Gravar a conexão pelo painel não envia ativos nem formulários: a seleção existente é mantida.

## Ativos e formulários

Os canais são Páginas (`pages`), Anúncios (`ads`) e Formulários (`leads`). Cada canal tem sua própria lista de identificadores autorizados. A descoberta lista o que o token alcança; só passa a valer o que for marcado e gravado. Lista vazia não concede acesso.

No canal Formulários, a lista contém contas de anúncios. Os formulários são escolhidos por conta, depois de a conta estar gravada. Lead Sync aceita somente formulários patrocinados. Os escopos `r_ads` e `rw_ads` não dão acesso a respostas de formulários: é preciso o produto e a permissão próprios do Lead Sync.

A opção de incluir todos os formulários de uma conta, inclusive os futuros, e o intervalo de descoberta estão descritos em LEAD-DISCOVERY.md. A seleção explícita é o padrão.

Salvar a seleção usa a revisão lida ao abrir a aba **Ativos**. Em conflito, reabra a aba e revise.

## Concessões

Registrar um consumidor não lhe dá acesso. O administrador concede, por conexão:

| Concessão | Onde | O que define |
|---|---|---|
| Formulários (Lead Sync) | Aba **Concessões**; `save-grant` | Consumidor, formulários, endereço HTTPS de notificações e permissões: `metadata`, `responses`, `verify`, `subscriptions`, `campaign_lookup` e `ad_source`. A última permite ler qualquer criativo das contas concedidas; para consulta por resposta, marque também `responses` e confira o formulário autorizado. |
| Conversões de aquisição | Aba **Ativos**; `save-conversion-grant` | Conta de anúncios e regra de conversão de fonte API vinculadas ao Site Core. |
| Conversões por etapa comercial | Aba **Ativos**; `save-stage-conversion-grant` | Uma regra própria por etapa, distinta da regra de aquisição. |

Concessão sem formulários não concede acesso. `campaign_lookup` exige que a conta também esteja selecionada em Anúncios. O consumidor com concessão válida opera sem sessão humana.

Alterar a conexão pode tornar uma concessão obsoleta. A simulação de `save-connection` mostra, para cada concessão, se ela é preservada, exige reconfirmação ou fica bloqueada. Uma concessão obsoleta só volta com reconfirmação explícita; instalar uma versão nova ou editar o nome da conexão não a recupera. Os estados e campos dessa simulação estão em CREDENTIALS.md, seção «Concessões por domínio».

## Retenção

Há três políticas independentes:

| O que | Onde se define | Padrão |
|---|---|---|
| Resultados de coleta | Em cada conexão, grupo **Guarda dos resultados de coleta** | Sem expiração |
| Auditoria local | Aba **Retenção**; `save-retention` | Sem prazo |
| Histórico diário | Não configurável | Não expira |

A mudança da auditoria é simulada antes de gravar. A remoção de eventos antigos ocorre na manutenção seguinte, não no momento da gravação. Detalhes em HISTORY.md.

## Versão da API do LinkedIn

Definida por conexão, em **Diagnóstico → Configuração avançada da versão da API**, com simulação e confirmação. Mudar a versão exige rever coletas e concessões daquela conexão.

## Agendas

Uma agenda guarda a consulta completa, o intervalo e a quantidade de dias completos a coletar. Quem executa é o cron do site; o horário informado indica quando a agenda fica elegível. O usuário que criou a agenda precisa continuar autorizado. Veja WORKER.md.

## Faixas aceitas

| Item | Faixa aceita | Padrão |
|---|---|---|
| Conexões por site | até 100 | — |
| Nome da conexão (`label`) | até 120 caracteres | o identificador, se omitido |
| Usuários associados (`users`) | até 100 | quem criou a conexão |
| Ativos por canal (`assets.pages`, `assets.ads`, `assets.leads`) | até 100 em cada canal | nenhum |
| Formulários por conta (`forms`) | até 100 por conta, em até 100 contas | nenhum |
| Guarda dos resultados (`retention_mode`, `retention_days`) | sem expiração ou 1 a 3650 dias | sem expiração; 90 dias quando se escolhe prazo |
| Antecedência do aviso de vencimento (`credential_notice_days`) | 1 a 365 dias | 14 dias |
| Intervalo da descoberta de formulários (`lead_discovery_interval_minutes`) | 5 a 1440 minutos | — |
| Versão da API (`api_version`) | ano e mês, seis dígitos | 202609 |
| Retenção da auditoria (`audit_mode`, `audit_days`) | sem prazo ou 1 a 36500 dias | sem prazo; 30 dias quando se escolhe prazo |
| Agendas por site | até 100 | — |
| Intervalo da agenda (`interval_minutes`) | 60 a 43200 minutos | — |
| Dias completos da agenda (`lookback_days`) | 1 a 30 | — |
| Página de documento (`limit_bytes`) | 256 a 65536 bytes | 16384 bytes |
