/* Administration only. Provider values are always rendered as text, never HTML. */
(()=>{'use strict';
const cfg=window.F3Social,$=s=>document.querySelector(s),all=s=>[...document.querySelectorAll(s)];
const el=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
const meta=cfg.provider==='meta',qf=$('#f3-query'),cf=$('#f3-connection');
let connections=cfg.bootstrap.connections||[],activeTab=cfg.tab,dirty=false,users=new Set([Number(cfg.bootstrap.currentUser)]),userRows=new Map(),userOffset=null;
let contextEpoch=0,fieldsEpoch=0,assetsEpoch=0,grantEpoch=0,journalEpoch=0,lastQuery=null,next=null,contextLoaded=false,assetEdit=null;
let objectPage=null,campaignPage=null,grantsRows=[],grantForms={},grantAll=new Set(),journalRows=[],journalOffset=null,historyQuery=null,historyNext=null;
const reportNames={profile:'Perfil do Instagram',media:'Mídias do Instagram',stories:'Stories do Instagram',account_insights:'Métricas da conta do Instagram',media_insights:'Métricas de mídia',stories_insights:'Métricas de Stories',audience:'Público do Instagram',page_profile:'Perfil da Página',page_insights:'Métricas da Página',page_posts:'Publicações da Página',post_insights:'Métricas de publicação',page_videos:'Vídeos da Página',video_insights:'Métricas de vídeo',page_audience:'Público da Página',page_ratings:'Avaliações da Página',organization:'Organização',page_statistics:'Estatísticas da Página',share_statistics:'Estatísticas de publicações',follower_statistics:'Estatísticas de seguidores',posts:'Publicações',ad_accounts:'Contas de anúncios',campaign_groups:'Grupos de campanhas',campaigns:'Campanhas',creatives:'Anúncios',ad_analytics:'Métricas de anúncios'};
const labels={instagram:'Instagram',facebook:'Facebook',pages:'Páginas',ads:'Anúncios',leads:'Formulários',queued:'Na fila',retry:'Aguardando nova tentativa',running:'Em execução',paused:'Pausada',complete:'Concluída',partial:'Parcial',cancelled:'Cancelada',failed:'Falhou',unknown:'Desconhecido',pending:'Pendente',confirmed:'Confirmada',uncertain:'Incerta',deleted:'Removida',active:'Ativa',ok:'Verificado',unavailable:'Indisponível',available:'Disponível',requires_remote_validation:'Exige validação externa',name:'Nome',id:'Identificação',status:'Estado',state:'Estado',version:'Versão',report:'Relatório',value:'Valor',date:'Data',metric:'Métrica',period:'Período',created_at:'Criado em',updated_at:'Atualizado em',next_at:'Próxima execução',revision:'Revisão',connection_id:'Conexão',account_id:'Conta',channel:'Canal',rows:'Linhas',pages:'Páginas',errors:'Erros',warnings:'Avisos',coverage:'Cobertura',api_version:'Versão da API',provider:'Fornecedor',reason:'Motivo',code:'Código',message:'Mensagem',success:'Sucesso',enabled:'Ativa',forms:'Formulários',permissions:'Permissões',consumer_id:'Consumidor',credential_revision:'Revisão da conexão',grant_revision:'Revisão da concessão',callback_url:'Endereço de recebimento',operation_revision:'Revisão da operação',remote_effect:'Efeito remoto',page_views_total:'Visualizações do perfil da Página',page_media_view:'Visualizações de mídia da Página',page_total_media_view_unique:'Pessoas que visualizaram mídias da Página',page_post_engagements:'Engajamentos com publicações da Página',page_daily_follows:'Novos seguidores da Página',page_daily_unfollows:'Pessoas que deixaram de seguir a Página',page_follows:'Seguidores da Página',reach:'Alcance',views:'Visualizações',accounts_engaged:'Contas engajadas',total_interactions:'Interações totais',likes:'Curtidas',comments:'Comentários',shares:'Compartilhamentos',saves:'Salvamentos',saved:'Salvamentos',profile_links_taps:'Toques em links do perfil',follows_and_unfollows:'Entradas e saídas de seguidores',follower_count:'Seguidores',online_followers:'Seguidores conectados',username:'Nome de usuário',biography:'Biografia',website:'Site',followers_count:'Número de seguidores',follows_count:'Contas seguidas',media_count:'Número de mídias',profile_picture_url:'Imagem do perfil',caption:'Legenda',media_type:'Tipo de mídia',media_product_type:'Formato de mídia',timestamp:'Data e hora',permalink:'Link permanente',like_count:'Número de curtidas',comments_count:'Número de comentários',ig_reels_video_view_total_time:'Tempo total de reprodução de Reels',ig_reels_avg_watch_time:'Tempo médio de reprodução de Reels',replies:'Respostas',navigation:'Navegação',follower_demographics:'Demografia de seguidores',engaged_audience_demographics:'Demografia do público engajado',reached_audience_demographics:'Demografia do público alcançado',about:'Sobre',category:'Categoria',fan_count:'Fãs',link:'Link',created_time:'Data de criação',permalink_url:'Link permanente',title:'Título',description:'Descrição',length:'Duração',recommendation_type:'Tipo de recomendação',review_text:'Avaliação',post_media_view:'Visualizações da publicação',post_media_view_unique:'Pessoas que visualizaram a publicação',post_clicks:'Cliques na publicação',post_reactions_by_type_total:'Reações por tipo',total_video_views:'Visualizações do vídeo',total_video_views_unique:'Pessoas que visualizaram o vídeo',total_video_view_total_time:'Tempo total de reprodução',total_video_avg_time_watched:'Tempo médio de reprodução',page_fans_city:'Fãs por cidade',page_fans_country:'Fãs por país',page_fans_gender_age:'Fãs por gênero e idade',impressions:'Impressões',clicks:'Cliques',costInLocalCurrency:'Custo na moeda da conta',costInUsd:'Custo em dólares',likes:'Curtidas',comments:'Comentários',shares:'Compartilhamentos',follows:'Novos seguidores',externalWebsiteConversions:'Conversões no site',externalWebsitePostClickConversions:'Conversões após clique',externalWebsitePostViewConversions:'Conversões após visualização',dateRange:'Período',pivotValues:'Grupos',totalEngagements:'Engajamentos totais',landingPageClicks:'Cliques na página de destino',companyPageClicks:'Cliques na página da empresa',oneClickLeads:'Contatos de formulários',oneClickLeadFormOpens:'Aberturas de formulário',videoViews:'Visualizações de vídeo',videoStarts:'Inícios de vídeo',videoCompletions:'Conclusões de vídeo',videoFirstQuartileCompletions:'Vídeo: primeiro quarto',videoMidpointCompletions:'Vídeo: metade',videoThirdQuartileCompletions:'Vídeo: terceiro quarto',approximateUniqueImpressions:'Impressões únicas aproximadas',localizedName:'Nome da organização',vanityName:'Nome público',localizedDescription:'Descrição',organization:'Organização',account:'Conta',campaign:'Campanha',campaignGroup:'Grupo de campanhas',creative:'Anúncio',currency:'Moeda',type:'Tipo',owner:'Proprietário',role:'Papel',totalPageStatistics:'Estatísticas totais da Página',totalShareStatistics:'Estatísticas totais de publicações',followerCountsByAssociationType:'Seguidores por associação',followerCountsByFunction:'Seguidores por função',followerCountsByGeoCountry:'Seguidores por país',followerCountsByIndustry:'Seguidores por setor',followerCountsBySeniority:'Seguidores por experiência',followerCountsByStaffCountRange:'Seguidores por porte',lifetimeFollowerCounts:'Seguidores acumulados',timeRange:'Intervalo de tempo',specificContent:'Conteúdo',author:'Autor',commentary:'Texto da publicação',lifecycleState:'Estado da publicação',content:'Conteúdo',visibility:'Visibilidade',lastModifiedAt:'Última alteração',createdAt:'Criação',totalFollowerCounts:'Total de seguidores',organicFollowerCount:'Seguidores orgânicos',paidFollowerCount:'Seguidores pagos'};
Object.assign(labels,{all_forms_accounts:'Contas com todos os formulários',form_discovery:'Descoberta de formulários',discovered_at:'Descoberto em',form_id:'Formulário',form_version:'Versão do formulário',subscription:'Assinatura',externalWebsitePostClickConversions:'Conversões após clique',externalWebsitePostViewConversions:'Conversões após visualização',conversionValueInLocalCurrency:'Valor de conversões na moeda da conta',reactions:'Reações',approximateMemberReach:'Alcance aproximado de pessoas',ctr:'Taxa de cliques',cpc:'Custo por clique',cpm:'Custo por mil impressões',roas:'Retorno sobre investimento em anúncios',logoV2:'Logotipo',publishedAt:'Publicado em',mobilePageStatistics:'Estatísticas em celular',desktopPageStatistics:'Estatísticas em computador',organizationalEntity:'Organização',share:'Publicação',ugcPost:'Publicação de usuário',followerGains:'Novos seguidores',followerCountsByGeo:'Seguidores por região',firstDegreeSize:'Número de seguidores',reference:'Referência',runSchedule:'Programação',totalBudget:'Orçamento total',objectiveType:'Objetivo',costType:'Tipo de custo',intendedStatus:'Estado desejado',isServing:'Em veiculação','reactions.summary(true)':'Resumo de reações','comments.summary(true)':'Resumo de comentários'});reportNames.follower_total='Total de seguidores';if(!meta)reportNames.audience='Público da organização';
Object.assign(labels,{execution_success:'Execução concluída',local_checks_ok:'Verificações locais aprovadas',checks:'Verificações',external_checks:'Verificações externas',not_run:'Não executadas',remote_homologated:'Homologação externa comprovada',storage:'Armazenamento',authenticated_encryption:'Criptografia autenticada',cursor_roundtrip:'Continuação de consultas',endpoint_allowlist:'Endereços remotos permitidos',closed_schema:'Validação de entradas',empty_scope_denied:'Recusa de seleção vazia',csv_formula_protection:'Proteção de fórmulas CSV',schema_catalog:'Catálogo de operações',storage_ready:'Armazenamento pronto',crypto_ready:'Criptografia pronta',connection_count:'Conexões cadastradas',mcp_installed:'Transporte MCP instalado',abilities_available:'API de operações disponível',cron:'Execução agendada',next:'Próxima execução',last:'Última execução',traffic_required:'Depende de tráfego no site',audit_health:'Estado da auditoria',proof:'Comprovação',account_id:'Conta autorizada',metadata_read:'Leitura de metadados',analytics_read:'Leitura de métricas',insights_read:'Leitura de métricas',lead_responses_read:'Leitura de respostas de formulários',app_approval_verified:'Aprovação do aplicativo comprovada',checked_at:'Verificado em',page_permissions:'Permissões da Página',page_id:'Página',source:'Origem',permissions_verified:'Permissões verificadas',scopes:'Permissões declaradas',read_insights_granted:'Permissão para ler métricas',pages_read_engagement_granted:'Permissão para ler engajamento',is_valid:'Credencial válida',diagnostic_error:'Erro de diagnóstico',http_status:'Estado HTTP',provider_code:'Código do fornecedor',provider_subcode:'Subcódigo do fornecedor',provider_is_transient:'Falha temporária',plan_complete:'Plano concluído',all_rows_guaranteed:'Todas as linhas garantidas',origin_all_rows_guaranteed:'Integridade da origem garantida',stop_reason:'Motivo de parada',requested_from:'Início solicitado',requested_to:'Fim solicitado',error_count:'Quantidade de erros',errors_sampled:'Erros limitados à amostra',continuation:'Há mais páginas',fields_unavailable:'Campos indisponíveis',plan_finished:'Plano concluído',migration_complete:'Migração concluída',retention:'Retenção',mode:'Modo',finite:'Prazo em dias',unlimited:'Sem expiração automática',stored_rows_only:'Somente linhas armazenadas',days:'Dias',retention_days:'Dias de retenção',retention_mode:'Modo de retenção',count:'Quantidade',total:'Total',field:'Campo',availability:'Disponibilidade',available:'Disponível',empty_or_suppressed:'Sem valor ou suprimido na origem',value_unavailable:'Valor indisponível',multiple_source_buckets:'Mais de um período retornado pela origem',unsupported_for_asset_or_version:'Recusa para este ativo ou versão',provider_rejected:'Recusado pelo fornecedor',undetermined:'Não determinado',cause:'Causa',diagnostic:'Diagnóstico',entity_id:'Objeto',observed_at:'Observado em',end_time:'Fim do período',source_values:'Valores originais',timezone:'Fuso horário',currency:'Moeda',source_field:'Campo original',formula:'Fórmula',aggregation:'Agregação',unit:'Unidade',temporal:'Tipo de período',updated_by:'Alterado por',configured_by:'Configurado por',created_by:'Criado por',expires_at:'Validade',last_code:'Último código',last_error:'Último erro',last_job:'Última coleta',query:'Consulta',schedule_id:'Agenda',interval_minutes:'Intervalo em minutos',lookback_days:'Dias completos anteriores',credential_generation:'Geração da credencial',authorization_revision:'Revisão de autorização',metadata:'Metadados',responses:'Respostas',verify:'Verificação de assinaturas',subscriptions:'Gerenciamento de assinaturas',subscription_id:'Assinatura',ownership_key:'Operação própria',contract:'Contrato',consumer_id:'Consumidor',credential_revision:'Revisão da credencial',grant_revision:'Revisão da concessão',application_id:'Aplicativo',client_id:'Aplicativo',credential_context:'Contexto da credencial',grant_context:'Contexto da concessão',wanted:'Configuração solicitada',remote_id:'Recibo remoto',creating:'Criação em andamento',deleting:'Remoção em andamento',confirmed:'Confirmada',uncertain:'Incerta',deleted:'Removida',operation_uncertain:'Resultado incerto',none:'Nenhum',read:'Leitura',write:'Gravação',verified:'Verificado',not_verified:'Não verificado',unavailable:'Indisponível',denied:'Recusado',granted:'Concedido'});
Object.assign(labels,{ACTIVE:'Ativo',ARCHIVED:'Arquivado',CANCELED:'Cancelado',DRAFT:'Rascunho',PAUSED:'Pausado',PENDING_DELETION:'Remoção pendente',REMOVED:'Removido',COMPLETED:'Concluído',APPROVED:'Aprovado',REJECTED:'Recusado',PUBLISHED:'Publicado',SUBMITTED:'Enviado',PROCESSING:'Em processamento',DELETED:'Removido',ACCOUNT_MANAGER:'Gerente da conta',ACCOUNT_BILLING_ADMIN:'Administrador financeiro',VIEWER:'Leitor',CREATIVE_MANAGER:'Gerente de anúncios',CAMPAIGN_MANAGER:'Gerente de campanhas',ADMINISTRATOR:'Administrador',create:'Criação',delete:'Remoção'});
const knownLabel=k=>reportNames[k]||labels[k];
const keyLabel=k=>knownLabel(k)||'Detalhe técnico';
const label=k=>knownLabel(k)||k;
const enumKeys=new Set(['report','channel','metric','field','source_field','status','state','availability','temporal','aggregation','cause','reason','stop_reason','external_checks','retention_mode','mode','role']);
const displayValue=(key,value)=>enumKeys.has(key)?label(String(value)):String(value);
const msg=(text,error=false)=>{
 const region=$('#f3-message');
 region.setAttribute('role',error?'alert':'status');region.setAttribute('aria-live',error?'assertive':'polite');
 region.dataset.error=String(error);region.textContent=text;
};
let actionSequence=0;
const activeButtons=new WeakSet();
// A consumed confirmation cannot take keyboard focus. Name its next valid action.
const continuation={
 'f3-identity-confirm':'#f3-identity-preview',
 'f3-api-version-confirm':'#f3-api-version button:not([type])',
 'f3-retention-save':'#f3-retention-form button:not([type])',
 'f3-management-execute':'#f3-management-form button[type=submit]',
 'f3-stage-grant':'#f3-stage-preview',
 'f3-connections-more':'#f3-connection-list tbody button',
 'f3-connections-prev':'#f3-connection-list tbody button'
};
function startAction(e) {
 const button=e?.submitter||(e?.currentTarget?.tagName==='BUTTON'?e.currentTarget:null)
     ||(e?.type==='submit'?e.target.querySelector('button:not([type]),button[type=submit]'):null);
 if(!button)return {report:msg,done:()=>{}};
 if(activeButtons.has(button)||button.disabled)return null;
 activeButtons.add(button);button.setAttribute('aria-busy','true');msg('');
 const n=++actionSequence, panel=button.closest('.f3-section');
 const next=continuation[button.id];let keepFocus=Boolean(next&&document.activeElement===button);
 const moved=event=>{if(!button.contains(event.target)&&event.target!==document.body)keepFocus=false;};
 if(keepFocus){document.addEventListener('focusin',moved,true);document.addEventListener('pointerdown',moved,true);}
 const note=button.nextElementSibling?.classList.contains('f3-action-note')?button.nextElementSibling:el('span');
 note.className='f3-action-note';note.textContent='';button.after(note);
 const report=(text,error=false)=>{
   if(!note.isConnected||panel?.hidden)return;
   note.dataset.error=String(error);note.textContent=text;
   if(n===actionSequence)msg(text,error);
 };
 // Keep the initiating button focusable throughout the request. The WeakSet prevents double activation.
 return {report,done:()=>{
   document.removeEventListener('focusin',moved,true);document.removeEventListener('pointerdown',moved,true);
   activeButtons.delete(button);button.removeAttribute('aria-busy');
   if(keepFocus&&n===actionSequence&&!panel?.hidden&&button.disabled&&[document.body,button].includes(document.activeElement)){
     const follow=$(next);if(follow&&!follow.disabled&&follow.getClientRects().length)follow.focus();
   }
 }};
}
cfg.startAction=startAction;
const dt=n=>n?new Date(Number(n)*1000).toLocaleString('pt-BR',{timeZone:'UTC'})+' UTC':'Não definido';
const dateInput=n=>n?new Date(Number(n)*1000).toISOString().slice(0,16):'';
const unix=s=>s?Math.floor(Date.parse(s+'Z')/1000):0;
const uuid=()=>crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
function credentialWarnings(warnings=[]){
 cf.querySelectorAll('[data-credential-warning]').forEach(n=>n.remove());
 for(const warning of warnings){if(!['token','client_id','client_secret','refresh_token'].includes(warning.field)||typeof warning.message!=='string')continue;
  const input=cf.elements.namedItem(warning.field);if(!input)continue;const note=el('small',warning.message);note.className='f3-field-help';note.dataset.credentialWarning=warning.field;note.dataset.warningCode=warning.code;note.setAttribute('role','status');input.closest('label').append(note);
 }
}
async function api(op,input={}){const r=await fetch(cfg.root+op,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':cfg.nonce},body:JSON.stringify(input)});let v;try{v=await r.json();}catch(_){throw Error('O servidor não retornou uma resposta válida. Tente novamente.');}if(op==='save-connection' && iAmEditing(input.connection_id))credentialWarnings(v.success?v.data?.warnings||[]:v.details?.warnings||[]);if(!r.ok||!v.success){const e=Error((v.message||'Operação recusada.')+' ['+(v.code||'http_'+r.status)+']');e.code=v.code;e.details=v.details;throw e;}return v.data;}
function task(fn){return async e=>{
 e?.preventDefault();const action=startAction(e);if(!action)return;
 try{await fn(e,action.report);}catch(err){action.report(err.message,true);}finally{action.done();}
};}
function bind(id,event,fn){$(id)?.addEventListener(event,task(fn));}
function button(box,text,fn){const b=el('button',text);b.type='button';b.className='button';b.addEventListener('click',task(fn));box.append(b);return b;}
function options(node,items,value,empty='Nenhuma opção disponível'){if(!node)return;node.replaceChildren(...items.map(x=>{const o=el('option',x.label??x.name??label(x));o.value=String(x.value??x.id??x);return o;}));if(!items.length){const o=el('option',empty);o.value='';node.append(o);}if(value!==undefined&&[...node.options].some(o=>o.value===String(value)))node.value=String(value);}
function checkChoice(target,id,name,selected,onchange){const l=el('label'),i=el('input');l.className='f3-check';i.type='checkbox';i.value=String(id);i.checked=selected;l.append(i,document.createTextNode(' '+name));i.addEventListener('change',()=>onchange(i.checked));target.append(l);return l;}
function named(row,noun='Ativo'){return row.name||row.username||`${noun} já selecionado · nome indisponível (${row.id})`;}
function pretty(target,data){target.replaceChildren();if(data===null||typeof data!=='object'){target.append(el('p',data===null?'Sem valor':typeof data==='boolean'?(data?'Sim':'Não'):label(String(data))));return;}if(Array.isArray(data)){if(!data.length){target.append(el('p','Nenhum registro.'));return;}for(const item of data){const d=el('div');d.className='f3-record';pretty(d,item);target.append(d);}return;}const dl=el('dl');dl.className='f3-details';for(const [k,v]of Object.entries(data)){const term=el('dt',keyLabel(k));if(!knownLabel(k))term.title=k;dl.append(term);const dd=el('dd');if(v&&typeof v==='object'){const d=el('details');d.append(el('summary',Array.isArray(v)?v.length+' registros':'Ver detalhes'));const body=el('div');pretty(body,v);d.append(body);dd.append(d);}else dd.textContent=typeof v==='boolean'?(v?'Sim':'Não'):v===null?'Sem valor':(['created_at','updated_at','next_at','expires_at'].includes(k)?dt(v):displayValue(k,v));dl.append(dd);}target.append(dl);}
function table(target,rows,empty='O LinkedIn não retornou linhas para esta seleção.'){target.replaceChildren();if(!rows.length){target.append(el('p',empty));return;}const keys=[...new Set(rows.flatMap(r=>Object.keys(r||{})))],t=el('table'),head=el('tr');keys.forEach(k=>{const th=el('th',keyLabel(k));if(!knownLabel(k))th.title=k;head.append(th);});t.append(head);for(const r of rows){const tr=el('tr');keys.forEach(k=>{const td=el('td');if(r[k]&&typeof r[k]==='object'){const d=el('details');d.append(el('summary','Ver detalhes'));const v=el('div');pretty(v,r[k]);d.append(v);td.append(d);}else td.textContent=r[k]===null?'Sem valor':displayValue(k,r[k]??'');tr.append(td);});t.append(tr);}target.append(t);}
function connection(id){return connections.find(c=>c.id===id);}
const PAGE_SIZE=20;
let directoryPage=0;
const fold=v=>String(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR');
function renderConnectionCards(){
 const list=$('#f3-connection-list'),term=fold($('#f3-connection-search').value.trim());
 const matches=connections.filter(c=>!term||fold(c.label+' '+c.id).includes(term));
 directoryPage=Math.min(directoryPage,Math.max(0,Math.ceil(matches.length/PAGE_SIZE)-1));
 const start=directoryPage*PAGE_SIZE,rows=matches.slice(start,start+PAGE_SIZE);
 $('#f3-connections-prev').disabled=!directoryPage;
 $('#f3-connections-more').disabled=start+rows.length>=matches.length;
 $('#f3-connection-count').textContent=rows.length?(start+1)+'–'+(start+rows.length)+' de '+matches.length+' conexões.':'0 conexões.';
 list.replaceChildren();
 if(!rows.length){list.append(el('p',term?'Nenhuma conexão corresponde à busca.':'Nenhuma conexão cadastrada. Use Nova conexão para começar.'));return;}
 const table=el('table'),head=el('thead'),headers=el('tr'),body=el('tbody');
 for(const name of ['Nome','Estado','Token','Validade (UTC)','Ação']){const th=el('th',name);th.scope='col';headers.append(th);}
 head.append(headers);table.append(head,body);
 for(const c of rows){
   const row=el('tr');
   for(const value of [c.label,c.enabled?'Ativa':'Pausada',c.token_configured?'Salvo':'Sem token',c.expires_at?new Date(c.expires_at*1000).toISOString().slice(0,16).replace('T',' '):'—'])row.append(el('td',value));
   const cell=el('td'),editBtn=button(cell,'Editar conexão',()=>openEditor(c.id));
   editBtn.setAttribute('aria-label','Editar conexão: '+c.label);row.append(cell);body.append(row);
 }
 list.append(table);
}
$('#f3-connection-search').addEventListener('input',()=>{directoryPage=0;renderConnectionCards();});
bind('#f3-connections-more','click',()=>{directoryPage++;renderConnectionCards();});
bind('#f3-connections-prev','click',()=>{directoryPage=Math.max(0,directoryPage-1);renderConnectionCards();});
function iAmEditing(id){return activeTab==='connections'&&!$('#f3-connection-editor').hidden&&cf.elements.connection_id.value===id;}
function editorView(open){
 $('#f3-connection-directory').hidden=open;$('#f3-connection-editor').hidden=!open;
}
function editorUrl(id,push){
 const u=new URL(location.href);u.searchParams.set('tab','connections');u.searchParams.delete('connection_id');
 u.searchParams.delete('new');u.searchParams.delete('connection');if(id==='@new')u.searchParams.set('new','1');else if(id)u.searchParams.set('connection',id);
 u.hash='';history[push?'pushState':'replaceState']({},'',u);
}
function canDiscard(){return !dirty || window.confirm('Sair da edição e descartar as alterações ainda não salvas?');}
let editorEpoch=0;
async function openEditor(id,push=true){
 const seq=++editorEpoch,c=id&&id!=='@new'?connection(id):null;
 if(id&&id!=='@new'&&!c){editorView(false);throw Error('Conexão não encontrada. Busque pelo nome ou identificador na lista.');}
 if(push)editorUrl(id,true);editorView(Boolean(id));
 if(!id){setDirty(false);if(push)$('#f3-connection-search').focus();return;}
 $('#f3-editor-heading').textContent=c?'Editar conexão':'Nova conexão';
 if(c){await edit(c);}else{newConnection();await loadUsers();}
 if(seq!==editorEpoch||activeTab!=='connections')return;
 if(push)cf.elements.label.focus();
}
bind('#f3-back-connections','click',()=>{if(canDiscard())return openEditor(null);});
bind('#f3-open-assets','click',()=>{const id=cf.elements.connection_id.value;if(!connection(id)||!canDiscard())return;$('#f3-assets-connection').value=id;setDirty(false);return tab('assets');});
function renderConnections(){const items=connections.map(c=>({value:c.id,label:c.label}));for(const s of ['#f3-context [name="connection_id"]','#f3-assets-connection','#f3-grant [name="connection_id"]','#f3-subscription-journal [name="connection_id"]','#f3-api-version [name="connection_id"]']){const n=$(s);if(n)options(n,items,n.value,'Cadastre uma conexão em Conexão');}options(qf.elements.channel,cfg.channels.filter(ch=>ch!=='leads').map(ch=>({value:ch,label:label(ch)})),qf.elements.channel.value);renderConnectionCards();const a=$('#f3-api-version');if(a)a.elements.api_version.value=connection(a.elements.connection_id.value)?.api_version||cfg.apiVersion;}
// All admin selectors consume the same paged contract; never silently hide later connections.
cfg.readConnections=async reader=>{
 const rows=[];let offset=0;
 do{const page=await reader('list-connections',offset?{offset}:{});rows.push(...page.connections);
  if(page.next_offset!==null&&(!Number.isInteger(page.next_offset)||page.next_offset<=offset))throw Error('A lista de conexões não avançou. Reabra a aba.');
  offset=page.next_offset;
 }while(offset!==null);
 return rows;
};
async function loadConnections(){connections=await cfg.readConnections(api);renderConnections();contextLoaded=false;}
function localTime(){const v=cf.elements.expires.value;
 const d=v?new Date(v+'Z'):null;
 $('#f3-local-expiry').textContent=d&&Number.isFinite(d.getTime())?'No seu fuso: '+d.toLocaleString('pt-BR',{timeZoneName:'short'})+'.':'';
}
cf.elements.expires.addEventListener('input',localTime);
function syncResultDays(){cf.elements.retention_days.disabled=cf.elements.retention_mode.value!=='finite';}
cf.elements.retention_mode.addEventListener('change',syncResultDays);
function setDirty(v){dirty=v;$('#f3-dirty').textContent=v?'Alterações ainda não salvas.':'';}
cf.addEventListener('input',e=>{if(['token','client_id','client_secret','refresh_token'].includes(e.target.name))credentialWarnings();setDirty(true);if(!['reconfirm_leads','reconfirm_conversions'].includes(e.target.name))clearIdentityPreview();});window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
function drawUsers(){const box=$('#f3-user-options');box.replaceChildren();for(const row of userRows.values())checkChoice(box,row.id,row.name+(row.can_administer?'':' · sem permissão administrativa'),users.has(Number(row.id)),on=>{on?users.add(Number(row.id)):users.delete(Number(row.id));setDirty(true);});}
let usersEpoch=0;
async function loadUsers(more=false){const gen=++usersEpoch;$('#f3-users-state').textContent='Carregando nomes dos usuários…';try{const r=await api('admin-options',{kind:'users',search:$('#f3-user-search').value,offset:more?(userOffset||0):0});if(gen!==usersEpoch)return;if(!more){for(const [id]of userRows)if(!users.has(Number(id)))userRows.delete(id);}r.rows.forEach(x=>userRows.set(Number(x.id),x));userOffset=r.next_offset;drawUsers();$('#f3-users-more').hidden=userOffset===null;$('#f3-users-state').textContent=r.rows.length?'Selecione os usuários pelo nome.':'Nenhum usuário encontrado nesta busca.';}catch(e){if(gen===usersEpoch)$('#f3-users-state').textContent='Não foi possível carregar os nomes. A seleção salva foi mantida. '+e.message;}}
async function edit(c){$('#f3-open-assets').disabled=false;credentialWarnings();cf.reset();clearIdentityPreview();renderIdentity(c,$('#f3-saved-identity'));if(!meta){$('#f3-pending-authorization').hidden=!c.authorization_pending;for(const box of $('#f3-oauth-scopes').querySelectorAll('input'))box.checked=(c.identity?.scopes||[]).includes(box.value);}for(const k of ['label','retention_days','retention_mode','client_id','application_id','credential_notice_days'])if(cf.elements[k])cf.elements[k].value=c[k]??'';syncResultDays();cf.elements.connection_id.value=c.id;cf.elements.expected_revision.value=c.revision;cf.elements.enabled.checked=c.enabled;cf.elements.expires.value=dateInput(c.expires_at);if(!meta){cf.elements.refresh_token.value='';cf.elements.refresh_expires.value=dateInput(c.refresh_expires_at);cf.elements.clear_refresh_token.checked=false;}users=new Set(c.users.map(Number));userRows.clear();setDirty(false);localTime();$('#f3-connection-state').textContent='Editando '+c.label+'. Credenciais salvas não são exibidas.';if(users.size){try{const r=await api('admin-options',{kind:'users',ids:[...users]});if(cf.elements.connection_id.value!==c.id)return;r.rows.forEach(x=>userRows.set(Number(x.id),x));}catch(e){msg(e.message,true);}}await loadUsers();}
function newConnection(){$('#f3-open-assets').disabled=true;credentialWarnings();cf.reset();clearIdentityPreview();$('#f3-saved-identity')?.replaceChildren();if(!meta){$('#f3-pending-authorization').hidden=true;for(const box of $('#f3-oauth-scopes').querySelectorAll('input'))box.checked=false;}cf.elements.connection_id.value='conexao-'+uuid();cf.elements.expected_revision.value=0;cf.elements.retention_days.value=90;cf.elements.retention_mode.value='unlimited';syncResultDays();users=new Set([Number(cfg.bootstrap.currentUser)]);setDirty(false);localTime();$('#f3-connection-state').textContent='Nova conexão. O identificador interno será criado automaticamente.';drawUsers();}
bind('#f3-user-find','click',()=>loadUsers());bind('#f3-users-more','click',()=>loadUsers(true));bind('#f3-new-connection','click',()=>openEditor('@new'));
let identityPreview=null,identityEpoch=0;
function showGrantChoices(affected={},identityChanged=false){
 for(const [name,key] of [['reconfirm_leads','lead_grants'],['reconfirm_conversions','conversion_grants']]){
   const box=cf.elements[name];if(!box)continue;
   box.checked=false;box.closest('label').hidden=!(affected[key]||[]).some(g=>g.enabled&&(g.can_reconfirm||identityChanged));
 }
}
function clearIdentityPreview(){identityEpoch++;showGrantChoices();identityPreview=null;const b=$('#f3-identity-confirm');if(b)b.disabled=true;$('#f3-identity-preview-result')?.replaceChildren();}
function grantStatus(v){return {preserved:'preservada',inactive:'inativa',requires_reconfirmation:'exige reconfirmação',already_stale:'já estava obsoleta',blocked:'recursos indisponíveis',reconfirmed:'reconfirmada'}[v]||v||'';}
function renderIdentity(c,target){if(!target)return;target.replaceChildren();const p=c?.identity;if(!p){target.append(el('p','Identidade e escopos ainda não conferidos. Use Verificar permissões na autorização pelo LinkedIn.'));return;}target.append(el('p','Token de: '+(p.member?.name||'Membro não informado pelo LinkedIn')+' · Aplicativo: '+(p.application_name||'Nome não informado')+' · Client ID '+(p.client_id||'não informado')+' · Validade: '+dt(p.expires_at)+' · Escopos:'));const list=el('p');for(const scope of p.scopes||[]){const write=['rw_ads','w_organization_social','rw_organization_admin','rw_conversions'].includes(scope);const item=el(write?'strong':'span',scope+(write?' (escrita)':'')+' ');list.append(item);}target.append(list);}
function connectionInput(){const d=new FormData(cf),i={connection_id:d.get('connection_id'),expected_revision:Number(d.get('expected_revision')),label:d.get('label'),token:d.get('token'),client_id:d.get('client_id'),client_secret:d.get('client_secret'),enabled:cf.elements.enabled.checked,users:[...users],retention_days:Number(d.get('retention_days')),expires_at:unix(d.get('expires')),clear_token:cf.elements.clear_token.checked,clear_client_secret:cf.elements.clear_client_secret.checked};i.retention_mode=d.get('retention_mode');if(i.retention_mode==='unlimited')delete i.retention_days;if(!meta){i.credential_notice_days=Number(d.get('credential_notice_days'));i.application_id=d.get('application_id');i.refresh_token=d.get('refresh_token');i.clear_refresh_token=cf.elements.clear_refresh_token.checked;if(d.get('refresh_expires'))i.refresh_expires_at=unix(d.get('refresh_expires'));}if(!meta)i.use_pending_authorization=cf.elements.use_pending_authorization.checked;return i;}
async function persistCandidate(input,msg){
 const stamp=editorEpoch, revision=identityEpoch;
 const result=await api('save-connection',input);
 await loadConnections();
 if(stamp!==editorEpoch || !iAmEditing(input.connection_id))return;
 if(revision!==identityEpoch){msg('A versão enviada foi salva. O formulário mudou durante o envio; reabra a conexão para conferir a revisão.',true);return;}
 editorUrl(result.connection.id,false);$('#f3-editor-heading').textContent='Editar conexão';
 setDirty(false);await edit(connection(result.connection.id)||result.connection);
 if(!iAmEditing(input.connection_id))return;
 credentialWarnings(result.warnings||[]);document.dispatchEvent(new CustomEvent('f3-linkedin-connection-saved'));
 msg('Conexão salva. Agendas atualizadas: '+(result.schedules_rebased?.length||0)+'. '+(result.grant_effects||[]).filter(g=>g.action&&g.status!=='reconfirmed').map(g=>g.consumer_id+': '+g.action).join(' '));
}
bind('#f3-connection','submit',(e,msg)=>persistCandidate(connectionInput(),msg));
bind('#f3-identity-preview','click',async()=>{clearIdentityPreview();const epoch=identityEpoch,input=connectionInput(),r=await api('save-connection',{...input,dry_run:true});if(epoch!==identityEpoch)return;identityPreview={input,confirmation:r.confirmation};const box=$('#f3-identity-preview-result');renderIdentity({identity:r.identity},box);if(r.credential_notice_policy)box.append(el('p','Antecedência do aviso: '+r.credential_notice_policy.before+' → '+r.credential_notice_policy.after+' dias.'));box.append(el('p',r.identity_change_required?'A identidade mudou ou não pôde ser comprovada como a mesma. Confira e confirme abaixo.':'A identidade não requer troca guiada. Este salvamento também pode ser confirmado abaixo.'));showGrantChoices(r.affected,r.identity_change_required);for(const schedule of r.affected.schedules)box.append(el('p','Agenda: '+schedule.label+' · revisão '+schedule.revision));for(const grant of r.affected.lead_grants)box.append(el('p','Lead Sync: '+grant.consumer_id+' · '+(grant.enabled?'ativo':'inativo')+' · '+grantStatus(grant.status)+(grant.action?' · '+grant.action:'')));for(const grant of r.affected.conversion_grants)box.append(el('p','Conversions API: conta '+grant.account_id+' · regra '+grant.conversion_id+' · '+(grant.enabled?'ativa':'inativa')+' · '+grantStatus(grant.status)+(grant.action?' · '+grant.action:'')));$('#f3-identity-confirm').disabled=false;});
bind('#f3-identity-confirm','click',async(e,msg)=>{if(!identityPreview)throw Error('Simule novamente antes de confirmar.');const p=identityPreview;await persistCandidate({...p.input,confirmation:p.confirmation,reconfirm_leads:cf.elements.reconfirm_leads.checked,reconfirm_conversions:cf.elements.reconfirm_conversions.checked},msg);});
bind('#f3-rotate','submit',async(e,msg)=>{const c=connection(cf.elements.connection_id.value);if(!c)throw Error('Escolha uma conexão salva em Editar conexão.');const f=$('#f3-rotate'),i={connection_id:c.id,expected_revision:Number(cf.elements.expected_revision.value),token:f.elements.token.value};if(f.elements.expires.value)i.expires_at=unix(f.elements.expires.value);await api('rotate-token',i);f.reset();await loadConnections();await edit(connection(c.id));msg('Token validado e substituído. Agendas preservadas.');});
// Asset selection has an immutable revision and preserves unseen selected entries.
function drawAssetChoices(box,rows,set,noun='Ativo'){box.replaceChildren();for(const row of rows.values())checkChoice(box,row.id,named(row,noun),set.has(String(row.id)),on=>{on?set.add(String(row.id)):set.delete(String(row.id));setDirty(true);});}
async function assetEditor(){const epoch=++assetsEpoch,c=connection($('#f3-assets-connection').value),root=$('#f3-asset-options');root.replaceChildren();$('#f3-connection-forms')?.replaceChildren();assetEdit=null;if(!c){$('#f3-assets-state').textContent='Salve uma conexão para escolher ativos.';return;}const state={id:c.id,revision:c.revision,sets:{},rows:{},forms:Object.fromEntries(Object.entries(c.forms||{}).map(([k,v])=>[k,new Set(v)])),formRows:{},allForms:new Set(c.all_forms_accounts||[]),interval:c.lead_discovery_interval_minutes||60};assetEdit=state;$('#f3-assets-state').textContent='A seleção salva está disponível. Carregue os nomes e descubra novos ativos por canal.';
for(const ch of cfg.channels){state.sets[ch]=new Set(c.assets[ch]||[]);state.rows[ch]=new Map((c.assets[ch]||[]).map(id=>[id,{id,name:null}]));const box=el('fieldset'),list=el('div'),status=el('p');list.className='f3-choices';box.append(el('legend',label(ch)),list,status);root.append(box);drawAssetChoices(list,state.rows[ch],state.sets[ch]);let cursor=null,offset=0;
const load=async discovery=>{status.textContent=discovery?'Consultando ativos disponíveis…':'Carregando nomes dos ativos salvos…';try{const r=await api('admin-options',discovery?{kind:'assets',connection_id:c.id,channel:ch,...(cursor?{cursor}:{})}:{kind:'selected',connection_id:c.id,channel:ch,offset});if(epoch!==assetsEpoch)return;if(r.connection_revision!==c.revision)throw Error('A conexão mudou. Reabra a seleção antes de salvar.');r.rows.forEach(row=>state.rows[ch].set(String(row.id),row));drawAssetChoices(list,state.rows[ch],state.sets[ch]);if(discovery){cursor=r.next_cursor;more.hidden=!cursor;}else{offset=r.next_offset;namesMore.hidden=offset===null;}status.textContent=r.rows.length?'Lista carregada. Novos ativos só serão incluídos se você os marcar.':'A origem não retornou ativos nesta página.';}catch(e){if(epoch===assetsEpoch)status.textContent='Não foi possível completar a lista. A seleção foi conservada. '+e.message;}};
button(box,'Carregar ativos disponíveis',async()=>{cursor=null;await load(true);});const more=button(box,'Carregar mais ativos',()=>load(true));more.hidden=true;button(box,'Carregar nomes selecionados',()=>{offset=0;return load(false);});const namesMore=button(box,'Carregar mais nomes',()=>load(false));namesMore.hidden=true;if(state.sets[ch].size)load(false);
}
if(!meta){const intervalLabel=el('label','Intervalo de descoberta em minutos'),interval=el('input');interval.type='number';interval.min='5';interval.max='1440';interval.value=state.interval;interval.id='f3-lead-discovery-interval';interval.addEventListener('input',()=>{state.interval=Number(interval.value);setDirty(true);});intervalLabel.append(interval);$('#f3-connection-forms').append(intervalLabel);for(const account of c.assets.leads){const box=el('fieldset'),list=el('div'),status=el('p');list.className='f3-choices';box.append(el('legend','Formulários da conta selecionada'),list,status);$('#f3-connection-forms').append(box);const automatic=el('input'),autoLabel=el('label','Todos os formulários da conta, inclusive novos');automatic.type='checkbox';automatic.className='f3-all-forms';automatic.dataset.account=account;automatic.checked=state.allForms.has(account);automatic.addEventListener('change',()=>{automatic.checked?state.allForms.add(account):state.allForms.delete(account);setDirty(true);});autoLabel.prepend(automatic);box.prepend(autoLabel);const set=state.forms[account]||(state.forms[account]=new Set()),rows=new Map([...set].map(id=>[id,{id,name:null}]));state.formRows[account]=rows;drawAssetChoices(list,rows,set,'Formulário');let offset=0;const load=async()=>{status.textContent='Carregando formulários…';try{const r=await api('admin-options',{kind:'forms',connection_id:c.id,channel:'leads',account_id:account,offset});if(epoch!==assetsEpoch)return;if(r.connection_revision!==c.revision)throw Error('Conexão alterada. Reabra a seleção.');r.rows.forEach(x=>rows.set(String(x.id),x));box.querySelector('legend').textContent='Formulários · '+(r.account_name||'Conta selecionada ('+account+')');drawAssetChoices(list,rows,set,'Formulário');offset=r.next_offset;more.hidden=offset===null;status.textContent=r.rows.length?'Marque os formulários permitidos.':'Nenhum formulário retornado.';}catch(e){status.textContent='Seleções conservadas. '+e.message;}};button(box,'Carregar formulários',()=>{offset=0;return load();});const more=button(box,'Carregar mais formulários',load);more.hidden=true;}}
}
bind('#f3-assets-connection','change',assetEditor);
bind('#f3-save-assets','click',async(e,msg)=>{const s=assetEdit;if(!s)throw Error('Selecione uma conexão salva.');const i={connection_id:s.id,expected_revision:s.revision,assets:Object.fromEntries(Object.entries(s.sets).map(([k,v])=>[k,[...v]]))};if(!meta){i.forms=Object.fromEntries([...s.sets.leads].map(id=>[id,[...(s.forms[id]||[])]]));i.all_forms_accounts=[...s.allForms].filter(id=>s.sets.leads.has(id));i.lead_discovery_interval_minutes=s.interval;const preview=await api('save-connection',{...i,dry_run:true});const grants=[...preview.affected.lead_grants,...preview.affected.conversion_grants];if(!window.confirm('Confirmar ativos e formulários? Contas com seleção automática: '+(i.all_forms_accounts.join(', ')||'nenhuma')+'. '+grants.filter(g=>g.enabled).map(g=>g.consumer_id+': '+grantStatus(g.status)+(g.action?' — '+g.action:'')).join(' ')))return;i.confirmation=preview.confirmation;for(const field of ['reconfirm_leads','reconfirm_conversions'])if(grants.some(g=>g.reconfirm_field===field&&g.can_reconfirm&&['already_stale','requires_reconfirmation'].includes(g.status)))i[field]=window.confirm('Reconfirmar agora as concessões afetadas de '+(field==='reconfirm_leads'?'Lead Sync':'Conversions API')+'? Serão conferidos os escopos e recursos necessários.');}const result=await api('save-connection',i);setDirty(false);await loadConnections();await assetEditor();msg('Ativos e formulários salvos. '+(result.grant_effects||[]).filter(g=>g.action&&g.status!=='reconfirmed').map(g=>g.consumer_id+': '+g.action).join(' '));});
// Report context is loaded only for the section that needs it.
function reportsFor(ch){return cfg.reports.filter(r=>meta?(ch==='facebook'?r.startsWith('page_')||['post_insights','video_insights'].includes(r):!r.startsWith('page_')&&!['post_insights','video_insights'].includes(r)):(ch==='ads'?['ad_accounts','campaign_groups','campaigns','creatives','ad_analytics'].includes(r):!['ad_accounts','campaign_groups','campaigns','creatives','ad_analytics'].includes(r)));}
async function context(){
 const labelName=qf.elements.account_id.closest('label').querySelector('span');
 if(labelName)labelName.textContent=qf.elements.channel.value==='pages'?'Página autorizada':'Conta de anúncios autorizada';
 const epoch=++contextEpoch,c=connection(qf.elements.connection_id.value),ch=qf.elements.channel.value,select=qf.elements.account_id;const reports=reportsFor(ch);options(qf.elements.report,reports.map(r=>({value:r,label:label(r)})),qf.elements.report.value);options(select,[],null,c?.assets[ch]?.length?'Carregando nomes dos ativos…':'Escolha ativos na aba Ativos');select.disabled=true;$('#f3-context-state').textContent=c?'Carregando esta seleção…':'Cadastre uma conexão para consultar.';objectPage=campaignPage=null;$('#f3-campaign-options')?.replaceChildren();if(!c){await fields();return;}
let offset=0,rows=[];try{do{const r=await api('admin-options',{kind:'selected',connection_id:c.id,channel:ch,offset});if(epoch!==contextEpoch)return;rows.push(...r.rows);offset=r.next_offset;}while(offset!==null);options(select,rows.map(r=>({value:r.id,label:named(r)})));select.disabled=false;contextLoaded=true;$('#f3-context-state').textContent=rows.length?'Ativos autorizados desta conexão.':'Nenhum ativo selecionado. Abra Ativos para escolher.';}catch(e){if(epoch!==contextEpoch)return;options(select,(c.assets[ch]||[]).map(id=>({value:id,label:'Ativo selecionado · nome indisponível ('+id+')'})));select.disabled=false;$('#f3-context-state').textContent='Não foi possível carregar os nomes. '+e.message;}if(epoch===contextEpoch)await fields();}
function control(name,visible){const n=qf.elements[name];if(!n)return;n.disabled=!visible;n.closest('label').hidden=!visible;}
async function fields(){const epoch=++fieldsEpoch,report=qf.elements.report.value;objectPage=campaignPage=null;$('#f3-object-more').hidden=true;$('#f3-object-state').textContent='';$('#f3-campaign-options')?.replaceChildren();$('#f3-campaign-more')?.setAttribute('hidden','');if(meta){control('granularity',['account_insights','page_insights'].includes(report));control('media_id',report==='media_insights');control('entity_id',['post_insights','video_insights'].includes(report));control('iterate_media',report==='media_insights');control('breakdown',report==='audience');control('timeframe',report==='audience');if(report==='audience')qf.elements.timeframe.value='this_month';}else{control('pivot',report==='ad_analytics');control('granularity',report==='ad_analytics');$('#f3-campaign-filter').hidden=report!=='ad_analytics';}$('#f3-fields').replaceChildren();if(!report)return;$('#f3-fields-state').textContent='Carregando os campos deste relatório…';try{const i={report};if(qf.elements.connection_id.value)i.connection_id=qf.elements.connection_id.value;const r=await api('list-fields',i);if(epoch!==fieldsEpoch)return;for(const f of r.fields){const l=checkChoice($('#f3-fields'),f.name,label(f.name),false,()=>{});if(f.availability_reason)l.title=f.availability_reason;}$('#f3-fields-state').textContent='Selecione os campos desejados ou mantenha os padrões. Métricas dependem da disponibilidade da origem.';}catch(e){if(epoch===fieldsEpoch)$('#f3-fields-state').textContent=e.message;}if(meta&&['media_insights','post_insights','video_insights'].includes(report)&&epoch===fieldsEpoch)await loadObjects(false,epoch);}
function base(){const c=qf.elements.connection_id.value,ch=qf.elements.channel.value,a=qf.elements.account_id.value;if(!c||!ch||!a)throw Error('Escolha uma conexão e um ativo autorizado.');return {connection_id:c,channel:ch,account_id:a};}
async function loadObjects(more=false,epoch=fieldsEpoch){const report=qf.elements.report.value,source=report==='stories_insights'?'stories':report==='post_insights'?'page_posts':report==='video_insights'?'page_videos':'media',target=qf.elements[source==='media'||source==='stories'?'media_id':'entity_id'];target.disabled=true;$('#f3-object-state').textContent='Carregando objetos pelo nome…';try{const r=await api('admin-options',{kind:'objects',...base(),report:source,...(more&&objectPage?{cursor:objectPage}:{})});if(epoch!==fieldsEpoch)return;const old=more?[...target.options].filter(o=>o.value).map(o=>({value:o.value,label:o.textContent})):[];options(target,[...old,...r.rows.map(row=>({value:row.id,label:named(row,'Objeto')}))]);objectPage=r.next_cursor;$('#f3-object-more').hidden=!objectPage;$('#f3-object-state').textContent=r.rows.length?'Escolha o objeto pelo nome.':'Nenhum objeto disponível neste recorte.';}catch(e){if(epoch===fieldsEpoch){options(target,[],null,'Lista indisponível');$('#f3-object-state').textContent=e.message;}}finally{if(epoch===fieldsEpoch)target.disabled=false;}}
async function campaigns(more=false){const epoch=fieldsEpoch;$('#f3-object-state').textContent='Carregando campanhas…';const r=await api('admin-options',{kind:'objects',...base(),report:'campaigns',...(more&&campaignPage?{cursor:campaignPage}:{})});if(epoch!==fieldsEpoch)return;if(!more)$('#f3-campaign-options').replaceChildren();r.rows.forEach(row=>checkChoice($('#f3-campaign-options'),row.id,named(row,'Campanha'),false,()=>{}));campaignPage=r.next_cursor;$('#f3-campaign-more').hidden=!campaignPage;$('#f3-object-state').textContent=r.rows.length?'Campanhas carregadas.':'Nenhuma campanha retornada.';}
function qvalue(){const q={...base(),report:qf.elements.report.value,limit:Number(qf.elements.limit.value),fields:[...$('#f3-fields').querySelectorAll('input:checked')].map(x=>x.value)};for(const k of ['date_from','date_to','granularity','media_id','entity_id','breakdown','timeframe','pivot']){const n=qf.elements[k];if(n&&!n.disabled&&n.value)q[k]=n.value;}if(qf.elements.iterate_media&&!qf.elements.iterate_media.disabled&&qf.elements.iterate_media.checked){q.iterate_media=true;delete q.media_id;}if(!meta&&q.report==='ad_analytics'){const ids=[...$('#f3-campaign-options').querySelectorAll('input:checked')].map(x=>x.value);if(ids.length)q.campaign_ids=ids;}return q;}
function show(data){next=data.next_cursor;$('#f3-next').hidden=!next;const box=$('#f3-coverage');box.replaceChildren(el('p','Cobertura do plano: '+(data.coverage.complete?'concluída sem erro registrado':label(data.coverage.stop_reason))+'. A origem não garante histórico integral.'));for(const w of data.warnings||[])box.append(el('p',w));if(data.coverage.errors?.length){const d=el('div');pretty(d,data.coverage.errors);box.append(d);}table($('#f3-result'),data.rows);}
bind('#f3-query','submit',async(e,msg)=>{lastQuery=qvalue();msg('Consultando a página selecionada…');show(await api('query',lastQuery));msg('Consulta concluída. Confira a cobertura e os avisos.');});bind('#f3-next','click',async()=>show(await api('query',{...lastQuery,cursor:next})));
for(const k of ['connection_id','channel'])qf.elements[k].addEventListener('change',task(context));qf.elements.account_id.addEventListener('change',task(fields));qf.elements.report.addEventListener('change',task(fields));bind('#f3-object-more','click',()=>loadObjects(true));bind('#f3-campaign-load','click',()=>campaigns());bind('#f3-campaign-more','click',()=>campaigns(true));
async function download(job,format){const r=await api('export',{job_id:job.job_id,format,idempotency_key:uuid(),allow_partial:job.status!=='complete'}),chunks=[];let offset=0;do{const part=await api('export-read',{export_id:r.export_id,offset_bytes:offset});chunks.push(Uint8Array.from(atob(part.content_base64),c=>c.charCodeAt(0)));offset=part.next_offset;}while(offset!==null);downloadBlob(chunks,format,r.filename);}
function downloadBlob(chunks,format,name){const url=URL.createObjectURL(new Blob(chunks,{type:format==='json'?'application/json':'text/csv'})),a=el('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function jobs(offset=0,append=false){const root=$('#f3-job-list');if(!append)root.replaceChildren(el('p','Carregando coletas locais…'));const r=await api('list-jobs',{offset});if(!append)root.replaceChildren();if(!r.jobs.length)root.append(el('p','Nenhuma coleta registrada.'));for(const j of r.jobs){const box=el('div');box.className='f3-card';box.append(el('strong',label(j.query.report)+' · '+label(j.status)),el('p',`${j.pages} páginas · ${j.rows} linhas · Próxima execução: ${dt(j.next_at)}`));if(j.last_code)box.append(el('p','Último retorno: '+j.last_code));if(['queued','retry'].includes(j.status)){button(box,'Avançar agora',async()=>{await api('run-job',{job_id:j.job_id});await jobs();});button(box,'Pausar',async()=>{await api('control-job',{job_id:j.job_id,expected_revision:j.revision,action:'pause'});await jobs();});}if(j.status==='paused')button(box,'Retomar',async()=>{await api('control-job',{job_id:j.job_id,expected_revision:j.revision,action:'resume'});await jobs();});if(!['complete','partial','cancelled'].includes(j.status))button(box,'Cancelar',async()=>{await api('control-job',{job_id:j.job_id,expected_revision:j.revision,action:'cancel'});await jobs();});if(j.pages){button(box,'Ver primeira página',async()=>{const r=await api('job-results',{job_id:j.job_id});show(r.data);$('#f3-next').hidden=true;await tab('reports');});for(const f of ['csv','json'])button(box,'Baixar '+f.toUpperCase()+(j.status==='complete'?'':' (parcial)'),()=>download(j,f));}root.append(box);}if(r.next_offset!==null){const b=button(root,'Carregar mais coletas',async()=>{b.remove();await jobs(r.next_offset,true);});}if(!append)await schedules();}
async function schedules(){const r=await api('list-schedules'),root=$('#f3-schedule-list');root.replaceChildren();for(const s of r.schedules){const box=el('div');box.className='f3-card';box.append(el('strong',(s.label||'Agenda existente')+' · '+(s.enabled?'Ativa':'Pausada')),el('p','Próxima execução: '+dt(s.next_at)+' · A cada '+s.interval_minutes+' minutos'));if(s.last_code)box.append(el('p','Último retorno: '+s.last_code));button(box,'Editar agenda',async(e,msg)=>{qf.elements.connection_id.value=s.query.connection_id;qf.elements.channel.value=s.query.channel;await context();qf.elements.account_id.value=s.query.account_id;qf.elements.report.value=s.query.report;await fields();for(const [k,v]of Object.entries(s.query)){const n=qf.elements[k];if(n&&k!=='fields'&&k!=='campaign_ids'){if(n.type==='checkbox')n.checked=!!v;else n.value=v;}}all('#f3-fields input').forEach(n=>n.checked=(s.query.fields||[]).includes(n.value));const f=$('#f3-schedule');f.elements.schedule_id.value=s.schedule_id;f.elements.expected_revision.value=s.revision;f.elements.label.value=s.label||'Agenda existente';for(const k of ['interval_minutes','lookback_days'])f.elements[k].value=s[k];f.elements.next_at.value=dateInput(s.next_at);f.dataset.nextAt=String(s.next_at);f.dataset.enabled=String(s.enabled);f.dataset.query=JSON.stringify(s.query);msg('Agenda carregada. A consulta salva será preservada nesta edição. Para uma consulta diferente, crie uma nova agenda.');});button(box,s.enabled?'Pausar agenda':'Ativar agenda',async()=>{await api('save-schedule',{schedule_id:s.schedule_id,label:s.label||'Agenda existente',expected_revision:s.revision,query:s.query,enabled:!s.enabled,interval_minutes:s.interval_minutes,lookback_days:s.lookback_days});await schedules();});root.append(box);}}
function newSchedule(){const f=$('#f3-schedule');f.reset();f.elements.schedule_id.value='agenda-'+uuid();f.elements.expected_revision.value=0;delete f.dataset.query;delete f.dataset.enabled;delete f.dataset.nextAt;}
bind('#f3-refresh-jobs','click',()=>jobs());bind('#f3-new-schedule','click',newSchedule);bind('#f3-schedule','submit',async(e,msg)=>{const f=$('#f3-schedule'),d=new FormData(f),i={schedule_id:d.get('schedule_id'),label:d.get('label'),expected_revision:Number(d.get('expected_revision')),query:f.dataset.query?JSON.parse(f.dataset.query):qvalue(),enabled:f.dataset.enabled!=='false',interval_minutes:Number(d.get('interval_minutes')),lookback_days:Number(d.get('lookback_days'))};if(d.get('next_at')&&d.get('next_at')!==dateInput(f.dataset.nextAt))i.next_at=unix(d.get('next_at'));await api('save-schedule',i);newSchedule();await schedules();msg('Agenda salva. A execução depende do cron do site.');});
bind('#f3-collect','click',async(e,msg)=>{await api('create-job',{query:qvalue(),idempotency_key:uuid()});msg('Coleta criada.');await tab('jobs');});bind('#f3-backfill','click',async(e,msg)=>{const r=await api('create-backfill',{query:qvalue(),idempotency_key:uuid()});msg('Coleta histórica criada até '+(r.backfill?.frozen_until||r.frozen_until)+'.'+(r.backfill?.window_adjusted?' O período foi ajustado à janela disponível do LinkedIn.':''));await tab('jobs');});
async function grants(){const root=$('#f3-grants');root.replaceChildren(el('p','Carregando concessões locais…'));let r=await api('list-grants');const consumers=r.consumers;grantsRows=r.grants;while(r.next_offset!==null){r=await api('list-grants',{offset:r.next_offset});grantsRows.push(...r.grants);}options($('#f3-grant').elements.consumer_id,consumers.map(c=>({value:c.id,label:c.label||c.id})),$('#f3-grant').elements.consumer_id.value,'Nenhum consumidor registrado neste site');table(root,grantsRows,'Nenhuma concessão de formulários cadastrada neste site.');await grantSelection();}
async function grantSelection(){const epoch=++grantEpoch,f=$('#f3-grant'),c=connection(f.elements.connection_id.value),existing=grantsRows.find(g=>g.consumer_id===f.elements.consumer_id.value&&g.connection_id===c?.id);f.elements.expected_revision.value=existing?.revision||0;f.elements.enabled.checked=existing?.enabled??true;f.elements.callback_url.value=existing?.callback_url||'';all('#f3-grant [name="permission"]').forEach(i=>i.checked=(existing?.permissions||[]).includes(i.value));grantForms={};grantAll=new Set(existing?.all_forms_accounts||[]);const box=$('#f3-grant-forms');box.replaceChildren();if(!c)return;if(existing&&existing.credential_revision!==c.revision)box.append(el('p','A conexão mudou. Revise e salve novamente: somente os formulários ainda autorizados aparecem nesta seleção.')); for(const account of c.assets.leads){const group=el('fieldset');group.append(el('legend','Formulários autorizados da conta'));if((c.all_forms_accounts||[]).includes(account)){const automatic=el('input'),autoLabel=el('label','Todos os formulários da conta, inclusive novos; criar webhook automaticamente');automatic.type='checkbox';automatic.className='f3-grant-all-forms';automatic.dataset.account=account;automatic.checked=grantAll.has(account);automatic.addEventListener('change',()=>{automatic.checked?grantAll.add(account):grantAll.delete(account);setDirty(true);});autoLabel.prepend(automatic);group.append(autoLabel);}const list=el('div'),state=el('p');list.className='f3-choices';group.append(list,state);box.append(group);const set=new Set((existing?.forms?.[account]||[]).filter(id=>(c.forms?.[account]||[]).includes(id))); grantForms[account]=set;const rows=new Map((c.forms?.[account]||[]).map(id=>[id,{id,name:null}]));drawAssetChoices(list,rows,set,'Formulário');let offset=0;const load=async()=>{state.textContent='Carregando nomes dos formulários…';try{const r=await api('admin-options',{kind:'forms',connection_id:c.id,channel:'leads',account_id:account,offset});if(epoch!==grantEpoch)return;r.rows.filter(row=>rows.has(String(row.id))).forEach(row=>rows.set(String(row.id),row));group.querySelector('legend').textContent='Formulários autorizados · '+(r.account_name||'Conta selecionada ('+account+')');drawAssetChoices(list,rows,set,'Formulário');offset=r.next_offset;more.hidden=offset===null;state.textContent='Somente os formulários autorizados na conexão podem ser concedidos.';}catch(e){state.textContent='Seleção conservada. '+e.message;}};button(group,'Carregar nomes dos formulários',()=>{offset=0;return load();});const more=button(group,'Carregar mais nomes',load);more.hidden=true;if(rows.size)load();}}
for(const k of ['consumer_id','connection_id'])$('#f3-grant')?.elements[k].addEventListener('change',task(grantSelection));
bind('#f3-grant','submit',async(e,msg)=>{const f=$('#f3-grant'),d=new FormData(f);const input={consumer_id:d.get('consumer_id'),connection_id:d.get('connection_id'),expected_revision:Number(d.get('expected_revision')),enabled:f.elements.enabled.checked,permissions:d.getAll('permission'),forms:Object.fromEntries(Object.entries(grantForms).map(([k,v])=>[k,[...v]])),callback_url:d.get('callback_url'),all_forms_accounts:[...grantAll]};const old=grantsRows.find(g=>g.consumer_id===input.consumer_id&&g.connection_id===input.connection_id);if(input.permissions.includes('ad_source')||(old?.permissions||[]).includes('ad_source')||grantAll.size||input.permissions.includes('campaign_lookup')||(old?.permissions||[]).includes('campaign_lookup')||JSON.stringify(input.all_forms_accounts)!==JSON.stringify(old?.all_forms_accounts||[])){const preview=await api('save-grant',{...input,dry_run:true});if(!window.confirm('Confirmar permissões: '+input.permissions.map(p=>p==='ad_source'?'leitura da origem de anúncios das contas concedidas':p==='campaign_lookup'?'consulta de campanha vinculada ao lead':(labels[p]||p)).join(', ')+'. Contas com formulários automáticos: '+(input.all_forms_accounts.join(', ')||'nenhuma')+'. A seleção automática cria webhooks na callback informada.'))return;input.confirmation=preview.confirmation;}await api('save-grant',input);setDirty(false);await grants();msg('Concessão salva para a revisão atual da conexão.');});
async function journal(more=false){const epoch=++journalEpoch,f=$('#f3-subscription-journal');if(!f.elements.connection_id.value)return;const r=await api('admin-options',{kind:'journal',connection_id:f.elements.connection_id.value,channel:'leads',offset:more?(journalOffset||0):0});if(epoch!==journalEpoch)return;journalRows=more?[...journalRows,...r.rows]:r.rows;journalOffset=r.next_offset;options(f.elements.ownership_key,journalRows.map(row=>({value:row.id,label:row.name+' · '+label(row.state)})),f.elements.ownership_key.value,'Nenhuma operação administrativa nesta conexão');$('#f3-journal-more').hidden=journalOffset===null;journalChoice();}
function journalChoice(){const f=$('#f3-subscription-journal'),row=journalRows.find(r=>r.id===f.elements.ownership_key.value);f.elements.account_id.value=row?.account_id||'';f.elements.expected_operation_revision.value=row?.operation_revision??'';f.elements.authorize_current_context.checked=false;}
function journalInput(){const f=$('#f3-subscription-journal');if(!f.elements.ownership_key.value)throw Error('Escolha uma operação administrativa existente.');return {connection_id:f.elements.connection_id.value,account_id:f.elements.account_id.value,ownership_key:f.elements.ownership_key.value};}
bind('#f3-journal-refresh','click',()=>journal());bind('#f3-journal-more','click',()=>journal(true));$('#f3-subscription-journal')?.elements.connection_id.addEventListener('change',task(()=>journal()));$('#f3-subscription-journal')?.elements.ownership_key.addEventListener('change',journalChoice);
bind('#f3-subscription-journal','submit',async()=>{const r=await api('lead-get-subscription-operation',journalInput());$('#f3-subscription-journal').elements.expected_operation_revision.value=r.operation_revision;pretty($('#f3-subscription-result'),r);});bind('#f3-subscription-reconcile','click',async()=>{const f=$('#f3-subscription-journal'),r=await api('lead-reconcile-subscription',{...journalInput(),expected_operation_revision:Number(f.elements.expected_operation_revision.value),authorize_current_context:f.elements.authorize_current_context.checked});f.elements.expected_operation_revision.value=r.operation_revision;pretty($('#f3-subscription-result'),r);});
function historySelection(){if(!meta&&!['page_statistics','share_statistics','follower_statistics','ad_analytics'].includes(qf.elements.report.value))throw Error('Escolha Estatísticas da Página, publicações, seguidores ou Análise de anúncios para consultar o histórico diário.');const v={...base(),report:qf.elements.report.value,limit:50};for(const k of ['date_from','date_to'])if(qf.elements[k].value)v[k]=qf.elements[k].value;return v;}
function historyShow(r){historyNext=r.next_cursor;$('#f3-history-next').hidden=!historyNext;table($('#f3-history-result'),r.rows,'Nenhum registro local neste período e seleção.');pretty($('#f3-history-status'),{migration_complete:r.migration_complete,coverage:r.coverage,retention:r.retention});}
bind('#f3-history-query','click',async()=>{historyQuery=historySelection();historyShow(await api('history-query',historyQuery));});bind('#f3-history-next','click',async()=>historyShow(await api('history-query',{...historyQuery,cursor:historyNext})));bind('#f3-history-migrate','click',async()=>pretty($('#f3-history-status'),await api('history-migrate')));
async function downloadHistory(format,msg){let r=await api('history-export',{query:historySelection(),format,idempotency_key:uuid()});while(r.state==='queued'){r=await api('history-export-step',{export_id:r.export_id});msg('Preparando exportação: '+r.rows+' linhas.');}if(r.state!=='complete')throw Error('Exportação interrompida: '+(r.last_code||r.state));const chunks=[];for(let part=0;part<r.parts;part++){let at=0;do{const chunk=await api('history-export-read',{export_id:r.export_id,part,offset_bytes:at});chunks.push(Uint8Array.from(atob(chunk.content_base64),c=>c.charCodeAt(0)));at=chunk.next_offset;}while(at!==null);}downloadBlob(chunks,format,r.filename);msg('Exportação concluída.');}
for(const f of ['csv','json'])bind('#f3-history-'+f,'click',(e,msg)=>downloadHistory(f,msg));
// Local diagnostics and a supplier validation have independent targets and generations.
let diagnosticEpoch=0,remoteEpoch=0;
const dx={connection:$('#f3-diagnostic-connection'),channel:$('#f3-diagnostic-channel'),account:$('#f3-diagnostic-account'),local:$('#f3-diagnostic-result'),remote:$('#f3-diagnostic-remote')};
function selectedDiagnostic(){return {connection_id:dx.connection.value,channel:dx.channel.value,account_id:dx.account.value};}
function diagnosticChoices(){
 ++remoteEpoch;dx.remote.replaceChildren();
 const previous=dx.connection.value;
 options(dx.connection,[{value:'',label:'Escolha uma conexão'},...connections.map(c=>({value:c.id,label:c.label}))],previous);
 if(!previous&&connections.length===1)dx.connection.value=connections[0].id;
 options(dx.channel,cfg.channels.map(ch=>({value:ch,label:label(ch)})),dx.channel.value||'pages');
 const c=connection(dx.connection.value),ids=c?.assets?.[dx.channel.value]||[],old=dx.account.value;
 options(dx.account,[{value:'',label:'Escolha um ativo'},...ids.map(id=>({value:String(id),label:'ID '+id}))],old);
 if(!dx.account.value&&ids.length===1)dx.account.value=String(ids[0]);
 dx.account.disabled=!ids.length;$('#f3-validate').disabled=!c?.enabled||!dx.account.value;
 $('#f3-diagnostic-selection').textContent=!c?'Escolha a conexão que deseja verificar.':!c.enabled?'A conexão está pausada.':!ids.length?'Nenhum ativo deste canal está selecionado. Confira a aba Ativos.':'A lista usa os identificadores salvos; o fornecedor só é consultado ao validar.';
}
dx.connection.addEventListener('change',diagnosticChoices);dx.channel.addEventListener('change',diagnosticChoices);dx.account.addEventListener('change',diagnosticChoices);
function diagnosticDetails(host,data){
 const details=el('details'),body=el('div');details.append(el('summary','Ver detalhes técnicos'),body);
 details.addEventListener('toggle',()=>{if(details.open&&!body.childNodes.length)pretty(body,data);});host.append(details);
}
async function localDiagnostic(op){
 const stamp=++diagnosticEpoch;dx.local.replaceChildren(el('p','Consultando o WordPress…'));
 let r;try{r=await api(op);}catch(err){if(stamp===diagnosticEpoch)dx.local.replaceChildren(el('p',err.message));return;}
 if(stamp!==diagnosticEpoch||activeTab!=='diagnostics')return;dx.local.replaceChildren();
 if(op==='selftest'){const checks=r.checks||[],passed=checks.filter(c=>c.state==='ok').length;
  dx.local.append(el('h3',r.local_checks_ok?'Autoteste local aprovado':'Confira as verificações locais'),el('p',passed+' de '+checks.length+' verificações locais aprovadas. O acesso ao LinkedIn não foi testado.'));
 }else{
  const issues=r.issues||[];dx.local.append(el('h3',r.state==='ok'?'Estado do worker: normal':'Estado do worker: requer atenção'),el('p',r.connection_count+(r.connection_count===1?' conexão':' conexões')+' · '+r.active_schedules+(r.active_schedules===1?' agenda ativa':' agendas ativas')+' · '+dt(r.observed_at)));
  dx.local.append(el('p','Armazenamento: '+(r.storage_ready?'disponível':'indisponível')+' · Criptografia: '+(r.crypto_ready?'disponível':'indisponível')+'.'));
  for(const i of issues)dx.local.append(el('p',(i.label?i.label+': ':'')+(i.action||i.code)));
  for(const c of r.access_lifecycle?.connections||[])if(c.incident)dx.local.append(el('p',(connection(c.connection_id)?.label||c.connection_id)+': '+(c.incident.message||c.incident.code)));
 }diagnosticDetails(dx.local,r);
}
bind('#f3-selftest','click',()=>localDiagnostic('selftest'));bind('#f3-status','click',()=>localDiagnostic('status'));
bind('#f3-validate','click',async()=>{
 const i=selectedDiagnostic(),stamp=++remoteEpoch;if(!i.connection_id||!i.account_id)throw Error('Escolha a conexão e o ativo autorizado.');
 dx.remote.replaceChildren(el('p','Consultando os metadados do ativo…'));
 let r;try{r=await api('validate-connection',i);}catch(err){if(stamp===remoteEpoch)dx.remote.replaceChildren(el('p',err.message));return;}
 if(stamp!==remoteEpoch||activeTab!=='diagnostics')return;
 dx.remote.replaceChildren(el('h3','Metadados verificados'),el('p',label(i.channel)+' · ativo '+i.account_id+' · '+(connection(i.connection_id)?.label||i.connection_id)+'.'));diagnosticDetails(dx.remote,r);
});
const vf=$('#f3-api-version'),versionResult=$('#f3-api-version-result');let versionPreview=null,versionEpoch=0;
function clearVersionPreview(){versionEpoch++;versionPreview=null;$('#f3-api-version-confirm').disabled=true;versionResult.replaceChildren();}
vf.addEventListener('input',e=>{if(!e.target.matches('[data-version-reconfirm]'))clearVersionPreview();});
vf.elements.connection_id.addEventListener('change',()=>{clearVersionPreview();vf.elements.api_version.value=connection(vf.elements.connection_id.value)?.api_version||cfg.apiVersion;});
bind('#f3-api-version','submit',async()=>{
 clearVersionPreview();const stamp=versionEpoch,c=connection(vf.elements.connection_id.value);if(!c)throw Error('Escolha uma conexão.');
 const input={connection_id:c.id,expected_revision:c.revision,api_version:vf.elements.api_version.value};
 const r=await api('save-connection',{...input,dry_run:true});if(stamp!==versionEpoch)return;
 versionPreview={input,confirmation:r.confirmation};versionResult.append(el('strong','Prévia: '+c.label+' · '+c.api_version+' → '+input.api_version));
 for(const [key,flag,title] of [['lead_grants','reconfirm_leads','Lead Sync'],['conversion_grants','reconfirm_conversions','Conversões']]){
  const grants=(r.affected?.[key]||[]).filter(g=>g.enabled);
  for(const g of grants)versionResult.append(el('p',title+' · '+g.consumer_id+': '+grantStatus(g.status)+(g.action?' · '+g.action:'')));
  const affected=grants.filter(g=>g.status!=='preserved');
  if(affected.length&&affected.every(g=>g.can_reconfirm)){const l=el('label'),box=el('input');box.type='checkbox';box.dataset.versionReconfirm=flag;l.append(box,document.createTextNode(' Reconfirmar '+title+' nesta alteração'));versionResult.append(l);}
 }
 versionResult.append(el('p','A configuração permanece igual até a confirmação.'));$('#f3-api-version-confirm').disabled=false;
});
bind('#f3-api-version-confirm','click',async(e,msg)=>{
 const p=versionPreview;if(!p)return;
 if(vf.elements.connection_id.value!==p.input.connection_id||vf.elements.api_version.value!==p.input.api_version||connection(p.input.connection_id)?.revision!==p.input.expected_revision){clearVersionPreview();throw Error('A seleção mudou. Simule a versão da API novamente.');}
 const flags=Object.fromEntries([...versionResult.querySelectorAll('[data-version-reconfirm]:checked')].map(n=>[n.dataset.versionReconfirm,true]));
 clearVersionPreview();const r=await api('save-connection',{...p.input,confirmation:p.confirmation,...flags});await loadConnections();
 msg('Versão da API salva. '+(r.grant_effects||[]).filter(g=>g.action&&g.status!=='reconfirmed').map(g=>g.action).join(' '));
});
let helpEpoch=0,manuals=new Map();
const docSelect=$('#f3-help-document'),docBody=$('#f3-help-content');
function describeManual(){
 ++helpEpoch;docBody.replaceChildren();
 $('#f3-help-description').textContent=manuals.get(docSelect.value)?.description||'';
}
docSelect.addEventListener('change',describeManual);
async function helpIndex(){
 const stamp=++helpEpoch,r=await api('documentation',{document:'index'});
 if(stamp!==helpEpoch||activeTab!=='help')return;
 const old=docSelect.value||'PRIMEIROS-PASSOS.md';
 manuals=new Map(r.documents.map(d=>[d.document,d]));
 docSelect.replaceChildren();
 for(const [key,title] of [['manual','Manuais'],['schema','Schemas'],['history','Histórico']]){
   const group=el('optgroup');group.label=title;
   for(const d of manuals.values()){
     const kind=(d.document.endsWith('.json')||d.kind==='schema')?'schema':(d.kind==='history'||/^(?:RELEASE-|CHANGELOG)/.test(d.document))?'history':'manual';
     if(kind!==key)continue;const option=el('option',d.title||d.document);option.value=d.document;group.append(option);
   }
   if(group.children.length)docSelect.append(group);
 }
 if(manuals.has(old))docSelect.value=old;describeManual();
}
// Only these inline constructs create elements. Raw HTML, unrecognized markup and unsafe links stay text.
function appendInline(parent,source){
 const pattern=/(`[^`\n]+`|\*\*[^*\n]+\*\*|\*[^*\n]+\*|\[[^\]\n]+\]\([^()\s]+\))/g;
 let at=0;
 for(const m of source.matchAll(pattern)){
   parent.append(document.createTextNode(source.slice(at,m.index)));const token=m[0];
   if(token[0]==='`')parent.append(el('code',token.slice(1,-1)));
   else if(token.startsWith('**'))parent.append(el('strong',token.slice(2,-2)));
   else if(token.startsWith('*'))parent.append(el('em',token.slice(1,-1)));
   else{
     const split=token.lastIndexOf(']('),name=token.slice(1,split),href=token.slice(split+2,-1);
     let url=null;try{url=new URL(href);}catch(_){}
     if(url?.protocol==='https:'&&!url.username&&!url.password){
       const a=el('a',name);a.href=url.href;a.rel='noopener noreferrer';a.target='_blank';parent.append(a);
     }else parent.append(document.createTextNode(name));
   }
   at=m.index+token.length;
 }
 parent.append(document.createTextNode(source.slice(at)));
}
function renderManual(target,source,isJson){
 target.replaceChildren();
 if(isJson){target.append(el('pre',source));return;}
 const fragment=document.createDocumentFragment(),lines=source.split(/\r?\n/);
 const cells=line=>line.trim().replace(/^\||\|$/g,'').split('|').map(c=>c.trim());
 const isSeparator=line=>/^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(line);
 const listMatch=line=>/^\s*(?:(\d+)\.|[-*+])\s+(.+)/.exec(line);
 let i=0;
 while(i<lines.length){
   const line=lines[i++];
   if(!line.trim())continue;
   if(/^\s*```/.test(line)){
     const block=[];while(i<lines.length&&!/^\s*```/.test(lines[i]))block.push(lines[i++]);if(i<lines.length)i++;
     const pre=el('pre');pre.append(el('code',block.join('\n')));fragment.append(pre);continue;
   }
   const h=/^(#{1,6})\s+(.+)/.exec(line);
   if(h){const node=el('h'+Math.min(6,h[1].length+1));appendInline(node,h[2]);fragment.append(node);continue;}
   if(i<lines.length&&line.includes('|')&&isSeparator(lines[i])){
     i++;const table=el('table'),head=el('thead'),hr=el('tr'),body=el('tbody'),wrap=el('div');wrap.className='f3-scroll';
     for(const v of cells(line)){const th=el('th');th.scope='col';appendInline(th,v);hr.append(th);}head.append(hr);
     while(i<lines.length&&lines[i].trim()&&lines[i].includes('|')){const tr=el('tr');for(const v of cells(lines[i++])){const td=el('td');appendInline(td,v);tr.append(td);}body.append(tr);}
     table.append(head,body);wrap.append(table);fragment.append(wrap);continue;
   }
   let entry=listMatch(line);
   if(entry){const ordered=!!entry[1],list=el(ordered?'ol':'ul');if(ordered)list.start=Number(entry[1]);for(;;){
     const li=el('li');appendInline(li,entry[2]);list.append(li);entry=i<lines.length?listMatch(lines[i]):null;
     if(!entry||!!entry[1]!==ordered)break;i++;
   }fragment.append(list);continue;}
   const paragraph=[line];while(i<lines.length&&lines[i].trim()&&!/^\s*(?:#{1,6}\s|```|\|)/.test(lines[i])&&!listMatch(lines[i]))paragraph.push(lines[i++]);
   const p=el('p');appendInline(p,paragraph.join(' '));fragment.append(p);
 }
 target.append(fragment);
}
bind('#f3-help-read','click',async(e,notify)=>{
 const id=docSelect.value,stamp=++helpEpoch,meta=manuals.get(id);if(!meta)throw Error('Escolha um documento do índice.');
 let offset=0,text='';
 do{
   const i={document:id,offset,limit_bytes:16384,expected_revision:meta.sha256},r=await api('documentation',i);
   if(stamp!==helpEpoch||activeTab!=='help')return;
   if(r.revision!==meta.sha256||r.offset!==offset||typeof r.content!=='string'||(r.next_offset!==null&&(!Number.isInteger(r.next_offset)||r.next_offset<=offset||r.next_offset>meta.bytes)))throw Error('A leitura divergiu do índice. Reabra a Ajuda.');
   text+=r.content;offset=r.next_offset;
 }while(offset!==null);
 if(new Blob([text]).size!==meta.bytes)throw Error('Documento incompleto. Reabra a Ajuda.');
 renderManual(docBody,text,id.endsWith('.json'));notify('Documento carregado: '+(meta.title||id)+'.');
});
function routeTab(){
 const u=new URL(location.href),id=u.searchParams.get('tab')||'connections';
 if(id==='assets' && ['#f3-conversions','#f3-stage-conversions'].includes(u.hash))return u.hash==='#f3-conversions'?'conversions':'stages';
 return id;
}
function contextSummary(){
 const selected=n=>qf.elements[n]?.selectedOptions?.[0]?.textContent;
 $('#f3-context-summary').textContent=[selected('connection_id'),selected('channel')].filter(Boolean).join(' · ');
}
qf.elements.channel.addEventListener('change',contextSummary);
qf.elements.connection_id.addEventListener('change',contextSummary);
let navEpoch=0;
async function tab(name,push=true){
 if(!all('[data-tab]').some(a=>a.dataset.tab===name))name='connections';
 if(push&&activeTab==='connections'&&!$('#f3-connection-editor').hidden&&!canDiscard())return;
 if(push || name!==activeTab)setDirty(false);
 const seq=++navEpoch;
 if(activeTab==='diagnostics'&&name!==activeTab){++diagnosticEpoch;++remoteEpoch;dx.local.replaceChildren();dx.remote.replaceChildren();}
 if(push||name!==activeTab){++actionSequence;++helpEpoch;msg('');}
 activeTab=name;cfg.tab=name;
 const group=all('[data-tab]').find(a=>a.dataset.tab===name).dataset.group;
 all('.f3-section').forEach(e=>e.hidden=e.id!=='f3-'+name);
 all('[data-subnav]').forEach(n=>n.hidden=n.dataset.subnav!==group);
 all('[data-tab]').forEach(a=>{
   const selected=a.hasAttribute('data-main')?a.dataset.group===group:a.dataset.tab===name;
   if(selected)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');
 });
 const ctx=$('#f3-context');ctx.hidden=!['reports','jobs','history'].includes(name);contextSummary();
 if(!ctx.hidden&&!ctx.dataset.initialized){ctx.open=window.innerWidth>782;ctx.dataset.initialized='1';}
 if(push){
   const u=new URL(location.href);u.searchParams.set('tab',name);u.searchParams.delete('connection');u.searchParams.delete('connection_id');u.searchParams.delete('new');u.hash='';history.pushState({tab:name},'',u);
 }
 if(name==='connections'){
   const u=new URL(location.href);await openEditor(u.searchParams.get('connection')||u.searchParams.get('connection_id')||(u.searchParams.get('new')==='1'?'@new':null),false);
 }else if(name==='diagnostics')diagnosticChoices();
 else if(name==='assets')await assetEditor();
 else if(['reports','jobs','history'].includes(name)){
   if(!contextLoaded)await context();if(seq!==navEpoch)return;
   if(name==='jobs')await jobs();
 }else if(name==='leads'){await grants();if(seq===navEpoch)await journal();}
 else if(name==='help')await helpIndex();
 else if(name==='retention')await retentionLoad();
 if(seq===navEpoch)document.dispatchEvent(new CustomEvent('f3-linkedin-panel',{detail:name}));
}
all('[data-tab]').forEach(a=>a.addEventListener('click',e=>{
 if(e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;task(()=>tab(a.dataset.tab))(e);
}));
window.addEventListener('popstate',()=>task(()=>tab(routeTab(),false))());
let retentionPreview=null,retentionEpoch=0;const rf=$('#f3-retention-form'),retentionResult=$('#f3-retention-result');
function invalidateRetention(){retentionEpoch++;retentionPreview=null;$('#f3-retention-save').disabled=true;retentionResult.textContent='';rf.elements.audit_days.disabled=rf.elements.audit_mode.value!=='finite';}
async function retentionLoad(){invalidateRetention();const stamp=retentionEpoch,r=await api('get-retention');if(stamp!==retentionEpoch)return;for(const k of ['audit_mode','audit_days'])rf.elements[k].value=r[k];rf.elements.expected_revision.value=r.revision;invalidateRetention();}
rf.addEventListener('input',invalidateRetention);rf.addEventListener('change',invalidateRetention);
bind('#f3-retention-form','submit',async()=>{
 invalidateRetention();const stamp=retentionEpoch,i={expected_revision:Number(rf.elements.expected_revision.value),audit_mode:rf.elements.audit_mode.value,dry_run:true};
 if(i.audit_mode==='finite')i.audit_days=Number(rf.elements.audit_days.value);
 const r=await api('save-retention',i);if(stamp!==retentionEpoch)return;
 retentionPreview=i;retentionResult.textContent=r.eligible_for_removal+' eventos poderão ser removidos na próxima manutenção. O histórico diário será preservado.';$('#f3-retention-save').disabled=false;
});
bind('#f3-retention-save','click',async()=>{
 if(!retentionPreview)return;const input=retentionPreview;invalidateRetention();
 if(input.audit_mode!==rf.elements.audit_mode.value||input.expected_revision!==Number(rf.elements.expected_revision.value)||(input.audit_mode==='finite'&&input.audit_days!==Number(rf.elements.audit_days.value)))throw Error('A política mudou. Simule novamente.');
 const r=await api('save-retention',{...input,dry_run:false});await retentionLoad();retentionResult.textContent=r.persisted?'Política salva. A manutenção aplicará o prazo escolhido.':'Política não salva.';
});

document.addEventListener('f3-linkedin-credential-change',task(async e=>{await loadConnections();const c=connection(e.detail.connection_id);if(c)await edit(c);}));
renderConnections();newConnection();newSchedule();if(cfg.bootstrap.error)msg(cfg.bootstrap.error,true);task(async()=>{
 if(connections.length>=100)await loadConnections();
 await tab(routeTab(),false);
})();
})();
