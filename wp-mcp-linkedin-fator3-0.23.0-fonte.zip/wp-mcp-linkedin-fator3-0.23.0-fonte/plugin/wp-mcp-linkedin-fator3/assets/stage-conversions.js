/* Commercial-stage grant configuration only; no provider conversion event dispatch. */
(()=>{'use strict';const cfg=window.F3Social,$=s=>document.querySelector(s),status=$('#f3-stage-status');if(cfg.provider!=='linkedin'||!status)return;
let epoch=0,connections=[],grants=[],rules=[],offset=0,preview=null;
const connection=$('#f3-stage-connection_id'),account=$('#f3-stage-account_id'),action=$('#f3-stage-conversion_id'),confirm=$('#f3-stage-grant');
async function api(op,data={}){const r=await fetch(cfg.root+op,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':cfg.nonce},body:JSON.stringify(data)}),v=await r.json();if(!r.ok||!v.success)throw Error((v.message||'Falha na operação')+' ['+(v.code||r.status)+']');return v.data;}
function options(select,rows){select.replaceChildren(new Option('Escolha',''));for(const r of rows)select.add(new Option(r.name||r.id,r.id));}
function invalidate(){epoch++;preview=null;confirm.disabled=true;}
function selected(){return grants.find(g=>g.action===action.value)||{revision:0,enabled:false};}
function changed(){invalidate();rules=[];offset=0;options(action,[]);$('#f3-stage-more').hidden=true;}
function accounts(){changed();const c=connections.find(c=>c.id===connection.value);options(account,(c?.assets.ads||[]).map(id=>({id,name:'Conta autorizada ('+id+')'})));}
function render(){const box=$('#f3-stage-grants');box.replaceChildren();for(const g of grants){const b=document.createElement('button');b.type='button';b.className='button';b.textContent='Regra '+g.action+' · Conta '+(g.account_id||'—')+' · '+(g.enabled?'Concedida':'Revogada');b.addEventListener('click',()=>{invalidate();connection.value=g.connection_id||'';accounts();account.value=g.account_id||'';rules=g.rule?[{id:g.action,name:g.rule.name,ready_source:g.rule.enabled&&g.rule.conversion_method==='CONVERSIONS_API'}]:[];options(action,rules);action.value=g.action;status.textContent='Concessão selecionada. Confira a prontidão ou revogue esta ação.';});box.append(b);}}
async function refreshGrants(){grants=[];let at=0;do{const r=await api('get-stage-conversion-grants',{offset:at});grants.push(...r.grants);at=r.next_offset;}while(at!==null);render();}
async function init(){invalidate();connections=await cfg.readConnections(api);options(connection,connections.map(c=>({id:c.id,name:c.label})));accounts();await refreshGrants();status.textContent='Escolha uma regra distinta da aquisição e confira antes de conceder.';}
async function load(){const c=connections.find(c=>c.id===connection.value);if(!c||!account.value)throw Error('Escolha conexão e conta autorizada.');const stamp=epoch,r=await api('list-conversion-rules',{connection_id:c.id,account_id:account.value,offset});if(stamp!==epoch)return;if(r.connection_revision!==c.revision)throw Error('A conexão mudou; reabra a concessão.');rules.push(...r.rules);options(action,rules.map(r=>({id:r.id,name:(r.name||'Regra')+' · '+r.id+' · '+(r.ready_source?'API ativa':'Não elegível')})));offset=r.next_offset;$('#f3-stage-more').hidden=offset===null;}
function input(){const c=connections.find(c=>c.id===connection.value),r=rules.find(r=>r.id===action.value);if(!c||!r?.ready_source||!account.value)throw Error('Escolha uma regra API ativa e uma conta autorizada.');return {consumer_id:'site-core-quality',purpose:'crm_stage',action:action.value,expected_revision:selected().revision,enabled:true,connection_id:c.id,account_id:account.value,expected_connection_revision:c.revision};}
function bind(selector,fn){$(selector)?.addEventListener('click',async e=>{
 e.preventDefault();const action=cfg.startAction(e);if(!action)return;
 try{await fn();}catch(err){status.textContent=err.message;action.report(err.message,true);}finally{action.done();}
});}
connection.addEventListener('change',accounts);account.addEventListener('change',changed);action.addEventListener('change',()=>{invalidate();status.textContent='Regra '+action.value+' selecionada. Confira a concessão.';});
bind('#f3-stage-load',async()=>{changed();await load();});bind('#f3-stage-more',load);
bind('#f3-stage-preview',async()=>{invalidate();const i=input(),stamp=epoch;const p=await api('save-stage-conversion-grant',{...i,dry_run:true});if(stamp!==epoch)return;preview=i;confirm.disabled=false;status.textContent='Conferido: conta '+p.account_id+', regra '+p.action+' ('+p.rule.name+'). Confirme para autorizar esta ação comercial. Nenhum evento enviado.';});
bind('#f3-stage-grant',async()=>{if(!preview||JSON.stringify(input())!==JSON.stringify(preview))throw Error('Confira novamente a concessão selecionada.');const i=preview;invalidate();await api('save-stage-conversion-grant',{...i,dry_run:false,confirm:true});await refreshGrants();status.textContent='Concessão comercial salva. Configure esta regra na etapa correspondente do Site Core.';});
bind('#f3-stage-revoke',async()=>{const g=selected();if(!g.action)throw Error('Selecione uma concessão existente.');invalidate();await api('save-stage-conversion-grant',{consumer_id:'site-core-quality',purpose:'crm_stage',action:g.action,expected_revision:g.revision,enabled:false,dry_run:false,confirm:true});await refreshGrants();status.textContent='Ação '+g.action+' revogada.';});
const enter=()=>init().catch(e=>{status.textContent=e.message;});
let active=false;function selectPanel(name){if(name!=='stages'){active=false;return;}if(!active){active=true;enter();}}
document.addEventListener('f3-linkedin-panel',e=>selectPanel(e.detail));selectPanel(cfg.tab);
})();
