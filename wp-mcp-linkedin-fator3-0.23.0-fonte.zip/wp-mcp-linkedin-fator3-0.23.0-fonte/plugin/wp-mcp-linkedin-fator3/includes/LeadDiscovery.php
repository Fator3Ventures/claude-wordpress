<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Explicit account-wide authorization; metadata only. No commercial ingestion. */
final class LeadDiscovery {
    public const CONTRACT='linkedin-lead-reader/1.2.0';
    private static function key(string $connection,string $account,string $consumer=''): string {return hash('sha256',Util::json([$connection,$account,$consumer]));}
    public static function catalog(string $connection,string $account): ?array {return Store::get('lead_catalog',self::key($connection,$account));}
    public static function connectionForms(array $c,string $account): array {
        $ids=$c['forms'][$account]??[];
        if(in_array($account,$c['all_forms_accounts']??[],true))$ids=array_merge($ids,array_map('strval',array_keys(self::catalog($c['id'],$account)['value']['forms']??[])));
        return array_values(array_unique($ids));
    }
    public static function forms(array $c,array $g,string $account): array {
        $ids=self::connectionForms($c,$account);
        return in_array($account,$g['all_forms_accounts']??[],true)?$ids:array_values(array_intersect($g['forms'][$account]??[],$ids));
    }
    public static function configure(array $c,?array $g=null,int $revision=0): void {
        foreach(($g['all_forms_accounts']??$c['all_forms_accounts']??[]) as $account){
            $key=self::key($c['id'],$account,$g['consumer_id']??'');$r=Store::get('lead_scan',$key);
            $v=($r['value']??[])+['connection_id'=>$c['id'],'account_id'=>$account,'consumer_id'=>$g['consumer_id']??'','offset'=>0,'next_at'=>0,'sequence'=>0,'seen'=>[]];
            $v['next_at']=0;$v['offset']=0;Store::put('lead_scan',$key,$v,$r['revision']??0);
        }
        self::ensure();
    }
    public static function ensure(): bool {
        if(!Store::scan('lead_scan','',1))return true;
        if(wp_next_scheduled(Config::KEY.'_lead_discovery'))return true;
        return (bool)wp_schedule_single_event(time()+60,Config::KEY.'_lead_discovery');
    }
    private static function context(array $v): array {
        $c=Connections::get($v['connection_id']);Connections::usable($c);Access::asset($c,'leads',$v['account_id']);
        if(!in_array($v['account_id'],$c['all_forms_accounts'],true))throw new Fault('selection_disabled','Seleção automática desativada.');
        $g=null;$gr=0;
        if($v['consumer_id']!==''){
            $r=Store::get('grant',$v['consumer_id'].':'.$c['id']);$g=$r['value']??[];$gr=$r['revision']??0;
            if(!PublicApi::registered($v['consumer_id'])||PublicApi::contract($v['consumer_id'])!==self::CONTRACT)throw new Fault('consumer_unavailable','Consumidor 1.2 indisponível.');
            if(empty($g['enabled'])||($g['credential_revision']??0)!==$c['revision']||!in_array($v['account_id'],$g['all_forms_accounts']??[],true)||array_diff(['metadata','responses','verify','subscriptions'],$g['permissions']??[])||empty($g['callback_url']))throw new Fault('grant_revoked','Concessão automática indisponível.');
            ConsumerGrants::authorize($g);
        }
        return [$c,$g,$gr];
    }
    public static function tick(): array {
        $result=Result::run(static fn()=>Store::lock('lead-discovery-worker',static function(){
            $cursor=(string)get_option(Config::KEY.'_lead_discovery_cursor','');$rows=Store::scan('lead_scan',$cursor,20);if(!$rows){$cursor='';$rows=Store::scan('lead_scan','',20);}
            $until=microtime(true)+20;$processed=0;$errors=[];
            foreach($rows as $row){if(microtime(true)>$until)break;$cursor=$row['key'];if(($row['value']['next_at']??0)>time())continue;
                $r=Result::run(static fn()=>Http::within(12,max(1,(int)($until-microtime(true))),static fn()=>self::step($row['key'])));$processed++;
                if(!$r['success']){$errors[]=['task'=>$row['key'],'code'=>$r['code']];$fresh=Store::get('lead_scan',$row['key']);$v=$fresh['value'];$v['last_code']=$r['code'];$v['next_at']=time()+300;Store::put('lead_scan',$row['key'],$v,$fresh['revision']);}
            }
            update_option(Config::KEY.'_lead_discovery_cursor',$cursor,false);return ['processed'=>$processed,'errors'=>$errors,'commercial_effects'=>false];
        }));
        update_option(Config::KEY.'_lead_discovery_last',['at'=>time(),'result'=>$result],false);self::ensure();return $result;
    }
    private static function step(string $key): array {
        $r=Store::get('lead_scan',$key);$v=$r['value'];[$c,$g,$gr]=self::context($v);Http::budget(12,20);
        $binding=Management::revision([$c['revision'],$gr]);if(($v['binding']??null)!==$binding){$v['offset']=0;$v['binding']=$binding;}
        // A bounded batch covers the usual initial catalogue; commit progress per form.
        $start=$v['offset'];$processed=0;$body=Http::request($c,'leadForms',['q'=>'owner','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$v['account_id']],'start'=>$v['offset'],'count'=>5])['body'];$rows=Adapter::elements($body);
        if(count($rows)>5)throw new Fault('upstream_invalid','Página de descoberta excedeu o limite solicitado.');
        foreach($rows as $form){
            if(!Http::remaining($g?2:1))break;
            $id=(string)($form['id']??'');$version=(string)($form['versionId']??'');$created=(string)($form['created']??'');
            if(!preg_match('/^[0-9]+$/D',$id)||!preg_match('/^[0-9]+$/D',$version)||!preg_match('/^[0-9]{13}$/D',$created)||($form['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$v['account_id'])throw new Fault('upstream_invalid','Formulário sem identidade, proprietário ou instante válidos.');
            [$fresh,$freshGrant,$freshRevision]=self::context($v);if($fresh['revision']!==$c['revision']||$freshRevision!==$gr)throw new Fault('revision_conflict','A autorização mudou durante a descoberta.');$metadata=['form_id'=>$id,'form_version'=>$version,'created_at_ms'=>$created];$catalogKey=self::key($c['id'],$v['account_id']);
            Store::lock('lead-catalog:'.$catalogKey,static function()use($catalogKey,$id,$metadata,$v){$catalog=Store::get('lead_catalog',$catalogKey);$data=$catalog['value']??['connection_id'=>$v['connection_id'],'account_id'=>$v['account_id'],'forms'=>[]];if(($data['forms'][$id]??null)===$metadata)return;if(count($data['forms'])>=10000&&!isset($data['forms'][$id]))throw new Fault('catalog_limit','Catálogo atingiu 10000 formulários nesta conta.');$data['forms'][$id]=$metadata;Store::put('lead_catalog',$catalogKey,$data,$catalog['revision']??0);});
            if($g){
                $formKey=$id.':'.$version;$requestKey='auto-'.substr(hash('sha256',$key.':'.$formKey),0,55);
                $reader=PublicApi::lead_reader($v['consumer_id']);$receipt=$reader->create_subscription(['connection_id'=>$c['id'],'account_id'=>$v['account_id'],'form_id'=>$id,'form_version'=>$version,'callback_url'=>$g['callback_url'],'idempotency_key'=>$requestKey,'credential_revision'=>$c['revision'],'grant_revision'=>$gr]);
                [$fresh,$freshGrant,$freshRevision]=self::context($v);if($fresh['revision']!==$c['revision']||$freshRevision!==$gr)throw new Fault('revision_conflict','A autorização mudou após a assinatura; consulte o diário.');
                $sub=$receipt['success']?array_intersect_key($receipt['data'],array_flip(['ownership_key','subscription_id','state','remote_effect','operation_revision'])):array_intersect_key($receipt['details']??[],array_flip(['ownership_key','remote_effect']))+['state'=>'failed','code'=>$receipt['code']];
                $hash=Management::revision([$metadata,$sub,$c['revision'],$gr]);
                if(($v['seen'][$formKey]??null)!==$hash){
                    $sequence=++$v['sequence'];$event=['contract'=>self::CONTRACT,'event_id'=>$key.':'.sprintf('%012d',$sequence),'sequence'=>$sequence,'consumer_id'=>$v['consumer_id'],'connection_id'=>$c['id'],'account_id'=>$v['account_id'],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'discovered_at'=>time(),'subscription'=>$sub]+$metadata;
                    $v['seen'][$formKey]=$hash;$v['offset']=$start+$processed+1;
                    // Event and checkpoint commit together; hook delivery may be repeated by the consumer.
                    $r=ConnectionChanges::transaction(static function()use($event,$key,$v,$r){Store::put('lead_form_event',$event['event_id'],$event,0);return Store::put('lead_scan',$key,$v,$r['revision']);});
                    $audit=['success'=>true,'code'=>'form_discovered'];Audit::record('lead-form-discovered',['connection_id'=>$c['id']],$audit,$v['consumer_id'],'cron', $event);
                    try{do_action('f3_linkedin_lead_form_discovered',$event);}catch(\Throwable $e){$v['last_notification_code']='consumer_notification_failed';}
                }
                $v['last_subscription']=$sub;
            }
            $v['offset']=$start+(++$processed);$r=Store::put('lead_scan',$key,$v,$r['revision']);
        }
        $more=$processed<count($rows)||Adapter::more($body,$start,count($rows),5);$v['offset']=$more?$start+$processed:0;$v['next_at']=$more?time()+30:time()+60*$c['lead_discovery_interval_minutes'];$v['last_at']=time();$v['last_code']=isset($sub)&&($sub['state']??'')!=='confirmed'?($sub['code']??'subscription_uncertain'):null;$v['complete']=!$more;
        Store::put('lead_scan',$key,$v,$r['revision']);return ['complete'=>!$more];
    }
    public static function events(string $consumer,array $c,array $g,int $gr,array $i): array {
        if($consumer===''||PublicApi::contract($consumer)!==self::CONTRACT)throw new Fault('unsupported','Eventos pertencem ao consumidor do contrato 1.2.');
        $key=self::key($c['id'],$i['account_id'],$consumer);$after=(int)($i['after']??0);$rows=Store::scan('lead_form_event',$key.':'.sprintf('%012d',$after),51);$events=[];
        $allowed=self::forms($c,$g,$i['account_id']);$last=$after;$more=false;
        foreach($rows as $row){if(!str_starts_with($row['key'],$key.':'))break;if($last-$after>=50){$more=true;break;}$v=$row['value'];$last=$v['sequence'];if(in_array($v['form_id'],$allowed,true))$events[]=$v;}
        return ['events'=>$events,'next_after'=>$last,'has_more'=>$more,'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'delivery'=>'at_least_once','consumer_must_persist_checkpoint'=>true];
    }
    public static function status(string $connection): array {
        Access::admin();$c=Connections::get($connection);$tasks=[];$after='';do{$rows=Store::scan('lead_scan',$after,100);foreach($rows as $r){$after=$r['key'];if($r['value']['connection_id']===$connection)$tasks[]=array_diff_key($r['value'],array_flip(['seen','binding']));}}while(count($rows)===100);
        return ['connection_id'=>$connection,'all_forms_accounts'=>$c['all_forms_accounts'],'interval_minutes'=>$c['lead_discovery_interval_minutes'],'tasks'=>$tasks,'next_tick'=>wp_next_scheduled(Config::KEY.'_lead_discovery')?:null,'repair'=>'not_attempted'];
    }
}
