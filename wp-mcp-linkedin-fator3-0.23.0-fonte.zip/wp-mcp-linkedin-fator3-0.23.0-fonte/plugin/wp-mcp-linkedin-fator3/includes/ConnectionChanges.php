<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Candidate validation and the atomic boundary for connections and their schedules. */
final class ConnectionChanges {
    public const READ_SCOPES=['r_ads','r_ads_reporting','r_organization_admin','r_organization_social'];
    public const WRITE_SCOPES=['rw_ads','w_organization_social','rw_organization_admin','rw_conversions'];
    /** Only safe metadata is returned: no credential, fragment, length or fingerprint. */
    private static function warning(string $field,string $code,string $message): array {return ['field'=>$field,'code'=>$code,'message'=>$message];}
    public static function normalize(array $i,array &$warnings): array {
        foreach(['token','client_secret','refresh_token','client_id'] as $field)if(array_key_exists($field,$i)){
            $v=$i[$field];$limit=$field==='client_id'?160:16384;
            // Check controls BEFORE trimming; pasted CR/LF/TAB must never disappear silently.
            if(!is_string($v)||strlen($v)>$limit||preg_match('//u',$v)!==1||preg_match('/\p{Cc}/u',$v))
                throw new Fault('invalid_input','Credencial deve ser texto sem caracteres de controle e dentro do limite permitido.',['field'=>$field]);
            if($v==='')continue; // Existing empty-field / explicit-clear semantics.
            $trimmed=preg_replace('/^\p{Zs}+|\p{Zs}+$/u','',$v);
            if($trimmed==='')throw new Fault('invalid_input','A credencial informada contém somente espaços.',['field'=>$field]);
            if($trimmed!==$v)$warnings[]=self::warning($field,'credential_spaces_trimmed','Espaços nas pontas foram removidos antes da conferência no LinkedIn.');
            if(preg_match('/\p{Zs}/u',$trimmed))$warnings[]=self::warning($field,'credential_internal_spaces','Há espaço interno fora do padrão esperado; o valor foi preservado para conferência no LinkedIn.');
            $i[$field]=$trimmed;
        }
        return $i;
    }
    public static function formats(array $c,array $before,array $input): array {
        $warnings=[];$changed=static fn($k)=>($c[$k]??'')!==($before[$k]??'');
        if($changed('token')&&$c['token']!==''){
            if(strlen($c['token'])<100)$warnings[]=self::warning('token','access_token_short','Access Token abaixo do tamanho usual; a validade será conferida no LinkedIn.');
            if(in_array($c['token'],array_filter([$c['client_id'],$c['client_secret'],$before['client_id']??'',$before['client_secret']??'']),true))
                $warnings[]=self::warning('token','access_token_looks_like_app_credential','O valor coincide com uma credencial do aplicativo. Confira se copiou o Access Token.');
        }
        if($changed('client_id')&&$c['client_id']!==''){
            if(ctype_digit($c['client_id']))$warnings[]=self::warning('client_id','client_id_numeric','O valor parece o número do aplicativo. Confira Client ID em Auth → Application credentials.');
            elseif(!preg_match('/^[a-zA-Z0-9]+$/D',$c['client_id']))$warnings[]=self::warning('client_id','client_id_unexpected_characters','O Client ID contém caracteres fora do padrão usual; será conferido no LinkedIn.');
        }
        if($changed('client_secret')&&$c['client_secret']!==''){
            if(strlen($c['client_secret'])>=100)$warnings[]=self::warning('client_secret','client_secret_long','Primary Client Secret acima do tamanho usual; confira o campo copiado.');
            if(in_array($c['client_secret'],[$c['token'],$c['client_id']],true))$warnings[]=self::warning('client_secret','client_secret_looks_like_other_credential','O valor coincide com Access Token ou Client ID; confira Primary Client Secret.');
        }
        // Application ID is an asset identifier, not an authentication credential.
        if($changed('application_id')&&$c['application_id']!==''&&!ctype_digit($c['application_id']))throw new Fault('invalid_application_id','O número do aplicativo (App ID no endereço) aceita somente dígitos.');
        if(!empty($input['refresh_token'])&&$c['refresh_token']===$c['token'])$warnings[]=self::warning('refresh_token','refresh_token_matches_access_token','Refresh Token coincide com Access Token. A renovação será conferida no endpoint OAuth quando utilizada.');
        return $warnings;
    }
    public static function verify(array $c): array {
        // The provider, not a manually entered expiration, decides whether the candidate is active.
        $candidate=$c;$candidate['enabled']=true;$candidate['expires_at']=0;
        $proof=Credentials::requireScopes($candidate,self::READ_SCOPES);
        if(($proof['client_id']??'')!==$c['client_id']||($proof['expires_at']??0)<=time())throw new Fault('verification_incomplete','O LinkedIn não confirmou o Client ID e a validade deste token. O token salvo continua em uso.',['verification_reason'=>($proof['client_id']??'')!==$c['client_id']?'client_id_unconfirmed':'expiry_unconfirmed']);
        $proof['member']=Credentials::member($candidate,$proof['scopes']);
        $proof['write_scopes']=array_values(array_intersect(self::WRITE_SCOPES,$proof['scopes']));
        return $proof;
    }
    public static function sameIdentity(array $before,array $c,array $proof): bool {
        if($before['client_id']!==$c['client_id'])return false;
        if($before['token']===$c['token'])return true;
        $a=$before['identity']['member']['subject']??null;$b=$proof['member']['subject']??null;
        return is_string($a)&&$a!==''&&is_string($b)&&hash_equals($a,$b);
    }
    public static function rows(string $bucket,string $id): array {
        $out=[];$after='';do{$rows=Store::scan($bucket,$after,100);foreach($rows as $r){$after=$r['key'];$v=$r['value'];if(($v['connection_id']??$v['query']['connection_id']??'')===$id)$out[]=$r;}}while(count($rows)===100);return $out;
    }
    /** Compare only the authorization actually used by each grant. No remote calls. */
    private static function grantEffect(string $bucket,array $r,array $before,array $c,bool $identityChange,bool $changed,?array $proof): array {
        $g=$r['value'];$lead=$bucket==='grant';$field=$lead?'credential_revision':'connection_revision';
        $out=['status'=>'inactive','can_reconfirm'=>false,'reconfirm_field'=>$lead?'reconfirm_leads':'reconfirm_conversions','action'=>null];
        if(empty($g['enabled']))return $out;
        $allowed=!empty($c['enabled'])&&!empty($c['token']);$affected=$identityChange||($changed&&!$proof);
        foreach(['users','api_version','application_id','enabled'] as $k)if(($before[$k]??null)!==($c[$k]??null))$affected=true;
        if($lead){
            $accounts=array_unique(array_merge(array_map('strval',array_keys($g['forms']??[])),$g['all_forms_accounts']??[]));
            if(array_diff($g['all_forms_accounts']??[],$c['all_forms_accounts']??[]))$allowed=false;
            foreach($accounts as $account){
                if(!in_array($account,$c['assets']['leads'],true)||array_diff($g['forms'][$account]??[],LeadDiscovery::connectionForms($c,$account)))$allowed=false;
                if(in_array('campaign_lookup',$g['permissions']??[],true)&&!in_array($account,$c['assets']['ads'],true))$allowed=false;
                $a=LeadDiscovery::forms($before,$g,$account);$b=LeadDiscovery::forms($c,$g,$account);sort($a);sort($b);if($a!==$b)$affected=true;
            }
            if($proof&&!in_array('r_marketing_leadgen_automation',$proof['scopes'],true))$affected=true;
        }else{
            if(!in_array($g['account_id'],$c['assets']['ads'],true))$allowed=false;
            if($proof&&array_diff(['r_ads','rw_conversions'],$proof['scopes']))$affected=true;
        }
        $current=($g[$field]??0)===($before['revision']??0);
        $status=!$allowed?'blocked':(!$current?'already_stale':($affected?'requires_reconfirmation':'preserved'));
        return array_replace($out,['status'=>$status,'can_reconfirm'=>$allowed,'action'=>in_array($status,['blocked','already_stale','requires_reconfirmation'],true)?($allowed?'Simule e confirme '.$out['reconfirm_field'].' neste salvamento.':'Reveja ativos, formulários e conexão; depois regrave a concessão correspondente.'):null]);
    }
    private static function fingerprint(array $i,array $before,array $rows,?array $proof): string {
        unset($i['dry_run'],$i['confirmation'],$i['reconfirm_leads'],$i['reconfirm_conversions']);
        $revisions=[];foreach($rows as $bucket=>$list)foreach($list as $r)$revisions[$bucket.':'.$r['key']]=$r['revision'];
        return hash_hmac('sha256',Util::json([$i,Credentials::binding($before),$revisions,Access::principal(),$proof['client_id']??null,$proof['member']['subject']??null,$proof['scopes']??null]),wp_salt('auth'));
    }
    public static function save(array $i,array $c,array $before,?array $old,array $warnings=[]): array {
        try {
            $warnings=array_merge($warnings,self::formats($c,$before,$i));
            $out=self::saveCandidate($i,$c,$before,$old,$warnings);
            return $out+['warnings'=>$warnings];
        } catch(Fault $e) {
            throw new Fault($e->reason,$e->getMessage(),array_replace($e->details,['warnings'=>$warnings]));
        }
    }
    private static function saveCandidate(array $i,array $c,array $before,?array $old,array $warnings): array {
        $principal=Access::principal();$expected=(int)$i['expected_revision'];$proof=null;
        if(!empty($i['use_pending_authorization']))$c['refresh_binding_verified']=!empty($i['refresh_binding_verified']);
        elseif(($before['refresh_token']??'')!==($c['refresh_token']??''))$c['refresh_binding_verified']=false;
        $changed=Credentials::binding($before)!==Credentials::binding($c);
        if($c['enabled'] && $c['token']==='')throw new Fault('application_required','Informe Access Token, Client ID e Primary Client Secret para ativar a conexão. Para preparar OAuth sem token, salve a conexão pausada.');
        if(($changed||$warnings)&&$c['token']!=='')$proof=self::verify($c);
        $identityChange=$old&&!empty($before['token'])&&$proof&&!self::sameIdentity($before,$c,$proof);
        $rows=['schedule'=>self::rows('schedule',$c['id']),'grant'=>self::rows('grant',$c['id']),'conversion_grant'=>self::rows('conversion_grant',$c['id'])];
        foreach(['grant','conversion_grant'] as $bucket)foreach($rows[$bucket] as &$row)$row['effect']=self::grantEffect($bucket,$row,$before+['revision'=>$expected],$c,(bool)$identityChange,$changed,$proof);unset($row);
        $fingerprint=self::fingerprint($i,$before,$rows,$proof);
        $summary=['schedules'=>array_map(static fn($r)=>['id'=>$r['key'],'label'=>$r['value']['label'],'revision'=>$r['revision'],'enabled'=>$r['value']['enabled']],$rows['schedule']),
            'lead_grants'=>array_map(static fn($r)=>['consumer_id'=>$r['value']['consumer_id'],'enabled'=>$r['value']['enabled'],'revision'=>$r['revision']]+$r['effect'],$rows['grant']),
            'conversion_grants'=>array_map(static fn($r)=>['consumer_id'=>$r['value']['consumer_id']??Conversions::CONSUMER,'purpose'=>$r['value']['purpose']??'acquisition','account_id'=>$r['value']['account_id']??null,'conversion_id'=>$r['value']['conversion_id']??null,'enabled'=>$r['value']['enabled'],'revision'=>$r['revision']]+$r['effect'],$rows['conversion_grant'])];
        if(!empty($i['dry_run']))return ['persisted'=>false,'lead_selection'=>['all_forms_accounts'=>$c['all_forms_accounts']??[],'interval_minutes'=>$c['lead_discovery_interval_minutes']??60],'credential_notice_policy'=>['before'=>$before['credential_notice_days']??14,'after'=>$c['credential_notice_days']??14],'identity_change_required'=>(bool)$identityChange,'identity'=>$proof?self::publicProof($proof,$c):($c['identity']??null),'affected'=>$summary,'confirmation'=>Util::cursor(['fingerprint'=>$fingerprint,'expires'=>time()+600]),'expires_at'=>time()+600];
        if(!empty($i['confirmation'])){$preview=Util::uncursor($i['confirmation']);if(!hash_equals($fingerprint,(string)($preview['fingerprint']??'')))throw new Fault('revision_conflict','A candidata, a identidade, as agendas ou as concessões mudaram. Simule novamente.');}
        if(($c['credential_notice_days']??14)!==($before['credential_notice_days']??14)&&empty($i['confirmation']))throw new Fault('simulation_required','Simule as alterações e confirme antes de mudar a antecedência dos avisos.');
        if((($c['all_forms_accounts']??[])!==($before['all_forms_accounts']??[])||($c['lead_discovery_interval_minutes']??60)!==($before['lead_discovery_interval_minutes']??60))&&empty($i['confirmation']))throw new Fault('simulation_required','Simule e confirme a seleção automática de formulários.');
        if($identityChange){
            $name=$proof['member']['name']??('Client ID '.$c['client_id']);
            if(empty($i['confirmation']))throw new Fault('identity_change_required','O token novo é de outra identidade ('.$name.'). Para trocar, use \'Simular alterações\' e \'Confirmar alterações\': o token é conferido, a seleção de ativos, formulários e concessões é mantida e as agendas são regravadas na nova revisão.',['member_verified'=>!empty($proof['member']['subject']),'simulation_required'=>true]);
            // Identity changes never also silently widen or replace the selected resources.
            foreach(['all_forms_accounts','assets','forms','users','api_version','enabled'] as $k)if(($before[$k]??null)!==($c[$k]??null))throw new Fault('identity_selection_changed','Troque primeiro a identidade mantendo a seleção salva. Altere a seleção em outro salvamento.');
            if(array_filter($rows['grant'],static fn($r)=>!empty($r['value']['enabled']))&&empty($i['reconfirm_leads']))throw new Fault('grant_confirmation_required','Reconfirme as concessões do Lead Sync nesta tela.');
            if(array_filter($rows['conversion_grant'],static fn($r)=>!empty($r['value']['enabled']))&&empty($i['reconfirm_conversions']))throw new Fault('grant_confirmation_required','Reconfirme a concessão da Conversions API nesta tela.');
        }
        foreach(['grant','conversion_grant'] as $bucket)foreach($rows[$bucket] as &$r){
            $e=$r['effect'];if(in_array($e['status'],['inactive','preserved'],true))continue;
            if(empty($i[$e['reconfirm_field']]))continue;
            if(empty($i['confirmation']))throw new Fault('simulation_required','Simule antes de reconfirmar uma concessão.');
            if(!$e['can_reconfirm'])throw new Fault('grant_selection_invalid','A concessão contém recursos fora da seleção candidata.',['affected'=>$summary]);
            $candidate=array_replace($c,['revision'=>$expected]);if($proof)$candidate['expires_at']=$proof['expires_at'];
            if($bucket==='conversion_grant')$r['verified_rule']=Conversions::verifyCandidate($candidate,$r['value']);
            else{Credentials::requireScopes($candidate,['r_marketing_leadgen_automation']);if(!PublicApi::registered($r['value']['consumer_id']))throw new Fault('consumer_unregistered','O consumidor precisa estar disponível para reconfirmar.');}
            $r['effect']['status']='reconfirmed';
        }unset($r);
        $authChanged=(bool)$identityChange;
        foreach(['all_forms_accounts','enabled','assets','forms','users','api_version','application_id'] as $k)if(($before[$k]??null)!==($c[$k]??null))$authChanged=true;
        $c['authorization_revision']=($before['authorization_revision']??1)+($old&&$authChanged?1:0);
        if($proof){$c['expires_at']=$proof['expires_at'];$c['identity']=self::publicProof($proof,$c);}
        elseif($changed){$c['identity']=null;$authChanged=true;$c['authorization_revision']=($before['authorization_revision']??1)+1;}
        elseif(isset($before['identity'])){$c['identity']=$before['identity'];if($c['identity']){$c['identity']['application_name']=self::appName($c);$c['expires_at']=$c['identity']['expires_at'];}}
        $eligible=array_filter($rows['schedule'],static fn($r)=>in_array($r['value']['query']['account_id'],$c['assets'][$r['value']['query']['channel']]??[],true)&&(($r['value']['connection_revision']??0)===$expected||$identityChange));
        $history=$before['connection_history']??[];
        $history[]=['at'=>time(),'by'=>get_current_user_id(),'from_revision'=>$expected,'to_revision'=>$expected+1,'identity_change'=>(bool)$identityChange,'authorization_revision'=>$c['authorization_revision'],'credential_generation'=>$c['credential_generation'],'schedules'=>array_column($eligible,'key')];
        $c['connection_history']=array_slice($history,-20);unset($c['authorization_pending']);
        Access::checkPrincipal($principal);Access::admin();
        return self::transaction(static function()use($i,$c,$before,$old,$expected,$proof,$rows,$identityChange,$authChanged){
            $saved=Store::put('connection',$c['id'],$c,$expected);
            // Each CAS belongs to the same transaction. Do not resurrect schedules paused by an operator.
            $rebased=[];foreach($rows['schedule'] as $r){$v=$r['value'];if(!in_array($v['query']['account_id'],$c['assets'][$v['query']['channel']]??[],true))continue;
                if(($v['connection_revision']??0)!==$expected&&!$identityChange)continue;
                $v['connection_revision']=$saved['revision'];$v['authorization_revision']=$c['authorization_revision'];$v['credential_generation']=$c['credential_generation'];
                if(($v['last_code']??null)==='revision_conflict')$v['last_code']=null;
                Store::put('schedule',$r['key'],$v,$r['revision'],$r['expires_at']);$rebased[]=$r['key'];
            }
            // Current, unaffected grants follow atomically. Stale/changed grants need explicit confirmation.
            $effects=[];
            foreach(['grant'=>'credential_revision','conversion_grant'=>'connection_revision'] as $bucket=>$field)foreach($rows[$bucket] as $r){$v=$r['value'];$effect=$r['effect'];
                $effects[]=['consumer_id'=>$v['consumer_id']??Conversions::CONSUMER,'purpose'=>$v['purpose']??($bucket==='grant'?'leads':'acquisition'),'account_id'=>$v['account_id']??null,'conversion_id'=>$v['conversion_id']??null]+$effect;
                if(!in_array($effect['status'],['preserved','reconfirmed'],true))continue;
                $reconfirmed=$effect['status']==='reconfirmed';
                if($bucket==='conversion_grant'&&!$reconfirmed){$v['service_revision']=$v['service_revision']??$r['revision'];$v['service_connection_revision']=$v['service_connection_revision']??$v[$field];}
                $v[$field]=$saved['revision'];
                if($reconfirmed){$v['updated_at']=time();$v['principal']=Access::principal();if($bucket==='grant')$v['configured_by']=get_current_user_id();else{unset($v['service_revision'],$v['service_connection_revision']);$v['rule']=$r['verified_rule'];$v['destination_ref']=bin2hex(random_bytes(32));}}
                if($bucket==='conversion_grant'&&($v['consumer_id']??'')===StageConversions::CONSUMER)$v['authorization_revision']=$c['authorization_revision'];
                $grantSaved=Store::put($bucket,$r['key'],$v,$r['revision'],$r['expires_at']);
                if($bucket==='grant')LeadDiscovery::configure($c,$v,$grantSaved['revision']);
            }
            // The effective material is now the base record. An old overlay must not restore a manually changed refresh token.
            $overlay=Store::get('credential',$c['id']);if($overlay)Store::remove('credential',$c['id'],$overlay['revision']);
            if($proof)self::storeProof($c,$proof);
            Credentials::saved($c,$proof!==null);LeadDiscovery::configure($c);
            if(!empty($i['use_pending_authorization'])){$pending=Store::get('credential_candidate',$c['id']);if($pending)Store::remove('credential_candidate',$c['id'],$pending['revision']);}
            return ['persisted'=>true,'connection'=>Connections::public($c+['revision'=>$saved['revision']]),'schedules_rebased'=>$rebased,'identity_changed'=>(bool)$identityChange,'grant_effects'=>$effects];
        });
    }
    private static function appName(array $c): string {$parts=explode('·',$c['label'],2);return trim($parts[1]??'')?:'Nome não informado';}
    public static function publicProof(array $proof,array $c): array {return $proof+['application_name'=>self::appName($c),'application_name_source'=>'administrator_label'];}
    public static function storeProof(array $c,array $proof): void {
        $r=Store::get('token_proof',$c['id']);$binding=Credentials::binding($c);
        // A scopes-only check must not discard an already verified subject for this exact credential.
        if(!array_key_exists('member',$proof)&&$r&&hash_equals($binding,$r['value']['binding']))$proof['member']=$r['value']['member']??null;
        Store::put('token_proof',$c['id'],$proof+['binding'=>$binding],$r['revision']??0);
    }
    public static function transaction(callable $fn) {
        global $wpdb;if($wpdb->query('START TRANSACTION')===false)throw new Fault('storage_unavailable','Não foi possível iniciar o salvamento atômico.');
        try{$out=$fn();if($wpdb->query('COMMIT')===false)throw new Fault('persistence_unconfirmed','O banco não confirmou o salvamento. Releia a conexão antes de tentar novamente.');return $out;}
        catch(\Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }
}
