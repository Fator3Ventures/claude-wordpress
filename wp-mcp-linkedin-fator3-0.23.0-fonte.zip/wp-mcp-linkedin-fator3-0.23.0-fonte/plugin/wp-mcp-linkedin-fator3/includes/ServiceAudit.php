<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Domain half of the service audit contract. The central consumer is optional. */
final class ServiceAudit {
    public const CONTRACT='mutation-service-audit/1.0.0';
    public const EVENT='linkedin-service-mutation/1.0.0';
    public const HOOK='f3_linkedin_service_mutation_recorded';
    private static $central=null;

    public static function boot(): void {
        add_action('f3_mcp_register_mutation_service_audit',static function($contract,$register=null,$status=null): void {
            if($contract!==self::CONTRACT||!is_callable($register)||!is_callable($status))return;
            try {
                $r=$register(self::descriptor());
                if(self::registered($r))self::$central=$status;
            } catch(\Throwable $e) { /* Failed admission must not break the provider bootstrap. */ }
        },10,3);
    }
    public static function descriptor(): array {
        return ['contract'=>self::CONTRACT,'provider'=>Config::SLUG,'event_contract'=>self::EVENT,'event_hook'=>self::HOOK,
            'reader'=>'linkedin/get-service-write-operation','introspector'=>'f3_linkedin_introspect_service_grant'];
    }
    public static function schema(): array {
        $hash=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        $p=['provider'=>['type'=>'string','enum'=>[Config::SLUG]],'consumer_id'=>['type'=>'string','enum'=>[Conversions::CONSUMER,StageConversions::CONSUMER]],'principal_ref'=>$hash,'grant_revision'=>$hash,'operation_id'=>$hash];
        return Schemas::obj($p,array_keys($p));
    }
    private static function registered($r): bool {
        return is_array($r)&&($r['contract']??'')===self::CONTRACT&&($r['provider']??'')===Config::SLUG&&($r['registered']??false)===true;
    }
    private static function query(array $identity=[]): array {
        if(!is_callable(self::$central))return [];
        try {$r=(self::$central)(Config::SLUG,$identity);return is_array($r)?$r:[];}catch(\Throwable $e){return [];}
    }
    public static function capabilities(): array {
        $registered=self::registered(self::query());
        return self::descriptor()+['domain_implemented'=>true,'central_registered'=>$registered,
            'central_audit'=>!is_callable(self::$central)?'service_principal_unsupported':($registered?'service_provider_registered':'service_provider_not_registered'),
            'emission'=>'local_php_only','retroactive_import'=>false,'read_requires'=>'manage_options_and_current_grant_owner'];
    }
    /** References identify service authority, never the incidental WordPress user. */
    public static function bind(array $g,int $revision): array {
        $consumer=$g['consumer_id'];$base=[get_current_blog_id(),$consumer,$g['destination_ref']];
        $mac=static fn($purpose,$value)=>hash_hmac('sha256',$purpose."\0".Util::json($value),wp_salt('auth'));
        return ['provider'=>Config::SLUG,'consumer_id'=>$consumer,
            'principal_ref'=>$mac('linkedin-service-principal/1',$base),
            'grant_revision'=>$mac('linkedin-service-grant/1',[$base,$g['service_revision']??$revision,$g['connection_id'],$g['service_connection_revision']??$g['connection_revision'],$g['account_id'],$g['conversion_id'],$g['principal']])];
    }
    private static function current(string $key=Conversions::CONSUMER): array {
        if($key!==Conversions::CONSUMER){
            $prefix=StageConversions::CONSUMER.':';if(!str_starts_with($key,$prefix))throw new Fault('service_grant_invalid','Concessão desconhecida.');
            return StageConversions::context(substr($key,strlen($prefix)));
        }
        $r=Store::get('conversion_grant',Conversions::CONSUMER);
        if(!$r||empty($r['value']['enabled']))throw new Fault('service_grant_inactive','Concessão de serviço indisponível.');
        $g=$r['value'];$c=Connections::get($g['connection_id']);Connections::usable($c);ConsumerGrants::authorize($g);Access::asset($c,'ads',$g['account_id']);
        if($c['revision']!==$g['connection_revision']||($g['consumer_id']??'')!==Conversions::CONSUMER)throw new Fault('service_grant_changed','A concessão ou conexão mudou.');
        if(($g['rule']['conversion_method']??'')!=='CONVERSIONS_API'||($g['rule']['enabled']??false)!==true
            ||($g['rule']['id']??'')!==$g['conversion_id']||($g['rule']['account_id']??'')!==$g['account_id'])throw new Fault('service_rule_invalid','Regra API não comprovada.');
        $p=Store::get('token_proof',$c['id']);$p=$p['value']??[];
        if(($p['active']??false)!==true||!is_string($p['binding']??null)||!hash_equals(Credentials::binding($c),$p['binding'])
            ||!is_array($p['scopes']??null)||array_diff(['rw_conversions','r_ads'],$p['scopes'])
            ||(!empty($p['expires_at'])&&$p['expires_at']<=time()))throw new Fault('service_scope_unverified','Escopos locais não comprovados para a credencial vigente.');
        return [$g,$c,$r['revision']];
    }
    private static function resolve(array $i): array {
        if(is_wp_error(rest_validate_value_from_schema($i,self::schema(),'service_identity')))throw new Fault('service_identity_invalid','Identidade de serviço inválida.');
        $r=Store::get('conversion_event',$i['operation_id']);
        if(!$r||empty($r['value']['service'])||!isset($r['value']['service_identity']))throw new Fault('service_operation_unbound','Operação sem vínculo de serviço desta versão.');
        [$g,$c,$revision]=self::current($r['value']['grant_key']??Conversions::CONSUMER);$bound=self::bind($g,$revision);$expected=$bound+['operation_id'=>$i['operation_id']];
        if(!hash_equals(Management::revision($i),Management::revision($expected))||!hash_equals(Management::revision($r['value']['service_identity']),Management::revision($expected))
            ||$r['value']['connection_id']!==$g['connection_id']||$r['value']['account_id']!==$g['account_id']||$r['value']['conversion_id']!==$g['conversion_id'])throw new Fault('service_identity_mismatch','Identidade ou revisão de serviço divergente.');
        return [$r,$g,$c];
    }
    private static function result(array $v): array {
        $r=$v['result'];
        if(!in_array($r['status']??'', ['entregue','recusado','incerto'],true)||!is_string($r['code']??null)||!preg_match('/^[a-z][a-z0-9_]{0,99}$/D',$r['code'])
            ||!is_int($r['http']??null)||$r['http']<0||$r['http']>599||!is_bool($r['non_delivery_proven']??null))throw new Fault('service_journal_invalid','Recibo técnico inválido.');
        $out=array_intersect_key($r,array_flip(['status','code','http','non_delivery_proven']));
        if(isset($r['retry_after'])&&is_int($r['retry_after'])&&$r['retry_after']>=0)$out['retry_after']=$r['retry_after'];
        return $out;
    }
    private static function snapshots(array $v): array {
        return ['before'=>['status'=>'nao_enviado'],'after'=>in_array($v['state'],['dispatching','uncertain'],true)?null:self::result($v)];
    }
    private static function event(array $i,array $r): array {
        $v=$r['value'];
        if(!in_array($v['operation']??'', ['send-conversion-event','send-conversion-events'],true)||!in_array($v['state']??'', ['dispatching','confirmed','uncertain','rejected'],true))throw new Fault('service_journal_invalid','Estado técnico inválido.');
        $s=self::snapshots($v);
        return ['contract'=>self::EVENT,'provider'=>Config::SLUG,'operation_id'=>$i['operation_id'],'operation'=>$v['operation'],'state'=>$v['state'],
            'before_sha256'=>Management::revision($s['before']),'after_sha256'=>$s['after']===null?null:Management::revision($s['after']),
            'consumer_id'=>$i['consumer_id'],'principal_ref'=>$i['principal_ref'],'grant_revision'=>$i['grant_revision']];
    }
    /** Local PHP metadata only: usable as user zero; no account details, network or mutation. */
    public static function introspect(array $i): array {
        try {[$r]=self::resolve($i);$event=self::event($i,$r);return ['contract'=>self::CONTRACT,'valid'=>true,'identity'=>$i,'event'=>$event,'event_sha256'=>Management::revision($event)];}
        catch(Fault $e){return ['contract'=>self::CONTRACT,'valid'=>false,'code'=>$e->reason];}
        catch(\Throwable $e){return ['contract'=>self::CONTRACT,'valid'=>false,'code'=>'service_introspection_unavailable'];}
    }
    public static function status(array $r): string {
        if(!isset($r['value']['service_identity']))return 'service_operation_unbound';
        if(!is_callable(self::$central))return 'service_principal_unsupported';
        $i=$r['value']['service_identity'];$proof=self::introspect($i);
        if(!$proof['valid'])return 'service_authority_unavailable';
        $s=self::query($i);if(!self::registered($s))return 'service_provider_not_registered';
        return ($s['recorded']??false)===true&&is_string($s['event_sha256']??null)&&hash_equals($proof['event_sha256'],$s['event_sha256'])?'recorded':'service_record_unconfirmed';
    }
    public static function emit(array $r): string {
        $proof=self::introspect($r['value']['service_identity']??[]);
        if(!$proof['valid'])return 'service_authority_unavailable';
        try {do_action(self::HOOK,$proof['event']);}catch(\Throwable $e){return 'service_event_failed';}
        return self::status($r);
    }
    public static function read(array $i): array {
        Access::admin();[$r,$g,$c]=self::resolve($i);Access::owned($g['principal']);Access::connection($c,'ads',$g['account_id']);
        $event=self::event($i,$r);$v=$r['value'];
        return ['contract'=>self::CONTRACT,'principal_type'=>'service','identity'=>$i,'operation_id'=>$i['operation_id'],'operation_revision'=>$r['revision'],
            'operation'=>$v['operation'],'state'=>$v['state'],'event_sha256'=>Management::revision($event),'result'=>self::result($v),
            'central_audit'=>self::status($r),'redacted'=>true]+self::snapshots($v);
    }
}
