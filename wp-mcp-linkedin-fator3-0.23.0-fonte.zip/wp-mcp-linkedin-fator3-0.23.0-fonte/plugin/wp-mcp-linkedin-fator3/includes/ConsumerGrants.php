<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** A domain grant survives transport rotation. The stored actor remains immutable audit evidence. */
final class ConsumerGrants {
    public static function owner(array $grant): array {
        $user=$grant['principal']['user_id']??$grant['configured_by']??0;
        if(!is_int($user)||$user<1)throw new Fault('not_authorized','Concessão sem administrador de origem válido.');
        return ['user_id'=>$user,'channel'=>null];
    }
    public static function authorize(array $grant): void {Access::checkPrincipal(self::owner($grant));}

    public static function page(int $offset,int $limit): array {
        Access::admin();$items=[];$more=false;
        foreach(['grant','conversion_grant'] as $bucket){
            $rows=Store::list($bucket,$offset,$limit+1);
            $more=$more||count($rows)>$limit;
            foreach(array_slice($rows,0,$limit) as $r)$items[]=self::describe($bucket,$r);
        }
        return ['items'=>$items,'next_offset'=>$more?$offset+$limit:null,'remote_checked'=>false,'transport_bound'=>false];
    }
    private static function describe(string $bucket,array $r): array {
        $g=$r['value'];$leads=$bucket==='grant';$consumer=$g['consumer_id']??'';
        $stage=!$leads&&$consumer===StageConversions::CONSUMER;
        $out=['consumer_id'=>$consumer,'purpose'=>$leads?'leads':($stage?'crm_stage':'acquisition'),'connection_id'=>$g['connection_id']??null,'resource'=>$leads?($g['connection_id']??null):($g['conversion_id']??$g['action']??null),'revision'=>$r['revision'],'enabled'=>!empty($g['enabled']),'state'=>'disabled','reason'=>'grant_disabled','regrant_operation'=>'linkedin/'.($leads?'save-grant':($stage?'save-stage-conversion-grant':'save-conversion-grant'))];
        if(!$out['enabled'])return $out;
        try{
            self::authorize($g);
            if($leads){
                if(!PublicApi::registered($consumer))throw new Fault('consumer_unregistered','Consumidor indisponível.');
                $c=Connections::get($g['connection_id']);Connections::usable($c);
                if($c['revision']!==($g['credential_revision']??null))throw new Fault('revision_conflict','Conexão alterada.');
                $accounts=array_unique(array_merge(array_keys(array_filter($g['forms']??[])),$g['all_forms_accounts']??[]));
                if(!$accounts||empty($g['permissions']))throw new Fault('empty_scope','Nenhum recurso autorizado.');
                foreach($accounts as $account){
                    $id=(string)$account;Access::asset($c,'leads',$id);
                    if(array_intersect(['ad_source','campaign_lookup'],$g['permissions']))Access::asset($c,'ads',$id);
                    if(in_array($id,$g['all_forms_accounts']??[],true)){
                        if(!in_array($id,$c['all_forms_accounts']??[],true))throw new Fault('asset_access_denied','Seleção da conta divergente.');
                    }elseif(array_diff($g['forms'][$account]??[],LeadDiscovery::forms($c,$g,$id)))throw new Fault('asset_access_denied','Formulário não selecionado.');
                }
            }elseif($stage){
                StageConversions::context($g['action']);
            }elseif($consumer===Conversions::CONSUMER){
                $cap=Conversions::capabilities();if(!$cap['ready'])throw new Fault($cap['reason'],'Aquisição indisponível.');
            }else throw new Fault('consumer_unregistered','Consumidor indisponível.');
            $out['state']='ready';$out['reason']='ok';
        }catch(Fault $e){$out['state']='blocked';$out['reason']=$e->reason;}
        return $out;
    }
}
