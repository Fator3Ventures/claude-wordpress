<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Metadata linked to an authorized lead; never an arbitrary campaign catalogue. */
final class LeadCampaign {
    public const CONTRACT='linkedin-lead-campaign/1.0.0';
    // Default lead payload plus only the campaign decoration used by this SDK (API 202609).
    public const FIELDS='id,responseId,leadType,owner,submitter,versionedLeadGenFormUrn,leadMetadata,associatedEntity,submittedAt,testLead,formResponse,leadMetadataInfo:(sponsoredLeadMetadataInfo:(campaign:(id,name)))';
    public static function read(array $c,string $path,array $query,callable $guard): array {
        $guard();
        try{return Http::request($c,$path,$query+['fields'=>self::FIELDS],'GET',null,$guard)['body'];}
        catch(Fault $e){
            if($e->reason!=='upstream_validation'||($e->details['http_status']??0)!==400||empty($e->details['projection_rejected']))throw $e;
            // Optional enrichment must not stop ingestion. No loop, no retry of other failures.
            $guard();unset($query['fields']);return Http::request($c,$path,$query,'GET',null,$guard)['body'];
        }
    }
    public static function campaignId($urn): ?string {
        return is_string($urn)&&preg_match('/^urn:li:sponsoredCampaign:([0-9]{1,40})$/D',$urn,$m)?$m[1]:null;
    }
    private static function validName($name): bool {
        return is_string($name)&&trim($name)!==''&&strlen($name)<=1024&&!preg_match('/[\x00-\x1F\x7F]/',$name);
    }
    public static function metadata(array &$raw,string $account): array {
        $reference=$raw['leadMetadata']['sponsoredLeadMetadata']['campaign']??null;
        $id=self::campaignId($reference);
        $decorated=$raw['leadMetadataInfo']['sponsoredLeadMetadataInfo']['campaign']??null;
        $out=['contract'=>self::CONTRACT,'account_id'=>$account,'id'=>$id,'name'=>null,'source'=>'lead_metadata','status'=>$id?'not_provided':'not_applicable','code'=>$id?'campaign_name_not_provided':'campaign_not_associated','retryable'=>false];
        if($reference!==null&&$id===null||$decorated!==null&&(!is_array($decorated)||!$id||($decorated['id']??null)!==$reference||isset($decorated['account'])&&$decorated['account']!=='urn:li:sponsoredAccount:'.$account)){
            if(is_array($raw['leadMetadataInfo']['sponsoredLeadMetadataInfo']??null))unset($raw['leadMetadataInfo']['sponsoredLeadMetadataInfo']['campaign']);
            return array_replace($out,['status'=>'invalid_metadata','code'=>'campaign_binding_invalid']);
        }
        if(is_array($decorated)&&self::validName($decorated['name']??null))return array_replace($out,['name'=>$decorated['name'],'status'=>'available','code'=>'ok']);
        if(is_array($decorated)&&isset($decorated['name'])&&!is_string($decorated['name'])){
            unset($raw['leadMetadataInfo']['sponsoredLeadMetadataInfo']['campaign']['name']);
            return array_replace($out,['status'=>'invalid_metadata','code'=>'campaign_name_invalid']);
        }
        if(is_array($decorated)&&isset($decorated['name'])&&trim($decorated['name'])!==''){
            unset($raw['leadMetadataInfo']['sponsoredLeadMetadataInfo']['campaign']['name']);
            return array_replace($out,['status'=>'invalid_metadata','code'=>'campaign_name_invalid']);
        }
        return $out;
    }
    public static function lookup(array $c,array $metadata,callable $guard): array {
        if($metadata['status']==='available'||$metadata['status']==='not_applicable')return $metadata;
        if($metadata['status']==='invalid_metadata')throw new Fault('campaign_metadata_invalid','Metadados da campanha não correspondem à resposta autorizada.');
        $guard();$proof=Credentials::requireScopes($c,[]);$guard();
        if(!array_intersect(['r_ads','rw_ads'],$proof['scopes']))throw new Fault('scope_missing','A consulta da campanha exige r_ads ou rw_ads.');
        $r=Http::request($c,'adAccounts/'.$metadata['account_id'].'/adCampaigns/'.$metadata['id'],['fields'=>'id,name,account'],'GET',null,$guard)['body'];$guard();
        if((!is_string($r['id']??null)&&!is_int($r['id']??null))||(string)$r['id']!==$metadata['id']||($r['account']??null)!=='urn:li:sponsoredAccount:'.$metadata['account_id'])throw new Fault('campaign_binding_invalid','Campanha retornada fora da conta ou referência do lead.');
        if(!isset($r['name'])||is_string($r['name'])&&trim($r['name'])==='')return array_replace($metadata,['source'=>'campaign_api','code'=>'campaign_name_not_provided']);
        if(!self::validName($r['name']))throw new Fault('campaign_metadata_invalid','Nome da campanha retornado em formato inválido.');
        return array_replace($metadata,['name'=>$r['name'],'source'=>'campaign_api','status'=>'available','code'=>'ok']);
    }
    public static function failure(string $code,array $details): array {
        $http=$details['http_status']??0;
        $transient=in_array($code,['upstream_error','oauth_unavailable','rate_limited','busy','budget_exhausted'],true)||$http===429||$http>=500;
        $status=$transient?'temporarily_unavailable':match($code){
            'revision_conflict'=>'stale_context',
            'not_authorized','asset_access_denied','scope_missing','token_rejected','token_expired','application_required','oauth_rejected','app_account_not_listed','connection_paused','consumer_unregistered'=>'not_authorized',
            'resource_not_found'=>'not_provided',
            default=>'invalid_metadata'};
        return ['campaign_contract'=>self::CONTRACT,'campaign_status'=>$status,'remote_effect'=>'none','retryable'=>$transient];
    }
}
