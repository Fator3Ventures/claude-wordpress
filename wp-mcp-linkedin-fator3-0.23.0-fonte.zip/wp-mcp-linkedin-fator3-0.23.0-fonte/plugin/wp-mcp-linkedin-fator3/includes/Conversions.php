<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Provider transport only. Core owns consent, contacts, queue and business retries. */
final class Conversions {
    public const CONTRACT='site-conversion-delivery/1.0.0';
    public const CONSUMER='site-core-conversions';
    public static function boot(): void {
        add_filter('f3base_conversoes_adaptador',static function($adapter,$target,$contract,$context){
            if($adapter===null&&$target==='linkedin'&&$contract===self::CONTRACT&&($context['consumer_id']??'')===self::CONSUMER)return new ConversionDelivery();
            if($adapter===null&&$target==='linkedin'&&$contract===StageConversions::CONTRACT&&($context['consumer_id']??'')===StageConversions::CONSUMER&&($context['purpose']??'')===StageConversions::PURPOSE&&is_string($context['action']??null)&&preg_match('/^[1-9][0-9]{0,29}$/D',$context['action']))return new StageConversionDelivery($context['action']);
            return $adapter;
        },10,4);
    }
    public static function handles(string $op): bool {return isset(ConversionSchemas::all()[$op]);}
    public static function writes(string $op): bool {return in_array($op,['save-stage-conversion-grant','save-conversion-grant','send-conversion-event','send-conversion-events'],true);}
    public static function scopeStatus(): array {return Credentials::status()['conversion_access'];}
    /** Only a proof bound to the effective credential may be supplied here. */
    public static function scopeFlags(string $id,?array $proof): array {
        return ['connection_id'=>$id,'checked'=>$proof!==null,
                'rw_conversions'=>$proof?in_array('rw_conversions',$proof['scopes'],true):null,
                'r_ads'=>$proof?in_array('r_ads',$proof['scopes'],true):null,'checked_at'=>$proof['checked_at']??null];
    }
    private static function proof(array $c): ?array {
        $p=Store::get('token_proof',$c['id']);return $p&&hash_equals($p['value']['binding'],Credentials::binding($c))?$p['value']:null;
    }
    /** Honor locally known invalidity; no introspection or credential mutation from a diagnostic. */
    private static function proofFailure(?array $proof): ?string {
        if($proof===null)return null;
        if(($proof['active']??false)!==true)return 'token_rejected';
        if(!empty($proof['expires_at'])&&(int)$proof['expires_at']<=time())return 'token_expired';
        return null;
    }
    private static function inspect(array $c): void {
        $p=Credentials::inspect($c);Connections::revalidate($c);
        ConnectionChanges::storeProof($c,$p);
        if(array_diff(['rw_conversions','r_ads'],$p['scopes']))throw new Fault('sem_escopo','O Access Token precisa de rw_conversions e r_ads. Confira Auth → OAuth 2.0 scopes e gere nova autorização.',['required_scopes'=>['rw_conversions','r_ads'],'remote_write_sent'=>false]);
    }
    private static function role(array $c,string $account): void {
        for($start=0;$start<1000;$start+=100){
            $r=Http::request($c,'adAccountUsers',['q'=>'authenticatedUser','start'=>$start,'count'=>100])['body'];$rows=Adapter::elements($r);
            foreach($rows as $row)if(($row['account']??'')==='urn:li:sponsoredAccount:'.$account){
                if(!in_array($row['role']??'',['ACCOUNT_BILLING_ADMIN','ACCOUNT_MANAGER','CAMPAIGN_MANAGER','CREATIVE_MANAGER'],true))throw new Fault('papel_insuficiente','A conta exige papel de gestão para Conversions API.');return;
            }
            if(!Adapter::more($r,$start,count($rows),100))break;
        }
        throw new Fault('papel_nao_comprovado','O papel do membro na conta selecionada não foi comprovado.');
    }
    private static function rule(array $c,string $account,string $id,bool $requireApi=true): array {
        $r=Http::request($c,'conversions/'.$id)['body'];
        if((string)($r['id']??'')!==$id||($r['account']??'')!=='urn:li:sponsoredAccount:'.$account)throw new Fault('regra_divergente','A regra não pertence à conta selecionada.');
        $out=['id'=>$id,'name'=>mb_substr(sanitize_text_field((string)($r['name']??'')),0,180),'account_id'=>$account,'enabled'=>($r['enabled']??false)===true,'conversion_method'=>(string)($r['conversionMethod']??''),'checked_at'=>time()];
        if($requireApi){if(!$out['enabled'])throw new Fault('regra_inativa','A regra de conversão está desativada.');if($out['conversion_method']!=='CONVERSIONS_API')throw new Fault('regra_sem_fonte_api','Escolha uma regra com Data source Direct API / Conversions API no Campaign Manager → Measurement → Conversion tracking. Regras Insight Tag não são convertidas automaticamente.');}
        return $out;
    }
    public static function rules(array $i): array {
        $c=Connections::get($i['connection_id']);Access::connection($c,'ads',$i['account_id']);self::inspect($c);$at=$i['offset']??0;
        $r=Http::request($c,'conversions',['q'=>'account','account'=>'urn:li:sponsoredAccount:'.$i['account_id'],'start'=>$at,'count'=>50])['body'];$rows=Adapter::elements($r);$out=[];
        foreach($rows as $row){if(($row['account']??'')!=='urn:li:sponsoredAccount:'.$i['account_id'])throw new Fault('regra_divergente','Regra de outra conta.');$id=Util::numeric((string)($row['id']??''));$out[]=['id'=>$id,'name'=>mb_substr(sanitize_text_field((string)($row['name']??'')),0,180),'enabled'=>($row['enabled']??false)===true,'conversion_method'=>(string)($row['conversionMethod']??''),'ready_source'=>($row['conversionMethod']??'')==='CONVERSIONS_API'&&($row['enabled']??false)===true];}
        // Some API versions omit paging on a complete short list. Never claim exhaustion at the limit.
        $more=isset($r['paging'])?Adapter::more($r,$at,count($rows),50):count($rows)>=50;
        return ['rules'=>$out,'next_offset'=>$more?$at+count($rows):null,'connection_revision'=>$c['revision'],'selection_required'=>true];
    }
    public static function grant(): array {
        $r=Store::get('conversion_grant',self::CONSUMER);if(!$r)return ['revision'=>0,'consumer_id'=>self::CONSUMER,'enabled'=>false];
        return array_intersect_key($r['value'],array_flip(['consumer_id','enabled','connection_id','account_id','conversion_id','destination_ref','connection_revision','rule','created_at']))+['revision'=>$r['revision']];
    }
    public static function requireLocalProof(array $c): void {
        $p=self::proof($c);if(!$p)throw new Fault('escopo_nao_verificado','Valide a credencial atual.');
        $invalid=self::proofFailure($p);if($invalid!==null)throw new Fault($invalid,'Credencial sem prova ativa.');
        if(array_diff(['rw_conversions','r_ads'],$p['scopes']))throw new Fault('sem_escopo','Permissão de conversão ausente.');
    }
    public static function verifyDestination(array $c,string $account,string $action): array {
        self::inspect($c);self::role($c,$account);return self::rule($c,$account,$action);
    }
    public static function verifyCandidate(array $c,array $g): array {
        Access::asset($c,'ads',$g['account_id']);Credentials::requireScopes($c,['rw_conversions','r_ads']);self::role($c,$g['account_id']);return self::rule($c,$g['account_id'],$g['conversion_id']);
    }
    public static function saveGrant(array $i): array {
        if(!empty($i['connection_id']))return Store::lock('connection:'.$i['connection_id'],static fn()=>self::saveGrantLocked($i));
        return self::saveGrantLocked($i);
    }
    private static function saveGrantLocked(array $i): array {
        Access::admin();return Store::lock('conversion-grant',static function()use($i){
            $old=Store::get('conversion_grant',self::CONSUMER);if(($old['revision']??0)!==$i['expected_revision'])throw new Fault('revision_conflict','Releia a concessão de conversões.');
            if(!$i['enabled']){$v=$old['value']??['consumer_id'=>self::CONSUMER];$v['enabled']=false;Store::put('conversion_grant',self::CONSUMER,$v,$i['expected_revision']);return self::grant();}
            foreach(['connection_id','account_id','conversion_id','expected_connection_revision'] as $k)if(!isset($i[$k]))throw new Fault('invalid_input','Escolha conexão, conta, regra e revisão da conexão.');
            $c=Connections::get($i['connection_id']);Access::connection($c,'ads',$i['account_id']);if($c['revision']!==$i['expected_connection_revision'])throw new Fault('revision_conflict','A conexão mudou.');
            if(preg_match('/^[1-9][0-9]{0,29}$/D',$i['conversion_id']))StageConversions::denyCommercial($i['conversion_id']);
            self::inspect($c);self::role($c,$i['account_id']);$rule=self::rule($c,$i['account_id'],$i['conversion_id']);Connections::revalidate($c);
            $principal=Access::principal();Access::checkPrincipal($principal);
            $same=$old&&($old['value']['enabled']??false)&&($old['value']['connection_id']??'')===$c['id']&&($old['value']['connection_revision']??0)===$c['revision']&&($old['value']['account_id']??'')===$i['account_id']&&($old['value']['conversion_id']??'')===$i['conversion_id']&&($old['value']['principal']??[])===$principal;
            $v=['consumer_id'=>self::CONSUMER,'enabled'=>true,'connection_id'=>$c['id'],'connection_revision'=>$c['revision'],'account_id'=>$i['account_id'],'conversion_id'=>$i['conversion_id'],'rule'=>$rule,'scopes'=>['rw_conversions','r_ads'],'principal'=>$principal,'destination_ref'=>$same?$old['value']['destination_ref']:bin2hex(random_bytes(32)),'created_at'=>time()];
            Store::put('conversion_grant',self::CONSUMER,$v,$i['expected_revision']);return self::grant();
        });
    }
    private static function context(string $ref=''): array {
        $r=Store::get('conversion_grant',self::CONSUMER);if(!$r||empty($r['value']['enabled']))throw new Fault('sem_concessao','Conceda Conversions API explicitamente ao Site Core.');$g=$r['value'];
        if($ref!==''&&!hash_equals($g['destination_ref'],$ref))throw new Fault('destino_alterado','O destino vinculado mudou.');
        try{$c=Connections::get($g['connection_id']);}catch(Fault $e){throw new Fault('sem_conexao','Conexão não disponível.');}
        Connections::usable($c);ConsumerGrants::authorize($g);Access::asset($c,'ads',$g['account_id']);
        if($c['revision']!==$g['connection_revision'])throw new Fault('destino_alterado','Reconfirme a concessão após alterar a conexão.');
        if(($g['rule']['conversion_method']??'')!=='CONVERSIONS_API')throw new Fault('regra_sem_fonte_api','Regra sem fonte API comprovada.');
        return [$g,$c,$r['revision']];
    }
    public static function capabilities(): array {
        $out=['contract'=>self::CONTRACT,'supported_contracts'=>[self::CONTRACT,StageConversions::CONTRACT],'ready'=>false,'reason'=>'sem_conexao','destination_ref'=>'','conversion_id'=>''];
        try{
            if(!Store::list('connection',0,1))return $out;
            [$g,$c]=self::context();$out['destination_ref']=$g['destination_ref'];$out['conversion_id']=(string)$g['conversion_id'];$p=self::proof($c);
            $invalid=self::proofFailure($p);if($invalid!==null)throw new Fault($invalid,'A prova local do Access Token indica inatividade ou expiração. Revalide a credencial.');
            if(!$p&&!empty($g['scopes']))$p=['scopes'=>$g['scopes']];
            if(!$p)throw new Fault('escopo_nao_verificado','Verifique o Access Token.');
            if(array_diff(['rw_conversions','r_ads'],$p['scopes']))throw new Fault('sem_escopo','Permissão de conversão ausente.');
            $out['ready']=true;$out['reason']='pronto';
        }catch(Fault $e){$out['reason']=$e->reason;}catch(\Throwable $e){$out['reason']='armazenamento_indisponivel';}
        return $out;
    }
    /**
     * Full local readiness checklist for the site-core-conversions destination (0.8.0). No HTTP, no write.
     * `conversion_id` is the server rule configured in Site Core (Medição → Conversions API) when the caller has it.
     */
    public static function diagnose(array $i): array {
        Access::admin();$checks=[];$add=static function(string $id,bool $ok,string $code,string $action,bool $blocking=true)use(&$checks){$checks[]=['id'=>$id,'ok'=>$ok,'blocking'=>$blocking,'code'=>$ok?'ok':$code,'action'=>$ok?null:$action];};
        $r=Store::get('conversion_grant',self::CONSUMER);$g=$r['value']??null;$enabled=!empty($g['enabled']);
        $add('grant_enabled',$enabled,'sem_concessao','Em Ferramentas → Fator3 MCP LinkedIn → Conexão → Conversions API, escolha conexão, conta e regra e conceda ao Site Core (site-core-conversions).');
        $c=null;
        if($g&&!empty($g['connection_id'])){try{$c=Connections::get($g['connection_id']);}catch(Fault $e){$c=null;}}
        $add('connection_available',$c!==null,'sem_conexao','A conexão concedida não existe mais. Salve a conexão e conceda novamente.');
        $usable=false;$usableCode='sem_conexao';
        if($c){try{Connections::usable($c);$usable=true;}catch(Fault $e){$usableCode=$e->reason;}}
        $add('connection_usable',$usable,$usableCode,'Ative a conexão e cadastre um Access Token válido (Ferramentas → Fator3 MCP LinkedIn → Conexão).');
        $add('connection_revision_current',$c&&$g&&$c['revision']===($g['connection_revision']??-1),'destino_alterado','A conexão mudou depois da concessão. Reconfirme a concessão de Conversions API.');
        $add('account_selected',$c&&$g&&in_array((string)($g['account_id']??''),$c['assets']['ads']??[],true),'asset_access_denied','Marque a conta de anúncios concedida em Ativos → ads e salve.');
        $rule=$g['rule']??[];
        $add('rule_api_source',($rule['conversion_method']??'')==='CONVERSIONS_API','regra_sem_fonte_api','Escolha uma regra com fonte Conversions API (Campaign Manager → Measurement → Conversion tracking). Regra do Insight Tag não serve ao servidor.');
        $add('rule_enabled',($rule['enabled']??false)===true,'regra_inativa','Ative a regra no Campaign Manager e reconfirme a concessão.');
        $proof=$c?self::proof($c):null;$scopes=$proof['scopes']??($g['scopes']??[]);$missing=array_values(array_diff(['rw_conversions','r_ads'],$scopes));
        if($proof!==null){$invalid=self::proofFailure($proof);$add('token_proof_valid',$invalid===null,$invalid??'ok','A prova local indica Access Token inativo ou expirado. Renove e revalide a credencial antes de retomar as conversões.');}
        $add('token_scopes',$scopes!==[]&&!$missing,$scopes===[]?'escopo_nao_verificado':'sem_escopo','Valide o Access Token: o aplicativo precisa de rw_conversions e r_ads (Developers → aplicativo → Products/Auth).');
        $principal=false;if($g&&!empty($g['principal'])){try{ConsumerGrants::authorize($g);$principal=true;}catch(Fault $e){$principal=false;}}
        $add('grant_owner_authorized',$principal,'not_authorized','O administrador que concedeu perdeu acesso ao site. Um administrador atual deve reconfirmar a concessão.');
        $match=null;
        if(isset($i['conversion_id'])){$match=$g&&(string)($g['conversion_id']??'')===$i['conversion_id'];$add('core_rule_matches_grant',$match,'regra_divergente','O ID de regra de servidor do Site Core (Medição → Conversions API) deve ser igual à regra concedida aqui ('.(string)($g['conversion_id']??'nenhuma').').');}
        $expires=(int)($c['expires_at']??0);$soon=$expires>0&&$expires-time()<=3*86400;
        $add('token_not_expiring',!$soon,'token_expira_em_breve','O Access Token vence em até 3 dias; renove ou cadastre o token de renovação.',false);
        $age=isset($proof['checked_at'])?(int)floor((time()-(int)$proof['checked_at'])/86400):null;
        $add('scope_proof_recent',$age!==null&&$age<=30,'prova_de_escopo_antiga','Revalide o Access Token para renovar a prova local de escopos.',false);
        $audit=ServiceAudit::capabilities();
        $add('central_audit_registered',!empty($audit['central_registered']),(string)$audit['central_audit'],'Instale/atualize o Fator3 MCP (0.28.0 ou posterior) para registrar os envios de serviço no Registro central.',false);
        $blocking=array_values(array_filter($checks,static fn($x)=>$x['blocking']&&!$x['ok']));
        return ['consumer_id'=>self::CONSUMER,'contract'=>self::CONTRACT,'ready'=>!$blocking,'blocking_count'=>count($blocking),'checks'=>$checks,
            'grant'=>$g?['enabled'=>$enabled,'connection_id'=>$g['connection_id']??null,'account_id'=>$g['account_id']??null,'conversion_id'=>isset($g['conversion_id'])?(string)$g['conversion_id']:null,'rule_method'=>$rule['conversion_method']??null,'rule_checked_at'=>$rule['checked_at']??null,'revision'=>$r['revision']]:null,
            'scope_proof'=>['checked'=>$proof!==null,'scopes'=>array_values(array_intersect($scopes,['rw_conversions','r_ads'])),'checked_at'=>$proof['checked_at']??null,'age_days'=>$age],
            'core_rule_match'=>$match,'central_audit'=>$audit['central_audit'],'remote_checked'=>false];
    }
    public static function payload(array $p): array {
        $check=rest_validate_value_from_schema($p,ConversionSchemas::payload(),'conversion');if(is_wp_error($check))throw new Fault('payload_invalido','Evento fora do contrato site-linkedin-conversion/1.0.0.');
        if($p['eventId']!==$p['event_id'])throw new Fault('event_id_divergente','Preserve o mesmo ID original do evento.');
        if($p['conversionHappenedAt']>time()*1000+300000||$p['conversionHappenedAt']<(time()-90*86400)*1000)throw new Fault('instante_invalido','O instante original deve estar dentro de 90 dias, em milissegundos.');
        $user=$p['user'];$types=[];foreach($user['userIds']??[] as $id){if(isset($types[$id['idType']]))throw new Fault('payload_invalido','Identificador repetido.');$types[$id['idType']]=true;
            $pattern=$id['idType']==='SHA256_EMAIL'?'/^[a-f0-9]{64}$/D':'/^[A-Za-z0-9._~-]{1,500}$/D';if(!preg_match($pattern,$id['idValue']))throw new Fault('payload_invalido','Identificador de conversão inválido.');}
        $info=$user['userInfo']??[];if(isset($info['firstName'])!==isset($info['lastName']))throw new Fault('payload_invalido','Nome e sobrenome devem ser enviados juntos.');
        if(!$types&&empty($info['firstName']))throw new Fault('sem_identificador','O evento não contém identificador utilizável.');
        foreach($info as $value)if(trim($value)===''||preg_match('/[\x00-\x1f]/',$value))throw new Fault('payload_invalido','Campo de identificação inválido.');
        return array_intersect_key($p,array_flip(['conversion','conversionHappenedAt','conversionValue','eventId','user']));
    }
    private static function digest($v): string {return hash_hmac('sha256',Util::json($v),wp_salt('auth'));}
    private static function failure(string $code,int $http=0,bool $proven=true,int $retry=0): array {return ['status'=>$proven?'recusado':'incerto','code'=>$code,'http'=>$http,'non_delivery_proven'=>$proven]+($retry?['retry_after'=>$retry]:[]);}
    public static function sendBound(array $payload,string $ref): array {return self::deliver([$payload],$ref)[0];}
    public static function deliver(array $payloads,string $ref,?array $human=null,?string $stageAction=null): array {
        try{return Store::lock('conversion-delivery',static function()use($payloads,$ref,$human,$stageAction){
            if(!$payloads||count($payloads)>100)throw new Fault('lote_invalido','Envie de 1 a 100 eventos.');
            [$g,$c,$grantRevision]=$stageAction!==null?StageConversions::context($stageAction,$ref):self::context($ref);if($human){Access::owned($human);Access::connection($c,'ads',$g['account_id']);}
            $wire=[];$keys=[];$results=[];$rows=[];$seen=[];
            // Validate the entire batch before any remote effect. No PII persists in the journal.
            foreach($payloads as $n=>$p){$body=$stageAction!==null?StageConversions::payload($p,$stageAction):self::payload($p);if($body['conversion']!=='urn:lla:llaPartnerConversion:'.$g['conversion_id'])throw new Fault('regra_divergente','Evento de outra regra.');
                $key=self::digest($stageAction!==null?[StageConversions::CONSUMER,StageConversions::PURPOSE,$g['account_id'],$g['conversion_id'],$body['eventId']]:[$g['account_id'],$g['conversion_id'],$body['eventId']]);if(isset($seen[$key]))throw new Fault('evento_repetido_no_lote','O lote contém o mesmo evento mais de uma vez.');$seen[$key]=true;
                $hash=self::digest($stageAction!==null?$p:$body);$old=Store::get('conversion_event',$key);
                if($old){$v=$old['value'];if(!hash_equals($v['payload_digest'],$hash))throw new Fault('idempotency_conflict','O evento já foi admitido com outro conteúdo ou instante.');
                    if(in_array($v['state'],['confirmed','dispatching','uncertain'],true)){$results[$n]=$v['result']+['operation_id'=>$key,'replayed'=>true,'central_audit'=>!empty($v['service'])?ServiceAudit::status($old):CentralAudit::status()];continue;}}
                $wire[]=$body;$keys[]=$n;$rows[$n]=[$key,$old,['connection_id'=>$c['id'],'account_id'=>$g['account_id'],'conversion_id'=>$g['conversion_id'],'principal'=>$human??$g['principal'],'service'=>!$human,'payload_digest'=>$hash,'state'=>'prepared','created_at'=>$old['value']['created_at']??time(),'before'=>['status'=>'nao_enviado'],'after'=>null,'operation'=>count($payloads)>1?'send-conversion-events':'send-conversion-event','result'=>self::failure('envio_sem_recibo',0,false)]];
                if($stageAction!==null)$rows[$n][2]+=['grant_key'=>StageConversions::key($stageAction),'consumer_id'=>StageConversions::CONSUMER,'purpose'=>StageConversions::PURPOSE,'action'=>$stageAction];
                if(!$human)$rows[$n][2]['service_identity']=ServiceAudit::bind($g,$grantRevision)+['operation_id'=>$key];
            }
            if(!$wire){ksort($results);return array_values($results);}
            Http::budget(30,25);self::inspect($c);self::role($c,$g['account_id']);self::rule($c,$g['account_id'],$g['conversion_id']);
            $sent=false;
            try{
                $response=Http::request($c,'conversionEvents',[],'POST',count($wire)===1?$wire[0]:['elements'=>$wire],static function()use($ref,$c,$g,$grantRevision,$human,$stageAction,&$rows,&$sent){
                    [,,$currentGrantRevision]=$stageAction!==null?StageConversions::context($stageAction,$ref):self::context($ref);if($currentGrantRevision!==$grantRevision)throw new Fault('service_grant_changed','Concessão alterada antes do envio.');Connections::revalidate($c);if($human)Access::owned($human);
                    foreach($rows as &$item){[$key,$old,$v]=$item;$v['state']='dispatching';$r=Store::put('conversion_event',$key,$v,$old['revision']??0);$item=[$key,$r,$v];}unset($item);$sent=true;
                });
                $entries=count($wire)===1?[['status'=>$response['status']]]:($response['body']['elements']??null);
                $valid=is_array($entries)&&array_is_list($entries)&&count($entries)===count($wire);
                foreach($keys as $pos=>$n){$status=$valid&&is_int($entries[$pos]['status']??null)?$entries[$pos]['status']:0;
                    $results[$n]=$status===201?['status'=>'entregue','code'=>'linkedin_http_201','http'=>201,'non_delivery_proven'=>false]:self::failure($status?'linkedin_http_'.$status:'recibo_invalido',$status,$status>=400&&$status<500&&$status!==408);}
            }catch(Fault $e){$http=(int)($e->details['http_status']??0);$proven=!$sent||($http>=400&&$http<500&&$http!==408);foreach($keys as $n)$results[$n]=self::failure($http?'linkedin_http_'.$http:$e->reason,$http,$proven,(int)($e->details['retry_after']??0));}
            foreach($rows as $n=>$item){[$key,$old,$v]=$item;$v['result']=$results[$n];$v['state']=$results[$n]['status']==='entregue'?'confirmed':($results[$n]['status']==='incerto'?'uncertain':'rejected');$v['after']=$v['state']==='uncertain'?null:$results[$n];
                // If persistence fails after dispatch, keep dispatching as the durable uncertainty guard.
                try{$r=Store::put('conversion_event',$key,$v,$old['revision']??0);$audit=self::event($key,$r);}catch(\Throwable $e){$results[$n]=self::failure('recibo_nao_persistido',0,false);$audit='service_journal_unavailable';}
                $results[$n]+=['operation_id'=>$key,'replayed'=>false,'central_audit'=>$audit];}
            ksort($results);return array_values($results);
        });}catch(Fault $e){return array_fill(0,max(1,count($payloads)),self::failure($e->reason,0,$e->reason!=='idempotency_conflict'));}catch(\Throwable $e){return array_fill(0,max(1,count($payloads)),self::failure('falha_interna',0,false));}
    }
    private static function event(string $key,array $r): string {
        if($r['value']['service'])return ServiceAudit::emit($r);
        if(!current_user_can('manage_options'))return 'not_authorized';
        try{do_action('f3_linkedin_mutation_recorded',['contract'=>'linkedin-mutation/1.0.0','provider'=>Config::SLUG,'operation_id'=>$key,'operation'=>$r['value']['operation'],'state'=>$r['value']['state'],'before_sha256'=>Management::revision($r['value']['before']),'after_sha256'=>$r['value']['after']===null?null:Management::revision($r['value']['after']),'reader'=>'linkedin/get-write-operation']);}catch(\Throwable $e){update_option(Config::KEY.'_audit_health','extension_event_failed',false);}
        return CentralAudit::status();
    }
    public static function operation(string $key): array {
        $r=Store::get('conversion_event',$key);if(!$r)throw new Fault('not_found','Operação ausente.');$v=$r['value'];if(!empty($v['service'])&&isset($v['service_identity']))return ServiceAudit::read($v['service_identity']);Access::owned($v['principal']);$c=Connections::get($v['connection_id']);Access::connection($c,'ads',$v['account_id']);
        return ['operation_id'=>$key,'operation_revision'=>$r['revision'],'state'=>$v['state'],'before'=>$v['before'],'after'=>$v['after'],'result'=>$v['result'],'central_audit'=>$v['service']?'service_principal_unsupported':CentralAudit::status()];
    }
    public static function dispatch(string $op,array $i): array {
        if($op==='get-stage-conversion-grants')return StageConversions::grants($i);
        if($op==='save-stage-conversion-grant')return StageConversions::save($i);
        if($op==='stage-conversion-capabilities')return StageConversions::capabilities($i['action']);
        if($op==='get-service-write-operation')return ServiceAudit::read($i);
        if($op==='list-conversion-rules')return self::rules($i);
        if($op==='save-conversion-grant')return self::saveGrant($i);
        if($op==='get-conversion-grant')return self::grant();
        if($op==='conversion-capabilities')return self::capabilities();
        if($op==='diagnose-conversions')return self::diagnose($i);
        $payloads=$op==='send-conversion-event'?[$i['payload']]:$i['payloads'];$principal=Access::principal();[$g,$c]=self::context($i['destination_ref']);Access::connection($c,'ads',$g['account_id']);
        foreach($payloads as $p){$body=self::payload($p);if($body['conversion']!=='urn:lla:llaPartnerConversion:'.$g['conversion_id'])throw new Fault('regra_divergente','Evento de outra regra.');}
        $digest=self::digest([$payloads,$i['destination_ref'],$principal,$c['revision'],$c['credential_generation']]);
        if($i['dry_run']??true){self::inspect($c);self::role($c,$g['account_id']);self::rule($c,$g['account_id'],$g['conversion_id']);$token=bin2hex(random_bytes(32));Store::put('conversion_preview',hash('sha256',$token),['digest'=>$digest,'expires'=>time()+600],0,time()+600);return ['dry_run'=>true,'remote_write_sent'=>false,'event_count'=>count($payloads),'conversion_id'=>$g['conversion_id'],'confirm_token'=>$token,'expires_at'=>time()+600,'personal_data_returned'=>false];}
        $p=Store::get('conversion_preview',hash('sha256',$i['confirm_token']??''));if(empty($i['confirm'])||!$p||$p['value']['expires']<time()||!hash_equals($p['value']['digest'],$digest))throw new Fault('preview_required','Gere e confirme a prévia do mesmo evento e destino.');
        $rows=self::deliver($payloads,$i['destination_ref'],$principal);return $op==='send-conversion-event'?$rows[0]:['results'=>$rows,'event_count'=>count($rows)];
    }
}

/** Public PHP adapter. Capability reads never contact LinkedIn or impersonate a user. */
final class ConversionDelivery {
    public function capabilities(): array {return Conversions::capabilities();}
    public function send(array $payload): array {return ['status'=>'recusado','code'=>'destination_binding_required','http'=>0,'non_delivery_proven'=>true];}
    public function sendBound(array $payload,string $destination_ref): array {return Conversions::sendBound($payload,$destination_ref);}
}
