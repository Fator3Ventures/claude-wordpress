<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

final class Management {
    public const FACETS=['local'=>'locations','setor'=>'industries','empresa'=>'employers','cargo'=>'titles','funcao'=>'jobFunctions','senioridade'=>'seniorities','competencia'=>'skills','interesse'=>'interests','segmento'=>'audienceMatchingSegments'];
    public static function handles(string $op): bool {return isset(ManagementSchemas::all()[$op]);}
    public static function writes(string $op): bool {return self::handles($op)&&!str_starts_with($op,'get-')&&!str_starts_with($op,'search-')&&!str_starts_with($op,'list-');}
    public static function destructive(string $op): bool {return str_starts_with($op,'delete-')||str_starts_with($op,'activate-')||in_array($op,['create-post','update-post','create-comment'],true);}
    private static function canonical($v) {if(is_array($v)){if(!array_is_list($v))ksort($v);foreach($v as &$x)$x=self::canonical($x);unset($x);}return $v;}
    public static function revision(array $v): string {return hash('sha256',Util::json(self::canonical($v)));}
    private static function account(string $id): string {return 'urn:li:sponsoredAccount:'.$id;}
    private static function page(string $id): string {return 'urn:li:organization:'.$id;}
    private static function ads(string $kind): bool {return in_array($kind,['campaign-group','campaign','creative','ad-account'],true);}
    private static function path(string $kind,array $i,bool $create=false): string {
        $root='adAccounts/'.($i['account_id']??'');
        return match($kind){
            'campaign-group'=>$root.'/adCampaignGroups'.(!$create?'/'.$i['campaign_group_id']:''),
            'campaign'=>$root.'/adCampaigns'.(!$create?'/'.$i['campaign_id']:''),
            'creative'=>$root.'/creatives'.(!$create?'/'.rawurlencode('urn:li:sponsoredCreative:'.$i['creative_id']):''),
            'ad-account'=>$root,'organization'=>'organizations/'.$i['page_id'],
            'post'=>$create?'posts':'posts/'.rawurlencode($i['post_id']),
            'comment'=>'socialActions/'.rawurlencode($i['post_id']).'/comments',
            'image-upload'=>'images','video-upload'=>'videos',
            default=>throw new Fault('unsupported','Recurso de gestão desconhecido.')};
    }
    private static function scope(string $kind,bool $write): array {return self::ads($kind)?($write?['rw_ads']:[]):($write?['w_organization_social','r_organization_social']:['r_organization_social']);}
    private static function access(array $c,string $kind,array $i): void {Access::connection($c,self::ads($kind)?'ads':'pages',self::ads($kind)?$i['account_id']:$i['page_id']);Connections::usable($c);}
    private static function fetch(array $c,string $kind,array $i): array {
        self::access($c,$kind,$i);$r=Http::request($c,self::path($kind,$i))['body'];
        if(self::ads($kind)){
            if($kind==='ad-account'){if((string)($r['id']??'')!==$i['account_id'])throw new Fault('asset_access_denied','Conta retornada divergente.');}
            else {
                if($kind==='creative'){
                    if(isset($r['account'])&&$r['account']!==self::account($i['account_id']))throw new Fault('asset_access_denied','Anúncio de outra conta.');
                    if(!preg_match('/^urn:li:sponsoredCampaign:([0-9]+)$/D',(string)($r['campaign']??''),$m))throw new Fault('upstream_invalid','Campanha do anúncio ausente.');
                    self::fetch($c,'campaign',['connection_id'=>$c['id'],'account_id'=>$i['account_id'],'campaign_id'=>$m[1]]);
                }elseif(($r['account']??'')!==self::account($i['account_id']))throw new Fault('asset_access_denied','Objeto de outra conta.');
                $key=str_replace('-','_',$kind).'_id';$wanted=$kind==='creative'?'urn:li:sponsoredCreative:'.$i[$key]:$i[$key];
                if((string)($r['id']??'')!==$wanted)throw new Fault('upstream_invalid','Identificador do objeto divergente.');
            }
        }elseif($kind==='organization'){if((string)($r['id']??'')!==$i['page_id'])throw new Fault('asset_access_denied','Página retornada divergente.');}
        elseif($kind==='post'&&(($r['author']??'')!==self::page($i['page_id'])||($r['id']??'')!==$i['post_id']))throw new Fault('asset_access_denied','Publicação não pertence à Página selecionada.');
        return $r;
    }
    public static function dispatch(string $op,array $i): array {
        if($op==='inspect-token')return Credentials::inspectOperation($i);
        if($op==='refresh-token')return Credentials::refresh($i);
        if($op==='oauth-start')return Credentials::start($i);
        if($op==='list-write-operations')return self::operations($i);
        if($op==='get-write-operation')return self::operation($i['operation_id']);
        if($op==='reconcile-write-operation')return self::reconcile($i);
        if($op==='close-write-operation')return self::close($i);
        if(str_starts_with($op,'search-'))return self::search($i+($op==='search-locations'?['facet'=>'local']:[]));
        [$verb,$kind]=explode('-',$op,2);$c=Connections::get($i['connection_id']);self::access($c,$kind,$i);
        if($verb==='get'){$proof=Credentials::requireScopes($c,self::scope($kind,false));if(self::ads($kind)&&!array_intersect(['r_ads','rw_ads'],$proof['scopes']))throw new Fault('scope_missing','Permissão de leitura de anúncios ausente.');$r=self::fetch($c,$kind,$i);return ['object'=>$r,'revision'=>self::revision($r)];}
        return self::write($op,$verb,$kind,$i);
    }
    public static function search(array $i): array {
        $c=Connections::get($i['connection_id']);Access::connection($c,'ads',$i['account_id']);$proof=Credentials::requireScopes($c,[]);if(!array_intersect(['r_ads','rw_ads'],$proof['scopes']))throw new Fault('scope_missing','Permissão de leitura de anúncios ausente.');
        return self::searchWith($c,$i);
    }
    private static function searchWith(array $c,array $i): array {
        $facet=self::FACETS[$i['facet']];$offset=$i['offset']??0;
        if($i['facet']==='segmento'){$path='adSegments';$q=['q'=>'accounts','accounts'=>[self::account($i['account_id'])],'start'=>$offset,'count'=>100];}
        else{$path='adTargetingEntities';$fixed=in_array($facet,['jobFunctions','seniorities'],true);$q=['q'=>$fixed?'adTargetingFacet':'typeahead','facet'=>'urn:li:adTargetingFacet:'.$facet,'start'=>$offset,'count'=>100,'locale'=>['language'=>$i['language']??'pt','country'=>$i['country']??'BR']];if(!$fixed)$q+=['query'=>$i['search'],'queryVersion'=>'QUERY_USES_URNS'];}
        $body=Http::request($c,$path,$q)['body'];$rows=Adapter::elements($body);$out=[];
        foreach($rows as $r){
            if($i['facet']==='segmento'){if(($r['account']??'')!==self::account($i['account_id']))continue;$urn='urn:li:adSegment:'.Util::numeric((string)($r['id']??''));}
            else{if(($r['facetUrn']??'')!=='urn:li:adTargetingFacet:'.$facet)continue;$urn=(string)($r['urn']??'');if(!preg_match('/^urn:li:[A-Za-z]+:[A-Za-z0-9_-]+$/D',$urn))continue;}
            $name=(string)($r['name']??'');if(mb_stripos($name,$i['search'])===false)continue;$out[]=['name'=>$name,'urn'=>$urn,'facet'=>$i['facet'],'search_offset'=>$offset];
        }
        return ['rows'=>$out,'next_offset'=>Adapter::more($body,$offset,count($rows),100)?$offset+count($rows):null,'selection_required'=>true];
    }
    private static function targeting(array $c,array $i,array $criteria): array {
        $include=[];$exclude=[];
        foreach($criteria as $item){$found=self::searchWith($c,['account_id'=>$i['account_id'],'facet'=>$item['facet'],'search'=>$item['name'],'offset'=>$item['search_offset']??0]);
            $matches=array_values(array_filter($found['rows'],static fn($r)=>isset($item['selected_urn'])?hash_equals($item['selected_urn'],$r['urn']):mb_strtolower($r['name'])===mb_strtolower($item['name'])));
            if(count($matches)!==1||(!isset($item['selected_urn'])&&$found['next_offset']!==null))throw new Fault('targeting_ambiguous','Escolha um resultado único da busca de segmentação.',['facet'=>$item['facet'],'choices'=>$found['rows'],'next_offset'=>$found['next_offset']]);
            $facet='urn:li:adTargetingFacet:'.self::FACETS[$item['facet']];if(!empty($item['exclude']))$exclude[$facet][]=$matches[0]['urn'];else $include[$facet][]=$matches[0]['urn'];
        }
        if(empty($include['urn:li:adTargetingFacet:locations']))throw new Fault('invalid_input','Inclua ao menos um local na segmentação.');
        $out=['include'=>['and'=>[]]];foreach($include as $facet=>$ids)$out['include']['and'][]=['or'=>[$facet=>array_values(array_unique($ids))]];
        if($exclude)$out['exclude']=['or'=>$exclude];return $out;
    }
    private static function media(array $c,string $urn,string $page,string $type): void {
        if(!str_starts_with($urn,'urn:li:'.$type.':'))throw new Fault('invalid_input','Tipo de mídia divergente.');
        $r=Http::request($c,($type==='image'?'images/':'videos/').rawurlencode($urn))['body'];
        if(($r['owner']??'')!==self::page($page))throw new Fault('asset_access_denied','A mídia não pertence à Página selecionada.');
        if(($r['status']??'')!=='AVAILABLE')throw new Fault('media_not_ready','A mídia ainda não está disponível para publicação.');
    }
    private static function body(string $kind,string $verb,array $i,array $c,array $before): array {
        $f=$i['fields']??[];$body=[];$status=$kind==='creative'?'intendedStatus':'status';
        if($verb==='activate')return [$status=>'ACTIVE'];
        if($verb==='delete')return [$status=>'PENDING_DELETION'];
        if($verb==='initialize')return ['initializeUploadRequest'=>['owner'=>self::page($i['page_id'])]+($kind==='video-upload'?['fileSizeBytes'=>$i['file_size'],'uploadCaptions'=>false,'uploadThumbnail'=>false]:[])];
        if(self::ads($kind)){
            if($kind==='campaign-group'&&$verb==='create'&&empty($f['schedule']['start']))throw new Fault('invalid_input','Informe schedule.start para criar o grupo de campanhas.');
            foreach(['name'=>'name','total_budget'=>'totalBudget','daily_budget'=>'dailyBudget','bid'=>'unitCost','schedule'=>'runSchedule','type'=>'type','cost_type'=>'costType','objective'=>'objectiveType','format'=>'format','optimization'=>'optimizationTargetType','bidding_strategy'=>'biddingStrategy','offsite_delivery'=>'offsiteDeliveryEnabled','audience_expansion'=>'audienceExpansionEnabled','status'=>$status] as $from=>$to)if(array_key_exists($from,$f))$body[$to]=$f[$from];
            if(isset($f['schedule']['end'])&&$f['schedule']['end']<=$f['schedule']['start'])throw new Fault('invalid_input','O fim deve ser posterior ao início.');
            $account=null;foreach(['totalBudget','dailyBudget','unitCost'] as $field)if(isset($body[$field])){$account??=isset($before['currency'])?$before:self::fetch($c,'ad-account',$i);if($body[$field]['currency']!==($account['currency']??null))throw new Fault('invalid_input','Use a moeda da conta de anúncios.');}
            if($kind==='campaign'){
                if(isset($f['campaign_group_id'])){$parent=self::fetch($c,'campaign-group',$i+['campaign_group_id'=>$f['campaign_group_id']]);$body['campaignGroup']='urn:li:sponsoredCampaignGroup:'.$f['campaign_group_id'];}
                if(isset($f['language'])||isset($f['country'])){$locale=$before['locale']??[];if(isset($f['language']))$locale['language']=$f['language'];if(isset($f['country']))$locale['country']=$f['country'];if(count($locale)!==2)throw new Fault('invalid_input','Informe idioma e país.');$body['locale']=$locale;}
                if(isset($f['targeting']))$body['targetingCriteria']=self::targeting($c,$i,$f['targeting']);
            }
            if($kind==='creative'&&$verb==='create'){
                Access::asset($c,'pages',$f['page_id']);Credentials::requireScopes($c,['rw_ads','r_organization_social']);
                self::fetch($c,'post',['page_id'=>$f['page_id'],'post_id'=>$f['post_id']]);$campaign=self::fetch($c,'campaign',$i+['campaign_id'=>$f['campaign_id']]);
                $body['campaign']='urn:li:sponsoredCampaign:'.$f['campaign_id'];$body['content']=['reference'=>$f['post_id']];
                if(isset($f['form_id'])){Access::asset($c,'leads',$i['account_id']);if(!in_array($f['form_id'],$c['forms'][$i['account_id']]??[],true))throw new Fault('asset_access_denied','Formulário não selecionado.');
                    $form=Http::request($c,'leadForms/'.$f['form_id'])['body'];if(($form['owner']['sponsoredAccount']??'')!==self::account($i['account_id']))throw new Fault('asset_access_denied','Formulário de outra conta.');
                    $body['leadgenCallToAction']=['destination'=>'urn:li:adForm:'.$f['form_id'],'label'=>$f['call_to_action']??'LEARN_MORE'];
                }elseif(($campaign['objectiveType']??'')==='LEAD_GENERATION')throw new Fault('invalid_input','A campanha exige um formulário selecionado.');
            }
            if($verb==='create'){$body[$status]='DRAFT';if($kind!=='creative')$body['account']=self::account($i['account_id']);}
        }elseif($kind==='post'){
            if($verb==='update')return ['commentary'=>$f['text']];
            $body=['author'=>self::page($i['page_id']),'commentary'=>$f['text'],'visibility'=>'PUBLIC','distribution'=>['feedDistribution'=>'MAIN_FEED','targetEntities'=>[],'thirdPartyDistributionChannels'=>[]],'lifecycleState'=>'PUBLISHED','isReshareDisabledByAuthor'=>false];
            if(in_array($f['content_type'],['image','video'],true)){if(empty($f['media_id']))throw new Fault('invalid_input','Selecione uma mídia disponível.');self::media($c,$f['media_id'],$i['page_id'],$f['content_type']);$body['content']=['media'=>['id'=>$f['media_id']]+(isset($f['title'])?['title'=>$f['title']]:[])];}
            if($f['content_type']==='article'){
                if(empty($f['article_url'])||!in_array(wp_parse_url($f['article_url'],PHP_URL_SCHEME),['http','https'],true)||empty($f['title']))throw new Fault('invalid_input','Artigo exige endereço HTTP(S) e título.');
                $article=['source'=>$f['article_url'],'title'=>$f['title']];if(isset($f['description']))$article['description']=$f['description'];if(isset($f['thumbnail_id'])){self::media($c,$f['thumbnail_id'],$i['page_id'],'image');$article['thumbnail']=$f['thumbnail_id'];}$body['content']=['article'=>$article];
            }
        }elseif($kind==='comment')$body=['actor'=>self::page($i['page_id']),'object'=>$i['post_id'],'message'=>['text'=>$f['text']]];
        if(!$body)throw new Fault('invalid_input','Nenhum campo alterável foi informado.');return $body;
    }
    private static function before(array $c,string $verb,string $kind,array $i): array {
        if($verb==='create'||$verb==='initialize')return self::fetch($c,self::ads($kind)?'ad-account':($kind==='comment'?'post':'organization'),$i);
        return self::fetch($c,$kind,$i);
    }
    private static function requestHash(string $op,array $i): string {unset($i['dry_run'],$i['confirm_token'],$i['confirm']);return self::revision(['operation'=>$op,'input'=>$i]);}
    private static function write(string $op,string $verb,string $kind,array $i): array {
        Http::budget(30,25);$principal=Access::principal();$digest=self::requestHash($op,$i);$key=hash('sha256',Util::json([$principal,$i['connection_id'],$i['request_key']]));
        $targetLock=self::revision([$kind,$i['account_id']??null,$i['page_id']??null,$i[str_replace('-','_',$kind).'_id']??null,$i['post_id']??null]);
        return Store::lock('management-target:'.$targetLock,static fn()=>Store::lock('connection:'.$i['connection_id'],static function()use($op,$verb,$kind,$i,$principal,$digest,$key){
            $c=Connections::get($i['connection_id']);self::access($c,$kind,$i);$old=Store::get('mutation',$key);
            if($old){if(!hash_equals($digest,$old['value']['request_hash']))throw new Fault('idempotency_conflict','A chave já foi usada com outro conteúdo.');Access::owned($old['value']['principal']);return self::projection($key,$old,true);}
            Credentials::requireScopes($c,self::scope($kind,true));$before=self::before($c,$verb,$kind,$i);$revision=self::revision($before);
            if(!hash_equals($i['expected_revision'],$revision))throw new Fault('revision_conflict','O objeto remoto mudou. Releia e refaça a prévia.',['current_revision'=>$revision]);
            $body=self::body($kind,$verb,$i,$c,$before);$intent=self::revision([$op,$i['account_id']??null,$i['page_id']??null,$i['post_id']??null,$i[str_replace('-','_',$kind).'_id']??null,$body]);$guard=Store::get('mutation_guard',$intent);if($guard){$pending=Store::get('mutation',$guard['value']['operation_id']);if($pending&&in_array($pending['value']['state'],['prepared','dispatching','uncertain','awaiting_verification'],true))throw new Fault('operation_uncertain','Reconcilie a intenção anterior antes de usar outra chave.',['operation_id'=>$guard['value']['operation_id']]);}$path=self::path($kind,$i,$verb==='create');$query=[];$method='POST';$wire=$body;
            if($verb==='initialize')$query=['action'=>'initializeUpload'];
            elseif($verb==='delete'&&($kind==='post'||($before[$kind==='creative'?'intendedStatus':'status']??'')==='DRAFT')){$method='DELETE';$wire=null;}
            elseif(in_array($verb,['update','activate','delete'],true))$wire=['patch'=>['$set'=>$body]];
            $payload=['request_hash'=>$digest,'body_hash'=>self::revision($body),'revision'=>$revision,'connection_revision'=>$c['revision'],'credential_generation'=>$c['credential_generation'],'principal'=>$principal,'expires'=>time()+600];
            if($i['dry_run']??true){$confirmation=bin2hex(random_bytes(32));Store::put('write_preview',hash('sha256',$confirmation),$payload,0,$payload['expires']);return ['dry_run'=>true,'remote_write_sent'=>false,'before'=>$before,'proposed'=>$body,'method'=>$method,'destructive'=>self::destructive($op),'confirm_token'=>$confirmation,'expected_revision'=>$revision,'expires_at'=>$payload['expires'],'concurrency'=>'optimistic_read_before_write'];}
            if(empty($i['confirm_token'])||empty($i['confirm']))throw new Fault('preview_required','Gere e confirme uma prévia antes de executar.');
            $saved=Store::get('write_preview',hash('sha256',$i['confirm_token']));$preview=$saved['value']??[];if(($preview['expires']??0)<time())throw new Fault('preview_stale','A prévia expirou.');foreach(['request_hash','body_hash','revision','connection_revision','credential_generation','principal'] as $field)if(($preview[$field]??null)!==$payload[$field])throw new Fault('preview_stale','A prévia não corresponde ao conteúdo, credencial ou autorização atual.');
            $v=['operation'=>$op,'connection_id'=>$c['id'],'principal'=>$principal,'request_hash'=>$digest,'kind'=>$kind,'verb'=>$verb,'input'=>array_intersect_key($i,array_flip(['connection_id','account_id','page_id','campaign_group_id','campaign_id','creative_id','post_id'])),'before'=>$before,'desired'=>$body,'path'=>$path,'method'=>$method,'state'=>'prepared','created_at'=>time(),'remote_id'=>null,'remote_effect'=>'none','after'=>null];
            $r=Store::put('mutation',$key,$v);Store::put('mutation_guard',$intent,['operation_id'=>$key],$guard['revision']??0);$sent=false;
            try{
                $receipt=Http::request($c,$path,$query,$method,$wire,static function()use($c,$principal,$key,&$r,&$v,&$sent){Access::checkPrincipal($principal);Connections::revalidate($c);$v['state']='dispatching';$v['remote_effect']='unknown';$r=Store::put('mutation',$key,$v,$r['revision']);$sent=true;});
                $v['remote_effect']='confirmed';$v['remote_id']=$receipt['id']?:($receipt['body']['id']??null);$v['state']='awaiting_verification';
                if($verb==='initialize'){$value=$receipt['body']['value']??[];$v['remote_id']=$value[$kind==='image-upload'?'image':'video']??null;$v['upload']=$value;}
                $r=Store::put('mutation',$key,$v,$r['revision']);$v['after']=self::verify($c,$v);$v['state']='confirmed';$v['verified_at']=time();$r=Store::put('mutation',$key,$v,$r['revision']);
            }catch(Fault $e){$v['last_code']=$e->reason;$v['last_error']=array_intersect_key($e->details,array_flip(['http_status','provider_code','serviceErrorCode','provider_message','provider_message_sanitized','creation_rejected','action']));if($v['state']==='dispatching'){$rejected=$verb==='create'&&!$v['remote_id']&&!empty($e->details['creation_rejected']);$v['state']=$rejected?'rejected':($sent?'uncertain':'rejected_before_dispatch');if($rejected)$v['remote_effect']='none';}elseif(!$sent){$v['state']='rejected_before_dispatch';$v['remote_effect']='none';}$r=Store::put('mutation',$key,$v,$r['revision']);self::event($key,$r);throw new Fault($e->reason,$e->getMessage(),$e->details+['operation_id'=>$key,'state'=>$v['state'],'remote_effect'=>$v['remote_effect'],'requires_reconciliation'=>in_array($v['state'],['uncertain','dispatching','awaiting_verification'],true)]);}
            self::event($key,$r);return self::projection($key,$r);
        }));
    }
    private static function verify(array $c,array $v): array {
        $i=$v['input'];$kind=$v['kind'];$verb=$v['verb'];
        if($verb==='initialize'){
            $id=(string)$v['remote_id'];$type=$kind==='image-upload'?'image':'video';if(!preg_match('/^urn:li:'.$type.':[A-Za-z0-9_-]+$/D',$id))throw new Fault('operation_uncertain','Recibo de mídia ausente.');
            $r=Http::request($c,($type==='image'?'images/':'videos/').rawurlencode($id))['body'];if(($r['owner']??'')!==self::page($i['page_id']))throw new Fault('asset_access_denied','Proprietário da mídia divergente.');return $r;
        }
        if($verb==='create'){
            $id=(string)$v['remote_id'];if($kind==='post'){if(!preg_match('/^urn:li:(share|ugcPost):[0-9]+$/D',$id))throw new Fault('operation_uncertain','Recibo de publicação ausente.');$i['post_id']=$id;}
            elseif($kind==='comment'){
                if(!preg_match('/^[0-9]+$/D',$id))throw new Fault('operation_uncertain','Recibo de comentário ausente.');
                $r=Http::request($c,$v['path'].'/'.$id)['body'];if(($r['actor']??'')!==self::page($i['page_id'])||($r['message']['text']??null)!==$v['desired']['message']['text'])throw new Fault('verification_failed','O comentário relido diverge da solicitação.');return $r;
            }else{if($kind==='creative')$id=preg_replace('/^urn:li:sponsoredCreative:/','',$id);if(!preg_match('/^[0-9]+$/D',$id))throw new Fault('operation_uncertain','Recibo do objeto ausente.');$i[str_replace('-','_',$kind).'_id']=$id;}
        }
        try{$r=self::fetch($c,$kind,$i);}catch(Fault $e){if($v['method']==='DELETE'&&$e->reason==='resource_not_found')return ['deleted'=>true];throw $e;}
        if($v['method']==='DELETE')throw new Fault('verification_pending','A exclusão ainda não foi confirmada na releitura.');
        foreach($v['desired'] as $k=>$expected){if(in_array($k,['distribution','isReshareDisabledByAuthor'],true))continue;if(!array_key_exists($k,$r)||self::canonical($r[$k])!==self::canonical($expected))throw new Fault('verification_pending','A releitura ainda não confirma todos os campos enviados.',['field'=>$k]);}
        return $r;
    }
    public static function operations(array $i): array {
        Access::admin();$principal=Access::principal();Access::checkPrincipal($principal);$c=Connections::get($i['connection_id']);
        $binding=self::revision([$c['id'],$c['revision'],$principal,$i['state']??null,$i['limit']??50]);$after='';
        if(!empty($i['cursor'])){$cursor=Util::uncursor($i['cursor']);if(($cursor['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação fora do filtro ou autorização.');$after=$cursor['after'];}
        $limit=$i['limit']??50;$out=[];$scanned=0;$more=false;
        do{$rows=Store::scan('mutation',$after,100);$more=count($rows)===100;
            foreach($rows as $index=>$r){$after=$r['key'];$scanned++;$v=$r['value'];
                if(($v['connection_id']??'')===$c['id']&&(!isset($i['state'])||$v['state']===$i['state'])&&Util::same($principal,$v['principal']??[])){
                    try{$ads=self::ads($v['kind']);Access::asset($c,$ads?'ads':'pages',$ads?$v['input']['account_id']:$v['input']['page_id']);}
                    catch(Fault $e){if($e->reason==='asset_access_denied')continue;throw $e;}
                    $out[]=['operation_id'=>$r['key'],'operation_revision'=>$r['revision'],'operation'=>$v['operation'],'connection_id'=>$c['id'],'state'=>$v['state'],'account_id'=>$v['input']['account_id']??null,'page_id'=>$v['input']['page_id']??null,'created_at'=>$v['created_at']??null,'remote_effect'=>$v['remote_effect']??'unknown'];
                    if(count($out)===$limit){$more=$more||$index<count($rows)-1;break;}
                }
            }
        }while($more&&count($out)<$limit&&$scanned<500);
        Connections::revalidate($c);Access::checkPrincipal($principal);
        return ['operations'=>$out,'next_cursor'=>$more?Util::cursor(['binding'=>$binding,'after'=>$after,'expires'=>time()+900]):null,'order'=>'operation_id_ascending','scanned'=>$scanned,'remote_effect'=>'none'];
    }
    public static function operation(string $key): array {if(Store::get('conversion_event',$key))return Conversions::operation($key);$r=Store::get('mutation',$key);if(!$r)throw new Fault('not_found','Operação não encontrada.');Access::owned($r['value']['principal']);$c=Connections::get($r['value']['connection_id']);$i=$r['value']['input'];$ads=self::ads($r['value']['kind']);Access::connection($c,$ads?'ads':'pages',$ads?$i['account_id']:$i['page_id']);return self::projection($key,$r);}
    private static function projection(string $key,array $r,bool $replayed=false): array {
        $v=$r['value'];return ['operation_id'=>$key,'operation_revision'=>$r['revision'],'state'=>$v['state'],'replayed'=>$replayed,'remote_effect'=>$v['remote_effect'],'remote_id'=>$v['remote_id'],'before'=>$v['before'],'after'=>$v['after'],'last_code'=>$v['last_code']??null,'requires_reconciliation'=>in_array($v['state'],['prepared','dispatching','uncertain','awaiting_verification'],true),'last_error'=>$v['last_error']??null,'closure'=>$v['closure']??null,'migration'=>$v['migration']??null,'upload'=>$v['upload']??null,'central_audit'=>CentralAudit::status()];
    }
    private static function event(string $key,array $r): void {
        // Domain-owned extension event. Never import the MCP's private persistence classes.
        try{do_action('f3_linkedin_mutation_recorded',['contract'=>'linkedin-mutation/1.0.0','provider'=>Config::SLUG,'operation_id'=>$key,'operation'=>$r['value']['operation'],'state'=>$r['value']['state'],'before_sha256'=>self::revision($r['value']['before']),'after_sha256'=>$r['value']['after']===null?null:self::revision($r['value']['after']),'reader'=>'linkedin/get-write-operation']);}catch(\Throwable $e){update_option(Config::KEY.'_audit_health','extension_event_failed',false);}
    }
    private static function close(array $i): array {
        Access::admin();$r=Store::get('mutation',$i['operation_id']);if(!$r)throw new Fault('not_found','Operação ausente.');$v=$r['value'];Access::owned($v['principal']);
        $input=$v['input'];$target=self::revision([$v['kind'],$input['account_id']??null,$input['page_id']??null,$input[str_replace('-','_',$v['kind']).'_id']??null,$input['post_id']??null]);
        return Store::lock('management-target:'.$target,static fn()=>Store::lock('connection:'.$v['connection_id'],static function()use($i){
            $r=Store::get('mutation',$i['operation_id']);$v=$r['value'];Access::owned($v['principal']);$c=Connections::get($v['connection_id']);Access::connection($c,self::ads($v['kind'])?'ads':'pages',self::ads($v['kind'])?$v['input']['account_id']:$v['input']['page_id']);
            if($r['revision']!==$i['expected_operation_revision'])throw new Fault('revision_conflict','Releia o diário antes de encerrar.');
            if($v['state']==='closed')return self::projection($i['operation_id'],$r,true);
            if(!in_array($v['state'],['uncertain','dispatching','awaiting_verification','prepared'],true))throw new Fault('invalid_state','Esta operação já está encerrada.');
            $warning='Encerrar libera somente esta intenção. O efeito remoto permanece desconhecido; outra criação pode duplicar um objeto existente. Pesquise no fornecedor antes de repetir.';
            if($i['dry_run']??true)return ['dry_run'=>true,'operation_id'=>$i['operation_id'],'operation_revision'=>$r['revision'],'state'=>$v['state'],'proposed_state'=>'closed','warning'=>$warning,'remote_write_sent'=>false];
            if(!$i['accept_duplicate_risk']||trim($i['note'])==='')throw new Fault('confirmation_required','Informe o motivo e reconheça o risco de duplicação.');
            $v['closure']=['reason'=>$i['reason'],'note'=>sanitize_text_field($i['note']),'by'=>Access::principal(),'at'=>time(),'previous_state'=>$v['state'],'previous_remote_effect'=>$v['remote_effect'],'duplicate_risk_accepted'=>true];$v['state']='closed';
            $r=Store::put('mutation',$i['operation_id'],$v,$r['revision']);self::event($i['operation_id'],$r);return self::projection($i['operation_id'],$r)+['warning'=>$warning];
        }));
    }
    /** The 0.14 diary stored only last_code. Never reinterpret generic upstream_error as rejection. */
    public static function upgrade(): array {
        if(Util::boot(Config::KEY.'_mutation_rejections_015',false))return ['complete'=>true];
        return Store::lock('mutation-rejections-015',static function(){
            $m=Store::get('migration','mutation-rejections-015');$after=$m['value']['after']??'';$rows=Store::scan('mutation',$after,50);$changed=0;
            foreach($rows as $row){$changed+=Store::lock('connection:'.$row['value']['connection_id'],static function()use($row){
                $r=Store::get('mutation',$row['key']);$v=$r['value'];if(($v['verb']??'')!=='create'||($v['state']??'')!=='uncertain'||!empty($v['remote_id'])||!empty($v['after']))return 0;
                $code=$v['last_code']??'';$source='persisted_error_envelope';$error=$v['last_error']??[];$status=!empty($error['creation_rejected'])&&in_array($error['http_status']??0,[400,401,403,404,422],true)?$error['http_status']:null;
                // Incident evidence supplied by the owner in request 18; narrowly bind the exceptional 422.
                if(!$status&&$code==='upstream_error'&&str_starts_with($row['key'],'ea7838f5')&&$v['operation']==='create-campaign-group'&&$v['connection_id']==='linkedin-cto-office'&&($v['input']['account_id']??'')==='558431216'&&empty($v['desired']['runSchedule'])&&($v['desired']['name']??'')==='TESTE FROTA 92f - rascunho a apagar (01/11)'){$status=422;$source='received_request_18_2026-11-01';}
                if(!$status&&$code==='asset_access_denied'&&str_starts_with($row['key'],'66c4c78e')&&$v['operation']==='create-campaign-group'&&$v['connection_id']==='linkedin-cto-office'&&($v['input']['account_id']??'')==='558431216'&&!empty($v['desired']['runSchedule']['start'])){$status=403;$source='received_request_18_2026-11-01';}
                if(!$status)return 0;
                $v['migration']=['version'=>'0.15.0','at'=>time(),'previous_state'=>$v['state'],'previous_remote_effect'=>$v['remote_effect'],'legacy_code'=>$code,'rejection_status_inferred'=>$status,'evidence_source'=>$source];$v['state']='rejected';$v['remote_effect']='none';$r=Store::put('mutation',$row['key'],$v,$r['revision']);self::event($row['key'],$r);return 1;
            });$after=$row['key'];}
            $complete=count($rows)<50;Store::put('migration','mutation-rejections-015',['after'=>$after,'complete'=>$complete],$m['revision']??0);if($complete)update_option(Config::KEY.'_mutation_rejections_015',true,true);return ['complete'=>$complete,'changed'=>$changed];
        });
    }
    private static function reconcile(array $i): array {
        $old=Store::get('mutation',$i['operation_id']);if(!$old)throw new Fault('not_found','Operação ausente.');Access::owned($old['value']['principal']);
        return Store::lock('connection:'.$old['value']['connection_id'],static function()use($i){$r=Store::get('mutation',$i['operation_id']);$v=$r['value'];if($r['revision']!==$i['expected_operation_revision'])throw new Fault('revision_conflict','Releia a operação.');$c=Connections::get($v['connection_id']);self::access($c,$v['kind'],$v['input']);Credentials::requireScopes($c,self::scope($v['kind'],true));
            if(in_array($v['state'],['confirmed','rejected','rejected_before_dispatch','closed'],true))return self::projection($i['operation_id'],$r,true);
            $v['after']=self::verify($c,$v);$v['state']='confirmed';$v['remote_effect']='confirmed';$v['verified_at']=time();$v['last_code']=null;$r=Store::put('mutation',$i['operation_id'],$v,$r['revision']);self::event($i['operation_id'],$r);return self::projection($i['operation_id'],$r);
        });
    }
}
