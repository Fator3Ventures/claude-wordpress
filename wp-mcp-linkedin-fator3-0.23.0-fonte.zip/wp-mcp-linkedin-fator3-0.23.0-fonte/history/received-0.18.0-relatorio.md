# Entrega — Fator3 MCP LinkedIn 0.18.0

Revisão 1 · 05/11/2026, America/Sao_Paulo · Rodada de implementação e revisão. **Apta no escopo funcional testado**, com pendências de homologação visual e de fornecedor delimitadas na seção 6. Versão ativa no Site-Teste: **0.18.0**.

**Cópia anterior ao fechamento do fonte.** O relatório externo canônico se chama `wp-mcp-linkedin-fator3-0.18.0-relatorio.md`; os números finais do ZIP fonte são preenchidos somente nele.

## 1. De onde esta versão entra

Instalação limpa ou atualização direta da **0.17.1**. A base foi conferida pelo conteúdo: instalador de 379078 bytes, SHA-256 `e3a6c06d2c254a50af60e434a0575424e552ed4f62422ea1aabcff6bd591f1f9`; fonte de 2682300 bytes, SHA-256 `a7a96acae25a6d4003548677b5b14ff7c8769f216c4440178558cf948002c163`. Slug, basename, provider, menu, domínio de texto, SDKs e 99 operações públicas preservados.

Normas lidas: `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, ambos **revisão 5 de 02/11/2026**. Esta é uma nova rodada minor decorrente do pedido direto de análise, melhorias, testes, UI e documentação, sem novo número na aba central. Requisitos: **PHP 8.3+ e WordPress 7.1.4+**. Bancada: PHP 8.3.6, WordPress 7.1.4, MySQL 8.0.46. Nenhum runtime inferior foi usado como alvo.

## 2. Convivência e encaminhamentos

| Pacote | Referência / bancada | Site-Teste imediatamente antes e depois da troca LinkedIn |
|---|---|---|
| Site Core | 1.69.0, ativo | 1.69.0, ativo |
| Fator3 MCP | 0.38.0 no início; regressão repetida com instalador oficial 0.39.0 | 0.39.0, ativo |
| Google | 0.26.0 na bancada local | 0.27.0, ativo |
| Meta | 0.19.0, ativo | 0.19.0, ativo |
| Pipedrive | 0.5.0 extraído; não ativado localmente, exige PHP 8.3.36 | 0.5.0, ativo |

O ambiente compartilhado recebeu MCP 0.39.0 e Google 0.27.0 por outras rodadas. O inventário foi repetido antes da nossa troca. A execução só substituiu o LinkedIn. Há prova de convivência com o Google 0.27.0 no site, sem declaração de testes funcionais próprios de Google/Pipedrive. O ZIP MCP 0.39.0 usado na regressão final tem SHA-256 `158760eb738041848193611de4b07ea18d0dd4755f99f15e0735e28d90edae48`. Não há nova ordem de atualização entre provedores.

**Impacto desta rodada:** nenhum novo encaminhamento técnico. Foram avaliados o cliente Lead Sync, CAPI, o transporte MCP, a operação administrativa de configuração e os leitores de documentação. A restrição nova atinge uma entrada contraditória do próprio painel/API: substituir e apagar o mesmo segredo. Não foi identificada necessidade de adaptação de outro pacote. A busca por chamadas literais nos instaladores examinados é evidência auxiliar, não prova de inexistência de clientes dinâmicos.

**Acompanhamento anterior:** o relatório Core 1.69.0 informa atendimento técnico dos impactos LinkedIn 0.16.0/0.17.1 para lookup de campanha e adoção do recibo canônico. A inspeção do instalador Core confirmou as referências em `class-f3base-linkedin-campanhas.php`, `class-f3base-linkedin-cliente.php`, `class-f3base-linkedin-assinaturas.php` e `class-f3base-linkedin-descoberta.php`. O aceite em conta real permanece separado dessa evidência. Não foi alterado documento central ou runtime de outro pacote.

## 3. Mudanças e evidências

| Achado | Alteração | Evidência observável |
|---|---|---|
| A lista de conexões consultava novamente o registro cifrado e os vínculos para cada linha | `Connections::list` lê uma página por chave, com credencial, prova e candidata na mesma consulta. `Credentials::withRecords` aplica os mesmos critérios do leitor individual; a projeção pública remove segredos | Para 51 linhas, **256 SELECTs na base e 1 na nova versão**, contando apenas a tabela do plugin. Resultado público igual ao leitor individual; candidata expirada ou de outro usuário permanece oculta. A medição não é um benchmark do tempo total da página |
| Aquisição e gestão liam só a primeira página de conexões | Os seletores de aquisição, etapas comerciais e gestão compartilham a paginação e verificam se a continuação avança | Conexão na segunda página disponível nos seletores e no diário, sem duplicação |
| Credenciais, remoção e retenção ficavam misturadas no formulário; muitos cartões afastavam a edição | Identificação/acesso, credenciais, renovação, usuários, guarda e remoção receberam grupos próprios. Busca local por nome/ID, oito cartões por vez, foco no campo ao editar, rótulos e descrições acessíveis separados | Busca por acento/caixa/ID e estado vazio; nenhuma nova requisição para buscar; dias habilitados só no modo finito |
| Uma prévia atrasada podia habilitar a confirmação de uma política já editada | Invalidar a prévia por revisão de tela e conferir os campos antes de confirmar. Após confirmar, o botão permanece desabilitado até nova simulação | Resposta real da prévia de 20 dias foi deliberadamente atrasada durante a edição para 12. A primeira não habilitou a gravação; apenas 12 dias foram persistidos |
| Diagnóstico gravava a versão da API antes de mostrar o efeito nas concessões | Simular, revisar efeitos e confirmar a mesma conexão/revisão/versão; reconfirmações elegíveis podem ser selecionadas. Edição posterior invalida a prévia | Prévia não altera revisão; edição subsequente desabilita o botão; somente a última versão confirmada foi gravada |
| Informar um novo segredo e marcar sua remoção podia descartar o novo valor | Recusar a entrada contraditória para token, segredo do aplicativo e token de renovação | Três negativas `invalid_input`, sem chamada ao fornecedor ou alteração do registro |
| A ajuda decodificava todo o catálogo e recalculava hashes para ler um documento | O build gera índice de metadados e decodificador por ID permitido. O índice não carrega os corpos. A leitura individual verifica tamanho/hash e mantém paginação UTF-8 | Índice sem carregar o arquivo de conteúdo; guia recomposto em 14 páginas pequenas; todos os textos comparados com o ZIP na bancada |

O novo guia `PRIMEIROS-PASSOS.md` mostra como configurar, conceder, verificar e recuperar uma operação. O README passou a ser um índice por objetivo. Migração e recuperação foram alinhadas ao projeto; foram removidas orientações de retorno a versões antigas nos manuais correntes. Notas antigas de release continuam identificadas como histórico. Não há alteração na API do fornecedor, nos contratos de recebimento de leads ou na criação de assinaturas.

## 4. Instalação e prova da troca

| Cenário | Resultado |
|---|---|
| Instalação limpa, isolada | WP 7.1.4/PHP 8.3.6; 47 verificações funcionais dos pedidos anteriores e quatro do novo leitor documental, zero falhas |
| Atualização direta 0.17.1 → instalador final 0.18.0 | 14 verificações de configuração/preservação e quatro específicas de documentação, zero falhas; comparação de ciphertext, revisões e progresso antes de operar o alvo |
| Regressão integrada com MCP 0.39.0 | **443 verificações declaradas, zero falhas**; um cenário histórico específico de outra origem foi identificado como não aplicável em instalação limpa. Inclui negativas de autorização, stages, auditoria e executor MCP. Nenhum erro próprio ou de acompanhante nos logs finais |
| UI | **28 verificações novas + 54 anteriores**, zero falhas. HTML/JS do pacote, autenticação e REST reais em WordPress; DOM executado em jsdom 27.4.0 |
| Ajuda por MCP local | 42 documentos recompostos em 50 páginas, 64 verificações, zero falhas. Conteúdo, bytes, revisões e versões conferidos |
| Build | 36 arquivos PHP com lint aprovado; 85 arquivos no instalador, raiz correta, sem QA/dependências de desenvolvimento; build determinístico e árvore de runtime do fonte igual ao ZIP |

A UI e a matriz inicial usaram a candidata de SHA-256 `8420f78c212b5cb25f5e2049bd815d9d32bdfd6fa5a45e2d8ead3dce930b9df9`. Depois da mudança de inventário no site, a documentação de migração passou a remeter ao inventário do relatório. A comparação binária comprovou que mudaram somente esse Markdown, o catálogo/índice documental gerado e o manifesto. **Todo código funcional e todos os assets de UI testados são idênticos** aos do instalador final. Upgrade, documentação e regressão com o MCP vigente foram executados sobre o ZIP final. A bancada do transporte explicita a dependência de `mcp-stages012.php` dos dados criados por `stages012.php`; os resultados finais incluem a preparação correta.

**Site-Teste:** atualização direta de 0.17.1 via WP MCP fator3-teste, `plugins/upload-base64`, slug esperado `wp-mcp-linkedin-fator3`, SHA-256 esperado da seção 8 e chave idempotente. Uma troca, `applied:true`, operação `62ad7f181ee8e1088e65cd5094cfe126`, backup de arquivos `21f0d54d0fa46cbd3fb302da`. Sondas internas de `/` e `/wp-json/`: 200 antes e depois.

Verificação independente: LinkedIn **ativo em 0.18.0**; `linkedin/status` retornou `state:ok`, sem ocorrências, zero conexões e agendas ativas. `linkedin/selftest` aprovou nove itens locais. `list-connections` retornou a página vazia esperada e `get-retention` pôde ser lido sem escrita. O manifesto e o arquivo principal coincidiram com o ZIP. O índice do MCP 0.39.0 coincidiu nos **42 documentos**; sete deles, incluindo o schema longo, foram lidos integralmente em nove páginas e comparados byte a byte. Os cinco acompanhantes mantiveram versão, ativação e hash do arquivo principal durante a nossa troca. Não foram criadas fixtures no site compartilhado. A publicação raw e a distribuição de frota são do dono/frota; não houve push ou implantação em produção nesta rodada.

## 5. Banco, migração e correção

Schema físico 2 preservado. Nenhuma nova tabela, cron, concessão, efeito remoto ou migração reversa. A atualização não recria credenciais, agenda, seleção ou diário. A prova de migração operou a base e comparou registros cifrados, política de auditoria, concessão, operação incerta, coleta pausada e cursor de descoberta no alvo. O backup registrado na instalação cobre arquivos, não o banco. Conservar banco e salts para recuperação de dados; falha em versão instalada exige correção em nova versão. Antes de retomar uma escrita remota incerta, conferir seu recibo.

## 6. Pendências e limites

- **Inspeção visual em navegador gráfico:** o Chromium disponível não iniciou porque a criação do socket do processo foi recusada. A validação de UI cobre comportamento, DOM, rótulos, descrições e estados de controles. Não comprova a aparência renderizada em cada largura ou leitor de tela. Responsável pelo aceite visual: manutenção/dono no wp-admin autorizado.
- **Fornecedor real:** sem conexão LinkedIn no Site-Teste. Não houve nova homologação OAuth, webhook, Ads ou conversão real em ctooffice. Dono/frota mantêm os aceites que exigem aplicativo/conta autorizados.
- **Acompanhantes:** a convivência com Google 0.27.0 e Pipedrive 0.5.0 foi observada no site. Não foram testadas operações comerciais desses dois provedores. Logs, sondas e hashes de arquivos principais não constituem auditoria completa de seus runtimes.

## 7. Credenciais e configuração do dono

Nenhuma credencial adicional é exigida para atualizar. Para uso real, em Ferramentas → Fator3 MCP LinkedIn → Conexão, informar membro/aplicativo, Client ID, segredo e Access Token correspondentes, validade UTC e escopos necessários. Refresh Token é opcional quando permitido. Escolher ativos e concessões separadamente. Campos secretos vazios preservam o existente; para remoção, usar apenas o controle correspondente. Não há valores reais em relatório, testes ou evidências.

## 8. Identidade dos arquivos

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| `wp-mcp-linkedin-fator3-0.18.0-instalador.zip` | 379539 | `1e6c6e398ab2c507d827e428ae3b28099753459ef1b97a04ddf1c3922d819460` |
| `wp-mcp-linkedin-fator3-0.18.0-fonte.zip` | A preencher no relatório externo após empacotamento | A preencher no relatório externo após empacotamento |

Somente o instalador é instalável. Evidências atuais em `evidence/release0180/`, plano em `planning/release-0.18.0.md` e entradas em `inputs/0.18.0/`. O checklist de encerramento foi conferido: requisitos e identidade, migração, permissões, testes, documentação, conteúdo dos ZIPs e inventário final. Limites pendentes estão na seção 6.
