# Impacto de wp-mcp-linkedin-fator3 0.20.0 em wp-mcp-fator3

Revisão 2 · 2026-11-10T20:32-03:00 · Etapa: entrega · Situação: encerrado no emissor · Natureza: apresentação do contrato · Classificação: alerta-tecnico · Ticket: não atribuído.

**Decisão:** o LinkedIn acrescentou cinco projeções tipadas para que um agente consiga interpretar as respostas sem alterar o redator do MCP. O destinatário 0.43.0 permanece como distribuído. Não há pedido de implementação, ordem de troca entre plugins ou resposta pendente do mantenedor do MCP.

## Base, alvo e fronteira

Base: LinkedIn 0.19.0, SHA-256 `613cb47cfb3be2b91dfa1f20f39c465780a6fffb5432b645290448fe592a0f0c`. Alvo emitido: `wp-mcp-linkedin-fator3-0.20.0-instalador.zip`, 429846 bytes, SHA-256 `4b3f7321b81a28bbed6595d6922ec7d388685690d58d278f3f4b3ebc592ee743`. Destinatário ensaiado: instalador oficial do MCP 0.43.0, SHA-256 `c0f3a10ad4275dc51abd4ab01ac9d2647914fb13d214b9e4f460cd989ddf4951`.

A revisão 1 observou quatro escalares ocultos; levantou sete hipóteses adicionais. A inspeção e a execução de `SafeOutput::value` (includes/Release014.php), em conjunto com includes/DataSafety.php, confirmaram o quinto caso. As chaves legadas e os controles de acesso continuam no SDK/REST. O texto de uma falha ou o valor de uma credencial não são fontes válidas para projeção sob nome neutro.

| Operação e campo histórico (redigido pelo transporte) | Acesso público correspondente | Contrato |
|---|---|---|
| configuration-schema: credential_input | input_method | enum fixo: manual_token |
| configuration-schema: empty_secret_keeps_existing | blank_keeps_existing | booleano verdadeiro |
| status: maintenance.last.credentials_code | maintenance.last.renewal_result | enum restrito; sem execução pode não existir; código desconhecido vira other_failure |
| capabilities: local_sdk.features.dispatch_authorization | local_sdk.features.dispatch_checks_access | booleano |
| get-connection / status: credential_notice_days | connection.notice_days / access_lifecycle.connections[].notice_days | inteiro, 1–365 dias |

Passaram sem mudança na execução do componente: authorization_revision, credential_generation e credential_revision como inteiros; refresh_configured, secret_configured e token_configured como booleanos. Três controles continuaram redigidos: token opaco no campo próprio, segredo numérico no campo próprio e valor do tipo Bearer sob uma chave neutra. Não se adotou uma regra global para liberar valores curtos.

## Prova, reprodução e limite

Em WordPress isolado, instale o conjunto vigente e execute `server020.php` em banco exclusivo. A suíte atravessa o endpoint JSON-RPC do MCP, com autenticação de bancada, para configuration-schema, status, capabilities e get-connection; confere tipos, aviso do registro legado e equivalência das representações estruturada/textual. O destinatário é o original, sem patch: as chaves antigas continuam filtradas e as novas chegam legíveis. Renomear blank_keeps_existing para um nome filtrado reprova exclusivamente o controle específico no teste de transporte. A fixture usa credenciais sintéticas; não homologa uma conta do LinkedIn.

Implementação do emissor: Api::dispatch/descrição da configuração, Connections (projeção pública), Worker (resultado limitado), Credentials (prazo) e LeadReader (descritor). Consulte CONTRACTS.md e AGENTS.md instalados, o teste no fonte e a evidência no relatório da release. Na instalação compartilhada, a ausência de uma conexão não autoriza criar fixture para expor o prazo; o caso com dados foi provado na bancada.

## Confirmação no Site-Teste

Após a troca única para 0.20.0, o próprio conector retornou input_method=manual_token, blank_keeps_existing=true, renewal_result=ok e dispatch_checks_access=true. O inventário não tem conexões LinkedIn; o quinto campo fica comprovado pela conexão sintética no transporte integral de bancada.

## Evolução

Revisão 1: planejamento, alerta aberto e quatro campos observados; hipóteses ainda sem ensaio no destinatário. Revisão 2: implementação e entrega; diagnóstico confirmado e aceite atendido pelo próprio emissor. A cópia imutável da revisão 1 e o parecer estão no fonte. Sem alteração em código ou documentação do Core ou do MCP.
