# Fonte — Fator3 MCP LinkedIn 0.23.0

O Pedido 25 separa a autorização de consumidores do transporte MCP usado para cadastrá-los. A validação continua vinculada ao administrador original e aos recursos selecionados. O manual instalado está em `plugin/wp-mcp-linkedin-fator3/docs/CONCESSOES.md`. A decisão, os limites e o resultado no Site-Teste estão no relatório da raiz. Os fontes editáveis ficam em `build/common`, `build/linkedin`, `build/assets`, `build/manuals` e `build/docs/linkedin`; `plugin/wp-mcp-linkedin-fator3` reproduz os arquivos instalados.

## Reproduzir o pacote e as provas

1. Use PHP 8.3 de 64 bits, WordPress 7.1.4, MySQL 8 e cliente mysql. Para reproduzir as provas desta versão, informe os caminhos locais de cada dependência em uma cópia de `tools/lab-release0230.example.json`; confira os hashes. Use banco e usuários descartáveis, sem conexões reais. O runner cria e remove o banco de cada execução. O diretório de trabalho de cada teste deve ser novo.
2. A partir desta raiz, gere o ZIP e verifique a identidade da árvore:

```sh
F3_SOCIAL_PHP=/caminho/php8.3 python3 build/build.py
python3 tools/verify-installer023.py build/dist/wp-mcp-linkedin-fator3-0.23.0-instalador.zip plugin/wp-mcp-linkedin-fator3
```

3. Execute as suítes no WordPress nativo. Exemplo com um manifesto local que já passou pela verificação de hashes:

```sh
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li23-rotacao --order linkedin-integrated --tests rotation023.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li23-conversoes --order linkedin-integrated --tests conversions023.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li23-migracao --origin upgrade --order linkedin-integrated --tests migration023.php
```

Para os outros grupos, use `ad-source022.php`, `suite.php` (modo integrado e `linkedin-only`) e `mcp-docs080.php` (instalação nova e `--origin upgrade`). O controle negativo usa `rotation023.php --candidate /dependencias/wp-mcp-linkedin-fator3-0.22.0-instalador.zip`: quatro leituras e três diagnósticos devem falhar na base. Não use este controle no site compartilhado. As chamadas de fornecedor são simuladas; toda a implementação WordPress, MCP e Core exercitada é a dos pacotes identificados no manifesto.

4. Em `evidence/release0230`, consulte a matriz, as verificações por suíte, o inventário e os hashes dos documentos lidos no Site-Teste. A edição do relatório dentro do fonte precede seu fechamento; tamanho e SHA-256 finais estão no relatório externo. Arquivos de versões anteriores são históricos.
