"""Render the shipped WordPress settings in Chrome, exclusively against disposable localhost."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
from urllib.parse import quote, urlsplit

from playwright.sync_api import sync_playwright, expect

origin = os.environ['F3_UI_URL']
address = urlsplit(origin)
if address.scheme != 'http' or address.hostname != '127.0.0.1' or not address.port:
    raise ValueError('Only the owned IPv4 loopback fixture is allowed')
lab = Path(os.environ['F3_LAB_ROOT'])
out = lab / 'evidence' / 'browser-layout'
out.mkdir(exist_ok=True)
shell = Path(os.environ['F3_CHROME_HEADLESS_SHELL']).resolve(strict=True)
checks, errors, pictures = [], [], []
sizes = {'desktop': (1440, 900), 'mobile': (390, 844)}


def check(title, value, details=None):
    entry = {'name': title, 'passed': bool(value)}
    if details is not None:
        entry['detail'] = details
    checks.append(entry)
    return entry['passed']


def layout(page, tab, width, size):
    # Check actual CSS pixels and each visible, interactive control relative to the viewport.
    data = page.evaluate('''tab => {
      const root=document.querySelector('#f3-'+tab); if(!root) throw Error('Unknown panel: '+tab);
      const w=document.documentElement.clientWidth;
      const outside=[...root.querySelectorAll('input, select, button, textarea, summary')].filter(el=>{
        const rect=el.getBoundingClientRect(); if(!rect.width||!rect.height) return false;
        return rect.right>w+1 || rect.left < -1;
      }).map(el=>el.id||el.name||el.tagName);
      return {viewport:w,document_width:document.documentElement.scrollWidth,
        panel_left:Math.round(root.getBoundingClientRect().left),panel_right:Math.round(root.getBoundingClientRect().right),
        outside};
    }''', tab)
    check(f'{size}: {tab} fits without horizontal page scroll', data['document_width'] <= data['viewport'] + 1, data)
    check(f'{size}: {tab} interactive controls remain horizontally visible', not data['outside'], data['outside'])


def capture(page, size, tab, anchor):
    page.locator(anchor).evaluate('el=>{el.scrollIntoView({block:"start"});scrollBy(0,-65)}')
    name = f'{size}-{tab}.png'
    page.screenshot(path=out/name, animations='disabled', caret='hide')
    pictures.append({'file': name, 'sha256': hashlib.sha256((out/name).read_bytes()).hexdigest()})


def open_tab(page, tab):
    page.locator(f'.f3-tabs [data-tab="{tab}"]').click()
    expect(page.locator('#f3-'+tab)).to_be_visible()
    expect(page.locator(f'.f3-tabs [data-tab="{tab}"]')).to_have_attribute('aria-current','page')
    page.wait_for_load_state('networkidle')


def exercise(context, size, width, height):
    page = context.new_page()
    page.on('pageerror', lambda error: errors.append(str(error)[:180]))
    # Authenticate directly into the scope under test; do not render unrelated dashboard widgets.
    target=origin+'/wp-admin/tools.php?page=wp-mcp-linkedin-fator3&tab=connections'
    page.goto(origin+'/wp-login.php?redirect_to='+quote(target,safe=''))
    page.locator('#user_login').fill('social_admin')
    page.locator('#user_pass').fill(os.environ['F3_UI_PASSWORD'])
    page.locator('#wp-submit').click()
    page.wait_for_url(target,timeout=60000)
    expect(page.locator('#f3-connection-count')).to_contain_text('de 56 conexões')
    expect(page.locator('#f3-user-options input').first).to_be_attached()
    check(f'{size}: installed version shown', page.locator('.f3-badge').inner_text().endswith(os.environ['F3_LAB_VERSION']))
    search = page.get_by_role('searchbox',name='Buscar conexão por nome ou identificador')
    search.fill('conexao de demonstracao')
    expect(page.locator('#f3-connection-list .f3-card')).to_have_count(1)
    page.get_by_role('button',name='Editar conexão').click()
    label=page.locator('#f3-connection input[name=label]')
    expect(label).to_be_focused();expect(label).to_have_value('Conexão de demonstração')
    check(f'{size}: filtered card opens the correct connection and focuses its name', True)
    token = page.locator('#f3-connection input[name=token]')
    expect(token).to_have_value('')
    check(f'{size}: access token is masked and has a distinct accessible description',
          token.get_attribute('type')=='password' and token.evaluate('e=>!!document.getElementById(e.getAttribute("aria-describedby"))'))
    geometry=page.locator('#f3-connection [name=enabled]').evaluate("""el=>{
      const group=el.parentElement.getBoundingClientRect(),name=document.getElementById(el.getAttribute('aria-labelledby')).getBoundingClientRect(),
        help=document.getElementById(el.getAttribute('aria-describedby')).getBoundingClientRect();
      const maxWidth=parseFloat(getComputedStyle(document.getElementById(el.getAttribute('aria-describedby'))).maxWidth);
      return {label_width:Math.round(name.width),description_width:Math.round(help.width),group_width:Math.round(group.width),
        available_width:Math.round(Math.min(group.width,Number.isFinite(maxWidth)?maxWidth:group.width)),
        description_below_label_px:Math.round(help.top-name.bottom),left_indent_px:Math.round(help.left-group.left)};
    }""")
    check(f'{size}: checkbox description is below its label and uses available width up to its reading limit',
          geometry['description_below_label_px']>=0 and abs(geometry['left_indent_px'])<=1
          and geometry['description_width']>=geometry['available_width']*.95,geometry)
    layout(page, 'connections', width, size)
    capture(page,size,'connections','#f3-connection')
    disclosure=page.locator('#f3-connection .f3-sensitive > summary')
    check(f'{size}: remove credentials controls are collapsed by default',
          not disclosure.locator('..').evaluate('e=>e.open'))
    disclosure.focus();disclosure.press('Enter')
    expect(page.locator('#f3-connection [name=clear_token]')).to_be_visible()
    check(f'{size}: keyboard can expand removal options without changing them',
          not page.locator('#f3-connection [name=clear_token]').is_checked())
    disclosure.press('Enter')
    open_tab(page,'management')
    check(f'{size}: commercial execution remains disabled without reviewed preview',
          page.locator('#f3-management-execute').is_disabled())
    layout(page,'management', width, size)
    capture(page,size,'management','#f3-management')
    open_tab(page,'diagnostics')
    page.locator('#f3-selftest').click()
    expect(page.locator('#f3-diagnostic-result')).to_contain_text('Autoteste local aprovado',timeout=30000)
    check(f'{size}: local selftest separates supplier validation and report filters',
          not page.locator('#f3-context').is_visible() and page.locator('#f3-diagnostic-remote').inner_text()=='')
    layout(page,'diagnostics',width,size)
    capture(page,size,'diagnostics','#f3-diagnostics')
    for tab in ('leads','retention','help'):
        open_tab(page,tab);layout(page,tab,width,size)
    check(f'{size}: no unhandled script errors in the audited screens', not errors)
    page.close()


results = {'engine': 'Google Chrome Headless Shell', 'sandbox_enabled': True,
           'fixture': 'real WordPress wp-admin, shipped scripts/CSS, synthetic administrator; loopback only',
           'browser_sha256': hashlib.sha256(shell.read_bytes()).hexdigest(),
           'playwright': importlib.metadata.version('playwright'),'viewports':sizes}
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(shell), chromium_sandbox=True, timeout=30000)
        results['version'] = browser.version
        for size,(width,height) in sizes.items():
            ctx=browser.new_context(viewport={'width':width,'height':height},service_workers='block',
                                    device_scale_factor=1,locale='pt-BR')
            try:
                def route(r):
                    u=urlsplit(r.request.url)
                    if u.scheme==address.scheme and u.netloc==address.netloc:
                        r.continue_()
                    else:
                        r.abort()
                ctx.route('**/*',route)
                exercise(ctx,size,width,height)
            finally:
                ctx.close()
        browser.close()
except Exception as error:
    check('Browser exercise completed',False, str(error)[:360])
finally:
    results.update(checks=checks, screenshots=pictures, script_errors=errors, total=len(checks),
                   failed=sum(not c['passed'] for c in checks))
    (out/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'browser':results.get('version'),'checks':len(checks),'failed':results['failed'],
                  'failed_checks':[c['name'] for c in checks if not c['passed']]}))
raise SystemExit(1 if results['failed'] else 0)
