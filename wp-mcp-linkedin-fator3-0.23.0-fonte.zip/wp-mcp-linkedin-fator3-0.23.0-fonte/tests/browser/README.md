# Validação visual do painel em navegador

`tests/native/webui019.php` abre um WordPress descartável em loopback, cria somente uma identidade administrativa sintética e executa o painel publicado no Chrome Headless Shell. Usa o transporte REST real, o CSS do wp-admin e o CSS e JavaScript do instalador. As chamadas HTTP do WordPress ficam nas fixtures de laboratório, e o navegador aceita somente a origem local da bancada. Não se conecta ao LinkedIn nem executa criação ou exclusão de anúncios.

**Requisitos de desenvolvimento:** Python com Playwright 1.62.0 e Chrome Headless Shell 152.0.7940.0 (Linux x86-64, pacote Chrome for Testing). A cópia usada nesta prova tinha SHA-256 `eea6a8f2cd69a00ed863b71ce12177f0da0069ad29e64cb4331b6bcee1e80e3f` no ZIP e `87899b7da5bd361f443412c560296272c461ebdff35302d5b21232470c973d55` no executável. O navegador é externo ao instalador e ao ZIP fonte. O teste usa o sandbox nativo do navegador e executa um servidor apenas em `127.0.0.1`.

```bash
export F3_CHROME_HEADLESS_SHELL=/dependencias/chrome-headless-shell-linux64/chrome-headless-shell
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li019-visual --order linkedin-integrated --tests webui019.php
```

Cada tamanho usa perfil novo e login real no wp-admin sintético. A aplicação procura e edita uma conexão, verifica o foco, expande/recolhe o grupo de remoção pelo teclado e confirma que nenhuma remoção ou execução comercial foi selecionada. A prova verifica o espaço do rótulo e da descrição, a largura do documento e os limites dos controles visíveis em seis abas (Conexão, Anúncios e publicações, Diagnóstico, Formulários e concessões, Retenção e Ajuda). Mede em **1440×900 e 390×844 pixels CSS**, escala 1. `evidence/browser-layout/results.json` registra versão do navegador, verificações, medidas e hashes. As medidas usam pixels CSS: a descrição deve começar abaixo do rótulo e ocupar a largura disponível até o limite de legibilidade de 70ch. Os hashes identificam as imagens daquela execução; a validade sintética mostrada no painel varia com o relógio, portanto não se compara o bitmap de duas execuções byte a byte. Seis PNGs dos painéis Conexão, Diagnóstico e Anúncios/publicações são gerados no diretório da bancada para inspeção interna.

O teste comprova renderização e interação nas duas larguras, usando o Chromium headless. Não representa Safari, Firefox, leitor de tela, dispositivo móvel físico, todas as abas/estados possíveis ou uma auditoria integral de acessibilidade. As imagens registram dados de demonstração e não substituem as verificações de estado no DOM.
