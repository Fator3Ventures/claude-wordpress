"""Render the shipped WordPress settings in Chrome, exclusively against disposable localhost."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from playwright.sync_api import sync_playwright, expect

origin = os.environ['F3_UI_URL']
address = urlsplit(origin)
if address.scheme != 'http' or address.hostname != '127.0.0.1' or not address.port:
    raise ValueError('Only the owned IPv4 loopback fixture is allowed')
lab = Path(os.environ['F3_LAB_ROOT'])
out = lab / 'evidence' / 'browser-layout020'
out.mkdir(exist_ok=True)
shell = Path(os.environ['F3_CHROME_HEADLESS_SHELL']).resolve(strict=True)
checks, errors, pictures = [], [], []
# An optional explicitly requested sandbox exception applies only to this disposable,
# loopback-only synthetic browser harness (never to the shipped plugin).
sandbox = os.environ.get('F3_LAB_CHROME_NO_SANDBOX')!='1'
sizes = {'desktop': (1440, 900), 'mobile': (390, 844)}


def check(title, value, details=None):
    entry = {'name': title, 'passed': bool(value)}
    if details is not None:
        entry['detail'] = details
    checks.append(entry)
    return entry['passed']


def layout(page, tab, width, size):
    # Check actual CSS pixels and each visible, interactive control relative to the viewport.
    data = page.evaluate('''tab => {
      const root=document.querySelector('#f3-'+tab); if(!root) throw Error('Unknown panel: '+tab);
      const w=document.documentElement.clientWidth;
      const outside=[...root.querySelectorAll('input, select, button, textarea, summary')].filter(el=>{
        const rect=el.getBoundingClientRect(); if(!rect.width||!rect.height) return false;
        return rect.right>w+1 || rect.left < -1;
      }).map(el=>el.id||el.name||el.tagName);
      return {viewport:w,document_width:document.documentElement.scrollWidth,
        panel_left:Math.round(root.getBoundingClientRect().left),panel_right:Math.round(root.getBoundingClientRect().right),
        outside};
    }''', tab)
    check(f'{size}: {tab} fits without horizontal page scroll', data['document_width'] <= data['viewport'] + 1, data)
    check(f'{size}: {tab} interactive controls remain horizontally visible', not data['outside'], data['outside'])


def controls(page, size, scope):
    metrics=page.locator(scope).evaluate('''root=>{
      const visible=e=>!!(e&&e.checkVisibility()&&e.getClientRects().length);
      const rect=e=>e.getBoundingClientRect(), gap=(a,b)=>Math.max(b.left-a.right,a.left-b.right,b.top-a.bottom,a.top-b.bottom);
      const buttons=[...root.querySelectorAll('button.button')].filter(visible), touching=[],labels=[];
      for(const a of buttons){
        let b=a.nextElementSibling;while(b&&!visible(b))b=b.nextElementSibling;
        if(b?.matches('button.button') && gap(rect(a),rect(b))<.5)touching.push(a.id+':'+b.id);
      }
      for(const label of root.querySelectorAll('label')){
        const e=label.querySelector('input:not([type=hidden]),select,textarea');if(!visible(e))continue;
        const name=[...label.childNodes].find(n=>(n.nodeType===Node.TEXT_NODE||n.nodeName==='SPAN')&&n.textContent.trim());
        if(!name)continue;
        const range=document.createRange();range.selectNodeContents(name);
        if([...range.getClientRects()].filter(r=>r.width&&r.height).some(r=>gap(r,rect(e))<.5))labels.push(e.id||e.name);
      }
      const fonts=[...root.querySelectorAll('.f3-field-help,.f3-field-doc summary')].filter(visible).map(e=>parseFloat(getComputedStyle(e).fontSize));
      return {touching,labels,help_min:fonts.length?Math.min(...fonts):null};
    }''')
    check(f'{size}: {scope} action and label spacing',not metrics['touching'] and not metrics['labels'],metrics)
    check(f'{size}: {scope} help text readable',metrics['help_min'] is None or metrics['help_min']>=12,metrics['help_min'])

def capture(page, size, tab, anchor):
    page.locator(anchor).evaluate('el=>{el.scrollIntoView({block:"start"});scrollBy(0,-65)}')
    name = f'{size}-{tab}.png'
    page.screenshot(path=out/name, animations='disabled', caret='hide')
    pictures.append({'file': name, 'sha256': hashlib.sha256((out/name).read_bytes()).hexdigest()})


def run_checks(page,size,width):
    target=origin+'/wp-admin/tools.php?page=wp-mcp-linkedin-fator3&tab='
    groups={'connections':'connections','assets':'connections','leads':'leads','conversions':'leads','stages':'leads',
            'reports':'reports','jobs':'reports','history':'reports','management':'management',
            'diagnostics':'diagnostics','retention':'diagnostics','help':'help'}
    def ok(name,value,detail=None):
        return check(f'{size}: {name}',value,detail)
    def by(selector):
        return page.locator(selector)
    def run(label,fn):
        try: fn()
        except Exception as exc: ok(label,False,str(exc)[:500])
    def goto(panel,suffix=''):
        page.goto(target+panel+suffix);page.wait_for_load_state('networkidle');page.evaluate('scrollTo(0,0)')
    requests=[]
    def track(r):
        u=urlsplit(r.url);route=parse_qs(u.query).get('rest_route',[u.path])[0]
        if '/f3-linkedin/v1/' in route:
            op=route.split('/')[-1]
            if op=='admin-options':op+=':'+str((r.post_data_json or {}).get('kind',''))
            requests.append(op)
    page.on('request',track)
    def panel_contract(panel):
        requests.clear()
        goto(panel);expect(by('#f3-'+panel)).to_be_visible()
        current=by('.f3-tabs a[aria-current="page"]')
        ok(panel+' selects its group',current.count()==1 and current.get_attribute('data-group')==groups[panel])
        layout(page,panel,width,size)
        controls(page,size,'#f3-'+panel)
        if panel in ('connections','assets','diagnostics','help'):
            allowed={'connections':set(),'assets':{'admin-options:selected'},'diagnostics':set(),'help':{'documentation'}}
            ok(panel+' only loads its own data',set(requests)<=allowed[panel],sorted(set(requests)))
        m=page.evaluate("""() => {
          const els=Array.from(document.querySelectorAll('.f3-social input[type=checkbox]')).map(n=>n.getBoundingClientRect()).filter(r=>r.width&&r.height);
          const nav=document.querySelector('.f3-tabs');
          return {count:els.length,square:els.every(r=>Math.abs(r.width-r.height)<1),height:nav.getBoundingClientRect().height,
                  topics:nav.children.length,rows:new Set([...nav.children].map(a=>Math.round(a.getBoundingClientRect().top))).size};
        }""")
        ok(panel+' checkbox geometry',m['square'],m)
        ok(panel+' six sections on one line',m['topics']==6 and m['rows']==1 and (size!='mobile' or m['height']<=48),m)
        if panel=='jobs':
            pos=by('#f3-schedule [name=label]').evaluate('e=>e.getBoundingClientRect().top+scrollY')
            ok('collection field within first viewport budget',pos<=(420 if size=='desktop' else 520),pos)
            ok('schedule label preserved',by('#f3-schedule input[name=label]').evaluate("e=>document.getElementById(e.getAttribute('aria-labelledby')).textContent")=='Nome da agenda')
        if panel=='reports':
            if size=='mobile':by('#f3-context summary').click()
            asset=by('#f3-context select[name=account_id]')
            def name():return asset.evaluate("e=>document.getElementById(e.getAttribute('aria-labelledby')).textContent")
            by('#f3-context [name=channel]').select_option('pages');ok('Page label matches selection',name()=='Página autorizada')
            by('#f3-context [name=channel]').select_option('ads');ok('Ads label matches selection',name()=='Conta de anúncios autorizada')
            ok('numeric page size is bounded',by('#f3-query [name=limit]').evaluate('e=>Math.abs(e.getBoundingClientRect().width - parseFloat(getComputedStyle(e).width))<1 && e.offsetWidth < 150'))
        if panel in ('jobs','connections'): capture(page,size,panel,'.f3-heading')
        if panel=='leads':
            perm=by('#f3-grant [name=permission][value=ad_source]')
            ok('source permission explicitly opt-in for ads accounts',perm.count()==1 and perm.is_visible() and not perm.is_checked() and 'qualquer anúncio' in perm.locator('xpath=..').inner_text())
            ok('empty local grant list named correctly',by('#f3-grants').inner_text().strip()=='Nenhuma concessão de formulários cadastrada neste site.')
            ok('grant label preserved',by('#f3-grant input[name=enabled]').evaluate("e=>document.getElementById(e.getAttribute('aria-labelledby')).textContent")=='Concessão ativa')
        if panel=='help':
            expect(by('#f3-help-document')).to_have_value('PRIMEIROS-PASSOS.md')
            ok('document groups',by('#f3-help-document optgroup').evaluate_all('xs=>xs.map(x=>x.label)')==['Manuais','Schemas','Histórico'])
            by('#f3-help-read').click();expect(by('#f3-help-content h2').first).to_be_visible()
            ok('help renders as document',by('#f3-help-content h2,#f3-help-content h3').count()>1 and len(by('#f3-help-description').inner_text())>0)
    for panel in groups:run('panel '+panel,lambda panel=panel: panel_contract(panel))
    def legacy():
        goto('assets','#f3-conversions');expect(by('#f3-conversions')).to_be_visible()
        goto('assets','#f3-stage-conversions');expect(by('#f3-stage-conversions')).to_be_visible()
        ok('legacy conversion fragments reach the right panel',True)
    run('legacy fragments',legacy)
    def directory():
        goto('connections')
        expect(by('#f3-connection-list tbody tr')).to_have_count(20)
        by('#f3-connections-more').click();by('#f3-connections-more').click()
        expect(by('#f3-connection-count')).to_contain_text('41–56')
        by('#f3-connection-list tbody tr').nth(10).get_by_role('button').click()
        expect(by('#f3-connection [name=connection_id]')).to_have_value('z018-50')
        expect(by('#f3-connection input[name=label]')).to_be_focused()
        ok('missing identity names its actual next control','Verificar permissões' in by('#f3-saved-identity').inner_text() and by('#f3-token-inspect').text_content()=='Verificar permissões')
        ok('51st connection opens by stable URL','connection=z018-50' in page.url)
        by('#f3-back-connections').click();expect(by('#f3-connection-count')).to_contain_text('41–56')
        by('#f3-connection-search').fill('z018-55');expect(by('#f3-connection-list tbody tr')).to_have_count(1)
        by('#f3-connection-list button').click();expect(by('#f3-connection [name=connection_id]')).to_have_value('z018-55')
        ok('global search includes later records',True)
    run('directory navigation',directory)
    def edit():
        goto('connections','&connection=ui')
        form=by('#f3-connection');expect(form).to_be_visible()
        pos=form.evaluate('e=>e.getBoundingClientRect().top+scrollY')
        if size=='desktop':ok('editor starts above 320px',pos<=320,pos)
        controls(page,size,'#f3-connection')
        ok('six or fewer permanent explanations',form.locator('.f3-field-help:visible').count()<=6,form.locator('.f3-field-help:visible').count())
        ok('retention days preserve their local label',form.locator('[name=retention_days]').evaluate("e=>document.getElementById(e.getAttribute('aria-labelledby')).textContent")=='Dias de guarda')
        ok('editor checkbox preserves its name',form.locator('[name=enabled]').evaluate("e=>document.getElementById(e.getAttribute('aria-labelledby')).textContent")=='Conexão ativa')
        ok('copyable callback before submit',form.evaluate("f=>Boolean(f.querySelector('#f3-oauth-return').compareDocumentPosition(f.querySelector('button[type=submit],.f3-form-footer button')) & Node.DOCUMENT_POSITION_FOLLOWING)"))
        summary=form.locator('details summary').filter(has_text='Renovação e aviso').first
        summary.focus();summary.press('Enter');expect(form.locator('[name=credential_notice_days]')).to_be_visible()
        ok('keyboard opens the renewal panel',True)
        ok('keyboard focus indicator is visible',summary.evaluate("e=>e.matches(':focus-visible')&&getComputedStyle(e).outlineStyle!=='none'"))
        days=form.locator('[name=credential_notice_days]');original=int(days.input_value());days.fill(str(original+1))
        before=form.locator('[name=expected_revision]').input_value()
        save=form.locator('.f3-form-footer button');save.click()
        expect(by('#f3-message')).to_have_attribute('role','alert')
        expect(by('#f3-message')).to_contain_text('simulation_required')
        expect(save).to_be_focused()
        ok('save error visible and next to trigger',by('#f3-message').evaluate('e=>{const r=e.getBoundingClientRect();return r.top>=0&&r.bottom<=innerHeight}') and 'simulation_required' in save.locator('xpath=following-sibling::*[1]').inner_text())
        preview=by('#f3-identity-preview');confirm=by('#f3-identity-confirm')
        preview.click();expect(confirm).to_be_enabled()
        ok('dependency controls hidden without grants',not form.locator('[name=reconfirm_leads]').is_visible() and not form.locator('[name=reconfirm_conversions]').is_visible())
        days.fill(str(original+2));expect(confirm).to_be_disabled()
        ok('edited draft invalidates confirmation',True)
        preview.click();expect(confirm).to_be_enabled();confirm.click()
        expect(by('#f3-message')).to_contain_text('Conexão salva.',timeout=12000)
        ok('save without related schedules/grants succeeds',int(form.locator('[name=expected_revision]').input_value())>int(before))
        expect(preview).to_be_focused()
        ok('consumed confirmation moves focus to its continuation',confirm.is_disabled() and preview.evaluate("e=>document.activeElement===e"))
        # Deliberately reorder two UI responses without bypassing backend validation.
        page.evaluate("""() => { window.testRelease=null;const original=window.fetch;window.fetch=async (...args)=>{
           const r=await original(...args);if(String(args[0]).includes('/save-connection')&&window.testHold){
             window.testHold=false;await new Promise(resolve=>{window.testRelease=resolve;});}return r;};window.testHold=true;}""")
        days.fill(str(original+3));save.click()
        page.wait_for_function('typeof window.testRelease==="function"')
        preview.click();expect(confirm).to_be_enabled();preview.focus();page.evaluate('window.testRelease()')
        expect(save.locator('xpath=following-sibling::*[1]')).to_contain_text('simulation_required')
        expect(preview).to_be_focused()
        ok('late error stays with origin without stealing focus',by('#f3-message').get_attribute('role')!='alert' or 'simulation_required' not in by('#f3-message').inner_text())
    run('connection preview and feedback',edit)
    def security():
        # Controlled document source using the real renderer and its signed metadata contract.
        goto('help')
        manual="""# Teste

**Forte** *ênfase* e `<img>` [seguro](https://example.org/) [texto](javascript:alert) [outro](data:text/plain,x) <img src=x onerror=window.bad=1>

| A | B |
| --- | --- |
| 1 | 2 |

[malformado]("""
        raw=manual.encode();revision=hashlib.sha256(raw).hexdigest()
        def fixture(route):
            i=route.request.post_data_json;assert i['document'] in ('index','PRIMEIROS-PASSOS.md')
            if i['document']=='index':
                data={'documents':[{'document':'PRIMEIROS-PASSOS.md','title':'Teste','description':'Documento sintético','kind':'manual','sha256':revision,'bytes':len(raw)}]}
            else:
                assert i['expected_revision']==revision
                at=i['offset'];end=raw.index(b'| A |') if at==0 else len(raw)
                data={'revision':revision,'content':raw[at:end].decode(),'offset':at,'next_offset':end if end<len(raw) else None}
            route.fulfill(json={'success':True,'data':data})
        page.route('**/*documentation*',fixture)
        try:
            goto('help');by('#f3-help-read').click()
            doc=by('#f3-help-content');expect(doc.locator('table')).to_be_visible()
            ok('restricted Markdown treats HTML and unsafe links as data',doc.locator('img,script').count()==0 and '<img src=x' in doc.inner_text() and doc.locator('a').count()==1 and doc.locator('a').get_attribute('href')=='https://example.org/' and doc.locator('strong, em, table, code').count()==4 and page.evaluate('window.bad===undefined'))
        finally:page.unroute('**/*documentation*',fixture)
    run('reader untrusted multipart document',security)
    if size=='desktop':
        def zoom():
            # CSS zoom enlarges text and controls together inside the real WP viewport.
            goto('jobs');page.locator('html').evaluate("e=>e.style.zoom='200%'")
            field=by('#f3-schedule input[name=label]');field.focus();field.press('Tab')
            ok('200% layout zoom preserves keyboard access',by('#f3-schedule input[name=interval_minutes]').evaluate("e=>document.activeElement===e&&e.matches(':focus-visible')") and page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'),page.evaluate('({vw:innerWidth,scroll:document.documentElement.scrollWidth})'))
            page.locator('html').evaluate("e=>e.style.zoom=''")
        run('zoom and keyboard',zoom)
    ok('no unhandled JavaScript errors',not errors,errors)

def exercise(context,size,width,height):
    page=context.new_page();page.set_default_timeout(15000);page.set_default_navigation_timeout(30000)
    expect.set_options(timeout=15000)
    page.on('pageerror',lambda err:errors.append(str(err)[:160]))
    page.on('dialog',lambda dialog:dialog.accept())
    target=origin+'/wp-admin/tools.php?page=wp-mcp-linkedin-fator3&tab=connections'
    # This test exercises wp-admin, not the login form. Authenticate against the exact
    # loopback origin rather than following an ambient login action or an external redirect.
    login=origin+'/wp-login.php';context.request.get(login,max_redirects=0)
    response=context.request.post(login,form={'log':'social_admin','pwd':os.environ['F3_UI_PASSWORD'],
                                  'testcookie':'1','redirect_to':target},max_redirects=0)
    if response.status not in (302,303) or not any(c['name'].startswith('wordpress_logged_in_') for c in context.cookies()):
        raise RuntimeError('WordPress login failed: HTTP '+str(response.status)+', redirect path '+urlsplit(response.headers.get('location','')).path)
    page.goto(target)
    if not page.locator('.f3-social').count():
        raise RuntimeError('Settings shell unavailable after login; path '+urlsplit(page.url).path)
    run_checks(page,size,width);page.close()

results = {'engine': 'Google Chrome Headless Shell', 'sandbox_enabled': sandbox,
           'fixture': 'real WordPress wp-admin, shipped scripts/CSS, synthetic administrator; loopback only',
           'browser_sha256': hashlib.sha256(shell.read_bytes()).hexdigest(),
           'playwright': importlib.metadata.version('playwright'),'viewports':sizes}
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=str(shell), chromium_sandbox=sandbox, timeout=30000)
        results['version'] = browser.version
        for size,(width,height) in sizes.items():
            ctx=browser.new_context(viewport={'width':width,'height':height},service_workers='block',
                                    device_scale_factor=1,locale='pt-BR')
            try:
                def route(r):
                    u=urlsplit(r.request.url)
                    if u.scheme==address.scheme and u.netloc==address.netloc:
                        r.continue_()
                    else:
                        r.abort()
                ctx.route('**/*',route)
                exercise(ctx,size,width,height)
            finally:
                ctx.close()
        browser.close()
except Exception as error:
    check('Browser exercise completed',False, str(error)[:360])
finally:
    results.update(checks=checks, screenshots=pictures, script_errors=errors, total=len(checks),
                   failed=sum(not c['passed'] for c in checks))
    (out/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'browser':results.get('version'),'checks':len(checks),'failed':results['failed'],
                  'failed_checks':[c['name'] for c in checks if not c['passed']]}))
raise SystemExit(1 if results['failed'] else 0)
