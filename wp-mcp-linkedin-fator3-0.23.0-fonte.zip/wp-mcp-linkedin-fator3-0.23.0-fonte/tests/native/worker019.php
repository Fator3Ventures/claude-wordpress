<?php
/** Real WordPress database and SDKs; provider access is synthetic. Run on a fresh lab. */
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;

$tests=[];$observed=[];
function check019(string $name,callable $fn): void {global $tests;try{$fn();$tests[]=['name'=>$name,'passed'=>true];}catch(Throwable $e){$tests[]=['name'=>$name,'passed'=>false,'reason'=>$e->getMessage()];}}
$id='worker019';$consumer='reader019';$input=['connection_id'=>$id,'channel'=>'ads','account_id'=>'222'];
$reader=setup17($id,$consumer);$c=L\Connections::get($id);
api17('save-conversion-grant',['consumer_id'=>'site-core-conversions','enabled'=>true,'expected_revision'=>L\Conversions::grant()['revision'],'connection_id'=>$id,'expected_connection_revision'=>$c['revision'],'account_id'=>'222','conversion_id'=>'9001']);
$lead=['connection_id'=>$id,'account_id'=>'222'];
assert17(L\Conversions::capabilities()['ready']&&$reader->effective_status($lead)['success'],'Fixture requires both grants before diagnostic');
$sid='schedule019';$slot=time()-120;$q=['connection_id'=>$id,'channel'=>'ads','account_id'=>'222','report'=>'ad_accounts'];
L\Schedules::save(['schedule_id'=>$sid,'label'=>'Schedule fixture','query'=>$q,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>$slot]);
$jobKey=hash('sha256','schedule|'.$sid.'|'.$slot);
$onGet=null;$upstreamOk=true;$gets=0;
add_filter('pre_http_request',static function($pre,$args,$url)use(&$onGet,&$upstreamOk,&$gets){
 if(parse_url($url,PHP_URL_PATH)!=='/rest/adAccounts/222')return $pre;
 $gets++;if($onGet)$onGet();return $upstreamOk?result17(['id'=>222]):result17(['message'=>'Synthetic rejection'],403);
},PHP_INT_MAX,3);
$before=L\Store::get('connection',$id);$beforeSchedule=L\Store::get('schedule',$sid);$beforeLead=L\Store::get('grant',$consumer.':'.$id);
$beforeCapi=L\Store::get('conversion_grant',L\Conversions::CONSUMER);$beforeService=L\ServiceAudit::bind($beforeCapi['value'],$beforeCapi['revision']);
$proof=api17('validate-connection',$input);
$observed+=['connection_revision_before'=>$before['revision'],'connection_revision_after'=>$proof['revision'],'capi_ready_after'=>L\Conversions::capabilities()['ready'],'lead_reader_after'=>$reader->effective_status($lead)['success']];
check019('Asset diagnostic persists explicit proof without rewriting connection payload/revision',function()use($proof,$before,$id,$gets){assert17($proof['persisted']&&$proof['proof']['account_id']==='222'&&$proof['proof']['metadata_read']&&$gets===1);assert17($proof['revision']===$before['revision']&&L\Store::get('connection',$id)===$before,'Connection changed');});
check019('Diagnostic keeps current Lead Sync grant operational and revision unchanged',function()use($reader,$lead,$beforeLead,$id,$consumer){assert17($reader->effective_status($lead)['success']&&L\Store::get('grant',$consumer.':'.$id)===$beforeLead);});
check019('Diagnostic keeps CAPI ready, destination and service principal unchanged',function()use($beforeCapi,$beforeService){$g=L\Store::get('conversion_grant',L\Conversions::CONSUMER);assert17(L\Conversions::capabilities()['ready']&&$g===$beforeCapi&&L\ServiceAudit::bind($g['value'],$g['revision'])===$beforeService);});
check019('Diagnostic leaves schedule checkpoint intact',function()use($sid,$beforeSchedule){assert17(L\Store::get('schedule',$sid)===$beforeSchedule);});
check019('Dedicated proof is returned identically by public detail and paged list in one SQL read',function()use($id,$proof){$one=api17('get-connection',['connection_id'=>$id])['connection'];$reads=0;$spy=function($sql)use(&$reads){if(str_starts_with($sql,'SELECT')&&str_contains($sql,L\Store::table()))$reads++;return $sql;};add_filter('query',$spy);try{$pages=L\Connections::list();}finally{remove_filter('query',$spy);}
 $listed=array_column($pages,null,'id')[$id];assert17($one===$listed&&$one['remote_proof']===$proof['proof']&&$reads===1);assert17(!str_contains(wp_json_encode($one),'fixture-secret17')&&!isset($one['binding']));});
check019('Repeated validation does not invalidate the revision held by another administrator',function()use($id,$input,$before){$r=api17('validate-connection',$input);assert17($r['revision']===$before['revision']&&L\Store::get('connection',$id)===$before);});
check019('Unselected account and anonymous principal denied before provider GET',function()use($input,&$gets){$n=$gets;foreach([false,true] as $anon){if($anon)wp_set_current_user(0);try{$r=L\Api::dispatch('validate-connection',$anon?$input:array_replace($input,['account_id'=>'999']));assert17(!$r['success']);}finally{wp_set_current_user(1);}}assert17($gets===$n);});
check019('Supplier refusal leaves the previous proof and configuration untouched',function()use($input,$id,&$upstreamOk){$old=L\Store::get('validation_proof',$id);$raw=L\Store::get('connection',$id);$upstreamOk=false;try{$r=L\Api::dispatch('validate-connection',$input);assert17(!$r['success']&&$old===L\Store::get('validation_proof',$id)&&$raw===L\Store::get('connection',$id));}finally{$upstreamOk=true;}});
check019('Changing the principal during GET prevents committing a result',function()use($id,$input,&$onGet){$prior=L\Store::get('validation_proof',$id);$onGet=static fn()=>wp_set_current_user(0);try{$r=L\Api::dispatch('validate-connection',$input);assert17(!$r['success']&&$r['code']==='not_authorized'&&$prior===L\Store::get('validation_proof',$id));}finally{$onGet=null;wp_set_current_user(1);}});

// Only the new format has this optional bucket. Corrupt just the synthetic diagnostic proof.
if(L\Config::VERSION!=='0.18.0')check019('Unreadable optional proof is isolated and a fresh validation can replace it',function()use($id,$input){
 global $wpdb;$old=L\Store::get('validation_proof',$id);$before=L\Store::get('connection',$id);
 assert17($wpdb->query($wpdb->prepare('UPDATE %i SET payload=%s WHERE bucket=%s AND record_key=%s',L\Store::table(),'broken-test-ciphertext','validation_proof',$id))===1);
 $read=api17('get-connection',['connection_id'=>$id])['connection'];assert17($read['remote_proof']===null&&$read['remote_proof_error']==='cipher_unreadable');assert17(array_column(L\Connections::list(),null,'id')[$id]===$read);
 $fresh=api17('validate-connection',$input);$r=L\Store::get('validation_proof',$id);assert17($r['revision']===$old['revision']+1&&$fresh['proof']===$r['value']['proof']&&$before===L\Store::get('connection',$id));
});

if(L\Config::VERSION!=='0.18.0')check019('Concurrent proof write wins CAS and is not overwritten by a stale validation',function()use($id,$input){
 $old=L\Store::get('validation_proof',$id);$ran=false;$spy=function($sql)use(&$ran,$old,$id){
  if(!$ran&&str_starts_with($sql,'UPDATE')&&str_contains($sql,"bucket='validation_proof'")&&str_contains($sql,$id)){
   $ran=true;$v=$old['value'];$v['proof']['checked_at']='concurrent-fixture';L\Store::put('validation_proof',$id,$v,$old['revision']);
  }return $sql;
 };
 add_filter('query',$spy);try{$r=L\Api::dispatch('validate-connection',$input);}finally{remove_filter('query',$spy);}
 $won=L\Store::get('validation_proof',$id);assert17($ran&&!$r['success']&&$r['code']==='revision_conflict'&&$won['value']['proof']['checked_at']==='concurrent-fixture'&&$won['revision']===$old['revision']+1);
});
if(L\Config::VERSION!=='0.18.0')check019('Transient storage errors reading an optional proof propagate',function()use($id){
 $spy=static function($sql){if(str_starts_with($sql,'SELECT')&&str_contains($sql,"bucket='validation_proof'"))throw new L\Fault('storage_unavailable','Synthetic transient read');return $sql;};
 add_filter('query',$spy);try{$r=L\Api::dispatch('get-connection',['connection_id'=>$id]);assert17(!$r['success']&&$r['code']==='storage_unavailable');}finally{remove_filter('query',$spy);}
});

$armed=false;$lostAck=false;$spy=function($sql)use(&$armed,&$lostAck,$jobKey){if(!$lostAck&&str_contains($sql,$jobKey)){
 if(str_starts_with($sql,'INSERT IGNORE INTO'))$armed=true;
 elseif($armed&&str_starts_with($sql,'SELECT * FROM')){$armed=false;$lostAck=true;throw new L\Fault('storage_unavailable','Synthetic lost readback');}
 }return $sql;};
add_filter('query',$spy);try{L\Schedules::tick();}finally{remove_filter('query',$spy);}
$s=L\Store::get('schedule',$sid);$job=L\Store::get('job',$jobKey);$observed+=['readback_fault_fired'=>$lostAck,'job_exists_after_lost_ack'=>(bool)$job,'schedule_enabled_after_lost_ack'=>$s['value']['enabled'],'slot_preserved'=>$s['value']['next_at']===$slot];
check019('Fault after insertion leaves one durable job and an active retry on the original occurrence',function()use($lostAck,$s,$slot,$job){assert17($lostAck&&$job&&$s['value']['last_code']==='storage_unavailable');assert17($s['value']['enabled']&&$s['value']['next_at']===$slot&&($s['value']['retry_not_before']??0)>time());});
check019('Worker health identifies the pending retry without mutating schedule or job',function()use($sid,$s,$job,$jobKey){$h=L\Worker::health();assert17((bool)array_filter($h['issues'],fn($i)=>($i['schedule_id']??null)===$sid&&$i['code']==='schedule_retry_pending'));assert17(L\Store::get('schedule',$sid)===$s&&L\Store::get('job',$jobKey)===$job);});
check019('Pass before retry deadline leaves all persisted revisions unchanged',function()use($sid,$s,$job,$jobKey){L\Schedules::tick();assert17(L\Store::get('schedule',$sid)===$s&&L\Store::get('job',$jobKey)===$job);});
check019('Resumed occurrence adopts previously inserted job and advances exactly once',function()use($sid,$s,$job,$jobKey,$slot){$v=$s['value'];$v['retry_not_before']=time()-1;L\Store::put('schedule',$sid,$v,$s['revision']);L\Schedules::tick();$after=L\Store::get('schedule',$sid);assert17($after['value']['enabled']&&$after['value']['last_job']===$jobKey&&$after['value']['next_at']>$slot&&empty($after['value']['retry_not_before'])&&$after['value']['last_code']===null);assert17(L\Store::get('job',$jobKey)===$job);$found=array_filter(L\Store::list('job',0,100),fn($r)=>($r['value']['schedule_id']??null)===$sid);assert17(count($found)===1);L\Schedules::tick();assert17(L\Store::get('schedule',$sid)===$after);});
check019('Authorization loss still disables a due schedule without creating a new job',function()use($sid){$r=L\Store::get('schedule',$sid);$v=$r['value'];$v['enabled']=true;$v['next_at']=time()-5;$v['authorization_revision']=-1;unset($v['retry_not_before']);L\Store::put('schedule',$sid,$v,$r['revision']);L\Schedules::tick();$new=L\Store::get('schedule',$sid)['value'];assert17(!$new['enabled']&&$new['last_code']==='revision_conflict');assert17(!L\Store::get('job',hash('sha256','schedule|'.$sid.'|'.$v['next_at'])));});
check019('Credential rotation during GET cannot attach old proof to the new credential',function()use($id,$input,&$onGet){$raw=L\Store::get('connection',$id);$prior=L\Store::get('validation_proof',$id);$overlay=L\Store::get('credential',$id);$onGet=static function()use($id,$raw,$overlay){L\Store::put('credential',$id,['binding'=>L\Credentials::binding($raw['value']),'token'=>'synthetic-rotated19','credential_generation'=>$raw['value']['credential_generation']+1],$overlay['revision']??0);};
 try{$r=L\Api::dispatch('validate-connection',$input);assert17(!$r['success']&&$r['code']==='revision_conflict'&&$prior===L\Store::get('validation_proof',$id));$one=api17('get-connection',['connection_id'=>$id])['connection'];assert17($one['remote_proof']===null&&$one['credential_generation']>$raw['value']['credential_generation']);$listed=array_column(L\Connections::list(),null,'id');assert17($listed[$id]['remote_proof']===null);}finally{$onGet=null;}});
check019('Configuration revision change during GET prevents publishing the candidate observation',function()use($id,$input,&$onGet){$prior=L\Store::get('validation_proof',$id);$onGet=static function()use($id){$r=L\Store::get('connection',$id);$v=$r['value'];$v['label']='Concurrent label';L\Store::put('connection',$id,$v,$r['revision']);};try{$r=L\Api::dispatch('validate-connection',$input);assert17(!$r['success']&&$r['code']==='revision_conflict'&&$prior===L\Store::get('validation_proof',$id));}finally{$onGet=null;}});
$out=['version'=>L\Config::VERSION,'scope'=>'WordPress real, MySQL, LinkedIn HTTP fixture','tests'=>$tests,'observations'=>$observed,'total'=>count($tests),'failed'=>count(array_filter($tests,fn($x)=>!$x['passed']))];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/worker019.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out)."\n";exit($out['failed']?1:0);
