<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
$objects=[];foreach(['7019'=>'135.50','7020'=>'217.25'] as $id=>$amount)$objects[$id]=['id'=>(string)$id,'name'=>'Grupo de teste '.$id,'account'=>'urn:li:sponsoredAccount:222','status'=>'DRAFT','totalBudget'=>['amount'=>$amount,'currency'=>'BRL'],'runSchedule'=>['start'=>1924992000123,'end'=>1925123456789]];
update_option('f3_ui_groups',$objects,false);
