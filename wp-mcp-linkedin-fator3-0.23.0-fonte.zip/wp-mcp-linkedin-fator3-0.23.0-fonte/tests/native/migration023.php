<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
use Fator3\LinkedIn as L;
global $wpdb;$base=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline023.json'),true);$rows=$wpdb->get_results("SELECT bucket,record_key,revision,payload,expires_at,queue_state,queue_next FROM ".L\Store::table()." WHERE bucket IN ('connection','grant','token_proof','credential','mutation','settings','job','lead_scan','schedule','validation_proof','audit') ORDER BY bucket,record_key",ARRAY_A);
$checks=['base_target'=>$base['version']==='0.22.0'&&L\Config::VERSION==='0.23.0','records_and_revisions'=>$base['count']>=7&&hash('sha256',serialize($rows))===$base['digest'],'paused_cursor'=>L\Store::get('job','paused019')['value']['cursor']==='fixture-cursor'&&L\Store::get('job','paused019')['value']['status']==='paused','uncertain_receipt'=>L\Store::get('mutation',str_repeat('a',64))['value']['state']==='uncertain','policy'=>L\Retention::get()['audit_days']===45];
$checks['old_grant_not_extended']=!in_array('ad_source',L\Store::get('grant','consumer019:upgrade019')['value']['permissions'],true);
$checks['schedule_preserved']=!L\Store::get('schedule','paused-schedule')['value']['enabled'];
if(class_exists(\Fator3\McpFiles\ConnectionContext::class)){
 require_once __DIR__.'/fixtures017.php';L\PublicApi::register_consumer(['id'=>'consumer019','label'=>'Synthetic 17','contract'=>'linkedin-lead-reader/1.2.0']);
 wp_set_current_user(0);$v=L\PublicApi::lead_reader('consumer019')->get_response(['connection_id'=>'upgrade019','account_id'=>'222','form_id'=>'8331','response_id'=>'lead17']);
 $checks['legacy_grant_recovers_after_rotation']=$v['success']&&!\Fator3\McpFiles\ConnectionContext::credential_active('grant:qa23-upgrade',1);
}
$r=['total'=>count($checks),'failed'=>count(array_filter($checks,fn($ok)=>!$ok)),'records'=>count($rows),'checks'=>$checks];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/migration023.json',wp_json_encode($r));echo wp_json_encode($r)."\n";exit($r['failed']?1:0);
