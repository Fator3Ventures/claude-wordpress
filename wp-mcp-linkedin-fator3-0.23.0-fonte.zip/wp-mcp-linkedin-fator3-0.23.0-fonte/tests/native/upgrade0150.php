<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
use Fator3\LinkedIn as L;
$b=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline0150.json'),true);$checks=[];global $wpdb;
foreach($b['records'] as $old){$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE bucket=%s AND record_key=%s',L\Store::table(),$old['bucket'],$old['key']),ARRAY_A);$checks[]=['name'=>'preserved '.$old['bucket'].'/'.$old['key'],'passed'=>hash('sha256',serialize($row))===$old['sha256']];}
foreach(['upstream_validation','token_rejected','asset_access_denied','resource_not_found','upstream_error','operation_uncertain'] as $code){$v=L\Store::get('mutation',hash('sha256','legacy15-'.$code))['value'];$reject=false;$checks[]=['name'=>'migration '.$code,'passed'=>$v['state']===($reject?'rejected':'uncertain')&&$v['remote_effect']===($reject?'none':'unknown')&&$v['last_code']===$code];}
$v=L\Store::get('mutation','ea7838f5'.str_repeat('0',56))['value'];$checks[]=['name'=>'reported 422 narrow migration','passed'=>$v['state']==='rejected'&&$v['migration']['evidence_source']==='received_request_18_2026-11-01'];
$checks[]=['name'=>'reported 403 narrow migration','passed'=>L\Store::get('mutation','66c4c78e'.str_repeat('0',56))['value']['state']==='rejected'];
$checks[]=['name'=>'persisted rejection evidence migration','passed'=>L\Store::get('mutation',hash('sha256','legacy15-proven'))['value']['state']==='rejected'];
$checks[]=['name'=>'receipt not guessed absent','passed'=>L\Store::get('mutation',hash('sha256','legacy15-receipt'))['value']['state']==='uncertain'];
$c=L\Connections::public(L\Connections::get('legacy14'));$checks[]=['name'=>'all forms defaults disabled and original configuration preserved','passed'=>$c['all_forms_accounts']===[]&&$c['lead_discovery_interval_minutes']===60&&array_diff_key($c,array_flip(['all_forms_accounts','lead_discovery_interval_minutes']))===$b['connection']];
$checks[]=['name'=>'direct accepted upgrade','passed'=>$b['version']==='0.14.0'&&L\Config::VERSION==='0.15.0'];
$before=$wpdb->get_results('SELECT * FROM '.L\Store::table().' ORDER BY bucket,record_key',ARRAY_A);L\Management::upgrade();$checks[]=['name'=>'migration idempotent','passed'=>$before===$wpdb->get_results('SELECT * FROM '.L\Store::table().' ORDER BY bucket,record_key',ARRAY_A)];
$out=['total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'checks'=>$checks];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/upgrade0150.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out)."\n";
// Clear only synthetic singleton grants so independent regression fixtures can use them.
foreach(['site-core-conversions','site-core-quality:221'] as $key){$r=L\Store::get('conversion_grant',$key);L\Store::remove('conversion_grant',$key,$r['revision']);}
$rp=L\Retention::get();L\Retention::save(['expected_revision'=>$rp['revision'],'audit_mode'=>'unlimited','dry_run'=>false]);exit($out['failed']?1:0);
