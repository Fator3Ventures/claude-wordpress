<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
wp_set_current_user(1);
use Fator3\LinkedIn as L;
$checks=[];$file=realpath(L\Config::DIR.'includes/Data/Documentation.php');
$http=0;add_filter('pre_http_request',function()use(&$http){$http++;return new WP_Error('blocked');});
$index=L\Documentation::read(['document'=>'index']);
$checks['index_is_metadata_only']=!in_array($file,get_included_files(),true);
$doc=L\Documentation::read(['document'=>'PRIMEIROS-PASSOS.md','limit_bytes'=>256]);
$checks['selected_body_loaded']=in_array($file,get_included_files(),true);
$content=$doc['content'];$pages=1;
while($doc['next_offset']!==null){$doc=L\Documentation::read(['document'=>'PRIMEIROS-PASSOS.md','offset'=>$doc['next_offset'],'expected_revision'=>$doc['revision'],'limit_bytes'=>256]);$content.=$doc['content'];$pages++;}
$checks['paginated_utf8_complete']=$pages>1&&$content===file_get_contents(L\Config::DIR.'docs/PRIMEIROS-PASSOS.md')&&hash('sha256',$content)===$doc['revision'];
$checks['no_provider_http']=$http===0;
$r=['checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($v)=>!$v)),'pages'=>$pages,'version'=>L\Config::VERSION];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/docs018.json',wp_json_encode($r));echo wp_json_encode($r)."\n";exit($r['failed']?1:0);
