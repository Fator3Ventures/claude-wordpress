<?php
declare(strict_types=1);
// Disposable installation only: patch the isolated recipient before WordPress boot.
$lab=getenv('F3_LAB_ROOT');
if(!$lab||!getenv('F3_LAB_ID')||json_decode((string)file_get_contents($lab.'/.social-lab.json'),true)['id']!==getenv('F3_LAB_ID'))throw new RuntimeException('Owned lab required');
$core=$lab.'/wordpress/wp-content/plugins/base-site-core-fator3';$file=$core.'/includes/class-f3base-linkedin-cliente.php';$old=file_get_contents($file);
if(hash('sha256',$old)!=='9d12633560406d207839f026d3578122f3dbc98f54ed1bda18fd61b06a0eebdb')throw new RuntimeException('Unexpected Core release');
$patch=dirname(__DIR__,2).'/impacts/core-1.80.0-ad-source.patch';
$p=proc_open(['patch','--batch','-p1','--input',$patch],[0=>['file','/dev/null','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,$core);
foreach($pipes as $pipe){stream_get_contents($pipe);fclose($pipe);}if(proc_close($p)!==0)throw new RuntimeException('Patch refused');
register_shutdown_function(static function()use($file,$old){file_put_contents($file,$old);});
define('F3_CORE_FRONTIER_021',true);require __DIR__.'/ad-source021.php';
