<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
use Fator3\LinkedIn as L;
$checks=[];$http=0;$queries=[];function ck019($name,$ok){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$ok];}
add_filter('pre_http_request',function()use(&$http){$http++;return new WP_Error('blocked','Unexpected request');});
$spy=function($sql)use(&$queries){if(str_contains($sql,L\Store::table()))$queries[]=$sql;return $sql;};
function observe019(){global $queries,$spy;$queries=[];add_filter('query',$spy);try{$result=L\Credentials::status();}finally{remove_filter('query',$spy);}return [$result,count(array_filter($queries,static fn($q)=>str_starts_with($q,'SELECT'))),count(array_filter($queries,static fn($q)=>preg_match('/^(INSERT|UPDATE|DELETE)/i',$q)))];}
[$empty,$n0]=observe019();$initialIds=array_column($empty['connections'],'connection_id');ck019('Initial lifecycle contains no fixture and matches its scope projection',!array_filter($initialIds,fn($id)=>str_starts_with($id,'health019-'))&&$initialIds===array_column($empty['conversion_access'],'connection_id'));
$now=time();for($n=1;$n<=35;$n++){
 $id=sprintf('health019-%02d',$n);$c=['id'=>$id,'label'=>'Fixture '.$n,'token'=>'HIDDEN-bearer','refresh_token'=>'HIDDEN-refresh','client_id'=>'app019','client_secret'=>'HIDDEN-secret','expires_at'=>$now+10*86400,'credential_notice_days'=>7,'users'=>[1],'enabled'=>$n!==2,'assets'=>['ads'=>[],'leads'=>[],'pages'=>[]]];L\Store::put('connection',$id,$c,0);
 if($n<=3){
  $r=['binding'=>L\Credentials::binding($c),'token'=>'HIDDEN-rotated','credential_generation'=>4,'expires_at'=>$now+4*86400];L\Store::put('credential',$id,$r,0);
  if($n!==2)$c['token']=$r['token'];L\Store::put('token_proof',$id,['binding'=>L\Credentials::binding($c),'scopes'=>['rw_conversions','r_ads'],'active'=>true,'checked_at'=>$now-30,'expires_at'=>$now+3*86400],0);
  if($n===1)L\Store::put('credential_health',$id,['last_result'=>'identity_change_required','failures'=>2,'incident'=>['code'=>'identity_change_required'],'next_attempt'=>$now+600],0);
 }
}
[$result,$n,$writes]=observe019();$rows=array_column($result['connections'],null,'connection_id');$scopes=array_column($result['conversion_access'],null,'connection_id');
ck019('Lifecycle SQL reads do not grow with connection count',$n===$n0&&$n===1);
$expectedIds=array_merge($initialIds,array_map(fn($i)=>sprintf('health019-%02d',$i),range(1,35)));sort($expectedIds,SORT_STRING);ck019('All 35 fixture connections and scope projections retain stable matching order',array_keys($rows)===array_keys($scopes)&&array_keys($rows)===$expectedIds);
ck019('Scope and expiry follow the effective rotated credential',$rows['health019-01']['credential_generation']===4&&$rows['health019-01']['expires_at']===$now+3*86400&&$scopes['health019-01']['checked']&&$scopes['health019-01']['rw_conversions']&&$scopes['health019-01']['r_ads']);
ck019('Mismatched proof cannot supply scopes or a checked timestamp',!$scopes['health019-02']['checked']&&$scopes['health019-02']['r_ads']===null&&$scopes['health019-02']['checked_at']===null&&$rows['health019-02']['scopes']===[]&&!$rows['health019-02']['enabled']);
ck019('Pending identity blocks automatic retry and exposes the operator action',$rows['health019-01']['next_attempt']===null&&$rows['health019-01']['incident']['action']==='refresh_and_confirm_identity'&&$rows['health019-01']['failures']===2);
ck019('Notice date uses configured policy and effective expiry',$rows['health019-01']['notification_due_at']===$now-4*86400);
ck019('Unverified scope is unknown, not granted or denied',$scopes['health019-35']['rw_conversions']===null&&$scopes['health019-35']['checked_at']===null);
ck019('No secrets, domain writes or provider requests',!str_contains(wp_json_encode($result),'HIDDEN-')&&$writes===0&&$http===0);
ck019('Standalone scope projection agrees with lifecycle',L\Conversions::scopeStatus()===$result['conversion_access']);
$full=L\Api::dispatch('status');ck019('Public status count agrees with the same returned lifecycle snapshot',$full['success']&&$full['data']['connection_count']===count($full['data']['access_lifecycle']['connections']));
wp_set_current_user(0);try{ck019('Unauthenticated principal cannot read credential health',!L\Api::dispatch('status')['success']);}finally{wp_set_current_user(1);}
$o=['version'=>L\Config::VERSION,'empty_selects'=>$n0,'populated_selects'=>$n,'connections'=>35,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed']))];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/lifecycle019.json',wp_json_encode($o,JSON_PRETTY_PRINT));echo wp_json_encode($o)."\n";exit($o['failed']?1:0);
