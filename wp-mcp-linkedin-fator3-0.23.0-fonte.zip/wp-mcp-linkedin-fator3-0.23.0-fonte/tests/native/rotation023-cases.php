<?php
declare(strict_types=1);
namespace Fator3\LinkedIn\QA023;
use Fator3\LinkedIn as L;
use Fator3\McpFiles as M;

/** QA only. Fixed local models; never issues an outbound request. Uses disposable OAuth rows, not client credentials. */
function run(): array {
    if(!current_user_can('manage_options'))throw new \RuntimeException('Administrator required');
    $user=get_current_user_id();$previous=M\ConnectionContext::transport_identity();
    $tag='qa23'.bin2hex(random_bytes(10));$consumer=$tag.'-consumer';$gids=[$tag.'-old',$tag.'-new'];
    $key=$consumer.':'.$tag;$in=['connection_id'=>$tag,'account_id'=>'222'];
    $ids=['8331','8332','8333','8334'];$checks=[];$reads=0;
    $check=static function($name,$value)use(&$checks){$checks[$name]=(bool)$value;};
    $http=static function($pre,$args,$url)use(&$reads){
        if(($args['method']??'GET')==='GET'&&parse_url($url,PHP_URL_HOST)==='api.linkedin.com'&&parse_url($url,PHP_URL_PATH)==='/rest/leadFormResponses'){
            ++$reads;return ['response'=>['code'=>200],'headers'=>[],'body'=>'{"elements":[],"paging":{"start":0,"total":0}}','cookies'=>[]];
        }
        return new \WP_Error('qa_network_blocked','QA request blocked.');
    };
    $oauth=static function($id)use($user){$p=['user_id'=>$user,'grant_id'=>$id,'client_id'=>'qa23-client','profile'=>'maintenance','status'=>'active','expires'=>time()+90];if(!M\Persistence::put('oauth-grants',$id,$p,true))throw new \RuntimeException('Fixture identity unavailable');M\ConnectionContext::oauth($p);if((M\ConnectionContext::get()['connection_id']??'')!=='grant:'.$id)throw new \RuntimeException('Fixture policy unavailable');};
    add_filter('pre_http_request',$http,PHP_INT_MAX,3);
    try{
        // Create only the isolated connection. Consumer authorization is written through the actual MCP executor.
        $c=['id'=>$tag,'label'=>'QA LinkedIn 25','token'=>str_repeat('synthetic-qa23',9),'client_id'=>'fixture23','client_secret'=>'','application_id'=>'','enabled'=>true,'expires_at'=>0,'users'=>[$user],'assets'=>['ads'=>['222'],'leads'=>['222'],'pages'=>[]],'forms'=>['222'=>$ids],'api_version'=>L\Config::API_VERSION,'created_by'=>$user,'created_at'=>time(),'retention_days'=>90,'retention_mode'=>'unlimited','remote_proof'=>null];
        L\Store::put('connection',$tag,$c,0);L\PublicApi::register_consumer(['id'=>$consumer,'label'=>'QA 23','contract'=>'linkedin-lead-reader/1.2.0']);
        $oauth($gids[0]);$grant=['connection_id'=>$tag,'consumer_id'=>$consumer,'expected_revision'=>0,'enabled'=>true,'permissions'=>['metadata','responses'],'forms'=>['222'=>$ids]];
        $r=\WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::execute(['ability_name'=>'linkedin/save-grant','parameters'=>$grant]);
        $row=L\Store::get('grant',$key);$check('recorded_by_first_transport',!empty($r['data']['success'])&&($row['value']['principal']['channel']['connection_id']??'')==='grant:'.$gids[0]);
        if(!$row)throw new \RuntimeException('Test grant not written');
        $reader=L\PublicApi::lead_reader($consumer);
        $read=static fn($form)=>$reader->read_responses($in+['form_id'=>$form,'form_version'=>'1','from_ms'=>'1793000000000','to_ms'=>'1793000060000']);
        $check('before_rotation_read',$read($ids[0])['success']);
        M\Persistence::delete('oauth-grants',$gids[0]);
        $check('old_credential_revoked',!M\ConnectionContext::credential_active('grant:'.$gids[0],$user));
        $oauth($gids[1]);
        $check('second_transport_authorized',M\ConnectionContext::credential_active('grant:'.$gids[1],$user));
        M\ConnectionContext::restore_identity(null,0);
        foreach($ids as $id){$v=$read($id);$check('service_reads_form_'.$id,$v['success']&&($v['data']['responses']??null)===[]);}
        $before=$reads;$check('unselected_form_denied',$read('8999')['code']==='asset_access_denied'&&$reads===$before);
        $check('no_regrant_or_revision_change',L\Store::get('grant',$key)===$row);
        wp_set_current_user($user);
        M\ConnectionContext::oauth(['user_id'=>$user,'grant_id'=>$gids[1],'client_id'=>'qa23-client','profile'=>'maintenance']);
        $state=static function()use($consumer){
            for($off=0;$off!==null;){$r=L\Api::dispatch('status',['grants_offset'=>$off,'grants_limit'=>20]);if(!$r['success'])return null;$p=$r['data']['consumer_grants']??[];foreach($p['items']??[] as $v)if($v['consumer_id']===$consumer)return $v;$off=$p['next_offset']??null;}return null;
        };
        $item=$state();$check('status_ready_and_scoped',($item['state']??null)==='ready'&&$item['resource']===$tag&&$item['regrant_operation']==='linkedin/save-grant'&&!isset($item['principal'],$item['token']));
        // Demote only a synthetic owner by changing fixture data, never the actual WP administrator.
        $v=$row['value'];$v['principal']['user_id']=0;$bad=L\Store::put('grant',$key,$v,$row['revision']);
        $before=$reads;$check('invalid_owner_blocks_before_network',$read($ids[0])['code']==='not_authorized'&&$reads===$before);
        $item=$state();$check('status_blocked_reason',($item['state']??null)==='blocked'&&$item['reason']==='not_authorized');
        $v=$row['value'];$v['enabled']=false;L\Store::put('grant',$key,$v,$bad['revision']);
        $check('disabled_grant_denied',$read($ids[0])['code']==='not_authorized'&&$reads===$before);
        $check('status_disabled',($state()['state']??null)==='disabled');
        try{L\Access::checkPrincipal($row['value']['principal']);$denied=false;}catch(L\Fault $e){$denied=true;}
        $check('human_original_channel_still_denied',$denied);
    }finally{
        M\ConnectionContext::restore_identity($previous,$user);remove_filter('pre_http_request',$http,PHP_INT_MAX);
        foreach($gids as $id){M\Persistence::delete('connections','grant:'.$id);M\Persistence::delete('oauth-grants',$id);}
        foreach([['grant',$key],['connection',$tag]] as [$b,$k])if($a=L\Store::get($b,$k))L\Store::remove($b,$k,$a['revision']);
    }
    $check('domain_rows_removed_and_transport_tombstoned',!L\Store::get('grant',$key)&&!L\Store::get('connection',$tag)&&!M\ConnectionContext::credential_active('grant:'.$gids[1],$user)&&(M\Persistence::get('connections','grant:'.$gids[0])['_storage']['status']??'')==='deleted');
    return ['checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($x)=>!$x)),'fixture_reads'=>$reads];
}
