const fs=require('fs');
const {JSDOM,CookieJar,ResourceLoader,VirtualConsole}=require(process.env.F3_JSDOM);
(async()=>{
 const root=process.env.F3_UI_URL,jar=new CookieJar(),checks=[],errors=[],calls=[];
 let pending=0,gate=null,dom;
 const unexpected=reason=>{const message=reason instanceof Error?reason.stack:JSON.stringify(reason,Object.keys(reason||{}));errors.push('unhandled: '+message);console.error('Unhandled cause: '+message);};
 process.on('unhandledRejection',unexpected);
 async function request(url,opts={}){
  const r=await fetch(url,{...opts,signal:AbortSignal.timeout(60000),headers:{connection:'close',...opts.headers,cookie:await jar.getCookieString(url)},redirect:'manual'});
  for(const c of r.headers.getSetCookie())await jar.setCookie(c,url);if(r.status>=300&&r.status<400){const next=new URL(r.headers.get('location'),url).href;await r.arrayBuffer();return request(next);}
  return r;
 }
 await request(root+'/wp-login.php');await request(root+'/wp-login.php',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({log:'social_admin',pwd:process.env.F3_UI_PASSWORD,redirect_to:root+'/wp-admin/',testcookie:'1'}).toString()});
 class LocalResources extends ResourceLoader{fetch(url,opts){return url.startsWith(root+'/')?super.fetch(url,opts):null;}}
 const url=root+'/wp-admin/tools.php?page=wp-mcp-linkedin-fator3&tab=management',html=await(await request(url)).text(),vc=new VirtualConsole();
 vc.on('jsdomError',e=>{if(!/Not implemented|Could not parse CSS/.test(e.message))errors.push(e.message);});
 dom=new JSDOM(html,{url,cookieJar:jar,runScripts:'dangerously',resources:new LocalResources(),pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  w.matchMedia=()=>({matches:false,addListener(){},removeListener(){},addEventListener(){}});w.scrollTo=()=>{};
  w.fetch=async(u,o)=>{pending++;try{
   const href=new URL(u.url||u,root).href,op=href.split('/').at(-1);if(new URL(href).origin!==root)throw Error('Rede externa bloqueada no laboratório');
   let input={};if(typeof o?.body==='string'){try{input=JSON.parse(o.body);}catch(_){/* WordPress also sends non-JSON forms. */}}
   calls.push({op,input});
   // If an obsolete client tries to dispatch a commercial mutation, record the attempt but never forward it.
   if(input.dry_run===false&&input.confirm===true)return {ok:false,status:409,json:async()=>({success:false,code:'fixture_intercept',message:'Escrita interceptada na bancada'})};
   const response=await request(href,o);if(gate&&gate.op===op&&(!gate.predicate||gate.predicate(input))){const g=gate;gate=null;g.received=true;await new Promise(resolve=>g.release=resolve);}return response;
  }finally{pending--;}}
 }});
 const w=dom.window,d=w.document,$=s=>d.querySelector(s),f=$('#f3-management-form'),execute=$('#f3-management-execute'),box=$('#f3-management-result');
 const pause=ms=>new Promise(r=>setTimeout(r,ms));const event=(n,type)=>n.dispatchEvent(new w.Event(type,{bubbles:true,cancelable:true}));
 const change=(n,v)=>{f.elements[n].value=v;event(f.elements[n],'change');};const input=(n,v)=>{f.elements[n].value=v;event(f.elements[n],'input');};
 const wait=async(fn,label)=>{for(let n=0;n<800;n++){if(fn())return;await pause(40);}throw Error(label+': '+box.textContent+' / '+$('#f3-message').textContent);};
 const check=(name,passed)=>checks.push({name,passed:!!passed});
 const hold=(op,predicate)=>{const g={op,predicate,received:false};gate=g;return g;};
 const held=async(g)=>wait(()=>g.received&&g.release,'Expected delayed '+g.op);
 const release=async(g)=>{g.release();await pause(50);};
 const requestPreview=()=>event(f,'submit');
 try{
  await wait(()=>f.elements.connection_id.querySelector('option[value=ui]'),'boot');
  change('connection_id','ui');change('account_id','222');change('action','update');
  $('#f3-management-list').click();await wait(()=>f.elements.object_id.querySelector('option[value="7019"]'),'managed objects');
  change('object_id','7019');$('#f3-management-read').click();await wait(()=>f.elements.name.value==='Grupo de teste 7019','explicit read');
  check('Explicit read preserves the remote monetary amount',f.elements.total_budget.value==='135.50');
  check('Explicit read preserves the currency paired with the amount',f.elements.currency.value==='BRL');
  change('object_id','7020');input('name','Nome editado localmente');input('total_budget','199.90');input('currency','BRL');
  requestPreview();await wait(()=>calls.some(c=>c.op==='update-campaign-group'&&c.input.dry_run),'implicit read and preview');
  const q=calls.find(c=>c.op==='update-campaign-group'&&c.input.dry_run);
  check('Revision-only read preserves typed name in request and editor',q.input.fields.name==='Nome editado localmente'&&f.elements.name.value==='Nome editado localmente');
  check('Revision-only read preserves typed amount in request and editor',q.input.fields.total_budget?.amount==='199.90'&&f.elements.total_budget.value==='199.90');
  check('Update does not submit an untouched schedule or other field from an earlier read',Object.keys(q.input.fields).sort().join(',')==='name,total_budget');
  await wait(()=>pending===0,'updated preview response');
  const previewCall=async()=>{const n=calls.length;requestPreview();await wait(()=>calls.slice(n).some(c=>c.op==='update-campaign-group'&&c.input.dry_run),'schedule preview');await wait(()=>pending===0,'schedule confirmation ready');return calls.slice(n).find(c=>c.op==='update-campaign-group').input.fields.schedule;};
  const stampA=1924992000123,stampB=1925123456789;
  change('object_id','7019');input('start','2031-01-01T02:25');let proposed=await previewCall();
  check('Editing only start preserves exact remote end including milliseconds',proposed?.start===Date.parse('2031-01-01T02:25Z')&&proposed?.end===stampB);
  change('object_id','7020');$('#f3-management-read').click();await wait(()=>f.elements.name.value==='Grupo de teste 7020','read second schedule');
  input('end','2031-02-01T08:30');proposed=await previewCall();
  check('Editing only end preserves exact remote start despite minute-only display',proposed?.start===stampA&&proposed?.end===Date.parse('2031-02-01T08:30Z'));
  input('end','');proposed=await previewCall();
  check('Explicitly clearing end proposes removal without changing exact start',proposed?.start===stampA&&!Object.hasOwn(proposed,'end'));

  change('action','create');input('name','Rascunho A');input('start','2031-01-01T12:00');input('total_budget','');input('currency','BRL');
  let g=hold('create-campaign-group',i=>i.dry_run);requestPreview();await held(g);input('name','Rascunho B');await release(g);
  check('Delayed preview cannot reenable execution after editing',execute.disabled);
  input('name','Prévia mais antiga');g=hold('create-campaign-group',i=>i.dry_run);requestPreview();await held(g);input('name','Prévia atual');requestPreview();
  await wait(()=>!execute.disabled&&box.textContent.includes('Prévia atual'),'current preview');
  await release(g);check('Older response cannot replace the currently reviewed proposal',box.textContent.includes('Prévia atual')&&!box.textContent.includes('Prévia mais antiga'));
  // Simulate a form change by external code without a DOM change event.
  f.elements.name.value='Outro valor visível';const written=calls.filter(c=>c.input.dry_run===false).length;execute.click();await pause(75);
  check('Programmatic mismatch never dispatches an execute request',calls.filter(c=>c.input.dry_run===false).length===written);
  change('action','update');change('object_id','7019');g=hold('get-campaign-group');$('#f3-management-read').click();await held(g);
  change('object_id','7020');input('name','Rascunho do segundo grupo');await release(g);
  check('Read returning after selection change never overwrites current draft',f.elements.name.value==='Rascunho do segundo grupo');
  change('kind','campaign');change('action','create');input('target_search','Santos');g=hold('search-targeting');$('#f3-target-search').click();await held(g);
  input('target_search','Campinas');await release(g);
  check('Obsolete targeting results cannot be chosen for a new search',![...f.elements.target_result.options].some(o=>o.value));
  $('#f3-target-search').click();await wait(()=>[...f.elements.target_result.options].some(o=>o.textContent==='Campinas'),'new targeting search');
  change('target_result','0');$('#f3-target-add').click();check('A valid current targeting choice can still be added',$('#f3-target-selected').textContent.includes('Campinas'));
  change('account_id','');check('Changing account removes targeting chosen in another account',!$('#f3-target-selected').textContent);
  change('account_id','222');change('action','update');
  const selectAudience=async()=>{input('target_search','Campinas');$('#f3-target-search').click();await wait(()=>[...f.elements.target_result.options].some(o=>o.textContent==='Campinas'),'audience in current scope');change('target_result','0');$('#f3-target-add').click();};
  $('#f3-management-list').click();await wait(()=>f.elements.object_id.querySelector('option[value="555"]')&&pending===0,'campaign options');change('object_id','555');await selectAudience();
  $('#f3-management-list').click();await wait(()=>pending===0,'same catalog');check('Reloading same campaign retains selected object and its audience',f.elements.object_id.value==='555'&&$('#f3-target-selected').textContent.includes('Campinas'));
  // An object previously visible but no longer returned on this catalog page.
  f.elements.object_id.add(new w.Option('Campanha anterior','777'));change('object_id','777');
  check('Changing campaign explicitly clears audience and search results',!$('#f3-target-selected').textContent&&![...f.elements.target_result.options].some(o=>o.value));
  await selectAudience();input('name','Rascunho fora do recorte');$('#f3-management-list').click();await wait(()=>pending===0,'object removed from catalog');
  check('Catalog removing target clears audience, search, draft and selection',!f.elements.object_id.value&&!$('#f3-target-selected').textContent&&!f.elements.name.value&&![...f.elements.target_result.options].some(o=>o.value));
  change('action','activate');check('Activation describes potential spend before confirmation',($('#f3-management-effect')?.textContent||'').includes('gasto')&&execute.textContent.includes('ativação'));
  change('kind','post');change('action','create');check('Publication describes page visibility before confirmation',($('#f3-management-effect')?.textContent||'').includes('publicado')&&execute.textContent.includes('Publicar'));
  check('Target, editing and execution are separately named groups',['1. Destino e operação','2. Dados da alteração','3. Revisão e execução'].every(l=>[...f.querySelectorAll('legend')].some(x=>x.textContent===l)));
  check('No management JavaScript runtime error',errors.length===0);
 }catch(e){checks.push({name:'Complete test sequence',passed:false,reason:e.message});}
 const result={engine:'jsdom + actual WordPress page, authenticated REST, synthetic LinkedIn; confirmation intercepted before forwarding',total:checks.length,failed:checks.filter(v=>!v.passed).length,checks,errors};
 fs.writeFileSync(process.env.F3_LAB_ROOT+'/evidence/management019.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));dom.window.close();if(result.failed)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
