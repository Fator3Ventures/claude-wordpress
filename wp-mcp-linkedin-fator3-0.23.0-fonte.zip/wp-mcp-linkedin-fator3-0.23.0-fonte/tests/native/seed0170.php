<?php
require __DIR__.'/fixtures017.php';use Fator3\LinkedIn as L;
assert17(L\Config::VERSION==='0.16.0');$reader=setup17('upgrade17','upgrade17','1.1.0');$keys=[];
foreach(['8331','8332','8333','8334'] as $form){$r=$reader->create_subscription(['connection_id'=>'upgrade17','account_id'=>'222','form_id'=>$form,'form_version'=>'1','callback_url'=>'https://example.com/lead17','idempotency_key'=>'legacy-'.$form]);assert17($r['success'],wp_json_encode($r));$keys[]=$r['data']['ownership_key'];}
$records=[];foreach(['connection','grant','subscription','subscription_guard'] as $bucket)foreach(L\Store::scan($bucket,'',100) as $r)$records[]=['bucket'=>$bucket,'key'=>$r['key'],'hash'=>hash('sha256',serialize($r))];
file_put_contents(getenv('F3_LAB_ROOT').'/baseline0170.json',wp_json_encode(['version'=>L\Config::VERSION,'records'=>$records,'keys'=>$keys,'remote'=>$GLOBALS['remote17']]));
echo "{\"baseline_operated_1_1\":true,\"confirmed_subscriptions\":4}\n";
