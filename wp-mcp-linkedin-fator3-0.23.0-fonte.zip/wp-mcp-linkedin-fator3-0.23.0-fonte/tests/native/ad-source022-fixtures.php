<?php
require_once __DIR__.'/ad-source021-fixtures.php';
function fixture22($pre,$args,$url){
    $v=fixture21($pre,$args,$url);
    if(is_wp_error($v))return $v;
    $path=rawurldecode(parse_url($url,PHP_URL_PATH));$body=json_decode($v['body'],true);
    $case=$GLOBALS['f22case']??'normal';
    if(str_contains($path,'/creatives/')){
        $target=match($case){'foreign'=>'urn:li:adForm:8444','malformed'=>'urn:li:organization:8331','alternate'=>'urn:li:leadGenForm:8331','absent'=>null,default=>'urn:li:adForm:8331'};
        if($target===null)unset($body['leadgenCallToAction']['destination']);else $body['leadgenCallToAction']['destination']=$target;
    }
    if(str_contains($path,'/images/')||str_contains($path,'/videos/')){
        $base='https://media.licdn.com/dms/image/fixture?t=synthetic_signature_21';$future=$GLOBALS['f22epoch'];
        if($case==='early-first')$body['downloadUrl']=$base.'&e=1000000000&e='.$future;
        if($case==='early-last')$body['downloadUrl']=$base.'&e='.$future.'&e=1000000000';
        if($case==='short')$body['downloadUrl']=$base.'&e=0';
        if($case==='valid')$body['downloadUrl']=$base.'&e='.($future+21).'&e='.$future.'&e='.($future+11);
        if($case==='video-thumb')$body['thumbnail']=$base.'&%65=1000000000&e='.$future;
    }
    $v['body']=wp_json_encode($body);return $v;
}
