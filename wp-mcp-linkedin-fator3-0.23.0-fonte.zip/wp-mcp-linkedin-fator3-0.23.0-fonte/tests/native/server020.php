<?php
/** Disposable WordPress only. Synthetic LinkedIn HTTP fixtures; optional real MCP JSON-RPC over loopback. */
declare(strict_types=1);
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;
use Fator3\McpFiles as M;

$lab=getenv('F3_LAB_ROOT');
$owner=json_decode(file_get_contents($lab.'/.social-lab.json'),true);
if($owner['id']!==getenv('F3_LAB_ID'))throw new RuntimeException('Owned lab required');
$checks=[];
function check20(string $label, bool $pass): void {global $checks;$checks[]=['name'=>$label,'passed'=>$pass];}
function events20(): int {global $wpdb;return (int)$wpdb->get_var("SELECT COUNT(*) FROM ".L\Store::table()." WHERE bucket='audit'");}
function added20(string $label,int $expected,callable $f) {$n=events20();$result=$f();check20($label,events20()===$n+$expected);return $result;}
function rest20(string $op,array $input=[]): WP_REST_Response {$r=new WP_REST_Request('POST','/'.L\Config::REST.'/'.$op);$r->set_header('Content-Type','application/json');$r->set_body(wp_json_encode((object)$input));return rest_do_request($r);}
function mcp20(string $origin,string $auth,string $op,array $i=[]): array {
    $params=['name'=>'wp-mcp-ultimate-execute-ability','arguments'=>['ability_name'=>'linkedin/'.$op,'parameters'=>(object)$i],'_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>(object)[]]];
    $body=wp_json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>'tools/call','params'=>$params]);
    $ctx=stream_context_create(['http'=>['method'=>'POST','ignore_errors'=>true,'follow_location'=>0,'timeout'=>30,'header'=>"Host: example.com\r\nAuthorization: ".$auth."\r\nContent-Type: application/json\r\nAccept: application/json\r\nMcp-Protocol-Version: 2026-07-28\r\nMcp-Method: tools/call\r\nMcp-Name: wp-mcp-ultimate-execute-ability\r\n",'content'=>$body]]);
    $wire=file_get_contents($origin.'/?rest_route=/mcp/wp-mcp-fator3',false,$ctx);
    $obj=json_decode($wire?:'',true);
    if(!isset($obj['result']['structuredContent']))throw new RuntimeException('MCP tool result unavailable; status '.($http_response_header[0]??'unknown').' / '.($obj['error']['code']??$obj['code']??'no_code'));
    $result=$obj['result'];$v=$result['structuredContent'];
    check20('parity text/structuredContent '.$op,json_decode($result['content'][0]['text'],true)===$v);
    if(!empty($result['isError'])||empty($v['success']))throw new RuntimeException('MCP refused: '.$op.' / '.($v['error_code']??'unknown'));
    while(isset($v['data']['success']))$v=$v['data'];
    return $v['data'];
}

$reader=setup17('valid20','reader20');$ctx=['connection_id'=>'valid20','account_id'=>'222'];
$paused=['connection_id'=>'incomplete20','expected_revision'=>0,'enabled'=>false];
$r=L\Api::dispatch('save-connection',array_replace($paused,['connection_id'=>'newempty20','enabled'=>true]));
check20('new enabled connection without token refused before persistence',$r['code']==='application_required'&&!L\Store::get('connection','newempty20'));
$p=api17('save-connection',$paused)['connection'];
$r=L\Api::dispatch('save-connection',['connection_id'=>'incomplete20','expected_revision'=>$p['revision'],'enabled'=>true]);
check20('paused draft cannot be enabled without a token',$r['code']==='application_required'&&!L\Connections::get('incomplete20')['enabled']);
$v=L\Connections::get('valid20');
$r=api17('save-connection',['connection_id'=>'valid20','expected_revision'=>$v['revision'],'token'=>'','client_secret'=>'','label'=>'Renamed']);
check20('blank secret fields retain the verified material',$r['persisted']&&$v['token']===L\Connections::get('valid20')['token']&&$v['client_secret']===L\Connections::get('valid20')['client_secret']);
$v=L\Store::get('connection','incomplete20');$v['value']['enabled']=true;L\Store::put('connection','incomplete20',$v['value'],$v['revision']);
$snap=L\Store::get('connection','incomplete20');$calls=count($GLOBALS['calls17']);
added20('25 successful status reads do not append audit rows',0,function(){for($n=0;$n<25;$n++)api17('status',[]);});
$state=api17('status',[]);
check20('diagnoses historical active connection without token without repairing or contacting supplier',$state['state']==='degraded'&&in_array('incomplete20',array_column(array_filter($state['issues'],fn($i)=>$i['code']==='connection_without_token'),'connection_id'),true)&&$snap===L\Store::get('connection','incomplete20')&&$calls===count($GLOBALS['calls17']));
added20('local REST GET-equivalent does not audit',0,fn()=>rest20('get-connection',['connection_id'=>'valid20']));
$r=added20('local validation refusal contributes one event',1,fn()=>L\Api::dispatch('get-connection',['connection_id'=>'bad id']));
check20('closed input rejected',!$r['success']);
$r=added20('direct SDK read without network does not audit',0,fn()=>$reader->effective_status($ctx));
check20('SDK consumer still reads numeric credential revision',!empty($r['success'])&&is_int($r['data']['credential_revision']));
$r=added20('direct SDK supplier read audits one logical call',1,fn()=>$reader->read_responses($ctx+['form_id'=>'8331','form_version'=>'1','from_ms'=>'1793500000000','to_ms'=>'1793700000000']));
check20('SDK reader actually consulted supplier',$r['success']);
$r=added20('relayed provider read audits once',1,fn()=>L\Api::dispatch('lead-read-responses',$ctx+['form_id'=>'8331','form_version'=>'1','from_ms'=>'1793500000000','to_ms'=>'1793700000000']));
check20('relayed lookup succeeds',$r['success']);
$r=added20('relayed SDK refusal audits once',1,fn()=>L\Api::dispatch('lead-effective-status',array_replace($ctx,['account_id'=>'999'])));
check20('relay preserved denial',!$r['success']);
added20('local rejected SDK records one event',1,fn()=>$reader->effective_status(array_replace($ctx,['account_id'=>'999'])));
added20('schema failure for documentation leaves audit unchanged',0,fn()=>L\Api::dispatch('documentation',['surplus'=>1]));
$read=api17('documentation',['document'=>'README.md','limit_bytes'=>256]);$args=['document'=>'README.md','offset'=>$read['next_offset'],'limit_bytes'=>256];
$m=L\Api::dispatch('documentation',$args);$stale=L\Api::dispatch('documentation',$args+['expected_revision'=>str_repeat('a',64)]);$valid=L\Api::dispatch('documentation',$args+['expected_revision'=>$read['revision']]);
check20('pagination absent revision, stale revision and valid revision are distinguishable',$m['code']==='revision_conflict'&&$m['conflict']&&str_contains($m['message'],'expected_revision')&&$stale['code']==='revision_conflict'&&$stale['message']!==$m['message']&&$valid['success']);
$subscriber=wp_insert_user(['user_login'=>'review020','user_pass'=>wp_generate_password(24),'role'=>'subscriber']);
wp_set_current_user($subscriber);$a=wp_get_ability('linkedin/get-connection');
added20('discovery permission probe has no audit side effect',0,fn()=>$a->check_permissions(['connection_id'=>'valid20']));
$r=added20('authenticated domain REST denial recorded once',1,fn()=>rest20('get-connection',['connection_id'=>'valid20']));
check20('subscriber REST refused',$r->get_status()===403);
if($a instanceof M\OwnedAbility){
    $filter=['ability'=>'linkedin/get-connection'];
    $before=M\Persistence::listing('audit',$filter,200);
    $r=added20('MCP gate rejects before entering the LinkedIn audit',0,fn()=>$a->execute(['connection_id'=>'valid20']));
    $after=M\Persistence::listing('audit',$filter,200);
    check20('MCP gate writes exactly one transport denial receipt',count($after)===count($before)+1&&$after[0]['success']===false&&$after[0]['user']===$subscriber);
    check20('subscriber denied by decorated ability',is_array($r)&&$r['success']===false&&$r['error_code']==='permission_denied');
}else{
    $r=added20('authenticated native ability denial recorded once',1,fn()=>$a->execute(['connection_id'=>'valid20']));
    check20('subscriber ability refused',is_wp_error($r));
}
wp_set_current_user(1);
$meta=wp_get_ability('linkedin/status')->get_meta()['fator3'];
check20('catalog distinguishes audit from domain writes',$meta['mode']==='read'&&$meta['local_effect']==='none'&&$meta['audit_policy']==='on_supplier_attempt_or_failure'&&wp_get_ability('linkedin/documentation')->get_meta()['fator3']['audit_policy']==='none');
update_option('f3_linkedin_last_maintenance',['credentials_code'=>'unexpected-free-text']);
check20('unknown maintenance code cannot escape through a neutral alias',api17('status',[])['maintenance']['last']['renewal_result']==='other_failure');
update_option('f3_linkedin_last_maintenance',['credentials_code'=>'ok']);
if(class_exists(M\SafeOutput::class)) {
    $server=null;$uuid=null;
    try {
        $sock=stream_socket_server('tcp://127.0.0.1:0',$errno,$err);if(!$sock)throw new RuntimeException('No loopback port');
        $address=stream_socket_get_name($sock,false);fclose($sock);
        $app=WP_Application_Passwords::create_new_application_password(1,['name'=>'isolated-server020']);
        if(is_wp_error($app))throw new RuntimeException('Application password not created');
        $uuid=$app[1]['uuid'];$id='app:'.$uuid;
        M\Persistence::put('connections',$id,['connection_id'=>$id,'user_id'=>1,'status'=>'active','profile'=>'maintenance','abilities'=>[],'policy_version'=>1,'expires'=>0]);
        $auth='Basic '.base64_encode(get_userdata(1)->user_login.':'.$app[0]);
        $cmd=json_decode(getenv('F3_LAB_PHP'),true);$log=$lab.'/private/server020-http.log';
        $server=proc_open([...$cmd,'-S',$address,'-t',ABSPATH,__DIR__.'/server020-router.php'],[0=>['pipe','r'],1=>['file',$log,'a'],2=>['file',$log,'a']],$pipes);
        fclose($pipes[0]);for($n=0;$n<100;$n++){if($s=@fsockopen('127.0.0.1',(int)explode(':',$address)[1],$e,$err,.1)){fclose($s);break;}usleep(50000);}
        $origin='http://'.$address;
        $cfg=mcp20($origin,$auth,'configuration-schema');$health=mcp20($origin,$auth,'status');$cap=mcp20($origin,$auth,'capabilities');$conn=mcp20($origin,$auth,'get-connection',['connection_id'=>'valid20'])['connection'];
        $life=array_column($health['access_lifecycle']['connections'],null,'connection_id')['valid20'];
        check20('actual MCP keeps config rules and masks legacy names',$cfg['input_method']==='manual_token'&&$cfg['blank_keeps_existing']===true&&$cfg['credential_input']==='[redigido]'&&$cfg['empty_secret_keeps_existing']==='[redigido]');
        check20('actual MCP keeps typed maintenance and SDK projections',$health['maintenance']['last']['renewal_result']==='ok'&&$cap['local_sdk']['features']['dispatch_checks_access']===true&&$cap['local_sdk']['features']['dispatch_authorization']==='[redigido]');
        check20('actual MCP preserves notice threshold and unchanged revision types',$conn['notice_days']===14&&$life['notice_days']===14&&$conn['credential_notice_days']==='[redigido]'&&is_int($conn['authorization_revision'])&&is_int($conn['credential_generation'])&&is_bool($conn['token_configured'])&&is_bool($conn['secret_configured'])&&is_bool($conn['refresh_configured']));
        check20('actual MCP preserves issue without credential bytes',in_array('connection_without_token',array_column($health['issues'],'code'),true)&&!str_contains(wp_json_encode([$cfg,$health,$cap,$conn]),'fixture-secret17')&&!str_contains(wp_json_encode([$cfg,$health,$cap,$conn]),str_repeat('synthetic17',15)));
    }catch(Throwable $ex){check20('real loopback MCP: '.$ex->getMessage(),false);}
    finally{if(is_resource($server)){proc_terminate($server);proc_close($server);}if($uuid){M\Persistence::delete('connections','app:'.$uuid);WP_Application_Passwords::delete_application_password(1,$uuid);}}
}
$out=['release'=>L\Config::VERSION,'mcp_loaded'=>class_exists(M\SafeOutput::class),'supplier'=>'synthetic HTTP boundary','total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'checks'=>$checks];
file_put_contents($lab.'/evidence/server020.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));echo wp_json_encode(['total'=>$out['total'],'failed'=>$out['failed'],'failures'=>array_values(array_filter($checks,fn($c)=>!$c['passed']))])."\n";exit((int)(bool)$out['failed']);
