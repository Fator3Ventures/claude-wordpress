<?php
/** Isolated GET-only LinkedIn fixture. No real account, address or credentials. */
function fixture21($pre,$args,$url){
    $p=rawurldecode(parse_url($url,PHP_URL_PATH));$m=$GLOBALS['f21mode']??'article';
    $GLOBALS['f21calls'][]=[$args['method'],$p];
    if(!str_starts_with($url,'https://api.linkedin.com/rest/')||$args['method']!=='GET')return new WP_Error('no_network','Blocked by the isolated fixture');
    $status=200;$owner='urn:li:organization:111';$account='urn:li:sponsoredAccount:222';$post='urn:li:share:444';$image='urn:li:image:FX_4';$video='urn:li:video:FX_5';
    if(str_contains($p,'/leadFormResponses/')){
        $body=['id'=>'response_1','owner'=>['sponsoredAccount'=>$m==='wrong-lead'?'urn:li:sponsoredAccount:444':$account],'versionedLeadGenFormUrn'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:8331,1)','leadType'=>'SPONSORED','associatedEntity'=>['associatedCreative'=>$m==='missing-creative'?null:'urn:li:sponsoredCreative:777'],'leadMetadata'=>['sponsoredLeadMetadata'=>['campaign'=>'urn:li:sponsoredCampaign:'.($m==='wrong-campaign-ref'?'123':'999')]]];
    }elseif(str_ends_with($p,'/creatives/urn:li:sponsoredCreative:777')){$body=['id'=>'urn:li:sponsoredCreative:777','account'=>$m==='foreign-account'?'urn:li:sponsoredAccount:333':$account,'campaign'=>'urn:li:sponsoredCampaign:999','name'=>'Anúncio A','content'=>$m==='no-post'?[]:['reference'=>$post],'leadgenCallToAction'=>['destination'=>'urn:li:adForm:8331','label'=>'LEARN_MORE']];}
    elseif(str_ends_with($p,'/adCampaigns/999')){$body=['id'=>999,'name'=>'Campanha A','account'=>$m==='foreign-campaign'?'urn:li:sponsoredAccount:333':$account];}
    elseif(str_ends_with($p,'/posts/'.$post)){
        $content=match($m){'video','video-no-expiry'=>['media'=>['id'=>$video,'title'=>'Vídeo']],'no-media'=>[],default=>['article'=>['title'=>'Título','description'=>'Descrição','source'=>'https://example.org/article','thumbnail'=>$image]]};
        $body=['id'=>$m==='wrong-post'?'urn:li:share:445':$post,'author'=>$owner,'adContext'=>['dscAdAccount'=>$m==='wrong-dsc'?'urn:li:sponsoredAccount:333':$account],'content'=>$content,'commentary'=>'Texto','contentLandingPage'=>'https://example.org/landing','contentCallToActionLabel'=>'VISIT_WEBSITE'];
    }elseif(str_ends_with($p,'/images/'.$image)||str_ends_with($p,'/videos/'.$video)){
        if($m==='denied'){$body=['status'=>403];$status=403;}
        else{$videoMode=str_contains($p,'/videos/');$body=['id'=>$m==='wrong-media-id'?'urn:li:image:other':($videoMode?$video:$image),'owner'=>$m==='foreign-owner'?'urn:li:organization:999':$owner,'status'=>$m==='processing'?'PROCESSING':'AVAILABLE','downloadUrl'=>($m==='unsafe-cdn'?'https://licdn.com.evil.test/d':'https://media.licdn.com/dms/image/fixture').'?v=beta&t=synthetic_signature_21','downloadUrlExpiresAt'=>(time()+($m==='expired'?-5:3600))*1000,'thumbnail'=>'https://media.licdn.com/image/small'.($m==='video-no-expiry'?'':'?e='.(time()+1800))];}
    }else{return new WP_Error('unrecognized','Unexpected fixture path');}
    if(isset($GLOBALS['f21hook']))($GLOBALS['f21hook'])($p);
    return ['response'=>['code'=>$status],'body'=>wp_json_encode($body),'headers'=>[],'cookies'=>[]];
}
