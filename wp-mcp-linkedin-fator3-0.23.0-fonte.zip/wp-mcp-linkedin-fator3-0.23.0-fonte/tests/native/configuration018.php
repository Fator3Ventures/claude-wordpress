<?php
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;
$checks=[];function test018(string $name,callable $f){global $checks;try{$f();$checks[]=['name'=>$name,'passed'=>true];}catch(Throwable $e){$checks[]=['name'=>$name,'passed'=>false,'reason'=>$e->getMessage()];}}
if(getenv('F3_LAB_ORIGIN')==='upgrade')test018('Direct upgrade retains ciphertext, revisions, grants, paused job, settings and progress',function(){
 global $wpdb;$base=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline018.json'),true);
 $rows=$wpdb->get_results("SELECT bucket,record_key,revision,payload,expires_at,queue_state,queue_next FROM ".L\Store::table()." WHERE bucket IN ('connection','grant','token_proof','credential','mutation','settings','job','lead_scan') ORDER BY bucket,record_key",ARRAY_A);
 assert17($base['version']==='0.17.1'&&L\Config::VERSION==='0.18.0'&&$base['count']>=7&&hash('sha256',serialize($rows))===$base['digest']);
});
$baseline=L\Config::VERSION==='0.17.1';
for($n=0;$n<57;$n++){
 $id=sprintf('list018-%02d',$n);$c=['id'=>$id,'label'=>'Equipe '.$n,'token'=>'SANITIZED-token-'.$n,'client_secret'=>'SANITIZED-secret','client_id'=>'fixture18','refresh_token'=>'SANITIZED-refresh','users'=>[1],'assets'=>['ads'=>['222']],'enabled'=>true,'token_configured'=>true];L\Store::put('connection',$id,$c,0);
 if($n<4){
  $binding=L\Credentials::binding($c);L\Store::put('credential',$id,['binding'=>$n===2?'mismatch':$binding,'token'=>'SANITIZED-effective','refresh_token'=>'SANITIZED-rotated','credential_generation'=>5],0);
  if($n!==2)$c['token']='SANITIZED-effective';L\Store::put('token_proof',$id,['binding'=>$n===1?'mismatch':L\Credentials::binding($c),'client_id'=>'fixture18','scopes'=>['r_ads'],'expires_at'=>time()+900],0);
  L\Store::put('credential_candidate',$id,['user'=>$n===1?99:1,'revision'=>1,'credentials'=>['token'=>'SANITIZED-pending']],0,$n===2?time()-60:time()+900);
 }
}
global $wpdb;$count=0;$spy=function($sql)use(&$count,$wpdb){if(str_starts_with($sql,'SELECT')&&str_contains($sql,L\Store::table()))$count++;return $sql;};add_filter('query',$spy);
$rows=L\Connections::list(0,51);remove_filter('query',$spy);
test018('Listing a page uses one SQL statement regardless of connection count',function()use($count,$baseline){assert17($baseline?$count>51:$count===1,'reads: '.$count);});
test018('Public page matches individual effective credentials including bindings and expired/foreign candidates',function()use($rows){foreach($rows as $r){assert17($r===L\Connections::public(L\Connections::get($r['id'])));}});
test018('Secrets are absent from all projected rows',function()use($rows){assert17(!str_contains(wp_json_encode($rows),'SANITIZED-'));});
test018('A pending OAuth candidate is visible only to its current owner and before expiry',function()use($rows){$by=array_column($rows,null,'id');assert17(is_array($by['list018-00']['authorization_pending'])&&$by['list018-01']['authorization_pending']===null&&$by['list018-02']['authorization_pending']===null);});
test018('Two real REST/ability-domain pages have no gaps or duplicate ids',function(){ $a=api17('list-connections',[]);$b=api17('list-connections',['offset'=>$a['next_offset']]);$ids=array_column(array_merge($a['connections'],$b['connections']),'id');$target=array_values(array_filter($ids,fn($id)=>str_starts_with($id,'list018-')));assert17(count($target)===57&&count(array_unique($target))===57&&$b['next_offset']===null);});
test018('Non-admin cannot enumerate connections',function(){wp_set_current_user(0);try{$r=L\Api::dispatch('list-connections');assert17(!$r['success']);}finally{wp_set_current_user(1);}});
if(!$baseline)foreach(['token','client_secret','refresh_token'] as $field)test018('Replace and remove '.$field.' fails before provider or persistence',function()use($field){
 $id='list018-00';$before=L\Store::get('connection',$id);$http=count($GLOBALS['calls17']);$r=L\Api::dispatch('save-connection',['connection_id'=>$id,'expected_revision'=>$before['revision'],$field=>'SANITIZED-new','clear_'.$field=>true]);assert17(!$r['success']&&$r['code']==='invalid_input');assert17(count($GLOBALS['calls17'])===$http&&$before===L\Store::get('connection',$id));
});
test018('Empty page reads zero rows and produces no continuation',function(){assert17(L\Connections::list(9999,10)===[]);});
if(!$baseline){
 foreach([['document'=>'../wp-config.php'],['document'=>'https://example.test/x']] as $i)test018('Documentation rejects '.$i['document'],function()use($i){$r=L\Api::dispatch('documentation',$i);assert17(!$r['success']&&$r['code']==='not_found');});
 test018('Changed document revision is rejected before returning content',function(){$r=L\Api::dispatch('documentation',['document'=>'PRIMEIROS-PASSOS.md','offset'=>256,'expected_revision'=>str_repeat('0',64)]);assert17(!$r['success']&&$r['code']==='revision_conflict');});
}
$r=['version'=>L\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($v)=>!$v['passed'])),'page_rows'=>count($rows),'connection_table_selects'=>$count];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/configuration018.json',wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($r)."\n";exit($r['failed']?1:0);
