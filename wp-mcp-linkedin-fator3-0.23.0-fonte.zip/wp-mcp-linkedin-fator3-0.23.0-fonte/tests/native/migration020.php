<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
use Fator3\LinkedIn as L;
global $wpdb;$base=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline020.json'),true);$rows=$wpdb->get_results("SELECT bucket,record_key,revision,payload,expires_at,queue_state,queue_next FROM ".L\Store::table()." WHERE bucket IN ('connection','grant','token_proof','credential','mutation','settings','job','lead_scan','schedule','validation_proof','audit') ORDER BY bucket,record_key",ARRAY_A);
$checks=['base_target'=>$base['version']==='0.19.0'&&L\Config::VERSION==='0.20.0','records_and_revisions'=>$base['count']>=7&&hash('sha256',serialize($rows))===$base['digest'],'paused_cursor'=>L\Store::get('job','paused019')['value']['cursor']==='fixture-cursor'&&L\Store::get('job','paused019')['value']['status']==='paused','uncertain_receipt'=>L\Store::get('mutation',str_repeat('a',64))['value']['state']==='uncertain','policy'=>L\Retention::get()['audit_days']===45];
$before=L\Store::get('connection','legacy-empty');$status=L\Api::dispatch('status');
$checks['legacy_invalid_diagnosed']=in_array('connection_without_token',array_column($status['data']['issues']??[],'code'),true);
$checks['no_silent_repair']=$before===L\Store::get('connection','legacy-empty')&&!empty($before['value']['enabled']);
$checks['schedule_preserved']=!L\Store::get('schedule','paused-schedule')['value']['enabled'];
$r=['total'=>count($checks),'failed'=>count(array_filter($checks,fn($ok)=>!$ok)),'records'=>count($rows),'checks'=>$checks];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/migration020.json',wp_json_encode($r));echo wp_json_encode($r)."\n";exit($r['failed']?1:0);
