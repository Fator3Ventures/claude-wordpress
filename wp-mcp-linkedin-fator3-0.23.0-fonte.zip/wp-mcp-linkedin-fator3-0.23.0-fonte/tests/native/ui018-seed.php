<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);use Fator3\LinkedIn as L;
// Names sort after the real fixture; the last connection is available only on page two.
for($n=1;$n<=55;$n++){$id=sprintf('z018-%02d',$n);L\Store::put('connection',$id,['id'=>$id,'label'=>'Equipe '.$n,'enabled'=>false,'expires_at'=>0,'token'=>'','client_id'=>'','client_secret'=>'','users'=>[1],'api_version'=>'202609','assets'=>['ads'=>['222'],'leads'=>[],'pages'=>[]]],0);}
