<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);use Fator3\LinkedIn as L;
for($n=1;$n<=53;$n++){L\Store::put('mutation',str_pad(dechex($n),64,'0',STR_PAD_LEFT),['operation'=>'create-campaign-group','connection_id'=>'ui','principal'=>L\Access::principal(),'kind'=>'campaign-group','input'=>['account_id'=>'222'],'state'=>$n<3?'uncertain':'confirmed','created_at'=>1793592000+$n,'remote_effect'=>$n<3?'unknown':'confirmed','remote_id'=>$n<3?null:'999','desired'=>['body'=>'PRIVATE_JOURNAL_BODY<script>not-executable</script>'],'before'=>null,'after'=>null],0);}
