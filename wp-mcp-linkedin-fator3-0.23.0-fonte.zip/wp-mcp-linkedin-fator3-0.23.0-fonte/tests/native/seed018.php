<?php
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;
assert17(L\Config::VERSION==='0.17.1');
$reader=setup17('upgrade018','consumer018','1.2.0');
L\Store::put('job','paused018',['status'=>'paused','query'=>['connection_id'=>'upgrade018'],'cursor'=>'fixture-cursor','pages'=>3,'rows'=>18,'principal'=>L\Access::principal()],0);
L\Store::put('lead_scan','resume018',['next_at'=>time()+86400,'offset'=>4,'connection_id'=>'upgrade018'],0);
L\Store::put('mutation',str_repeat('a',64),['state'=>'uncertain','connection_id'=>'upgrade018','operation'=>'create-campaign-group','principal'=>L\Access::principal()],0);
L\Retention::save(['expected_revision'=>0,'audit_mode'=>'finite','audit_days'=>45,'dry_run'=>false]);
global $wpdb;$rows=$wpdb->get_results("SELECT bucket,record_key,revision,payload,expires_at,queue_state,queue_next FROM ".L\Store::table()." WHERE bucket IN ('connection','grant','token_proof','credential','mutation','settings','job','lead_scan') ORDER BY bucket,record_key",ARRAY_A);
file_put_contents(getenv('F3_LAB_ROOT').'/baseline018.json',wp_json_encode(['version'=>L\Config::VERSION,'count'=>count($rows),'digest'=>hash('sha256',serialize($rows))]));
