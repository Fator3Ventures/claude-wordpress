<?php
/** Run by the immutable 0.15.0 before replacement, exclusively in a disposable local lab. */
require __DIR__.'/seed0140.php';
use Fator3\LinkedIn as L;
if(L\Config::VERSION!=='0.15.0')throw new RuntimeException('Expected accepted 0.15.0');
$c=L\Connections::get('legacy14');
$catalog=['connection_id'=>'legacy14','account_id'=>'222','forms'=>['8333'=>['id'=>'8333','version'=>'1','created_at_ms'=>'1793500000000']],'updated_at'=>time()];
L\Store::put('lead_catalog','legacy14:222',$catalog,0);
L\PublicApi::register_consumer(['id'=>'upgrade0160','label'=>'Upgrade fixture','contract'=>'linkedin-lead-reader/1.2.0']);
L\Store::put('grant','upgrade0160:legacy14',['enabled'=>true,'connection_id'=>'legacy14','consumer_id'=>'upgrade0160','credential_revision'=>$c['revision'],'permissions'=>['metadata','responses'],'forms'=>['222'=>['8333']],'all_forms_accounts'=>[],'principal'=>L\Access::principal()],0);
L\Store::put('lead_form_event','fixture:000000000001',['event_id'=>'fixture:000000000001','sequence'=>1,'connection_id'=>'legacy14','account_id'=>'222','form_id'=>'8333','state'=>'confirmed'],0);
L\Store::put('subscription',str_repeat('f',64),['state'=>'confirmed','remote_id'=>'555','consumer'=>'upgrade0160','connection_id'=>'legacy14','credential_revision'=>$c['revision'],'wanted'=>['owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:222'],'versionedForm'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:8333,1)']],0);
$tables=[];foreach([L\Store::table(),L\History::table()] as $table){$rows=$wpdb->get_results('SELECT * FROM '.$table.' ORDER BY 1',ARRAY_A);$tables[$table]=['rows'=>count($rows),'sha256'=>hash('sha256',serialize($rows))];}
$cron=[];foreach(['f3_linkedin_worker','f3_linkedin_maintenance','f3_linkedin_lead_discovery'] as $hook)$cron[$hook]=wp_next_scheduled($hook);
file_put_contents(getenv('F3_LAB_ROOT').'/baseline0160.json',wp_json_encode(['version'=>L\Config::VERSION,'tables'=>$tables,'cron'=>$cron,'connection'=>L\Connections::public($c),'retention'=>L\Retention::get()]));
