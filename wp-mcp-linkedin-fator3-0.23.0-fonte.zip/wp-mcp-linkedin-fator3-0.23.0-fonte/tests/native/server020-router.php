<?php
// Only the ephemeral CLI loopback server for server020.php uses this test router.
if(PHP_SAPI!=='cli-server'||!str_starts_with($_SERVER['REMOTE_ADDR']??'','127.')||!getenv('F3_LAB_ID')){http_response_code(403);exit;}
$_SERVER['HTTPS']='on';$_SERVER['SERVER_PORT']=443;
require getenv('F3_LAB_ROOT').'/wordpress/index.php';
