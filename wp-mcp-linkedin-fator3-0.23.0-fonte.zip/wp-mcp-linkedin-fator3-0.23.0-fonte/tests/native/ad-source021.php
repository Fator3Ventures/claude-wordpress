<?php
declare(strict_types=1);
require __DIR__.'/fixtures017.php';require __DIR__.'/ad-source021-fixtures.php';
use Fator3\LinkedIn as L;
use Fator3\McpFiles as M;
$lab=getenv('F3_LAB_ROOT');assert17(json_decode(file_get_contents($lab.'/.social-lab.json'),true)['id']===getenv('F3_LAB_ID'));
$checks=[];function test21($name,$condition){global $checks;$checks[$name]=(bool)$condition;}
$uuid='11111111-2222-4333-8444-555555555555';$consumer='site-core-li-'.str_replace('-','',$uuid);
if(class_exists('F3Base_Linkedin_Cliente')){
 $cfg=array_replace(F3Base_Linkedin_Integracoes::padrao(),['uuid'=>$uuid,'connection_id'=>'origin21','conta_id'=>'222','ativo'=>true,'cliente'=>'linkedin_plugin']);
 global $wpdb;$wpdb->replace($wpdb->options,['option_name'=>F3Base_Linkedin::OPCAO,'option_value'=>maybe_serialize(['integracoes'=>['example'=>$cfg]]),'autoload'=>'no']);wp_cache_delete(F3Base_Linkedin::OPCAO,'options');wp_cache_delete('alloptions','options');F3Base_Linkedin_Cliente::registrar();
}
$reader=setup17('origin21',$consumer);$in=['connection_id'=>'origin21','account_id'=>'222'];
$creative=$in+['creative_id'=>'777'];$lead=$in+['form_id'=>'8331','response_id'=>'response_1'];$op='lead-resolve-ad-source';
remove_all_filters('pre_http_request');add_filter('pre_http_request','fixture21',PHP_INT_MAX,3);
$go=function($mode,$i=null)use($op,$creative){$GLOBALS['f21mode']=$mode;$GLOBALS['f21calls']=[];return L\Api::dispatch($op,$i??$creative);};
$grant=['connection_id'=>'origin21','consumer_id'=>$consumer,'expected_revision'=>1,'enabled'=>true,'permissions'=>['ad_source','responses'],'forms'=>['222'=>['8331']]];
$r=$reader->resolve_ad_source($creative);test21('old grant denied before HTTP',$r['code']==='not_authorized'&&empty($GLOBALS['f21calls']));
$p=api17('save-grant',$grant+['dry_run'=>true]);$r=L\Api::dispatch('save-grant',$grant);test21('new permission requires explicit confirmation',$r['code']==='simulation_required');
api17('save-grant',$grant+['confirmation'=>$p['confirmation']]);
$r=$go('article');$a=$r['data']['ad_source']??[];test21('one input call projects verified account, creative, campaign and post',($a['contract']??'')===L\AdSource::CONTRACT&&$a['creative_id']==='777'&&$a['creative_name']==='Anúncio A'&&$a['campaign_id']==='999'&&$a['campaign_name']==='Campanha A'&&$a['post_urn']==='urn:li:share:444');
test21('article text title description button and destination',($a['text']??null)==='Texto'&&$a['title']==='Título'&&$a['description']==='Descrição'&&$a['button']==='LEARN_MORE'&&$a['destination_url']==='https://example.org/landing');
test21('image URL and thumbnail share the real validity',($a['media_type']??null)==='image'&&$a['content_type']==='article'&&$a['media']===$a['thumbnail']&&$a['media']['expires_at_ms']>time()*1000&&str_starts_with($a['media']['url'],'https://media.licdn.com/'));
test21('campaign manager, post and native form links separately identified',($a['campaign_manager_url']??'')==='https://www.linkedin.com/campaignmanager/accounts/222/campaigns/999/creatives'&&$a['post_url']==='https://www.linkedin.com/feed/update/urn:li:share:444/'&&$a['lead_form_urn']==='urn:li:adForm:8331');
test21('four metadata GETs only; never downloads media',count($GLOBALS['f21calls'])===4&&array_unique(array_column($GLOBALS['f21calls'],0))===['GET']);
$r=$go('video')['data']['ad_source'];test21('video and thumbnail have independent URLs and expirations',$r['media_type']==='video'&&$r['media']['url']!==$r['thumbnail']['url']&&$r['thumbnail']['expires_at_ms']>0&&$r['media']['expires_at_ms']>$r['thumbnail']['expires_at_ms']);
$r=$go('video-no-expiry')['data']['ad_source'];test21('unknown thumbnail validity remains null',$r['thumbnail']['url']!==null&&$r['thumbnail']['expires_at_ms']===null);
foreach(['expired','unsafe-cdn','processing','no-media','no-post'] as $mode){$r=$go($mode);test21('no usable link for '.$mode,$r['success']&&$r['data']['ad_source']['media']['url']===null);}
foreach(['foreign-account','foreign-campaign','wrong-post','wrong-dsc','wrong-media-id','foreign-owner'] as $mode){$r=$go($mode);test21('reject unrelated resource: '.$mode,$r['code']==='ad_source_binding_invalid'&&empty($r['data']));}
$r=$go('denied');test21('supplier deny retained',$r['code']==='asset_access_denied');
$r=$go('article',$lead);test21('authorized native lead returns same projection with no personal payload',$r['success']&&$r['data']['ad_source']['creative_id']==='777'&&count($GLOBALS['f21calls'])===5&&!str_contains(wp_json_encode($r),'formResponse'));
foreach(['wrong-lead'=>'ad_source_binding_invalid','missing-creative'=>'ad_source_not_associated','wrong-campaign-ref'=>'ad_source_binding_invalid'] as $m=>$code){test21($m,$go($m,$lead)['code']===$code);}
foreach([$in,$creative+['form_id'=>'8331','response_id'=>'response_1'],$in+['form_id'=>'8331'],$creative+['page_id'=>'111']] as $n=>$v){$r=$go('article',$v);test21('malformed input '.$n,$r['code']==='invalid_input'&&count($GLOBALS['f21calls'])===0);}
$r=$go('article',array_replace($creative,['account_id'=>'333']));test21('nonselected account before HTTP',$r['code']==='asset_access_denied'&&!$GLOBALS['f21calls']);
$GLOBALS['f21mode']='article';$r=$reader->resolve_ad_source($lead);test21('granted native SDK source',$r['success']&&$r['data']['ad_source']['creative_id']==='777');
$r=$reader->resolve_ad_source(array_replace($lead,['form_id'=>'8332']));test21('consumer limited to granted form',$r['code']==='asset_access_denied');
$GLOBALS['f21calls']=[];$r=$reader->resolve_ad_source($creative+['grant_revision'=>1]);test21('stale grant revision before sending',!$r['success']&&!$GLOBALS['f21calls']);
if(class_exists('F3Base_Linkedin_Cliente')){

 $r=F3Base_Linkedin_Integracoes::executar('example',static fn()=>F3Base_Linkedin_Cliente::chamar('resolve_ad_source',['creative_id'=>'777']));
 if(defined('F3_CORE_FRONTIER_021')){
    $split=F3Base_Linkedin_Integracoes::executar('example',static fn()=>F3Base_Linkedin_Cliente::origem_anuncio(['form_id'=>'8331','response_id'=>'response_1']));
    test21('experimental consumer handles native form and separates temporary addresses',!empty($split['ok'])&&$split['origem']['creative_id']==='777'&&!str_contains(wp_json_encode($split['origem']),'synthetic_signature_21')&&str_contains($split['midia_temporaria']['media']['url']??'','synthetic_signature_21'));
 }
 test21('official Site Core client gives verified source through its selected integration',!empty($r['ok'])&&$r['data']['ad_source']['creative_name']==='Anúncio A');
}
if(class_exists(M\ConnectionContext::class)){
 $gid='qa21_'.bin2hex(random_bytes(8));M\Persistence::put('oauth-grants',$gid,['grant_id'=>$gid,'user_id'=>1,'client_id'=>'qa21','profile'=>'maintenance','status'=>'active']);
 try{M\ConnectionContext::oauth(['user_id'=>1,'grant_id'=>$gid,'client_id'=>'qa21','profile'=>'maintenance']);
 $mr=\WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::execute(['ability_name'=>'linkedin/'.$op,'parameters'=>$creative]);$a=$mr['data']['data']['ad_source']??[];
 test21('MCP native executor returns temporary URL and types',is_string($a['media']['url']??null)&&str_contains($a['media']['url'],'synthetic_signature_21')&&is_int($a['media']['expires_at_ms'])&&$a['media_links_temporary']===true);
 }finally{M\Persistence::delete('connections','grant:'.$gid);M\Persistence::delete('oauth-grants',$gid);M\ConnectionContext::restore_identity(null,1);}
}
$sub=wp_create_user('readonly21',wp_generate_password());wp_set_current_user($sub);$r=$go('article');test21('subscriber refused before HTTP',$r['code']==='not_authorized'&&!$GLOBALS['f21calls']);wp_set_current_user(1);
$GLOBALS['f21mode']='article';$GLOBALS['f21calls']=[];$GLOBALS['f21hook']=static function($path)use($consumer){if(str_contains($path,'/creatives/')){$g=L\Store::get('grant',$consumer.':origin21');$g['value']['enabled']=false;L\Store::put('grant',$consumer.':origin21',$g['value'],$g['revision']);}};
$r=$reader->resolve_ad_source($creative);test21('revoked mid-read stops before campaign and withholds result',!$r['success']&&count($GLOBALS['f21calls'])===1&&empty($r['data']));
global $wpdb;$seen=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".L\Store::table()." WHERE CONVERT(payload USING utf8mb4) LIKE '%synthetic_signature_21%'");
test21('no plaintext signed URLs stored in plugin table',$seen===0);
$out=['checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($v)=>!$v))];file_put_contents($lab.'/evidence/ad-source021.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out)."\n";exit((int)($out['failed']>0));
