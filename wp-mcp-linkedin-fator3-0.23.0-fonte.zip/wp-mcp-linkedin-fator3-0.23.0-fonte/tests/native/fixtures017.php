<?php
/** Strict, synthetic provider boundary. No network or commercial identities. */
require_once getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
use Fator3\LinkedIn as L;
$GLOBALS['mode17']='normal';$GLOBALS['calls17']=[];$GLOBALS['remote17']=[];$GLOBALS['race17']=null;
function assert17($ok,$message='assertion'){if(!$ok)throw new RuntimeException($message);}
function result17($body,$http=200,$headers=[]){return ['response'=>['code'=>$http],'body'=>wp_json_encode($body),'headers'=>$headers,'cookies'=>[]];}
function api17($op,$input){$r=L\Api::dispatch($op,$input);assert17($r['success'],wp_json_encode($r));return $r['data'];}
function save17($i,$flags=[]){$p=api17('save-connection',$i+['dry_run'=>true]);return api17('save-connection',$i+['confirmation'=>$p['confirmation']]+$flags);}
function lead17($id='lead17') {return ['id'=>$id,'responseId'=>'tracking17','leadType'=>'SPONSORED','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:222'],'versionedLeadGenFormUrn'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:8331,1)','leadMetadata'=>['sponsoredLeadMetadata'=>['campaign'=>'urn:li:sponsoredCampaign:999']],'submittedAt'=>'1793600000000','testLead'=>true,'formResponse'=>['answers'=>[['questionId'=>1,'answerDetails'=>['textQuestionAnswer'=>['answer'=>' fixture ']]]],'consentResponses'=>[['consentId'=>2,'response'=>true]]]];}
add_filter('pre_http_request',function($pre,$args,$url){
 $path=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);$mode=$GLOBALS['mode17'];$GLOBALS['calls17'][]=['path'=>$path,'query'=>$q,'method'=>$args['method']];if($GLOBALS['race17'])($GLOBALS['race17'])($path,$q);
 if(str_ends_with($path,'introspectToken')){parse_str($args['body'],$candidate);return result17(['active'=>true,'client_id'=>$candidate['client_id'],'expires_at'=>time()+86400,'scope'=>implode(',',array_merge(L\ConnectionChanges::READ_SCOPES,['rw_ads','rw_conversions','r_marketing_leadgen_automation','openid']))]);}
 if(str_ends_with($path,'/userinfo'))return result17(['sub'=>'fixture-member17','name'=>'Fixture']);
 if(str_ends_with($path,'/adAccountUsers'))return result17(['elements'=>[['account'=>'urn:li:sponsoredAccount:222','role'=>'ACCOUNT_MANAGER']],'paging'=>['start'=>0,'total'=>1]]);
 if(preg_match('~/conversions/(900[12])$~',$path,$m))return result17(['id'=>(int)$m[1],'account'=>'urn:li:sponsoredAccount:222','enabled'=>true,'conversionMethod'=>'CONVERSIONS_API','name'=>'Synthetic rule']);
 if(str_contains($path,'/leadFormResponses')){
  assert17(($args['headers']['LinkedIn-Version']??'')==='202609','wire API version');
  if($mode==='projection_rejected'&&isset($q['fields'])||$mode==='always_projection')return result17(['message'=>"Projected field 'optionalMetadata' not present in schema 'LeadFormResponse'",'status'=>400],400);
  if(preg_match('/^http(\d+)$/',$mode,$m))return result17(['message'=>'Generic provider refusal','status'=>(int)$m[1]],(int)$m[1]);
  if($mode==='timeout')return new WP_Error('fixture_timeout','No response');
  $v=lead17();if($mode==='foreign')$v['owner']['sponsoredAccount']='urn:li:sponsoredAccount:333';
  if(isset($q['fields'])){
   $expected='id,responseId,leadType,owner,submitter,versionedLeadGenFormUrn,leadMetadata,associatedEntity,submittedAt,testLead,formResponse,leadMetadataInfo:(sponsoredLeadMetadataInfo:(campaign:(id,name)))';
   assert17($q['fields']===$expected,'strict documented projection');
   $v['leadMetadataInfo']=['sponsoredLeadMetadataInfo'=>['campaign'=>['id'=>'urn:li:sponsoredCampaign:999','name'=>'Synthetic campaign']]];
  }
  if(str_ends_with($path,'/leadFormResponses'))return result17(['elements'=>[$v],'paging'=>['start'=>(int)($q['start']??0),'count'=>50,'total'=>$mode==='projection_rejected'?51:1]]);
  return result17($v);
 }
 if(str_ends_with($path,'/adAccounts/222/adCampaigns/999'))return result17(['id'=>999,'account'=>'urn:li:sponsoredAccount:222','name'=>'Campaign API']);
 if(str_ends_with($path,'/leadForms')){$forms=[];for($n=1;$n<=($mode==='many_forms'?7:4);$n++)$forms[]=['id'=>8330+$n,'versionId'=>1,'created'=>1793500000000,'owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:222']];$start=(int)($q['start']??0);$count=(int)($q['count']??50);return result17(['elements'=>array_slice($forms,$start,$count),'paging'=>['start'=>$start,'count'=>$count,'total'=>count($forms)]]);}
 if(str_ends_with($path,'/leadNotifications')){
  if($args['method']==='POST'){$want=json_decode($args['body'],true);preg_match('/leadGenForm:(\d+),/',$want['versionedForm'],$m);$id=(string)(1000+(int)$m[1]);$GLOBALS['remote17'][$id]=$want+['id'=>$id];return result17([],201,['x-restli-id'=>$id]);}
  return result17(['elements'=>array_values($GLOBALS['remote17']),'paging'=>['start'=>0,'total'=>count($GLOBALS['remote17'])]]);
 }
 if(preg_match('~/leadNotifications/(\d+)$~',$path,$m)){if($args['method']==='DELETE'){unset($GLOBALS['remote17'][$m[1]]);return result17([],204);}return isset($GLOBALS['remote17'][$m[1]])?result17($GLOBALS['remote17'][$m[1]]):result17(['message'=>'Not found'],404);}
 if(str_contains($path,'adCampaignGroups'))return result17(['message'=>'Invalid field','status'=>422],422);
 return new WP_Error('unexpected_fixture_request',$path);
},PHP_INT_MAX,3);
function setup17($id='qa017',$consumer='reader17',$contract='1.2.0'){
 api17('save-connection',['connection_id'=>$id,'expected_revision'=>0,'token'=>str_repeat('synthetic17',15),'client_id'=>'fixture17','client_secret'=>'fixture-secret17','application_id'=>'1717','assets'=>['ads'=>['222'],'leads'=>['222'],'pages'=>['111']],'forms'=>['222'=>['8331','8332','8333','8334']]]);
 L\PublicApi::register_consumer(['id'=>$consumer,'label'=>'Synthetic 17','contract'=>'linkedin-lead-reader/'.$contract]);
 api17('save-grant',['connection_id'=>$id,'consumer_id'=>$consumer,'expected_revision'=>0,'enabled'=>true,'permissions'=>['metadata','responses','verify','subscriptions'],'forms'=>['222'=>['8331','8332','8333','8334']],'callback_url'=>'https://example.com/lead17']);
 return L\PublicApi::lead_reader($consumer);
}
