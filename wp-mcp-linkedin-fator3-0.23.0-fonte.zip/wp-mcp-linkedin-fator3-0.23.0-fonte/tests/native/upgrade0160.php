<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
use Fator3\LinkedIn as L;
$b=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline0160.json'),true);$checks=[];global $wpdb;
foreach($b['tables'] as $table=>$old){$rows=$wpdb->get_results('SELECT * FROM '.$table.' ORDER BY 1',ARRAY_A);$checks[]=['name'=>'byte-identical persisted table '.$table,'passed'=>count($rows)===$old['rows']&&hash('sha256',serialize($rows))===$old['sha256']];}
$checks[]=['name'=>'connection and selection unchanged','passed'=>L\Connections::public(L\Connections::get('legacy14'))===$b['connection']];
$checks[]=['name'=>'retention unchanged','passed'=>L\Retention::get()===$b['retention']];
$g=L\Store::get('grant','upgrade0160:legacy14');$checks[]=['name'=>'no implicit campaign permission','passed'=>!in_array('campaign_lookup',$g['value']['permissions'],true)&&$g['revision']===1];
foreach($b['cron'] as $hook=>$at)$checks[]=['name'=>'cron preserved '.$hook,'passed'=>wp_next_scheduled($hook)===$at];
$checks[]=['name'=>'direct 0.15.0 to 0.16.0','passed'=>$b['version']==='0.15.0'&&L\Config::VERSION==='0.16.0'];
$checks[]=['name'=>'existing acquisition and commercial identities remain valid','passed'=>L\ServiceAudit::introspect(L\Store::get('conversion_event',hash('sha256','baseline012-confirmed'))['value']['service_identity'])['valid']&&L\ServiceAudit::introspect(L\Store::get('conversion_event',hash('sha256','baseline0130-stage-confirmed'))['value']['service_identity'])['valid']];
$out=['total'=>count($checks),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed'])),'checks'=>$checks];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/upgrade0160.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out)."\n";exit($out['failed']?1:0);
