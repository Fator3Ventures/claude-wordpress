<?php
// Disposable WordPress lab only; no remote LinkedIn calls.
add_filter('pre_http_request',static function($pre,$args,$url){
 if($pre!==false||!str_contains($url,'api.linkedin.com'))return $pre;
 $path=parse_url($url,PHP_URL_PATH);if(!str_ends_with($path,'/adTargetingEntities'))return $pre;
 parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);
 $body=['elements'=>[['facetUrn'=>$q['facet']??'', 'name'=>$q['query']??'Cidade','urn'=>'urn:li:geo:1000']],'paging'=>['start'=>0,'count'=>100,'total'=>1]];
 return ['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>200,'message'=>'Synthetic targeting'],'cookies'=>[]];
},15,3);
