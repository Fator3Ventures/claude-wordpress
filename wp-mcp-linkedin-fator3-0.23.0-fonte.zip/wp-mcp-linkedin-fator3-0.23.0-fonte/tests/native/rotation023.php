<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
require __DIR__.'/rotation023-cases.php';
$r=\Fator3\LinkedIn\QA023\run();file_put_contents(getenv('F3_LAB_ROOT').'/evidence/rotation023.json',wp_json_encode($r,JSON_PRETTY_PRINT));echo wp_json_encode($r)."\n";exit($r['failed']?1:0);
