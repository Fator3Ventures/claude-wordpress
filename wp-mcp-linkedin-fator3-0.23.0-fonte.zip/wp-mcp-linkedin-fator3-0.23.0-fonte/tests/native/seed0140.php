<?php
require __DIR__.'/seed0130.php';
\Fator3\LinkedIn\Store::put('credential_health','legacy14',['incident'=>['code'=>'identity_change_required','opened_at'=>time()-3600,'last_at'=>time()-30],'notices'=>['refresh_failure:123'=>['at'=>time()-60,'sent'=>true]],'failures'=>2],\Fator3\LinkedIn\Store::get('credential_health','legacy14')['revision']??0);
$b=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline0130.json'),true);foreach($b['tables'] as $table=>&$summary){$rows=$wpdb->get_results('SELECT * FROM '.$table.' ORDER BY 1',ARRAY_A);$summary=['rows'=>count($rows),'sha256'=>hash('sha256',serialize($rows))];}unset($summary);$b['health']=\Fator3\LinkedIn\Store::get('credential_health','legacy14');file_put_contents(getenv('F3_LAB_ROOT').'/baseline0130.json',wp_json_encode($b));
