<?php
/** Seed real base 0.14.0; no production records or HTTP. */
require __DIR__.'/seed0140.php';
use Fator3\LinkedIn as L;
if(L\Config::VERSION!=='0.14.0')throw new RuntimeException('Expected accepted 0.14.0');
$common=['operation'=>'create-campaign-group','connection_id'=>'legacy14','principal'=>L\Access::principal(),'request_hash'=>str_repeat('a',64),'kind'=>'campaign-group','verb'=>'create','input'=>['connection_id'=>'legacy14','account_id'=>'222'],'before'=>['id'=>'222'],'desired'=>['name'=>'Synthetic legacy','account'=>'urn:li:sponsoredAccount:222','status'=>'DRAFT'],'path'=>'adAccounts/222/adCampaignGroups','method'=>'POST','state'=>'uncertain','created_at'=>time()-100,'remote_id'=>null,'remote_effect'=>'unknown','after'=>null];
foreach(['upstream_validation','token_rejected','asset_access_denied','resource_not_found','upstream_error','operation_uncertain'] as $code)L\Store::put('mutation',hash('sha256','legacy15-'.$code),$common+['last_code'=>$code],0);
$reported=$common;$reported['connection_id']='linkedin-cto-office';$reported['input']=['connection_id'=>'linkedin-cto-office','account_id'=>'558431216'];$reported['desired']['name']='TESTE FROTA 92f - rascunho a apagar (01/11)';$reported['last_code']='upstream_error';L\Store::put('mutation','ea7838f5'.str_repeat('0',56),$reported,0);
$known=$reported;$known['desired']['runSchedule']=['start'=>1793660400000];$known['last_code']='asset_access_denied';L\Store::put('mutation','66c4c78e'.str_repeat('0',56),$known,0);
$proven=$common;$proven['last_code']='upstream_validation';$proven['last_error']=['http_status'=>422,'creation_rejected'=>true,'provider_message'=>'Invalid field'];L\Store::put('mutation',hash('sha256','legacy15-proven'),$proven,0);
$copy=$common;$copy['remote_id']='999';$copy['last_code']='asset_access_denied';L\Store::put('mutation',hash('sha256','legacy15-receipt'),$copy,0);
$records=[];foreach($wpdb->get_results('SELECT * FROM '.L\Store::table().' ORDER BY bucket,record_key',ARRAY_A) as $row)if($row['bucket']!=='mutation')$records[]=['bucket'=>$row['bucket'],'key'=>$row['record_key'],'sha256'=>hash('sha256',serialize($row))];
file_put_contents(getenv('F3_LAB_ROOT').'/baseline0150.json',wp_json_encode(['version'=>L\Config::VERSION,'records'=>$records,'connection'=>L\Connections::public(L\Connections::get('legacy14'))]));
