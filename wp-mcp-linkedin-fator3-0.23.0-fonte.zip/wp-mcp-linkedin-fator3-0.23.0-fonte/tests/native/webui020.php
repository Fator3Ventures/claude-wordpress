<?php
declare(strict_types=1);
// Opt-in, disposable WP laboratory only. No credentials, browser or fixtures ship in the installer.
$lab=getenv('F3_LAB_ROOT');
$owner=$lab?json_decode((string)@file_get_contents($lab.'/.social-lab.json'),true):null;
if(!$owner || !getenv('F3_LAB_ID') || $owner['id']!==getenv('F3_LAB_ID'))throw new RuntimeException('Owned laboratory required');
if(!is_executable((string)getenv('F3_CHROME_HEADLESS_SHELL')))throw new RuntimeException('Set F3_CHROME_HEADLESS_SHELL to the verified local browser executable');
require $lab.'/wordpress/wp-load.php';wp_set_current_user(1);
$mu=ABSPATH.'wp-content/mu-plugins';wp_mkdir_p($mu);
$cmd=json_decode((string)getenv('F3_LAB_PHP'),true);
$run=static function(array $argv): int {
    $process=proc_open($argv,[0=>['pipe','r'],1=>STDOUT,2=>STDERR],$pipes);if(!is_resource($process))throw new RuntimeException('Failed to start test child');
    fclose($pipes[0]);return proc_close($process);
};
$installed=[];$server=null;
try {
    foreach(['ui-fixtures.php','ui0150-fixtures.php'] as $file){
        if(file_exists("$mu/$file")||!copy(__DIR__."/$file","$mu/$file"))throw new RuntimeException('Cannot install owned browser fixture');
        $installed[]="$mu/$file";
    }
    $socket=stream_socket_server('tcp://127.0.0.1:0',$errno,$err);
    if(!$socket)throw new RuntimeException('Cannot reserve loopback port');
    $address=stream_socket_get_name($socket,false);fclose($socket);
    putenv('F3_UI_URL=http://'.$address);putenv('F3_UI_PASSWORD='.bin2hex(random_bytes(24)));
    foreach(['ui-init.php','ui018-seed.php'] as $file)
        if($run(array_merge($cmd,[__DIR__."/$file"]))!==0)throw new RuntimeException('Browser fixture initialization failed');
    $server=proc_open(array_merge($cmd,['-S',$address,'-t',ABSPATH,__DIR__.'/router.php']),[0=>['pipe','r'],1=>['file',$lab.'/private/webui-server.log','a'],2=>['file',$lab.'/private/webui-server.log','a']],$pipes);
    if(!is_resource($server))throw new RuntimeException('Cannot start loopback server');
    fclose($pipes[0]);$ready=false;
    for($i=0;$i<80;$i++){
        $client=@fsockopen('127.0.0.1',(int)substr(strrchr($address,':'),1),$errno,$err,.1);
        if($client){fclose($client);$ready=true;break;}usleep(50000);
    }
    if(!$ready)throw new RuntimeException('Loopback server did not start');
    $status=$run(['python3',dirname(__DIR__).'/browser/layout020.py']);
}finally{
    if(is_resource($server)){proc_terminate($server);proc_close($server);}
    foreach($installed as $file)unlink($file);
}
exit($status);
