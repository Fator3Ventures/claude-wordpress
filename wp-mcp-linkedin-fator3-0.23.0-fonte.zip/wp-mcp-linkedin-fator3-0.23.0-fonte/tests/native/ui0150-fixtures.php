<?php
// Disposable laboratory only. Never copied to the released runtime.
add_action('f3_linkedin_register_consumers',static function($api){$api::register_consumer(['id'=>'ui-auto','label'=>'Consumidor automático sintético','contract'=>'linkedin-lead-reader/1.2.0']);});
add_filter('http_request_host_is_external',static fn($external,$host)=>$host==='127.0.0.1'?true:$external,10,2);
