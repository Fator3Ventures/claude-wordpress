"""Create deliberately incorrect installers ONLY inside a new temp directory, for lab.py --candidate."""
from pathlib import Path
import zipfile,json,sys,hashlib
root=Path(__file__).resolve().parents[2]; path=root/'build/dist/wp-mcp-linkedin-fator3-0.20.0-instalador.zip'
folder=Path(sys.argv[1]).resolve()
if folder==root or root in folder.parents:raise SystemExit('Use a new external QA directory')
folder.mkdir(exist_ok=False,parents=True);prefix='wp-mcp-linkedin-fator3/'
cases={'guard':('includes/ConnectionChanges.php',"if($c['enabled'] && $c['token']==='')","if($changed && $c['enabled'] && $c['token']==='')"),
       'audit':('includes/Api.php',"return !self::exempt($op) && (empty","return $op==='status' || !self::exempt($op) && (empty"),
       'transport':('includes/Api.php',"'blank_keeps_existing'=>true","'secret_blank_keeps_existing'=>true"),
       'docrevision':('includes/Documentation.php','Para continuar, informe expected_revision com a revisão da primeira página.','Documento alterado; reinicie pelo índice.'),
       'checkbox':('assets/admin.css',None,'.f3-social input[type=checkbox]{width:7px!important;height:25px!important;}'),
       'labels':('includes/Admin.php',None,None)}
cases.update({
    'feedback':('assets/admin.js','if(n===actionSequence)msg(text,error);','button.focus();msg(text,error);'),
    'emptylist':('assets/admin.js','Nenhuma concessão de formulários cadastrada neste site.','O LinkedIn não retornou linhas para esta seleção.'),
    # Independent selectors deliberately violate the separate geometric budgets.
    'geometry':('assets/admin.css',None,'''
.f3-social #f3-connection-editor{padding-top:460px!important}
.f3-social #f3-schedule{padding-top:560px!important}
.f3-social .f3-tabs{height:85px!important;max-height:none!important}
.f3-social #f3-query [name=limit]{width:420px!important;max-width:none!important}
.f3-social .f3-field-help,.f3-social .f3-field-doc summary{font-size:8px!important}
.f3-social #f3-connection .f3-field-doc:not([open])>small{display:block!important}
.f3-social .f3-field-doc{display:contents!important}
.f3-social .f3-actions{gap:0!important}
.f3-social .f3-actions button{margin-left:0!important;margin-right:0!important}
.f3-social #f3-message:not(:empty){position:absolute!important;top:0!important}
'''),
})
with zipfile.ZipFile(path) as z: original={n:z.read(n) for n in z.namelist()}
for name,(target,old,new) in cases.items():
    rows=original.copy();k=prefix+target;s=rows[k].decode()
    if name=='labels':
        old="'Nome da agenda'";new="'Nome da conexão'"
    if old:
        assert s.count(old)==1,(name,s.count(old));s=s.replace(old,new)
    else:s+='\n'+new+'\n'
    rows[k]=s.encode()
    m=prefix+'manifest.sha256.json'; manifest=json.loads(rows[m]);manifest[target]=hashlib.sha256(rows[k]).hexdigest()
    rows[m]=(json.dumps(manifest,indent=2)+'\n').encode()
    with zipfile.ZipFile(folder/(name+'.zip'),'w',zipfile.ZIP_DEFLATED) as out:
        for p,b in rows.items():out.writestr(p,b)
