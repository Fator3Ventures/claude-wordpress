"""Mutate an isolated copy of compiled manuals; verify the specific semantic check rejects each drift."""
import hashlib,json,os,re,shutil,subprocess,sys,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];plugin=root/'build/dist/wp-mcp-linkedin-fator3';sys.path.insert(0,str(root/'build/manuals'))
from verify import verify
src=plugin/'docs'; php=os.environ.get('F3_SOCIAL_PHP','php')
reg=json.loads(subprocess.check_output([php,root/'build/manuals/registry.php',plugin]))
v=reg['version']
def replace(l,r):
    def do(s):
        if l not in s:raise RuntimeError('inapplicable mutation '+l)
        return s.replace(l,r)
    return do
def add(t):return lambda s:s+'\n'+t+'\n'
def removehead(s):return re.sub(r'\d+\.\d+\.\d+','',s.splitlines()[0])+'\n'+'\n'.join(s.splitlines()[1:])
checks=[
 ('title missing','title','AGENTS.md',removehead),
 ('title stale','title','AGENTS.md',replace(v,'0.19.0')),
 ('current declaration','current','README.md',replace('A release corrente é ','A versão é ')),
 ('time-based heading','historic-heading','OPERATIONS.md',add('## Novidades da 0.19.0')),
 ('invented operation','operation','AGENTS.md',add('Use `linkedin/does-not-exist`.')),
 ('missing document','document','README.md',add('Consulte INEXISTENTE.md.')),
 ('missing index link','index','README.md',replace('ABILITIES.md','o catálogo')),
 ('invented control','label','PRIMEIROS-PASSOS.md',add('Use **Um botão inexistente no formulário**.')),
 ('label from wrong form','editor-field','PRIMEIROS-PASSOS.md',replace('**ID do aplicativo** |','**Nome da agenda** |')),
 ('fault replaced','error-code','TROUBLESHOOTING.md',replace('| `busy` |','| `impossivel_inventado` |')),
 ('operation count','operation-count','README.md',replace('das '+str(len(reg['abilities']))+' operações','das 0 operações')),
 ('range mismatch','page-range','README.md',replace('256 a 65536','256 a 32768')),
 ('old companion','companion','AGENTS.md',add('A versão Core 1.10.0 é necessária.')),
 ('duplicate paragraph','duplicate','WORKER.md',add(next(s for s in (src/'OPERATIONS.md').read_text().split('\n\n') if len(s)>150 and not s.startswith(('#','|','-'))))),
 ('lost capability row','catalog','ABILITIES.md',replace('| `configuration-schema` |','| `wrong-operation` |')),
 ('documentation index issue','index','README.md',replace('lead-campaign-schema.json','novo esquema')),
]
out=[]; verify(src,reg,plugin)
for name,kind,file,apply in checks:
    with tempfile.TemporaryDirectory() as temp:
        where=Path(temp)/'docs';shutil.copytree(src,where);p=where/file;p.write_text(apply(p.read_text()))
        try:verify(where,reg,plugin);caught=False
        except ValueError as e:caught=any(x.startswith(kind+':') for x in str(e).splitlines())
        out.append(dict(scenario=name,expected=kind,detected=caught))
print(json.dumps({'total':len(out),'killed':sum(c['detected'] for c in out),'checks':out},indent=2));sys.exit(int(not all(c['detected'] for c in out)))
