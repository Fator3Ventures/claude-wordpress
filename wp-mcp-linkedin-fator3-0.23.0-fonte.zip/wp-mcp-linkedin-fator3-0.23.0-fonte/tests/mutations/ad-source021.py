"""Produce QA-only ZIPs in a fresh directory, for tests/native/ad-source021.php."""
from pathlib import Path
import sys,tempfile,zipfile,json,hashlib
s=Path(__file__).resolve().parents[2];z=next((s/'build/dist').glob('*instalador.zip'));out=Path(sys.argv[1]).resolve();assert not out.is_relative_to(s);out.mkdir(exist_ok=False)
root='wp-mcp-linkedin-fator3/';target='includes/AdSource.php';manifest='manifest.sha256.json'
with zipfile.ZipFile(z) as src:files={n:src.read(n) for n in src.namelist()}
cases={'expiry':("$expires!==null&&$expires<=","false&&$expires!==null&&$expires<="),
       'ownership':("!in_array($asset['owner']??null,[$author,$accountUrn,'urn:li:sponsoredContentAccount:'.$account],true)","false"),
       'campaign':("($fromCampaign!==null&&$fromCampaign!==$campaign)","false")}
for key,(old,new) in cases.items():
 outfiles=files.copy();t=files[root+target].decode();assert t.count(old)==1
 outfiles[root+target]=t.replace(old,new).encode();m=json.loads(files[root+manifest]);m[target]=hashlib.sha256(outfiles[root+target]).hexdigest();outfiles[root+manifest]=json.dumps(m,indent=2).encode()
 with zipfile.ZipFile(out/(key+'.zip'),'w',zipfile.ZIP_DEFLATED) as f:
  for n,b in outfiles.items():f.writestr(n,b)
