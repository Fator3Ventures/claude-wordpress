"""Compare full runtime content to an actual installer (independent of compression implementation)."""
from pathlib import Path,PurePosixPath
from zipfile import ZipFile
import hashlib,json,stat,sys
def verify(archive,tree):
    slug='wp-mcp-linkedin-fator3'; sha=lambda b:hashlib.sha256(b).hexdigest()
    with ZipFile(archive) as z:
        if z.testzip():raise ValueError('CRC mismatch')
        files={}
        for i in z.infolist():
            pp=PurePosixPath(i.filename)
            if pp.is_absolute() or '..' in pp.parts or pp.parts[0]!=slug or len(pp.parts)<2 or stat.S_ISLNK(i.external_attr>>16):raise ValueError(i.filename)
            if i.is_dir():continue
            n=str(PurePosixPath(*pp.parts[1:])); 
            if n in files:raise ValueError('duplicate: '+n)
            files[n]=sha(z.read(i))
        manifest=json.loads(z.read(slug+'/manifest.sha256.json'))
        if manifest!={k:v for k,v in files.items() if k!='manifest.sha256.json'}:raise ValueError('manifest mismatch')
        if b'Version: 0.23.0' not in z.read(slug+'/'+slug+'.php')[:4096]:raise ValueError('version mismatch')
    disk={p.relative_to(tree).as_posix():sha(p.read_bytes()) for p in tree.rglob('*') if p.is_file()}
    if files!=disk:raise ValueError('runtime mismatch')
    return {'files':len(files),'manifest_entries':len(manifest),'identical_tree':True,'sha256':sha(archive.read_bytes())}
if __name__=='__main__':print(json.dumps(verify(Path(sys.argv[1]),Path(sys.argv[2]))))
