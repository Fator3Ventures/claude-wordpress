# Plano — Fator3 MCP LinkedIn 0.20.0

Revisão 1 · 10/11/2026, America/Sao_Paulo · Rodada: planejamento, com análise, testes e revisão documental da base
Slug: `wp-mcp-linkedin-fator3` · Base: 0.19.0 · Versão-alvo prevista: 0.20.0 · Instalador-alvo: ainda não gerado
Status do plano: aguardando as decisões da seção 10 para iniciar a implementação

Todos os números deste documento foram lidos de arquivos gerados nesta rodada (`facts.json` e evidências do pacote de evidências). Os identificadores `L20-nn` são internos a este plano; não foi aberto ID novo na aba central.

## 1. Documentos lidos e base

Lidos integralmente nas fontes do projeto: `instrucoes-agentes-plugins-fator3.md`, revisão 5 de 02/11/2026, e `padrao-desenvolvimento-plugins-fator3.md`, revisão 5 de 02/11/2026. Sem divergência entre os dois.

Base recebida do usuário, conferida contra a seção 8 do relatório 0.19.0:

| Arquivo | Bytes | SHA-256 | Confere com o relatório |
|---|---:|---|---|
| `wp-mcp-linkedin-fator3-0.19.0-instalador.zip` | 397354 | `613cb47cfb3be2b91dfa1f20f39c465780a6fffb5432b645290448fe592a0f0c` | sim |
| `wp-mcp-linkedin-fator3-0.19.0-fonte.zip` | 3056323 | `25f3458b99584a68bb56920c12ef828508d6cb0f2c72eceb0921d24d3eae3a62` | sim |

Os dois ZIPs seguem inalterados. Esta rodada não gera instalador.

Requisitos do projeto: PHP 8.3 e WordPress 7.1.4. Runtimes usados nos testes locais desta rodada: PHP 8.3.6, WordPress 7.1.4 e MySQL 8.0.46.

## 2. Conjunto vigente e divergência do ambiente

O relatório 0.19.0 declara a regressão final contra um conjunto de acompanhantes. O Site-Teste, lido hoje pelo WP MCP fator3-teste, tem outro:

| Pacote | No relatório 0.19.0 | No Site-Teste hoje |
|---|---|---|
| base-site-core-fator3 | 1.71.0 | 1.78.0 |
| wp-mcp-fator3 | 0.41.0 | 0.43.0 |
| wp-mcp-google-fator3 | 0.28.0 | 0.31.0 |
| wp-mcp-meta-fator3 | 0.21.0 | 0.21.0 |
| wp-mcp-pipedrive-fator3 | 0.7.0 | 0.8.0 |

4 dos 5 acompanhantes mudaram desde a regressão. A qualificação «apta no escopo testado» da 0.19.0 vale para o conjunto antigo. A integração da 0.19.0 com o Site Core 1.78.0 e o MCP 0.43.0 não tem prova de bancada. O conjunto vigente para a 0.20.0 é o da coluna da direita; os instaladores correspondentes são entrada obrigatória da implementação (seção 11).

## 3. O que foi testado nesta rodada

| Prova | Ambiente | Resultado |
|---|---|---|
| Lint PHP dos 36 arquivos do instalador | PHP 8.3.6 local | 0 falhas |
| Sintaxe dos 4 scripts | Node local | 0 falhas |
| Manifesto interno contra os arquivos | Instalador extraído | 85 entradas, todas conferem |
| Reconstrução pelo `build/build.py` do fonte | Local | 86 de 86 arquivos com conteúdo idêntico; ZIP com bytes diferentes (achado L20-13) |
| 9 suítes do próprio fonte, cada uma em WordPress e banco descartáveis | Bancada local, só o LinkedIn instalado | 333 verificações, 0 falhas |
| Teste visual do próprio fonte, `webui019.php` | Chrome 153.0.8010.12 na bancada | 42 verificações, 0 falhas; mesmo total do relatório: sim |
| Captura das 10 abas em 1440×900 e 390×844, com dados de demonstração e com o site vazio | Chrome 153.0.8010.12 na bancada | 48 imagens e medidas por aba |
| Sonda de layout e de comportamento | Chrome 153.0.8010.12 na bancada | Achados L20-02 a L20-05 e L20-09 a L20-12 |
| Reprodução dirigida de salvamento de conexão | Bancada local | Achado L20-01 |
| Leituras pelo MCP: estado, autoteste, catálogo, conexões, concessões, retenção, auditoria, capacidades | Site-Teste | Estado `ok`, 9 de 9 no autoteste, 99 operações |
| Leitura documental pelo MCP com o hash calculado do instalador | Site-Teste | 3 documentos aceitos até a última página; 3 controles negativos recusados |

Detalhe das suítes locais: suite 135, requests017 47, worker019 19, management019 22, diagnostic019 12, lifecycle019 12, ui0170 54, ui018 28 e docs018 4. Os totais de diagnostic019, lifecycle019, management019, requests017, ui0170, ui018 e worker019 coincidem com os que o relatório 0.19.0 declara. docs018 e suite não aparecem isoladas no relatório.

Não executado, com motivo:

| Prova | Motivo | Responsável |
|---|---|---|
| Suítes integradas (`linkedin-integrated`), transporte MCP em bancada e `mcp-docs080` | Instaladores dos acompanhantes não foram fornecidos | Dono: fornecer os pacotes da seção 11 |
| Migração 0.18.0 → 0.19.0 | Instalador 0.18.0 não fornecido; deixa de ser necessário, pois a base da 0.20.0 é a 0.19.0 | — |
| Qualquer escrita no Site-Teste | Rodada de planejamento | — |
| Acesso real ao LinkedIn | O Site-Teste não tem conexão configurada | Dono/frota |

## 4. Achados

### Defeitos funcionais

**L20-01 — Conexão nova é gravada ativa sem nenhuma credencial, e o diagnóstico a considera saudável.**
Reprodução na bancada (`estatico/enabled-no-token.json`): conexão nova, ativa, só com nome → `ok`, `enabled: true`, `token_configured: false`. Controle: a mesma chamada com apenas Client ID → `application_required`. Controle: conexão pausada sem credencial → `ok`. Depois do caso A, `linkedin/status` devolve `state: ok` com 0 avisos.
Causa: em `ConnectionChanges::saveCandidate` a recusa `application_required` depende de o vínculo de credenciais ter mudado. Numa conexão nova sem credenciais o vínculo antes e depois é o mesmo, e a recusa não dispara. A própria mensagem do código descreve a regra pretendida: para preparar OAuth sem token, salvar pausada.

**L20-02 — Rótulos de campo trocados.**
A ajuda de campo é indexada pelo atributo `name` do HTML e substitui o rótulo pedido pela tela. Em 26 das 50 chamadas de campo de `Admin.php` o texto exibido difere do pedido. Em 5 casos o resultado está errado para o contexto:

- «Conta autorizada» aparece como «Conta de anúncios (Ad account ID)»
- «Conexão ativa» aparece como «Ativar esta configuração (controle local)»
- «Dias de guarda» aparece como «Retenção dos resultados (configuração local)»
- «Nome da agenda» aparece como «Nome da conexão»
- «Concessão ativa» aparece como «Ativar esta configuração (controle local)»

O primeiro caso aparece com o canal Páginas selecionado, quando a lista contém Páginas. O quarto aplica ao nome da agenda também o texto de ajuda do nome da conexão. Evidência: `estatico/label-collisions.json` e capturas `seeded-desktop-jobs.png` e `seeded-desktop-reports.png`.

**L20-03 — O resultado de uma ação aparece fora da área visível e o foco se perde.**
Todas as mensagens vão para uma faixa no alto da página. Na aba Conexão com 56 conexões, ao salvar com a página rolada em 3118 px, a faixa ficou a 3550 px do botão, fora da janela (`message_in_viewport: false`). Depois da ação o foco estava em `BODY#`: o botão é desabilitado durante a chamada e o foco não volta. Evidência: `tela/probe.json`, `probe-feedback-viewport.png`.

**L20-04 — Textos que apontam para controles inexistentes ou se contradizem.**
O cartão da conexão manda usar «Conferir token»; o botão chama-se «Verificar permissões». O mesmo cartão escreve «Nome não informado (nome informado; Client ID … confirmado)». Listas locais vazias, como a de concessões, exibem «A origem não retornou linhas neste recorte.».

**L20-05 — Caixas de seleção deformadas.**
Em 390 px, 29 das 31 caixas visíveis nas 10 abas não são quadradas (tamanhos medidos: 16x25, 22x25 e 25x25). Em 1440 px, 7 de 37. Causa: `.f3-check input{width:auto!important;min-height:0!important}` anula a largura do WordPress e conserva a altura.

**L20-06 — Toda leitura grava auditoria; a retenção padrão é sem prazo; o catálogo declara o contrário.**
Na bancada, cada chamada de `status`, `selftest`, `list-connections`, `capabilities`, `get-retention` e `list-schedules` acrescentou 1 linha; 25 chamadas de `status` acrescentaram 25. `documentation` acrescentou 0. O catálogo publica 55 operações de leitura com `local_effect: none`; 53 delas gravam uma linha por chamada. Abrir as 10 abas do painel faz 25 chamadas ao plugin (10 só na aba Ativos). No Site-Teste, sem nenhuma conexão, a primeira página da auditoria já traz 50 eventos, todos de leitura, e há continuação. A retenção padrão é `unlimited`.

**L20-07 — Campos não secretos chegam redigidos ao agente.**
Pelo MCP 0.43.0 do Site-Teste, 4 campos vieram como `[redigido]`: `credential_input` e `empty_secret_keeps_existing` em `configuration-schema`, `maintenance.last.credentials_code` em `status` e `local_sdk.features.dispatch_authorization` em `capabilities`. Os dois primeiros são as regras que o agente precisa para não apagar um segredo ao salvar. O código tem outras 7 chaves de resposta com o mesmo padrão de nome e valor não secreto (authorization_revision, credential_generation, credential_notice_days, credential_revision, refresh_configured, secret_configured e token_configured). Sem conexão no Site-Teste não foi possível observar se elas também são redigidas; `credential_revision` é usada pelos fluxos documentados de concessão.

**L20-08 — Continuação de documento sem `expected_revision` responde «Documento alterado».**
O código devolvido é `revision_conflict`, com `conflict: true`, embora nada tenha mudado. Reproduzido no Site-Teste.

### Layout da tela de configuração

**L20-09 — A aba Conexão é longa e põe a lista antes do formulário.**
Com 56 conexões, a página tem 4,46 telas de altura no desktop e 6,96 no celular; vazia, 2,76 e 4,64. Os 8 cartões exibidos ocupam 1510 px e o formulário começa em 1979 px. O formulário mostra 32 controles e 14 blocos de ajuda permanentes, com 3188 caracteres em corpo de 10,8 px. O endereço de retorno OAuth e o bloco de autorização ficam abaixo do botão de salvar, embora sejam necessários antes de obter o token.

**L20-10 — A seleção compartilhada empurra o conteúdo de três abas.**
Em Relatórios, Coletas e Histórico o bloco «Seleção da consulta» mede 372 px no desktop e 752 px no celular. Em Coletas, o primeiro campo próprio da aba começa em 828 px numa janela de 900 px, e em 1339 px numa de 844 px.

**L20-11 — Navegação e agrupamento.**
São 10 abas em uma faixa; no celular quebram em 3 linhas (121 px). A ordem não acompanha o uso: Coletas vem antes de Relatórios, e Retenção fica entre Histórico e Anúncios. As concessões estão divididas: formulários em «Formulários e concessões», conversões dentro de «Ativos», que por isso tem 3 botões primários e 4,8 telas no celular.

**L20-12 — Acabamento.**
4 pares de botões sem espaço entre si (Consultar estado / Atualizar operações, Consultar operação / Reconciliar sem reenviar, Salvar agenda / Nova agenda e Simular alteração / Confirmar política). 8 rótulos encostados no controle (assets: Conexão, assets: Intervalo de descoberta em minutos, connections: Buscar conexão por nome ou identificador, connections: Buscar usuário por nome, help: Documento, management: Conexão, management: Estado e management: Identificação da operação). Campos numéricos esticados: «Linhas por página», que aceita até 100, mede 1188 px. A aba Ajuda lista 43 arquivos pelo nome, 18 deles notas de versões antigas, e mostra o Markdown cru: 32 marcadores de negrito e 8 linhas de tabela aparentes no primeiro documento, 0 elementos renderizados.

### Manutenção, build e testes

**L20-13 — O ZIP do instalador só se reproduz com a mesma biblioteca de compressão.**
A reconstrução local gerou os 86 arquivos com conteúdo idêntico e 55 fluxos comprimidos diferentes (zlib local 1.3.1.zlib-ng); o SHA-256 do ZIP difere do entregue. O conteúdo se reproduz; os bytes do ZIP variam com a biblioteca de compressão da máquina.

**L20-14 — O fonte editável tem a densidade de código minificado.**
Em `build/common`, `build/linkedin` e `build/assets`: 36 arquivos, 532525 bytes em 3856 linhas, 109 linhas com mais de 500 caracteres; a maior tem 5693 caracteres, em `admin.js`. `admin.js` tem 69865 bytes em 211 linhas e `admin.css`, 5040 bytes em 13. Um diff de revisão nessas condições não localiza a mudança.

**L20-15 — O teste visual não cobre o que falhou.**
`tests/browser/layout019.py` verifica 6 das 10 abas (ficam de fora: assets, history, jobs e reports), captura 3 e mede somente transbordamento horizontal. Nesta bancada ele passa com 42 verificações e 0 falhas sobre a mesma tela em que foram medidos os achados L20-02 a L20-05 e L20-09 a L20-12.

**L20-16 — O teste documental confere só a primeira linha.**
`mcp-docs080.php` aprova um manual corrente se o título traz a versão. 15 dos 21 manuais correntes, sem contar o CHANGELOG, têm o título em 0.19.0 e seções organizadas por release antiga; 16 citam versões de outros pacotes (53 menções, 0 delas do conjunto vigente); 8 parágrafos se repetem literalmente, 39 ocorrências. O lint desta rodada acusa 76 erros nos manuais do instalador 0.19.0.

**L20-17 — Itens menores.**
O runtime LinkedIn carrega ramos do pacote Meta (26 referências a `f3_meta` em PHP e 15 usos da variável `meta` em `admin.js`). Não há chamada a função de tradução (0); o `Text Domain` do cabeçalho não é usado. A documentação é empacotada duas vezes: 343047 bytes em `docs/` e 459255 bytes em `includes/Data/Documentation.php`. Rodar duas suítes que gravam no mesmo banco de bancada contamina a segunda; `tools/lab.py` aceita a lista sem avisar.

## 5. Correções planejadas

| ID | Mudança | Arquivos | Aceite observável | Mutação que precisa derrubar o teste |
|---|---|---|---|---|
| L20-01 | Recusar com `application_required` a gravação de conexão ativa sem token, inclusive nova. Acrescentar ao `status` o aviso `connection_without_token` para conexões ativas sem token já existentes; não pausá-las na migração. | `ConnectionChanges.php`, `Worker.php`, `WORKER.md` | Caso A passa a `application_required`; casos B e C inalterados; aviso presente para registro antigo | Retirar a nova condição: o caso A volta a `ok` |
| L20-02 | Ajuda de campo com chave explícita por formulário; a tela volta a exibir o rótulo que pediu. Rótulo do seletor de conta varia com o canal. | `FieldHelp.php`, `Admin.php`, `admin.js` | `label_collisions.py` sem substituição implícita; teste de DOM com os 5 rótulos de L20-02 | Indexar de novo um campo só pelo `name` |
| L20-03 | Faixa de mensagens fixa sob a barra do WordPress; estado junto ao botão acionado; foco devolvido ao botão; erro com `role="alert"`. | `admin.js`, `admin.css`, `Admin.php` | `probe.py`: mensagem dentro da janela em qualquer rolagem; foco no botão | Remover o posicionamento fixo; remover a devolução do foco |
| L20-04 | Corrigir os textos apontados; mensagens de lista vazia próprias de cada lista. | `admin.js` | Teste de DOM por texto | Restaurar um dos textos antigos |
| L20-05 | Caixas com largura e altura iguais, sem `!important` sobre o tamanho. | `admin.css` | `probe.py`: zero caixas não quadradas nas duas larguras | Restaurar a regra antiga |
| L20-06 | Conforme a decisão D1. Proposta: não auditar leitura local bem-sucedida; manter escritas, leituras no LinkedIn e toda recusa. Declarar o efeito real no catálogo. | `Api.php`, `Labels.php`, `SECURITY.md` | 25 chamadas de `status` acrescentam zero linhas; uma recusa acrescenta uma | Voltar a auditar `status` |
| L20-07 | Chaves novas, de nome neutro, para os valores não secretos redigidos; as antigas permanecem. Teste que passa cada resposta pública pelo transporte real e falha se um campo não secreto voltar redigido. | `Api.php`, `LeadReader.php`, `Worker.php`, `CONTRACTS.md` | Teste com o MCP vigente na bancada | Renomear uma chave nova para um nome com `token` |
| L20-08 | Mensagem própria para continuação sem `expected_revision`; o código permanece. | `Documentation.php` | Mensagem distinta nos dois casos | Unificar as mensagens |
| L20-13 | Verificação de reprodução por conteúdo (manifesto) no build e registro da versão do zlib no relatório. | `build/build.py`, `tools/` | Reconstrução em outra máquina aprova por conteúdo | Alterar um byte de um arquivo do runtime |
| L20-14 | Reformatar o fonte editável, uma instrução por linha, em passo isolado e anterior às demais mudanças. | `build/common`, `build/linkedin`, `build/assets` | Sequência de tokens PHP e árvore sintática JS idênticas antes e depois; suítes sem alteração de resultado | Alterar um literal durante a reformatação |
| L20-15 | Teste visual nas 10 abas com os limites da seção 6. | `tests/browser/`, `tests/native/` | Falha na 0.19.0, passa na 0.20.0 | Cada limite é exercitado por uma mutação de CSS ou de marcação |
| L20-16 | Lint documental no build; catálogo de operações, tabela de códigos e tabela de faixas gerados do código. | `build/build.py`, `build/docs/` | Build falha com manual divergente | As 13 mutações já escritas em `docs_mutation.py` |
| L20-17 | Reiniciar o banco entre suítes em `tools/lab.py` ou recusar a combinação. Demais itens ficam registrados, sem mudança nesta versão. | `tools/lab.py` | Duas suítes na mesma chamada passam | — |

Nenhuma dessas mudanças acrescenta fase de confirmação, token de confirmação ou desfazer a rotas de escrita.

## 6. Layout planejado

### Estrutura

Seis seções no lugar das 10 abas, na ordem de uso. Os valores atuais de `tab=` continuam aceitos e levam à seção e ao bloco correspondentes.

| Seção | Reúne | Vem de |
|---|---|---|
| Conexões | Lista, edição, autorização e ativos de cada conexão | Conexão, Ativos (parte de ativos) |
| Concessões | Formulários, conversões de aquisição e etapas comerciais | Formulários e concessões, Ativos (blocos de conversões) |
| Dados | Relatórios, Coletas e Histórico, com a seleção em uma barra | Relatórios, Coletas, Histórico |
| Anúncios e publicações | Sem mudança de conteúdo | Anúncios e publicações |
| Manutenção | Diagnóstico, retenção da auditoria, versão da API | Diagnóstico, Retenção |
| Ajuda | Documentos e referência de campos | Ajuda |

No celular a navegação ocupa uma linha, com rolagem horizontal.

### Conexões

```
Conexões                                             [ Nova conexão ]
[ buscar por nome ou identificador            ]
+---------------------------------------------------------------------+
| Nome                 | Estado | Token    | Validade (UTC) |         |
| Marketing · App      | Ativa  | Salvo    | 09/01/2027     | Editar  |
| Equipe 1             | Pausada| Sem token| —              | Editar  |
+---------------------------------------------------------------------+
                                                   1–20 de 56   ‹ ›
```

A lista passa a tabela, 20 linhas por página. Editar abre a conexão em vista própria (`tab=connections&connection=<id>`), com o formulário no topo:

```
‹ Conexões   Marketing · App                              Ativa [x]
1 Aplicativo        Client ID | Segredo | Número do aplicativo
                    Endereço de retorno OAuth  [ copiar ]
2 Acesso            ( ) Colar token   ( ) Autorizar no LinkedIn
                    Token | Validade (UTC)  = 14:00 em America/Sao_Paulo
3 Ativos            Páginas | Anúncios | Formulários
4 Quem usa e guarda Usuários | Guarda dos resultados
▸ Renovação e aviso   ▸ Remover credenciais   ▸ Efeito sobre agendas e concessões
---------------------------------------------------------------------
Alterações não salvas                 [ Salvar conexão ]   (barra fixa)
```

- O retorno OAuth sobe para o passo 1.
- O bloco de efeito sobre agendas e concessões aparece só em conexão existente que tenha agenda ou concessão.
- Ajuda de campo em duas camadas: uma linha curta visível, em corpo de 12 px ou mais; o caminho no LinkedIn e o link em «Onde encontrar», recolhido. O aviso sobre espaços aparece uma vez por grupo.
- Larguras por tipo: número até 12 caracteres, data e hora até 22, identificador até 30, token e segredo na largura do grupo.

### Dados

```
Conexão [Marketing · App ▾]  Canal [Páginas ▾]  Página [Empresa ▾]  Relatório [Estatísticas ▾]  De [  ] Até [  ]
[ Relatórios ] [ Coletas ] [ Histórico ]
```

A seleção vira uma barra de uma linha no desktop. No celular fica recolhida em um resumo, com «Alterar». O rótulo do terceiro seletor acompanha o canal.

### Ajuda

Índice agrupado em Manuais, Schemas e Histórico, com título e descrição de cada documento; Markdown renderizado por um conversor restrito a títulos, parágrafos, listas, tabelas, código e ênfase, sem HTML do documento. O índice devolvido por `linkedin/documentation` ganha `title`, `description` e `kind`, de forma aditiva.

### Limites que o teste visual vai impor

| Medida | Hoje | Limite na 0.20.0 |
|---|---|---|
| Início do formulário de edição da conexão, desktop | 1979 px | até 320 px |
| Primeiro campo próprio de Coletas, desktop / celular | 828 / 1339 px | até 420 / 520 px |
| Altura da navegação no celular | 121 px | até 48 px |
| Mensagem de resultado dentro da janela depois de salvar | não | sempre |
| Foco depois de uma ação assíncrona | `BODY#` | no botão acionado |
| Caixas não quadradas, celular / desktop | 29 / 7 | 0 / 0 |
| Pares de botões sem espaço | 4 | 0 |
| Rótulos encostados no controle | 8 | 0 |
| Corpo do texto de ajuda | 10,8 px | 12 px ou mais |
| Blocos de ajuda permanentes no formulário de conexão | 14 | até 6 |
| Largura de «Linhas por página» | 1188 px | até 12 caracteres |
| Rótulos exibidos diferentes do pedido sem chave explícita | 26 | 0 |

## 7. Documentação

A documentação instalada faz parte do instalador 0.19.0, que é imutável. A melhoria pedida para a «versão atual» foi feita sobre o conteúdo da 0.19.0 e entregue como árvore pronta para `build/docs/linkedin/`, com diff; chega aos sites na 0.20.0.

Entregue nesta rodada (`wp-mcp-linkedin-fator3-0.20.0-docs-revisados.zip`):

- 7 manuais reescritos contra o código e a tela da 0.19.0: README.md, PRIMEIROS-PASSOS.md, AGENTS.md, ADMINISTRATION.md, CONFIGURATION.md, OPERATIONS.md e TROUBLESHOOTING.md.
- `ABILITIES.md`, novo, gerado do registro do plugin: as 99 operações por assunto.
- 10 manuais de domínio com limpeza mecânica: 15 ocorrências de parágrafos repetidos removidas e 21 seções renomeadas pelo assunto. O roteiro confere que cada parágrafo mantido é igual ao da base, comparado com espaços normalizados; os removidos ficam uma vez no `CHANGELOG.md`, que passa a ter um único título de nível 1. `FIELD-HELP.md` recebeu ainda uma correção de digitação.
- Inalterados: HISTORY.md, LEAD-DISCOVERY.md, MIGRATION.md e STAGE-CONVERSIONS.md e as 18 notas `RELEASE-*`.
- `docs_lint.py`, com 11 verificações contra o código: 76 erros na base, 0 na árvore revisada. 13 de 13 defeitos plantados foram acusados. O lint confere 110 textos de tela citados e 13 números contra o código.
- Prova de bancada com a árvore revisada no build real: `docs018` 4 de 4, leitura paginada em 25 páginas; `suite` 135; `ui018` 28. O runtime PHP, JS e CSS desse candidato de bancada é o da 0.19.0; o candidato não é artefato de entrega.

Fica para a implementação da 0.20.0:

- 8 manuais de domínio ainda citam versões de outros pacotes (21 menções). Corrigir exige os relatórios e fontes do conjunto vigente. O modo `--strict` do lint falha enquanto restarem.
- Atualizar os manuais de tela para o layout novo e retirar as seções «Comportamentos a conhecer nesta versão» à medida que L20-01 a L20-08 forem corrigidos.
- Mover os geradores para o build (L20-16).

## 8. Testes da 0.20.0

Matriz da seção 8.2 do padrão, mais:

| Cenário | Prova |
|---|---|
| Atualização 0.19.0 → 0.20.0 | Conexões, concessões, agendas, diários e política de retenção preservados; conexão ativa sem token existente permanece e passa a gerar aviso |
| Instalação limpa | Suítes locais atuais e as novas |
| Conjunto vigente | Suítes integradas com os 5 acompanhantes da seção 2 |
| Tela | Teste visual nas 10 abas e nas duas larguras, com os limites da seção 6 |
| Documentação pelo MCP | Critério 7.3 do padrão, com índice descrito |
| Redação pelo transporte | L20-07, com o MCP vigente |
| Site-Teste | Uma troca, com leitura do inventário antes e depois |

Cada item da seção 5 tem a mutação indicada. A execução das mutações na árvore real cabe ao agente principal, depois da implementação delegada.

## 9. Impactos avaliados

| Destinatário | Avaliação |
|---|---|
| wp-mcp-fator3 | Impacto preliminar emitido: `wp-mcp-linkedin-fator3-0.20.0-impacto-wp-mcp-fator3.md`, classificação `alerta-tecnico`, situação `aberto`. A correção planejada (L20-07) fica toda no emissor. |
| base-site-core-fator3 | Sem impacto identificado nas mudanças planejadas. `nao-avaliado`: o Core 1.78.0 não foi examinado; conferir na implementação se ele lê `linkedin/audit` (L20-06) ou as chaves de L20-07. |
| wp-mcp-meta-fator3 | `nao-avaliado`: `build/common` nasceu compartilhado com o pacote Meta. As mudanças deste plano ficam na cópia do LinkedIn. |
| wp-mcp-google-fator3, wp-mcp-pipedrive-fator3 | Sem fronteira tocada. |

## 10. Decisões do dono

| ID | Decisão | Proposta deste plano |
|---|---|---|
| D1 | Auditoria de leituras (L20-06): deixar de auditar leitura local bem-sucedida, ou manter e declarar o efeito no catálogo | Deixar de auditar. A auditoria passa a registrar o que muda estado, o que consulta o LinkedIn e o que é recusado. |
| D2 | Campos redigidos (L20-07): chaves neutras no LinkedIn, ou lista de exceções no MCP | Chaves neutras no LinkedIn. Não depende de outra release. |
| D3 | Reagrupamento em seis seções (seção 6) | Aprovar antes da implementação; muda tela e manuais. |
| D4 | Fases de simulação e confirmação existentes: 25 operações aceitam `dry_run`, 20 exigem `confirm_token` e 2 usam `confirmation` | Manter na 0.20.0. São contratos publicados e a remoção exige coordenação com os consumidores. Este plano não acrescenta nenhuma. |
| D5 | Reformatação do fonte (L20-14) nesta mesma versão | Incluir, como primeiro passo, verificada por equivalência sintática. |

## 11. Entradas necessárias e pendências

- Instaladores e relatórios vigentes: Site Core 1.78.0, MCP 0.43.0, Google 0.31.0, Meta 0.21.0 e Pipedrive 0.8.0. Sem eles as suítes integradas e L20-07 ficam sem prova.
- Referência de layout: as telas administrativas dos pacotes MCP 0.43.0 e Google 0.31.0 não foram examinadas nesta rodada. Comparar componentes e nomenclatura com elas antes de fechar a seção 6, pelos fontes ou por sessão autenticada no Site-Teste.
- Homologação com conta real do LinkedIn: segue pendente, com o dono e a frota.
- Mínimos de runtime: PHP 8.3 exercitado em 8.3.6; WordPress no piso 7.1.4.

## 12. Sequência de execução

1. Reformatação do fonte (L20-14), isolada, com prova de equivalência.
2. Correções de servidor: L20-01, L20-06, L20-07, L20-08, com testes de bancada.
3. Tela: L20-02 a L20-05 e seção 6, com o teste visual novo (L20-15).
4. Documentação e build: árvore revisada, geradores e lint no build (L20-16), manuais de tela atualizados.
5. Bancada integrada com o conjunto vigente, atualização 0.19.0 → 0.20.0 e instalação limpa.
6. Mutações pelo agente principal; fechamento de instalador, relatório e fonte na ordem da seção 4.3 do padrão; troca única no Site-Teste.

Os passos 2 e 3 podem ser delegados em paralelo depois do passo 1. O passo 6 não é delegado.

## 13. Artefatos desta rodada

| Artefato | Conteúdo |
|---|---|
| `wp-mcp-linkedin-fator3-0.20.0-plano.md` | Este plano |
| `wp-mcp-linkedin-fator3-0.20.0-impacto-wp-mcp-fator3.md` | Impacto preliminar ao MCP |
| `wp-mcp-linkedin-fator3-0.20.0-docs-revisados.zip` | Árvore de documentação revisada, diff contra a 0.19.0, lint, mutações e relatórios |
| `wp-mcp-linkedin-fator3-0.20.0-evidencias.zip` | Capturas, medidas, saídas da bancada, observações do Site-Teste, roteiros e `facts.json` |
| Base 0.19.0 | Instalador e fonte recebidos, inalterados, identificados na seção 1 |

Checklist da seção 14 do padrão, itens aplicáveis a planejamento: documentos centrais lidos e revisões informadas; base, alvo e conjunto vigente explícitos; impactos avaliados e o relevante registrado como preliminar, sem exigir hash futuro; nenhuma alteração em instalação compartilhada, release alheia ou efeito externo. Itens de release (instalador, fonte, relatório de entrega, instalação limpa e migração da versão-alvo) são `nao-aplicavel` nesta rodada.
