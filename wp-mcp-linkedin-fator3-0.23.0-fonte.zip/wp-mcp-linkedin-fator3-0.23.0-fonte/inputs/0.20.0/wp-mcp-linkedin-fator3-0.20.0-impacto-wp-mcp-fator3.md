# Impacto de wp-mcp-linkedin-fator3 0.20.0 em wp-mcp-fator3

Data/hora: 2026-11-10T18:43-03:00 · Revisão: 1
Etapa: planejamento
Situação: aberto
Versão-base: 0.19.0, instalador recebido do usuário, SHA-256 `613cb47cfb3be2b91dfa1f20f39c465780a6fffb5432b645290448fe592a0f0c` · Versão-alvo: 0.20.0, prevista
Instalador emissor: alvo ainda não gerado
Destinatário examinado: wp-mcp-fator3 0.43.0, em execução no Site-Teste; fonte e instalador não disponíveis nesta rodada
Natureza: comportamento do transporte sobre o contrato de saída de um provedor
Classificação: alerta-tecnico

Registro preliminar de planejamento. Não é solicitação pronta para implementação.

## Mudança e consequência

Comportamento atual, observado em 10/11/2026 pelo conector WP MCP fator3-teste: respostas do provedor `wp-mcp-linkedin-fator3` chegam ao agente com 4 campos não secretos substituídos por `[redigido]`.

| Operação | Campo | Valor emitido pelo LinkedIn | Valor recebido pelo agente |
|---|---|---|---|
| `linkedin/configuration-schema` | `credential_input` | `"manual_token"` | `"[redigido]"` |
| `linkedin/configuration-schema` | `empty_secret_keeps_existing` | `true` | `"[redigido]"` |
| `linkedin/status` | `maintenance.last.credentials_code` | código de resultado da manutenção | `"[redigido]"` |
| `linkedin/capabilities` | `local_sdk.features.dispatch_authorization` | `true` | `"[redigido]"` |

Na mesma resposta de `configuration-schema`, as definições de schema sob as chaves `token` e `client_secret` chegam intactas: são objetos. Os quatro campos atingidos têm valor escalar e nome com `credential`, `secret` ou `authorization`.

Consequência: o agente não recebe as duas regras que evitam apagar um segredo ao salvar uma conexão, nem o código da última manutenção de credenciais. O contrato `social-configuration/1.0.0` publicado pelo LinkedIn fica incompleto pelo transporte.

Risco ainda não medido: o LinkedIn emite outras 7 chaves de valor não secreto com o mesmo padrão de nome (authorization_revision, credential_generation, credential_notice_days, credential_revision, refresh_configured, secret_configured e token_configured). `credential_revision` e `authorization_revision` são lidas pelos consumidores e pelos agentes para detectar concessão obsoleta. O Site-Teste não tem conexão nem concessão, e essas chaves não apareceram em nenhuma resposta desta rodada.

Incerteza: a regra do redator não foi lida no código. A descrição acima é inferência das respostas.

## Ação ou decisão do responsável

Nenhuma ação é exigida para a 0.20.0 do LinkedIn: a correção planejada fica no emissor (ver «Prontidão do emissor»).

Para avaliação do responsável pelo MCP: outros provedores que publiquem indicadores com esses termos no nome sofrem o mesmo efeito. Duas alternativas, a critério do responsável:

1. Redigir pelo valor e pela posição, não só pelo nome: manter a redação para texto longo ou com formato de credencial e liberar booleanos, inteiros e enumerações curtas.
2. Permitir que o provedor declare, no registro `ExtensionContract::register`, os caminhos de saída não secretos.

Aceite observável de qualquer das duas: `linkedin/configuration-schema` devolve `empty_secret_keeps_existing: true` ao agente, e um token real continua redigido.

## Diagnóstico e alteração proposta no destinatário

Reprodução, com perfil administrativo no Site-Teste:

1. Executar `linkedin/configuration-schema` com `{}`. Observar `credential_input` e `empty_secret_keeps_existing`.
2. Executar `linkedin/status` com `{}`. Observar `maintenance.last.credentials_code`.
3. Executar `linkedin/capabilities` com `{}`. Observar `local_sdk.features.dispatch_authorization`.

Origem dos valores no emissor, instalador 0.19.0: `includes/Api.php` (resposta de `configuration-schema`), `includes/Worker.php` (`Worker::maintenance`, opção `f3_linkedin_last_maintenance`) e `includes/LeadReader.php` (lista `features`).

Localização no destinatário, patch e teste em cópia isolada: não realizados. Impedimento concreto: o fonte e o instalador do wp-mcp-fator3 0.43.0 não foram fornecidos. Próxima ação: fornecer o pacote vigente do MCP à rodada de implementação do LinkedIn.

## Prontidão do emissor

Planejado para a 0.20.0, item L20-07 do plano; ainda não implementado:

- Chaves novas, de nome neutro, com os mesmos valores; as chaves atuais permanecem, sem mudança de contrato para quem lê por REST ou PHP.
- Teste de bancada que passa cada resposta pública do LinkedIn pelo executor real do MCP vigente e falha quando um campo não secreto volta redigido. Esse teste também responde ao risco das 7 chaves.
- Documentação: a lista observada já consta de `AGENTS.md` na árvore revisada desta rodada.

Lacunas: implementação e teste dependem do instalador do MCP 0.43.0. Antes da mudança no destinatário, o LinkedIn funciona com as chaves novas. Depois dela, as duas formas ficam legíveis. Em nenhum dos dois estados o LinkedIn precisa de outra release.

## Compatibilidade e sequência

Conjunto vigente lido no Site-Teste: base-site-core-fator3 1.78.0, wp-mcp-fator3 0.43.0, wp-mcp-google-fator3 0.31.0, wp-mcp-meta-fator3 0.21.0 e wp-mcp-pipedrive-fator3 0.8.0. Sem ordem de troca: a correção do emissor não depende do destinatário. Sem suporte a versões antigas nem a combinações mistas.

## Validação e evidência

Base da análise: respostas ao vivo do Site-Teste, transcritas em `site-teste/observacoes-2026-11-10.json` do pacote de evidências, e leitura do instalador 0.19.0. Prova local com o destinatário: não executada, pelo impedimento acima. Nenhum mock foi usado. Previsto na implementação: teste com o MCP real nos dois estados, chave antiga redigida e chave nova legível.

## Resposta esperada

Dispensável para a 0.20.0 do LinkedIn. Se o responsável adotar uma das alternativas, indicar a versão do MCP que a contém.

## Evolução e encerramento

Revisão 1: registro inicial, no planejamento da 0.20.0. Será atualizado na implementação, com o resultado do teste contra o MCP vigente, e na entrega, com o hash do instalador.
