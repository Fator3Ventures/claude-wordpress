# Entrega — Fator3 MCP Google 0.28.0

Revisão 1 · 05/11/2026 · Implementação e revisão do código, testes, interface e documentação. Estado **com-pendencias**. O Google 0.28.0 foi instalado e está ativo no Site-Teste. A release corrige falhas reproduzidas no painel da 0.27.0 e protege o histórico do planejador contra páginas inválidas.

## 1. De onde esta versão entra

Instalação limpa ou atualização direta de `wp-mcp-google-fator3` 0.27.0. A base foi a última entrega da própria conversa, com instalador de 913.917 bytes e SHA-256 `c6819912d0280925d9d1de09571d972bc966b6fa8c9351b8468f6944335a5678`. O fonte-base de 7.309.425 bytes tem SHA-256 `c70a90dd4018249ac0b6aa2e7401bd43b5fe0385ff29228dbea8bce69e9ef7c7`.

Requisitos publicados: PHP ≥ 8.3 e WordPress ≥ 7.1.4. A bancada executou WordPress 7.1.4, PHP 8.3.6 e MySQL 8.0.46. O patch PHP 8.3.0 exato ficou fora da execução. As duas referências obrigatórias do projeto foram relidas integralmente: `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, revisão 5 de 02/11/2026.

## 2. Convivência e encaminhamentos

| Pacote | Bancada principal | Conjunto observado após a instalação |
|---|---|---|
| Google | 0.28.0, ou 0.27.0 na origem da atualização | 0.28.0 ativo |
| MCP | 0.39.0 | 0.40.0 ativo |
| Site Core | 1.70.0 | 1.71.0 ativo |
| Meta | 0.20.0 | 0.20.0 ativo |
| LinkedIn | 0.18.0 | 0.18.0 ativo |
| Pipedrive | 0.6.0 | 0.6.0 ativo |

O inventário imediatamente anterior à troca ainda tinha MCP 0.39.0 e Core 1.70.0. A operação desta rodada foi exclusivamente sobre o Google. Os instaladores MCP 0.40.0 e Core 1.71.0 foram recuperados e identificados para a verificação complementar do conjunto final. Manifestos separados permitem reproduzir tanto a bancada da migração quanto o par final.

A responsabilidade pelas correções identificadas pertence ao Google. Foram avaliadas as fronteiras de transporte MCP, conversões e leitores do Core e o bootstrap com os acompanhantes. Nenhum contrato de integração exige alteração em outro pacote. As 305 abilities, as 43 definições públicas de configuração, o slug e o basename continuam disponíveis. O catálogo agora informa o impedimento local de uma consulta ao planejador ou ao arquivo com maior precisão.

## 3. Mudanças e evidência

O pedido desta rodada é a revisão geral de código, testes, UI e documentação. O planejador entregue em **Pedidos MCP Google 49** faz parte do recorte revisto. Nenhum número de ticket novo foi atribuído.

| Cenário revisado | Comportamento observado | Alteração entregue |
|---|---|---|
| Consulta de listas Google | A 0.27.0 atribuía um booleano a um contador inteiro de escopo administrativo, causando `TypeError`. A chave de cache das escolhas também usava um prefixo recusado pelo próprio cache. | Corrigido o contador com restauração em `finally`. Listas completas ficam cifradas por identidade, conexão, tipo e recurso pai por 15 minutos. Uma resposta parcial ou erro conserva a última lista completa até seu vencimento. Falha de gravação tem diagnóstico próprio. |
| Conversões | Uma ação ausente ou desconhecida podia cair no ramo de gravação. O teste na base confirmou a remoção de um cliente Ads salvo. A consulta de listas também misturava os dois serviços. | O painel aceita ações explícitas e confere a conexão do formulário. Ações inválidas, contexto divergente e revisão antiga preservam o destino. GA4 e Ads têm controles separados para consultar propriedades/fluxos e contas/ações. A consulta conserva a seleção em edição. |
| Navegação e configuração | “Verificar acessos” abria limites e auditoria. A conexão, os serviços e a política apareciam em uma página longa. O retorno de alguns formulários perdia o painel de origem. | A aba Conexão tem Identidade, Serviços e recursos e Permissões. Os atalhos antigos abrem o destino correspondente, e o retorno após salvar conserva conexão e painel. A prévia de redução continua funcional sem JavaScript. Desabilitar um serviço preserva os vínculos existentes. |
| Acervo Ads | A edição apresentava janelas de 90/7 dias e todos os conjuntos, mesmo quando havia uma conta configurada com 45/3 dias e um único conjunto. | O seletor abre os valores salvos da conta, incluindo os leitores. A criação começa com coleta desligada; tentar cadastrar uma conta já configurada orienta a abri-la para edição. A tela separa coleta, leitura por outro plugin e estado do planejador. |
| Histórico do planejador | A base aceitava uma linha malformada como palavra `null`. O horário SQL de um checkpoint podia mudar o resultado de um filtro por data. | O planejador valida a página antes de arquivá-la. Campos inválidos retornam `f3_google_keyword_response` e conservam o último cursor. Resposta válida vazia continua aceita. A normalização usa blocos de cem. O filtro lê a data UTC de observação e alcança também recibos anteriores. A listagem usa cursor estável e examina até 200 recibos por chamada. |
| Uso e acessibilidade do painel | Campos de escolha tinham ajuda pouco específica e IDs repetíveis; edição dinâmica de perfis precisava manter nomes, rótulos e foco. | Adicionados textos associados aos campos, grupos GA4/Ads com legendas, foco visível, controles ajustáveis à largura, indicação do painel ativo e nomes estáveis para linhas de perfil. O estado de edição também acompanha adições e exclusões. |
| Documentação instalada | Guias de entrada acumulavam instruções de várias versões, inclusive procedimentos antigos de instalação. | Novo guia por tarefa e aba, manual autônomo do planejador, índice, guia de agentes, atualização e validação. Os arquivos editáveis e a documentação compilada são conferidos no build. |

Pontos de código principais: `includes/Admin.php`, `includes/Admin/Screen.php`, `ConversionScreen.php`, `ArchiveScreen.php`, `Resources.php`, `includes/Policy.php`, `includes/SetupAdmin.php`, `includes/Ads/PlannerRequest.php`, `KeywordPlanner.php`, `ArchiveStore.php`, `includes/Catalog.php` e `assets/admin.{css,js}`. As mudanças de comportamento próprias estão cobertas por testes específicos, além das suítes reaproveitadas de renovação e integração.

## 4. Instalação e prova de prontidão

| Execução | Verificações aprovadas | Escopo |
|---|---:|---|
| Base 0.27.0 | 7, separadas da candidata | Reprodução do destino de navegação errado, formulário com janelas padrão, gravação indevida, descoberta interrompida, chave de cache recusada e resposta Google malformada. |
| Google 0.28.0 isolado | 131 | Instalação limpa, storage, funções próprias, autorização e planejador sem acompanhantes. |
| Conjunto principal | 465 | Cinco acompanhantes ativos, transporte do Core, renovação, formulários, planejador e documentação integral por MCP. |
| Atualização 0.27.0 → 0.28.0 | 159 | Troca autenticada do ZIP, processo novo, configurações, criptografia, pausas, auditoria, cursores e leitura de recibo gravado pelo codec 0.27.0. |
| Interface por HTTP e DOM | 48 | Inclui 43 na suíte do painel. HTML servido pelo wp-admin, JS instalado, formulários enviados ao servidor, retorno à conexão correta, vínculos com JS desativado, rótulos e recusa ao assinante. Ambiente jsdom 27.4.0. |
| Volume e paginação | 7 | 10.000 entradas e saídas com 12 observações mensais por termo, reconstituição UTF-8 e filtro paginado em 202 recibos com inserção concorrente. |
| **Candidata na matriz principal** | **810** | Soma das cinco execuções anteriores da 0.28.0, sem contar a reprodução da base. |
| Conjunto final MCP 0.40.0 / Core 1.71.0 | **201** | Quatro suítes com os instaladores finais: ativação dos três acompanhantes, prontidão do Core, 151 verificações do transporte e 45 de integração e painel. Zero falhas nas execuções finais. |

Foram 1.011 verificações da candidata ao somar as 810 da matriz principal e as 201 do conjunto final. O total inclui cenários repetidos em instalações diferentes. O ensaio com 10.000 linhas teve pico PHP de **147.156.992 bytes**. Na execução equivalente registrada para a 0.27.0, foram 149.422.080 bytes. São medidas do processo de laboratório e da fixture específica, sem extrapolação para o site público.

O instalador contém 175 arquivos. Os 171 arquivos PHP passaram no lint. O build verificou catálogo, schemas, documentação compilada e links locais. Foram comparados integralmente os bytes dos plugins instalados na bancada com seus respectivos ZIPs. O WordPress de teste bloqueou e-mail e HTTP externo. O Google, o correio e medições de tráfego real não foram usados para certificar os resultados sintéticos.

**Site-Teste.** A operação `76006fdbc8bc82f72b2280d527a4a7b0` aplicou o instalador pelo MCP com `expected_slug=wp-mcp-google-fator3`, SHA-256 da seção 8 e chave idempotente própria. A versão avançou de 0.27.0 para 0.28.0 e permaneceu ativa. As sondas em `/` e `/wp-json/` retornaram HTTP 200 antes e depois. O MCP registrou backup da operação.

- Os 25 itens do índice documental remoto coincidem em tamanho e SHA-256 com os documentos instalados da bancada. `GUIA-0.28.0.md` e `PLANEJADOR.md` foram lidos integralmente em duas páginas cada. O conteúdo coincidiu com os editáveis. Nas bancadas de instalação e atualização, cada leitura integral do índice percorreu 87 páginas e 4.413.895 bytes pelo MCP, sem tráfego com o Google.
- As 43 definições compactas públicas ficaram idênticas antes e depois. A revisão automática recusou a consulta ampla de valores efetivos pelo risco de expor configuração privada. A conferência remota usou os schemas públicos; preservação dos valores e dos registros cifrados foi comprovada na migração local.
- `google/readiness-status` manteve o diagnóstico anterior: credencial Google ausente, serviços de conversão sem destino selecionado e armazenamento, recuperação, executor, incidentes e Core em estado `ok`. `google/ability-catalog` retornou as quatro consultas do planejador e o leitor local no modo de leitura, todos indisponíveis porque Ads está desligado naquela conexão.
- A instalação, configuração e distribuição das outras unidades da frota não fizeram parte da operação. Nenhuma sonda, conta sintética, destino ou segredo foi criado no Site-Teste. A frota publica e confere o instalador raw antes da distribuição. Não houve push nesta rodada.

Evidências sanitizadas em `plugin/wp-mcp-google-fator3/evidence/028`. Reprodução em `reproducao/LEIA-ME.md`, com os manifestos dos dois conjuntos de versões.

## 5. Banco, migração e correção por nova versão

A atualização usa a estrutura existente. O primeiro acesso lê o arquivo e os recibos já gravados. Uma página inválida não avança a contagem nem o cursor do histórico. A listagem por data usa o instante da observação cifrada, inclusive quando uma versão anterior registrou um checkpoint em outro dia. Uma página filtrada vazia pode indicar que ainda há registros a examinar; siga `next_before_sequence` até nulo.

As listas de recursos consultadas pelo administrador usam o armazenamento temporário cifrado. A ausência de cache leva a uma consulta explícita. A atualização não inicia coleta nem amplia autorização. Preserve banco e salts nos backups de dados. Para corrigir regressões após a troca, contenha o fluxo afetado e distribua uma nova release, preservando recibos e revisões.

## 6. Pendências e limites

| Responsável | Situação |
|---|---|
| Mantenedor / QA | A suíte de Chromium de ponta a ponta foi escrita no fonte. O executável local foi interrompido pela política de sockets do ambiente. O navegador disponível fora do laboratório não alcançou seu endereço de loopback. Permanecem pendentes a inspeção visual e as verificações de geometria em 1440×900 e 390×844. HTTP e DOM foram exercitados separadamente. |
| Mantenedor / QA | A suíte histórica integral de PHPUnit não foi executada. O runner estava ausente e o acesso à distribuição oficial expirou. Lint e verificações nativas são registrados separadamente. |
| Dono do projeto Google / operador autorizado de ctooffice | Permanece o aceite externo do Pedido 49 após acesso Basic: comparar três termos com o painel Ads e conferir ideias pela URL Engagia. As pendências históricas de acervos e entregas comerciais seguem sob homologação da frota. |
| Frota | Publicar e distribuir quando autorizado, com conferência do SHA-256 servido. Apenas o Site-Teste foi atualizado nesta rodada. |

## 7. Credenciais e configuração do dono

O plugin mantém as identidades já configuradas. Para usar uma conta real, selecione a conexão em **Ferramentas → Fator3 MCP Google → Conexão → Identidade**. Em **Serviços e recursos**, escolha o perfil de operação, o cliente Ads e, quando aplicável, sua gerenciadora e o nível declarado do projeto. Em **Permissões**, restrinja os recursos. Para GA4, confira a propriedade, o fluxo e o segredo do Measurement Protocol no destino apropriado. O relatório e as evidências não contêm valores de credencial.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | `wp-mcp-google-fator3-0.28.0-instalador.zip` | 916324 | `10d3722e12d1493308273ab0febbabe68f8dd4c901c7abb3a7c03d3cec3e8919` |
| Fonte | `wp-mcp-google-fator3-0.28.0-fonte.zip` | 7402407 | `4b160221dc738ea8fd095f6087fa67f4538d6da1c0f2c079e74828c52df04019` |

Este relatório externo é canônico. A cópia no fonte antecede o seu fechamento. O instalador foi reconstruído a partir da árvore extraída do ZIP de fonte e comparado byte a byte com o ZIP instalado no Site-Teste.
