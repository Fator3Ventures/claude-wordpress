# Entrega — Fator3 MCP 0.40.0

Revisão 1 · 2026-11-05T10:53-03:00 · Implementação e revisão de código, testes, configuração e documentação · **Apta no escopo testado**. MCP 0.40.0 ativo no Site-Teste.

Identidade: `wp-mcp-fator3/wp-mcp-fator3.php`. Normas efetivamente lidas: `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, ambas revisão 5 de 02/11/2026. A solicitação desta rodada veio do dono, sem novo número na aba de pedidos. O checklist da seção 14 foi conferido. Os limites estão na seção 6.

## 1. De onde a versão entra

WordPress limpo ou atualização direta a partir do MCP 0.39.0. Base da própria entrega anterior: instalador de 920.888 bytes, SHA-256 `158760eb738041848193611de4b07ea18d0dd4755f99f15e0735e28d90edae48`; fonte de 4.325.511 bytes, SHA-256 `e693abba43d2be07f456d62a6b0612767553502cbd2eddce98f92c882cf9c4ed`. Identidade confirmada com o relatório e com o inventário remoto anterior à troca.

Requisitos do projeto: WordPress ≥ 7.1.4 e PHP ≥ 8.3. Bancada: WordPress 7.1.4, PHP 8.3.6, MySQL 8.0.46, Chromium 157.0.8103.38. Site-Teste: WordPress 7.1.4, PHP 8.3.36. Somente a nova versão opera após a atualização.

## 2. Convivência e encaminhamentos

Os cinco instaladores abaixo foram identificados pelos bytes e pelo cabeçalho, ativados juntos na bancada e conferidos no Site-Teste. Cada versão informada é a vigente de seu pacote. Nenhum acompanhante precisou de edição nem de ordem especial de troca para estas mudanças.

| Pacote | Versão | SHA-256 do instalador |
|---|---|---|
| base-site-core-fator3 | 1.70.0 | `a98245e9e0a41035e9f0439add1e41cd52ded7d43761a4112dd1d380848b9089` |
| wp-mcp-google-fator3 | 0.27.0 | `c6819912d0280925d9d1de09571d972bc966b6fa8c9351b8468f6944335a5678` |
| wp-mcp-linkedin-fator3 | 0.18.0 | `1e6c6e398ab2c507d827e428ae3b28099753459ef1b97a04ddf1c3922d819460` |
| wp-mcp-meta-fator3 | 0.20.0 | `2f229301c8dd08357ed9d023edc1d610ac1b78e01114dce45913e1979b95399b` |
| wp-mcp-pipedrive-fator3 | 0.6.0 | `0cfec48e6142064d6024b49e9026e79e359178ae04846fd5c442597c6b70908e` |

O MCP preserva os schemas de entrada e saída de suas **167 habilidades** comparadas. A ordenação da busca documental prioriza os guias atuais. A revisão incidiu na administração do MCP, políticas por identidade, limites, tratamento da fonte própria e documentação. A seleção dos provedores e os contratos de domínio dos acompanhantes não mudaram. Nenhum impacto individual novo foi identificado neste escopo. A integração examinou registro/descoberta via transporte e o uso de uma estrutura de leads clonada do Core vigente. O ensaio não chama APIs comerciais.

## 3. Mudanças e evidência

| Fluxo | Achado na base | Correção e prova |
|---|---|---|
| Associar, editar e revogar | Na 0.39.0, a associação sem revisão substituiu um perfil Personalizado por Leitura. A ação de revogação compartilhava o formulário de edição. | A lista abre o editor sob demanda. Associação só cria o primeiro perfil, edição confere a revisão e revogação usa formulário independente com confirmação no servidor. Campos truncados ou contas inválidas são recusados. Teste de duas abas confirmou que o perfil salvo pela primeira prevalece. |
| Emissão de senha | As duas telas implementavam separadamente a emissão e a limpeza em caso de falha. Na base, uma exceção ao gravar a política podia interromper a limpeza. A emissão por formulário usava a página genérica de resposta do WordPress. | Página inicial e editor usam a mesma emissão. Uma falha de escrita induzida no MySQL deixou intacta a quantidade de senhas da conta. O formulário completo tem um identificador de uso único: repetir o POST não cria nem reexibe senha. O resultado mostra conta, perfil e identidade; o segredo fica recolhido até ser solicitado. A referência de repetição é armazenada sem o segredo. |
| Listar clientes | O carregamento consultava sessões uma vez por identidade e montava a lista inteira de habilidades mesmo antes de abrir o editor. Todas as abas inicializavam o diagnóstico das rotas. | Sessões da página são contadas em uma consulta agrupada. O editor, a seleção de conta e o diagnóstico carregam apenas nas telas que precisam deles. A lista mostra validade, último acesso UTC e sessões. No celular, cada cliente tem os campos rotulados e a ação visível. |
| Arquivos e banco | O canal tinha controles redundantes e a escrita podia ser salva a partir de uma tela desatualizada. | Acesso, escrita, transferência e retenção têm ações separadas. O painel distingue a preferência do estado efetivo sob bloqueio. As revisões de opções são conferidas sob trava contra a linha persistida. Uma cópia desatualizada no cache WordPress não pode apagar a configuração concorrente de outro pacote. |
| Atualizações | Um endereço simples gravado por `system/settings-update` era exibido como vazio. Salvar um endereço nessa situação provocava `TypeError`. | A tela apresenta a URL como “A confirmar”. Somente ao salvar explicitamente o operador a transforma em descritor. O teste exercitou gravação, conflito, URL/host inválidos e remoção apenas da entrada MCP. A política da frota por ZIP versionado continua documentada como fluxo habitual. |
| Ajuda e documentação | O manual administrativo ainda se apresentava como 0.28.0. O painel apenas selecionava documentos; o agente já dispunha de busca por seção. | O manual agora cobre as tarefas e efeitos das telas 0.40.0. A Ajuda usa a busca do guia instalado para abrir o trecho encontrado e preservar paginação e hash. A navegação por teclado, o estado vazio e a recusa de cursor de outro documento são testados. |

### Custo da renderização do painel

Mesma base WordPress, mesmos 31 registros, cinco acompanhantes ativos e processos novos antes/depois. Contagem SQL durante `Admin::render` e bytes de HTML do painel. As medições excluem o bootstrap do wp-admin e não representam duração de uma requisição inteira.

| Tela | Consultas SQL | Inicializações REST | Bytes de HTML |
|---|---:|---:|---:|
| Clientes conectados | 70 → 2 | 1 → 0 | 228.968 → 17.894 |
| Arquivos e banco | 9 → 3 | 1 → 0 | 7.604 → 7.285 |
| Ajuda | 6 → 0 | 1 → 0 | 10.958 → 13.815 |

Em Clientes conectados, as consultas específicas de contagem de sessões passaram de **31 para 1** e o número de caixas de seleção de habilidades na lista passou de 836 para zero. As habilidades continuam disponíveis na edição do perfil. Arquivos: `baseline-defects.json` e `page-<versão>-<aba>.json`.

## 4. Instalação e prova da troca

| Cenário | Resultado | Evidência no fonte |
|---|---|---|
| Instalação limpa, MCP isolado | Ativação pelo WordPress em banco novo e execução em processos separados. 33 verificações de configuração e autorização, incluindo persistência, falha induzida e recusa de editor/subscriber. | configuration-writers.json |
| Migração 0.39.0 → 0.40.0 | 12 verificações; senha de aplicação, perfil, limite, retenção, canal de outro plugin e recibo incerto preservados. A prévia de restauração emitida na base concluiu na nova versão. | migration-before.json, migration-after.json |
| Navegador, WordPress integrado | 56 verificações no Chromium. Oito telas, desktop 1365×900 e celular 390×844, ações reais de um administrador, edição concorrente, emissão/replay/revogação, erro de retenção, nonce inválido, editor sem autorização, teclado e pesquisa. Sem exceção JavaScript nos fluxos aprovados do pacote fechado. | browser.json |
| Regressão SQL do pedido 77 | 39 verificações: escopo de linhas, conflito, BLOB/NULL, tabela de 100.001 linhas, concorrência, interrupção e restauração. | row-backup.json, scale.json, interruption-and-lock.json |
| Cinco acompanhantes e guia instalado | 57 verificações incluindo descoberta das ferramentas, saúde, leitura integral local dos documentos e UPDATE/restauração em cópia sintética da estrutura real de leads do Core. | integration-and-guide.json, schema-parity.json |
| Empacotamento | **197 verificações funcionais locais** nas linhas acima. Separadamente, 15 verificações do pacote, sintaxe de 461 arquivos PHP, sintaxe do JavaScript e igualdade de todos os 474 arquivos em ambas as instalações. | package-check.json, installed-parity.json |
| Site-Teste | O próprio conector instalou o ZIP pelo arquivo verificado, com slug e hash esperados. Operação `75e9230fba0d9e84678ad69d33a9278c`. Home e REST responderam 200 antes e depois. Em nova requisição, `system/health` confirmou 0.40.0 saudável, com zero recuperações pendentes. Os outros oito plugins conservaram versão e atividade nesta janela. | site-teste.json |
| Aceite remoto da interface distribuída | 10 arquivos amostrados no site, incluindo CSS, JS, controladores e telas, tiveram SHA-256 igual ao ZIP. Listagem autorizada respondeu pelo MCP. Guia confirmou 39 documentos instalados lidos integralmente em 45 páginas, com bytes e SHA-256 iguais ao fonte. Busca “revogar acesso” retornou primeiro `administracao`; caminho fora do índice foi recusado. | runtime-files.json, site-guide.json, site-teste.json |

A configuração da frota segue a publicação do ZIP e relatório pelo responsável e a verificação dos bytes servidos na URL raw. Destino previsto: `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/wp-mcp-fator3-0.40.0-instalador.zip`. Usar `plugins/upload` com URL conferida, `expected_slug: wp-mcp-fator3`, `expected_sha256` da seção 8, overwrite e activate. Nesta rodada só o Site-Teste recebeu o arquivo. O ZIP temporário da transferência foi excluído por hash. As sondas e o recibo da instalação permanecem no histórico. A interface de formulários foi exercitada na bancada, e os arquivos correspondentes foram verificados no Site-Teste.

## 5. Banco, migração e correção por nova versão

A instalação não cria tabela, não reemite credenciais nem altera preferências por padrão. A emissão pelo formulário usa o bucket de idempotência existente para reservar uma solicitação antes de criar a senha. O comprovante registra a identidade/resultado, sem guardar a senha criada. A retenção existente continua aplicável. Falha após emissão exige consultar o estado da conta antes de tentar outra ação. Backups SQL anteriores e confirmações em andamento foram exercitados. Uma correção depois da instalação segue em nova versão.

## 6. O que permanece pendente

- **Frota / pedido MCP 77 anterior.** A verificação da escrita específica no registro 46 de korvena.com.br não integrou esta rodada. Este relatório mantém o aceite em produção com a frota e não atribui causa aos 502 históricos.
- **PHP 8.3.0 exato.** O piso está declarado; os binários exercitados foram 8.3.6 e 8.3.36. A bancada executou o WordPress mínimo 7.1.4.
- **Limites de escopo.** Os testes HTTP, de navegador e os dados de falha induzida usaram instalações descartáveis. Nenhuma alteração de política de acesso de pessoas reais foi executada. Não se certificam outros navegadores, contas comerciais ou integrações externas completas a partir desses testes.

## 7. Credenciais e configuração do dono

Ferramentas → Fator3 MCP exige `manage_options`; a edição de identidade também exige autorização sobre a conta. A alteração de fonte requer `update_plugins`. Conexões existentes preservam usuário, perfil e credenciais. Para emitir uma nova senha, escolha a conta e o perfil no painel, revele o valor na página de confirmação e copie-o diretamente para o cliente. Para apenas revisar a instalação, leia Ajuda ou `system/guide` com `document: "release-0400"`; nenhuma senha nova é necessária.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | [wp-mcp-fator3-0.40.0-instalador.zip](./wp-mcp-fator3-0.40.0-instalador.zip) | 932250 | `2434f99df49c56b6f0200d0ddca18c6dffe1b7c6058c2c88f04859f1e046bd81` |
| Fonte | [wp-mcp-fator3-0.40.0-fonte.zip](./wp-mcp-fator3-0.40.0-fonte.zip) | 4365881 | `f6a05b6f86745ffa08fac7ada577cbb555cef67e963085f91788c2d4895eda54` |

Relatório externo canônico. A cópia no fonte é anterior ao fechamento. O instalador foi reconstruído a partir do ZIP fonte e comparado aos bytes instalados no Site-Teste.
