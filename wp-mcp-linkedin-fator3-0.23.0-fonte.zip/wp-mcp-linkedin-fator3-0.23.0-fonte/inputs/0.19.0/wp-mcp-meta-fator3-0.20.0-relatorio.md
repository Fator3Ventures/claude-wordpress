# Entrega — Fator3 MCP Meta 0.20.0

Revisão 1 · 2026-11-05T08:41:46-03:00 · Implementação. **Status: com pendências de homologação visual e de fornecedor.** Instalado e ativo no Site-Teste. Slug/provider: `wp-mcp-meta-fator3`; basename: `wp-mcp-meta-fator3/wp-mcp-meta-fator3.php`.

## 1. De onde esta versão entra

Base direta: **0.19.0**, instalador original de 342993 bytes, SHA-256 `f7629f48fffb774542a480fb55f29a151762b06a27b34c9a0c3188da3599451b`; fonte SHA-256 `21d13446e4b18cec279bfaf8c0bde0d3f93008e9832fe0b7f560ee1095c95ead`. As duas identidades foram conferidas antes do trabalho. Esta release atende ao pedido direto de revisão do código, configuração, UI, testes e documentação. Esse pedido não recebeu novo ID na aba da frota. O Pedido MCP Meta 27 é anterior e mantém seu aceite externo pendente.

Aplicados integralmente `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, ambos revisão 5 de 02/11/2026. Plano e escopo em planning/PLANO.md. Cabeçalho, readme e build declaram **WordPress ≥ 7.1.4 e PHP ≥ 8.3 de 64 bits**. Build/lint: PHP 8.3.6, Python 3.12.14, zlib 1.3.2. WordPress observado: 7.1.4, PHP 8.3.36, MySQL 8.4.11. Não se afirma teste no patch 8.3.0 exato. Instalação limpa e atualização direta cobertas; nenhuma matriz de versões antigas ou downgrade.

## 2. Convivência e encaminhamentos

No início, o Site-Teste apresentava Core 1.69.0, MCP 0.38.0, Google 0.26.0, LinkedIn 0.17.1 e Pipedrive 0.5.0. Outros fluxos de manutenção atualizaram três acompanhantes antes da troca do Meta. A ocorrência foi detectada sem sobrescrever trabalho alheio. Conjunto observado imediatamente antes e depois da instalação do Meta: **Core 1.69.0, MCP 0.39.0, Google 0.27.0, LinkedIn 0.18.0 e Pipedrive 0.5.0**. Nos cinco, versões, ativação e hashes completos da árvore permaneceram iguais durante a troca. A versão inicial de cada um não é matriz suportada.

O Meta usa as mesmas 47 operações, contratos SDK, nomes, tipos de entrada e envelope de saída. Os catálogos de entradas, saídas e rótulos públicos são byte a byte idênticos aos da base. No conjunto vigente verificamos transporte MCP, capabilities, índice/ajuda, saúde e registro de consumidores. Em instalação limpa, Meta funciona sozinho. As melhorias estão no painel e na apresentação de documentos; não exigem nova concessão nem ordem especial de troca entre plugins. Não surgiu impacto técnico que exija alteração de Core, MCP, Google, LinkedIn ou Pipedrive. Nenhum relatório individual de impacto foi emitido. A coexistência medida não equivale à homologação de todas as funcionalidades desses plugins.

## 3. Mudanças e evidências

| Fluxo | Achado na base | Alteração entregue e prova |
|---|---|---|
| Renovação de credenciais | Uma candidata digitada para A continuava no formulário ao editar B. A validação do servidor ainda existia, mas o operador podia enviar um valor ao destino errado. | Limpa token, validade, prévia e controles de remoção ao mudar de destino. Exibe o nome da conexão antes de renovar. Respostas de edição vencidas não substituem o novo alvo. Testes DOM exercitam A→B, nova conexão e confirmação por revisão. |
| Organização da configuração | Nome, app, segredo, token, validade e retenção dividiam a mesma grade; remoção aparecia junto às ações habituais. | Quatro grupos orientam o cadastro: identificação/aplicativo, acesso à Meta, retenção e usuários. Descrições associadas por ID, instruções longas em detalhes expansíveis, remoção/renovação disponíveis apenas na edição. Formulário de Conversas separa página/aplicativo da autorização de recepção e contatos. |
| Retenção | O formulário enviava dias mesmo em modo ilimitado. Um campo oculto também participava da validação do navegador. | Somente o modo finito habilita/exige/envia os dias. Ao escolher ilimitado, o servidor preserva o valor anterior do prazo e aplica a política sem expiração. Teste integrado: 321 dias → ilimitado, sem perder o valor armazenado; revisão antiga recusada. |
| Diagnóstico | Abrir a aba chamava status, com possibilidade de reparar cron. A seleção podia consultar nomes no fornecedor. | Abertura lê health; seleção usa ativos locais e não carrega campos de relatório. Recuperação de agendamento e validação da conta são comandos explícitos com efeitos descritos. Testes do painel capturam as operações; no WordPress, health deixa um worker ausente sem rearme. |
| Ajuda | A seleção podia mostrar texto da leitura anterior. O leitor calculava o índice de todos os documentos inclusive para páginas que não o retornavam. | Guia do painel como primeira leitura, estado de conclusão, revisão fixa e descarte de resposta obsoleta ao trocar o documento. Calcula o índice apenas quando a resposta o exige. Sem alteração do contrato. Sem alegação de ganho de latência sem medição. |
| Acesso ao painel | Uma negação chamava wp_die com 403 na posição de título; um parâmetro tab não escalar podia produzir aviso de conversão. | Resposta administrativa 403 explícita, aba inválida volta a Conexão. WordPress real: assinante recusado no painel e nas rotas de configuração, conta e documentação. |
| Documentação | Guia misturava instruções de outros plugins, bases anteriores e procedimento de retorno. | Índice orientado por tarefa, guia de configuração e administração, atualização a partir da 0.19.0 e recuperação por versão corretiva. Histórico de mudanças identificado; guia de monitoramento do Pedido 27 preservado. |

### Matriz executada com o ZIP final

| Escopo | Suíte | Verificações | Falhas |
|---|---|---:|---:|
| DOM | ui-dom | 19 | 0 |
| DOM | ui-identity | 22 | 0 |
| DOM | ui-monitoring | 15 | 0 |
| DOM | ui-messaging | 17 | 0 |
| WordPress | clean-smoke | 36 | 0 |
| WordPress | clean-configuration | 16 | 0 |
| WordPress | clean-dataset | 77 | 0 |
| WordPress | migration-result | 14 | 0 |

**Total: 216 verificações, zero falhas** (73 de interface e 143 no WordPress). As 19 verificações específicas de interface, mais os 16 casos WordPress de configuração, incluem novas regressões desta rodada. As 22 de credenciais, 15 de monitoramento e 17 de conversas exercitam o JS do candidato em jsdom 27.4.0 com REST simulado. Não medem layout de navegador. A suíte dataset executou Jobs, consultas e verificações com 150 respostas HTTP sintéticas: 77 verificações e nenhuma chamada real ao fornecedor. Os testes de autorização, retenção, ajuda e upgrade usaram WordPress/banco reais.

Sintaxe dos 34 PHP verificada pelo build. Os 66 arquivos de runtime instalado conferem com o pacote; esquemas públicos preservados. Evidências intermediárias estão segregadas em evidence/candidate. Uma fixture da série 0.13 esperava apenas um relatório no canal de anúncios; foi substituída pela já existente que contempla também ads_activity e passou. Os ensaios intermediários e confirmações documentais não aumentam o total final.

## 4. Instalação e prova da troca

Site autorizado: https://fator3-teste-mcp-1.dreamhosters.com/. Instalação por `plugins/upload-base64`, com bytes do ZIP, expected_slug e expected_sha256, sem publicar no repositório público. Operação `6305ef5f68263d5244835f04146bb3ce`; recibo `a4975e9676263091e92031a5`; 0.19.0→0.20.0, ativo antes/depois. Sondas internas de / e /wp-json/ antes e depois com HTTP 200; elas não comprovam acesso externo. Para distribuição na frota, o responsável publica o instalador e o relatório na raiz raw de Fator3Ventures/claude-wordpress, confere o SHA dos bytes servidos e só então usa plugins/upload com as guardas. Não há publicação raw por esta manutenção.

- **Instalação limpa:** WordPress 7.1.4 com somente o Meta ativo, em prefixo privado, sem credencial externa. Renderização administrativa, REST, integridade do runtime e documentos passaram. Em migração separada, 13 registros de negócio e quatro linhas históricas cifradas permaneceram idênticos, incluindo pausas, política finita, grants e estado de agenda.
- **Prontidão:** meta/health com parâmetros vazios retornou versão 0.20.0, estado ok, armazenamento/criptografia prontos, auditoria íntegra, 0 conexões e 0 agendas ativas. A árvore final do Meta tem SHA-256 `0874c8af528ace6989f8faf518baf854630737cc6a03a6b237bb906553f2011d`.
- **Documentação:** índice de 28 itens antes/depois. Após a troca, leitura integral dos 28 documentos pelo MCP em 31 páginas, com expected_revision, bytes e SHA conferidos contra o instalador. No laboratório, o guia administrativo foi reconstituído em 17 páginas de 256 bytes, com recusa de revisão divergente e de travessia de diretório. Ajuda e leitura de saúde não fizeram chamadas externas na suíte específica.
- **Integridade compartilhada:** dois registros de negócio intactos, histórico vazio, sete opções e hashes individuais idênticos, configuração de monitoramento Core idêntica no intervalo imediato de troca. Auditoria técnica das operações de QA não entra no digest de negócio. Nenhuma alteração na versão/arquivos dos cinco acompanhantes nesse intervalo.
- **Limpeza:** os dois laboratórios finais foram desmontados; 14 tabelas exclusivas removidas em cada um, zero remanescentes, diretórios e manifestos removidos. Controller e bundle temporários removidos com guarda de SHA e backup. Descoberta normal final: 47 operações Meta, todas 0.20.0, nenhuma habilidade de QA.

## 5. Banco, migração e correção por nova versão

Nenhuma tabela, coluna, opção de negócio ou migração de dados nova. A atualização não regrava credenciais, concessões, seleção, retenção ou jobs. Tokens/segredos vazios na edição preservam os valores existentes. A retenção sem expiração continua como padrão. Na atualização, preserve backup consistente de banco e salts. Se uma falha aparecer após instalação, contenha o fluxo afetado, preserve o estado e entregue correção em nova versão; não há downgrade. Antes de repetir uma escrita de resultado incerto, releia a revisão e os recibos do efeito.

## 6. Pendências

- **UI autenticada e dispositivos:** o navegador do Site-Teste chegou ao login do WordPress. A interface foi exercitada com HTML real do plugin e jsdom, e o painel foi renderizado em WordPress como administrador. A validação visual autenticada, de layout móvel e com leitor de tela permanece pendente. Responsável: manutenção, em sessão administrativa autorizada.
- **Fornecedor e frota:** os testes não usaram credenciais Meta de produção nem contas reais; não houve gasto Ads, publicação, contato ou e-mail real. O aceite do Pedido27 em korvena.com.br e ctooffice.com.br permanece com a frota: nova execução de dataset-qualidade-diario com o token salvo e leitura correspondente no Core, ou recusa legível com orientação. Mantêm-se as pendências 20 e 88 já registradas; o novo painel não as encerra.
- **Cobertura:** houve coexistência efetiva no conjunto instalado e exercício das fronteiras afetadas. Não houve homologação comercial completa de cada acompanhante nem instalação em produção. O teste local não afirma suporte a todo patch futuro.

## 7. Credenciais e configuração do dono

Ferramentas → Fator3 MCP Meta → Conexão: nome, App ID, App Secret, token de usuário do sistema e validade UTC quando houver. Atribuir os ativos e permissões de leitura pertinentes no aplicativo e na conexão. Use o guia CONFIGURATION.md para os escopos por uso; para Ads, confira ads_read. O proprietário confere a identidade antes de renovar e seleciona os ativos em Ativos; descobrir não concede acesso. Para observação use Diagnóstico. Nenhuma credencial real está nos artefatos.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | wp-mcp-meta-fator3-0.20.0-instalador.zip | 332569 | `2f229301c8dd08357ed9d023edc1d610ac1b78e01114dce45913e1979b95399b` |
| Fonte | wp-mcp-meta-fator3-0.20.0-fonte.zip | 740886 | `3c99d98805db6075e22e3351cb15dd6493e117d8b1bb37b8b1076b869e4d7076` |

O instalador é o único ZIP instalável. O fonte contém build, runtime idêntico, testes, evidências sanitizadas e a cópia anterior ao fechamento do fonte. Neste documento externo os campos de identidade do fonte são preenchidos após empacotar; o ZIP não contém outro ZIP. Nenhuma credencial ou instalação de laboratório está incluída.
