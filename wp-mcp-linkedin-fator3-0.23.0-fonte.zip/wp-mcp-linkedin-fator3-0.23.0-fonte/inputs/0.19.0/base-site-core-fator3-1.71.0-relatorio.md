# Entrega — Fator3 Site Core 1.71.0

Revisão 1 · 05/11/2026 · Revisão funcional, desempenho e qualidade da medição. Status `com-pendencias` pelos limites de cobertura de campo e de ambiente descritos abaixo.

## 1. Origem e requisitos

A versão entra em WordPress limpo ou por atualização direta da 1.70.0. A base canônica tem 4.266.812 bytes no instalador, SHA-256 `a98245e9e0a41035e9f0439add1e41cd52ded7d43761a4112dd1d380848b9089`. O fonte de referência tem 5.753.985 bytes, SHA-256 `ba59795f3d49e29d966c469f5776cbc789fc413728fae6d2a7d7270c68b401df`. A identidade do plugin é `base-site-core-fator3/base-site-core-fator3.php`.

Foram lidas integralmente as normas instrucoes-agentes-plugins-fator3.md e padrao-desenvolvimento-plugins-fator3.md, ambas na revisão 5 de 02/11/2026. Os mínimos declarados são WordPress 7.1.4 e PHP 8.3. A bancada executou WordPress 7.1.4, PHP 8.3.6, MySQL 8.0.46 e WP-CLI 2.12.0. O Site-Teste informou WordPress 7.1.4 e PHP 8.3.36.

## 2. Convivência

| Pacote | Primeiro inventário | Ativo no Site-Teste após a instalação |
| --- | --- | --- |
| Core | 1.70.0 | 1.71.0 |
| MCP | 0.39.0 | 0.40.0 |
| Google | 0.27.0 | 0.27.0 |
| LinkedIn | 0.18.0 | 0.18.0 |
| Meta | 0.20.0 | 0.20.0 |
| Pipedrive | 0.6.0 | 0.6.0 |

A bancada executou os testes com os cinco acompanhantes finais da tabela, incluindo o instalador MCP 0.40.0 que entrou durante a rodada. O Site-Teste também manteve WP Super Cache 3.1.5 e Yoast SEO 28.8 ativos. As identidades estão em `pacotes-vigentes.json`.

A mudança do contrato administrativo 8.32.0 → 8.33.0 acrescenta uma opção e campos opcionais à consulta de vitais. O modo detalhado continua sendo o padrão da operação. O painel passou a pedir somente resumo. A análise dos cinco acompanhantes não identificou adaptação obrigatória de chamada, schema próprio, permissão, configuração, callback, fila ou cron. O registro PHP completo continua disponível quando o MCP descobre o catálogo. O benchmark controlado mede as duas versões isoladas dos acompanhantes. O Site-Teste mede a composição compartilhada, onde as versões dos acompanhantes também evoluíram.

## 3. Mudanças e provas

A solicitação desta rodada foi a revisão de código, funcionalidades, testes, custo de carregamento e qualidade dos dados. Ela chegou sem um novo ID numérico de pedido. As verificações do pedido 369 pertencem à regressão da fronteira LinkedIn.

| Área | Problema encontrado e mudança entregue | Prova |
| --- | --- | --- |
| Inicialização do servidor | A visita carregava um arquivo com 101 inicializadores compilados. O gerador separa os registros públicos dos complementares. Administração, cron e descoberta REST promovem o registro quando precisam dele. | Registro PHP carregado na página de 95.237 para 11.745 bytes. Em 40 pares CLI, a mediana da etapa caiu de 3,56 para 1,62 ms e a memória incremental de 1.097.624 para 407.168 bytes. Equivalência dos callbacks em cinco perfis e seis rotas em WordPress. |
| Instrumentação PHP | O monitor participava do hook global e inspecionava callbacks e SQL das visitas anônimas comuns. Página e login anônimos agora dispensam a sonda detalhada. A solicitação assinada habilita a medição e identifica a própria resposta. O corte do relógio antecede a montagem do relatório e a soma preserva a precisão. | 44 verificações do despachante e 23 cenários HTTP. Perfil administrativo e REST, sessão, assinatura rejeitada e resposta antiga de cache cobertos. |
| Consentimento e formulários | O navegador montava um diálogo oculto e calculava cores no início da visita. Agora prepara o diálogo na primeira abertura, aproxima a leitura da paleta da entrada do rodapé na área visível e limita buscas aos nós relevantes em formulários dinâmicos. | No perfil público compilado e cenário padrão, leituras iniciais de estilo 13 → 0, canvas 1 → 0, elementos internos ocultos 8 → 0 e leituras de cookie 16 → 11. Quarenta inserções alheias passaram de 40 varreduras globais do formulário para zero. Evidência JSDOM 27.4.0. |
| Dados de campo | Havia p75 nulo exibido como zero, falha de consulta escalar convertida em zero e fases de LCP pré-renderizado com origens temporais distintas. A validação agora vincula as fases à métrica e respeita revogação antes de calcular atribuição. | 27 verificações WordPress/MySQL e 54 JS em seis ativos. Reenvio, atualização fora de ordem, CLS zero, legado e automação excluídos, lote de 501 registros, falha SQL e consentimento cobertos. |
| Leitura do painel | A tabela simples lia atribuições que não exibia. O novo modo `somente_resumo` retorna contagens, exclusões e p75. O modo detalhado informa o número de amostras de cada fase e compara somente as completas para eleger a dominante. | O teste observa o SQL da própria requisição. Zero consultas de atribuição no painel e no modo de resumo, com os mesmos percentis do modo detalhado. |
| Documentação | O guia MEDICAO-DESEMPENHO.md explica o que se mede, quais campos são coletados, como a amostra é reduzida e como comparar versões. Guias, contrato, exemplos e inventário foram atualizados. | 185 documentos, 801 páginas e 2.107 verificações booleanas em WordPress local, inclusive paginação, hashes, aliases, schemas, recusa de caminhos e de pessoas sem permissão. Recibo remoto na seção 5. |

## 4. Resultados de desempenho e cobertura

### Comparação controlada do tempo até o primeiro byte

Em cada versão e rota, alternamos 24 pares com o Core ligado e desligado. O cron estava parado, o OPcache aquecido e o cache integral de página desativado. O relógio mediu a requisição HTTP em loopback até o primeiro octeto. As sondas assinadas foram executadas à parte. A mediana do custo marginal é a mediana das diferenças dos pares.

| Rota | Mediana do acréscimo 1.70.0 | Mediana do acréscimo 1.71.0 | p95 do acréscimo 1.70.0 → 1.71.0 |
| --- | ---: | ---: | ---: |
| Inicial | 8,540 ms | 3,883 ms | 10,228 → 11,705 ms |
| Artigo | 8,470 ms | 2,997 ms | 10,177 → 8,206 ms |
| Login | 3,398 ms | 0,386 ms | 5,548 → 2,477 ms |

A mediana do acréscimo caiu nas três rotas. A inicial apresentou maior dispersão e aumento no p95. A faixa nominal de 95% para a mediana da candidata foi de 0,762 a 8,214 ms na inicial e de −0,733 a 1,494 ms no login. A carga compartilhada do host variou entre as duas execuções. O TTFB absoluto da inicial com o Core passou de 29,097 para 33,925 ms, e o artigo de 27,671 para 28,142 ms. A série preliminar e a repetição final estão separadas no fonte. Esses resultados não sustentam uma promessa de redução do tempo total por visitante.

As consultas adicionais permaneceram em 4, 5 e 0 por rota. A inicial e o artigo receberam os mesmos 13.877 bytes adicionais de HTML. O total dos arquivos próprios JS/CSS declarados nessa configuração cresceu de 100.344 para 100.857 bytes sem compressão. O perfil público mínimo mediu 20.409 → 20.602 bytes com gzip local de nível 9. O login não declarou arquivos do Core. Esses números não incluem uma execução dos scripts no navegador nem o tráfego posterior de terceiros. O ganho demonstrado no frontend foi a redução do trabalho inicial.

### Dados já existentes no Site-Teste

De 9 de outubro a 5 de novembro de 2026, a consulta de 28 dias excluiu dois registros legados por métrica. Entre os carregamentos sem marca de teste e sem sinal identificado de automação, havia duas amostras de TTFB (p75 862 ms), duas de LCP (p75 1.184 ms), duas de CLS (p75 0) e nenhuma de INP. Com duas observações o p75 corresponde à maior delas. Os testes marcados tinham respectivamente 81, 70, 38 e 4 amostras e são apresentados separadamente no inventário de medição.

O Core conserva cobertura de diagnóstico/replay em todas as visitas elegíveis pela configuração e pelo consentimento. O volume de vitais depende também do suporte do navegador, da interação e da entrega do lote. A linha local mantém a revisão mais recente da chave técnica, caminho, classe, largura, métrica e valor. A atribuição aceita alvos estruturais e fases compatíveis com LCP ou INP. A origem de um script no mesmo intervalo expressa coincidência temporal. A tela indica os denominadores, os descartes e as faltas de informação.

A tabela não armazena uma coluna de versão. Leituras de 28 dias feitas pouco antes e pouco depois da instalação compartilham quase toda a mesma população. A configuração efetiva de retenção de resumos/eventos no Site-Teste era de 120 meses, com janela de painel de 28 dias. Consulte `evidence/1710/medicao-analise.md` para o inventário dos sinais, retenção, recibos, filas, sanitização e limitações, incluindo a verificação de limite de 75 mil linhas anterior à admissão de uma chave nova.

## 5. Instalação, prontidão e verificação remota

O mesmo ZIP foi validado na instalação limpa e na atualização direta em WordPress descartável. Ambas passaram por execução do cron nativo, verificação em processo novo, repetição da migração, desinstalação, reativação e conferência dos dados aplicáveis. O teste de atualização conferiu opções, conteúdo, cursores, agendamentos e registros de vitais legados. O ZIP foi conferido com SHA-256 antes e depois de ambos os ciclos.

No Site-Teste autorizado, o conector transferiu o ZIP em 17 partes e conferiu os 4.284.656 bytes e o SHA-256. A instalação a partir do caminho temporário usou `expected_slug=base-site-core-fator3`, o hash integral esperado e pré-imagem dos arquivos. A operação 350d09c5edfc1f4c59825fe4a5a16418 foi confirmada como completa, com o candidato ativo. O arquivo ZIP temporário foi removido por exclusão condicionada ao mesmo hash.

A confirmação do executor ocorreu em 2026-11-05T11:05:21-03:00. A leitura própria do Core informou ciclo concluído, contrato 8.33.0, código `core_operacional`, zero avisos e verificações de cabeçalhos, navegação e conta Pipedrive concluídas. A saúde do WordPress retornou positiva, com zero recuperações pendentes. A janela de 24 horas já registrava ocorrências de cron antes da instalação.

Pelo MCP remoto, o índice passou do hash da 1.70.0 ao da 1.71.0. Os 185 documentos foram descobertos. O conteúdo integral de cinco guias foi comparado com os bytes locais, incluindo quatro páginas de MEDICAO-DESEMPENHO.md. Os recibos ficam em `site-instalacao.json`, `site-documentacao.json` e `site-saude.json`.

### Sondas no Site-Teste

| Medição, mediana de até três leituras | Base 1.70.0 | Candidata 1.71.0 |
| --- | ---: | ---: |
| HTTP total da inicial com desvio de cache | 428,020 ms, 3 respostas | 1.580,041 ms entre 2 respostas de 3 tentativas. Repetição separada 409,634 ms, 3 de 3 |
| HTTP total do login com desvio de cache | 289,868 ms | 448,366 ms |
| HTTP total da inicial servida com acerto de cache | 46,312 ms | 87,627 ms |
| Tempo próprio instrumentado na inicial | 49,571 ms | 47,899 ms |
| Tempo próprio instrumentado no login | 5,029 ms | 6,522 ms |

Uma tentativa da primeira série da inicial excedeu o limite de cinco segundos. A mediana das duas respostas concluídas exclui esse timeout. O primeiro lote da candidata retornou 146.419 bytes, e a repetição retornou 142.447 bytes, o mesmo tamanho da base. Foram observadas 5 consultas instrumentadas na inicial e 0 no login nas duas versões. O transporte não forneceu TTFB remoto separado. A mudança concomitante de MCP 0.39.0 para 0.40.0, a variação do HTML, as condições de cache e a carga concorrente impedem atribuir essas diferenças ao Core.

A consulta remota com `somente_resumo:true` retornou somente os cinco campos de cada métrica. A janela sobreposta de 28 dias conservou as mesmas contagens e p75 do inventário anterior. O timeout, os dois lotes e os limites do método estão em `site-perf-base.json` e `site-perf-candidato.json`.

No Chrome conectado à página inicial HTTPS do Site-Teste, em sessão autenticada, o botão “Política de Cookie” começou recolhido e apontava ao painel oculto. O clique abriu o diálogo, moveu o foco e exibiu o estado de medição. Escape fechou o painel e devolveu o foco ao botão. A escolha existente foi preservada. A prova interativa não depende da contagem de operações do teste JSDOM.

O fonte reúne os resultados em `evidence/1710`. O lint cobriu 596 arquivos PHP. A matriz também executou as 19 verificações de configuração, as 10 de edição de origem LinkedIn e as 60 do pedido 369 na bancada com os acompanhantes. Os testes de frontend repetem cenários nos fontes, nos minificados e no perfil composto. São execuções sobre representações diferentes do mesmo código, não usuários independentes.

## 6. Banco, backup e recuperação

A mudança é aditiva no contrato de leitura e preserva a estrutura das tabelas. A atualização registra os marcos próprios de instalação. Os testes compararam os registros sintéticos antes e depois da migração, repetição e reinstalação. A distribuição de vitais, a retenção configurada e os dados comerciais existentes não exigiram reclassificação histórica. A pré-imagem da operação remota cobre os arquivos do plugin. O backup dos dados segue o inventário do site e os procedimentos de recuperação privada do Core. Qualquer correção de código após a instalação deve ter uma nova versão. Restabelecer a consistência deve preservar cursores, decisões de consentimento e dados pendentes.

## 7. Pendências e alcance

- Medir LCP e INP de visitantes exige janelas antes/depois com audiência, marca de versão operacional, rota e dispositivo comparáveis. O Site-Teste não tinha volume suficiente. Também não foi exercitada a meta de produção de 100 ms em fator3.com.br.
- A bancada executou PHP 8.3.6 e o Site-Teste 8.3.36. A revisão exata 8.3.0 e uma matriz adicional de navegador/dispositivo não foram exercitadas. JSDOM verifica comportamento do JavaScript e não mede pintura real nem tempos de transferência.
- As alterações atuam no Core e em seus relatórios. Não houve gastos, campanhas, captura comercial nem envio real a Google, Meta, LinkedIn, Clarity ou Pipedrive. A publicação raw e a distribuição a outros sites ficam sob responsabilidade da frota.

## 8. Operação e credenciais

A instalação requer o canal de manutenção autorizado e a operação de documentação requer `manage_options`. Na leitura de vitais use `f3base/vitais-ler` com `{"dias":28,"segmento":"sem_testes","automacao":"audiencia","somente_resumo":true}`. O retorno inclui o intervalo e os contadores por métrica. Para investigar atribuições, um administrador solicita o modo detalhado. O operador usa Site Core → Configurações para revisar consentimento, carregamento dos destinos e retenção. Esta versão não cria um campo de credencial e não exige cadastrar uma conta de fornecedor. As sondas da página/login usam assinatura interna do site.

## 9. Arquivos e integridade

| Arquivo | Bytes | SHA-256 |
| --- | ---: | --- |
| base-site-core-fator3-1.71.0-instalador.zip | 4284656 | 7aa9f94e4ecfd30db81ab10603981fb3e4503f7039aeaf5b0fae1ab287d37e57 |
| base-site-core-fator3-1.71.0-fonte.zip | 5828164 | a532a725dabe76af9ec36811e4e4611826b397716188f5c99d938eeb3bd43278 |

O relatório externo é o documento canônico de fechamento. O fonte inclui a cópia anterior ao empacotamento, identificada com o nome do relatório externo. O manifesto do fonte dá o hash individual de cada arquivo. O instalador contém somente o runtime e sua documentação. Os dois ZIPs foram confrontados arquivo a arquivo.
