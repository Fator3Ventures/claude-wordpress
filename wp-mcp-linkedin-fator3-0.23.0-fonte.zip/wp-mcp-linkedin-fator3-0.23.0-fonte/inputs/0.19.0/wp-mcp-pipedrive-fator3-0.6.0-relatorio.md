# Entrega — Fator3 MCP Pipedrive 0.6.0

Revisão 1 · 2026-11-05T08:58:36-03:00 · implementação, revisão e homologação no Site-Teste.

**Status: apta no escopo testado.** A 0.6.0 está instalada e ativa no Site-Teste. O painel permite revisar e alterar regras sem sair do WordPress. A gravação protege alterações concorrentes; a simulação mantém o vínculo com a conta que foi lida. O aceite comercial anterior com Pipedrive real continua pendente.

## 1. De onde esta versão entra

Instalação limpa ou migração direta **0.5.0 → 0.6.0**. Identidade preservada: `wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php`, provider e rotas `pipedrive/*`. O cabeçalho declara **WordPress ≥ 7.1.4 e PHP ≥ 8.3**. Site único, PHP de 64 bits, OpenSSL, mbstring e InnoDB. A execução funcional usou WordPress 7.1.4, PHP **8.3.36** e MySQL **8.4.11**. O lint local usou PHP 8.3.6. Esses são os runtimes observados; não se atribui teste a outros patches de PHP.

| Base conferida | Bytes | SHA-256 |
| --- | ---: | --- |
| `wp-mcp-pipedrive-fator3-0.5.0-instalador.zip` | 95.019 | `59e8c99d5bb8a54fcfeaba06c56d816b940a1fe97a7d6b473d13a252c6e5042a` |
| `wp-mcp-pipedrive-fator3-0.5.0-fonte.zip` | 447.838 | `12217911a656f192a32df80fb6716abd009da6f3efe16252418c30a6e00b229a` |

O código revisado veio do fonte exato da entrega anterior. A instalação compartilhada antes da atualização correspondia ao instalador-base arquivo por arquivo. Foram lidos integralmente **instrucoes-agentes-plugins-fator3.md** e **padrao-desenvolvimento-plugins-fator3.md**, ambos **revisão 5 de 02/11/2026**. A solicitação desta rodada é direta, sem novo número da aba: análise e melhorias de código, aumento dos testes, configuração e documentação. O pedido 10 da base foi tratado como regressão e teve seus limites de aceite preservados.

## 2. Convivência e encaminhamentos

| Pacote | Inventário inicial | Primeira bancada integrada | Conjunto final validado |
| --- | --- | --- | --- |
| Site Core | 1.69.0 | 1.69.0 | **1.70.0** |
| MCP | 0.38.0 | 0.39.0 | 0.39.0 |
| Google | 0.26.0 | 0.27.0 | 0.27.0 |
| Meta | 0.19.0 | 0.20.0 | 0.20.0 |
| LinkedIn | 0.17.1 | 0.18.0 | 0.18.0 |
| Pipedrive | 0.5.0 | 0.6.0 | **0.6.0** |

Os acompanhantes foram copiados da instalação ativa para bancos e diretórios descartáveis. Não foram reempacotados ou atualizados pelo mantenedor Pipedrive no ambiente compartilhado. As mudanças de versão observadas durante o trabalho foram medidas novamente, sem presumir que o inventário inicial ainda valia. Google, Meta e LinkedIn foram exercitados em ativação e convivência; suas APIs comerciais não foram homologadas nesta rodada.

**Sem impacto técnico novo a encaminhar.** O Core mantém credencial, transporte e orçamento pelo contrato `pipedrive-api-client/1.0.0`; o MCP mantém autorização, descoberta e execução. A revisão do formulário, da escrita e da fila é interna ao Pipedrive. O pacote continua oferecendo 19 operações públicas. Unidades locais continuam no contrato existente; não há novo job, callback, token, dependência social ou mudança de schema de banco.

O impacto histórico `base-site-core-fator3-1.51.0-impacto-wp-mcp-pipedrive-fator3.md`, revisão 1, Pedido Core 294 C1–C8, descreve o cliente usado desde a base. Registro, autorização, orçamento, prévia, aplicação e recibo foram exercitados com o cliente original nas duas bancadas atuais; o limite de fornecedor real permanece. Não foi reemitido um impacto antigo como pedido novo.

O Core 1.69.0 era o vigente no fechamento do instalador. As referências instaladas a ele descrevem esse contexto. A confirmação adicional com Core 1.70.0, depois da troca externa, está em `evidence/core170-*.json`: mesma árvore Pipedrive e mesmo contrato, **63 verificações aprovadas**. O inventário final é a referência operacional desta entrega.

## 3. Mudanças e evidência

| Área solicitada | Problema observado na base | Implementação e prova |
| --- | --- | --- |
| Configuração | Uma única tela abria estado técnico em JSON, diário e documentação. As regras comerciais não tinham editor no painel. | Quatro seções: Visão geral, Regras de operação, Diário e retenção, Ajuda. Cada seção lê os dados que usa. O guia de conexão indica o próximo passo. Ajuda funciona sem consultas de negócio. |
| Edição e confirmação | O administrador dependia do MCP para preparar regras. Sobrescrever o objeto inteiro para mudar um horário aumentava o risco de perder regras avançadas. | Editor guiado para fuso, dias, janela, períodos, feriados, tipo de atividade e motivos; objeto JSON completo para toques, textos, canais, espera e auditoria. O modo guiado preserva os demais grupos. Validar campos é local; simular usa Core; aplicação exige prévia da mesma conta e administrador, nonce, frase e ordem do dono. Uma prévia de negócio não é aplicável por esta tela. |
| Concorrência | A 0.5.0 verificava a revisão antes de gravar, mas o `UPDATE` de regras comparava somente o nome da opção. Um escritor fora da trava podia ter sua alteração sobrescrita. | O `UPDATE` compara também os bytes anteriores; a gravação exige releitura dos bytes efetivos. Um teste com segunda conexão MySQL alterou a opção no intervalo e a alteração concorrente sobreviveu. Em Chromium, um formulário antigo foi recusado antes de consultar o fornecedor. |
| Tipos de regras | O validador REST aceita algumas representações textuais de booleanos e inteiros. O PHP pode interpretar a string `"false"` como verdadeira. A base recusou um rascunho desativado com essa representação. | Tipos declarados pelo schema são normalizados antes da avaliação. Lista malformada ou duplicada após conversão é recusada. A leitura não regrava a opção. Verificados dias, flags aninhadas e canal protegido. |
| Integridade de leituras | Um GET individual podia devolver outro ID e ainda servir como estado para preparar uma escrita. Uma nova consulta de status após a simulação podia fornecer um contexto diferente do que fora realmente lido. | Estado individual exige ID correspondente; a prévia de configuração usa a identidade da própria coleta. Resposta de outro registro, atividade com vínculo divergente e mudança de contexto são recusadas nos casos testados. |
| Fila e mensagens | A fila varria todas as atividades para cada lead e podia pedir detalhes de atividades sem relação com a saída. Valores estruturados podiam produzir comparações por rótulo; campo com apenas HTML podia deixar uma variável vazia sem bloquear o texto. | Agrupamento por lead; detalhe somente de atividade WhatsApp pertinente; vínculo incompleto bloqueia indicação de envio. Condições e exclusões comparam IDs; variável sem conteúdo após remoção de HTML ou espaço Unicode bloqueia a mensagem. A base foi reproduzida permitindo o valor composto só de marcação. |
| Diário e recibo | Uma atualização do diário com zero linhas afetadas podia passar sem confirmar a existência da linha. A releitura estrita de um detalhe JSON representado por objeto PHP podia indicar divergência apesar da gravação. | Conclusão exige diário confirmado; ausência da linha interrompe a transação e mantém a tentativa em execução para reconciliação. Releitura usa a mesma representação JSON persistida. Há testes dos dois casos. |
| Custo de inicialização | Todo carregamento do plugin incluía todos os módulos, mesmo sem usar uma operação. | Carregamento sob demanda por mapa fechado de classes; schemas reutilizados por requisição. No mesmo ensaio isolado de bootstrap com apenas Pipedrive ativo, **18 arquivos na 0.5.0 e 1 na 0.6.0**. Essa é uma medida de arquivos PHP incluídos, não de milissegundos de página ou de desempenho de toda a frota. |
| Acessibilidade e documentação | A tela não apresentava caminho claro para começar, revisar uma prévia ou recuperar um conflito. | Rótulos e descrições associados aos campos, agrupamento por tarefa, mensagens de erro/estado, navegação por teclado, paginação e CSS restrito ao próprio painel. Novo documento `painel`; índice, configuração, contratos, operação e notas revistos. O mesmo conteúdo está no WordPress e no MCP. |

A UI apresenta os grupos alterados, o número de leads avaliados e as ações devidas; o resumo mostra até 20 IDs, sem expor textos individuais interpolados. A simulação consome orçamento de leitura e cria prévia local cifrada de 15 minutos. Validar campos não faz leitura do fornecedor nem grava estado. A alteração no formulário depois da simulação exige nova prévia para ser aplicada.

## 4. Instalação e prova da troca

**478 verificações na matriz principal**, contadas uma vez por resultado final de cada cenário, incluindo a revalidação da fronteira Core. São verificações e não 478 fluxos comerciais distintos.

| Ambiente / cenário | Aprovadas | Evidência |
| --- | ---: | --- |
| WP isolado, instalação limpa: funções nativas e permissões, relatório, retenção | 90 + 49 + 33 | `current-native`, `current-report`, `current-retention` |
| Mesmo ambiente: regressões de fluxos e Pedido 10 | 56 + 48 | `current-release`, `current-requests050` |
| Novas regressões de código, configuração, coleta e persistência | **32** | `current-quality060` |
| Primeira combinação: MCP/convivência; três grupos com cliente Core 1.69.0 original | 42 + 8 + 6 + 7 | `current-integrated`, `current-core`, `current-core-report`, `current-core-workflows` |
| Migração direta e reinício em processos novos | 15 + 2 | `upgrade-verify-upgrade`, `upgrade-upgrade-restart` |
| Navegador, incluindo duas abas, teclado, largura estreita e negativas | **27** | `browser.json`, 22 requisições ao painel |
| Nova bancada: MCP/convivência e cliente Core 1.70.0 original | 42 + 8 + 6 + 7 | `core170-integrated`, `core170-core`, `core170-core-report`, `core170-core-workflows` |

As **32 verificações de regressão e 27 de interface** são cobertura nova desta revisão. Não se somaram as provas históricas da 0.5.0, a execução preliminar de protótipo ou a matriz do antigo piso WordPress 7.1.3. Separadamente, passaram **17 verificações de documentação/assets** no WordPress isolado, **22 comparações** da instalação compartilhada e **74 verificações de empacotamento/evidência, incluindo 39 lints PHP**.

**Prova de interface.** Chromium Headless Shell 157.0.8103.38 em desktop de 1280 × 900 e tela de 360 × 800. GET e POST do navegador foram encaminhados ao handler real `Admin::page()` no WordPress descartável. O navegador recebeu o HTML produzido pelo plugin e os estilos de WordPress/Pipedrive; opção, revisões, prévias, nonces e recibos foram processados no banco do laboratório. A autorização comercial e as respostas do fornecedor foram sintéticas. Esse transporte substitui o login e o transporte HTTP do wp-admin compartilhado; não é uma prova de login visual naquele site. O hook real de administração confirmou CSS apenas na página do plugin, com URL e versão corretas.

**Ajustes da bancada.** Quatro expectativas iniciais de versão dos acompanhantes ficaram desatualizadas durante a rodada. O inventário, a ativação e os cabeçalhos congelados identificaram os novos números; o teste integrado foi repetido e passou 42/42. No teste de duas abas, foi necessário criar um contexto explícito de Chromium. O teste de CSS passou a carregar o bootstrap administrativo do WordPress para dispor de `get_current_screen()`. Esses ajustes foram no harness; o instalador final não foi modificado depois de instalado.

**Instalação compartilhada:** [Site-Teste](https://fator3-teste-mcp-1.dreamhosters.com/), `plugins/upload-base64`, `expected_slug=wp-mcp-pipedrive-fator3`, SHA-256 da seção 8, `activate=true`, `overwrite=true`. Operação **df00b78dd1ba3b7424bf1dc4da57a466**, pré-imagem de arquivos **69f2714e8740e2b2a96a8794**, estado `applied`. O inventário e o processo PHP independente confirmaram **0.6.0 ativa**. Reativação silenciosa; não se atribui execução integral do hook de ativação a essa troca. As sondas internas `/` e `/wp-json/` deram HTTP 200 antes e depois. Não medem acesso externo por CDN.

**Documentação instalada:** 12 documentos, 61 páginas pelo executor MCP original em cada bancada integrada. No Site-Teste compartilhado foram lidos os 12 documentos em 16 páginas por `pipedrive/documentacao-ler`, com revisão fixada nas continuações e comparação de conteúdo, tamanho e hash. O painel pode ser aberto em Ferramentas → Fator3 MCP Pipedrive. Todos os **34 arquivos instalados** corresponderam ao ZIP. O estado técnico de regras e retenção foi conferido por leitura; `pipedrive/status` continuou retornando `operacao_nao_autorizada` com a versão correta, como previsto.

**Encerramento:** Core 1.70.0, MCP 0.39.0, Google 0.27.0, Meta 0.20.0, LinkedIn 0.18.0 e Pipedrive 0.6.0 ativos. Saúde `healthy=true`, zero operações de recuperação não resolvidas. Descoberta completa: **19 operações Pipedrive 0.6.0 e zero QA da rodada**. As limpezas finais das primeiras três bancadas removeram 101 + 14 + 14 tabelas; a revalidação do Core removeu outras 101. Em todos os casos, zero tabelas próprias restantes e diretório removido. Controladores e ZIP temporário próprios foram excluídos com guarda de hash, inclusive depois da revalidação; auditoria e backups normais do MCP preservados. Não houve publicação no GitHub nem implantação em outro site.

## 5. Banco, migração e correção por nova versão

Não há tabela, coluna, opção nova ou migração destrutiva. A instalação não regrava regras, retenção, credenciais ou autorizações existentes. Tipos são interpretados na leitura; gravação só ocorre ao confirmar uma simulação. Mudança de revisão preserva a configuração vencedora e exige recarga.

A prova de migração partiu do instalador 0.5.0: quatro operações e três linhas de diário, retenção explícita de 730 dias, regra de cadência ativa com feriado e canal protegido, trava pendente e um recibo permanente de WhatsApp criado por operação real da base contra fixture. Após atualizar, as linhas e os valores brutos das regras permaneceram iguais; revisão, schema, escolha de retenção, trava e recibo foram preservados. Repetir a mesma chave com contexto sintético inalterado devolveu o recibo sem nova escrita; contexto alterado recusou o replay. O novo processo e a reativação preservaram a política.

No Site-Teste compartilhado, as duas tabelas próprias continuaram com zero linhas; hashes das regras, retenção, schema e autorização de operação do Core concordaram antes e depois. A comparação é do estado selecionado; a pré-imagem nativa cobre os arquivos do plugin, não é backup integral do banco. Em caso de falha, conter o fluxo afetado, preservar banco, salts, recibos e diário, reconciliar qualquer efeito externo e corrigir por **nova versão**. Não há procedimento de downgrade.

## 6. O que permanece pendente

- **Dono/frota — aceite comercial do Pedido 10:** confirmar em korvena.com.br os campos e regras da conta e o fluxo de atividade, idempotência, fila, auditoria e nota final no Pipedrive real. As respostas de CRM desta rodada foram simuladas; nenhum cliente recebeu mensagem e nenhum registro real foi modificado.
- **Frota — distribuição:** publicar e instalar somente no escopo que o dono determinar, conferindo o ZIP e o SHA desta entrega. O instalador não foi publicado em `main` por este trabalho.
- **Limites da prova de UI:** fluxo do componente e persistência passaram em navegador e WordPress descartável. Não foi exercitada a sessão visual autenticada do wp-admin compartilhado, nem personalizações de CSS de todos os sites. A contagem de arquivos incluídos no bootstrap não mede latência de produção.

Não foi identificada pendência de código nas fronteiras testadas. O aceite externo herdado não foi marcado como concluído na aba central.

## 7. Credenciais e configuração do dono

O token fica no Fator3 Site Core, junto da conta e da autorização explícita do consumidor `operacao`. Nenhuma credencial real foi solicitada ou incluída nos artefatos. O painel Pipedrive exibe o estado da conexão e não recebe token. A validação local continua disponível com operação comercial desabilitada. Para simular com dados da conta, o Core deve registrar o cliente e autorizar a operação no site correto; não habilitar o Site-Teste como conta comercial por conveniência.

Acesso ao painel, regras, conta e diário exige `manage_options`. No MCP também vale a política da conexão. Não copiar mensagens interpoladas, campos pessoais ou dados privados da conta para relatórios. O guia `painel` e o schema instalado explicam configuração, efeitos, erros e verificação após salvar.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| Instalador WordPress | [wp-mcp-pipedrive-fator3-0.6.0-instalador.zip](wp-mcp-pipedrive-fator3-0.6.0-instalador.zip) | 106.032 | `0cfec48e6142064d6024b49e9026e79e359178ae04846fd5c442597c6b70908e` |
| Fonte | [wp-mcp-pipedrive-fator3-0.6.0-fonte.zip](wp-mcp-pipedrive-fator3-0.6.0-fonte.zip) | 273.167 | `42c0fbdb6cb055ba12fc39a2263986d9cdad8012b3eb56bd72d06bde475d5d9f` |

Relatório externo canônico: `wp-mcp-pipedrive-fator3-0.6.0-relatorio.md`. A cópia interna é anterior ao fechamento. O tamanho e SHA finais do fonte foram preenchidos neste relatório sem reabrir o ZIP.

Instalador com única raiz `wp-mcp-pipedrive-fator3/`; fonte com única raiz `wp-mcp-pipedrive-fator3-0.6.0-fonte/`. Apenas o instalador é instalável. O fonte inclui runtime idêntico, build, testes, evidências sanitizadas, referências e cópia deste relatório. Nenhum ZIP contém outro ZIP. O fonte foi extraído em outro diretório e seu build reproduziu exatamente os bytes do instalador aplicado.
