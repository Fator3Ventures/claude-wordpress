# Entrega — Fator3 Site Core 1.67.0

Revisão: 1 · Data: 01/11/2026 · Status: **com-pendencias** (instalação remota do ZIP final bloqueada pela revisão automática de aprovação, aceites da frota e metas anteriores de bytes). Nova rodada minor sobre a 1.66.0 publicada. Implementação dos pedidos 365, 366 e 367, mais correção de reinstalação encontrada na validação. Contrato administrativo 8.30.0. Slug/basename preservados: `base-site-core-fator3/base-site-core-fator3.php`.

## 1. De onde esta versão entra

Retomada do chat indicado pelo dono: `6ae60e1f-bef0-83e8-8ed7-470bad3bb81c`, “Plugin Core”. O agente anterior já havia implementado 365/366/367, encontrado e corrigido a reinstalação, executado provas locais e instalado um primeiro candidato no Site-Teste. Faltavam a conclusão do catálogo Instagram, reconciliação da prova de cache em CLI, fechamento dos testes do artefato final, fonte e relatório. Esta retomada recuperou a árvore de trabalho e evidências, acrescentou a correção restrita do WP Super Cache, completou as matrizes e fechou os artefatos. A última troca remota permanece bloqueada conforme seção 4; não se declara a rodada integralmente homologada.

Base canônica imutável: `base-site-core-fator3-1.66.0-fonte.zip`, 8187553 bytes, SHA-256 `280a7fa4e706c5f1af3034bd1d11dc8dd466cf33958a4a33ebb4a24ad16b3b0c`; instalador 4218989 bytes, SHA-256 `0f796b2001478fe32e5ce47b5851f79148e6a1eebac7087c39a603a587692830`. Relatório externo da base: SHA-256 `c6eaafb4c8e8292189f1122160c50d11bf50bc38f91d47ea955d2b7c39c860ba`.

Escopo recebido em `Fator3 Site Core(20261101-221737).md`, SHA-256 `02102066183f2afeac1909cf08dc2f81e483091aea979b474cb31618edb256f6`: 365/366/367 abertos. Lidos integralmente `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, ambos revisão 4 de 16/10/2026; o plano está em `PLANO-1.67.0.md`. Insumos, tamanhos e hashes estão em `inputs/1670/manifest.json`.

O documento recebido informa encerrados 354/362/363/364 na frota. Em particular, informa 51,5/53,9/51,2 ms próprios do Core em fator3.com.br na 1.66.0 e primeira cópia com arquivos públicos nos 12 sites. São aceites recebidos, não medições novas desta rodada. As metas anteriores de bytes seguem abertas, como indicado na seção 6.

## 2. Convivência e encaminhamentos

| Pacote | Versão considerada | Evidência e impacto |
|---|---|---|
| MCP | 0.38.0 | Ativação e convivência local; canal nativo do Site-Teste. Nenhuma alteração. |
| Google | 0.26.0 | Fonte, instalador e relatório recebidos; correção de schema para transporte `ambos`/`invalid_output` considerada. Ativação local e contexto Core preservado. |
| Meta | 0.19.0 | Fonte, instalador e relatório recebidos; SDK/armazenamento oficiais exercitados com concessão local, contagens por dia, cobertura parcial e revogação. Sem HTTP de fornecedor. |
| LinkedIn | 0.14.0 | Ativação e convivência local; identidade canônica de aquisição permanece compartilhada. Nenhuma entrega comercial ensaiada. |
| Pipedrive | 0.5.0 | Exige PHP 8.3.36; convivência observada no Site-Teste. Sem criar contato ou negócio para teste. |

Google instalador: `f75031f2a430e099b7d3603d321993a049b4fb49606b9267144a59971eeebfe4`; Meta instalador: `f7629f48fffb774542a480fb55f29a151762b06a27b34c9a0c3188da3599451b`. Identidades dos fontes e relatórios também constam do manifesto.

Nenhum novo encaminhamento individual: não há mudança de contrato que exija implementação em outro pacote. Contratos Core administrativo 8.30.0, contexto de medição 1.0.0 e finalidades de conversão 1.1.0 preservados. A saída Meta é aditiva; os campos e modos anteriores permanecem. Acompanhantes não são alterados nem redistribuídos no fonte.

## 3. Mudanças e evidência

**365 — aviso de opções fora do catálogo.** O diagnóstico distingue configurações declaradas de estados internos explicitamente inventariados. Foram incorporados 20 nomes exatos de estado e mantidas três famílias fechadas de nomes dinâmicos. Não existe dispensa genérica para `f3base_`: erro de digitação, marco desconhecido e configuração não declarada continuam produzindo aviso. As duas opções de conversas Instagram também foram movidas para a composição direta do catálogo: a prova remota identificou que ainda dependiam da ordem de carregamento. A configuração continua declarada como configuração, sem dispensa genérica. A listagem contém somente nomes. Reconhecimento diagnóstico não concede permissão para gravar ou apagar o estado. Foram conferidos os 177 nomes observados no Site-Teste antes da troca.

**366 — prova do cache.** A reprodução na 1.66.0 mostrou que `content_url()` adotava HTTP em CLI, embora a home fosse HTTPS; a verificação de mesma origem então recusava o próprio artefato. A 1.67.0 aplica explicitamente o esquema canônico da home à URL do conteúdo, preservando validações de host, porta e caminho. A sonda prioriza o arquivo vinculado à cópia servida, limita a busca a 128 entradas e registra diretório relativo, parcialidade e até 12 recusas com motivo. Links simbólicos de arquivo são recusados. Não expõe HTML do cache ou caminho absoluto do servidor.


A retomada também corrigiu a diferença de contexto entre CLI e HTTP do WP Super Cache 3.1.4: quando o global wpsc_ignore_tracking_parameters está ausente, o Core lê exclusivamente uma atribuição literal de nível superior no arquivo de configuração do provedor. A leitura é limitada a 256 KiB, não executa PHP, não altera globais e não substitui false explícito. Configuração dinâmica, duplicada, condicional ou ilegível permanece sem confirmação. Com a configuração literal padrão, CLI e página pública calculam o mesmo contexto, evitando cache_obsoleto falso após a verificação automática.

Só há prova de proteção com corpo vazio e HTTP 200/403/404/410. Conteúdo exposto, erro com corpo, redirecionamento ou resultado truncado não se tornam sucesso. Saúde e pós-atualização usam a mesma verificação vigente; `recibo_inicial` preserva o resultado original. Um sucesso novo limpa o aviso vigente sem reiniciar o ciclo; uma nova pendência mostra seu motivo atual. Consultas não executam sondas nem alteram o recibo original. O teste isolado usa TTL 86400 e fixtures explícitas de WP Super Cache/HTTP; a prova de arquivo real servido pertence ao Site-Teste, na seção 4.

**367 — Lead local e recebido Meta.** A reprodução na 1.66.0 mostrou o formulário aceito usando `record_id` como `event_id`, mas o coletor procurando somente `correlacao`, o que recusava o Lead legítimo com 409. A resolução agora compartilha a identidade de `F3Base_Aquisicoes`, sem reservar outra aquisição. Exige contato aceito/clique elegível, método correspondente, classe, consentimento, classificação e ausência de supressão/exclusão. Cliques que já usam a correlação continuam compatíveis. `MaterialDownload` mantém nome e opt-in próprios.

A observação grava o `event_id` exato; o hash de deduplicação e o instante original permanecem. O disparo do Pixel pode enriquecer a mesma observação de falso para verdadeiro, inclusive durante um POST pendente. Confirmação com Meta suprimida não registra disparo. A eliminação do contato limpa o identificador exato e bloqueia repetição. Não há reconstrução de ids históricos.

`f3base/meta-entregas-ler`, `modo:eventos`, inclui recibos locais sem fila e recibos do servidor, com `event_id`, `identificador_disponivel`, `capturado_em`, `navegador_observado`, `pixel_navegador_id` e `origem_recibo`. Uma observação local tem estado `observado_local`, campos exclusivos do servidor nulos e não afirma recebimento pela Meta. Paginação estável de 100 linhas. Diário por dia UTC, rota e classe; `comparacao_meta` coloca o local e o recebido no mesmo dia/fuso e dataset do produtor. As classes locais ficam separadas; total externo não é atribuído a uma classe ou evento individual. Cobertura parcial e ausência de concessão mantêm valores desconhecidos, não zeros. Browser e servidor não são somados como pessoas únicas. A leitura usa o acervo concedido do SDK oficial, sem consultar HTTP do fornecedor.

**Reinstalação.** A validação adicional revelou que o desinstalador anterior removia tabelas auxiliares e preservava o checkpoint de instalação concluída. A 1.67.0 arquiva o recibo e marca `reinstalacao_pendente` antes da remoção; a reativação abre novo ciclo mesmo na mesma versão. A reconstrução confirmada também retira falhas de estrutura observadas antes dela na mesma requisição, evitando que o shutdown invalide o esquema recém-reparado. As configurações e tabelas comerciais preservadas continuam intactas. A prova física verifica as 70 tabelas após reinstalar, além da preservação de cinco tabelas comerciais e suspensão apenas das pendências previstas.

| Prova executada | Resultado / alcance |
|---|---|
| Reprodução na base 1.66.0 | 4 verificações: esquema HTTP/HTTPS em CLI e identidade de aquisição versus correlação. |
| 365 | 213 verificações; módulos/estados conhecidos sem aviso e seis nomes desconhecidos mantidos no aviso. |
| 366 | 37 verificações; consistência CLI/HTTP, configuração ambígua (incluindo controles com sintaxe alternativa), TTL 86400, proteção/exposição, redirecionamento, origem, symlink, diagnóstico persistido e motivo vigente. |
| 367 | 248 verificações: captura nativa, enriquecimento, duplicatas, consentimento, classes, material, fila, paginação, identidade histórica, eliminação e zero entrega externa. Resultados completos nos JSONs. |
| SDK Meta 0.19.0 | 9 verificações novas e 43 de regressão Meta Ads. Dia America/Sao_Paulo, dataset exato, cobertura parcial, concessão revogada e zero HTTP. |
| JS fonte/minificado | 18 verificações com transporte simulado; mesma identidade/instante nos beacons, disparo durante POST, supressão e retirada de consentimento. |
| Contextos 364 | 190 verificações em cada um dos cinco contextos: público, REST, MCP, cron e CLI. |
| Regressões | 64 comparações HTML; CTA frio/quente/profundidade; 362 com 10 verificações; 363 com 187 verificações e matriz discreta de 49.152 combinações/180 variantes de prazo. |
| Documentação | Leitura integral pela habilidade, paginação, hashes, aliases, permissão e confinamento; inventário e dicionário aditivo. |
| Sintaxe | Todos os 591 arquivos PHP do instalador aprovados em PHP 8.3.6. |
| Ciclos nativos | WordPress 7.1.4 e 7.1.2/PHP 8.3.6: instalação limpa, atualização direta da 1.66.0, repetição, desinstalação/reativação; exato ZIP final. |

As matrizes do ZIP final estão em `evidence/1670/recovery-current/` (WordPress 7.1.4) e `recovery-minimum/` (7.1.2), ambas com PHP 8.3.6 e MySQL 8.0.46. Elas repetem os ciclos nativos, 365/366/367, as 64 comparações HTML, 362, documentação e cobertura física de schema. As provas JS, SDK Meta, contextos 364 e matriz 363 foram recuperadas da execução anterior desta mesma rodada, conferidas e preservadas: não são apresentadas como reexecutadas após o ajuste restrito de leitura do WP Super Cache. Resultados de outras versões permanecem históricos. Não houve homologação comercial com fornecedores.

A primeira repetição local encontrou `tablespace exists` ao recriar uma tabela auxiliar apagada no banco descartável. A matriz completa foi então executada do zero em dois diretórios de dados privados novos, com `innodb_file_per_table=OFF`, e passou. Essa mudança é exclusiva do laboratório: não alterou o código entregue nem a configuração do banco remoto. O registro está em `recovery-lab-note.json`; `tests/recovery-matrix1670.py` reproduz a escolha. A correção de produto da reinstalação é distinta desse problema de ambiente e está descrita acima.

## 4. Instalação e prova da troca

**Estado ao encerrar: o ZIP final foi validado localmente, mas sua instalação no Site-Teste ficou bloqueada pela revisão automática de aprovação.** O site permanece ativo no candidato 1.67.0 de SHA-256 `f2c63e0a021dce178cf368eafb2ebfdf32ec5f505c72bba0bc1e38cdf0d1bb7a` (4219294 bytes), instalado nesta retomada pela operação `227cd1b16af5fed9cc0f7e46a4734c68`, com pré-imagem de arquivos `a2c3862c97cafc37f8c9d88d`. Essa pré-imagem não desfaz efeitos de banco. As sondas nativas de antes/depois passaram em `/` e `/wp-json/`, HTTP 200, com bypass confirmado; são sondas internas de mesma origem.

O candidato deixado no site contém as correções 365/366/367, reinstalação e contexto CLI. O ZIP final da seção 8 acrescenta apenas a recusa conservadora de controles PHP com sintaxe alternativa na leitura da configuração WP Super Cache. São 910 de 911 arquivos idênticos; o arquivo diferente é `includes/class-f3base-cache-pagina.php`. A correspondência foi conferida reconstruindo o ZIP anterior e obtendo exatamente seu SHA-256. O pacote final foi novamente aprovado nas duas matrizes locais, com as quatro novas verificações; não se atribui a ele uma instalação remota que não ocorreu.

A revisão automática recusou a sexta parte do envio, por considerar ausente autorização explícita para compartilhar o pacote com esse destino. A seção 8 do padrão do projeto, revisão 4, identifica e autoriza esse ambiente; após conferir essa evidência, a mesma operação continuou recusada. O envio parcial foi cancelado. A conclusão remota exige confirmação explícita do dono para enviar e instalar o ZIP final em `https://fator3-teste-mcp-1.dreamhosters.com/`. Nenhum meio alternativo de instalação foi usado após a recusa.

**Prova automática observada no candidato instalado:** em 01/11/2026, 22:15:13–22:15:16 −03, a execução CLI `dd52b10e-1061-4ced-9e5e-22572d302146`, hook `f3base_cache_verificar`, concluiu com `cabecalhos_comprovados`. A prova está persistida, HIT verdadeiro, seis cabeçalhos presentes, nenhuma falta; cache configurado em 86400 segundos. O corpo servido coincide com o artefato observado; acesso direto devolveu HTTP 200 com corpo vazio, sem exposição. A saúde às 22:18:47 −03 mostra catálogo vazio e zero avisos, incluindo retirada automática de `pos_atualizacao_cabecalhos`, sem regravar preferência ou resetar ciclo.

O ciclo anterior da atualização direta 1.66.0 → primeiro candidato 1.67.0 é `55c8f399-4b05-4bf2-a4f0-21b3106d01c8`, confirmado às 20:04:10 −03, com 20 etapas. Esse recibo é preservado; a substituição de candidato na mesma versão não é apresentada como um novo ciclo de migração. O recibo inicial dos cabeçalhos continua às 20:04:15 −03 e a projeção vigente usa a prova nova de 22:15:13 −03. As matrizes locais comprovam separadamente a atualização direta da 1.66.0 para o exato ZIP final.

Oito configurações foram comparadas integralmente por revisões e hashes de campos antes/depois da instalação do candidato: contato, formulários, consentimento, carregamento dos destinos, transporte Meta, Meta Ads, Pipedrive e cabeçalhos. Todas iguais. Não há prova nova de 93 configurações: o escopo desta comparação é oito. Os acompanhantes permanecem nas versões da seção 2.

Documentação RELEASE e AGENTES 1.67.0 lida integralmente pelo MCP instalado (35 e 9 linhas), sem paginação pendente, com hashes iguais aos documentos do ZIP final. Provas locais adicionais verificam todos os documentos, confinamento, permissões e aliases.

Sondas de desempenho do candidato, sem cache: página com 54,410 / 52,504 / 53,346 ms próprios do Core; login com 9,982 / 9,722 / 9,995 ms. Nenhuma abertura do catálogo completo nem consulta de estrutura; zero parseamentos CTA na página. Esses valores medem callbacks e carga até o footer, não TTFB nem tempo total da página, e não são medições da frota.

Limpeza concluída: os dois ZIPs temporários criados pela rodada foram removidos com backups recuperáveis; a transferência incompleta do ZIP final foi cancelada. A instalação ativa foi preservada. Nenhum acompanhante, credencial, preferência, contato comercial ou banco remoto foi alterado para fabricar aceite. Evidências selecionadas e sanitizadas em `site-test-recovery.json`, `site-test-final-correspondence.json` e arquivos de candidato.



Para a frota, instalar o ZIP identificado na seção 8 sobre a 1.66.0, mantendo o mesmo slug, sem excluir a pasta antes e sem usar desinstalação como procedimento de atualização. O executor nativo conclui a migração e publica os ativos antes da prova de cabeçalhos/cache. Conferir versão/ciclo, `f3base/resumo-operacional-ler`, `f3base/saude-ler`, `f3base/ativos-publicos-ler` e o primeiro cache público. Não resetar estado nem regravar preferências para fazer o aceite passar.

## 5. Banco e volta de versão

Migração aditiva: `f3base_meta_eventos.event_id varchar(100) NOT NULL DEFAULT ''`; versão de esquema do proprietário 16700. Nenhuma nova tabela, alteração de índices ou reprocessamento de dados comerciais. Linhas antigas mantêm hash, data, rota, classe e flag; identificador desconhecido retorna `null` na leitura. Eliminação do contato limpa o identificador exato. Inventário, dicionário e verificação final do ciclo refletem a coluna.

A reinstalação modifica apenas o ciclo operacional: arquiva o recibo, marca necessidade de novo ciclo e reconstrói as estruturas que a política de desinstalação já removia. Não amplia a lista de dados apagados. As configurações continuam preservadas. Uma falha em persistir a marca interrompe a desinstalação antes da remoção de estruturas.

Rollback para 1.66.0 usa o instalador canônico/pré-imagem e conserva o banco; a coluna adicional é compatível com o código anterior. Isso reintroduz os defeitos 365/366/367 e de reinstalação. Não restaurar um banco antigo por cima de contatos/recibos atuais; seguir o protocolo de recuperação para qualquer restauração conjunta. Não remover coluna ou inventar identificadores históricos para voltar arquivos.

## 6. O que permanece pendente

| Item | Estado e motivo |
|---|---|
| ZIP final no Site-Teste | Bloqueado pela revisão automática de aprovação durante o envio. Falta autorização explícita do dono para enviar/instalar o SHA-256 da seção 8 no Site-Teste e conferir seu estado remoto. O candidato ativo e sua prova CLI estão identificados na seção 4; ambos os ambientes locais passaram com o ZIP final. |
| 365 | Código e teste do pacote concluídos; aceite nos 12 sites é implantação/verificação da frota. Usar `avisos.catalogo`, mantendo qualquer nome realmente desconhecido visível. |
| 366 | Código e teste do pacote concluídos; aceite automático nos 11 sites depende da implantação e da execução do cron em cada ambiente. Conferir motivo vigente, cache protegido e remoção do aviso, sem reset manual. |
| 367 | Código e teste do pacote concluídos; falta o próximo contato **real** elegível de korvena.com.br com publicidade permitida. Comparar `event_id` com o Pixel e recebido do mesmo dia/fuso. Nenhum contato foi fabricado para fechar esse aceite. |
| Metas anteriores de 3 KiB e 20/30 KiB | Permanecem abertas na pendência 20, conforme lista recebida. Bootstrap 3132 bytes (60 acima de 3 KiB); tracking 40227 bytes; composições públicas exemplificadas em `assets.json`. Esta rodada não conclui a redução de bytes. Responsabilidade do pacote. |

Não ficou implementação de 365/366/367 adiada para P2. A separação por módulos/contexto já pertence à base e suas regressões foram preservadas. A entrega de código não encerra automaticamente aceite da frota ou metas anteriores. Não foram criadas sondas comerciais diárias, marcos automáticos de primeira ocorrência real ou reverse DNS, em conformidade com as decisões recebidas. Sem publicação no Git ou instalação em produção nesta rodada.

## 7. Credenciais e configuração do dono

Nenhuma credencial nova, rotação, alteração de segredo ou concessão. Não é necessário regravar destinos, contato, consentimento ou seleção Meta para usar as correções. O monitoramento externo continua dependente da concessão já existente e do acervo do produtor. Testes de fornecedores usam dados sintéticos locais, com HTTP/e-mail bloqueados; não há contato, mensagem ou conversão comercial criada para a homologação.

As evidências de preservação remota usam nomes/hashes, sem valores de configuração. O fonte exclui bancos, dumps, logs brutos, credenciais, laboratórios, dependências instaladas e ZIPs aninhados. Relatórios não expõem conteúdo de contato nem cookies. Documentação operacional está instalada e acessível por `f3base/documentacao-ler`, incluindo `RELEASE-1.67.0.md` e `AGENTES-1.67.0.md`.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | `base-site-core-fator3-1.67.0-instalador.zip` | 4219398 | `d781cdbccfb00fc3224385e4e12e8e67bf4a06b58e2c1f1d6a686bca3df94c6b` |
| Fonte | `base-site-core-fator3-1.67.0-fonte.zip` | 8423214 | `b27e26695befc939cf147891baffa5bbb6aa930f9f25ef97a4269d539358755c` |

Relatório externo canônico: `base-site-core-fator3-1.67.0-relatorio.md`. A cópia interna antecede o fechamento do fonte para evitar autorreferência do hash. O empacotador certifica a igualdade dos 911 arquivos de runtime com o instalador testado e gera `source-manifest.json`. Os três arquivos constituem a entrega; não há impacto individual novo.
