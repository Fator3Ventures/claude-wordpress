# Entrega — Fator3 MCP 0.39.0

Revisão 1 · 2026-11-05T08:28-03:00 · Implementação do Pedido MCP 77 · Status **com-pendencias** (aceite da frota).

Slug e basename: `wp-mcp-fator3` e `wp-mcp-fator3/wp-mcp-fator3.php`. Site-Teste ativo e saudável. Normas lidas integralmente: `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, ambas revisão 5 de 02/11/2026. Aba examinada: `Fator3 MCP(20261105-110441).md`. A seção 14 do padrão foi conferida no fechamento. As provas desta rodada estão em `evidencias/0390/`.

## 1. De onde esta versão entra

Instalação limpa ou atualização direta da 0.38.0. A base recuperada foi confrontada com o relatório do próprio MCP. Instalador 0.38.0 de 913.547 bytes, SHA-256 `bc550c6573527a0d71bfa560036f83e7c8aec546f49d70b8e0095da5d303c1a5`. Fonte 0.38.0 de 6.041.317 bytes, SHA-256 `cdf50f0d75c1dba5dbea1a6f1d687fad04bea67a43ddc98fd24c6ff526c9a7f1`. O Site-Teste também estava em 0.38.0. A versão de operação após a troca é 0.39.0.

Requisitos declarados: WordPress ≥ 7.1.4, PHP ≥ 8.3. Testados em laboratório: WordPress 7.1.4, PHP 8.3.6 e MySQL 8.0.46. No Site-Teste: WordPress 7.1.4 e PHP 8.3.36 observados pelo MCP. PHP 8.3.0 exato: sem ensaio nesta rodada.

## 2. Convivência e encaminhamentos

Os quatro instaladores anexados tiveram identidade interna, integridade ZIP e SHA-256 conferidos. Foram ativados em conjunto na bancada, com a nova versão do MCP, e observados ativos no Site-Teste antes e depois da troca. Os hashes de todos os anexos estão em `inputs.json`.

| Plugin | Versão | SHA-256 do instalador | Prova própria |
|---|---|---|---|
| Site Core | 1.69.0 | `8659ce0e526d378cf8424d0ff42deed660fee9f957be08f2bf26a74ce7f52996` | Catálogo e escrita/restauração pela estrutura real de leads clonada na bancada |
| Google | 0.26.0 | `f75031f2a430e099b7d3603d321993a049b4fb49606b9267144a59971eeebfe4` | Schema de google/status pelo transporte |
| Meta | 0.19.0 | `f7629f48fffb774542a480fb55f29a151762b06a27b34c9a0c3188da3599451b` | Schema de meta/health pelo transporte |
| LinkedIn | 0.17.1 | `e3a6c06d2c254a50af60e434a0575424e552ed4f62422ea1aabcff6bd591f1f9` | Schema do leitor de operações de serviço e registro saudável |

O escopo novo é optativo no contrato administrativo do MCP. O schema da tabela de leads do Core comporta o UPDATE ensaiado. Não se identificou necessidade de alteração nos quatro pacotes. Os assuntos entre Core e LinkedIn descritos nos relatórios recebidos concernem à integração comercial desses plugins. Nenhum impacto individual novo foi emitido. Pipedrive 0.5.0 foi observado ativo no Site-Teste; seus fluxos não fizeram parte da prova local. O pedido MCP 76 consta encerrado na aba recebida. Esta rodada não refez a avaliação de desempenho do Core 354.

## 3. Mudanças e evidência

**Pedido MCP 77.** A aba relata duas respostas 502 na confirmação de um UPDATE de uma linha em korvena.com.br. Na base, a etapa de backup usa por padrão um dump do banco e o planejador materializa toda a tabela alvo. A associação com os 502 é hipótese. O operador pode escolher agora `backup_scope: "selected_rows"` em `db/execute`. O modo cobre até 200 linhas de um UPDATE com WHERE de uma tabela InnoDB e identidade estável. A cópia usa a seleção completa, independentemente de `limit_preview`. O padrão `database` e a opção `selected_tables` continuam disponíveis.

A prévia calcula a seleção, esquema, hashes e chaves únicas pela guarda `selection-guard/2`. A confirmação revalida a seleção sob locks e grava o artefato privado gzip, com pré-imagens binárias e assinatura de metadados. Confere seu conteúdo antes de escrever. O readback verifica as linhas pela chave, inclusive seu conteúdo, antes do commit. O recibo contém `backup_id`, bytes, escopo e linhas afetadas. Falha de cópia ou seleção divergente impede a mutação. Sem token a chamada apenas prepara a prévia.

Para restaurar, invoque `db/restore` com `artifact_id` igual ao `backup_id` recebido. Confira `restores_entire_tables:false`, repita com o token dessa prévia e verifique a linha por chave. A restauração exige schema e pós-imagem correspondentes, verifica todas as linhas antes de aplicar, preserva edições fora da seleção e produz uma nova cópia das linhas que vai restaurar. Recusa `allow_changed_destination:true` neste modo. O formato privado `sql_rows` participa do inventário e da retenção de artefatos SQL. Valores originais permanecem no artefato privado, inclusive quando mascarados na apresentação.

A seleção reduzida exclui alterações de colunas únicas, joins, subconsultas, DDL, DELETE, INSERT, options e usermeta. A guarda também rejeita dependências com efeitos não modelados, como triggers e chaves estrangeiras. Um predicado sem índice ainda pode exigir varredura e bloquear vizinhos. Não há garantia de latência para toda consulta.

## 4. Instalação e prova da troca

| Cenário | Resultado | Evidência |
|---|---|---|
| WordPress limpo, MCP isolado, transporte HTTP | Prévia, aplicação, binário/NULL, recuperação inversa, replay, recusa por perfil e conflitos passaram | row-backup.json · 28 verificações |
| 100.001 linhas, seleção por PK | 1 linha alterada e restaurada; 111 bytes no artefato comprimido. Prévia e confirmação juntas em 616,47 ms numa execução local. O limite de 201 linhas e artefato corrompido foram recusados | scale.json e scale-metrics.json · 6 |
| Interrupção e concorrência | Lock por outra conexão cancela a confirmação; interrupção simulada após commit mantém recibo incerto e permite recuperar a pré-imagem. Repetir não duplicou o incremento | interruption-and-lock.json · 5 |
| Migração nativa da base | Preservados verificador da credencial, conexão e perfil, opções, recibo incerto e confirmação SQL emitida na 0.38.0 e usada na 0.39.0 | upgrade-before.json e upgrade-after.json · 8 |
| Conjunto atual integrado | Descoberta, saúde, leitura dos 38 documentos, via MCP HTTP, recusa de caminho arbitrário; UPDATE e restauração em cópia do schema oficial de leads, com linha sintética 46 | integration-and-guide.json · 54 |
| Empacotamento | 101 verificações funcionais locais aprovadas acima. Separadamente, 15 verificações de pacote, incluindo lint de 457 PHP, 469 membros, nenhuma remoção de arquivo de runtime da base e comparação dos bytes | package-check.json |
| Site-Teste | Troca 0.38.0 → 0.39.0 pelo próprio conector, pacote com hash conferido, ativo antes e depois. Home e REST HTTP 200 nas sondas anteriores e posteriores. Saúde final positiva, recuperação com zero pendências. Os oito outros plugins preservaram versão e atividade | site-teste.json |
| Aceite funcional no Site-Teste | UPDATE de uma linha do rascunho sintético, `selected_rows:1`, `selection_exact:true`, `applied:true`, `persisted:true`. Backup privado de 435 bytes. Restauração pelo ID devolveu o texto original, confirmado por consulta independente. A repetição da escrita devolveu o recibo prévio e o rascunho continuou restaurado | site-teste.json |
| Documentação do Site-Teste | 38 documentos lidos integralmente em 44 páginas. Cada texto teve bytes e SHA-256 comparados ao fonte; o schema instalado anuncia `selected_rows` | site-guide.json |

Instalador usado pelo Site-Teste: seção 8. A troca usou `plugins/upload-base64` com arquivo temporário, `expected_slug: wp-mcp-fator3` e `expected_sha256`. Operação de pacote `a6c13355ddc42e083afadcf8fbf35be8`. Backup SQL do ensaio `260d5df36fa3792c310cfb8b3181fadc`. O rascunho de teste foi excluído definitivamente e a contagem por seu ID voltou a zero. O ZIP temporário foi removido por hash. Restam os comprovantes do teste e suas pré-imagens privadas, sujeitos à retenção do site.

Para implantação da frota, após publicação pelo responsável, conferir os bytes em `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/wp-mcp-fator3-0.39.0-instalador.zip`. Em seguida usar `plugins/upload` com URL, slug, hash da seção 8, overwrite e activate. Conferir a versão em nova requisição e consultar `system/guide` com o documento `release-0390`. Essa URL é o destino previsto para publicação; não foi publicada nem verificada nesta rodada.

## 5. Banco, migração e correção por nova versão

Não há nova tabela, opção ou migração em massa. O novo formato de pré-imagem usa armazenamento privado já existente e índice de artefatos SQL. O token associa a intenção e o escopo à prévia, usuário, site e conexão de escrita. Recebida resposta incerta, consulte `operations/status` e leia o estado atual antes de nova ação. Em falha após instalação, a correção segue em versão posterior. Backups de dados e comprovantes são preservados.

## 6. O que permanece pendente

- **Frota / korvena.com.br — Pedido 77.** Para fechar o aceite original, implantar o ZIP verificado, obter a alteração de negócio exata e atual para o registro 46, fazer nova prévia com o escopo reduzido e confirmar. Registrar duração, resposta, backup_id, readback e saúde. O valor a gravar não consta da aba. Nesta rodada não houve alteração de dados nem implantação em produção.
- **Runtime.** O piso exato PHP 8.3.0 não esteve disponível nas bancadas usadas; PHP 8.3.6 e 8.3.36 foram exercitados. A hipótese para os 502 históricos segue sem atribuição causal comprovada.
- As APIs comerciais não foram chamadas. O escopo de integração foi o transporte e o schema SQL pertinente, sem homologação de contas, campanhas ou envios.

## 7. Credenciais e configuração do dono

Utilizar credencial administrativa já autorizada com perfil Manutenção, canal de arquivos e escrita SQL habilitados no servidor. Tela: Ferramentas → Fator3 MCP. A release não requer novo segredo nem mudança global de política. Leitura do guia usa seu gate documental. As provas de permissão incluem recusa da escrita e da restauração para perfil de leitura. Artefatos de linhas devem ter a mesma proteção de acesso que os dados originais.

## 8. Identidade dos arquivos

| Artefato | Arquivo | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | [wp-mcp-fator3-0.39.0-instalador.zip](./wp-mcp-fator3-0.39.0-instalador.zip) | 920888 | `158760eb738041848193611de4b07ea18d0dd4755f99f15e0735e28d90edae48` |
| Fonte | [wp-mcp-fator3-0.39.0-fonte.zip](./wp-mcp-fator3-0.39.0-fonte.zip) | 4325511 | `e693abba43d2be07f456d62a6b0612767553502cbd2eddce98f92c882cf9c4ed` |

Relatório externo canônico. A cópia no ZIP é anterior ao fechamento do fonte. O instalador pode ser reconstruído byte a byte a partir do fonte entregue.
