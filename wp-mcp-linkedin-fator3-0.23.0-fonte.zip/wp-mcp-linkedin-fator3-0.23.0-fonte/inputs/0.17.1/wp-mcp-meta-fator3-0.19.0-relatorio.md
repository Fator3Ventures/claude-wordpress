# Entrega — Fator3 MCP Meta 0.19.0

Revisão documental **2**, em 01/11/2026, America/Sao_Paulo. Versão corrente do software: **0.19.0**, mantida sem alteração de código. Esta revisão substitui o relatório externo e acrescenta provas de compatibilidade com Core 1.67.0 e Google 0.26.0. Instalador e fonte originais permanecem byte a byte iguais.

O documento de pedidos desta rodada é idêntico ao utilizado para implementar a 0.19.0. O Pedido27 já está implementado; não foi recebido Pedido28 nem nova evidência de falha da 0.19.0. A análise e os testes não demonstraram necessidade de correção no Meta. Conforme os normativos do projeto, isso não justifica novo minor ou patch. As alterações desta revisão estão no material de validação e no relatório, sem constituir nova versão do plugin.

## 1. Bases, instruções e rastreabilidade

Aplicados integralmente `01-instrucoes-agentes-plugins-fator3.md` e `02-padrao-desenvolvimento-plugins-fator3.md`, revisão4, e as orientações do dono: retenção máxima, teste livre no Site-Teste e relatório de impacto restrito a impactos técnicos novos/pedidos a outro mantenedor. Plano anterior aos testes: `planning/review.md` do arquivo de validação. O identificador interno `0200` dos testes não é uma versão de software entregue.

Base desta revisão: instalador e fonte finais Meta 0.19.0. A entrega original implementou o Pedido27 sobre a 0.18.0. O relatório original foi preservado byte a byte em `history/wp-mcp-meta-fator3-0.19.0-relatorio-revisao1.md` no arquivo de validação: 18798 bytes, SHA-256 `6124f88e22b853a4d21c2c21af9c04338505f8dbb29ce11b31678d6654d5a5d2`.

Entradas desta revisão, lidas e conferidas:

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| base-site-core-fator3-1.67.0-relatorio(2).md | 21584 | `21ae03d8e0decc04b6eb2a5851bb526d1ae1bc0b8fed5974f5b61318fa204de4` |
| base-site-core-fator3-1.67.0-fonte(2).zip | 8423214 | `b27e26695befc939cf147891baffa5bbb6aa930f9f25ef97a4269d539358755c` |
| wp-mcp-google-fator3-0.26.0-instalador(3).zip | 896007 | `f75031f2a430e099b7d3603d321993a049b4fb49606b9267144a59971eeebfe4` |
| base-site-core-fator3-1.67.0-instalador(2).zip | 4219398 | `d781cdbccfb00fc3224385e4e12e8e67bf4a06b58e2c1f1d6a686bca3df94c6b` |
| Fator3 MCP Meta(20261102-013417).md | 5333 | `dbc2fcda02360e09acf848dafe0a7bd97f8a8a3985a7d5d94b999f17d72ae89f` |
| wp-mcp-google-fator3-0.26.0-fonte(3).zip | 7215381 | `cf3ce94a99943e9ae562abc956d8db5a9e08bfa8ff3ef7968e93d8aa5b00b567` |
| wp-mcp-google-fator3-0.26.0-relatorio(3).md | 14643 | `07d38edcc4e57d9e6608f341ea384830ae81f26b3b963a3c809188eecd1ea3c6` |

O pedido recebido tem 5333 bytes e SHA-256 `dbc2fcda02360e09acf848dafe0a7bd97f8a8a3985a7d5d94b999f17d72ae89f`, igual ao documento `Fator3 MCP Meta(20261101-213443).md` usado na entrega original. O relato de HTTP400/código100 refere-se ao contexto anterior; não constitui nova reprodução na 0.19.0. O aceite informado do Pedido26 continua preservado, sem reabertura.

## 2. Convivência e encaminhamentos

| Pacote | Base examinada nesta revisão | Resultado e limite |
|---|---|---|
| Meta | 0.19.0, 66 arquivos | Runtime intacto; instalação isolada e convivência aprovadas. |
| Core | 1.67.0 final recebido, 911 arquivos | SDK existente atende comparacao_meta. Todos os hashes finais conferidos na cópia privada. |
| MCP | 0.38.0, 467 arquivos | Contratos decorados, autorização e descoberta preservados. |
| Google | 0.26.0 recebido, 172 arquivos | Matriz integrada passou; pacote final conferido. Ajuste recebido de conversões ao Core não exige mudança no Meta. |
| LinkedIn | 0.14.0, 73 arquivos | Capabilities executada pelo MCP; arquivos/estado compartilhados preservados. Nenhuma regressão observada nesse escopo. |
| Pipedrive | 0.5.0, 31 arquivos | Registro/status e negação sem concessão preservados; sem envio. |

O Core 1.67.0 adiciona `comparacao_meta` a `f3base/meta-entregas-ler`, consumindo o SDK de monitoramento já publicado pelo Meta. Agrupa por dataset/evento/dia/fuso do produtor e conserva desconhecidos e cobertura. A comparação local não transforma soma navegador+servidor em eventos únicos. Não foi necessário mudar o produtor, seus contratos, IDs ou autorizações.

O Core compartilhado no Site-Teste está identificado como 1.67.0, mas seu arquivo `includes/class-f3base-cache-pagina.php` ainda difere do pacote final recebido: SHA-256 observado `f6f839293b98bfac0d079c4e6f46acd60f0a9a5e9676b868d89eaaed744c050a`; final recebido `9b2e68a7b77bec58f28c4cc2921470ceb10e37d86004c87149c692bec9ee1740`. O relatório do Core já registra essa diferença de implantação. Nesta revisão, apenas a cópia privada recebeu o arquivo final e passou na conferência dos 911 hashes. O Core compartilhado não foi atualizado. Não se declara implantação do Core final com base nos testes privados.

Não surgiu impacto técnico novo nem solicitação a outro mantenedor. Não acompanha relatório de impacto, respeitando a finalidade definida pelo dono. Em particular, não há pedido de alteração do LinkedIn decorrente desta revisão. A observação de implantação do Core acima é uma limitação já documentada por seu mantenedor, não um novo impacto criado pelo Meta.

## 3. Mudanças examinadas e provas

### 3.1 Software preservado

Nenhum arquivo de runtime do Meta foi alterado. Permanecem as melhorias da 0.19.0: diagnóstico sanitizado com chamada/etapa e rastreio; vínculo confirmado por `act_conta/adspixels`; consultas stats independentes com agregação event; coleta parcial que preserva dados úteis quando stats/EMQ falham; cobertura conservadora por evento/dia/fuso; bloqueios de revogação, conflito e persistência; retenção cifrada sem prazo. Os detalhes e o diff da implementação original permanecem na fonte 0.19.0 e no relatório histórico.

Código100 continua sem causa histórica comprovada nos sites reais. As novas informações de erro permitem investigar uma nova ocorrência. Um token diferente do salvo no plugin não comprova autorização da conexão instalada.

### 3.2 Validação nova

Executadas **251 verificações, zero falhas**, em WordPress 7.1.4/PHP 8.3.36/MySQL 8.4.11, com tabelas, pasta e salts próprios. HTTP Meta usa fixtures; chamadas de rede e correio dos processos de teste são bloqueadas/interceptadas. Uma tentativa de e-mail sintética do monitoramento foi interceptada antes do envio. Não houve chamada Meta real, anúncio, gasto, publicação ou contato comercial.

| Evidência em evidence/ | Verificações | Falhas |
|---|---:|---:|
| isolated-smoke.json | 36 | 0 |
| isolated-dataset.json | 77 | 0 |
| integrated-dataset0200.json | 92 | 0 |
| integrated-integration0200.json | 27 | 0 |
| integrated-coremonitor0200.json | 19 | 0 |
| **Total desta revisão** | **251** | **0** |

O dataset integrado inclui sete verificações adicionais de Core 1.67.0: execução do coletor Jobs com resposta parcial simulada, persistência e leitura pelo SDK até `comparacao_meta`; valor navegador5 com servidor desconhecido; cobertura e unicidade desconhecidas; janela e fuso exatos; classes de tráfego locais separadas; ausência de HTTP/e-mail extra na leitura; grant revogado devolvendo indisponibilidade e nenhuma linha, sem inferir zero. Essas provas exercitam a cadeia de implementação real com fornecedor simulado, sem afirmar aceite de uma conta de produção.

A suíte de diagnóstico cobre mensagens/chamadas sanitizadas, respostas transitórias/inválidas/vazias, proteção de segredos sintéticos, independência stats/EMQ, cobertura, dias de23/25 horas, zero explícito, revisão de concessão e autorização. Os ajustes novos estão apenas na bancada: IDs próprios de agenda e paginação da auditoria evitam depender da primeira agenda ou dos primeiros100 registros. Não são correções do plugin.

As 629 verificações finais e quatro de reprodução da entrega original permanecem **históricas**, fora do total251. Piso WordPress6.4/PHP8.1.2 exato e upgrade0.18.0→0.19.0 não foram reexecutados nesta revisão; seus registros anteriores continuam aplicáveis aos mesmos bytes de software. Não foi repetida uma homologação completa de todas as funções comerciais de cada acompanhante.

Conferidos os28 documentos por hash na instalação isolada. Pelo MCP do Site-Teste, relidos integralmente `COLLECTION-DIAGNOSTICS.md`, `MONITORING.md` e `input-schemas.json`, em seis páginas com revisão, bytes e SHA iguais ao pacote. Descoberta final:47 operações Meta0.19.0, sem operações QA. A entrega original já contém a leitura integral dos28 documentos em31 páginas; essa contagem não é apresentada como execução desta revisão.

## 4. Instalação efetiva e prontidão

Meta0.19.0 já estava instalado e ativo em https://fator3-teste-mcp-1.dreamhosters.com/ e permanece nessa condição. **Nenhum plugin foi reinstalado no ambiente compartilhado nesta revisão.** O recibo da instalação original continua no relatório histórico: operação `ffe251601de27360f1300ec6d26fcd3b`, pré-imagem `5a9db353cde0dcd70c2b0911`.

Health final: versão0.19.0, state=ok, storage_ready e crypto_ready verdadeiros, audit_health=ok, issues vazio, zero conexões e agendas ativas. Esse site não dispõe de credencial Meta comercial para homologar coleta real. A disponibilidade local não comprova prontidão de uma conexão de produção.

Os seis grupos de comparação antes/depois passaram: dois registros de negócio, histórico vazio, sete opções Meta e hashes individuais, configuração de monitoramento Core, versões/ativação/árvores dos seis plugins. Meta preserva tree SHA-256 `bb717b14c78c202b4c648c5fed5a7c5f23bcd256410a06c2192a6741f04c77dd`. A comparação não inclui a auditoria técnica das operações MCP nem estado volátil de manutenção.

Laboratório encerrado:101 tabelas privadas removidas, zero remanescentes, pasta e manifesto removidos. Controlador e bundle temporários excluídos com guarda de hash e backup. Sondas internas de `/` e `/wp-json/` com bypass retornaramHTTP200 durante a limpeza; não representam teste de acesso externo. Após a limpeza, health e catálogo normal foram novamente consultados.

Evidências: `shared-before.json`, `shared-after.json`, `shared-comparison.json`, `integrate.json`, `lab-cleanup.json`, recibos `cleanup-*`, `final-health.json`, `final-discovery.json` e `documents-verified.json`. Nenhuma regressão foi observada nos cenários exercitados; não se promete ausência universal de impacto fora deles.

## 5. Banco, retenção e reversão

Esta revisão não introduz DDL, tabela, coluna, option de negócio, migração, limpeza de acervo, alteração de retenção, grant, credencial ou agenda. Os dados compartilhados foram preservados. Não existe atualização nova do Meta a reverter; a única substituição de entrega é documental.

Para instalar a versão corrente em outro ambiente: backup consistente de arquivos, banco e salts; instalar o ZIP original0.19.0 sobre o mesmo slug `wp-mcp-meta-fator3`, basename `wp-mcp-meta-fator3/wp-mcp-meta-fator3.php`, sem desinstalar. Requisitos: WordPress6.4/PHP8.1.2 de64 bits, criptografia e travas nomeadas no banco. Conferir versão, health,47 operações/documentação e executar coleta com o token salvo.

A reversão da atualização original0.18→0.19 exige restaurar pré-imagem/instalador0.18 preservando banco e salts; retorna às consultas e diagnóstico anteriores. Não desfaz histórico já persistido nem efeitos externos. Não usar desinstalação como rollback. Nenhuma mudança irreversível de esquema foi introduzida pela0.19.0.

## 6. Pendências e aceite externo

| Item | Situação | Verificação restante |
|---|---|---|
| Pedido27 | Implementado na0.19.0; nova compatibilidade comprovada em laboratório | Aceite com token salvo em korvena.com.br e ctooffice: agenda dataset-qualidade-diario concluída/parcial e linhas no leitor Core, ou recusa legível com orientação. |
| Pedido26 | Aceite informado no documento recebido, preservado | Sem reabertura por esta revisão. |
| Pendência20 | Mantida | Monitoramento com alteração real, contagens/EMQ/próximo incidente;30 dias Ads comparados ao Gerenciador nas duas contas; Pedido22 com credencial real fora do padrão. |
| Pendência88 | Mantida | Twinia sem conexão, conforme documento recebido. |
| Core1.67.0 final no Site-Teste | Cópia final validada somente no laboratório | Implantação do arquivo final de cache pelo fluxo de manutenção do Core; esta revisão não a executou. |

Não foi alterado o documento de pedidos da frota nem declarado encerramento do Pedido27 em produção.

## 7. Credenciais e ações do operador

Nenhum segredo real incluído nos artefatos ou coletado do navegador. As fixtures são sintéticas; as provas de integridade usam digests sem conteúdo de negócio. O Site-Teste compartilhado permanece sem conexão Meta.

Na homologação real, consultar `meta/job-status`, `meta/list-schedules`, `meta/audit` e `meta/health`. Para job já pausado, verificar a causa e criar nova coleta/backfill quando apropriado; a0.19.0 não reautoriza nem retoma planos automaticamente. Preservar token, salts, seleções e concessões existentes ao instalar. O README do arquivo de validação contém a reprodução restrita ao Site-Teste e a limpeza necessária.

## 8. Artefatos e integridade

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| wp-mcp-meta-fator3-0.19.0-instalador.zip | 342993 | `f7629f48fffb774542a480fb55f29a151762b06a27b34c9a0c3188da3599451b` |
| wp-mcp-meta-fator3-0.19.0-fonte.zip | 4132426 | `21d13446e4b18cec279bfaf8c0bde0d3f93008e9832fe0b7f560ee1095c95ead` |
| wp-mcp-meta-fator3-0.19.0-validacao-core-1.67.0.zip | 252326 | `a36fb333c8a96d4cfe0629dd42e2c977644b0fe20c3a949d7c96cec0fe054dcb` |

Os dois ZIPs de software são exatamente os já entregues na0.19.0; não foram reconstruídos. A fonte mantém seu relatório interno original. A revisão documental2 é externa e não altera retroativamente esse arquivo imutável. O ZIP adicional contém apenas material de validação, entradas, uma cópia canônica de arquivo Core usada na bancada e evidências; **não é instalador** e não deve ser enviado ao instalador de plugins WordPress. Não contém ZIP aninhado. A identidade deste relatório é calculada após fechamento e registrada no recibo externo, sem autorreferência.
