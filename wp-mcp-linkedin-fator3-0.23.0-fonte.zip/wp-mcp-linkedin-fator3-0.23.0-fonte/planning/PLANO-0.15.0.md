# Plano — Fator3 MCP LinkedIn 0.15.0

Revisão 1, 02/11/2026 UTC. Base aceita 0.14.0, instalador SHA-256 91b49ab4aaac5487657496d22d2d1e3a31334a4afa2547dd7946ebdf1d9868ef. Alvo ainda não gerado.

Escopo: pedidos LinkedIn 18–21 recebidos em Fator3 MCP LinkedIn(20261102-013138).md. Somente código e documentos do emissor. Core 1.67.0, Google 0.26.0, Meta 0.19.0 recebidos; MCP 0.38.0 e Pipedrive 0.5.0 recuperados para convivência. Normas recebidas e revisão 5 preservada na base aplicadas. Não alterar pedidos centrais ou documentos de acompanhantes.

18: classificar rejeição definitiva de criação (400/401/403/404/422 sem recibo); persistir diagnóstico sanitizado; escape administrativo explícito com CAS, motivo e reconhecimento de risco; migração conservadora do diário. A base não preserva HTTP nem mensagem no diário/auditoria comum: códigos isolados não provam ausência de recibo; os dois incidentes relatados usam evidência recebida delimitada por conexão/conta/prefixo/operação, e diagnósticos futuros completos permitem migração genérica. Não inventar recibo nem generalizar upstream_error. Exigir início na prévia e corrigir alcance da trava.

19–20: corrigir somente finder leadNotifications; anotar falhas anteriores ao POST com efeito none, sem substituir efeito de repetição já enviada; trim de respostas textuais compartilhado por getter/finder. Reproduzir com fixtures dos formatos reais, preservando multi-seleção e conteúdo interno.

21: contrato aditivo linkedin-lead-reader/1.2.0; seleção all_forms_accounts por conexão/concessão, simulação e revisão; descoberta periódica limitada e retomável, sem alteração de concessões antigas; catálogo próprio, criação idempotente de webhook na mesma passagem e evento durável notificável ao consumidor, com identidade/versão/instante e recibo. Registro local no canal Registro. O Core 1.67.0 ainda mantém seleção própria explícita: precisa incorporar evento/seleção na integração. Encaminhamento: ../impacts/wp-mcp-linkedin-fator3-0.15.0-impacto-base-site-core-fator3.md. Implementação do produtor independente, opt-in; não alegar aceite ponta a ponta do consumidor antigo.

Provas previstas: reprodução dos defeitos na base; testes dirigidos de rejeição/incerteza/escape/migração, concessão/revogação, paginação/retomada, respostas canônicas; WordPress real limpo e atualização direta; matriz mínima WP 6.4/PHP 8.1.2; integração com pacotes recebidos, DOM da seleção, leitura documental completa; Site-Teste autorizado, somente LinkedIn, com inventário e backup. Fornecedor real e aceites de ctooffice são evidência recebida/aceite de frota, não provas locais.

Entrega: fonte, instalador, relatório em oito seções e impacto Core pertinente, hashes exatos, sem dependências de laboratório ou dados privados.

## Revisão 2 — implementação e revisão

Produtor 1.2 implementado com 97 operações totais. Migração limitada às provas persistidas e aos dois incidentes recebidos, sem inferir rejeição por código antigo genérico. Evento/checkpoint atômicos, recuperação paginada e assinatura idempotente foram exercitados com interrupção injetada. Rejeição cobre resposta 4xx vazia ou envelope de erro sem recibo; respostas ambíguas permanecem incertas. Correções da bancada: contagens do catálogo para 97 operações, paginação do Registro e espera da renderização assíncrona; nenhuma dessas correções afrouxa autorização ou asserção funcional.

## Revisão 3 — entrega

Instalador 345084 bytes, SHA-256 e12b2b468b71c53d7ecc67c55f758ee1af5ba2b24082f9b12046c66944169e85. Site-Teste atualizado exclusivamente no LinkedIn de 0.14.0 para 0.15.0, operação 56985276877a20a582826b627b3cc1c0, backup 365299839b7eb1f16619f7af, sondas 200 e autoteste local aprovado. Documentação integral: 35 documentos, 37 páginas remotas, bytes/hashes idênticos ao instalador. Matriz e contagens finais no relatório e evidence/release0150.

Encaminhamento Core mantém situação aberta: contrato do produtor entregue, adoção/aceite do consumidor e teste real com formulário/lead novos pendentes. Não há impacto técnico que exija alterar MCP 0.38.0, Google 0.26.0, Meta 0.19.0 ou Pipedrive 0.5.0 nesta rodada; convivência, metadados de execução e limites registrados no relatório. Nenhum documento central ou pacote desses responsáveis foi editado.
