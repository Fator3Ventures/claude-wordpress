# Planejamento — LinkedIn 0.17.1

Revisão 2 · 02/11/2026 · implementação e fechamento. A revisão 1 anterior ao código, inicialmente alvo 0.17.0, está preservada em release-0.17.0-revisao1.md; o encaminhamento inicial ao Core está em impacto-core-0.17.0-revisao1-antes-do-codigo.md.

Mantidos base aceita 0.16.0, escopo dos pedidos 18/21/22/23, contratos e matriz da revisão 1. Core 1.68.0, MCP 0.38.0, Google 0.26.0, Meta 0.19.0, Pipedrive 0.5.0 examinados. Sem alterações em outros pacotes ou nas abas centrais.

As normas comuns revisão 5 de 23/10 foram recuperadas durante a conferência final, substituindo a revisão 4 usada inicialmente. Respostas/aceites aos impactos recebidos ficam exclusivamente no relatório principal; o impacto próprio só é revisado pela especificação técnica adicional da adoção (alias para recibo canônico, validação de existência, ausência de novo POST) e orientação coordenada ao consumidor. Não reemitir o pedido antigo de adoção de resolve_campaign para comunicar resposta.

A 0.17.0 passou nos testes funcionais e foi instalada apenas no Site-Teste nesta rodada. A conferência documental por MCP encontrou referência corrente a 0.16.0 e cabeçalhos antigos. O patch 0.17.1 corrige essa incoerência, acrescenta verificação documental e preserva o instalador intermediário imutável. Base direta para o dono continua 0.16.0; 0.17.0 não é etapa necessária.

Fechamento: repetir testes pertinentes sobre 0.17.1, comprovar diff sem alteração funcional em relação à intermediária, instalação única sequencial 0.17.0 → 0.17.1 no Site-Teste, documentação integral, inventário e hashes dos cabeçalhos acompanhantes. Fonte sem dependências externas ou ZIPs internos. Relatório interno anterior ao fechamento; hash do fonte apenas no externo. Homologação real ctooffice e adoção complementar Core continuam pendentes com seus responsáveis.
