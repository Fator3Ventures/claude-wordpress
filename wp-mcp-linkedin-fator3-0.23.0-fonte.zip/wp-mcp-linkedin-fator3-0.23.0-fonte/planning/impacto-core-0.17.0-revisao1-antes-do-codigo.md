# Impacto — LinkedIn 0.17.0 → Site Core

Emissor: wp-mcp-linkedin-fator3, base 0.16.0, alvo 0.17.0. Destinatário: base-site-core-fator3 1.68.0. Etapa: planejamento; revisão 1; 02/11/2026. Situação: aberto. Classes: validacao-coordenada / acao-necessaria. Pedidos: LinkedIn 21–23, Core 369(d).

## Consequência e decisão proposta

Leitura de leads deve sobreviver à recusa da projeção opcional: retry GET único sem fields; campanha sem decoração permanece not_provided. Core deve continuar ingestão e recuperar suas janelas pendentes, sem inventar nome. A extensão resolve_campaign 1.0.0 permanece disponível mediante campaign_lookup explícito; sua adoção e política de enriquecimento continuam responsabilidade Core, pendentes desde o impacto 0.16.0.

Descoberta emitirá vários eventos por passagem limitada e reutilizará recibos confirmados próprios existentes no contrato 1.1. Eventos mantêm outbox/sequence, entrega pelo menos uma vez e ownership_key canônica. Consumidor deve continuar persistindo checkpoint junto da seleção e deduplicar; nenhuma nova ingestão compete com ele. Alterações de conexão preservam grants de domínios não afetados; identidade de serviço CAPI permanece nas alterações benignas.

## Sequência, evidência e aceite

Implementar somente LinkedIn, testar Core 1.68 original como consumidor, instalação limpa e upgrade da 0.16.0 com assinaturas 1.1. Depois validar leitura dos quatro formulários, outbox/assinaturas sem duplicação e readiness CAPI após mudança só de leads. Testes previstos incluem recusas 400/403/429, alteração concorrente de grant e retorno sem nome. Não é necessária nova versão Core para consumir o comportamento existente de descoberta ou continuar sem nome. O fallback de campanha exige adoção explícita própria.

Provas de fornecedor/ctooffice dependem de implantação da frota e credenciais autorizadas; não serão declaradas a partir de fixtures. Nenhum arquivo ou documento central Core/MCP é alterado. Documento preparado para encaminhamento, sem envio a pessoas.

Evolução: revisão 1 emitida antes da implementação; revisar com evidências ao fechar a entrega.
