<?php
/** Contexto canônico compartilhado por cliques e formulários. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Leads_Contexto {
    public static function sessao( $valor ): ?string {
        return is_string( $valor ) && preg_match( '/^[a-f0-9]{32}$/D', $valor ) ? $valor : null;
    }
    /** Nunca usa nome/e-mail para inferir a ação de um CTA. */
    public static function destino( string $url ): array {
        $invalid=array('metodo'=>'contato_cta','tipo'=>'invalido','valido'=>false);
        if($url===''||$url[0]==='#'||preg_match('/[\x00-\x20\x7f\\\\]/',$url)){return $invalid;}
        $p=wp_parse_url($url);if(!is_array($p)||isset($p['user'])||isset($p['pass'])){return $invalid;}
        $scheme=strtolower($p['scheme']??'');$host=strtolower($p['host']??'');$path=$p['path']??'';
        $tipo='';parse_str($p['query']??'',$query);
        if($scheme==='tel'&&preg_match('/^\+?[0-9().-]{5,30}$/D',$path)){$tipo='telefone';}
        elseif($scheme==='mailto'&&is_email(rawurldecode($path))){$tipo='email';}
        elseif($scheme==='https'&&in_array($host,array('wa.me','api.whatsapp.com'),true)&&(!isset($p['port'])||$p['port']===443)){
            if(($host==='wa.me'&&(preg_match('#^/[1-9][0-9]{6,14}/?$#D',$path)||preg_match('#^/message/[A-Za-z0-9_-]+/?$#D',$path)))||($host==='api.whatsapp.com'&&rtrim($path,'/')==='/send'&&is_string($query['phone']??null)&&preg_match('/^[1-9][0-9]{6,14}$/D',$query['phone']))){$tipo='whatsapp';}
        }
        elseif(in_array($scheme,array('','http','https'),true)){
            $home=wp_parse_url(home_url());$same=!$host||($host===strtolower($home['host']??'')&&($scheme===''||$scheme===strtolower($home['scheme']??'https'))&&(int)($p['port']??($scheme==='https'?443:80))===(int)($home['port']??(($home['scheme']??'')==='https'?443:80)));
            if($same&&$path!==''){$tipo='interno';}
        }
        return $tipo===''?$invalid:array('metodo'=>$tipo==='whatsapp'?'whatsapp_cta':'contato_cta','tipo'=>$tipo,'valido'=>true);
    }
    public static function whatsapp_configurado(string $url): bool {
        $cfg=F3Base_Options::ler('f3base_contato');if(empty($cfg['carimbar_whatsapp_por_destino'])||self::destino($url)['tipo']!=='whatsapp'){return false;}
        $p=wp_parse_url($url);$n='';if(($p['host']??'')==='wa.me'){$n=trim($p['path']??'','/');}else{parse_str($p['query']??'',$q);$n=$q['phone']??'';}
        $normal=static fn($v)=>is_string($v)?preg_replace('/[+(). -]/','',$v):'';
        return preg_match('/^[1-9][0-9]{6,14}$/D',$normal($n))&&$normal($n)===$normal($cfg['whatsapp_e164']??'');
    }
    public static function pagina( string $url ): int {
        if ( '' === $url ) { return 0; }
        $p = wp_parse_url( $url );
        $site_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( false === $p || isset( $p['user'] ) || ( isset( $p['host'] ) && strtolower( $p['host'] ) !== $site_host ) ) { return 0; }
        $url = isset( $p['host'] ) ? $url : home_url( '/' . ltrim( $url, '/' ) );
        $id = url_to_postid( $url );
        if ( ! $id && untrailingslashit( $url ) === untrailingslashit( home_url() ) ) { $id = (int) get_option( 'page_on_front' ); }
        $post = $id ? get_post( $id ) : null;
        return $post instanceof WP_Post && is_post_publicly_viewable( $post ) && '' === $post->post_password ? (int) $id : 0;
    }
    /** Dados de rede vêm exclusivamente da requisição recebida pelo servidor. */
    public static function capturar( array $d, bool $medicao ): array {
        $publicidade=F3Base_Modulo_Consentimento::permite_categoria('publicidade');
        $d['atribuicao']=F3Base_Atribuicao::para_captura($d['atribuicao']??array(),$medicao,$publicidade);
        $d['atribuicao_reducao']=$medicao?($publicidade?'nenhuma':'publicidade_nao_permitida'):'medicao_nao_permitida';
        $d['consentimento_publicidade']=$publicidade;
        $d['consentimento_snapshot']=F3Base_Modulo_Consentimento::referencia_confirmada()+array('medicao'=>$medicao,'publicidade'=>$publicidade);
        if(!F3Base_Modulo_Consentimento::modo_granular()){$d['consentimento_snapshot']['politica_versao']='legado:'.F3Base_Modulo_Consentimento::politica_versao();}
        $origem = F3Base_Modulo_Endpoint_Leads::origem();
        $ip = filter_var( $origem['valor'] ?? '', FILTER_VALIDATE_IP ) ?: null;
        $d['navegacao'] = $medicao ? self::sessao($d['navegacao'] ?? null) : null;
        $d['dispositivo'] = $medicao && in_array($d['dispositivo']??'',array('movel','desktop'),true) ? $d['dispositivo'] : '';
        $d['sessao'] = $medicao ? self::sessao( $d['sessao'] ?? null ) : null;
        $d['correlacao'] = $d['correlacao'] ?? $d['correlation_id'] ?? null;
        $d['post_id'] = self::pagina( (string) ( $d['pagina'] ?? '' ) ) ?: null;
        $d['contexto'] = array(
            'ip' => $ip, 'ip_fonte' => $origem['fonte'] ?? 'indisponivel',
            'user_agent' => substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ), 0, 500 ),
            'superficie' => in_array($d['superficie']??'',array('conteudo','menu','flutuante','elementor'),true)?$d['superficie']:'',
            'post_id' => $d['post_id'], 'versao' => F3BASE_PLUGIN_VERSAO,
            'sessao_motivo' => $d['sessao'] ? 'informada_pelo_tracking' : ( $medicao ? 'tracking_sem_sessao' : 'medicao_nao_permitida' ),
        );
        $d['snapshot'] = array_merge( $d['snapshot'] ?? array(), array(
            'site' => get_bloginfo( 'name' ), 'pagina_titulo' => $d['post_id'] ? get_the_title( $d['post_id'] ) : '',
            'pagina_url' => $d['pagina'] ?? '',
        ) );
        return $d;
    }
}
