<?php
/** Uma configuração de navegação, sem alterar menus ou templates do tema. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Navegacao {
    const OPTION='f3base_navegacao';
    private static bool $migrando=false;
    private static array $observados=array();
    public static function iniciar(): void {
        add_action('wp_ajax_f3base_navegacao_buscar',static function(){check_ajax_referer('f3base-navegacao','nonce');if(!current_user_can('manage_options')){wp_send_json_error(array('codigo'=>'sem_permissao'),403);}wp_send_json(self::listar(array('tipo'=>sanitize_key($_GET['tipo']??''),'busca'=>sanitize_text_field(wp_unslash($_GET['busca']??'')),'pagina'=>max(1,(int)($_GET['pagina']??1)))));});
        add_filter('pre_option_f3base_nav_id',static function(){ $v=F3Base_Options::ler(self::OPTION);return ($v['tipo']??'tema')==='bloco'?(int)$v['id']:0; });
        add_filter('render_block_data',static function($b){if(($b['blockName']??'')==='core/navigation') { self::$observados[]=(int)($b['attrs']['ref']??0); }return $b;},PHP_INT_MAX);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('navegacao-listar','Pesquisar menus clássicos e blocos publicados',array(__CLASS__,'listar'),array('tipo'=>array('type'=>'string','enum'=>array('menu_classico','bloco')),'busca'=>array('type'=>'string','maxLength'=>100),'pagina'=>array('type'=>'integer','minimum'=>1)),array('tipo'));});
    }
    public static function schema(): array {return array('type'=>'object','additionalProperties'=>false,'required'=>array('schema','tipo','id'),'properties'=>array('schema'=>array('type'=>'integer','enum'=>array(1)),'tipo'=>array('type'=>'string','enum'=>array('tema','menu_classico','bloco')),'id'=>array('type'=>'integer','minimum'=>0)));}
    public static function catalogo(array $c): array {
        $c['f3base_nav_id']['operavel']=false;
        $c['f3base_nav_id']['derivada']=true;
        $c['f3base_nav_id']['descricao']='Projeção somente de leitura: ID de bloco, ou zero. Escreva f3base_navegacao.';
        $c['f3base_nav_id']['recusa']=static fn()=> 'Use f3base_navegacao; f3base_nav_id é derivada e não aceita escrita.';
        $c[self::OPTION]=array('rotulo'=>'Navegação do site','descricao'=>'Escolha quem administra a navegação e, se necessário, a referência publicada. O tema continua responsável por exibi-la.','operavel'=>true,'secao'=>'conteudo','campo'=>'grupo','padrao'=>array('schema'=>1,'tipo'=>'tema','id'=>0),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>array(__CLASS__,'recusar'),'schema_config'=>self::schema(),'schema_entrada'=>self::schema(),'subcampos'=>array('schema'=>array('tipo'=>'inteiro','rotulo'=>'Versão do formato'),'tipo'=>array('tipo'=>'enum','rotulo'=>'Origem da navegação','opcoes'=>array('tema'=>'Administrada pelo tema','menu_classico'=>'Menu clássico','bloco'=>'Bloco de navegação')),'id'=>array('tipo'=>'inteiro','rotulo'=>'Referência selecionada')));
        return $c;
    }
    public static function recusar($v): string {
        $r=rest_validate_value_from_schema($v,self::schema());if(is_wp_error($r)){return $r->get_error_message();}
        if($v['tipo']==='tema'){return $v['id']===0?'':'Navegação administrada pelo tema exige ID zero.';}
        if(self::$migrando){return '';}
        return self::diagnostico($v)['referencia_valida']?'':'Selecione um menu clássico existente ou um bloco de navegação publicado do tipo escolhido.';
    }
    public static function migrar(): array {
        if(F3Base_Options::fotografia(self::OPTION)['existe']){return array('ok'=>true);}
        $old=F3Base_Options::fotografia_bruta('f3base_nav_id');if($old['erro']){return array('ok'=>false,'codigo'=>'navegacao_leitura_falhou');}
        $id=max(0,(int)($old['valor']??0));$v=array('schema'=>1,'tipo'=>$id?'bloco':'tema','id'=>$id);
        self::$migrando=true;try{$r=F3Base_Options::gravar(self::OPTION,$v,F3Base_Options::ORIGEM_MIGRACAO,F3Base_Options::revisao(self::OPTION));}finally{self::$migrando=false;}
        if(!empty($r['persisted'])){delete_option('f3base_nav_id');}
        return array('ok'=>!empty($r['persisted']),'codigo'=>$r['codigo']??'navegacao_migrada');
    }
    public static function diagnostico(?array $v=null): array {
        $v=$v??F3Base_Options::ler(self::OPTION);$tipo=$v['tipo']??'';$id=(int)($v['id']??0);$valid=false;$ref=null;$assoc=array();
        if($tipo==='tema'){$valid=$id===0;}
        elseif($tipo==='menu_classico'){$term=get_term($id,'nav_menu');$valid=$id>0&&$term&&!is_wp_error($term);if($valid){$ref=array('id'=>$id,'nome'=>$term->name);foreach(get_nav_menu_locations() as $loc=>$term_id){if((int)$term_id===$id){$assoc[]=$loc;}}}}
        elseif($tipo==='bloco'){$p=get_post($id);$valid=$id>0&&$p&&$p->post_type==='wp_navigation'&&$p->post_status==='publish';if($p){$ref=array('id'=>$id,'nome'=>$p->post_title,'status'=>$p->post_status);}}
        return array('configuracao'=>$v,'referencia_valida'=>(bool)$valid,'referencia'=>$ref,'associacao'=>array('localizacoes'=>$assoc,'suporte_declarado'=>current_theme_supports('f3base-navigation')),'uso_observado'=>array('escopo'=>'requisição atual','blocos_renderizados'=>array_values(array_unique(self::$observados))),'uso_no_cabecalho'=>'nao_comprovado','warnings'=>$valid?array():array('referencia_invalida_ou_indisponivel'));
    }
    public static function listar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $page=max(1,(int)($e['pagina']??1));$q=sanitize_text_field($e['busca']??'');$items=array();
        if(($e['tipo']??'')==='menu_classico'){$rows=get_terms(array('taxonomy'=>'nav_menu','hide_empty'=>false,'search'=>$q,'number'=>51,'offset'=>($page-1)*50));if(is_wp_error($rows)){return array('ok'=>false,'codigo'=>'consulta_falhou');}foreach($rows as $p){$items[]=array('id'=>(int)$p->term_id,'nome'=>$p->name);}}
        elseif(($e['tipo']??'')==='bloco'){$rows=get_posts(array('post_type'=>'wp_navigation','post_status'=>'publish','s'=>$q,'posts_per_page'=>51,'offset'=>($page-1)*50,'orderby'=>'ID','order'=>'ASC'));foreach($rows as $p){$items[]=array('id'=>(int)$p->ID,'nome'=>$p->post_title);}}
        else{return array('ok'=>false,'codigo'=>'tipo_invalido');}
        return array('ok'=>true,'itens'=>array_slice($items,0,50),'pagina'=>$page,'proxima_pagina'=>count($items)>50?$page+1:null);
    }
    public static function render(array $v): void {
        echo '<input type="hidden" name="f3base[f3base_navegacao][schema]" value="1"><label for="f3base-nav-tipo">Origem da navegação</label> <select id="f3base-nav-tipo" name="f3base[f3base_navegacao][tipo]">';
        foreach(array('tema'=>'Administrada pelo tema','menu_classico'=>'Menu clássico','bloco'=>'Bloco de navegação') as $k=>$label){echo '<option value="'.esc_attr($k).'" '.selected($v['tipo']??'tema',$k,false).'>'.esc_html($label).'</option>';}
        echo '</select><p><label for="f3base-nav-id">Menu ou bloco (ID e nome)</label> <select id="f3base-nav-id" name="f3base[f3base_navegacao][id]"><option value="0">0 — Administrado pelo tema</option>';
        $seen=array('tema:0');foreach(array('menu_classico'=>'Menus clássicos','bloco'=>'Blocos publicados') as $tipo=>$label){echo '<optgroup label="'.esc_attr($label).'">';$r=self::listar(array('tipo'=>$tipo));foreach($r['itens']??array() as $i){$seen[]=$tipo.':'.$i['id'];echo '<option data-tipo="'.esc_attr($tipo).'" value="'.$i['id'].'" '.selected(($v['tipo']??'')===$tipo?(int)$v['id']:-1,$i['id'],false).'>'.esc_html($i['id'].' — '.$i['nome']).'</option>';}echo '</optgroup>';}
        if(!in_array(($v['tipo']??'tema').':'.(int)($v['id']??0),$seen,true)){echo '<option selected value="'.(int)$v['id'].'">'.(int)$v['id'].' — referência atual fora da lista; confira o diagnóstico</option>';}
        echo '</select></p><p><label for="f3base-nav-busca">Pesquisar por nome</label> <input id="f3base-nav-busca" type="search" maxlength="100"> <button type="button" class="button" id="f3base-nav-pesquisar" data-nonce="'.esc_attr(wp_create_nonce('f3base-navegacao')).'" data-url="'.esc_url(admin_url('admin-ajax.php')).'">Pesquisar</button> <button type="button" class="button" id="f3base-nav-proxima" hidden>Próxima página</button> <span id="f3base-nav-status" role="status"></span></p><p>A pesquisa usa o tipo selecionado e mostra 50 itens por página. A associação não prova a exibição no cabeçalho.</p><details><summary>Diagnóstico da navegação</summary><pre>'.esc_html(wp_json_encode(self::diagnostico($v),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details>';
    }
}
