<?php
/** Versioned read-only profiles. A complete profile is not proof that a site conforms. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Config_Perfil {
    public const ID='piso-padrao-3.2';
    public const REVISAO='2026-09-29-core-1.16.0';
    public const OBSERVACOES=array('cache.publico','publicacao:/robots.txt','publicacao:/llms.txt','publicacao:/llms-full.txt','configuracao.explicita');
    public static function schema(): array {
        $texto=array('type'=>'string','minLength'=>1,'maxLength'=>200);
        $cond=array('type'=>'object','additionalProperties'=>false,'required'=>array('id'),'properties'=>array(
            'id'=>$texto,'nome'=>$texto,'campo'=>array('type'=>'array','maxItems'=>8,'items'=>$texto),'observacao'=>$texto,
            'comparacao'=>array('type'=>'string','enum'=>array('igual','presente','derivado_do_host','contem','referencia_valida','configurado','verificado')),
            'esperado'=>F3Base_Config_Contrato::schema_dado('Valor de referência; segredo aceita somente presença.'),
            'regra'=>array('type'=>'string','enum'=>array('whatsapp','rotas_privadas','arquivo'))
        ));
        $excecao=array('type'=>'object','additionalProperties'=>false,'required'=>array('condicao','responsavel','motivo','expira_em','perfil_id','perfil_revisao','estado_ref'),'properties'=>array(
            'condicao'=>$texto,'responsavel'=>$texto,'motivo'=>array('type'=>'string','minLength'=>1,'maxLength'=>500),'expira_em'=>array('type'=>'integer','minimum'=>1),'perfil_id'=>$texto,'perfil_revisao'=>$texto,'estado_ref'=>$texto
        ));
        $excecoes=array('type'=>'array','maxItems'=>200,'items'=>$excecao);
        return array('type'=>'object','additionalProperties'=>false,'properties'=>array(
            'perfil_id'=>$texto,'perfil_revisao'=>$texto,'excecoes'=>$excecoes,
            'perfil'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('id','revisao','condicoes'),'properties'=>array(
                'id'=>$texto,'revisao'=>$texto,'condicoes'=>array('type'=>'array','minItems'=>1,'maxItems'=>200,'items'=>$cond),'excecoes'=>$excecoes,'exigir_gravacao'=>array('type'=>'boolean')
            )),
            'contexto'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('rotas_privadas'=>array('type'=>'array','maxItems'=>100,'items'=>array('type'=>'string','maxLength'=>500)),'regime_whatsapp'=>array('type'=>'boolean'))),
            'somente_divergencias'=>array('type'=>'boolean','default'=>false)
        ));
    }
    public static function distribuido(): array {
        $p=F3BASE_PLUGIN_DIR.'docs/perfis/piso-padrao-3.2.json';
        return is_readable($p)?(json_decode((string)file_get_contents($p),true)??array()):array();
    }
    public static function avaliar($e=null): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $cont=array('conforme'=>0,'divergente'=>0,'excecao_valida'=>0,'indeterminado'=>0);
        $erro=static fn($c)=>array('ok'=>false,'codigo'=>$c,'estado'=>'indeterminado','contadores'=>array_replace($cont,array('indeterminado'=>1)),'verificacoes'=>0,'itens'=>array(),'configuracao_alterada'=>false);
        if(!is_array($e)){return $erro('perfil_ausente');}
        if(is_wp_error(rest_validate_value_from_schema($e,self::schema()))){return $erro('perfil_invalido');}
        if(isset($e['perfil'])&&isset($e['perfil_id'])){return $erro('perfil_ambiguo');}
        $meta=array();
        if(isset($e['perfil_id'])){
            if($e['perfil_id']!==self::ID){return $erro('perfil_nao_encontrado');}
            $meta=self::distribuido();
            if(!$meta){return $erro('perfil_indisponivel');}
            if(isset($e['perfil_revisao'])&&$e['perfil_revisao']!==$meta['revisao']){return $erro('perfil_revisao_divergente');}
            if(version_compare(F3BASE_PLUGIN_VERSAO,$meta['plugin_minimo'],'<')){return $erro('perfil_incompativel');}
            $p=$meta['perfil'];
        }elseif(isset($e['perfil'])){$p=$e['perfil'];if(isset($e['perfil_revisao'])){return $erro('perfil_ambiguo');}}
        else{return $erro('perfil_ausente');}
        $p['excecoes']=array_merge($p['excecoes']??array(),$e['excecoes']??array());$itens=array();$vistos=array();
        foreach($p['condicoes'] as $c){
            if(isset($vistos[$c['id']])){return $erro('condicao_duplicada');}$vistos[$c['id']]=true;
            $r=self::comparar($c,!empty($p['exigir_gravacao']),$e['contexto']??array());
            if($r['estado']==='divergente'){foreach($p['excecoes'] as $ex){if($ex['condicao']===$c['id']&&$ex['perfil_id']===$p['id']&&$ex['perfil_revisao']===$p['revisao']&&$ex['expira_em']>time()){$r['estado']='excecao_valida';$r['excecao']=$ex;break;}}}
            ++$cont[$r['estado']];if(empty($e['somente_divergencias'])||in_array($r['estado'],array('divergente','indeterminado'),true)){$itens[]=$r;}
        }
        $state=$cont['divergente']?'divergente':($cont['indeterminado']?'indeterminado':($cont['excecao_valida']?'excecao_valida':'conforme'));
        return array('ok'=>true,'estado'=>$state,'perfil'=>array('id'=>$p['id'],'revisao'=>$p['revisao'],'completo'=>$meta['completo']??null,'escopo'=>$meta['escopo']??'declarado_pelo_chamador','revisao_fonte'=>$meta['revisao_fonte']??null),'checked_at'=>time(),'contadores'=>$cont,'verificacoes'=>count($p['condicoes']),'itens'=>$itens,'configuracao_alterada'=>false);
    }
    /** Require every top-level contract key; nested list objects only require applicable mandatory fields. */
    private static function faltantes($v,array $s,string $path='',bool $top=true): array {
        $r=array();$types=(array)($s['type']??array());
        if(in_array('object',$types,true)&&isset($s['properties'])){
            $keys=$top?array_keys($s['properties']):($s['required']??array());
            foreach($keys as $k){$p=$path===''?$k:$path.'.'.$k;if(!is_array($v)||!array_key_exists($k,$v)){$r[]=$p;}else{$r=array_merge($r,self::faltantes($v[$k],$s['properties'][$k],$p,false));}}
        }elseif(in_array('array',$types,true)&&is_array($v)&&isset($s['items'])){foreach($v as $i=>$item){$r=array_merge($r,self::faltantes($item,$s['items'],$path.'['.$i.']',false));}}
        return $r;
    }
    private static function valores($v,array $path,string $prefix='',string $regra=''): array {
        if(!$path){return array(array('caminho'=>$prefix,'existe'=>true,'valor'=>$v));}
        $k=array_shift($path);$r=array();
        if($k==='*'){
            if(!is_array($v)){return array(array('caminho'=>$prefix,'existe'=>false,'valor'=>null));}
            foreach($v as $i=>$item){if($regra==='arquivo'&&is_array($item)&&isset($item['tipo'])&&$item['tipo']!=='file'){continue;}$r=array_merge($r,self::valores($item,$path,$prefix.'['.$i.']',$regra));}return $r;
        }
        $next=$prefix===''?$k:$prefix.'.'.$k;
        if(!is_array($v)||!array_key_exists($k,$v)){return array(array('caminho'=>$next,'existe'=>false,'valor'=>null));}
        return self::valores($v[$k],$path,$next,$regra);
    }
    private static function comparar(array $c,bool $explicito,array $ctx): array {
        $r=array('id'=>$c['id'],'estado'=>'indeterminado','codigo'=>'condicao_nao_suportada','heranca_status'=>'indeterminado','chaves_herdadas'=>null);
        $cmp=$c['comparacao']??'igual';
        if(isset($c['observacao'])){
            $r['heranca_status']='nao_aplicavel';$r['chaves_herdadas']=array();
            if($c['observacao']==='configuracao.explicita'){
                $faltas=array();$inc=false;
                foreach(F3Base_Config_Contrato::nomes() as $n){if($n==='f3base_consentimento'||F3Base_Options::e_segredo($n)){continue;}
                    $d=F3Base_Options::declaracao($n);$f=F3Base_Options::fotografia_bruta($n);if($f['erro']){$inc=true;continue;}
                    $keys=$f['existe']?self::faltantes($f['valor'],F3Base_Config_Contrato::schema_valor($d)):array('');
                    if($keys){$faltas[$n]=$keys;}
                }
                return array_replace($r,array('estado'=>$inc?'indeterminado':($faltas?'divergente':'conforme'),'codigo'=>$inc?'leitura_falhou':'presenca_explicita','heranca_status'=>$inc?'indeterminado':($faltas?'herdado':'explicito'),'chaves_herdadas'=>$inc?null:$faltas));
            }
            if(!in_array($c['observacao'],self::OBSERVACOES,true)||$cmp!=='verificado'){return $r;}
            $proof=$c['observacao']==='cache.publico'?F3Base_Cache_Pagina::verificacao():F3Base_Publicacao_Sonda::consultar(array('caminho'=>substr($c['observacao'],11)));
            $ok=($proof['status']??'')==='verified'||!empty($proof['valida']);
            return array_replace($r,array('estado'=>$ok?'conforme':'indeterminado','codigo'=>$ok?'evidencia_vigente':'evidencia_ausente_ou_vencida','evidencia'=>$proof));
        }
        $nome=$c['nome']??'';$d=F3Base_Options::declaracao($nome);
        if(!$d||!empty($d['estado_execucao'])){return $r;}
        $f=F3Base_Options::fotografia_bruta($nome);if($f['erro']){$r['codigo']='leitura_falhou';return $r;}
        $r['nome']=$nome;$r['campo']=$c['campo']??array();$r['revisao']=$f['revisao'];
        if(F3Base_Options::e_segredo($nome)){
            if(!in_array($cmp,array('presente','configurado'),true)||!empty($c['campo'])){$r['codigo']='segredo_somente_presenca';return $r;}
            $obs=$f['existe']&&!in_array($f['valor'],array(null,'',array()),true);
            return array_replace($r,array('estado'=>$obs===($c['esperado']??true)?'conforme':'divergente','codigo'=>'segredo_presenca','heranca_status'=>$f['existe']?'explicito':'herdado','chaves_herdadas'=>$f['existe']?array():array(''),'observado'=>array('existe'=>$f['existe'],'tipo'=>gettype($f['valor']),'bytes'=>is_string($f['valor'])?strlen($f['valor']):null,'mascarado'=>true)));
        }
        $h=F3Base_Config_Consultas::heranca($nome,$d);$r['chaves_herdadas']=$h['chaves_herdadas'];$r['heranca_status']=$h['heranca_status'];
        if(!$h['leitura_confirmada']||!hash_equals($f['revisao'],F3Base_Options::revisao($nome))){$r['codigo']='configuracao_mudou';return $r;}
        $valor=$f['existe']?$f['valor']:($explicito?null:F3Base_Options::ler($nome));
        $values=$f['existe']||!$explicito?self::valores($valor,$c['campo']??array(),'',$c['regra']??''):array(array('caminho'=>'','existe'=>false,'valor'=>null));
        $esperado=$c['esperado']??true;$ok=true;$inc=false;$obs=array();
        if($cmp==='derivado_do_host'){$esperado='~/logs/'.preg_replace('/^www\\./i','',(string)wp_parse_url(home_url('/'),PHP_URL_HOST)).'/https/access.log.*';}
        if(($c['regra']??'')==='rotas_privadas'){
            if(!array_key_exists('rotas_privadas',$ctx)){$inc=true;}else{$esperado=array_values(array_unique(array_merge((array)$esperado,$ctx['rotas_privadas'])));}
        }
        foreach($values as $v){$value=$v['valor'];$valid=$v['existe'];
            $schema=F3Base_Config_Contrato::schema_valor($d);foreach($c['campo']??array() as $part){$schema=$part==='*'?($schema['items']??array()):($schema['properties'][$part]??array());}
            if($cmp==='presente'&&$valid&&$schema&&is_wp_error(rest_validate_value_from_schema($value,$schema))){$valid=false;}
            if($cmp==='presente'){
                if(empty($c['campo'])&&$valid){$missing=self::faltantes($value,F3Base_Config_Contrato::schema_valor($d));$valid=!$missing;$r['faltantes']=$missing;}
                if(($c['regra']??'')==='whatsapp'){$contato=F3Base_Options::ler('f3base_contato');$precisa=$ctx['regime_whatsapp']??!empty($contato['flutuante']);foreach(F3Base_Options::ler('f3base_formularios') as $form){$precisa=$precisa||($form['regime']??'')==='whatsapp';}if($precisa){$valid=$valid&&is_string($value)&&preg_match('/^[0-9]{10,15}$/D',$value);}}
            }elseif($cmp==='igual'||$cmp==='derivado_do_host'){$valid=$valid&&F3Base_Options::equivalente($value,$esperado);}
            elseif($cmp==='contem'){$valid=$valid&&is_array($value)&&is_array($esperado)&&!array_filter($esperado,static fn($x)=>!in_array($x,$value,true));}
            elseif($cmp==='configurado'){$valid=(!in_array($value,array(null,'',array()),true))===$esperado;}
            elseif($cmp==='referencia_valida'&&$nome==='f3base_navegacao'){$nav=F3Base_Navegacao::diagnostico(is_array($value)?$value:array());$r['navegacao']=$nav;$valid=$nav['referencia_valida'];}
            else{$r['codigo']='comparacao_nao_suportada';return $r;}
            $ok=$ok&&(bool)$valid;$obs[]=array('caminho'=>$v['caminho'],'existe'=>$v['existe'],'valor'=>$value,'conforme'=>(bool)$valid);
        }
        return array_replace($r,array('estado'=>!$ok?'divergente':($inc?'indeterminado':'conforme'),'codigo'=>$inc?'contexto_ou_uso_nao_confirmado':($values?'comparado':'sem_itens_aplicaveis'),'esperado'=>$esperado,'observado'=>$obs));
    }
}
