<?php
/** Relatórios de requisições, sem inferir identidade humana nem cruzar IP com leads. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Agentes {
    public static function tabela(bool $fontes=false): string {global $wpdb;return $wpdb->prefix.($fontes?'f3base_acessos_horas_fontes':'f3base_acessos_horas');}
    public static function instalar(): void {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();
        foreach(array(false,true) as $fonte){$t=self::tabela($fonte);$extra=$fonte?"fonte char(64) NOT NULL,\nregra char(64) NOT NULL,\n":'';$key=$fonte?'fonte,':'';
            dbDelta("CREATE TABLE {$t} (\n{$extra}dia date NOT NULL,\nhora_utc datetime NOT NULL,\nagente varchar(64) NOT NULL,\nclasse_caminho varchar(16) NOT NULL,\nstatus_grupo varchar(16) NOT NULL,\ncontagem bigint unsigned NOT NULL,\nPRIMARY KEY  ({$key}dia,hora_utc,agente,classe_caminho,status_grupo),\nKEY hora_agente (hora_utc,agente)\n) ENGINE=InnoDB {$cc};");}
    }
    public static function grupo(int $status): string {return ($status>=200&&$status<=299)||$status===304?'atendido':(in_array($status,array(403,429),true)?'bloqueado':'outro');}
    public static function observar(array &$horas,array $r,int $stamp): void {
        $hora=gmdate('Y-m-d H:00:00',$stamp);$grupo=self::grupo((int)$r['status']);$key=implode('|',array($r['dia'],$hora,$r['agente'],$r['classe_caminho'],$grupo));
        if(isset($horas[$key])){++$horas[$key]['contagem'];}else{$horas[$key]=array('dia'=>$r['dia'],'hora_utc'=>$hora,'agente'=>$r['agente'],'classe_caminho'=>$r['classe_caminho'],'status_grupo'=>$grupo,'contagem'=>1);}
        if(count($horas)>20000){throw new RuntimeException('Teto de agregados horários excedido; contribuição anterior preservada.');}
    }
    /** Executadas na mesma transação da contribuição diária. */
    public static function guardar(string $fonte,string $regra,array $horas): void {
        global $wpdb;$t=self::tabela(true);if(false===$wpdb->delete($t,array('fonte'=>$fonte))){throw new RuntimeException('Contribuição horária indisponível.');}
        foreach($horas as $r){if(false===$wpdb->insert($t,array('fonte'=>$fonte,'regra'=>$regra)+$r)){throw new RuntimeException('Persistência horária recusada.');}}
    }
    public static function publicar(string $dia,string $regra): void {
        global $wpdb;$t=self::tabela();$f=self::tabela(true);
        if(false===$wpdb->delete($t,array('dia'=>$dia))||false===$wpdb->query($wpdb->prepare('INSERT INTO %i (dia,hora_utc,agente,classe_caminho,status_grupo,contagem) SELECT dia,hora_utc,agente,classe_caminho,status_grupo,SUM(contagem) FROM %i WHERE dia=%s AND regra=%s GROUP BY dia,hora_utc,agente,classe_caminho,status_grupo',$t,$f,$dia,$regra))){throw new RuntimeException('Publicação horária recusada.');}
    }
    public static function limpar(): void {
        global $wpdb;$c=F3Base_Modulo_Acessos_Servidor::config();$days=min(90,max(1,(int)($c['retencao_horaria_dias']??30)),max(1,(int)$c['retencao_meses']*28));
        foreach(array(false,true) as $src){$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE hora_utc<%s',self::tabela($src),gmdate('Y-m-d H:00:00',time()-$days*DAY_IN_SECONDS)));}
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('agentes-relatorio','Agentes e buscadores: requisições, conteúdo e frequência',array(__CLASS__,'consultar'),self::schema());});
        add_action('admin_post_f3base_agentes_csv',array(__CLASS__,'csv'));
    }
    public static function schema(): array {return array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'visao'=>array('type'=>'string','enum'=>array('resumo','conteudo','frequencia','horas')),'agente'=>array('type'=>'string','maxLength'=>64),'caminho'=>array('type'=>'string','maxLength'=>191),'classe_caminho'=>array('type'=>'string','maxLength'=>16),'metodo'=>array('type'=>'string','enum'=>array('GET','HEAD','POST','outro')),'status'=>array('type'=>'integer','minimum'=>100,'maximum'=>599),'pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>1000));}
    public static function consultar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $valid=rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::schema()));if(is_wp_error($valid)){return array('ok'=>false,'codigo'=>'filtros_invalidos');}
        $de=$e['de']??wp_date('Y-m-d',time()-29*DAY_IN_SECONDS);$ate=$e['ate']??wp_date('Y-m-d');$view=$e['visao']??'resumo';
        if($de>$ate||(strtotime($ate)-strtotime($de))/DAY_IN_SECONDS>179){return array('ok'=>false,'codigo'=>'periodo_maximo_180_dias');}
        $cob=F3Base_Acessos_Coleta::cobertura($de,$ate);$days=array();foreach($cob as $d){$days[$d['dia']]=$d['estado'];}
        $out=array('ok'=>true,'visao'=>$view,'fuso_diario'=>wp_timezone_string(),'fuso_horario'=>'UTC','cobertura'=>$cob,'linhas'=>array(),'identidade'=>'declarada_no_user_agent','testes'=>'Logs não carregam a marca dos agentes da equipe; não há exclusão por inferência de IP/horário.','limites'=>'HTTP 2xx/304 é atendimento ou revalidação observada; não comprova camada de cache. Sem fonte não significa zero.');
        if(!F3Base_Modulo_Acessos_Servidor::tabela_pronta()){return $out+array('estado'=>'sem_estrutura');}
        if($view==='horas'&&(isset($e['caminho'])||isset($e['metodo'])||isset($e['status']))){return array('ok'=>false,'codigo'=>'filtro_incompativel_com_agregado_horario');}
        global $wpdb;$t=$wpdb->prefix.F3Base_Modulo_Acessos_Servidor::TABELA;$where=$wpdb->prepare('dia BETWEEN %s AND %s',$de,$ate);
        foreach(array('agente','caminho','classe_caminho','metodo','status') as $k){if(isset($e[$k])){$where.=$wpdb->prepare(" AND {$k}=%s",$e[$k]);}}
        $page=$e['pagina']??1;$offset=($page-1)*100;
        if($view==='horas'){$rows=$wpdb->get_results($wpdb->prepare("SELECT hora_utc,agente,classe_caminho,status_grupo,SUM(contagem) AS contagem FROM %i WHERE {$where} GROUP BY hora_utc,agente,classe_caminho,status_grupo ORDER BY hora_utc,agente,classe_caminho,status_grupo LIMIT 101 OFFSET %d",self::tabela(),$offset),ARRAY_A);}
        elseif($view==='frequencia'){
            $rows=$wpdb->get_results($wpdb->prepare("SELECT dia,agente,SUM(contagem) n,MIN(primeiro_em) primeiro,MAX(ultimo_em) ultimo,SUM(instantes_validos) validos FROM %i WHERE {$where} GROUP BY dia,agente ORDER BY agente,dia LIMIT 20001",$t),ARRAY_A);
            if(count($rows)>20000){return array('ok'=>false,'codigo'=>'reduza_periodo');}$map=array();
            foreach($rows as $r){$a=$r['agente'];$m=$map[$a]??array('agente'=>$a,'dias_ativos'=>0,'primeira_data'=>$r['dia'],'ultima_data'=>$r['dia'],'intervalos'=>array(),'segundos'=>0,'pares'=>0);$prev=$m['ultima_data'];if($m['dias_ativos']&&$prev!==$r['dia']){$complete=true;for($d=strtotime($prev);$d<=strtotime($r['dia']);$d+=DAY_IN_SECONDS){if(($days[gmdate('Y-m-d',$d)]??'')!=='completo'){$complete=false;break;}}if($complete){$m['intervalos'][]=(int)round((strtotime($r['dia'])-strtotime($prev))/DAY_IN_SECONDS);}}
                ++$m['dias_ativos'];$m['ultima_data']=$r['dia'];if((int)$r['validos']===(int)$r['n']&&(int)$r['n']>1&&$r['primeiro']&&$r['ultimo']){$m['segundos']+=strtotime($r['ultimo'].' UTC')-strtotime($r['primeiro'].' UTC');$m['pares']+=(int)$r['n']-1;}$map[$a]=$m;
            }$rows=array();foreach($map as $m){sort($m['intervalos']);$n=count($m['intervalos']);$m['mediana_entre_datas_dias']=$n?($m['intervalos'][(int)floor(($n-1)/2)]+$m['intervalos'][(int)floor($n/2)])/2:null;$m['pares_datas_cobertos']=$n;$m['intervalo_medio_intradia_segundos']=$m['pares']?round($m['segundos']/$m['pares'],2):null;unset($m['intervalos'],$m['segundos']);$rows[]=$m;}$rows=array_slice($rows,$offset,101);
        }else{$group=$view==='conteudo'?'agente,classe_caminho,caminho':'agente';$rows=$wpdb->get_results($wpdb->prepare("SELECT {$group},SUM(contagem) requisicoes,SUM(CASE WHEN status BETWEEN 200 AND 299 OR status=304 THEN contagem ELSE 0 END) atendidas,SUM(CASE WHEN status IN (403,429) THEN contagem ELSE 0 END) bloqueadas,MIN(primeiro_em) primeiro_em,MAX(ultimo_em) ultimo_em,SUM(instantes_validos) instantes_validos FROM %i WHERE {$where} GROUP BY {$group} ORDER BY requisicoes DESC,{$group} LIMIT 101 OFFSET %d",$t,$offset),ARRAY_A);foreach($rows as &$r){$r['bloqueadas_pct']=$r['requisicoes']?round(100*$r['bloqueadas']/$r['requisicoes'],2):null;$r['classe_agente']=F3Base_Modulo_Acessos_Servidor::classe_agente($r['agente']);}unset($r);}
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}$out['linhas']=array_slice($rows,0,100);foreach($out['linhas'] as &$line){$line['nome_agente']=self::nome($line['agente']);}unset($line);$out['hoje_temporario']=F3Base_Acessos_Atuais::fotografia();$out['proxima_pagina']=count($rows)>100?$page+1:null;$out['estado']=$rows?'observado':'sem_registros_no_recorte';return $out;
    }
    public static function nome(string $family): string {
        $names=array('gptbot'=>'OpenAI — GPTBot (treinamento)','oai-searchbot'=>'OpenAI — busca ChatGPT','chatgpt-user'=>'OpenAI — ChatGPT (requisição a pedido)','oai-adsbot'=>'OpenAI — verificação de anúncios','claudebot'=>'Anthropic — ClaudeBot (treinamento)','claude-searchbot'=>'Anthropic — busca Claude','claude-user'=>'Anthropic — Claude (requisição a pedido)','google-gemini-notebook'=>'Google — Gemini Notebook','google-notebooklm'=>'Google — NotebookLM (assinatura legada)','google-agent'=>'Google — infraestrutura de agentes','cloudvertexbot'=>'Google — Vertex AI');return $names[$family]??$family;
    }
    public static function render(): void {
        $e=array();foreach(array_keys(self::schema()) as $k){if(isset($_GET[$k])&&$_GET[$k]!==''){$e[$k]=in_array($k,array('status','pagina'),true)?(int)$_GET[$k]:sanitize_text_field(wp_unslash($_GET[$k]));}}
        echo '<h2>Agentes e buscadores</h2><form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="agentes"><label>Análise <select name="visao">';foreach(array('resumo'=>'Resumo','conteudo'=>'Conteúdo requisitado','frequencia'=>'Frequência entre datas','horas'=>'Distribuição horária (UTC)') as $k=>$v){echo '<option value="'.$k.'" '.selected($e['visao']??'resumo',$k,false).'>'.esc_html($v).'</option>';}echo '</select></label> ';
        foreach(array('de'=>'De','ate'=>'Até','agente'=>'Agente (família)','caminho'=>'Caminho exato','classe_caminho'=>'Classe de caminho','metodo'=>'Método HTTP','status'=>'Status HTTP') as $k=>$label){echo '<label>'.esc_html($label).' <input name="'.$k.'" type="'.(in_array($k,array('de','ate'),true)?'date':'text').'" value="'.esc_attr((string)($e[$k]??'')).'"></label> ';}echo '<button class="button">Consultar</button></form>';
        $r=self::consultar($e);if(empty($r['ok'])){echo '<p role="alert">'.esc_html($r['codigo']).'</p>';return;}
        echo '<p>OpenAI/ChatGPT, Anthropic/Claude e Google/Gemini são identificados por assinaturas declaradas. Isso não autentica o operador. Google-Agent e CloudVertexBot têm finalidades próprias.</p><p>'.esc_html($r['limites'].' '.$r['testes']).'</p>';
        F3Base_Relatorios::tabela($r['linhas']);if($r['proxima_pagina']){echo '<a class="button" href="'.esc_url(add_query_arg('pagina',$r['proxima_pagina'])).'">Próxima página</a>';}
        echo '<details><summary>Cobertura e significado dos intervalos</summary><p>Mediana entre datas usa somente pares cercados por cobertura completa. Não representa tempo exato entre requisições. Intervalo intradia exige todos os instantes válidos; não calcula média de médias. Datas antigas preservam seu calendário; instantes novos e horas são UTC.</p>';F3Base_Relatorios::tabela($r['cobertura']);echo '</details><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_agentes_csv">';wp_nonce_field('f3base-agentes-csv');foreach($e as $k=>$v){echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr((string)$v).'">';}echo '<button class="button">Exportar CSV filtrado</button></form>';
    }
    public static function csv(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-agentes-csv');$e=array();foreach(array_keys(self::schema()) as $k){if(isset($_POST[$k])&&$_POST[$k]!==''){$e[$k]=in_array($k,array('status','pagina'),true)?(int)$_POST[$k]:sanitize_text_field(wp_unslash($_POST[$k]));}}$e['pagina']=1;$all=array();do{$r=self::consultar($e);if(empty($r['ok'])||count($all)>20000){wp_die('Reduza o período ou corrija os filtros.',400);}$all=array_merge($all,$r['linhas']);$e['pagina']=$r['proxima_pagina'];}while($e['pagina']);nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="f3base-agentes.csv"');$f=fopen('php://output','w');if($all){fputcsv($f,array_keys($all[0]));foreach($all as $line){fputcsv($f,array_map(static fn($v)=>F3Base_Acessos_Relatorio::celula_csv($v===null?'Indisponível':$v),$line));}}fclose($f);exit;
    }
}
