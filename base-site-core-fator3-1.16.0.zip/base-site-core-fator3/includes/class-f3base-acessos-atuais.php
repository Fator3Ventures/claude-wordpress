<?php
/** Leitura incremental e temporária do dia atual; nenhuma linha entra no histórico. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Acessos_Atuais {
	public const CACHE             = 'f3base_acessos_fotografia';
	public const BYTES_POR_LEITURA = 8388608;
	public const MAX_BYTES_CACHE   = 8388608;
	/** Consulta da fotografia já armazenada; não abre logs nem renova seu prazo. */
	public static function fotografia(): array {
		// get_transient() expurga options vencidas; esta projeção é somente leitura.
		if ( function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache() ) {
			$e = wp_cache_get( self::CACHE, 'transient' );
		} else {
			$prazo = (int) get_option( '_transient_timeout_' . self::CACHE, 0 );
			$e     = $prazo > 0 && $prazo < time() ? false : get_option( '_transient_' . self::CACHE, false );
		}
		if ( ! is_array( $e ) || ( $e['dia'] ?? '' ) !== wp_date( 'Y-m-d' ) || ( $e['regra'] ?? '' ) !== F3Base_Modulo_Acessos_Servidor::config_hash() || empty( F3Base_Modulo_Acessos_Servidor::config()['ligado'] ) ) {
			return array(
				'dia'             => wp_date( 'Y-m-d' ),
				'linhas'          => array(),
				'erro'            => 'Hoje ainda não atualizado; clique Atualizar.',
				'atualizado'      => 0,
				'bytes_pendentes' => 0,
				'ignoradas'       => 0,
			); }
		return array(
			'dia'             => $e['dia'],
			'regra'           => $e['regra'],
			'fuso'            => wp_timezone_string(),
			'linhas'          => array_values( $e['agregados'] ),
			'erro'            => '',
			'atualizado'      => (int) $e['atualizado'],
			'bytes_pendentes' => (int) $e['bytes_pendentes'],
			'ignoradas'       => (int) $e['ignoradas'],
			'origem'          => 'arquivo_ativo',
			'cobertura'       => 'parcial',
		);
	}
	public static function ler(): array {
		$c     = F3Base_Modulo_Acessos_Servidor::config();
		$saida = array(
			'dia'             => wp_date( 'Y-m-d' ),
			'regra'           => F3Base_Modulo_Acessos_Servidor::config_hash(),
			'fuso'            => wp_timezone_string(),
			'atualizado'      => time(),
			'linhas'          => array(),
			'erro'            => '',
			'ignoradas'       => 0,
			'bytes_lidos'     => 0,
			'bytes_pendentes' => 0,
			'incremental'     => false,
		);
		if ( empty( $c['ligado'] ) ) {
			$saida['erro'] = 'Leitura de hoje desligada junto com a coleta de acessos.';
			return $saida; }
		$f    = null;
		$lock = null;
		try {
			$padrao             = F3Base_Modulo_Acessos_Servidor::resolver_padrao( $c['padrao_do_log'] );
			$pastas             = array();
			$pastas_encontradas = @glob( dirname( $padrao ), GLOB_ONLYDIR ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte.
			foreach ( $pastas_encontradas ? $pastas_encontradas : array() as $pasta ) {
				$real = @realpath( $pasta ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte.
				if ( false !== $real ) {
					$pastas[ $real ] = true; }
			}
			if ( count( $pastas ) !== 1 ) {
				throw new RuntimeException( 'O log atual exige um único diretório acessível deste site. Verifique o padrão de log.' ); }
			$arquivo = key( $pastas ) . '/access.log';
			if ( ! @is_file( $arquivo ) || ! @is_readable( $arquivo ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte.
				throw new RuntimeException( 'Log atual ausente ou sem leitura: ' . $arquivo ); }
			$lock = @fopen( get_temp_dir() . 'f3base-atual-' . hash( 'sha256', ABSPATH . $arquivo ) . '.lock', 'c' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte. Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
			if ( ! $lock || ! flock( $lock, LOCK_EX | LOCK_NB ) ) {
				throw new RuntimeException( 'Atualização em curso ou trava temporária indisponível. Atualize novamente.' ); }
			$f = @fopen( $arquivo, 'rb' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte. Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
			if ( ! $f ) {
				throw new RuntimeException( 'Não foi possível abrir o log atual.' ); }
			$stat = fstat( $f );
			if ( ! $stat ) {
				throw new RuntimeException( 'Não foi possível inspecionar o log atual.' ); }
			$chave  = hash( 'sha256', wp_json_encode( array( $arquivo, $c, $saida['regra'], $saida['dia'], wp_timezone_string(), F3BASE_PLUGIN_VERSAO ) ) );
			$e      = get_transient( self::CACHE );
			$valido = is_array( $e ) && ( $e['chave'] ?? '' ) === $chave && ( $e['ino'] ?? -1 ) === $stat['ino'] && ( $e['dev'] ?? -1 ) === $stat['dev'] && ( $e['offset'] ?? PHP_INT_MAX ) <= $stat['size'];
			if ( $valido ) {
				$valido = hash_equals( $e['assinatura'], self::assinatura( $f, $e['offset'] ) ); }
			if ( ! $valido ) {
				$e = array(
					'chave'     => $chave,
					'ino'       => $stat['ino'],
					'dev'       => $stat['dev'],
					'offset'    => 0,
					'agregados' => array(),
					'caminhos'  => array(),
					'n'         => 0,
					'ignoradas' => 0,
				); }
			F3Base_Modulo_Acessos_Servidor::preparar_caminhos();F3Base_Acessos_Repeticao::iniciar($e['repeticao_temporaria']??array());
            $saida['incremental'] = $valido;
			$inicio               = $e['offset'];
			fseek( $f, $inicio );
			$restam = min( self::BYTES_POR_LEITURA, $stat['size'] - $inicio );
			$limite = (int) ini_get( 'max_execution_time' );
			$prazo  = microtime( true ) + ( $limite > 0 ? max( 1, min( F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA, intdiv( $limite, 3 ) ) ) : F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA );
			$longa  = false;
			while ( $restam > 0 && microtime( true ) <= $prazo ) {
				$bruta = fgets( $f, min( 32769, $restam + 1 ) );
				if ( false === $bruta ) {
					throw new RuntimeException( 'Log atual truncado ou leitura interrompida. Atualize novamente.' ); }
				$restam               -= strlen( $bruta );
				$saida['bytes_lidos'] += strlen( $bruta );
				if ( ! str_ends_with( $bruta, "\n" ) ) {
					$longa = true;
					continue; }
				$e['offset'] = ftell( $f );
				++$e['n'];
				if ( $longa ) {
					++$e['ignoradas'];
					$longa = false;
					continue; }
				$data = false;
				if ( preg_match( '~^\S+ \S+ \S+ \[([^\]]+)\] ~', $bruta, $m ) ) {
					$data = DateTimeImmutable::createFromFormat( '!d/M/Y:H:i:s O', $m[1] ); }
				$falhas = DateTimeImmutable::getLastErrors();
				if ( false === $data || ( $falhas && ( $falhas['warning_count'] || $falhas['error_count'] ) ) ) {
					++$e['ignoradas'];
					continue; }
				if ( $data->setTimezone( wp_timezone() )->format( 'Y-m-d' ) !== $saida['dia'] ) {
					continue; }
				$r = F3Base_Modulo_Acessos_Servidor::linha( $bruta, $c['caminhos_excluidos'] );
				if ( null === $r ) {
					++$e['ignoradas'];
					continue; }
				$r=F3Base_Acessos_Repeticao::observar($bruta,$r,$data->getTimestamp());
                $a = $r['agente'];
				$p = $r['caminho'];
				if ( '' !== $p ) {
					if ( ! isset( $e['caminhos'][ $a ][ $p ] ) && count( $e['caminhos'][ $a ] ?? array() ) >= F3Base_Modulo_Acessos_Servidor::TETO_CAMINHOS_POR_DIA ) {
						$r['caminho']        = '';
						$r['classe_caminho'] = 'outro'; } else {
						$e['caminhos'][ $a ][ $p ] = true; }
				}
				$k = wp_json_encode( array_slice( $r, 0, 5 ) );
				if ( isset( $e['agregados'][ $k ] ) ) {
					++$e['agregados'][ $k ]['contagem'];$stamp=$data->getTimestamp();$utc=gmdate('Y-m-d H:i:s',$stamp);$old=$e['agregados'][$k];$e['agregados'][$k]['primeiro_em']=isset($old['primeiro_em'])?min($old['primeiro_em'],$utc):$utc;$e['agregados'][$k]['ultimo_em']=isset($old['ultimo_em'])?max($old['ultimo_em'],$utc):$utc;$e['agregados'][$k]['instantes_validos']=(int)($old['instantes_validos']??0)+1;
				} else {
					$r['primeiro_em']=gmdate('Y-m-d H:i:s',$data->getTimestamp());$r['ultimo_em']=$r['primeiro_em'];$r['instantes_validos']=1;$e['agregados'][ $k ] = $r; }
				if ( count( $e['agregados'] ) > F3Base_Modulo_Acessos_Servidor::TETO_AGREGADOS ) {
					throw new RuntimeException( 'Teto de agregados do log atual excedido. Use coleta externa para este volume.' ); }
			}
			if ( $e['offset'] === $inicio && $saida['bytes_lidos'] >= self::BYTES_POR_LEITURA ) {
				throw new RuntimeException( 'Linha incompleta excedeu o orçamento de leitura do log atual.' ); }
			clearstatcache( true, $arquivo );
			$agora = @stat( $arquivo ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte.
			if ( ! $agora || $agora['ino'] !== $stat['ino'] || $agora['dev'] !== $stat['dev'] || $agora['size'] < $stat['size'] || wp_date( 'Y-m-d' ) !== $saida['dia'] ) {
				delete_transient( self::CACHE );
				throw new RuntimeException( 'Log atual rotacionado, truncado ou dia alterado durante a leitura. Atualize novamente.' ); }
			if ( $e['ignoradas'] > $e['n'] / 2 ) {
				throw new RuntimeException( 'Formato do log atual não reconhecido na maioria das linhas.' ); }
			$e['repeticao_temporaria']=F3Base_Acessos_Repeticao::exportar();F3Base_Acessos_Repeticao::concluir();
            $e['assinatura']      = self::assinatura( $f, $e['offset'] );
			$e['dia']             = $saida['dia'];
			$e['regra']           = F3Base_Modulo_Acessos_Servidor::config_hash();
			$e['atualizado']      = time();
			$e['bytes_pendentes'] = max( 0, $stat['size'] - $e['offset'] );
			if ( strlen( serialize( $e ) ) <= self::MAX_BYTES_CACHE ) { // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- Apenas mede bytes do array interno; não recebe objetos nem executa unserialize.
				set_transient( self::CACHE, $e, DAY_IN_SECONDS ); } else {
				delete_transient( self::CACHE );
				throw new RuntimeException( 'Fotografia temporária excedeu o limite de memória; use coleta externa para este volume.' ); }
				$saida['linhas']          = array_values( $e['agregados'] );
				$saida['ignoradas']       = $e['ignoradas'];
				$saida['bytes_pendentes'] = max( 0, $stat['size'] - $e['offset'] );
		} catch ( Throwable $erro ) {
			$saida['erro'] = $erro->getMessage(); } finally {
			if ( is_resource( $f ) ) {
				fclose( $f ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
			} if ( is_resource( $lock ) ) {
				flock( $lock, LOCK_UN );
				fclose( $lock ); } // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
			}
			return $saida;
	}
	/** Confere começo e fronteira já lida; identifica rotação por cópia e truncamento. */
	private static function assinatura( $f, int $offset ): string {
		fseek( $f, 0 );
		$primeiro = $offset > 0 ? fread( $f, min( 256, $offset ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
		fseek( $f, max( 0, $offset - 256 ) );
		$ultimo = $offset > 0 ? fread( $f, min( 256, $offset ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
		return hash( 'sha256', $primeiro . '|' . $ultimo );
	}
}
