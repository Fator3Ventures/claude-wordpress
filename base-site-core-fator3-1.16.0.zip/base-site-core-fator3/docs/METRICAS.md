# Métricas — contrato 1.0.0 / plugin 1.16.0

Os IDs abaixo são os nomes de saída da ability `f3base/relatorios-consultar`. Não some quadros como se fossem fontes independentes. A regra desta edição é `core-1.16.0`; reproduzir o painel exige mesmos filtros, fuso, período, classe, deduplicação e cobertura.

## Elegibilidade comum

Lixeira e eliminação pendente ficam fora. Segmento padrão: `sem_testes`; `somente_testes` e `todos` são explícitos. `nao_marcado` não garante visitante humano. Suspeitos (`captura=suspeito`) e spam (`atendimento=spam`) ficam em categorias separadas; suspeito tem precedência se ambas existirem. Envios elegíveis exigem captura aceita, sem spam e método `formulario`, `whatsapp_formulario` ou `conteudo`. Cliques usam `whatsapp_cta`/`contato_cta`, depois das exclusões anteriores. Método desconhecido não vira envio por ter nome/e-mail.

Datas são locais do WordPress, convertidas em limites UTC: início inclusivo e fim exclusivo. Dia em andamento é parcial. Não há janela de conversão posterior ao fim do relatório. Formulário/método filtram contatos; não alteram o denominador de tráfego da página. Filtros publicitários selecionam leads e análise com a mesma atribuição; comportamento só participa dessa coorte se houver análise pareada por classe/sessão/página e período.

| ID / quadro | Definição e fontes | Unidade e ausência |
|---|---|---|
| `registros` / totais | Quantidade de linhas elegíveis ao recorte, inclusive categorias suspeito/spam/outros. | registros; não pessoas |
| `envios` / totais; `envios_aceitos` / páginas | Contagem de envios elegíveis em leads. Múltiplos envios da sessão contam individualmente. | envios |
| `cliques` / totais; `cliques_registrados` / páginas | Contagem de intenções elegíveis nos métodos CTA. | cliques; não conversas |
| `sessoes_observadas` | União de classe + sessão com página vista em eventos ou análise. Nas páginas, inclui também o caminho. As duas fontes não se somam. | sessões observadas; não visitantes únicos |
| `sessoes_com_envio` | Sessões com página vista na mesma página, anterior ou igual ao recebimento de ao menos um envio elegível. | sessões deduplicadas |
| `taxa_envio_pct` | 100 × sessões com envio / sessões observadas na dimensão. | percentual; NULL sem denominador |
| `taxa_envio_site_pct` | União de sessões convertidas nas páginas / união de sessões observadas do site × 100. | não somar sessões entre páginas |
| `sessoes_com_clique`, `taxa_clique_pct` | Mesma regra temporal de página vista, para intenções CTA. | sessão e percentual; NULL sem denominador |
| `pareamento_pct` / cobertura | 100 × contatos elegíveis com página vista anterior / contatos elegíveis (envios + cliques). | percentual; mede cobertura, não conversão |
| `envios_atribuidos`, `cliques_atribuidos` / campanhas | Volumes com o snapshot publicitário do lead, mesmo sem sessão. Chave: plataforma, conta, campanha, grupo e anúncio; sem IDs, rótulos delimitam a origem. | registros; ausência de IDs permanece explícita |
| `envios_pareados`, `cliques_pareados` / campanhas | Registro cujo `dados.navegacao` encontra análise de página na mesma classe/sessão antes do recebimento. | subconjunto pareado; não somar aos atribuídos |
| `instancias_vistas`, `inicios`, `tentativas`, `instancias_com_erro` / formulários | Instâncias deduplicadas por classe/sessão/correlação e agrupadas por ID/revisão do formulário. Cada tipo é uma etapa, não outro lead. | instâncias; captura depende de medição |
| `envios_aceitos`, `inicios_com_envio` / formulários | Volume de aceite e interseção dos inícios com aceites observados na instância. | volume e instâncias são unidades diferentes |
| `taxa_inicio_envio_pct` | 100 × inícios com aceite / inícios observados no recorte. | NULL sem início observado |
| `abandono_observado_30min` | Início sem aceite no período e pelo menos 30 min desde o último evento da instância, limitados ao fim do recorte. | não comprova abandono definitivo |
| `sessoes_expostas`, `sessoes_com_envio_apos`, `taxa_associada_pct` / blocos | Sessões com seção vista; subconjunto com envio na página em horário posterior; razão × 100. | associação temporal, não causalidade |
| `tempo_ativo_estimado_ms` / blocos | Soma de valores de tempo ativo da seção. | ms estimados; não tempo de atenção comprovado |
| `p75` / qualidade | Ordenar amostras vinculadas de análise e escolher posição ceil(0,75 × N). Cada ID vital conserva a maior sequência válida. | ms para LCP/INP/FCP/TTFB; CLS sem unidade |
| `p75_sessoes_com_envio`, `p75_sem_envio_observado` | Recalcular p75 sobre amostras de cada grupo de sessão/página. | NULL no grupo sem amostra; não média dos p75 |
| `sessoes_com_erro`, `sessoes_com_friccao` / páginas | Interseção de sessões vistas com eventos correspondentes. | sessão; erro não é prova de perda de lead |
| `taxa_envio_com_erro_pct`, `taxa_envio_sem_erro_pct` | Taxa recalculada com numerador e denominador de cada grupo. | não comparar causalmente sem análise adicional |
| `novos`, `respondidos`, pendências de aviso/resposta / operação | Estado atual dos contatos criados no período. Pode mudar após o fim do período. | estoque da coorte; não histórico de estados |
| `maior_idade_novo_horas` | Maior tempo desde recebimento entre contatos novos dessa coorte. | horas até a consulta |
| `p75_ate_primeira_marcacao_horas` | Primeira marcação `respondido` por record_id, menos recebimento; recalcular p75 dessas durações. | ação manual, não comprova e-mail entregue |
| `concessoes`, `concessoes_utilizadas`, `taxa_uso_pct` / materiais | Pré-agregação das concessões ligadas aos leads filtrados; usada significa `usados>0`. | acesso autorizado, não leitura concluída |
| `envios` / demanda | Contagem por opção fechada na definição capturada/revisão compatível. Campos pessoais e texto livre são excluídos. | checkbox pode participar de várias opções; não somar como leads únicos |
| `Aguardando resposta agora` / cartão geral | Contatos aceitos, novos, sem lixeira/eliminação e no segmento, de todos os períodos. | estoque atual explicitamente separado do período |

## Limites e comparações

Leitura integrada: até 3.000 leads e 30.000 eventos por fonte depois dos filtros SQL. Excesso retorna `reduza_periodo`, sem publicar taxas parciais. Interface/ability paginam até 200 linhas. CSV integrado usa todas as linhas desse mesmo conjunto limitado. Eventos de jornada são limitados aos 500 anteriores ao recebimento; corte é declarado.

Retenção, consentimento, armazenamento bloqueado, ausência de sessão e coleta iniciada durante o intervalo alteram cobertura. Campo ausente não vale zero. Taxas precisam dos insumos; não tire média simples de percentuais ou percentis. Comparação usa período anterior de igual duração, com as mesmas regras, e não atribui causa à variação. O quadro de logs conta requisições técnicas e não aplica o segmento de cookie aos logs que não registram essa marca.

A API retorna versão, período/fuso, filtros, totais, cobertura, limites/erros e retenção. Relatórios próprios devem acrescentar horário da extração, regra aplicada e fontes externas. Custos, vendas, receita e leads nativos não estão disponíveis por sincronização nesta release.
