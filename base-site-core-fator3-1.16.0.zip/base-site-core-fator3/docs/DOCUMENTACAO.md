# Documentação instalada — Core 1.16.0

Este acervo acompanha o instalador em `wp-content/plugins/base-site-core-fator3/docs/`. O agente pode ler arquivos ou usar `f3base/documentacao-ler` autenticado: sem argumentos retorna o índice; `arquivo`, `linha` e `limite` paginam até 200 linhas e retornam SHA-256 e próxima linha. O schema instalado é a fonte dos parâmetros aceitos. A proteção HTTP distribuída exige Apache/AllowOverride compatível; Nginx precisa de regra equivalente da hospedagem.

| Arquivo | Uso |
|---|---|
| README.md | Instalação nova ou 1.15 → 1.16, recursos e limites |
| INSTRUCOES-DO-PLUGIN.md | Roteiro de agente, marca de teste e operações |
| CONFIGURACAO.md | Sub-abas, herança, menu, permissões e defaults |
| AJUDA-OPCOES.md | Ajuda por opção/campo: funcionamento, escolha, vantagens, limitações e exemplo |
| dados/ajuda-opcoes.json | Mesma ajuda e schemas em formato estruturado |
| CONTRACTS.md | Contratos e semântica de erros/retentativas |
| REFERENCIA-CATALOGO.md | Declarações de opções, módulos e abilities |
| AGENTES-1.16.md | Exemplos de operação, perfil e verificação |
| AGENTES-E-BUSCADORES.md | Famílias, frequência, horas e cobertura dos logs |
| LEADS-E-FORMULARIOS.md | Captura, e-mail, papéis, anexos e telas |
| PIPEDRIVE.md | Configuração, dados enviados, fila, reenvio e eliminação |
| ORIGENS-ANUNCIOS.md | Meta, Google, reconciliação, LinkedIn e OpenAI |
| CRUZAMENTOS-PUBLICIDADE.md | Atribuição web e cruzamento com contas de anúncios |
| DICIONARIO-DADOS.md | Relações e significado dos dados |
| dados/contrato.json | Colunas, índices e contrato de dados 4.0.0 |
| CONSULTAS-EXEMPLO.sql | SELECTs para análises, sem escrita direta |
| RELATORIOS.md / METRICAS.md | Telas, filtros, fórmulas e limites |
| OFERTAS.md | Ofertas, prova de preço/período e emissão |
| OPERACAO-E-RECUPERACAO.md | Cron, cache, LLMS, servidor e recuperação na 1.16 |
| perfis/piso-padrao-3.2.json | Perfil atual, revisão 2026-09-29-core-1.16.0, somente leitura |
| VALIDACAO.md | Evidências locais, CRM-A01…A15 e pendências externas |
| CHANGELOG.md | Histórico das versões |

O contrato de configuração tem conteúdo **4.0.0**; o nome da ability `config-core-contrato-v1` permanece por ser o identificador do serviço. Consulte a versão do conteúdo. Não use documentos antigos para preencher valores ou contornar recusas. Documentos e diagnósticos não contêm credenciais. Dados de contatos exigem capability própria; não publique exportações de leads, mensagens ou caminhos privados.
