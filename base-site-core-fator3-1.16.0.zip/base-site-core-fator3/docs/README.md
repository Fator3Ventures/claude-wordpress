# Base Site Core Fator3 1.16.0

**Pacote: revisão 2, 29/09/2026.** Substitui o ZIP inicial da 1.16.0; confira os hashes da entrega.

Instale `base-site-core-fator3-1.16.0.zip` pelo WordPress. O ZIP de fontes/testes é material de desenvolvimento, não é instalável. Os únicos caminhos admitidos são instalação nova e atualização de uma 1.15.0 concluída. Não há suporte ou procedimento de retorno a versões anteriores. Preserve backup e contatos novos; recuperação é dirigida na própria 1.16.

A versão acrescenta referência explícita a menu clássico ou bloco de navegação, ajuda por campo e seção correta ao salvar, área Agentes e buscadores, correção do assunto de e-mail, inventário limitado de CTAs, correções de atribuição, cache, ofertas, consentimento, autoria e LLMS. Integra contatos com Pipedrive por fila e oferece recepção Google Ads e consulta de formulários Meta. Atribuição OpenAI Ads usa sinais web como oppref; não é importação nativa de formulário.

**Integrações externas vêm desligadas.** Configure em Contatos → Integrações. A captura local não espera o CRM. A entrega depende de acesso, mapeamento verificado e executor de tarefas funcionando. Homologação real Pipedrive/Meta/Google permanece pendente nesta entrega: VALIDACAO.md distingue os ensaios locais da aceitação nas contas.

Configurações preservadas: false, zero, strings e listas vazias explícitas não são substituídos por defaults. Em instalação nova, destinatários internos usam o endereço de administração quando a chave está ausente; índice usa Arquivo gerado; a gestão da política vem habilitada no modo Todas; a raiz privada é preparada. Não há exclusão automática do acervo por atualização/desinstalação.

Tema e implantador estão fora do escopo. Selecionar menu não altera o tema. Não houve implantação em nenhum site nesta entrega. Consulte DOCUMENTACAO.md para operação autenticada, dados e limites.
