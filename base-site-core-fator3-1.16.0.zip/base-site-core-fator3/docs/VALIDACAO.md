# Validação — Core 1.16.0

Data: 29/09/2026. Revisão 2 do pacote. **Pacote validado em bancada local; homologação das contas externas pendente.** Sem implantação no Site-Teste ou na frota nesta entrega. Não houve acesso/teste a korvena.net.br. Caminhos admitidos: instalação nova e atualização da 1.15.0 concluída; nenhum downgrade.

## Ambiente e evidências

WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, WP Super Cache 3.1.3, servidor PHP local com oito workers, Chrome 151.0.7922.34, Lighthouse 13.5.0. Dados sintéticos; e-mails bloqueados. CRM/CAPI/Meta usam transporte interceptado. Os resultados finais e harnesses ficam em suite/versao-1160/evidencias no ZIP de fontes. Números abaixo são asserções, não casos independentes nem homologações remotas.

| Conjunto | Verificações aprovadas | Evidência |
|---|---:|---|
| Contratos, navegação, captura, segredos e ingestão | 74 | core.json |
| CRM com API simulada | 26 | crm.json |
| Regressão CAPI | 10 | capi.json |
| Bordas de contrato/relatórios | 17 | bordas.json |
| Publicação LLMS | 23 | llms.json |
| Ofertas, atribuição, agentes e reconciliação Google | 37 | novas.json |
| Meta: paginação, retomada e duplicidade | 14 | origens.json |
| HTTP local / formulário sem JS / cache PHP | 23 | http.json |
| Redirects e evidências | 21 | redirects-bordas.json |
| Consentimento: temas/contraste | 104 | consentimento.json |
| Consentimento: transparência, alfa, oklch e tema | 50 | consentimento-tema.json |
| Transporte de análise | 22 | transporte.json |
| Regressão específica da retentativa após 503 | 1 | transporte-retentativa.json |
| Telas administrativas | 22 | admin.json |
| Análise com 12 processos concorrentes | 9 | concorrencia.json |
| Documentação, inventário CTA e perfil | 14 | fechamento.json |
| Troca concorrente de credenciais e validação de catálogo | 9 | credenciais.json |
| CTA sem WhatsApp: navegador, endpoint e banco | 11 | cta-sem-whatsapp.json |

Instalação/atualização: dez etapas aprovadas, cinco em cada origem (instalar, semear, atualizar, repetir, retomar), incluindo preservação de valores explícitos. Sintaxe: 123 arquivos PHP e 21 JS; sete assets recompostos com Terser fixado, conferidos contra o manifesto.

O teste HTTP observou arquivo de cache PHP e corpo vazio no acesso direto, além de HIT e confirmação 303 sem JS com cabeçalhos/noindex. Isso não é prova de configuração Apache/Nginx de qualquer hospedagem. O ensaio de doze processos verifica deduplicação/maior sequência e falhas reais de banco induzidas com triggers, incluindo 503 e ACK parcial. Não demonstra a causa histórica dos cinco erros reportados nos sites.

Correções encontradas durante a implementação: retentativa podia ficar sem agendamento após um temporizador antecipado; registro do submenu Integrações antes de Contatos causava 403. Ambas foram corrigidas e reexecutadas. Fixtures foram isoladas para não somar contribuições de logs de execuções anteriores, e o timestamp concorrente foi fixado para representar a mesma identidade/payload. Esses ajustes não alteram o contrato de produção. `pageshow.persisted` é um evento controlado, sem provar elegibilidade real para bfcache.

## Revisão 2 — fechamento local

Corrigidas lacunas adicionais: CTAs sem WhatsApp agora carregam a captura mesmo sem formulário; Pipedrive e Meta invalidam a verificação após alteração de credencial/configuração; lotes não misturam credenciais e respostas superadas não certificam o novo estado; campos esperados do lead são registrados antes do POST e conferidos mesmo após resposta perdida; IDs de alternativas são recusados quando o catálogo não os confirma.

Reexecutados core, CRM, credenciais, origens, fechamento e navegação real do CTA. O teste do CTA confere resposta HTTP 201, destino preservado e a linha no banco pela correlação, incluindo método e post_id. Instalação nova/1.15 reexecutada no pacote revisado. Demais evidências conservadas para fluxos sem alterações; a matriz de desempenho abaixo precede a revisão 2 e não mede seu novo caminho de CTA sem WhatsApp. Sem contatos remotos, e-mails ou alterações nos sites.

## Desempenho com presets padrão

Seis rodadas, três mobile/três desktop. pauseAfterLoad, pauseAfterFcp, networkQuiet e cpuQuiet de 1000 ms, sem ampliar artificialmente a coleta. Configuração resolvida, trace e DevTools completos acompanham cada medição. HTML real de HIT WP Super Cache foi reproduzido no servidor de teste; gtag oficial foi servido localmente e coletores externos não foram usados. Não mede latência do Google nem equivale ao PageSpeed de produção.

| Rodada | Perfil | Nota | LCP ms | TBT ms | Primeiro POST de análise desde a navegação |
|---|---|---:|---:|---:|---|
| 1 | mobile | 83 | 4732 | 13.0 | não observado na janela |
| 1 | desktop | 99 | 887 | 0.0 | 5127 ms |
| 2 | mobile | 84 | 4464 | 55.5 | 5135 ms |
| 2 | desktop | 99 | 1038 | 0.0 | 5198 ms |
| 3 | mobile | 98 | 2411 | 51.5 | 5150 ms |
| 3 | desktop | 99 | 917 | 0.0 | 5091 ms |

O POST apareceu em cinco das seis janelas, com respostas 200 e eventos confirmados. Adiar cinco segundos após load **não garante ficar fora do trace** e não demonstrou ganho causal de nota. Mantido o prazo com saídas antecipadas e recuperação de erro; nenhum ajuste de tema/gtag foi incluído. A matriz mede o fluxo normal anterior à correção de retentativa (exercitada separadamente) e à retirada de funções sem consumidores; não afirma benchmark byte a byte do ZIP final.

## Homologação Pipedrive — CRM-A01…CRM-A15

Todos os casos abaixo estão **pendentes no destino real**. Ambiente externo: não disponibilizado; conta: não verificada; horário/evidência remota: não existem nesta execução; versão alvo: 1.16.0; limpeza remota: não aplicável, nenhum objeto externo criado. Os mocks aprovados acima não substituem essas linhas. Preparar sandbox/developer com IDs próprios, executar contratos e, depois, entrega sintética limitada na conta comercial autorizada. Guardar horário UTC, IDs/evidências e limpeza de cada caso.

| Caso | Aceite remoto pendente |
|---|---|
| CRM-A01 | Campanha Instagram, unidade/canal/parceiro/ponto, nota e atividade; conferência dos campos na releitura. |
| CRM-A02 | Retorno no dia seguinte sem nova UTM mantém a origem conforme a janela/modelo. |
| CRM-A03 | Sem UTM: mapa de fallback explícito, sem inventar atribuição. |
| CRM-A04 | Parceiro/campanha desconhecido: valor vazio e qualidade visível, sem inferência. |
| CRM-A05 | Segundo envio da mesma pessoa com oportunidade aberta: reutiliza e acrescenta nota. |
| CRM-A06 | Pessoa/empresa preexistentes: não duplicar nem sobrescrever. |
| CRM-A07 | Token inválido e recadastro: pausa/reenvio controlado sem duplicidade. |
| CRM-A08 | Falha 503 induzida em sandbox: retentativa e recuperação. |
| CRM-A09 | Resposta perdida entre pessoa e lead: conciliar antes de repetir criação. |
| CRM-A10 | Medição recusada/revogada: atribuição não observada; não afirmar orgânico. |
| CRM-A11 | Lead sintético Meta com marca de teste e campos comerciais/nativos confirmados. |
| CRM-A12 | Google Send test, duplicata e CRM em modo explícito de homologação. |
| CRM-A13 | Chave Google errada: 403 e nenhuma captura. |
| CRM-A14 | Eliminação: objeto sintético exclusivo apagado; compartilhado preservado com pendência. |
| CRM-A15 | Limites/429/reset real da conta observados; pausa sem perda nem cota inventada. |

Também pendem: seleção múltipla com dois IDs em lead v1 e releitura, campos/permissões da conta real, webhook Google público usando a ferramenta do provedor, equivalência de ID Google API/webhook, executor da reconciliação, permissões/ativos Meta e identificação efetiva dos testes Meta, corrida entre instalações independentes, latência de loopback/cron real e ensaio com o Yoast ativo na versão da frota. A reserva de robots usa cópia/hash/remoção condicionais no código; a restauração e proteção HTTP devem ser comprovadas no sistema de arquivos/hospedagem real. Não declarar esses aceites externos encerrados.

## Pendências e exclusões do escopo

- Backlog 50: nova soma sobre logs reais ainda disponíveis; sem log não há reconstrução legítima.
- Backlog 52: observar sete dias sem a falha de persistência; a bancada não substitui esse período.
- LinkedIn nativo: aprovação/acesso da API e homologação. OpenAI nativo: contrato oficial, acesso e homologação. Atribuição web dos dois está disponível nos limites documentados.
- Webhook genérico de saída e confirmação por URL de formulário seguem adiados. Custos, receita/ROI, identificação autenticada de robôs e automação de bloqueios estão fora.
- Implantador, tema, compensações locais e hospedagem não foram alterados. A mudança do WhatsApp flutuante direto para formulário continua decisão do dono.

Integrações vêm desligadas. A falta de acesso externo não impede instalar as correções locais, mas impede declarar a integração homologada para ativação comercial. Consulte PIPEDRIVE.md e ORIGENS-ANUNCIOS.md para os próximos passos concretos.
