# Agentes e buscadores — 1.16.0

Medição → Agentes e buscadores reúne resumo, conteúdo requisitado, frequência entre datas e horas UTC. A coleta vem de logs do servidor, separada dos eventos JavaScript. Filtros de período, família, caminho, classe de caminho, método e status valem também para o CSV e `f3base/agentes-relatorio`. Consultas têm paginação; exportação tem teto e pede período menor quando excedido.

| Família | Nome e limite |
|---|---|
| gptbot | OpenAI — GPTBot, treinamento |
| oai-searchbot | OpenAI — busca ChatGPT |
| chatgpt-user | OpenAI — requisição a pedido no ChatGPT |
| oai-adsbot | OpenAI — verificação de anúncios; não é clique pago |
| claudebot / claude-searchbot / claude-user | Anthropic — treinamento, busca e requisição a pedido do Claude |
| google-gemini-notebook | Google — Gemini Notebook |
| google-notebooklm | Google — assinatura legada NotebookLM |
| google-agent / cloudvertexbot | Infraestrutura de agentes Google / Vertex AI; não afirmar que toda requisição veio do Gemini |

A assinatura é declarada por User-Agent, não autentica o operador. Google-Extended é controle de uso de conteúdo, não uma família HTTP a inventar. Assinaturas desconhecidas permanecem outras/desconhecidas. Não guardar IP, User-Agent bruto, query ou referer para esse relatório.

**Requisições** são soma de contagens, não visitantes únicos. **Atendidas**: 2xx e 304. **Bloqueadas**: 403 e 429. Outros códigos permanecem separados; 404 não prova bloqueio. Primeiro/último instante representam observações válidas, não o tempo em que o agente leu o conteúdo.

A frequência entre datas calcula mediana de intervalos somente entre datas ativas cercadas por cobertura completa. Ausência de arquivo ou importação parcial não vira dia com zero. O intervalo intradia usa a soma das amplitudes primeiro–último dividida pelos pares de requisições, apenas quando todos os instantes são válidos; não é média de médias, nem lista exata de intervalos. A hora é UTC; o calendário diário histórico conserva a regra original.

Agregados horários e instantes começaram na 1.16. Histórico sem granularidade retorna indisponível; não é preenchido por inferência. Reimportar a mesma contribuição substitui sua soma em vez de duplicar. Retenção segue a coleta de acessos; “hoje” é fotografia temporária distinta do arquivo fechado. Logs sem marca de cookie/cabeçalho não permitem excluir retroativamente os testes dos agentes.
