# Fator3 Site Core 1.89.0

Versão 1.89.0. Catálogo ampliado e ficha comercial na consulta de sessão. Consulte docs/RELEASE-1.89.0.md.

Instalação nova ou atualização da 1.88.1. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.41.0.

Índice de operação em docs/DOCUMENTACAO.md.
