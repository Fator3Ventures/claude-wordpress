<?php
/**
 * Meta 0.7.0 — Melhorias M1–M5 (ordem do dono de 22/10/2026). Standalone native test in a real WordPress lab.
 * The defects proven here also run against the 0.6.0 base through tests/native/defects.php.
 */
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
require_once __DIR__.'/lab-helpers.php';
use Fator3\Meta as M;
wp_set_current_user(1);
$checks=[];$http=0;$mail=[];
function v070(string $name,bool $ok,string $why=''){global $checks;$checks[]=['name'=>$name,'passed'=>$ok]+($ok||$why===''?[]:['reason'=>$why]);echo json_encode(end($checks),JSON_UNESCAPED_UNICODE)."\n";}
add_filter('pre_http_request',function($pre,$args,$url)use(&$http){$http++;$id=basename((string)parse_url($url,PHP_URL_PATH));return ['headers'=>[],'body'=>wp_json_encode(['id'=>$id,'name'=>'QA 070 synthetic','username'=>'qa070','followers_count'=>1]),'response'=>['code'=>200,'message'=>'fixture'],'cookies'=>[]];},1,3);
add_filter('pre_wp_mail',function($pre,$atts)use(&$mail){$mail[]=$atts;return true;},1,2);
global $wpdb;$t=M\Store::table();
try{
 M\Connections::save(['connection_id'=>'qa070','expected_revision'=>0,'token'=>'qa070-synthetic-not-a-token','assets'=>['instagram'=>['888070']],'users'=>[1]]);
 $q=['connection_id'=>'qa070','channel'=>'instagram','account_id'=>'888070','report'=>'profile'];
 M\Schedules::save(['schedule_id'=>'qa070_hourly','label'=>'QA 070 horária','query'=>$q,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()-7201]);

 // M1 — read-only health
 wp_clear_scheduled_hook('f3_meta_worker');$writes=[];$spy=static function($sql)use(&$writes){if(preg_match('/^\s*(INSERT|UPDATE|DELETE|REPLACE)/i',$sql))$writes[]=$sql;return $sql;};
 $httpBefore=$http;$mailBefore=count($mail);add_filter('query',$spy);try{$h=M\Worker::observe();}finally{remove_filter('query',$spy);}
 v070('M1 health reports worker_missing and overdue schedule',$h['state']==='degraded'&&in_array('worker_missing',array_column($h['issues'],'code'),true)&&in_array('schedule_overdue',array_column($h['issues'],'code'),true));
 v070('M1 health does not repair, write, mail or call Meta',wp_next_scheduled('f3_meta_worker')===false&&$writes===[]&&$http===$httpBefore&&count($mail)===$mailBefore&&$h['repair']==='not_attempted',wp_json_encode($writes));
 $r=M\Api::dispatch('health');v070('M1 meta/health dispatch succeeds for administrator',$r['success']&&$r['data']['state']==='degraded'&&wp_next_scheduled('f3_meta_worker')===false);
 // Published paths (REST and ability): the only writes are the local audit row and the audit health option.
 $httpBefore=$http;$mailBefore=count($mail);
 [$rest,$wRest]=lab_writes(static function(){$q=new WP_REST_Request('POST','/f3-meta/v1/health');$q->set_header('Content-Type','application/json');$q->set_body('{}');return rest_do_request($q);});
 v070('M1 REST meta/health writes only one audit row (no repair, schedule, mail or HTTP)',$rest->get_status()===200&&lab_audit_inserts($wRest,$t)===1&&lab_non_audit_writes($wRest,$t,'f3_meta')===[]&&wp_next_scheduled('f3_meta_worker')===false&&$http===$httpBefore&&count($mail)===$mailBefore,wp_json_encode(lab_non_audit_writes($wRest,$t,'f3_meta')));
 // With the Fator3 MCP active, native ability calls follow its integration profile and are logged in its own Registro; the MCP path is covered by the read-profile check below.
 if(function_exists('wp_get_ability')&&!class_exists('Fator3\\McpFiles\\ConnectionContext')){[$ab,$wAb]=lab_writes(static fn()=>wp_get_ability('meta/health')->execute([]));
  v070('M1 ability meta/health writes only one audit row (no repair, schedule, mail or HTTP)',is_array($ab)&&$ab['success']&&lab_audit_inserts($wAb,$t)===1&&lab_non_audit_writes($wAb,$t,'f3_meta')===[]&&wp_next_scheduled('f3_meta_worker')===false&&$http===$httpBefore&&count($mail)===$mailBefore,wp_json_encode(lab_non_audit_writes($wAb,$t,'f3_meta')));}
 $au=M\Api::dispatch('audit',[]);v070('M1 the meta/health call is visible in the local audit',$au['success']&&in_array('health',array_column($au['data']['events'],'operation'),true));
 $abilities070=function_exists('wp_get_ability');$a=$abilities070?wp_get_ability('meta/health'):null;$m=$a?$a->get_meta():[];
 if($abilities070)v070('M1 meta/health is advertised read-only with no local or remote effect',$a&&$m['annotations']['readonly']===true&&$m['fator3']['mode']==='read'&&$m['fator3']['local_effect']==='none'&&$m['fator3']['remote_effect']==='none'&&str_starts_with($a->get_label(),'Meta: '));
 if($abilities070){$s=wp_get_ability('meta/status')->get_meta();v070('M1 meta/status contract unchanged (local write, recovery)',$s['annotations']['readonly']===false&&$s['fator3']['local_effect']==='write');}
 if(class_exists('Fator3\\McpFiles\\ConnectionContext')){
  $grant='qa070_'.bin2hex(random_bytes(8));\Fator3\McpFiles\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>1,'client_id'=>'qa070','profile'=>'read','status'=>'active']);
  \Fator3\McpFiles\ConnectionContext::oauth(['user_id'=>1,'grant_id'=>$grant,'client_id'=>'qa070','profile'=>'read']);
  try{$health=M\Api::dispatch('health',[],true);$status=M\Api::dispatch('status',[],true);}
  finally{\Fator3\McpFiles\ConnectionContext::restore_identity(null,1);\Fator3\McpFiles\Persistence::delete('connections','grant:'.$grant);\Fator3\McpFiles\Persistence::delete('oauth-grants',$grant);}
  v070('M1 MCP read profile can diagnose with meta/health and still cannot call meta/status',$health['success']&&!$status['success']&&$status['code']==='not_authorized',wp_json_encode([$health['code'],$status['code']]));
 }
 $subscriber=wp_create_user('meta070_subscriber',wp_generate_password(),'meta070@example.invalid');(new WP_User($subscriber))->set_role('subscriber');wp_set_current_user($subscriber);
 $req=new WP_REST_Request('POST','/f3-meta/v1/health');$req->set_header('Content-Type','application/json');$req->set_body('{}');
 v070('M1 meta/health denied to subscriber (ability and REST 403)',(!$a||is_wp_error($a->check_permissions([]))||$a->check_permissions([])===false)&&rest_do_request($req)->get_status()===403);
 wp_set_current_user(1);
 do_action('f3_meta_maintenance');v070('M1 maintenance still restores the worker after a read-only diagnosis',wp_next_scheduled('f3_meta_worker')!==false);

 // M2 — no package SQL while a fresh request loads (options in autoload, queue settled)
 $q2=lab_bootstrap_sql($t,'f3_meta_');v070('M2 a fresh request runs no SQL of the package during bootstrap',$q2===[],wp_json_encode($q2));
 v070('M2 bootstrap markers are autoloaded',(function(){$all=wp_load_alloptions(true);return isset($all['f3_meta_schema'],$all['f3_meta_history_schema'],$all['f3_meta_queue_settled'])&&M\Queue::settled();})());
 // M3 — unreadable record does not block migration; retention skips it
 $template=['query'=>$q,'principal'=>M\Access::principal(),'connection_revision'=>1,'status'=>'complete','pages'=>0,'rows'=>0,'created_at'=>time()-86400,'updated_at'=>time()-86400,'next_at'=>0,'last_code'=>null,'errors'=>[]];
 for($n=0;$n<150;$n++)M\Store::put('job','00000000000000000qa070_done_'.str_pad((string)$n,3,'0',STR_PAD_LEFT),$template);
 $wpdb->query($wpdb->prepare("UPDATE %i SET queue_state='',queue_next=0 WHERE bucket='job' AND record_key LIKE %s",$t,'00000000000000000qa070_done_%'));
 $wpdb->insert($t,['bucket'=>'job','record_key'=>'000000000000000000qa070_bad','revision'=>1,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time(),'expires_at'=>0,'queue_state'=>'','queue_next'=>0]);
 for($pass=0;$pass<10&&M\Queue::pending();$pass++)M\Queue::migrate();
 $bad=$wpdb->get_var($wpdb->prepare("SELECT queue_state FROM %i WHERE bucket='job' AND record_key=%s",$t,'000000000000000000qa070_bad'));
 $hh=M\Worker::health();
 v070('M3 unreadable legacy job is projected unreadable and the other 150 are migrated',!M\Queue::pending()&&$bad===M\Queue::UNREADABLE&&$hh['queue']['unreadable_jobs']===1&&in_array('queue_record_unreadable',array_column($hh['issues'],'code'),true));
 $mailBefore=count($mail);update_option('f3_meta_operation_notice',[]);M\Worker::notify();$last=end($mail);
 v070('M3 unreadable records are diagnosed but not e-mailed every hour',count($mail)===$mailBefore||!str_contains((string)($last['message']??''),'chave atual'));
 $wpdb->query($wpdb->prepare("UPDATE %i SET expires_at=%d WHERE bucket='job' AND record_key=%s",$t,time()-10,'000000000000000000qa070_bad'));
 M\Store::put('job','000000000000000000qa070_old',$template,0,time()-10);
 $removed=null;$err=null;try{$removed=M\Store::prune();}catch(Throwable $e){$err=get_class($e).':'.($e->reason??$e->getMessage());}
 v070('M3 retention skips the unreadable expired job and removes the readable one',$err===null&&M\Store::get('job','000000000000000000qa070_old')===null&&$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE bucket='job' AND record_key=%s",$t,'000000000000000000qa070_bad'))==='1',(string)$err);
 $wpdb->delete($t,['bucket'=>'job','record_key'=>'000000000000000000qa070_bad']);$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='job' AND record_key LIKE %s",$t,'00000000000000000qa070_done_%'));
 // 150 unreadable expired jobs ordered before a readable expired job: one retention pass must reach the readable one.
 for($n=0;$n<150;$n++)$wpdb->insert($t,['bucket'=>'job','record_key'=>'000000000000000000qa070_bad_'.str_pad((string)$n,3,'0',STR_PAD_LEFT),'revision'=>1,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time(),'expires_at'=>time()-10,'queue_state'=>'unreadable','queue_next'=>0]);
 M\Store::put('job','000000000000000000qa070_zold',$template,0,time()-10);$e3=null;try{M\Store::prune();}catch(Throwable $e){$e3=$e->reason??get_class($e);}
 v070('M3 retention reaches a readable expired job behind 150 unreadable expired jobs in one pass',$e3===null&&M\Store::get('job','000000000000000000qa070_zold')===null,(string)$e3);
 // The same with unmarked unreadable jobs: the first pass marks them, the second reaches the readable one.
 $wpdb->query($wpdb->prepare("UPDATE %i SET queue_state='invalid' WHERE bucket='job' AND record_key LIKE %s",$t,'000000000000000000qa070_bad_%'));
 M\Store::put('job','000000000000000000qa070_zold',$template,0,time()-10);M\Store::prune();M\Store::prune();
 $marked=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE bucket='job' AND queue_state='unreadable' AND record_key LIKE %s",$t,'000000000000000000qa070_bad_%'));
 v070('M3 retention isolates unmarked unreadable jobs and reaches the readable one by the second pass',M\Store::get('job','000000000000000000qa070_zold')===null&&$marked===150);
 $wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='job' AND record_key LIKE %s",$t,'000000000000000000qa070_bad_%'));

 // M4 — maintenance self-heal
 wp_clear_scheduled_hook('f3_meta_maintenance');$c=lab_child('echo json_encode(["next"=>wp_next_scheduled("f3_meta_maintenance")]);');
 wp_cache_delete('alloptions','options');wp_cache_delete('cron','options');
 v070('M4 hourly maintenance event self-heals on the next request',$c['rc']===0&&!empty($c['json']['next'])&&wp_next_scheduled('f3_meta_maintenance')!==false,wp_json_encode($c));
 v070('M4 health flags a missing maintenance event without e-mail',(function(){wp_clear_scheduled_hook('f3_meta_maintenance');$h=M\Worker::health();$ok=in_array('maintenance_missing',array_column($h['issues'],'code'),true);wp_schedule_event(time()+3600,'hourly','f3_meta_maintenance');return $ok;})());

 // M5 — audit newest first
 $base=time()+1000;foreach([10,30,20] as $k=>$age){$key='0000qa070audit'.$k;M\Store::put('audit',$key,['operation'=>'qa070-'.$age,'actor'=>['type'=>'user','id'=>1],'transport'=>'local_sdk','connection_id'=>null,'code'=>'ok','at'=>$base-$age],0,time()+86400);$wpdb->update($t,['updated_at'=>$base-$age],['bucket'=>'audit','record_key'=>$key]);}
 $all=M\Api::dispatch('audit',['since'=>$base-60]);$ops=array_column($all['data']['events']??[],'operation');
 v070('M5 audit lists newest first',$all['success']&&$all['data']['order']==='newest_first'&&$ops===['qa070-10','qa070-20','qa070-30'],wp_json_encode($ops));
 $r=M\Api::dispatch('audit',['since'=>$base-25]);v070('M5 audit since filter',array_column($r['data']['events'],'operation')===['qa070-10','qa070-20']);
 $bad=M\Api::dispatch('audit',['since'=>-1]);v070('M5 audit since rejects negative values',!$bad['success']&&$bad['code']==='invalid_input');

 // list-connections pagination from one read
 for($n=0;$n<52;$n++)M\Connections::save(['connection_id'=>'qa070c'.str_pad((string)$n,2,'0',STR_PAD_LEFT),'expected_revision'=>0,'assets'=>['instagram'=>[]]]);
 $p1=M\Api::dispatch('list-connections');$p2=M\Api::dispatch('list-connections',['offset'=>50]);
 v070('list-connections pages of 50 with exact next_offset and no secrets',count($p1['data']['connections'])===50&&$p1['data']['next_offset']===50&&$p2['data']['next_offset']===null&&count($p2['data']['connections'])>=3&&!str_contains(wp_json_encode($p1),'qa070-synthetic-not-a-token'));
 foreach(M\Store::list('connection',0,100) as $row)if(str_starts_with($row['key'],'qa070c'))M\Store::remove('connection',$row['key'],$row['revision']);
}finally{
 foreach(['schedule'=>'qa070_hourly','connection'=>'qa070'] as $bucket=>$key){$row=M\Store::get($bucket,$key);if($row)M\Store::remove($bucket,$key,$row['revision']);}
}
$failed=count(array_filter($checks,fn($c)=>!$c['passed']));$report=['abilities_api'=>function_exists('wp_get_ability'),'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'version'=>M\Config::VERSION,'origin'=>getenv('F3_LAB_ORIGIN'),'checks'=>$checks,'total'=>count($checks),'failed'=>$failed,'provider_http_fixture_calls'=>$http,'mail_intercepted'=>count($mail)];
file_put_contents(getenv('F3_LAB_ROOT').'/evidence/release070.json',wp_json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));echo json_encode(['total'=>count($checks),'failed'=>$failed])."\n";if($failed)exit(1);
