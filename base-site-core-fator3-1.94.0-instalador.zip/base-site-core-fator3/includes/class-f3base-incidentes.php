<?php
/** Contrato local incidentes/1. As observações são do produtor e a entrega é do Core. */
declare(strict_types=1);
defined('ABSPATH') || exit;

final class F3Base_Incidentes {
    private const PREFIXO = 'f3base_incidente_v1_';
    public const ROTAS = [
        'meta'=>'tools.php?page=wp-mcp-meta-fator3',
        'linkedin'=>'tools.php?page=wp-mcp-linkedin-fator3',
        'google'=>'tools.php?page=wp-mcp-google-fator3',
        'pipedrive'=>'tools.php?page=wp-mcp-pipedrive-fator3',
        'canal'=>'tools.php?page=wp-mcp-fator3',
        'core'=>'admin.php?page=base-site-core-fator3',
    ];
    public const CODIGOS = [
        'agenda_parada','autorizacao_recusada','credencial_invalida','token_vencendo',
        'refresh_vencendo','prova_vencendo','renovacao_falhou','graph_vencendo',
        'canal_indisponivel','integracao_indisponivel','cron_sem_passagem','destino_tecnico_ausente',
    ];

    public static function iniciar(): void {
        add_filter('f3base_incidente_publicar_v1', static fn($anterior,$e)=>self::publicar($e), 10, 2);
        add_action('wp_abilities_api_init', [self::class,'registrar'], 80);
        add_action('admin_init', static function() {
            if (current_user_can('manage_options')) {self::observar();}
        });
        add_action('admin_notices', static function() {
            if (current_user_can('manage_options') && F3Base_Alertas_Operacionais::destinatario()==='') {
                printf('<div class="notice notice-warning"><p>Os avisos técnicos aguardam um endereço de e-mail. <a href="%s">Configurar destino técnico</a>.</p></div>',
                    esc_url(F3Base_Configuracoes_Hub::url('conexoes','f3base_avisos_tecnicos')));
            }
        });
        add_filter('pre_wp_mail',[F3Base_Incidentes_Provedores::class,'email_legado'],5,2);
        add_filter('pre_http_request',[F3Base_Incidentes_Provedores::class,'webhook_legado'],5,3);
    }

    public static function registrar(): void {
        F3Base_Servicos::ability('incidentes-tecnicos-ler','Incidentes técnicos e confirmação do transporte',
            [self::class,'listar'], ['apos'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$']]);
        F3Base_Servicos::ability('incidente-entrega-reconciliar','Registrar o resultado de uma entrega incerta após conferir o transporte',
            [self::class,'reconciliar'], [
                'id'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$'],
                'reserva'=>['type'=>'string','format'=>'uuid'],
                'resultado'=>['type'=>'string','enum'=>['aceito','nao_enviado']],
            ], ['id','reserva','resultado'], false);
    }

    private static function chave(string $pacote,string $codigo,string $ref): string {
        return self::PREFIXO.hash('sha256', $pacote.'|'.$codigo.'|'.$ref);
    }

    /** Valor original do recurso nunca é guardado. O identificador opaco é estável no site. */
    public static function publicar(array $e): array {
        return self::registrar_evento($e, null);
    }

    /** Snapshot coletado no próprio observador. Metadados livres do filtro não são persistidos. */
    public static function observar_registro_canal(): void {
        $registro = F3Base_Incidentes_Provedores::registro_canal();
        if ($registro === null) {return;}
        $indisponivel = $registro['erros'] !== [];
        if (!$indisponivel && !$registro['verificado']) {return;}
        self::registrar_evento([
            'pacote'=>'canal', 'codigo'=>'canal_indisponivel', 'recurso'=>'registro-wordpress',
            'estado'=>$indisponivel ? 'aberto' : 'recuperado', 'acao_humana'=>$indisponivel,
        ], $registro);
    }

    private static function registrar_evento(array $e, ?array $registro): array {
        $p=$e['pacote']??''; $c=$e['codigo']??''; $id=$e['recurso']??''; $estado=$e['estado']??'';
        if (!is_string($p) || !isset(self::ROTAS[$p]) || !in_array($c,self::CODIGOS,true)
            || !is_string($id) || $id==='' || strlen($id)>240 || !in_array($estado,['aberto','recuperado'],true)
            || (isset($e['rota']) && $e['rota']!==self::ROTAS[$p])
            || !is_bool($e['acao_humana']??true)
            || (isset($e['desde']) && (!is_int($e['desde']) || $e['desde']<1 || $e['desde']>time()))
            || (isset($e['vence_em']) && (!is_int($e['vence_em']) || $e['vence_em']<1))) {
            return ['ok'=>false,'codigo'=>'observacao_invalida'];
        }
        $ref=hash_hmac('sha256',$id,wp_salt('auth'));
        $key=self::chave($p,$c,$ref);
        return self::com_trava($key, static function() use ($key,$e,$p,$c,$id,$ref,$estado,$registro) {
            $r=get_option($key,[]);
            if (!$r && $estado==='recuperado') {return ['ok'=>true,'estado'=>'sem_incidente'];}
            if (($r['estado']??'')!==$estado) {
                $r['pacote']=$p; $r['codigo']=$c; $r['recurso_ref']=$ref; $r['rota']=self::ROTAS[$p];
                $r['estado']=$estado; $r['alterado_em']=time();
                if ($estado==='aberto') {$r['desde']=$e['desde']??time();}
                $r['acao_humana']=$e['acao_humana']??true; $r['vence_em']=$e['vence_em']??null;
                $r['fila'][]=['estado'=>$estado,'desde'=>$r['desde'],'em'=>time(),'vence_em'=>$r['vence_em'],
                    'acao_humana'=>$r['acao_humana'],'entrega'=>'pendente'];
                if ($p === 'canal' && $c === 'canal_indisponivel' && $id === 'registro-wordpress') {
                    $r['historico_registro'] = self::historico_registro($r, $e, $registro);
                }
                if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'persistencia_falhou'];}
            } elseif ($estado==='aberto' && isset($e['vence_em']) && $r['vence_em']!==$e['vence_em']) {
                $r['vence_em']=$e['vence_em'];
                if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'persistencia_falhou'];}
            }
            return self::entregar($key,$r);
        });
    }

    /** Rastro circular administrativo, separado da fila de entregas e da identificação do recurso. */
    private static function historico_registro(array $r, array $e, ?array $registro): array {
        $origem = $registro === null ? 'publicador_canal' : 'observador_core';
        if ($registro === null) {
            try {$registro = F3Base_Incidentes_Provedores::registro_canal();}
            catch (Throwable $erro) {$registro = null;}
        }
        $marcos = [];
        foreach (['init','wp_abilities_api_init','rest_api_init','f3_mcp_adapter_init','wp_loaded','admin_init','f3base_zelador_tick'] as $hook) {
            $marcos[$hook] = doing_action($hook) ? 'em_execucao' : (did_action($hook) ? 'concluido' : 'pendente');
        }
        $historico = $r['historico_registro'] ?? [];
        $historico[] = [
            'estado'=>$e['estado'], 'recebido_em'=>time(), 'desde_informado'=>$e['desde'] ?? null,
            'origem'=>$origem, 'contexto'=>defined('WP_CLI') && WP_CLI ? 'cli' : (wp_doing_cron() ? 'http_cron' : 'web'),
            'versao_core'=>F3BASE_PLUGIN_VERSAO, 'versao_canal'=>defined('F3_MCP_FILES_VERSION') ? F3_MCP_FILES_VERSION : null,
            'marcos'=>$marcos, 'registro_na_recepcao'=>$registro,
        ];
        return array_slice($historico, -12);
    }

    private static function com_trava(string $key, callable $fn): array {
        if (!F3Base_Pipedrive_Fila::travar_linha($key)) {return ['ok'=>false,'codigo'=>'ocupado','repetir'=>true];}
        try {
            // Uma opção não-autoload lida antes da trava pode estar no cache deste processo.
            wp_cache_delete($key,'options'); wp_cache_delete('notoptions','options');
            return $fn();
        } finally {F3Base_Pipedrive_Fila::liberar_linha($key);}
    }

    private static function entregar(string $key,array $r): array {
        while ($r['fila']??[]) {
            $ev=$r['fila'][0];
            if (($ev['entrega']??'')==='reservado') {return ['ok'=>false,'estado'=>'entrega_incerta'];}
            if (F3Base_Alertas_Operacionais::destinatario()==='') {return ['ok'=>true,'estado'=>'aguardando_destino'];}
            if (($ev['tentar_apos']??0)>time()) {return ['ok'=>true,'estado'=>'aguardando_retentativa'];}
            $r['fila'][0]['entrega']='reservado';
            $r['fila'][0]['reserva']=wp_generate_uuid4();
            if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'reserva_nao_gravada'];}
            $fase=$ev['estado']==='aberto'?'Incidente técnico':'Recuperação técnica';
            $titulo=$fase.' · '.$r['pacote'].' · '.$r['codigo'];
            $texto=implode("\n",[$titulo, 'Site: '.wp_parse_url(home_url(),PHP_URL_HOST),
                'Referência do recurso: '.$r['recurso_ref'], 'Desde: '.wp_date('d/m/Y H:i:s T',$ev['desde']),
                'Observação: '.wp_date('d/m/Y H:i:s T',$ev['em']),
                $ev['vence_em']?'Vencimento: '.wp_date('d/m/Y H:i:s T',$ev['vence_em']):'',
                'Ação de pessoa: '.($ev['estado']==='aberto' && $ev['acao_humana']?'sim':'não'),
                'Reparo: '.admin_url($r['rota'])]);
            $envio=F3Base_Alertas_Operacionais::enviar($titulo,$texto);
            if (!empty($envio['ok'])) {array_shift($r['fila']);}
            elseif (($envio['estado']??'')!=='incerto') {
                $r['fila'][0]['entrega']='pendente'; $r['fila'][0]['tentar_apos']=time()+300;
            }
            $r['ultimo_envio']=['fase'=>$ev['estado'],'codigo'=>$envio['codigo'],'em'=>time()];
            if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'confirmacao_nao_gravada'];}
            if (!$envio['ok']) {return ['ok'=>false,'estado'=>$envio['estado']];}
        }
        return ['ok'=>true,'estado'=>$r['estado'],'entrega'=>$r['ultimo_envio']??null];
    }

    public static function reconciliar(array $e): array {
        if (!current_user_can('manage_options')) {return ['ok'=>false,'codigo'=>'sem_permissao'];}
        if (!preg_match('/^[a-f0-9]{64}$/D', $e['id']??'') || empty($e['reserva'])
            || !in_array($e['resultado']??'', ['aceito','nao_enviado'], true)) {
            return ['ok'=>false,'codigo'=>'entrada_invalida'];
        }
        $key=self::PREFIXO.$e['id'];
        return self::com_trava($key,static function() use ($key,$e) {
            $r=get_option($key,[]);
            $ev=$r['fila'][0]??[];
            if (($ev['entrega']??'')!=='reservado' || ($ev['reserva']??null)!==$e['reserva']) {
                return ['ok'=>false,'codigo'=>'reserva_divergente'];
            }
            if ($e['resultado']==='aceito') {array_shift($r['fila']);}
            else {$r['fila'][0]['entrega']='pendente'; unset($r['fila'][0]['tentar_apos']);}
            $r['reconciliacao']=['resultado'=>$e['resultado'],'em'=>time(),'operador'=>get_current_user_id(),'fase'=>$ev['estado']];
            if (!update_option($key,$r,false)) {return ['ok'=>false,'codigo'=>'persistencia_falhou'];}
            return ['ok'=>true,'entregas_pendentes'=>count($r['fila'])];
        });
    }

    public static function vencimento(string $pacote,string $codigo,string $id,int $vence): array {
        if ($vence<1) {return ['ok'=>true,'estado'=>'validade_desconhecida'];}
        $dias=(int)(F3Base_Options::ler('f3base_avisos_tecnicos')['antecedencia_dias']??14);
        $limiar=$vence-$dias*DAY_IN_SECONDS;
        return self::publicar(['pacote'=>$pacote,'codigo'=>$codigo,'recurso'=>$id,'vence_em'=>$vence,
            'desde'=>max(1,min(time(),$limiar)),'estado'=>time()>=$limiar?'aberto':'recuperado']);
    }

    public static function listar(array $e=[]): array {
        global $wpdb;
        $apos=$e['apos']??'';
        $linhas=$wpdb->get_results($wpdb->prepare('SELECT option_name, option_value FROM %i WHERE option_name LIKE %s AND option_name>%s ORDER BY option_name LIMIT 51',
            $wpdb->options,$wpdb->esc_like(self::PREFIXO).'%',self::PREFIXO.$apos),ARRAY_A);
        if ($wpdb->last_error) {return ['ok'=>false,'codigo'=>'leitura_indisponivel'];}
        $itens=[]; $next=null;
        foreach (array_slice($linhas,0,50) as $linha) {
            $r=maybe_unserialize($linha['option_value']);
            if (!is_array($r)) {continue;}
            $id=substr($linha['option_name'],strlen(self::PREFIXO)); $r['id']=$id;
            $r['entregas_pendentes']=count($r['fila']??[]); $r['proxima_entrega']=$r['fila'][0]['entrega']??null;
            if ($r['proxima_entrega']==='reservado') {$r['reserva']=$r['fila'][0]['reserva']??null;}
            unset($r['fila']); $itens[]=$r; $next=$id;
        }
        return ['ok'=>true,'itens'=>$itens,'proximo'=>count($linhas)>50?$next:null,
            'destino_configurado'=>F3Base_Alertas_Operacionais::destinatario()!==''];
    }

    public static function observar(): void {
        if (wp_installing() || get_transient('f3base_incidentes_revisados')) {return;}
        self::com_trava('f3base_revisar_incidentes',static function() {
            if (get_transient('f3base_incidentes_revisados')) {return [];}
            set_transient('f3base_incidentes_revisados',1,300);
            F3Base_Incidentes_Provedores::observar();
            $apos=''; $abertos=[];
            do {
                $page=self::listar(['apos'=>$apos]); if (!$page['ok']) {return [];}
                foreach ($page['itens'] as $r) {
                    if ($r['entregas_pendentes']) {
                        $key=self::PREFIXO.$r['id'];
                        self::com_trava($key,static fn()=>self::entregar($key,get_option($key,[])));
                    }
                    if ($r['estado']==='aberto') {$abertos[]=$r['pacote'].' · '.$r['codigo'].' · '.substr($r['recurso_ref'],0,12);}
                }
                $apos=$page['proximo'];
            } while ($apos);
            $cfg=F3Base_Options::ler('f3base_avisos_tecnicos'); $dia=wp_date('Y-m-d');
            if ($abertos && !empty($cfg['resumo_diario']) && F3Base_Alertas_Operacionais::destinatario()!==''
                && get_option('f3base_incidentes_dia','')!==$dia && update_option('f3base_incidentes_dia',$dia,false)) {
                $envio=F3Base_Alertas_Operacionais::enviar('Resumo diário de incidentes técnicos',implode("\n",$abertos));
                if (!$envio['ok'] && $envio['estado']!=='incerto') {delete_option('f3base_incidentes_dia');}
            }
            return [];
        });
    }
}
