<?php
/** Bounded private diagnostic ring; never accepts request payloads or exception text. */
declare(strict_types=1);
namespace WpMcpUltimate\OAuth;
use Fator3\McpFiles\StateStore;

final class ClientDiagnostics {
    private const CODES = ['client_unavailable', 'metadata_fetch_failed', 'metadata_invalid', 'metadata_unsafe', 'metadata_method_unsupported', 'client_persistence_failed'];
    public static function failure(string $category, string $client_id = ''): \WP_Error {
        if (!in_array($category, self::CODES, true)) $category = 'metadata_invalid';
        $id = bin2hex(random_bytes(12));
        $record = ['diagnostic_id'=>$id, 'category'=>$category, 'time'=>time(), 'site_id'=>get_current_blog_id(), 'client_hash'=>hash_hmac('sha256', $client_id, wp_salt('auth'))];
        // Last 128 records, PHP guard, 0600 files. SQL failures can still be diagnosed.
        try {
            $dir = StateStore::directory('oauth-diagnostics');
            $lock=fopen($dir.'/ring.lock.php','c+b');
            if(!$lock)throw new \RuntimeException('Diagnostic lock unavailable.');
            @chmod($dir.'/ring.lock.php',0600);
            try {
                if(!flock($lock,LOCK_EX))throw new \RuntimeException('Diagnostic lock unavailable.');
                $path=$dir.'/ring.php';$records=[];
                if(is_file($path)) {
                    $bytes=file_get_contents($path,false,null,0,65537);
                    if(is_string($bytes)&&strlen($bytes)<=65536&&str_starts_with($bytes,StateStore::HEADER))$records=json_decode(substr($bytes,strlen(StateStore::HEADER)),true)?:[];
                }
                if(!is_array($records)||!array_is_list($records))$records=[];
                $records=array_slice($records,-127);$records[]=$record;
                StateStore::write($path,StateStore::HEADER.wp_json_encode($records));
            } finally {flock($lock,LOCK_UN);fclose($lock);}
        } catch (\Throwable $ignored) { /* The opaque ID remains available; no unsafe log fallback. */ }
        return new \WP_Error($category, 'Client authorization could not be resolved.', ['diagnostic_id'=>$id]);
    }
}
