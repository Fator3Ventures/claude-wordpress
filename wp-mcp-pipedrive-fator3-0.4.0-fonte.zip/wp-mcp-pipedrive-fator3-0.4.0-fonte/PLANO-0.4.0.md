# Plano de execução — Fator3 MCP Pipedrive 0.4.0

29/10/2026. Base íntegra 0.3.0; pedidos 4–9 de 28/10/2026.

1. Preservar slug, contratos Core pipedrive-api-client/1.0.0, autenticação, orçamento operacao, retenção e nove rotas existentes. Conferir Core 1.60/MCP 0.36/Google 0.22/Meta 0.14/LinkedIn 0.12 e normas comuns revisão 5.
2. Configuração local revisionada: cadência, calendário, intervalos, exclusões, etiquetas, textos, motivos e auditoria. Simular e vincular aprovação à revisão/candidato antes de salvar. Sem presumir textos/prazos da referência ausente; desativada até configuração. Lista inicial archive_reason é a autorizada no pedido 6; lost_reason vazio até ordem do dono.
3. Leituras paginadas e limitadas: fila, auditoria por IDs, contagem por campo com HMAC para texto livre, declaração de completude/custo/visibilidade.
4. Escritas compostas: WhatsApp com chave por mensagem; encerramento/perda/edição arquivada com prévia, validação e revalidação; serialização por conta/registro, recibo persistente e incerteza sem repetição automática. Rearquivar após falha da edição e declarar resultado. Não há atomicidade distribuída nem WhatsApp enviado por este plugin.
5. Testes sintéticos isolados no Site-Teste, HTTP/e-mail interceptados; instalação limpa e upgrade0.3→0.4; regressões, novos casos positivos/negativos, consentimento por revisão e estado concorrente. Validar mínimo declarado e ambiente corrente quando disponíveis.
6. Documentar limites, desfazimento, fontes, pendências externas. Empacotar instalador/fonte sem ZIP aninhado e relatório em português; instalar bytes finais no Site-Teste, conferir hashes/estado/sondas, retirar auxiliares e entregar.

Não há impacto externo novo identificado: transporte genérico Core atende os métodos; schemas novos usam extensão pública MCP. Nenhum pacote acompanhante será alterado. Aceites em contas reais, confronto de tela e implantação nos sites-porta permanecem da frota.

## Fechamento
527 verificações funcionais/integração e 58 estáticas aprovadas; backend mínimo7.1.3/PHP 8.3.36 validado. Acompanhantes atualizaram MCP 0.37/LinkedIn 0.13 em paralelo; matriz final congelada e provada sem alterar o compartilhado. Pipedrive 0.4 ativo, dados preservados, 19 rotas e11 documentos. Limpeza concluída. Regras comerciais e homologação na conta real continuam pendentes do dono/frota.
