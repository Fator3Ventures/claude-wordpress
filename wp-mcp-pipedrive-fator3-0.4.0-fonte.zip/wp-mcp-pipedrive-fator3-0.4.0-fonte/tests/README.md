# Provas — 0.3.0

PHP nativo em WordPress 7.1.3/PHP 8.3.36/MySQL 8.0.41, laboratórios descartáveis. Não executar testes mutáveis nas tabelas do site compartilhado.

`lab-controller.php` registra temporariamente qa-pipedrive030/run, apenas administrador e ações enumeradas. Prefixos exatos f3pipqa_0300c_ e f3pipqa_0300u_, raízes /tmp/f3-pipedrive-qa-0300-d848899a8f83-{current,upgrade}, marcador f3-pipedrive-disposable-0300-d848899a8f83. Verificar autorização e ausência de conflito antes de reproduzir. WordPress do servidor é reutilizado somente para leitura; banco isolado, salts próprios e bloqueio de HTTP/e-mail. O arquivo privado de configuração não integra fonte/evidências e é apagado na limpeza.

Bundle QA temporário em wp-content/f3-pipedrive-qa-0300.zip: runner.php (lab-runner.php), installer.zip (0.3.0 final), base.zip (0.2.0, hash no relatório), tests/*.php exceto controladores. Bundle não integra esta entrega, porque ZIPs não contêm outros ZIPs.

Sequência current: setup, install, native, report, retention, integrate, integrated, core, core-report, cleanup. Sequência upgrade: setup, install-base, seed-upgrade, upgrade, verify-upgrade, upgrade-restart, cleanup. Uma chamada/processo por ação. `native` e `retention` criam usuários sintéticos no banco isolado; reiniciar cenário limpo antes de repeti-las. Workers usam marcador 0300. Provas cobrem concorrência CAS/locks em processos MySQL distintos. First attempt do worker herdou marcador 0200, corrigido apenas no teste e repetido do zero; ver current-native-attempt1.json.

`report.php`: 49 checks com cliente em memória, transporte vedado, sem writes no banco. `integrated.php`: executor MCP original, descoberta/read profile/docs. `core-report.php`: cliente Core original e transporte WP interceptado com credencial sintética só no banco isolado. Não equivalem ao fornecedor real.

Para compartilhado: instalar `shared-controller.php` temporário em mu-plugins e cópia de report.php em wp-content/f3-pipedrive-report030.php. `qa-pipedrive030-shared/run` aceita snapshot ou report; trava hostname e versão, limita-se ao cenário fixo, restaura cliente/identidade ao terminar, não altera tabelas ou configuração. Tirar snapshot antes/depois, comparar hashes de tabelas, retenção e autorização, conferir todos os hashes de runtime. Remover os dois arquivos. Não usar fixture como autorização comercial.

Evidências finais em evidence/. Candidato recebeu correções documentais antes do fechamento; PHP funcional permaneceu idêntico. Instalador final repetiu instalação limpa, relatório, executor MCP/documentos e atualização direta. Regressões de PHP/retencão anteriores permanecem pertinentes porque esses bytes não mudaram. Conferência da conta real e tela não realizada.
