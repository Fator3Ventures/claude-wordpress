<?php
use Fator3\Pipedrive\{Api,Retention,Store,Support};
if(!defined('F3_PIPEDRIVE_DISPOSABLE') || !str_starts_with($wpdb->prefix,'f3pipqa_0400'))throw new RuntimeException('Private lab required');
wp_set_current_user(1);$checks=[];$check=static function($n,$ok)use(&$checks){$checks[]=['name'=>$n,'passed'=>(bool)$ok];};
$raw=static function($n,$v){update_option($n,$v,false);wp_cache_delete($n,'options');};
$token=str_repeat('a9',20);$calls=0;$writes=0;$record=['id'=>910,'content'=>'QA Core retention'];
$http=static function($pre,$args,$url)use(&$calls,&$writes,&$record){
 if(!str_starts_with($url,'https://api.pipedrive.com/v1/notes/910'))return new WP_Error('qa_block','Other HTTP blocked');
 ++$calls;if(($args['method']??'GET')!=='GET'){++$writes;$record=array_replace($record,json_decode($args['body'],true));}
 return ['response'=>['code'=>200],'headers'=>['x-daily-ratelimit-token-remaining'=>'9000'],'body'=>wp_json_encode(['success'=>true,'data'=>$record])];
};add_filter('pre_http_request',$http,99,3);
$cfg=F3Base_Options::ler('f3base_pipedrive');$cfg['dominio']='qa040.pipedrive.com';$cfg['ativo']=true;
$raw('f3base_pipedrive',$cfg);$raw('f3base_pipedrive_token',F3Base_Segredos::cifrar('f3base_pipedrive_token',$token));
$state=['estado'=>'verificado','conta_id'=>'12345','usuario_id'=>1234,'dominio'=>$cfg['dominio'],'instalacao'=>'qa040','revisao'=>F3Base_Options::revisao('f3base_pipedrive'),'credencial_revisao'=>F3Base_Options::revisao('f3base_pipedrive_token')];$state['identidade_conta']=F3Base_Integracoes::identidade_pipedrive($state);
$raw('f3base_pipedrive_estado',$state);$raw('f3base_pipedrive_operacao',['ativo'=>true,'consumidores'=>['wp-mcp-pipedrive-fator3'],'orcamento_diario'=>3000]);
$raw(F3Base_Pipedrive_Saldo::OPTION,[]);$raw('f3base_pipedrive_operacao_orcamento',[]);
$policy=Retention::read();if($policy['diario_dias']!==0)Retention::configure(['diario_dias'=>0,'revisao_esperada'=>$policy['revisao']]);
$id=bin2hex(random_bytes(16));$journal=Store::table('journal');$wpdb->insert($journal,['previa_id'=>$id,'created'=>time()-400*DAY_IN_SECONDS,'metadata'=>Support::json(['previa_id'=>$id,'metodo'=>'PUT','caminho'=>'/v1/notes/910','classe'=>'registro','status'=>'ok','chaves_alteradas'=>['content'],'saldo_depois'=>null])]);
$line=static fn()=>$wpdb->get_row($wpdb->prepare("SELECT * FROM $journal WHERE previa_id=%s",$id),ARRAY_A);$before=$line();
$s=Api::dispatch('status');$check('real_core_registered_and_authorized',$s['success'] && $s['data']['registro_cliente']==='registrado');
$check('status_policy_no_http',($s['data']['retencao']['diario_dias']??-1)===0 && $calls===0);
$p=Api::dispatch('api-previa',['metodo'=>'PUT','caminho'=>'/v1/notes/910','corpo'=>['content'=>'QA changed by actual Core client']]);
$check('real_core_preview_preserves_old_line',$p['success'] && $before===$line());
if(!$p['success'])throw new RuntimeException('Preview refused: '.($p['code']??'unknown'));
$r=Api::dispatch('api-aplicar',['previa_id'=>$p['data']['previa_id']]);
$check('real_core_apply_preserves_old_line',$r['success'] && $before===$line() && $writes===1);
$n=$calls;$repeat=Api::dispatch('api-aplicar',['previa_id'=>$p['data']['previa_id']]);
$check('real_core_receipt_replay',$repeat===$r && $calls===$n);
$s=Api::dispatch('status');$check('real_core_budget_integration',$s['data']['orcamento']['consumido']===50 && $s['data']['saldo_conta']['restante']===9000);
$check('response_does_not_expose_fixture_token',!str_contains(wp_json_encode([$s,$p,$r]),$token));
$check('metadata_no_note_value',!str_contains($wpdb->get_var($wpdb->prepare("SELECT metadata FROM $journal WHERE previa_id=%s",$p['data']['previa_id'])),'QA changed'));
remove_filter('pre_http_request',$http,99);
return ['checks'=>$checks,'passed'=>count(array_filter($checks,fn($c)=>$c['passed'])),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'core_version'=>get_plugin_data(WP_PLUGIN_DIR.'/base-site-core-fator3/base-site-core-fator3.php',false,false)['Version'],'core_http_intercepted'=>$calls,'core_writes_intercepted'=>$writes,'supplier_http'=>0,'scope'=>'Original Core client, synthetic credentials and WordPress HTTP responses; isolated database.'];
