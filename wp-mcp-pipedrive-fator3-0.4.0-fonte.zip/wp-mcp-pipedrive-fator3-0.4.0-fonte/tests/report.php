<?php
/** Native WordPress report tests; synthetic account only, no supplier HTTP. */
use Fator3\Pipedrive\{Api,CoreClient,Store,Retention};
if(!defined('F3_PIPEDRIVE_DISPOSABLE'))throw new RuntimeException('QA marker required');
$checks=[];$check=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};
$actor=get_current_user_id();wp_set_current_user(1);
$property=new ReflectionProperty(CoreClient::class,'client');$original=$property->getValue();
$http=0;$block=static function()use(&$http){++$http;return new WP_Error('qa_block','Blocked');};add_filter('pre_http_request',$block,999);
final class ReportFixture {
 public array $data=[],$requests=[];public string $mode='';public int $spent=0,$limit=100000;public bool $allowed=true;
 public function capabilities(){return ['contract'=>'pipedrive-api-client/1.0.0'];}
 public function status(){return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>$this->allowed,'conta'=>['dominio'=>'fixture.pipedrive.com','conta_id'=>101,'usuario_id'=>1],'revisao'=>$this->mode==='revision'&&$this->spent?'changed':'report-fixture','orcamento'=>['teto'=>$this->limit,'consumido'=>$this->spent,'reservado'=>0],'saldo_conta'=>null]];}
 public function request($m,$p,$q,$b,$ctx){
  $this->requests[]=[$m,$p,$q,$b,$ctx];
  if($this->spent+20>$this->limit)return ['success'=>false,'code'=>'orcamento_esgotado','remote_dispatched'=>false];
  $this->spent+=20;if($this->mode==='slow')usleep(1100000);
  if($this->mode==='timeout')throw new RuntimeException('PII_CANARY_SECRET');
  if($this->mode==='error')return ['success'=>false,'remote_dispatched'=>true,'data'=>['http_status'=>429,'body'=>['error'=>'PII_CANARY_SECRET'],'saldo_conta'=>null]];
  $v2=str_starts_with($p,'/api/v2/');$offset=(int)($q['start']??$q['cursor']??0);$all=$this->data[$p]??[];
  $rows=array_slice($all,$offset,2);$more=$offset+2<count($all);
  $additional=$v2?['next_cursor'=>$more?(string)($offset+2):null]:['pagination'=>['more_items_in_collection'=>$more,'next_start'=>$more?$offset+2:null]];
  if($this->mode==='malformed')$additional=[];
  if($this->mode==='loop'&&$v2)$additional=['next_cursor'=>'2'];
  if($this->mode==='empty_more'){$rows=[];$additional=$v2?['next_cursor'=>'2']:['pagination'=>['more_items_in_collection'=>true,'next_start'=>$offset+2]];}
  if($this->mode==='null'&&!$rows)$rows=null;
  return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>$rows,'additional_data'=>$additional],'saldo_conta'=>null]];
 }
}
$base=new ReportFixture();$names=['Parceiro','Unidade','Canal','Campanha','Ponto de conversão','Motivo de ganho'];$keys=[];
foreach($names as $n=>$name){$key=str_repeat(dechex($n+1),40);$keys[]=$key;$base->data['/v1/dealFields'][]=['key'=>$key,'name'=>$name,'field_type'=>'enum','options'=>[['id'=>1,'label'=>'PII_CANARY_PERSON'],['id'=>2,'label'=>'PII_CANARY_EMAIL']]];}
$lead=static function($id,$date,$arch=false)use($keys){$r=['id'=>sprintf('00000000-0000-4000-8000-%012d',$id),'title'=>'PII_CANARY_TITLE','name'=>'PII_CANARY_PERSON','email'=>'pii_canary@example.test','phone'=>'+5511999999999','add_time'=>$date,'is_archived'=>$arch,'archive_reason'=>$arch?'Motivo QA':null,'archive_time'=>$arch?'2026-10-20T12:00:00Z':null];foreach($keys as $key)$r[$key]=1;return $r;};
$base->data['/v1/leads']=[$lead(1,'2026-09-28T03:00:00Z'),$lead(2,'2026-10-28T02:59:59Z'),$lead(3,'2026-10-28T03:00:00Z')];
$base->data['/v1/leads/archived']=[$lead(4,'2026-10-10T12:00:00Z',true),$lead(5,'2026-08-01T12:00:00Z',true)];
$deal=static fn($id,$state,$arch=false)=>['id'=>$id,'title'=>'PII_CANARY_TITLE','status'=>$state,'is_archived'=>$arch,'pipeline_id'=>2,'stage_id'=>3,'add_time'=>'2026-10-01 12:00:00','won_time'=>'2026-10-20T12:00:00Z','lost_time'=>'2026-10-21T12:00:00Z','lost_reason'=>'PII_CANARY_PERSON','custom_fields'=>[$keys[5]=>1]];
$base->data['/api/v2/deals']=[$deal(1,'open'),$deal(2,'won'),$deal(3,'lost')];$base->data['/api/v2/deals/archived']=[$deal(4,'won',true)];
$input=['data_inicio'=>'2026-09-28','data_fim'=>'2026-10-27','limite_plano'=>10,'categorias'=>[['dimensao'=>'motivo_arquivamento','valor'=>'Motivo QA','codigo'=>7]]];
$run=static function($fixture,$i=null)use($property,$input){$fixture->spent=0;$fixture->requests=[];$property->setValue(null,$fixture);return Api::dispatch('relatorio',$i??$input);};
$tables=static fn()=>[$GLOBALS['wpdb']->get_results('SELECT * FROM '.Store::table('ops').' ORDER BY previa_id',ARRAY_A),$GLOBALS['wpdb']->get_results('SELECT * FROM '.Store::table('journal').' ORDER BY id',ARRAY_A),get_option(Retention::OPTION)];$before=$tables();
try{
 $r=$run(clone $base);$d=$r['data'];
 $check('complete_report',$r['success']&&$d['completo']&&$d['coleta_completa']);
 $check('timezone_inclusive_dates',$d['leads']['abertos_observados']===2&&$d['leads']['arquivados_observados']===1);
 $check('dimensions_grouped',count($d['leads']['grupos'])===2&&$d['leads']['grupos'][0]['parceiro']==='opcao:1'&&$d['leads']['grupos'][0]['quantidade']===2);
 $check('reason_numeric_alias',$d['leads']['grupos'][1]['motivo_arquivamento']==='codigo:7');
 $check('won_lost_including_archived',$d['negocios']['ganhos_observados']===2&&$d['negocios']['perdidos_observados']===1);
 $check('pipeline_stage',count($d['negocios']['por_funil_etapa'])===4&&$d['negocios']['por_funil_etapa'][0]['funil_id']===2);
 $check('usage_independent_of_period',$d['uso_plano']['total']===6&&$d['uso_plano']['saldo']===4&&$d['uso_plano']['percentual']===60.0);
 $check('pagination_and_cost',$d['custo']['gasto']===180&&$d['fontes']['campos']['paginas']===3&&$d['fontes']['negocios_ativos']['paginas']===2);
 $json=wp_json_encode($r);$check('no_supplier_text_or_pii',!str_contains($json,'PII_CANARY')&&!str_contains($json,'pii_canary')&&!str_contains($json,'5511999999999')&&!str_contains($json,'Motivo QA')&&!str_contains($json,'00000000-0000-4000'));
 $hash=$d['negocios']['por_resultado_motivo'][1]['motivo'];$check('free_reason_is_hmac',str_starts_with($hash,'categoria:')&&strlen($hash)===74);
 $r2=$run(clone $base);$check('stable_category_codes',$r2['data']['negocios']['por_resultado_motivo'][1]['motivo']===$hash);
 $r=$run(clone $base,$input+['criterio_leads'=>'arquivamento']);$check('archive_date_optional',$r['data']['leads']['arquivados_observados']===2);
 $f=clone $base;unset($f->data['/v1/leads/archived'][0]['archive_time']);$r=$run($f,$input+['criterio_leads'=>'arquivamento']);$check('missing_archive_date_no_guess',!$r['data']['completo']&&$r['data']['leads']['arquivados_observados']===1);
 $i=$input;unset($i['limite_plano']);$r=$run(clone $base,$i);$check('unknown_plan_limit_explicit',!$r['data']['completo']&&$r['data']['coleta_completa']&&$r['data']['uso_plano']['limite']===null&&$r['data']['uso_plano']['total']===6);
 $f=clone $base;$f->limit=40;$r=$run($f);$check('budget_partial_zero_for_refusal',!$r['data']['completo']&&$r['data']['custo']['gasto']===40&&$r['data']['uso_plano']['total']===null);
 $r=$run(clone $base,$input+['max_chamadas'=>1]);$check('call_limit_partial',$r['data']['custo']['gasto']===20&&in_array('limite_chamadas',$r['data']['pendencias'],true));
 $f=clone $base;$f->mode='timeout';$r=$run($f);$check('uncertain_cost_range',$r['data']['custo']['gasto']===null&&$r['data']['custo']['maximo']===20&&!str_contains(wp_json_encode($r),'PII_CANARY'));
 $f=clone $base;$f->mode='error';$r=$run($f);$check('error_cost_no_body',$r['data']['custo']['gasto']===20&&!str_contains(wp_json_encode($r),'PII_CANARY'));
 $f=clone $base;$f->mode='slow';$r=$run($f,$input+['tempo_maximo_segundos'=>1]);$check('time_limit_partial',!$r['data']['completo']&&$r['data']['custo']['gasto']===20&&in_array('limite_tempo',$r['data']['pendencias'],true));
 foreach(['malformed','empty_more','loop','revision'] as $mode){$f=clone $base;$f->mode=$mode;$r=$run($f);$check('partial_'.$mode,$r['success']&&!$r['data']['completo']&&$r['data']['custo']['chamadas_tentadas']<20);}
 $f=clone $base;$f->data['/v1/leads'][]=$f->data['/v1/leads'][0];$r=$run($f);$check('dedup_no_overcount',!$r['data']['completo']&&$r['data']['duplicatas']===1&&$r['data']['leads']['abertos_observados']===2&&$r['data']['uso_plano']['total']===null);
 $f=clone $base;$f->data['/v1/dealFields'][0]['name']='missing';$r=$run($f);$check('missing_mapping_partial',!$r['data']['completo']&&$r['data']['campos']['parceiro']['chave']===null);
 $i=$input+['campos'=>['parceiro'=>$keys[0]]];$r=$run($f,$i);$check('explicit_field_mapping',$r['data']['completo']);
 $f=clone $base;$duplicate=$f->data['/v1/dealFields'][0];$duplicate['key']=str_repeat('a',40);$f->data['/v1/dealFields'][]=$duplicate;$r=$run($f);$check('ambiguous_mapping_partial',!$r['data']['completo']&&in_array('campo_ambiguo_parceiro',$r['data']['pendencias'],true));
 $r=$run($f,$i);$check('explicit_resolves_ambiguity',$r['data']['completo']);
 $f=clone $base;$f->data['/v1/dealFields'][0]['field_type']='people';$r=$run($f);$check('person_field_not_reported',!$r['data']['completo']&&$r['data']['campos']['parceiro']['chave']===null);
 $f=clone $base;$f->data['/v1/dealFields'][0]['field_type']='text';$f->data['/v1/leads'][0][$keys[0]]='PII_CANARY_PERSON';$r=$run($f);$check('custom_text_not_reflected',!str_contains(wp_json_encode($r),'PII_CANARY'));
 $f=clone $base;$f->data['/v1/dealFields'][0]['field_type']='set';$f->data['/v1/leads'][0][$keys[0]]='1,2';$f->data['/v1/leads'][1][$keys[0]]=[2,1];$r=$run($f);$check('set_order_does_not_double_count',$r['data']['leads']['grupos'][0]['quantidade']===2&&$r['data']['leads']['grupos'][0]['parceiro']==='conjunto:opcao:1,opcao:2');
 $f=clone $base;$f->data['/v1/leads'][0]['add_time']='2026-02-30 12:00:00';$r=$run($f);$check('invalid_record_date_partial',!$r['data']['completo']);
 $f=clone $base;$f->data['/v1/leads'][0]['is_archived']=true;$r=$run($f);$check('concurrent_state_mismatch_partial',!$r['data']['completo']&&$r['data']['uso_plano']['total']===null);
 $f=clone $base;foreach(array_keys($f->data) as $p)if($p!=='/v1/dealFields')$f->data[$p]=[];$f->mode='null';$r=$run($f);$check('empty_account_zero',$r['data']['completo']&&$r['data']['uso_plano']['total']===0);
 $f=clone $base;$f->data['/v1/leads']=[];for($n=1;$n<=220;$n++){$row=$lead($n,'2026-10-01T12:00:00Z');$row[$keys[0]]='unique-'.$n;$f->data['/v1/leads'][]=$row;}$r=$run($f,$input+['max_chamadas'=>120]);$check('bounded_output',!$r['data']['completo']&&strlen(wp_json_encode($r))<60000);
 foreach([['data_inicio'=>'2026-02-30'],['fuso'=>'bad/zone'],['data_inicio'=>'2026-11-01'],['max_chamadas'=>121],['campos'=>['parceiro'=>'title']],['unknown'=>true],['limite_plano'=>0]] as $n=>$bad){$r=$run(clone $base,array_replace($input,$bad));$check('invalid_input_'.$n,!$r['success']&&$r['code']==='entrada_invalida');}
 $f=clone $base;$f->allowed=false;$r=$run($f);$check('core_refused_before_http',!$r['success']&&count($f->requests)===0);
 wp_set_current_user(0);$r=Api::dispatch('relatorio',$input);$check('anonymous_refused',$r['code']==='nao_autorizado');wp_set_current_user(1);
 $meta=wp_get_ability('pipedrive/relatorio')->get_meta();$check('read_metadata',$meta['annotations']['readonly']&&$meta['fator3']['remote_effect']==='read'&&$meta['fator3']['local_effect']==='none');
 $f=clone $base;$property->setValue(null,$f);$request=new WP_REST_Request('GET','/f3-pipedrive/v1/relatorio');$request->set_query_params($input);$rest=rest_do_request($request);$check('rest_get_report',$rest->get_data()['data']['completo']??false);
 $check('fixed_core_context',count($f->requests)>0&&array_reduce($f->requests,static fn($ok,$req)=>$ok&&$req[0]==='GET'&&$req[3]===[]&&$req[4]['consumer']==='operacao'&&$req[4]['provider']==='wp-mcp-pipedrive-fator3',true));
 $check('no_tables_or_retention_changed',$tables()===$before);
 $check('no_real_http',$http===0);
}finally{$property->setValue(null,$original);remove_filter('pre_http_request',$block,999);wp_set_current_user($actor);}
return ['checks'=>$checks,'passed'=>count(array_filter($checks,static fn($c)=>$c['passed'])),'failed'=>count(array_filter($checks,static fn($c)=>!$c['passed'])),'supplier_http'=>$http];
