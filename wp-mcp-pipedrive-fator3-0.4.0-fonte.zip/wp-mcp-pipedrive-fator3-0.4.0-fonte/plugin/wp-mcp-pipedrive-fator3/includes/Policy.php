<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

final class Policy {
    private const UUID = '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}';
    private const INT = '[1-9][0-9]{0,15}';
    public static function route(string $method, string $path, array $query = [], array $body = []): array {
        if (strlen($path)>200 || !preg_match('~^/(v1|api/v2)/[A-Za-z0-9/-]+$~D',$path) || str_contains($path,'//') || str_contains(strtolower($path),'merge')) { self::deny(); }
        self::reserved($query); self::reserved($body);
        $row = null; $id = null; $resource = null;
        if (preg_match('~^/v1/(leads|leadLabels)/('.self::UUID.')$~D',$path,$m)) {
            $resource=$m[1];$id=$m[2];
        } elseif (preg_match('~^/v1/(dealFields|personFields|organizationFields|filters|notes)/('.self::INT.')$~D',$path,$m)) {
            $resource=$m[1];$id=$m[2];
        } elseif (preg_match('~^/api/v2/(deals|persons|organizations|activities)/('.self::INT.')$~D',$path,$m)) {
            $resource=$m[1];$id=$m[2];
        }
        $isField = in_array($resource,['dealFields','personFields','organizationFields'],true);
        if ($method==='GET') {
            $params=[];
            if ($id && in_array($resource,['leads','notes','filters','deals','persons','organizations','activities'],true)) { $row=true; }
            elseif (in_array($path,['/v1/leads','/v1/leads/archived'],true)) { $row=true;$params=['filter_id','limit','start']; }
            elseif (in_array($path,['/v1/dealFields','/v1/personFields','/v1/organizationFields','/v1/activityFields','/v1/noteFields'],true)) { $row=true;$params=['limit','start']; }
            elseif ($path==='/v1/notes') { $row=true;$params=['lead_id','deal_id','person_id','org_id','limit','start']; }
            elseif ($path==='/v1/filters') { $row=true;$params=['type']; }
            elseif (in_array($path,['/v1/leadLabels','/v1/activityTypes','/v1/users/me'],true)) { $row=true; }
            elseif (in_array($path,['/api/v2/activities'],true)) { $row=true;$params=['lead_id','deal_id','limit','cursor']; }
            elseif (in_array($path,['/api/v2/persons','/api/v2/organizations','/api/v2/pipelines','/api/v2/stages','/api/v2/deals','/api/v2/deals/archived'],true)) { $row=true;$params=['limit','cursor']; }
            if (!$row || $body || array_diff(array_keys($query),$params)) { self::deny(); }
            self::query($query);
            return ['classe'=>'leitura','resource'=>$resource,'id'=>$id,'metodo'=>$method,'caminho'=>$path,'query'=>$query,'corpo'=>[]];
        }
        if ($query) { self::deny(); }
        $class='registro';$keys=[];$required=[];
        if ($resource==='leads' && $id && $method==='PATCH') {
            $keys=['title','owner_id','label_ids','person_id','organization_id','value','expected_close_date','visible_to','was_seen','is_archived','archive_reason','origin_id','channel','channel_id'];
            foreach (array_keys($body) as $k) { if (preg_match('/^[a-f0-9]{40}(?:_(?:currency|start|end|until))?$/D',(string)$k)) { $keys[]=$k; } }
        } elseif ($resource==='notes' && $id && $method==='PUT') {
            $keys=['content','pinned_to_deal_flag','pinned_to_person_flag','pinned_to_organization_flag','pinned_to_lead_flag'];
        } elseif ($id && $method==='DELETE' && in_array($resource,['leads','persons','organizations','deals','notes','activities'],true)) {
            $keys=[];
        } else {
            $class='estrutura';
            if (preg_match('~^/v1/(dealFields|personFields|organizationFields)$~D',$path,$m) && $method==='POST') {
                $resource=$m[1];$keys=['name','field_type','options'];$required=['name','field_type'];
            } elseif ($isField && $id && $method==='PUT') { $keys=['name','options','remover_opcoes']; }
            elseif ($isField && $id && $method==='DELETE') { $keys=[]; }
            elseif ($path==='/v1/filters' && $method==='POST') { $resource='filters';$keys=['name','conditions','type'];$required=$keys; }
            elseif ($resource==='filters' && $id && $method==='PUT') { $keys=['name','conditions']; }
            elseif ($resource==='filters' && $id && $method==='DELETE') { $keys=[]; }
            elseif ($path==='/v1/leadLabels' && $method==='POST') { $resource='leadLabels';$keys=['name','color'];$required=$keys; }
            elseif ($resource==='leadLabels' && $id && $method==='PATCH') { $keys=['name','color']; }
            elseif ($resource==='leadLabels' && $id && $method==='DELETE') { $keys=[]; }
            else { self::deny(); }
        }
        if (array_diff(array_keys($body),$keys)) { self::deny(); }
        if (array_diff($required,array_keys($body)) || ($method!=='DELETE' && !$body)) { throw new Fault('corpo_invalido','Preencha os campos obrigatórios da operação.'); }
        self::body($body,$resource,$method);
        if($resource==='leads'&&array_key_exists('archive_reason',$body))Configuration::reason('archive_reasons',$body['archive_reason']);
        if($resource==='leads'&&($body['is_archived']??false)===true&&!isset($body['archive_reason']))throw new Fault('motivo_invalido','Arquivar exige motivo da lista aprovada.');
        $reversible = $class==='registro' || $method==='POST' || ($method!=='DELETE' && empty($body['remover_opcoes']));
        return ['classe'=>$class,'resource'=>$resource,'id'=>$id,'metodo'=>$method,'caminho'=>$path,'query'=>[],
            'corpo'=>$body,'se_desfaz'=>$reversible,'reversao'=>$method==='DELETE'&&$class==='registro'?'Verifique a lixeira e o prazo de recuperação da conta antes de excluir. Este plugin não restaura registros.':($reversible?'Exige outra operação explícita; não há reversão automática.':'Pode apagar valores ou estrutura permanentemente.')];
    }
    public static function deny(): never { throw new Fault('caminho_fora_da_lista','Caminho, método ou parâmetro fora da lista permitida.'); }
    private static function reserved(array $value): void {
        foreach ($value as $k=>$v) {
            if (is_string($k) && preg_match('/^(?:ids|api_token|access_token|token|authorization|headers|url|host)$/i',$k)) { self::deny(); }
            if (is_array($v)) { self::reserved($v); }
        }
    }
    private static function query(array $q): void {
        foreach ($q as $key=>$v) {
            if ($key==='cursor') { if (!is_string($v)||strlen($v)>1024||preg_match('/[\x00-\x20]/',$v)) { self::deny(); } }
            elseif ($key==='type') { if (!in_array($v,['deals','leads','people','org','activity','products','projects'],true)) { self::deny(); } }
            elseif ($key==='lead_id') { if (!is_string($v)||!preg_match('~^'.self::UUID.'$~D',$v)) { self::deny(); } }
            elseif (!is_int($v) || $v<($key==='start'?0:1) || ($key==='limit' && $v>500)) { self::deny(); }
        }
    }
    private static function body(array $b, ?string $resource, string $method): void {
        if (strlen(Support::json($b))>65536) { throw new Fault('corpo_excedeu_limite','O corpo deve ter no máximo 64 KiB.'); }
        foreach ($b as $k=>$v) {
            if (in_array($k,['name','title','color','field_type','archive_reason','origin_id','channel_id','expected_close_date','content'],true)) {
                if (!is_string($v) || ($v==='' && in_array($k,['name','title','field_type','color'],true)) || strlen($v)>($k==='content'?60000:4000)) { throw new Fault('corpo_invalido','Tipo ou tamanho de campo inválido.'); }
            }
            if (in_array($k,['owner_id','person_id','organization_id','channel'],true) && $v!==null && (!is_int($v)||$v<1)) { throw new Fault('corpo_invalido','Identificador deve ser inteiro positivo ou null quando admitido pelo fornecedor.'); }
            if (in_array($k,['was_seen','is_archived'],true) && !is_bool($v)) { throw new Fault('corpo_invalido','Informe booleano para flags do lead.'); }
            if (str_starts_with((string)$k,'pinned_to_') && !in_array($v,[0,1,true,false],true)) { throw new Fault('corpo_invalido','A fixação da nota aceita 0 ou 1.'); }
        }
        if (isset($b['label_ids'])) {
            if (!is_array($b['label_ids']) || !array_is_list($b['label_ids'])) { throw new Fault('corpo_invalido','label_ids deve ser uma lista.'); }
            foreach ($b['label_ids'] as $id) { if (!is_string($id)||!preg_match('~^'.self::UUID.'$~D',$id)) { throw new Fault('corpo_invalido','Etiqueta exige UUID válido.'); } }
        }
        if (array_key_exists('value',$b) && $b['value']!==null) {
            $v=$b['value'];
            if (!is_array($v)||array_diff(array_keys($v),['amount','currency'])||!is_numeric($v['amount']??null)||!is_string($v['currency']??null)||!preg_match('/^[A-Z]{3}$/D',$v['currency'])) { throw new Fault('corpo_invalido','Valor exige amount e currency ISO de três letras.'); }
        }
        if (isset($b['expected_close_date']) && !preg_match('/^\d{4}-\d{2}-\d{2}$/D',$b['expected_close_date'])) { throw new Fault('corpo_invalido','Data esperada deve usar AAAA-MM-DD.'); }
        if (isset($b['visible_to']) && !in_array($b['visible_to'],['1','3','5','7'],true)) { throw new Fault('corpo_invalido','Visibilidade inválida.'); }
        if (isset($b['color']) && !in_array($b['color'],['blue','brown','dark-gray','gray','green','orange','pink','purple','red','yellow'],true)) { throw new Fault('corpo_invalido','Cor de etiqueta inválida.'); }
        if (isset($b['field_type']) && !in_array($b['field_type'],['varchar','varchar_auto','text','enum','set','date','daterange','time','timerange','double','monetary','address','phone','user','org','people'],true)) { throw new Fault('corpo_invalido','Tipo de campo não permitido.'); }
        if (isset($b['options'])) {
            if (!is_array($b['options']) || !array_is_list($b['options'])) { throw new Fault('corpo_invalido','options deve ser lista de objetos.'); }
            $seen=[];
            foreach ($b['options'] as $o) {
                if (!is_array($o)||array_diff(array_keys($o),['id','label','color'])||!is_string($o['label']??null)||$o['label']==='') { throw new Fault('corpo_invalido','Opção exige label e aceita id existente.'); }
                if (isset($o['id'])) {
                    if (!is_int($o['id'])||$o['id']<1||isset($seen[$o['id']])||$method==='POST') { throw new Fault('corpo_invalido','ID de opção inválido, repetido ou indevido na criação.'); }
                    $seen[$o['id']]=true;
                }
            }
        }
        if (array_key_exists('remover_opcoes',$b)) {
            if (!isset($b['options'])||!is_array($b['remover_opcoes'])||!array_is_list($b['remover_opcoes'])) { throw new Fault('corpo_invalido','remover_opcoes exige options e uma lista de IDs.'); }
            foreach ($b['remover_opcoes'] as $id) { if (!is_int($id)||$id<1) { throw new Fault('corpo_invalido','ID de remoção inválido.'); } }
            if (count(array_unique($b['remover_opcoes']))!==count($b['remover_opcoes'])) { throw new Fault('corpo_invalido','IDs repetidos na remoção.'); }
        }
        if (isset($b['conditions'])) { self::conditions($b['conditions']); }
        if (isset($b['type']) && !in_array($b['type'],['deals','leads','people','org','activity','products','projects'],true)) { throw new Fault('corpo_invalido','Tipo de filtro inválido.'); }
    }
    private static function conditions($c, int $depth=0): void {
        if (!is_array($c)||$depth>3) { throw new Fault('corpo_invalido','Condições de filtro inválidas.'); }
        if (isset($c['conditions'])) {
            if (array_diff(array_keys($c),['glue','conditions'])||!in_array($c['glue']??null,['and','or'],true)||!is_array($c['conditions'])||!array_is_list($c['conditions'])) { throw new Fault('corpo_invalido','Grupo de filtro exige glue e conditions.'); }
            foreach ($c['conditions'] as $child) { self::conditions($child,$depth+1); }
        } elseif (array_diff(array_keys($c),['object','field_id','operator','value','extra_value']) || !isset($c['object'],$c['field_id'],$c['operator']) || !array_key_exists('value',$c)) {
            throw new Fault('corpo_invalido','Condição exige object, field_id, operator e value.');
        }
    }
    public static function removals(array $route, array $current): array {
        if ($route['metodo']!=='PUT' || !in_array($route['resource'],['dealFields','personFields','organizationFields'],true)) { return []; }
        $body=$route['corpo'];
        if (!array_key_exists('options',$body)) { return []; } // Omission preserves existing options in Pipedrive.
        if (!isset($current['options']) || !is_array($current['options'])) { throw new Fault('estado_incompleto','A lista atual de opções não foi fornecida; escrita recusada.'); }
        $old=[];
        foreach ($current['options'] as $o) {
            if (!is_array($o)||!isset($o['id'],$o['label'])||!is_numeric($o['id'])) { throw new Fault('estado_incompleto','Opção atual ilegível.'); }
            $old[(int)$o['id']]=['id'=>(int)$o['id'],'label'=>(string)$o['label']];
        }
        $kept=[];
        foreach ($body['options'] as $o) {
            if (isset($o['id'])) {
                if (!isset($old[$o['id']])) { throw new Fault('opcao_desconhecida','O corpo contém ID de opção que não pertence ao campo.'); }
                $kept[]=$o['id'];
            }
        }
        $missing=array_values(array_diff(array_keys($old),$kept));sort($missing);
        $explicit=$body['remover_opcoes']??[];sort($explicit);
        if ($missing!==$explicit) { throw new Fault('opcao_seria_apagada','A lista remover_opcoes deve corresponder exatamente às opções omitidas.', ['opcoes'=>array_values(array_intersect_key($old,array_flip($missing)))]); }
        return array_values(array_intersect_key($old,array_flip($missing)));
    }
}
