<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
final class Documentation {
    public const DOCUMENTS=['index'=>'README.md','especificacao'=>'SPECIFICATION.md','configuracao'=>'CONFIGURATION.md','uso'=>'USAGE.md',
        'contratos'=>'CONTRACTS.md','agentes'=>'AGENT-GUIDE.md','operacao'=>'OPERATIONS.md','release'=>'CHANGELOG.md','schemas'=>'schemas.json','fluxos'=>'WORKFLOWS.md','regras-iniciais'=>'regras-iniciais.json'];
    public static function read(array $i): array {
        Support::admin();$id=$i['documento']??'index';
        if (!isset(self::DOCUMENTS[$id])) { throw new Fault('documento_invalido','Escolha um ID publicado no índice documental.'); }
        $base=realpath(ROOT.'/docs');$path=realpath(ROOT.'/docs/'.self::DOCUMENTS[$id]);
        if (!$base||!$path||!str_starts_with($path,$base.DIRECTORY_SEPARATOR)||!is_file($path)) { throw new Fault('documento_indisponivel','Documento local indisponível.'); }
        $text=file_get_contents($path);
        if ($text===false) { throw new Fault('documento_indisponivel','Não foi possível ler o documento.'); }
        $hash=hash('sha256',$text);$offset=$i['offset']??0;$limit=$i['limite_bytes']??16000;
        if ($offset>0 && !isset($i['sha256_esperado'])) { throw new Fault('revisao_exigida','Informe sha256_esperado nas continuações.'); }
        if (isset($i['sha256_esperado']) && !hash_equals($hash,$i['sha256_esperado'])) { throw new Fault('documento_alterado','Documento mudou; reinicie pelo offset zero.'); }
        if ($offset>strlen($text)||($offset<strlen($text)&&$offset>0&&(ord($text[$offset])&0xC0)===0x80)) { throw new Fault('offset_invalido','Offset fora do documento ou no meio de um caractere UTF-8.'); }
        $chunk=mb_strcut($text,$offset,$limit,'UTF-8');$next=$offset+strlen($chunk);
        return ['provider'=>SLUG,'version'=>VERSION,'origem'=>'local','documento'=>$id,'sha256'=>$hash,'total_bytes'=>strlen($text),'offset'=>$offset,
            'conteudo'=>$chunk,'proximo_offset'=>$next<strlen($text)?$next:null,'fim'=>$next>=strlen($text),'ids_permitidos'=>array_keys(self::DOCUMENTS),'limite_maximo_bytes'=>24000];
    }
}
