<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
final class Cadence {
    public static function marker(string $lead,string $touch,int $time,string $key): string {
        $data=$touch.':'.$time.':'.hash('sha256',$key);
        return '[F3PD1:'.$data.':'.hash_hmac('sha256',$lead.':'.$data,wp_salt('auth')).']';
    }
    public static function progress(array $lead,?array $activity,array $c): array {
        $n=-1;$last=null;$codes=array_column($c['toques'],'codigo');
        foreach($c['toques'] as $i=>$t)if($t['etiqueta_id']!==''&&in_array($t['etiqueta_id'],$lead['label_ids']??[],true))$n=max($n,$i);
        $note=(string)($activity['note']??'');
        preg_match_all('/\[F3PD1:([a-z0-9_-]{1,40}):(\d{10,11}):([a-f0-9]{64}):([a-f0-9]{64})\]/',$note,$matches,PREG_SET_ORDER);
        foreach($matches as $m){$index=array_search($m[1],$codes,true);if($index!==false&&hash_equals(hash_hmac('sha256',$lead['id'].':'.$m[1].':'.$m[2].':'.$m[3],wp_salt('auth')),$m[4])&&$index>=$n){$n=$index;$last=max($last??0,(int)$m[2]);}}
        return ['indice'=>$n+1,'ultimo'=>$last,'ambiguo'=>$note!==''&&$n===-1];
    }
    public static function slot(int $target,array $c): array {
        $zone=new \DateTimeZone($c['fuso']);$day=(new \DateTimeImmutable('@'.$target))->setTimezone($zone)->setTime(0,0);$periods=$c['periodos'];usort($periods,static fn($a,$b)=>strcmp($a['hora'],$b['hora']));
        for($d=0;$d<8;$d++,$day=$day->modify('+1 day')){
            if(!in_array((int)$day->format('N'),$c['dias'],true))continue;
            foreach($periods as $p){[$h,$m]=array_map('intval',explode(':',$p['hora']));$at=$day->setTime($h,$m)->getTimestamp();if($at>=$target)return ['instante'=>$at,'periodo'=>$p['codigo']];}
        }
        throw new Fault('configuracao_invalida','Não há próximo período no calendário.');
    }
    public static function evaluate(array $lead,array $activities,array $c,int $now): array {
        $out=['lead_id'=>$lead['id'],'toque'=>null,'devido_em_utc'=>null,'periodo'=>null,'texto_aprovado'=>null,'devido'=>false,'motivo'=>null];
        if(!$c['habilitada']){$out['motivo']='configuracao_pendente';return $out;}
        if(!empty($lead['is_archived'])){$out['motivo']='lead_arquivado';return $out;}
        if(array_intersect($lead['label_ids']??[],$c['exclusoes']['etiquetas'])){$out['motivo']='etiqueta_excluida';return $out;}
        foreach($c['exclusoes']['campos'] as $rule){$value=Collection::field($lead,$rule['campo']);$values=is_array($value)?$value:[$value];foreach($values as $v)foreach($rule['valores'] as $excluded)if((string)$v===(string)$excluded){$out['motivo']=$rule['regra'];return $out;}}
        $wa=array_values(array_filter($activities,static fn($a)=>(string)($a['lead_id']??'')===(string)$lead['id']&&($a['type']??'')===$c['tipo_whatsapp']));
        if(count($wa)>1){$out['motivo']='atividade_whatsapp_duplicada';return $out;}
        $a=$wa[0]??null;if($a&&!empty($a['done'])){$out['motivo']='atividade_concluida';return $out;}
        $progress=self::progress($lead,$a,$c);$index=$progress['indice'];
        if($progress['ambiguo']){$out['motivo']='historico_sem_marcador';return $out;}
        if(!isset($c['toques'][$index])){$out['motivo']='cadencia_concluida';return $out;}
        $t=$c['toques'][$index];$base=$t['base']==='entrada'?Collection::instant($lead['add_time']??null):$progress['ultimo'];
        if($base===null){$out['motivo']='instante_base_indisponivel';return $out;}
        $slot=self::slot($base+$t['atraso_minutos']*60,$c);$text=array_column($c['textos'],'texto','codigo');
        $local=(new \DateTimeImmutable('@'.$now))->setTimezone(new \DateTimeZone($c['fuso']));$within=in_array((int)$local->format('N'),$c['dias'],true)&&$local->format('H:i')>=$c['janela']['inicio']&&$local->format('H:i')<=$c['janela']['fim'];
        $out['toque']=$t['codigo'];$out['periodo']=$slot['periodo'];$out['devido_em_utc']=gmdate('Y-m-d\TH:i:s\Z',$slot['instante']);$out['texto_aprovado']=$text[$t['texto_id']];$out['devido']=$within&&$slot['instante']<=$now;$out['motivo']=$out['devido']?null:($within?'aguardando_prazo':'fora_da_janela');return $out;
    }
    public static function queue(array $i,?array $candidate=null): array {
        $cfg=Configuration::read();$c=$candidate??$cfg['regras'];$reader=new Collection($i);$now=isset($i['agora'])?Collection::instant($i['agora']):time();if($now===null)throw new Fault('entrada_invalida','agora deve ser RFC3339 UTC.');
        $leads=$reader->all('/v1/leads');$activities=$c['habilitada']?$reader->all('/api/v2/activities'):[];
        foreach($activities as &$a){if(($a['type']??'')===$c['tipo_whatsapp']&&!array_key_exists('note',$a)){try{$a=$reader->one('/api/v2/activities/'.(int)$a['id']);}catch(Fault $e){$reader->issues[]=$e->reason;}}}unset($a);
        $out=[];foreach($leads as $lead){if(count($out)>=200){$reader->issues[]='limite_de_saida';break;}$row=self::evaluate($lead,$activities,$c,$now);if(!$c['habilitada'])$row['motivo']='configuracao_pendente';$out[]=$row;}
        if($reader->issues)foreach($out as &$row){$row['devido']=false;$row['texto_aprovado']=null;$row['motivo']='coleta_incompleta';}unset($row);
        return $reader->result(['itens'=>$out,'revisao'=>$cfg['revisao'],'simulada'=>$candidate!==null,'agora_utc'=>gmdate('Y-m-d\TH:i:s\Z',$now)]);
    }
}
