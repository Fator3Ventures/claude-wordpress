<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
final class Insights {
    public static function count(array $i): array {
        $r=new Collection($i);$type=$i['entidade'];$field=$i['campo'];
        $map=['leads'=>['/v1/dealFields','/v1/leads','/v1/leads/archived'],'negocios'=>['/v1/dealFields','/api/v2/deals','/api/v2/deals/archived'],'pessoas'=>['/v1/personFields','/api/v2/persons'],'organizacoes'=>['/v1/organizationFields','/api/v2/organizations']];
        $paths=$map[$type];$catalog=$r->all(array_shift($paths));$r->complete();$found=null;foreach($catalog as $f)if(($f['key']??$f['field_code']??null)===$field)$found=$f;
        if(!$found)throw new Fault('campo_indisponivel','Campo não encontrado no catálogo da entidade.');
        $seen=[];$groups=[];$total=0;$empty=0;
        foreach($paths as $path)foreach($r->all($path) as $row){$id=(string)$row['id'];if(isset($seen[$id])){$r->issues[]='colecao_concorrente';continue;}$seen[$id]=true;++$total;$v=Collection::field($row,$field);
            if($v===null||$v===''||$v===[]){$key='vazio';++$empty;}
            elseif(in_array($found['field_type']??'',['enum','set'],true)){
                $values=is_array($v)?$v:explode(',',(string)$v);$ids=[];foreach($values as $value){if(is_array($value))$value=$value['id']??null;if(!is_scalar($value)||!ctype_digit((string)$value)){$r->issues[]='opcao_ilegivel';continue 2;}$ids[]=(int)$value;}sort($ids);foreach(array_unique($ids) as $oid){$code='opcao:'.$oid;$groups[$code]=($groups[$code]??0)+1;}continue;
            }else{$key='categoria:'.hash_hmac('sha256',Support::json([$r->status['conta'],$type,$field,$v]),wp_salt('auth'));}
            $groups[$key]=($groups[$key]??0)+1;
        }
        ksort($groups);if(count($groups)>200){$r->issues[]='limite_de_grupos';$groups=array_slice($groups,0,200,true);}
        $out=[];foreach($groups as $key=>$n)$out[]=['valor'=>$key,'quantidade'=>$n];
        return $r->result(['entidade'=>$type,'campo'=>$field,'grupos'=>$out,'total_observado'=>$total,'vazios'=>$empty,'arquivados_incluidos'=>in_array($type,['leads','negocios'],true),'semantica_multiplos'=>'Cada opção conta uma vez por registro; a soma de múltipla escolha pode exceder total_observado.','arquivo_contatos'=>'Pessoas e organizações não possuem coleção de arquivo nesta API; registros excluídos não entram.']);
    }
    public static function audit(array $i): array {
        $r=new Collection($i);$cfg=Configuration::read();$c=$cfg['regras']['auditoria'];$now=isset($i['agora'])?Collection::instant($i['agora']):time();if($now===null)throw new Fault('entrada_invalida','Instante inválido.');
        $leads=$r->all('/v1/leads');$deals=$r->all('/api/v2/deals');$activities=$r->all('/api/v2/activities');$orgs=$r->all('/api/v2/organizations');$people=$r->all('/api/v2/persons');
        $orgs=array_column($orgs,null,'id');$people=array_column($people,null,'id');$out=[];$emit=static function($entity,$id,$rule)use(&$out,$r){if(count($out)>=1000){$r->issues[]='limite_de_saida';return;}$out[]=['entidade'=>$entity,'id'=>$id,'regra'=>$rule];};
        if(count($c['campos_origem'])!==4)$r->issues[]='quatro_campos_origem_nao_configurados';
        if($c['separador_titulo']==='')$r->issues[]='regra_titulo_nao_configurada';
        foreach($leads as $lead){$id=$lead['id'];foreach($c['campos_origem'] as $j=>$key){$v=Collection::field($lead,$key);if($v===null||$v===''||$v===[])$emit('lead',$id,'origem_ausente_'.($j+1));}
            $next=false;foreach($activities as $a)if(($a['lead_id']??null)===$id&&empty($a['done'])&&!empty($a['due_date']))$next=true;if(!$next)$emit('lead',$id,'sem_proxima_atividade');
            if($c['separador_titulo']!==''){$parts=explode($c['separador_titulo'],(string)($lead['title']??''));if(count($parts)!==2||trim($parts[0])===''||trim($parts[1])==='')$emit('lead',$id,'titulo_fora_do_padrao');}
            $oid=$lead['organization_id']??null;$pid=$lead['person_id']??null;if(is_array($oid))$oid=$oid['value']??$oid['id']??null;if(is_array($pid))$pid=$pid['value']??$pid['id']??null;
            if($oid&&$pid){if(!isset($orgs[$oid],$people[$pid]))$r->issues[]='contato_vinculado_nao_visivel';else{$a=mb_strtolower(trim((string)($orgs[$oid]['name']??'')));$b=mb_strtolower(trim((string)($people[$pid]['name']??'')));if($a!==''&&$a===$b)$emit('organizacao',$oid,'nome_igual_pessoa');}}
        }
        if(!$c['etapas'])$r->issues[]='alertas_etapas_nao_configurados';$stages=array_column($c['etapas'],null,'id');
        foreach($deals as $d){if(($d['status']??'')!=='open')continue;$s=$stages[$d['stage_id']??0]??null;if(!$s){$r->issues[]='etapa_sem_regra';continue;}$last=Collection::instant($d['stage_change_time']??null);if($last===null){$r->issues[]='data_etapa_indisponivel';}elseif($now-$last>$s['alerta_minutos']*60)$emit('negocio',$d['id'],'etapa_sem_avanco');
            if($s['primeira'])foreach($activities as $a){if((string)($a['deal_id']??'')!==(string)$d['id']||!in_array($a['type']??'',$c['tipos_reuniao'],true))continue;$due=Collection::instant(($a['due_date']??'').' '.($a['due_time']??'23:59:59'));if($due!==null&&$due<$now){$emit('negocio',$d['id'],'reuniao_vencida_primeira_etapa');break;}}
        }
        $out=array_values(array_unique($out,SORT_REGULAR));return $r->result(['itens'=>$out,'revisao'=>$cfg['revisao'],'agora_utc'=>gmdate('Y-m-d\TH:i:s\Z',$now)]);
    }
}
