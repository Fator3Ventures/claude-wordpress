> Versão corrente 0.4.0: consulte também `pipedrive/documentacao-ler {"documento":"fluxos"}` para pedidos 4–9, regras, novas rotas e limites. As listas de motivos substituem o aceite irrestrito anterior de archive_reason.

# Operação e recuperação — 0.4.0

Sem cron, fila, webhook ou HTTP próprio. Desativação e desinstalação não chamam a API e preservam as tabelas.

## Armazenamento

`{prefix}f3_pipedrive_operations`: chave de 32 hexadecimais, aleatória para prévias e derivada de HMAC para mensagens, administrador, digest de site/conta/revisão, estado ready/running/done/expired, prazos, payload e result cifrados AES-256-GCM. A prévia guarda corpo a enviar e hash do estado atual, sem persistir a cópia integral do estado lido. Payload removido ao concluir; pendentes expirados são esvaziados na próxima operação de manutenção sob demanda. Recibos comuns cifrados duram 180 dias para reprodução idêntica; os de WhatsApp não têm expurgo automático. Os salts WordPress são necessários para decifrar.

`{prefix}f3_pipedrive_journal`: ID sequencial, previa_id único, instante UTC e metadados. Caminho com IDs, classe, status, chaves e saldo; nomes/opções de estrutura permitidos. Nenhum conteúdo de nota ou valor de campo pessoal é gravado no diário. O recibo privado cifrado é separado da auditoria; ele pode conter a resposta privada do fornecedor, necessária à repetição exata.

O diário tem **retenção sem prazo por padrão**: a limpeza de recibos vencidos não remove sua linha. Uma escolha explícita de 1–36.500 dias habilita expurgo do diário pelo instante UTC original; 0 desabilita esse expurgo. Configuração pelo painel ou retencao-configurar com revisão e confirmação para prazo finito. status.data.retencao e retencao-ler mostram a política efetiva. Salvar altera somente a política; os dados não são excluídos nessa chamada.

Recibos comuns mantêm retenção de 180 dias contados da criação da prévia, independentemente do diário. Recibos de mensagem WhatsApp são permanentes para impedir duplicação futura. Após remover um recibo, previa_id deixa de poder reproduzir a resposta; isso não impede consultar sua linha técnica preservada. Nunca usar recibo vencido como justificativa para repetir uma mutação. Reconcilie o fornecedor antes de nova intenção.

Limpeza sob demanda em prévia/aplicação, sem agendamento. Sem novas escritas, dados vencidos podem permanecer fisicamente. Tentativas running e suas linhas são preservadas para reconciliação mesmo com prazo finito; seu payload expirado é esvaziado na limpeza. Leitura de ajuda/status/registro/política não aciona reparo ou limpeza. Configuração e limpeza compartilham trava por banco/tabela de options; indisponibilidade da trava recusa a operação conservadoramente.

## Uma tentativa por prévia

UPDATE condicional ready→running e INSERT único na auditoria são confirmados em transação InnoDB antes do despacho. Duas execuções não podem adquirir a mesma prévia. Depois da chamada, recibo e auditoria são concluídos em outra transação. Falha de confirmação mantém a operação conservadoramente incerta. Nunca resetar running para ready para tentar novamente.

Falha entre a aquisição e o HTTP também fica incerta: a segurança contra duplicação tem prioridade. Reconciliar no fornecedor e registrar decisão administrativa fora do plugin antes de nova operação. Não há ferramenta de desbloqueio automático ou replay forçado.

## Instalação e reversão

Base direta aceita: 0.2.0. A atualização não executa expurgo, não regrava datas/linhas e não exige migração destrutiva. Sem a option de retenção, vale o padrão sem prazo; a escolha explícita posterior permanece em reativação/reinstalação. O schema das duas tabelas continua 1. Instalação limpa usa dbDelta e exige InnoDB; leituras não reparam tabelas ausentes.

Antes de trocar arquivos, preservar banco e salts. Restaurar arquivos não restaura valores apagados, opções, conta, quota nem chamadas externas. Desinstalar preserva os registros; remoção de tabelas exige decisão administrativa separada. Não executar DROP em tabelas de outros plugins nem apagar o banco compartilhado.

Core compatível continua responsável por autorização, credencial e orçamento. A atualização não liga operação comercial.

**Alerta histórico sobre volta para 0.1.0 (fora da base desta rodada):** o código antigo ignora a nova política e pode excluir diário com mais de 180 dias na próxima prévia/aplicação. Para preservar histórico, interrompa operações antes de voltar e mantenha backup do banco; prefira correção adiante. O backup de arquivos não restaura linhas apagadas. Ampliar o prazo não recupera exclusões anteriores.

## Funcionalidade herdada da 0.3.0

Atualização direta 0.3.0 → 0.4.0 não migra banco/opções nem expurga diário. Nova leitura não chama Store::cleanup. Reversão para 0.3.0 remove as dez rotas novas, mantém relatorio e preserva armazenamento. Prévia anterior pode exigir nova criação porque versão integra a revisão do cliente Core; não repetir escrita incerta. Relatório é síncrono, limitado e sem retomada; não configura jobs. Veja USAGE.md para custo e parciais.

## Versão 0.4.0
Operações compostas com prévia, regras em option e recibo por etapa. Sem retry automático de efeitos incertos.
