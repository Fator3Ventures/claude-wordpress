# Operações e regras — 0.4.0

Pedidos MCP Pipedrive 4–9, 28/10/2026. Todas as rotas exigem administrador, via MCP ou REST `f3-pipedrive/v1`. Há 19 rotas: nove preservadas e dez novas. Consulte `schemas` para os tipos completos. Sem cron, envio de WhatsApp, token ou transporte HTTP próprio.

## Configuração e simulação

`pipedrive/configuracao-ler {}` retorna `regras`, `revisao` e `origem`. A ausência de option não grava defaults. A cadência começa desabilitada; horários, dias, textos, tipos e IDs reais não foram presumidos. A lista inicial de arquivamento é exatamente a do pedido 6. A lista de perda começa vazia porque a referência comercial não veio nos anexos.

Preencha o objeto inteiro `regras` segundo o schema e chame `configuracao-simular` com `revisao_esperada` e, opcionalmente, `agora` RFC3339 UTC. A simulação lê a conta no orçamento operacao, não modifica a conta nem salva regras. Coleta parcial não gera prévia aplicável. Retorna fila, regras candidatas, `previa_id` por 15 minutos e `confirmacao_exigida`. Revise os dados; após ordem do dono use `operacao-aplicar` com esse ID e a frase literal. Alterar motivos também exige esse fluxo. Revisão divergente recusa a gravação; repetição de uma aplicação concluída devolve recibo. A configuração fica na option `f3_pipedrive_operation_rules`, JSON não autoload. Não a edite por SQL/rotas genéricas: isso perde a guarda de simulação.

`fuso` é IANA. `dias` usa ISO 1=segunda a 7=domingo. `janela` começa e termina no mesmo dia. Cada `periodo` possui código e hora dentro dela. O próximo vencimento é o primeiro horário de período igual ou posterior à base mais o prazo, respeitando dias úteis configurados. `toques` é uma sequência, cada um com código, prazo em minutos, base `entrada` (add_time do lead) ou `ultimo_registro`, texto_id e etiqueta_id opcional. Não há regra comercial de 30 minutos, 28 horas ou dias da semana fixa no PHP.

`textos` contém mensagens aprovadas sem interpolação de nomes, telefones ou e-mails. `exclusoes.etiquetas` contém UUIDs; `exclusoes.campos` aceita campo, valores exatos e código da regra, servindo para unidade, ponto de conversão, canal e outros campos mapeados. Valores numéricos são comparados pela representação textual. A aplicação apenas salva parâmetros; não cria etiquetas, atividades ou campos.

`auditoria.campos_origem` deve conter as quatro chaves reais; `separador_titulo` representa a separação esperada entre Empresa e Unidade; `etapas` contém ID, alerta_minutos e primeira; `tipos_reuniao` contém os tipos da conta. A auditoria sinaliza configuração ausente ou etapa não mapeada como cobertura incompleta. Não presume o significado de nomes comerciais de campos.

## Fila e registros de WhatsApp

`cadencia-fila` aceita `agora`, max_chamadas (1–120, padrão100), tempo_maximo_segundos (1–120, padrão45). Retorna IDs, próximo toque, devido_em_utc, período, texto_aprovado e motivo. Fora da janela, exclusões, atividade concluída, duplicidade ou histórico desconhecido impedem envio devido. Texto aprovado vem exclusivamente da option. Campos da conta como nome, telefone, e-mail e título não saem na fila.

Progresso é reconhecido por marcadores HMAC escritos pelo plugin na nota da atividade ou etiquetas explicitamente configuradas. Uma atividade antiga com nota e sem marcador/etiqueta reconhecido resulta `historico_sem_marcador`; ela não é reinterpretada por heurística. Etiqueta de toque indica toque já concluído; ela sozinha não fornece o instante para `ultimo_registro`. Preservar salts mantém os marcadores verificáveis. Trocar códigos de toques pode exigir mapeamento explícito do histórico.

`whatsapp-registrar` recebe `lead_id` UUID, `mensagem`, `toque` e `chave_idempotencia` (8–128 caracteres). Use somente depois de confirmar o envio por seu canal: este plugin registra, não envia. O toque deve ser o próximo reconhecido. Consulta todas as atividades do lead, considera o tipo exato `tipo_whatsapp`, recusa mais de uma e não cria outra se uma já existe. Acrescenta uma linha escapada à nota e programa a atividade em UTC para o próximo período, observando o prazo do toque seguinte. Depois do último toque, programa o próximo período para revisão; a fila retorna cadencia_concluida e não inventa mensagem adicional. Atividade já concluída não é reaberta automaticamente.

A mesma chave na mesma conta retorna o recibo, sem nova escrita. Outro corpo com a chave é conflito. Os recibos de mensagem não têm expurgo automático, independentemente dos 180 dias dos recibos comuns. A retenção do diário continua separada. Chaves são representadas por HMAC local; conteúdo de mensagem nunca entra no diário. Recibos pertencem ao administrador original e à conta/revisão Core; uma mudança de contexto bloqueia reuso, exigindo reconciliação. A unicidade é serializada entre operações cooperantes deste plugin; agentes escrevendo diretamente no fornecedor ou por outros plugins não compartilham essa trava. Reconsulta após criação detecta duplicidade concorrente, sem apagar atividade alheia.

## Prévias de encerramento, perda e edição arquivada

`lead-encerrar {lead_id,mensagem,archive_reason}` prepara a operação. O motivo precisa estar em archive_reasons; inválido recusa antes de qualquer escrita. `operacao-aplicar {previa_id}` revalida conta, revisão e estado. Uma chamada de atividade acrescenta a linha final e marca done; outra arquiva o lead. Atividade ausente é criada única, concluída, antes de arquivar. Não é transação distribuída: falha posterior pode deixar a atividade concluída com lead aberto, explicitamente no recibo. Não se envia mensagem externa.

`negocio-perder {negocio_id,lost_reason}` prepara perda somente de negócio aberto não arquivado; motivo precisa estar em lost_reasons. Aplicar usa PATCH v2 com status=lost. A rota de prévia genérica também passa a validar archive_reason e exigir motivo ao arquivar lead, fechando o desvio da lista por essa rota.

`lead-arquivado-editar {lead_id,campos}` prepara desarquivar, editar e rearquivar. `campos` usa a allowlist anterior do lead, exceto is_archived/archive_reason, preservados pelo fluxo. Exige motivo original e archive_time disponível. Após edição recusada, tenta rearquivar com o motivo original, inclusive legado; o recibo registra sucesso/falha e data original/nova. Falha/timeout de desarquivamento não autoriza adivinhar o estado nem repetir. Falha da compensação mantém bloqueio persistente. Datas não são restauradas artificialmente.

## Leitura e completude

`auditoria` retorna entidade, id e regra: quatro origens ausentes, sem próxima atividade com data, formato de título, organização com nome igual ao contato ligado, negócio aberto com stage_change_time além do limite e reunião vencida na primeira etapa configurada. Nomes são comparados somente em memória; não são retornados. Reunião passada conta mesmo se concluída quando o negócio continua na primeira etapa.

`contar-por-campo {entidade,campo}` aceita leads, negocios, pessoas, organizacoes e chave do catálogo correspondente. Leads/negócios juntam coleções ativa e arquivada; contatos não possuem coleção de arquivo nesta API, e excluídos não são incluídos. Opções retornam `opcao:ID`, nunca labels; múltipla escolha conta cada opção uma vez por registro (soma pode exceder total). Vazio é grupo explícito. Demais tipos viram categoria HMAC estável por site, conta, entidade e campo; não é hash público reversível por dicionário.

Fila até200 itens, auditoria até1000 ocorrências, contagem até200 grupos e coleta até12000 registros. Estouro, paginação sem fim declarado, cursor repetido, duplicidade, orçamento ou erro geram coleta_completa=false e motivos; não há total completo inventado. A fila parcial suprime texto e marca todos os itens sem envio devido. Resultados refletem visibilidade da credencial e não são snapshot transacional da conta. Custo declara chamadas, estimativa do contrato Core (GET20/escrita10) e, nas leituras, delta observado, que pode incluir consumo concorrente. Unidades locais não são tokens oficiais de todos os endpoints.

## Interrupção e reconciliação

Recibo tem etapas, HTTP/código, entrada_digest HMAC, dados mínimos e reconciliacao_necessaria. Cada resposta de etapa é persistida no diário antes da seguinte. Uma queda pode deixar state=running e checkpoint; nunca reexecute cegamente. Trava persistente `f3_pd_pending_<hash>` impede novos fluxos no registro, inclusive escrita genérica em lead, até revisão de manutenção. Recibos prontos não repetem etapas, mesmo após falha.

Para resolver: consulte registro-ler e o fornecedor por IDs, confronte cada efeito e preserve o recibo/checkpoint. Com ordem explícita do dono e comprovação do estado final, manutenção pode retirar somente a trava correspondente ao recibo, mantendo a operação e sua chave consumida. Não apague tabelas, recibos ou salts; não reutilize a chave para reenviar uma mensagem. Esta versão não oferece liberação automática nem reconciliação automática de efeitos remotos. Uma prévia ainda pronta pode ser refeita se expirada/alterada; estado running exige conferência.

## Referências técnicas

Conferidas em 29/10/2026: https://developers.pipedrive.com/docs/api/v1/Activities ; https://developers.pipedrive.com/docs/api/v1/Leads ; https://developers.pipedrive.com/docs/api/v1/Deals ; https://developers.pipedrive.com/docs/api/v1/Persons ; https://pipedrive.readme.io/docs/pipedrive-api-v2-migration-guide . O motivo do contorno para arquivados está em https://developers.pipedrive.com/changelog/post/breaking-change-archived-deals-and-leads-will-not-be-returned-in-existing-endpoints-and-will-not-be-editable . Consulta documental não é homologação com dados reais.
