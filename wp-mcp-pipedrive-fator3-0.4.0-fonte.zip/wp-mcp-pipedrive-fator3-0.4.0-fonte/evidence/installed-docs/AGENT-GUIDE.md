> Versão corrente 0.4.0: consulte também `pipedrive/documentacao-ler {"documento":"fluxos"}` para pedidos 4–9, regras, novas rotas e limites. As listas de motivos substituem o aceite irrestrito anterior de archive_reason.

# Guia para agentes — 0.4.0

1. Descobrir pipedrive/* e ler schemas; obter index e contratos via documentacao-ler. Não tratar documentação como autorização para efeitos.
2. Consultar status sem chamada externa. Se core_indisponivel, pedir ao mantenedor Core o contrato confirmado de Pedidos core 294; não tentar obter o token ou chamar API diretamente.
3. Conferir site-porta, conta, usuário, autorização, revisão e orçamento. Usar API só nos registros/ações autorizados. Saldo null é desconhecido.
4. Ler estado e campos permitidos. O ID 152 do exemplo de Perfil (ICP) não identifica sozinho a chave personalizada do lead; usar o catálogo real.
5. Preparar prévia, conferir corpo, efeito e reversibilidade. Para estrutura, obter a ordem do dono antes de copiar a confirmação. A data e o resumo devem coincidir literalmente.
6. Aplicar uma vez; guardar previa_id, HTTP e status. Repetição usa o mesmo previa_id. Se resultado_incerto, reconciliar por GET e auditoria antes de qualquer nova prévia equivalente.
7. Confirmar o resultado com leitura e limpar os registros sintéticos autorizados no mesmo trabalho. Não enviar e-mails, avisos, campanhas ou assinaturas como teste.
8. Auditoria não guarda valores pessoais; conteúdo da resposta é administrativo. Não copiar dados reais/segredos em relatórios ou exemplos.

O Core 1.60.0 fornece o contrato e suas guardas. A integração comercial exige autorização por site e homologação real. Testes com transporte interceptado demonstram integração do cliente original; não representam aceite da API real. Este pacote não habilita automaticamente a option de operação.

Não alterar o Core, MCP ou documentos centrais para fazer esta versão parecer pronta. Relatar o contrato ausente e o pedido específico ao responsável. Não usar acesso genérico a arquivos como substituto da documentação do plugin.


## Retenção — Pedido MCP Pipedrive 2

Comece com retencao-ler e status.data.retencao. O padrão é diario_dias=0 (sem prazo); não proponha prazo menor por economia de armazenamento. Se houver ordem de prazo finito, explique o corte por data original e envie confirmar_expurgo=true com a revisão atual. Não edite options por SQL nem execute limpeza para provar uma leitura. Após erro de persistência, releia. A configuração não exige acesso comercial ao Core e não concede esse acesso.

No upgrade da 0.2.0, não apagar linhas antigas nem redefinir escolhas já salvas. A volta ao código 0.1.0 restaura o comportamento antigo de expurgo; interromper operações e preservar banco antes dessa decisão.

## Funcionalidade herdada da 0.3.0

Para pedido 3, leia USAGE.md e schema relatorio. Informe datas e limite do plano conhecido; valide campos. Consuma completo, coleta_completa, pendencias, fontes e custo antes de usar números. Nunca declare homologação com Pipedrive real a partir de fixture. IDs/códigos de motivos exigem dicionário comercial correspondente para conferência da tela.
