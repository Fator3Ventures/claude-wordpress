> Versão corrente 0.4.0: consulte também `pipedrive/documentacao-ler {"documento":"fluxos"}` para pedidos 4–9, regras, novas rotas e limites. As listas de motivos substituem o aceite irrestrito anterior de archive_reason.

# Fator3 MCP Pipedrive 0.4.0

Operações administrativas na conta Pipedrive pelo token que permanece no Site Core. Este pacote não armazena token, não faz HTTP próprio e não interfere nas filas de entrega de leads.

## Prontidão

Core 1.60.0 oferece o contrato `pipedrive-api-client/1.0.0` consumido pelo pacote. A operação exige autorização explícita por site e provider; a atualização não a concede. Sem contrato, status informa core_indisponivel; sem autorização, operacao_nao_autorizada. A política local de retenção aparece no status em ambos os casos. Ajuda, configuração local e auditoria não dependem de fornecedor.

Retenção herdada da 0.2.0: **diário sem prazo por padrão**; a atualização preserva a escolha já salva. `pipedrive/retencao-ler` e `pipedrive/retencao-configurar` permitem escolher dias; 0 significa sem prazo. O painel oferece a mesma configuração. Recibos comuns cifrados mantêm 180 dias (WhatsApp: sem expurgo automático para manter idempotência) e prévias 15 minutos. São dezenove operações ao todo.

## Índice e leitura

| ID | Arquivo | Assunto |
|---|---|---|
| index | README.md | Visão geral |
| especificacao | SPECIFICATION.md | Listas e comportamento |
| configuracao | CONFIGURATION.md | Pré-requisitos e autorização |
| uso | USAGE.md | Fluxo e exemplos |
| contratos | CONTRACTS.md | Contratos Core, retenção e erros |
| agentes | AGENT-GUIDE.md | Orientação de operação |
| operacao | OPERATIONS.md | Armazenamento e recuperação |
| release | CHANGELOG.md | Escopo 0.4.0 |
| fluxos | WORKFLOWS.md | Regras, cadência, operações e auditoria 0.4.0 |
| regras-iniciais | regras-iniciais.json | Defaults sem configuração comercial presumida |
| schemas | schemas.json | Schemas gerados do runtime |

Descobrir `pipedrive/documentacao-ler`. Chamar `{}` para este índice, ou `{"documento":"uso"}`. Continuações usam `offset=proximo_offset` e `sha256_esperado` da página anterior. Encerrar quando `fim=true`. Páginas de 256 a 24.000 bytes, padrão 16.000, com corte UTF-8. O SHA-256 representa o documento completo. Não juntar revisões diferentes. IDs são fechados; caminhos arbitrários e symlinks externos são recusados. Todos os acessos exigem manage_options.

A documentação é estática: sua leitura não consulta o Core nem fornecedor, não verifica token e não cria tabelas, cron ou configurações. Painel: Ferramentas → Fator3 MCP Pipedrive.

## Funcionalidade herdada da 0.3.0

Nova operação: `pipedrive/relatorio`. Leia USAGE.md antes de comparar com a tela; distingue período, subtotais, visibilidade e limite do plano informado.
