> Versão corrente 0.4.0: consulte também `pipedrive/documentacao-ler {"documento":"fluxos"}` para pedidos 4–9, regras, novas rotas e limites. As listas de motivos substituem o aceite irrestrito anterior de archive_reason.

# Especificação — 0.4.0

Referência: Pedidos MCP Pipedrive 1; pedido de 23/10/2026, C1–C8 e A1–A16. Cinco rotas de domínio mais `pipedrive/documentacao-ler`, incluída para cumprir a norma documental.

| Operação | Efeito |
|---|---|
| pipedrive/status | Leitura local de estado do Core, sem HTTP |
| pipedrive/api-ler | GET permitido; orçamento e saldo geridos pelo Core |
| pipedrive/api-previa | GET atual quando há ID, armazenamento local cifrado, validade 15 minutos |
| pipedrive/api-aplicar | Revalidação GET, aquisição atômica, uma tentativa remota e recibo |
| pipedrive/registro-ler | Auditoria local, paginada por id decrescente |
| pipedrive/documentacao-ler | Ajuda local, allowlist e SHA-256 |

## Lista GET

* `/v1/leads/{uuid}`, `/v1/leads`, `/v1/leads/archived`; listas aceitam filter_id, limit (1–500), start.
* `/v1/dealFields`, `/v1/personFields`, `/v1/organizationFields`, `/v1/activityFields`, `/v1/noteFields`; limit/start.
* `/v1/filters` (type), `/v1/filters/{id}`, `/v1/leadLabels`, `/v1/activityTypes`, `/v1/users/me`.
* `/v1/notes/{id}`, `/v1/notes` (lead_id, deal_id, person_id, org_id, limit/start).
* `/api/v2/deals/{id}`, `/api/v2/persons/{id}`, `/api/v2/organizations/{id}`, `/api/v2/activities/{id}`.
* `/api/v2/pipelines`, `/api/v2/stages` (limit/cursor).

IDs de lead/etiqueta são UUID; os outros são inteiros positivos. Query deve vir em objeto separado. Nenhum caminho aceita URL absoluta, query embutida, encoding de barras, travessia ou merge. `ids`, token, headers e host não são entradas permitidas.

## Lista de escrita

| Classe | Método | Caminho |
|---|---|---|
| registro | PATCH | /v1/leads/{uuid} |
| registro | PUT | /v1/notes/{id} |
| registro | DELETE | /v1/leads/{uuid}, /v1/notes/{id}, /api/v2/persons/{id}, /api/v2/organizations/{id}, /api/v2/deals/{id}, /api/v2/activities/{id} |
| estrutura | POST | /v1/dealFields, /v1/personFields, /v1/organizationFields |
| estrutura | PUT, DELETE | /v1/dealFields/{id}, /v1/personFields/{id}, /v1/organizationFields/{id} |
| estrutura | POST | /v1/filters, /v1/leadLabels |
| estrutura | PUT, DELETE | /v1/filters/{id} |
| estrutura | PATCH, DELETE | /v1/leadLabels/{uuid} |

Os corpos também usam listas fechadas. Lead: title, owner_id, label_ids, person_id, organization_id, value, expected_close_date, visible_to, was_seen, is_archived, archive_reason, origin_id, channel, channel_id e chaves personalizadas de 40 hexadecimais (sufixos currency/start/end/until). Nota: content e pinned_to_deal_flag/person_flag/organization_flag/lead_flag. Campo novo: name, field_type, options; alteração: name, options, remover_opcoes. Filtro novo: name, type, conditions; alteração: name, conditions. Etiqueta: name, color. DELETE não recebe corpo.

Campos existentes e etiquetas são localizados no catálogo GET permitido; não se inventa GET de etiqueta individual. Campos usam até vinte páginas, parando quando localizados; paginação inválida/incompleta recusa. Não há busca ou escrita genérica fora dessas listas.

## Integridade

PUT com options compara IDs atuais e recebidos. IDs existentes omitidos exigem correspondência exata em remover_opcoes; a lista e os nomes aparecem na prévia. Esse controle local é removido do corpo enviado ao fornecedor. IDs desconhecidos/duplicados são recusados. Omitir integralmente options conserva as opções atuais (renomeação apenas). Não há substituição por uma lista parcial sem confirmação.

Estrutura exige frase literal devolvida pela prévia, com data America/Sao_Paulo, método/caminho, chaves e digest da prévia. A frase não comprova por si só que o dono autorizou: o operador deve ter a ordem antes de aplicá-la.

Prévia vinculada a administrador, site, conta, usuário Pipedrive e revisão do Core. Aplicação revalida autorização e estado; mudança exige nova prévia. O Core precisa validar revisao_esperada no despacho para fechar a janela de troca de conta. Alterações feitas por terceiros entre o último GET e a escrita continuam limitadas pela ausência de compare-and-swap remoto no fornecedor.

A exclusão não é desfeita por este plugin. Lixeira, prazo e tipos recuperáveis devem ser conferidos na conta; não se garante restauração de toda entidade. Exclusão de campo/opção destrói valores. Filtro/etiqueta excluídos não têm reversão automática.

Fora: criação dos registros já atendidos pelo conector, merge, exclusão em massa, webhooks, cron, fila, mailbox, files, usuários/cobrança, escrita em funis/etapas/tipos de atividade. Endpoints v2 de campos não são habilitados por suposição; a conta não foi homologada para essa migração.


## Retenção herdada da 0.2.0

Diário técnico permanente por padrão (diario_dias=0); prazo positivo configurável até 36.500 dias por painel/MCP com revisão e confirmação de expurgo futuro. Recibos comuns cifrados continuam com 180 dias; recibos WhatsApp ficam sem expurgo automático e prévias com 900 segundos. Retencao-ler é observacional; retencao-configurar escreve somente política local. Status inclui retencao; registro-ler distingue prazo e sem_prazo. Atualização da 0.3.0 conserva as linhas e seus instantes. Sem alteração de schema de tabelas, sem cron e sem autorização comercial automática.

## Relatório agregado herdado da 0.3.0

Pedido 3: leitura agregada paginada com período, completude, custo operacao, dimensões e uso do plano. Sem persistir dados ou emitir textos livres. A semântica completa, limites, códigos, ausência de motivo nativo de ganho e comparação dependente de limite informado estão em USAGE.md.
