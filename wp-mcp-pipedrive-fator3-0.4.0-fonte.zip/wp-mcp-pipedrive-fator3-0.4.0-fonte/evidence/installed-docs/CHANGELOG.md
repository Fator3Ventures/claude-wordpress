# 0.4.0 — 29/10/2026

Pedidos4–9: configuração com simulação/revisão, fila, WhatsApp idempotente, encerramento/perda, edição arquivada com compensação, auditoria e contagem. Dez rotas novas; nove preservadas. Core1.60.0/MCP0.36.0, contrato pipedrive-api-client/1.0.0 preservado. Sem migração de tabelas/cron; regras começam pendentes. Recibos WhatsApp sem expurgo automático. Leia fluxos para limites e reconciliação.

# Notas de versão

## 0.3.0 — 28/10/2026

Pedidos MCP Pipedrive 3: relatório agregado com paginação interna, datas/fuso, códigos sem texto pessoal, negócios ativos/arquivados, completude e custo. Limite do plano informado pelo chamador; motivo de ganho customizado; não é snapshot histórico. Atualização direta de 0.2.0. Core contrato 1.0.0 preservado. Sem migração ou novas credenciais. Aceite da conta real depende de conferência de 30 dias em korvena.com.br.

## Histórico preservado

# Notas — Fator3 MCP Pipedrive 0.2.0

26/10/2026, America/Sao_Paulo. Base direta: 0.1.0. Pedido MCP Pipedrive 2(a–d).

Diário sem prazo por padrão, configurável no painel e pelas novas retencao-ler/retencao-configurar. Status exibe a política mesmo com Core desautorizado. Prazo finito exige ciência explícita; escrita usa revisão, geração e releitura, compartilhando trava com a limpeza. Recibos conservam 180 dias, prévias 15 minutos; diário deixa de depender da existência do recibo. Upgrade não apaga nem redata linhas e preserva a configuração posterior.

O contrato pipedrive-api-client/1.0.0 está presente no Core 1.56.0; documentação deixa de tratá-lo como proposta futura. MCP 0.33.0 oferece transporte/política genéricos. Meta 0.12.0, Google 0.19.0 e LinkedIn 0.10.1 não são dependências do pacote. Nenhum plugin acompanhante foi modificado.

Sem cron, webhook, token ou HTTP próprios. Oito abilities; nenhum campo de credencial novo. Conferir o relatório externo para provas executadas, limitações, estado do Site-Teste e hashes finais.

## Histórico 0.1.0 — 23/10/2026

Primeira versão: cinco operações de domínio, documentação paginada, REST/painel administrativos, listas fechadas, prévia de 15 minutos, proteção de opções/estrutura, revalidação, aplicação única, recibos cifrados e auditoria. A aba de pedidos atual registra sua homologação posterior pela frota nos sites-porta; essa é evidência recebida, não nova execução comercial desta release.
