<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Eligibility of a collection; never changes the supplier value or the next due date. */
final class ScheduleAvailability {
    private const MIN_FOLLOWERS = 100;
    private const EMPTY_CODES = ['empty_or_suppressed','value_unavailable'];

    public static function emptyMetric(array $error,string $metric): bool {
        return ($error['field']??null)===$metric && in_array($error['code']??null,self::EMPTY_CODES,true);
    }

    /** Validates only the per-metric Graph total, after the parent row has been attributed. */
    public static function totalState(mixed $total,bool $requestedBreakdown): string {
        if($total===null || $total===[])return 'absent';
        if(!is_array($total)||array_is_list($total))return 'unreadable';
        $value=$total['value']??null;
        if($value!==null&&!is_numeric($value)&&($requestedBreakdown||array_key_exists('breakdowns',$total)))return 'unreadable';
        if(!array_key_exists('breakdowns',$total))return $value!==null?'available':(array_key_exists('value',$total)?'absent':'unreadable');
        $groups=$total['breakdowns'];
        if(!is_array($groups)||!array_is_list($groups))return 'unreadable';
        $hasValue=$value!==null;
        foreach($groups as $group){
            if(!is_array($group)||!is_array($group['results']??null)||!array_is_list($group['results']))return 'unreadable';
            if(array_key_exists('dimension_keys',$group)&&!self::dimensions($group['dimension_keys'],true))return 'unreadable';
            foreach($group['results'] as $bucket){
                if(!is_array($bucket)||!is_numeric($bucket['value']??null))return 'unreadable';
                if(array_key_exists('dimension_values',$bucket)&&!self::dimensions($bucket['dimension_values'],false))return 'unreadable';
                $hasValue=true;
            }
        }
        return $hasValue?'available':'empty_breakdown';
    }
    private static function dimensions(mixed $values,bool $keys): bool {
        if(!is_array($values)||!array_is_list($values))return false;
        foreach($values as $v)if(!is_string($v)&&($keys||!is_numeric($v)))return false;
        return true;
    }

    /** Probe only after a successful, empty follower-demographics read on the same selected IG account. */
    public static function observeAudience(array $connection,string $account,array &$page): void {
        if(count($page['errors'])!==1 || !self::emptyMetric($page['errors'][0],'follower_demographics')
            || array_filter($page['rows'],[CollectionState::class,'useful']))return;
        $p=Http::request($connection,$account,['fields'=>'id,followers_count'])['body'];
        if((string)($p['id']??'')!==$account)throw new Fault('upstream_invalid','O perfil de conferência não corresponde à conta da consulta.');
        $count=$p['followers_count']??null;
        if(!is_int($count)||$count<0||$count>=self::MIN_FOLLOWERS)return;
        $proof=['kind'=>'nao_aplicavel','reason'=>'below_minimum_followers','followers_count'=>$count,
            'minimum_followers'=>self::MIN_FOLLOWERS,'account_id'=>$account,'observed_at'=>time()];
        $page['errors'][0]['eligibility']=$proof;
        foreach($page['rows'] as &$row){
            $row['diagnostic']['eligibility']=$proof;
            $row['diagnostic']['message']='O perfil tem '.$count.' seguidores; o mínimo para esta consulta é '.self::MIN_FOLLOWERS.'.';
        }
        unset($row);
        $page['errors'][0]['message']=$page['rows'][0]['diagnostic']['message'];
    }

    /** Count every error, including those that do not fit the diagnostic sample. */
    public static function followGaps(array $errors): int {
        return count(array_filter($errors,static fn($e)=>self::emptyMetric($e,'follows_and_unfollows')));
    }

    public static function assessment(array $job,array $coverage): ?array {
        if($job['last_code']!=='fields_unavailable'||empty($coverage['plan_complete'])||$job['query']['channel']!=='instagram')return null;
        $n=(int)($coverage['error_count']??0);
        if($n<1)return null;
        if($job['query']['report']==='audience' && $n===1 && $job['successful_rows']===0){
            $e=$coverage['errors'][0]??[];$p=$e['eligibility']??null;
            if(self::emptyMetric($e,'follower_demographics') && ($p['kind']??null)==='nao_aplicavel'
                && ($p['account_id']??null)===$job['query']['account_id'])return $p;
        }
        if($job['query']['report']==='account_insights' && $job['successful_rows']>0 && ($coverage['follow_gap_count']??null)===$n)
            return ['kind'=>'parcial_esperado','reason'=>'follows_and_unfollows_unavailable','metric'=>'follows_and_unfollows'];
        return null;
    }
}
