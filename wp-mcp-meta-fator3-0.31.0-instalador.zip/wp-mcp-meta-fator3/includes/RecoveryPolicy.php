<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** One policy per WordPress site. Reading and simulating never update options or the queue. */
final class RecoveryPolicy {
    private const OPTION='f3_meta_recovery_policy';
    private const DEFAULTS=[
        'retry_minutes'=>[5,10,20,40,60],
        'repeat_minutes'=>360,
        'max_attempts'=>8,
        'gap_days'=>30,
    ];

    public static function current(): array {
        $value=get_option(self::OPTION,false);
        if($value===false)return self::DEFAULTS+['revision'=>0];
        if(!is_array($value)||!is_int($value['revision']??null)||$value['revision']<1)
            throw new Fault('storage_corrupt','Não foi possível ler a política de recuperação salva.');
        try{return self::settings($value)+['revision'=>$value['revision']];}
        catch(Fault){throw new Fault('storage_corrupt','A política de recuperação salva contém parâmetros inválidos.');}
    }

    public static function read(): array {
        Access::admin();
        return ['scope'=>'site','policy'=>self::current(),'defaults'=>self::DEFAULTS];
    }

    /** failedAttempts=1 means that the first attempt has just failed. */
    public static function delayMinutes(array $policy,int $failedAttempts): int {
        return $policy['retry_minutes'][max(0,$failedAttempts-1)]??$policy['repeat_minutes'];
    }

    private static function invalid(string $field,string $message): never {
        throw new Fault('invalid_input',$message,['field'=>'policy.'.$field,'problem'=>'invalid_value']);
    }

    private static function settings(array $v): array {
        $steps=$v['retry_minutes']??null;
        if(!is_array($steps)||!array_is_list($steps)||count($steps)<1||count($steps)>12)
            self::invalid('retry_minutes','Informe de uma a doze esperas iniciais em minutos.');
        $previous=0;
        foreach($steps as $n){
            if(!is_int($n)||$n<1||$n>1440||$n<$previous)self::invalid('retry_minutes','Use esperas inteiras de 1 a 1.440 minutos, em ordem não decrescente.');
            $previous=$n;
        }
        $out=['retry_minutes'=>$steps];
        foreach(['repeat_minutes'=>[$previous,1440],'max_attempts'=>[2,30],'gap_days'=>[1,30]] as $k=>[$min,$max]){
            $n=$v[$k]??null;
            if(!is_int($n)||$n<$min||$n>$max)self::invalid($k,match($k){
                'repeat_minutes'=>'O intervalo de repetição deve ser pelo menos a última espera inicial e no máximo 1.440 minutos.',
                'max_attempts'=>'Informe de 2 a 30 tentativas, contando a primeira.',
                'gap_days'=>'Informe uma janela de 1 a 30 dias.',
            });
            $out[$k]=$n;
        }
        return $out;
    }

    private static function plan(array $input,array $current): array {
        if(($input['expected_revision']??null)!==$current['revision'])
            throw new Fault('revision_conflict','A política mudou. Recarregue a revisão vigente e simule de novo.',['current_revision'=>$current['revision']]);
        $settings=self::settings($input['policy']);
        $changed=$settings!==array_intersect_key($current,self::DEFAULTS);
        $minutes=[];for($n=1;$n<$settings['max_attempts'];$n++)$minutes[]=self::delayMinutes($settings,$n);
        return ['scope'=>'site','current'=>$current,'proposed'=>$settings,'changed'=>$changed,
            'waits_minutes'=>$minutes,'total_wait_minutes'=>array_sum($minutes),
            'plan_digest'=>hash_hmac('sha256',Util::json(['recovery-policy/1',get_current_blog_id(),$current['revision'],$settings]),wp_salt('auth'))];
    }

    public static function simulate(array $input): array {
        Access::admin();return self::plan($input,self::current());
    }

    public static function save(array $input): array {
        Access::admin();
        return Store::lock('recovery-policy',static function()use($input){
            // A worker may have read the old option before it acquired this site's writer lock.
            wp_cache_delete(self::OPTION,'options');wp_cache_delete('notoptions','options');
            $current=self::current();$plan=self::plan($input,$current);
            if(!hash_equals($plan['plan_digest'],$input['plan_digest']))
                throw new Fault('simulation_mismatch','Refaça a simulação com a revisão e os valores que deseja salvar.');
            if(!$plan['changed'])return ['scope'=>'site','policy'=>$current,'changed'=>false,'persisted'=>true];
            $value=$plan['proposed']+['revision'=>$current['revision']+1];
            if(!update_option(self::OPTION,$value,false))throw new Fault('persistence_unconfirmed','Não foi possível confirmar a gravação da política. Releia o estado.');
            wp_cache_delete(self::OPTION,'options');
            if(self::current()!==$value)throw new Fault('persistence_unconfirmed','A política relida é diferente da proposta. Releia o estado.');
            return ['scope'=>'site','policy'=>$value,'changed'=>true,'persisted'=>true];
        });
    }
}
