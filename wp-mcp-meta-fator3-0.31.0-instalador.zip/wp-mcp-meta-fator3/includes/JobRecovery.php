<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Recovery of an existing checkpoint. Never creates an alternative job or grants access. */
final class JobRecovery {
    private const PAGE_SIZE=50;
    private const CURSOR='f3_meta_recovery_pause_scan';
    public static function transientEvidence(Fault $e): bool {
        $http=(int)($e->details['http_status']??0);
        return ($e->details['provider_is_transient']??false)===true||$http===408||($http>=500&&$http<600);
    }
    /** Only read failures plausibly attributable to an individual remote insight may be isolated. */
    public static function isolatable(Fault $e): bool {
        if(in_array($e->reason,['rate_limited','budget_exhausted','operation_uncertain','busy'],true))return false;
        return self::transientEvidence($e)||in_array($e->reason,['upstream_invalid','upstream_error','network_error','timeout'],true);
    }
    public static function retryableRead(Fault $e): bool {
        // Never advertise blind retries of a write without its remote receipt.
        return $e->reason!=='operation_uncertain' && (self::isolatable($e)||in_array($e->reason,['rate_limited','budget_exhausted','busy'],true)
            || (isset($e->details['http_status'])&&in_array($e->reason,['asset_access_denied','token_rejected','resource_not_found','upstream_validation'],true)&&empty($e->details['provider_code'])));
    }
    private static function permanent(Fault $e,array $v,?array $c): bool {
        if(self::transientEvidence($e)||in_array($e->reason,['upstream_invalid','upstream_error'],true))return false;
        $d=$e->details;
        if(in_array($e->reason,['token_rejected','asset_access_denied','not_authorized','resource_not_found'],true)){
            $vendor=(int)($d['provider_code']??0);
            if(($d['auth_scope']??'')==='connection'&&!$vendor)$vendor=(int)($d['connection_validation']['provider_code']??0);
            // A generic remote 403 or an unreachable validation endpoint is not proof of a permanent refusal.
            if(isset($d['http_status'])||isset($d['provider_call'])||$vendor)return $vendor>0;
            if($e->reason==='asset_access_denied'&&$c!==null){
                $q=$v['query'];return !in_array($q['account_id'],$c['assets'][$q['channel']]??[],true)
                    ||($q['channel']==='dataset'&&!in_array($q['ads_account_id']??null,$c['assets']['ads']??[],true));
            }
            return false;
        }
        if($e->reason==='revision_conflict')return $c!==null && (int)($v['connection_revision']??0)<(int)($c['plan_floor']??0);
        if($e->reason==='invalid_input')return ($e->details['schema']??'')==='query' && !in_array($v['query']['report']??'',Catalog::reports(),true);
        return in_array($e->reason,['unsupported_field','unsupported_timeframe','unsupported_breakdown','not_configured','connection_paused','token_expired','credential_revalidation_required'],true);
    }
    /** Freeze the policy used for this page's recovery cycle. Changes apply to the next cycle. */
    private static function policy(array &$v): array {
        return $v['recovery_policy']??=RecoveryPolicy::current();
    }
    public static function isolationDue(array $v): bool {
        $p=$v['recovery_policy']??null;
        return $p!==null && !empty($v['can_isolate'])
            && in_array($v['query']['report'],['account_insights','page_insights','stories_insights','media_insights','post_insights','video_insights','audience','page_audience'],true)
            && (int)($v['attempts']??0)>=$p['max_attempts']-1;
    }
    public static function failure(array &$v,Fault $e,?array $c): void {
        $p=self::policy($v);$v['last_code']=$e->reason;$v['last_error']=CollectionState::diagnostic($e->reason,$e->details);
        $v['availability_assessment']=null;$v['outcome']='failed';$v['next_at']=0;$v['pause_reason']=null;
        if($e->reason==='budget_exhausted'){
            // A local worker allocation is replenished independently and consumes no provider attempt.
            $v['status']='retry';$v['next_at']=time()+max(300,(int)($e->details['retry_after']??0));return;
        }
        $v['attempts']=(int)($v['attempts']??0)+1;$v['can_isolate']=self::isolatable($e);
        $permanent=self::permanent($e,$v,$c);
        if(!$permanent&&$v['attempts']<$p['max_attempts']){
            $v['status']='retry';$v['next_at']=time()+max(60*RecoveryPolicy::delayMinutes($p,$v['attempts']),(int)($e->details['retry_after']??0));
            return;
        }
        $v['status']='paused';$v['pause_reason']=$permanent?'permanent':'attempts_exhausted';
        $v['paused_microtime']=microtime(true);$v['paused_generation']=$c['credential_generation']??($v['credential_generation']??0);
    }
    public static function reset(array &$v): void {
        unset($v['recovery_policy'],$v['paused_microtime'],$v['paused_generation'],$v['can_isolate'],$v['isolation_attempted']);
        $v['attempts']=0;$v['pause_reason']=null;
    }
    public static function projection(array $v): array {
        return ['attempts'=>(int)($v['attempts']??0),'next_retry_at'=>($v['status']??'')==='retry'?(int)$v['next_at']:null,
            'pause_reason'=>($v['status']??'')==='paused'?(!empty($v['manual_pause'])?'manual':($v['pause_reason']??null)):null,
            'recovery_policy_revision'=>$v['recovery_policy']['revision']??null,'max_attempts'=>$v['recovery_policy']['max_attempts']??null,
            'isolation_attempted'=>(bool)($v['isolation_attempted']??false)];
    }
    private static function proofKey(array $q): string {return hash('sha256',Util::json([$q['connection_id'],$q['report']]));}
    /** Proof of access to an individual projection must not come from a different metric or entity. */
    private static function selection(array $q): string {
        unset($q['date_from'],$q['date_to'],$q['limit'],$q['cursor']);
        if(isset($q['fields']))sort($q['fields'],SORT_STRING);
        ksort($q);return hash('sha256',Util::json($q));
    }
    /** At most one encrypted receipt per connection/report; no scans of the unbounded completed-job archive. */
    public static function completed(string $id,array $v): void {
        if($v['status']!=='complete')return;
        $q=$v['query'];$key=self::proofKey($q);$done=['job_id'=>$id,'selection'=>self::selection($q),'at'=>microtime(true)];
        for($i=0;$i<3;$i++){
            $old=Store::get('recovery_success',$key);
            if($old&&($old['value']['at']??0)>=$done['at'])return;
            try{Store::put('recovery_success',$key,$done,$old['revision']??0);return;}
            catch(Fault $e){if($e->reason!=='revision_conflict')throw $e;}
        }
        // Concurrent successes update the same receipt; the winner is itself proof of progress.
    }
    private static function resume(string $id): bool {
        return Store::lock('job:'.$id,static function()use($id){
            $r=Store::get('job',$id);if(!$r)return false;$v=$r['value'];
            if(($v['status']??'')!=='paused'||!empty($v['manual_pause']))return false;
            $q=$v['query'];$reason=$v['pause_reason']??null;
            $legacy=$reason===null&&!empty($v['last_code']);
            if(!$legacy&&!in_array($reason,['permanent','attempts_exhausted'],true))return false;
            $c=Connections::get($q['connection_id']);
            // In particular, a different identity/API version, removed grant or manually paused series is not revived.
            Connections::checkPlan($v,$c);Access::worker(SiteOwner::executor($v['principal']),$c,$q['channel'],$q['account_id']);
            if(!empty($v['schedule_id'])){
                $s=Store::get('schedule',$v['schedule_id']);if(!$s||empty($s['value']['enabled']))return false;
            }
            $at=(float)($v['paused_microtime']??$v['updated_at']??0);
            $proof=Store::get('recovery_success',self::proofKey($q))['value']??[];
            $later=!empty($proof)&&$proof['job_id']!==$id&&$proof['at']>$at;
            $newCredential=(int)$c['credential_generation']>(int)($v['paused_generation']??$v['credential_generation']??0);
            if($legacy){
                // Before 0.31.0 a parser error paused immediately; take it into the new cycle once.
                $oldFault=new Fault($v['last_code'],'',$v['last_error']??[]);
                if(self::permanent($oldFault,$v,$c))$reason='permanent';else $reason='legacy_retry';
            }
            if($reason==='attempts_exhausted'&&!$later)return false;
            if($reason==='permanent'){
                // Recheck the actual old selection locally before authorizing any new read.
                Schemas::validate('query',$q);Catalog::validateSelection($c,$q);
                $wasLocal=in_array($v['last_code']??'',['unsupported_field','unsupported_timeframe','unsupported_breakdown','invalid_input','connection_paused','token_expired','credential_revalidation_required','not_configured','revision_conflict'],true);
                $reprobeAt=$at+60*(int)($v['recovery_policy']['repeat_minutes']??RecoveryPolicy::current()['repeat_minutes']);
                if(!$wasLocal&&!$newCredential&&!($later&&($proof['selection']??'')===self::selection($q))&&microtime(true)<$reprobeAt)return false;
            }
            self::reset($v);$v['status']=$v['outcome']='queued';$v['next_at']=$v['updated_at']=time();$v['last_code']=null;
            $v['last_auto_resume']=['reason'=>$reason,'at'=>$v['updated_at']];
            Store::put('job',$id,$v,$r['revision'],$r['expires_at']);return true;
        });
    }
    /** Rotating bounded scan using the runnable index, never walking terminal or cancelled jobs. */
    public static function maintenance(): array {
        return Store::lock('recovery-maintenance',static function(){
            global $wpdb;$cur=(array)get_option(self::CURSOR,[]);$t=Store::table();$limit=self::PAGE_SIZE;
            $rows=$wpdb->get_results($wpdb->prepare("SELECT record_key,queue_next FROM %i WHERE bucket='job' AND queue_state='paused' AND (queue_next>%d OR (queue_next=%d AND record_key>%s)) ORDER BY queue_next,record_key LIMIT %d",$t,(int)($cur['next']??0),(int)($cur['next']??0),(string)($cur['key']??''),$limit),ARRAY_A);
            if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao selecionar coletas para recuperação.');
            $count=0;foreach($rows as $row){
                try{$count+=(int)self::resume($row['record_key']);}catch(Fault $e){
                    if(!in_array($e->reason,['busy','revision_conflict','cipher_unreadable','storage_corrupt','not_authorized','asset_access_denied','connection_paused','token_expired','credential_revalidation_required','not_configured','unsupported_field','unsupported_timeframe','unsupported_breakdown','invalid_input'],true))throw $e;
                }
            }
            if(count($rows)===$limit){$last=end($rows);update_option(self::CURSOR,['key'=>$last['record_key'],'next'=>(int)$last['queue_next']],false);}
            elseif($cur)delete_option(self::CURSOR);
            if($count)Jobs::scheduleTick();
            return ['checked'=>count($rows),'resumed'=>$count];
        });
    }
    public static function health(): array {
        global $wpdb;$items=[];$limit=self::PAGE_SIZE;
        // Scan at most limit+1 entries from either indexed state. Exact count only while inside the public limit.
        $more=false;foreach(['retry','paused'] as $state){
            $ids=$wpdb->get_col($wpdb->prepare("SELECT record_key FROM %i WHERE bucket='job' AND queue_state=%s ORDER BY queue_next,record_key LIMIT %d",Store::table(),$state,$limit+1-count($items)));
            if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao ler o diagnóstico de recuperação.');
            foreach($ids as $id){
                if(count($items)>=$limit){$more=true;break 2;}
                try{$v=Store::get('job',$id)['value']??null;}catch(Fault $e){if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;$v=null;}
                if(!$v||$v['status']!==$state)continue;
                $items[]=['job_id'=>$id,'schedule_id'=>$v['schedule_id']??null,'connection_id'=>$v['query']['connection_id'],'report'=>$v['query']['report'],'status'=>$v['status'],'last_code'=>$v['last_code']??null]+self::projection($v);
            }
        }
        return ['jobs'=>$items,'total'=>$more?null:count($items),'at_least'=>count($items)+(int)$more,'truncated'=>$more,'limit'=>$limit];
    }
}
