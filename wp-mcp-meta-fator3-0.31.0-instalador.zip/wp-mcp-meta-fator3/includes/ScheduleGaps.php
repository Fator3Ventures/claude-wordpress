<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Bounded calendar-day recovery for scheduled period reports. All writes run under the schedule lock. */
final class ScheduleGaps {
    private const PERIOD_REPORTS=['account_insights','page_insights','ads_insights','ads_activity','dataset_quality'];
    private const MAX_DAYS=30;
    private const NO_SUCCESS=26*3600;
    private static function daily(array $q):bool {
        return in_array($q['report']??'',self::PERIOD_REPORTS,true);
    }
    private static function selection(array $q):array {
        unset($q['date_from'],$q['date_to'],$q['cursor']);ksort($q);return $q;
    }
    private static function date(mixed $d):?int {
        if(!is_string($d)||!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$d))return null;
        $t=strtotime($d.' 00:00:00 UTC');return $t!==false&&gmdate('Y-m-d',$t)===$d?$t:null;
    }
    /** Useful dates across pages. Only the last 30 calendar dates of a scheduled plan can enter the gap window. */
    public static function page(array &$job,array $data):void {
        if(empty($job['schedule_id'])||!self::daily($job['query']))return;
        $to=self::date($job['query']['date_to']??null);if($to===null)return;
        foreach($data['rows'] as $row){
            $day=$row['date']??$row['date_start']??null;
            $at=self::date($day);if($at!==null&&$at<=$to&&$at>$to-self::MAX_DAYS*86400&&CollectionState::useful($row))
                $job['useful_schedule_days'][$day]=true;
        }
    }
    public static function succeeded(array $job):bool {
        return $job['status']==='complete'||($job['status']==='partial'&&(($job['successful_rows']??0)>0||($job['outcome']??'')==='nao_aplicavel'));
    }
    public static function failure(array &$schedule,int $now):void {
        // Freeze the outgoing baseline once. A useful *page* can update last_success_at later,
        // but it must not keep a never-completed collection healthy indefinitely.
        if(!array_key_exists('collection_success_at',$schedule))$schedule['collection_success_at']=(int)($schedule['last_success_at']??0);
        if(empty($schedule['collection_failure_since']))$schedule['collection_failure_since']=$now;
    }
    public static function since(array $s,int $now):?int {
        if(empty($s['enabled']))return null;
        $failure=(int)($s['collection_failure_since']??0);
        if(!$failure&&in_array($s['last_run_status']??'',['failed','partial'],true)&&empty($s['availability_assessment'])&&empty($s['last_successful_rows']))
            $failure=(int)($s['last_error']['observed_at']??0);
        if(!$failure && ($s['next_at']??0)>0 && (int)$s['next_at']<$now)$failure=(int)$s['next_at'];
        if(!$failure)return null;
        $last=(int)($s['collection_success_at']??$s['last_success_at']??0);
        $since=max((int)($s['collection_observation_started_at']??0),$last?:$failure);
        if((int)($s['interval_minutes']??0)*60>=self::NO_SUCCESS)$since=max($since,$failure);
        // For a new long-interval schedule, an observed failure or missed due time must exist first.
        return $now-$since>=self::NO_SUCCESS?$since:null;
    }
    /** A late terminal result counts for this selection's clock, not for the newer job's state or days. */
    public static function record(array &$s,string $sid,string $key,array $job,bool $own):bool {
        if(($job['schedule_id']??null)!==$sid||($job['schedule_epoch']??null)!==($s['collection_epoch']??null)
            ||self::selection($job['query'])!==self::selection($s['query']))return false;
        $tracked=in_array($key,(array)($s['pending_days']??[]),true);
        $status=$job['status'];$ok=self::succeeded($job);
        if(!$own&&!$tracked&&!$ok)return false;
        if($ok){
            $at=(int)($job['updated_at']??time());$prior=(int)($s['collection_success_at']??$s['last_success_at']??0);
            $s['collection_success_at']=max($prior,$at);
            if(!$own&&!$tracked)return $at>$prior;
            if($own&&$at>=(int)($s['collection_failure_since']??0))unset($s['collection_failure_since']);
        }elseif($own&&in_array($status,['retry','paused','partial'],true)&&empty($job['manual_pause']))self::failure($s,(int)($job['updated_at']??time()));
        if(!self::daily($job['query']))return true;
        $from=self::date($job['query']['date_from']??null);$to=self::date($job['query']['date_to']??null);
        if($to===null||$from===null)return true;
        if($status==='cancelled'||!empty($job['manual_pause']))return true;
        $useful=$job['useful_schedule_days']??[];$missing=(array)($s['pending_days']??[]);
        for($d=max($from,$to-(self::MAX_DAYS-1)*86400);$d<=$to;$d+=86400){
            $day=gmdate('Y-m-d',$d);
            if(!$own&&($missing[$day]??null)!==$key)continue;
            if($status==='complete'||($job['outcome']??'')==='nao_aplicavel'||isset($useful[$day])||($ok&&$from===$to))
                unset($missing[$day]);
            elseif(in_array($status,['queued','partial','retry','paused'],true))$missing[$day]=$key;
        }
        ksort($missing);$s['pending_days']=array_slice($missing,-self::MAX_DAYS,null,true);
        return true;
    }

    /** Called after creating/reusing the ordinary job. Never replace its slot, date window or priority.
     * One tracked original or recovery per calendar day; active/paused originals keep their own retry policy.
     * A terminal without useful data is re-planned for a single date, not a wide historical interval. */
    public static function dispatch(array &$s,string $sid,array $q,array $c,string $currentKey):void {
        // Remember that a scheduled slot is outstanding even when its job stays queued.
        // Frequent dispatches must not reset the first pending slot (a stalled backlog).
        self::failure($s,min(time(),max(1,(int)$s['next_at'])));
        $to=self::date($q['date_to']??null);if($to===null||!self::daily($q))return;
        $last=$s['last_job']??null;
        if($last&&$last!==$currentKey){
            $previous=Store::get('job',$last);
            if($previous&&!self::succeeded($previous['value']))self::record($s,$sid,$last,$previous['value'],true);
        }
        if(empty($s['pending_days']))return;
        $policy=RecoveryPolicy::current();$days=max(0,min(self::MAX_DAYS,(int)$policy['gap_days']));
        $floor=gmdate('Y-m-d',$to-max(0,$days-1)*86400);
        $seen=[];
        foreach($s['pending_days'] as $day=>$oldKey){
            if(!$days||strcmp($day,$floor)<0||strcmp($day,$q['date_to'])>0){unset($s['pending_days'][$day]);continue;}
            if(strcmp($day,$q['date_from'])>=0){$s['pending_days'][$day]=$currentKey;continue;}
            $seen[$oldKey]??=Store::get('job',$oldKey)['value']??[];
            $old=$seen[$oldKey];$status=$old['status']??null;
            if($status==='complete'||!empty($old['useful_schedule_days'][$day])){unset($s['pending_days'][$day]);continue;}
            if($status==='cancelled'||!empty($old['manual_pause'])){unset($s['pending_days'][$day]);continue;}
            if(in_array($status,['queued','retry','paused'],true))continue;
            $query=array_replace($q,['date_from'=>$day,'date_to'=>$day]);
            $key=hash('sha256','gap|'.$sid.'|'.$currentKey.'|'.$day);
            if(!Store::get('job',$key)){
                $job=['intent'=>hash('sha256',Util::json($query)),'query'=>$query,'principal'=>$s['principal'],'connection_revision'=>$c['revision'],
                    'status'=>'queued','pages'=>0,'rows'=>0,'cursor'=>null,'next_at'=>time(),'attempts'=>0,'max_pages'=>500,'errors'=>[],
                    'created_at'=>time(),'updated_at'=>time(),'last_code'=>null,'schedule_id'=>$sid,'schedule_epoch'=>$s['collection_epoch']??null,'gap_day'=>$day,'gap_policy_revision'=>$policy['revision']]+Connections::checkpoint($c);
                Store::put('job',$key,$job);
            }
            $s['pending_days'][$day]=$key;
        }
    }
    /** Same projection consumed by both the publisher and the periodic observer of Site Core 1.98. */
    public static function incidents(array $issues,array $connectionsWithSchedules):array {
        $out=[];
        foreach($issues as $i){
            if($i['code']==='schedule_collection_unresolved'){
                // Keep the Core incident wire identity stable across producer/observer and retries.
                $i['code']='schedule_overdue';$out[]=$i;continue;
            }
            if(in_array($i['code'],['schedule_authorization_failed','schedule_resource_access_failed','schedule_overdue','schedule_budget_exhausted'],true))continue;
            if($i['code']==='connection_authorization_failed'&&isset($connectionsWithSchedules[$i['connection_id']]))continue;
            $out[]=$i;
        }
        return $out;
    }
}
