<?php
use Fator3\LinkedIn as S;
if(!class_exists(S\ServiceAudit::class))return;
/** Contract test double only. This does not implement or modify the MCP package. */
final class ServiceAuditContractFixture {
 public static array $events=[];
 public static string $mode='normal';
 public static function register($d): array {expect($d===f3_linkedin_service_audit_descriptor());return ['contract'=>S\ServiceAudit::CONTRACT,'provider'=>S\Config::SLUG,'registered'=>true];}
 public static function status($provider,$identity): array {
  if(self::$mode==='status_throw')throw new RuntimeException('Synthetic central unavailable');
  $r=['contract'=>S\ServiceAudit::CONTRACT,'provider'=>$provider,'registered'=>self::$mode!=='unregistered'];
  if(!$identity)return $r;
  $key=$identity['principal_ref'].':'.$identity['operation_id'];$e=self::$events[$key]??null;
  return $r+['recorded'=>$e!==null,'event_sha256'=>self::$mode==='wrong_receipt'?str_repeat('f',64):($e?S\Management::revision($e):'')];
 }
 public static function receive($event): void {
  if(self::$mode==='event_throw')throw new RuntimeException('Synthetic receiver failed');
  if(self::$mode==='drop')return;
  $identity=array_intersect_key($event,array_flip(['provider','consumer_id','principal_ref','grant_revision','operation_id']));
  $proof=f3_linkedin_introspect_service_grant($identity);
  expect($proof['valid']&&$proof['event']===$event,'Contract fixture rejects unknown/forged event');
  self::$events[$event['principal_ref'].':'.$event['operation_id']]=$event;
 }
}
wp_set_current_user(1);$capiMode='normal';$capiMutation=null;add_filter('pre_http_request',$capiFixture,0,3);
$g=S\Conversions::grant();$current=S\Connections::get('conversions');
$g=ncall('save-conversion-grant',['consumer_id'=>S\Conversions::CONSUMER,'expected_revision'=>$g['revision'],'enabled'=>true,'connection_id'=>'conversions','account_id'=>'222','conversion_id'=>'67890','expected_connection_revision'=>$current['revision']]);$serviceRef=$g['destination_ref'];
$events070=[];$human070=[];$capture070=static function($e)use(&$events070){$events070[]=$e;};$captureHuman070=static function($e)use(&$human070){$human070[]=$e;};add_action(S\ServiceAudit::HOOK,$capture070);add_action('f3_linkedin_mutation_recorded',$captureHuman070);
function sid070(array $r): array {return S\Store::get('conversion_event',$r['operation_id'])['value']['service_identity'];}
function mutate070(string $bucket,string $key,callable $change,callable $run): void {
 $r=S\Store::get($bucket,$key);$v=$r['value'];$new=$change($v);S\Store::put($bucket,$key,$new,$r['revision']);
 try{$run();}finally{$now=S\Store::get($bucket,$key);S\Store::put($bucket,$key,$v,$now['revision']);}
}
check('070 descriptor and schema are public, closed and read-only',function(){need_abilities();
 $d=f3_linkedin_service_audit_descriptor();expect($d['introspector']==='f3_linkedin_introspect_service_grant'&&$d['reader']==='linkedin/get-service-write-operation');
 expect(count(S\Schemas::all())===(version_compare(lab_version(),'0.15.0','>=')?(version_compare(lab_version(),'0.17.0','>=')?99:(version_compare(lab_version(),'0.16.0','>=')?98:97)):(version_compare(lab_version(),'0.12.0','>=')?93:(version_compare(lab_version(),'0.11.0','>=')?90:81))));$a=wp_get_ability($d['reader']);expect($a->get_meta()['annotations']['readonly']===true);expect(S\Schemas::all()['get-service-write-operation']['additionalProperties']===false);
 expect(!isset(S\Schemas::all()['introspect-service-grant'])&&!isset(S\Schemas::all()['emit-service-event']));
});
$central070=version_compare((string)lab_companion('wp-mcp-fator3/wp-mcp-fator3.php'),'0.28.0','>=');$GLOBALS['central070']=$central070;
check('070 service audit availability matches the actual MCP consumer; isolated mode never claims it',function()use($central070){expect(S\ServiceAudit::capabilities()['central_audit']===($central070?'service_provider_registered':'service_principal_unsupported'));expect(S\ServiceAudit::capabilities()['central_registered']===$central070);if(class_exists('Fator3\\McpFiles\\MutationAudit'))expect(Fator3\McpFiles\MutationAudit::capabilities()['contract']==='mutation-audit/1.0.0');});
check('070 user zero emits bounded service event with no human mutation or identity switch',function()use($serviceRef,&$events070,&$human070){
 $n=count($events070);$h=count($human070);wp_set_current_user(0);try{$r=(new S\ConversionDelivery())->sendBound(cpayload('070-zero'),$serviceRef);expect(get_current_user_id()===0);}finally{wp_set_current_user(1);}
 expect($r['status']==='entregue'&&$r['central_audit']===($GLOBALS['central070']?'recorded':'service_principal_unsupported'),wp_json_encode($r));expect(count($events070)===$n+1&&count($human070)===$h);$GLOBALS['result070']=$r;$GLOBALS['identity070']=sid070($r);$GLOBALS['payload070']=cpayload('070-zero');
 $event=end($events070);expect(count($event)===10&&$event['consumer_id']==='site-core-conversions');
 foreach(['user_id','connection_id','account_id','conversion_id','payload','Synthetic','firstName',str_repeat('a',64),'synthetic-first-party'] as $bad)expect(!str_contains(wp_json_encode($event),$bad),$bad);
});
check('0100 benign rename preserves existing service receipt identity',function(){$c=S\Connections::get('conversions');ncall('save-connection',['connection_id'=>$c['id'],'expected_revision'=>$c['revision'],'label'=>'Membro · Aplicativo renomeado']);expect(f3_linkedin_introspect_service_grant($GLOBALS['identity070'])['valid']);});
check('070 local introspector works as zero and administrative read has no HTTP or database writes',function(){
 $i=$GLOBALS['identity070'];$n=count($GLOBALS['capiCalls']);global $wpdb;$writes=[];$spy=static function($sql)use(&$writes){if(preg_match('/^\s*(INSERT|UPDATE|DELETE|REPLACE|ALTER|CREATE|DROP|TRUNCATE)/i',$sql))$writes[]=$sql;return $sql;};add_filter('query',$spy);
 try{wp_set_current_user(0);$r=f3_linkedin_introspect_service_grant($i);expect($r['valid']);expect(get_current_user_id()===0);wp_set_current_user(1);$read=ncall('get-service-write-operation',$i);expect($read['principal_type']==='service'&&$read['before']['status']==='nao_enviado'&&$read['after']['status']==='entregue');expect($r['event_sha256']===$read['event_sha256']);}finally{wp_set_current_user(1);remove_filter('query',$spy);}
 expect($writes===[]&&count($GLOBALS['capiCalls'])===$n,'Read must be local and side-effect-free');
});
check('070 subscriber and zero cannot read service details',function(){foreach([0,$GLOBALS['editor']] as $id){wp_set_current_user($id);try{nbad('get-service-write-operation',$GLOBALS['identity070'],'not_authorized');}finally{wp_set_current_user(1);}}});
check('070 unrelated administrator cannot read another grant owner journal',function(){
 $id=wp_create_user('service-other-admin','synthetic-unused-password','service-admin@example.invalid');$u=new WP_User($id);$u->set_role('administrator');wp_set_current_user($id);try{nbad('get-service-write-operation',$GLOBALS['identity070'],'not_authorized');}finally{wp_set_current_user(1);}
});
check('070 identity spoof, extra fields and service reader for human write fail closed',function(){
 foreach(['principal_ref','grant_revision','operation_id'] as $key){$i=$GLOBALS['identity070'];$i[$key]=str_repeat('e',64);expect(!f3_linkedin_introspect_service_grant($i)['valid']);}
 foreach(['provider'=>'other-provider','consumer_id'=>'other-consumer','callback'=>'file:///synthetic'] as $key=>$v){$i=$GLOBALS['identity070'];$i[$key]=$v;expect(!f3_linkedin_introspect_service_grant($i)['valid']);}
 $r=S\Store::get('conversion_event',$GLOBALS['identity070']['operation_id']);$v=$r['value'];$v['service']=false;$key=str_repeat('d',64);S\Store::put('conversion_event',$key,$v,0);$i=$GLOBALS['identity070'];$i['operation_id']=$key;expect(!f3_linkedin_introspect_service_grant($i)['valid']);
});
check('070 revoked local scope, credential proof and expired proof deny detail',function(){
 foreach(['scope','binding','expired'] as $kind)mutate070('token_proof','conversions',static function($v)use($kind){if($kind==='scope')$v['scopes']=['r_ads'];elseif($kind==='binding')$v['binding']=str_repeat('0',64);else $v['expires_at']=time()-1;return $v;},static function()use($kind){expect(!f3_linkedin_introspect_service_grant($GLOBALS['identity070'])['valid']);nbad('get-service-write-operation',$GLOBALS['identity070'],$kind==='expired'?'token_expired':'service_scope_unverified');});
});
check('070 revoked grant blocks detail without deleting journal or emitting replay',function(){
 $i=$GLOBALS['identity070'];$g=S\Conversions::grant();ncall('save-conversion-grant',['consumer_id'=>S\Conversions::CONSUMER,'expected_revision'=>$g['revision'],'enabled'=>false]);expect(!f3_linkedin_introspect_service_grant($i)['valid']);nbad('get-service-write-operation',$i,'service_grant_inactive');expect(S\Store::get('conversion_event',$i['operation_id'])!==null);
});
$g=S\Conversions::grant();$g=ncall('save-conversion-grant',['consumer_id'=>S\Conversions::CONSUMER,'expected_revision'=>$g['revision'],'enabled'=>true,'connection_id'=>'conversions','account_id'=>'222','conversion_id'=>'67890','expected_connection_revision'=>S\Connections::get('conversions')['revision']]);$serviceRef=$g['destination_ref'];
check('070 regrant never revives old service identities',function(){expect(!f3_linkedin_introspect_service_grant($GLOBALS['identity070'])['valid']);});
check('070 hypothetical central fixture admits descriptor and confirms exact event receipt',function()use($serviceRef){
 do_action('f3_mcp_register_mutation_service_audit',S\ServiceAudit::CONTRACT,[ServiceAuditContractFixture::class,'register'],[ServiceAuditContractFixture::class,'status']);add_action(S\ServiceAudit::HOOK,[ServiceAuditContractFixture::class,'receive']);
 wp_set_current_user(0);try{$r=S\Conversions::sendBound(cpayload('070-fixture-confirmed'),$serviceRef);}finally{wp_set_current_user(1);}
 expect($r['status']==='entregue'&&$r['central_audit']==='recorded',wp_json_encode($r));$GLOBALS['fixture070']=$r;$GLOBALS['fixtureIdentity070']=sid070($r);
});
check('070 incidental user does not become service principal or emit human event',function()use($serviceRef,&$human070){$n=count($human070);wp_set_current_user($GLOBALS['editor']);try{$r=S\Conversions::sendBound(cpayload('070-incidental'),$serviceRef);expect(get_current_user_id()===$GLOBALS['editor']);}finally{wp_set_current_user(1);}expect($r['status']==='entregue'&&count($human070)===$n);expect(sid070($r)['principal_ref']===$GLOBALS['fixtureIdentity070']['principal_ref']);});
check('070 confirmed and uncertain replay never sends or reemits service event',function()use($serviceRef,&$events070){
 global $capiMode;foreach(['normal','timeout'] as $mode){$capiMode=$mode;$p=cpayload('070-replay-'.$mode);$r=S\Conversions::sendBound($p,$serviceRef);$n=csendCount();$events=count($events070);$id=sid070($r);$again=S\Conversions::sendBound($p,$serviceRef);expect($again['replayed']&&csendCount()===$n&&count($events070)===$events&&sid070($again)===$id);if($mode==='timeout')expect($again['status']==='incerto');}$capiMode='normal';
});
check('070 emitted event is not confused with central persistence or forged receipt',function()use($serviceRef){
 foreach(['drop'=>'service_record_unconfirmed','wrong_receipt'=>'service_record_unconfirmed','unregistered'=>'service_provider_not_registered','status_throw'=>'service_provider_not_registered','event_throw'=>'service_event_failed'] as $mode=>$status){ServiceAuditContractFixture::$mode=$mode;$p=cpayload('070-central-'.$mode);$r=S\Conversions::sendBound($p,$serviceRef);expect($r['status']==='entregue'&&$r['central_audit']===$status,wp_json_encode($r));$n=csendCount();expect(S\Conversions::sendBound($p,$serviceRef)['replayed']&&csendCount()===$n);}ServiceAuditContractFixture::$mode='normal';
});
check('070 new reader respects actual MCP profile',function(){
 if(!class_exists('Fator3\\McpFiles\\ConnectionsAdmin'))return;
 $i=$GLOBALS['fixtureIdentity070'];Fator3\McpFiles\ConnectionsAdmin::save(['connection_id'=>'integration:user:1','user_id'=>1,'profile'=>'custom','abilities'=>'linkedin/status']);$a=wp_get_ability('linkedin/get-service-write-operation')->execute($i);expect(is_wp_error($a)||empty($a['success']));
 Fator3\McpFiles\ConnectionsAdmin::save(['connection_id'=>'integration:user:1','user_id'=>1,'profile'=>'custom','abilities'=>'linkedin/get-service-write-operation,linkedin/get-write-operation,linkedin/send-conversion-event,audit/get-operation']);$a=wp_get_ability('linkedin/get-service-write-operation')->execute($i);expect(!is_wp_error($a)&&$a['success'],is_wp_error($a)?$a->get_error_code():wp_json_encode($a));
});
check('070 existing human audit still excludes service event path',function()use($serviceRef,&$events070,&$human070){
 $i=['destination_ref'=>$serviceRef,'payload'=>cpayload('070-human')];$p=ncall('send-conversion-event',$i);$n=count($events070);$h=count($human070);$r=ncall('send-conversion-event',$i+['dry_run'=>false,'confirm'=>true,'confirm_token'=>$p['confirm_token']]);expect($r['status']==='entregue'&&count($events070)===$n&&count($human070)===$h+1);expect(!isset(S\Store::get('conversion_event',$r['operation_id'])['value']['service_identity']));
});
check('070 context revision change during preflight refuses POST and event',function()use($serviceRef,&$events070){
 global $capiMutation;$n=csendCount();$events=count($events070);$capiMutation=static function($path){if($path==='/rest/conversions/67890'){$g=S\Store::get('conversion_grant',S\Conversions::CONSUMER);S\Store::put('conversion_grant',S\Conversions::CONSUMER,$g['value'],$g['revision']);}};
 try{$r=S\Conversions::sendBound(cpayload('070-revision-race'),$serviceRef);expect($r['status']==='recusado'&&$r['code']==='service_grant_changed'&&csendCount()===$n&&count($events070)===$events,wp_json_encode($r));}finally{$capiMutation=null;}
});
check('070 stale grant revision remains denied even with unchanged selected asset',function(){expect(!f3_linkedin_introspect_service_grant($GLOBALS['fixtureIdentity070'])['valid']);});
check('070 changing selected asset denies old reference and does not erase audit history',function()use($serviceRef){
 $r=S\Conversions::sendBound(cpayload('070-selection'),$serviceRef);$i=sid070($r);$c=S\Connections::get('conversions');ncall('save-connection',['connection_id'=>'conversions','expected_revision'=>$c['revision'],'assets'=>['ads'=>[]]]);expect(!f3_linkedin_introspect_service_grant($i)['valid']);expect(S\Store::get('conversion_event',$r['operation_id'])!==null);
});
remove_filter('pre_http_request',$capiFixture,0);remove_action(S\ServiceAudit::HOOK,$capture070);remove_action(S\ServiceAudit::HOOK,[ServiceAuditContractFixture::class,'receive']);remove_action('f3_linkedin_mutation_recorded',$captureHuman070);
