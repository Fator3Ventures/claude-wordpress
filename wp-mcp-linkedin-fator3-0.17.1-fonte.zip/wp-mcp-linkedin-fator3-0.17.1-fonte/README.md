# Fator3 MCP LinkedIn 0.17.1 — fonte da entrega

Atualização direta da base aceita 0.16.0. Atende aos incrementos dos pedidos 18, 21, 22 e 23: diário paginado por conexão/estado, descoberta inicial em lote e adoção de assinaturas próprias 1.1, preservação de concessões não afetadas e retry limitado da leitura de leads após recusa de projeção opcional. A 0.17.0 foi intermediária de validação no Site-Teste; a 0.17.1 corrige sua coerência documental. Consulte o relatório próprio.

## Organização

- plugin/wp-mcp-linkedin-fator3/: runtime idêntico ao instalador.
- build/: código autoral, documentação instalada e build determinístico exclusivo LinkedIn.
- tests/native/requests017.php e fixtures017.php: novas regras e negativas; seed0170.php: base 0.16.0 operada pelo SDK 1.1.
- tests/native/ui0170.*: HTML/JS reais e REST autenticado via jsdom, incluindo o diário.
- tests/native/mcp-docs080.php: leitura integral MCP e coerência da versão corrente nos manuais.
- tests/core1680/: consumidor original adaptado à bancada; runtime Core não alterado.
- tools/lab.py e lab-release0171.example.json: laboratório descartável com dependências verificadas.
- evidence/release0171/: provas finais; evidence/release0170-intermediaria/: provas pertinentes da intermediária.
- inputs/0.17.1/: pedidos, normas revisão 5 e relatórios recebidos imutáveis com manifesto; entradas anteriores mantidas como histórico.
- planning/: planejamento prévio e evolução; impacts/: encaminhamentos técnicos próprios e histórico.
- history/: relatórios anteriores imutáveis.

## Reprodução

WordPress 6.4+, PHP 8.1.2+ de 64 bits, MySQL/MariaDB com InnoDB e bloqueios nomeados, criptografia autenticada. Bancada: WordPress 7.1.4, PHP 8.3.6, MySQL 8.0.46; mínimo exercitado WP 6.4/PHP 8.1.2. Integrados: Core 1.68.0, MCP 0.38.0, Google 0.26.0 e Meta 0.19.0. Pipedrive 0.5.0 extraído e identificado localmente, mas sem ativação por exigir PHP 8.3.36; coexistência ativa conferida no Site-Teste.

Execute python3 build/build.py com PHP do PATH ou F3_SOCIAL_PHP. O build inclui todos os documentos allowlisted no catálogo MCP e valida os 35 arquivos PHP. Instalador: 379078 bytes, SHA-256 e3a6c06d2c254a50af60e434a0575424e552ed4f62422ea1aabcff6bd591f1f9. build/dist fica fora do fonte.

Ajuste caminhos e credenciais do manifesto de exemplo para um MySQL descartável. O runner exige diretório vazio, cria schema próprio e remove somente esse schema. Dependências externas têm hashes no manifesto; não estão aninhadas neste ZIP. Não use banco compartilhado.

```bash
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li0171-new --order linkedin-integrated --tests requests017.php,mcp-docs080.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li0171-upgrade --order linkedin-integrated --origin upgrade --tests requests017.php,mcp-docs080.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li0171-min --order linkedin-only --wordpress wordpress_minimum --php php81 --tests requests017.php
```

O consumidor core1680.php, a regressão histórica e suite.php devem executar em laboratório separado dos casos requests017.php, que deixam grants sintéticos intencionalmente ativos. A matriz detalhada está em evidence/release0171/regression/environment.json. Upgrade usa baseline_linkedin 0.16.0; seed.php seleciona seed0170.php para essa base. Não instalar intermediária para executar esse caminho.

Para DOM, instale tests/dom/package-lock.json externamente, configure F3_JSDOM para jsdom 27.4.0 e CODEX_PRIMARY_RUNTIME_NODE para Node 24.22.1; execute ui0170.php sozinho em laboratório integrado limpo. Não é inspeção visual em navegador. HTTP do fornecedor é interceptado; homologação real permanece separada.

python3 tools/package-source.py --output-dir /diretorio/externo confere igualdade runtime/instalador e fecha a raiz versionada sem ZIPs internos. A cópia interna do relatório é anterior ao fechamento; o externo recebe o hash final do fonte. Não reescrever instalador fechado sem outra versão.
