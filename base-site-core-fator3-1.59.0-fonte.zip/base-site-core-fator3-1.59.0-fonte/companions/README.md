# Acompanhantes considerados — Core 1.59.0

Pacotes originais fornecidos separadamente, sem alteração pelo build Core. A seleção depende de contratos/capacidades e autorização; a matriz abaixo delimita a combinação examinada, sem homologar toda função dos acompanhantes.

| Pacote | Versão | Fronteira pertinente |
| --- | --- | --- |
| wp-mcp-fator3 | 0.34.0 | Autorização, schemas/documentação, upload privado idempotente, sondas e limitação de auditoria central comercial LinkedIn. |
| wp-mcp-google-fator3 | 0.22.0 | Aquisição 1.0/1.1, comercial 1.2, concessão por ação e extensão de consulta assíncrona 1.0; GA4 preservado. |
| wp-mcp-meta-fator3 | 0.13.0 | SDK Meta Ads e contratos Instagram preservados. |
| wp-mcp-linkedin-fator3 | 0.12.0 | Comercial 1.2, concessão/binding, diário local e aquisição preservada; sem extensão assíncrona Google. |
| wp-mcp-pipedrive-fator3 | 0.3.0 | Cliente Core 1.0 preservado; exige PHP 8.3.36. |

| Instalador recebido | Bytes | SHA-256 |
| --- | ---: | --- |
| wp-mcp-fator3-0.34.0-instalador.zip | 903878 | `5d96b6a33cfc4a7c729c106268f4bc9d8938b34384da022345d7b7dae611a295` |
| wp-mcp-google-fator3-0.22.0-instalador.zip | 856534 | `a84754409f89b7b9c7367c1d261c44ef93c2f6039b379c3ec5c6242ec7188ebd` |
| wp-mcp-meta-fator3-0.13.0-instalador.zip | 284069 | `3ecd6ee6f277c7581adc05b4fa38c46611e3232b4400bb4a4421956c9fba8ac1` |
| wp-mcp-linkedin-fator3-0.12.0-instalador.zip | 304948 | `19748e788190f371809db469a6de052a645e25f39fad1672606dc776234ec54c` |
| wp-mcp-pipedrive-fator3-0.3.0-instalador.zip | 59877 | `30fc784a552a89351900c169fad7300759163fb886b842f45ba807bb0977f657` |

Fontes novos: Google 0.22, 5989075 bytes, SHA-256 `1d9ba106eb9ababad67b964fa4ad44246acc27eeda3e83e7866ea57386d77abf`; LinkedIn 0.12, 1713239 bytes, SHA-256 `15c182cc89605cb1fc18121d8db81fd9008daa06cb787f7224a973d18f4f65d1`. Nomes importados podem conter `(1)`; esse sufixo local não altera a identidade. Os manifests de `inputs/1590` preservam os nomes e locais de extração originais. Os insumos anteriores permanecem referenciados em `inputs/1580`.

Google entrega um patch de consumidor sobre o arquivo Core 1.58 identificado por SHA-256 `84c429dda8697699357aa219ed028925811f0cfc86101ac3fd0edc7bdb683b20`, diff SHA-256 `a10ef8971a47ac38950e6759aa80b378380021a2e388f8fc1c23e252602d2eaa`. A incorporação Core 1.59 é revista e testada como release própria; não equivale a aprovar automaticamente o patch apenas por ter ensaio no produtor.

No laboratório, use os modos separados `core-only-mode1590.php`, `socials-only1590.php` e `site-1590-companions.php`. Reinicie o processo após mudar a seleção. Não desative pacotes do site compartilhado para reproduzir um caso. Pipedrive permanece inativo no PHP 8.3.6; seu mínimo não é reduzido pelo piso Core.

O impacto LinkedIn 0.12 → MCP foi preservado literalmente em `inputs/1590/wp-mcp-linkedin-fator3-0.12.0-impacto-wp-mcp-fator3.md`: MCP 0.34 não confirma auditoria central de `site-core-quality`. O diário/recibo local permanece, e a lacuna central não autoriza reenvio. O relatório Core registra esse encaminhamento recebido, sem reemiti-lo.

Testes usam dados/credenciais sintéticos e interceptação de transportes. Não incluir grants reais, logs brutos ou dados de clientes nos artefatos. Relatórios dos emissores, inventário remoto e provas próprias Core são categorias distintas. Contas reais, atribuição e auditoria central corrigida exigem seu aceite específico.
