# Fonte Core 1.59.0

Base direta canônica: Core 1.58.0, instalador de 2816484 bytes, SHA-256 `71bf6497a2f2e2c605baf64f0f82c273201915039506b58ac220fc572afbd5e4`; fonte de 4690094 bytes, SHA-256 `279b9609867b7459347d7bf1434b536073eb20fb2b996b4fdbcd6e644e37b50c`. A entrega 1.58 permanece imutável. Contrato administrativo 8.23.0 conservado; runtime canônico em `work/plugin/base-site-core-fator3`.

Esta rodada incorpora a consulta de recibos comerciais incertos entregue no retorno Google 0.22 e considera o produtor LinkedIn 0.12, no Pedido Core 323. Consulta vinculada preserva evento, ação, concessão e revisão, sem reingestão. A capacidade efetiva do produtor decide a disponibilidade. Os contratos de aquisição e o escopo anterior permanecem; o teste 322 conserva as dependências de limpeza individual.

Leia `docs/DOCUMENTACAO.md`, `RELEASE-1.59.0.md`, `AGENTES-1.59.0.md` e `RECONCILIACAO-COMERCIAL-1.59.md` no runtime. Os resultados próprios, implantação e aceites estão no relatório externo `base-site-core-fator3-1.59.0-relatorio.md`. Relatórios Google/LinkedIn são evidência dos emissores e não se somam aos testes próprios Core.

Plano anterior à implementação: `history/1590/PLANO.md`. Entradas e retornos: `inputs/1590`; provas desta rodada: `evidence/1590`. A documentação anterior substituída foi preservada em `history/docs-ate-1.58.0`, e os guias/release 1.58 continuam disponíveis para as funcionalidades vigentes. Diretórios históricos não representam testes reexecutados nesta rodada. Norma 02 revisão 5 rege encaminhamentos: respostas/desfechos ficam no relatório principal, sem impacto novo apenas para encerramento.

Reprodução em `build/README.md`; acompanhantes imutáveis e identidades em `build/COMPANIONS.md`. A árvore final contém a incorporação, sem exigir reaplicar o patch recebido. Fontes/runtimes de terceiros, laboratórios, node_modules, dumps, logs brutos e ZIPs aninhados ficam fora do fonte Core. Manifestos preservam os insumos.

Mínimos Core: WordPress 7.1.2/PHP 8.3.6 de 64 bits. Pipedrive 0.3 exige PHP 8.3.36; não ativar no piso inferior do Core. O ciclo padrão é 1.58 → 1.59; o salto remoto desde 1.57.1 recebe prova separada. O relatório distingue o que foi executado de procedimentos ainda previstos.

A cópia do relatório dentro do fonte antecede seu próprio fechamento e conserva marcadores de tamanho/hash desse ZIP, preenchidos apenas no relatório externo. Isso evita hash circular. Publicação GitHub, contas comerciais e implantação na frota não são inferidas da entrega ou dos testes locais.
