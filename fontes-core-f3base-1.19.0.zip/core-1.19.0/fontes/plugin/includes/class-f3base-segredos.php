<?php
/** Segredos de terceiros cifrados no banco, vinculados ao site e ao nome da opção. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Segredos {
    const PREFIXO='f3sec:v1:';
    const NOMES=array('f3base_clarity_api_token','f3base_meta_capi_token','f3base_pipedrive_token','f3base_anuncios_meta_token','f3base_anuncios_google_chave','f3base_anuncios_linkedin_token');
    public static function gerenciado(string $nome): bool{return in_array($nome,self::NOMES,true);}
    public static function chave(string $nome): string {return hash_hkdf('sha256',wp_salt('secure_auth'),32,'f3base:segredos:v1:'.$nome,'f3base-secretbox');}
    public static function cifrar(string $nome,string $valor): string {
        if($valor===''){return '';}
        if(!self::gerenciado($nome)||!function_exists('sodium_crypto_secretbox')){throw new RuntimeException('cifra_indisponivel');}
        $nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return self::PREFIXO.base64_encode($nonce.sodium_crypto_secretbox($valor,$nonce,self::chave($nome)));
    }
    public static function abrir(string $nome,?string $cipher=null): string {
        $cipher=$cipher??get_option($nome,'');if(!is_string($cipher)||$cipher===''||!self::gerenciado($nome)||!str_starts_with($cipher,self::PREFIXO)||!function_exists('sodium_crypto_secretbox_open')){return '';}
        $v=base64_decode(substr($cipher,strlen(self::PREFIXO)),true);
        if($v===false||strlen($v)<SODIUM_CRYPTO_SECRETBOX_NONCEBYTES+SODIUM_CRYPTO_SECRETBOX_MACBYTES){return '';}
        try{$p=sodium_crypto_secretbox_open(substr($v,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),substr($v,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),self::chave($nome));return is_string($p)?$p:'';}catch(Throwable $e){return '';}
    }
    public static function status(string $nome): array {
        $v=get_option($nome,'');$present=is_string($v)&&$v!=='';
        return array('presente'=>$present,'versao'=>$present&&str_starts_with($v,self::PREFIXO)?1:null,'estado'=>!$present?'ausente':(self::abrir($nome)!==''?'disponivel':'recadastrar'));
    }
    public static function migrar(): array {
        $out=array();foreach(self::NOMES as $nome){$f=F3Base_Options::fotografia_bruta($nome);if($f['erro']){$out[$nome]='leitura_falhou';continue;}$v=$f['valor'];
            if(!$f['existe']||$v===''||(is_string($v)&&str_starts_with($v,self::PREFIXO))){$out[$nome]=self::status($nome)['estado'];continue;}
            if(!is_string($v)||!function_exists('sodium_crypto_secretbox')){$out[$nome]='recadastrar';continue;}
            $r=F3Base_Options::gravar($nome,$v,F3Base_Options::ORIGEM_MIGRACAO,$f['revisao']);
            $out[$nome]=!empty($r['persisted'])&&hash_equals($v,self::abrir($nome))?'migrado':'recadastrar';
        }return $out;
    }
}
