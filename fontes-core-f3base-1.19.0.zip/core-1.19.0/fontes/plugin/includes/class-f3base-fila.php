<?php
/** Primitivas comuns; cada destino conserva seu contrato, retenção e estados. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Fila {
    private static array $acordar=array();
    /** O adaptador fornece SQL fechado e valores; retorno estrito evita duas posses. */
    public static function reservar_condicional(string $sql,array $args): bool {global $wpdb;return $wpdb->query($wpdb->prepare($sql,...$args))===1;}
    public static function possui(?array $row,string $coluna,string $token,array $estados): bool {return $row&&$token!==''&&isset($row[$coluna])&&hash_equals($token,(string)$row[$coluna])&&in_array($row['estado'],$estados,true);}
    public static function lease(): string {return wp_generate_uuid4();}
    public static function restante(float $inicio,int $segundos): int {return max(0,(int)floor(max(1,min(30,$segundos))-(microtime(true)-$inicio)));}
    public static function agendar(string $hook,int $quando=0): bool {
        $quando=$quando?:time();$old=wp_next_scheduled($hook);$ok=$old&&$old<=$quando;
        if(!$ok){$ok=(bool)wp_schedule_single_event($quando,$hook);if($ok&&$old){wp_unschedule_event($old,$hook);}}
        if($ok&&!(defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON)&&$quando<=time()+1&&!isset(self::$acordar[$hook])){self::$acordar[$hook]=true;add_action('shutdown',static function(){if(!get_transient('f3base_filas_acordando')){set_transient('f3base_filas_acordando',1,15);spawn_cron();}});}
        return (bool)$ok;
    }
    public static function percentil(array $v,float $p): ?int {if(!$v){return null;}sort($v,SORT_NUMERIC);return (int)$v[max(0,(int)ceil(count($v)*$p)-1)];}
}
