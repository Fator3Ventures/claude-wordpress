<?php
/** Partial writes preserve raw untouched fields and validate related domain fields. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Config_Mescla {
    public static function preparar(array $d,$atual,$parcial): array {
        if(($d['campo']??'')!=='grupo'||!is_array($atual)||!is_array($parcial)){return array('ok'=>false,'codigo'=>'mescla_nao_aplicavel','erros'=>array());}
        $schema=F3Base_Config_Contrato::schema_entrada($d);
        $schema['additionalProperties']=false;
        $errors=self::erros_schema($parcial,$schema,'',true);
        if($errors){return array('ok'=>false,'codigo'=>'entrada_parcial_invalida','erros'=>$errors);}
        return array('ok'=>true,'valor'=>self::mesclar($atual,$parcial,$schema));
    }
    private static function mesclar(array $old,array $new,array $schema): array {
        foreach($new as $k=>$v){$s=$schema['properties'][$k]??array();
            if(is_array($v)&&is_array($old[$k]??null)&&($s['type']??'')==='object'&&isset($s['properties'])){$old[$k]=self::mesclar($old[$k],$v,$s);}
            else{$old[$k]=$v;}
        }return $old;
    }
    /** Overlays only explicitly touched leaves. Arrays replace, never merge by index. */
    public static function preservar(array $raw,array $normalized,array $delta,array $schema): array {
        foreach($delta as $k=>$v){$s=$schema['properties'][$k]??array();
            if(is_array($v)&&is_array($raw[$k]??null)&&is_array($normalized[$k]??null)&&($s['type']??'')==='object'&&isset($s['properties'])){$raw[$k]=self::preservar($raw[$k],$normalized[$k],$v,$s);}
            elseif(array_key_exists($k,$normalized)){$raw[$k]=$normalized[$k];}
        }return $raw;
    }
    public static function escopo(string $nome,array $valor,array $delta,array $d): array {
        $keys=array_keys($delta);$grupos=array();
        foreach($d['dependencias_config']??array() as $dep){$g=array_values(array_filter(array($dep['campo']??null,$dep['requer']??null,$dep['outro_campo']??null),'is_string'));if(count($g)>1){$grupos[]=$g;}}
        if($nome==='f3base_seo_entidade'){$grupos[]=array('cnpj','endereco');$grupos[]=array('organizacao_mae','organizacoes_filhas');}
        do{$before=$keys;foreach($grupos as $g){if(array_intersect($keys,$g)){$keys=array_values(array_unique(array_merge($keys,$g)));}}}while($before!==$keys);
        return array_intersect_key($valor,array_flip($keys));
    }
    /** Explicit path diagnostics; no raw values in error text. */
    public static function deduplicar(array $erros): array {$out=array();foreach($erros as $e){$key=wp_json_encode(array($e['codigo']??'', $e['caminho']??$e['campo']??'', $e['causa']??$e['motivo']??''));$out[$key]=$e;}return array_values($out);}
    public static function erros_schema($v,array $s,string $path='',bool $partial=false): array {
        $out=array();$types=(array)($s['type']??array());
        if(is_array($v)&&in_array('object',$types,true)&&isset($s['properties'])){
            if(!$partial){foreach($s['required']??array() as $k){if(!array_key_exists($k,$v)){$out[]=array('caminho'=>self::path($path,$k),'codigo'=>'campo_obrigatorio','motivo'=>'Campo obrigatório ausente.');}}}
            foreach($v as $k=>$value){
                if(isset($s['properties'][$k])){$out=array_merge($out,self::erros_schema($value,$s['properties'][$k],self::path($path,$k),$partial));}
                elseif(($s['additionalProperties']??true)===false){$out[]=array('caminho'=>self::path($path,$k),'codigo'=>'campo_desconhecido','motivo'=>'Campo fora do contrato. Uma lista enviada substitui a anterior; omitir esta chave remove o dado.');}
            }
        }elseif(is_array($v)&&in_array('array',$types,true)&&isset($s['items'])){
            foreach($v as $i=>$value){$out=array_merge($out,self::erros_schema($value,$s['items'],$path.'['.$i.']'));}
        }
        if($out){return $out;}
        $check=$partial?self::schema_parcial($s):$s;
        $r=rest_validate_value_from_schema($v,$check,$path);
        return is_wp_error($r)?array(array('caminho'=>$path,'codigo'=>$r->get_error_code(),'motivo'=>'Valor incompatível com o tipo ou limite declarado.')):array();
    }
    private static function schema_parcial(array $s): array {
        if(in_array('object',(array)($s['type']??array()),true)){unset($s['required']);foreach($s['properties']??array() as $k=>$child){$s['properties'][$k]=self::schema_parcial($child);}}
        // Array items are complete replacements and keep their required fields.
        return $s;
    }
    private static function path(string $path,$k): string {return $path===''?(string)$k:$path.'.'.$k;}
    public static function removidos($antes,$depois,string $path=''): array {
        if(!is_array($antes)||!is_array($depois)){return array();}$r=array();
        foreach($antes as $k=>$v){$p=is_int($k)?$path.'['.$k.']':self::path($path,$k);if(!array_key_exists($k,$depois)){$r[]=$p;}else{$r=array_merge($r,self::removidos($v,$depois[$k],$p));}}return $r;
    }
}
