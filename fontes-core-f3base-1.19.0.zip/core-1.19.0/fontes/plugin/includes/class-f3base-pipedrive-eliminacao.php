<?php
/** Eliminação remota limitada à autoria e exclusividade comprovadas em nova leitura. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Eliminacao {
 public static function iniciar(): void {add_action(F3Base_Pipedrive_Fila::EVENTO,array(__CLASS__,'processar'),20);}
 public static function prova(string $step,array $data): array {
  $keys=array('pessoa'=>array('id','name','emails','phones','owner_id','org_id','add_time','update_time'),'lead'=>array('id','title','person_id','organization_id','owner_id','origin_id','label_ids','add_time','update_time','is_archived','was_seen'),'nota'=>array('id','content','person_id','lead_id','deal_id','add_time','update_time'),'atividade'=>array('id','subject','type','person_id','lead_id','deal_id','owner_id','note','done','due_date','add_time','update_time'))[$step]??array('id','name','add_time','update_time');
  $v=array_intersect_key($data,array_flip($keys));foreach($data as $k=>$value){if(preg_match('/^[a-f0-9]{40}$/D',(string)$k)){$v[$k]=$value;}}
  return array('hash'=>F3Base_Leads_Repositorio::hash($v),'campos'=>array_keys($v),'em'=>time());
 }
 private static function igual(string $step,array $data,array $proof): bool {
  if(empty($proof['hash'])||empty($proof['campos'])||(in_array($step,array('pessoa','lead'),true)&&!in_array('update_time',$proof['campos'],true))){return false;}$selected=array_intersect_key($data,array_flip($proof['campos']));
  return count($selected)===count($proof['campos'])&&hash_equals($proof['hash'],F3Base_Leads_Repositorio::hash($selected));
 }
 private static function apagar(string $path): array {$r=F3Base_Pipedrive_Api::pedir('DELETE',$path);return !empty($r['ok'])||($r['http']??0)===404?array('ok'=>true):$r;}
 public static function processar(): array {
  global $wpdb;F3Base_Pipedrive_Api::iniciar_lote();$cfg=F3Base_Pipedrive_Api::configuracao_lote();$state=(array)F3Base_Options::fotografia_bruta('f3base_pipedrive_estado')['valor'];if(empty($cfg['ativo'])||!F3Base_Pipedrive_Api::lote_atual()||!F3Base_Integracoes::pipedrive_verificado($state)){return array('ok'=>true,'codigo'=>'aguarda_integracao');}
  $account=$state['dominio'].'|'.$state['conta_id'].'|'.$state['instalacao'];$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE codigo='eliminacao_remota_pendente' AND estado NOT IN ('enviando','cancelando') ORDER BY atualizado_em LIMIT 3",F3Base_Pipedrive_Fila::tabela()),ARRAY_A);$n=0;
  foreach($rows as $row){if($row['conta']!==$account){continue;}$j=json_decode($row['journal'],true)?:array();$clean=$j['eliminacao_remota']??array();$marker='f3base:'.$row['chave'];$pending=false;$review=false;$clean['motivos']=array();
   foreach(array('nota'=>'v1/notes','atividade'=>'v2/activities') as $step=>$path){$id=$j['criados'][$step]??null;if(!$id){if($row['etapa']===$step){$review=true;$clean['motivos'][]=$step.'_sem_confirmacao';}continue;}if(in_array($step,$clean['removidos']??array(),true)){continue;}$r=F3Base_Pipedrive_Api::pedir('GET',$path.'/'.(int)$id);if(($r['http']??0)===404){$clean['removidos'][]=$step;continue;}if(empty($r['ok'])){$pending=true;continue;}$data=$r['data'];$text=$step==='nota'?($data['content']??''):($data['note']??'');
    if(!str_contains(wp_strip_all_tags($text),$marker.':'.$step)||!self::igual($step,$data,$j['provas_criacao'][$step]??array())){$review=true;$clean['motivos'][]=$step.'_alterada_ou_sem_prova';continue;}
    $r=self::apagar($path.'/'.(int)$id);if(!empty($r['ok'])){$clean['removidos'][]=$step;}else{$pending=true;}
   }
   $person=(int)($j['pessoa']??0);$ownlead=$j['criados']['lead']??'';$leadremoved=in_array('lead',$clean['removidos']??array(),true);
   if(!$pending&&!$review&&$ownlead&&!$leadremoved){
    $r=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.$ownlead);
    if(($r['http']??0)===404){$review=true;$clean['motivos'][]='lead_ausente_ou_convertido';}
    elseif(empty($r['ok'])){$pending=true;}
    elseif(($r['data']['origin_id']??'')!==$marker||!self::igual('lead',$r['data'],$j['provas_criacao']['lead']??array())||!empty($r['data']['is_archived'])||!empty($r['data']['was_seen'])){$review=true;$clean['motivos'][]='lead_alterado_ou_compartilhado';}
    else {
     $notes=F3Base_Pipedrive_Api::listar('v1/notes',array('lead_id'=>$ownlead));$acts=F3Base_Pipedrive_Api::listar('v2/activities',array('lead_id'=>$ownlead));
     if(empty($notes['ok'])||empty($acts['ok'])){$pending=true;}
     elseif($notes['data']||$acts['data']){$review=true;$clean['motivos'][]='lead_com_historico_independente';}
     else{$r=self::apagar('v1/leads/'.$ownlead);if(!empty($r['ok'])){$clean['removidos'][]='lead';$leadremoved=true;}else{$pending=true;}}
    }
   }
   if(!$pending&&!$review&&$person&&!empty($j['criados']['pessoa'])&&(!$ownlead||$leadremoved)&&!in_array('pessoa',$clean['removidos']??array(),true)){
    $counts=array('open_deals_count','related_open_deals_count','closed_deals_count','related_closed_deals_count','participant_open_deals_count','participant_closed_deals_count','email_messages_count','activities_count','files_count','notes_count','followers_count');
    $r=F3Base_Pipedrive_Api::pedir('GET','v2/persons/'.$person,array('include_fields'=>implode(',',$counts)));
    if(($r['http']??0)===404){$clean['removidos'][]='pessoa';}
    elseif(empty($r['ok'])){$pending=true;}
    elseif(!self::igual('pessoa',$r['data'],$j['provas_criacao']['pessoa']??array())||count(array_intersect_key($r['data'],array_flip($counts)))!==count($counts)||array_filter(array_intersect_key($r['data'],array_flip($counts)),static fn($v)=>!is_numeric($v)||(int)$v!==0)){$review=true;$clean['motivos'][]='pessoa_alterada_compartilhada_ou_cobertura_incompleta';}
    else{$links=F3Base_Pipedrive_Api::listar('v1/leads',array('person_id'=>$person));if(empty($links['ok'])){$pending=true;}elseif($links['data']){$review=true;$clean['motivos'][]='pessoa_com_outro_lead';}else{$r=self::apagar('v2/persons/'.$person);if(!empty($r['ok'])){$clean['removidos'][]='pessoa';}else{$pending=true;}}}
   }
   if(($person&&!in_array('pessoa',$clean['removidos']??array(),true))||(!empty($j['oportunidade'])&&!$leadremoved)||!empty($j['organizacao'])||$row['etapa']){$review=true;}
   $clean['estado']=$pending?'pendente':($review?'revisao_comercial_necessaria':'concluida');$clean['verificada_em']=time();$clean['motivos']=array_values(array_unique($clean['motivos']));$j['eliminacao_remota']=$clean;
   $wpdb->update(F3Base_Pipedrive_Fila::tabela(),array('journal'=>wp_json_encode($j),'codigo'=>$pending?'eliminacao_remota_pendente':($review?'eliminacao_requer_revisao':'eliminacao_remota_concluida'),'atualizado_em'=>time()),array('chave'=>$row['chave'],'atualizado_em'=>$row['atualizado_em'],'lease'=>$row['lease']));++$n;
  }return array('ok'=>true,'processados'=>$n);
 }
}
