/*! F3 Base — formulários com envio idempotente, contexto e renovação de token. GPL-2.0-or-later. */
(function(){
 'use strict';
 var estados=new WeakMap();
 function mensagem(f,k,padrao){try{var m=JSON.parse(f.dataset.mensagens||'{}');return typeof m[k]==='string'&&m[k].trim()?m[k]:padrao;}catch(e){return padrao;}}
 function conferirArquivos(f){
  var total=0,quantidade=0,post=Number(f.dataset.postMaxBytes)||0,maxUploads=Number(f.dataset.maxFileUploads)||0,valido=true,inputs=Array.from(f.querySelectorAll('input[type="file"]'));
  inputs.forEach(function(el){el.setCustomValidity('');el.removeAttribute('aria-invalid');var files=Array.from(el.files||[]),max=Number(el.dataset.maxBytes)||0,limite=Number(el.dataset.maxFiles)||5;
   quantidade+=files.length;files.forEach(function(file){total+=file.size;});
   if(files.length>limite||files.some(function(file){return max>0&&file.size>max;})){el.setCustomValidity(mensagem(f,'arquivo_limite','Confira o tamanho e a quantidade de arquivos.'));el.setAttribute('aria-invalid','true');valido=false;}
  });
  // Arquivos sozinhos são um limite inferior do multipart. O PHP confere o corpo completo.
  if(inputs.length&&((post>0&&total>post)||(maxUploads>0&&quantidade>maxUploads))){inputs[0].setCustomValidity(mensagem(f,'arquivo_limite','O envio excede o limite total do servidor.'));inputs[0].setAttribute('aria-invalid','true');valido=false;}
  return valido;
 }
 document.addEventListener('change',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(f&&e.target.type==='file'){conferirArquivos(f);}});

 function id(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(x){return ('0'+x.toString(16)).slice(-2);}).join('');}
 function preparar(f){if(!f.dataset.f3baseInstancia){f.elements.submissao.value=id();f.elements.token.value='';f.dataset.f3baseInstancia='1';}return f.elements.submissao.value;}
 window.f3baseFormularioInstancia=preparar;
 function estado(f){preparar(f);var s=estados.get(f);if(!s){s={iniciado:false,enviando:false,token:null,aceito:false,carga:null,teste:null};estados.set(f,s);}return s;}
 function evento(f,n,d){f.dispatchEvent(new CustomEvent('f3base-formulario-'+n,{bubbles:true,detail:d||{}}));}
 function valido(v){try{return Number(JSON.parse(atob(v.split('.')[0])).t)+7200>Date.now()/1000+60;}catch(e){return false;}}
 function pedir(url,op){var control=new AbortController(),timer=setTimeout(function(){control.abort();},15000);op.signal=control.signal;return fetch(url,op).finally(function(){clearTimeout(timer);});}
 function token(f,force){var s=estado(f);if(!force&&valido(f.elements.token.value)){return Promise.resolve();}if(s.token){return s.token;}
  s.token=pedir(f.dataset.endpoint+'token',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({formulario:f.dataset.f3baseFormulario,pagina:Number(f.dataset.pagina),submissao:f.elements.submissao.value})}).then(function(r){return r.json();}).then(function(r){if(!r.ok||!valido(r.token)){throw new Error(mensagem(f,'token_indisponivel','Não foi possível preparar o envio. Tente novamente.'));}f.elements.token.value=r.token;}).finally(function(){s.token=null;});return s.token;
 }
 document.addEventListener('invalid',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(f){estado(f);e.target.setAttribute('aria-invalid','true');var out=f.querySelector('.f3base-formulario-resultado');if(out){out.textContent=mensagem(f,'validacao','Confira os campos destacados.');}evento(f,'erro',{codigo:'validacao_navegador'});}},true);
 document.addEventListener('input',function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');if(!f){return;}if(e.target.validity&&e.target.validity.valid){e.target.removeAttribute('aria-invalid');}var s=estado(f);if(!s.iniciado){s.iniciado=true;evento(f,'inicio',{formulario:f.dataset.f3baseFormulario});token(f).catch(function(){});}});
 function contexto(f,d,s){var c=window.f3baseContexto,a=window.f3baseAnalise&&window.f3baseAnalise.contexto();s.teste=c?c.teste():false;
  var oferta=window.f3baseOfertas&&window.f3baseOfertas.contexto(f);if(oferta){d.set('oferta',JSON.stringify(oferta));}
  d.set('contexto_teste',s.teste?'1':'0');d.set('atribuicao',JSON.stringify(c?c.atribuicao():{}));
  if(a){d.set('navegacao',a.navegacao);d.set('dispositivo',a.dispositivo);}var sessao=window.f3baseTracking&&window.f3baseTracking.sessao();if(sessao){d.set('sessao',sessao);}
 }
 document.addEventListener('submit',function(e){var f=e.target;if(!f.matches('[data-f3base-formulario]')){return;}e.preventDefault();var s=estado(f);if(s.enviando||s.aceito){return;}if(!s.carga){conferirArquivos(f);}if(!s.carga&&!f.reportValidity()){evento(f,'erro',{codigo:'validacao_navegador'});return;}
  var b=f.querySelector('[type="submit"]'),out=f.querySelector('.f3base-formulario-resultado');s.enviando=true;b.disabled=true;out.textContent=mensagem(f,'enviando','Enviando…');f.setAttribute('aria-busy','true');evento(f,'tentativa',{});
  // A retry retains fields, files, classification and submission ID from the first attempt.
  if(!s.carga){s.carga=new FormData(f);s.carga.delete('action');contexto(f,s.carga,s);}
  function enviar(renewed){return token(f,renewed).then(function(){s.carga.set('token',f.elements.token.value);return pedir(f.dataset.endpoint+'enviar',{method:'POST',credentials:'same-origin',body:s.carga});}).then(function(res){if(res.status===413){var err=new Error(mensagem(f,'arquivo_limite','O envio excedeu o limite total do servidor.'));err.codigo='limite_servidor';throw err;}return res.json().then(function(r){r._http=res.status;return r;});}).then(function(r){if(!r.ok){if(r.codigo==='token_ou_revisao_invalida'&&!renewed){return enviar(true);}var err=new Error(r.mensagem||mensagem(f,'falha','Não foi possível receber o envio. Tente novamente.'));err.codigo=r.codigo;err.rejeitado=r._http>=400&&r._http<500&&r._http!==409&&r._http!==429;throw err;}return r;});}
  enviar(false).then(function(r){out.textContent=r.mensagem||mensagem(f,'sucesso','Contato registrado.');if(r.url){var a=document.createElement('button');a.type='button';a.className='wp-element-button';a.textContent=r.method==='conteudo'?'Baixar conteúdo':'Continuar no WhatsApp';a.addEventListener('click',function(){location.assign(r.url);});out.appendChild(document.createElement('br'));out.appendChild(a);}
   if(r.aceito){s.aceito=true;evento(f,'aceito',{formulario:f.dataset.f3baseFormulario,correlacao:r.correlation_id,method:r.method,duplicado:r.duplicado,contexto_teste:s.teste,classe_trafego:r.classe_trafego});f.reset();b.hidden=true;var again=document.createElement('button');again.type='button';again.className='wp-element-button';again.textContent=mensagem(f,'novo_envio','Novo envio');again.addEventListener('click',function(){s.aceito=false;s.carga=null;s.iniciado=false;s.teste=null;s.token=null;f.elements.submissao.value=id();f.elements.token.value='';b.hidden=false;out.textContent='';f.querySelectorAll('[aria-invalid]').forEach(function(el){el.removeAttribute('aria-invalid');});evento(f,'novo',{});var first=f.querySelector('input:not([type="hidden"]):not([name="website"]),textarea,select');if(first){first.focus();}});out.appendChild(document.createElement('br'));out.appendChild(again);if(r.redirecionar){location.assign(r.redirecionar);}}
  }).catch(function(err){out.textContent=err.name==='AbortError'?mensagem(f,'nao_confirmado','O envio ainda não foi confirmado. Tente novamente.'):(err.name==='TypeError'?mensagem(f,'conexao','Falha de conexão. Tente novamente.'):err.message)||mensagem(f,'conexao','Falha de conexão. Tente novamente.');if(err.rejeitado||['campos_invalidos','campo_invalido','limite_servidor'].indexOf(err.codigo)>=0){s.carga=null;}out.focus();evento(f,'erro',{formulario:f.dataset.f3baseFormulario,codigo:/^[a-z0-9_]{1,64}$/.test(err.codigo||'')?err.codigo:'envio_nao_confirmado'});}).finally(function(){s.enviando=false;b.disabled=false;f.removeAttribute('aria-busy');});
 });
}());
