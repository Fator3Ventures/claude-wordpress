# Meta — transporte e fila 1.19

## Configurar

`f3base_meta_transporte`: `modo=navegador|ambos|servidor`, `eventos=[PageView,Lead]`. Instalação nova usa navegador. Atualização com Lead CAPI configurado preserva `ambos` e `eventos=[Lead]`. Não ativa PageView CAPI automaticamente. GA4 não possui modos ambos/servidor; Google Ads e LinkedIn preservam transporte atual.

Cadastre `f3base_meta_capi_token` como segredo e o destino `f3base_meta_capi_pixel_id`. Vazio herda o Pixel direto. Quando o Pixel vier do GTM, informe explicitamente o dataset/pixel da CAPI. A fila conserva o destino de cada evento; trocar Pixel não transfere eventos antigos.

`ambos` mantém `event_name` e `event_id` compartilhados. PageView nasce uma vez por navegação, com instante original; o envelope próprio descarrega também na saída curta. Lead é criado no aceite/clique pelo Core; repetição não cria outro ID. O endpoint `/wp-json/f3base/v1/meta-eventos` valida consentimento, token, origem, formato, prazo, classe e caminho e enfileira sem HTTP externo no atendimento ao visitante. IP/UA vêm da requisição e do proxy confiável, não do corpo. `_fbp`/`_fbc` obedecem consentimento; `_fbc` requer clique real. Nem sendBeacon nem callback do Pixel provam entrega remota.

O catálogo equivalente nesta versão é PageView/Lead. Formulários e CTAs conservam `method`. AutoConfig e tags de terceiros podem emitir outros sinais; esses sinais bloqueiam a alegação de equivalência para servidor.

## Prazo e proteção

Payload cifrado por libsodium secretbox, chave derivada de `wp_salt('secure_auth')` com contexto `f3base:capi:payload:v1`. Rotação/perda dos salts pode tornar a fila indecifrável; não é anonimização. Não copie payload para diagnóstico. Tentativas não renovam ocorrência, ID ou expiração.

Teto operacional: sete dias contados do evento; em ambos também se aplica a janela de deduplicação. `f3base_meta_janela` registra limites oficialmente conferidos, URL, data e confirmação do operador, válida por 90 dias, com margem de cinco minutos. As páginas oficiais responderam 429 na consulta desta implementação: os valores de referência de sete dias/48 h não são anunciados como reconfirmados. **Sem conferência vigente, o prazo efetivo é uma hora**. Alterar regras só pode reduzir o prazo de trabalhos existentes. Resultado remoto incerto também restringe a repetição à janela segura de deduplicação.

16 tentativas máximas, recuo até seis horas, teto de mil payloads pendentes e 64 KiB cifrados por trabalho. Entregue, cancelado, recusado definitivamente, expirado ou sem tentativa útil: remove payload pessoal. Revogação cancela pendências; chamada já em curso pode terminar, ficando registrada como tal. Metadados de entrega duram 90 dias pela política da fila. Se o cron parar, a limpeza física atrasa: isso não é apresentado como prazo cumprido. A retomada limpa expirados antes do despacho.

Inventário de exportação: `meta-entregas-ler` retorna contagens e metadados permitidos; exportações de medição/CSV não incluem fila ou IP; `clarity-exportar` inclui apenas acervo analítico sanitizado. O Core não produz dump integral do banco nem backup de payload CAPI. Exportação de dados pessoais de leads tem escopo próprio e não amplia retenção de IP dos leads. Backups integrais independentes do banco/hospedagem copiam o que existe no banco e têm retenção externa; o plugin não elimina cópias que não controla.

## Homologar servidor

Leia `f3base/meta-entregas-ler`: por dia UTC/evento/rota/classe, mostra captura, disparo observado, fila e desfechos. `modo=eventos` pagina 100 metadados; `evento_hash` permite conciliar captura/fila sem exportar payload. Elegíveis não observados e EMQ são indisponíveis, não zero. Testes não entram na mesma linha de tráfego normal.

`f3base/meta-homologacao-registrar` recebe período fechado mínimo de sete dias, evidência externa HTTPS da Meta, validação da credencial, equivalência do catálogo, ausência de tags Meta de terceiros e, por PageView/Lead: elegíveis, pixel, servidor, deduplicados, descartes inexplicados. Exige ao menos 100 eventos de cada tipo, diferença residual até 5%, zero descartes inexplicados e conciliação local por ID até entregue. A evidência externa é declarada pelo operador; a API não finge verificá-la automaticamente.

Após prova válida, escolha servidor explicitamente. Mudanças de conta, token, consentimento, catálogo, AutoConfig, GTM/evidência ou janelas invalidam a prova. Sem prova válida, a execução retorna a ambos; reavalie e homologue. Verifique ausência real de `fbevents.js`, inclusive tema/GTM, e acompanhe mais sete dias. O pacote não declara esta homologação externa concluída.
