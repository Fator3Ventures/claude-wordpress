# Base Site Core Fator3 1.19.0

Instale `base-site-core-fator3-1.19.0.zip` pelo WordPress. O ZIP de fontes/testes não é instalável. Suporta instalação nova ou atualização da **1.18.0 concluída**. Retomada ocorre dentro da 1.19.0; não há migração anterior nem downgrade. Tema e implantador são externos.

A versão corrige Contatos → Relatórios, unifica os filtros e denominadores da audiência, amplia a análise de IA por conteúdo e assinatura e renova a prova de navegação pelo cron sem login. Completa mensagens/confirmacão dos formulários, gestão de arquivos por agentes e medição de ofertas. Acrescenta GTM aditivo, agendamento ocioso, Clarity com acervo local e transporte Meta com homologação por site.

Preferências explícitas, inclusive `false`, `0` e `[]`, são preservadas. Sem IDs/credenciais, nenhum fornecedor novo é ativado. Lead CAPI preexistente é preservado em `ambos`, apenas Lead; PageView CAPI exige escolha. GA4 continua pela tag. A atualização não produz envios retroativos ao CRM.

O histórico Clarity tem retenção independente: `0`, sem expiração automática, é o padrão. A resposta analítica sanitizada é guardada antes da normalização e pode ser reprocessada/exportada/restaurada. Janelas móveis sobrepostas não são parcelas somáveis. IP da fila Meta permanece somente no payload cifrado pendente: teto de projeto de sete dias, reduzido pela janela externa efetivamente conferida; sem conferência operacional, prazo conservador de uma hora. Desfecho terminal remove o payload.

Leia [DOCUMENTACAO.md](DOCUMENTACAO.md), [RELEASE-1.19.md](RELEASE-1.19.md), [MEDICAO-1.19.md](MEDICAO-1.19.md) e [VALIDACAO.md](VALIDACAO.md). Todos acompanham o plugin em `docs/` e podem ser lidos por `f3base/documentacao-ler` autenticado. Validação local não substitui a homologação das contas Meta, GA4/GTM e Clarity pela frota.
