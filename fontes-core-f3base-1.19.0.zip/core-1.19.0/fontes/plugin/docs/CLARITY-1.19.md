# Clarity — tag, consultas e acervo local

## Configuração

ID público em `f3base_clarity_project_id`; vazio é inerte. Token somente no servidor em `f3base_clarity_api_token`, cifrado e vinculado ao projeto no cadastro. Trocar projeto não reutiliza silenciosamente a credencial. `f3base_clarity.coleta_ativa=true` só atua com ID/token válidos; `retencao_meses=0` preserva o acervo sem expiração automática. Reduzir a política elimina consultas anteriores ao corte; política editorial é independente.

Tag somente após consentimento de medição, sob estratégia/prazo próprio. Usa consentv2 antes da coleta, marca de testes e parada na revogação. Mensagens/campos/áreas privadas têm máscara. O conteúdo da página também depende da configuração de mascaramento do projeto: confira em conta autorizada. Token de exportação nunca vai ao navegador. Recarregar para conceder não restaura dados revogados.

## Exportação e histórico

Data Export API: `https://www.clarity.ms/export-data/api/v1/project-live-insights`, janela de 1/2/3 dias, até três dimensões entre Browser, Device, Country/Region, OS, Source, Medium, Campaign, Channel e URL. Não oferece consulta de datas arbitrárias para recompor o passado.

O Core mantém dez tentativas locais por projeto/dia UTC: oito automáticas e duas manuais. Outros consumidores podem gastar a cota remota. 429 respeita Retry-After e pausa local. Trava por projeto evita consumo concorrente. Cron diário tem orçamento de 45 s, continuação agendada e idempotência por data/recorte. Plano prioriza total e URL × Device/Channel para 24/72 h, depois aquisição e ambiente. Mil linhas por bloco sinalizam possível truncamento; recorte mais simples URL e total é tentado dentro da cota. Ausência de truncamento detectado não certifica completude do fornecedor.

`f3base_clarity_coletas` guarda uma tentativa/consulta, parâmetros, projeto, instantes UTC, janela nominal, duração, estado, cota/cobertura, hash, versões e resposta analítica sanitizada gzip. `f3base_clarity` guarda linhas derivadas por coleta/parser/bloco/linha, dimensões e todos os valores fornecidos. Novas métricas analíticas válidas permanecem no JSON mesmo quando a tela não as conhece. Blocos vazios e precisão numérica/string são preservados. Dados não fornecidos não viram zero.

Limite técnico de resposta: 8 MiB; textos/campos têm limites de formato e tamanho documentados no saneamento. Remove query/fragmento de URLs, segredos e identificadores pessoais; registra contagem de remoções sem seu conteúdo. Resposta sanitizada é gravada antes de normalizar, com journal privado para recuperação de falha de banco. Parser novo pode criar derivação versionada sem consumir API; o corpo não é duplicado por normalização. Hash refere-se à representação sanitizada, não ao corpo privado recebido do fornecedor. Erros HTTP não são arquivados como corpos arbitrários.

## Consultar e cruzar

Medição → Clarity lista consultas, não totais mensais. Selecione uma coleta para página, métrica, dimensões e valores. Comparação aceita somente projeto, parâmetros, parser e saneamento compatíveis e estados completos; linhas devem ser pareadas por métrica + dimensões, nunca por posição. Não some nem subtraia janelas móveis para inventar dias isolados. Cobertura une intervalos nominais de consultas completas do mesmo recorte e mostra lacunas internas; isso não prova cobertura diária exata.

O quadro Core usa as mesmas páginas e instantes nominais: visualizações, sessões observadas, sessões com origem IA, início de formulário, aceites pareados, seções e tempo ativo. Exclui testes/automação conforme a coorte própria. Não aplica Device/Channel do Clarity como se fossem segmentos Core e não junta pessoas entre fornecedores. Para robôs, abra o conteúdo no painel IA com seu período; não associe gravação, robô e contato por suposição. Brutos expirados não são recuperados pelo acervo externo.

| Ability | Efeito |
|---|---|
| clarity-ler | Leitura local; modos resumo, consultas, resposta; projeto/de/ate/pagina/limite/coleta. Datas filtram o momento da consulta. |
| clarity-comparar | Dois IDs anterior/atual e página, sem HTTP nem adição artificial. |
| clarity-consultar | Janela dias e dimensões; idempotency_key obrigatório; consome cota e persiste. |
| clarity-coletar | Executa plano do cron; grava dados, não é leitura. |
| clarity-reprocessar | Reprocessa coleta local sem rede. |
| clarity-exportar | Resposta gzip/base64, metadados e hash de uma coleta sanitizada. |
| clarity-restaurar | Valida estrutura, janela, hash e saneamento; restaura sem API. |
| clarity-gravacoes | Adaptador separado sob demanda, com cota própria. |

Todas usam prefixo `f3base/` e exigem capabilities/política do canal. Respostas, CSV e contrato compartilham a mesma consulta. Exportação não contém token. Troca de projeto mantém o histórico consultável por projeto anterior. Desativar plugin não apaga acervo.

## Gravações

Adaptador baseado no MCP oficial Microsoft Clarity 2.0.2, commit `1708e8d45f940dd9eb14dfc06d68d766a200ca1f`: POST para host fixo `https://clarity.microsoft.com/mcp/recordings/sample`. Filtros de intervalo (até 31 dias), URL sanitizada, dispositivo, rage/dead clicks, ordenação e até 250 resultados. Quatro tentativas locais por dia; isso não é promessa de cota do fornecedor. Timeout de 20 s e resposta de 2 MiB.

Retorna somente links válidos do Clarity e metadados mínimos; não baixa, arquiva ou torna públicas gravações. Quantidade de links é amostra, não total de sessões. Sem contrato funcional, responde indisponível/schema incompatível sem interromper formulários ou histórico. Teste local usa contrato simulado; acesso real, disponibilidade e mascaramento dependem da homologação da frota.

Homologação externa: três dias de coletas, interrupção maior que 24 h e nova consulta ampla, com janelas/lacunas declaradas; comparar com a resposta da mesma consulta. Períodos móveis distintos não são tratados como equivalentes à tela do fornecedor.
