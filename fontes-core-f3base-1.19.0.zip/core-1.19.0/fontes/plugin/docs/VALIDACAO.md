# Validação — F3 Base Core 1.19.0

Data: 01/10/2026. Contrato 4.3.0. Base exclusiva: **1.18.0 concluída ou instalação nova**. Retomada na própria versão; downgrade não suportado. Nenhum site de produção foi acessado ou alterado. Korvena.net.br será testado pelo dono. Tema e implantador não foram alterados.

## Ambiente e resultado

WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46/InnoDB, Chromium 154.0.8037.92 e Playwright. Dados sintéticos, e-mail bloqueado, fornecedores simulados e HTTP WordPress local. Canal MCP 0.13.0 real autorizado, sem conexão à frota.

**692 asserções aprovadas**, mais **159 verificações em dez etapas de instalação/atualização**. São asserções, não 851 cenários independentes. Somente os conjuntos abaixo foram contabilizados. Evidências em `suite/versao-1190/evidencias/` no ZIP de fontes.

| Conjunto | Asserções | Evidência |
|---|---:|---|
| Instalação, menu, navegação cron, opções e contratos | 109 | `fundacao.json` |
| Arquivos privados, revisão, idempotência e concessões | 28 | `arquivos.json` |
| Resumo de e-mails, mensagens, MIME, spam e falha transacional | 20 | `regressoes-adicionais.json` |
| Regressões editoriais, sessões e identidade de conteúdo | 65 | `editorial.json` |
| Coorte comum, filtros, IA efetiva, assinaturas e comparação | 43 | `relatorios-ia.json` |
| Fila Meta, cifra, prazos, conciliação e funil de ofertas | 37 | `meta-ofertas.json` |
| Acervo integral sanitizado, cotas, comparação e gravações simuladas | 37 | `clarity.json` |
| Contrato MCP 0.13.0 e permissões de leitura/escrita | 96 | `mcp.json` |
| Navegador: consentimento, GTM, modos e prazos | 41 | `carregadores.json` |
| Navegador: PageView, ofertas, idempotência e frequência | 23 | `meta-ofertas-browser.json` |
| WordPress HTTP: três regimes, JS/sem JS, PDFs e menu real | 38 | `forms-browser.json` |
| Interfaces desktop/celular, filtros, comparação e erros JS | 23 | `ui.json` |
| Documentação instalada, schemas e controle de leitura | 132 | `documentacao.json` |

Os dois caminhos verificam instalar, semear dados, atualizar, repetir e retomar. O instalador real 1.18.0 tem SHA-256 `7429202b8d00ca9e0b8c76403d24552847ac6d668d9dd405a16bff5ed2bda584`. Preferências falsas, listas vazias, política, contatos e segredos foram preservados. Pendências CAPI antigas foram cifradas sem renovar prazo. Sem IDs/tokens novos, Clarity continua inerte; CAPI existente conserva Lead em ambos.

Sintaxe conferida em 142 arquivos PHP e 26 JavaScript. Nove assets minificados recompostos e conferidos com Terser fixado. `pacote.json` documenta CRC, conteúdo byte a byte, manifesto e reprodução do instalador. `upgrade.json` informa o hash do ZIP usado no fechamento. Documentação também é lida pela ability instalada, não só pela presença dos arquivos.

## Cobertura efetiva

- Clique real Contatos → Relatórios, cron de navegação com usuário zero, permissões administrativas e perfis MCP distintos.
- Relatórios comuns com filtros, testes/automação, anotações, histórico expirado, método, canal e ads; IA por representação, rede, assinatura, horários e semanas. Sem somar distintos diários.
- Consentimento antes das tags, revogação, ausência de SDK em testes, GTM aditivo, send_to, ocioso com/sem requestIdleCallback, prazos independentes e modo Meta servidor sem fbevents gerado pelo Core. Análise própria conserva o primeiro envio em cinco segundos.
- Formulários com/sem JS nos três regimes, confirmação após aceite, continuidade privada/WhatsApp, mensagens, assunto sem duplicação, antispam e limites PHP. Expiração responde 410. Resumo de e-mails reserva pendentes sem reenvio duplicado.
- Cadastro/importação/substituição privada, hash e revisão concorrente; concessões válidas entregam arquivo novo. Downloads concorrentes recebem conteúdo íntegro. Falha de banco anterior à publicação mantém versão anterior; origem pública só é excluída por operação explícita.
- Ofertas por instância visível, reabertura sem duplicação, fila até disponibilidade do emissor, consentimento/testes, início/envio aceito e funil sem encaixe artificial.
- Meta: cifra, prazo útil superior a 24 h sob janela confirmada, teto, prazo fixo, limpeza terminal, revogação, fila e captura conciliadas por hash; prova insuficiente recusa servidor.
- Clarity: todas as métricas/dimensões válidas da resposta de teste, precisão e blocos vazios, saneamento, gzip/hash, normalização e reprocessamento sem HTTP, exportação/restauração, retenção independente, cotas/429, comparação compatível e isolamento da falha de gravações.
- Interfaces em 1440 e 390 px, inspeção visual de PNGs, filtros e quadros Clarity legíveis. Ausência de erros JavaScript nos percursos verificados.

## Homologações externas e limites

Testes simulados não comprovam recebimento nas contas Meta/GA4/Clarity, SMTP ou Pipedrive. Nenhuma homologação da frota foi encerrada por esta entrega. A aprovação de modo Meta servidor continua condicionada à evidência por site e à conciliação local; o pacote não a ativa automaticamente.

Meta: conferir janelas oficiais vigentes antes de habilitar retenção ampliada; sem confirmação válida, uma hora. Homologar autoConfig e deduplicação/catálogo em sete dias, com mínimo previsto por evento, depois acompanhar mais sete dias no modo servidor. Campos de EMQ ou entrega remota não observados não viram zero.

Clarity: conferir tag, consentv2, mascaramento efetivo e gravações em conta autorizada; coletar por três dias, pausar mais de 24 h e verificar janela/lacuna após retomada. A cópia local é integral para informação analítica aceita pelo contrato e saneada; não inclui segredos, identificadores pessoais ou gravações. Janelas móveis não permitem fabricar dias isolados ou somar usuários.

Desempenho: não houve nova rodada PageSpeed/Lighthouse nem medição de custo do SDK real. A validação de agendamento não é promessa de ganho em TBT/LCP/INP. Comparações exigem execuções repetidas equivalentes, mediana/dispersão e dados de campo com volume explícito.

Pipedrive e integrações nativas já entregues preservam seus aceites externos. Casos de rede, banco e navegador simulados não certificam hospedagem, falta física de disco, proxy, restauração de backup ou cron da frota. Ausência de log permanece lacuna; requisição IA não comprova citação/recomendação nem causa de uma visita posterior. Suites históricas e `novas.php` não executada não integram a contagem desta entrega.
