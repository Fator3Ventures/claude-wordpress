# Pipedrive — Core 1.19.0

## Ativação

A integração vem desligada. Em **Contatos → Integrações → Pipedrive**, configure o domínio da empresa (somente `empresa.pipedrive.com`), responsável, etiqueta opcional, unidade, campos comerciais, mapas de alternativas e credencial. O token fica cifrado no servidor; campo vazio mantém o valor e apagar é explícito. Salvar agenda a verificação da identidade da conta e dos catálogos de usuários, etiquetas, atividades e campos. Nenhum campo, funil ou usuário é criado pelo pacote.

A verificação fica vinculada às revisões da configuração e da credencial. Trocar ou apagar o token invalida imediatamente essa prova e os catálogos. Entrega e eliminação remota aguardam nova verificação; uma consulta em andamento não pode certificar a nova credencial usando respostas da anterior. Cada lote conserva seu próprio contexto e para antes da chamada seguinte quando ele muda. Uma chamada já enviada pode ter sido executada: seus IDs e checkpoints continuam sujeitos à conciliação.

Os seletores mostram as chaves/tipos encontrados na conta. Serviço exige campo de seleção múltipla (`set`); os demais mapas devem usar os tipos validados. Os valores dos mapas são IDs de alternativas, não rótulos traduzidos. Use `formulario_id:valor` quando dois formulários usam o mesmo texto para serviços diferentes. `unidade` é o ID da alternativa da unidade deste site. `atividade_tipo` deve existir no catálogo; a atividade inicial é opcional.

Ative o módulo somente após conferir a conta e o mapeamento. Cada formulário tem checkbox próprio de envio ao Pipedrive (true por padrão, subordinado ao módulo global), papéis nome/e-mail/telefone/empresa/cargo/serviço e serviço fixo opcional. Desativar o checkbox exclui novas capturas desse formulário. Integração não retroenvia histórico. Formulários de clique, spam, duplicatas de transporte e contatos sem nome + e-mail/telefone identificável ficam fora da entrega automática.

Consulte a prévia privada `f3base/pipedrive-previa` com `record_id`. A autorização de coleta/contato e o aviso de privacidade são responsabilidade da operação do site. A prévia não envia dados. Homologação real ainda é pré-requisito de ativação: veja CRM-A01…A15 em VALIDACAO.md.

## O que é enviado

| Destino | Dados e regra |
|---|---|
| Organização | Busca exata pelo nome informado; cria quando não existe. Não modifica organização existente. Ambiguidade suspende. |
| Pessoa | Busca exata por e-mail; na ausência, telefone internacional E.164. Nome, e-mail, telefone, organização e responsável na criação. Não sobrescreve pessoa preexistente. Cargo fica na nota e no campo comercial opcional; não depende de `job_title` restrito por contact sync. |
| Oportunidade | Reutiliza um negócio aberto único ou lead não arquivado único. Caso contrário cria lead. Mais de uma alternativa suspende para revisão, sem fusão automática. |
| Campos comerciais | Unidade do site; canal da plataforma; parceiro da convenção da campanha; ponto nativo/site/whatsapp_formulario; serviços; campanha; anúncio/criativo; cargo opcional. Mapeamento vinculado à conta, sem IDs fixos universais. |
| Nota | Identificação do registro/formulário, campos enviados, página sem query, atribuição permitida, qualidade e jornada observada. HTML escapado e limite de tamanho. Link para o detalhe privado no WordPress. |
| Atividade | Primeiro contato, quando habilitada e oportunidade nova; etapa separada para evitar repetir nota ao retomar tarefa. |

A convenção de campanha é `unidade_parceiro_objetivo_AAAAMM`. O parceiro é procurado no mapa; campanha fora do padrão ou parceiro desconhecido fica visível em `journal.qualidade` e na nota. Ausência de medição não prova origem orgânica: a qualidade declara ausência/recusa/revogação. Um mapa vazio não adivinha valores. Nas fontes que não entregam nome de campanha, configure `mapeamento.campanhas` por ID na origem nativa.

A nota leva no máximo 20 páginas e 50 eventos anteriores à captura, da mesma sessão e classe de tráfego e dentro da retenção disponível. Falta de vínculo ou consentimento é sinalizada; não junta por IP, e-mail ou similaridade. Eventos de análise, comportamento e cliques têm fontes diferentes e não equivalem a pessoas únicas. Testes ficam fora por padrão; modo explícito de homologação permite apenas fluxo sintético marcado. Formulários nativos não têm jornada web inventada.

Não são enviados IP, user agent bruto, cookies, fbc/fbp, oppref, anexos ou links públicos para arquivos privados. Click IDs permitidos podem aparecer na atribuição conforme consentimento, não como identidade de pessoa. Consentimento é reavaliado no despacho da nota; revogação reduz dados de medição/publicidade. Retirada posterior à entrega exige procedimento de eliminação, não apaga automaticamente a cópia remota.

## Fila e operação

A captura grava intenção durável no próprio lead. A fila contém referências, IDs remotos e checkpoints, sem copiar o corpo do contato. Cron/loopback processa até dez itens por rodada, com orçamento de 20 segundos; formulário não espera o CRM. Se WP-Cron estiver desabilitado, configure executor externo. E-mail e CRM possuem estados independentes.

Estados efetivos incluem `pendente`, `enviando`, `entregue`, `suspenso`, `falhou`, `incerto`, `cancelando` e `cancelado`. Posse temporária dura 120 segundos. Entrega só termina após etapas obrigatórias e releitura dos campos comerciais da nova oportunidade. A API v1 recebe Serviço como string de IDs separados por vírgulas, e a releitura normaliza a representação antes da comparação. Homologue esse contrato na conta real antes de ativar.

Uma execução inicial e até seis retentativas de falha transitória usam 1, 5, 15, 60, 180 e 720 minutos, com jitter. Pausas por credencial/orçamento não consomem tentativas. 429 respeita Retry-After. Resposta perdida após POST fica incerta e é conciliada antes de qualquer nova criação. Checkpoint persistido impede repetir etapas concluídas. Reenvio exige revisão atual e é recusado quando incompatível com o estado.

Contatos → Integrações → Entregas mostra estado, motivo, tentativas, próxima execução e etapas. No detalhe do contato, `crm.pipedrive` traz IDs e resultado. Abilities: `integracoes-ler`, `pipedrive-verificar` (somente leitura), `integracoes-verificar-agora` (consulta conta e atualiza catálogos), `pipedrive-processar` (pode enviar), `pipedrive-reenviar` (revisão/simulação), `pipedrive-previa` (dados privados). Leia o schema instalado antes de executar.

Orçamento diário **local** limita o consumo desta instalação e reinicia em UTC. Não é a cota restante global da empresa. Cabeçalhos de limite observados podem pausar o executor. Várias instalações não compartilham trava nem orçamento; a revisão posterior detecta ambiguidades observadas, mas não garante criação exatamente única entre sites. Não configurar duas origens para importar a mesma conta/formulário sem uma autoridade definida.

Os campos esperados do lead têm suas chaves e hash registrados antes do POST, sem guardar o conteúdo comercial no diário. Se a resposta se perder, a retomada localiza a oportunidade pelo marcador e relê os campos; divergência suspende a entrega antes de acrescentar nota/atividade. Catálogo vazio de alternativas não valida IDs configurados.

## Eliminação e retenção

Expiração por retenção local cancela despachos futuros e não apaga atividade comercial no CRM. Eliminação explícita a pedido primeiro cancela a fila e marca recibos nativos; só então remove o contato local. A limpeza externa tem estado próprio e pode permanecer pendente.

Notas/atividades próprias são removidas apenas com ID, marcador e hash compatível. Lead/pessoa criados exclusivamente pelo Core só são candidatos se permanecem inalterados, sem vínculo comercial independente e com prova suficiente. Organização, entidade preexistente, oportunidade compartilhada/convertida/editada ou prova incompleta ficam preservadas e exigem revisão comercial. Não se declara eliminação remota concluída ao apagar apenas o registro local. IDs mínimos e hashes permanecem para conclusão e auditoria; não são expostos publicamente.

Histórico técnico de entregas é compactado após 30 dias por padrão (7–90 configurável); recibos/etapas necessários à conciliação e eliminação pendente permanecem. Tombstones de origem nativa duram 90 dias e o marco de ingestão evita recriação fora da janela. Troca de conta não reinterpreta IDs antigos; suspense e reconciliação são explícitos.

## Exemplo da conta informado pelo dono

Referência fornecida no plano, **não verificada por esta entrega e não aplicada como default**. Confirme IDs na conta de destino, especialmente em sandbox, onde serão diferentes.

| Papel | Chave / exemplos fornecidos |
|---|---|
| Responsável / etiqueta | 24617815 / 77570ba0-b933-11f1-9be3-955dbf3be411 |
| Unidade | a6856374537cc03694d68f8a242b083fc20d0e2c; fator3=44, ctooffice=45, korvena=46 |
| Canal | 53bf9d1b48b76933f8b5cead0fb07112d064961a; Meta=80, LinkedIn=81, Google=82, OpenAI Ads=83, não identificada=85 |
| Parceiro | c980b55160e74cd39d67a1666e65e750011c2b3a; apex=47, saask=48, datta=49, interno=50, sem campanha=51 |
| Ponto | cd1662eaac4c279d069f158256289c5d72b8e854; nativo=52, site=53, whatsapp_formulario=54 |
| Serviço | 5a81949e986c3f117cc748791e72a0f3c0d24e9e; opções 89–96 conforme catálogo da conta |
| Campanha | c3a9451e31d91c3002155884d68c68f67cf7fcfa |
| Anúncio | 0017e916e1b899c61a97452e23aede3d7a01db22 |

Documentação primária: https://developers.pipedrive.com/docs/api/v1/Persons ; https://developers.pipedrive.com/docs/api/v1/Leads ; https://developers.pipedrive.com/docs/api/v1/Notes ; https://developers.pipedrive.com/docs/api/v1/Activities . Adaptadores atuais usam v2 para pessoas/organizações/atividades/negócios/campos e v1 para leads/notas/catálogos que mantêm esse contrato. Rota alterada/ID removido suspende com motivo, sem fallback cego.
