# F3 Base Core — plano consolidado da versão 1.19.0

Data: 01/10/2026. Base analisada: código da versão 1.18.0, commit `8ea6a78`.
Revisão: 01/10/2026, após análise de “Pendências do site-core após a 1.18.0(1).md” e conferência integral de “Pedidos ao pacote core.md”, agora recebido como arquivo. O documento oficial confirma os mesmos quinze pedidos; não acrescenta um item 102. A frota informa 14 sites na 1.18.0, contrato 4.2.0 e perfil `piso-padrao-3.2`.

Estado: planejamento atualizado com as decisões do dono de 01/10/2026, às 08:00 (America/Sao_Paulo); nenhuma alteração foi implementada ou publicada. Decisões fechadas: item 94 restrito à Meta; GA4 permanece pela tag, sem modo `ambos`; concessões vigentes seguem a versão nova do PDF; histórico Clarity incluído nesta versão, preservando o máximo de informação útil local; IP na fila pode permanecer além de 24 h quando necessário à entrega. O desenho adota teto operacional de sete dias, limitado pela janela efetiva de envio/deduplicação e com limpeza antecipada após entrega, expiração, revogação ou desfecho terminal.

**Decisão do item 101 encerrada:** o dono determinou manter o histórico nesta versão e o máximo de informações possível do nosso lado. Implementar o acervo das consultas originais, métricas, dimensões, cobertura e qualidade; leituras futuras não sobrescrevem as anteriores. O aceite observa o que a fonte efetivamente retorna e não afirma reconstrução diária exata por subtração. O acervo agregado terá retenção própria, sem expiração automática por padrão, conforme detalhado abaixo. Não resta decisão de produto pendente sobre histórico ou retenção do IP.

## Decisão de escopo

O plano contempla os quinze pedidos 17, 82, 83, 88, 90 e 92–101, com os ajustes e limites abaixo, além de R119-01. O item 94 contempla somente o envio Meta, com modos `navegador`, `ambos` e `servidor`, condicionado à homologação para ativar o modo servidor em cada site. GA4 continua exclusivamente pela tag; novos transportes de Google Ads e LinkedIn ficam para versão posterior. O item 101 entrega leitura e histórico local do Clarity por consultas originais com janelas e cobertura explícitas. Preservar toda informação analítica retornada dentro do contrato de dados; não prometer recuperar dias exatos pela subtração de agregados móveis.

| Pedido | Encaminhamento | Ajuste relevante |
| --- | --- | --- |
| Menu Contatos → Relatórios | Corrigir | Ordem de registro, destino explícito e teste pelo menu real. |
| 92 — prova de navegação | Incorporar | Renovar antes do vencimento e após invalidação; cron executa uma rotina interna sem depender de usuário autenticado. |
| 93 — Meta autoConfig | Incorporar | Opção preserva o padrão atual; ganho de desempenho depende de medição. |
| 95 — modo ocioso | Incorporar | Prazo próprio por destino, consentimento e cancelamento das filas preservados. |
| 88 — relatórios integrados | Incorporar | Mesma fonte e definição do editorial para audiência; histórico sem cobertura não vira sessão humana. |
| 83 — IA por conteúdo | Incorporar | Operador declarado, finalidade, evidência de rede, status e última requisição; arquivos de descoberta separados. |
| 90 — robô genérico | Incorporar com aceite corrigido | Assinatura técnica reduzida não garante identificação do operador. |
| 82 — rede incompatível | Incorporar | Classificação efetiva suspeita, mantendo a família declarada como evidência. |
| 17 — formulários | Incorporar o que falta | Agrupamento por e-mail e HTTP 410 já existem; mantê-los e testar. |
| 96 — arquivos privados | Incorporar | Substituição deve preservar também concessões válidas, hoje vinculadas ao hash. |
| 97 — ofertas | Incorporar | Contrato e medição no Core; apresentação e gatilhos no tema. |
| 94 — envio pelo servidor | Incorporar somente Meta | IP pode superar 24 h durante entrega pendente: teto operacional de sete dias e prazo efetivo menor quando exigido por envio/deduplicação; limpeza antecipada obrigatória. |
| 98 — canal MCP 0.13 | Incorporar | Provedor, contrato de política e Update URI; conferir o contrato executável do canal e testar permissões sem downgrade do Core. |
| 99 — GTM aditivo | Incorporar | Tags preenchidas continuam emitidas; eventos para o contêiner, diagnóstico de coincidências e destino CAPI independente do slot do Pixel direto. |
| 100 — Clarity no navegador | Incorporar | Slot vazio inerte; consentv2, carregamento, supressão de testes e mascaramento do conteúdo pessoal exibido pelo Core. |
| 101 — consultas e histórico Clarity | Incorporar nesta versão; decisão fechada | Acervo local completo das informações analíticas retornadas, consultas de 24/48/72 h preservadas, retenção própria e documentação para agentes. |

### Conciliação do novo anexo com decisões anteriores

- **94:** permanece somente Meta nesta release. A instrução de 01/10 autoriza ultrapassar 24 h de retenção do IP quando necessário; ela substitui o teto anterior. O prazo operacional concreto e seus encerramentos estão na seção Meta. Ads/LinkedIn continuam fora dos novos transportes.
- **17:** corrigir a interpretação do plano anterior: o pedido se refere ao agrupamento de **avisos enviados por e-mail**, já existente no resumo horário, e não somente ao filtro de contatos por endereço. Ambos permanecem; os testes pedidos cobrem os avisos e o HTTP 410.
- **38:** conservar o primeiro envio da análise em 5 segundos. O item 94 trata seu próprio envelope Meta e a descarga de saída; não antecipar o temporizador global de `f3base-analise.js`.
- **101:** o dono encerrou a alternativa de adiamento em 01/10. Manter o histórico e preservar o máximo de informação analítica local. O aceite desta revisão mede acervo, consultas, qualidade e disponibilidade local; a limitação técnica de reconstrução diária permanece documentada, sem ser tratada como informação recuperada.
- **Fora do escopo:** webhook genérico continua adiado. DNS reverso de robôs sem lista oficial está decidido como não fazer. Implantador, tema e integração do pacote MCP Google permanecem com seus responsáveis.

“Pedidos ao pacote core.md” foi lido integralmente nesta revisão. A cópia tem cabeçalho de 27/09/2026 e acréscimos de 30/09; o anexo de pendências a associa à revisão 117, mas o arquivo oficial recebido não declara um número de revisão. Esta conferência cobre a cópia anexada, sem presumir que o artefato externo foi atualizado ou que seu estado atual foi acessado.

### Conferência com a lista oficial

| Grupo | Resultado e encaminhamento |
| --- | --- |
| 17, 82, 83, 88, 90, 92, 93, 95, 96, 97 | Pedidos já contemplados no plano. Mantidos os aceites de regressão do resumo de e-mails/410, cron sem usuário, parcela sem operador e limites de inferência sobre IA. |
| 98, 99, 100 | Confirmação do escopo acrescentado na revisão anterior: canal 0.13, GTM aditivo e Clarity. As dependências técnicas e a configuração separada do destino CAPI continuam necessárias. |
| 94 | Somente Meta. A decisão posterior de 01/10 autoriza retenção superior a 24 h quando útil à entrega, conforme limite operacional da fila. |
| 101 | Histórico incluído por decisão posterior de 01/10, preservando o máximo de informação local. O método de consulta e seu aceite atualizado constam deste plano. |
| R119-01 — menu Contatos → Relatórios | Não aparece entre os quinze números do documento oficial. Permanece no plano por pedido expresso nesta conversa e reprodução na base 1.18.0; não inventar um número oficial para ele. |

O documento oficial determina que a baixa dos pedidos cabe à sessão que conferiu a entrega, com sua evidência. Planejamento e geração futura do pacote não autorizam retirar itens como entregues. Esta revisão preserva o anexo oficial e registra a conciliação somente neste plano.

### Itens já entregues ou operacionais: não reabrir como desenvolvimento

- **1/18:** detector concorrente de `/llms.txt` e transição de `robots.txt` permanecem classificados pelo dono como não problemas.
- **17(a)/(b), 45, 51 e 55:** ativar resposta automática, painel de consentimento do tema, bloqueio de listagem e ofertas específicas é decisão de operação do site. Não ativar esses recursos como efeito da atualização. Pipedrive e origens Meta/Google já entregues conservam configuração e homologação externa separadas.
- **34 e 43:** acrescentar atributo no botão de korvena.com.br e retirar filtros antecipados dos temas são tarefas dos sites; não produzir patches por site nem transferir a apresentação do tema ao Core.
- **38:** prazo inicial da análise permanece 5 s após `load`.
- **52 e 79:** observação de logs e aceite com visitas reais pertencem à frota; ausência dessas evidências não prova defeito novo do pacote.
- **85:** preservar `gsc-importar` e a visão GSC. A fonte diária das fotografias pertence ao pacote MCP Google, item 8; não criar outro coletor no Core para essa pendência.
- **86:** a perda dos logs anteriores à instalação continua como lacuna registrada; não reconstruir acessos sem fonte.

Preservar também as decisões de não fazer: negação por escrita no diretório de cache, API/rota para o Teste de pesquisa aprimorada, DNS reverso/direto para robôs sem faixas e inferência de URL antiga pelo último segmento em 404. Não reintroduzir esses itens sem o fato novo ou a decisão exigidos no documento oficial. Webhook genérico permanece adiado; sequência de e-mails pós-download e conteúdo pago continuam fora da especificação.

O código da 1.18.0 foi recuperado do pacote de fontes e inspecionado nesta revisão. As medições e ocorrências dos sites são evidências fornecidas pela frota; não foram reproduzidas em produção. Não houve acesso ao korvena.net.br ou alteração nos sites.

## R119-01 — corrigir Contatos → Relatórios

**Prioridade alta.** O atalho gera `/wp-admin/f3base-relatorios`, que resulta em 404. O destino esperado é a área de conversão da Medição, mantendo o acesso pelo menu Contatos.

### Causa confirmada

O módulo de relatórios registra o submenu antes de o módulo de contatos registrar o menu pai. Ambos usam o evento `admin_menu` na prioridade padrão. O WordPress calcula a identificação da página com base no menu pai disponível naquele momento.

Na reprodução local com a 1.18.0:

| Verificação | Resultado |
| --- | --- |
| Identificação registrada | `admin_page_f3base-relatorios` |
| Identificação esperada após criar Contatos | `contatos_page_f3base-relatorios` |
| Link efetivamente renderizado | `f3base-relatorios` |
| Primeiro submenu de Contatos | Relatórios; o item inicial da lista de contatos não é criado automaticamente |

Uma simulação que adia somente o registro desse submenu, sem alterar os arquivos do plugin, produz `admin.php?page=f3base-relatorios`, faz as identificações coincidirem e restaura o item inicial Contatos. Isso confirma a dependência da ordem de registro.

Há ainda uma ambiguidade no redirecionamento: `resultados` existe nas áreas `geral` e `conversao`. A busca atual escolhe a primeira ocorrência, podendo abrir uma área diferente da pretendida.

### Implementação prevista

1. Registrar o menu Contatos antes de seus submenus por uma sequência explícita. Preferir um ponto coordenador no registro do menu Contatos, chamando o registro de Relatórios depois da criação do pai, sem depender da ordem de inicialização dos módulos.
2. Garantir que o clique principal em Contatos abra a lista de contatos e que Relatórios permaneça como submenu próprio. Preservar Formulários, Conteúdo privado e Integrações.
3. Manter o endereço administrativo válido `admin.php?page=f3base-relatorios` como entrada e definir seu destino padrão explicitamente: `admin.php?page=f3base-medicao&area=conversao&visao=resultados`. Usar as funções de URL do WordPress, respeitando instalações em subdiretórios.
4. Substituir a resolução ambígua de área por um mapeamento explícito das visões válidas de relatório. Preservar os filtros suportados, inclusive a escolha de aplicar anotações; normalizar valores inválidos para um destino válido. O redirecionamento deve permanecer interno ao painel.
5. Preservar as permissões atuais: Relatórios exige `manage_options`; acesso à lista de contatos por uma permissão mais restrita não concede acesso aos relatórios.
6. Atualizar o histórico de alterações, a documentação integrada de navegação e a cobertura automatizada.

### Critérios de aceite

- Clicar no menu real Contatos → Relatórios, partindo do Painel, da lista de contatos e de Formulários, abre Medição → Conversão com resposta final 200, sem 404 ou ciclo de redirecionamento.
- O link renderizado contém a rota administrativa correta; o acesso direto à entrada de Relatórios chega ao mesmo destino padrão.
- O clique principal em Contatos abre a lista de contatos. Os demais submenus continuam funcionais.
- Visões e filtros válidos sobrevivem ao redirecionamento; parâmetros inválidos têm tratamento previsível e seguro.
- Um administrador vê e acessa Relatórios; um usuário sem a capacidade necessária não ganha acesso pelo menu nem pela URL direta.
- Verificar instalação nova e atualização da 1.18.0, além da composição correta da URL para WordPress em subdiretório.
- Executar os testes de navegação relacionados, lint e as verificações obrigatórias de empacotamento da release.

Os testes anteriores de interface acessavam a Medição diretamente pela URL. O novo teste deve atravessar o menu lateral para cobrir a falha reportada.

### Arquivos centrais

- `fontes/plugin/includes/class-f3base-leads-admin.php`
- `fontes/plugin/includes/class-f3base-relatorios.php`
- `fontes/plugin/includes/class-f3base-medicao-interface.php`, se necessário para normalizar destino e filtros.
- Testes de navegação e documentação integrada da próxima versão.

Não há necessidade prevista de alterar o esquema do banco ou a captura de dados para esta correção. Não há decisão de produto pendente para este item. A validação será local; nenhum teste em produção foi realizado nesta análise.

## Acesso provisório

Abrir **Medição → Conversão**. Também é possível acessar o endereço administrativo do próprio site com:

```text
/wp-admin/admin.php?page=f3base-medicao&area=conversao&visao=resultados
```

Em instalações em subdiretório, usar o caminho administrativo correspondente.

## Referências técnicas

- [WordPress: get_plugin_page_hookname](https://developer.wordpress.org/reference/functions/get_plugin_page_hookname/)
- [WordPress: add_submenu_page](https://developer.wordpress.org/reference/functions/add_submenu_page/)
- Fonte local da 1.18.0 e reprodução do HTML do menu no laboratório; a simulação alterou apenas a ordem dos callbacks em memória.

## 92 — renovação da prova de navegação

**Confirmado no código.** `F3Base_Navegacao::contexto_prova()` inclui a geração do cache; a prova vence em 24 horas. `verificar_publica()` exige `manage_options`, e só há os acionamentos por ability e AJAX. Simplesmente conectar esse método ao cron falharia por ausência de usuário autenticado.

Implementar:

- Extrair uma rotina interna de verificação, executada pelo cron sem usuário autenticado; manter autenticação e permissões nas entradas administrativas.
- Renovar a prova a cada 12 horas para haver margem antes da validade de 24 horas, com trava contra concorrência e novas tentativas limitadas em caso de erro.
- Agendar uma verificação após limpeza do cache ou mudança relevante de navegação, tema, menus e configuração. Unificar invalidações repetidas em um único trabalho pendente.
- Preservar a invalidação por contexto: retirar a geração do cache isoladamente não resolve o vencimento por tempo nem as outras mudanças relevantes.
- Mostrar última tentativa, última prova válida, próxima execução e motivo de pendência. Atraso de cron não produz conformidade artificial.
- Usar o agendamento nativo, sem exigir configuração na hospedagem. Uma visita administrativa ou chamada de diagnóstico pode reagendar trabalho vencido; a leitura não deve bloquear esperando a sonda HTTP.

Aceite: atualização e instalação nova agendam a rotina; uma limpeza invalida e dispara renovação; com o agendador executando, P66 permanece conforme no dia seguinte sem chamada manual. WP-Cron depende de execução do WordPress: ausência de tráfego ou cron desabilitado deve aparecer como atraso, sem prometer prazo de relógio garantido.

## 93 e 95 — carregamento de terceiros

### Configuração automática da Meta

Criar `f3base_meta_auto_config` booleano, padrão `true`, editável no catálogo, painel e `config-core-escrever`. Inserir `fbq('set', 'autoConfig', false, pixel)` antes de `init` quando desligado. Preservar `PageView`, `Lead`, consentimento, isolamento de testes e identificadores usados pela CAPI.

A configuração vale para o pixel gerenciado pelo Core. Tags duplicadas em tema, GTM ou outro plugin devem ser diagnosticadas; o Core não controla seus eventos. A descrição explicará a troca: reduz coleta automática, mas exige marcação explícita dos eventos desejados.

O ganho reportado veio de remover todo o pixel; isso não mede o ganho de desligar apenas autoConfig. A ausência de `SubscribedButtonClick`/`Microdata` exige conferência no ambiente Meta. Nesta análise a documentação Meta consultada respondeu bloqueio de acesso; o comando do pedido deve ser homologado com a versão efetiva do pixel antes de declarar esse aceite.

### Modo ocioso e prazo independente

- Acrescentar `ocioso` ao modo Google e aos modos Meta/LinkedIn. Manter `imediato`, `apos_interacao` e `herdar` com o efeito atual.
- Acrescentar `meta_teto_segundos` e `linkedin_teto_segundos`: `herdar` ou inteiro entre 1 e 30; padrão `herdar`. A estrutura existente com `meta` e `linkedin` como modos permanece válida.
- Em `ocioso`, aguardar `load`, então usar `requestIdleCallback` com prazo e temporizador de segurança. Sem suporte, usar temporizador pós-load. O prazo é contado do `load`; um consentimento concedido depois do prazo permite iniciar a partir da concessão.
- Não cadastrar gestos como gatilho de liberação em `ocioso`. Isso evita que o gesto ordene o carregamento; não garante que nenhuma execução coincida com uma interação posterior.
- Respeitar a categoria de consentimento e sua revogação em todos os caminhos. Agendamento, carregamento e drenagem de fila devem ser idempotentes. Eventos enfileirados preservam seu instante original e a classificação de teste.
- Cancelar timers/listeners ao liberar ou revogar, evitar duas inclusões da mesma tag e tratar navegação restaurada pelo histórico.

Aceite: Meta com teto próprio de 2 segundos e Google imediato; inclusão da Meta após load, sem depender de gesto, apenas uma vez. Testar com e sem `requestIdleCallback`, consentimento tardio, revogação, testes e restauração de página. Os 2 segundos são prazo solicitado ao navegador, sujeito a suspensão de aba e bloqueio da thread.

Comparar múltiplas execuções do mesmo roteiro antes/depois, mediana e dispersão de TBT/LCP; acompanhar INP/LCP de campo com volume e período explícitos. Não fixar uma nota PageSpeed prometida. As políticas novas entram somente onde ausentes: `false`, listas vazias e prazos escolhidos continuam intactos. Em particular, ativar o modo ocioso é uma escolha do site, não efeito automático da atualização.

## 88 — paridade entre relatório editorial e integrado

**Confirmado no código.** O editorial ancora sessões e eventos em `f3base_analise`, usa classificação de automação e resolve conteúdo público. O integrado tem outra consulta, incluindo `f3base_eventos`; os universos não são equivalentes. Os totais 149 e 44 são os reportados pela frota, não uma recontagem feita nesta análise.

Implementar uma camada comum de métricas de audiência, consultada pela interface, CSV e abilities. Acrescentar visão `resumo` e filtros de canal, tipo de conteúdo e automação em `relatorios-integrados-ler`, usando as mesmas definições do editorial. Nas visões de conversão, os denominadores de sessões e páginas devem vir dessa mesma camada; contatos sem sessão vinculável continuam visíveis com cobertura separada.

Entregar visitantes observados, sessões por canal, destaque orgânico/IA, conteúdo por canal, requisições de IA qualificadas, bloqueios e comparação com período anterior. Retornar período, fuso, filtros efetivos, anotações aplicadas, cobertura, fonte e versão da regra. Sessões não equivalem a pessoas únicas; o rótulo não pode prometer identidade humana comprovada.

Excluir automação e caminhos técnicos por padrão conforme o editorial. Histórico sem evidência suficiente permanece como histórico sem classificação, sem fabricar atribuição, visitantes ou sessões. Valores indisponíveis são `null` com motivo; não somar visitantes únicos de vários dias para estimar pessoas no período. Preservar a opção explícita de consultar automação e testes.

Aceite: mesmos recortes e mesma fotografia de dados produzem exatamente os mesmos totais em tela e ability; incluir casos com eventos antigos sem análise, anotações, testes, automação, dados expirados, `/wp-admin/` e sitemaps. A versão do contrato deve explicitar a correção das definições, preservando o parâmetro `method`.

## 82, 83 e 90 — IA, conteúdo e automação

### Classificação efetiva e rede — 82

Criar uma regra única de classificação efetiva, usada por todas as consultas e resumos. Uma família declarada como IA, com IP confiável e resultado `fora_das_faixas` de uma lista oficial válida, passa para `automacao-suspeita`. Preservar `agente_declarado`, finalidade declarada, estado/lista/data da rede e motivo `ip_fora_das_faixas_oficiais`.

`rede_compativel` permanece compatibilidade observada; não prova o uso final do conteúdo nem autenticação absoluta do operador. `sem_fonte_oficial`, `fonte_expirada`, `ip_nao_confiavel` e histórico não verificado continuam identificados como não verificados, sem virar verificados nem suspeitos por ausência de evidência.

Aplicar a regra também aos agregados existentes que já têm `rede_estado`, inclusive hora, dia e observações temporárias. A família original não deve ser sobrescrita de forma irreversível. Dados antigos sem essa dimensão permanecem desconhecidos. Reprocessamento usa contribuição idempotente, quando o log ainda está disponível.

Aceite: mesma linha deixa os resumos de treino/busca/resposta e aparece no painel de automação suspeita, sem aumentar o total geral. A visualização de suspeitos deve permitir caminhos técnicos/varreduras: a exclusão editorial de `/.env` continua, mas não pode esconder a evidência nesse diagnóstico. Nenhum IP é adicionado aos agregados.

### IA por conteúdo — 83

Reutilizar os agregados de log, ampliando a consulta para incluir agente, finalidade, rede, método, status, contagem e última ocorrência. A linha de cada página/artigo deve apresentar:

- Requisições de OpenAI/ChatGPT, Anthropic/Claude, Google/Gemini quando identificável e demais agentes reconhecidos; distinguir operador declarado de finalidade treino/busca/resposta.
- HTML e Markdown do Core associados ao mesmo conteúdo, conservando a representação para comparação.
- Atendimentos, bloqueios, redirecionamentos e erros; primeira/última ocorrência com fuso legível.
- Sessões humanas observadas com origem IA, navegações, tempo ativo quando disponível, início de formulário e envios aceitos, no mesmo recorte de conteúdo.
- Série semanal e comparação com período anterior, indicando semanas parciais e cobertura incompleta.

`/llms.txt` e `/llms-full.txt` terão resumo próprio de descoberta. A leitura do índice não conta como uma leitura de cada artigo. GET 200, HEAD e 304 precisam de rótulos distintos: HEAD não entrega corpo e 304 observa revalidação. Um acesso de robô não prova citação, recomendação ou treinamento; uma visita com referência de IA não prova qual acesso anterior do robô a causou. Referências conferidas continuam com sua própria evidência.

Aceite: por artigo, responder qual agente requisitou qual representação, quando e com qual status, e quantas sessões com origem IA foram observadas. O aceite mede leitura por IA, no sentido de requisições observadas, e visitas vindas de IA; citação e recomendação não se medem pelo servidor. IA não verificada e automação suspeita têm totais separados dos compatíveis com rede oficial. Ausência de log não equivale a ausência de leitura.

### Assinatura reduzida — 90

Acrescentar `assinatura_ua` e versão da regra aos agregados diários, horários, por fonte e temporários; incluir nas chaves de agregação, relatórios e CSV. Extrair somente produtos técnicos de um vocabulário controlado, removendo versões, URLs, e-mails, comentários livres, endereços e identificadores. Não guardar o user-agent integral nem um hash que funcione como identificador individual.

Exemplos de rótulos: monitor reconhecido, `curl`, `python-requests`, cliente HTTP genérico ou assinatura desconhecida. Associação a operador só com evidência da assinatura conhecida ou classificação administrativa explícita. `curl` identifica uma ferramenta, não quem a executou.

**Aceite definido pelo dono:** volume em `/` agrupado por assinatura, com a parcela sem operador identificável contada à parte. Apresentar operador somente quando houver evidência. Histórico só pode ganhar assinatura se o log original ainda existir.

## 17 — formulários e contatos

### Já atendido; conservar e testar

- Agrupamento dos avisos por e-mail já existe em `F3Base_Leads_Notificacoes`: limite de avisos individuais e resumo horário dos pendentes. Preservar, com regressão da passagem ao resumo, reserva dos registros, destinatários, exclusão de suspeitos/lixeira e separação de testes. A regra não é agrupar leads pela identidade de quem preencheu. O filtro de contatos pelo endereço também permanece; não fundir nem apagar leads.
- Concessões vencidas/revogadas/esgotadas respondem 410; a confirmação temporária também responde 410. Manter a regra e testar que nenhum desses caminhos reabre o formulário automaticamente. Token inválido continua com a resposta de segurança adequada, sem revelar concessões.
- Mensagem de confirmação e assunto por formulário já existem. A entrega completa as opções que faltam.

### Implementar

1. `confirmacao_url` por formulário, opcional, gravável no editor e por ability. Aceitar URL interna normalizada; destinos externos somente com autorização explícita de host na configuração. Rejeitar esquemas perigosos e credenciais embutidas. Sem campo, permanece a mensagem atual.
2. Redirecionar somente após persistência e resposta de sucesso, em JS e no envio sem JS. Não incluir nome, e-mail ou outros dados pessoais na URL. Para conteúdo privado e WhatsApp, preservar a ação de download/continuação por referência temporária privada; definir no editor a interação com a página de confirmação para não perder o material ou o contato. Nunca disparar nova conversão pelo simples carregamento da página de obrigado.
3. Mensagens por formulário para envio, validação e falhas esperadas, com chaves fechadas e fallback. Erros técnicos não podem ser mascarados como sucesso. Preservar o fluxo antispam e não expor o motivo interno de suspeita ao visitante.
4. Expandir `{nome}` no assunto a partir do campo com papel `nome`, antes da composição final, com fallback legível, limite de tamanho e remoção de quebras de linha. A prévia deve usar a mesma função; manter o nome do site sem duplicação.
5. Registrar e exibir alerta quando extensão e MIME detectado por `finfo` divergirem de forma reconhecível. O alerta não cria uma nova lista global de extensões proibidas. Arquivo permanece privado e servido como download; políticas de cada campo continuam válidas.
6. Mostrar antes do envio os limites de arquivo e de requisição do PHP, quantidade máxima e limite explícito do campo. O total de `post_max_size` inclui todos os arquivos e campos. Validar no navegador quando mensurável; o servidor permanece autoridade. Proxy desconhecido deve ser apresentado como desconhecido, sem inventar um teto. Não reintroduzir 10 MiB por padrão.
7. Introduzir variáveis `--f3base-form-*` para espaçamento, cores, borda, raio, foco e botões, com fallbacks. Acrescentar `wp-element-button`; manter rótulos, foco, erros acessíveis e navegação por teclado. O tema define a identidade visual.

Aceite: fixture equivalente ao formulário ctooffice salva e usa a página de confirmação sem mapa específico do site; cobre os três regimes, com/sem JS, falhas, spam, arquivos e links expirados. O Core entrega configuração genérica; migrar um mapa proprietário do tema não é responsabilidade do plugin. Preservar o nome e os valores de `method` na medição.

## 96 — arquivos privados operáveis por agentes

Adicionar abilities de cadastro, listagem e substituição, com permissões equivalentes à gestão de conteúdo privado. Os nomes finais e schemas devem constar do contrato instalado.

- Cadastro por bytes codificados na chamada ou por ID de anexo local da biblioteca de mídia. Proposta de teto de transporte: 8 MiB decodificados por chamada, declarado no schema e no diagnóstico, sujeito a limite menor do canal/PHP. Isso limita apenas esse transporte; não altera a política dos anexos de formulário ou da importação local de mídia.
- Validar autenticação, finalidade, tamanho real, espaço, MIME por `finfo`, nome, SHA-256 esperado e raiz privada. Reutilizar um núcleo comum de validação, mantendo `is_uploaded_file()` obrigatório no caminho de upload HTTP; não aceitar caminhos arbitrários, URLs remotas ou substituições por symlink.
- Listagem paginada: ID, nome, bytes, MIME, SHA-256, criação, atualização, estado e formulários vinculados. Não expor caminho físico, token ou URL de concessão.
- Importação de mídia copia o arquivo; por padrão a origem pública permanece e o retorno avisa isso. Oferecer exclusão como operação explícita posterior à cópia verificada, mostrando vínculos conhecidos. Não prometer remoção de caches ou cópias externas. Nenhuma exclusão automática na atualização.
- **Comportamento decidido: seguir a versão nova.** Concessões vigentes passam a entregar o arquivo novo pelo mesmo link. Substituição exige ID, `expected_sha256` e chave de idempotência. Verificar nova versão antes da publicação; preservar ID, formulários, tokens, expirações, quotas, contadores e revogações.
- Hoje `concessoes.versao` precisa coincidir com o SHA-256 do ativo. A substituição deve publicar a versão e atualizar o vínculo das concessões ainda válidas de forma consistente. Concessões expiradas/revogadas não são reativadas. Downloads concorrentes recebem um arquivo íntegro; falha antes da publicação mantém a versão anterior, e o estado permite retomar a operação.

Aceite: cadastrar PDF, configurar formulário, conceder e baixar apenas por abilities; substituir, observar SHA diferente com o mesmo ID e baixar a nova versão pelo mesmo link ainda válido. Cobrir concorrência, falha de disco/banco, hash divergente, permissões e tentativa de reativar link vencido.

## 97 — contrato de ofertas do tema

Adotar `data-f3base-oferta` com `modal|folha|barra|bloco` e `data-f3base-oferta-id` com o padrão de identificador de formulário. `data-f3base-superficie` permanece com sua finalidade atual. Cada contêiner deve ter um formulário do Core; ambiguidade ou ID inválido gera diagnóstico.

Definir instância como uma apresentação do contêiner em um carregamento/navegação. O mesmo nó reaberto na mesma navegação continua a mesma instância nesta versão; início/fim de ciclo diferente exige novo contrato explícito. IDs estáveis de oferta podem aparecer em várias páginas, mas não devem identificar ofertas diferentes dentro do mesmo carregamento.

O Core detecta visibilidade real do formulário, desconsiderando contêiner oculto e aba oculta, e registra uma exibição por instância. Aceita `f3base-oferta-aberta` com `gatilho=rolagem|saida|tempo|clique` e `f3base-oferta-fechada` com `motivo=botao|esc|fora|navegacao`, no próprio contêiner. Valores inválidos são descartados; repetir o evento não aumenta a contagem. Abertura sinalizada sem exibição observada não é tratada como impressão.

Adicionar eventos internos `oferta_exibida`, `oferta_aberta`, `oferta_fechada`, com ID/tipo de oferta, formulário, navegação e instância. Mapear ao GA4 como eventos personalizados documentados com `form_id`, `oferta_id`, `oferta_tipo`, gatilho ou motivo aplicável, sob as mesmas regras de consentimento/testes de `form_start`. A implementação deve definir nomes finais únicos no catálogo, sem duplicar a exibição por duas rotas de coleta.

Relacionar início e envio aceito à oferta/instância de origem. O denominador do funil exibida → iniciada → enviada é a instância observada, com etapas únicas; envios de outras instâncias ou formulários não são encaixados à força. O total de formulários aceitos vem do servidor. Relatórios mostram também fechamento, motivo, gatilho e cobertura, em tela e `relatorios-integrados-ler`.

Incluir os auxiliares opcionais `podeExibir(id,dias)` e `registrarExibicao(id)` como consulta de elegibilidade e registro idempotente. Persistência apenas conforme o consentimento; sem autorização, usar memória da página. Limite por oferta e supressão após conversão confirmada da oferta não podem criar perfil entre sites. O tema decide quando mostrar, ocultar e construir o modal; o Core não injeta apresentação nem gatilhos.

Diagnóstico sobre o HTML servido identifica marcações válidas, ausentes e inválidas. Conteúdo criado só por JS deve ser distinguido de erro; complementar com observação de runtime quando disponível. Não inferir frequência real a partir de HTML estático.

Aceite: fixture de tema gera uma exibição, abertura e fechamento válidos por instância; repetições e valores inválidos não contam; rejeição de consentimento e teste não chegam aos destinos reais. Verificar oferta sem formulário, múltiplas instâncias, conversão, frequência e visita restaurada. Aceite de GA4 em tempo real é homologação externa posterior à entrega, executada pela frota.

## 94 — envio pelo servidor restrito à Meta

**Decisão do dono de 30/09/2026:** esta release implementa o item 94 somente para Meta. GA4 continua pela tag; não haverá modo `ambos` nem `servidor` para GA4. Novos transportes de Google Ads e LinkedIn ficam adiados. A aprovação da retenção temporária do IP encerra a decisão pendente, preservando os critérios técnicos de homologação por site.

### Escopo e exclusões explícitas

| Destino | Comportamento nesta release |
| --- | --- |
| Meta | `navegador`, `ambos` com deduplicação e `servidor` sem `fbevents.js`, após homologação. Expandir a CAPI atual de Lead para PageView e eventos explicitamente mapeados. |
| GA4 | Coleta pela tag. Recusar `ambos` e `servidor`; não duplicar eventos por Measurement Protocol. |
| Google Ads | Preservar o transporte atual pelo navegador; nenhuma nova integração de envio pelo servidor neste item. |
| LinkedIn | Preservar o transporte atual pelo navegador; nenhuma nova integração de envio pelo servidor neste item. |

O GA4 não oferece deduplicação genérica entre tag e Measurement Protocol pelo mesmo `event_id`. Copiar os mesmos eventos pelos dois caminhos não atende ao modo `ambos` e produz duplicação. O Measurement Protocol é documentado como complemento à coleta por tag, sem demonstrar substituição integral de sessões e atribuição [S1]. O plano não estende esse comportamento a mecanismos específicos de outros eventos ou produtos.

Carregamento das tags continua coberto pelos itens 93 e 95; transporte Meta é configuração separada. A atualização não ativa servidor automaticamente. Preservar o Lead CAPI já configurado: a introdução de uma option com padrão navegador não pode desligar a combinação existente. Instalação nova não ativa destinos nem credenciais sozinha.

### IP: retenção necessária à entrega, ampliada em 01/10

- Guardar o IP original somente no payload pendente protegido da fila Meta enquanto houver possibilidade útil de entrega. Adotar teto operacional de **sete dias a partir do evento original**, reduzido quando a janela efetiva de aceitação ou de deduplicação exigir. Uma tentativa ou reagendamento não reinicia prazo, `event_time` nem `event_id`.
- A remoção do teto de 24 h evita perder a capacidade de correspondência durante interrupções temporárias. Não reter sete dias um evento já entregue, cancelado, definitivamente recusado ou sem tentativa útil restante. Registrar `expira_em` e o motivo do prazo efetivo na fila, sem IP no diagnóstico.
- Eliminar o IP e demais dados de correspondência do payload após entrega confirmada, expiração, revogação ou outro desfecho terminal. Conservar somente metadados não pessoais necessários ao diagnóstico. A limpeza também deve alcançar trabalhos cancelados e interrompidos.
- Não adicionar IP a relatórios, agregados, logs de diagnóstico ou exportações. Esta decisão não amplia a retenção existente nos leads.
- Excluir o payload transitório com IP de exportações e backups produzidos pelo próprio Core. Inventariar esses caminhos e documentar que cópias integrais independentes do banco/hospedagem têm gestão de retenção própria; o plugin não pode prometer eliminação de cópias que não controla. Não persistir IP em um backup nomeado como mecanismo de recuperação da fila.
- Obter IP da requisição e da configuração confiável de proxy, nunca de campo livre do navegador; não substituir pelo IP da hospedagem.
- Proteger o payload armazenado, restringir leitura e documentar gestão das chaves. Criptografia não transforma o IP em dado anônimo; permissões, revogação e prazo continuam obrigatórios.

### Captura e fila

Capturar visitas pelo script próprio, inclusive em página cacheada. Envelope Meta inclui ID de evento, instante original, consentimento e sua versão, classe de tráfego, URL/contexto permitido, formulário/oferta quando aplicável e identificadores válidos. Preservar nomes e parâmetros do catálogo Meta efetivamente utilizado.

Reaproveitar `_fbp` e `_fbc` válidos sob consentimento. Quando a política permitir, criar identificador de navegador conforme o formato oficial; `_fbc` só com evidência real de clique Meta. Não inventar click IDs, restaurar identidade revogada ou enviar informações pessoais como parâmetros livres. Normalizar e aplicar hash a e-mail/telefone quando o evento e o consentimento permitirem.

Preservar o prazo inicial de 5 segundos da análise (item 38, decisão do dono). O envelope Meta terá descarga em `visibilitychange`/`pagehide`, inclusive na saída anterior ao prazo, com o mesmo ID idempotente; integrar ao transporte próprio quando possível, sem alterar o temporizador global da análise nem duplicar PageView. Navegador encerrado ou sem rede continua sendo limitação de cobertura: não prometer entrega absoluta. A extensão de captura autorizada pelo item 94 não autoriza antecipar todos os eventos da análise.

O recebimento próprio apenas valida e enfileira; nenhuma chamada externa na requisição do visitante. A fila deve ter chave idempotente, teto de tamanho/pendências, reserva concorrente, novas tentativas limitadas, recuo, classificação de recusa permanente, expiração e cancelamento por revogação. Processar em lotes pelo agendador nativo, com orçamento por execução e diagnóstico de atrasos, sem daemon ou pedido à DreamHost.

O teto operacional adotado é sete dias, contando do evento original; priorizar entrega em minutos. Aplicar o menor prazo entre esse teto e as condições verificadas do transporte: idade aceita pela API, deduplicação quando houver emissão pelo Pixel/GTM e segurança de repetição quando uma tentativa anterior tiver resultado incerto. A janela de aceitação de um evento atrasado não comprova que ele será deduplicado durante todo esse período. No modo `ambos`, não prolongar tentativas além da janela demonstrada de deduplicação; em resultado remoto incerto, registrar a limitação e impedir repetição que não seja segura. Não alterar o instante do evento para contornar expiração.

Sete dias é o teto de projeto para a fila, consistente com a janela citada no pedido da frota; a verificação dos limites atuais da versão Meta e da deduplicação é requisito de implementação/homologação. As páginas oficiais consultadas em 01/10 responderam 429, portanto esta revisão não apresenta esses limites externos como novamente confirmados. O diagnóstico deve mostrar o prazo efetivo e a regra/fonte usada, que pode ser menor que sete dias.

A limpeza por prazo não depende de uma tentativa de envio bem-sucedida; se o agendador parar, mostrar atraso e limpar assim que voltar, sem apresentar como cumprida uma eliminação física que ainda não ocorreu. No primeiro processamento após a retomada, eliminar dados vencidos antes de enviar lotes. Conservar os metadados agregados de entrega depois de remover o payload pessoal.

Consentimento e regras de teste valem para captura, fila e envio; revogação cancela dados pendentes. Testes não chegam ao destino real sem a configuração de homologação já admitida pelo Core. Guardar token Meta fora do catálogo público; segredo ausente recusa a mudança, com motivo, sem expor o valor.

### Deduplicação e prova para ativar servidor

No modo `ambos`, compartilhar `event_name` e ID entre Pixel e CAPI conforme o contrato Meta. Repetição de transporte mantém o ID; evento diferente recebe outro. O envio do Pixel, o enfileiramento e o processamento da CAPI devem preservar a mesma referência de origem.

Uma ability deve devolver contagens diárias por evento e rota: elegíveis, capturados, disparados, enfileirados, aceitos, pendentes, rejeitados e expirados. Separar evidência local de processamento/deduplicação observada no Gerenciador de Eventos. Callback do pixel e `sendBeacon=true` não comprovam recebimento remoto. EMQ só é apresentada quando obtida da Meta, com conta, período e origem da evidência; ausência não é aprovação.

Comparar a mesma população consentida, fuso, período e evento. Bloqueadores podem gerar mais eventos pela rota servidor; explicar a diferença com evidência disponível. O total editorial de sessões não é denominador automaticamente equivalente ao da plataforma.

Aceite operacional: sete dias completos em `ambos`, sem duplicações nos cenários controlados, sem descartes inexplicados e diferença residual por evento de até 5%, com volume suficiente. Com menos de 100 eventos elegíveis de um tipo, indicar amostra insuficiente e ampliar a janela, complementando com teste controlado de homologação. A tolerância não autoriza omitir sinal conhecido. Todo Lead elegível precisa de desfecho conciliável individualmente.

Somente liberar `servidor` se houver equivalência do catálogo usado, prova externa de deduplicação e correspondência, credencial válida e condições de consentimento atendidas. AutoConfig ativo ou qualquer sinal usado sem equivalente bloqueia a troca. Conta, catálogo, política ou configuração relevante alterados invalidam a prova anterior.

Após a ativação, comprovar ausência de `fbevents.js` e acompanhar PageView/Lead por mais sete dias. Tags Meta incluídas por terceiros devem ser detectadas e impedir a alegação de remoção total. A homologação será feita pela frota após a entrega; a implementação do pacote não será anunciada como homologação externa já concluída.

### Adiamentos

GA4 pelo servidor e duplicação via `ambos` ficam excluídos desta release. Novos transportes Google Ads/LinkedIn ficam adiados por decisão de escopo; sua avaliação futura terá de demonstrar equivalência das funções usadas, atribuição e deduplicação específica. Nenhum desses adiamentos reabre a decisão de IP ou o comportamento das concessões.

## 98 — contrato do canal MCP 0.13.0

**Confirmado na fonte 1.18.0:** o ponto comum `F3Base_Servicos::registrar_ability()` acrescenta somente `meta.fator3.version`; o cabeçalho usa `Update URI: false`. O novo anexo e o item 25 do documento de pendências do canal descrevem o contrato de provedor. O pacote executável 0.13.0 e o Core 1.17.1 de homologação não estavam disponíveis entre as fontes recuperadas: assinatura do callback, identificador do provedor e esquema de registro precisam ser conferidos nesses artefatos antes da implementação. O plano antigo do canal não substitui esse contrato.

Implementar no Core 1.19.0:

1. Registrar o provedor no gancho `f3_mcp_register_providers`, com prefixo `f3base/`, identidade estável e versão real do plugin. Usar a assinatura do canal, sem copiar a base antiga nem rebaixar a versão.
2. Declarar `meta.fator3.provider`, `version` e `policy_contract: 1` em todas as abilities do Core. Inventariar registros que não passem pelo helper central. Metadados não substituem as permissões WordPress.
3. Conferir classificação de cada operação: leitura armazenada, consulta externa com consumo de cota, coleta que grava, edição de configuração/segredos e exclusão. Não marcar como leitura uma escrita só porque seu nome termina em `ler`; não ampliar o perfil Leitura para resolver uma recusa.
4. Substituir `Update URI` por identificador próprio coordenado com a fonte de atualização do canal. Cabeçalho de identidade e endereço do ZIP são coisas distintas; testar oferta da versão, origem, hash e instalação. Não criar um atualizador paralelo.
5. Manter o Core funcional sem o plugin MCP ativo. O registro deve tolerar a ausência do canal e a ordem de carregamento, sem fatal e sem rota anônima adicional.

Aceite em laboratório: Core 1.19.0 + canal 0.13.0 executam uma leitura `f3base/*` com perfil Leitura; o mesmo perfil não modifica configuração nem cadastra arquivo. Perfil autorizado executa sua operação e perfil insuficiente recebe recusa legível. Cobrir metadados de todo o catálogo, novas rotas Clarity, ativação sem MCP, instalação nova e atualização 1.18.0. O piloto real é homologação da frota. A disponibilidade do contrato executável é dependência técnica, não nova decisão de produto.

## 99 — GTM junto das tags diretas

**Confirmado na fonte:** `caminho()` escolhe GTM de forma exclusiva; `dados_de_medicao()` esvazia os outros IDs; há retornos antecipados em tracking e leads. Trocar apenas o carregador deixaria conversões sem envio direto.

### Emissão e contrato de eventos

- Substituir a exclusividade por destinos independentes. GTM configurado não apaga GA4, Ads, Meta ou LinkedIn configurados. As regras explícitas de consentimento, testes e modo de transporte Meta continuam valendo. O ID citado de ctooffice é configuração daquele site, nunca default do pacote.
- Preservar a política atual do GTM e publicar o consentimento inicial antes do carregador. Não sobrescrever `window.dataLayer`. Aplicar categorias de consentimento por evento; um contêiner carregado não recebe automaticamente dados de uma categoria recusada.
- Com GTM preenchido e permitido, publicar uma vez o objeto `{event, ...parametros}` para os eventos do catálogo, incluindo comportamento, `form_start`, `generate_lead` e ofertas. `generate_lead` conserva `form_id`, `method` e `correlation_id`. Não incluir respostas pessoais de formulário, tokens ou segredos.
- Manter o comando direto `gtag('event', ...)`, com `send_to` explícito para o destino correto. O objeto para GTM não pode voltar a entrar no emissor direto. IDs, instante, consentimento e classificação de teste permanecem os da ocorrência original, inclusive após espera pelo carregamento.
- Documentar para o fornecedor do contêiner: gatilho, parâmetros, ID de destino, consentimento, testes e mapeamento `correlation_id` → `eventID` do `Lead` Meta. Para outros eventos Meta, usar o ID canônico da ocorrência, documentado no item 94. A deduplicação exige também o mesmo nome de evento e o mesmo destino.

A documentação Google descreve o papel da chave `event` no dataLayer [S7]; ela não substitui o teste de contagem com os carregadores reais. O aceite deve provar que publicar o objeto adicional não duplica o evento direto quando não há tag correspondente no contêiner.

### CAPI quando o Pixel vem do GTM

O aceite do anexo deixa vazio o slot do Pixel direto. Hoje `F3Base_Modulo_Meta_Capi::pixel_id()` lê exatamente esse slot; portanto, o cenário não funciona apenas com GTM aditivo.

Acrescentar `f3base_meta_capi_pixel_id`, opcional e validado, como destino da CAPI. Vazio herda o `f3base_meta_pixel_id` já existente; preenchê-lo não carrega Pixel direto. Exibir origem e ID efetivo no diagnóstico, mantendo o token secreto. No teste de GTM, o novo campo informa o mesmo Pixel usado pelo contêiner. A fila conserva o destino capturado; alteração posterior não redireciona eventos antigos para outra conta. Divergência entre IDs gera aviso e impede declarar deduplicação entre aqueles destinos. O modo `ambos` pode usar a emissão de navegador pelo GTM, desde que sua equivalência seja homologada; não exigir Pixel direto para esse teste.

### Duplicação e diagnóstico

Não pedir ao dono declaração de cobertura do contêiner nem condicionar o envio direto a essa declaração. A presença de um ID ou SDK não prova que um evento já foi entregue. Reutilizar inicialização comprovadamente existente quando seguro, mas não suprimir a ocorrência direta por mera suspeita de duplicação. A duplicação causada por tags externas que o pacote não consiga controlar é aceita pela decisão registrada; deve aparecer como limite de cobertura.

Diagnóstico em `como-usar`, assunto `tracking`: destinos configurados/efetivos, GTM aditivo, coincidências encontradas, fonte e data da observação, estado `nao_verificavel` quando necessário. A inspeção do JS público do contêiner será limitada ao host oficial, tamanho, tempo e cache; nunca executá-lo no servidor. Busca estática é melhor esforço: ausência de ID literal não prova ausência de tag. Complementar com observação de rede em homologação, incluindo Clarity. Não buscar o contêiner a cada visita.

Atualizar catálogo, ajuda dos campos e descrições que hoje prometem caminho único. O modo Meta servidor controla a emissão do Core; se GTM ou outro emissor incluir `fbevents.js`, não declarar a página sem Pixel nem aprovar essa condição do item 94.

Aceite: slots novos/vazios preservam emissores e contagens da 1.18.0; GTM vazio não acrescenta requisições. Comparação de HTML normaliza somente diferenças inevitáveis de versão/nonce e separa outras mudanças autorizadas da release. Com contêiner publicado vazio, confirmar mesmas contagens GA4 `page_view`/`generate_lead` e Meta `PageView`/`Lead`; repetir com consentimento tardio, bloqueio de script e modo de teste. Com Pixel só no GTM e CAPI configurada pelo novo campo, comprovar `Lead` deduplicado. Contêiner com o mesmo `G-` e projeto Clarity deve produzir diagnóstico de coincidência quando detectável, sem cortar a tag direta.

## 100 — Microsoft Clarity no navegador

### Configuração e carregamento

Criar `f3base_clarity_project_id`, vazio por padrão, no catálogo, painel e `config-core-escrever`. Validar identificador de projeto, sem aceitar URL ou código JavaScript; documentar o formato e o limite efetivamente homologados. Sem ID, não criar stub, carregar SDK, emitir evento Clarity ou abrir conexão antecipada ao fornecedor.

Adicionar `clarity` a `f3base_carregamento_destinos`, padrão `herdar`, com `imediato`, `apos_interacao` e `ocioso` conforme item 95; teto próprio opcional com o mesmo contrato dos demais destinos. Acrescentar Clarity à supressão de testes. Atualização não cria projetos nem preenche IDs: a frota configura o projeto de cada site por canal.

### Consentimento, testes e privacidade

Usar o portão de medição para permitir a inclusão do SDK e mapear separadamente publicidade e medição para `ad_Storage` e `analytics_Storage`, com valores `granted|denied`. Enfileirar `consentv2` com o estado vigente antes de carregar o fornecedor; repetir somente quando o estado mudar. Homologar que essa ordem chega ao SDK antes da primeira coleta. A Microsoft recomenda V2; a referência consultada descreve a V1 como prevista para descontinuação, não como já removida [S8].

`consentv2` negado não significa SDK desligado: a documentação permite coleta limitada sem cookies [S8]. A regra do Core continua sendo não iniciar Clarity com medição recusada. Se houver revogação depois de iniciado, cancelar filas/agendamentos, atualizar consentimento e interromper a captura. O fonte oficial expõe `stop()` [S12]; testar o comportamento na tag efetivamente entregue, incluindo eventual descarga final de dados capturados antes da revogação. Não usar apenas remoção da tag DOM como prova de parada. Depois de parada, a próxima navegação consentida pode iniciar nova captura; não prometer retomada do mesmo registro sem suporte comprovado.

O navegador já marcado para suprimir testes não carrega o script. Ativação de testes no meio de uma página interrompe a captura futura; não apaga a parte já enviada como visita normal. `/f3base-teste/` e páginas administrativas não gravam sessão. O aceite de nenhuma sessão de teste pressupõe a marcação antes da visita que será testada.

Auditar telas e fragmentos que o Core renderiza com nome, e-mail, telefone ou mensagem do visitante. Marcar apenas esses elementos com `data-clarity-mask="true"`, inclusive inserções após envio; não marcar indiscriminadamente formulário inteiro, conteúdo editorial ou botões. Inputs e selects já são mascarados em todos os modos [S9]. Registrar os pontos encontrados ou declarar que não há eco de dado pessoal. Mascaramento do DOM não protege URLs: não incluir Clarity em endpoints privados que exponham token de concessão/confirmação, nem transmitir esse token como tag, evento ou URL de relatório.

Em conversão aceita, usar `clarity('set', 'form_id', ...)` e `clarity('set', 'method', ...)`, com valores do catálogo [S10]. Não enviar `identify` com nome, e-mail, telefone ou hash desses dados; esta versão não precisa criar identificador compartilhado entre Clarity e lead. Os rótulos não provam uma relação individual exportável pela API agregada.

### Diagnóstico e aceite

Exibir projeto configurado, política efetiva, supressão, último estado de consentimento observado e coincidências detectadas no GTM, sem listar dados de visitantes. A configuração do servidor não prova o consentimento de todos os navegadores. Se o fornecedor externo contornar o portão, registrar interferência.

Cobrir slot vazio, concessão/revogação, anúncio recusado com medição permitida, ocioso, carga concorrente, teste marcado e mudança para teste. Verificar ausência de dados pessoais nas confirmações em gravação com projeto Relaxado. Comparar mediana de três medições PageSpeed equivalentes antes/depois, mais custo de requisições e execução; não prometer custo zero. Diagnosticar CSP incompatível sem alargar a política global silenciosamente. Sessão visível no projeto, máscara e rede real são homologações externas da frota, separadas dos testes do pacote.

## 101 — consultas e histórico do Clarity: incluído nesta versão

### Ajuste necessário ao método proposto

A API documenta apenas janelas móveis de 24/48/72 horas, até três dimensões, dez chamadas por projeto/dia e até mil linhas sem paginação [S11]. Não há parâmetro de início/fim fixo no contrato consultado. As seguintes conclusões são análise técnica desse contrato, não garantias dadas pela Microsoft:

- Chamadas de 24, 48 e 72 h não têm uma fotografia transacional comum. Dispará-las em paralelo não fixa o mesmo instante final nem o estágio de processamento dos dados.
- Subtrair conjuntos de sessões/usuários pode remover sessões que aparecem nos dois intervalos. Sem regra documentada de atribuição temporal e denominadores por métrica, não há prova de aditividade; ponderar toda média pelo número de sessões também não é válido automaticamente.
- A igualdade entre soma das diferenças e janela maior é uma identidade algébrica; não prova que cada faixa corresponde ao dia alegado. Resultados negativos identificam algumas inconsistências, não todas.
- Consultar novamente horas depois muda a janela. Isso não mede, isoladamente, atraso de processamento da mesma janela.

Portanto, **não implementar a diferença de janelas como faixas diárias completas nem usá-la para preencher lacunas**. A decisão de 01/10 mantém o histórico no escopo com preservação máxima das consultas originais, segundo o desenho abaixo. Ele atende à preservação das informações retornadas e evita soma indevida; a reconstrução exata de cada dia continua sem suporte demonstrado. A fonte editorial do Core oferece a série diária própria; Clarity acrescenta indicadores de experiência dentro das janelas que realmente devolveu. Não substituir a API por raspagem do painel ou um endpoint interno para fabricar datas arbitrárias. A inclusão do histórico está decidida e não depende de nova confirmação.

### Credencial, coleta e cotas

Criar segredo `f3base_clarity_api_token`, no padrão dos segredos existentes, vinculado ao projeto. Escrita/substituição/remoção com permissão adequada, somente presença e estado nas leituras, fora de HTML, configuração exportada e logs. Token ausente deixa a coleta desativada; não prejudica o site. Troca de projeto segmenta o histórico e impede misturar projetos.

Coletar pelo cron nativo, nominalmente a cada 24 h, e por `clarity-coletar`, reutilizando rotina interna sem usuário autenticado no cron. Trava por projeto, reserva atômica de orçamento e chave de execução evitam concorrência e repetição da mesma tentativa. Uma falha de persistência permite retomar a resposta já obtida; não repetir HTTP desnecessariamente. `ler` nunca dispara coleta ou renovação oculta.

Plano de consultas: preservar consultas de 24 h para rotina e usar também 72 h para cobertura recente mais ampla; a janela de 48 h permanece disponível quando apropriada ao atraso/recorte. Essa consulta amplia cobertura observada, não recupera dias isolados. Priorizar total sem dimensões, URL × Device e URL × Channel; acrescentar Source × Medium × Campaign e Browser × OS × Country/Region dentro da cota. Usar até oito chamadas automáticas úteis por dia, priorizando falhas/recortes truncados sobre dimensões secundárias, sem desperdiçar cota repetindo parâmetros equivalentes na mesma execução. Reservar as duas consultas manuais já previstas. Registrar por que cada recorte foi coletado, adiado ou omitido; a cota impede garantir todos os cruzamentos em todas as janelas.

Guardar tentativa/recebimento em UTC e duração; se não houver limites temporais na resposta, o fim é nominal ao instante da consulta, com precisão declarada, não um limite exato inventado. Repetições em horários diferentes são consultas distintas, mesmo quando os valores coincidem. As janelas de 72 h não sobrescrevem as de 24 h nem substituem uma fotografia histórica anterior.

Limitar tentativas automáticas a oito por dia e reservar duas para consultas manuais ao vivo, contando também falhas e alternativas de recorte de forma conservadora. Toda chamada externa sob demanda passa pelo mesmo orçamento; `coletar` não o contorna. Recebido 429, interromper até a próxima janela de cota aplicável e respeitar eventual `Retry-After`. Manter dia UTC como chave operacional local, indicando que a documentação consultada não define explicitamente o horário de reinício da cota.

A cota é do projeto: outro site, MCP ou consumidor pode gastá-la. O contador local mede consumo conhecido, não saldo garantido na Microsoft. Preferir um projeto por site; compartilhamento exige coordenação de orçamento ou diagnóstico de consumo externo. Não criar chamada de sondagem a cada abertura do painel.

### Dados armazenados e consulta

Criar `{prefixo}f3base_clarity` para valores por **consulta**, com identificador da coleta, projeto, janela solicitada, início/fim nominais UTC, precisão temporal, recorte, dimensões permitidas, métrica, valor, unidade, denominador quando fornecido e estado. Criar registro de coletas para origem cron/manual, resposta, horários, linhas por bloco de métricas, orçamento, falhas, esquema e cobertura. Não chamar essas linhas de faixas diárias disjuntas.

Preservar **todas as métricas e dimensões analíticas retornadas pela consulta**, incluindo valores e precisão originais, contagens, usuários distintos, médias, taxas, denominadores fornecidos, indicadores de fricção e blocos vazios. Não limitar persistência aos campos usados pela tela desta versão. Não somar sessões por URL para obter total do projeto nem reponderar sem denominador comprovado; valores ausentes são indisponíveis, não zero. O adaptador registra alterações de esquema e conserva campos analíticos novos válidos, sinalizando que ainda não foram normalizados.

Guardar também a **resposta analítica completa sanitizada**, com parâmetros, versão do adaptador, versão da regra de saneamento, hash dessa representação e referência aos dados normalizados. Isso permite reprocessar e melhorar os relatórios sem consumir novamente a API ou perder métricas que a interface ainda não usa. Persistir a resposta antes de normalizar; uma falha de parser mantém a fonte sanitizada disponível para retomada. Uma nova interpretação cria versão derivada e conserva a anterior; a repetição da persistência da mesma coleta é idempotente.

Limpar query strings e fragmentos sensíveis de URLs antes da persistência; retirar segredos, cabeçalhos de autenticação e identificadores pessoais. Resolver conteúdo local pelo mesmo mecanismo editorial e manter URLs não resolvidas separadas. Variantes que normalizam para a mesma página não autorizam somar usuários/sessões distintos ou médias. Conservar categorias/dimensões analíticas com limites de tipo e tamanho e registrar a existência de campos removidos, sem copiar seu conteúdo sensível. “Máximo de informações” se aplica ao acervo analítico retornado, mantendo as restrições de consentimento, mascaramento e isolamento de segredos já definidas.

### Retenção e acesso ao acervo local

- Criar política própria `f3base_clarity.retencao_meses`, com `0` = **sem expiração automática**, padrão para o acervo agregado e suas respostas sanitizadas. Desvincular esse histórico da expiração de `f3base_medicao_editorial.retencao_meses`; reduzir retenção editorial não apaga Clarity.
- Permitir prazo explícito quando escolhido pelo operador; preservar valores já configurados, indicar efeito antes de aplicar uma redução e registrar a limpeza. Atualização, desativação ou troca de projeto não apagam o acervo silenciosamente. A política não se aplica ao IP da fila Meta, aos segredos ou a registros individuais de gravação.
- Usar armazenamento privado, compressão sem perda das respostas, índices e paginação; não carregar o acervo inteiro no painel nem em options com autoload. Dados normalizados para consulta e respostas para reprocessamento referenciam a mesma coleta. Não armazenar cópias redundantes do mesmo corpo para a mesma coleta.
- Mostrar tamanho, crescimento, número de consultas, primeira/última coleta e cobertura. Diante de falta de espaço, registrar falha explícita e lacuna; não apagar silenciosamente fotografias antigas para fingir continuidade. Arquivamento/exportação de agregados preserva metadados, hashes e capacidade de restauração.
- Ampliar `clarity-ler` com modos documentados `resumo`, `consultas` e `resposta`, acesso paginado e opção de ler a resposta sanitizada de uma coleta. Relatórios, CSV e consulta por agentes usam o mesmo dicionário e a mesma semântica temporal. Leitura/reprocessamento locais não gastam a cota externa.
- Conservar histórico das tentativas, orçamento conhecido, erros técnicos redigidos, recortes, qualidade e lacunas junto do acervo. Respostas HTTP de erro não devem ser arquivadas integralmente se contiverem tokens, dados pessoais ou conteúdo arbitrário.

Estados de qualidade: resposta disponível sem truncamento detectado, possivelmente truncada, esquema incompatível, inválida e falha. Mil linhas é sinal conservador de possível truncamento, não prova matemática de que há linhas omitidas; ausência desse sinal não certifica completude de todas as métricas. Não interpretar linha ausente como zero. Verificar o teto e a estrutura por bloco de métrica durante homologação.

Se atingir o teto, consultar um recorte mais simples dentro da cota: URL × Device → URL → total, e separadamente URL × Channel → URL → total. Trocar Device por Channel não reduz necessariamente a cardinalidade. Guardar cada recorte como consulta distinta; não substituir a cobertura por dispositivo/canal por uma cobertura total. Consulta de janela menor acrescenta informação recente, sem preencher a parte omitida da janela maior.

### Abilities e interface

| Entrada | Contrato |
| --- | --- |
| `f3base/clarity-ler` | Lê somente o histórico local por projeto, intervalo de consultas, página e dimensões efetivamente disponíveis. Retorna janelas, qualidade, sobreposição, falhas e limites de cobertura; nenhuma chamada externa. |
| `f3base/clarity-consultar` | Consulta ao vivo de 1/2/3 dias e dimensões válidas, descontando orçamento. Explicita consumo e devolve a consulta identificada, sem fingir atender datas arbitrárias. |
| `f3base/clarity-coletar` | Disparo autenticado do mesmo trabalho do cron, com trava/cota e resultado de execução. Grava histórico; não tem classificação de leitura. |
| `f3base/clarity-gravacoes` | Consulta sob demanda de links/metadados mínimos por filtro, até o limite homologado de 250; adaptador separado descrito abaixo. Não incorpora gravações ao banco do site. |

Adicionar visão `clarity` em Medição editorial, com consulta/janela selecionada e comparação de recortes compatíveis. Mostrar páginas, dispositivo/canal disponíveis e indicadores de fricção ao lado de seções, leads e origem IA do Core, com fonte e período próprios. Vinculação por conteúdo/período é contexto agregado, não prova de que determinada gravação corresponde a um lead ou de que um robô gerou aquela visita. Não unir usuários entre sistemas por inferência.

No filtro de um mês, listar consultas daquele mês e suas janelas; não somar fotografias sobrepostas para criar total mensal Clarity. Mesmo janelas aparentemente disjuntas não autorizam somar métricas distintas sem regra de aditividade. Resumos do Core continuam separados. Mostrar tanto falhas de coleta quanto trechos sem cobertura nominal; cobertura nominal não equivale a dados diários recuperáveis. Oferecer CSV/contrato para agentes com essa mesma semântica.

### Links de gravações: integração isolada

O repositório oficial do MCP Clarity oferece `list-session-recordings` [S13]. O anexo indica o endpoint `https://clarity.microsoft.com/mcp/recordings/sample`; ele não integra o contrato público da Data Export API consultado.

Incorporar `clarity-gravacoes` como adaptador de compatibilidade, somente sob demanda, com token no servidor, host fixo, filtros permitidos, limites de tamanho/tempo, contador próprio e estado explícito de indisponibilidade. Antes de codificar, conferir método, schema, autenticação e limite na versão identificada do MCP oficial; registrar commit/versão e teste de contrato. Não instalar Node ou outro MCP no WordPress. Não supor que sua cota é igual à da exportação nem ilimitada; aplicar orçamento local conservador e tratar a recusa remota. Uma mudança desse endpoint não pode interromper os formulários, o histórico ou a medição própria.

Retornar links apenas a operadores autorizados, validar host e não registrar URLs sensíveis em diagnóstico. A consulta não concede acesso externo à gravação, não baixa o vídeo e não oferece acesso anônimo pelo Core. Mostrar que se trata de amostra, sem contagem de sessões a partir da quantidade de links. Falta de contrato funcional bloqueia este subitem e deve aparecer como pendência concreta no relatório, nunca como funcionalidade homologada.

### Aceite definido após a decisão de 01/10

Testes do pacote: credencial ausente/inválida, troca de projeto, cota concorrente, 429, falha de HTTP/banco, resposta vazia, métrica ausente, teto de linhas e recortes alternativos. Provar que `clarity-ler` não usa a rede; consultas repetidas conservam suas janelas e não duplicam totais. Retenção, limpeza de URLs e permissões entram no mesmo conjunto. Demonstrar que todas as métricas/dimensões válidas de uma resposta são preservadas, inclusive as que a tela não mostra; reprocessar a cópia sanitizada sem HTTP; retomar falha de normalização; exportar/restaurar com integridade. Simular expiração editorial e passagem de tempo para provar que a política Clarity padrão não elimina o acervo. Demonstrar falha de espaço legível sem exclusão automática de histórico.

Homologação externa: três dias de coleta, interrupção superior a 24 h, consulta ampla depois da interrupção, com janelas e lacunas declaradas e sem reconstrução fictícia. Conferir valores de cada consulta contra sua resposta original e filtros efetivos; confrontar a interface Clarity somente quando períodos e recortes forem comparáveis. Registrar duração e horários das chamadas. Não chamar consultas móveis realizadas horas depois de “mesma janela” nem declarar atraso de processamento exato a partir delas. Testar gravações pelo adaptador e isolamento de sua falha. A conclusão dessas homologações depende da frota e das credenciais, não de acesso a produção nesta revisão.

## Execução, compatibilidade e documentação

1. Obter o contrato executável do canal 0.13.0 e incorporar o item 98; corrigir menu/renovação da prova e estabilizar classificação de rede/camada comum de relatórios.
2. Ampliar as dimensões e visões de IA/conteúdo, a assinatura reduzida e as comparações.
3. Implementar autoConfig, carregamento ocioso, GTM aditivo e Clarity, com testes de filas, consentimento, revogação e ausência de duplicação produzida pelo próprio Core. Criar a opção independente de destino CAPI e preservar emissões já configuradas.
4. Completar formulários e gestão de arquivos privados; implementar o contrato de ofertas e seus relatórios sobre a camada comum. Integrar ofertas ao dataLayer e às políticas dos destinos.
5. Implementar consultas, acervo completo sanitizado, retenção própria, reprocessamento e visão Clarity do item 101, incluído nesta versão; verificar o contrato do adaptador de gravações. Manter a análise própria com prazo inicial de 5 s.
6. Implementar o item 94 exclusivamente para Meta, com a retenção de IP aprovada e o bloqueio de ativação de servidor até homologação por site. Manter GA4, Google Ads e LinkedIn pelos transportes atuais, inclusive quando GTM estiver configurado.
7. Atualizar documentação instalada, schemas de abilities, dicionário de dados, exemplos, consultas para agentes, catálogo de eventos, estados de consentimento/testes e limitações de inferência. Documentar os novos campos no mesmo pacote; não depender de arquivos particulares da frota.
8. Validar e empacotar uma única release, com instalador, fontes, relatório de testes, manifesto e SHA-256. Não publicar versões intermediárias para completar esse escopo.

Os caminhos de instalação previstos são site novo e atualização da 1.18.0 com migração concluída. Não se projetam migração de versões anteriores nem downgrade. A 1.19.0 terá marcador próprio de conclusão e retomada idempotente dentro da mesma versão, versão de regra e indicação de cobertura histórica. Atualização acrescenta apenas campos ausentes, com procedência registrada, e não sobrescreve preferências, listas vazias, valores `false`, `f3base_operaveis=todas`, navegação, anotações, consentimento, modo de teste, leads ou eventos.

Documentar explicitamente as ampliações de coleta pedidas: ofertas, assinatura reduzida, GTM, Clarity e transporte Meta. Não acrescentar scripts, beacons, cookies ou dados pessoais fora dessas finalidades. A retenção temporária de IP do item 94 foi ampliada pelo dono em 01/10/2026 e segue os limites da seção Meta. O histórico Clarity passa a ter retenção própria sem expiração automática por padrão. Sem IDs novos, a atualização não ativa Clarity nem GTM; a configuração existente é preservada.

### Entrega e operação da frota

- Instalador `base-site-core-fator3-1.19.0.zip`, com destino de publicação previsto `https://github.com/Fator3Ventures/claude-wordpress/raw/main/base-site-core-fator3-1.19.0.zip`. Relatório, manifesto e arquivo publicado devem indicar o mesmo SHA-256. O endereço previsto não é declaração de publicação realizada.
- Tabela de rastreabilidade para R119-01 e cada número do pedido: comportamento entregue → arquivo/linha na versão nova → teste/evidência. Separar teste local de homologação externa; item não atendido tem motivo e restante explícitos.
- Relacionar delta por site: requisitos de cache em `wp-cache-config.php`, bloco `F3BASE MANAGED`, options gravadas pela migração e tabelas/índices novos. Registrar “sem alteração” quando aplicável; não alterar infraestrutura para facilitar a implementação.
- Registrar mudanças de comportamento e de definição de métricas em `mudancas` de `f3base/como-usar`, com `desde_versao`, para datar quebras de série. Incluir GTM aditivo, classificação de IA e semântica das consultas Clarity.
- Atualizar `docs/OPERACAO-E-RECUPERACAO.md` com retomada de migração, filas, segredos, retenção, perda de coletas durante interrupção e recuperação por backup. Recuperação não promete downgrade compatível.
- Documentação instalada deve conter catálogo e exemplos de leitura, permissões MCP, nomes/tipos/índices das tabelas, fuso, período, qualidade/cobertura, chaves de ligação e cruzamentos que não são possíveis. Incluir limites da API Clarity e orientação de deduplicação para o fornecedor GTM.

As decisões de produto desta revisão estão fechadas: histórico Clarity nesta versão, preservação máxima de informação analítica local e retenção do IP superior a 24 h quando útil à entrega, com o teto operacional e a limpeza definidos acima. A limitação de decomposição diária permanece explicitada no contrato. Contrato executável do MCP, IDs/tokens dos projetos, confirmação das janelas Meta e homologação externa são dependências de implementação/operação, não novas aprovações de escopo nem consentimentos presumidos para acessar sites ou contas nesta revisão. Manter a entrega única; não adiar o histórico por conta própria.

## Validação consolidada

| Frente | Evidência exigida |
| --- | --- |
| Atualização/configuração | Site novo e 1.18.0; retomada; valores falsos/vazios preservados; defaults novos sem ativação de fornecedor. |
| Navegação | Clique real no menu, permissões, subdiretório; cron sem usuário, invalidação, concorrência e atraso visível. |
| Relatórios | Tela/CSV/abilities com números iguais sob filtros iguais; cobertura, histórico sem análise, anotações e ausência de automação no resumo padrão. |
| IA | Rede compatível/incompatível/expirada; HTML/Markdown; descoberta; HEAD/304/403/429; comparação semanal e horários no fuso. |
| Carregamento | Matriz de consentimento e teste; ocioso/imediato/interação; prazos próprios; uma inclusão; benchmarks repetidos. |
| Formulários | JS e sem JS; três regimes; confirmação; placeholders; mensagens; limites; antispam; acessibilidade; regressão do resumo de avisos por e-mail e do 410. |
| Conteúdo privado | Cadastro/lista/substituição; hash esperado; mesma concessão válida após substituição; concorrência e falhas sem exposição pública. |
| Ofertas | Visibilidade, eventos inválidos/repetidos, instância, funil, consentimento/testes, frequência e separação de responsabilidade do tema. |
| Meta pelo servidor | Deduplicação Pixel/CAPI, segredo ausente, revogação; fila útil além de 24 h, teto de sete dias ou prazo externo menor, sem renovação; limpeza imediata em desfecho; repetição segura e expiração. GA4 recusa `ambos` e `servidor`. |
| MCP 0.13 | Provedor/contrato em todo o catálogo; leitura permitida e escrita recusada no perfil Leitura; Update URI coordenado; Core ativo sem MCP. |
| GTM aditivo | Contêiner vazio sem perda/duplicação direta; consentimento antes do carregador; Meta via GTM com destino CAPI independente; diagnósticos de IDs coincidentes. |
| Clarity no navegador | Slot vazio inerte; consentv2 antes da coleta; revogação/parada; testes; máscara no dado exibido; ausência de tokens privados; custo medido. |
| Histórico Clarity | Respostas analíticas sanitizadas completas, normalização versionada e reprocessamento sem rede; consultas móveis preservadas, sem soma/diferença indevida; cota/qualidade; retenção própria sem expiração padrão; integridade de exportação/restauração; gravações com falha isolada. |
| Análise própria | Primeiro envio mantém 5 s; descarregamento Meta na saída curta sem antecipar toda a análise; nenhuma nova duplicação. |

O desenvolvimento usa laboratório. Homologações citadas para fator3, ctooffice e korvena.com.br permanecem roteiro da frota após a entrega, com autorização e contas adequadas. A ordem informada pela frota é Site-Teste → piloto korvena.net.br → demais, com fator3.com.br e korvena.com.br por último. Isso não altera a instrução do dono: os testes em korvena.net.br serão feitos por ele, não pelo agente desta tarefa. Pipedrive já entregue mantém sua homologação externa pendente; este plano não a declara concluída nem reabre a integração sem defeito novo demonstrado. Nenhum site foi acessado ou modificado nesta revisão.

## Fontes e rastreabilidade

- Documento recebido: “Pendências do site-core após a 1.18.0.md”, 30/09/2026.
- Novo documento recebido em 01/10/2026: “Pendências do site-core após a 1.18.0(1).md”, conteúdo datado de 30/09, com itens 98–101 e restrições de entrega adicionais.
- Documento oficial recebido e lido integralmente em 01/10/2026: “Pedidos ao pacote core.md”, com quinze pendências numeradas, itens operacionais já entregues e decisões de não fazer. SHA-256 da cópia: `5a53cd971a13ebc950e729002149007d9b095b570e767b23b38416033d472bf4`.
- Decisão direta do dono em 01/10/2026, 08:00 BRT: não adiar o histórico; manter o máximo de informações possível localmente; permitir retenção de IP por mais de 24 h quando necessário. Substitui a pendência de aceite do 101 e o teto anterior de IP.
- “Pendências do canal wp-mcp-fator3 após a 0.13.0.md”, item 25, confirma a dependência do contrato do provedor. “plano-wp-mcp-fator3-0.13.0-release-unica.md”, revisão 7, descreve planejamento anterior; não é evidência de homologação do canal instalado.
- Pacote lido: `fontes-core-f3base-1.18.0.zip`. Arquivos centrais: `class-f3base-navegacao.php`, `class-f3base-release-configuracao.php`, `class-f3base-evolucao.php`, `f3base-tracking.js`, `class-f3base-relatorios.php`, `class-f3base-editorial-relatorios.php`, `class-f3base-agentes.php`, `class-f3base-modulo-acessos-servidor.php`, `class-f3base-formularios.php`, `class-f3base-leads-admin.php`, `class-f3base-leads-notificacoes.php`, `class-f3base-arquivos-privados.php`, `class-f3base-conteudo-privado.php`, `class-f3base-modulo-meta-capi.php` e `class-f3base-capi-fila.php`.
- [S1 — Google: finalidade do Measurement Protocol](https://developers.google.com/analytics/devguides/collection/protocol/ga4).
- [S2 — Google: transporte e parâmetros do Measurement Protocol](https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference).
- [S3 — Google Ads: alterações e restrições das APIs](https://developers.google.com/google-ads/api/docs/deprecations).
- [S4 — LinkedIn: deduplicação](https://learn.microsoft.com/en-us/linkedin/marketing/conversions/deduplication?view=li-lms-2026-09).
- [S5 — LinkedIn: públicos e outros usos da Conversions API](https://learn.microsoft.com/en-us/linkedin/marketing/conversions/conversions-usecase?view=li-lms-2026-08).
- [S6 — LinkedIn: públicos de visitantes do site](https://learn.microsoft.com/en-us/linkedin/marketing/matched-audiences/website-visitors-retargeting?view=li-lms-2026-05).
- [S7 — Google: dataLayer e eventos](https://developers.google.com/tag-platform/tag-manager/datalayer).
- [S8 — Microsoft Clarity: Consent API V2](https://learn.microsoft.com/en-us/clarity/setup-and-installation/clarity-consent-api-v2).
- [S9 — Microsoft Clarity: mascaramento](https://learn.microsoft.com/en-us/clarity/setup-and-installation/clarity-masking).
- [S10 — Microsoft Clarity: API cliente](https://learn.microsoft.com/en-us/clarity/setup-and-installation/clarity-api).
- [S11 — Microsoft Clarity: Data Export API](https://learn.microsoft.com/en-us/clarity/setup-and-installation/clarity-data-export-api).
- [S12 — Microsoft Clarity: tipos oficiais, incluindo stop e consentv2](https://github.com/microsoft/clarity/blob/master/packages/clarity-js/types/index.d.ts).
- [S13 — Microsoft Clarity: MCP oficial e ferramenta de gravações](https://github.com/microsoft/clarity-mcp-server).

Fontes S1–S6 consultadas em 30/09/2026 e S7–S13 em 01/10/2026. A disponibilidade real de permissões/recursos de cada conta, as respostas da Meta e a tag/API Clarity precisam de homologação; esta análise não verificou contas de anúncios ou projetos Clarity. O anexo recebido foi preservado; esta revisão atualiza somente o plano consolidado.
