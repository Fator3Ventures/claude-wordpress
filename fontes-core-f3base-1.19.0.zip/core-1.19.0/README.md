# Fontes — F3 Base Core 1.19.0

Plugin instalável em fontes/plugin. Plano aprovado em PLANO-APROVADO.md. Suíte desta entrega em suite/versao-1190; somente as evidências listadas em VALIDACAO.md representam esta entrega. Guias instalados em fontes/plugin/docs. Build determinístico: python3 montar-release.py --saida DIRETORIO. Dependências de minificação fixadas em suite/build-assets; node suite/build-assets/build.cjs fontes/plugin.

Referência para a bancada: instalador original 1.18.0 em referencias/. Runtime, WordPress, banco, dependências instaladas e credenciais não integram o pacote.

Dois caminhos: instalação nova ou 1.18.0 concluída. Sem downgrade, alteração do tema/implantador ou acesso à frota.
