import subprocess,os
from pathlib import Path
root=Path(__file__).parent
for f in ['mcp-preparar.php','mcp.php']:
 subprocess.run([os.environ['F3BASE_TEST_WORKSPACE']+'/runtime1150/php',str(root/f)],check=True)
