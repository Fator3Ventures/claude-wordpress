<?php
require __DIR__.'/bootstrap.php';
$ids=[];$project='lab119ui';$saved=get_option('f3base_clarity_project_id',null);F3Base_Options::gravar('f3base_clarity_project_id',$project);global $wpdb;
foreach([time()-2*DAY_IN_SECONDS,time()-DAY_IN_SECONDS] as $t){$id=bin2hex(random_bytes(16));$ids[]=$id;$wpdb->insert(F3Base_Clarity_Acervo::tabela(),['id'=>$id,'projeto'=>$project,'chave'=>hash('sha256',$id),'parametros'=>wp_json_encode(['dias'=>1,'dimensoes'=>['URL','Device']]),'origem'=>'manual','solicitado_em'=>$t,'janela_dias'=>1,'inicio_nominal'=>$t-DAY_IN_SECONDS,'fim_nominal'=>$t,'estado'=>'solicitando','cobertura'=>'{}']);F3Base_Clarity_Acervo::receber($id,[['metricName'=>'Traffic','information'=>[['URL'=>home_url('/'),'Device'=>'PC','totalSessionCount'=>'120','distinctUserCount'=>'100']]]],200,$t,37);}
update_option('f3base_suite119_ui',['ids'=>$ids,'project'=>$saved]);file_put_contents(__DIR__.'/evidencias/ui-fixture.json',wp_json_encode(['ids'=>$ids]));echo 'prepared';
