<?php
require __DIR__.'/bootstrap.php';
$checks=[];$details=[];
function ck($k,$v,$d=null){global $checks,$details;$checks[$k]=(bool)$v;if(!$v){$details[$k]=$d;}}
$ids=[];$bytes="%PDF-1.4\n% synthetic lab\n1 0 obj\n<< /Type /Catalog >>\nendobj\n%%EOF\n";
$e=['nome'=>'laboratorio.pdf','base64'=>base64_encode($bytes),'sha256'=>hash('sha256',$bytes),'idempotency_key'=>'suite119-'.wp_generate_uuid4()];
global $wpdb;
try{
ck('schema',F3Base_Leads_Repositorio::instalar());
$r=F3Base_Arquivos_Servico::cadastrar($e);ck('cadastrar',!empty($r['ok']),$r);$id=$r['arquivo']['id']??'';$ids[]=$id;
ck('privado',strlen($id)===32&&is_file(F3Base_Arquivos_Privados::caminho($id)));
ck('sem_caminho',!isset($r['arquivo']['blob_id'])&&!isset($r['arquivo']['path']));
ck('duplicado',(F3Base_Arquivos_Servico::cadastrar($e)['duplicado']??false));
$bad=$e;$bad['nome']='outro.pdf';ck('idempotencia_divergente',(F3Base_Arquivos_Servico::cadastrar($bad)['codigo']??'')==='idempotencia_divergente');
$bad=$e;$bad['idempotency_key']=wp_generate_uuid4();$bad['sha256']=str_repeat('0',64);ck('hash_recusado',(F3Base_Arquivos_Servico::cadastrar($bad)['codigo']??'')==='copia_ou_sha256_divergente');
ck('mime_alerta',F3Base_Arquivos_Privados::alerta_mime('falso.pdf','text/plain')==='extensao_mime_divergentes');
ck('extensao_livre',F3Base_Arquivos_Privados::alerta_mime('livre.xyz','text/plain')==='');
$old=F3Base_Arquivos_Privados::obter($id);$g=[];
foreach(['vigente','vencida','revogada','esgotada'] as $tipo){$gid=bin2hex(random_bytes(16));$g[$tipo]=$gid;$wpdb->insert(F3Base_Leads_Repositorio::tabela('concessoes'),['id'=>$gid,'lead_record_id'=>str_repeat('a',32),'ativo'=>$id,'versao'=>$old['sha256'],'expira'=>$tipo==='vencida'?time()-100:time()+3600,'quota'=>5,'usados'=>$tipo==='esgotada'?5:2,'revogada'=>$tipo==='revogada'?1:0]);}
$new=$bytes."% new version\n";$e2=['id'=>$id,'nome'=>'nova.pdf','base64'=>base64_encode($new),'sha256'=>hash('sha256',$new),'expected_sha256'=>$old['sha256'],'idempotency_key'=>wp_generate_uuid4()];
$r2=F3Base_Arquivos_Servico::substituir($e2);ck('substituir',!empty($r2['ok']),$r2);
$atual=F3Base_Arquivos_Privados::obter($id);ck('id_estavel',$atual['id']===$id);ck('novo_blob',$atual['blob_id']!==$old['blob_id']);ck('novo_hash',hash_file('sha256',F3Base_Arquivos_Privados::caminho($id))===$e2['sha256']);
ck('snapshot_anterior_integro',file_get_contents(F3Base_Arquivos_Privados::raiz().'/'.($old['blob_id']?:$id))===$bytes);
foreach($g as $tipo=>$gid){$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s',F3Base_Leads_Repositorio::tabela('concessoes'),$gid),ARRAY_A);ck('versao_'.$tipo,$row['versao']===($tipo==='vigente'?$e2['sha256']:$old['sha256']));ck('quota_'.$tipo,(int)$row['usados']===($tipo==='esgotada'?5:2)&&(int)$row['quota']===5);}
$again=$e2;$again['idempotency_key']=wp_generate_uuid4();ck('cas_recusa',(F3Base_Arquivos_Servico::substituir($again)['codigo']??'')==='revisao_divergente');
ck('retry_substituicao',(F3Base_Arquivos_Servico::substituir($e2)['duplicado']??false));
$lista=F3Base_Arquivos_Servico::listar(['id'=>$id]);ck('lista_paginada',count($lista['arquivos'])===1&&!isset($lista['arquivos'][0]['blob_id']));
wp_set_current_user(0);ck('cadastro_protegido',(F3Base_Arquivos_Servico::cadastrar($e)['codigo']??'')==='sem_permissao');ck('leitura_protegida',(F3Base_Arquivos_Servico::listar()['codigo']??'')==='sem_permissao');wp_set_current_user(1);
ck('upload_http_nao_afrouxado',(F3Base_Arquivos_Privados::receber(['error'=>0,'tmp_name'=>__FILE__,'name'=>'teste.php'])['codigo']??'')==='upload_nao_autentico');
}finally{wp_set_current_user(1);foreach($ids as $id){if(!$id){continue;}$wpdb->delete(F3Base_Leads_Repositorio::tabela('concessoes'),['ativo'=>$id]);$bs=$wpdb->get_col($wpdb->prepare('SELECT blob_id FROM %i WHERE ativo=%s',F3Base_Leads_Repositorio::tabela('arquivos_blobs'),$id));foreach($bs as $blob_id){@unlink(F3Base_Arquivos_Privados::raiz().'/'.$blob_id);}$wpdb->delete(F3Base_Leads_Repositorio::tabela('arquivos_blobs'),['ativo'=>$id]);$wpdb->delete(F3Base_Leads_Repositorio::tabela('arquivos_leads'),['id'=>$id]);}}
$out=['checks'=>$checks,'falhas'=>array_keys(array_filter($checks,fn($x)=>!$x)),'detalhes'=>$details];file_put_contents(__DIR__.'/evidencias/arquivos.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode(['total'=>count($checks),'falhas'=>$out['falhas'],'detalhes'=>$details]);exit($out['falhas']?1:0);
