<?php
require __DIR__.'/bootstrap.php';
$checks=array();$details=array();$saved=array();
function ck($key,$ok,$detail=null){global $checks,$details;$checks[$key]=(bool)$ok;if(!$ok){$details[$key]=$detail;}}
function pref($key,$v){global $saved;if(!array_key_exists($key,$saved)){$saved[$key]=get_option($key,null);}return F3Base_Options::gravar($key,$v);}
try {
    ck('versao',F3BASE_PLUGIN_VERSAO==='1.19.0');
    ck('update_uri',str_contains(file_get_contents(F3BASE_PLUGIN_ARQUIVO),'Update URI:        https://fator3.com.br/plugins/base-site-core-fator3'));
    ck('instalacao_concluida',F3Base_Instalacao::origem()==='atual');
    ck('proximas_origens',str_contains(file_get_contents(F3BASE_PLUGIN_DIR.'includes/class-f3base-instalacao.php'),"return '1.18.0'"));
    foreach(array('f3base_gtm_container_id'=>'GTM-LAB119','f3base_ga4_measurement_id'=>'G-LAB1190','f3base_meta_pixel_id'=>'123456789012345','f3base_clarity_project_id'=>'lab119','f3base_meta_auto_config'=>false) as $k=>$v){$r=pref($k,$v);ck('gravar_'.$k,!empty($r['persisted']),$r);}
    $d=F3Base_Modulo_Tracking::dados_de_medicao();ck('gtm_aditivo',$d['gtm']==='GTM-LAB119'&&$d['ga4']==='G-LAB1190'&&$d['meta']['pixelId']==='123456789012345'&&$d['caminho']==='misto',$d);
    ck('meta_autoconfig_falso',$d['meta']['autoConfig']===false);ck('clarity_publico',$d['clarity']['projectId']==='lab119'&&!isset($d['clarity']['token']));
    ck('modo_ocioso',!empty(pref('f3base_google_carregamento',array('modo'=>'ocioso','teto_segundos'=>2))['persisted']));
    $c=F3Base_Options::ler('f3base_carregamento_destinos');$c['meta']='ocioso';$c['meta_teto_segundos']=1;
    ck('prazo_por_destino',!empty(pref('f3base_carregamento_destinos',$c)['persisted']));$c['meta_teto_segundos']=31;ck('prazo_invalido',empty(F3Base_Options::gravar('f3base_carregamento_destinos',$c)['persisted']));
    ck('lista_vazia_preservada',F3Base_Release_1190::completar(array('x'=>array(),'n'=>false),array('x'=>array('abc'),'n'=>true))===array('x'=>array(),'n'=>false));
    ck('clarity_teste_suprimido',F3Base_Testes::politica('clarity','teste')==='suprimir');
    $matches=F3Base_Tracking_Diagnostico::inspecionar('var ga="G-LAB1190"; var ads="AW-123456";',F3Base_Modulo_Tracking::ids());ck('gtm_literal_diagnosticado',count($matches)===1&&$matches[0]['slot']==='f3base_ga4_measurement_id',$matches);
    require_once ABSPATH.'wp-admin/includes/plugin.php';global $menu,$submenu,$admin_page_hooks;do_action('admin_menu');
    ck('submenu_hook_correto',get_plugin_page_hookname('f3base-relatorios','f3base-leads')==='contatos_page_f3base-relatorios',get_plugin_page_hookname('f3base-relatorios','f3base-leads'));
    ck('primeiro_submenu_contatos',($submenu['f3base-leads'][0][2]??'')==='f3base-leads',$submenu['f3base-leads']??array());
    $saved['f3base_nav_prova']=get_option('f3base_nav_prova',null);
    $http=static function($r,$args,$url){return str_contains($url,'f3base_nav_sonda')?array('headers'=>array(),'response'=>array('code'=>200),'body'=>'<html><header><nav data-f3base-nav-ref="0" data-f3base-nav-tipo="bloco">Menu</nav></header></html>'):$r;};
    add_filter('pre_http_request',$http,999,3);wp_set_current_user(0);ck('manual_anonimo_recusado',(F3Base_Navegacao::verificar_publica()['codigo']??'')==='sem_permissao');
    do_action(F3Base_Navegacao::EVENTO);$p=F3Base_Options::ler('f3base_nav_prova');ck('cron_sem_usuario',$p['estado']==='observada'&&$p['motivo']==='cron'&&$p['ultimo_sucesso_em']>time()-30,$p);
    ck('prova_vigente',F3Base_Navegacao::diagnostico()['prova_vigente']);wp_set_current_user(1);remove_filter('pre_http_request',$http,999);
    $a=F3Base_Trava::adquirir('suite119',20);$b=F3Base_Trava::adquirir('suite119',20);ck('trava_exclusiva',$a&&!$b);if($a){F3Base_Trava::liberar($a);}$b=F3Base_Trava::adquirir('suite119',20);ck('trava_liberada',(bool)$b);if($b){F3Base_Trava::liberar($b);}
    $abilities=wp_get_abilities();$core=array_filter($abilities,static fn($ability)=>str_starts_with($ability->get_name(),'f3base/'));
    ck('abilities_presentes',count($core)>50,count($core));foreach($core as $ability){$m=$ability->get_meta()['fator3']??array();ck('mcp_'.$ability->get_name(),($m['provider']??'')==='base-site-core-fator3'&&($m['version']??'')==='1.19.0'&&($m['policy_contract']??0)===1,$m);}
} finally {wp_set_current_user(1);foreach($saved as $key=>$v){if($v===null){delete_option($key);}else{update_option($key,$v);}}}
$out=array('checks'=>$checks,'falhas'=>array_keys(array_filter($checks,static fn($x)=>!$x)),'detalhes'=>$details);
if(!is_dir(__DIR__.'/evidencias')){mkdir(__DIR__.'/evidencias');}file_put_contents(__DIR__.'/evidencias/fundacao.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode(array('total'=>count($checks),'falhas'=>$out['falhas'],'detalhes'=>$details));exit($out['falhas']?1:0);
