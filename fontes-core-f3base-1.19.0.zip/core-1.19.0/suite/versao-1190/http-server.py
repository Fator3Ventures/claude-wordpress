"""Isolated, multi-worker PHP HTTP fixture; run inside lab.py."""
from pathlib import Path
import os,sys,subprocess,time,urllib.request,signal
ROOT=Path(os.environ['F3BASE_TEST_WORKSPACE']);site=Path(os.environ['F3BASE_SITE']);log_path=ROOT/'lab1150/php-http.log'
env=os.environ.copy();env['PHP_CLI_SERVER_WORKERS']='8';env['F3BASE_LAB_HTTP']='1'
log=log_path.open('w');cmd=[str(ROOT/'runtime1150/php'),'-d','display_errors=Off','-S','127.0.0.1:8150','-t',str(site),str(Path(__file__).with_name('router.php'))]
proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=log,start_new_session=True)
try:
 for _ in range(80):
  if proc.poll() is not None:raise RuntimeError(log_path.read_text()[-2000:])
  try:
   with urllib.request.urlopen('http://127.0.0.1:8150/wp-login.php',timeout=1) as r:
    if r.status==200:break
  except Exception:time.sleep(.1)
 else:raise RuntimeError('PHP HTTP fixture unavailable: '+log_path.read_text()[-2000:])
 run=[str(ROOT/'runtime1150/php') if x=='php' else x for x in sys.argv[1:]]
 result=subprocess.run(run,env=env);sys.exit(result.returncode)
finally:
 os.killpg(proc.pid,signal.SIGTERM)
 try:proc.wait(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 log.close()
