'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright-core');
const root=process.env.F3BASE_TEST_WORKSPACE,source=path.resolve(__dirname,'../../fontes/plugin/assets');
const checks={},cases=[],pages=new Map();let browser;
const server=http.createServer((q,r)=>{const u=new URL(q.url,'http://127.0.0.1');r.setHeader('Content-Type','text/html; charset=utf-8');r.end(pages.get(u.pathname)||'<!doctype html><title>Bancada</title>');});
const base={caminho:'misto',gtm:'GTM-LAB119',ga4:'G-LAB1190',ads:{id:'AW-123456789',label:'lab'},meta:{pixelId:'123456789012345',autoConfig:false,origem:'https://connect.facebook.net/en_US/fbevents.js'},linkedin:{partnerId:'123456',conversionId:'987654',origem:'https://snap.licdn.com/li.lms-analytics/insight.min.js'},clarity:{projectId:'lab119'},origemGoogle:'https://www.googletagmanager.com/',googleCarregamento:{modo:'imediato',teto_segundos:1},resumo:{ativo:false},comportamento:{}};
function ck(k,v){checks[k]=!!v;if(!v)console.error('FAIL',k);}
function html(cfg,opt={}){
 return '<!doctype html><html><head><meta charset="UTF-8"></head><body><h1>Conteúdo público</h1>'+ (opt.block?' <img src="/bloqueio.png" alt="">':'')+'<script>'+`
 window.__consent={medicao:${opt.medicao!==false},publicidade:${opt.publicidade!==false}};window.__teste=${!!opt.teste};
 window.dataLayer=[];window.gtag=function(){dataLayer.push(arguments)};gtag('consent','default',{analytics_storage:'denied',ad_storage:'denied'});
 window.f3baseConsentimento={permiteCategoria:function(c){return __consent[c]},permiteTags:function(){return __consent.medicao},permiteGtm:function(){return __consent.medicao&&__consent.publicidade}};
 window.f3baseContexto={teste:function(){return __teste},politica:function(d,t){return (typeof t==='boolean'?t:__teste)?'suprimir':'normal'},configTestes:{ga4_ids:[]}};
 window.f3baseContextoDados={carregamento:${JSON.stringify(opt.carga||{ativo:true,meta:'herdar',linkedin:'herdar',clarity:'herdar'})}};
 window.f3baseTrackingDados=${JSON.stringify(cfg)};window.f3baseLeadsDados={medicao:f3baseTrackingDados};
 ${opt.noIdle?'window.requestIdleCallback=undefined;window.cancelIdleCallback=undefined;':''}
 </script><script>`+fs.readFileSync(path.join(source,'f3base-tracking.js'),'utf8')+'</script><script>'+fs.readFileSync(path.join(source,'f3base-leads.js'),'utf8')+'</script></body></html>';
}
async function scenario(name,cfg,opt={}){
 const p=await browser.newPage(),requests=[],errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.route('https://**/*',async route=>{const u=route.request().url();requests.push({url:u,at:Date.now()});let body='';
  if(u.includes('clarity.ms/tag/'))body='window.__clarityCalls=Array.from(window.clarity.q||[],x=>Array.from(x));window.clarity=function(){__clarityCalls.push(Array.from(arguments))};';
  if(u.includes('licdn.com/'))body='window.lintrk=function(){(window.__linkedinCalls=window.__linkedinCalls||[]).push(Array.from(arguments))}';
  await route.fulfill({status:200,contentType:'application/javascript',body});});
 let release; if(opt.block){await p.route('**/bloqueio.png',async route=>{await new Promise(r=>release=r);await route.fulfill({status:200,contentType:'image/png',body:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aFZkAAAAASUVORK5CYII=','base64')});});}
 pages.set('/'+name,html(cfg,opt));await p.goto('http://127.0.0.1:8159/'+name,{waitUntil:opt.block?'domcontentloaded':'load'});
 return {p,requests,errors,release:()=>release&&release(),finish:async()=>{ck(name+'_sem_erro',!errors.length);cases.push({name,requests,errors});await p.close();}};
}
(async()=>{
 await new Promise(r=>server.listen(8159,'127.0.0.1',r));browser=await chromium.launch({executablePath:path.join(root,'runtime1150/headless/chrome-headless-shell-linux64/chrome-headless-shell'),args:['--no-sandbox']});
 let s=await scenario('sem_slots',{...base,caminho:'nenhum',gtm:'',ga4:'',ads:{},meta:{},linkedin:{},clarity:{}});await s.p.waitForTimeout(100);ck('sem_slots_inerte',s.requests.length===0);ck('sem_gtm_objetos',await s.p.evaluate(()=>dataLayer.every(x=>!x.event)));await s.finish();
 s=await scenario('aditivo',base);await s.p.waitForFunction(()=>window.__clarityCalls&&window.lintrk);await s.p.evaluate(()=>document.dispatchEvent(new CustomEvent('f3base-formulario-aceito',{detail:{formulario:'contato',method:'formulario',correlacao:'a'.repeat(32),duplicado:false,contexto_teste:false}})));
 let v=await s.p.evaluate(()=>({layer:dataLayer.map(x=>x.event?x:Array.from(x)),meta:Array.from(fbq.queue,x=>Array.from(x)),clarity:__clarityCalls}));
 ck('gtm_e_quatro_diretos',s.requests.length===5);ck('consentimento_primeiro',v.layer[0][0]==='consent'&&v.layer[0][1]==='default');
 ck('gtm_start_unico',v.layer.filter(x=>x.event==='gtm.js').length===1);ck('ga4_config_unico',v.layer.filter(x=>x[0]==='config'&&x[1]===base.ga4).length===1);
 ck('gerar_lead_objeto_unico',v.layer.filter(x=>x.event==='generate_lead').length===1);ck('gerar_lead_ga4_unico',v.layer.filter(x=>x[0]==='event'&&x[1]==='generate_lead'&&x[2].send_to===base.ga4).length===1);
 ck('id_canonico_gtm',v.layer.find(x=>x.event==='generate_lead').event_id==='a'.repeat(32));ck('meta_auto_config_antes_init',v.meta.findIndex(x=>x[0]==='set'&&x[1]==='autoConfig'&&x[2]===false)<v.meta.findIndex(x=>x[0]==='init'));
 ck('meta_pageview_unica',v.meta.filter(x=>x[0]==='track'&&x[1]==='PageView').length===1);ck('meta_lead_unico',v.meta.filter(x=>x[0]==='track'&&x[1]==='Lead'&&x[3].eventID==='a'.repeat(32)).length===1);
 ck('clarity_consentimento_antes_tags',v.clarity[0][0]==='consentv2'&&v.clarity[0][1].analytics_Storage==='granted');ck('clarity_sem_identidade',v.clarity.every(x=>x[0]!=='identify'));ck('clarity_lead_tags',v.clarity.some(x=>x[0]==='set'&&x[1]==='form_id'&&x[2]==='contato'));
 await s.p.evaluate(()=>{for(let i=0;i<4;i++){window.dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}));f3baseTracking.carregar();}});ck('bfcache_nao_duplica',s.requests.length===5);await s.finish();
 s=await scenario('negado',base,{medicao:false,publicidade:false});await s.p.waitForTimeout(120);ck('negado_sem_sdk',s.requests.length===0);await s.finish();
 s=await scenario('teste',base,{teste:true});await s.p.waitForTimeout(120);ck('teste_sem_sdk',s.requests.length===0);await s.finish();
 s=await scenario('somente_medicao',base,{publicidade:false});await s.p.waitForFunction(()=>window.__clarityCalls);ck('sem_publicidade_somente_ga4_clarity',s.requests.length===2);v=await s.p.evaluate(()=>__clarityCalls);ck('clarity_ads_negado',v[0][1].ad_Storage==='denied'&&v[0][1].analytics_Storage==='granted');
 await s.p.evaluate(()=>{__consent.medicao=false;document.dispatchEvent(new Event('f3base-consentimento'));});v=await s.p.evaluate(()=>__clarityCalls);ck('clarity_revogacao_stop',v.at(-1)[0]==='stop'&&v.at(-2)[0]==='consentv2'&&v.at(-2)[1].analytics_Storage==='denied');
 await s.p.evaluate(()=>{__consent.medicao=true;document.dispatchEvent(new Event('f3base-consentimento'));f3baseClarityConversao('contato','formulario');});ck('clarity_nao_retoma_sessao_parada',(await s.p.evaluate(()=>__clarityCalls)).length===v.length);await s.finish();
 s=await scenario('meta_servidor',{...base,gtm:'',meta:{...base.meta,modo:'servidor'}});await s.p.waitForFunction(()=>window.__clarityCalls);await s.p.evaluate(()=>document.dispatchEvent(new CustomEvent('f3base-formulario-aceito',{detail:{formulario:'contato',method:'formulario',correlacao:'e'.repeat(32),contexto_teste:false}})));ck('servidor_sem_fbevents',s.requests.every(x=>!x.url.includes('facebook')));ck('servidor_ga4_mantido',await s.p.evaluate(()=>dataLayer.some(x=>x[0]==='event'&&x[1]==='generate_lead')));await s.finish();
 const idle={...base,gtm:'',googleCarregamento:{modo:'ocioso',teto_segundos:1}};
 s=await scenario('ocioso_apos_load',idle,{block:true});await s.p.waitForTimeout(120);ck('ocioso_nada_antes_load',s.requests.length===0);s.release();await s.p.waitForLoadState('load');await s.p.waitForFunction(()=>window.__clarityCalls);ck('ocioso_carrega_depois_load',s.requests.length===4);await s.finish();
 s=await scenario('ocioso_fallback',idle,{noIdle:true});ck('fallback_ainda_aguarda',s.requests.length===0);await s.p.waitForTimeout(1200);ck('fallback_prazo_sem_ric',s.requests.length===4);await s.finish();
 s=await scenario('ocioso_revogado',idle,{noIdle:true});await s.p.evaluate(()=>{__consent.medicao=false;__consent.publicidade=false;document.dispatchEvent(new Event('f3base-consentimento'));});await s.p.waitForTimeout(1200);ck('revogacao_cancela_timers',s.requests.length===0);await s.finish();
 s=await scenario('prazos_independentes',{...idle,googleCarregamento:{modo:'ocioso',teto_segundos:3}},{carga:{ativo:true,meta:'ocioso',meta_teto_segundos:1,linkedin:'herdar',clarity:'herdar'},noIdle:true});await s.p.waitForTimeout(1200);ck('prazo_meta_independente',s.requests.length===1&&s.requests[0].url.includes('facebook'));await s.p.waitForTimeout(2100);ck('herdar_respeita_prazo_google',s.requests.length===4);await s.finish();
 fs.mkdirSync(path.join(__dirname,'evidencias'),{recursive:true});const out={browser:browser.version(),checks,cases};fs.writeFileSync(path.join(__dirname,'evidencias/carregadores.json'),JSON.stringify(out,null,2));console.log(JSON.stringify({total:Object.keys(checks).length,falhas:Object.keys(checks).filter(k=>!checks[k])}));if(Object.values(checks).some(v=>!v))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{if(browser)await browser.close();server.closeAllConnections();server.close();});
