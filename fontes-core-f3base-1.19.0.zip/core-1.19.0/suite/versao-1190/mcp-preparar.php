<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';add_option('f3base_suite119_plugins',get_option('active_plugins'),'',false);$r=activate_plugin('wp-mcp-fator3/wp-mcp-fator3.php');if(is_wp_error($r)){echo $r->get_error_message();exit(1);}echo "activated";
