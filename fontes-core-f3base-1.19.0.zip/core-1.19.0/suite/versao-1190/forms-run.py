from pathlib import Path
import os,subprocess
p=Path(__file__).parent;php=os.environ['F3BASE_TEST_WORKSPACE']+'/runtime1150/php'
subprocess.run([php,str(p/'forms-preparar.php')],check=True)
try:
 r=subprocess.run(['python3',str(p/'http-server.py'),'node',str(p/'forms.cjs')])
finally:
 subprocess.run([php,str(p/'forms-limpar.php')])
raise SystemExit(r.returncode)
