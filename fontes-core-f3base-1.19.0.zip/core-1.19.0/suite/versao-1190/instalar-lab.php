<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110')){exit(2);}
define('WP_INSTALLING',true);
$_SERVER['HTTP_HOST']='127.0.0.1:8150';$_SERVER['REQUEST_URI']='/';
require $site.'/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';
if(!is_blog_installed()){wp_install('Bancada Core 1.19','labadmin','lab@example.test',true,'','Somente-Laboratorio-119!');}
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';
$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');
if(is_wp_error($r)){fwrite(STDERR,$r->get_error_message());exit(1);}
echo wp_json_encode(F3Base_Instalacao::atualizar(),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
