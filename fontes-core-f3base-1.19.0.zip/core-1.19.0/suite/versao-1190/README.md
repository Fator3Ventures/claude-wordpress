# Bancada 1.19.0

Evidências desta entrega em evidencias/*.json. Cada conjunto contém assertions nomeadas; upgrade.json separa instalação nova e atualização do ZIP original 1.18.0, com SHA fixado no runner. Não são homologações dos fornecedores.

Ambiente efetivamente usado: WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46/InnoDB e Chromium 154.0.8037.92. HTTP externo e wp_mail interceptados. DB local descartável; nenhuma credencial real. Os scripts exigem F3BASE_TEST_WORKSPACE e F3BASE_SITE com marcador de bancada. lab.py inicializa/encerra o MySQL isolado, executa PHP/Node e guarda dump apenas no ambiente, fora destes fontes. Runtime/WordPress/banco/navegador não são distribuídos.

Com uma bancada equivalente, ajustar paths runtime1150/lab1150, o marcador .f3base-bancada-110 e endereço local. Nunca apontar para produção. Exemplo: F3BASE_TEST_WORKSPACE=/caminho python3 suite/versao-1190/lab.py php suite/versao-1190/fundacao.php. Integração MCP requer o pacote 0.13.0 autorizado em work/impl119-contract/mcp/wp-mcp-fator3; não é dependência do Core em produção.

forms-run.py executa PHP multithread local, prepara/limpa fixtures e verifica HTTP + JS/sem JS. ui-run.py prepara/limpa consultas sintéticas para renderização. Os testes de carregadores e meta-ofertas usam navegador real com respostas de fornecedores simuladas. Esses dados não comprovam recebimento em Meta/GA4/Clarity nem qualidade de máscaras de uma conta real.

Testes adaptados de versões anteriores foram usados somente quando listados em VALIDACAO.md; não se somam evidências históricas. novas.php é uma adaptação histórica disponível e não foi executada como gate desta entrega; não contar como prova.
