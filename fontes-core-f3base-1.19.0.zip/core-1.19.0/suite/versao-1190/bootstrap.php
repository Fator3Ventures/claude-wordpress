<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110')){exit(2);}
$_SERVER['HTTP_HOST']='127.0.0.1:8150';$_SERVER['SERVER_NAME']='127.0.0.1';$_SERVER['REMOTE_ADDR']='192.0.2.115';$_SERVER['REQUEST_URI']='/';require $site.'/wp-load.php';wp_set_current_user(1);
