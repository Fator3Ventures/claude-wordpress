"""Derive the installed human-readable table dictionary from the generated contract."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];docs=root/'fontes/plugin/docs';d=json.loads((docs/'dados/contrato.json').read_text())
def cell(v):
 if v is None:return 'NULL'
 if not isinstance(v,str):v=json.dumps(v,ensure_ascii=False)
 return v.replace('|','\\|').replace('\n',' ')
s='''# Dicionário de dados — 1.19.0 / contrato 4.3.0

Gerado de `dados/contrato.json`, com tipos e índices conferidos no MySQL da bancada. Substituir o prefixo de tabela somente pelo prefixo validado do site. IDs externos/opacos são strings. Sessão, IP ou UA não identificam uma pessoa comprovada.

Datas de filtros usam o fuso WordPress; início inclusivo e fim exclusivo no começo do dia seguinte. DATETIME de leads é UTC; epochs são segundos UTC salvo indicação explícita. Dia agregado segue o calendário da regra. Ausência, desconhecido e zero são estados diferentes.

A audiência usa análise como fonte canônica. Histórico agregado sem pseudônimos não permite reconstruir distintos do período. Para fórmulas, cobertura e filtros de conteúdo/sessão, leia MEDICAO-1.19.md e METRICAS.md. Clarity guarda consultas móveis completas sanitizadas: não soma consultas para fabricar totais de dias ou pessoas.

Contatos e agregados seguem suas políticas próprias; consultar valores efetivos no site. Clarity tem retenção independente, zero sem expiração automática por padrão. Payload CAPI cifrado permanece só até o desfecho ou prazo útil; metadados seguem retenção da fila. Recibos podem sobreviver ao contato eliminado. Não exportar payload, segredos ou caminho físico.

## Relações e chaves

'''
for relation in d.get('relacoes',[]):s+='- '+(relation if isinstance(relation,str) else json.dumps(relation,ensure_ascii=False))+'\n'
for name,table in d['tabelas'].items():
 s+='\n## '+name+'\n\n'
 if table.get('granularidade'):s+=table['granularidade']+'\n\n'
 if table.get('documentacao'):s+='Guia: `'+table['documentacao']+'`.\n\n'
 s+='| Coluna | Tipo MySQL | Nulo | Padrão | Significado | Desde |\n|---|---|---|---|---|---|\n'
 for c in table['colunas']:
  s+='| `'+c['nome']+'` | `'+c['tipo_mysql']+'` | '+('sim' if c['nulo'] else 'não')+' | '+cell(c.get('padrao'))+' | '+cell(c['significado'])+' | '+cell(c.get('disponivel_desde','consultar contrato'))+' |\n'
 s+='\nÍndices:\n\n'
 for name,index in table.get('indices',{}).items():s+='- `'+name+'` ('+('único' if index['unico'] else 'não único')+'): '+', '.join('`'+c+'`' for c in index['colunas'])+'.\n'
s+='\n## Campos JSON\n\nContratos completos também em dados/contrato.json. Snapshot comercial e audiência têm escopos diferentes; não inferir atribuição ausente.\n\n```json\n'+json.dumps(d.get('json',{}),ensure_ascii=False,indent=2)+'\n```\n'
(docs/'DICIONARIO-DADOS.md').write_text(s);print(json.dumps({'dicionario_bytes':len(s.encode()),'tabelas':len(d['tabelas'])}))
