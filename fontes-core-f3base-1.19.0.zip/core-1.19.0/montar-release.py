"""Build reproducible 1.19.0 installer and SHA-256 per-file manifest; no runtime dependencies."""
from pathlib import Path
import hashlib,json,zipfile,argparse
VERSION='1.19.0';ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--saida',default='dist');args=p.parse_args();dest=Path(args.saida).resolve();dest.mkdir(parents=True,exist_ok=True);plugin=ROOT/'fontes/plugin'
assert 'Version:           '+VERSION in (plugin/'base-site-core-fator3.php').read_text() or 'Version: '+VERSION in (plugin/'base-site-core-fator3.php').read_text()
rows=[]
with zipfile.ZipFile(dest/f'base-site-core-fator3-{VERSION}.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(plugin.rglob('*')):
  if not file.is_file():continue
  assert not file.is_symlink(),file
  rel=file.relative_to(plugin).as_posix();body=file.read_bytes();i=zipfile.ZipInfo('base-site-core-fator3/'+rel,(2026,10,1,0,0,0));i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,body);rows.append({'arquivo':rel,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
manifest={'versao':VERSION,'revisao_pacote':1,'base_atualizacao':'1.18.0 concluída ou instalação nova','downgrade_suportado':False,'arquivos':rows,'nota':'Arquivos e timestamps determinísticos; comparar manifesto e ZIP entregue. Nenhum dado/credencial da bancada integra o instalador.'}
(dest/f'manifesto-{VERSION}.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'arquivos':len(rows),'saida':str(dest)}))
