"""Close reproducible 1.19.0 release from named local evidence. Never deploy."""
from pathlib import Path
import argparse,json,hashlib,zipfile,subprocess,re,tempfile
ROOT=Path(__file__).resolve().parent;plugin=ROOT/'fontes/plugin';ev=ROOT/'suite/versao-1190/evidencias';VERSION='1.19.0'
p=argparse.ArgumentParser();p.add_argument('--saida',default=str(ROOT.parents[1]/'deliverables/1.19.0'));p.add_argument('--preparar',action='store_true');args=p.parse_args();out=Path(args.saida).resolve();out.mkdir(parents=True,exist_ok=True)
labels={'fundacao':'Instalação, menu, navegação cron, opções e contratos','arquivos':'Arquivos privados, revisão, idempotência e concessões','regressoes-adicionais':'Resumo de e-mails, mensagens, MIME, spam e falha transacional','editorial':'Regressões editoriais, sessões e identidade de conteúdo','relatorios-ia':'Coorte comum, filtros, IA efetiva, assinaturas e comparação','meta-ofertas':'Fila Meta, cifra, prazos, conciliação e funil de ofertas','clarity':'Acervo integral sanitizado, cotas, comparação e gravações simuladas','mcp':'Contrato MCP 0.13.0 e permissões de leitura/escrita','carregadores':'Navegador: consentimento, GTM, modos e prazos','meta-ofertas-browser':'Navegador: PageView, ofertas, idempotência e frequência','forms-browser':'WordPress HTTP: três regimes, JS/sem JS, PDFs e menu real','ui':'Interfaces desktop/celular, filtros, comparação e erros JS','documentacao':'Documentação instalada, schemas e controle de leitura'}
results=[]
for key,label in labels.items():
 d=json.loads((ev/(key+'.json')).read_text());checks=d.get('checks',{})
 assert checks and all(v is True for v in checks.values()) and not any(d.get(x) for x in ['falhas','stderr','errors']),key
 for case in d.get('cases',[]):assert not case.get('errors'),(key,case)
 results.append({'conjunto':label,'assercoes':len(checks),'evidencia':key+'.json'})
upgrade=json.loads((ev/'upgrade.json').read_text());assert len(upgrade)==10
for step in upgrade:assert step['exit']==0 and not step['stderr'] and not step['resultado'].get('falhas') and all(step['resultado']['checks'].values()),step
upchecks=sum(len(step['resultado']['checks']) for step in upgrade)
syntax=json.loads((ev/'sintaxe.json').read_text());assert not syntax['falhas'] and syntax['assets_reproduziveis']==9
total=sum(r['assercoes'] for r in results)
validation=f'''# Validação — F3 Base Core 1.19.0

Data: 01/10/2026. Contrato 4.3.0. Base exclusiva: **1.18.0 concluída ou instalação nova**. Retomada na própria versão; downgrade não suportado. Nenhum site de produção foi acessado ou alterado. Korvena.net.br será testado pelo dono. Tema e implantador não foram alterados.

## Ambiente e resultado

WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46/InnoDB, Chromium 154.0.8037.92 e Playwright. Dados sintéticos, e-mail bloqueado, fornecedores simulados e HTTP WordPress local. Canal MCP 0.13.0 real autorizado, sem conexão à frota.

**{total} asserções aprovadas**, mais **{upchecks} verificações em dez etapas de instalação/atualização**. São asserções, não {total+upchecks} cenários independentes. Somente os conjuntos abaixo foram contabilizados. Evidências em `suite/versao-1190/evidencias/` no ZIP de fontes.

| Conjunto | Asserções | Evidência |
|---|---:|---|
'''+''.join(f"| {r['conjunto']} | {r['assercoes']} | `{r['evidencia']}` |\n" for r in results)+f'''
Os dois caminhos verificam instalar, semear dados, atualizar, repetir e retomar. O instalador real 1.18.0 tem SHA-256 `7429202b8d00ca9e0b8c76403d24552847ac6d668d9dd405a16bff5ed2bda584`. Preferências falsas, listas vazias, política, contatos e segredos foram preservados. Pendências CAPI antigas foram cifradas sem renovar prazo. Sem IDs/tokens novos, Clarity continua inerte; CAPI existente conserva Lead em ambos.

Sintaxe conferida em {syntax['php']} arquivos PHP e {syntax['javascript']} JavaScript. Nove assets minificados recompostos e conferidos com Terser fixado. `pacote.json` documenta CRC, conteúdo byte a byte, manifesto e reprodução do instalador. `upgrade.json` informa o hash do ZIP usado no fechamento. Documentação também é lida pela ability instalada, não só pela presença dos arquivos.

## Cobertura efetiva

- Clique real Contatos → Relatórios, cron de navegação com usuário zero, permissões administrativas e perfis MCP distintos.
- Relatórios comuns com filtros, testes/automação, anotações, histórico expirado, método, canal e ads; IA por representação, rede, assinatura, horários e semanas. Sem somar distintos diários.
- Consentimento antes das tags, revogação, ausência de SDK em testes, GTM aditivo, send_to, ocioso com/sem requestIdleCallback, prazos independentes e modo Meta servidor sem fbevents gerado pelo Core. Análise própria conserva o primeiro envio em cinco segundos.
- Formulários com/sem JS nos três regimes, confirmação após aceite, continuidade privada/WhatsApp, mensagens, assunto sem duplicação, antispam e limites PHP. Expiração responde 410. Resumo de e-mails reserva pendentes sem reenvio duplicado.
- Cadastro/importação/substituição privada, hash e revisão concorrente; concessões válidas entregam arquivo novo. Downloads concorrentes recebem conteúdo íntegro. Falha de banco anterior à publicação mantém versão anterior; origem pública só é excluída por operação explícita.
- Ofertas por instância visível, reabertura sem duplicação, fila até disponibilidade do emissor, consentimento/testes, início/envio aceito e funil sem encaixe artificial.
- Meta: cifra, prazo útil superior a 24 h sob janela confirmada, teto, prazo fixo, limpeza terminal, revogação, fila e captura conciliadas por hash; prova insuficiente recusa servidor.
- Clarity: todas as métricas/dimensões válidas da resposta de teste, precisão e blocos vazios, saneamento, gzip/hash, normalização e reprocessamento sem HTTP, exportação/restauração, retenção independente, cotas/429, comparação compatível e isolamento da falha de gravações.
- Interfaces em 1440 e 390 px, inspeção visual de PNGs, filtros e quadros Clarity legíveis. Ausência de erros JavaScript nos percursos verificados.

## Homologações externas e limites

Testes simulados não comprovam recebimento nas contas Meta/GA4/Clarity, SMTP ou Pipedrive. Nenhuma homologação da frota foi encerrada por esta entrega. A aprovação de modo Meta servidor continua condicionada à evidência por site e à conciliação local; o pacote não a ativa automaticamente.

Meta: conferir janelas oficiais vigentes antes de habilitar retenção ampliada; sem confirmação válida, uma hora. Homologar autoConfig e deduplicação/catálogo em sete dias, com mínimo previsto por evento, depois acompanhar mais sete dias no modo servidor. Campos de EMQ ou entrega remota não observados não viram zero.

Clarity: conferir tag, consentv2, mascaramento efetivo e gravações em conta autorizada; coletar por três dias, pausar mais de 24 h e verificar janela/lacuna após retomada. A cópia local é integral para informação analítica aceita pelo contrato e saneada; não inclui segredos, identificadores pessoais ou gravações. Janelas móveis não permitem fabricar dias isolados ou somar usuários.

Desempenho: não houve nova rodada PageSpeed/Lighthouse nem medição de custo do SDK real. A validação de agendamento não é promessa de ganho em TBT/LCP/INP. Comparações exigem execuções repetidas equivalentes, mediana/dispersão e dados de campo com volume explícito.

Pipedrive e integrações nativas já entregues preservam seus aceites externos. Casos de rede, banco e navegador simulados não certificam hospedagem, falta física de disco, proxy, restauração de backup ou cron da frota. Ausência de log permanece lacuna; requisição IA não comprova citação/recomendação nem causa de uma visita posterior. Suites históricas e `novas.php` não executada não integram a contagem desta entrega.
'''
(plugin/'docs/VALIDACAO.md').write_text(validation)
items=[
('R119-01','Contatos → Relatórios usa menu registrado antes da validação e admin.php; clique real sem 404.','class-f3base-leads-admin.php','menu','fundacao.json; forms-browser.json','Conferência do menu por site.'),
('17','Confirmação genérica, três regimes JS/sem JS, mensagens, assunto com nome, MIME/limites PHP e estilo; preservar resumo de avisos e 410.','class-f3base-confirmacao.php','preparar','forms-browser.json; regressoes-adicionais.json','SMTP/caixa autorizada e páginas do tema.'),
('82','Classificação efetiva suspeita para IA fora de faixas válidas; conserva agente/rede declarados e total.','class-f3base-agentes-classificacao.php','efetiva','relatorios-ia.json','Confiança no IP de origem e cobertura dos logs do site.'),
('83','IA por página/artigo, HTML/Markdown, método/status/rede, instantes, semanas e sessões vindas de IA; descoberta separada.','class-f3base-editorial-relatorios.php','consultar','relatorios-ia.json; editorial.json','Leitura é requisição observada; servidor não mede citação/recomendação.'),
('88','Fonte canônica analise e coorte comum entre editorial, integrado, CSV e abilities; filtros e cobertura preservados.','class-f3base-relatorios.php','consultar','relatorios-ia.json; editorial.json','Séries antigas sem dados não são reconstruídas.'),
('90','Assinatura reduzida em agregados, filtro técnico e volume em / com sem_operador_identificavel separado.','class-f3base-agentes-classificacao.php','assinatura','relatorios-ia.json; ui.json','Ferramenta não identifica operador; histórico depende do log disponível.'),
('92','Renovação de prova por cron sem usuário, trava, invalidação e retentativa; permissão administrativa mantida.','class-f3base-navegacao.php','executar_prova','fundacao.json','Execução diária efetiva do cron é aceite operacional.'),
('93','autoConfig false antes de init; PageView/Lead explícitos preservados.','class-f3base-modulo-tracking.php','enfileirar','carregadores.json','Comportamento de eventos automáticos do Pixel real.'),
('94','Meta PageView/Lead por navegador/ambos/servidor, conciliação, prova, payload cifrado e prazo útil até sete dias conforme janela confirmada. GA4 segue tag.','class-f3base-meta-transporte.php','homologar','meta-ofertas.json; meta-ofertas-browser.json; carregadores.json','Janelas oficiais, deduplicação e sete dias antes/depois na conta por site.'),
('95','Ocioso pós-load e teto independente com fallback, consentimento, revogação e idempotência.','class-f3base-modulo-tracking.php','enfileirar','carregadores.json','Benchmarks repetidos e métricas de campo não executados.'),
('96','Abilities de cadastro/listagem/substituição, blobs imutáveis, CAS/hash e concessões vigentes seguem arquivo novo; mídia pública preservada por padrão.','class-f3base-arquivos-servico.php','gravar','arquivos.json; regressoes-adicionais.json; forms-browser.json','Operação da pasta privada e backup na hospedagem.'),
('97','Contrato de oferta do tema, instância/visibilidade, eventos, frequência e funil com aceites do servidor; GA4/GTM sob consentimento.','class-f3base-ofertas-medicao.php','relatorio','meta-ofertas.json; meta-ofertas-browser.json','Tema implementa apresentação; recebimento GA4 em conta autorizada.'),
('98','Provider/policy_contract em todo catálogo, perfil Leitura sem escrita, capabilities WP e Update URI próprio; Core sem MCP.','class-f3base-servicos.php','registrar_ability','mcp.json; fundacao.json','Configuração das conexões da frota.'),
('99','GTM aditivo, send_to direto, objeto canônico por evento, destino CAPI independente e diagnóstico de duplicação.','class-f3base-tracking-diagnostico.php','ler','carregadores.json; fundacao.json','Contêiner e tags de terceiros são responsabilidade do operador.'),
('100','Clarity opcional no navegador, consentv2, máscara, revogação, testes e estratégia própria; token só no servidor.','class-f3base-clarity.php','catalogo','carregadores.json; clarity.json','Mascaramento e custo do SDK real exigem homologação.'),
('101','Acervo completo analítico sanitizado, sem expiração padrão, normalização versionada, coleta/cotas, comparação, exportação/restauração e gravações isoladas.','class-f3base-clarity-acervo.php','instalar','clarity.json; ui.json','Três dias de coletas, pausa >24 h e gravações em conta real.')]
mapped=[]
for pedido,change,file,func,evidence,external in items:
 path=plugin/'includes'/file;assert path.exists(),path
 lines=path.read_text().splitlines();matches=[i+1 for i,l in enumerate(lines) if re.search(r'function\s+'+re.escape(func)+r'\s*\(',l)]
 mapped.append({'pedido':pedido,'estado':'Implementado e validado localmente; homologação externa quando indicada','resultado':change,'arquivo':'includes/'+file,'linha':matches[0] if matches else 1,'funcao':func if matches else '', 'evidencia':evidence,'restante_externo':external})
maptext='# Mapa da entrega — 1.19.0\n\nPlano aprovado preservado em PLANO-APROVADO.md nos fontes. Implementado refere-se ao pacote local, não ao encerramento de aceites na frota. Linhas identificam esta versão; documentação/schemas detalham os contratos.\n\n| Pedido | Comportamento entregue | Código | Evidência local | Restante / limite |\n|---|---|---|---|---|\n'
for row in mapped:maptext+=f"| {row['pedido']} | {row['resultado']} | `{row['arquivo']}:{row['linha']}` | {row['evidencia']} | {row['restante_externo']} |\n"
maptext+='\nDecisões preservadas: GA4 sem transporte duplo; concessões válidas seguem novo PDF; 410 e resumo de e-mails são regressões; navegação por cron anônimo; assinatura sem operador inventado; leitura/visita IA sem inferir citação; histórico Clarity nesta entrega; retenção Meta ampliável além de 24 h. Não há novos adiamentos de implementação destes itens. Limites de fontes externas e homologações permanecem explícitos.\n'
(plugin/'docs/MAPA-ENTREGA-1.19.md').write_text(maptext);(plugin/'docs/dados/entrega-1.19.json').write_text(json.dumps({'versao':VERSION,'base':'1.18.0','itens':mapped},ensure_ascii=False,indent=2)+'\n')
delta='''## Delta por site

- **Banco:** cinco tabelas novas: `{prefixo}f3base_arquivos_blobs`, `f3base_arquivos_operacoes`, `f3base_meta_eventos`, `f3base_clarity_coletas` e `f3base_clarity`. Leads schema 5 acrescenta vínculo de blob/MIME/origem/atualização em arquivos. Análise ganha contexto de ofertas; agregados de acessos ganham assinatura reduzida/regra nas dimensões e chaves. Fila CAPI schema 3 acrescenta nome/instante/rota/prazo/hash/classe e cifra payload pendente. Colunas, tipos e todos os índices estão em `docs/dados/contrato.json`.
- **Options:** marcador `f3base_release_1190` registra origem/checkpoints/defaults. Somente chaves ausentes recebem padrões: autoConfig, políticas/prazos de carregamento, Meta, Clarity e hosts de confirmação. `false`, zero, listas vazias, todas as opções de canal e credenciais existentes permanecem. CAPI Lead configurada na base recebe ambos/Lead; PageView CAPI não é ativado implicitamente. Estados técnicos de Clarity/cota/credencial e Meta/prova são criados conforme uso.
- **Cache:** sem novo parâmetro ou exclusão em `wp-cache-config.php`; sem alteração de diretivas no bloco `F3BASE MANAGED`. Regras/provas existentes seguem serviços próprios. Não há mudança de infraestrutura ou do tema.
- **Privados:** provisionamento conferido na instalação; novas importações/substituições usam blobs e recibos privados. Origem pública nunca é removida automaticamente. Concessões válidas seguem versão nova; limites/revogação/expiração permanecem.
- **Cron:** prova de navegação a cada 12 h com retentativa, coleta Clarity quando configurada, continuidade e limpezas próprias. Executor parado implica atraso declarado; não se promete execução por relógio sem WordPress/cron.
- **Coleta:** ofertas e contexto de conversão, assinatura técnica reduzida, histórico analítico Clarity e transporte Meta conforme configuração/consentimento. Sem IDs novos não se ativa Clarity/GTM. A fila Meta pode guardar IP/UA cifrados além de 24 h quando ainda úteis; teto de sete dias e janela externa aplicável, sem renovação, com remoção terminal. Sem janela confirmada vigente usa uma hora. Histórico Clarity tem retenção zero (sem expiração automática) por padrão.
- **Séries:** resumo integrado passa à mesma audiência editorial; registrar o corte UTC de atualização por site. Histórico sem evidência conserva lacuna/indisponibilidade. Não somar janelas Clarity, visitantes diários ou robôs como pessoas.
- **Documentação instalada:** guias por recurso, catálogo de opções/ajuda, schemas das abilities, tabelas/índices, SQL de leitura, rastreabilidade, operação e validação. Agente lê `docs/` ou `f3base/documentacao-ler` autenticado.

## Instalação e recuperação

Instale **base-site-core-fator3-1.19.0.zip** sobre a 1.18.0 concluída ou em site novo. O ZIP de fontes serve para auditoria/desenvolvimento, não para a tela de plugins. Faça o backup operacional e confira versão, marcador concluído, saúde, pasta privada, menu e envio marcado como teste. Novos fornecedores dependem de IDs/tokens e escolha explícita.

Recuperação é retomada na própria 1.19.0: corrigir a causa, reinstalar os mesmos arquivos quando necessário e executar atualização/pendências. Não apagar marcadores nem fazer downgrade. Preserve banco, pasta privada e salts de forma protegida; não restaure banco antigo sobre contatos novos. O guia `docs/OPERACAO-E-RECUPERACAO.md` detalha filas, acervos e backup.

A implementação não acessou nem instalou em produção. O destino GitHub previsto no plano não foi publicado por esta tarefa. Homologações por conta/site estão em VALIDACAO.md e no mapa; o dono realiza os testes em korvena.net.br.
'''
(plugin/'docs/DELTA-1.19.md').write_text('# Alterações por site — 1.19.0\n\n'+delta)
state={'version':VERSION,'status':'IMPLEMENTADO_VALIDADO_LOCALMENTE','plan':'PLANO-APROVADO.md','base':'1.18.0 concluída ou instalação nova','production_access':False,'tests':results,'assertions':total,'upgrade_checks':upchecks,'upgrade_steps':10,'external_homologation':'Pendente por site/conta; detalhes em docs/VALIDACAO.md','note':'Não houve implantação na frota nem publicação no GitHub.'}
(ROOT/'IMPLEMENTACAO-ESTADO.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
if args.preparar:
 print(json.dumps({'documentacao':'preparada','assercoes':total,'upgrade_verificacoes':upchecks}));raise SystemExit(0)
subprocess.run(['python3',str(ROOT/'montar-release.py'),'--saida',str(out)],check=True)
installer=out/f'base-site-core-fator3-{VERSION}.zip';manifest=out/f'manifesto-{VERSION}.json';digest=hashlib.sha256(installer.read_bytes()).hexdigest()
assert {step.get('instalador_sha256') for step in upgrade}=={digest},'Reexecute upgrade.py com F3BASE_INSTALLER apontando para este ZIP antes de fechar'
manifest_data=json.loads(manifest.read_text());expected={p.relative_to(plugin).as_posix():p for p in plugin.rglob('*') if p.is_file()};rows={r['arquivo']:r for r in manifest_data['arquivos']}
with zipfile.ZipFile(installer) as z:
 assert z.testzip() is None
 actual={n.removeprefix('base-site-core-fator3/'):n for n in z.namelist()};assert set(actual)==set(expected)==set(rows)
 for rel,path in expected.items():
  assert not path.is_symlink() and '..' not in Path(rel).parts
  data=path.read_bytes();assert z.read(actual[rel])==data and rows[rel]['sha256']==hashlib.sha256(data).hexdigest()
with tempfile.TemporaryDirectory() as temp:
 subprocess.run(['python3',str(ROOT/'montar-release.py'),'--saida',temp],check=True,capture_output=True)
 assert (Path(temp)/installer.name).read_bytes()==installer.read_bytes()
package={'versao':VERSION,'arquivos':len(expected),'zip_crc':True,'fontes_byte_a_byte':True,'manifesto_sha256':True,'reproduzivel':True,'sha256_instalador':digest}
(ev/'pacote.json').write_text(json.dumps(package,ensure_ascii=False,indent=2)+'\n')
report=out/f'RELATORIO-{VERSION}.md';report.write_text(f'# Entrega — F3 Base Core {VERSION}\n\nInstalador: `{installer.name}`\n\nSHA-256: `{digest}`\n\n'+delta+'\n'+maptext+'\n'+validation)
source=out/f'fontes-core-f3base-{VERSION}.zip';files=list((ROOT/'fontes').rglob('*'))+list((ROOT/'suite/versao-1190').rglob('*'))+list((ROOT/'suite/build-assets').rglob('*'))+[ROOT/'referencias/base-site-core-fator3-1.18.0.zip']+[ROOT/n for n in ['README.md','PLANO-APROVADO.md','IMPLEMENTACAO-ESTADO.json','montar-release.py','fechar-release.py']]
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(set(files)):
  if not file.is_file() or any(p in ['node_modules','__pycache__','.git','docs-gerados'] for p in file.parts) or file.suffix=='.pyc':continue
  assert not file.is_symlink(),file
  rel=file.relative_to(ROOT).as_posix();i=zipfile.ZipInfo('core-'+VERSION+'/'+rel,(2026,10,1,0,0,0));i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,file.read_bytes())
with zipfile.ZipFile(source) as z:assert z.testzip() is None
artifacts=[installer,source,report,manifest]
(out/f'SHA256SUMS-{VERSION}.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in artifacts))
print(json.dumps({'versao':VERSION,'assercoes':total,'upgrade_etapas':10,'upgrade_verificacoes':upchecks,'sha256_instalador':digest,'arquivos':{f.name:f.stat().st_size for f in artifacts}},ensure_ascii=False))
