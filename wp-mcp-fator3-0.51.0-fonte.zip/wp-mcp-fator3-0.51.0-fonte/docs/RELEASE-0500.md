# Fator3 MCP 0.50.0 — avisos de manutenção e de registro

Instalação limpa ou atualização direta da 0.49.0. Requisitos de execução: WordPress 7.1.4 e PHP 8.3 ou superiores. Conjunto de referência: Core 1.94.0, Google 0.37.0, Meta 0.29.0, LinkedIn 0.26.0 e Pipedrive 0.12.0.

## Pedido MCP 85 — continuidade da manutenção

Uma passagem parcial pode indicar inventário em curso, outra página de candidatos ou orçamento de tempo esgotado. A próxima execução do evento f3_mcp_automatic_maintenance retoma o trabalho. O operador pode consultar system/maintenance-policy e olhar last_run.status, continuation_required, stalled e stall_counts. O contador aumenta por passagem efetivamente executada. As consultas de diagnóstico preservam o contador. Uma seleção protegida que continua igual abre o incidente na passagem configurada. O avanço da limpeza ou a liberação da proteção permite a recuperação na próxima passagem. Uma falha efetiva na leitura, na execução ou na política abre o incidente ao ser observada. O incidente da agenda continua independente.

Em Ferramentas → Fator3 MCP → Configurar → Arquivos e banco, o campo Passagens sem avanço aceita de 1 a 96. O padrão é 3. No MCP, simule system/maintenance-configure com policy.stall_passes. Para gravar, repita com dry_run=false e expected_revision da simulação. Alterar somente esse limite preserva o lote já selecionado e o cursor de retenção. As permissões e as proteções dos artefatos continuam aplicáveis.

## Pedido MCP 86 — registro do canal

O publicador do canal verifica o registro em requisição HTTP web ou cron HTTP, depois da inicialização necessária. Com registro saudável, a cadência ordinária é de cinco minutos. Após a primeira falha conclusiva, a próxima requisição HTTP elegível pode confirmar ou cancelar a suspeita. Duas falhas consecutivas em requisições distintas abrem canal_indisponivel para registro-wordpress. A primeira leitura saudável encerra o episódio. As chamadas dentro da mesma requisição contam uma vez. Passagens do WP-CLI e diagnósticos inconclusivos preservam a contagem.

O ponto PHP local Fator3\McpFiles\ChannelIncidents::observeRegistration() permite ao Site Core acionar a mesma observação. O Core 1.94.0 contém um observador independente que requer a delegação descrita no impacto desta edição. A fila e a entrega seguem o contrato incidentes/1. Para o aceite operacional, confira o produtor e o contexto em historico_registro durante 24 horas após a implantação na frota.
