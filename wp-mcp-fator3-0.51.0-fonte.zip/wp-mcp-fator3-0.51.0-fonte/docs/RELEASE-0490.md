# Fator3 MCP 0.49.0 — registro das rotas HTTP

Instalação limpa ou migração direta da 0.48.0. Requisitos: WordPress 7.1.4 ou superior e PHP 8.3 ou superior. O conjunto de referência inclui Fator3 Site Core 1.94.0, Google 0.37.0, Meta 0.29.0, LinkedIn 0.26.0 e Pipedrive 0.12.0.

## Pedido MCP84 e Core430

Quando um plugin inicializa a API REST antes da criação do transporte MCP, o WordPress já pode ter executado a prioridade 16 de rest_api_init. O transporte agora verifica o estágio desse hook. Se a prioridade ainda vai executar, agenda o registro das rotas. Se a prioridade foi alcançada ou se a ação terminou, registra as rotas na mesma requisição. Em uma instalação com WP-CLI isso permite consultar o servidor depois de uma inicialização precoce do REST por outro plugin.

O canal usa a rotina de registro existente para verificar a propriedade da rota principal e do alias. Se outro plugin já ocupa uma das rotas, o canal conserva o callback existente e registra o conflito para diagnóstico. A outra rota segue sua própria verificação. As duas rotas usam a política de autenticação e as permissões já configuradas no WordPress.

## Conferência após instalar

Consulte system/health em uma nova requisição administrativa. Espere a versão 0.49.0, registro do servidor e ferramentas prontos, rota principal e alias registrados. Se houver mcp_route_conflict, identifique o plugin que ocupa a rota indicada antes de alterar a configuração. No Core, consulte f3base/incidentes-tecnicos-ler para comparar as novas transições do recurso registro-wordpress com horário, produtor e contexto. Os episódios e entregas anteriores permanecem na fila. O operador confirma a entrega de e-mail usando o destino técnico do Core.

A mudança ocorre durante o bootstrap do transporte. A atualização preserva opções, concessões, política de retenção, recibos e agenda. O schema de dados continua na versão 2. O fluxo de correção após uma instalação usa uma nova versão. Para detalhes de configuração da retenção e dos avisos OAuth, consulte as notas da 0.48.0.
