# Impacto de Fator3 MCP 0.47.0 em Fator3 Site Core

Data: 18/11/2026 · Revisão: 1 · Etapa: implementação · Situação: alinhado.
Versão-base: MCP 0.46.0, entrega restaurada. Versão-alvo: 0.47.0, candidata.
Instalador emissor: ainda não fechado. Destinatário examinado: Core 1.93.0, instalador SHA-256 `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8`.
Natureza: contrato. Classificação: validacao-coordenada. Tickets: MCP84 / Core430.

## Mudança e consequência

Resposta ao impacto recebido do Core 1.93.0: `ChannelIncidents` passa a produzir `f3base_incidente_publicar_v1(null,event)` para o pacote `canal`. Usa exclusivamente os códigos e rota permitidos em `F3Base_Incidentes`. O Core continua proprietário de deduplicação, fila, destino técnico e e-mail. A referência `registro-wordpress` é compartilhada com `F3Base_Incidentes_Provedores::canal` para não duplicar o episódio.

## Ação do responsável

A frota confere/configura o destino técnico do Core, instala o MCP novo com hash e slug, observa aviso e recuperação e confirma recebimento na caixa autorizada. O teste de transporte interceptado demonstra o caminho de execução até `wp_mail`, sem comprovar caixa postal. Em CTOOffice, medir idempotência e backups após um dia de cron nativo com a política de 24h. Não há envio ou publicação à frota nesta tarefa.

## Diagnóstico e contrato do destinatário

A versão 1.93.0 já fornece o contrato requerido. Não se solicita patch: alterar o destinatário seria desnecessário. Entradas: `pacote:canal`, `codigo` permitido, `recurso` estável, `estado:aberto|recuperado`, `rota:tools.php?page=wp-mcp-fator3`, `acao_humana`, `desde`, `vence_em` opcional. `ok:true` transfere a responsabilidade de entrega ao Core; ausência de contrato ou resposta sem `ok` conserva a observação local para retentativa. O consumidor usa os resultados `aguardando_destino`, `ocupado` e `entrega_incerta` conforme implementação real. Segredos e texto de exceção não atravessam a fronteira.

## Prontidão e sequência

Core 1.93.0 já instalado no Site-Teste e copiado sem alterações no laboratório. MCP candidato implementa produtor, aviso de concessão e fila local. Sem Core, retenção própria segue autônoma e observações aguardam; com o contrato presente, são reenviadas. Nenhuma outra alteração de código do MCP é prevista para completar este contrato. Não há suporte operacional a combinações históricas nem downgrade. Publicação/instalação de releases alheias não fazem parte desta rodada.

## Validação e evolução

Contrato atendido testado no WordPress real isolado com o Core recebido: aviso de refresh entregue ao coletor `pre_wp_mail`, deduplicação e recuperação depois da renovação real de tokens. Ausência de contrato, retentativa, prova final de instalação e hashes serão registrados no fechamento. O registro próprio foi iniciado na implementação; o contrato já estava definido no encaminhamento recebido. A recepção real e medição de um dia em produção dependem de instalação e operação da frota.
