# Fator3 MCP 0.51.0 — identidades históricas e validade OAuth

Base de atualização direta testada: 0.50.0. Também admite instalação limpa. Requisitos mínimos: WordPress 7.1.4 e PHP 8.3. A matriz desta edição inclui o Site Core 1.95.0, Google 0.38.0, Meta 0.29.0, LinkedIn 0.26.0 e Pipedrive 0.12.0.

## Pedidos MCP 87

Em Ferramentas → Fator3 MCP → Configurar → Clientes, busque o identificador completo do registro histórico. Abra Consultar, confira a conta e o identificador, marque a confirmação e use Revogar acesso. Um registro legado pode ter uma política armazenada como ativa mesmo depois de perder todo o acesso. A lista passa a exibir **Sem acesso** para esse registro. A concessão resultante da migração tem seu próprio identificador e sua própria situação. Concessões ativas precisam ter ao menos um token de acesso ou renovação ativo e dentro da validade para aparecerem como ativas na lista.

Pelo canal, leia connections/list e passe o connection_id completo e a revisão policy_version em expected_policy_version para connections/revoke. Uma resposta bem-sucedida traz revoked verdadeiro. Releia a lista para conferir status revoked e a revisão. Se houver conflito de revisão, releia o registro antes de decidir sobre a alteração. A operação encerra as sessões do identificador escolhido. Outras identidades da mesma conta ou do mesmo cliente conservam suas concessões.

## Pedidos MCP 88

Uma autorização ou uma renovação bem-sucedida emite um token de acesso de 24 horas (86400 segundos) e um token de renovação de 90 dias (7776000 segundos). O cliente recebe expires_in igual a 86400. A utilização do token de renovação emite um novo par com prazos contados a partir dessa troca. O vencimento dos tokens emitidos antes da atualização continua sendo o que está gravado.

Com o aviso configurado em 14 dias, uma concessão renovada nesta versão entra na janela de refresh_vencendo após 76 dias sem nova renovação. A publicação ocorre na primeira observação elegível. O Core recebe o vencimento efetivo e conduz a entrega. A revogação invalida o acesso na próxima chamada, inclusive dentro das 24 horas. Reutilizar uma renovação já consumida revoga a concessão. A manutenção automática aplica os critérios de expiração e preserva os comprovantes necessários à detecção de reuso.
