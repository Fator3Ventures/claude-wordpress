# Impacto do Fator3 MCP 0.50.0 no Fator3 Site Core

Revisão 1 · Planejamento · 18/11/2026 · Pedido MCP 86. Base do emissor wp-mcp-fator3 0.49.0, instalador SHA-256 c1981c997840231a47492333ebb48125b2e8b8dd8619ec660bc8ad205883b134. Alvo 0.50.0, instalador ainda em preparação. Destinatário base-site-core-fator3 1.94.0, SHA-256 0eff84a92622b3daa2aebd81437bbb2c33eaea648d1955c46e29ef70aedf9008.

O MCP e F3Base_Incidentes::observar_registro_canal() produzem transições para o mesmo recurso registro-wordpress. O segundo caminho publica sua decisão diretamente no Core. Um único produtor deve aplicar o quórum de duas requisições web e ignorar CLI. A decisão sobre o registro pertence ao canal. A fila, histórico, reconciliação e entrega continuam com o Core pelo filtro incidentes/1. A proposta para o Core consiste em delegar o seu ponto de observação à operação local ChannelIncidents::observeRegistration() quando disponível. A coleta passiva de contexto no histórico continua independente.

Aceite: processo WP-CLI sem transição, falha web isolada sem abertura, duas falhas de requisições distintas com uma abertura e saúde restaurada com uma recuperação. Exercitar o observador do Core e do MCP na mesma requisição. A equipe do Core decide a inclusão oficial. A observação de 24 horas na frota começa após implantação coordenada.

## Revisão 2 · Encaminhamento ao responsável pelo Core

A 0.50.0 oficial do emissor está instalada no Site-Teste. Instalador wp-mcp-fator3-0.50.0-instalador.zip, 966854 bytes, SHA-256 97f6c6a233c2210e24cdef205a66a41c95e20eca9ad8f3644e518bc8ed4ee95f. O contrato local de delegação está implementado. O Core mantém a publicação dos outros incidentes e continua lendo o snapshot passivo para explicar o contexto histórico da transição.

Aplique a alteração abaixo em includes/class-f3base-incidentes.php na próxima edição oficial do Core. O método público observar_registro_canal é o caminho ativo alcançado por F3Base_Incidentes_Provedores::canal(). A guarda de disponibilidade mantém o diagnóstico próprio quando o publicador estiver ausente. O registro de contexto em historico_registro usa registro_canal() diretamente, preservando a separação entre diagnóstico e decisão de abertura.

```diff
--- a/includes/class-f3base-incidentes.php
+++ b/includes/class-f3base-incidentes.php
@@ -57,6 +57,10 @@
 
     /** Snapshot coletado no próprio observador. Metadados livres do filtro não são persistidos. */
     public static function observar_registro_canal(): void {
+        if (is_callable(['Fator3\McpFiles\ChannelIncidents', 'observeRegistration'])) {
+            \Fator3\McpFiles\ChannelIncidents::observeRegistration();
+            return;
+        }
         $registro = F3Base_Incidentes_Provedores::registro_canal();
         if ($registro === null) {return;}
         $indisponivel = $registro['erros'] !== [];
```

SHA-256 do patch distribuído em tools/release0500/core-registro.patch: 99b4aca6a4772469be132454216d9779143e3f8d319dfdad8ca359b18edbe790.

**Prova própria.** A mesma requisição web com o servidor MCP desabilitado produziu uma suspeita de contagem 1 no MCP e uma abertura imediata de origem observador_core no Core oficial 1.94.0. Com a proposta aplicada na cópia isolada, uma falha seguida de saúde deixou o histórico sem abertura. Duas falhas em requisições HTTP distintas abriram uma vez, com origem publicador_canal e contexto http_cron. A recuperação web encerrou o episódio uma vez. Houve três chamadas adicionais dos observadores na mesma requisição. Os históricos sanitizados constam em evidencias/0500/core.json, e os passos em registro-http.json.

**Responsabilidade e ordem.** Distribuir o MCP e incorporar a delegação na edição oficial do Core. Quando os dois estiverem ativos, a frota verifica por 24 horas as passagens de WP-CLI a cada 15 minutos nos 11 sites; examina origem, contexto e horário das novas transições. Na troca de um site com acúmulo, compara last_run e a redução da contagem com os avisos de manutenção. O Site-Teste recebeu exclusivamente a edição oficial do MCP. A fila preexistente e o destino técnico seguem a configuração do Core.

## Revisão 3 de acompanhamento na entrega MCP 0.51.0, 18/11/2026

O Core 1.95.0 oficial incorporou a delegação ao observador do canal. A revisão 2 do retorno do Core identifica o instalador pelo SHA-256 6971df93ecf39e14e584e0fc3dc802aee77ab4f2d58eb5b8ce35d6a503a4c21c. A bancada do MCP reproduziu seis requisições HTTP com o Core oficial, MCP 0.51.0 e os dois observadores. O histórico do Core guardou uma abertura em cron HTTP e uma recuperação web, ambas com origem publicador_canal. Ver evidencias/0510/registro-http.json e registro-core.json. Correção de código encerrada. A observação de 24 horas em 11 sites continua sob responsabilidade da frota.
