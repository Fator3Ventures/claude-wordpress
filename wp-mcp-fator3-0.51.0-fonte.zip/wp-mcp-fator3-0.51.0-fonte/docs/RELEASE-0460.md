# Fator3 MCP 0.46.0

Instalação limpa ou atualização direta da 0.45.0 em WordPress 7.1.4 e PHP 8.3 ou superiores. O conjunto de referência inclui Site Core 1.87.3, Google 0.36.0, Meta 0.27.0, LinkedIn 0.24.0 e Pipedrive 0.11.1. O nome das operações e o schema do banco do canal permanecem vigentes.

## Pedidos MCP 81

Em Ferramentas → Fator3 MCP, Operação reúne Visão geral e Atividade. Configurar reúne Conexão, Clientes e Arquivos e banco. Suporte reúne Diagnóstico e Ajuda. Os links antigos abrem a mesma aba, conservando filtros e seleção. A busca de clientes aceita nome, login e identificador. A lista de atividade e a de clientes mostram a faixa exibida e o total. Em telas estreitas, deslize dentro da tabela para consultar as últimas colunas.

## Pedidos MCP 82

O MCP registra a solicitação antes do processamento de db/execute, db/batch, db/search-replace, db/export e db/restore. O processo PHP CLI mantém a conexão com o banco durante a execução. A chamada que a iniciou aguarda até três segundos, descontando a margem do limite PHP. Uma operação em andamento devolve status, retryable e um operation_id com prefixo sqljob:. Consulte operations/status com esse identificador até obter result. Se result.preview for verdadeiro, use o confirm_token na habilidade original. A auditoria usa o identificador sqljob: no início e no encerramento. O recibo da fase continua disponível com seu identificador phase:.

O executor exige PHP CLI da mesma instalação, com o WordPress, suas extensões e acesso ao mesmo armazenamento privado. O site inicia o processo diretamente quando disponível. O cron CLI também pode assumir solicitações ainda pendentes. Depois de dez minutos sem início, confira o cron CLI antes de criar nova prévia. Se um executor desaparecer após iniciar, consulte o recibo da fase e o backup. As solicitações e resultados locais ficam cifrados com uma chave derivada dos salts do site e têm limpeza agendada em 24 horas. O resultado completo fica restrito à identidade autorizada.

## Pedidos MCP 83

system/error-log agrupa as ocorrências AH01276 em diretórios de sonda equivalentes. A mensagem do grupo contém {hex} no trecho variável e count informa o número de ocorrências. No fatal, stack contém uma amostra de quadros vinculados ao mesmo fluxo. Os argumentos das chamadas são omitidos. stack_truncated sinaliza corte por quantidade ou tamanho. As continuações de pilha ficam fora da contagem de avisos.
