# Entrega 0.51.0

Pedidos MCP 87 e 88. Base direta 0.50.0. Consulte RELEASE-0510.md para a operação e evidencias/0510 para os ensaios desta edição.
