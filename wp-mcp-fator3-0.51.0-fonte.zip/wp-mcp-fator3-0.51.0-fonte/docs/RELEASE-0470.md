# Fator3 MCP — notas da versão 0.47.0

Pedido 84, de 18/11/2026. Base direta: 0.46.0. Requisitos: WordPress >= 7.1.4 e PHP >= 8.3. Esta edição mantém o slug, basename, rotas OAuth/MCP e as três ferramentas públicas do canal. Senhas de aplicação e descoberta sem limite explícito conservam o comportamento aprovado.

## Conjunto vigente

Fator3 Site Core 1.93.0; Google 0.36.0; Meta 0.28.0; LinkedIn 0.25.0; Pipedrive 0.11.1. O contrato `incidentes/1` e o filtro local `f3base_incidente_publicar_v1` são fornecidos pelo Core 1.93.0. O canal produz observações; o Core mantém destino, fila, deduplicação, retentativa e envio pelo e-mail técnico. Nenhum webhook Slack é adicionado.

## Configuração e simulação

Ferramentas → Fator3 MCP → Configurar → Arquivos e banco → Manutenção automática. Administradores com `manage_options` podem simular critérios ou salvar a política com guarda de revisão. A simulação preserva o acervo e apresenta quantidades por categoria, proteções e indicação de outros lotes. A política fica em `f3_mcp_automatic_maintenance` e é protegida contra `options/update` genérico.

| Campo | Padrão | Efeito |
|---|---:|---|
| `enabled` | true | Habilita exclusão; os avisos continuam quando pausada |
| `backups_days` | 1 | Backups, pré-imagens e exportações SQL completos sem referências pendentes, após 24h |
| `idempotency_days` | 1 | Retira resultados volumosos concluídos; mantém comprovante mínimo de repetição |
| `oauth_receipts_days` | 30 | Prazo para excluir comprovantes OAuth já compactados |
| `audit_days` | 0 | Zero preserva auditoria; positivo permite compactar registros mais antigos |
| `refresh_notice_days` | 14 | Antecedência do aviso da concessão OAuth ativa |
| `cron_late_seconds` | 3600 | Tolerância do atraso do evento de manutenção |

Dias inteiros de 1 a 3650, com zero adicional para auditoria; atraso entre 1 e 86400 segundos. Política inválida pausa a exclusão. Uma mudança de política enquanto existe lote pendente é recusada com `maintenance_in_progress`; a próxima passagem retoma o lote. A gravação concorrente recebe `revision_conflict`.

As três novas habilidades exigem `manage_options` e perfil de conexão autorizado:

- `system/maintenance-policy`: sem parâmetros; retorna `policy`, `revision`, `next_run`, `last_run` e estado do contrato de incidentes.
- `system/maintenance-configure`: `policy` parcial; `dry_run:true` padrão. Para gravar, `dry_run:false` e `expected_revision` da leitura/simulação corrente.
- `system/maintenance-preview`: `policy` parcial opcional; simula a passagem sem executar exclusões. Consulte o `success` de cada categoria: inventário indisponível não é acervo vazio.

```json
{"ability_name":"system/maintenance-policy","parameters":{}}
```

```json
{"ability_name":"system/maintenance-preview","parameters":{"policy":{"backups_days":1,"audit_days":0}}}
```

```json
{"ability_name":"system/maintenance-configure","parameters":{"policy":{"enabled":true,"backups_days":1},"dry_run":true}}
```

A confirmação repete a proposta com `dry_run:false` e a revisão recebida. Os defaults de `plugins/upload`, a política de conexão e as confirmações destrutivas existentes permanecem aplicáveis.

## Execução e proteções

O evento `f3_mcp_automatic_maintenance` recorre a cada 900 segundos. A primeira passagem é prevista para um minuto após o agendamento. WP-Cron depende de execução do WordPress ou cron externo da hospedagem. Intervalo previsto não prova horário real nem monitoramento de indisponibilidade total.

Cada passagem usa identidade interna por site, trava exclusiva e seleções congeladas das rotinas nativas. Tokens/idempotência/auditoria usam até 100 registros por categoria; backups e SQL até 200. Um orçamento de 15 segundos entre categorias preserva continuação. Hashes e remoção de um componente individual dependem do tamanho e da hospedagem; não há garantia de término de todo o acervo em 15 segundos. Cursores impedem que cópias antigas protegidas bloqueiem o avanço das demais. Lotes parciais mantêm comprovante e retomada.

Tokens válidos, validade desconhecida, operações em andamento/incertas e artefatos referenciados são preservados. Token expirado perde o estado utilizável na próxima seleção; um comprovante compacto permanece pelo prazo configurado. Refresh consumido de concessão ativa conserva o controle de reutilização. Mesmo após revogação, expiração, compactação e alteração da concessão precisam ter superado o prazo para exclusão física. O prazo não altera o TTL do token: acesso 1 hora, refresh 30 dias sem renovação.

Resultados de idempotência concluídos migram transacionalmente para `idempotency-receipts`, com fingerprint e operação, sem o resultado volumoso. A chave antiga continua recusando repetição (`idempotency_result_expired`) e parâmetros diferentes continuam em conflito. A tabela operacional diminui; o comprovante mínimo permanece. Auditoria com prazo positivo perde o payload detalhado e fica como registro excluído. Não se apagam referências de operações incertas por idade.

## Incidentes e OAuth

O produtor observa registro local do canal, agenda do marcador, atraso da manutenção, falha de manutenção, sentinela degradada e concessões OAuth. Os códigos são `canal_indisponivel`, `agenda_parada`, `cron_sem_passagem`, `integracao_indisponivel`, `refresh_vencendo` e `renovacao_falhou`. O recurso `registro-wordpress` coincide com a observação do Core para deduplicar o mesmo episódio.

Uma troca OAuth de um par concessão/cliente conhecido publica falha ou recuperação. Sucesso grava `last_refresh_at` e `refresh_expires_at` na concessão, dentro da transação de emissão. Concessões existentes usam o maior vencimento de refresh armazenado. O aviso não renova a credencial e não simula uso do cliente. A renovação real encerra o aviso quando o novo prazo sai da janela; revogação encerra o aviso de validade daquela concessão.

Sem Core, observações aguardam em fila local. Core sem destino técnico conserva sua fila e retorna `aguardando_destino`. Recursos/segredos não são incluídos no texto do e-mail: o Core usa referência opaca. `wp_mail` aceito não comprova recebimento na caixa postal. Para conferir destino e fila use as telas e `f3base/incidentes-tecnicos-ler` do Core.

## Sentinela e mudança de pasta

Os carregadores MU `000-f3-mcp-recovery.php` e `000-f3-database-recovery.php` resolvem o diretório privado em cada requisição: `F3_MCP_PRIVATE_DIR`, se explícito, ou `WP_CONTENT_DIR/f3-mcp-private`. A atualização troca um carregador antigo que gravava caminho absoluto, sem depender de alteração no runtime independente. Copie `wp-content` e preserve as chaves de assinatura do WordPress. Constante externa personalizada deve acompanhar o destino no `wp-config.php`.

Esta portabilidade é a localização do acervo pela sentinela. Journals pendentes também contêm caminhos dos alvos e pré-imagens; uma migração de site com operações pendentes exige reconciliá-las antes da cópia. Não há tradução automática de caminhos assinados de uma operação em andamento.

## Atualização e diagnóstico

Instalação limpa ou atualização direta de 0.46.0. Preserve opções, identidades de conexão, chaves e estado privado. Confirme `system/health`, `system/maintenance-policy`, `cron/list` e o índice `system/guide` em nova requisição. Leia este documento com `system/guide` usando `document:release-0470`, seguindo a paginação e verificando versão/hash. O relatório externo registra os bytes e testes efetivamente validados. Correções após entrega/instalação final exigem outra versão; não se recomenda downgrade.
