# Administração por assunto — 0.13.0

Abra Ferramentas > Fator3 MCP LinkedIn. Cada aba tem endereço próprio com `tab`, pode ser recarregada e respeita Voltar/Avançar do navegador. Os controles comuns usam a mesma seleção em Relatórios, Coletas, Histórico (Meta) e Diagnóstico.

1. Conexão: nome, credenciais, validade UTC, retenção e usuários pelo nome. Abertura lê conexões locais; os nomes de usuários têm estado próprio de carregamento. Identificador interno é automático.
2. Ativos: escolha uma conexão. Carregue nomes selecionados e/ou ativos disponíveis por canal; use carregar mais quando indicado. Novos resultados não são marcados automaticamente. Marque e salve. LinkedIn: salve contas de formulários antes de descobrir os respectivos formulários; depois marque-os e salve novamente.
3. Relatórios: conexão, canal e conta pelo nome; relatório e campos em português; mídias/publicações/vídeos por seletor, campanhas por caixas. Defina datas quando exigidas. Consultar página não cria coleta. Próxima página preserva a seleção original. Stories são capturados em conjunto conforme o relatório existente. Zero é valor; ausência, recusa e múltiplos buckets continuam distintos.
4. Coletas: criar, avançar, pausar, retomar, cancelar e baixar CSV/JSON. Use nomes nas agendas e horário UTC. O cron decide a execução efetiva. Editar nome/intervalo não altera a consulta armazenada; Nova agenda usa a seleção atual.
5. Formulários e concessões: escolha consumidor e conexão, marque formulários autorizados e permissões. Nenhum editor JSON é necessário. Reconfirme concessões após alterar a conexão. O diário lista operações administrativas próprias; operações de consumidores são controladas pelo SDK do consumidor.
6. Diagnóstico: autoteste local, estado, validação do ativo e versão avançada da API por conexão.
7. Ajuda: índice e leitura completa da documentação instalada, sem depender do transporte MCP.

Credenciais existentes não são preenchidas no navegador. Erros não apagam seleções. Quando a origem não informa um nome, a identificação fica visível apenas como referência de um item já selecionado; não é preciso digitá-la. Nomes podem repetir e não substituem as identidades internas. As áreas técnicas de diagnóstico preservam códigos do fornecedor para investigação.

## Nova aba e renovação

Anúncios e publicações: escolha conexão, conta/Página selecionada, recurso e ação. Carregar objetos percorre listas; Ler objeto e revisão preenche valores atuais. Edite campos em português, busque nomes de segmentação e revise a prévia. Confirmar e executar é habilitado somente após prévia válida. Alterar campos invalida a confirmação. Em caso de incerteza, copie a identificação da operação no próprio painel e use Consultar/Reconciliar, sem nova criação. Valores técnicos de códigos/IDs são evidências de suporte; não há editor de JSON.

Em Conexão, o bloco Autorização pelo LinkedIn e renovação contém escopos em palavras, autorização, inspeção, renovação manual e validade. O retorno mostra confirmação/erro. Avisos e incidentes também aparecem no status; o cron envia somente para admin_email configurado.


## Atualização 0.10.0 — pedido 13

Consulte RELEASE-0.10.0.md e CREDENTIALS.md: candidata conferida antes de persistir, identidade guiada, nomes com origem explícita e agendas rebaseadas no mesmo salvamento. A configuração recebe revisão a cada gravação; authorization_revision e credential_generation distinguem autorização e credencial. Uma alteração benigna mantém o vínculo das identidades de serviço CAPI já emitidas; uma nova concessão ou identidade continua revogando o vínculo anterior. Não editar documentos recebidos de outros pacotes para responder a pedidos.


## Retenção e histórico na 0.11.0

Consulte HISTORY.md: auditoria local configurável com padrão unlimited; conexões existentes preservam a política finita; o acervo diário independe da retenção dos resultados. Nove operações novas, total 90. A consulta local mantém as permissões e a partição da identidade/concessão de origem. A coleta retroativa usa janelas publicadas e não garante integralidade remota. Não alterar documentos de outros pacotes ao entregar esta versão.

## Etapas comerciais na 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.35.0 passou a admitir esse consumidor; a integração foi repetida com MCP 0.36.0 e recibo central recorded. Em MCP 0.34.0 a limitação histórica permanece. Não repetir evento por falta de recibo central. Atualização direta corrente: 0.12.0 → 0.13.0. Veja RELEASE-0.13.0.md para os avisos de credenciais.

## Credenciais na 0.13.0

Pedido MCP LinkedIn 15: espaços externos aparados com aviso; espaços internos e heurísticas de formato são avisos por campo, com decisão remota. Controles, limites máximos, escopos, identidade, CAS e confirmação permanecem. Leia CREDENTIALS.md e RELEASE-0.13.0.md. Sucesso/prévia retornam data.warnings; erros de validação remota retornam details.warnings. Nenhum segredo aparece no aviso.
