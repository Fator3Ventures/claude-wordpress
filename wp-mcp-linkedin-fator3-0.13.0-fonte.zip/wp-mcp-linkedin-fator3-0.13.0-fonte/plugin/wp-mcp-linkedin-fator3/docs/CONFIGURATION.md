# Configuração LinkedIn — 0.13.0

Na aba Conexão, cadastre Access Token, Client ID e Primary Client Secret. Use “membro · aplicativo” como nome. Em Ativos, selecione Páginas, contas de Anúncios e contas de Formulários separadamente, pelos nomes. A versão mensal da API (padrão 202609) fica em Diagnóstico > configuração avançada. IDs continuam sendo strings nos contratos. Lead Sync aceita somente SPONSORED e requer formulários explicitamente selecionados por conta. `r_ads`/`rw_ads` não implicam acesso a respostas: Lead Sync precisa do produto e permissão específicos do LinkedIn.

Tokens e client_secret são cifrados. Secret é usado para challenge/notificação; token para consultas e assinaturas. Configure client_id/application_id para rastreabilidade da transição; valores configurados não comprovam remotamente a titularidade do aplicativo. Token vazio mantém o atual. Toda gravação incrementa a revisão de configuração; mudanças da mesma identidade rebaseiam agendas e concessões vigentes. Troca de identidade exige simulação e reconfirmação explícita. Mudança de seleção exige reconfirmar concessões.

Registrar consumidor não autoriza acesso. Administrador concede permissões metadata, responses, verify e/ou subscriptions, formulários selecionados e callback HTTPS do próprio site. Formulários vazios não concedem acesso. Releia get-connection/get-grant; list-grants é paginada e retorna next_offset. O SDK concedido funciona com usuário zero e não exige sessão humana.

A versão não muda o seletor de provedor do Core. Preserve credencial e concessão antigas até concluir drenagem do diário de assinaturas. Não substitua aliases ou remova registros como tentativa de resolver timeout.

A seleção dos usuários WordPress usa nomes e busca paginada. Não concede `manage_options`. Token/chave vazios mantêm os valores cifrados. Marcar remover é uma alteração explícita. A gravação da aba Conexão não envia ativos/formulários: os mantém. Descoberta não marca novos ativos. Na falha da origem, a seleção anterior continua disponível, identificada como nome indisponível quando necessário. Salvar seleção usa a revisão capturada ao abrir Ativos; conflito exige reabrir e revisar.

## Complementos da 0.5.0

Consulte CREDENTIALS.md para refresh e autorização pelo navegador. Para as novas escritas, ID e segredo do app são obrigatórios para introspecção. Renovação automática aumenta somente credential_generation, sem alterar revisão/concessões. Na 0.10.0, a gravação manual distingue identidade, autorização e geração; veja CREDENTIALS.md.

## Auditoria de serviço
Nenhuma credencial, campo ou concessão nova na 0.7.0. A concessão CAPI existente continua explícita. status/capabilities mostram service_audit; no MCP 0.27.0 a parte central é indisponível. Instalar a atualização não reconfirma grants nem reemite diários.


## Retenção e histórico na 0.11.0

Consulte HISTORY.md: auditoria local configurável com padrão unlimited; conexões existentes preservam a política finita; o acervo diário independe da retenção dos resultados. Nove operações novas, total 90. A consulta local mantém as permissões e a partição da identidade/concessão de origem. A coleta retroativa usa janelas publicadas e não garante integralidade remota. Não alterar documentos de outros pacotes ao entregar esta versão.

## Etapas comerciais na 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.35.0 passou a admitir esse consumidor; a integração foi repetida com MCP 0.36.0 e recibo central recorded. Em MCP 0.34.0 a limitação histórica permanece. Não repetir evento por falta de recibo central. Atualização direta corrente: 0.12.0 → 0.13.0. Veja RELEASE-0.13.0.md para os avisos de credenciais.

## Credenciais na 0.13.0

Pedido MCP LinkedIn 15: espaços externos aparados com aviso; espaços internos e heurísticas de formato são avisos por campo, com decisão remota. Controles, limites máximos, escopos, identidade, CAS e confirmação permanecem. Leia CREDENTIALS.md e RELEASE-0.13.0.md. Sucesso/prévia retornam data.warnings; erros de validação remota retornam details.warnings. Nenhum segredo aparece no aviso.
