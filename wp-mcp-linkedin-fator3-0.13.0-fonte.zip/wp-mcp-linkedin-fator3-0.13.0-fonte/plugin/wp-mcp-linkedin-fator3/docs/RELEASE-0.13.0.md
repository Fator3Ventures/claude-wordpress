# Fator3 MCP LinkedIn 0.13.0 — credenciais com avisos

Pedido MCP LinkedIn 15 e regra do dono de 28/10/2026. Base direta 0.12.0; WordPress 6.4 e PHP 8.1.2 de 64 bits preservados. 93 operações, sem remoção ou mudança nos schemas de entrada.

Espaços nas pontas das credenciais são aparados com aviso; os internos são preservados para a conferência no LinkedIn. Heurísticas locais de tamanho usual, alfabeto ou semelhança com outra credencial também geram aviso. A base tinha validadores adicionais em ConnectionChanges além do trecho indicado no pedido; foram tratados no fluxo completo.

`save-connection` retorna `warnings` com campo, código e mensagem no objeto data; em recusa posterior, no objeto details. A tela mostra os avisos junto dos campos em sucesso, prévia e erro remoto. Sem valor ou fragmento de segredo. Controles Unicode, inclusive quebras e tabulações, são recusados antes da normalização; limites máximos e entradas somente com espaços permanecem recusados. Consulte CREDENTIALS.md para códigos e semântica de campo vazio/remoção.

Introspecção, aplicativo, escopos, validade, identidade, CAS, confirmação guiada e transação permanecem obrigatórios. Recusa remota conserva a credencial salva e seus vínculos. Nenhuma conexão ou concessão é criada na atualização. Refresh manual não se torna verificado pela introspecção do Access Token.

Matriz considerada: Core 1.60.0, MCP 0.36.0, Google 0.22.0, Meta 0.14.0 e Pipedrive 0.3.0. A auditoria comercial que estava pendente contra MCP 0.34.0 foi atendida no MCP 0.35.0 e comprovada com a 0.36.0. Contratos de aquisição e etapas permanecem intactos. Não repetir conversão por falha de auditoria central.

Testes com WordPress real e fornecedor sintético cobrem normalização, recusa remota, segurança, permissões, preservação, concorrência, interface e integração. A gravação com token real válido exige o dono da conta; o Site-Teste não tinha conexão configurada no início. Relatório externo distingue as provas finais e suas limitações.

Nenhuma migração de banco ou alteração de retenção. Para rollback, preserve banco/salts/diários e use o instalador íntegro 0.12.0, ciente de que as recusas locais antigas retornam para entradas futuras. Código e documentos de acompanhantes não são modificados por esta entrega.
