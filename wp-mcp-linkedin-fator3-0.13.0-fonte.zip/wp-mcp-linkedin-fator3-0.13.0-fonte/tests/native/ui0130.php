<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
$lab=getenv('F3_LAB_ROOT');$source=getenv('F3_SOURCE_ROOT');$mu=ABSPATH.'wp-content/mu-plugins';wp_mkdir_p($mu);copy(__DIR__.'/ui-fixtures.php',$mu.'/ui-fixtures.php');
$socket=stream_socket_server('tcp://127.0.0.1:0',$errno,$error);if(!$socket)throw new RuntimeException($error);$address=stream_socket_get_name($socket,false);fclose($socket);
$origin='http://'.$address;$password=bin2hex(random_bytes(24));putenv('F3_UI_URL='.$origin);putenv('F3_UI_PASSWORD='.$password);
$cmd=json_decode(getenv('F3_LAB_PHP'),true);$run=static function($argv){$p=proc_open($argv,[0=>['pipe','r'],1=>STDOUT,2=>STDERR],$pipes);fclose($pipes[0]);return proc_close($p);};
if($run(array_merge($cmd,[__DIR__.'/ui-init.php']))!==0)exit(1);
$server=proc_open(array_merge($cmd,['-S',$address,'-t',ABSPATH,__DIR__.'/router.php']),[0=>['pipe','r'],1=>['file',$lab.'/private/ui-server.log','a'],2=>['file',$lab.'/private/ui-server.log','a']],$pipes);fclose($pipes[0]);
try{for($n=0;$n<100;$n++){if(@fsockopen('127.0.0.1',(int)substr(strrchr($address,':'),1),$e,$m,.1))break;usleep(50000);}$code=$run([getenv('CODEX_PRIMARY_RUNTIME_NODE'),__DIR__.'/ui0130.cjs']);}finally{proc_terminate($server);proc_close($server);unlink($mu.'/ui-fixtures.php');}
exit($code);
