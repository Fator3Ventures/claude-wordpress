<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';require_once __DIR__.'/lab-helpers.php';wp_set_current_user(1);
use Fator3\McpFiles as M;use Fator3\LinkedIn as L;
$grant='credentials15_'.bin2hex(random_bytes(8));$checks=[];$reject=false;$calls=0;
M\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>1,'client_id'=>'credentials15','profile'=>'maintenance','status'=>'active']);M\ConnectionContext::oauth(['user_id'=>1,'grant_id'=>$grant,'client_id'=>'credentials15','profile'=>'maintenance']);
add_filter('pre_http_request',static function($pre,$a,$url)use(&$reject,&$calls){$calls++;if(!str_ends_with($url,'introspectToken'))return new WP_Error('blocked');parse_str($a['body'],$body);$data=['active'=>true,'client_id'=>$body['client_id'],'expires_at'=>time()+10000,'scope'=>implode(',',L\ConnectionChanges::READ_SCOPES)];return ['headers'=>[],'body'=>wp_json_encode($data),'response'=>['code'=>$reject?401:200,'message'=>'fixture'],'cookies'=>[]];},-100,3);
function mt15($name,$passed){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$passed];if(!$passed)throw new RuntimeException($name);}
function mx15($i){return \WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::execute(['ability_name'=>'linkedin/save-connection','parameters'=>$i]);}
try {
 $i=['connection_id'=>'mcp15','expected_revision'=>0,'token'=>' unusual credential15 ','client_id'=>'fixtureApp15','client_secret'=>'secret15'];$r=mx15($i);$data=$r['data']['data']??[];mt15('MCP persists normalized candidate after remote validation',!empty($r['success'])&&!empty($r['data']['success'])&&($data['persisted']??false)&&L\Connections::get('mcp15')['token']==='unusual credential15');
 mt15('MCP preserves advisory field, code and message',count($data['warnings']??[])===3&&($data['warnings'][0]['field']??'')==='token'&&($data['warnings'][0]['code']??'')==='credential_spaces_trimmed');
 $before=L\Store::get('connection','mcp15');$reject=true;$n=$calls;$r=mx15(['connection_id'=>'mcp15','expected_revision'=>$before['revision'],'token'=>' rejected credential15 ']);mt15('MCP remote rejection preserves saved record and advisory',empty($r['data']['success'])&&count($r['data']['details']['warnings']??[])===3&&L\Store::get('connection','mcp15')===$before&&$calls>$n);
 mt15('MCP output contains no submitted secret',!str_contains(wp_json_encode($r),'rejected credential15')&&!str_contains(wp_json_encode($data),'unusual credential15')&&!str_contains(wp_json_encode($data),'secret15'));
 $n=$calls;M\Persistence::delete('oauth-grants',$grant);$r=mx15($i);mt15('revoked transport denies before validation',empty($r['success'])&&$calls===$n);
}finally{M\Persistence::delete('connections','grant:'.$grant);M\Persistence::delete('oauth-grants',$grant);M\ConnectionContext::restore_identity(null,1);}
$out=['transport'=>'MCP '.lab_companion('wp-mcp-fator3/wp-mcp-fator3.php').' original executor, synthetic supplier','total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'checks'=>$checks];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/mcp-request015.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out)."\n";exit($out['failed']?1:0);
