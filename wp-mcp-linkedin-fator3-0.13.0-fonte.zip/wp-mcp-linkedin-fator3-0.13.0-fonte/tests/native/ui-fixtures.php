<?php
// Installed only in disposable laboratories, never in a delivered plugin.
add_action('f3_linkedin_register_consumers',static function($api){$api::register_consumer(['id'=>'ui-consumer','label'=>'Consumidor de demonstração','contract'=>'linkedin-lead-reader/1.1.0']);});
add_filter('pre_http_request',static function($pre,$args,$url){if($pre!==false)return $pre;if(str_contains($url,'api.wordpress.org'))return ['headers'=>[],'body'=>wp_json_encode(['offers'=>[],'plugins'=>[],'themes'=>[],'translations'=>[],'no_update'=>[]]),'response'=>['code'=>200,'message'=>'Fixture'],'cookies'=>[]];$path=parse_url($url,PHP_URL_PATH);parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);$body=null;
 if(str_contains($url,'graph.facebook.com')){
  if(str_ends_with($path,'/me/accounts'))$body=['data'=>[['id'=>'900','name'=>'Página de demonstração','instagram_business_account'=>['id'=>'111','username'=>'demonstracao','name'=>'Perfil de demonstração']],['id'=>'901','name'=>'Página adicional','instagram_business_account'=>['id'=>'112','name'=>'Perfil adicional']]]];
  elseif(($q['fields']??'')==='id,access_token')$body=['id'=>'900','access_token'=>'synthetic-page-ui'];
  elseif(str_ends_with($path,'/media'))$body=['data'=>[['id'=>'444','caption'=>'Conteúdo de demonstração','timestamp'=>'2026-10-12T12:00:00+0000','media_type'=>'IMAGE']]];
  elseif(str_ends_with($path,'/posts'))$body=['data'=>[['id'=>'900_444','message'=>'Publicação de demonstração','created_time'=>'2026-10-12T12:00:00+0000']]];
  elseif(str_ends_with($path,'/videos'))$body=['data'=>[['id'=>'445','title'=>'Vídeo de demonstração','created_time'=>'2026-10-12T12:00:00+0000']]];
  elseif(str_ends_with($path,'/insights')){$body=['data'=>[]];foreach(explode(',',$q['metric']) as $metric)$body['data'][]=['name'=>$metric,'period'=>'day','total_value'=>['value'=>7]];}
  else{$id=basename($path);$body=['id'=>$id,'name'=>$id==='900'?'Página de demonstração':'Perfil de demonstração','owner'=>['id'=>'111'],'from'=>['id'=>'900']];}
 }elseif(str_contains($url,'api.linkedin.com')){
  if(str_ends_with($path,'/organizationAcls'))$body=['elements'=>[['organization'=>'urn:li:organization:111','role'=>'ADMINISTRATOR','state'=>'APPROVED']],'paging'=>['start'=>0,'total'=>1]];
  elseif(str_ends_with($path,'/adAccountUsers'))$body=['elements'=>[['account'=>'urn:li:sponsoredAccount:222','role'=>'ACCOUNT_MANAGER']],'paging'=>['start'=>0,'total'=>1]];
  elseif(str_ends_with($path,'/organizations/111'))$body=['id'=>'111','localizedName'=>'Organização de demonstração'];
  elseif(str_ends_with($path,'/adAccounts/222'))$body=['id'=>'222','name'=>'Conta de anúncios de demonstração','currency'=>'BRL'];
  elseif(str_ends_with($path,'/adCampaigns'))$body=['elements'=>[['id'=>'555','name'=>'Campanha de demonstração','account'=>'urn:li:sponsoredAccount:222']],'metadata'=>[]];
  elseif(str_ends_with($path,'/leadForms'))$body=['elements'=>[['id'=>'333','name'=>'Formulário de demonstração','versionId'=>1,'owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:222']]],'paging'=>['start'=>0,'total'=>1]];
  elseif(str_ends_with($path,'/organizationPageStatistics')){preg_match('/start:(\d+)/',$q['timeIntervals'],$m);$t=(int)$m[1]+1;$body=['elements'=>[['organization'=>'urn:li:organization:111','timeRange'=>['start'=>$t,'end'=>$t+86400000],'totalPageStatistics'=>['views'=>['allPageViews'=>['pageViews'=>42]]]]],'paging'=>['start'=>0,'count'=>10]];}
  elseif(str_ends_with($path,'/adAnalytics'))$body=['elements'=>[['impressions'=>100,'clicks'=>5,'dateRange'=>['start'=>['year'=>2026,'month'=>10,'day'=>12],'end'=>['year'=>2026,'month'=>10,'day'=>18]],'pivotValues'=>['urn:li:sponsoredAccount:222']]]];
 }
 if($body===null)return $pre;return ['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>200,'message'=>'Controlled fixture'],'cookies'=>[]];
},100,3);

add_filter('pre_http_request',static function($pre,$args,$url){
 if($pre!==false)return $pre;$path=parse_url($url,PHP_URL_PATH);$method=$args['method']??'GET';$body=null;$status=200;$headers=[];
 if(str_ends_with($path,'/userinfo'))$body=['sub'=>str_contains($args['headers']['Authorization'],'ui-member-B')?'uiB':'uiA','name'=>str_contains($args['headers']['Authorization'],'ui-member-B')?'Membro UI B':'Membro UI A'];
 if(str_ends_with($path,'/introspectToken')){parse_str($args['body'],$candidate);if(($candidate['token']??'')==='synthetic-ui-secret')return ['headers'=>[],'body'=>'{}','response'=>['code'=>401,'message'=>'Fixture rejection'],'cookies'=>[]];}
 if(str_ends_with($path,'/introspectToken'))$body=['active'=>true,'client_id'=>'uiapp','scope'=>'r_ads,r_ads_reporting,r_organization_admin,rw_ads,r_organization_social,w_organization_social,rw_conversions,openid,profile','expires_at'=>time()+10000];
 if(str_contains($url,'api.linkedin.com')&&str_contains($path,'/adCampaignGroups')){
  $objects=get_option('f3_ui_groups',[]);
  if($method==='POST'){$v=json_decode($args['body'],true);$id='9001';$objects[$id]=$v+['id'=>$id];update_option('f3_ui_groups',$objects,false);$body=[];$status=201;$headers=['x-restli-id'=>$id];}
  elseif(basename($path)==='adCampaignGroups')$body=['elements'=>array_values($objects),'metadata'=>[]];
  elseif(isset($objects[basename($path)]))$body=$objects[basename($path)];else{$body=[];$status=404;}
 }
 if($body===null)return $pre;return ['headers'=>$headers,'body'=>wp_json_encode($body),'response'=>['code'=>$status,'message'=>'Controlled UI fixture'],'cookies'=>[]];
},50,3);

add_filter('pre_http_request',static function($pre,$args,$url){$path=parse_url($url,PHP_URL_PATH);if(!str_contains($path,'/conversions'))return $pre;$rule=['id'=>67890,'account'=>'urn:li:sponsoredAccount:222','name'=>'Contato de demonstração','conversionMethod'=>'CONVERSIONS_API','enabled'=>true];$body=str_ends_with($path,'/conversions')?['elements'=>[$rule],'paging'=>['start'=>0,'total'=>1]]:$rule;return ['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>200,'message'=>'Controlled fixture'],'cookies'=>[]];},20,3);

add_filter('pre_http_request',static fn($pre)=>$pre===false?new WP_Error('ui_external_blocked'): $pre,9999);
