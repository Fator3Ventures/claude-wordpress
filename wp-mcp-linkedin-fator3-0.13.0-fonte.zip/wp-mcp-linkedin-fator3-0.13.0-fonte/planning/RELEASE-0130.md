# Plano — Fator3 MCP LinkedIn 0.13.0

29/10/2026. Base aceita 0.12.0: instalador 304948 bytes, SHA-256 19748e788190f371809db469a6de052a645e25f39fad1672606dc776234ec54c. Alvo previsto 0.13.0; instalador ainda não fechado. Pedido MCP LinkedIn 15 e regra do dono de 28/10/2026, preservada no documento Core recebido. Normas comuns revisão 5 da base prevalecem sobre os avulsos revisão 4.

Escopo: aparar espaços externos com aviso, preservar espaços internos para o fornecedor e converter heurísticas de credencial em avisos. O documento do pedido afirma não haver outros validadores, mas ConnectionChanges::formats também recusa tokens curtos, Client ID numérico/não alfanumérico e credenciais cruzadas. Aplicar a regra do dono ao fluxo completo, preservando limites, controles, campos obrigatórios, CAS, identidade, escopos e atomicidade. Application ID é identificador de ativo, mantém validação própria.

Avisos por campo/código/motivo nas respostas e junto dos campos na tela, inclusive quando o fornecedor recusa. Nenhum valor, fragmento ou hash de credencial no aviso. Campo de senha vazio continua preservando a salva; somente espaços é entrada inválida. Refresh manual não passa a ser considerado remotamente verificado só pela introspecção do Access Token.

Matriz recebida: Core 1.60.0, MCP 0.36.0, Meta 0.14.0; Google 0.22.0 e Pipedrive 0.3.0 indicados pelos relatórios. Apenas LinkedIn será modificado/instalado. Validar instalação limpa, upgrade direto, mínimos, regressão de credenciais/agendas/grants/histórico, DOM/REST, executor e documentação MCP. Comparar bytes dos acompanhantes.

Impactos: nenhuma adaptação nova de contrato exigida aos acompanhantes; warnings é campo aditivo dentro do envelope já aberto. O impacto histórico LinkedIn 0.12 → MCP foi informado como atendido em 0.35; repetir a prova com MCP 0.36 e registrar resultado no relatório principal, sem reemitir impacto de encerramento. Se aparecer consequência técnica nova, emitir encaminhamento antes de implementar a parte afetada.

Aceite remoto: usar somente abilities existentes e o instalador LinkedIn. Site-Teste está sem conexão; não há credencial real fornecida para provar gravação válida após introspecção. Executar preflight de candidato sintético recusado pelo fornecedor e registrar o limite; não criar helper remoto ou contornar a introspecção. Sucesso com fornecedor simulado será provado em WordPress local descartável. Homologação com token real permanece com dono/frota.

Entrega: fonte, instalador, relatório em português; impacto adicional somente se houver solicitação substantiva. Fechar instalador após testes, instalar no Site-Teste, ler documentação integral, fechar fonte uma única vez e preencher sua identidade no relatório externo. Nenhum push/frota, envio comercial ou alteração de documento alheio.

## Fechamento da implementação — 29/10/2026

Instalador 0.13.0 fechado e instalado no Site-Teste: 314596 bytes, SHA-256 `1c45738322f4901aeacdc36615789ae961e8b9d521ba321a27de0aea76c13502`. As quatro matrizes finais somam 1256 verificações funcionais aprovadas, oito não aplicáveis e zero falhas; além de 66 documentais locais e 30 DOM. Nove autotestes remotos aprovados; 32 documentos instalados lidos por inteiro, em 34 páginas, todos idênticos ao instalador. O preflight real de token sintético alcançou o fornecedor e recebeu HTTP 400 com aviso de espaço aparado, sem criar conexão. Aceite com token real válido continua com dono/frota.

Nenhum encaminhamento técnico novo. Impacto 0.12 → MCP, revisão 1, atendido na combinação original Core 1.60.0/MCP 0.36.0, conforme prova própria de recibo central comercial e aquisição preservada. Encerramento registrado no relatório principal; impacto histórico não reemitido. Runtime instalado não pode ser alterado silenciosamente. Próximo passo administrativo: fechar fonte e entregar os três artefatos identificados no relatório.
