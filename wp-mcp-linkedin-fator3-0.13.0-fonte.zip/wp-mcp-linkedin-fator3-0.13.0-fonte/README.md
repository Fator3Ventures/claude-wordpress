# Fator3 MCP LinkedIn 0.13.0 — fonte da entrega

Implementação de **Pedidos MCP LinkedIn 15**, sobre a base aceita 0.12.0. Espaços externos em credenciais manuais são aparados com aviso; espaços internos e outras heurísticas geram avisos e deixam a validação remota decidir. Controles, tipos inválidos, limites, obrigatoriedade, autorização e persistência atômica continuam protegidos.

Leia `wp-mcp-linkedin-fator3-0.13.0-relatorio.md` para a matriz de provas, convivência e pendências. A versão foi instalada no Site-Teste. A gravação de token real válido com espaço final permanece pendente do dono da conta: a prova local usa fornecedor sintético e a prova remota usa candidato sintético recusado pelo LinkedIn.

## Organização

- `plugin/wp-mcp-linkedin-fator3/`: runtime idêntico ao instalador testado e instalado.
- `build/`: fontes autorais, documentação e gerador; somente o LinkedIn é gerado nesta entrega.
- `tests/native/`: testes em WordPress/MySQL reais, com HTTP do fornecedor simulado; `request015.php`, `mcp-request015.php`, `upgrade0130.php` e `ui0130.*` cobrem esta rodada.
- `tools/lab.py` e `tools/lab-release0130.example.json`: laboratório descartável com dependências externas identificadas por SHA-256.
- `evidence/release0130/`: resultados finais, comparação de contratos, preservação dos acompanhantes, documentação MCP e recibos do Site-Teste.
- `inputs/0.13.0/`: pedidos, normas revisão 5, relatórios recebidos e identidades dos pacotes originais, sem modificá-los.
- `planning/RELEASE-0130.md`: escopo e análise de impactos desde o planejamento.
- `history/received-0.12.0/`: relatório, README e impacto da base, preservados como histórico. Demais diretórios de versões anteriores também são históricos.

## Reprodução

O instalador requer WordPress 6.4+, PHP 8.1.2+ de 64 bits, criptografia autenticada e banco com travas nomeadas. Foram executados WordPress 6.4/PHP 8.1.2 e WordPress 7.1.3/PHP 8.3.6, com MySQL 8.0.46. O laboratório integrado usa Core 1.60.0, MCP 0.36.0, Google 0.22.0 e Meta 0.14.0 originais. Pipedrive 0.3.0 fica inativo no laboratório PHP 8.3.6 por exigir 8.3.36; sua presença ativa no Site-Teste não equivale a homologação funcional.

Execute `python3 build/build.py` com PHP disponível no PATH ou em `F3_SOCIAL_PHP`. A saída é `build/dist/wp-mcp-linkedin-fator3-0.13.0-instalador.zip`; SHA-256 esperado: `1c45738322f4901aeacdc36615789ae961e8b9d521ba321a27de0aea76c13502` (314596 bytes). `build/dist` não integra este ZIP fonte.

Para os testes, copie o manifesto exemplo para um arquivo local e ajuste caminhos, MySQL e a variável de senha em ambiente descartável. As dependências WordPress/PHP/instaladores acompanhantes e jsdom 27.4.0 são externas, não incluídas. Não aponte para o banco compartilhado de produção. O runner cria schema próprio e usa diretório novo por execução. O teste DOM requer Node e `F3_JSDOM` apontando para o módulo jsdom.

```bash
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li013-clean --order linkedin-integrated --tests suite.php,request012.php,request013.php,request014.php,mcp-history011.php,request015.php,stages012.php,mcp-stages012.php,mcp-request015.php,mcp-docs080.php,ui0130.php
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li013-upgrade --order linkedin-integrated --origin upgrade --tests upgrade0130.php,suite.php,request012.php,request013.php,request014.php,mcp-history011.php,request015.php,stages012.php,mcp-stages012.php,mcp-request015.php,mcp-docs080.php
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li013-min --order linkedin-only --wordpress wordpress_minimum --php php81 --tests suite.php,request012.php,request013.php,request014.php,request015.php,stages012.php
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li013-isolated --order linkedin-only --tests suite.php,request012.php,request013.php,request014.php,request015.php,stages012.php
```

As quatro matrizes somam 1256 verificações funcionais aprovadas, oito não aplicáveis e zero falhas; adicionalmente, 66 verificações documentais locais e 30 de DOM. São execuções entre ambientes, não 1256 requisitos distintos. O rótulo literal antigo `MCP 0.33.0` em `mcp-history011.json` é metadado histórico do teste; os manifests e a comparação de bytes comprovam o executor original 0.36.0 efetivamente usado. A prova de atualização válida nesta rodada é `upgrade0130.json`, não a antiga fixture 0.10.1 de `request014.php`.

`tools/package-source.py --output-dir /diretorio/externo` compara `plugin/` com o instalador e fecha um fonte com raiz versionada, sem ZIP aninhado. Recusa sobrescrever fonte já fechado. A cópia interna do relatório antecede o fechamento; a identidade final do fonte consta no relatório externo canônico. Não modifique o runtime 0.13.0 já instalado sem criar nova versão.
