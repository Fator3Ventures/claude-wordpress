"""Close a prepared source tree once, with deterministic archive metadata.

Requires build/dist/<slug>-<version>-instalador.zip (the tested installer, kept outside the source ZIP) and checks that
plugin/<slug>/ is byte-identical to it before closing. Refuses nested ZIPs and overwriting a closed source.
"""
from pathlib import Path
import argparse, zipfile, hashlib, json, re
root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(); parser.add_argument('--output-dir', required=True, type=Path); args = parser.parse_args()
output = args.output_dir.resolve()
if output == root or root in output.parents:
    raise SystemExit('Output must be outside source tree')
version = re.search(r"^VERSION='([0-9]+\.[0-9]+\.[0-9]+)'", (root / 'build/build.py').read_text(), re.M).group(1)
if not root.name.endswith('-' + version + '-fonte'):
    raise SystemExit('Use the release source root')
slug = root.name.removesuffix('-' + version + '-fonte')
report = slug + '-' + version + '-relatorio.md'
required = ['plugin/' + slug + '/manifest.sha256.json', 'build/build.py', 'tests/native/suite.php', report]
for item in required:
    if not (root / item).is_file():
        raise SystemExit('Missing ' + item)
installer = root / 'build/dist' / (slug + '-' + version + '-instalador.zip')
with zipfile.ZipFile(installer) as z:
    shipped = {n: hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
tree = {('' + slug + '/' + p.relative_to(root / 'plugin' / slug).as_posix()): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'plugin' / slug).rglob('*') if p.is_file()}
if shipped != tree:
    raise SystemExit('plugin/' + slug + ' differs from the tested installer')
allowed = {'plugin', 'build', 'tests', 'tools', 'evidence', 'planning', 'inputs', 'impacts', 'history', 'README.md', report}
files = [p for p in sorted(root.rglob('*')) if p.is_file() and p.relative_to(root).parts[0] in allowed and '__pycache__' not in p.parts and 'node_modules' not in p.parts and not p.is_relative_to(root / 'build/dist')]
if any(p.suffix.lower() == '.zip' for p in files):
    raise SystemExit('Nested ZIP prohibited')
output.mkdir(parents=True, exist_ok=True); target = output / (root.name + '.zip')
if target.exists():
    raise SystemExit('Refusing to overwrite a closed source')
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        info = zipfile.ZipInfo(root.name + '/' + p.relative_to(root).as_posix(), date_time=(2026, 10, 29, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED; info.create_system = 3
        info.external_attr = (0o100755 if p.suffix in ('.sh',) else 0o100644) << 16
        z.writestr(info, p.read_bytes(), compresslevel=9)
print(json.dumps({'file': target.name, 'bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'files': len(files), 'runtime_equals_installer': True}))
