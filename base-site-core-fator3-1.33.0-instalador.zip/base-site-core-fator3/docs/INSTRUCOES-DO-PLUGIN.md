# Instruções do Core

Leia [AGENTES-1.33.0.md](AGENTES-1.33.0.md) e [DOCUMENTACAO.md](DOCUMENTACAO.md). Schemas gerados e diagnóstico instalado descrevem o contrato atual; relatórios de versões anteriores não são instruções operacionais desta versão.
