# Guia de agentes — Core 1.33.0

Comece por DOCUMENTACAO.md e pelo schema da ability instalada. Contrato Core 7.1.0; provider `base-site-core-fator3`. Não inferir permissão pelo número da versão do plugin acompanhante. A matriz local exercitada foi MCP 0.21.1 / Google 0.8.5; pacotes futuros exigem sua própria matriz.

## Visitas e testes

Ative `/f3base-teste/` antes de navegar para testar; cookie válido por um ano. Alternativa: `X-F3Base-Teste: 1` em todas as requisições ao site, inclusive fetch e beacon. Não envie a marca a fornecedores externos. `/f3base-teste/?sair=1` afeta as próximas navegações; eventos da página anterior preservam a classificação original. Destinos externos de teste são suprimidos por padrão, salvo política de homologação configurada.

Ler uma integração pelo MCP não transforma leads reais consultados em testes. No LinkedIn, `testLead` remoto é a evidência da classe; não use IP ou identidade do executor. Contatos nativos não possuem sessão web ou jornada inventada.

## Credenciais e efeitos

Peça ao dono para inserir segredos nos campos de senha do wp-admin. Campo vazio mantém o valor; exclusão é explícita. Diagnóstico e abertura da tela não consultam fornecedores. Verificação remota é uma ação separada, contabilizada quando despachada. Nunca copie credenciais para mensagens, relatórios ou argumentos de abilities que não as aceitam.

Slack: operar somente IDs locais registrados. Correção/apagamento exige instrução do dono, revisão e chave da operação. `chat.delete` aceito não basta; ausência posterior é a prova. Resultado incerto exige releitura antes de repetir. Presença de mensagem nunca comprova leitura humana.

LinkedIn: `anuncios-linkedin-acesso-verificar` confere token e formulário sem ler contatos. Para efeito remoto use `simular: false`. `anuncios-linkedin-webhook-configurar` recebe `acao`, `revisao`, `chave_operacao`; por padrão simula. Não expõe segredos. Em timeout de criação, reconciliar antes de ativar novamente. Não editar assinaturas de outro site.

Pipedrive: observar separadamente os três orçamentos e pausa remota. Não aumentar cota automaticamente para ocultar falha. Mapa de canal/parceiro/campanha é próprio de cada site; IDs e campos devem vir do catálogo da conta, nunca de exemplos de outro cliente.

## Leitura de dados

`dados.comunicacao_envio` conserva snapshot cifrado da apresentação comum; use `lead-jornada-ler`, visão aviso, com permissão de leads. Origem comercial pode diferir do primeiro toque analítico, com procedência explícita. Não some campanhas como se fossem contatos distintos. `li_fat_id` não identifica automaticamente campanha ou anúncio.

Leia DICIONARIO-DADOS.md e os schemas em docs/dados/. Datas Unix são UTC, `submittedAt` LinkedIn usa milissegundos e IDs são strings. Acesso IA demonstra leitura observada, e referrer demonstra visita recebida; nenhum deles comprova recomendação ou citação pela IA.

## Recuperação

MCP, Google e Core mantêm guardas independentes. Preparar/drenar cada participante antes de backup/restore; preservar pasta privada e história. Retomar um não retoma os demais. Reconcilie filas e efeitos incertos antes de reabrir envios. Instalação e saúde não executam conversores históricos nem reparam proveniência antiga. A origem CLI é passagem observada, não inspeção do crontab. Tema e implantação pertencem a outros responsáveis.

## Contexto de medição

Use `f3base/medicao-contexto-ler` e `f3base/medicao-eventos-ler`, ou a fachada PHP pública descrita em MEDICAO-SDK-1.33.md. Não deduza emissão pelo ID salvo. Configurado, permitido, enviado e recebido são provas diferentes. Pagine o catálogo usando a revisão do snapshot desde a primeira página. Nenhuma leitura cria tags, concessões ou recursos Google.

## Instalação desta entrega

Atualização direta 1.31.0 → 1.33.0 ou WordPress novo. Não instalar a 1.32.0 intermediariamente. Em instalação nova pelo MCP 0.21.1, use upload **inativo** e ativação explícita em outra chamada; leia a saúde em uma requisição seguinte. O executor MCP tem correção própria planejada; não se substitui por chamadas a inicializadores privados do Core.

A atualização abre o ciclo da versão alvo em `f3base_instalacao`, arquiva a evidência anterior e confirma etapas e finalização próprias. Não apague opções para forçar atualização. Leia OPERACAO-E-RECUPERACAO.md.

MCP 0.22.0 e Google 0.8.6 ainda dependem de binários finais para homologação conjunta. O alinhamento da bridge `executor-registration/1.0.0` está resolvido nos planos; sua implementação pertence aos acompanhantes. O cliente externo LinkedIn ainda não está liberado: consulte IMPACTO-SOCIAIS-1.33.md.
