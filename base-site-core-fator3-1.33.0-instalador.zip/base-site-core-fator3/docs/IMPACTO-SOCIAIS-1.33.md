# Core 1.33.0 → Meta e LinkedIn

Documento para encaminhamento pelo responsável; não enviado a terceiros.

## Situação CORE-SOC-01

Entregue uma fronteira única `F3Base_Linkedin_Cliente` para as chamadas comerciais do cliente interno e um diagnóstico explícito na tela/ability. Instalação e upgrade preservam o interno, não copiam segredos nem mudam callback. **Não há adoção do provedor externo nesta entrega.** Não foi implementada uma API inventada para LI-04.

Para concluir a escolha e troca retomável, o produtor precisa entregar o SDK `linkedin-lead-reader/1.0.0`: entrypoint PHP, descoberta, descritor/capabilities, schemas e fixtures de acesso efetivo, formulários, respostas, challenge/notificação e gestão de assinaturas. O grant deve vincular consumidor, conexão, conta, formulários e ações. Lista vazia autoriza zero. Leitor deve funcionar em cron sem usuário, sem fingir capability de pessoa.

Fechar também: identidade de app; compatibilidade de cursor/marco; revisão da concessão; reuso de assinatura própria; quem responde ao challenge; validação local de bytes originais sem devolver segredo; estabilidade de callback/contexto ao mudar cliente. Sem isso não é seguro drenar, conciliar e confirmar uma troca. A23–A26 da troca externa e I02 continuam pendentes; testes do cliente interno não os encerram.

## CORE-SOC-02 — roteiro de homologação externa

Com ambiente e destinos autorizados: cadastrar credenciais no painel do dono; provar Lead Sync SPONSORED/conta/formulário; conferir acesso sem ler respostas; ativar assinatura própria; observar GET challenge HTTPS e POST autenticado; confirmar recibo durável antes do ACK; importar submissão `testLead` pela mesma identidade em polling/webhook; conferir um contato e uma intenção; testar repetição e falha transitória; conferir aviso/CRM de homologação e reconciliar a assinatura. Não apagar assinaturas alheias. Registrar IDs técnicos, tempos e hashes sem credenciais ou respostas pessoais.

I03/L07/L14 permanecem abertos até essa execução. Não houve envio real ou implantação na frota nesta entrega.

## Cinco responsáveis

| Dono | Escopo |
|---|---|
| Core | Site, consentimento, audiência local, contatos e entregas comerciais; Pixel/CAPI e Meta Lead Ads atuais; cliente interno LinkedIn |
| MCP | Transporte e permissões administrativas; não é autorização de leitura comercial pelo cron |
| MCP Google | Serviços Google e grant GSC; consumidor do contexto/catálogo Core; relatórios remotos independentes |
| Provedor Meta | Instagram Insights inicial; não recebe propriedade dos pipelines Pixel/CAPI/Lead Ads do Core |
| Provedor LinkedIn | Pages/Ads/Lead Sync pelo SDK futuro; credenciais e grants próprios |

Relatórios locais, recorte editorial GSC e consultas remotas têm universos e cobertura diferentes. Não transferir configurações/permissões, não ler options/segredos privados dos novos provedores e não fabricar visita web para uma submissão nativa. Instalar provedores não inicia uma segunda importação. Sheets comum, Google Ads leads, BigQuery e Porter não são dependências desta entrega.
