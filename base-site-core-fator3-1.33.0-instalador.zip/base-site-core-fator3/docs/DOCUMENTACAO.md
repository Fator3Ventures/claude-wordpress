# Documentação instalada — Core 1.33.0

Caminho: `wp-content/plugins/base-site-core-fator3/docs/`. Use `f3base/documentacao-ler` com `arquivo`, `linha` e `limite` até 200. A resposta informa hash e continuação; exige `manage_options`, inclusive em recuperação. Leia o índice atual antes dos guias temáticos. Nomes de versão nos guias preservados indicam a introdução da funcionalidade, não a versão a instalar.

| Documento | Uso |
|---|---|
| RELEASE-1.33.0.md | Mudanças, implantação e limites desta entrega |
| AGENTES-1.33.0.md | Operação, testes, credenciais e consultas |
| LINKEDIN-LEAD-SYNC.md | Configuração, API, webhook, deduplicação e recuperação |
| ORCAMENTO-PIPEDRIVE.md | Cotas, cadência, alertas e diagnósticos |
| ATRIBUICAO-1.32.md | Origem comercial e histórico analítico |
| SLACK-1.32.md | Leitura exata, comparação e exclusões comprovadas |
| EDITORIAL-1.32.md | Janelas, limites e falhas explícitas |
| CONFIGURACOES-1.29.md | Localização dos controles e escolhas |
| FORMULARIOS-1.29.md / FORMULARIOS-1.28.md | Campos, etapas e diálogos; complemento do botão em RELEASE-1.33.0.md |
| COMUNICACAO-CONTATOS-1.27.md | Resumo comum e legibilidade dos três destinos |
| PUBLICIDADE-1.30.md / QUALIDADE-META-1.29.md | Consentimento, negativas e retorno comercial |
| HISTORICO-1.29.md / RELATORIOS.md | Jornada, filtros e cruzamentos |
| OPERACAO-E-RECUPERACAO.md / CRON-DIAGNOSTICO-1.31.md | Pausa, backup, restore e origem do executor |
| VALIDACAO.md / IMPACTO-1.33.0.md | Provas locais, limites externos e companheiros |
| AJUDA-OPCOES.md / dados/configuracao-schema.json | Schemas e ajuda gerados do código atual |
| CONTRACTS.md / dados/abilities-*.json | Contratos e autorização |
| DICIONARIO-DADOS.md / dados/contrato.json | Tabelas, unidades, relações e retenção |
| ../dados/estado-inventario.json | Propriedade, backup, retenção e uninstall |

Documentação não ativa integração e não comprova autorização remota. Relatórios de releases antigas estão no pacote de fontes, fora do índice de ajuda vigente.

## Interfaces da 1.33.0

- MEDICAO-SDK-1.33.md: fachada PHP e abilities de leitura, schemas completos e exemplos sintéticos.
- MEDICAO-EVENTOS-1.33.md: eventos, regras e mapeamentos gerados da mesma declaração usada no runtime.
- schemas/measurement-*.json e fixtures/measurement/*.json: contratos executáveis e respostas completas; disponíveis também pela leitura documental autenticada.
- OPERACAO-E-RECUPERACAO.md: instalação direta da 1.31.0, ciclo próprio, retomada e recuperação.
- IMPACTO-1.33.0.md e IMPACTO-SOCIAIS-1.33.md: limites e coordenação com os outros donos.

Documentos RELEASE/CHANGELOG anteriores são históricos. Não executar instruções de instalação de uma release antiga para chegar à atual.
