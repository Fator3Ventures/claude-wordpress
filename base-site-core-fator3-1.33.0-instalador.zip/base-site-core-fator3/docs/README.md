# Documentação do pacote

O índice vigente é [DOCUMENTACAO.md](DOCUMENTACAO.md), Core 1.33.0. Guias temáticos descrevem recursos mantidos; instalação e recuperação seguem OPERACAO-E-RECUPERACAO.md.
