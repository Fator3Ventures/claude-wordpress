# Validação — Site Core 1.33.0

Bancada local: WordPress 7.1.2, PHP 8.3.6, MySQL 8.0 e Chromium. Dados sintéticos; e-mail bloqueado e APIs externas simuladas ou bloqueadas. Nenhuma implantação na frota, mensagem real ou acesso a korvena.net.br.

O relatório externo da entrega identifica o SHA-256 do instalador final e os resultados da instalação nova e atualização direta do ZIP 1.31.0. A 1.32.0 não é uma etapa intermediária. Suíte e evidências estão em `suite/versao-1330/` no pacote de fontes. Nomes herdados de testes indicam a origem do cenário; somente execuções registradas nesta entrega contam como prova.

| Frente | Prova e alcance |
|---|---|
| Atualização | WordPress e SQL reais; ciclo alvo, histórico, falha de leitura/gravação, retomada, reserva renovável, dois processos simultâneos, agendamento e confirmação posterior. O relógio do checkpoint de confirmação é avançado na fixture; não há alteração de relógio no produto. |
| Preservação | Comparação por hash dos contatos, filas, sessão, campanha, recibo, arquivo, concessão e segredos sintéticos selecionados, mais procedência e lista vazia. Não é cópia de uma base de produção. |
| SDK | Leitura PHP com usuário zero, sem HTTP/escrita/DDL; slots físicos/efetivos, filtros, revisões, paginação, falhas, autorização, schemas fechados e fixtures. Abilities lidas também pelo HTTP MCP real. |
| Navegador | Chromium carrega os minificados reais; consentimento negado/aceito/revogado, teste/404/editor, formulário, atribuição, captura e download privado. Solicitações a fornecedores são interceptadas. Recebimento externo não é comprovado. |
| Google | MCP 0.21.1 e Google 0.8.5 reais, ordens invertidas, permissão negada, conexão não padrão e concessão explícita, cron com usuário zero, coleta e persistência locais com transporte Google simulado. |
| LinkedIn interno | Importação, relatórios, fila comercial e callback HTTP; challenge/HMAC, recusa, tamanho máximo, recibo durável e repetição. HTTPS do endpoint é simulado pelo roteador local. |
| Regressões comerciais | Slack, Pipedrive, qualidade, comunicação, publicidade, cron e relatórios editoriais com cenários de falha e transporte controlado. |
| Ponte do implantador | Ausência, ambiguidade, falta de validador e JSON válido; escrita não aplica configuração no site. O validador do teste é fixture, não o plugin implantador. |
| Conteúdo/SEO | Escrita autorizada MCP e efeito público; invalidação local de cache/índice. Yoast não está instalado: a operação SEO retorna indisponibilidade; a leitura de noindex já gravado é ensaiada por fixture separada. |
| Documentação | Paginação/hash de guias, schemas e fixtures, recusa anônima e a caminhos indevidos; consulta em recuperação e checkpoint inválido. |

Falhas SQL injetadas são parte dos testes. Logs intermediários, credenciais de laboratório, cookies, banco e screenshots não integram os artefatos de entrega. Resultados parciais ou testes não executados não são contados como aprovação.

## Limites externos e de ambiente

I01: Google 0.8.6 ainda sem binário entregue; produtor Core testado, adaptador futuro não homologado. MCP 0.22.0 e sua bridge também não executados. A concordância dos planos revisão 4 não equivale a código.

I02/CORE-SOC-01: a troca para provedor LinkedIn externo não foi implementada, por falta do entrypoint e schemas LI-04. Entregues fronteira do cliente interno e diagnóstico. Não há seletor funcional externo nem acesso a segredos de outro plugin.

I03/L07/L14: aplicativo, conta, formulário, callback HTTPS público, lead de teste e recebimento nos destinos exigem homologação remota autorizada. Os testes locais não comprovam esses fatos.

O percurso combinado de substituição de plugin ativo pelo MCP 0.21.1 retornou ativação pendente na bancada. A entrega foi validada pelo atualizador nativo WordPress. O encaminhamento MCP descreve a observação, sem atribuir causa não demonstrada e sem alterar o acompanhante.

Não houve homologação de multisite, cache externo, tema/implantador ou infraestrutura da hospedagem. Essas limitações não criam bloqueio de instalação por versão de outro plugin.
