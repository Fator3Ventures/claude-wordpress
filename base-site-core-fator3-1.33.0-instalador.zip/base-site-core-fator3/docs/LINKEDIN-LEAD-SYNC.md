# LinkedIn Lead Sync — Core 1.32.0

A integração importa submissões de formulários nativos patrocinados do LinkedIn. É separada da tag de conversão web e não requer visita ao site. Consulta periódica de uma hora recupera notificações perdidas; webhook opcional antecipa a leitura. O Core usa REST API 202609, protocolo Rest.li 2.0.0, `leadForms`, `leadFormResponses` e `leadNotifications`. Não usa os endpoints antigos `adForms`/`adFormResponses`.

## Configurar pelo wp-admin

1. Acesse F3 Base → Configurações → Conexões e entregas → Origens de anúncios → LinkedIn.
2. Informe a conta de anúncios e os IDs dos formulários selecionados. Confirme a propriedade/autorização. Lista vazia importa zero formulários; nunca significa toda a conta.
3. Cole o token no campo privado. Para introspecção automática, preencha Client ID e Client Secret. Para webhook, Client Secret é obrigatório; Application ID, quando informado, também é conferido no desafio. Valores não são reapresentados, só estado e vínculo.
4. Use Verificar acesso. Requer aplicativo aprovado Lead Sync e escopo `r_marketing_leadgen_automation`, além do acesso aos ativos da conta/página. A verificação lê metadados dos formulários, conta e página associada; confere os papéis do membro autenticado e, com Client ID/Secret, introspecta o token. `adAccounts` e `adAccountUsers?q=authenticatedUser` exigem `r_ads` ou `rw_ads`; `organizationAcls?q=roleAssignee` exige `r_organization_admin` ou `rw_organization_admin`. Nenhuma dessas leituras consulta respostas de contatos. Sem as credenciais ou permissões adicionais, a prova é parcial. Papel elegível ausente em consulta completa é recusado; erro, paginação incompleta ou falta de permissão de metadados significa não comprovado. Os resultados separam conta, papel na conta, página associada e papel aprovado na página, com fonte e instante. Não é necessário conceder escrita para essa conferência. A primeira coleta autorizada comprova separadamente a leitura de contatos.
5. Ative a integração para a consulta periódica. A ativação e cada novo formulário guardam marco próprio; não há importação automática anterior ao marco.
6. Para antecipar o recebimento, use Ativar recebimento imediato. O Core cadastra assinaturas somente dos formulários selecionados, relê o cadastro e mostra o resultado por formulário. Consulte o estado antes de repetir uma ação incerta.

Vantagem do webhook: menor espera quando a infraestrutura consegue disparar o executor. Limites: depende da aprovação do aplicativo, HTTPS público, credenciais válidas e execução do cron. O cadastro confirmado não comprova que uma notificação chegou. Desligar só o webhook mantém a consulta periódica.

## Endpoint e autenticação

URL gerada pelo próprio site: `/wp-json/f3base/v1/anuncios/linkedin/notificacoes?contexto=…`. HTTPS obrigatório. `contexto` identifica a configuração vigente, não é a credencial. Sem cookie, login ou token MCP; respostas privadas sem cache.

GET calcula HMAC-SHA256 de `challengeCode` com Client Secret, hexadecimal minúsculo, e devolve JSON `challengeCode`/`challengeResponse`. O LinkedIn exige resposta em até três segundos e revalida periodicamente. Responder ao desafio não comprova que o fornecedor o aceitou.

POST compara `X-LI-Signature` com HMAC-SHA256 de `hmacsha256=` concatenado aos bytes exatos do corpo usando o Client Secret. Não reserializa antes da assinatura. Limites: 128 KiB, JSON de profundidade até 32, 300 notificações autenticadas por conta/minuto. Conta, formulário versionado, tipo `SPONSORED`, ação e marco temporal são conferidos. Erro de assinatura retorna 403; corpo excessivo 413; persistência indisponível 503; cota local 429. JSON inválido também pode ser recusado pelo WordPress antes da callback.

## Fila e identidade

O recibo cifrado é persistido antes de 2xx. A callback solicita WP-Cron e retorna sem esperar CRM/Slack/e-mail. O executor retoma pendências se o loopback falhar. Há estado do despacho, horário da notificação, fila, próxima execução e resultado de processamento; não há promessa de entrega imediata.

Chave comercial: provedor + conta + formulário + ID remoto da resposta + `submittedAt` em milissegundos. A mesma referência remota com submissão nova gera contato novo; a reconsulta da mesma submissão não gera outro efeito. Webhook e polling compartilham o mesmo pipeline, trava por resposta e recibo. Notificação não avança cursor do polling.

Consulta em páginas de 50, cursores independentes por formulário/versão, releitura sobreposta de dez minutos e checkpoint somente após toda a página persistir. Até vinte segundos por passagem, com recuo por falha e `Retry-After`. IDs e URNs são strings; datas de captura, notificação e processamento não são intercambiáveis.

`CREATED` autoriza buscar a resposta; 404 transitório é retomável. `DELETED` suspende pendências da submissão correspondente e registra retirada remota. Contato e CRM já entregue permanecem; exclusão atrasada não cancela submissão posterior. Ação desconhecida não fabrica lead. Recibos mínimos são preservados para impedir duplicação e reabertura indevida.

## Campos e privacidade

Perguntas são mapeadas por ID, nome remoto único ou `predefinedField` comprovado. Múltipla escolha conserva IDs e rótulos da versão do formulário. Nomes ambíguos não são inferidos. Guardar consentimentos específicos do formulário não autoriza genericamente cookies ou todas as finalidades.

Método `anuncio_linkedin`, plataforma `linkedin_ads`, ponto `nativo`. Campanha e criativo vêm da API ou mapas explícitos do site; falta de evidência permanece ausente. Não são criados IP de visitante, user agent, localização, dispositivo ou sessão web. A apresentação comum de e-mail/Slack/Pipedrive explica a ausência da jornada. Testes remotos respeitam a política de destinos do Core.

## Administração e recuperação

`f3base/anuncios-linkedin-webhook-configurar`: ações `consultar`, `ativar`, `desativar`, `reconciliar`; `simular` padrão true. Mutações exigem `manage_options`, revisão atual e chave única de operação. Chave repetida com os mesmos argumentos devolve o resultado anterior; argumentos diferentes são conflito. Segredos não entram nessa ability.

Timeout após POST cria estado incerto; a reconciliação procura a assinatura exata antes de qualquer nova criação. Confere proprietário, URL e formulário versionado antes de alterar/remover. Assinaturas de terceiros permanecem intocadas. Remoção recusada fica pendente; trocar token/conta pode impedir a limpeza com a nova credencial, e o diagnóstico deve orientar resolver esse impedimento. O Core não retém silenciosamente token antigo.

Mudanças de conta, formulários, URL ou segredos invalidam provas. Novas versões do formulário são observadas pela consulta periódica e reconciliadas. Desligar toda a integração pausa novas entradas e preserva o acervo. Restore/uninstall suspendem as filas próprias. Saúde e `integracoes-ler` são leituras locais, sem reparo remoto; ocorrências por classe/contexto são deduplicadas e resolvidas após sucesso.

## Homologação externa pendente

A bancada cobre contrato, assinatura, endpoint HTTP, filas, repetição, exclusões e falhas com respostas simuladas. Para provar o fornecedor: aplicativo aprovado, token e Client Secret inseridos pelo dono, HTTPS público, ativação pelo Core, teste nativo, aviso autenticado, processamento e nova revalidação. Depois, quando autorizado, confirmar lead real no CRM com os mapas do site. Não considerar um desafio sintético como aceite remoto.

Fontes primárias conferidas em 15/10/2026:

- https://learn.microsoft.com/en-us/linkedin/marketing/lead-sync/leadsync?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/shared/api-guide/webhook-validation
- https://learn.microsoft.com/en-us/linkedin/shared/authentication/token-introspection
- https://learn.microsoft.com/en-us/linkedin/marketing/lead-sync/lead-sync-api-migration-guide?view=li-lms-2026-09

O exemplo oficial de criação usa `versionedForm`; a leitura tolera também `versionedFormUrn`, nome apresentado em outra página do schema. A validação remota desse contrato continua parte da homologação, sem fallback para API antiga.

Metadados de acesso (consulta oficial em 15/10/2026):

- https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads/account-structure/create-and-manage-accounts?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads/account-structure/create-and-manage-account-users?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/community-management/organizations/organization-access-control-by-role?view=li-lms-2026-09
