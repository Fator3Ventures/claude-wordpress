# Fator3 Site Core 1.33.0

Atualização direta da 1.31.0 ou instalação nova. A 1.32.0 não precisa ser instalada: suas entregas estão incorporadas. Sem bloqueio por versão dos acompanhantes e sem cadeia de reparos históricos.

Esta versão corrige o checkpoint da atualização e entrega um SDK público de contexto de medição e catálogo de eventos. Mantém a captura, os avisos e o cliente interno LinkedIn, incluindo o webhook preparado na 1.32.0.

Contrato de configuração 7.1.0; perfil 3.5. SDK de medição `site-measurement-context/1.0.0`. Acompanhantes de referência: MCP 0.21.1 e MCP Google 0.8.5. A adoção do novo SDK pelo Google 0.8.6 e a integração externa LinkedIn têm homologação conjunta pendente.

[Índice instalado](docs/DOCUMENTACAO.md) · [Release](docs/RELEASE-1.33.0.md) · [Agentes](docs/AGENTES-1.33.0.md) · [SDK](docs/MEDICAO-SDK-1.33.md) · [Validação](docs/VALIDACAO.md).

Não contém credenciais, não altera plugins acompanhantes ou tema e não ativa importação ou envio externo por instalar.
