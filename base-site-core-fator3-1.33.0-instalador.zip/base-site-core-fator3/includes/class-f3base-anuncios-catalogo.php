<?php
/** Catálogo nativo: papéis por tipo explícito, sem adivinhar pelo texto da pergunta. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Anuncios_Catalogo {
    private static ?array $paginas=null;
    public static function usar(array $pages,array $cfg): void {self::$paginas=array_intersect_key($pages,array_flip($cfg['paginas']));}
    private static function paginas(): array {
        $cfg=F3Base_Options::ler('f3base_anuncios_meta');if(self::$paginas!==null){return self::$paginas;}$s=get_option('f3base_anuncios_estado',array())['meta']??array();if(!F3Base_Integracoes::revisoes_atuais($s,'f3base_anuncios_meta','f3base_anuncios_meta_token')){return array();}return array_intersect_key($s['paginas']??array(),array_flip($cfg['paginas']));
    }
    public static function formularios(string $origem,array $cfg): array {
        if($origem==='linkedin'){return F3Base_Linkedin::formularios($cfg);}if($origem!=='meta'||($cfg['formularios_modo']??'selecionados')!=='todos_paginas_autorizadas'){return array_map('strval',$cfg['formularios']??array());}$out=array();foreach(self::paginas() as $p){if(empty($p['completa'])){continue;}foreach($p['itens']??array() as $f){$out[]=(string)$f['id'];}}return array_values(array_unique($out));
    }
    public static function definicao(string $id): ?array {
        if(preg_match('/^linkedin-([0-9]+)$/D',$id,$li)){return F3Base_Linkedin::catalogo($li[1]);}if(str_starts_with($id,'grupo-')){foreach(self::listar() as $def){if($def['id']===$id){return $def;}}return null;}if(!preg_match('/^meta-([0-9]+)$/D',$id,$m)){return null;}foreach(self::paginas() as $p){if(empty($p['completa'])){continue;}$form=$p['itens'][$m[1]]??null;if(!$form){continue;}$fields=array();foreach($form['questions']??array() as $q){$key=(string)($q['key']??'');if($key===''){continue;}$opts=array();foreach($q['options']??array() as $o){$opts[]=array('valor'=>(string)($o['key']??$o['value']??$o['text']??''),'rotulo'=>(string)($o['value']??$o['text']??''));}$fields[]=array('nome'=>$key,'rotulo'=>(string)($q['label']??$key),'tipo'=>(string)($q['type']??''),'papel'=>(array('FULL_NAME'=>'nome','EMAIL'=>'email','PHONE'=>'telefone','PHONE_NUMBER'=>'telefone','COMPANY_NAME'=>'empresa','JOB_TITLE'=>'cargo')[$q['type']??'']??''),'opcoes'=>$opts);}return array('id'=>$id,'titulo'=>$form['nome']??$id,'campos'=>$fields,'obtido_em'=>(int)($p['em']??time()),'revisao'=>hash('sha256',wp_json_encode($form['questions']??array())));}return null;
    }
    public static function listar(): array {
        $forms=array();foreach(self::paginas() as $p){if(empty($p['completa'])){continue;}foreach($p['itens']??array() as $form){$def=self::definicao('meta-'.$form['id']);if($def){$forms[]=$def;}}}
        foreach(F3Base_Linkedin::formularios(F3Base_Linkedin::config()) as $fid){$def=F3Base_Linkedin::catalogo($fid);if($def){$forms[]=$def;}}
        $groups=array();foreach($forms as &$f){$g=self::grupo($f);$f['grupo']=$g['id'];if(!isset($groups[$g['id']])){$groups[$g['id']]=$g+array('titulo'=>'Grupo de perguntas compatíveis · '.substr($g['id'],6,10),'formularios'=>array());}$groups[$g['id']]['formularios'][]=$f['id'];}unset($f);
        return array_merge($forms,array_values($groups));
    }
    private static function assinatura(array $f): string {return hash('sha256',wp_json_encode(array($f['tipo']??'',trim(mb_strtolower($f['rotulo']??'')),$f['opcoes']??array())));}
    private static function grupo(array $def): array {
        $fields=array();foreach($def['campos'] as $field){$sig=self::assinatura($field);if(isset($fields[$sig])){return array('id'=>'grupo-'.hash('sha256',$def['id']),'campos'=>array());}$field['nome']=$sig;$fields[$sig]=$field;}ksort($fields);
        return array('id'=>'grupo-'.hash('sha256',implode('|',array_keys($fields))),'campos'=>array_values($fields));
    }
    public static function mapa_respostas(string $form,array $cfg): array {
        $map=array();$def=self::definicao($form);if($def){$g=self::grupo($def);foreach($def['campos'] as $field){$v=$cfg['mapa_respostas'][$g['id']][self::assinatura($field)]??null;if($v){$map[$field['nome']]=$v;}}}
        return array_replace($map,$cfg['mapa_respostas'][$form]??array());
    }
    public static function marcar_teste(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$lead=F3Base_Leads_Repositorio::obter((string)($e['record_id']??''));if(!$lead||$lead['eliminacao_pendente']||$lead['captura']==='eliminado'){return array('ok'=>false,'codigo'=>'contato_indisponivel');}
        if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'revisao'=>(int)$lead['revisao'],'efeito'=>'Excluir de relatórios comerciais e cancelar pendências. Entregas já realizadas não são retiradas das plataformas.');}
        if((int)($e['revisao']??0)!==(int)$lead['revisao']){return array('ok'=>false,'codigo'=>'conflito');}$d=$lead['dados'];$d['contexto_teste']=true;$d['classificacao_administrativa']=array('autor'=>get_current_user_id(),'em'=>time(),'anterior'=>$lead['classe_trafego'],'motivo'=>sanitize_textarea_field($e['motivo']??''));global $wpdb;
        $ok=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('classe_trafego'=>'teste','dados'=>wp_json_encode($d),'aviso'=>'suprimido_teste','revisao'=>(int)$lead['revisao']+1),array('record_id'=>$lead['record_id'],'revisao'=>$lead['revisao']));if($ok!==1){return array('ok'=>false,'codigo'=>'conflito_ou_persistencia');}
        $cancel=F3Base_Avisos::cancelar($lead['record_id'])&&F3Base_Pipedrive_Fila::cancelar($lead['record_id'],'marcado_teste')&&F3Base_Qualidade::cancelar($lead['record_id']);F3Base_Capi_Fila::cancelar($lead['record_id'],0,true);
        return array('ok'=>$cancel,'persisted'=>true,'codigo'=>$cancel?'marcado_teste':'marcado_teste_cancelamento_pendente');
    }
    public static function papeis(string $origem,string $form): array {
        if($origem!=='meta'){return array();}$def=self::definicao('meta-'.$form);$map=array();$roles=array('FULL_NAME'=>'nome','EMAIL'=>'email','PHONE'=>'telefone','PHONE_NUMBER'=>'telefone','COMPANY_NAME'=>'empresa','JOB_TITLE'=>'cargo');$used=array();foreach($def['campos']??array() as $f){$role=$roles[$f['tipo']]??'';if(!$role){continue;}$used[$role][]=$f['nome'];}foreach($used as $role=>$keys){if(count($keys)===1){$map[$keys[0]]=$role;}}return $map;
    }
    public static function sem_nome(array $d,array $c,?array $f): bool {
        $mode=$f['pipedrive_sem_nome']??'herdar';if($mode==='herdar'){$mode=$c['sem_nome']??'recusar';}$native=$d['origem_nativa']??array();if($native){$cfg=F3Base_Options::ler('f3base_anuncios_'.$native['origem']);$mode=$cfg['mapeamento']['formularios'][$native['formulario_id']]['sem_nome']??$cfg['mapeamento']['sem_nome']??$mode;}
        return $mode==='enviar'&&(is_email($d['email']??'')||F3Base_Pipedrive_Api::telefone((string)($d['telefone']??''))!=='');
    }
    public static function nome_alternativo(array $ctx,array $cfg): string {
        $fallback=$ctx['empresa']?:$ctx['email']?:$ctx['telefone'];$vars=array('{empresa}'=>$ctx['empresa']?:$fallback,'{email}'=>$ctx['email'],'{telefone}'=>$ctx['telefone'],'{formulario}'=>$ctx['formulario']??'');$name=trim(strtr($cfg['modelo_nome']??'{empresa}',$vars));return mb_substr(sanitize_text_field($name?:$fallback),0,200);
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('contato-marcar-teste','Marcar contato como teste, preservando trilha e cancelando pendências',array(__CLASS__,'marcar_teste'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'revisao'=>array('type'=>'integer'),'motivo'=>array('type'=>'string','maxLength'=>500),'simular'=>array('type'=>'boolean','default'=>true)),array('record_id'),false));
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('anuncios-contato-reavaliar','Reavaliar papéis e elegibilidade local sem reenviar entregas confirmadas',array(__CLASS__,'reavaliar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'revisao'=>array('type'=>'integer'),'simular'=>array('type'=>'boolean','default'=>true)),array('record_id'),false));
    }
    public static function reavaliar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$lead=F3Base_Leads_Repositorio::obter($e['record_id']);$n=$lead['dados']['origem_nativa']??array();if(!$lead||!$n||$lead['lixeira']||$lead['eliminacao_pendente']){return array('ok'=>false,'codigo'=>'contato_nativo_indisponivel');}$cfg=F3Base_Options::ler('f3base_anuncios_'.$n['origem']);$map=array_replace(self::papeis($n['origem'],$n['formulario_id']),$cfg['mapeamento']['campos']??array(),$cfg['mapeamento']['formularios'][$n['formulario_id']]['campos']??array());$d=$lead['dados'];foreach($map as $key=>$role){$val=$d['campos'][$key]??null;if(in_array($role,array('nome','email','telefone','empresa','cargo'),true)&&is_string($val)){if($role==='email'&&!is_email($val)){continue;}$d[$role]=$val;}}$d['catalogo_nativo']=$n['origem']==='linkedin'?($d['catalogo_nativo']??null):self::definicao($n['origem'].'-'.$n['formulario_id']);$intent=F3Base_Pipedrive_Fila::intencao($d);
        if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'revisao'=>(int)$lead['revisao'],'papeis'=>array_intersect_key($d,array_flip(array('nome','email','telefone','empresa','cargo'))),'entrega'=>$intent,'reenviar_confirmados'=>false);}
        if((int)($e['revisao']??0)!==(int)$lead['revisao']){return array('ok'=>false,'codigo'=>'conflito');}global $wpdb;$delivery=$lead['entrega'];if(empty($delivery['pipedrive']['solicitado'])){$delivery=array_replace($delivery,$intent);}$ok=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d),'nome'=>$d['nome']??$lead['nome'],'email'=>$d['email']??$lead['email'],'entrega'=>wp_json_encode($delivery),'revisao'=>(int)$lead['revisao']+1,'atualizado_em'=>gmdate('Y-m-d H:i:s')),array('record_id'=>$lead['record_id'],'revisao'=>$lead['revisao']));if($ok!==1){return array('ok'=>false,'codigo'=>'conflito_ou_persistencia');}F3Base_Pipedrive_Fila::enfileirar(F3Base_Leads_Repositorio::obter($lead['record_id']));return array('ok'=>true,'persisted'=>true,'codigo'=>'contato_reavaliado');
    }
}
