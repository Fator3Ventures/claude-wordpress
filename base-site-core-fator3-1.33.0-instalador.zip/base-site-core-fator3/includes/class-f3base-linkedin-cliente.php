<?php
/** Fronteira interna do leitor comercial. A adoção externa aguarda o SDK LI-04 real. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Linkedin_Cliente {
    public static function estado(): array {
        return array('selecionado'=>'interno','disponivel'=>true,'troca'=>'indisponivel',
            'externo'=>array('contrato'=>'linkedin-lead-reader/1.0.0','implementado'=>false,'homologado'=>false,'codigo'=>'sdk_publico_pendente'),
            'proxima_acao'=>'Use as credenciais do cliente interno nesta tela. A adoção externa requer a interface pública e homologação conjunta LI-04; instalar outro plugin não troca o cliente nem copia credenciais.');
    }
    public static function pedir(string $method,string $path,array $data=array()): array { return F3Base_Linkedin_Api::pedir($method,$path,$data); }
    public static function prazo(float $at): void { F3Base_Linkedin_Api::prazo($at); }
    public static function introspectar(array $cfg): array { return F3Base_Linkedin_Api::introspectar($cfg); }
}
