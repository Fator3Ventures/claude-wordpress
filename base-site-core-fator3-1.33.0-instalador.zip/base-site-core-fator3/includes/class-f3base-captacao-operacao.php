<?php
/** Recuperação da captação e alertas operacionais; nunca cria contato ou conversão. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Captacao_Operacao {
    const HOOK='f3base_captacao_monitorar';
    public static function iniciar(): void {
        add_action('init',static function(){F3Base_Recuperacao::executar(static fn()=>self::reavaliar());},96);
        add_action(self::HOOK,static function(){F3Base_Recuperacao::executar(static function(){self::reavaliar();self::acompanhar();F3Base_Fila::agendar(self::HOOK,time()+300);});});
    }
    private static function identidade(): string {
        return hash('sha256',F3BASE_PLUGIN_VERSAO.'|'.F3Base_Options::revisao('f3base_anuncios_meta').'|'.F3Base_Options::revisao('f3base_anuncios_meta_token'));
    }
    public static function reavaliar(): void {
        if(empty(F3Base_Options::ler('f3base_anuncios_meta')['ativo'])){return;}
        if(!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}
        $s=get_option('f3base_anuncios_estado',array());$key=self::identidade();
        if(($s['meta']['recuperacao_revisao']??'')===$key){return;}
        $lock=F3Base_Trava::adquirir('captacao-reavaliar',15);if(!$lock){return;}
        try {
            global $wpdb;$t=F3Base_Operacao_Intencoes::tabela();
            if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){return;}
            $old=F3Base_Operacao_Intencoes::da_tarefa('anuncios');$changed=array();
            foreach($old as $r){
                if($r['estado']!=='esgotada'||!empty($r['em_execucao'])){continue;}
                // A suspended task is an administrative pause. Only exhausted capture is superseded.
                $e=$r;$e['timestamp']=max(time(),$r['timestamp']+1);unset($e['intencao']);
                if(!F3Base_Operacao_Intencoes::registrar($e,time()+1)){return;}
                $n=$wpdb->update($t,array('estado'=>'concluida','codigo'=>'superada_por_nova_revisao','atualizada_em'=>time()),array('chave'=>$r['intencao'],'estado'=>'esgotada'));
                if($n===false){return;}$changed[]=array('anterior'=>$r['intencao'],'nova'=>F3Base_Operacao_Intencoes::chave($e),'em'=>time(),'release'=>F3BASE_PLUGIN_VERSAO);
            }
            F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($s)use($key,$changed){$s['meta']['recuperacao_revisao']=$key;$s['meta']['recuperacoes']=array_slice(array_merge($s['meta']['recuperacoes']??array(),$changed),-50);return $s;});
            if($changed){F3Base_Operacao_Intencoes::agendar(time()+1);F3Base_Fila::agendar(F3Base_Anuncios::EVENTO,time()+1);}
        } finally {F3Base_Trava::liberar($lock);}
    }
    public static function recuperada(): void {
        global $wpdb;$s=get_option('f3base_anuncios_estado',array())['meta']??array();
        if(!F3Base_Integracoes::revisoes_atuais($s,'f3base_anuncios_meta','f3base_anuncios_meta_token')||($s['estado']??'')!=='verificada'){return;}
        $n=$wpdb->query($wpdb->prepare("UPDATE %i SET estado='concluida',codigo='superada_por_consulta_completa',atualizada_em=%d WHERE tarefa='anuncios' AND estado='esgotada' AND reserva_ate<=%d",F3Base_Operacao_Intencoes::tabela(),time(),time()));
        if($n){F3Base_Fila::agendar(F3Base_Anuncios::EVENTO,time()+300);}
    }
    /** Cadência observada não prova a configuração do crontab. Leitura sem reparos. */
    public static function cadencia(): array {
        global $wpdb;$t=$wpdb->prefix.'f3base_execucoes';$base=array('segundos'=>300,'fonte'=>'cadencia_solicitada_sem_amostra','amostras'=>0,'ultima_cli'=>null);
        $rows=$wpdb->get_results($wpdb->prepare("SELECT inicio FROM %i WHERE origem='cli' AND parent_run_id='' AND core_examinado=1 AND inicio>=%d ORDER BY inicio DESC LIMIT 48",$t,time()-2*DAY_IN_SECONDS),ARRAY_A);
        if($wpdb->last_error){return $base+array('erro'=>'historico_indisponivel');}
        $times=array_values(array_unique(array_map(static fn($x)=>(int)$x['inicio'],$rows?:array())));$gaps=array();for($i=1;$i<count($times);$i++){$d=$times[$i-1]-$times[$i];if($d>=60&&$d<=21600){$gaps[]=$d;}}
        if(count($gaps)<2){return $base;}sort($gaps);$seconds=max(300,$gaps[(int)floor((count($gaps)-1)*0.5)]);return array('segundos'=>$seconds,'fonte'=>'intervalo_mediano_cli_observado','amostras'=>count($gaps),'ultima_cli'=>$times[0]);
    }
    public static function diagnostico(): array {
        $s=get_option('f3base_anuncios_estado',array())['meta']??array();$cfg=F3Base_Options::ler('f3base_anuncios_meta');$blocked=null;
        try{foreach(F3Base_Operacao_Intencoes::da_tarefa('anuncios') as $r){if(in_array($r['estado'],array('esgotada','suspensa'),true)){$blocked=$r;break;}}}catch(Throwable $e){return array('estado'=>'indisponivel','codigo'=>'intencoes_ilegivel');}
        $last=(int)($s['ultimo_sucesso_completo']??0);$scheduled=(int)($s['ultima_execucao_agendada']??0);$since=(int)($s['ativado_em']??time());$age=time()-($last?:$since);$scheduleAge=time()-($scheduled?:$since);$next=wp_next_scheduled(F3Base_Anuncios::EVENTO);
        $cadencia=self::cadencia();$limiar=max(900,$cadencia['segundos']+max(300,(int)ceil($cadencia['segundos']*.2)));$failure=!empty($s['formularios_com_problema'])||(!empty($s['codigo'])&&!in_array($s['codigo'],array('paginando','catalogo_paginando','orcamento_execucao','coleta_em_execucao'),true));
        $state=empty($cfg['ativo'])?'desligada':($blocked?$blocked['estado']:($failure?'falha':($age>=$limiar||$scheduleAge>=$limiar?'atrasada':'observada')));
        return array('estado'=>$state,'ultima_execucao_agendada'=>$scheduled?:null,'ultimo_sucesso_completo'=>$last?:null,'proxima_execucao_confirmada'=>$next?:null,'idade_cobertura_segundos'=>max(0,$age),'idade_agendador_segundos'=>max(0,$scheduleAge),'ocorrencia_bloqueadora'=>$blocked,'codigo'=>$blocked['codigo']??($s['codigo']??''),'acao'=>$blocked?'Corrija a configuração/credencial ou reative a ocorrência na Operação.':($state==='atrasada'?'Confira o cron e execute uma consulta completa.':'Acompanhamento automático.'),'cadencia_segundos'=>$cadencia['segundos'],'cadencia'=>$cadencia,'limiar_atraso_segundos'=>$limiar,'formularios_com_problema'=>$s['formularios_com_problema']??array());
    }
    public static function acompanhar(): void {
        $d=self::diagnostico();if(in_array($d['estado'],array('desligada','indisponivel','suspensa'),true)){return;}
        $s=get_option('f3base_anuncios_estado',array())['meta']['alerta']??array();$problem=in_array($d['estado'],array('esgotada','atrasada','falha'),true);
        if(!$problem&&empty($s['aberto'])){return;}if($problem&&!empty($s['aberto'])&&(int)($s['em']??0)>time()-DAY_IN_SECONDS){return;}
        $lock=F3Base_Trava::adquirir('captacao-alerta',15);if(!$lock){return;}
        try{
            // Persist reservation first: an uncertain remote outcome must not create a retry storm.
            $save=F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($state)use($problem){$state['meta']['alerta']=array('aberto'=>$problem,'em'=>time(),'resultado'=>'reservado');return $state;});if(empty($save['persisted'])){return;}
            $title=($problem?'Captação Meta requer atenção':'Captação Meta recuperada').' — '.wp_specialchars_decode(get_bloginfo('name'),ENT_QUOTES);
            $body='Site: '.home_url('/')."\n".'Horário: '.wp_date('d/m/Y H:i:s T')."\n".'Estado: '.$d['estado']."\n".'Causa: '.($d['codigo']?:'intervalo observado e tolerância excedidos sem execução completa')."\n".$d['acao']."\n".'Formulários com problema: '.wp_json_encode($d['formularios_com_problema']??array())."\n".F3Base_Configuracoes_Hub::url('conexoes','f3base_anuncios_meta');
            $result=self::enviar_alerta($title,$body);F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($state)use($result){$state['meta']['alerta']['resultado']=$result;return $state;});
        }finally{F3Base_Trava::liberar($lock);}
    }
    private static function enviar_alerta(string $title,string $body): array {
        $cfg=F3Base_Options::ler('f3base_avisos');$channel=$cfg['canal']??'email';$result=array();$ok=false;
        if(in_array($channel,array('slack','ambos'),true)){
            if(($cfg['slack_transporte']??'webhook')==='app'){$r=F3Base_Slack::api('chat.postMessage',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('channel'=>$cfg['slack_canal_id'],'text'=>$title."\n".$body));$ok=!empty($r['ok']);}
            else{$url=F3Base_Segredos::abrir(F3Base_Avisos::SEGREDO);if(F3Base_Avisos::url_valida($url)){$r=wp_remote_post($url,array('timeout'=>5,'redirection'=>0,'headers'=>array('Content-Type'=>'application/json'),'body'=>wp_json_encode(array('text'=>$title."\n".$body))));$ok=!is_wp_error($r)&&wp_remote_retrieve_response_code($r)===200;}}
            $result['slack']=$ok?'aceito':'sem_confirmacao';
        }elseif(in_array($channel,array('webhook','email_webhook'),true)){
            $url=F3Base_Segredos::abrir(F3Base_Avisos::WEBHOOK_URL);$secret=F3Base_Segredos::abrir(F3Base_Avisos::WEBHOOK_CHAVE);$payload=wp_json_encode(array('schema'=>'f3base.operacao.alerta.v1','site'=>home_url('/'),'titulo'=>$title,'texto'=>$body,'em'=>time()));
            if($secret&&F3Base_Avisos::webhook_url_valida($url)){$r=wp_safe_remote_post($url,array('timeout'=>5,'redirection'=>0,'headers'=>array('Content-Type'=>'application/json','X-F3Base-Signature'=>'sha256='.hash_hmac('sha256',$payload,$secret)),'body'=>$payload));$ok=!is_wp_error($r)&&wp_remote_retrieve_response_code($r)>=200&&wp_remote_retrieve_response_code($r)<300;}$result['webhook']=$ok?'aceito':'sem_confirmacao';
        }
        if(!$ok||in_array($channel,array('email','ambos','email_webhook'),true)){$to=F3Base_Options::ler('f3base_contato')['email_leads']??get_option('admin_email');$result['email']=wp_mail($to,$title,$body)?'aceito_wp_mail':'sem_confirmacao';}
        return $result;
    }
}
