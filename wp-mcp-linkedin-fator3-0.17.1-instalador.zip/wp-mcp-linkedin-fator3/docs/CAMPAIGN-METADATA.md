# Campanha vinculada ao lead — 0.17.1

Extensão pública `linkedin-lead-campaign/1.0.0`, aditiva aos leitores 1.0, 1.1 e 1.2. Responde ao impacto Core 1.68.0, item 369(d). Não altera a negociação de contratos existentes nem a identidade do lead. `PublicApi::capabilities()` e `$reader->descriptor()['extensions']['campaign']` anunciam suporte. A presença do método não concede autorização.

## Metadados na leitura normal

`get_response` e `read_responses` solicitam explicitamente `leadMetadataInfo`, `ownerInfo` e `associatedEntityInfo`, junto a todos os campos padrão documentados da resposta. Mantêm `id`, `responseId`, `leadType`, `owner`, `submitter`, `versionedLeadGenFormUrn`, `leadMetadata`, `associatedEntity`, `submittedAt`, `testLead` e `formResponse`. Respostas, consentimentos, versão e milissegundos mantêm o contrato anterior, inclusive a normalização textual da 0.15.0. Não realizam consulta Ads nem introspecção adicional.

Cada resposta ganha `campaign`, separado de `raw`. O esquema estrutural está em `lead-campaign-schema.json`: contract, account_id, id (string ou null), name (string ou null), source, status, code e retryable. `source` é `lead_metadata` ou `campaign_api`. Só há nome válido quando `status:available`. O nome é preservado como fornecido; não é derivado do ID, da conta ou do formulário. O ID de campanha decorado deve coincidir exatamente com a URN em `leadMetadata.sponsoredLeadMetadata.campaign`; o proprietário do lead deve corresponder à conta autorizada. Se a decoração informar conta, ela também precisa corresponder.

Nome ausente resulta em `not_provided`; lead sem associação de campanha, `not_applicable`. Decoração divergente ou nome malformado resulta em `invalid_metadata`; o nome inválido é removido de `raw` para impedir seu uso pelo consumidor antigo. Esses estados não bloqueiam a entrega de um lead válido. Falhas de identidade, conta, formulário ou timestamp do próprio lead continuam recusando a resposta inteira.

## Consulta complementar explícita

Permissão nova `campaign_lookup`, concedida junto a `responses`, com a conta selecionada em `assets.ads` e `assets.leads`. Conexões/concessões antigas não recebem essa permissão automaticamente. Na aba Concessões marque “Consultar nome da campanha vinculada ao lead”; examine a simulação e confirme. Pela API use `save-grant` com a concessão completa, `expected_revision`, `dry_run:true`; confirme a mesma entrada com `confirmation`, sem `dry_run`. Alteração da revisão invalida a prévia. A concessão precisa manter conta/formulário autorizados. Ela não concede escrita Ads, publicação ou conversões.

```php
$reader = \Fator3\LinkedIn\PublicApi::lead_reader('meu-consumidor');
$descriptor = $reader->descriptor();
if (($descriptor['extensions']['campaign'] ?? null) === 'linkedin-lead-campaign/1.0.0') {
    $result = $reader->resolve_campaign([
        'connection_id' => 'minha-conexao',
        'account_id' => '222',
        'form_id' => '8333',
        'response_id' => 'resposta_exemplo',
        'credential_revision' => $credentialRevision,
        'grant_revision' => $grantRevision,
    ]);
}
```

As revisões são obtidas do contexto público vigente. Entrada fechada igual à de `get_response`; `campaign_id` arbitrário é recusado. O método relê o lead, valida conta/formulário/resposta e extrai exclusivamente a referência de campanha dessa resposta. Se houver decoração válida, retorna-a. Caso contrário, exige introspecção atual com `r_ads` ou `rw_ads` e consulta `GET /rest/adAccounts/{account_id}/adCampaigns/{campaign_id}?fields=id,name,account`. O retorno deve coincidir com ID e conta solicitados. Não usa `admin-options`, cache persistente ou token exportado.

Saída de sucesso: envelope habitual com `data.campaign`, `data.response_identity`, `credential_revision`, `grant_revision`, `remote_effect:none` e `commercial_effects:false`, além de contract/consumer_id do leitor. Não retorna respostas pessoais nem os demais campos Ads. A operação humana equivalente é `linkedin/lead-resolve-campaign`, somente leitura remota, exigindo `manage_options`. Serviço deve usar consumidor registrado; funciona com usuário corrente 0, revalidando a autorização atual do configurador da concessão, as revisões e a seleção antes/depois dos despachos. Remoção/revogação impede entregar dados obtidos durante a corrida.

Orçamento: até três GETs (incluindo a única repetição sem projeção, quando necessária), uma introspecção OAuth de leitura, sem escrita comercial; GETs têm timeout de até 8 segundos, introspecção de até 12 segundos e prazo global de 25 segundos observado antes dos GETs. Não há paginação, busca em contas alternativas ou repetição genérica. Respostas de erro preservam código original e acrescentam `details.campaign_contract`, `details.campaign_status`, `details.remote_effect:none` e retryable, repetido no envelope.

| Situação | campaign_status / status | Conduta do consumidor |
| --- | --- | --- |
| Nome confirmado | available | Usar após precedência do mapa local. |
| Nome não fornecido, recurso 404 | not_provided | Registrar ausência; manter lead. |
| Lead sem campanha associada | not_applicable | Manter lead sem inventar nome. |
| Concessão, conta ou escopo recusado, 401/403 | not_authorized | Solicitar correção de autorização. |
| Revisão desatualizada | stale_context | Reler contexto público e reconfirmar quando necessário. |
| 429/5xx, timeout, indisponibilidade OAuth ou orçamento | temporarily_unavailable | Retry posterior limitado, observando retry_after quando retornado. |
| Vínculo ou conteúdo inválido | invalid_metadata | Registrar inconsistência e não usar nome. |

`success:true` com `not_provided` não significa campanha nomeada. Em erro, `data` é null. Não transformar falta de permissão em ausência de nome. Um contrato indisponível no produtor é detectado por capabilities/descriptor, antes da chamada.

## Responsabilidade do Core e aceite

Core 1.68.0 já negocia Lead Reader 1.2 e usa a decoração validada em `raw`, preservando o mapa local. A integração PHP real foi exercitada com HTTP sintético que só fornece decoração quando solicitada, coleta sem usuário corrente e deduplicação. O Core ainda precisa adotar `resolve_campaign` para o fallback explícito. Nenhum pacote/documento Core é alterado por esta entrega. Completar um nome não autoriza reimportar lead, repetir webhook ou reenviar conversão. Persistência do enriquecimento e política de retry pertencem ao consumidor.

Os produtos/permissões do LinkedIn continuam necessários; nome pode não existir ou não ser fornecido. Testes locais não homologam o fornecedor. Referências oficiais consultadas em 02/11/2026: [Lead Sync](https://learn.microsoft.com/en-us/linkedin/marketing/lead-sync/leadsync?view=li-lms-2026-10), [schema](https://learn.microsoft.com/en-us/linkedin/marketing/lead-sync/lead-sync-schema?view=li-lms-2026-10), [migração](https://learn.microsoft.com/en-us/linkedin/marketing/lead-sync/lead-sync-api-migration-guide), [campanhas](https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads/account-structure/create-and-manage-campaigns?view=li-lms-2026-03).

## Recusa da projeção na 0.17.0

A projeção conserva campos padrão e solicita apenas leadMetadataInfo.sponsoredLeadMetadataInfo.campaign.id/name como decoração. Não solicita ownerInfo/associatedEntityInfo. Em HTTP400 com a mensagem específica de campo projetado ausente no schema, repete uma vez o GET sem fields, mantendo os demais parâmetros. Aplica a get_response, read_responses e à releitura do lead em resolve_campaign. Reconfere administrador de origem, conexão, concessão, conta e formulário antes da repetição e depois da leitura. Sem nome retorna not_provided; o lead pode continuar. Outros erros não acionam esta recuperação. creation_rejected nunca qualifica uma leitura.
