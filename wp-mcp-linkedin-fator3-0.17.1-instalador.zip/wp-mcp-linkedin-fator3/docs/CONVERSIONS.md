# Conversions API — 0.17.1

## Responsabilidade e autorização
O Core mantém consentimento publicitário, contatos, origem/tempo/ID de evento, fila, supressão de spam/homologação e limite de tentativas. LinkedIn mantém credenciais, transporte e validação do destino. Não há leitura de options/tabelas privadas do Core. O filtro f3base_conversoes_adaptador retorna ConversionDelivery somente se o adaptador anterior for null, destino linkedin, contrato site-conversion-delivery/1.0.0 e contexto consumer_id=site-core-conversions.

Concessão explícita, independente de Lead Sync: Ativos → Conversions API. Selecione conexão/conta Ads já marcada, carregue regras, selecione regra ativa CONVERSIONS_API e confirme. O salvamento verifica rw_conversions e r_ads por introspecção e um papel permitido na conta: ACCOUNT_BILLING_ADMIN, ACCOUNT_MANAGER, CAMPAIGN_MANAGER ou CREATIVE_MANAGER. VIEWER é recusado. Guarde expected_revision da concessão e expected_connection_revision da conexão.

get-conversion-grant é leitura local; save-conversion-grant enabled=false revoga sem consultar o fornecedor. Nova conexão/conta/regra, alteração da revisão da conexão, revogação/reconcessão ou mudança do principal gera novo destination_ref. Reconfirmar exatamente o mesmo vínculo preserva a referência. Não preencha referências históricas silenciosamente no Core.

## Regras e fontes
list-conversion-rules lista por conta selecionada, offset e next_offset, até 50. Nome, ID string, enabled, conversion_method e ready_source são projeções administrativas. O grant e cada envio releem a regra e verificam a conta proprietária, enabled=true e conversionMethod=CONVERSIONS_API. Regras compartilhadas de outra conta não são adotadas nesta versão.

O plugin não inventa atualização da fonte de regra Insight Tag. Configure regra API em Campaign Manager → Measurement → Conversion tracking e associe campanhas no fornecedor. A orientação oficial usa regras distintas por fonte, deduplicadas por eventId comum. O ID de servidor configurado no Core deve coincidir com a concessão de aquisição. A referência ao Core 1.47.0 nas notas anteriores é histórica. A seleção de regra API isoladamente não conclui a homologação da regra 31692506.

## SDK público
ConversionDelivery::capabilities() retorna contract, ready, reason, destination_ref opaco (64 hex) e conversion_id string. Só lê estado local; não introspecta, repara, concede nem envia. ready significa configuração local verificada, não aprovação atual garantida. Motivos incluem sem_conexao, sem_concessao, sem_escopo, escopo_nao_verificado, regra_sem_fonte_api, destino_alterado, token_expired, connection_paused e not_authorized. Renovação programática preserva vínculo; cada envio comprova novamente os escopos mesmo quando a prova local é anterior à renovação.

send(payload) recusa destination_binding_required. sendBound(payload,destination_ref) é a entrada operacional para o Core, inclusive usuário WordPress zero. Revalida concessão, administrador de origem e eventual política de transporte da concessão, seleção de Ads, revisão da conexão, escopos atuais, papel e fonte API, antes de despachar. Não assume usuário humano.

Payload site-linkedin-conversion/1.0.0: record_id como referência interna, event_id e eventId iguais, strings ASCII até 128; conversion=urn:lla:llaPartnerConversion:<ID concedido>; conversionHappenedAt inteiro em ms, janela de 90 dias e tolerância futura de 5 minutos; user.userIds com SHA256_EMAIL (hex minúsculo de 64 caracteres) e/ou LINKEDIN_FIRST_PARTY_ADS_TRACKING_UUID; user.userInfo com firstName e lastName juntos e companyName/title/countryCode opcionais. O record_id pode diferir do eventId, como ocorre no código do Core 1.47.0: só o ID congelado do evento vai ao fornecedor. li_fat_id aceita até 500 caracteres no formato observado pelo Core. Não calcula hash de email nem infere país. conversionValue opcional com currencyCode ISO de três letras e amount decimal string. Só chaves do schema LinkedIn chegam ao HTTP; contract/record_id/event_id são removidos. O schema completo está em input-schemas.json.

Resposta sem corpo remoto nem PII: status entregue/recusado/incerto, code simbólico, http inteiro, non_delivery_proven e retry_after quando houver, operation_id e replay quando admitido. 201 significa aceito na API, não conversão atribuída/contada na interface. Recusa comprovada pode ser reavaliada pelo Core dentro dos seus limites (até 10 tentativas/90 dias). Timeout, 5xx, HTTP 408, recibo inconsistente ou falha de persistência depois do despacho ficam incertos; não se repetem automaticamente. Não há contrato de reconciliação CAPI nesta versão: a API não oferece consulta por eventId que prove não entrega.

## Abilities humanas e lote
send-conversion-event recebe payload, destination_ref, dry_run (default true), confirm e confirm_token. A prévia comprova acesso e devolve somente contagem/regra/confirm_token, sem identificação pessoal. Executar exige dry_run=false, confirm=true e confirm_token da mesma prévia, válida por 600 segundos e vinculada a principal, conteúdo, destino e geração da credencial. Nunca use dados reais como simples teste.

send-conversion-events recebe payloads (1–100). Valida todo o lote antes de qualquer efeito. Envia elementos pendentes por BATCH_CREATE; se resta só um, usa CREATE. A resposta individual é correlacionada pela posição do lote. Quantidade divergente ou status ausente mantém incerteza. Replay confirmado/incerto não volta ao HTTP; apenas recusados comprovadamente podem ser tentados de novo. Mesmo eventId repetido dentro do lote é recusado. O tamanho conservador de cem eventos limita memória/tempo; não é o teto do LinkedIn.

## Persistência e Registro
Trava nomeada global de envio, CAS e diário cifrado impedem concorrência local. Chave estável por conta/regra/eventId, derivada por HMAC local; digest de conteúdo também HMAC. Payload, nomes, email, hash de contato e li_fat_id não são persistidos nem retornados. Apenas referência opaca, conta/regra/conexão, principal, estado, recibo simbólico e antes/depois técnicos são guardados. Estado dispatching é persistido antes do HTTP; crash posterior bloqueia reenvio. Não há transação distribuída com LinkedIn.

Chamadas administrativas mantêm linkedin-mutation/1.0.0 e o descritor humano admitido pelo MCP 0.27.0. Envios SDK persistem identidade de serviço e emitem linkedin-service-mutation/1.0.0, inclusive com usuário incidental, conforme SERVICE-AUDIT.md. O novo leitor exige concessão/revisão vigentes; revogação bloqueia detalhe sem apagar histórico. O MCP 0.27.0 ainda não consome esse contrato: central_audit=service_principal_unsupported permanece nessa combinação. Nenhum usuário humano é assumido. A confirmação recorded exige recibo central com digest exato, quando um canal compatível estiver disponível.

## Referências conferidas em 22/10/2026
- https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads-reporting/conversions-api?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads-reporting/conversions-api-schema?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/conversions/conversions-usecase?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/conversions/conversions-workflow?view=li-lms-2026-09

## Diagnóstico de requisitos — 0.8.0

`linkedin/diagnose-conversions` (POST `/wp-json/f3-linkedin/v1/diagnose-conversions`, administrador, leitura, sem chamada ao LinkedIn; como toda operação despachada (exceto `documentation` e `get-service-write-operation`), grava uma linha no registro de auditoria local (`linkedin/audit`, retenção configurável, padrão sem prazo desde 0.11.0 (HISTORY.md)) e mantém `f3_linkedin_audit_health`; não altera concessão, conexão, credenciais, fila nem agendas) devolve `ready`, `blocking_count`, `checks[]` (`id`, `ok`, `blocking`, `code`, `action`), `grant`, `scope_proof`, `core_rule_match`, `central_audit` e `remote_checked=false`.

Requisitos bloqueantes: `grant_enabled`, `connection_available`, `connection_usable`, `connection_revision_current`, `account_selected`, `rule_api_source`, `rule_enabled`, `token_scopes` (rw_conversions e r_ads), `grant_owner_authorized` e, quando a entrada traz `conversion_id`, `core_rule_matches_grant`. Informativos: `token_not_expiring` (3 dias), `scope_proof_recent` (30 dias) e `central_audit_registered`.

Passe em `conversion_id` o ID da regra de servidor configurado no Site Core (Medição → Conversions API). Divergência gera `regra_divergente`: o envio do Core seria recusado com o mesmo código. Sem `conversion_id`, `ready` coincide com `conversion-capabilities.ready`. Os dados de regra e escopos vêm da última concessão e da última prova local; para conferir no LinkedIn, use `list-conversion-rules` e a validação do token.

## Prontidão local — correção 0.8.1

Quando existe prova de introspecção ligada à credencial vigente, `conversion-capabilities` e `diagnose-conversions` respeitam `active` e `expires_at` dessa prova. Token conhecido inativo retorna `token_rejected`; expiração conhecida vencida retorna `token_expired`. O diagnóstico acrescenta a verificação bloqueante `token_proof_valid` quando essa prova existe. Renove e revalide a credencial antes de retomar. Não há HTTP, renovação ou alteração da concessão nessas leituras; o envio mantém sua introspecção remota obrigatória.

Quando a prova não existe ou já não corresponde à credencial, continua a semântica anterior de escopos da concessão com `scope_proof.checked=false` e aviso de revalidação. Prontidão local não certifica autorização remota atual. A correção não muda IDs separados de navegador/servidor, event_id, destination_ref, payload nem o contrato do Core.

## Etapas comerciais na 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.35.0 passou a admitir esse consumidor; a integração foi repetida com MCP 0.36.0 e recibo central recorded. Em MCP 0.34.0 a limitação histórica permanece. Não repetir evento por falta de recibo central.
