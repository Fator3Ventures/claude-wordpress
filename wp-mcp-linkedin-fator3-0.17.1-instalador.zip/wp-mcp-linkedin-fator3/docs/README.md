# Fator3 MCP LinkedIn 0.17.1

Plugin independente. Configure em Ferramentas > Fator3 MCP LinkedIn. Entradas humanas (painel, REST, abilities/MCP, arquivos e tarefas iniciadas por usuário) exigem `manage_options`. A lista legada `users` não concede acesso a pessoas sem essa capacidade. O transporte MCP é opcional; o plugin não chama Google, Core ou outro provedor para executar relatórios.

## Índice instalado

- STAGE-CONVERSIONS.md — configuração, contrato comercial e recuperação.
- RELEASE-0.17.1.md — correção documental final desta rodada.
- RELEASE-0.17.0.md — funcionalidades desta rodada: leitura resiliente, diário, assinaturas e concessões.
- RELEASE-0.16.0.md — histórico da extensão de campanha vinculada ao lead.
- CAMPAIGN-METADATA.md e lead-campaign-schema.json — projeção validada e fallback autorizado.
- RELEASE-0.15.0.md — histórico dos pedidos 18–21.
- LEAD-DISCOVERY.md — seleção automática, contrato 1.2, webhooks e recuperação.
- RELEASE-0.14.0.md — histórico dos pedidos 16/17.
- RELEASE-0.13.0.md — histórico dos avisos de formato de credenciais.
- RELEASE-0.12.0.md — histórico de conversões comerciais.
- HISTORY.md — políticas de retenção, acervo diário, cobertura, backfill e exportação.
- RELEASE-0.11.0.md — histórico de retenção e acervo.

- ADMINISTRATION.md — abas, seletores e fluxos de administração.
- AGENTS.md — operação por agentes e limites de autorização.
- CONFIGURATION.md — tokens, seleção e acesso.
- OPERATIONS.md — consultas, processamento e exportações.
- CONTRACTS.md — contratos, REST/MCP, schemas e erros.
- SDK-PHP.md — SDK local e responsabilidade de consumidores.
- SECURITY.md — isolamento, dados e autorização.
- MIGRATION.md — atualização, retenção e rollback.
- TROUBLESHOOTING.md — diagnóstico, limites e falhas.
- WORKER.md — fila de coletas indexada, recuperação do worker e diagnóstico no status.
- CHANGELOG.md — alterações da versão.
- input-schemas.json e output-schema.json — contratos gerados pelo build.

Todos estes arquivos integram o instalador e o conteúdo retornado por `linkedin/documentation`. Consulte `{"document":"index"}`. Para ler um documento use `document`, `offset` (bytes) e `limit_bytes` (256–65536). Continue por `next_offset`, repetindo `expected_revision` igual a `revision`. Concatene `content` sem separadores; confira o SHA-256 integral indicado. O cursor documental não faz HTTP, não migra armazenamento, não grava auditoria nem lê caminhos arbitrários. A resposta identifica slug, versão, origem local, tamanho e hash. O painel usa a mesma operação.

## Instalação e dependências

WordPress 6.4+, PHP 8.1.2+ de 64 bits (mínimos exercitados na 0.8.0: WordPress 6.4 com PHP 8.1.2, sem Abilities API; e WordPress 7.1.3 com PHP 8.3.6), MySQL/MariaDB com InnoDB e bloqueios nomeados, criptografia sodium ou AES-256-GCM, HTTPS externo e WP-Cron ou cron real. Abilities exigem a API de abilities disponível; em WordPress sem ela o painel e REST continuam operando. Instale o ZIP instalador; o ZIP fonte é para desenvolvimento. Consulte o relatório da entrega para a matriz de versões efetivamente testadas.

Tokens nunca são retornados por APIs de configuração. Configuração local, teste com respostas simuladas e homologação externa são estados distintos. Acesso real depende de produtos, permissões, ativos e versões liberados pelo fornecedor.

## Histórico — capacidades da versão 0.9.0

Na 0.8.0 eram 81 operações: as 80 da 0.7.0 permanecem com identificadores e rótulos; a nova `linkedin/diagnose-conversions` (somente leitura) lista cada requisito do envio de conversões pelo servidor. Leia também:

- WORKER.md — fila indexada (schema 2), recuperação e diagnóstico do worker.
- CONVERSIONS.md — SDK CAPI, concessão, diagnóstico de requisitos e riscos de entrega.
- MANAGEMENT.md — especificação, prévia, execução, reconciliação e exemplos de anúncios/publicações.
- CREDENTIALS.md — autorização opcional pelo navegador, renovação, avisos e preservação do acesso.
- FIELD-HELP.md — nomes e localização dos campos.
- SERVICE-AUDIT.md — contrato de serviço e integração com o Registro central do Fator3 MCP.
- RELEASE-0.9.0.md — isolamento concorrente seguro (pedido 12).
- RELEASE-0.8.1.md — correções da revisão independente.
- RELEASE-0.8.0.md — histórico das melhorias que originaram esta revisão.
- RELEASE-0.7.0.md, RELEASE-0.6.0.md, RELEASE-0.5.0.md — histórico.

A atualização direta da rodada 0.9.0 foi 0.8.1 → 0.9.0, com schema 2 preservado. Com o Fator3 MCP 0.28.0 ou posterior, `service_audit.central_registered=true` e os envios de serviço registram `central_audit=recorded`; sem o MCP, `service_principal_unsupported` continua correto. Não confunda entrega do código com homologação real do LinkedIn.

A 0.9.0 relê coletas ilegíveis sob bloqueio individual e condiciona o isolamento à mesma revisão e ao mesmo ciphertext. Não cria novas operações ou concessões. Veja MIGRATION.md.


## Atualização 0.10.0 — pedido 13

Consulte RELEASE-0.10.0.md e CREDENTIALS.md: candidata conferida antes de persistir, identidade guiada, nomes com origem explícita e agendas rebaseadas no mesmo salvamento. A configuração recebe revisão a cada gravação; authorization_revision e credential_generation distinguem autorização e credencial. Uma alteração benigna mantém o vínculo das identidades de serviço CAPI já emitidas; uma nova concessão ou identidade continua revogando o vínculo anterior. Não editar documentos recebidos de outros pacotes para responder a pedidos.

A versão histórica 0.11.0 introduziu a retenção e o acervo diário. Leia RELEASE-0.11.0.md e HISTORY.md para auditoria, retenção, acervo diário, migração e coleta retroativa. A correção da origem do Refresh Token da 0.10.1 permanece.

## Etapas comerciais na 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.35.0 passou a admitir esse consumidor; a integração foi repetida com MCP 0.36.0 e recibo central recorded. Em MCP 0.34.0 a limitação histórica permanece. Não repetir evento por falta de recibo central.

## Histórico 0.14.0 — pedidos 16/17

Versão histórica 0.15.0; atualização direta daquela rodada: 0.14.0 → 0.15.0. Pedidos 18–21 em RELEASE-0.15.0.md. Pacotes examinados: Core 1.67.0, MCP 0.38.0, Google 0.26.0, Meta 0.19.0 e Pipedrive 0.5.0. Provas e limites no relatório da entrega.

A release corrente é 0.17.1, com atualização direta da base aceita 0.16.0 ou da intermediária 0.17.0 usada no Site-Teste. O Core 1.68.0 recebido adota a seleção automática/eventos 1.2. Leia RELEASE-0.17.1.md, RELEASE-0.17.0.md, CAMPAIGN-METADATA.md e LEAD-DISCOVERY.md.

## Histórico 0.16.0

Leia CAMPAIGN-METADATA.md e RELEASE-0.16.0.md. Metadados de campanha são solicitados e validados nas leituras existentes. A nova permissão campaign_lookup é opcional, exige responses e conta Ads selecionada, com simulação/confirmação; não é adicionada a concessões antigas. O método resolve_campaign é somente leitura remota e não importa contatos. Core 1.68.0 já adota a descoberta 1.2 e consome a decoração; o fallback novo ainda exige adoção própria. Documentos e pacotes Core/MCP não são alterados.
