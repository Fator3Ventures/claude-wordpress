<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

final class PublicApi {
    private static array $consumers=[];
    public static function capabilities(): array {
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'contracts'=>['social-reporting/1.0.0','linkedin-lead-reader/1.0.0','linkedin-lead-reader/1.1.0','linkedin-lead-reader/1.2.0'],'extensions'=>['campaign'=>LeadCampaign::CONTRACT],'features'=>['campaign_projection'=>true,'campaign_lookup'=>true,'subscription_journal'=>true,'global_intent_guard'=>true,'dispatch_authorization'=>true,'grant_pagination'=>true,'all_forms_selection'=>true,'form_discovery_events'=>true,'text_answers_trimmed'=>true],'entrypoint'=>self::class,'registration_hook'=>'f3_linkedin_register_consumers','methods'=>['register_consumer','lead_reader','capabilities'],'consumers'=>array_values(self::$consumers),'commercial_ingestion'=>false,'core_selection_required'=>true];
    }
    public static function register_consumer(array $descriptor): array {
        return Result::run(static function()use($descriptor){Util::guardKeys($descriptor,['id','label','contract']);$id=Util::id($descriptor['id']??'');if(!in_array($descriptor['contract']??'',['linkedin-lead-reader/1.0.0','linkedin-lead-reader/1.1.0','linkedin-lead-reader/1.2.0'],true))throw new Fault('unsupported','Contrato de consumidor incompatível.');if(isset(self::$consumers[$id])){if(self::$consumers[$id]!==$descriptor)throw new Fault('consumer_conflict','Registro de consumidor divergente.');return $descriptor;}self::$consumers[$id]=$descriptor;return $descriptor;});
    }
    public static function contract(string $id): string {return self::$consumers[$id]['contract']??'linkedin-lead-reader/1.1.0';}
    public static function grantsPage(array $i): array {Access::admin();$at=(int)($i['offset']??0);$r=Store::list('grant',$at,51);return ['consumers'=>array_values(self::$consumers),'grants'=>array_map(static fn($x)=>$x['value']+['revision'=>$x['revision']],array_slice($r,0,50)),'next_offset'=>count($r)>50?$at+50:null];}
    public static function grantProjection(array $i): array {Access::admin();$r=Store::get('grant',$i['consumer_id'].':'.$i['connection_id']);if(!$r)throw new Fault('not_found','Concessão não encontrada.');return ['grant'=>$r['value']+['revision'=>$r['revision']]];}
    public static function registered(string $id): bool {return isset(self::$consumers[$id]);}
    public static function lead_reader(string $consumer): LeadReader {
        if($consumer!==''&&!self::registered($consumer))throw new Fault('consumer_unregistered','Consumidor local não registrado.');
        if($consumer==='')Access::admin();return new LeadReader($consumer);
    }
    public static function grant(array $i): array {
        Access::admin();return Store::lock('connection:'.$i['connection_id'],static fn()=>self::grantLocked($i));
    }
    private static function grantLocked(array $i): array {
        Access::admin();Schemas::validate('save-grant',$i);if(!self::registered($i['consumer_id']))throw new Fault('consumer_unregistered','O consumidor deve registrar seu contrato primeiro.');
        $c=Connections::get($i['connection_id']);$old=Store::get('grant',$i['consumer_id'].':'.$c['id']);$forms=[];$all=array_values(array_unique($i['all_forms_accounts']??$old['value']['all_forms_accounts']??[]));if(array_diff($all,$c['all_forms_accounts']))throw new Fault('asset_access_denied','A conexão precisa autorizar todos os formulários desta conta.');if($all&&(self::contract($i['consumer_id'])!=='linkedin-lead-reader/1.2.0'||array_diff(['metadata','responses','verify','subscriptions'],$i['permissions'])||empty($i['callback_url'])))throw new Fault('automatic_grant_incomplete','Seleção automática exige contrato 1.2, quatro permissões e callback do consumidor.');
        foreach($i['forms'] as $account=>$ids){$account=(string)$account;Access::asset($c,'leads',$account);foreach($ids as $form){Util::numeric($form);if(!in_array($form,LeadDiscovery::connectionForms($c,$account),true))throw new Fault('asset_access_denied','Formulário não selecionado na conexão.');}$forms[$account]=array_values(array_unique($ids));}
        $campaignLookup=in_array('campaign_lookup',$i['permissions'],true);if($campaignLookup){if(!in_array('responses',$i['permissions'],true))throw new Fault('invalid_input','Consulta de campanha exige leitura de respostas.');foreach(array_unique(array_merge(array_map('strval',array_keys($forms)),$all)) as $account)Access::asset($c,'ads',$account);}
        $key=$i['consumer_id'].':'.$c['id'];$value=['consumer_id'=>$i['consumer_id'],'connection_id'=>$c['id'],'enabled'=>$i['enabled'],'permissions'=>$i['permissions'],'forms'=>$forms,'all_forms_accounts'=>$all,'credential_revision'=>$c['revision'],'callback_url'=>$i['callback_url']??'','configured_by'=>get_current_user_id(),'updated_at'=>time()];
        if($value['callback_url']!==''&&(!wp_http_validate_url($value['callback_url'])||wp_parse_url($value['callback_url'],PHP_URL_SCHEME)!=='https'||wp_parse_url($value['callback_url'],PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST)))throw new Fault('invalid_input','Callback deve usar HTTPS no domínio deste site.');
        $old=Store::get('grant',$key);if(($old['revision']??0)!==$i['expected_revision'])throw new Fault('revision_conflict','Releia a concessão.');$candidate=$value;unset($candidate['updated_at']);$fingerprint=Management::revision([$candidate,$i['expected_revision'],Access::principal()]);if(!empty($i['dry_run']))return ['dry_run'=>true,'persisted'=>false,'grant'=>$value,'confirmation'=>Util::cursor(['fingerprint'=>$fingerprint,'expires'=>time()+600])];if(!empty($i['confirmation'])){$preview=Util::uncursor($i['confirmation']);if(!hash_equals($fingerprint,$preview['fingerprint']??''))throw new Fault('revision_conflict','A concessão mudou; simule novamente.');}if(($all!==($old['value']['all_forms_accounts']??[])||$all||$campaignLookup!==in_array('campaign_lookup',$old['value']['permissions']??[],true)||$campaignLookup)&&empty($i['confirmation']))throw new Fault('simulation_required','Simule e confirme a concessão automática ou de consulta de campanhas.');$value['principal']=Access::principal();
        $r=Store::put('grant',$key,$value,$i['expected_revision']);LeadDiscovery::configure($c,$value,$r['revision']);return ['persisted'=>true,'grant_revision'=>$r['revision'],'grant'=>$value];
    }
    public static function grants(): array {Access::admin();$a=[];foreach(Store::list('grant',0,100) as $r)$a[]=$r['value']+['revision'=>$r['revision']];return $a;}
}
final class LeadReader {
    public const CONTRACT='linkedin-lead-reader/1.0.0';
    private string $consumer;
    private array $attempt=[];
    public function __construct(string $consumer) {if($consumer!==''&&!PublicApi::registered($consumer))throw new Fault('consumer_unregistered','Consumidor não registrado.');$this->consumer=$consumer;}
    public function descriptor(): array {return ['contract'=>PublicApi::contract($this->consumer),'provider'=>Config::SLUG,'version'=>Config::VERSION,'consumer_id'=>$this->consumer,'lead_types'=>['SPONSORED'],'extensions'=>['campaign'=>LeadCampaign::CONTRACT],'methods'=>['descriptor','effective_status','check_access','list_forms','get_form','read_responses','get_response','resolve_campaign','verify_challenge','verify_notification','list_form_events','list_subscriptions','create_subscription','delete_subscription','get_subscription_operation','reconcile_subscription'],'opaque_cursor_transferable'=>false,'credential_secret_export'=>false];}
    private function call(string $method,array $i,callable $fn): array {
        $this->attempt=['remote_effect'=>'none','failure_phase'=>'before_dispatch'];
        $result=Result::run(function()use($method,$i,$fn){Schemas::validate('lead-'.str_replace('_','-',$method),$i);$grantBefore=$this->consumer!==''?Store::get('grant',$this->consumer.':'.$i['connection_id']):null;$principal=$this->consumer===''?Access::principal():null;Http::budget(12,25);$data=['contract'=>PublicApi::contract($this->consumer),'consumer_id'=>$this->consumer]+$fn();if($grantBefore){$grantNow=Store::get('grant',$this->consumer.':'.$i['connection_id']);if(!$grantNow||$grantNow['revision']!==$grantBefore['revision']||!$grantNow['value']['enabled'])throw new Fault('revision_conflict','Concessão alterada durante a operação.',isset($data['ownership_key'])?['ownership_key'=>$data['ownership_key'],'remote_effect'=>$data['remote_effect']??'confirmed']:[]);}if($principal)Access::checkPrincipal($principal);if(strlen(Util::json($data))>700000)throw new Fault('response_limit','Página excedeu o orçamento.');return $data;});if(!$result['success']&&$method==='resolve_campaign'){$result['details']=($result['details']??[])+LeadCampaign::failure($result['code'],$result['details']??[]);$result['retryable']=$result['details']['retryable'];}if(!$result['success']&&$method==='create_subscription')$result['details']=($result['details']??[])+$this->attempt;Audit::record('lead-'.$method,$i,$result,$this->consumer?:null);return $result;
    }
    private function context(array $i,string $permission,bool $requireToken=true): array {
        $c=Connections::get($i['connection_id']);$account=Util::numeric($i['account_id']);Access::asset($c,'leads',$account);
        if($this->consumer===''){
            Access::admin();$g=['all_forms_accounts'=>$c['all_forms_accounts'],'forms'=>$c['forms'],'permissions'=>['metadata','responses','verify','subscriptions','campaign_lookup'],'callback_url'=>'','credential_revision'=>$c['revision']];$gr=0;
        }else{
            if(!PublicApi::registered($this->consumer))throw new Fault('consumer_unregistered','Consumidor não está disponível.');$grant=Store::get('grant',$this->consumer.':'.$c['id']);if(!$grant||!$grant['value']['enabled'])throw new Fault('not_authorized','Consumidor sem concessão ativa.');$g=$grant['value'];$gr=$grant['revision'];
            if($g['credential_revision']!==$c['revision'])throw new Fault('revision_conflict','A credencial mudou; reconfirme a concessão do consumidor.');
        }
        if(!in_array($permission,$g['permissions'],true))throw new Fault('not_authorized','Permissão de domínio não concedida.');
        if(isset($i['credential_revision'])&&$i['credential_revision']!==$c['revision']||isset($i['grant_revision'])&&$i['grant_revision']!==$gr)throw new Fault('revision_conflict','Revisão do contrato de acesso mudou.');
        if(!$c['enabled'])throw new Fault('connection_paused','Conexão pausada.');if($requireToken)Connections::usable($c);
        $forms=LeadDiscovery::forms($c,$g,$account);$c['lead_catalog_revision']=LeadDiscovery::catalog($c['id'],$account)['revision']??0;
        return [$c,$g,$gr,$forms];
    }
    private function formAllowed(string $id,array $forms): void {Util::numeric($id);if(!in_array($id,$forms,true))throw new Fault('asset_access_denied','Formulário não concedido.');}
    private function binding(array $c,int $gr,array $i): string {$q=$i;unset($q['cursor']);return hash('sha256',Util::json([$this->consumer,$this->consumer===''?Access::principal():null,$c['revision'],$gr,$c['lead_catalog_revision']??0,$q]));}
    public function effective_status(array $i): array {
        return $this->call('effective_status',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'metadata',false);return ['descriptor'=>$this->descriptor(),'connection_id'=>$c['id'],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'forms'=>$forms,'all_forms'=>in_array($i['account_id'],$c['all_forms_accounts'],true)&&in_array($i['account_id'],$g['all_forms_accounts']??[],true),'discovery_revision'=>$c['lead_catalog_revision'],'enabled'=>$c['enabled'],'token_configured'=>(bool)$c['token'],'secret_configured'=>(bool)$c['client_secret'],'expires_at'=>$c['expires_at'],'remote_access_verified'=>false];});
    }
    public function check_access(array $i): array {
        return $this->call('check_access',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'metadata');$proof=Adapter::validate($c,'leads',$i['account_id']);$checked=[];foreach(array_slice($forms,0,5) as $id){$r=$this->fetchForm($c,$i['account_id'],$id);$checked[]=['id'=>$id,'version'=>(string)$r['versionId']];}return ['proof'=>$proof,'forms_checked'=>$checked,'forms_remaining'=>max(0,count($forms)-5),'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'lead_responses_read'=>false];});
    }
    private function fetchForm(array $c,string $account,string $form): array {
        $f=Http::request($c,'leadForms/'.Util::numeric($form))['body'];
        if((string)($f['id']??'')!==$form||($f['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$account||!preg_match('/^[0-9]+$/D',(string)($f['versionId']??'')))throw new Fault('asset_access_denied','Formulário ou proprietário divergente.');return $f;
    }
    public function list_forms(array $i): array {
        return $this->call('list_forms',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'metadata');$binding=$this->binding($c,$gr,$i);$at=0;
            if(!empty($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação alterada.');$at=$cur['offset'];}
            $rows=[];foreach(array_slice($forms,$at,5) as $id)$rows[]=$this->fetchForm($c,$i['account_id'],$id);$next=$at+count($rows)<count($forms)?Util::cursor(['binding'=>$binding,'offset'=>$at+count($rows),'expires'=>time()+3600]):null;
            return ['forms'=>$rows,'next_cursor'=>$next,'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'complete'=>$next===null];});
    }
    public function get_form(array $i): array {
        return $this->call('get_form',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'metadata');$this->formAllowed($i['form_id'],$forms);return ['form'=>$this->fetchForm($c,$i['account_id'],$i['form_id']),'credential_revision'=>$c['revision'],'grant_revision'=>$gr];});
    }
    public static function formVersion(string $urn): array {
        if(!preg_match('/^urn:li:versionedLeadGenForm:\(urn:li:leadGenForm:([0-9]+),\s*([0-9]+)\)$/D',$urn,$m))throw new Fault('upstream_invalid','Identidade versionada do formulário inválida.');return ['id'=>$m[1],'version'=>$m[2],'urn'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$m[1].','.$m[2].')'];
    }
    private function response(array $r,string $account,array $forms,?string $form=null): array {
        $f=self::formVersion((string)($r['versionedLeadGenFormUrn']??''));$this->formAllowed($f['id'],$forms);
        if($form!==null&&$f['id']!==$form||($r['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$account||($r['leadType']??'')!=='SPONSORED'||!preg_match('/^[A-Za-z0-9_-]{1,150}$/D',(string)($r['id']??''))||!is_bool($r['testLead']??null))throw new Fault('upstream_invalid','Resposta fora do escopo autorizado.');
        $stamp=$r['submittedAt']??null;if((!is_string($stamp)&&!is_int($stamp))||!preg_match('/^[0-9]{13}$/D',(string)$stamp))throw new Fault('upstream_invalid','submittedAt deve preservar milissegundos.');
        if(is_array($r['formResponse']['answers']??null)){foreach($r['formResponse']['answers'] as $k=>$answer){if(is_array($answer)&&is_string($answer['answerDetails']['textQuestionAnswer']['answer']??null))$r['formResponse']['answers'][$k]['answerDetails']['textQuestionAnswer']['answer']=trim($answer['answerDetails']['textQuestionAnswer']['answer']);}}
        $campaign=LeadCampaign::metadata($r,$account);
        return ['campaign'=>$campaign,'identity'=>['source'=>'linkedin','account_id'=>$account,'form_id'=>$f['id'],'response_id'=>(string)$r['id'],'submitted_at_ms'=>(string)$stamp],'form_version'=>$f['version'],'raw'=>$r];
    }
    private function responseGuard(array $i,array $c,array $g,int $gr): callable {
        $principal=$this->consumer===''?Access::principal():($g['principal']??['user_id'=>$g['configured_by']??0,'channel'=>null]);
        return function()use($i,$c,$gr,$principal){Access::checkPrincipal($principal);[$now,$grant,$revision,$forms]=$this->context($i,'responses');if($now['revision']!==$c['revision']||$revision!==$gr)throw new Fault('revision_conflict','A autorização mudou durante a leitura.');$this->formAllowed($i['form_id'],$forms);};
    }
    public function read_responses(array $i): array {
        return $this->call('read_responses',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'responses');$this->formAllowed($i['form_id'],$forms);
            $from=$i['from_ms'];$to=$i['to_ms'];if(strcmp($from,$to)>0||(int)$to-(int)$from>31*86400000)throw new Fault('invalid_input','Janela de leads limitada a 31 dias.');
            $binding=$this->binding($c,$gr,$i);$start=0;$version=$i['form_version'];
            if(!empty($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação fora da concessão/seleção.');$start=$cur['offset'];}
            $q=['q'=>'owner','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'leadType'=>['leadType'=>'SPONSORED'],'versionedLeadGenFormUrn'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$i['form_id'].','.$version.')','submittedAtTimeRange'=>['start'=>$from,'end'=>$to],'start'=>$start,'count'=>50,'limitedToTestLeads'=>$i['test_only']??false];
            $guard=$this->responseGuard($i,$c,$g,$gr);$r=LeadCampaign::read($c,'leadFormResponses',$q,$guard);$guard();$elements=Adapter::elements($r);if(count($elements)>50)throw new Fault('upstream_invalid','Página de leads excedeu o limite.');$rows=[];
            foreach($elements as $x){$v=$this->response($x,$i['account_id'],$forms,$i['form_id']);$stamp=$v['identity']['submitted_at_ms'];if($v['form_version']!==$version||strcmp($stamp,$from)<0||strcmp($stamp,$to)>0)throw new Fault('upstream_invalid','Resposta fora da versão/janela.');$rows[]=$v;}
            $more=Adapter::more($r,$start,count($elements),50);$next=$more?Util::cursor(['binding'=>$binding,'offset'=>$start+count($elements),'expires'=>time()+86400]):null;
            return ['responses'=>$rows,'next_cursor'=>$next,'coverage'=>['complete'=>!$more,'all_rows_guaranteed'=>null,'from_ms'=>$from,'to_ms'=>$to],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'commercial_effects'=>false];});
    }
    public function get_response(array $i): array {
        return $this->call('get_response',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'responses');$this->formAllowed($i['form_id'],$forms);$guard=$this->responseGuard($i,$c,$g,$gr);$r=LeadCampaign::read($c,'leadFormResponses/'.$i['response_id'],[],$guard);$guard();
            if((string)($r['id']??'')!==$i['response_id'])throw new Fault('upstream_invalid','Resposta divergente.');return ['response'=>$this->response($r,$i['account_id'],$forms,$i['form_id']),'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'commercial_effects'=>false];});
    }
    public function resolve_campaign(array $i): array {
        return $this->call('resolve_campaign',$i,function()use($i){
            [$c,$g,$gr,$forms]=$this->context($i,'campaign_lookup');
            if(!in_array('responses',$g['permissions'],true))throw new Fault('not_authorized','Leitura da resposta não concedida.');
            Access::asset($c,'ads',$i['account_id']);$this->formAllowed($i['form_id'],$forms);
            $principal=$this->consumer===''?Access::principal():($g['principal']??['user_id'=>$g['configured_by']??0,'channel'=>null]);
            $guard=function()use($i,$c,$gr,$principal){
                Access::checkPrincipal($principal);[$current,$grant,$revision,$forms]=$this->context($i,'campaign_lookup');
                if($current['revision']!==$c['revision']||$revision!==$gr||!in_array('responses',$grant['permissions'],true))throw new Fault('revision_conflict','A autorização mudou durante a consulta.');
                Access::asset($current,'ads',$i['account_id']);$this->formAllowed($i['form_id'],$forms);
            };
            $guard();Http::budget(3,25);
            $raw=LeadCampaign::read($c,'leadFormResponses/'.$i['response_id'],[],$guard);$guard();
            if((string)($raw['id']??'')!==$i['response_id'])throw new Fault('upstream_invalid','Resposta divergente.');
            $response=$this->response($raw,$i['account_id'],$forms,$i['form_id']);
            $campaign=LeadCampaign::lookup($c,$response['campaign'],$guard);$guard();
            return ['campaign'=>$campaign,'response_identity'=>$response['identity'],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'remote_effect'=>'none','commercial_effects'=>false];
        });
    }
    public function verify_challenge(array $i): array {
        return $this->call('verify_challenge',$i,function()use($i){[$c]=$this->context($i,'verify',false);if(!$c['client_secret'])throw new Fault('not_configured','Client secret ausente.');if(isset($i['application_id'])&&$i['application_id']!==$c['application_id'])throw new Fault('asset_access_denied','App divergente.');return ['challengeCode'=>$i['challenge_code'],'challengeResponse'=>hash_hmac('sha256',$i['challenge_code'],$c['client_secret']),'credential_revision'=>$c['revision']];});
    }
    public function verify_notification(array $i): array {
        return $this->call('verify_notification',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'verify',false);if(!$c['client_secret'])throw new Fault('not_configured','Client secret ausente.');$raw=$i['raw_body'];
            if(!hash_equals(hash_hmac('sha256','hmacsha256='.$raw,$c['client_secret']),$i['signature']))throw new Fault('signature_invalid','Assinatura recusada.');
            $p=json_decode($raw,true,48,JSON_BIGINT_AS_STRING);if(!is_array($p)||($p['type']??'')!=='LEAD_ACTION'||($p['leadType']??'')!=='SPONSORED'||(is_array($p['owner']??null)?($p['owner']['sponsoredAccount']??''):($p['owner']??''))!=='urn:li:sponsoredAccount:'.$i['account_id']||!in_array($p['leadAction']??'',['CREATED','DELETED'],true))throw new Fault('notification_out_of_scope','Notificação fora do escopo.');
            $f=self::formVersion((string)($p['leadGenForm']??''));$this->formAllowed($f['id'],$forms);if(!preg_match('/^urn:li:leadGenFormResponse:([A-Za-z0-9_-]{1,150})$/D',(string)($p['leadGenFormResponse']??''),$m)||!preg_match('/^[0-9]{13}$/D',(string)($p['occurredAt']??'')))throw new Fault('upstream_invalid','Notificação sem identidade temporal válida.');
            return ['verified'=>true,'notification'=>$p,'form_id'=>$f['id'],'form_version'=>$f['version'],'response_id'=>$m[1],'occurred_at_ms'=>(string)$p['occurredAt'],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'receipt_persisted'=>false,'consumer_must_persist_before_ack'=>true];});
    }
    public function list_form_events(array $i): array {return $this->call('list_form_events',$i,function()use($i){if(isset($i['consumer_id'])&&$i['consumer_id']!==$this->consumer)throw new Fault('not_authorized','Consumidor divergente.');[$c,$g,$gr]=$this->context($i,'metadata',false);return LeadDiscovery::events($this->consumer,$c,$g,$gr,$i);});}
    public function list_subscriptions(array $i): array {
        return $this->call('list_subscriptions',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'subscriptions');$r=Http::request($c,'leadNotifications',['q'=>'criteria','owner'=>['value'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']]],'leadType'=>['leadType'=>'SPONSORED'],'start'=>$i['offset']??0,'count'=>50])['body'];$rows=Adapter::elements($r);$safe=[];foreach($rows as $v){try{$f=self::formVersion((string)($v['versionedForm']??$v['versionedFormUrn']??''));}catch(Fault $e){continue;}if(in_array($f['id'],$forms,true)&&($v['owner']['sponsoredAccount']??'')==='urn:li:sponsoredAccount:'.$i['account_id'])$safe[]=$v;}$more=Adapter::more($r,$i['offset']??0,count($rows),50);return ['subscriptions'=>$safe,'next_offset'=>$more?($i['offset']??0)+count($rows):null,'ownership_not_inferred'=>true];});
    }
    private function wanted(array $i,array $g): array {
        $url=$i['callback_url'];if(!wp_http_validate_url($url)||wp_parse_url($url,PHP_URL_SCHEME)!=='https'||wp_parse_url($url,PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST))throw new Fault('invalid_input','Callback deve usar HTTPS neste site.');
        if($this->consumer!==''&&$url!==$g['callback_url'])throw new Fault('not_authorized','Callback diferente da concessão.');
        return ['webhook'=>$url,'owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'versionedForm'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$i['form_id'].','.$i['form_version'].')','leadType'=>'SPONSORED'];
    }
    private static function equivalent(array $a,array $b): bool {return ($a['webhook']??'')===$b['webhook']&&($a['owner']??null)===$b['owner']&&($a['leadType']??'')==='SPONSORED'&&($a['versionedForm']??$a['versionedFormUrn']??'')===$b['versionedForm'];}
    /** All subscription writers share one site-local database lock, across consumers and connections. */
    private static function resourceKey(array $want): string {
        return hash('sha256',Util::json([$want['owner'],$want['leadType'],$want['versionedForm']]));
    }
    private static function migrateJournal(): void {
        $m=Store::get('migration','subscriptions-020');if($m&&$m['value']['complete'])return;
        $after=$m['value']['after']??'';$rows=Store::scan('subscription',$after,50);
        foreach($rows as $row){$v=$row['value'];$rk=self::resourceKey($v['wanted']);$index=Store::get('subscription_guard',$rk);$keys=$index['value']['keys']??[];
            if(!in_array($row['key'],$keys,true)){$keys[]=$row['key'];Store::put('subscription_guard',$rk,['keys'=>$keys],$index['revision']??0);}$after=$row['key'];}
        $done=count($rows)<50;Store::put('migration','subscriptions-020',['after'=>$after,'complete'=>$done],$m['revision']??0);
        if(!$done)throw new Fault('migration_pending','O diário de assinaturas está sendo indexado. Repita a operação; nenhum POST foi enviado.');
    }
    private function dispatchGuard(array $i,array $c,int $gr,array $want,?array $principal): void {
        [$now,$g,$revision,$forms]=$this->context($i,'subscriptions');
        if($now['revision']!==$c['revision']||$revision!==$gr)throw new Fault('revision_conflict','O acesso mudou antes do envio.');
        $f=self::formVersion($want['versionedForm']);$this->formAllowed($f['id'],$forms);
        $this->wanted(['account_id'=>$i['account_id'],'form_id'=>$f['id'],'form_version'=>$f['version'],'callback_url'=>$want['webhook']],$g);
        if($principal)Access::checkPrincipal($principal);
    }
    private function ownOperation(string $key,array $i,array $c,array $forms): array {
        $r=Store::get('subscription',$key);if(!$r)throw new Fault('ownership_missing','Assinatura sem autoria local.');$v=$r['value'];
        if($v['consumer']!==$this->consumer||$v['connection_id']!==$c['id']||$v['wanted']['owner']['sponsoredAccount']!=='urn:li:sponsoredAccount:'.$i['account_id'])throw new Fault('not_authorized','Operação fora deste consumidor, conexão ou conta.');
        $this->formAllowed(self::formVersion($v['wanted']['versionedForm'])['id'],$forms);return $r;
    }
    private static function projection(string $key,array $r,bool $replayed=false): array {
        $v=$r['value'];return ['ownership_key'=>$key,'operation_revision'=>$r['revision'],'subscription_id'=>$v['remote_id'],'state'=>$v['state'],'replayed'=>$replayed,'last_code'=>$v['last_code']??null,'remote_effect'=>$v['remote_effect']??($v['state']==='confirmed'?'confirmed':'unknown'),'credential_revision'=>$v['credential_revision'],'delivery_verified'=>false,'requires_reconciliation'=>in_array($v['state'],['creating','dispatching','uncertain','deleting'],true)];
    }
    public function create_subscription(array $i): array {
        return $this->call('create_subscription',$i,function()use($i){
            [$c,$g,$gr,$forms]=$this->context($i,'subscriptions');$this->formAllowed($i['form_id'],$forms);$want=$this->wanted($i,$g);
            $principal=$this->consumer===''?Access::principal():null;$key=hash('sha256',Util::json([$this->consumer,$c['id'],$i['idempotency_key']]));$this->attempt['ownership_key']=$key;
            return Store::lock('subscriptions-global',function()use($i,$c,$gr,$want,$key,$principal,$forms){
                self::migrateJournal();$alias=Store::get('subscription_alias',$key);
                if($alias){$canonical=$alias['value']['ownership_key'];$r=$this->ownOperation($canonical,$i,$c,$forms);if(!self::equivalent($r['value']['wanted'],$want))throw new Fault('idempotency_conflict','Chave de assinatura reutilizada.');$this->dispatchGuard($i,$c,$gr,$want,$principal);return self::projection($canonical,$r,true)+['adopted'=>true];}
                $old=Store::get('subscription',$key);
                if($old){$this->attempt=['ownership_key'=>$key,'remote_effect'=>$old['value']['remote_effect']??'unknown','failure_phase'=>'existing_operation'];if(!self::equivalent($old['value']['wanted'],$want))throw new Fault('idempotency_conflict','Chave de assinatura reutilizada.');if(PublicApi::contract($this->consumer)==='linkedin-lead-reader/1.0.0'&&!in_array($old['value']['state'],['confirmed','deleted'],true))throw new Fault('operation_uncertain','Intenção sem confirmação; consulte o diário pelo contrato 1.1.',['ownership_key'=>$key,'remote_effect'=>$old['value']['remote_effect']??'unknown']);return self::projection($key,$old,true);}
                $rk=self::resourceKey($want);$index=Store::get('subscription_guard',$rk);$keys=$index['value']['keys']??[];
                $active=[];foreach($keys as $existing){$r=Store::get('subscription',$existing);if(!$r)throw new Fault('journal_inconsistent','Referência do diário ausente; envio bloqueado.');if(!in_array($r['value']['state'],['deleted','rejected_before_dispatch'],true))$active[$existing]=$r;}
                if(count($active)===1){$existing=array_key_first($active);$r=$active[$existing];$v=$r['value'];
                    if($v['state']==='confirmed'&&!empty($v['remote_id'])&&$v['consumer']===$this->consumer&&$v['connection_id']===$c['id']&&($v['application_id']??'')!==''&&$v['application_id']===$c['application_id']&&($v['client_id']??'')===$c['client_id']&&self::equivalent($v['wanted'],$want)){
                        $this->dispatchGuard($i,$c,$gr,$want,$principal);$remote=Http::request($c,'leadNotifications/'.$v['remote_id'])['body'];$this->dispatchGuard($i,$c,$gr,$want,$principal);
                        if(!self::equivalent($remote,$want)||(string)($remote['id']??'')!==$v['remote_id'])throw new Fault('ownership_mismatch','O objeto remoto não corresponde ao recibo próprio.');
                        $r=ConnectionChanges::transaction(static function()use($key,$existing,$r,$v,$c,$gr){$v['credential_revision']=$c['revision'];$v['grant_revision']=$gr;$updated=Store::put('subscription',$existing,$v,$r['revision']);Store::put('subscription_alias',$key,['ownership_key'=>$existing],0);return $updated;});
                        return self::projection($existing,$r,true)+['adopted'=>true];
                    }
                }
                if($active)throw new Fault('subscription_intent_blocked','Este formulário possui uma intenção ativa ou sem confirmação. Reconcilie a operação existente antes de criar outra.');
                $matches=$this->findSubscriptions($c,$want);if($matches)throw new Fault('subscription_exists_unowned','Assinatura equivalente já existe; autoria não foi presumida.');
                $v=['consumer'=>$this->consumer,'connection_id'=>$c['id'],'credential_revision'=>$c['revision'],'grant_revision'=>$gr,'application_id'=>$c['application_id'],'client_id'=>$c['client_id'],'wanted'=>$want,'state'=>'prepared','remote_id'=>null,'created_at'=>time(),'remote_effect'=>'none'];
                $keys[]=$key;Store::put('subscription_guard',$rk,['keys'=>$keys],$index['revision']??0);$r=Store::put('subscription',$key,$v);
                $dispatched=false;
                try{
                    $remote=Http::request($c,'leadNotifications',[],'POST',$want,function()use($i,$c,$gr,$want,$principal,$key,&$r,&$v,&$dispatched){
                        $this->dispatchGuard($i,$c,$gr,$want,$principal);$v['state']='dispatching';$v['remote_effect']='unknown';$r=Store::put('subscription',$key,$v,$r['revision']);$dispatched=true;$this->attempt=['ownership_key'=>$key,'remote_effect'=>'unknown','failure_phase'=>'after_dispatch'];
                    });
                    $remoteId=(string)($remote['id']?:($remote['body']['id']??''));
                    if(!preg_match('/^[0-9]+$/D',$remoteId))throw new Fault('operation_uncertain','O fornecedor não retornou um ID confirmado.');
                    // Persist the receipt before any further authorization or remote read.
                    $v['remote_id']=$remoteId;$v['state']='confirmed';$v['remote_effect']='confirmed';$this->attempt['remote_effect']='confirmed';$r=Store::put('subscription',$key,$v,$r['revision']);
                    try{$this->dispatchGuard($i,$c,$gr,$want,$principal);}catch(Fault $e){throw new Fault($e->reason,$e->getMessage(),['ownership_key'=>$key,'remote_effect'=>'confirmed']);}
                    return self::projection($key,$r);
                }catch(Fault $e){
                    if(($v['state']??'')!=='confirmed'){$v['state']=$dispatched?'uncertain':'rejected_before_dispatch';$v['remote_effect']=$dispatched?'unknown':'none';$v['last_code']=$e->reason;$r=Store::put('subscription',$key,$v,$r['revision']);}
                    throw new Fault($e->reason,$e->getMessage(),$e->details+['ownership_key'=>$key,'remote_effect'=>$v['remote_effect']]);
                }
            });
        });
    }
    private function findSubscriptions(array $c,array $want): array {
        $start=0;$found=[];for($page=0;$page<8;$page++){$r=Http::request($c,'leadNotifications',['q'=>'criteria','owner'=>['value'=>$want['owner']],'leadType'=>['leadType'=>'SPONSORED'],'start'=>$start,'count'=>50])['body'];$rows=Adapter::elements($r);foreach($rows as $row)if(self::equivalent($row,$want))$found[]=$row;if(!Adapter::more($r,$start,count($rows),50))return $found;$start+=count($rows);}throw new Fault('coverage_incomplete','Listagem de assinaturas incompleta; criação recusada.');
    }
    public function get_subscription_operation(array $i): array {
        return $this->call('get_subscription_operation',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'subscriptions',false);return self::projection($i['ownership_key'],$this->ownOperation($i['ownership_key'],$i,$c,$forms));});
    }
    public function reconcile_subscription(array $i): array {
        return $this->call('reconcile_subscription',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'subscriptions');$key=$i['ownership_key'];
            return Store::lock('subscriptions-global',function()use($i,$c,$g,$gr,$forms,$key){self::migrateJournal();$r=$this->ownOperation($key,$i,$c,$forms);$v=$r['value'];
                if($r['revision']!==$i['expected_operation_revision'])throw new Fault('revision_conflict','O diário mudou.');
                if(in_array($v['state'],['prepared','rejected_before_dispatch'],true)){$v['state']='rejected_before_dispatch';$v['remote_effect']='none';$r=Store::put('subscription',$key,$v,$r['revision']);return self::projection($key,$r);}
                if(!$v['remote_id'])throw new Fault('operation_uncertain','Intenção sem recibo remoto. Uma listagem vazia não prova ausência de criação; reenvio permanece bloqueado.',['ownership_key'=>$key,'remote_effect'=>'unknown']);
                if($c['revision']!==$v['credential_revision']){
                    if(empty($i['authorize_current_context'])||empty($v['application_id'])||$v['application_id']!==$c['application_id']||($v['client_id']??'')!==$c['client_id'])throw new Fault('context_rebind_required','A reconciliação requer autorização explícita e identidade de aplicativo preservada.');
                }
                $this->dispatchGuard($i,$c,$gr,$v['wanted'],$this->consumer===''?Access::principal():null);
                try{$remote=Http::request($c,'leadNotifications/'.$v['remote_id'])['body'];if(!self::equivalent($remote,$v['wanted'])||(string)($remote['id']??$v['remote_id'])!==$v['remote_id'])throw new Fault('ownership_mismatch','O objeto remoto não corresponde ao recibo.');$v['state']='confirmed';$v['remote_effect']='confirmed';}
                catch(Fault $e){if($e->reason!=='resource_not_found')throw $e;if(!in_array($v['state'],['deleting','deleted'],true))throw new Fault('operation_uncertain','A ausência atual não confirma a criação anterior.');$v['state']='deleted';$v['remote_effect']='removed';}
                $v['credential_revision']=$c['revision'];$v['grant_revision']=$gr;$v['last_code']=null;$r=Store::put('subscription',$key,$v,$r['revision']);return self::projection($key,$r);
            });
        });
    }
    public function delete_subscription(array $i): array {
        return $this->call('delete_subscription',$i,function()use($i){[$c,$g,$gr,$forms]=$this->context($i,'subscriptions');$key=$i['ownership_key'];$principal=$this->consumer===''?Access::principal():null;
            return Store::lock('subscriptions-global',function()use($key,$c,$i,$forms,$gr,$principal){self::migrateJournal();$r=$this->ownOperation($key,$i,$c,$forms);$v=$r['value'];
                if($v['credential_revision']!==$c['revision'])throw new Fault('context_rebind_required','Reconcilie a operação com a credencial atual antes de removê-la.');
                if($v['state']==='deleted')return self::projection($key,$r,true);
                if(!$v['remote_id']||$v['state']!=='confirmed')throw new Fault('operation_uncertain','Reconcilie o recibo antes da remoção.');
                $remote=Http::request($c,'leadNotifications/'.$v['remote_id'])['body'];if(!self::equivalent($remote,$v['wanted']))throw new Fault('ownership_mismatch','Assinatura remota mudou.');
                $dispatched=false;
                try{Http::request($c,'leadNotifications/'.$v['remote_id'],[],'DELETE',null,function()use($i,$c,$gr,$principal,$key,&$v,&$r,&$dispatched){$this->dispatchGuard($i,$c,$gr,$v['wanted'],$principal);$v['state']='deleting';$v['remote_effect']='unknown';$r=Store::put('subscription',$key,$v,$r['revision']);$dispatched=true;$this->attempt=['ownership_key'=>$key,'remote_effect'=>'unknown','failure_phase'=>'after_dispatch'];});
                    $v['state']='deleted';$v['remote_effect']='removed';$r=Store::put('subscription',$key,$v,$r['revision']);
                    try{$this->dispatchGuard($i,$c,$gr,$v['wanted'],$principal);}catch(Fault $e){throw new Fault($e->reason,$e->getMessage(),['ownership_key'=>$key,'remote_effect'=>'removed']);}
                    return self::projection($key,$r);
                }catch(Fault $e){if($dispatched&&$v['state']!=='deleted'){$v['last_code']=$e->reason;Store::put('subscription',$key,$v,$r['revision']);}throw new Fault($e->reason,$e->getMessage(),$e->details+['ownership_key'=>$key,'remote_effect'=>$dispatched?$v['remote_effect']:'none']);}
            });
        });
    }
}
