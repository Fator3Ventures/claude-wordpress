<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class Config {
 public const VERSION='0.17.1'; public const SLUG='wp-mcp-linkedin-fator3'; public const NAME='Fator3 MCP LinkedIn';
 public const KEY='f3_linkedin'; public const TABLE='f3_linkedin_records'; public const PREFIX='linkedin';
 public const REST='f3-linkedin/v1'; public const CHANNELS=['pages','ads','leads'];
 public const API_VERSION='202609'; public const API_PATTERN='/^20[0-9]{2}(0[1-9]|1[0-2])$/D';
 public const DIR=__DIR__.'/../'; public const FILE=__DIR__.'/../wp-mcp-linkedin-fator3.php';
}
