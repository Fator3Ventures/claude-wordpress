<?php
/**
 * Módulo llms-full-txt.
 *
 * Rota virtual `/llms-full.txt` com o TEXTO INTEGRAL de cada item selecionado.
 * Mesma seleção, mesmas exclusões e mesma precedência de emissor do índice
 * curto: a regra mora em `F3Base_Llms` e no módulo `llms-txt-reserva`, e este
 * módulo a CONSULTA — dois arquivos que listassem conjuntos diferentes seriam
 * dois vereditos sobre o mesmo site.
 *
 * DESLIGADO POR PADRÃO, e a chave é `bots_ia.llms_full_txt`. Com ela desligada o
 * módulo fecha INATIVO: nenhum hook é registrado, a rota não existe e não há
 * superfície pública nenhuma — a mesma física da chave-mestra do llms.txt. O
 * motivo é declarado: o arquivo é uma segunda cópia integral do site em texto
 * puro, o custo é certo e o ganho é hipótese; ligar é um clique.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Texto integral em /llms-full.txt.
 */
final class F3Base_Modulo_Llms_Full_Txt extends F3Base_Modulo {

	/**
	 * Caminho público do recurso.
	 */
	public const CAMINHO = '/llms-full.txt';

	/**
	 * CARIMBO PRÓPRIO desta rota, e o carimbo do índice curto é outro.
	 *
	 * Até a 1.0.1 as duas rotas gravavam `F3Base_Atividade::ULTIMO_LLMS`: a
	 * resposta de um endereço apagava a do outro, e a tela mostrava uma única
	 * linha de "última resposta" que ora falava do índice, ora do texto
	 * integral, sem dizer qual. Dois endereços públicos são duas atividades.
	 */
	public const ATIVIDADE = 'ultimo_llms_full_servido';

	/**
	 * Quem respondeu, para o cabeçalho `X-F3Base-Mecanismo`.
	 */
	public const MECANISMO = 'rota-texto-integral';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'llms-full-txt';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Texto integral em llms-full.txt', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Serve /llms-full.txt com o texto integral de cada item que o llms.txt lista — mesma seleção, mesmas exclusões e mesma precedência de emissor. Desligado por padrão: publica uma segunda cópia integral do site em texto puro, e com a chave desligada não há hook, rota nem superfície pública.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'template_redirect',
				'metodo'     => 'talvez_servir',
				'prioridade' => 0,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_llms' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$emissor = F3Base_Modulo_Llms_Txt_Reserva::emissor();

		return array(
			array(
				'rotulo'   => __( 'Endereço público sem outro dono', 'f3base' ),
				'presente' => (bool) $emissor['serve'],
				'detalhe'  => (string) $emissor['motivo'],
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( self::ATIVIDADE, __( 'Última resposta pela rota de texto integral', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( empty( $config['ligado'] ) ) {
			return $this->inativo(
				__( 'recurso llms.txt desligado na configuração de bots de IA: sem o índice curto não há texto integral a publicar, e nenhum hook é registrado.', 'f3base' )
			);
		}

		if ( empty( $config['full'] ) ) {
			return $this->inativo(
				__( 'texto integral desligado na configuração: nenhum hook, nenhuma rota e nenhuma superfície pública. O arquivo publica uma segunda cópia integral do site em texto puro — o custo é certo e o ganho é hipótese —, e ligar a chave o faz existir na requisição seguinte, sem release nova.', 'f3base' )
			);
		}

		$emissor = F3Base_Modulo_Llms_Txt_Reserva::emissor();

		if ( ! $emissor['serve'] ) {
			return $this->ativo( (string) $emissor['motivo'] );
		}

		$itens = F3Base_Modulo_Llms_Txt_Reserva::selecao( $config );

		if ( array() === $itens ) {
			return $this->degradado(
				__( 'ligado e sem item nenhum a publicar: a rota responderia só com o cabeçalho do site. Preencha a seleção curada ou publique conteúdo dos tipos declarados.', 'f3base' )
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: número de itens com texto integral. */
				_n( 'respondendo no endereço público com o texto integral de %d item.', 'respondendo no endereço público com o texto integral de %d itens.', count( $itens ), 'f3base' ),
				count( $itens )
			)
		);
	}

	/**
	 * Serve a rota quando ela é a responsável pelo endereço.
	 *
	 * @return void
	 */
	public function talvez_servir(): void {
		if ( ! F3Base_Modulo_Llms_Txt_Reserva::requisicao_de( self::CAMINHO ) ) {
			return;
		}

		$config = $this->config();

		if ( empty( $config['full'] ) ) {
			return;
		}

		if ( ! F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve'] ) {
			return;
		}

		$itens    = F3Base_Modulo_Llms_Txt_Reserva::selecao( $config );
		$conteudo = self::montar( $itens, $config );

		F3Base_Atividade::registrar(
			self::ATIVIDADE,
			array(
				'bytes'     => strlen( $conteudo ),
				'itens'     => count( $itens ),
				'respondeu' => self::MECANISMO,
			)
		);

		F3Base_Modulo_Llms_Txt_Reserva::responder( $conteudo, $config, self::MECANISMO );
	}

	/**
	 * Monta o texto integral. Regra pura sobre itens já selecionados.
	 *
	 * Cada item sai com título, URL, data e o corpo limpo da interface — a mesma
	 * limpeza do resumo, SEM CORTE NENHUM: formulário, script, estilo,
	 * navegação, botão e SVG não são texto do site.
	 *
	 * O CORTE NÃO É PEDIDO COM UM TETO ENORME, e é aí que morava o defeito: até
	 * a 1.0.1 esta função chamava `resumo_limpo( $corpo, PHP_INT_MAX )`, e
	 * `wp_trim_words()` repassa `$palavras + 1` a `preg_split()` — `PHP_INT_MAX
	 * + 1` é float, e o PHP 8.1+ derruba a requisição com `TypeError`. A rota
	 * pública respondia 500 assim que a chave `full` era ligada. Quem não corta
	 * chama `F3Base_Llms::limpar()`, que não tem corte a fazer.
	 *
	 * @param array<int,array<string,mixed>> $itens  Itens selecionados e ordenados.
	 * @param array<string,mixed>            $config Configuração normalizada.
	 * @return string
	 */
	public static function montar( array $itens, array $config ): string {
		$linhas   = array();
		$linhas[] = '# ' . wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		$linhas[] = '';

		/* A MESMA precedência do índice curto, e ela mora num lugar só. */
		$frase = F3Base_Modulo_Llms_Txt_Reserva::primeira_frase( $config );

		if ( '' !== $frase ) {
			$linhas[] = '> ' . $frase;
			$linhas[] = '';
		}

		foreach ( $itens as $item ) {
			$url = isset( $item['url'] ) ? trim( (string) $item['url'] ) : '';

			if ( '' === $url ) {
				continue;
			}

			$titulo = isset( $item['titulo'] ) ? trim( (string) $item['titulo'] ) : '';

			$linhas[] = '## ' . ( '' !== $titulo ? $titulo : $url );
			$linhas[] = 'URL: ' . $url;

			$data = isset( $item['data'] ) ? trim( (string) $item['data'] ) : '';

			if ( '' !== $data ) {
				$linhas[] = 'Data: ' . $data;
			}

			$linhas[] = '';

			$corpo = isset( $item['conteudo'] ) ? (string) $item['conteudo'] : '';
			$corpo = '' !== trim( $corpo )
				? F3Base_Llms::limpar( $corpo )
				: trim( (string) ( $item['descricao'] ?? '' ) );

			if ( '' !== $corpo ) {
				$linhas[] = $corpo;
				$linhas[] = '';
			}
		}

		return implode( "\n", $linhas ) . "\n";
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$config = F3Base_Options::ler( 'f3base_llms' );

		return is_array( $config ) ? $config : array();
	}
}
