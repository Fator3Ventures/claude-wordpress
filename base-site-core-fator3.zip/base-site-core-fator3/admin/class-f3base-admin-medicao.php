<?php
/**
 * O menu MEDIÇÃO — casa própria dos números do site.
 *
 * POR QUE ELE EXISTE. A medição morava num quadro no fim da tela de
 * configuração, depois dos campos e antes do diagnóstico. Quem abria aquela
 * tela ia gravar uma option; quem quer saber o que os visitantes fizeram tem
 * outra pergunta, e ela não é sub-item de configuração nenhuma. O quadro
 * também competia por atenção com trinta campos de formulário, e o operador
 * chegava nele rolando por assuntos que não eram o dele.
 *
 * O QUE ELE RESPONDE, e a ordem é essa: quanto o site recebeu no período, o
 * que aconteceu em cada evento declarado — com a pergunta que cada um responde,
 * em português comum — e em que páginas. A tela de configuração continua
 * existindo para as options; ela perdeu o quadro e ganhou um caminho para cá.
 *
 * O VAZIO É RESPOSTA, E É A TELA MAIS IMPORTANTE DAQUI. Site novo não tem
 * dado, e uma tabela de zeros parece medição feita. Sem linha nenhuma esta tela
 * diz o que está coletando, desde quando, e — quando falta alguma coisa —
 * exatamente o que falta e onde ligar. Nunca uma tela em branco.
 *
 * CADA QUADRO DIZ DE QUAL DAS DUAS TABELAS ELE VEM, e isso é da 1.0.1. A tela
 * mostrava a tabela bruta e os quadros do agregado sem dizer em lugar nenhum
 * que são DUAS tabelas com propósitos diferentes. Quem operava foi ao banco
 * para entender o que via, encontrou `f3base_comportamento` — que soma na mesma
 * linha por desenho — e concluiu que o registro estava sendo reescrito. Não
 * estava: as linhas do registro são distintas, cada uma com `id` próprio. O que
 * faltava era a tela dizer de onde cada número vinha, e a frase de cada tabela
 * tem produtor único, no módulo.
 *
 * E O HORÁRIO DIZ DE ONDE ELE VEIO. O carimbo de cada acionamento sai da âncora
 * do lote, e a âncora tem três procedências de qualidades diferentes — a origem
 * do navegador, a âncora derivada do servidor e, nas linhas gravadas antes
 * desta versão, a hora da CHEGADA do lote. Uma tela que afirmasse um horário
 * sem que nada soubesse de onde ele veio faria as três parecerem a mesma coisa.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Menu de primeiro nível com o comportamento dos visitantes.
 */
final class F3Base_Admin_Medicao {

	/**
	 * Slug do menu.
	 */
	public const SLUG = 'f3base-medicao';

	/**
	 * Registra os ganchos da tela.
	 *
	 * @return void
	 */
	public static function iniciar(): void {
		add_action( 'admin_menu', array( __CLASS__, 'registrar_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enfileirar' ) );
	}

	/**
	 * Menu de PRIMEIRO NÍVEL, e não um submenu do site-core.
	 *
	 * A posição fica logo acima da tela de configuração: quem abre o painel
	 * para ver como o site está indo encontra a medição antes de encontrar as
	 * chaves que a produzem.
	 *
	 * @return void
	 */
	public static function registrar_menu(): void {
		add_menu_page(
			__( 'Medição', 'f3base' ),
			__( 'Medição', 'f3base' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-chart-bar',
			57
		);
	}

	/**
	 * Enfileira o estilo já existente do plugin.
	 *
	 * @param string $tela Hook da tela atual.
	 * @return void
	 */
	public static function enfileirar( string $tela ): void {
		if ( 'toplevel_page_' . self::SLUG !== $tela ) {
			return;
		}

		wp_enqueue_style(
			'f3base-admin',
			F3BASE_PLUGIN_URL . 'admin/assets/f3base-admin.css',
			array(),
			F3BASE_PLUGIN_VERSAO
		);
	}

	/**
	 * Desenha a tela.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão para ver a medição deste site.', 'f3base' ), 403 );
		}

		echo '<div class="wrap f3base-tela">';

		printf( '<h1>%s</h1>', esc_html__( 'Medição', 'f3base' ) );

		if ( ! class_exists( 'F3Base_Modulo_Comportamento' ) ) {
			printf(
				'<p class="f3base-vazio">%s</p></div>',
				esc_html__( 'O módulo que guarda a medição não está disponível nesta instalação do plugin.', 'f3base' )
			);

			return;
		}

		self::render_controle_da_medicao();

		$resumo = F3Base_Modulo_Comportamento::resumo();

		/*
		 * QUEM É CONTADO SAI DO MÓDULO, e não desta tela. A frase daqui dizia,
		 * em todo site, "contam apenas as visitas em que o consentimento
		 * permitiu medir" — uma descrição do modo de NEGATIVA POR PADRÃO. No
		 * modo pré-aprovado ninguém consentiu nada: a medição começa na chegada,
		 * por decisão declarada do projeto, e quem lia aquela frase concluía que
		 * estava vendo só quem tinha dito sim. A frase que vem do módulo diz o
		 * que vale nas DUAS políticas — contam as sessões em que a política
		 * vigente permitiu medir, e quem recusou no controle do rodapé fica de
		 * fora — e nomeia qual política está valendo neste site.
		 */
		printf(
			'<p class="f3base-intro">%s %s</p>',
			esc_html(
				sprintf(
					/* translators: %d: período em dias. */
					__( 'O que os visitantes fizeram nos últimos %d dias, somado pelo próprio site a partir do que cada visita registrou ao sair da página. Nada aqui identifica visitante: os números são totais por dia, por página e por tipo de acontecimento.', 'f3base' ),
					(int) $resumo['dias']
				)
			),
			esc_html( F3Base_Modulo_Comportamento::quem_e_contado() )
		);

		/*
		 * O FUSO DO DIA É DITO UMA VEZ, no alto e com produtor único. O corte por
		 * dia dos quadros é UTC — é assim que ele é gravado nas duas tabelas — e
		 * a coluna Horário sai em `wp_date()`, no fuso do site. As duas coisas
		 * estão certas, a diferença é real perto da virada, e sem esta linha quem
		 * soma os dois quadros encontra números que não fecham.
		 */
		printf(
			'<p class="description f3base-fuso-do-dia">%s</p>',
			esc_html( F3Base_Modulo_Comportamento::fuso_do_dia() )
		);

		self::render_estado_da_coleta( $resumo );

		if ( (int) $resumo['linhas'] < 1 ) {
			echo '</div>';

			return;
		}

		/*
		 * A TELA FOI CORTADA PELO USUÁRIO, depois de vê-la. Ficaram três
		 * quadros: a tabela bruta de acionamentos — que é o pedido central —, a
		 * profundidade por página e as saídas para fora. Saíram profundidade em
		 * bloco próprio, fricção, carregamento, erros de JavaScript, páginas com
		 * mais registro e "o que não está nesta tela".
		 *
		 * Bloco cortado é bloco REMOVIDO, e não escondido: um quadro vazio
		 * ocupa a atenção de quem abre a tela e não responde nada.
		 */
		self::render_acionamentos();
		self::render_visitas_por_pagina();
		self::render_profundidade( $resumo );
		self::render_vitais( $resumo );
		self::render_saidas( $resumo );

		echo '</div>';
	}

	/**
	 * ONDE SE DESLIGA ISTO, e a frase vem ANTES de qualquer número.
	 *
	 * O pedido que criou esta linha: *"Permita também que essa medição possa
	 * ser desativada na área de configuração do plugin."* O controle já
	 * existia — `f3base_comportamento.ligado`, na seção de privacidade — e não
	 * ganhou irmão nenhum: uma segunda chave para a mesma decisão seria duas
	 * respostas para "esta instalação mede?", divergindo na primeira vez que
	 * alguém mexesse numa e não na outra. O que faltava era ele ser
	 * ENCONTRÁVEL: quem abre esta tela não tem por que saber que a chave que a
	 * desliga mora na tela ao lado, embaixo de um título sobre privacidade.
	 *
	 * DESLIGADO, A FRASE É A PRIMEIRA COISA DA TELA. Antes disso o
	 * desligamento aparecia no meio de uma lista, depois do parágrafo de
	 * abertura, e o que o operador via primeiro era uma tela sem número nenhum
	 * — que é indistinguível de um site sem visita. Tela vazia sem explicação
	 * devolve quem lê ao ponto de partida.
	 *
	 * @return void
	 */
	private static function render_controle_da_medicao(): void {
		/*
		 * O ENDEREÇO SAI DA CONSTANTE DA OUTRA TELA, e a âncora sai da regra
		 * que aquela tela usa para montar o `id` do sub-campo. Repetir o slug
		 * ou o `id` aqui como literal criaria a segunda fonte que renomear o
		 * campo quebraria em silêncio: o link continuaria existindo e deixaria
		 * de levar a lugar nenhum.
		 */
		$endereco = admin_url( 'admin.php?page=' . F3Base_Admin_Tela::SLUG )
			. '#' . F3Base_Admin_Tela::id_do_subcampo( 'f3base_comportamento', 'ligado' );

		$link = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $endereco ),
			esc_html__( 'Configuração do F3 Base, em Privacidade e retenção', 'f3base' )
		);

		if ( ! F3Base_Modulo_Comportamento::ligado() ) {
			printf(
				'<div class="notice notice-warning f3base-medicao-desligada"><p>%s</p></div>',
				sprintf(
					/* translators: %s: link para o controle na tela de configuração. */
					esc_html__( 'A medição está desligada nesta instalação. Nada é coletado e nada é guardado. O controle fica em %s.', 'f3base' ),
					$link
				)
			);

			return;
		}

		printf(
			'<p class="f3base-intro f3base-controle-da-medicao">%s</p>',
			sprintf(
				/* translators: %s: link para o controle na tela de configuração. */
				esc_html__( 'Esta medição pode ser desligada quando você quiser, no controle "Guardar o resumo no site", em %s. Desligada, as páginas param de enviar e nada novo é guardado; o que já foi guardado continua aqui até o prazo de retenção apagá-lo, e o envio para o Google Analytics, quando houver, não muda.', 'f3base' ),
				$link
			)
		);
	}

	/**
	 * O ESTADO DA COLETA, e é aqui que o vazio vira resposta.
	 *
	 * @param array<string,mixed> $resumo Resumo do período.
	 * @return void
	 */
	private static function render_estado_da_coleta( array $resumo ): void {
		$ligado = F3Base_Modulo_Comportamento::ligado();
		$desde  = F3Base_Modulo_Comportamento::coletando_desde();

		echo '<section class="f3base-bloco">';

		printf( '<h2>%s</h2>', esc_html__( 'Estado da coleta', 'f3base' ) );

		self::render_de_qual_tabela( array( 'agregado' ) );

		/*
		 * O QUE FALTA SAI NOMEADO, e cada item traz onde resolver. Uma tela que
		 * só diz "sem dados" devolve o operador ao ponto de partida: ele não
		 * tem como saber se o site não teve visita, se a coleta está desligada
		 * ou se o consentimento está barrando tudo.
		 */
		$faltas = array();

		if ( ! $ligado ) {
			$faltas[] = __( 'A coleta está DESLIGADA: nada é enviado pelas páginas e nada é guardado. Ligue "Guardar o resumo no site" na tela F3 Base, em Privacidade e retenção.', 'f3base' );
		}

		if ( ! F3Base_Modulo_Comportamento::tabela_pronta() ) {
			$faltas[] = sprintf(
				/* translators: %s: nome da tabela. */
				__( 'A tabela %s não está pronta com as colunas desta versão: as visitas chegam e não têm onde ser gravadas. Desative e reative o plugin para que ele a crie.', 'f3base' ),
				F3Base_Modulo_Comportamento::nome_tabela()
			);
		}

		if ( class_exists( 'F3Base_Modulo_Consentimento' ) && ! F3Base_Modulo_Consentimento::permite_tags() ) {
			$faltas[] = __( 'O consentimento está barrando a medição nesta requisição: enquanto a política do site for de negativa por padrão, só é medido quem aceitar.', 'f3base' );
		}

		if ( array() !== $faltas ) {
			printf( '<p class="f3base-vazio">%s</p>', esc_html__( 'Há coisas faltando para este site medir:', 'f3base' ) );
			echo '<ul class="f3base-faltas">';

			foreach ( $faltas as $falta ) {
				printf( '<li>%s</li>', esc_html( $falta ) );
			}

			echo '</ul>';
		}

		if ( '' === $desde ) {
			printf(
				'<p class="f3base-vazio">%s</p>',
				esc_html__( 'Ainda não há nenhuma visita registrada. Isto não é audiência zero: é ausência de registro. Enquanto ninguém abrir uma página do site depois de a coleta estar no ar, não há o que somar aqui.', 'f3base' )
			);
		} else {
			printf(
				'<p>%s</p>',
				esc_html(
					sprintf(
						/* translators: 1: data do primeiro registro, 2: total de registros no período, 3: período em dias. */
						__( 'Coletando desde %1$s. No período mostrado há %2$s registro(s), somados dos últimos %3$d dias.', 'f3base' ),
						(string) $desde,
						number_format_i18n( (int) $resumo['total'] ),
						(int) $resumo['dias']
					)
				)
			);
		}

		if ( (int) $resumo['linhas'] < 1 && '' !== $desde ) {
			printf(
				'<p class="f3base-vazio">%s</p>',
				esc_html(
					sprintf(
						/* translators: 1: período em dias, 2: data do primeiro registro. */
						__( 'Nada no período: há registros neste site desde %2$s, mas nenhum nos últimos %1$d dias. Ou o site parou de receber visitas, ou a retenção já apagou as linhas antigas do período mostrado.', 'f3base' ),
						(int) $resumo['dias'],
						(string) $desde
					)
				)
			);
		}

		self::render_periodo_maior_que_a_retencao();
		self::render_cortadas( $resumo );

		echo '</section>';
	}

	/**
	 * O PERÍODO DO PAINEL PODE PASSAR DO PRAZO DO REGISTRO, e a tela avisa.
	 *
	 * POR QUE ISTO EXISTE. `dias_no_painel` e `retencao_eventos_dias` são duas
	 * chaves independentes, e nada amarra uma à outra: com o painel somando 28
	 * dias e o registro guardando 7, os quadros que leem o REGISTRO — a tabela
	 * bruta, "quantas vezes cada página foi visitada", "pessoas diferentes" —
	 * cobrem uma semana, e os que leem o AGREGADO cobrem quatro. Os dois dizem
	 * "nos últimos 28 dias" e um deles está descrevendo outro período.
	 *
	 * O AVISO, E NÃO A CORREÇÃO. Encolher o painel em silêncio esconderia a
	 * série do agregado, que é justamente a que sobrevive por ser anônima; e
	 * esticar a retenção do registro alongaria a guarda de dado pessoal por
	 * conta própria. As duas escolhas são de quem opera o site, e o que faltava
	 * era ele saber que precisava fazê-la.
	 *
	 * @return void
	 */
	private static function render_periodo_maior_que_a_retencao(): void {
		$painel   = (int) F3Base_Modulo_Comportamento::dias_no_painel();
		$registro = (int) F3Base_Modulo_Comportamento::retencao_eventos_dias();

		if ( $painel <= $registro ) {
			return;
		}

		printf(
			'<p class="f3base-vazio f3base-periodo-alem-da-retencao">%s</p>',
			esc_html(
				sprintf(
					/* translators: 1: período do painel em dias, 2: prazo do registro em dias. */
					__( 'Os quadros desta tela não cobrem o mesmo período: o painel soma %1$d dias e o registro detalhado só guarda %2$d. Os quadros que vêm do registro — a tabela de acionamentos, as visitas por página e "pessoas diferentes" — mostram os últimos %2$d dias, e os que vêm do resumo mostram os %1$d. A diferença é dessas duas chaves, e quem as ajusta é quem opera o site: encolher o período do painel esconderia a série do resumo, que dura mais justamente por não identificar ninguém, e esticar o prazo do registro alongaria a guarda de dado pessoal.', 'f3base' ),
					$painel,
					$registro
				)
			)
		);
	}

	/**
	 * O QUE ESTE SITE DESCARTOU, dito antes de a tabela ser lida.
	 *
	 * POR QUE ESTE QUADRO EXISTE. O corte sempre foi nosso e sempre foi
	 * contado — o navegador conta o que estourou o orçamento da visita, o
	 * servidor conta o que estourou o teto do corpo —, e o número saía NOMEADO
	 * na resposta da rota. Só que a resposta da rota morre no navegador: quem
	 * abre esta tela via uma tabela e não tinha como saber que faltava alguma
	 * coisa nela. Somava achando que tinha tudo, e essa é a pior forma de um
	 * número errado — a que não parece errada.
	 *
	 * ELE NÃO É UM EVENTO, e por isso não está entre eles: ninguém "cortou"
	 * nada, foi o pacote que descartou. Mostrá-lo na lista de acionamentos
	 * faria o operador somar descarte com acontecimento.
	 *
	 * ZERO NÃO IMPRIME NADA. Um quadro que dissesse "0 descartadas" em todo
	 * site saudável ocuparia a atenção de quem abre a tela para não responder
	 * nada — e é o oposto do que ele existe para fazer, que é chamar atenção
	 * justamente quando há o que ver.
	 *
	 * @param array<string,mixed> $resumo Resumo do período.
	 * @return void
	 */
	private static function render_cortadas( array $resumo ): void {
		$total = (int) ( $resumo['cortadas'] ?? 0 );

		if ( $total < 1 ) {
			return;
		}

		printf(
			'<p class="f3base-vazio">%s</p>',
			esc_html(
				sprintf(
					/* translators: 1: total descartado, 2: período em dias. */
					_n(
						'Esta tabela está incompleta: %1$s acionamento foi DESCARTADO nos últimos %2$d dias e não virou linha. O descarte é do pacote, não do visitante — acontece quando uma visita passa do orçamento de linhas dela, quando um lote passa do tamanho aceito pela rota, ou quando o navegador não conseguiu entregar um lote a tempo. Some o que está abaixo sabendo que este número ficou de fora.',
						'Esta tabela está incompleta: %1$s acionamentos foram DESCARTADOS nos últimos %2$d dias e não viraram linha. O descarte é do pacote, não do visitante — acontece quando uma visita passa do orçamento de linhas dela, quando um lote passa do tamanho aceito pela rota, ou quando o navegador não conseguiu entregar um lote a tempo. Some o que está abaixo sabendo que estes números ficaram de fora.',
						$total,
						'f3base'
					),
					number_format_i18n( $total ),
					(int) $resumo['dias']
				)
			)
		);

		/*
		 * O NÚMERO DO DESCARTE VEM DO AGREGADO e fala sobre o REGISTRO, e é
		 * exatamente esse cruzamento que precisa estar dito: ele é a única
		 * afirmação da tela em que uma tabela responde pela completude da
		 * outra.
		 */
		self::render_de_qual_tabela( array( 'agregado' ) );

		/*
		 * ONDE ELE ACONTECEU, e não só quanto. Descarte concentrado numa página
		 * é outra conversa que descarte espalhado: a primeira é uma página que
		 * produz mais acionamento do que o orçamento da visita comporta, a
		 * segunda é entrega falhando no site inteiro. Sem o caminho, as duas
		 * são o mesmo número.
		 */
		$paginas = is_array( $resumo['cortadas_paginas'] ?? null ) ? $resumo['cortadas_paginas'] : array();

		if ( array() === $paginas ) {
			return;
		}

		$linhas = array();

		foreach ( array_slice( $paginas, 0, 10 ) as $pagina ) {
			$linhas[] = array(
				(string) $pagina['caminho'],
				number_format_i18n( (int) $pagina['total'] ),
			);
		}

		self::render_tabela(
			__( 'Página', 'f3base' ),
			__( 'Descartadas', 'f3base' ),
			$linhas
		);
	}

	/**
	 * A TABELA BRUTA DE ACIONAMENTOS — o quadro principal desta tela.
	 *
	 * Nas palavras do usuário: *"uma tabela que apresente dia e horário em que
	 * cada trigger foi acionado, isso identificado por sessão e por visitante.
	 * NÃO APENAS A PRIMEIRA VEZ que a trigger seja acionada, todas as vezes que
	 * ela for acionada mesmo que seja pelo mesmo visitante e durante a mesma
	 * sessão."*
	 *
	 * Uma linha por acionamento, da mais recente para a mais antiga. O gatilho
	 * aparece em português comum — "passou de 25%", "bloco abertura" —, e a
	 * frase sai da declaração dos eventos, nunca escrita aqui.
	 *
	 * FILTRO E PAGINAÇÃO NÃO SÃO ENFEITE: com uma linha por acionamento, o
	 * primeiro site com tráfego produz milhares delas, e uma tela que
	 * despejasse tudo seria inútil exatamente onde ela mais importa.
	 *
	 * @return void
	 */
	private static function render_acionamentos(): void {
		/*
		 * VINTE E CINCO POR PÁGINA, e o número é a diferença entre a paginação
		 * existir e ela ser teórica. Com cem por página e sessenta e duas linhas
		 * no primeiro site real, nenhum controle aparecia: o operador via a
		 * tabela cortada e não tinha como saber se estava vendo tudo.
		 */
		$por_pagina = 25;

		/*
		 * OS FILTROS VÊM DA URL e são conferidos contra a FORMA do pseudônimo
		 * antes de chegar à consulta: valor fora dela é descartado, e não
		 * escapado — o que não tem a forma de um apelido não é um apelido.
		 */
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- leitura de tela, sem efeito colateral.
		$visitante = isset( $_GET['visitante'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['visitante'] ) ) : '';
		$sessao    = isset( $_GET['sessao'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['sessao'] ) ) : '';
		$pagina    = isset( $_GET['pagina_da_tabela'] ) ? max( 1, (int) $_GET['pagina_da_tabela'] ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		/*
		 * O FILTRO FORA DA FORMA É DESCARTADO AQUI, e não só na consulta — esta
		 * é a correção. A consulta já o descartava: `acionamentos()` confere cada
		 * um contra a forma do pseudônimo e só acrescenta a cláusula quando ele
		 * passa. A TELA não conferia nada, e a frase de `render_filtros()` saía
		 * assim mesmo: "Mostrando apenas o visitante joao@exe" sobre uma tabela
		 * que trazia TODOS os visitantes. O leitor via um recorte que a consulta
		 * não fez e concluía que aquele visitante tinha feito tudo aquilo.
		 *
		 * A FORMA VEM DO MÓDULO, e nunca de uma expressão escrita aqui: duas
		 * definições do mesmo alfabeto divergem na primeira vez que uma delas
		 * mudar, e a tela voltaria a afirmar um recorte que a consulta recusa.
		 */
		$recusados = array();

		if ( '' !== $visitante && 1 !== preg_match( F3Base_Modulo_Comportamento::FORMA_PSEUDONIMO, $visitante ) ) {
			$recusados[] = __( 'visitante', 'f3base' );
			$visitante   = '';
		}

		if ( '' !== $sessao && 1 !== preg_match( F3Base_Modulo_Comportamento::FORMA_PSEUDONIMO, $sessao ) ) {
			$recusados[] = __( 'visita', 'f3base' );
			$sessao      = '';
		}

		$acionamentos = F3Base_Modulo_Comportamento::acionamentos(
			array(
				'visitante' => $visitante,
				'sessao'    => $sessao,
				'limite'    => $por_pagina,
				'salto'     => ( $pagina - 1 ) * $por_pagina,
			)
		);

		echo '<section class="f3base-bloco">';

		printf( '<h2>%s</h2>', esc_html__( 'Cada acionamento, um por linha', 'f3base' ) );

		printf(
			'<p class="f3base-bloco-resumo">%s</p>',
			esc_html(
				sprintf(
					/* translators: %d: período em dias. */
					__( 'Todas as vezes que algo foi acionado nos últimos %d dias, da mais recente para a mais antiga — inclusive quando foi o mesmo visitante, na mesma visita, no mesmo bloco. É a leitura que mostra alguém voltando e relendo. A coluna "vez" conta as passagens DA VISITA INTEIRA, e não as de uma página carregada: quem vê um bloco, vai para outra página do site e volta continua contando de onde parou, e a volta aparece como 2ª. Cada endereço tem a contagem dele — o mesmo bloco em outra página recomeça na 1ª.', 'f3base' ),
					(int) F3Base_Modulo_Comportamento::dias_no_painel()
				)
			)
		);

		self::render_de_qual_tabela( array( 'registro' ) );

		if ( array() !== $recusados ) {
			printf(
				'<p class="f3base-vazio f3base-filtro-recusado">%s</p>',
				esc_html(
					sprintf(
						/* translators: %s: nomes dos filtros recusados. */
						_n(
							'O filtro por %s foi IGNORADO: o valor no endereço não tem a forma de um apelido, que é um hexadecimal sorteado de 32 caracteres. A tabela abaixo mostra tudo, sem recorte nenhum.',
							'Os filtros por %s foram IGNORADOS: os valores no endereço não têm a forma de um apelido, que é um hexadecimal sorteado de 32 caracteres. A tabela abaixo mostra tudo, sem recorte nenhum.',
							count( $recusados ),
							'f3base'
						),
						implode( __( ' e ', 'f3base' ), $recusados )
					)
				)
			);
		}

		self::render_filtros( $visitante, $sessao );

		if ( array() === $acionamentos['linhas'] ) {
			printf(
				'<p class="f3base-vazio">%s</p></section>',
				'' === $visitante && '' === $sessao
					? esc_html__( 'Nenhum acionamento registrado no período.', 'f3base' )
					: esc_html__( 'Nenhum acionamento com esse filtro. Limpe o filtro para ver todos.', 'f3base' )
			);

			return;
		}

		echo '<table class="widefat striped f3base-totais"><thead><tr>';

		foreach (
			array(
				__( 'Visitante', 'f3base' ),
				__( 'Visita', 'f3base' ),
				__( 'Data', 'f3base' ),
				__( 'Horário', 'f3base' ),
				__( 'Página', 'f3base' ),
				__( 'O que aconteceu', 'f3base' ),
				__( 'Vez', 'f3base' ),
			) as $cabecalho
		) {
			printf( '<th>%s</th>', esc_html( $cabecalho ) );
		}

		echo '</tr></thead><tbody>';

		foreach ( $acionamentos['linhas'] as $linha ) {
			echo '<tr>';

			/*
			 * O APELIDO APARECE ABREVIADO E CLICÁVEL: inteiro ele ocupa a linha
			 * e ninguém o lê; clicável ele vira o filtro, que é para o que ele
			 * serve nesta tela.
			 */
			printf(
				'<td><a href="%s"><code>%s</code></a></td>',
				esc_url( self::url_do_filtro( (string) $linha['visitante'], '' ) ),
				esc_html( substr( (string) $linha['visitante'], 0, 8 ) )
			);

			printf(
				'<td><a href="%s"><code>%s</code></a></td>',
				esc_url( self::url_do_filtro( '', (string) $linha['sessao'] ) ),
				esc_html( substr( (string) $linha['sessao'], 0, 8 ) )
			);

			/*
			 * O HORÁRIO COM A FRAÇÃO DE SEGUNDO, e a precisão passou a ter
			 * razão de ser na 1.0.1: até ela o carimbo era a hora em que o LOTE
			 * CHEGOU, e vinte e cinco linhas seguidas traziam o mesmo
			 * `09:22:25` porque tinham mesmo o mesmo valor. Com o carimbo do
			 * ACIONAMENTO, dois disparos separados por trezentos milissegundos
			 * são dois instantes diferentes — e um formato que parasse no
			 * segundo continuaria mostrando os dois iguais, escondendo a
			 * correção atrás do mesmo sintoma.
			 *
			 * MILISSEGUNDOS, e não décimos: é a resolução em que o dado é
			 * medido no navegador. Arredondar na exibição faria a tela ordenar
			 * por um número e mostrar outro, que é a forma de a coluna "vez"
			 * parecer errada sem estar.
			 */
			printf(
				'<td>%s</td><td>%s%s</td>',
				esc_html( wp_date( 'd/m/Y', (int) $linha['criado_em'] ) ),
				esc_html(
					null === $linha['fracao_ms']
						? wp_date( 'H:i:s', (int) $linha['criado_em'] )
						: wp_date( 'H:i:s', (int) $linha['criado_em'] ) . ',' . str_pad( (string) (int) $linha['fracao_ms'], 3, '0', STR_PAD_LEFT )
				),
				self::marca_da_ancora( (string) $linha['ancora'] )
			);

			printf( '<td>%s</td>', esc_html( (string) $linha['caminho'] ) );
			printf( '<td>%s</td>', esc_html( (string) $linha['frase'] ) );

			/*
			 * A VEZ é o que distingue a primeira passagem da releitura. "1ª" e
			 * "3ª" na mesma linha do mesmo bloco é a resposta inteira à pergunta
			 * do usuário.
			 *
			 * E ELA CONTA A VISITA, não o carregamento — por isso o resumo deste
			 * bloco diz isso em português comum, antes da tabela. Quem lê "1ª"
			 * três vezes seguidas na mesma visita soma errado: até a 1.3.3 o
			 * contador vivia no carregamento e voltava para 1 a cada navegação,
			 * e a tabela mostrava três primeiras vezes onde houve uma primeira e
			 * duas releituras. Uma coluna que não diz sobre QUE janela ela conta
			 * é uma coluna que cada leitor interpreta de um jeito.
			 */
			printf(
				'<td>%s</td>',
				esc_html(
					sprintf(
						/* translators: %s: número da ocorrência. */
						__( '%sª', 'f3base' ),
						number_format_i18n( (int) $linha['ocorrencia'] )
					)
				)
			);

			echo '</tr>';
		}

		echo '</tbody></table>';

		self::render_paginacao( $pagina, $por_pagina, (int) $acionamentos['total'], $visitante, $sessao );

		self::render_procedencia_do_horario( $acionamentos['linhas'] );

		printf(
			'<p class="description">%s</p>',
			esc_html__( 'O apelido do visitante e o da visita são sorteados no navegador e não dizem quem a pessoa é. Clique em um deles para ver só o que aquele visitante — ou aquela visita — acionou.', 'f3base' )
		);

		echo '</section>';
	}

	/**
	 * DE QUAL DAS DUAS TABELAS ESTE QUADRO VEM, e o que aquela tabela responde.
	 *
	 * POR QUE ESTA LINHA EXISTE EM TODO QUADRO. A tela mostrava a tabela bruta e
	 * três quadros do agregado sem dizer, em lugar nenhum, que são DUAS tabelas
	 * com propósitos diferentes. Quem operava abriu o banco procurando entender
	 * o que via, encontrou `f3base_comportamento` — que soma na mesma linha por
	 * desenho — e concluiu que o registro estava sendo reescrito. Não estava: as
	 * linhas do registro são distintas, cada uma com `id` próprio. O que faltava
	 * era a tela dizer de onde cada número vinha.
	 *
	 * A FRASE NÃO É ESCRITA AQUI. Ela sai de `proposito_das_tabelas()`, que é o
	 * produtor único: repetida em quatro quadros, ela divergiria na primeira
	 * edição apressada e a tela passaria a descrever a mesma tabela de dois
	 * jeitos.
	 *
	 * @param array<int,string> $quais Chaves das tabelas de que este quadro lê.
	 * @return void
	 */
	private static function render_de_qual_tabela( array $quais ): void {
		$tabelas = F3Base_Modulo_Comportamento::proposito_das_tabelas();
		$partes  = array();

		foreach ( $quais as $qual ) {
			if ( ! isset( $tabelas[ $qual ] ) ) {
				continue;
			}

			$partes[] = sprintf(
				/* translators: 1: nome da tabela no banco, 2: o que aquela tabela responde. */
				__( '%1$s — %2$s', 'f3base' ),
				$tabelas[ $qual ]['tabela'],
				$tabelas[ $qual ]['responde']
			);
		}

		if ( array() === $partes ) {
			return;
		}

		printf(
			'<p class="description f3base-de-qual-tabela">%s %s</p>',
			esc_html(
				1 === count( $partes )
					? __( 'Vem de uma tabela:', 'f3base' )
					: __( 'Vem das DUAS tabelas:', 'f3base' )
			),
			esc_html( implode( ' · ', $partes ) )
		);
	}

	/**
	 * DE ONDE VEIO O HORÁRIO de cada linha desta página da tabela.
	 *
	 * A TELA NÃO PODE AFIRMAR UM HORÁRIO SEM QUE NADA SAIBA DE ONDE ELE VEIO. O
	 * carimbo de cada acionamento sai da âncora do lote, e a âncora tem três
	 * procedências com qualidades diferentes: a origem do navegador (absoluto,
	 * ordem e espaçamento exatos), a âncora derivada do servidor (ordem e
	 * espaçamento exatos, absoluto exato só quando o lote não ficou na fila) e
	 * a hora da CHEGADA, que é o que as linhas gravadas antes desta versão têm.
	 * Sem esta linha, as três apareceriam iguais na coluna Horário.
	 *
	 * ELA CONTA AS LINHAS DESTA PÁGINA, e diz isso: contar a tabela inteira
	 * custaria uma consulta a mais para responder sobre linhas que quem lê não
	 * está vendo.
	 *
	 * @param array<int,array<string,mixed>> $linhas Linhas exibidas.
	 * @return void
	 */
	private static function render_procedencia_do_horario( array $linhas ): void {
		$por_ancora = array(
			F3Base_Modulo_Comportamento::ANCORA_VISITANTE => 0,
			F3Base_Modulo_Comportamento::ANCORA_SERVIDOR  => 0,
			F3Base_Modulo_Comportamento::ANCORA_CHEGADA   => 0,
		);

		foreach ( $linhas as $linha ) {
			$ancora = (string) $linha['ancora'];

			if ( isset( $por_ancora[ $ancora ] ) ) {
				++$por_ancora[ $ancora ];
			}
		}

		$frases = array();

		if ( $por_ancora[ F3Base_Modulo_Comportamento::ANCORA_VISITANTE ] > 0 ) {
			$frases[] = sprintf(
				/* translators: %s: quantas linhas desta página. */
				__( '%s com o horário medido no próprio carregamento da página: a hora, a ordem e a distância entre elas são exatas.', 'f3base' ),
				number_format_i18n( $por_ancora[ F3Base_Modulo_Comportamento::ANCORA_VISITANTE ] )
			);
		}

		if ( $por_ancora[ F3Base_Modulo_Comportamento::ANCORA_SERVIDOR ] > 0 ) {
			$frases[] = sprintf(
				/* translators: %s: quantas linhas desta página. */
				__( '%s com o horário ancorado NO SERVIDOR, porque o relógio do aparelho não pôde ser usado — ele veio ausente, adiantado demais ou velho demais. A ordem e a distância entre elas continuam exatas; a hora absoluta erra pelo tempo que o lote levou para ser entregue, e só é exata quando ele chegou na hora.', 'f3base' ),
				number_format_i18n( $por_ancora[ F3Base_Modulo_Comportamento::ANCORA_SERVIDOR ] )
			);
		}

		if ( $por_ancora[ F3Base_Modulo_Comportamento::ANCORA_CHEGADA ] > 0 ) {
			$frases[] = sprintf(
				/* translators: %s: quantas linhas desta página. */
				__( '%s marcadas com (chegada): são linhas gravadas por uma versão anterior deste plugin, cujo horário é o do momento em que o lote CHEGOU ao servidor, e não o do acionamento. Um lote traz dezenas de acionamentos de segundos ou minutos de navegação, então essas linhas saem todas no mesmo segundo e não dizem em que ordem nem a que distância aconteceram. Elas não são reescritas — inventar um horário seria pior que ter um grosseiro — e somem sozinhas quando a retenção do registro as alcançar.', 'f3base' ),
				number_format_i18n( $por_ancora[ F3Base_Modulo_Comportamento::ANCORA_CHEGADA ] )
			);
		}

		if ( array() === $frases ) {
			return;
		}

		printf(
			'<p class="description f3base-procedencia-do-horario">%s %s</p>',
			esc_html__( 'De onde vem o horário nesta página da tabela:', 'f3base' ),
			esc_html( implode( ' ', $frases ) )
		);
	}

	/**
	 * A marca que acompanha o horário de uma linha cuja procedência precisa ser
	 * dita na própria célula.
	 *
	 * SÓ A DA CHEGADA GANHA MARCA, e isso é decisão: as outras duas ordenam e
	 * espaçam certo, e marcar todas encheria a coluna de ruído até que a
	 * marca deixasse de ser lida. A da chegada é a única que não responde a
	 * pergunta que a coluna faz.
	 *
	 * @param string $ancora Procedência gravada na linha.
	 * @return string
	 */
	private static function marca_da_ancora( string $ancora ): string {
		if ( F3Base_Modulo_Comportamento::ANCORA_CHEGADA !== $ancora ) {
			return '';
		}

		return '<br><small>' . esc_html__( '(chegada)', 'f3base' ) . '</small>';
	}

	/**
	 * Os filtros por visitante e por visita.
	 *
	 * @param string $visitante Filtro corrente.
	 * @param string $sessao    Filtro corrente.
	 * @return void
	 */
	private static function render_filtros( string $visitante, string $sessao ): void {
		if ( '' === $visitante && '' === $sessao ) {
			return;
		}

		printf(
			'<p class="f3base-bloco-resumo">%s <a href="%s">%s</a></p>',
			esc_html(
				'' !== $visitante
					? sprintf(
						/* translators: %s: apelido do visitante. */
						__( 'Mostrando apenas o visitante %s.', 'f3base' ),
						substr( $visitante, 0, 8 )
					)
					: sprintf(
						/* translators: %s: apelido da visita. */
						__( 'Mostrando apenas a visita %s.', 'f3base' ),
						substr( $sessao, 0, 8 )
					)
			),
			esc_url( self::url_do_filtro( '', '' ) ),
			esc_html__( 'ver todos', 'f3base' )
		);
	}

	/**
	 * O endereço desta tela com um filtro aplicado.
	 *
	 * @param string $visitante Apelido, ou vazio.
	 * @param string $sessao    Apelido, ou vazio.
	 * @param int    $pagina    Página da tabela.
	 * @return string
	 */
	private static function url_do_filtro( string $visitante, string $sessao, int $pagina = 1 ): string {
		$argumentos = array( 'page' => self::SLUG );

		if ( '' !== $visitante ) {
			$argumentos['visitante'] = $visitante;
		}

		if ( '' !== $sessao ) {
			$argumentos['sessao'] = $sessao;
		}

		if ( $pagina > 1 ) {
			$argumentos['pagina_da_tabela'] = $pagina;
		}

		return add_query_arg( $argumentos, admin_url( 'admin.php' ) );
	}

	/**
	 * A paginação da tabela bruta.
	 *
	 * @param int    $pagina     Página corrente.
	 * @param int    $por_pagina Linhas por página.
	 * @param int    $total      Total de linhas.
	 * @param string $visitante  Filtro corrente.
	 * @param string $sessao     Filtro corrente.
	 * @return void
	 */
	private static function render_paginacao( int $pagina, int $por_pagina, int $total, string $visitante, string $sessao ): void {
		$paginas = max( 1, (int) ceil( $total / max( 1, $por_pagina ) ) );

		/*
		 * O RODAPÉ APARECE SEMPRE, inclusive quando tudo cabe numa página. Uma
		 * paginação que só surge quando transborda deixa quem lê sem saber se
		 * está vendo tudo — foi exatamente o que aconteceu: sessenta e duas
		 * linhas, cem por página, nenhum controle na tela, e a conclusão de que
		 * a tabela estava truncada.
		 */
		echo '<p class="f3base-paginacao">';

		printf(
			'%s ',
			esc_html(
				sprintf(
					/* translators: 1: primeira linha mostrada, 2: última, 3: total. */
					__( 'Mostrando de %1$s a %2$s de %3$s acionamentos.', 'f3base' ),
					number_format_i18n( $total > 0 ? ( ( $pagina - 1 ) * $por_pagina ) + 1 : 0 ),
					number_format_i18n( min( $total, $pagina * $por_pagina ) ),
					number_format_i18n( $total )
				)
			)
		);

		if ( $pagina > 1 ) {
			printf(
				'<a href="%s">%s</a> ',
				esc_url( self::url_do_filtro( $visitante, $sessao, $pagina - 1 ) ),
				esc_html__( '← mais recentes', 'f3base' )
			);
		}

		printf(
			'<span>%s</span>',
			esc_html(
				sprintf(
					/* translators: 1: página corrente, 2: total de páginas. */
					__( 'página %1$s de %2$s', 'f3base' ),
					number_format_i18n( $pagina ),
					number_format_i18n( $paginas )
				)
			)
		);

		if ( $pagina < $paginas ) {
			printf(
				' <a href="%s">%s</a>',
				esc_url( self::url_do_filtro( $visitante, $sessao, $pagina + 1 ) ),
				esc_html__( 'mais antigos →', 'f3base' )
			);
		}

		echo '</p>';
	}

	/**
	 * AS MEDIDAS DE CARREGAMENTO, com a explicação e a régua ao lado.
	 *
	 * POR QUE ESTE QUADRO EXISTE. Ele era prometido e não existia: o resumo já
	 * calculava `vitais`, o pacote já trazia `dados/vitais.tsv` com a explicação
	 * e o limiar de cada medida, e nenhuma linha da tela chamava qualquer um dos
	 * dois. Quatro medidas eram coletadas em toda visita, gravadas, somadas — e
	 * lidas por ninguém.
	 *
	 * A SIGLA NÃO É RESPOSTA. Quem opera o site não tem obrigação de saber o que
	 * significa LCP, e um número sem régua não decide nada: 0,08 é bom ou ruim?
	 * A explicação e o limiar saem da declaração, nunca escritos aqui — escritos
	 * na tela, seriam uma segunda descrição da mesma medida e divergiriam da
	 * declaração na primeira vez que alguém mexesse numa e não na outra.
	 *
	 * O LIMIAR É RÉGUA, E NÃO SELO. A tela mostra o valor medido e o limiar lado
	 * a lado e NÃO classifica a página: os cortes são do fornecedor e mudam por
	 * calendário, e um "bom" impresso por nós discordaria do console dele no dia
	 * em que ele se movesse, sem uma linha dizendo por quê.
	 *
	 * @param array<string,mixed> $resumo Resumo do período.
	 * @return void
	 */
	private static function render_vitais( array $resumo ): void {
		$declaradas = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::vitais_declarados()
			: array();

		$medidas = array();

		foreach ( (array) ( $resumo['vitais'] ?? array() ) as $linha ) {
			$medidas[ (string) $linha['metrica'] ] = $linha;
		}

		echo '<section class="f3base-bloco">';

		printf( '<h2>%s</h2>', esc_html__( 'Quanto a página demora a ficar utilizável', 'f3base' ) );

		printf(
			'<p class="f3base-bloco-resumo">%s</p>',
			esc_html(
				sprintf(
					/* translators: %d: período em dias. */
					__( 'A experiência de carregamento medida no aparelho de quem visitou o site nos últimos %d dias — e não num teste de laboratório. Ao lado de cada valor está o limiar de "bom" publicado pelo fornecedor da medida: ele é régua, e não selo. Esta tela não classifica a página, porque os cortes mudam por calendário e são deles.', 'f3base' ),
					(int) $resumo['dias']
				)
			)
		);

		self::render_de_qual_tabela( array( 'agregado' ) );

		if ( array() === $declaradas ) {
			printf(
				'<p class="f3base-vazio">%s</p></section>',
				esc_html__( 'A declaração das medidas de carregamento não pôde ser lida (dados/vitais.tsv): sem ela não há explicação nem limiar, e um número sem régua não decide nada.', 'f3base' )
			);

			return;
		}

		echo '<table class="widefat striped f3base-totais"><thead><tr>';
		printf(
			'<th>%s</th><th>%s</th><th>%s</th><th>%s</th>',
			esc_html__( 'Medida', 'f3base' ),
			esc_html__( 'Valor típico no período', 'f3base' ),
			esc_html__( 'Bom até', 'f3base' ),
			esc_html__( 'Visitas medidas', 'f3base' )
		);
		echo '</tr></thead><tbody>';

		/*
		 * A LISTA SAI DA DECLARAÇÃO, e não da tabela: medida declarada e sem
		 * nenhuma amostra aparece como "não medido" em vez de sumir. Uma lista
		 * montada a partir do que a tabela por acaso tem esconderia justamente a
		 * medida que parou de ser coletada, que é o defeito que mais importa
		 * descobrir.
		 */
		foreach ( $declaradas as $sigla => $declaracao ) {
			$medida = $medidas[ (string) $sigla ] ?? null;

			echo '<tr>';

			printf(
				'<td><strong>%s</strong><br><small>%s</small></td>',
				esc_html( (string) $sigla ),
				esc_html( (string) $declaracao['explicacao'] )
			);

			printf(
				'<td>%s</td>',
				null === $medida
					? esc_html__( 'não medido', 'f3base' )
					: esc_html( self::como_valor( (float) $medida['media'], (string) $declaracao['unidade'] ) )
			);

			printf(
				'<td>%s</td>',
				esc_html( self::como_valor( (float) $declaracao['bom_ate'], (string) $declaracao['unidade'] ) )
			);

			printf(
				'<td>%s</td>',
				null === $medida
					? esc_html__( '—', 'f3base' )
					: esc_html( number_format_i18n( (int) $medida['amostra'] ) )
			);

			echo '</tr>';
		}

		echo '</tbody></table>';

		printf(
			'<p class="description">%s</p>',
			esc_html__( 'O valor típico é a média das visitas medidas no período. Medida declarada sem nenhuma amostra aparece como "não medido": pode ser um navegador que não reporta aquele número, ou a medida ter parado de ser coletada — e as duas coisas são resposta, enquanto sumir da tabela não é.', 'f3base' )
		);

		echo '</section>';
	}

	/**
	 * Um valor de medida de carregamento com a unidade declarada.
	 *
	 * A unidade sai da declaração, como a explicação e o limiar: um `ms` escrito
	 * aqui seria a segunda descrição da mesma medida, e a medida sem unidade —
	 * que existe — apareceria com uma que ela não tem.
	 *
	 * @param float  $valor   Valor medido.
	 * @param string $unidade Unidade declarada, ou vazio.
	 * @return string
	 */
	private static function como_valor( float $valor, string $unidade ): string {
		$casas = '' === $unidade ? 3 : 0;

		return '' === $unidade
			? number_format_i18n( $valor, $casas )
			: sprintf(
				/* translators: 1: valor formatado, 2: unidade declarada. */
				__( '%1$s %2$s', 'f3base' ),
				number_format_i18n( $valor, $casas ),
				$unidade
			);
	}

	/**
	 * SAÍDAS PARA FORA DO SITE, com o vazio explicado.
	 *
	 * O quadro mostrava zero, e zero sem explicação parece defeito: foi o que
	 * fez o usuário concluir que o coletor estava quebrado. Ele não estava —
	 * nenhuma página publicada tinha um único link para fora, e não havia o que
	 * clicar. A diferença entre "ninguém clicou" e "não há onde clicar" é a
	 * diferença entre um número e uma resposta, e ela é medida no conteúdo.
	 *
	 * @param array<string,mixed> $resumo Resumo do período.
	 * @return void
	 */
	private static function render_saidas( array $resumo ): void {
		$evento = F3Base_Modulo_Comportamento::evento_do_gatilho( 'clique-externo' );
		$linhas = array();

		foreach ( (array) $resumo['eventos'] as $linha ) {
			if ( '' !== $evento && str_starts_with( (string) $linha['rotulo'], $evento ) ) {
				$linhas[] = array(
					trim( str_replace( $evento, '', (string) $linha['rotulo'] ), ' ·' ),
					number_format_i18n( (int) $linha['total'] ),
				);
			}
		}

		echo '<section class="f3base-bloco">';

		printf( '<h2>%s</h2>', esc_html__( 'Saídas para fora do site', 'f3base' ) );

		/*
		 * A LINHA VEM ANTES DO RAMO, e não dentro dele: o quadro VAZIO é
		 * justamente aquele em que quem lê vai procurar de onde o número
		 * deveria ter vindo.
		 */
		self::render_de_qual_tabela( array( 'agregado' ) );

		if ( array() !== $linhas ) {
			printf(
				'<p class="f3base-bloco-resumo">%s</p>',
				esc_html__( 'Para onde o visitante foi quando saiu daqui. Só o domínio de destino é registrado — nunca o endereço completo, que carregaria identificador de campanha e de pessoa.', 'f3base' )
			);

			self::render_tabela( __( 'Domínio', 'f3base' ), __( 'Saídas no período', 'f3base' ), $linhas );

			echo '</section>';

			return;
		}

		/*
		 * O VAZIO COM CAUSA. Sem link publicado, o quadro não está zerado: ele
		 * não tem o que contar, e dizer isso é o que impede alguém de procurar
		 * um defeito que não existe.
		 */
		printf(
			'<p class="f3base-vazio">%s</p>',
			F3Base_Modulo_Comportamento::ha_link_externo_publicado()
				? esc_html__( 'Nenhuma saída registrada no período. Há links para fora nas páginas publicadas, e ninguém clicou neles até agora.', 'f3base' )
				: esc_html__( 'Nenhuma página publicada tem link para fora do site, então não há o que clicar — este quadro passa a contar quando houver. Isto não é medição parada: é ausência do que medir.', 'f3base' )
		);

		echo '</section>';
	}

	/**
	 * QUANTAS VEZES CADA PÁGINA FOI VISITADA, e por quantas pessoas.
	 *
	 * O quadro voltou a pedido do usuário. Ele havia cortado "páginas com mais
	 * registro", que somava TODA a atividade — uma página longa e lida até o fim
	 * produzia mais registro que uma curta com o mesmo público, e o número não
	 * respondia nada. Visitas e pessoas são outra pergunta, e é a que ele fez.
	 *
	 * @return void
	 */
	private static function render_visitas_por_pagina(): void {
		$paginas = F3Base_Modulo_Comportamento::visitas_por_pagina();

		echo '<section class="f3base-bloco">';

		printf( '<h2>%s</h2>', esc_html__( 'Quantas vezes cada página foi visitada', 'f3base' ) );

		printf(
			'<p class="f3base-bloco-resumo">%s</p>',
			esc_html(
				sprintf(
					/* translators: %d: período em dias. */
					__( 'Aberturas de página nos últimos %d dias, e quantas pessoas diferentes as abriram. A distância entre as duas colunas é a medida de quem volta: dez visitas de duas pessoas é um site que segura, dez de dez é um site visitado uma vez.', 'f3base' ),
					(int) F3Base_Modulo_Comportamento::dias_no_painel()
				)
			)
		);

		self::render_de_qual_tabela( array( 'registro' ) );

		if ( array() === $paginas ) {
			printf(
				'<p class="f3base-vazio">%s</p></section>',
				esc_html__( 'Nenhuma abertura de página registrada no período.', 'f3base' )
			);

			return;
		}

		echo '<table class="widefat striped f3base-totais"><thead><tr>';
		printf(
			'<th>%s</th><th>%s</th><th>%s</th>',
			esc_html__( 'Página', 'f3base' ),
			esc_html__( 'Visitas', 'f3base' ),
			esc_html__( 'Pessoas diferentes', 'f3base' )
		);
		echo '</tr></thead><tbody>';

		foreach ( $paginas as $linha ) {
			printf(
				'<tr><td>%s</td><td>%s</td><td>%s</td></tr>',
				esc_html( (string) $linha['caminho'] ),
				esc_html( number_format_i18n( (int) $linha['visitas'] ) ),
				esc_html( number_format_i18n( (int) $linha['pessoas'] ) )
			);
		}

		echo '</tbody></table>';

		echo '</section>';
	}

	/**
	 * A PROFUNDIDADE DE LEITURA, PÁGINA POR PÁGINA.
	 *
	 * Somada, ela não responde nada: a página que ninguém termina e a que todo
	 * mundo termina entram no mesmo total, e é justamente qual das duas está
	 * longa demais que o operador precisa saber. Cada página aparece com os
	 * marcos dela e com o número de carregamentos ao lado, para que "2 chegaram
	 * a 90%" seja lido como proporção e não como número solto.
	 *
	 * @param array<string,mixed> $resumo Resumo do período.
	 * @return void
	 */
	private static function render_profundidade( array $resumo ): void {
		$paginas  = F3Base_Modulo_Comportamento::profundidade_por_pagina();
		$registro = F3Base_Modulo_Comportamento::registro_por_pagina();

		echo '<section class="f3base-bloco">';

		printf( '<h2>%s</h2>', esc_html__( 'Até onde as pessoas descem, em cada página', 'f3base' ) );

		printf(
			'<p class="f3base-bloco-resumo">%s</p>',
			esc_html(
				sprintf(
					/* translators: %d: período em dias. */
					__( 'Uma linha por página, com quantas visitas passaram de cada marco de profundidade nos últimos %d dias e a proporção sobre os carregamentos daquela página. É a leitura que diz se a página está longa demais: muita gente entrando e pouca chegando ao fim é conteúdo que não segura, não audiência que falta.', 'f3base' ),
					(int) $resumo['dias']
				)
			)
		);

		/*
		 * ESTE QUADRO É O ÚNICO QUE MISTURA AS DUAS, e dizê-lo importa: os
		 * totais de cada marco e o denominador saem do AGREGADO — que soma —,
		 * e o tempo típico, a releitura e "pessoas diferentes" saem do
		 * REGISTRO. Sem a linha, quem comparasse este quadro com a tabela bruta
		 * encontraria números que não fecham e concluiria que um dos dois está
		 * errado.
		 */
		self::render_de_qual_tabela( array( 'agregado', 'registro' ) );

		if ( array() === $paginas ) {
			printf(
				'<p class="f3base-vazio">%s</p></section>',
				esc_html__( 'Nenhuma página com registro de profundidade no período. A rolagem só é medida quando alguém abre a página — e uma página que cabe inteira na tela conta como lida até o fim assim que termina de carregar.', 'f3base' )
			);

			return;
		}

		$marcos_vistos = array();

		foreach ( $paginas as $pagina ) {
			foreach ( $pagina['marcos'] as $marco ) {
				$marcos_vistos[ (string) $marco['marco'] ] = true;
			}
		}

		$colunas = array_keys( $marcos_vistos );
		usort(
			$colunas,
			static function ( string $a, string $b ): int {
				return (int) $a <=> (int) $b;
			}
		);

		echo '<table class="widefat striped f3base-totais"><thead><tr>';
		printf(
			'<th>%s</th><th>%s</th><th>%s</th>',
			esc_html__( 'Página', 'f3base' ),
			esc_html__( 'Carregamentos', 'f3base' ),
			esc_html__( 'Pessoas diferentes', 'f3base' )
		);

		foreach ( $colunas as $coluna ) {
			printf(
				'<th>%s</th>',
				esc_html(
					sprintf(
						/* translators: %s: marco de profundidade em porcentagem. */
						__( 'Passou de %s%%', 'f3base' ),
						$coluna
					)
				)
			);
		}

		echo '</tr></thead><tbody>';

		foreach ( $paginas as $pagina ) {
			$por_marco = array();

			foreach ( $pagina['marcos'] as $marco ) {
				$por_marco[ (string) $marco['marco'] ] = $marco;
			}

			$registro_da_pagina = $registro[ (string) $pagina['caminho'] ] ?? null;

			echo '<tr>';
			printf( '<td>%s</td>', esc_html( (string) $pagina['caminho'] ) );
			printf(
				'<td>%s</td>',
				(int) $pagina['carregamentos'] > 0
					? esc_html( number_format_i18n( (int) $pagina['carregamentos'] ) )
					: esc_html__( 'não medido', 'f3base' )
			);

			/*
				PESSOAS DIFERENTES NÃO É CARREGAMENTOS, e a diferença entre os
				dois é exatamente a medida de quem volta ao site. Quando o
				registro detalhado não existe — porque o navegador do visitante
				bloqueia o armazenamento local, ou porque o prazo curto já
				apagou —, a coluna diz que não foi medido em vez de mostrar zero.
			*/
			printf(
				'<td>%s</td>',
				null === $registro_da_pagina
					? esc_html__( 'não medido', 'f3base' )
					: esc_html( number_format_i18n( (int) $registro_da_pagina['visitantes'] ) )
			);

			foreach ( $colunas as $coluna ) {
				if ( ! isset( $por_marco[ $coluna ] ) ) {
					printf( '<td>%s</td>', esc_html__( '—', 'f3base' ) );

					continue;
				}

				$linha_do_marco = $por_marco[ $coluna ];

				/*
				 * SEM DENOMINADOR, SÓ O NÚMERO. Inventar uma porcentagem sobre
				 * um total que não foi medido seria a pior das duas saídas: ela
				 * pareceria proporção e não seria.
				 */
				if ( null === $linha_do_marco['proporcao'] ) {
					printf( '<td>%s</td>', esc_html( number_format_i18n( (int) $linha_do_marco['total'] ) ) );

					continue;
				}

				$detalhe_do_marco = ( null !== $registro_da_pagina && isset( $registro_da_pagina['marcos'][ $coluna ] ) )
					? $registro_da_pagina['marcos'][ $coluna ]
					: null;

				printf(
					'<td>%s%s</td>',
					esc_html(
						sprintf(
							/* translators: 1: quantas visitas passaram do marco, 2: proporção em porcentagem. */
							__( '%1$s de %2$s%%', 'f3base' ),
							number_format_i18n( (int) $linha_do_marco['total'] ),
							number_format_i18n( round( (float) $linha_do_marco['proporcao'] * 100 ) )
						)
					),
					null === $detalhe_do_marco ? '' : self::detalhe_do_marco( $detalhe_do_marco )
				);
			}

			echo '</tr>';
		}

		echo '</tbody></table>';

		printf(
			'<p class="description">%s</p>',
			esc_html__( 'O marco é calculado sobre a altura DAQUELA página, relida a cada medição: a imagem que carrega depois e o bloco que expande entram na conta. Página que cabe inteira na tela conta como lida até o fim — mas só depois de terminar de carregar, para que uma página longa cujas imagens ainda não chegaram não seja contada como lida.', 'f3base' )
		);

		printf(
			'<p class="description">%s</p>',
			esc_html__( 'Sob cada número: o tempo típico até a pessoa chegar ali, contado do momento em que a página abriu, e quantas vezes alguém subiu e desceu de novo até aquele ponto. O tempo é o valor do meio de todas as visitas, e não a média: uma aba deixada aberta a tarde inteira move a média da página e não move este número.', 'f3base' )
		);

		echo '</section>';
	}

	/**
	 * O detalhe de um marco: tempo típico e releitura, sob o número principal.
	 *
	 * @param array<string,mixed> $marco Dados do registro para aquele marco.
	 * @return string
	 */
	private static function detalhe_do_marco( array $marco ): string {
		$partes = array();

		if ( null !== $marco['mediana'] ) {
			$partes[] = sprintf(
				/* translators: %s: tempo típico até o marco, já formatado. */
				__( 'em %s', 'f3base' ),
				self::como_tempo( (int) $marco['mediana'] )
			);
		}

		if ( (int) $marco['releitura'] > 0 ) {
			$partes[] = sprintf(
				/* translators: %s: quantas passagens foram releitura. */
				_n( '%s releitura', '%s releituras', (int) $marco['releitura'], 'f3base' ),
				number_format_i18n( (int) $marco['releitura'] )
			);
		}

		if ( array() === $partes ) {
			return '';
		}

		return '<br><small>' . esc_html( implode( ' · ', $partes ) ) . '</small>';
	}

	/**
	 * Milissegundos em português comum.
	 *
	 * @param int $ms Milissegundos.
	 * @return string
	 */
	private static function como_tempo( int $ms ): string {
		if ( $ms < 1000 ) {
			return sprintf(
				/* translators: %s: milissegundos. */
				__( '%s ms', 'f3base' ),
				number_format_i18n( $ms )
			);
		}

		if ( $ms < 60000 ) {
			return sprintf(
				/* translators: %s: segundos. */
				__( '%s s', 'f3base' ),
				number_format_i18n( $ms / 1000, 1 )
			);
		}

		return sprintf(
			/* translators: 1: minutos, 2: segundos. */
			__( '%1$s min %2$s s', 'f3base' ),
			number_format_i18n( intdiv( $ms, 60000 ) ),
			number_format_i18n( intdiv( $ms % 60000, 1000 ) )
		);
	}

	/**
	 * Uma tabela de duas colunas.
	 *
	 * @param string                      $coluna_a Cabeçalho da primeira coluna.
	 * @param string                      $coluna_b Cabeçalho da segunda coluna.
	 * @param array<int,array<int,string>> $linhas   Linhas.
	 * @return void
	 */
	private static function render_tabela( string $coluna_a, string $coluna_b, array $linhas ): void {
		if ( array() === $linhas ) {
			return;
		}

		echo '<table class="widefat striped f3base-totais"><thead><tr>';
		printf( '<th>%s</th><th>%s</th>', esc_html( $coluna_a ), esc_html( $coluna_b ) );
		echo '</tr></thead><tbody>';

		foreach ( $linhas as $linha ) {
			printf(
				'<tr><td>%s</td><td>%s</td></tr>',
				esc_html( (string) $linha[0] ),
				esc_html( (string) $linha[1] )
			);
		}

		echo '</tbody></table>';
	}
}
