# Fonte do Fator3 Site Core 1.89.1

O código, os assets e a documentação que entram no WordPress estão em `work/plugin/base-site-core-fator3/`. O catálogo completo e os dados de pesquisa do pedido 415 ficam em `reference/415/`. As referências de preço e classificação dos modelos anteriores ficam em `reference/413/` e `reference/414/`.

## Reproduzir o instalador e o fonte

Execute a partir da raiz deste fonte. O build usa Python 3 e foi conferido com zlib 1.3.2. PHP 8.3 ou superior é necessário apenas para executar PHP. Os scripts históricos em `build/` e `tests/` permanecem disponíveis para desenvolvimento.

```sh
python3 build/gerar-catalogo-aparelhos.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.89.1-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.89.1-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.89.1-fonte.zip
```

O empacotador confere os hashes do runtime, exclui dependências instaladas e arquivos temporários e exige um fonte menor que 100.000.000 bytes. O gerador do índice documental é `build/gerar-indice-docs.py`.

## Repetir o ensaio do pedido 415

1. Forneça o instalador original da 1.89.0 e rode `python3 tests/conferir-acrescimo-415.py /caminho/base-site-core-fator3-1.89.0-instalador.zip`. O script verifica a identidade da base, cada ficha anterior, os índices por nome e por raiz e o conteúdo de todos os arquivos PHP.
2. Em WordPress descartável com banco `core1891_415` e `WP_ENVIRONMENT_TYPE=local`, ative a 1.89.0. Execute `wp --user=1 eval-file tests/pedido-415.php`. O script registra os dois perfis sintéticos e exige as duas pendências.
3. Atualize o mesmo banco com o instalador 1.89.1, ative o Core e repita o comando. A listagem percorre as duas páginas, confirma a ausência dos dois itens e confere as seis colunas de cada ficha. Compare `sha256_perfis` entre as saídas para comprovar a preservação das observações.
4. Execute `F3_QA_CATALOGO="$PWD/reference/415/catalogo-aparelhos.csv" wp --user=1 eval-file tests/catalogo-precos-413.php`. Descarte o laboratório ao encerrar.

Os resultados da rodada ficam em `evidence/1891/`. A 1.89.0 já entregue conserva as capturas do painel e os fontes de versões anteriores. Nesta entrega essas cópias saíram do ZIP. A cópia interna do relatório está em `RELATORIO-PRE-FECHAMENTO.md`. O relatório externo traz o tamanho e SHA-256 final do fonte.
