# Insumos da 0.9.0

Base oficial recebida do dono: versão 0.8.0; o SHA-256 dos dois ZIPs de origem consta na seção 1 do relatório de entrega. Para esta rodada, leia o plano e o parecer identificados como 0.9.0, os dois documentos centrais (revisão 5, 02/11/2026) e a lista de pedidos. Os dois impactos em inputs são o registro **preliminar**: a revisão de entrega fica na raiz do fonte.

A matriz vigente, com identificação dos cinco instaladores, está em evidence/090/companion-installers.json. pacotes.json, core1730-* e relatorios-acompanhantes/ são material recebido na rodada anterior; não identificam o conjunto atual. O histórico de origem da 0.8.0 está em historico/. Não há ZIP de entrada dentro do fonte.
