# Parecer sobre o plano — Fator3 MCP Pipedrive 0.9.0 (prevista)

Revisão 1 do parecer · 10/11/2026, 20:04 −03:00 · Rodada: revisão de planejamento.  
Slug: `wp-mcp-pipedrive-fator3` · Base: 0.8.0 · Plano examinado: revisão 1, de 10/11/2026 · Status: **com-pendencias**. O instalador 0.9.0 ainda não foi gerado nesta rodada.

**Recomendação:** manter a 0.9.0 e as prioridades fila, recuperação e configuração guiada. Revisar o plano antes de implementar os contratos. Há um defeito anterior à própria recuperação: em duas respostas ambíguas, a 0.8.0 elimina a pendência que a nova tela precisaria mostrar. Corrigir essa classificação primeiro. Os demais trabalhos independentes não precisam aguardar acesso comercial nem os cinco instaladores acompanhantes.

## 1. De onde esta versão entra

Base examinada: os ZIPs anexados de fonte e instalador 0.8.0. Recalculei os hashes e comparei caminhos e bytes dos **36 arquivos** do runtime das duas árvores: idênticos. Li o plano, as evidências, o Pedido 11 mantido no fonte, o relatório da entrega anterior e os trechos de código que sustentam os achados. As duas regras centrais — `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md` — foram lidas integralmente na revisão 5, de 02/11/2026.

Requisitos: WordPress ≥ 7.1.4 e PHP ≥ 8.3. Sonda desta revisão: PHP CLI 8.3.6, sem WordPress nem banco reais. A matriz com WordPress 7.1.4 / PHP 8.3.6 / MariaDB 10.11.14 pertence às evidências anexadas. A próxima release deve provar instalação limpa e atualização direta **0.8.0 → 0.9.0**.

## 2. Convivência e encaminhamentos

Em 10/11 reconsultei, somente para leitura, o Site-Teste. O inventário ativo confirmou Pipedrive **0.8.0**, Core **1.78.0**, MCP **0.43.0**, Google **0.31.0**, Meta **0.21.0** e LinkedIn **0.19.0**. O cliente consta como registrado, e o Core mantém a operação Pipedrive desautorizada. IDs de consulta: inventário `9e9edb4386cd746533c557dc`; status `5101df44c44f3f1226f7e7e1`. Isto resolve D5 para a data, não congela o ambiente até a instalação.

| Destinatário | Consequência e ação | Documento |
|---|---|---|
| Core 1.78.0 | O cliente reserva 20 unidades locais por GET, limita a resposta a 512 KiB, recusa `ids` e serializa o transporte por instalação. Projetar e validar P1/P3 com esse contrato. Sem mudança de código solicitada ao Core. | [Impacto Core](wp-mcp-pipedrive-fator3-0.9.0-impacto-base-site-core-fator3.md) |
| MCP 0.43.0 | A política existe e é carregada. Declarar os efeitos das novas operações e validar perfis e capacidades. Perfil personalizado depende dos nomes exatos autorizados. | [Impacto MCP](wp-mcp-pipedrive-fator3-0.9.0-impacto-wp-mcp-fator3.md) |

Não identifiquei alteração de interface Google, Meta ou LinkedIn no escopo proposto. Os documentos de impacto são registros preliminares para o dono; não houve comunicação externa nem alteração dos acompanhantes.

## 3. Mudanças propostas e evidência

### Prioridade anterior a P2: uma recusa pode esconder uma escrita

Exercitei o fluxo `negocio-perder` usando o adaptador e o workflow originais do instalador 0.8.0, junto às classes de operação e cliente lidas do Core 1.78.0. O transporte HTTP, a persistência e os serviços do WordPress foram simulados. A entrada foi feita depois da prévia; a sonda verifica a classificação e a decisão de manter/remover o marcador.

| Resposta HTTP simulada à escrita | Resultado do Core | Resultado do workflow 0.8.0 | Marcador ao final |
|---|---|---|---|
| 200, JSON inválido | `resultado_incerto`, despachada | `operacao_recusada` | Removido |
| 200, 524.289 bytes | `resposta_excedeu_limite`, despachada | `operacao_recusada` | Removido |
| 503 | `resultado_incerto`, despachada | `resultado_parcial_ou_incerto` | Preservado |
| 422, recusa | `fornecedor_recusou` | `operacao_recusada` | Removido |
| 200, resposta válida de sucesso | `ok` | `operacao_concluida` | Removido |

`CoreClient::request` converte os dois primeiros erros em `fornecedor_recusou`; `Workflows::execute` interpreta esse código como desfecho certo. A prova mostra a perda da proteção local. Não demonstra duplicação nem perda de negócio em conta real. **Orientação para a 0.8.0:** se o diário mostrar recusa após despacho com HTTP 2xx, conferir o estado do registro no fornecedor antes de abrir outra tentativa.

**Aceite da correção:** preservar a distinção entre recusa conhecida, ausência de despacho e efeito desconhecido. Após despacho com corpo inválido ou excessivo, a escrita mantém recibo e pendência; repetir a chave não envia escrita; nova tentativa para a mesma entidade fica bloqueada. Para GET grande, reduzir a página quando possível, respeitando orçamento/tempo e sem promover cobertura incompleta a completa. Validar em WordPress com persistência e processo novo. Não repetir automaticamente uma mutação.

### Decisões do plano

| ID | Recomendação | Critério de aceite |
|---|---|---|
| D1 · Regras | Separar aplicar regras de varrer toda a conta. Manter prévia de uso único para as regras exatas, administrador, conta/site, autorização e revisão esperada. Mostrar alcance e validade. | Com 201 e 1.000 leads, alteração de feriado é possível com amostra declarada. Prévia expirada, de outro usuário ou conta e revisão superada falham sem gravar. Uma falha real de origem não se apresenta como “zero devidos”. Validar com o dono se poderá aplicar sem **nenhuma** observação válida; até lá, não criar essa dispensa. |
| D2 · Confirmação | Recomendo retirar a cópia da frase **somente na tela de regras**. Mostrar valores antes/depois, alcance e botão explícito de aplicação; manter nonce, capacidade, posse, prazo e recibo. A confirmação remota permanece. | Uma chamada MCP ou REST não consegue escolher o tratamento do painel por parâmetro. Atualizar as regras exige nova confirmação quando a revisão muda. Frase de operações estruturais fica fora desta mudança. |
| D3 · Fila | Paginar os **leads avaliados**; “só devidos” é um filtro de apresentação. Preservar a visão de bloqueados e motivos, com contadores da página separados dos totais conhecidos. | Página sem devidos pode ter continuação. Distinguir página concluída, fim da fila e falha da fonte. Cursor vinculado a conta, consulta, revisão e instante de avaliação; sem falso devido ao faltar histórico. Testar paginação estável, mudanças concorrentes, expiração e troca de conta. Não prometer snapshot transacional por offset. |
| D4 · Recuperação | Rejeitar liberação em uma chamada baseada apenas na conferência de quem chama. Separar **consultar**, **revisar o caso** e **confirmar uma resolução**. Preservar a relação entre marcador, recibo, entidade e progresso. | Comparar o estado atual com a prévia sob trava da entidade. Confirmado o efeito, registrar o progresso compatível; confirmada a ausência, registrar essa resolução; se a prova é inconclusiva, conservar o bloqueio. Não reenviar a operação. Dois operadores concorrentes não podem resolver estados diferentes. |
| D5 · Acompanhantes | Usar o inventário observado e reconferir no início da homologação. É verificação técnica; não exige que o dono escolha uma versão já instalada. | Registrar identidade dos arquivos relevantes, repetir os testes de fronteira e separar autorizações por ambiente. Não condicionar o editor guiado ou os testes locais à entrega de pacotes sem interface afetada. |

### Correções aos pacotes P1–P7

| Pacote | Ajuste ao plano e teste que decide o aceite |
|---|---|
| P1 · Fila e custo (C1/C6) | R1 registra 200 linhas todas indevidas com 201 leads e nenhuma prévia: a 0.8.0 mistura limite de **saída** e falha da **leitura**. Alterar só o número mantém o defeito. R9 usa 200 leads e 5.000 atividades leves, todas do tipo chamada, sem vínculo com lead. 52→11 chamadas exige uma página de leads e dez de atividades; mantendo leads em 100, são **12**, ou 240 unidades, nessa mesma fixture. Acrescentar notas extensas, atividades WhatsApp abertas e concluídas, detalhes faltantes, página acima de 512 KiB e falha no meio. Medir custo de atravessar a fila inteira, não só da primeira página; não reler todas as atividades a cada continuação. `relatorio.uso_plano` conta leads e negócios ativos visíveis; não fornece total de atividades. Não exigir uma varredura comercial para começar. |
| P2 · Recuperação e diário (C2–C4) | O bloqueio por edição da nota protege a sequência; falta um modo seguro de decidir o que fazer em seguida. R10 mostra que apagar o marcador pode deixar `historico_sem_marcador`. Usar conferência no Core, evidência por etapa e resolução local indivisível; registrar operador, alvo e desfecho sem divulgar a mensagem. Casos: edição e exclusão de atividade, operação parcial, pendência da 0.8.0 sem dados suficientes, troca de conta, repetição e interrupção. Sem prova para atribuir o toque, manter bloqueio e explicar o que falta. |
| P3 · Concorrência e retenção (C5/C11) | Remover a retenção global de dentro da chamada de rede; preservar a trava por entidade e a proteção contra expurgo durante execução. O Core tem outra trava por instalação, com tentativa sem espera. R6 pode provar independência **local**, mas não duas escritas simultâneas bem-sucedidas no fornecedor. Provar recusa antes do despacho e retomada segura. Executar limpeza em lotes com frequência limitada, inclusive no uso exclusivo de operações compostas; preservar marcadores, recibos e etapas ainda necessários. |
| P4 · Painel (C7/C9) | Priorizar habilitar a cadência do zero: guiar por tipo de atividade, horários, sequência e textos; indicar erro ao lado do campo e manter as entradas. Na revisão, mostrar diferença de valores e custo. Usar redirecionamento após POST **e** identificador de tentativa tratado no servidor: F5, clique duplo e reenvio não criam segunda prévia nem novo custo. Verificar por teclado, sem JS e em tela estreita. O painel deve distinguir “não avaliado” de zero e indicar data/alcance da última observação; abrir a tela não dispara varredura do CRM. |
| P5 · Ajuda (C8) | Formatar por seção inclusive acima de 24.000 bytes; permitir navegação entre seções, com âncoras/links válidos e seguros. Testar 30 KB, caracteres UTF-8, continuação, fim e revisão diferente entre páginas. Manter leitura local sem custo comercial. |
| P6 · Testes e build (C10/C12, T1–T4) | Provar conflito entre prévias concorrentes e recusa de rotas fora da lista. T3 passa a testar continuidade sem omissão; T4, proteção do recibo contra expurgo. Substituir mutações que virem comportamento legítimo em P1/P3. Um teste da página fixa de 500 penalizaria a redução correta em resposta grande. Comparar manifesto por caminho e conteúdo para diagnóstico, fixar ferramentas/compressão para reprodução e continuar verificando SHA-256 do ZIP **exato** para distribuir e instalar. |
| P7 · Documentação | Usar a revisão externa da 0.8.0 como base editorial. O procedimento que apaga opção do banco pertence ao diagnóstico histórico: na 0.9.0, documentar a resolução real ou o motivo do bloqueio. Atualizar as 19 operações de referência conforme o catálogo final; validar leitor MCP, exemplo de fila sem devidos com continuação e recuperação incerta, inclusive versão/hash após atualizar. |

Referência pública: [Activities](https://developers.pipedrive.com/docs/api/v1/Activities) documenta páginas de até 500 e cursor. [Leads](https://developers.pipedrive.com/docs/api/v1/Leads) documenta paginação por `start` e `limit`. Nenhuma dessas garantias substitui a lista de parâmetros, os limites de resposta ou o orçamento do Core.

## 4. Instalação e prova da troca

Não houve instalação, mudança de configuração nem chamada à conta comercial nesta rodada. O Site-Teste permaneceu com o Pipedrive 0.8.0 ativo na consulta. A sonda anexa reproduz dez cenários: cinco resultados de escrita e cinco parâmetros de leitura. Foi reexecutada a partir da versão distribuída da sonda; a saída coincide byte a byte com a referência. Não houve mutação real.

Força da evidência recebida: o plano relata **408** asserções de dez suítes. O ZIP contém saídas-base individuais de **oito**, que somam **334**; faltam as saídas-base de `report` (49) e `insights070` (25). Os registros dessas suítes contra mutantes não substituem o original. Não há contradição demonstrada no total; anexar as duas saídas ou repetir as suítes no fechamento. O relatório 0.8.0 registra 550 em outro escopo, incluindo 38 de navegador; os totais não se somam. O arquivo de verificação documental sustenta 201 checagens e detecção dos oito defeitos plantados. A tela fotografada é a da 0.8.0; o layout previsto não teve prova visual nesta análise.

## 5. Banco, migração e correção por nova versão

Desenhar índice de pendências que permita enumerar por conta, com identificador da operação e entidade suficiente para reconciliação. As chaves atuais são derivadas da entidade; não permitem inverter o hash para descobrir o lead. Reaproveitar evidência autenticada quando existir; rotular como não identificável quando faltar. Preservar o recibo original e acrescentar decisão auditável. Progresso, marca de resolução e liberação do bloqueio devem ficar coerentes após queda de processo. Provar em migração com operação concluída, incerta, em execução e política de retenção finita. Não reabrir uma atividade comercial nem fazer downgrade para corrigir o estado.

## 6. O que permanece pendente

Sequência recomendada: **(1)** corrigir e testar o resultado incerto; **(2)** fechar D1/D2 e o contrato de recuperação, desenhar paginação com limites; **(3)** executar P1–P3 e as melhorias independentes de UI/ajuda; **(4)** validar permissões, concorrência, migração, navegador e documentação instalada; **(5)** coordenar homologação no Site-Teste, reconferir inventário e concluir a entrega.

A decisão do dono é sobre aplicar regras com simulação limitada e a confirmação exigida no painel. A orientação técnica é preservar o bloqueio em caso ambíguo. A validação real do Pedido 11 em korvena.com.br, com lead de teste autorizado e repetição sem nova escrita, não está comprovada pelos anexos nem por esta revisão. Não usar as reproduções locais como aceite do fornecedor. Nenhum ticket de outro mantenedor foi criado.

## 7. Credenciais e configuração do dono

Esta análise não requer credenciais nem ampliação de perfil. A eventual prova comercial é do responsável pela conta no ambiente autorizado. Os perfis MCP personalizados devem receber apenas os nomes das operações necessárias, após fechar o contrato. Abrir a tela ou ler o manual não deve autorizar o fornecedor, gastar cota ou expurgar dados.

## 8. Identidade dos arquivos

| Artefato examinado | Bytes | SHA-256 |
|---|---:|---|
| [wp-mcp-pipedrive-fator3-0.8.0-instalador.zip](https://chatgpt.com/library?file_id=libfile_3d24da66f3b48191a261637f46499c4a&account_id=personal) | 122083 | `89e41f2f7a2124eb1a5961fe06d6aff60fd168b8d6dd2ea1b21a272772ff7f30` |
| [wp-mcp-pipedrive-fator3-0.8.0-fonte.zip](https://chatgpt.com/library?file_id=libfile_6646df28690c8191bb8736e123a744d9&account_id=personal) | 507256 | `b4ae837c77c84c4e31a21b5a34b9f5d479189e10e02508026e4b41c2e74cc93b` |
| wp-mcp-pipedrive-fator3-0.9.0-plano.md (revisão analisada) | 19892 | `f9082ce9be7e0bd7a04179d5068ecb99e14f68750bf8d1f59afce97f4f46f654` |
| wp-mcp-pipedrive-fator3-0.8.0-evidencias-revisao-1.zip | 1934640 | `1e0032877c2e1f857c3cb3bafe60c4f1e158c5bd4376688495a87117050a8e8b` |
| wp-mcp-pipedrive-fator3-0.8.0-docs-revisao-1.zip | 46571 | `0a770038f6a33b6b31f16f00a978ebf340224ad6bf71c1ba6b667f2fe3972296` |
| [wp-mcp-pipedrive-fator3-0.9.0-prova-plano.zip](wp-mcp-pipedrive-fator3-0.9.0-prova-plano.zip) (sonda de revisão, não instalável) | 3772 | `09fed72de81b09dc9ece624d94eff5115a32aebce229ab5db020895cdd55d3aa` |

[Relatório da entrega original 0.8.0](https://chatgpt.com/library?file_id=libfile_6d11413454a88191b6b04aab6d04b296&account_id=personal). Os ZIPs-base permanecem inalterados. Este parecer complementa o plano e não altera a documentação instalada. Conferidos os itens do checklist aplicáveis a planejamento; os aceites de release futura estão na seção 6.
