# Impacto de Fator3 MCP Pipedrive 0.9.0 em Fator3 Site Core

10/11/2026, 20:04 −03:00 · Revisão 1 · Planejamento · Aberto · **validação coordenada**. Natureza: contrato de transporte, concorrência e orçamento. Emissor: base 0.8.0, instalador SHA-256 `89e41f2f7a2124eb1a5961fe06d6aff60fd168b8d6dd2ea1b21a272772ff7f30`; alvo previsto 0.9.0, sem instalador. Destinatário: `base-site-core-fator3` 1.78.0, ativo no Site-Teste. Leitura dos arquivos instalados; sem alegação sobre o hash do ZIP completo do Core.

## Mudança e consequência

P1 propõe páginas maiores e filtros no cliente `pipedrive-api-client/1.0.0`; P3 propõe reduzir a trava de retenção do emissor. O Core tem restrições próprias. `F3Base_Pipedrive_Operacao::request` recusa a chave `ids` em qualquer nível da consulta ou corpo antes do transporte, limita query a 16 KiB e resposta a 512 KiB e reserva 20 unidades locais por GET. A documentação pública de Activities permitir um parâmetro não o torna disponível pelo Core. `F3Base_Pipedrive_Trava::executar` obtém uma trava por instalação, sem espera, e a mantém durante o HTTP. Duas escritas sobre leads diferentes não têm garantia de despacho simultâneo.

## Ação ou decisão

Proposta: **nenhuma alteração de código no Core** para esta versão. Trabalhar com parâmetros já admitidos, preservar as barreiras, medir requisições e bytes e tratar contenção antes do despacho. Consultas por `lead_id` ou páginas de coleção são planos possíveis; comparar o custo total com fixtures variadas. Não usar `ids`, nem abrir a lista de segurança do Core para uma otimização ainda sem necessidade demonstrada. A mudança solicitada é de critérios e validação do emissor. Responsáveis pela prova integrada: mantenedor Pipedrive e homologação do Core. Ticket: não criado.

## Diagnóstico, proposta e prontidão do emissor

Arquivos do destinatário examinados: `includes/class-f3base-pipedrive-cliente.php` (SHA-256 `b062262d054049db25e9bd1bc014a03161a4d35210d6a6a91c95d2c357b1966e`), `includes/class-f3base-pipedrive-operacao.php` (`83161604ade7fbaedba8afd0f55ad02a3b6586bdd4305f9616867f75c1b23e41`), `includes/class-f3base-pipedrive-trava.php`, `includes/class-f3base-pipedrive-orcamento.php` e `docs/PIPEDRIVE-OPERACAO.md`. Requests de leitura do cliente e operação: `aadee7dfcbc30eb56f3ff7a7`, `8193d051824207732d342e6e`.

A sonda local reproduziu o contrato do Core com HTTP simulado. `limit=500` e `lead_id` chegaram ao transporte pelos caminhos admitidos. `ids` foi recusado pelo Core e pela política do emissor. `done` e `updated_since` chegaram ao HTTP simulado no Core isolado, mas a política do Pipedrive 0.8.0 os recusa. O teste não atesta resposta da API do fornecedor. Não usar `done=false` ou recorte temporal como prova da inexistência de histórico anterior.

O Core **já distingue** `resultado_incerto` e `resposta_excedeu_limite` após despacho. É o adaptador do emissor que os perde em HTTP 2xx. Proposta ao emissor: preservar códigos conhecidos segundo despacho, HTTP e semântica da operação; nenhuma repetição automática de escrita incerta. Em GET, paginação adaptativa limitada, mesmo cursor/offset de origem e verificação contra duplicidade. A 0.9.0 ainda não implementa esse contrato. Patch no destinatário: não aplicável.

## Sequência, testes e encerramento esperado

1. Corrigir a classificação em Pipedrive e provar no WordPress que recibo e pendência sobrevivem a processo novo. Exercitar 2xx ilegível e >512 KiB, 422 e 503. Ver [sonda anexa](wp-mcp-pipedrive-fator3-0.9.0-prova-plano.zip).
2. Em bancada, exercitar autorização ausente, autorizada, cota insuficiente, resposta grande e contenção da trava do Core. Aceite: zero HTTP quando a recusa antecede o despacho; em dúvida posterior, bloquear; comparar custo da fila completa sob limite de chamadas, bytes e tempo.
3. Provar que a limpeza local não retém a rede e não perde evidência em andamento. Se o segundo despacho for recusado por contenção, comunicar o estado e permitir retomada segura conforme o recibo. Não exigir mudar a trava global do destinatário.
4. Reconferir versões antes da instalação coordenada. Nenhum efeito na conta comercial nesta revisão. Encerrar o impacto com resultados da matriz; reabrir decisão conjunta somente se surgir necessidade de um contrato novo. Nenhuma release do Core ou instalação alheia foi realizada.
