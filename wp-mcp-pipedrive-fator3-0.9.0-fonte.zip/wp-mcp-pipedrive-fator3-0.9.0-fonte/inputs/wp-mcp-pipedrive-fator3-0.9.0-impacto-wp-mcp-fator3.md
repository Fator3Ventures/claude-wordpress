# Impacto de Fator3 MCP Pipedrive 0.9.0 em Fator3 MCP

10/11/2026, 20:04 −03:00 · Revisão 1 · Planejamento · Aberto · **validação coordenada**. Natureza: catálogo, efeitos e perfis de conexão. Emissor: base 0.8.0, instalador SHA-256 `89e41f2f7a2124eb1a5961fe06d6aff60fd168b8d6dd2ea1b21a272772ff7f30`; alvo previsto 0.9.0, sem instalador. Destinatário: `wp-mcp-fator3` 0.43.0 ativo. Nomes de operações novas abaixo são propostas do plano, não operações já publicadas.

## Mudança e consequência

O plano adiciona consulta das pendências e resolução do progresso. `pipedrive/pendencias-ler` expõe estado administrativo da conta; resolver um caso altera estado local e afeta quais futuras operações comerciais serão permitidas. O perfil personalizado do MCP compara o nome da operação a uma lista explícita. O perfil de leitura também considera as anotações da operação e o provedor. Registrar metadados errados pode permitir uma ação fora da intenção do perfil ou impedir consultas legítimas. Abrir a tela de um administrador nativo do WordPress e executar por conexão MCP são caminhos distintos.

## Diagnóstico e proposta ao destinatário

No MCP 0.43.0 instalado, `wp-mcp-fator3.php` carrega `includes/ConnectionContext.php`; o arquivo declara `Fator3\McpFiles\AuthorizationPolicy::check`. A leitura confirmou recusa sem contexto nas condições normais, decisão por perfil/ability e tratamento próprio da chamada administrativa nativa. Requests: declaração `e7586180ecaabdfb5aee2b95`; carregamento `406f424c69f775800ffee758`. Portanto C12 **não é evidência de bypass no MCP instalado**. O ponto de atenção é a condição em `Pipedrive\Api::dispatch` e como cada canal atesta sua origem. O REST nativo da 0.8.0 usa a sua própria capacidade administrativa.

Proposta: manter o contrato do MCP; não é necessário patch ao destinatário neste momento. No emissor, `Api::schemas/abilities/writes/routes` e o despacho devem descrever consulta local pura, consulta com GET ao fornecedor e confirmação com escrita local como efeitos distintos. Marcar como escrita qualquer prévia que grave estado. Exigir administrador e limitar a listagem à conta; listar não revela mensagens ou valores privados de outra conta. Se a origem é uma conexão MCP, uma política ausente não pode habilitar a resolução. Preservar painel nativo autorizado, ajuda local e REST com autorização própria. Não aceitar um campo do chamador para simular origem “painel”.

## Ação, prontidão e sequência

Responsável Pipedrive: fechar o contrato **consulta → revisão → confirmação** antes de publicar nomes finais e metadados. Substituir a proposta de liberar às cegas e evitar duas escritas independentes que deixem o lead destravado com progresso inconsistente. Responsável por perfis/frota: após esse fechamento, identificar os perfis personalizados que realmente precisam da ação e conceder apenas essas abilities. Nenhuma ampliação automática nem alteração de perfil nesta revisão. Ticket: não criado. O emissor está em planejamento, sem contrato-alvo instalado.

## Validação e encerramento

| Cenário | Resultado exigido |
|---|---|
| Admin WordPress + perfil MCP somente leitura | Descoberta e leitura autorizadas segundo o catálogo; nenhuma mutação, inclusive prévia que grave estado. |
| Admin + perfil personalizado sem a operação | Recusa; nenhum registro, avanço ou liberação. Com permissão explícita, resolve apenas o caso autorizado. |
| Operador sem capacidade administrativa, conta/ator trocado, revisão antiga | Consulta privada ou mutação recusada conforme o caso; zero efeito. |
| Admin local sem MCP / conexão sem política válida | Tela e ajuda locais continuam disponíveis; uma chamada remota identificada como MCP não resolve o caso sem política. |
| REST autenticado, sessão de painel, repetição | Rota remota não obtém a dispensa da frase do painel; confirmação repetida devolve o mesmo resultado sem nova ação. |

Provar por descoberta real, por execução positiva e negativa e por inspeção do estado persistido. Não alterar a release do MCP nem exigir suporte a versões antigas. Atualizar este documento com os nomes, efeitos, versões e resultados finais antes de encerrar. Esta revisão confirmou a implementação de política por leitura de fonte; não simulou perfis reais nem exercitou uma ability 0.9.0 no site.
