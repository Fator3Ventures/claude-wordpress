# Plano — Fator3 MCP Pipedrive 0.9.0 (previsto)

Revisão 1 · 2026-11-10 · America/Sao_Paulo · Rodada: planejamento, com revisão documental da 0.8.0.
Slug: `wp-mcp-pipedrive-fator3` · Base: 0.8.0 · Alvo previsto: 0.9.0; instalador-alvo ainda não gerado.
Normas lidas integralmente: `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, ambas revisão 5, de 02/11/2026.

Base examinada, conferida em disco: instalador `wp-mcp-pipedrive-fator3-0.8.0-instalador.zip`, 122.083 bytes, SHA-256 `89e41f2f7a2124eb1a5961fe06d6aff60fd168b8d6dd2ea1b21a272772ff7f30`; fonte `wp-mcp-pipedrive-fator3-0.8.0-fonte.zip`, 507.256 bytes, SHA-256 `b4ae837c77c84c4e31a21b5a34b9f5d479189e10e02508026e4b41c2e74cc93b`. Os dois conferem com a seção 8 do relatório de entrega. Nenhum deles foi alterado e nada foi instalado ou gravado no Site-Teste.

## 1. Conclusão

O que a 0.8.0 promete para o Pedido 11 funciona na bancada: nota sem marcador, pessoa do lead como participante principal, repetição sem nova escrita. As 408 asserções das dez suítes PHP do fonte passaram contra o ZIP entregue, em ambiente que o relatório não cobriu (MariaDB).

Três defeitos comprometem a operação real e são o centro da 0.9.0:

1. **C1.** Com mais de 200 leads abertos a fila não devolve nenhum item devido e a simulação não cria prévia: as regras deixam de poder ser alteradas.
2. **C2.** Editar a nota da atividade de WhatsApp no Pipedrive tira o lead da cadência, e não existe operação para recolocá-lo.
3. **C3.** Uma operação composta que para no meio bloqueia o lead; a pendência não aparece no painel nem em operação alguma, e a única saída é apagar uma opção do banco.

A tela de configuração não configura a função principal do plugin: toques e textos só existem em JSON, e a cadência não pode ser habilitada pelo modo guiado.

Cinco pontos dependem de decisão do dono antes de consolidar a interface (seção 5).

## 2. O que foi executado

| Ambiente | O que | Resultado |
| --- | --- | --- |
| Local | `php -l` em 68 arquivos PHP do instalador e do fonte | Sem erro. |
| Local | Runtime do fonte comparado ao instalador | Idênticos, 36 arquivos. |
| Local | `build/schemas.php` regenerado | Igual a `docs/schemas.json`. |
| Local | `build/package.py installer` | Conteúdo e metadados idênticos; o ZIP sai com 122.217 bytes em vez de 122.083 (achado C10). |
| Bancada: WordPress 7.1.4, PHP 8.3.6, MariaDB 10.11.14 | Instalação do ZIP entregue pelo instalador nativo e dez suítes PHP do fonte, cada uma em processo próprio | 408 aprovadas, 0 reprovadas: native 90, report 49, retention 33, release 56, requests050 48, quality060 32, writes070 34, insights070 25, requests080 37, restart080 4. |
| Bancada | 15 defeitos plantados, um por vez, na cópia instalada | 10 acusados pelas suítes; 5 não acusados (seção 4.2). |
| Bancada | Reproduções R1 a R10, com cliente Core sintético que pagina como a API | Seção 4.1. |
| Bancada, Chrome real no wp-admin | Login, as quatro seções, validar, simular e aplicar regras pelo formulário | Fluxo completo concluído; capturas e medidas na seção 4.3. |
| Site-Teste, pelo conector | Descoberta, `status`, leitura dos 12 documentos, paginação e 11 recusas | 10 operações de leitura e 9 de escrita na 0.8.0; os 12 documentos com tamanho e SHA-256 iguais aos do instalador; recusas conforme o código. |

A bancada usa o mesmo WordPress e o mesmo PHP declarados como mínimo e um banco diferente do relatório (MySQL 8.4.11 lá, MariaDB 10.11.14 aqui). Os dados do CRM são sintéticos.

## 3. O ambiente mudou desde o relatório

| Pacote | Conferido no relatório da 0.8.0 | Ativo no Site-Teste em 10/11/2026 |
| --- | --- | --- |
| Site Core | 1.73.0 | **1.78.0** |
| MCP | 0.41.0 | **0.43.0** |
| Google | 0.30.0 | **0.31.0** |
| Meta | 0.21.0 | 0.21.0 |
| LinkedIn | 0.19.0 | 0.19.0 |
| Pipedrive | 0.8.0 | 0.8.0 |

Valores transcritos da resposta de `plugins/list` (request `fde4fbcffa95572f2e6ada2c`). Com o Core 1.78.0, `pipedrive/status` devolve `registro_cliente: registrado` e `operacao_nao_autorizada`: o registro do contrato continua funcionando; requisições pelo cliente não foram exercitadas, porque a operação comercial está desautorizada no Site-Teste. A fronteira com Core 1.78.0, MCP 0.43.0 e Google 0.31.0 está **não avaliada**: não recebi esses pacotes. Os guias instalados da 0.8.0 citam o Core 1.72.1.

## 4. Achados

Gravidade: **alta** impede uma função em uso real ou deixa um registro sem saída; **média** custa orçamento ou induz erro de operação; **baixa** é acabamento.

### 4.1 Correções

| ID | Grav. | Achado | Evidência |
| --- | --- | --- | --- |
| C1 | alta | A fila corta em 200 leads e trata o corte como coleta parcial. Com 200 leads: `ok`, 200 devidos. Com 201: `coleta_parcial`, motivo `limite_de_saida`, 0 devidos, os 200 itens como `coleta_incompleta`. A simulação com 201 devolve `coleta_parcial`, gasta 80 unidades e deixa 0 prévias gravadas (com 200: 1). `cadencia-fila` não tem parâmetro de paginação. | R1 · `Cadence.php` (laço da fila) |
| C2 | alta | Depois de uma linha acrescentada à mão na nota, a fila devolve `progresso_divergente` e `whatsapp-registrar` devolve `progresso_divergente`. Nenhuma das 19 operações realinha o progresso. Restaurar o texto exato da nota resolve; atividade excluída não tem recuperação. | R2, R10 · `Progress.php` |
| C3 | alta | Releitura que não confirma a atividade deixa `resultado_parcial_ou_incerto` e um marcador de pendência. O mesmo lead passa a receber `reconciliacao_necessaria` em `whatsapp-registrar` e em `api-aplicar`. Não há operação que liste ou libere a pendência, e o painel não a mostra. Liberada à mão, a fila devolve `historico_sem_marcador`. | R10 · `Workflows.php` |
| C4 | média | A linha do diário de uma operação composta não identifica o lead ou o negócio: caminho `pipedrive/whatsapp-registrar`, chaves `chave_idempotencia, lead_id, mensagem, toque`, sem ID. As etapas são gravadas, e o painel não as exibe. | R8 · `Workflows::meta` |
| C5 | média | A trava de retenção é única e fica retida durante a chamada ao fornecedor. Com uma escrita em andamento por 5 s, outro lead recebe `retencao_ocupada` em 1 s e `api-previa` recebe `retencao_ocupada`. A mensagem fala em limpeza. | R6 · `Workflows.php`, `Retention.php` |
| C6 | média | As coletas usam páginas de 100; a API aceita até 500 em `/api/v2/activities` e a lista fechada já permite 500. Com 200 leads e 5.000 atividades: 52 chamadas, 1.040 unidades, 35% do teto diário padrão do Core. Em experimento isolado com páginas de 500: 11 chamadas, 220 unidades. | R9 · `Collection.php` |
| C7 | média | Validar, simular e aplicar respondem ao próprio POST, sem redirecionar. Reenviar o POST de simulação leva de 3 para 6 chamadas, de 60 para 120 unidades e de 1 para 2 prévias. Ocorrências de `wp_safe_redirect` no runtime: 0. Demonstrado no servidor; no Chrome automatizado o recarregamento não reenviou o formulário. | R3 · `Admin.php`, `AdminRules.php` |
| C8 | média | A Ajuda só formata guias de até 24.000 bytes: o mesmo guia com 24.453 bytes vira texto cru paginado. `fluxos` tem 21.490 bytes na 0.8.0. Links em Markdown aparecem literais. | R5 · `Admin::help`, `AdminDocument.php` |
| C9 | média | O modo guiado edita 10 campos; as regras têm 18 grupos. Marcar "Habilitar cadência" a partir das regras iniciais devolve "Cadência habilitada exige dias, períodos, toques e tipo WhatsApp." | R4 · `AdminRules.php` |
| C10 | baixa | O ZIP reproduzido tem o mesmo conteúdo e outro tamanho, porque a compressão depende da biblioteca zlib da máquina. O build não registra versões de ferramentas, e `verify.py` compara bytes do arquivo. | Reprodução local · `build/` |
| C11 | baixa | A limpeza de prévias, recibos e diário vencidos só roda em `api-previa` e `api-aplicar`. Um site que usa só operações compostas nunca expurga. | Conferidor · `Operations.php` |
| C12 | baixa | `Api::dispatch` só consulta a política da conexão se a classe `\Fator3\McpFiles\AuthorizationPolicy` existir; sem ela resta `manage_options`. Leitura de código; não verifiquei se o MCP 0.43.0 mantém essa classe. | `Api.php` |

Fonte do limite de página em C6: https://developers.pipedrive.com/docs/api/v1/Activities, consultada em 10/11/2026. Em GET `/api/v2/activities`, `limit` tem padrão 100 e máximo 500, e existem os filtros `done`, `ids` e `updated_since`.

### 4.2 O que os testes do fonte não acusam

Cada defeito foi plantado na cópia instalada e as suítes pertinentes foram executadas depois de reinstalação limpa.

- **Acusados (10):** participante não principal, marcador de volta à nota, progresso não persistido, lead sem pessoa aceito, nota alterada sem bloqueio, continuação de documento sem hash, prazo finito sem confirmação, fila parcial mantendo devidos, despacho sem checagem de administrador, estrutura sem frase.
- **T1. Guardas de revisão.** Com as duas guardas removidas (`Configuration::save` e `Workflows::apply`), uma prévia antiga sobrescreve regras mais novas (R7 falha), e as 10 suítes passam (native, report, retention, release, requests050, quality060, writes070, insights070, requests080, restart080). No pacote original a guarda funciona (R7: `revisao_conflitante`).
- **T2. Lista fechada.** Com `/v1/users` e `/v1/mailbox/mailMessages` liberados para GET, passam 7 suítes (native, release, requests050, quality060, writes070, insights070, report).
- **T3. Teto da fila.** Trocar 200 por 201 não é acusado (requests050, quality060, requests080).
- **T4. Trava de retenção.** Retirá-la de `whatsapp-registrar` não é acusado (requests050, writes070, requests080, retention): nenhum teste define o que ela protege nesse caminho.

A suíte de navegador do fonte (38 asserções) e a atualização 0.7.0 → 0.8.0 não foram executadas por mim.

### 4.3 Tela de configuração

Medidas tomadas no wp-admin real da bancada, a 1280 × 900.

| Seção | Altura | Painéis | Controles | O que falta |
| --- | --- | --- | --- | --- |
| Visão geral | 730 px | 2 | 0 | Três fatos e três links fixos. Sem saldo, sem pendências, sem leads fora da cadência. |
| Regras, modo guiado | 1.848 px (2.1 telas) | 4 | 18, 0 listas de escolha | Fuso, tipo de atividade, períodos, feriados e motivos em texto livre. Botões só no fim da página. |
| Regras, JSON | 1.371 px | 3 | 1 área de texto | Único caminho para toques, textos e os demais grupos. |
| Diário e retenção | 872 px | 2 | 3 | A retenção vem antes do diário. Sem filtro, sem etapas, sem o registro afetado; hora só em UTC; códigos crus. |
| Ajuda | 3.098 px (3.4 telas) | 2 | 0 | Navegação acima do conteúdo; links não clicáveis. |

A confirmação pede que o administrador copie à mão uma frase de 101 caracteres e mostra só os nomes dos grupos alterados, sem os valores antes e depois. O plugin não carrega nenhum script (0 no painel). Não há rolagem horizontal a 390 px.

## 5. Decisões do dono

| ID | Decisão | Posição que defendo |
| --- | --- | --- |
| D1 | A gravação das regras continua exigindo a leitura completa da conta? | Não. Hoje uma troca de feriado custa uma leitura inteira e fica impossível acima de 200 leads. Proponho que a simulação resuma (contagens e amostra) e que a gravação dependa só da revisão das regras. É mudança de contrato de um Pedido anterior. |
| D2 | A frase literal continua no painel? | Não no painel: nonce, capacidade e posse da prévia já amarram quem aplica, e a frase só acrescenta cópia manual. No MCP ela fica, salvo ordem em contrário. |
| D3 | A fila acima de 200 leads pagina ou devolve só os devidos? | Devolver os devidos, com contadores por motivo e cursor de continuação. Decidir depois de medir a conta real. |
| D4 | As operações novas de recuperação gravam em uma chamada, sem prévia e sem frase? | Sim. São liberações do bloqueio do próprio plugin; a conferência no Pipedrive é de quem chama. |
| D5 | Qual é o conjunto vigente para a 0.9.0? | Core 1.78.0, MCP 0.43.0 e Google 0.31.0, como estão no Site-Teste. Preciso dos instaladores para revalidar a fronteira. |

## 6. Layout proposto

Quadros publicados no canvas "Fator3 MCP Pipedrive — layout proposto da tela (0.9.0)". Os valores entre colchetes são marcadores; nenhum número foi inventado. Não renderizei os quadros para conferência.

1. **Visão geral.** Faixa "Precisa de atenção" no topo (pendências, leads com progresso divergente, alcance da fila), conexão com saldo e barra de orçamento, lista de primeiros passos com estado, e as últimas escritas.
2. **Regras.** Um editor por grupos, com navegação lateral e marca de "alterado", no lugar dos dois modos. Toques em tabela com linhas adicionáveis; textos com contador; tipo de atividade, etiquetas e campos carregados da conta sob demanda. Barra de ação sempre visível com o que mudou e o custo estimado da simulação. O JSON continua como último item, e como caminho sem JavaScript.
3. **Revisar e aplicar.** Etapas explícitas, quatro números (avaliados, devidos, custo, validade com contagem regressiva em hora local), tabela "em vigor × depois de aplicar" por regra, e a confirmação. A frase fica recolhida em "Aplicar pelo MCP", com botão de copiar.
4. **Diário.** A tabela primeiro: hora local com UTC abaixo, nome legível da operação, registro com link para o Pipedrive, resultado em etiqueta, etapas expansíveis, filtros. A pendência abre com as etapas e a ação de liberar. Leads com progresso divergente em lista própria. A retenção vira uma linha com botão.

Como construir: resposta por redirecionamento depois de cada POST; um arquivo de JavaScript sem dependências para linhas repetíveis, aviso de alterações não salvas, cópia, contagem regressiva e expansão; tudo utilizável sem script pelo modo JSON. Título de tela, menu e capacidade permanecem.

## 7. Escopo da 0.9.0

Uma versão só. Para cada pacote, o teste novo precisa falhar com o defeito indicado plantado na árvore real antes de ser aceito.

| Pacote | Conteúdo | Aceite e defeito a plantar |
| --- | --- | --- |
| P1 · Fila e simulação | C1, C6, D1, D3. Antes: medir na conta real leads abertos e atividades (`relatorio.uso_plano` e uma leitura da fila). | R1 com 201 e com 1.000 leads devolve os devidos e permite gravar regras. Plantar: teto de volta a 200; página de volta a 100. |
| P2 · Recuperação | C2, C3, C4, D4. Operações `pendencias-ler`, `pendencia-liberar`, `progresso-realinhar`; ID do registro no diário das operações compostas. | R10 refeito pelas operações, sem tocar no banco. Plantar: liberar sem conferir o ID da prévia; realinhar lead de outra conta. |
| P3 · Travas e limpeza | C5, C11. A trava de retenção cobre só política e limpeza; a limpeza roda também nas operações compostas. | R6: dois leads em paralelo concluem. Antes de mexer, escrever o teste que T4 mostrou não existir. Plantar: trava removida também da limpeza. |
| P4 · Tela | C7, C9 e a seção 6. | Suíte de navegador no wp-admin real: habilitar a cadência do zero sem JSON; F5 depois de simular não cria prévia. Plantar: sem redirecionamento; toque sem texto aceito. |
| P5 · Ajuda | C8. Links clicáveis; guia longo paginado por seção, sem cair em texto cru. | Guia de 30.000 bytes formatado. Plantar: limite de volta a 24.000. |
| P6 · Testes e build | T1, T2, T3, C10, C12. Instantâneo da lista fechada; teste das guardas de revisão; conferidor de documentação no build; versões de ferramentas registradas e comparação por conteúdo. | As mutações m06, m11, m13, m14 e m15 passam a ser acusadas. |
| P7 · Documentação | Incorporar a revisão desta rodada e atualizá-la para o comportamento da 0.9.0. | Conferidor sem reprovação; os oito defeitos plantados continuam acusados. |

Implementação e testes de cada pacote por subagentes, a partir deste plano; a verificação por mutação e o fechamento ficam comigo.

## 8. Impactos em outros pacotes

Nenhum documento de impacto emitido nesta etapa. Registro preliminar:

- **MCP.** As três operações novas de P2 são rotas novas em `pipedrive/`: os perfis de conexão precisam autorizá-las. É configuração, sem mudança de código prevista no MCP. C12 pede confirmar o nome da classe de política no MCP 0.43.0.
- **Core.** P1 passa a enviar `limit` 500 e pode precisar de `done`, `ids` ou `updated_since` em `/api/v2/activities`. **Não avaliado**: não sei se o cliente do Core 1.78.0 restringe parâmetros de consulta nem como o orçamento trata páginas maiores. Decidir com o fonte do Core antes de consolidar P1.
- **Google, Meta, LinkedIn.** Sem fronteira com este pacote no escopo examinado.

## 9. Documentação revisada da 0.8.0

Os guias em Markdown foram revisados para descrever o comportamento atual; nas notas da versão a mudança se limita ao conjunto conferido e aos limites conhecidos; os dois JSON ficaram idênticos. A 0.8.0 instalada é imutável: a revisão entra no instalador da 0.9.0 (P7) e, até lá, vale como referência externa.

| Arquivo | Bytes revisado | Bytes na 0.8.0 | Situação |
| --- | --- | --- | --- |
| `AGENT-GUIDE.md` | 6.027 | 4.174 | revisado |
| `CHANGELOG.md` | 8.510 | 7.259 | revisado |
| `CONFIGURATION.md` | 6.497 | 4.591 | revisado |
| `CONTRACTS.md` | 12.763 | 8.547 | revisado |
| `OPERATIONS.md` | 8.611 | 5.931 | revisado |
| `PANEL.md` | 8.224 | 6.185 | revisado |
| `README.md` | 3.781 | 2.756 | revisado |
| `SPECIFICATION.md` | 9.152 | 6.832 | revisado |
| `USAGE.md` | 11.797 | 13.075 | revisado |
| `WORKFLOWS.md` | 15.612 | 21.490 | revisado |
| `regras-iniciais.json` | 625 | 625 | inalterado |
| `schemas.json` | 50.199 | 50.199 | inalterado |

O que mudou: tabela completa de códigos de retorno com o próximo passo; tabela de limites com a consequência de cada um; as 19 operações com método REST e efeito; procedimentos de recuperação executáveis; passo a passo da primeira configuração com regras mínimas validadas; o que fica gravado no site; limites conhecidos nas notas da versão; exemplos com entrada e saída reais da bancada; referências a versões de acompanhantes retiradas dos guias.

Conferência: 201 checagens aprovadas e 0 reprovadas contra o runtime instalado (operações, 91 códigos extraídos do código, limites com sonda no fonte, identificadores, exemplos, leitura paginada dos 12 documentos e renderização no painel). Dos 8 defeitos plantados em cópias da documentação, 8 foram acusados. Os procedimentos de recuperação foram executados na bancada: 7 de 7 conferidos.

## 10. O que não foi verificado

- Conta real do Pipedrive e aceite do Pedido 11 em korvena.com.br: continuam pendentes, com o responsável pela conta.
- Requisições pelo cliente real do Core: o Site-Teste está desautorizado; a bancada usa cliente sintético.
- Fronteira com Core 1.78.0, MCP 0.43.0 e Google 0.31.0.
- Suíte de navegador do fonte, atualização 0.7.0 → 0.8.0 e MySQL 8.4.
- REST autenticado e o wp-admin do Site-Teste compartilhado.
- Tamanho da conta real: quantos leads abertos e quantas atividades. Sem essa medida, C1 e C6 têm gravidade demonstrada e alcance desconhecido.
- Os quadros do layout não foram renderizados por mim.

## 11. Sequência

1. Dono decide D1 a D5 e entrega os instaladores vigentes dos acompanhantes.
2. Medição da conta real (P1) e leitura do fonte do Core; impacto para o Core, se houver.
3. Implementação de P1 a P7 por subagentes, sobre cópia do fonte 0.8.0.
4. Verificação por mutação de cada pacote na árvore real; instalação limpa e atualização 0.8.0 → 0.9.0 em bancada.
5. Instalação no Site-Teste em janela coordenada, leitura documental pelo MCP, relatório e fechamento dos artefatos.
