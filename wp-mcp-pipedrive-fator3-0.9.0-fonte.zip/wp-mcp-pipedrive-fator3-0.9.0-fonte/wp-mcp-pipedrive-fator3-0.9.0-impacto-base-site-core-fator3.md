# Impacto de Fator3 MCP Pipedrive 0.9.0 em Fator3 Site Core

Revisão 2 · 10/11/2026 · Entrega · Classificação: validação coordenada · Situação: resolvido no escopo técnico testado · Ticket: não aberto.

**Emissor.** Base 0.8.0 (instalador SHA-256 89e41f2f7a2124eb1a5961fe06d6aff60fd168b8d6dd2ea1b21a272772ff7f30). Alvo 0.9.0 instalado e ativo no Site-Teste; instalador SHA-256 42523b9b547fc8820c3917e192c4b48341efbb1da6815c78fcc18f8a373c09c0.

Destinatário: 1.78.0, instalador SHA-256 503a07a6fc1106d1582596c96f10fa9c558fb92cea968782efe26f923b2ccce6. Contrato mantido: pipedrive-api-client/1.0.0. O Core continua a autorizar o consumidor, controlar o orçamento e serializar o transporte por instalação.

**Mudança entregue.** O adaptador Pipedrive preserva a incerteza do Core quando a escrita foi despachada e o resultado não é conclusivo, inclusive em HTTP 2xx com corpo ilegível ou acima do limite. O recibo e a pendência impedem repetição cega. A fila usa paginação admitida, consulta por lead conforme a densidade e redução do tamanho na mesma posição em caso de limite de resposta; não exige o parâmetro ids bloqueado pelo Core. O mutex de retenção do emissor já não cobre o HTTP. A concorrência local entre leads não elimina a trava do Core.

**Validação e aceite técnico.** No WordPress com os acompanhantes reais, as 17 asserções de core-workflows cobrem, entre outras, corpo ilegível/grande em 2xx, bloqueio persistido, ausência de reenvio, nota, participante e orçamento; mais 8 em core e 6 em core-report. HTTP do fornecedor interceptado. A fila com 1.000 leads consumiu 10 GET na massa esparsa e o cenário de 200 leads/5.000 atividades usou 11 GET/220 unidades na massa medida. A recusa comercial no Site-Teste permaneceu após atualizar. O comportamento com o provedor comercial e a necessidade de ajustar o teto à carga real continuam sob controle do dono.

**Ação do destinatário:** nenhuma mudança ou sequência de instalação exigida no Core. Reabrir somente se o emissor passar a exigir outra operação, parâmetro ou garantia de transporte.

**Histórico e reprodução.** Rev. 1 (10/11): diagnóstico e alternativas antes da implementação; preservada em inputs/wp-mcp-pipedrive-fator3-0.9.0-impacto-base-site-core-fator3.md no fonte. Rev. 2: comportamento implementado no emissor, conferido em instalação limpa e na matriz vigente; não houve patch nem entrega de código do destinatário. Para reproduzir: seguir tests/README.md no fonte e executar o cenário matrix, com os ZIPs/hashes de evidence/090/companion-installers.json. Resultados em evidence/090/nativo-matrix, nativo-clean e site-depois.json. Responsáveis: mantenedor Pipedrive pela entrega e mantenedor do destinatário por eventual mudança futura. O aceite comercial do Pedido 11 pertence ao dono da conta.
