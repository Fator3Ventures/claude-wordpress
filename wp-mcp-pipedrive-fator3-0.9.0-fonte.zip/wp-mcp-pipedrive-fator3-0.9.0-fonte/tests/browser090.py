#!/usr/bin/env python3
"""Native WordPress wp-admin test. Only the Pipedrive supplier is synthetic; login, SQL, redirects, assets and UI are real."""
import os,json,time,shutil
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.sync_api import sync_playwright
src=Path(__file__).resolve().parent.parent
root=Path(os.environ['F3_WP_ROOT']);lab=root.parent
assert lab.name=='browser' and (lab/'marker').is_file()
url=os.environ['F3_BROWSER_URL'];assert url=='http://127.0.0.1:18490'
out=src/'evidence/090/browser090.json';out.parent.mkdir(exist_ok=True,parents=True)
steps=[];http=[];js=[];errors=[];metrics=lab/'browser090-counts.jsonl'
def check(name,value):
    steps.append({'teste':name,'aprovado':bool(value)})
    if not value:raise AssertionError(name)
def stat():
    time.sleep(.06)
    data=[json.loads(x) for x in metrics.read_text().splitlines()] if metrics.exists() else []
    return (sum(x['gets'] for x in data),sum(x['writes'] for x in data),data[-1]['drafts'] if data else 0)
result={'ambiente':'wp-admin nativo, banco descartável e cliente Pipedrive sintético','checks':steps}
try:
 with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.environ.get('F3_CHROMIUM',shutil.which('chromium')),args=['--disable-dev-shm-usage','--no-sandbox']);result['chrome']=browser.version
    browserctx=browser.new_context(viewport={'width':1280,'height':880},locale='pt-BR')
    page=browserctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('response',lambda x:http.append(x.status) if x.request.method=='POST' and 'tools.php' in x.url else None)
    page.set_default_timeout(8000)
    pwd=Path(os.environ['F3_BROWSER_PASSWORD_FILE']).read_text().strip()
    page.goto(url+'/wp-login.php');page.locator('#user_login').fill(os.environ['F3_BROWSER_USER']);page.locator('#user_pass').fill(pwd);page.locator('#wp-submit').click()
    tools=url+'/wp-admin/tools.php?page=wp-mcp-pipedrive-fator3';page.goto(tools+'&aba=regras');check('admin_nativo',page.locator('#wpadminbar').count() and page.locator('.f3pd-editor').count())
    rules=page.locator('.f3pd-editor');check('inicio_com_cadencia_desligada',not page.locator('[name=habilitada]').is_checked())
    def btn(name):return page.get_by_role('button',name=name,exact=True)
    def click(name):btn(name).click();page.wait_for_load_state('load')
    def link(name):page.get_by_role('link',name=name,exact=True).click();page.wait_for_load_state('load')
    page.locator('[name=habilitada]').check();page.get_by_label('Segunda',exact=True).check()
    page.get_by_label('Tipo de atividade WhatsApp',exact=True).fill('whatsapp');page.get_by_label('Períodos',exact=True).fill('manha 10:00')
    rules.locator('input[name="textos[0][codigo]"]').fill('boas_vindas');rules.locator('[name="textos[0][texto]"]').fill('Uma mensagem de teste')
    rules.locator('input[name="toques[0][codigo]"]').fill('inicio');rules.locator('input[name="toques[0][texto_id]"]').fill('boas_vindas');rules.locator('[name="toques[0][atraso_minutos]"]').fill('0')
    before=stat();click('Validar campos');check('validar_local_mantem_form_sem_gasto',stat()==before and 'Campos válidos' in page.locator('.f3pd-body').inner_text() and rules.locator('[name="textos[0][texto]"]').input_value()=='Uma mensagem de teste')
    click('Consultar tipos, etiquetas e campos na conta');check('catalogo_so_quando_solicitado',stat()[0]==before[0]+3 and page.locator('datalist#f3pd-list-tipo_whatsapp option[value="whatsapp"]').count()==1)
    posted=[]
    page.on('request',lambda req: posted.append(req.post_data) if req.method=='POST' and 'tools.php' in req.url else None)
    before=stat();click('Simular na conta');review=page.locator('.f3pd-confirm');check('simulacao_em_prev_unica',review.count()==1 and stat()[0]>before[0] and stat()[2]==before[2]+1)
    check('diferencas_e_horario_visiveis',review.get_by_text('Em vigor',exact=True).count() and review.get_by_text('Depois de aplicar',exact=True).count() and review.locator('time[datetime]').count())
    after=stat();page.reload();check('f5_sem_nova_previa_ou_leitura',after==stat() and page.locator('.f3pd-confirm').count()==1)
    response=page.request.post(tools+'&aba=regras',data=posted[0],headers={'Content-Type':'application/x-www-form-urlencoded'},max_redirects=0)
    check('reenvio_post_303_mesma_previa_sem_custo',response.status==303 and stat()==after and parse_qs(urlparse(response.headers['location']).query)==parse_qs(urlparse(page.url).query))
    check('frase_nao_exigida_no_painel',page.locator('input[name=confirmacao]').count()==0)
    assert not page.locator('[name=ordem]').is_checked();click('Aplicar regras simuladas');check('exige_confirmacao_explicita',page.locator('[name=ordem]').evaluate('e=>!e.validity.valid') and stat()==after)
    page.locator('[name=ordem]').check();click('Aplicar regras simuladas');check('habilita_cadencia_pelo_guiado',page.locator('[name=habilitada]').is_checked() and 'Regras persistidas' in page.locator('.f3pd-body').inner_text())
    check('posts_usam_303',http and all(x==303 for x in http))
    link('Configuração completa (JSON)');obj=json.loads(page.locator('[name=regras_json]').input_value());check('persistencia_toque_e_texto',obj['habilitada'] and obj['toques'][0]['texto_id']==obj['textos'][0]['codigo'])
    # Deliberately malformed JSON is retained for editing and must remain inert.
    invalid='</textarea><img id=f3pdx src=x>';page.locator('[name=regras_json]').fill(invalid);before=stat();click('Validar campos')
    check('json_invalido_preservado_e_escapado',stat()==before and page.locator('#f3pdx').count()==0 and page.locator('[name=regras_json]').input_value()==invalid and 'JSON válido' in page.locator('main .notice-error').inner_text())
    link('Diário e retenção');check('diario_tem_registro_e_etapas',page.get_by_role('heading',name='Registro de escritas').count() and page.locator('.f3pd-body table details').count())
    page.get_by_text('Retenção do diário',exact=True).click();check('retencao_abre_sob_demanda',page.get_by_label('Dias de conservação').is_visible())
    page.get_by_label('Dias de conservação').fill('45');click('Salvar retenção');check('retencao_finita_exige_aceite',page.locator('main .notice-error').count()==1)
    page.get_by_text('Retenção do diário',exact=True).click();page.get_by_label('Dias de conservação').fill('45');page.locator('[name=confirmar_expurgo]').check();click('Salvar retenção');check('retencao_finita_persistida',page.get_by_label('Dias de conservação').input_value()=='45')
    page.get_by_text('Retenção do diário',exact=True).click();page.get_by_label('Dias de conservação').fill('0');click('Salvar retenção');check('retencao_sem_prazo_restaurada',page.get_by_label('Dias de conservação').input_value()=='0')
    before=stat();link('Ajuda');check('ajuda_formatada_sem_crm',page.locator('article.f3pd-guide').count() and stat()[0]==before[0])
    link('Schemas JSON');link('Ler próxima parte');check('continuacao_documental_com_hash','revisao=' in page.url and 'offset=' in page.url)
    import re
    page.goto(re.sub('revisao=[a-f0-9]{64}','revisao='+'0'*64,page.url));check('doc_alterado_exige_reinicio',page.locator('main .notice-error').count()==1 and page.get_by_role('link',name='Voltar ao início do documento').count()==1)
    page.set_viewport_size({'width':390,'height':844});link('Regras de operação');check('tela_390_sem_rolagem_lateral',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    page.locator('[name=fuso]').focus();page.keyboard.press('Tab');check('teclado_campos_guiados',page.locator(':focus').get_attribute('name')=='tipo_whatsapp')
    check('nenhuma_escrita_no_fornecedor',stat()[1]==0)
    check('nenhum_erro_js',not errors)
    browserctx2=browser.new_context(java_script_enabled=False,storage_state=browserctx.storage_state());p2=browserctx2.new_page();p2.goto(tools+'&aba=regras')
    n=p2.locator('[data-rows=textos] fieldset').count();p2.get_by_role('button',name='Adicionar linhas para edição').click();p2.wait_for_load_state('load');check('edicao_guiada_sem_js',p2.locator('[data-rows=textos] fieldset').count()>n)
    nonceform=p2.locator('form.f3pd-editor');payload=nonceform.evaluate("f=>{const d=new URLSearchParams(new FormData(f));d.set('f3_pipedrive_action','rules_simulate');d.set('_wpnonce','invalido');return d.toString()}")
    stopped=p2.request.post(tools+'&aba=regras',data=payload,headers={'Content-Type':'application/x-www-form-urlencoded'},max_redirects=0)
    check('nonce_invalido_recusado',stopped.status==403)
    guest=browser.new_context();outsider=guest.request.get(tools+'&aba=regras',max_redirects=0);check('sem_sessao_nao_le_regras',outsider.status in (302,303,403))
    browser.close()
except BaseException as e:
 result['erro']=str(e)[:800]
finally:
 result['aprovadas']=sum(x['aprovado'] for x in steps);result['reprovadas']=sum(not x['aprovado'] for x in steps)+(1 if 'erro' in result and all(x['aprovado'] for x in steps) else 0)
 out.write_text(json.dumps(result,ensure_ascii=False,indent=2));print({k:v for k,v in result.items() if k not in ('checks',)})
if result['reprovadas']:raise SystemExit(1)
