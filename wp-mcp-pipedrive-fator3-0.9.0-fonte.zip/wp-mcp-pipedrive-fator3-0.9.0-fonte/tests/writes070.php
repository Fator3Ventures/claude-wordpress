<?php
/** Ordinary, interrupted and historical receipts exercised against disposable WordPress storage. */
use Fator3\Pipedrive\{Api,Configuration,CoreClient,Retention,Store,Support,Workflows};
global $wpdb;
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||F3_PIPEDRIVE_DISPOSABLE!==true||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))throw new RuntimeException('Disposable only');
require_once __DIR__.'/fixture050.php';
wp_set_current_user(1);
$checks=[];$ids=[];$markers=[];$http=0;
$ok=static function(string $name,bool $passed)use(&$checks){$checks[]=compact('name','passed');};
$guard=static function()use(&$http){++$http;return new WP_Error('http_bloqueado_qa','Nenhum transporte externo na bancada.');};
$fixture=new ReleaseFixture();
$transport=new class($fixture){
    public bool $reorder=false;public $after=null,$onStatus=null;public int $n=0;
    public function __construct(public ReleaseFixture $fixture){}
    public function status(){
        $s=$this->fixture->status();++$this->n;
        if($this->reorder)$s['data']['conta']=array_reverse($s['data']['conta'],true);
        if($this->onStatus)$s=($this->onStatus)($s,$this->n);
        return $s;
    }
    public function request(...$args){
        $r=$this->fixture->request(...$args);
        if($this->after)($this->after)(...$args);
        return $r;
    }
};
$client=new ReflectionProperty(CoreClient::class,'client');$original=$client->getValue();
$options=[Configuration::OPTION=>get_option(Configuration::OPTION,null),Retention::OPTION=>get_option(Retention::OPTION,null)];
$ops=Store::table('ops');$journal=Store::table('journal');
$uuid=static fn($n)=>sprintf('70000000-0000-4000-8000-%012d',$n);
$key=static fn($n)=>'writes070-'.bin2hex(random_bytes(6)).'-'.$n;
$oldId=static fn($account,$key)=>substr(hash_hmac('sha256',Support::json([$account,$key]),wp_salt('auth')),0,32);
$remember=static function($id)use(&$ids){if(!is_string($id)||!preg_match('/^[0-9a-f]{32}$/D',$id))throw new RuntimeException('Missing fixture operation ID');$ids[]=$id;return $id;};
$journalEntry=static function($id)use($wpdb,$journal){$row=$wpdb->get_var($wpdb->prepare("SELECT metadata FROM $journal WHERE previa_id=%s",$id));return is_string($row)?json_decode($row,true):null;};
$legacy=static function($account,$input)use($oldId,$remember){
    $id=$remember($oldId($account,$input['chave_idempotencia']));
    $hash=hash_hmac('sha256',Support::json($input),wp_salt('auth'));
    $p=['workflow'=>'whatsapp-registrar','input'=>$input,'fingerprint'=>$hash];
    Store::create($id,CoreClient::binding(CoreClient::status()),$p);Store::keepMessage($id);
    $meta=['previa_id'=>$id,'metodo'=>'WORKFLOW','caminho'=>'pipedrive/whatsapp-registrar','etapas'=>[]];
    Store::claim($id,$meta);
    $result=['success'=>true,'code'=>'operacao_concluida','previa_id'=>$id,'data'=>['operacao'=>'whatsapp-registrar','id'=>$input['lead_id'],'entrada_digest'=>$hash,'etapas'=>[]]];
    Store::finish($id,$result,$meta);return $result;
};
$pin=static function($scope)use(&$markers){$name=Store::CANONICAL_PENDING.hash('sha256',$scope);$markers[]=$name;return $name;};
add_filter('pre_http_request',$guard);$client->setValue(null,$transport);
try{
    $c=Configuration::defaults();$c['habilitada']=true;$c['tipo_whatsapp']='whatsapp';$c['dias']=[1,2,3,4,5,6,7];
    $c['periodos']=[['codigo'=>'manha','hora'=>'09:00']];$c['textos']=[['codigo'=>'m','texto'=>'Mensagem sintética']];
    $c['toques']=[['codigo'=>'t','base'=>'entrada','atraso_minutos'=>0,'texto_id'=>'m','etiqueta_id'=>'']];$c['lost_reasons']=['QA perda'];
    update_option(Configuration::OPTION,Support::json($c),false);
    $account=$fixture->status()['data']['conta'];$site=Support::digest($account);
    $lead=['id'=>$uuid(1),'person_id'=>88,'add_time'=>'2026-11-01T12:00:00Z','is_archived'=>false];
    $fixture->data['/v1/leads/'.$lead['id']]=$lead;$fixture->data['/api/v2/activities']=[];
    $input=['lead_id'=>$lead['id'],'mensagem'=>'QA única','toque'=>'t','chave_idempotencia'=>$key('new')];
    $res=Api::dispatch('whatsapp-registrar',$input);$id=$remember($res['previa_id']??null);
    $ok('new_message_one_write',$res['success']&&$fixture->writes===1);
    $ok('new_message_receipt_permanent',(int)Store::get($id)['retain_until']===PHP_INT_MAX);
    $calls=count($fixture->requests);$transport->reorder=true;
    $replay=Api::dispatch('whatsapp-registrar',array_reverse($input,true));
    $ok('message_replay_reordered_input_and_account',$replay===$res&&count($fixture->requests)===$calls);
    $changed=array_replace($input,['mensagem'=>'Outro conteúdo']);
    $ok('changed_message_refused_before_reads',Api::dispatch('whatsapp-registrar',$changed)['code']==='idempotencia_conflitante'&&count($fixture->requests)===$calls);
    $transport->reorder=false;

    // Fixed old encoding + noncanonical account / input orders reproduce stored 0.6.0 IDs and digests.
    $oldInput=['toque'=>'t','chave_idempotencia'=>$key('old'),'mensagem'=>'Histórica','lead_id'=>$lead['id']];
    $expected=$legacy($account,$oldInput);$old=$expected['previa_id'];$cipher=Store::get($old)['result'];
    $transport->reorder=true;
    $ok('old_receipt_replays_original_id_without_provider',Api::dispatch('whatsapp-registrar',array_reverse($oldInput,true))===$expected&&count($fixture->requests)===$calls);
    $ok('old_receipt_ciphertext_unchanged',Store::get($old)['result']===$cipher);
    $fixture->revision='second-revision';
    $ok('same_account_new_revision_cannot_replay',Api::dispatch('whatsapp-registrar',$oldInput)['code']==='contexto_alterado'&&count($fixture->requests)===$calls);
    $fixture->revision='fixture040';$wpdb->update($ops,['actor_id'=>99999999],['previa_id'=>$old]);
    $ok('other_actor_cannot_replay',Api::dispatch('whatsapp-registrar',$oldInput)['code']==='previa_de_outro_usuario'&&count($fixture->requests)===$calls);
    $wpdb->update($ops,['actor_id'=>get_current_user_id()],['previa_id'=>$old]);
    $legacy(array_reverse($account,true),$oldInput);
    $ok('two_historical_receipts_require_reconciliation',Api::dispatch('whatsapp-registrar',$oldInput)['code']==='reconciliacao_necessaria'&&count($fixture->requests)===$calls);
    $transport->reorder=false;

    $switch=$transport->n+2;$transport->onStatus=static function($s,$n)use($switch){if($n===$switch)$s['data']['revisao']='different';return $s;};
    $cross=Api::dispatch('whatsapp-registrar',array_replace($input,['chave_idempotencia'=>$key('switch')]));
    $ok('snapshot_rejects_different_context_before_supplier_reads',$cross['code']==='contexto_alterado'&&count($fixture->requests)===$calls);
    $transport->onStatus=null;

    // Expired journal lines must not mix up receipt ownership. Each public original route still replays.
    $wpdb->delete($journal,['previa_id'=>$id]);
    $ok('whatsapp_done_not_replayed_as_workflow_or_raw',Api::dispatch('operacao-aplicar',['previa_id'=>$id])['code']==='operacao_invalida'
        &&Api::dispatch('api-aplicar',['previa_id'=>$id])['code']==='operacao_invalida'&&count($fixture->requests)===$calls);
    $ok('whatsapp_original_route_replays_without_journal',Api::dispatch('whatsapp-registrar',$input)===$res&&count($fixture->requests)===$calls);
    $fixture->data['/v1/notes/7002']=['id'=>7002,'content'=>'QA original'];
    $notePreview=Api::dispatch('api-previa',['metodo'=>'PUT','caminho'=>'/v1/notes/7002','corpo'=>['content'=>'QA nota']]);
    $note=$remember($notePreview['data']['previa_id']??null);$args=['previa_id'=>$note];$noteResult=Api::dispatch('api-aplicar',$args);
    $wpdb->delete($journal,['previa_id'=>$note]);$calls=count($fixture->requests);
    $ok('raw_done_replays_without_journal',$noteResult['success']&&Api::dispatch('api-aplicar',$args)===$noteResult&&count($fixture->requests)===$calls);
    $ok('raw_done_not_replayed_as_workflow',Api::dispatch('operacao-aplicar',$args)['code']==='operacao_invalida'&&count($fixture->requests)===$calls);

    $cfg=$remember(bin2hex(random_bytes(16)));$cfgMeta=['previa_id'=>$cfg,'caminho'=>'pipedrive/configuracao','metodo'=>'WORKFLOW'];
    Store::create($cfg,CoreClient::binding(CoreClient::status()),['workflow'=>'configuracao']);Store::claim($cfg,$cfgMeta);
    $savedError=['success'=>false,'code'=>'revisao_conflitante','message'=>'As regras mudaram.','data'=>[]];
    Store::finish($cfg,$savedError,$cfgMeta);$wpdb->delete($journal,['previa_id'=>$cfg]);$args=['previa_id'=>$cfg];
    $ok('old_config_failure_replays_on_original_routes',Api::dispatch('operacao-aplicar',$args)===$savedError&&Workflows::applySettings($args)===$savedError);
    $ok('config_done_not_replayed_as_raw',Api::dispatch('api-aplicar',$args)['code']==='operacao_invalida'&&count($fixture->requests)===$calls);

    // The second mutation returned in the fixture, but its journal has disappeared.
    $arch=$uuid(2);$path='/v1/leads/'.$arch;
    $fixture->data[$path]=['id'=>$arch,'title'=>'Original','is_archived'=>true,'archive_reason'=>'QA arquivo','archive_time'=>'2026-11-01T12:00:00Z'];
    $p=Api::dispatch('lead-arquivado-editar',['lead_id'=>$arch,'campos'=>['title'=>'QA edição']]);
    $edit=$remember($p['data']['previa_id']??null);$marker=$pin($site.':lead:'.$arch);$before=$fixture->writes;$observed=null;
    $wrong=Api::dispatch('api-aplicar',['previa_id'=>$edit]);
    $ok('wrong_route_cannot_consume_workflow',$wrong['code']==='operacao_invalida'&&$fixture->writes===$before&&Store::get($edit)['state']==='ready');
    $transport->after=static function($method,$unused,$q,$body,$context)use(&$observed,$journalEntry,$journal,$wpdb,$edit){
        if($method==='PATCH'&&isset($body['title'])&&($context['previa_id']??null)===$edit){$observed=$journalEntry($edit);$wpdb->delete($journal,['previa_id'=>$edit]);}
    };
    $failure=Api::dispatch('operacao-aplicar',['previa_id'=>$edit]);$transport->after=null;
    $ok('checkpoint_keeps_workflow_identity',$observed['caminho']==='pipedrive/lead-arquivado-editar'&&$observed['etapas'][0]['etapa']==='desarquivar');
    $ok('lost_edit_checkpoint_stops_compensating_write',$failure['code']==='resultado_incerto'&&$fixture->writes===$before+2&&!$fixture->data[$path]['is_archived']);
    $ok('lost_checkpoint_keeps_claim_and_marker',Store::get($edit)['state']==='running'&&get_option($marker)===$edit);
    $calls=count($fixture->requests);
    $ok('interrupted_operation_never_resends',Api::dispatch('operacao-aplicar',['previa_id'=>$edit])['code']==='resultado_incerto'&&count($fixture->requests)===$calls);

    // The provider accepts both spellings. Its data stays canonical independently of the URL used.
    $mixed='aBcDEFab-CAfe-42aB-80AB-feedF00Dface';$lower=strtolower($mixed);
    $fixture->data['/v1/leads/'.$lower]=['id'=>$lower,'title'=>'Sintético','is_archived'=>false];
    $p=Api::dispatch('api-previa',['metodo'=>'PATCH','caminho'=>'/v1/leads/'.$lower,'corpo'=>['title'=>'Alteração de teste']]);
    $aliasRaw=$remember($p['data']['previa_id']);$args=['previa_id'=>$aliasRaw];$calls=count($fixture->requests);
    $oldMessage=['lead_id'=>$mixed,'mensagem'=>'Mensagem histórica','toque'=>'t','chave_idempotencia'=>$key('legacy')];
    $sealed=$legacy($account,$oldMessage);
    $oldKey=Store::PENDING_PREFIX.hash('sha256',$site.':lead:'.$mixed);$markers[]=$oldKey;add_option($oldKey,$sealed['previa_id'],'',false);
    $altMessage=array_replace($oldMessage,['lead_id'=>$lower]);
    $ok('legacy_message_alias_replays_without_provider',Api::dispatch('whatsapp-registrar',$altMessage)===$sealed&&count($fixture->requests)===$calls);
    $ok('old_mixed_case_marker_blocks_raw_alias_before_dispatch',Api::dispatch('api-aplicar',$args)['code']==='reconciliacao_necessaria'&&count($fixture->requests)===$calls&&Store::get($aliasRaw)['state']==='ready');
    $checkScope=static function($scope){try{Workflows::checkPending($scope);return true;}catch(\Fator3\Pipedrive\Fault $e){return $e->reason;}};
    $ok('legacy_known_target_leaves_other_account_entity_and_deal_independent',
        $checkScope($site.':lead:aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa')===true&&
        $checkScope(str_repeat('0',64).':lead:'.$lower)===true&&$checkScope($site.':deal:7001')===true);
    $wpdb->update($ops,['result'=>''],['previa_id'=>$sealed['previa_id']]);
    $ok('unreadable_old_marker_never_implies_no_pending',Api::dispatch('api-aplicar',$args)['code']==='reconciliacao_necessaria'&&count($fixture->requests)===$calls);
    $ok('opaque_marker_still_excludes_provably_unrelated_uuid_and_deal',$checkScope($site.':lead:7000000a-0000-4000-8000-000000000001')===true&&$checkScope($site.':deal:7001')===true);
    delete_option($oldKey);
    $canonical=$pin($site.':lead:'.$lower);add_option($canonical,$sealed['previa_id'],'',false);
    $fixture->data['/v1/leads/'.$mixed]=$fixture->data['/v1/leads/'.$lower];
    $p=Api::dispatch('api-previa',['metodo'=>'PATCH','caminho'=>'/v1/leads/'.$mixed,'corpo'=>['title'=>'Outra']]);
    $mixedRaw=$remember($p['data']['previa_id']);$calls=count($fixture->requests);
    $ok('both_spellings_hit_same_current_marker',Api::dispatch('api-aplicar',['previa_id'=>$mixedRaw])['code']==='reconciliacao_necessaria'&&Api::dispatch('api-aplicar',$args)['code']==='reconciliacao_necessaria'&&count($fixture->requests)===$calls);
    delete_option($canonical);

    // End-to-end: timeout leaves a done/partial deal receipt; a new raw delete cannot bypass it.
    $fixture->data['/api/v2/deals/7001']=['id'=>7001,'title'=>'QA','status'=>'open','is_archived'=>false];
    $p=Api::dispatch('negocio-perder',['negocio_id'=>7001,'lost_reason'=>'QA perda']);$deal=$remember($p['data']['previa_id']??null);
    $p=Api::dispatch('api-previa',['metodo'=>'DELETE','caminho'=>'/api/v2/deals/7001']);$raw=$remember($p['data']['previa_id']??null);
    $dealMarker=$pin($site.':deal:7001');$fixture->fail='timeout';$partial=Api::dispatch('operacao-aplicar',['previa_id'=>$deal]);$fixture->fail='';
    $ok('uncertain_deal_done_but_still_pending',$partial['code']==='resultado_parcial_ou_incerto'&&Store::get($deal)['state']==='done'&&get_option($dealMarker)===$deal);
    $calls=count($fixture->requests);$blocked=Api::dispatch('api-aplicar',['previa_id'=>$raw]);
    $ok('raw_deal_delete_respects_workflow_pending',$blocked['code']==='reconciliacao_necessaria'&&count($fixture->requests)===$calls&&Store::get($raw)['state']==='ready');

    Retention::configure(['diario_dias'=>7,'confirmar_expurgo'=>true,'revisao_esperada'=>Retention::read()['revisao']]);
    $ordinary=$remember(bin2hex(random_bytes(16)));$meta=['previa_id'=>$ordinary,'status'=>'ok'];
    Store::create($ordinary,CoreClient::binding(CoreClient::status()),['op'=>'qa']);Store::claim($ordinary,$meta);Store::finish($ordinary,['success'=>true],$meta);
    foreach([$deal,$ordinary] as $rid){$wpdb->update($ops,['retain_until'=>time()-1],['previa_id'=>$rid]);$wpdb->update($journal,['created'=>time()-10*DAY_IN_SECONDS],['previa_id'=>$rid]);}
    Store::cleanup();
    $ok('active_pending_receipt_survives_expiry',Support::open(Store::get($deal)['result'])===$partial);
    $ok('active_pending_journal_survives_finite_policy',$journalEntry($deal)['status']==='resultado_parcial_ou_incerto');
    $ok('ordinary_closed_receipt_expires_normally',$wpdb->get_var($wpdb->prepare("SELECT previa_id FROM $ops WHERE previa_id=%s",$ordinary))===null&&$journalEntry($ordinary)===null);
    delete_option($dealMarker);Store::cleanup();
    $ok('released_marker_restores_ordinary_expiry',$wpdb->get_var($wpdb->prepare("SELECT previa_id FROM $ops WHERE previa_id=%s",$deal))===null&&$journalEntry($deal)===null);
    $ok('no_supplier_http_calls',$http===0);
}finally{
    remove_filter('pre_http_request',$guard);$client->setValue(null,$original);
    foreach($markers as $name)delete_option($name);
    foreach(array_unique($ids) as $id){$wpdb->delete($journal,['previa_id'=>$id]);$wpdb->delete($ops,['previa_id'=>$id]);}
    foreach($options as $name=>$value){if($value===null)delete_option($name);else update_option($name,$value,false);}
}
return ['checks'=>$checks,'passed'=>count(array_filter($checks,fn($x)=>$x['passed'])),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed'])),'supplier_http'=>$http,'fixture_writes'=>$fixture->writes];
