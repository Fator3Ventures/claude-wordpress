<?php
$mode=$argv[1]??'';
if(!is_file(__DIR__.'/marker')||is_link(__DIR__.'/marker')||trim(file_get_contents(__DIR__.'/marker'))!=='f3-pipedrive-disposable-0900-d848899a8f83')exit(3);
if(!in_array($mode,['install','install-base','seed-upgrade','upgrade','verify-upgrade','upgrade-restart','native','report','retention','integrate','integrated','core','core-report','release','requests050','documents050','quality060','writes070','insights070','requests080','restart080','bootstrap','core-workflows','diagnostics','dev-install','escritas090','policy090','recuperacao090','fila090','travas090','doc090','restart090','painel090','mutacao-fila090'],true))exit(2);
define('F3_PIPEDRIVE_DISPOSABLE',true);
if(in_array($mode,['install','install-base','dev-install'],true))define('WP_INSTALLING',true);
define('ABSPATH',__DIR__.'/wordpress/');require ABSPATH.'wp-load.php';
if(!in_array($wpdb->prefix,['f3pipqa_0900c_','f3pipqa_0900u_','f3pipqa_0900v_'],true)||!defined('WP_HOME')||!in_array(rtrim(WP_HOME,'/'),['http://127.0.0.1:18491','http://127.0.0.1:18490'],true))exit(3);
require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/template.php';
if(!defined('WP_INSTALLING'))wp_set_current_user(1);$result=[];
try {
 if($mode==='dev-install'){
  require_once ABSPATH.'wp-admin/includes/upgrade.php';
  if(!is_blog_installed())wp_install('Pipedrive disposable QA','qa_admin','qa@example.test',true,'',is_file(__DIR__.'/pw')?trim(file_get_contents(__DIR__.'/pw')):wp_generate_password(40));
  wp_set_current_user(1);$r=activate_plugin('wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php');if(is_wp_error($r))throw new RuntimeException($r->get_error_code());$result=['active'=>is_plugin_active('wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php')];
 }elseif(in_array($mode,['install','install-base'],true)){
  require_once ABSPATH.'wp-admin/includes/upgrade.php';
  if(!is_blog_installed())wp_install('Pipedrive disposable QA','qa_admin','qa@example.test',true,'',wp_generate_password(40));
  wp_set_current_user(1);if(!defined('FS_METHOD'))define('FS_METHOD','direct');require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
  $up=new Plugin_Upgrader(new Automatic_Upgrader_Skin());$r=$up->install(__DIR__.($mode==='install-base'?'/base.zip':'/installer.zip'));
  if($r!==true)throw new RuntimeException('Native install failed');
  $r=activate_plugin('wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php');if(is_wp_error($r))throw new RuntimeException($r->get_error_code());
  $result=['installed'=>true,'version'=>get_plugin_data(WP_PLUGIN_DIR.'/wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php',false,false)['Version'],'wp'=>$wp_version,'php'=>PHP_VERSION,'mysql'=>$wpdb->db_version(),'storage'=>get_option('f3_pipedrive_schema'),'zip_sha256'=>hash_file('sha256',__DIR__.($mode==='install-base'?'/base.zip':'/installer.zip'))];
 }elseif($mode==='seed-upgrade'){
  if(Fator3\Pipedrive\VERSION!=='0.8.0')throw new RuntimeException('Wrong upgrade base');
  $policy=Fator3\Pipedrive\Retention::read();Fator3\Pipedrive\Retention::configure(['diario_dias'=>730,'revisao_esperada'=>$policy['revisao'],'confirmar_expurgo'=>true]);
  $ops=Fator3\Pipedrive\Store::table('ops');$journal=Fator3\Pipedrive\Store::table('journal');
  foreach(['done','ready','running'] as $state){$id=bin2hex(random_bytes(16));$wpdb->insert($ops,['previa_id'=>$id,'actor_id'=>1,'binding'=>str_repeat('0',64),'state'=>$state,'created'=>time()-400*DAY_IN_SECONDS,'expires'=>time()-1,'retain_until'=>time()+3600,'payload'=>Fator3\Pipedrive\Support::seal(['synthetic'=>'preserve']),'result'=>$state==='done'?Fator3\Pipedrive\Support::seal(['success'=>true,'fixture'=>true]):'']);if($state!=='ready')$wpdb->insert($journal,['previa_id'=>$id,'created'=>time()-400*DAY_IN_SECONDS,'metadata'=>wp_json_encode(['previa_id'=>$id,'metodo'=>'PUT','caminho'=>'/v1/notes/900','classe'=>'registro','status'=>$state,'chaves_alteradas'=>['content'],'saldo_depois'=>null])]);}
  $rules=Fator3\Pipedrive\Configuration::defaults();$rules['habilitada']=true;$rules['fuso']='America/Sao_Paulo';$rules['dias']=[1,2,3,4,5];$rules['periodos']=[['codigo'=>'manha','hora'=>'09:30']];$rules['tipo_whatsapp']='qa_wa';$rules['textos']=[['codigo'=>'qa','texto'=>'Mensagem sintética']];$rules['toques']=[['codigo'=>'t1','base'=>'entrada','atraso_minutos'=>60,'texto_id'=>'qa','etiqueta_id'=>'','prazo'=>'minutos_uteis']];$rules['feriados']=['2026-12-25'];$rules['canais']=[['codigo'=>'protegido','condicao'=>['campo'=>'origem','operador'=>'igual','valores'=>[7]],'permitir_encerramento'=>false,'permitir_arquivamento'=>false]];
  update_option(Fator3\Pipedrive\Configuration::OPTION,Fator3\Pipedrive\Support::json($rules),false);
  require_once __DIR__.'/tests/fixture050.php';$fixture=new ReleaseFixture();$prop=new ReflectionProperty(Fator3\Pipedrive\CoreClient::class,'client');$prop->setValue(null,$fixture);$id='60000000-0000-4000-8000-000000000002';$fixture->data['/v1/leads/'.$id]=['id'=>$id,'add_time'=>'2026-11-01T00:00:00Z','is_archived'=>false,'person_id'=>75,'label_ids'=>[]];$msg=['lead_id'=>$id,'mensagem'=>'Registro de migração sintético','toque'=>'t1','chave_idempotencia'=>'upgrade070-wa-01'];$receipt=Fator3\Pipedrive\Api::dispatch('whatsapp-registrar',$msg);if(!$receipt['success']||$fixture->writes!==1)throw new RuntimeException('Não foi criado o recibo real de fixture da base');
  add_option('f3_pd_pending_'.str_repeat('a',64),'synthetic-pending-060','',false);
  $rulesRaw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",Fator3\Pipedrive\Configuration::OPTION));
  $snapshot=['message'=>$msg,'receipt'=>$receipt,'rules_raw'=>$rulesRaw,'rules_revision'=>Fator3\Pipedrive\Configuration::read()['revisao'],'ops'=>$wpdb->get_results("SELECT * FROM $ops ORDER BY previa_id",ARRAY_A),'journal'=>$wpdb->get_results("SELECT * FROM $journal ORDER BY id",ARRAY_A),'schema'=>get_option('f3_pipedrive_schema'),'retention'=>get_option('f3_pipedrive_retention'),'docs'=>hash_file('sha256',Fator3\Pipedrive\ROOT.'/docs/schemas.json')];
  file_put_contents(__DIR__.'/upgrade-snapshot.json',wp_json_encode($snapshot));$result=['base_version'=>Fator3\Pipedrive\VERSION,'operations'=>count($snapshot['ops']),'journal'=>count($snapshot['journal']),'snapshot_sha256'=>hash('sha256',wp_json_encode($snapshot))];
 }elseif($mode==='upgrade'){
  if(Fator3\Pipedrive\VERSION!=='0.8.0')throw new RuntimeException('Wrong upgrade source');
  if(!defined('FS_METHOD'))define('FS_METHOD','direct');require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
  $up=new Plugin_Upgrader(new Automatic_Upgrader_Skin());$r=$up->install(__DIR__.'/installer.zip',['overwrite_package'=>true]);
  if($r!==true)throw new RuntimeException('Native overwrite failed');
  $result=['upgraded_files'=>true,'next_process_required'=>true,'current_process'=>Fator3\Pipedrive\VERSION,'zip_sha256'=>hash_file('sha256',__DIR__.'/installer.zip')];
 }elseif($mode==='verify-upgrade'){
  $snapshot=json_decode(file_get_contents(__DIR__.'/upgrade-snapshot.json'),true);$ops=Fator3\Pipedrive\Store::table('ops');$journal=Fator3\Pipedrive\Store::table('journal');
  $tests=['version'=>Fator3\Pipedrive\VERSION==='0.9.0','active'=>is_plugin_active('wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php'),'operations_byte_equal'=>$snapshot['ops']===$wpdb->get_results("SELECT * FROM $ops ORDER BY previa_id",ARRAY_A),'journal_byte_equal'=>$snapshot['journal']===$wpdb->get_results("SELECT * FROM $journal ORDER BY id",ARRAY_A),'schema_unchanged'=>$snapshot['schema']===get_option('f3_pipedrive_schema'),'retention_preserved'=>get_option('f3_pipedrive_retention')===$snapshot['retention']&&Fator3\Pipedrive\Retention::read()['diario_dias']===730,'docs_updated'=>$snapshot['docs']!==hash_file('sha256',Fator3\Pipedrive\ROOT.'/docs/schemas.json')];
  $tests['rules_raw_byte_equal']=$snapshot['rules_raw']===$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",Fator3\Pipedrive\Configuration::OPTION));
  $tests['rules_revision_unchanged']=$snapshot['rules_revision']===Fator3\Pipedrive\Configuration::read()['revisao'];
  $tests['pending_marker_preserved']=get_option('f3_pd_pending_'.str_repeat('a',64))==='synthetic-pending-060';
  require_once __DIR__.'/tests/fixture050.php';$fixture=new ReleaseFixture();$prop=new ReflectionProperty(Fator3\Pipedrive\CoreClient::class,'client');$prop->setValue(null,$fixture);
  $reply=Fator3\Pipedrive\Api::dispatch('whatsapp-registrar',$snapshot['message']);$tests['old_receipt_replays_without_write']=$reply===$snapshot['receipt']&&$fixture->requests===[]&&$fixture->writes===0;
  $fixture->revision='qa-new-revision';$reply=Fator3\Pipedrive\Api::dispatch('whatsapp-registrar',$snapshot['message']);$tests['changed_context_blocks_replay']=$reply['code']==='contexto_alterado'&&$fixture->writes===0;
  $tests['whatsapp_receipt_and_progress_still_permanent']=(int)$wpdb->get_var("SELECT COUNT(*) FROM $ops WHERE retain_until=9223372036854775807")===2;
  Fator3\Pipedrive\Store::install();$tests['activation_preserves_old_journal']=$snapshot['journal']===$wpdb->get_results("SELECT * FROM $journal ORDER BY id",ARRAY_A);
  $r=Fator3\Pipedrive\Api::dispatch('retencao-configurar',['diario_dias'=>730,'revisao_esperada'=>Fator3\Pipedrive\Retention::read()['revisao'],'confirmar_expurgo'=>true]);$tests['finite_choice_saved']=$r['success'];
  $result=['checks'=>$tests,'passed'=>count(array_filter($tests)),'failed'=>count(array_filter($tests,fn($v)=>!$v))];
 }elseif($mode==='upgrade-restart'){
  $p=Fator3\Pipedrive\Retention::read();Fator3\Pipedrive\Store::install();$tests=['choice_after_restart'=>$p['diario_dias']===730,'choice_after_reactivation'=>$p===Fator3\Pipedrive\Retention::read()];$result=['checks'=>$tests,'passed'=>count(array_filter($tests)),'failed'=>count(array_filter($tests,fn($v)=>!$v))];
 }elseif($mode==='integrate'){
  foreach(['wp-mcp-fator3','base-site-core-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3'] as $slug){$r=activate_plugin($slug.'/'.$slug.'.php');if(is_wp_error($r))throw new RuntimeException('Activate '.$slug.': '.$r->get_error_code());}
  $result=['companions_active'=>true];
 }elseif($mode==='bootstrap'){
  $root=Fator3\Pipedrive\ROOT.'/';$files=array_values(array_filter(get_included_files(),fn($p)=>str_starts_with($p,$root)));$result=['version'=>Fator3\Pipedrive\VERSION,'runtime_files'=>array_map(fn($p)=>substr($p,strlen($root)),$files),'count'=>count($files)];
 }elseif($mode==='diagnostics'){ $log=WP_CONTENT_DIR.'/debug.log';$content=is_file($log)?file_get_contents($log):'';$result=['wp'=>$wp_version,'php'=>PHP_VERSION,'log_bytes'=>strlen($content),'pipedrive_errors'=>preg_match_all('/^.*(?:Warning|Notice|Deprecated|Fatal|Parse error).*wp-mcp-pipedrive-fator3.*$/mi',$content),'installed_version'=>Fator3\Pipedrive\VERSION];
 }else{if(!defined('Fator3\\Pipedrive\\VERSION'))throw new RuntimeException('Runtime nativo indisponível neste cenário');$result=require __DIR__.'/tests/'.($mode==='core'?'core-retention':$mode).'.php';}
}catch(Throwable $e){$result=['exception'=>get_class($e),'message'=>$e->getMessage(),'file'=>basename($e->getFile()),'line'=>$e->getLine(),'checks_so_far'=>$checks??[]];}
echo 'F3_QA_RESULT='.json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
exit(isset($result['exception'])||!empty($result['failed'])?1:0);
