<?php
declare(strict_types=1);
use Fator3\Pipedrive\{Api,CoreClient};
require_once __DIR__.'/fixture050.php';

/** Local transport for two independent processes; no HTTP can leave the fixture. */
function f3qa090_messaging(string $lead,string $key,bool $hold,?callable $beforeFirstGet=null): array {
    $fixture=new ReleaseFixture();$fixture->revision='retencao-090';
    $fixture->data['/v1/leads/'.$lead]=['id'=>$lead,'person_id'=>17,'add_time'=>'2026-11-01T12:00:00Z','is_archived'=>false,'label_ids'=>[]];
    $transport=new class($fixture,$hold,$beforeFirstGet) {
        public function __construct(private ReleaseFixture $base,private bool $hold,private $onGet){}
        public function status(): array {return $this->base->status();}
        public function request($method,$path,$q,$body,$context): array {
            if ($this->onGet && $method==='GET') {$change=$this->onGet;$this->onGet=null;$change();}
            if ($this->hold && $method==='POST' && $path==='/api/v2/activities') {
                // Only after receipt claim, persistent marker and checkpoint.
                fwrite(STDOUT,"QA_DISPATCH ".($context['previa_id']??'')."\n");fflush(STDOUT);
                stream_set_timeout(STDIN,20);
                if (trim((string)fgets(STDIN))!=='QA_RELEASE') throw new RuntimeException('Barreira de fixture interrompida.');
                $this->hold=false;
            }
            return $this->base->request($method,$path,$q,$body,$context);
        }
    };
    $p=new ReflectionProperty(CoreClient::class,'client');$previous=$p->getValue();$p->setValue(null,$transport);
    try {$r=Api::dispatch('whatsapp-registrar',['lead_id'=>$lead,'mensagem'=>'Mensagem sintética de concorrência','toque'=>'t1','chave_idempotencia'=>$key]);}
    finally {$p->setValue(null,$previous);}
    return ['code'=>$r['code'],'receipt'=>$r['previa_id']??null,'writes'=>$fixture->writes];
}
