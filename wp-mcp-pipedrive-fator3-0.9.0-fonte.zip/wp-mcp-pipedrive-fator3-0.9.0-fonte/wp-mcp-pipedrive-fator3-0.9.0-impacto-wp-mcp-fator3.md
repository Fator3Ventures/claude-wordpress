# Impacto de Fator3 MCP Pipedrive 0.9.0 em Fator3 MCP

Revisão 2 · 10/11/2026 · Entrega · Classificação: validação coordenada · Situação: resolvido no escopo técnico testado · Ticket: não aberto.

**Emissor.** Base 0.8.0 (instalador SHA-256 89e41f2f7a2124eb1a5961fe06d6aff60fd168b8d6dd2ea1b21a272772ff7f30). Alvo 0.9.0 instalado e ativo no Site-Teste; instalador SHA-256 42523b9b547fc8820c3917e192c4b48341efbb1da6815c78fcc18f8a373c09c0.

Destinatário: 0.43.0, instalador SHA-256 c0f3a10ad4275dc51abd4ab01ac9d2647914fb13d214b9e4f460cd989ddf4951. Contratos mantidos: descoberta e política de acesso por perfil e nome exato.

| Operação registrada | Método | Efeito e autorização |
|---|---|---|
| pipedrive/pendencias-ler | GET | Leitura local da conta e operador autorizados, sem HTTP ao fornecedor. |
| pipedrive/recuperacao-previa | POST | Consulta a evidência disponível, inclusive por GET quando necessário; grava uma prévia local. Classificada como escrita. |
| pipedrive/recuperacao-confirmar | POST | Revalida e registra a decisão localmente; não repete a escrita comercial. Classificada como escrita. |

**Mudança entregue.** O catálogo passa de 19 para 22 operações. A origem administrativa nativa é determinada pelo servidor; os chamadores remotos não podem dispensar o consentimento declarando que são o painel. Um perfil de leitura não ganha permissão de resolver casos; perfis personalizados precisam incluir explicitamente os nomes pretendidos, além das demais autorizações da conta, do ator e do administrador.

**Validação e aceite técnico.** O MCP 0.43.0 foi testado na matriz com perfis de leitura e personalizados; a suíte integrada passou 59/59. As suítes de política e recuperação exercitam acesso anônimo, contexto ausente, transferência de ator, revisão e confirmação. A descoberta no Site-Teste publicou 22 nomes (11 de leitura e 11 de escrita); sem autorização comercial a nova consulta devolveu operacao_nao_autorizada. Todos os 12 documentos continuam acessíveis ao administrador habilitado.

**Ação do destinatário:** nenhuma mudança de código no MCP. Antes de usar a recuperação numa conexão de frota, seu administrador confere o acesso das três operações e concede só as necessárias. Nenhum perfil compartilhado foi ampliado. Não há ordem de troca obrigatória entre os dois pacotes.

**Histórico e reprodução.** Rev. 1 (10/11): diagnóstico e alternativas antes da implementação; preservada em inputs/wp-mcp-pipedrive-fator3-0.9.0-impacto-wp-mcp-fator3.md no fonte. Rev. 2: comportamento implementado no emissor, conferido em instalação limpa e na matriz vigente; não houve patch nem entrega de código do destinatário. Para reproduzir: seguir tests/README.md no fonte e executar o cenário matrix, com os ZIPs/hashes de evidence/090/companion-installers.json. Resultados em evidence/090/nativo-matrix, nativo-clean e site-depois.json. Responsáveis: mantenedor Pipedrive pela entrega e mantenedor do destinatário por eventual mudança futura. O aceite comercial do Pedido 11 pertence ao dono da conta.
