# Guia para agentes · 0.30.0

1. Descubra `google/documentation`. Leia o índice com `{}`. Se o documento tiver mais de uma página, continue em `next_offset` enviando `expected_revision` do índice. Para a configuração pelo painel, use **GUIA-0.30.0.md**.
2. Consulte `google/status` com `{"compact":true,"connection_id":"default"}` e `google/readiness-status`. Identifique a conexão, o serviço e o recurso. Credencial configurada e acesso ao recurso são verificações distintas.
3. Consulte `google/ability-catalog` com prefixo e modo. Para o planejador use `{"prefix":"ads/keyword-","mode":"read"}`. Confira `available`, `unavailable_reason` e o schema da operação antes de executá-la.
4. Para revisar uma configuração, consulte `google/configuration-schema` e use a operação específica indicada no campo. Use simulação, revisão esperada e confirmação quando o contrato exigir. Confira o valor persistido após a gravação.
5. Para falhas de lista de recursos, consulte o diagnóstico da conexão correta. Para uma coleta parcial, leia o recibo e retome apenas a parte pendente. Para uma escrita remota incerta, procure o recibo e reconcilie antes de repetir.

**Referências por tarefa.** PLANEJADOR.md descreve sementes, cota, cursor e junção com Search Console. CORE-ACERVOS.md cobre a seleção dos leitores. SDK-PHP.md documenta os contratos locais. CONVERSOES.md e AVISOS-RENOVACAO.md descrevem verificação e recuperação. O catálogo instalado e os schemas publicados identificam os nomes efetivos da release.

Para um diagnóstico antigo, confira a conexão, o método e a hora e peça ao administrador uma nova verificação dos serviços envolvidos. Para ideias interrompidas, descubra o estado confirmado por `ads/keyword-archive` e siga a seção de retomada de PLANEJADOR.md. O índice de documentação retorna tamanho e revisão sem carregar os manuais. Na leitura paginada, preserve o SHA-256 entre as páginas e use o deslocamento em bytes retornado pela operação.

Na 0.31.0, para Pedidos MCP Google 49, siga a seção de descoberta e diagnóstico de PLANEJADOR.md. O catálogo do produtor e a descoberta do transporte têm papéis distintos; compare ambos, respeitando o perfil da conexão.
