# ADR-001-FILA · 0.31.0

O guia GUIA-0.31.0.md descreve as telas atuais. Para instalação, atualização ou correção use MIGRACAO.md. O catálogo e os schemas instalados descrevem as interfaces vigentes.

## Referência técnica e histórico de contratos

# Documentação corrente — 0.26.0

## Versão 0.26.0 — Integração Core 1.65.1

Atualização direta da 0.24.0. Guia instalado da integração Ads/GSC com o Core entregue, configuração do leitor corrigida e proposta histórica desativada. Permanecem 300 habilidades (115 de leitura, 185 de escrita), 42 opções e todos os contratos. Pedidos Google 43–46 estão preservados: avisos de formato da Service Account com validação remota; acervo Ads cifrado permanente e leitor local `google-ads-reader/1.0.0`; GSC `search-console-reader/1.1.0` consulta/página/dia com concessão própria e GSC 1.0 independente.

Acompanhantes desta rodada: Core 1.65.1, MCP 0.38.0, Meta 0.17.0 e LinkedIn 0.13.0. O Core já incorpora os consumidores Ads/GSC e a reconciliação comercial. Configure o leitor por `f3base_google_ads_acervo`; preserve `f3base_google_ads` para conversões/tag. Não reaplique os adaptadores históricos Core323/337/340/342. A operação integrada está em CORE-ACERVOS.md; resultados e limites constam do relatório externo. Somente Google é atualizado por esta release.
## Histórico da 0.21.0 — preservado como referência

Base direta **0.20.0**. Acompanhantes examinados: Core 1.57.1, MCP 0.33.0, Meta 0.12.0, LinkedIn 0.11.0 e Pipedrive 0.2.0. O relatório externo distingue convivência, provas nativas e fornecedor real. A versão amplia conversões, consultas e diagnósticos, preservando a retenção ilimitada e o SDK GA4 da 0.20.0. As seções versionadas anteriores abaixo são histórico; não definem a base de atualização desta rodada.

# ADR 001 — Repositório e executor de tarefas

Revisão 0.19.0: estrutura de fila preservada; rotação de chave da mesma identidade conserva revisão de execução, grants, referências e validade das provas dos destinos. Compatibilidade verificada com Core 1.49.1. Evidência corrente: `evidence/019` e relatório externo. As referências das revisões anteriores abaixo são históricas.

Atualização 0.14.0: base direta Google 0.13.0; adaptador Core de entrega 1.0.0 e leitura de transporte negociada 1.1.0, sem fila Google paralela. Prontidão é por conexão e exige verificação; resultado incerto não permite repetição automática. Evidências correntes e limites no relatório 0.14.0; as seções versionadas anteriores abaixo são históricas.

Decisão vigente na **0.13.0**: manter o repositório próprio indexado e o worker compartilhado por MCP, WP-Cron e WP-CLI.

A tabela `{prefix}f3_google_records` usa metadados indexados, proprietário/geração da lease, confirmação por leitura e commits transacionais de resultado/cursor. A tabela `{prefix}f3_google_cron` mantém passagens/incidentes e projeções por origem. Limites cooperativos e cursores controlam manutenção e histórico.

A instalação limpa cria diretamente o schema atual; a atualização utiliza os registros da 0.12.0. Não existem fases históricas de cópia/verificação ou fallback de registros em options. As proteções correntes — recuperação fora do banco, drenagem, contexto, geração, orçamento, lease e validação da intenção — permanecem.

A reconciliação de um evento terminal cujo resumo ainda não foi gravado é necessária no funcionamento atual. Ela preserva o resultado sem repetir o job nem a chamada Google. Escrita despachada sem conclusão confirmada permanece `unknown` e requer consulta/reconciliação do destino.

O custo da decisão é manter schema, SQL, concorrência e recuperação. A suíte nativa verifica WordPress e MySQL reais; o dublê unitário não demonstra a semântica transacional do servidor. Não há promessa de execução remota exatamente uma vez. Nenhuma tabela ou ação de outro plugin é apagada.

Action Scheduler foi avaliado em uma release anterior; não integra o runtime e não é uma dependência desta bancada. O leitor PHP GSC continua independente da fila: uma consulta do Core não fabrica passagem cron Google.


## Atualização 0.20.0

Pedidos 37/38: retenção 0 sem prazo e SDK ga4-reader/1.0.0. Valores explícitos da base 0.19.0 permanecem; manutenção protege os registros presentes quando configurada retenção ilimitada. GSC não muda. O SDK GA4 não implementa o acervo do Core. Consulte o guia 0.20.0 e SDK-PHP para concessão, cotas, limites e uso.
