# Atualização e recuperação · 0.31.0

A atualização direta parte da 0.30.0. A instalação limpa exige WordPress 7.1.4 e PHP 8.3 ou superiores. A release usa a tabela de registros existente e não agenda coleta, concede permissão ou solicita credencial ao instalar.

1. Antes da troca, confira a versão, a saúde, a seleção de serviços e a identidade da conexão. Preserve backup do banco e das salts que protegem as credenciais e o acervo.
2. Confira o SHA-256 do instalador contra o relatório. Atualize pelo basename existente, com sobrescrita explícita e conferência de identidade.
3. Em uma nova requisição, consulte `google/readiness-status` e abra `google/documentation`. Confira a versão 0.31.0 e o guia desta release.
4. Em **Acervo Ads**, abra uma conta que já tinha coleta e verifique seus conjuntos de dados e janelas. No planejador, recibos e históricos da 0.27.0 continuam legíveis.
5. Uma falha de página conserva o último checkpoint confirmado. Releia o recibo antes de retomar. Conversões com resultado incerto exigem reconciliação por recibo antes de qualquer nova tentativa.

Se surgir uma regressão após instalar, pause o fluxo afetado, preserve os registros e aplique a correção em uma versão posterior. Os dados de recuperação e os recibos de efeitos externos precisam acompanhar essa correção.

Reabra formulários que já estavam no navegador ao atualizar. Gere novamente as prévias administrativas pendentes. Para validar um diagnóstico, confira a conexão, a identidade e a hora em **Avançado → Diagnóstico**. Recibos já publicados do planejador podem ser consultados após a troca. Verifique o estado da leitura antes de retomar um cursor.

A 0.31.0 preserva configurações, credenciais, candidatas OAuth, acervos, jobs e revisões. A alteração limita-se à permissão de diagnóstico das consultas do planejador. Não há DDL, migração de dados ou ativação automática de Ads. Após a troca, descubra `ads/keyword` e confira as cinco rotas. Com Ads desligado, `ads/keyword-ideas` deve retornar `f3_google_connector_off`.
