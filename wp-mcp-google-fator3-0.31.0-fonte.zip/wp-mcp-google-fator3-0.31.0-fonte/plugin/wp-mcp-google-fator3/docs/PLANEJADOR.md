# Planejador de palavras-chave · 0.29.0

Escolha a conta Ads da conexão e confira o nível em **Conexão → Serviços e recursos**. O contador em **Acervo Ads** considera apenas as operações observadas por esta instalação.

## Consultar

Cada ability remota usa somente métodos de leitura do Google Ads. O efeito local é arquivar a leitura e atualizar a contagem. Por padrão, ideias e métricas usam Brasil (2076), português (1014), Google Search e os últimos 12 meses disponíveis do planejador. Pode-se passar geo, language, network e year_month_range. O campo geo é uma lista de até dez recursos geoTargetConstants. Exemplos para o MCP, em parâmetros JSON:

- ads/keyword-metrics — {"keywords":["cto as a service","cto fracionado","consultoria de tecnologia"]}
- ads/keyword-ideas — {"url":"https://www.engagia.com.br/","page_size":1000}. Use keywords, url, site ou keywords com url. Use site para domínio inteiro. Aceita page_size até 10000. A chamada percorre páginas, com checkpoint por página. Enquanto complete for false, repita ads/keyword-ideas com resume_id e a mesma conta/conexão, até o fim. Um cursor repetido gera erro explícito. A aquisição de páginas e a paginação do resultado arquivado são independentes.
- ads/keyword-forecast — {"campaign":{"adGroups":[{"keywords":[{"text":"cto fracionado","matchType":"PHRASE"}]}],"biddingStrategy":{"maximizeClicksBiddingStrategy":{"dailyTargetSpendMicros":"10000000"}}}}. campaign usa CampaignToForecast REST. forecast_period é opcional. A resposta explicita moeda, impressões, cliques e custo, com null onde a versão ou estratégia omite a métrica.
- ads/keyword-themes — {"keywords":["cto fracionado"],"ad_groups":["customers/1234567890/adGroups/456"]}. Envie grupos existentes da mesma conta. A resposta conserva sugestões de grupo/campanha e os grupos inutilizáveis.
- ads/keyword-archive — {"from":"2026-10-01","to":"2026-11-30"} lista as leituras por data UTC e cliente. Paginar listas com next_before_sequence. Para abrir use {"archive_id":"<id retornado>","limit":50,"offset":0}. Siga next_offset. Para requisições acima de 8192 bytes, reconstrua meta.request_part passando meta.next_request_offset como request_offset até null e confira meta.request_sha256. A resposta contém data, requisição efetiva, série mensal, concorrência, índice, variantes e moeda. Lances e CPC são convertidos de micros. Conceitos dependem de a API fornecê-los nas ideias. Ausência é preservada e zero continua zero. Credenciais, IDs de sessão e cabeçalhos não integram o arquivo.

## Cruzar com Search Console

Execute ads/keyword-metrics e use o archive_id completo. Depois chame google/blend:

```json
{"on":["query"],"join":"left","date_range":{"from":"2026-10-01","to":"2026-10-31"},"queries":[{"prefix":"gsc","connector":"search-console","accounts":["sc-domain:example.com"],"metrics":["impressions","clicks","position"],"dimensions":["query"]},{"prefix":"ads","connector":"keyword-planner","customer_id":"1234567890","archive_id":"<id retornado>"}]}
```

Também aceita on:["keyword"]. A junção compara textos após aparar espaços e normalizar caixa, conserva acentos e recusa chaves duplicadas. Cada grupo Ads participa sob o termo canônico retornado. Um volume de variantes agrupadas nunca é distribuído por várias consultas. O intervalo do GSC e a janela histórica da pesquisa permanecem separados. Use full para incluir termos exclusivos das duas fontes.

## Operação e aceite

Descubra as quatro consultas e o leitor local com google/ability-catalog. Se a conta do projeto estiver no Explorer, o dono conclui a verificação de marca e solicita Basic. Com aprovação, comparar três palavras no painel Ads no mesmo dia, idioma, local e rede, testar a URL Engagia e consultar o histórico de alterações da conta. Acesso de produção exige a autorização aplicável.

Os instantâneos cifrados usam o repositório já instalado. Não há cron de planejamento, migração destrutiva ou novo grant para o Core. Uma leitura incompleta é identificada por complete:false. Para outra operação que falhar, iniciar uma nova consulta mantém o registro separado. Faça backup dos dados e salts antes de uma troca. Correções posteriores entram em nova versão.

Referências do fornecedor: [níveis e permissões](https://developers.google.com/google-ads/api/docs/api-policy/access-levels), [cotas](https://developers.google.com/google-ads/api/docs/best-practices/quotas), [ideias](https://developers.google.com/google-ads/api/docs/keyword-planning/generate-keyword-ideas), [histórico](https://developers.google.com/google-ads/api/docs/keyword-planning/generate-historical-metrics), [previsão](https://developers.google.com/google-ads/api/docs/keyword-planning/generate-forecast-metrics) e [temas](https://developers.google.com/google-ads/api/docs/keyword-planning/generate-ad-group-themes).

Páginas com campos estruturados inválidos, termos vazios ou métricas ilegíveis retornam `f3_google_keyword_response`. Consulte o recibo: a página inválida não entra na contagem arquivada. Para ideias, use o mesmo `resume_id` para continuar. Uma página válida sem resultados produz zero linhas.

O filtro de datas usa o início da observação em UTC, inclusive para recibos criados na 0.27.0 e retomados em outro dia. A listagem examina no máximo 200 recibos por chamada. Siga `next_before_sequence` até ser nulo, mesmo quando a página filtrada estiver vazia.

## Retomar uma pesquisa após alteração de acesso

O planejador verifica a conexão, a identidade, o canal, a política e a versão da API antes de publicar a página recebida. Se uma dessas condições mudar durante a consulta, a página em trânsito é recusada. Os lotes dessa página e seu novo cursor são gravados juntos. Uma falha conserva o último ponto confirmado.

1. Guarde o `resume_id` quando a resposta o fornecer. Abra `ads/keyword-archive` com esse identificador e confira `complete` e as linhas publicadas.
2. Confira a identidade, a conta, o nível do planejador e a política atuais. Para retomar uma pesquisa de ideias compatível, envie o mesmo `resume_id` à mesma conexão e conta.
3. Se a intenção passou para outra identidade, conta ou versão da API e o recibo for recusado, inicie uma nova leitura autorizada. O histórico confirmado continua disponível segundo a política de leitura.

## Descoberta e diagnóstico pelo MCP · Pedidos MCP Google 49

1. Use `discover-abilities` com `{"prefix":"ads/keyword","per_page":20}`. Com o canal Google aberto, administrador e perfil Manutenção, a lista contém `ads/keyword-archive`, `ads/keyword-forecast`, `ads/keyword-ideas`, `ads/keyword-metrics` e `ads/keyword-themes`. Perfil personalizado lista apenas suas operações autorizadas.
2. Leia `get-ability-info` de `ads/keyword-ideas`. O schema permite sementes alternativas (`keywords`, `url`, `site`, palavras mais URL) ou `resume_id`; não há um campo obrigatório único.
3. Execute `ads/keyword-ideas` com `{"url":"https://www.engagia.com.br/"}`. Ads desligado retorna `f3_google_connector_off` antes de rede ou arquivo. Serviço ligado sem credencial retorna `f3_google_not_configured`. A conta precisa estar selecionada/autorizada, com nível do projeto suficiente para seguir.

| Resultado | Próxima ação |
|---|---|
| `f3_google_connector_off` | Em Conexão → Serviços e recursos, revise a seleção de Ads e salve explicitamente. |
| `f3_google_not_configured` | Prepare, valide e ative a identidade em Conexão → Identidade. |
| `f3_google_keyword_access_level` | Confira o nível no projeto e registre-o em Acesso ao Google Ads. Explorer/Não informado bloqueiam o planejador; Test só permite conta de teste. |
| Recusa de permissão/catálogo | Confira versão instalada, canal, usuário administrador e perfil da conexão MCP. Não amplie permissões sem verificar a política pretendida. |

A versão 0.31.0 corrige a ocultação de `keyword-ideas` quando Ads estava desligado. A correção pertence ao callback Google e funciona com o MCP 0.41.0 original. Descoberta não consulta o fornecedor, não liga serviços e não comprova acesso a contas. As quatro consultas podem gravar seu resultado no acervo local somente após passar pelos gates; o histórico mantém sua autorização de conta. Nenhuma consulta do planejador cria anúncios ou campanhas reais.
