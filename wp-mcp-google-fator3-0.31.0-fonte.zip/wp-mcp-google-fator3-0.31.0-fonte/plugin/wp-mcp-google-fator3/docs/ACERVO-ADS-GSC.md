# ACERVO-ADS-GSC · 0.29.0

O guia GUIA-0.29.0.md descreve as telas atuais. Para instalação, atualização ou correção use MIGRACAO.md. O catálogo e os schemas instalados descrevem as interfaces vigentes.

## Referência técnica e histórico de contratos

# Referência operacional — Google 0.26.0

Base direta 0.25.1. Matriz desta rodada: Core 1.66.0, MCP 0.38.0, Meta 0.18.0 e LinkedIn 0.14.0. Pedido 48 e limites da rodada estão no guia GUIA-0.26.0.md e no relatório externo. As seções versionadas herdadas abaixo descrevem capacidades e evidências históricas; não definem a base corrente nem representam novos testes. Contratos e políticas aqui descritos permanecem, exceto a cópia de transporte 1.1.0 alinhada ao Core (ambos e invalid_output).

# Acervo Ads e leitor GSC — Google 0.24.0

## Ativação e autorização

A instalação não coleta. São independentes: autorização de coleta por conexão/conta; concessão de leitura Ads por consumidor/conta/datasets; concessão GSC de consulta/página/dia. Nenhuma delas herda autorização de conversões. Administração exige `manage_options` (ou a restrição administrativa adicional vigente). Credenciais, canal, conta, política, administrador que concedeu e revisão são revalidados. Revogar impede a próxima página e descarta a resposta se a revogação ocorrer durante HTTP. Rotação da mesma identidade preserva as concessões; mudança de identidade exige nova autorização.

`ads/archive-configure` verifica conta/moeda/fuso no Google. `ads/archive-collect` lê uma página e escreve somente o acervo local. `ads/archive-consumer-grant` altera apenas a concessão local. `ads/archive-status` é leitura local. Status e leitores Ads nunca iniciam coleta nem fazem HTTP. A leitura local pode continuar com coleta pausada enquanto a concessão do leitor, identidade e política continuarem válidas.

## Dados e limites

| Dataset | Granularidade e campos específicos | Janela de recuperação |
|---|---|---|
| clicks | GCLID, identidade do clique, campanha/grupo, palavra-chave/correspondência, rede, dispositivo | Um dia por consulta; 90 dias |
| customer | Conta/dia: cost_micros, clicks, impressions, conversions | 37 meses de métricas diárias |
| campaign | Campanha/dia e métricas | 37 meses |
| ad_group | Grupo/dia, campanha e métricas | 37 meses |
| ad | Anúncio/dia, grupo/campanha e métricas | 37 meses |
| search_terms | Termo/dia/campanha/grupo e métricas | 37 meses; omissões do fornecedor |
| changes | Instante, entidade/recurso, operação, campos, valor antigo/novo, autor/cliente | 30 dias corridos; somente 29 dias anteriores completos |

Toda linha tem account_id, date, dataset, currency e time_zone; dados ausentes do fornecedor são nulos. IDs e inteiros Ads (inclusive cost_micros) são strings decimais para evitar perda de precisão; conversions admite fração. Moeda nunca é inferida nem convertida. Não some contas com moedas distintas. Campos métricos zero omitidos pelo Proto3 são zero na linha efetivamente retornada; dia não coletado não equivale a zero.

`click_view` não publica o termo de busca por clique: `search_term:null`, motivo `not_exposed_per_click`. Palavra-chave não é termo. GCLID ausente em modalidades não suportadas permanece nulo com `gclid_unavailable:true`; não inventar correspondência ao contato. A identidade do clique precisa ser válida. Termos agregados ficam em `search_terms` e não são ligados a um GCLID.

Change events usam intervalos disjuntos. Ao atingir 10.000 resultados, o coletor divide o intervalo e recomeça o recorte. Um segundo indivisível ainda saturado publica `truncated:true`, `change_event_second_limit`. A API não representa todo o histórico da interface. Nenhuma cobertura declara universalmente todas as linhas.

## Agenda, persistência e retenção

O worker de minuto já existente processa ontem e a revisita diária antes de avançar no backfill. Revisita padrão 7 dias (1–30); backfill padrão 90 dias (1–1125), limitado adicionalmente pela janela de cada dataset. No máximo uma página por conta/passagem, até quatro contas, com orçamento cooperativo de 20 segundos. Há trava por conta, checkpoint cifrado e retomada; recortes com erro são deferidos de 5 minutos a 6 horas para não bloquear os demais. Credenciais/canal/revisão são conferidos antes e depois da rede e antes da publicação.

Dados e checkpoints usam a tabela indexada existente `f3_google_records`, kinds adsrows/adsjob/adssnapshot/adslatest/adsplan, payload cifrado com salts do site. Não há DDL nem expiração: `retention_days:0` significa permanente, o máximo do pacote. Revisitas publicam uma revisão imutável e trocam o ponteiro corrente; não somam contagens. Revisões anteriores permanecem. Uma revisita parcial não substitui visão completa anterior. O volume cresce com páginas, revisitas e revisões; planeje backup e capacidade de banco. Desinstalar continua sendo a remoção explícita do plugin/dados, não um procedimento de atualização.

## MCP — exemplos sintéticos

Primeiro obtenha `configuration_revision` por `google/integration-status` com `compact:true`. Escritas usam a revisão atual e conexão explícita; uma revisão antiga é conflito. Não execute exemplos em contas reais sem a concessão do operador.

```json
{"ability":"ads/archive-status","parameters":{"connection_id":"default"}}
{"ability":"ads/archive-configure","parameters":{"connection_id":"default","account_id":"1234567890","enabled":true,"datasets":["clicks","campaign","changes"],"backfill_days":90,"revisit_days":7,"expected_revision":"REVISAO_ATUAL"}}
{"ability":"ads/archive-collect","parameters":{"connection_id":"default","account_id":"1234567890","dataset":"clicks","date":"2026-10-27","refresh":false}}
{"ability":"ads/archive-consumer-grant","parameters":{"connection_id":"default","consumer_id":"base-site-core-fator3","account_id":"1234567890","datasets":["clicks","campaign"],"enabled":true,"expected_revision":"REVISAO_ATUAL"}}
```

A coleta devolve `state:pending` até publicar, com páginas/linhas/revisão. Continue a mesma conta/dataset/data. `refresh:true` inicia nova revisão somente quando a anterior terminou. Para interromper, desabilite a coleta; não apague checkpoints. Consulte os schemas vivos para envelopes completos de erro, estado, cobertura e revisão.

## SDK Ads local

Contrato exato `google-ads-reader/1.0.0`, hook `f3_mcp_google_register_ads_consumers` com dois argumentos `(service, contract)`. O registro é `service->register_consumer(id, version, contract, callback)`. Callback retorna `{account_ids:["1234567890"], revision:"revisao-do-consumidor", ready:true}`. Retorno é cliente com `capabilities()`, `status()`, `query(array)`. Não construa clientes manualmente: o objeto precisa ser o registrado. Não há endpoint para executor PHP arbitrário.

```php
add_action('f3_mcp_google_register_ads_consumers', function ($service, $contract) {
    if ($contract !== 'google-ads-reader/1.0.0') return;
    $client = $service->register_consumer('meu-plugin', '1.0.0', $contract,
        static fn() => ['account_ids'=>['1234567890'], 'revision'=>'cfg-1', 'ready'=>true]);
    // Guarde o cliente no serviço do seu plugin, sem fazer consultas no registro.
}, 10, 2);
// Após concessão administrativa explícita, em operação autorizada do consumidor:
$result = $client->query(['contract_version'=>'1.0.0','connection_id'=>'default',
 'account_id'=>'1234567890','dataset'=>'campaign','date'=>'2026-10-27',
 'consumer_revision'=>'cfg-1','limit'=>500]);
```

`limit` de 1 a 1000, padrão 500. `next_cursor` é opaco, cifrado e expira em 24h, vinculado a consumidor/conexão/conta/dataset/data/revisões/limite. Repetir cursor após revisita ou mudança de concessão/configuração falha: reinicie a leitura desse dia. A saída traz rows, moeda/fuso, revision, extracted_at e coverage. `coverage.archived:false` + rows vazias significa não coletado; `archived:true` + archive_rows:0 significa recorte publicado vazio. `pagination_complete` descreve a extração remota; `local_pagination_complete` descreve a paginação deste cliente. Não confundir as duas.

`coverage.archive_state` distingue `not_collected` (sem coleta iniciada), `incomplete` (checkpoint sem publicação), `published`, `partial` e `revisiting` (visão anterior ainda servida). `latest_collection_state/revision/truncated` expõem o andamento; `previous_complete_preserved:true` sinaliza revisita parcial cujo resultado não substituiu a visão completa. Assim, ausência de arquivo, coleta parcial e revisão preservada não viram zero silenciosamente. Uma linha ausente de snapshot não prova ausência universal no fornecedor.

Concessão ausente/revogada retorna `success:false`, sem linhas nem HTTP. A consulta não cria trabalho. A SDK exige que o consumidor aplique sua própria autorização administrativa e trate revisões/erros; não fornece isolamento contra PHP malicioso no mesmo WordPress.

## Search Console 1.1

Hook existente `f3_mcp_google_register_consumers`, argumento contrato exato `search-console-reader/1.1.0`; capability `gsc.query-page-day.read`. Cada contrato recebe seu serviço e cliente, sem substituir o registro 1.0. Callback `{property, revision, ready}`. Cliente `query/status/effective_status`; mesmos campos de entrada 1.0: contract_version, property, consumer_revision, date, run_id, trigger (`cli/http_cron/manual`), budget_ms (1–20000), limit (até 5000/limite do site) e cursor opcional. O calendário é America/Los_Angeles, dados finalizados, um dia por recorte. O limite efetivo está em capabilities.

```json
{"ability":"google/configure-consumer","parameters":{"contract":"search-console-reader/1.1.0","consumer_id":"base-site-core-fator3","enabled":true,"expected_revision":"REVISAO_ATUAL"}}
```

O plugin consumidor seleciona a propriedade em seu callback; a concessão fixa essa propriedade, principal, administrador e canal. Repetir concessão idêntica conserva a revisão. As concessões 1.0/1.1/GA4 são independentes.

Linhas acrescentam `query` a date/page/clicks/impressions/ctr/position. A paginação continua inclusive após página curta até uma página vazia observável; o teto documentado é 50.000 linhas/dia/tipo. A cobertura traz start_row, returned_rows, rows_accumulated, pagination_complete, truncated, truncation_reason, all_rows_guaranteed:false, anonymous_queries_excluded:true. Em 50.000 linhas, mesmo a última página vazia mantém `truncated:true/api_daily_row_limit`.

`anonymous_query_clicks` e `anonymous_query_count` são nulos, motivo `not_exposed_by_api`. A API não informa a quantidade exata oculta. A diferença entre page-day e query-page-day pode envolver anonimização, limites e agregação; não rotule todo o resíduo como anônimo. GSC 1.0 conserva suas dimensões e paginação anteriores.

## Integração Core e comprovação

O Core 1.61.1 já incorpora os leitores, enriquecimento e histórico. Use `f3base_google_ads_acervo`; `f3base_google_ads` permanece para conversões/tag. Não reaplique a proposta histórica. Consulte [CORE-ACERVOS.md](CORE-ACERVOS.md) para configuração, concessões, permissões e aceite. A prova com contas reais pertence ao operador autorizado; fixtures não encerram esse aceite.

## Referências oficiais da implementação 0.23.0

- https://developers.google.com/google-ads/api/fields/v26/click_view
- https://developers.google.com/google-ads/api/docs/change-event
- https://developers.google.com/google-ads/api/docs/query/date-ranges
- https://developers.google.com/google-ads/api/docs/reporting/zero-metrics
- https://developers.google.com/webmaster-tools/v1/how-tos/all-your-data
- https://developers.google.com/webmaster-tools/v1/how-tos/search_analytics
- https://developers.google.com/search/blog/2022/10/performance-data-deep-dive
