# Verificação da instalação · 0.31.0

Use `google/status`, `google/readiness-status` e `google/documentation` em nova requisição. Confira versão, seleção, conta e identidade antes de operar.

`tools/release031.py` executa os cenários isolado, integrado, migração direta 0.30.0 → 0.31.0 e navegador, em WordPress descartável. O conjunto é Core 1.72.1, MCP 0.41.0, LinkedIn 0.19.0, Meta 0.21.0 e Pipedrive 0.7.0. A prova da base é identificada separadamente. O relatório externo registra os resultados efetivamente executados.

O teste de Pedidos MCP Google 49 percorre o transporte MCP HTTP real: descoberta das cinco rotas, schema de ideias com sementes alternativas, execução com Ads desligado, falta de credenciais, conexão selecionada, perfil personalizado, usuário sem administração e canal fechado. Nenhum desses diagnósticos autoriza consulta ou gasto no fornecedor. As fixtures do planejador exercem ideias, métricas, previsão, temas, paginação e acesso Basic com respostas sintéticas.

O navegador verifica o painel em 1440 × 900 e 390 × 844; outros navegadores e contas Google reais ficam fora dessa prova. Para o aceite de fornecedor em ctooffice.com.br, use o token Basic autorizado e a URL https://www.engagia.com.br/, verificando ideias reais. A descoberta no Site-Teste não substitui esse aceite.
