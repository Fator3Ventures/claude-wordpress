<?php
/**
 * Server-rendered admin screens; progressive enhancement is optional.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Admin;

use Fator3\McpGoogle\{
	Admin, Options, Settings, Connections, Configuration, Setup, Plugin, Crypto, Audit
};
use Fator3\McpGoogle\Auth\{
	Candidate, Credentials, OAuthFlow, ServiceAccount
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Screen {

	private static array $failed_values = array();
	private static int $counter         = 0;
	private static $revision            = null;
	public static function render(): void {
		self::$failed_values = array();
		self::$revision      = Settings::revision();
        echo '<div class="wrap f3-google"><header class="f3-heading"><div><h1>Fator3 MCP Google</h1><p>Administre as conexões com o Google e acompanhe as operações deste site.</p></div><span class="f3-version">'.esc_html(F3_MCP_GOOGLE_VERSION).'</span></header>';
		self::notice();
		$registry = Connections::registry();
		echo '<div class="f3-context"><form method="get" action="' . esc_url( admin_url( 'tools.php' ) ) . '"><input type="hidden" name="page" value="' . esc_attr( Admin::SLUG ) . '"><input type="hidden" name="section" value="' . esc_attr( Admin::section() ) . '"><label for="f3-connection"><strong>Conexão</strong></label> <select id="f3-connection" name="connection_id">';
		foreach ( $registry as $id => $meta ) {
			echo '<option value="' . esc_attr( $id ) . '"' . selected( Connections::id(), $id, false ) . '>' . esc_html( $meta['label'] . ' (' . $id . ')' ) . '</option>';
		}
		echo '</select> ';
        foreach (Admin::panel_args(Admin::section()) as $key=>$value) { self::hidden($key,$value); }
        $site_limits = Admin::section() === 'advanced' && Admin::panel_args( 'advanced' )['advanced_panel'] === 'limits';
        echo '<button class="button">Abrir conexão</button></form><span>' . ( $site_limits ? 'Limites e auditoria abrangem todas as conexões deste site.' : 'Os formulários abaixo usam a conexão selecionada.' ) . '</span></div>';
		$provider = Credentials::current();
		$identity = DiagnosticState::identity($provider, \Fator3\McpGoogle\Auth\Candidate::state(Options::auth_mode()));
		echo '<dl class="f3-summary"><div><dt>Método selecionado</dt><dd>' . esc_html( self::method_label( Options::auth_mode() ) ) . '</dd></div><div><dt>Identidade</dt><dd>' . esc_html( $identity ) . '</dd></div><div><dt>Canal MCP Google</dt><dd>' . ( Options::is_enabled() ? 'Habilitado; confira os acessos no diagnóstico' : 'Desabilitado neste site' ) . '</dd></div></dl>';
		echo '<nav class="f3-navigation" aria-label="Configuração Google">';
		foreach ( Admin::SECTIONS as $id => $label ) {
			echo '<a href="' . esc_url( Admin::url( '', $id ) ) . '"' . ( Admin::section() === $id ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		echo '</nav><main id="f3-main">';
        $is_operations = Admin::section()==='advanced' && Admin::panel_args('advanced')['advanced_panel']==='operations';
        if (($_GET['f3_status']??'')==='operation_result' && Admin::section()!=='conversions' && !$is_operations) {
            OperationsScreen::render(true);
        }
        switch (Admin::section()) {
            case 'conversions': ConversionScreen::render(); break;
            case 'archive': ArchiveScreen::render(); break;
            case 'gsc': OperationsScreen::search_console(); ArchiveScreen::gsc(); break;
            case 'gtm': OperationsScreen::tag_manager(); break;
            case 'incidents': OperationsScreen::incidents(); break;
            case 'advanced':
                self::advanced_navigation();
                break;
            default:
                $panel = Admin::panel_args('connection')['connection_panel'];
                self::navigation('connection', 'connection_panel', Admin::CONNECTION_PANELS, $panel);
                if ($panel === 'services') { self::services(); }
                elseif ($panel === 'permissions') { OperationsScreen::permissions(); }
                else { self::connection(); }
                break;
        }

		echo '<details class="f3-details"><summary>Documentação desta versão</summary><p>Guias e contratos da versão ' . esc_html( F3_MCP_GOOGLE_VERSION ) . '. Downloads disponíveis para administradores autenticados.</p><ul>';
		foreach ( Admin::documents() as $name => $label ) {
			$url = wp_nonce_url(
				add_query_arg(
					array(
						'action'   => 'f3_mcp_google_documentation',
						'document' => $name,
					),
					admin_url( 'admin-post.php' )
				),
				'f3_mcp_google_documentation'
			);
			echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . ' · ' . esc_html( $name ) . '</a></li>';
		}
		echo '</ul></details>';
		echo '</main><p id="f3-live" class="screen-reader-text" role="status" aria-live="polite"></p></div>';
	}
    private static function navigation(string $section,string $key,array $panels,string $selected): void {
        $label = $section === 'connection' ? 'Configurações da conexão' : 'Opções avançadas';
        echo '<nav class="f3-subnav" aria-label="'.esc_attr($label).'">';
        foreach ($panels as $id=>$name) {
            $url = add_query_arg($key,$id,Admin::url('',$section));
            echo '<a href="'.esc_url($url).'"'.($id===$selected?' aria-current="page"':'').'>'.esc_html($name).'</a>';
        }
        echo '</nav>';
    }
	private static function method_label( string $mode ): string {
		return 'oauth' === $mode ? 'Conta Google · OAuth' : 'Conta de serviço';
	}
	private static function notice(): void {
        foreach ((array)\Fator3\McpGoogle\Cache::get(Admin::feedback_key('warnings')) as $warning) {
            if(is_array($warning))echo '<div class="notice notice-warning" role="status"><p>'.esc_html($warning['reason']??'').' <code>'.esc_html($warning['code']??'').'</code></p></div>';
        }
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
		$status   = isset( $_GET['f3_status'] ) && is_string( $_GET['f3_status'] ) ? sanitize_key( wp_unslash( $_GET['f3_status'] ) ) : '';
		$messages = array(
			'saved'                => 'Configuração salva.',
			'unchanged'            => 'Nenhuma alteração necessária.',
			'sa_saved'             => 'Chave validada no Google, salva e cifrada como candidata. Ative para usar.',
			'sa_cleared'           => 'Chave removida.',
			'activated'            => 'Método ativado. Confira o acesso aos recursos em Diagnóstico.',
			'created'              => 'Conexão criada. Configure a Conta de serviço para começar.',
			'tested'               => 'A verificação foi registrada. Confira o resultado abaixo.',
			'diagnostic_stale'     => 'A conexão ou a configuração do formulário mudou. Confira a conexão selecionada antes de iniciar um novo teste.',
			'diagnostic_unreadable' => 'A leitura da configuração falhou. Recarregue a página antes de iniciar o teste.',
			'diagnostic_changed'   => 'A configuração mudou durante a verificação. O resultado foi descartado. Confira os valores atuais e teste novamente.',
			'diagnostic_store_failed' => 'A verificação foi executada, mas o resultado não pôde ser registrado. Um registro já exibido pertence a uma execução anterior.',
			'discovered'           => 'Consulta de recursos concluída. Confira os resultados antes de selecionar.',
			'log_cleared'          => 'Auditoria limpa.',
			'oauth_ok'             => 'Autorização OAuth salva. Use a ação “Usar OAuth” para ativá-la quando necessário.',
			'oauth_disconnected'   => 'Autorização OAuth removida desta conexão.',
			'oauth_revoked'        => 'Autorização removida desta conexão e revogada no Google.',
			'oauth_revoke_failed'  => 'A desconexão local foi concluída; a revogação no Google falhou.',
			'oauth_denied'         => 'O consentimento não foi concedido. O método anterior foi preservado.',
			'oauth_state'          => 'Esta autorização expirou ou não corresponde à configuração atual. Inicie a conexão novamente.',
			'oauth_missing_client' => 'Salve o Identificador do aplicativo e o Segredo do aplicativo antes de conectar.',
			'oauth_no_refresh'     => 'O Google não devolveu autorização para acesso contínuo. Inicie a autorização novamente e confira o aplicativo OAuth.',
		);
        if ('recovery_observed' === $status) {
            $guard=\Fator3\McpGoogle\Recovery::status();
            echo '<div class="notice notice-info" role="status"><p>'.esc_html(!empty($guard['paused'])?'A guarda de recuperação está ativa. Confira a drenagem e a geração atuais no quadro de recuperação antes de restaurar ou retomar.':'A guarda já foi retomada. Confira seu estado atual antes de repetir a operação.').'</p></div>';
        } elseif ( 'save_failed' === $status ) {
			$data = \Fator3\McpGoogle\Cache::get( Admin::feedback_key( 'failure' ) );
			if ( is_array( $data ) ) {
				self::$failed_values = (array) ( $data['values'] ?? array() );
				echo '<div class="notice notice-error" role="alert"><p><strong>Não foi possível salvar.</strong> ' . esc_html( $data['message'] ?? '' ) . '</p><p><code>' . esc_html( $data['code'] ?? '' ) . '</code></p>';
				if ( ! empty( $data['rollback_failed'] ) ) {
					echo '<p>A restauração não foi concluída. Confira os valores persistidos em Avançado antes de repetir a operação.</p>';
				}
				echo '</div>';
			} else {
				echo '<div class="notice notice-error"><p>Não foi possível salvar. Recarregue e tente novamente.</p></div>';
			}
		} elseif ( isset( $messages[ $status ] ) ) {
			$error = in_array( $status, array( 'oauth_revoke_failed', 'oauth_denied', 'oauth_state', 'oauth_missing_client', 'oauth_no_refresh', 'diagnostic_stale', 'diagnostic_unreadable', 'diagnostic_changed', 'diagnostic_store_failed' ), true );
			echo '<div class="notice notice-' . ( 'tested' === $status ? 'info' : ( $error ? 'error' : 'success' ) ) . ' is-dismissible" role="status"><p>' . esc_html( $messages[ $status ] ) . '</p></div>';
		}
	}
	public static function form( string $action, string $extra = '' ): void {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Only literal attribute fragments from this class are passed; all dynamic attribute values are escaped.
		echo '<form class="f3-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" ' . $extra . '>';
		foreach ( array(
			'action'        => $action,
			'connection_id' => Connections::id(),
			'section'       => Admin::section(),
			'method'        => Admin::method(),
		) + Admin::panel_args(Admin::section()) as $name => $value ) {
			self::hidden( $name, $value );
		}
		$revision = self::$revision ?? Settings::revision();
		self::hidden( 'expected_revision', is_string( $revision ) ? $revision : 'unreadable' );
		self::hidden( '_wpnonce', wp_create_nonce( $action ) );
		wp_referer_field();
	}
	private static function hidden( string $name, string $value ): void {
		echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	private static function button( string $label = 'Salvar', string $name = '', string $value = '', bool $primary = true ): void {
		echo '<button type="submit" class="button' . ( $primary ? ' button-primary' : '' ) . '"' . ( '' !== $name ? ' name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' : '' ) . '>' . esc_html( $label ) . '</button>';
	}
	private static function field( string $name, string $label, string $value, string $help, string $type = 'text', string $attributes = '' ): void {
		if ( isset( self::$failed_values[ $name ] ) && is_scalar( self::$failed_values[ $name ] ) && 'password' !== $type ) {
			$value = wp_unslash( (string) self::$failed_values[ $name ] );
		}
		$id = 'f3-field-' . $name;
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Only literal attribute fragments from this class are passed; all dynamic attribute values are escaped.
		echo '<div class="f3-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><input id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( 'password' === $type ? '' : $value ) . '" aria-describedby="' . esc_attr( $id ) . '-help" ' . $attributes . '><p class="description" id="' . esc_attr( $id ) . '-help">' . esc_html( $help ) . '</p></div>';
	}
	private static function option( string $id, string $type = 'text', string $attributes = '' ): void {
		$meta = Fields::metadata()[ $id ];
		self::field( $id, $meta['label'], 'oauth_client_id' === $id ? Candidate::oauth_value( Options::OAUTH_CLIENT_ID ) : (string) Options::get( 'f3_mcp_google_' . $id, '' ), $meta['description'], $type, $attributes );
	}
	private static function secret_status( string $name ): string {
		$state = Options::stored( Options::storage_name( $name ) );
		if ( ! $state['success'] ) {
			return 'Falha de leitura';
		}
		if ( ! $state['exists'] || '' === $state['value'] ) {
			return 'Não configurado';
		}
		return null === Options::secret_problem( $name ) ? 'Salvo e cifrado' : 'Salvo, mas ilegível';
	}
	private static function copy( string $text, string $label = 'Copiar' ): void {
		$id = 'f3-copy-' . ( ++self::$counter );
		echo '<span class="f3-copy"><code id="' . esc_attr( $id ) . '">' . esc_html( $text ) . '</code><button type="button" class="button f3-copy-button" data-copy-target="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</button></span>';
	}
	private static function details( string $label, array $data ): void {
        if (Admin::section()!=='advanced') return;
		$id = 'f3-json-' . ( ++self::$counter );
		echo '<details class="f3-details"><summary>' . esc_html( $label ) . '</summary><button type="button" class="button f3-copy-button" data-copy-target="' . esc_attr( $id ) . '">Copiar JSON</button><pre id="' . esc_attr( $id ) . '">' . esc_html( wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details>';
	}
	private static function connection(): void {
		echo '<section class="f3-card"><h2>Autenticação</h2><p>Escolha uma forma de autenticação para esta conexão. Conta de serviço é a opção padrão. Configure e ative o método escolhido. Todos os serviços desta conexão utilizarão essa identidade.</p><nav class="f3-methods" aria-label="Método de autenticação">';
		foreach ( array(
			'service_account' => 'Conta de serviço · padrão',
			'oauth'           => 'Conta Google · OAuth',
		) as $mode => $label ) {
			echo '<a href="' . esc_url( Admin::url( '', 'connection', $mode ) ) . '"' . ( Admin::method() === $mode ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . ( Options::auth_mode() === $mode && ! is_wp_error( Credentials::current() ) ? ' <span class="f3-badge">Em uso</span>' : '' ) . '</a>';
		}
		echo '</nav><p class="description">Abrir uma aba permite preparar as credenciais desse método. A ativação tem uma ação própria.</p>';
		if ( ! Crypto::available() ) {
			echo '<div class="notice notice-error inline"><p>O servidor precisa de libsodium ou OpenSSL com AES-256-GCM para cifrar as credenciais. Nenhum segredo será salvo até corrigir este requisito.</p></div>';
		}
		if ( 'service_account' === Admin::method() ) {
			self::service_account();
		} else {
			self::oauth();
		}
		echo '</section>';
        if ( Admin::method() === 'service_account' ) { self::credential_summary(); }
		echo '<details class="f3-card"><summary>Nome da conexão</summary>';
		self::form('f3_mcp_google_rename_connection');
		$meta=Fields::connection_name();
		self::field('connection_label',$meta['label'],Connections::registry()[Connections::id()]['label'],$meta['description'],'text','required maxlength="100" placeholder="conta de serviço · projeto"');
		self::button('Salvar nome');echo '</form></details>';
        echo '<details class="f3-card"><summary>Adicionar conexão</summary><p>' . esc_html( Fields::metadata()['connections']['description'] ) . '</p>';
		self::form( 'f3_google_setup_create' );
		self::field( 'new_id', 'ID da conexão', '', 'Identificador estável: começa com letra minúscula e aceita letras, números, hífen e sublinhado. Até 40 caracteres.', 'text', 'required pattern="[a-z][a-z0-9_-]{0,39}" maxlength="40"' );
		self::field( 'label', $meta['label'], '', $meta['description'], 'text', 'required maxlength="100" placeholder="conta de serviço · projeto"' );
		self::button( 'Criar conexão' );
		echo '</form></details>';
	}
	private static function service_account(): void {
		echo '<ol class="f3-steps"><li>Importar chave</li><li>Conceder acesso</li><li>Selecionar recursos</li><li>Testar</li></ol>';
		echo '<p><strong>Chave:</strong> ' . esc_html( self::secret_status( Options::SA_JSON ) ) . '</p>';
		$candidate = Candidate::read( 'service_account' );
		$key       = ServiceAccount::validate_key( is_array( $candidate ) ? ( $candidate['secrets'][ Options::SA_JSON ] ?? '' ) : Options::get_secret( Options::SA_JSON ) );
		self::details(
			'Credencial candidata e credencial ativa',
			array(
				'candidate'         => Candidate::state( 'service_account' ),
				'active_configured' => Credentials::is_configured(),
				'activation'        => 'Autenticação obrigatória; outra identidade exige simulação e confirmação dos recursos vinculados.',
			)
		);
		if ( ! is_wp_error( $key ) ) {
			echo '<div class="f3-identity"><p><strong>E-mail para conceder acesso</strong></p>';
			self::copy( (string) $key['client_email'], 'Copiar e-mail' );
			echo '<p class="description">Projeto: ' . esc_html( (string) ( $key['project_id'] ?? 'não informado' ) ) . ' · Chave: …' . esc_html( substr((string) ( $key['private_key_id'] ?? '' ),-8) ) . '</p></div>';
			if ( 'service_account' !== Options::auth_mode() ) {
				echo '<p><span class="f3-badge">Salva, fora de uso</span></p>';
			}
		}
		echo '<details class="f3-details"><summary>Como criar o projeto e a chave no Google Cloud</summary><p>Crie ou reutilize uma Conta de serviço no projeto, habilite as APIs dos serviços utilizados e baixe uma chave JSON. Depois conceda acesso ao e-mail dessa conta nos recursos Google.</p><p><a href="https://console.cloud.google.com/iam-admin/serviceaccounts" target="_blank" rel="noopener noreferrer">Abrir contas de serviço no Google Cloud</a></p><p>O script de referência acompanha este plugin e deve ser executado no Google Cloud Shell. Leia as variáveis antes de executar; a execução pode criar recursos e uma chave. A versão revisada permite reutilização e separa criação de rotação. O pacote de fontes contém o histórico de referência. O download autenticado fornece o script revisado.</p>';
		self::form( 'f3_mcp_google_script', 'data-no-dirty="true"' );
		self::button( 'Baixar script de referência', '', '', false );
		echo '</form></details>';
		self::import_form( 'service_account' );
		if(is_array($candidate)&&\Fator3\McpGoogle\Auth\Configuration::identity_change($candidate))self::identity_change($candidate);
        echo '<details class="f3-details"><summary>Ajustar delegação da conta de serviço</summary>';
        self::form('f3_mcp_google_save_sa');
        if (Admin::section()==='advanced') {
		echo '<div class="f3-field"><label for="f3-sa-json">Chave JSON da conta de serviço (Service account key)</label><textarea id="f3-sa-json" name="sa_json" rows="7" spellcheck="false" autocomplete="off" aria-describedby="f3-sa-json-help"></textarea><p id="f3-sa-json-help" class="description">' . esc_html( Fields::metadata()['sa_json']['description'] ) . '</p></div>';
        }
		self::option( 'sa_subject', 'email' );
		echo '<div class="f3-actions">';
		self::button();
		self::button( 'Salvar e usar Conta de serviço', 'activate', '1', false );
		echo '</div></form></details>';
		if ( Candidate::state( 'service_account' )['ready'] ) {
			self::activation( 'service_account' );
		}
		echo '<h3>Conceder acesso aos serviços</h3><p>O e-mail da conta de serviço precisa receber acesso em cada conta, propriedade ou arquivo utilizado. As permissões do projeto Cloud não concedem esse acesso automaticamente.</p>';
		foreach ( Fields::effective_services() as $id => $level ) {
			$meta = Fields::services()[ $id ] ?? null;
			if ( ! $meta ) {
				continue;
			}
			echo '<details class="f3-details"><summary>' . esc_html( $meta['label'] ) . '</summary><p>' . esc_html( $meta['help'] ) . '</p><a href="' . esc_url( $meta['url'] ) . '" target="_blank" rel="noopener noreferrer">Abrir ' . esc_html( $meta['label'] ) . '</a></details>';
		}
		echo '<p><a class="button button-primary" href="' . esc_url( Admin::url( '', 'services' ) ) . '">Selecionar serviços e recursos</a></p>';
		self::remove_form( 'service_account' );
	}
	private static function import_form( string $mode ): void {
		self::form( 'f3_google_setup_import' );
		echo '<div class="f3-field"><label for="f3-file">' . esc_html('oauth' === $mode ? 'JSON do cliente OAuth Web' : Fields::metadata()['sa_json']['label']) . '</label><input type="file" name="credential" id="f3-file" accept="application/json,.json" required aria-describedby="f3-file-help"><p class="description" id="f3-file-help">'.esc_html('oauth'===$mode?'Arquivo de cliente Web, até 1 MiB. Importar preserva o método em uso.':Fields::metadata()['sa_json']['description']).'</p><p>'.esc_html('oauth' === $mode ? 'A importação confere o tipo Web e a URL de retorno. Depois autorize a conta Google e ative a candidata.' : 'Até 1 MiB. A chave é verificada no Google antes de ser salva. Importar prepara uma candidata; use a ativação para colocá-la em uso.').'</p></div><div class="f3-actions">';
		$first = 'service_account' === $mode && ! Credentials::is_configured();
		self::button( 'Salvar', '', '', ! $first );
		if ( 'service_account' === $mode ) {
			self::button( 'Salvar e usar Conta de serviço', 'activate', '1', $first );
		}
		echo '</div></form>';
	}
	private static function activation( string $mode ): void {
		if($mode==='service_account'){$data=Candidate::read($mode);if(is_array($data)&&\Fator3\McpGoogle\Auth\Configuration::identity_change($data))return;}
		self::form( 'f3_mcp_google_save_mode' );
		self::hidden( 'auth_mode', $mode );
		echo '<div class="f3-actions">';
		self::button( 'oauth' === $mode ? 'Usar OAuth' : 'Usar Conta de serviço' );
		echo '<span>'.esc_html('oauth' === $mode ? 'A ativação verifica a autenticação e o acesso aos recursos vinculados, incluindo o contêiner GTM. Falhas preservam a credencial ativa.' : 'A ativação verifica a autenticação. A rotação da mesma conta preserva os acessos; outra identidade exige prévia dos recursos. Falhas preservam a credencial ativa.').'</span></div></form>';
	}
	private static function credential_summary(): void {
		$s=\Fator3\McpGoogle\Auth\Validation::summary();
		$date=static fn($stamp)=>$stamp?wp_date('d/m/Y H:i:s T',(int)$stamp):'não comprovado';
		echo '<section class="f3-card f3-credential-summary"><h2>Conta de serviço salva</h2><p>Identidade: '.esc_html($s['identity']?:'não configurada').' · Projeto: '.esc_html($s['project_id']?:'não informado').' · Chave: '.esc_html($s['key_suffix']?'…'.$s['key_suffix']:'não configurada').'</p><p>Autenticação comprovada: '.esc_html($date($s['authentication_at'])).' · Último acesso comprovado: '.esc_html($date($s['resource_access_at'])).' '.esc_html(implode(', ',$s['services'])).'</p><p>Token de desenvolvedor: '.esc_html($s['developer_token_accepted_at']?'aceito em '.$date($s['developer_token_accepted_at']).' (MCC '.($s['mcc']?:'acesso direto').')':'sem comprovação para a configuração atual').'</p>';
		if($s['rotation_history']){echo '<details><summary>Histórico de rotação de chave</summary><ul>';foreach(array_reverse($s['rotation_history']) as $r)echo '<li>'.esc_html($date($r['at']).' · …'.$r['from_suffix'].' → …'.$r['to_suffix']).'</li>';echo '</ul></details>';}
		echo '</section>';
	}
	private static function identity_change(array $data): void {
		echo '<section class="f3-card"><h3>Trocar identidade</h3><p>'.esc_html(\Fator3\McpGoogle\Auth\Configuration::identity_message($data)).'</p>';
		self::form('f3_mcp_google_plan_identity');self::button('Simular troca de identidade');echo '</form>';
		$plan=\Fator3\McpGoogle\Cache::get(Admin::feedback_key('identity_plan'));
		if(is_array($plan)&&($plan['expected_revision']??null)===self::$revision){
			echo '<table class="widefat"><thead><tr><th>Serviço</th><th>Recurso</th><th>Acesso da nova conta</th></tr></thead><tbody>';
			foreach($plan['preflight']['checks']??[] as $c)echo '<tr><td>'.esc_html(Fields::services()[substr($c['name'],5)]['label']??$c['name']).'</td><td>'.esc_html($c['target']??'').'</td><td>'.esc_html($c['detail']).'</td></tr>';
			echo '</tbody></table>';
			if(empty($plan['preflight']['checks']))echo '<p>Nenhum recurso vinculado para testar. A autenticação foi comprovada; configure os recursos após a troca.</p>';
			if(!empty($plan['can_switch'])){self::form('f3_mcp_google_switch_identity');self::hidden('expected_plan_hash',$plan['plan_hash']);echo '<label><input type="checkbox" name="confirm_identity_change" value="1" required> Confirmo a troca para a conta indicada, mantendo serviços e recursos.</label>';self::button('Trocar identidade');echo '</form>';}
		}
		echo '</section>';
	}
	private static function remove_form( string $mode ): void {
		echo '<details class="f3-details f3-danger"><summary>Remover credenciais ' . esc_html( self::method_label( $mode ) ) . '</summary><p>Se este método estiver em uso, as chamadas desta conexão ficarão sem autenticação. A remoção afeta somente esta conexão.</p>';
		self::form( 'service_account' === $mode ? 'f3_mcp_google_save_sa' : 'f3_mcp_google_save_oauth' );
		self::button( 'Remover credenciais', 'service_account' === $mode ? 'clear_sa' : 'clear_oauth', '1', false );
		echo '</form></details>';
	}
	private static function oauth(): void {
        $candidate = Candidate::read( 'oauth' );
        $pending = Candidate::state( 'oauth' );
        $active = Options::has_secret( Options::OAUTH_REFRESH_TOKEN );
        $client_ready = ! is_wp_error( $candidate ) && Candidate::oauth_value( Options::OAUTH_CLIENT_ID ) !== '' && Candidate::oauth_value( Options::OAUTH_CLIENT_SECRET, true ) !== '';
        echo '<p>Prepare o aplicativo, autorize a conta e ative a conexão. Cada etapa mantém sua configuração até a confirmação da próxima.</p>';
        echo '<section class="f3-oauth-step" aria-labelledby="f3-oauth-app"><h3 id="f3-oauth-app">1. Configurar aplicativo Web</h3><div class="f3-identity"><p><strong>URL de retorno (callback OAuth)</strong></p>';
        self::copy( OAuthFlow::redirect_uri(), 'Copiar URL de retorno' );
        echo '<p class="description">Cadastre exatamente esta URL nas URIs de redirecionamento autorizadas do aplicativo Web em Google Cloud → APIs e serviços → Credenciais.</p></div>';
        self::import_form( 'oauth' );
        echo '<details class="f3-details"><summary>Informar Client ID e Client secret manualmente</summary>';
        self::form( 'f3_mcp_google_save_oauth', 'aria-label="Configurar aplicativo OAuth"' );
        self::option( 'oauth_client_id', 'text', 'autocomplete="off" required' );
        self::option( 'oauth_client_secret', 'password', 'autocomplete="new-password"' );
        self::button( 'Salvar aplicativo' );
        echo '</form></details></section>';

        echo '<section class="f3-oauth-step" aria-labelledby="f3-oauth-consent"><h3 id="f3-oauth-consent">2. Autorizar conta Google</h3><p>Escolha os serviços em <a href="' . esc_url( Admin::url( '', 'services' ) ) . '">Serviços e recursos</a> antes de autorizar. Selecione uma conta que tenha acesso aos recursos vinculados.</p>';
        if ( is_wp_error( $candidate ) ) {
            echo '<div class="notice notice-error inline"><p>A credencial candidata está ilegível. Remova as credenciais deste método e configure o aplicativo novamente.</p></div>';
        } else {
            echo '<p><strong>Aplicativo preparado:</strong> <code>' . esc_html( Candidate::oauth_value( Options::OAUTH_CLIENT_ID ) ?: 'não configurado' ) . '</code></p>';
        }
        echo '<p id="f3-oauth-start-help" class="description">' . esc_html( $client_ready ? 'O consentimento prepara uma candidata. A etapa 3 coloca essa autorização em uso.' : 'Salve o Client ID e o Client secret na etapa 1 para habilitar a autorização.' ) . '</p>';
        self::form( 'f3_mcp_google_oauth_start', 'aria-label="Autorizar conta Google" aria-describedby="f3-oauth-start-help"' );
        echo '<button type="submit" class="button button-primary"' . ( $client_ready ? '' : ' disabled' ) . '>' . esc_html( $active || $pending['ready'] ? 'Autorizar novamente com Google' : 'Conectar com Google' ) . '</button></form>';
        echo '<p class="description">Em aplicativos externos no modo Testing, autorizações com estes escopos expiram em sete dias. Confira a publicação do aplicativo para operação contínua.</p></section>';

        echo '<section class="f3-oauth-step" aria-labelledby="f3-oauth-activate"><h3 id="f3-oauth-activate">3. Conferir e ativar autorização</h3><div class="f3-oauth-states">';
        foreach ( [
            ['Autorização salva', $active ? ( Options::auth_mode() === 'oauth' ? 'Em uso nesta conexão' : 'Salva, fora de uso' ) : 'Sem autorização', $active ? (string) Options::get( Options::OAUTH_EMAIL, '' ) : ''],
            ['Autorização candidata', $pending['ready'] ? 'Pronta para ativar' : ( $pending['readable'] ? 'Aguardando consentimento' : 'Candidata ilegível' ), $pending['identity'] ?? ''],
        ] as [$label, $status, $identity] ) {
            echo '<dl><dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( $status ) . '</dd><dt>Conta Google</dt><dd>' . esc_html( $identity ?: 'E-mail ainda não disponível' ) . '</dd></dl>';
        }
        echo '</div>';
        $requested = Credentials::scopes_for( 'any' );
        $granted = is_array( $candidate ) ? (array) ( $candidate['values'][ Options::OAUTH_SCOPES ] ?? [] ) : (array) Options::get( Options::OAUTH_SCOPES, [] );
        if ( ( $pending['ready'] || ( ! $pending['present'] && $active ) ) && array_diff( $requested, $granted ) ) {
            echo '<div class="notice notice-warning inline"><p>A autorização preparada não inclui todas as permissões selecionadas. Autorize novamente na etapa 2 para incluir os serviços adicionados.</p></div>';
        }
        if ( $pending['ready'] ) { self::activation( 'oauth' ); }
        else { echo '<p class="description">Conclua o consentimento na etapa 2 para habilitar “Usar OAuth”.</p>'; }
        self::details( 'Credencial candidata OAuth', $pending );
        self::details( 'Permissões solicitadas e concedidas', [ 'requested' => $requested, 'granted' => $granted ] );
        echo '</section>';
        if ( $active || $pending['ready'] ) {
            echo '<details class="f3-details f3-danger"><summary>Desconectar ou revogar OAuth</summary><p>Desconectar remove as autorizações salva e candidata desta conexão. Os aplicativos permanecem configurados. Será necessário autorizar novamente para ativar OAuth.</p>';
            self::form( 'f3_mcp_google_oauth_disconnect', 'aria-label="Desconectar OAuth"' );
            self::button( 'Desconectar esta conexão', '', '', false ); echo '</form>';
            if ( $active ) {
                echo '<p>A revogação usa a autorização salva e também remove o acesso no Google. Pode afetar outros sites e aplicativos do mesmo usuário e projeto. Uma candidata de outro projeto é removida apenas localmente.</p>';
                self::form( 'f3_google_operation' ); self::hidden( 'operation', 'prepare-revoke' ); self::hidden( 'section', 'operations' );
                self::button( 'Revisar revogação no Google', '', '', false ); echo '</form>';
            }
            echo '</details>';
        }
        self::remove_form( 'oauth' );
    }
	public static function services(): void {
		$services = Fields::effective_services();
		if ( isset( self::$failed_values['services'] ) && is_array( self::$failed_values['services'] ) ) {
			$services = self::$failed_values['services'];
		}
		$bindings = (array) Options::get( Connections::BINDINGS, array() );
		$default_property   = (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' );
		if ( ! array_key_exists( 'ga_property_id', $bindings ) ) {
			$bindings['ga_property_id'] = $default_property;
		}
		if ( preg_replace( '~^properties/~', '', (string) $bindings['ga_property_id'] ) !== $default_property ) {
			echo '<div class="notice notice-warning inline"><p>Há duas propriedades GA4 salvas. Propriedade padrão usada por operações GA: <code>' . esc_html( $default_property ) . '</code>; vínculo usado pelo fluxo de configuração: <code>' . esc_html( $bindings['ga_property_id'] ) . '</code>. Confira o campo abaixo. Ao salvar, ele será utilizado nas duas representações.</p></div>';
		}
		echo '<section class="f3-card"><h2>Serviços e recursos</h2><p>' . esc_html( Fields::metadata()['services']['description'] ) . '</p>';
		self::form( 'f3_google_setup_save' );
		self::hidden( 'services_present', '1' );
		foreach ( Fields::services() as $service => $meta ) {
			$level = $services[ $service ] ?? '';
			echo '<fieldset class="f3-service"><legend>' . esc_html( $meta['label'] ) . '</legend><div class="f3-service-choice"><label for="f3-service-' . esc_attr( $service ) . '">Nível de operação</label><select name="services[' . esc_attr( $service ) . ']" id="f3-service-' . esc_attr( $service ) . '" data-service-select="' . esc_attr( $service ) . '">';
			foreach ( array_merge( array( '' ), Setup::LEVELS[ $service ] ) as $value ) {
				echo '<option value="' . esc_attr( $value ) . '"' . selected( $level, $value, false ) . '>' . esc_html(
					array(
						''      => 'Desativado',
						'read'  => 'Leitura',
						'write' => 'Leitura e escrita',
						'admin' => 'Administração, incluindo usuários',
					)[ $value ]
				) . '</option>';
			}
			echo '</select></div><p class="description">' . esc_html( $meta['help'] ) . '</p><div data-service-fields="' . esc_attr( $service ) . '"' . ( '' === $level ? ' hidden' : '' ) . '>';
			foreach ( Fields::resources() as $field => $info ) {
				if ( $info['service'] !== $service ) {
					continue;
				}
                $data=ResourceChoices::items($service);
                if (!$data) $data=Resources::cached($service)['items']??[];
                if ($field==='sitemap_url'||$field==='spreadsheet_id') self::field($field,$info['label'],(string)($bindings[$field]??''),$info['description']);
                else ResourceChoices::select($field,$info['label'],(string)($bindings[$field]??''),$data,$info['description']);

				$suggestion = 'sitemap_url' === $field ? Resources::sitemap_suggestion() : '';
				if ( '' !== $suggestion ) {
					echo '<p class="description">Sugestão do site (confira a publicação): ';
					self::copy( $suggestion );
					echo '</p>';
				}
			}
			echo '</div></fieldset>';
		}
		echo '<p><label><input type="checkbox" name="validate_access" value="1"> Testar acesso aos recursos antes de salvar</label></p><p class="description">Deixe desmarcado para preparar a configuração antes de conceder acesso ou autorizar OAuth. Salvar uma seleção não comprova acesso ao Google.</p>';
		self::button('Salvar serviços e recursos');
        echo '<button class="button" name="preview_configuration" value="1" type="submit">Revisar alterações</button><p class="description">Desativações e reduções exigem uma etapa de confirmação antes de salvar.</p>';
		echo '</form></section>';
		if ( isset( $services['ads'] ) ) {
			echo '<section class="f3-card" aria-labelledby="f3-ads-access-title"><h2 id="f3-ads-access-title">Acesso ao Google Ads</h2><p>Configure o projeto e o token usados pela conexão selecionada. A permissão da conta Google e a seleção de serviços também precisam autorizar a consulta.</p><p><strong>Token de desenvolvedor:</strong> ' . esc_html( self::secret_status( Options::ADS_DEVELOPER_TOKEN ) ) . '</p>';
			self::form( 'f3_mcp_google_save_ads' );
			echo '<div class="f3-field"><label for="f3-ads-level">Nível de acesso do projeto no Google Cloud</label><select id="f3-ads-level" aria-describedby="f3-ads-level-help" name="ads_access_level">';
            $level = \Fator3\McpGoogle\Ads\PlannerAccess::level();
            foreach (\Fator3\McpGoogle\Ads\PlannerAccess::LEVELS as $choice) {
                echo '<option value="'.esc_attr($choice).'" '.selected($level,$choice,false).'>'.esc_html($choice==='unknown'?'Não informado':ucfirst($choice)).'</option>';
            }
            echo '</select><p id="f3-ads-level-help" class="description">Use o nível exibido na página Google Ads API do projeto. Basic ou Standard permitem o Planejador; Test exige conta de teste. Explorer e Não informado bloqueiam as consultas. Este campo registra sua declaração; salvar não comprova acesso no Google.</p></div>';
            self::option( 'ads_developer_token', 'password', 'autocomplete="new-password"' );
			self::option( 'ads_login_customer_id', 'text', 'placeholder="123-456-7890"' );
			echo '<details class="f3-details"><summary>Versão da API e remoção do token</summary>';
			self::field( 'ads_api_version', Fields::metadata()['ads_api_version']['label'], Options::ads_api_version(), Fields::metadata()['ads_api_version']['description'], 'text', 'pattern="v[0-9]{1,3}"' );
			echo '<label><input type="checkbox" name="clear_developer_token" value="1"> Remover o token de desenvolvedor desta conexão</label></details>';
			self::button('Salvar acesso ao Google Ads');
			echo '</form><aside aria-labelledby="f3-planner-access-title"><h3 id="f3-planner-access-title">Conferir o Planejador pelo MCP</h3><p>Com o canal aberto e um perfil autorizado, a descoberta de <code>ads/keyword</code> deve listar cinco operações. Elas continuam descobríveis com Ads desligado; ao consultar, o diagnóstico informa o que falta configurar.</p><p>A presença no catálogo não comprova credencial, acesso à conta ou nível Basic/Standard. Consulte o manual PLANEJADOR.md na Ajuda para verificar cada etapa.</p></aside></section>';
		}
		self::discovery();
		echo '<p><a class="button" href="' . esc_url( Admin::url( '', 'diagnostics' ) ) . '">Verificar acessos em Diagnóstico</a></p>';
	}
	private static function discovery(): void {
		echo '<section class="f3-card"><h2>Consultar recursos acessíveis</h2><p>Salve a seleção de serviços antes de consultar. Os resultados alimentam as sugestões dos campos acima. Nenhum recurso será selecionado automaticamente.</p>';
		foreach ( array( 'ga', 'ads', 'gsc', 'sheets' ) as $service ) {
			if ( ! isset( Fields::effective_services()[ $service ] ) ) {
				continue;
			}
			$data = Resources::cached( $service );
			echo '<div class="f3-discovery"><h3>' . esc_html( Fields::services()[ $service ]['label'] ) . '</h3>';
			self::form( 'f3_mcp_google_discover' );
			self::hidden( 'service', $service );
			self::button( 'Consultar recursos', '', '', false );
			echo '</form>';
			if ( is_array( $data ) ) {
				echo '<p>' . ( empty( $data['success'] ) ? 'Consulta falhou.' : ( empty( $data['items'] ) ? 'Nenhum recurso encontrado nesta consulta.' : count( $data['items'] ) . ' recurso(s) disponível(is) nas sugestões.' ) ) . ( empty( $data['complete'] ) ? ' A listagem não está completa.' : '' ) . '</p>';
				foreach ( $data['warnings'] ?? array() as $warning ) {
					echo '<p>' . esc_html( $warning ) . '</p>';
				}
				if ( ! empty( $data['message'] ) ) {
					echo '<p>' . esc_html( $data['message'] ) . '</p>';
				}
				if ( ! empty( $data['next_page_token'] ) ) {
					self::form( 'f3_mcp_google_discover' );
					self::hidden( 'service', $service );
					self::hidden( 'page_token', $data['next_page_token'] );
					self::button( 'Consultar próxima página', '', '', false );
					echo '</form>';
				}
				self::details( 'Ver recursos e detalhes da consulta', $data );
			}
			echo '</div>';
		}
		echo '<p class="description">A descoberta de planilhas depende das permissões do Drive incluídas na conexão. Se a planilha não aparecer, informe o ID ou a URL conhecida e teste o acesso ao arquivo.</p></section>';
	}
	private static function diagnostics(): void {
		echo '<section class="f3-card"><h2>Verificar a conexão</h2><p id="f3-diagnostic-help">O teste verifica o servidor e tenta ler os serviços habilitados com a identidade ativa desta conexão. A leitura de um recurso confirma o acesso a ele naquele momento. Permissões de escrita e administração exigem verificações próprias.</p>';
		self::form( 'f3_mcp_google_test', 'aria-label="Teste de acessos da conexão" aria-describedby="f3-diagnostic-help" data-no-dirty="true"' );
		self::button( 'Testar acessos agora' );
		echo '</form><nav class="f3-diagnostic-links" aria-label="Preparar o teste"><a href="' . esc_url( add_query_arg( 'connection_panel', 'identity', Admin::url( '', 'connection' ) ) ) . '">Conferir identidade</a><a href="' . esc_url( Admin::url( '', 'services' ) ) . '">Conferir serviços e recursos</a></nav></section>';
		echo '<section class="f3-card f3-diagnostic-result" aria-labelledby="f3-diagnostic-result-title"><h2 id="f3-diagnostic-result-title">Resultado da última verificação</h2><p class="description">O resultado fica disponível por até uma hora para o administrador que executou o teste. Abrir esta página apenas consulta esse registro.</p>';
		$result = \Fator3\McpGoogle\Cache::get( Admin::diagnostic_key() );
		if ( false === $result ) {
			echo '<p class="f3-empty">Nenhum resultado disponível para esta conexão. Use “Testar acessos agora” para obter uma leitura atual.</p>';
		} elseif ( ! is_array( $result ) || ! DiagnosticState::valid( $result ) ) {
			echo '<p class="f3-empty">Diagnóstico armazenado inválido ou de formato anterior. Execute uma nova verificação.</p>';
		} elseif ( ( $result['connection_id'] ?? '' ) !== Connections::id() || ! in_array( $result['auth_mode'] ?? '', Options::AUTH_MODES, true ) ) {
			echo '<p class="f3-empty">Resultado desatualizado. O registro não identifica esta conexão e seu método. Execute uma nova verificação.</p>';
		} else {
			$stale = self::$revision !== $result['revision'] || $result['auth_mode'] !== Options::auth_mode();
			if ( $stale ) {
				echo '<p class="f3-empty"><strong>Resultado desatualizado.</strong> Execute uma nova verificação para confirmar os acessos da configuração atual.</p>';
			}
			echo '<dl class="f3-diagnostic-meta"><div><dt>Conexão testada</dt><dd>' . esc_html( $result['connection_id'] ) . '</dd></div><div><dt>Método usado</dt><dd>' . esc_html( self::method_label( $result['auth_mode'] ) ) . '</dd></div><div><dt>Verificado em</dt><dd>' . esc_html( DiagnosticState::instant( $result['checked_at'] ) ) . '</dd></div></dl>';
			$verdict = $result['result_status'];
			$verdict_labels = array( 'passed' => 'Concluído', 'incomplete' => 'Incompleto', 'failed' => 'Reprovado', 'execution_error' => 'Não concluído' );
			$verdict_style = array( 'passed' => 'passed', 'incomplete' => 'not_configured', 'failed' => 'failed', 'execution_error' => 'failed' );
			echo '<p><span class="f3-state f3-state-' . esc_attr( $stale ? 'skipped' : $verdict_style[ $verdict ] ) . '">' . esc_html( $verdict_labels[ $verdict ] ) . ( $stale ? ' (anterior)' : '' ) . '</span></p><p>' . esc_html( \Fator3\McpGoogle\SelfTest::message( $result ) ) . '</p>';
			$services = array();
			$local = array();
			foreach ( $result['checks'] ?? array() as $check ) {
				if ( str_starts_with( $check['name'], 'live_' ) ) {
					$services[] = $check;
				} else {
					$local[] = $check;
				}
			}
			if ( $services ) {
				echo '<h3>Acesso aos serviços Google</h3>';
				self::diagnostic_checks( $services, $stale );
			}
			if ( $local ) {
				echo '<details class="f3-details"><summary>Verificações locais do plugin</summary>';
				self::diagnostic_checks( $local, $stale );
				echo '</details>';
			}
			self::details( 'Detalhes técnicos da verificação', $result );
		}
		echo '</section><section class="f3-card"><h2>Capacidades do servidor</h2><dl class="f3-definition"><dt>Abilities API</dt><dd>' . ( Plugin::abilities_api_available() ? 'Disponível' : 'Ausente. Instale o provedor da Abilities API compatível com este WordPress.' ) . '</dd><dt>Servidor MCP</dt><dd>' . esc_html( \Fator3\McpGoogle\McpServer::message( Plugin::mcp_status() ) ) . '</dd><dt>Criptografia dos segredos</dt><dd>' . esc_html( Crypto::backend() ) . '</dd>';
		if ( 'service_account' === Options::auth_mode() ) {
			echo '<dt>Assinatura da Conta de serviço</dt><dd>' . ( function_exists( 'openssl_sign' ) ? 'OpenSSL disponível' : 'OpenSSL ausente. Habilite a extensão para utilizar Conta de serviço.' ) . '</dd>';
		}
		echo '</dl>';
		self::details( 'Ver estado local do servidor MCP', Plugin::mcp_status() );
		echo '</section>';
	}
	private static function diagnostic_checks( array $checks, bool $stale ): void {
		$labels = array( 'passed' => 'Aprovado', 'failed' => 'Falhou', 'skipped' => 'Ignorado', 'not_configured' => 'Não configurado' );
		echo '<div class="f3-table-wrap"><table class="widefat striped f3-diagnostic-table"><thead><tr><th scope="col">Verificação</th><th scope="col">Resultado</th><th scope="col">Detalhe e próxima ação</th></tr></thead><tbody>';
		foreach ( $checks as $check ) {
			$status = $check['status'];
			$service = preg_replace( '/^live_/', '', $check['name'] );
			$label = Fields::services()[ $service ]['label'] ?? $check['name'];
			echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td><span class="f3-state f3-state-' . esc_attr( $stale ? 'skipped' : $status ) . '">' . esc_html( $labels[ $status ] ) . ( $stale ? ' (anterior)' : '' ) . '</span></td><td>' . esc_html( $check['detail'] ?? '' );
			if ( ! empty( $check['target'] ) ) {
				echo '<br><code>' . esc_html( $check['target'] ) . '</code>';
			}
			if ( ! $stale && in_array( $status, array( 'failed', 'not_configured' ), true ) ) {
				echo '<p class="description">' . esc_html( self::next_action( $check ) ) . '</p>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
	}
	private static function next_action( array $check ): string {
		$code = $check['error_code'] ?? '';
		if ( str_contains( $code, 'crypto' ) ) {
			return 'Confira a cifra do servidor e as chaves de segurança do WordPress antes de reimportar a credencial.';
		}
		if ( str_contains( $code, 'quota' ) || str_contains( $code, 'rate' ) ) {
			return 'Confira a cota e o intervalo de nova tentativa nos detalhes técnicos.';
		}
		if ( str_contains( $code, 'auth' ) || str_contains( $code, 'token' ) ) {
			return 'Confira a identidade ativa em Conexão e repita o teste.';
		}
		if ( in_array( $check['name'], array( 'config', 'live_ads' ), true ) && 'not_configured' === $check['status'] && str_contains( strtolower( $check['detail'] ?? '' ), 'token' ) ) {
			return 'Confira a configuração de acesso à API Google Ads em Serviços e recursos.';
		}
		if ( str_starts_with( $check['name'], 'live_' ) ) {
			return 'Confira o recurso selecionado, a API habilitada e a permissão da identidade em Serviços e recursos.';
		}
		return 'Consulte o detalhe da verificação e confira as capacidades do servidor antes de testar novamente.';
	}
    private static function advanced_navigation(): void {
        $panel = Admin::panel_args('advanced')['advanced_panel'];
        self::navigation('advanced','advanced_panel',Admin::ADVANCED_PANELS,$panel);
        switch($panel) {
            case 'diagnostics':self::diagnostics();break;
            case 'operations':OperationsScreen::render();break;
            case 'templates':OperationsScreen::controls();break;
            case 'credentials':self::service_account();break;
            case 'contract':

                $field=sanitize_key(wp_unslash($_GET['configuration_field']??''));
                echo '<p>Consulte uma opção por vez. O catálogo completo está no documento de configuração disponível para download.</p><form method="get"><input type="hidden" name="page" value="'.esc_attr(Admin::SLUG).'"><input type="hidden" name="section" value="advanced"><input type="hidden" name="advanced_panel" value="contract"><input type="hidden" name="connection_id" value="'.esc_attr(Connections::id()).'"><label>Opção <select name="configuration_field"><option value="">Selecionar</option>';
                $definitions=Configuration::definitions();
                foreach($definitions as $key=>$definition) echo '<option value="'.esc_attr($key).'" '.selected($field,$key,false).'>'.esc_html($definition['label']??$key).'</option>';
                echo '</select></label> <button class="button">Consultar</button></form>';
                if(isset($definitions[$field])) self::details('Definição selecionada',$definitions[$field]);
                break;
            default:self::advanced();
        }
    }
	private static function advanced(): void {
		echo '<section class="f3-card"><h2>Controle do site</h2><p>' . esc_html( Fields::metadata()['enabled']['description'] ) . '</p>';
		if ( Admin::forced_by_filter() ) {
			echo '<p>Esta opção também é controlada pelo filtro <code>f3_mcp_google_enabled</code>. O valor efetivo pode diferir do valor salvo.</p>';
		}
		self::form( 'f3_mcp_google_toggle' );
		self::hidden( 'enable', Options::is_enabled() ? '0' : '1' );
		self::button( Options::is_enabled() ? 'Bloquear chamadas Google' : 'Permitir chamadas Google' );
		echo '</form></section><section class="f3-card"><h2>Limites do site</h2><p>Aplicados a todas as conexões deste WordPress.</p>';
		self::form( 'f3_mcp_google_save_limits' );
		foreach ( Options::LIMITS as $name => $rule ) {
			$id   = substr( $name, strlen( 'f3_mcp_google_' ) );
			$meta = Fields::metadata()[ $id ];
			self::field( $id, $meta['label'], (string) Options::limit( $name ), $meta['description'] . ' Padrão: ' . $rule['default'] . '. Intervalo: ' . $rule['minimum'] . '–' . $rule['maximum'] . '.', 'number', 'min="' . $rule['minimum'] . '" max="' . $rule['maximum'] . '" step="1" required' );
		}
		self::button();
		echo '</form></section><section class="f3-card"><h2>Auditoria</h2><p>Últimas 30 operações de todas as conexões, no fuso do WordPress.</p>';
		$log = Audit::recent( 30 );
		if ( ! $log ) {
			echo '<p>Nenhuma operação registrada.</p>';
		} else {
			echo '<div class="f3-table-wrap"><table class="widefat striped"><thead><tr><th>Quando</th><th>Ação</th><th>Alvo</th></tr></thead><tbody>';
			foreach ( $log as $row ) {
				echo '<tr><td>' . esc_html( DiagnosticState::instant((string)($row['time'] ?? '')) ) . '</td><td>' . esc_html( $row['action'] ?? '' ) . '</td><td>' . esc_html( $row['target'] ?? '' ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '<details class="f3-details f3-danger"><summary>Limpar auditoria</summary><p>Remove o histórico de operações de todas as conexões deste site.</p>';
		self::form( 'f3_mcp_google_clear_log' );
		self::button( 'Limpar auditoria', '', '', false );
		echo '</form></details></section><section class="f3-card"><h2>Informações técnicas</h2><p>WordPress: ' . esc_html( get_bloginfo( 'version' ) ) . ' · Plugin: ' . esc_html( F3_MCP_GOOGLE_VERSION ) . '</p>';
		// Direct definitions remain available in wp-admin while the MCP channel is closed.
		echo '<p>Consulte as opções individualmente na aba Contrato de configuração.</p>';
		echo '<p>Agendamentos utilizam WP-Cron. Para execução independente de visitas, configure o cron do servidor para acionar wp-cron.php. Acompanhe os resultados em google/list-jobs.</p></section>';
	}
}
