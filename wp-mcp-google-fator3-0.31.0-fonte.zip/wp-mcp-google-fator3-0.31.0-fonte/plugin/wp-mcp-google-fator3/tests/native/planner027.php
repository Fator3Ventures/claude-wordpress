<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,Ads\PlannerAccess as Access,Ads\PlannerRequest as Request,Ads\KeywordPlanner as Planner,Storage\Repository};
wp_get_abilities();
$cid='1234567890';$site='sc-domain:example.com';
$setup=O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'12345-application.apps.googleusercontent.com',
    Settings::AUTH_READY=>true,C::BINDINGS=>['ads_customer_id'=>$cid,'gsc_site_url'=>$site],C::SERVICES=>['ads'=>'read','gsc'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]]],
    [O::OAUTH_CLIENT_SECRET=>'synthetic-client',O::OAUTH_REFRESH_TOKEN=>'synthetic-refresh']);
verifyLab('Seed synthetic credential and explicit Ads/GSC bindings',$setup['success']);
function kwcall($name,$args=[]) {
    $result=wp_get_ability($name)->execute($args);
    return is_wp_error($result)?['success'=>false,'error_code'=>$result->get_error_code(),'message'=>$result->get_error_message()]:$result;
}
function level027($level) { $r=Settings::save([Access::OPTION=>['level'=>$level,'scope'=>Access::scope()]],[],[],Settings::revision()); verifyLab('Administrative save '.$level,$r['success'],$r); }
$requests=[];$loop=false;$failpage=false;$testAccount=false;$explorer=false;
$fixture=function($pre,$args,$url)use(&$requests,&$loop,&$failpage,&$testAccount,&$explorer,$cid) {
    $body=is_array($args['body']??null)?$args['body']:json_decode($args['body']??'{}',true);$method=substr($url,strrpos($url,':')+1);$code=200;
    if (str_contains($url,'/token')) { $data=['access_token'=>'synthetic-access','expires_in'=>3600,'scope'=>'https://www.googleapis.com/auth/adwords https://www.googleapis.com/auth/webmasters.readonly']; }
    elseif (str_contains($url,'/googleAds:search')) { $data=['fieldMask'=>'customer.currencyCode,customer.testAccount','results'=>[['customer'=>['currencyCode'=>'BRL','testAccount'=>$testAccount]]]]; }
    elseif (str_contains($url,'discovery') && str_contains($url,'searchconsole')) { $data=json_decode(file_get_contents(__DIR__.'/../fixtures/discovery/searchconsole-v1.json'),true); }
    elseif (str_contains(strtolower($url),'/searchanalytics/query')) { $data=['rows'=>[['keys'=>[' Consultoria CTO '],'clicks'=>2,'impressions'=>12,'position'=>3.5],['keys'=>['sem par'],'clicks'=>1,'impressions'=>2,'position'=>9]]]; }
    elseif (in_array($method,Request::METHODS,true)) {
        $metric=['avgMonthlySearches'=>'100','monthlySearchVolumes'=>[['year'=>2026,'month'=>'OCTOBER','monthlySearches'=>'110']],'competition'=>'MEDIUM','competitionIndex'=>'0','lowTopOfPageBidMicros'=>'0','highTopOfPageBidMicros'=>'3750000','averageCpcMicros'=>'1250000'];
        $data=match($method) {
            'generateKeywordIdeas'=>['results'=>[['text'=>'idea'.($body['pageToken']??'first'),'keywordIdeaMetrics'=>$metric,'keywordAnnotations'=>['concepts'=>[['name'=>'Software']]]]]],
            'generateKeywordHistoricalMetrics'=>['results'=>[['text'=>'consultoria cto','closeVariants'=>['consultorias cto'],'keywordMetrics'=>$metric],['text'=>'vazio','keywordMetrics'=>[]]]],
            'generateKeywordForecastMetrics'=>['campaignForecastMetrics'=>['clicks'=>4,'costMicros'=>'4400000']],
            'generateAdGroupThemes'=>['adGroupKeywordSuggestions'=>[['keywordText'=>'cto','suggestedAdGroup'=>'customers/'.$cid.'/adGroups/456']],'unusableAdGroups'=>[['adGroup'=>'customers/'.$cid.'/adGroups/789']]],
        };
        if ($method==='generateKeywordIdeas') {
            if (!isset($body['pageToken']) || $loop) { $data['nextPageToken']='next'; }
            if ($failpage && isset($body['pageToken'])) { $code=400;$data=['error'=>['status'=>'INVALID_ARGUMENT','message'=>'synthetic failure']]; }
        }
        if ($explorer) { $code=403;$data=['error'=>['status'=>'PERMISSION_DENIED','details'=>[['errors'=>[['errorCode'=>['authorizationError'=>'DEVELOPER_TOKEN_NOT_APPROVED'],'message'=>'Explorer access not allowed']]]]]]; }
    } else { return $pre; }
    $requests[]=['method'=>$method,'url'=>$url,'body'=>$body,'http'=>$code];
    return ['headers'=>[],'response'=>['code'=>$code],'body'=>wp_json_encode($data)];
};
add_filter('pre_http_request',$fixture,1,3);
foreach (array_keys(Request::METHODS) as $kind) {
 $a=wp_get_ability('ads/keyword-'.$kind);verifyLab('Read metadata '.$kind,$a && $a->get_meta()['fator3']['mode']==='read' && $a->get_meta()['fator3']['local_effect']==='write');
}
$cat=kwcall('google/ability-catalog',['prefix'=>'ads/keyword-','mode'=>'read']);
verifyLab('Five planner readers in catalog',!empty($cat['success'])&&in_array('ads/keyword-forecast',array_column($cat['abilities']??[],'name'),true),$cat['message']??null);
foreach (['unknown','explorer','test','basic','standard'] as $level) {
 level027($level);
 foreach(['google/status','google/readiness-status'] as $name) {
   $status=kwcall($name,$name==='google/status'?['compact'=>true]:[]);
   verifyLab($name.' local level '.$level,($status['ads_planning_access']['level']??null)===$level,$status['message']??null);
 }
 if($level==='explorer') {
  foreach(['ideas'=>['site'=>'https://www.engagia.com.br/'],'metrics'=>['keywords'=>['cto']],'forecast'=>['campaign'=>['adGroups'=>[[]],'biddingStrategy'=>['x'=>1]]],'themes'=>['keywords'=>['cto'],'ad_groups'=>['customers/'.$cid.'/adGroups/456']]] as $kind=>$args) {
   $r=kwcall('ads/keyword-'.$kind,$args);
   verifyLab('Explorer blocks before dispatch '.$kind,($r['error_code']??'')==='f3_google_keyword_access_level' && ($r['access']['level']??'')==='explorer' && $requests===[],$r);
  }
 }
}
level027('basic');
$_GET['connection_panel']='services'; ob_start(); \Fator3\McpGoogle\Admin\Screen::render(); $admin_html=ob_get_clean(); unset($_GET['connection_panel']);
verifyLab('Admin form exposes current Ads access level and nonce',str_contains($admin_html,'name="ads_access_level"') && preg_match('~value="basic"\s+selected~',$admin_html) && str_contains($admin_html,'_wpnonce'));
foreach([['keywords'=>['cto']],['url'=>'https://www.engagia.com.br/'],['site'=>'https://www.engagia.com.br/'],['keywords'=>['cto'],'url'=>'https://www.engagia.com.br/']] as $k=>$seed){
 $r=kwcall('ads/keyword-ideas',$seed+['page_size'=>10000]);verifyLab('Ideas seed '.$k.' includes both pages, concept and currency',!empty($r['complete']) && $r['row_count']===2 && $r['rows'][0]['concepts'][0]['name']==='Software' && $r['rows'][0]['currency']==='BRL',$r);
}
$r=kwcall('ads/keyword-ideas',['site'=>'https://example.com','url'=>'https://example.com']);verifyLab('Ambiguous seeds refused',empty($r['success']),$r);
$failpage=true;$r=kwcall('ads/keyword-ideas',['keywords'=>['x']]);$resume=$r['resume_id']??'';
verifyLab('Second-page failure returns saved cursor',empty($r['success'])&&strlen($resume)===32,$r);$failpage=false;
$r=kwcall('ads/keyword-archive',['archive_id'=>$resume]);verifyLab('Retained incomplete first page',$r['complete']===false&&$r['row_count']===1,$r);
$r=kwcall('ads/keyword-ideas',['resume_id'=>$resume]);verifyLab('Resume completes without a duplicate',$r['complete']&&$r['row_count']===2,$r);
$loop=true;$r=kwcall('ads/keyword-ideas',['keywords'=>['loop']]);$loop=false;verifyLab('Cycle stops and exposes receipt',($r['error_code']??'')==='f3_google_keyword_pagination' && isset($r['resume_id']),$r);
$r=kwcall('ads/keyword-metrics',['keywords'=>['consultoria cto','consultorias cto','vazio']]);
verifyLab('Metric averages variant group zero and null explicitly',$r['success'] && $r['rows'][0]['low_top_of_page_bid']==0 &&
  $r['rows'][0]['high_top_of_page_bid']==3.75 && $r['rows'][0]['average_cpc']==1.25 && $r['rows'][0]['competition_index']===0 &&
  $r['rows'][1]['avg_monthly_searches']===null && $r['rows'][0]['close_variants']===['consultorias cto'],$r);
$id=$r['archive_id']; verifyLab('Resolved geo, language and network defaults',$r['meta']['request']['language']==='languageConstants/1014'&&$r['meta']['request']['geoTargetConstants']===['geoTargetConstants/2076']&&$r['meta']['request']['keywordPlanNetwork']==='GOOGLE_SEARCH');
$n=count($requests);
$page=kwcall('ads/keyword-archive',['archive_id'=>$id,'offset'=>1,'limit'=>1]);verifyLab('Local page without HTTP',$page['rows'][0]['keyword']==='vazio'&&count($requests)===$n);
$list=kwcall('ads/keyword-archive',['from'=>gmdate('Y-m-d'),'limit'=>2]);verifyLab('Monthly history paginates',count($list['reads']??[])===2&&$list['next_before_sequence']>0,$list);
$second=kwcall('ads/keyword-archive',['before_sequence'=>$list['next_before_sequence'],'limit'=>2]);verifyLab('Next page is disjoint',!array_intersect(array_column($list['reads'],'archive_id'),array_column($second['reads'],'archive_id')));
$raw=Repository::get('keywordread',$cid.'-'.$id);verifyLab('Private seeds encrypted at rest',isset($raw['ciphertext'])&&!str_contains(wp_json_encode($raw),'consultoria'));
$r=kwcall('ads/keyword-metrics',['keywords'=>array_fill(0,10001,'x')]);verifyLab('Reject 10001 terms',empty($r['success'])&&count($requests)===$n,$r['message']??null);
$r=kwcall('ads/keyword-metrics',['keywords'=>array_map(fn($i)=>'x'.$i,range(1,10000))]);verifyLab('Accept 10000 input terms',$r['success']&&($r['meta']['request_bytes']??0)>64000 && ($r['meta']['next_request_offset']??0)>0,$r['message']??null);
$r=kwcall('ads/keyword-forecast',['campaign'=>['adGroups'=>[['keywords'=>[['text'=>'cto','matchType'=>'EXACT']]]],'biddingStrategy'=>['maximizeClicksBiddingStrategy'=>['dailyTargetSpendMicros'=>'10000000']]]]);
verifyLab('Forecast numeric cost and unavailable impressions',!empty($r['success'])&&$r['rows'][0]['cost']==4.4&&$r['rows'][0]['impressions']===null,$r);
$r=kwcall('ads/keyword-themes',['keywords'=>['cto'],'ad_groups'=>['customers/'.$cid.'/adGroups/456']]);
verifyLab('Themes both usable and unusable',$r['success']&&count($r['meta']['unusable_ad_groups'])===1,$r);
$r=kwcall('ads/keyword-themes',['keywords'=>['cto'],'ad_groups'=>['customers/1111111111/adGroups/456']]);verifyLab('Cross-account ad groups refused',!$r['success']);
foreach (['query','keyword'] as $key) {
 $r=kwcall('google/blend',['on'=>[$key],'join'=>'left','date_range'=>['from'=>'2026-10-01','to'=>'2026-10-31'],'queries'=>[
    ['prefix'=>'gsc','connector'=>'search-console','accounts'=>[$site],'metrics'=>['impressions','clicks','position'],'dimensions'=>['query']],
    ['prefix'=>'ads','connector'=>'keyword-planner','archive_id'=>$id]]]);
 verifyLab('GSC metrics joined to CPC and volume by '.$key,$r['success']&&$r['row_count']===2&&in_array(1.25,$r['rows'][0],true)&&in_array(100,$r['rows'][0],true),$r);
}
$explorer=true;$r=kwcall('ads/keyword-metrics',['keywords'=>['x']]);$explorer=false;
verifyLab('Realistic provider 403 preserves reason and action',($r['details']['status']??0)===403&&str_contains($r['action']??'','Basic'),$r);
level027('test');$r=kwcall('ads/keyword-metrics',['keywords'=>['x']]);verifyLab('Test blocks production',($r['error_code']??'')==='f3_google_keyword_access_level',$r);
$testAccount=true;$r=kwcall('ads/keyword-metrics',['keywords'=>['x']]);verifyLab('Test accepts verified test account',$r['success'],$r);
verifyLab('Local rolling usage and level limits',Access::status()['operations_last_24h']>10 && Access::status()['test_daily_limit']===15000);
$policy=['mode'=>'restricted','services'=>['ads'=>['resources'=>[$cid],'operations'=>['googleads.customers.googleAds.search','googleads.customers.generateKeywordHistoricalMetrics']]]];
O::set(Policy::OPTION,$policy);
$r=kwcall('ads/keyword-metrics',['keywords'=>['x']]);verifyLab('Restricted mode allows authorized method and account',$r['success'],$r);
$r=kwcall('ads/keyword-ideas',['keywords'=>['x']]);verifyLab('Restricted mode blocks excluded method',empty($r['success']),$r);
$r=kwcall('ads/keyword-archive',['customer_id'=>'1111111111','archive_id'=>$id]);verifyLab('Restricted local archive refuses unauthorized customer',empty($r['success']),$r);
O::set(Policy::OPTION,['mode'=>'identity','services'=>[]]);
O::set(O::OAUTH_CLIENT_ID,'67890-newproject.apps.googleusercontent.com');
verifyLab('Changing the Cloud project invalidates the declaration',Access::level()==='unknown');
O::set(O::OAUTH_CLIENT_ID,'12345-application.apps.googleusercontent.com');
$subscriber=wp_create_user('subscriber027',bin2hex(random_bytes(10)));wp_set_current_user($subscriber);
$r=kwcall('ads/keyword-archive',['archive_id'=>$id]);verifyLab('Subscriber cannot read archived account',$r['success']===false);wp_set_current_user(1);
$r=kwcall('ads/keyword-archive',['customer_id'=>'1111111111','archive_id'=>$id]);verifyLab('Archive isolated by account',empty($r['success']));
C::create('other','Other');$r=kwcall('ads/keyword-archive',['connection_id'=>'other','customer_id'=>$cid,'archive_id'=>$id]);verifyLab('Archive isolated by connection',empty($r['success']));
verifyLab('No Ads mutation endpoint was dispatched',!array_filter($requests,fn($call)=>str_contains($call['url'],'mutate')));
remove_filter('pre_http_request',$fixture,1);
finishLab('planner027',['http'=>'synthetic only','dispatches'=>count($requests)]);
