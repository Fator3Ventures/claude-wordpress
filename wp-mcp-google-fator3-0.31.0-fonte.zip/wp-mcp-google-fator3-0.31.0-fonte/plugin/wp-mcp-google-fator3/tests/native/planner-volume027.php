<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,Ads\PlannerAccess as Access};
wp_get_abilities();$cid='1234567890';
O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'12345-bulk.apps.googleusercontent.com',
 Settings::AUTH_READY=>true,C::BINDINGS=>['ads_customer_id'=>$cid],C::SERVICES=>['ads'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]]],
 [O::OAUTH_CLIENT_SECRET=>'fixture-secret',O::OAUTH_REFRESH_TOKEN=>'fixture-refresh']);
O::set(Access::OPTION,['level'=>'basic','scope'=>Access::scope()]);
$fixture=function ($pre,$args,$url) {
 if (str_contains($url,'/token')) { $data=['access_token'=>'bulk-fixture','expires_in'=>3600]; }
 elseif (str_contains($url,'/googleAds:search')) { $data=['fieldMask'=>'customer.currency_code,customer.test_account','results'=>[['customer'=>['currencyCode'=>'BRL','testAccount'=>false]]]]; }
 elseif (str_contains($url,':generateKeywordHistoricalMetrics')) {
  $words=json_decode($args['body'],true)['keywords'];$months=[];
  foreach (['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'] as $month) { $months[]=['month'=>$month,'year'=>'2025','monthlySearches'=>'100']; }
  $metrics=['avgMonthlySearches'=>'100','monthlySearchVolumes'=>$months,'averageCpcMicros'=>'1000000'];
  $data=['results'=>array_map(fn($word)=>['text'=>$word,'keywordMetrics'=>$metrics],$words)];
 } else { return $pre; }
 return ['headers'=>[],'response'=>['code'=>200],'body'=>wp_json_encode($data)];
};
add_filter('pre_http_request',$fixture,1,3);
$words=array_map(fn($i)=>'palavra número '.$i,range(1,10000));
$read=wp_get_ability('ads/keyword-metrics')->execute(['keywords'=>$words]);
verifyLab('10k rows and twelve monthly values per row persisted',is_array($read)&&!empty($read['success'])&&$read['row_count']===10000&&count($read['rows'])===25&&count($read['rows'][0]['monthly_search_volumes'])===12,$read['message']??null);
$archive=wp_get_ability('ads/keyword-archive');
$part=$archive->execute(['archive_id'=>$read['archive_id'],'offset'=>9999,'limit'=>1]);
verifyLab('Last archived row is the ten-thousandth with its complete series',$part['rows'][0]['keyword']==='palavra número 10000'&&count($part['rows'][0]['monthly_search_volumes'])===12&&$part['next_offset']===null);
$meta=$read['meta'];$request=$meta['request_part'];
while ($meta['next_request_offset']!==null) {
 $part=$archive->execute(['archive_id'=>$read['archive_id'],'offset'=>10000,'request_offset'=>$meta['next_request_offset']]);
 $meta=$part['meta'];$request.=$meta['request_part'];
}
verifyLab('Reassemble and verify all UTF-8 seeds using bounded response pages',hash('sha256',$request)===$meta['request_sha256']&&json_decode($request,true)['keywords']===$words);
verifyLab('Accounting includes metadata and planner request',Access::status()['operations_last_24h']===2);
finishLab('planner-volume027',['results'=>10000,'months_per_result'=>12,'memory_peak_bytes'=>memory_get_peak_usage(true)]);
