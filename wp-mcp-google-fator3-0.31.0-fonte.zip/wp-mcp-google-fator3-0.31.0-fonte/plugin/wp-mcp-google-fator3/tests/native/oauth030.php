<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options,Settings,Connections,Policy};
use Fator3\McpGoogle\Auth\{Candidate,Configuration,OAuthFlow};
Options::batch_verified([Options::ENABLED=>true,Options::AUTH_MODE=>'oauth',Settings::AUTH_READY=>true,Options::OAUTH_CLIENT_ID=>'active.apps.googleusercontent.com',Connections::SERVICES=>['gtm'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]]], [Options::OAUTH_CLIENT_SECRET=>'GOCSPX-active',Options::OAUTH_REFRESH_TOKEN=>'active-refresh']);
$seed=static function(){return Candidate::save('oauth',[Options::OAUTH_CLIENT_ID=>'pending.apps.googleusercontent.com',Options::OAUTH_EMAIL=>'pending@example.invalid',Options::OAUTH_SCOPES=>['https://www.googleapis.com/auth/tagmanager.readonly']],[Options::OAUTH_CLIENT_SECRET=>'GOCSPX-pending',Options::OAUTH_REFRESH_TOKEN=>'pending-refresh']);};
verifyLab('Candidate seeded in native encrypted option',$seed()['success']);
$before=Settings::revision();$r=Configuration::save_oauth('new.apps.googleusercontent.com','',$before);
verifyLab('Different OAuth client cannot inherit prior secret',!$r['success']&&$r['error_code']==='f3_google_oauth_secret_required'&&$before===Settings::revision());
$r=Configuration::save_oauth('pending.apps.googleusercontent.com','',$before);verifyLab('Same OAuth client blank secret is a no-op',$r['success']&&!$r['changed']&&$before===Settings::revision());
$reject=static fn($new,$old)=>$old;add_filter('pre_update_option_'.Candidate::OAUTH,$reject,10,2);
try{$r=OAuthFlow::disconnect(false,$before);}finally{remove_filter('pre_update_option_'.Candidate::OAUTH,$reject,10);}
verifyLab('Native write failure rolls back both grants',!$r['success']&&Settings::revision()===$before&&Candidate::state('oauth')['ready']&&Options::get_secret(Options::OAUTH_REFRESH_TOKEN)==='active-refresh');
Connections::create('separate030','Separate');Connections::run('separate030',$seed);$before=Settings::revision();
$r=OAuthFlow::disconnect(false,$before);verifyLab('Native disconnect clears active and candidate grants',$r['success']&&!Candidate::state('oauth')['ready']&&Options::get_secret(Options::OAUTH_REFRESH_TOKEN)==='');
verifyLab('Both application pairs survive local disconnect',Candidate::oauth_value(Options::OAUTH_CLIENT_SECRET,true)==='GOCSPX-pending'&&Options::get_secret(Options::OAUTH_CLIENT_SECRET)==='GOCSPX-active');
verifyLab('Another connection retains its candidate',Connections::run('separate030',static fn()=>Candidate::state('oauth')['ready']));
$before=Settings::revision();$r=OAuthFlow::disconnect(false,$before);verifyLab('Repeated disconnect does not rewrite revision',$r['success']&&$before===Settings::revision());
$seed();$before=Settings::revision();$subscriber=wp_create_user('oauth030subscriber',bin2hex(random_bytes(16)));wp_set_current_user($subscriber);
verifyLab('Subscriber cannot disconnect',OAuthFlow::disconnect()['error_code']==='f3_google_forbidden');wp_set_current_user(1);verifyLab('Forbidden call preserves both candidates',$before===Settings::revision());
Options::set(Connections::BINDINGS,['gtm_container_path'=>'accounts/123/containers/456']);$before=Settings::revision();$calls=[];
$fixture=static function($pre,$args,$url)use(&$calls){$calls[]=$url;if(str_contains($url,'/token'))return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode(['access_token'=>'synthetic030','expires_in'=>3600])];if(str_contains($url,'tagmanager.googleapis.com'))return ['response'=>['code'=>403],'headers'=>[],'body'=>wp_json_encode(['error'=>['status'=>'PERMISSION_DENIED']])];return $pre;};
add_filter('pre_http_request',$fixture,1,3);try{$r=Configuration::activate('oauth',$before);}finally{remove_filter('pre_http_request',$fixture,1);}
verifyLab('GTM denial prevents candidate promotion',$r['error_code']==='f3_google_candidate_access'&&$before===Settings::revision()&&Candidate::state('oauth')['ready']);
verifyLab('Exact bound GTM container was tested',count(array_filter($calls,static fn($url)=>str_contains($url,'accounts/123/containers/456')))===1);
verifyLab('Encrypted candidate does not expose its token in database',!str_contains((string)get_option(Candidate::OAUTH),'pending-refresh'));
finishLab('oauth030',['supplier_responses'=>'synthetic','google_requests_real'=>0]);
