<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,Ads\PlannerAccess,Ads\ArchiveStore,Ads\PlannerRequest,Storage\Repository};

function planner029call(string $ability,array $input): array {
    $r=wp_get_ability('ads/keyword-'.$ability)->execute($input);
    return is_wp_error($r)?['success'=>false,'error_code'=>$r->get_error_code()]:$r;
}
function planner029count(string $kind): int {
    return Repository::count($kind);
}

$account='1234567890';$policy=['mode'=>'identity','services'=>[]];
O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'12345-review.apps.googleusercontent.com',Settings::AUTH_READY=>true,
    C::BINDINGS=>['ads_customer_id'=>$account],C::SERVICES=>['ads'=>'read'],Policy::OPTION=>$policy,O::ADS_API_VERSION=>'v25'],
    [O::OAUTH_CLIENT_SECRET=>'fixture-client',O::OAUTH_REFRESH_TOKEN=>'fixture-refresh',O::ADS_DEVELOPER_TOKEN=>'fixture-token',
        O::SA_JSON=>'{}']);
O::set(PlannerAccess::OPTION,['scope'=>PlannerAccess::scope(),'level'=>'basic']);
$baseline=F3_MCP_GOOGLE_VERSION==='0.28.0';
$scenario='';$pages=[];
$fixture=function($pre,$args,$url)use(&$scenario,&$pages,$account) {
    if (str_contains($url,'/token')) {
        $body=['access_token'=>'fixture-access','expires_in'=>3600];
    } elseif (str_ends_with($url,'googleAds:search')) {
        if ($scenario==='identity') { O::set_secret(O::OAUTH_REFRESH_TOKEN,'fixture-other-principal'); }
        $body=['fieldMask'=>'customer.currency_code,customer.test_account','results'=>[['customer'=>['currencyCode'=>'BRL','testAccount'=>false]]]];
    } elseif (str_ends_with($url,':generateKeywordIdeas')) {
        $token=json_decode($args['body'],true)['pageToken']??null;
        $pages[]=$token;
        $body=$token===null ? ['results'=>[['text'=>'primeira']],'nextPageToken'=>'page-two'] : ['results'=>[['text'=>$scenario===''?'segunda':'revogada']]];
        if ($token!==null) {
            if ($scenario==='legacy') {
                return ['response'=>['code'=>400],'headers'=>[],'body'=>'{"error":{"status":"INVALID_ARGUMENT","message":"fixture interrupted"}}'];
            }
            if ($scenario==='stale') {
                $latest=Repository::select('keywordread',['id_prefix'=>$account.'-'],1,0,true,true)[0];
                $id=$latest['record_id'];
                $checkpoint=ArchiveStore::get('keywordread',$id);
                $checkpoint['observed_at']='2026-01-01T00:00:00+00:00';
                $saved=ArchiveStore::put('keywordread',$id,$checkpoint);
                if (!$saved['success']) { throw new RuntimeException('Failed to write concurrent checkpoint'); }
            }
            if ($scenario==='during_write') {
                $body['results']=array_map(static fn($i)=>['text'=>'pendente-'.$i],range(1,101));
            }
            if ($scenario==='channel') { O::set(O::ENABLED,false); }
            if ($scenario==='api') { O::set(O::ADS_API_VERSION,'v26'); }
            if ($scenario==='method') { O::set(Policy::OPTION,['mode'=>'restricted','services'=>['ads'=>['resources'=>[$account],'operations'=>['googleads.customers.googleAds.search']]]]); }
            if ($scenario==='external') {
                // A separate administrator can commit while this process still caches alloptions.
                global $wpdb;
                $wpdb->update($wpdb->options,['option_value'=>'0'],['option_name'=>O::ENABLED]);
            }
        }
    } else { return $pre; }
    return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];
};
add_filter('pre_http_request',$fixture,1,3);
$scenario='identity';$prior=planner029count('keywordread');
$read=planner029call('ideas',['keywords'=>['contexto inicial']]);
if ($baseline) {
    verifyLab('Baseline mixed the original account metadata with the replacement principal',!empty($read['complete']) && count($pages)===2,$read);
} else {
    verifyLab('Principal replaced during account lookup stops before planner dispatch',($read['error_code']??'')==='f3_google_keyword_context' && !$pages,$read);
    verifyLab('Changed account lookup produced no receipt',planner029count('keywordread')===$prior && !isset($read['archive_id']));
}
O::set_secret(O::OAUTH_REFRESH_TOKEN,'fixture-refresh');
foreach (['channel','api','method','external'] as $scenario) {
    $pages=[];$chunks=planner029count('adsrows');
    $r=planner029call('ideas',['keywords'=>['trabalho']]);
    verifyLab('Provider received each initial page exactly once '.$scenario,$pages===[null,'page-two'],$pages);
    if ($baseline) {
        verifyLab('Baseline published the revoked second page '.$scenario,!empty($r['complete']) && array_column($r['rows'],'keyword')===['primeira','revogada'],$r);
    } else {
        verifyLab('Reject changed context '.$scenario,($r['error_code']??'')==='f3_google_keyword_context' && isset($r['resume_id']),$r);
        verifyLab('Rejected page added no chunk '.$scenario,planner029count('adsrows')===$chunks+1);
    }
    if ($scenario==='external') {
        wp_cache_delete('alloptions','options');
        wp_cache_delete(O::ENABLED,'options');
    }
    $reset=O::batch_verified([O::ENABLED=>true,Policy::OPTION=>$policy,O::ADS_API_VERSION=>'v25']);
    verifyLab('Restore original authorization '.$scenario,$reset['success'],$reset['error_code']??null);
    if ($baseline) { continue; }
    $receipt=planner029call('archive',['archive_id'=>$r['resume_id']]);
    verifyLab('Retain first authorized page '.$scenario,empty($receipt['complete']) && $receipt['row_count']===1 && $receipt['rows'][0]['keyword']==='primeira',$receipt);
    $scenario='';$restored=planner029call('ideas',['resume_id'=>$r['resume_id']]);
    verifyLab('Resume uses same cursor and stores each authorized row once',!empty($restored['complete']) && array_column($restored['rows'],'keyword')===['primeira','segunda'] && $pages===[null,'page-two','page-two'],$restored);
}

if (!$baseline) {
    foreach (['stale','during_write'] as $scenario) {
        $chunks=planner029count('adsrows'); $pages=[];
        $changed=false;
        $watch=function(string $sql)use (&$changed,$scenario,&$pages,$chunks) {
            if ($scenario!=='during_write' || $changed || count($pages)!==2
                || !str_starts_with($sql,'INSERT IGNORE INTO '.Repository::table())
                || !str_contains($sql,"'adsrows'")) {
                return $sql;
            }
            // This independently committed edit must be visible before the planner transaction commits.
            [$host,$port]=explode(':',DB_HOST);
            $db=new mysqli($host,DB_USER,DB_PASSWORD,DB_NAME,(int)$port);
            global $wpdb;
            $prior=(int)$db->query("SELECT COUNT(*) FROM ".Repository::table()." WHERE kind='adsrows'")->fetch_row()[0];
            $changed=$prior===$chunks+1 && $db->query("UPDATE $wpdb->options SET option_value='0' WHERE option_name='".O::ENABLED."'") && $db->affected_rows===1;
            $db->close();
            return $sql;
        };
        add_filter('query',$watch);
        $read=planner029call('ideas',['keywords'=>['gravação']]);
        remove_filter('query',$watch);
        $code=$scenario==='stale'?'f3_google_repository_conflict':'f3_google_keyword_context';
        verifyLab('Reject superseded or revoked write '.$scenario,($read['error_code']??'')===$code && isset($read['resume_id']),$read);
        verifyLab('Uncommitted chunks were rolled back '.$scenario,planner029count('adsrows')===$chunks+1);
        if ($scenario==='during_write') {
            verifyLab('External connection committed the revocation while writing',$changed);
            wp_cache_delete('alloptions','options');
            wp_cache_delete(O::ENABLED,'options');
            verifyLab('Restore channel after external edit',O::set(O::ENABLED,true)['success']);
        }
        $archived=planner029call('archive',['archive_id'=>$read['resume_id']]);
        verifyLab('Committed receipt survived '.$scenario,$archived['row_count']===1 && !$archived['complete'] &&
            ($scenario!=='stale' || $archived['meta']['observed_at']==='2026-01-01T00:00:00+00:00'),$archived);
        $scenario='';$restored=planner029call('ideas',['resume_id'=>$read['resume_id']]);
        verifyLab('Retry after interrupted commit preserves both pages',!empty($restored['complete']) && array_column($restored['rows'],'keyword')===['primeira','segunda'] && $pages===[null,'page-two','page-two'],$restored);
    }
    foreach (['metrics','forecast','themes'] as $kind) {
        verifyLab('Reject unsolicited cursor for a non-paginated RPC '.$kind,
            PlannerRequest::validate_response($kind,['nextPageToken'=>'unexpected'])?->get_error_code()==='f3_google_keyword_response');
    }
}
if (getenv('F3_LAB_ORIGIN')==='upgrade') {
    if ($baseline) {
        $scenario='legacy';$read=planner029call('ideas',['keywords'=>['leitura anterior']]);
        verifyLab('Baseline saved interrupted receipt for direct update',empty($read['success']) && isset($read['resume_id']),$read);
        update_option('f3_lab_planner029_legacy_id',$read['resume_id'],false);
    } else {
        $id=get_option('f3_lab_planner029_legacy_id','');
        // Run this suite on both sides of a direct update to exercise actual 0.28 ciphertext and cursor.
        if ($id!=='') {
            $pages=[];$scenario='';
            $old=planner029call('archive',['archive_id'=>$id]);
            verifyLab('0.28 ciphertext readable after direct update',empty($old['complete']) && array_column($old['rows'],'keyword')===['primeira'] && !$pages,$old);
            $continued=planner029call('ideas',['resume_id'=>$id]);
            verifyLab('0.28 cursor completed once by new version',!empty($continued['complete']) && array_column($continued['rows'],'keyword')===['primeira','segunda'] && $pages===['page-two'],$continued);
        }
    }
}
remove_filter('pre_http_request',$fixture,1);
finishLab($baseline?'planner029-base':'planner029',['provider'=>'synthetic']);
