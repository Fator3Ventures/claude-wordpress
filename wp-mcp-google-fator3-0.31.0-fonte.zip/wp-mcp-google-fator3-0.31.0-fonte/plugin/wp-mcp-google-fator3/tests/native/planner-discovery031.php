<?php
require __DIR__.'/common.php'; require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy};
use Fator3\McpFiles\Persistence;
$baseline=F3_MCP_GOOGLE_VERSION===expectedLab('baseline');
function tool031(string $tool,array $params,string $auth): array {
 $r=wp_remote_post(rest_url('mcp/wp-mcp-fator3'),['timeout'=>75,'headers'=>['Authorization'=>$auth,'Content-Type'=>'application/json','Accept'=>'application/json','Mcp-Protocol-Version'=>'2026-07-28','Mcp-Method'=>'tools/call','Mcp-Name'=>$tool],'body'=>wp_json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>'tools/call','params'=>['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>new stdClass()],'name'=>$tool,'arguments'=>$params]])]);
 if(is_wp_error($r))return ['error_code'=>$r->get_error_code()];
 $body=json_decode(wp_remote_retrieve_body($r),true);$data=$body['result']['structuredContent']??$body;
 while(isset($data['data'])&&is_array($data['data']))$data=$data['data'];
 return $data;
}
$credentials=[];
try {
 O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>false,C::SERVICES=>['gsc'=>'read']]);
 $credential=rpc_identityLab();$credentials[]=[$credential['uuid'],1];$auth=$credential['auth'];
 $settings=Settings::revision();
 $list=tool031('wp-mcp-ultimate-discover-abilities',['prefix'=>'ads/keyword','per_page'=>20],$auth);
 $names=array_column($list['abilities']??[],'name');sort($names);
 $expected=['ads/keyword-archive','ads/keyword-forecast','ads/keyword-ideas','ads/keyword-metrics','ads/keyword-themes'];
 if($baseline)unset($expected[2]);
 verifyLab('Real MCP discovery matches expected planner list',$names===array_values($expected),$list);
 $info=tool031('wp-mcp-ultimate-get-ability-info',['ability_name'=>'ads/keyword-ideas'],$auth);
 verifyLab('Ideas schema discovery matches version', $baseline?($info['success']??true)===false:($info['name']??'')==='ads/keyword-ideas',$info);
 if(!$baseline){
  verifyLab('Alternative seeds and resume retain public schema',isset($info['input_schema']['properties']['url'],$info['input_schema']['properties']['site'],$info['input_schema']['properties']['resume_id'])&&empty($info['input_schema']['required']));
  verifyLab('Planner keeps read mode and local archival effect',($info['meta']['fator3']['mode']??'')==='read'&&($info['meta']['fator3']['local_effect']??'')==='write');
 }
 $inputs=['ideas'=>['url'=>'https://www.engagia.com.br/'],'metrics'=>['keywords'=>['cto']],'forecast'=>['campaign'=>[]],'themes'=>['keywords'=>['cto'],'ad_groups'=>['customers/1234567890/adGroups/1']]];
 foreach($inputs as $kind=>$input){
  $r=rpcLab('ads/keyword-'.$kind,$input);
  verifyLab('MCP disabled connector diagnosis '.$kind,$baseline?empty($r['success'])&&($r['error_code']??'')!=='f3_google_connector_off':($r['error_code']??'')==='f3_google_connector_off',$r);
 }
 wp_cache_flush();verifyLab('Discovery and refusals preserve configuration',$settings===Settings::revision());
 if(!$baseline){
  $noerror=tool031('wp-mcp-ultimate-discover-abilities',['prefix'=>'ads/keyword','readonly'=>true,'per_page'=>20],$auth);
  verifyLab('Read filter retains all five planner operations',count($noerror['abilities']??[])===5);
  O::batch_verified([O::ADS_ENABLED=>true,C::SERVICES=>['ads'=>'read']]);
  $r=rpcLab('ads/keyword-ideas',['url'=>'https://www.engagia.com.br/']);verifyLab('Missing credential returns domain diagnosis',($r['error_code']??'')==='f3_google_not_configured',$r);
  O::batch_verified([O::ADS_ENABLED=>false,C::SERVICES=>['gsc'=>'read']]);
  C::create('selection031','Selected diagnostic connection');
  C::run('selection031',static function(){O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,C::SERVICES=>['ads'=>'read']]);});
  $r=rpcLab('ads/keyword-ideas',['connection_id'=>'selection031','url'=>'https://www.engagia.com.br/']);verifyLab('MCP checks selected Google connection',($r['error_code']??'')==='f3_google_not_configured',$r);
  $custom=rpc_identityLab('custom',['ads/keyword-archive']);$credentials[]=[$custom['uuid'],1];
  $list=tool031('wp-mcp-ultimate-discover-abilities',['prefix'=>'ads/keyword','per_page'=>20],$custom['auth']);
  verifyLab('Custom profile discovers only explicitly permitted reader',array_column($list['abilities']??[],'name')===['ads/keyword-archive'],$list);
  $r=rpcLab('ads/keyword-ideas',$inputs['ideas'],$custom['auth']);verifyLab('Custom profile cannot execute ungranted ideas',empty($r['success'])&&($r['error_code']??'')!=='f3_google_connector_off',$r);
  $custom=rpc_identityLab('custom',['ads/keyword-ideas']);$credentials[]=[$custom['uuid'],1];
  $list=tool031('wp-mcp-ultimate-discover-abilities',['prefix'=>'ads/keyword','per_page'=>20],$custom['auth']);verifyLab('Explicit grant discovers ideas with Ads off',array_column($list['abilities']??[],'name')===['ads/keyword-ideas'],$list);
  $r=rpcLab('ads/keyword-ideas',$inputs['ideas'],$custom['auth']);verifyLab('Explicit grant gets connector diagnosis',($r['error_code']??'')==='f3_google_connector_off',$r);
  $uid=wp_create_user('reader031',bin2hex(random_bytes(16)));$sub=WP_Application_Passwords::create_new_application_password($uid,['name'=>'Reader031']);$credentials[]=[$sub[1]['uuid'],$uid];
  Persistence::put('connections','app:'.$sub[1]['uuid'],['connection_id'=>'app:'.$sub[1]['uuid'],'user_id'=>$uid,'status'=>'active','profile'=>'maintenance','policy_version'=>1]);
  $r=rpcLab('ads/keyword-ideas',$inputs['ideas'],'Basic '.base64_encode('reader031:'.$sub[0]));verifyLab('Nonadministrator is denied despite maintenance profile',empty($r['success'])&&($r['error_code']??'')!=='f3_google_connector_off',$r);
  O::set(O::ENABLED,false);$r=rpcLab('ads/keyword-ideas',$inputs['ideas']);verifyLab('Closed Google channel stays denied',empty($r['success'])&&($r['error_code']??'')!=='f3_google_connector_off',$r);
  O::set(O::ENABLED,true);
  $r=rpcLab('ads/update-campaign',['customer_id'=>'1234567890','campaign_id'=>'123','status'=>'PAUSED']);verifyLab('Unrelated mutation remains refused',empty($r['success']),$r);
 }
} finally { foreach($credentials as [$uuid,$uid])WP_Application_Passwords::delete_application_password($uid,$uuid); }
finishLab('planner-discovery031'.($baseline?'-base':''),['baseline_reproduction'=>$baseline,'provider'=>'none; external HTTP blocked by laboratory']);
