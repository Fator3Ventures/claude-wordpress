<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{Automation\Execution,ConversionDelivery as D,RenewalNotifications as N,Options as O,Connections as C,Settings,Policy,Records,Admin,Lock};
wp_get_abilities();update_option('f3base_ga4_measurement_id','G-TEST025');
$calls=[];$bad=false;$deadline_once=false;$mail=[];$transport='ok';$nested=false;$secret='synthetic-mp-025';
$http=static function($pre,$args,$url)use(&$calls,&$bad,&$deadline_once,$secret){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;
 $calls[]=$url;
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic025','expires_in'=>3600];
 elseif($deadline_once && str_contains($url,'measurementProtocolSecrets')) {
    $deadline_once=false;
    return Execution::run(static fn()=>Execution::check(),0);
 }
 elseif(str_contains($url,'measurementProtocolSecrets'))$body=['measurementProtocolSecrets'=>[['secretValue'=>$bad?'wrong':$secret]]];
 elseif(str_contains($url,'analyticsadmin.googleapis.com'))$body=['name'=>'properties/123/dataStreams/456','webStreamData'=>['measurementId'=>'G-TEST025']];
 elseif(str_contains($url,'/debug/mp/collect'))$body=['validationMessages'=>[]];
 elseif(str_contains($url,'googleAds:search')){if($bad)return new WP_Error('synthetic_read_failed','Synthetic unavailable');$body=['results'=>[['conversionAction'=>['resourceName'=>'customers/1234567890/conversionActions/789','type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>37.5,'defaultCurrencyCode'=>'BRL']]]]];}
 elseif(str_contains($url,'/events:ingest')&&!empty(json_decode($args['body'],true)['validateOnly']))$body=[];
 else return new WP_Error('unexpected_external_call','Only synthetic validation is allowed');
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];
};
add_filter('pre_http_request',$http,1,3);
$sender=static function($pre,$atts)use(&$mail,&$transport,&$nested){$mail[]=$atts['subject'];if($nested)D::renew_due();if($transport==='throw')throw new RuntimeException('Synthetic mail uncertainty');return $transport!=='false';};
add_filter('pre_wp_mail',$sender,PHP_INT_MAX,2);
function due025($target,$expiry=null){$c=O::get(D::CONFIG);$c['renewal'][$target]['next_attempt']=time()-1;if($expiry!==null)$c['verified'][$target]['expires']=$expiry;O::set(D::CONFIG,$c);}
function run025(){wp_set_current_user(0);try{return D::renew_due();}finally{wp_set_current_user(1);}}
function policy025($hours){$p=N::plan(['configuration'=>['expiry_warning_hours'=>$hours]]);return N::configure(['configuration'=>$p['configuration'],'expected_revision'=>$p['configuration_revision'],'expected_plan_hash'=>$p['plan_hash']]);}
function inc025($target='ga4'){return Records::get('incident',N::incident_id($target));}
function observed025($target,$c,$failed){return D::locked(static function()use($target,$c,$failed){N::observe($target,$c,$failed);return ['success'=>true];},true);}
$initial=Settings::revision();$before=google_config_digestLab();$p=N::plan(['configuration'=>['expiry_warning_hours'=>3]]);
verifyLab('Plan has no persistence or provider calls',$p['success']&&$p['dry_run']&&!$p['persisted']&&$before===google_config_digestLab()&&$calls===[]&&$mail===[]);
verifyLab('New default is six hours without materializing option',N::config()===['expiry_warning_hours'=>6]&&!O::stored(O::storage_name(N::OPTION))['exists']);
foreach([-1,25,6.0,'6',null] as $hours)verifyLab('Reject malformed hours '.json_encode($hours),empty(N::plan(['configuration'=>['expiry_warning_hours'=>$hours]])['success']));
verifyLab('Apply requires exact plan',empty(N::configure(['configuration'=>['expiry_warning_hours'=>3],'expected_revision'=>$p['configuration_revision'],'expected_plan_hash'=>str_repeat('0',64)])['success']));
verifyLab('Verified configuration apply',policy025(3)['success']&&N::config()['expiry_warning_hours']===3&&$mail===[]&&$calls===[]&&Settings::revision()!==$initial);
verifyLab('Stale preview is rejected',empty(N::configure(['configuration'=>['expiry_warning_hours'=>3],'expected_revision'=>$p['configuration_revision'],'expected_plan_hash'=>$p['plan_hash']])['success']));
verifyLab('Same effective value is no-op',policy025(3)['changed']===false);
C::create('isolated025','Isolated');verifyLab('Connection starts with independent default',C::run('isolated025',static fn()=>N::config()['expiry_warning_hours'])===6);
verifyLab('Plan from another connection refused',C::run('isolated025',static fn()=>N::configure(['configuration'=>['expiry_warning_hours'=>3],'expected_revision'=>$p['configuration_revision'],'expected_plan_hash'=>$p['plan_hash']]))['success']===false);
wp_set_current_user(0);verifyLab('Anonymous policy read/write denied',empty(N::plan(['configuration'=>['expiry_warning_hours'=>1]])['success'])&&empty(N::configure([])['success']));wp_set_current_user(1);policy025(6);
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic025',O::OAUTH_REFRESH_TOKEN=>'synthetic025',O::ADS_DEVELOPER_TOKEN=>'synthetic025']);
$r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'stream'=>'properties/123/dataStreams/456','customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789'],'mp_secret'=>$secret]);verifyLab('Native Core conversion configuration ready',$r['success'],$r);
foreach(['ga4','google_ads'] as $target){$r=D::verify(['expected_revision'=>D::revision(),'target'=>$target]);verifyLab('Native synthetic proof '.$target,!empty($r['success']),$r);}
$proofs=O::get(D::CONFIG);policy025(4);verifyLab('Policy change preserves proofs grants and all delivery state',O::get(D::CONFIG)===$proofs);policy025(6);
$bad=true;due025('ga4');$r=run025();$i=inc025();$cap=(new D('ga4'))->capabilities();
verifyLab('First failure immediately visible with no mail',$i['status']==='open'&&$i['email_state']==='deferred'&&count($mail)===0&&$cap['ready']&&$cap['renewal']['result']==='failed',$r);
verifyLab('Failure preserves expiry and starts 5 minute backoff',$cap['verification_expires_at']===$proofs['verified']['ga4']['expires']&&$cap['renewal']['next_attempt']>=time()+295);
$reads=count($calls);$i0=$i;D::status();D::status();verifyLab('Status does not send call or rewrite incident',count($calls)===$reads&&$mail===[]&&inc025()===$i0);
$bad=false;due025('ga4');run025();verifyLab('Recovery on next retry resolves silently',inc025()['status']==='resolved'&&$mail===[]);
$bad=true;due025('ga4');run025();$c=O::get(D::CONFIG);$c['verified']['ga4']['expires']=time()+6*HOUR_IN_SECONDS;$c['renewal']['ga4']['next_attempt']=time()+1000;O::set(D::CONFIG,$c);$reads=count($calls);run025();
verifyLab('Expiry threshold between retries sends one attention without HTTP',count($mail)===1&&count($calls)===$reads&&inc025()['email_state']==='accepted'&&inc025()['notification_reason']==='proof_near_expiry');
run025();D::status();verifyLab('Repeated executor and read do not duplicate attention',count($mail)===1);
$bad=false;due025('ga4');run025();run025();verifyLab('Notified recovery sends exactly once',count($mail)===2&&inc025()['recovery_email_state']==='accepted'&&inc025()['status']==='resolved');
$cycle=inc025()['notification_cycle'];$bad=true;$nested=true;
for($n=1;$n<=6;$n++){due025('ga4');run025();verifyLab('Sequence notification threshold failure '.$n,count($mail)===($n<6?2:3));}
$nested=false;verifyLab('New failure cycle gets a new notification identity',inc025()['notification_cycle']!==$cycle&&inc025()['notification_reason']==='retry_sequence_exhausted');
due025('ga4');run025();verifyLab('Hourly retries continue without another attention',count($mail)===3&&(new D('ga4'))->capabilities()['renewal']['next_attempt']>=time()+3595);
// A healthy provider cannot recover a proof when the worker's current pass runs out of time.
$bad=false;$deadline_once=true;$baseline_mail=count($mail);
$deadline_message=Execution::run(static fn()=>Execution::check(),0)->get_error_message();
for($attempt=0;$attempt<3;$attempt++) {
    due025('ga4');$r=run025();
    $renewal=O::get(D::CONFIG)['renewal']['ga4'];
    $incident=inc025();
    $detail=['pass'=>$r['ga4']??null,'phase'=>$renewal['phase']??null,'provider'=>$renewal['provider_error']??null,
        'incident'=>$incident['status']??null,'recovery'=>$incident['recovery_email_state']??null,'mail'=>count($mail)];
    if(!empty($r['ga4']['success'])) break;
    // Accelerate only a scheduled retry after the known local deadline. All other causes fail immediately.
    verifyLab('Expired recovery pass preserves the incident and schedules another attempt '.($attempt+1),
        ($renewal['provider_error']['message']??null)===$deadline_message && ($renewal['provider_error']['http_status']??null)===0 &&
        $renewal['next_attempt']>time() && $incident['status']==='open' && $incident['recovery_email_state']==='not_needed' &&
        count($mail)===$baseline_mail,$detail);
}
verifyLab('Second cycle recovery once',!$deadline_once && !empty($r['ga4']['success']) && $incident['status']==='resolved' &&
    $incident['recovery_email_state']==='accepted' && count($mail)===4,$detail);
$bad=true;due025('google_ads',time()+100);run025();verifyLab('Ads uses independent incident and notice',count($mail)===5&&inc025('google_ads')['email_state']==='accepted');
$bad=false;due025('google_ads');run025();verifyLab('Ads recovers independently',count($mail)===6&&inc025('google_ads')['recovery_email_state']==='accepted');
$sample=['verified'=>['ga4'=>['expires'=>100000]],'renewal'=>['ga4'=>['result'=>'failed','failures'=>1]]];
verifyLab('Threshold boundary is inclusive',!N::decision(['expiry_warning_hours'=>6],$sample,'ga4',78399)['eligible']&&N::decision(['expiry_warning_hours'=>6],$sample,'ga4',78400)['eligible']);
verifyLab('Zero warns only at expiry',!N::decision(['expiry_warning_hours'=>0],$sample,'ga4',99999)['eligible']&&N::decision(['expiry_warning_hours'=>0],$sample,'ga4',100000)['eligible']);
verifyLab('No prior proof waits for exhaustion',!N::decision(['expiry_warning_hours'=>24],['renewal'=>$sample['renewal']],'ga4',100000)['eligible']);
$bad=true;$transport='false';due025('ga4',time()+100);run025();$n=count($mail);due025('ga4');run025();verifyLab('Mail rejection not automatically resent',inc025()['email_state']==='failed'&&count($mail)===$n);$bad=false;due025('ga4');run025();verifyLab('No recovery mail without accepted attention',count($mail)===$n&&inc025()['status']==='resolved');
$transport='throw';$bad=true;due025('ga4',time()+100);run025();$n=count($mail);due025('ga4');run025();verifyLab('Mail exception remains unknown without resend',count($mail)===$n&&inc025()['email_state']==='unknown');$transport='ok';$bad=false;due025('ga4');run025();verifyLab('Unknown attention does not trigger recovery',count($mail)===$n);
// Legacy upgrade semantics and interruption after a receipt commit.
$old=['id'=>N::incident_id('ga4'),'status'=>'open','email_state'=>'accepted','event'=>'conversion_renewal','connection_id'=>'default'];Records::put('incident',$old['id'],$old);$c=O::get(D::CONFIG);$c['renewal']['ga4']['result']='failed';$c['renewal']['ga4']['failures']=6;observed025('ga4',$c,true);verifyLab('Legacy accepted attention not duplicated',count($mail)===$n);
observed025('ga4',$c,false);observed025('ga4',$c,false);verifyLab('Legacy accepted attention gets one recovery',count($mail)===$n+1&&inc025()['recovery_email_state']==='accepted');
$old['status']='resolved';Records::put('incident',$old['id'],$old);$n=count($mail);observed025('ga4',$c,false);verifyLab('Legacy resolved incident stays byte-identical',inc025()===$old&&count($mail)===$n);
$old+=['notification_cycle'=>'interrupted025'];$old['status']='open';$old['email_state']='dispatching';Records::put('incident',$old['id'],$old);$rid=hash('sha256',$old['id'].'|interrupted025|attention');Records::put('mail',$rid,['status'=>'accepted']);
verifyLab('Status recovers accepted transport evidence read-only',N::status($c,'ga4')['attention_state']==='accepted'&&inc025()===$old);observed025('ga4',$c,false);verifyLab('Committed receipt allows recovery after incident interruption',count($mail)===$n+1);
$old['notification_cycle']='reserved025';$old['email_state']='deferred';Records::put('incident',$old['id'],$old);Records::put('mail',hash('sha256',$old['id'].'|reserved025|attention'),['status'=>'dispatching']);$n=count($mail);observed025('ga4',$c,true);verifyLab('Durable reservation prevents replay after crash',count($mail)===$n&&inc025()['email_state']==='unknown');
// A failed incident write must prevent the first mail, even with eligible state.
$old['notification_cycle']='database025';$old['email_state']='deferred';Records::put('incident',$old['id'],$old);global $wpdb;$suppress=$wpdb->suppress_errors(true);
$fail=static function($sql){return str_contains($sql,'f3_mcp_google')&&preg_match('/^(INSERT|UPDATE)/i',$sql)?'INVALID SYNTHETIC SQL':$sql;};add_filter('query',$fail,PHP_INT_MAX);
try{observed025('ga4',$c,true);}finally{remove_filter('query',$fail,PHP_INT_MAX);$wpdb->suppress_errors($suppress);}verifyLab('Failed persistence cannot precede an email',count($mail)===$n);
require_once ABSPATH.'wp-admin/includes/template.php';$_GET=['section'=>'conversions'];$_SERVER['REQUEST_METHOD']='GET';ob_start();Admin::render();$html=ob_get_clean();verifyLab('Native UI exposes simulation without raw JSON',str_contains($html,'name="expiry_warning_hours"')&&str_contains($html,'Simular')&&!str_contains($html,$secret));file_put_contents(getenv('F3_EVIDENCE_DIR').'/renewal025-screen.html',$html);
// Native admin HTTP round-trip proves preview hashes survive the form and nonce gate.
$token=WP_Session_Tokens::get_instance(1)->create(time()+600);$cookie=wp_generate_auth_cookie(1,time()+600,'auth',$token);$logged=wp_generate_auth_cookie(1,time()+600,'logged_in',$token);$_COOKIE[LOGGED_IN_COOKIE]=$logged;$nonce=wp_create_nonce('f3-google-conversions');
$url=admin_url('tools.php?page='.Admin::SLUG.'&section=conversions');$headers=['Cookie'=>AUTH_COOKIE.'='.$cookie.'; '.LOGGED_IN_COOKIE.'='.$logged];
$post=wp_remote_post($url,['timeout'=>30,'headers'=>$headers,'body'=>['connection_id'=>'default','_wpnonce'=>$nonce,'action_kind'=>'renewal-preview','expiry_warning_hours'=>'9']]);$body=wp_remote_retrieve_body($post);
$dom=new DOMDocument();@$dom->loadHTML($body);$xp=new DOMXPath($dom);$form=$xp->query('//form[button[@value="renewal-apply"]]')->item(0);$fields=[];if($form)foreach($xp->query('.//input[@name]',$form) as $input)$fields[$input->getAttribute('name')]=$input->getAttribute('value');
verifyLab('Native admin preview displays guarded apply form',wp_remote_retrieve_response_code($post)===200&&isset($fields['plan_hash'],$fields['revision'])&&N::config()['expiry_warning_hours']===6);
$fields['action_kind']='renewal-apply';$post=wp_remote_post($url,['timeout'=>30,'headers'=>$headers,'body'=>$fields]);verifyLab('Native admin applies exact simulated value',wp_remote_retrieve_response_code($post)===200&&N::config()['expiry_warning_hours']===9);
$post=wp_remote_post($url,['timeout'=>30,'headers'=>$headers,'body'=>array_merge($fields,['_wpnonce'=>'invalid','expiry_warning_hours'=>'10'])]);verifyLab('Invalid native nonce preserves policy',N::config()['expiry_warning_hours']===9&&str_contains(wp_remote_retrieve_body($post),'expired'));
WP_Session_Tokens::get_instance(1)->destroy($token);unset($_COOKIE[LOGGED_IN_COOKIE]);policy025(6);

$credential=rpc_identityLab();$auth=$credential['auth'];$r=rpcLab('google/plan-renewal-notifications',['configuration'=>['expiry_warning_hours'=>8]]);verifyLab('MCP 0.38 transports simulation',!empty($r['success'])&&!empty($r['dry_run'])&&isset($r['plan_hash']),$r);
$r=rpcLab('google/configure-renewal-notifications',['configuration'=>$r['configuration'],'expected_revision'=>$r['configuration_revision'],'expected_plan_hash'=>$r['plan_hash']]);verifyLab('MCP 0.38 applies policy through authenticated endpoint',!empty($r['success'])&&$r['configuration']['expiry_warning_hours']===8,$r);
$meta=wp_get_ability('google/configure-renewal-notifications')->get_meta();verifyLab('Local config has no Google remote effect',($meta['fator3']['remote_effect']??null)==='none',$meta);
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);O::set(D::CONFIG,D::defaults());remove_filter('pre_http_request',$http,1);remove_filter('pre_wp_mail',$sender,PHP_INT_MAX);
finishLab('renewal025',['providers'=>'synthetic validations only','mail'=>'intercepted; no delivery','clock'=>'timestamps accelerated','concurrency'=>'reentrant executor while notification delivery lock is held']);
