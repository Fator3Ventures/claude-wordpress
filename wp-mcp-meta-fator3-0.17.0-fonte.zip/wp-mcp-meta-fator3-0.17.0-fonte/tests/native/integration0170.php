<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
use Fator3\Meta as M90;
use Fator3\McpFiles as C90;
function meta_companions090_cases(){
 M90\Access::admin();if(M90\Config::VERSION!=='0.17.0')throw new RuntimeException('Wrong candidate');
 $checks=[];$check=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};$u=get_current_user_id();$old=C90\ConnectionContext::transport_identity();$id='qa090_'.bin2hex(random_bytes(10));$keys=[];$http=0;$mail=0;
 $h=static function($pre)use(&$http){$http++;return new WP_Error('qa090_external_blocked');};$m=static function()use(&$mail){$mail++;return true;};add_filter('pre_http_request',$h,1);add_filter('pre_wp_mail',$m,1);
 try{
  C90\Persistence::put('oauth-grants',$id,['grant_id'=>$id,'user_id'=>$u,'client_id'=>'qa090','profile'=>'maintenance','status'=>'active']);C90\ConnectionContext::oauth(['user_id'=>$u,'grant_id'=>$id,'client_id'=>'qa090','profile'=>'maintenance']);C90\ConnectionContext::get();
  foreach(['busy','upstream_error','rate_limited'] as $reason){$r=M90\Result::fail(new M90\Fault($reason,'synthetic'));$check($reason.' unknown effects are not transient',$r['retryable']&&!array_key_exists('applied',$r)&&!C90\ExecutionCoordinator::transient($r));}
  $check('explicit retryable non-applied failure remains transient',C90\ExecutionCoordinator::transient(['success'=>false,'retryable'=>true,'applied'=>false]));
  $n=0;$input=['idempotency_key'=>$id];$key=C90\ConnectionContext::key().':'.$u.':meta/status:'.$id;$keys[]=$key;
  $run=static function()use(&$n){$n++;return M90\Result::fail(new M90\Fault('busy','synthetic busy with unknown effects'));};
  $a=C90\ExecutionCoordinator::once('meta/status',$input,$run,'qa090_first');$b=C90\ExecutionCoordinator::once('meta/status',$input,$run,'qa090_second');
  $check('unknown-effect Meta failure keeps receipt and replays once',$n===1&&!$a['success']&&!$b['success']&&($b['replayed']??false)&&($b['error_code']??'')==='busy');
  $policy=C90\Persistence::get('connections','grant:'.$id);$policy['profile']='read';C90\Persistence::put('connections','grant:'.$id,$policy);
  $health=M90\Api::dispatch('health',[],true);$status=M90\Api::dispatch('status',[],true);$check('read profile allows health and denies status',$health['success']&&!$status['success']&&$status['code']==='not_authorized');
  $policy['profile']='custom';$policy['abilities']=['meta/health'];C90\Persistence::put('connections','grant:'.$id,$policy);$status=M90\Api::dispatch('status',[],true);$check('custom profile without status cannot repair',!$status['success']&&$status['code']==='not_authorized');
  $policy['profile']='maintenance';C90\Persistence::put('connections','grant:'.$id,$policy);$status=M90\Api::dispatch('status',[],true);$check('maintenance profile allows status',$status['success']);
  $target=['connection_id'=>'privacy-grant0170','account_id'=>'7120','sender_id'=>'8120'];$privacy=M90\Messaging::privacyStatus($target);$request=$target+['expected_revision'=>$privacy['revision'],'idempotency_key'=>'privacy-grant-'.substr($id,0,20)];
  $policy['profile']='read';C90\Persistence::put('connections','grant:'.$id,$policy);$adsDenied=M90\Api::dispatch('save-ads-grant',['consumer_id'=>'qa-core','connection_id'=>'qa-ads','account_id'=>'130','expected_revision'=>0,'enabled'=>true],true);$check('read MCP profile cannot enable Ads reader grant',$adsDenied['code']==='not_authorized');$denied=M90\Result::run(static fn()=>M90\Messaging::eraseLocalData($request));$check('privacy erase rejects read transport profile',$denied['code']==='not_authorized');
  $policy['profile']='maintenance';C90\Persistence::put('connections','grant:'.$id,$policy);
  C90\Persistence::delete('oauth-grants',$id);$adsDenied=M90\Result::run(static fn()=>M90\AdsReader::save(['consumer_id'=>'qa-core','connection_id'=>'qa-ads','account_id'=>'130','expected_revision'=>0,'enabled'=>false]));$check('revoked MCP identity cannot create local Ads grant',$adsDenied['code']==='not_authorized');$denied=M90\Result::run(static fn()=>M90\Messaging::eraseLocalData($request));$check('revoked transport cannot fall back to local admin',$denied['code']==='not_authorized');
  C90\Persistence::put('oauth-grants',$id,['grant_id'=>$id,'user_id'=>$u,'client_id'=>'qa090','profile'=>'maintenance','status'=>'active']);$receipt=M90\Messaging::eraseLocalData($request);$check('active maintenance transport can erase locally',$receipt['state']==='erased');
  $liResult=wp_get_ability('linkedin/capabilities')->execute([]);$pdResult=wp_get_ability('pipedrive/status')->execute([]);
 }finally{foreach($keys as $key)C90\StateStore::delete('idempotency',$key);C90\Persistence::delete('connections','grant:'.$id);C90\Persistence::delete('oauth-grants',$id);C90\ConnectionContext::restore_identity($old,$u);remove_filter('pre_http_request',$h,1);remove_filter('pre_wp_mail',$m,1);}
 $check('original connection identity restored',C90\ConnectionContext::transport_identity()===$old);$check('no provider or email calls',$http===0&&$mail===0);
 $public=M90\Connections::public(['token'=>'synthetic-secret','client_secret'=>'synthetic-app-secret','token_identity'=>['subject_id'=>'901','subject_name'=>'QA Sistema','app_verified'=>true,'application_id'=>'123456789012345','application_name'=>'QA App','scopes'=>['read_insights'],'remote_expires_at'=>0]]);
 $safe=C90\SafeOutput::value($public);$check('public identity survives real MCP secret filter',($safe['identity']['subject_name']??null)==='QA Sistema'&&!isset($safe['token'],$safe['client_secret'])&&($safe['token_identity']??null)==='[redigido]');
 $preview=C90\SafeOutput::value(['confirmation'=>'synthetic-confirmation','identity'=>$public['identity']]);$check('identity switch preview and confirmation survive real MCP filter',$preview['confirmation']==='synthetic-confirmation'&&$preview['identity']['application_name']==='QA App');
 $check('new operation is discovered and declares read provider/write local',$a=wp_get_ability('meta/switch-identity')&&M90\Api::writes('switch-identity'));
 $li=wp_get_ability('linkedin/capabilities');$liVersion=is_array($liResult)?($liResult['version']??null):null;$check('current LinkedIn independently callable with matching loaded version',is_array($liResult)&&!empty($liResult['success'])&&$liVersion===\Fator3\LinkedIn\Config::VERSION);
 $expected=json_decode(file_get_contents(__DIR__.'/../companion-hashes0170.json'),true);$integrity=[];
 foreach($expected as $slug=>$files){
  $mismatches=[];foreach($files as $path=>$sha){$file=WP_PLUGIN_DIR.'/'.$slug.'/'.$path;if(!is_file($file)||hash_file('sha256',$file)!==$sha)$mismatches[]=$path;}$integrity[$slug]=['files'=>count($files),'mismatches'=>$mismatches];$check($slug.' matches provided runtime',!$mismatches);
 }
 $pd=wp_get_ability('pipedrive/status');$check('Pipedrive provider available without granting or sending',is_array($pdResult)&&($pdResult['code']??null)==='operacao_nao_autorizada'&&($pdResult['data']['registro_cliente']??null)==='registrado'&&($pdResult['data']['chamada_externa']??null)===false);
 $diag=C90\SafeOutput::value(['last_error'=>['http_status'=>403,'provider_code'=>200,'provider_subcode'=>33,'observed_at'=>1792874000]]);$check('MCP preserves measured collection diagnostic',$diag['last_error']['provider_subcode']===33&&$diag['last_error']['observed_at']===1792874000);
 $check('47 Meta operations, additive optional label',count(M90\Schemas::all())===47&&isset(M90\Schemas::all()['switch-identity']['properties']['label'])&&!in_array('label',M90\Schemas::all()['switch-identity']['required'],true));
 return ['version'=>M90\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),'integrity'=>$integrity,'pipedrive_status'=>$pdResult,'linkedin_observed_version'=>$liVersion,'callback_runs'=>$n,'http_calls'=>$http,'mail_calls'=>$mail,'retry_fixture'=>'ExecutionCoordinator::once with real Meta failure envelope and synthetic callback; no provider operation'];
}

$r=meta_companions090_cases();file_put_contents(getenv('F3_LAB_ROOT').'/evidence/integration0170.json',wp_json_encode($r));echo wp_json_encode($r);if($r['failed'])exit(1);
