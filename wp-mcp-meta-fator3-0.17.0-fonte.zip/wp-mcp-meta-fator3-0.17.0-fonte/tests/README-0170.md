# Verificação 0.17.0

O controlador tests/site/isolated0170-controller.php aceita somente operações fixas no host Site-Teste, vincula um bundle por SHA-256 e cria prefixo MySQL/diretório privados. Credenciais de banco permanecem no servidor. HTTP e e-mail reais são bloqueados nos subprocessos. Não instalar o controlador em produção nem incluí-lo no instalador.

Construir runtime com build/build.py; montar bundle com tools/build-isolated0170-probe.py --baseline <runtime 0.16.0> --candidate <runtime 0.17.0> --output <controlador temporário>. Rodar base 0.16.0 com budget-baseline0170, upgrade preservando estado, instalação limpa, budget0170, release0170, release0130 e review071. Integrar cópias verificadas dos cinco companheiros; executar integration0170, corefresh0170, coreads0170, coremonitor0170 e core3490170. Rodar instalação limpa também em WordPress 6.4/PHP 8.1.2 exato com pacotes oficiais pinados. Recolher evidências antes de cleanup e remover controlador e bundle do site.

As fixtures locais devem terminar com zero falhas. A reprodução da base confirma as falhas esperadas e é contabilizada como teste de reprodução, não como sucesso da candidata. Resultados efetivos e limitações estão no relatório e evidence. Suítes anteriores preservadas no fonte são histórico; não presumir que todas foram reexecutadas.
