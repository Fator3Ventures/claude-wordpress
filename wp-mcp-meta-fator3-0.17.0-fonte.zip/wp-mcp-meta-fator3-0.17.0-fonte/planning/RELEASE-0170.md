# Meta 0.17.0 — Pedido 25

30/10/2026, America/Sao_Paulo. Base Meta 0.16.0, instalador SHA-256 a49f3e8ae9e60814ab55cf1bd4b3277e859a477347d02f664353c1268fda0b6b. Alvo previsto 0.17.0; instalador ainda não gerado. Core 1.62.0, Google 0.24.0, MCP 0.37.0, LinkedIn 0.13.0 e Pipedrive 0.4.0 observados ativos no Site-Teste.

## Análise antes da implementação

Http mantém contador e prazo estáticos por execução PHP. Schedules consulta Ads::yesterday antes de inicializar orçamento próprio; pode herdar limite esgotado/expirado de outra fase. Não existe quota diária local por conta/conexão/agenda. Quota remota é um registro separado por conexão com Retry-After. A fila ordena jobs pelo vencimento, sem prioridade das agendas frente a retroativos antigos. O diagnóstico não expõe consumo/reposição e Worker não classifica bloqueio de orçamento por mais de 24 horas.

## Implementação e aceite previstos

Inicializar orçamento no despacho; limitar fases pelo prazo da passagem; reservar seleção prioritária às últimas coletas das agendas ativas, sem mudar banco ou checkpoints. Diagnóstico aditivo em health/list-schedules, erros e auditoria: limite, consumo, prazo, motivo de esgotamento, próxima execução estimada e quota remota separada. Persistir início do bloqueio por agenda; após 24 horas emitir incidente/e-mail técnico com deduplicação, sem envio pela leitura. Manter pausas explícitas, concessões, dados e retenção.

Reproduzir falha da base com orçamento herdado esgotado/expirado e fila vazia. Testar três agendas Ads com retroativos em curso, priorização fora das primeiras 20 entradas, checkpoints, permissões, quotas remotas, incidência/recuperação/deduplicação e corrida. Instalação limpa, atualização direta 0.16.0 e piso próprio; integração Core 1.62.0 para leitura de dado recém-coletado. Usar dados sintéticos em laboratório isolado, com HTTP/e-mail interceptados. Aceite em korvena.com.br e ctooffice permanece com a frota; nenhuma alteração de produção nesta rodada.

## Fronteiras

SDKs e 47 entradas públicas permanecem. Core passa a encontrar os dias coletados normalmente; não há adaptação exigida do consumidor. Não foi identificado novo pedido técnico a outro pacote; resultados e pendências de frota ficam no relatório, sem impacto de resposta/encerramento. Caso os testes revelem consequência nova, documentá-la antes de implementar a parte afetada. Normas r5 e instruções expressas do usuário sobre impactos prevalecem sobre r4 recebida.

## Resultado da rodada

Candidata final 0.17.0, instalador a360feff0bdb723c7f3c2a240b288bc1c3af917e851cb798d905e31a95b4162d. As provas e pendências estão no relatório próprio. Pipedrive passou de 0.4.0 para 0.5.0 por alteração externa durante os testes; a convivência foi repetida com a 0.5.0. Nenhum acompanhante foi alterado por esta rodada. Manter a regra do usuário: arquivos de impacto apresentam consequências técnicas e pedidos novos, nunca respostas ou encerramentos.
