# Fonte — Fator3 MCP Meta 0.17.0

Base direta 0.16.0; Pedido Meta 25. Código editável em build; build/build.py gera runtime, contratos, documentos e ZIP determinístico. Definir F3_SOCIAL_PHP para PHP CLI compatível. Lock local tools/build-runtime0160.json (PHP CLI 8.3.6). plugin contém runtime idêntico ao instalador final. Consulte planning/RELEASE-0170.md, tests/README-0170.md, evidence e relatório da rodada. Fontes/relatórios anteriores em history são históricos. Nada do laboratório integra o instalador.
