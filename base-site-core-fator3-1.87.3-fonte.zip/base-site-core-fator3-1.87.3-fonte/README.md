# Fonte do Fator3 Site Core 1.87.3

O runtime é work/plugin/base-site-core-fator3. Leia docs/RELEASE-1.87.3.md e docs/AGENTES-1.87.3.md nesse diretório. PLANO-1.87.3.md e reference/pedidos-407-412.md registram o escopo. As bases anteriores estão em history/1.86.0-runtime e history/1.87.0-runtime, e os resultados em evidence/1873. RELATORIO-PRE-FECHAMENTO.md é a cópia do relatório anterior ao fechamento do fonte.

## Reconstrução

```sh
python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.87.3-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.87.3-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.87.3-fonte.zip
```

Em WordPress local descartável, com o instalador ativo, rode wp eval-file tests/407-412.php como administrador. O ensaio usa opções temporárias e restaura as originais. O ensaio de memória precisa de um contato sintético e de 128 MiB. Os testes com nomes de releases anteriores preservam os critérios da versão que os originou.

## Histórico anterior à base suportada

A árvore da 1.86.0 e a da 1.87.0 estão expandidas. As 14 árvores de 1.74.0 a 1.85.1 foram preservadas em um arquivo tar.xz de fontes históricas, conferido arquivo por arquivo contra os manifestos. Para executar um ensaio dessas versões antigas, na raiz do fonte use `tar -xJf history/runtimes-1.74-a-1.85.1.tar.xz -C history`. A construção e os testes da 1.87.3 dispensam esse passo.
