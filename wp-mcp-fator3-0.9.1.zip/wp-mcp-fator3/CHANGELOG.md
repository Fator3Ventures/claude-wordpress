# Changelog

## 0.9.1 — 2026-09-08

- `plugins/delete`: carrega `wp-admin/includes/file.php` antes de acessar credenciais/filesystem; corrige a função indefinida herdada do Ultimate.
- Falta de credenciais e falhas de conexão devolvem erro estruturado sem emitir formulário FTP/SSH ou encerrar a requisição MCP. Sucesso exige retorno `true` do WordPress.
- Limpa o cache de plugins após excluir, evitando uma segunda exclusão com inventário desatualizado na mesma requisição.
- `files/read`: adiciona `tail_lines`, `offset`, `limit`, `grep` e `grep_regex`, com schemas expostos pelas metatools existentes.
- Leitura por blocos, inclusive do fim para o início, permite consultar logs acima do limite de leitura integral. Preserva linhas completas, LF/CRLF, a ordem original e o teto de bytes da resposta.
- Paginação informa `returned_lines`, `has_more` e `next_offset`; o hash parcial identifica seu escopo em `sha256_scope`.
- Chamadas apenas com `path` mantêm o contrato anterior. Slug, arquivo principal, endpoint, opções e autenticação preservados.

## 0.9.0 — 2026-09-08

- Plugin único, mantendo o slug e o arquivo principal Fator3 e incorporando Ultimate 2.1.0 no commit `d5eff50ff3d5609fa491dfb9af7946c261b00c89`.
- Migração de configurações, Application Passwords e dados OAuth antes do desinstalador do Ultimate; backups e opções Fator3 preservados.
- Compatibilidade temporária com o Ultimate ativo, seguida de carga autônoma depois da desativação.
- Arquivos sem confinamento de caminho por padrão; suporte a absolutos e `..`, filtros de raízes e constante `F3_MCP_FILES_CONFINE='wp'`.
- Proteção de autoedição, capacidades, kill-switch, constantes de bloqueio e sintaxe PHP preservados. Rejeição de raízes inválidas, wrappers e bytes nulos.
- Backup de exclusão preservado; restauração com integridade, sintaxe e backup do destino; falhas de backup e escritas incompletas impedem a operação.
- Correção de unslash em criação, atualização e patch de posts/páginas e nos campos auditados de mídia, comentários e usuários.
- Patch literal limitado de páginas trata `$1` e barras como texto literal.
- Painel único com aba de conexão, banner permanente de alcance e diagnóstico de registro MCP. Test Connection verifica as três ferramentas.
- Falta de uma classe de habilidades passa a gerar diagnóstico sem derrubar as outras rotas REST.
- Preservadas as melhorias dos PRs abertos #7, #9, #11 e #14 já integradas no upstream via #16, incluindo as correções posteriores aos patches originais.
- Auto-teste atualizado ao contrato 0.9.0 e regressões em WordPress nativo e com polyfill.

## Base anterior

O complemento fornecido é 0.8.0. Já aceitava qualquer extensão, possuía backups antes de exclusões e tinha as três rotas SQL com confirmação em duas fases. Essas funcionalidades foram mantidas.
