<?php
/** Local-only Ads archive SDK. Explicit per-consumer/account/dataset grants. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
use Fator3\McpGoogle\{Ads\OriginAd,Ads\AdsApi,Http\GoogleClient,Storage\Admission,Ability,Ads\Archive,Ads\ArchiveQuery,Ads\ArchiveStore,Audit,Auth\Credentials,Channel,Connections,Crypto,Options,Policy,Recovery,Response,Settings,Storage\State};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class AdsServiceApi {
    public const CONTRACT='google-ads-reader/1.0.0';
    public const VERSION='1.0.0';
    public const GRANTS='f3_mcp_google_ads_consumer_grants';
    private static array $consumers=[];
    public static function init(): void { add_action('plugins_loaded',[self::class,'discover'],32); }
    public static function discover(): void { do_action('f3_mcp_google_register_ads_consumers',new self(),self::CONTRACT); }
    public static function capabilities(): array { return ['contract'=>self::CONTRACT,'contract_version'=>self::VERSION,'plugin_version'=>F3_MCP_GOOGLE_VERSION,'registration_hook'=>'f3_mcp_google_register_ads_consumers','client_methods'=>['capabilities','status','query'],'datasets'=>ArchiveQuery::DATASETS,'extensions'=>['origin_ad'=>['contract'=>OriginAd::CONTRACT,'method'=>'origin_ad','remote_calls'=>true,'required_grant'=>'origin_ad','input_schema'=>OriginAd::schema(),'output_schema'=>OriginAd::output_schema()]],'source'=>'encrypted_local_archive','remote_calls'=>false,'retention_days'=>0,'limit_max'=>1000,'input_schema'=>self::schema(),'output_schema'=>self::output_schema()]; }
    public static function schema(): array { return ['type'=>'object','additionalProperties'=>false,'required'=>['contract_version','connection_id','account_id','dataset','date','consumer_revision'],'properties'=>['contract_version'=>['type'=>'string','enum'=>[self::VERSION]],'connection_id'=>['type'=>'string'],'account_id'=>['type'=>'string','pattern'=>'^[0-9]{10}$'],'dataset'=>['type'=>'string','enum'=>ArchiveQuery::DATASETS],'date'=>['type'=>'string','pattern'=>'^\\d{4}-\\d{2}-\\d{2}$'],'consumer_revision'=>['type'=>'string','minLength'=>1,'maxLength'=>128],'limit'=>['type'=>'integer','minimum'=>1,'maximum'=>1000,'default'=>500],'cursor'=>['type'=>'string','maxLength'=>4096]]]; }
    public static function output_schema(): array {
        return ['type'=>'object','properties'=>[
            'success'=>['type'=>'boolean'],'message'=>['type'=>'string'],'error_code'=>['type'=>'string'],
            'contract_version'=>['type'=>'string','enum'=>[self::VERSION]],'connection_id'=>['type'=>'string'],
            'account_id'=>['type'=>'string'],'dataset'=>['type'=>'string','enum'=>ArchiveQuery::DATASETS],'date'=>['type'=>'string'],
            'currency'=>['type'=>'string'],'time_zone'=>['type'=>'string'],'revision'=>['type'=>['string','null']],
            'extracted_at'=>['type'=>'integer'],'rows'=>['type'=>'array','items'=>['type'=>'object']],
            'next_cursor'=>['type'=>['string','null']],'remote_dispatched'=>['type'=>'boolean'],
            'coverage'=>['type'=>'object','properties'=>[
                'archive_state'=>['type'=>'string','enum'=>['not_collected','incomplete','published','partial','revisiting']],
                'latest_collection_state'=>['type'=>['string','null']],'latest_collection_revision'=>['type'=>['string','null']],
                'latest_collection_truncated'=>['type'=>'boolean'],'previous_complete_preserved'=>['type'=>'boolean'],
                'archived'=>['type'=>'boolean'],'archive_rows'=>['type'=>'integer'],'returned_rows'=>['type'=>'integer'],
                'start_row'=>['type'=>'integer'],'local_pagination_complete'=>['type'=>'boolean'],
                'pagination_complete'=>['type'=>'boolean'],'truncated'=>['type'=>'boolean'],
                'truncation_reason'=>['type'=>['string','null']],'all_rows_guaranteed'=>['type'=>'boolean'],
                'search_term_per_click'=>['type'=>'boolean'],'api_omissions_possible'=>['type'=>'boolean'],'source'=>['type'=>'string']]]]];
    }
    public static function register_consumer(string $id,string $version,string $contract,callable $configuration) {
        if($contract!==self::CONTRACT||!preg_match('/^[a-z][a-z0-9-]{1,79}$/D',$id)||!preg_match('/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/D',$version))return new \WP_Error('f3_google_consumer_contract','Identidade, versão ou contrato incompatível.');
        if(isset(self::$consumers[$id]))return new \WP_Error('f3_google_consumer_duplicate','Consumidor já registrado.');
        $client=new AdsConsumerClient();self::$consumers[$id]=['id'=>$id,'version'=>$version,'configuration'=>$configuration,'client'=>$client];return $client;
    }
    private static function config(array $c) {
        try{$cfg=($c['configuration'])();}catch(\Throwable $e){return new \WP_Error('f3_google_consumer_configuration','Callback indisponível.');}
        if(!is_array($cfg)||($cfg['ready']??null)!==true||!is_array($cfg['account_ids']??null)||!is_string($cfg['revision']??null)||strlen($cfg['revision'])<1||strlen($cfg['revision'])>128)return new \WP_Error('f3_google_consumer_configuration','Callback exige account_ids, revision e ready.');
        foreach($cfg['account_ids'] as $a)if(!is_string($a)||!preg_match('/^[0-9]{10}$/D',$a))return new \WP_Error('f3_google_consumer_configuration','Conta inválida no consumidor.');
        return array_intersect_key($cfg,array_flip(['account_ids','revision','ready']));
    }
    private static function find(AdsConsumerClient $client): ?array { foreach(self::$consumers as $c)if($c['client']===$client)return $c;return null; }
    public static function grants() { $r=Options::stored(Options::storage_name(self::GRANTS));return !$r['success']||($r['exists']&&!is_array($r['value']))?new \WP_Error('f3_google_consumer_grants_read','Concessões ilegíveis.'):($r['value']??[]); }
    private static function guard(array $c,array $cfg,string $account,string $dataset,array $grant): ?\WP_Error {
        if($e=Recovery::guard()??State::guard())return $e;
        $all=self::grants();if(is_wp_error($all))return $all;
        if(($all[$c['id'].'|'.$account]??null)!==$grant||empty($grant['enabled'])||!in_array($dataset,$grant['datasets']??[],true)||!Options::is_enabled())return new \WP_Error('f3_google_consumer_unauthorized','Leitura do acervo sem concessão vigente.');
        if(!Options::user_authorized((int)($grant['granted_by']??0))||($grant['principal']??'')!==Credentials::execution_identity()||!Policy::permitted('ads',$account))return new \WP_Error('f3_google_consumer_unauthorized','Administrador, identidade ou política mudou.');
        $now=self::config($c);if(is_wp_error($now))return $now;
        if($now!==$cfg||$grant['consumer_revision']!==$cfg['revision']||!in_array($account,$cfg['account_ids'],true))return new \WP_Error('f3_google_consumer_changed','Configuração do consumidor mudou; reautorize o acervo.');
        return null;
    }
    public static function configure(array $i): array {
        if(!Options::authorized())return Archive::fail('forbidden','Permissão administrativa exigida.');
        $id=$i['consumer_id']??'';$account=$i['account_id']??'';$enabled=$i['enabled']??null;$datasets=$i['datasets']??[];
        if(!is_string($id)||!isset(self::$consumers[$id])||!is_string($account)||!preg_match('/^[0-9]{10}$/D',$account)||!is_bool($enabled)||!is_string($i['expected_revision']??null)||!is_array($datasets)||count(array_filter($datasets,'is_string'))!==count($datasets)||($enabled&&!$datasets)||array_diff($datasets,ArchiveQuery::DATASETS))return Archive::fail('input','Consumidor registrado, conta, datasets, enabled e revisão são obrigatórios.');
        if (array_key_exists('origin_ad',$i) && !is_bool($i['origin_ad'])) { return Archive::fail('input','origin_ad exige valor booleano.'); }
        $cfg=self::config(self::$consumers[$id]);if($enabled&&(is_wp_error($cfg)||!in_array($account,$cfg['account_ids'],true)))return Archive::fail('consumer','Conta não selecionada no consumidor.');
        if($enabled&&(!Policy::permitted('ads',$account)||!Credentials::is_configured()))return Archive::fail('authorization','Credencial e política devem permitir a conta.');
        $all=self::grants();if(is_wp_error($all))return Response::fail($all);
        $key=$id.'|'.$account;
        $grant=['enabled'=>$enabled,'datasets'=>array_values(array_unique($datasets)),'account_id'=>$account,'principal'=>Credentials::execution_identity(),'granted_by'=>get_current_user_id(),'consumer_revision'=>is_array($cfg)?$cfg['revision']:''];
        $prior=$all[$key]??[];
        // A legacy update may narrow or revoke rights, never add a remote grant.
        $same_authority=($prior['consumer_revision']??null)===$grant['consumer_revision'] && ($prior['principal']??null)===$grant['principal'] && ($prior['granted_by']??null)===$grant['granted_by'];
        $origin=$enabled && in_array('clicks',$datasets,true) && ($i['origin_ad']??($same_authority && !empty($prior['origin_ad'])));
        if (!empty($i['origin_ad']) && !$origin) { return Archive::fail('input','Para autorizar anúncios de origem, ative o leitor e selecione Cliques.'); }
        if ($origin) { $grant['origin_ad']=true; }
        if(array_diff_key($prior,['revision'=>true,'at'=>true])!==$grant)$grant+=['revision'=>bin2hex(random_bytes(16)),'at'=>time()];else $grant=$prior;
        $all[$key]=$grant;
        return Settings::save([self::GRANTS=>$all],[],[],$i['expected_revision'],null,static function()use($enabled,$id,$cfg){return $enabled&&self::config(self::$consumers[$id])!==$cfg?new \WP_Error('f3_google_consumer_changed','Configuração do consumidor mudou antes da concessão.'):null;})+['integration'=>self::status()];
    }
    public static function status(?string $only=null): array {
        $all=self::grants();$items=[];
        foreach(self::$consumers as $id=>$c){if($only!==null&&$only!==$id)continue;$cfg=self::config($c);$grants=[];
            if(is_array($all))foreach($all as $key=>$g)if(str_starts_with($key,$id.'|'))$grants[]=array_intersect_key($g,array_flip(['enabled','account_id','datasets','origin_ad','revision','at']));
            $items[]=['id'=>$id,'version'=>$c['version'],'configuration'=>is_wp_error($cfg)?['ready'=>false,'error_code'=>$cfg->get_error_code()]:$cfg,'grants'=>$grants];
        }
        return ['contract'=>self::CONTRACT,'connection_id'=>Connections::id(),'consumers'=>$items,'grants_error'=>is_wp_error($all)?$all->get_error_code():null,'remote_calls'=>false];
    }
    public static function client_status(AdsConsumerClient $client): array { $c=self::find($client);return $c?self::status($c['id']):Archive::fail('consumer','Cliente não registrado.'); }
    public static function query(AdsConsumerClient $client,array $i): array {
        $c=self::find($client);if(!$c)return Archive::fail('consumer','Cliente não registrado.');
        $schema=self::schema();
        if(array_diff(array_keys($i),array_keys($schema['properties']))||array_diff($schema['required'],array_keys($i))||($i['contract_version']??'')!==self::VERSION)return Archive::fail('input','Contrato ou parâmetros inválidos.');
        foreach(['connection_id','account_id','dataset','date','consumer_revision'] as $k)if(!is_string($i[$k]))return Archive::fail('input','Tipo de parâmetro inválido.');
        $limit=$i['limit']??500;
        if(!preg_match('/^[0-9]{10}$/D',$i['account_id'])||!in_array($i['dataset'],ArchiveQuery::DATASETS,true)||!ArchiveQuery::valid_date($i['date'])||!is_int($limit)||$limit<1||$limit>1000||isset($i['cursor'])&&(!is_string($i['cursor'])||strlen($i['cursor'])>4096))return Archive::fail('input','Recorte, limite ou cursor inválido.');
        return Connections::run($i['connection_id'],static function()use($c,$i,$limit){
            $cfg=self::config($c);if(is_wp_error($cfg))return Response::fail($cfg);
            if($cfg['revision']!==$i['consumer_revision'])return Archive::fail('revision','Revisão do consumidor mudou.');
            $all=self::grants();if(is_wp_error($all))return Response::fail($all);$grant=$all[$c['id'].'|'.$i['account_id']]??[];
            if($e=self::guard($c,$cfg,$i['account_id'],$i['dataset'],$grant))return Response::fail($e);
            $m=ArchiveStore::latest($i['account_id'],$i['dataset'],$i['date']);if(is_wp_error($m))return Response::fail($m);
            $job=ArchiveStore::get('adsjob',ArchiveStore::key($i['account_id'],$i['dataset'],$i['date']));if(is_wp_error($job))return Response::fail($job);
            $newer=is_array($m)&&is_array($job)&&$m['revision']!==$job['revision'];
            $collection=['archive_state'=>$m===null?($job?'incomplete':'not_collected'):($newer&&$job['state']!=='complete'?'revisiting':(!empty($m['coverage']['truncated'])?'partial':'published')),
                'latest_collection_state'=>$job['state']??null,'latest_collection_revision'=>$job['revision']??null,
                'latest_collection_truncated'=>!empty($job['truncated']),'previous_complete_preserved'=>$newer&&$job['state']==='complete'&&!empty($job['truncated'])];
            if($e=self::guard($c,$cfg,$i['account_id'],$i['dataset'],$grant))return Response::fail($e);
            if($m===null)return Response::ok(['contract_version'=>self::VERSION,'rows'=>[],'next_cursor'=>null,'revision'=>null,'coverage'=>$collection+['archived'=>false,'pagination_complete'=>false,'truncated'=>false,'all_rows_guaranteed'=>false],'remote_dispatched'=>false]);
            $binding=[$c['id'],Connections::id(),$i['account_id'],$i['dataset'],$i['date'],$cfg['revision'],$grant['revision'],$m['revision'],$limit];$offset=0;
            if(!empty($i['cursor'])){$plain=Crypto::decrypt($i['cursor']);$cursor=is_string($plain)?json_decode($plain,true):null;if(!is_array($cursor)||($cursor['binding']??null)!==$binding||($cursor['expires']??0)<time()||!is_int($cursor['offset']??null)||$cursor['offset']<0||$cursor['offset']>$m['rows'])return Archive::fail('cursor','Cursor expirado ou de outra conta, concessão ou revisão.');$offset=$cursor['offset'];}
            $rows=ArchiveStore::page($m,$offset,$limit);if(is_wp_error($rows))return Response::fail($rows);
            if($e=self::guard($c,$cfg,$i['account_id'],$i['dataset'],$grant))return Response::fail($e);
            $latest=ArchiveStore::latest($i['account_id'],$i['dataset'],$i['date']);if(!is_array($latest)||$latest['revision']!==$m['revision'])return Archive::fail('revision','Uma revisita mudou o recorte. Reinicie a leitura.');
            $next=null;$end=$offset+count($rows);if($end<$m['rows']){$next=Crypto::encrypt(wp_json_encode(['binding'=>$binding,'offset'=>$end,'expires'=>time()+86400]));if(!$next)return Archive::fail('crypto','Falha ao criar cursor.');}
            $ctx=['actor'=>['type'=>'plugin','id'=>$c['id'],'version'=>$c['version']],'run_id'=>'ads-reader-'.bin2hex(random_bytes(8)),'trigger'=>PHP_SAPI==='cli'?'cli':'manual','request_id'=>\Fator3\McpGoogle\Records::id(),'property'=>$i['account_id'],'consumer_revision'=>$cfg['revision']];
            $audit=Context::run($ctx,static fn()=>Audit::append('plugin:ads.archive.read',$i['account_id'],['mode'=>'read','status'=>'completed','dataset'=>$i['dataset'],'date'=>$i['date'],'rows'=>count($rows)]));if(empty($audit['success']))return Archive::fail('audit','Auditoria não confirmada; não avance o cursor.');
            return Response::ok(['contract_version'=>self::VERSION,'connection_id'=>Connections::id(),'account_id'=>$i['account_id'],'dataset'=>$i['dataset'],'date'=>$i['date'],'currency'=>$m['currency'],'time_zone'=>$m['time_zone'],'revision'=>$m['revision'],'extracted_at'=>$m['extracted_at'],'rows'=>$rows,'next_cursor'=>$next,'coverage'=>$collection+$m['coverage']+['archived'=>true,'archive_rows'=>$m['rows'],'returned_rows'=>count($rows),'start_row'=>$offset,'local_pagination_complete'=>$next===null],'remote_dispatched'=>false]);
        });
    }
    /** The registered object's identity and the current grant bind every provider read. */
    public static function origin_ad(AdsConsumerClient $client,array $i): array {
        $consumer=self::find($client);
        if (!$consumer) { return Archive::fail('consumer','Cliente não registrado.'); }
        if (!OriginAd::valid($i)) { return Archive::fail('input','Informe o contrato, a seleção do leitor e exatamente um localizador válido.'); }
        return Connections::run($i['connection_id'],static function() use($consumer,$i) {
            $account=$i['account_id'];
            $cfg=self::config($consumer);
            if (is_wp_error($cfg)) { return Response::fail($cfg); }
            $all=self::grants();
            if (is_wp_error($all)) { return Response::fail($all); }
            $grant=$all[$consumer['id'].'|'.$account]??[];
            if ($cfg['revision']!==$i['consumer_revision'] || empty($grant['origin_ad'])) { return Archive::fail('authorization','Autorize a consulta do anúncio de origem para a seleção atual.'); }
            $revision=Settings::execution_revision();
            if (is_wp_error($revision)) { return Response::fail($revision); }
            $guard=static function() use($consumer,$cfg,$account,$grant,$revision) {
                if ($error=self::guard($consumer,$cfg,$account,'clicks',$grant)) { return $error; }
                if (!Options::ads_enabled() || !Connections::enabled('ads') || Settings::execution_revision()!==$revision) {
                    return new \WP_Error('f3_google_origin_changed','O acesso ao Google Ads mudou. Repita a leitura.');
                }
                return null;
            };
            if ($error=$guard()) { return Response::fail($error); }
            $ctx=['contract'=>OriginAd::CONTRACT,'actor'=>['type'=>'plugin','id'=>$consumer['id'],'version'=>$consumer['version']],
                'run_id'=>'origin-'.bin2hex(random_bytes(8)),'trigger'=>'manual','request_id'=>\Fator3\McpGoogle\Records::id(),
                'property'=>$account,'consumer_revision'=>$cfg['revision'],'http_attempts'=>0,'body'=>null,'guard'=>$guard];
            return Admission::run('ads:origin.read',static fn()=>Context::run($ctx,static function() use($ctx,$i,$account,$guard) {
                $search=static function(string $query) use($ctx,$account,$guard) {
                    if ($error=$guard()) { return $error; }
                    $body=['query'=>$query];
                    $scoped=array_replace($ctx,['body'=>$body]);
                    return Context::run($scoped,static fn()=>GoogleClient::post(AdsApi::base().'/customers/'.$account.'/googleAds:search',$body,AdsApi::request_opts()+['retries'=>0]));
                };
                $result=OriginAd::resolve($i,$search);
                if ($error=$guard()) { return Response::fail($error); }
                $audit=Audit::append('plugin:ads.origin.read',$account,['mode'=>'read','status'=>$result['state']??'failed']);
                if (empty($audit['success'])) { return Archive::fail('audit','Auditoria da consulta não confirmada.'); }
                return $result+['contract'=>OriginAd::CONTRACT,'account_id'=>$account,'connection_id'=>Connections::id()];
            }));
        });
    }
    public static function register(): void {
        Ability::register('ads/archive-consumer-grant','any',['label'=>'Google Ads: autorizar leitor do acervo','description'=>'Autoriza o acervo local por consumidor e conta. Com clicks e origin_ad, autoriza também a consulta do criativo ao Google.','mode'=>'write','input_schema'=>['required'=>['consumer_id','account_id','enabled','expected_revision'],'properties'=>['consumer_id'=>['type'=>'string'],'account_id'=>['type'=>'string','pattern'=>'^[0-9]{10}$'],'enabled'=>['type'=>'boolean'],'expected_revision'=>['type'=>'string'],'origin_ad'=>['type'=>'boolean','description'=>'Consultar o criativo da conta no Google Ads. Exige leitor ativo e clicks.'],'datasets'=>['type'=>'array','uniqueItems'=>true,'items'=>['type'=>'string','enum'=>ArchiveQuery::DATASETS]]]],'output_schema'=>Archive::output_schema(),'callback'=>[self::class,'configure']]);
    }
}
