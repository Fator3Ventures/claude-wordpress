<?php
/** Query × page × day; separate registration, grant and cursor from GSC 1.0. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
use Fator3\McpGoogle\{Auth\Credentials,Options};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class QueryServiceApi extends ServiceApi {
    public const CONTRACT='search-console-reader/1.1.0';
    public const VERSION='1.1.0';
    public const CAPABILITY='gsc.query-page-day.read';
    public const GRANTS='f3_mcp_google_query_consumer_grants';
    protected static array $consumers=[];
    public static function capabilities(): array {
        return parent::capabilities()+['dimensions'=>['date','page','query'],'anonymous_queries_excluded'=>true,
            'pagination_end'=>'empty API page; 50000 rows/day/type may truncate',
            'coverage_fields'=>['returned_rows','start_row','rows_accumulated','pagination_complete','truncated','truncation_reason','anonymous_queries_excluded','anonymous_query_clicks','anonymous_query_count','anonymous_counts_reason','all_rows_guaranteed']];
    }
    protected static function dimensions(): array { return ['date','page','query']; }
    // An empty final page is observable, including at the documented 50k ceiling.
    protected static function more(int $count,int $limit,int $start): bool { return $count>0 && $start+$count<=50000; }
    protected static function coverage(array $coverage): array {
        $total=$coverage['start_row']+$coverage['returned_rows'];
        $pending=$coverage['returned_rows']>0 && $total<=50000;
        return array_replace($coverage,[
            'rows_accumulated'=>$total,'pagination_complete'=>!$pending,
            'truncated'=>$pending||$total>=50000,
            'truncation_reason'=>$total>=50000?'api_daily_row_limit':($pending?'page_pending':null),
            'anonymous_queries_excluded'=>true,'anonymous_query_clicks'=>null,
            'anonymous_query_count'=>null,'anonymous_counts_reason'=>'not_exposed_by_api',
            'coverage_note'=>'Consultas anonimizadas são omitidas. A diferença para page-day também pode incluir limites de linhas e agregação; não é contagem exata de anonimização.',
        ]);
    }
    protected static function new_grant(string $id,bool $enabled) {
        $cfg=static::config(static::$consumers[$id]);
        if($enabled&&is_wp_error($cfg))return $cfg;
        return parent::new_grant($id,$enabled)+['property'=>is_array($cfg)?$cfg['property']:null,'principal'=>Credentials::execution_identity(),'granted_by'=>get_current_user_id()];
    }
    protected static function guard(array $consumer,array $configuration,string $revision,array $grant): ?\WP_Error {
        $error=parent::guard($consumer,$configuration,$revision,$grant);
        if($error)return $error;
        return ($grant['property']??null)!==$configuration['property'] || ($grant['principal']??null)!==Credentials::execution_identity() || !Options::user_authorized((int)($grant['granted_by']??0))
            ? new \WP_Error('f3_google_consumer_unauthorized','Reautorize a propriedade, identidade ou administrador do leitor de consultas.') : null;
    }
}
