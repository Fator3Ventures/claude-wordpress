<?php
/**
 * Opt-in operational incidents. Transport acceptance is not delivery confirmation.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Ability, Audit, Connections, Lock, Options, Records, Response, Settings
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Alerts {
    public const OPTION = 'f3_mcp_google_alerts';
    public const EVENTS = array( 'access', 'cron_late', 'sitemap_error', 'scheduled_check' );
    public const MAX_RECIPIENTS = 10;
    public const MIN_INTERVAL = 60;
    public const MAX_INTERVAL = 604800;
    public static function schema(): array {
        return array(
            'type' => 'object',
            'additionalProperties' => false,
            'properties' => array(
                'enabled' => array(
                    'type' => 'boolean',
                    'default' => false,
                ),
                'email_enabled' => array(
                    'type' => 'boolean',
                    'default' => false,
                    'description' => 'Exige ao menos um destinatário válido.',
                ),
                'recipients' => array(
                    'type' => 'array',
                    'maxItems' => self::MAX_RECIPIENTS,
                    'items' => array(
                        'type' => 'string',
                        'format' => 'email',
                    ),
                ),
                'events' => array(
                    'type' => 'array',
                    'items' => array(
                        'type' => 'string',
                        'enum' => self::EVENTS,
                    ),
                    'uniqueItems' => true,
                ),
                'minimum_interval' => array(
                    'type' => 'integer',
                    'minimum' => self::MIN_INTERVAL,
                    'maximum' => self::MAX_INTERVAL,
                    'default' => 3600,
                ),
            ),
        );
    }
    private static function slack_url(string $url): bool {
        return preg_match('~^https://hooks\.slack\.com/services/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+$~D', $url) === 1;
    }

    public static function save_slack(string $url, bool $clear, ?string $revision): array {
        if (!Options::authorized()) { return Response::fail(new \WP_Error('f3_google_forbidden','Permissão administrativa exigida.')); }
        if ($revision === null) { return Settings::conflict(); }
        if (($clear && $url !== '') || ($url !== '' && !self::slack_url($url))) {
            return Response::fail(new \WP_Error('f3_google_slack_destination','Informe um Incoming Webhook de hooks.slack.com ou marque a remoção.'));
        }
        return Settings::save([], $url === '' ? [] : [Options::INCIDENT_WEBHOOK=>$url], $clear ? [Options::INCIDENT_WEBHOOK] : [], $revision);
    }

    /** Reserve the incident before external I/O. Never repeat an ambiguous delivery. */
    public static function channel_blocked(array $job, ?string $reason): void {
        if (!in_array($reason,['f3_google_channel_revoked','f3_google_channel_changed'],true) || ($job['status'] ?? '') !== 'blocked') { return; }
        if (Connections::id() !== $job['connection_id']) {
            Connections::run($job['connection_id'], static function () use ($job,$reason) { self::channel_blocked($job,$reason); });
            return;
        }
        $resource = 'job/' . $job['id'];
        $id = hash('sha256', $job['connection_id'].'|channel|'.$resource);
        $now = time();
        $action = 'Revise a tarefa em Ferramentas → Fator3 MCP Google → Avançado → Tarefas e agendas. Crie uma nova intenção pela rota google/create-job.';
        $entry = ['id'=>$id,'connection_id'=>$job['connection_id'],'event'=>'channel','resource'=>$resource,
            'status'=>'open','code'=>$reason,'action'=>$action,'created_at'=>$now,'updated_at'=>$now,
            'generation'=>1,'email_state'=>'dispatching','slack_state'=>'dispatching','task'=>'channel_notice','run_after'=>0,
            'last_notified_at'=>0,'next_notification_at'=>0];
        if (!Records::insert('incident',$id,$entry)) { return; }
        $title = 'Fator3 MCP Google — tarefa bloqueada';
        $body = home_url().' · Conexão '.$job['connection_id']."\n".$resource.' · '.$reason."\nDesde ".gmdate('Y-m-d H:i:s',$now)." UTC\n".$action;
        $email = (string)get_option('admin_email');
        try {
            $entry['email_state'] = is_email($email) ? (wp_mail($email,$title,$body) ? 'accepted' : 'failed') : 'not_configured';
        } catch (\Throwable $error) { $entry['email_state']='unknown'; }
        $url = Options::get_secret(Options::INCIDENT_WEBHOOK);
        $entry['slack_state'] = 'not_configured';
        if (self::slack_url($url)) {
            try {
                $response = wp_safe_remote_post($url,['timeout'=>5,'redirection'=>0,'headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode(['text'=>$title."\n".$body])]);
                $entry['slack_state'] = is_wp_error($response) ? 'unknown' : (wp_remote_retrieve_response_code($response) === 200 && trim(wp_remote_retrieve_body($response)) === 'ok' ? 'accepted' : 'failed');
            } catch (\Throwable $error) { $entry['slack_state']='unknown'; }
        }
        $entry['last_notified_at']=$now;
        Records::put('incident',$id,$entry);
    }

    public static function close_channel_incident(array $job): void {
        if (!in_array($job['blocked_reason'] ?? '', ['f3_google_channel_changed','f3_google_channel_revoked'], true)) { return; }
        $id = hash('sha256', $job['connection_id'].'|channel|job/'.$job['id']);
        $row = Records::get('incident',$id);
        if ($row && $row['status'] === 'open') {
            $row['status']='resolved';
            $row['updated_at']=time();
            Records::put('incident',$id,$row);
        }
    }

    public static function config(): array {
        return (array) Options::get(
            self::OPTION,
            array(
                'enabled' => false,
                'email_enabled' => false,
                'recipients' => array(),
                'events' => self::EVENTS,
                'minimum_interval' => 3600,
            )
        );
    }
    public static function configure( array $input ): array {
        $v = $input['configuration'] ?? null;
        if ( ! is_array( $v ) || array_diff( array_keys( $v ), array( 'enabled', 'email_enabled', 'recipients', 'events', 'minimum_interval' ) ) ) {
            return Response::fail( new \WP_Error( 'f3_google_alert_input', 'Configuração de alertas inválida.' ) );
        }
        $v = array_merge( self::config(), $v );
        if ( ! is_bool( $v['enabled'] ) || ! is_bool( $v['email_enabled'] ) || ! is_array( $v['recipients'] ) || count( $v['recipients'] ) > self::MAX_RECIPIENTS || ! is_array( $v['events'] ) || array_diff( $v['events'], self::EVENTS ) || ! is_int( $v['minimum_interval'] ) || $v['minimum_interval'] < self::MIN_INTERVAL || $v['minimum_interval'] > self::MAX_INTERVAL ) {
            return Response::fail( new \WP_Error( 'f3_google_alert_input', 'Confira tipos, eventos e intervalo de 60–604800 segundos.' ) );
        }
        foreach ( $v['recipients'] as $email ) {
            if ( ! is_string( $email ) || ! is_email( $email ) ) {
                return Response::fail( new \WP_Error( 'f3_google_alert_recipient', 'E-mail inválido.' ) );
            }
        }
        if ( $v['email_enabled'] && ! $v['recipients'] ) {
            return Response::fail( new \WP_Error( 'f3_google_alert_recipient', 'Configure destinatários antes de ativar e-mail.' ) );
        }
        return Settings::save( array( self::OPTION => $v ), array(), array(), $input['expected_revision'] ?? null );
    }
    public static function observe( string $event, string $resource_id, bool $failed, string $code, string $action ): void {
        if ( \Fator3\McpGoogle\Confirmation::capturing() ) {
            return;
        }
        $config = self::config();
        if ( empty( $config['enabled'] ) || ! in_array( $event, $config['events'], true ) ) {
            return;
        }
        $id = hash( 'sha256', Connections::id() . '|' . $event . '|' . $resource_id );
        $lock = Lock::acquire( 'incident:' . $id, 60 );
        if ( null === $lock ) {
            return;
        }
        try {
            $old = Records::get( 'incident', $id );
            if ( null === $old && ! $failed ) {
                return;
            }
            $state = $failed ? 'open' : 'resolved';
            if ( $old && $old['status'] === $state ) {
                return;
            }
            $incident = array(
                'id' => $id,
                'connection_id' => Connections::id(),
                'event' => $event,
                'resource' => substr( $resource_id, 0, 512 ),
                'status' => $state,
                'code' => $code,
                'action' => $action,
                'created_at' => $old['created_at'] ?? time(),
                'updated_at' => time(),
                'generation' => ( $old['generation'] ?? 0 ) + 1,
                'email_state' => empty( $config['email_enabled'] ) ? 'disabled' : 'pending',
                'last_notified_at' => $old['last_notified_at'] ?? 0,
                'next_notification_at' => max( time(), ( $old['last_notified_at'] ?? 0 ) + $config['minimum_interval'] ),
            );
            $incident['task'] = 'pending' === $incident['email_state'] ? 'notify_pending' : 'notify_disabled';
            $incident['run_after'] = $incident['next_notification_at'];
            $saved = Records::put( 'incident', $id, $incident );
            if ( ! $saved['success'] ) {
                return;
            }
        }
        catch ( \Throwable $e ) {
            \Fator3\McpGoogle\Cache::set( 'f3_mcp_google_alert_error_' . Connections::id(), time(), 86400 );
        }
        finally {
            Lock::release( $lock );
        }
    }
    private static function send( array $incident, array $config ): void {
        $attempt_id = $incident['id'] . '_' . $incident['generation'];
        $attempt = array(
            'status' => 'dispatching',
            'created_at' => time(),
            'incident_id' => $incident['id'],
            'generation' => $incident['generation'],
        );
        if ( ! Records::insert( 'mail', $attempt_id, $attempt ) ) {
            $prior = Records::get( 'mail', $attempt_id );
            $incident['email_state'] = 'dispatching' === ( $prior['status'] ?? '' ) ? 'unknown' : ( $prior['status'] ?? 'unknown' );
            $incident['task'] = 'notify_' . $incident['email_state'];
            Records::put( 'incident', $incident['id'], $incident );
            return;
        }
        $subject = 'Google: ' . $incident['event'] . ' — ' . $incident['status'];
        $body = 'Site: ' . home_url() . "\nConexão: " . $incident['connection_id'] . "\nRecurso: " . $incident['resource'] . "\nCódigo: " . $incident['code'] . "\nAção: " . $incident['action'];
        try {
            $accepted = wp_mail( $config['recipients'], $subject, Audit::redact( $body ) );
            $attempt['status'] = $accepted ? 'accepted' : 'failed';
        }
        catch ( \Throwable $e ) {
            $attempt['status'] = 'unknown';
        }
        $saved = Records::put( 'mail', $attempt_id, $attempt );
        $incident['email_state'] = $saved['success'] ? $attempt['status'] : 'unknown';
        $incident['last_notified_at'] = time();
        $incident['task'] = 'notify_' . $incident['email_state'];
        Records::put( 'incident', $incident['id'], $incident );
    }
    public static function dispatch(): int {
        $count=0;
        $config = self::config();
        if ( empty( $config['enabled'] ) || empty( $config['email_enabled'] ) ) {
            return 0;
        }
        $page = self::state(
            array(
                'dispatch' => true,
                'limit' => 100,
            )
        );
        if ( empty( $page['available'] ) ) {
            return 0;
        }
        foreach ( $page['incidents'] as $incident ) {
            if ( Execution::active() && Execution::remaining() < 2 ) {
                break;
            }
            if ( 'pending' !== ( $incident['email_state'] ?? '' ) || ( $incident['next_notification_at'] ?? 0 ) > time() ) {
                continue;
            }
            $lock = Lock::acquire( 'incident:' . $incident['id'], 60 );
            if ( null === $lock ) {
                continue;
            }
            try {
                $current = Records::get( 'incident', $incident['id'] );
                if ( $current && 'pending' === $current['email_state'] && ( $current['next_notification_at'] ?? 0 ) <= time() ) {
                    $config = self::config();
                    if ( ! empty( $config['enabled'] ) && ! empty( $config['email_enabled'] ) && in_array( $current['event'], $config['events'], true ) ) {
                        self::send( $current, $config );
                        ++$count;
                    }
                }
            }
            finally {
                Lock::release( $lock );
            }
        }
        return $count;
    }
    public static function result( string $event, string $resource_id, array $result ): void {
        if ( \Fator3\McpGoogle\Confirmation::capturing() ) {
            return;
        }
        $failed = empty( $result['success'] ) || false === ( $result['all_checks_passed'] ?? true );
        self::observe( $event, $resource_id, $failed, $result['error_code'] ?? ( $failed ? 'check_failed' : 'recovered' ), 'Consultar diagnóstico e conferir o recurso antes de repetir alterações.' );
    }
    /** The optional internal filter selects open incidents before pagination for readiness. */
    public static function state( array $input = array(), bool $open_only = false ): array {
        $out = array();
        $limit = max( 1, min( 100, (int) ( $input['limit'] ?? 30 ) ) );
        $offset = max( 0, (int) ( $input['offset'] ?? 0 ) );
        $base = array(
            'configuration' => self::config(),
            'transport_acceptance_is_delivery' => false,
            'self_monitoring_limit' => 'Se o executor do site parar, o próprio site não garante emitir alerta. Monitor externo deve consultar o status.',
        );
        try {
            $filters = array( 'connection_id' => Connections::id() );
            if ( $open_only ) {
                $filters['state'] = 'open';
            }
            if ( ! empty( $input['dispatch'] ) ) {
                $filters += array(
                    'task' => 'notify_pending',
                    'due_before' => time(),
                );
            }
            $rows = \Fator3\McpGoogle\Storage\Repository::select( 'incident', $filters, $limit + 1, $offset, false );
            if ( is_wp_error( $rows ) ) {
                return $base + array(
                    'available' => false,
                    'error_code' => $rows->get_error_code(),
                    'incidents' => array(),
                );
            }
            $more = count( $rows ) > $limit;
            foreach ( array_slice( $rows, 0, $limit ) as $row ) {
                $incident = Records::get( 'incident', $row['record_id'] );
                if ( null !== $incident ) {
                    $out[] = $incident;
                } elseif ( $open_only ) {
                    return $base + array( 'available' => false, 'error_code' => 'f3_google_incident_read', 'incidents' => array() );
                }
            }
            return $base + array(
                'available' => true,
                'incidents' => $out,
                'next_offset' => $more ? $offset + count( $out ) : null,
            );
        }
        catch ( \Throwable $error ) {
            return $base + array(
                'available' => false,
                'error_code' => 'f3_google_incident_read',
                'incidents' => array(),
            );
        }
    }
    public static function register(): void {
        Ability::register(
            'google/alerts',
            'any',
            array(
                'label' => 'Google: alertas operacionais',
                'description' => 'Consulta configuração e incidentes locais. Não envia mensagens.',
                'input_schema' => array(
                    'properties' => array(
                        'offset' => array(
                            'type' => 'integer',
                            'minimum' => 0,
                        ),
                        'limit' => array(
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                        ),
                    ),
                ),
                'callback' => static fn ( array $input ) => Response::ok( self::state( $input ) ),
            )
        );
        Ability::register(
            'google/configure-alerts',
            'any',
            array(
                'label' => 'Google: configurar alertas',
                'description' => 'Ativa observação e e-mail mediante configuração explícita. Revalida intervalo e destinatários; a aceitação do envio não comprova entrega.',
                'mode' => 'write',
                'input_schema' => array(
                    'required' => array( 'configuration', 'expected_revision' ),
                    'properties' => array(
                        'configuration' => self::schema(),
                        'expected_revision' => array( 'type' => 'string' ),
                    ),
                ),
                'callback' => array( self::class, 'configure' ),
            )
        );
    }
}
