<?php
/**
 * Administrative actions: capability + nonce, verified saves and scoped feedback.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

use Fator3\McpGoogle\Auth\{Credentials, Configuration as AuthConfiguration};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Admin {

	public const SLUG     = 'wp-mcp-google-fator3';
	public const SECTIONS=['overview'=>'Visão geral','connection'=>'Conexão','conversions'=>'Conversões','archive'=>'Acervo Ads','gsc'=>'Search Console','gtm'=>'GTM','incidents'=>'Incidentes','advanced'=>'Avançado','help'=>'Ajuda'];
    public const CONNECTION_PANELS = ['identity'=>'Identidade','services'=>'Serviços e recursos','permissions'=>'Permissões'];
    public const ADVANCED_PANELS = ['limits'=>'Limites e auditoria','diagnostics'=>'Diagnóstico','operations'=>'Tarefas e agendas','templates'=>'Modelos e manutenção','credentials'=>'Credenciais avançadas','contract'=>'Contrato de configuração'];
    private const LINKS = [
        'services'=>['connection','services'], 'diagnostics'=>['advanced','diagnostics'],
        'operations'=>['advanced','operations'], 'controls'=>['advanced','templates'], 'profiles'=>['conversions',null],
    ];

	public static function init(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'assets' ) );
		foreach ( array( 'rename_connection', 'plan_identity', 'switch_identity', 'toggle', 'toggle_ga', 'toggle_ads', 'save_mode', 'save_sa', 'save_oauth', 'save_ads', 'save_ga', 'save_limits', 'test', 'clear_log', 'discover', 'script', 'documentation' ) as $action ) {
			add_action( 'admin_post_f3_mcp_google_' . $action, array( self::class, 'handle_' . $action ) );
		}
	}
	public static function menu(): void {
		add_management_page( 'Fator3 MCP Google', 'Fator3 MCP Google', 'manage_options', self::SLUG, array( self::class, 'render' ) );
	}
	public static function assets( string $hook ): void {
		if ( 'tools_page_' . self::SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'f3-google-admin', plugins_url( 'assets/admin.css', F3_MCP_GOOGLE_FILE ), array(), F3_MCP_GOOGLE_VERSION );
		wp_enqueue_script( 'f3-google-admin', plugins_url( 'assets/admin.js', F3_MCP_GOOGLE_FILE ), array(), F3_MCP_GOOGLE_VERSION, true );
	}
	public static function section(): string {
        $requested = self::request('section');
        if (isset(self::SECTIONS[$requested])) { return $requested; }
        if (isset(self::LINKS[$requested])) { return self::LINKS[$requested][0]; }
        // A panel parameter without a section keeps links written before 0.32.0 on their section.
        if ('' === $requested && isset(self::CONNECTION_PANELS[self::request('connection_panel')])) { return 'connection'; }
        if ('' === $requested && isset(self::ADVANCED_PANELS[self::request('advanced_panel')])) { return 'advanced'; }
        return 'overview';
    }

    /** Only the panel belonging to the selected section travels in navigation and POST forms. */
    public static function panel_args(string $section): array {
        $link = self::LINKS[$section] ?? self::LINKS[self::request('section')] ?? null;
        $section = self::LINKS[$section][0] ?? $section;
        if ($section === 'connection') {
            $key = 'connection_panel'; $panels = self::CONNECTION_PANELS;
        } elseif ($section === 'advanced') {
            $key = 'advanced_panel'; $panels = self::ADVANCED_PANELS;
        } else {
            return [];
        }
        $selected = $link && $link[0] === $section && $link[1] ? $link[1] : self::request($key);
        return [$key => isset($panels[$selected]) ? $selected : array_key_first($panels)];
    }

	public static function method(): string {
		$s = self::request( 'method' );
		return in_array( $s, Options::AUTH_MODES, true ) ? $s : Options::auth_mode();
	}
	private static function request( string $name ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
		$v = isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? sanitize_key( wp_unslash( $_POST[ $name ] ) ) : ( isset( $_GET[ $name ] ) && is_string( $_GET[ $name ] ) ? sanitize_key( wp_unslash( $_GET[ $name ] ) ) : '' );
		return $v;
	}
	public static function url( string $status = '', ?string $section = null, ?string $method = null ): string {
		$args = array(
			'page'          => self::SLUG,
			'connection_id' => Connections::id(),
			'section'       => self::LINKS[$section ?? ''][0] ?? $section ?? self::section(),
			'method'        => $method ?? self::method(),
		);
		$args += self::panel_args($section ?? self::section());
        if ($args['section']==='archive') {
            $account=self::posted('archive_target');
            if ($account==='new' || preg_match('/^[0-9]{10}$/D',$account)) { $args['archive_account']=$account; }
        }
		if ( '' !== $status ) {
			$args['f3_status'] = $status;
		}
		return add_query_arg( $args, admin_url( 'tools.php' ) );
	}
	public static function posted( string $field ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
		return isset( $_POST[ $field ] ) && is_scalar( $_POST[ $field ] ) ? trim( sanitize_text_field( wp_unslash( (string) $_POST[ $field ] ) ) ) : '';
	}
	public static function posted_revision(): ?string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
		return isset( $_POST['expected_revision'] ) ? self::posted( 'expected_revision' ) : null;
	}
	public static function guard( string $nonce ): void {
		if ( ! Options::authorized() ) {
			wp_die( 'Permissão insuficiente.' );
		}
		check_admin_referer( $nonce );
		$connection = self::posted( 'connection_id' );
		if ( is_wp_error( Connections::select( '' !== $connection ? $connection : 'default' ) ) ) {
			wp_die( 'Conexão inválida.' );
		}
	}
	public static function feedback_key( string $kind, ?int $user_id = null ): string {
		return 'f3_mcp_google_ui_' . $kind . '_' . ( $user_id ?? get_current_user_id() ) . '_' . Connections::id();
	}
	public static function require_saved( array $result, ?int $user_id = null ): void {
        \Fator3\McpGoogle\Cache::set(self::feedback_key('warnings',$user_id),$result['warnings']??[],300);
		if ( ! empty( $result['success'] ) ) {
			return;
		}
		Audit::log(
			'configuration:rejected',
			Connections::id(),
			array(
				'status'     => 'error',
				'error_code' => $result['error_code'] ?? 'f3_google_option_write',
			)
		);
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
		$safe = array_intersect_key( $_POST, array_flip( array( 'sa_subject', 'oauth_client_id', 'ads_login_customer_id', 'ads_api_version', 'ga_default_property', 'ga_property_id', 'ads_customer_id', 'gsc_site_url', 'spreadsheet_id', 'sitemap_url', 'max_rows', 'http_timeout', 'audit_retention', 'inspection_budget', 'services' ) ) );
		// Whitelist only non-secret editable values; arbitrary response details are excluded.
		\Fator3\McpGoogle\Cache::set(
			self::feedback_key( 'failure', $user_id ),
			array(
				'code'            => $result['error_code'] ?? 'f3_google_option_write',
				'message'         => $result['message'] ?? 'Falha ao salvar configuração.',
				'values'          => $safe,
				'rollback_failed' => ! empty( array_filter( $result['rollback'] ?? array(), static fn ( $r ) => empty( $r['success'] ) ) ),
			),
			300
		);
		self::back( 'save_failed' );
	}
	public static function saved( array $result, string $status = 'saved' ): void {
		self::require_saved( $result );
		$changed = $result['changed'] ?? null;
		if ( null === $changed && isset( $result['operations'] ) ) {
			$changed = (bool) array_filter( $result['operations'], static fn ( $r ) => ! empty( $r['changed'] ) );
		}
		self::back( false === $changed ? 'unchanged' : $status );
	}
	public static function back( string $status, ?string $section = null ): void {
		wp_safe_redirect( self::url( $status, $section ) );
		exit;
	}
	private static function save( array $values, array $secrets = array(), array $deletes = array() ): array {
		return Settings::save( $values, $secrets, $deletes, self::posted_revision() );
	}
	public static function handle_toggle(): void {
		self::guard( 'f3_mcp_google_toggle' );
		self::saved( self::save( array( Options::ENABLED => '1' === self::posted( 'enable' ) ) ) );
	}
	public static function handle_toggle_ga(): void {
		self::toggle_service( 'ga' );
	}
	public static function handle_toggle_ads(): void {
		self::toggle_service( 'ads' );
	}
	private static function toggle_service( string $service ): void {
		self::guard( 'f3_mcp_google_toggle_' . $service );
		$services = Admin\Fields::effective_services();
		if ( '1' === self::posted( 'enable' ) ) {
			$services[ $service ] = $services[ $service ] ?? 'read';
		} else {
			unset( $services[ $service ] );
		}
		$input = array(
			'services'        => $services,
			'validate_access' => false,
		);
		if ( null !== self::posted_revision() ) {
			$input['expected_revision'] = self::posted_revision();
		}
		SetupAdmin::submit( $input );
	}
	public static function handle_save_mode(): void {
		self::guard( 'f3_mcp_google_save_mode' );
		self::saved( AuthConfiguration::activate( self::posted( 'auth_mode' ), self::posted_revision() ), 'activated' );
	}
	public static function handle_rename_connection(): void {
		self::guard('f3_mcp_google_rename_connection');
		self::saved(Connections::rename(self::posted('connection_label'),self::posted_revision()??''));
	}
	public static function handle_plan_identity(): void {
		self::guard('f3_mcp_google_plan_identity');
		$result=AuthConfiguration::plan_identity_change(self::posted_revision());
		self::require_saved($result);
		Cache::set(self::feedback_key('identity_plan'),$result,600);
		wp_safe_redirect(self::url('identity_planned','connection','service_account'));exit;
	}
	public static function handle_switch_identity(): void {
		self::guard('f3_mcp_google_switch_identity');
		if(self::posted('confirm_identity_change')!=='1'){self::require_saved(Response::fail(new \WP_Error('f3_google_identity_confirm','Confirme a troca de identidade.')));return;}
		self::saved(AuthConfiguration::switch_identity(self::posted_revision()??'',self::posted('expected_plan_hash')),'activated');
	}
	public static function handle_save_sa(): void {
		self::guard( 'f3_mcp_google_save_sa' );
		if ( '1' === self::posted( 'clear_sa' ) ) {
			self::saved( AuthConfiguration::clear( 'service_account', self::posted_revision() ), 'sa_cleared' );
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper. Structured input is validated by the shared schema/credential writer; text sanitization would corrupt JSON or the key.
		$json = isset( $_POST['sa_json'] ) && is_string( $_POST['sa_json'] ) ? trim( wp_unslash( $_POST['sa_json'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
		$result    = AuthConfiguration::save_sa( $json, isset( $_POST['sa_subject'] ) ? self::posted( 'sa_subject' ) : null, '1' === self::posted( 'activate' ), self::posted_revision() );
		$activated = '1' === self::posted( 'activate' );
		self::saved( $result, $activated ? 'activated' : 'sa_saved' );
	}
	public static function handle_save_oauth(): void {
		self::guard( 'f3_mcp_google_save_oauth' );
		if ( '1' === self::posted( 'clear_oauth' ) ) {
			self::saved( AuthConfiguration::clear( 'oauth', self::posted_revision() ) );
			return;
		}
		self::saved( AuthConfiguration::save_oauth( self::posted( 'oauth_client_id' ), self::posted( 'oauth_client_secret' ), self::posted_revision() ) );
	}
	public static function handle_save_ads(): void {
		self::guard( 'f3_mcp_google_save_ads' );
		$values  = array();
		$secrets = array();
		$deletes = array();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
		if ( isset( $_POST['ads_login_customer_id'] ) ) {
			$raw = self::posted( 'ads_login_customer_id' );
			$id  = '' === $raw ? '' : Ads\CustomerId::normalize( $raw );
			if ( is_wp_error( $id ) ) {
				self::require_saved( Response::fail( $id ) );
				return;
			}
			$values[ Options::ADS_LOGIN_CUSTOMER_ID ] = $id;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
		if ( isset( $_POST['ads_api_version'] ) ) {
			$version = self::posted( 'ads_api_version' );
			if ( ! preg_match( Options::ADS_VERSION_PATTERN, $version ) ) {
				self::require_saved( Response::fail( new \WP_Error( 'f3_google_ads_version', 'Informe uma versão no formato v25.' ) ) );
				return;
			}
			$values[ Options::ADS_API_VERSION ] = $version;
		}
		if ( isset($_POST['ads_access_level']) ) {
            $level = self::posted('ads_access_level');
            if (!in_array($level,Ads\PlannerAccess::LEVELS,true)) {
                self::require_saved(Response::fail(new \WP_Error('f3_google_ads_level','Nível de acesso inválido.')));
                return;
            }
            $values[Ads\PlannerAccess::OPTION] = ['level'=>$level,'scope'=>Ads\PlannerAccess::scope()];
            if ($level==='unknown' && Ads\PlannerAccess::level()==='unknown' && Ads\PlannerAccess::project_access()) {
                $values[Ads\PlannerAccess::OPTION]['legacy_access']=true;
            }
        }
		self::saved( Auth\Validation::save_ads($values,$secrets,$deletes,self::posted_revision()) );
	}
	public static function handle_save_ga(): void {
		self::guard( 'f3_mcp_google_save_ga' );
		$input = array(
			'bindings'        => array( 'ga_property_id' => self::posted( 'ga_default_property' ) ),
			'validate_access' => false,
		);
		if ( null !== self::posted_revision() ) {
			$input['expected_revision'] = self::posted_revision();
		}
		SetupAdmin::submit( $input );
	}
	public static function handle_save_limits(): void {
		self::guard( 'f3_mcp_google_save_limits' );
		$values = array();
		foreach ( Options::LIMITS as $name => $rule ) {
			$id = substr( $name, strlen( 'f3_mcp_google_' ) );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
			if ( ! isset( $_POST[ $id ] ) ) {
				continue;
			}
			$raw = self::posted( $id );
			if ( ! preg_match( '/^[0-9]+$/D', $raw ) || (int) $raw < $rule['minimum'] || (int) $raw > $rule['maximum'] ) {
				self::require_saved( Response::fail( new \WP_Error( 'f3_google_limit', Admin\Fields::metadata()[ $id ]['label'] . ': informe um inteiro de ' . $rule['minimum'] . ' a ' . $rule['maximum'] . '.' ) ) );
				return;
			}
			$values[ $name ] = (int) $raw;
		}
		self::saved( self::save( $values ) );
	}
	public static function diagnostic_key(): string {
		return self::feedback_key( 'test' );
	}
	public static function handle_test(): void {
		self::guard( 'f3_mcp_google_test' );
		$revision = Settings::revision();
		if ( is_wp_error( $revision ) ) {
			self::back( 'diagnostic_unreadable', 'diagnostics' );
			return;
		}
		if ( '' === self::posted( 'connection_id' ) || self::posted_revision() !== $revision ) {
			self::back( 'diagnostic_stale', 'diagnostics' );
			return;
		}
		$mode = Options::auth_mode();
		$result = SelfTest::run( array( 'live' => true ) );
		Audit::log( 'selftest', Connections::id() );
		if ( $revision !== Settings::revision() ) {
			self::back( 'diagnostic_changed', 'diagnostics' );
			return;
		}
		$result += array(
			'connection_id' => Connections::id(),
			'auth_mode'     => $mode,
			'checked_at'    => gmdate( 'c' ),
			'revision'      => $revision,
		);
		$stored = Cache::set( self::diagnostic_key(), $result, 3600 );
		self::back( $stored ? 'tested' : 'diagnostic_store_failed', 'diagnostics' );
	}
	public static function handle_discover(): void {
		self::guard( 'f3_mcp_google_discover' );
		$service = self::posted( 'service' );
		$revision = self::posted_revision();
		if ( null === $revision || $revision !== Settings::revision() ) {
			self::back( 'discovery_stale' );
			return;
		}
		$result = Admin\Resources::discover( $service, self::posted( 'page_token' ) );
		if ( $revision !== Settings::revision() ) {
			self::back( 'discovery_stale' );
			return;
		}
		$stored = Cache::set( self::feedback_key( 'discovery_' . $service ), $result, 600 );
		self::back( $stored ? Admin\Resources::notice( $result ) : 'discovery_store_failed' );
	}
	public static function handle_clear_log(): void {
		self::guard( 'f3_mcp_google_clear_log' );
		self::saved( Audit::clear(), 'log_cleared' );
	}
	public static function documents(): array {
		return array(
			'README.md'                            => 'Índice: identidade, mapa de documentos e leitura pelo MCP',
			'ESPECIFICACAO.md'                     => 'Especificação: objetivo, fronteiras, dados, efeitos e limites',
			'GUIA-' . F3_MCP_GOOGLE_VERSION . '.md' => 'Guia de configuração e operação pelo painel',
			'AGENT-GUIDE.md'                       => 'Guia para agentes',
			'RECEITAS.md'                          => 'Receitas de uso por tarefa',
			'CONTRACTS.md'                         => 'Contratos das habilidades',
			'MIGRACAO.md'                          => 'Instalação, atualização, desinstalação e recuperação',
			'CHANGELOG.md'                         => 'Notas da versão e histórico',
			'VALIDACAO.md'                         => 'Verificação da instalação e limites da validação',
			'ACOMPANHAMENTO-CRON.md'               => 'Cron, executor e manutenção',
			'ANALYTICS.md'                         => 'Coleta, calendário e exportação',
			'PLANEJADOR.md'                        => 'Planejador de palavras-chave e junção com GSC',
			'ACERVO-ADS-GSC.md'                    => 'Acervo Ads e leitor de consultas GSC',
			'CORE-ACERVOS.md'                      => 'Configuração dos leitores com o Site Core',
			'CONVERSOES.md'                        => 'Contexto de conversões do Site Core e diagnóstico GTM',
			'CONVERSION-DELIVERY-CORE-140.md'      => 'Entrega de conversões pelo servidor',
			'AVISOS-RENOVACAO.md'                  => 'Avisos de renovação',
			'CONTRATOS-PUBLICOS.md'                => 'Contratos entre plugins',
			'SDK-PHP.md'                           => 'SDKs PHP dos leitores',
			'ability-catalog.json'                 => 'Catálogo completo de operações e schemas',
			'configuration-definitions.json'       => 'Schema de configuração',
			'profile-schema.json'                  => 'Schema de perfis GA4',
			'stage-conversion-payload.json'        => 'Schema de conversão por etapa comercial',
			'core-conversions-capabilities.json'   => 'SDK Core: descritor de conversões',
			'core-conversions-snapshot-input.json' => 'SDK Core: entrada do snapshot',
			'core-conversions-snapshot.json'       => 'SDK Core: saída do snapshot',
		);
	}
	/**
	 * Groups of the Help section: group label => document IDs of documents().
	 * Every document of documents() must appear in exactly one group (checked by UiLayout032Test).
	 */
	public static function document_groups(): array {
		return array(
			'Comece por aqui'          => array( 'README.md', 'ESPECIFICACAO.md', 'GUIA-' . F3_MCP_GOOGLE_VERSION . '.md', 'CHANGELOG.md' ),
			'Uso dos serviços'         => array( 'ANALYTICS.md', 'PLANEJADOR.md', 'ACERVO-ADS-GSC.md', 'CONVERSOES.md' ),
			'Operação e manutenção'    => array( 'ACOMPANHAMENTO-CRON.md', 'AVISOS-RENOVACAO.md', 'VALIDACAO.md', 'MIGRACAO.md' ),
			'Agentes e MCP'            => array( 'AGENT-GUIDE.md', 'RECEITAS.md', 'CONTRACTS.md', 'ability-catalog.json' ),
			'Integração entre plugins' => array( 'CONTRATOS-PUBLICOS.md', 'SDK-PHP.md', 'CORE-ACERVOS.md', 'CONVERSION-DELIVERY-CORE-140.md', 'core-conversions-capabilities.json', 'core-conversions-snapshot-input.json', 'core-conversions-snapshot.json' ),
			'Schemas de configuração'  => array( 'configuration-definitions.json', 'profile-schema.json', 'stage-conversion-payload.json' ),
		);
	}
	/** Authenticated download URL of a packaged document (same action and nonce since 0.4). */
	public static function document_url( string $name ): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action'   => 'f3_mcp_google_documentation',
					'document' => $name,
				),
				admin_url( 'admin-post.php' )
			),
			'f3_mcp_google_documentation'
		);
	}
	public static function handle_documentation(): void {
		self::guard( 'f3_mcp_google_documentation' );
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce and capability checked immediately above by guard().
		$name = isset( $_GET['document'] ) && is_string( $_GET['document'] ) ? wp_unslash( $_GET['document'] ) : '';
		$content = Documentation::content( $name );
		if ( is_wp_error( $content ) ) {
			wp_die( esc_html( $content->get_error_message() ) );
		}
		header( 'Content-Type: ' . (str_ends_with($name,'.json') ? 'application/json' : 'text/markdown') . '; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'Cache-Control: no-store' );
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Nonce-authenticated download of packaged Markdown with fixed allowlisted names.
		echo $content;
		exit;
	}
	public static function handle_script(): void {
		self::guard( 'f3_mcp_google_script' );
		header( 'Content-Type: text/plain; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="googlecloudscript.txt"' );
		header( 'Cache-Control: no-store' );
		echo require F3_MCP_GOOGLE_DIR . 'includes/Data/CloudScript.php'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- authenticated plain-text download.
		exit;
	}
	public static function forced_by_filter(): bool {
		return (bool) has_filter( 'f3_mcp_google_enabled' );
	}
	public static function render(): void {
		if ( ! Options::authorized() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI navigation/filter; no mutation.
		$id = isset( $_GET['connection_id'] ) && is_string( $_GET['connection_id'] ) ? sanitize_key( wp_unslash( $_GET['connection_id'] ) ) : 'default';
		if ( is_wp_error( Connections::select( $id ) ) ) {
			echo '<div class="notice notice-error"><p>Conexão inválida.</p></div>';
			return;
		}
		Admin\Screen::render();
	}
}
