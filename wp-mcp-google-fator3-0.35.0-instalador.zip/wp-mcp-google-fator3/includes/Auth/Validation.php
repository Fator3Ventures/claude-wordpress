<?php
/** Credential checks never reuse an old token or persist the submitted credential. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Auth;
use Fator3\McpGoogle\{Options, Settings, Connections, Response};
use Fator3\McpGoogle\Http\GoogleClient;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Validation {
    public const RECEIPTS='f3_mcp_google_credential_receipts';
    public static function failure(string $code,string $message): array {
        // HTTP bookkeeping can have happened. Do not assert applied=false for the whole operation.
        return Response::fail(new \WP_Error($code,$message),['persisted'=>false,'changed'=>false,'active_preserved'=>true]);
    }
    public static function revision(?string $expected) {
        if (!Options::authorized()) return new \WP_Error('f3_google_forbidden','Permissão insuficiente.');
        $revision=Settings::revision();
        if (is_wp_error($revision)) return $revision;
        if ($expected!==null && !hash_equals($revision,$expected)) return new \WP_Error('f3_google_configuration_conflict','A configuração mudou. Recarregue antes de salvar.');
        return $revision;
    }
    public static function sa(array $data): array {
        $key=ServiceAccount::validate_key($data['secrets'][Options::SA_JSON]??'',true);
        if (is_wp_error($key)) return self::failure($key->get_error_code(),$key->get_error_message());
        $warnings=ServiceAccount::warnings($key);
        $subject=$data['values'][Options::SA_SUBJECT]??'';
        $scopes=Credentials::scopes_for('any');
        if (!$scopes) $scopes=[Credentials::SCOPE_GA];
        $jwt=ServiceAccount::build_jwt($key,$scopes,time(),$subject);
        if ($jwt==='') return self::failure('f3_google_sa_sign','Não foi possível assinar com esta chave. A chave salva continua em uso.')+['warnings'=>$warnings];
        $r=GoogleClient::post($key['token_uri'],['grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion'=>$jwt],['auth'=>false,'form'=>true,'retries'=>0]);
        if (is_wp_error($r)) {
            $reason=self::reason($r);
            $detail=$reason==='invalid_grant'?' Confira se a chave foi apagada ou desativada, o relógio do servidor e a delegação, se utilizada.':'';
            return self::failure('f3_google_credential_rejected','O Google recusou esta chave ('.$reason.').'.$detail.' A chave salva continua em uso.')+['warnings'=>$warnings];
        }
        if (!is_string($r['access_token']??null)||$r['access_token']==='') return self::failure('f3_google_token','O Google não confirmou a autenticação. A chave salva continua em uso.')+['warnings'=>$warnings];
        return ['success'=>true,'authentication_validated'=>true,'checked_at'=>time(),'scopes'=>$scopes,'warnings'=>$warnings];
    }
    private static function reason(\WP_Error $error): string {
        $d=(array)$error->get_error_data();$reason=$d['reason']??$d['status']??$error->get_error_code();
        return is_scalar($reason)&&preg_match('/^[a-zA-Z0-9_.-]{1,80}$/D',(string)$reason)?(string)$reason:'falha_de_validacao';
    }
    public static function receipts() {
        $r=Options::stored(Options::storage_name(self::RECEIPTS));
        return !$r['success']||($r['exists']&&!is_array($r['value']))?new \WP_Error('f3_google_receipts_read','Não foi possível ler as comprovações de credenciais.') : ($r['value']??[]);
    }
    public static function sa_fingerprint(array $data): string {
        return hash_hmac('sha256',wp_json_encode([$data['secrets'][Options::SA_JSON]??'', $data['values'][Options::SA_SUBJECT]??'']),wp_salt('auth'));
    }
    private static function access_key(): string {
        return 'f3_mcp_google_access_'.hash('sha256',wp_json_encode([Connections::id(),Credentials::identity_key(),Options::get(Connections::SERVICES),Options::get(Connections::BINDINGS)]));
    }
    public static function observe_access(array $result): void {
        if(!Options::authorized()||Connections::preview_values()||Connections::preview_secrets())return;
        $services=[];
        foreach($result['checks']??[] as $check)if(($check['status']??'')==='passed'&&!empty($check['resource_tested']))$services[]=substr($check['name'],5);
        if($services)\Fator3\McpGoogle\Cache::set(self::access_key(),['at'=>time(),'services'=>$services],30*DAY_IN_SECONDS);
    }
    public static function save_ads(array $values,array $secrets,array $deletes,?string $expected): array {
        $revision=self::revision($expected);if(is_wp_error($revision))return self::failure($revision->get_error_code(),$revision->get_error_message());
        if(isset($values[Options::ADS_LOGIN_CUSTOMER_ID])&&$values[Options::ADS_LOGIN_CUSTOMER_ID]!==''){
            $id=\Fator3\McpGoogle\Ads\CustomerId::normalize($values[Options::ADS_LOGIN_CUSTOMER_ID]);
            if(is_wp_error($id))return self::failure($id->get_error_code(),$id->get_error_message());
            $values[Options::ADS_LOGIN_CUSTOMER_ID]=$id;
        }
        if(isset($values[Options::ADS_API_VERSION])&&!preg_match(Options::ADS_VERSION_PATTERN,$values[Options::ADS_API_VERSION]))return self::failure('f3_google_ads_version','Versão da API inválida.');
        // Old forms cannot overwrite the historical salt used by previously verified destinations.
        unset($secrets[Options::ADS_DEVELOPER_TOKEN], $values[Options::ADS_DEVELOPER_TOKEN]);
        $deletes=array_values(array_diff($deletes,[Options::ADS_DEVELOPER_TOKEN]));
        return Settings::save($values,$secrets,$deletes,$revision);
    }
    public static function summary(): array {
        if (!Options::authorized()) return [];
        $r=self::receipts();$r=is_wp_error($r)?[]:$r;
        $json=Options::get_secret(Options::SA_JSON);$key=json_decode($json,true);$key=is_array($key)?$key:[];
        $data=['values'=>[Options::SA_SUBJECT=>Options::get(Options::SA_SUBJECT,'')],'secrets'=>[Options::SA_JSON=>$json]];
        $sa=$r['service_account']??[];
        if (!hash_equals(self::sa_fingerprint($data),(string)($sa['fingerprint']??''))) $sa=[];
        $access=\Fator3\McpGoogle\Cache::get(self::access_key());
        if(is_array($access)&&($access['at']??0)>($sa['resource_access_at']??0)){$sa['resource_access_at']=$access['at'];$sa['services']=$access['services'];}
        return ['warnings'=>ServiceAccount::warnings($key),'identity'=>$key['client_email']??'','project_id'=>$key['project_id']??'','key_suffix'=>substr((string)($key['private_key_id']??''),-8),
            'authentication_at'=>$sa['at']??null,'services'=>$sa['services']??[], 'resource_access_at'=>$sa['resource_access_at']??null,
            'rotation_history'=>$r['rotations']??[]];
    }
}
