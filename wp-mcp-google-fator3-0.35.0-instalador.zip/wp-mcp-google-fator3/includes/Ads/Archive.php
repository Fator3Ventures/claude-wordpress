<?php
/** Explicit account collection, bounded resumable pages and daily revisitation. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;
use Fator3\McpGoogle\{Ability,Audit,Auth\Credentials,Automation\Execution,Automation\ExecutorSchedule,Automation\Jobs,Channel,Connections,Http\GoogleClient,Lock,Options,Policy,Recovery,Response,Settings,Storage\Admission,Storage\State};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class Archive {
    public const CONFIG='f3_mcp_google_ads_archive';
    public static function init(): void { add_action(Jobs::HOOK,[self::class,'cron'],20); }
    public static function config() {
        $r=Options::stored(Options::storage_name(self::CONFIG));
        return !$r['success']||($r['exists']&&!is_array($r['value']))?new \WP_Error('f3_google_archive_config','Configuração do acervo ilegível.'):($r['value']??[]);
    }
    public static function fail(string $code,string $message,array $extra=[]): array { return Response::fail(new \WP_Error('f3_google_archive_'.$code,$message),$extra); }
    public static function guard(string $account,array $cfg): ?\WP_Error {
        if($e=Recovery::guard()??State::guard())return $e;
        $all=self::config();if(is_wp_error($all))return $all;
        if(($all[$account]??null)!==$cfg||empty($cfg['enabled'])||!Options::is_enabled()||!Options::ads_enabled()||!Connections::enabled('ads'))return new \WP_Error('f3_google_archive_paused','Coleta não autorizada ou pausada.');
        if(!Options::user_authorized((int)($cfg['granted_by']??0))||($cfg['principal']??'')!==Credentials::execution_identity()||!Policy::permitted('ads',$account))return new \WP_Error('f3_google_archive_authorization','Identidade, conta ou administrador da coleta mudou.');
        $rev=Settings::execution_revision();
        return is_wp_error($rev)?$rev:(!hash_equals($cfg['execution_revision'],$rev)?new \WP_Error('f3_google_archive_context','Reautorize a coleta após mudar serviços, política, gerenciadora ou identidade.'):null);
    }
    public static function configure(array $i): array {
        if(!Options::authorized())return self::fail('forbidden','Permissão administrativa exigida.');
        $account=$i['account_id']??'';$enabled=$i['enabled']??null;
        if(!is_string($account)||!preg_match('/^[0-9]{10}$/D',$account)||!is_bool($enabled)||!is_string($i['expected_revision']??null))return self::fail('input','Conta de 10 dígitos, enabled e revisão são obrigatórios.');
        $revision=\Fator3\McpGoogle\Auth\Validation::revision($i['expected_revision']);if(is_wp_error($revision))return Response::fail($revision);
        $all=self::config();if(is_wp_error($all))return Response::fail($all);
        $before=Settings::execution_revision();if(is_wp_error($before))return Response::fail($before);
        $cfg=$all[$account]??[];
        if($enabled){
            $datasets=$i['datasets']??ArchiveQuery::DATASETS;$backfill=$i['backfill_days']??90;$revisit=$i['revisit_days']??7;
            if(!is_array($datasets)||count(array_filter($datasets,'is_string'))!==count($datasets)||!$datasets||array_diff($datasets,ArchiveQuery::DATASETS)||count($datasets)!==count(array_unique($datasets))||!is_int($backfill)||$backfill<1||$backfill>1125||!is_int($revisit)||$revisit<1||$revisit>30)return self::fail('input','Datasets, backfill (1–1125 dias) ou revisita (1–30 dias) inválidos.');
            if(!Options::is_enabled()||!Options::ads_enabled()||!Connections::enabled('ads')||!Policy::permitted('ads',$account))return self::fail('authorization','Ative o Ads e autorize esta conta na política da conexão.');
            $raw=GoogleClient::post(AdsApi::base().'/customers/'.$account.'/googleAds:search',['query'=>'SELECT customer.id, customer.currency_code, customer.time_zone, customer.manager FROM customer LIMIT 1'],['connector'=>'ads','mode'=>'read','operation_id'=>'googleads.customers.googleAds.search','headers'=>AdsApi::headers(),'scopes'=>[Credentials::SCOPE_ADS],'retries'=>0]);
            if(is_wp_error($raw))return Response::fail($raw);
            $customer=$raw['results'][0]['customer']??[];
            if((string)($customer['id']??'')!==$account||!preg_match('/^[A-Z]{3}$/D',(string)($customer['currencyCode']??''))||!in_array($customer['timeZone']??'',\DateTimeZone::listIdentifiers(\DateTimeZone::ALL_WITH_BC),true)||!empty($customer['manager']))return self::fail('account','A API não confirmou conta anunciante, moeda e fuso.');
            $cfg=['enabled'=>true,'datasets'=>array_values($datasets),'backfill_days'=>$backfill,'revisit_days'=>$revisit,'currency'=>$customer['currencyCode'],'time_zone'=>$customer['timeZone'],'granted_by'=>get_current_user_id(),'principal'=>Credentials::execution_identity(),'execution_revision'=>$before];
        } else {$cfg['enabled']=false;}
        $cfg['revision']=bin2hex(random_bytes(16));$cfg['at']=time();$all[$account]=$cfg;
        $now=Settings::execution_revision();if(is_wp_error($now)||!hash_equals($before,$now))return Settings::conflict();
        $saved=Settings::save([self::CONFIG=>$all],[],[],$i['expected_revision']);
        if(!empty($saved['success'])&&$enabled)$saved['scheduling']=ExecutorSchedule::ensure('ads_archive_grant');
        return $saved+['archive'=>self::status()];
    }
    public static function status(): array {
        if(!Options::authorized())return self::fail('forbidden','Permissão administrativa exigida.');
        $all=self::config();if(is_wp_error($all))return Response::fail($all);
        $accounts=[];
        foreach($all as $account=>$cfg){
            $e=self::guard((string)$account,$cfg);
            $plan=ArchiveStore::get('adsplan',ArchiveStore::key((string)$account,'plan',''));
            $accounts[]=['account_id'=>(string)$account,'enabled'=>!empty($cfg['enabled']),'datasets'=>$cfg['datasets']??[],'backfill_days'=>$cfg['backfill_days']??null,'revisit_days'=>$cfg['revisit_days']??null,'currency'=>$cfg['currency']??null,'time_zone'=>$cfg['time_zone']??null,'ready'=>$e===null,'reason_code'=>$e?$e->get_error_code():null,'deferred_slices'=>is_array($plan)?count($plan['deferred']??[]):0,'progress'=>is_wp_error($plan)?['error_code'=>$plan->get_error_code()]:array_intersect_key($plan??[],array_flip(['cycle','working','backfill_offset','last_result','at']))];
        }
        return Response::ok(['accounts'=>$accounts,'retention_days'=>0,'retention'=>'permanent','encrypted'=>true,'remote_calls'=>false,'configuration_revision'=>Settings::revision(),'collection_hook'=>Jobs::HOOK,'datasets'=>ArchiveQuery::DATASETS,'provider_windows'=>['clicks_days'=>90,'changes_complete_days'=>29,'daily_performance_months'=>37]]);
    }
    public static function collect(array $i): array {
        if(!Options::authorized())return self::fail('forbidden','Permissão administrativa exigida.');
        return Admission::run('ads/archive-collect',static fn()=>self::advance((string)($i['account_id']??''),(string)($i['dataset']??''),(string)($i['date']??''),($i['refresh']??false)===true));
    }
    private static function advance(string $account,string $dataset,string $date,bool $refresh=false): array {
        $all=self::config();if(is_wp_error($all))return Response::fail($all);
        $cfg=$all[$account]??null;
        if(!is_array($cfg)||!in_array($dataset,$cfg['datasets']??[],true)||!ArchiveQuery::valid_date($date))return self::fail('input','Conta, dataset ou dia não autorizado.');
        if($e=self::guard($account,$cfg))return Response::fail($e);
        $today=(new \DateTimeImmutable('now',new \DateTimeZone($cfg['time_zone'])))->format('Y-m-d');
        if($date>=$today||$date<ArchiveQuery::first_day($dataset,$today))return self::fail('window','Dia fora da janela recuperável do fornecedor. O acervo já salvo permanece legível.');
        $id=ArchiveStore::key($account,$dataset,$date);$lock=Lock::acquire('ads-archive:'.Connections::id().':'.$account,60);
        if(!$lock)return self::fail('busy','Coleta desta conta em execução.');
        try {
            $guard=static fn()=>!Lock::owned($lock)?new \WP_Error('f3_google_archive_lease','Reserva da coleta expirou.'):self::guard($account,$cfg);
            return Execution::run(static function()use($account,$dataset,$date,$cfg,$id,$refresh,$guard){
                $job=ArchiveStore::get('adsjob',$id);if(is_wp_error($job))return Response::fail($job);
                if(is_array($job)&&$job['state']==='complete'&&!$refresh)return Response::ok(['state'=>'complete','revision'=>$job['revision'],'reused'=>true,'remote_dispatched'=>false]);
                if(!$job||($job['state']==='complete'&&$refresh)||($job['grant_revision']??'')!==$cfg['revision']||time()-($job['created_at']??0)>82800){
                    $job=['state'=>'fetch','revision'=>bin2hex(random_bytes(16)),'account_id'=>$account,'dataset'=>$dataset,'date'=>$date,'grant_revision'=>$cfg['revision'],'created_at'=>time(),'chunks'=>[],'window_chunks'=>[],'ranges'=>[[0,86400]],'token'=>'','window_rows'=>0,'rows'=>0,'truncated'=>false,'pages'=>0];
                    $saved=ArchiveStore::put('adsjob',$id,$job);if(empty($saved['success']))return $saved;
                }
                if($job['state']==='publish')return self::publish($job,$cfg,$id,$guard);
                if($e=$guard())return Response::fail($e);
                $range=$job['ranges'][0];$query=ArchiveQuery::gaql($dataset,$date,$range);$body=['query'=>$query];if($job['token']!=='')$body['pageToken']=$job['token'];
                $before=Audit::append('ads:archive.begin',$account,['mode'=>'read','status'=>'started','dataset'=>$dataset,'date'=>$date]);if(empty($before['success']))return self::fail('audit','Coleta suspensa: auditoria indisponível.');
                $raw=GoogleClient::post(AdsApi::base().'/customers/'.$account.'/googleAds:search',$body,['connector'=>'ads','mode'=>'read','operation_id'=>'googleads.customers.googleAds.search','headers'=>AdsApi::headers(),'scopes'=>[Credentials::SCOPE_ADS],'retries'=>0]);
                if(is_wp_error($raw))return Response::fail($raw,['state'=>'pending','remote_dispatched'=>true]);
                if($e=$guard())return Response::fail($e);
                if(isset($raw['results'])&&!is_array($raw['results'])||isset($raw['nextPageToken'])&&!is_string($raw['nextPageToken']))return self::fail('response','Página Ads inválida.');
                $rows=[];foreach($raw['results']??[] as $r){if(!is_array($r))return self::fail('response','Linha Ads inválida.');$row=ArchiveQuery::normalize($r,$dataset,$account,$date,$cfg);if(is_wp_error($row))return Response::fail($row);$rows[]=$row;}
                if(count($rows)>10000)return self::fail('response','A página excede o limite de 10.000 linhas do fornecedor.');
                $next=$raw['nextPageToken']??'';
                if($next!==''&&($next===$job['token']||!$rows))return self::fail('cursor','A API repetiu o cursor ou devolveu página vazia com continuação.');
                $after=Audit::append('ads:archive.end',$account,['mode'=>'read','status'=>'completed','rows'=>count($rows),'dataset'=>$dataset,'date'=>$date]);if(empty($after['success']))return self::fail('audit','Auditoria final não confirmada; cursor preservado.');
                $count=$job['window_rows']+count($rows);
                if($dataset==='changes'&&$count>=10000&&$range[1]-$range[0]>1){
                    $mid=intdiv($range[0]+$range[1],2);array_splice($job['ranges'],0,1,[[$range[0],$mid],[$mid,$range[1]]]);
                    $job['window_chunks']=[];$job['window_rows']=0;$job['token']='';
                } else {
                    foreach(array_chunk($rows,500) as $n=>$part){
                        $chunk=$job['revision'].'_'.$job['pages'].'_'.$n;
                        $saved=ArchiveStore::put('adsrows',$chunk,['rows'=>$part]);if(empty($saved['success']))return $saved;
                        $job['window_chunks'][]=['id'=>$chunk,'count'=>count($part)];
                    }
                    $job['window_rows']=$count;$job['token']=$next;
                    if($next===''){
                        $job['chunks']=array_merge($job['chunks'],$job['window_chunks']);$job['rows']+=$count;
                        if($dataset==='changes'&&$count>=10000)$job['truncated']=true;
                        $job['window_chunks']=[];$job['window_rows']=0;array_shift($job['ranges']);
                        if(!$job['ranges']){$job['state']='publish';$job['extracted_at']=time();}
                    }
                }
                $job['pages']++;if($e=$guard())return Response::fail($e);
                $saved=ArchiveStore::put('adsjob',$id,$job);if(empty($saved['success']))return $saved;
                if($job['state']==='publish')return self::publish($job,$cfg,$id,$guard);
                return Response::ok(['state'=>'pending','rows_persisted'=>$job['rows']+$job['window_rows'],'pages'=>$job['pages'],'revision'=>$job['revision'],'remote_dispatched'=>true]);
            },20,$guard);
        }finally{Lock::release($lock);}
    }
    private static function publish(array $job,array $cfg,string $id,callable $guard): array {
        if($e=$guard())return Response::fail($e);
        $manifest=['revision'=>$job['revision'],'account_id'=>$job['account_id'],'dataset'=>$job['dataset'],'date'=>$job['date'],'currency'=>$cfg['currency'],'time_zone'=>$cfg['time_zone'],'extracted_at'=>$job['extracted_at']??time(),'rows'=>$job['rows'],'chunks'=>$job['chunks'],'coverage'=>['pagination_complete'=>true,'truncated'=>$job['truncated'],'truncation_reason'=>$job['truncated']?'change_event_second_limit':null,'all_rows_guaranteed'=>false,'search_term_per_click'=>false,'api_omissions_possible'=>true,'source'=>'google_ads_api'],'retention_days'=>0];
        $r=ArchiveStore::put('adssnapshot',$job['revision'],$manifest);if(empty($r['success']))return $r;
        if($e=$guard())return Response::fail($e);
        $old=ArchiveStore::latest($job['account_id'],$job['dataset'],$job['date']);if(is_wp_error($old))return Response::fail($old);
        // A partial revisit never replaces a previously complete view.
        $publish=!$job['truncated']||!is_array($old)||!empty($old['coverage']['truncated']);
        if($publish){$r=ArchiveStore::put('adslatest',$id,['revision'=>$job['revision']]);if(empty($r['success']))return $r;}
        $job['state']='complete';$job['completed_at']=time();$r=ArchiveStore::put('adsjob',$id,$job);if(empty($r['success']))return $r;
        return Response::ok(['state'=>'complete','revision'=>$job['revision'],'published'=>$publish,'rows'=>$job['rows'],'coverage'=>$manifest['coverage'],'remote_dispatched'=>true]);
    }
    public static function cron(): void {
        if(!Options::is_enabled()||Recovery::guard()||State::guard()||(ExecutorSchedule::status()['desired_state']??'')!=='active')return;
        $registry=Connections::registry_verified();if(is_wp_error($registry))return;
        $targets=[];foreach(array_keys($registry) as $cid){$all=Connections::run($cid,static fn()=>self::config());if(is_array($all))foreach($all as $account=>$cfg)if(!empty($cfg['enabled']))$targets[]=[$cid,(string)$account,$cfg];}
        if(!$targets)return;
        $start=intdiv(time(),60)%count($targets);$targets=array_merge(array_slice($targets,$start),array_slice($targets,0,$start));
        Execution::run(static function()use($targets){
            foreach(array_slice($targets,0,4) as [$cid,$account,$cfg]){
                if(Execution::remaining()<3)break;
                if(!Options::user_authorized((int)($cfg['granted_by']??0)))continue;
                $prior=get_current_user_id();wp_set_current_user((int)$cfg['granted_by']);
                try{Connections::run($cid,static fn()=>Admission::run('ads:archive.cron',static fn()=>self::cycle($account,$cfg)));}finally{wp_set_current_user($prior);}
            }
        });
    }
    private static function cycle(string $account,array $cfg): array {
        if($e=self::guard($account,$cfg))return Response::fail($e);
        $lock=Lock::acquire('ads-plan:'.Connections::id().':'.$account,60);if(!$lock)return self::fail('busy','Planejador ocupado.');
        try{
            $id=ArchiveStore::key($account,'plan','');$plan=ArchiveStore::get('adsplan',$id);if(is_wp_error($plan))return Response::fail($plan);
            $today=(new \DateTimeImmutable('now',new \DateTimeZone($cfg['time_zone'])))->format('Y-m-d');
            if(!$plan||($plan['grant_revision']??'')!==$cfg['revision'])$plan=['grant_revision'=>$cfg['revision'],'backfill_offset'=>$cfg['revisit_days']+1,'backfill_index'=>0];
            if(($plan['cycle']??'')!==$today){$plan['cycle']=$today;$plan['revisit_offset']=1;$plan['revisit_index']=0;}
            for($skip=0;$skip<40;$skip++){
                if(empty($plan['working'])){
                    $plan['turn']=($plan['turn']??0)+1;
                    $idle=$plan['revisit_offset']>$cfg['revisit_days']&&$plan['backfill_offset']>$cfg['backfill_days'];
                    if($idle||$plan['turn']%3===0)foreach($plan['deferred']??[] as $key=>$retry){
                        if($retry['date']<ArchiveQuery::first_day($retry['dataset'],$today)){unset($plan['deferred'][$key]);continue;}
                        if($retry['retry_at']<=time()){$plan['working']=array_intersect_key($retry,array_flip(['dataset','date']));break;}
                    }
                }
                if(empty($plan['working'])){
                    $phase=$plan['revisit_offset']<=$cfg['revisit_days']?'revisit':'backfill';$offset=$plan[$phase.'_offset'];
                    if($phase==='backfill'&&$offset>$cfg['backfill_days'])return ArchiveStore::put('adsplan',$id,$plan)+['state'=>'idle'];
                    $dataset=$cfg['datasets'][$plan[$phase.'_index']];$date=(new \DateTimeImmutable($today,new \DateTimeZone('UTC')))->modify('-'.$offset.' days')->format('Y-m-d');
                    if(++$plan[$phase.'_index']>=count($cfg['datasets'])){$plan[$phase.'_index']=0;$plan[$phase.'_offset']++;}
                    $plan['working']=['dataset'=>$dataset,'date'=>$date];
                }
                $w=$plan['working'];
                $latest=ArchiveStore::latest($account,$w['dataset'],$w['date']);if(is_wp_error($latest))return Response::fail($latest);
                if($w['date']<ArchiveQuery::first_day($w['dataset'],$today)||(is_array($latest)&&($latest['extracted_at']??0)>=strtotime($today.' 00:00:00 '.$cfg['time_zone']))){unset($plan['working']);continue;}
                $saved=ArchiveStore::put('adsplan',$id,$plan);if(empty($saved['success']))return $saved;
                $r=self::advance($account,$w['dataset'],$w['date'],true);
                $plan['last_result']=array_intersect_key($r,array_flip(['success','state','revision','rows','coverage','error_code']));$plan['at']=time();
                $retryKey=$w['dataset'].'|'.$w['date'];
                if(($r['state']??'')==='complete'){unset($plan['working'],$plan['deferred'][$retryKey]);}
                elseif(empty($r['success'])){
                    $attempts=($plan['deferred'][$retryKey]['attempts']??0)+1;
                    $plan['deferred'][$retryKey]=$w+['attempts'=>$attempts,'retry_at'=>time()+min(21600,300*(2**min(6,$attempts-1)))];
                    unset($plan['working']); // One failed resource must not starve other days/datasets.
                }
                if(!Lock::owned($lock))return self::fail('lease','Reserva do planejamento expirou.');
                $saved=ArchiveStore::put('adsplan',$id,$plan);return empty($saved['success'])?$saved:$r;
            }
            return ArchiveStore::put('adsplan',$id,$plan)+['state'=>'pending'];
        }finally{Lock::release($lock);}
    }
    public static function output_schema(): array {
        return ['type'=>'object','properties'=>[
            'success'=>['type'=>'boolean'],'message'=>['type'=>'string'],'error_code'=>['type'=>'string'],
            'configuration_revision'=>['type'=>['string','null']],'accounts'=>['type'=>'array','items'=>['type'=>'object']],
            'archive'=>['type'=>'object'],'integration'=>['type'=>'object'],'scheduling'=>['type'=>'object'],
            'state'=>['type'=>'string','enum'=>['pending','complete','idle']],'revision'=>['type'=>['string','null']],
            'rows'=>['type'=>'integer'],'rows_persisted'=>['type'=>'integer'],'pages'=>['type'=>'integer'],
            'coverage'=>['type'=>'object'],'published'=>['type'=>'boolean'],'reused'=>['type'=>'boolean'],
            'remote_dispatched'=>['type'=>'boolean'],'remote_calls'=>['type'=>'boolean'],
            'retention_days'=>['type'=>'integer'],'retention'=>['type'=>'string'],'encrypted'=>['type'=>'boolean'],
            'collection_hook'=>['type'=>'string'],'datasets'=>['type'=>'array','items'=>['type'=>'string','enum'=>ArchiveQuery::DATASETS]],
            'provider_windows'=>['type'=>'object']]];
    }
    public static function register(): void {
        $account=['type'=>'string','pattern'=>'^[0-9]{10}$'];$dataset=['type'=>'string','enum'=>ArchiveQuery::DATASETS];
        Ability::register('ads/archive-status','any',['label'=>'Google Ads: estado do acervo','description'=>'Estado local de contas, revisita, backfill e retenção permanente. Não coleta nem repara agenda.','output_schema'=>self::output_schema(),'callback'=>[self::class,'status']]);
        Ability::register('ads/archive-configure','any',['label'=>'Google Ads: autorizar coleta do acervo','description'=>'Autoriza ou pausa coleta por conta, após confirmar moeda/fuso no Google. Não concede leitura a outro plugin. Retenção permanente.','mode'=>'write','input_schema'=>['required'=>['account_id','enabled','expected_revision'],'properties'=>['account_id'=>$account,'enabled'=>['type'=>'boolean'],'expected_revision'=>['type'=>'string'],'datasets'=>['type'=>'array','minItems'=>1,'uniqueItems'=>true,'items'=>$dataset],'backfill_days'=>['type'=>'integer','minimum'=>1,'maximum'=>1125,'default'=>90],'revisit_days'=>['type'=>'integer','minimum'=>1,'maximum'=>30,'default'=>7]]],'output_schema'=>self::output_schema(),'callback'=>[self::class,'configure']]);
        Ability::register('ads/archive-collect','any',['label'=>'Google Ads: avançar coleta de um dia','description'=>'Avança uma página e persiste checkpoint cifrado. Continue enquanto state=pending. refresh inicia revisita de recorte concluído. Sem mutação no Google.','mode'=>'write','input_schema'=>['required'=>['account_id','dataset','date'],'properties'=>['account_id'=>$account,'dataset'=>$dataset,'date'=>['type'=>'string','pattern'=>'^\\d{4}-\\d{2}-\\d{2}$'],'refresh'=>['type'=>'boolean','default'=>false]]],'output_schema'=>self::output_schema(),'callback'=>[self::class,'collect']]);
    }
}
