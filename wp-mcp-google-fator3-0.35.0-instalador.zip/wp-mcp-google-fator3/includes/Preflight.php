<?php
/**
 * Read-only probes of the chosen resources, with machine-readable states.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Http\GoogleClient;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Preflight {
	public static function run( array $input = array() ): array {
		if ( isset( $input['services'] ) && ( ! is_array( $input['services'] ) || array_diff( $input['services'], array_keys( Setup::LEVELS ) ) ) ) {
			return Response::fail(
				new \WP_Error( 'f3_google_preflight_input', 'Lista de serviços inválida.' ),
				array(
					'execution_success' => false,
					'checks_passed'     => false,
				)
			);
		}
		$validation = Setup::plan( array_intersect_key( $input, array( 'bindings' => true ) ) );
		if ( ! $validation['success'] ) {
			return $validation + array(
				'execution_success' => false,
				'checks_passed'     => false,
			);
		}
		$bindings = $input['bindings'] ?? Options::get( Connections::BINDINGS, array() );
		$bindings = is_array( $bindings ) ? $bindings : array();
		$checks   = array();
		foreach ( array( 'ga', 'ads', 'gsc', 'siteverification', 'sheets', 'drive', 'gtm' ) as $service ) {
			if ( ! empty( $input['services'] ) && ! in_array( $service, $input['services'], true ) ) {
				continue;
			}
			$on = Connections::enabled( $service ) && ( 'ga' !== $service || Options::ga_enabled() ) && ( 'ads' !== $service || Options::ads_enabled() );
			if ( ! $on ) {
				$checks[] = self::check( $service, 'skipped', 'Serviço desativado.' );
				continue;
			}
			$credentials = Credentials::current();
			if ( is_wp_error( $credentials ) ) {
				$checks[] = self::check( $service, in_array( $credentials->get_error_code(), array( 'f3_google_crypto_decrypt', 'f3_google_option_read' ), true ) ? 'failed' : 'not_configured', $credentials->get_error_message(), $credentials );
				continue;
			}
			$opts   = array(
				'scopes'  => Credentials::scopes_for( $service ),
				'mode'    => 'read',
				'retries' => 0,
			);
			$target = '';
			switch ( $service ) {
				case 'gtm':
					$target   = (string) ( $bindings['gtm_container_path'] ?? '' );
					$response = '' !== $target ? TagManager\Api::call( 'containers.get', array( 'path' => $target ) ) : TagManager\Api::call( 'list' );
					break;
				case 'ga':
					$target   = (string) ( $bindings['ga_property_id'] ?? Options::get( Options::GA_DEFAULT_PROPERTY, '' ) );
					$response = '' === $target ? GoogleClient::get( GoogleClient::HOST_GA_ADMIN . '/v1beta/accountSummaries', array( 'pageSize' => 1 ), $opts ) : GoogleClient::get( GoogleClient::HOST_GA_ADMIN . '/v1beta/properties/' . rawurlencode( preg_replace( '~^properties/~', '', $target ) ), array(), $opts );
					break;
				case 'ads':
					if ( ! Ads\PlannerAccess::project_access() ) {
						$checks[] = self::check( $service, 'not_configured', 'Declare o nível de acesso do projeto em Conexão → Serviços e recursos.' );
						continue 2;
					}
					$target   = (string) ( $bindings['ads_customer_id'] ?? '' );
					$response = '' !== $target ? Ads\AdsApi::customer( $target ) : Ads\AdsApi::list_accessible_customers();
					break;
				case 'gsc':
					$target   = (string) ( $bindings['gsc_site_url'] ?? '' );
					$url      = GoogleClient::HOST_GOOGLE . '/webmasters/v3/sites' . ( '' !== $target ? '/' . rawurlencode( $target ) : '' );
					$response = GoogleClient::get( $url, array(), $opts );
					break;
				case 'siteverification':
					$response = GoogleClient::get( GoogleClient::HOST_GOOGLE . '/siteVerification/v1/webResource', array(), $opts );
					break;
				case 'sheets':
					$target = (string) ( $bindings['spreadsheet_id'] ?? '' );
					if ( '' === $target ) {
						$checks[] = self::check( $service, 'not_configured', 'Selecione spreadsheet_id para testar acesso ao arquivo.' );
						continue 2;
					}
					$response = GoogleClient::get( GoogleClient::HOST_SHEETS . '/v4/spreadsheets/' . rawurlencode( $target ), array( 'fields' => 'spreadsheetId' ), $opts );
					break;
				default:
					$target   = (string) ( $bindings['spreadsheet_id'] ?? '' );
					$response = GoogleClient::get(
						GoogleClient::HOST_GOOGLE . '/drive/v3/files' . ( '' !== $target ? '/' . rawurlencode( $target ) : '' ),
						'' !== $target ? array(
							'fields'            => 'id',
							'supportsAllDrives' => true,
						) : array(
							'pageSize' => 1,
							'fields'   => 'files(id)',
						),
						$opts
					);
			}
			$check                    = is_wp_error( $response ) ? self::check( $service, 'failed', $response->get_error_message(), $response ) : self::check( $service, 'passed', '' !== $target ? 'Leitura do recurso concluída.' : 'API respondeu à listagem; acesso a um recurso específico não foi testado.' );
			$check['target']          = $target;
			$check['resource_tested'] = '' !== $target;
			$checks[]                 = $check;
		}
		$result                   = SelfTest::summarize( $checks );
		$provider                 = Credentials::current();
		$result['credential']     = is_wp_error( $provider ) ? array( 'configured' => false ) : $provider->describe();
		$result['site_url']       = home_url();
		$result['plugin_version'] = F3_MCP_GOOGLE_VERSION;
		$result['connection_id']  = Connections::id();
		$result['checked_at']     = gmdate( 'c' );
		$last_http                = \Fator3\McpGoogle\Cache::get( 'f3_mcp_google_http_' . Connections::id() );
		$result['last_http']      = $last_http ? $last_http : null;
		\Fator3\McpGoogle\Auth\Validation::observe_access($result);
		return $result;
	}
	private static function check( string $service, string $status, string $detail, $error = null ): array {
		return array(
			'name'       => 'live_' . $service,
			'status'     => $status,
			'ok'         => 'passed' === $status,
			'detail'     => $detail,
			'error_code' => is_wp_error( $error ) ? $error->get_error_code() : null,
			'error'      => is_wp_error( $error ) ? Response::fail( $error ) : null,
		);
	}
}
