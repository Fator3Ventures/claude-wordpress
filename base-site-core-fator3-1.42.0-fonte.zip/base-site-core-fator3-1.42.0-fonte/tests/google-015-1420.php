<?php
require __DIR__.'/bootstrap.php';require getenv('F3BASE_ROOT').'/google-dependency/wp-mcp-google-fator3/wp-mcp-google-fator3.php';\Fator3\McpGoogle\Storage\State::ensure_ready();function verifyLab($name,$ok,$detail=null){if(!$ok){echo wp_json_encode($detail)."\n";}check($ok,$name);}function google_config_digestLab(){return '';}
use Fator3\McpGoogle\{ConversionDelivery as D,Options as O,Connections as C,Policy,Settings,Configuration,CoreConversions};
wp_get_abilities();verifyLab('Native Core worker hook registered',has_action('f3base_conversoes_servidor')!==false,['installation'=>F3Base_Instalacao::resumo(),'recovery'=>F3Base_Recuperacao::ler()]);$calls=[];$scenario='ok';$secret='synthetic-mp-014';
$fixture=static function($pre,$args,$url)use(&$calls,&$scenario,$secret){
 if(str_starts_with($url,'http://127.0.0.1'))return $pre;
 $calls[]=[$url,$args];$body=[];$code=200;
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access014','expires_in'=>3600];
 elseif(str_contains($url,'measurementProtocolSecrets'))$body=['measurementProtocolSecrets'=>[['secretValue'=>$scenario==='wrong-secret'?'different':$secret]]];
 elseif(str_contains($url,'analyticsadmin.googleapis.com'))$body=['name'=>'properties/123/dataStreams/456','webStreamData'=>['measurementId'=>$scenario==='wrong-stream'?'G-WRONG':'G-TEST014']];
 elseif(str_contains($url,'/debug/mp/collect'))$body=['validationMessages'=>$scenario==='bad-debug'?[['description'=>'invalid fixture']]:[]];
 elseif(str_contains($url,'/mp/collect')){if($scenario==='timeout')return new WP_Error('http_request_failed','fixture timeout');$code=204;}
 elseif(str_contains($url,'googleAds:search'))$body=['results'=>[['conversionAction'=>['resourceName'=>'customers/1234567890/conversionActions/789','type'=>'UPLOAD_CLICKS','status'=>'ENABLED']]]];
 elseif(str_contains($url,':uploadClickConversions')){
  if($scenario==='timeout')return new WP_Error('http_request_failed','fixture timeout');
  $sent=json_decode($args['body'],true)['conversions'][0];$result=array_intersect_key($sent,array_flip(['conversionAction','conversionDateTime','gclid','gbraid','wbraid']));
  if($scenario==='action-only')$result=['conversionAction'=>$sent['conversionAction']];
  if($scenario==='wrong-click')$result['gclid']='another';
  $body=$scenario==='partial'?['partialFailureError'=>['code'=>3]]:['results'=>[$result]];
 }else return $pre;
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>$code===204?'':wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
$before=google_config_digestLab();$r=D::status();verifyLab('Local status needs no provider call',$r['success']&&count($calls)===0&&$before===google_config_digestLab());
verifyLab('Unconfigured adapter is unready',!(new D('ga4'))->capabilities()['ready']);
$existing=new stdClass();verifyLab('Preserves other adapter',D::adapter($existing,'ga4',D::CONTRACT)===$existing);verifyLab('Unsupported contract does not register',D::adapter(null,'ga4','unknown')===null);
$config=['enabled'=>true,'measurement_id'=>'G-TEST014','stream'=>'properties/123/dataStreams/456','customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789'];
$r=D::configure(['expected_revision'=>str_repeat('0',64),'config'=>$config]);verifyLab('Stale config revision refused',!$r['success']&&$r['conflict']);
$r=D::configure(['expected_revision'=>D::revision(),'config'=>$config+['value'=>123]]);verifyLab('Unknown config fields refused',!$r['success']);
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-014',O::OAUTH_REFRESH_TOKEN=>'synthetic-014',O::ADS_DEVELOPER_TOKEN=>'synthetic-dev014']);
$r=D::configure(['expected_revision'=>D::revision(),'config'=>$config,'mp_secret'=>$secret]);verifyLab('Configuration and encrypted secret persisted',$r['success']&&O::get_secret(D::SECRET)===$secret&&get_option(D::SECRET)!==$secret,$r);
verifyLab('Configuration alone cannot authorize delivery',!(new D('ga4'))->capabilities()['ready']);
$scenario='wrong-stream';$r=D::verify(['expected_revision'=>D::revision(),'target'=>'ga4']);verifyLab('Rejects unrelated stream measurement',$r['code']==='stream_unverified',$r);
$scenario='wrong-secret';$r=D::verify(['expected_revision'=>D::revision(),'target'=>'ga4']);verifyLab('Debug alone cannot validate MP secret',$r['code']==='mp_secret_unverified',$r);
$scenario='ok';$r=D::verify(['expected_revision'=>D::revision(),'target'=>'ga4']);verifyLab('GA4 verifies ownership secret and debug',$r['success'],$r);
verifyLab('Verification makes GA4 locally ready',(new D('ga4'))->capabilities()['ready']);
$r=D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);verifyLab('Developer token alone never proves upload eligibility',$r['code']==='eligibility_attestation_required');
$receipt=['customer_id'=>$config['customer_id'],'conversion_action'=>$config['conversion_action'],'successful_upload_confirmed'=>true,'request_id'=>'synthetic-receipt014'];
$r=D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads','eligibility_receipt'=>$receipt]);verifyLab('Ads verifies action with explicit administrative attestation',$r['success'],$r);
verifyLab('Attestation provenance remains explicit',D::status()['ads_eligibility_source']==='administrator_attestation_and_action_read');
$ga=new D('ga4');$ads=new D('google_ads');$now=time()-5;$id=str_repeat('a',32);
$payload=['record_id'=>$id,'event_id'=>$id,'occurred_at'=>gmdate('c',$now),'measurement_id'=>$config['measurement_id'],'event_name'=>'generate_lead','client_id'=>'123.456','session_id'=>'42','timestamp_micros'=>$now*1000000];
function dispatch014($adapter,$payload){try{wp_set_current_user(0);return $adapter->send($payload);}finally{wp_set_current_user(1);}}
$r=dispatch014($ga,$payload);verifyLab('Stored background grant works without impersonation',$r['status']==='entregue'&&$r['processed']===null,$r);$sent=json_decode(end($calls)[1]['body'],true);
verifyLab('GA4 preserves client session event and original timestamp',$sent['client_id']===$payload['client_id']&&$sent['timestamp_micros']===$payload['timestamp_micros']&&$sent['events'][0]['params']['session_id']==='42'&&$sent['events'][0]['params']['event_id']===$id);
verifyLab('GA4 does not fabricate engagement',!isset($sent['events'][0]['params']['engagement_time_msec']));
$scenario='bad-debug';$n=count($calls);$r=dispatch014($ga,$payload);verifyLab('Failed debug prevents collection',$r['status']==='recusado'&&$r['non_delivery_proven']&&count($calls)===$n+1,$r);
$scenario='timeout';$n=count($calls);$r=dispatch014($ga,$payload);verifyLab('GA4 timeout is uncertain and never retried',$r['status']==='incerto'&&count($calls)===$n+2,$r);
$scenario='ok';$expired=$payload;$expired['occurred_at']=gmdate('c',$now-73*3600);$expired['timestamp_micros']=($now-73*3600)*1000000;$n=count($calls);verifyLab('GA4 rejects outside collection window without HTTP',dispatch014($ga,$expired)['status']==='recusado'&&count($calls)===$n);
$p=['record_id'=>$id,'event_id'=>$id,'order_id'=>$id,'occurred_at'=>gmdate('c',$now),'click_ids'=>['gclid'=>'original-click'],'ad_user_data'=>'GRANTED','value'=>37.5,'currency'=>'BRL'];
$r=dispatch014($ads,$p);verifyLab('Ads accepts matching individual result',$r['status']==='entregue',$r);$sent=json_decode(end($calls)[1]['body'],true);$one=$sent['conversions'][0];
verifyLab('Ads preserves order value currency and consent',count($sent['conversions'])===1&&$one['orderId']===$id&&$one['conversionValue']===37.5&&$one['currencyCode']==='BRL'&&$one['consent']['adUserData']==='GRANTED');
foreach(['action-only','wrong-click','partial','timeout'] as $scenario){$n=count($calls);$r=dispatch014($ads,$p);verifyLab('Ads '.$scenario.' remains uncertain without HTTP replay',$r['status']==='incerto'&&count($calls)===$n+1,$r);}
$scenario='ok';$bad=$p;$bad['click_ids']['wbraid']='another';$n=count($calls);verifyLab('Ambiguous click IDs rejected before HTTP',dispatch014($ads,$bad)['status']==='recusado'&&count($calls)===$n);
$bad=$p;$bad['ad_user_data']='DENIED';verifyLab('Missing consent prevents upload',dispatch014($ads,$bad)['status']==='recusado');
$n=count($calls);$before=google_config_digestLab();$status=D::status();verifyLab('Ready status is still strictly local',count($calls)===$n&&$before===google_config_digestLab()&&!str_contains(wp_json_encode($status),$secret));
verifyLab('Old and negotiated Core read contracts coexist',CoreConversions::snapshot()['ok']&&(!class_exists('F3Base_Conversoes_Contexto')||$status['core_transport']['ok']),$status['core_transport']);
ob_start();D::screen();$html=ob_get_clean();verifyLab('Administrative form has fields nonce and no secret echo',str_contains($html,'type="password"')&&str_contains($html,'_wpnonce')&&!str_contains($html,$secret));

$scenario='ok';$n=count($calls);$ref=$ga->capabilities()['destination_ref'];
$r=$ga->sendBound($payload,'wrong');check($r['code']==='destination_mismatch'&&count($calls)===$n,'bound_wrong_destination_no_http');
$r=$ga->sendBound($payload,$ref);check($r['status']==='entregue','bound_current_destination_delivered');
check(is_callable(array($ga,'sendBound')),'binding_extension_negotiated');

$wpdb->query('DELETE FROM '.F3Base_Conversoes_Servidor::tabela());
raw('f3base_conversoes_transporte',['ga4'=>'servidor','google_ads'=>'navegador']);
$record=F3Base_Leads_Repositorio::guardar(['nome'=>'Synthetic integration','email'=>'integration141@example.test','metodo'=>'formulario','captura'=>'aceito','formulario'=>'fixture141','contexto_teste'=>false,'notificar'=>false]);
$lead=F3Base_Leads_Repositorio::obter($record['record_id']);$data=$lead['dados'];$data['audiencia_excluida']=false;
$data['consentimento_snapshot']=['medicao'=>true,'publicidade'=>true,'politica_versao'=>'legado:'.F3Base_Modulo_Consentimento::politica_versao()];
$data['ga4']=['client_id'=>'123.456','session_id'=>(string)(time()-10),'measurement_id'=>'G-TEST014','session_evidence'=>['source'=>'google_tag_native','started_at'=>time()-10,'observed_at'=>time(),'received_at'=>time()]];
$wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>wp_json_encode($data),'classe_trafego'=>'nao_marcado'],['record_id'=>$record['record_id']]);
F3Base_Conversoes_Servidor::processar();$rows=F3Base_Conversoes_Servidor::ler(['record_id'=>$record['record_id']])['entregas'];check($rows[0]['estado']==='entregue'&&$rows[0]['destino_ref']===$ref,'core_actual_google_bound_delivery');
$n=count($calls);F3Base_Conversoes_Servidor::processar();check(count($calls)===$n,'core_actual_google_no_replay');
$r=D::configure(['expected_revision'=>D::revision(),'config'=>array_merge($config,['measurement_id'=>'G-OTHER'])]);
$r=$ga->sendBound($payload,$ref);check($r['status']==='recusado','changed_configuration_refused');
evidence('google-015-1420');
