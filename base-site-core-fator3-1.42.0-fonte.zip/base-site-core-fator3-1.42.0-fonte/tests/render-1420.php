<?php
require __DIR__.'/bootstrap.php';
require_once ABSPATH.'wp-admin/includes/template.php';
$method=new ReflectionMethod(F3Base_Admin_Tela::class,'render_formulario');$method->setAccessible(true);
$dir=getenv('F3BASE_ROOT').'/lab/render';wp_mkdir_p($dir);$sizes=array();
foreach(F3Base_Interface::secoes() as $key=>$section){$_GET['secao']=$key;ob_start();$method->invoke(null);$html=ob_get_clean();check(strlen($html)>100,'render_'.$key);check(!str_contains($html,'Escolha conforme o fluxo descrito'),'no_generic_'.$key);$sizes[$key]=strlen($html);file_put_contents($dir.'/'.$key.'.html','<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:16px system-ui;margin:30px;color:#222;background:#f5f5f5}table{width:100%}th{text-align:left;width:250px}td,th{padding:12px;vertical-align:top}input,select,textarea{max-width:100%;padding:6px}details{margin:10px 0}p{max-width:90ch}nav a{display:inline-block;padding:8px}</style><h1>'.esc_html($section['titulo']).'</h1>'.$html.'</html>');}
foreach(array('f3base_email_novo_lead','credenciais') as $key){$_GET['integracao']=$key;ob_start();F3Base_Integracoes::render();$html=ob_get_clean();check(strlen($html)>100,'render_'.$key);check(!preg_match('/\bC[01]\b/',$html),'rotulos_'.$key);file_put_contents($dir.'/'.$key.'.html','<!doctype html><meta charset="utf-8"><h1>Configuração</h1>'.$html);}
evidence('render-1420');
