# Core 1.42.0 — escopo da implementação

Base: 1.41.0, SHA-256 66ae54be3b0ec7a066187455b8358fc3c3431a47de8fc6aa8ac8c5efa3510919. Pedidos core 238–242 da lista (10). Preservar versões publicadas.

238: reduzir histórico comercial e manter deduplicação privada. 239: configuração SMTP, estado e campos de segredos ausentes. 240: confirmação sem prazo/canal prometido. 241: nomes descritivos, configuração por site, migração e aliases por uma versão. 242: schema único de entrada para os dois contratos existentes.

Fronteiras avaliadas: Google 0.15 já incorporou sendBound e não pede desenvolvimento Core; MCP transporta as abilities e descobre os schemas vigentes. Meta/LinkedIn não têm contrato alterado: apenas acesso administrativo a credenciais já existentes. Sem nova dependência ou impacto de desenvolvimento identificado em outro plugin. Consumidores administrativos devem redescobrir contrato 8.7.0 e usar nomes atuais; aliases das duas abilities anteriores duram esta versão. Não foi presumida inspeção do código do Implantador.

Validar instalação limpa, upgrade da 1.41, segredos e incerteza preservados, autorização, UI renderizada, ambos os contratos, diário Pipedrive, Google 0.15 e ajuda paginada. Homologação de fornecedor e instalação remota são provas distintas e dependem da publicação pela frota.
