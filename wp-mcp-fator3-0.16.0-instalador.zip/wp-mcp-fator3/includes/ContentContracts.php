<?php
/** Versioned content contracts: aliases, selective reads, patches and final readback. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ContentContracts {
    public static function aliases(string $name,array $input) {
        $pairs=['rotulo'=>'label','campos'=>'fields','contar'=>'exact'];
        if($name==='audit/list'){$pairs['before']='cursor';$pairs['path']='target';}
        if($name==='backups/prune')$pairs['selection_sha256']='expected_selection_sha256';
        if(str_starts_with($name,'content/')) $pairs['parent_id']='parent';
        foreach($pairs as $alias=>$canonical) if(array_key_exists($alias,$input)) {
            if(array_key_exists($canonical,$input)&&$input[$canonical]!==$input[$alias]) return new \WP_Error('alias_conflict','Aliases possuem valores diferentes: '.$alias.' e '.$canonical.'.');
            $input[$canonical]=$input[$alias];unset($input[$alias]);
        }
        if(isset($input['prefixo'])) {
            $prefixes=(array)$input['prefixo'];
            if(isset($input['prefixes'])&&(array)$input['prefixes']!==$prefixes) return new \WP_Error('alias_conflict','prefixo e prefixes diferem.');
            $input['prefixes']=$prefixes;unset($input['prefixo']);
        }
        return $input;
    }
    public static function raw(int $id) {
        global $wpdb;
        $row=$wpdb->get_row($wpdb->prepare("SELECT post_content,CHAR_LENGTH(post_content) AS char_length,LENGTH(post_content) AS bytes FROM {$wpdb->posts} WHERE ID=%d",$id),ARRAY_A);
        if(!$row||$wpdb->last_error) return new \WP_Error('content_readback_failed','Não foi possível verificar conteúdo persistido.');
        return ['content'=>$row['post_content'],'char_length'=>(int)$row['char_length'],'bytes'=>(int)$row['bytes'],'sha256'=>hash('sha256',$row['post_content'])];
    }
    public static function patch(array $input,string $kind): array {
        $id=(int)($input['id']??0);$post=get_post($id);
        if(!$post || ($kind==='page' && $post->post_type!=='page')) return Result::fail('not_found','Conteúdo não encontrado.');
        if(!current_user_can('edit_post',$id)) return Result::fail('permission_denied','Sem permissão para editar este conteúdo.');
        $find=(string)($input['find']??'');$replacement=(string)($input['replace']??'');
        if($find==='') return Result::fail('find_required','find não pode ser vazio.');
        $limit=(int)($input['limit']??-1);
        if($limit===0||$limit< -1||$limit>10000) return Result::fail('invalid_limit','limit deve ser -1 ou entre 1 e 10000.');
        if(isset($input['all'])&&!$input['all']&&$limit>1) return Result::fail('conflicting_patch_options','all:false exige unicidade e não admite limit maior que 1.');
        $unique=isset($input['all']) ? !$input['all'] : $limit<1;
        $old=$post->post_content;$count=0;
        if(!empty($input['regex'])) {
            $valid=RegexGuard::validate($find);if($valid) return Result::error($valid);
            $probe=RegexGuard::run(static function() use($find,$old) { return @preg_match_all($find,$old,$m,PREG_PATTERN_ORDER); });
            if(false===$probe) return Result::fail('regex_execution_failed','PCRE excedeu o orçamento ou o texto é incompatível.');
            $matches=$probe;
            if($unique && $matches>1) return Result::fail('patch_not_unique','Há mais de uma correspondência; use all:true ou limit explícito.', ['matches'=>$matches]);
            $new=RegexGuard::run(static function() use($find,$replacement,$old,$limit,&$count) { return @preg_replace($find,$replacement,$old,$limit,$count); });
            if(null===$new) return Result::fail('regex_execution_failed','Falha na substituição PCRE; nada foi gravado.');
        } else {
            $matches=substr_count($old,$find);
            if($unique&&$matches>1) return Result::fail('patch_not_unique','Há mais de uma correspondência; use all:true ou limit explícito.', ['matches'=>$matches]);
            $new=$old;$pos=0;
            while(($limit<0||$count<$limit)&&false!==($pos=strpos($new,$find,$pos))) { $new=substr_replace($new,$replacement,$pos,strlen($find));$pos+=strlen($replacement);$count++; }
        }
        if(strlen($new)>PathGuard::max_bytes()) return Result::fail('content_size_limit','Conteúdo final excede o limite do canal.');
        if($new!==$old) { $saved=wp_update_post(wp_slash(['ID'=>$id,'post_content'=>$new]),true);if(is_wp_error($saved)) return Result::error($saved); }
        clean_post_cache($id);$raw=self::raw($id);if(is_wp_error($raw)) return Result::error($raw);
        $actual=$raw['content'];unset($raw['content']);
        $data=$raw+['id'=>$id,'replacements'=>$count,'changed'=>$actual!==$old,'applied'=>$actual!==$old,'persisted'=>true,'revision'=>ContentTools::revision($id),'link'=>get_permalink($id)];
        if($actual!==$new) return Result::fail('content_filtered','Conteúdo persistido difere do solicitado; não repetir automaticamente.', $data+['expected_sha256'=>hash('sha256',$new)]);
        return Result::ok($data,$count?'Substituição verificada.':'Nenhuma correspondência; conteúdo preservado.');
    }
    public static function read(array $input,string $kind,callable $legacy): array {
        $post=!empty($input['id'])?get_post((int)$input['id']):null;
        if(!$post&&!empty($input['slug'])&&$kind!=='revision') $post=get_page_by_path($input['slug'],OBJECT,$kind==='page'?'page':'post');
        if(!$post||($kind==='page'&&$post->post_type!=='page')||($kind==='revision'&&$post->post_type!=='revision')) return Result::fail('not_found','Conteúdo não encontrado.');
        return Locks::run(['post:'.get_current_blog_id().':'.$post->ID=>LOCK_SH],static function() use($post,$input,$legacy,$kind) {
            clean_post_cache($post->ID);$post=get_post($post->ID);
            if(!$post||!current_user_can('read_post',$post->ID)||($kind==='revision'&&!current_user_can('read_post',(int)$post->post_parent))) return Result::fail('permission_denied','Sem permissão para ler este conteúdo e seu pai.');
            if(!isset($input['fields'])) { $result=$legacy($input);if(false===($result['success']??true)) return $result; }
            else {
                $fields=$input['fields'];$result=['success'=>true,'id'=>$post->ID];
                $map=['title'=>'post_title','slug'=>'post_name','status'=>'post_status','content'=>'post_content','excerpt'=>'post_excerpt','parent'=>'post_parent','parent_id'=>'post_parent','menu_order'=>'menu_order','date'=>'post_date','modified'=>'post_modified','author_id'=>'post_author','post_type'=>'post_type'];
                foreach($map as $key=>$property) if(in_array($key,$fields,true)) $result[$key]=in_array($key,['parent','parent_id','menu_order','author_id'],true)?(int)$post->$property:$post->$property;
                if(in_array('link',$fields,true)) $result['link']=get_permalink($post->ID);
                if(in_array('featured_image',$fields,true)) $result['featured_image']=get_the_post_thumbnail_url($post->ID,'full')?:'';
                if(in_array('template',$fields,true)) $result['template']=get_page_template_slug($post->ID)?:'';
                foreach(['author_name','author'] as $key) if(in_array($key,$fields,true)) { $author=get_user_by('id',$post->post_author);$result[$key]=$author?$author->display_name:''; }
                foreach(['categories'=>'category','tags'=>'post_tag'] as $key=>$taxonomy) if(in_array($key,$fields,true)) { $terms=wp_get_object_terms($post->ID,$taxonomy);if(is_wp_error($terms))return Result::error($terms);$result[$key]=array_map(static fn($t)=>['id'=>$t->term_id,'name'=>$t->name,'slug'=>$t->slug],$terms); }
            }
            $raw=self::raw($post->ID);if(is_wp_error($raw))return Result::error($raw);unset($raw['content']);
            foreach($raw as $key=>$value) if(!isset($input['fields'])||in_array($key,$input['fields'],true)) $result[$key]=$value;
            if(!isset($input['fields'])||in_array('revision',$input['fields'],true)) $result['revision']=ContentTools::revision($post->ID);
            if($kind==='revision'&&in_array('parent_revision',$input['fields']??[],true)) $result['parent_revision']=ContentTools::revision((int)$post->post_parent);
            return $result;
        });
    }
    public static function option(array $input): array {
        $name=(string)$input['name'];$missing=new \stdClass();$value=get_option($name,$missing);
        if($value===$missing) return Result::fail('option_not_found','Option ausente.');
        $secret=DataSafety::secret_key($name);
        if(array_key_exists('key',$input)) {
            if(!is_array($value)) return Result::fail('option_type_conflict','key exige option do tipo array.');
            if(!array_key_exists($input['key'],$value)) return Result::fail('option_key_not_found','Chave ausente.');
            $secret=$secret||DataSafety::secret_key((string)$input['key']);$value=$value[$input['key']];
        }
        $type=gettype($value);$redacted=[];
        $walk=static function($v,string $path='value') use (&$walk,&$redacted) {
            if(is_object($v)) { $redacted[]=$path;return '[redigido]'; }
            if(is_array($v)) foreach($v as $k=>&$child) { if(DataSafety::secret_key((string)$k)) { $redacted[]=$path.'.'.$k;$child='[redigido]'; } else $child=$walk($child,$path.'.'.$k); }
            return $v;
        };
        if($secret) { $value='[redigido]';$redacted=['value']; } else $value=$walk($value);
        return Result::ok(['name'=>$name,'value'=>$value,'type'=>$type,'redacted'=>$redacted,'value_source'=>'get_option_effective']+(array_key_exists('key',$input)?['key'=>$input['key']]:[]));
    }
    public static function schema(array $args,string $name): array {
        $props=&$args['input_schema']['properties'];
        if(str_starts_with($name,'content/') && isset($props['parent'])) { $props['parent_id']=$props['parent'];$args['description']=str_replace('parent_id','parent (alias parent_id)',$args['description']); }
        if(in_array($name,['content/patch-post','content/patch-page'],true)) {
            $props['all']=Registry::boolean();$props['limit']=['type'=>'integer','minimum'=>-1,'maximum'=>10000,'description'=>'-1 ou 1–10000. Sem all:true nem limite positivo explícito, exige unicidade; zero inválido. Regex também respeita o limite.'];
            $args['description']='Altera conteúdo com revisão e lock. Padrão exige unicidade; all:true autoriza todas, limit positivo limita literal/PCRE. Confere SHA-256, bytes e CHAR_LENGTH persistidos; divergência retorna content_filtered.';
            $args['execute_callback']=static fn($input)=>self::patch($input,str_ends_with($name,'page')?'page':'post');
        }
        if(in_array($name,['content/get-page','content/get-post','content/get-revision'],true)) {
            $fields=['id','title','slug','status','content','excerpt','parent','parent_id','menu_order','date','modified','author_id','author_name','author','featured_image','template','categories','tags','link','revision','sha256','char_length','bytes','post_type'];
            if($name==='content/get-revision')$fields[]='parent_revision';
            $props['fields']=['type'=>'array','items'=>['type'=>'string','enum'=>$fields],'minItems'=>1,'uniqueItems'=>true];
            $callback=$args['execute_callback'];$kind=substr($name,12);
            $args['execute_callback']=static fn($input)=>self::read($input,$kind,$callback);
        }
        if($name==='options/get') { $props['key']=['type'=>['string','integer'],'description'=>'Chave literal de primeiro nível; não interpreta caminho JSON.'];$args['execute_callback']=[self::class,'option']; }
        return $args;
    }
}
