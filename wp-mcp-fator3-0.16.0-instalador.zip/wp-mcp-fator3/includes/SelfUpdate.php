<?php
/** Preload the complete private runtime before replacing any of its source files. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SelfUpdate {
    public static function preload() {
        $count=0;
        try{
            foreach(['core/includes','core/vendor'] as $folder){
                $it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator(F3_MCP_FILES_DIR.$folder,\FilesystemIterator::SKIP_DOTS));
                foreach($it as $file){if(!$file->isFile()||$file->getExtension()!=='php')continue;$tokens=token_get_all((string)file_get_contents($file->getPathname()));$namespace='';
                    foreach($tokens as $i=>$token){if(!is_array($token))continue;
                        if($token[0]===T_NAMESPACE){$namespace='';for($j=$i+1;isset($tokens[$j])&&!in_array($tokens[$j],[';','{'],true);$j++)if(is_array($tokens[$j])&&in_array($tokens[$j][0],[T_STRING,T_NAME_QUALIFIED,T_NS_SEPARATOR],true))$namespace.=$tokens[$j][1];}
                        if(!in_array($token[0],[T_CLASS,T_INTERFACE,T_TRAIT,T_ENUM],true)||!str_starts_with($namespace,'WpMcpUltimate\\'))continue;
                        $j=$i+1;while(isset($tokens[$j])&&is_array($tokens[$j])&&in_array($tokens[$j][0],[T_WHITESPACE,T_COMMENT,T_DOC_COMMENT],true))$j++;
                        if(!isset($tokens[$j])||!is_array($tokens[$j])||$tokens[$j][0]!==T_STRING)continue;$class=$namespace.'\\'.$tokens[$j][1];
                        if(str_starts_with($class,'WpMcpUltimate\\Server\\Cli\\')&&!(defined('WP_CLI')&&WP_CLI))continue;
                        if(!class_exists($class)&&!interface_exists($class)&&!trait_exists($class))return new \WP_Error('self_update_preload_failed','Classe privada não pôde ser pré-carregada.',['class'=>$class]);$count++;
                    }
                }
            }
            return ['preloaded_private_types'=>$count,'recovery_runtime'=>'mu-plugin-v1'];
        }catch(\Throwable $e){return new \WP_Error('self_update_preload_failed','Pré-carregamento incompleto; servidor não alterado.',['class'=>$class??null,'exception_type'=>get_class($e)]);}
    }
}
