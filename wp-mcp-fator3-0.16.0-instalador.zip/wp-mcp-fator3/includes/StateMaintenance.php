<?php
/** Explicit, bounded state retention. Tombstones preserve consumed identities. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class StateMaintenance {
    private const CATEGORIES = ['audit','oauth-clients','oauth-codes','oauth-tokens','sessions','transfers','idempotency'];

    public static function register(): void {
        Registry::add('system/maintenance', 'Simula manutenção em lotes de até 100 registros. dry_run:false exige expected_selection_sha256 da prévia e preserva estados ativos/incertos. Tokens expirados viram comprovantes sem segredo; idempotência compactada nunca repete o efeito. Backups usam backups/prune.', [
            'category'=>['type'=>'string','enum'=>self::CATEGORIES],
            'older_than_days'=>Registry::integer(1,3650),
            'max_total_bytes'=>Registry::integer(1),
            'dry_run'=>Registry::boolean(true),
            'before_id'=>Registry::integer(1),
            'expected_selection_sha256'=>Registry::string(),
        ], ['category'], [self::class,'run'], 'manage_options', false);
    }

    private static function scope(): string {
        if (is_admin() && current_user_can('manage_options')) return 'admin:'.get_current_user_id();
        return ConnectionContext::key();
    }

    public static function run(array $input): array {
        if (!current_user_can('manage_options')) return Result::fail('permission_denied','Manutenção exige manage_options.');
        $category=$input['category'];
        if (!in_array($category,self::CATEGORIES,true)) return Result::fail('maintenance_category_invalid','Categoria desconhecida.');
        return Locks::run(['state-maintenance:'.$category=>LOCK_EX], static function()use($input,$category){
            if (($input['dry_run']??true)===false) return self::apply($input);
            global $wpdb;
            $buckets=match($category){'audit'=>['audit'],'oauth-clients'=>['oauth-clients'],'oauth-codes'=>['oauth-codes'],'oauth-tokens'=>['oauth-tokens'],'sessions'=>['sessions'],'transfers'=>['uploads'],default=>['idempotency']};
            $before=(int)($input['before_id']??PHP_INT_MAX);$age=(int)($input['older_than_days']??($category==='audit'?90:14));
            $selected=[];$more=false;$next=null;$scan=[];
            foreach($buckets as $bucket){
                $table=Persistence::table($bucket);$predicate="expires_at>0 AND expires_at<".time();
                if($category==='audit') {
                    $predicate='created_at<'.(time()-$age*DAY_IN_SECONDS);
                    if(isset($input['max_total_bytes'])) {
                        $cutoff=$wpdb->get_var($wpdb->prepare("SELECT id FROM (SELECT id,SUM(OCTET_LENGTH(payload)) OVER (ORDER BY id DESC) cumulative_bytes FROM `$table` WHERE bucket='audit' AND status<>'deleted') volume WHERE cumulative_bytes>%d ORDER BY id DESC LIMIT 1",$input['max_total_bytes']));
                        if($wpdb->last_error)return Result::fail('maintenance_read_failed','Não foi possível calcular retenção por volume.');
                        if($cutoff!==null)$predicate.=' OR id<='.(int)$cutoff;
                    }
                }
                if($category==='oauth-clients') {
                    $grants=Persistence::table('oauth-grants');
                    $predicate.=" AND COALESCE(JSON_EXTRACT(payload,'$.authorized_at'),0)=0 AND COALESCE(JSON_EXTRACT(payload,'$.legacy'),false)=false AND NOT EXISTS (SELECT 1 FROM `$grants` g WHERE g.client_id=`$table`.client_id AND g.status='active' AND (g.expires_at=0 OR g.expires_at>".time()."))";
                }
                if($category==='idempotency')$predicate="status='complete' AND updated_at<".(time()-$age*DAY_IN_SECONDS);
                if($category==='transfers')$predicate.=" AND status IN ('pending','cancelled')";
                $rows=$wpdb->get_results($wpdb->prepare("SELECT id,record_key,bucket,revision,status,expires_at,created_at,OCTET_LENGTH(payload) bytes,payload FROM `$table` WHERE bucket=%s AND id<%d AND status<>'deleted' AND ($predicate) ORDER BY id DESC LIMIT 101",$bucket,$before),ARRAY_A);
                if($wpdb->last_error)return Result::fail('maintenance_read_failed','Não foi possível selecionar o estado.');
                foreach($rows as $row)$scan[]=$row;
            }
            usort($scan,static fn($a,$b)=>(int)$b['id']<=>(int)$a['id']);$more=count($scan)>100;$scan=array_slice($scan,0,100);
            foreach($scan as $row){
                $payload=json_decode($row['payload'],true);if(!is_array($payload))continue;
                // Tokens with an unknown expiry and finalizations in flight never enter this selection.
                $selected[]=['bucket'=>$row['bucket'],'id'=>(int)$row['id'],'record_key'=>$row['record_key'],'revision'=>(int)$row['revision'],'bytes'=>(int)$row['bytes'],'status'=>$row['status'],'expires'=>(int)$row['expires_at'],'transfer_id'=>$category==='transfers'?($payload['transfer_id']??null):null];
                $next=(int)$row['id'];
            }
            $plan=['category'=>$category,'scope'=>self::scope(),'time'=>time(),'expires'=>time()+3600,'rows'=>$selected,'status'=>'pending','completed'=>[]];
            $sha=hash_hmac('sha256',serialize($plan),wp_salt('auth'));StateStore::put('state-maintenance',$sha,$plan);
            return Result::ok(['dry_run'=>true,'selected'=>count($selected),'selected_bytes'=>array_sum(array_column($selected,'bytes')),'selection_sha256'=>$sha,'has_more'=>$more,'next_before_id'=>$more?$next:null,'items'=>array_map(static fn($r)=>array_intersect_key($r,array_flip(['bucket','id','bytes','status','expires'])),$selected)]);
        });
    }

    private static function apply(array $input): array {
        global $wpdb;
        $sha=$input['expected_selection_sha256']??'';$plan=StateStore::get('state-maintenance',$sha);
        if(!$plan||$plan['scope']!==self::scope()||$plan['category']!==$input['category']||($plan['expires']<time()&&empty($plan['completed'])))return Result::fail('maintenance_selection_invalid','Prévia ausente, expirada ou de outra identidade/categoria.');
        if($plan['status']==='complete')return Result::ok(['changed'=>false,'replayed'=>true,'completed'=>count($plan['completed'])]);
        foreach($plan['rows'] as $row){
            if(in_array($row['record_key'],$plan['completed'],true))continue;
            $process=static function()use($row,$wpdb,$plan,$sha){
                $table=Persistence::table($row['bucket']);$current=$wpdb->get_row($wpdb->prepare("SELECT revision,status,payload FROM `$table` WHERE record_key=%s",$row['record_key']),ARRAY_A);
                $existing=$current?json_decode($current['payload'],true):null;
                if(($existing['maintenance_selection']??'')===$sha)return Result::ok(['changed'=>false,'replayed'=>true]);
                if(!$current||(int)$current['revision']!==$row['revision'])return Result::fail('maintenance_selection_conflict','Registro mudou desde a prévia.',['conflict'=>true]);
                $value=json_decode($current['payload'],true);
                if($plan['category']==='oauth-clients'&&(!empty($value['authorized_at'])||!empty($value['legacy'])||empty($value['expires'])||$value['expires']>time()))return Result::fail('maintenance_selection_conflict','Cliente foi autorizado ou mudou de validade.',['conflict'=>true]);
                if($plan['category']==='transfers'){
                    if(!preg_match('/^[a-f0-9]{32}$/D',(string)$row['transfer_id'])||!in_array($value['status'],['pending','cancelled'],true)||$value['expires']>time())return Result::fail('maintenance_selection_conflict','Transferência mudou de estado.',['conflict'=>true]);
                    $dir=StateStore::directory('transfers').'/'.$row['transfer_id'];if(file_exists($dir))\Fator3\RecoveryV1\Engine::remove($dir);
                }
                $status=$plan['category']==='idempotency'?'compacted':'deleted';
                $compact=['status'=>$status,'time'=>$value['time']??time(),'compacted_at'=>time(),'maintenance_selection'=>$sha];
                if($status==='compacted')$compact+=array_intersect_key($value,array_flip(['fingerprint','operation_id','connection_id','user_id']));
                $n=$wpdb->query($wpdb->prepare("UPDATE `$table` SET payload=%s,status=%s,revision=revision+1,updated_at=%d WHERE record_key=%s AND revision=%d",wp_json_encode($compact),$status,time(),$row['record_key'],$row['revision']));
                return $n===1?Result::ok(['changed'=>true]):Result::fail('maintenance_selection_conflict','Estado mudou durante a manutenção.',['conflict'=>true]);
            };
            $r=$row['transfer_id']?Locks::run(['upload:'.$row['transfer_id']=>LOCK_EX],$process):$process();
            if(empty($r['success']))return $r+['completed'=>count($plan['completed']),'partial'=>(bool)$plan['completed'],'selection_sha256'=>$sha];
            $plan['completed'][]=$row['record_key'];StateStore::put('state-maintenance',$sha,$plan);
        }
        $plan['status']='complete';StateStore::put('state-maintenance',$sha,$plan);StateStore::put('maintenance-status',$plan['category'],['time'=>time(),'category'=>$plan['category'],'completed'=>count($plan['completed'])]);
        return Result::ok(['changed'=>(bool)$plan['completed'],'completed'=>count($plan['completed']),'selection_sha256'=>$sha,'dry_run'=>false]);
    }

    public static function storage(): array {
        global $wpdb;$rows=[];
        foreach(['audit','idempotency','oauth-clients','oauth-codes','oauth-tokens','sessions','uploads','backup-index'] as $bucket){
            $table=Persistence::table($bucket);$row=$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) records,COALESCE(SUM(OCTET_LENGTH(payload)),0) payload_bytes,COALESCE(SUM(stored_bytes),0) indexed_file_bytes FROM `$table` WHERE bucket=%s AND status<>'deleted'",$bucket),ARRAY_A);
            $rows[$bucket]=$row?array_map('intval',$row):null;
        }
        return ['database'=>$rows,'file_bytes_scope'=>'Índice de envelopes; árvores de recuperação, exportações e arquivos legados não estão incluídos.','last_maintenance'=>Persistence::listing('maintenance-status',[],10),'automatic_deletion_enabled'=>false];
    }
}
