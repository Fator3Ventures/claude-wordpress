<?php
/** Read the documentation shipped with this exact package; no remote content. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Guide {
    public static function register(): void {
        Registry::add('system/guide', 'Consulta a ajuda incluída neste pacote por tema e o contrato efetivo de uma habilidade. Sem topic, lista temas. Exemplos exigem revisão das permissões e dos valores locais.', [
            'topic'=>Registry::string('Tema devolvido pela listagem; all retorna o manual.'),
            'ability'=>Registry::string('Nome exato de habilidade visível para esta conexão.'),
        ], [], [self::class,'read'], 'edit_posts');
    }
    public static function read(array $input): array {
        if(isset($input['ability'])) {
            $ability=wp_get_ability($input['ability']);
            if(!$ability)return Result::fail('ability_not_found','Habilidade não registrada.');
            $meta=$ability->get_meta();
            if(!Discovery::eligibility($ability)['visible'])return Result::fail('profile_denied','Habilidade fora do catálogo desta conexão.');
            return Result::ok(['plugin_version'=>F3_MCP_FILES_VERSION,'ability'=>$ability->get_name(),'description'=>$ability->get_description(),'availability'=>Discovery::eligibility($ability)['availability'],'input_schema'=>$ability->get_input_schema(),'output_schema'=>$ability->get_output_schema(),'source'=>'installed_runtime']);
        }
        $path=F3_MCP_FILES_DIR.'includes/guide-content.php';
        if(!is_file($path))return Result::fail('guide_unavailable','Manual não foi incluído no pacote.');
        $text=require $path;$sections=[];
        foreach(preg_split('/(?=^## )/m',$text) as $section){
            if(!preg_match('/^## ([^\n]+)/',$section,$match))continue;
            $key=sanitize_title($match[1]);$sections[$key]=['topic'=>$key,'title'=>$match[1],'content'=>$section];
        }
        $data=['plugin_version'=>F3_MCP_FILES_VERSION,'document_sha256'=>hash('sha256',$text),'source'=>'installed_documentation'];
        if(!isset($input['topic']))return Result::ok($data+['topics'=>array_values(array_map(static fn($s)=>array_diff_key($s,['content'=>true]),$sections))]);
        if($input['topic']==='all')return Result::ok($data+['content'=>$text]);
        if(!isset($sections[$input['topic']]))return Result::fail('guide_topic_not_found','Consulte a listagem para obter um tema válido.',$data);
        return Result::ok($data+$sections[$input['topic']]);
    }
}
