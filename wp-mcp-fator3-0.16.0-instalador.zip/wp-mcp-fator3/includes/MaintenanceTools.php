<?php
/** Native, typed maintenance; no global orphan cleanup runs during activation. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class MaintenanceTools {
    public static function register(): void {
        Registry::add('rewrite/flush','Regenera regras pelo WordPress com flush_rewrite_rules(false). Não altera .htaccess; devolve contagem e regras de categoria/tag antes e depois.',[],[],[self::class,'rewrite'],'manage_options',false);
        Registry::add('plugins/cleanup-orphaned-uninstall','Limpa somente callbacks de plugins comprovadamente ausentes. Prévia/confirm_token; não executa uninstall, não exclui plugins nem posts. Diretórios residuais exigem inspeção.', ['plugins'=>['type'=>'array','items'=>Registry::string(),'minItems'=>1,'maxItems'=>100,'uniqueItems'=>true]], ['plugins'],[self::class,'orphans'],static fn()=>current_user_can('manage_options')&&current_user_can('delete_plugins'),false);
        Registry::add('menus/delete','Exclui menu clássico por ID com prévia/confirm_token e backup. Preserva páginas/posts vinculados. Menu em uso exige acknowledge_in_use:true; wp_navigation não é menu clássico.', ['menu_id'=>Registry::integer(1),'acknowledge_in_use'=>Registry::boolean()],['menu_id'],[self::class,'menu_delete'],'edit_theme_options',false);
        Registry::add('options/delete','Exclui até 100 options por nomes exatos via delete_option; prévia/confirm_token, backup íntegro privado, hooks e cache nativos. Não aceita prefixos nem options protegidas.', ['names'=>['type'=>'array','items'=>['type'=>'string','minLength'=>1,'maxLength'=>191],'minItems'=>1,'maxItems'=>100,'uniqueItems'=>true]],['names'],[self::class,'options_delete'],'manage_options',false);
        Registry::add('media/regenerate','Regenera derivados pelos tamanhos registrados no WordPress. Preserva original; verifica metadados e arquivos. Falhas parciais são explícitas.', ['id'=>Registry::integer(1),'expected_revision'=>Registry::string()],['id'],[self::class,'regenerate'],static fn($a)=>current_user_can('upload_files')&&current_user_can('edit_post',(int)($a['id']??0)),false);
        Registry::add('media/set-site-icon','Define ícone usando WP_Site_Icon e tamanhos filtrados do WordPress. Exige imagem quadrada de pelo menos 512px; preserva original e devolve URLs verificadas.', ['id'=>Registry::integer(1),'expected_revision'=>Registry::string()],['id'],[self::class,'site_icon'],static fn($a)=>current_user_can('manage_options')&&current_user_can('upload_files')&&current_user_can('edit_post',(int)($a['id']??0)),false);
    }
    public static function protected_option(string $name): bool {
        global $wpdb;
        if(ConnectionContext::maintenance())return SiteAdmin::internal($name);
        $list=['active_plugins','auto_update_plugins','siteurl','home','users_can_register','default_role','admin_email','cron','auto_updater.lock','rewrite_rules','recently_activated','uninstall_plugins',$wpdb->prefix.'user_roles','template','stylesheet','current_theme','WPLANG'];
        $extra=apply_filters('wp_mcp_ultimate_protected_options',$list,$name);if(is_array($extra))$list=array_unique(array_merge($list,$extra));
        return in_array($name,$list,true)||str_starts_with($name,'f3_mcp_')||str_starts_with($name,'_transient_f3_mcp_')||DataSafety::secret_key($name);
    }
    private static function rewrite_state(): array {
        $rules=(array)get_option('rewrite_rules',[]);$selected=[];
        $bases=[trim((string)get_option('category_base','category'),'/')?:'category',trim((string)get_option('tag_base','tag'),'/')?:'tag'];
        foreach($rules as $rule=>$query)if(str_contains($query,'category_name=')||str_contains($query,'tag=')||str_starts_with($rule,$bases[0].'/')||str_starts_with($rule,$bases[1].'/'))$selected[$rule]=$query;
        return ['count'=>count($rules),'category_base'=>$bases[0],'tag_base'=>$bases[1],'rules'=>$selected,'sha256'=>hash('sha256',serialize($rules))];
    }
    public static function rewrite(array $input=[]): array {
        return Locks::run(['rewrite:'.get_current_blog_id()=>LOCK_EX],static function() {
            $before=self::rewrite_state();flush_rewrite_rules(false);$after=self::rewrite_state();
            return Result::ok(['before'=>$before,'after'=>$after,'changed'=>$before['sha256']!==$after['sha256'],'persisted'=>is_array(get_option('rewrite_rules',null)),'hard'=>false]);
        });
    }
    public static function permalink(string $name,array $input): array {
        global $wp_rewrite;
        return Locks::run(['rewrite:'.get_current_blog_id()=>LOCK_EX],static function()use($name,$input,$wp_rewrite) {
            $old=get_option($name);$before=self::rewrite_state();$value=(string)$input['value'];
            if(isset($input['key']))return Result::fail('option_type_conflict','Permalink é option escalar.');
            if($name==='permalink_structure')$wp_rewrite->set_permalink_structure($value);
            elseif($name==='category_base')$wp_rewrite->set_category_base($value);
            else $wp_rewrite->set_tag_base($value);
            flush_rewrite_rules(false);$new=get_option($name);
            if($new!==$value)return Result::fail('option_write_rejected','A estrutura solicitada não foi persistida.', ['persisted'=>false]);
            return Result::ok(['name'=>$name,'old_value'=>$old,'new_value'=>$new,'changed'=>$old!==$new,'persisted'=>true,'rewrite'=>['before'=>$before,'after'=>self::rewrite_state()]]);
        });
    }
    public static function options_snapshot(array $input) {
        global $wpdb;$names=$input['names']??[];
        if(!$names||count($names)>100)return new \WP_Error('invalid_names','Selecione de 1 a 100 nomes exatos.');
        foreach($names as $name)if(!is_string($name))return new \WP_Error('invalid_names','Todos os nomes precisam ser strings.');
        $names=array_values(array_unique($names));sort($names);$existing=[];$missing=[];
        foreach($names as $name) {
            if(!is_string($name)||$name===''||strlen($name)>191||preg_match('/[\x00-\x1f*%]/',$name)||self::protected_option($name))return new \WP_Error('option_protected','Nome inválido ou option protegida; utilize habilidade específica.');
            $row=$wpdb->get_row($wpdb->prepare("SELECT option_name,option_value,autoload FROM {$wpdb->options} WHERE option_name=%s",$name),ARRAY_A);
            if($wpdb->last_error)return new \WP_Error('option_read_failed','Não foi possível verificar a seleção.');
            if($row)$existing[$name]=$row;else $missing[]=$name;
        }
        return ['existing'=>$existing,'missing'=>$missing];
    }
    public static function options_delete(array $input): array {
        $snapshot=self::options_snapshot($input);if(is_wp_error($snapshot))return Result::error($snapshot);
        $removed=[];$unchanged=$snapshot['missing'];$failed=[];$pending=array_keys($snapshot['existing']);
        foreach($snapshot['existing'] as $name=>$expected) {
            $now=self::options_snapshot(['names'=>[$name]]);if(is_wp_error($now)||($now['existing'][$name]??null)!==$expected) { $failed[$name]='option_conflict';break; }
            $ok=delete_option($name);$after=self::options_snapshot(['names'=>[$name]]);$sentinel=new \stdClass();$effective=get_option($name,$sentinel);
            if(!$ok||is_wp_error($after)||isset($after['existing'][$name])||$effective!==$sentinel) { $failed[$name]='option_delete_not_confirmed';break; }
            $removed[]=$name;$pending=array_values(array_diff($pending,[$name]));
        }
        $data=['removed'=>$removed,'unchanged'=>$unchanged,'failed'=>$failed,'pending'=>$pending,'changed'=>(bool)$removed,'applied'=>(bool)$removed,'atomic'=>false];
        return $failed?Result::fail('options_delete_partial','Exclusão parcial; confira itens pendentes.',$data):Result::ok($data+['persisted'=>true]);
    }
    public static function menu_snapshot(array $input) {
        $menu=wp_get_nav_menu_object((int)$input['menu_id']);if(!$menu||is_wp_error($menu))return new \WP_Error('menu_not_found','Menu clássico não encontrado.');
        $locations=array_filter(get_nav_menu_locations(),static fn($id)=>(int)$id===(int)$menu->term_id);
        if($locations&&empty($input['acknowledge_in_use']))return new \WP_Error('menu_in_use','Menu associado ao tema. Informe acknowledge_in_use:true para solicitar prévia de exclusão.', ['locations'=>array_keys($locations)]);
        $items=wp_get_nav_menu_items($menu->term_id,['post_status'=>'any'])?:[];$meta=[];
        foreach($items as $item)$meta[$item->ID]=get_post_meta($item->ID);
        return ['menu'=>$menu,'items'=>$items,'meta'=>$meta,'locations'=>$locations];
    }
    public static function menu_delete(array $input): array {
        $before=self::menu_snapshot($input);if(is_wp_error($before))return Result::error($before);
        $result=wp_delete_nav_menu((int)$input['menu_id']);if(is_wp_error($result))return Result::error($result);
        $left=[];foreach($before['items'] as $item)if(get_post($item->ID))$left[]=$item->ID;
        $locations=array_filter(get_nav_menu_locations(),static fn($id)=>(int)$id===(int)$input['menu_id']);
        if(wp_get_nav_menu_object((int)$input['menu_id'])||$left||$locations)return Result::fail('menu_delete_partial','Exclusão não foi confirmada integralmente.', ['applied'=>true,'remaining_items'=>$left,'locations'=>$locations]);
        return Result::ok(['menu_id'=>(int)$input['menu_id'],'changed'=>true,'persisted'=>true,'removed_items'=>count($before['items'])]);
    }
    public static function orphan_snapshot(array $input) {
        require_once ABSPATH.'wp-admin/includes/plugin.php';$registered=(array)get_option('uninstall_plugins',[]);$found=[];
        foreach($input['plugins'] as $plugin) {
            if(!preg_match('~^(?:[A-Za-z0-9_.-]+/)?[A-Za-z0-9_.-]+\.php$~D',$plugin)||str_contains($plugin,'..'))return new \WP_Error('invalid_plugin_basename','Informe basename exato do plugin.');
            if(file_exists(WP_PLUGIN_DIR.'/'.$plugin)||dirname($plugin)!=='.'&&file_exists(WP_PLUGIN_DIR.'/'.dirname($plugin)))return new \WP_Error('plugin_absence_unconfirmed','Plugin ou diretório residual existe; callback preservado.');
            if(array_key_exists($plugin,$registered))$found[$plugin]=$registered[$plugin];
        }
        ksort($found);return ['callbacks'=>$found];
    }
    public static function orphans(array $input): array {
        global $wpdb;$snapshot=self::orphan_snapshot($input);if(is_wp_error($snapshot))return Result::error($snapshot);
        if(!$snapshot['callbacks'])return Result::ok(['changed'=>false,'removed'=>[]]);
        $old=get_option('uninstall_plugins',[]);$new=array_diff_key($old,$snapshot['callbacks']);
        // Compare-and-swap preserves concurrent callbacks from non-cooperating writers.
        $changed=$wpdb->query($wpdb->prepare("UPDATE {$wpdb->options} SET option_value=%s WHERE option_name='uninstall_plugins' AND option_value=%s",maybe_serialize($new),maybe_serialize($old)));
        if($changed!==1)return Result::fail('option_conflict','Registro mudou desde a leitura; nada foi removido.', ['conflict'=>true]);
        wp_cache_delete('uninstall_plugins','options');wp_cache_delete('alloptions','options');
        $actual=get_option('uninstall_plugins',[]);
        if(array_intersect_key($actual,$snapshot['callbacks']))return Result::fail('orphan_cleanup_not_confirmed','Callback reapareceu; confira os registros.', ['applied'=>true]);
        return Result::ok(['changed'=>true,'removed'=>array_keys($snapshot['callbacks']),'callbacks_executed'=>false]);
    }
    public static function regenerate(array $input): array {return MediaImages::generate((int)$input['id']);}
    public static function site_icon(array $input): array {return MediaImages::site_icon($input);}
}
