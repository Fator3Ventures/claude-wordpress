<?php
/** Targeted role changes under the lock shared with user assignment and default_role. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Roles {
    private const NATIVE = ['administrator','editor','author','contributor','subscriber'];
    public static function register(): void {
        $fields=['role'=>Registry::string(),'confirm_token'=>Registry::string()];
        Registry::add('roles/delete','Exclui papel personalizado sem usuários, fora dos papéis nativos e do padrão. Prévia e confirm_token; backup do papel alvo.', $fields,['role'],[self::class,'delete'],[ConnectionTools::class,'permission'],false);
        Registry::add('roles/restore','Restaura somente o papel escolhido de um backup de papéis. Prévia e confirm_token; preserva demais papéis e não atribui usuários.', $fields+['backup_id'=>Registry::string()],['role','backup_id'],[self::class,'restore'],[ConnectionTools::class,'permission'],false);
    }
    public static function fresh(): array {
        global $wpdb;
        $key=$wpdb->prefix.'user_roles';
        $raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM $wpdb->options WHERE option_name=%s",$key));
        if($wpdb->last_error || $raw===null) throw new \RuntimeException('roles_storage_unavailable');
        $roles=maybe_unserialize($raw);
        if(!is_array($roles)) throw new \RuntimeException('roles_storage_invalid');
        wp_cache_delete($key,'options');wp_cache_delete('alloptions','options');wp_roles()->for_site();
        return $roles;
    }
    private static function valid(string $role,?array $value): bool {
        if($role==='' || sanitize_key($role)!==$role) return false;
        if($value===null) return true;
        if(!isset($value['name'],$value['capabilities']) || !is_string($value['name']) || !is_array($value['capabilities'])) return false;
        foreach($value['capabilities'] as $cap=>$grant) if(!is_string($cap)||$cap===''||!is_bool($grant))return false;
        return true;
    }
    private static function state(string $role): array {
        global $wpdb;
        $roles=self::fresh();
        $default=$wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name='default_role'");
        if($wpdb->last_error)throw new \RuntimeException('roles_storage_unavailable');
        // Scan the role maps rather than matching serialized substrings: users may have several roles.
        $rows=$wpdb->get_col($wpdb->prepare("SELECT meta_value FROM $wpdb->usermeta WHERE meta_key=%s",$wpdb->prefix.'capabilities'));
        if($wpdb->last_error)throw new \RuntimeException('roles_users_unavailable');
        $count=0;foreach($rows as $raw){$caps=maybe_unserialize($raw);if(is_array($caps)&&!empty($caps[$role]))++$count;}
        $value=$roles[$role]??null;
        return ['role'=>$role,'exists'=>array_key_exists($role,$roles),'value'=>$value,'users'=>$count,
            'default_role'=>$default,'native'=>in_array($role,self::NATIVE,true),
            'revision'=>hash('sha256',serialize($value))];
    }
    private static function removal(array $s): ?\WP_Error {
        if($s['native'])return new \WP_Error('role_protected','Papel nativo não pode ser excluído.');
        if($s['default_role']===$s['role'])return new \WP_Error('role_is_default','Papel padrão não pode ser excluído.');
        if($s['users']>0)return new \WP_Error('role_in_use','Papel atribuído a usuários; nenhuma atribuição foi alterada.',['users'=>$s['users']]);
        return null;
    }
    private static function apply(string $role,?array $desired,array $before,string $ability): array {
        $backup=Backups::create_snapshot($ability,['role_contract'=>1,'role'=>$role,'before'=>$before['value'],'after'=>$desired]);
        if(is_wp_error($backup))return Result::error($backup);
        self::write($role,$desired);
        $after=self::state($role);
        if($after['value']!==$desired || $after['exists']!==($desired!==null))return Result::fail('roles_readback_conflict','Papel observado difere do pedido.',['applied'=>null,'backup_id'=>$backup,'role'=>$role]);
        return Result::ok(['role'=>$role,'changed'=>$before['value']!==$desired,'persisted'=>true,'backup_id'=>$backup,'revision'=>$after['revision']]);
    }
    private static function write(string $role,?array $desired): void {
        self::fresh();
        if($desired===null){remove_role($role);return;}
        if(get_role($role) && (wp_roles()->roles[$role]['name']??'')!==$desired['name'])remove_role($role);
        if(!get_role($role))add_role($role,$desired['name'],$desired['capabilities']);
        $object=get_role($role);if(!$object)throw new \RuntimeException('role_creation_failed');
        foreach(array_keys($object->capabilities) as $cap)if(!array_key_exists($cap,$desired['capabilities']))$object->remove_cap($cap);
        foreach($desired['capabilities'] as $cap=>$grant)$object->add_cap($cap,$grant);
    }
    private static function change(string $name,array $i,?array $desired,bool $delete=false,?array $source=null): array {
        if(!ConnectionTools::permission())return Result::fail('permission_denied','Exige manage_options e perfil Manutenção.');
        $role=(string)$i['role'];if(!self::valid($role,$desired))return Result::fail('roles_invalid','Papel ou capacidades inválidos.');
        return Locks::run(['wordpress-roles'=>LOCK_EX],static function()use($name,$i,$role,$desired,$delete,$source){
            return Phase::run($name,$i,static function()use($role,$desired,$delete,$source){
                $s=self::state($role);
                if($delete&&!$s['exists'])return new \WP_Error('role_not_found','Papel não encontrado.');
                if($desired===null && ($guard=self::removal($s)))return $guard;
                if($source && array_key_exists('after',$source) && $source['after']!==$s['value'])return new \WP_Error('preimage_conflict','Papel mudou desde o backup.',['conflict'=>true]);
                return $s+['desired'=>$desired,'removing'=>$desired===null,'restore_legacy_without_postimage'=>$source!==null&&!array_key_exists('after',$source)];
            },static fn($before)=>self::apply($role,$desired,$before,$name));
        });
    }
    public static function update(array $i): array {return self::change('roles/update',$i,['name'=>$i['name'],'capabilities'=>$i['capabilities']]);}
    public static function delete(array $i): array {return self::change('roles/delete',$i,null,true);}
    public static function restore(array $i): array { return self::restore_loaded($i); }
    private static function restore_loaded(array $i): array {
        // Hold EX across loading and backup creation; this shares ordering with retention.
        return Locks::run(['wordpress-roles'=>LOCK_EX],static fn()=>Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($i){
            $m=Backups::metadata($i['backup_id']);if(is_wp_error($m))return Result::error($m);
            if(($m['kind']??'')!=='snapshot'||!in_array($m['ability']??'',['roles/update','roles/delete','roles/restore'],true)||(int)($m['site_id']??0)!==get_current_blog_id()||!is_array($m['snapshot']??null))return Result::fail('backup_type_mismatch','Backup de papéis da instalação atual necessário.');
            $s=$m['snapshot'];$role=$i['role'];
            if(isset($s['role_contract'])){
                if($s['role_contract']!==1||($s['role']??null)!==$role||!array_key_exists('before',$s)||!array_key_exists('after',$s))return Result::fail('backup_type_mismatch','Backup não pertence ao papel informado.');
                $value=$s['before'];$source=['after'=>$s['after']];
            }else{
                foreach($s as $key=>$value)if(!is_string($key)||!is_array($value)||!self::valid($key,$value))return Result::fail('backup_corrupt','Mapa antigo inválido.');
                $value=$s[$role]??null;$source=[];
            }
            if($value!==null && (!is_array($value)||!self::valid($role,$value)))return Result::fail('backup_corrupt','Pré-imagem do papel inválida.');
            return self::change('roles/restore',$i,$value,false,$source)+['source_backup_id'=>$i['backup_id']];
        }));
    }
    public static function replace(array $i): array {
        if(!ConnectionTools::permission())return Result::fail('permission_denied','Exige manage_options e perfil Manutenção.');
        return Locks::run(['wordpress-roles'=>LOCK_EX],static function()use($i){
            $all=isset($i['key'])?array_replace(self::fresh(),[$i['key']=>$i['value']]):$i['value'];
            if(!is_array($all))return Result::fail('roles_invalid','Papéis precisam de mapa de name/capabilities.');
            foreach($all as $key=>$value)if(!is_string($key)||!is_array($value)||!self::valid($key,$value))return Result::fail('roles_invalid','Papel ou capacidades inválidos.');
            return Phase::run('roles/replace',$i,static function()use($all){
                $old=self::fresh();$states=[];
                foreach(array_keys(array_diff_key($old,$all)) as $role){$state=self::state($role);if($guard=self::removal($state))return $guard;$states[$role]=$state;}
                return ['roles'=>$old,'removed'=>$states];
            },static function($before)use($all){
                $old=$before['roles'];$backups=[];
                foreach(array_unique(array_merge(array_keys($old),array_keys($all))) as $role)if(($old[$role]??null)!==($all[$role]??null)){
                    $id=Backups::create_snapshot('roles/update',['role_contract'=>1,'role'=>$role,'before'=>$old[$role]??null,'after'=>$all[$role]??null]);
                    if(is_wp_error($id))return Result::error($id);$backups[$role]=$id;
                }
                foreach(array_keys($backups) as $role)self::write($role,$all[$role]??null);
                $after=self::fresh();$ok=$after==$all;
                return $ok?Result::ok(['changed'=>$old!=$after,'persisted'=>true,'backup_id'=>reset($backups)?:null,'backup_ids'=>$backups,'roles'=>$after]):Result::fail('roles_readback_conflict','Papéis observados diferem do pedido.',['applied'=>null,'backup_ids'=>$backups]);
            });
        });
    }
}
