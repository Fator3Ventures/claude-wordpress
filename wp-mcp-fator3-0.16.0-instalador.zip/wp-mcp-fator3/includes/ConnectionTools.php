<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ConnectionTools {
    public static function permission(): bool {return current_user_can('manage_options')&&ConnectionContext::maintenance();}
    public static function register(): void {
        $id=['connection_id'=>Registry::string(),'expected_policy_version'=>Registry::integer(),'confirm_token'=>Registry::string()];
        Registry::add('connections/list','Lista identidades sem credenciais. Integrações não configuradas são Sem acesso; expiradas e revogadas continuam identificáveis.',['before_id'=>Registry::integer(1),'per_page'=>Registry::integer(1,100)],[],[self::class,'listing'],[self::class,'permission']);
        $settings=['profile'=>['type'=>'string','enum'=>['read','content','maintenance','custom']],'label'=>Registry::string(),'expires'=>Registry::string(),'roots'=>['type'=>'array','items'=>Registry::string()],'abilities'=>['type'=>'array','items'=>Registry::string()],'post_types'=>['type'=>'array','items'=>Registry::string()],'meta_keys'=>['type'=>'array','items'=>Registry::string()],'database_write'=>Registry::boolean(),'allow_backup_export'=>Registry::boolean(),'allow_foreign_backup_export'=>Registry::boolean(),'readonly_executor'=>Registry::boolean(),'file_bytes'=>Registry::integer(1048576,1073741824)];
        Registry::add('connections/update','Atualiza perfil/ajustes com revisão obrigatória. Alterar a própria identidade exige prévia e confirm_token. Manutenção tem direitos plenos efetivos.',$id+$settings,['connection_id','expected_policy_version'],static fn($i)=>self::change($i,false),[self::class,'permission'],false);
        Registry::add('connections/revoke','Revoga uma identidade exata sem revogar grants independentes. Autorrevogação exige confirmação em duas fases.',$id,['connection_id','expected_policy_version'],static fn($i)=>self::change($i,true),[self::class,'permission'],false);
        Registry::add('system/settings','Consulta ajustes do canal: fonte de atualização, limite de arquivo e bloqueio geral.',[],[],[self::class,'settings'],[self::class,'permission']);
        Registry::add('system/settings-update','Altera ajustes do canal em duas fases com backup/auditoria. Configurar feed não liga atualização automática.',['file_bytes'=>Registry::integer(1048576,1073741824),'enabled'=>Registry::boolean(),'sql_retention'=>['type'=>'object','properties'=>['older_than_days'=>Registry::integer(1,3650),'max_count'=>Registry::integer(1,10000),'min_keep'=>Registry::integer(0,10000)],'additionalProperties'=>false],'update_channels'=>['type'=>'object','additionalProperties'=>['type'=>'string']],'confirm_token'=>Registry::string()],[],[self::class,'update_settings'],[self::class,'permission'],false);
    }
    public static function listing(array $i): array {
        $limit=$i['per_page']??50;$rows=Persistence::listing('connections',[], $limit+1,$i['before_id']??PHP_INT_MAX);$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);$out=[];
        foreach($rows as $r){$r=ConnectionContext::policy($r['connection_id'])??$r;$r['status']=$r['_storage']['status']??$r['status'];$r['access_enabled']=$r['status']==='active'&&($r['profile']??'unconfigured')!=='unconfigured'&&(!$r['expires']||$r['expires']>time())&&ConnectionContext::credential_active($r['connection_id'],(int)$r['user_id']);$r['state_label']=$r['access_enabled']?'Ativa':'Sem acesso';if(($r['profile']??'')==='maintenance')$r['effective']=['roots'=>'php_reachable_paths','database_write'=>true,'allow_backup_export'=>true,'allow_foreign_backup_export'=>true];$out[]=array_diff_key($r,['_storage'=>true]);}
        return Result::ok(['connections'=>$out,'has_more'=>$more,'next_before_id'=>$more?(int)end($rows)['_row_id']:null]);
    }
    public static function change(array $i,bool $revoke): array {
        $id=$i['connection_id'];return Locks::run(['connection:'.$id=>LOCK_EX],static function()use($i,$id,$revoke){
            $old=ConnectionContext::policy($id);if(!$old)return Result::fail('connection_not_found','Identidade não encontrada.');
            if((int)$old['policy_version']!==$i['expected_policy_version'])return Result::fail('connection_policy_conflict','Política alterada.',['conflict'=>true]);
            $snapshot=static fn()=>array_intersect_key(ConnectionContext::policy($id)??[],array_flip(['connection_id','user_id','profile','policy_version','expires','status']));
            return Phase::run('connections/'.($revoke?'revoke':'update'),$i,$snapshot,static function()use($i,$old,$revoke){
                $input=array_replace($old,$i);$input['intent']=$revoke?'revoke':'save';
                foreach(['roots','abilities','post_types','meta_keys'] as $key)$input[$key]=implode("\n",(array)($input[$key]??[]));
                $input['expires']=isset($i['expires'])?$i['expires']:(!empty($old['expires'])?gmdate('c',$old['expires']):'');
                $result=ConnectionsAdmin::save($input);
                if(!empty($result['success'])){
                    $new=Persistence::get('connections',$i['connection_id']);
                    if(isset($i['file_bytes'])&&!$revoke){$new['file_bytes']=$i['file_bytes'];Persistence::put('connections',$i['connection_id'],$new);}
                    $result['policy_version']=$new['policy_version'];$result['connection_id']=$i['connection_id'];
                }
                return $result;
            },$id===ConnectionContext::key());
        });
    }
    public static function settings(array $i=[]): array {return Result::ok(['sql_retention'=>SqlArtifacts::policy(),'file_bytes'=>(int)get_option('f3_mcp_file_bytes',PathGuard::MAX_BYTES),'enabled'=>(bool)get_option(PathGuard::OPTION_ENABLED,true),'update_channels'=>get_option('f3_mcp_update_channels',[])]);}
    public static function update_settings(array $i): array {
        if(isset($i['sql_retention'])){$i['sql_retention']=array_replace(SqlArtifacts::policy(),$i['sql_retention']);if(!SqlArtifacts::valid_policy($i['sql_retention']))return Result::fail('artifact_policy_invalid','Retenção exige idade/quantidade positivas e 0 <= min_keep <= max_count.');}
        foreach($i['update_channels']??[] as $url)if(!wp_http_validate_url($url)||wp_parse_url($url,PHP_URL_SCHEME)!=='https')return Result::fail('feed_url_invalid','Fonte precisa ser uma URL HTTPS pública válida.');
        return Locks::run(['channel-settings'=>LOCK_EX],static fn()=>Phase::run('system/settings-update',$i,static fn()=>self::settings(),static function($old)use($i){
            $backup=Backups::create_snapshot('channel-settings',$old);if(is_wp_error($backup))return Result::error($backup);
            foreach(['sql_retention'=>'f3_mcp_sql_retention','file_bytes'=>'f3_mcp_file_bytes','enabled'=>PathGuard::OPTION_ENABLED,'update_channels'=>'f3_mcp_update_channels'] as $key=>$option)if(array_key_exists($key,$i))update_option($option,$i[$key],false);
            $after=self::settings();foreach(['sql_retention','file_bytes','enabled','update_channels'] as $key)if(array_key_exists($key,$i)&&$after[$key]!==$i[$key])return Result::fail('settings_readback_conflict','Configuração observada difere do pedido.',['applied'=>null,'backup_id'=>$backup,'observed'=>$after]);return $after+['backup_id'=>$backup,'changed'=>$old!==$after,'persisted'=>true];
        }));
    }
}
