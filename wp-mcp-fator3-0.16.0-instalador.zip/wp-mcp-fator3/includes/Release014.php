<?php
/** 0.14 contracts; registered before the common authorization/audit decorator. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SafeOutput {
    public static function error(array $data): array {
        $safe=[];
        foreach($data as $key=>$value){
            if(DataSafety::secret_key((string)$key)&&!in_array($key,['confirm_token','error_code'],true))$safe[$key]='[redigido]';
            else $safe[$key]=is_array($value)?self::error($value):$value;
        }
        return $safe;
    }
}
final class Phase {
    private static ?string $active=null;
    public static function current(): ?string {return self::$active;}
    public static function status(array $i): array {
        $id=substr($i['operation_id'],6);if(!preg_match('/^[a-f0-9]{32}$/D',$id))return Result::fail('operation_not_found','Operação não encontrada.');
        $index=StateStore::get('phase014-index',$id);$s=$index?StateStore::get('phase014',$index['token']):null;if(!$s||$s['connection_id']!==ConnectionContext::key())return Result::fail('operation_not_found','Operação não encontrada.');
        $out=['operation_id'=>$i['operation_id'],'ability'=>$s['name'],'status'=>$s['status'],'expires_at'=>gmdate('c',$s['expires'])];
        if(isset($s['result']))$out['result']=$s['result'];
        $backup=$s['backup_id']??$s['result']['backup_id']??null;if(is_string($backup)&&preg_match('/^[a-f0-9]{32}$/D',$backup))$out['backup']=SqlArtifacts::availability($backup);
        if($s['status']==='running'){foreach(glob(StateStore::directory('database-recovery').'/*.php')?:[] as $path){$j=\Fator3\RecoveryV1\Engine::read($path);if(($j['operation_id']??null)===$i['operation_id']){$out['recovery_id']=$j['id'];$out['recovery_status']=$j['status'];break;}}$out['applied']=null;$out['retryable']=false;}
        return Result::ok($out);
    }
    /** Caller holds the target lock. Every effect has a durable, credential-bound claim. */
    public static function run(string $name,array $input,callable $snapshot,callable $apply,bool $always=true): array {
        $args=$input;unset($args['confirm_token'],$args['idempotency_key']);
        $intent=hash('sha256',serialize($args));$connection=ConnectionContext::key();
        $token=$input['confirm_token']??'';
        if($token===''){
            $before=$snapshot();if(is_wp_error($before))return Result::error($before);
            $hash=hash_hmac('sha256',serialize($before),wp_salt('auth'));
            if(!$always)return Result::normalize($apply($before));
            $token=bin2hex(random_bytes(32));$id=bin2hex(random_bytes(16));StateStore::put('phase014-index',$id,['token'=>$token]);StateStore::put('phase014',$token,['operation_id'=>'phase:'.$id,'name'=>$name,'intent'=>$intent,'connection_id'=>$connection,'fingerprint'=>$hash,'expires'=>time()+600,'status'=>'pending']);
            return Result::ok(['operation_id'=>'phase:'.$id,'preview'=>true,'applied'=>false,'changed'=>false,'confirm_token'=>$token,'expires_at'=>gmdate('c',time()+600),'summary'=>SafeOutput::error($before)]+array_intersect_key(SafeOutput::error($before),array_flip(['preview_rows','redacted','affected_rows','statement_previews','selection_exact'])));
        }
        if(!preg_match('/^[a-f0-9]{64}$/D',$token))return Result::fail('confirmation_invalid','Confirmação inválida.');
        return Locks::run(['phase014:'.$token=>LOCK_EX],static function()use($token,$name,$intent,$connection,$snapshot,$apply){
            $s=StateStore::get('phase014',$token);
            if(!$s||$s['name']!==$name||$s['intent']!==$intent||$s['connection_id']!==$connection)return Result::fail('confirmation_invalid','Confirmação não pertence à seleção/conexão.');
            if($s['status']==='complete')return $s['result']+['replayed'=>true];
            if($s['status']!=='pending')return Result::fail('operation_uncertain','Efeito iniciado sem conclusão; consulte a operação antes de repetir.',['operation_id'=>$s['operation_id']??null,'applied'=>null,'retryable'=>false]);
            if($s['expires']<time())return Result::fail('confirmation_expired','Prévia expirada.');
            $before=$snapshot();if(is_wp_error($before))return Result::error($before);
            if(!hash_equals($s['fingerprint'],hash_hmac('sha256',serialize($before),wp_salt('auth'))))return Result::fail(str_starts_with($name,'db/')?'database_conflict':'preimage_conflict','Alvo mudou desde a prévia.',['conflict'=>true]);
            $s['status']='running';StateStore::put('phase014',$token,$s);
            $prior=self::$active;self::$active=$s['operation_id']??null;try{$result=Result::normalize($apply($before))+['operation_id'=>self::$active];}finally{self::$active=$prior;}$s['status']='complete';$s['result']=$result;StateStore::put('phase014',$token,$s);return $result;
        });
    }
}
final class Release014 {
    public static function init(): void {
        // Removed operational documents must not be redirected by WordPress's canonical guessing.
        add_action('template_redirect',static function(){
            $base=(string)wp_parse_url(plugins_url('wp-mcp-fator3/'),PHP_URL_PATH);
            $path=rawurldecode((string)wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH));
            foreach(['README.md','CHANGELOG.md','docs/OPERACAO.md','docs/ATUALIZACAO.md','docs/COBERTURA-SEO.md','docs/CONTRATO-EXTENSOES.md','docs/CONTRATOS-INSTALADOS.json'] as $name)if($path===$base.$name){status_header(404);nocache_headers();header('Content-Type: text/plain; charset=utf-8');echo 'Not found';exit;}
        },0);
    }

    public static function register(): void {
        ConnectionTools::register();CronTools::register();SiteAdmin::register();DatabaseAdmin::register();QueryExports::register();ArchiveTools::register();ThemePackages::register();
    }
    public static function schema(array $args,string $name): array {
        $p=&$args['input_schema']['properties'];
        if(DestructiveActions::supports($name))$p['confirm']=Registry::boolean();
        if(in_array($name,['files/write','files/patch','files/delete','files/move','files/fetch','files/restore','files/upload-finalize'],true))$p['probe']=Registry::boolean(true);
        if($name==='db/query'){
            $p['timeout_seconds']=Registry::integer(1,3600);
            $args['output_schema']['properties']['redacted']=['type'=>'array','items'=>['type'=>'object']];
            $args['execute_callback']=[DatabaseRead::class,'query'];
            $args['description']='Consulta de leitura MySQL. Manutenção aceita tabelas/views do banco do site, JOIN, UNION, subconsultas, CTE, janelas e funções analíticas. Resposta até 2000 linhas; db/query-export gera arquivo privado completo. Segredos são redigidos na apresentação; administração SQL não é isolamento contra inferência.';
        }
        if($name==='db/execute'){
            $p['backup_scope']=['type'=>'string','enum'=>['database','selected_tables']];
            $native=$args['execute_callback'];
            $args['execute_callback']=static fn($in)=>ConnectionContext::maintenance()?DatabaseAdmin::execute($in):$native($in);
            $args['description']='Escrita MySQL em duas fases com selection-guard/2: guarda linhas, schema e dependências selecionadas. confirm_token válido por 10 minutos; database_conflict exige nova prévia. Formas sem plano verificável retornam sql_guard_unavailable. Backup privado contém valores originais e segredos; backup_scope:database é padrão, selected_tables é opt-in somente para DML elegível de uma tabela e restaura a tabela inteira. DDL tem recuperação por snapshot, sem transação global; db/batch aceita DML InnoDB.';
        }
        if(in_array($name,['db/execute','db/batch','db/search-replace'],true)){
            $args['output_schema']['properties']=($args['output_schema']['properties']??[])+[
                'guard_contract'=>['type'=>'string','enum'=>[SqlMutationPlan::CONTRACT]],'guard_scope'=>Registry::string(),
                'target_tables'=>['type'=>'array','items'=>Registry::string()],'selected_rows'=>Registry::integer(),
                'selection_exact'=>Registry::boolean(),'backup_scope'=>['type'=>'string','enum'=>['database','selected_tables']],'backup_tables'=>['type'=>'array','items'=>Registry::string()],
                'conflict_reason'=>['type'=>'string','enum'=>['target_rows_changed','selection_changed','dependency_changed','schema_changed','unique_key_changed']],
            ];
        }
        if($name==='themes/activate'){$p['confirm_token']=Registry::string();$args['execute_callback']=[ThemePackages::class,'activate'];}
        if($name==='operations/status'){
            $args['description']='Consulta plano por plan_id ou exportação/cron/confirmação por operation_id. Mostra estado observado; efeito incerto não autoriza repetição.';
            $p['operation_id']=Registry::string();$args['input_schema']['required']=[];$native=$args['execute_callback'];
            $args['execute_callback']=static fn($in)=>isset($in['operation_id'])?(str_starts_with($in['operation_id'],'cron:')?CronTools::status($in):(str_starts_with($in['operation_id'],'phase:')?Phase::status($in):QueryExports::status($in))):$native($in);
        }
        if($name==='options/update'){$args['execute_callback']=[SiteAdmin::class,'option'];$args['description']='Grava option com backup e readback. Manutenção administra options exceto f3_mcp_* e estado interno equivalente. Endereço, idioma, papéis e cron usam os serviços nativos; mudanças de endereço exigem confirmação.';$p['confirm_token']=Registry::string();}
    	return $args;
    }
}
