<?php
/** Streaming gzip validation with separate compressed/expanded budgets. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class GzipReader {
    public static function read(string $path,array $input): array {
        if(!function_exists('inflate_init'))return Result::fail('gzip_unavailable','A extensão zlib não está disponível.');
        if(isset($input['cursor'])||isset($input['offset_bytes'])||isset($input['byte_limit']))return Result::fail('conflicting_read_modes','Leitura descompactada não aceita cursor nem offsets do arquivo bruto.');
        $source=@fopen($path,'rb');if(!$source)return Result::fail('file_read_failed','Não foi possível abrir o gzip.');
        $tmp=StateStore::directory('transfers').'/gzip-'.bin2hex(random_bytes(16)).'.tmp';$target=@fopen($tmp,'x+b');
        if(!$target){fclose($source);return Result::fail('gzip_storage_failed','Temporário privado indisponível.');}@chmod($tmp,0600);
        $initial=fstat($source);$hash=hash_init('sha256');$compressed=0;$expanded=0;$members=0;$ended=true;$context=null;$binary=false;$carry='';$deadline=microtime(true)+5;
        $text_mode=(bool)array_intersect(array_keys($input),['grep','grep_regex','offset','limit','tail_lines']);
        try {
            if(fread($source,2)!=="\x1f\x8b")return Result::fail('gzip_invalid','Assinatura gzip ausente.');rewind($source);
            while(!feof($source)) {
                if(microtime(true)>$deadline)return Result::fail('gzip_scan_limit','Orçamento de tempo atingido.',['complete'=>false,'scan_complete'=>false,'truncated'=>true,'reason'=>'time_budget','expanded_bytes'=>$expanded]);
                $chunk=fread($source,512);if(false===$chunk)return Result::fail('gzip_read_failed','Falha de leitura comprimida.');if($chunk==='')break;
                $compressed+=strlen($chunk);hash_update($hash,$chunk);
                if($compressed>16*1024*1024)return Result::fail('gzip_scan_limit','Orçamento comprimido atingido.',['complete'=>false,'scan_complete'=>false,'truncated'=>true,'reason'=>'compressed_budget']);
                $pending=$chunk;
                while($pending!=='') {
                    if($ended){$context=inflate_init(ZLIB_ENCODING_GZIP);$ended=false;}
                    $before=inflate_get_read_len($context);$output=@inflate_add($context,$pending,ZLIB_SYNC_FLUSH);$consumed=inflate_get_read_len($context)-$before;
                    if(false===$output||$consumed<=0)return Result::fail('gzip_invalid','Gzip corrompido ou membro inválido.',['complete'=>false,'integrity_verified'=>false]);
                    $expanded+=strlen($output);
                    if($expanded>64*1024*1024)return Result::fail('gzip_scan_limit','Orçamento expandido atingido.',['complete'=>false,'scan_complete'=>false,'truncated'=>true,'reason'=>'expanded_budget','expanded_bytes'=>$expanded]);
                    if(str_contains($output,"\0"))$binary=true;
                    if(!$binary) {
                        $probe=$carry.$output;$carry='';
                        if(!preg_match('//u',$probe)) {
                            $valid=false;for($trim=1;$trim<=min(3,strlen($probe));$trim++)if(preg_match('//u',substr($probe,0,-$trim))){$carry=substr($probe,-$trim);$valid=true;break;}
                            if(!$valid)$binary=true;
                        }
                    }
                    if($output!==''&&fwrite($target,$output)!==strlen($output))return Result::fail('gzip_storage_failed','Disco insuficiente durante expansão privada.');
                    $pending=substr($pending,$consumed);
                    if(inflate_get_status($context)===ZLIB_STREAM_END){$members++;$ended=true;}
                    elseif($pending!=='')return Result::fail('gzip_invalid','Estado inesperado no fluxo gzip.');
                }
            }
            if(!$ended||!$members)return Result::fail('gzip_invalid','Gzip truncado; EOF/CRC não confirmados.',['integrity_verified'=>false,'complete'=>false]);
            if($carry!==''&&!preg_match('//u',$carry))$binary=true;
            if($text_mode&&$binary)return Result::fail('gzip_binary_filter','Conteúdo descompactado é binário; filtros textuais recusados.');
            fflush($target);clearstatcache(true,$path);$final=fstat($source);$current=@stat($path);
            foreach(['dev','ino','size','mtime','ctime'] as $field)if(!$current||$initial[$field]!==$final[$field]||$current[$field]!==$initial[$field])return Result::fail('file_conflict','Arquivo mudou durante a leitura.',['conflict'=>true]);
            $max=PathGuard::max_bytes();
            if($text_mode) { $result=FileReader::read($tmp,$input,$max);if(is_wp_error($result))return Result::error($result); }
            else { rewind($target);$bytes=$expanded?fread($target,min($expanded,$max)):'';if(false===$bytes)return Result::fail('gzip_read_failed','Falha ao ler expansão verificada.');$result=Result::ok(DataSafety::bytes($bytes)+['bytes'=>strlen($bytes),'sha256'=>hash('sha256',$bytes),'sha256_scope'=>'returned_content','partial'=>$expanded>$max,'has_more'=>$expanded>$max]); }
            return array_replace($result,['path'=>PathGuard::to_relative($path),'compression'=>'gzip','compressed_bytes'=>$compressed,'file_bytes'=>$initial['size'],'expanded_bytes'=>$expanded,'gzip_members'=>$members,'compression_ratio'=>$compressed?round($expanded/$compressed,3):0,'compressed_sha256'=>hash_final($hash),'integrity_verified'=>true,'scan_complete'=>true,'complete'=>empty($result['has_more']),'truncated'=>!empty($result['has_more']),'continuation'=>'Repita seletores de linhas dentro do orçamento; não existe cursor descompactado.']);
        } finally {fclose($source);fclose($target);@unlink($tmp);}
    }
}
