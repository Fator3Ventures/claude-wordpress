<?php
/** Fill the registered SEO contract gap through Yoast's metadata API. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class SeoAdapter {
    private const FIELDS=[
        'title'=>'title','description'=>'metadesc','focus_keyphrase'=>'focuskw','canonical'=>'canonical',
        'open_graph_title'=>'opengraph-title','open_graph_description'=>'opengraph-description',
        'open_graph_image'=>'opengraph-image','twitter_title'=>'twitter-title',
        'twitter_description'=>'twitter-description','twitter_image'=>'twitter-image',
    ];
    public static function register(): void {
        $fields=[];foreach(self::FIELDS as $name=>$key)$fields[$name]=['type'=>'string','maxLength'=>4096];
        $fields['indexing']=['type'=>'string','enum'=>['default','index','noindex']];$fields['nofollow']=Registry::boolean();
        $permission=static fn($a)=>current_user_can('edit_post',(int)($a['id']??0))&&(!self::available()||current_user_can('wpseo_manage_options')||current_user_can('wpseo_edit_advanced_metadata'));
        Registry::add('content/get-seo','Lê campos armazenados pela API WPSEO_Meta e revisão final do conteúdo. Não confunde templates de título com HTML renderizado. Indisponível sem Yoast compatível; configuração institucional pertence ao Core.',['id'=>Registry::integer(1)],['id'],[self::class,'read'],$permission);
        Registry::add('content/update-seo','Atualiza somente os campos SEO fornecidos pela API do Yoast, com lock do conteúdo, revisão, backup e leitura de volta. String vazia limpa o campo; indexing:default restaura herança. Reconstrói o indexable pelo serviço do provedor; não escreve options privadas.',['id'=>Registry::integer(1),'values'=>['type'=>'object','properties'=>$fields,'minProperties'=>1,'additionalProperties'=>false],'expected_revision'=>Registry::string()],['id','values'],[self::class,'update'],$permission,false);
    }
    private static function available(): bool {
        return defined('WPSEO_VERSION')&&class_exists('WPSEO_Meta')&&is_callable(['WPSEO_Meta','get_value'])&&is_callable(['WPSEO_Meta','set_value'])&&function_exists('YoastSEO');
    }
    private static function values(int $id): array {
        $values=[];foreach(self::FIELDS as $name=>$key)$values[$name]=(string)\WPSEO_Meta::get_value($key,$id);
        $values['indexing']=match((string)\WPSEO_Meta::get_value('meta-robots-noindex',$id)){'1'=>'noindex','2'=>'index',default=>'default'};
        $values['nofollow']=(string)\WPSEO_Meta::get_value('meta-robots-nofollow',$id)==='1';return $values;
    }
    public static function read(array $input): array {
        if(!self::available())return Result::fail('seo_provider_unavailable','Yoast SEO compatível não está ativo.');
        $id=(int)$input['id'];if(!get_post($id))return Result::fail('not_found','Conteúdo não encontrado.');
        return Result::ok(['id'=>$id,'provider'=>'yoast-seo','provider_version'=>WPSEO_VERSION,'values'=>self::values($id),'revision'=>ContentTools::revision($id),'value_scope'=>'stored_metadata','rendered_html_verified'=>false]);
    }
    public static function update(array $input): array {
        if(!self::available())return Result::fail('seo_provider_unavailable','Yoast SEO compatível não está ativo.');
        $id=(int)$input['id'];if(!get_post($id))return Result::fail('not_found','Conteúdo não encontrado.');
        foreach(['canonical','open_graph_image','twitter_image'] as $field)if(isset($input['values'][$field])&&$input['values'][$field]!==''&&(!in_array(wp_parse_url($input['values'][$field],PHP_URL_SCHEME),['http','https'],true)||!wp_parse_url($input['values'][$field],PHP_URL_HOST)))return Result::fail('seo_url_invalid','URLs SEO precisam ser absolutas HTTP(S) ou vazias.');
        try{$builder=\YoastSEO()->classes->get('Yoast\\WP\\SEO\\Builders\\Indexable_Builder');}catch(\Throwable $e){return Result::fail('seo_provider_incompatible','Serviço de indexação do Yoast indisponível; nada foi alterado.');}
        if(!is_callable([$builder,'build_for_id_and_type']))return Result::fail('seo_provider_incompatible','Contrato de indexação indisponível.');
        $before=self::values($id);$changes=array_filter($input['values'],static fn($v,$k)=>$v!==$before[$k],ARRAY_FILTER_USE_BOTH);
        if(!$changes)return Result::ok(self::read($input)+['changed'=>false,'persisted'=>true]);
        $backup=Backups::create_snapshot('content/update-seo',['id'=>$id,'provider'=>'yoast-seo','version'=>WPSEO_VERSION,'values'=>$before]);if(is_wp_error($backup))return Result::error($backup);
        foreach($changes as $name=>$value){
            $key=self::FIELDS[$name]??($name==='indexing'?'meta-robots-noindex':'meta-robots-nofollow');
            if($name==='indexing')$value=match($value){'noindex'=>'1','index'=>'2',default=>'0'};
            if($name==='nofollow')$value=$value?'1':'0';
            if($value==='')\WPSEO_Meta::delete($key,$id);else \WPSEO_Meta::set_value($key,$value,$id);
        }
        $indexed=false;try{$indexed=(bool)$builder->build_for_id_and_type($id,'post');}catch(\Throwable $e){}
        clean_post_cache($id);$after=self::values($id);$filtered=[];foreach($changes as $field=>$value)if($after[$field]!==$value)$filtered[]=$field;
        $data=self::read($input)+['changed'=>$before!==$after,'applied'=>$before!==$after,'persisted'=>!$filtered,'backup_id'=>$backup,'indexable_rebuilt'=>$indexed,'filtered_fields'=>$filtered];
        if($filtered||!$indexed)return Result::fail($filtered?'seo_fields_filtered':'seo_indexable_unconfirmed','Metadados foram processados, mas há divergência ou indexação não confirmada. Consulte valores e pré-imagem.',$data);
        return Result::ok($data);
    }
}
