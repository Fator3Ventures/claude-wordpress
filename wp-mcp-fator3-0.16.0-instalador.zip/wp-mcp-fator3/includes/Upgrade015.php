<?php
/** Idempotent metadata-only upgrade. No credential copying, revocation or policy elevation. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Upgrade015 {
    private static bool $existing=false;
    public static function capture(): void {self::$existing=(int)get_option('f3_mcp_schema_version',0)===2;}
    public static function run(): void {
        if(get_option('f3_mcp_release_version',null)==='0.15.0')return;
        // Schema version 2 is also installed on clean bootstrap, so use pre-existing durable
        // state to describe the origin. This label never changes authorization decisions.
        $origin=self::$existing?'0.14.0':'clean';
        $key='release:0.15.0';
        $journal=Persistence::get('migration',$key);
        if(!$journal){Persistence::put('migration',$key,['from'=>$origin,'to'=>'0.15.0','status'=>'running','started_at'=>time()],true);}
        if(get_option('f3_mcp_014_credential_ids',null)===null){
            $ids=[];
            if($origin==='0.14.0' && class_exists('WP_Application_Passwords'))foreach(get_users(['fields'=>'ID']) as $uid){
                foreach(\WP_Application_Passwords::get_user_application_passwords((int)$uid) as $item)
                    if((int)$item['created']<=(int)get_option('f3_mcp_policy_installed_at',0))$ids[]='app:'.$item['uuid'];
            }
            add_option('f3_mcp_014_credential_ids',$ids,'',false);
        }
        // The data schema remains 2. Persisted 0.14 formats are interpreted in place.
        // Pending SQL tokens are invalidated on use; completed/uncertain results stay readable.
        Persistence::put('migration',$key,['from'=>$journal['from']??$origin,'to'=>'0.15.0','status'=>'complete','finished_at'=>time(),
            'credentials_preserved'=>true,'policies_preserved'=>true,'data_schema'=>2]);
        update_option('f3_mcp_release_version','0.15.0',false);
    }
}
