<?php
/** Selection guard v2: tokenized statements, private typed preimages, disposable simulation.
 * Temporary tables never share the physical names of live tables. No live DML is used in preview.
 */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class SqlGuardUnavailable extends \RuntimeException {}
final class SqlMutationPlan {
    public const CONTRACT='selection-guard/2';
    public const MAX_ROWS=100000;
    public const MAX_BYTES=67108864;
    private \mysqli $db;
    private array $schemas=[];
    private array $temporary=[];
    private array $locks=[];
    private array $scratch=[];
    private int $bytes=0;
    private float $started;
    private $row_transform;
    public function __construct(\mysqli $db,?callable $row_transform=null){$this->db=$db;$this->row_transform=$row_transform;$this->started=microtime(true);}
    public static function q(string $s): string {return '`'.str_replace('`','``',$s).'`';}
    public static function value($s): string {return $s===null?'NULL':"CAST(X'".bin2hex((string)$s)."' AS BINARY)";}
    private function comparison(array $schema,string $col,$value): string {
        if($value===null)return 'NULL';
        foreach($schema['columns'] as $c)if($c['Field']===$col && !empty($c['Collation'])){
            $charset=explode('_',$c['Collation'])[0];
            if(!preg_match('/^[a-z0-9]+$/D',$charset))throw new SqlGuardUnavailable('charset_not_modelled');
            return "CONVERT(X'".bin2hex((string)$value)."' USING ".$charset.") COLLATE ".$c['Collation'];
        }
        return self::value($value);
    }
    private static function render(array $t): string {$sql='';foreach($t as $tok)$sql.=($sql!==''&&$tok['value']!=='('? ' ':'').$tok['value'];return $sql;}
    private static function upper(array $t,int $i): string {return strtoupper($t[$i]['value']??'');}
    private static function id(array $t,int $i): string {
        if(!in_array($t[$i]['kind']??'',['word','identifier'],true))throw new SqlGuardUnavailable('identifier_required');
        return trim($t[$i]['value'],'`');
    }
    private static function positions(array $t): array {
        $out=[];$d=0;foreach($t as $i=>$v){if($v['value']===')')$d--;if($d<0||$d>24)throw new SqlGuardUnavailable('expression_depth');$out[$i]=$d;if($v['value']==='(')$d++;}if($d!==0)throw new SqlGuardUnavailable('expression_depth');return $out;
    }
    private function rows(string $sql, bool $numeric=false): array {
        $r=$this->db->query($sql,MYSQLI_USE_RESULT);if(!$r)throw new \RuntimeException('database_read_failed',$this->db->errno);$out=[];
        try {while($row=$numeric?$r->fetch_row():$r->fetch_assoc()){$this->bytes+=strlen(serialize($row));if(count($out)>=self::MAX_ROWS||$this->bytes>self::MAX_BYTES||microtime(true)-$this->started>30)throw new SqlGuardUnavailable('selection_budget');$out[]=$row;}}
        finally {$r->free();}return $out;
    }
    private function table(string $name,bool $allow_absent=false): array {
        if(isset($this->schemas[$name]))return $this->schemas[$name];
        global $wpdb;
        if(str_starts_with($name,$wpdb->prefix.'f3_mcp_') || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D',$name))throw new SqlGuardUnavailable('protected_source');
        $escaped=$this->db->real_escape_string($name);
        $r=$this->rows("SELECT TABLE_TYPE,ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='$escaped'");
        if(!$r){if($allow_absent)return $this->schemas[$name]=['absent'=>true];throw new SqlGuardUnavailable('table_missing');}
        if($r[0]['TABLE_TYPE']!=='BASE TABLE'||$r[0]['ENGINE']!=='InnoDB')throw new SqlGuardUnavailable('innodb_base_table_required');
        $r=$this->rows('SHOW CREATE TABLE '.self::q($name));$create=array_values($r[0])[1];
        $cols=$this->rows('SHOW FULL COLUMNS FROM '.self::q($name));$indexes=$this->rows('SHOW INDEX FROM '.self::q($name));$pk=[];$unique=[];$auto=null;
        foreach($indexes as $v){if($v['Non_unique']!=='0')continue;if(!empty($v['Sub_part'])||empty($v['Column_name']))throw new SqlGuardUnavailable('expression_or_prefix_unique_key');$unique[$v['Key_name']][(int)$v['Seq_in_index']]=$v['Column_name'];}
        foreach($unique as &$key){ksort($key);$key=array_values($key);}unset($key);ksort($unique);$pk=$unique['PRIMARY']??[];
        if(!$pk)foreach($unique as $key){$valid=true;foreach($cols as $c)if(in_array($c['Field'],$key,true)&&$c['Null']!=='NO')$valid=false;if($valid){$pk=$key;break;}}
        foreach($cols as $c)if(str_contains($c['Extra'],'auto_increment'))$auto=$c['Field'];
        $triggers=$this->rows("SELECT TRIGGER_NAME,ACTION_STATEMENT FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND EVENT_OBJECT_TABLE='$escaped'");
        $fk=$this->rows("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE CONSTRAINT_SCHEMA=DATABASE() AND ((TABLE_NAME='$escaped' AND REFERENCED_TABLE_NAME IS NOT NULL) OR REFERENCED_TABLE_NAME='$escaped')");
        if($triggers||$fk)throw new SqlGuardUnavailable($triggers?'trigger_not_modelled':'foreign_key_not_modelled');
        return $this->schemas[$name]=['create'=>$create,'canonical'=>preg_replace('/\sAUTO_INCREMENT=\d+\b/','',$create),'columns'=>$cols,'pk'=>$pk,'unique'=>$unique,'auto'=>$auto];
    }
    private function source(array $t,int &$i,array &$refs,array &$positions): string {
        $table=self::id($t,$i);$positions[]=$i;$i++;$alias=$table;
        if(self::upper($t,$i)==='AS'){$i++;$alias=self::id($t,$i++);}
        elseif(in_array($t[$i]['kind']??'',['word','identifier'],true)&&!in_array(self::upper($t,$i),['SET','WHERE','INNER','JOIN','ON','ORDER','LIMIT','LEFT','RIGHT','CROSS','GROUP','HAVING','UNION','FOR','VALUES','VALUE','SELECT','ON'],true))$alias=self::id($t,$i++);
        if(isset($refs[$alias])||in_array($table,$refs,true))throw new SqlGuardUnavailable('self_or_duplicate_source');
        $refs[$alias]=$table;$schema=$this->table($table);if(!$schema['pk'])throw new SqlGuardUnavailable('stable_identity_required');return $alias;
    }
    /** Structural grammar: one DML target; deterministic expressions; explicit physical sources. */
    public function parse(string $sql): array {
        $t=SqlReadPolicy::tokens($sql);if(is_wp_error($t))throw new SqlGuardUnavailable('token_grammar');$depth=self::positions($t);$verb=strtolower(self::upper($t,0));
        if(in_array($verb,['create','drop','alter','truncate'],true))return $this->ddl($t,$verb);
        $functions=['ABS','CEIL','CEILING','FLOOR','ROUND','TRUNCATE','MOD','CONCAT','CONCAT_WS','REPLACE','LOWER','UPPER','TRIM','LTRIM','RTRIM','SUBSTRING','SUBSTR','LEFT','RIGHT','LENGTH','CHAR_LENGTH','COALESCE','IFNULL','NULLIF','IF','CAST','CONVERT','HEX','UNHEX','LOCATE','JSON_SET','JSON_REPLACE','JSON_REMOVE','JSON_EXTRACT','JSON_UNQUOTE','JSON_OBJECT','JSON_ARRAY','VALUES'];
        foreach($t as $j=>$tok){$u=self::upper($t,$j);if($tok['kind']==='word'&&in_array($u,['UNION','WITH','GROUP','HAVING','WINDOW','OVER','RETURNING','PROCEDURE','IGNORE','LOW_PRIORITY','HIGH_PRIORITY','DELAYED','CURRENT_TIMESTAMP','CURRENT_DATE','CURRENT_TIME','LOCALTIME','LOCALTIMESTAMP'],true))throw new SqlGuardUnavailable('construct_not_modelled');
            if($tok['kind']==='word'&&($t[$j+1]['value']??'')==='('&&!in_array($u,array_merge($functions,['IN','EXISTS','NOT','AND','OR','WHERE','ON','VALUES','VALUE']),true)){
                // The explicit INSERT column list follows its physical table, not a function.
                if(!($j===2&&in_array($verb,['insert','replace'],true)))throw new SqlGuardUnavailable('function_not_modelled');
            }
        }
        $refs=[];$positions=[];$i=1;$target='';$select='';$assign=[];$deps=[];
        if($verb==='delete'){if(self::upper($t,$i)==='FROM')$i++;else{$delete_alias=self::id($t,$i++);if(self::upper($t,$i++)!=='FROM')throw new SqlGuardUnavailable('single_delete_target');}}
        if(in_array($verb,['insert','replace'],true)){if(self::upper($t,$i)==='INTO')$i++;$target_table=self::id($t,$i);$positions[]=$i++;$target=$target_table;$refs[$target]=$target_table;$schema=$this->table($target_table);if(!$schema['pk'])throw new SqlGuardUnavailable('stable_identity_required');}
        else{$target=$this->source($t,$i,$refs,$positions);$target_table=$refs[$target];if(isset($delete_alias)&&$delete_alias!==$target)throw new SqlGuardUnavailable('single_delete_target');}
        $cl=[];foreach($t as $j=>$tok)if($depth[$j]===0&&$tok['kind']==='word'&&in_array(self::upper($t,$j),['SET','WHERE','ORDER','LIMIT','SELECT','VALUES','VALUE','ON'],true))$cl[self::upper($t,$j)]??=$j;
        $columns=[];
        if(in_array($verb,['insert','replace'],true)){
            if(($t[$i]['value']??'')!=='(')throw new SqlGuardUnavailable('insert_columns_required');$i++;
            while(($t[$i]['value']??'')!==')'){$columns[]=self::id($t,$i++);if(($t[$i]['value']??'')===',')$i++;elseif(($t[$i]['value']??'')!==')')throw new SqlGuardUnavailable('insert_columns_required');}$i++;
            if(count($columns)!==count(array_unique($columns)))throw new SqlGuardUnavailable('duplicate_columns');
            if(self::upper($t,$i)==='SELECT'){
                $from=null;foreach($t as $j=>$tok)if($j>$i&&$depth[$j]===0&&self::upper($t,$j)==='FROM'){$from=$j;break;}
                if($from===null)throw new SqlGuardUnavailable('insert_select_source');$s=$from+1;$alias=$this->source($t,$s,$refs,$positions);
                if(!in_array(self::upper($t,$s),['WHERE','ORDER','LIMIT',''],true))throw new SqlGuardUnavailable('insert_select_source');
                if(isset($cl['LIMIT']))$this->total_order($t,$cl,$alias,$this->schemas[$refs[$alias]]['pk']);
                $select=self::render(array_slice($t,$i));$deps[]='SELECT '.self::q($alias).'.* FROM '.self::render(array_slice($t,$from+1));
            }elseif(!in_array(self::upper($t,$i),['VALUES','VALUE'],true))throw new SqlGuardUnavailable('insert_values_required');
        }else{
            $from_start=$verb==='delete'?(isset($delete_alias)?3:2):1;
            $from_end=$verb==='update'?($cl['SET']??throw new SqlGuardUnavailable('set_required')):($cl['WHERE']??$cl['ORDER']??$cl['LIMIT']??count($t));
            while($i<$from_end){if(self::upper($t,$i)==='INNER')$i++;if(self::upper($t,$i++)!=='JOIN')throw new SqlGuardUnavailable('inner_join_required');$this->source($t,$i,$refs,$positions);if(self::upper($t,$i++)!=='ON')throw new SqlGuardUnavailable('join_on_required');while($i<$from_end&&!(($depth[$i]??0)===0&&in_array(self::upper($t,$i),['JOIN','INNER'],true)))$i++;}
            $suffix=$cl['WHERE']??$cl['ORDER']??$cl['LIMIT']??count($t);
            $select='SELECT '.implode(',',array_map(static fn($a)=>self::q($a).'.*',array_keys($refs))).' FROM '.self::render(array_slice($t,$from_start,$from_end-$from_start)).' '.self::render(array_slice($t,$suffix));
            if($verb==='update'){
                $assign=array_slice($t,$cl['SET']+1,$suffix-$cl['SET']-1);$levels=self::positions($assign);$start=0;
                foreach($assign as $j=>$a){
                    if(strtoupper($a['value'])==='SELECT')throw new SqlGuardUnavailable('assignment_subquery');
                    if($a['value']==='='&&$levels[$j]===0){
                        $lhs=array_slice($assign,$start,$j-$start);
                        if(count($lhs)===1)$col=self::id($lhs,0);
                        elseif(count($lhs)===3&&$lhs[1]['value']==='.'&&self::id($lhs,0)===$target)$col=self::id($lhs,2);
                        else throw new SqlGuardUnavailable('single_update_target');
                        if(!in_array($col,array_column($this->schemas[$target_table]['columns'],'Field'),true))throw new SqlGuardUnavailable('unknown_assignment_column');
                    }
                    if($a['value']===','&&$levels[$j]===0)$start=$j+1;
                }
            }
            // Every subquery has its own explicit dependency read and locking clause.
            foreach($t as $j=>$tok)if($j>=$suffix&&self::upper($t,$j)==='SELECT'){
                if($depth[$j]!==1)throw new SqlGuardUnavailable('nested_subquery');$end=$j;while($end<count($t)&&!(($depth[$end]??0)===0&&($t[$end]['value']??'')===')'))$end++;
                $from=null;for($k=$j+1;$k<$end;$k++)if(self::upper($t,$k)==='FROM'&&$depth[$k]===1){$from=$k;break;}
                if($from===null)throw new SqlGuardUnavailable('subquery_source');$k=$from+1;$alias=$this->source($t,$k,$refs,$positions);
                if(self::upper($t,$k)!=='WHERE')throw new SqlGuardUnavailable('subquery_predicate');
                $inner=self::render(array_slice($t,$k+1,$end-$k-1));$sub_from=self::render(array_slice($t,$from+1,$k-$from-1));
                $correlated=false;for($x=$k+1;$x<$end;$x++)if(trim($t[$x]['value'],'`')===$target&&($t[$x+1]['value']??'')==='.')$correlated=true;
                if($correlated)$deps[]='SELECT '.self::q($alias).'.* FROM '.$sub_from.', '.self::q($target_table).' AS '.self::q($target).' WHERE '.$inner;
                else $deps[]='SELECT '.self::q($alias).'.* FROM '.$sub_from.' WHERE '.$inner;
            }
            // SELECT projection above intentionally includes only top-level joined sources.
            if(isset($cl['LIMIT'])){
                $this->total_order($t,$cl,$target,$this->schemas[$target_table]['pk']);
            }
        }
        foreach($refs as $name){foreach($this->schemas[$name]['columns'] as $c)if(str_contains(strtolower($c['Extra']),'on update')||str_contains($c['Extra'],'GENERATED'))throw new SqlGuardUnavailable('generated_value_not_modelled');}
        return compact('sql','t','verb','target','target_table','refs','positions','select','deps','columns')+['ddl'=>false];
    }
    /** Only direct column terms prove a total order; mentioning a key inside an expression does not. */
    private function total_order(array $t,array $cl,string $alias,array $identity): void {
        if(!isset($cl['ORDER'])||self::upper($t,$cl['ORDER']+1)!=='BY')throw new SqlGuardUnavailable('limit_requires_total_order');
        $i=$cl['ORDER']+2;$end=$cl['LIMIT'];$columns=[];
        while($i<$end){
            $column=self::id($t,$i++);
            if(($t[$i]['value']??'')==='.'){if($column!==$alias)throw new SqlGuardUnavailable('limit_requires_total_order');$i++;$column=self::id($t,$i++);}
            $columns[]=$column;
            if(in_array(self::upper($t,$i),['ASC','DESC'],true))$i++;
            if($i===$end)break;
            if(($t[$i++]['value']??'')!==',')throw new SqlGuardUnavailable('limit_requires_total_order');
        }
        if(array_diff($identity,$columns))throw new SqlGuardUnavailable('limit_requires_total_order');
    }
    private function ddl(array $t,string $verb): array {
        // DDL is one object, with explicit backup recovery; it never enters a DML batch.
        $i=1;if(self::upper($t,$i)==='TABLE')$i++;else throw new SqlGuardUnavailable('ddl_table_required');
        if(self::upper($t,$i)==='IF')throw new SqlGuardUnavailable('ddl_condition_not_modelled');
        $name=self::id($t,$i);$schema=$this->table($name,$verb==='create');
        foreach($t as $tok)if($tok['kind']==='word'&&in_array(strtoupper($tok['value']),['SELECT','LIKE','REFERENCES','FOREIGN','RENAME','PARTITION','TABLESPACE','DIRECTORY','UNION','TRIGGER'],true))throw new SqlGuardUnavailable('ddl_dependency_not_modelled');
        if($verb==='create'&&empty($schema['absent']))throw new SqlGuardUnavailable('create_target_exists');
        if(in_array($verb,['drop','truncate'],true)&&$i!==count($t)-1)throw new SqlGuardUnavailable('single_ddl_object');
        return ['sql'=>self::render($t),'ddl'=>true,'verb'=>$verb,'target_table'=>$name,'refs'=>[$name=>$name],'positions'=>[$i],'t'=>$t];
    }
    private function rewrite(string $sql): string {
        $t=SqlReadPolicy::tokens($sql);if(is_wp_error($t))throw new SqlGuardUnavailable('rewrite_grammar');
        foreach($t as $i=>&$tok){if(!in_array($tok['kind'],['word','identifier'],true))continue;$id=trim($tok['value'],'`');
            if(isset($this->temporary[$id]) && (in_array(self::upper($t,$i-1),['FROM','JOIN','UPDATE','INTO'],true)||($t[$i+1]['value']??'')==='.'||(($t[$i-1]['value']??'')===','&&isset($this->schemas[$id]))))$tok['value']=self::q($this->temporary[$id]);
        }unset($tok);return self::render($t);
    }
    private function clone_tables(): void {
        foreach($this->schemas as $name=>$s){if(!empty($s['absent']))continue;$temp='f3_guard_'.bin2hex(random_bytes(12));$this->temporary[$name]=$temp;
            DatabaseRead::checked($this->db,'CREATE TEMPORARY TABLE '.self::q($temp).' LIKE '.self::q($name));
            // Plain SELECT is an MVCC read. INSERT ... SELECT would lock the live source.
            $rows=$this->rows('SELECT * FROM '.self::q($name));$cols=implode(',',array_map([self::class,'q'],array_column($s['columns'],'Field')));
            foreach(array_chunk($rows,100) as $chunk){$values=[];foreach($chunk as $row)$values[]='('.implode(',',array_map([self::class,'value'],array_values($row))).')';DatabaseRead::checked($this->db,'INSERT INTO '.self::q($temp).' ('.$cols.') VALUES '.implode(',',$values));}
        }
    }
    private function digest(array $rows): string {$r=array_map('serialize',$rows);sort($r,SORT_STRING);return hash_hmac('sha256',serialize($r),wp_salt('auth'));}
    private function key(array $row,array $cols): string {return hash_hmac('sha256',serialize(array_map(static fn($k)=>$row[$k],$cols)),wp_salt('auth'));}
    private function keys(array $rows,array $cols): array {$out=[];foreach($rows as $row)$out[]=$this->key($row,$cols);sort($out,SORT_STRING);return array_values(array_unique($out));}
    private function query_guard(string $sql): array {
        $rows=$this->rows($this->rewrite($sql));$this->locks[$sql]=true;return ['digest'=>$this->digest($rows),'count'=>count($rows)];
    }
    public static function lock_sql(string $sql): string {
        $t=SqlReadPolicy::tokens($sql);if(is_wp_error($t))throw new SqlGuardUnavailable('lock_grammar');$d=self::positions($t);$sub=false;$out=[];
        foreach($t as $i=>$tok){if(strtoupper($tok['value'])==='SELECT'&&$d[$i]===1)$sub=true;if($sub&&$tok['value']===')'&&$d[$i]===0){$out[]='FOR UPDATE';$sub=false;}$out[]=$tok['value'];}
        $sql='';foreach($out as $v)$sql.=($sql!==''&&$v!=='('? ' ':'').$v;return $sql.' FOR UPDATE';
    }
    public static function lock(\mysqli $db,array $queries): void {
        sort($queries,SORT_STRING);$bytes=0;$start=microtime(true);
        foreach($queries as $sql){$r=$db->query(self::lock_sql($sql),MYSQLI_USE_RESULT);if(!$r)throw new \RuntimeException('database_lock_failed',$db->errno);$count=0;
            try{while($row=$r->fetch_row()){$bytes+=strlen(serialize($row));if(++$count>self::MAX_ROWS||$bytes>self::MAX_BYTES||microtime(true)-$start>30)throw new SqlGuardUnavailable('selection_budget');}}
            finally{$r->free();}
        }
    }
    public function build(array $sqls): array {
        $mode=$this->rows('SELECT @@SESSION.sql_mode AS mode')[0]['mode'];if(str_contains($mode,'NO_BACKSLASH_ESCAPES'))foreach($sqls as $sql)if(str_contains($sql,'\\'))throw new SqlGuardUnavailable('sql_mode_quoting');
        $asts=[];foreach($sqls as $sql)$asts[]=$this->parse($sql);$ddl=(bool)$asts[0]['ddl'];
        if(count($asts)>1)foreach($asts as $ast)if($ast['ddl']||count($ast['refs'])>1)throw new SqlGuardUnavailable('batch_sources_not_modelled');
        $guard=['contract'=>self::CONTRACT,'schema'=>[],'steps'=>[]];$presentation=['guard_contract'=>self::CONTRACT,'guard_scope'=>$ddl?'ddl_objects':'selected_rows_and_dependencies','target_tables'=>array_values(array_unique(array_column($asts,'target_table'))),'selected_rows'=>0,'selection_exact'=>true,'backup_scope'=>'database','backup_contains_sensitive_values'=>true,'statement_previews'=>[],'preview_rows'=>[],'redacted'=>[],'transactional'=>!$ddl];
        foreach($this->schemas as $name=>$s)$guard['schema'][$name]=hash('sha256',!empty($s['absent'])?'absent':($ddl?$s['create']:$s['canonical']));ksort($guard['schema']);
        if($ddl){$a=$asts[0];$name=$a['target_table'];$rows=!empty($this->schemas[$name]['absent'])?[]:$this->rows('SELECT * FROM '.self::q($name));$guard['steps'][]=['target'=>$this->digest($rows),'selection'=>[],'dependencies'=>[],'unique'=>[]];$presentation['selected_rows']=count($rows);$presentation['statement_previews'][]=['index'=>0,'verb'=>$a['verb'],'selected_rows'=>count($rows)];return compact('guard','presentation','asts')+['locks'=>[]];}
        try {$this->clone_tables();
            foreach($asts as $idx=>$a){$name=$a['target_table'];$s=$this->schemas[$name];$before=$this->rows('SELECT * FROM '.self::q($this->temporary[$name]));$pre=[];$deps=[];$depqueries=$a['deps'];
                if($a['select']!==''&&!in_array($a['verb'],['insert','replace'],true)){
                    // Numeric fields prevent duplicate column names across joined sources from hiding bytes.
                    $raw=$this->rows($this->rewrite($a['select']),true);
                    if(count($raw)>self::MAX_ROWS)throw new SqlGuardUnavailable('selection_budget');$n=count($s['columns']);$names=array_column($s['columns'],'Field');
                    foreach($raw as $row)$pre[]=array_combine($names,array_slice($row,0,$n));
                    if(count($pre)!==count($this->keys($pre,$s['pk'])))throw new SqlGuardUnavailable('ambiguous_join_target');
                    if(count($a['refs'])>1)$deps[]=$this->digest($raw);
                    $this->locks[$a['select']]=true;
                }
                foreach($depqueries as $q)$deps[]=$this->query_guard($q);
                if(count($asts)>1&&in_array($a['verb'],['insert','replace'],true)&&$s['auto']&&!in_array($s['auto'],$a['columns'],true))throw new SqlGuardUnavailable('batch_generated_identity');
                $prior='f3_guard_pre_'.bin2hex(random_bytes(10));$this->scratch[]=$prior;
                DatabaseRead::checked($this->db,'CREATE TEMPORARY TABLE '.self::q($prior).' LIKE '.self::q($this->temporary[$name]));
                DatabaseRead::checked($this->db,'INSERT INTO '.self::q($prior).' SELECT * FROM '.self::q($this->temporary[$name]));
                $candidates=$pre;
                if(in_array($a['verb'],['insert','replace'],true)){
                    foreach($s['columns'] as $c)if(!in_array($c['Field'],$a['columns'],true)&&str_contains(strtolower((string)$c['Default']),'current_timestamp'))throw new SqlGuardUnavailable('nondeterministic_default');
                    $candidate='f3_guard_input_'.bin2hex(random_bytes(10));$this->scratch[]=$candidate;
                    DatabaseRead::checked($this->db,'CREATE TEMPORARY TABLE '.self::q($candidate).' LIKE '.self::q($this->temporary[$name]));
                    $original=$this->temporary[$name];$this->temporary[$name]=$candidate;
                    $input_tokens=$a['t'];$levels=self::positions($input_tokens);foreach($input_tokens as $k=>$tok)if(self::upper($input_tokens,$k)==='ON'&&$levels[$k]===0){$input_tokens=array_slice($input_tokens,0,$k);break;}
                    try{DatabaseRead::checked($this->db,$this->rewrite(self::render($input_tokens)));$candidates=$this->rows('SELECT * FROM '.self::q($candidate));}
                    finally{$this->temporary[$name]=$original;}
                }
                // Execute only against disposable tables. Errors here never touch the live database.
                DatabaseRead::checked($this->db,$this->rewrite($a['sql']));$predicted=$this->db->affected_rows;
                if($this->row_transform){
                    // Serialize-aware search/replace is simulated on the same disposable preimage.
                    // Its prospective unique values therefore participate in the normal guard.
                    $predicted=0;
                    foreach($pre as $row){
                        $next=($this->row_transform)($name,$row,$s);$sets=[];$where=[];
                        foreach($next as $col=>$value)if($value!==$row[$col])$sets[]=self::q($col).'='.self::value($value);
                        if(!$sets)continue;
                        foreach($s['pk'] as $col)$where[]=self::q($col).' <=> '.$this->comparison($s,$col,$row[$col]);
                        DatabaseRead::checked($this->db,'UPDATE '.self::q($this->temporary[$name]).' SET '.implode(',',$sets).' WHERE '.implode(' AND ',$where));
                        $predicted+=$this->db->affected_rows;
                    }
                }
                $after=$this->rows('SELECT * FROM '.self::q($this->temporary[$name]));$old=[];$new=[];foreach($before as $r)$old[$this->key($r,$s['pk'])]=$r;foreach($after as $r)$new[$this->key($r,$s['pk'])]=$r;
                $changed=[];foreach($new as $k=>$r)if(!isset($old[$k])||$r!==$old[$k])$changed[]=$r;
                if(in_array($a['verb'],['insert','replace'],true))foreach($old as $k=>$r)if(!isset($new[$k])||$r!==$new[$k])$pre[]=$r;
                $unique=[];
                // Guard all affected unique values, including absent keys and key changes.
                foreach(array_merge($candidates,$changed) as $row)foreach($s['unique'] as $cols){
                    if(in_array($a['verb'],['insert','replace'],true)&&$s['auto']&&$cols===[$s['auto']]&&!in_array($s['auto'],$a['columns'],true))continue;
                    $parts=[];foreach($cols as $col){if($row[$col]===null){$parts=[];break;}$parts[]=self::q($col).' = '.$this->comparison($s,$col,$row[$col]);}if(!$parts)continue;
                    $q='SELECT * FROM '.self::q($name).' WHERE '.implode(' AND ',$parts);$this->locks[$q]=true;
                    // Compare against pre-statement state, not the simulated postimage.
                    $matches=$this->rows('SELECT * FROM '.self::q($prior).' WHERE '.implode(' AND ',$parts));
                    if(in_array($a['verb'],['insert','replace'],true))foreach($matches as $matched)$pre[$this->key($matched,$s['pk'])]=$matched;
                    $unique[hash_hmac('sha256',$q,wp_salt('auth'))]=$this->digest($matches);
                }ksort($unique);
                $dedup=[];foreach($pre as $row)$dedup[$this->key($row,$s['pk'])]=$row;$pre=array_values($dedup);
                // Lock row identities selected by later dependent batch steps, even when they
                // are not selected by the same predicate in the original snapshot.
                foreach($pre as $row){$parts=[];foreach($s['pk'] as $col)$parts[]=self::q($col).' = '.$this->comparison($s,$col,$row[$col]);$this->locks['SELECT * FROM '.self::q($name).' WHERE '.implode(' AND ',$parts)]=true;}
                $guard['steps'][]=['selection'=>$this->keys($pre,$s['pk']),'target'=>$this->digest($pre),'dependencies'=>$deps,'unique'=>$unique];
                $shown=DataSafety::rows(array_slice($pre,0,max(0,200-count($presentation['preview_rows']))),$name);
                $presentation['preview_rows']=array_merge($presentation['preview_rows'],DatabaseWriter::transport_rows($shown['rows']));$presentation['redacted']=array_merge($presentation['redacted'],$shown['redacted']);$presentation['selected_rows']+=count($pre);
                $presentation['statement_previews'][]=['index'=>$idx,'verb'=>$a['verb'],'selected_rows'=>count($pre),'predicted_affected_rows'=>$predicted,'preview_truncated'=>count($pre)>200];
            }
            return compact('guard','presentation','asts')+['locks'=>array_keys($this->locks)];
        }finally{foreach(array_merge(array_values($this->temporary),$this->scratch) as $temp)try{DatabaseRead::checked($this->db,'DROP TEMPORARY TABLE IF EXISTS '.self::q($temp));}catch(\Throwable $ignored){}$this->temporary=[];$this->scratch=[];}
    }
    public static function conflict(array $before,array $after): ?string {
        if($before['schema']!==$after['schema'])return 'schema_changed';
        foreach($before['steps'] as $i=>$s){$n=$after['steps'][$i]??[];foreach(['selection'=>'selection_changed','target'=>'target_rows_changed','dependencies'=>'dependency_changed','unique'=>'unique_key_changed'] as $key=>$reason)if(($s[$key]??null)!==($n[$key]??null))return $reason;}
        return null;
    }
}
