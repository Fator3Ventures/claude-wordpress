<?php
/** Durable SQL confirmation, pinned MySQL connection, locks before a consistent read view. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SqlMutation {
    private static function fields(array $plan): array {return array_intersect_key($plan['presentation'],array_flip(['guard_contract','guard_scope','target_tables','selected_rows','selection_exact','backup_scope','backup_tables','backup_contains_sensitive_values']));}
    private static function scope(array &$p,string $name,array $input): void {
        $scope=$input['backup_scope']??'database';
        if(!in_array($scope,['database','selected_tables'],true))throw new SqlGuardUnavailable('backup_scope_unsupported');
        if($scope==='selected_tables'){
            if($name!=='db/execute'||count($p['asts'])!==1)throw new SqlGuardUnavailable('backup_scope_unsupported');
            $a=$p['asts'][0];
            if(!in_array($a['verb'],['insert','replace','update','delete'],true)||count($a['refs']??[])!==1||!empty($a['deps']))throw new SqlGuardUnavailable('backup_scope_unsupported');
        }
        $p['presentation']['backup_scope']=$scope;
        $p['presentation']['backup_tables']=$scope==='selected_tables'?$p['presentation']['target_tables']:[];
    }
    private static function identity(string $name,array $input): array {
        unset($input['confirm_token'],$input['idempotency_key']);
        return ['name'=>$name,'intent'=>hash('sha256',serialize($input)),'connection_id'=>ConnectionContext::key(),'user_id'=>get_current_user_id(),'site_id'=>get_current_blog_id()];
    }
    private static function failed(\Throwable $e,?\mysqli $db,bool $before_write=true): array {
        $errno=(int)$e->getCode()?:($db?$db->errno:0);
        if($e instanceof SqlGuardUnavailable && $e->getMessage()==='backup_scope_unsupported')return Result::fail('backup_scope_unsupported','Escopo reduzido exige db/execute com DML de uma tabela sem dependências externas.',['applied'=>false,'changed'=>false]);
        if($e instanceof SqlGuardUnavailable)return Result::fail($e->getMessage()==='selection_budget'?'sql_selection_budget':'sql_guard_unavailable','Não é possível provar a seleção desta forma SQL. Ajuste a instrução conforme a matriz do manual.',['reason'=>$e->getMessage(),'applied'=>false,'changed'=>false]);
        if(in_array($errno,[1205,1213,3024],true))return Result::fail($errno===1213?'database_deadlock':'database_lock_timeout','A transação foi cancelada por contenção ou tempo limite. Revise o estado antes de repetir.',['applied'=>false,'changed'=>false,'retryable'=>true,'mysql_errno'=>$errno]);
        return Result::fail($before_write?'sql_preview_failed':'sql_write_failed','O MySQL recusou a operação. SQL e valores originais são omitidos.',['applied'=>false,'changed'=>false,'mysql_errno'=>$errno]);
    }
    private static function connect(): \mysqli {$db=DatabaseRead::connection();DatabaseRead::checked($db,'SET SESSION innodb_lock_wait_timeout=5');DatabaseRead::checked($db,'SET SESSION lock_wait_timeout=5');DatabaseRead::checked($db,'SET SESSION max_execution_time=30000');DatabaseRead::checked($db,'SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');return $db;}
    /** The old bucket/index remain readable by operations/status; only the SQL guard is versioned. */
    public static function run(string $name,array $input,array $sqls,?callable $effect=null,?callable $extra=null,?callable $row_transform=null): array {
        $ddl=in_array(SqlGuard::verb($sqls[0]),['create','alter','drop','truncate'],true);
        return Locks::run(['database-admin:'.get_current_blog_id()=>($ddl?LOCK_EX:LOCK_SH)],static fn()=>SqlArtifacts::lock(static fn()=>self::run_locked($name,$input,$sqls,$effect,$extra,$row_transform)));
    }
    private static function run_locked(string $name,array $input,array $sqls,?callable $effect,?callable $extra,?callable $row_transform): array {
        $who=self::identity($name,$input);$token=$input['confirm_token']??'';
        if($token===''){
            $db=null;try{$db=self::connect();DatabaseRead::checked($db,'START TRANSACTION');$p=(new SqlMutationPlan($db,$row_transform))->build($sqls);self::scope($p,$name,$input);if($extra)$p['presentation']+=$extra($db);
                if($name==='db/execute')$p['presentation']['preview_rows']=array_slice($p['presentation']['preview_rows'],0,max(1,min(200,(int)($input['limit_preview']??20))));
                $db->rollback();
                $token=bin2hex(random_bytes(32));$id=bin2hex(random_bytes(16));$s=$who+['operation_id'=>'phase:'.$id,'guard_contract'=>SqlMutationPlan::CONTRACT,'guard'=>$p['guard'],'locks'=>$p['locks'],'expires'=>time()+600,'status'=>'pending'];
                StateStore::put('phase014-index',$id,['token'=>$token]);StateStore::put('phase014',$token,$s);
                return Result::ok(['operation_id'=>$s['operation_id'],'preview'=>true,'applied'=>false,'changed'=>false,'confirm_token'=>$token,'expires_at'=>gmdate('c',$s['expires']),'summary'=>$p['presentation']]+self::fields($p)+array_intersect_key($p['presentation'],array_flip(['preview_rows','redacted','statement_previews'])));
            }catch(\Throwable $e){if(($input['backup_scope']??'database')==='selected_tables' && $e instanceof SqlGuardUnavailable)$e=new SqlGuardUnavailable('backup_scope_unsupported');return self::failed($e,$db);}finally{if($db){try{$db->rollback();$db->close();}catch(\Throwable $ignored){}}}
        }
        if(!preg_match('/^[a-f0-9]{64}$/D',$token))return Result::fail('confirmation_invalid','Confirmação inválida.');
        return Locks::run(['phase014:'.$token=>LOCK_EX],static function()use($who,$name,$input,$sqls,$token,$effect,$extra,$row_transform){
            $s=StateStore::get('phase014',$token);
            if(!$s && $name==='db/execute'){
                $old=StateStore::get('db-confirmations',$token);
                if($old && ($old['user']??0)===get_current_user_id() && ($old['blog']??0)===get_current_blog_id()
                    && ($old['connection_id']??'')===ConnectionContext::key() && hash_equals($old['sql_hash']??'',hash('sha256',$sqls[0]))){
                    if(($old['status']??'')==='complete')return $old['result']+['replayed'=>true];
                    return Result::fail(($old['status']??'')==='pending'?'confirmation_version_changed':'operation_uncertain','Confirmação da 0.14: faça nova prévia somente se o efeito não foi iniciado.',['applied'=>($old['status']??'')==='pending'?false:null,'retryable'=>false]);
                }
            }
            if(!$s||$s['name']!==$name||$s['intent']!==$who['intent']||$s['connection_id']!==$who['connection_id'])return Result::fail('confirmation_invalid','Confirmação não pertence à seleção/conexão.');
            if(isset($s['user_id'])&&($s['user_id']!==$who['user_id']||$s['site_id']!==$who['site_id']))return Result::fail('confirmation_invalid','Identidade alterada.');
            if($s['status']==='complete')return $s['result']+['replayed'=>true];
            if($s['status']!=='pending')return Result::fail('operation_uncertain','Efeito iniciado sem conclusão. Consulte operations/status; não reaplique.',['applied'=>null,'changed'=>null,'operation_id'=>$s['operation_id'],'retryable'=>false]);
            if(($s['guard_contract']??'')!==SqlMutationPlan::CONTRACT)return Result::fail('confirmation_version_changed','Confirmação anterior à guarda 2. Faça nova prévia.',['applied'=>false,'changed'=>false]);
            if($s['expires']<time())return Result::fail('confirmation_expired','Prévia expirada.',['applied'=>false]);
            $db=null;$backup=null;$started=false;$committed=false;$commit_attempted=false;$ddl=false;$table_locked=false;$result=null;
            try{
                $db=self::connect();$ddl=in_array(SqlGuard::verb($sqls[0]),['create','alter','drop','truncate'],true);
                if(!$ddl){DatabaseRead::checked($db,'START TRANSACTION');do_action('f3_mcp_sql_checkpoint','before_locks',$s['operation_id'],null,$db);SqlMutationPlan::lock($db,$s['locks']);}
                else DatabaseRead::checked($db,'START TRANSACTION WITH CONSISTENT SNAPSHOT');
                $p=(new SqlMutationPlan($db,$row_transform))->build($sqls);self::scope($p,$name,$input);$reason=SqlMutationPlan::conflict($s['guard'],$p['guard']);
                if($reason)return Result::fail('database_conflict','A seleção mudou. Revise uma nova prévia.',['operation_id'=>$s['operation_id'],'conflict'=>true,'conflict_reason'=>$reason,'applied'=>false,'changed'=>false]+self::fields($p));
                do_action('f3_mcp_sql_checkpoint','locked',$s['operation_id'],null);
                // Original values, consistent MVCC reads, no database-wide FOR UPDATE.
                try{$backup=DatabaseAdmin::dump($db,($p['presentation']['backup_scope']==='selected_tables'?$p['presentation']['backup_tables']:null),['purpose'=>'sql_mutation','ability'=>$name,'operation_id'=>$s['operation_id'],'references'=>[$s['operation_id']]]);}catch(\Throwable $e){return Result::fail('database_backup_failed','Backup indisponível; nenhuma instrução foi aplicada.',['applied'=>false,'changed'=>false,'operation_id'=>$s['operation_id']]);}
                if(!PrivateArtifact::verify($backup['id']))throw new SqlGuardUnavailable('backup_verification_failed');
                if($ddl){
                    $db->commit();$target=$p['asts'][0]['target_table'];
                    if($p['asts'][0]['verb']!=='create'){
                        DatabaseRead::checked($db,'LOCK TABLES '.SqlMutationPlan::q($target).' WRITE');$table_locked=true;
                        // Metadata reads on information_schema are allowed under LOCK TABLES.
                        $locked=(new SqlMutationPlan($db,$row_transform))->build($sqls);$reason=SqlMutationPlan::conflict($s['guard'],$locked['guard']);
                        if($reason)return Result::fail('database_conflict','O alvo DDL mudou antes da trava.',['operation_id'=>$s['operation_id'],'conflict'=>true,'conflict_reason'=>$reason,'applied'=>false,'changed'=>false]);
                    }
                }
                $s['status']='running';$s['backup_id']=$backup['id'];StateStore::put('phase014',$token,$s);$started=true;
                $results=[];$effect_result=[];
                if($effect){$effect_result=$effect($db);$results=$effect_result['statement_results'];}
                else foreach($sqls as $idx=>$sql){do_action('f3_mcp_sql_checkpoint','before_statement',$s['operation_id'],$idx);DatabaseRead::checked($db,$sql);$results[]=['index'=>$idx,'affected_rows'=>$db->affected_rows,'insert_id'=>$db->insert_id?:null];}
                // A readback of each target gives a durable receipt of the committed effect.
                $readback=[];foreach($p['presentation']['target_tables'] as $table){if($ddl&&SqlGuard::verb($sqls[0])==='drop')continue;$r=DatabaseRead::checked($db,'SELECT COUNT(*) FROM '.SqlMutationPlan::q($table));$readback[$table]=['rows_at_readback'=>(int)$r->fetch_row()[0]];$r->free();}
                do_action('f3_mcp_sql_checkpoint','before_commit',$s['operation_id'],null);
                if(!$ddl){$commit_attempted=true;if(!$db->commit())throw new \RuntimeException('commit_uncertain');}$committed=true;do_action('f3_mcp_sql_checkpoint','after_commit',$s['operation_id'],null);
                $affected=array_sum(array_column($results,'affected_rows'));$result=Result::ok(['applied'=>true,'changed'=>$ddl||$affected>0,'persisted'=>true,'atomic'=>!$ddl,'backup_id'=>$backup['id'],'artifact_id'=>$backup['id'],'backup_bytes'=>$backup['bytes'],'backup_tables'=>array_keys($backup['tables']),'statement_results'=>$results,'affected_rows'=>$affected,'readback'=>$readback,'recovery_method'=>$ddl?'snapshot_restore':'transaction_and_snapshot','operation_id'=>$s['operation_id']]+self::fields($p)+$effect_result);
                $s['status']='complete';$s['result']=$result;StateStore::put('phase014',$token,$s);wp_cache_flush();return $result;
            }catch(\Throwable $e){
                if($db&&!$committed&&!$ddl)try{$db->rollback();}catch(\Throwable $ignored){}
                if($committed||$commit_attempted||($started&&$ddl)||($started&&in_array((int)$e->getCode(),[2006,2013],true))){return Result::fail('operation_uncertain','Recibo inconclusivo; consulte operations/status e o backup. Não repetir automaticamente.',['operation_id'=>$s['operation_id'],'backup_id'=>$backup['id']??null,'applied'=>null,'changed'=>null,'retryable'=>false]);}
                if(!$started && (in_array((int)$e->getCode(),[1062,1146,1054,1347],true) || $e instanceof SqlGuardUnavailable && in_array($e->getMessage(),['trigger_not_modelled','foreign_key_not_modelled','table_missing','innodb_base_table_required','stable_identity_required'],true)))
                    return Result::fail('database_conflict','A seleção ou estrutura mudou. Faça nova prévia.',['operation_id'=>$s['operation_id'],'conflict'=>true,'conflict_reason'=>(int)$e->getCode()===1062?'unique_key_changed':'schema_changed','applied'=>false,'changed'=>false]);
                $result=self::failed($e,$db,!$started)+['operation_id'=>$s['operation_id'],'backup_id'=>$backup['id']??null];
                if($started){$s['status']='complete';$s['result']=$result;StateStore::put('phase014',$token,$s);}return $result;
            }finally{if($db){try{if($table_locked)$db->query('UNLOCK TABLES');$db->rollback();$db->close();}catch(\Throwable $ignored){}}}
        });
    }
}
