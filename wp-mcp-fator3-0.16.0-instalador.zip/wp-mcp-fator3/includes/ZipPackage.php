<?php
/** Bounded ZIP extraction for plugin staging (stored/deflated, single disk, no links). */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ZipPackage {
    public static function extract(string $zip, string $directory): array {
        $stream = fopen($zip, 'rb');
        if (!$stream) throw new \RuntimeException('ZIP unavailable.');
        try {
            $size = filesize($zip);
            if ($size < 22 || $size > PathGuard::max_bytes()) throw new \RuntimeException('ZIP size invalid.');
            fseek($stream, max(0, $size - 65557));
            $tail = stream_get_contents($stream);
            $end = strrpos($tail, "PK\x05\x06");
            if ($end === false || strlen($tail) - $end < 22) throw new \RuntimeException('ZIP end missing.');
            $e = unpack('vdisk/vstart/vlocal/vcount/Vlength/Voffset/vcomment', substr($tail, $end + 4, 18));
            $end_at = $size - strlen($tail) + $end;
            if ($e['disk'] || $e['start'] || $e['local'] !== $e['count'] || !$e['count'] || $e['count'] > 20000 || $end + 22 + $e['comment'] !== strlen($tail) || $e['offset'] + $e['length'] !== $end_at) throw new \RuntimeException('ZIP directory invalid.');
            fseek($stream, $e['offset']);
            $entries = []; $seen = []; $total = 0;
            for ($i = 0; $i < $e['count']; $i++) {
                $header = self::read($stream, 46);
                if (substr($header, 0, 4) !== "PK\x01\x02") throw new \RuntimeException('ZIP entry invalid.');
                $r = unpack('vmade/vneeded/vflags/vmethod/vtime/vdate/Vcrc/Vcompressed/Vbytes/vname/vextra/vcomment/vdisk/vinternal/Vexternal/Voffset', substr($header, 4));
                $name = self::read($stream, $r['name']);
                self::read($stream, $r['extra'] + $r['comment']);
                $normal = rtrim($name, '/'); $folder = str_ends_with($name, '/');
                if (!$normal || str_contains($name, '\\') || preg_match('~(^/|(^|/)\.\.?(/|$)|//|[\x00-\x1f:])~', $name) || strlen($name) > 1024 || substr_count($name, '/') > 64 || isset($seen[$normal])) throw new \RuntimeException('ZIP path invalid.');
                $type = ($r['external'] >> 16) & 0170000;
                if ($r['disk'] || $r['needed'] > 20 || ($r['flags'] & ~0x080e) || !in_array($r['method'], [0, 8], true) || ($type && $type !== ($folder ? 0040000 : 0100000))) throw new \RuntimeException('ZIP entry type unsupported.');
                $total += $r['bytes'];
                if ($total > min(1073741824,max(134217728,PathGuard::max_bytes()*8)) || $r['offset'] + 30 + $r['compressed'] > $e['offset'] || ($folder && $r['bytes'])) throw new \RuntimeException('ZIP expansion limit.');
                $seen[$normal] = true;
                $entries[] = $r + ['filename' => $name, 'folder' => $folder, 'size' => $r['bytes']];
            }
            if (ftell($stream) !== $end_at) throw new \RuntimeException('ZIP directory length mismatch.');
            // Validate every entry before creating any extracted object.
            foreach ($entries as $entry) {
                $path = $directory . '/' . $entry['filename'];
                fseek($stream, $entry['offset']); $header = self::read($stream, 30);
                if (substr($header, 0, 4) !== "PK\x03\x04") throw new \RuntimeException('ZIP local header invalid.');
                $local = unpack('vneeded/vflags/vmethod/vtime/vdate/Vcrc/Vcompressed/Vbytes/vname/vextra', substr($header, 4));
                $name = self::read($stream, $local['name']); self::read($stream, $local['extra']);
                if ($name !== $entry['filename'] || $local['method'] !== $entry['method'] || $local['flags'] !== $entry['flags'] || ftell($stream) + $entry['compressed'] > $e['offset']) throw new \RuntimeException('ZIP local entry mismatch.');
                if (!($local['flags'] & 8) && ($local['bytes'] !== $entry['bytes'] || $local['compressed'] !== $entry['compressed'] || $local['crc'] !== $entry['crc'])) throw new \RuntimeException('ZIP local checksum mismatch.');
                if ($entry['folder']) {
                    if (!is_dir($path) && !mkdir($path, 0755, true)) throw new \RuntimeException('ZIP directory failed.');
                    continue;
                }
                if (!is_dir(dirname($path)) && !mkdir(dirname($path), 0755, true)) throw new \RuntimeException('ZIP parent failed.');
                $out = fopen($path, 'xb'); if (!$out) throw new \RuntimeException('ZIP output conflict.');
                try {
                    chmod($path, defined('FS_CHMOD_FILE') ? FS_CHMOD_FILE : 0644);
                    $crc = hash_init('crc32b'); $written = 0; $left = $entry['compressed'];
                    $inflate = $entry['method'] === 8 ? inflate_init(ZLIB_ENCODING_RAW) : null;
                    do {
                        $bytes = self::read($stream, min(4096, $left)); $left -= strlen($bytes);
                        $decoded = $inflate ? inflate_add($inflate, $bytes, $left ? ZLIB_SYNC_FLUSH : ZLIB_FINISH) : $bytes;
                        if ($decoded === false || ($written += strlen($decoded)) > $entry['bytes']) throw new \RuntimeException('ZIP expanded size mismatch.');
                        hash_update($crc, $decoded);
                        for ($offset = 0, $length = strlen($decoded); $offset < $length;) {
                            $n = fwrite($out, substr($decoded, $offset));
                            if (!$n) throw new \RuntimeException('ZIP partial output.');
                            $offset += $n;
                        }
                    } while ($left > 0);
                    if ($written !== $entry['bytes'] || hash_final($crc) !== sprintf('%08x', $entry['crc']) || ($inflate && (inflate_get_status($inflate) !== ZLIB_STREAM_END || inflate_get_read_len($inflate) !== $entry['compressed']))) throw new \RuntimeException('ZIP integrity mismatch.');
                } finally { fclose($out); }
            }
            return $entries;
        } finally { fclose($stream); }
    }
    private static function read($stream, int $length): string {
        if ($length < 0) throw new \RuntimeException('ZIP length invalid.');
        $bytes = $length ? fread($stream, $length) : '';
        if ($bytes === false || strlen($bytes) !== $length) throw new \RuntimeException('ZIP truncated.');
        return $bytes;
    }
}
