<?php
/** Native upgrader lifecycle with a verified same-filesystem package swap. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;

final class AtomicPluginUpgrader extends \Plugin_Upgrader {
    private array $stage;
    private string $journal;

    public function __construct(array $stage,string $journal) {
        parent::__construct(new \Automatic_Upgrader_Skin());
        $this->stage=$stage;$this->journal=$journal;
    }

    public function install_package($args=[]) {
        $source=rtrim((string)($args['source']??''),'/').'/'.$this->stage['root'];
        $destination=WP_PLUGIN_DIR.'/'.$this->stage['root'];$extra=(array)($args['hook_extra']??[]);
        if(wp_normalize_path(rtrim((string)($args['destination']??''),'/'))!==wp_normalize_path(WP_PLUGIN_DIR))return new \WP_Error('package_destination_invalid','Destino fora do diretório de plugins.');
        $selected=apply_filters('upgrader_source_selection',trailingslashit($source),$args['source'],$this,$extra);
        if(is_wp_error($selected))return $selected;
        if(realpath(rtrim($selected,'/'))!==realpath($source))return new \WP_Error('package_source_changed','Um filtro alterou a origem; faça nova avaliação do pacote.');
        try {
            // Copy and validate before the native hook can deactivate the old version.
            Engine::prepare_install($this->journal,$source);
            $res=apply_filters('upgrader_pre_install',true,$extra);if(is_wp_error($res))return $res;
            Engine::commit_install($this->journal);
            $this->result=[
                'source'=>$source,'source_files'=>array_values(array_diff((array)scandir($destination),['.','..'])),
                'destination'=>trailingslashit($destination),'destination_name'=>$this->stage['root'],
                'local_destination'=>WP_PLUGIN_DIR,'remote_destination'=>trailingslashit($destination),
                'clear_destination'=>!empty($args['clear_destination']),
            ];
            $res=apply_filters('upgrader_post_install',true,$extra,$this->result);
            if(is_wp_error($res)){$this->result=$res;return $res;}
            return $this->result;
        } catch(\Throwable $error){return new \WP_Error('package_swap_failed','Troca de pacote não concluída; consulte o diário de recuperação.');}
        finally {
            $working=realpath((string)($args['source']??''));$upgrade=realpath(WP_CONTENT_DIR.'/upgrade');
            if(!empty($args['clear_working'])&&$working&&$upgrade&&str_starts_with($working,$upgrade.'/')) {
                // Cleanup failure is recorded; it cannot erase an already committed outcome.
                try {Engine::remove($working);}catch(\Throwable $ignored){$this->skin->feedback('Staging temporário não removido: consulte o diagnóstico de armazenamento.');}
            }
        }
    }
}
