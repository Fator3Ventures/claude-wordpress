<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class QueryExports {
    public static function init(): void {
        add_action('f3_mcp_query_job',[self::class,'worker'],10,1);
        add_action('rest_api_init',static function(){register_rest_route('wp-mcp-fator3/v1','/query-worker',['methods'=>'POST','permission_callback'=>static function($r){$id=(string)$r->get_param('id');$s=StateStore::get('query-jobs',$id);return $s&&is_string($r->get_param('key'))&&hash_equals($s['worker_key_sha256'],hash('sha256',$r->get_param('key')));},'callback'=>static function($r){self::worker((string)$r->get_param('id'));return new \WP_REST_Response(['accepted'=>true]);}]);});
    }
    public static function register(): void {
        Registry::add('db/query-export','Exporta resultado completo em snapshot de leitura, CSV/JSONL e gzip opcional. Sem teto de linhas; limites físicos/tempo são informados. async:true agenda worker consultável em operations/status.',['sql'=>Registry::string(),'format'=>['type'=>'string','enum'=>['csv','jsonl']],'gzip'=>Registry::boolean(true),'async'=>Registry::boolean(true),'timeout_seconds'=>Registry::integer(1,3600)],['sql'],[self::class,'create'],[ConnectionTools::class,'permission'],false);
        Registry::add('db/export-part','Lê parte de artefato privado com hash do arquivo/parte. Pode conter dados originais em dumps SQL.',['artifact_id'=>Registry::string(),'offset_bytes'=>Registry::integer(),'byte_limit'=>Registry::integer(1,262144)],['artifact_id'],[PrivateArtifact::class,'part'],[ConnectionTools::class,'permission']);
        Registry::add('db/query-page','Pagina snapshot JSONL sem gzip por chave sequencial materializada. Cursor vinculado ao arquivo imutável; não usa OFFSET sobre tabelas mutáveis.',['artifact_id'=>Registry::string(),'cursor'=>Registry::string(),'per_page'=>Registry::integer(1,2000)],['artifact_id'],[self::class,'page'],[ConnectionTools::class,'permission']);
        Registry::add('db/export-cancel','Solicita cancelamento cooperativo de exportação; arquivo incompleto nunca é oferecido como completo.',['operation_id'=>Registry::string()],['operation_id'],static function($i){$s=StateStore::get('query-jobs',$i['operation_id']);if(!$s||$s['connection_id']!==ConnectionContext::key())return Result::fail('operation_not_found','Operação não encontrada.');StateStore::put('query-cancel',$i['operation_id'],['status'=>'requested']);return Result::ok(['cancel_requested'=>true]);},[ConnectionTools::class,'permission'],false);
    }
    public static function create(array $i): array {
        $sql=DatabaseRead::validate($i['sql']);if(is_wp_error($sql))return Result::error($sql);
        if(!in_array(SqlGuard::verb($sql),['select','with'],true))return Result::fail('export_select_required','Exportação requer SELECT ou WITH SELECT.');
        $id=bin2hex(random_bytes(16));$key=bin2hex(random_bytes(32));$state=['id'=>$id,'status'=>'pending','sql'=>$sql,'sql_sha256'=>hash('sha256',$sql),'format'=>$i['format']??'jsonl','gzip'=>$i['gzip']??true,'timeout_seconds'=>DatabaseRead::seconds($i),'connection_id'=>ConnectionContext::key(),'user_id'=>get_current_user_id(),'worker_key_sha256'=>hash('sha256',$key),'time'=>time(),'expires'=>time()+DAY_IN_SECONDS];StateStore::put('query-jobs',$id,$state);
        if($i['async']??true){wp_schedule_single_event(time()+1,'f3_mcp_query_job',[$id]);wp_remote_post(rest_url('wp-mcp-fator3/v1/query-worker'),['timeout'=>0.01,'blocking'=>false,'body'=>['id'=>$id,'key'=>$key],'cookies'=>[]]);}
        else self::worker($id);
        return self::status(['operation_id'=>$id]);
    }
    public static function status(array $i): array {
        $s=StateStore::get('query-jobs',(string)($i['operation_id']??''));if(!$s||$s['connection_id']!==ConnectionContext::key()&&!ConnectionContext::maintenance())return Result::fail('operation_not_found','Operação não encontrada.');
        if($s['status']==='running'&&($s['lease_until']??0)<time())return Result::fail('export_snapshot_lost','Worker não concluiu no prazo. Snapshot perdido; inicie nova exportação, sem reutilizar linhas parciais.',['operation_id'=>$s['id'],'status'=>'interrupted','checkpoint_rows'=>$s['checkpoint_rows']??0,'retry_requires_new_operation'=>true]);
        if($s['status']==='pending'&&$s['expires']<time())return Result::fail('export_expired','Operação expirou antes do disparo.',['operation_id'=>$s['id'],'status'=>'expired']);
        return Result::ok(array_intersect_key($s,array_flip(['status','sql_sha256','format','gzip','time','expires','timeout_seconds','artifact_id','row_count','bytes','sha256','error_code','duration_ms','lease_until','checkpoint_rows','heartbeat_at']))+['operation_id'=>$s['id'],'consistency'=>'materialized_repeatable_read_snapshot']);
    }
    public static function worker(string $id): void {
        if(!preg_match('/^[a-f0-9]{32}$/D',$id))return;
        Locks::run(['query-job:'.$id=>LOCK_EX],static function()use($id){
            $s=StateStore::get('query-jobs',$id);if(!$s||$s['status']!=='pending'||$s['expires']<time())return;
            $old_user=get_current_user_id();$identity=ConnectionContext::resume($s['connection_id'],(int)$s['user_id']);
            if(!ConnectionContext::maintenance()||!current_user_can('manage_options')){$s['status']='failed';$s['error_code']='job_permission_revoked';StateStore::put('query-jobs',$id,$s);ConnectionContext::restore_identity($identity,$old_user);return;}
            $db=null;$w=null;$start=microtime(true);$s['status']='running';$s['lease_until']=time()+$s['timeout_seconds']+10;$s['started_at']=time();StateStore::put('query-jobs',$id,$s);
            try{
                $db=DatabaseRead::connection();DatabaseRead::checked($db,'SET SESSION max_execution_time='.($s['timeout_seconds']*1000));DatabaseRead::checked($db,'SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');DatabaseRead::checked($db,'START TRANSACTION WITH CONSISTENT SNAPSHOT, READ ONLY');
                if(StateStore::get('query-cancel',$id))throw new \RuntimeException('export_cancelled');
                $result=$db->query($s['sql'],MYSQLI_USE_RESULT);if(!$result instanceof \mysqli_result)throw new \RuntimeException('query_failed');$fields=$result->fetch_fields();do_action('f3_mcp_query_snapshot_ready',$id);$w=PrivateArtifact::writer($s['format'],$s['gzip']);$csv=fopen('php://temp','w+b');
                $emit=static function(array $values)use($csv):string{ftruncate($csv,0);rewind($csv);fputcsv($csv,$values,',','"','');rewind($csv);return stream_get_contents($csv);};
                if($s['format']==='csv')PrivateArtifact::append($w,$emit(array_map(static fn($f)=>$f->name,$fields)));
                while($row=$result->fetch_assoc()){
                    $safe=DatabaseRead::redact($row,$fields,$s['sql']);$transport=DatabaseWriter::transport_rows([$safe['row']])[0];
                    $line=$s['format']==='jsonl'?json_encode($transport,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)."\n":$emit(array_map(static fn($v)=>is_array($v)?json_encode($v,JSON_THROW_ON_ERROR):$v,array_values($transport)));
                    PrivateArtifact::append($w,$line);$w['rows']++;
                    if($w['rows']%500===0){if(StateStore::get('query-cancel',$id))throw new \RuntimeException('export_cancelled');if(microtime(true)-$start>$s['timeout_seconds'])throw new \RuntimeException('export_timeout');$s['row_count']=$w['rows'];$s['checkpoint_rows']=$w['rows'];$s['heartbeat_at']=time();StateStore::put('query-jobs',$id,$s);}
                }
                fclose($csv);$result->free();if(StateStore::get('query-cancel',$id))throw new \RuntimeException('export_cancelled');if(microtime(true)-$start>$s['timeout_seconds'])throw new \RuntimeException('export_timeout');$db->commit();$meta=PrivateArtifact::finish($w,['consistency'=>'repeatable_read_snapshot','sql_sha256'=>$s['sql_sha256']]);$s=array_replace($s,['status'=>'complete','artifact_id'=>$meta['id'],'row_count'=>$meta['rows'],'sha256'=>$meta['sha256'],'bytes'=>$meta['bytes']]);
            }catch(\Throwable $error){$s['status']='failed';$s['error_code']=in_array($error->getMessage(),['export_cancelled','export_timeout'],true)?$error->getMessage():'export_failed';if($w){if(is_resource($w['stream']))fclose($w['stream']);@unlink(PrivateArtifact::path($w['id']));}}
            finally{if($db){try{$db->rollback();$db->close();}catch(\Throwable $ignore){}}$s['duration_ms']=(int)((microtime(true)-$start)*1000);StateStore::put('query-jobs',$id,$s);ConnectionContext::restore_identity($identity,$old_user);}
        });
    }
    public static function page(array $i): array {
        try{$m=PrivateArtifact::meta($i['artifact_id']);if($m['format']!=='jsonl'||$m['gzip'])return Result::fail('cursor_requires_jsonl','Crie snapshot format:jsonl, gzip:false para paginação por chave.');
            $offset=0;$key=0;if(!empty($i['cursor'])){$c=Cursor::decode($i['cursor']);if(is_wp_error($c))return Result::error($c);if(($c['kind']??'')!=='query-page'||$c['artifact']!==$m['id']||$c['connection']!==ConnectionContext::key()||$c['sha256']!==$m['sha256'])return Result::fail('cursor_invalid','Cursor não pertence ao snapshot/conexão.');$offset=$c['offset'];$key=$c['key'];}
            $f=fopen(PrivateArtifact::path($m['id']),'rb');fseek($f,strlen(StateStore::HEADER)+$offset);$rows=[];$bytes=0;
            while(count($rows)<($i['per_page']??200)&&($line=fgets($f))!==false){$bytes+=strlen($line);if($bytes>16777216){fclose($f);return Result::fail('query_byte_limit','Reduza per_page.');}$rows[]=['row_key'=>++$key,'values'=>json_decode($line,true,512,JSON_THROW_ON_ERROR)];}
            $next=ftell($f)-strlen(StateStore::HEADER);fclose($f);return Result::ok(['rows'=>$rows,'row_count'=>count($rows),'total_rows'=>$m['rows'],'has_more'=>$next<$m['bytes'],'next_cursor'=>$next<$m['bytes']?Cursor::encode(['kind'=>'query-page','artifact'=>$m['id'],'sha256'=>$m['sha256'],'connection'=>ConnectionContext::key(),'offset'=>$next,'key'=>$key]):null,'consistency'=>'immutable_materialized_snapshot']);
        }catch(\Throwable $e){return Result::fail('query_cursor_failed','Não foi possível ler o snapshot.');}
    }
}
