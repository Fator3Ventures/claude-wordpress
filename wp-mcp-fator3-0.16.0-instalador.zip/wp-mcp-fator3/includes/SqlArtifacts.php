<?php
/** SQL artifact inventory and frozen retention. Lock order: database, inventory, item/phase. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;
final class SqlArtifacts {
    public const BUCKET='sql-artifact-index';
    private static ?array $recovery_refs=null;
    public static function lock(callable $callback,bool $exclusive=false) {
        self::$recovery_refs=null;
        $r=Locks::run(['sql-artifacts:'.get_current_blog_id()=>$exclusive?LOCK_EX:LOCK_SH],$callback);
        if(is_array($r)&&($r['error_code']??'')==='resource_busy')return Result::fail('artifact_in_use','Artefatos em uso por outra operação; nenhuma exclusão aplicada.',['conflict'=>true,'retryable'=>true]);
        return $r;
    }
    public static function policy(): array {
        return array_replace(['older_than_days'=>30,'max_count'=>20,'min_keep'=>3],(array)get_option('f3_mcp_sql_retention',[]));
    }
    public static function valid_policy(array $p): bool {
        return array_keys($p)===['older_than_days','max_count','min_keep'] && is_int($p['older_than_days'])&&$p['older_than_days']>=1&&$p['older_than_days']<=3650
            &&is_int($p['max_count'])&&$p['max_count']>=1&&$p['max_count']<=10000&&is_int($p['min_keep'])&&$p['min_keep']>=0&&$p['min_keep']<=$p['max_count'];
    }
    private static function index(array $m): array {
        $id=$m['id'];$path=PrivateArtifact::path($id);clearstatcache(true,$path);
        $complete=is_file($path)&&!is_link($path)&&filesize($path)===(int)$m['bytes']+strlen(StateStore::HEADER);
        return ['id'=>$id,'artifact_id'=>$id,'metadata_contract'=>1,'kind'=>'sql','format'=>'sql','gzip'=>(bool)($m['gzip']??false),
            'purpose'=>$m['purpose']??'unknown','ability'=>$m['ability']??null,'operation_id'=>$m['operation_id']??null,
            'time'=>gmdate('c',(int)$m['time']),'created_at'=>(int)$m['time'],'bytes'=>(int)$m['bytes'],'logical_bytes'=>$m['logical_bytes']??null,
            'stored_bytes'=>$complete?filesize($path)+(is_file($path.'.meta.php')?filesize($path.'.meta.php'):0):0,
            'sha256'=>$m['sha256'],'scope'=>$m['scope']??'unknown','tables'=>array_keys($m['tables']??[]),
            'status'=>$complete?'complete':'incomplete','references'=>$m['references']??[],
            'connection_id'=>$m['connection_id']??null,'user_id'=>$m['user_id']??null,'backup_contains_sensitive_values'=>true];
    }
    public static function published(array $m): void {
        if(($m['format']??'')!=='sql')return;
        $r=Locks::run(['sql-artifact-item:'.$m['id']=>LOCK_EX],static function()use($m){
            $old=Persistence::get(self::BUCKET,$m['id']);$row=self::index($m);
            if($old && ($old['status']??'')==='removed')throw new \RuntimeException('artifact_tombstone_conflict');
            $row['references']=array_values(array_unique(array_merge($row['references'],$old['references']??[])));
            Persistence::put(self::BUCKET,$m['id'],$row);
        });
        if(is_array($r)&&empty($r['success']))throw new \RuntimeException('artifact_index_unavailable');
    }
    public static function pin(string $id,string $operation): void {
        $r=Locks::run(['sql-artifact-item:'.$id=>LOCK_EX],static function()use($id,$operation){
            $row=Persistence::get(self::BUCKET,$id);
            if(!$row){self::published(PrivateArtifact::meta($id,false));$row=Persistence::get(self::BUCKET,$id);}
            if(($row['status']??'')!=='complete')throw new \RuntimeException('artifact_unavailable');
            $row['references']=array_values(array_unique(array_merge($row['references']??[],[$operation])));
            Persistence::put(self::BUCKET,$id,$row);
        });
        if(is_array($r)&&empty($r['success']))throw new \RuntimeException('artifact_reference_unavailable');
    }
    private static function phase(string $operation): ?array {
        if(!preg_match('/^phase:([a-f0-9]{32})$/D',$operation,$m))return null;
        $idx=StateStore::get('phase014-index',$m[1]);return $idx?StateStore::get('phase014',$idx['token']):null;
    }
    /** References are rechecked against durable receipts; uncertainty never expires by age. */
    private static function reason(array $row): ?string {
        if(($row['status']??'')!=='complete')return 'artifact_not_complete';
        foreach($row['references']??[] as $ref){
            $p=self::phase($ref);
            if(!$p)return 'artifact_reference_unknown';
            if(($p['status']??'')==='complete')continue;
            if(($p['status']??'')==='pending'&&($p['expires']??PHP_INT_MAX)<time())continue;
            return 'artifact_referenced';
        }
        $refs=self::recovery_refs();
        if($refs['error'])return $refs['error'];
        if(isset($refs['ids'][$row['id']]))return 'artifact_referenced';
        return null;
    }
    private static function recovery_refs(): array {
        if(self::$recovery_refs!==null)return self::$recovery_refs;
        $out=['ids'=>[],'error'=>null];$checked=0;
        foreach(new \FilesystemIterator(StateStore::directory('database-recovery'),\FilesystemIterator::SKIP_DOTS) as $file){
            $path=$file->getPathname();if($file->getFilename()==='index.php'||!str_ends_with($path,'.php'))continue;
            if(++$checked>1000){$out['error']='artifact_recovery_inventory_partial';break;}
            $j=is_link($path)?null:Engine::read($path);
            if(!$j){$out['error']='artifact_recovery_unknown';break;}
            if(in_array($j['status']??'',['complete','rolled_back'],true))continue;
            foreach(['artifact_id','rollback_artifact_id'] as $key)if(!empty($j[$key]))$out['ids'][$j[$key]]=true;
        }
        return self::$recovery_refs=$out;
    }
    /** At most 200 payloads are inspected per request; newly created artifacts are indexed at publication. */
    public static function inventory(): array {
        $state=StateStore::get('migration','sql-artifacts-1')??['after'=>'','complete'=>false,'processed'=>0];
        if(!empty($state['complete']))return $state;
        $window=[];$more=false;
        foreach(new \FilesystemIterator(StateStore::directory('artifacts'),\FilesystemIterator::SKIP_DOTS) as $file){
            $name=$file->getFilename();if(!preg_match('/^([a-f0-9]{32})\.php(?:\.meta\.php)?$/D',$name,$hit)||$hit[1]<=$state['after'])continue;
            $window[$hit[1]]=true;
            if(count($window)>201){ksort($window,SORT_STRING);array_pop($window);$more=true;}
        }
        ksort($window,SORT_STRING);if(count($window)>200){array_pop($window);$more=true;}
        foreach(array_keys($window) as $id){
            $old=Persistence::get(self::BUCKET,$id);
            if(!$old){
                $path=PrivateArtifact::path($id);
                try{
                    if(is_link($path)||is_link($path.'.meta.php'))throw new \RuntimeException('linked_artifact');
                    $m=PrivateArtifact::meta($id,false);
                    if($m['format']==='sql'){
                        if(!in_array($m['purpose']??'',['sql_mutation','manual_export','restore_preimage'],true)){
                            global $wpdb;$table=Persistence::table('phase014');
                            $like='%'.$wpdb->esc_like($id).'%';
                            $candidates=$wpdb->get_col($wpdb->prepare("SELECT payload FROM `$table` WHERE bucket='phase014' AND payload LIKE %s",$like));
                            if($wpdb->last_error)throw new \RuntimeException('receipts_unavailable');
                            $m['purpose']='unknown';$m['references']=[];
                            foreach($candidates as $raw){$p=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
                                if(($p['backup_id']??$p['result']['backup_id']??'')!==$id)continue;
                                if(!empty($p['operation_id']))$m['references'][]=$p['operation_id'];
                                if(in_array($p['name']??'',['db/execute','db/batch','db/search-replace'],true)){$m['purpose']='sql_mutation';$m['ability']=$p['name'];$m['operation_id']=$p['operation_id']??null;}
                                elseif(($p['name']??'')==='db/restore')$m['purpose']='restore_preimage';
                            }
                        }
                        self::published($m);
                    }
                }catch(\Throwable $error){
                    // Missing or corrupt metadata cannot prove format or references. Preserve it.
                    Persistence::put(self::BUCKET,$id,['id'=>$id,'artifact_id'=>$id,'kind'=>'unknown','purpose'=>'unknown','status'=>'incomplete','stored_bytes'=>is_file($path)&&!is_link($path)?filesize($path):0,'time'=>gmdate('c'),'created_at'=>time(),'references'=>[],'reason'=>'artifact_unverifiable']);
                }
            }
            $state['after']=$id;$state['processed']++;
        }
        $state['complete']=!$more;$state['observed_at']=time();StateStore::put('migration','sql-artifacts-1',$state);return $state;
    }
    public static function availability(string $id): array {
        $row=Persistence::get(self::BUCKET,$id);
        if($row && ($row['status']??'')==='removed')return ['artifact_id'=>$id,'available'=>false,'status'=>'removed','removed_at'=>$row['removed_at']??null];
        try{$m=PrivateArtifact::meta($id,false);return ['artifact_id'=>$id,'available'=>is_file(PrivateArtifact::path($id)),'status'=>$m['status']];}
        catch(\Throwable $e){return ['artifact_id'=>$id,'available'=>false,'status'=>'unavailable_or_uncertain'];}
    }
    public static function health(): array {
        self::$recovery_refs=null;
        global $wpdb;$table=Persistence::table(self::BUCKET);
        $rows=$wpdb->get_results($wpdb->prepare("SELECT status,COUNT(*) n,COALESCE(SUM(stored_bytes),0) bytes FROM `$table` WHERE bucket=%s GROUP BY status",self::BUCKET),ARRAY_A);
        if($wpdb->last_error)return ['inventory_complete'=>false,'error'=>'artifact_inventory_unavailable'];
        $totals=['count'=>0,'stored_bytes'=>0,'complete'=>0,'incomplete'=>0,'removed'=>0];
        foreach($rows as $r){$status=$r['status'];$totals[$status]=(int)$r['n'];if($status!=='removed'){$totals['count']+=(int)$r['n'];$totals['stored_bytes']+=(int)$r['bytes'];}}
        $state=StateStore::get('migration','sql-artifacts-1');
        // Bounded metadata-only observation. Never scan payloads or advance migration on health.
        $page=self::rows('sql_artifacts',[],1001);$policy=self::policy();$rank=0;
        $metrics=['eligible'=>0,'eligible_bytes'=>0,'protected'=>0,'protected_bytes'=>0,'unknown'=>0,'examined'=>0];
        foreach(array_slice($page,0,1000) as $row){
            ++$metrics['examined'];if(($row['purpose']??'unknown')==='unknown')++$metrics['unknown'];
            $reason=self::reason($row);$candidate=false;
            if(($row['purpose']??'')==='sql_mutation'&&($row['status']??'')==='complete'){
                ++$rank;$candidate=$rank>$policy['min_keep']&&($rank>$policy['max_count']||$row['created_at']<time()-$policy['older_than_days']*DAY_IN_SECONDS);
            }
            if($reason!==null){++$metrics['protected'];$metrics['protected_bytes']+=(int)$row['stored_bytes'];}
            elseif($candidate){++$metrics['eligible'];$metrics['eligible_bytes']+=(int)$row['stored_bytes'];}
        }
        $last=StateStore::get('diagnostics','sql-artifact-retention');if(is_array($last))unset($last['_storage'],$last['_row_id']);
        $metrics['complete']=count($page)<=1000&&!empty($state['complete']);$metrics['observed_at']=time();
        return $totals+['inventory_complete'=>!empty($state['complete']),'inventory_observed_at'=>$state['observed_at']??null,'policy'=>self::policy(),
            'eligibility'=>$metrics,'metrics_scope'=>'indexed_artifacts','last_selection'=>$last,
            'maintenance'=>'backups/list category:sql_artifacts advances inventory; backups/prune creates an exact, reference-checked selection. No automatic deletion.'];
    }
    public static function listing(array $i): array {
        if(!ConnectionTools::permission())return Result::fail('permission_denied','Dumps SQL exigem manage_options e perfil Manutenção.');
        return self::lock(static function()use($i){
            $inventory=self::inventory();$filters=[];
            foreach(['since','until'] as $key)if(isset($i[$key])){$v=strtotime($i[$key]);if($v===false)return Result::fail('invalid_date','Use data ISO 8601.');$filters[$key]=$v;}
            $limit=max(1,min(200,(int)($i['per_page']??30)));$offset=max(0,(int)($i['offset']??0));
            // SQL category has no file path/label contract; explicit refusal prevents misleading filters.
            if(isset($i['path'])||isset($i['label']))return Result::fail('artifact_filter_unsupported','Artefatos SQL aceitam categoria e datas; não path/label.');
            $all=self::rows($i['category']??'sql_artifacts',$filters,$limit+1,$offset);$rows=array_slice($all,0,$limit);$more=count($all)>$limit;
            foreach($rows as &$row){$reason=self::reason($row);$row['protected']=$reason!==null;$row['protection_reason']=$reason;unset($row['references'],$row['_storage'],$row['_row_id']);}unset($row);
            return Result::ok(['backups'=>$rows,'has_more'=>$more,'next_offset'=>$more?$offset+count($rows):null,'inventory_complete'=>$inventory['complete'],'storage'=>self::health()]);
        },true);
    }
    private static function rows(string $category,array $filters=[],?int $limit=null,int $offset=0): array {
        global $wpdb;$table=Persistence::table(self::BUCKET);$where="bucket=%s AND status<>'removed'";$params=[self::BUCKET];
        if($category==='sql_mutation'){$where.=" AND JSON_UNQUOTE(JSON_EXTRACT(payload,'$.purpose'))='sql_mutation'";}
        foreach(['since'=>'>=','until'=>'<'] as $k=>$op)if(isset($filters[$k])){$where.=" AND created_at$op%d";$params[]=$filters[$k];}
        $limit_sql=$limit===null?'':' LIMIT '.max(1,$limit).' OFFSET '.max(0,$offset);
        $rows=$wpdb->get_col($wpdb->prepare("SELECT payload FROM `$table` WHERE $where ORDER BY created_at DESC,id DESC$limit_sql",...$params));
        if($wpdb->last_error)throw new \RuntimeException('artifact_inventory_unavailable');
        return array_map(static fn($raw)=>json_decode($raw,true,512,JSON_THROW_ON_ERROR),$rows);
    }
    private static function public_plan(array $state,bool $dry): array {
        $items=[];$bytes=0;$removed=0;$removed_bytes=0;
        foreach($state['items'] as $item){$items[]=array_intersect_key($item,array_flip(['id','bytes','status','purpose','time']));$bytes+=$item['bytes'];if($item['status']==='complete')$removed++;foreach($item['parts'] as $part)if($part['phase']==='removed')$removed_bytes+=$part['bytes'];}
        return ['category'=>$state['category'],'dry_run'=>$dry,'expected_selection_sha256'=>$state['selection_sha256'],'selection'=>$items,'selected'=>count($items),'selected_bytes'=>$bytes,
            'blocked'=>$state['blocked'],'removed_count'=>$removed,'removed_bytes'=>$removed_bytes,'remaining_count'=>count($items)-$removed,
            'has_more'=>$state['has_more'],'metrics_before'=>$state['metrics_before'],'metrics_after'=>self::health()];
    }
    private static function components(array $row): array {
        $path=PrivateArtifact::path($row['id']);$out=[];
        foreach([$path,$path.'.meta.php'] as $p){if(is_link($p)||!is_file($p))throw new \RuntimeException('artifact_unverifiable');$out[]=['path'=>$p,'sha256'=>hash_file('sha256',$p),'bytes'=>filesize($p),'phase'=>'pending'];}
        return $out;
    }
    private static function plan(array $i): array {
        $inventory=self::inventory();
        if(empty($inventory['complete']))return Result::fail('artifact_inventory_incomplete','Inventário parcial; repita a listagem antes de excluir.',['inventory'=>$inventory]);
        $ids=$i['artifact_ids']??null;$category=$i['category']??'sql_mutation';
        if($ids!==null && array_intersect(array_keys($i),['older_than_days','max_count','min_keep','max_total_bytes','offset','include_legacy']))return Result::fail('artifact_selection_ambiguous','Selecione IDs ou política, em chamadas separadas.');
        if(isset($i['max_total_bytes'])||isset($i['include_legacy'])||isset($i['offset']))return Result::fail('artifact_filter_unsupported','Retenção SQL usa idade/quantidade/mínimo ou IDs completos.');
        $policy=array_replace(self::policy(),array_intersect_key($i,self::policy()));
        if(!self::valid_policy($policy))return Result::fail('artifact_policy_invalid','Política de retenção inválida.');
        $rows=self::rows($category);$items=[];$blocked=[];$more=false;$found=[];$rank=0;
        foreach($rows as $row){
            $eligible=false;
            if($ids!==null){$eligible=in_array($row['id'],$ids,true);if($eligible)$found[]=$row['id'];}
            elseif(($row['purpose']??'')==='sql_mutation' && ($row['status']??'')==='complete'){$rank++;$eligible=$rank>$policy['min_keep']&&($rank>$policy['max_count']||$row['created_at']<time()-$policy['older_than_days']*DAY_IN_SECONDS);}
            if(!$eligible)continue;
            if($reason=self::reason($row)){$blocked[]=['id'=>$row['id'],'reason'=>$reason];continue;}
            if(count($items)>=200){$more=true;continue;}
            try{$parts=self::components($row);$items[]=['id'=>$row['id'],'purpose'=>$row['purpose'],'time'=>$row['time'],'bytes'=>array_sum(array_column($parts,'bytes')),'parts'=>$parts,'status'=>'pending'];}
            catch(\Throwable $e){$blocked[]=['id'=>$row['id'],'reason'=>'artifact_unverifiable'];}
        }
        foreach(array_diff($ids??[],$found) as $id)$blocked[]=['id'=>$id,'reason'=>'artifact_not_found_in_category'];
        $state=['contract'=>1,'category'=>$category,'connection_id'=>ConnectionContext::key(),'user_id'=>get_current_user_id(),'site_id'=>get_current_blog_id(),'time'=>time(),'expires'=>time()+600,'status'=>'pending','items'=>$items,'blocked'=>$blocked,'has_more'=>$more,'metrics_before'=>self::health(),'intent'=>self::intent($i)];
        $hash=hash_hmac('sha256',serialize($state),wp_salt('auth'));$state['selection_sha256']=$hash;
        StateStore::put('sql-retention-plans',ConnectionContext::key().'|'.$hash,$state);
        StateStore::put('diagnostics','sql-artifact-retention',['observed_at'=>time(),'selected'=>count($items),'selected_bytes'=>array_sum(array_column($items,'bytes')),'blocked'=>count($blocked),'has_more'=>$more,'scope'=>$ids!==null?'explicit_ids':'policy']);
        return Result::ok(self::public_plan($state,true));
    }
    private static function intent(array $i): string {unset($i['dry_run'],$i['expected_selection_sha256'],$i['idempotency_key']);ksort($i);return hash('sha256',serialize($i));}
    public static function prune(array $i): array {
        if(!ConnectionTools::permission())return Result::fail('permission_denied','Dumps SQL exigem manage_options e perfil Manutenção.');
        return self::lock(static function()use($i){
            if($i['dry_run']??true)return self::plan($i);
            $hash=$i['expected_selection_sha256']??'';
            if(!preg_match('/^[a-f0-9]{64}$/D',$hash))return Result::fail('backup_selection_required','Use o hash da simulação SQL.');
            $key=ConnectionContext::key().'|'.$hash;$s=StateStore::get('sql-retention-plans',$key);
            if(!$s || $s['site_id']!==get_current_blog_id()||$s['user_id']!==get_current_user_id()||$s['category']!==($i['category']??''))return Result::fail('backup_selection_invalid','Seleção de outra identidade/categoria.');
            // Confirmation may send only category/hash, or repeat exactly the original selectors.
            $selectors=array_diff(array_keys($i),['category','dry_run','expected_selection_sha256','idempotency_key']);
            if($selectors&&self::intent($i)!==$s['intent'])return Result::fail('backup_selection_conflict','Seletores divergentes da prévia.',['conflict'=>true]);
            if($s['status']==='complete')return Result::ok(self::public_plan($s,false)+['replayed'=>true]);
            if($s['status']==='pending'&&$s['expires']<time())return Result::fail('backup_selection_expired','Seleção expirada.');
            foreach($s['items'] as $item){
                if($item['status']==='complete')continue;
                $row=Persistence::get(self::BUCKET,$item['id']);
                if(($row['status']??'')==='removed' && !array_filter($item['parts'],static fn($p)=>$p['phase']!=='removed'))continue;
                if(($row['status']??'')==='pruning'&&($row['prune_selection']??'')===$hash)$row['status']='complete';
                if(!$row || self::reason($row)!==null)return Result::fail('backup_selection_conflict','Artefato ganhou referência ou ficou indisponível.',['conflict'=>true,'artifact_id'=>$item['id']]);
                foreach($item['parts'] as $part){
                    if($part['phase']==='removed')continue;
                    if($part['phase']==='removing'&&!file_exists($part['quarantine']))continue;
                    $p=isset($part['quarantine'])&&is_file($part['quarantine'])?$part['quarantine']:$part['path'];
                    if(is_link($p)||!is_file($p)||!hash_equals($part['sha256'],hash_file('sha256',$p)))return Result::fail('backup_selection_conflict','Componente mudou; seleção preservada.',['conflict'=>true,'artifact_id'=>$item['id']]);
                }
            }
            $s['status']='running';StateStore::put('sql-retention-plans',$key,$s);$failed=[];
            foreach($s['items'] as &$item){
                if($item['status']==='complete')continue;
                try{
                    $row=Persistence::get(self::BUCKET,$item['id']);$row['status']='pruning';$row['prune_selection']=$hash;Persistence::put(self::BUCKET,$item['id'],$row);
                    foreach($item['parts'] as &$part){
                        if($part['phase']==='removed')continue;
                        if(!isset($part['quarantine'])){$part['quarantine']=dirname($part['path']).'/.sql-prune-'.bin2hex(random_bytes(16)).'.php';$part['phase']='quarantining';StateStore::put('sql-retention-plans',$key,$s);}
                        if(is_file($part['path'])&&!rename($part['path'],$part['quarantine']))throw new \RuntimeException('artifact_quarantine_failed');
                        $part['phase']='removing';StateStore::put('sql-retention-plans',$key,$s);
                        do_action('f3_mcp_sql_prune_checkpoint','before_remove',$item['id']);
                        if(file_exists($part['quarantine'])&&!unlink($part['quarantine']))throw new \RuntimeException('artifact_remove_failed');
                        $part['phase']='removed';StateStore::put('sql-retention-plans',$key,$s);
                        $row['stored_bytes']=array_sum(array_map(static fn($p)=>$p['phase']==='removed'?0:$p['bytes'],$item['parts']));Persistence::put(self::BUCKET,$item['id'],$row);
                    }unset($part);
                    $row=Persistence::get(self::BUCKET,$item['id']);$row['status']='removed';$row['stored_bytes']=0;$row['removed_at']=time();$row['references']=[];Persistence::put(self::BUCKET,$item['id'],$row);
                    $item['status']='complete';StateStore::put('sql-retention-plans',$key,$s);
                }catch(\Throwable $e){unset($part);$failed[]=$item['id'];}
            }unset($item);
            if(!$failed)$s['status']='complete';StateStore::put('sql-retention-plans',$key,$s);
            return $failed?Result::fail('backup_prune_partial','Repita a mesma seleção para concluir os componentes restantes.',self::public_plan($s,false)+['failed'=>$failed,'pending'=>true]):Result::ok(self::public_plan($s,false));
        },true);
    }
}
