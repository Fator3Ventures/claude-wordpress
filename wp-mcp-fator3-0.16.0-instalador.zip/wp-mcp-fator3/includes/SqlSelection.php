<?php
/** AST for one-table literal DML selected by one equality INNER JOIN or one IN subquery. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SqlSelection {
    private array $tokens; private int $i=0; private array $tables=[]; private array $columns=[];
    private function __construct(array $tokens){$this->tokens=$tokens;}
    private function peek(): string {return strtoupper($this->tokens[$this->i]['value']??'');}
    private function take(string $value): bool {if($this->peek()===$value){$this->i++;return true;}return false;}
    private function expect(string $value): void {if(!$this->take($value))throw new \DomainException('Expected '.$value);}
    private function identifier(): string {$t=$this->tokens[$this->i++]??[];if(!in_array($t['kind']??'',['word','identifier'],true))throw new \DomainException('Identifier required');return trim($t['value'],'`');}
    private function table(): string {
        global $wpdb;$table=$this->identifier();$valid=SqlReadPolicy::source($table,true);if(is_wp_error($valid))throw new \DomainException($valid->get_error_code());
        $alias=$table;if($this->take('AS'))$alias=$this->identifier();elseif(in_array($this->tokens[$this->i]['kind']??'',['word','identifier'],true)&&!in_array($this->peek(),['INNER','JOIN','ON','SET','WHERE'],true))$alias=$this->identifier();
        if(isset($this->tables[$alias]))throw new \DomainException('Duplicate alias');$this->tables[$alias]=$table;
        $cols=$wpdb->get_col('DESCRIBE `'.$table.'`',0);if($wpdb->last_error||!$cols)throw new \DomainException('Unverified columns');
        foreach($cols as $column)if(str_starts_with($column,'__f3_source_'))throw new \DomainException('Reserved projection column');
        $this->columns[$alias]=array_values(array_filter($cols,static fn($c)=>!DataSafety::secret_key($c)));return $alias;
    }
    private function column(?string $scope=null): array {
        $first=$this->identifier();$alias=null;$column=$first;
        if($this->take('.')){$alias=$first;$column=$this->identifier();}
        if($alias===null){$found=[];foreach($this->columns as $a=>$cols)if(($scope===null||$a===$scope)&&in_array($column,$cols,true))$found[]=$a;if(count($found)!==1)throw new \DomainException('Ambiguous or protected column');$alias=$found[0];}
        if(!isset($this->columns[$alias])||($scope!==null&&$alias!==$scope)||!in_array($column,$this->columns[$alias],true))throw new \DomainException('Protected or unknown column');
        return ['type'=>'column','alias'=>$alias,'column'=>$column,'sql'=>'`'.$alias.'`.`'.$column.'`'];
    }
    private function literal(): array {
        $sign='';if($this->take('-'))$sign='-';elseif($this->take('+'))$sign='+';$t=$this->tokens[$this->i++]??[];
        if(($t['kind']??'')==='number')return ['type'=>'literal','sql'=>$sign.$t['value']];
        if($sign!=='')throw new \DomainException('Signed non-number');
        if(($t['kind']??'')==='string'||in_array(strtoupper($t['value']??''),['NULL','TRUE','FALSE'],true))return ['type'=>'literal','sql'=>$t['value']];throw new \DomainException('Literal required');
    }
    private function operand(?string $scope=null): array {
        $kind=$this->tokens[$this->i]['kind']??'';
        return in_array($kind,['string','number'],true)||in_array($this->peek(),['NULL','TRUE','FALSE','-','+'],true)?$this->literal():$this->column($scope);
    }
    private function predicate(?string $scope=null,int $depth=0): array {
        if($depth>16)throw new \DomainException('Predicate depth');$left=$this->and($scope,$depth+1);
        while($this->take('OR')){$right=$this->and($scope,$depth+1);$left=['type'=>'or','left'=>$left,'right'=>$right,'sql'=>'('.$left['sql'].' OR '.$right['sql'].')'];}return $left;
    }
    private function and(?string $scope,int $depth): array {
        $left=$this->factor($scope,$depth);
        while($this->take('AND')){$right=$this->factor($scope,$depth);$left=['type'=>'and','left'=>$left,'right'=>$right,'sql'=>'('.$left['sql'].' AND '.$right['sql'].')'];}return $left;
    }
    private function factor(?string $scope,int $depth): array {
        if($this->take('(')){$p=$this->predicate($scope,$depth+1);$this->expect(')');return $p;}
        $left=$this->operand($scope);$operator=$this->peek();
        if($this->take('IS')){$not=$this->take('NOT');$this->expect('NULL');return ['type'=>'null','left'=>$left,'sql'=>$left['sql'].' IS '.($not?'NOT ':'').'NULL'];}
        if(!in_array($operator,['=','!=','<>','<','>','<=','>=','LIKE'],true))throw new \DomainException('Unsupported predicate');$this->i++;$right=$this->operand($scope);
        return ['type'=>'compare','operator'=>$operator,'left'=>$left,'right'=>$right,'sql'=>$left['sql'].' '.$operator.' '.$right['sql']];
    }
    public static function parse(string $sql) {
        $tokens=SqlReadPolicy::tokens($sql);if(is_wp_error($tokens))return $tokens;$p=new self($tokens);
        try{
            $verb=strtolower($p->peek());$p->i++;$delete_alias=null;
            if($verb==='delete'){if(!$p->take('FROM')){$delete_alias=$p->identifier();$p->expect('FROM');}}
            elseif($verb!=='update')throw new \DomainException('Unsupported DML');
            $target=$p->table();if($delete_alias!==null&&$delete_alias!==$target)throw new \DomainException('Only one target is allowed');
            $source=null;$join=null;
            if($p->take('INNER')){$p->expect('JOIN');$source=$p->table();$p->expect('ON');$left=$p->column();$p->expect('=');$right=$p->column();if($left['alias']===$right['alias']||!in_array($target,[$left['alias'],$right['alias']],true))throw new \DomainException('Join must connect both sources');$join=['type'=>'equality_join','left'=>$left,'right'=>$right,'sql'=>$left['sql'].' = '.$right['sql']];}
            $assign=[];
            if($verb==='update'){$p->expect('SET');do{$col=$p->column($target);$p->expect('=');$literal=$p->literal();if(isset($assign[$col['column']]))throw new \DomainException('Duplicate assignment');$assign[$col['column']]=$literal;}while($p->take(','));}
            $p->expect('WHERE');$subquery=null;
            if($source===null){
                $left=$p->column($target);$p->expect('IN');$p->expect('(');$p->expect('SELECT');
                // Projection precedes its source; retain tokens, then resolve against the registered source.
                $projection=$p->i;$p->identifier();if($p->take('.'))$p->identifier();$p->expect('FROM');$source=$p->table();$after_source=$p->i;
                $p->i=$projection;$right=$p->column($source);$p->i=$after_source;$p->expect('WHERE');$predicate=$p->predicate($source);$p->expect(')');
                $subquery=['type'=>'in_subquery','left'=>$left,'right'=>$right,'predicate'=>$predicate];
            }else $predicate=$p->predicate();
            if($p->i!==count($tokens))throw new \DomainException('Trailing or unsupported syntax');
            global $wpdb;$table=$p->tables[$target];$keys=$wpdb->get_results('SHOW INDEX FROM `'.$table.'` WHERE Key_name=\'PRIMARY\'',ARRAY_A);if($wpdb->last_error||!$keys)throw new \DomainException('Deterministic primary key required');
            usort($keys,static fn($a,$b)=>(int)$a['Seq_in_index']<=>(int)$b['Seq_in_index']);$pk=[];foreach($keys as $key){if(empty($key['Column_name'])||!empty($key['Sub_part'])||!in_array($key['Column_name'],$p->columns[$target],true))throw new \DomainException('Unsupported primary key');$pk[]=$key['Column_name'];}
            foreach($pk as $col)if(isset($assign[$col]))throw new \DomainException('Primary key updates are not supported by this extension');
            $ast=['verb'=>$verb,'target'=>$target,'source'=>$source,'tables'=>$p->tables,'columns'=>$p->columns,'assignments'=>$assign,'join'=>$join,'subquery'=>$subquery,'predicate'=>$predicate,'primary_key'=>$pk];
            return ['table'=>$table,'verb'=>$verb,'select'=>'','selection_ast'=>$ast,'sources'=>array_values($p->tables)];
        }catch(\DomainException $e){return new \WP_Error('sql_selection_unsupported','Seleção fora do subconjunto JOIN/IN autorizado: '.$e->getMessage().'.');}
    }
    private static function from(array $ast,string $alias): string {return '`'.$ast['tables'][$alias].'` AS `'.$alias.'`';}
    /** Called twice: preview, then serializable confirmation with locks on source and targets. */
    public static function rows(array &$pre,bool $lock) {
        global $wpdb;$ast=$pre['selection_ast'];$target=$ast['target'];$source=$ast['source'];$suffix=' LIMIT '.(SqlGuard::MAX_ROWS+1).($lock?' FOR UPDATE':'');$source_rows=[];
        if($ast['subquery']){
            $sub=$ast['subquery'];$src='SELECT '.implode(',',array_map(static fn($c)=>'`'.$source.'`.`'.$c.'`',$ast['columns'][$source])).' FROM '.self::from($ast,$source).' WHERE '.$sub['predicate']['sql'];
            $source_rows=$wpdb->get_results($src.$suffix,ARRAY_A);if($wpdb->last_error||!is_array($source_rows)||count($source_rows)>SqlGuard::MAX_ROWS)return new \WP_Error('sql_selection_limit','Fonte excede orçamento ou falhou.');
            $sql='SELECT `'.$target.'`.* FROM '.self::from($ast,$target).' WHERE '.$sub['left']['sql'].' IN (SELECT '.$sub['right']['sql'].' FROM '.self::from($ast,$source).' WHERE '.$sub['predicate']['sql'].')';
            $rows=$wpdb->get_results($sql.$suffix,ARRAY_A);
        }else{
            $fields=['`'.$target.'`.*'];foreach($ast['columns'][$source] as $i=>$column)$fields[]='`'.$source.'`.`'.$column.'` AS `__f3_source_'.$i.'`';
            $sql='SELECT '.implode(',',$fields).' FROM '.self::from($ast,$target).' INNER JOIN '.self::from($ast,$source).' ON '.$ast['join']['sql'].' WHERE '.$ast['predicate']['sql'];
            $raw=$wpdb->get_results($sql.$suffix,ARRAY_A);$rows=[];
            foreach($raw?:[] as $row){$src=[];foreach($ast['columns'][$source] as $i=>$column){$src[$column]=$row['__f3_source_'.$i];unset($row['__f3_source_'.$i]);}$source_rows[]=$src;$key=[];foreach($ast['primary_key'] as $pk)$key[]=$row[$pk];$rows[serialize($key)]=$row;}$rows=array_values($rows);
            if(count($raw?:[])>SqlGuard::MAX_ROWS)return new \WP_Error('sql_selection_limit','JOIN excede orçamento de linhas intermediárias.');
        }
        if($wpdb->last_error||!is_array($rows)||count($rows)>SqlGuard::MAX_ROWS||strlen(serialize([$rows,$source_rows]))>16777216)return new \WP_Error('sql_selection_limit','Seleção excede orçamento ou falhou.');
        $serialized=array_map('serialize',$source_rows);sort($serialized,SORT_STRING);$pre['selection_fingerprint']=hash_hmac('sha256',serialize($serialized),wp_salt('auth'));return $rows;
    }
    public static function frozen(array $pre,array $rows): string {
        global $wpdb;$ast=$pre['selection_ast'];$ors=[];
        foreach($rows as $row){$and=[];foreach($ast['primary_key'] as $key)$and[]=$wpdb->prepare('`'.$key.'`=%s',$row[$key]);$ors[]='('.implode(' AND ',$and).')';}
        $where=$ors?implode(' OR ',$ors):'1=0';$table='`'.$pre['table'].'`';
        if($pre['verb']==='delete')return 'DELETE FROM '.$table.' WHERE '.$where;
        $set=[];foreach($ast['assignments'] as $col=>$literal)$set[]='`'.$col.'`='.$literal['sql'];return 'UPDATE '.$table.' SET '.implode(',',$set).' WHERE '.$where;
    }
}
