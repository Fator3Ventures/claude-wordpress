<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class CronTools {
    public static function register(): void {
        $event=['hook'=>Registry::string(),'timestamp'=>Registry::integer(1),'args'=>['type'=>'array','items'=>Result::any_schema()],'expected_revision'=>Registry::string()];
        Registry::add('cron/list','Lista eventos WordPress com identidade/revisão, agenda e argumentos redigidos.',['hook'=>Registry::string(),'offset'=>Registry::integer(),'per_page'=>Registry::integer(1,200)],[],[self::class,'listing']);
        Registry::add('cron/run','Executa evento existente no contexto cron. Ações WordPress não têm valor de retorno; resposta informa execução, reagendamento e exceção. Não aceita código PHP.',$event,['hook','timestamp','expected_revision'],[self::class,'run'],[ConnectionTools::class,'permission'],false);
        Registry::add('cron/schedule','Agenda evento por hook registrado, argumentos e recorrência nativa.',['hook'=>Registry::string(),'timestamp'=>Registry::integer(1),'args'=>['type'=>'array','items'=>Result::any_schema()],'recurrence'=>Registry::string()],['hook','timestamp'],[self::class,'schedule'],[ConnectionTools::class,'permission'],false);
        Registry::add('cron/unschedule','Remove somente o evento identificado e revisado.',$event,['hook','timestamp','expected_revision'],[self::class,'unschedule'],[ConnectionTools::class,'permission'],false);
        Registry::add('system/delete-transient','Remove transient exato pelas APIs WordPress; estado interno MCP exige suas rotas.',['name'=>Registry::string()],['name'],static function($i){if(str_contains($i['name'],'f3_mcp_'))return Result::fail('transient_protected','Estado interno do canal.');$changed=delete_transient($i['name']);return Result::ok(['changed'=>$changed,'persisted'=>get_transient($i['name'])===false,'storage'=>wp_using_ext_object_cache()?'external_object_cache':'wordpress_options']);},[ConnectionTools::class,'permission'],false);
        Registry::add('system/cache-flush','Executa wp_cache_flush; não equivale à limpeza do cache de página.',[],[],static function(){return wp_cache_flush()?Result::ok(['changed'=>true,'object_cache_flushed'=>true]):Result::fail('cache_flush_failed','Backend recusou a limpeza.');},[ConnectionTools::class,'permission'],false);
    }
    private static function revision($event): string {return hash_hmac('sha256',serialize($event),wp_salt('auth'));}
    public static function listing(array $i): array {
        $rows=[];foreach(_get_cron_array()?:[] as $at=>$hooks)foreach($hooks as $hook=>$events){if(isset($i['hook'])&&$i['hook']!==$hook)continue;foreach($events as $e){$raw=['hook'=>$hook,'timestamp'=>(int)$at,'args'=>$e['args'],'schedule'=>$e['schedule']];$rows[]=$raw+['revision'=>self::revision($raw),'next_run'=>gmdate('c',(int)$at),'overdue'=>(int)$at<time()];}}
        foreach($rows as &$row)$row['args']=SafeOutput::error($row['args']);unset($row);$offset=$i['offset']??0;$n=$i['per_page']??100;return Result::ok(['events'=>array_slice($rows,$offset,$n),'total'=>count($rows),'has_more'=>$offset+$n<count($rows)]);
    }
    private static function event(array $i){$e=wp_get_scheduled_event($i['hook'],$i['args']??[],(int)$i['timestamp']);if(!$e)return new \WP_Error('cron_event_not_found','Evento não encontrado.');$raw=['hook'=>$e->hook,'timestamp'=>(int)$e->timestamp,'args'=>$e->args,'schedule'=>$e->schedule];if(!hash_equals(self::revision($raw),$i['expected_revision']))return new \WP_Error('cron_event_conflict','Agenda alterada.',['conflict'=>true]);return $e;}
    public static function schedule(array $i): array {
        if(!has_action($i['hook']))return Result::fail('cron_hook_unregistered','Hook não possui callbacks registrados.');
        return Locks::run(['wp-cron'=>LOCK_EX],static function()use($i){$args=$i['args']??[];$old=wp_get_scheduled_event($i['hook'],$args,$i['timestamp']);if($old)return Result::ok(['changed'=>false,'scheduled'=>true]);$r=empty($i['recurrence'])?wp_schedule_single_event($i['timestamp'],$i['hook'],$args,true):wp_schedule_event($i['timestamp'],$i['recurrence'],$i['hook'],$args,true);if(is_wp_error($r))return Result::error($r);return Result::ok(['changed'=>(bool)$r,'scheduled'=>(bool)wp_get_scheduled_event($i['hook'],$args,$i['timestamp'])]);});
    }
    public static function unschedule(array $i): array {return Locks::run(['wp-cron'=>LOCK_EX],static function()use($i){$e=self::event($i);if(is_wp_error($e))return Result::error($e);$r=wp_unschedule_event($e->timestamp,$e->hook,$e->args,true);return is_wp_error($r)?Result::error($r):Result::ok(['changed'=>(bool)$r,'persisted'=>!wp_get_scheduled_event($e->hook,$e->args,$e->timestamp)]);});}
    public static function status(array $i): array {
        $id=substr($i['operation_id'],5);if(!preg_match('/^[a-f0-9]{32}$/D',$id))return Result::fail('operation_not_found','Operação não encontrada.');
        $state=StateStore::get('cron-runs',$id);if(!$state||($state['connection_id']!==ConnectionContext::key()&&!self::admin()))return Result::fail('operation_not_found','Operação não encontrada.');
        if($state['status']==='running'){$lease=fopen(StateStore::directory('cron-runs').'/'.$id.'.lease','c+b');if($lease&&flock($lease,LOCK_EX|LOCK_NB)){$state['status']='uncertain';$state['reason']='cron_owner_interrupted';StateStore::put('cron-runs',$id,$state);flock($lease,LOCK_UN);}if($lease)fclose($lease);}
        return Result::ok(['operation_id'=>$i['operation_id'],'business_result'=>'unknown']+array_diff_key($state,['connection_id'=>true]));
    }
    private static function admin(): bool {return ConnectionContext::maintenance()&&current_user_can('manage_options');}
    public static function run(array $i): array {
        return Locks::run(['wp-cron'=>LOCK_EX],static function()use($i){
            $e=self::event($i);if(is_wp_error($e))return Result::error($e);
            if(!has_action($e->hook))return Result::fail('cron_hook_unregistered','Evento sem callback registrado.');
            $lock=get_transient('doing_cron');if($lock && (float)$lock+WP_CRON_LOCK_TIMEOUT>microtime(true))return Result::fail('cron_busy','WP-Cron já está executando.',['retryable'=>true]);
            $own=sprintf('%.22F',microtime(true));set_transient('doing_cron',$own);
            $user=get_current_user_id();$start=microtime(true);$job=bin2hex(random_bytes(16));$lease=fopen(StateStore::directory('cron-runs').'/'.$job.'.lease','c+b');if(!$lease||!flock($lease,LOCK_EX|LOCK_NB)){if($lease)fclose($lease);delete_transient('doing_cron');return Result::fail('cron_lease_failed','Não foi possível registrar a execução.');}$state=['status'=>'running','hook'=>$e->hook,'request_user_id'=>$user,'execution_user_id'=>0,'time'=>time(),'connection_id'=>ConnectionContext::key()];StateStore::put('cron-runs',$job,$state);
            try {
                if($e->schedule){$r=wp_reschedule_event($e->timestamp,$e->schedule,$e->hook,$e->args,true);if(is_wp_error($r))return Result::error($r);}
                $r=wp_unschedule_event($e->timestamp,$e->hook,$e->args,true);if(is_wp_error($r))return Result::error($r);
                if(!defined('DOING_CRON'))define('DOING_CRON',true);wp_set_current_user(0);do_action_ref_array($e->hook,$e->args);
                $state['status']='complete';$state['finished_at']=time();StateStore::put('cron-runs',$job,$state);return Result::ok(['operation_id'=>'cron:'.$job,'changed'=>true,'executed'=>true,'callback_result'=>null,'business_result'=>'unknown','result_semantics'=>'WordPress action completed without exception','duration_ms'=>(int)((microtime(true)-$start)*1000),'next_run'=>wp_next_scheduled($e->hook,$e->args)?:null]);
            }catch(\Throwable $err){$state['status']='uncertain';StateStore::put('cron-runs',$job,$state);return Result::fail('cron_callback_failed','Callback lançou exceção; efeitos externos precisam de conferência.',['applied'=>null,'hook'=>$e->hook]);}
            finally {if($state['status']==='running'){$state['status']='uncertain';$state['finished_at']=time();StateStore::put('cron-runs',$job,$state);}flock($lease,LOCK_UN);fclose($lease);wp_set_current_user($user);if(get_transient('doing_cron')===$own)delete_transient('doing_cron');}
        });
    }
}
