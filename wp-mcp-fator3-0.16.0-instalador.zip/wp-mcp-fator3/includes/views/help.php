<?php
if(!current_user_can('manage_options'))return;
echo '<section class="f3-card"><h2>Manual de operação instalado</h2><details><summary>Abrir manual</summary><pre style="white-space:pre-wrap">'.esc_html((string)(require F3_MCP_FILES_DIR.'includes/guide-content.php')).'</pre></details></section>';
