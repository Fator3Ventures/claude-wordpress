<?php
namespace Fator3\McpFiles;
OperationsAdmin::operations();
