<?php
\Fator3\McpFiles\ConnectionsAdmin::render();
