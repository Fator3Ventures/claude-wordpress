<?php
\Fator3\McpFiles\UpdateChannel::render();
