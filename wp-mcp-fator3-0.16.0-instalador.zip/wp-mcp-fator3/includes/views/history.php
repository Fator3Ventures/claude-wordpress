<?php
namespace Fator3\McpFiles;
OperationsAdmin::history();
