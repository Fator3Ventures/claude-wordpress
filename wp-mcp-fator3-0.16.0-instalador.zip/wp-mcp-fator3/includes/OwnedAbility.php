<?php
/** Preserve safe public denial codes while retaining WordPress validation/hooks. */
declare(strict_types=1);
namespace Fator3\McpFiles;
class OwnedAbility extends \WP_Ability {
    public function execute($input=null) {
        RootToolContext::enter($this->get_name());
        try {
        $normalized=$this->normalize_input($input);
        if(is_wp_error($normalized))return $normalized;
        $valid=$this->validate_input($normalized);if(is_wp_error($valid))return $valid;
        try { $allowed=$this->check_permissions($normalized); }
        catch(\Throwable $error) { $allowed=new \WP_Error('permission_denied','Não foi possível confirmar a permissão.'); }
        if(true!==$allowed) {
            $failure=is_wp_error($allowed)?Result::error($allowed):Result::fail('permission_denied','Permissão recusada.');
            Audit::record($this->get_name(),is_array($normalized)?$normalized:[],$failure,0);
            return $failure;
        }
        // WordPress still runs its permission check, input/output validation and hooks.
        // The decorated callback rechecks the effective policy before replay/effects.
        return parent::execute($input);
        } finally { RootToolContext::leave(); }
    }
}
