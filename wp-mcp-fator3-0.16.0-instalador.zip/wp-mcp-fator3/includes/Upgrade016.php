<?php
/** Upgrade from 0.15.0 or a clean installation. No credential migration is repeated. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Upgrade016 {
    private static string $origin = 'clean';
    public static function capture(): void {
        self::$origin = (string) get_option('f3_mcp_release_version', 'clean');
    }
    public static function run(): void {
        if (self::$origin === '0.16.0') return;
        if (!in_array(self::$origin, ['clean', '0.15.0'], true)) {
            throw new \RuntimeException('MCP 0.16.0 requires a clean installation or 0.15.0.');
        }
        $key = 'release:0.16.0';
        $journal = Persistence::get('migration', $key);
        if (!$journal) Persistence::put('migration', $key, [
            'from'=>self::$origin, 'to'=>'0.16.0', 'status'=>'running', 'started_at'=>time()
        ], true);
        // Keep even false/empty existing captures. This release does not inspect credentials.
        add_option('f3_mcp_014_credential_ids', [], '', false);
        Persistence::put('migration', $key, [
            'from'=>$journal['from'] ?? self::$origin, 'to'=>'0.16.0', 'status'=>'complete',
            'finished_at'=>time(), 'credentials_preserved'=>true, 'policies_preserved'=>true, 'data_schema'=>2
        ]);
        update_option('f3_mcp_release_version', '0.16.0', false);
    }
}
