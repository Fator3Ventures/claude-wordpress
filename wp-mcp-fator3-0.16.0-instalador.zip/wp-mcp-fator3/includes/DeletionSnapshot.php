<?php
/** Native deletion preimages. External hooks can have additional, nontransactional effects. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class DeletionSnapshot {
    public static function post(int $id) {
        global $wpdb;$post=get_post($id,ARRAY_A);if(!$post)return new \WP_Error('not_found','Conteúdo não encontrado.');
        $revisions=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->posts} WHERE post_parent=%d AND post_type='revision' ORDER BY ID LIMIT 1001",$id),ARRAY_A);
        $comments=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->comments} WHERE comment_post_ID=%d ORDER BY comment_ID LIMIT 1001",$id),ARRAY_A);
        if($wpdb->last_error||count($revisions)>1000||count($comments)>1000)return new \WP_Error('deletion_preimage_limit','Histórico excede a pré-imagem limitada; reduza a seleção por operação tipada.');
        foreach($revisions as &$revision)$revision=['post'=>$revision,'meta'=>get_post_meta((int)$revision['ID'])];unset($revision);
        foreach($comments as &$comment)$comment=['comment'=>$comment,'meta'=>get_comment_meta((int)$comment['comment_ID'])];unset($comment);
        $out=['post'=>$post,'meta'=>get_post_meta($id),'terms'=>wp_get_object_terms($id,get_object_taxonomies($post['post_type'])),'revisions'=>$revisions,'comments'=>$comments,'children'=>$wpdb->get_results($wpdb->prepare("SELECT ID,post_parent,post_type FROM {$wpdb->posts} WHERE post_parent=%d AND post_type<>'revision' ORDER BY ID LIMIT 1001",$id),ARRAY_A)];
        if(is_wp_error($out['terms']))return $out['terms'];
        if($wpdb->last_error)return new \WP_Error('deletion_preimage_failed','Falha ao ler os filhos; nada foi excluído.');
        if(count($out['children'])>1000)return new \WP_Error('deletion_preimage_limit','Filhos excedem a pré-imagem limitada.');
        if($post['post_type']==='attachment'){
            $out['metadata']=wp_get_attachment_metadata($id);$file=get_attached_file($id);$paths=[];
            if($file){$paths[]=$file;$base=dirname($file);foreach($out['metadata']['sizes']??[] as $size)$paths[]=$base.'/'.$size['file'];if(!empty($out['metadata']['original_image']))$paths[]=$base.'/'.$out['metadata']['original_image'];foreach((array)get_post_meta($id,'_wp_attachment_backup_sizes',true) as $size)if(!empty($size['file']))$paths[]=$base.'/'.$size['file'];}
            $out['files']=[];$total=0;
            foreach(array_unique($paths) as $path){$resolved=Locks::path($path);if(is_wp_error($resolved))return $resolved;if(!is_file($resolved)){ $out['files'][]=['path'=>$resolved,'missing'=>true];continue;}
                $size=filesize($resolved);$total+=$size;if($total>67108864)return new \WP_Error('deletion_preimage_limit','Arquivos da mídia excedem 64 MiB.');
                $out['files'][]=['path'=>$resolved,'bytes'=>$size,'sha256'=>hash_file('sha256',$resolved)];
            }
        }
        if(strlen(serialize($out))>16777216)return new \WP_Error('deletion_preimage_limit','Pré-imagem excede 16 MiB de metadados.');return $out;
    }
    public static function preserve_files(array &$snapshot) {
        $ids=[];
        foreach($snapshot['files']??[] as $file){if(!empty($file['missing']))continue;
            if(!is_file($file['path'])||!hash_equals($file['sha256'],hash_file('sha256',$file['path'])))return new \WP_Error('deletion_conflict','Arquivo associado mudou desde a seleção.');
            $id=Backups::create_file($file['path']);if(is_wp_error($id))return $id;$ids[]=$id;
        }
        if(isset($snapshot['content']))foreach($snapshot['content'] as &$post){$more=self::preserve_files($post);if(is_wp_error($more))return $more;$ids=array_merge($ids,$more);}unset($post);
        if($ids)$snapshot['file_backups']=$ids;return $ids;
    }
    public static function user(int $id,array $input) {
        global $wpdb;$user=get_userdata($id);if(!$user)return new \WP_Error('not_found','Usuário não encontrado.');
        if(empty($input['reassign_to'])&&empty($input['delete_content']))return new \WP_Error('user_content_disposition_required','Informe reassign_to válido ou delete_content:true explicitamente.');
        if(!empty($input['reassign_to'])&&((int)$input['reassign_to']===$id||!get_user_by('id',(int)$input['reassign_to'])))return new \WP_Error('reassign_invalid','Usuário de destino inválido.');
        $posts=$wpdb->get_col($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_author=%d AND post_type<>'revision' ORDER BY ID LIMIT 1001",$id));
        if($wpdb->last_error||count($posts)>1000)return new \WP_Error('deletion_preimage_limit','Usuário tem conteúdo demais para uma exclusão única.');
        $content=[];$bytes=0;foreach($posts as $post){$row=self::post((int)$post);if(is_wp_error($row))return $row;$content[]=$row;foreach($row['files']??[] as $file)$bytes+=(int)($file['bytes']??0);if($bytes>67108864)return new \WP_Error('deletion_preimage_limit','Arquivos associados ao usuário excedem 64 MiB.');if(strlen(serialize($content))>16777216)return new \WP_Error('deletion_preimage_limit','Conteúdo do usuário excede limite da pré-imagem.');}
        return ['user'=>(array)$user->data,'meta'=>get_user_meta($id),'content_count'=>count($content),'content'=>$content,'reassign_to'=>$input['reassign_to']??null,'external_hook_effects_reversible'=>false];
    }
}
