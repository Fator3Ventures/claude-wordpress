<?php
/** Frozen, resumable retention selections. New backups never enter an existing confirmation. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;
final class Retention {
    private static function component(string $path): array {
        if(is_link($path))throw new \RuntimeException('Linked component.');
        $manifest=Engine::manifest($path);if(!$manifest)throw new \RuntimeException('Missing component.');
        $bytes=0;foreach($manifest['files'] as $entry)$bytes+=(int)($entry['bytes']??0);
        return ['path'=>$path,'sha256'=>Engine::digest($manifest),'bytes'=>$bytes,'removed'=>false];
    }
    private static function item(array $row): array {
        $id=$row['id'];$legacy=!empty($row['legacy']);$parts=[];
        foreach($row['protected_by_backups']??[] as $parent)if(is_file(StateStore::path('backups',$parent)))throw new \RuntimeException('backup_reference');
        if(!empty($row['protected_by_operations']))throw new \RuntimeException('operation_reference');
        if($legacy){
            $meta=WP_CONTENT_DIR.'/f3-mcp-backups/'.$id.'.json';
            if(($row['kind']??'file')==='file'){
                $bak=WP_CONTENT_DIR.'/f3-mcp-backups/'.$id.'.bak';
                if(!is_file($bak)||is_link($bak)||!hash_equals((string)($row['sha256']??''),hash_file('sha256',$bak)))throw new \RuntimeException('legacy_pair_invalid');
                $parts[]=self::component($bak);
            }
            $parts[]=self::component($meta);
        }else{
            $payload=Backups::metadata($id);if(is_wp_error($payload))throw new \RuntimeException('backup_corrupt');
            if(($payload['ability']??'')==='recovery'){
                $journal=Recovery::directory().'/'.($payload['snapshot']['journal_id']??'').'.journal.php';$state=Engine::read($journal);
                if(!$state||!in_array($state['status'],['complete','rolled_back','unchanged'],true))throw new \RuntimeException('recovery_reference');
                if(file_exists($state['preimage']))$parts[]=self::component($state['preimage']);
                // The signed journal is retained as a consumed-operation receipt, never reused as a new effect.
            }
            $parts[]=self::component(StateStore::path('backups',$id));
        }
        foreach(glob(StateStore::directory('backup-exports').'/'.$id.'-*.php')?:[] as $export)$parts[]=self::component($export);
        return ['id'=>$id,'kind'=>$row['kind']??'unknown','legacy'=>$legacy,'time'=>$row['time']??null,'parts'=>$parts,'bytes'=>array_sum(array_column($parts,'bytes')),'status'=>'pending'];
    }
    private static function plan(array $input): array {
        global $wpdb;$cutoff=time()-max(1,(int)($input['older_than_days']??30))*DAY_IN_SECONDS;
        $table=Persistence::table('backup-index');$all_bytes=(int)$wpdb->get_var("SELECT COALESCE(SUM(stored_bytes),0) FROM `$table` WHERE bucket='backup-index' AND status<>'deleted'");
        $offset=max(0,(int)($input['offset']??0));$rows=$wpdb->get_col($wpdb->prepare("SELECT payload FROM `$table` WHERE bucket='backup-index' AND status<>'deleted' ORDER BY created_at,id LIMIT 201 OFFSET %d",$offset));
        if($wpdb->last_error)throw new \RuntimeException('Inventory unavailable.');$more=count($rows)>200;$rows=array_slice($rows,0,200);$selected=[];$blocked=[];$projected=$all_bytes;
        foreach($rows as $json){$row=json_decode($json,true,512,JSON_THROW_ON_ERROR);$when=strtotime((string)($row['time']??''));$over=isset($input['max_total_bytes'])&&$projected>(int)$input['max_total_bytes'];if(!$when||$when>=$cutoff&&!$over)continue;
            try{$item=self::item($row);$selected[]=$item;$projected-=(int)($row['stored_bytes']??0);}catch(\Throwable $e){$blocked[]=['id'=>$row['id'],'reason'=>$e->getMessage()];}
        }
        $legacy_more=false;$legacy_next=null;
        if(!empty($input['include_legacy'])){
            $directory=WP_CONTENT_DIR.'/f3-mcp-backups';$seen=0;$after=(string)($input['legacy_after']??'');$candidates=[];
            // A bounded ordered window without trusting arbitrary file names as backups.
            if(is_dir($directory)&&!is_link($directory))foreach(new \FilesystemIterator($directory,\FilesystemIterator::SKIP_DOTS) as $file){
                $name=$file->getFilename();if($name<=$after||!preg_match('/^(?:db)?[a-f0-9]{16,64}\.(?:json|bak)$/iD',$name))continue;
                // A recognized .bak without its metadata is blocked, never silently
                // omitted or treated as an independently deletable backup.
                if(str_ends_with($name,'.bak')&&file_exists($directory.'/'.substr($name,0,-4).'.json'))continue;
                $candidates[$name]=$file->getPathname();
                if(count($candidates)>201){ksort($candidates,SORT_STRING);array_pop($candidates);$legacy_more=true;}
            }
            ksort($candidates,SORT_STRING);if(count($candidates)>200){array_pop($candidates);$legacy_more=true;}
            foreach($candidates as $name=>$file){$legacy_next=$name;
                if(str_ends_with($name,'.bak')){$blocked[]=['id'=>basename($file,'.bak'),'reason'=>'legacy_metadata_missing'];continue;}
                $id=basename($file,'.json');
                if(is_link($file)||filesize($file)>16777216){$blocked[]=['id'=>$id,'reason'=>'legacy_unsafe'];continue;}
                $row=json_decode((string)file_get_contents($file),true);$when=is_array($row)?strtotime((string)($row['time']??'')):false;
                if(!$row||($row['id']??'')!==$id||!$when){$blocked[]=['id'=>$id,'reason'=>'legacy_corrupt'];continue;}if($when>=$cutoff)continue;
                $row['kind']=isset($row['rows'])?'database':'file';$row['legacy']=true;
                try{$selected[]=self::item($row);}catch(\Throwable $e){$blocked[]=['id'=>$id,'reason'=>$e->getMessage()];}
            }
        }
        $state=['status'=>'pending','connection_id'=>ConnectionContext::key(),'time'=>time(),'expires'=>time()+3600,'items'=>$selected,'blocked'=>$blocked,'indexed_bytes'=>$all_bytes,'projected_indexed_bytes'=>max(0,$projected),'has_more'=>$more||$legacy_more,'next_offset'=>$more?$offset+count($rows):null,'legacy_after'=>$legacy_more?$legacy_next:null];
        $hash=hash_hmac('sha256',serialize($state),wp_salt('auth'));StateStore::put('retention-plans',ConnectionContext::key().'|'.$hash,$state);$state['selection_sha256']=$hash;return $state;
    }
    private static function public(array $state,bool $dry): array {
        $selection=[];foreach($state['items'] as $item)$selection[]=array_intersect_key($item,array_flip(['id','kind','legacy','time','bytes','status']));
        return ['dry_run'=>$dry,'selected'=>count($selection),'selection'=>$selection,'blocked'=>$state['blocked'],'indexed_bytes'=>$state['indexed_bytes'],'projected_indexed_bytes'=>$state['projected_indexed_bytes'],'has_more'=>$state['has_more'],'next_offset'=>$state['next_offset'],'legacy_after'=>$state['legacy_after'],'expected_selection_sha256'=>$state['selection_sha256'],'removed'=>count(array_filter($selection,static fn($r)=>$r['status']==='complete'))];
    }
    public static function prune(array $input): array {
        return Locks::run(['backups:'.get_current_blog_id()=>LOCK_EX],static function()use($input){
            if($input['dry_run']??true)return Result::ok(self::public(self::plan($input),true));
            $hash=$input['expected_selection_sha256']??'';
            if(!preg_match('/^[a-f0-9]{64}$/D',$hash))return Result::fail('backup_selection_required','Use o expected_selection_sha256 da simulação.');
            $key=ConnectionContext::key().'|'.$hash;$state=StateStore::get('retention-plans',$key);
            if(!$state||($state['connection_id']??'')!==ConnectionContext::key())return Result::fail('backup_selection_invalid','Seleção não pertence a esta conexão.');
            $state['selection_sha256']=$hash;
            if($state['status']==='complete')return Result::ok(self::public($state,false)+['replayed'=>true]);
            if($state['status']==='pending'&&$state['expires']<time())return Result::fail('backup_selection_expired','Simulação expirou.');
            foreach($state['items'] as $item){
                if($item['status']==='complete')continue;
                $index=Persistence::get('backup-index',$item['id']);foreach($index['protected_by_backups']??[] as $parent)if(is_file(StateStore::path('backups',$parent)))return Result::fail('backup_selection_conflict','Backup ganhou referência de pré-imagem.',['conflict'=>true]);if(!empty($index['protected_by_operations']))return Result::fail('backup_selection_conflict','Backup ganhou referência de operação.',['conflict'=>true]);
                foreach($item['parts'] as $part){if($part['removed']||($part['phase']??'')==='removing')continue;
                    $observed=isset($part['quarantine'])&&file_exists($part['quarantine'])?$part['quarantine']:$part['path'];$actual=Engine::digest(Engine::manifest($observed));
                    if($actual===null&&$state['status']==='running')continue;
                    if($actual!==$part['sha256'])return Result::fail('backup_selection_conflict','Componente selecionado mudou; nada novo foi incluído.',['conflict'=>true,'backup_id'=>$item['id']]);
                }
            }
            $state['status']='running';StateStore::put('retention-plans',$key,$state);$failed=[];
            foreach($state['items'] as &$item){
                if($item['status']==='complete')continue;
                foreach($item['parts'] as &$part){if($part['removed'])continue;
                    try{
                        if(!isset($part['quarantine'])){$part['quarantine']=dirname($part['path']).'/.f3-prune-'.bin2hex(random_bytes(16));$part['phase']='quarantining';StateStore::put('retention-plans',$key,$state);}
                        if(file_exists($part['path'])){if(file_exists($part['quarantine'])||!rename($part['path'],$part['quarantine']))throw new \RuntimeException('Cannot quarantine component.');}
                        $part['phase']='removing';StateStore::put('retention-plans',$key,$state);
                        if(file_exists($part['quarantine']))Engine::remove($part['quarantine']);
                        $part['removed']=true;StateStore::put('retention-plans',$key,$state);
                    }
                    catch(\Throwable $e){$failed[]=['id'=>$item['id'],'remaining_component'=>basename($part['path'])];break;}
                }unset($part);
                if(!array_filter($item['parts'],static fn($p)=>!$p['removed'])){$item['status']='complete';if(!$item['legacy'])StateStore::delete('backup-index',$item['id']);StateStore::put('retention-plans',$key,$state);}
            }unset($item);
            if(!$failed)$state['status']='complete';StateStore::put('retention-plans',$key,$state);
            return $failed?Result::fail('backup_prune_partial','Repita a mesma seleção para reconciliar componentes restantes.',self::public($state,false)+['failed'=>$failed,'pending'=>true]):Result::ok(self::public($state,false));
        });
    }
}
