<?php
/** Explicit HTTPS manifest channels; disabled until the administrator supplies real feed URLs. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class UpdateChannel {
    public const HOST='fator3.com.br';
    public const PACKAGES=[
        'wp-mcp-fator3'=>'wp-mcp-fator3/wp-mcp-fator3.php',
        'base-site-core-fator3'=>'base-site-core-fator3/base-site-core-fator3.php',
        'wp-mcp-google-fator3'=>'wp-mcp-google-fator3/wp-mcp-google-fator3.php',
    ];
    public static function init(): void {
        add_filter('update_plugins_'.self::HOST,[self::class,'offer'],10,4);
        add_filter('upgrader_pre_download',[self::class,'download'],20,4);
        add_action('admin_post_f3_mcp_update_channels',[self::class,'submit']);
    }
    public static function validate(array $doc,string $package,array $hosts) {
        $plugin=self::PACKAGES[$package]??null;
        if(($doc['schema_version']??null)!==1||($doc['package']??'')!==$package||($doc['plugin']??'')!==$plugin)return new \WP_Error('manifest_identity_invalid','Identidade do manifesto não corresponde ao pacote.');
        foreach(['version','url','sha256'] as $key)if(!is_string($doc[$key]??null))return new \WP_Error('manifest_schema_invalid','Campo obrigatório ausente.');
        if(!preg_match('/^[0-9][A-Za-z0-9.+-]{0,63}$/D',$doc['version'])||!preg_match('/^[a-f0-9]{64}$/D',$doc['sha256']))return new \WP_Error('manifest_schema_invalid','Versão ou digest inválido.');
        $url=wp_parse_url($doc['url']);
        if(($url['scheme']??'')!=='https'||!in_array(strtolower($url['host']??''),$hosts,true)||isset($url['user'])||isset($url['pass'])||isset($url['fragment'])||isset($url['port'])&&$url['port']!==443)return new \WP_Error('manifest_origin_invalid','URL do pacote fora das origens HTTPS autorizadas.');
        foreach(['requires','tested'] as $group){if(!is_array($doc[$group]??null))return new \WP_Error('manifest_schema_invalid','Requisitos e teste precisam ser tipados.');foreach(['wordpress','php'] as $key)if(!is_string($doc[$group][$key]??null)||!preg_match('/^\d+(?:\.\d+){1,3}$/D',$doc[$group][$key]))return new \WP_Error('manifest_schema_invalid','Versão de requisito/teste inválida.');}
        if(!is_string($doc['tested']['evidence']??null)||$doc['tested']['evidence']==='')return new \WP_Error('manifest_evidence_missing','Manifesto precisa identificar evidência de homologação.');
        if(isset($doc['requires']['plugins'])&&!is_array($doc['requires']['plugins']))return new \WP_Error('manifest_dependency_invalid','Dependências precisam ser mapa.');
        foreach($doc['requires']['plugins']??[] as $dependency=>$version){if(!isset(self::PACKAGES[$dependency])||!is_string($version)||!preg_match('/^\d+(?:\.\d+){1,3}$/D',$version))return new \WP_Error('manifest_dependency_invalid','Dependência fora do contrato.');}
        return $doc;
    }
    public static function manifest(string $package) {
        $channel=get_option('f3_mcp_update_channels',[])[$package]??null;
        if(!$channel||empty($channel['url']))return new \WP_Error('update_channel_unconfigured','Canal sem URL configurada.');
        $key=$package.'|'.hash('sha256',serialize($channel));$cached=StateStore::get('update-manifests',$key);
        if($cached&&($cached['expires']??0)>time())return $cached['manifest'];
        $url=$channel['url'];$safe=Http::validate_public_url($url);if(is_wp_error($safe)||wp_parse_url($url,PHP_URL_SCHEME)!=='https')return new \WP_Error('manifest_origin_invalid','Manifesto exige origem HTTPS pública.');
        $r=wp_safe_remote_get($url,['timeout'=>5,'redirection'=>0,'cookies'=>[],'sslverify'=>true,'limit_response_size'=>65537,'headers'=>['Accept'=>'application/json']]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return new \WP_Error('manifest_fetch_failed','Manifesto indisponível; redirecionamentos são recusados.');
        $bytes=wp_remote_retrieve_body($r);if(strlen($bytes)>65536)return new \WP_Error('manifest_size_limit','Manifesto supera 64 KiB.');
        $type=strtolower(trim(explode(';',(string)wp_remote_retrieve_header($r,'content-type'))[0]));$doc=json_decode($bytes,true);
        if($type!=='application/json'||!is_array($doc)||array_is_list($doc))return new \WP_Error('manifest_schema_invalid','JSON de manifesto inválido.');
        $hosts=array_values(array_unique(array_merge([strtolower((string)wp_parse_url($url,PHP_URL_HOST))],$channel['package_hosts']??[])));
        $valid=self::validate($doc,$package,$hosts);if(is_wp_error($valid))return $valid;
        StateStore::put('update-manifests',$key,['manifest'=>$valid,'expires'=>time()+300,'time'=>time()]);return $valid;
    }
    public static function offer($update,array $headers,string $plugin,array $locales) {
        $package=array_search($plugin,self::PACKAGES,true);if($package===false)return $update;
        $manifest=self::manifest($package);if(is_wp_error($manifest))return false;
        if(!is_wp_version_compatible($manifest['requires']['wordpress'])||!is_php_version_compatible($manifest['requires']['php']))return false;
        require_once ABSPATH.'wp-admin/includes/plugin.php';$installed=get_plugins();
        foreach($manifest['requires']['plugins']??[] as $dep=>$version)if(!isset($installed[self::PACKAGES[$dep]])||version_compare($installed[self::PACKAGES[$dep]]['Version'],$version,'<'))return false;
        return ['slug'=>$package,'version'=>$manifest['version'],'new_version'=>$manifest['version'],'package'=>$manifest['url'],'requires'=>$manifest['requires']['wordpress'],'requires_php'=>$manifest['requires']['php'],'tested'=>$manifest['tested']['wordpress'],'f3_sha256'=>$manifest['sha256'],'f3_manifest_version'=>1];
    }
    /** Digest validation also covers WordPress's native admin updater. */
    public static function download($reply,string $url,$upgrader,array $extra) {
        $plugin=$extra['plugin']??'';$package=array_search($plugin,self::PACKAGES,true);if($package===false)return $reply;
        if($package==='wp-mcp-fator3'&&$upgrader!==null&&!$upgrader instanceof AtomicPluginUpgrader)return new \WP_Error('self_update_requires_recovery','Atualize o servidor pela habilidade plugins/update, que usa recuperação independente. O atualizador nativo não possui esse diário.');
        $manifest=self::manifest($package);if(is_wp_error($manifest))return $manifest;
        if($url!==$manifest['url'])return new \WP_Error('package_identity_conflict','Oferta mudou; consulte atualizações novamente.');
        if(is_wp_error($reply))return $reply;
        if(is_string($reply)&&is_file($reply))return hash_equals($manifest['sha256'],hash_file('sha256',$reply))?$reply:new \WP_Error('package_hash_conflict','ZIP não corresponde ao manifesto.');
        $safe=Http::validate_public_url($url);if(is_wp_error($safe))return $safe;
        $r=wp_safe_remote_get($url,['timeout'=>20,'redirection'=>0,'cookies'=>[],'sslverify'=>true,'limit_response_size'=>16777217]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return new \WP_Error('package_download_failed','Download falhou; redirecionamentos não são aceitos no canal próprio.');
        $bytes=wp_remote_retrieve_body($r);if(strlen($bytes)>16777216||!hash_equals($manifest['sha256'],hash('sha256',$bytes)))return new \WP_Error('package_hash_conflict','Tamanho ou digest diverge do manifesto.');
        $file=wp_tempnam($package.'.zip');if(!$file||file_put_contents($file,$bytes)!==strlen($bytes)){if($file)@unlink($file);return new \WP_Error('package_download_failed','Temporário incompleto.');}return $file;
    }
    public static function submit(): void {
        if(!current_user_can('manage_options')||!current_user_can('update_plugins'))wp_die('Permissão insuficiente.','',['response'=>403]);check_admin_referer('f3_mcp_update_channels');
        $posted=wp_unslash($_POST['channels']??[]);$channels=[];$error='';
        if(!is_array($posted))$error='Configuração inválida.';
        else foreach(self::PACKAGES as $package=>$plugin){$entry=$posted[$package]??[];$url=trim((string)($entry['url']??''));if($url==='')continue;$p=wp_parse_url($url);
            if(strlen($url)>2048||($p['scheme']??'')!=='https'||empty($p['host'])||isset($p['user'])||isset($p['pass'])||isset($p['fragment'])){$error='Informe URLs HTTPS sem credenciais/fragmentos.';break;}
            $hosts=preg_split('/[\s,]+/',strtolower(trim((string)($entry['package_hosts']??''))),-1,PREG_SPLIT_NO_EMPTY)?:[];
            foreach($hosts as $host)if(!preg_match('/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/D',$host)){$error='Host adicional inválido.';break 2;}
            $channels[$package]=['url'=>$url,'package_hosts'=>array_values(array_unique($hosts))];
        }
        if(!$error){update_option('f3_mcp_update_channels',$channels,false);delete_site_transient('update_plugins');}
        $notice=wp_generate_uuid4();set_transient('f3_mcp_notice_'.get_current_user_id().'_'.$notice,['success'=>$error==='','message'=>$error?:'Canais salvos. Nenhum pacote foi instalado.'],60);wp_safe_redirect(add_query_arg('notice',$notice,Admin::url('updates')));exit;
    }
    public static function render(): void {
        $channels=get_option('f3_mcp_update_channels',[]);
        echo '<section class="f3-card"><h2>Canais de atualização</h2><p>Informe o manifesto HTTPS publicado de cada pacote. Campos vazios deixam o canal desabilitado. O Update URI identifica o pacote e não é automaticamente uma URL de download.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('f3_mcp_update_channels');echo '<input type="hidden" name="action" value="f3_mcp_update_channels">';
        foreach(self::PACKAGES as $package=>$file){$c=$channels[$package]??[];echo '<fieldset><legend><strong>'.esc_html($package).'</strong></legend><p><label>URL do manifest.json<br><input class="large-text" type="url" name="channels['.esc_attr($package).'][url]" value="'.esc_attr($c['url']??'').'"></label></p><details><summary>Origens adicionais de download</summary><p>Por padrão o ZIP precisa vir do mesmo host do manifesto. Redirecionamentos são recusados.</p><label>Hosts adicionais, separados por espaço<input class="large-text" name="channels['.esc_attr($package).'][package_hosts]" value="'.esc_attr(implode(' ',$c['package_hosts']??[])).'"></label></details></fieldset>';}
        echo '<p><button class="button button-primary">Salvar canais</button></p></form></section>';
    }
}
