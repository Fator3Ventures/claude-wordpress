<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;
final class ThemePackages {
    public static function register(): void {
        Registry::add('themes/upload','Instala tema ZIP por URL/base64 com staging, hash/slug, backup, sonda e reversão. activate/overwrite false por padrão.',['url'=>Registry::string(),'content_base64'=>Registry::string(),'expected_sha256'=>Registry::string(),'expected_slug'=>Registry::string(),'overwrite'=>Registry::boolean(),'activate'=>Registry::boolean()],[],[self::class,'upload'],'install_themes',false);
        Registry::add('themes/update','Atualiza tema pela oferta WordPress, preservando ativação e backup.',['stylesheet'=>Registry::string()],['stylesheet'],[self::class,'update'],'update_themes',false);
        Registry::add('themes/delete','Exclui tema inativo sem dependentes, em duas fases e com backup.',['stylesheet'=>Registry::string(),'confirm_token'=>Registry::string()],['stylesheet'],[self::class,'delete'],'delete_themes',false);
        Registry::add('themes/rollback','Restaura arquivos e seleção de tema anterior a uma operação. Hash divergente impede sobrescrever alterações posteriores.',['backup_id'=>Registry::string()],['backup_id'],[self::class,'rollback'],'update_themes',false);
    }
    public static function activate(array $i): array {
        $slug=$i['stylesheet'];if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,99}$/D',$slug))return Result::fail('theme_invalid','Nome de tema inválido.');
        $theme=wp_get_theme($slug);if(!$theme->exists()||$theme->errors())return Result::fail('theme_invalid','Tema ou dependência indisponível.');
        if(!is_wp_version_compatible($theme->get('RequiresWP'))||!is_php_version_compatible($theme->get('RequiresPHP')))return Result::fail('package_requirements','WordPress/PHP incompatíveis.');
        return Locks::trees([get_theme_root()],static function()use($i,$slug){$target=get_theme_root().'/'.$slug;
            return Phase::run('themes/activate',$i,static fn()=>['stylesheet'=>get_option('stylesheet'),'template'=>get_option('template'),'current_theme'=>get_option('current_theme'),'target_sha256'=>Engine::digest(Engine::manifest($target))],static function($old)use($slug,$target){
                if($old['stylesheet']===$slug)return Result::ok(['changed'=>false,'stylesheet'=>$slug]);$baseline=Probe::run();if(!Recovery::verified($baseline))return Result::fail('theme_baseline_failed','Sonda inicial falhou.');
                $op=Recovery::begin($target,Engine::digest(Engine::manifest($target)),['tree_operation'=>true,'theme'=>$slug,'theme_before'=>array_diff_key($old,['target_sha256'=>true]),'lock_root'=>get_theme_root()]);
                try{switch_theme($slug);Recovery::close($op,'applied');$probe=Probe::run();if(!Recovery::verified($probe)){$r=Engine::restore($op['file'],true);return Result::fail('theme_probe_failed','Sonda recusou o tema.',['recovery'=>$r,'backup_id'=>$op['state']['backup_id']]);}Recovery::close($op,'complete');return Result::ok(['changed'=>true,'stylesheet'=>get_stylesheet(),'template'=>get_template(),'backup_id'=>$op['state']['backup_id'],'probe_after'=>$probe]);}
                catch(\Throwable $e){$r=Engine::restore($op['file'],true);return Result::fail('theme_activation_failed','Não foi possível selecionar o tema.',['recovery'=>$r,'backup_id'=>$op['state']['backup_id']]);}finally{Recovery::release($op);}
            });
        });
    }
    public static function upload(array $i): array {
        if(count(array_intersect(array_keys($i),['url','content_base64']))!==1)return Result::fail('package_source_invalid','Forneça URL ou content_base64.');
        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/theme.php';
        if(get_filesystem_method()!=='direct')return Result::fail('filesystem_direct_required','Recuperação requer filesystem direto.');
        $dir=StateStore::directory('theme-staging').'/'.bin2hex(random_bytes(16));mkdir($dir,0700);mkdir($dir.'/expanded',0700);
        try{
            if(isset($i['url'])){$r=Http::fetch($i['url'],PathGuard::max_bytes());if(is_wp_error($r))return Result::error($r);$bytes=$r['body'];}else $bytes=base64_decode($i['content_base64'],true);
            if($bytes===false||strlen($bytes)>PathGuard::max_bytes())return Result::fail('package_size_limit','ZIP inválido ou acima do limite.');$hash=hash('sha256',$bytes);if(isset($i['expected_sha256'])&&!hash_equals(strtolower($i['expected_sha256']),$hash))return Result::fail('package_hash_conflict','Digest do ZIP diverge.',['conflict'=>true]);
            Engine::atomic($dir.'/theme.zip',$bytes,0600);unset($bytes);$entries=ZipPackage::extract($dir.'/theme.zip',$dir.'/expanded');$roots=[];foreach($entries as $entry)$roots[explode('/',$entry['filename'])[0]]=true;
            if(count($roots)!==1)return Result::fail('package_multiple_roots','Tema exige uma raiz.');$slug=array_key_first($roots);
            if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,99}$/D',$slug)||isset($i['expected_slug'])&&$i['expected_slug']!==$slug)return Result::fail('package_slug_conflict','Raiz não corresponde ao tema esperado.');
            $theme=wp_get_theme($slug,$dir.'/expanded');if(!$theme->exists()||!$theme->get('Name'))return Result::fail('theme_invalid','style.css/tema inválido.');
            if(!is_wp_version_compatible($theme->get('RequiresWP'))||!is_php_version_compatible($theme->get('RequiresPHP')))return Result::fail('package_requirements','WordPress/PHP incompatíveis.');
            if($theme->get('Template')&&!wp_get_theme($theme->get('Template'))->exists())return Result::fail('theme_parent_missing','Instale o tema pai antes.');
            return Locks::trees([get_theme_root()],static function()use($i,$dir,$slug,$theme,$hash){
                $target=get_theme_root().'/'.$slug;$old=wp_get_theme($slug);$exists=is_dir($target);if($exists&&empty($i['overwrite']))return Result::fail('destination_exists','overwrite:true necessário.');if($exists&&!current_user_can('update_themes'))return Result::fail('permission_denied','Substituição exige update_themes.');
                if(!empty($i['activate'])&&!current_user_can('switch_themes'))return Result::fail('permission_denied','Ativação exige switch_themes.');
                $before=['stylesheet'=>get_option('stylesheet'),'template'=>get_option('template'),'current_theme'=>get_option('current_theme')];$probe=Probe::run();if(!Recovery::verified($probe))return Result::fail('theme_baseline_failed','Sonda inicial falhou; tema preservado.');
                $expected=Engine::digest(Engine::manifest($dir.'/expanded/'.$slug));$op=Recovery::begin($target,$expected,['tree_operation'=>true,'theme'=>$slug,'theme_before'=>$before,'lock_root'=>get_theme_root()]);
                try{
                    Engine::prepare_install($op['file'],$dir.'/expanded/'.$slug);Engine::commit_install($op['file']);Recovery::close($op,'applied');wp_clean_themes_cache();
                    if(!empty($i['activate']))switch_theme($slug);$after=Probe::run();
                    if(!Recovery::verified($after)){$restore=Engine::restore($op['file'],true);wp_clean_themes_cache();return Result::fail('theme_probe_failed','Tema não aprovado pela sonda.',['backup_id'=>$op['state']['backup_id'],'recovery'=>$restore,'probe_after'=>$after]);}
                    Recovery::close($op,'complete');return Result::ok(['changed'=>true,'stylesheet'=>$slug,'version'=>wp_get_theme($slug)->get('Version'),'old_version'=>$exists?$old->get('Version'):null,'active_before'=>$before['stylesheet']===$slug,'active_after'=>get_stylesheet()===$slug,'backup_id'=>$op['state']['backup_id'],'zip_sha256'=>$hash,'probe_before'=>$probe,'probe_after'=>$after]);
                }catch(\Throwable $e){$restore=Engine::restore($op['file'],true);return Result::fail('theme_install_failed','Troca de tema falhou.',['backup_id'=>$op['state']['backup_id'],'recovery'=>$restore]);}finally{Recovery::release($op);}
            });
        }catch(\Throwable $e){return Result::fail('theme_package_invalid','Falha de validação ou preparação do tema.');}finally{Engine::remove($dir);}
    }
    public static function update(array $i): array {require_once ABSPATH.'wp-admin/includes/update.php';wp_update_themes();$offers=get_site_transient('update_themes');$o=$offers->response[$i['stylesheet']]??null;if(!$o)return Result::ok(['changed'=>false,'stylesheet'=>$i['stylesheet']]);return self::upload(['url'=>$o['package'],'expected_slug'=>$i['stylesheet'],'overwrite'=>true]);}
    public static function delete(array $i): array {
        $slug=$i['stylesheet'];if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,99}$/D',$slug))return Result::fail('theme_invalid','Nome inválido.');
        return Locks::trees([get_theme_root()],static function()use($i,$slug){
            if(in_array($slug,[get_stylesheet(),get_template()],true))return Result::fail('theme_active','Tema ou pai ativo não pode ser excluído.');foreach(wp_get_themes() as $theme)if($theme->get('Template')===$slug)return Result::fail('theme_has_dependents','Há tema filho instalado.');$target=get_theme_root().'/'.$slug;if(!is_dir($target))return Result::fail('theme_not_found','Tema ausente.');
            return Phase::run('themes/delete',$i,static fn()=>['stylesheet'=>$slug,'sha256'=>Engine::digest(Engine::manifest($target))],static function()use($target,$slug){$op=Recovery::begin($target,null,['tree_operation'=>true,'theme'=>$slug]);try{Engine::remove($target);Recovery::close($op,'complete');wp_clean_themes_cache();return Result::ok(['changed'=>true,'backup_id'=>$op['state']['backup_id']]);}finally{Recovery::release($op);}});
        });
    }
    public static function rollback(array $i): array {return ArchiveTools::rollback($i);}
}
