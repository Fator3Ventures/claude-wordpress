<?php
/** Internal root invocation capability. Never derived from client arguments. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class RootToolContext {
    private static ?array $root=null;
    private static array $abilities=[];
    public static function open($server,string $name): ?object {
        if(self::$root!==null || self::$abilities || !ConnectionEndpoints::is_owned($server))return null;
        $context=ConnectionContext::get();
        if(!$context || !in_array($context['transport']??'', ['oauth','wordpress-application-password'],true))return null;
        $handle=new \stdClass();self::$root=['handle'=>$handle,'name'=>$name,'connection'=>$context['connection_id'],'user'=>get_current_user_id()];
        return $handle;
    }
    public static function close(?object $handle): void {
        if($handle!==null && (self::$root['handle']??null)===$handle)self::$root=null;
    }
    public static function enter(string $name): void {self::$abilities[]=$name;}
    public static function leave(): void {array_pop(self::$abilities);}
    public static function allows(\WP_Ability $ability): bool {
        if(!self::$root || !ServerContract::google_bridge($ability))return false;
        $name=$ability->get_name();
        return self::$root['name']===$name && self::$root['user']===get_current_user_id()
            && self::$root['connection']===ConnectionContext::key()
            && (self::$abilities===[] || self::$abilities===[$name]);
    }
}
