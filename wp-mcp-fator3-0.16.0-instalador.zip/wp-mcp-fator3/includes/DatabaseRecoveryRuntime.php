<?php
/** Independent rollback of an interrupted database import. No MCP autoload or persisted DB state. */
declare(strict_types=1);
namespace Fator3\DatabaseRecovery014;
use Fator3\RecoveryV1\Engine;
final class Controller {
    private static function internal(string $name,array $state): bool {
        return isset($state['internal_tables']) ? in_array($name,$state['internal_tables'],true) : str_starts_with($name,$state['internal_prefix']);
    }

    public static function lines(string $path,array $meta): \Generator {
        $file=fopen($path,'rb');if(!$file||fread($file,strlen(Engine::HEADER))!==Engine::HEADER)throw new \RuntimeException('database_backup_invalid');
        $buffer='';$inflate=!empty($meta['gzip'])?inflate_init(ZLIB_ENCODING_GZIP):null;
        try{while(!feof($file)){$raw=fread($file,65536);if($raw===false)throw new \RuntimeException('database_backup_read');$bytes=$inflate?inflate_add($inflate,$raw,feof($file)?ZLIB_FINISH:ZLIB_SYNC_FLUSH):$raw;if($bytes===false)throw new \RuntimeException('database_backup_compression');$buffer.=$bytes;while(($offset=strpos($buffer,"\n"))!==false){yield substr($buffer,0,$offset);$buffer=substr($buffer,$offset+1);}}if($buffer!=='')yield $buffer;}finally{fclose($file);}
    }
    public static function valid(string $path,array $meta): bool {
        $f=fopen($path,'rb');if(!$f)return false;$head=fread($f,strlen(Engine::HEADER));$h=hash_init('sha256');hash_update_stream($h,$f);fclose($f);return $head===Engine::HEADER&&hash_equals($meta['sha256']??'',hash_final($h));
    }
    private static function sql(\mysqli $db,string $sql): void {if($db->query($sql)===false)throw new \RuntimeException('database_recovery_sql',(int)$db->errno);}
    private static function quote(string $name): string {return '`'.str_replace('`','``',$name).'`';}
    /** Keep wp_options continuously available: build its replacement then use atomic RENAME TABLE. */
    public static function apply(\mysqli $db,string $sql,array &$state): void {
        $boot=$state['boot_table'];$prefix=null;$table=null;
        if(preg_match('/^(DROP TABLE IF EXISTS|CREATE TABLE|INSERT INTO)\s+`((?:[^`]|``)+)`/i',$sql,$match)){$prefix=$match[1];$table=str_replace('``','`',$match[2]);}
        if($table===$boot){
            if(str_starts_with($prefix,'DROP')){$state['boot_stage']='f3_recovery_stage_'.substr($state['id'],0,20);self::sql($db,'DROP TABLE IF EXISTS '.self::quote($state['boot_stage']));return;}
            if(empty($state['boot_stage']))throw new \RuntimeException('boot_stage_missing');
            $sql=$prefix.' '.self::quote($state['boot_stage']).substr($sql,strlen($match[0]));self::sql($db,$sql);return;
        }
        self::flush_boot($db,$state);self::sql($db,$sql);
    }
    public static function flush_boot(\mysqli $db,array &$state): void {
        if(empty($state['boot_stage']))return;$stage=$state['boot_stage'];$boot=$state['boot_table'];$old='f3_recovery_old_'.substr($state['id'],0,20);
        $r=$db->query('SELECT COUNT(*) FROM '.self::quote($stage)." WHERE option_name='siteurl'");$ready=$r&&$r->fetch_row()[0]>0;if($r)$r->free();if(!$ready)throw new \RuntimeException('boot_options_incomplete');
        self::sql($db,'DROP TABLE IF EXISTS '.self::quote($old));self::sql($db,'RENAME TABLE '.self::quote($boot).' TO '.self::quote($old).', '.self::quote($stage).' TO '.self::quote($boot));unset($state['boot_stage']);self::sql($db,'DROP TABLE '.self::quote($old));
    }
    public static function restore(string $journal): array {
        $state=Engine::read($journal);if(!$state||empty($state['rollback_artifact_path']))return ['status'=>'recovery_required','reason'=>'rollback_not_prepared'];
        $path=$state['rollback_artifact_path'];$meta=Engine::read($path.'.meta.php');if(!$meta||$meta['format']!=='sql'||!self::valid($path,$meta))return ['status'=>'recovery_required','reason'=>'backup_invalid'];
        $db=null;
        try{
            $c=$state['database_connection'];$db=mysqli_init();mysqli_options($db,MYSQLI_OPT_CONNECT_TIMEOUT,10);
            if(!mysqli_real_connect($db,$c['host'],DB_USER,DB_PASSWORD,DB_NAME,$c['port'],$c['socket'],defined('MYSQL_CLIENT_FLAGS')?MYSQL_CLIENT_FLAGS:0))throw new \RuntimeException('database_recovery_connection');
            $db->set_charset($c['charset']);self::sql($db,"SET SESSION sql_mode='".$db->real_escape_string($c['sql_mode'])."'");self::sql($db,'SET FOREIGN_KEY_CHECKS=0');$state['status']='recovering';unset($state['boot_stage']);Engine::write($journal,$state);
            $r=$db->query('SHOW FULL TABLES');$objects=$r->fetch_all(MYSQLI_NUM);$r->free();
            if(($meta['scope']??'')==='database')foreach($objects as [$name,$type])if(!self::internal($name,$state)&&!isset($meta['tables'][$name]))self::sql($db,($type==='VIEW'?'DROP VIEW ':'DROP TABLE ').self::quote($name));
            foreach(self::lines($path,$meta) as $line){if(!str_starts_with($line,'-- f3-statement:'))continue;$sql=base64_decode(trim(substr($line,strlen('-- f3-statement:'))),true);if($sql===false)throw new \RuntimeException('database_backup_statement');
                if(preg_match('/^(?:DROP TABLE IF EXISTS|CREATE TABLE|INSERT INTO)\s+`((?:[^`]|``)+)`/i',$sql,$hit)&&self::internal(str_replace('``','`',$hit[1]),$state))continue;
                self::apply($db,$sql,$state);
            }
            self::flush_boot($db,$state);
            foreach($state['runtime'] as $table=>$set){self::sql($db,'DELETE FROM '.self::quote($table).' WHERE '.$set['where']);foreach($set['rows'] as $row){unset($row['option_id'],$row['umeta_id']);$columns=implode(',',array_map([self::class,'quote'],array_keys($row)));$values=implode(',',array_map(static fn($v)=>$v===null?'NULL':"CAST(X'".bin2hex((string)$v)."' AS BINARY)",array_values($row)));self::sql($db,'INSERT INTO '.self::quote($table).' ('.$columns.') VALUES ('.$values.')');}}
            self::sql($db,'SET FOREIGN_KEY_CHECKS=1');$state['status']='rolled_back';$state['finished_at']=time();Engine::write($journal,$state);if(function_exists('wp_cache_flush'))wp_cache_flush();return ['status'=>'rolled_back','recovery_id'=>$state['id']];
        }catch(\Throwable $error){$state['status']='recovery_required';$state['recovery_error']=in_array($error->getMessage(),['database_backup_invalid','database_backup_read','database_backup_compression','database_recovery_sql','boot_stage_missing','boot_options_incomplete','database_recovery_connection','database_backup_statement'],true)?$error->getMessage():'database_recovery_failed';$state['mysql_errno']=(int)$error->getCode();$state['recovery_exception']=get_class($error);Engine::write($journal,$state);return ['status'=>'recovery_required','recovery_id'=>$state['id']];}
        finally{if($db){try{$db->close();}catch(\Throwable $ignored){}}}
    }
    /** A live owner holds the journal lease. A dead owner releases it at process exit. */
    public static function sweep(string $directory): void {
        $pending=0;foreach(glob($directory.'/*.php')?:[] as $path){$s=Engine::read($path);if(!$s||!in_array($s['status']??'',['running','recovering','recovery_required'],true))continue;if(++$pending>200)break;
            $lease=fopen($path.'.lease','c+b');if(!$lease||!flock($lease,LOCK_EX|LOCK_NB)){if($lease)fclose($lease);continue;}
            $lock=fopen($s['lock_path'],'c+b');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB)){if($lock)fclose($lock);flock($lease,LOCK_UN);fclose($lease);continue;}
            try{self::restore($path);}finally{flock($lock,LOCK_UN);fclose($lock);flock($lease,LOCK_UN);fclose($lease);}
        }
    }
}
