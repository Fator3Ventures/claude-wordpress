<?php
/** One localized description layer; parameter names always come from the effective schema. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ContractLanguage {
    public static function describe(array $args, string $name): array {
        static $descriptions=null;
        if($descriptions===null)$descriptions=json_decode((string)file_get_contents(__DIR__.'/descriptions-pt_BR.json'),true,512,JSON_THROW_ON_ERROR);
        if(!isset($descriptions[$name]))return $args;
        $params=array_keys($args['input_schema']['properties']??[]);$required=$args['input_schema']['required']??[];
        $args['description']=$descriptions[$name];
        if($params)$args['description'].=' Parâmetros: '.implode(', ',$params).'.';
        if($required)$args['description'].=' Obrigatórios: '.implode(', ',$required).'.';
        return $args;
    }
}
