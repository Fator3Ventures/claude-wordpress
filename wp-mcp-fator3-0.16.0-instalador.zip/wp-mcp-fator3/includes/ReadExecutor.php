<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ReadExecutor {
    public const NAME='wp-mcp-ultimate/execute-readonly-ability';
    public static function register(): void {
        Registry::add(self::NAME,'Execute Readonly Ability. Somente habilidades de leitura de provedores registrados. Mutantes, executores e classificação desconhecida são recusados. A mesma política vale no executor genérico.',['ability_name'=>Registry::string(),'parameters'=>['type'=>['object','string']]],['ability_name','parameters'],[self::class,'execute'],[self::class,'permission']);
    }
    public static function permission($input=[]) {
        if(!current_user_can('edit_posts')||empty(ConnectionContext::get()['readonly_executor']))return new \WP_Error('readonly_executor_disabled','Executor de leitura não habilitado para esta conexão.');
        $ability=wp_get_ability((string)($input['ability_name']??''));
        if(!$ability)return new \WP_Error('ability_not_found','Habilidade não encontrada.');
        if(!AuthorizationPolicy::readonly($ability))return new \WP_Error('ability_not_readonly','Habilidade mutante, executora ou sem classificação confiável.');
        return \WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::check_permission($input);
    }
    public static function execute(array $input): array {
        $permission=self::permission($input);if(is_wp_error($permission))return Result::error($permission);
        return \WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::execute($input);
    }
}
