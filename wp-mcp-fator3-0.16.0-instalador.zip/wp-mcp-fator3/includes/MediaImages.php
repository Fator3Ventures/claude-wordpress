<?php
/** Native derivative generation with complete preimage and observed files. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class MediaImages {
    private static function backup(int $id) {
        $snapshot=DeletionSnapshot::post($id);if(is_wp_error($snapshot))return $snapshot;
        $files=DeletionSnapshot::preserve_files($snapshot);if(is_wp_error($files))return $files;
        $backup=Backups::create_snapshot('media/regenerate',$snapshot);if(is_wp_error($backup))return $backup;
        foreach($files as $file){$meta=Backups::metadata($file,false);$meta['protected_by_backups']=[$backup];StateStore::put('backup-index',$file,$meta);}return $backup;
    }
    private static function file_hashes(int $id): array {
        $meta=wp_get_attachment_metadata($id);$original=get_attached_file($id);$hashes=[];if(!$original)return $hashes;
        foreach($meta['sizes']??[] as $name=>$size){$file=dirname($original).'/'.$size['file'];$hashes[$name]=is_file($file)?hash_file('sha256',$file):null;}ksort($hashes);return $hashes;
    }
    public static function generate(int $id): array {
        if(get_post_type($id)!=='attachment'||!wp_attachment_is_image($id))return Result::fail('attachment_invalid','Selecione uma imagem da biblioteca.');
        require_once ABSPATH.'wp-admin/includes/image.php';$file=get_attached_file($id);
        if(!$file||!is_file($file))return Result::fail('original_missing','Arquivo original indisponível.');
        $editor=wp_get_image_editor($file);if(is_wp_error($editor))return Result::fail('media_editor_unavailable','WordPress não dispõe de editor compatível para gerar esta imagem.',['applied'=>false]);unset($editor);
        $before=wp_get_attachment_metadata($id);$before_files=self::file_hashes($id);$before_hash=hash_file('sha256',$file);$backup=self::backup($id);if(is_wp_error($backup))return Result::error($backup);
        $metadata=wp_generate_attachment_metadata($id,$file);
        if(is_wp_error($metadata)||!is_array($metadata)||!$metadata)return Result::fail('media_generation_failed','Não foi possível completar os derivados.',['backup_id'=>$backup,'applied'=>null]);
        wp_update_attachment_metadata($id,$metadata);$actual=wp_get_attachment_metadata($id);$missing=[];$files=[];$skipped=[];
        $effective=get_attached_file($id);$base=dirname($effective?:$file);$width=(int)($actual['width']??0);$height=(int)($actual['height']??0);
        $expected=apply_filters('intermediate_image_sizes_advanced',wp_get_registered_image_subsizes(),$actual,$id);
        foreach(is_array($expected)?$expected:[] as $name=>$size){
            if(!is_array($size))continue;$resize=image_resize_dimensions($width,$height,(int)($size['width']??0),(int)($size['height']??0),$size['crop']??false);
            if(!$resize){$skipped[$name]='source_too_small_or_no_resize';continue;}
            if(empty($actual['sizes'][$name]))$missing[]=$name;
        }
        foreach($actual['sizes']??[] as $size=>$entry){$path=$base.'/'.$entry['file'];$dimensions=is_file($path)?wp_getimagesize($path):false;
            if(!$dimensions||(int)$entry['width']!==$dimensions[0]||(int)$entry['height']!==$dimensions[1])$missing[]=$size;
            else $files[$size]=['file'=>$entry['file'],'width'=>$dimensions[0],'height'=>$dimensions[1],'bytes'=>filesize($path),'sha256'=>hash_file('sha256',$path)];
        }
        $preserved=is_file($file)&&hash_equals($before_hash,hash_file('sha256',$file));$persisted=$metadata===$actual;
        $data=['id'=>$id,'sizes'=>$files,'missing_sizes'=>array_values(array_unique($missing)),'skipped_sizes'=>$skipped,'metadata'=>$actual,'changed'=>$before!==$actual||$before_files!==self::file_hashes($id),'revision'=>ContentTools::revision($id),'original_preserved'=>$preserved,'backup_id'=>$backup,'persisted'=>$persisted,'applied'=>true];
        return $missing||!$preserved||!$persisted?Result::fail('media_generation_partial','Há divergências nos arquivos/metadados; consulte os tamanhos e a pré-imagem.',$data):Result::ok($data);
    }
    public static function site_icon(array $input): array {
        require_once ABSPATH.'wp-admin/includes/class-wp-site-icon.php';require_once ABSPATH.'wp-admin/includes/image.php';
        $id=(int)$input['id'];$file=get_attached_file($id);$size=$file?wp_getimagesize($file):false;
        if(!wp_attachment_is_image($id)||!$size||$size[0]!==$size[1]||$size[0]<512)return Result::fail('site_icon_dimensions','Ícone exige imagem quadrada de pelo menos 512 × 512.');
        return Locks::run(['option:'.get_current_blog_id().':site_icon'=>LOCK_EX],static function()use($id){
            $icon=new \WP_Site_Icon();$sizes=static function($current)use($icon){$all=$icon->additional_sizes($current);foreach($all as &$size){if(isset($size['width '])&&!isset($size['width'])){$size['width']=$size['width '];unset($size['width ']);}}unset($size);return $all;};add_filter('intermediate_image_sizes_advanced',$sizes);
            try{$r=self::generate($id);}finally{remove_filter('intermediate_image_sizes_advanced',$sizes);remove_action('delete_attachment',[$icon,'delete_attachment_data']);remove_filter('get_post_metadata',[$icon,'get_post_metadata'],10);}
            if(empty($r['success']))return $r;
            $before=(int)get_option('site_icon',0);$backup=Backups::create_snapshot('media/set-site-icon',['site_icon'=>$before,'attachment_backup_id'=>$r['backup_id']]);if(is_wp_error($backup))return Result::error($backup);
            $meta=Backups::metadata($r['backup_id'],false);if(!is_wp_error($meta)){$meta['protected_by_backups']=array_values(array_unique(array_merge($meta['protected_by_backups']??[],[$backup])));StateStore::put('backup-index',$r['backup_id'],$meta);}
            update_option('site_icon',$id);wp_cache_delete('alloptions','options');wp_cache_delete('site_icon','options');$after=(int)get_option('site_icon',0);$urls=[];$missing=[];
            foreach($icon->additional_sizes([]) as $name=>$spec){$url=wp_get_attachment_image_url($id,$name);if(!$url)$missing[]=$name;else $urls[$name]=$url;}
            if($after!==$id||$missing)return Result::fail('site_icon_not_confirmed','Opção ou derivados do ícone não confirmados.',['applied'=>true,'backup_id'=>$backup,'site_icon'=>$after,'missing_sizes'=>$missing,'generation'=>$r]);
            return Result::ok(['id'=>$id,'site_icon'=>$id,'previous_site_icon'=>$before,'urls'=>$urls,'changed'=>$before!==$id||$r['changed'],'persisted'=>true,'revision'=>ContentTools::revision($id),'backup_id'=>$backup,'generation'=>$r]);
        });
    }
}
