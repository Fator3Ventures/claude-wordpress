<?php
/** Exact-object metadata, registered schemas and explicit administrative exceptions. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class MetadataTools {
    public static function register(): void {
        $props=['id'=>Registry::integer(1),'key'=>['type'=>'string','minLength'=>1,'maxLength'=>191],'meta_id'=>Registry::integer(1),'expected_revision'=>Registry::string()];
        Registry::add('content/get-meta','Lê metadados de um post por chave exata e opcional meta_id. Preserva múltiplos valores e IDs; segredos são redigidos. Chaves não registradas exigem exceção administrativa explícita no perfil.',$props,['id','key'],[self::class,'get'],static fn($a)=>self::permission($a,false));
        Registry::add('content/update-meta','Atualiza valor por API WordPress e schema registrado. meta_id seleciona um valor; chave com vários valores exige meta_id. Chave não registrada exige exceção exata no perfil e manage_options. Retorna valor efetivo e revisão final.',$props+['value'=>Result::any_schema()],['id','key','value'],[self::class,'update'],static fn($a)=>self::permission($a,true),false);
        Registry::add('content/delete-meta','Exclui um único meta_id/chave/post com prévia, confirmação e pré-imagem privada. Não aceita prefixos nem classifica chaves como órfãs pelo nome.',$props,['id','key','meta_id'],[self::class,'delete'],static fn($a)=>self::permission($a,true),false);
    }
    private static function registration(int $id,string $key): ?array {
        $all=array_replace(get_registered_meta_keys('post'),get_registered_meta_keys('post',(string)get_post_type($id)));return $all[$key]??null;
    }
    public static function permission(array $input,bool $write) {
        $id=(int)($input['id']??0);$key=(string)($input['key']??'');
        if(!$id||!get_post($id)||!current_user_can($write?'edit_post':'read_post',$id))return new \WP_Error('permission_denied','Sem permissão para o post.');
        if($key===''||strlen($key)>191||preg_match('/[\x00-\x1f*%]/',$key)||DataSafety::secret_key($key)||in_array($key,['_wp_attached_file','_wp_attachment_metadata','_thumbnail_id','_edit_lock','_edit_last'],true))return new \WP_Error('meta_protected','Chave protegida; utilize habilidade específica.');
        $registration=self::registration($id,$key);
        if($registration)return current_user_can('edit_post_meta',$id,$key);
        if(!current_user_can('manage_options')||!in_array($key,(array)(ConnectionContext::get()['meta_keys']??[]),true))return new \WP_Error('meta_unregistered','Chave não registrada. Configure exceção exata no perfil administrativo antes de acessá-la.');
        return true;
    }
    private static function rows(array $input): array {
        global $wpdb;$where='post_id=%d AND meta_key=%s';$params=[(int)$input['id'],$input['key']];
        if(isset($input['meta_id'])){$where.=' AND meta_id=%d';$params[]=(int)$input['meta_id'];}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT meta_id,meta_key,meta_value FROM {$wpdb->postmeta} WHERE {$where} ORDER BY meta_id LIMIT 101",$params),ARRAY_A);
        if($wpdb->last_error)throw new \RuntimeException('Metadata read failed.');return $rows?:[];
    }
    public static function get(array $input): array {
        return Locks::run(['post:'.get_current_blog_id().':'.(int)$input['id']=>LOCK_SH],static function()use($input) {
            $rows=self::rows($input);if(count($rows)>100)return Result::fail('meta_result_limit','Mais de 100 valores; selecione um meta_id.');
            $result=[];foreach($rows as $row) { $value=maybe_unserialize($row['meta_value']);$redacted=is_object($value)||DataSafety::secret_key($row['meta_key']);$safe=$redacted?'[redigido]':self::safe($value);$result[]=['meta_id'=>(int)$row['meta_id'],'key'=>$row['meta_key'],'value'=>$safe,'redacted'=>$redacted||$safe!==$value]; }
            return Result::ok(['id'=>(int)$input['id'],'key'=>$input['key'],'values'=>$result,'revision'=>ContentTools::revision((int)$input['id']),'registered'=>self::registration((int)$input['id'],$input['key'])!==null]);
        });
    }
    private static function safe($value) {
        if(is_object($value))return '[redigido]';if(is_array($value))foreach($value as $key=>&$child)$child=DataSafety::secret_key((string)$key)?'[redigido]':self::safe($child);return $value;
    }
    public static function update(array $input): array {
        $id=(int)$input['id'];$key=$input['key'];$value=$input['value'];$registration=self::registration($id,$key);
        if($registration) {
            $schema=['type'=>$registration['type']??'string'];if(is_array($registration['show_in_rest']??null))$schema=array_replace($schema,$registration['show_in_rest']['schema']??[]);
            $valid=rest_validate_value_from_schema($value,$schema,'value');if(is_wp_error($valid))return Result::error($valid);
        }
        $before=self::rows($input);if(count($before)>1)return Result::fail('meta_ambiguous','Há múltiplos valores; selecione meta_id.');
        if(isset($input['meta_id'])&&!$before)return Result::fail('meta_not_found','meta_id não pertence a este post/chave.');
        if($before&&maybe_unserialize($before[0]['meta_value'])===$value)return self::get($input)+['changed'=>false,'persisted'=>true];
        $backup=Backups::create_snapshot('content/update-meta',['post_id'=>$id,'key'=>$key,'rows'=>$before]);if(is_wp_error($backup))return Result::error($backup);
        if($before){$mid=(int)$before[0]['meta_id'];$ok=update_metadata_by_mid('post',$mid,$value);}
        else {$mid=add_post_meta($id,$key,wp_slash($value),false);$ok=(bool)$mid;}
        clean_post_cache($id);$record=$mid?get_metadata_by_mid('post',(int)$mid):false;
        if(!$ok||!$record)return Result::fail('meta_write_failed','Persistência não confirmada.',['backup_id'=>$backup,'applied'=>null,'persisted'=>false]);
        $result=self::get(['id'=>$id,'key'=>$key,'meta_id'=>(int)$mid]);$result+=['changed'=>true,'persisted'=>true,'backup_id'=>$backup];
        if($record->meta_value!==$value) { unset($result['success']); return Result::fail('meta_filtered','Valor efetivo foi normalizado por filtros.',$result+['normalized'=>true]); }
        return $result;
    }
    public static function delete(array $input): array {
        $before=self::rows($input);if(!$before)return Result::ok(['changed'=>false,'persisted'=>true,'id'=>(int)$input['id'],'meta_id'=>(int)$input['meta_id']]);
        $ok=delete_metadata_by_mid('post',(int)$input['meta_id']);clean_post_cache((int)$input['id']);
        if(!$ok||self::rows($input))return Result::fail('meta_delete_failed','Exclusão não confirmada.',['applied'=>null]);
        return Result::ok(['changed'=>true,'persisted'=>true,'id'=>(int)$input['id'],'meta_id'=>(int)$input['meta_id'],'revision'=>ContentTools::revision((int)$input['id'])]);
    }
}
