<?php
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ResourceMetadata {
	private static ?string $catalog = null;
	private static function canonical($value) {
		if (!is_array($value)) return $value;
		if (!array_is_list($value)) ksort($value);
		foreach ($value as &$child) $child = self::canonical($child);
		return $value;
	}
	public static function fingerprint(): string {
		if (null !== self::$catalog) return self::$catalog;
		$rows = [];
		foreach (wp_get_abilities() as $ability) {
			$meta = $ability->get_meta();
			if (($meta['mcp']['type'] ?? '') !== 'resource') continue;
			$rows[$ability->get_name()] = ['meta'=>$meta, 'label'=>$ability->get_label(), 'description'=>$ability->get_description()];
		}
		return self::$catalog = hash('sha256', serialize(self::canonical($rows)));
	}
	public static function log_once(string $ability, string $code, callable $logger): void {
		try {
			$key = self::fingerprint() . ':' . $ability . ':' . $code;
			if (Persistence::put('resource-diagnostics', $key, ['ability'=>$ability,'code'=>$code,'catalog_sha256'=>self::fingerprint(),'time'=>time()], true)) $logger();
		} catch (\Throwable $error) { /* A failed marker must not turn into request log flooding. */ }
	}
	public static function uri(array $meta) {
		$uri = $meta['mcp']['uri'] ?? $meta['uri'] ?? null;
		if (!is_string($uri) || '' === trim($uri)) return new \WP_Error('resource_uri_not_found', 'Resource URI absent in meta.mcp.uri and meta.uri.');
		$uri = trim($uri);
		if (strlen($uri)>4096 || !preg_match('~^[a-z][a-z0-9+.-]*:[^\x00-\x20\x7f]+$~iD', $uri)) return new \WP_Error('resource_uri_invalid', 'Resource URI has an invalid scheme or characters.');
		return $uri;
	}
	public static function mime(array $meta) {
		$mime = $meta['mcp']['mimeType'] ?? $meta['mimeType'] ?? null;
		if (null === $mime) return null;
		if (!is_string($mime) || !preg_match('~^[a-zA-Z0-9!#$&^_.+-]+/[a-zA-Z0-9!#$&^_.+-]+(?:;[\x20-\x7e]*)?$~D', $mime)) return new \WP_Error('resource_mime_invalid', 'Resource MIME type is invalid.');
		return $mime;
	}
}
