<?php
/** Portable exports assembled on disk; no whole archive is loaded into PHP memory. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;
final class BackupExport {
    public static function source(string $id) {
        $meta=Backups::metadata($id,false);if(is_wp_error($meta))return $meta;
        $original=StateStore::path('backups',$id);
        if(empty($meta['legacy'])&&($meta['ability']??'')!=='recovery')return ['path'=>$original,'skip'=>strlen(StateStore::HEADER),'meta'=>$meta];
        $legacy=!empty($meta['legacy']);$entries=[];$identity='';
        if($legacy){
            $identity=hash_file('sha256',WP_CONTENT_DIR.'/f3-mcp-backups/'.$id.'.json');
            if($meta['kind']==='file'){
                $file=WP_CONTENT_DIR.'/f3-mcp-backups/'.$id.'.bak';
                if(!is_file($file)||is_link($file)||!hash_equals($meta['sha256']??'',hash_file('sha256',$file)))return new \WP_Error('backup_corrupt','Par legado ausente ou alterado.');
                $entries['']=$file;$identity.=':'.$meta['sha256'];
            }
        }else{
            $meta=Backups::metadata($id);if(is_wp_error($meta))return $meta;
            $journal=$meta['snapshot']['journal_id']??'';
            if(!preg_match('/^[a-f0-9]{32}$/D',$journal))return new \WP_Error('backup_corrupt','Referência de recuperação inválida.');
            $state=Engine::read(Recovery::directory().'/'.$journal.'.journal.php');
            if(!$state)return new \WP_Error('backup_corrupt','Diário autenticado indisponível.');
            $manifest=Engine::manifest($state['preimage']);
            if(!$manifest||Engine::digest($manifest)!==$state['before_sha256'])return new \WP_Error('backup_corrupt','Pré-imagem não confere.');
            $meta['portable_tree']=['format'=>'fator3-tree-base64-v1','manifest'=>$manifest];
            foreach($manifest['files'] as $path=>$info)if(empty($info['directory']))$entries[$path]=$manifest['kind']==='file'?$state['preimage']:$state['preimage'].'/'.$path;
            $identity=$state['before_sha256'];
        }
        $destination=StateStore::directory('backup-exports').'/'.$id.'-'.hash('sha256',$identity).'.php';
        if(is_file($destination))return ['path'=>$destination,'skip'=>strlen(StateStore::HEADER),'meta'=>$meta];
        $temp=$destination.'.'.bin2hex(random_bytes(8)).'.tmp';$out=fopen($temp,'xb');if(!$out)return new \WP_Error('backup_export_failed','Exportação privada indisponível.');chmod($temp,0600);
        try{
            unset($meta['_storage'],$meta['content_base64']);$json=json_encode($meta,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES);
            self::write($out,StateStore::HEADER.substr($json,0,-1));
            if($legacy&&$meta['kind']==='file'){
                self::write($out,',"content_base64":"');self::base64($out,$entries['']);self::write($out,'"');
            }elseif(!$legacy){
                self::write($out,',"tree_files_base64":{');$first=true;
                foreach($entries as $name=>$file){self::write($out,($first?'':',').json_encode($name,JSON_THROW_ON_ERROR).':"');self::base64($out,$file);self::write($out,'"');$first=false;}self::write($out,'}');
            }
            self::write($out,'}');if(!fflush($out))throw new \RuntimeException('Export flush failed.');if(function_exists('fsync')&&!fsync($out))throw new \RuntimeException('Export sync failed.');fclose($out);$out=null;
            if(!rename($temp,$destination))throw new \RuntimeException('Export commit failed.');
            return ['path'=>$destination,'skip'=>strlen(StateStore::HEADER),'meta'=>$meta];
        }catch(\Throwable $e){@unlink($temp);return new \WP_Error('backup_export_failed','Exportação incompleta; originais preservados.');}
        finally{if(is_resource($out))fclose($out);}
    }
    private static function write($handle,string $bytes): void {
        $i=0;while($i<strlen($bytes)){$n=fwrite($handle,substr($bytes,$i));if(!$n)throw new \RuntimeException('Incomplete export.');$i+=$n;}
    }
    private static function base64($out,string $file): void {
        $h=fopen($file,'rb');if(!$h)throw new \RuntimeException('Missing source.');$before=fstat($h);$carry='';
        try{while(!feof($h)){$bytes=fread($h,196608);if($bytes===false)throw new \RuntimeException('Source read failed.');$bytes=$carry.$bytes;$n=intdiv(strlen($bytes),3)*3;self::write($out,base64_encode(substr($bytes,0,$n)));$carry=substr($bytes,$n);}if($carry!=='')self::write($out,base64_encode($carry));
            $keys=array_flip(['dev','ino','size','mtime','ctime']);if(array_intersect_key($before,$keys)!==array_intersect_key(fstat($h),$keys))throw new \RuntimeException('Source changed.');
        }finally{fclose($h);}
    }
}
