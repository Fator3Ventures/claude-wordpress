<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SchemaTools {
    public static function read(array $input): array {
        global $wpdb;
        return DatabaseBudget::run('SELECT 1',static function()use($input,$wpdb) {
            $name=$input['table']??null;
            if($name!==null&&(!is_string($name)||!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D',$name)||!str_starts_with($name,$wpdb->prefix)))return Result::fail('table_invalid','Nome de tabela inválido ou fora deste site.');
            $where='TABLE_SCHEMA=DATABASE() AND TABLE_TYPE=\'BASE TABLE\' AND TABLE_NAME LIKE %s';$params=[$wpdb->esc_like($wpdb->prefix).'%'];
            if($name!==null) { $where.=' AND TABLE_NAME=%s';$params[]=$name; }
            $limit=max(1,min(100,(int)($input['per_page']??100)));$offset=max(0,(int)($input['offset']??0));$params[]=$limit+1;$params[]=$offset;
            $rows=$wpdb->get_results($wpdb->prepare("SELECT TABLE_NAME,ENGINE,TABLE_ROWS,DATA_LENGTH FROM information_schema.TABLES WHERE {$where} ORDER BY TABLE_NAME LIMIT %d OFFSET %d",$params),ARRAY_A);
            if($wpdb->last_error)return Result::fail('schema_read_failed','Não foi possível ler o catálogo físico.');
            if($name!==null&&!$rows)return Result::fail('table_not_found','Tabela não encontrada.');
            $more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);$tables=[];$complete=true;$deadline=microtime(true)+10;
            foreach($rows as $row) {
                $table=$row['TABLE_NAME'];$item=['name'=>$table,'rows'=>(int)$row['TABLE_ROWS'],'rows_estimate'=>(int)$row['TABLE_ROWS'],'engine'=>$row['ENGINE'],'data_size'=>size_format((int)$row['DATA_LENGTH'])];
                if(!empty($input['exact'])) {
                    $item['rows_exact']=null;
                    if(microtime(true)>$deadline) { $item['count_error']='count_budget_exceeded';$complete=false; }
                    else {
                        $n=$wpdb->get_var("SELECT /*+ MAX_EXECUTION_TIME(2000) */ COUNT(*) FROM `{$table}`");
                        if($wpdb->last_error||$n===null) { $item['count_error']='count_inconclusive';$complete=false; }else $item['rows_exact']=(int)$n;
                    }
                }
                $tables[]=$item;
            }
            $columns=$name!==null?$wpdb->get_results("DESCRIBE `{$name}`",ARRAY_A):[];
            if($wpdb->last_error)return Result::fail('schema_read_failed','Colunas não puderam ser verificadas.');
            return Result::ok(['prefix'=>$wpdb->prefix,'tables'=>$tables,'columns'=>$columns,'count_complete'=>$complete,'count_scope'=>'independent_statements','has_more'=>$more,'next_offset'=>$more?$offset+count($tables):null]);
        });
    }
}
