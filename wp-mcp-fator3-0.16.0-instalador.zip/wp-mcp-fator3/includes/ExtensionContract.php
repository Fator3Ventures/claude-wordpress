<?php
/** Explicit opt-in SDK. Registration does not grant WordPress capabilities. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ExtensionContract {
    public const POLICY_VERSION=1;
    public static function init(): void {
        add_action('plugins_loaded',static function(){do_action('f3_mcp_register_providers',self::POLICY_VERSION);},5);
    }
    public static function register(string $id,string $version,array $prefixes) {
        if(!preg_match('/^[a-z0-9][a-z0-9-]{1,100}$/D',$id)||!preg_match('/^[0-9][A-Za-z0-9.+-]{0,63}$/D',$version)||!$prefixes)return new \WP_Error('provider_invalid','Identidade, versão e prefixos explícitos são necessários.');
        foreach($prefixes as $prefix)if(!is_string($prefix)||!preg_match('~^[a-z0-9-]+/$~D',$prefix))return new \WP_Error('provider_invalid','Prefixos devem terminar em /.');
        foreach(Providers::all() as $existing)if($existing['id']!==$id&&array_intersect($prefixes,$existing['prefixes']))return new \WP_Error('provider_prefix_conflict','Prefixo já pertence a outro provedor.');
        if(Providers::known($id))return new \WP_Error('provider_already_registered','Registro de provedor já existe neste request.');
        Providers::register($id,$version,$prefixes);return true;
    }
    public static function adheres(string $name,array $meta): bool {
        if(($meta['policy_contract']??0)!==self::POLICY_VERSION)return false;
        $registered=Providers::metadata($name);
        return $registered['provider']!=='unknown'&&($meta['provider']??'')===$registered['provider']&&($meta['version']??'')===$registered['version'];
    }
}
