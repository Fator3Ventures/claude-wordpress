<?php
/** Native MySQL read execution, preserving SQL and original column metadata. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class DatabaseRead {
    public static function validate(string $sql) {
        if(!ConnectionContext::maintenance())return SqlGuard::validate_select($sql);
        if(strlen($sql)>1048576||str_contains($sql,"\0"))return new \WP_Error('sql_size_limit','SQL supera 1 MiB ou contém NUL.');
        $scan=SqlGuard::scan($sql);if($scan['error']||$scan['statements']!==1)return new \WP_Error('sql_single_statement','Envie uma única instrução SQL completa.');
        $sql=$scan['sql'];$mask=SqlGuard::mask($sql);$top=SqlGuard::mask($sql,true);$verb=SqlGuard::verb($sql);
        if(!in_array($verb,['select','with','show','describe','desc','explain'],true))return new \WP_Error('sql_read_only','Esta rota aceita somente leitura.');
        if($verb==='with'&&!preg_match('/\bSELECT\b/i',$top))return new \WP_Error('sql_read_only','WITH deve terminar em SELECT.');
        if(preg_match('/\b(?:insert|update|delete|create|alter|drop|truncate|rename|call|execute|prepare|outfile|dumpfile|into|procedure|load_file|load|sys_exec|get_lock|release_lock|sleep|benchmark)\b|@|:=/i',$mask))return new \WP_Error('sql_read_only','Construção com efeito colateral não é leitura.');
        preg_match_all('/\b(?:from|join)\s+`?([\w]+)`?\s*\./i',$mask,$matches);foreach($matches[1] as $schema)if(!in_array(strtolower($schema),[strtolower(DB_NAME),'information_schema'],true))return new \WP_Error('sql_database_scope','Fonte externa ao banco do site.');
        return $sql;
    }
    public static function connection(): \mysqli {
        global $wpdb;
        $host=DB_HOST;$port=3306;$socket=null;
        if(method_exists($wpdb,'parse_db_host')){$parsed=$wpdb->parse_db_host(DB_HOST);if($parsed){[$host,$port,$socket]=$parsed;$port=$port?:3306;}}
        $db=mysqli_init();mysqli_options($db,MYSQLI_OPT_CONNECT_TIMEOUT,10);
        if(!@mysqli_real_connect($db,$host,DB_USER,DB_PASSWORD,DB_NAME,(int)$port,$socket,defined('MYSQL_CLIENT_FLAGS')?MYSQL_CLIENT_FLAGS:0))throw new \RuntimeException('database_connection_failed');
        $db->set_charset($wpdb->charset?:'utf8mb4');
        $mode=$wpdb->get_var('SELECT @@SESSION.sql_mode');$db->query("SET SESSION sql_mode='".$db->real_escape_string((string)$mode)."'");
        return $db;
    }
    public static function seconds(array $i): int {$server=(int)ini_get('max_execution_time');$max=$server>0?max(1,$server-2):3600;return max(1,min($max,(int)($i['timeout_seconds']??30)));}
    public static function checked(\mysqli $db,string $sql) {
        $r=$db->query($sql);if($r===false)throw new \RuntimeException('sql_execution_failed',$db->errno);return $r;
    }
    /** Origin metadata survives aliases. Exact single-table key predicates disambiguate value-only projections. */
    public static function redact(array $row,array $fields,string $sql): array {
        $keys=[];$safe=[];$redacted=[];
        foreach($fields as $f)if(in_array($f->orgname,['option_name','meta_key'],true))$keys[$f->orgtable]=(string)($row[$f->name]??'');
        $exact=null;
        // Only a direct, unaliased source and one exact key predicate prove every value's key.
        $projection='(?:`?[A-Za-z0-9_]+`?(?:\\s+AS\\s+`?[A-Za-z0-9_]+`?)?)(?:\\s*,\\s*`?[A-Za-z0-9_]+`?(?:\\s+AS\\s+`?[A-Za-z0-9_]+`?)?)*';
        if(preg_match("/^SELECT\\s+".$projection."\\s+FROM\\s+`?[A-Za-z0-9_]+`?\\s+WHERE\\s+`?(?:meta_key|option_name)`?\\s*=\\s*'([A-Za-z0-9_.:-]+)'(?:\\s+LIMIT\\s+\\d+)?$/iD",trim($sql),$m))$exact=$m[1];
        foreach($fields as $f){$name=$f->name;$origin=$f->orgname?:$name;$v=$row[$name]??null;$key=$keys[$f->orgtable]??$exact;$reason=null;
            if(DataSafety::secret_key($origin)||DataSafety::secret_key($name))$reason='sensitive_column';
            elseif(in_array($origin,['meta_value','option_value'],true)){if($key===null)$reason='key_origin_unknown';elseif(DataSafety::secret_key($key))$reason='sensitive_key';}
            if(apply_filters('f3_mcp_sensitive_cell',false,$f->orgtable,$origin,$key??''))$reason='provider_sensitive';
            if($reason){$v='[redigido]';$redacted[]=['column'=>$name,'reason'=>$reason,'origin'=>$origin];}
            $safe[$name]=$v;
        }
        return ['row'=>$safe,'redacted'=>$redacted];
    }
    public static function query(array $i): array {
        if(!PathGuard::is_enabled()||!current_user_can('manage_options'))return Result::fail('permission_denied','Canal fechado ou permissão ausente.');
        $sql=self::validate((string)$i['sql']);if(is_wp_error($sql))return Result::error($sql);
        $limit=max(1,min(2000,(int)($i['limit']??200)));$db=null;
        try{
            $db=self::connection();self::checked($db,'SET SESSION max_execution_time='.(self::seconds($i)*1000));self::checked($db,'START TRANSACTION READ ONLY');
            $q=SqlGuard::enforce_limit($sql,$limit+1);
            $result=$db->query($q,MYSQLI_USE_RESULT);if(!$result instanceof \mysqli_result)throw new \RuntimeException('sql_result_missing');
            $fields=$result->fetch_fields();$rows=[];$redacted=[];$bytes=0;$more=false;
            while($row=$result->fetch_assoc()){if(count($rows)>=$limit){$more=true;break;}$shown=self::redact($row,$fields,$sql);$idx=count($rows);foreach($shown['redacted'] as $v)$redacted[]=['row'=>$idx]+$v;$transport=DatabaseWriter::transport_rows([$shown['row']])[0];$bytes+=strlen(serialize($transport));if($bytes>16777216){$result->free();return Result::fail('query_byte_limit','Use db/query-export para resultado maior que 16 MiB.');}$rows[]=$transport;}
            $result->free();$db->commit();return Result::ok(['rows'=>$rows,'row_count'=>count($rows),'has_more'=>$more,'redacted'=>$redacted,'timeout_seconds'=>self::seconds($i),'sql_sha256'=>hash('sha256',$sql)]);
        }catch(\Throwable $e){return Result::fail('sql_read_failed','O MySQL recusou ou interrompeu a consulta. SQL e valores não são registrados.',['mysql_errno'=>(int)$e->getCode()?:($db?$db->errno:0),'retryable'=>false]);}
        finally{if($db){try{$db->rollback();$db->close();}catch(\Throwable $ignore){}}}
    }
}
