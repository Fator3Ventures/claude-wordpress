<?php
/** Public, local integration SDK. Does not initialize the registry or authorize callers. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ServerContract {
    public const CONTRACT = 'server-integration/1.0.0';
    private static array $errors = [];
    public static function failure(string $code): void { self::$errors[] = $code; }
    public static function identity(): array {
        return ['contract'=>self::CONTRACT,'provider'=>'wp-mcp-fator3','server_id'=>'wp-mcp-ultimate-server',
            'route'=>ConnectionEndpoints::PRIMARY,'aliases'=>[ConnectionEndpoints::LEGACY]];
    }
    public static function enabled(): bool {
        return true === apply_filters('f3_mcp_create_default_server', true, self::identity());
    }
    public static function capabilities(): array {
        return self::identity()+['version'=>F3_MCP_FILES_VERSION,'configuration_hook'=>'f3_mcp_default_server_config',
            'configuration_hook_available'=>true,'policy_contract'=>1,'contributions'=>['tools','resources','prompts']];
    }
    public static function status(): array {
        $s=ConnectionStatus::snapshot(false);
        return self::identity()+array_intersect_key($s,array_flip(['core_loaded','server_enabled','registry_checked',
            'server_registered','tools_ready','endpoints','external_connectivity_tested']))+
            ['channel_enabled'=>PathGuard::is_enabled(),'errors'=>array_values(array_unique(array_merge($s['errors'],self::$errors)))];
    }
    public static function google_bridge(\WP_Ability $ability): bool {
        $name=$ability->get_name();$meta=$ability->get_meta();$f=$meta['fator3']??[];
        return in_array($name,['google/mcp-read','google/mcp-write'],true)
            && ($f['provider']??'')==='wp-mcp-google-fator3' && ExtensionContract::adheres($name,$f)
            && !empty($f['executes_ability']) && !empty($meta['mcp']['public'])
            && ($f['mode']??'')===(str_ends_with($name,'-read')?'read':'write')
            && (bool)($meta['annotations']['readonly']??false)===str_ends_with($name,'-read');
    }
    public static function configure(array $defaults,bool $resolve): array {
        // Early endpoint queries must not trigger Abilities API initialization or filter callbacks.
        if(!$resolve || !did_action('wp_abilities_api_init') || doing_action('wp_abilities_api_init'))return $defaults;
        $registered=wp_get_abilities();
        foreach(['google/mcp-read','google/mcp-write'] as $name){
            $ability=$registered[$name]??null;
            if($ability && self::google_bridge($ability))$defaults['tools'][]=$name;
        }
        try {$candidate=apply_filters('f3_mcp_default_server_config',$defaults,self::identity());}
        catch(\Throwable $e){self::$errors[]='server_config_callback_failed';return $defaults;}
        if(!is_array($candidate)){self::$errors[]='server_config_invalid';return $defaults;}
        $result=$defaults;
        foreach(['tools'=>'tool','resources'=>'resource','prompts'=>'prompt'] as $key=>$type){
            if(!isset($candidate[$key]) || !is_array($candidate[$key]) || !array_is_list($candidate[$key])){self::$errors[]='server_config_invalid';return $defaults;}
            foreach($candidate[$key] as $name){
                if(!is_string($name)){self::$errors[]='server_config_invalid';return $defaults;}
                if(in_array($name,$defaults[$key],true))continue;
                $ability=$registered[$name]??null;$meta=$ability?$ability->get_meta():[];
                if(!$ability || empty($meta['mcp']['public']) || ($meta['mcp']['type']??'tool')!==$type
                    || !ExtensionContract::adheres($name,$meta['fator3']??[])){
                    self::$errors[]='server_contribution_invalid';return $defaults;
                }
                $result[$key][]=$name;
            }
            $result[$key]=array_values(array_unique($result[$key]));
        }
        foreach($candidate as $key=>$value)if(!in_array($key,['tools','resources','prompts'],true) && (!array_key_exists($key,$defaults)||$value!==$defaults[$key])){
            self::$errors[]='server_identity_immutable';return $defaults;
        }
        return $result;
    }
}
