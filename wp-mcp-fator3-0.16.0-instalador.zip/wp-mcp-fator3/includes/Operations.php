<?php
/** Persistent, bounded deployment plans. No distributed transaction is promised. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Operations {
	private const ALLOWED = ['files/write','files/patch','files/delete','files/fetch','files/restore','files/mkdir','files/move','files/copy','content/create-post','content/create-page','content/update-post','content/update-page','content/patch-post','content/patch-page','content/upsert','content/untrash','content/restore-revision','content/edit-block','options/update','themes/install','themes/activate','plugins/install','plugins/update','plugins/activate','plugins/deactivate','plugins/upload','plugins/upload-base64','plugins/rollback','system/probe','content/get-post','content/get-page','files/stat','operations/assert'];
	public static function register(): void {
        self::extra_routes();
		$step = ['type' => 'object', 'properties' => ['id' => ['type' => 'string', 'pattern' => '^[a-zA-Z0-9_-]{1,64}$'], 'ability' => ['type' => 'string', 'enum' => self::ALLOWED], 'parameters' => ['type' => 'object'], 'depends_on' => ['type' => 'array', 'items' => Registry::string(), 'maxItems' => 50]], 'required' => ['id','ability','parameters'], 'additionalProperties' => false];
		Registry::add('operations/plan', 'Validate and store an ordered deployment plan without executing steps. References use {"$ref":"step_id.field.subfield"} and require an earlier dependency. Plans expire after 24h before starting. Compensation is best effort and limited to explicitly reversible results.', ['steps' => ['type' => 'array', 'items' => $step, 'minItems' => 1, 'maxItems' => 50], 'on_failure' => ['type' => 'string', 'enum' => ['stop','compensate'], 'default' => 'stop']], ['steps'], [self::class, 'plan'], 'edit_posts', false);
		Registry::add('operations/apply', 'Execute up to max_steps of a saved plan, storing each result and reusing per-step idempotency keys. Resume the same plan ID after a partial response. An uncertain step is never blindly repeated.', ['plan_id' => Registry::string(), 'max_steps' => Registry::integer(1, 20)], ['plan_id'], [self::class, 'apply'], 'edit_posts', false);
		Registry::add('operations/status', 'Read a plan and step results owned by the authenticated user. A plan is not a global atomic transaction.', ['plan_id' => Registry::string()], ['plan_id'], [self::class, 'status'], 'edit_posts');
	}
    public static function extra_routes(): void {
        Registry::add('operations/list','Lista planos desta conexão com resumo, status e cursor. Não expõe parâmetros sensíveis.',['cursor'=>Registry::string(),'per_page'=>Registry::integer(1,100),'status'=>Registry::string()],[],[self::class,'listing'],'edit_posts');
        Registry::add('operations/preview','Exibe permissões, alvos e pré-condições sem executar callbacks mutantes. Referências a resultados futuros ficam pendentes. Persiste um identificador de prévia; apply recusa alvos alterados desde a prévia.',['plan_id'=>Registry::string()],['plan_id'],[self::class,'preview'],'edit_posts',false);
        Registry::add('operations/cancel','Solicita cancelamento sem aguardar o lock longo. Etapa em execução pode terminar; impede as seguintes. Não desfaz efeitos anteriores.',['plan_id'=>Registry::string()],['plan_id'],[self::class,'cancel'],'edit_posts',false);
        Registry::add('operations/assert','Compara um valor com expected por igualdade estrita. Pode receber resultado de passo anterior via referência do plano. Não produz efeitos.',['actual'=>Result::any_schema(),'expected'=>Result::any_schema()],['actual','expected'],static fn($a)=>$a['actual']===$a['expected']?Result::ok(['matched'=>true]):Result::fail('assertion_failed','Resultado não corresponde à asserção.'),'edit_posts');
    }

	private static function references($value, array $allowed): bool {
		if (!is_array($value)) return false;
		$found = false;
		if (isset($value['$ref'])) {
			if (count($value) !== 1 || !is_string($value['$ref']) || !preg_match('/^([a-zA-Z0-9_-]+)\.([a-zA-Z0-9_.-]+)$/D', $value['$ref'], $m) || !in_array($m[1], $allowed, true)) throw new \RuntimeException('A reference must name an earlier explicit dependency and a result field.');
			return true;
		}
		foreach ($value as $child) $found = self::references($child, $allowed) || $found;
		return $found;
	}
	private static function resolve($value, array $results) {
		if (!is_array($value)) return $value;
		if (isset($value['$ref'])) {
			$parts = explode('.', $value['$ref']); $id = array_shift($parts); $data = $results[$id] ?? null;
			foreach ($parts as $part) { if (!is_array($data) || !array_key_exists($part, $data)) throw new \RuntimeException('Reference not found: ' . $value['$ref']); $data = $data[$part]; }
			return $data;
		}
		foreach ($value as &$child) $child = self::resolve($child, $results); unset($child); return $value;
	}
	public static function plan(array $input): array {
		if (strlen(serialize($input)) > 4194304) return Result::fail('plan_size_limit', 'Plan exceeds 4 MiB.');
		$seen = []; $steps = [];
		try { foreach ($input['steps'] as $step) {
			if (isset($seen[$step['id']])) return Result::fail('plan_duplicate_id', 'Step IDs must be unique.');
			$deps = $step['depends_on'] ?? [];
			foreach ($deps as $dep) if (!isset($seen[$dep])) return Result::fail('plan_dependency_invalid', 'Dependencies must occur before their dependent step.');
			if (!in_array($step['ability'], self::ALLOWED, true)) return Result::fail('plan_ability_forbidden', 'Ability is not supported in resumable plans.');
			$ability = wp_get_ability($step['ability']); if (!$ability) return Result::fail('ability_not_found', $step['ability']);
			$meta = $ability->get_meta(); if (AuthorizationPolicy::executor($ability)) return Result::fail('executor_target_forbidden','Executores não são alvos de planos.'); if (empty($meta['mcp']['public'])) return Result::fail('ability_not_public', 'The requested ability is not publicly exposed.');
			$refs = self::references($step['parameters'], $deps);
			if (!$refs) { $valid = rest_validate_value_from_schema($step['parameters'], $ability->get_input_schema(), 'parameters'); if (is_wp_error($valid)) return Result::error($valid); $permission = $ability->check_permissions($step['parameters']); if (is_wp_error($permission) || !$permission) return Result::fail('permission_denied', 'Permission denied for plan step: ' . $step['id']); }
			unset($step['parameters']['idempotency_key']);
			$steps[] = $step + ['depends_on' => $deps, 'status' => 'pending', 'schema_hash' => hash('sha256', serialize($ability->get_input_schema())), 'validation' => $refs ? 'deferred_until_references_resolve' : 'validated']; $seen[$step['id']] = true;
		} } catch (\Throwable $e) { return Result::fail('plan_reference_invalid', $e->getMessage()); }
		$id = bin2hex(random_bytes(16));
		$state = ['plan_id' => $id, 'owner' => get_current_user_id(), 'connection_id'=>ConnectionContext::key(), 'blog' => get_current_blog_id(), 'time' => time(), 'expires' => time() + DAY_IN_SECONDS, 'status' => 'pending', 'steps' => $steps, 'on_failure' => $input['on_failure'] ?? 'stop', 'version' => F3_MCP_FILES_VERSION];
		StateStore::put('plans', $id, $state);
		return Result::ok(['plan_id' => $id, 'status' => 'pending', 'steps' => count($steps), 'expires_at' => gmdate('c', $state['expires']), 'atomic' => false]);
	}
	private static function get(string $id) {
		if (!preg_match('/^[a-f0-9]{32}$/D', $id)) return new \WP_Error('plan_invalid', 'Invalid plan identifier.');
		$state = StateStore::get('plans', $id);
		if (!$state || $state['owner'] !== get_current_user_id() || $state['blog'] !== get_current_blog_id() || ($state['connection_id']??'')!==ConnectionContext::key()) return new \WP_Error('plan_not_found', 'Plan not found for this user and site.');
		return $state;
	}
	public static function status(array $input): array {
		$state = self::get($input['plan_id']); if (is_wp_error($state)) return Result::error($state);
		foreach ($state['steps'] as &$step) {
            $ability=wp_get_ability($step['ability']);
            if(!$ability||is_wp_error(AuthorizationPolicy::check($step['ability'],[],!empty($ability->get_meta()['annotations']['readonly']),true)))unset($step['result']);
            unset($step['parameters'], $step['schema_hash']);
        } unset($step,$state['_storage']);
        if(StateStore::get('plan-cancel',$state['plan_id'])&&!in_array($state['status'],['complete','cancelled','compensated'],true))$state['cancellation']='cancel_requested';
		return Result::ok(['plan' => $state, 'atomic' => false]);
	}
	public static function apply(array $input): array {
		$id = $input['plan_id'];
		return Locks::run(['plan:' . get_current_blog_id() . ':' . $id => LOCK_EX], static function () use ($id, $input) {
			$state = self::get($id); if (is_wp_error($state)) return Result::error($state);
			if (in_array($state['status'],['complete','cancelled'],true)) return self::status(['plan_id' => $id]);
			if ('compensated' === $state['status'] || 'compensation_incomplete' === $state['status']) return Result::fail('plan_closed', 'This failed plan has entered compensation and cannot be reapplied.', ['plan_id' => $id]);
			if ('pending' === $state['status'] && $state['expires'] < time()) return Result::fail('plan_expired', 'Plan expired before execution. Create a new plan.');
			$done = 0; $results = []; $start = microtime(true); $max = max(1, min(20, (int)($input['max_steps'] ?? 5)));
			$state['status'] = 'running'; StateStore::put('plans', $id, $state);
			foreach ($state['steps'] as $index => &$step) {
				if ('complete' === $step['status']) { $results[$step['id']] = $step['result']; continue; }
				if (StateStore::get('plan-cancel',$id)) { $state['status']='cancelled'; break; }
                if ($done >= $max || microtime(true) - $start > 15) break;
				if ('failed' === $step['status'] && empty($step['result']['retryable'])) { $state['status'] = 'failed'; break; }
				try {
					$ability = wp_get_ability($step['ability']);
					if (!$ability || !hash_equals($step['schema_hash'], hash('sha256', serialize($ability->get_input_schema())))) { $result = Result::fail('plan_schema_changed', 'Ability schema changed. Review and create a new plan.'); }
					else {
						$args = self::resolve($step['parameters'], $results);
                        if(isset($ability->get_input_schema()['properties']['idempotency_key']))$args['idempotency_key']='plan:'.$id.':'.$step['id'];
                        if(isset($step['preconditions'])) {
                            $actual=self::conditions($step['ability'],$args);
                            if($actual!==$step['preconditions'])throw new \DomainException('preview_conflict');
                            if(isset($actual['sha256'])&&isset($ability->get_input_schema()['properties']['expected_sha256'])&&!isset($args['expected_sha256']))$args['expected_sha256']=$actual['sha256'];
                            if(isset($actual['revision'])&&isset($ability->get_input_schema()['properties']['expected_revision'])&&!isset($args['expected_revision']))$args['expected_revision']=$actual['revision'];
                        }
						$step['status'] = 'running'; StateStore::put('plans', $id, $state);
						$result = Result::normalize($ability->execute($args));
					}
				} catch (\Throwable $e) { $result = Result::fail($e instanceof \DomainException?'plan_preview_conflict':'plan_step_exception','Etapa não concluída; reveja prévia e resultado.',['conflict'=>$e instanceof \DomainException]); }
				if(!empty($result['backup_id']))Backups::reference($result['backup_id'],$id);
                $step['result'] = $result; $step['status'] = false === ($result['success'] ?? true) ? 'failed' : 'complete'; $done++;
				if ('failed' === $step['status']) { $state['status'] = 'failed'; StateStore::put('plans', $id, $state); break; }
				$results[$step['id']] = $result; StateStore::put('plans', $id, $state);
                if(StateStore::get('plan-cancel',$id)){$state['status']='cancelled';break;}
			} unset($step);
			if ('failed' === $state['status'] && 'compensate' === $state['on_failure']) $state = self::compensate($state);
			elseif (!in_array($state['status'],['failed','cancelled'],true)) $state['status'] = count(array_filter($state['steps'], static fn($s) => 'complete' !== $s['status'])) ? 'paused' : 'complete';
			StateStore::put('plans', $id, $state);
			$response = self::status(['plan_id' => $id]);
			if (in_array($state['status'], ['failed','compensated','compensation_incomplete'], true)) return Result::fail('plan_step_failed', 'A plan step failed. Inspect per-step results before continuing.', ['plan' => $response['plan'], 'atomic' => false]);
			return $response;
		});
	}
	private static function compensate(array $state): array {
		$complete = true;
		foreach ($state['steps'] as $failed) if ('failed' === $failed['status'] && !in_array($failed['result']['error_code'] ?? '', ['file_not_found','file_conflict','content_conflict','resource_busy','permission_denied','ability_invalid_input','destination_exists','invalid_hash','plan_schema_changed'], true) && false !== ($failed['result']['applied'] ?? null)) $complete = false;
		for ($i = count($state['steps']) - 1; $i >= 0; $i--) {
			$step = &$state['steps'][$i]; if ('complete' !== $step['status']) continue;
			$r = $step['result']; $ability = ''; $args = [];
			if (!empty($r['backup_id']) && isset($r['sha256']) && in_array($step['ability'], ['files/write','files/patch','files/fetch','files/copy','files/restore'], true)) { $ability = 'files/restore'; $args = ['backup_id' => $r['backup_id'], 'expected_sha256' => $r['sha256']]; }
			elseif (!empty($r['backup_id']) && in_array($step['ability'],['plugins/upload','plugins/upload-base64','plugins/update'],true)) { $ability='plugins/rollback';$args=['backup_id'=>$r['backup_id']]; }
            elseif ('files/mkdir' === $step['ability'] && !empty($r['created'])) { $ability = 'files/delete'; $args = ['path' => $r['path'], 'empty_dir' => true]; }
			elseif (false === ($r['changed'] ?? true)) { $step['compensation'] = ['success' => true, 'changed' => false]; continue; }
			if (!$ability) { $step['compensation'] = Result::fail('compensation_unavailable', 'No complete inverse is recorded for this step.'); $complete = false; continue; }
			$args['idempotency_key'] = 'compensate:' . $state['plan_id'] . ':' . $step['id'];
			$step['compensation'] = Result::normalize(wp_get_ability($ability)->execute($args));
			if (false === ($step['compensation']['success'] ?? true)) $complete = false;
			StateStore::put('plans', $state['plan_id'], $state);
		} unset($step);
		$state['status'] = $complete ? 'compensated' : 'compensation_incomplete'; return $state;
	}
    private static function conditions(string $name,array $input): array {
        if(str_starts_with($name,'files/')&&isset($input['path'])){
            $path=Locks::path($input['path']);if(is_wp_error($path))throw new \RuntimeException('Invalid path.');
            return ['exists'=>file_exists($path),'sha256'=>is_file($path)?hash_file('sha256',$path):hash('sha256','')];
        }
        if(str_starts_with($name,'content/')&&!empty($input['id']))return ['revision'=>ContentTools::revision((int)$input['id'])];
        if(in_array($name,['plugins/update','plugins/activate','plugins/deactivate'],true)){
            require_once ABSPATH.'wp-admin/includes/plugin.php';$p=$input['plugin'];$all=get_plugins();
            return ['version'=>$all[$p]['Version']??null,'active'=>is_plugin_active($p),'tree_sha256'=>\Fator3\RecoveryV1\Engine::digest(\Fator3\RecoveryV1\Engine::manifest(WP_PLUGIN_DIR.'/'.dirname($p)))];
        }
        return [];
    }
    public static function listing(array $input): array {
        $before=PHP_INT_MAX;$context=ConnectionContext::key();
        if(!empty($input['cursor'])){$c=Cursor::decode($input['cursor']);if(is_wp_error($c))return Result::error($c);if(($c['kind']??'')!=='plans'||($c['connection']??'')!==$context||($c['status']??'')!==($input['status']??''))return Result::fail('cursor_invalid','Cursor de outro contexto.');$before=(int)$c['before'];}
        $filters=['connection_id'=>$context];if(isset($input['status']))$filters['status']=$input['status'];
        $limit=min(100,max(1,(int)($input['per_page']??20)));$rows=Persistence::listing('plans',$filters,$limit+1,$before);$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);$items=[];
        foreach($rows as $row)$items[]=['plan_id'=>$row['plan_id'],'status'=>$row['status'],'created_at'=>gmdate('c',$row['time']),'steps'=>count($row['steps']),'completed'=>count(array_filter($row['steps'],static fn($s)=>$s['status']==='complete'))];
        return Result::ok(['operations'=>$items,'has_more'=>$more,'next_cursor'=>$more?Cursor::encode(['kind'=>'plans','connection'=>$context,'status'=>$input['status']??'','before'=>end($rows)['_row_id']]):null]);
    }
    public static function preview(array $input): array {
        $id=$input['plan_id'];return Locks::run(['plan:'.get_current_blog_id().':'.$id=>LOCK_EX],static function()use($id){
            $state=self::get($id);if(is_wp_error($state))return Result::error($state);
            if(!in_array($state['status'],['pending','paused'],true))return Result::fail('plan_preview_unavailable','Prévia exige plano pendente/pausado.');$out=[];
            foreach($state['steps'] as &$step){
                $a=wp_get_ability($step['ability']);$refs=self::references($step['parameters'],$step['depends_on']);
                $item=['id'=>$step['id'],'ability'=>$step['ability'],'simulation'=>$refs?'deferred_until_references_resolve':'no_mutation_simulator','external_effects'=>true,'compensation'=>'only_if_recorded_inverse_available'];
                if(!$refs){$permission=$a?$a->check_permissions($step['parameters']):false;$item['permitted']=$permission===true;
                    if($permission===true){$step['preconditions']=self::conditions($step['ability'],$step['parameters']);$item['preconditions']=$step['preconditions'];$item['target']=array_intersect_key($step['parameters'],array_flip(['path','id','plugin','expected_slug']));}
                    else {$item['error_code']=is_wp_error($permission)?$permission->get_error_code():'permission_denied';unset($step['preconditions']);}
                }$out[]=$item;
            }unset($step);
            $state['preview_id']=bin2hex(random_bytes(16));StateStore::put('plans',$id,$state);
            return Result::ok(['plan_id'=>$id,'preview_id'=>$state['preview_id'],'steps'=>$out,'preview'=>true,'applied'=>false]);
        });
    }
    public static function cancel(array $input): array {
        $id=$input['plan_id'];$state=self::get($id);if(is_wp_error($state))return Result::error($state);
        if(in_array($state['status'],['complete','cancelled','compensated','compensation_incomplete'],true))return Result::ok(['plan_id'=>$id,'status'=>$state['status'],'changed'=>false,'rolled_back'=>false]);
        $created=Persistence::put('plan-cancel',$id,['plan_id'=>$id,'connection_id'=>ConnectionContext::key(),'status'=>'cancel_requested','time'=>time()],true);
        return Result::ok(['plan_id'=>$id,'status'=>'cancel_requested','changed'=>$created,'rolled_back'=>false,'in_flight_step_may_complete'=>true]);
    }

}
