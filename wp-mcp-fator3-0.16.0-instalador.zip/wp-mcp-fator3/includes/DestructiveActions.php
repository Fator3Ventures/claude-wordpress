<?php
/** Typed two-phase deletion. Confirmation is connection-bound and never contains secrets. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class DestructiveActions {
    public static function supports(string $name): bool { return in_array($name,['plugins/delete','users/delete','menus/delete','options/delete','plugins/cleanup-orphaned-uninstall','content/delete-meta','content/delete-post','content/delete-page','comments/delete','media/delete'],true); }
    public static function required(string $name,array $input): bool {
        return in_array($name,['plugins/delete','users/delete','menus/delete','options/delete','plugins/cleanup-orphaned-uninstall','content/delete-meta'],true)
            || in_array($name,['content/delete-post','content/delete-page','comments/delete'],true)&&!empty($input['force'])
            || $name==='media/delete'&&($input['force']??true);
    }
    public static function snapshot(string $name,array $input) {
        $id=(int)($input['id']??0);
        if(str_starts_with($name,'content/')||str_starts_with($name,'media/'))return DeletionSnapshot::post($id);
        if($name==='comments/delete')return ['comment'=>get_comment($id,ARRAY_A),'meta'=>get_comment_meta($id)];
        if($name==='users/delete')return DeletionSnapshot::user($id,$input);
        if($name==='options/delete')return MaintenanceTools::options_snapshot($input);
        if($name==='menus/delete')return MaintenanceTools::menu_snapshot($input);
        if($name==='plugins/cleanup-orphaned-uninstall')return MaintenanceTools::orphan_snapshot($input);
        if($name==='plugins/delete') {
            require_once ABSPATH.'wp-admin/includes/plugin.php';$plugin=(string)($input['plugin']??$input['plugin_file']??'');
            $plugins=get_plugins();if(!isset($plugins[$plugin])){if(!empty($input['_f3_resume']))return ['plugin'=>$plugin,'missing'=>true,'auto_update'=>in_array($plugin,(array)get_site_option('auto_update_plugins',[]),true)];return new \WP_Error('plugin_not_found','Plugin não encontrado.');}
            return ['tree_sha256'=>\Fator3\RecoveryV1\Engine::digest(\Fator3\RecoveryV1\Engine::manifest(dirname($plugin)==='.'?WP_PLUGIN_DIR.'/'.$plugin:WP_PLUGIN_DIR.'/'.dirname($plugin))),'plugin'=>$plugin,'data'=>$plugins[$plugin],'active'=>is_plugin_active($plugin),'auto_update'=>in_array($plugin,(array)get_site_option('auto_update_plugins',[]),true),'uninstall'=>get_option('uninstall_plugins',[])[$plugin]??null];
        }
        return new \WP_Error('preview_unsupported','Prévia indisponível para este tipo.');
    }
    private static function canonical($v) { if(!is_array($v))return $v; if(!array_is_list($v))ksort($v);return array_map([self::class,'canonical'],$v); }
    public static function run(string $name,array $input,callable $run): array {
        if(!empty($input['confirm']) && empty($input['confirm_token'])){
            if(!ConnectionContext::maintenance())return Result::fail('profile_denied','confirm:true exige Manutenção.');
            $next=$input;unset($next['confirm']);$preview=self::run($name,$next,$run);
            if(empty($preview['success'])||empty($preview['confirm_token']))return $preview;
            $next['confirm_token']=$preview['confirm_token'];return self::run($name,$next,$run);
        }
        $args=$input;unset($args['confirm'],$args['confirm_token'],$args['idempotency_key']);
        $key=hash('sha256',serialize(self::canonical($args)));$connection=ConnectionContext::key();
        if(empty($input['confirm_token'])) {
            $snapshot=self::snapshot($name,$args);if(is_wp_error($snapshot))return Result::error($snapshot);
            if($name==='options/delete'&&!$snapshot['existing']||$name==='plugins/cleanup-orphaned-uninstall'&&!$snapshot['callbacks'])return Result::normalize($run());
            $digest=hash_hmac('sha256',serialize($snapshot),wp_salt('auth'));
            $token=bin2hex(random_bytes(32));
            StateStore::put('destructive-confirmations',$token,['status'=>'pending','name'=>$name,'fingerprint'=>$key,'connection_id'=>$connection,'snapshot'=>$digest,'expires'=>time()+600,'time'=>time()]);
            return Result::ok(['preview'=>true,'applied'=>false,'changed'=>false,'confirm_token'=>$token,'expires_at'=>gmdate('c',time()+600),'ability'=>$name,'target'=>array_intersect_key($args,array_flip(['id','plugin','plugin_file','menu_id','names','force','reassign_to','delete_content','acknowledge_in_use'])),'summary'=>self::summary($name,$snapshot),'recovery'=>'Pré-imagem privada auxilia recuperação. Efeitos de hooks externos não são transacionais.']);
        }
        $token=(string)$input['confirm_token'];if(!preg_match('/^[a-f0-9]{64}$/D',$token))return Result::fail('confirmation_invalid','Confirmação inválida.');
        return Locks::run(['deletion-confirm:'.$token=>LOCK_EX],static function() use($token,$name,$args,$key,$connection,$run) {
            $state=StateStore::get('destructive-confirmations',$token);
            if(!$state||$state['name']!==$name||$state['connection_id']!==$connection||!hash_equals($state['fingerprint'],$key))return Result::fail('confirmation_invalid','Confirmação não pertence a esta conexão e seleção.');
            // Completed deletions are replayable even when the target no longer exists.
            if($state['status']==='complete')return array_replace($state['result'],['replayed'=>true]);
            if(!in_array($state['status'],['pending','partial'],true))return Result::fail('operation_uncertain','Confirmação consumida sem conclusão; reconcilie o alvo.');
            if($state['expires']<=time())return Result::fail('confirmation_expired','Prévia expirada.');
            $snapshot=self::snapshot($name,$args+['_f3_resume'=>$state['status']==='partial']);if(is_wp_error($snapshot))return Result::error($snapshot);
            $digest=hash_hmac('sha256',serialize($snapshot),wp_salt('auth'));
            if(!hash_equals($state['snapshot'],$digest))return Result::fail('deletion_conflict','Alvo mudou desde a prévia.',['conflict'=>true]);
            $file_ids=DeletionSnapshot::preserve_files($snapshot);if(is_wp_error($file_ids))return Result::error($file_ids);
            $backup=$state['backup_id']??Backups::create_snapshot($name,$snapshot);if(is_wp_error($backup))return Result::error($backup);
            foreach($file_ids as $file_id){$meta=Backups::metadata($file_id,false);$meta['protected_by_backups']=[$backup];StateStore::put('backup-index',$file_id,$meta);}
            $prior=$state['result']??[];$state['status']='running';$state['backup_id']=$backup;StateStore::put('destructive-confirmations',$token,$state);
            $result=Result::normalize($run());if(!empty($result['backup_id']))$result['deletion_metadata_backup_id']=$backup;else $result['backup_id']=$backup;
            if($name==='options/delete'&&isset($prior['removed']))$result['removed']=array_values(array_unique(array_merge($prior['removed'],$result['removed']??[])));
            $state['status']='complete';
            if(in_array($name,['options/delete','plugins/delete'],true)&&!empty($result['pending'])) {
                $remaining=self::snapshot($name,$args+['_f3_resume'=>true]);
                if(!is_wp_error($remaining)) { $state['status']='partial';$state['snapshot']=hash_hmac('sha256',serialize($remaining),wp_salt('auth'));$result['resume_with_same_confirmation']=true; }
            }
            $state['result']=$result;StateStore::put('destructive-confirmations',$token,$state);
            return $result;
        });
    }
    private static function summary(string $name,array $snapshot): array {
        if($name==='options/delete')return ['existing'=>array_keys($snapshot['existing']),'missing'=>$snapshot['missing'],'backup_contains_sensitive_values'=>'unknown'];
        if($name==='menus/delete')return ['menu_id'=>$snapshot['menu']->term_id,'items'=>count($snapshot['items']),'locations'=>array_keys($snapshot['locations'])];
        if($name==='plugins/cleanup-orphaned-uninstall')return ['plugins'=>array_keys($snapshot['callbacks']),'callbacks_will_execute'=>false];
        if($name==='plugins/delete')return array_intersect_key($snapshot,array_flip(['plugin','active','auto_update']));
        return ['id'=>$snapshot['post']['ID']??$snapshot['user']['ID']??$snapshot['comment']['comment_ID']??null,'content_count'=>$snapshot['content_count']??null,'backup_contains_sensitive_values'=>'unknown'];
    }
}
