<?php
/** Opt-in debug constants using the shared lock/backup/syntax/atomic writer. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class DebugTools {
    public static function update(array $input): array {
        if(!apply_filters('wp_mcp_ultimate_allow_toggle_debug',false))return Result::fail('debug_edit_disabled','Edição de wp-config.php está desabilitada por padrão.');
        if(!PathGuard::is_enabled()||!current_user_can('manage_options'))return Result::fail('permission_denied','Canal fechado ou permissão administrativa ausente.');
        $path=is_file(ABSPATH.'wp-config.php')?ABSPATH.'wp-config.php':dirname(rtrim(ABSPATH,'/')).'/wp-config.php';
        if(is_link($path)||!is_file($path)||!is_writable($path))return Result::fail('config_unavailable','wp-config.php regular e gravável é necessário.');$path=realpath($path);
        $context=ConnectionContext::get();$inside=($context['profile']??'')==='legacy';
        foreach($context['roots']??[] as $root){$root=realpath($root);if($root&&str_starts_with($path,rtrim($root,'/').'/'))$inside=true;}
        if(!$inside)return Result::fail('profile_path_denied','wp-config.php está fora das raízes autorizadas.');
        return Locks::trees([$path],static function()use($path,$input){
            $conflict=Locks::check_hash($path,$input);if($conflict)return $conflict;
            $old=file_get_contents($path);if($old===false||strlen($old)>1048576)return Result::fail('config_read_failed','Configuração ausente ou acima de 1 MiB.');
            $values=['WP_DEBUG'=>(bool)$input['debug']];foreach(['debug_log'=>'WP_DEBUG_LOG','debug_display'=>'WP_DEBUG_DISPLAY'] as $field=>$constant)if(isset($input[$field]))$values[$constant]=(bool)$input[$field];
            $parsed=self::rewrite($old,$values);if(is_wp_error($parsed))return Result::error($parsed);$next=$parsed['content'];
            if($next===$old)return Result::ok(['changed'=>false,'sha256'=>hash('sha256',$old),'constants'=>$values]);
            $syntax=PathGuard::check_php_syntax($next);if(is_wp_error($syntax))return Result::error($syntax);
            $backup=Backups::create_file($path);if(is_wp_error($backup))return Result::error($backup);
            $written=Files::atomic_write($path,$next);if(is_wp_error($written))return Result::error($written);
            $actual=hash_file('sha256',$path);if(!hash_equals(hash('sha256',$next),(string)$actual))return Result::fail('config_readback_failed','Configuração efetiva diverge da gravação.',['backup_id'=>$backup,'applied'=>null]);
            return Result::ok(['changed'=>true,'persisted'=>true,'backup_id'=>$backup,'sha256'=>$actual,'constants'=>$values,'runtime_values_require_new_request'=>true]);
        });
    }
    public static function rewrite(string $php,array $values) {
        $tokens=token_get_all($php);$flat=[];$offset=0;$insertion=null;$openings=0;
        foreach($tokens as $token){$text=is_array($token)?$token[1]:$token;$type=is_array($token)?$token[0]:null;
            if(!in_array($type,[T_WHITESPACE,T_COMMENT,T_DOC_COMMENT],true))$flat[]=['type'=>$type,'text'=>$text,'offset'=>$offset];
            if($type===T_OPEN_TAG){$openings++;$insertion=$offset+strlen($text);}
            if($type===T_NAMESPACE)return new \WP_Error('debug_insertion_ambiguous','Configuração com namespace não é suportada.');
            $offset+=strlen($text);
        }
        if($openings!==1)return new \WP_Error('debug_insertion_ambiguous','Exige um único bloco PHP.');
        // PHP requires declare(strict_types=1) before executable statements.
        $start=1;while(($flat[$start]['type']??null)===T_DECLARE){while(isset($flat[$start])&&$flat[$start]['text']!==';'){if(in_array($flat[$start]['text'],['{',':'],true))return new \WP_Error('debug_insertion_ambiguous','Bloco declare não suportado.');$start++;}if(!isset($flat[$start]))return new \WP_Error('debug_insertion_ambiguous','Declaração incompleta.');$insertion=$flat[$start]['offset']+1;$start++;}
        $edits=[];$found=[];
        for($i=0;$i<count($flat);$i++){
            if($flat[$i]['type']!==T_STRING||strtolower($flat[$i]['text'])!=='define'||($flat[$i+1]['text']??'')!=='('||($flat[$i+2]['type']??null)!==T_CONSTANT_ENCAPSED_STRING)continue;
            $key=trim($flat[$i+2]['text'],"'\"");if(!array_key_exists($key,$values))continue;
            if(isset($found[$key]))return new \WP_Error('debug_constant_ambiguous','Constante definida mais de uma vez: '.$key);$found[$key]=true;
            $value=$flat[$i+4]??[];
            if(($flat[$i+3]['text']??'')!==','||($flat[$i+5]['text']??'')!==')'||!in_array(strtolower($value['text']??''),['true','false'],true))return new \WP_Error('debug_constant_dynamic','Constante usa expressão não booleana: '.$key);
            $edits[]=['offset'=>$value['offset'],'length'=>strlen($value['text']),'text'=>$values[$key]?'true':'false'];
        }
        $insert='';foreach(array_diff_key($values,$found) as $name=>$value)$insert.="define( '".$name."', ".($value?'true':'false')." );\n";
        if($insert!==''){if($insertion===null)return new \WP_Error('debug_insertion_ambiguous','Nenhum ponto seguro de inserção foi reconhecido.');$edits[]=['offset'=>$insertion,'length'=>0,'text'=>"\n".$insert];}
        usort($edits,static fn($a,$b)=>$b['offset']<=>$a['offset']);foreach($edits as $edit)$php=substr_replace($php,$edit['text'],$edit['offset'],$edit['length']);
        return ['content'=>$php];
    }
}
