<?php
/** Administrative views expose summaries, never private plan parameters or SQL previews. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class OperationsAdmin {
    public static function init(): void {
        add_action('admin_post_f3_mcp_admin_cancel',[self::class,'cancel']);
        add_action('admin_post_f3_mcp_maintenance',[self::class,'maintain']);
    }
    private static function guard(string $nonce): void {
        if(!current_user_can('manage_options'))wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer($nonce);
    }
    public static function cancel(): void {
        self::guard('f3_mcp_admin_cancel');$id=is_string($_POST['plan_id']??null)?wp_unslash($_POST['plan_id']):'';
        $plan=preg_match('/^[a-f0-9]{32}$/D',$id)?StateStore::get('plans',$id):null;
        if(!$plan){self::notice(Result::fail('plan_not_found','Plano não encontrado.'),'operations');return;}
        $terminal=in_array($plan['status'],['complete','cancelled','compensated','compensation_incomplete'],true);
        $changed=!$terminal&&Persistence::put('plan-cancel',$id,['plan_id'=>$id,'connection_id'=>$plan['connection_id'],'requested_by_admin'=>get_current_user_id(),'status'=>'cancel_requested','time'=>time()],true);
        $r=Result::ok(['changed'=>$changed,'plan_id'=>$id],'Pedido registrado. A etapa em andamento pode terminar; efeitos anteriores não foram revertidos.');
        Audit::record('admin/operations/cancel',['id'=>$id],$r,0);self::notice($r,'operations');
    }
    private static function notice(array $result,string $tab): void {
        $key=wp_generate_uuid4();set_transient('f3_mcp_notice_'.get_current_user_id().'_'.$key,['success'=>!empty($result['success']),'message'=>$result['message']??'Ação concluída.'],60);
        wp_safe_redirect(add_query_arg('notice',$key,Admin::url($tab)));exit;
    }
    private static function details(string $title,$data): void {
        echo '<details><summary>'.esc_html($title).'</summary><pre class="code" style="white-space:pre-wrap;overflow-wrap:anywhere">'.esc_html(wp_json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</pre></details>';
    }
    public static function operations(): void {
        $before=max(1,(int)($_GET['before_id']??PHP_INT_MAX));$filter=[];
        if(is_string($_GET['status']??null)&&$_GET['status']!=='')$filter['status']=sanitize_key(wp_unslash($_GET['status']));
        $rows=Persistence::listing('plans',$filter,31,$before);$more=count($rows)>30;$rows=array_slice($rows,0,30);
        echo '<section class="f3-card"><h2>Operações</h2><p>Planos de todas as conexões deste site. Cancelar impede os próximos passos; uma etapa em andamento pode concluir. A prévia completa deve ser feita pelo conector que possui o plano.</p>';
        self::filters('operations',['status'=>'Estado']);
        foreach($rows as $row){
            $cancel=StateStore::get('plan-cancel',$row['plan_id']);$done=count(array_filter($row['steps'],static fn($s)=>$s['status']==='complete'));
            echo '<article><h3><code>'.esc_html($row['plan_id']).'</code></h3><p>'.esc_html($row['status'].($cancel?' · cancelamento solicitado':'').' · '.$done.'/'.count($row['steps']).' etapas · '.$row['connection_id']).'</p><div class="f3-table-scroll" tabindex="0" role="region" aria-label="Registros operacionais"><table class="widefat striped"><thead><tr><th>Etapa</th><th>Habilidade</th><th>Estado</th><th>Resultado observado</th></tr></thead><tbody>';
            foreach($row['steps'] as $step){
                $summary=array_intersect_key($step['result']??[],array_flip(['success','changed','persisted','applied','error_code','operation_id','backup_id','recovery_status']));
                echo '<tr><td>'.esc_html($step['id']).'</td><td>'.esc_html($step['ability']).'</td><td>'.esc_html($step['status']).'</td><td>';self::details('Resultado', $summary);if(isset($step['preconditions']))self::details('Pré-condições da prévia',$step['preconditions']);echo '</td></tr>';
            }
            echo '</tbody></table></div>';
            if(!in_array($row['status'],['complete','cancelled','compensated','compensation_incomplete'],true)){
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('f3_mcp_admin_cancel');echo '<input type="hidden" name="action" value="f3_mcp_admin_cancel"><input type="hidden" name="plan_id" value="'.esc_attr($row['plan_id']).'"><p><button class="button">Solicitar cancelamento</button></p></form>';
            }
            echo '</article>';
        }
        if(!$rows)echo '<p>Nenhum plano encontrado.</p>';
        if($more)echo '<p><a class="button" href="'.esc_url(add_query_arg(['before_id'=>end($rows)['_row_id']]+$filter,Admin::url('operations'))).'">Próximos planos</a></p>';echo '</section>';
    }
    private static function filters(string $tab,array $fields): void {
        echo '<form method="get"><input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="'.esc_attr($tab).'">';
        foreach($fields as $key=>$label){$value=is_string($_GET[$key]??null)?wp_unslash($_GET[$key]):'';echo '<p><label>'.esc_html($label).' <input name="'.esc_attr($key).'" value="'.esc_attr($value).'"></label></p>';}
        echo '<p><button class="button">Filtrar</button></p></form>';
    }
    public static function history(): void {
        echo '<section class="f3-card"><h2>Histórico e armazenamento</h2><p>O histórico contém metadados operacionais. Exportações restauráveis de backup podem conter valores originais e exigem permissão específica.</p>';
        self::filters('history',['connection_id'=>'Conexão','ability'=>'Habilidade','target'=>'Alvo/caminho exato','operation_id'=>'Operação','since'=>'Desde (ISO 8601)','until'=>'Até (ISO 8601)']);
        $input=['per_page'=>30];foreach(['connection_id','ability','target','operation_id','since','until','cursor'] as $k)if(is_string($_GET[$k]??null)&&$_GET[$k]!=='')$input[$k]=wp_unslash($_GET[$k]);
        $r=Audit::listing($input);
        if(empty($r['success']))echo '<p>'.esc_html($r['message']).'</p>';
        else{
            echo '<div class="f3-table-scroll" tabindex="0" role="region" aria-label="Registros operacionais"><table class="widefat striped"><thead><tr><th>Data</th><th>Conexão</th><th>Habilidade</th><th>Alvo</th><th>Resultado</th></tr></thead><tbody>';
            foreach($r['entries'] as $event)echo '<tr><td>'.esc_html((string)$event['time']).'</td><td>'.esc_html($event['connection_id']??'unknown').'</td><td>'.esc_html($event['ability']).'</td><td>'.esc_html($event['target']??'').'</td><td>'.esc_html(empty($event['success'])?($event['error_code']??'Falha'):'Concluído').'</td></tr>';
            echo '</tbody></table></div>';if(!$r['history_complete'])echo '<p>Importação do histórico legado em andamento; esta listagem ainda não é completa.</p>';
            if($r['has_more']){unset($input['per_page']);echo '<p><a class="button" href="'.esc_url(add_query_arg(array_replace($input,['cursor'=>$r['next_cursor']]),Admin::url('history'))).'">Próximos registros</a></p>';}
        }
        self::details('Ocupação e última manutenção',StateMaintenance::storage());
        echo '<h3>Manutenção explícita</h3><p>Comece pela simulação. Estados em andamento, operações incertas e comprovantes de idempotência são preservados. Para prévias por idade/volume do acervo de arquivos use backups/prune.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('f3_mcp_maintenance');echo '<input type="hidden" name="action" value="f3_mcp_maintenance"><label>Categoria <select name="category">';
        foreach(['audit'=>'Auditoria','oauth-clients'=>'Clientes não autorizados expirados','oauth-codes'=>'Códigos OAuth expirados','oauth-tokens'=>'Tokens OAuth expirados','sessions'=>'Sessões expiradas','transfers'=>'Partes de uploads expirados','idempotency'=>'Resultados concluídos de idempotência'] as $v=>$label)echo '<option value="'.esc_attr($v).'">'.esc_html($label).'</option>';
        echo '</select></label> <label>Idade mínima em dias <input type="number" min="1" max="3650" name="older_than_days" value="90"></label><p><button class="button">Simular lote</button></p></form></section>';
    }
    public static function maintain(): void {
        self::guard('f3_mcp_maintenance');$category=is_string($_POST['category']??null)?sanitize_key(wp_unslash($_POST['category'])):'';
        $input=['category'=>$category,'older_than_days'=>max(1,min(3650,(int)($_POST['older_than_days']??90))),'dry_run'=>($_POST['apply']??'')!=='1'];
        if(is_string($_POST['expected_selection_sha256']??null))$input['expected_selection_sha256']=wp_unslash($_POST['expected_selection_sha256']);
        $r=StateMaintenance::run($input);Audit::record('admin/maintenance',['name'=>$category],$r,0);
        if(empty($r['success'])||!$input['dry_run'])self::notice($r,'history');
        nocache_headers();ob_start();echo '<h1>Simulação de manutenção</h1><p>Nenhum registro foi removido. A aplicação alcança somente este lote.</p>';self::details('Seleção',$r);
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('f3_mcp_maintenance');
        foreach(['action'=>'f3_mcp_maintenance','category'=>$category,'apply'=>'1','expected_selection_sha256'=>$r['selection_sha256']] as $key=>$value)echo '<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($value).'">';
        echo '<p><button class="button">Aplicar esta seleção</button></p></form><p><a href="'.esc_url(Admin::url('history')).'">Voltar sem aplicar</a></p>';wp_die(ob_get_clean(),'Simulação de manutenção',['response'=>200]);
    }
}
