<?php
/** Administrative database operations. DDL recovery is separate from transactional DML. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class DatabaseAdmin {
    public static function permission(): bool {return ConnectionTools::permission()&&PathGuard::is_enabled()&&Database::writes_enabled();}
    public static function register(): void {
        Registry::add('db/recovery-status','Consulta diário de restauração independente, sem devolver valores originais ou credenciais.',['recovery_id'=>Registry::string()],['recovery_id'],static function($i){if(!preg_match('/^[a-f0-9]{32}$/D',$i['recovery_id']))return Result::fail('recovery_invalid','Identificador inválido.');$s=\Fator3\RecoveryV1\Engine::read(StateStore::directory('database-recovery').'/'.$i['recovery_id'].'.php');return $s?Result::ok(array_intersect_key($s,array_flip(['id','status','artifact_id','started_at','finished_at','completed_statements','recovery_error','rollback_artifact_id','operation_id']))):Result::fail('recovery_not_found','Diário não encontrado.');},[ConnectionTools::class,'permission']);
        $tables=['type'=>'array','items'=>Registry::string(),'uniqueItems'=>true];
        Registry::add('db/batch','Executa lote DML InnoDB em transação única, com prévia/confirm_token, cópia integral e rollback na primeira falha. DDL é recusado antes da primeira escrita.',['statements'=>['type'=>'array','items'=>Registry::string(),'minItems'=>1,'maxItems'=>100],'confirm_token'=>Registry::string()],['statements'],[self::class,'batch'],[self::class,'permission'],false);
        Registry::add('db/export','Exporta banco ou tabelas em SQL gzip privado, com schema, dados, views, triggers, contagens e SHA-256. Contém valores originais, inclusive segredos.',['tables'=>$tables],[],[self::class,'export'],[ConnectionTools::class,'permission'],false);
        Registry::add('db/restore','Restaura dump produzido por este canal, validado por hash; duas fases e backup anterior. Estado operacional corrente MCP é preservado para não reativar tokens revogados. DDL recuperável, sem promessa de transação global.',['artifact_id'=>Registry::string(),'confirm_token'=>Registry::string(),'allow_changed_destination'=>Registry::boolean()],['artifact_id'],[self::class,'restore'],[self::class,'permission'],false);
        Registry::add('db/search-replace','Simula troca literal em strings/JSON/arrays serializados sem instanciar objetos. Confirmação, pré-imagem, contagem por tabela/coluna; objetos serializados são apontados e preservados.',['search'=>['type'=>'string','minLength'=>1],'replace'=>Registry::string(),'tables'=>$tables,'columns'=>$tables,'confirm_token'=>Registry::string()],['search','replace'],[self::class,'search_replace'],[self::class,'permission'],false);
    }
    private static function q(string $name): string {return '`'.str_replace('`','``',$name).'`';}
    private static function tables(\mysqli $db,?array $selected=null): array {
        $r=DatabaseRead::checked($db,'SHOW FULL TABLES');$all=[];while($row=$r->fetch_row())$all[$row[0]]=$row[1];$r->free();
        if($selected!==null){foreach($selected as $t)if(!isset($all[$t]))throw new \RuntimeException('table_not_found');$all=array_intersect_key($all,array_flip($selected));}ksort($all);return $all;
    }
    private static function internal(string $table): bool {return in_array($table,OwnedState::tables(),true);}
    private static function fingerprint(\mysqli $db,?array $only=null,bool $lock=false): array {
        $tables=self::tables($db,$only);$out=[];
        foreach($tables as $table=>$type){if(self::internal($table))continue;$r=DatabaseRead::checked($db,'SHOW CREATE TABLE '.self::q($table));$create=$r->fetch_row()[1];$r->free();$hash=hash_init('sha256');$count=0;
            if($type==='BASE TABLE'){$r=$db->query('SELECT * FROM '.self::q($table).($lock?' FOR UPDATE':''),MYSQLI_USE_RESULT);if(!$r)throw new \RuntimeException('table_read_failed');while($row=$r->fetch_row()){hash_update($hash,serialize($row));$count++;}$r->free();}
            $out[$table]=['type'=>$type,'schema_sha256'=>hash('sha256',$create),'data_sha256'=>hash_final($hash),'rows'=>$count];
        }return $out;
    }
    private static function check_dump_objects(\mysqli $db,?array $only): void {
        if($only!==null)return;
        $r=DatabaseRead::checked($db,"SELECT COUNT(*) FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA=DATABASE()");$n=(int)$r->fetch_row()[0];$r->free();
        $r=DatabaseRead::checked($db,"SELECT COUNT(*) FROM information_schema.EVENTS WHERE EVENT_SCHEMA=DATABASE()");$n+=(int)$r->fetch_row()[0];$r->free();
        if($n)throw new \RuntimeException('dump_routines_events_unsupported');
    }
    /** Restore base tables first, then views in dependency order. */
    private static function ordered_tables(\mysqli $db,?array $only): array {
        $all=self::tables($db,$only);$ordered=array_filter($all,static fn($type)=>$type==='BASE TABLE');$pending=array_diff_key($all,$ordered);
        while($pending){$progress=false;foreach($pending as $name=>$type){$q="SELECT TABLE_NAME FROM information_schema.VIEW_TABLE_USAGE WHERE VIEW_SCHEMA=DATABASE() AND VIEW_NAME='".$db->real_escape_string($name)."' AND TABLE_SCHEMA=DATABASE()";$r=DatabaseRead::checked($db,$q);$dependencies=[];while($v=$r->fetch_row())$dependencies[]=$v[0];$r->free();if(array_intersect(array_keys($pending),$dependencies))continue;$ordered[$name]=$type;unset($pending[$name]);$progress=true;}if(!$progress)throw new \RuntimeException('view_dependency_cycle');}
        return $ordered;
    }
    private static function statement(array &$w,string $sql): void {PrivateArtifact::append($w,'-- f3-statement:'.base64_encode($sql)."\n".$sql.";\n");}
    public static function dump(\mysqli $db,?array $only=null,array $context=[]): array {
        $r=SqlArtifacts::lock(static fn()=>self::dump_locked($db,$only,$context));
        if(empty($r['id']))throw new \RuntimeException('artifact_in_use');return $r;
    }
    private static function dump_locked(\mysqli $db,?array $only,array $context): array {
        self::check_dump_objects($db,$only);$tables=self::ordered_tables($db,$only);$w=PrivateArtifact::writer('sql',true);$manifest=[];$deferred=[];
        try{
            PrivateArtifact::append($w,"-- Fator3 MCP 0.16 SQL snapshot. Original values; private recovery artifact.\n");
            foreach($tables as $table=>$type){$quoted=self::q($table);$r=DatabaseRead::checked($db,'SHOW CREATE TABLE '.$quoted);$create=$r->fetch_row()[1];$r->free();$manifest[$table]=['type'=>$type,'rows'=>0,'schema_sha256'=>hash('sha256',$create),'runtime_state'=>self::internal($table)];
                if($type==='VIEW'){$deferred[]=['table'=>$table,'sql'=>$create];continue;}
                self::statement($w,'DROP TABLE IF EXISTS '.$quoted);self::statement($w,$create);
                $cols=DatabaseRead::checked($db,'SHOW FULL COLUMNS FROM '.$quoted);$names=[];$types=[];$order=[];while($c=$cols->fetch_assoc())if(!str_contains($c['Extra'],'GENERATED')){$names[]=$c['Field'];$types[]=$c['Type'];if($c['Key']==='PRI')$order[]=$c['Field'];}$cols->free();
                $manifest[$table]['columns']=$names;$manifest[$table]['order']=$order;$digest=hash_init('sha256');$r=$db->query('SELECT '.implode(',',array_map([self::class,'q'],$names)).' FROM '.$quoted.($order?' ORDER BY '.implode(',',array_map([self::class,'q'],$order)):''),MYSQLI_USE_RESULT);if(!$r)throw new \RuntimeException('table_read_failed');
                while($row=$r->fetch_row()){hash_update($digest,serialize($row));$values=[];foreach($row as $idx=>$v)$values[]=$v===null?'NULL':(str_starts_with(strtolower($types[$idx]),'bit(')?"X'".bin2hex($v)."'":(strtolower($types[$idx])==='json'?"CONVERT(X'".bin2hex($v)."' USING utf8mb4)":"CAST(X'".bin2hex($v)."' AS BINARY)"));self::statement($w,'INSERT INTO '.$quoted.' ('.implode(',',array_map([self::class,'q'],$names)).') VALUES ('.implode(',',$values).')');$manifest[$table]['rows']++;$w['rows']++;}$r->free();$manifest[$table]['rows_sha256']=hash_final($digest);
            }
            foreach($deferred as $entry){self::statement($w,'DROP VIEW IF EXISTS '.self::q($entry['table']));self::statement($w,$entry['sql']);}
            $triggers=DatabaseRead::checked($db,'SHOW TRIGGERS');$tr=[];while($row=$triggers->fetch_assoc())if(isset($tables[$row['Table']]))$tr[]=$row;$triggers->free();
            foreach($tr as $t){$r=DatabaseRead::checked($db,'SHOW CREATE TRIGGER '.self::q($t['Trigger']));$row=$r->fetch_assoc();$r->free();self::statement($w,'DROP TRIGGER IF EXISTS '.self::q($t['Trigger']));self::statement($w,$row['SQL Original Statement']);}
            return PrivateArtifact::finish($w,$context+['metadata_contract'=>1,'purpose'=>'unknown','tables'=>$manifest,'triggers'=>array_column($tr,'Trigger'),'database'=>DB_NAME,'charset'=>$db->character_set_name(),'backup_contains_sensitive_values'=>true,'scope'=>$only===null?'database':'selected_tables','restores_runtime_state'=>false,'preserved_state_manifest'=>OwnedState::manifest(),'objects'=>['tables'=>array_keys(array_filter($tables,static fn($t)=>$t==='BASE TABLE')),'views'=>array_keys(array_filter($tables,static fn($t)=>$t==='VIEW')),'triggers'=>array_column($tr,'Trigger'),'routines'=>[],'events'=>[]]]);
        }catch(\Throwable $e){if(is_resource($w['stream']))fclose($w['stream']);@unlink(PrivateArtifact::path($w['id']));throw $e;}
    }
    public static function export(array $i): array {return Locks::run(['database-admin:'.get_current_blog_id()=>LOCK_SH],static fn()=>SqlArtifacts::lock(static fn()=>self::export_locked($i)));}
    private static function export_locked(array $i): array {$db=null;try{$db=DatabaseRead::connection();DatabaseRead::checked($db,'SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');DatabaseRead::checked($db,'START TRANSACTION WITH CONSISTENT SNAPSHOT');$meta=self::dump($db,$i['tables']??null,['purpose'=>'manual_export','ability'=>'db/export']);$db->commit();return Result::ok(['artifact_id'=>$meta['id'],'sha256'=>$meta['sha256'],'bytes'=>$meta['bytes'],'row_count'=>$meta['rows'],'tables'=>$meta['tables'],'triggers'=>$meta['triggers'],'format'=>'sql','gzip'=>true,'backup_contains_sensitive_values'=>true]);}catch(\Throwable $e){return Result::fail($e->getMessage()==='dump_routines_events_unsupported'?'dump_routines_events_unsupported':'database_export_failed','Dump não concluído. Banco com rotinas/eventos SQL requer exportação específica; artefato incompleto não é publicado.');}finally{if($db){$db->rollback();$db->close();}}}
    private static function validate(string $sql,bool $batch=false) {
        $scan=SqlGuard::scan($sql);if(strlen($sql)>1048576||$scan['error']||$scan['statements']!==1)return new \WP_Error('sql_single_statement','Cada item precisa ser uma instrução completa até 1 MiB.');
        $sql=$scan['sql'];$verb=SqlGuard::verb($sql);$mask=SqlGuard::mask($sql);
        global $wpdb;if(preg_match('/(?:^|[^A-Za-z0-9_])'.preg_quote($wpdb->prefix.'f3_mcp_','/').'[A-Za-z0-9_]*/i',$mask))return new \WP_Error('channel_state_protected','Estado transacional do canal usa connections/* e system/settings-update.');
        if(!in_array($verb,$batch?['insert','replace','update','delete']:['insert','replace','update','delete','create','alter','drop','truncate','rename'],true))return new \WP_Error('sql_statement_unsupported','Somente DML; DDL de tabelas/índices é permitido fora do lote transacional.');
        if(in_array($verb,['create','drop','alter'],true)&&!preg_match('/^(?:create|drop|alter)\s+(?:unique\s+)?(?:table|index)\b/i',$sql))return new \WP_Error('sql_ddl_unsupported','DDL aceita tabelas/índices, sem usuários, rotinas ou permissões.');
        if(preg_match('/\b(?:outfile|dumpfile|load_file|load|call|prepare|execute|sys_exec|sleep|benchmark|get_lock|release_lock)\b|@|:=/i',$mask))return new \WP_Error('sql_construct_forbidden','Construção fora do contrato de banco.');
        if(preg_match('/\b(?:table|from|join|update|into|rename)\s+`?\w+`?\s*\./i',$mask))return new \WP_Error('sql_database_scope','Use nomes de tabelas do banco atual, sem qualificador de banco.');
        return $sql;
    }
    public static function execute(array $i): array {return self::mutate([$i['sql']],$i,false);}
    public static function batch(array $i): array {return self::mutate($i['statements'],$i,true);}
    private static function mutate(array $statements,array $i,bool $batch): array {
        if(!self::permission())return Result::fail('permission_denied','Escrita não autorizada.');
        $clean=[];$ddl=false;foreach($statements as $sql){$s=self::validate($sql,$batch);if(is_wp_error($s))return Result::error($s);$clean[]=$s;$ddl=$ddl||in_array(SqlGuard::verb($s),['create','alter','drop','truncate','rename'],true);}
        return SqlMutation::run($batch?'db/batch':'db/execute',$i,$clean);
    }
    public static function restore(array $i): array {return Locks::run(['database-admin:'.get_current_blog_id()=>LOCK_EX],static fn()=>SqlArtifacts::lock(static fn()=>self::restore_locked($i)));}
    private static function restore_locked(array $i): array {
        try{$meta=PrivateArtifact::meta($i['artifact_id']);if($meta['format']!=='sql'||!PrivateArtifact::verify($meta['id']))return Result::fail('backup_invalid','Dump inválido.');}
        catch(\Throwable $e){return Result::fail('backup_invalid','Dump não encontrado.');}
        return Locks::run(['database-admin:'.get_current_blog_id()=>LOCK_EX],static function()use($i,$meta){$db=DatabaseRead::connection();try{if(isset($meta['postimage'])&&$meta['postimage']!==self::fingerprint($db)&&empty($i['allow_changed_destination']))return Result::fail('restore_destination_changed','Banco difere da pós-imagem da operação. Confira as alterações antes de criar nova prévia com allow_changed_destination:true.',['conflict'=>true,'applied'=>false]);return self::restore_phase($i,$db,$meta);}finally{$db->close();}});
    }
    private static function restore_phase(array $i,\mysqli $db,array $meta): array {
        $only=($meta['scope']??'')==='selected_tables'?array_keys($meta['tables']):null;
        $r=Phase::run('db/restore',$i,static fn()=>['tables'=>self::fingerprint($db,$only),'artifact_id'=>$i['artifact_id']],static function()use($i,$db){
            $op=Phase::current();$before=self::dump($db,null,['purpose'=>'restore_preimage','ability'=>'db/restore','operation_id'=>$op,'references'=>$op?[$op]:[]]);
            $r=self::restore_confirmed($i['artifact_id'],$before['id']);return $r+['backup_id'=>$before['id']];
        });
        if(!empty($r['preview'])&&!empty($r['operation_id']))SqlArtifacts::pin($meta['id'],$r['operation_id']);
        return $r+['backup_scope'=>$meta['scope']??'database','restore_tables'=>array_keys($meta['tables']),'restores_entire_tables'=>true];
    }
    private static function install_recovery(): void {
        Recovery::install_sentinel();if(!class_exists('Fator3\\DatabaseRecovery014\\Controller',false))require_once __DIR__.'/DatabaseRecoveryRuntime.php';$target=WPMU_PLUGIN_DIR.'/f3-database-recovery-014.php';\Fator3\RecoveryV1\Engine::atomic($target,(string)file_get_contents(__DIR__.'/DatabaseRecoveryRuntime.php'),0600);
        $loader="<?php\nif(!defined('ABSPATH'))exit;\nrequire_once __DIR__.'/f3-mcp-recovery-runtime-v1.php';\nrequire_once __DIR__.'/f3-database-recovery-014.php';\n\\Fator3\\DatabaseRecovery014\\Controller::sweep(".var_export(StateStore::directory('database-recovery'),true).");\n";
        \Fator3\RecoveryV1\Engine::atomic(WPMU_PLUGIN_DIR.'/000-f3-database-recovery.php',$loader,0600);
    }
    private static function runtime_rows(\mysqli $db): array {
        global $wpdb;$out=[];
        foreach([$wpdb->options=>OwnedState::option_where(),$wpdb->usermeta=>OwnedState::user_where()] as $table=>$where){$r=DatabaseRead::checked($db,'SELECT * FROM '.self::q($table).' WHERE '.$where);$out[$table]=['where'=>$where,'rows'=>$r->fetch_all(MYSQLI_ASSOC)];$r->free();}return $out;
    }
    private static function restore_runtime(\mysqli $db,array $runtime): void {
        foreach($runtime as $table=>$set){DatabaseRead::checked($db,'DELETE FROM '.self::q($table).' WHERE '.$set['where']);foreach($set['rows'] as $row){unset($row['option_id'],$row['umeta_id']);$columns=implode(',',array_map([self::class,'q'],array_keys($row)));$values=implode(',',array_map(static fn($v)=>$v===null?'NULL':"CAST(X'".bin2hex((string)$v)."' AS BINARY)",array_values($row)));DatabaseRead::checked($db,'INSERT INTO '.self::q($table).' ('.$columns.') VALUES ('.$values.')');}}
    }
    public static function restore_confirmed(string $id,?string $rollback_id=null): array {return Locks::run(['database-admin:'.get_current_blog_id()=>LOCK_EX],static fn()=>SqlArtifacts::lock(static fn()=>self::restore_confirmed_locked($id,$rollback_id)));}
    private static function restore_confirmed_locked(string $id,?string $rollback_id): array {
        $db=null;$journal=null;$lease=null;
        try{
            $m=PrivateArtifact::meta($id);if($m['format']!=='sql'||!PrivateArtifact::verify($id))throw new \RuntimeException('invalid_dump');$db=DatabaseRead::connection();$runtime=self::runtime_rows($db);if(($m['scope']??'')==='selected_tables')$runtime=array_intersect_key($runtime,$m['tables']);
            $rollback_id=$rollback_id??self::dump($db,null,['purpose'=>'restore_preimage','ability'=>'db/restore','operation_id'=>Phase::current(),'references'=>Phase::current()?[Phase::current()]:[]])['id'];self::install_recovery();
            $jid=bin2hex(random_bytes(16));$journal=StateStore::directory('database-recovery').'/'.$jid.'.php';
            global $wpdb;$parsed=$wpdb->parse_db_host(DB_HOST);
            $state=['preserved_state_manifest'=>OwnedState::manifest(),'internal_tables'=>OwnedState::tables(),'operation_id'=>Phase::current(),'rollback_artifact_id'=>$rollback_id,'boot_table'=>$wpdb->options,'rollback_artifact_path'=>PrivateArtifact::path($rollback_id),'internal_prefix'=>$wpdb->prefix.'f3_mcp_','lock_path'=>StateStore::directory('locks').'/'.hash('sha256','database-admin:'.get_current_blog_id()).'.php','database_connection'=>['host'=>$parsed[0],'port'=>$parsed[1]?:3306,'socket'=>$parsed[2],'charset'=>$db->character_set_name(),'sql_mode'=>$db->query('SELECT @@SESSION.sql_mode')->fetch_row()[0]],'id'=>$jid,'status'=>'running','artifact_id'=>$id,'connection_id'=>ConnectionContext::key(),'started_at'=>time(),'completed_statements'=>0,'runtime'=>$runtime];$lease=fopen($journal.'.lease','c+b');if(!$lease||!flock($lease,LOCK_EX|LOCK_NB))throw new \RuntimeException('database_recovery_lease');\Fator3\RecoveryV1\Engine::write($journal,$state);
            DatabaseRead::checked($db,'SET FOREIGN_KEY_CHECKS=0');$skip=false;$count=0;
            // Full snapshots restore the previous object set; selected snapshots never drop unrelated tables.
            if(($m['scope']??'')==='database')foreach(array_reverse(self::ordered_tables($db,null),true) as $name=>$type)if(!self::internal($name)&&!isset($m['tables'][$name]))DatabaseRead::checked($db,($type==='VIEW'?'DROP VIEW ':'DROP TABLE ').self::q($name));
            foreach(PrivateArtifact::lines($id) as $line){
                if(!str_starts_with($line,'-- f3-statement:'))continue;$sql=base64_decode(trim(substr($line,strlen('-- f3-statement:'))),true);if($sql===false)throw new \RuntimeException('invalid_dump_statement');
                $skip=preg_match('/^(?:DROP TABLE IF EXISTS|CREATE TABLE|INSERT INTO)\s+`((?:[^`]|``)+)`/i',$sql,$hit)&&self::internal(str_replace('``','`',$hit[1]));if($skip)continue;
                $state['next_statement_sha256']=hash('sha256',$sql);\Fator3\RecoveryV1\Engine::write($journal,$state);
                \Fator3\DatabaseRecovery014\Controller::apply($db,$sql,$state);$count++;$state['completed_statements']=$count;unset($state['next_statement_sha256']);\Fator3\RecoveryV1\Engine::write($journal,$state);do_action('f3_mcp_database_restore_checkpoint',$jid,$count,!empty($state['boot_stage']));
            }
            \Fator3\DatabaseRecovery014\Controller::flush_boot($db,$state);
            $statement_count=$count;foreach($m['tables'] as $table=>$description){if($description['type']!=='BASE TABLE'||self::internal($table))continue;
                $digest=hash_init('sha256');$count=0;$query='SELECT '.implode(',',array_map([self::class,'q'],$description['columns'])).' FROM '.self::q($table);if($description['order'])$query.=' ORDER BY '.implode(',',array_map([self::class,'q'],$description['order']));
                $r=$db->query($query,MYSQLI_USE_RESULT);while($row=$r->fetch_row()){hash_update($digest,serialize($row));$count++;}$r->free();if($count!==$description['rows']||!hash_equals($description['rows_sha256'],hash_final($digest)))throw new \RuntimeException('restore_readback_mismatch');
            }
            self::restore_runtime($db,$runtime);$state['status']='complete';$state['finished_at']=time();unset($state['runtime']);\Fator3\RecoveryV1\Engine::write($journal,$state);
            wp_cache_flush();return Result::ok(['changed'=>true,'restored_statements'=>$statement_count,'runtime_state_preserved'=>true,'preserved_state_manifest'=>OwnedState::manifest(),'atomic'=>false,'artifact_id'=>$id,'recovery_id'=>$jid]);
        }catch(\Throwable $e){if($journal&&$db){try{self::restore_runtime($db,$runtime);$state['status']='recovery_required';\Fator3\RecoveryV1\Engine::write($journal,$state);}catch(\Throwable $ignored){}}return Result::fail('database_restore_failed','Restauração incompleta; diário privado preservado. Corrija a causa e faça nova prévia de db/restore com o backup indicado.',['applied'=>null,'recovery_id'=>$state['id']??null,'mysql_errno'=>(int)$e->getCode()]);}
        finally{if(is_resource($lease)){flock($lease,LOCK_UN);fclose($lease);}if($db){try{$db->query('SET FOREIGN_KEY_CHECKS=1');$db->close();}catch(\Throwable $ignore){}}}
    }
    private static function replace_json($v,string $search,string $replace,int &$n) {
        if(is_array($v)||$v instanceof \stdClass){foreach($v as $k=>$child){$next=self::replace_json($child,$search,$replace,$n);if(is_array($v))$v[$k]=$next;else $v->$k=$next;}return $v;}
        if(is_string($v)){$v=str_replace($search,$replace,$v,$count);$n+=$count;}return $v;
    }
    private static function replace_value($v,string $search,string $replace,int &$n) {
        if(is_object($v))throw new \RuntimeException('serialized_object_unsupported');
        if(is_array($v)){foreach($v as $key=>&$value)$value=self::replace_value($value,$search,$replace,$n);unset($value);return $v;}
        if(is_string($v)){if(is_serialized($v)){$decoded=unserialize($v,['allowed_classes'=>false]);return serialize(self::replace_value($decoded,$search,$replace,$n));}if(preg_match('/^\s*[\[{]/',$v)){$json=json_decode($v);if(json_last_error()===JSON_ERROR_NONE){$changed=self::replace_json($json,$search,$replace,$n);return $n?json_encode($changed,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):$v;}}$v=str_replace($search,$replace,$v,$count);$n+=$count;}return $v;
    }
    /** Bounded keyset batches; the caller's InnoDB transaction owns consistency. */
    private static function replacement_stream(\mysqli $db,string $search,string $replace,?array $tables=null,?array $columns=null): \Generator {
        $quote=static fn($v)=>$v===null?'NULL':"CAST(X'".bin2hex((string)$v)."' AS BINARY)";
        foreach(self::tables($db,$tables) as $table=>$type){
            if($type!=='BASE TABLE'||self::internal($table))continue;
            $cols=DatabaseRead::checked($db,'SHOW COLUMNS FROM '.self::q($table));$pk=[];$text=[];$types=[];
            while($c=$cols->fetch_assoc()){if($c['Key']==='PRI')$pk[]=$c['Field'];if(preg_match('/char|text|json|blob/i',$c['Type'])&&!str_contains($c['Extra'],'GENERATED'))$text[]=$c['Field'];$types[$c['Field']]=$c['Type'];}$cols->free();if($columns!==null)$text=array_values(array_intersect($text,$columns));
            if(!$pk||!$text){if($text)yield ['skipped'=>true,'table'=>$table,'reason'=>'primary_key_required'];continue;}
            $last=null;
            do{
                $where='';if($last!==null){$terms=[];foreach($pk as $index=>$key){$term=[];for($j=0;$j<$index;$j++)$term[]=self::q($pk[$j]).'='.$quote($last[$pk[$j]]);$term[]=self::q($key).'>'.$quote($last[$key]);$terms[]='('.implode(' AND ',$term).')';}$where=' WHERE '.implode(' OR ',$terms);}
                $r=DatabaseRead::checked($db,'SELECT * FROM '.self::q($table).$where.' ORDER BY '.implode(',',array_map([self::class,'q'],$pk)).' LIMIT 200');$batch=$r->fetch_all(MYSQLI_ASSOC);$r->free();
                foreach($batch as $row){$last=array_intersect_key($row,array_flip($pk));foreach($text as $col){if($row[$col]===null)continue;$n=0;
                    if(in_array($col,$pk,true)&&str_contains($row[$col],$search)){yield ['skipped'=>true,'table'=>$table,'column'=>$col,'key_sha256'=>hash('sha256',serialize($last)),'reason'=>'primary_key_change_requires_sql'];continue;}
                    try{$next=self::replace_value($row[$col],$search,$replace,$n);}catch(\Throwable $e){yield ['skipped'=>true,'table'=>$table,'column'=>$col,'key_sha256'=>hash('sha256',serialize($last)),'reason'=>'serialized_object_unsupported'];continue;}
                    if($n)yield ['table'=>$table,'column'=>$col,'before'=>$row[$col],'after'=>$next,'key'=>$last,'occurrences'=>$n,'column_type'=>$types[$col]];
                }}
            }while(count($batch)===200);
        }
    }
    private static function replacements(\mysqli $db,string $search,string $replace,?array $tables=null,?array $columns=null): array {
        $counts=[];$skipped=[];$samples=[];foreach(self::replacement_stream($db,$search,$replace,$tables,$columns) as $change){if(!empty($change['skipped'])){$skipped[]=$change;continue;}if(count($samples)<20)$samples[]=['table'=>$change['table'],'column'=>$change['column'],'key_sha256'=>hash('sha256',serialize($change['key'])),'before'=>'[redigido]','after'=>'[redigido]','occurrences'=>$change['occurrences']];$counts[$change['table']][$change['column']]=($counts[$change['table']][$change['column']]??0)+$change['occurrences'];}return ['counts'=>$counts,'skipped'=>$skipped,'samples'=>$samples];
    }
    public static function search_replace(array $i): array {
        if(!self::permission())return Result::fail('permission_denied','Escrita não autorizada.');
        if($i['search']==='')return Result::fail('search_required','Busca vazia não permitida.');
        $db=null;
        try {
            $db=DatabaseRead::connection();$sqls=[];
            foreach(self::tables($db,$i['tables']??null) as $table=>$type){
                if($type!=='BASE TABLE'||self::internal($table))continue;
                $r=DatabaseRead::checked($db,'SHOW FULL COLUMNS FROM '.self::q($table));$cols=$r->fetch_all(MYSQLI_ASSOC);$r->free();$pk=[];$text=[];
                foreach($cols as $c){if($c['Key']==='PRI')$pk[]=$c['Field'];if(preg_match('/char|text|json|blob/i',$c['Type'])&&!str_contains($c['Extra'],'GENERATED'))$text[]=$c['Field'];}
                if(isset($i['columns']))$text=array_values(array_intersect($text,$i['columns']));
                $text=array_values(array_diff($text,$pk));if(!$text)continue;
                if(!$pk)return Result::fail('sql_guard_unavailable','Search-replace exige chave primária em cada tabela selecionada.',['reason'=>'stable_identity_required','applied'=>false]);
                $pred=[];foreach($text as $col)$pred[]='LOCATE('.SqlMutationPlan::value($i['search']).',CAST('.self::q($col).' AS BINARY))>0';
                // No-op DML is only the planner's selection representation. The effect callback
                // below applies the serialization-aware changes under these same locks.
                $sqls[]='UPDATE '.self::q($table).' SET '.self::q($pk[0]).'='.self::q($pk[0]).' WHERE '.implode(' OR ',$pred);
            }
        }catch(\Throwable $e){return Result::fail('sql_guard_unavailable','Seleção de tabelas/colunas não verificável.',['reason'=>'search_replace_selection','applied'=>false]);}
        finally{if($db)$db->close();}
        if(!$sqls)return Result::ok(['preview'=>true,'applied'=>false,'changed'=>false,'selected_rows'=>0,'confirmation_required'=>false,'guard_contract'=>SqlMutationPlan::CONTRACT]);
        return SqlMutation::run('db/search-replace',$i,$sqls,static function($db)use($i){
            $counts=[];$skipped=[];$changed=0;
            foreach(self::replacement_stream($db,$i['search'],$i['replace'],$i['tables']??null,$i['columns']??null) as $c){
                if(!empty($c['skipped'])){$skipped[]=$c;continue;}
                $where=[];foreach($c['key'] as $k=>$v)$where[]=self::q($k).' <=> '.SqlMutationPlan::value($v);
                $where[]=self::q($c['column']).' <=> '.SqlMutationPlan::value($c['before']);
                $value=SqlMutationPlan::value($c['after']);if($c['column_type']==='json')$value='CONVERT('.$value.' USING utf8mb4)';
                DatabaseRead::checked($db,'UPDATE '.self::q($c['table']).' SET '.self::q($c['column']).'='.$value.' WHERE '.implode(' AND ',$where));
                if($db->affected_rows!==1)throw new \RuntimeException('replacement_conflict');
                $changed++;$counts[$c['table']][$c['column']]=($counts[$c['table']][$c['column']]??0)+$c['occurrences'];
            }
            return ['statement_results'=>[['index'=>0,'affected_rows'=>$changed]],'changed_cells'=>$changed,'counts'=>$counts,'skipped'=>$skipped];
        },static fn($db)=>self::replacements($db,$i['search'],$i['replace'],$i['tables']??null,$i['columns']??null),static function($table,$row,$schema)use($i){
            foreach($schema['columns'] as $column){$name=$column['Field'];
                if(in_array($name,$schema['pk'],true)||$row[$name]===null||!preg_match('/char|text|json|blob/i',$column['Type'])||isset($i['columns'])&&!in_array($name,$i['columns'],true))continue;
                $count=0;try{$row[$name]=self::replace_value($row[$name],$i['search'],$i['replace'],$count);}catch(\Throwable $ignored){}
            }return $row;
        });
    }
    public static function replace_confirmed(string $search,string $replace,?array $tables=null,?array $expected=null,?array $columns=null): array {
        $db=DatabaseRead::connection();try{DatabaseRead::checked($db,'START TRANSACTION');$locked=self::fingerprint($db,$tables,true);if($expected!==null&&$locked!==$expected){$db->rollback();return Result::fail('database_conflict','Seleção mudou desde a prévia.',['conflict'=>true]);}$backup=self::dump($db,$tables);$set=['counts'=>[],'skipped'=>[]];$changed=0;
            foreach(self::replacement_stream($db,$search,$replace,$tables,$columns) as $c){if(!empty($c['skipped'])){$set['skipped'][]=$c;continue;}$changed++;$set['counts'][$c['table']][$c['column']]=($set['counts'][$c['table']][$c['column']]??0)+$c['occurrences'];$quote=static fn($v)=>$v===null?'NULL':"CAST(X'".bin2hex((string)$v)."' AS BINARY)";$where=[];foreach($c['key'] as $k=>$v)$where[]=self::q($k).' <=> '.$quote($v);$where[]=self::q($c['column']).' <=> '.$quote($c['before']);DatabaseRead::checked($db,'UPDATE '.self::q($c['table']).' SET '.self::q($c['column']).'='.($c['column_type']==='json'?'CONVERT('.$quote($c['after']).' USING utf8mb4)':$quote($c['after'])).' WHERE '.implode(' AND ',$where));if($db->affected_rows!==1)throw new \RuntimeException('replacement_conflict');}
            $db->commit();wp_cache_flush();return Result::ok(['changed'=>$changed>0,'changed_cells'=>$changed,'counts'=>$set['counts'],'skipped'=>$set['skipped'],'backup_id'=>$backup['id'],'atomic'=>true]);
        }catch(\Throwable $e){$db->rollback();return Result::fail('search_replace_failed','Troca não concluída; transação revertida.',['applied'=>false,'reason'=>$e->getMessage()==='replacement_conflict'?'preimage_changed':'database_error','mysql_errno'=>(int)$e->getCode()]);}finally{$db->close();}
    }
}
