<?php
/** Presentation redaction, byte transport and bounded regular expressions. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class DataSafety {
	public static function secret_key(string $key): bool {
		return (bool)preg_match('/(?:pass(?:word|wd)?|secret|token|credential|api[_-]?key|private[_-]?key|authorization|session_tokens|application_passwords|activation_key|auth_key|salt)/i', $key);
	}
	/** This copy is for presentation only. Never feed it to recovery or comparison. */
	public static function rows(array $rows, ?string $table = null): array {
		$redacted = [];
		foreach ($rows as $index => &$row) {
			if (!is_array($row)) continue;
			$key = (string)($row['option_name'] ?? $row['meta_key'] ?? '');
			foreach ($row as $column => &$value) {
				$payload = in_array(strtolower((string)$column), ['option_value', 'meta_value'], true);
				$hide = self::secret_key((string)$column) || ($payload && ('' === $key || self::secret_key($key)));
				// Extensions may add sensitivity; they cannot unclassify built-in secrets.
				$hide = $hide || (bool)apply_filters('f3_mcp_sensitive_cell', false, $table, $column, $key);
				if ($hide) { $value = '[redigido]'; $redacted[] = $index . '.' . $column; }
			}
			unset($value);
		}
		unset($row);
		return ['rows' => $rows, 'redacted' => array_values(array_unique($redacted))];
	}
	public static function binary_extension(string $path): bool {
		return in_array(strtolower(pathinfo($path, PATHINFO_EXTENSION)), ['zip','gz','bz2','xz','7z','rar','tar','png','jpg','jpeg','gif','webp','avif','ico','pdf','woff','woff2','ttf','otf','eot','mo','mp3','mp4','mov','wav','ogg','flac','sqlite','db','exe','so','bin'], true);
	}
	public static function binary(string $bytes, string $path = ''): bool {
		return self::binary_extension($path) || str_contains($bytes, "\0") || 1 !== preg_match('//u', $bytes);
	}
	public static function bytes(string $bytes, string $path = ''): array {
		return self::binary($bytes, $path) ? ['encoding' => 'base64', 'content_base64' => base64_encode($bytes)] : ['encoding' => 'utf-8', 'content' => $bytes];
	}
}

final class RegexGuard {
	public static function run(callable $callback) {
		$old = [ini_get('pcre.backtrack_limit'), ini_get('pcre.recursion_limit')];
		ini_set('pcre.backtrack_limit', '100000'); ini_set('pcre.recursion_limit', '1000');
		try { return $callback(); }
		finally { ini_set('pcre.backtrack_limit', (string)$old[0]); ini_set('pcre.recursion_limit', (string)$old[1]); }
	}
	public static function validate(string $pattern): ?\WP_Error {
		if ('' === $pattern || strlen($pattern) > 4096) return new \WP_Error('invalid_grep_regex', 'PCRE deve conter delimitadores e ter até 4096 bytes.');
		return self::run(static fn() => false === @preg_match($pattern, '') ? new \WP_Error('invalid_grep_regex', 'PCRE inválida: confira delimitadores, modificadores e sintaxe; exemplo /error|fatal/i.') : null);
	}
	public static function match(string $pattern, string $text) {
		if (strlen($text) > 1048576) return new \WP_Error('regex_line_limit', 'Linha excede 1 MiB para avaliação PCRE.');
		return self::run(static function () use ($pattern, $text) {
			$result = @preg_match($pattern, $text);
			return false === $result ? new \WP_Error('regex_execution_failed', 'PCRE excedeu o orçamento ou o texto é incompatível com o padrão.') : $result;
		});
	}
}
