<?php
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SiteAdmin {
    public static function register(): void {
        Roles::register();
        Registry::add('site/set-admin-email','Altera e-mail administrativo autorizado sem link de confirmação; limpa pedido pendente.',['email'=>Registry::string()],['email'],static fn($i)=>self::option(['name'=>'admin_email','value'=>$i['email']]),[ConnectionTools::class,'permission'],false);
        Registry::add('site/set-language','Instala tradução oficial antes de trocar o idioma.',['locale'=>Registry::string()],['locale'],static fn($i)=>self::option(['name'=>'WPLANG','value'=>$i['locale']]),[ConnectionTools::class,'permission'],false);
        Registry::add('site/set-address','Altera home/siteurl em duas fases; opcionalmente substitui URLs em dados serializados. Exige destino HTTP/TLS alcançável; não administra DNS.',['home'=>Registry::string(),'siteurl'=>Registry::string(),'search_replace'=>Registry::boolean(),'confirm_token'=>Registry::string()],['home','siteurl'],[self::class,'address'],[ConnectionTools::class,'permission'],false);
        Registry::add('roles/list','Lista papéis e capacidades WordPress.',[],[],static fn()=>Result::ok(['roles'=>wp_roles()->roles]),'manage_options');
        Registry::add('roles/update','Cria/atualiza papel usando APIs WordPress, backup e revisão. Alteração exige prévia/confirm_token.',['role'=>Registry::string(),'name'=>Registry::string(),'capabilities'=>['type'=>'object','additionalProperties'=>['type'=>'boolean']],'confirm_token'=>Registry::string()],['role','name','capabilities'],[self::class,'role'],[ConnectionTools::class,'permission'],false);
    }
    public static function internal(string $name): bool {return str_starts_with($name,'f3_mcp_')||str_starts_with($name,'_transient_f3_mcp_')||str_starts_with($name,'_transient_timeout_f3_mcp_');}
    public static function option(array $i): array {
        global $wpdb;
        $name=$i['name']??'';
        if($name===''||self::internal($name)||!ConnectionContext::maintenance()&&MaintenanceTools::protected_option($name))return Result::fail('option_protected','Option interna ou fora do perfil; ajustes do canal usam system/settings-update.');
        if(in_array($name,['home','siteurl'],true))return self::address(['home'=>$name==='home'?$i['value']:get_option('home'),'siteurl'=>$name==='siteurl'?$i['value']:get_option('siteurl')]+array_intersect_key($i,['confirm_token'=>true]));
        if($name==='stylesheet')return current_user_can('switch_themes')?ThemePackages::activate(['stylesheet'=>(string)$i['value']]+array_intersect_key($i,['confirm_token'=>true])):Result::fail('permission_denied','Capacidade switch_themes necessária.');
        if(in_array($name,['template','current_theme'],true))return Result::fail('option_requires_theme_route','Informe o stylesheet em themes/activate; o WordPress deriva template/current_theme.',['required_ability'=>'themes/activate','required_fields'=>['stylesheet']]);
        if($name==='active_plugins')return Result::fail('option_requires_plugin_route','Ativação exige hooks e verificação do pacote. Use plugins/activate ou plugins/deactivate para o plugin exato.',['required_abilities'=>['plugins/activate','plugins/deactivate']]);
        if($name===$wpdb->prefix.'user_roles')return self::roles_option($i);
        if($name==='admin_email'&&!is_email($i['value']))return Result::fail('email_invalid','Endereço de e-mail inválido.');
        if($name==='WPLANG'){
            $locale=(string)$i['value'];if($locale==='en_US')$i['value']='';if($locale!==''&&$locale!=='en_US'&&!preg_match('/^[a-z]{2,3}(?:_[A-Za-z0-9]+){0,2}$/D',$locale))return Result::fail('locale_invalid','Locale inválido.');
            if($locale!==''&&$locale!=='en_US'&&!in_array($locale,get_available_languages(),true)){
                require_once ABSPATH.'wp-admin/includes/translation-install.php';require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
                if(!wp_download_language_pack($locale))return Result::fail('language_install_failed','Pacote não instalado; idioma preservado.');
            }
        }
        return Locks::run(['option:'.get_current_blog_id().':'.$name=>LOCK_EX],static function()use($i,$name){
            $missing=new \stdClass();$old=get_option($name,$missing);$backup=Backups::create_snapshot('options/update',['name'=>$name,'exists'=>$old!==$missing,'value'=>$old===$missing?null:$old]);if(is_wp_error($backup))return Result::error($backup);
            if($name==='cron'&&!is_array($i['value']))return Result::fail('cron_invalid','Cron precisa ser um array de eventos nativos.');
            $before=Probe::run();if(!Recovery::verified($before))return Result::fail('option_baseline_failed','Sonda inicial não aprovada; option preservada.',['probe_before'=>$before,'backup_id'=>$backup]);
            $result=$name==='WPLANG'&&$i['value']===''&&$old===$missing?Result::ok(['name'=>'WPLANG','changed'=>false,'new_value'=>'','effective_locale'=>'en_US','storage'=>'wordpress_default']):VerifiedOptions::update($name,$i);
            if($name==='admin_email'&&!empty($result['success'])){delete_option('new_admin_email');delete_option('adminhash');}
            if($name==='cron')wp_cache_delete('cron','options');
            $after=Probe::run();
            if(!Recovery::verified($after)){$old===$missing?delete_option($name):update_option($name,$old);return Result::fail('option_probe_failed','Sonda após gravação falhou; valor anterior restaurado.',['backup_id'=>$backup,'rolled_back'=>get_option($name,$missing)===$old,'probe_after'=>$after]);}
            if(DataSafety::secret_key($name))foreach(['old_value','new_value','value','requested_value','readback_value'] as $key)if(array_key_exists($key,$result))$result[$key]='[redigido]';
            return SafeOutput::error($result)+['backup_id'=>$backup,'probe_before'=>$before,'probe_after'=>$after];
        });
    }
    private static function roles_option(array $i): array { return Roles::replace($i); }
    public static function role(array $i): array { return Roles::update($i); }
    public static function address(array $i): array {
        foreach(['home','siteurl'] as $key)if(!filter_var($i[$key],FILTER_VALIDATE_URL)||!in_array(wp_parse_url($i[$key],PHP_URL_SCHEME),['http','https'],true))return Result::fail('site_url_invalid','URL absoluta HTTP/HTTPS necessária.');
        return Locks::run(['site-address'=>LOCK_EX],static fn()=>Phase::run('site/set-address',$i,static fn()=>['home'=>get_option('home'),'siteurl'=>get_option('siteurl')],static function($old)use($i){
            foreach(['home','siteurl'] as $key){$r=wp_safe_remote_get($i[$key],['timeout'=>15,'cookies'=>[],'redirection'=>0]);if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return Result::fail('site_destination_unavailable','Destino não respondeu 200; endereços preservados.');}
            $backup=Backups::create_snapshot('site/set-address',$old);if(is_wp_error($backup))return Result::error($backup);
            $replace=null;if(!empty($i['search_replace'])){$replace=DatabaseAdmin::replace_confirmed($old['home'],$i['home']);if(empty($replace['success']))return $replace;}
            update_option('home',untrailingslashit($i['home']));update_option('siteurl',untrailingslashit($i['siteurl']));flush_rewrite_rules(false);
            $probe=Probe::run();if(!Recovery::verified($probe)){update_option('home',$old['home']);update_option('siteurl',$old['siteurl']);flush_rewrite_rules(false);if(!empty($replace['backup_id']))DatabaseAdmin::restore_confirmed($replace['backup_id']);return Result::fail('site_address_probe_failed','Sonda falhou; endereços restaurados.',['backup_id'=>$backup,'probe_after'=>$probe]);}
            return Result::ok(['changed'=>$old['home']!==get_option('home')||$old['siteurl']!==get_option('siteurl'),'backup_id'=>$backup,'home'=>get_option('home'),'siteurl'=>get_option('siteurl'),'probe_after'=>$probe,'search_replace'=>$replace]);
        }));
    }
}
