<?php
declare(strict_types=1);

namespace WpMcpUltimate\OAuth;

/**
 * Dynamic Client Registration (RFC 7591), public clients only (PKCE,
 * no client secret) — matches how MCP clients register themselves.
 */
final class RegistrationEndpoint {

	private const RATE_LIMIT         = 5;      // Registrations per IP per window.
	private const RATE_LIMIT_WINDOW  = 3600;   // 1 hour.
	private const MAX_REDIRECT_URIS  = 5;      // Per client.
	private const MAX_URI_LENGTH     = 2000;   // Per redirect_uri.
	private const MAX_CLIENT_NAME    = 200;    // Characters.

	public static function handle(): void {
		Responses::maybe_handle_preflight();

		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			Responses::oauth_error( 'invalid_request', 'Only POST is supported.', 405 );
		}

		// Registration is unauthenticated by design (RFC 7591 public
		// clients), so it must be bounded: rate-limit per IP and cap the
		// total number of stored clients (existing registrations are never evicted).
		// NOTE: REMOTE_ADDR is the direct peer; behind a reverse proxy or CDN
		// every visitor may share one address, making this a per-window cap
		// for the whole site rather than per client. That is intentionally
		// fail-safe (it can only over-limit, never under-limit).
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
        try{
            $rate=\Fator3\McpFiles\Locks::run(['oauth-registration-rate'=>LOCK_EX],static function()use($ip){
                $bucket=(int)floor(time()/self::RATE_LIMIT_WINDOW);$key=hash_hmac('sha256',($ip?:'unknown').'|'.$bucket,wp_salt('auth'));
                $state=\Fator3\McpFiles\StateStore::get('registration-rate',$key)??['attempts'=>0,'expires'=>($bucket+1)*self::RATE_LIMIT_WINDOW,'time'=>time()];
                if($state['attempts']>=self::RATE_LIMIT)return ['success'=>false];
                $state['attempts']++;\Fator3\McpFiles\StateStore::put('registration-rate',$key,$state);return ['success'=>true];
            });
            if(empty($rate['success']))Responses::oauth_error('invalid_request','Too many registration attempts. Try again later.',429);
        }catch(\Throwable $e){Responses::oauth_error('temporarily_unavailable','Registration state unavailable.',503);}

		$raw  = file_get_contents( 'php://input', false, null, 0, 65537 );
        if (strlen((string)$raw)>65536) Responses::oauth_error('invalid_client_metadata','Registration exceeds 64 KiB.',413);
		$body = json_decode( (string) $raw, true );

		if ( ! is_array( $body ) || array_is_list($body) ) {
			Responses::oauth_error( 'invalid_client_metadata', 'Request body must be a JSON object.' );
		}

		$redirect_uris = $body['redirect_uris'] ?? null;
		if ( ! is_array( $redirect_uris ) || !array_is_list($redirect_uris) || empty( $redirect_uris ) ) {
			Responses::oauth_error( 'invalid_redirect_uri', 'redirect_uris is required and must be a non-empty array.' );
		}
		if ( count( $redirect_uris ) > self::MAX_REDIRECT_URIS ) {
			Responses::oauth_error( 'invalid_redirect_uri', 'Too many redirect_uris.' );
		}

		foreach ( $redirect_uris as $uri ) {
			if ( ! is_string( $uri ) || strlen( $uri ) > self::MAX_URI_LENGTH || ! self::is_valid_redirect_uri( $uri ) ) {
				Responses::oauth_error( 'invalid_redirect_uri', 'Every redirect_uri must be an https:// URL, or an http:// loopback URL.' );
			}
		}

		$application_type=$body['application_type']??'web';
        if(!in_array($application_type,['web','native'],true))Responses::oauth_error('invalid_client_metadata','application_type must be web or native.');
        foreach($redirect_uris as $uri)if($application_type==='web'&&wp_parse_url($uri,PHP_URL_SCHEME)!=='https')Responses::oauth_error('invalid_redirect_uri','HTTP loopback redirects require application_type native.');
        if(($body['token_endpoint_auth_method']??'none')!=='none')Responses::oauth_error('invalid_client_metadata','Only public clients using PKCE are supported.');
        $client_name = isset( $body['client_name'] ) && is_string( $body['client_name'] )
			? sanitize_text_field( mb_substr( $body['client_name'], 0, self::MAX_CLIENT_NAME ) )
			: 'MCP Client';

		$client_id = bin2hex( random_bytes( 16 ) );
		$issued_at = time();

		try{$saved = TokenStore::save_client(
			$client_id,
			array(
				'client_name'   => $client_name,
                'application_type'=>$application_type,
                'issuer'=>untrailingslashit(home_url()),
				'redirect_uris' => array_values( $redirect_uris ),
				'created'       => $issued_at,
			)
		);

        }catch(\Throwable $e){Responses::oauth_error('temporarily_unavailable','Client registration was not persisted.',503);}
		if (is_wp_error($saved)) Responses::oauth_error($saved->get_error_code(), $saved->get_error_message(), 429);
		if ($saved !== true) Responses::oauth_error('temporarily_unavailable', 'Client registration was not persisted.', 503);
		Responses::json(
			array(
				'client_id'                  => $client_id,
				'client_id_issued_at'        => $issued_at,
                'application_type'=>$application_type,
                'issuer'=>untrailingslashit(home_url()),
				'client_name'                => $client_name,
				'redirect_uris'              => array_values( $redirect_uris ),
				'grant_types'                => array( 'authorization_code', 'refresh_token' ),
				'response_types'             => array( 'code' ),
				'token_endpoint_auth_method' => 'none',
			),
			201
		);
	}

	public static function is_valid_redirect_uri( string $uri ): bool {
		$parts = wp_parse_url( $uri );
		if (strlen($uri)>2000 || preg_match('/[\x00-\x20]/',$uri) || isset($parts['fragment']) || isset($parts['user']) || isset($parts['pass']) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return false;
		}

		if ( 'https' === $parts['scheme'] ) {
			return true;
		}

		// RFC 8252: native/local clients get an http loopback exception.
		if ( 'http' === $parts['scheme'] && in_array( $parts['host'], array( '127.0.0.1', 'localhost', '::1', '[::1]' ), true ) ) {
			return true;
		}

		return false;
	}
}
