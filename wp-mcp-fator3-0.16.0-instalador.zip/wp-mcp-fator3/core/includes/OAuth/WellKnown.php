<?php
declare(strict_types=1);

namespace WpMcpUltimate\OAuth;

/**
 * Serves OAuth Authorization Server Metadata (RFC 8414) and Protected
 * Resource Metadata (RFC 9728).
 *
 * Both documents are, per spec, expected at the true origin root. This
 * site's WordPress install lives under a subdirectory (e.g. /blog) with
 * an unrelated application at the domain root, so the plugin cannot own
 * the true root — it serves both documents relative to home_url()
 * instead, which is the common fallback most MCP/OAuth clients (and
 * WordPress plugins in the same situation) accept.
 */
final class WellKnown {

	public static function handle( string $which, ?string $route = null ): void {
		if ( 'authorization-server' === $which ) {
			self::send_authorization_server_metadata();
			return;
		}

		self::send_protected_resource_metadata($route);
	}

	private static function send_authorization_server_metadata(): void {
		$origin = untrailingslashit( home_url() );

		Responses::json(
			array(
				'issuer'                                 => $origin,
                'client_id_metadata_document_supported' => true,
                'authorization_response_iss_parameter_supported'=>true,
				'authorization_endpoint'                 => $origin . '/wp-mcp-oauth/authorize',
				'token_endpoint'                          => $origin . '/wp-mcp-oauth/token',
				'registration_endpoint'                   => $origin . '/wp-mcp-oauth/register',
				'response_types_supported'                => array( 'code' ),
				'grant_types_supported'                   => array( 'authorization_code', 'refresh_token' ),
				'code_challenge_methods_supported'         => array( 'S256' ),
				'token_endpoint_auth_methods_supported'    => array( 'none' ),
				'scopes_supported'                         => array('mcp','mcp:read','mcp:content','mcp:maintenance','mcp:custom'),
			)
		);
	}

	private static function send_protected_resource_metadata(?string $route = null): void {
		$origin = untrailingslashit( home_url() );

		Responses::json(
			array(
				'resource'               => \Fator3\McpFiles\ConnectionEndpoints::url($route ?? \Fator3\McpFiles\ConnectionEndpoints::LEGACY),
				'authorization_servers'  => array( $origin ),
			)
		);
	}
}
