<?php
declare(strict_types=1);

namespace WpMcpUltimate\OAuth;

/**
 * Token endpoint: exchanges an authorization code (with PKCE) or a
 * refresh token for a Bearer access token.
 */
final class TokenEndpoint {

	public static function handle(): void {
		Responses::maybe_handle_preflight();

		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			Responses::oauth_error( 'invalid_request', 'Only POST is supported.', 405 );
		}

		$params      = self::parse_body();
        foreach (['grant_type','client_id','code','code_verifier','redirect_uri','refresh_token','resource'] as $field) {
            if (isset($params[$field]) && (!is_string($params[$field]) || strlen($params[$field]) > 4096)) Responses::oauth_error('invalid_request', 'OAuth fields must be bounded scalar strings.');
        }
		$grant_type  = $params['grant_type'] ?? '';

		if (!in_array($grant_type, ['authorization_code','refresh_token'], true)) Responses::oauth_error('unsupported_grant_type', 'Use authorization_code or refresh_token.');
		$result = TokenStore::exchange($params);
		if (is_wp_error($result)) Responses::oauth_error($result->get_error_code(), $result->get_error_message(), $result->get_error_code() === 'temporarily_unavailable' ? 503 : 400);
		Responses::json($result);
	}

	private static function parse_body(): array {
		// Some SAPIs expose the header only as HTTP_CONTENT_TYPE.
		$content_type = $_SERVER['CONTENT_TYPE'] ?? ( $_SERVER['HTTP_CONTENT_TYPE'] ?? '' );

		if ( false !== stripos( $content_type, 'application/json' ) ) {
			$raw = (string) file_get_contents('php://input', false, null, 0, 65537);
            if (strlen($raw) > 65536) Responses::oauth_error('invalid_request', 'Token request exceeds 64 KiB.', 413);
            $decoded = json_decode($raw, true);
            return is_array($decoded) && !array_is_list($decoded) ? $decoded : [];
		}

		// application/x-www-form-urlencoded (the RFC 6749-mandated content type).
		return wp_unslash($_POST); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- token endpoint is a machine-to-machine OAuth grant exchange, not a WP form submission.
	}
}
