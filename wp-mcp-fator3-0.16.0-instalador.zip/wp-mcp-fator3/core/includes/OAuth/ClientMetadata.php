<?php
/** Public-client CIMD resolution. Never called while exchanging a token in a SQL transaction. */
declare(strict_types=1);
namespace WpMcpUltimate\OAuth;
use Fator3\McpFiles\Http;

final class ClientMetadata {
    public static function valid_id(string $id): bool {
        if(strlen($id)>2048||preg_match('/[\x00-\x20]/',$id))return false;
        $p=wp_parse_url($id);$path=rawurldecode($p['path']??'');
        return ($p['scheme']??'')==='https'&&!empty($p['host'])&&$path!==''&&$path!=='/'&&!isset($p['user'],$p['pass'])&&!isset($p['fragment'])&&!isset($p['query'])&&!str_contains($path,'\\')&&!preg_match('~(^|/)\.\.?(/|$)~',$path)&&empty($p['user'])&&empty($p['pass']);
    }
    public static function resolve(string $id,?array $stored): ?array {
        if(!self::valid_id($id))return null;
        if($stored&&($stored['issuer']??'')!==untrailingslashit(home_url()))return null;
        if($stored&&($stored['metadata_expires']??0)>time())return $stored;
        $safe=Http::validate_public_url($id);if(is_wp_error($safe))return null;
        // Redirects are refused. The client_id is an exact HTTPS document identity.
        $r=wp_safe_remote_get($id,['timeout'=>5,'redirection'=>0,'cookies'=>[],'sslverify'=>true,'limit_response_size'=>65537,'headers'=>['Accept'=>'application/json']]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return null;
        $type=strtolower(trim(explode(';',(string)wp_remote_retrieve_header($r,'content-type'))[0]));
        if($type!=='application/json')return null;$bytes=wp_remote_retrieve_body($r);if(strlen($bytes)>65536)return null;
        $doc=json_decode($bytes,true);if(!is_array($doc)||array_is_list($doc)||($doc['client_id']??'')!==$id||!is_string($doc['client_name']??null)||$doc['client_name']===''||strlen($doc['client_name'])>200)return null;
        if(($doc['token_endpoint_auth_method']??'none')!=='none'||!is_array($doc['redirect_uris']??null)||!array_is_list($doc['redirect_uris'])||!count($doc['redirect_uris'])||count($doc['redirect_uris'])>5)return null;
        foreach($doc['redirect_uris'] as $uri)if(!is_string($uri)||strlen($uri)>2000||!RegistrationEndpoint::is_valid_redirect_uri($uri))return null;
        foreach(['grant_types'=>['authorization_code','refresh_token'],'response_types'=>['code']] as $field=>$allowed)if(isset($doc[$field])&&(!is_array($doc[$field])||array_diff($doc[$field],$allowed)))return null;
        $cache=strtolower((string)wp_remote_retrieve_header($r,'cache-control'));$ttl=300;
        if(preg_match('/(?:^|,)\s*max-age\s*=\s*(\d+)/',$cache,$m))$ttl=min(3600,(int)$m[1]);
        if(str_contains($cache,'no-cache')||str_contains($cache,'no-store'))$ttl=0;
        $result=['client_id'=>$id,'client_name'=>sanitize_text_field($doc['client_name']),'redirect_uris'=>array_values(array_unique($doc['redirect_uris'])),'token_endpoint_auth_method'=>'none','issuer'=>untrailingslashit(home_url()),'metadata_document'=>true,'metadata_expires'=>time()+$ttl,'status'=>'active','time'=>$stored['time']??time()];
        $persist=$result;if(str_contains($cache,'no-store')){$persist['client_name']='MCP Client';$persist['redirect_uris']=[];}
        $saved=TokenStore::save_client($id,$persist);return $saved===true?$result:null;
    }
}
