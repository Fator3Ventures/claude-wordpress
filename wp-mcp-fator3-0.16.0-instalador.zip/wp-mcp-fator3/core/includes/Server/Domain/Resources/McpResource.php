<?php

/**
 * MCP Resource component.
 *
 * @package McpAdapter
 */

declare( strict_types=1 );

namespace WpMcpUltimate\Server\Domain\Resources;

use WpMcpUltimate\Server\Domain\Contracts\McpComponentInterface;
use WpMcpUltimate\Server\Domain\Utils\McpValidator;
use WpMcpUltimate\Server\Domain\Utils\RevisionProjectionTrait;
use WpMcpUltimate\Server\Infrastructure\ErrorHandling\Contracts\McpErrorHandlerInterface;
use WpMcpUltimate\Server\Infrastructure\Observability\FailureReason;
use WpMcpUltimate\McpSchema\Record\Resource;
use WpMcpUltimate\McpSchema\Schema;
use WP_Error;

/**
 * Resource component providing unified execution and permission checks.
 *
 * This class supports multiple ways to register resources:
 *
 * 1. Array configuration:
 * ```php
 * $resource = McpResource::fromArray([
 *     'uri'         => 'WordPress://local/readme',
 *     'title'       => 'README',
 *     'description' => 'Example resource',
 *     'handler'     => fn() => 'Hello',
 *     'permission'  => fn() => true,
 * ]);
 * ```
 *
 * 2. From WordPress Ability (ability-backed):
 * ```php
 * $resource = McpResource::fromAbility($ability);
 * ```
 *
 * McpResource stores revision-neutral configuration for MCP projection. Internal
 * adapter metadata and execution wiring live on this class and are never
 * exposed to MCP clients. Use get_protocol_record() for protocol responses.
 *
 * @since 0.5.0
 */
final class McpResource implements McpComponentInterface {
	use RevisionProjectionTrait;

	// =========================================================================
	// Runtime Properties
	// =========================================================================

	/**
	 * Ability used for execution/permission checks (ability-backed resources).
	 *
	 * @var \WP_Ability|null
	 */
	private ?\WP_Ability $ability = null;

	/**
	 * Direct execution handler (callable-backed resources).
	 *
	 * @var callable|null
	 */
	private $handler = null;

	/**
	 * Direct permission callback (callable-backed resources).
	 *
	 * @var callable|null
	 */
	private $permission_callback = null;

	/**
	 * Internal adapter metadata (never exposed to clients).
	 *
	 * @var array<string, mixed>
	 */
	private array $adapter_meta = array();

	/**
	 * Observability context tags for logging/metrics.
	 *
	 * @var array<string, mixed>
	 */
	private array $observability_context = array();

	// =========================================================================
	// Constructor
	// =========================================================================

	/**
	 * Private constructor - use factory methods.
	 *
	 * @param array<string, mixed> $resource_data Revision-neutral Resource data.
	 */
	private function __construct( array $resource_data ) {
		$this->initialize_protocol_data( $resource_data );
	}

	// =========================================================================
	// Factory Methods
	// =========================================================================

	/**
	 * @param array $config The resource configuration array.
	 *
	 * @return self|\WP_Error
	 */
	public static function fromArray( array $config ) {
		if ( empty( $config['uri'] ) ) {
			return new WP_Error( 'mcp_resource_missing_uri', 'Resource configuration must include a "uri" field.' );
		}

		if ( ! isset( $config['handler'] ) || ! is_callable( $config['handler'] ) ) {
			return new WP_Error( 'mcp_resource_missing_handler', 'Resource configuration must include a callable "handler" field.' );
		}

		$uri = trim( $config['uri'] );

		if ( ! McpValidator::validate_resource_uri( $uri ) ) {
			return new WP_Error( 'mcp_resource_invalid_uri', 'Resource "uri" must be a valid RFC 3986 URI with a scheme.' );
		}

		$name = isset( $config['name'] ) ? trim( $config['name'] ) : $uri;
		if ( '' === $name ) {
			return new WP_Error( 'mcp_resource_missing_name', 'Resource "name" cannot be empty.' );
		}

		$resource_data = array(
			'name' => $name,
			'uri'  => $uri,
		);

		if ( isset( $config['title'] ) ) {
			$resource_data['title'] = $config['title'];
		}

		if ( isset( $config['description'] ) ) {
			$resource_data['description'] = $config['description'];
		}

		// Include mimeType when non-empty. The value itself is not checked.
		if ( isset( $config['mimeType'] ) ) {
			$mime_type = trim( $config['mimeType'] );
			if ( '' !== $mime_type ) {
				$resource_data['mimeType'] = $mime_type;
			}
		}

		// Include size only when > 0.
		if ( isset( $config['size'] ) && $config['size'] > 0 ) {
			$resource_data['size'] = $config['size'];
		}

		// Validate and include icons if set.
		if ( isset( $config['icons'] ) && is_array( $config['icons'] ) && ! empty( $config['icons'] ) ) {
			$icons_result = McpValidator::validate_icons_array( $config['icons'] );
			if ( ! empty( $icons_result['valid'] ) ) {
				$resource_data['icons'] = $icons_result['valid'];
			}
		}

		$resource_meta = McpValidator::normalize_meta( $config['meta'] ?? null );
		if ( null !== $resource_meta ) {
			$resource_data['_meta'] = $resource_meta;
		}

		if ( isset( $config['annotations'] ) && is_array( $config['annotations'] ) && ! empty( $config['annotations'] ) ) {
			$resource_data['annotations'] = $config['annotations'];
		}

		$instance          = new self( $resource_data );
		$instance->handler = $config['handler'];

		if ( isset( $config['permission'] ) && is_callable( $config['permission'] ) ) {
			$instance->permission_callback = $config['permission'];
		}

		$instance->observability_context = array(
			'component_type' => 'resource',
			'resource_uri'   => $uri,
			'source'         => 'array',
		);

		return $instance;
	}

	/**
	 * Create an ability-backed MCP resource.
	 *
	 * @param \WP_Ability $ability WordPress ability.
	 * @param \WpMcpUltimate\Server\Infrastructure\ErrorHandling\Contracts\McpErrorHandlerInterface|null $error_handler Optional error handler.
	 *
	 * @return self|\WP_Error
	 */
	public static function fromAbility( \WP_Ability $ability, ?McpErrorHandlerInterface $error_handler = null ) {
		$resource_data = RegisterAbilityAsMcpResource::build( $ability, $error_handler );
		if ( $resource_data instanceof WP_Error ) {
			return $resource_data;
		}

		$instance               = new self( $resource_data['resource_data'] );
		$instance->adapter_meta = $resource_data['adapter_meta'];
		$instance->ability      = $ability;

		$instance->observability_context = array(
			'component_type' => 'resource',
			'resource_uri'   => $resource_data['resource_data']['uri'],
			'ability_name'   => $ability->get_name(),
			'source'         => 'ability',
		);

		return $instance;
	}

	// =========================================================================
	// McpComponentInterface Implementation
	// =========================================================================

	/**
	 * Get the clean protocol record for one revision.
	 *
	 * @param \WpMcpUltimate\McpSchema\Schema $schema Selected schema.
	 * @since n.e.x.t
	 */
	public function get_protocol_record( Schema $schema ): Resource {
		return $this->project_record( $schema, Resource::class, $this->protocol_data() );
	}

	/**
	 * Get the neutral resource URI.
	 *
	 * @since n.e.x.t
	 */
	public function get_uri(): string {
		return (string) ( $this->protocol_data()['uri'] ?? '' );
	}

	/**
	 * Execute the resource read.
	 *
	 * @param mixed $arguments Read arguments (may be empty).
	 *
	 * @return mixed
	 */
	public function execute( $arguments ) {
		// Ability-backed resources match existing behavior: no args passed to abilities.
		if ( null !== $this->ability ) {
			try {
				return $this->ability->execute();
			} catch ( \Throwable $throwable ) {
				return new WP_Error(
					'mcp_execution_failed',
					$throwable->getMessage(),
					array( 'error_type' => get_class( $throwable ) )
				);
			}
		}

		if ( null !== $this->handler ) {
			try {
				return call_user_func( $this->handler, $arguments );
			} catch ( \Throwable $throwable ) {
				return new WP_Error(
					'mcp_execution_failed',
					$throwable->getMessage(),
					array( 'error_type' => get_class( $throwable ) )
				);
			}
		}

		return new WP_Error( 'mcp_resource_no_handler', 'No resource execution strategy configured.' );
	}

	/**
	 * Check whether the current request has permission to read this resource.
	 *
	 * @param mixed $arguments Read arguments (may be empty).
	 *
	 * @return bool|\WP_Error
	 */
	public function check_permission( $arguments ) {
		// Ability-backed resources match existing behavior: no args passed to abilities.
		if ( null !== $this->ability ) {
			try {
				return $this->ability->check_permissions();
			} catch ( \Throwable $throwable ) {
				return new WP_Error(
					'mcp_permission_check_failed',
					$throwable->getMessage(),
					array( 'error_type' => get_class( $throwable ) )
				);
			}
		}

		if ( null !== $this->permission_callback ) {
			try {
				$result = call_user_func( $this->permission_callback, $arguments );

				return $result instanceof WP_Error ? $result : (bool) $result;
			} catch ( \Throwable $throwable ) {
				return new WP_Error(
					'mcp_permission_check_failed',
					$throwable->getMessage(),
					array( 'error_type' => get_class( $throwable ) )
				);
			}
		}

		return new WP_Error(
			'mcp_permission_denied',
			'Access denied.',
			array( 'failure_reason' => FailureReason::NO_PERMISSION_STRATEGY )
		);
	}

	/**
	 * Get internal adapter metadata for this resource.
	 *
	 * @return array<string, mixed>
	 */
	public function get_adapter_meta(): array {
		return $this->adapter_meta;
	}

	/**
	 * Get observability context tags for logging/metrics.
	 *
	 * @return array<string, mixed>
	 */
	public function get_observability_context(): array {
		return $this->observability_context;
	}
}
