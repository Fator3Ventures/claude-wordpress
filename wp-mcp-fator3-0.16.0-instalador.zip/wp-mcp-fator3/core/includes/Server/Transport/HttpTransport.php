<?php
/**
 * MCP HTTP Transport for WordPress - MCP 2025-06-18 Compliant
 *
 * This transport implements the MCP Streamable HTTP specification and can work
 * both with and without the mcp-wordpress-remote proxy.
 *
 * @package McpAdapter
 */

declare( strict_types=1 );

namespace WpMcpUltimate\Server\Transport;

use WpMcpUltimate\Server\Transport\Contracts\McpRestTransportInterface;
use WpMcpUltimate\Server\Transport\Infrastructure\HttpRequestContext;
use WpMcpUltimate\Server\Transport\Infrastructure\HttpRequestHandler;
use WpMcpUltimate\Server\Transport\Infrastructure\McpTransportContext;
use WpMcpUltimate\Server\Transport\Infrastructure\McpTransportHelperTrait;

/**
 * MCP HTTP Transport - Unified transport for both proxy and direct clients
 *
 * Implements MCP 2025-06-18 Streamable HTTP specification
 */
class HttpTransport implements McpRestTransportInterface {
	use McpTransportHelperTrait;

	/**
	 * The HTTP request handler.
	 *
	 * @var \WpMcpUltimate\Server\Transport\Infrastructure\HttpRequestHandler
	 */
	protected HttpRequestHandler $request_handler;

	/**
	 * Initialize the class and register routes
	 *
	 * @param \WpMcpUltimate\Server\Transport\Infrastructure\McpTransportContext $transport_context The transport context.
	 */
	public function __construct( McpTransportContext $transport_context ) {
		$this->request_handler = new HttpRequestHandler( $transport_context );
		add_action( 'rest_api_init', array( $this, 'register_routes' ), 16 );
	}

	/**
	 * Register MCP HTTP routes
	 */
	public function register_routes(): void {
		// Get server info from request handler's transport context
		$server = $this->request_handler->get_transport_context()->mcp_server;

        $owned = \Fator3\McpFiles\ConnectionEndpoints::is_owned($server);
        $routes = $owned ? \Fator3\McpFiles\ConnectionEndpoints::routes() : ['/' . trim($server->get_server_route_namespace(), '/') . '/' . trim($server->get_server_route(), '/')];
        foreach ($routes as $route) {
            $existing = rest_get_server()->get_routes()[$route] ?? [];
            if ($existing) {
                $ours = false;
                foreach ($existing as $endpoint) if (is_array($endpoint) && ($endpoint['callback'] ?? null) === [$this, 'handle_request']) $ours = true;
                if ($owned) \Fator3\McpFiles\ConnectionEndpoints::recorded($route, $ours, [$this, 'handle_request']);
                continue;
            }
            // The namespace may contain slashes; split relative to the configured namespace.
            $ns = trim($server->get_server_route_namespace(), '/');
            if (str_starts_with($route, '/' . $ns . '/')) $path = substr($route, strlen($ns) + 2);
            else { $ns = 'mcp'; $path = substr($route, strlen('/mcp/')); }
            register_rest_route($ns, $path, ['methods' => ['POST', 'GET', 'DELETE'], 'callback' => [$this, 'handle_request'], 'permission_callback' => [$this, 'check_permission']]);
            if ($owned) \Fator3\McpFiles\ConnectionEndpoints::recorded($route, true, [$this, 'handle_request']);
        }
	}

	/**
	 * Check if the user has permission to access the MCP API
	 *
	 * @param \WP_REST_Request<array<string, mixed>> $request The request object.
	 *
	 * @return bool True if the user has permission, false otherwise.
	 */
	public function check_permission( \WP_REST_Request $request ) {
		$context = new HttpRequestContext( $request );
        $origin=(string)$request->get_header('origin');
        if($origin!=='') {
            $normalize=static function($url) { $p=wp_parse_url($url);if(!$p||!in_array($p['scheme']??'',['http','https'],true)||empty($p['host'])||isset($p['user'])||isset($p['pass'])||isset($p['query'])||isset($p['fragment'])||!in_array($p['path']??'',['','/'],true))return null;return strtolower($p['scheme'].'://'.$p['host']).':'.($p['port']??($p['scheme']==='https'?443:80)); };
            $actual=$normalize($origin);$home=wp_parse_url(home_url('/'));$base=$home['scheme'].'://'.$home['host'].(isset($home['port'])?':'.$home['port']:'');
            $allowed=array_filter(array_map($normalize,array_merge([$base],(array)get_option('f3_mcp_allowed_origins',[]))));
            if($actual===null||!in_array($actual,$allowed,true))return new \WP_Error('mcp_origin_forbidden','Origem não autorizada.',['status'=>403]);
        }

		// Check permission using callback or default
		$transport_context = $this->request_handler->get_transport_context();

		if ( null !== $transport_context->transport_permission_callback ) {
			try {
				$allowed = call_user_func($transport_context->transport_permission_callback, $context->request);
				return !is_wp_error($allowed) && true === $allowed;
			} catch (\Throwable $error) {
				return false;
			}
		}
		$user_capability = apply_filters( 'f3_mcp_default_transport_permission_user_capability', 'edit_posts', $context );

		// Validate that the filtered capability is a non-empty string
		if ( ! is_string( $user_capability ) || empty( $user_capability ) ) {
			$user_capability = 'edit_posts';
		}

		$user_has_capability = current_user_can( $user_capability ); // phpcs:ignore WordPress.WP.Capabilities.Undetermined -- Capability is filtered and defaults to 'edit_posts'

		if ( ! $user_has_capability ) {
			$user_id = get_current_user_id();
			$this->request_handler->get_transport_context()->error_handler->log(
				sprintf( 'Permission denied for MCP API access. User ID %d does not have capability "%s"', $user_id, $user_capability ),
				array( 'HttpTransport::check_permission' )
			);
		}

		return $user_has_capability;
	}

	/**
	 * Handle HTTP requests according to MCP 2025-06-18 specification
	 *
	 * @param \WP_REST_Request<array<string, mixed>> $request The request object.
	 *
	 * @return \WP_REST_Response
	 */
	public function handle_request( \WP_REST_Request $request ): \WP_REST_Response {
		$context = new HttpRequestContext( $request );

		$response = $this->request_handler->handle_request( $context );
        // Observability failure must not turn an already executed mutation into a retry.
        try { \Fator3\McpFiles\ConnectionStatus::observe($request, $response); } catch (\Throwable $ignored) {}
        return $response;
	}
}
