<?php
/**
 * System method handlers for MCP requests.
 *
 * @package McpAdapter
 */

declare( strict_types=1 );

namespace WpMcpUltimate\Server\Handlers\System;

use WpMcpUltimate\Server\McpRequestContext;
use WpMcpUltimate\McpSchema\Record\PingRequest;

/**
 * Handles system-related MCP methods.
 */
class SystemHandler {
	/**
	 * Handles the ping request.
	 *
	 * @param \WpMcpUltimate\McpSchema\Record\PingRequest $request Validated request.
	 * @param \WpMcpUltimate\Server\McpRequestContext $request_context Exact request context.
	 * @return array<string, mixed> Logical empty result.
	 * @since n.e.x.t
	 */
	public function ping( PingRequest $request, McpRequestContext $request_context ): array {
		unset( $request, $request_context );
		return array();
	}
}
