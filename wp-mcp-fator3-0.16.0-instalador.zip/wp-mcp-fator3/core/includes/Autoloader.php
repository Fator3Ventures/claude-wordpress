<?php
declare(strict_types=1);

namespace WpMcpUltimate;

final class Autoloader {
    private static bool $registered = false;

    public static function register(): bool {
        if (self::$registered) {
            return true;
        }

        spl_autoload_register([self::class, 'autoload']);
        self::$registered = true;
        return true;
    }

    private static function autoload(string $class): void {
        $schema_prefix='WpMcpUltimate\\McpSchema\\';
        if(str_starts_with($class,$schema_prefix)) {
            $file=WP_MCP_ULTIMATE_DIR.'vendor/php-mcp-schema/src/'.str_replace('\\','/',substr($class,strlen($schema_prefix))).'.php';
            if(is_file($file))require_once $file;
            return;
        }
        $prefix = 'WpMcpUltimate\\';
        if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
            return;
        }

        $relative = substr($class, strlen($prefix));
        $file = WP_MCP_ULTIMATE_DIR . 'includes/' . str_replace('\\', '/', $relative) . '.php';

        if (file_exists($file)) {
            require_once $file;
        }
    }
}
