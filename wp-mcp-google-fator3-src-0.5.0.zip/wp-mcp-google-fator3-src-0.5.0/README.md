# WP MCP Google Fator3 0.5.0 - pacote-fonte

Release integral de 30/09/2026. Este ZIP nao e instalavel e deve ficar fora da pasta publica do WordPress.

- `wp-mcp-google-fator3/`: codigo, testes, composer.lock, README, CHANGELOG, CONTRACTS, docs e referencias Cloud Shell original/revisada.
- `guia-wp-mcp-google-fator3-0.5.0.md`: guia consolidado, migracao, validacao e matriz de entrega.
- `integration/`: sondas nativas e README com dependencias, variaveis e ordem de execucao.
- `evidence/`: resultados finais e inventario do instalador. APIs Google/e-mail/distribuicao foram simulados. Nenhuma implantacao em producao.
- `fixtures/`: bases antigas e dependencias somente para comparacao, com licencas preservadas. Nao sao a release para instalar.
- `MANIFEST.sha256.json`: hashes dos arquivos deste pacote, exceto o proprio manifesto.

O instalador separado e `wp-mcp-google-fator3-0.5.0.zip`. Para reproduzi-lo, no diretorio do codigo execute `python3 build/build.py --output /tmp/wp-mcp-google-fator3-0.5.0.zip`. O build usa allowlist e indices em todas as pastas, sem documentos/scripts publicos nem .htaccess. Gates e evidencias pertencem ao codigo entregue; qualquer alteracao posterior requer revalidar os gates afetados.

Para desenvolvimento, execute `composer install`, `composer test`, `composer lint`, `php build/export-contracts.php --check` e `python3 build/check-docs.py`. Dependencias de desenvolvimento nao integram o runtime. Nao execute os testes de mutacao simultaneamente com testes/runtime: eles alteram e restauram arquivos controladamente.
