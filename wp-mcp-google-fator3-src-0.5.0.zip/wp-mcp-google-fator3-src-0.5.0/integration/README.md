# Laboratório nativo — 0.5.0

Use apenas uma instalação e banco descartáveis. Estas sondas apagam/recriam registros, instalam/substituem plugins, simulam falhas SQL e exercitam desinstalação multisite. Elas interceptam as chamadas externas e não usam credenciais Google reais.

A raiz esperada contém `wp-mcp-google-fator3/`, `integration/`, `evidence/`, `mysql-wordpress/` e `tools/`. O pacote-fonte inclui os três primeiros. Não inclui servidores, PHP, WordPress, navegador nem bancos de dados.

## Dependências

- PHP 8.3.6 com mysqli, pdo_sqlite, OpenSSL, cURL, mbstring, DOM/XML/SimpleXML, Phar e Zip; Python 3; MySQL 8.0.46. O plugin declara PHP 8.0+, mas o ensaio nativo desta entrega usou 8.3.6.
- WordPress 7.1 usado no laboratório, completo em `mysql-wordpress/`. Copie `integration/wp-config.fixture.php` para `mysql-wordpress/wp-config.php`, somente no laboratório. Crie o tema mínimo `wp-content/themes/f3-fixture/style.css` com `Theme Name: Fixture` e `index.php` vazio. A configuração usa porta MySQL 33071, banco `f3_google_next`, credenciais descartáveis e cron desativado.
- `composer install` no diretório do plugin instala as ferramentas fixadas em `composer.lock`. Use `vendor/bin/phpunit` para testes unitários. As sondas CLI esperam WP-CLI 2.12.0 em `tools/wp-cli.phar`.
- Playwright e Chrome Headless Shell 154.0.8037.92 para `browser.mjs`. Defina `F3_PLAYWRIGHT_MODULE` (módulo ou caminho absoluto) e `F3_CHROME` (executável). Rode após `admin-forms.php`; o script lê os HTMLs gerados e grava o próprio `evidence/browser-latest.json`. Não redirecione stdout para esse mesmo arquivo.
- Apache com mod_php, autoindex e `AllowOverride None` para `package-http.py`; veja `--help` para caminhos de módulos/bibliotecas. Essa prova usa instalação limpa e sobreposição da versão anterior.

## Fixtures de comparação

`fixtures/` contém somente bases de teste: o instalador Google 0.4.0, fontes do canal MCP 0.12.1 e fontes do Action Scheduler usados no experimento. Não instale essas bases como a nova release. Licenças e avisos acompanham cada fixture. Extraia em diretórios separados e defina:

- `F3_GOOGLE_BASE_ZIP`: arquivo `fixtures/google-0.4.0.zip`.
- `F3_GOOGLE_BASE_SOURCE`: diretório `wp-mcp-google-fator3` extraído dessa fixture.
- `F3_MCP_CHANNEL`: arquivo principal `wp-mcp-fator3.php` extraído da fixture MCP.
- `F3_ACTION_SCHEDULER`: arquivo `action-scheduler.php` extraído da fixture correspondente.
- `F3_GOOGLE_CANDIDATE_ZIP`: instalador 0.5.0 entregue ou reproduzido por `build/build.py`.

O experimento Action Scheduler não afirma equivalência de todos os estados do worker; veja `docs/ADR-001-FILA.md`. Ele não é dependência do runtime.

## Execução

Defina `F3_TEST_PHP`, `F3_TEST_MYSQLD` e `F3_TEST_MYSQL_BASEDIR` com caminhos absolutos. O PHP apontado deve carregar também as extensões nos processos filhos; pode ser um wrapper. `F3_TEST_RUNTIME` aponta opcionalmente para um bundle com `root/usr/`. Não execute dois runners simultaneamente: a porta da fixture é fixa. `run-mysql.py --fresh` inicializa e remove um datadir temporário, sem reutilizar banco existente.

Na raiz do pacote-fonte:

```sh
python3 integration/run-mysql.py --fresh repository-mysql.php migration-failures.php executor-scope.php concurrency-mysql.php audit-markers.php audit-performance.php cli-mysql.php admin-forms.php documentation.php mcp-channel.php public-transport.php multisite-setup.php uninstall-multisite.php performance.php scheduler-comparison.php upgrader-mysql.php
node integration/browser.mjs
php integration/native-options.php mysql-wordpress wp-mcp-google-fator3 /tmp/f3-options-novo.sqlite
python3 integration/empty-put-wire.py --php /caminho/php --plugin /caminho/wp-mcp-google-fator3 --requests mysql-wordpress/wp-includes/Requests
```

O caminho SQLite deve estar ausente antes do teste. Os scripts têm cenários próprios; alguns dependem da preparação anterior indicada na sequência. `documentation.php` compara os exemplos/schemas aos registros nativos. Evidências finais acompanham os fontes; logs de depuração, tokens temporários, bancos e executáveis de desenvolvimento foram excluídos.
