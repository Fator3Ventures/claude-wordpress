<?php
declare(strict_types=1);
define('FS_METHOD','direct');$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';require_once ABSPATH.'wp-admin/includes/class-automatic-upgrader-skin.php';
use Fator3\McpGoogle\{Options,Updater};
wp_set_current_user(1);WP_Filesystem();$checks=array();function verify(string $name,bool $ok):void{global $checks;$checks[$name]=$ok;if(!$ok){throw new RuntimeException($name);}}
$plugin='wp-mcp-google-fator3/wp-mcp-google-fator3.php';$target=WP_PLUGIN_DIR.'/wp-mcp-google-fator3';if(is_dir($target)){$wp_filesystem->delete($target,true);}
$old=getenv('F3_GOOGLE_BASE_ZIP')?:dirname(__DIR__,2).'/review-040-input/WP Plugin/wp-mcp-google-fator3-0.4.0.zip';$unzip=unzip_file($old,WP_PLUGIN_DIR);verify('base_040_extracted',true===$unzip&&is_file($target.'/CHANGELOG.md')&&is_dir($target.'/docs'));
$archive=getenv('F3_GOOGLE_CANDIDATE_ZIP')?:__DIR__.'/../evidence/google-development-only.zip';$bytes=file_get_contents($archive);$url='https://distribution.example.test/google.zip';
$manifest=array('schema_version'=>'1.0.0','plugin'=>'wp-mcp-google-fator3','version'=>'0.5.0','sha256'=>hash('sha256',$bytes),'requires_php'=>'8.0','requires_wordpress'=>'6.9','package_url'=>$url);
Options::set(Updater::OPTION,array('enabled'=>true,'manifest_url'=>'https://distribution.example.test/manifest.json','allowed_hosts'=>array('distribution.example.test')));delete_transient('f3_mcp_google_update_manifest');
$flavor='valid';$requests=array();$dns=static fn()=>array(array('ip'=>'93.184.216.34'));$response=static function($null,$requested)use(&$flavor,&$requests,&$manifest,$bytes){$requests[]=$requested;if(str_ends_with($requested,'manifest.json')){return array('success'=>true,'status'=>200,'body'=>json_encode($manifest));}if('downgrade'===$flavor){return array('success'=>true,'status'=>302,'headers'=>array('location'=>'http://distribution.example.test/google.zip'));}return array('success'=>true,'status'=>200,'body'=>'tampered'===$flavor?'wrong-bytes':$bytes);};
add_filter('f3_mcp_google_public_dns',$dns);add_filter('f3_mcp_google_public_response',$response,10,2);
add_filter('pre_http_request',static fn()=>array('response'=>array('code'=>503),'body'=>'fixture forbids external network','headers'=>array()));
$upgrader=new Plugin_Upgrader(new Automatic_Upgrader_Skin());$flavor='tampered';$bad=$upgrader->download_package($url,false,array('plugin'=>$plugin));verify('hash_mismatch_refused',is_wp_error($bad)&&'f3_google_update_checksum'===$bad->get_error_code());
$flavor='downgrade';$before=count($requests);$bad=$upgrader->download_package($url,false,array('plugin'=>$plugin));verify('https_downgrade_refused',is_wp_error($bad)&&1===count($requests)-$before);
$flavor='valid';$manual=$upgrader->download_package($archive,false,array('plugin'=>$plugin));verify('manual_archive_preserved',$manual===$archive);
$origin=array('allowed_hosts'=>array('distribution.example.test'));$foreign=$manifest;$foreign['package_url']='https://foreign.example/google.zip';verify('foreign_package_host_refused',is_wp_error(Updater::validate($foreign,$origin)));
$manifest['requires_php']='99.0';delete_transient('f3_mcp_google_update_manifest');$bad=$upgrader->download_package($url,false,array('plugin'=>$plugin));verify('incompatible_package_refused',is_wp_error($bad));$manifest['requires_php']='8.0';delete_transient('f3_mcp_google_update_manifest');
Options::set_secret(Options::OAUTH_REFRESH_TOKEN,'preserved-on-upgrade');$cipher=Options::stored(Options::OAUTH_REFRESH_TOKEN)['value'];Options::set(Options::GA_DEFAULT_PROPERTY,'123456');
set_site_transient('update_plugins',(object)array('last_checked'=>time(),'checked'=>array($plugin=>'0.4.0'),'response'=>array($plugin=>(object)array('slug'=>'wp-mcp-google-fator3','plugin'=>$plugin,'new_version'=>'0.5.0','package'=>$url))));
$result=$upgrader->upgrade($plugin,array('clear_update_cache'=>false));if(is_wp_error($result)){throw new RuntimeException($result->get_error_code().': '.$result->get_error_message());}verify('native_plugin_upgrader_completed',true===$result);
verify('installed_header_version','0.5.0'===get_plugin_data($target.'/wp-mcp-google-fator3.php',false,false)['Version']);
verify('old_documentation_removed',!is_file($target.'/README.md')&&!is_file($target.'/CHANGELOG.md')&&!is_file($target.'/CONTRACTS.md')&&!is_dir($target.'/docs')&&!is_dir($target.'/reference'));
$no_htaccess=true;$dirs=array($target);foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($target,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST) as $path){if($path->isDir()){$dirs[]=(string)$path;}$no_htaccess=$no_htaccess&&'.htaccess'!==$path->getFilename();}
verify('no_htaccess',$no_htaccess);
verify('every_runtime_directory_has_index',count($dirs)===count(array_filter($dirs,static fn($dir)=>is_file($dir.'/index.php'))));
verify('credentials_and_public_options_preserved',$cipher===Options::stored(Options::OAUTH_REFRESH_TOKEN)['value']&&'123456'===Options::get(Options::GA_DEFAULT_PROPERTY));
echo json_encode(array('wordpress'=>get_bloginfo('version'),'upgrader'=>'Plugin_Upgrader::upgrade','candidate_only'=>true,'directories'=>count($dirs),'checks'=>$checks),JSON_PRETTY_PRINT)."\n";
