# Contratos — WP MCP Google Fator3 0.5.0

Este documento descreve a versão 0.5.0. A situação da validação está em [VALIDACAO.md](docs/VALIDACAO.md). A consulta executável dos schemas prevalece sobre exemplos; diferenças documentais bloqueiam o build de produção.

## Versões e compatibilidade

| Interface | Versão | Regra |
|---|---|---|
| Execução | 2.0.0 | `meta.fator3.execution_contract_version`; confirmação obrigatória nas operações afetadas |
| Catálogo de habilidades | 2.0.0 | Registro atual, paginação e schemas opcionais |
| Configuração | 2.0.0 | Opções, valores seguros, revisão, credencial ativa/candidata e operações permitidas |
| Perfil GA4 | 1.0.0 | Seções explícitas; não há perfil de agência embutido |
| Modelo portátil | 1.0.0 | Lista permitida de serviços, bindings, limites e política |
| Manifesto de atualização | 1.0.0 | Origem HTTPS, versão, requisitos e SHA256 do pacote |

`google/configuration-schema` aceita pedidos `1.0.0` e `1.1.0` como projeções do catálogo **atual**. Não reproduz a fotografia das 22 opções antigas: `1.0.0` omite metadados de interface; `1.1.0` inclui interface/revisão/autenticação. Consumidores devem tolerar novas opções. Essas projeções não restauram os contratos antigos de escrita nem dispensam confirmação.

## Entrada e autorização

Os objetos superiores são fechados (`additionalProperties:false`). `connection_id` seleciona explicitamente uma conexão; a omissão usa `default` ou o contexto do job em execução. Não há fallback para outra identidade quando um recurso é recusado.

A execução confere canal, capacidade WordPress, conexão, serviço, credencial, escopos e política de recursos. Administradores podem usar os formulários locais expressamente permitidos mesmo com o canal fechado; essa exceção não reabre chamadas MCP. Credenciais não são gravadas por `options/update` nem retornadas pelo contrato.

`google/execute-read` admite somente métodos classificados como leitura. O verbo HTTP não determina o efeito: relatórios e URL Inspection usam POST de leitura. Métodos novos do Discovery sem classificação aprovada são recusados. Seletores wildcard são recusados em escritas antes da expansão. `google/execute-action` permanece, sujeito às mesmas regras.

`mode` e as anotações MCP descrevem a ferramenta. `remote_effect` distingue consultas, mutações possíveis e operações locais; `local_effect` indica mutação funcional local. Cache e auditoria incidental não convertem uma consulta em mutação do recurso Google. `available` no catálogo avalia configuração local, sem comprovar acesso ao recurso: `resource_access_verified:false` é explícito.

## Envelope e resultado

`success:false` permanece falso e inclui `error_code`/mensagem. O adaptador do canal também sinaliza `isError:true`. Não deduzir resultado a partir do texto da mensagem.

O efeito se refere à operação executada: local para configuração/fila, remoto para chamadas Google. A admissão de um job não comprova aplicação remota; consulte `job_outcomes`/resultado da execução.

| `operation_outcome` | Interpretação |
|---|---|
| `not_applicable` | Consulta sem mutação remota |
| `not_applied` | Nenhuma mutação desta intenção aplicada |
| `applied` | Efeito confirmado pela resposta/validação correspondente |
| `partial` | Algumas etapas aplicadas; consultar os resultados por etapa |
| `unknown` | Resultado remoto incerto; conferir o destino antes de uma nova intenção |

`retryable:false` em `unknown`/`partial`. Executar uma passagem local não implica escrita aplicada: jobs de leitura retornam `not_applicable`, escritas pendentes retornam `not_applied`, e o executor publica `job_outcomes` com o resultado observado por tarefa. Uma resposta HTTP bem-sucedida não comprova indexação do Google nem entrega de e-mail. Para diagnóstico, `execution_success`, `all_checks_passed`, contadores e estados por verificação distinguem execução, aprovação, falha, ausência de configuração e etapas puladas.

## Persistência e configuração

`Options::set()`, `set_secret()` e gravação em lote retornam `success`, `persisted`, `changed`, código e mensagem. A confirmação lê o banco; o retorno booleano de `update_option()` isolado não comprova falha. Uma opção ausente recebendo `false` é criada explicitamente. Valor equivalente já gravado retorna sucesso sem mudança.

Segredos são cifrados antes da persistência. Falhas de leitura, cifra, escrita, verificação e compensação são distintas. Operações compostas preservam o estado anterior quando possível e informam falha de restauração sem anunciar sucesso. `expected_revision` rejeita formulários/planos obsoletos. A revisão de execução dos jobs ignora mudanças que não alteram a identidade/política/serviços, como simples seleção de novos defaults.

O contrato diferencia valor persistido, efetivo e padrão. Para segredos, informa somente presença e legibilidade; uma falha de leitura não vira ausência. Credenciais candidatas possuem opções cifradas separadas e promoção explícita após validar autenticação e recursos já vinculados. Falha preserva a ativa. Rotação de chave da mesma Service Account não representa troca de principal.

## Confirmação e diário de tentativas

Use `google/prepare-operation` com habilidade e parâmetros exatos. A preparação faz consultas e captura localmente os pedidos de mutação; devolve alvos/efeitos, token opaco de uso único e validade de dez minutos. Isso não atesta aprovação humana e não equivale a um `validateOnly` remoto.

A confirmação vincula ator, site, conexão, identidade, revisão, política, método, corpo e conjunto de alvos. A execução reconsulta o estado necessário, compara a intenção, consome o token sob trava e registra a intenção de despacho antes do transporte. Tokens ausentes, expirados, reaproveitados ou pertencentes a outro contexto são recusados sem nova escrita.

Redução de retenção, exclusões, alterações de acesso/proprietários, Google Signals e operações compostas sensíveis exigem esse fluxo. Aumento de retenção não exige por si só confirmação adicional. Operações antigas sem o novo token podem passar a retornar `f3_google_confirmation_required`: há incompatibilidade deliberada de escrita com a 0.4.0.

Quando a criação retorna um ID, a continuação deriva de um modelo semântico aprovado, fixa os pedidos concretos no armazenamento antes de enviar e restringe a autorização temporária ao recurso criado. Falha posterior retorna IDs/etapas confirmadas e resultado parcial/incerto, sem fingir rollback remoto.

## Fila, agendas e recuperação

Jobs congelam recursos, parâmetros e datas na admissão; agendas congelam recursos e mantêm períodos relativos para cada ocorrência. A chave de idempotência é vinculada a ator/conexão/intenção; mudança de intenção com a mesma chave é conflito. Troca posterior de defaults não redireciona o job.

O worker compartilha prazo de 20 segundos, reserva de dois segundos para persistência e teto de 25 itens entre MCP, cron e CLI. Resultado/cursor têm commit transacional com proprietário, geração e lease. Uma leitura abandonada pode retomar; uma escrita despachada sem resultado fica `unknown` e não é repetida automaticamente. Não há promessa de execução remota exatamente uma vez.

`inspect-urls`: 1–500 URLs, duplicatas normalizadas; `auto` processa até cinco URLs únicas na chamada quando há orçamento; `queued` apenas admite. Cota local inicial: 25 tentativas/minuto e até 1.000/dia por propriedade/instalação, incluindo retentativas. Outros clientes Google podem consumir a mesma cota remota.

Exportações entram em `approval_required`. `google/prepare-job` e `google/approve-job` delegam uma intenção ao job; tokens não ficam nos parâmetros. Alteração de contexto ou estado relevante bloqueia o despacho. `get-job` pagina resultados; cancelamento preserva etapas concluídas; reconciliação exige evidência e não repete a escrita.

Agendas aceitam `report`, `query` e `preflight`, com intervalo de 3.600–2.592.000 segundos. Atualização exige a revisão de `get-schedule`. Ocorrências vencidas são identificadas por agenda/data prevista; o atraso é coalescido em uma ocorrência por passagem, sem reproduzir todos os intervalos perdidos. O executor atua na conexão selecionada, salvo `all_connections:true`; o cron usa todas as conexões do site.

Retenção: detalhes 30 dias (1–365); resumos/deduplicação 90 dias (30–730), nunca menos que detalhes. Alterações afetam novos encerramentos. Limpeza tem prévia por padrão e até 100 remoções por passagem; preserva ativos, resultados desconhecidos e deduplicação ainda necessária. Resumos de falhas não resolvidas permanecem para diagnóstico. Diários de confirmações resolvidas são removidos com seus filhos após a retenção; confirmações consumidas sem desfecho permanecem.

## Política e portabilidade

Conexões novas começam restritas; instalações anteriores sem política explícita preservam o acesso da identidade. Defaults não concedem autorização. A política verifica alvos, pais, recursos relacionados e destinatários de compartilhamento. Métodos/suboperações não cobertos são recusados sob restrição; não há autorização implícita de toda uma MCC.

`plan-policy` calcula o impacto e informa revisão/hash; `configure-policy` exige ambos. Modelos portáteis exportam somente serviços, vínculos, limites e política. Recursos são parâmetros por padrão; incluir IDs exige pedido explícito. Credenciais, identidades de autenticação, destinatários e preferências de alertas não são exportados. Aplicação exige prévia/revisão e usa a mesma gravação verificada.

## Auditoria, notificações e atualização

Falha de gravação do log não altera um efeito remoto já conhecido. A chamada recebe `audit_warning`, o status expõe `audit_health`, e a janela de auditoria deixa `complete:false`. O marcador conserva a lacuna observada mesmo que gravações posteriores funcionem. Ocultar um token em texto não conta como reutilização da credencial na telemetria.

Eventos de auditoria têm sequência local ao site e, quando observável, `configuration_revision` e `configuration_change_id`. Uma gravação alterada e confirmada retorna `revision`, `configuration_change_id` e `audit_marker` (`event:…`); falha no log preserva o resultado da configuração, devolve marcador nulo e `audit_warning`. Uma gravação sem mudança não cria marcador. `desde_revisao` aceita o hash de configuração, o marcador exato ou uma sequência decimal (compatibilidade), sempre exclusivo. Hash com mais de um marcador retorna `f3_google_audit_revision_ambiguous`, até 20 candidatos seguros e indicador de truncamento, sem escolher uma ocorrência. Marcador ausente, expurgado ou anterior à implantação retorna `f3_google_audit_revision_unavailable` e cobertura indisponível. `configuration_marker` identifica a fronteira resolvida; `coverage_start` informa o início do histórico retido. Eventos legados não recebem associação inventada. O cursor fixa filtros, conexão, ator, teto da janela e expiração de uma hora. `complete` e `retention_gap` informam a cobertura. Exportação JSON/CSV entrega bytes autenticados com tamanho/hash; CSV neutraliza fórmulas. Sheets usa ação de escrita própria, cursor fixado, células literais e confirmação.

Alertas são optativos, por conexão, com até dez destinatários e intervalo de 60–604.800 segundos. Eventos: `access`, `cron_late`, `sitemap_error`, `scheduled_check`. Uma transição persistida deduplica notificações; crash após iniciar envio gera estado incerto e não reenvia automaticamente.

O atualizador usa somente origem configurada por administrador. Valida HTTPS em cada salto, hosts autorizados, limite de bytes, SHA256, estrutura protegida, versão interna e requisitos. O manifesto identifica `plugin`, `schema_version`, `version`, `package_url`, `sha256`, `requires_php` e `requires_wordpress`. Não existe servidor de distribuição predefinido nem publicação automática.
