# Validação da versão 0.5.0

Data: 30/09/2026. A entrega reúne o escopo da [matriz](FECHAMENTO-DOCUMENTAL.md) em um único instalador. Não houve implantação em produção, chamadas a contas Google reais ou envio real de e-mail.

## Ambiente e natureza das provas

- PHP 8.3.6, WordPress 7.1 completo e MySQL 8.0.46 no laboratório descartável.
- Funções reais de opções/cache/hooks do WordPress também exercitadas com adaptador SQLite isolado. Isso não equivale a homologar o repositório MySQL em SQLite.
- MCP Fator3 0.12.1, WP-CLI 2.12.0 e Chrome 154.0.8037.92.
- Apache/PHP local, listagem de diretório habilitada e `AllowOverride None`, para verificar o pacote sem `.htaccess`.
- APIs Google, entrega de e-mail e origem de distribuição interceptadas por fixtures. O transporte do PUT foi exercitado contra servidor HTTP local usando Requests do WordPress.

A suíte unitária/regressão está em `tests/`; as sondas nativas e evidências ficam nas pastas `integration/` e `evidence/` da raiz do pacote-fonte. Elas são destrutivas para a fixture: use exclusivamente banco/WordPress descartáveis. Dependências e parâmetros do laboratório são descritos no README do pacote-fonte.

## Cobertura

| Verificação | Resultado / alcance |
|---|---|
| PHPUnit | 949 testes e 10.143 asserções aprovados; resultado integral em `evidence/current.txt` |
| Mutação | Quatro defeitos introduzidos isoladamente foram detectados; código restaurado por hash |
| PHPCS/PHPCompatibility | Zero erros e avisos no runtime, com piso PHP 8.0 e exceções locais justificadas para SQL fresco, nonce centralizado e transportes controlados |
| Persistência nativa | 25 verificações de primeira gravação de `false`, no-op, recusa, cifra, compensação e disputa entre processos |
| Migração | 242 registros legados, bloqueio de escrita sem contexto, divisão de resultados, verificação e preservação da origem |
| Falhas e concorrência | SQL recusado, corrupção, perda/substituição de lease, interrupção de leitura/escrita, disputa de confirmação e commit único nos cenários ensaiados |
| Auditoria por configuração | Hash, marcador exclusivo, repetição A→B→A, ambiguidade, expurgo/ausência, janela fixa, isolamento e falha local sem reverter configuração |
| Executor e CLI | Escopo antes do limite de seleção, passagem limitada, usuário explícito, JSON, códigos de saída e disputa com worker nativo |
| Painel | Nonces, autorização, revisão obsoleta, agendas, políticas, configuração local com canal fechado; 38 verificações de navegador/teclado/cópia e layout móvel |
| Catálogo/documentação | 167 habilidades e 21 exemplos comparados ao registro/schema nativo; geradores fixados e links locais conferidos |
| Canal MCP | Ferramentas de leitura/escrita, anotações, `isError`, canal fechado, metadados e rotas canônica/legada |
| GA4/GSC/Core | Cenários de diff, retenção, grafia, acesso opcional, fonte Core, paginação, ambiguidade, simulação, preparação e inspeção usando respostas Google simuladas |
| Lifecycle | Retenção e purge por site, credenciais removidas na desinstalação, desativação de rede e preservação de dados de outros plugins; criação dos registros comprovada antes da remoção |
| Atualização | `Plugin_Upgrader::upgrade` real substituiu a 0.4.0; preservou credenciais e removeu documentos antigos; recusou hash, host, protocolo e compatibilidade inválidos |
| Empacotamento | 114 arquivos, 16 diretórios com índices; documentação/referências fora do runtime; HTTP direto verificado em instalação limpa e substituição |
| PUT vazio | Três entradas com corpo vazio, `Content-Length: 0` e HTTP 204 local; regressão do 411 preservada |

O navegador usou HTML renderizado pelo WordPress e os assets reais do plugin. Os handlers de formulário foram exercitados separadamente no WordPress. Isso não representa um teste de login/formulários de ponta a ponta contra Google real.

## Medidas de desempenho

Dez leituras de revisão da configuração passaram de 230 consultas SQL na 0.4.0 para 10 na 0.5.0: redução de **95,7%** no cenário medido. Com cron já agendado e job legado de aproximadamente 500 KB, `Jobs::init()` passou de uma consulta/leitura do job para zero.

Com retenções de 100, 1.000 e 5.000 eventos, append e leitura de 30 eventos tiveram SQL limitado, sem crescimento com o tamanho do histórico na fixture. O cache de configuração/tokens pode reduzir consultas nas passagens seguintes. A leitura decodifica somente os 30 eventos solicitados. O resultado completo, tempos e consultas constam de `audit-performance-final.txt`. A redação de tokens não incrementa mais a telemetria de uso do cache.

A carga de 500 URLs usa respostas de inspeção simuladas com 200 ms. O primeiro lote processa até 25 itens dentro do orçamento de 20 segundos; tempo/memória medidos constam de `repository-mysql-final.txt`. Latência real do Google e outros clientes concorrentes podem reduzir o trabalho por passagem. O retorno informa progresso e retomada, sem prometer conclusão imediata.

## Limites da homologação

- Não comprova permissões, quotas, disponibilidade das APIs ou conformidade de propriedades reais. O administrador deve validar seus recursos e o perfil que escolher.
- O ramo de cache externo do WordPress foi exercitado; não houve servidor Redis/Memcached no laboratório.
- Não houve matriz completa de hospedagens, versões antigas de PHP/WordPress ou MariaDB. O piso declarado permanece PHP 8.0/WordPress 6.4 com Abilities nativa ou polyfill; PHPCompatibility cobre sintaxe/compatibilidade estática, não substitui essa matriz.
- O atualizador foi validado com manifesto/pacote controlados. Uma origem de produção precisa ser definida/configurada pelo administrador; nenhuma URL é ativada por padrão.
- Piloto e implantação em lotes, inventário da frota, credenciais e disparador de cron são etapas operacionais posteriores, usando o mesmo pacote. Consulte [Migração](MIGRACAO.md).

## Reproduzir as verificações do código

```sh
composer install
composer test
composer lint
php build/export-contracts.php --check
python3 build/check-docs.py
python3 build/build.py --output /caminho/wp-mcp-google-fator3-0.5.0.zip
```

O build de produção depende dos gates documentados. Qualquer alteração posterior exige revalidar os gates afetados; os resultados acima se referem aos hashes entregues.
