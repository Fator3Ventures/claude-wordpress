# Atualização direta, migração e recuperação — 0.5.0

## Antes de substituir a 0.4.0

Faça backup do banco e do pacote anterior. Confira personalizações externas na pasta do plugin e mantenha-as fora dela: a substituição nativa remove o diretório antigo. Não use extração por cima como caminho de atualização homologado. Não execute `uninstall.php` durante uma atualização.

A configuração anterior permanece na conexão `default`. OAuth ativo não é convertido para Service Account. Ausência de política preserva o alcance da identidade anterior; novas conexões começam restritas. A nova preferência de limpeza pública na desinstalação começa desativada.

## Migração do armazenamento

O repositório fica em `{prefixo}f3_google_records`, com índices para conexão, estado, vencimento, auditoria e retenção. Jobs, agendas, itens, resultados, deduplicação e diários têm registros independentes. Resultados tabulares são armazenados em blocos; listagens consultam metadados.

A transição segue `drain → copy → verify → indexed`. Durante cópia/verificação, novas admissões e novos despachos são bloqueados; trabalhadores já ativos param na guarda seguinte. A origem nas opções é preservada. O cursor é persistido por registro, e a troca ocorre somente após releitura, hash e contagens compatíveis. Corrupção/falha mantém `failed` e não ativa uma cópia incompleta.

O cron `f3_mcp_google_storage_step` avança lotes. Consulte `google/storage-status`; `google/migrate-storage` retoma um lote sob autorização. Em falha, investigue `failed_record` e o erro antes de continuar. Não elimine dados de origem para fazer uma divergência desaparecer. Repare a causa e repita a verificação.

Jobs antigos sem contexto autorizado viram `blocked`; escritas antigas em andamento viram `unknown`. Agendas antigas sem contexto ficam desativadas para revisão. Eles não passam a usar uma credencial diferente implicitamente.

## Confirmar a atualização

1. Confira versão, conexão e estado da migração.
2. Execute diagnóstico dos recursos usados no site, com autorização de acesso real.
3. Redescubra as habilidades no cliente MCP e adapte escritas sensíveis ao contrato 2.0.0.
4. Verifique os diretórios/URLs antigas de documentação após a substituição. Limpe caches externos que ainda sirvam cópias antigas; o plugin não controla CDN/backup.
5. Valide o disparador de cron num período sem visitas e confira `agendas_vencidas`.
6. Revise agendas/jobs bloqueados e a política antes de criar novas intenções.

## Reversão

Não copie o ZIP antigo por cima do novo nem force jobs incertos a `pending`. A versão antiga não lê o novo repositório. Uma reversão operacional exige backup coerente anterior à migração e revisão dos efeitos remotos produzidos desde esse backup. Restaurar o banco não desfaz alterações no Google.

Para uma falha de job, preserve IDs, contexto, cursor, resultado e auditoria. Consulte o destino. `reconcile-job` registra a conclusão observada sem repetir a ação. Resultado parcial pode exigir correção manual ou nova intenção limitada ao que falta.

## Inventário de remoção

| Ação | Credenciais duráveis | Tokens temporários | Configuração pública / histórico | Agendas/jobs |
|---|---|---|---|---|
| Substituição/atualização | Preservados | Reutilizados ou renovados conforme contexto | Preservados/migrados | Contexto antigo sem prova exige revisão |
| Desativação | Preservados | Removidos | Preservados | Cron de jobs e migração cancelado |
| Desinstalação padrão | Removidos, inclusive candidatas | Removidos | Preservados e sanitizados | Pausados; escritas em andamento ficam incertas |
| Desinstalação com purge | Removidos | Removidos | Dados próprios removidos | Registros próprios removidos |

Em multisite, a rotina percorre os sites e respeita a preferência de purge de cada um. Remove caches próprios de rede identificados, sem apagar tabelas/opções/cron de outros plugins e sem revogação remota.
