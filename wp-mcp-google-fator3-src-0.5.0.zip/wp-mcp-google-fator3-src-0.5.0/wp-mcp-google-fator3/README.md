# WP MCP Google Fator3 0.5.0

**Release 0.5.0 — 30/09/2026.** Entrega integral, sem versões intermediárias. Código e pacotes validados no laboratório descrito em [Validação](docs/VALIDACAO.md); não houve implantação em produção ou chamadas a contas Google reais.

Plugin genérico de integração entre WordPress, MCP e Google Analytics 4, Ads, Search Console, Site Verification, Sheets e Drive. Service Account é o método prioritário. OAuth de usuário permanece disponível em área separada; cada conexão tem uma única credencial ativa.

O registro contém **167 habilidades: 65 de leitura e 102 de escrita**, com `meta.fator3.version: 0.5.0`. O contrato de configuração **2.0.0** descreve **31 opções**, suas regras, dependências e operações permitidas. Consulte o [catálogo gerado](docs/CATALOGO.md) e os [schemas completos](docs/ability-catalog.json).

## Conteúdo desta versão

- Configuração com ajuda, Service Account primeiro, JSON recolhível, credenciais candidatas cifradas e ativação validada sem substituir prematuramente a credencial ativa.
- Gravações verificadas, revisão contra alterações concorrentes e distinção entre valor já igual, primeira gravação de `false` e falha de persistência/criptografia.
- Separação entre execução do diagnóstico e aprovação das verificações; resultados de escrita indicam efeito aplicado, não aplicado, parcial ou desconhecido.
- Preparação e confirmação vinculadas para escritas sensíveis, inclusive exportações em fila. Escrita incerta exige reconciliação; não é repetida automaticamente.
- Repositório MySQL indexado, migração retomável, resultados paginados, executor limitado, agendas e inspeção de até 500 URLs com retomada.
- Perfis GA4 configuráveis, diff e aplicação com retenção primeiro; vínculo opcional pelo Measurement ID do Site Core; preparação e acompanhamento de migração no Search Console.
- Políticas por recurso, modelos sem segredos, alertas operacionais optativos, auditoria por revisão com exportação autenticada, telemetria e origem de atualização configurável.
- Instalador com lista explícita de arquivos, índice em cada diretório e ausência de documentos/scripts operacionais públicos. Nenhum `.htaccess` no plugin.

O plugin não depende de `padrao-unico-de-configuracao.md`. Não impõe oito dimensões ou qualquer política de agência como configuração universal. Os perfis representam o estado desejado definido pelo administrador.

## Instalar e atualizar

Use o ZIP instalável `wp-mcp-google-fator3-0.5.0.zip`, pela opção **substituir a versão instalada** do WordPress. Não desinstale para atualizar. A atualização preserva credenciais; a desinstalação sempre as remove. Não extraia o pacote-fonte na pasta pública do plugin.

Requisitos técnicos: PHP 8.0+, WordPress com Abilities API nativa ou polyfill compatível, OpenSSL para credenciais e MySQL/MariaDB para o repositório. Os fluxos que consultam páginas públicas e o atualizador exigem cURL com resolução DNS fixada. O canal MCP é fornecido por um plugin de transporte separado.

A URL preferida de transporte é `/wp-json/mcp/wp-mcp-fator3`. O canal Fator3 0.12.1 mantém `/wp-json/mcp/wp-mcp-ultimate` como alias. O complemento Google não cria outro servidor nem substitui o transporte. O callback OAuth permanece `/wp-json/wp-mcp-google-fator3/v1/oauth/callback`.

## Documentação

- [Guia de configuração, atualização e operação](docs/GUIA-0.5.0.md).
- [Contratos de execução e persistência](CONTRACTS.md).
- [Catálogo de habilidades](docs/CATALOGO.md) e [definições de configuração](docs/configuration-definitions.json).
- [Exemplos](docs/examples.json), [schema de perfis GA4](docs/profile-schema.json) e [modelos de relatório](docs/report-templates.json).
- [Migração e recuperação](docs/MIGRACAO.md), [matriz de escopo](docs/FECHAMENTO-DOCUMENTAL.md) e [evidências/pendências](docs/VALIDACAO.md).
- [Histórico de mudanças](CHANGELOG.md). Os guias antigos ficam em `docs/history/` e não substituem os contratos atuais.

O script Cloud Shell revisado pode ser baixado no painel por administrador autenticado, com nonce. O original e a referência legível acompanham `reference/` no pacote-fonte. O script não é executado pelo plugin.

## Desenvolvimento

```sh
composer install
composer test
php build/export-contracts.php
python3 build/compile-profile-schema.py --check
python3 build/build.py --output /caminho/wp-mcp-google-fator3-0.5.0.zip
```

O build de produção verifica `build/release-gates.json`. `--development` gera somente um artefato interno de teste, sem autorizar sua publicação. As fixtures de Google não comprovam acesso a contas reais; essa distinção acompanha as evidências.
