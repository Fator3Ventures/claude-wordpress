from pathlib import Path
import subprocess,socket,os,time,json,shutil
root=Path.cwd();base=root/'release-011';env=os.environ.copy();env['LD_LIBRARY_PATH']=str(base/'runtime/usr/lib/x86_64-linux-gnu');env['F3_TEST_WP_LOAD']=str(base/'mysql-wp/wp-load.php')
php=[str(root/'rmdir/runtime/usr/bin/php8.3'),'-c',str(base/'php.ini')]
for dest in [base/'mysql-wp/wp-content/plugins/wp-mcp-fator3',root/'delete-post/lab/wordpress/wp-content/plugins/wp-mcp-fator3']:shutil.copytree(base/'build/wp-mcp-fator3',dest,dirs_exist_ok=True)
args=[str(base/'runtime/usr/sbin/mariadbd'),'--no-defaults','--basedir='+str(base/'runtime/usr'),'--datadir='+str(base/'mariadb-suite-data'),'--user=root','--bind-address=127.0.0.1','--port=33316','--socket=','--pid-file='+str(base/'mariadb.pid'),'--log-error='+str(base/'runtime/db-error.log'),'--innodb-use-native-aio=0','--innodb-buffer-pool-size=64M','--skip-log-bin']
if not (base/'mariadb-suite-data/mysql').exists():
 with (base/'runtime/db-suite-install.log').open('w') as f:
  subprocess.run([str(base/'runtime/usr/bin/mariadb-install-db'),'--no-defaults','--basedir='+str(base/'runtime/usr'),'--datadir='+str(base/'mariadb-suite-data'),'--auth-root-authentication-method=normal','--skip-test-db','--innodb-use-native-aio=0'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=45)
server=subprocess.Popen(args,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 deadline=time.monotonic()+15
 while time.monotonic()<deadline:
  if server.poll() is not None:raise RuntimeError('Database exited: '+(base/'runtime/db-error.log').read_text()[-1000:])
  try:s=socket.create_connection(('127.0.0.1',33316),timeout=.1);s.close();break
  except OSError:time.sleep(.05)
 else:raise RuntimeError('MariaDB readiness timeout')
 p=subprocess.run(php+[str(base/'scripts/install_mysql_wp.php')],env=env,text=True,capture_output=True,timeout=45);print('INSTALL',p.returncode,p.stdout[:1000],p.stderr[:500],flush=True)
 if p.returncode:raise RuntimeError('WordPress installation failed')
 for mode in ['enabled','disabled']:
  output=base/f'results/contracts-mariadb-{mode}.json'
  with output.open('w')as f:p=subprocess.run(php+[str(base/'scripts/contracts.php'),mode],env=env,stdout=f,stderr=subprocess.PIPE,text=True,timeout=90)
  try:
   d=json.loads(output.read_text());print(mode,d['passed'],d['total'],json.dumps([c for c in d['checks']if not c['pass']])[:4000],flush=True)
  except:print(output.read_text()[:1500],p.stderr[:1500],flush=True)
 if (base/'scripts/mysql_extra.php').exists():
  with (base/'results/mariadb-extra.json').open('w')as f:p=subprocess.run(php+[str(base/'scripts/mysql_extra.php')],env=env,stdout=f,stderr=subprocess.PIPE,text=True,timeout=120)
  print('extra',p.returncode,p.stderr[:500],flush=True)
finally:
 server.terminate()
 try:server.wait(timeout=15)
 except subprocess.TimeoutExpired:server.kill();server.wait()
