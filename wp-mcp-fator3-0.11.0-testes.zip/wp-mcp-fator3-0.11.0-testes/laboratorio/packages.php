<?php
if (PHP_SAPI !== 'cli') { exit(2); }

require getenv('F3_TEST_WP_LOAD') ?: __DIR__.'/../../delete-post/lab/wordpress/wp-load.php';
if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);wp_set_current_user(1);
use Fator3\McpFiles\Result;
$checks=[];$tag='f3-fixture-011';$original=get_stylesheet();$version='1.0.0';
function pcall($n,$a=[]){return Result::normalize(wp_get_ability($n)->execute($a));}
function pcheck($n,$ok,$a=null){global $checks;$checks[]=['test'=>$n,'pass'=>(bool)$ok]+($ok?[]:['actual'=>$a]);}
$api=static function($value,$action,$args)use($tag){if(($args->slug??'')!==$tag)return $value;return (object)['name'=>'Fator3 fixture','slug'=>$tag,'download_link'=>'https://downloads.wordpress.org/plugin/'.$tag.'.zip','requires'=>'6.7','requires_php'=>'8.0','version'=>'1.0.0'];};
$theme_api=static function($value,$action,$args)use($tag){if(($args->slug??'')!==$tag)return $value;return (object)['name'=>'Fator3 theme fixture','slug'=>$tag,'download_link'=>'https://downloads.wordpress.org/theme/'.$tag.'.zip','requires'=>'6.7','requires_php'=>'8.0','version'=>'1.0.0'];};
$http=static function($response,$args,$url)use(&$version,$tag){
 if(!str_contains($url,'downloads.wordpress.org/')||!str_contains($url,$tag))return $response;
 $type=str_contains($url,'/theme/')?'theme':'plugin';$zip=__DIR__.'/../fixtures/'.$type.'-'.$version.'.zip';
 if(!is_file($zip))return new WP_Error('fixture_missing','Missing package fixture.');
 if(!empty($args['stream']))copy($zip,$args['filename']);
 return ['headers'=>[],'body'=>empty($args['stream'])?file_get_contents($zip):'','response'=>['code'=>200,'message'=>'OK'],'cookies'=>[],'filename'=>$args['filename']??null];
};
add_filter('plugins_api',$api,10,3);add_filter('themes_api',$theme_api,10,3);add_filter('pre_http_request',$http,10,3);
try{
 $r=pcall('plugins/install',['slug'=>$tag]);pcheck('native plugin catalog install fixture',$r['success']&&is_file(WP_PLUGIN_DIR.'/'.$tag.'/main.php'),$r);
 $r=pcall('plugins/activate',['plugin'=>$tag.'/main.php']);pcheck('native plugin activate',$r['success']&&is_plugin_active($tag.'/main.php'),$r);
 $r=pcall('plugins/delete',['plugin'=>$tag.'/main.php']);pcheck('active plugin delete refused',!$r['success'],$r);
 $r=pcall('plugins/deactivate',['plugin'=>$tag.'/main.php']);pcheck('native plugin deactivate',$r['success']&&!is_plugin_active($tag.'/main.php'),$r);
 $version='1.1.0';$offer=(object)['last_checked'=>time(),'checked'=>[$tag.'/main.php'=>'1.0.0'],'response'=>[$tag.'/main.php'=>(object)['slug'=>$tag,'plugin'=>$tag.'/main.php','new_version'=>'1.1.0','package'=>'https://downloads.wordpress.org/plugin/'.$tag.'.zip']],'no_update'=>[]];$update_filter=static fn($value)=>$offer;add_filter('pre_set_site_transient_update_plugins',$update_filter);set_site_transient('update_plugins',$offer);$r=pcall('plugins/update',['plugin'=>$tag.'/main.php']);remove_filter('pre_set_site_transient_update_plugins',$update_filter);pcheck('native plugin update fixture',$r['success']&&($r['version']??'')==='1.1.0',$r);
 $r=pcall('plugins/delete',['plugin'=>$tag.'/main.php']);pcheck('native plugin delete loads filesystem',$r['success']&&!is_file(WP_PLUGIN_DIR.'/'.$tag.'/main.php'),$r);
 $version='1.0.0';$r=pcall('themes/install',['slug'=>$tag]);pcheck('native theme install fixture',$r['success']&&wp_get_theme($tag)->exists(),$r);
 $r=pcall('themes/validate',['stylesheet'=>$tag]);pcheck('native theme validation',$r['success'],$r);
 $r=pcall('themes/activate',['stylesheet'=>$tag]);pcheck('native theme activation',$r['success']&&get_stylesheet()===$tag,$r);
}catch(Throwable $e){pcheck('unexpected exception',false,$e->getMessage());}
finally{remove_filter('plugins_api',$api);remove_filter('themes_api',$theme_api);remove_filter('pre_http_request',$http);switch_theme($original);if(is_plugin_active($tag.'/main.php'))deactivate_plugins($tag.'/main.php');if(is_dir(WP_PLUGIN_DIR.'/'.$tag))delete_plugins([$tag.'/main.php']);if(wp_get_theme($tag)->exists()){require_once ABSPATH.'wp-admin/includes/theme.php';delete_theme($tag);}delete_site_transient('update_plugins');}
$r=['passed'=>count(array_filter($checks,fn($x)=>$x['pass'])),'total'=>count($checks),'catalog_transport'=>'controlled fixture; native upgrader/filesystem lifecycle','checks'=>$checks];echo json_encode($r,JSON_PRETTY_PRINT|JSON_PARTIAL_OUTPUT_ON_ERROR)."\n";exit($r['passed']===$r['total']?0:1);
