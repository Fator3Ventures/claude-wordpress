from pathlib import Path
import subprocess,os,json,time,socket,base64,urllib.request,urllib.error,shutil
root=Path.cwd();base=root/'release-011';wp=root/'delete-post/lab/wordpress';php=[str(root/'rmdir/runtime/usr/bin/php8.3'),'-c',str(root/'delete-post/lab/php.ini')];checks=[];session_id=''
shutil.copytree(base/'build/wp-mcp-fator3',wp/'wp-content/plugins/wp-mcp-fator3',dirs_exist_ok=True)
subprocess.run(php+[str(base/'scripts/http_setup.php')],check=True)
auth=json.loads((base/'http-auth.json').read_text());token=base64.b64encode((auth['username']+':'+auth['password']).encode()).decode();port=38011
logs=(base/'results/http-server.log').open('w');server=subprocess.Popen(php+['-S',f'127.0.0.1:{port}','-t',str(wp)],stdout=logs,stderr=logs);opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));endpoint=f'http://127.0.0.1:{port}/index.php?rest_route=/mcp/wp-mcp-ultimate'
def test(n,ok,actual=None):checks.append({'test':n,'pass':bool(ok),**({}if ok else {'actual':actual})})
def rpc(method,params,id=1,authorized=True):
 global session_id
 req=urllib.request.Request(endpoint,data=json.dumps({'jsonrpc':'2.0','id':id,'method':method,'params':params}).encode(),headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream',**({'Mcp-Session-Id':session_id,'Mcp-Protocol-Version':'2025-06-18'}if session_id else {}),**({'Authorization':'Basic '+token}if authorized else {})})
 try:
  with opener.open(req,timeout=15)as r:
   if r.headers.get('Mcp-Session-Id'):session_id=r.headers.get('Mcp-Session-Id')
   return r.status,json.loads(r.read())
 except urllib.error.HTTPError as e:
  try:body=json.loads(e.read())
  except:body={'message':'non-JSON error'}
  return e.code,body
try:
 deadline=time.monotonic()+5
 while time.monotonic()<deadline:
  try:s=socket.create_connection(('127.0.0.1',port),timeout=.1);s.close();break
  except OSError:time.sleep(.03)
 code,r=rpc('initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'f3-regression','version':'1'}});test('HTTP initialize',code==200 and 'result'in r,r)
 code,r=rpc('tools/list',{},2);tools=r.get('result',{}).get('tools',[]);test('exactly three metatools',code==200 and len(tools)==3,[t.get('name')for t in tools]);execute=next((t['name']for t in tools if 'execute-ability'in t['name']),'')
 code,r=rpc('tools/call',{'name':execute,'arguments':{'ability_name':'content/delete-post','parameters':{'id':2147483647,'force':False}}},3);test('HTTP MCP domain error isError',code==200 and r.get('result',{}).get('isError')is True and r['result'].get('structuredContent',{}).get('data',{}).get('error_code')=='not_found',r)
 code,r=rpc('tools/call',{'name':execute,'arguments':{'ability_name':'system/capabilities','parameters':{}}},4);test('HTTP MCP capabilities',code==200 and r.get('result',{}).get('structuredContent',{}).get('data',{}).get('plugin_version')=='0.11.0',r)
 code,r=rpc('tools/list',{},5,False);test('HTTP anonymous denied',code in [401,403],r)
 private=json.loads((base/'http-path.json').read_text())['path']
 try:
  with opener.open(f'http://127.0.0.1:{port}'+private,timeout=5)as response:data=response.read();status=response.status
 except urllib.error.HTTPError as e:data=e.read();status=e.code
 test('private PHP envelope does not expose payload',b'f3-private-fixture'not in data and (status in [403,404]or data==b''),{'status':status,'response_bytes':len(data)})
finally:
 server.terminate()
 try:server.wait(timeout=5)
 except subprocess.TimeoutExpired:server.kill();server.wait()
 logs.close();subprocess.run(php+[str(base/'scripts/http_setup.php'),'cleanup'],check=True)
r={'passed':sum(c['pass']for c in checks),'total':len(checks),'transport':'real loopback HTTP, WordPress Application Password, PHP development server','checks':checks};(base/'results/http.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));raise SystemExit(0 if r['passed']==r['total']else 1)
