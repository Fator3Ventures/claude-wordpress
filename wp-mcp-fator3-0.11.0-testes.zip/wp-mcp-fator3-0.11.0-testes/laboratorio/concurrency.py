from pathlib import Path
import subprocess,json,time,hashlib,shutil
root=Path.cwd(); work=root/'release-011/concurrency';work.mkdir(exist_ok=True)
php=[str(root/'rmdir/runtime/usr/bin/php8.3'),'-c',str(root/'delete-post/lab/php.ini'),str(root/'release-011/scripts/worker.php')]
checks=[]; n=0
wp=root/'delete-post/lab/wordpress'; target=wp/'wp-content/f3-concurrency-011.txt';target.write_text('old')
def start(data):
 global n;n+=1;p=work/f'input-{n}.json';p.write_text(json.dumps(data));return subprocess.Popen(php+[str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def finish(proc):
 out,err=proc.communicate(timeout=20)
 if err: print('stderr',err[:200])
 try:return json.loads(out)
 except:return {'error':'bad worker output','output':out,'returncode':proc.returncode}
def call(name,args,timeout=2):return finish(start({'ability':name,'parameters':args,'timeout':timeout}))
def check(name,ok,value=None):checks.append({'test':name,'pass':bool(ok),**({}if ok else {'actual':value})})
def hold(path,ms=1500,ability=None,params=None):
 signal=work/f'signal-{time.time_ns()}';data={'hold_path':str(path),'signal':str(signal),'hold_ms':ms}
 if ability:data.update(ability=ability,parameters=params)
 p=start(data);deadline=time.monotonic()+5
 while not signal.exists() and time.monotonic()<deadline:time.sleep(.01)
 if not signal.exists():raise RuntimeError('Worker failed to obtain lock: '+str(finish(p)))
 return p
try:
 sha=hashlib.sha256(b'old').hexdigest()
 a=hold(target,900,'files/write',{'path':str(target),'content':'winner','expected_sha256':sha})
 b=start({'ability':'files/write','parameters':{'path':str(target),'content':'loser','expected_sha256':sha}})
 ra,rb=finish(a),finish(b)
 check('concurrent expected hash has one winner',ra.get('success') and rb.get('error_code')=='file_conflict' and target.read_text()=='winner',[ra,rb])
 backup=ra.get('backup_id')
 cases=[('files/write',{'path':str(target),'content':'bad'}),('files/patch',{'path':str(target),'find':'winner','replace':'bad'}),('files/delete',{'path':str(target)}),('files/fetch',{'path':str(target),'url':'https://example.com/a.txt'}),('files/restore',{'backup_id':backup}),('files/copy',{'source':str(target),'destination':str(target)+'.copy'}),('files/move',{'source':str(target),'destination':str(target)+'.move'})]
 for name,args in cases:
  a=hold(target,1500)
  r=call(name,args,.03);check(name+' uses shared file lock',r.get('error_code')=='resource_busy' and r.get('retryable') and r.get('conflict'),r)
  finish(a)
 check('blocked mutations leave original bytes',target.exists() and target.read_text()=='winner')
 alias=wp/'wp-content/f3-concurrency-alias.txt';alias.symlink_to(target)
 a=hold(target,800);r=call('files/write',{'path':str(alias),'content':'bad'},.02);finish(a);check('symlink aliases share canonical lock',r.get('error_code')=='resource_busy',r);alias.unlink()
 dest=wp/'wp-content/f3-concurrency-dest.txt';dest.write_text('destination')
 a=hold(dest,800);r=call('files/copy',{'source':str(target),'destination':str(dest),'overwrite':True},.02);finish(a);check('copy destination is locked',r.get('error_code')=='resource_busy' and dest.read_text()=='destination',r);dest.unlink()
 parent=wp/'wp-content/f3-concurrency-empty';parent.mkdir(exist_ok=True)
 a=hold(parent/'future.txt',800);r=call('files/delete',{'path':str(parent),'empty_dir':True},.02);finish(a);check('parent rmdir waits for child mutation',r.get('error_code')=='resource_busy' and parent.exists(),r);parent.rmdir()
 fixture=wp/'wp-content/plugins/f3-lock-fixture';fixture.mkdir(exist_ok=True);main=fixture/'main.php';main.write_text('<?php /* Plugin Name: F3 Lock Fixture */')
 a=hold(main,800);r=call('plugins/delete',{'plugin':'f3-lock-fixture/main.php'},.02);finish(a);check('native plugin delete shares descendant locks',r.get('error_code')=='resource_busy' and main.exists(),r);shutil.rmtree(fixture)
 # Exact same idempotency key in simultaneous calls must produce one backup/result.
 target.write_text('before');params={'path':str(target),'content':'once','idempotency_key':'parallel-'+str(time.time_ns())};a=start({'ability':'files/write','parameters':params});b=start({'ability':'files/write','parameters':params});ra,rb=finish(a),finish(b)
 check('parallel idempotency executes once',ra.get('success') and rb.get('success') and ra.get('backup_id')==rb.get('backup_id') and bool(ra.get('replayed'))!=bool(rb.get('replayed')),[ra,rb])
finally:
 if target.exists():target.unlink()
report={'passed':sum(c['pass']for c in checks),'total':len(checks),'checks':checks};(root/'release-011/results/concurrency.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
raise SystemExit(0 if report['passed']==report['total']else 1)
