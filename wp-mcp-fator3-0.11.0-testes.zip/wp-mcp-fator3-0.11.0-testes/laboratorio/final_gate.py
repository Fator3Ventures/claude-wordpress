from pathlib import Path
import subprocess,shutil,json,os
root=Path.cwd();b=root/'release-011';source=b/'build/wp-mcp-fator3';php=[str(root/'rmdir/runtime/usr/bin/php8.3'),'-c',str(root/'delete-post/lab/php.ini')];wp=root/'delete-post/lab/wordpress';env=os.environ.copy();summary=[]
for dest in [wp/'wp-content/plugins/wp-mcp-fator3',b/'wp67/wordpress/wp-content/plugins/wp-mcp-fator3',b/'mysql-wp/wp-content/plugins/wp-mcp-fator3']:shutil.copytree(source,dest,dirs_exist_ok=True)
files=[p for p in source.rglob('*.php') if 'tests' not in p.relative_to(source).parts];errors=[]
for p in files:
 r=subprocess.run(php+['-l',str(p)],text=True,capture_output=True)
 if r.returncode:errors.append({'file':str(p.relative_to(source)),'error':r.stdout+r.stderr})
(b/'results/php-lint.json').write_text(json.dumps({'files':len(files),'errors':errors},indent=2));print('lint',len(files),len(errors),flush=True)
if errors:raise SystemExit(1)
def run(name,cmd,report=None,custom_env=None):
 p=b/'results'/name
 with p.open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.PIPE,text=True,env=custom_env or env,timeout=150)
 summary.append({'suite':name,'exit_code':r.returncode});print(name,r.returncode,r.stderr[:120],flush=True)
 if r.returncode:print(p.read_text()[:1500],flush=True)
run('contracts-sqlite.json',php+[str(b/'scripts/contracts.php')])
run('contracts-sqlite-trash-disabled.json',php+[str(b/'scripts/contracts.php'),'disabled'])
wp67env=env|{'F3_TEST_WP_LOAD':str(b/'wp67/wordpress/wp-load.php')}
run('contracts-wp67.json',php+[str(b/'scripts/contracts.php')],custom_env=wp67env)
run('contracts-wp67-trash-disabled.json',php+[str(b/'scripts/contracts.php'),'disabled'],custom_env=wp67env)
for n in ['advanced','packages']:run(n+'.json',php+[str(b/f'scripts/{n}.php')])
for name,script in [('inherited-integration','integration.php'),('inherited-files091','files-read-delete-091.php'),('inherited-upstream','upstream-regressions.php')]:run(name+'-console.txt',php+[str(source/'tests'/script),str(wp),str(b/f'results/{name}.json')])
for mode in ['enabled','disabled']:run('inherited-delete-post-'+mode+'-console.txt',php+[str(source/'tests/delete-post-093.php'),str(wp),mode,str(b/f'results/inherited-delete-post-{mode}.json')])
run('inherited-rmdir-console.txt',php+[str(source/'tests/rmdir-092.php'),str(b/'results/inherited-rmdir.json')])
for mode in ['wp','edit','mods']:run('confine-'+mode+'-console.txt',php+[str(source/'tests/confine.php'),str(wp),mode,str(b/f'results/confine-{mode}.json')])
run('concurrency-console.txt',['python',str(b/'scripts/concurrency.py')])
run('mysql-console.txt',['python',str(b/'scripts/mysql_suite.py')])
run('http-console.txt',['python',str(b/'scripts/http_suite.py')])
run('inventory-console.txt',php+[str(b/'scripts/inventory.php')])
(b/'results/final-gate.json').write_text(json.dumps(summary,indent=2));print('DONE',len(summary),'suites, failures',sum(x['exit_code']!=0 for x in summary),flush=True)
raise SystemExit(int(any(x['exit_code']for x in summary)))
