<?php
if (PHP_SAPI !== 'cli') { exit(2); }

require getenv('F3_TEST_WP_LOAD') ?: __DIR__.'/../../delete-post/lab/wordpress/wp-load.php';wp_set_current_user(1);
$names=[];$schemas=[];foreach(wp_get_abilities()as$a){$meta=$a->get_meta();if(empty($meta['mcp']['public']))continue;$names[]=$a->get_name();$schemas[$a->get_name()]=['input_schema'=>$a->get_input_schema(),'output_schema'=>$a->get_output_schema(),'meta'=>$meta];}sort($names);ksort($schemas);
file_put_contents(__DIR__.'/../results/ability-inventory.json',json_encode(['version'=>F3_MCP_FILES_VERSION,'names'=>$names,'abilities'=>$schemas],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));echo count($names)." public abilities\n";
