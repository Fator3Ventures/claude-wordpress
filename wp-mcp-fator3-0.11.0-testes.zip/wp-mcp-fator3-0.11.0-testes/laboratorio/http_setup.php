<?php
if (PHP_SAPI !== 'cli') { exit(2); }

require __DIR__.'/../../delete-post/lab/wordpress/wp-load.php';
if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);
$user=get_user_by('id',1);
if(($argv[1]??'')==='cleanup'){$data=json_decode(file_get_contents(__DIR__.'/../http-auth.json'),true);WP_Application_Passwords::delete_application_password(1,$data['uuid']);unlink(__DIR__.'/../http-auth.json');exit;}
$r=WP_Application_Passwords::create_new_application_password(1,['name'=>'Fator3 disposable HTTP regression']);
if(is_wp_error($r))throw new RuntimeException($r->get_error_message());
$path=__DIR__.'/../http-auth.json';file_put_contents($path,json_encode(['username'=>$user->user_login,'password'=>$r[0],'uuid'=>$r[1]['uuid']]));chmod($path,0600);
use Fator3\McpFiles\StateStore;
StateStore::put('http-fixture','private',['secret'=>'f3-private-fixture-do-not-expose']);
file_put_contents(__DIR__.'/../http-path.json',json_encode(['path'=>str_replace(ABSPATH,'/',StateStore::path('http-fixture','private'))]));
