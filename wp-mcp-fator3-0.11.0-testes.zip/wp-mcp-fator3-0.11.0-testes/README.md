# Evidências e harnesses — WP MCP Fator3 0.11.0

Este ZIP é material de revisão/teste. O arquivo instalável é `wp-mcp-fator3-0.11.0.zip`.

`results/` contém os resultados reais da última execução completa. `manifest-plugin-sha256.json` permite conferir cada arquivo do plugin, e `provenance-0.11.0.json` lista os caminhos adicionados, alterados e removidos em relação à 0.9.3. `VALIDACAO-0.11.0.md` explica os ambientes e limites.

## Executar os testes PHP

Use uma instalação descartável de WordPress com usuário administrador ID 1, plugin Fator3 0.11.0 ativo, canais de arquivos/banco habilitados e filesystem gravável. Defina `F3_DELETE_POST_DISPOSABLE_LAB=true` apenas no wp-config.php desse laboratório. Algumas suítes criam e excluem conteúdo, opções, tabelas, arquivos, plugins, temas e registros de teste; não use um site real.

As cópias PHP aqui incluem guarda CLI, e o teste MariaDB recebe uma verificação explícita da constante de laboratório; os corpos das asserções são os executados. Não há um instalador automático de WordPress/banco neste pacote.

```bash
F3_TEST_WP_LOAD=/caminho/laboratorio/wordpress/wp-load.php php laboratorio/contracts.php
F3_TEST_WP_LOAD=/caminho/laboratorio/wordpress/wp-load.php php laboratorio/contracts.php disabled
F3_TEST_WP_LOAD=/caminho/laboratorio/wordpress/wp-load.php php laboratorio/advanced.php
F3_TEST_WP_LOAD=/caminho/laboratorio/wordpress/wp-load.php php laboratorio/packages.php
```

`packages.php` encontra os ZIPs em `../fixtures/`. Os testes MariaDB exigem InnoDB/mysqli e um banco descartável que permita criar tabelas/triggers. O `mysql_extra.php` também usa o worker; ajuste o caminho desse worker caso reorganize a árvore.

## Orquestração e testes herdados

Os scripts Python preservam os caminhos e portas do laboratório original para documentar o ensaio; ajuste as variáveis de caminho no início antes de executá-los em outro ambiente. Eles não são executáveis portáveis sem essa preparação. A disposição original foi:

- `release-011/build/wp-mcp-fator3`: código do plugin;
- `release-011/scripts`: conteúdo de `laboratorio/`;
- `release-011/fixtures`: fixtures deste ZIP;
- `release-011/results` e `release-011/concurrency`: saídas temporárias;
- `delete-post/lab/wordpress`: WordPress 6.9.4 + SQLite;
- `release-011/wp67/wordpress`: WordPress 6.7.4 + SQLite;
- `release-011/mysql-wp`: WordPress 6.9.4 + MariaDB;
- `rmdir/runtime/usr/bin/php8.3`, `delete-post/lab/php.ini` e `release-011/php.ini`: PHP/extensões;
- `release-011/runtime`: binários MariaDB; `release-011/mariadb-suite-data`: banco descartável.

Os testes herdados estão também no diretório `tests/` do plugin. Use-os nessa localização, conforme o README e cabeçalhos de cada script, porque alguns resolvem os includes relativamente à pasta do plugin. Os testes JS/E2E históricos são fontes preservadas, sem execução nesta rodada.

Nenhum wp-config.php, banco, senha de aplicação ou runtime foi incluído. Os relatórios JSON não carregam os parâmetros completos das operações bem-sucedidas. Os arquivos de credenciais temporárias do ensaio HTTP não fazem parte das evidências.
