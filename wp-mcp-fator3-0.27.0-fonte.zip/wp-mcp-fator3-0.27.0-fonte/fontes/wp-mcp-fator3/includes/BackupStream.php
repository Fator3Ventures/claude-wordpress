<?php
/** Streaming codec for the existing protected JSON/content_base64 envelope. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class BackupStream {
    public const CHUNK=196608;
    private $in;
    private string $buffer='';
    private int $pos=0;
    private function char(): string {
        if($this->pos>=strlen($this->buffer)){$this->buffer=fread($this->in,self::CHUNK);$this->pos=0;if($this->buffer===false)throw new \RuntimeException('backup_read_failed');if($this->buffer==='')return '';}
        return $this->buffer[$this->pos++];
    }
    private function nonspace(): string {do{$c=$this->char();}while($c!==''&&str_contains(" \r\n\t",$c));return $c;}
    public static function write($h,string $s): void {for($p=0,$n=strlen($s);$p<$n;){$w=fwrite($h,substr($s,$p,self::CHUNK));if(!$w)throw new \RuntimeException('backup_write_failed');$p+=$w;}}
    public static function create(string $source,array $meta,string $dest): array {
        $in=@fopen($source,'rb');if(!$in)throw new \RuntimeException('backup_read_failed');$out=null;$tmp=$dest.'.'.bin2hex(random_bytes(8)).'.php';
        try {
            $before=fstat($in);if(!$before||($before['mode']&0170000)!==0100000||is_link($source))throw new \RuntimeException('backup_source_unsafe');
            $size=(int)$before['size'];$free=@disk_free_space(dirname($dest));if($free!==false&&$free<4*ceil($size/3)+2097152)throw new \RuntimeException('backup_disk_space');
            $out=fopen($tmp,'xb');if(!$out)throw new \RuntimeException('backup_write_failed');chmod($tmp,0600);
            self::write($out,StateStore::HEADER.'{"content_base64":"');$hash=hash_init('sha256');$bytes=0;$carry='';
            while(!feof($in)){$chunk=fread($in,self::CHUNK);if($chunk===false||$chunk===''&&!feof($in))throw new \RuntimeException('backup_read_failed');$bytes+=strlen($chunk);hash_update($hash,$chunk);$chunk=$carry.$chunk;$n=intdiv(strlen($chunk),3)*3;self::write($out,base64_encode(substr($chunk,0,$n)));$carry=substr($chunk,$n);}
            if($carry!=='')self::write($out,base64_encode($carry));
            $digest=hash_final($hash);$after=fstat($in);clearstatcache(true,$source);$pathstat=@stat($source);
            foreach(['dev','ino','size','mtime','ctime'] as $key)if(($before[$key]??null)!==($after[$key]??null)||($before[$key]??null)!==($pathstat[$key]??null))throw new \RuntimeException('backup_source_changed');
            if($bytes!==$size||!hash_equals($digest,(string)hash_file('sha256',$source)))throw new \RuntimeException('backup_source_changed');
            $meta+=['bytes'=>$bytes,'sha256'=>$digest,'site_id'=>get_current_blog_id()];
            self::write($out,'",'.substr(json_encode($meta,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE),1));
            if(!fflush($out)||function_exists('fsync')&&!fsync($out))throw new \RuntimeException('backup_flush_failed');fclose($out);$out=null;
            $verified=self::read($tmp);if($verified!==$meta)throw new \RuntimeException('backup_readback_failed');
            if(!rename($tmp,$dest))throw new \RuntimeException('backup_commit_failed');return $meta;
        }finally{fclose($in);if(is_resource($out))fclose($out);if(is_file($tmp))unlink($tmp);}
    }
    /** Parse top-level JSON structurally; bounded metadata, escaped keys, duplicate rejection. */
    public static function read(string $path,$sink=null,bool $header=true,bool $require_file_payload=true): array {
        $p=new self();$p->in=@fopen($path,'rb');if(!$p->in||is_link($path))throw new \RuntimeException('backup_read_failed');
        try {
            if($header&&fread($p->in,strlen(StateStore::HEADER))!==StateStore::HEADER)throw new \RuntimeException('invalid_envelope');
            if($p->nonspace()!=='{')throw new \RuntimeException('invalid_metadata');$out=[];$seen=[];$c=$p->nonspace();$decoded=0;$digest=null;
            while($c!=='}'){
                if($c!=='"')throw new \RuntimeException('invalid_metadata');$key=$p->string();if(strlen($key)>256||isset($seen[$key]))throw new \RuntimeException('duplicate_or_invalid_key');$seen[$key]=true;
                if($p->nonspace()!==':')throw new \RuntimeException('invalid_metadata');$first=$p->nonspace();
                if($key==='content_base64'){
                    if($first!=='"')throw new \RuntimeException('invalid_base64');[$decoded,$digest]=$p->base64($sink);$c=$p->nonspace();
                }else{
                    $raw=$first;$depth=0;$quoted=false;$escape=false;
                    while(true){
                        $last=$raw[strlen($raw)-1];
                        if($quoted){if($escape)$escape=false;elseif($last==='\\')$escape=true;elseif($last==='"')$quoted=false;}
                        else {if($last==='"')$quoted=true;elseif($last==='{'||$last==='[')$depth++;elseif($last==='}'||$last===']')$depth--;}
                        $c=$p->char();if($c==='')throw new \RuntimeException('invalid_metadata');
                        if(!$quoted&&$depth===0&&($c===','||$c==='}'))break;
                        $raw.=$c;if(strlen($raw)>16777216)throw new \RuntimeException('backup_metadata_limit');
                    }
                    $out[$key]=json_decode($raw,true,64,JSON_THROW_ON_ERROR);
                    if(strlen(serialize($out))>16777216)throw new \RuntimeException('backup_metadata_limit');
                }
                if($c==='}')break;if($c!==',')throw new \RuntimeException('invalid_metadata');$c=$p->nonspace();if($c==='}')throw new \RuntimeException('invalid_metadata');
            }
            if($p->nonspace()!=='')throw new \RuntimeException('trailing_data');
            if($digest!==null&&((int)($out['bytes']??-1)!==$decoded||!hash_equals((string)($out['sha256']??''),$digest)))throw new \RuntimeException('backup_corrupt');
            if(($out['kind']??'')==='file'&&$header&&$require_file_payload&&$digest===null)throw new \RuntimeException('backup_corrupt');return $out;
        }finally{if(is_resource($p->in))fclose($p->in);}
    }
    private function string(): string {
        $raw='"';$escaped=false;
        while(($c=$this->char())!==''){$raw.=$c;if(strlen($raw)>4096)throw new \RuntimeException('key_limit');if($c==='"'&&!$escaped)return json_decode($raw,true,16,JSON_THROW_ON_ERROR);if($c==='\\'&&!$escaped)$escaped=true;else $escaped=false;}
        throw new \RuntimeException('invalid_string');
    }
    private function base64($sink): array {
        $pending='';$hash=hash_init('sha256');$bytes=0;$padding=false;
        while(true){
            if($this->pos>=strlen($this->buffer)){$c=$this->char();if($c==='')throw new \RuntimeException('invalid_base64');$this->pos--;}
            $n=strcspn($this->buffer,"\"\\",$this->pos);$pending.=substr($this->buffer,$this->pos,$n);$this->pos+=$n;
            $end=false;
            if($this->pos<strlen($this->buffer)){$c=$this->char();if($c==='"')$end=true;else{$escape=$this->char();$raw='"\\'.$escape;if($escape==='u')for($j=0;$j<4;$j++)$raw.=$this->char();$pending.=json_decode($raw.'"',true,8,JSON_THROW_ON_ERROR);}}
            $take=$end?strlen($pending):max(0,(intdiv(strlen($pending),4)-1)*4);
            if($take){$part=substr($pending,0,$take);$pending=substr($pending,$take);if($padding||preg_match('/[^A-Za-z0-9+\/=]/D',$part))throw new \RuntimeException('invalid_base64');$decoded=base64_decode($part,true);if($decoded===false||base64_encode($decoded)!==$part)throw new \RuntimeException('invalid_base64');$padding=str_contains($part,'=');$bytes+=strlen($decoded);if($bytes>67108864)throw new \RuntimeException('backup_size_limit');hash_update($hash,$decoded);if(is_resource($sink))self::write($sink,$decoded);}
            if($end)break;
        }return [$bytes,hash_final($hash)];
    }
}
