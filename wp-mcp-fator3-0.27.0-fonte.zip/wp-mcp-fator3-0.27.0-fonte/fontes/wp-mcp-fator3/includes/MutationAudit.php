<?php
/** Public reference-only audit contract. The provider remains the snapshot authority. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class MutationAudit {
    public const CONTRACT = 'mutation-audit/1.0.0';
    private static array $providers = [];
    private static array $errors = [];
    private static bool $initialized = false;
    private static ?string $panel_reader = null;

    public static function init(): void {
        add_action('f3_linkedin_mutation_recorded', static function($event): void {
            if (is_array($event)) self::record($event);
        });
    }
    public static function capabilities(): array {
        return ['contract'=>self::CONTRACT,'registration_hook'=>'f3_mcp_register_mutation_audit',
            'methods'=>['capabilities','register','record','status'],'reader'=>'audit/get-operation',
            'storage'=>'reference_only','retroactive_import'=>false];
    }
    /** Installed provider PHP only; never exposed as an agent-callable registration tool. */
    public static function register(array $descriptor) {
        $provider=$descriptor['provider']??'';
        if (!is_string($provider)||!preg_match('/^[a-z0-9-]{1,100}$/D',$provider)) return new \WP_Error('mutation_descriptor_invalid','Provedor inválido.');
        $fail=static function(string $code)use($provider){unset(self::$providers[$provider]);self::$errors[$provider]=$code;return new \WP_Error($code,'Descritor de auditoria recusado.');};
        if (isset(self::$errors[$provider])) return $fail(self::$errors[$provider]);
        if (array_diff(array_keys($descriptor),['contract','provider','reader','event_contract'])||($descriptor['contract']??'')!==self::CONTRACT
            ||!is_string($descriptor['reader']??null)||!preg_match('~^[a-z0-9-]+/[a-z0-9-]+$~D',$descriptor['reader'])
            ||!is_string($descriptor['event_contract']??null)||!preg_match('~^[a-z0-9-]+/\d+\.\d+\.\d+$~D',$descriptor['event_contract'])) return $fail('mutation_descriptor_invalid');
        if (!self::reader($descriptor)) return $fail('mutation_reader_invalid');
        if (isset(self::$providers[$provider])&&self::$providers[$provider]!=$descriptor) return $fail('mutation_descriptor_conflict');
        self::$providers[$provider]=$descriptor;
        return true;
    }
    private static function reader(array $descriptor): ?\WP_Ability {
        $name=$descriptor['reader'];
        if (str_starts_with($name,'audit/')||!Providers::known($descriptor['provider'])||Providers::metadata($name)['provider']!==$descriptor['provider']) return null;
        $ability=wp_get_ability($name);$meta=$ability?$ability->get_meta():[];$f=$meta['fator3']??[];
        if (!$ability||!ExtensionContract::adheres($name,$f)||($f['provider']??'')!==$descriptor['provider']||empty($f['decorated'])
            ||empty($meta['mcp']['public'])||($meta['mcp']['type']??'tool')!=='tool'||!AuthorizationPolicy::readonly($ability)) return null;
        $schema=$ability->get_input_schema();
        if (($schema['properties']['operation_id']['type']??'')!=='string'||array_diff($schema['required']??[],['operation_id'])) return null;
        return $ability;
    }
    private static function initialize(): void {
        if (self::$initialized) return;
        wp_get_abilities();self::$initialized=true;
        try { do_action('f3_mcp_register_mutation_audit',self::CONTRACT); }
        catch (\Throwable $error) { self::$errors['registration']='mutation_registration_failed';self::$providers=[];return; }
        // Delimited compatibility with the event and public reader shipped in LinkedIn 0.5.0.
        $provider='wp-mcp-linkedin-fator3';$ability=wp_get_ability('linkedin/get-write-operation');
        if (!isset(self::$providers[$provider])&&!isset(self::$errors[$provider])&&$ability&&($ability->get_meta()['fator3']['version']??'')==='0.5.0')
            self::register(['contract'=>self::CONTRACT,'provider'=>$provider,'reader'=>'linkedin/get-write-operation','event_contract'=>'linkedin-mutation/1.0.0']);
    }
    public static function status(): array {
        self::initialize();return self::capabilities()+['providers'=>array_values(self::$providers),'errors'=>self::$errors];
    }
    private static function origin(): string {
        return ConnectionContext::native_identity()?'integration:user:'.get_current_user_id():ConnectionContext::key();
    }
    public static function reference_id(string $provider,string $operation): string {
        return 'mutation:'.hash('sha256',$provider."\0".$operation);
    }
    /** Accept only metadata. Invalid events cannot persist arbitrary fields or credentials. */
    public static function record(array $event) {
        try {
            self::initialize();$provider=$event['provider']??'';$operation=$event['operation_id']??'';
            if (!is_string($provider)||!is_string($operation)||!preg_match('/^[a-f0-9]{64}$/D',$operation)) return new \WP_Error('mutation_event_invalid','Referência inválida.');
            $d=self::$providers[$provider]??null;
            if (!$d||!self::reader($d)||($event['contract']??'')!==$d['event_contract']||($event['reader']??'')!==$d['reader']) return new \WP_Error('mutation_provider_unavailable','Provedor/leitor não admitido.');
            if (!current_user_can('manage_options')) return new \WP_Error('mutation_access_denied','Administrador de origem necessário.');
            foreach (['operation','state'] as $field) if (!is_string($event[$field]??null)||!preg_match('/^[a-z][a-z0-9_-]{0,79}$/D',$event[$field])) return new \WP_Error('mutation_event_invalid','Metadados inválidos.');
            foreach (['before_sha256','after_sha256'] as $field) if (!array_key_exists($field,$event)||$event[$field]!==null&&(!is_string($event[$field])||!preg_match('/^[a-f0-9]{64}$/D',$event[$field]))) return new \WP_Error('mutation_event_invalid','Hash inválido.');
            $ability=explode('/',$d['reader'])[0].'/'.$event['operation'];
            if (Providers::metadata($ability)['provider']!==$provider) return new \WP_Error('mutation_event_invalid','Operação fora do provedor.');
            $id=self::reference_id($provider,$operation);$connection=self::origin();$user=get_current_user_id();
            return Locks::run(['mutation-audit:'.$id=>LOCK_EX],static function()use($id,$event,$provider,$operation,$ability,$connection,$user,$d){
                $previous=Persistence::get('audit',$id);
                if ($previous&&(($previous['user']??0)!==$user||($previous['connection_id']??'')!==$connection)) return new \WP_Error('mutation_owner_conflict','Referência pertence a outra origem.');
                $row=['id'=>$id,'kind'=>'mutation_reference','contract'=>self::CONTRACT,'time'=>$previous['time']??gmdate('c'),
                    'updated_at'=>gmdate('c'),'user'=>$user,'connection_id'=>$connection,'ability'=>$ability,'target'=>'',
                    'provider'=>$provider,'operation_id'=>$operation,'reader'=>$d['reader'],'event_contract'=>$d['event_contract'],
                    'state'=>$event['state'],'before_sha256'=>$event['before_sha256'],'after_sha256'=>$event['after_sha256'],
                    'success'=>$event['state']==='confirmed'];
                Persistence::put('audit',$id,$row);return ['audit_id'=>$id,'operation_id'=>$operation];
            });
        } catch (\Throwable $error) { Audit::write_failure();return new \WP_Error('mutation_persistence_failed','Referência não persistida. Consulte o diário do provedor.'); }
    }
    /** Internal UI scope never changes identity, policy or the provider's permission callback. */
    public static function allows_panel_reader(string $name): bool {
        return self::$panel_reader===$name&&is_admin()&&current_user_can('manage_options')
            &&ConnectionContext::native_identity();
    }
    public static function read_panel(array $input): array {
        if (!is_admin()||!current_user_can('manage_options')||!ConnectionContext::native_identity()) return Result::fail('mutation_access_denied','Use a conexão que originou a operação.');
        return self::read($input,true);
    }
    public static function get(array $input): array { return self::read($input,false); }
    private static function read(array $input,bool $panel): array {
        $prior=self::$panel_reader;
        try {
            if (!current_user_can('manage_options')) return Result::fail('mutation_access_denied','Permissão insuficiente.');
            $provider=$input['provider']??'';$operation=$input['operation_id']??'';
            if (!is_string($provider)||!preg_match('/^[a-z0-9-]{1,100}$/D',$provider)||!is_string($operation)||!preg_match('/^[a-f0-9]{64}$/D',$operation)) return Result::fail('mutation_reference_invalid','Referência inválida.');
            if (!$panel) {$policy=AuthorizationPolicy::check('audit/get-operation',$input,true);if(is_wp_error($policy))return Result::error($policy);}
            $row=Persistence::get('audit',self::reference_id($provider,$operation));
            if (!$row||($row['kind']??'')!=='mutation_reference'||($row['status']??'active')==='deleted') return Result::fail('mutation_not_found','Referência não encontrada ou removida pela retenção.');
            if (($row['user']??0)!==get_current_user_id()||($row['connection_id']??'')!==self::origin()) return Result::fail('mutation_access_denied','Use o usuário e a conexão que originaram a operação.');
            self::initialize();$d=self::$providers[$provider]??null;$ability=$d?self::reader($d):null;
            if (!$ability||$row['reader']!==$d['reader']||$row['event_contract']!==$d['event_contract']) return Result::fail('mutation_provider_unavailable','O leitor público do provedor está indisponível.');
            if ($panel) self::$panel_reader=$d['reader'];
            $result=$ability->execute(['operation_id'=>$operation]);
            if (is_wp_error($result)) return Result::fail('mutation_read_denied','O provedor ou o perfil não autorizou a consulta.');
            if (!is_array($result)||empty($result['success'])) return Result::fail('mutation_read_denied','O provedor não disponibilizou a operação para esta identidade e seleção de ativos.');
            $data=$result['data']??$result;
            if (!is_array($data)||($data['operation_id']??'')!==$operation||!array_key_exists('before',$data)||!array_key_exists('after',$data)||!is_string($data['state']??null)) return Result::fail('mutation_result_invalid','Resposta do leitor incompatível com o contrato.');
            $view=['before'=>$data['before'],'after'=>$data['after']];
            if (strlen(wp_json_encode($view,JSON_THROW_ON_ERROR))>1048576) return Result::fail('mutation_snapshot_too_large','A consulta excedeu o limite de 1 MiB.');
            return Result::ok(['contract'=>self::CONTRACT,'audit_id'=>$row['id'],'provider'=>$provider,'operation_id'=>$operation,
                'state'=>$data['state'],'reference_state'=>$row['state'],'reference_current'=>$row['state']===$data['state'],
                'snapshot_source'=>'provider_public_reader','redacted'=>true,'before'=>self::redact($data['before']),'after'=>self::redact($data['after'])]);
        } catch (\Throwable $error) { return Result::fail('mutation_read_failed','Não foi possível consultar o diário do provedor.'); }
        finally { self::$panel_reader=$prior; }
    }
    private static function redact($value,int $depth=0) {
        if ($depth>40) return '[limite de profundidade]';
        if (is_array($value)||$value instanceof \stdClass) {
            $out=[];foreach ((array)$value as $key=>$item) $out[$key]=DataSafety::secret_key((string)$key)?'[redigido]':self::redact($item,$depth+1);
            return $value instanceof \stdClass?(object)$out:$out;
        }
        if (is_string($value)) return preg_replace('%\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+%i','[redigido]',$value);
        return is_scalar($value)||$value===null?$value:'[redigido]';
    }
}
