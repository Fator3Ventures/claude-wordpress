<?php
/** Allowlisted documentation shipped with this exact package. No remote reads or writes. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Guide {
    public static function register(): void {
        Registry::add('system/guide', 'Lista documentos e temas instalados, lê páginas UTF-8 com revisão/hash e consulta o schema efetivo de habilidade visível. Sem parâmetros lista; document inicia leitura paginada. Não acessa arquivos arbitrários nem altera estado.', [
            'topic'=>Registry::string('Tema devolvido pela listagem; all retorna o manual legado. Não combinar com document.'),
            'ability'=>Registry::string('Nome exato de habilidade visível; não combinar com paginação documental.'),
            'document'=>Registry::string('ID exato da lista de documentos instalados.'),
            'cursor'=>Registry::string('Continuação opaca vinculada ao documento, tema e hash.'),
            'byte_limit'=>Registry::integer(256,32768),
            'expected_sha256'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$'],
        ], [], [self::class,'read'], 'edit_posts');
    }
    public static function read(array $input): array {
        if(isset($input['ability'])) {
            if(count($input)!==1)return Result::fail('guide_input_invalid','ability não pode ser combinada com parâmetros documentais.');
            $ability=wp_get_ability($input['ability']);
            if(!$ability)return Result::fail('ability_not_found','Habilidade não registrada.');
            if(!Discovery::eligibility($ability)['visible'])return Result::fail('profile_denied','Habilidade fora do catálogo desta conexão.');
            return Result::ok(['plugin_version'=>F3_MCP_FILES_VERSION,'ability'=>$ability->get_name(),'description'=>$ability->get_description(),'availability'=>Discovery::eligibility($ability)['availability'],'input_schema'=>$ability->get_input_schema(),'output_schema'=>$ability->get_output_schema(),'source'=>'installed_runtime']);
        }
        if(isset($input['document'],$input['topic']))return Result::fail('guide_input_invalid','Escolha document ou topic.');
        $path=F3_MCP_FILES_DIR.'includes/guide-documents.php';
        if(!is_file($path)||is_link($path)||is_link(dirname($path))||!str_starts_with((string)realpath($path),rtrim((string)realpath(F3_MCP_FILES_DIR),DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR))return Result::fail('guide_unavailable','Documentação instalada indisponível.');
        $documents=require $path;
        $manual=$documents['operacao']['content'];$sections=[];
        foreach(preg_split('/(?=^## )/m',$manual) as $section){
            if(!preg_match('/^## ([^\n]+)/',$section,$match))continue;
            $key=sanitize_title($match[1]);$sections[$key]=['topic'=>$key,'title'=>$match[1],'content'=>$section];
        }
        $id=$input['document']??'operacao';$topic=$input['topic']??null;
        if(!isset($documents[$id]))return Result::fail('guide_document_not_found','Consulte a lista de documentos.');
        $text=$documents[$id]['content'];$hash=hash('sha256',$text);
        $data=['plugin_slug'=>'wp-mcp-fator3','plugin_version'=>F3_MCP_FILES_VERSION,'document_id'=>$id,'document_revision'=>F3_MCP_FILES_VERSION.':'.$hash,'document_sha256'=>$hash,'source'=>'installed_documentation'];
        if(isset($input['expected_sha256'])&&!hash_equals($hash,$input['expected_sha256']))return Result::fail('guide_revision_conflict','Documento mudou; reinicie a leitura.',$data+['conflict'=>true]);
        if(!isset($input['document'])&&$topic===null&&!isset($input['cursor'])&&!isset($input['byte_limit'])) {
            $catalog=[];foreach($documents as $name=>$doc)$catalog[]=['id'=>$name,'title'=>$doc['title'],'bytes'=>strlen($doc['content']),'sha256'=>hash('sha256',$doc['content'])];
            return Result::ok($data+['documents'=>$catalog,'topics'=>array_values(array_map(static fn($s)=>array_diff_key($s,['content'=>true]),$sections))]);
        }
        if($topic!==null&&$topic!=='all') {
            if(!isset($sections[$topic]))return Result::fail('guide_topic_not_found','Consulte a listagem para obter um tema válido.',$data);
            $text=$sections[$topic]['content'];$data+=array_diff_key($sections[$topic],['content'=>true]);
        }
        $paged=isset($input['document'])||isset($input['cursor'])||isset($input['byte_limit']);
        if(!$paged)return Result::ok($data+['content'=>$text]); // Existing topic clients remain compatible.
        $offset=0;
        if(isset($input['cursor'])&&$input['cursor']!=='') {
            $cursor=Cursor::decode($input['cursor']);if(is_wp_error($cursor))return Result::error($cursor);
            if(($cursor['kind']??'')!=='guide'||($cursor['document']??null)!==$id||($cursor['topic']??null)!==$topic)return Result::fail('cursor_invalid','Cursor de outro documento ou tema.');
            if(($cursor['hash']??'')!==$hash)return Result::fail('guide_revision_conflict','Documento mudou; reinicie a leitura.',$data+['conflict'=>true]);
            $offset=$cursor['offset']??-1;
            if(!is_int($offset)||$offset<0||$offset>strlen($text)||($offset<strlen($text)&&(ord($text[$offset])&0xc0)===0x80))return Result::fail('cursor_invalid','Posição inválida.');
        }
        $limit=max(256,min(32768,(int)($input['byte_limit']??8192)));
        // Compiled documents are UTF-8. Cut before a continuation byte without
        // requiring mbstring, which is not a mandatory WordPress extension.
        $next=min(strlen($text),$offset+$limit);
        while($next>$offset&&$next<strlen($text)&&(ord($text[$next])&0xc0)===0x80)--$next;
        $page=substr($text,$offset,$next-$offset);$more=$next<strlen($text);
        return Result::ok($data+['content'=>$page,'offset_bytes'=>$offset,'returned_bytes'=>strlen($page),'total_bytes'=>strlen($text),'has_more'=>$more,'next_cursor'=>$more?Cursor::encode(['kind'=>'guide','document'=>$id,'topic'=>$topic,'hash'=>$hash,'offset'=>$next]):null]);
    }
}
