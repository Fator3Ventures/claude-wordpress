<?php
/** Consumable previews with transaction-time preimage verification. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class DatabaseWriter {
	private static ?\mysqli $transaction_connection = null;
	public static function execute(array $input): array {
		if (!PathGuard::is_enabled() || !Database::writes_enabled() || !current_user_can('manage_options')) return Result::fail('permission_denied', 'Database writes are disabled or unauthorized.');
		$clean = SqlGuard::validate_write((string)($input['sql'] ?? ''));
		if (is_wp_error($clean)) return Result::error($clean);
        return SqlMutation::run('db/execute',$input,[$clean]);
    }

	private static function requirements(array $pre, string $sql) {
		global $wpdb;
		$sqlite = defined('DB_ENGINE') && 'sqlite' === DB_ENGINE;
		if (!$sqlite) {
			$mode = (string)$wpdb->get_var('SELECT @@SESSION.sql_mode');
			if ($wpdb->last_error) return new \WP_Error('sql_mode_unknown', 'Could not verify SQL parsing mode.');
			if (isset($pre['values']) && !str_contains($mode, 'STRICT_TRANS_TABLES') && !str_contains($mode, 'STRICT_ALL_TABLES')) return new \WP_Error('sql_strict_mode_required', 'INSERT/REPLACE previews require strict SQL mode to prevent silent value coercion or truncation.');
			if (str_contains($mode, 'ANSI_QUOTES') && str_contains($sql, '"') || str_contains($mode, 'NO_BACKSLASH_ESCAPES') && str_contains($sql, '\\')) return new \WP_Error('sql_mode_unsupported', 'SQL uses quoting incompatible with the active SQL mode.');
			foreach($pre['sources']??[$pre['table']] as $source){$source_engine=$wpdb->get_var($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s',$source));if(strtolower((string)$source_engine)!=='innodb')return new \WP_Error('transaction_unavailable','Toda fonte da seleção exige InnoDB.');}
            $engine = $wpdb->get_var($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s', $pre['table']));
			if ('innodb' !== strtolower((string)$engine)) return new \WP_Error('transaction_unavailable', 'Verified writes require an InnoDB table. Engine is absent or nontransactional.');
			$triggers = $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND EVENT_OBJECT_TABLE=%s', $pre['table']));
			if ($wpdb->last_error) return new \WP_Error('trigger_check_failed', 'Cannot verify table triggers.');
			if ((int)$triggers) return new \WP_Error('sql_trigger_unsupported', 'This table has triggers. Their changes cannot be represented by a target-row preview; use a typed application operation.');
			// A cascading relationship can alter records outside the advertised backup.
			$fk = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME=%s AND (DELETE_RULE IN ('CASCADE','SET NULL') OR UPDATE_RULE IN ('CASCADE','SET NULL'))", $pre['table']));
			if ($wpdb->last_error || (int)$fk) return new \WP_Error('sql_cascade_unsupported', 'Could not exclude cascading writes beyond the target-row backup.');
		}
		$mask = SqlGuard::mask($sql);
		if (preg_match('/\b(rand|uuid|now|sysdate|sleep|benchmark|load_file|get_lock|current_timestamp|current_date|current_time)\b|@/i', $mask)) return new \WP_Error('sql_nondeterministic', 'Writes must use deterministic expressions and cannot reference session variables.');
		return ['sqlite' => $sqlite];
	}
	private static function select(array $pre) {
		global $wpdb;
		if ('' !== $pre['select']) return $pre['select'];
		$table = $pre['table'];
		$indices = $wpdb->get_results("SHOW INDEX FROM `{$table}`", ARRAY_A);
		if ($wpdb->last_error) return new \WP_Error('sql_index_failed', 'Não foi possível verificar índices.');
		$columns = $wpdb->get_results("DESCRIBE `{$table}`", ARRAY_A);
		if ($wpdb->last_error) return new \WP_Error('sql_columns_failed', 'Não foi possível verificar colunas.');
		$defs = []; foreach ($columns as $col) $defs[strtolower($col['Field'])] = $col;
		$unique = [];
		foreach ($indices as $idx) if (0 === (int)$idx['Non_unique']) {
			if (empty($idx['Column_name']) || !empty($idx['Sub_part'])) return new \WP_Error('sql_index_unsupported', 'Expression or prefix unique indexes cannot be previewed reliably.');
			$unique[$idx['Key_name']][(int)$idx['Seq_in_index']] = $idx['Column_name'];
		}
		$ors = [];
		foreach ($pre['values'] as $row) {
			$row = array_change_key_case($row, CASE_LOWER);
			foreach ($row as $column => $_) if (!isset($defs[$column])) return new \WP_Error('sql_column_unknown', 'Unknown insert column: ' . $column);
			foreach ($unique as $key) {
				$and = []; $skip = false;
				foreach ($key as $column) {
					$lower = strtolower($column); $def = $defs[$lower] ?? [];
					if (isset($row[$lower])) $value = $row[$lower];
					else {
						if (str_contains(strtolower($def['Extra'] ?? ''), 'auto_increment')) { $skip = true; break; }
						if (str_contains(strtolower($def['Extra'] ?? ''), 'generated') || !array_key_exists('Default', $def)) return new \WP_Error('sql_default_unsupported', 'An omitted unique key depends on an expression or unknown default.');
						$value = null === $def['Default'] ? 'NULL' : $wpdb->prepare('%s', $def['Default']);
					}
					if ('null' === strtolower($value)) { $skip = true; break; }
					$and[] = '`' . $column . '` = ' . $value;
				}
				if (!$skip && $and) $ors[] = '(' . implode(' AND ', $and) . ')';
			}
		}
		return 'SELECT * FROM `' . $table . '` WHERE ' . ($ors ? implode(' OR ', array_unique($ors)) : '1=0');
	}
	private static function rows(array &$pre, bool $lock) {
        if(isset($pre['selection_ast']))return SqlSelection::rows($pre,$lock);
		global $wpdb;
		$sql = self::select($pre); if (is_wp_error($sql)) return $sql;
		$sql = SqlGuard::enforce_limit($sql, SqlGuard::MAX_ROWS + 1);
		if ($lock) $sql .= ' FOR UPDATE';
		$rows = $wpdb->get_results($sql, ARRAY_A);
		if ($wpdb->last_error || !is_array($rows)) return new \WP_Error('sql_preview_failed', 'Não foi possível ler a pré-imagem.');
		if (count($rows) > SqlGuard::MAX_ROWS || strlen(serialize($rows)) > 16777216) return new \WP_Error('sql_preview_limit', 'The preimage exceeds 2000 rows or 16 MiB. Use a smaller explicit selection.');
		return $rows;
	}
	private static function digest(array $rows): string {
		$packed = []; foreach ($rows as $row) { ksort($row); $packed[] = serialize($row); } sort($packed, SORT_STRING);
		return hash('sha256', serialize($packed));
	}
	public static function transport_rows(array $rows): array {
		foreach ($rows as &$row) foreach ($row as &$value) if (is_string($value) && !preg_match('//u', $value)) $value = ['encoding' => 'base64', 'data' => base64_encode($value)]; unset($row, $value);
		return $rows;
	}
	/** Execute transaction statements without wpdb's automatic reconnect/replay. */
	private static function transaction_query(string $sql) {
		global $wpdb;
		if (defined('DB_ENGINE') && 'sqlite' === DB_ENGINE) return $wpdb->query($sql);
		if (!(self::$transaction_connection instanceof \mysqli) || $wpdb->dbh !== self::$transaction_connection) { $wpdb->last_error = 'Unsupported transaction connection adapter.'; return false; }
		$filtered = apply_filters('query', $sql);
		if (!is_string($filtered) || $filtered !== $sql) { $wpdb->last_error = 'A query filter rejected the statement.'; return false; }
		$wpdb->flush(); $wpdb->last_query = $filtered; $wpdb->num_queries++;
		try {
			$result = mysqli_query(self::$transaction_connection, $filtered);
			if (false === $result) { $wpdb->last_error = mysqli_error(self::$transaction_connection); return false; }
			if ($result instanceof \mysqli_result) mysqli_free_result($result);
			$wpdb->rows_affected = max(0, mysqli_affected_rows(self::$transaction_connection));
			$wpdb->insert_id = mysqli_insert_id(self::$transaction_connection);
			return $wpdb->rows_affected;
		} catch (\Throwable $e) { $wpdb->last_error = 'Falha na operação de banco; valores e SQL omitidos.'; return false; }
	}
	private static function apply(array $pre, string $sql, string $token, array $state, array $requirements): array {
		global $wpdb;
		$begun = false; $committed = false;
		try {
			// Persist consumption BEFORE starting the business transaction. Otherwise a
			// disconnect/rollback also restores a pending token, allowing uncertain DML
			// to be repeated. Build the backup from this verified snapshot outside the
			// transaction, then verify the same snapshot again under row/gap locks.
			$rows = self::rows($pre, false);
			if (is_wp_error($rows)) return Result::error($rows);
			if (!hash_equals($state['preimage_hash'], self::digest($rows)) || ($state['selection_fingerprint'] ?? null) !== ($pre['selection_fingerprint'] ?? null)) return Result::fail('database_conflict', 'Rows changed since the preview. Request a new preview.', ['conflict' => true, 'applied' => false]);
			$backup = $rows ? Backups::create_rows($pre['table'], $sql, $rows) : '';
			if (is_wp_error($backup)) return Result::error($backup);
			$state['status'] = 'running'; $state['backup_id'] = $backup;
			StateStore::put('db-confirmations', $token, $state);
			$connection = $requirements['sqlite'] ? null : (string)$wpdb->get_var('SELECT CONNECTION_ID()');
			self::$transaction_connection = $wpdb->dbh instanceof \mysqli ? $wpdb->dbh : null;
			if (!$requirements['sqlite'] && false === self::transaction_query('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')) return Result::fail('transaction_isolation_failed', 'Cannot set serializable isolation. Nothing was applied.');
			if (false === self::transaction_query('START TRANSACTION')) return Result::fail('transaction_begin_failed', 'Cannot start a transaction. Nothing was applied.');
			$begun = true;
			$rows = self::rows($pre, !$requirements['sqlite']);
			if (is_wp_error($rows)) return self::rollback(Result::error($rows));
			if (null !== $connection && $connection !== (string)$wpdb->get_var('SELECT CONNECTION_ID()')) return self::rollback(Result::fail('transaction_connection_changed', 'Database reconnected during preview locking. No write was attempted.', ['conflict' => true]));
			if (!hash_equals($state['preimage_hash'], self::digest($rows)) || ($state['selection_fingerprint']??null)!==($pre['selection_fingerprint']??null)) return self::rollback(Result::fail('database_conflict', 'Rows changed since the preview. Request a new preview.', ['conflict' => true, 'applied' => false]));
			$dml=isset($pre['selection_ast'])?SqlSelection::frozen($pre,$rows):$sql;
            if(null!==$connection&&$connection!==(string)$wpdb->get_var('SELECT CONNECTION_ID()'))return self::rollback(Result::fail('transaction_connection_changed','Conexão mudou antes da escrita.',['applied'=>false]));
            $actual = self::transaction_query($dml);
			if (false === $actual) $result = self::rollback(Result::fail('sql_write_failed', 'O banco rejeitou a escrita; detalhes sensíveis omitidos.', ['applied' => false, 'backup_id' => $backup]));
			elseif (in_array($pre['verb'], ['update', 'delete'], true) && $actual > count($rows)) $result = self::rollback(Result::fail('database_conflict', 'The write exceeded its preimage and was rolled back.', ['conflict' => true, 'applied' => false, 'backup_id' => $backup]));
			elseif (false === self::transaction_query('COMMIT')) {
				// Loss of the commit acknowledgement cannot prove whether the server committed.
				self::transaction_query('ROLLBACK');
				return Result::fail('transaction_commit_uncertain', 'COMMIT was not acknowledged. The token remains consumed; inspect the target before another operation.', ['applied' => null, 'backup_id' => $backup]);
			} else {
				$committed = true;
				$result = Result::ok(['applied' => true, 'affected_rows' => (int)$actual, 'backup_id' => $backup, 'preview_rows' => [], 'confirm_token' => '', 'table' => $pre['table'], 'warning' => (string)SqlGuard::serialized_warning($sql, $pre['table'])], 'Write committed. Reusing this token returns this recorded result.');
				wp_cache_flush();
			}
			$state['status'] = 'complete'; $state['result'] = $result;
			StateStore::put('db-confirmations', $token, $state);
			return $result;
		} catch (\Throwable $e) {
			if ($committed) return Result::fail('confirmation_commit_record_failed', 'Database committed but completion could not be saved. Do not repeat with a new token.', ['applied' => true, 'backup_id' => $state['backup_id'] ?? '']);
			return $begun ? self::rollback(Result::fail('database_operation_failed', 'Falha na operação de banco; valores e SQL omitidos.')) : Result::fail('database_operation_failed', 'Falha na operação de banco; valores e SQL omitidos.');
		} finally { if ($begun && !$committed) self::transaction_query('ROLLBACK'); self::$transaction_connection = null; }
	}
	private static function rollback(array $result): array {
		global $wpdb;
		if (false === self::transaction_query('ROLLBACK')) return Result::fail('transaction_rollback_failed', 'Rollback was not acknowledged. Inspect database state before continuing.', ['applied' => null, 'original_error' => $result, 'backup_id' => $result['backup_id'] ?? '']);
		$result['rolled_back'] = true; $result['applied'] = false; return $result;
	}
}
