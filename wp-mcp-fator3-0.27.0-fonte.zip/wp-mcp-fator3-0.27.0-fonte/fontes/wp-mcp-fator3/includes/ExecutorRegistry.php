<?php
/** Opt-in declarations from installed PHP providers. No callbacks or caller identities. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ExecutorRegistry {
    public const CONTRACT = 'executor-registration/1.0.0';
    private static array $entries = [];
    private static array $errors = [];
    private static bool $finalized = false;
    private static bool $finalizing = false;
    public static function capabilities(): array {
        return ['contract'=>self::CONTRACT,'schema_revision'=>1,'provider'=>'wp-mcp-fator3','registration_hook'=>'f3_mcp_register_executors','methods'=>['capabilities','register','status','finalize'],'available'=>true];
    }
    public static function register(array $descriptor) {
        $name=$descriptor['ability']??'';
        if(self::$finalized)return new \WP_Error('executor_registry_closed','Registration is finalized for this request.');
        if(!is_string($name)||!preg_match('~^[a-z0-9-]+/[a-z0-9-]+$~D',$name))return new \WP_Error('executor_descriptor_invalid','Invalid ability name.');
        $fail=static function(string $code)use($name){self::$errors[$name]=$code;unset(self::$entries[$name]);return new \WP_Error($code,'Executor declaration was refused.');};
        if(isset(self::$errors[$name]))return $fail(self::$errors[$name]);
        if(($descriptor['contract']??'')!==self::CONTRACT)return $fail('executor_contract_unsupported');
        if(array_diff(array_keys($descriptor),['contract','ability','provider','mode','allowed_targets'])||!is_string($descriptor['provider']??null)||!in_array($descriptor['mode']??null,['read','write'],true))return $fail('executor_descriptor_invalid');
        $provider=$descriptor['provider'];
        if(!Providers::known($provider))return $fail('executor_provider_unavailable');
        if(Providers::metadata($name)['provider']!==$provider)return $fail('executor_provider_mismatch');
        $targets=$descriptor['allowed_targets']??null;
        if(!is_array($targets)||array_diff(array_keys($targets),['names','prefixes']))return $fail('executor_targets_invalid');
        foreach(['names','prefixes'] as $kind) {
            if(!isset($targets[$kind])||!is_array($targets[$kind])||!array_is_list($targets[$kind])||count($targets[$kind])>512)return $fail('executor_targets_invalid');
            foreach($targets[$kind] as $target) {
                if(!is_string($target)||!preg_match($kind==='names'?'~^[a-z0-9-]+/[a-z0-9-]+$~D':'~^[a-z0-9-]+/$~D',$target)||Providers::metadata($target)['provider']!==$provider)return $fail('executor_target_forbidden');
            }
            $descriptor['allowed_targets'][$kind]=array_values(array_unique($targets[$kind]));sort($descriptor['allowed_targets'][$kind]);
        }
        if(isset(self::$entries[$name])&&self::$entries[$name]!=$descriptor)return $fail('executor_conflict');
        self::$entries[$name]=$descriptor;return true;
    }
    public static function status(): array {
        return self::capabilities()+['finalized'=>self::$finalized,'admitted'=>self::$finalized?array_values(self::$entries):[],'pending'=>self::$finalized?[]:array_keys(self::$entries),'errors'=>self::$errors];
    }
    public static function finalize(): array {
        if(self::$finalized||self::$finalizing||!did_action('wp_abilities_api_init')||doing_action('wp_abilities_api_init'))return self::status();
        self::$finalizing=true;
        try {
            $abilities=wp_get_abilities();
            try { do_action('f3_mcp_register_executors',self::CONTRACT); }
            catch(\Throwable $e) { foreach(self::$entries as $name=>$unused)self::$errors[$name]='executor_registration_failed';self::$entries=[];self::$errors['registration']='executor_registration_failed';self::$finalized=true;return self::status(); }
            // Delimited adapter for the delivered Google 0.8.5 public metadata. It only declares.
            $google_prefixes=[];foreach(Providers::all() as $provider)if($provider['id']==='wp-mcp-google-fator3')$google_prefixes=$provider['prefixes'];
            foreach(['google/mcp-read'=>'read','google/mcp-write'=>'write'] as $name=>$mode) {
                if(isset(self::$entries[$name])||isset(self::$errors[$name]))continue;
                $ability=$abilities[$name]??null;$f=$ability?$ability->get_meta()['fator3']??[]:[];
                if(($f['provider']??'')==='wp-mcp-google-fator3'&&($f['version']??'')==='0.8.5'&&ExtensionContract::adheres($name,$f))self::register(['contract'=>self::CONTRACT,'ability'=>$name,'provider'=>'wp-mcp-google-fator3','mode'=>$mode,'allowed_targets'=>['names'=>[],'prefixes'=>$google_prefixes]]);
            }
            foreach(self::$entries as $name=>$descriptor) {
                $ability=$abilities[$name]??null;
                if(!$ability||!self::valid_ability($ability,$descriptor)){self::$errors[$name]='executor_ability_invalid';unset(self::$entries[$name]);}
            }
            self::$finalized=true;
        } finally {self::$finalizing=false;}
        return self::status();
    }
    private static function valid_ability(\WP_Ability $ability,array $descriptor): bool {
        $meta=$ability->get_meta();$f=$meta['fator3']??[];
        return ExtensionContract::adheres($ability->get_name(),$f)&&($f['provider']??'')===$descriptor['provider']
            && ($f['executes_ability']??false)===true&&($f['decorated']??false)===true&&($meta['mcp']['public']??false)===true&&($meta['mcp']['type']??'tool')==='tool'
            && ($f['mode']??'')===$descriptor['mode']&&is_bool($meta['annotations']['readonly']??null)&&$meta['annotations']['readonly']===($descriptor['mode']==='read');
    }
    public static function descriptor(\WP_Ability $ability): ?array {
        self::finalize();$descriptor=self::$entries[$ability->get_name()]??null;
        return self::$finalized&&$descriptor&&self::valid_ability($ability,$descriptor)?$descriptor:null;
    }
    public static function target(array $descriptor,\WP_Ability $ability): bool {
        $name=$ability->get_name();$f=$ability->get_meta()['fator3']??[];
        if(AuthorizationPolicy::executor($ability)||!ExtensionContract::adheres($name,$f)||($f['provider']??'')!==$descriptor['provider'])return false;
        if($descriptor['mode']==='read'&&!AuthorizationPolicy::readonly($ability))return false;
        if(in_array($name,$descriptor['allowed_targets']['names'],true))return true;
        foreach($descriptor['allowed_targets']['prefixes'] as $prefix)if(str_starts_with($name,$prefix))return true;
        return false;
    }
}
