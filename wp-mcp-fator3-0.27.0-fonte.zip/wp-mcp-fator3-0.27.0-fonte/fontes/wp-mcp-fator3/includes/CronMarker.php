<?php
/** Evidence for MCP's marker only. Diagnostic reads never repair the agenda. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class CronMarker {
    public const HOOK='f3_mcp_cron_observed';
    private static array $native_intent=[];
    private static array $lifecycle=[];
    private static array $diagnostic=[];
    private static array $unpersisted_failures=[];
    public static function init(): void {
        add_action(self::HOOK,[self::class,'observed']);
        add_filter('pre_reschedule_event',static function($pre,$event){if($event->hook===self::HOOK)self::$native_intent[get_current_blog_id()]['reschedule']=(array)$event;return $pre;},PHP_INT_MAX,2);
        add_filter('pre_unschedule_event',static function($pre,$ts,$hook,$args){if($hook===self::HOOK)self::$native_intent[get_current_blog_id()]['unschedule']=['timestamp'=>$ts,'args'=>$args];return $pre;},PHP_INT_MAX,4);
        foreach(['reschedule','unschedule'] as $operation)add_action('cron_'.$operation.'_event_error',static function($error,$hook,$event)use($operation){if($hook===self::HOOK)self::incident($operation,$event,$error);},10,3);
    }
    /** No _get_cron_array(): WordPress upgrades old arrays by writing on that path. */
    private static function matching($cron,bool $missing=false): array {
        if($missing)return [];
        if(!is_array($cron)||($cron['version']??null)!==2)throw new \RuntimeException('cron_payload_invalid');
        $rows=[];
        foreach($cron as $ts=>$hooks){
            if($ts==='version')continue;
            if(!is_array($hooks))throw new \RuntimeException('cron_structure_invalid');
            if(!array_key_exists(self::HOOK,$hooks))continue;
            if(!is_array($hooks[self::HOOK]))throw new \RuntimeException('marker_structure_invalid');
            foreach($hooks[self::HOOK] as $key=>$event){
                $valid=is_int($ts)&&$ts>0&&is_array($event)&&($event['schedule']??null)==='hourly'&&($event['interval']??null)===3600&&($event['args']??null)===[]&&$key===md5(serialize([]));
                $rows[]=['timestamp'=>$ts,'schedule'=>is_array($event)?($event['schedule']??null):null,'interval'=>is_array($event)?($event['interval']??null):null,'args'=>is_array($event)?($event['args']??null):null,'key'=>$key,'valid_shape'=>$valid,'event'=>$event];
            }
        }
        usort($rows,static fn($a,$b)=>strcmp(serialize($a),serialize($b)));
        return $rows;
    }
    private static function current(): array {
        global $wpdb;$db=null;$effective=null;$raw=null;$errors=[];
        try{$wpdb->last_error='';$raw=$wpdb->get_var("SELECT option_value FROM `$wpdb->options` WHERE option_name='cron'");if($wpdb->last_error)throw new \RuntimeException('cron_sql_read_failed');$db=self::matching($raw===null?null:maybe_unserialize($raw),$raw===null);}catch(\Throwable $e){$errors['persisted']=$e->getMessage();}
        try{wp_cache_delete('cron','options');wp_cache_delete('alloptions','options');wp_cache_delete('notoptions','options');$value=get_option('cron',null);$effective=self::matching($value,$raw===null&&$value===null&&$db!==null);}catch(\Throwable $e){$errors['effective']=$e->getMessage();}
        return ['persisted'=>$db,'effective'=>$effective,'consistent'=>$db!==null&&$effective!==null&&$db===$effective,'errors'=>$errors];
    }
    private static function history(): array {return Persistence::get('cron-marker','scheduling')??[];}
    private static function failed(string $code): void {$blog=get_current_blog_id();self::$unpersisted_failures[$blog]=(self::$unpersisted_failures[$blog]??0)+1;self::$diagnostic[$blog]=['status'=>'failed','error_code'=>$code,'scope'=>'current_process','time'=>time()];}
    /** Every writer uses this same site lock and verifies its own write receipt. */
    private static function change(callable $modify): array {
        try{
            $result=Locks::run(['cron-marker-history:'.get_current_blog_id()=>LOCK_EX],static function()use($modify){
                $state=self::history();unset($state['_storage']);$state=$modify($state);$pending=self::$unpersisted_failures[get_current_blog_id()]??0;$state['untracked_writes']=(int)($state['untracked_writes']??0)+$pending;$receipt=bin2hex(random_bytes(16));$state['write_receipt']=$receipt;
                Persistence::put('cron-marker','scheduling',$state);
                $after=self::history();if(($after['write_receipt']??null)!==$receipt)throw new \RuntimeException('cron_diagnostic_readback_failed');
                self::$unpersisted_failures[get_current_blog_id()]=0;self::$diagnostic[get_current_blog_id()]=['status'=>'confirmed','receipt'=>$receipt,'scope'=>'current_process','time'=>time()];return Result::ok();
            });
            if(empty($result['success']))self::failed((string)($result['error_code']??'cron_history_lock_failed'));
            return $result;
        }catch(\Throwable $e){self::failed('cron_diagnostic_persistence_failed');return Result::fail('cron_diagnostic_persistence_failed','Could not persist and verify the cron observation.');}
    }
    private static function record(array $operation): array {return self::change(static function($s)use($operation){$s['last_operation']=$operation;return $s;});}
    private static function transition(string $desired): array {
        $intent=['desired_state'=>$desired,'generation'=>bin2hex(random_bytes(16)),'origin'=>$desired==='active'?'activation':'deactivation','time'=>time()];self::$lifecycle[get_current_blog_id()]=$intent;
        return self::change(static function($s)use($intent){$s['intent']=$intent;return $s;});
    }
    public static function activate(): array {
        try{$r=Locks::run(['cron-marker:'.get_current_blog_id()=>LOCK_EX],static function(){
            $written=self::transition('active');if(empty($written['success']))return $written;
            $read=self::current();
            if(!$read['consistent'])return self::record(['operation'=>'schedule','status'=>'unconfirmed','reason'=>'cron_readback_unavailable','time'=>time()]);
            if(count($read['persisted'])===1&&$read['persisted'][0]['valid_shape'])return self::record(['operation'=>'schedule','status'=>'confirmed','reason'=>'existing_valid_marker','time'=>time()]);
            if($read['persisted'])return self::record(['operation'=>'schedule','status'=>'unconfirmed','reason'=>'unexpected_marker_shape','time'=>time()]);
            $ts=time()+300;$native=wp_schedule_event($ts,'hourly',self::HOOK,[],true);$after=self::current();$verified=$after['consistent']&&count($after['persisted'])===1&&$after['persisted'][0]['valid_shape']&&$after['persisted'][0]['timestamp']===$ts;
            $record=self::record(['operation'=>'schedule','status'=>$verified?'confirmed':(is_wp_error($native)?'failed':'unconfirmed'),'timestamp'=>$ts,'args_sha256'=>hash('sha256',serialize([])),'interval'=>3600,'schedule'=>'hourly','origin'=>'activation','time'=>time(),'native_return'=>is_wp_error($native)?$native->get_error_code():$native]);
            if(is_wp_error($native))self::incident('schedule',(object)['timestamp'=>$ts,'schedule'=>'hourly','interval'=>3600,'args'=>[]],$native);
            return $record;
        });if(empty($r['success']))self::failed((string)($r['error_code']??'cron_operation_lock_failed'));return $r;
        }catch(\Throwable $e){self::failed('cron_activation_failed');return Result::fail('cron_activation_failed','Cron activation could not be observed.');}
    }
    /** Explicit lifecycle compatibility entry point. Never hooked to init. */
    public static function ensure(): array {return self::activate();}
    public static function incident(string $operation,$event,$error): array {
        $e=array_merge((array)$event,self::$native_intent[get_current_blog_id()][$operation]??[]);
        $r=['id'=>bin2hex(random_bytes(12)),'operation'=>$operation,'timestamp'=>(int)($e['timestamp']??0),'schedule'=>$e['schedule']??false,'interval'=>(int)($e['interval']??0),'args_sha256'=>hash('sha256',serialize($e['args']??[])),'args_empty'=>($e['args']??[])===[],'time'=>time(),'status'=>'unconfirmed','error_code'=>is_wp_error($error)?$error->get_error_code():'unknown','origin'=>'native_wp_cron'];
        $read=self::current();$proved=false;
        if($read['consistent']&&$r['timestamp']>0){
            if($operation==='unschedule'){$proved=true;foreach($read['persisted'] as $row)if($row['timestamp']===$r['timestamp']&&hash('sha256',serialize($row['args']))===$r['args_sha256'])$proved=false;}
            elseif($operation==='reschedule'&&$r['interval']>0){foreach($read['persisted'] as $row)if(is_int($row['timestamp'])&&$row['timestamp']>$r['timestamp']&&($row['timestamp']-$r['timestamp'])%$r['interval']===0&&$row['schedule']===$r['schedule']&&$row['interval']===$r['interval']&&hash('sha256',serialize($row['args']))===$r['args_sha256'])$proved=true;}
        }
        if($proved){$r['status']='confirmed';$r['resolved_at']=time();$r['resolved_by']='persisted_postcondition';}
        return self::change(static function($s)use($r){$s['incidents']=$s['incidents']??[];if(count($s['incidents'])>=100)$s['untracked_errors']=(int)($s['untracked_errors']??0)+1;else $s['incidents'][]=$r;return $s;});
    }
    public static function observed(): array {
        global $wpdb;$stamp=time();$native=update_option('f3_mcp_last_cron_observed',$stamp,false);$wpdb->last_error='';$actual=$wpdb->get_var("SELECT option_value FROM `$wpdb->options` WHERE option_name='f3_mcp_last_cron_observed'");$verified=!$wpdb->last_error&&(string)$actual===(string)$stamp;
        return self::record(['operation'=>'callback_marker','status'=>$verified?'confirmed':'unconfirmed','callback_executed'=>true,'marker_persisted'=>$verified,'time'=>$stamp,'native_return'=>$native]);
    }
    public static function status(): array {
        $history_ok=true;try{$s=self::history();}catch(\Throwable $e){$s=[];$history_ok=false;}
        $r=self::current();$blog=get_current_blog_id();$runtime=isset(self::$lifecycle[$blog])?self::$lifecycle[$blog]['desired_state']:(in_array('wp-mcp-fator3/wp-mcp-fator3.php',(array)get_option('active_plugins',[]),true)||isset(((array)get_site_option('active_sitewide_plugins',[]))['wp-mcp-fator3/wp-mcp-fator3.php'])?'active':'unknown');
        $intent=self::$lifecycle[$blog]??($s['intent']??['desired_state'=>$runtime,'origin'=>'runtime_context','generation'=>null]);
        $desired=$intent['desired_state']??'unknown';$state='intent_unknown';$status='unconfirmed';$absence='unconfirmed';
        if($r['persisted']===null||$r['effective']===null)$state='read_failed';
        elseif($runtime==='active'&&$desired==='inactive')$state='intent_conflict';
        elseif(!in_array($desired,['active','inactive'],true))$state='intent_unknown';
        elseif(!$r['consistent'])$state='divergent';
        elseif($desired==='inactive'){if(!$r['persisted']){$state='inactive';$status='unobserved';$absence='confirmed';}else $state='unexpected_presence';}
        elseif(!$r['persisted'])$state='missing';
        elseif(count($r['persisted'])>1)$state='multiple_occurrences';
        elseif(!$r['persisted'][0]['valid_shape'])$state='unexpected_shape';
        else{$state='active';$status='confirmed';}
        $diagnostic=self::$diagnostic[$blog]??['status'=>'unobserved','scope'=>'current_process'];$reasons=[];if(!$history_ok)$reasons[]='history_read_failed';if(($diagnostic['status']??'')==='failed'||!empty($s['untracked_writes'])||!empty(self::$unpersisted_failures[$blog]))$reasons[]='diagnostic_persistence_failed';if(!empty($s['untracked_errors']))$reasons[]='incident_overflow';
        return ['contract'=>'mcp-cron-marker/2','scope'=>'site_marker_only','hook'=>self::HOOK,'status'=>$status,'current_state'=>$state,'desired_state'=>$desired,'intent'=>$intent,'absence'=>['status'=>$absence],'readback'=>$r,'last_operation'=>$s['last_operation']??null,'incidents'=>$s['incidents']??[],'untracked_errors'=>(int)($s['untracked_errors']??0),'untracked_writes'=>(int)($s['untracked_writes']??0)+(self::$unpersisted_failures[$blog]??0),'history_complete'=>!$reasons,'history_coverage'=>['scope'=>'retrieved_history_and_current_process','reasons'=>$reasons,'unrecorded_process_failures_detectable'=>false],'diagnostic_persistence'=>$diagnostic,'callbacks_replayed'=>false];
    }
    public static function deactivate(): array {
        try{$result=Locks::run(['cron-marker:'.get_current_blog_id()=>LOCK_EX],static function(){
            $written=self::transition('inactive');if(empty($written['success']))return $written;
            $native=wp_clear_scheduled_hook(self::HOOK,[],true);$r=self::current();return self::record(['operation'=>'clear','status'=>$r['consistent']&&!$r['persisted']?'confirmed':(is_wp_error($native)?'failed':'unconfirmed'),'time'=>time(),'native_return'=>is_wp_error($native)?$native->get_error_code():$native]);
        });if(empty($result['success']))self::failed((string)($result['error_code']??'cron_operation_lock_failed'));return $result;
        }catch(\Throwable $e){self::failed('cron_deactivation_failed');return Result::fail('cron_deactivation_failed','Cron deactivation could not be observed.');}
    }
}
