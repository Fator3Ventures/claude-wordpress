<?php
/** Scoped Yoast adapter: preserve identity, bounded typed repair. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SeoIndexables {
    public static function rows(int $id,bool $lock=false,string $type='post'): array {
        global $wpdb;
        return Persistence::rows($wpdb->prepare("SELECT * FROM `{$wpdb->prefix}yoast_indexable` WHERE object_id=%d AND object_type=%s ORDER BY id LIMIT 1001".($lock?' FOR UPDATE':''),$id,$type));
    }
    public static function services() {
        try {
            $c=\YoastSEO()->classes;$b=$c->get('Yoast\\WP\\SEO\\Builders\\Indexable_Builder');$r=$c->get('Yoast\\WP\\SEO\\Repositories\\Indexable_Repository');
            if(!is_callable([$b,'build_for_id_and_type'])||!is_callable([$r,'query'])||(new \ReflectionMethod($b,'build_for_id_and_type'))->getNumberOfParameters()<3)throw new \RuntimeException();
            return [$b,$r];
        } catch(\Throwable $e){return new \WP_Error('seo_provider_incompatible','Contrato de indexação compatível indisponível; nada foi alterado.');}
    }
    public static function rebuild(int $id,?int $expected=null,string $type='post'): bool {
        $services=self::services();if(is_wp_error($services))return false;
        try {
            [$b,$r]=$services;$rows=self::rows($id,false,$type);if(count($rows)>1)return false;
            $old=$rows?(int)$rows[0]['id']:null;if($expected!==null&&$expected!==$old)return false;
            // query() avoids the repository's automatic upgrade/build side effect.
            $model=$old?$r->query()->where('id',$old)->find_one():false;
            if($old&&!$model)return false;
            $built=$b->build_for_id_and_type($id,$type,$model);$after=self::rows($id,false,$type);
            return $built&&count($after)===1&&(!$old||(int)$after[0]['id']===$old)&&(int)$built->id===(int)$after[0]['id'];
        }catch(\Throwable $e){return false;}
    }
    public static function preflight(int $id,string $type='post') {
        $s=self::services();if(is_wp_error($s))return $s;
        try{[$b,$r]=$s;$rows=self::rows($id,false,$type);if(count($rows)>1)return new \WP_Error('seo_indexable_duplicates','Duplicatas existentes requerem reparação explícita.');$model=$rows?$r->query()->where('id',(int)$rows[0]['id'])->find_one():$r->query()->create(['object_id'=>$id,'object_type'=>$type]);
            $helper=\YoastSEO()->classes->get('Yoast\\WP\\SEO\\Helpers\\Indexable_Helper');if(!is_callable([$helper,'should_index_indexable'])||!$helper->should_index_indexable($model))return new \WP_Error('seo_indexing_disabled','Persistência de indexação desabilitada pelo provedor; nada foi alterado.');return true;
        }catch(\Throwable $e){return new \WP_Error('seo_provider_incompatible','Não foi possível verificar a indexação do provedor.');}
    }
    public static function permission(array $i): bool {
        return ConnectionTools::permission()&&ContentTools::permission($i)&&(current_user_can('wpseo_manage_options')||current_user_can('wpseo_edit_advanced_metadata'));
    }
    public static function register(): void {
        Registry::add('content/deduplicate-seo-indexables','Prévia e confirmação de reparo Yoast para um post/página. Preserva menor ID e recusa dependências não modeladas. Preserva hierarquia da linha mantida e remove a hierarquia própria das duplicadas. Backup privado limitado a 1000 linhas e 4 MiB; não reindexa o site.', ['id'=>Registry::integer(1),'confirm_token'=>Registry::string()],['id'],[self::class,'repair'],[self::class,'permission'],false);
        Registry::add('content/delete-orphan-seo-indexable','Apaga um indexable Yoast de post/página/termo comprovadamente ausente. Prévia, confirm_token, backup e releitura; recusa referências sobreviventes e não reindexa o site.',['indexable_id'=>Registry::integer(1),'confirm_token'=>Registry::string()],['indexable_id'],[self::class,'orphan'],[self::class,'orphan_permission'],false);
    }
    public static function orphan_permission(array $i=[]): bool {return ConnectionTools::permission()&&(current_user_can('wpseo_manage_options')||current_user_can('wpseo_edit_advanced_metadata'));}
    private static function schema() {
        global $wpdb;
        if(!defined('WPSEO_VERSION'))return new \WP_Error('seo_provider_unavailable','Yoast indisponível.');
        $tables=['indexable'=>$wpdb->prefix.'yoast_indexable','hierarchy'=>$wpdb->prefix.'yoast_indexable_hierarchy','links'=>$wpdb->prefix.'yoast_seo_links'];$schemas=[];
        foreach($tables as $key=>$t){
            $engine=Persistence::rows($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s',$t));
            if(($engine[0]['ENGINE']??'')!=='InnoDB')return new \WP_Error('seo_schema_unsupported','Reparo requer as três tabelas Yoast InnoDB.');
            $schemas[$key]=Persistence::rows("SHOW FULL COLUMNS FROM `$t`");
            $foreign=Persistence::rows($wpdb->prepare('SELECT TABLE_NAME,COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE REFERENCED_TABLE_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME=%s',$t));
            if($foreign)return new \WP_Error('seo_dependencies_unsupported','Há chaves estrangeiras externas; reparo específico necessário.');
        }
        $allowed=json_decode('{"indexable":["id","permalink","permalink_hash","object_id","object_type","object_sub_type","author_id","post_parent","title","description","breadcrumb_title","post_status","is_public","is_protected","has_public_posts","number_of_pages","canonical","primary_focus_keyword","primary_focus_keyword_score","readability_score","is_cornerstone","is_robots_noindex","is_robots_nofollow","is_robots_noarchive","is_robots_noimageindex","is_robots_nosnippet","twitter_title","twitter_image","twitter_description","twitter_image_id","twitter_image_source","open_graph_title","open_graph_description","open_graph_image","open_graph_image_id","open_graph_image_source","open_graph_image_meta","link_count","incoming_link_count","prominent_words_version","created_at","updated_at","blog_id","language","region","schema_page_type","schema_article_type","has_ancestors","estimated_reading_time_minutes","version","object_last_modified","object_published_at","inclusive_language_score","seo_title_score","meta_description_score"],"hierarchy":["indexable_id","ancestor_id","depth","blog_id"],"links":["id","url","post_id","target_post_id","type","indexable_id","target_indexable_id","height","width","size","language","region"]}',true);
        foreach($schemas as $key=>$schema){$actual=array_column($schema,'Field');sort($actual);$known=$allowed[$key];sort($known);if($actual!==$known)return new \WP_Error('seo_schema_unsupported','Colunas Yoast fora do schema verificado.');}
        $cols=array_column($schemas['hierarchy'],'Field');sort($cols);if($cols!==['ancestor_id','blog_id','depth','indexable_id'])return new \WP_Error('seo_schema_unsupported','Schema da hierarquia desconhecido.');
        $linkcols=array_column($schemas['links'],'Field');foreach(['indexable_id','target_indexable_id'] as $k)if(!in_array($k,$linkcols,true))return new \WP_Error('seo_schema_unsupported','Referência de links desconhecida.');
        return ['tables'=>$tables,'schemas'=>$schemas];
    }
    private static function snapshot(int $id,bool $lock=false) {
        global $wpdb;
        if(!self::permission(['id'=>$id]))return new \WP_Error('permission_denied','Exige Manutenção, administração e edição SEO.');
        if(!in_array(get_post_type($id),['post','page'],true))return new \WP_Error('seo_object_unsupported','A reparação atende posts e páginas.');
        $schema=self::schema();if(is_wp_error($schema))return $schema;$tables=$schema['tables'];$schemas=$schema['schemas'];
        $rows=self::rows($id,$lock);$ids=array_map('intval',array_column($rows,'id'));$hierarchy=[];$links=[];
        if($ids){$list=implode(',',$ids);$suffix=$lock?' FOR UPDATE':'';
            $hierarchy=Persistence::rows("SELECT * FROM `{$tables['hierarchy']}` WHERE indexable_id IN ($list) OR ancestor_id IN ($list) ORDER BY indexable_id,ancestor_id,depth LIMIT 1001".$suffix);
            $links=Persistence::rows("SELECT * FROM `{$tables['links']}` WHERE indexable_id IN ($list) OR target_indexable_id IN ($list) ORDER BY id LIMIT 1001".$suffix);
        }
        $remove=array_slice($ids,1);$postmeta=Persistence::rows($wpdb->prepare("SELECT * FROM `$wpdb->postmeta` WHERE post_id=%d ORDER BY meta_id LIMIT 1001".($lock?' FOR UPDATE':''),$id));
        foreach($hierarchy as $h)if(in_array((int)$h['ancestor_id'],$remove,true)&&!in_array((int)$h['indexable_id'],$remove,true))return new \WP_Error('seo_dependencies_unsupported','Hierarquia externa requer reparação específica.');
        foreach($links as $l)if(in_array((int)$l['indexable_id'],$remove,true)||in_array((int)$l['target_indexable_id'],$remove,true))return new \WP_Error('seo_dependencies_unsupported','Duplicata possui links; nada foi alterado.');
        $s=['contract'=>'yoast-deduplicate/1','id'=>$id,'site_id'=>get_current_blog_id(),'yoast_version'=>WPSEO_VERSION,'schemas'=>$schemas,'rows'=>$rows,'hierarchy'=>$hierarchy,'links'=>$links,'postmeta'=>$postmeta,'keep_id'=>$ids[0]??null,'remove_ids'=>$remove];
        if(count($rows)+count($hierarchy)+count($links)+count($postmeta)>1000||strlen(serialize($s))>4194304)return new \WP_Error('seo_preimage_limit','Pré-imagem excede 1000 linhas ou 4 MiB.');return $s;
    }
    private static function summary(array $s): array {return ['id'=>$s['id'],'keep_id'=>$s['keep_id'],'remove_ids'=>$s['remove_ids'],'relationships'=>count($s['hierarchy']),'hierarchy_removed'=>count(array_filter($s['hierarchy'],static fn($h)=>in_array((int)$h['indexable_id'],$s['remove_ids'],true))),'hierarchy_preserved'=>count(array_filter($s['hierarchy'],static fn($h)=>!in_array((int)$h['indexable_id'],$s['remove_ids'],true))),'preimage_sha256'=>hash('sha256',serialize($s))];}
    public static function repair(array $i): array {
        return Locks::run(['post:'.get_current_blog_id().':'.(int)$i['id']=>LOCK_EX],static function()use($i){
            $s=self::snapshot((int)$i['id']);if(is_wp_error($s))return Result::error($s);
            if(!$s['remove_ids']&&empty($i['confirm_token']))return Result::ok(['changed'=>false,'persisted'=>true,'keep_id'=>$s['keep_id']]);
            return Phase::run('content/deduplicate-seo-indexables',$i,static function()use($i){$s=self::snapshot((int)$i['id']);return is_wp_error($s)?$s:self::summary($s);},static function($before)use($i){
                global $wpdb;$s=self::snapshot((int)$i['id']);if(is_wp_error($s))return Result::error($s);if(self::summary($s)!==$before)return Result::fail('preimage_conflict','Seleção mudou.');
                $backup=Backups::create_snapshot('content/deduplicate-seo-indexables',$s);if(is_wp_error($backup))return Result::error($backup);
                try{$result=Persistence::transaction(static function()use($i,$before,$s,$wpdb){
                    $fresh=self::snapshot((int)$i['id'],true);if(is_wp_error($fresh))return $fresh;if(self::summary($fresh)!==$before)return new \WP_Error('preimage_conflict','Seleção mudou sob lock.');
                    $list=implode(',',array_map('intval',$s['remove_ids']));
                    Persistence::query("DELETE FROM `{$wpdb->prefix}yoast_indexable_hierarchy` WHERE indexable_id IN ($list)");
                    Persistence::query("DELETE FROM `{$wpdb->prefix}yoast_indexable` WHERE id IN ($list)");
                    $dangling=Persistence::rows("SELECT * FROM `{$wpdb->prefix}yoast_indexable_hierarchy` WHERE indexable_id IN ($list) OR ancestor_id IN ($list) LIMIT 1 FOR UPDATE");
                    $after=self::rows((int)$i['id'],true);if($dangling||count($after)!==1||$after[0]!==$s['rows'][0])throw new \RuntimeException('readback');
                    return true;
                });if(is_wp_error($result))return Result::error($result)+['backup_id'=>$backup];
                $after=self::snapshot((int)$i['id']);if(is_wp_error($after)||count($after['rows'])!==1||$after['rows'][0]!==$s['rows'][0]||$after['postmeta']!==$s['postmeta']||$after['hierarchy']!==array_values(array_filter($s['hierarchy'],static fn($h)=>!in_array((int)$h['indexable_id'],$s['remove_ids'],true)))||$after['links']!==$s['links'])return Result::fail('seo_repair_unconfirmed','Releitura após commit divergente.',['backup_id'=>$backup,'applied'=>null]);
                clean_post_cache((int)$i['id']);return Result::ok(['id'=>(int)$i['id'],'changed'=>true,'persisted'=>true,'keep_id'=>$s['keep_id'],'removed_ids'=>$s['remove_ids'],'backup_id'=>$backup,'readback'=>['count'=>1,'removed_absent'=>true,'hierarchy_removed'=>true]]);
                }catch(\Throwable $e){return Result::fail('seo_repair_failed','Reparo não confirmado; consulte a pré-imagem.',['backup_id'=>$backup,'applied'=>null]);}
            });
        });
    }
    private static function orphan_snapshot(int $id,bool $lock=false) {
        global $wpdb;
        if(!self::orphan_permission())return new \WP_Error('permission_denied','Exige Manutenção, administração e capacidade SEO.');
        $schema=self::schema();if(is_wp_error($schema))return $schema;$tables=$schema['tables'];$suffix=$lock?' FOR UPDATE':'';
        $row=Persistence::rows($wpdb->prepare("SELECT * FROM `{$tables['indexable']}` WHERE id=%d".$suffix,$id))[0]??null;
        if(!$row)return new \WP_Error('seo_indexable_not_found','Indexable não encontrado.');
        $object=(int)$row['object_id'];$type=$row['object_type'];$sub=$row['object_sub_type'];
        if($object<=0)return new \WP_Error('seo_object_unsupported','Objeto sem identidade verificável.');
        if($type==='post'&&in_array($sub,['post','page'],true)){
            $exists=Persistence::rows($wpdb->prepare("SELECT ID,post_type,post_status FROM `$wpdb->posts` WHERE ID=%d".$suffix,$object));
            if($exists)return new \WP_Error('seo_object_exists','Objeto ainda existe, inclusive se privado ou na lixeira.');
            $absence=['kind'=>'post_absent','object_id'=>$object];
        }elseif($type==='term'&&is_string($sub)&&$sub!==''){
            $terms=Persistence::rows($wpdb->prepare("SELECT term_id FROM `$wpdb->terms` WHERE term_id=%d".$suffix,$object));
            $tt=Persistence::rows($wpdb->prepare("SELECT term_taxonomy_id FROM `$wpdb->term_taxonomy` WHERE term_id=%d AND taxonomy=%s".$suffix,$object,$sub));
            if($terms&&$tt)return new \WP_Error('seo_object_exists','Termo e vínculo taxonômico ainda existem.');
            $absence=['kind'=>$terms?'term_taxonomy_absent':'term_absent','object_id'=>$object,'taxonomy'=>$sub,'term_rows'=>$terms,'taxonomy_rows'=>$tt];
        }else return new \WP_Error('seo_object_unsupported','Operação atende somente indexables de posts, páginas e termos.');
        $h=Persistence::rows($wpdb->prepare("SELECT * FROM `{$tables['hierarchy']}` WHERE indexable_id=%d OR ancestor_id=%d ORDER BY indexable_id,ancestor_id,depth LIMIT 1001".$suffix,$id,$id));
        $links=Persistence::rows($wpdb->prepare("SELECT * FROM `{$tables['links']}` WHERE indexable_id=%d OR target_indexable_id=%d ORDER BY id LIMIT 1001".$suffix,$id,$id));
        foreach($h as $relation)if((int)$relation['indexable_id']!==$id)return new \WP_Error('seo_dependencies_unsupported','Outra linha preservada referencia este indexable.');
        if($links)return new \WP_Error('seo_dependencies_unsupported','Indexable possui links não modelados para exclusão.');
        $s=['contract'=>'yoast-orphan-delete/1','site_id'=>get_current_blog_id(),'yoast_version'=>WPSEO_VERSION,'schemas'=>$schema['schemas'],'indexable_id'=>$id,'row'=>$row,'hierarchy'=>$h,'absence'=>$absence];
        if(count($h)+1>1000||strlen(serialize($s))>4194304)return new \WP_Error('seo_preimage_limit','Pré-imagem excede 1000 linhas ou 4 MiB.');
        return $s;
    }
    private static function orphan_summary(array $s): array {
        return ['indexable_id'=>$s['indexable_id'],'object_type'=>$s['row']['object_type'],'object_sub_type'=>$s['row']['object_sub_type'],'object_id'=>(int)$s['row']['object_id'],'absence'=>$s['absence'],'hierarchy_rows'=>count($s['hierarchy']),'preimage_sha256'=>hash('sha256',serialize($s))];
    }
    private static function orphan_absent(int $id,bool $lock=false): bool {
        global $wpdb;$suffix=$lock?' FOR UPDATE':'';
        foreach(['yoast_indexable'=>"id=$id",'yoast_indexable_hierarchy'=>"indexable_id=$id OR ancestor_id=$id",'yoast_seo_links'=>"indexable_id=$id OR target_indexable_id=$id"] as $table=>$where)if(Persistence::rows("SELECT * FROM `{$wpdb->prefix}$table` WHERE $where LIMIT 1".$suffix))return false;
        return true;
    }
    public static function orphan(array $i): array {
        if(!self::orphan_permission())return Result::fail('permission_denied','Exige Manutenção, administração e capacidade SEO.');
        $id=(int)$i['indexable_id'];
        return Locks::run(['seo-indexable:'.get_current_blog_id().':'.$id=>LOCK_EX],static function()use($i,$id){
            return Phase::run('content/delete-orphan-seo-indexable',$i,static function()use($id){$s=self::orphan_snapshot($id);return is_wp_error($s)?$s:self::orphan_summary($s);},static function($before)use($id){
                global $wpdb;$s=self::orphan_snapshot($id);if(is_wp_error($s))return Result::error($s);
                if(self::orphan_summary($s)!==$before)return Result::fail('preimage_conflict','Objeto/dependências mudaram.');
                $backup=Backups::create_snapshot('content/delete-orphan-seo-indexable',$s);if(is_wp_error($backup))return Result::error($backup);
                try{
                    $result=Persistence::transaction(static function()use($id,$before,$wpdb){
                        $fresh=self::orphan_snapshot($id,true);if(is_wp_error($fresh))return $fresh;
                        if(self::orphan_summary($fresh)!==$before)return new \WP_Error('preimage_conflict','Objeto/dependências mudaram sob lock.');
                        Persistence::query($wpdb->prepare("DELETE FROM `{$wpdb->prefix}yoast_indexable_hierarchy` WHERE indexable_id=%d",$id));
                        Persistence::query($wpdb->prepare("DELETE FROM `{$wpdb->prefix}yoast_indexable` WHERE id=%d",$id));
                        if(!self::orphan_absent($id,true))throw new \RuntimeException('readback');return true;
                    });
                    if(is_wp_error($result))return Result::error($result)+['backup_id'=>$backup,'applied'=>false];
                    if(!self::orphan_absent($id))return Result::fail('seo_orphan_delete_unconfirmed','Releitura após commit divergente.',['backup_id'=>$backup,'applied'=>null]);
                    return Result::ok(['indexable_id'=>$id,'changed'=>true,'persisted'=>true,'backup_id'=>$backup,'readback'=>['indexable_absent'=>true,'hierarchy_absent'=>true,'links_absent'=>true]]);
                }catch(\Throwable $e){return Result::fail('seo_orphan_delete_failed','Exclusão não confirmada; consulte a pré-imagem.',['backup_id'=>$backup,'applied'=>null]);}
            });
        });
    }
}
