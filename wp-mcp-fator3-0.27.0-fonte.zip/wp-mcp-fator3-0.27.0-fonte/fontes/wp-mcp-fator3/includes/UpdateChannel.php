<?php
/** Explicit HTTPS manifest channels; disabled until the administrator supplies real feed URLs. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class UpdateChannel {
    private static array $downloads=[];
    public const HOST='fator3.com.br';
    public const PACKAGES=[
        'wp-mcp-fator3'=>'wp-mcp-fator3/wp-mcp-fator3.php',
        'base-site-core-fator3'=>'base-site-core-fator3/base-site-core-fator3.php',
        'wp-mcp-google-fator3'=>'wp-mcp-google-fator3/wp-mcp-google-fator3.php',
    ];
    public static function init(): void {
        add_filter('update_plugins_'.self::HOST,[self::class,'offer'],10,4);
        add_filter('pre_set_site_transient_update_plugins',[self::class,'selected_offers'],100);
        add_filter('upgrader_pre_download',[self::class,'download'],20,4);
        add_filter('upgrader_pre_install',static function($reply,$extra){
            if(is_wp_error($reply))return $reply;
            $selected=self::$downloads[$extra['plugin']??'']??null;
            return $selected ? PackageDistribution::guard($selected) : $reply;
        },20,2);
        add_action('admin_post_f3_mcp_update_channels',[self::class,'submit']);
    }
    public static function validate(array $doc,string $package,array $hosts) {
        $plugin=PackageDistribution::packages()[$package]??null;
        if(($doc['schema_version']??null)!==1||($doc['package']??'')!==$package||($doc['plugin']??'')!==$plugin)return new \WP_Error('manifest_identity_invalid','Identidade do manifesto não corresponde ao pacote.');
        foreach(['version','url','sha256'] as $key)if(!is_string($doc[$key]??null))return new \WP_Error('manifest_schema_invalid','Campo obrigatório ausente.');
        if(!preg_match('/^[0-9][A-Za-z0-9.+-]{0,63}$/D',$doc['version'])||!preg_match('/^[a-f0-9]{64}$/D',$doc['sha256']))return new \WP_Error('manifest_schema_invalid','Versão ou digest inválido.');
        $url=wp_parse_url($doc['url']);
        if(($url['scheme']??'')!=='https'||!in_array(strtolower($url['host']??''),$hosts,true)||isset($url['user'])||isset($url['pass'])||isset($url['fragment'])||isset($url['port'])&&$url['port']!==443)return new \WP_Error('manifest_origin_invalid','URL do pacote fora das origens HTTPS autorizadas.');
        foreach(['requires','tested'] as $group){if(!is_array($doc[$group]??null))return new \WP_Error('manifest_schema_invalid','Requisitos e teste precisam ser tipados.');foreach(['wordpress','php'] as $key)if(!is_string($doc[$group][$key]??null)||!preg_match('/^\d+(?:\.\d+){1,3}$/D',$doc[$group][$key]))return new \WP_Error('manifest_schema_invalid','Versão de requisito/teste inválida.');}
        if(!is_string($doc['tested']['evidence']??null)||$doc['tested']['evidence']==='')return new \WP_Error('manifest_evidence_missing','Manifesto precisa identificar evidência de homologação.');
        // Companion versions are descriptive metadata, never installation requirements.
        return $doc;
    }
    public static function manifest(string $package) {
        $channel=get_option('f3_mcp_update_channels',[])[$package]??null;
        if(!$channel||empty($channel['url']))return new \WP_Error('update_channel_unconfigured','Canal sem URL configurada.');
        $key=$package.'|'.hash('sha256',serialize($channel));$cached=StateStore::get('update-manifests',$key);
        if($cached&&($cached['expires']??0)>time())return $cached['manifest'];
        $url=$channel['url'];$safe=Http::validate_public_url($url);if(is_wp_error($safe)||wp_parse_url($url,PHP_URL_SCHEME)!=='https')return new \WP_Error('manifest_origin_invalid','Manifesto exige origem HTTPS pública.');
        $r=wp_safe_remote_get($url,['timeout'=>5,'redirection'=>0,'cookies'=>[],'sslverify'=>true,'limit_response_size'=>65537,'headers'=>['Accept'=>'application/json']]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return new \WP_Error('manifest_fetch_failed','Manifesto indisponível; redirecionamentos são recusados.');
        $bytes=wp_remote_retrieve_body($r);if(strlen($bytes)>65536)return new \WP_Error('manifest_size_limit','Manifesto supera 64 KiB.');
        $type=strtolower(trim(explode(';',(string)wp_remote_retrieve_header($r,'content-type'))[0]));$doc=json_decode($bytes,true);
        if($type!=='application/json'||!is_array($doc)||array_is_list($doc))return new \WP_Error('manifest_schema_invalid','JSON de manifesto inválido.');
        $hosts=array_values(array_unique(array_merge([strtolower((string)wp_parse_url($url,PHP_URL_HOST))],$channel['package_hosts']??[])));
        $valid=self::validate($doc,$package,$hosts);if(is_wp_error($valid))return $valid;
        StateStore::put('update-manifests',$key,['manifest'=>$valid,'expires'=>time()+300,'time'=>time()]);return $valid;
    }
    public static function offer($update,array $headers,string $plugin,array $locales) {
        $package=array_search($plugin,PackageDistribution::packages(),true);if($package===false)return $update;
        $selection=PackageDistribution::selection($package);if($selection['origin']!=='mcp')return $update;
        $manifest=PackageDistribution::manifest($package);if(is_wp_error($manifest))return false;
        if(!is_wp_version_compatible($manifest['requires']['wordpress'])||!is_php_version_compatible($manifest['requires']['php']))return false;
        return ['slug'=>$package,'version'=>$manifest['version'],'new_version'=>$manifest['version'],'package'=>$manifest['url'],'requires'=>$manifest['requires']['wordpress'],'requires_php'=>$manifest['requires']['php'],'tested'=>$manifest['tested']['wordpress'],'f3_sha256'=>$manifest['sha256'],'f3_manifest_version'=>1,'f3_distribution_selection'=>$selection];
    }
    /** Registered optional packages need not share the built-in Update URI host. */
    public static function selected_offers($updates) {
        if(!is_object($updates)||!is_array($updates->checked??null))return $updates;
        foreach(PackageDistribution::packages() as $package=>$plugin) {
            if(!isset($updates->checked[$plugin])||PackageDistribution::selection($package)['origin']!=='mcp')continue;
            $offer=self::offer(false,[],$plugin,[]);
            unset($updates->response[$plugin],$updates->no_update[$plugin]);
            if(!is_array($offer))continue; // A selected but failed channel cannot revive another origin.
            $key=version_compare($offer['new_version'],(string)$updates->checked[$plugin],'>')?'response':'no_update';
            if(!is_array($updates->$key??null))$updates->$key=[];
            $updates->{$key}[$plugin]=(object)($offer+['id'=>$plugin,'plugin'=>$plugin]);
        }
        return $updates;
    }
    /** Digest validation also covers WordPress's native admin updater. */
    public static function download($reply,string $url,$upgrader,array $extra) {
        $plugin=$extra['plugin']??'';$package=array_search($plugin,PackageDistribution::packages(),true);if($package===false)return $reply;
        $selection=PackageDistribution::selection($package);
        // A previously selected MCP offer cannot become a provider download after reconfiguration.
        if(isset($extra['f3_distribution_selection'])){$guard=PackageDistribution::guard($extra['f3_distribution_selection']);if(is_wp_error($guard))return $guard;}
        $offer=get_site_transient('update_plugins')->response[$plugin]??null;
        if(isset($offer->f3_distribution_selection)){$guard=PackageDistribution::guard((array)$offer->f3_distribution_selection);if(is_wp_error($guard))return $guard;}
        if($selection['origin']!=='mcp')return $reply;
        self::$downloads[$plugin]=$selection;
        if($package==='wp-mcp-fator3'&&$upgrader!==null&&!$upgrader instanceof AtomicPluginUpgrader)return new \WP_Error('self_update_requires_recovery','Atualize o servidor pela habilidade plugins/update, que usa recuperação independente. O atualizador nativo não possui esse diário.');
        $manifest=PackageDistribution::manifest($package);if(is_wp_error($manifest))return $manifest;
        if($url!==$manifest['url'])return new \WP_Error('package_identity_conflict','Oferta mudou; consulte atualizações novamente.');
        if(is_wp_error($reply))return $reply;
        if(is_string($reply)&&is_file($reply))return hash_equals($manifest['sha256'],hash_file('sha256',$reply))?$reply:new \WP_Error('package_hash_conflict','ZIP não corresponde ao manifesto.');
        $safe=Http::validate_public_url($url);if(is_wp_error($safe))return $safe;
        $r=wp_safe_remote_get($url,['timeout'=>20,'redirection'=>0,'cookies'=>[],'sslverify'=>true,'limit_response_size'=>16777217]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return new \WP_Error('package_download_failed','Download falhou; redirecionamentos não são aceitos no canal próprio.');
        $bytes=wp_remote_retrieve_body($r);if(strlen($bytes)>16777216||!hash_equals($manifest['sha256'],hash('sha256',$bytes)))return new \WP_Error('package_hash_conflict','Tamanho ou digest diverge do manifesto.');
        $guard=PackageDistribution::guard($selection);if(is_wp_error($guard))return $guard;
        $file=wp_tempnam($package.'.zip');if(!$file||file_put_contents($file,$bytes)!==strlen($bytes)){if($file)@unlink($file);return new \WP_Error('package_download_failed','Temporário incompleto.');}return $file;
    }

    /** Local form owns exactly one entry; distribution APIs still support all providers. */
    public static function save_admin(array $posted,string $revision): array {
        if(!current_user_can('manage_options')||!current_user_can('update_plugins'))return Result::fail('permission_denied','Permissão insuficiente.');
        if(array_diff(array_keys($posted),['wp-mcp-fator3']))return Result::fail('update_channel_scope','Esta tela configura somente o Fator3 MCP.');
        $entry=$posted['wp-mcp-fator3']??null;
        if(!is_array($entry)||!is_string($entry['url']??null)||!is_string($entry['package_hosts']??null))return Result::fail('update_channel_invalid','Configuração inválida.');
        $url=trim($entry['url']);$hosts=[];
        if($url!==''){
            $p=wp_parse_url($url);
            if(strlen($url)>2048||($p['scheme']??'')!=='https'||empty($p['host'])||isset($p['user'])||isset($p['pass'])||isset($p['fragment'])||(isset($p['port'])&&$p['port']!==443))return Result::fail('update_channel_invalid','Informe um endereço HTTPS sem credenciais, fragmentos ou porta alternativa.');
            $hosts=preg_split('/[\s,]+/',strtolower(trim($entry['package_hosts'])),-1,PREG_SPLIT_NO_EMPTY)?:[];
            if(count($hosts)>50)return Result::fail('update_channel_invalid','Use no máximo 50 domínios.');
            foreach($hosts as $host)if(strlen($host)>253||!filter_var($host,FILTER_VALIDATE_DOMAIN,FILTER_FLAG_HOSTNAME))return Result::fail('update_channel_invalid','Domínio adicional inválido.');
        }
        return Locks::run(['package-distribution'=>LOCK_EX],static function()use($url,$hosts,$revision){
            $channels=get_option('f3_mcp_update_channels',[]);
            if(!is_array($channels))return Result::fail('update_channel_invalid','Configuração armazenada inválida. Nenhuma alteração aplicada.');
            if(!hash_equals(hash('sha256',serialize($channels)),$revision))return Result::fail('settings_conflict','Os canais mudaram. Recarregue a página antes de salvar.');
            if($url==='')unset($channels['wp-mcp-fator3']);else $channels['wp-mcp-fator3']=array_replace($channels['wp-mcp-fator3']??[],['url'=>$url,'package_hosts'=>array_values(array_unique($hosts))]);
            $r=VerifiedOptions::update('f3_mcp_update_channels',['value'=>$channels]);
            if(!empty($r['success'])){PackageDistribution::publish_selection();delete_site_transient('update_plugins');}
            return $r;
        });
    }
    public static function submit(): void {
        if(!current_user_can('manage_options')||!current_user_can('update_plugins'))wp_die('Permissão insuficiente.','',['response'=>403]);check_admin_referer('f3_mcp_update_channels');
        $posted=wp_unslash($_POST['channels']??[]);$r=self::save_admin(is_array($posted)?$posted:[],is_string($_POST['revision']??null)?wp_unslash($_POST['revision']):'');
        Audit::record('admin/update-channel',['name'=>'wp-mcp-fator3'],$r,0);
        $notice=wp_generate_uuid4();set_transient('f3_mcp_notice_'.get_current_user_id().'_'.$notice,['success'=>!empty($r['success']),'message'=>!empty($r['success'])?'Canal do Fator3 MCP salvo. Nenhum pacote foi instalado.':($r['message']??'Não foi possível salvar.')],60);wp_safe_redirect(add_query_arg('notice',$notice,Admin::url('updates')));exit;
    }
    public static function render(): void {
        if(!current_user_can('manage_options'))return;
        $channels=get_option('f3_mcp_update_channels',[]);$c=is_array($channels)?($channels['wp-mcp-fator3']??[]):[];
        echo '<section class="f3-card"><h2>Atualizações do Fator3 MCP</h2><p>Configure a fonte publicada de atualização deste plugin.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';Admin::nonce('f3_mcp_update_channels');
        echo '<input type="hidden" name="action" value="f3_mcp_update_channels"><input type="hidden" name="revision" value="'.esc_attr(hash('sha256',serialize($channels))).'">';
        echo '<p><label for="f3-update-url">Endereço da fonte de atualização (HTTPS)</label><br><input id="f3-update-url" class="large-text" type="url" maxlength="2048" name="channels[wp-mcp-fator3][url]" value="'.esc_attr($c['url']??'').'" aria-describedby="f3-update-help"></p>';
        Admin::help('f3-update-help','Use o endereço publicado pelo responsável pelo pacote. Deixe vazio para desabilitar este canal.');
        echo '<p><label for="f3-update-hosts">Domínios adicionais para baixar o pacote</label><br><input id="f3-update-hosts" class="large-text" name="channels[wp-mcp-fator3][package_hosts]" value="'.esc_attr(implode(' ',$c['package_hosts']??[])).'" aria-describedby="f3-hosts-help"></p>';
        Admin::help('f3-hosts-help','Separe por espaço. O domínio da fonte já é permitido; informe apenas outros domínios de download autorizados.');
        echo '<p><button class="button button-primary" '.disabled(!current_user_can('update_plugins'),true,false).'>Salvar canal do MCP</button></p></form><p><a href="'.esc_url(add_query_arg('document','package-distribution',Admin::url('help'))).'">Consultar documentação de distribuição</a></p></section>';
    }
}
