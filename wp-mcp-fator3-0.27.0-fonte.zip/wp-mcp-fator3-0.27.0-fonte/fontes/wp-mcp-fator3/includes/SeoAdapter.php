<?php
/** Fill the registered SEO contract gap through Yoast's metadata API. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class SeoAdapter {
    private const FIELDS=[
        'title'=>'title','description'=>'metadesc','focus_keyphrase'=>'focuskw','canonical'=>'canonical',
        'open_graph_title'=>'opengraph-title','open_graph_description'=>'opengraph-description',
        'open_graph_image'=>'opengraph-image','twitter_title'=>'twitter-title',
        'twitter_description'=>'twitter-description','twitter_image'=>'twitter-image',
        'open_graph_image_id'=>'opengraph-image-id','twitter_image_id'=>'twitter-image-id',
    ];
    public static function register(): void {
        $fields=[];foreach(self::FIELDS as $name=>$key)$fields[$name]=str_ends_with($name,'_id')?Registry::integer(0):['type'=>'string','maxLength'=>4096];
        $fields['indexing']=['type'=>'string','enum'=>['default','index','noindex']];$fields['nofollow']=Registry::boolean();
        SeoIndexables::register();
        $permission=static fn($a)=>current_user_can('edit_post',(int)($a['id']??0))&&(!self::available()||current_user_can('wpseo_manage_options')||current_user_can('wpseo_edit_advanced_metadata'));
        Registry::add('content/get-seo','Lê campos armazenados pela API WPSEO_Meta e revisão final do conteúdo. Não confunde templates de título com HTML renderizado. Indisponível sem Yoast compatível; configuração institucional pertence ao Core.',['id'=>Registry::integer(1)],['id'],[self::class,'read'],$permission);
        Registry::add('content/update-seo','Atualiza somente os campos SEO fornecidos pela API do Yoast, com lock do conteúdo, revisão, backup e leitura de volta. String vazia limpa o campo; indexing:default restaura herança. Reconstrói o indexable pelo serviço do provedor; não escreve options privadas.',['id'=>Registry::integer(1),'values'=>['type'=>'object','properties'=>$fields,'minProperties'=>1,'additionalProperties'=>false],'expected_revision'=>Registry::string()],['id','values'],[self::class,'update'],$permission,false);
    }
    private static function available(): bool {
        return defined('WPSEO_VERSION')&&class_exists('WPSEO_Meta')&&is_callable(['WPSEO_Meta','get_value'])&&is_callable(['WPSEO_Meta','set_value'])&&function_exists('YoastSEO');
    }
    private static function values(int $id): array {
        $values=[];foreach(self::FIELDS as $name=>$key)$values[$name]=str_ends_with($name,'_id')?(int)\WPSEO_Meta::get_value($key,$id):(string)\WPSEO_Meta::get_value($key,$id);
        $values['indexing']=match((string)\WPSEO_Meta::get_value('meta-robots-noindex',$id)){'1'=>'noindex','2'=>'index',default=>'default'};
        $values['nofollow']=(string)\WPSEO_Meta::get_value('meta-robots-nofollow',$id)==='1';return $values;
    }
    public static function read(array $input): array {
        if(!self::available())return Result::fail('seo_provider_unavailable','Yoast SEO compatível não está ativo.');
        $id=(int)$input['id'];if(!get_post($id))return Result::fail('not_found','Conteúdo não encontrado.');
        return Result::ok(['id'=>$id,'provider'=>'yoast-seo','provider_version'=>WPSEO_VERSION,'values'=>self::values($id),'revision'=>ContentTools::revision($id),'value_scope'=>'stored_metadata','rendered_html_verified'=>false]);
    }
    /** Native attachment URL/metadata mapping; no remote downloads or basename guesses. */
    private static function images(array $values) {
        foreach(['open_graph_image','twitter_image'] as $key){
            $ik=$key.'_id';if(!array_key_exists($key,$values)&&!array_key_exists($ik,$values))continue;
            $url=$values[$key]??null;$id=(int)($values[$ik]??0);
            if($url!==null&&$url!==''){
                $found=(int)attachment_url_to_postid($url);
                $u=wp_upload_dir();$prefix=trailingslashit($u['baseurl']);if(str_starts_with($url,$prefix)){global $wpdb;$matches=Persistence::rows($wpdb->prepare("SELECT post_id FROM `$wpdb->postmeta` WHERE meta_key='_wp_attached_file' AND meta_value=%s LIMIT 2",substr($url,strlen($prefix))));if(count($matches)>1&&!$id)return new \WP_Error('seo_image_ambiguous','URL corresponde a mais de um anexo; informe ID válido.');}
                if(!$found){
                    $upload=wp_upload_dir();$base=trailingslashit($upload['baseurl']);
                    if(str_starts_with($url,$base)){
                        global $wpdb;$relative=substr($url,strlen($base));
                        // Candidate metadata search is bounded and never itself proves ownership.
                        $candidates=Persistence::rows($wpdb->prepare("SELECT post_id FROM `$wpdb->postmeta` WHERE meta_key='_wp_attachment_metadata' AND meta_value LIKE %s LIMIT 101",'%'.$wpdb->esc_like(basename($relative)).'%'));
                        if(count($candidates)>100)return new \WP_Error('seo_image_ambiguous','Muitas imagens candidatas. Informe o ID.');
                        foreach($candidates as $c)if(in_array($url,self::image_urls((int)$c['post_id']),true)){if($found&&$found!==(int)$c['post_id'])return new \WP_Error('seo_image_ambiguous','URL corresponde a mais de uma imagem.');$found=(int)$c['post_id'];}
                    }
                }
                if($id&&(!in_array($url,self::image_urls($id),true)))return new \WP_Error('seo_image_mismatch','URL e ID não identificam a mesma imagem.');
                if(!$id)$id=$found;
            }
            if($url===''){if($id)return new \WP_Error('seo_image_mismatch','URL vazia exige ID zero ou omitido.');$id=0;}
            if($id){$urls=self::image_urls($id);if(!$urls)return new \WP_Error('seo_image_invalid','Anexo deve ser imagem local com arquivo e metadados válidos.');if($url===null)$url=$urls[0];}
            elseif($url===null)$url='';
            $values[$key]=$url;$values[$ik]=$id;
        }return $values;
    }
    private static function image_urls(int $id): array {
        if(get_post_type($id)!=='attachment'||!wp_attachment_is_image($id))return [];
        $file=get_attached_file($id);$meta=wp_get_attachment_metadata($id);if(!$file||!is_file($file)||!is_array($meta)||empty($meta['width'])||empty($meta['height']))return [];
        $actual=wp_getimagesize($file);if(!$actual||(int)$actual[0] !== (int)$meta['width']||(int)$actual[1] !== (int)$meta['height'])return [];
        $main=wp_get_attachment_url($id);if(!$main)return [];$urls=[$main];$original=wp_get_original_image_url($id);if($original)$urls[]=$original;
        foreach(array_keys($meta['sizes']??[]) as $size){$v=wp_get_attachment_image_src($id,$size);if($v&&is_file(dirname($file).'/'.$meta['sizes'][$size]['file']))$urls[]=$v[0];}
        return array_values(array_unique($urls));
    }
    public static function update(array $input): array {
        if(!self::available())return Result::fail('seo_provider_unavailable','Yoast SEO compatível não está ativo.');
        $id=(int)$input['id'];if(!get_post($id))return Result::fail('not_found','Conteúdo não encontrado.');
        foreach(['canonical','open_graph_image','twitter_image'] as $field)if(isset($input['values'][$field])&&$input['values'][$field]!==''&&(!in_array(wp_parse_url($input['values'][$field],PHP_URL_SCHEME),['http','https'],true)||!wp_parse_url($input['values'][$field],PHP_URL_HOST)))return Result::fail('seo_url_invalid','URLs SEO precisam ser absolutas HTTP(S) ou vazias.');
        $services=SeoIndexables::services();if(is_wp_error($services))return Result::error($services);
        try{$rows=SeoIndexables::rows($id);}catch(\Throwable $e){return Result::fail('seo_provider_incompatible','Tabela de indexação indisponível.');}
        if(count($rows)>1)return Result::fail('seo_indexable_duplicates','Existem duplicatas; use a prévia content/deduplicate-seo-indexables.',['count'=>count($rows),'repair_ability'=>'content/deduplicate-seo-indexables']);
        $ready=SeoIndexables::preflight($id);if(is_wp_error($ready))return Result::error($ready);
        $images=self::images($input['values']);if(is_wp_error($images))return Result::error($images);$input['values']=$images;
        $before=self::values($id);$changes=array_filter($input['values'],static fn($v,$k)=>$v!==$before[$k],ARRAY_FILTER_USE_BOTH);
        if(!$changes)return Result::ok(self::read($input)+['changed'=>false,'persisted'=>true]);
        $raw_meta=[];foreach(self::FIELDS as $key){$full='_yoast_wpseo_'.$key;$raw_meta[$full]=['exists'=>metadata_exists('post',$id,$full),'values'=>get_post_meta($id,$full,false)];}
        $backup=Backups::create_snapshot('content/update-seo',['id'=>$id,'provider'=>'yoast-seo','version'=>WPSEO_VERSION,'values'=>$before,'raw_metadata'=>$raw_meta]);if(is_wp_error($backup))return Result::error($backup);
        foreach($changes as $name=>$value){
            $key=self::FIELDS[$name]??($name==='indexing'?'meta-robots-noindex':'meta-robots-nofollow');
            if($name==='indexing')$value=match($value){'noindex'=>'1','index'=>'2',default=>'0'};
            if($name==='nofollow')$value=$value?'1':'0';
            if($value==='')\WPSEO_Meta::delete($key,$id);else \WPSEO_Meta::set_value($key,(string)$value,$id);
        }
        $indexed=SeoIndexables::rebuild($id,$rows?(int)$rows[0]['id']:null);
        clean_post_cache($id);$after=self::values($id);$filtered=[];foreach($changes as $field=>$value)if($after[$field]!==$value)$filtered[]=$field;
        $data=self::read($input)+['changed'=>$before!==$after,'applied'=>$before!==$after,'persisted'=>!$filtered,'backup_id'=>$backup,'indexable_rebuilt'=>$indexed,'filtered_fields'=>$filtered];
        if($filtered||!$indexed)return Result::fail($filtered?'seo_fields_filtered':'seo_indexable_unconfirmed','Metadados foram processados, mas há divergência ou indexação não confirmada. Consulte valores e pré-imagem.',$data);
        return Result::ok($data);
    }
}
