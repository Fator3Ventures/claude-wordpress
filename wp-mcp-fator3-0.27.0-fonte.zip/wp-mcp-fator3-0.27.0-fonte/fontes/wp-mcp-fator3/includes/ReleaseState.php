<?php
/** Release observations are independent of data schema and package-origin permissions. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ReleaseState {
    public static function run(): array {
        try {
            return Locks::run(['release-initialization'=>LOCK_EX], static function(): array {
                $schema = get_option('f3_mcp_schema_version', 0);
                if (!in_array($schema, [0, 2, '0', '2'], true)) {
                    return Result::fail('mcp_schema_unsupported', 'Formato de persistência MCP não reconhecido; preserve os dados e confira a versão do schema.');
                }
                Persistence::install();
                $saved = Persistence::get('release-state', 'current');
                if (($saved['version'] ?? '') === F3_MCP_FILES_VERSION) return Result::ok(['changed'=>false]);
                Persistence::put('release-state', 'current', [
                    'version'=>F3_MCP_FILES_VERSION, 'status'=>'complete',
                    'observed_at'=>time(), 'data_schema'=>2,
                ]);
                if ((Persistence::get('release-state', 'current')['version'] ?? '') !== F3_MCP_FILES_VERSION) {
                    throw new \RuntimeException('Release observation unavailable.');
                }
                return Result::ok(['changed'=>true]);
            });
        } catch (\Throwable $error) {
            return Result::fail('mcp_initialization_failed', 'Persistência MCP indisponível; confira a instalação e o armazenamento.');
        }
    }

    public static function boot(): void {
        $result = self::run();
        if (!empty($result['success'])) {
            require_once F3_MCP_FILES_DIR . 'core/bootstrap.php';
            return;
        }
        add_action('admin_notices', static function(): void {
            echo '<div class="notice notice-error"><p>Fator3 MCP: inicialização incompleta. Confira a persistência e o armazenamento antes de usar o canal.</p></div>';
        });
        add_filter('rest_authentication_errors', static function($prior) use ($result) {
            $route = ConnectionEndpoints::request_route();
            if ($route === null || !ConnectionEndpoints::matches($route)) return $prior;
            return new \WP_Error($result['error_code'], $result['message'], ['status'=>503]);
        }, PHP_INT_MAX);
    }
}
