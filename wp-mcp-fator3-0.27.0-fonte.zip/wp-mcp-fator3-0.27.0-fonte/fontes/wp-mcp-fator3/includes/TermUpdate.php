<?php
/** Native taxonomy updates with identity, URL preview and bounded preimage. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class TermUpdate {
    public static function register(): void {
        Registry::add('content/update-term','Atualiza campos enviados por wp_update_term, com backup e revisão. Mudança efetiva de slug ou pai hierárquico exige duas fases. Não cria redirecionamento nem faz flush de permalinks.', ['taxonomy'=>Registry::string(),'term_id'=>Registry::integer(1),'name'=>['type'=>'string','minLength'=>1,'maxLength'=>200],'slug'=>['type'=>'string','minLength'=>1,'maxLength'=>200],'description'=>Registry::string(),'parent'=>Registry::integer(0),'expected_revision'=>Registry::string(),'confirm_token'=>Registry::string()],['taxonomy','term_id'],[self::class,'update'],[self::class,'permission'],false);
    }
    public static function permission(array $i): bool {
        $tax=get_taxonomy((string)($i['taxonomy']??''));return $tax&&current_user_can($tax->cap->edit_terms)&&current_user_can('edit_term',(int)($i['term_id']??0));
    }
    private static function snapshot(array $i) {
        global $wpdb;$id=(int)$i['term_id'];$tax=(string)$i['taxonomy'];
        if(!self::permission($i))return new \WP_Error('permission_denied','Taxonomia registrada e capacidade nativa de edição necessárias.');
        clean_term_cache($id,$tax);$term=get_term($id,$tax,ARRAY_A);if(!$term||is_wp_error($term))return new \WP_Error('term_not_found','Termo não encontrado.');
        $fields=array_intersect_key($i,array_flip(['name','slug','description','parent']));if(!$fields)return new \WP_Error('term_change_required','Informe ao menos um campo.');
        if(isset($fields['slug'])&&($fields['slug']===''||sanitize_title($fields['slug'])!==$fields['slug']))return new \WP_Error('term_slug_invalid','Slug deve ser canônico e não vazio.');
        if(isset($fields['name'])&&trim($fields['name'])==='')return new \WP_Error('term_name_invalid','Nome não pode ser vazio.');
        $parent=(int)($fields['parent']??$term['parent']);
        if($parent){if(!is_taxonomy_hierarchical($tax))return new \WP_Error('term_parent_invalid','Taxonomia não hierárquica.');$seen=[$id];$pid=$parent;while($pid){if(in_array($pid,$seen,true))return new \WP_Error('term_parent_cycle','Pai criaria ciclo.');$seen[]=$pid;$t=get_term($pid,$tax);if(!$t||is_wp_error($t))return new \WP_Error('term_parent_invalid','Pai ausente na taxonomia.');$pid=(int)$t->parent;}}
        if(defined('WPSEO_VERSION')){$ready=SeoIndexables::preflight($id,'term');if(is_wp_error($ready))return $ready;}
        $slug=(string)($fields['slug']??$term['slug']);$probe=(object)['term_id'=>$id,'taxonomy'=>$tax,'parent'=>$parent];
        if(wp_unique_term_slug($slug,$probe)!==$slug)return new \WP_Error('term_slug_conflict','Slug exigiria sufixo de unicidade.');
        $meta=Persistence::rows($wpdb->prepare("SELECT * FROM `$wpdb->termmeta` WHERE term_id=%d ORDER BY meta_id LIMIT 1001",$id));
        $rels=Persistence::rows($wpdb->prepare("SELECT * FROM `$wpdb->term_relationships` WHERE term_taxonomy_id=%d ORDER BY object_id LIMIT 1001",$term['term_taxonomy_id']));
        $children=is_taxonomy_hierarchical($tax)?get_term_children($id,$tax):[];if(is_wp_error($children))return $children;
        $seo=[];if(defined('WPSEO_VERSION')){$seo['taxonomy_meta']=get_option('wpseo_taxonomy_meta',[]);$seo['version']=WPSEO_VERSION;$seo['indexables']=SeoIndexables::rows($id,false,'term');}
        $parents=[];foreach(array_slice($seen??[],1) as $pid)$parents[]=get_term($pid,$tax,ARRAY_A);
        $s=['term'=>$term,'meta'=>$meta,'relationships'=>$rels,'children'=>$children,'parents'=>$parents,'provider'=>$seo,'url'=>get_term_link($id,$tax)];
        if(is_wp_error($s['url']))$s['url']=null;
        if(count($meta)+count($rels)+count($children)>1000||strlen(serialize($s))>4194304)return new \WP_Error('term_preimage_limit','Pré-imagem excede 1000 linhas ou 4 MiB.');
        $s['revision']=hash('sha256',serialize($s));return $s;
    }
    public static function update(array $i): array {
        return Locks::run(['taxonomy-terms:'.get_current_blog_id()=>LOCK_EX],static function()use($i){
            $s=self::snapshot($i);if(is_wp_error($s))return Result::error($s);
            if(isset($i['expected_revision'])&&!hash_equals($s['revision'],$i['expected_revision']))return Result::fail('term_conflict','Termo mudou.',['revision'=>$s['revision'],'conflict'=>true]);
            $fields=array_intersect_key($i,array_flip(['name','slug','description','parent']));$changes=[];foreach($fields as $k=>$v)if((string)$s['term'][$k]!== (string)$v)$changes[$k]=$v;
            if(!$changes&&empty($i['confirm_token']))return Result::ok(['changed'=>false,'persisted'=>true,'term_id'=>(int)$i['term_id'],'term_taxonomy_id'=>(int)$s['term']['term_taxonomy_id'],'revision'=>$s['revision'],'url'=>$s['url']]);
            $two=isset($changes['slug'])||isset($changes['parent'])&&is_taxonomy_hierarchical($i['taxonomy']);
            return Phase::run('content/update-term',$i,static function()use($i){$s=self::snapshot($i);return is_wp_error($s)?$s:['term_id'=>(int)$i['term_id'],'term_taxonomy_id'=>(int)$s['term']['term_taxonomy_id'],'revision'=>$s['revision'],'old_url'=>$s['url'],'affected_descendants'=>count($s['children']),'proposed'=>array_intersect_key($i,array_flip(['name','slug','description','parent']))];},static function($before)use($i,$fields){
                $s=self::snapshot($i);if(is_wp_error($s))return Result::error($s);if($s['revision']!==$before['revision'])return Result::fail('term_conflict','Termo mudou antes da gravação.');
                $backup=Backups::create_snapshot('content/update-term',$s);if(is_wp_error($backup))return Result::error($backup);
                $saved=wp_update_term((int)$i['term_id'],$i['taxonomy'],wp_slash($fields));if(is_wp_error($saved))return Result::error($saved)+['backup_id'=>$backup];
                clean_term_cache((int)$i['term_id'],$i['taxonomy']);$after=get_term((int)$i['term_id'],$i['taxonomy'],ARRAY_A);$filtered=[];foreach($fields as $k=>$v)if((string)($after[$k]??'')!==(string)$v)$filtered[]=$k;
                $indexed=!defined('WPSEO_VERSION')||SeoIndexables::rebuild((int)$i['term_id'],isset($s['provider']['indexables'][0]['id'])?(int)$s['provider']['indexables'][0]['id']:null,'term');
                $fresh=self::snapshot($i);$data=['term_id'=>(int)$i['term_id'],'term_taxonomy_id'=>(int)$saved['term_taxonomy_id'],'taxonomy'=>$i['taxonomy'],'changed'=>$s['term']!==$after,'persisted'=>!$filtered,'backup_id'=>$backup,'filtered_fields'=>$filtered,'url'=>get_term_link((int)$i['term_id'],$i['taxonomy']),'revision'=>is_wp_error($fresh)?'':$fresh['revision'],'indexable_rebuilt'=>$indexed,'native_hooks_invoked'=>true,'redirect_created'=>false];
                if($filtered||is_wp_error($fresh)||!$indexed)return Result::fail('term_update_unconfirmed','Gravação processada; confira releitura e backup.',$data+['partial'=>true]);return Result::ok($data);
            },$two);
        });
    }
}
