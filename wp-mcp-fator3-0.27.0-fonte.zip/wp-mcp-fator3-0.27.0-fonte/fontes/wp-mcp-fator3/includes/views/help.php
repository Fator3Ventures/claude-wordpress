<?php
namespace Fator3\McpFiles;
if(!current_user_can('manage_options'))return;
$catalog=Guide::read([]);$document=is_string($_GET['document']??null)?wp_unslash($_GET['document']):'administracao';
$input=['document'=>$document,'byte_limit'=>8192];if(is_string($_GET['cursor']??null))$input['cursor']=wp_unslash($_GET['cursor']);
$page=Guide::read($input);
echo '<section class="f3-card"><h2>Ajuda e documentação</h2><p>Consulte o manual instalado com esta versão. Os mesmos documentos estão disponíveis ao assistente pela habilidade system/guide.</p><form method="get"><input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="help"><label for="f3-help-document">Documento</label> <select name="document" id="f3-help-document">';
foreach($catalog['documents']??[] as $doc)echo '<option value="'.esc_attr($doc['id']).'" '.selected($document,$doc['id'],false).'>'.esc_html($doc['title']).'</option>';
echo '</select> <button class="button">Abrir documento</button></form>';
if(empty($page['success']))echo '<p role="alert">'.esc_html($page['message']??'Documento indisponível.').'</p>';
else{
    echo '<p>Trecho '.esc_html((string)($page['offset_bytes']+1)).' a '.esc_html((string)($page['offset_bytes']+$page['returned_bytes'])).' de '.esc_html((string)$page['total_bytes']).' bytes.</p><pre class="f3-manual" tabindex="0">'.esc_html($page['content']).'</pre>';
    echo '<div class="f3-actions"><a href="'.esc_url(add_query_arg('document',$document,Admin::url('help'))).'">Início do documento</a>';
    if($page['has_more'])echo '<a class="button" href="'.esc_url(add_query_arg(['document'=>$document,'cursor'=>$page['next_cursor']],Admin::url('help'))).'">Continuar leitura</a>';
    echo '</div>';
}
echo '</section>';
