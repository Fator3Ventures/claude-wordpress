<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$enabled = PathGuard::is_enabled(); $hard = Admin::hard_block();
?>
<div class="f3-grid">
<section class="f3-card"><div class="f3-card-heading"><h2>Arquivos e banco</h2><?php Admin::badge($enabled, 'Canal habilitado', 'Canal fechado'); ?></div>
    <p>Controla files/* e o acesso ao banco. O servidor MCP e as habilidades de conteúdo mantêm suas próprias permissões.</p>
    <?php if ($hard): ?><p class="f3-error">Canal bloqueado por DISALLOW_FILE_EDIT ou DISALLOW_FILE_MODS no wp-config.php.</p><?php elseif (Admin::forced_by_filter()): ?><p class="f3-subtle">Estado controlado também pelo filtro f3_mcp_files_enabled.</p><?php endif; ?>
    <?php Admin::form('channel', (bool)get_option(PathGuard::OPTION_ENABLED, true), $hard); ?>
    <?php if ($enabled): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php Admin::nonce('f3_mcp_settings'); ?><input type="hidden" name="action" value="f3_mcp_save"><input type="hidden" name="section" value="channel"><input type="hidden" name="enable" value="0"><button class="button f3-danger">Fechar canal agora</button><p class="description">Solicita o bloqueio de novas chamadas de arquivos e banco. Confira o estado efetivo após salvar: filtros do site podem sobrepor essa preferência.</p></form><?php endif; ?>
</section>
<section class="f3-card"><div class="f3-card-heading"><h2>Escrita no banco</h2><?php Admin::badge($enabled && Database::writes_enabled(), 'Escrita habilitada', 'Escrita indisponível'); ?></div><p>db/execute exige prévia e token de confirmação. A leitura por db/query e db/schema acompanha o canal geral.</p>
    <?php if (!$enabled): ?><p class="f3-subtle">O canal geral está fechado. A preferência será aplicada quando ele estiver habilitado.</p><?php endif; ?>
    <?php if (has_filter('f3_mcp_db_writes_enabled')): ?><p>O filtro f3_mcp_db_writes_enabled também controla o resultado efetivo.</p><?php endif; ?>
    <?php Admin::form('database', (bool)get_option(Database::OPTION_WRITES, true)); ?>
    <p><a href="<?php echo esc_url(add_query_arg('document','sql-guard',Admin::url('help'))); ?>">Como funciona a confirmação SQL</a></p>
</section></div>
<section class="f3-card"><h2>Limite do canal por arquivo</h2>
<?php $file_limit=get_option('f3_mcp_file_bytes',16777216); ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php Admin::nonce('f3_mcp_file_limit'); ?>
<input type="hidden" name="action" value="f3_mcp_file_limit"><input type="hidden" name="revision" value="<?php echo esc_attr(hash('sha256',serialize($file_limit))); ?>">
<label for="f3-global-limit">Tamanho máximo em bytes</label><br><input id="f3-global-limit" type="number" required min="1048576" max="1073741824" step="1" name="file_bytes" value="<?php echo esc_attr((string)$file_limit); ?>" aria-describedby="f3-global-help">
<?php Admin::help('f3-global-help','Entre 1 MiB e 1 GiB. Perfis de Manutenção herdam este valor, salvo limite próprio; filtros do servidor podem restringir o limite efetivo.'); ?>
<button class="button button-primary">Salvar limite</button></form></section>
<section class="f3-card"><h2>Alcance e limites efetivos</h2><p><?php echo esc_html(PathGuard::is_confined() ? 'O acesso está restrito às raízes configuradas, respeitando as permissões do PHP.' : 'O canal alcança os arquivos permitidos ao usuário do PHP, inclusive arquivos de configuração e credenciais. A autoedição do plugin é bloqueada por padrão.'); ?></p>
<dl class="f3-facts">
<dt>Escopo</dt><dd><?php echo esc_html(PathGuard::is_confined() ? implode(', ', PathGuard::roots()) ?: 'Nenhuma raiz válida: acesso recusado.' : 'Sistema de arquivos alcançável pelo PHP'); ?></dd>
<dt>Limite por arquivo</dt><dd><?php echo esc_html(size_format(PathGuard::max_bytes())); ?></dd>
<dt>Permissão para arquivos</dt><dd><?php Admin::badge(PathGuard::can_edit(), 'Sua conta está autorizada', 'Sua conta não tem permissão'); ?> <span class="description">edit_themes + manage_options</span></dd>
<dt>Restrição de diretórios do PHP</dt><dd><?php echo esc_html(ini_get('open_basedir') ?: 'Não definido'); ?></dd>
<dt>Extensões permitidas</dt><dd><?php echo esc_html(implode(', ', PathGuard::allowed_extensions()) ?: 'Todas, salvo bloqueios abaixo'); ?></dd>
<dt>Extensões bloqueadas</dt><dd><?php echo esc_html(implode(', ', PathGuard::denied_extensions()) ?: 'Nenhuma regra adicional'); ?></dd>
<dt>Nomes protegidos</dt><dd><?php echo esc_html(implode(', ', PathGuard::denied_basenames()) ?: 'Sem lista adicional de nomes'); ?></dd>
</dl><p class="description">Constantes e filtros do site definem limites adicionais. As gravações concorrentes usam os mesmos bloqueios por arquivo.</p></section>

<section class="f3-card"><h2>Retenção dos backups SQL</h2><p>A política seleciona dumps automáticos por idade ou quantidade e preserva o mínimo recente e as referências ativas. Nenhum arquivo é apagado automaticamente.</p>
<?php $policy=SqlArtifacts::policy(); ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<?php Admin::nonce('f3_mcp_sql_retention'); ?>
<input type="hidden" name="action" value="f3_mcp_sql_retention"><input type="hidden" name="revision" value="<?php echo esc_attr(hash('sha256',serialize($policy))); ?>">
<?php foreach(['older_than_days'=>['Idade em dias',1,3650],'max_count'=>['Quantidade máxima',1,10000],'min_keep'=>['Mínimo a preservar',0,10000]] as $key=>$field): ?>
<p><label for="f3-<?php echo esc_attr($key); ?>"><?php echo esc_html($field[0]); ?></label><br><input id="f3-<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>" type="number" required aria-describedby="f3-retention-<?php echo esc_attr($key); ?>" min="<?php echo (int)$field[1]; ?>" max="<?php echo (int)$field[2]; ?>" value="<?php echo (int)$policy[$key]; ?>"></p>
<?php Admin::help('f3-retention-'.$key,['older_than_days'=>'Idade mínima para selecionar backups automáticos antigos.','max_count'=>'Quantidade máxima desejada no acervo automático.','min_keep'=>'Quantidade recente preservada, mesmo ao exceder idade ou volume.'][$key]); endforeach; ?><button class="button button-primary">Salvar política</button></form>
<p><a href="<?php echo esc_url(add_query_arg('document','sql-retention',Admin::url('help'))); ?>">Consultar instruções de limpeza dos backups</a></p></section>
