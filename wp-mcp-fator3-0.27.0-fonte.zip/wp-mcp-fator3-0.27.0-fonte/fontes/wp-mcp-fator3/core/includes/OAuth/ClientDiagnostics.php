<?php
/** Bounded private diagnostic ring; never accepts request payloads or exception text. */
declare(strict_types=1);
namespace WpMcpUltimate\OAuth;
use Fator3\McpFiles\StateStore;

final class ClientDiagnostics {
    private const CODES = ['client_unavailable', 'metadata_fetch_failed', 'metadata_invalid', 'metadata_unsafe', 'metadata_method_unsupported', 'client_persistence_failed'];
    /** Read a bounded atomic snapshot. No repair, remote fetch or credential disclosure. */
    public static function listing(array $input = []): array {
        if (!current_user_can('manage_options')) return \Fator3\McpFiles\Result::fail('permission_denied','Permissão insuficiente.');
        try {
            $base=rtrim(wp_normalize_path(defined('F3_MCP_PRIVATE_DIR')?(string)F3_MCP_PRIVATE_DIR:WP_CONTENT_DIR.'/f3-mcp-private'),'/');
            $dir=$base.'/oauth-diagnostics';$path=$dir.'/ring.php';
            if ((!str_starts_with($base,'/')&&!preg_match('~^[A-Za-z]:/~',$base))||is_link($base)||is_link($dir)||is_link($path)) throw new \RuntimeException();
            $records=[];
            if (file_exists($path)) {
                if(!is_file($path))throw new \RuntimeException();
                $bytes=@file_get_contents($path,false,null,0,65537);
                if(!is_string($bytes)||strlen($bytes)>65536||!str_starts_with($bytes,StateStore::HEADER))throw new \RuntimeException();
                $records=json_decode(substr($bytes,strlen(StateStore::HEADER)),true,512,JSON_THROW_ON_ERROR);
                if(!is_array($records)||!array_is_list($records)||count($records)>128)throw new \RuntimeException();
            }
            $entries=[];
            foreach(array_reverse($records) as $row) {
                if(!is_array($row)||($row['site_id']??null)!==get_current_blog_id())continue;
                if(!is_string($row['diagnostic_id']??null)||!preg_match('/^[a-f0-9]{24}$/D',$row['diagnostic_id'])
                    ||!in_array($row['category']??null,self::CODES,true)||!is_int($row['time']??null)||$row['time']<1)continue;
                $entries[]=array_intersect_key($row,array_flip(['diagnostic_id','category','time']));
            }
            return \Fator3\McpFiles\Result::ok(['entries'=>$entries,'total'=>count($entries),'limit'=>128,'order'=>'newest_first','time_format'=>'unix_seconds','retention'=>'last_128_failures']);
        } catch (\Throwable $error) {
            return \Fator3\McpFiles\Result::fail('oauth_diagnostics_unavailable','Não foi possível ler as falhas de autorização de clientes.');
        }
    }
    public static function failure(string $category, string $client_id = ''): \WP_Error {
        if (!in_array($category, self::CODES, true)) $category = 'metadata_invalid';
        $id = bin2hex(random_bytes(12));
        $record = ['diagnostic_id'=>$id, 'category'=>$category, 'time'=>time(), 'site_id'=>get_current_blog_id(), 'client_hash'=>hash_hmac('sha256', $client_id, wp_salt('auth'))];
        // Last 128 records, PHP guard, 0600 files. SQL failures can still be diagnosed.
        try {
            $dir = StateStore::directory('oauth-diagnostics');
            $lock=fopen($dir.'/ring.lock.php','c+b');
            if(!$lock)throw new \RuntimeException('Diagnostic lock unavailable.');
            @chmod($dir.'/ring.lock.php',0600);
            try {
                if(!flock($lock,LOCK_EX))throw new \RuntimeException('Diagnostic lock unavailable.');
                $path=$dir.'/ring.php';$records=[];
                if(is_file($path)) {
                    $bytes=file_get_contents($path,false,null,0,65537);
                    if(is_string($bytes)&&strlen($bytes)<=65536&&str_starts_with($bytes,StateStore::HEADER))$records=json_decode(substr($bytes,strlen(StateStore::HEADER)),true)?:[];
                }
                if(!is_array($records)||!array_is_list($records))$records=[];
                $records=array_slice($records,-127);$records[]=$record;
                StateStore::write($path,StateStore::HEADER.wp_json_encode($records));
            } finally {flock($lock,LOCK_UN);fclose($lock);}
        } catch (\Throwable $ignored) { /* The opaque ID remains available; no unsafe log fallback. */ }
        return new \WP_Error($category, 'Client authorization could not be resolved.', ['diagnostic_id'=>$id]);
    }
}
