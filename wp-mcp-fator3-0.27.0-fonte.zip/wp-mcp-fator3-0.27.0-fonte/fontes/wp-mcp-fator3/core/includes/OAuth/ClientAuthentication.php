<?php
/** One source of truth for discovery, metadata negotiation and token requests. */
declare(strict_types=1);
namespace WpMcpUltimate\OAuth;

final class ClientAuthentication {
    public static function supported(): array { return ['none']; }
    public static function select(array $document) {
        if (array_key_exists('token_endpoint_auth_method', $document) && (!is_string($document['token_endpoint_auth_method']) || !preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $document['token_endpoint_auth_method']))) {
            return new \WP_Error('metadata_invalid', 'Invalid singular authentication method.');
        }
        if (array_key_exists('token_endpoint_auth_methods_supported', $document)) {
            $methods = $document['token_endpoint_auth_methods_supported'];
            if (!is_array($methods) || !array_is_list($methods) || !$methods || count($methods) > 32) return new \WP_Error('metadata_invalid', 'Invalid authentication methods list.');
            foreach ($methods as $method) if (!is_string($method) || !preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $method)) return new \WP_Error('metadata_invalid', 'Invalid authentication methods list.');
        } else {
            // Local CIMD policy: omitted methods describe a public client. DCR has its own validation.
            $methods = [$document['token_endpoint_auth_method'] ?? 'none'];
        }
        foreach (self::supported() as $method) if (in_array($method, $methods, true)) return $method;
        return new \WP_Error('metadata_method_unsupported', 'No mutually supported authentication method.');
    }
    public static function request_error(array $params, string $authorization = ''): ?\WP_Error {
        foreach (['client_secret', 'client_assertion', 'client_assertion_type'] as $field) if (array_key_exists($field, $params)) return new \WP_Error('invalid_client', 'Only public clients using none are supported.');
        if ($authorization !== '' || isset($_SERVER['PHP_AUTH_USER']) || isset($_SERVER['PHP_AUTH_PW'])) return new \WP_Error('invalid_client', 'Token endpoint client authentication must use none.');
        return null;
    }
}
