<?php
declare(strict_types=1);

namespace WpMcpUltimate\OAuth;

use Fator3\McpFiles\ConnectionEndpoints;

/** Authenticates MCP Bearer tokens only after WordPress has initialized REST. */
final class BearerAuth {
    private static bool $authenticating = false;

    public static function init(): void {
        // Never resolve routes or tokens from determine_current_user. URL and
        // endpoint filters can query the current user and re-enter that filter.
        // Priority 95 preserves Application Password (90) and cookie (100) auth.
        add_filter('rest_authentication_errors', [self::class, 'authenticate_rest'], 95);
    }

    public static function authenticate_rest($result) {
        if (null !== $result || self::$authenticating) return $result;

        // A normal anonymous request does not need MCP routing or token storage.
        $token = self::bearer_token();
        if (null === $token) return $result;
        if (!doing_filter('rest_authentication_errors') || doing_filter('determine_current_user') || !did_action('plugins_loaded') ||
            !did_action('rest_api_init') || doing_action('rest_api_init') ||
            !class_exists(ConnectionEndpoints::class, false)) return $result;

        self::$authenticating = true;
        try {
            // Resolve WordPress' cookie/Basic identity before calling any URL,
            // route, option or user-dependent filters. Preserve their precedence.
            if (get_current_user_id()) return $result;

            // Mirrors WordPress route precedence, including POST/GET rest_route.
            // A prefix or a foreign callback at our path must never gain a user.
            $route = ConnectionEndpoints::request_route();
            if (null === $route || !ConnectionEndpoints::is_registered($route)) return $result;

            $user_id = self::token_user($token);
            if (!$user_id) return $result;
            wp_set_current_user($user_id);
            return true;
        } finally {
            self::$authenticating = false;
        }
    }

    private static function token_user(string $token): int {
        $payload = TokenStore::get_access_token($token);
        if (!$payload || !self::positive_id($payload['user_id'] ?? null)) return 0;
        if (!self::positive_id($payload['site_id'] ?? null) || (int)$payload['site_id'] !== get_current_blog_id()) return 0;
        if (empty($payload['resource']) || is_wp_error(ConnectionEndpoints::resource($payload['resource']))) return 0;
        if (!is_string($payload['scope'] ?? null) || !in_array($payload['scope'], ['mcp','mcp:read','mcp:content','mcp:maintenance','mcp:custom'], true)) return 0;
        // Deleted users must not acquire a synthetic current identity.
        $user = get_user_by('id', (int)$payload['user_id']);
        if ($user) \Fator3\McpFiles\ConnectionContext::oauth($payload);
        return $user ? (int)$user->ID : 0;
    }

    private static function positive_id($value): bool {
        return (is_int($value) || (is_string($value) && preg_match('/^[0-9]+$/D', $value))) && (int)$value > 0;
    }

    /** Read only request bytes; no URL, sanitization or authentication filters. */
    private static function bearer_token(): ?string {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if ('' === $header) $header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        if (!is_string($header) || strlen($header) > 8192) return null;
        if (!preg_match('/^Bearer[ \t]+([A-Za-z0-9._~+\/-]+=*)[ \t]*$/iD', $header, $match)) return null;
        return $match[1];
    }
}
