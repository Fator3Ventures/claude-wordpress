<?php
/** Public-client CIMD resolution. Never called while exchanging a token in a SQL transaction. */
declare(strict_types=1);
namespace WpMcpUltimate\OAuth;
use Fator3\McpFiles\Http;

final class ClientMetadata {
    public static function valid_id(string $id): bool {
        if(strlen($id)>2048||preg_match('/[\x00-\x20]/',$id))return false;
        $p=wp_parse_url($id);$path=rawurldecode($p['path']??'');
        return ($p['scheme']??'')==='https'&&!empty($p['host'])&&$path!==''&&$path!=='/'&&!isset($p['user'],$p['pass'])&&!isset($p['fragment'])&&!isset($p['query'])&&!str_contains($path,'\\')&&!preg_match('~(^|/)\.\.?(/|$)~',$path)&&empty($p['user'])&&empty($p['pass']);
    }
    public static function resolve(string $id,?array $stored): ?array {
        $result=self::resolve_result($id,$stored);return is_wp_error($result)?null:$result;
    }
    public static function resolve_result(string $id,?array $stored) {
        $fail=static fn(string $code)=>ClientDiagnostics::failure($code,$id);
        if(!self::valid_id($id))return $fail('metadata_unsafe');
        if($stored&&($stored['issuer']??'')!==untrailingslashit(home_url()))return $fail('metadata_invalid');
        if($stored&&($stored['metadata_expires']??0)>time()&&($stored['token_endpoint_auth_method']??'')==='none')return $stored;
        $safe=Http::validate_public_url($id);if(is_wp_error($safe))return $fail('metadata_unsafe');
        // No redirects: client_id is the exact HTTPS document identity.
        try {$r=wp_safe_remote_get($id,['timeout'=>5,'redirection'=>0,'cookies'=>[],'sslverify'=>true,'limit_response_size'=>65537,'headers'=>['Accept'=>'application/json']]);}catch(\Throwable $e){return $fail('metadata_fetch_failed');}
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return $fail('metadata_fetch_failed');
        $type=strtolower(trim(explode(';',(string)wp_remote_retrieve_header($r,'content-type'))[0]));
        if($type!=='application/json')return $fail('metadata_invalid');
        $bytes=wp_remote_retrieve_body($r);if(strlen($bytes)>65536)return $fail('metadata_invalid');
        $decoded=json_decode($bytes);$doc=$decoded instanceof \stdClass?(array)$decoded:null;
        if(!is_array($doc)||array_is_list($doc)||($doc['client_id']??'')!==$id||!is_string($doc['client_name']??null)||trim($doc['client_name'])===''||strlen($doc['client_name'])>200)return $fail('metadata_invalid');
        $method=ClientAuthentication::select($doc);if(is_wp_error($method))return $fail($method->get_error_code());
        if(!is_array($doc['redirect_uris']??null)||!array_is_list($doc['redirect_uris'])||!count($doc['redirect_uris'])||count($doc['redirect_uris'])>5)return $fail('metadata_invalid');
        foreach($doc['redirect_uris'] as $uri)if(!is_string($uri)||strlen($uri)>2000||!RegistrationEndpoint::is_valid_redirect_uri($uri))return $fail('metadata_invalid');
        // Client capabilities may exceed this server's capabilities. They do not enable grants.
        // Absent fields retain OAuth registration defaults; present lists must support our flow.
        foreach(['grant_types'=>'authorization_code','response_types'=>'code'] as $field=>$required)if(array_key_exists($field,$doc)) {
            if(!is_array($doc[$field])||!array_is_list($doc[$field])||!$doc[$field])return $fail('metadata_invalid');
            foreach($doc[$field] as $value)if(!is_string($value)||$value===''||preg_match('/[\x00-\x1f\x7f]/',$value))return $fail('metadata_invalid');
            if(!in_array($required,$doc[$field],true))return $fail('metadata_invalid');
        }
        $cache=strtolower((string)wp_remote_retrieve_header($r,'cache-control'));$ttl=300;
        if(preg_match('/(?:^|,)\s*max-age\s*=\s*(\d+)/',$cache,$m))$ttl=min(3600,(int)$m[1]);
        if(str_contains($cache,'no-cache')||str_contains($cache,'no-store'))$ttl=0;
        $result=['client_id'=>$id,'client_name'=>sanitize_text_field($doc['client_name']),'redirect_uris'=>array_values(array_unique($doc['redirect_uris'])),'token_endpoint_auth_method'=>$method,'issuer'=>untrailingslashit(home_url()),'metadata_document'=>true,'metadata_expires'=>time()+$ttl,'status'=>'active','time'=>$stored['time']??time()];
        $persist=$result;if(str_contains($cache,'no-store')){$persist['client_name']='MCP Client';$persist['redirect_uris']=[];}
        try { $saved=TokenStore::save_client($id,$persist); } catch (\Throwable $e) { return $fail('client_persistence_failed'); }
        return $saved===true?$result:$fail('client_persistence_failed');
    }
}
