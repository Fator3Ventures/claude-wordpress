<?php
/** Persisted protocol sessions. Identity is provided by authenticated credentials. */
declare(strict_types=1);
namespace WpMcpUltimate\Server\Transport\Infrastructure;
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\ConnectionContext;
use Fator3\McpFiles\Locks;
final class SessionManager {
    private static function timeout(): int { return max(60,(int)apply_filters('f3_mcp_session_inactivity_timeout',DAY_IN_SECONDS)); }
    private static function key(int $user,string $id): string { return $user.':'.$id; }
    public static function create_session(int $user,array $params=[], $error_handler=null) {
        if(!$user||!get_user_by('id',$user)) return false;
        $result=Locks::run(['session-user:'.$user=>LOCK_EX],static function() use($user,$params) {
            self::cleanup_expired_sessions($user);
            $max=max(1,min(128,(int)apply_filters('f3_mcp_session_max_per_user',32)));
            if(count(Persistence::listing('sessions',['user_id'=>$user,'status'=>'active'],$max+1)) >= $max) return false;
            $id=wp_generate_uuid4(); $now=time();
            Persistence::put('sessions',self::key($user,$id),['session_id'=>$id,'user_id'=>$user,'connection_id'=>ConnectionContext::key(),'created_at'=>$now,'last_activity'=>$now,'negotiated_protocol_version'=>\WpMcpUltimate\Server\McpVersionNegotiator::negotiate((string)($params['protocolVersion']??'')),'client_params'=>array_replace(array_intersect_key($params,['protocolVersion'=>true,'clientInfo'=>true,'capabilities'=>true]),['negotiatedProtocolVersion'=>\WpMcpUltimate\Server\McpVersionNegotiator::negotiate((string)($params['protocolVersion']??''))]),'status'=>'active','expires'=>$now+self::timeout()],true);
            return $id;
        });
        return is_string($result)?$result:false;
    }
    public static function get_session(int $user,string $id) {
        if(!$user||!preg_match('/^[a-zA-Z0-9-]{1,128}$/D',$id)) return false;
        $row=Persistence::get('sessions',self::key($user,$id));
        if(!$row||($row['_storage']['status']??'')!=='active'||(int)($row['expires']??0)<=time()) return false;
        if(empty($row['negotiated_protocol_version']))return false;
        if(isset($row['connection_id']) && $row['connection_id']!==ConnectionContext::key()) return false;
        return $row;
    }
    public static function validate_session(int $user,string $id,$error_handler=null): bool {
        $row=self::get_session($user,$id); if(!$row) return false;
        if(time()-(int)$row['last_activity']>=60) {
            $result=Locks::run(['session:'.self::key($user,$id)=>LOCK_EX],static function() use($user,$id) {
                $row=self::get_session($user,$id); if(!$row) return false;
                $row['last_activity']=time(); $row['expires']=time()+self::timeout();
                Persistence::put('sessions',self::key($user,$id),$row); return true;
            });
            return true===$result;
        }
        return true;
    }
    public static function delete_session(int $user,string $id,$error_handler=null): bool {
        return true===Locks::run(['session:'.self::key($user,$id)=>LOCK_EX],static function()use($user,$id) { if(!self::get_session($user,$id))return false;return Persistence::delete('sessions',self::key($user,$id)); });
    }
    public static function get_all_user_sessions(int $user): array {
        if(!$user) return []; $out=[];
        foreach(Persistence::listing('sessions',['user_id'=>$user,'status'=>'active'],1000) as $row) if($row['expires']>time()) $out[$row['session_id']]=$row;
        return $out;
    }
    public static function cleanup_expired_sessions(int $user): int {
        $n=0;
        foreach(Persistence::listing('sessions',['user_id'=>$user,'status'=>'active'],1000) as $row) if($row['expires']<=time()) { Persistence::delete('sessions',self::key($user,$row['session_id']));$n++; }
        return $n;
    }
}
