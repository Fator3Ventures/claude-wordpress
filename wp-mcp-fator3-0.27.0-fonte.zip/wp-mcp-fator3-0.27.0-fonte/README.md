# Fator3 MCP 0.27.0

Servidor MCP independente para WordPress. Pedidos MCP 63/64: rótulos públicos em português, interseção de capacidades CIMD e diagnóstico administrativo das falhas de cliente. Base imediata 0.26.1; instalação limpa; WordPress 7.1.2 / PHP 8.3.6.

Operação e contratos: docs/OPERACAO.md, docs/OAUTH-CIMD.md e docs/RELEASE-0270.md. Guias instalados consultáveis por system/guide. Identidade wp-mcp-fator3/wp-mcp-fator3.php. B22 ChatGPT encerrado historicamente; aceite do aplicativo Claude distinguido dos testes do servidor.

Build: python3 tools/sync_docs.py; python3 tools/build_packages.py. Testes da rodada: tools/release0270; evidencias/0270. Fechamento: tools/release0270/close-release.py. Evidências anteriores são históricas. Contrato humano mutation-audit/1.0.0 revalidado com LinkedIn 0.6.0; contrato de serviço permanece proposta no impacto, sem capacidade de runtime. Nenhuma publicação automática em GitHub/frota. Sem tokens reais ou bancos privados nos pacotes.
