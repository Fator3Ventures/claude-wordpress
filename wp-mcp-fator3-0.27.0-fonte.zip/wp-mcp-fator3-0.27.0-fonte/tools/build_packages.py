#!/usr/bin/env python3
"""Build the sole versioned installer. No publishing, update feed, or homologation suffix."""
from pathlib import Path
import argparse,hashlib,json
import build
ROOT=build.ROOT
def runtime_digest(packages):
 h=hashlib.sha256()
 for slug,data in sorted(packages.items()):
  for path,value in sorted(data.items()):h.update(path.encode()+b'\0'+hashlib.sha256(value).digest())
 return h.hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path);p.add_argument('--review',action='store_true',help=argparse.SUPPRESS);a=p.parse_args()
 members=build.inventory();dest=a.out or ROOT;dest.mkdir(parents=True,exist_ok=True)
 file=dest/f'wp-mcp-fator3-{build.version()}-instalador.zip';build.write_zip(file,members);result=build.audit(file,members)
 report={'version':build.version(),'runtime_sha256':runtime_digest({'wp-mcp-fator3':members}),'installer':{k:v for k,v in result.items()if k!='members_sha256'},'published':False}
 (ROOT/'evidencias/package.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
