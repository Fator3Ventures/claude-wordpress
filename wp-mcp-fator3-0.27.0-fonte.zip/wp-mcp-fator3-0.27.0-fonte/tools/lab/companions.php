<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;use Fator3\McpFiles\Providers;
wp_set_current_user(1);Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'time'=>time()]);
$rows=[];$failures=[];$counts=[];
foreach(wp_get_abilities() as $ability){$name=$ability->get_name();$meta=$ability->get_meta();$provider=$meta['fator3']['provider']??Providers::metadata($name)['provider'];if(!in_array($provider,['base-site-core-fator3','wp-mcp-google-fator3'],true))continue;$counts[$provider]=($counts[$provider]??0)+1;
    $row=['name'=>$name,'provider'=>$provider,'version'=>$meta['fator3']['version']??Providers::metadata($name)['version'],'adherent'=>!empty($meta['fator3']['adherent']),'schema'=>$ability->get_input_schema(),'description'=>$ability->get_description(),'readonly'=>!empty($meta['annotations']['readonly'])];$rows[]=$row;if(!$row['version'])$failures[]=$name.':missing_version';
}
if(empty($counts['base-site-core-fator3'])||empty($counts['wp-mcp-google-fator3']))$failures[]='provider_catalog_missing';
file_put_contents(dirname(__DIR__,2).'/evidencias/companion-catalog-0140.json',wp_json_encode(['providers'=>Providers::all(),'counts'=>$counts,'catalog'=>$rows],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$GLOBALS['wpdb']->db_version(),'versions'=>['core'=>defined('F3BASE_PLUGIN_VERSAO')?F3BASE_PLUGIN_VERSAO:null,'google'=>defined('F3_MCP_GOOGLE_VERSION')?F3_MCP_GOOGLE_VERSION:null],'counts'=>$counts,'failures'=>$failures,'scope'=>'synthetic activation/catalog/policy metadata; no Google credentials or external calls'];file_put_contents(dirname(__DIR__,2).'/evidencias/companions-0140.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out,JSON_PRETTY_PRINT)."\n";
// Restore the base lab activation set; the integration fixture is independent of all other suites.
update_option('active_plugins',['wp-mcp-fator3/wp-mcp-fator3.php']);exit($failures?1:0);
