<?php
/** O06: cancel while another PHP process holds the plan lock and performs a write. */
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{Persistence, StateStore};
wp_set_current_user(1);
Persistence::put('connections', 'integration:user:1', ['user_id' => 1, 'connection_id' => 'integration:user:1', 'profile' => 'maintenance', 'status' => 'active', 'policy_version' => 1, 'roots' => [ABSPATH], 'time' => time()]);
$tests = [];
$directory = WP_CONTENT_DIR . '/f3-test-cancellation';
wp_mkdir_p($directory);
chmod($directory, 0700);
foreach ([false, true] as $uncertain) {
    $first = wp_insert_post(['post_title' => 'Synthetic first', 'post_content' => 'before-first', 'post_status' => 'draft']);
    $second = wp_insert_post(['post_title' => 'Synthetic second', 'post_content' => 'before-second', 'post_status' => 'draft']);
    $plan = wp_get_ability('operations/plan')->execute(['steps' => [
        ['id' => 'first', 'ability' => 'content/update-post', 'parameters' => ['id' => $first, 'content' => 'after-first']],
        ['id' => 'second', 'ability' => 'content/update-post', 'parameters' => ['id' => $second, 'content' => 'after-second'], 'depends_on' => ['first']],
    ]]);
    if (empty($plan['plan_id'])) throw new RuntimeException('Plan creation failed: ' . wp_json_encode($plan));
    $base = $directory . '/' . bin2hex(random_bytes(8));
    $fixture = ['plan_id' => $plan['plan_id'], 'post_id' => $first, 'ready' => $base . '.ready', 'release' => $base . '.release', 'uncertain' => $uncertain];
    file_put_contents($base . '.json', wp_json_encode($fixture));
    $process = proc_open([PHP_BINARY, ...(php_ini_loaded_file() ? ['-c', php_ini_loaded_file()] : []), __DIR__ . '/cancel-worker.php', $base . '.json'], [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
    fclose($pipes[0]);
    try {
        $deadline = microtime(true) + 15;
        while (!is_file($fixture['ready'])) {
            if (microtime(true) > $deadline) throw new RuntimeException('Cancellation worker did not reach barrier.');
            usleep(1000);
        }
        $started = microtime(true);
        $cancel = wp_get_ability('operations/cancel')->execute(['plan_id' => $plan['plan_id']]);
        $elapsed = microtime(true) - $started;
        $repeat = wp_get_ability('operations/cancel')->execute(['plan_id' => $plan['plan_id']]);
        $during = wp_get_ability('operations/status')->execute(['plan_id' => $plan['plan_id']]);
        $tests[] = ['name' => 'O06 cancellation is independent of long lock (' . ($uncertain ? 'uncertain' : 'success') . ')', 'passed' => ($cancel['status'] ?? '') === 'cancel_requested' && $elapsed < 2 && ($repeat['changed'] ?? true) === false && ($during['plan']['cancellation'] ?? '') === 'cancel_requested', 'latency_seconds' => round($elapsed, 4)];
    } finally {
        file_put_contents($fixture['release'], 'continue');
    }
    $output = stream_get_contents($pipes[1]);
    $errors = stream_get_contents($pipes[2]);
    fclose($pipes[1]); fclose($pipes[2]);
    $exit = proc_close($process);
    $result = json_decode($output, true);
    clean_post_cache($first); clean_post_cache($second);
    $state = StateStore::get('plans', $plan['plan_id']);
    $preserved = $exit === 0 && get_post_field('post_content', $first, 'raw') === 'after-first' && get_post_field('post_content', $second, 'raw') === 'before-second' && $state['steps'][1]['status'] === 'pending';
    if (!$uncertain) {
        $again = wp_get_ability('operations/apply')->execute(['plan_id' => $plan['plan_id']]);
        $tests[] = ['name' => 'O06 completed in-flight step retained; next step never starts after cancellation or resume', 'passed' => $preserved && ($result['plan']['status'] ?? '') === 'cancelled' && $state['steps'][0]['status'] === 'complete' && ($again['plan']['status'] ?? '') === 'cancelled'];
    } else {
        $step = $state['steps'][0]['result'] ?? [];
        $tests[] = ['name' => 'O06 failure after effect remains uncertain, never disguised as rollback', 'passed' => $preserved && ($step['error_code'] ?? '') === 'operation_exception' && array_key_exists('applied', $step) && $step['applied'] === null && ($result['plan']['status'] ?? '') === 'failed'];
    }
    foreach (glob($base . '.*') as $file) unlink($file);
    wp_delete_post($first, true); wp_delete_post($second, true);
}
rmdir($directory);
$failures = count(array_filter($tests, static fn($test) => !$test['passed']));
$out = ['php' => PHP_VERSION, 'wordpress' => $GLOBALS['wp_version'], 'database' => $wpdb->db_version(), 'workers' => 'Separate PHP processes; real post write and deterministic hook barrier.', 'tests' => count($tests), 'failures' => $failures, 'results' => $tests];
file_put_contents(dirname(__DIR__, 2) . '/evidencias/cancellation-0130.json', wp_json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
echo wp_json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
exit($failures ? 1 : 0);
