<?php
/** Real browser on a freshly-created local fixture, never on the fleet. */
require getenv('F3_WP_ROOT');
use Fator3\McpFiles\{Persistence,Recovery,SystemTools};
if(PHP_SAPI!=='cli'||home_url()!=='http://127.0.0.1:18093'||wp_get_environment_type()!=='local')throw new RuntimeException('Disposable loopback lab required.');
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'roots'=>[ABSPATH],'time'=>time()]);
$user=get_userdata(1);if($user->user_login!=='f3_lab_admin')throw new RuntimeException('Synthetic administrator required.');
$password=bin2hex(random_bytes(24));wp_set_password($password,1);
$post=wp_insert_post(wp_slash(['post_type'=>'post','post_title'=>'Synthetic editor roundtrip','post_status'=>'draft','post_content'=>'<!-- wp:group --><div class="wp-block-group"><!-- wp:paragraph --><p>Original</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Segundo</p><!-- /wp:paragraph --></div><!-- /wp:group -->']));
$edit=wp_get_ability('content/edit-block')->execute(['id'=>$post,'block_path'=>[0,0],'inner_html'=>'<p>Editado pelo MCP: <strong>texto</strong> \\--</p>']);
if(empty($edit['success']))throw new RuntimeException('Block setup failed.');
$plan=wp_get_ability('operations/plan')->execute(['steps'=>[['id'=>'sample','ability'=>'operations/assert','parameters'=>['actual'=>'synthetic','expected'=>'synthetic']]]]);
Recovery::install_sentinel();
$copy=WPMU_PLUGIN_DIR.'/f3-mcp-recovery-runtime-v1.php';file_put_contents($copy,"\n// Synthetic previous runtime marker\n",FILE_APPEND);
Recovery::refresh_existing_sentinel();
$refresh_ok=hash_file('sha256',$copy)===hash_file('sha256',F3_MCP_FILES_DIR.'includes/RecoveryEngine.php')&&Recovery::runtime_refresh_status()==='updated_for_next_request';
$health=SystemTools::health();$health_ok=isset($health['recovery']['status'],$health['recovery']['runtime_refresh']);
$block_external=WPMU_PLUGIN_DIR.'/f3-browser-no-external.php';
file_put_contents($block_external,"<?php add_filter('pre_http_request',static function(\$pre,\$args,\$url){return parse_url(\$url,PHP_URL_HOST)==='127.0.0.1'?\$pre:new WP_Error('fixture_external_http_blocked','Local test.');},10,3);\n");
$command=[getenv('CODEX_PRIMARY_RUNTIME_NODE')?:'node',__DIR__.'/browser.cjs'];
$process=proc_open($command,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,null,null);
if(!is_resource($process))throw new RuntimeException('Browser process unavailable.');
fwrite($pipes[0],json_encode(['origin'=>home_url(),'username'=>$user->user_login,'password'=>$password,'post_id'=>$post,'screenshots'=>dirname(__DIR__,2).'/evidencias/ui']));fclose($pipes[0]);
try {
    $stdout=stream_get_contents($pipes[1]);$stderr=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($process);
    $out=json_decode($stdout,true);
    if(!is_array($out))$out=['tests'=>1,'failures'=>1,'results'=>[['name'=>'Browser harness completed','passed'=>false]],'diagnostic'=>substr($stderr,0,1000)];
    $out['results'][]=['name'=>'Existing sentinel updates after source replacement','passed'=>$refresh_ok];
    $out['results'][]=['name'=>'Health exposes bounded recovery diagnostics','passed'=>$health_ok];
    $out['tests']=count($out['results']);$out['failures']=count(array_filter($out['results'],static fn($r)=>!$r['passed']));
    if($exit&&!$out['failures'])$out['failures']=1;
    $out+=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'scope'=>'Local Chromium on PHP HTTP development server; core/group and core/paragraph fixtures only, no production clients or fleet blocks.'];
    file_put_contents(dirname(__DIR__,2).'/evidencias/browser-0130.json',json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n");
    echo json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
}finally{
    @unlink($block_external);wp_delete_post($post,true);
    foreach(WP_Application_Passwords::get_user_application_passwords(1) as $app)WP_Application_Passwords::delete_application_password(1,$app['uuid']);
}
exit($out['failures']?1:0);
