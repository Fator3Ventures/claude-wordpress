<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\DebugTools;
use Fator3\McpFiles\StateStore;
wp_set_current_user(1);
Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'database_write'=>true,'roots'=>[ABSPATH],'allow_backup_export'=>true,'time'=>time()]);
$tests=[];$failures=0;
function check($name,$ok,$detail=[]){global $tests,$failures;$tests[]=['name'=>$name,'passed'=>(bool)$ok,'detail'=>$ok?null:$detail];if(!$ok)$failures++;}
function ability($name,$args=[]){$a=wp_get_ability($name);if(!$a)return ['error_code'=>'ability_missing'];$r=$a->execute($args);return is_wp_error($r)?['error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r;}
$dir=WP_CONTENT_DIR.'/f3-transfer-fixtures';wp_mkdir_p($dir);$path=$dir.'/file.bin';@unlink($path);
$bytes=str_repeat("test\x00\xff",50000);$r=ability('files/upload-create',['path'=>$path,'total_bytes'=>strlen($bytes),'sha256'=>hash('sha256',$bytes)]);$id=$r['transfer_id']??'';
check('E04 create does not change destination',!empty($r['success'])&&!file_exists($path),$r);
$r=ability('files/upload-finalize',['transfer_id'=>$id]);check('E04 missing parts refused',($r['error_code']??'')==='transfer_incomplete',$r);
foreach(str_split($bytes,262144) as $i=>$part){$r=ability('files/upload-part',['transfer_id'=>$id,'index'=>$i,'content_base64'=>base64_encode($part)]);check('E04 accepts bounded part '.$i,!empty($r['success']),$r);}
$r=ability('files/upload-part',['transfer_id'=>$id,'index'=>0,'content_base64'=>base64_encode(substr($bytes,0,262144))]);check('E04 identical part replay',!empty($r['success'])&&empty($r['changed']),$r);
$r=ability('files/upload-part',['transfer_id'=>$id,'index'=>0,'content_base64'=>base64_encode(str_repeat('x',262144))]);check('E04 different part conflict',($r['error_code']??'')==='transfer_part_conflict',$r);
$r=ability('files/upload-finalize',['transfer_id'=>$id]);check('E04 final binary equality',!empty($r['success'])&&is_file($path)&&hash_file('sha256',$path)===hash('sha256',$bytes),$r);
$r=ability('files/upload-finalize',['transfer_id'=>$id]);check('E04 completion replay',!empty($r['success'])&&!empty($r['replayed']),$r);
$new='new binary';$r=ability('files/upload-create',['path'=>$path,'total_bytes'=>strlen($new),'sha256'=>hash('sha256',$new),'expected_sha256'=>hash('sha256',$bytes),'label'=>'transfer']);$id=$r['transfer_id']??'';
ability('files/upload-part',['transfer_id'=>$id,'index'=>0,'content_base64'=>base64_encode($new)]);
$r=ability('files/upload-finalize',['transfer_id'=>$id]);check('E04 replacing makes preimage',!empty($r['success'])&&!empty($r['backup_id']),$r);$backup=$r['backup_id']??'';
$export='';$cursor='';$parts=0;do{$r=ability('backups/export-part',['backup_id'=>$backup,'cursor'=>$cursor,'byte_limit'=>65536]);if(empty($r['success']))break;$export.=base64_decode($r['content_base64'],true);$cursor=$r['next_cursor'];$parts++;}while($cursor&&$parts<30);
check('E05 export reconstructs backup JSON',!empty($r['success'])&&json_decode($export,true)!==null&&hash('sha256',$export)===($r['sha256']??'')&&$parts>1,$r);
$config="<?php\ndeclare(strict_types=1);\nif (true) { define('DB_NAME','fixture'); }\ndefine('WP_DEBUG', false);\n";
$r=DebugTools::rewrite($config,['WP_DEBUG'=>true,'WP_DEBUG_LOG'=>false]);check('F12 debug tokens preserve declare and insert globally',is_array($r)&&str_contains($r['content'],"define('WP_DEBUG', true)")&&strpos($r['content'],'WP_DEBUG_LOG')<strpos($r['content'],'if (true)')&&strpos($r['content'],'WP_DEBUG_LOG')>strpos($r['content'],'strict_types'),$r);
$r=DebugTools::rewrite("<?php define('WP_DEBUG', getenv('DEBUG'));",['WP_DEBUG'=>true]);check('F12 dynamic constant refused',is_wp_error($r)&&$r->get_error_code()==='debug_constant_dynamic');
$t=$wpdb->prefix.'f3_fixture_targets';$s=$wpdb->prefix.'f3_fixture_sources';
$wpdb->query("DROP TABLE IF EXISTS `$t`, `$s`");$wpdb->query("CREATE TABLE `$t` (id INT, part INT, grp INT, val VARCHAR(50), PRIMARY KEY(id,part)) ENGINE=InnoDB");$wpdb->query("CREATE TABLE `$s` (id INT PRIMARY KEY, grp INT, chosen INT) ENGINE=InnoDB");
add_filter('f3_mcp_sql_read_tables',static fn($tables)=>array_merge($tables,[$t,$s]));
$wpdb->query("INSERT INTO `$t` VALUES (1,1,10,'one'),(2,1,20,'two'),(2,2,20,'two-b')");$wpdb->query("INSERT INTO `$s` VALUES (1,10,1),(2,10,1),(3,20,0)");
$sql="UPDATE `$t` AS t INNER JOIN `$s` AS s ON t.grp=s.grp SET t.val='changed' WHERE s.chosen=1";
$r=ability('db/execute',['sql'=>$sql]);check('F23 JOIN distinct targets preview only',!empty($r['success'])&&($r['affected_rows']??-1)===1&&$wpdb->get_var("SELECT val FROM `$t` WHERE id=1")==='one',$r);
$token=$r['confirm_token']??'';$r=ability('db/execute',['sql'=>$sql,'confirm_token'=>$token]);check('F23 JOIN frozen PK update',!empty($r['success'])&&($r['affected_rows']??-1)===1&&$wpdb->get_var("SELECT val FROM `$t` WHERE id=1")==='changed',$r);
$r=ability('db/execute',['sql'=>$sql,'confirm_token'=>$token]);check('F23 confirmation replay',!empty($r['success'])&&!empty($r['replayed']),$r);
$sql="DELETE FROM `$t` WHERE grp IN (SELECT grp FROM `$s` WHERE chosen=0)";$r=ability('db/execute',['sql'=>$sql]);$token=$r['confirm_token']??'';check('F23 IN composite targets',!empty($r['success'])&&($r['affected_rows']??-1)===2,$r);
$wpdb->query("UPDATE `$s` SET chosen=1 WHERE id=3");$r=ability('db/execute',['sql'=>$sql,'confirm_token'=>$token]);check('F23 source change conflicts',($r['error_code']??'')==='database_conflict'&&(int)$wpdb->get_var("SELECT COUNT(*) FROM `$t`")===3,$r);
$wpdb->query("UPDATE `$s` SET chosen=0 WHERE id=3");$r=ability('db/execute',['sql'=>$sql]);$token=$r['confirm_token']??'';$r=ability('db/execute',['sql'=>$sql,'confirm_token'=>$token]);check('F23 IN frozen composite delete',!empty($r['success'])&&!empty($r['applied'])&&($r['affected_rows']??-1)===2&&(int)$wpdb->get_var("SELECT COUNT(*) FROM `$t`")===1,$r);
$policy=Persistence::get('connections','integration:user:1');$policy['profile']='custom';$policy['abilities']=['db/execute'];$policy['database_write']=true;Persistence::put('connections','integration:user:1',$policy);
$sql="UPDATE `$t` t INNER JOIN `{$wpdb->users}` u ON t.id=u.ID SET t.val='bad' WHERE u.ID=1";$r=ability('db/execute',['sql'=>$sql]);check('F23 protected source rejected before preview',($r['error_code']??'')==='sql_selection_unsupported',$r);
$wpdb->query("DROP TABLE `$t`, `$s`");unlink($path);rmdir($dir);
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'database'=>$wpdb->db_version(),'tests'=>count($tests),'failures'=>$failures,'results'=>$tests];file_put_contents(dirname(__DIR__,2).'/evidencias/advanced-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";exit($failures?1:0);
