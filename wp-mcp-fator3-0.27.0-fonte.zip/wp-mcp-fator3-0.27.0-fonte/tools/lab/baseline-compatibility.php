<?php
/** Companion adoption is inert when installed before the new policy server. */
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';
wp_set_current_user(1);$enabled=get_option('f3_mcp_google_enabled',false);update_option('f3_mcp_google_enabled',true);$counts=['core'=>0,'google'=>0];$violations=[];
foreach(wp_get_abilities()as $a){$n=$a->get_name();if(str_starts_with($n,'f3base/'))$counts['core']++;if(preg_match('~^(ga|ads|google|gsc|siteverification)/~',$n))$counts['google']++;}
foreach(['google/status','f3base/config-core-ler']as $name){$a=wp_get_ability($name);$r=$a?$a->execute([]):new WP_Error('missing');if(is_wp_error($r)||($r['success']??$r['ok']??true)===false)$violations[]=$name;}
$out=['php'=>PHP_VERSION,'wordpress'=>$GLOBALS['wp_version'],'mcp'=>F3_MCP_FILES_VERSION,'core'=>F3BASE_PLUGIN_VERSAO,'google'=>F3_MCP_GOOGLE_VERSION,'counts'=>$counts,'failures'=>$violations,'passed'=>F3_MCP_FILES_VERSION==='0.12.1'&&F3BASE_PLUGIN_VERSAO==='1.17.1'&&F3_MCP_GOOGLE_VERSION==='0.4.1'&&$counts===['core'=>63,'google'=>132]&&!$violations,'scope'=>'New companion packages on unmodified 0.12.1 server, in an isolated fresh lab; native reads, no external Google requests.'];
update_option('f3_mcp_google_enabled',$enabled);
file_put_contents(dirname(__DIR__,2).'/evidencias/baseline-compatibility-0130.json',wp_json_encode($out,JSON_PRETTY_PRINT));echo wp_json_encode($out,JSON_PRETTY_PRINT)."\n";exit($out['passed']?0:1);
