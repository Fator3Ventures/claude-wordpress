<?php
require getenv('F3_WP_ROOT')?:'/workspace/scratch/d7106ddbcd96/implementacao-0130/lab/wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/plugin.php';wp_set_current_user(1);
foreach(['base-site-core-fator3/base-site-core-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php'] as $plugin){$r=activate_plugin($plugin,'',false,true);if(is_wp_error($r)){echo json_encode(['plugin'=>$plugin,'activation_failed'=>$r->get_error_code()]);exit(1);}}
echo "Synthetic companion activation completed.\n";
