<?php
/** Synthetic process barrier after a real post write; never shipped in the plugin. */
require getenv('F3_WP_ROOT');
wp_set_current_user(1);
$fixture = json_decode(file_get_contents($argv[1]), true, 512, JSON_THROW_ON_ERROR);
add_action('wp_after_insert_post', static function ($id) use ($fixture) {
    if ((int) $id !== (int) $fixture['post_id']) return;
    file_put_contents($fixture['ready'], 'written');
    $deadline = microtime(true) + 15;
    while (!is_file($fixture['release'])) {
        if (microtime(true) > $deadline) throw new RuntimeException('Synthetic barrier timeout.');
        usleep(1000);
    }
    if (!empty($fixture['uncertain'])) throw new RuntimeException('Synthetic exception after effect.');
}, 10, 1);
$result = wp_get_ability('operations/apply')->execute(['plan_id' => $fixture['plan_id']]);
echo wp_json_encode($result, JSON_UNESCAPED_UNICODE);

