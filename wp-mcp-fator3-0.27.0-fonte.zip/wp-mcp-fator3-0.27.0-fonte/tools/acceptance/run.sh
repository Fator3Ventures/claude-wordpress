#!/bin/sh
set -eu
cd "$(dirname "$0")"
docker compose --env-file .env -f compose.yaml up --build --wait
mkdir -p ../../evidencias/apache
collect_evidence() {
  result=$?
  trap - EXIT
  docker compose --env-file .env -f compose.yaml cp wordpress:/work/evidencias/. ../../evidencias/apache/ || result=1
  exit "$result"
}
trap collect_evidence EXIT
docker compose --env-file .env -f compose.yaml exec -T wordpress apache2 -v > ../../evidencias/apache/apache-version.txt
docker compose --env-file .env -f compose.yaml images --format json > ../../evidencias/apache/images.json
docker compose --env-file .env -f compose.yaml exec -T --user www-data wordpress python3 /work/tools/acceptance/suite.py
