#!/bin/sh
set -eu
php /work/tools/acceptance/install.php
chown -R www-data:www-data /var/www/html/wp-content /var/www/html/wp-config.php
exec docker-php-entrypoint "$@"
