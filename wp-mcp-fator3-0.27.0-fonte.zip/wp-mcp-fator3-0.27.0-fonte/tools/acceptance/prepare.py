"""Create only local synthetic lab credentials. Never add the generated env to a release."""
import os,secrets
from pathlib import Path
p=Path(__file__).with_name('.env')
fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:
 for name in ['F3_LAB_DB_PASSWORD','F3_LAB_ROOT_PASSWORD','F3_LAB_ADMIN_PASSWORD']:
  f.write(name+'='+secrets.token_hex(32)+'\n')
print('Synthetic credentials prepared; values are not displayed.')
