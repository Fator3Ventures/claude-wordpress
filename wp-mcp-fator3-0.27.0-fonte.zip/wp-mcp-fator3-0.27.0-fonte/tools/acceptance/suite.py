#!/usr/bin/env python3
"""Record every acceptance command, including failures, and emit CI evidence."""
from pathlib import Path
import hashlib
import os
import json
import subprocess
import sys
import time

root = Path('/work')
plugin = Path('/var/www/html/wp-content/plugins/wp-mcp-fator3')
digest = hashlib.sha256()
for path in sorted(plugin.rglob('*')):
    if path.is_file():
        digest.update(path.relative_to(plugin).as_posix().encode() + b'\0' + hashlib.sha256(path.read_bytes()).digest())
invocation = {'source_tree_sha256': digest.hexdigest(), 'transport': 'Apache mod_php for HTTP loopback; CLI orchestrates fixtures', 'started_at': int(time.time()), 'suites': []}
suites = 'sql-tests sql-failure-tests concurrency-tests recovery-tests http-tests oauth-http recovery recovery-storage crash'.split()
destination = root / 'evidencias/apache-invocation.json'
try:
    for name in suites:
        path = root / 'tools/release015' / (name + '.php')
        extra = ['-d', 'opcache.enable_cli=1', '-d', 'opcache.validate_timestamps=0', '-d', 'opcache.file_update_protection=0'] if name == 'opcache-recovery' else []
        env = os.environ.copy(); env['F3_TEST_ENGINE'] = str(plugin / 'includes/RecoveryEngine.php')
        result = subprocess.run(['php', *extra, str(path)], cwd=root, env=env)
        invocation['suites'].append({'file': str(path.relative_to(root)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'exit_code': result.returncode})
        destination.write_text(json.dumps(invocation, indent=2) + '\n')
        if result.returncode:
            sys.exit(result.returncode)
finally:
    if destination.is_file():
        subprocess.run(['python3', str(root / 'tools/lab/junit.py'), '--invocation', str(destination), '--out', str(root / 'evidencias/apache-junit.xml')], check=False)
