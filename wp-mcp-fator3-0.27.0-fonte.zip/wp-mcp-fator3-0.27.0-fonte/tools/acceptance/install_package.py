"""Install the exact stable installer, never the development tree."""
from pathlib import Path
import hashlib,json,zipfile
root=Path('/work');report=json.loads((root/'evidencias/package.json').read_text())
p=report['installer'];archive=root/p['file']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==p['sha256']
with zipfile.ZipFile(archive) as z:
 assert not z.testzip()
 assert all(n.startswith('wp-mcp-fator3/') and '..' not in Path(n).parts for n in z.namelist())
 z.extractall('/var/www/html/wp-content/plugins')
