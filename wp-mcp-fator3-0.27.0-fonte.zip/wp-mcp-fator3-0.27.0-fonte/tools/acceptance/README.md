# Reproduzir as suítes da 0.15.0

A evidência executada desta release está em `evidencias/` e no relatório-base. Foi usada a stack WordPress 7.1.2, PHP 8.3.30, MySQL 8.0.46 e Apache 2.4.58 com quatro workers PHP-FPM/OPcache; o cliente real também atualizou o Site-Teste. Não confundir a stack executada com a receita Docker opcional abaixo, que usa mod_php e não foi executada nesta entrega.

## Docker opcional

Requer Docker Engine/Compose. Na raiz do fonte, rode `python3 tools/acceptance/prepare.py` uma vez e depois `tools/acceptance/run.sh`. O script prepara apenas credenciais sintéticas. A receita instala o ZIP gerado, testa SQL/concorrência/recuperação/HTTP/OAuth e salva JSON/JUnit, sem conectar à frota. Prefixo sintético `wp_`; banco descartável `f3_lab`. Não publique a porta além de loopback nem inclua o arquivo de credenciais em pacotes.

O banco MySQL 8.0.46 e PHP 8.3.30 são fixados; o ZIP WordPress 7.1.2 é conferido por SHA-256. A versão resolvida do Apache fica na evidência do operador. Use `docker compose --env-file tools/acceptance/.env -f tools/acceptance/compose.yaml down` para parar. Excluir o volume apaga apenas o laboratório, mas é decisão explícita do operador.

## Integração com os complementos

As suítes `tools/release015/server-tests.php` e `fixture-sdk-tests.php` exigem cópias separadas de Core 1.19.0, Google 0.6.0 e Elementor 4.3.3 nos slugs usuais. Esses fontes não integram esta entrega. Os hashes dos anexos usados estão em `docs/ENTRADAS-TESTE.json`. Ative-os com `integration-setup.php`, teste as duas ordens de carga e `F3_ELEMENTOR_ENABLED=absent|0|1`; defina `F3_VARIANT` para preservar cada JSON. O filtro genérico deliberadamente desligado e o diagnóstico antecipado estão na fixture descrita em `tools/release015/README.md`.

## Atualização e falhas

`upgrade-http.php` exige WordPress local descartável inicialmente na 0.14.0, o instalador final no diretório do projeto e um ZIP de falha sintético. Exercita a troca HTTP por senha de aplicação, tokens OAuth emitidos antes da troca, rotação/revogação, as duas URLs, OPcache e reversão de pacote com fatal. O relatório registra o hash efetivamente executado. Não rode a fixture de erro no site de trabalho.

`sql-failure-tests.php` força timeout/deadlock reais no MySQL e ENOSPC do kernel por `/dev/full`, redirecionado apenas pelo processo de teste. `crash.php` encerra um processo auxiliar com SIGKILL em três barreiras de troca e verifica retomada. Isso não equivale a encher um filesystem montado inteiro. `tools/lab/` contém suítes herdadas: seus IDs/expectativas anteriores são históricos, não resultados da 0.15.
