"""Pin public third-party inputs and generate local package fixtures. No credentials."""
import hashlib,urllib.request,zipfile,io
from pathlib import Path
packages=[('wordpress-seo.28.5.zip','da297cf7f0a9fdb4c7a605e1d8896552fc97360f6b0f55eaa318fe8f8a1b829c'),('elementor.4.3.0.zip','3617ade04fc0b236756159399c56e4cc91c463daaedb3318b7cf5c7207cefa90')]
root=Path('/var/www/html/wp-content/plugins')
for name,digest in packages:
 with urllib.request.urlopen('https://downloads.wordpress.org/plugin/'+name,timeout=60) as r:data=r.read(33554433)
 if len(data)>33554432 or hashlib.sha256(data).hexdigest()!=digest:raise RuntimeError('Third-party fixture digest mismatch: '+name)
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  for entry in z.infolist():
   path=Path(entry.filename)
   if path.is_absolute() or '..' in path.parts:raise RuntimeError('Fixture path invalid')
  z.extractall(root)

# Complete self-update copies; headers are synthetic, never distributed.
import re
source=Path('/var/www/html/wp-content/plugins/wp-mcp-fator3');lab=Path('/lab');lab.mkdir(exist_ok=True)
for version,fatal in [('0.14.0-lab1',False),('0.14.0-lab2',True)]:
 with zipfile.ZipFile(lab/('self-'+version+'.zip'),'w',zipfile.ZIP_DEFLATED)as z:
  for path in sorted(source.rglob('*')):
   if not path.is_file():continue
   relative=path.relative_to(source).as_posix();data=path.read_bytes()
   if relative=='wp-mcp-fator3.php':
    data=re.sub(rb'(Version:\s+)[^\s]+',lambda m:m[1]+version.encode(),data,count=1)
    data=re.sub(rb"('F3_MCP_FILES_VERSION', ')[^']+",lambda m:m[1]+version.encode(),data,count=1)
    if fatal:data+=b'\n'+bytes([92])+b'f3_synthetic_missing_function_for_recovery();\n'
   z.writestr('wp-mcp-fator3/'+relative,data)
