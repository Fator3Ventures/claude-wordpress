<?php
if(PHP_VERSION!=='8.3.30')throw new RuntimeException('Unexpected PHP version.');
$root='/var/www/html';
if(!is_file($root.'/wp-config.php')){
    $values=['DB_HOST'=>'db','DB_NAME'=>'f3_lab','DB_USER'=>'f3_lab','DB_PASSWORD'=>getenv('F3_LAB_DB_PASSWORD'),'DB_CHARSET'=>'utf8mb4','DB_COLLATE'=>'','WP_HOME'=>'http://127.0.0.1:18093','WP_SITEURL'=>'http://127.0.0.1:18093','WP_DEBUG'=>true,'WP_DEBUG_LOG'=>true,'WP_DEBUG_DISPLAY'=>false,'DISABLE_WP_CRON'=>true,'FS_METHOD'=>'direct','WP_ENVIRONMENT_TYPE'=>'local'];
    foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $key)$values[$key]=bin2hex(random_bytes(32));
    $config="<?php\n";foreach($values as $key=>$value)$config.='define('.var_export($key,true).','.var_export($value,true).");\n";
    $config.="\$table_prefix='wp_';define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';";file_put_contents($root.'/wp-config.php',$config);chmod($root.'/wp-config.php',0600);
}
define('WP_INSTALLING',true);require $root.'/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';
if($GLOBALS['wp_version']!=='7.1.2'||!str_starts_with($wpdb->db_version(),'8.0.'))throw new RuntimeException('Unexpected lab stack.');
if(!is_blog_installed())wp_install('Fator3 acceptance lab','f3_lab_admin','lab@example.invalid',false,'',getenv('F3_LAB_ADMIN_PASSWORD'));
update_option('active_plugins',['wp-mcp-fator3/wp-mcp-fator3.php']);
$zip=new ZipArchive();foreach(['1'=>'0.1.0','2'=>'0.2.0','fatal'=>'0.3.0'] as $name=>$version){$zip->open('/lab/fixtures/package-'.$name.'.zip',ZipArchive::CREATE|ZipArchive::OVERWRITE);$zip->addFromString('f3-synthetic-package/f3-synthetic-package.php',"<?php\n/* Plugin Name: F3 Synthetic Package\nVersion: $version\n*/\n".($name==='fatal'?'f3_intentional_fixture_fatal();':''));$zip->close();}
wp_mkdir_p(ABSPATH.'wp-content/mu-plugins');
file_put_contents(ABSPATH.'wp-content/mu-plugins/f3-yoast-lab-indexing.php',"<?php add_filter('Yoast\\\\WP\\\\SEO\\\\should_index_indexables', '__return_true');\n");
echo "Synthetic lab initialized.\n";
