#!/usr/bin/env python3
"""Check actual schemas against operation examples and compatibility statements."""
from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
contract=json.loads((root/'docs/CONTRATOS-INSTALADOS.json').read_text())
a=contract['abilities'];checks=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)})
manual=(root/'docs/OPERACAO.md').read_text()
for match in re.finditer(r'```json\n(.*?)\n```',manual+'\n'+(root/'docs/ATUALIZACAO.md').read_text(),re.S):
 example=json.loads(match[1])
 if not isinstance(example,dict) or 'ability_name' not in example:continue
 name=example['ability_name'];params=example['parameters'];schema=a.get(name,{}).get('input_schema',{})
 check('Manual example parameters exist: '+name,name in a and set(params)<=set(schema.get('properties',{})) and set(schema.get('required',[]))<=set(params))
for name in ['plugins/upload','plugins/upload-base64']:
 p=a[name]['input_schema']['properties']
 check(name+' defaults remain false',p['activate'].get('default') is False and p['overwrite'].get('default') is False)
for name,pairs in {'content/update-page':[('parent','parent_id')],'plugins/list':[('fields','campos'),('prefixes','prefixo')],'files/write':[('label','rotulo')],'db/schema':[('exact','contar')]}.items():
 p=a[name]['input_schema']['properties']
 for first,second in pairs:check(name+' alias '+second,first in p and second in p and p[first]['type']==p[second]['type'])
for name,fields in {'files/read':['offset_bytes','cursor','compression','grep','tail_lines'],'content/patch-page':['expected_revision','limit','all'],'system/maintenance':['max_total_bytes','expected_selection_sha256'],'system/guide':['topic','ability']}.items():
 check(name+' documented contract',set(fields)<=set(a[name]['input_schema']['properties']))
check('Plan excludes SQL mutation','db/execute' not in a['operations/plan']['input_schema']['properties']['steps']['items']['properties']['ability']['enum'])
check('Manual has no future-release placeholders',not re.search(r'previst[oa].*0\.12\.2|ser[aá] implementad[oa]',manual,re.I))
check('Canonical manual equals source',manual==(root/'fontes/wp-mcp-fator3/docs/OPERACAO.md').read_text())
embedded=(root/'fontes/wp-mcp-fator3/includes/guide-content.php').read_text()
check('Protected guide generated from canonical manual',"if (!defined('ABSPATH')) { exit; }" in embedded and manual in embedded)
check('Current package contract',contract['package_header_version']=='0.23.0' and contract['implementation_target']=='0.23.0')
for name in ['db/query-export','db/export','db/restore','db/search-replace','db/batch','connections/list','connections/update','connections/revoke','system/settings','system/settings-update','cron/list','cron/run','themes/upload','themes/activate','themes/update','themes/delete','themes/rollback','files/archive','files/extract']:
 check('Current contract present: '+name,name in a)
check('SQL restoration conflict option','allow_changed_destination' in a['db/restore']['input_schema']['properties'])
check('Search replace column selection','columns' in a['db/search-replace']['input_schema']['properties'])
check('Single release scope',json.loads((root/'docs/RELEASE-SPEC.json').read_text())['ids']==['MCP-0230'])
for name in ['db/execute','db/batch','db/search-replace']:
 check(name+' guard output','guard_contract' in a[name]['output_schema']['properties'] and 'conflict_reason' in a[name]['output_schema']['properties'])
check('SQL guard canonical contract','selection-guard/2' in (root/'docs/SQL-GUARD.md').read_text())
check('SDK canonical contract','server-integration/1.0.0' in (root/'docs/SERVER-INTEGRATION.md').read_text())
check('Supported inputs',json.loads((root/'docs/RELEASE-SPEC.json').read_text())['inputs']==['clean','0.22.0'])
for name in ['roles/delete','roles/restore']:check('Role contract: '+name,name in a)
check('SQL categories',a['backups/list']['input_schema']['properties']['category']['enum']==['backups','sql_mutation','sql_artifacts'])
check('Optional scope preserves old tokens','default' not in a['db/execute']['input_schema']['properties']['backup_scope'])
check('Retention settings','sql_retention' in a['system/settings-update']['input_schema']['properties'])
check('Local companion matrix',json.loads((root/'docs/RELEASE-SPEC.json').read_text())['companions']=={'base-site-core':'1.33.0','wp-mcp-google-fator3':'0.10.0','wp-mcp-meta-fator3':'0.2.0','wp-mcp-linkedin-fator3':'0.2.0'})
header=(root/'fontes/wp-mcp-fator3/wp-mcp-fator3.php').read_text()
uri=re.search(r'^ \* Update URI:\s+(\S+)',header,re.M)[1]
check('Update URI docs match real header',uri in manual and uri in (root/'docs/ATUALIZACAO.md').read_text() and 'Update URI: false' not in manual)
check('Probe test context documented',a['system/probe']['input_schema']['properties']['contexto_teste']['type']=='boolean' and 'traffic_class_scope' in manual)
check('Baseline is not a runtime version gate',json.loads((root/'docs/RELEASE-SPEC.json').read_text())['inputs_are_test_baselines_not_runtime_gate'] is True and 'sem trava por versão de origem' in manual)
check('Removed migration runtime absent',not (root/'fontes/wp-mcp-fator3/includes/Upgrade016.php').exists() and not (root/'fontes/wp-mcp-fator3/includes/Upgrade015.php').exists())
for ref in json.loads((root/'docs/RELEASE-SPEC.json').read_text())['canonical'].values():check('Canonical specification exists: '+ref,(root/'docs'/ref).is_file())
transport=(root/'fontes/wp-mcp-fator3/core/includes/Server/Transport/HttpTransport.php').read_text()
check('Auth diagnostic codes match documentation','mcp_permission_denied' in manual and 'mcp_permission_denied' in transport and 'mcp_authentication_required' in manual and 'mcp_authentication_required' in transport)
check('Canonical probe contract included in guide',(root/'docs/PROBE-AUDIT.md').read_text().split('\n',1)[1] in manual)
for name in ['plugins/upload','plugins/upload-base64','plugins/update','plugins/reconcile']:
 p=a[name]['input_schema']['properties']['probe_timeout_seconds'];check(name+' package timeout 1 to 30',p['minimum']==1 and p['maximum']==30)
check('Package pending is nullable','null' in a['plugins/upload']['output_schema']['properties']['applied']['type'])
check('Status read-only and reconcile mutation',a['plugins/operation-status']['meta']['annotations']['readonly'] is True and a['plugins/reconcile']['meta']['annotations']['readonly'] is False)
check('Package journal distinct from executor','package_operation_id' in a['plugins/upload']['output_schema']['properties'] and 'package_operation_id' in manual)
out={'scope':'schema/example/alias/document coherence; not full editorial acceptance','checks':checks,'tests':len(checks),'failures':sum(not c['passed'] for c in checks)}
(root/'evidencias/0230/documentation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'}));print([c for c in checks if not c['passed']])
raise SystemExit(bool(out['failures']))
