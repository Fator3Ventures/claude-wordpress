# server-integration/1.0.0 — contrato corrente

Contrato canônico L01/L02/I04/I05. Provedor `wp-mcp-fator3`; política de extensão continua `policy_contract:1`.

Identidade constante: `server_id:wp-mcp-ultimate-server`, `route:/mcp/wp-mcp-fator3`, `aliases:[/mcp/wp-mcp-ultimate]`. Slug, Text Domain, Update URI e nomes dos metatools permanecem.

Filtros públicos: `f3_mcp_create_default_server(bool $enabled, array $identity)` e `f3_mcp_default_server_config(array $config, array $identity)`. O primeiro usa true como default e compartilha a decisão entre categoria, habilidades, fábrica e diagnóstico. O kill-switch continua controlando autorização, independentemente do registro do servidor.

O segundo aceita contribuições em `tools`, `resources`, `prompts`; preserva defaults e os três metatools. Nomes novos precisam existir, estar públicos, ter tipo correto e pertencer a provedor aderente. Retornos inválidos preservam defaults e registram códigos sanitizados. ID, endpoints, autenticação e handlers não podem ser substituídos. Contribuições repetidas são deduplicadas. Este SDK é cooperação entre plugins PHP; não é isolamento contra PHP malicioso.

`Fator3\McpFiles\ServerContract::capabilities()` informa contrato, versão, identidade e disponibilidade do hook. `::status()` é observação local, sem HTTP ou montagem recursiva: `core_loaded`, `server_enabled`, `channel_enabled`, `registry_checked`, `server_registered`, `tools_ready`, `endpoints`, `errors`. Antes de registro, desconhecidos são null; URLs também são null até o WordPress inicializar WP_Rewrite. `external_connectivity_tested:false` distingue isso de conectividade externa comprovada. A fachada não devolve credenciais ou identidades de conexões.

Filtros `mcp_adapter_*` não controlam o núcleo embutido. O ciclo é `f3_mcp_adapter_init`. O mapa completo está em `server-hook-map.json` no fonte; os demais hooks são internos, sem estabilidade de SDK prometida. Hooks da Abilities API e `f3_mcp_register_providers` continuam compartilhados. O Fator3 não altera `elementor_mcp_enabled`, não desliga o servidor Elementor e continua descobrindo seus recursos públicos com URI em `meta.mcp.uri`.

Google 0.8.5 conserva `google/mcp-read` e `google/mcp-write` por um adaptador do MCP que verifica os metadados públicos e o provedor. Não chama APIs privadas Google. A contribuição Google ao filtro próprio é deduplicada. O executor opcional de leitura do canal também é preservado.

Somente uma chamada direta de ferramenta registrada no servidor Fator3, autenticada por OAuth/senha de aplicação, estabelece contexto interno de entrada. Bridges admitidas pelo ExecutorRegistry têm admissão nesse contexto, verificando perfil e permissão nativa. Leitura não admite a bridge de escrita; Personalizado precisa permitir a bridge e o alvo final. O Google conserva seus gates e confirmações. Qualquer executor usado como alvo retorna `ability_executor_forbidden`, incluindo bridges Google e `mcp-adapter/execute-ability`. Parâmetros do cliente e outra porta MCP não fabricam esse contexto.

A integração PHP Core → Google permanece fora do transporte MCP. Não recebe perfil sintético, não depende de sessão MCP, nem ganha bypass pelo nome do provedor. O catálogo reflete as abilities realmente registradas pelo complemento instalado.

Parâmetros nativos dos provedores são preservados: por exemplo, `label` de `google/create-connection` chega ao callback Google. Normalização dos aliases do canal e remoção de seu rótulo de auditoria aplicam-se somente às habilidades próprias do MCP. A coordenação não reinterpreta campos de negócio dos complementos.

## Compatibilidade e ciclo do servidor

A 0.22.0 atende WordPress limpo e MCP 0.21.0, sem trava por versão de origem ou dos companheiros. Core 1.33.0 e Google 0.8.5 são a matriz de validação. Políticas explícitas e dados atuais permanecem; importadores históricos foram retirados.

A primeira entrada REST/CLI conclui o registro público de habilidades após init e antes de compor tools, resources e prompts. Chamadas reentrantes durante registro/configuração não publicam um servidor parcial. ServerContract::status continua observacional. O Google 0.8.5 usa o ciclo público e não precisa aquecer o registro antecipadamente. Um erro de criação é diagnosticado e não marca a inicialização como concluída.


## Google 0.8.5 entregue

Configuração 4.0.0 recebe `services` como mapa: `{"gtm":"write"}`. `merge:true` preserva serviços omitidos; sem merge há substituição. Omitir services preserva a seleção; mapa vazio propõe remoção; null é inválido. `dry_run:true` permanece escrita para autorização, retorna a revisão e hash sem aplicar.

Redução exige `confirm_service_reduction`, `expected_revision` e `expected_plan_hash` explícitos da prévia. O MCP não completa, traduz ou substitui esses campos. Conflito exige nova prévia. Não há redirecionamento para `google/prepare-operation`, destinado às confirmações remotas.

`not_applied`, `persisted:false`, `changed:false`, parcial, desconhecido, contagens null, cobertura e diagnósticos permanecem estruturados. `checks.executor`, erros ativos, incidentes históricos, health e work_health são evidências distintas. Consulta não repara agenda. Cada provedor mantém seus tokens, cotas, jobs e recuperação.

SDK Core → Google conserva `search-console-reader/1.0.0`, consumidor `base-site-core-fator3`, grant explícito e conexão efetiva, inclusive não padrão. `query` e `effective_status` devem ser chamáveis. A consulta não fabrica usuário humano nem passagem cron.

## Core 1.33.0 entregue

Contrato 7.0.0. `f3base/config-procedencia-reparar` foi retirado pelo Core e não recebe alias MCP. As rotas `f3base/anuncios-linkedin-acesso-verificar`, `f3base/anuncios-linkedin-consultar` e `f3base/anuncios-linkedin-webhook-configurar` são escrita, inclusive com `simular:true`. Personalizado exige concessão explícita; grants antigos não são ampliados.

O schema de webhook conserva `acao`, `simular`, `revisao` e `chave_operacao`. A decoração MCP `idempotency_key` é independente da chave nativa: não preenche revisão, consentimento ou chave do Core. O webhook público `/wp-json/f3base/v1/anuncios/linkedin/notificacoes` usa desafio HTTPS, HMAC e processamento assíncrono próprios; não ganha autenticação MCP.

O transporte preserva `codigo`, `motivo` e `diagnostico` editorial, incluindo fonte, linhas, limite_linhas, memoria_estimada_bytes, memoria_disponivel_bytes, periodo e visao. `limite_linhas_editorial`, `orcamento_memoria_editorial` e `consulta_sql_falhou` não viram sucesso ou zero, nem autorizam repetição/redução automática do período.

Avisos JSON Core podem emitir `f3base.operacao.v1`, tipo `pipedrive_orcamento`, sob HMAC próprio. Consumidores distinguem eventos operacionais de leads; o MCP não altera receptores externos.


## Contratos adicionais 0.22.0

Consulte EXECUTOR-REGISTRATION.md, PACKAGE-DISTRIBUTION.md, OAUTH-CIMD.md e CORE-MEASUREMENT.md. A admissão e a inclusão de bridges usam exclusivamente o registro genérico. A adaptação delimitada Google 0.8.5 gera descritores com seus seis prefixos registrados; uma declaração explícita inválida não aciona fallback.
