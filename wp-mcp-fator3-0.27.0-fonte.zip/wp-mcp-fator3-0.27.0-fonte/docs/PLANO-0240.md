# Plano MCP 0.24.0 — Pedido MCP 61
Revisão 1 · 17/10/2026 · Implementação solicitada.
Base imutável 0.23.0: instalador SHA-256 6a64708f5737eb08c6f726dd5941b28d36a28ecbb45f79f32d2c96d00030a4ab. Alvo 0.24.0; instalador ainda não gerado no planejamento.
Diretrizes lidas integralmente: instruções e padrão, revisão 4, de 16/10/2026. Cópias revisão 3 são superadas.

1. Adicionar somente cache_bypass_verified booleano à projeção SafeOutput, recursivamente em amostras/totais e sondas antes/depois, preservando false e sem coerção de tipos.
2. Provar falha na base, sucesso na candidata e proteção de valores não booleanos/segredos; DataSafety de SQL/options não muda.
3. Validar instalação limpa e atualização direta 0.23.0, leitura documental e sondas pelo MCP HTTP com o pacote final.
4. Conferir estado compartilhado, instalar apenas MCP no Site-Teste, guardar pré-imagem e verificar em novas requisições. Instalação direta de homologação por bytes/hash não é publicação raw da frota.
5. Entregar instalador, fonte, relatório, identidade e limites.

## Fronteiras avaliadas antes da implementação
Core 1.35.0 e Google 0.11.0 recebidos; Meta/LinkedIn 0.2.0 da base. A correção é da apresentação das sondas de manutenção WordPress: não altera APIs, configuração, permissões ou dados desses plugins; não exige adaptação. Sem impacto técnico de desenvolvimento identificado nesses destinatários, não emitir avisos de versão. O pedido 61 já documenta a consequência para a frota, tratada no relatório operacional. Implantador atual não fornecido: não avaliado; nenhuma dependência nova. Nenhum conflito condiciona a alteração.
Impacto Google 0.11.0 → MCP, revisão 2: resolvido pelo mantenedor no escopo testado; recebido e preservado, sem nova ação de desenvolvimento. Evidência recebida não é ensaio próprio.

## Aceites
- Booleanos true/false conservados nas amostras e totais de probe_before/probe_after.
- Tipos string/int/null/array/object sob esse nome e segredos adjacentes continuam redigidos.
- Respostas de sucesso/erro, textual/estruturada, preservam o tipo; idempotência da projeção.
- WordPress novo com MCP isolado, atualização direta, versão em processo novo e dados preservados.
- Documentação instalada descobrível, paginada e íntegra, negativa de acesso e hash obsoleto.
- Site-Teste: upload com sondas booleanas; registrar rota real, sem equiparar base64 a prova de distribuição raw.
- Pacote/fonte correspondentes, sem segredos, testes ou ZIPs aninhados no instalador.
