# Validação 0.22.0

Candidata implementada; validação efetiva com ChatGPT (B22) pendente. Testes locais usam WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46 e lighttpd/PHP-FPM com quatro workers e OPcache sem validação de timestamps. Não houve implantação nos sites.

O ponto de partida instalado é MCP 0.21.0 + Core 1.31.0 + Google 0.8.5. Foram executadas atualizações nativas por HTTP autenticado nas duas ordens MCP/Core, diretamente para 0.22.0/1.33.0. MCP 0.21.1 e Core 1.32.0 não foram instalados. Seus intermediários não são pré-requisitos. As versões dos companheiros são matriz de ensaio, nunca bloqueio de instalação.

Os testes da candidata ficam em `tools/release0220/` e as evidências em `evidencias/0220/`. O relatório final mapeia B01–B35, C01–C06 e M01–M08 com os limites efetivos. Registros de releases anteriores permanecem históricos e não entram na contagem da candidata.

A negociação do documento ChatGPT foi validada com a captura de 15/10/2026. O percurso OAuth local usa HTTP real, consentimento WordPress e cookie sintético válido; a busca CIMD externa é simulada, mantendo o conteúdo capturado e substituindo somente a identidade pelo endpoint controlado. Isso não equivale a uma conexão real do ChatGPT. DCR e refresh têm evidências próprias, incluindo credenciais geradas na base 0.21.0 e preservadas após a atualização.

Google 0.8.5 e Core 1.33.0 foram executados como pacotes reais. Os testes Google mantêm serviços externos simulados. Meta, LinkedIn e a declaração consumidora Google 0.8.6 usam fixtures do contrato; não certificam produtos ou contas reais. Google 0.8.6, plugins sociais, tráfego externo real, multisite, cache persistente Redis/Memcached e observação prolongada não foram homologados.
