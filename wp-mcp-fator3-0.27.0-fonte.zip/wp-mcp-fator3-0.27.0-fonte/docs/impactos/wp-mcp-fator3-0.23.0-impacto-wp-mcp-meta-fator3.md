# Impacto — Fator3 MCP 0.23.0 → wp-mcp-meta-fator3

Revisão 1 · 16/10/2026 · Emissor: wp-mcp-fator3 0.23.0 · Destinatário examinado: 0.2.0
Classificação: **informativo** · Pedidos: Pedidos MCP 60; MCP-221-09; S01/S04

## Contrato e evidência própria

Schema nativo maxLength 64, padrão e required preservados. Jobs e exportações via HTTP produziram recibos iguais no replay e recusaram ativos revogados, com API simulada. No Site-Teste, conexão inexistente retorna not_configured em lugar de falha pela retirada da chave.

Instalador: `wp-mcp-fator3-0.23.0-instalador.zip`, 818313 bytes, SHA-256 `6a64708f5737eb08c6f726dd5941b28d36a28ecbb45f79f32d2c96d00030a4ab`. Basename preservado: wp-mcp-fator3/wp-mcp-fator3.php. Instalação limpa e atualização direta 0.22.0→0.23.0; sem dependência obrigatória de acompanhantes. server-integration/1.0.0, executor-registration/1.0.0, package-distribution/1.0.0 e policy_contract 1 permanecem.

## Ação e limites

Repetir create-job/export na conta real autorizada: o Site-Teste tem connection_count=0. Falha antiga completa não é expurgada: reconciliar no produtor; nova chave somente após comprovar ausência de efeito. Retenção, Facebook/Instagram e SDK próprios permanecem sob o mantenedor Meta.

Relatórios dos outros mantenedores são evidências recebidas. Somente os ensaios descritos no relatório MCP e em evidencias/0230 são execução própria. O código do destinatário não foi alterado. Nenhum envio ao mantenedor ou publicação foi realizado.

## Operação

O MCP entrega a chave nativa ao callback sem trim ou ampliação do schema. No replay de sucesso novo, o callback recebe a mesma chave para revalidar o domínio; resultado antigo não é usado para contornar grant/seleção. Chave exclusiva do canal continua removida do callback e conserva o cache do MCP. Registros incertos/compactados e falhas antigas permanecem protegidos.

Ajuda instalada: system/guide, com catálogo, páginas por bytes, cursor e SHA-256. Ajuda estática mantém seu gate; configuração/contas continuam administrativas. Consulte `wp-mcp-fator3-0.23.0-relatorio.md` para hashes, testes, reversão e pendências. Este encaminhamento é arquivo próprio preparado para o dono.
