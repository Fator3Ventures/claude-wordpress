# Impacto — Fator3 MCP 0.23.0 → base-site-core-fator3

Revisão 1 · 16/10/2026 · Emissor: wp-mcp-fator3 0.23.0 · Destinatário examinado: 1.33.0; 1.34.0 apenas plano
Classificação: **informativo** · Pedidos: M91-01/N24; M91-02/N25; Core 212/217

## Contrato e evidência própria

O MCP preserva os diagnósticos tipados e mapeia revision_conflict no envelope comum. O Core 1.33.0 real foi comparado por callback, ability e HTTP; revisão válida funciona e vencida mantém code, data:null, conflict:true e retryable:false. Não há mudança no SDK site-measurement-context/1.0.0 nem bridge Core nova.

Instalador: `wp-mcp-fator3-0.23.0-instalador.zip`, 818313 bytes, SHA-256 `6a64708f5737eb08c6f726dd5941b28d36a28ecbb45f79f32d2c96d00030a4ab`. Basename preservado: wp-mcp-fator3/wp-mcp-fator3.php. Instalação limpa e atualização direta 0.22.0→0.23.0; sem dependência obrigatória de acompanhantes. server-integration/1.0.0, executor-registration/1.0.0, package-distribution/1.0.0 e policy_contract 1 permanecem.

## Ação e limites

Repetir N24/N25 com o futuro binário 1.34.0. Pedidos Core 212/217 continuam pertencendo ao Core; os payloads futuros não foram homologados. Não se pede alteração do contrato nativo para acomodar o MCP.

Relatórios dos outros mantenedores são evidências recebidas. Somente os ensaios descritos no relatório MCP e em evidencias/0230 são execução própria. O código do destinatário não foi alterado. Nenhum envio ao mantenedor ou publicação foi realizado.

## Operação

O MCP entrega a chave nativa ao callback sem trim ou ampliação do schema. No replay de sucesso novo, o callback recebe a mesma chave para revalidar o domínio; resultado antigo não é usado para contornar grant/seleção. Chave exclusiva do canal continua removida do callback e conserva o cache do MCP. Registros incertos/compactados e falhas antigas permanecem protegidos.

Ajuda instalada: system/guide, com catálogo, páginas por bytes, cursor e SHA-256. Ajuda estática mantém seu gate; configuração/contas continuam administrativas. Consulte `wp-mcp-fator3-0.23.0-relatorio.md` para hashes, testes, reversão e pendências. Este encaminhamento é arquivo próprio preparado para o dono.
