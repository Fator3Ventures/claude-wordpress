# Impacto — Fator3 MCP 0.23.0 → wp-mcp-google-fator3

Revisão 1 · 16/10/2026 · Emissor: wp-mcp-fator3 0.23.0 · Destinatário examinado: 0.10.0 local; 0.9.0 no Site-Teste
Classificação: **informativo** · Pedidos: M91-01; M91-02; G91-01/03

## Contrato e evidência própria

Preflight real conserva checks_passed:false, all_checks_passed:false, passed:0 e credential.configured:false. Bridges dedicadas read/write executadas, com negativos de perfil, alvo estrangeiro e executor aninhado. Cinco seções reais de resultados paginados foram reconstruídas sem perda; o limite do produtor permanece menor que 2 MiB.

Instalador: `wp-mcp-fator3-0.23.0-instalador.zip`, 818313 bytes, SHA-256 `6a64708f5737eb08c6f726dd5941b28d36a28ecbb45f79f32d2c96d00030a4ab`. Basename preservado: wp-mcp-fator3/wp-mcp-fator3.php. Instalação limpa e atualização direta 0.22.0→0.23.0; sem dependência obrigatória de acompanhantes. server-integration/1.0.0, executor-registration/1.0.0, package-distribution/1.0.0 e policy_contract 1 permanecem.

## Ação e limites

Não renomear indicadores nem desligar sanitização. Google 0.10.0 não foi instalado no Site-Teste nesta rodada; a prova conjunta dessa versão é local. Homologação com fornecedor e credenciais reais continua separada.

Relatórios dos outros mantenedores são evidências recebidas. Somente os ensaios descritos no relatório MCP e em evidencias/0230 são execução própria. O código do destinatário não foi alterado. Nenhum envio ao mantenedor ou publicação foi realizado.

## Operação

O MCP entrega a chave nativa ao callback sem trim ou ampliação do schema. No replay de sucesso novo, o callback recebe a mesma chave para revalidar o domínio; resultado antigo não é usado para contornar grant/seleção. Chave exclusiva do canal continua removida do callback e conserva o cache do MCP. Registros incertos/compactados e falhas antigas permanecem protegidos.

Ajuda instalada: system/guide, com catálogo, páginas por bytes, cursor e SHA-256. Ajuda estática mantém seu gate; configuração/contas continuam administrativas. Consulte `wp-mcp-fator3-0.23.0-relatorio.md` para hashes, testes, reversão e pendências. Este encaminhamento é arquivo próprio preparado para o dono.
