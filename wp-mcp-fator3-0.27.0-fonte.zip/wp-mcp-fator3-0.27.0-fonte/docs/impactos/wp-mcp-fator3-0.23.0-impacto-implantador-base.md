# Impacto — Fator3 MCP 0.23.0 → implantador-base

Revisão 1 · 16/10/2026 · Emissor: wp-mcp-fator3 0.23.0 · Destinatário examinado: binário e versão atual não fornecidos
Classificação: **nao-avaliado** · Pedidos: Distribuição 0.23.0; decisão 89

## Contrato e evidência própria

Slug implantador-base confirmado na documentação do projeto. Não foi executado seu runtime. O MCP foi testado por upload-base64 com hash, slug, pré-imagem, reativação em PHP novo e sonda. Isso não certifica download raw, atualização da frota ou o Implantador.

Instalador: `wp-mcp-fator3-0.23.0-instalador.zip`, 818313 bytes, SHA-256 `6a64708f5737eb08c6f726dd5941b28d36a28ecbb45f79f32d2c96d00030a4ab`. Basename preservado: wp-mcp-fator3/wp-mcp-fator3.php. Instalação limpa e atualização direta 0.22.0→0.23.0; sem dependência obrigatória de acompanhantes. server-integration/1.0.0, executor-registration/1.0.0, package-distribution/1.0.0 e policy_contract 1 permanecem.

## Ação e limites

Publicar somente o instalador após decisão do dono, conferir expected_sha256 e expected_slug=wp-mcp-fator3 e verificar nova requisição. O fonte continua privado. Não reativar o Implantador em sites já implantados como parte desta atualização.

Relatórios dos outros mantenedores são evidências recebidas. Somente os ensaios descritos no relatório MCP e em evidencias/0230 são execução própria. O código do destinatário não foi alterado. Nenhum envio ao mantenedor ou publicação foi realizado.

## Operação

O MCP entrega a chave nativa ao callback sem trim ou ampliação do schema. No replay de sucesso novo, o callback recebe a mesma chave para revalidar o domínio; resultado antigo não é usado para contornar grant/seleção. Chave exclusiva do canal continua removida do callback e conserva o cache do MCP. Registros incertos/compactados e falhas antigas permanecem protegidos.

Ajuda instalada: system/guide, com catálogo, páginas por bytes, cursor e SHA-256. Ajuda estática mantém seu gate; configuração/contas continuam administrativas. Consulte `wp-mcp-fator3-0.23.0-relatorio.md` para hashes, testes, reversão e pendências. Este encaminhamento é arquivo próprio preparado para o dono.
