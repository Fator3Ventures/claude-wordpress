# Impacto — Fator3 MCP 0.23.0 → wp-mcp-linkedin-fator3

Revisão 1 · 16/10/2026 · Emissor: wp-mcp-fator3 0.23.0 · Destinatário examinado: 0.2.0
Classificação: **informativo** · Pedidos: Pedidos MCP 60; MCP-221-09; S01/S04/S06

## Contrato e evidência própria

Chaves nativas preservadas em jobs, exportações e lead-create-subscription. Teste HTTP real do WordPress com fornecedor simulado: um POST, mesmo recibo em replay, revisão pública inteira, recusa de perfil apenas analítico e após revogação do ativo. Nenhuma assinatura real foi criada.

Instalador: `wp-mcp-fator3-0.23.0-instalador.zip`, 818313 bytes, SHA-256 `6a64708f5737eb08c6f726dd5941b28d36a28ecbb45f79f32d2c96d00030a4ab`. Basename preservado: wp-mcp-fator3/wp-mcp-fator3.php. Instalação limpa e atualização direta 0.22.0→0.23.0; sem dependência obrigatória de acompanhantes. server-integration/1.0.0, executor-registration/1.0.0, package-distribution/1.0.0 e policy_contract 1 permanecem.

## Ação e limites

Repetir com fornecedor autorizado e consumidor Core quando disponíveis. Registro não concede acesso; o callback nativo continua responsável por autorização e idempotência de domínio. Contratos Lead Reader 1.0/1.1 do produtor não foram alterados. Estados legados incertos não são reabertos pelo MCP.

Relatórios dos outros mantenedores são evidências recebidas. Somente os ensaios descritos no relatório MCP e em evidencias/0230 são execução própria. O código do destinatário não foi alterado. Nenhum envio ao mantenedor ou publicação foi realizado.

## Operação

O MCP entrega a chave nativa ao callback sem trim ou ampliação do schema. No replay de sucesso novo, o callback recebe a mesma chave para revalidar o domínio; resultado antigo não é usado para contornar grant/seleção. Chave exclusiva do canal continua removida do callback e conserva o cache do MCP. Registros incertos/compactados e falhas antigas permanecem protegidos.

Ajuda instalada: system/guide, com catálogo, páginas por bytes, cursor e SHA-256. Ajuda estática mantém seu gate; configuração/contas continuam administrativas. Consulte `wp-mcp-fator3-0.23.0-relatorio.md` para hashes, testes, reversão e pendências. Este encaminhamento é arquivo próprio preparado para o dono.
