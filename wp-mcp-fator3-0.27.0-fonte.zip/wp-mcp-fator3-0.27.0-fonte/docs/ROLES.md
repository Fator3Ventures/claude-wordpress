## Excluir e restaurar papéis

roles/delete exige role; roles/restore exige role e backup_id. Ambos exigem manage_options, perfil Manutenção e prévia/confirm_token, nunca exclusão imediata por confirm:true. Recusam exclusão de administrator/editor/author/contributor/subscriber, default_role e papéis atribuídos a qualquer usuário, inclusive usuários com múltiplos papéis. Códigos: role_protected, role_is_default, role_in_use, role_not_found e preimage_conflict.

```json
{"ability_name":"roles/delete","parameters":{"role":"papel_personalizado"}}
```

Após revisar a prévia, repita com confirm_token. A confirmação relê uso/default/capacidades, cria backup do alvo e verifica o estado gravado. O recibo informa role, persisted, changed, backup_id e operation_id. Uma confirmação concluída pode ser repetida sem novo efeito.

roles/restore restaura só o papel escolhido, verifica a pós-imagem esperada e faz backup da alteração atual. Restaurar a criação de um papel significa removê-lo, sujeito às mesmas guardas. Exige o contrato de snapshot atual, com papel, pré-imagem e pós-imagem explícitos. Não atribui usuários.

roles/update calcula a alteração dentro do lock. options/update de user_roles aplica as mesmas recusas antes da primeira escrita; use roles/delete/restore para operações pontuais. As rotas de usuários e alteração de default_role compartilham a coordenação. Escritores externos/SQL administrativo não cooperantes continuam fora do lock MCP; persistência incerta exige investigação. Capacidades humanas não reescrevem concessões do consumidor PHP Google.

