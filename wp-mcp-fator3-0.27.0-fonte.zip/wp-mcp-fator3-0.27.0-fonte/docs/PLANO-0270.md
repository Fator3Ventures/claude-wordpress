# Plano — Fator3 MCP 0.27.0

22/10/2026 · implementação · base aceita 0.26.1 (instalador ed8035e6e326ac3c2021bac1ae9c11fde39c26686e1763299b445c3992cb5384). Alvo previsto 0.27.0, instalador ainda não gerado no planejamento.

Pedidos MCP 63: rótulos públicos em português e descrição da chave de idempotência acrescentada pelo transporte; IDs e permissões preservados. Pedido 64: interseção de capacidades declaradas no CIMD, com authorization_code/code obrigatórios quando o campo é informado; diagnóstico administrativo local e MCP. JWT bearer não será anunciado nem emitido.

Base de convivência recebida: Core 1.47.0, LinkedIn 0.6.0, Google 0.17.0 e Meta 0.4.1. Site-Teste confirmou essa combinação com MCP 0.26.1 antes da alteração. Nenhum pacote alheio será editado.

Impacto pertinente: impacto-mcp-0.27.0-para-linkedin.md, revisão 1, criado antes da implementação. Pedido LinkedIn 10 será revalidado com descritor explícito. Para 8(d), propor contrato separado de principal de serviço: a 0.6.0 não emite evento de serviço nem oferece leitor público com comprovação de concessão para esse contrato. Não relaxar o contrato humano 1.0.0 nem ler classes/tabelas privadas para contornar a lacuna. Especificação coordenada, ainda sem runtime de serviço, descrita no impacto.

Verificação prevista: catálogo efetivo/nomes/descrições/perfis; CIMD válido, campos inválidos/ausentes, concessões extras, resposta sem code, preservação de PKCE/audience/redirect e recusa de JWT no endpoint; ring privado e gates/ausência de segredos; WordPress real/HTTP, upgrade direto, limpo isolado/mínimos, painel e documentação completa no Site-Teste. Consentimento e três ferramentas de um conector real do Claude devem ser distinguidos do ensaio do servidor com metadados reais. B22 ChatGPT permanece encerrado historicamente.

## Encerramento da rodada

Implementação 0.27.0 entregue com instalador fcf5ad0099b9490abfb8e9ea6ef83c769cad053e2ee75712efce50e219f62bc1. Provas e pendências no relatório externo. Impacto LinkedIn atualizado à revisão 2: descritor humano revalidado; proposta de serviço ainda aberta. Ver ferramentas/evidências da rodada 0270.
