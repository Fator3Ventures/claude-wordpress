# Manutenção 0.21.1

Bases: WordPress limpo e atualização direta MCP 0.21.0. Core 1.32.0/Google 0.8.4 compõem a matriz; versões, presença e ordem não bloqueiam instalação ou bootstrap. A exigência `requires.plugins` do canal opcional foi retirada; requisitos próprios WordPress/PHP e verificação de origem/hash continuam.

| Área | Alteração | Estado atual preservado |
|---|---|---|
| Inicialização | Sem marcadores/opções para recuperadores anteriores; observação `release-state/current` | Schema 2, sem expurgo de dados |
| Autenticação | Sem importação de opções/transientes, captura 0.14, perfil herdado ou shim antigo | Grants atuais, expiração, rotação/reuso, perfis explícitos e revogação |
| Sessões/auditoria | Sem importação de usermeta, arquivos e option de auditoria | SQL atual, sessões vinculadas à conexão e paginação |
| Estado/idempotência | Sem importador arquivo→SQL nem chave antiga sem conexão | Chave atual, recibos e resultado incerto |
| Backups | Sem leitores JSON/BAK públicos, índice em arquivo ou rotas legacy-status/legacy-retire | Envelope privado, exportação, restauração, tombstone, referências e seleção congelada |
| Inventário SQL | Sem inferir proveniência a partir de recibos antigos | Reconciliação limitada, origem desconhecida protegida |
| Recuperação | Sem importar diários anteriores ao índice ativo | Diário/ponteiro assinados, sentinela, OPcache e pré-imagem |
| Papéis | Sem restauração de mapa completo sem pós-imagem | Snapshot atual por papel, conflito e duas fases |
| Interface | Sem formulários de migração e exceção Legado | Configuração explícita, revogação e controle de revisão |

Nomes de formatos usados na 0.21.0 (`phase014`, `legacy_sessions`, `RecoveryV1`, cursor `backup-retention-018`) continuam para preservar dados e operações correntes. Não são migradores. Tabelas históricas já existentes não são removidas. A identidade SDK `wp-mcp-ultimate-server` e o endereço `/mcp/wp-mcp-ultimate` continuam válidos para conexões atuais.

O catálogo MCP passa de 168 para 166 habilidades pela retirada das duas rotas de acervo anterior; não há habilidade nova. Catálogos dos companheiros são descobertos dinamicamente.

Testes atuais em `tools/release0211`; regressões úteis reutilizam helpers antigos sem exigir instalação anterior à 0.21.0. Documentos e provas anteriores não são recontados. `docs/SERVER-INTEGRATION.md` descreve Google configuração 4.0.0, Core contrato 7.0.0, três rotas LinkedIn e diagnósticos editoriais. Google 0.8.5 final não foi disponibilizado: A13/A14 não executados, sem dependência circular de entrega.

O relatório externo contém resultados, hashes e limites. Não há implantação, limpeza de frota ou chamadas a contas Google/LinkedIn reais.
