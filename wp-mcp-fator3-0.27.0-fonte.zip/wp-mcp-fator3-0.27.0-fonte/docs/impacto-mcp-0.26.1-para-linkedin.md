# Impacto — Fator3 MCP 0.26.1 → Fator3 MCP LinkedIn 0.5.0

- Emissor: responsável pelo wp-mcp-fator3; destinatário: responsável pelo wp-mcp-linkedin-fator3.
- Tipo: validacao-coordenada. Pedido de origem: LinkedIn 6(c), impacto LinkedIn 0.5.0 → MCP.
- Base aceita MCP: 0.25.0. Alvo final: 0.26.1. LinkedIn preservado: 0.5.0.
- Etapa: entrega; revisão 2; situação: integração implementada e validada pelo MCP com transporte LinkedIn sintético. Data: 2026-10-22T12:34:29-03:00.

## Histórico e decisão

Revisão 1 emitida no planejamento em 22/10/2026, antes da implementação dependente, com alvo previsto MCP 0.26.0 e instalador ainda não gerado. A proposta foi receber referências, conservar os snapshots no diário do provedor e consultar apenas leitor público autorizado. Não houve alteração no pacote LinkedIn.

A candidata 0.26.0 foi instalada no Site-Teste. A revisão visual detectou que um mapeamento MCP nativo revogado bloqueava também a consulta pelo administrador no painel. A revisão 2 entrega 0.26.1: a identidade nativa é separada da política de transporte, sem reativar perfil ou assumir outra credencial. A 0.26.0 intermediária não é a entrega final.

## Contrato entregue e consequência

Contrato público **mutation-audit/1.0.0**, documentado integralmente em docs/MUTATION-AUDIT.md e em system/guide document:mutation-audit. Classe pública Fator3\McpFiles\MutationAudit: capabilities, register, record e status. Hook f3_mcp_register_mutation_audit. Descritor: contract, provider, reader e event_contract. A nova ferramenta audit/get-operation recebe provider e operation_id.

O adaptador automático está delimitado à versão LinkedIn 0.5.0, ao hook f3_linkedin_mutation_recorded, ao evento linkedin-mutation/1.0.0 e ao leitor linkedin/get-write-operation. Não lê tabela/classe privada do LinkedIn. O índice guarda referência e hashes declarados; before/after são lidos no diário somente com autorização atual. Campos estranhos do evento são descartados. Uma referência por provedor/operação; as tentativas MCP permanecem correlacionadas, inclusive replay. Não há importação retroativa ou repetição de efeito remoto por falha de auditoria.

O painel pode consultar uma operação de painel somente pelo administrador de origem, preservando os gates do provedor. Uma operação MCP exige o usuário e a conexão originais; o painel não assume o grant. Perfis custom precisam permitir audit/get-operation e o leitor do provedor. Segredos são redigidos; depois=null mantém incerteza. A string central_audit=summary_only_until_mcp_contract ainda emitida pelo LinkedIn 0.5.0 é uma indicação histórica e não controla a capacidade real deste MCP.

## Orientação ao responsável LinkedIn

O LinkedIn 0.5.0 recebido funciona sem modificação. Na próxima versão do LinkedIn, registrar explicitamente o descritor pelo hook público e manter o evento/leitor ou versionar a mudança com novo encaminhamento; o adaptador automático não presume compatibilidade de versões futuras. Atualizar então a indicação central_audit para refletir a capacidade detectada. Isso não foi alterado pelo agente MCP e não é declarado como trabalho concluído do agente LinkedIn.

## Aceite e evidência

MCP: 31 verificações funcionais aprovadas em WordPress real com Core 1.46.1, Google 0.17.0, Meta 0.4.1 e LinkedIn 0.5.0. Escrita por MCP HTTP e dispatcher nativo de painel com HTTP LinkedIn sintético, um efeito por request_key, referência estável, antes/depois autorizado, bloqueios por outro administrador, não administrador, perfil insuficiente, ativo desmarcado e credencial revogada. Perfil nativo revogado não é reativado. Estado incerto, payload redigido, evento inválido e conflito de descritor também verificados.

No Site-Teste: MCP 0.26.1 saudável, descritor LinkedIn admitido, painel revisado e documentação integral conferida. Sem publicação/anúncio real LinkedIn. Evidências: evidencias/0260/acceptance.json, site-tests.json e site-documents.json. Encerrada a implementação MCP do impacto recebido; homologação de negócio com conta real continua com responsável LinkedIn/operador, quando solicitada.

Instalador final MCP: wp-mcp-fator3-0.26.1-instalador.zip; 841342 bytes; SHA-256 `ed8035e6e326ac3c2021bac1ae9c11fde39c26686e1763299b445c3992cb5384`. A regra de identidade/ativo do diário permanece a autoridade; não usar conexão alternativa para superar uma recusa.
