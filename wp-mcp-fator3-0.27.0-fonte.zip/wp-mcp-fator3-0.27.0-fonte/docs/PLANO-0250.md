# Plano de implementação — Fator3 MCP 0.25.0

Revisão de 21/10/2026. Base imediata: 0.24.0. Inclui integralmente o pedido MCP 62 recebido no documento Fator3 MCP(2).md e substitui o escopo preliminar apenas documental.

## Escopo e aceite

1. Navegação por assuntos com abas por URL e apresentação consistente com LinkedIn/Meta 0.4.1: Conexão do servidor, Clientes conectados, Arquivos e banco, Operações, Registro, Diagnóstico, Atualizações e Ajuda.
2. Perfis com rótulos e ajuda individual em português; habilidades em lista pesquisável com nome e identificador; tipos de conteúdo e identidades existentes selecionáveis. Preservar identidades, permissões, revogações, expiração e seleção fora da pesquisa.
3. Registro com datas/horas selecionáveis em UTC e resultado selecionável. Operações com estado selecionável e nomes traduzidos. Nenhum filtro exige ISO digitado.
4. Atualizações mostra apenas o próprio MCP. Salvar preserva integralmente os canais dos demais pacotes, valida revisão concorrente, permissões e origem HTTPS. Contrato de distribuição permanece versão 1.
5. Configurações operacionais estruturadas, limites validados e ajuda curta por campo. Manual completo em Ajuda, com documentos paginados, e pelo MCP system/guide. Sem editor JSON operacional.
6. Corrigir documentação/metadata vigente, distinguir históricos e registrar limites exatos testados. Nenhuma dependência obrigatória dos plugins opcionais.

## Referências conferidas

Core 1.43.0; Google 0.16.0; LinkedIn 0.4.1; Meta 0.4.1. Relatórios e ZIPs fornecidos conferidos. Os sociais adotam abas por URL e seletores com nomes. O Core inclui reconciliação da extensão Google. Não há alteração necessária em companion ou contrato público causada por esta versão; por isso não se abre pedido de impacto sem conteúdo.

## Validação

PHP nativo 8.3.6, WordPress local real, HTTP/FPM e MySQL isolados. Instalação limpa do ZIP final; atualização direta 0.24.0 → 0.25.0 com preservação de credenciais, opções, tokens, recibos e backups. Testes das mutações administrativas e rejeições de permissão, nonce e revisão; filtros e seleções; documentação integral/hash; regressão da projeção de booleanos do pedido 61. Conferência visual no Site-Teste e coexistência com os quatro companions atuais. Distinguir execução nativa, DOM e navegador; não declarar fluxos de provedores ou ChatGPT CIMD B22 como homologados sem execução.

## Entrega

Instalador, fonte completo reprodutível e relatório Markdown com evidências, limitações, bytes e SHA-256. Somente o MCP é instalado no Site-Teste; nenhuma publicação em frota, GitHub ou canal automático.
