# Fator3 MCP 0.26.1 — antes/depois no Registro central

Base imediata MCP 0.25.0. Escopo novo: impacto LinkedIn 0.5.0, Pedido LinkedIn 6(c). A aba MCP recebida não contém novo pedido aberto; não foi criada numeração artificial.

- Contrato mutation-audit/1.0.0 com referências ao diário do produtor, sem duplicar snapshots.
- Adaptador para evento e leitor público do LinkedIn 0.5.0, inclusive operações do painel.
- audit/get-operation e detalhe Antes/Depois no Registro, preservando usuário, conexão, perfil e ativo.
- Replay mantém operation_id; tentativas de transporte são correlacionadas à referência estável.
- Matriz recebida: Core 1.46.1, Google 0.17.0, Meta 0.4.1 e LinkedIn 0.5.0. Site-Teste preserva Google 0.16.0 instalado.
- B22/CIMD encerrado no Site-Teste em 21/10/2026, conforme relatório MCP 0.25.0 revisão 3; não implica nova homologação de toda frota ou de fluxos não executados.

Mínimos WordPress 7.1.2 e PHP 8.3.6; schema SQL 2. Mantidos identidade, ferramentas-raiz, contratos de SQL, executor, distribuição, OAuth e recuperação. Nenhuma chamada real de publicação/anúncio LinkedIn é necessária para homologar o contrato; a bancada usa respostas HTTP sintéticas. Consulte MUTATION-AUDIT, ATUALIZACAO e o relatório externo para evidências e limitações.

A candidata 0.26.0 foi instalada nesta rodada. A revisão visual encontrou um perfil de integração nativa revogado bloqueando também o administrador no painel. A 0.26.1 separa identidade nativa e política MCP: o painel não reativa perfil, não toma credencial e continua exigindo o administrador original. A 0.26.0 intermediária não é o artefato final desta entrega.
