# package-distribution/1.0.0

Produtor: `Fator3\McpFiles\PackageDistribution`, MCP 0.22.0. Registro optativo de pacotes e seleção explícita de origem. Não cria dependência de instalação.

```php
PackageDistribution::capabilities(): array;
PackageDistribution::register(array $descriptor); // true ou WP_Error
PackageDistribution::status(): array;
PackageDistribution::selection(string $package): array;
PackageDistribution::manifest(string $package); // documento ou WP_Error; pode fazer HTTP
PackageDistribution::guard(array $snapshot); // true ou WP_Error; leitura local
```

`capabilities`, `status` e `selection` não fazem HTTP. `manifest` é a busca explícita. O registro ocorre no hook `f3_mcp_register_packages`, após o registro de provedores. Descritor estrito: `contract`, `package` (slug), `plugin` (`slug/entrada.php`) e `provider` já registrado. Os três pacotes atuais MCP/Core/Google permanecem predefinidos. Registro equivalente é idempotente; colisão recusa a identidade. Ver `schemas/package-descriptor.schema.json`.

```php
add_action('f3_mcp_register_packages', static function ($contract) {
    if ($contract !== 'package-distribution/1.0.0') return;
    \Fator3\McpFiles\PackageDistribution::register([
        'contract' => $contract,
        'package' => 'meu-plugin',
        'plugin' => 'meu-plugin/meu-plugin.php',
        'provider' => 'meu-plugin',
    ]);
});
```

## Um proprietário por operação

`selection` retorna `available`, `origin` (`mcp` ou `provider`), `revision`, `package`, `plugin`, `provider`, `contract` e `fallback_allowed:false`. Uma URL de canal MCP explicitamente configurada seleciona MCP, mesmo que a origem própria do consumidor também exista. Sem URL MCP, a origem é `provider`: isso não garante que o consumidor tenha uma oferta configurada. Nunca tentar a segunda origem porque a primeira falhou.

O consumidor captura a seleção antes de preparar a oferta e chama `guard` imediatamente antes do efeito. Uma revisão alterada exige nova oferta. Os filtros MCP verificam incidência antes de buscar manifesto. Quando a origem é do provedor, devolvem o resultado anterior; quando MCP é selecionado, falhas de manifesto/hash/origem são erros, sem fallback. Pacotes opcionais registrados podem ter outro host em Update URI: a seleção final de ofertas aplica somente os pacotes cujo proprietário é MCP. As ofertas MCP carregam `f3_distribution_selection`; o download e o pre-install conferem sua revisão. O executor MCP mantém lock compartilhado da configuração enquanto aplica; o formulário de configuração usa lock exclusivo.

O recibo público na option **`f3_mcp_distribution_selection`** é parte deste contrato. Contém apenas contrato e mapa `packages` de seleções, sem URLs dos feeds. O consumidor pode persistir sua própria cópia e deve consultá-la quando a classe MCP não estiver disponível: se a última seleção conhecida era MCP, ausência do plugin não libera automaticamente a origem própria. Reconfiguração deliberada do administrador é necessária. Ausência de recibo/contrato tem diagnóstico próprio; não é uma busca HTTP nem uma autorização de fallback. A option privada `f3_mcp_update_channels` não faz parte da API do consumidor.

## Segurança e instalação manual

Manifesto exige identidade exata, versão, SHA-256, origem pública HTTPS sem redirecionamentos, limites de bytes e requisitos próprios WordPress/PHP. Versões de outros plugins são informativas. `Update URI` não é automaticamente URL de feed.

O upload manual por rota tipada usa ZIP, SHA esperado, staging, validação de caminhos/expansão, backup e prova. Não depende de um feed configurado. Autoatualização nativa do próprio MCP, quando interceptada pelo canal MCP, continua exigindo executor de recuperação. Não remova filtros nem leia configuração privada para forçar uma origem.

Google 0.8.5 conserva o comportamento atual; seu consumo efetivo deste SDK pertence ao GOOGLE-02 da 0.8.6 e não foi declarado homologado apenas pela fixture.
