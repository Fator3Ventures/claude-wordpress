# Fator3 MCP — plano da versão 0.23.0

**Planejamento · revisão 2 · 2026-10-16T03:09:06-03:00 · America/Sao_Paulo**

A versão-alvo passa a ser **0.23.0**, por incremento minor obrigatório no padrão vigente. A proposta anterior de 0.22.1 foi somente planejamento e não gerou software. A base permanece **0.22.0**, já instalada segundo a aba do pacote. Esta revisão substitui o plano anterior sem renomear a versão publicada.

Prioridades: **Pedidos MCP 60** (chave de idempotência nativa), **M91-01/N24** (diagnóstico público tipado), **M91-02/N25** (conflito de revisão), documentação instalada paginada e provas das integrações existentes. Os IDs locais MCP-221-01 a MCP-221-08 e V01–V21 são preservados por rastreabilidade; seu prefixo histórico não designa a versão-alvo. MCP-221-09 é a frente local do Pedido 60, sem criar ou alterar a numeração central de pedidos.

Diretrizes lidas integralmente: `instrucoes-agentes-plugins-fator3.md`, revisão 3, e `padrao-desenvolvimento-plugins-fator3.md`, revisão 3, ambas de 16/10/2026. Também lidos `Regra comum.md` (16/10/2026), a aba `Fator3 MCP.md` (16/10/2026), encaminhamento Google 0.9.1 revisão 1 e impacto Core 1.33.0→MCP revisão documental 4. Google 0.9.1 é a designação recebida de uma proposta do outro mantenedor; este plano não a renomeia nem presume que exista seu binário.

Esta rodada é **documental e de inspeção estática**. O instalador e o fonte MCP 0.22.0 foram conferidos por SHA-256. A auditoria de empacotamento passou para os 455 arquivos do instalador, comparados ao inventário gerado pelo build do fonte: 400 entradas de runtime e 55 `index.php` gerados pelo build. Isso não é teste funcional PHP/WordPress nem rehash de instalação remota. Nenhum código de plugin, site, conta ou configuração foi alterado. Todos os aceites de 0.23.0 abaixo continuam planejados.

## 1. Base e decisões

| Componente | Base disponível | Papel nesta release |
|---|---|---|
| MCP | 0.22.0 | Atualização direta para 0.23.0 ou instalação limpa |
| Core | 1.33.0 | Integração corrente e reprodução do conflito; 1.34.0 é candidato futuro, fornecido como plano |
| Google | 0.9.0 | Consumidor real dos registros de executores e distribuição; diagnóstico afetado pela sanitização |
| Meta | 0.1.0 | Provedor real de Instagram, com abilities próprias e transporte MCP opcional |
| LinkedIn | 0.1.0 | Provedor real de relatórios e produtor do SDK `linkedin-lead-reader/1.0.0` |

Instalação, ativação e bootstrap continuam independentes da versão, presença e ordem dos acompanhantes. Falta de capacidade ou concessão afeta apenas a operação correspondente. Isso não elimina os requisitos próprios de PHP/WordPress, a validação de pacotes ou as permissões de domínio.

As transições MCP 0.21.0→0.22.0, Core 1.31.0→1.33.0 e Google 0.8.4→0.9.0 são evidência histórica. Não voltar a exigir versões intermediárias, criar migrações históricas ou acrescentar um adaptador Google 0.8.4. O caminho corrente Google 0.9.0 deve usar seu registro explícito, sem depender do adaptador nominal 0.8.5 existente. Remover esse adaptador não é pré-requisito das correções; limpeza de compatibilidade sem relação com os defeitos fica fora desta release.

Preservar `server-integration/1.0.0`, `executor-registration/1.0.0` e `package-distribution/1.0.0`. A correção do envelope mantém o contrato de resultados vigente e sua extensão documentada. Os contratos de execução/configuração de cada produtor não serão uniformizados à força.

**MCP-01, MCP-02 e MCP-03 já foram entregues na 0.22.0.** A antiga divergência com o plano Google 0.8.6 foi superada por MCP 0.22.0 e Google 0.9.0. Não reabrir MCP-03 como construção de uma bridge genérica nova: nesta etapa falta completar a prova com os consumidores reais e os endpoints dedicados.

## 2. Achados e alcance das evidências

| Achado | Evidência e conclusão | Tratamento |
|---|---|---|
| Campos públicos redigidos | Homologação MCP e encaminhamento Core; `DataSafety::secret_key()` reconhece `pass`/`credential`, e `SafeOutput::error()` substitui valores inteiros, booleanos e objetos | Correção obrigatória no MCP |
| Conflito classificado como falha genérica | Core retorna `ok:false`, `code:revision_conflict`, `data:null`; `Result::normalize()` acrescenta `error_code:operation_failed`, `conflict:false` | Correção obrigatória no MCP |
| Bridges Google não exercitadas diretamente | Homologação viu o registro, mas não chamou as ferramentas dedicadas; o fonte Google 0.9.0 já declara ambas pelo SDK | Teste real de transporte; mudança de código somente se demonstrada falha |
| Pacotes sociais já existem | Instaladores e fontes 0.1.0 recebidos; relatório registra instalação no Site-Teste e 30 casos nativos com APIs simuladas | Atualizar o estado dos contratos antes marcados como propostos e testar a fronteira MCP |
| Lead Sync ainda exige integração Core | LinkedIn 0.1.0 entrega o leitor; Core 1.33.0 não tem seu consumidor. O SDK não entrega a passagem de contexto durante troca comercial | Trabalho Core/LinkedIn; não criar um cliente ou bridge Core no MCP |
| Pós-imagem divergente em bancada anterior | Google relata arquivos antigos reaparecidos e conflitos, sem causa estabelecida; percursos independentes passaram | Instrumentar e tentar reproduzir; não atribuir causa ao MCP nem relaxar a guarda |
| Chave nativa retirada e schema substituído | Inspeção própria de `AbilityRuntime::decorate`, `ExecutionCoordinator::locked/once` e schemas/uso Meta e LinkedIn 0.1.0; produção relatada na aba MCP | Pedido MCP 60; corrigir transporte e decoração sem mudar o contrato do produtor |
| Ajuda sem paginação | `Guide::register/read` oferece `topic`/`ability`, temas e hash, mas não cursor/limite nem guarda entre páginas | Evoluir `system/guide` de forma compatível |
| Nova autorização CIMD ainda pendente | A conexão OAuth existente funcionou no Site-Teste; isso não prova uma nova conexão ChatGPT completa | Manter B22 aberto com aceite específico |

A aba MCP informa 0.22.0 nos 12 sites, com Google 0.9.0 e Core 1.33.0; essa é evidência recebida, não uma inspeção remota desta rodada. A situação da frota é mais recente que a incerteza registrada no encaminhamento Google. Antes de testar ou instalar, reler o estado real. A presença da aba não encerra B22.

O inventário recebido do Site-Teste compara nomes e tamanhos dos arquivos; não equivale a rehash independente de cada arquivo. A prova social de bootstrap isolado ocorreu por requisição controlada, sem uma matriz completa de instalações limpas. O relatório Google usa WordPress real com respostas de fornecedor simuladas. Nenhuma dessas evidências comprova credenciais ou execução real nas contas Google, Meta ou LinkedIn.

## 3. Trabalho da release

### MCP-221-01 — Preservar o diagnóstico público sem expor segredos

**Prioridade P0, junto ao Pedido MCP 60 e à normalização de conflitos.** Corrigir a política de apresentação aplicada às respostas tipadas. A regra usada para tabelas SQL, options e metadados arbitrários não pode ser relaxada globalmente para resolver o preflight Google.

Pontos de revisão: `includes/DataSafety.php`, `includes/Release014.php` (`SafeOutput`), `includes/Support.php` e `core/includes/Server/Handlers/Tools/ToolsHandler.php`, além dos chamadores afetados. A fronteira de logs deve receber a mesma atenção nos casos de erro exercitados.

Implementar uma distinção explícita entre campo público tipado e folha secreta. Não liberar um objeto inteiro por se chamar `credential`, não permitir qualquer valor sob um nome aparentemente seguro e não renomear campos do Google como contorno. Indicadores conhecidos devem conservar seu tipo; conteúdo desconhecido continua protegido pela política conservadora. Tratar objetos e arrays conforme os formatos efetivamente aceitos na serialização.

Aceite mínimo no preflight sem credenciais, tanto no callback quanto na ability e no HTTP MCP:

```json
{
  "checks_passed": false,
  "all_checks_passed": false,
  "passed": 0,
  "credential": {"configured": false}
}
```

O envelope pode acrescentar metadados do canal; os campos públicos de domínio devem permanecer equivalentes. `execution_success:true` significa que o diagnóstico foi executado, sem transformar verificações reprovadas em sucesso de configuração ou acesso remoto.

Os negativos incluem senha, token e chave privada sintéticos, inclusive dentro de `credential`, arrays e objetos aninhados. Conferir saída textual, `structuredContent` e os registros gerados pelos cenários. Não registrar segredos para demonstrar sua redação: usar marcadores sintéticos e evidência sanitizada. Preservar a entrega autorizada de `confirm_token` nas respostas das operações em duas fases que o exigem, sem passá-lo aos logs. A apresentação redigida não altera backups privados nem seus controles de acesso.

### MCP-221-02 — Normalizar conflitos sem alterar o erro de domínio

**Prioridade P0, na mesma release.** Corrigir `Result::normalize()` e documentar uma tabela explícita de classificação. Para a resposta Core afetada, o resultado esperado é:

```json
{
  "ok": false,
  "code": "revision_conflict",
  "data": null,
  "success": false,
  "error_code": "revision_conflict",
  "conflict": true,
  "retryable": false
}
```

Preservar os campos nativos e não trocar `null` por objeto, lista ou string. O código `revision_conflict` deve preencher corretamente o envelope comum quando este estiver ausente. Envelopes comuns já válidos permanecem estáveis; entradas contraditórias precisam de precedência documentada e caso de regressão, sem produzir combinações enganosas.

Não identificar conflito por mensagem traduzida, substring ou simples falha. Códigos desconhecidos conservam seu código nativo e usam o fallback genérico documentado; falha real de banco continua falha de banco. Conflito de revisão não autoriza repetição automática: exige releitura e nova intenção/revisão. Cobrir arrays, `WP_Error` e passagem repetida pelo normalizador, sem duplicar ou degradar o resultado.

As correções 01 e 02 devem ser verificadas juntas no mesmo candidato, porque uma normalização correta seguida de sanitização destrutiva ainda viola o aceite. Encaminhar a evidência correspondente aos casos Core **N24/N25**.

### MCP-221-03 — Validar os registros genéricos com Google 0.9.0

Usar o pacote real, e não apenas um produtor de teste. Comprovar a chamada HTTP direta de `google/mcp-read` e `google/mcp-write` no servidor que as expõe. Chamar uma bridge dentro do executor genérico é um negativo de aninhamento, não prova do caminho dedicado.

Conferir autorização da ferramenta raiz e do alvo, os seis prefixos declarados pelo Google, identidade da conexão, revogação durante a operação e o isolamento entre grants. Mudança na ordem das chaves de objetos e atualização de `last_seen` não devem invalidar autorização equivalente; mudança real de política deve interromper o uso. Simular escrita não concede permissão de escrita.

Validar o consumo de `package-distribution/1.0.0`: origem selecionada, revisão, manifesto, guarda, MCP inativo, origem indisponível, alteração entre prévia e execução e ZIP manual. Somente a origem escolhida executa; indisponibilidade não habilita fallback silencioso. Não acessar options privadas, chamar `UpdateChannel` pelo consumidor ou remover filtros de outro produto.

Transportar cursor, cobertura, qualidade, avisos, `partial`, `null`, zero e estado incerto sem reinterpretar a coleta. Preservar **2.097.152 bytes** como limite atual do JSON que alimenta `structuredContent` no caminho padrão de `ToolsHandler`, depois da normalização/decoração. Esse número não é o tamanho total do HTTP, que também contém representação textual e envelope JSON-RPC. Medir ambos e não apresentar esse teto como orçamento de rede total. Excesso continua `result_size_limit`, sem truncamento silencioso, sem declarar coleta completa e sem gerar exportação/job automático.

**G91-01:** o Google propõe **1.048.576 bytes** para seu envelope de domínio, paginação por bytes e seção e orientação de job explícito para consulta inline grande. A implementação pertence ao Google. O MCP documentará seu limite e validará a saída final decorada, incluindo UTF-8 multibyte, metadados de continuação e estados incompletos. Não elevar o teto para acomodar a coleta de 8 MiB. Até o candidato Google existir, usar fixtures para o contrato e registrar a prova integrada como pendente.

### MCP-221-04 — Homologar Meta e LinkedIn como provedores reais

Conferir registro, descoberta, schemas e execução das abilities dos dois pacotes 0.1.0, em instalação isolada e combinada. O relatório recebido declara 23 operações Meta e 37 LinkedIn; a prova deve comparar os catálogos efetivos de cada binário, sem confundir esse total com a contagem global da conexão.

Os pacotes publicam abilities próprias. Não exigir que passem a declarar executores dedicados ou uma origem de atualização automática: essas integrações são opcionais. Não acrescentar nomes sociais fixos ao servidor MCP.

Testar leitura sem credenciais, falhas tipadas e cenários sintéticos autorizados de consulta, job, continuação e exportação CSV/JSON. Revalidar a identidade e concessão ao criar, continuar e ler o resultado. Dois usuários, dois grants do mesmo usuário, recurso não concedido, grant revogado e dados pessoais devem ter negativos próprios. Uma classificação de leitura não basta para autorizar respostas pessoais de leads. Criar jobs/exportações e alterar assinaturas devem manter seus efeitos e permissões declarados.

O MCP deve respeitar também os limites menores impostos pelo produtor. Não ampliar página ou resposta para preencher o teto de transporte. Metadados de cobertura e identificadores remotos permanecem intactos; timestamp em milissegundos não vira número de ponto flutuante.

### MCP-221-05 — Regressão de pacote, ativação e preservação de estado

Executar instalação limpa e atualização MCP 0.22.0→0.23.0. Cobrir pacote novo com ativação, pacote presente inativo com ativação, atualização de pacote ativo e instalação sem ativação, incluindo o caminho nativo WordPress pertinente. Usar requisição nova para comprovar o código efetivamente carregado e distinguir arquivos aplicados, plugin ativo, hooks executados e prontidão do domínio.

Preservar clientes DCR/CIMD, grants, perfis, tokens válidos, configurações, referências de backup e estado operacional corrente. Não resetar caches, credenciais ou concessões por conveniência. Jobs e configurações dos acompanhantes devem permanecer sob seu próprio dono. Requisitos de instalação não podem depender de um número nominal de versão de outro plugin.

Comparar caminhos e SHA-256 de cada arquivo com o instalador depois de encerrar os processos do ensaio. Registrar prévia de rollback e suas limitações: rollback de arquivos não reverte banco ou efeitos remotos. Se reaparecer divergência de pós-imagem, preservar journal, inventários anterior/posterior, staging/previous e características do filesystem; investigar a reprodução antes de definir uma correção. Nunca forçar rollback sobre pós-imagem divergente nem limpar arquivos históricos indiscriminadamente.

### MCP-221-06 — Fechar a pendência CIMD com evidência própria

Não há novo defeito CIMD identificado nesta revisão. Manter a correção da 0.22.0 e executar seus controles de regressão: lista plural contendo `none` aceita; métodos exclusivos incompatíveis e lista malformada rejeitados; comportamento legado documentado; identidade, redirect URI, recurso, PKCE S256 e consentimento preservados. Manter diagnóstico correlacionável sem tokens, códigos, segredos ou URL completa da autorização.

Para fechar **B22**, uma conexão CIMD nova do ChatGPT deve completar login, consentimento, troca de código, `initialize`, listagem de ferramentas e uma leitura. Registrar separadamente a conexão DCR existente, novo registro DCR e renovação de token. Teste HTTP simulado ou reaproveitamento de conexão existente não fecha esse aceite.

A atualização corretiva não deve exigir nova autorização de conexões válidas. A criação de uma nova conexão para o ensaio B22 é uma etapa de homologação, não um procedimento obrigatório para todos os usuários. Documentar o comportamento do cache e qualquer exceção efetivamente identificada.

### MCP-221-07 — Alinhar a integração com o Core 1.34.0

Fornecer ao responsável Core o candidato, hash e evidência N24/N25. Quando o binário Core 1.34.0 estiver disponível, repetir callback→ability→HTTP com esse candidato e a atualização direta 1.33.0→1.34.0. A ausência desse binário não impede instalar ou testar o MCP com o Core 1.33.0; impede declarar a integração futura homologada.

O Core planeja configuração administrativa **8.0.0**, distinta do SDK `site-measurement-context/1.0.0`, cuja revisão de schema permanece `"1"`. O MCP não deve inferir prontidão da integração pela versão administrativa nem ler opções privadas para compensar falta de contrato.

O SDK LinkedIn 0.1.0 já existe, mas a troca Core→plugin→Core, drenagem e verificação de notificações com contexto anterior ainda precisam de coordenação entre Core e LinkedIn. Dois clientes comerciais podem coexistir no produto com escolha explícita por integração; ausência ou revogação pausa o fluxo escolhido, sem fallback. O cron usa concessão de consumidor local, sem usuário humano artificial e sem uma bridge Core adicional. O MCP apenas transporta as operações públicas que o Core vier a publicar, respeitando seus gates.

Pedidos core **212/217** permanecem no Core: diagnósticos de memória e encerramento sem configuração. Quando seus payloads/candidato forem recebidos, preservar tipos, códigos e estado sem converter ausência de configuração em sucesso. Não corrigir cálculo de memória ou lógica de tarefa no MCP.

### MCP-221-08 — Documentação e entrega rastreável

Atualizar documentação corrente, changelog, contratos publicados e exemplos para MCP 0.23.0, Google 0.9.0 e os produtores sociais 0.1.0. Marcar Core 1.34.0 como planejado até existir evidência do candidato. Corrigir referências que ainda apresentam bridges genéricas ou SDK LinkedIn como não entregues. Relatórios históricos permanecem intactos.

Separar evidência recebida, testes desta implementação, WordPress com fornecedor simulado, HTTP MCP real, ChatGPT real e fornecedor externo real. Não somar contagens de suítes recebidas como se fossem novos testes executados. Listar limitações por componente e caso, sem rótulo genérico de “homologação completa”.


**Documentação instalada:** preservar `system/guide`, hoje com `topic` e `ability`, acrescentando leitura paginada compatível. Definir no schema parâmetros aditivos para cursor/limite e revisão esperada; devolver slug, versão, ID do documento/tema, hash, origem local, continuação e fim explícito. Manter chamadas existentes para temas curtos; se uma leitura integral exceder o teto, devolver orientação explícita para paginação. A leitura longa deve detectar troca de hash entre páginas. A implementação deve congelar e publicar os nomes novos antes dos testes conjuntos, sem inventar uma rota concorrente.

O build atual empacota manual compilado em `includes/guide-content.php` e exclui `docs/` do runtime. Conservar a geração a partir de uma fonte única e verificar que todos os tópicos obrigatórios — especificação, configuração, uso, contratos, guia de agentes, operação e release — estão acessíveis no pacote instalado. Arquivos externos isolados não fecham o aceite. IDs/allowlist devem impedir caminhos arbitrários, travessia e symlinks externos; abrir ajuda não chama fornecedor nem altera estado. O gate estático existente não será reduzido. Conta conectada e configuração efetiva exigem `manage_options` ou capacidade exclusiva de administrador, cumulativamente às permissões MCP/domínio. Verificar painel, REST e MCP nas fronteiras afetadas; desvios no social são encaminhados ao dono, sem correção indevida de seu pacote.

**Entrega futura:** `wp-mcp-fator3-0.23.0-fonte.zip`, `wp-mcp-fator3-0.23.0-instalador.zip`, `wp-mcp-fator3-0.23.0-relatorio.md` e cinco impactos, destinados a `base-site-core-fator3`, `wp-mcp-google-fator3`, `wp-mcp-meta-fator3`, `wp-mcp-linkedin-fator3` e `implantador-base`. Conferir cabeçalho/tela, nomes, raízes, runtime, versão e hashes; o fonte inclui cópia do relatório identificada como anterior ao fechamento. Relatório externo segue as oito seções do padrão, com título `Entrega — Fator3 MCP 0.23.0` e bytes/SHA-256 dos dois ZIPs.

### MCP-221-09 — Pedidos MCP 60: preservar idempotência do produtor

**P0. Evidência própria estática:** `AbilityRuntime::decorate()` substitui o schema `idempotency_key` por string de 1–128 caracteres em toda escrita aderente; `ExecutionCoordinator::locked()` retira a chave antes do callback. Meta e LinkedIn 0.1.0 declaram o campo em `create-job` e `export`, com `maxLength:64`, padrão `^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$` e presença obrigatória. `Query` e `Export` o usam na identidade da operação. O LinkedIn também o declara em `lead-create-subscription`; testar este último com fornecedor controlado e sem assinatura externa real. A prova de produção Meta foi recebida na aba MCP; não foi repetida nesta rodada.

Contrato da correção:

1. Registrar internamente, no momento da decoração, se o campo já existia no schema original. O registro não pode ser controlado pelos argumentos enviados pelo cliente. Não consultar somente o schema já decorado para inferir a origem do campo.
2. Quando nativo, preservar valor, schema, `required`, limites, padrão e semântica do produtor. Não fazer trim, renomear, gerar outra chave nem ampliar limites. Repassar ao callback; uma chave opcional ausente continua ausente. Aplicar também a campo nativo de leitura, sem acrescentar idempotência de escrita à leitura.
3. Quando acrescentado exclusivamente pelo MCP, manter o contrato atual do canal e removê-lo somente da chamada ao callback que não o declarou. Preservar operações próprias e duas fases. Repetir a decoração não deve perder a origem original.
4. O canal pode usar a mesma chave nativa para sua proteção, mantendo isolamento por site/conexão/usuário/ability e identidade dos argumentos. A mesma chave com intenção diferente retorna conflito; repetição equivalente devolve o mesmo job/exportação sem efeito duplicado. Não mudar o algoritmo/chaves persistidas sem necessidade demonstrada nem migrar históricos por conveniência.
5. Revalidar autorização antes de entregar resultado em replay. Concorrência, resultado incerto, registro compactado e revogação continuam protegidos. A conferência da permissão do produtor não pode ser contornada por resultado armazenado.
6. Verificar a interação entre `locked()` e `once()`: a retirada da chave da projeção usada no fingerprint não tem o mesmo propósito que sua retirada dos argumentos do callback. Separar essas responsabilidades e testar ambas, inclusive pelo executor genérico. Não resolver o defeito removendo globalmente a idempotência MCP.

**Inferência a validar na implementação:** `once()` grava o retorno normalizado como `complete` mesmo em falhas não listadas como transitórias. Uma tentativa 0.22.0 que tenha alcançado esse ponto com `invalid_input` pode continuar devolvendo o erro antigo após o upgrade. Preparar fixture real desse registro. Política inicial: preservar os registros; para chave com falha antiga, documentar reconciliação do job/exportação no produtor e nova chave somente depois de comprovar ausência de efeito. Não expurgar toda a tabela nem executar automaticamente operações incertas. Qualquer alternativa de reabertura seletiva exige prova de ausência de efeito, identificação exata da falha e regressão correspondente.

**Aceite específico do Pedido 60:** em conexão Meta autorizada no Site-Teste, `meta/create-job` e `meta/export` via MCP retornam sucesso de domínio e recibos válidos; repetir a mesma intenção/chave retorna o mesmo job/exportação. Usar coleta mínima e recursos de teste. Separar a prova com pacote real/API simulada da prova com conta real solicitada; indisponibilidade de credencial deixa esta última pendente. Não tratar HTTP 200 isolado como sucesso de domínio.

## 4. Matriz mínima de aceite

Todos os casos abaixo estão **planejados**. Cada execução deve informar hash do candidato, ambiente, identidade/perfil sintéticos, entrada sanitizada, resultado esperado/observado e evidência. Reutilizar fixtures existentes quando cobrem o risco; não repetir toda a suíte histórica sem necessidade.

| ID | Cenário e resultado obrigatório | Fronteira |
|---|---|---|
| V01 | Preflight Google sem credencial preserva booleanos, zero e `credential.configured:false` | Callback, ability e HTTP |
| V02 | Segredos sintéticos aninhados continuam protegidos; tipos públicos equivalentes em sucesso/erro e nas duas representações MCP | Unitário e HTTP/logs |
| V03 | Revisão válida executa; revisão vencida retorna código coerente, `conflict:true`, `data:null` e sem retry automático | Core 1.33 e MCP |
| V04 | Falha SQL, código desconhecido, `WP_Error`, envelope válido e normalização repetida não viram conflito indevido | Unitário e WordPress |
| V05 | Prévia/confirmar de operação em duas fases continua utilizável; segredos de banco seguem redigidos na apresentação | WordPress e HTTP |
| V06 | Google registra e executa suas duas bridges diretamente no servidor correto | Pacote Google real e HTTP |
| V07 | Alvo sem grant, outro provedor, bridge aninhada, perfil read, escrita simulada e outro servidor são recusados conforme política | HTTP; efeitos remotos controlados |
| V08 | Mesmo usuário/grants distintos, usuários distintos, revogação e mudança real de política isolam operação e resultado; ordem de chaves equivalente não falha | WordPress e HTTP |
| V09 | Distribuição respeita seleção/revisão e não troca de origem na indisponibilidade; ZIP manual permanece disponível | MCP + Google real |
| V10 | Meta/LinkedIn registram catálogos reais sem exceção por nome; autorização do MCP e do produtor continuam cumulativas | Pacotes sociais reais e HTTP |
| V11 | Job, cursor e leitura de exportação não atravessam usuário/grant; revogação impede continuação/acesso | Social/Google com dados sintéticos |
| V12 | Grant de relatórios não autoriza leads pessoais ou mutação de assinatura; campos nativos, nulos e cobertura são preservados | LinkedIn real, API controlada |
| V13 | Resposta no limite e acima de 2 MiB, incluindo serialização multibyte; limite menor do produtor prevalece; excesso não vira sucesso parcial silencioso | Serializador e HTTP |
| V14 | Instalação limpa e quatro estados de ativação; chamada em requisição nova sem aquecimento corretivo | WordPress nativo e executor MCP |
| V15 | Atualização 0.22.0→0.23.0 preserva OAuth, perfis, estado e dados; componentes ausentes e ordens opostas não bloqueiam bootstrap | Bancada isolada |
| V16 | Hash por arquivo após fim dos processos, pós-imagem e prévia de rollback; conflito preserva evidência e recusa ação insegura | Filesystem real |
| V17 | Regressões CIMD positivas/negativas, cache e diagnóstico seguro | Automatizado e HTTP |
| V18 | Nova conexão CIMD ChatGPT completa login→consentimento→código/token→initialize→tools/list→leitura | ChatGPT real; fecha B22 |
| V19 | DCR novo, DCR existente e refresh continuam válidos após atualização | OAuth real em ambiente de teste |
| V20 | N24/N25 repetidos no Core 1.34.0 com hashes fixados e SDK de medição preservado | Condicionado ao candidato Core |
| V21 | Isolamento completo com MCP sozinho, pares relevantes, conjunto atual e provedor desativado; diagnóstico local não faz reparo ou concessão | Instalações de teste |
| V22 | Schema e valor nativos preservados, inclusive padrão/tamanho/required, chave opcional, leitura e decoração repetida; chave exclusivamente MCP removida do callback | Fixture + Meta/LinkedIn reais |
| V23 | Pedido 60: criar job e exportar pelo MCP, repetir chave e obter os mesmos recibos sem duplicação | Meta 0.1.0 + HTTP; conta autorizada separada |
| V24 | Jobs/exportações LinkedIn e assinatura controlada recebem chave nativa; negativos mantêm permissão e validação | LinkedIn real, fornecedor simulado |
| V25 | Mesma chave/intenção diferente, concorrência, grant revogado, registro incerto/compactado e isolamento entre usuários/conexões | Coordenador + WordPress/HTTP |
| V26 | Registro de falha `invalid_input` da base preservado; reconciliação e recuperação documentadas; sucesso antigo/estado incerto não repetem efeito | Upgrade 0.22.0→0.23.0 |
| V27 | Descobrir e ler ajuda completa paginada, validar hash, detectar alteração entre páginas e após upgrade; rejeitar caminho externo e comprovar ausência de efeito remoto | `system/guide`, painel e sessão MCP |
| V28 | Conta/configuração negadas a não administrador no painel/REST/MCP; ajuda estática não expõe dados; permissões de domínio mantidas | Fronteiras próprias; desvios externos encaminhados |
| V29 | G91-01: página Google até 1 MiB cabe após decoração; próxima seção/página preservada; inline excessivo não cria job; resposta acima de 2 MiB falha explicitamente | Fixtures; candidato Google quando disponível |
| V30 | Diagnóstico Core 212/217 conserva memória tipada, códigos e ausência de configuração sem aprovação indevida | Condicionado a payload/candidato Core |
| V31 | Artefatos, cabeçalho/tela, manual instalado, relatório e cinco impactos correspondem ao binário e ao build; sem ZIP aninhado | Empacotamento/documentação |
| V32 | Requisitos mínimos efetivamente declarados testados ou identificados como pendência; nenhuma redução nominal de mínimo sem prova | Ambiente de runtime |

V10–V12 provam a fronteira do transporte usando pacotes reais e fornecedor controlado. Acesso a contas reais, aceitação de aplicações, webhooks externos e entrega de leads exigem homologação própria do produtor/consumidor. Não são presumidos por aprovação do MCP.

## 5. Sequência e critérios de liberação

1. Fixar as entradas e reproduzir os três defeitos em testes que falhem na 0.22.0. Registrar o comportamento nativo antes de alterar o transporte.
2. Implementar MCP-221-09/01/02 e MCP-221-08 e executar as regressões de tipos, segredos, conflitos e operações em duas fases.
3. Produzir um candidato único e exercitar Google e sociais reais, com HTTP dedicado e matriz de identidade/concessão. Corrigir apenas falhas demonstradas de responsabilidade MCP; encaminhar falhas de produtor ao respectivo dono.
4. Executar instalação/atualização e comparar o inventário final. Qualquer alteração posterior exige novo hash e repetição dos casos afetados.
5. Executar B22 e DCR/refresh; entregar ao Core o candidato para N24/N25 quando sua 1.34.0 estiver disponível.
6. Entregar ao dono instalador, fonte, changelog, relatório de validação e cinco impactos com o mesmo conjunto de hashes. Publicação/implantação em sites é uma etapa posterior ao planejamento.

**Gate técnico MCP:** V01–V17, V19, V21–V22, V24–V28, V31–V32 e a parcela controlada de V23/V29 devem ter resultado correspondente no candidato para declarar a correção validada nesse escopo. Falhas de domínio dos acompanhantes são registradas com responsável e bloqueiam apenas o aceite integrado afetado. Instalação/uso próprio continuam independentes. Não declarar gate aprovado com um teste obrigatório pendente.

**Aceites externos separados:** V18 fecha B22 somente com ChatGPT real; V23 fecha o aceite de conta real Meta somente com conexão autorizada; V20/V30 dependem do Core candidato/payload e a parcela integrada de V29 depende do candidato Google. A falta desses acessos permite entregar candidato identificado, com estado `com-pendencias` e delimitação do uso validado. O transporte genérico não substitui a prova da bridge dedicada. O estado da frota não fecha B22.

**Distribuição:** entregar artefatos ao dono; publicação pela frota segue URL raw e conferência dos bytes com `expected_sha256` e `expected_slug`. Não criar fonte de atualização automática para os pacotes Fator3, habilitá-los em `auto_update_plugins` nem alterar a seleção de origem durante o upgrade. O contrato `package-distribution/1.0.0` permanece preservado sem ativação de feed nesta tarefa.

## 6. Fora do escopo

- Implementar clientes de API, coleta, métricas, credenciais ou agregações Google/Meta/LinkedIn no MCP.
- Implementar o seletor comercial Lead Sync, CRM, deduplicação, callback ou drenagem no transporte MCP.
- Sheets social, incluindo SDK, stubs, configuração preparatória e testes GOOGLE-SOC-01/S07. Sheets existente no Google permanece.
- Meta Ads no plugin Meta local; esse domínio continua no MCP oficial externo. Instagram é o escopo Meta local recebido.
- Leitor de leads Google Ads, BigQuery ou migração de relatórios Porter.
- Nova taxonomia de perfis, reset de concessões, compatibilidade histórica adicional ou migrações intermediárias.
- Nova mudança no mecanismo OAuth sem falha demonstrada e sem regressão correspondente.

## 7. Fontes e rastreabilidade

| Referência | Material usado | Uso principal |
|---|---|---|
| E01 | `relatorio-homologacao-mcp-0.22.0(1).html` | Comportamento recebido do Site-Teste, defeitos, limites e pendências |
| E02 | `encaminhamento-core-1.34.0-mcp-google.md`, revisão 2 | Dono das correções, N24/N25, isolamento, atualização e contratos |
| E03 | `plano-core-1.34.0(1).md` | Modelo Lead Sync futuro, configuração administrativa e gates Core |
| E04 | `encaminhamento-google-0.9.0-mcp (1).md` e `relatorio-entrega-google-0.9.0(5).md` | Consumidores dos SDKs, ordens de atualização e achado de filesystem |
| E05 | Fonte e instalador Google 0.9.0; `guia-wp-mcp-google-fator3-0.9.0(5).md` | `McpBridge`, `Distribution`, contratos correntes |
| E06 | `relatorio-meta-linkedin-0.1.0.html`, fontes e dois instaladores 0.1.0 | Produtores reais, limites da validação e SDK LinkedIn entregue |
| E07 | `encaminhamento-mcp(4).md`, `analise-e-plano-integrado (1)(2).md`, `contratos-integracao-social (1)(2).md` | Arquitetura, histórico de tickets e fronteiras de responsabilidade; estados antigos reconciliados com E02/E06 |
| E08 | Fonte entregue MCP 0.22.0 | Conferência estática de sanitização, normalização, serialização e registro de executores |

Hashes dos pacotes conferidos nos bytes locais; essa conferência não é validação funcional:

| Pacote | SHA-256 |
|---|---|
| Fonte MCP 0.22.0 | `50ff0c8734a7c133561dc44d45256fa0923bc7735655a25b6792d469e69bfda8` |
| Instalador Google 0.9.0 | `333e3f177be1095ac9e568e66d4d8cab9b4dfbd4d6a86505e8b7a02583182b32` |
| Fonte Google 0.9.0 | `a25b6202eabbc6d2d40de754d92f03c3a19ff5cae556315fa30497e7be6da814` |
| Instalador Meta 0.1.0 | `4ce0a3446a55f634bb109662c2aacd83759c7d0a9b467d6a8706b17b917fb378` |
| Instalador LinkedIn 0.1.0 | `6112381105bd60de42c61b47b7831aaefe94fbb88971eb79a4c7f6315a6c8999` |
| Fonte conjunto Meta/LinkedIn 0.1.0 | `0521ccafafac94752a326ecded8c5c13c1cf967e66d8de49a985ec7ebac4333b` |

Os relatórios recebidos identificam os instaladores MCP 0.22.0 por `622b75d20c3dc115bb8391d08f59c484ebbc6ac78547b8dac08b0f6b10e1fa7d` e Core 1.33.0 por `de427cb219be769d9e44ae9aaf5e6f31055990b3d8f9b8664ac0faa596f61364`. Esses dois valores são referências recebidas, não um rehash dos arquivos instalados no site nesta revisão.


## 8. Rastreabilidade desta revisão e coordenação

| Origem | Identidade | Incorporação |
|---|---|---|
| Padrão e instruções dos agentes | Revisão 3, 16/10/2026 | Minor, base atual, documentação instalada, autorização, artefatos e cinco impactos |
| `Fator3 MCP.md` | Aba de 16/10/2026, base 0.22.0 | Pedido MCP 60; itens 1–59 encerrados, sem reabertura; B22 separado |
| `encaminhamento-google-0.9.1-mcp.md` | Revisão 1, 16/10/2026 | M91-01, M91-02, G91-01; contratos preservados |
| `base-site-core-fator3-1.33.0-impacto-wp-mcp-fator3.md` | Revisão documental 4 | N24/N25, memória/configuração 212/217, documental/admin e hashes por arquivo |
| `implantador.md` | Documento do responsável de 23/09/2026 | Slug `implantador-base` confirmado; versão 2.5.0 é referência histórica, runtime atual não examinado |

As referências E01–E08 e contagens da revisão 1 permanecem histórico de evidência recebida. Nesta revisão, a inspeção própria foi concentrada nos anexos novos, nos pontos de código relacionados e na integridade dos ZIPs-base. Não reexecutamos as suítes citadas nesses relatórios.

**Encaminhamentos desta rodada:** cinco documentos com emissor disponível **0.22.0** e alvo planejado **0.23.0**, sem hash fictício de candidato. Core e Google: `acao-necessaria` para provas conjuntas; Meta e LinkedIn: `acao-necessaria` para prova do Pedido 60 e adequação administrativa sob seus próprios pedidos; Implantador: `nao-avaliado` para runtime atual, com orientação operacional. Todos preparados para o dono encaminhar; nenhum envio realizado.

**Sem implementação:** os ZIPs 0.22.0 anexos são bases imutáveis e continuam contendo os defeitos descritos. O relatório documental desta rodada não modifica o relatório congelado dentro do fonte antigo. A versão 0.23.0 ainda não possui instalador, fonte ou hash. Ações seguintes: implementar, testar o candidato e atualizar as evidências/impactos.
