# Atualização de premissas aprovada em 15/10/2026

A instrução final do usuário substitui as linhas de base intermediárias deste plano: MCP 0.21.1 e Core 1.32.0 não foram instalados. A entrega ensaia diretamente MCP 0.21.0 → 0.22.0 e Core 1.31.0 → 1.33.0 nas duas ordens, com Google 0.8.5 original. Não se acrescenta dependência de versões dos companheiros. O relatório 0.22.0 registra o tratamento de B01/B06 e M02–M04 conforme esta alteração.

Abaixo, o plano aprovado preservado para rastreabilidade; o estado efetivo dos aceites está no relatório.

# Fator3 MCP 0.22.0 — plano da próxima versão

Revisão 4 · 15/10/2026 · Situação: planejada, ainda não implementada.

A 0.22.0 prioriza dois defeitos: a ativação nativa de plugins pelo executor de pacotes e a negociação CIMD no OAuth usado pelo ChatGPT. Também publicará os contratos optativos de distribuição e registro de bridges, consolidará a integração com o Google 0.8.5 entregue e preparará a admissão/transporte dos provedores Meta/LinkedIn e das leituras de medição Core 1.33.0. A base de desenvolvimento é o MCP 0.21.1 final. No upload, `activate:true` pode informar sucesso sem executar a inicialização do plugin; no OAuth, a resolução CIMD ignora a lista de métodos suportados e impede novas autorizações compatíveis com `none`.

Por decisão do usuário em 15/10/2026, **0.22.0 substitui a versão planejada 0.21.2**, sem exigir uma release intermediária. **MCP-03 integra obrigatoriamente esta entrega**, na frente P09. Esta revisão conserva P01–P08/B01–B29 e acrescenta P09/P10, B30–B35 e C05/C06. P01/P02 e P06 continuam P0; P09 é P1 da mesma release. O pedido OAuth permanece integral e sua validação real ChatGPT continua separada. Meta/LinkedIn começam com abilities diretas, mesmo com o registro genérico disponível.

## Decisões mantidas

- Instalação, atualização, ativação e bootstrap MCP permanecem independentes da versão, presença e ordem dos companheiros. A matriz de testes identifica os pacotes ensaiados; não será convertida em condição de instalação.
- Continuam as entradas WordPress limpo e atualização direta do MCP 0.21.0. A passagem pela 0.21.1 não é obrigatória. A 0.21.1 já entregue também terá ensaio de atualização direta, como continuidade da versão corrente.
- Não retornarão importadores, aliases, migrações ou ajustes intermediários exclusivos de pacotes anteriores à base aceita. Estados e operações válidos produzidos pela 0.21.0/0.21.1 serão preservados.
- Permanecem schema MCP 2, política 1, SDK `server-integration/1.0.0`, provider `wp-mcp-fator3`, servidor `wp-mcp-ultimate-server`, identidades, concessões e recursos atuais. O registro de bridges terá contrato/capacidade aditivos próprios, sem mudar silenciosamente essas semânticas. Não há nova ability de negócio própria do MCP prevista.
- Correções pertencem ao MCP. Core 1.32.0 e Google 0.8.5 serão usados com seus instaladores originais, sem modificá-los para facilitar os testes. Candidatos futuros dos companheiros entram em linhas próprias, com versão/hash efetivos.
- A arquitetura passa a prever cinco plugins independentes: Core, MCP, Google, Fator3 Meta e Fator3 LinkedIn. Ausência de integração opcional afeta somente a função dependente. Não haverá plugin obrigatório adicional de infraestrutura.
- O modo de token manual dos novos provedores sociais não altera OAuth/CIMD/DCR do servidor MCP. Contratos sociais e de distribuição apresentados nesta revisão são propostas; não serão anunciados como APIs entregues antes de sua implementação.

## Enquadramento dos novos encaminhamentos

| Pedido recebido | Destino nesta versão | Situação e dependência |
|---|---|---|
| MCP-01 — ativação | P01/P02; B01–B07 | P0. Prontidão do domínio pertence ao dono do plugin; não há reparo privado pelo MCP. |
| Correção OAuth/CIMD | P06; B15–B22 | P0 preservado. A nova conexão real ChatGPT continua obrigatória para declarar homologação integral CIMD. |
| MCP-02 — distribuição | P07; B23/B24; C01 | P1. Fachada e testes com consumidor fixture podem ser entregues pelo MCP; adoção GOOGLE-02 exige candidata Google própria. |
| MCP-04 — documentação/transporte | P03/P05/P08; B27/B29; C04 | P1. Documentação e regressões do transporte podem avançar antes de P01; a prova do fluxo de instalação corrigido depende dele. |
| MCP-SOC-01 — provedores sociais | P08; B25/B26/B28; C02/C03 | P1. Fixtures agora; homologação independente de Meta e LinkedIn quando cada candidato existir. |
| MCP-03 — bridges genéricas | P09; B30–B34; C05 | P1 obrigatório na 0.22.0. Publicar registro/admissão genéricos e substituir a exceção de autorização Google, com equivalência comprovada e transição da base atual. |
| CORE-01/02 — leituras públicas de medição | P10; B35; C06 | Preparação MCP obrigatória com fixtures; produtor real Core 1.33.0 e integração Google permanecem com seus donos. |

| Domínio | Responsável e limite do MCP |
|---|---|
| Instagram Insights | Fator3 Meta guarda credencial, consulta API, coleta e aplica política de ativos. MCP admite e transporta as abilities publicadas. |
| LinkedIn Pages/Ads e API Lead Sync | Fator3 LinkedIn mantém clientes HTTP, credenciais e autorização de domínio. Relatório analítico não concede leitura de respostas pessoais. |
| Lead Sync comercial | Core mantém seleção, polling, callback pública, recibos, deduplicação, contatos e CRM. A troca para o provedor LinkedIn é explícita, pelo contrato proposto `linkedin-lead-reader/1.0.0`; instalar o plugin não troca o executor. |
| Meta Lead Ads, Pixel/CAPI e consentimento existentes | Permanecem no Core. O MCP não transfere tokens ou estado para o novo Meta. |
| Google e Sheets | Google mantém APIs, credenciais e exportações. `sheets-table-writer/1.0.0` é proposta P2: tabela pronta e destino concedido, sem coleta social pelo Google ou pelo MCP. |
| Meta Ads/Instagram Ads | A decisão recebida mantém o MCP oficial Meta como conexão externa do agente. Não criar cliente desse MCP dentro do WordPress. |

BigQuery, migração/importação Porter e compatibilidade com aliases de campos Porter ficam fora do escopo. As evidências remotas recebidas usam Core 1.31.0, MCP 0.21.0 e Google 0.8.4; a base estática dos encaminhamentos usa Core 1.32.0, MCP 0.21.1 e Google 0.8.5. Nenhum desses resultados homologa antecipadamente a candidata 0.22.0. O planejamento Core 1.33.0 e as futuras releases Google/Meta/LinkedIn continuam independentes.

## Achados e efeito no escopo

| Achado | Evidência examinada | Decisão |
|---|---|---|
| Ativação silenciosa no upload | `includes/RecoveryEngine.php::activate_worker()` da 0.21.1 chama `activate_plugin($plugin, '', false, true)`. | Corrigir o modo de ativação conforme o estado anterior e a intenção registrada da operação. |
| Inicialização omitida no Google novo | O hook do Google 0.8.5 define opções iniciais e chama preparação de armazenamento/agendas. O relatório Google registra `permission_denied` após o upload combinado em bancada. | Exigir ensaio de instalação realmente nova, com prontidão lida antes de qualquer manutenção que possa reparar o estado. |
| Atualização e primeira ativação têm ciclos diferentes | WordPress permite ativação silenciosa durante atualização. `PackageService` preserva `active_before` e executa a ativação em PHP novo. | Não substituir globalmente o quarto argumento por `false`; atualização de plugin previamente ativo conserva a reativação silenciosa. |
| A presença em `active_plugins` não prova inicialização | O worker atual comprova retorno/estado ativo; `plugins/activate` também retorna cedo quando o plugin já está ativo. | Separar estado ativo, conclusão do ciclo de ativação e saúde posterior. Não declarar que um plugin já ativo foi inicializado nesta operação. |
| O executor é copiado para MU-plugin | `Recovery::install_sentinel()` e `refresh_existing_sentinel()` mantêm uma cópia independente de `RecoveryEngine.php`. | Testar a atualização dessa cópia e o comportamento em nova requisição, incluindo autoatualização MCP e OPcache. |
| Google 0.8.5 já está entregue | Instalador, fonte, contratos e relatórios foram recebidos; os 139 arquivos do instalador coincidem com o manifesto de validação. | Substituir a referência condicional da documentação corrente por integração com os contratos efetivamente entregues. |
| A13/A14 receberam provas complementares | `native-clean/cold.json`, `native-repro/cold.json`, `native-install/install.json` e `native-upgrade/upgrade.json` do Google. | Preservar as evidências MCP anteriores. Anexar a complementação recebida e produzir provas próprias da 0.22.0. |
| CIMD compatível rejeitado | `core/includes/OAuth/ClientMetadata.php` da 0.21.1 considera apenas o campo singular e retorna `null` quando ele difere de `none`. O documento público ChatGPT consultado nesta revisão declara o singular `private_key_jwt` e a lista `["none", "private_key_jwt"]`. | Negociar a interseção dos métodos, mantendo suporte efetivo apenas a `none` e PKCE S256. |
| Erros OAuth sem distinção suficiente | `AuthorizationEndpoint` apresenta “Unknown client” quando a resolução não produz cliente; erros de armazenamento também podem ser lançados por `Persistence`. | Classificar causas e correlacionar a resposta com diagnóstico sanitizado, inclusive falhas de leitura/gravação. |
| Distribuição restrita a três pacotes | `UpdateChannel::PACKAGES` contém MCP, Core e Google; validação, oferta, download e painel usam essa lista. O filtro de download consulta o manifesto para pacotes reconhecidos. | P07 precisa de registro optativo de identidade e seleção da origem antes de buscar manifesto. Apenas envolver métodos privados em uma fachada não cobre novos pacotes nem a disputa de filtros. |
| Registro público já admite provedores adicionais | `ExtensionContract` valida identidade, versão e exclusividade de prefixos; `ServerContract` aceita contribuições públicas aderentes. A exceção de executores em `RootToolContext` permanece nominal Google. | Usar esse registro para abilities sociais diretas, provar autorização e colisões e conservar a recusa de executores aninhados. |
| Resultado estruturado já é preservado no caminho padrão | `ToolsHandler` serializa o resultado uma vez e devolve o mesmo JSON em texto e `structuredContent`. Essa inspeção não é prova de todos os limites do transporte. | Acrescentar regressões de envelopes e tamanho; alterar runtime somente quando um caso demonstrar perda ou autorização insuficiente. |
| Guia de extensões desatualizado | `docs/CONTRATO-EXTENSOES.md` do fonte ainda referencia Google 0.6/Core 1.19 e bridge futura; `SERVER-INTEGRATION.md` trata Google 0.8.5 como planejado. | Corrigir a documentação corrente e manter anexos históricos identificados. |

A causa da supressão de hooks foi confirmada por inspeção do MCP e do WordPress local e pela [referência oficial de activate_plugin](https://developer.wordpress.org/reference/functions/activate_plugin/). O incidente funcional é evidência recebida da bancada Google; não foi reproduzido durante este planejamento. Não há evidência de ocorrência em produção.

## P01 — Corrigir a ativação no executor de pacotes

Prioridade máxima. Alterar `PackageService.php` e `RecoveryEngine.php`, revisando seus pontos de integração com `Recovery.php` e `AtomicPluginUpgrader.php` somente onde necessário.

Persistir no diário assinado a intenção de ativação antes da troca. O worker deve usar essa intenção, o estado anterior e o estado relido para executar o ciclo correto. A escolha não dependerá de slug Google, versão do companheiro, existência de uma opção privada ou chamada de diagnóstico que inicialize o plugin.

| Situação no início da operação | Comportamento planejado |
|---|---|
| Plugin ausente; `activate:true` | Instalar e executar `activate_plugin` com hooks nativos habilitados no worker independente. |
| Plugin instalado e inativo; `activate:true` | Executar a ativação nativa com hooks, inclusive quando o ZIP já coincide com os arquivos presentes. |
| Plugin ausente ou inativo; `activate:false` ou omitido | Instalar/substituir sem ativar e sem executar hooks de ativação. |
| Plugin previamente ativo; pacote substituído | Preservar estado ativo e ciclo de atualização, com reativação silenciosa; não repetir o hook de instalação. `activate:false` não desativa um plugin que já estava ativo. |
| Mesmos arquivos e estado desejado já alcançado | Retornar sem alteração; não disparar hooks nem afirmar que houve nova inicialização. |
| Estado ativo ou arquivos mudam concorrentemente | Registrar conflito ou resultado inconclusivo; não desativar/reativar à força para produzir uma prova artificial. |

Manter a API nativa como responsável pela ativação. Não gravar diretamente `active_plugins`, disparar manualmente `do_action('activate_…')` ou chamar a classe de configuração Google como substituto desse ciclo. A restauração do estado anterior de ativação pelo mecanismo de recuperação é uma responsabilidade já existente e deve continuar delimitada à recuperação; não será usada para inicializar uma instalação nova.

Conservar os controles existentes: capacidades WordPress, autorização MCP, conexão vigente, revisão de política, token interno de uso único, diário assinado, locks, origem da chamada, hash da pós-imagem e isolamento do worker. `activate:false` continua sendo o padrão do upload.

## P02 — Comprovar o resultado e preservar a recuperação

O resultado deve distinguir a intenção registrada, o modo efetivamente executado, a conclusão observada da ativação, o estado ativo e a sonda posterior. Acrescentar apenas os campos necessários aos schemas e às respostas existentes; nomes e enums finais serão fechados com a implementação e cobertos nos testes de contrato.

Para declarar concluída uma instalação com ativação nativa, exigir: worker autorizado; chamada nativa concluída sem erro; evidência de conclusão do ciclo solicitado; plugin ativo; identidade/versão e arquivos correspondentes ao pacote; sonda em outra requisição aprovada. Manter `plugins/operation-status` observacional.

A verificação genérica comprova o ciclo e a saúde do pacote/site. Ela não certifica credenciais, tabelas privadas ou funcionamento remoto de qualquer plugin. As pós-condições específicas Google serão comprovadas nos ensaios de integração. O MCP não chamará `google/maintenance` automaticamente para transformar uma instalação incompleta em sucesso.

Quando o dono publicar um contrato optativo de prontidão, consumir somente a leitura documentada, sem reparo ou inicialização. Na ausência dele, informar que a prontidão específica não foi verificada; isso não impede a instalação independente nem converte `is_plugin_active()` em prova de negócio. O plano não presume que Meta/LinkedIn já publicaram esse contrato. Ensaiar cada pacote efetivo em C02/C03 quando disponível.

Timeout, interrupção ou saída inesperada depois do início do hook podem deixar efeitos persistidos. Por isso:

- `running` ou efeito desconhecido não autorizam repetir a ativação. A reconciliação relê o diário e verifica o estado sem disparar hooks novamente.
- A emissão de outra credencial interna só é permitida quando houver prova de que a tentativa anterior não entrou no efeito, mantendo o limite já usado para uma tentativa `pending` expirada.
- Repetição de uma operação concluída reutiliza seu recibo. Concorrência, revogação e alteração do pacote são recusadas antes de executar efeitos.
- Erros de transporte, HTTP 5xx, `WP_Error`, saída inesperada e falha do hook terão casos separados. Um status HTTP isolado não comprova que nenhum efeito de banco ocorreu.
- Pré-imagens, locks, retenção protetora e rollback de arquivos continuam disponíveis. Nenhum resultado de rollback poderá afirmar reversão de tabelas, opções ou efeitos externos produzidos pelo hook; conservar `database_effects_reversible:false`.

Diários correntes criados pela 0.21.0/0.21.1 continuam legíveis e conservam sua semântica. A ausência de novos campos não autoriza inferir que um hook deixou de executar, transformar uma operação encerrada em pendente ou reexecutá-la. Esse cuidado preserva operações atuais; não acrescenta importação ou migração de formatos históricos.

Na autoatualização MCP, o processo que iniciou a troca pode ter carregado o executor anterior. A prova da correção exigirá nova requisição após a atualização e confirmação de que a cópia independente contém o código novo. Não recarregar a mesma classe em um processo já inicializado nem usar alteração de header como prova de execução.

## P03 — Incorporar os contratos Google 0.8.5

| Área | Contrato entregue | Trabalho MCP |
|---|---|---|
| Catálogo | 3.0.0; 281 habilidades | Descoberta dinâmica, schemas reais e primeiros acessos HTTP/WP-CLI nas duas ordens de carregamento. A quantidade é uma conferência do pacote, não filtro de funcionamento. |
| Manutenção | `google/maintenance`, escrita administrativa, 2.0.0 | Validar autorização da bridge e do alvo separadamente, resultado estruturado, limites e guarda de recuperação. |
| Rotas retiradas | `google/migrate-storage`, `google/complete-transition` | Ausentes sem aliases. Grant específico para um nome retirado não autoriza a manutenção nova. Não converter permissões automaticamente. |
| Armazenamento | `google/storage-status.storage`, 2.0.0 | Preservar prontidão atual, tabelas e falhas; retirar da orientação corrente as fases históricas removidas. Leituras não iniciam manutenção. |
| Cron | Sem `legacy_last_pass` e `migration_pending` | Atualizar exemplos e consumidores documentais; manter estado atual, histórico, trabalho e manutenção distintos. Preservar hooks dos outros provedores. |
| Configuração/execução | 4.0.0 / 2.0.0 | Conservar mapa de serviços, merge/substituição, omissão/vazio/null, confirmação de redução, revisão/hash e resultados parciais. |
| SDK/Core | SDK 1.0.0; Core 1.32.0, contrato 7.0.0 | Revalidar conexão Google não padrão e concessão explícita pelo Core, sem fabricar usuário humano ou observação de cron. |

Se a descoberta e o transporte correntes já atendem aos contratos, a entrega dessa frente será documentação e testes. Não inserir condições Google no runtime sem uma falha concreta demonstrada.

As provas recebidas A13 sustentam descoberta/autorização nas duas ordens. As provas A14 sustentam instalação inicial em duas chamadas e atualização Google 0.8.4 → 0.8.5 com MCP 0.21.1. Elas não comprovam a instalação combinada corrigida, nem substituem a matriz conjunta da nova candidata MCP.

## P06 — Corrigir a negociação CIMD e o diagnóstico OAuth

Prioridade máxima, incluída pelo pedido de 15/10/2026. Alterar `core/includes/OAuth/ClientMetadata.php` e os pontos necessários de `TokenStore.php`, `AuthorizationEndpoint.php`, `TokenEndpoint.php`, `Responses.php` e `WellKnown.php`. Reutilizar os mecanismos de persistência e diagnóstico do MCP, sem nova ability pública de diagnóstico ou alteração de grants.

### Negociação e documentos anteriores

O conjunto efetivo de métodos do servidor continua sendo `{none}`. A descoberta, a resolução do cliente e o endpoint de token devem compartilhar essa mesma definição. Nos metadados do cliente, o campo plural é `token_endpoint_auth_methods_supported` e o singular é `token_endpoint_auth_method`. Não anunciar `private_key_jwt` nem introduzir validação JWT/JWKS nesta correção.

| Metadados do cliente | Resultado previsto |
|---|---|
| Lista plural válida contém `none`; singular é `private_key_jwt` | Aceitar o método `none`; a preferência singular não elimina a interseção válida. |
| Lista plural válida contém somente métodos não suportados | Recusar com causa específica de método incompatível. |
| Plural presente como `null`, string, objeto, lista vazia ou lista com itens não string/vazios | Recusar como documento inválido; não recorrer ao singular para contornar o erro. |
| Plural ausente; singular é `none` | Aceitar conforme o contrato de cliente público já suportado. |
| Plural ausente; singular válido declara outro método | Recusar como método incompatível. |
| Ambos ausentes | Manter `none` como política explícita do Fator3 MCP, documentada e testada. |
| Singular presente com tipo inválido, mesmo havendo lista | Recusar como metadado malformado; ausência e valor inválido são estados distintos. |

A lista válida é tratada como conjunto, sem preferência de ordem, coerção de tipos ou correção silenciosa dos valores. Valores string desconhecidos não concedem suporte: somente a interseção efetiva autoriza um método. O singular, quando válido e acompanhado do plural, funciona como preferência; não torna obrigatório um método fora da interseção.

O fallback para `none` com ambos ausentes preserva a política atual da 0.21.1. Será identificado como decisão local de interoperabilidade. A especificação CIMD consultada é um Internet-Draft, e sua discussão sobre omissão permanece aberta; não atribuir ao padrão uma obrigatoriedade universal desse fallback. Suporte a documentos OAuth anteriores válidos faz parte do protocolo corrente e não reintroduz suporte a pacotes ou migradores históricos.

### Endpoint de token e controles preservados

Persistir o método efetivamente aceito e verificar sua coerência no consumo do código e na renovação. Requisições que tentem autenticação por método não suportado, como assertion JWT ou segredo/Basic, não podem ser silenciosamente tratadas como autenticação `none` bem-sucedida. Definir erros OAuth apropriados sem divulgar os valores recebidos. Não buscar JWKS quando o método efetivo é `none`.

Preservar PKCE S256, uso único do código, correspondência exata de `client_id` e `redirect_uri`, recurso/audiência, issuer, site, escopos, consentimento e perfil. Manter a coerência do `iss` nas respostas de autorização com o anúncio atual. Nenhum erro anterior à validação do redirect poderá redirecionar para uma URI não validada.

Conservar HTTPS, TLS verificado, identidade exata do documento, proteção SSRF, bloqueio de endereços privados, recusa de redirecionamento na busca CIMD, limites de tamanho/tempo, tipo de conteúdo e validações de JSON. A regra deve valer para qualquer cliente compatível, sem exceção por domínio ChatGPT, URL fixa, query especial ou alteração na allowlist de redirects.

### Diagnóstico correlacionável

Substituir a perda de causa por um resultado interno tipado, ou mecanismo equivalente que preserve cada falha até a resposta. Os nomes finais serão definidos na implementação; as categorias obrigatórias são:

| Categoria | Exemplos a distinguir |
|---|---|
| Cliente inexistente/indisponível | Identificador DCR não encontrado; estado revogado/expirado em motivo interno próprio. |
| Busca de metadados falhou | Timeout, transporte ou status HTTP inesperado. |
| Documento inválido/inseguro | JSON/tipos inválidos, identidade divergente, URL insegura, redirect inválido, tamanho excedido ou lista malformada. |
| Método incompatível | Documento válido sem interseção com os métodos efetivamente aceitos. |
| Persistência falhou | Leitura, gravação, capacidade esgotada ou confirmação de armazenamento indisponível. |

Gerar identificador opaco de diagnóstico e disponibilizá-lo na resposta/página de erro para correlação com registro restrito. Registrar apenas data, etapa, categoria, versão, estado de cache e identificador derivado do cliente quando necessário. Não registrar tokens, refresh tokens, códigos, verifier/challenge, cookies, cabeçalho Authorization, segredos, assertions, `state`, corpo integral do documento ou URL completa da autorização. Sanitizar também exceções e mensagens do transporte.

O registro precisa funcionar antes de login/consentimento, ter limite de volume/retenção e não expor consulta pública dos detalhes. Falha do próprio mecanismo de diagnóstico não pode transformar rejeição em sucesso nem ocultar o identificador já apresentado. Os testes usarão marcadores sintéticos para verificar ausência desses dados nos logs e nas respostas.

### Cache, persistência e conexões existentes

O código atual mantém metadados em `oauth-clients`, com TTL padrão de 300 segundos, teto de 3.600 segundos e revalidação para `no-cache`/`no-store`. Preservar esses limites e testar acerto de cache, expiração, falha de atualização e persistência mínima de `no-store`. Documento expirado não deve ser reutilizado como fallback de uma busca reprovada para autorizar uma nova conexão.

A correção não exige expurgo de clientes, grants ou tokens. Preservar clientes DCR e CIMD válidos já armazenados; entradas atuais `none` permanecem reconhecidas. Se o cache receber campos adicionais, sua ausência em registros válidos da base aceita não autoriza revogação ou mudança de identidade. Não acrescentar HTTP dentro da transação de troca/renovação; a autorização de novas concessões e a emissão baseada em concessões existentes têm percursos distintos.

A rejeição por método no resolvedor atual ocorre antes da gravação desse novo documento. Uma conexão que falhou nessa etapa deverá repetir a autorização após a correção; não há grant concluído a recuperar desse percurso. Conexões DCR existentes não precisam ser recriadas por esta mudança. Expiração, revogação, perda de concessão ou mudança legítima de identidade continuam podendo exigir nova autorização, com motivo explícito.

### Homologação com ChatGPT

Automação local deve percorrer OAuth e MCP completos com cliente CIMD controlado. Além disso, uma nova conexão real do ChatGPT deve completar login WordPress, consentimento, troca do código, `initialize`, listagem de ferramentas e uma chamada de leitura. Registrar horário, ambiente, versão/hash, modo CIMD e resultados de cada etapa, sem guardar credenciais ou códigos.

O endpoint afetado informado é `https://www.korvena.net.br/wp-json/mcp/wp-mcp-fator3`. Conferir a versão instalada antes de qualquer aplicação. O pedido relata incompatibilidade no teste 0.21.0 e no fonte 0.21.1; a versão Korvena não será inferida desses dados. Usar primeiro o ambiente de teste para a candidata e preservar a conexão DCR já existente.

A etapa real exige um endpoint acessível ao ChatGPT com a candidata e participação do titular no login/consentimento. O plano não instala nada nem autoriza uma implantação silenciosa na Korvena. B22 permanecerá pendente se essa execução não estiver disponível; resultados automatizados não o substituem. O pacote poderá ser gerado como candidato, mas a correção CIMD não será declarada integralmente homologada antes desse aceite.

## P07 — Publicar a distribuição optativa de pacotes

P1, atende MCP-02. Entregar a fachada pública proposta `package-distribution/1.0.0`, seus schemas, assinaturas PHP, exemplos e fixtures. Ela deve informar o dono efetivo da atualização e permitir consumir o canal selecionado sem conhecer `f3_mcp_update_channels`, chamar métodos internos de `UpdateChannel` ou remover callbacks MCP. Não criar uma ability remota de registro de origens nem expor segredos de configuração.

| Superfície lógica | Contrato a fechar na implementação |
|---|---|
| Registro de pacote | Opt-in explícito com provedor, slug, arquivo principal e versão/capacidade do contrato. Validar identidade, colisões e associação do pacote ao provedor. Preservar os três registros atuais. Os slugs/entrypoints finais Meta/LinkedIn serão fornecidos pelos produtores; não deduzi-los dos prefixos de abilities. |
| Consulta local | Devolver disponibilidade, suporte, origem configurada/efetiva, dono e revisão opaca. Sem HTTP, download, escrita reparadora ou inicialização do parceiro. Distinguir `unavailable`, `unsupported`, não configurado e `conflict`. |
| Consulta de manifesto | Ação explícita, separada da consulta local; usa somente a origem selecionada e seus limites. Retorna identidade, versão, procedência, digest e estado de cache. |
| Consumo/execução | Usar um único executor do canal selecionado, com autorização pertinente, seleção/revisão fixadas e conferidas antes do efeito. Reutilizar verificações do executor de pacotes, diário e recuperação quando aplicáveis. |

O registro é cooperação pública entre plugins PHP confiáveis, não uma autorização derivada de argumentos do cliente ou de metadados de um ZIP. Registro não concede capacidades WordPress, grants MCP ou confiança em hosts. Um pacote ausente do registro permanece fora desse canal; a instalação manual autorizada continua disponível.

Preservar a precedência do canal MCP quando configurado. Formalizar a seleção para os casos canal MCP apenas, origem própria apenas, ambos e nenhum. A origem efetiva é única; falha, expiração de cache ou indisponibilidade dela não troca silenciosamente para outra. Revisão alterada durante manifesto/download/aplicação produz conflito e exige nova seleção/prévia, sem aplicar bytes de outra oferta. Invalidar o cache pertinente à seleção alterada; uma resposta de cache não pode ocultar a troca de dono.

O próprio MCP decide a incidência de seus filtros **antes** de buscar manifesto ou realizar rede. Para origem própria selecionada, pacote não administrado ou fluxo manual, não impor manifesto MCP nem obrigar o consumidor a remover o filtro. ZIP manual conserva validação de identidade, hash, autorização e proteções de autoatualização; essa separação não cria desvio do executor seguro. Manter HTTPS público, TLS, controles SSRF, limites, recusa de redirects e procedência verificada do canal atual.

PHP e WordPress podem ter requisitos nativos do pacote. Versões, presença ou ordem de acompanhantes permanecem informações de capacidade/homologação e não bloqueiam instalação. Com MCP inativo, a integração de distribuição MCP fica indisponível; o companheiro continua com painel, serviços e instalação manual. Não selecionar automaticamente outra origem para compensar a ausência.

**Coordenação:** GOOGLE-02 pertence à próxima candidata Google. Testar a fachada primeiro com consumidor fixture e manter regressão Google 0.8.5 original. Não retirar nesta release pontos ainda consumidos pela base 0.8.5 sem preservar seu comportamento; a retirada do acesso privado pelo Google é comprovada somente por C01. Isso preserva a base atual, sem reintroduzir migradores históricos. Meta/LinkedIn poderão aderir separadamente. A entrega MCP pode publicar o contrato e registrar a adoção real como pendente.

## P08 — Preparar provedores sociais e provar o transporte

P1, atende MCP-SOC-01 e a ampliação de MCP-04. Reutilizar o registro público de extensões e a contribuição ao servidor. Os identificadores propostos são `meta`/`meta/*` e `linkedin`/`linkedin/*`; confirmar exclusividade com `f3base/*`, `google/*` e demais provedores registrados. Não criar aliases, transferir proprietário ou presumir capacidade pelo nome do pacote.

Entregar guia e fixtures com descritor de provedor, versão/schema, contrato, efeito, sensibilidade e capacidade exigida, além de schemas de entrada/saída. Os nomes concretos de abilities pertencem aos produtores e precisam de confirmação no primeiro marco de contrato. Campos novos que alterem admissão devem anunciar capacidade/versão própria, sem mudar silenciosamente `policy_contract:1` ou `server-integration/1.0.0`. Descoberta comprova registro; não comprova credencial configurada, produto aprovado, acesso ao ativo ou consulta real.

### Admissão e autorização por domínio

| Superfície | Exigência |
|---|---|
| Relatórios analíticos | Perfil/capacidade de leitura, ability permitida e autorização do provedor para conexão e ativos selecionados. |
| Respostas pessoais Lead Sync | Concessão específica para respostas, contas e formulários; grant de relatório é insuficiente, inclusive no perfil MCP de leitura. Seleção vazia não autoriza todos os formulários. |
| Conexões/credenciais | Alteração exige autorização de escrita e os controles nativos. Cadastro privado de token no painel do provedor permanece o padrão; não criar armazenamento ou emissão de tokens sociais no MCP. |
| Jobs, assinaturas, importações e exportações persistentes | Classificar pelo efeito: criar job, assinatura ou arquivo é escrita; observar resultado exige autorização atual e vínculo ao titular/consumidor. Consulta de estado não inicia trabalho. |

O descritor não concede acesso sozinho. Cada chamada, página, partição, consulta de job e leitura de arquivo deve revalidar contexto autenticado, perfil, ability e autorização de domínio. O provedor conserva vínculo a consumidor, conexão, ativos, seleção e revisão de credencial/política. Não aceitar ator fornecido como argumento livre, nem permitir que um cursor ou ID de job amplie o grant ou revele resultado de outro usuário. Revogação ou mudança de conta entre páginas interrompe a continuação; o transporte não reinicia a coleta automaticamente.

Consultas analíticas LinkedIn podem ser leitura. As operações existentes de escrita do Core, inclusive suas simulações, mantêm os gates atuais. `idempotency_key` MCP não preenche revisão, confirmação ou chave nativa do Core. Atualizações não ampliam concessões já salvas. Credenciais não aparecem em catálogo, exemplos, logs, diagnósticos ou respostas.

Abilities diretas não dependem de MCP-03. Na 0.22.0, `RootToolContext` admite somente bridges validadas pelo registro de P09, em entrada raiz autenticada no servidor próprio. Outra porta MCP, categoria, metadado falso, argumento ou executor aninhado não fabrica contexto nem troca o provedor autorizado. A transição Google preserva nomes, schemas, grants e autorização de domínio e precisa passar pelos aceites de equivalência antes de retirar a admissão nominal atual.

A callback pública LinkedIn do Core continua protegida pelo protocolo próprio do fornecedor; não passa a exigir login MCP. Pausa ou ausência de um provedor afeta apenas suas funções. Em nova requisição, retirar sua exposição ou retornar indisponibilidade específica, mantendo administração WordPress, outros provedores e seus trabalhos independentes.

### Fidelidade dos resultados e limites

Preservar contratos nativos Google/Core e o envelope proposto `social-reporting/1.0.0` dos novos provedores. Não obrigar Google/Core a adotar o envelope social. Os testes devem comparar entrada e saída estruturada e distinguir:

- Tipos, objetos/listas, zero, `null`, ausência de campo, consulta vazia, indisponibilidade e erro de autorização.
- Cursor, `next_offset`/`next_start_row`, total conhecido/desconhecido, partições restantes, limites e ponto de parada. Não fabricar cursor para uma origem que utiliza partições.
- `complete`, `all_rows_guaranteed`, intervalo solicitado/efetivo, lacunas, páginas e cobertura. Terminar o plano executável não prova que a origem forneceu todas as linhas.
- Fuso, moeda, versão API, origem, instante, semântica temporal, avisos, supressão/limiares e falhas por conta/período. Não somar taxas, métricas únicas ou moedas distintas.
- Erros nativos, `persisted`, `changed`, resultado parcial/desconhecido e recibos de jobs. Sucesso do transporte não é prova de sucesso integral da operação de negócio.

O MCP não busca páginas adicionais, calcula métricas, reduz períodos, faz retentativa remota automática nem cria exportação oculta. Quando um resultado exceder limite do transporte, usar somente continuação ou referência privada que o provedor tenha disponibilizado sob autorização. Se não houver mecanismo, retornar limite explícito, sem cortar linhas e afirmar completude, inventar cursor ou repetir uma operação de efeito incerto. Os mecanismos de leitura de arquivo devem preservar autorização e não publicar dados pessoais por URL irrestrita.

O caminho padrão de `ToolsHandler` já preserva o JSON estruturado na inspeção realizada. A frente começa pelos testes; mudanças no transporte serão limitadas às falhas comprovadas. Incluir a regressão T10: mutação de conteúdo pelo MCP seguida de observação pública dos efeitos SEO/llms/cache/noindex previstos pelo Core, usando suas APIs e sem ler opções privadas como substituto da prova.

**Entregas e fronteiras:** guia corrente, fixtures reproduzíveis, catálogo efetivo e matriz de autorização/transporte. Coleta, tokens, quotas, algoritmos analíticos, ingestão comercial, validação criptográfica social e Sheets continuam nos respectivos donos. Testar Meta e LinkedIn separadamente; a disponibilidade ou aprovação externa de um não bloqueia o outro nem a release MCP.

## P09 — Registro público e admissão de bridges — MCP-03

**P1 obrigatório na 0.22.0**, alinhado a G08/GOOGLE-04 do plano Google 0.8.6. Publicar um registro optativo de executores por provedor e usar esse registro como fonte única para descoberta/admissão. O MCP pode entregar e provar o produtor antes do consumidor Google 0.8.6; a falta desse candidato não autoriza retirar P09 ou declarar homologada a adoção GOOGLE-04.

### Contrato público proposto

Identificador de planejamento: **`executor-registration/1.0.0`**, capacidade adicional ao SDK `server-integration/1.0.0` e à política 1. É uma interface a implementar, com assinaturas PHP concretas, schemas JSON completos, exemplos e fixtures no pacote. O nome final deve ser fechado e comunicado no guia do produtor antes da implementação do consumidor; qualquer ajuste posterior precisa aparecer nos documentos de ambos.

| Superfície | Requisito |
|---|---|
| Descoberta/capacidade | Leitura local de contrato, métodos, revisão do schema e disponibilidade. Sem HTTP, inicialização recursiva da Abilities API ou concessão de acesso. |
| Registro optativo | Receber declaração de plugin PHP confiável associado a provedor já registrado. Descritor com contrato, nome exato da ability, provedor, modo `read`/`write` e restrição explícita dos alvos. Não receber callback arbitrário ou ator por argumento de ferramenta MCP. |
| Validação | Conferir ability existente, pública, executora, aderente à política e pertencente ao provedor declarado; modo e anotações devem corresponder. Alvos são nomes ou prefixos expressamente registrados pelo mesmo provedor, intersectados com o catálogo e as permissões efetivas. Lista vazia autoriza zero; ausência de restrição é inválida. |
| Estado/diagnóstico | Informar admissão ou motivo sanitizado: produtor ausente, contrato sem suporte, descritor inválido, conflito ou alvo proibido. Sem expor conexão, credencial, argumentos sensíveis ou reparar registro. |
| Exposição no servidor | Derivar a inclusão das ferramentas do conjunto validado, preservando identidade/rotas e metatools. Deduplicar declaração/contribuição equivalente; conflitos não escolhem automaticamente a variante mais permissiva. |

A declaração somente será efetiva depois do registro do provedor e da ability. Definir um ponto de finalização público coerente com o ciclo Abilities API, sem forçar sua execução durante consulta precoce de endpoints. Testar ordem de carga, primeira entrada REST/CLI e reentrância. Novo request recompõe o registro a partir dos provedores ativos; não persistir um privilégio porque o plugin esteve ativo anteriormente.

Registro é cooperação entre plugins PHP instalados e confiáveis. Ele não isola PHP malicioso e não substitui a autorização da conexão ou do domínio. Nem `meta.fator3.executes_ability`, categoria Google, nome parecido, flags do cliente ou registro em outro servidor concedem admissão isoladamente.

### Autoridade da chamada e do alvo

Revisar `ExtensionContract`, `ServerContract`, `RootToolContext`, `ConnectionContext`, `OwnedAbility` e os pontos necessários do handler/executor, limitando mudanças ao percurso demonstrado pelos testes.

1. Abrir contexto somente para chamada raiz de ferramenta registrada/admitida na porta Fator3, autenticada por OAuth ou senha de aplicação válida. Vincular o contexto interno ao servidor, bridge, usuário, conexão e política vigente; fechá-lo inclusive em exceção. Argumentos não criam ou reutilizam esse contexto.
2. Autorizar a bridge conforme o perfil e as capacidades WordPress. Perfil leitura recusa bridge/efeito de escrita, inclusive simulação. Personalizado exige a bridge e o alvo final.
3. Resolver e validar o alvo real antes de seu efeito: pertence ao provedor da bridge, está dentro da restrição declarada, tem efeito permitido e passa pela autorização nativa. Proibir qualquer alvo executor, inclusive a própria bridge, outra bridge e metatools de execução.
4. Manter no Google autorização de recurso, serviço, conexão, credencial, revisão/confirmação e idempotência. O registro MCP não amplia seu domínio. As bridges Google recusam alvos Core, Meta e LinkedIn.
5. Revalidar autorização em cada chamada, continuação e consulta de resultado. Remoção de provedor, revogação ou mudança de política interrompe o acesso; exceção/falha de validação não ativa um caminho alternativo permissivo.

A generalização é do registro por provedor. A 0.22.0 não cria uma nova ferramenta universal que possa despachar para qualquer domínio. Meta/LinkedIn mantêm abilities diretas nesta primeira integração.

### Transição sem regressão na base aceita

Preservar `google/mcp-read`, `google/mcp-write`, schemas, nomes de alvos e grants. A admissão e a composição do servidor deixam de depender dos condicionais nominais atuais de `google_bridge()`; ambos passam pelo mesmo registro validado.

O Google 0.8.5 entregue ainda não declara o contrato novo. Para preservar a base da atualização, preparar uma adaptação delimitada que transforme seus metadados públicos já verificados em descritores equivalentes. Essa adaptação apenas alimenta o registro comum, sem caminho paralelo de autorização, acesso a armazenamento privado, alias ou importação histórica. Os critérios de reconhecimento correspondem à identidade/aderência atuais; não basta o slug. Sua equivalência será comprovada com o instalador original e com as negativas de B32.

Quando o Google declarar o contrato público, usar sua declaração válida uma única vez e dispensar a adaptação para essas ferramentas. Declaração explícita inválida/conflitante não recorre à adaptação para contornar a recusa. Se houver declaração e contribuição equivalentes ao servidor, não duplicar ferramentas nem execução. Testar MCP→Google e Google→MCP, com requisição nova após cada troca, preservando a instalação independente.

Retirar a exceção nominal de autorização somente depois de B30–B34 aprovados. **Manter apenas a exceção antiga não satisfaz MCP-03**: a candidata precisa admitir também um provedor fixture independente pelo contrato público e aplicar os mesmos controles. Se essa implementação não passar, a release permanece candidata pendente de MCP-03; o item não volta automaticamente ao backlog.

### Coordenação com o Google 0.8.6

Entregar ao consumidor o contrato/capacidade, assinaturas, schemas, fixtures e provas do produtor 0.22.0. O encaminhamento Google que cita MCP 0.21.2/revisão 1 precisa passar a referenciar este plano e o contrato efetivo, preservando detecção de capacidade em vez de comparação numérica.

GOOGLE-04/G08 e o aceite **C16 do plano Google** continuam incluídos naquela release. C05 deste plano mede a integração real com o candidato Google; os IDs de aceite pertencem a documentos diferentes. A conclusão MCP de B30–B34 e a conclusão conjunta GOOGLE-04/C16 terão registros separados. A ausência de um pacote não bloqueia instalação, ativação, administração ou outras operações de nenhum plugin.

## P10 — Transporte do contrato público Core 1.33.0

Incorporar a especificação recebida `contratos-publicos-core-1.33.0(1).md`, ainda proposta. Produtor `base-site-core-fator3`; contrato `site-measurement-context/1.0.0`; capacidades `measurement.context.read` e `measurement.events.read`. A configuração Core 7.1.0 proposta, o contrato Core 7.0.0 entregue e o SDK GSC `search-console-reader/1.0.0` continuam identificados separadamente.

O Core prevê a fachada PHP `F3Base_Medicao_Contexto::capabilities/snapshot/events`. Essa cooperação local, inclusive em cron, não exige contexto MCP nem concede acesso a contatos/APIs. O consumidor Google detectará o produtor depois de concluídos os callbacks de registro; o MCP não carrega arquivos/classes privados Core, fabrica usuário ou substitui o adaptador Google.

Para o MCP, a fronteira são as abilities administrativas propostas `f3base/medicao-contexto-ler` e `f3base/medicao-eventos-ler`, quando efetivamente registradas. Usar descoberta dinâmica, schemas reais, `manage_options`, perfil e concessão pertinente. São leituras locais sem reparo/rede; leitura de configuração não autoriza alteração de credencial, conta remota, binding ou política.

Preservar integralmente no transporte:

- Envelope `ok`, `code`, `contract`, `provider`, `data` e mensagem sanitizada. Falha conserva `data:null`; `unreadable`, `unsupported`, `unavailable` e `revision_conflict` não viram slot vazio ou sucesso.
- Valores configurados/efetivos, ausência física, strings vazias e estados `configured`/`empty`/`disabled`/`invalid`; seis slots declarados, inclusive Clarity, sem expor as opções completas.
- Procedência, revisões opacas, `scope:site_request`, `runtime_verified:false` e `remote_access_verified:false`. Configuração declarada não comprova emissão no navegador ou recebimento remoto; diferença entre físico/efetivo não prova filtro sem a evidência do produtor.
- Paginação `limit`/`offset`/`expected_revision`, `next_offset` inteiro ou `null`, total e `complete` do catálogo. Página posterior exige a revisão prevista; conflito recusa a página e não dispara repetição automática.
- Parâmetros e regras declarativas do catálogo de eventos, sem dados de visitantes, respostas de leads ou segredos. Sanitização e schemas fechados pertencem ao produtor; provar a fronteira com fixtures e com seu candidato real quando disponível.

B35 comprova a preparação MCP com fixtures, incluindo gates administrativos e fidelidade do envelope. C06 prova as abilities do Core efetivo. Os aceites A16–A20 e I01 do documento Core permanecem sob responsabilidade de seus donos; transportar o resultado não certifica que o produtor resolveu a fotografia, a concorrência, o tracking ou a integração Google. A ausência do Core 1.33.0 não impede entregar os componentes MCP implementados.

## P04 — Validação da candidata

Nos testes automatizados, usar bancada descartável single-site, APIs externas bloqueadas ou simuladas, instaladores originais e requisições autenticadas reais. B22 usa uma conexão efetiva ChatGPT com endpoint de homologação e terá evidência separada. Reutilizar os casos úteis existentes e acrescentar os testes abaixo. As letras B são identificadores internos deste plano. B23–B35 usam contratos/fixtures e pacotes disponíveis; C01–C06 separam integrações que exigem candidatos ou acesso externo adicionais. B30–B34 são obrigatórios para concluir MCP-03, independentemente da disponibilidade Google 0.8.6. Nenhum aceite vira bloqueio de instalação em runtime.

| Aceite | Cenário | Prova necessária |
|---|---|---|
| B01 | Reprodução controlada na 0.21.1 | Plugin mínimo com contador de hook e instalação Google realmente nova demonstram a diferença entre fluxo silencioso e fluxo separado. Manter a prova de referência separada da candidata. |
| B02 | Instalação combinada corrigida | `upload-base64`, hash, slug, `overwrite:false`, `activate:true`: hook executado uma vez por tentativa comprovadamente concluída, estado ativo, diário concluído e sonda aprovada. Em requisição nova, Google apresenta canal/armazenamento prontos e schema disponível. Ler o estado antes de executar manutenção. |
| B03 | Modos de ativação | Instalação inativa, ativação explícita posterior, pacote existente inativo, ZIP idêntico, atualização ativa e repetição sem alteração obedecem à tabela P01. Contador prova que atualização ativa não repetiu o hook inicial. Cobrir os caminhos compartilhados de upload e update. |
| B04 | Interrupção e reconciliação | Timeout antes/depois de entrar no efeito, hook lento, exceção/fatal, saída inesperada, erro nativo e resposta perdida não viram sucesso sem prova. Reconciliação e replay não duplicam hooks cujo efeito é incerto. |
| B05 | Autorização e concorrência | Token interno inválido/expirado/reutilizado, política revogada ou alterada, ausência de capacidade, worker concorrente, estado ativo divergente e hash alterado são recusados de forma verificável. |
| B06 | Atualização do executor | Atualizar diretamente MCP 0.21.0 → 0.22.0 e 0.21.1 → 0.22.0; nova requisição executa a sentinela atualizada. Exercitar workers PHP-FPM aquecidos com OPcache e preservar o canal autenticado. |
| B07 | Recuperação e estado corrente | Pré-imagem identificada, rollback em `dry_run`, retenção de referências protegidas e operações pendentes válidas preservadas. Em fixture descartável, falha de ativação comprova restauração de arquivos/estado anterior sem alegar reversão do banco. |
| B08 | Catálogo e autorização Google | Novo nome descoberto/executável com autorização apropriada; nomes antigos ausentes; grant antigo insuficiente; bridge e alvo exigidos. `maintenance` continua escrita, com guarda e resultados parciais preservados. |
| B09 | Primeiro acesso e carregamento | MCP→Core→Google e Google→Core→MCP, sem aquecimento manual: primeira chamada HTTP e primeiro processo WP-CLI descobrem os contratos. Manutenção e cron de um provedor não alteram os demais. |
| B10 | Configuração e SDK | Regressão dirigida de configuração 4.0.0, confirmação de redução, conexão não padrão, restrições de serviço, grant explícito Core e preservação de erros/resultados desconhecidos pelo ToolsHandler. |
| B11 | Atualização conjunta | Duas sequências da matriz abaixo, hash e nova requisição a cada troca; preservar credenciais cifradas, conexões, serviços, token MCP válido, job concluído, agenda pausada e auditoria. Job concluído não é reenviado. |
| B12 | Instalação independente | MCP em WordPress limpo, companheiros ausentes/inativos e variação controlada de seus metadados não bloqueiam instalação ou bootstrap. Operação dependente sem capacidade retorna diagnóstico específico. |
| B13 | Estado da base aceita | Atualização direta preserva políticas/revogações, backups, recibos e operações correntes. Regressões de duas fases e idempotência serão dirigidas aos módulos compartilhados efetivamente alterados; não reabrir funcionalidades já entregues. |
| B14 | Empacotamento e evidência | Lint dos PHP alterados, schemas/exemplos coerentes, allowlist do instalador, guia incorporado, versões/hash consistentes e relatório vinculado aos bytes testados. Uma mudança de runtime após ensaio exige nova validação do percurso afetado. |
| B15 | Negociação CIMD | Matriz P06 completa: documento ChatGPT com singular `private_key_jwt` e plural contendo `none`; somente métodos não suportados; plural malformado/vazio; singular anterior válido; ambos ausentes. Casos aceitos persistem o método efetivo `none`. |
| B16 | Metadados e identidade | Recusar identidade divergente, URL insegura/privada, redirecionamento HTTP da busca, JSON/tipos inválidos, resposta excessiva e redirect URI inválida. As proteções não podem ser contornadas pelo campo plural. |
| B17 | Coerência no token | Descoberta anuncia somente o suporte real; código e refresh respeitam o método efetivo; método não suportado não vira `none` silenciosamente. PKCE, issuer, recurso, site, consentimento, escopos, replay e redirect continuam validados. Nenhuma busca JWKS ou HTTP na transação. |
| B18 | Diagnóstico sem segredos | Diferenciar todas as categorias P06, inclusive exceção de persistência e falha do logger. Correlacionar o identificador apresentado com registro restrito. Marcadores sintéticos comprovam que dados sensíveis e URL completa da autorização não vazam. |
| B19 | Cache CIMD | Cache válido, expiração, TTL máximo, `no-cache`, `no-store`, indisponibilidade de busca e gravação reprovada. Revalidação não promove documento inválido nem apaga concessões/clientes DCR. |
| B20 | DCR e estado anterior | Novo registro DCR, conexão DCR já existente, token válido e refresh emitidos na base aceita continuam funcionando após atualização direta. Preservar clientes, grants e perfis; expirados/revogados continuam recusados, com rotação e detecção de reuso mantidas. |
| B21 | Fluxo CIMD automatizado completo | Cliente controlado atravessa login/consentimento, código com S256, token, `initialize`, listagem e leitura MCP; incluir refresh e negativas. HTTP 201 no DCR ou redirecionamento ao login isolados não satisfazem este aceite. |
| B22 | Nova conexão real ChatGPT | Repetir o percurso completo especificado em P06 com ChatGPT, candidata identificada e endpoint real de homologação. Prova separada das fixtures, com cada etapa e resultado; ausência de execução fica explícita e impede declarar homologação integral CIMD. |
| B23 | Contrato público de distribuição | Consumidor fixture usa somente a fachada. Registro preserva os três pacotes atuais, admite pacote opt-in válido e recusa colisão/identidade falsa. Consulta local não faz HTTP, download ou inicialização; ausência e contrato sem suporte têm estados distintos. |
| B24 | Seleção e segurança do canal | Canal MCP apenas, origem própria apenas, ambos, nenhum, ZIP manual e MCP inativo. Provar um executor, filtro aplicado apenas quando pertinente, hash/origem corretos, revisão alterada durante operação recusada e ausência de fallback silencioso. Regressão com Google 0.8.5 original. Mapeia T09. |
| B25 | Registro social e primeiro acesso | Fixtures independentes Meta/LinkedIn, prefixos exclusivos, schemas e metadados válidos; recusar colisão/descritor falso. Testar cada provedor isoladamente com MCP, ordens invertidas e primeira requisição REST/CLI. Não exigir bridge genérica. Mapeia S01. |
| B26 | Grants, efeitos e continuações | Perfis leitura/escrita/Personalizado; relatório sem grant pessoal, ativo sem concessão, seleção vazia, job/arquivo de outro usuário, revogação entre páginas e troca de conta. Escrita/simulação preserva gates nativos; executor aninhado, outra porta e consumidor falso recusados. Marcadores secretos ausentes de saídas/logs. Mapeia S04. |
| B27 | Envelopes e tamanho | Comparação estruturada de tipos, nulos, zeros, erros, paginação/partições, cobertura, qualidade e parcialidade, inclusive jobs. `complete:true` não altera `all_rows_guaranteed:false`/desconhecido. Resultado grande não é cortado como sucesso integral; ausência de continuação retorna limite explícito sem efeito adicional. Mapeia T14/S03. |
| B28 | Ausência, pausa e atualização independentes | Desativar/remover cada provedor, pausar um canal e atualizar em nova requisição; somente as funções dependentes ficam indisponíveis. Administração MCP e demais provedores preservam estado. Não ler/mutar tokens, jobs ou callbacks alheios para reparar disponibilidade. Mapeia S06. |
| B29 | Efeito público SEO após mutação | Conteúdo de fixture alterado por rota MCP autorizada; reler efeitos previstos no contrato Core para llms/cache/noindex, sem reparo oculto. Registrar quais efeitos foram observados e erros nativos. Mapeia T10 e preserva os limites de rollback já documentados. |
| B30 | Contrato de executores e admissão genérica | Publicar capacidade, assinaturas e schemas; admitir bridges de provedor fixture independente. Recusar provedor/ability ausentes, identidade/modo incoerentes, metadados falsos e restrições de alvo inválidas. Lista vazia não autoriza alvos. Somente registro validado compõe o servidor. |
| B31 | Autoridade raiz, perfil e alvo | REST autenticado real, leitura/escrita/Personalizado, grant só da bridge ou só do alvo, simulação de escrita, recurso/serviço negado e alvos fora do provedor. Executor aninhado, próprio executor, outra porta, contexto forjado ou alterado são recusados antes do efeito. Mapeia T04/S04 e a fronteira MCP do C16 Google. |
| B32 | Equivalência e transição Google | Google 0.8.5 original funciona pelo registro comum com nomes/schemas/grants atuais. Fixture do consumidor novo usa declaração pública. Deduplicar declaração/contribuição equivalente; declaração explícita inválida não ativa adaptação alternativa. Não ampliar alvos nem conceder acesso por slug/categoria. |
| B33 | Ciclo do registro e independência | MCP sem Google; provedor fixture sozinho; dois provedores em ordens invertidas; primeira REST/CLI sem aquecimento; reentrância e exceção de registro. Diagnóstico não inicializa a Abilities API nem publica servidor parcial. Ausência de contrato não bloqueia WordPress ou outros provedores. |
| B34 | Revogação, remoção e contexto encerrado | Revogar grant/conexão, mudar política ou remover provedor entre chamadas/continuações; recusar acesso subsequente. Exceção na bridge fecha contexto e não autoriza a próxima chamada. Envelopes parciais/erros continuam íntegros. Provar que a autorização não usa a antiga exceção nominal. |
| B35 | Contrato de medição Core no transporte | Fixtures do descritor e das duas leituras administrativas, schemas/envelopes reais propostos. `manage_options` e grants insuficientes recusados; preservar revisões, `data:null`, estados, procedência, flags de verificação falsas e paginação com revisão. Leitura não escreve/repara; segredos/dados pessoais não pertencem às respostas. |

### Integrações condicionadas e resultado por responsável

| Aceite | Quando executar | Prova e limite da conclusão |
|---|---|---|
| C01 | Candidata Google com GOOGLE-02 disponível | Consumo real de `package-distribution/1.0.0`, sem ler option privada, chamar implementação interna ou remover filtros MCP. Reexecutar os cenários afetados de B24. B23/B24 com fixture não encerram GOOGLE-02. |
| C02 | Candidata Fator3 Meta disponível | Instalação nova/atualização, prontidão do dono e S01/S03/S04/S06 com pacote real identificado. Consulta externa autorizada, se disponível, tem prova própria; fixture não certifica token/app/Instagram. |
| C03 | Candidata Fator3 LinkedIn disponível | Mesma fronteira MCP de C02, mais separação analítica/PII e callback Core preservada. Não declarar certificada ingestão comercial S05 ou aprovação Lead Sync por ter transportado uma resposta. |
| C04 | Ambiente Google autorizado com acesso real disponível | Consulta GA4/GSC curta e somente de leitura para complementar T14, com versão/hash, seleção e metadados observados. Não exige Porter e não homologa conversões positivas, alto volume, Google Ads ou todas as combinações. |
| C05 | Candidata Google 0.8.6 com GOOGLE-04 disponível | Declaração real das duas bridges pelo contrato público, capacidade detectada, equivalência e ordens de atualização; nomes/schemas/grants preservados. Mapeia G08/GOOGLE-04 e C16 do plano Google. Conclusão deste consumidor é separada da prova do produtor em B30–B34. |
| C06 | Candidata Core 1.33.0 com CORE-01/02 disponível | Descoberta e execução autenticada das leituras de medição com schemas finais, estados e paginação do produtor real. Não substitui A16–A20/I01 do Core nem certifica emissão no navegador ou recebimento remoto. |

Registrar C01–C06 como validado, falhou, pendente ou não aplicável, sempre com motivo. Ausência de candidato/credencial mantém pendente a integração correspondente e não bloqueia a liberação dos componentes MCP comprovados. Isso não dispensa B30–B34 nem permite declarar GOOGLE-04/C16 concluídos com fixtures. Falha concreta no MCP encontrada nesses ensaios deve ser corrigida ou retirar a alegação de suporte afetada. B22 conserva seu critério próprio: sem execução real ChatGPT não há homologação integral CIMD.

### Matriz mínima de instalação e atualização

| Linha | Origem | Sequência e resultado esperado |
|---|---|---|
| M01 | WordPress limpo | Instalação/ativação nativa MCP candidata sem companheiros; depois instalação nova Google 0.8.5 pelo upload combinado corrigido. |
| M02 | MCP 0.21.0 + Google 0.8.4 inicializado + Core 1.32.0 | Atualizar MCP → 0.22.0, fazer nova requisição, atualizar Google → 0.8.5 e reler estado final. |
| M03 | Mesma origem de M02 | Atualizar Google → 0.8.5, fazer nova requisição, atualizar MCP → 0.22.0 e reler estado final. |
| M04 | MCP 0.21.1 + Google 0.8.5 + Core 1.32.0 | Atualizar MCP diretamente; preservar configuração/credenciais/agenda e comprovar executor novo em outra requisição. |
| M05 | WordPress limpo, conjunto final | Ensaiar as duas ordens de carregamento e os primeiros acessos sem aquecimento. Usar também o fluxo upload inativo → ativação explícita como regressão. |
| M06 | WordPress limpo + MCP candidata | Registrar separadamente fixture Meta e fixture LinkedIn, depois ambas; ordens invertidas, pausa/remoção e nova requisição. Nenhum pacote fictício será apresentado como candidato real. |
| M07 | Candidato de integração disponível | Linha individual por C01, C02, C03, C05 ou C06, com origem, versão/hash e contratos efetivos; incluir ordens MCP→Google e Google→MCP na adoção de bridges. Não exige lançar companheiros juntos; manter M01–M05 com os instaladores originais. |
| M08 | WordPress limpo + MCP 0.22.0, sem Google | Provedor fixture de outro domínio declara bridge pelo contrato novo; dois provedores e ordens invertidas comprovam mecanismo genérico. Rodar B30/B31/B33/B34 e as negativas; não apresentar fixture como produto entregue. |

A ordem dos ensaios não vira requisito operacional. Google 0.8.4 aparece somente como base inicializada da atualização Google aceita. Não será necessário restaurar suporte a pacotes anteriores nem carregar Core 1.31.0 para concluir esta manutenção.

As 731 verificações relatadas na entrega MCP 0.21.1 e as contagens do Google permanecem evidências dessas entregas. O relatório 0.22.0 contará somente execuções próprias da candidata, com origem das fixtures, falhas encontradas, correções e limites. A13/A14 históricos não serão sobrescritos nem somados como testes novos.

Na matriz M02/M04, incluir clientes DCR, grants, perfis e tokens válidos antes da troca para provar B20. O relato DCR recebido em 15/10 terminou no encaminhamento ao login; ele não comprova consentimento, emissão ou renovação. O novo relatório separará três origens: diagnóstico recebido, testes automatizados da candidata e execução efetiva com ChatGPT.

## P05 — Documentação e entrega

Atualizar `README`, `CHANGELOG`, `docs/PACOTES.md`, `docs/ATUALIZACAO.md`, `docs/CONTRATO-EXTENSOES.md`, `docs/SERVER-INTEGRATION.md`, contratos/exportações pertinentes, especificação de release, guia incorporado e instruções dos ensaios. Explicar a diferença entre instalação, ativação de inativo, atualização de ativo, operação pendente e rollback de arquivos. Documentar também a negociação CIMD, o fallback local para campos ausentes, cache, identificador de diagnóstico e quando uma nova autorização é necessária.

Publicar os contratos de distribuição e registro de executores com assinaturas/schemas reais, fixtures e guia de adoção; identificar separadamente suporte MCP, adoção GOOGLE-02 e adoção GOOGLE-04. Incluir `docs/EXECUTOR-REGISTRATION.md` ou seção canônica equivalente, com origem dos descritores, admissão raiz, restrição de alvos, estados e transição da base Google. Atualizar o guia dos cinco donos, abilities diretas sociais, contrato de medição Core, perfis, dados pessoais, efeitos persistentes e envelopes. Marcar APIs propostas e integrações ainda indisponíveis como tais. Corrigir os guias correntes sem reescrever A13/A14 ou outros anexos históricos.

Até a liberação da correção, a orientação para instalar Google novo usando MCP 0.21.1 continua sendo upload com `activate:false`, seguido de `plugins/activate` e leitura em outra requisição. Se um plugin já ficou ativo sem inicialização, chamar `plugins/activate` novamente não comprova reparo: essa rota retorna cedo para plugins ativos. O plano não acrescenta reparador automático para esse estado; eventual intervenção deve partir de diagnóstico e operação nativa explícita.

Entregar na implementação:

1. `wp-mcp-fator3-0.22.0-instalador.zip`.
2. `wp-mcp-fator3-0.22.0-fonte.zip`, incluindo testes e evidências próprias.
3. `wp-mcp-fator3-0.22.0-relatorio.md`, com aceites B01–B35, C01–C06, matriz M01–M08, origem das evidências e limites. Responder também por MCP-01/02/03/04 e MCP-SOC-01: implementado, validado, pendente ou não aplicável, com justificativa. MCP-03 é compromisso desta release e não pode ser marcado não aplicável por ausência do consumidor novo.
4. `SHA256SUMS-0.22.0.txt`.

Os bytes publicados devem ser os mesmos ensaiados. A entrega só será considerada concluída após o fluxo combinado funcionar sem chamada reparadora, após a atualização de plugin ativo comprovar que não repetiu a inicialização, após os aceites OAuth obrigatórios e após as provas MCP de distribuição/admissão/transporte previstas em B23–B35, incluindo o registro genérico de P09. A homologação integral CIMD inclui B22; se pendente, identificar a entrega como candidata com validação ChatGPT pendente. Não é necessário esperar novas versões Core, Google, Meta ou LinkedIn para comprovar o produtor MCP; suas integrações ainda não executadas permanecem identificadas em C01–C06.

Sequência de execução proposta: concluir as correções P0 e suas regressões; fechar os contratos P07/P09 e entregar schemas/fixtures aos consumidores; implementar e provar distribuição e admissão genérica com base Google atual e fixture independente; preparar P08/P10 e atualizar guias; empacotar os bytes ensaiados e executar B22 no ambiente de homologação. Os testes condicionados podem ocorrer quando cada produtor/consumidor estiver pronto, sem transformar seu calendário em dependência de instalação. Esta sequência permanece dentro da mesma release 0.22.0.

## Limites do escopo

Não há implantação na frota, limpeza de dados em produção, implementação dos novos plugins sociais, alterações nos companheiros, novas abilities de negócio próprias do MCP, ampliação de grants ou importação histórica. A conexão real ChatGPT pertence ao aceite B22. C02–C04 distinguem verificações externas condicionadas; não incluem uma homologação ampla dos fornecedores nem autorizam efeitos remotos de escrita. A exclusão tipada de termos em duas fases já entregue permanece preservada; não constitui nova demanda desta versão.

Continuam fora da homologação local a matriz completa multisite, caches Redis/Memcached reais, CDN/hospedagem específica, crontab de servidor, observação de vários dias e efeitos remotos de escrita Google/Meta/LinkedIn. Esses cenários não serão impostos como condição artificial de uma correção single-site. Google Ads, aprovação/certificação dos apps sociais, coleta comercial Lead Sync e escritor Sheets P2 conservam seus responsáveis e marcos separados. MCP-03 pertence à implementação obrigatória 0.22.0. Falhas concretas identificadas nos caminhos alterados devem ser tratadas antes da entrega.

## Rastreabilidade desta análise

Os registros das revisões 1–3 abaixo conservam a numeração 0.21.2 usada à época. A decisão vigente da revisão 4 substitui esse número por 0.22.0 e inclui MCP-03; não há pacote 0.21.2 entregue por este planejamento.

| Insumo | SHA-256 |
|---|---|
| MCP 0.21.1 instalador entregue | `12df8115663afb1755288bb115a06efe0ff651faa84561ce95ee951249171b9c` |
| MCP 0.21.1 fonte entregue | `c521cbcb9a39425fc7e2b685d0e77194df44baf29416282ab5cb14835e4d52a0` |
| Google 0.8.5 instalador recebido e conferido | `acd644d1cd9d7a766c03cad9cdd3c67c44635d1b0b2b49936060a588316be96f` |
| Google 0.8.5 fonte recebido | `ea8c0173ef7148c1ba905f0421ddc4752697a511acb532d722c09f27b64aa8b3` |
| `impacto-google-0.8.5-para-mcp.md` | `a068f9c3de669cb3dee6988b21b714987adeb6ff6fe4ea946acaf353ad607cb6` |
| `relatorio-entrega-google-0.8.5.md` | `c7d1216413fa8021dd9419d8ee8427faaf0581d2663d6ad97685f8663e9a6924` |
| `guia-wp-mcp-google-fator3-0.8.5.md` | `123e761dab4c38ddc14bde1f16c7886b57549672ff3a5ba23e406efb05600320` |
| Core 1.32.0 instalador já conferido na entrega MCP anterior | `d6248e0e70c577659a46aa6f9e5044144b591f66385ba9e1b10515f9bba917e4` |

Foram lidos os três documentos Google anexos, os contratos e trechos de inicialização/manutenção do fonte, as evidências específicas de instalação/atualização/primeiro acesso e os caminhos MCP de pacote, ativação, reconciliação e sentinela. O ZIP instalável Google foi comparado integralmente com o manifesto de runtime: 139 arquivos, nenhum ausente, excedente ou divergente; os arquivos comuns do fonte também coincidem.

A revisão 1 realizou análise estática e conferência dos artefatos. Não alterou o runtime MCP, não executou suítes de integração e não chamou sites ou serviços de produção. O plano 0.21.1 e suas provas permanecem preservados.

### Complementação da revisão 2 — OAuth/CIMD

Pedido incorporado: “Pedido de correção — incompatibilidade CIMD no OAuth do Fator3 MCP”, enviado nesta conversa em 15/10/2026. As observações Korvena/site de teste e o DCR até login conservam a condição de diagnóstico recebido.

Nesta revisão foram inspecionados `ClientMetadata`, `TokenStore`, `AuthorizationEndpoint`, `TokenEndpoint`, `RegistrationEndpoint`, `Responses`, `WellKnown`, `Persistence`, `Audit`, proteção HTTP e o teste CIMD da 0.21.1. Esse teste existente usa o singular `none`; não cobre a combinação atual do ChatGPT. A inferência é que a nova regressão precisa cobrir negociação e ciclo OAuth completo, além da resolução isolada.

Uma leitura pública HTTPS de `https://chatgpt.com/oauth/client.json` retornou HTTP 200, JSON de 544 bytes, `Cache-Control: public, max-age=300`, singular `private_key_jwt` e plural `["none", "private_key_jwt"]`. SHA-256 dos bytes observados: `5b62ad00a6d2562dda7b8e373611c41e09967518f5fc0824b243a8e1a29f915e`. Esse registro comprova o documento consultado em 15/10; não comprova autenticação ChatGPT ou execução no WordPress. Na implementação, guardar fixture pública datada e conferir novamente o documento para o teste real.

Referências primárias consultadas em 15/10/2026:

- [OpenAI — Authentication, Client registration](https://developers.openai.com/plugins/build/auth): negociação plural pela interseção e preferência singular na transição CIMD.
- [IETF — OAuth Client ID Metadata Document, draft 02](https://datatracker.ietf.org/doc/draft-ietf-oauth-client-id-metadata-document/): documento em desenvolvimento e requisitos de identidade/busca.
- [OAuth WG — discussão 92 sobre omissão dos métodos](https://github.com/oauth-wg/draft-ietf-oauth-client-id-metadata-document/issues/92): questão ainda aberta na consulta; justifica explicitar o fallback como política local.

A revisão 2 não alterou código de runtime, não instalou pacotes, não executou suítes OAuth e não acessou o WordPress da Korvena ou do site de teste. Os dois defeitos permanecem planejados para implementação na 0.21.2.

### Complementação da revisão 3 — encaminhamentos integrados e sociais

Foram incorporados os oito documentos enviados em 15/10/2026. O encaminhamento MCP e o contrato social orientam P07/P08; os planos e encaminhamentos dos demais donos delimitam dependências e responsabilidades. O pedido anterior do usuário de instalação limpa ou atualização direta da 0.21.0 permanece vigente; a referência dos novos documentos ao trio de pacotes anexado não elimina essa origem aceita.

| Documento recebido | SHA-256 dos bytes desta revisão |
|---|---|
| `plano-instagram-linkedin-lead-sync(1).md` | `22910d20f8ba3d0c080eca4470c8f0a8e8041d34b1925b2b65628ba119948d7e` |
| `analise-e-plano-integrado.md` | `1ed33312a064e6c0e68e66ed05cb72044a16c45ad117d760f64f72623f031f8d` |
| `contratos-integracao-social.md` | `a69f961febd81aedb8ff167991f9e868696821f16d9e8c25599631d9ec00ad12` |
| `encaminhamento-meta.md` | `69a41ba16e0858d1cc9bc743aca9d19c88450eba8ba02b865899d5d181d9c893` |
| `encaminhamento-linkedin.md` | `0eaa8fd73528d0def13ff0568523409828f9e73742259add96cc3ae1a2d97d3a` |
| `encaminhamento-google.md` | `681e34543e81379ba0f3ee31ae58949abfac9cf741c10f137739bcf80bd795a6` |
| `encaminhamento-mcp.md` | `fdcc38076b24fc8cbb73169a9a804f01063ef2f566137db9ad20c2a6c3aff2f5` |
| `encaminhamento-core.md` | `f2069c41809422bc7eba9fa0be4b84d4ac900b33df0f86943ac964e090d3e88f` |

O fonte MCP 0.21.1 foi recuperado e seu SHA-256 reconferido: `c521cbcb9a39425fc7e2b685d0e77194df44baf29416282ab5cb14835e4d52a0`. Foram examinados os pontos relevantes de `UpdateChannel`, `ExtensionContract`, `ServerContract`, `RootToolContext`, `ToolsHandler` e dos guias correntes. Essa inspeção sustenta os achados novos; não equivale a uma execução de suas suítes. A revisão 2 deste plano foi preservada como referência, com SHA-256 `76fb1d9ccd6be9b12b457139f8dfaf109c5642afcee062d3961eb99e97b70d57`.

As comparações GA4 (38 linhas/94 valores), GSC (22 linhas/88 valores) e catálogo GA4 (387 dimensões/98 métricas) são evidências relatadas nos encaminhamentos. Os JSONs `evidencias-validacao-ga4-gsc.json` e `verificacao-pacotes.json`, referenciados por eles, não estão entre estes oito anexos; seus dados brutos não foram revalidados nesta revisão. Isso não impede definir os testes MCP, mas impede apresentar essas contagens como execução própria. Google Ads continua descrito nos documentos recebidos como não funcional/não homologado no ambiente observado.

A revisão 3 atualizou somente o planejamento. Não alterou runtime, não gerou instalador 0.21.2, não executou suítes de integração, não criou conexões ChatGPT e não acessou sites ou APIs de fornecedores. Os tickets de código permanecem planejados; os aceites, pendentes de implementação e execução. A análise não encerra MCP-01/02/04/MCP-SOC-01 nem os tickets dos outros donos.

### Complementação da revisão 4 — release 0.22.0 e inclusão de MCP-03

Decisão expressa do usuário em 15/10/2026: incluir MCP-03 nesta release e considerar a próxima versão como 0.22.0. Essa decisão substitui o adiamento registrado na revisão 3 e a recomendação anterior de postergar GOOGLE-04. O compromisso G08/GOOGLE-04 do plano Google 0.8.6 passa a ter produtor previsto nesta release; a execução conjunta continua exigindo candidatos efetivos e provas próprias.

| Insumo desta revisão | SHA-256 |
|---|---|
| Plano MCP 0.21.2, revisão 3, preservado como referência | `9feb188f5da25b7fcf953b068b655adcac9a020079205fa5e1e221855809fcce` |
| `encaminhamento-google-0.8.6-para-mcp.md`, revisão 3 | `f53eb921a1c48e170d726d1d46e65fd1fdf7362ae6c4f45625580e3bf4b44c7f` |
| `contratos-publicos-core-1.33.0(1).md`, especificação 1 | `c2d5448cce97b44c316908d7e42d5111ed5848757af495581297a6f5bc08e9a6` |

O encaminhamento Google e o plano principal Google 0.8.6 foram lidos na verificação da divergência. O documento Core foi lido nesta revisão. Foram relidos os pontos de `ServerContract`/`RootToolContext` do fonte MCP 0.21.1 que admitem e expõem nominalmente as bridges, para delimitar o registro comum e a transição. Essa inspeção é evidência estática; as soluções P09/P10 e o nome `executor-registration/1.0.0` ainda dependem de implementação.

Atualizados escopo, numeração da release, matriz, entregáveis e critérios de conclusão. Permanecem as origens limpa/0.21.0/0.21.1, os controles de ativação/recuperação, a correção CIMD, os clientes/grants/tokens válidos e a independência de instalação. Os anexos Core/Google recebidos não foram alterados nem enviados a terceiros. A referência MCP 0.21.2 nesses documentos é histórica e deve ser atualizada pelos consumidores para 0.22.0/contrato efetivo antes do fechamento conjunto.

Esta revisão alterou somente o plano: nenhum runtime, instalador, site, credencial ou política foi modificado. Não foram executados testes funcionais ou homologação ChatGPT; todos os novos aceites estão planejados. A revisão documental de consistência não será contada como teste do plugin.
