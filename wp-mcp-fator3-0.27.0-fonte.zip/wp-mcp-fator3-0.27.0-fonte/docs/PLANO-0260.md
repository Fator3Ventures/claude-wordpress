# Plano — Fator3 MCP 0.26.1

Base imediata: MCP 0.25.0. Entradas: Core 1.46.1, Google 0.17.0, Meta 0.4.1 e LinkedIn 0.5.0. A aba MCP recebida não contém pedido novo aberto. Esta rodada atende o impacto LinkedIn 0.5.0, Pedido LinkedIn 6(c), sem criar numeração na aba MCP.

Implementar contrato público mutation-audit/1.0.0, referências ao diário do provedor no Registro central e consulta autorizada de antes/depois. Adaptador delimitado ao evento linkedin-mutation/1.0.0 e leitor público linkedin/get-write-operation já entregues. Nenhuma leitura de tabela/classe privada do LinkedIn. Não persistir snapshots no MCP. Identidade, principal, ativos e permissões continuam governados pelo provedor. Uma referência por provedor/operação; tentativas MCP são metadados correlacionados. Sem histórico retroativo inventado.

No painel, apenas o administrador que originou operação de painel pode usar o leitor registrado em contexto administrativo temporário, sem criar perfil ou assumir credencial. Operações de OAuth/Application Passwords exigem a conexão original. O contexto temporário autoriza somente o leitor registrado, mantém sua permissão original e é sempre encerrado.

Validar instalação limpa e atualização 0.25.0→0.26.1 em WordPress real, coexistência com bases recebidas, escrita simulada MCP/painel, replay sem efeito extra, principal/ativo/perfil revogados, segregação de snapshots, erros/falhas de provedor, saída sem segredo, interface e documentação completa. Atualizar B22/CIMD como encerrado no Site-Teste conforme relatório 0.25.0 revisão 3 de 21/10/2026; não afirmar novos testes de renovação/revogação nem homologação de toda frota.

Entregar fonte, instalador, relatório e impacto LinkedIn com hashes; instalar apenas MCP no Site-Teste, preservando versões dos demais plugins. Não publicar em GitHub/frota.
