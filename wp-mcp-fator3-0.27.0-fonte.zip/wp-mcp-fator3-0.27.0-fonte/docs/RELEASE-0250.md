# Fator3 MCP 0.25.0 — administração e pedido 62

Base imediata 0.24.0. Data: 21/10/2026. Esta versão implementa os sete itens do pedido 62 descritos no documento ADMINISTRACAO. Não reabre o pedido 61, já incorporado em 0.24.0.

## Comportamento

O painel adota abas por assunto e URL. Habilidades usam lista pesquisável com nome e ID; identidades e tipos têm seletores; permissões têm ajuda individual. Registro usa datas/horas UTC e resultado selecionável, e Operações traduz estados. A expiração conserva segundos. Atualizações administra somente wp-mcp-fator3, preservando entradas de terceiros e recusando revisão desatualizada. Limite global de arquivos é editável com validação. Ajuda exibe documentos paginados, sem editor JSON operacional.

## Compatibilidade

Companions de referência fornecidos: Core 1.43.0, Google 0.16.0, LinkedIn 0.4.1 e Meta 0.4.1. Nenhum deles é requisito para ativar o MCP. Contratos server-integration v1, executor-registration v1, package-distribution v1, política v1 e resultado v2 permanecem. Identificadores de habilidades, URLs de abas antigas e formatos de dados públicos não são renomeados.

Mínimo declarado: WordPress 7.1.2 e PHP 8.3.6. Os resultados efetivamente executados e as limitações de homologação estão no relatório externo. A geração do fonte fecha após a validação do instalador, sem alterar o ZIP testado.

## Limites

Credenciais de provedores e OAuth ChatGPT CIMD B22 precisam de seus fluxos reais; não são homologados por testes de painel. Restrições do servidor definidas em constantes/filtros são observadas, sem editor PHP. A atualização não publica em frota ou GitHub e não habilita fontes automáticas.
