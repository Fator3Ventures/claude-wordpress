## Inventário e poda de backups

`backups/prune category:backups` reconcilia somente envelopes privados do formato corrente. A varredura avança até 200 entradas por chamada, com orçamento de tempo. `inventory_complete:false`, `has_more:true` e `selected:0` indicam inventário em andamento. Novos arquivos concorrentes podem exigir ciclo posterior. Tombstones impedem reentrada; conteúdo inválido fica preservado e é relatado.

```json
{"ability_name":"backups/prune","parameters":{"category":"backups","max_total_bytes":0,"min_keep":0,"dry_run":true}}
```

A prévia seleciona até 200 backups. Idade, volume e quantidade são alternativas; `min_keep` protege os mais recentes. Confira `remaining_eligible`, `blocked`, `selected_scope:frozen_batch` e `expected_selection_sha256`. Confirme com `dry_run:false` e o hash exato. Repita a mesma confirmação para retomar falha parcial; depois do lote, faça nova prévia sem cursor. `next_cursor` percorre prévias sem remoção, vinculado a critérios, conexão e site.

A poda retira o envelope e exportações selecionados; o índice SQL conserva tombstone. Referências de operações, pré-imagens e conteúdo sem identidade comprovada ficam protegidos. A instalação não apaga acervo. Os leitores/importadores JSON/BAK e as rotas `backups/legacy-status` e `backups/legacy-retire` foram retirados; diretórios anteriores permanecem intactos.

## Tokens OAuth (45)

Uma contagem como 157 linhas não mede conexões ativas nem concede acesso. Access tokens duram 3.600 segundos; refresh tokens duram 2.592.000 segundos. Rotação preserva registros consumidos para detectar reutilização. Instalar a versão não faz poda automática.

```json
{"ability_name":"system/maintenance","parameters":{"category":"oauth-tokens","dry_run":true}}
```

Confirme com `dry_run:false` e `expected_selection_sha256` igual a `selection_sha256` da prévia. Percorra `next_before_id` enquanto `has_more`. Cada janela examina até 100 tokens vencidos, podendo selecionar zero e ainda haver outra janela.

Tokens válidos e expiração desconhecida são preservados. Os vencidos são compactados. Refresh consumido com grant mantém status `consumed` e recebe `retention_kind:replay_guard`: mantém apenas dados mínimos para detectar reutilização e revogar o grant. Comprovantes podem ser excluídos fisicamente quando expiração e compactação tiverem mais de 30 dias. Guards de refresh ligados a grant ativo são conservados; grant inativo também precisa estar sem alteração há mais de 30 dias. Não há redução por volume. `older_than_days`, se informado, aceita somente 30 para esta categoria. Confirmações válidas preparadas pela 0.21.0 mantêm seu contrato e prazo original.

`system/storage` apresenta grupos por tipo/status, expirados, prazo desconhecido, política e última manutenção. Planos/recibos operacionais são separados dos registros de token: a limpeza desta categoria não promete compactação física do arquivo InnoDB nem redução imediata de seu tamanho em disco.

