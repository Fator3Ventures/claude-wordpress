# Release 0.22.0

Escopo P01–P10 do plano aprovado, incluindo obrigatoriamente MCP-03. As bases efetivas são WordPress limpo e MCP 0.21.0; Core entregue 1.33.0 atualizado diretamente da 1.31.0; Google entregue 0.8.5. Versões dos companheiros não são gates de instalação. Google 0.8.6 é consumidor futuro dos novos contratos.

- OAuth/CIMD: negociação plural, legado público, diagnósticos privados, validação do método no token e preservação de estado.
- Ativação: intenção assinada, modo nativo para inativo/novo e reativação técnica para ativo; prova separada de saúde e prontidão funcional.
- executor-registration/1.0.0: registro genérico, validação, finalização, descoberta, limites de alvo e contexto raiz vinculado à política vigente.
- package-distribution/1.0.0: registro de pacotes, seleção local, recibo público de origem, manifesto explícito e guarda de revisão.
- Transporte de provedores: envelopes preservados, limite explícito de resposta de 2 MiB, fixtures sociais independentes e SDK real de medição Core.

Código e guia incorporado pertencem à mesma versão. Arquivos de docs/historico e evidências anteriores são históricos e não contam como resultados desta candidata. Ver VALIDACAO.md para o estado dos aceites e o relatório externo para hashes.
