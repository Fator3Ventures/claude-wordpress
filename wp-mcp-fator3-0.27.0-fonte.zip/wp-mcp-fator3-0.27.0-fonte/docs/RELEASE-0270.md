# Fator3 MCP 0.27.0 — pedidos 63 e 64

Base de atualização: 0.26.1; instalação limpa independente. Requisitos mantidos: WordPress 7.1.2 e PHP 8.3.6. Schema de persistência 2, perfil 1 e mutation-audit/1.0.0 preservados.

## Entregue

- Pedidos MCP 63: rótulos públicos em português por ação/domínio, usados também no painel; IDs, schemas e callbacks de domínio preservados. Descrição da idempotência de transporte em português. As três leituras core/ nativas recebem apresentação local, sem mudança de propriedade ou autorização.
- Pedido MCP 64: aceitar capacidade authorization_code/code entre tipos adicionais em documentos CIMD; manter validação da lista, autenticação none, HTTPS público, ausência de redirecionamento do documento, 64 KiB, cache limitado, redirect exato, PKCE S256, audiência e consentimento. Token JWT bearer continua não suportado.
- system/oauth-diagnostics: leitura administrativa das últimas 128 falhas de cliente (identificador, categoria, instante), também no Diagnóstico. Sem URLs, hashes de cliente, tokens, payloads, rede ou reparo. Gate local manage_options e política remota. Ver OAUTH-CIMD para exemplos e falhas.
- LinkedIn 0.6.0 registra descritor humano explicitamente. A proposta separada de principal de serviço ainda exige contrato público de concessão/leitura do provedor; não é capacidade entregue nem habilitação automática de envios em background.

## Operação e limites

Nenhuma migração de banco, reautorização forçada, renovação, reset de perfil ou efeito social é disparado na atualização. Falhas de cliente continuam em anel privado próprio, não no Registro de operações. Voltar arquivos à 0.26.1 remove a leitura nova e volta a recusar tipos adicionais, mantendo dados existentes.

A versão do documento, hash e paginação são fornecidos por system/guide. Consulte o relatório externo da entrega para evidências executadas e pendências; aceitação de metadados e fluxo HTTP sintético não equivalem à homologação de um conector Claude real.
