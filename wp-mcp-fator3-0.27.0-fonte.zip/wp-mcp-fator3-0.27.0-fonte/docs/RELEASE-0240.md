# Fator3 MCP 0.24.0 — Pedido MCP 61
Revisão 1 · 17/10/2026. Base suportada: instalação limpa ou atualização direta 0.23.0 → 0.24.0.

## Correção e contrato
A projeção pública mantém `cache_bypass_verified` quando seu valor é booleano, em cada amostra e no total de `probe_before` e `probe_after` das operações de pacote. A mesma correção vale para `system/probe`, consultas de operação e respostas de sucesso/erro nas representações textual e estruturada.

- `true`: a sonda confirmou a execução PHP nova pelo marcador assinado correspondente à requisição.
- `false`: a sonda não comprovou essa execução; consultar `cache_evidence`, `status` e asserções. Não converter false em sucesso nem repetir instalação por esse indicador isolado.
- String, inteiro, null, array e objeto nesse campo permanecem redigidos. Nenhuma coerção é aplicada.

Exemplo de fragmento: `{"probe_before":{"cache_bypass_verified":true,"samples":[{"cache_bypass_verified":true}]},"probe_after":{"cache_bypass_verified":false,"samples":[{"cache_bypass_verified":false}]}}`.

A execução de Probe, os requisitos de recuperação, DataSafety de SQL/options e a proteção de segredos não mudam. Bypass interno não comprova acesso externo, cache HIT, saúde comercial ou entrega no fornecedor.

## Atualizar e verificar
Conferir hash/slug, preservar a pré-imagem e usar `plugins/upload` com URL HTTPS, `expected_sha256`, `expected_slug:wp-mcp-fator3`, `overwrite:true`, `activate:true`. Homologação direta também aceita `plugins/upload-base64` com os mesmos controles. Consultar schema instalado antes de chamar.

A resposta da própria troca a partir da 0.23.0 pode ainda usar o código antigo carregado: não é a prova final da correção. Em requisição nova, consultar `system/capabilities`, `system/health`, `plugins/operation-status` e `system/probe`; um novo upload processado pela 0.24.0 deve trazer booleanos nas sondas. Não substituir valores já redigidos em registros históricos por true/false inventados. Estados incertos exigem reconciliação antes de repetir.

## Documentação, permissões e dados
Descobrir `system/guide`; sem parâmetros obtém índice. Ler `document:release-0240` ou `operacao`, com `byte_limit` 256–32768, `cursor` e `expected_sha256`. Conferir revisão, bytes, SHA-256 e has_more=false. IDs são allowlisted; leitura não chama fornecedor. Gate documental edit_posts e política de conexão permanecem; manutenção exige perfil e capacidades administrativas existentes.

Não há nova configuração, credencial, tabela, schema, migração, limpeza ou renovação. Atualizar preserva conexões, permissões, opções, jobs, pausas, recibos e backups. Retornar aos arquivos 0.23.0 restaura a redação indevida; não desfaz efeitos externos. Mínimos declarados herdados: WP 7.1.2/PHP 8.3; patches efetivamente ensaiados constam do relatório.

Core 1.35.0, Google 0.11.0 e Meta/LinkedIn 0.2.0 são acompanhantes, sem dependência obrigatória. Não há mudança de seus contratos. Homologação de fornecedores e nova conexão CIMD/ChatGPT B22 permanecem fora do Pedido 61; o relatório separa testes próprios e pendências.
