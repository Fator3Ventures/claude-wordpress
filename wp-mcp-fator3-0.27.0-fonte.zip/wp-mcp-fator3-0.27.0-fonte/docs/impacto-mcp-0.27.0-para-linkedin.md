# Impacto de Fator3 MCP 0.27.0 em wp-mcp-linkedin-fator3

Data 22/10/2026 · revisão 2 · etapa entrega · situação aberto · decisao-necessaria / validacao-coordenada.
Emissor wp-mcp-fator3; base aceita 0.26.1; versão entregue 0.27.0; instalador wp-mcp-fator3-0.27.0-instalador.zip, 846316 bytes, SHA-256 fcf5ad0099b9490abfb8e9ea6ef83c769cad053e2ee75712efce50e219f62bc1. Destinatário examinado LinkedIn 0.6.0, SHA-256 edfed426b2e0e4fce14a5c5c6241b12bed25186ab1da2102da96b2032a8af45e. Pedidos LinkedIn 10 e 8(d); resposta ao impacto recebido revisão 3.

## Contrato humano

Manter mutation-audit/1.0.0 e o descritor explícito da 0.6.0. Revalidar emissão humana, leitor público e gates sem assumir usuário do consentimento. Não alterar pacote LinkedIn.

## Proposta para o principal de serviço

Contrato proposto mutation-service-audit/1.0.0, separado e ainda não anunciado como capacidade do runtime. Registro apenas por PHP de provedor instalado e reconhecido, sem executor MCP de emissão. Descritor versionado deve declarar provedor, contrato de evento, leitor público somente de leitura e introspector público de concessão. Não aceitar callbacks ou caminhos recebidos por rede.

O provedor emitiria somente provider, operation_id, operation, state, hashes técnicos, consumer_id, principal_ref e grant_revision. principal_ref e grant_revision são referências opacas sem identidade pessoal; o principal de serviço é distinto de user_id e de grant OAuth humano. MCP confere a existência local, revisão e estado da concessão com o introspector público antes de armazenar referência estável (site + provider + principal_ref + operation_id). Registro não concede poder de envio e não altera a fila Core.

Na consulta, exigir administrador e perfil MCP para o leitor central e leitor do domínio. O leitor do provedor deve verificar concessão/revisão vigente, escopo, conta/regra ainda selecionadas e acesso do administrador solicitante; retornar apenas snapshots técnicos sem PII. Revogação bloqueia detalhe, conserva referência histórica. Serviço sem concessão válida, evento com identidade divergente, troca de ativo ou leitor indisponível falha fechado. Replay conserva identidade, estado incerto não repete efeito. Retenção segue a política central; sem importação histórica automática.

## Ação / critério de aceite

Responsável LinkedIn: confirmar a proposta ou contrapropor nomes/schema públicos para introspecção e leitura de serviço, com exemplo sem PII, regras de revogação e emissão desde sendBound. A 0.6.0 não oferece esse par nem emite evento de serviço; por isso não é possível habilitar a integração apenas no MCP sem fabricar autorização. Responsável MCP: implementar após o contrato de domínio estar alinhado, testar usuário zero/usuário incidental, concessão revogada, revisão divergente, replay e leitura administrativa. Consumidor Core continua sem mudança obrigatória se toda emissão ocorrer no adaptador LinkedIn; reavaliar se a contraproposta transferir responsabilidade ao Core.

Aceite previsto: envio sintético do adaptador real sob usuário zero gera uma referência de serviço; leitura autorizada mostra antes/depois sem PII; permissão indevida e revogação negam; nenhum usuário humano é assumido. Até esse aceite conjunto, central_audit=service_principal_unsupported e diário local permanecem corretos. Não declarar o Pedido 8(d) encerrado.


## Revisão 2 — resultado desta entrega

R1 foi emitida no planejamento, antes das mudanças de runtime. R2 preserva a proposta e registra a prova própria: 32 verificações de integração com LinkedIn 0.6.0, WordPress 7.1.3/PHP 8.3.6/MySQL 8.0.46, HTTP do fornecedor simulado, incluindo dispatcher administrativo, MCP HTTP, leitura central, identidade, ativo, revogação e recusa sob usuário zero. O Site-Teste confirma descritor humano registrado e health saudável com MCP 0.27.0, Core 1.47.0, LinkedIn 0.6.0, Google 0.17.0 e Meta 0.4.1. Evidências próprias: evidencias/0270/acceptance.json e site-tests.json.

Pedido LinkedIn 10: revalidação do descritor humano concluída no escopo acima. A auditoria de serviço 8(d) continua aberta: esta entrega especifica uma proposta, não oferece runtime mutation-service-audit/1.0.0 e não anuncia essa capacidade. Não se promete compatibilidade por inferir classes privadas da 0.6.0. É necessária a resposta do responsável LinkedIn sobre a fronteira pública; depois, implementar e executar o aceite conjunto descrito. A constatação de usuário zero recusado valida a fronteira atual, não a proposta futura. Não houve envio real, mudança no pacote LinkedIn, comunicação a terceiros nem conclusão atribuída ao outro responsável.
