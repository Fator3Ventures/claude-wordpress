# Fator3 MCP 0.23.0 — especificação e operação

Revisão 1, 16/10/2026. Slug/basename: wp-mcp-fator3 / wp-mcp-fator3/wp-mcp-fator3.php. Base: instalação limpa ou atualização direta 0.22.0 → 0.23.0. WordPress mínimo 7.1.2; PHP mínimo 8.3. Não há trava por versão de origem nem dependência obrigatória de acompanhantes. Consulte o relatório externo para os ambientes efetivamente verificados e limitações.

## Escopo

Pedidos MCP 60 (MCP-221-09), M91-01/Core N24 (MCP-221-01), M91-02/Core N25 (MCP-221-02) e documentação MCP-221-08. Preserva server-integration/1.0.0, executor-registration/1.0.0, package-distribution/1.0.0, policy_contract 1 e execução 2.0.0. Nenhum novo bridge por prefixo de fornecedor; nenhuma concessão automática. Core 1.34.0 continua plano sem binário.

## Chave de idempotência e autorização

A origem do campo é capturada em closure antes de acrescentar campos do canal. Schema, required, padrão, limites e valor nativos permanecem intactos; uma chave opcional ausente não é criada. Leitura não recebe cache de escrita. Somente a chave acrescentada pelo MCP é retirada antes do callback. O fingerprint continua excluindo a chave, com isolamento por site, conexão, usuário e ability; ordem de chaves de objeto é normalizada.

O lock revalida permissões do produtor e do canal antes do replay. Para escritas com chave nativa, o produtor é responsável pela idempotência de domínio: após sucesso na 0.23.0, repetição equivalente volta ao callback com a MESMA chave para revalidar seleção/grant e obter seu recibo. O canal não entrega o payload antigo saltando a autorização de domínio. Intenção divergente é recusada antes do callback. Callbacks que declaram idempotency_key devem implementar sua semântica nativa; declaração do campo não autoriza repetição não idempotente de efeitos externos.

Registros antigos não são apagados nem migrados. Falha antiga completa (inclusive invalid_input/rest_property_required) continua retornando a falha; reconcilie job/exportação no produtor e use uma nova chave somente após prova de ausência de efeito. Sucesso antigo com chave nativa, sem marca de encaminhamento, retorna idempotency_revalidation_required, sem expor o recibo nem reabrir a execução. Operações antigas com chave exclusivamente MCP mantêm replay. Running/incerto ou compactado não executam novamente; nunca troque chave para contornar incerteza.

## Diagnósticos e segredos

DataSafety mantém a classificação conservadora para SQL/options/metadados. A apresentação pública preserva checks_passed/all_checks_passed booleanos, passed booleano de sonda ou inteiro não negativo e credential.configured booleano. Também conserva token_configured/secret_configured booleanos e credential_generation/authorization_revision inteiros não negativos dos contratos sociais. Outros tipos nesses nomes e filhos desconhecidos de credential são redigidos. Arrays, objetos JSON, nulos e listas vazias conservam sua forma. Senha, token, segredo e chave privada continuam protegidos. A mesma projeção é usada nas respostas MCP de sucesso e falha, nas representações textual e estruturada.

Tokens opacos de confirmação de 64 hexadecimais (confirm_token/confirmation_token) permanecem disponíveis ao cliente autorizado para concluir duas fases; não são registrados em logs. Schemas de entrada/saída são metadados de descoberta, não credenciais. Logs de falha de tool incluem códigos, sem payload de domínio, mensagem de exceção ou corpo sensível. Auditoria mantém somente seus campos explícitos.

## Normalização de resultados

| Entrada | Envelope comum |
|---|---|
| success booleano explícito | Tem precedência sobre ok; campos nativos não são removidos |
| ok booleano sem success | Preenche success |
| Falha com code=revision_conflict sem error_code | error_code=revision_conflict, conflict=true, retryable=false |
| Falha com error_code=revision_conflict | Corrige conflict/retryable contraditórios para true/false |
| Falha com outro error_code explícito | Preserva código/classificação explícitos |
| Falha com code desconhecido, sem error_code | Conserva code; error_code=operation_failed; conflict=false/retryable=false quando ausentes |
| WP_Error | Conserva seu código em error_code e dados públicos; aplica a mesma regra de revisão |

Não há inferência por mensagem ou substring. data:null permanece null. Normalização é idempotente. Conflito exige releitura e nova intenção/revisão, não retry automático. Um success:true explícito não é convertido em falha por code/ok contraditórios.

## Documentação instalada

system/guide sem parâmetros lista temas e documentos com ID, título, bytes e hash. document contém um ID exato dessa lista; byte_limit é 256–32768 (padrão 8192). A resposta inclui conteúdo UTF-8, offset_bytes, returned_bytes, total_bytes, has_more e next_cursor. Reutilize document, cursor e, opcionalmente, expected_sha256. A revisão é versão:SHA256. Mudança de hash entre páginas produz guide_revision_conflict; reinicie a leitura. O hash refere-se ao documento completo, inclusive ao ler um tema do manual.

O modo legado topic continua disponível; sem paginação explícita retorna o conteúdo inteiro do tema/manual. ability consulta o schema visível e não se combina com documentação. IDs são allowlisted; não aceitam caminhos, URLs ou arquivos externos. Conteúdo compilado vem dos documentos canônicos. Não há HTTP remoto, auditoria de leitura nem persistência pelo leitor. O gate existente edit_posts e a política do canal permanecem; configuração e contas exigem autorização administrativa própria.

## Instalação, limites e validação

Instalar wp-mcp-fator3-0.23.0-instalador.zip. Upload remoto: expected_slug=wp-mcp-fator3 e expected_sha256 calculado dos bytes recebidos; overwrite/activate explícitos. Ativação ocorre em novo processo. Confirmar versão, saúde, journal e inventário após a troca; ativação não comprova prontidão comercial. Fonte e evidências não pertencem ao servidor.

O limite do JSON estruturado permanece 2097152 bytes; corpo HTTP pode ser maior por conter também a representação textual. Limite menor e paginação do produtor prevalecem. Não criar jobs implicitamente para contornar excesso. Google 0.10.0, Meta/LinkedIn 0.2.0 e Core 1.33.0 são as entradas fornecidas desta rodada; instalação da frota depende de publicação separada.

Não há migração nova de banco ou expurgo. Backup prévio do pacote e estado privado deve ser mantido; rollback respeita pós-imagem divergente e não desfaz efeitos de fornecedor. Uma conexão de manutenção existente não prova novo consentimento ChatGPT/CIMD B22. Fornecedores reais, Core 1.34 e Implantador atual têm aceites separados; consultar pendências do relatório da entrega.
