# Entrega 0.23.0

Instalador, fonte, relatório e cinco impactos. O fonte contém relatório anterior ao fechamento para evitar hash circular. Publicação GitHub/raw e novo aceite ChatGPT/CIMD são separados. Consulte o relatório externo para os resultados próprios, provas recebidas e pendências.
