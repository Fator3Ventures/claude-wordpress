# Impacto de Fator3 MCP LinkedIn 0.6.0 em wp-mcp-fator3
Data 2026-10-22 · revisão 3 · etapa entrega · situação com-pendencias · validacao-coordenada / acao-necessaria.
Emissor wp-mcp-linkedin-fator3; base aceita 0.5.0; versão entregue 0.6.0. Instalador wp-mcp-linkedin-fator3-0.6.0-instalador.zip, 189130 bytes, SHA-256 edfed426b2e0e4fce14a5c5c6241b12bed25186ab1da2102da96b2032a8af45e. Destinatário examinado 0.26.1; Pedidos LinkedIn 10 e 8(d).

## Proposta e consequência
Contrato mutation-audit/1.0.0; linkedin-mutation/1.0.0. Registrar descritor público no hook f3_mcp_register_mutation_audit, mantendo evento e leitor linkedin/get-write-operation. Ajustar central_audit pela admissão real. Testar snapshots das escritas de painel e MCP e gates originais. Eventos CAPI não transportam PII; execução background não assume identidade humana para forçar Registro. Coordenar limitação caso contrato do MCP exija administrador de origem.

## Compatibilidade e validação prevista
Funções próprias permanecem autônomas. Não editar pacote destinatário. Instalação limpa e atualização direta 0.5.0, combinação recebida e ausência de acompanhantes. HTTP LinkedIn simulado, permissões/revogação, idempotência, recusa e incerteza. Homologação real separada.

## Responsabilidade e encerramento
LinkedIn implementa adaptador/descritor e entrega evidência; destinatário mantém seu domínio. Revisor/dono confere o aceite. Documento criado antes do código da fronteira, atualizar na implementação e entrega, sem envio a terceiros.

## Revisão 2 — implementação e limitação de principal de serviço
O descritor explícito está implementado e o MCP 0.26.1 o admite em laboratório na versão LinkedIn 0.6.0. Antes/depois de escrita administrativa pelo dispatcher do painel e pela ability MCP passaram no leitor central; principal/seleção originais preservados. Eventos CAPI humanos contêm somente referência/estado/hashes de snapshots técnicos sem PII.
Classificação acrescida acao-necessaria, Pedido LinkedIn 8(d): MutationAudit::record exige manage_options e identidade humana na requisição. Core executa sendBound em segundo plano com usuário zero; não há contrato para principal de serviço. O LinkedIn mantém recibo/diário local sem PII e responde central_audit=service_principal_unsupported. Não assume o administrador que concedeu acesso nem importa tabelas do MCP. Responsável MCP deve propor contrato auditável de serviço com concessão/principal próprio e leitor autorizado; até lá, Registro central de todos os envios CAPI está pendente. Contrato de mutações humanas 1.0.0 não foi alterado.

## Revisão 3 — resultado entregue
Pedido 10 implementado e validado no Site-Teste com MCP 0.26.1: system/health.environment.mutation_audit admite wp-mcp-linkedin-fator3 pelo descritor explícito, contrato e leitor originais. Escritas CAPI simuladas pela ability MCP e pela rota REST administrativa usada pelo painel foram lidas por audit/get-operation com antes/depois técnicos e sem PII; 11 verificações da rodada final aprovadas. Não houve envio real ao LinkedIn. A rota administrativa foi chamada com rest_do_request e usuário autorizado, sem alegação de aceite manual do dono no navegador.

No laboratório integrado, o dispatcher do painel e a ability MCP também passaram, com gates de administrador/principal/ativo e ausência de segredos. Site-Teste ficou sem arquivo temporário, conexão, concessão, prévia ou diário sintético; referências centrais de auditoria e backups das operações foram mantidos. Evidências: evidence/site-teste-060.json e evidence/upgrade/native-tests.json. A necessidade do adaptador legado limitado à 0.5.0 está encerrada para esta versão.

Permanece aberta a ação do Pedido 8(d) para o principal de serviço. O pacote entrega diário local e motivo service_principal_unsupported; não afirma auditoria central completa dos envios em segundo plano. O responsável MCP deve especificar e validar o contrato de serviço. Não houve alteração do MCP nem envio deste encaminhamento a terceiros.
