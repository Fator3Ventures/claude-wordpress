# Pedidos — Fator3 MCP (wp-mcp-fator3)

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no canal **wp-mcp-fator3** (o servidor MCP de cada site; Conector WP MCP §1 e §2). Em outros documentos, cite como "Pedidos MCP N". Serve também de documento para o responsável pelo canal. Base da análise: código da 0.25.0. A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba. A numeração não muda.

**Situação em 21/10/2026: nenhum pedido aberto.** Versão instalada nos 12 sites da frota: 0.25.0 (ZIP `wp-mcp-fator3-0.25.0-instalador.zip`, 832.809 bytes, sha256 `7f32527a…`, no `main` do repositório, commit `7421882`, com a fonte `0ca0f140…` e o relatório), instalada em 21/10/2026 direto sobre a 0.24.0, depois do Fator3 MCP Meta 0.4.1 e do Fator3 MCP LinkedIn 0.4.1 em cada site; no Site-Teste pelo agente do pacote, nos outros 11 pela frota, com `applied` na primeira chamada e sondas `/` e `/wp-json/` 200 antes e depois; exige WordPress 7.1.2 e PHP 8.3.6. Saiu o 62, conferido na 0.25.0 no Site-Teste em 21/10 pelo navegador do dono: oito abas com endereço próprio e nomes distintos (Conexão do servidor, Clientes conectados, Arquivos e banco, Operações, Registro, Diagnóstico, Atualizações e Ajuda), abilities escolhidas numa lista com busca e o nome ao lado do identificador, filtros do registro com seletor de data e hora (UTC) e de resultado, estados de Operações em lista, aba de atualizações só com o canal deste pacote, ajuda por campo e manual em página própria, nenhum editor de JSON. Os rótulos das abilities em inglês que aparecem na lista ("Google: configure", "Fator3 MCP Meta — save-schedule" e semelhantes) vêm dos pacotes que as registram: Pedidos MCP Google 35, MCP Meta 12 e MCP LinkedIn 5. Fora da frota e sem pedido: a conexão real nova do ChatGPT por CIMD (B22 do relatório) segue sem homologação. Próxima entrega sem data.

**Numeração.** Item novo recebe o próximo número (hoje, 63) e vai no fim; item retirado deixa o número vago.

## wp-mcp-fator3 — pendentes

## Decidido não fazer

Da lista comum da frota, o que toca o canal:

- Rota de execução de PHP.
- Rota "frota" (um site chamando os outros).
- `db/execute` em uma fase.
- Fonte de atualização publicada para os pacotes Fator3 (decisão do dono, 01/10/2026): os pacotes seguem trocados por `plugins/upload` com o ZIP versionado do GitHub e `expected_sha256`, pela ordem do Padrão §1.1, e ficam fora de `auto_update_plugins`.
