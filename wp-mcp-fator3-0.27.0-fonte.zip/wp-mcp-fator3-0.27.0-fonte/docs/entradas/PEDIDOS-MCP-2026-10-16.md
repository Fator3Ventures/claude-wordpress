# Pedidos — Fator3 MCP (wp-mcp-fator3)

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no canal **wp-mcp-fator3** (o servidor MCP de cada site; Conector WP MCP §1 e §2). Em outros documentos, cite como "Pedidos MCP N". Serve também de documento para o responsável pelo canal. Base da análise: código da 0.22.0. A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba. Conteúdo movido do documento "Pedidos — Fator3 MCP" em 16/10/2026, com a numeração mantida.

**Situação em 16/10/2026: um pedido pendente (61).** Versão instalada nos 12 sites da frota: 0.23.0 (ZIP `wp-mcp-fator3-0.23.0-instalador.zip`, sha256 `6a64708f…`, no `main` do repositório, commit `4074a78`), instalada em 16/10/2026 direto sobre a 0.22.0, depois do Google 0.10.0 e antes do Site Core 1.34.0 em cada site; no Site-Teste pelo agente do pacote, nos outros 11 pela frota, com `applied` na primeira chamada e sondas `/` e `/wp-json/` 200 antes e depois. Saiu o 60 (conferido na 0.23.0 em ctooffice em 16/10: `meta/create-job` pelo MCP com `idempotency_key` respondeu `ok`, e a coleta diária de 01 a 14/10 concluiu pelo `meta/run-job`). Os itens 1 a 60 saíram desta lista e não se pedem de novo. Fora da frota e sem pedido: a conexão real nova do ChatGPT por CIMD (B22 do relatório) segue sem homologação pelo pacote. Aceite em produção do que não foi exercitado (repetição com a mesma chave devolvendo a mesma coleta; `meta/export` pelo MCP) fica no estado da frota (pendência 20). Próxima entrega sem data.

**Numeração.** Item novo recebe o próximo número (hoje, 62) e vai no fim; item retirado deixa o número vago.

## wp-mcp-fator3 — pendentes

**61. `cache_bypass_verified` das sondas de `plugins/upload` sai `[redigido]`** (0.23.0, korvena.com.br e fator3.com.br, 16/10/2026). Na mesma sessão, o upload do Google 0.10.0 em korvena.com.br, ainda com o canal 0.22.0, trouxe em `probe_before.samples[].cache_bypass_verified`, `probe_after.samples[].cache_bypass_verified` e no total da sonda o valor `true`; o upload do Site Core 1.34.0 no mesmo site, já com o canal 0.23.0, trouxe `"[redigido]"` nos três lugares, e o mesmo nos 11 sites da frota depois da troca do canal. O relatório da 0.23.0 (M91-01) lista os booleanos que a projeção pública mantém visíveis, e esse campo não está na lista. Efeito: a frota não lê mais, na resposta do upload, se a sonda passou por fora do cache, que é a prova de que o HTML conferido é o novo (Padrão §1.1). Pedido: `cache_bypass_verified` (booleano) na lista visível da projeção, nas amostras e no total da sonda. Aceite: no Site-Teste, `plugins/upload` com as sondas trazendo `cache_bypass_verified` `true` ou `false`.

## Decidido não fazer

Da lista comum da frota, o que toca o canal:

- Rota de execução de PHP.
- Rota "frota" (um site chamando os outros).
- `db/execute` em uma fase.
- Fonte de atualização publicada para os pacotes Fator3 (decisão do dono, 01/10/2026): os pacotes seguem trocados por `plugins/upload` com o ZIP versionado do GitHub e `expected_sha256`, pela ordem do Padrão §1.1, e ficam fora de `auto_update_plugins`.
