# Impacto de wp-mcp-google-fator3 0.11.0 em wp-mcp-fator3

Revisão 1 · 16/10/2026 · Etapa: planejamento · Situação: aberto
Google: base 0.10.0 (SHA-256 3e30634b1d1f87b9b4fdeba2a37ac382b1394a1ec7f7235166aa15d107ef8b52), alvo 0.11.0 previsto; instalador ainda não gerado.
MCP examinado: 0.23.0, SHA-256 6a64708f5737eb08c6f726dd5941b28d36a28ecbb45f79f32d2c96d00030a4ab.
Classificação: validacao-coordenada · Natureza: regressão/transporte · M91-01/M91-02; G91-01/03; Pedido MCP Google 25.

## Mudança e consequência

A 0.10.0 documentou corrupção de tipos no MCP 0.22.0. O relatório recebido do MCP 0.23.0 declara correção. A 0.11.0 verificará o produtor Google real, bridges, booleanos/zero/credential e redação de segredos, além de conflito Core real e resultados por bytes. Não haverá compensação Google nem aumento do teto.

O cabeçalho Google passará a exigir WordPress 7.1.2/PHP 8.3.6, combinação a testar em instalação limpa e atualização direta 0.10.0. O instalador deve respeitar a compatibilidade nativa; ambientes abaixo desses mínimos não têm suporte declarado nesta entrega.

## Ação e aceite

Responsável Google: executar HTTP MCP no laboratório descartável com os pacotes identificados, reconstruir documentação e páginas, conferir tipos e erros, preservar autorização. Responsável MCP: somente se aparecer divergência nova, analisar a evidência; não há alteração nova solicitada antes da prova.

## Compatibilidade e sequência

Os três contratos MCP 1.0.0 permanecem. Nenhuma dependência numérica de instalação entre plugins. O teste substitui apenas Google; acompanhantes são insumos identificados. Pendências de APIs reais e distribuição na frota não equivalem a falha de transporte.

## Evolução e encerramento

Retoma M91-01/M91-02 do impacto Google 0.10.0. Será atualizado com resultado próprio e hash da entrega; o relatório recebido não é contado como execução própria. Preparado para o dono, sem envio.


## Entrega — revisão 2, 16/10/2026

Etapa: entrega · Situação: **resolvido no escopo testado**. Instalador Google: `wp-mcp-google-fator3-0.11.0-instalador.zip`, 704694 bytes, SHA-256 `d181deaeee8ef365ac4d6a08884d9fa3d3a3164b21f0538d8ed5d56722536bf9`. A revisão 1 acima é o histórico de planejamento.

M91-01 passou com `google/preflight` real sem credencial: quatro indicadores preservados, inclusive zero e objeto credential. M91-02 passou com `F3Base_Medicao_Contexto::events` e `f3base/medicao-eventos-ler`, revisão divergente, null e classificação de conflito conservados pelo HTTP MCP. Não houve compensação no consumidor nem mudança no MCP. `contracts011.json` registra nove verificações por cenário aplicável; `release010.json` da rodada reconstrói seções por bytes e verifica redação de segredo sintético, bridges e isolamento. Os totais históricos não foram reutilizados.

Pedido 25: instalação limpa e atualização da 0.10.0 passaram no mínimo exato WP 7.1.2/PHP 8.3.6. No Site-Teste, atualização única com os bytes finais pelo upload-base64 com hash/slug; nova requisição pronta; 15 documentos/53 páginas com hashes conferidos. MCP 0.23.0 permaneceu intacto. Esse teste direto não é prova de publicação raw da frota.

Encerramento: nenhuma ação de desenvolvimento MCP permanece para M91-01/M91-02 nesta combinação. APIs reais e distribuição continuam fora desta homologação. Evidência no fonte: `evidence/011/validation011.json`, `site-update.json`, `site-documentation.json`. Este encerramento é do recorte Google examinado; não certifica todas as integrações MCP. Preparado para o dono, sem envio.
