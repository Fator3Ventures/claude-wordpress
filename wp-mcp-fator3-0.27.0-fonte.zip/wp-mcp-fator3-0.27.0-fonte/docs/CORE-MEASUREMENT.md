# Core 1.33.0 — medição e transporte

O pacote entregue implementa `site-measurement-context/1.0.0` em `F3Base_Medicao_Contexto::capabilities/snapshot/events`. O SDK PHP local funciona sem identidade MCP e sem conceder acesso a APIs. O MCP não carrega arquivos privados Core, fabrica usuários ou repara configurações.

As abilities administrativas `f3base/medicao-contexto-ler` e `f3base/medicao-eventos-ler` exigem manage_options e perfil/grant MCP compatível. O transporte preserva `ok`, `code`, `contract`, `provider`, `data`, revisões, seis slots (incluindo Clarity), configured/effective, procedência e flags falsas de verificação. Erro mantém `data:null`; não vira configuração vazia ou sucesso.

A paginação de events exige revisão nas continuações. Foram percorridos os 22 eventos reais do pacote Core 1.33.0 e recusada revisão obsoleta. SDK local sem usuário, HTTP autenticado, perfil personalizado insuficiente e editor sem manage_options foram verificados separadamente.

A atualização testada parte diretamente de Core 1.31.0. Core 1.32.0 não é uma etapa. O SDK de consulta Search Console Core → Google continua separado deste SDK e foi exercitado com Google 0.8.5 e respostas remotas simuladas. A adoção nova pelo Google 0.8.6 depende do pacote futuro.
