# Atualização para Fator3 MCP 0.18.0

Instalação nova e atualização da 0.17.0 delimitam manutenção e testes. Não há lista de versões de origem permitidas no código. Formato de persistência desconhecido recebe `mcp_schema_unsupported`; falha real recebe `mcp_initialization_failed` e contém o canal com HTTP 503, preservando o site e os dados. Isso não promete migração testada de pacotes anteriores à 0.17.0.

1. Confira SHA-256 e guarde o instalador anterior e acesso ao WordPress/hospedagem.
2. Instalação nova: envie `wp-mcp-fator3-0.18.0-instalador.zip`, ative e configure credencial/perfil. Identidades novas não recebem Manutenção automaticamente.
3. Na 0.17.0: use `plugins/upload` com a URL do ZIP, `expected_sha256`, `expected_slug:wp-mcp-fator3` e `overwrite:true`, ou substitua no wp-admin. O mecanismo mantém ativação anterior, backup e sondas independentes. Confira `active_before`, `active_after` e `recovery_status`. `activate` omitido não ativa um plugin antes inativo.
4. Confira `system/capabilities.plugin_version`, ambas as URLs e `system/guide`. A credencial, o perfil e os prazos anteriores devem permanecer.
5. Use `system/probe` com `contexto_teste:true` para conferir home e REST. Chamadas anônimas às rotas MCP devem receber 401 e aparecer em `audit/list`, com `ability:mcp/access-denied`.
6. Se houver índice de dumps incompleto, avance `backups/list` com `category:sql_artifacts` até `inventory_complete:true`. A atualização não poda arquivos. Revise qualquer seleção antes da remoção.

`ReleaseState` separa versão do pacote (constante/cabeçalho 0.18.0), schema de dados (2) e checkpoint `migration/release:0.18.0`. Ele preserva `f3_mcp_release_version` quando existente: essa option é um marcador histórico lido pelo recuperador 0.17.0, não a versão atual. Não a promova manualmente a 0.18.0. Instalação nova não inventa origem anterior. Options falsas/vazias permanecem; não há recaptura de senhas de aplicação, recriação de grants, renovação de prazos ou promoção de perfil. Reentrada é idempotente sob lock.

Foram retirados `Upgrade015.php` (sem consumidor runtime) e `Upgrade016.php` (substituído por ReleaseState). Permanecem leitores, identificadores e estados ainda usados: `Release014`, `phase014`, `legacy_sessions`, credenciais históricas, snapshots e índices incompletos. Um nome antigo não significa dado descartável.

Rollback recompõe arquivos/ativação, não desfaz efeitos externos nem restaura indiscriminadamente options. Manter o marcador histórico permite o retorno ao pacote 0.17.0 após a 0.18.0 inicializar. Não há transformação irreversível de schema nesta release. Recuperação do banco é distinta: siga RECUPERACAO-CONJUNTA.md e o manifesto do dump.

O cabeçalho real é `Update URI: https://fator3.com.br/plugins/wp-mcp-fator3`. É um identificador de atualização próprio; não é um manifesto publicado. `system/settings-update.update_channels` configura opcionalmente uma fonte HTTPS verificável por SHA-256; configurar origem não habilita atualização automática. A entrega mantém distribuição por ZIP versionado/hash e não publica feed. Core e Google não são substituídos pelo instalador MCP.
