# Validação da 0.18.0

Evidências atuais em evidencias/; material anterior em docs/historico/0.17.0. Scripts correntes em tools/release018. Os testes de artefatos SQL e contratos Core/Google reutilizam tools/release017 explicitamente.

Laboratório: WordPress 7.1.2, PHP CLI/FPM 8.3.6, MySQL 8.0.46, lighttpd, quatro workers e OPcache sem validação de timestamps. Apache com mod_rewrite e AllowOverride All verifica os 404 dos diretórios legados e arquivos estáticos. Há instalação limpa e self-upload real HTTP 0.17→0.18, inclusive falha deliberada após bootstrap e recuperação sem editar o banco.

Cobertura desta rodada: pedidos 42–46; inventário 240 backups; ausência de reaparecimento; termos com IDs divergentes, confirmação, conflito, transação revertida e releitura; OAuth com detecção real de refresh reutilizado; ambas as URLs MCP; artefatos SQL e recuperação coordenada Core 1.24.0/Google 0.8.0; schemas, documentação, sintaxe e pacote determinístico.

Os dados de fator3.com.br e korvena.com.br são evidência fornecida pelo solicitante, não dados alterados por estes testes. Não há aceite de exclusão desses termos nos sites nesta rodada. A matriz local não comprova funcionamento de APIs externas Google nem todas as hospedagens. Não foi fornecido Core 1.25.0. Consulte o relatório externo para resultados e hashes exatos.
