# Fator3 MCP 0.18.0 — impacto no Core

08/10/2026. Pedidos MCP 42–46. Nenhuma mudança obrigatória no Core foi identificada no contrato testado com Core 1.24.0. Não foi fornecido nem validado código Core 1.25.0.

Continuam server-integration/1.0.0, policy_contract:1, schema MCP 2, ambas as URLs e guardas independentes de recuperação. A suíte conjunta repetiu preparar/drenar, restore, recusa de geração incorreta e retomada explícita. Teste local com estados sintéticos: não é aceite da frota.

A retirada da pasta histórica não remove o alias MCP. As sondas opcionais de backups/legacy-status usam a marca declarativa contexto_teste. O 404 foi validado em Apache com mod_rewrite e AllowOverride; outras configurações precisam ser verificadas no aceite da hospedagem.

A retenção nova cobre estados e backups MCP, sem mudar a retenção de audiência ou intenções Core. content/delete-term exige manutenção e só trata termo vazio ou com relações para posts inexistentes. Não executa hooks de exclusão nem altera posts, tabelas ou políticas Core. Não há limpeza global de relações órfãs.
