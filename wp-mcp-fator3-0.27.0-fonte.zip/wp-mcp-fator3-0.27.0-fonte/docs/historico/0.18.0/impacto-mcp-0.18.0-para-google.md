# Fator3 MCP 0.18.0 — impacto no Google

08/10/2026. Integração local exercitada com Google 0.8.0 e Core 1.24.0. Nenhuma alteração obrigatória no Google foi identificada nos contratos envolvidos.

O SDK, as bridges, o contrato server-integration/1.0.0 e a recuperação por geração permanecem. A recuperação conjunta foi repetida com os plugins reais, dados sintéticos e rede externa bloqueada. Não se testou acesso a APIs Google nesta rodada.

A retenção OAuth desta release é a do servidor MCP em f3_mcp_tokens; não gerencia tokens OAuth nem conexões do plugin Google. Access/refresh válidos permanecem. O comprovante de refresh consumido conserva status consumed, compatível com o detector da 0.17.0, e prazo ligado à atividade do grant. Não há elevação de perfil nem reautorização implícita.

Poda e retirada do diretório histórico não alteram aliases, sessões nem catálogo Google. A nova rota de termos não depende de ability ou dump Google. O instalador MCP não contém nem substitui o provedor.
