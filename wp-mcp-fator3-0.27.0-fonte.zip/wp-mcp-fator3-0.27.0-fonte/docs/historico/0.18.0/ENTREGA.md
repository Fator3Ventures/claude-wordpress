# Entrega estável 0.18.0

Instalador versionado, fonte, relatório e SHA256SUMS. Pasta WordPress: wp-mcp-fator3. O instalador contém runtime e ajuda autenticada; o fonte contém código, documentação, testes e evidências sanitizadas, sem banco, credenciais, dependências externas ou fontes Core/Google.

Build determinístico: tools/build_packages.py. Verificação de manifesto, equivalência ao fonte, sintaxe e diferença da 0.17.0: tools/check_package.py. Coerência de schemas e exemplos: tools/check_documentation.py. Fonte: tools/pack_source.py. Extraia o fonte e reconstrua para comparar os bytes do instalador.

O relatório-base dentro do fonte evita circularidade do hash do próprio arquivo. A entrega não publica feed nem instala o pacote automaticamente nos sites da frota. A existência de pacote pronto não é comprovante de limpeza dos termos citados no pedido 46.
