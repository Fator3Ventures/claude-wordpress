# Fator3 MCP 0.18.0 — relatório de entrega

08/10/2026. Versão estável, baseada na 0.17.0. Escopo: pedidos MCP 42, 43, 44, 45 e o adicional 46. Instalador único, sem sufixo de homologação. Nenhum pacote foi instalado nem termo apagado nos sites da frota nesta rodada. A decisão de publicação continua com o dono.

## Resultado

| Pedido | Entrega | Prova local |
| --- | --- | --- |
| 42 | `backups/legacy-status` e `backups/legacy-retire`, em duas fases, para retirar somente diretórios vazios e arquivos de proteção gerenciados. | Conteúdo existente e arquivo desconhecido bloqueiam retirada; retirada vazia concluída; verificação não recria pasta. |
| 43 | `.htaccess` e `index.php` assegurados na raiz legada e em `nomeados/` existentes, na ativação/inicialização/verificação. | Reparação local e nove URLs retornando 404 no Apache, inclusive JSON/BAK estáticos. |
| 44 | Inventário retomável das fontes antigas e atuais; poda congelada em lotes; cursor estável, total elegível remanescente e bloqueios explícitos. | Defeito reproduzido na 0.17.0; 240 backups reconciliados e removidos em 200+40; listagem posterior não os reimporta. |
| 45 | Compactação dos tokens vencidos e remoção física dos comprovantes elegíveis após 30 dias; proteção de famílias refresh ativas. | Token válido preservado, guard consumido preservado, reutilização real revoga grant e comprovante de grant inativo é removido após retenção. |
| 46 | `content/delete-term`: identidade explícita, duas fases, backup privado e prova de ausência por releitura. | Termos registrados e não registrados, órfãos, IDs divergentes, conflito entre fases, rollback e chamada HTTP pelas duas URLs. |

## Causa e impacto

O reaparecimento do pedido 44 foi reproduzido: a prévia 0.17.0 selecionava zero, enquanto uma listagem posterior importava o índice antigo e a prévia passava a selecionar um backup já existente. A 0.18.0 reconcilia envelopes de índice, payloads privados sem índice e o acervo legado da raiz/nomeados antes da seleção final. A poda remove também o índice antigo em arquivo e conserva um tombstone SQL contra reimportação.

`selected` continua sendo o lote congelado, com até 200 backups. `inventory_complete:false` e `has_more:true` indicam reconciliação incompleta; zero nesse estado não significa acervo vazio. Após aplicar um lote, uma nova prévia sem cursor recalcula o restante. `remaining_eligible` e `blocked` separam remanescentes de conteúdo que não pode ser removido. Consulte RETENCAO-018.md.

O diretório legado é armazenamento histórico. O alias `/wp-json/mcp/wp-mcp-ultimate` é transporte e permanece ativo, assim como `/wp-json/mcp/wp-mcp-fator3`. Retirar a pasta não remove sessões ou credenciais.

Não houve alteração de schema MCP (continua 2), política (1), SDK `server-integration/1.0.0` ou guarda SQL `selection-guard/2`. A matriz exercitada é MCP 0.18.0, Core 1.24.0 e Google 0.8.0. Nenhuma alteração obrigatória nesses provedores foi identificada para este escopo; seus fontes não foram modificados. Core 1.25.0 não foi fornecido nem validado. Encaminhamentos atualizados estão no fonte.

## Uso e limites do pedido 46

O valor “tt” da demanda é `term_taxonomy_id`, distinto de `term_id`. Informe taxonomy e exatamente um dos IDs. Exemplo de prévia baseada na demanda, sem presumir que esse ID continua sendo o alvo no site:

```json
{"ability_name":"content/delete-term","parameters":{"taxonomy":"elementor_library_type","term_taxonomy_id":3,"allow_unregistered":true,"object_type":"post"}}
```

Confira o resumo e repita os mesmos argumentos com `confirm_token`. Taxonomia ausente exige explicitamente `allow_unregistered:true` e `object_type:post`. Exige Manutenção, manage_options e a capacidade nativa delete_terms quando registrada.

A operação salva a pré-imagem de terms, term_taxonomy, termmeta e relações do termo, sem dump integral. A exclusão ocorre em uma transação InnoDB com conexão fixa. A resposta identifica o backup e prova `term_absent`, `term_taxonomy_absent`, `relationships_absent` e `termmeta_absent`, com releitura também após commit. Confirmação repetida retorna recibo. Mudança entre as fases recusa a execução.

Esta rota atende **termos vazios ou relacionados apenas a posts inexistentes**. Relações com posts existentes, termos padrão, compartilhados ou com filhos são recusados. `count:0` não substitui a verificação dos posts. Há limites de 1.000 relações, 1.000 metadados e 4 MiB de pré-imagem. Não executa hooks de exclusão de provedores; invalida os caches. Backup permite recuperação assistida/exportação, sem nova rota automática de restore de termo.

Só as relações do termo escolhido são removidas. Linhas órfãs cujo próprio term_taxonomy_id não existe ficam fora desse contrato. Assim, as seis linhas mencionadas em Korvena só entram se pertencerem ao termo selecionado. Os dados de fator3.com.br e korvena.com.br são evidência fornecida pelo solicitante; não houve nova medição ou limpeza nesses sites.

## Retenção e proteção

Access tokens: 3.600 segundos. Refresh: 2.592.000 segundos. A poda é explícita por `system/maintenance category:oauth-tokens`, com prévia e confirmação. Registros vencidos são compactados; comprovantes são removidos quando expiração e compactação tiverem mais de 30 dias. Refresh consumido conserva status `consumed`, compatível com a 0.17.0, e dados mínimos para detectar reutilização enquanto seu grant estiver ativo. Grant inativo precisa também estar sem alteração há mais de 30 dias. Prazo desconhecido é preservado para revisão; contagem de linhas não prova autorização. Instalação não faz limpeza automática.

O 404 foi comprovado com Apache, mod_rewrite e AllowOverride All. Sem rewrite, a regra de negação retorna 403; servidores que ignoram `.htaccess`, como Nginx/lighttpd, exigem regra equivalente. O index.php isolado não protege arquivos estáticos. Configuração desconhecida e symlinks são preservados e reportados. O aceite nos 14 sites exige conferir os arquivos e o HTTP após publicação.

## Validação executada

WordPress 7.1.2, PHP CLI/FPM 8.3.6, MySQL 8.0.46, lighttpd, quatro workers e OPcache validate_timestamps=0; Apache separado para arquivos legados. Serviços reais, dados sintéticos, rede externa e email bloqueados.

| Suíte | Aprovadas | Evidência no fonte |
| --- | ---: | --- |
| Pedidos 42–46 | 28/28 | `release018.json` |
| Identidade, conflitos e rollback de termos | 11/11 | `edge-tests.json` |
| HTTP MCP, ambas as URLs e rota tipada | 24/24 | `http-tests.json` |
| Artefatos SQL e recuperação | 25/25 | `sql-artifacts-tests.json` |
| Recuperação conjunta Core/Google | 17/17 | `companions-tests.json` |
| Atualização HTTP 0.17→0.18 e rollback | 17/17 | `upgrade-http.json` |
| Proteção Apache dos arquivos legados | 9/9 | `apache-legacy-protection.json` |
| Retenção e reutilização de refresh | 4/4 | `token-guard-tests.json` |
| Documentação, exemplos e schemas | 69/69 | `documentation-0180.json` |
| Pacote, manifesto e reprodução | 14/14 | `package-verification.json` |

**135 verificações funcionais/de integração e 83 de documentação/pacote aprovadas.** Além disso, os 440 arquivos PHP do instalador passaram no lint; 163 contratos foram exportados do WordPress. O pacote contém 449 arquivos: quatro novos serviços, nove arquivos alterados e 436 membros idênticos à 0.17.0.

A atualização HTTP usou o executor 0.17.0 e os bytes exatos do instalador entregue. Preservou credenciais, perfil, expiração, options falsas/vazias e confirmação SQL pendente. Houve teste deliberado de falha após bootstrap, rollback sem remendo de banco, pool aquecido e nova atualização bem-sucedida. A retenção de refresh foi verificada também após o último ajuste de travamento da concessão.

Esses testes não substituem aceite da frota, todas as configurações de hospedagem ou APIs externas Google. Evidências históricas da 0.17.0 ficam separadas em docs/historico e não são contadas nesta entrega.

## Instalação e integridade

Instalador: `wp-mcp-fator3-0.18.0-instalador.zip` (728,814 bytes).

SHA-256 do instalador: `6a81e96234a718ffab342c11d52e1fbc09c253df5c8dc16cab155de892332412`.

Use o mesmo ZIP para instalação limpa ou atualização da 0.17.0, pelo wp-admin ou pela rota de upload com SHA-256, slug esperado e overwrite. As versões de origem são baselines de teste, sem trava de versão no runtime. Guarde o pacote anterior para rollback. Não foi publicado feed nem ativada atualização automática.

O fonte inclui instruções, documentação, testes e evidências; exclui dependências, banco, credenciais e fixtures ZIP de falha. O relatório-base interno evita referência circular ao hash do próprio fonte. A reconstrução a partir do fonte deve produzir o mesmo instalador; o resultado final é acrescentado ao relatório externo.
