# Validação 0.21.1

Cenários atuais descritos em tools/release0211/README.md e evidencias/0211/acceptance.json. Ambiente: WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, lighttpd/PHP-FPM, Core 1.32.0 e Google 0.8.4. Atualizações MCP/Core nas duas ordens usam ZIP original e HTTP autenticado.

Callbacks reais e diagnóstico controlado estão diferenciados nas evidências. O relatório contém contagens, hashes e limites; evidências de versões anteriores ficam no histórico e não são recontadas. Google 0.8.5 indisponível: A13/A14 não executados. Sem serviços externos reais, frota, multisite completo, Redis/Memcached ou monitoramento de sete dias.
