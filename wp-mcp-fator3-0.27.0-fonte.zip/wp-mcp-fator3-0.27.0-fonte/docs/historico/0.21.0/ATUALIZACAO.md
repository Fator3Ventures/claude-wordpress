# Atualização para Fator3 MCP 0.20.0

Instalação nova e atualização da 0.19.0 delimitam os ensaios desta entrega, sem trava por versão de origem. O schema continua 2 e o contrato de autorização continua 1. Formato desconhecido é recusado; não se promete migração testada de toda versão anterior.

1. Confira SHA-256 do instalador e conserve os pacotes anteriores e o acesso à hospedagem.
2. Instalação nova: envie `wp-mcp-fator3-0.20.0-instalador.zip`, ative e configure a conexão e o perfil explicitamente.
3. Atualização: pela 0.19.0, use `plugins/upload` com URL e `expected_sha256`, `expected_slug:wp-mcp-fator3`, `overwrite:true`, ou use o wp-admin. O executor ainda em memória é 0.19.0; ele conserva seu timeout e sua política antiga. A política nova começa nas próximas operações executadas pela 0.20.0.
4. Confira `system/capabilities.plugin_version`, ativação, ambas as URLs MCP e `system/guide`. Credenciais, políticas, prazos, sessões e confirmações existentes devem permanecer.
5. Consulte `backups/legacy-status`, opcionalmente com `test_http:true`, para observar o arquivo real e o bloqueio 403/404. O hash parcial de um pedido não prova equivalência de configuração.
6. Em novas trocas inconclusivas, conserve `package_operation_id`, consulte `plugins/operation-status` e use `plugins/reconcile`. Não faça outro upload às cegas. Escolha rollback explícito somente considerando os efeitos de banco e hooks.

`ReleaseState` registra `migration/release:0.20.0` e preserva a option histórica `f3_mcp_release_version`. Não há recaptura de credenciais, renovação de tokens ou elevação de perfil. Diários anteriores conservam seu contrato. A atualização não poda backups nem conclui demandas nos sites automaticamente.

`Update URI: https://fator3.com.br/plugins/wp-mcp-fator3` permanece identificador próprio, sem publicação de feed. O instalador MCP não inclui Core ou Google. A compatibilidade com Core 1.25.0 e Google 0.8.2 é descrita em IMPACTO-COMPANHEIROS-019.md; os arquivos dos dois plugins não foram alterados.


Consulte RELEASE-020.md para o novo token de revisão, backup em fluxo, rotas SEO/termos e matriz Core 1.30.0/Google 0.8.3. Relatório da entrega delimita as provas locais.
