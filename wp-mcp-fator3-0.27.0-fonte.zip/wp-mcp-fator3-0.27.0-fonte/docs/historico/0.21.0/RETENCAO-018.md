# Retenção e armazenamento legado — 0.18.0

## Diretório e alias (42–43)

`wp-content/f3-mcp-backups/` e seu subdiretório `nomeados/` pertencem ao acervo histórico. O alias `/wp-json/mcp/wp-mcp-ultimate` pertence ao transporte e continua ativo. A pasta pode ser retirada sem mudar o transporte ou as credenciais.

Enquanto o diretório existir, ativação, inicialização e verificações de saúde asseguram `.htaccess` e `index.php` em cada diretório existente. Arquivos reconhecidos do pacote são atualizados; configuração desconhecida e symlinks são preservados e reportados como bloqueio. Não se recriam diretórios ausentes. A regra Apache devolve 404 quando mod_rewrite e AllowOverride estão disponíveis; sem rewrite a negação é 403. Nginx, lighttpd e servidores que ignoram `.htaccess` precisam de regra equivalente no servidor. O `index.php` retorna 404 para acesso ao índice, mas não protege arquivos estáticos sozinho.

```json
{"ability_name":"backups/legacy-status","parameters":{"test_http":true}}
```

A resposta separa proteção local de teste HTTP, usa sondas marcadas e mostra conteúdo que impede retirada. Depois de exportar/podar o acervo desejado, `backups/legacy-retire` prepara a retirada; repita os mesmos argumentos com `confirm_token`. Exige Manutenção e manage_options. Só remove arquivos de proteção gerenciados e diretórios vazios. Conteúdo desconhecido, symlinks e armazenamento multisite compartilhado bloqueiam a operação. Gera backup dos metadados da retirada. Falha parcial tenta reaplicar proteção. Não apaga backups do usuário nessa rota.

## Inventário e poda (44)

`backups/prune category:backups` reconcilia o índice SQL, envelopes de índices antigos, backups privados sem índice, JSON/BAK na raiz legada e em `nomeados`. A varredura avança até 200 entradas por chamada, com orçamento de tempo, e mostra `inventory_complete:false`, `has_more:true` e `selected:0` até completar. Isso significa inventário em andamento, não ausência de backups. Novos arquivos concorrentes podem exigir um ciclo posterior.

```json
{"ability_name":"backups/prune","parameters":{"category":"backups","max_total_bytes":0,"min_keep":0,"include_legacy":true,"dry_run":true}}
```

Com o inventário completo, a seleção inclui no máximo 200 backups. Idade (padrão 30 dias), volume e quantidade são alternativas de elegibilidade; `min_keep` protege os mais recentes. Volume zero também alcança backups legados recentes. `include_legacy:false` os exclui da seleção. A resposta informa `remaining_eligible`, `blocked`, `selected_scope:frozen_batch` e `expected_selection_sha256`. Arquivos sem identidade/par, referências de recuperação e conteúdo desconhecido ficam bloqueados explicitamente.

Aplique com `dry_run:false` e `expected_selection_sha256`. Repita a mesma confirmação para retomar falha parcial. Depois de concluir um lote, faça uma nova prévia **sem cursor** para reavaliar o restante. `has_more` e `remaining_eligible` pós-aplicação descrevem o acervo remanescente conhecido, incluindo elegíveis bloqueados. Não são a quantidade do lote recém-removido. `next_cursor` serve para percorrer prévias sem removê-las, vinculando critérios, conexão e site. Os antigos deslocamentos não nulos são recusados; não se deve aumentar offset depois de apagar linhas.

A poda retira o payload, o índice antigo em arquivo e exportações relacionadas; o índice SQL mantém um tombstone que impede reimportação. `backups/list` também reconcilia o inventário e informa `history_complete`; uma listagem não ressuscita arquivos podados. O cálculo global usa funções de janela SQL (validado em MySQL 8); erro de inventário falha antes de remover.

## Tokens OAuth (45)

Uma contagem como 157 linhas não mede conexões ativas nem concede acesso. Access tokens duram 3.600 segundos; refresh tokens duram 2.592.000 segundos. Rotação preserva registros consumidos para detectar reutilização. Instalar a versão não faz poda automática.

```json
{"ability_name":"system/maintenance","parameters":{"category":"oauth-tokens","dry_run":true}}
```

Confirme com `dry_run:false` e `expected_selection_sha256` igual a `selection_sha256` da prévia. Percorra `next_before_id` enquanto `has_more`. Cada janela examina até 100 tokens vencidos, podendo selecionar zero e ainda haver outra janela.

Tokens válidos e expiração desconhecida são preservados. Os vencidos são compactados. Refresh consumido com grant mantém status `consumed` e recebe `retention_kind:replay_guard`, compatível com o detector da 0.17.0: mantém apenas dados mínimos para detectar reutilização e revogar o grant. Comprovantes podem ser excluídos fisicamente quando expiração e compactação tiverem mais de 30 dias. Guards de refresh ligados a grant ativo são conservados; grant inativo também precisa estar sem alteração há mais de 30 dias. Não há redução por volume. `older_than_days`, se informado, aceita somente 30 para esta categoria. Prévia antiga da 0.17.0 mantém seu contrato de compactação até o prazo original; a nova política vale para novas prévias.

`system/storage` apresenta grupos por tipo/status, expirados, prazo desconhecido, política e última manutenção. Planos/recibos operacionais são separados dos registros de token: a limpeza desta categoria não promete compactação física do arquivo InnoDB nem redução imediata de seu tamanho em disco.
