# Verificação de pacotes — pedido 48 / 0.19.0

`plugins/upload`, `plugins/upload-base64` e `plugins/update` aceitam `probe_timeout_seconds`, inteiro entre 1 e 30, padrão 15. O mesmo limite vale por requisição de ativação e por requisição da sonda posterior. Home e REST compartilham orçamento máximo de `min(45, 2*timeout+2)` segundos; ativação, staging e sonda inicial têm seus próprios tempos. Não é um prazo total da chamada. A sonda inicial permanece em 5 segundos: site já inconclusivo é recusado antes da troca. `system/probe` mantém o contrato geral de 1–10 segundos.

Após instalação completa, timeout, falha de transporte, HTTP 4xx, ausência da marca PHP ou divergência de versão/ativação produzem `package_verification_pending`, `applied:null`, `files_applied:true`, `pending:true`, `retryable:false`, `recovery_status:verification_pending`. Os arquivos candidatos, backup e diário são preservados. HTTP 5xx ou falha de ativação confirmada permitem recuperar a pré-imagem. Corrupção estrutural da instalação continua tendo recuperação própria. Nenhum desses caminhos desfaz migrações de banco ou efeitos externos: `database_effects_reversible:false`.

Use o `package_operation_id` de 32 caracteres devolvido pela troca. Ele identifica o diário e é distinto de `operation_id` do executor/idempotência. `plugins/operation-status` lê apenas operações da mesma conexão; devolve estado, versão/ativação observadas, backup, `file_state`, estado da ativação e última evidência. Essa consulta não faz sondas nem conclui a operação. `success:true` nela indica sucesso da leitura. `plugins/reconcile` verifica hash, ativação e home/REST em nova requisição e conclui o diário apenas com prova efetiva. Possui as mesmas permissões de atualização e exige ativação quando necessária. Perfil personalizado deve conceder as novas habilidades explicitamente.

```json
{"ability_name":"plugins/operation-status","parameters":{"operation_id":"0123456789abcdef0123456789abcdef"}}
```

```json
{"ability_name":"plugins/reconcile","parameters":{"operation_id":"0123456789abcdef0123456789abcdef","probe_timeout_seconds":30}}
```

Uma ativação que ainda roda não é repetida. Somente uma ativação nunca reivindicada e com token expirado, ou ainda não solicitada, pode ser iniciada pela reconciliação. Ativação interrompida em `running` permanece pendente e requer avaliação operacional; não se presume que seus efeitos foram desfeitos. Mudança da pós-imagem bloqueia a reconciliação. Upload do mesmo plugin enquanto há diário não resolvido é recusado. Não reutilize a chave de idempotência do upload para reconciliar: a resposta anterior continua sendo um recibo, não uma nova observação.

A sentinela preserva `verification_pending` mesmo após expirar a lease. Executor abandonado depois de instalar a árvore inteira passa a pendente; interrupção estrutural durante renomeação continua recuperável. `plugins/rollback` permite recuperação explícita de uma troca pendente, com backup da própria conexão e hash da pós-imagem, e não troca arquivos durante ativação em execução. Essa escolha continua sem reversão de banco. Após rollback, a sentinela invalida o cache do PHP servidor durante uma janela de 60 segundos; isso cobre rollback iniciado em CLI, cujo OPcache é separado do FPM.

A política nova vale para operações iniciadas pelo runtime 0.19.0. O upload que substitui o MCP 0.18.0 ainda é executado pelo código 0.18.0 carregado na requisição e conserva seu contrato antigo. A alteração não reinterpreta diários antigos nem resolve a migração/downgrade do Core (pedido Core163).
