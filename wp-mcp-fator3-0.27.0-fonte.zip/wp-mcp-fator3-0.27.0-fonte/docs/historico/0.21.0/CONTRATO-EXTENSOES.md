# Extensões Fator3 MCP 0.17.0

A política de habilidades permanece `policy_contract:1`. Registre provedor/versão/prefixos durante `f3_mcp_register_providers` e forneça os mesmos metadados às abilities. Registro não concede capacidades WordPress nem perfil de conexão. O permission_callback decorado aplica a política, inclusive se uma habilidade aderente chegar por outra porta.

O contrato canônico do servidor, seus filtros, identidade, diagnóstico e ferramentas diretas está em [SERVER-INTEGRATION.md](SERVER-INTEGRATION.md). O mapa de hooks internos está em `server-hook-map.json`; não use hooks genéricos `mcp_adapter_*` para configurar o Fator3.

Google 0.6 e Core 1.19 convivem com esta versão sem alteração de seus fontes. Para a bridge futura Google, use `f3_mcp_default_server_config`, valide a identidade `contract:server-integration/1.0.0` e contribua somente as abilities registradas. A união por nome evita duplicação com o adaptador de compatibilidade do canal.

Uma fachada PHP Core → Google não deve ser publicada como executor MCP nem depender de usuário 0 receber perfil. Desligar o transporte MCP não administra o serviço local dos complementos. Configurações e concessões permanecem com seus donos. Consulte os relatórios de impacto entregues com o fonte.
