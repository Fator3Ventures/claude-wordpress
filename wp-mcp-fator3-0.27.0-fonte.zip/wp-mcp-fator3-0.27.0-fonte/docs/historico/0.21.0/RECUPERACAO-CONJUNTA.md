# R01 — Core 1.25.0 e Google 0.8.2

## Recuperação conjunta Core 1.25.0 e Google 0.8.2

Consulte f3base/operacao-recuperacao-ler e google/recovery-status. Prepare Core com f3base/operacao-recuperacao, acao:preparar e geracao_esperada corrente; prepare Google com google/recovery, action:prepare. Aguarde pronto_para_restaurar:true do Core e ready_for_restore:true do Google. Essas barreiras não suspendem todo o WordPress nem processos externos.

Restaure somente após as duas guardas prontas. Releia ambas depois do restore: os arquivos de pausa fora do banco devem permanecer pausados. Reconcile options, concessões, conexões Google, jobs e contextos com o manifesto restaurado. Restauração de uma tabela de um provedor não comprova coerência de todo o seu estado. Não repita efeitos enviados às APIs.

Retome explicitamente cada provedor com geração atual: Google action:resume/expected_generation/acknowledge_reconciled:true; Core acao:retomar/geracao_esperada/reconciliacao_confirmada:true. Retomar um não retoma o outro. Core pode invalidar cursores/intenções/filas em tabelas não restauradas; registre esses efeitos como ações do provedor. Falha ou reconciliação incompleta mantém a pausa.

Core com sentinela ausente/divergente exige seu procedimento de recriação com precondicao_esperada e manter_pausado:true, seguido de preparar/drenar. O MCP não recria estado privado Core/Google. Use o guia incluído em cada pacote. Não atribua automaticamente f3base_ler_leads ou grants Google, nem fabrique sessão humana para o consumidor PHP.

Inventário introduzido no Core 1.24.0, preservado na matriz atual: `{prefix}f3base_operacao_intencoes`, `{prefix}f3base_consentimento_reparos`, `{prefix}f3base_audiencia_404` e `decisao_ref` em `{prefix}f3base_leads`, além das tabelas já presentes. Esses nomes documentam estados do provedor, não formam whitelist de dump. O dump integral descobre o banco real; o restrito segue seu manifesto. Pendências e estados esgotados de negócio do Core não são alvos da retenção MCP.

Google 0.8.2 conserva execution 2.0, configuration 3.0 e suas duas bridges. Prepare Core → Google; retome Google → Core somente após reconciliar e reler a geração. A atualização do MCP não retoma os provedores nem reconfigura suas APIs.
