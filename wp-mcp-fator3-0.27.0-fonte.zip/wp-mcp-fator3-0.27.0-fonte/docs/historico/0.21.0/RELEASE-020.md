# Fator3 MCP 0.20.0 — contratos e operação

Implementação dos pedidos 47 e 49–55 e do diagnóstico adicional do marcador cron próprio. O pedido 48 permanece atendido pela recuperação e reconciliação de pacotes da 0.19.0. Não há limpeza automática de termos ou indexables na ativação.

## Proteção e usuários

O pedido 47 reconhece a configuração legada de 205 bytes com `mod_php.c`, `php_flag engine off` e `Options -Indexes`. O reconhecimento exige bloqueio de acesso nos cenários de módulos Apache suportados; desabilitar PHP sozinho não basta. Regras equivalentes são preservadas byte a byte. Diretório/sentinela devem continuar em 403/404; um 404 existente não deve virar 200.

`users/update` aceita `user_nicename` opcional, canônico, não vazio, até 50 caracteres. Não normaliza silenciosamente nem aceita sufixo automático por colisão. Usa `wp_update_user`, lock de usuários/papéis, capacidades nativas e releitura. Retorna `id`, `user_nicename`, `changed`, `persisted`. Falha após hooks pode ser parcial e exige inspeção. Login e e-mail não mudam quando omitidos. Escritores externos ao lock não recebem garantia transacional global.

## Revisão e SEO

A revisão `content-revision/2` usa a representação persistida de post, todos os metadados e relações de taxonomia, com ordenação determinística e tipos consistentes. Não depende do estado filtrado do cache `WP_Post`. O hash é opaco: após instalar 0.20.0, faça uma leitura nova. Tokens antigos não são convertidos ou aceitos aproximadamente. Uma alteração real externa continua causando conflito. Hooks que gravem depois do retorno também representam alteração real.

O encadeamento é feito por chamadas independentes: `content/patch-post`, `content/update-post` e equivalentes para páginas retornam a revisão final; envie-a como `expected_revision` de `content/update-seo`. `operations/plan` mantém sua allowlist, sem incluir SEO nem `f3base/*`.

O adaptador Yoast consulta o indexable existente e fornece esse modelo ao builder. Confere quantidade e identidade na releitura; retorno não vazio do builder não é prova suficiente. Metadados têm backup, incluindo presença/ausência e valores brutos dos campos sociais. Indexação desabilitada é recusada antes da escrita. Duplicatas existentes retornam `seo_indexable_duplicates` e exigem reparação explícita. Falha depois da gravação informa os valores efetivos e `backup_id`; não repetir às cegas.

### Imagens sociais

`values.open_graph_image_id` e `values.twitter_image_id` são inteiros não negativos. ID positivo exige anexo de imagem local, arquivo legível e dimensões coerentes com os metadados. ID sozinho deriva URL; URL e ID juntos devem corresponder ao mesmo anexo. URL local usa a associação nativa ou uma correspondência exata com original/tamanhos registrados. Ambiguidade exige ID explícito. Não há busca remota de dimensões ou associação por simples nome de arquivo.

URL externa limpa o ID anterior; URL vazia limpa URL e ID. Mesma URL com ID ausente/incorreto constitui mudança. CDN depende de mapeamento verificável pelas APIs nativas. A resposta `get-seo` contém os IDs armazenados; `rendered_html_verified:false` continua distinguindo metadados de prova pública do HTML.

### Reparação de indexables

`content/deduplicate-seo-indexables` recebe `id` de post/página e, na confirmação, `confirm_token`. Exige Manutenção, administração, edição do post e capacidade SEO. Preserva integralmente o menor ID. Sem duplicatas, retorna `changed:false`.

A prévia identifica o ID preservado, excedentes, relações e hash. A confirmação repete schema/seleção sob transação InnoDB e lock do post. Backup privado inclui schema, versão Yoast, linhas, metadados e dependências, limitado a 1.000 linhas/4 MiB. Remove somente excedentes e hierarquia correspondente. Links ligados aos excedentes, hierarquia externa, chaves estrangeiras externas ou colunas desconhecidas são recusados. O schema verificado é o do Yoast 28.5, inclusive `blog_id` da hierarquia e `updated_at` com `ON UPDATE`. A guarda geral de SQL não foi afrouxada.

```json
{"ability_name":"content/deduplicate-seo-indexables","parameters":{"id":123}}
```

Reenvie os mesmos parâmetros com o token recebido. O token dura 600 segundos, é vinculado à conexão e a repetição concluída retorna o comprovante anterior. O backup auxilia recuperação por administração nativa/SQL em duas fases; não há restauração automática de uma limpeza SEO.

## Atualização de termos

`content/update-term` exige `taxonomy`, `term_id` e pelo menos um de `name`, `slug`, `description`, `parent`. Aceita `expected_revision` e `confirm_token`. Taxonomia deve estar registrada; a exceção de taxonomia ausente continua restrita a `content/delete-term`.

Nome/descrição sem mudança de URL são gravados em uma fase com backup. Mudança efetiva de slug ou pai hierárquico exige prévia e confirmação. `parent:0` remove o pai; descrição vazia limpa. Slug não canônico ou com colisão, pai inválido, ciclo e pai em taxonomia não hierárquica são recusados. O lock global de termos é compartilhado com exclusão. A pré-imagem limitada inclui termo, metadados, relações, descendentes, ascendentes e estado Yoast. Mudança da seleção exige nova prévia.

```json
{"ability_name":"content/update-term","parameters":{"taxonomy":"post_tag","term_id":12,"name":"Nome corrigido"}}
```

A gravação usa `wp_update_term`, hooks e invalidação nativos; com Yoast compatível, reconstrói e verifica o indexable do termo. Retorna IDs de termo e term-taxonomy, revisão, URL, `changed`, `persisted`, `backup_id`. Não faz flush de regras nem cria redirecionamento. URL/HTML públicos devem ser conferidos na operação do site.

## Backup em fluxo e mídia

Envelopes conservam o formato JSON protegido com `content_base64`. Escrita, validação e restauração de binários usam blocos de 192 KiB, SHA-256, leitura completa, verificação da identidade do arquivo e publicação atômica. O parser respeita escapes/ordem JSON, recusa chaves repetidas e limita metadados; não extrai conteúdo por expressão regular. O teto da pré-imagem de anexos continua 64 MiB de arquivos e 16 MiB de metadados.

Antes da exclusão, são preservados original, versão reduzida, tamanhos e backup sizes, junto de post, metadados, termos, revisões, comentários e filhos dentro dos limites. Falha de backup impede a chamada destrutiva. Relações de proteção entre pré-imagem e backups filhos também ficam em registro durável próprio para resistir à reconstrução do índice. Listagem, reconstrução de índice, exportação em partes e seleção de retenção não materializam todo o binário na memória.

`files/restore` restaura cada backup filho. O `backup_id` da pré-imagem de metadados não é um backup de arquivo. Não há `media/restore`. Recuperação assistida completa exige ler a pré-imagem, restaurar os binários pelos IDs filhos e reconstruir o anexo/metadados/relações pela administração nativa ou SQL em duas fases, com backup. Conferir IDs/URLs, hashes e relações. Hooks externos podem ter efeitos não reversíveis. No laboratório a reconstrução foi feita pelas APIs nativas a partir da pré-imagem.

Restauração PHP preserva a barreira de recuperação/sonda existente, com validação limitada a 2 MiB e orçamento de memória; arquivos maiores são recusados antes da escrita. Não há promessa de restaurar PHP arbitrariamente grande pelo caminho binário.

## Diagnóstico do marcador cron

`system/health.cron.scheduling` adiciona `contract:mcp-cron-marker/1`, escopo `site_marker_only`, hook, estado, releitura persistida/efetiva, última operação e incidentes. Trata exclusivamente `f3_mcp_cron_observed`. Não altera agendas do Google/Core.

`confirmed` exige pós-condição persistida e efetiva; `failed` conserva o erro nativo; `unconfirmed` indica prova insuficiente; `unobserved`, ausência de evidência. Callback executado e marcador persistido são observações distintas. Falhas nativas de reschedule/unschedule conservam código, intenção, timestamp, argumentos por hash e origem. O histórico tem limite de 100 incidentes; excedentes incrementam `untracked_errors` e tornam a cobertura incompleta. A leitura não repete callback nem resolve incidentes por idade. Desativar limpa o evento próprio de argumentos vazios e preserva dados; reativar confere a nova agenda.

Locks cobrem os participantes MCP. Plugins ou operadores que escrevam o cron diretamente podem concorrer; divergência é reportada, sem garantia global entre todos os escritores. Esta mudança não demonstra a causa de erros `could_not_set` observados em produção.

## Integração e distribuição

Matriz local: Core 1.30.0, Google 0.8.3, WordPress 7.1.2, PHP 8.3.6. Descoberta dinâmica continua usando os schemas reais. Core oferece 123 abilities e Google 282 distribuídas por seus namespaces. Novos contratos Core de Slack/qualidade/publicidade permanecem responsabilidade do Core; schemas de status/manutenção Google e resultados incompletos conservam suas distinções. Não foram enviados avisos Slack nem executadas chamadas externas Google/Pipedrive nos testes MCP.

Atualização Core não está concluída só porque um GET funcionou: a finalização depende do executor após a janela nativa. Recuperação preserva guardas atuais e requer gerações corretas, reconciliação e retomadas separadas (Google primeiro, Core depois). Não substituir `f3-core-state`/`f3-google-state` por sentinelas antigas, não reapresentar ações externas históricas. Não há promessa de downgrade do Core.

Instalador versionado, sem update feed, validação por SHA-256 e fora de `auto_update_plugins`. Aplicar em site piloto por ordem do dono, reler catálogo e revisões, conferir HTTP/SEO e só então executar alterações tipadas autorizadas. A entrega não executa rollout ou limpeza na frota. Monitoramento de sete dias e temas pendentes dos outros projetos não são comprovados por estes testes locais.
