# Entrega 0.19.0

Instalador, fonte reproduzível, relatório e SHA256SUMS-0.19.0.txt. Pasta WordPress: wp-mcp-fator3. O relatório-base dentro do fonte evita circularidade do hash do próprio arquivo. A entrega não publica feed nem instala o pacote nos sites da frota.

Build determinístico: tools/build_packages.py. Manifesto, equivalência ao fonte, sintaxe e diferenças contra 0.18.0: tools/check_package.py. Schemas e exemplos: tools/check_documentation.py. Fonte: tools/pack_source.py. Extraia o fonte e reconstrua para comparar os bytes do instalador.

O pedido 47 tem implementação e ensaio de gramática equivalente; o arquivo exato Padrão §5.2 não foi fornecido. O pedido 48 tem ensaios de resposta lenta, timeout, reconciliação e falha real. Esses resultados não constituem homologação automática dos sites citados pelo solicitante.
