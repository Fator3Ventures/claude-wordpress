# Fator3 MCP 0.21.0

Entrega dos pedidos 56–59 e correção do diagnóstico do marcador cron. O pedido 46 permanece disponível em `content/delete-term`, com duas fases, backup e prova de ausência do termo e das relações órfãs. Nenhuma dessas limpezas ocorre na ativação.

## SEO — pedidos 56 e 57

`content/deduplicate-seo-indexables` preserva o menor ID completo. Referências externas ao ID preservado são permitidas. A hierarquia própria das duplicadas é removida, inclusive quando seu ancestral é outro objeto. Uma linha sobrevivente que aponte para ID a remover, ou links não modelados envolvendo duplicadas, bloqueia a operação. A releitura verifica a linha preservada, seus metadados, hierarquia sobrevivente e links.

`content/delete-orphan-seo-indexable` recebe `indexable_id`. A primeira chamada devolve resumo e `confirm_token`; a segunda repete a identidade e o token. Atende indexables Yoast de posts, páginas e termos. Ausência é demonstrada pelas tabelas nativas, não por HTTP 404. Post privado/lixeira e termo existente em taxonomia desregistrada permanecem protegidos. O schema conhecido de Yoast e InnoDB são requisitos; esquema/dependência desconhecidos bloqueiam. Pré-imagem privada limitada a 1.000 linhas e 4 MiB, transação e releitura de ausência do indexable, hierarquia e links. Repetição da confirmação retorna o recibo. Exige perfil Manutenção, manage_options e capacidade SEO.

## Backups — pedido 58

`backups/prune category:backups` admite dois modos: `artifact_ids` (1–200 IDs únicos) ou política de idade/volume/quantidade com `exclude_ids`. Não misture os modos. IDs atuais de 24 caracteres e legados são aceitos; categorias SQL conservam IDs de 32 caracteres e recusam exclusões não suportadas. ID inexistente é bloqueado explicitamente; nunca aciona a política padrão.

A prévia vincula seleção, conexão, critérios e corte de idade. O cursor vincula também as exclusões. Confirmar usa `dry_run:false` e `expected_selection_sha256`. Seletores repetidos devem corresponder à prévia. Novo backup não entra no lote; mudança de componente ou referência bloqueia a aplicação. Pré-imagens referenciadas continuam protegidas. Exclusões por ID não vencem automaticamente: preservar até 18/10 é uma escolha operacional, sem regra de data hardcoded no plugin.

`selected_bytes` mede os componentes selecionados; `removed_bytes` soma os componentes com remoção confirmada no lote congelado, sem contar duas vezes a repetição. `removed_bytes_complete:false` sinaliza componente interrompido cuja remoção ainda não foi comprovada. Não representa espaço livre medido no volume. Inventário incompleto, bloqueios e remanescentes ficam explícitos.

`plugins/rollback` aceita `dry_run:true`: verifica permissão, vínculo do diário/backup, hash da pós-imagem e integridade da pré-imagem, sem restaurar árvore, alterar ativação ou diário. A prévia é pontual; a aplicação revalida sob locks de pacote/backups. `rollback_ready`, `already_restored` e `preimage_verified` distinguem os estados. Omissão de `dry_run` mantém a restauração existente. Não promete desfazer migrações de banco ou efeitos de hooks.

## Tokens — pedido 59

`system/maintenance category:oauth-tokens` aplica o predicado de elegibilidade antes do LIMIT de 100 itens. Recibos compactados recentes não escondem os vencidos restantes. Preserva tokens válidos, expiração desconhecida e a proteção de reutilização de refresh enquanto o grant estiver ativo; purge exige expiração, compactação e alteração do grant antigas o bastante, conforme o contrato de 30 dias.

A prévia informa `remaining_eligible`, `remaining_scope`, `eligible_observed_at`, `eligibility_complete`, `has_more` e `next_before_id`. Após aplicar um lote, faça nova prévia sem cursor para examinar todos os remanescentes. Cursor serve para percorrer sem aplicar e limita o escopo da contagem. Falha de contagem retorna null e evidência incompleta, nunca zero presumido. Aplicação revalida revisões e grant; repetição usa recibo persistido.

## Cron — contrato mcp-cron-marker/2

`system/health.cron.scheduling` trata apenas `f3_mcp_cron_observed`. O estado atual não herda sucesso/falha de `last_operation`. Uma ocorrência positiva e estruturalmente válida, com argumentos exatamente vazios, hourly/3600 e igualdade das visões persistida/efetiva confirma a agenda ativa. Ordem de enumeração é normalizada. Evento vencido pode ser agenda válida; isso não prova saúde da execução.

`current_state` distingue active, missing, divergent, unexpected_shape, multiple_occurrences, inactive, unexpected_presence, intent_unknown, intent_conflict e read_failed. `desired_state` e `intent` informam intenção/origem/geração. Em inatividade com ambas as visões vazias, o estado principal é unobserved e `absence.status:confirmed` comprova separadamente a limpeza.

Ativação e desativação explícitas registram intenção. Na atualização, um plugin ativo sem intenção nova usa o contexto atual; recibo antigo de clear não determina inatividade. `init`, diagnóstico e bootstrap não recriam o marcador. Para reagendá-lo explicitamente, use o ciclo administrativo de desativação/reativação, após conferir a causa da ausência. Leitura não chama `_get_cron_array`, que pode migrar/gravar opções legadas.

Operações, callbacks, incidentes e overflow compartilham lock por site e gravação com releitura de recibo. Falha/timeout ficam em `diagnostic_persistence`; prova independente da agenda permanece visível. `history_complete` tem escopo de histórico recuperado e processo atual, não detecta processos externos mortos sem qualquer registro durável. Há até 100 incidentes e contador de excedentes. O erro nativo original permanece mesmo quando sua pós-condição foi comprovada. Nenhum callback é repetido pelo diagnóstico. Não há garantia de serialização de todos os escritores externos do cron.

## Integração Google e Core

Matriz executável fornecida: Core 1.30.0 e Google 0.8.3; catálogo real de referência com 123 e 282 abilities, respectivamente. Descoberta dinâmica é a autoridade. O plano Google 0.8.4 prevê configuration 4.0.0 e cron.scheduling 2.0.0; execution 2.0.0, server-integration/1.0.0 e policy_contract:1 permanecem.

O MCP encaminha os parâmetros nativos sem completar `confirm_service_reduction`, `expected_revision` ou `expected_plan_hash`. `google/configure dry_run:true` continua na ferramenta de escrita e requer sua autorização. Sucesso com persisted:false, changed:false e operation_outcome:not_applied continua sendo simulação. Recusa de redução, diff de serviços e conflito permanecem explícitos; não há redirecionamento para google/prepare-operation, reservado às confirmações remotas do Google.

`checks.executor`, active_errors, incidentes históricos, health e work_health Google são evidências distintas, repassadas pelo transporte. A reparação do hook Google pertence ao Google; o MCP não altera esse hook nem o Core. O pacote final Google 0.8.4 não foi fornecido: os novos formatos são testados por fixtures de contrato, não por homologação de execução Google 0.8.4. A mesma ressalva vale para alterações apenas planejadas do Core 1.31.0.

## Instalação e limites

Instalação nova e atualização da 0.20.0 são bases de teste, sem trava por versão de origem. Schema MCP continua 2; URLs, perfis, credenciais, servidor, guardas SQL e SDK permanecem. Consulte o relatório para os testes efetivamente executados. O instalador contém somente runtime; os fontes incluem scripts, contratos e evidências. Não há rollout da frota, homologação de APIs Google reais, teste prolongado de produção, Redis/Memcached real ou matriz multisite completa nesta entrega.
