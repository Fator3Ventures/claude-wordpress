# Impacto dos plugins fornecidos na 0.19.0

A matriz local desta entrega usa Core 1.25.0 e Google 0.8.2 fornecidos pelo proprietário. Os fontes desses plugins permanecem intactos. A compatibilidade é por contratos; não há trava de igualdade de versões. As evidências desta release e o relatório delimitam os ensaios executados.

Core: o pedido 163 relaciona migração demorada, reconciliação e downgrade após apagar marcadores históricos. O MCP corrige a decisão de rollback por timeout e fornece diário consultável. Isso não torna reversíveis as migrações do Core nem implementa as demandas Core17, 150–152, 159, 163 e 164. Elas continuam com seu proprietário. A invalidacão do cache de página usa a API pública existente e não atesta limpeza de CDN externa.

Google: a 0.8.2 mantém 282 habilidades, execução/catálogo 2.0.0 e configuração 3.0.0. `google/status` e `google/storage-status` acrescentam `maintenance` 1.0.0. O MCP preserva `success:null`, contagens desconhecidas `null`, `inventory_complete`, `blocked_by`, idade da observação e erros; não converte desconhecido em sucesso ou zero. Sucesso da consulta não prova término da manutenção. Falha de limpeza não autoriza repetir uma escrita remota Google.

WP-CLI com `--user=<id>` não concede perfil MCP. A identidade `integration:user:<id>` precisa de concessão explícita e das capacidades WordPress. A atualização não eleva perfis. APIs Google são bloqueadas/simuladas nos ensaios locais; não se declara aceite de contas reais.

O relatório Google apresenta incremento p95 pareado de 114,061 ms na home e 124,593 ms no REST, acima da meta inicial de 100 ms. São medidas do laboratório Google, não medições desta release MCP nem previsão de produção. A 0.19.0 amplia o orçamento de verificação de pacotes e corrige a classificação de timeout; não promete resolver esse desempenho interno.
