# server-integration/1.0.0 — contrato instalado na 0.17.0

Contrato canônico L01/L02/I04/I05. Provedor `wp-mcp-fator3`; política de extensão continua `policy_contract:1`.

Identidade constante: `server_id:wp-mcp-ultimate-server`, `route:/mcp/wp-mcp-fator3`, `aliases:[/mcp/wp-mcp-ultimate]`. Slug, Text Domain, Update URI e nomes dos metatools permanecem.

Filtros públicos: `f3_mcp_create_default_server(bool $enabled, array $identity)` e `f3_mcp_default_server_config(array $config, array $identity)`. O primeiro usa true como default e compartilha a decisão entre categoria, habilidades, fábrica e diagnóstico. O kill-switch continua controlando autorização, independentemente do registro do servidor.

O segundo aceita contribuições em `tools`, `resources`, `prompts`; preserva defaults e os três metatools. Nomes novos precisam existir, estar públicos, ter tipo correto e pertencer a provedor aderente. Retornos inválidos preservam defaults e registram códigos sanitizados. ID, endpoints, autenticação e handlers não podem ser substituídos. Contribuições repetidas são deduplicadas. Este SDK é cooperação entre plugins PHP; não é isolamento contra PHP malicioso.

`Fator3\McpFiles\ServerContract::capabilities()` informa contrato, versão, identidade e disponibilidade do hook. `::status()` é observação local, sem HTTP ou montagem recursiva: `core_loaded`, `server_enabled`, `channel_enabled`, `registry_checked`, `server_registered`, `tools_ready`, `endpoints`, `errors`. Antes de registro, desconhecidos são null; URLs também são null até o WordPress inicializar WP_Rewrite. `external_connectivity_tested:false` distingue isso de conectividade externa comprovada. A fachada não devolve credenciais ou identidades de conexões.

Filtros `mcp_adapter_*` não controlam o núcleo embutido. O ciclo é `f3_mcp_adapter_init`. O mapa completo está em `server-hook-map.json` no fonte; os demais hooks são internos, sem estabilidade de SDK prometida. Hooks da Abilities API e `f3_mcp_register_providers` continuam compartilhados. O Fator3 não altera `elementor_mcp_enabled`, não desliga o servidor Elementor e continua descobrindo seus recursos públicos com URI em `meta.mcp.uri`.

Google 0.8.3 conserva `google/mcp-read` e `google/mcp-write` por um adaptador do MCP que verifica os metadados públicos e o provedor. Não chama APIs privadas Google. A contribuição Google ao filtro próprio é deduplicada. O executor opcional de leitura do canal também é preservado.

Somente uma chamada direta de ferramenta registrada no servidor Fator3, autenticada por OAuth/senha de aplicação, estabelece contexto interno de entrada. As duas bridges Google têm admissão explícita nesse contexto, verificando perfil e permissão nativa. Leitura não admite a bridge de escrita; Personalizado precisa permitir a bridge e o alvo final. O Google conserva seus gates e confirmações. Qualquer executor usado como alvo retorna `ability_executor_forbidden`, incluindo bridges Google e `mcp-adapter/execute-ability`. Parâmetros do cliente e outra porta MCP não fabricam esse contexto.

A integração PHP Core → Google permanece fora do transporte MCP. Não recebe perfil sintético, não depende de sessão MCP, nem ganha bypass pelo nome do provedor. O catálogo reflete as abilities realmente registradas pelo complemento instalado.

Parâmetros nativos dos provedores são preservados: por exemplo, `label` de `google/create-connection` chega ao callback Google. Normalização dos aliases do canal e remoção de seu rótulo de auditoria aplicam-se somente às habilidades próprias do MCP. A coordenação não reinterpreta campos de negócio dos complementos.

## Compatibilidade e ciclo do servidor

A 0.21.0 usa instalação nova e atualização da 0.20.0 como base de testes, sem trava por versão de origem. A matriz local é Core 1.30.0 e Google 0.8.3; versões são evidência da validação, não igualdade obrigatória no código. Não repete a captura histórica de credenciais nem eleva perfis. Options explicitamente falsas/vazias, prazos, revogações, recibos e confirmações SQL pendentes permanecem.

A primeira entrada REST/CLI conclui o registro público de habilidades após init e antes de compor tools, resources e prompts. Chamadas reentrantes durante registro/configuração não publicam um servidor parcial. ServerContract::status continua observacional. O aquecimento do Google permanece válido, mas não é necessário para corrigir o ciclo do MCP. Um erro de criação é diagnosticado e não marca a inicialização como concluída.


## Plano Google 0.8.4


Matriz executável fornecida: Core 1.30.0 e Google 0.8.3; catálogo real de referência com 123 e 282 abilities, respectivamente. Descoberta dinâmica é a autoridade. O plano Google 0.8.4 prevê configuration 4.0.0 e cron.scheduling 2.0.0; execution 2.0.0, server-integration/1.0.0 e policy_contract:1 permanecem.

O MCP encaminha os parâmetros nativos sem completar `confirm_service_reduction`, `expected_revision` ou `expected_plan_hash`. `google/configure dry_run:true` continua na ferramenta de escrita e requer sua autorização. Sucesso com persisted:false, changed:false e operation_outcome:not_applied continua sendo simulação. Recusa de redução, diff de serviços e conflito permanecem explícitos; não há redirecionamento para google/prepare-operation, reservado às confirmações remotas do Google.

`checks.executor`, active_errors, incidentes históricos, health e work_health Google são evidências distintas, repassadas pelo transporte. A reparação do hook Google pertence ao Google; o MCP não altera esse hook nem o Core. O pacote final Google 0.8.4 não foi fornecido: os novos formatos são testados por fixtures de contrato, não por homologação de execução Google 0.8.4. A mesma ressalva vale para alterações apenas planejadas do Core 1.31.0.

