# Encaminhamento Fator3 MCP 0.17.0 → Google 0.8.0

07/10/2026. Fonte Google 0.8.0 recebido e testado localmente, sem modificações. O encaminhamento planejado da 0.7.2 foi substituído pela análise do pacote final 0.8.0. O Site-Teste permaneceu com Google 0.7.1; não atribuir a ele testes da 0.8.0.

## Contratos e permissões

O MCP conserva `server-integration/1.0.0`, `policy_contract:1`, as bridges `google/mcp-read` e `google/mcp-write`, e parâmetros nativos. Não mudou o SDK execution 2.0/configuration 3.0 do Google. A integração é por contratos, sem exigir igualdade artificial da versão do provedor.

Foram exercitados registro frio, duas ordens de carga, deduplicação das ferramentas, consulta direta pelo handler, recusa da bridge como alvo de executor, alvo sujeito ao mesmo perfil, recusa de escrita pelo perfil Leitura e bloqueio Google durante recuperação. Capacidades humanas/Core não passam a conceder grants Google. Não foram emitidas credenciais novas, reabertos canais ou alteradas conexões reais Google.

## Resultado do selftest 0.8.0

A bridge entregou `success:true`, `execution_success:true`, `result_status:incomplete` e `complete:false`, sem erro MCP, quando o diagnóstico não tinha configuração/checagens externas completas. Isso não equivale a aprovação de acesso às APIs. Falha real continua `f3_google_selftest_failed`; erro de execução permanece `execution_error`. O código MCP não precisou mudar seu envelope para acomodar esse contrato.

As checagens usaram o plugin real com estados sintéticos e rede externa bloqueada; nenhuma API Google foi testada nesta entrega. Não há prova nova de acesso GA/Ads/GSC/Sheets/Drive/GTM. O catálogo do provedor permanece sob sua propriedade; a limpeza de migradores MCP não remove habilidades Google.

## Recuperação

O teste conjunto preparou/drenou Core e Google, restaurou banco com conexões sintéticas e manteve as guardas externas pausadas. Retomada Google→Core exigiu geração corrente e confirmação de reconciliação. Retomar um provedor não retoma o outro. A atualização do MCP, isoladamente, não aciona esses comandos nos provedores.

Nenhuma alteração obrigatória no plugin Google foi identificada para esta release. Manter no guia Google a distinção entre diagnóstico incompleto, falha e aprovação, e consultar o contrato corrente do servidor. `contexto_teste` do `system/probe` marca apenas HTTP à própria origem e não é propagado a APIs externas.
