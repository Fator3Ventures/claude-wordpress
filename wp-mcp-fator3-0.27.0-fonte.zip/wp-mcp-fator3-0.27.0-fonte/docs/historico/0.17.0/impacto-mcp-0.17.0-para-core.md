# Encaminhamento Fator3 MCP 0.17.0 → Site Core 1.24.0

07/10/2026. Código Core não modificado. Matriz local: MCP 0.17.0/Core 1.24.0/Google 0.8.0; Site-Teste: MCP 0.17.0/Core 1.24.0/Google 0.7.1.

## Integração preservada

`server-integration/1.0.0`, `policy_contract:1`, identidade do servidor, filtros exclusivos e ambas as URLs permanecem. Registro frio, tools/resources/prompts, permissões e ordem inversa de carga foram exercitados. Não é necessária alteração Core para a remoção dos migradores MCP. A versão de origem do MCP é referência de manutenção, sem gate no bootstrap novo.

Inventário documental atualizado para contrato Core 6.1.0/schema 7: `f3base_operacao_intencoes`, `f3base_consentimento_reparos`, `f3base_audiencia_404` e `f3base_leads.decisao_ref`, com prefixo real. O MCP não transforma esses nomes em whitelist de dump nem poda pendências de negócio. Recuperação local exercitou preparação/drenagem Core→Google e retomada Google→Core, guardas independentes e gerações. `manter_pausado:true` continua obrigatório ao recriar sentinela pelo procedimento Core.

## Pedido MCP 40: marca entregue; observabilidade da medição a definir no Core

`system/probe` aceita `contexto_teste:true` e o cabeçalho `X-F3Base-Teste:1`. Omitir ambos envia `0`; valores conflitantes são recusados. A resposta declara `classe_trafego` e `traffic_class_scope:outgoing_request`. Sondas internas de atualização/recuperação também saem como teste na 0.17.0.

O teste HTTP local confirmou que o resolver real `F3Base_Testes::resolver` da 1.24.0 reconhece teste/não marcado. A sonda no Site-Teste confirmou a classe de saída e PHP novo. **Não foi comprovada gravação de uma visita de sonda nas leituras de medição Core.** O código recebido resolve a marca nos coletores de eventos e nas operações que a suportam; um GET/HEAD da home não executa o JavaScript do navegador nem envia evento POST de análise/comportamento. Os logs HTTP importados também não ganham esse cabeçalho automaticamente. O MCP não deve inserir eventos sintéticos nessas tabelas para fazer o aceite passar.

Encaminhamento concreto ao responsável Core: definir se o aceite deve observar apenas a recepção da marca, ou criar observabilidade separada de sondas HTTP que conserve `classe_trafego`, sem somá-las como audiência humana. Se a fonte for log de acesso, especificar coleta/formato do cabeçalho e testes de segmentação. Tratar como extensão Core própria, não como mutação lateral pelo MCP. Nenhuma dessa instrumentação foi instalada nesta entrega.

## Pedido MCP 41

Recusas anônimas nas rotas do canal agora aparecem em `audit/list` como `mcp/access-denied`/`mcp_authentication_required`, sem as quatro linhas de erro por requisição. O Core não precisa mudar seu coletor de logs. Diagnósticos reais continuam registrados. A auditoria MCP permanece sob sua retenção e não entra na retenção de estados de negócio Core.

As versões dos provedores são conferidas por seus contratos; a combinação do Site-Teste está separada da matriz local no relatório. Não houve configuração de APIs nem implantação dos provedores na frota.
