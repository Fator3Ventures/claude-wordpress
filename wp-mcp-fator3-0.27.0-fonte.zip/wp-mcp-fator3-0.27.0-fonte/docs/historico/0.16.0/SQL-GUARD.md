# selection-guard/2 — contrato instalado na 0.16.0

Guarda preservada de 0.15.0; extensão M38B do escopo de backup. `db/execute`, `db/batch` e `db/search-replace` usam este protocolo. `db/restore` verifica o destino das tabelas presentes no manifesto; o dump integral conserva o alcance global. SQL não é aceito por `operations/plan`.

## Duas fases

Chame sem `confirm_token`. A resposta é prévia, com `applied:false`, token, `operation_id` e validade de 600 segundos. Repita os mesmos parâmetros com o token. A guarda privada está vinculada à intenção, credencial, usuário, site e contrato. Uma confirmação concluída devolve o recibo com `replayed:true`; uma operação iniciada sem recibo final devolve `operation_uncertain` e nunca se reaplica automaticamente. Consulte `operations/status`.

Tokens SQL pendentes da 0.15.0 preservam intenção, identidade, guarda, prazo e escopo integral quando omitido. Recibos concluídos e estados incertos continuam consultáveis. A atualização não captura novamente credenciais históricas.

`guard_contract:selection-guard/2`; `guard_scope:selected_rows_and_dependencies` ou `ddl_objects`; `target_tables`; `selected_rows`; `selection_exact`; `backup_scope:database` ou `selected_tables` em db/execute elegível; `backup_tables`. O antigo inventário global `summary.tables` deixa de ser a guarda de DML. `statement_previews.predicted_affected_rows` vem da simulação sequencial; `affected_rows` na aplicação vem do MySQL real. db/execute apresenta 20 linhas por padrão (`limit_preview`, máximo 200); demais prévias apresentam no máximo 200 linhas; a guarda cobre a seleção integral dentro do orçamento.

## SQL aceito e limites explícitos

| Forma | Cobertura |
|---|---|
| UPDATE/DELETE | Um alvo físico InnoDB, predicados, expressões determinísticas, alteração de chave, NULL, binário, Unicode; chave primária ou única não nula |
| JOIN | INNER JOIN, um alvo de escrita, sem duplicar identidade alvo; todas as linhas participantes influenciam a guarda |
| Subconsultas | Um nível em WHERE: IN e EXISTS; fontes físicas explícitas e predicado; fontes recebem suas próprias leituras bloqueantes |
| ORDER BY/LIMIT | LIMIT requer ORDER BY em colunas diretas contendo a identidade completa, inclusive no INSERT SELECT; seleção sem ordem total é recusada |
| INSERT/REPLACE | Lista explícita de colunas, VALUES; todas as chaves únicas, colisões e ausências; upsert com ON DUPLICATE KEY UPDATE |
| INSERT SELECT | Uma fonte física diferente do destino, projeção determinística e filtros; sem agregação/janela/UNION |
| Lote | Até 100 instruções DML; dependências sequenciais simuladas. Cada instrução tem uma fonte física; JOIN/subconsulta em lote e identidade autoatribuída em lote exigem reescrita explícita |
| DDL | CREATE TABLE, ALTER TABLE, DROP TABLE e TRUNCATE TABLE sobre um objeto. Sem IF EXISTS, RENAME, FK, PARTITION, tablespace, CREATE SELECT/LIKE ou rotinas |
| Search-replace | Seleção literal de linhas/colunas, chave primária; preserva objetos serializados e chaves primárias; valores únicos resultantes participam da guarda. Tabela selecionada sem chave causa recusa antes do token |

Expressões admitem aritmética e funções determinísticas declaradas no planejador, como CONCAT, REPLACE, COALESCE, IFNULL, CAST, CONVERT, HEX, UNHEX e funções JSON de valores. Funções não classificadas, funções temporais aleatórias, variáveis de sessão, views, tabelas sem identidade estável, índices únicos parciais/funcionais, colunas geradas/ON UPDATE, triggers e FKs não modeladas recebem `sql_guard_unavailable`, sem token utilizável e sem escrita. Não há fallback para a impressão do banco inteiro. UPDATE de vários alvos e autorreferência à mesma tabela por outro alias também são recusados. Consulte o erro `reason`; não altere dados para contornar a recusa.

A implementação materializa cópias temporárias das tabelas envolvidas para calcular o efeito sequencial, sem DML de ensaio na base real. Essa materialização é limitada a 100.000 linhas por leitura, 64 MiB acumulados e 30 segundos. O orçamento inclui cópias intermediárias e metadados, portanto uma tabela grande pode esgotá-lo mesmo com seleção pequena. Nesse caso retorna `sql_selection_budget`; a seleção nunca é truncada e assinada como completa. Use operações tipadas ou reduza a operação. O tokenizador admite até 8.192 tokens por instrução. Essa é uma limitação operacional explícita desta implementação.

## Concorrência, backup e resultados

Pré-imagens completas e seleções são assinadas com HMAC privado, preservando tipo estrutural, bytes e NULL. O contador corrente AUTO_INCREMENT não participa da guarda DML; o atributo da coluna permanece. DDL conserva o contador no schema de seu alvo.

A confirmação usa uma conexão MySQL fixa e REPEATABLE READ. Antes de criar a visão consistente, lê com FOR UPDATE as seleções, dependências, identidades e intervalos pertinentes. Os locks impedem alterações externas durante backup e escrita. Conforme índices e plano de execução, o InnoDB pode bloquear vizinhos examinados. Uma mudança fora da seleção entre prévia e confirmação não cria conflito só por pertencer à mesma tabela. Leituras de dependências são conservadoras dentro dos predicados modelados, especialmente fontes de IN/EXISTS.

O dump de recuperação é integral por padrão. db/execute admite selected_tables nas condições descritas em SQL-RETENTION.md. Ambos são privados e contêm valores originais, inclusive segredos. É produzido por leituras consistentes, sem FOR UPDATE em todas as tabelas. Falha de gravação/verificação cancela a aplicação. O volume do dump pode dominar a duração da operação; não equivale ao escopo da guarda. DML falha por rollback da transação, sem restaurar automaticamente o banco inteiro. DDL exige recuperação por snapshot e usa trava do objeto na conferência final. Restauração integral é outra operação explícita.

`database_conflict` inclui `conflict:true`, `applied:false`, `changed:false`, e `conflict_reason` (`target_rows_changed`, `selection_changed`, `dependency_changed`, `schema_changed`, `unique_key_changed`). Faça nova prévia e revise a diferença. Timeout SQL (`database_lock_timeout`), deadlock (`database_deadlock`), orçamento, backup indisponível e expiração são erros separados. A espera de locks SQL é 5 segundos; não é o `lock_wait_seconds` de arquivos.

`changed` depende das instruções efetivamente executadas. Não compara todo o banco após a escrita. O recibo inclui `statement_results`, `backup_id`, `readback`, `atomic` e estado persistido. Perda do recibo depois de commit deixa a operação incerta, com backup e ID para investigação. Não interprete `applied:null` como falha sem efeito.

Redação na prévia evita exposição acidental de tokens e colunas sensíveis. Um administrador com instalação de código e SQL pleno não fica isolado dos dados por essa redação. Guarde os backups com o mesmo cuidado dedicado ao banco original.
