# Encaminhamento ao Fator3 MCP Google — MCP 0.15.0

Data: 01/10/2026. Versão MCP estável implementada. Google 0.6.0 real exercitado; seu código não foi alterado. Documento preparado para encaminhamento pelo responsável, sem envio automático.

## O que o MCP entregou

O contrato `server-integration/1.0.0` está disponível por `Fator3\McpFiles\ServerContract::capabilities()` e `::status()`. O filtro de contribuição é `f3_mcp_default_server_config(array $config, array $identity): array`. A identidade contém `provider:wp-mcp-fator3`, `server_id:wp-mcp-ultimate-server`, `route:/mcp/wp-mcp-fator3` e o alias `/mcp/wp-mcp-ultimate`.

O núcleo Fator3 deixou de consumir os filtros genéricos `mcp_adapter_*`. Para Google 0.6.0, o MCP inclui explicitamente `google/mcp-read` e `google/mcp-write` quando seus metadados pertencem ao provedor aderente e correspondem à modalidade. Não chama API privada Google. Contribuições futuras pelo hook próprio são unificadas por nome, sem duplicação.

Permanece `f3_mcp_register_providers`, com provedor `wp-mcp-google-fator3`, versão real e `policy_contract:1`. O contrato de configuração Google e sua versão de produto não substituem essa política.

## Ferramenta direta, alvo final e parâmetros

As ferramentas externas `google-mcp-read` e `google-mcp-write` podem iniciar uma chamada direta autenticada no servidor Fator3. O contexto interno é criado pelo transporte, vinculado à requisição/servidor/credencial e encerrado ao sair. Não é um campo fabricável na entrada do agente.

Perfil de conexão, permissão WordPress, gates Google e autorização do alvo final continuam valendo. O perfil Leitura não pode usar a bridge de escrita; Personalizado precisa permitir a bridge e o alvo. Um executor usado como alvo de outro executor continua recusado com `ability_executor_forbidden`, incluindo as próprias bridges Google.

**Não remover `executes_ability:true` nem contornar `Channel::authorize()`.** A admissão da ferramenta direta não autoriza indiscriminadamente seus alvos. Confirmações, quotas e auditoria continuam com o Google.

Foi encontrado e corrigido no MCP um defeito adicional: `ExecutionCoordinator` removia `label` como se todo campo pertencesse ao rótulo de auditoria do canal. A 0.15.0 preserva os parâmetros nativos do provedor e limita a normalização de aliases às habilidades próprias. A criação de uma conexão sintética por `google-mcp-write` → `google/create-connection`, com `label`, passou no Google 0.6.0 real. Não foi criada conexão externa nem alterada credencial Google no site de testes.

## Mudanças solicitadas ao Google 0.7.0

| Ponto | Ação do projeto Google |
|---|---|
| Bridge | Adotar o hook próprio, validar contrato/provedor/ID e acrescentar apenas abilities registradas |
| Fallback 0.14 | Se o plano Google o mantiver, restringir o hook antigo inequivocamente ao canal 0.14; MCP 0.15 não depende dele |
| Diagnóstico | Consultar `ServerContract::status()`; respeitar `null` antes do registro e URLs desconhecidas antes de WP_Rewrite |
| Conectividade | Não transformar classe carregada em prova de acesso externo; o diagnóstico local não faz HTTP |
| Elementor | Não escrever `elementor_mcp_enabled` nem modificar seu servidor para configurar o Fator3 |
| Catálogo futuro | Remover as abilities/campos do importador conforme o plano Google; MCP descobre o registro real |

O serviço PHP `search-console-reader/1.0.0` deve permanecer independente de sessão/perfil MCP. MCP desligado não retira a concessão interna; Google desligado ou concessão revogada deve interromper o serviço. Não publicar esse consumidor como executor genérico nem aceitar `actor` como autorização.

Ainda precisam ser resolvidos no projeto Google os pedidos recebidos do Core: `budget_ms` explícito, `trigger:cli|http_cron|manual` e `last_pass` por origem/janela. Esta entrega não implementa essas mudanças nos complementos.

## SQL, snapshot e recuperação

As gravações normais Google em auditoria, quotas, options e `{prefix}f3_google_records` podem continuar. A guarda SQL passa a observar a seleção e suas dependências, não uma impressão do banco inteiro. Não suprima essas gravações para fazer a confirmação passar.

Foi corrigida a preservação indevida de `f3_mcp_google_*` como estado MCP. Em novos dumps/restaurações, options Google e sua tabela retornam ao mesmo snapshot; o estado MCP corrente é preservado por inventário explícito `preserved-state/1`. A prova local alterou options e tabela entre exportação e restauração e verificou a coerência resultante. Nenhum nome Google foi migrado ou renomeado no update normal MCP.

Diários de recuperação 0.14 existentes continuam legíveis com sua semântica original. Pausar e reconciliar trabalhos antes/depois de restauração é responsabilidade operacional dos complementos. Dump não desfaz efeitos remotos; rollback de pacote não desfaz migração de dados Google. Documentar quais options/tabelas compõem seu estado, sem divulgar valores secretos.

## Evidência e próxima verificação conjunta

Foram executadas leitura e escrita local reais pelas bridges, negações por perfil/alvo, recusa de executor aninhado, deduplicação, diagnóstico antecipado e coexistência com Elementor em seis combinações. No site de testes, Google 0.6.0 permaneceu ativo e `google/status` respondeu após a atualização MCP.

As fixtures de contrato futuro verificam deduplicação e independência de serviço PHP sintético. Não provam chamadas Search Console nem persistência do futuro Core 1.20.0/Google 0.7.0. Repetir essas provas com os fontes finais dos dois projetos, incluindo revogação do consumidor e restauração coerente de seu estado.
