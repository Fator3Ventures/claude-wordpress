# Atualização para Fator3 MCP 0.16.0

Entradas suportadas: instalação nova ou MCP 0.15.0. Convivência exclusivamente Core 1.22.1 e Google 0.7.1; nenhum desses pacotes é substituído pelo instalador MCP. Não há matriz de migração de versões mais antigas.

1. Confira SHA-256 e guarde o instalador anterior e acesso ao WordPress/hospedagem.
2. Instalação limpa: envie wp-mcp-fator3-0.16.0-instalador.zip pelo wp-admin, ative e configure credencial/perfil. Identidades novas não recebem Manutenção automaticamente.
3. Na 0.15.0: use plugins/upload com URL do ZIP, expected_sha256, expected_slug:wp-mcp-fator3 e overwrite:true, ou substitua pelo wp-admin. O mecanismo mantém ativação anterior, backup e sondas independentes. Consulte active_before/active_after e recovery_status.
4. Confira system/capabilities.plugin_version, as duas URLs existentes e system/guide. A credencial e o perfil anteriores devem permanecer.
5. Avance backups/list category:sql_artifacts até inventory_complete:true. Nada é apagado durante atualização. Faça poda somente após revisar uma seleção.

O registro de release 0.16.0 é idempotente e separado da captura histórica de credenciais. Checkpoints, revogações, políticas, IDs e prazos existentes são preservados. Confirmações SQL 0.15.0 mantêm selection-guard/2 e backup integral quando o campo era omitido. Trocar backup_scope exige nova prévia.

Rollback de pacote restaura arquivos, não desfaz efeitos externos. O formato do índice é aditivo e não apaga dados no upgrade. Recuperação de banco é uma operação distinta: siga RECUPERACAO-CONJUNTA.md e o manifesto do dump. Um restore reduzido pode criar uma pré-imagem integral de segurança.

Distribuição por ZIP versionado e hash. Update URI:false continua sem feed público; configurar origem não habilita atualização automática.
