# MCP 0.16.0 → Base Site Core 1.22.1

Data: 07/10/2026. Release MCP estável implementada e instalada no Site-Teste. Compatibilidade exclusivamente com Core 1.22.1 e Google 0.7.1; instalação nova ou MCP 0.15.0. Não foram alterados arquivos Core (274 arquivos do instalador comparados, todos idênticos).

## Contratos preservados

O servidor prepara a Abilities API antes de compor contribuições, com guardas de reentrada. SDK `server-integration/1.0.0`, `policy_contract:1`, identidade e URLs permanecem. Status antecipado continua sem efeitos de inicialização. A permissão nativa de cada alvo continua obrigatória; o MCP não concede `f3base_ler_leads` nem modifica grants Google.

## Efeito operacional

A 0.16.0 permite dump de uma tabela em DML elegível e restore limitado ao manifesto. Se opções/tabelas Core forem restauradas parcialmente, o operador deve reconciliar o conjunto. O MCP não cria um migrador de dados privados Core.

Para recuperação: ler `f3base/operacao-recuperacao-ler`; preparar com geração corrente; aguardar `pronto_para_restaurar:true`, além da guarda Google pronta; restaurar; reler as duas guardas; reconciliar e retomar cada uma. Recriação de sentinela usa o contrato Core `precondicao_esperada`/`manter_pausado:true`, seguida de preparo/drenagem. O MCP não altera esse procedimento.

Retomada Core pode invalidar intenções/filas/cursores em tabelas fora do manifesto. Esses efeitos continuam sendo atribuídos ao Core e devem ser registrados separadamente. A pausa Core não drena todo o WordPress.

## Provas

- Instalação nativa do Core 1.22.1 concluída no laboratório, sem fabricar checkpoint.
- Capacidade `f3base_ler_leads` sem manage_options aceita a leitura; manage_options funciona como alternativa nativa; ausência de ambas recusa a leitura.
- Trabalhador Core real em outro processo impediu prontidão antes da drenagem; o preparo concluiu após sua liberação.
- Restore integral com Core/Google reais, duas conexões Google e estado MCP corrente preservado; ambas as pausas sobreviveram.
- No Site-Teste, restauração limitada a tabela sintética, Core pausado antes/depois, retomada explícita da geração 1 para 2; efeitos nas filas e cursores examinados: zero.
- Mudanças de papéis preservaram opções/concessões Google no laboratório.

## Ação para o projeto Core

Nenhuma mudança obrigatória de código identificada. Atualizar a referência de compatibilidade e o guia conjunto para MCP 0.16.0, especialmente o alcance por manifesto e a distinção entre restore SQL e efeitos de retomada Core. Não remover nem condicionar por versão a própria guarda de recuperação. Os arquivos Core permanecem responsabilidade do projeto Core.

Instalador MCP SHA-256: `4b4081a9f3c1c22156d284b01ab023d4a33ae388fd68c44b599a0ac546ccc0e7`. Evidências no fonte MCP: companions-tests.json, core-permissions.json, full-recovery-tests.json, site-test-0160.json e companions-byte-comparison.json. Não houve validação de contas Google externas nem implantação na frota.
