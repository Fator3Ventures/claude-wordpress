# Fator3 MCP 0.15.0 — plano de implementação

Data: 01/10/2026. Revisão: 1. Estado: planejamento, sem alteração dos plugins e sem implantação. Versão proposta: **0.15.0**, em uma única entrega. A numeração minor identifica os novos contratos de integração e de confirmação SQL; não haverá releases intermediárias previstas neste plano.

## 1. Resultado, entradas e limites

Entregar integralmente os pedidos MCP **35, 36 e 37**, com os ajustes de integração identificados na revisão dos três códigos. O MCP mantém transporte, identidade, autorização dos agentes, operações WordPress, confirmação, backup e auditoria. O Core e o Google conservam suas responsabilidades de negócio.

Existem somente duas entradas suportadas:

1. WordPress sem instalação/dados anteriores do MCP: criar diretamente o estado da 0.15.0.
2. WordPress com **MCP 0.14.0**: atualizar preservando conexões, políticas, credenciais, dados e operações persistidas daquela versão.

A instalação 0.14.0 pode conter histórico originado em versões anteriores, credenciais ainda válidas e recuperação pendente. Esses dados pertencem à base suportada. Retirar uma cadeia de migração antiga não autoriza apagá-los, elevar permissões ou exigir reconfigurar os conectores.

Não modificar Core nem Google. Seus códigos atuais são **Core 1.19.0** e **Google 0.6.0**; Core 1.20.0 e Google 0.7.0 foram fornecidos como planos, não como implementações. Relatórios separados especificam o que cabe a cada projeto. Os pedidos atuais prevalecem sobre planos antigos já superados.

Não reabrir itens retirados da lista como entregues. Não incluir fonte pública de atualização, execução PHP arbitrária, rota de frota, SQL em uma fase, desligamento do servidor Elementor, configuração de crontab ou mudanças site a site. Não ampliar a matriz para multisite, SQLite ou outros bancos.

## 2. Base examinada e precisão das conclusões

Foram lidos os dez documentos encaminhados e examinados os três fontes. O fonte MCP foi recuperado da entrega anterior; seu SHA coincide com o informado nos planos Core/Google. As cópias antigas dos complementos dentro daquele fonte não foram usadas como base atual.

| Fonte | SHA-256 |
|---|---|
| MCP 0.14.0 | `02a07184f3978023d0670e19f1c2220cacf02f3e2a78ee8edc1a9fc1855b56bc` |
| Core 1.19.0 | `b9ed942b4007a79a4cae58bab23635b5acc34a0644db07dcf79a5addf098d515` |
| Google 0.6.0 | `aa3633164486b691e3e7336f87c965f64712bb6b029ead289e8ca389135f2ff2` |

Esta revisão é estática. Os incidentes e a instalação da 0.14.0 nos 14 sites são evidências fornecidas pelos pedidos. Não houve chamadas à frota, execução de PHP/MySQL, teste de Elementor nem homologação nesta etapa. O documento de pedidos informa que o gate da entrega 0.14.0 continua aberto; estar instalada não equivale a fechar esses aceites.

Caminhos abaixo relativos à raiz de cada plugin:

| Achado | Evidência | Consequência |
|---|---|---|
| Criação, categoria e metatools dependem do filtro genérico | MCP `core/includes/Server/McpAdapter.php:268,281,300` | Corrigir os três pontos, não só a criação da rota |
| Diagnóstico e cache de teste repetem a mesma dependência | MCP `includes/ConnectionStatus.php:10` e `fingerprint()` | Compartilhar uma única decisão de habilitação |
| Configuração e ciclo de inicialização também são globais | MCP `DefaultServerFactory.php:64`; `McpAdapter.php:95,176,272` | Isolar o ciclo do adapter embutido, incluindo validação de timing |
| Google acrescenta ferramentas sem identificar o servidor | Google `includes/McpBridge.php:17–22` | Contrato próprio; convivência explícita com Google 0.6 |
| A confirmação usa o banco inteiro em dois lugares | MCP `DatabaseAdmin.php:91,95–96`; `Release014.php`, `Phase::run()` | Separar resumo da prévia e guarda de concorrência; retirar ambas as comparações globais |
| O hash estrutural inclui o texto bruto de SHOW CREATE TABLE | MCP `DatabaseAdmin.php:23–25` | Excluir contador corrente de AUTO_INCREMENT da comparação estrutural DML |
| A prévia SQL usa conexões diferentes em um dos caminhos | `DatabaseAdmin.php:78`; `SqlSelection::rows()` usa `$wpdb` | Usar a mesma conexão transacional na seleção, trava, comparação e aplicação |
| Executores Google aderentes recebem um bloqueio geral | Google `McpBridge.php`, `meta.fator3.executes_ability`; MCP `AbilityRuntime.php:78–84` → `AuthorizationPolicy::check()` | Distinguir ferramenta direta registrada de executor usado como alvo de outro executor |
| Preservação de options na restauração inclui o prefixo Google | MCP `DatabaseAdmin.php:118–123`, expressão `^f3_mcp_`; Google usa `f3_mcp_google_*` | Tornar explícita a propriedade do estado preservado; evitar mistura de snapshots |
| Build exige origem pública e acrescenta sufixo de homologação | MCP `tools/build_packages.py:34–51` | Adequar à decisão de ZIP versionado sem feed; manter verificações técnicas |

O bloqueio dos executores Google decorre do fluxo estático quando o provedor está aderente e a permissão nativa passa. Não é apresentado como incidente reproduzido na frota. A colisão de options na restauração também é um achado estático. A tabela atual Google é `{prefix}f3_google_records`, não `{prefix}f3_mcp_google_*`: a colisão identificada é no tratamento de options/transients, não no nome dessa tabela.

## 3. Escopo rastreável da entrega

IDs `I`, `U` e `D` são internos deste plano. Não atribuem nova numeração à lista da frota.

| ID | Origem | Entrega | Responsável |
|---|---|---|---|
| M35 | Pedido MCP 35 | Servidor, metatools e diagnóstico independentes dos filtros Elementor/adapter genérico | MCP |
| I01 | Encaminhamentos Core/Google | SDK de configuração exclusivo, evidência pública local e preservação da bridge Google 0.6 | MCP; adaptação futura da bridge: Google |
| I02 | Revisão de código | Autorização de ferramentas diretas sem abrir execução aninhada | MCP |
| M36 | Pedido MCP 36 | Guarda SQL por seleção/dependências reais, transação, backup e resultado do próprio efeito | MCP |
| I03 | Revisão de código | Propriedade explícita do estado preservado na recuperação de banco | MCP; validação de convivência: Google/Core |
| M37 | Pedido MCP 37 | Marca visual, metadados, nomes de arquivos e relatório de release | MCP |
| U01 | Restrição do dono | Instalação limpa e atualização exclusiva da 0.14.0; remoção de caminhos antigos desnecessários | MCP |
| D01 | Pedidos e integração | Documentação canônica, testes, evidências e empacotamento | MCP |

Todos os oito IDs compõem a mesma release. Etapas internas não significam versões intermediárias. Correções de incidentes são implementadas e testadas primeiro; não serão condicionadas ao desenvolvimento do importador GSC dos outros projetos.

## 4. M35 — servidor Fator3 independente

### 4.1 Controle único

Criar um serviço interno de configuração do servidor com identidade constante e uma decisão de habilitação reutilizada pela criação, registro da categoria/metatools, painel, `system/health`, status local e impressão do teste de conexão.

Filtro público proposto: **`f3_mcp_create_default_server`**, valor padrão `true`, segundo argumento com identidade do servidor. Não ler nem escrever `mcp_adapter_create_default_server`. O kill-switch atual continua bloqueando o canal e suas operações; um filtro não pode reabrir acesso recusado pelo kill-switch. Registrar servidor e autorizar uma chamada continuam sendo estados diferentes.

Não mudar `elementor_mcp_enabled`. Seu valor ausente, falso ou verdadeiro não governa o canal. Não ligar à força o filtro global e não remover hooks do Elementor.

### 4.2 Completar o isolamento do adapter embutido

Substituir o ciclo interno `mcp_adapter_init` pelo ciclo próprio `f3_mcp_adapter_init`, incluindo `doing_action()`, callbacks da fábrica e comandos que dependam desse timing. Inventariar os outros `mcp_adapter_*` usados pelo núcleo embutido — configuração, transporte, sessão, nomes, listas, chamadas, recursos e prompts — e movê-los ao namespace próprio com um mapa explícito no fonte. Hooks internos não viram automaticamente SDK público.

O objetivo é impedir que callbacks feitos para outra classe de adapter recebam a instância Fator3, modifiquem ferramentas ou renomeiem metatools. O risco de fatal por callback tipado de terceiro é inferência do hook compartilhado; deve ser testado com fixture tipada e, depois, com o Elementor real. Não alterar os hooks WordPress da Abilities API nem `f3_mcp_register_providers`, que são compartilhados deliberadamente.

Preservar descoberta dos recursos Elementor e o suporte a `meta.mcp.uri`/`mimeType`. Isolar o servidor não significa retirar abilities ou recursos válidos de terceiros.

### 4.3 Aceite

Elementor 4.3.3 com `elementor_mcp_enabled` ausente, falso e verdadeiro; filtro genérico em `false`; ambos os sentidos de carregamento. Em todos os estados, Fator3 responde nas duas rotas e mantém seus metatools, salvo seu próprio controle desligado. O servidor Elementor conserva o estado escolhido por ele. Sem duplicação de servidor/categoria, fatal, recursão de `rest_api_init` ou novas linhas de erro repetidas a cada requisição.

## 5. I01/I02 — SDK e ferramentas dos complementos

### 5.1 Contrato público proposto: `server-integration/1.0.0`

Manter `policy_contract:1` e a assinatura de `f3_mcp_register_providers`. A versão do SDK de servidor é independente da versão do plugin e dos contratos de dados Core/Google.

Publicar:

- `f3_mcp_create_default_server(bool $enabled, array $identity): bool`.
- `f3_mcp_default_server_config(array $config, array $identity): array`.
- Fachada local `Fator3\McpFiles\ServerContract::capabilities()` e `::status()`, sem chamada HTTP, segredo ou inicialização recursiva.

Identidade imutável enviada aos filtros:

```json
{
  "contract": "server-integration/1.0.0",
  "provider": "wp-mcp-fator3",
  "server_id": "wp-mcp-ultimate-server",
  "route": "/mcp/wp-mcp-fator3",
  "aliases": ["/mcp/wp-mcp-ultimate"]
}
```

O filtro permite contribuições em `tools`, `resources` e `prompts`; não pode substituir ID, endpoints, autenticação, autorização, handlers de recuperação ou os três metatools obrigatórios. Validar tipos, existência, nomes únicos e autoria das contribuições. Retorno inválido conserva os defaults e produz diagnóstico sanitizado. Isso é contrato entre plugins PHP cooperantes, não isolamento de código PHP malicioso no mesmo processo.

Separar a identidade/configuração básica da resolução do catálogo. Contribuições de abilities só são resolvidas depois do registro da Abilities API; consultas antecipadas de endpoints/capacidades não podem forçar `wp_get_ability()` antes de `init` nem memorizar um catálogo vazio como definitivo. Testar as ordens de carregamento e a chamada antecipada do diagnóstico.

`capabilities()` informa contrato, versão e disponibilidade do hook. `status()` informa `core_loaded`, `server_enabled`, `channel_enabled`, `registry_checked`, `server_registered`, `tools_ready`, endpoints e códigos de falha; valores desconhecidos são `null`. `external_connectivity_tested:false` para essa observação local. Consultá-lo antes do registro não força montagem do servidor nem inventa falha. O diagnóstico autenticado já existente continua podendo apresentar histórico de conexões; a fachada não expõe identidades, tokens ou políticas.

### 5.2 Google atual e Google planejado

Remover a aplicação do filtro genérico faria as duas ferramentas diretas do Google 0.6 desaparecerem. Portanto, na própria distribuição MCP, incluir um adaptador pequeno que contribua **apenas** `google/mcp-read` e `google/mcp-write` quando essas abilities existirem, forem do provedor aderente `wp-mcp-google-fator3` e tiverem os metadados esperados. Ele não chama `McpBridge::init()` nem funções internas Google.

O Google 0.7 usará o novo filtro, validando contrato e identidade. Unir contribuições por nome, sem duplicação quando filtro e adaptador reconhecerem a mesma ferramenta. Não executar o filtro global como fallback. A compatibilidade aqui é com o outro plugin atualmente instalado, não com MCP antigo. Core não precisa desse adaptador: suas abilities seguem descobertas pelo registro.

Os três metatools originais são obrigatórios. As duas ferramentas Google e o executor opcional de leitura já existentes não serão removidos para forçar `tools/list` a ter exatamente três entradas. O teste confere os três nomes exigidos pelo pedido 37 e as ferramentas adicionais efetivamente habilitadas.

### 5.3 Separar entrada direta e alvo final

Hoje `AuthorizationPolicy::check()` recusa qualquer ability classificada como executor; o decorador também chama essa verificação na entrada direta do Google. Separar:

1. **Entrada MCP direta:** handler estabelece contexto interno de ferramenta registrada, associado ao servidor, à requisição autenticada e à conexão. Permitir somente os executores explicitamente registrados para essa entrada. Conferir permissões nativas, perfil, modo e configuração. Contexto em pilha, restaurado em `finally`; nenhum parâmetro do cliente pode criá-lo.
2. **Alvo de execução:** toda execução indireta passa pela política do alvo final. Um executor como alvo continua retornando `ability_executor_forbidden`, inclusive Google e `mcp-adapter/execute-ability`.
3. **Google:** a bridge conserva `Channel::authorize()` do alvo, classificação da operação, política da conexão Google, limites, confirmação e auditoria. Leitura não autoriza escrita; Manutenção não remove os gates Google.

Não criar exceção geral baseada só em `meta.fator3.executes_ability`, nome do provedor, usuário administrador ou presença de `actor=Core`. Não permitir a entrada direta por REST de terceiro, categoria genérica ou chamada aninhada que tenha herdado o contexto externo. Cada entrada deve validar o nome corrente e a profundidade.

### 5.4 Integração interna Core → Google

O contrato planejado `search-console-reader/1.0.0` é PHP local, de responsabilidade Google/Core. Não passa pelo servidor, não recebe perfil MCP e não deve depender de sessão de agente. Não decorar essa fachada como ability nem abrir exceção na política MCP para usuário 0.

Desligar o transporte MCP não desliga esse serviço. O controle global Google e a concessão do consumidor continuam podendo bloqueá-lo. O catálogo MCP reflete as abilities ativas: com Google 0.7, as três abilities do importador retirado deixam de aparecer; `google/status.gsc_import` é campo removido, não uma quarta ability. Contrato Core 5.0.0 e configuração Google 3.0.0 não alteram por si só `policy_contract:1`.

## 6. M36 — confirmação SQL utilizável em site vivo

### 6.1 Contrato da guarda

Trocar a impressão de todo o banco por um plano de mutação versionado, **`selection-guard/2`**. O plano registra SQL normalizado/hash, ordem das instruções, tabelas alvo, schemas relevantes, chaves/linhas selecionadas, dependências da seleção e das expressões, restrições de unicidade e ausências que precisam continuar verdadeiras.

O resumo visível da prévia não será o objeto inteiro assinado por `Phase::run()`. Separar `presentation` e `guard`: amostras redigidas, duração, timestamp de consulta e ordem de exibição não alteram a guarda. Vincular o token à conexão, usuário, site, intenção, versão do contrato e guarda privada. Manter validade de dez minutos, consumo único, replay do resultado e consulta por `operation_id`.

Amostra de até 200 linhas não limita a guarda às primeiras 200. A seleção inteira precisa ser coberta, com leitura em fluxo e limite explícito de tempo/volume. Estouro de limite produz erro antes de emitir uma confirmação utilizável; nunca assinar seleção truncada como completa.

Assinar as linhas completas selecionadas de forma determinística, por chave primária ou identidade única comprovada, preservando tipos, NULL e bytes. Usar HMAC privado para dados sensíveis; não expor hashes de valores de baixa entropia nem valores originais em erros. Mudança em outra linha da mesma tabela deve ser tolerada quando não mudar a seleção, dependências ou efeito previsto.

### 6.2 Estrutura e cobertura SQL

Assinatura estrutural canônica: colunas, tipos, collation, defaults, geração, chaves, índices, engine, FKs e triggers relevantes. Excluir o **contador corrente** de AUTO_INCREMENT da guarda DML; não excluir o atributo auto_increment da coluna. DDL que altere deliberadamente o contador tem pré-condição própria.

Implementar um planejador sobre tokens/AST, com testes por forma SQL; não descobrir fontes por regex de nomes de tabela. Reutilizar as regras existentes onde forem corretas, removendo a dependência de `$wpdb` dentro do fluxo `mysqli`. Não voltar a um banco inteiro como fallback silencioso.

| Forma | Guarda necessária |
|---|---|
| UPDATE/DELETE simples | Conjunto de chaves, pré-imagens completas e predicado; detectar entrada/saída de linhas da seleção |
| JOIN, IN, EXISTS, subconsultas | Alvos distintos e dependências reais das condições/expressões, inclusive ausências; alteração relevante na fonte conflita |
| ORDER BY/LIMIT | Ordem total verificável e fronteira da seleção; recusar escolha não determinística |
| INSERT literal | Valores solicitados, defaults relevantes e todas as restrições únicas; ausência também é pré-condição |
| REPLACE/ON DUPLICATE KEY UPDATE | Linhas que podem ser removidas/alteradas por cada chave única, além da entrada |
| INSERT SELECT e alterações de chave | Fonte, destino, colisões e dependências dos valores produzidos |
| Lote DML | Ordem, dependências entre instruções e conjunto de leituras/escritas da operação inteira |
| DDL | Objetos explicitamente afetados e dependentes; dados do alvo quando o DDL os destrói ou transforma |

O planejador não executa a mutação real para fazer a prévia. Transação seguida de rollback não torna inofensivos consumo de AUTO_INCREMENT, triggers ou efeitos externos. Para lote dependente, analisar as alterações produzidas pelas instruções anteriores; não apresentar seleções independentes do estado inicial como se fossem a simulação sequencial. Diferenciar contagem observada da prévia e contagem prevista. Se a prévia exata não puder ser calculada, informar isso e só emitir token quando as pré-condições integrais do lote ainda puderem ser provadas.

Tabela sem identidade estável, trigger/cascade não modelado, função não determinística ou construção sem plano verificável retorna **`sql_guard_unavailable`**, com motivo sanitizado, antes da escrita. Publicar uma matriz explícita do SQL aceito. Essa recusa é uma mudança de contrato em relação ao caminho administrativo amplo da 0.14, que aceitava SQL usando guarda global conservadora; não deve ser escondida como correção transparente. Não restringir formas já cobertas apenas para simplificar a implementação. A matriz de regressão deve incluir UPDATE aritmético, múltiplas instruções dependentes, INSERT/REPLACE e DDL, além do caso do incidente.

### 6.3 Confirmação, trava e backup

Na confirmação:

1. Revalidar identidade, permissão, token e intenção. Adquirir locks de operação na ordem determinística.
2. Abrir uma transação InnoDB na **mesma conexão** usada para selecionar, comparar e escrever. Não conservar transação entre prévia e confirmação HTTP.
3. Reler e bloquear alvos, dependências e intervalos/ausências pertinentes. Comparar seleção e estrutura com a guarda persistida. O lock PHP sozinho não bloqueia WP-Cron nem SQL externo.
4. Persistir a pré-imagem privada e verificar sua disponibilidade antes da primeira escrita. Falha de backup cancela a aplicação.
5. Executar o lote ordenado; conferir efeitos e pós-imagem pertinentes; commit único para DML. Manter o registro durável de operação e de backup para resultado perdido/incerto.
6. Responder com o resultado do próprio efeito, sem calcular `changed` pelo banco inteiro. Liberar travas em sucesso, erro e exceção.

InnoDB pode bloquear registros de índice examinados além das linhas finalmente retornadas. O plano deve medir contenção; não promete ausência total de bloqueios de vizinhos. Subconsultas exigem proteção de suas próprias fontes, e novas linhas que passariam a integrar a seleção precisam ser detectadas. Não basta acrescentar `FOR UPDATE` ao SELECT externo. Usar leituras bloqueantes e proteção de intervalos coerentes com o isolamento e os índices da stack testada.

Preservar inicialmente o dump integral privado da 0.14 como cópia de recuperação, separando seu escopo do escopo da guarda. Não usar `FOR UPDATE` em todas as tabelas para produzi-lo. Medir duração/espaço do dump em banco representativo e declarar `backup_scope:database`. A consistência do backup, a pré-imagem exata do alvo e o ponto de referência precisam estar registrados; escritas externas não podem mudar o alvo entre sua validação e a cópia. Não restaurar o banco inteiro automaticamente por uma falha DML: a transação faz rollback. Restauração integral continua operação distinta e explícita.

Reutilizar a guarda corrigida em `db/search-replace` quando houver seleção de linhas/colunas. Esse método hoje também compara tabelas inteiras; não alterar a guarda global deliberada de `db/restore`, cujo alvo pode ser o banco inteiro. DDL continua fora de `db/batch`, sem promessa de rollback transacional. Não acrescentar `db/execute` a `operations/plan`.

### 6.4 Respostas e diagnóstico

Preservar `confirm_token`, `operation_id`, `backup_id`, `affected_rows`, `statement_results`, `applied`, `changed`, `persisted`, `atomic` e redação de segredos. Acrescentar `guard_contract`, `guard_scope`, `target_tables`, `selected_rows`, `selection_exact` e `backup_scope` onde pertinentes. `summary.tables` deixa de significar inventário/fingerprint de todo o banco; documentar a mudança.

`database_conflict` continua sendo o código identificável de mudança concorrente, com `conflict:true`, `applied:false`, `changed:false` e `conflict_reason` entre `target_rows_changed`, `selection_changed`, `dependency_changed`, `schema_changed` ou `unique_key_changed`. Não repetir automaticamente usando uma nova prévia. Informar que a seleção precisa ser revista.

Timeout/deadlock, orçamento excedido, confirmação expirada e guarda indisponível são códigos distintos. Espera SQL e `lock_wait_seconds` de arquivos não são a mesma configuração. Em falha depois de commit sem recibo conclusivo, responder estado incerto e orientar consulta da operação; nunca reaplicar apenas porque a resposta HTTP se perdeu.

### 6.5 Aceite central

Prévia de UPDATE de uma linha de **tabela sintética `f3base_*`** em laboratório/Site-Teste autorizado. Entre prévia e confirmação, WP-Cron muda options, Core escreve histórico em outra tabela e Google registra auditoria/estado. A confirmação conclui, devolve backup e altera somente o esperado. Nova prova muda a própria linha: `database_conflict`, sem escrita. Não usar lead, fila CAPI real ou segredos como massa de teste.

## 7. I03 — propriedade do estado em restauração

`DatabaseAdmin::runtime_rows()` preserva options correntes por `^f3_mcp_`, incluindo options Google. Ao restaurar um dump, a tabela Google pode voltar no tempo enquanto algumas de suas configurações permanecem atuais. Isso não é o contrato declarado de preservar o estado **MCP**.

Criar inventário explícito de tabelas, options e famílias realmente pertencentes ao canal. Usá-lo nos novos diários e na recuperação independente. Excluir `f3_mcp_google_*` dessa preservação implícita. Manter a preservação deliberada de credenciais/sessões WordPress necessárias ao acesso de recuperação e documentar seu alcance. Uma proteção de configuração Google via rota tipada não deve ser confundida com propriedade MCP daquele dado.

Não reutilizar essa redução de escopo para liberar `options/update` ou `system/delete-transient` sobre credenciais/estado privado Google. A correção trata da composição do snapshot restaurado; configuração operável continua passando pelos contratos e permissões do dono do dado.

Novos backups/diários informam `preserved_state_manifest`, sem valores secretos. Dados Google e Core incluídos em restauração integral devem pertencer à fotografia restaurada, com recuperação operacional explícita; não combinar arbitrariamente options novas e tabela antiga. Isso não desfaz efeitos já enviados ao Google/Meta nem autoriza retomar jobs automaticamente. O procedimento de restauração deve suspender os executores envolvidos pelos controles dos seus donos e conferir estados antes de liberá-los.

Não reinterpretar nem apagar diários 0.14 em andamento: concluí-los com seu formato original e registrar essa condição antes da atualização. A correção de propriedade vale para novas operações. Os relatórios aos outros projetos pedem validação dos conjuntos de estado e do procedimento de pausa/retomada, sem mudar seus fontes nesta entrega.

## 8. U01 — atualização exclusiva da 0.14.0

### 8.1 Instalação e migração de dados

Instalação limpa não importa options do Ultimate, não procura complemento antigo e não recebe permissão administrativa implícita. Atualização reconhece a base 0.14, inventaria estado e aplica apenas mudanças de formato necessárias à nova guarda/SDK. Journal próprio, etapas idempotentes e leitura de confirmação; defaults só para valores ausentes, preservando `false`, vazio e listas vazias.

Remover instruções operacionais e caminhos de entrada para 0.12/0.13, plugin Ultimate separado e `f3-mcp-files`. Não retirar de modo cego formatos que ainda possam estar legitimamente persistidos na 0.14. Inventariar tokens, perfis explícitos, sessões, grants, backups, jobs, estados `phase014` e sentinelas antes de remover fallback. Não recriar senhas de aplicação, renovar expirações nem reativar credenciais revogadas.

Confirmações SQL pendentes 0.14 usam uma guarda diferente: ao confirmar na 0.15, devolver `confirmation_version_changed`, `applied:false`, pedindo nova prévia. Operações concluídas continuam consultáveis/reproduzíveis como recibo; `running`/incertas não serão reaplicadas. Operações em voo exigem drenagem ou diagnóstico antes da troca, sem deletar diário ou backup. Outras confirmações não devem ser invalidadas sem motivo de contrato.

### 8.2 Caminho de troca e migrador

A 0.14 já implementa self-upload com `SelfUpdate::preload()`, recuperação independente e ativação em nova requisição no `PackageService`. Caminho principal proposto: **`plugins/upload` do instalador 0.15**, SHA esperado, `expected_slug:wp-mcp-fator3`, sobrescrita explícita e preservação da ativação. Homologar esse caminho no pool HTTP/OPcache real antes de recomendá-lo na frota.

**Não produzir novo migrador nesta release.** O migrador anterior atendia principalmente às bases retiradas do suporte. Instalação limpa usa o instalador comum; a atualização da 0.14 usa o mecanismo já presente. O item 37(c), metadados do migrador, fica condicional e não exige um quarto arquivo quando não há migrador novo. O migrador 0.14 já instalado deve estar inativo fora de operação; sua retirada é ação operacional explícita após conferir ausência de recuperação pendente. Não excluir o plugin ou MU-plugin de recuperação automaticamente durante a atualização.

Se a prova de self-upload da **base 0.14** falhar, a publicação pelo canal fica bloqueada. A correção apenas na 0.15 não corrige o executor antigo já em memória. Nesse caso, documentar instalação pelo wp-admin e, se for indispensável um componente de transição, revisar este item e entregar somente `wp-mcp-fator3-migrator-0.15.0-instalador.zip`, restrito à 0.14, com os metadados exatos do pedido 37(c). Não abrir novamente suporte a versões anteriores.

## 9. M37 — marca e arquivos

Aplicar no plugin:

```text
Plugin Name: Fator3 MCP
Author: Fator3
Author URI: https://www.fator3.com.br
Description: Servidor MCP do site para agentes de IA: OAuth com perfil por conexão, conteúdo, mídia, arquivos, banco de dados, plugins, temas e auditoria, com backup e conferência em cada escrita. Configuração e desligamento em Ferramentas → Fator3 MCP.
```

Tela e menu: **Fator3 MCP**. `server_name`: **Fator3 MCP**. `server_description`: **Servidor MCP do site WordPress, operado pela Fator3**. Conferir menus, títulos, avisos, OAuth, ajuda e metadados visíveis. A descrição solicitada não substitui a documentação dos limites de operações externas e de rollback.

Preservar slugs/pastas, arquivos principais, Text Domain, Update URI atual, `server_id`, prefixos, options, rotas, identidade das conexões e nomes `wp-mcp-ultimate/*`. Endpoints continuam:

- `/wp-json/mcp/wp-mcp-fator3`, principal;
- `/wp-json/mcp/wp-mcp-ultimate`, alias, cuja rota REST interna é `/mcp/wp-mcp-ultimate`.

Gerar exatamente os três artefatos principais na raiz do repositório da entrega:

| Arquivo | Conteúdo/raiz |
|---|---|
| `wp-mcp-fator3-0.15.0-instalador.zip` | `wp-mcp-fator3/`, pronto para WordPress |
| `wp-mcp-fator3-0.15.0-fonte.zip` | `wp-mcp-fator3-0.15.0-fonte/`, código, testes, ferramentas, evidências e relatório-base |
| `wp-mcp-fator3-0.15.0-relatorio.md` | Relatório externo da release com situação de homologação e hashes |

Sem ZIP agregador, ZIPs de release repetidos, `-src-`, `-fonte-` antes da versão ou sufixo `nao-homologado`. Versão X.Y.Z no cabeçalho e nos arquivos. Artefatos antigos publicados conservam nomes, URLs e bytes. Testes podem recuperar fixtures fixadas por hash sem empacotar instaladores antigos repetidos no fonte novo.

O build deixa de exigir feed/origem pública de manifest como condição de release: essa demanda foi expressamente retirada em 01/10. Manter Update URI e configurações existentes, sem ativar feed nem auto-update. ZIP versionado por HTTPS para upload é distinto de um canal de atualização automática. Não inventar URL publicada; publicar no repositório depende da etapa autorizada de entrega.

### Relatório e hashes sem autorreferência

Fechar instalador → calcular SHA → gerar relatório-base com evidências e hash do instalador → incluir a cópia-base no fonte → fechar fonte → acrescentar SHA do fonte ao relatório externo. Marcar explicitamente a seção exclusivamente externa. Não prometer que as duas cópias são byte a byte idênticas.

O relatório não pode conter seu próprio SHA final. Seu hash, se necessário para o registro da publicação, fica no recibo externo/repositório; os hashes dos ZIPs ficam no relatório. Preservar o hash dos bytes efetivamente homologados. Mudança de estado de homologação altera o relatório e, se reconstruir o fonte, exige nova identidade do fonte, sem renomear os arquivos por estado.

## 10. D01 — documentação que acompanha o plugin

Uma especificação canônica por contrato: servidor, política, guarda SQL, resultado, recuperação e atualização. Gerar schemas e exemplos a partir do registro real, referenciados por manual, painel e relatório. Checagem documental deve comparar semântica entre fontes, não só bytes entre cópias.

Atualizar `OPERACAO.md`, ajuda autenticada, documentação de extensão, atualização, README, changelog, schemas e ferramentas de build. Manual da 0.15 descreve comportamento implementado; intenções futuras ficam no plano. Material histórico continua identificado, fora do caminho normal de operação.

Explicar especialmente: duas entradas suportadas; URLs preservadas; filtros próprios; diagnóstico local versus acesso externo; ferramentas diretas versus alvos aninhados; erro de conflito e nova prévia; escopo de backup; SQL não coberto; invalidade de confirmação 0.14; limites de restauração; ausência de feed e de novo migrador.

Documentação funcional permanece acessível por `system/guide`/painel autenticado, em dados PHP protegidos. Relatório completo vai no fonte e externamente, não como Markdown público do instalador. Conferir ausência de docs/scripts operacionais públicos e download autenticado da ajuda. Não copiar segredos, dados de clientes ou credenciais de testes nos artefatos.

## 11. Convivência e divergências entre os planos recebidos

| Tema | Decisão MCP | Encaminhamento |
|---|---|---|
| Isolamento do servidor | Filtros/ciclo próprios; adaptador explícito para Google 0.6 | Google migra sua bridge para `server-integration/1.0.0`; Core não força filtros |
| Coleta GSC | Nenhum perfil sintético, bypass ou intermediação MCP | Google fornece serviço; Core agenda e persiste |
| Configuração/contratos | Catálogo dinâmico, hash muda com registro efetivo | Core 5.0 e Google 3.0 precisam publicar seus diffs; política MCP continua 1 |
| SQL com cron | Escrita normal dos complementos continua | Não pausar cron/auditoria para fazer o token passar |
| Observabilidade | Não somar passagens dos três plugins como processos únicos | `cli`/`http_cron`/`manual` são evidência observada; leituras não são execuções |
| `cron/run` MCP | Preservar contexto cron/usuário 0 e auditoria do solicitante | Pela precedência proposta Core, chamada HTTP dessa rota será `http_cron`; não é prova de cron externo |
| Recuperação de dados | Corrigir preservação ampla de options; distinguir pacote de banco | Rollback de arquivos não desfaz migração Core/Google |
| Atualização dos complementos | Upload por SHA/slug; metadados atuais de `plugins/list` | Cada projeto gera seus próprios três arquivos; MCP não renomeia seus pacotes |

Duas pendências de alinhamento **entre Core e Google**, sem implementação MCP:

1. O plano Google ainda não formaliza `budget_ms` na tabela de entrada nem fixa o enum final de `trigger`; incorporar o encaminhamento Core com `cli`, `http_cron`, `manual`. Não usar os rótulos anteriores `servidor/wp-cron/rota` como outro contrato concorrente.
2. A correção Google de `last_pass` foi acrescentada no encaminhamento Core → Google após o plano Google. Ela precisa receber decisão/ID naquele projeto; não presumir que está coberta pelos pedidos Google 8/12. Não fazer essa mudança no MCP.

A ordem relativa Core/Google proposta nos documentos continua: Core pronto, coleta nova bloqueada; Google suspende/drena seu importador antigo; configuração e concessão liberam o consumidor Core. A release MCP não deve obrigar essa troca simultânea: funcionar com Core 1.19 e Google 0.6 é critério próprio.

## 12. Sequência, estimativa e responsabilidades

Estimativa de planejamento em dias úteis de uma pessoa experiente, incluindo implementação e testes locais. São faixas, não prazo assumido nem medição de trabalho já executado. Responsáveis por função; nenhum nome de pessoa foi fornecido. O mantenedor MCP responde por integração e fechamento; mantenedores Core/Google respondem apenas por seus contratos e testes conjuntos.

| Etapa | Itens | Dependência | Esforço |
|---|---|---|---|
| A | Fixar fixtures, reproduzir 35/36 e fechar contratos | Bases fornecidas | 1–2 dias |
| B | M35, I01, I02; diagnóstico e testes de duas portas | A | 3–5 dias |
| C | M36: planejador, guarda, lote, backup e concorrência | A | 7–12 dias |
| D | I03 e U01; formatos, estado e self-upload 0.14 | B/C | 2–4 dias |
| E | M37 e D01; docs, UI, build e relatório | Contratos estabilizados | 2–3 dias |
| F | Integração, pool HTTP e aceite do candidato | A–E | 2–4 dias |
| **Total** | **Entrega única** | Disponibilidade do laboratório/aceite | **17–30 dias úteis** |

A maior incerteza é a cobertura de SQL complexo/lotes e seus locks. Em A, produzir inventário da gramática usada e um protótipo da guarda, estimativa revisada e casos de aceite congelados. O protótipo não será distribuído como release intermediária. Não reduzir silenciosamente a cobertura ou chamar uma guarda global de correção concluída para cumprir a estimativa.

Pontos de controle: fim de B prova o canal com filtro genérico desligado; fim de C prova DML com tráfego concorrente e conflito real; fim de D prova a atualização da base 0.14; fim de F fecha a release. A espera pelo Google/Core novos não bloqueia as correções do MCP: testes do contrato futuro usam fixture identificada, e a homologação da integração futura é declarada separadamente quando aqueles fontes existirem.

## 13. Matriz de testes e gate de publicação

Laboratório reproduzível da stack fornecida: WordPress 7.1.2, PHP 8.3.30, MySQL 8.0/InnoDB (registrar patch efetivo), Apache/pool PHP com OPcache e processos HTTP separados. Não apresentar o servidor embutido PHP ou SQLite como prova dessa stack. Não ampliar suporte de plataforma; apenas reproduzir o ambiente padronizado informado.

| ID de teste | Prova obrigatória |
|---|---|
| T01 | Instalação limpa, 0.14 com dados, opções falsas/vazias, atualização repetida/interrompida; sem leitura de base 0.12/0.13 |
| T02 | Elementor 4.3.3 real, enabled ausente/falso/verdadeiro; filtro genérico false; duas ordens de carga; rotas e recursos preservados |
| T03 | Filtro próprio false, kill-switch desligado, identidade imutável, callback genérico tipado, configuração inválida e diagnóstico antes/depois do REST init |
| T04 | Core 1.19 + Google 0.6 reais: provider/versão/policy 1, três metatools e ferramentas Google sem duplicação |
| T05 | Google direto leitura/escrita; alvo final permitido/negado; custom, Leitura, Manutenção; executor aninhado proibido; contexto forjado e outra porta não liberam acesso |
| T06 | UPDATE pontual com options, cron, Core e Google escrevendo fora do alvo entre prévia/confirmação; sucesso e `backup_id` |
| T07 | Mudança da linha, entrada/saída da seleção, DELETE concorrente, nova linha correspondente, alteração relevante de JOIN/subconsulta, schema/FK/trigger: conflito sem escrita |
| T08 | Mesma tabela com linha alheia e aumento do AUTO_INCREMENT não conflita; mudança estrutural real conflita; seleção >200 integralmente guardada |
| T09 | Dois confirmadores, escritor SQL externo durante aplicação, deadlock, timeout, ordem de locks, replay, expiração, revogação e resposta HTTP perdida |
| T10 | Lote dependente, erro na instrução intermediária, INSERT/REPLACE/upsert, chave composta, binário/NULL/Unicode, DDL e seleção não verificável; nenhuma simulação mutante na base viva |
| T11 | Backup indisponível/ENOSPC, commit e recibo incerto, segredo redigido, alteração alheia não afeta `changed`; medir custo do dump e bloqueio do cron |
| T12 | Search-replace selecionado; restauração explícita global; options Google e tabela Google consistentes; estado MCP corrente preservado; diário 0.14 não reinterpretado |
| T13 | Self-upload executado pela 0.14: ativação mantida, versão realmente atendida pelo pool, sonda, candidato com fatal, processo encerrado durante troca e retomada independente |
| T14 | OAuth e senhas de aplicação da 0.14, refresh/revogação, duas URLs, conector Site-Teste sem reconfiguração; confirmação SQL antiga recusada com código próprio |
| T15 | `plugins/list` com nome/autor/descrição; três artefatos/raízes corretos; hashes; instalação a partir do ZIP entregue; documentação autenticada e sem exposição pública |
| T16 | Fixtures Core 1.20/Google 0.7: catálogo removido, contrato novo e MCP desligado sem autorizar/impedir indevidamente serviço PHP; repetir com fontes reais quando disponíveis |

Critério de publicação MCP: T01–T15 aprovados para os bytes candidatos, sem falhas críticas abertas nos fluxos alterados. T16 contra fixture fecha a compatibilidade de contrato proposta; não fecha o aceite do GSC real. Relatório deve indicar claramente quais combinações foram testadas, quais são simuladas e quais aguardam os outros projetos.

Aceites históricos da 0.14 serão reclassificados pelo novo escopo: sai migração de 0.12/0.13 e sai feed público; permanecem pool/OPcache, recuperação, falta real de espaço e cliente real quando necessários aos fluxos preservados. Não copiar automaticamente `379 asserções` como resultado da nova release, nem exigir os antigos 33 IDs no build da 0.15.

Entregar matriz de cobertura por ID, comandos/ambiente, resultados e hashes. Homologação tem estado no relatório e publicação é decisão do dono; o nome do arquivo não certifica aceite. Nenhum documento deste planejamento declara os testes acima executados.

## 14. Documentos entregues neste planejamento

- Este plano: especificação canônica das decisões MCP.
- `impacto-mcp-0.15.0-para-site-core.md`: compromissos e testes que afetam o Core.
- `impacto-mcp-0.15.0-para-google.md`: SDK, bridge, política e recuperação que afetam o Google.
- `verificacao-plano-0.15.0.json`: inventário dos anexos, hashes, conferência estática e limites da revisão.

Os relatórios são preparados para encaminhamento pelo dono. Não foram enviados a outros projetos nem aplicados aos seus códigos.

## Referências técnicas externas

- [MySQL 8.0 — Locking Reads](https://dev.mysql.com/doc/refman/8.0/en/innodb-locking-reads.html): locks na transação e necessidade de proteger fontes de subconsultas.
- [MySQL 8.0 — Phantom Rows](https://dev.mysql.com/doc/refman/8.0/en/innodb-next-key-locking.html): proteção de intervalos e novas linhas que mudam uma seleção.
- [MySQL 8.0 — Locks Set by Different SQL Statements](https://dev.mysql.com/doc/refman/8.0/en/innodb-locks-set.html): alcance de locks sobre índices examinados.

Consultadas em 01/10/2026. Nomes novos de SDK, contratos de guarda, campos e estimativas são propostas deste plano, não APIs já disponíveis na 0.14.0.
