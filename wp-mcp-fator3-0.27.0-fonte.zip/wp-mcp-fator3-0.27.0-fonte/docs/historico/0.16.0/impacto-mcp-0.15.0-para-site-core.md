# Encaminhamento ao Fator3 Site Core — MCP 0.15.0

Data: 01/10/2026. Versão MCP estável implementada. Base de integração exercitada: Core 1.19.0, Google 0.6.0 e Elementor 4.3.3. Este trabalho não alterou o código dos complementos. Documento preparado para encaminhamento pelo responsável; não enviado automaticamente.

## Resultado e contratos preservados

O Core 1.19.0 continua registrando seu provedor e habilidades no MCP 0.15.0. Foram mantidos `f3_mcp_register_providers`, o provedor `base-site-core-fator3`, o prefixo `f3base/` e `policy_contract:1`. A versão do contrato funcional Core é independente da versão dessa política. O catálogo continua dinâmico; não há lista congelada de habilidades Core.

As URLs principal e alias e os nomes técnicos dos metatools permanecem. O nome visual passou a Fator3 MCP. A instalação MCP admite WordPress limpo ou MCP 0.14.0; isso não altera a matriz de atualização própria do Core.

## Interfaces disponíveis agora

| Interface | Uso no Core |
|---|---|
| `Fator3\McpFiles\ServerContract::capabilities()` | Descobrir `server-integration/1.0.0`, identidade e hook próprio |
| `Fator3\McpFiles\ServerContract::status()` | Diagnóstico local opcional, sem HTTP, execução de tarefas ou credenciais |
| `f3_mcp_default_server_config` | Contribuir nomes de ferramentas/recursos/prompts públicos aderentes; não alterar autenticação ou identidade |
| `f3_mcp_create_default_server` | Controle do registro do servidor Fator3, distinto do kill-switch de autorização |

O contrato completo está em `SERVER-INTEGRATION.md`. Antes do registro, estados desconhecidos são `null`; antes de WP_Rewrite, as URLs também podem ser `null`. `external_connectivity_tested:false` não significa indisponibilidade. Não é necessário consumir esse SDK para executar serviços PHP locais.

Filtros genéricos `mcp_adapter_*` deixaram de controlar o servidor embutido Fator3. Não é necessário modificar a configuração Elementor, remover seus callbacks ou criar um segundo servidor para contornar o incidente.

## SQL e atividade do Core

`db/execute`, `db/batch` e `db/search-replace` usam `selection-guard/2`. Atividade fora das linhas/dependências selecionadas não invalida a confirmação apenas por alterar o banco. O backup continua integral e privado; seu escopo não é o escopo da guarda. `summary.tables` não é um contrato de inventário da prévia DML.

Não suspenda logs, auditoria, filas, transientes ou cron para estabilizar tokens. O MCP mantém locks das seleções e dependências durante backup e aplicação; consultas mal indexadas podem bloquear linhas vizinhas. Há orçamento explícito e recusa de SQL não verificável. A matriz canônica está em `SQL-GUARD.md`.

No site de testes foram comprovados sucesso após mudança alheia e conflito após mudança da linha alvo. Leituras reais de saúde Core e status Google passaram. No laboratório houve escritores MySQL em processos independentes. Não foram disparados jobs Core com envio externo para produzir evidência artificial de convivência; o teste específico de sua fila/cron continua pertencendo ao aceite do Core.

## Serviço Core → Google e recuperação

O serviço planejado `search-console-reader/1.0.0` permanece PHP local, com concessão e autorização próprias do Google. Não criar sessão MCP ou usuário administrador artificial para o cron. Desligar MCP não deve desligar esse serviço. A fixture MCP verificou apenas a independência dessa arquitetura; não certifica o serviço real das próximas versões Core/Google.

`cron/run` executa em contexto de cron com usuário 0. Uma invocação HTTP é observada como `http_cron`; a auditoria MCP registra o solicitante. Não identificá-la como CLI ou prova de execução pelo crontab. Origem/`trigger` é metadado, não autorização. Não somar contagens dos três plugins sem declarar o escopo de cada contador.

A recuperação de banco agora preserva somente estado MCP explicitamente inventariado. Options e tabelas Core/Google incluídas no dump voltam ao snapshot. Antes de restaurar o banco, use os controles dos próprios complementos para pausar trabalho e reconciliar filas. Restaurar dados não desfaz entregas remotas já efetuadas. `plugins/rollback` recupera arquivos e ativação, não migrações de banco Core.

## Ações para a próxima versão Core

1. Preservar provedor, prefixo e política 1; manter a migração Core independente de `db/execute`.
2. Fechar com Google os parâmetros `budget_ms` e `trigger:cli|http_cron|manual`, o vínculo do consumidor e a revisão da propriedade.
3. Exercitar sua fila/cron entre prévia e confirmação SQL, incluindo uma mudança alheia e uma mudança real da seleção.
4. Documentar pausa, retomada e reconciliação após restauração; verificar saúde estrutural após upload, além da sonda HTTP.
5. Repetir a integração com Core 1.20.0 e Google 0.7.0 reais quando seus fontes estiverem disponíveis.

Nenhuma adaptação obrigatória no Core 1.19.0 foi necessária para operar com MCP 0.15.0. As tarefas acima pertencem à evolução e validação do próprio Core.
