# MCP 0.16.0 → Google 0.7.1

Data: 07/10/2026. Release MCP estável implementada e instalada no Site-Teste. Compatibilidade exclusivamente com Google 0.7.1 e Core 1.22.1. Nenhum arquivo Google foi alterado (132 arquivos do instalador comparados, todos idênticos).

## Contratos preservados

Continuam `google/mcp-read` e `google/mcp-write`, metadados públicos, `policy_contract:1`, admissão do alvo e recusa de executores aninhados. O SDK permanece `server-integration/1.0.0`; identificador, endpoints e autenticação são preservados. O preparo Google em REST prioridade 0/CLI 19 pode permanecer: a correção MCP também foi provada com provedor que não aquece o registro.

Status do SDK é observação local. Um diagnóstico registered/compatible não substitui prova de conexão externa; o relatório distingue os dois. O catálogo/execução Google 2.0.0, configuração 3.0.0 e leitor PHP Search Console 1.0.0 não foram modificados.

## Provas

- 14 verificações no handler real em cada uma de duas ordens de carga: leitura, personalizado, manutenção, alvo não autorizado, escrita negada em leitura, executor aninhado e recuperação; zero chamadas HTTP Google.
- Primeiro acesso HTTP e WP-CLI real sem aquecimento prévio provados com provedor sintético independente.
- Trabalho Google em voo impediu prontidão; prepare concluiu após a liberação. Status/retomada permaneceram acessíveis durante a pausa e despacho remoto foi recusado.
- Restore integral com configurações distintas de duas conexões Google; valores da fotografia recuperados, pausa fora do banco preservada e estado corrente MCP conservado.
- No Site-Teste, `google/status` via conector OAuth existente reconheceu MCP 0.16.0/SDK compatível. Restore de tabela sintética preservou pausa Google; retomada explícita depois da verificação.
- Edição/exclusão/restauração de papéis humanos não alterou opções/concessões Google no laboratório.

As bridges diretas foram testadas pelo handler real no laboratório. O conector externo disponível nesta sessão chamou `google/status` e recuperação por Execute Ability; não se apresenta esse caso como chamada externa direta da bridge. O Site-Teste não possui credenciais Google configuradas: nenhuma leitura/escrita de contas Analytics, Ads ou Search Console foi executada.

## Efeito operacional e ação

Backup selecionado do MCP cobre uma tabela inteira. Se options Google e jobs/grants estiverem em tabelas diferentes, restauração parcial não comprova coerência. Manter pause, revisar configuração, concessões, jobs e contextos, e retomar com geração corrente/acknowledge_reconciled:true. O MCP não reconcilia internamente dados privados Google nem reenvia efeitos externos.

Nenhuma correção obrigatória de código Google identificada. Atualizar a referência de compatibilidade para MCP 0.16.0 e conservar o preparo do registro e a delegação de admissão ao alvo. Não é necessária mudança do contrato público da bridge nem concessão automática de capacidade/grant.

Instalador MCP SHA-256: `4b4081a9f3c1c22156d284b01ab023d4a33ae388fd68c44b599a0ac546ccc0e7`. Evidências: google-native-bridge.json, google-native-bridge-reverse.json, cold-http-cli.json, full-recovery-tests.json, site-test-0160.json e companions-byte-comparison.json. Não houve implantação na frota.
