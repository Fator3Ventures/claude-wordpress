# Fator3 MCP 0.25.0 — relatório de implementação e validação

Fechamento: {{DATE}} — America/Sao_Paulo.

{{REPORT_COPY_NOTE}}

## Resultado

Implementado o pedido **MCP 62**, com atualização da base **0.24.0**. O pacote final foi instalado e conferido no Site-Teste https://fator3-teste-mcp-1.dreamhosters.com/. Os quatro plugins acompanhantes foram considerados e mantidos nas versões existentes. Não houve publicação em frota, GitHub ou fonte automática de atualização.

O pedido 61 permanece resolvido na base; a regressão de booleanos e proteção de segredos foi exercitada novamente. A validação externa CIMD B22 continua pendente e não integra o aceite do pedido 62.

## Entregas

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| wp-mcp-fator3-0.25.0-instalador.zip | {{INSTALLER_BYTES}} | `{{INSTALLER_SHA}}` |
| wp-mcp-fator3-0.25.0-fonte.zip | {{SOURCE_BYTES}} | `{{SOURCE_SHA}}` |
| wp-mcp-fator3-0.25.0-relatorio.md | Este documento | Relatório externo, sem hash de si próprio para evitar autorreferência |

Instalador com 456 arquivos, dos quais 448 PHP. São 14 arquivos alterados e 442 idênticos à base 0.24.0; nenhum arquivo de runtime foi acrescentado ou removido. Os módulos de autenticação, SQL, recuperação e distribuição remota permanecem com seus contratos públicos. O ZIP não leva a bancada, testes, documentação bruta, credenciais ou ZIPs aninhados. A documentação instalada é compilada em uma lista fechada de documentos.

O fonte inclui código editável, documentação canônica, testes, scripts de construção e evidências sanitizadas. Sua reprodução foi conferida extraindo o próprio fonte, regenerando os guias e reconstruindo um instalador com o mesmo SHA-256. O hash externo do fonte é calculado somente após fechar o arquivo.

## Atendimento ao pedido 62

| Item | Implementação e comportamento |
|---|---|
| a — assuntos separados | Oito abas com URL própria: Conexão do servidor, Clientes conectados, Arquivos e banco, Operações, Registro, Diagnóstico, Atualizações e Ajuda. Navegação visual por botões arredondados, coerente com os sociais atuais. URLs e identificadores antigos das abas continuam aceitos. |
| b — português e ajuda individual | Rótulos administrativos em português; cada permissão adicional tem ajuda própria e associação acessível ao campo. Os nomes de produtos, protocolos e IDs públicos permanecem técnicos. |
| c — habilidades selecionáveis | Catálogo real em lista pesquisável com nome humano e identificador. Pesquisa não desmarca nem omite valores selecionados na submissão. Identidades existentes e tipos de conteúdo também usam seletores com nomes. |
| d — datas e estados | Registro com seletores nativos de data/hora em UTC e resultado Todos/Concluído/Falhou. Operações com lista de estados em português. Intervalos inválidos são recusados; segundos da expiração são preservados. Links antigos com ISO continuam aceitos. |
| e — atualização do próprio plugin | A tela exibe somente o canal do MCP, sem rótulo com nome de arquivo. Salvar ou desabilitar preserva as entradas dos demais pacotes; há controle de revisão, permissão e HTTPS. O contrato remoto multipacote não foi removido. |
| f — ajuda curta e manual separado | Ajuda contextual por campo e página própria de documentos com paginação. Foram atualizadas referências de versão, base e matriz; material histórico é identificado como tal. |
| g — configuração estruturada | Perfil, permissões, identidades, habilidades, tipos, expiração, limite por arquivo, retenção SQL e fonte de atualização são configuráveis em campos próprios. Exemplos e detalhes técnicos JSON são apenas de leitura, sem editor JSON operacional. |

O limite global de arquivo e o limite individual de Manutenção aceitam 1 MiB a 1 GiB. O campo individual vazio volta a herdar o canal. Constantes e filtros definidos pelo administrador do servidor são informados como restrições efetivas; a tela não edita arquivos PHP de configuração.

A interface mantém validação de capacidades, nonce, revogação e versão de política. Habilidades/tipos de provedores temporariamente ausentes podem permanecer em seleções preexistentes, sem autorizar novos identificadores desconhecidos. O salvamento do canal preserva valores falsos, vazios, campos adicionais e entradas de outros provedores. Alterações concorrentes exigem recarregar.

## Matriz e entradas consideradas

| Componente | Referência fornecida e conferida |
|---|---|
| MCP — base imediata | 0.24.0; instalador SHA-256 `e2c78fcf0e99da55237808bc51fe408405e367fd76a71172b497707996f8aa95` |
| Site Core | 1.43.0; instalador SHA-256 `5a7c02abb97f7161617ddfd8e4d28faf2fdb22e4ae5d4ed75416dc68d76ee9e7` |
| MCP Google | 0.16.0; instalador SHA-256 `e0dfee63fbd9ad9fcc6b5ab9a3b9d492d7e497822154e0572589a45f3116248c` |
| MCP LinkedIn | 0.4.1; instalador SHA-256 `a1f2bd2393c7f1b1780f106f4a7c3ac46776a8a7cc7071f1e269daad7ec34c43` |
| MCP Meta | 0.4.1; instalador SHA-256 `719e3db7bb55f58cd08c2e78420e06374a6a4b08fad693e849677783ddc82de2` |

Os relatórios dos quatro companions e as instruções de desenvolvimento rev4 de 16/10/2026 foram lidos integralmente. As entradas e hashes adicionais estão em `evidencias/0250/inputs.json`; o plano atualizado está em `docs/PLANO-0250.md`.

Não há dependência obrigatória de companion. Permanecem server-integration 1.0.0, executor-registration 1.0.0, package-distribution 1.0.0, policy_contract 1 e schema de dados/resultado 2. Não foi identificado impacto que exija alteração em outro plugin; por isso não foi produzido um pedido artificial de impacto. A limitação de rollback com arquivos novos citada pelo Google não foi alterada; este release não acrescenta arquivos ao runtime.

## Testes executados

| Camada | Ambiente e evidência | Resultado |
|---|---|---|
| Administração nativa | WordPress 7.1.3, PHP 8.3.6, MySQL, FPM/HTTP; admin.json | 69 verificações aprovadas |
| Administração no mínimo | WordPress 7.1.2, PHP 8.3.6; admin-minimum.json | 69 verificações aprovadas |
| MCP isolado | WordPress 7.1.2 / PHP 8.3.6; acceptance-isolated.json | 39 verificações aprovadas, incluindo leitura integral de 19 documentos |
| Coexistência | WordPress 7.1.3 / PHP 8.3.6 com os quatro companions atuais; acceptance-companions.json e companions-setup.json | 45 verificações e 4 ativações aprovadas |
| Atualização direta | 0.24.0 → ZIP final 0.25.0, HTTP nativo; upgrade.json e upgrade-package.json | 19 verificações aprovadas; todos os arquivos instalados coincidem com o ZIP |
| Instalação limpa | ZIP final em bancos/raízes novos, WordPress 7.1.2 e 7.1.3 / PHP 8.3.6; clean-minimum.json e clean.json | Ativação e leitura em processo novo aprovadas, sem companions |
| Projeção de resultados | Classes reais da versão; projection.json | 18 verificações aprovadas, preservando booleanos públicos e redação de segredos |
| DOM | HTML real de WordPress, jsdom 27.4.0; dom.json | 237 verificações aprovadas; pesquisa, seleção enviada, nomes, IDs e ajuda acessível |
| Sintaxe | PHP 8.3.6 sobre o instalador extraído; lint-installer.json | 448 arquivos PHP sem erro |
| Site-Teste | WordPress 7.1.3 / PHP 8.3.30; site-tests.json | Saudável após atualização; configurações e companions preservados |
| Navegador real | Chrome, sessão administrativa no Site-Teste; browser.json | Oito abas conferidas; pesquisa, filtros de data/resultado e paginação do manual funcionais |
| Documentação remota | system/guide, páginas completas; site-documents.json | 19 documentos com bytes e SHA-256 iguais aos fontes canônicos |

As contagens são verificações/assertivas, não quantidade de cenários independentes. Testes DOM não são apresentados como teste visual: a aparência e as interações também foram inspecionadas no Chrome. Capturas serviram à inspeção e não fazem parte do fonte.

A atualização direta verificou pré-imagem, oito respostas de novos workers com OPcache sem revalidação por timestamp, versão efetiva, preservação de senha de aplicação, token e refresh OAuth, prazo, perfil, recibo de idempotência, operação incerta, confirmação SQL pendente e backup privado. A prévia de rollback foi exercitada sem aplicar restauração.

## Aplicação no Site-Teste

O executor informou versão 0.25.0 ativa e sondas aprovadas. A candidata usada na inspeção inicial foi seguida pelo pacote com a revisão documental final, antes do fechamento da entrega. O pacote canônico é exclusivamente o hash `{{INSTALLER_SHA}}` acima.

- Operação inicial, partindo da 0.24.0: `e735740b145a4348811e50ed2cb99851`; pré-imagem `04a48ff551463a719105854a`.
- Operação do pacote final: `6b4fb083cf61153a70fb43d68e0940f9`; pré-imagem `cf5dabd3222881e7eee8c99f`.
- Os 14 arquivos modificados tiveram hashes lidos do servidor e comparados ao instalador final.
- sql_retention, file_bytes, enabled e update_channels permaneceram iguais; o contexto de política da conexão permaneceu igual.
- Core 1.43.0, Google 0.16.0, LinkedIn 0.4.1 e Meta 0.4.1 permaneceram ativos nas mesmas versões.
- O arquivo ZIP temporário foi removido por caminho exato e hash após a conferência. Pré-imagens de recuperação permanecem disponíveis.

Qualquer reversão deve começar pela consulta do diário e pela prévia do rollback corrente; uma pré-imagem de uma etapa anterior não deve ser aplicada ignorando a sequência de alterações. Restauração de arquivos não promete reversão de efeitos de banco dos companions.

## Limites e pendências

Mínimos declarados e exercitados nesta rodada: WordPress 7.1.2 e PHP 8.3.6. WordPress 7.1.3 também foi exercitado; o Site-Teste usa PHP 8.3.30. Não se declara teste desta candidata em PHP 8.3.0 ou em navegadores adicionais.

Não foram executadas chamadas de negócio às APIs externas Google, Meta, LinkedIn, Pipedrive ou Slack. A coexistência, o catálogo e os diagnósticos locais não substituem homologação dessas integrações com contas reais.

B22, conexão nova ChatGPT com CIMD, segue pendente. A preservação de uma conexão OAuth existente não comprova esse fluxo novo. Não houve reemissão automática de credenciais ou ampliação de perfis.

O diagnóstico do Site-Teste já indicava histórico incompleto de incidentes cron por limite de retenção antes da troca; isso continua identificado, embora o estado atual de saúde e os registros essenciais estejam confirmados. A versão não tenta reparar histórico antigo nem comprova todos os jobs dos provedores.

## Instalação e continuidade

Em instalação limpa, envie somente o instalador pelo WordPress, ative e configure explicitamente a conexão/perfil. Para a frota 0.24.0, valide o SHA-256 e use o fluxo de atualização com expected_slug, expected_sha256, overwrite e activate explícitos, conforme `docs/ATUALIZACAO.md`. Confirme a versão em requisição nova e acompanhe operation-status/reconcile se houver verificação pendente. Não desinstale para atualizar.

No MCP, `system/guide` lista os documentos; use `document:administracao`, `document:release-0250` ou `document:atualizacao`, mantendo o cursor e expected_sha256 entre páginas. Nenhuma etapa deste trabalho publicou automaticamente a versão para outros sites.
