<?php
/** Domain-scoped hosting logs. Bounded full-window aggregation, signed page cursors. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class HostingErrorLog {
    private const FILE_ZONE='America/Los_Angeles';
    public static function register(): void {
        Registry::add('system/error-log','Lê error.log do domínio (inclui alias sem www), arquivos diários e gzip no fuso America/Los_Angeles; interpreta PHP e Apache/mod_fcgid. Decodifica bytes Apache escapados em UTF-8 válido antes de mascarar, agrupar e filtrar; preserva trechos inválidos, controles ASCII e barras literais. Até três amostras mascaradas de linhas não reconhecidas, no escopo dos arquivos examinados. Agrupa a janela completa por mensagem normalizada/arquivo/linha; horários no fuso do site. Até 8 KiB por página, cursor vinculado à conexão, filtros e inventário. Leitura limitada a 32 MiB descomprimidos, 128 arquivos e 5 s; se exceder, reduzir período. since inclusivo, until exclusivo, RFC 3339; padrão últimas 24 h.',[
            'since'=>Registry::string(),'until'=>Registry::string(),'level'=>['type'=>'string','enum'=>['fatal','warning','notice','deprecated','error','critical','alert','emergency','info','debug']], 'text'=>['type'=>'string','maxLength'=>256],'cursor'=>Registry::string(),'per_page'=>Registry::integer(1,30)
        ],[],[self::class,'listing'],static fn()=>current_user_can('manage_options')&&FileTools::permission());
    }
    private static function stamp(string $text): ?int {
        if(!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/D',$text))return null;
        try{$d=new \DateTimeImmutable($text);$errors=\DateTimeImmutable::getLastErrors();return $errors&&($errors['warning_count']||$errors['error_count'])?null:$d->getTimestamp();}catch(\Throwable $e){return null;}
    }
    /** Mask before grouping/filtering/output; hashes and cursors never contain raw log text. */
    public static function redact(string $text): string {
        return DataSafety::diagnostic_detail($text);
    }
    /** Decode one contiguous Apache byte run only when it is valid, safe UTF-8. */
    private static function decode_utf8_escapes(string $text): string {
        return (string)preg_replace_callback('/(?<!\\\\)(?:\\\\x[0-9a-fA-F]{2})+/',static function(array $match): string {
            $bytes=hex2bin(str_replace('\\x','',$match[0]));
            // Keep invalid runs and ASCII controls literally; never interpret generic escapes.
            if($bytes===false||preg_match('//u',$bytes)!==1||preg_match('/[\x00-\x1f\x7f]/',$bytes))return $match[0];
            return $bytes;
        },$text);
    }
    public static function parse(string $line): ?array {
        if(!preg_match('/^\[([^\]]+)\]/',$line,$date))return null;
        $raw=preg_replace('/\.\d+(?=\s|$)/','',$date[1]);$zone=new \DateTimeZone(self::FILE_ZONE);$time=null;
        foreach(['!D M d H:i:s Y','!d-M-Y H:i:s e','!d-M-Y H:i:s'] as $format){$d=\DateTimeImmutable::createFromFormat($format,$raw,$zone);$e=\DateTimeImmutable::getLastErrors();if($d&&(!$e||(!$e['warning_count']&&!$e['error_count']))){$time=$d->getTimestamp();break;}}
        if($time===null)return null;
        $body=ltrim(substr($line,strlen($date[0])));$apache=null;
        // DreamHost: [date] [domain] [warn] [client ...] [pid ...] module.c(N): ...
        // Apache 2.4: [date] [module:error] [pid ...] ...
        if(preg_match('/^(?:\[[^\]\r\n]{1,255}\]\s*)?\[(?:[a-z0-9_]+:)?(emerg|alert|crit|error|warn|warning|notice|info|debug|trace[1-8])\]\s*(.*)$/i',$body,$envelope)){
            $levels=['emerg'=>'emergency','alert'=>'alert','crit'=>'critical','error'=>'error','warn'=>'warning','warning'=>'warning','notice'=>'notice','info'=>'info','debug'=>'debug'];
            $apache=$levels[strtolower($envelope[1])]??'debug';$body=$envelope[2];
            $body=(string)preg_replace('/^(?:\[(?:pid|tid|client|remote)\b[^\]]*\]\s*)+/i','',$body);
            if(preg_match('/\bmod_fcgid:\s*stderr:\s*(.*)$/i',$body,$stderr))$body=$stderr[1];
            else $body=(string)preg_replace('/^[a-z0-9_]+\.c\(\d+\):\s*/i','',$body);
        }
        $body=self::decode_utf8_escapes($body);
        if(preg_match('/(?:PHP\s+)?(Fatal error|Parse error|Warning|Notice|Deprecated|User warning|User notice|User deprecated)\s*:\s*(.*)/i',$body,$m)){
            $level=strtolower($m[1]);$level=str_contains($level,'error')?'fatal':str_replace('user ','',$level);$message=$m[2];
        }elseif($apache!==null){$level=$apache;$message=$body;}else return null;
        if(trim($message)==='')return null;
        $message=self::redact($message);$file=null;$number=null;
        // Apache proxy_fcgi may append a referer. It is neither part of the error nor safe metadata.
        $message=preg_replace('/, referer:.*$/i','',$message);
        if(preg_match('~\s+in (.+?)(?: on line |:)(\d+)(?:[\s;\x27]*|$)~',$message,$where)){$file=trim($where[1]);$number=(int)$where[2];$message=substr($message,0,strpos($message,$where[0]));}
        $message=preg_replace('/\s+/u',' ',trim($message))??'invalid_utf8';$message=preg_replace('/\b0x[0-9a-f]+\b/i','0x…',$message);
        return ['level'=>$level,'message'=>$message,'file'=>$file,'line'=>$number,'time'=>$time];
    }
    private static function cut(string $value,int $bytes): string {return function_exists('mb_strcut')?mb_strcut($value,0,$bytes,'UTF-8'):wp_check_invalid_utf8(substr($value,0,$bytes),true);}
    /** Verify every gzip member/CRC, with independent compressed/expanded limits. */
    private static function open(string $path,bool $gzip,float $deadline,array $expected) {
        $source=@fopen($path,'rb');if(!$source)return false;$opened=fstat($source);if(!$opened||is_link($path)||$opened['ino']!==$expected['inode']||$opened['dev']!==$expected['dev']||$opened['size']!==$expected['size']||$opened['mtime']!==$expected['mtime']){fclose($source);throw new \RuntimeException('error_log_changed');}if(!$gzip)return $source;
        $target=fopen('php://temp/maxmemory:2097152','w+b');$compressed=0;$expanded=0;$ended=true;$members=0;$context=null;
        try{
            if(fread($source,2)!=="\x1f\x8b")throw new \RuntimeException('error_log_invalid_gzip');rewind($source);
            while(!feof($source)){
                if(microtime(true)>$deadline)throw new \RuntimeException('error_log_scan_limit');
                $chunk=fread($source,512);if($chunk===false)throw new \RuntimeException('error_log_unreadable');if($chunk==='')break;
                $compressed+=strlen($chunk);if($compressed>16777216)throw new \RuntimeException('error_log_scan_limit');$pending=$chunk;
                while($pending!==''){
                    if($ended){$context=inflate_init(ZLIB_ENCODING_GZIP);$ended=false;}
                    $before=inflate_get_read_len($context);$out=@inflate_add($context,$pending,ZLIB_SYNC_FLUSH);$consumed=inflate_get_read_len($context)-$before;
                    if($out===false||$consumed<=0)throw new \RuntimeException('error_log_invalid_gzip');
                    $expanded+=strlen($out);if($expanded>33554432)throw new \RuntimeException('error_log_scan_limit');
                    if($out!==''&&fwrite($target,$out)!==strlen($out))throw new \RuntimeException('error_log_unreadable');$pending=substr($pending,$consumed);
                    if(inflate_get_status($context)===ZLIB_STREAM_END){$ended=true;$members++;}elseif($pending!=='')throw new \RuntimeException('error_log_invalid_gzip');
                }
            }
            if(!$ended||!$members)throw new \RuntimeException('error_log_invalid_gzip');rewind($target);return $target;
        }catch(\Throwable $e){if(is_resource($target))fclose($target);throw $e;}finally{fclose($source);}
    }
    private static function directory(): string {
        $host=strtolower((string)wp_parse_url(home_url('/'),PHP_URL_HOST));if(!preg_match('/^[a-z0-9][a-z0-9.-]*$/D',$host))throw new \RuntimeException('error_log_domain_invalid');
        $hosts=[$host];if(str_starts_with($host,'www.')&&strlen($host)>4)$hosts[]=substr($host,4);
        // Exact host wins at every supported ancestor; aliases never bypass a denied path.
        foreach($hosts as $domain){
            $parent=rtrim(ABSPATH,'/');
            for($i=0;$i<4;$i++,$parent=dirname($parent)){
                $candidate=$parent.'/logs/'.$domain.'/https';
                if(!is_dir($candidate))continue;
                $allowed=AuthorizationPolicy::check('files/read',['path'=>$candidate],true);if(is_wp_error($allowed))throw new \RuntimeException('permission_denied');
                $path=PathGuard::resolve($candidate,false);if(is_wp_error($path))throw new \RuntimeException('permission_denied');
                return $path;
            }
        }
        throw new \RuntimeException('error_log_not_found');
    }
    public static function listing(array $input): array {
        try{
            $cursor=null;if(!empty($input['cursor'])){$cursor=Cursor::decode($input['cursor']);if(is_wp_error($cursor)||($cursor['kind']??'')!=='hosting-error-log/3'||($cursor['site']??0)!==get_current_blog_id()||($cursor['connection']??'')!==ConnectionContext::key()||($cursor['expires']??0)<time())return Result::fail('cursor_invalid','Cursor de logs inválido ou expirado.');}
            $until=isset($input['until'])?self::stamp($input['until']):($cursor['until']??time());$since=isset($input['since'])?self::stamp($input['since']):($cursor['since']??$until-DAY_IN_SECONDS);
            if($since===null||$until===null||$since>=$until||$until-$since>31*DAY_IN_SECONDS)return Result::fail('error_log_period_invalid','Use since < until em RFC 3339, até 31 dias.');
            $criteria=hash('sha256',serialize([$since,$until,$input['level']??null,$input['text']??null]));if($cursor&&$cursor['criteria']!==$criteria)return Result::fail('cursor_invalid','Filtros divergentes do cursor.');
            $deadline=microtime(true)+5;$examined=0;$dir=self::directory();$zone=new \DateTimeZone(self::FILE_ZONE);$from=(new \DateTimeImmutable('@'.$since))->setTimezone($zone)->format('Y-m-d');$to=(new \DateTimeImmutable('@'.($until-1)))->setTimezone($zone)->format('Y-m-d');$files=[];
            foreach(new \FilesystemIterator($dir,\FilesystemIterator::SKIP_DOTS) as $entry){if(++$examined>4096||microtime(true)>$deadline)throw new \RuntimeException('error_log_scan_limit');$name=$entry->getFilename();if(!preg_match('/^error\.log(?:\.(\d{4}-\d{2}-\d{2}))?(\.gz)?$/D',$name,$m)||$entry->isLink()||!$entry->isFile())continue;if(!empty($m[1])&&($m[1]<$from||$m[1]>$to))continue;
                $path=$entry->getPathname();$allowed=AuthorizationPolicy::check('files/read',['path'=>$path],true);if(is_wp_error($allowed)||is_wp_error(PathGuard::resolve($path,false)))throw new \RuntimeException('permission_denied');
                $files[$name]=['path'=>$path,'size'=>$entry->getSize(),'mtime'=>$entry->getMTime(),'inode'=>$entry->getInode(),'dev'=>stat($path)['dev']];
                if(count($files)>128)throw new \RuntimeException('error_log_scan_limit');
            }
            ksort($files);$fingerprint=hash('sha256',serialize($files));if($cursor&&$cursor['inventory']!==$fingerprint)return Result::fail('error_log_changed','Logs mudaram; reinicie a paginação.',['conflict'=>true]);
            $groups=[];$bytes=0;$lines=0;$ignored=0;$compressed=0;$samples=[];
            foreach($files as $name=>$meta){$gzip=str_ends_with($name,'.gz');if($gzip)$compressed++;$h=null;$file_line=0;try{$h=self::open($meta['path'],$gzip,$deadline,$meta);if(!$h)throw new \RuntimeException('error_log_unreadable');
                while(!feof($h)){$line=fgets($h,65537);if($line===false){if(!feof($h))throw new \RuntimeException('error_log_unreadable');break;}$bytes+=strlen($line);$lines++;$file_line++;
                    if($bytes>33554432||microtime(true)>$deadline)throw new \RuntimeException('error_log_scan_limit');
                    if(strlen($line)>=65536&&!str_ends_with($line,"\n"))throw new \RuntimeException('error_log_line_limit');
                    $row=self::parse($line);if(!$row){$ignored++;
                        if(count($samples)<3){$excerpt=DataSafety::diagnostic_excerpt(self::decode_utf8_escapes($line),256);
                            if($excerpt!==''&&!in_array($excerpt,array_column($samples,'sample'),true)){
                                $sample=['source'=>$name,'line'=>$file_line,'sample'=>$excerpt];
                                while(strlen(wp_json_encode($sample))>256&&strlen($sample['sample'])>16)$sample['sample']=DataSafety::diagnostic_excerpt($sample['sample'],max(16,intdiv(strlen($sample['sample']),2)));
                                if(strlen(wp_json_encode($sample))<=256)$samples[]=$sample;
                            }
                        }continue;}
                    if($row['time']<$since||$row['time']>=$until||isset($input['level'])&&$row['level']!==$input['level']||isset($input['text'])&&!str_contains($row['message'],$input['text']))continue;
                    $key=hash('sha256',serialize([$row['level'],$row['message'],$row['file'],$row['line']]));
                    if(!isset($groups[$key])){$time=$row['time'];unset($row['time']);$groups[$key]=$row+['group_id'=>$key,'count'=>0,'first'=>$time,'last'=>$time];}
                    $groups[$key]['count']++;$groups[$key]['first']=min($groups[$key]['first'],$row['time']??$time);$groups[$key]['last']=max($groups[$key]['last'],$row['time']??$time);
                    if(count($groups)>5000)throw new \RuntimeException('error_log_scan_limit');
                }}finally{if(is_resource($h))fclose($h);}
                clearstatcache(true,$meta['path']);$after=stat($meta['path']);if(!$after||$after['ino']!==$meta['inode']||$after['size']!==$meta['size']||$after['mtime']!==$meta['mtime'])throw new \RuntimeException('error_log_changed');
            }
            ksort($groups);$groups=array_values($groups);$offset=(int)($cursor['offset']??0);$page=[];$page_bytes=0;$limit=max(1,min(30,(int)($input['per_page']??20)));
            foreach(array_slice($groups,$offset,$limit) as $row){foreach(['first','last'] as $f)$row[$f]=(new \DateTimeImmutable('@'.$row[$f]))->setTimezone(wp_timezone())->format(DATE_RFC3339);$row['message_truncated']=strlen($row['message'])>800;$row['message']=self::cut($row['message'],800);if($row['file']!==null)$row['file']=self::cut($row['file'],256);$size=strlen(wp_json_encode($row));while($size>2500&&strlen($row['message'])>50){$row['message']=self::cut($row['message'],intdiv(strlen($row['message']),2));$row['message_truncated']=true;$size=strlen(wp_json_encode($row));}if($page_bytes+$size>5200)break;$page[]=$row;$page_bytes+=$size;}
            $next=$offset+count($page);$more=$next<count($groups);$token=$more?Cursor::encode(['kind'=>'hosting-error-log/3','site'=>get_current_blog_id(),'connection'=>ConnectionContext::key(),'criteria'=>$criteria,'inventory'=>$fingerprint,'since'=>$since,'until'=>$until,'offset'=>$next,'expires'=>$cursor['expires']??time()+900]):null;
            return Result::ok(['groups'=>$page,'total_groups'=>count($groups),'has_more'=>$more,'next_cursor'=>$token,'since'=>gmdate(DATE_RFC3339,$since),'until'=>gmdate(DATE_RFC3339,$until),'file_timezone'=>self::FILE_ZONE,'site_timezone'=>wp_timezone()->getName(),'aggregation_scope'=>'complete_window','files_scanned'=>count($files),'gzip_files_scanned'=>$compressed,'lines_scanned'=>$lines,'unparsed_lines'=>$ignored,'unparsed_samples'=>$samples,'unparsed_scope'=>'scanned_files','unparsed_sample_limit'=>3,'bytes_scanned'=>$bytes]);
        }catch(\Throwable $e){$code=in_array($e->getMessage(),['permission_denied','error_log_domain_invalid','error_log_not_found','error_log_scan_limit','error_log_line_limit','error_log_unreadable','error_log_changed','error_log_invalid_gzip'],true)?$e->getMessage():'error_log_unavailable';return Result::fail($code,'Leitura não concluída. Confira acesso, reduza o período ou reinicie após rotação. Nenhuma contagem parcial apresentada.');}
    }
}
