<?php
/** Bounded reconciliation of current private envelopes. Tombstones never re-enter. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class BackupInventory {
    public static function advance(int $limit=200): array {
        $limit=max(1,min(200,$limit));$s=StateStore::get('inventory','backups');
        if(!$s||!empty($s['complete']))$s=['after'=>'','complete'=>false,'examined'=>0,'imported'=>0,'blocked'=>[]];
        $dir=StateStore::directory('backups');$files=[];$more=false;
        foreach(new \FilesystemIterator($dir,\FilesystemIterator::SKIP_DOTS) as $f){
            $n=$f->getFilename();if($n<=$s['after']||!preg_match('/^[a-f0-9]{64}\.php$/D',$n))continue;
            $files[$n]=$f->getPathname();
            if(count($files)>$limit+1){ksort($files,SORT_STRING);array_pop($files);}
        }
        ksort($files,SORT_STRING);$more=count($files)>$limit;$deadline=microtime(true)+3;
        foreach(array_slice($files,0,$limit,true) as $n=>$path){
            if(microtime(true)>=$deadline){$more=true;break;}
            $s['after']=$n;$s['examined']++;
            try {
                if(is_link($path)||!is_file($path)||filesize($path)>100*1024*1024)throw new \RuntimeException('unsafe_component');
                $v=BackupStream::read($path);$id=$v['id']??'';
                if(!preg_match('/^(?:db)?[a-f0-9]{16,64}$/iD',(string)$id))throw new \RuntimeException('invalid_identity');
                if((int)($v['site_id']??0)!==get_current_blog_id())continue;
                if(basename(StateStore::path('backups',$id))!==$n)throw new \RuntimeException('identity_mismatch');
                if(Backups::retired($id))continue;$existing=Persistence::get('backup-index',$id);
                if($existing&&isset($existing['plugin']))continue;
                $metadata=Backups::package_metadata($v);if($existing){if($metadata){$existing=array_replace($existing,$metadata,['target'=>$metadata['plugin']]);Persistence::put('backup-index',$id,$existing);$s['imported']++;}continue;}
                $v=array_replace($v,$metadata);
                $v['stored_bytes']=filesize($path);$refs=StateStore::get('backup-references',$id);
                if($refs)$v['protected_by_backups']=$refs['parents']??[];
                unset($v['rows'],$v['sql'],$v['content_base64'],$v['snapshot']);
                $v['target']=$v['plugin']??$v['path']??$v['table']??'';$v['inventory_source']='private_payload';
                if(Persistence::put('backup-index',$id,$v,true))$s['imported']++;
            }catch(\Throwable $e){
                // Cap diagnostic memory, while retaining a count and leaving every original intact.
                $s['blocked_count']=($s['blocked_count']??0)+1;
                if(count($s['blocked'])<200)$s['blocked'][]=['file'=>$n,'reason'=>in_array($e->getMessage(),['unsafe_component','invalid_identity','identity_mismatch'],true)?$e->getMessage():'invalid_metadata'];
            }
        }
        $s['complete']=!$more;$s['time']=time();StateStore::put('inventory','backups',$s);
        return array_intersect_key($s,array_flip(['complete','examined','imported','blocked','blocked_count']))+['sources'=>['private_payload']];
    }
}
