<?php
/** Internal root invocation capability. Never derived from client arguments. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class RootToolContext {
    private static ?array $root=null;
    private static array $abilities=[];
    public static function open($server,string $name): ?object {
        if(self::$root!==null || self::$abilities || !$server instanceof \WpMcpUltimate\Server\McpServer || !ConnectionEndpoints::is_owned($server))return null;
        $context=ConnectionContext::get();
        if(!$context || !in_array($context['transport']??'', ['oauth','wordpress-application-password'],true))return null;
        $ability=wp_get_ability($name);$descriptor=$ability?ExecutorRegistry::descriptor($ability):null;
        if(!$descriptor)return null;
        $handle=new \stdClass();self::$root=['handle'=>$handle,'name'=>$name,'connection'=>$context['connection_id'],'user'=>get_current_user_id(),'policy'=>self::policy($context),'descriptor'=>$descriptor];
        return $handle;
    }
    public static function close(?object $handle): void {
        if($handle!==null && (self::$root['handle']??null)===$handle)self::$root=null;
    }
    /** True while an MCP tools/call dispatch owns this request. */
    public static function active(): bool {return self::$root!==null;}
    /** Names of decorated abilities currently executing in this request, outermost first. */
    public static function stack(): array {return self::$abilities;}
    public static function enter(string $name): void {self::$abilities[]=$name;}
    public static function leave(): void {array_pop(self::$abilities);}
    private static function policy(array $context): string {
        unset($context['last_seen'],$context['transport'],$context['last_protocol_request']);
        // Touch timestamps are observational, not policy changes.
        unset($context['_storage']);
        return hash('sha256',serialize(self::canonical($context)));
    }
    private static function canonical(array $value): array {
        if(!array_is_list($value))ksort($value);
        foreach($value as &$item)if(is_array($item))$item=self::canonical($item);
        return $value;
    }
    private static function current(): bool {
        $context=ConnectionContext::get();
        return self::$root&&$context&&self::$root['user']===get_current_user_id()&&self::$root['connection']===$context['connection_id']&&self::$root['policy']===self::policy($context);
    }
    public static function check_target(\WP_Ability $ability) {
        if(!self::$root)return true;
        if($ability->get_name()===self::$root['name']&&self::allows($ability))return true;
        if(!self::current()||!ExecutorRegistry::target(self::$root['descriptor'],$ability))return new \WP_Error('executor_target_forbidden','Target or current policy is outside this root executor declaration.');
        return true;
    }
    public static function allows(\WP_Ability $ability): bool {
        if(!self::$root || !ExecutorRegistry::descriptor($ability) || !self::current())return false;
        $name=$ability->get_name();
        return self::$root['name']===$name && self::$root['user']===get_current_user_id()
            && self::$root['connection']===ConnectionContext::key()
            && (self::$abilities===[] || self::$abilities===[$name]);
    }
}
