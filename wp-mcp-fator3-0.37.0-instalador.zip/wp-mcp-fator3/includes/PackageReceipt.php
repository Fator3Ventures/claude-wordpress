<?php
/** Durable upload intent: created before download, linked before the filesystem effect. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class PackageReceipt {
    private static ?string $active=null;
    public static function id(): ?string {if(self::$active===null)return null;return StateStore::get('package-uploads',self::$active)['package_operation_id']??null;}
    private static function canonical($value) {if(!is_array($value))return $value;if(array_keys($value)!==range(0,count($value)-1))ksort($value);foreach($value as &$v)$v=self::canonical($v);unset($v);return $value;}
    public static function once(string $name,array $input,callable $run): array {
        $key=ConnectionContext::key().':'.get_current_user_id().':'.$name.':'.$input['idempotency_key'];
        $intent=['sha256'=>strtolower($input['expected_sha256']),'activate'=>(bool)($input['activate']??false),'overwrite'=>(bool)($input['overwrite']??false),'slug'=>$input['expected_slug']??null];$fingerprint=hash('sha256',serialize($intent));
        return Locks::run(['once:'.get_current_blog_id().':'.$key=>LOCK_EX],static function()use($key,$fingerprint,$name,$input,$run){
            $ability=wp_get_ability($name);$permission=$ability?$ability->check_permissions($input):false;
            if(is_wp_error($permission))return Result::error($permission);if($permission!==true)return Result::fail('permission_denied','Permissão atual insuficiente para ler o recibo.');
            $state=StateStore::get('package-uploads',$key);
            if(!$state&&($legacy=StateStore::get('idempotency',$key))){
                // The accepted base already consumed these keys. Never create a second intent on upgrade.
                $args=$input;unset($args['idempotency_key']);$old_fingerprint=hash('sha256',serialize(self::canonical($args)));
                if(!hash_equals((string)($legacy['fingerprint']??''),$old_fingerprint))return Result::fail('idempotency_conflict','Recibo da versão anterior exige os mesmos parâmetros originais.',['conflict'=>true]);
                if(($legacy['status']??'')==='complete')return array_replace($legacy['result'],['replayed'=>true,'receipt_source'=>'previous_idempotency_contract']);
                return Result::fail(($legacy['status']??'')==='compacted'?'idempotency_result_expired':'operation_uncertain','Operação anterior preservada; esta chave não inicia outra troca.',['operation_id'=>$legacy['operation_id']??'','replayed'=>true,'receipt_source'=>'previous_idempotency_contract']);
            }
            if($state){
                if(!hash_equals($state['fingerprint'],$fingerprint))return Result::fail('idempotency_conflict','Chave usada para outro ZIP ou outra intenção de ativação/substituição.',['conflict'=>true]);
                if(isset($state['result']))return array_replace($state['result'],['replayed'=>true]);
                $id=$state['package_operation_id'];$journal=\Fator3\RecoveryV1\Engine::read(Recovery::directory().'/'.$id.'.journal.php');
                if($journal){$r=PackageService::operation_status(['operation_id'=>$id]);return $r+['package_operation_id'=>$id,'replayed'=>true,'download_repeated'=>false,'applied'=>($journal['status']==='complete'?true:(in_array($journal['status'],['rolled_back','unchanged'],true)?false:null)),'pending'=>!in_array($journal['status'],['complete','rolled_back','unchanged'],true),'files_applied'=>($r['file_state']??'')==='candidate'];}
                return Result::fail('package_operation_interrupted','Execução anterior interrompida antes do diário; nenhuma nova troca será iniciada por esta chave.',['package_operation_id'=>$id,'applied'=>false,'replayed'=>true,'download_repeated'=>false]);
            }
            $id=bin2hex(random_bytes(16));$state=['fingerprint'=>$fingerprint,'package_operation_id'=>$id,'status'=>'running','time'=>time(),'connection_id'=>ConnectionContext::key(),'user_id'=>get_current_user_id()];
            if(!Persistence::put('package-uploads',$key,$state,true))return Result::fail('operation_uncertain','Recibo concorrente; releia com a mesma chave.');
            $old=self::$active;self::$active=$key;
            try{$r=Result::normalize($run());$r['package_operation_id']=$r['package_operation_id']??$id;$r['operation_id']=$r['operation_id']??$id;
                $state['status']='complete';$state['result']=$r;StateStore::put('package-uploads',$key,$state);return $r;
            }finally{self::$active=$old;}
        });
    }
}
