<?php
/** Execution boundary shared by the decorator and cooperating providers. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ExecutionCoordinator {
	public static function locked(string $name, array $input, callable $callback, bool $transport_key = false) {
		$call = static function () use ($input, $callback, $name, $transport_key) {
            $ability=wp_get_ability($name);$permission=$ability?$ability->check_permissions($input):false;
            if(is_wp_error($permission))return Result::error($permission);if($permission!==true)return Result::fail('permission_denied','Permissão mudou durante a espera pelo lock.');
            if(str_starts_with($name,'files/')&&isset($input['backup'])&&$input['backup']===false){foreach(['path','source','destination'] as $field)if(isset($input[$field])&&Recovery::runtime_path($input[$field]))return Result::fail('runtime_backup_required','PHP exige pré-imagem durável.');}
            $args = $input; if ($transport_key) unset($args['idempotency_key']);
            // Provider fields belong to their contract; Google uses label as business input.
            if(!empty($ability->get_meta()['fator3']['owned']))unset($args['label']);
            if(DestructiveActions::supports($name))unset($args['confirm_token'],$args['confirm']);
			if (preg_match('~^(content/(update|patch|delete)-(post|page)|media/(update|delete|regenerate|set-site-icon|convert)|content/(edit-block|restore-revision|update-meta|delete-meta|update-seo))$~', $name)) unset($args['expected_revision']); return Backups::labelled($input, static fn() => Recovery::scope($input,static fn() => DestructiveActions::required($name,$input) ? DestructiveActions::run($name,$input,static fn()=>$callback($args)) : $callback($args))); };
        if ($name==='media/get' && !empty($input['id'])) {
            return Locks::run(['post:'.get_current_blog_id().':'.(int)$input['id']=>LOCK_SH],static function()use($input,$call){
                $id=(int)$input['id'];clean_post_cache($id);$before=ContentTools::revision($id);
                $result=Result::normalize($call());
                if(!empty($result['success'])&&isset($result['media'])){
                    $after=ContentTools::revision($id);
                    if($before!==$after)return Result::fail('content_conflict','Anexo mudou durante a leitura; consulte novamente.',['conflict'=>true,'current_revision'=>$after]);
                    $result['revision']=$after;
                }
                return $result;
            });
        }
        if (in_array($name,['content/create-post','content/create-page'],true)) {
            $result=Result::normalize($call());$id=(int)($result['id']??0);
            if($id&&get_post($id)){
                clean_post_cache($id);$result['revision']=ContentTools::revision($id);$result['changed']=true;$result['applied']=true;
                $actual=ContentContracts::raw($id);
                if(is_wp_error($actual))return Result::fail('content_readback_failed','Conteúdo criado, mas a leitura de volta falhou.',$result+['persisted'=>null]);
                $result+=array_diff_key($actual,['content'=>true]);$result['persisted']=true;
                if(isset($input['content'])&&$actual['content']!==$input['content'])return Result::fail('content_filtered','Conteúdo criado difere após os filtros do WordPress.',$result);
                if(isset($input['featured_media'])&&(int)get_post_thumbnail_id($id)!==(int)$input['featured_media'])return Result::fail('featured_media_not_persisted','Conteúdo criado; imagem destacada divergente.',$result);
            }
            return $result;
        }
		if (in_array($name, ['db/query','db/execute'], true)) return DatabaseBudget::run((string)($input['sql'] ?? ''), $call);
		if (in_array($name, ['files/read','files/stat'], true)) return Locks::files([(string)($input['path'] ?? '')], static fn() => $call(), false);
		if (in_array($name,['media/upload','media/delete','media/regenerate','media/set-site-icon','media/convert'],true) || 'content/delete-post' === $name && !empty($input['id']) && 'attachment' === get_post_type((int)$input['id'])) {
			$upload = wp_upload_dir(null, false); $roots = [$upload['basedir']];
			if (!empty($input['id'])) { $attached = get_attached_file((int)$input['id']); if ($attached) $roots[] = dirname($attached); }
			foreach ($roots as &$root) while (!is_dir($root) && dirname($root) !== $root) $root = dirname($root); unset($root);
			$native = $call; $call = static fn() => Locks::trees(array_unique($roots), $native);
		}
		if (in_array($name, ['plugins/upload','plugins/upload-base64','plugins/delete','plugins/install','plugins/update','plugins/rollback','plugins/reconcile','plugins/cleanup-orphaned-uninstall'], true)) return Locks::trees([WP_PLUGIN_DIR], $call);
		if (in_array($name, ['themes/install','themes/activate'], true)) return Locks::trees([get_theme_root()], $call);
		if (in_array($name, ['files/write', 'files/patch', 'files/delete', 'files/fetch', 'files/restore'], true)) {
			if (!PathGuard::is_enabled() || !PathGuard::can_edit()) return Result::fail('permission_denied', 'File channel is closed or permission is missing.');
			$requested = (string)($input['path'] ?? '');
			if ('files/restore' === $name) {
				$meta = Backups::metadata((string)($input['backup_id'] ?? ''), false);
				if (is_wp_error($meta)) return Result::error($meta);
				if (($meta['kind'] ?? '') !== 'file' || !is_string($meta['path'] ?? null)) return Result::fail('backup_type_mismatch', 'files/restore requires a file backup.');
				$requested = (string)$meta['path'];
			}
			return Locks::files([$requested], static function ($paths) use ($requested, $input, $call) {
				$conflict = Locks::check_hash($paths[$requested], $input);
				return $conflict ?? $call();
			});
		}
		if (preg_match('~^(content/(update|patch|delete)-(post|page)|media/(update|delete|regenerate|set-site-icon|convert)|content/(edit-block|restore-revision|update-meta|delete-meta|update-seo))$~', $name) && !empty($input['id'])) {
			return Locks::run(['post:' . get_current_blog_id() . ':' . (int)$input['id'] => LOCK_EX], static function () use ($input, $call, $name) {
				clean_post_cache((int)$input['id']);
				if (isset($input['expected_revision']) && get_post((int)$input['id'])) {
					$current = ContentTools::revision((int)$input['id']);
					if (!hash_equals($current, (string)$input['expected_revision'])) return Result::fail('content_conflict', 'Content changed since the supplied revision.', ['conflict' => true, 'current_revision' => $current]);
				}
				$result=Result::normalize($call());
				if (get_post((int)$input['id'])) { clean_post_cache((int)$input['id']);$result[$name==='media/convert'?'source_revision':'revision']=ContentTools::revision((int)$input['id']); }
				return $result;
			});
		}
		if ('options/delete' === $name) {
            $keys=[]; foreach($input['names']??[] as $option) $keys['option:'.get_current_blog_id().':'.$option]=LOCK_EX;
            return Locks::run($keys,$call);
        }
        if ('menus/delete' === $name) return Locks::run(['menu:'.get_current_blog_id().':'.(int)($input['menu_id']??0)=>LOCK_EX],$call);
        if (in_array($name,['users/create','users/update','users/delete'],true)) return Locks::run(['wordpress-roles'=>LOCK_EX,'user:'.(int)($input['id']??0)=>LOCK_EX],$call);
        if ($name==='options/update' && ($input['name']??'')==='default_role') return Locks::run(['wordpress-roles'=>LOCK_EX],$call);
		if ('options/update' === $name) return Locks::run(['option:' . get_current_blog_id() . ':' . (string)($input['name'] ?? '') => LOCK_EX], $call);
		if ('comments/delete' === $name) return Locks::run(['comment:' . get_current_blog_id() . ':' . (int)($input['id'] ?? 0) => LOCK_EX], $call);
		return $call();
	}
	private static function canonical($value) { if (!is_array($value)) return $value; if (array_keys($value) !== range(0, count($value) - 1)) ksort($value); foreach ($value as &$v) $v = self::canonical($v); unset($v); return $value; }
	/**
	 * A failure the producer declared retryable and not applied: nothing to replay.
	 * Absence of an effect flag is not proof of non-delivery. Require an explicit
	 * applied=false; any present unknown/partial/effect flag keeps the receipt.
	 */
	public static function transient(array $result): bool {
		if (false !== ($result['success'] ?? true) || true !== ($result['retryable'] ?? false) || false !== ($result['applied'] ?? null)) return false;
		foreach (['persisted','changed','partial'] as $field) {
			if (array_key_exists($field, $result) && false !== $result[$field]) return false;
		}
		return !in_array((string)($result['error_code'] ?? ''), ['operation_uncertain','idempotency_conflict','idempotency_result_expired','idempotency_revalidation_required'], true);
	}
	public static function once(string $name, array $input, callable $run, string $operation_id, bool $native_key = false): array {
        if(in_array($name,['plugins/upload','plugins/upload-base64'],true)&&isset($input['expected_sha256']))return PackageReceipt::once($name,$input,$run);
		$key = ConnectionContext::key() . ':' . get_current_user_id() . ':' . $name . ':' . $input['idempotency_key'];
        $args=$input;unset($args['idempotency_key']);
		$fingerprint = hash('sha256', serialize(self::canonical($args)));
		return Locks::run(['once:' . get_current_blog_id() . ':' . $key => LOCK_EX], static function () use ($key, $fingerprint, $run, $operation_id, $name, $input, $native_key) {
			// A request may wait behind another execution. Recheck the producer and
			// channel policy under the same lock, including before a cached replay.
			$ability = wp_get_ability($name);
			$permission = $ability ? $ability->check_permissions($input) : false;
			if (is_wp_error($permission)) return Result::error($permission);
			if ($permission !== true) return Result::fail('permission_denied', 'Permissão mudou durante a espera pelo lock.');
			$state = StateStore::get('idempotency', $key);
			if ($state && ($state['status']??'')==='deleted') $state=null;
			// 0.29.0: a stored retryable failure without effect (including one stored by
			// 0.28.0) does not consume the key; the same key may run again.
			if ($state && 'complete' === ($state['status']??'') && hash_equals($state['fingerprint'], $fingerprint) && self::transient((array)($state['result']??[]))) { StateStore::delete('idempotency', $key); $state = null; }
			if ($state) {
				if (!hash_equals($state['fingerprint'], $fingerprint)) return Result::fail('idempotency_conflict', 'This key was used with different parameters.', ['conflict' => true]);
				if ('compacted' === $state['status']) return Result::fail('idempotency_result_expired','Efeito anterior registrado; resultado foi compactado. A chave não executará novamente.',['operation_id'=>$state['operation_id'],'replayed'=>true]);
				if ('complete' === $state['status']) {
					if (!$native_key || ($state['result']['success']??true) === false) return array_replace($state['result'], ['replayed' => true]);
					// Native producers own their receipt and authorization checks. A replay
					// must visit their idempotent callback, never disclose our cached data.
					if (empty($state['native_key'])) return Result::fail('idempotency_revalidation_required','Registro anterior exige reconciliação no produtor antes de nova intenção.',['operation_id'=>$state['operation_id'],'replayed'=>true]);
					$replayed = Result::normalize($run());
					return array_replace($replayed,['operation_id'=>$state['operation_id'],'replayed'=>true]);
				}
				return Result::fail('operation_uncertain', 'A previous execution did not record completion. Inspect its target before creating another operation.', ['operation_id' => $state['operation_id']]);
			}
			if (!Persistence::put('idempotency', $key, ['status' => 'running', 'fingerprint' => $fingerprint, 'operation_id' => $operation_id, 'time' => time()], !Persistence::get('idempotency',$key))) return Result::fail('operation_uncertain','Claim já existe; reconcilie a operação.');
			$result = Result::normalize($run());
			$result['operation_id'] = $operation_id;
			if (in_array($result['error_code'] ?? '', ['resource_busy','file_conflict','content_conflict','database_conflict','artifact_in_use','backup_selection_conflict','backup_prune_partial'], true) || self::transient($result)) { StateStore::delete('idempotency', $key); return $result; }
			StateStore::put('idempotency', $key, ['status' => 'complete', 'fingerprint' => $fingerprint, 'operation_id' => $operation_id, 'result' => $result, 'native_key'=>$native_key, 'time' => time()]);
			return $result;
		});
	}
}
