<?php
/** Local administrator view. Values come from ConnectionsAdmin::render(). */
namespace Fator3\McpFiles;
$profiles = ['read'=>'Leitura','content'=>'Conteúdo','maintenance'=>'Manutenção','custom'=>'Personalizado'];
$states = ['active'=>'Ativa','revoked'=>'Revogada','expired'=>'Expirada','disabled'=>'Desabilitada'];
?>
<section class="f3-card">
<h2>Clientes conectados</h2>
<p>O perfil limita o MCP e preserva as permissões do usuário WordPress. Use usuários de serviço por função. Integrações identificadas apenas pelo usuário compartilham a mesma política.</p>
<p>Configure o perfil de cada credencial. Revogações e restrições escolhidas são preservadas. Manutenção usa as permissões do usuário WordPress e do processo PHP; raízes e permissões adicionais abaixo se aplicam aos perfis restritos.</p>
<div class="f3-table-scroll" tabindex="0" role="region" aria-label="Conexões e perfis">
<table class="widefat striped f3-connections-table"><thead><tr><th>Identidade</th><th>Usuário</th><th>Perfil</th><th>Estado</th><th>Expira (UTC)</th><th>Último acesso (UTC)</th><th>Cliente / sessões</th><th>Ação</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr>
<td><?php echo esc_html(($row['label']??'')?:'Cliente sem nome'); ?><br><code><?php echo esc_html($row['connection_id']); ?></code></td>
<td><?php echo esc_html((get_userdata((int)$row['user_id'])->display_name??'Usuário removido').' (#'.$row['user_id'].')'); ?></td>
<td><?php echo esc_html($profiles[$row['profile']??'']??'Sem acesso'); ?></td>
<td><?php echo esc_html($states[$row['status']??'active']??'Estado não reconhecido'); ?></td>
<td><?php echo esc_html(empty($row['expires'])?'—':gmdate('d/m/Y H:i',$row['expires'])); ?></td>
<td><?php echo esc_html(empty($row['last_seen'])?'Ainda não observado':gmdate('d/m/Y H:i',$row['last_seen'])); ?></td>
<td><?php echo esc_html(($row['client_id']??'Senha/integração').' · '.$session_counts[$row['connection_id']].' sessões'); ?></td>
<td><a href="<?php echo esc_url(add_query_arg('connection',$row['connection_id'],Admin::url('connections'))); ?>">Editar</a></td>
</tr>
<?php endforeach; ?>
</tbody></table></div>
<p>Até 50 conexões por página, das mais recentes para as antigas. Revogar uma concessão OAuth encerra sua família de tokens.</p>
<?php if ($more): ?><p><a class="button" href="<?php echo esc_url(add_query_arg('before_id',end($rows)['_row_id'],Admin::url('connections'))); ?>">Conexões anteriores</a></p><?php endif; ?>
</section>
<?php if(!$editing && (!empty($_GET['choose_user']) || $user_search!=='')): ?>
<section class="f3-card"><h2>Pesquisar usuário</h2><form method="get"><input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="connections"><label for="f3-user-search">Nome ou identificação de acesso</label><input id="f3-user-search" type="search" name="user_search" value="<?php echo esc_attr($user_search); ?>"><button class="button">Pesquisar usuários</button></form><p>Até 100 resultados. Refine a pesquisa para localizar outra conta.</p></section>
<?php endif; ?>
<section class="f3-card">
<h2><?php echo $editing?'Editar identidade':'Configurar uma identidade'; ?></h2>
<?php if ($editing): ?><p>Valores atuais carregados. <a href="<?php echo esc_url(Admin::url('connections')); ?>">Configurar outra identidade ou emitir nova credencial</a></p><?php endif; ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<?php Admin::nonce('f3_mcp_connection'); ?>
<input type="hidden" name="action" value="f3_mcp_connection">
<?php if ($editing): ?><input type="hidden" name="expected_policy_version" value="<?php echo esc_attr((string)($values['policy_version']??0)); ?>"><?php endif; ?>
<?php if (!$editing): ?>
<p><a href="<?php echo esc_url(add_query_arg('choose_user','1',Admin::url('connections'))); ?>">Pesquisar outro usuário</a></p>
<?php endif; ?>
<p><label for="f3-connection-user">Usuário WordPress</label><br><select id="f3-connection-user" name="user_id" aria-describedby="f3-user-help" <?php disabled((bool)$editing); ?>>
<?php foreach ($users as $user): ?><option value="<?php echo esc_attr((string)$user->ID); ?>" <?php selected((int)($values['user_id']??($users[0]->ID??0)),(int)$user->ID); ?>><?php echo esc_html($user->display_name.' — '.$user->user_login.' (#'.$user->ID.')'); ?></option><?php endforeach; ?>
</select></p>
<?php if($editing): ?><input type="hidden" name="user_id" value="<?php echo (int)$values['user_id']; ?>"><?php endif; ?>
<?php Admin::help('f3-user-help','As permissões desta conta continuam limitando o cliente. A identidade existente permanece vinculada ao mesmo usuário.'); ?>
<p><label for="f3-connection-identity">Identidade autenticada</label><br><select id="f3-connection-identity" name="connection_id" aria-describedby="f3-identity-help">
<?php if($editing): ?><option value="<?php echo esc_attr($values['connection_id']); ?>"><?php echo esc_html((($values['label']??'')?:'Cliente sem nome').' — '.$values['connection_id']); ?></option>
<?php else: foreach($users as $user): ?>
<option data-user="<?php echo (int)$user->ID; ?>" value="integration:user:<?php echo (int)$user->ID; ?>"><?php echo esc_html('Integração de '.$user->display_name); ?></option>
<?php foreach(\WP_Application_Passwords::get_user_application_passwords($user->ID) as $app): ?><option data-user="<?php echo (int)$user->ID; ?>" value="app:<?php echo esc_attr($app['uuid']); ?>"><?php echo esc_html($app['name'].' — '.$user->display_name); ?></option><?php endforeach; ?>
<?php endforeach; endif; ?>
</select></p>
<?php Admin::help('f3-identity-help','Selecione uma credencial existente. Integrações do mesmo usuário compartilham a política. Para nova senha, use o botão de emissão ao final.'); ?>
<p><label for="f3-connection-label">Nome do cliente</label><br><input id="f3-connection-label" name="label" maxlength="128" value="<?php echo esc_attr($values['label']??''); ?>" aria-describedby="f3-label-help"></p>
<?php Admin::help('f3-label-help','Use um nome que permita reconhecer o assistente ou a integração.'); ?>
<p><label for="f3-connection-profile">Perfil de acesso</label><br><select id="f3-connection-profile" name="profile" aria-describedby="f3-profile-help"><?php foreach ($profiles as $key=>$label): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($values['profile']??'read',$key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></p>
<?php Admin::help('f3-profile-help','Leitura consulta dados; Conteúdo permite editá-los; Manutenção administra o site. Personalizado usa a seleção de habilidades abaixo.'); ?>
<?php
$choices=[];foreach(wp_get_abilities() as $ability)$choices[$ability->get_name()]=Admin::ability_label($ability->get_name());
foreach($values['abilities']??[] as $id)if(!isset($choices[$id]))$choices[$id]='Indisponível no momento — seleção preservada';
asort($choices,SORT_NATURAL|SORT_FLAG_CASE);
Admin::choices('abilities',$choices,$values['abilities']??[],'Habilidades do perfil Personalizado','A pesquisa não muda a seleção. Somente o perfil Personalizado usa esta lista; as permissões do usuário continuam valendo.');
$native_types=['post'=>'Publicação','page'=>'Página','attachment'=>'Mídia','revision'=>'Revisão','nav_menu_item'=>'Item de menu','custom_css'=>'CSS personalizado','customize_changeset'=>'Conjunto de alterações','oembed_cache'=>'Resposta incorporada','user_request'=>'Solicitação de usuário','wp_block'=>'Padrão de blocos','wp_template'=>'Modelo','wp_template_part'=>'Parte de modelo','wp_global_styles'=>'Estilos globais','wp_navigation'=>'Menu de navegação','wp_font_family'=>'Família de fontes','wp_font_face'=>'Variação de fonte'];
$types=[];foreach(get_post_types([], 'objects') as $type)$types[$type->name]=$native_types[$type->name]??$type->labels->singular_name;
foreach($values['post_types']??[] as $id)if(!isset($types[$id]))$types[$id]='Indisponível no momento — seleção preservada';
Admin::choices('post_types',$types,$values['post_types']??[],'Tipos de conteúdo','Nenhuma seleção permite todos os tipos autorizados ao usuário.');
foreach (['roots'=>['Diretórios permitidos','Informe um caminho absoluto existente por linha. Limita arquivos nos perfis restritos; Manutenção segue os limites do servidor.'],'meta_keys'=>['Exceções de metadados','Informe chaves exatas, separadas por linha. Autoriza metadados não registrados nos perfis restritos.']] as $key=>$field): ?>
<p><label for="f3-connection-<?php echo esc_attr($key); ?>"><?php echo esc_html($field[0]); ?></label><br><textarea id="f3-connection-<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>" rows="3" class="large-text" aria-describedby="f3-help-<?php echo esc_attr($key); ?>"><?php echo esc_textarea(implode("\n",$values[$key]??[])); ?></textarea></p>
<?php Admin::help('f3-help-'.$key,$field[1]); endforeach; ?>
<fieldset><legend>Permissões adicionais</legend>
<?php foreach (['allow_backup_export'=>['Exportar cópias de segurança','Permite exportar os valores originais dos backups desta conexão. Esses arquivos podem conter segredos.'],'allow_foreign_backup_export'=>['Exportar backups de outras conexões','Amplia a recuperação administrativa para backups de outros clientes. Exige também a permissão de exportação.'],'database_write'=>['Permitir escrita no banco','Autoriza alterações SQL nos perfis restritos. O canal geral, a prévia e a confirmação continuam obrigatórios.'],'readonly_executor'=>['Expor executor de leitura','Disponibiliza ao cliente uma ferramenta separada para habilidades somente de leitura.']] as $key=>$field): ?>
<p><label><input type="checkbox" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(!empty($values[$key])); ?> aria-describedby="f3-help-<?php echo esc_attr($key); ?>"> <?php echo esc_html($field[0]); ?></label></p>
<?php Admin::help('f3-help-'.$key,$field[1]); endforeach; ?></fieldset>
<p><label for="f3-connection-limit">Limite por arquivo em bytes</label><br><input id="f3-connection-limit" type="number" name="file_bytes" min="1048576" max="1073741824" step="1" value="<?php echo esc_attr((string)($values['file_bytes']??'')); ?>" aria-describedby="f3-limit-help"></p>
<?php Admin::help('f3-limit-help','No perfil Manutenção, use entre 1.048.576 e 1.073.741.824 bytes. Vazio herda o limite do canal.'); ?>
<p><label for="f3-connection-expires">Expiração (UTC)</label><br><input id="f3-connection-expires" type="datetime-local" step="1" name="expires" value="<?php echo esc_attr(empty($values['expires'])?'':gmdate('Y-m-d\TH:i:s',$values['expires'])); ?>" aria-describedby="f3-expires-help"></p>
<?php Admin::help('f3-expires-help','Escolha data e hora em UTC. Vazio mantém acesso sem prazo adicional definido neste perfil.'); ?>
<p><button class="button button-primary" name="intent" value="save">Salvar perfil</button>
<?php if (!$editing): ?><button class="button" name="intent" value="create">Emitir nova senha com este perfil</button><?php endif; ?>
<button class="button f3-danger" name="intent" value="revoke">Revogar esta identidade</button></p>
</form></section>
