<?php
/** Presentation redaction, byte transport and bounded regular expressions. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class DataSafety {
    /** Names/components, never arbitrary substrings such as pass in passagens. */
    private static function key_name(string $key): string {
        $key=preg_replace('/([a-z0-9])([A-Z])/', '$1_$2', $key);
        $key=preg_replace('/([A-Z])([A-Z][a-z])/', '$1_$2', $key);
        return trim((string)preg_replace('/[^a-z0-9]+/', '_', strtolower($key)), '_');
    }
    public static function secret_key(string $key): bool {
        $name=self::key_name($key);
        if(preg_match('/(?:^|_)(?:pass|passwords?|passwd|pwd|senhas?|secrets?|segredos?|tokens?|credentials?|credenciais|cookies?|authorization|salts?|chaves?)(?:_|$)/D',$name))return true;
        if(preg_match('/(?:^|_)(?:api|private|auth|activation|access|consumer|client|encryption|signing)_?key(?:_|$)/D',$name))return true;
        return (bool)preg_match('/(?:^|_)(?:accesstoken|refreshtoken|idtoken|clientsecret|sessiontokens|applicationpasswords|userpass)(?:_|$)/D',$name);
    }
    /** Presentation-only diagnostics. Storage/write guards still use secret_key(). */
    public static function diagnostic(string $key, $value): bool {
        $name=self::key_name($key);
        if(is_bool($value) && preg_match('/(?:^|_)(?:configured|present|available|valid|expired|enabled|verified)$/D',$name))return true;
        if((is_int($value)||is_float($value)) && is_finite((float)$value) && $value>=0 && preg_match('/(?:^|_)(?:count|total|generation|revision|age_seconds|expires_in|ttl_seconds)$/D',$name))return true;
        return is_string($value) && preg_match('/(?:^|_)(?:created_at|updated_at|expires_at|expired_at|issued_at|checked_at)$/D',$name)
            && (bool)preg_match('/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2}))?$/D',$value);
    }
    public static function sensitive_field(string $key, $value): bool {
        return self::secret_key($key) && !self::diagnostic($key,$value);
    }
    /** Recognizable complete credential values; no entropy/hash/UUID heuristic. */
    public static function secret_value($value): bool {
        if(!is_string($value))return false;
        $text=trim($value);
        return (bool)preg_match('~^(?:(?:Authorization:\s*)?(?:Bearer|Basic)\s+\S+|-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----[\s\S]+|eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)$~iD',$text);
    }
    /** Error/log text only: redact credentials, not the words describing them. */
    public static function diagnostic_text(string $value): string {
        if(self::secret_value($value))return '[redigido]';
        return (string)preg_replace('~\b(?:Bearer|Basic)\s+[A-Za-z0-9._\~+/-]+=*~i','[redigido]',$value);
    }
    /** Full diagnostic text for grouping. Never used for storage/write decisions. */
    public static function diagnostic_detail(string $text): string {
        if(defined('DB_PASSWORD')&&is_string(DB_PASSWORD)&&strlen(DB_PASSWORD)>0)$text=str_replace(DB_PASSWORD,'[redigido]',$text);
        foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $key)if(defined($key)&&is_string(constant($key))&&strlen(constant($key))>8)$text=str_replace(constant($key),'[redigido]',$text);
        $text=self::diagnostic_text($text);
        $text=(string)preg_replace('~\b((?:db[_-]?)?password|passwd|pwd|senha|secret|(?:api|access|refresh|private|client)[_-]?(?:key|token|secret)|authorization|token)\b[\x22\x27]?\s*[:=]\s*(?:\x22[^\x22]*\x22|\x27[^\x27]*\x27|[^\s,;\x22\x27]+)~i','$1=[redigido]',$text);
        $text=(string)preg_replace('~(https?://)[^\s/@:]+:[^\s/@]+@~i','$1[redigido]@',$text);
        return (string)preg_replace('~\b(?:AIza[0-9A-Za-z_-]{30,}|sk-[0-9A-Za-z_-]{16,}|eyJ[0-9A-Za-z_-]+\.eyJ[0-9A-Za-z_-]+\.[0-9A-Za-z_-]+)\b~','[redigido]',$text);
    }
    /** Short unstructured diagnostics: redact the whole input before cutting. */
    public static function diagnostic_excerpt(string $text,int $limit=320): string {
        // Unknown syntax/escaped quotes cannot reliably delimit a credential: hide its line suffix.
        $text=(string)preg_replace('~\b((?:db[_-]?)?password|passwd|pwd|senha|secret|(?:api|access|refresh|private|client)[_-]?(?:key|token|secret)|authorization|token|cookies?|session[_-]?id|phpsessid)\b[\x22\x27]?\s*[:=][^\r\n]*~i','$1=[redigido]',$text);
        $text=self::diagnostic_detail($text);
        $text=(string)preg_replace('~\b(?:Stack trace:|SELECT\s+|INSERT\s+INTO\b|UPDATE\s+\S+\s+SET\b|DELETE\s+FROM\b|ALTER\s+TABLE\b|CREATE\s+TABLE\b|DROP\s+TABLE\b)[\s\S]*~i','[detalhes redigidos]',$text);
        $text=(string)preg_replace('~-----BEGIN [^\r\n]*PRIVATE KEY-----[\s\S]*|\b(?:Set-Cookie|Cookie)\s*:[^\r\n]*~i','[redigido]',$text);
        $text=(string)preg_replace('~\b(?:https?|ftp)://[^\s<>\x22\x27]+~i','[url redigida]',$text);
        $text=(string)preg_replace('~\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b~i','[email redigido]',$text);
        $text=(string)preg_replace('~\[(?:client|remote)\s+[^\]]*\]|\b(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?\b~i','[endereco redigido]',$text);
        $text=(string)preg_replace_callback('~(?<![\w:])[0-9a-f:]*:[0-9a-f:]+(?:%[a-z0-9]+)?(?![\w:])~i',static fn($m)=>filter_var(explode('%',$m[0])[0],FILTER_VALIDATE_IP,FILTER_FLAG_IPV6)?'[endereco redigido]':$m[0],$text);
        $text=(string)preg_replace('~/(?:home|Users)/[^/\s]+~','/home/[usuario]',$text);
        $text=(string)preg_replace('~\x22[^\x22\r\n]*\x22|\x27[^\x27\r\n]*\x27|(?<![A-Za-z0-9_+/=\-])[A-Za-z0-9_+/=\-]{32,}(?![A-Za-z0-9_+/=\-])~','[redigido]',$text);
        $text=wp_check_invalid_utf8($text,true);
        $text=trim((string)preg_replace('/[\x00-\x20\x7f]+/',' ',$text));
        $limit=max(16,min(512,$limit));
        if(strlen($text)<=$limit)return $text;
        return (function_exists('mb_strcut')?mb_strcut($text,0,$limit-3,'UTF-8'):wp_check_invalid_utf8(substr($text,0,$limit-3),true)).'...';
    }
	/** This copy is for presentation only. Never feed it to recovery or comparison. */
	public static function rows(array $rows, ?string $table = null): array {
		$redacted = [];
		foreach ($rows as $index => &$row) {
			if (!is_array($row)) continue;
			$key = (string)($row['option_name'] ?? $row['meta_key'] ?? '');
			foreach ($row as $column => &$value) {
				$payload = in_array(strtolower((string)$column), ['option_value', 'meta_value'], true);
				$hide = self::secret_key((string)$column) || self::secret_value($value) || ($payload && ('' === $key || self::secret_key($key)));
				// Extensions may add sensitivity; they cannot unclassify built-in secrets.
				$hide = $hide || (bool)apply_filters('f3_mcp_sensitive_cell', false, $table, $column, $key);
				if ($hide) { $value = '[redigido]'; $redacted[] = $index . '.' . $column; }
			}
			unset($value);
		}
		unset($row);
		return ['rows' => $rows, 'redacted' => array_values(array_unique($redacted))];
	}
	public static function binary_extension(string $path): bool {
		return in_array(strtolower(pathinfo($path, PATHINFO_EXTENSION)), ['zip','gz','bz2','xz','7z','rar','tar','png','jpg','jpeg','gif','webp','avif','ico','pdf','woff','woff2','ttf','otf','eot','mo','mp3','mp4','mov','wav','ogg','flac','sqlite','db','exe','so','bin'], true);
	}
	public static function binary(string $bytes, string $path = ''): bool {
		return self::binary_extension($path) || str_contains($bytes, "\0") || 1 !== preg_match('//u', $bytes);
	}
	public static function bytes(string $bytes, string $path = ''): array {
		return self::binary($bytes, $path) ? ['encoding' => 'base64', 'content_base64' => base64_encode($bytes)] : ['encoding' => 'utf-8', 'content' => $bytes];
	}
}

final class RegexGuard {
	public static function run(callable $callback) {
		$old = [ini_get('pcre.backtrack_limit'), ini_get('pcre.recursion_limit')];
		ini_set('pcre.backtrack_limit', '100000'); ini_set('pcre.recursion_limit', '1000');
		try { return $callback(); }
		finally { ini_set('pcre.backtrack_limit', (string)$old[0]); ini_set('pcre.recursion_limit', (string)$old[1]); }
	}
	public static function validate(string $pattern): ?\WP_Error {
		if ('' === $pattern || strlen($pattern) > 4096) return new \WP_Error('invalid_grep_regex', 'PCRE deve conter delimitadores e ter até 4096 bytes.');
		return self::run(static fn() => false === @preg_match($pattern, '') ? new \WP_Error('invalid_grep_regex', 'PCRE inválida: confira delimitadores, modificadores e sintaxe; exemplo /error|fatal/i.') : null);
	}
	public static function match(string $pattern, string $text) {
		if (strlen($text) > 1048576) return new \WP_Error('regex_line_limit', 'Linha excede 1 MiB para avaliação PCRE.');
		return self::run(static function () use ($pattern, $text) {
			$result = @preg_match($pattern, $text);
			return false === $result ? new \WP_Error('regex_execution_failed', 'PCRE excedeu o orçamento ou o texto é incompatível com o padrão.') : $result;
		});
	}
}
