<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Credentials {
    /** Inspect the derived Page credential itself; never infer its scopes from /me. */
    public static function pagePermissions(array $source,array $page,string $account): array {
        $proof=['page_id'=>$account,'source'=>'graph_debug_token','status'=>'unknown','permissions_verified'=>false,'scopes'=>[],
            'read_insights_granted'=>null,'pages_read_engagement_granted'=>null,'is_valid'=>null,'checked_at'=>gmdate('c')];
        $auth=$source;
        if($source['client_id']!==''&&$source['client_secret']!==''){
            if(!ctype_digit($source['client_id']))throw new Fault('invalid_input','Meta App ID deve ser numérico.');
            $auth['token']=$source['client_id'].'|'.$source['client_secret'];$auth['expires_at']=0;
        }
        try{
            $data=Http::request($auth,'debug_token',['input_token'=>$page['token']])['body']['data']??null;
            if(!is_array($data)||!is_bool($data['is_valid']??null))throw new Fault('upstream_invalid','Inspeção de credencial incompleta.');
            $proof['is_valid']=$data['is_valid'];
            if(!$data['is_valid']){$proof['status']='invalid_credential';return $proof;}
            if(isset($data['profile_id'])&&(string)$data['profile_id']!==$account)throw new Fault('credential_identity_mismatch','A inspeção retornou outra Página.');
            if($source['client_id']!==''&&(string)($data['app_id']??'')!==$source['client_id'])throw new Fault('credential_identity_mismatch','A inspeção retornou outro aplicativo.');
            if(isset($data['type'])&&$data['type']!=='PAGE')throw new Fault('credential_identity_mismatch','A inspeção não confirmou uma credencial de Página.');
            if(!is_array($data['scopes']??null)||count($data['scopes'])>200)throw new Fault('upstream_invalid','Escopos da Página ausentes ou inválidos.');
            foreach($data['scopes'] as $scope){if(!is_string($scope)||!preg_match('/^[a-z][a-z0-9_]{0,79}$/D',$scope))throw new Fault('upstream_invalid','Escopo da Página inválido.');}
            $scopes=array_values(array_unique($data['scopes']));sort($scopes);$proof['scopes']=$scopes;
            $granular=$data['granular_scopes']??[];
            if(!is_array($granular)||count($granular)>200)throw new Fault('upstream_invalid','Escopos granulares inválidos.');
            foreach(['read_insights','pages_read_engagement'] as $scope){
                $granted=in_array($scope,$scopes,true);$targeted=[];
                foreach($granular as $entry){
                    if(!is_array($entry)||!is_string($entry['scope']??null))throw new Fault('upstream_invalid','Escopo granular inválido.');
                    if($entry['scope']!==$scope||!array_key_exists('target_ids',$entry))continue;
                    if(!is_array($entry['target_ids']))throw new Fault('upstream_invalid','Ativos do escopo inválidos.');
                    $ids=[];foreach($entry['target_ids'] as $id){if(!is_string($id)&&!is_int($id))throw new Fault('upstream_invalid','Ativo do escopo inválido.');$ids[]=(string)$id;}
                    $targeted[]=in_array($account,$ids,true);
                }
                if($targeted)$granted=$granted&&in_array(true,$targeted,true);
                $proof[$scope.'_granted']=$granted;
            }
            $proof['status']='verified';$proof['permissions_verified']=true;return $proof;
        }catch(Fault $e){
            if(!in_array($e->reason,['upstream_validation','upstream_invalid','upstream_error','token_rejected','asset_access_denied','resource_not_found','credential_identity_mismatch'],true))throw $e;
            // Unknown is not denied. Do not project upstream text or credential values.
            $proof['read_insights_granted']=null;$proof['pages_read_engagement_granted']=null;
            $proof['diagnostic_error']=['code'=>$e->reason]+array_intersect_key($e->details,array_flip(['http_status','provider_code','provider_subcode','provider_is_transient']));
            return $proof;
        }
    }
    public const READ_SCOPES=['pages_show_list','pages_read_engagement','read_insights','instagram_basic','instagram_manage_insights','ads_read'];
    public static function format(array $c,bool $requireApp=true): void {
        $token=$c['token'];
        if(preg_match('/^[a-fA-F0-9]{32}$/D',$token)||($c['client_secret']!==''&&hash_equals($c['client_secret'],$token)))throw new Fault('invalid_token_format',"Isto parece a Chave Secreta do Aplicativo, não um token. Copie o token na janela 'Token criado' do usuário do sistema.");
        if(strlen($token)<100||strlen($token)>16384||!str_starts_with($token,'EAA')||preg_match('/[\x00-\x20]/',$token))throw new Fault('invalid_token_format','O token deve começar com EAA e ter pelo menos 100 caracteres. Copie o valor completo da janela Token criado.');
        if($requireApp&&($c['client_id']===''||$c['client_secret']===''))throw new Fault('app_proof_required',"Informe o ID do Aplicativo e a Chave Secreta do Aplicativo. Onde achar: Meta for Developers → Meus apps → <app> → Configurações do app → Básico → 'ID do Aplicativo' e 'Chave Secreta do Aplicativo' → 'Mostrar'.");
        self::appFormat($c);
    }
    public static function appFormat(array $c): void {
        if($c['client_id']!==''&&!preg_match('/^[0-9]{15,17}$/D',$c['client_id']))throw new Fault('invalid_app_id','O ID do Aplicativo deve conter de 15 a 17 dígitos.');
        if($c['client_secret']!==''&&!preg_match('/^[a-fA-F0-9]{32}$/D',$c['client_secret']))throw new Fault('invalid_app_secret','A Chave Secreta do Aplicativo deve conter exatamente 32 caracteres hexadecimais (a–f e números).');
    }
    public static function identity(array $c): array {
        // An expired or paused saved connection can be inspected without changing its state.
        $c['enabled']=true;$c['expires_at']=0;
        $proof=['application_id'=>$c['application_id'],'proof'=>'app_scoped_subject_read','app_verified'=>false,'checked_at'=>time()];
        $debug=null;
        if($c['client_id']!==''&&$c['client_secret']!==''){
            $auth=$c;$auth['token']=$c['client_id'].'|'.$c['client_secret'];
            $debug=Http::inspect($auth,'debug_token',['input_token'=>$c['token']])['body']['data']??null;
            if(!is_array($debug)||!is_bool($debug['is_valid']??null))throw new Fault('upstream_invalid','A Meta não retornou uma inspeção válida do token.');
            if(!$debug['is_valid'])throw new Fault('token_rejected','A Meta recusou este token.',Http::diagnostic(['error'=>$debug['error']??[]],200));
            if((string)($debug['app_id']??'')!==$c['client_id'])throw new Fault('credential_app_mismatch','O token pertence a outro aplicativo. Confira o ID do Aplicativo e gere o token no mesmo app.');
            if(!is_int($debug['expires_at']??null)||$debug['expires_at']<0)throw new Fault('upstream_invalid','A Meta não confirmou a validade do token.');
            if($debug['expires_at']>0&&$debug['expires_at']<=time())throw new Fault('token_expired','A Meta informou que este token expirou.');
            if(!is_array($debug['scopes']??null)||count($debug['scopes'])>200)throw new Fault('upstream_invalid','A Meta não confirmou as permissões do token.');
            foreach($debug['scopes'] as $scope)if(!is_string($scope)||!preg_match('/^[a-z][a-z0-9_]{0,79}$/D',$scope))throw new Fault('upstream_invalid','A Meta retornou uma permissão inválida.');
            $scopes=array_values(array_unique($debug['scopes']));sort($scopes);
            $principal=(string)($debug['user_id']??'');Util::numeric($principal);
            $proof+=['principal_id'=>$principal,'scopes'=>$scopes,'remote_expires_at'=>$debug['expires_at'],'application_name'=>self::name($debug['application']??null),'extra_scopes'=>array_values(array_diff($scopes,self::READ_SCOPES))];
            $proof['application_id']=(string)$debug['app_id'];$proof['app_verified']=true;$proof['proof']='graph_debug_token_and_subject';
        }
        $r=Http::inspect($c,'me',['fields'=>'id,name'])['body'];$subject=(string)($r['id']??'');Util::numeric($subject);
        if($debug!==null&&$subject!==$proof['principal_id'])throw new Fault('credential_identity_mismatch','A Meta retornou identidades divergentes na conferência do token.');
        return $proof+['subject_id'=>$subject,'subject_name'=>self::name($r['name']??null)];
    }
    private static function name($v): ?string {return is_string($v)&&$v!==''?mb_substr(sanitize_text_field($v),0,180):null;}
    public static function sameIdentity(array $a,array $b): bool {
        return !empty($a['app_verified'])&&!empty($b['app_verified'])&&($a['subject_id']??'')===$b['subject_id']&&($a['principal_id']??'')===$b['principal_id']&&$a['application_id']===$b['application_id'];
    }
    public static function candidate(array $c): array {
        self::format($c);$c['enabled']=true;$c['expires_at']=0;
        try{
            $proof=self::identity($c);
            $count=array_sum(array_map('count',$c['assets']));if($count>12)throw new Fault('validation_limit','A conferência é limitada a 12 ativos por conexão. Divida a seleção em conexões menores.');
            foreach($c['assets'] as $channel=>$ids)foreach($ids as $id){
                $auth=$c;
                if($channel==='ads'){if(!in_array('ads_read',$proof['scopes']??[],true))throw new Fault('ads_read_required','O token precisa da permissão ads_read para a conta de anúncios selecionada.');Ads::account($c,$id,true);continue;}
                if($channel==='facebook'){
                    $page=Http::inspect($c,$id,['fields'=>'id,access_token'])['body'];
                    if((string)($page['id']??'')!==$id||!is_string($page['access_token']??null)||$page['access_token']===''||strlen($page['access_token'])>16384||preg_match('/[\x00-\x20]/',$page['access_token']))throw new Fault('asset_access_denied','O token não permite obter acesso à Página selecionada.');
                    $auth['token']=$page['access_token'];
                }
                $r=Http::inspect($auth,$id,['fields'=>$channel==='facebook'?'id,name':'id,username'])['body'];
                if((string)($r['id']??'')!==$id)throw new Fault('asset_access_denied','O token não confirmou acesso a todos os ativos selecionados.');
            }
            return $proof;
        }catch(Fault $e){
            $message=match($e->reason){
                'token_rejected'=>'A Meta recusou este token'.(isset($e->details['provider_code'])?' (código '.$e->details['provider_code'].')':'').'.',
                'asset_access_denied','resource_not_found'=>'O token não permite acessar a Página, o Instagram ou a conta de anúncios selecionada.',
                default=>$e->getMessage()
            };
            throw new Fault($e->reason,$message.' O token salvo continua em uso.',$e->details);
        }
    }
    public static function mismatch(array $proof): Fault {
        $name=$proof['subject_name']??('ID '.$proof['subject_id']);
        return new Fault('credential_identity_mismatch',"O token novo é de outra identidade (".$name."). Para trocar, use 'Trocar identidade e regravar agendas': o token é conferido, a seleção de ativos é mantida e as agendas são regravadas na nova revisão.");
    }
    public static function rotate(array $i): array {
        Schemas::validate('rotate-token',$i);if($i['token']==='')throw new Fault('invalid_token_format','Informe o novo token de acesso.');
        Connections::get($i['connection_id']);
        return ConnectionChanges::save($i)+['schedules_preserved'=>true,'application_independently_verified'=>true];
    }
}
