<?php
/**
 * Módulo consentimento.
 *
 * Padrão pré-aprovado: as tags carregam por padrão, o controle de revisão fica no
 * rodapé de TODA página, a negativa desliga e persiste pelo TTL da configuração e
 * o re-aceite religa. Consent Mode com `granted` na carga e `update` para `denied`
 * na negativa.
 *
 * A ESTRATÉGIA DE CARGA DO SCRIPT É DECIDIDA PELA POLÍTICA, e o motivo mora em
 * `estrategia_de_carga()`, que é onde a decisão acontece: pré-aprovado sai
 * `defer`, fora do caminho crítico; negado por padrão sai BLOQUEANTE no
 * `<head>`, porque ali a ordem é a garantia inteira. Não há chave de
 * configuração para isso — a condição decide, como no resto do pacote.
 *
 * O QUE A NEGATIVA TARDIA NÃO DESFAZ, e a assimetria é do fornecedor. O que o
 * Consent Mode do Google recebe é um `update`: a negativa vale do clique em
 * diante, e o que já foi enviado permanece com o fornecedor. Pixel da Meta e
 * Insight Tag do LinkedIn não têm equivalente de `update`: se já carregaram,
 * negar depois NÃO os descarrega — o script deles continua na página até a
 * navegação seguinte. O que o pacote garante a partir da negativa é que nenhum
 * envio novo sai para eles (o portão está em `f3base-leads.js`, no mesmo
 * `permiteTags()`) e que na página seguinte eles não voltam a ser carregados.
 *
 * A chave `aviso_primeira_visita` existe, tem consumidor (o aviso não bloqueante
 * do JavaScript) e nasce DESLIGADA — ligá-la é decisão declarada por projeto.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Política de consentimento e seu controle permanente.
 */
final class F3Base_Modulo_Consentimento extends F3Base_Modulo {

	/**
	 * Handle do script.
	 */
	public const HANDLE = 'f3base-consentimento';

	/**
	 * Cookie que persiste a decisão do titular.
	 */
	public const COOKIE = 'f3base_consentimento';

	/**
	 * Suporte que o tema declara quando ele próprio fornece o controle no rodapé.
	 */
	public const SUPORTE_TEMA = 'f3base-consentimento-rodape';

	/**
	 * `id` do banner, e o alvo do `aria-controls` do controle do rodapé.
	 *
	 * FONTE ÚNICA: o markup do tema, o markup de reserva deste módulo e o
	 * elemento que o JavaScript cria leem daqui. Um `aria-controls` apontando
	 * para um `id` que ninguém cria é referência pendurada — o leitor de tela
	 * anuncia um controle de alguma coisa que não existe —, e foi por isso que
	 * o banner passou a ser construído no `iniciar()`, e não no primeiro clique.
	 */
	public const ID_BANNER = 'f3base-consentimento-banner';

	/**
	 * O VOCABULÁRIO FECHADO do estado de consentimento — três valores, e só.
	 *
	 * O defeito que ele fecha estava no registro do lead: `consentimento: true`
	 * virava `_f3base_consentimento = sim` em TODO lead, porque o campo booleano
	 * que o navegador manda é o PORTÃO das tags, e sob a política pré-aprovada
	 * ele vale `true` sem que ninguém tenha decidido nada. O arquivo do lead
	 * passava a afirmar uma decisão do titular que não existiu — que é o oposto
	 * do que um registro de consentimento serve para provar.
	 *
	 * São três valores porque são três situações materialmente diferentes, e
	 * duas delas permitem tags: decisão explícita de permitir, decisão explícita
	 * de recusar, e ausência de decisão sob política pré-aprovada. A ausência de
	 * decisão sob política de NEGATIVA por padrão não é um quarto valor — ali
	 * não há consentimento nenhum, e o nome disso é `nao`.
	 */
	public const ESTADO_SIM    = 'sim';
	public const ESTADO_NAO    = 'nao';
	public const ESTADO_PADRAO = 'padrao-pre-aprovado';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'consentimento';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Consentimento', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Aplica a política declarada — pré-aprovado por padrão —, publica o controle de revisão no rodapé de toda página, persiste a negativa pelo TTL configurado e religa no re-aceite. Emite Consent Mode com granted na carga e update para denied na negativa.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 1,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_footer',
				'metodo'     => 'render_controle',
				'prioridade' => 20,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_consentimento' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$tema = current_theme_supports( self::SUPORTE_TEMA );

		return array(
			array(
				'rotulo'   => __( 'Controle no rodapé', 'f3base' ),
				'presente' => true,
				'detalhe'  => $tema
					? __( 'fornecido pela part do tema, que declara suporte; o comportamento continua sendo do site-core.', 'f3base' )
					: __( 'fornecido pelo próprio site-core em wp_footer, porque o tema não declara suporte.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'JavaScript no navegador', 'f3base' ),
				'presente' => true,
				'detalhe'  => __( 'sem JavaScript o controle não opera: perda declarada no relatório, como no fluxo de WhatsApp.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( F3Base_Options::ORIGEM_PADRAO === F3Base_Options::proveniencia( 'f3base_consentimento' ) ) {
			return $this->degradado(
				__( 'f3base_consentimento nunca foi gravada pelo implantador: o site opera sobre o padrão embutido do plugin, não sobre a política declarada do projeto.', 'f3base' )
			);
		}

		if ( empty( $config['controle_rodape'] ) ) {
			return $this->degradado(
				__( 'controle no rodapé desligado na configuração: o titular fica sem instrumento permanente de revisão.', 'f3base' )
			);
		}

		if ( 'pre-aprovado' === ( $config['padrao'] ?? 'pre-aprovado' ) ) {
			return $this->ativo(
				sprintf(
					/* translators: %d: prazo em dias. */
					__( 'política pré-aprovada com controle no rodapé; a negativa persiste por %d dias e o re-aceite religa. O script sai com defer, fora do caminho crítico: o default granted deste modo não muda o que seria enviado sem Consent Mode nenhum.', 'f3base' ),
					(int) ( $config['ttl_dias'] ?? 180 )
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: prazo em dias. */
				__( 'política de negativa por padrão: as tags só carregam após o aceite, que persiste por %d dias. O script sai BLOQUEANTE no cabeçalho: aqui a ordem é a garantia, e chegar depois de uma tag de terceiro seria um primeiro page_view sem o denied.', 'f3base' ),
				(int) ( $config['ttl_dias'] ?? 180 )
			)
		);
	}

	/**
	 * A ESTRATÉGIA DE CARGA É DECIDIDA PELA POLÍTICA, e não por um interruptor.
	 *
	 * Aqui é onde a decisão acontece, então é aqui que o motivo dela mora.
	 *
	 * **Pré-aprovado devolve `defer`.** O `default` deste modo é `granted`, que é
	 * materialmente o que o gtag faz sem Consent Mode nenhum: chegar tarde com
	 * `granted` não muda o que foi enviado. E a ordem que importa continua de pé
	 * sem custo — `defer` executa depois do parse e NA ORDEM DO DOCUMENTO, e o
	 * carregador de tags é `defer` no rodapé, atrás deste no documento e
	 * declarado como dependente deste handle. O consentimento continua rodando
	 * antes do carregador, e o script sai do caminho crítico do parser.
	 *
	 * **Negado por padrão devolve bloqueante.** Ali o `default` é `denied`, e a
	 * ordem deixa de ser conveniência para virar a garantia inteira: o que
	 * dispara antes de o `denied` chegar é um primeiro `page_view` com
	 * consentimento pleno de quem ainda não consentiu. E a ordem do `defer` só
	 * ordena scripts `defer` ENTRE SI — um `gtag.js` `async` de outro plugin, ou
	 * um snippet colado no cabeçalho, executa antes de qualquer `defer` da
	 * página. Bloquear o parser é o preço de não disparar antes de saber, e
	 * neste modo ele é o preço certo.
	 *
	 * A permissividade autorizada para o modo pré-aprovado NÃO se aplica aqui:
	 * ela foi autorizada descrevendo o cenário de pré-aprovação, em que a
	 * medição já começa na chegada por decisão declarada do projeto.
	 *
	 * @param string|null $padrao Política; nulo lê a option.
	 * @return string `defer`, ou string vazia para script bloqueante.
	 */
	public static function estrategia_de_carga( ?string $padrao = null ): string {
		if ( null === $padrao ) {
			$config = F3Base_Options::ler( 'f3base_consentimento' );
			$padrao = is_array( $config ) && isset( $config['padrao'] ) ? (string) $config['padrao'] : 'pre-aprovado';
		}

		return 'pre-aprovado' === $padrao ? 'defer' : '';
	}

	/**
	 * Enfileira o script de consentimento no cabeçalho.
	 *
	 * O script mora no `<head>` nos DOIS modos — é de lá que a ordem do
	 * documento o põe antes do carregador de tags, que vive no rodapé. O que a
	 * política decide é se ele BLOQUEIA o parser; o motivo de cada lado está em
	 * `estrategia_de_carga()`, que é onde a decisão acontece.
	 *
	 * @return void
	 */
	public static function url_politica_opcional(): string {
		$id = (int) get_option( 'wp_page_for_privacy_policy', 0 );
		$post = $id > 0 ? get_post( $id ) : null;
		if ( ! $post || 'publish' !== $post->post_status || ! empty( $post->post_password ) || ! is_post_publicly_viewable( $post ) ) { return ''; }
		return esc_url_raw( (string) get_privacy_policy_url(), array( 'http', 'https' ) );
	}

	public function enfileirar(): void {
		$config = $this->config();
		$padrao = (string) ( $config['padrao'] ?? 'pre-aprovado' );

		$argumentos = array(
			'in_footer' => false,
		);

		$estrategia = self::estrategia_de_carga( $padrao );

		if ( '' !== $estrategia ) {
			$argumentos['strategy'] = $estrategia;
		}

		wp_enqueue_script(
			self::HANDLE,
			F3BASE_PLUGIN_URL . 'assets/f3base-consentimento' . ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min' ) . '.js',
			array(),
			F3BASE_PLUGIN_VERSAO,
			$argumentos
		);

		wp_localize_script(
			self::HANDLE,
			'f3baseConsentimentoDados',
			array(
				'padrao'              => $padrao,
				'ttlDias'             => (int) ( $config['ttl_dias'] ?? 180 ),
				'controleRodape'      => ! empty( $config['controle_rodape'] ),
				'avisoPrimeiraVisita' => ! empty( $config['aviso_primeira_visita'] ),
				'cookie'              => self::COOKIE,
				'seletorControle'     => '[data-f3base-consentimento]',
				'idBanner'            => self::ID_BANNER,
				'categorias'          => array( 'analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization' ),
				'textos'              => array(
					'titulo'       => __( 'Política de Cookie', 'f3base' ),
					'explicacao'   => 'pre-aprovado' === $padrao
						? __( 'Este site carrega ferramentas de medição por padrão. Você pode desligá-las agora; a escolha fica guardada neste navegador.', 'f3base' )
						: __( 'Este site só carrega ferramentas de medição depois do seu aceite. Você pode mudar essa escolha quando quiser.', 'f3base' ),
					'aceitar'      => __( 'Permitir medição', 'f3base' ),
					'recusar'      => __( 'Desligar medição', 'f3base' ),
					'fechar'       => __( 'Fechar', 'f3base' ),
					'estadoAtivo'  => __( 'Medição ligada neste navegador.', 'f3base' ),
					'estadoNegado' => __( 'Medição desligada neste navegador.', 'f3base' ),
					'aviso'        => __( 'Este site usa medição por padrão. Ajuste no controle de privacidade do rodapé.', 'f3base' ),
					'avisoOk'      => __( 'Entendi', 'f3base' ),
					'politica'     => __( 'Política de Privacidade', 'f3base' ),
				),
				'politicaUrl'         => self::url_politica_opcional(),
			)
		);
	}

	/**
	 * Publica o controle de revisão no rodapé.
	 *
	 * Se o tema declara `f3base-consentimento-rodape`, ele já fornece o botão na
	 * part e nada é impresso aqui — o comportamento continua sendo deste módulo.
	 *
	 * @return void
	 */
	public function render_controle(): void {
		$config = $this->config();

		if ( empty( $config['controle_rodape'] ) ) {
			return;
		}

		if ( current_theme_supports( self::SUPORTE_TEMA ) ) {
			return;
		}

		printf(
			'<p class="f3base-consentimento-rodape"><button type="button" class="f3base-consentimento-abrir" data-f3base-consentimento="abrir" aria-haspopup="dialog" aria-expanded="false" aria-controls="%1$s">%2$s</button></p>',
			esc_attr( self::ID_BANNER ),
			esc_html__( 'Política de Cookie', 'f3base' )
		);
	}

	/**
	 * Decisão registrada no navegador do visitante, lida no servidor.
	 *
	 * @return string `granted`, `denied` ou `sem-decisao`.
	 */
	public static function decisao_do_visitante(): string {
		if ( ! isset( $_COOKIE[ self::COOKIE ] ) ) {
			return 'sem-decisao';
		}

		$valor = sanitize_key( wp_unslash( (string) $_COOKIE[ self::COOKIE ] ) );

		return in_array( $valor, array( 'granted', 'denied' ), true ) ? $valor : 'sem-decisao';
	}

	/**
	 * Há consentimento efetivo para carregar tags de terceiro?
	 *
	 * @return bool
	 */
	public static function permite_tags(): bool {
		$config = F3Base_Options::ler( 'f3base_consentimento' );
		$padrao = is_array( $config ) && isset( $config['padrao'] ) ? (string) $config['padrao'] : 'pre-aprovado';

		$decisao = self::decisao_do_visitante();

		if ( 'denied' === $decisao ) {
			return false;
		}

		if ( 'granted' === $decisao ) {
			return true;
		}

		return 'pre-aprovado' === $padrao;
	}

	/**
	 * Os três valores do vocabulário, para quem precisa validar contra a lista.
	 *
	 * @return array<int,string>
	 */
	public static function vocabulario_do_estado(): array {
		return array( self::ESTADO_SIM, self::ESTADO_NAO, self::ESTADO_PADRAO );
	}

	/**
	 * O ESTADO REAL do consentimento desta requisição, no vocabulário fechado.
	 *
	 * A decisão do titular vem do cookie, que é onde ela mora; a política vem da
	 * option. O parâmetro é o que o CLIENTE declarou — o portão de `permiteTags()`
	 * — e ele entra pela metade RESTRITIVA: um cliente que diz "não" é ouvido
	 * (o beacon pode ter viajado sem cookie, ou a recusa pode ser mais nova que
	 * a página), e um cliente que diz "sim" NUNCA promove a ausência de decisão
	 * a consentimento. Foi essa promoção que arquivou todo lead como consentido.
	 *
	 * @param bool|null $declarado O que o cliente declarou; nulo quando o campo não veio.
	 * @return string Um dos três valores do vocabulário.
	 */
	public static function estado_medido( ?bool $declarado = null ): string {
		if ( false === $declarado ) {
			return self::ESTADO_NAO;
		}

		$decisao = self::decisao_do_visitante();

		if ( 'granted' === $decisao ) {
			return self::ESTADO_SIM;
		}

		if ( 'denied' === $decisao ) {
			return self::ESTADO_NAO;
		}

		$config = F3Base_Options::ler( 'f3base_consentimento' );
		$padrao = is_array( $config ) && isset( $config['padrao'] ) ? (string) $config['padrao'] : 'pre-aprovado';

		return 'pre-aprovado' === $padrao ? self::ESTADO_PADRAO : self::ESTADO_NAO;
	}

	/**
	 * Este estado permite mandar evento a terceiro?
	 *
	 * É o MESMO portão de `permite_tags()`, respondido a partir do estado já
	 * medido: quem já mediu não mede de novo, e duas leituras da mesma coisa
	 * dentro da mesma requisição são duas chances de divergir.
	 *
	 * @param string $estado Estado do vocabulário fechado.
	 * @return bool
	 */
	public static function estado_permite_tags( string $estado ): bool {
		return self::ESTADO_NAO !== $estado && in_array( $estado, self::vocabulario_do_estado(), true );
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$config = F3Base_Options::ler( 'f3base_consentimento' );

		return is_array( $config ) ? $config : array();
	}
}
