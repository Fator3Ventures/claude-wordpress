<?php
/** Integração com cache de página: invalidação e evidência HTTP, sem editar o provedor. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class F3Base_Cache_Pagina {
	public const ESTADO = 'f3base_cache_estado';
	public const PROVA = 'f3base_cache_prova';
	public const CRON = 'f3base_cache_verificar';
	public const VALIDADE = 3600;
	private static bool $marcado = false;

	public static function perfil(): array {
		global $cache_enabled, $wp_cache_mod_rewrite, $wpsc_save_headers, $super_cache_enabled;
		$wp = defined( 'WP_CACHE' ) && WP_CACHE;
		$wpsc = function_exists( 'wp_cache_clear_cache' );
		$ativo = $wp && ( $wpsc ? ! empty( $cache_enabled ) : true );
		$modo = ! $ativo ? 'desligado' : ( ! $wpsc ? 'desconhecido' : ( ! empty( $wpsc_save_headers ) || empty( $super_cache_enabled ) ? 'wp-cache-cabecalhos' : ( ! empty( $wp_cache_mod_rewrite ) ? 'expert' : 'simple' ) ) );
		return array( 'ativo' => $ativo, 'provedor' => $wpsc ? 'wp-super-cache' : ( $wp ? 'nao-identificado' : 'nenhum' ), 'modo' => $modo, 'limpeza_disponivel' => $wpsc );
	}

	/** As opções de operação, retenção e segredos não alteram HTML público. */
	public static function afeta( string $nome ): bool {
		return in_array( $nome, array( 'f3base_contato', 'f3base_ga4_measurement_id', 'f3base_gtm_container_id', 'f3base_google_ads', 'f3base_meta_pixel_id', 'f3base_linkedin_partner_id', 'f3base_linkedin_conversion_id', 'f3base_atribuicao', 'f3base_verificacao_google', 'f3base_verificacao_meta', 'f3base_consentimento', 'f3base_comportamento', 'f3base_robots', 'f3base_llms', 'f3base_redirects', 'f3base_seo_entidade', 'f3base_cabecalhos', 'f3base_nav_id' ), true );
	}
	public static function sanitizar( $valor, $padrao ): array {
		$v = is_array( $valor ) ? $valor : array();
		foreach ( array( 'versao', 'geracao', 'solicitado_em', 'limpo_em', 'codigo' ) as $campo ) { if ( ! is_scalar( $v[ $campo ] ?? null ) ) { $v[ $campo ] = ''; } }
		return array_replace( $v, array( 'versao' => substr( (string) $v['versao'], 0, 32 ), 'geracao' => substr( (string) $v['geracao'], 0, 64 ), 'pendente' => ! empty( $v['pendente'] ), 'solicitado_em' => max( 0, (int) $v['solicitado_em'] ), 'limpo_em' => max( 0, (int) $v['limpo_em'] ), 'codigo' => sanitize_key( (string) $v['codigo'] ) ) );
	}
	public static function estado(): array { return (array) F3Base_Options::ler( self::ESTADO ); }

	/** Agrupa alterações do mesmo pedido; outro processo recebe geração própria. */
	public static function solicitar(): bool {
		delete_transient( self::PROVA );
		if ( self::$marcado ) { return true; }
		$e = self::estado();
		$e['geracao'] = wp_generate_uuid4(); $e['pendente'] = true; $e['solicitado_em'] = time(); $e['codigo'] = 'limpeza_agendada';
		$r = F3Base_Options::gravar( self::ESTADO, $e, F3Base_Options::ORIGEM_PADRAO );
		self::$marcado = ! empty( $r['persisted'] );
		return self::$marcado;
	}

	/** Só é chamado depois da leitura de volta confirmada da opção. */
	public static function apos_escrita( string $nome ): ?array {
		if ( ! self::afeta( $nome ) || ! self::perfil()['ativo'] ) { return null; }
		$ok = self::solicitar();
		return array( 'status' => $ok ? 'not_attempted' : 'failed', 'applied' => false, 'codigo' => $ok ? 'cache_agendado' : 'cache_agendamento_falhou', 'motivo' => $ok ? 'Configuração salva. Limpeza do cache agendada para o fim desta operação; entrega pública pendente.' : 'Configuração salva; não foi possível registrar a limpeza do cache.' );
	}

	/** O provedor não devolve confirmação HTTP. A prova pública continua separada. */
	public static function limpar(): array {
		$foto = F3Base_Options::fotografia( self::ESTADO );
		if ( ! empty( $foto['erro'] ) ) { return array( 'ok' => false, 'codigo' => 'estado_indisponivel' ); }
		$e = $foto['valor']; $p = self::perfil();
		if ( ! empty( $e['pendente'] ) && $p['ativo'] && ! $p['limpeza_disponivel'] ) { return array( 'ok' => false, 'codigo' => 'provedor_sem_operacao' ); }
		try {
			if ( $p['limpeza_disponivel'] ) {
				// Limpa também o cache desligado que será reutilizado se o operador o reativar.
				$r = wp_cache_clear_cache();
				if ( false === $r ) { return array( 'ok' => false, 'codigo' => 'provedor_recusou' ); }
			}
		} catch ( Throwable $erro ) { return array( 'ok' => false, 'codigo' => 'limpeza_falhou' ); }
		$e['pendente'] = false; $e['limpo_em'] = time(); $e['versao'] = F3BASE_PLUGIN_VERSAO; $e['codigo'] = 'limpeza_solicitada_ao_provedor';
		$r = F3Base_Options::gravar( self::ESTADO, $e, F3Base_Options::ORIGEM_PADRAO, $foto['revisao'] );
		delete_transient( self::PROVA );
		// Uma verificação explícita posterior não deve ser apagada novamente no shutdown.
		if ( ! empty( $r['persisted'] ) ) { self::$marcado = false; }
		return array( 'ok' => ! empty( $r['persisted'] ), 'codigo' => ! empty( $r['persisted'] ) ? $e['codigo'] : 'alteracao_concorrente', 'verificacao_pendente' => true );
	}
	public static function concluir(): void {
		if ( self::$marcado ) { self::limpar(); }
	}
	public static function preparar(): void {
		$e = self::estado();
		if ( ( $e['versao'] ?? '' ) !== F3BASE_PLUGIN_VERSAO ) { self::solicitar(); }
		if ( ! wp_next_scheduled( self::CRON ) ) { wp_schedule_event( time() + 120, 'hourly', self::CRON ); }
	}
	public static function tarefa(): void {
		if ( ! empty( self::estado()['pendente'] ) ) { self::limpar(); }
		self::verificar_publico();
	}

	/** Requisitos derivados da URL real; o implantador mescla estes caminhos na API do cache. */
	public static function exclusoes(): array {
		$r = wp_parse_url( rest_url( F3BASE_REST_NAMESPACE . '/' ) );
		$codificada = rawurlencode( '/' . F3BASE_REST_NAMESPACE );
		$lista = array( 'rest_route=/' . F3BASE_REST_NAMESPACE, 'rest_route=' . $codificada, 'rest_route=' . str_replace( '%2F', '%2f', $codificada ), 'f3base_markdown=', '/llms.txt', '/llms-full.txt', '\\.md(?:$|[?])' );
		// Com permalinks simples, o caminho REST é a própria home: excluí-lo desliga todo o cache.
		if ( ! str_contains( (string) ( $r['query'] ?? '' ), 'rest_route=' ) ) { array_unshift( $lista, (string) ( $r['path'] ?? '' ) ); }
		return array_values( array_unique( array_filter( $lista ) ) );
	}
	public static function proteger_rota( $resultado, $servidor, $pedido ) {
		if ( is_object( $pedido ) && method_exists( $pedido, 'get_route' ) && str_starts_with( $pedido->get_route(), '/' . F3BASE_REST_NAMESPACE . '/' ) ) {
			if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
		}
		return $resultado;
	}
	public static function proteger_resposta( $resultado, $servidor, $pedido ) {
		if ( is_object( $pedido ) && method_exists( $pedido, 'get_route' ) && str_starts_with( $pedido->get_route(), '/' . F3BASE_REST_NAMESPACE . '/' ) && $resultado instanceof WP_HTTP_Response ) {
			$resultado->header( 'Cache-Control', 'no-store, private' );
			$resultado->header( 'Pragma', 'no-cache' );
		}
		return $resultado;
	}
	public static function contexto(): string {
		return hash( 'sha256', wp_json_encode( array( self::perfil(), F3BASE_PLUGIN_VERSAO, home_url( '/' ), F3Base_Options::ler( 'f3base_cabecalhos' ), self::estado()['geracao'] ?? '' ) ) );
	}
	public static function prova(): array {
		$p = get_transient( self::PROVA );
		return is_array( $p ) && hash_equals( self::contexto(), (string) ( $p['contexto'] ?? '' ) ) && (int) ( $p['checked_at'] ?? 0 ) + self::VALIDADE > time() ? $p : array();
	}
	public static function verificacao(): array {
		$p = self::prova();
		if ( empty( $p ) ) { return F3Base_Options::resultado_verificacao( 'pending', 'public_http', 'hit_nao_comprovado', 'Cabeçalhos no acesso público ainda não comprovados; verifique uma resposta entregue pelo cache.' ); }
		return F3Base_Options::resultado_verificacao( $p['status'], 'public_http', $p['codigo'], $p['motivo'], $p['checked_at'] );
	}

	/** Prova de HIT por cabeçalho do servidor ou arquivo WPSC correspondente e geração estável. */
	public static function hit_comprovado( array $r, string $corpo ): bool {
		foreach ( array( 'wp-super-cache', 'x-wp-super-cache', 'x-cache', 'cf-cache-status' ) as $h ) {
			$v = (string) wp_remote_retrieve_header( $r, $h );
			if ( preg_match( '/\bHIT\b|served (?:supercache|wpcache)/i', $v ) ) { return true; }
		}
		// Expert não precisa acrescentar um cabeçalho: confirmar o arquivo da home no provedor.
		if ( self::perfil()['provedor'] !== 'wp-super-cache' || ! function_exists( 'get_supercache_dir' ) || ! str_contains( $corpo, 'Cached page generated by WP-Super-Cache' ) ) { return false; }
		$base = get_supercache_dir();
		foreach ( array( 'index.html', 'index-https.html' ) as $nome ) {
			$f = $base . $nome;
			if ( is_file( $f ) && is_readable( $f ) && filesize( $f ) <= 524288 && hash_equals( hash( 'sha256', $corpo ), (string) hash_file( 'sha256', $f ) ) ) { return true; }
		}
		// WP-Cache pode preservar cabeçalhos sem habilitar o cabeçalho opcional de HIT.
		// Ler somente os arquivos limitados da home; nunca executar PHP do cache.
		if ( is_dir( $base ) && is_readable( $base ) && function_exists( 'wp_cache_get_legacy_cache' ) ) {
			$vistos = 0;
			foreach ( new DirectoryIterator( $base ) as $arquivo ) {
				if ( ++$vistos > 128 ) { break; }
				if ( ! $arquivo->isFile() || ! preg_match( '/^wp-cache-[a-f0-9]+\.php$/', $arquivo->getFilename() ) || $arquivo->getSize() > 524303 ) { continue; }
				$conteudo = wp_cache_get_legacy_cache( $arquivo->getPathname() );
				if ( ! is_string( $conteudo ) ) { continue; }
				if ( hash_equals( hash( 'sha256', $corpo ), hash( 'sha256', $conteudo ) ) ) { return true; }
			}
		}
		return false;
	}

	/** Duas leituras anonymes, de tamanho e tempo limitados; nunca no caminho de cada visitante. */
	public static function verificar_publico(): array {
		$anterior = self::prova();
		if ( $anterior && (int) $anterior['checked_at'] + 60 > time() ) { return $anterior; }
		$contexto = self::contexto(); $perfil = self::perfil();
		$prova = array( 'contexto' => $contexto, 'checked_at' => time(), 'status' => 'pending', 'codigo' => 'http_indisponivel', 'motivo' => 'Verificação pública indisponível.', 'url' => home_url( '/' ), 'modo' => $perfil['modo'], 'hit' => false, 'cabecalhos' => array(), 'faltantes' => array() );
		$args = array( 'timeout' => 5, 'redirection' => 0, 'limit_response_size' => 524288, 'cookies' => array(), 'headers' => array( 'Accept' => 'text/html' ) );
		$r = wp_remote_get( $prova['url'], $args );
		if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
			$r2 = wp_remote_get( $prova['url'], $args );
			if ( ! is_wp_error( $r2 ) && 200 === wp_remote_retrieve_response_code( $r2 ) ) {
				$corpo = wp_remote_retrieve_body( $r2 );
				$a = array(); $b = array();
				preg_match( '/F3BASE-CACHE-PROBE:([a-f0-9-]{36})/', wp_remote_retrieve_body( $r ), $a );
				preg_match( '/F3BASE-CACHE-PROBE:([a-f0-9-]{36})/', $corpo, $b );
				$prova['hit'] = ! empty( $a[1] ) && ! empty( $b[1] ) && hash_equals( $a[1], $b[1] ) && self::hit_comprovado( $r2, $corpo );
				$modulo = new F3Base_Modulo_Cabecalhos();
				$esperados = $modulo->lista_de_cabecalhos();
				$c = F3Base_Options::ler( 'f3base_cabecalhos' );
				if ( ! empty( $c['hsts'] ) && 'https' === wp_parse_url( $prova['url'], PHP_URL_SCHEME ) ) { $esperados['Strict-Transport-Security'] = 'max-age=' . (int) $c['hsts_max_age']; }
				foreach ( $esperados as $nome => $esperado ) {
					$valor = wp_remote_retrieve_header( $r2, $nome );
					$valor = is_array( $valor ) ? implode( ', ', $valor ) : (string) $valor;
					$prova['cabecalhos'][ $nome ] = substr( $valor, 0, 2048 );
					$confere = strcasecmp( trim( $valor ), trim( $esperado ) ) === 0;
					if ( in_array( $nome, array( 'Content-Security-Policy', 'Strict-Transport-Security' ), true ) ) { $confere = preg_match( '/(?:^|[,;]\s*)' . preg_quote( $esperado, '/' ) . '(?:\s*;|\s*,|$)/i', $valor ) === 1; }
					if ( ! $confere ) { $prova['faltantes'][] = $nome; }
				}
				$prova['status'] = $prova['faltantes'] ? 'failed' : ( ! $perfil['ativo'] || $prova['hit'] ? 'verified' : 'pending' );
				$prova['codigo'] = $prova['faltantes'] ? 'cabecalhos_divergentes' : ( 'verified' === $prova['status'] ? 'cabecalhos_comprovados' : 'hit_nao_comprovado' );
				$prova['motivo'] = $prova['faltantes'] ? 'Proteções ausentes ou divergentes na resposta pública: ' . implode( ', ', $prova['faltantes'] ) . '.' : ( 'verified' === $prova['status'] ? 'Cabeçalhos conferidos na resposta pública' . ( $prova['hit'] ? ' entregue pelo cache.' : ' sem cache de página detectado.' ) : 'Cabeçalhos presentes, mas não houve comprovação de HIT. Confira o provedor ou a infraestrutura.' );
				$geracao = array(); preg_match( '/F3BASE-CONFIG:([a-f0-9]{64})/', $corpo, $geracao );
				if ( $perfil['ativo'] && ( empty( $geracao[1] ) || ! hash_equals( $contexto, $geracao[1] ) ) ) {
					$prova['status'] = 'failed'; $prova['codigo'] = 'cache_obsoleto'; $prova['motivo'] = 'A resposta pública não corresponde à geração atual do Core. Atualize o cache de página e eventual proxy.';
				}

			}
		}
		if ( ! hash_equals( $contexto, self::contexto() ) ) { $prova['status'] = 'pending'; $prova['codigo'] = 'contexto_alterado'; $prova['motivo'] = 'A configuração mudou durante a medição; execute outra verificação.'; }
		set_transient( self::PROVA, $prova, self::VALIDADE );
		return $prova;
	}
	public static function resumo(): array {
		return array( 'perfil' => self::perfil(), 'estado' => self::estado(), 'verification' => self::verificacao(), 'evidencia' => self::prova(), 'exclusoes_requeridas' => self::exclusoes(), 'proxima_verificacao' => (int) wp_next_scheduled( self::CRON ), 'limite_token' => F3Base_Modulo_Endpoint_Leads::limite_token() );
	}
}
