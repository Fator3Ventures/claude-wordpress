<?php
/** Cache versionado de conteúdo público, invalidado pelas mudanças do WordPress. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Modulo_Cache_Publico extends F3Base_Modulo {
	public const GERACAO = 'f3base_publico_geracao';
	public const TTL = 300;
	public const MAX_BYTES = 4194304;
	public function id(): string { return 'cache-publico'; }
	public function nome(): string { return 'Cache de conteúdo público'; }
	public function descricao(): string { return 'Atualiza o índice de caminhos e os textos llms quando conteúdo, visibilidade ou configuração mudam.'; }
	public function options_que_controlam(): array {
		return array( 'f3base_llms' );
	}
	protected function calcular_estado(): array { return ! empty( F3Base_Cache_Pagina::estado()['pendente'] ) ? $this->degradado( 'Atualização do cache de página pendente. A configuração permanece gravada.' ) : $this->ativo( 'Cache interno invalidável e limpeza de página coordenada com o provedor disponível.' ); }
	public function hooks(): array {
		return array(
			array( 'tipo' => 'action', 'hook' => 'init', 'metodo' => 'preparar', 'prioridade' => 20, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'shutdown', 'metodo' => 'concluir', 'prioridade' => 9999, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => F3Base_Cache_Pagina::CRON, 'metodo' => 'verificar', 'prioridade' => 10, 'args' => 0 ),
			array( 'tipo' => 'filter', 'hook' => 'rest_pre_dispatch', 'metodo' => 'proteger_rota', 'prioridade' => 0, 'args' => 3 ),
			array( 'tipo' => 'filter', 'hook' => 'rest_post_dispatch', 'metodo' => 'proteger_resposta', 'prioridade' => 9999, 'args' => 3 ),
			array( 'tipo' => 'action', 'hook' => 'wp_head', 'metodo' => 'marcador', 'prioridade' => 1, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'wpseo_saved_postdata', 'metodo' => 'conteudo_alterado', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'wpseo_saved_indexable', 'metodo' => 'indexavel_salvo', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'save_post', 'metodo' => 'conteudo_alterado', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'before_delete_post', 'metodo' => 'conteudo_alterado', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'transition_post_status', 'metodo' => 'visibilidade_alterada', 'prioridade' => 100, 'args' => 3 ),
			array( 'tipo' => 'action', 'hook' => 'added_post_meta', 'metodo' => 'meta_alterado', 'prioridade' => 100, 'args' => 2 ),
			array( 'tipo' => 'action', 'hook' => 'updated_post_meta', 'metodo' => 'meta_alterado', 'prioridade' => 100, 'args' => 2 ),
			array( 'tipo' => 'action', 'hook' => 'deleted_post_meta', 'metodo' => 'meta_alterado', 'prioridade' => 100, 'args' => 2 ),
			array( 'tipo' => 'action', 'hook' => 'set_object_terms', 'metodo' => 'conteudo_alterado', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'edited_term', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'delete_term', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'switch_theme', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'updated_option', 'metodo' => 'opcao_alterada', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'added_option', 'metodo' => 'opcao_alterada', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'deleted_option', 'metodo' => 'opcao_alterada', 'prioridade' => 100, 'args' => 1 ),
		);
	}
	/** Leads, revisões e métricas internas nunca invalidam páginas públicas. */
	public function conteudo_alterado( $id ): void {
		$post = is_numeric( $id ) ? get_post( (int) $id ) : null;
		if ( $post instanceof WP_Post && is_post_publicly_viewable( $post ) ) { self::invalidar(); }
	}
	public function meta_alterado( $meta_id, $post_id ): void { $this->conteudo_alterado( $post_id ); }
	public function visibilidade_alterada( $novo, $antigo, $post ): void {
		if ( ! $post instanceof WP_Post || $novo === $antigo ) { return; }
		$antes = clone $post; $antes->post_status = $antigo;
		if ( is_post_publicly_viewable( $post ) || is_post_publicly_viewable( $antes ) ) { self::invalidar(); }
	}
	public function indexavel_salvo( $indexavel ): void {
		if ( ! is_object( $indexavel ) || 'post' !== ( $indexavel->object_type ?? '' ) ) { return; }
		// A reconstrução inicial em uma leitura não deve limpar a página a cada MISS.
		// Os eventos de publicação/metadados acima já coordenam o cache de página.
		$post = get_post( (int) ( $indexavel->object_id ?? 0 ) );
		if ( $post instanceof WP_Post && is_post_publicly_viewable( $post ) ) { set_transient( self::GERACAO, wp_generate_uuid4(), DAY_IN_SECONDS ); }
	}
	public function opcao_alterada( string $nome ): void {
		if ( F3Base_Options::gravando( $nome ) ) { return; }
		if ( in_array( $nome, array( 'home', 'siteurl', 'blogname', 'blogdescription', 'blog_public', 'show_on_front', 'page_on_front', 'page_for_posts', 'permalink_structure', 'category_base', 'tag_base', 'active_plugins', 'f3base_llms', 'f3base_robots', 'f3base_redirects' ), true ) || str_starts_with( $nome, 'wpseo' ) || F3Base_Cache_Pagina::afeta( $nome ) ) { self::invalidar(); }
	}
	public static function invalidar(): void {
		set_transient( self::GERACAO, wp_generate_uuid4(), DAY_IN_SECONDS );
		if ( F3Base_Cache_Pagina::perfil()['limpeza_disponivel'] || F3Base_Cache_Pagina::perfil()['ativo'] ) { F3Base_Cache_Pagina::solicitar(); }
	}
	public function preparar(): void { F3Base_Cache_Pagina::preparar(); }
	public function concluir(): void { F3Base_Cache_Pagina::concluir(); }
	public function verificar(): void { F3Base_Cache_Pagina::tarefa(); }
	public function proteger_rota( $r, $s, $p ) { return F3Base_Cache_Pagina::proteger_rota( $r, $s, $p ); }
	public function proteger_resposta( $r, $s, $p ) { return F3Base_Cache_Pagina::proteger_resposta( $r, $s, $p ); }
	public function marcador(): void {
		if ( F3Base_Cache_Pagina::perfil()['ativo'] ) { echo '<!-- F3BASE-CACHE-PROBE:' . esc_html( wp_generate_uuid4() ) . ' F3BASE-CONFIG:' . esc_html( F3Base_Cache_Pagina::contexto() ) . ' -->' . "\n"; }
	}
	public function desinstalar(): void { wp_clear_scheduled_hook( F3Base_Cache_Pagina::CRON ); F3Base_Cache_Pagina::limpar(); }

	public static function geracao(): string {
		$g = get_transient( self::GERACAO );
		if ( ! is_string( $g ) || '' === $g ) { $g = wp_generate_uuid4(); set_transient( self::GERACAO, $g, DAY_IN_SECONDS ); }
		return is_string( $g ) ? $g : wp_generate_uuid4();
	}
	public static function lembrar( string $chave, callable $gerar ) {
		$g = self::geracao();
		$contexto = array( $g, F3BASE_PLUGIN_VERSAO, home_url( '/' ), get_locale(), get_option( 'permalink_structure' ), apply_filters( 'f3base_cache_contexto', '' ) );
		$nome = 'f3base_publico_' . hash( 'sha256', $chave . wp_json_encode( $contexto ) );
		$cache = get_transient( $nome );
		if ( is_array( $cache ) && array_key_exists( 'valor', $cache ) ) { return $cache['valor']; }
		$valor = $gerar();
		if ( $g === self::geracao() && strlen( serialize( $valor ) ) <= self::MAX_BYTES ) { set_transient( $nome, array( 'valor' => $valor ), self::TTL ); }
		return $valor;
	}
}
