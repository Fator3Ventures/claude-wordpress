from pathlib import Path
import os,subprocess,json,shutil,zipfile,hashlib
root=Path(__file__).resolve().parents[1]
# This script is launched inside run-lab.py so MySQL and PHP share a network namespace.
base=Path(os.environ.get('F3BASE_BASE_ZIP',str(root.parent/'base/base-site-core-fator3-1.38.0-instalador.zip')))
assert hashlib.sha256(base.read_bytes()).hexdigest()=='1b0de25e1dd4276fe7f7d8e428dfc0eb01a249d4108f680aa65bd3a4de3e59ee'
candidate=Path(os.environ.get('F3BASE_CANDIDATE',str(root/'build/candidate.zip')))
if not os.environ.get('F3BASE_CANDIDATE'):
 with zipfile.ZipFile(candidate,'w',zipfile.ZIP_DEFLATED) as z:
  for f in (root/'work/plugin/base-site-core-fator3').rglob('*'):
   if f.is_file():z.write(f,str(f.relative_to(root/'work/plugin')))
results={}
for kind in ['fresh','upgrade']:
 content=root/f'lab/content-{kind}'
 if content.exists():shutil.rmtree(content)
 content.mkdir();(content/'plugins').mkdir()
 shutil.copytree(root/'lab/wordpress/wp-content/mu-plugins',content/'mu-plugins');shutil.copytree(root/'lab/wordpress/wp-content/themes',content/'themes')
 with zipfile.ZipFile(candidate if kind=='fresh' else base) as z:z.extractall(content/'plugins')
 env=dict(os.environ,F3BASE_LAB_DB='core1390_'+kind,F3BASE_LAB_CONTENT=str(content))
 def call(mode,*args):
  r=subprocess.run([str(root/'build/php'),str(root/'tests/cycle-1370.php'),mode,*map(str,args)],env=env,capture_output=True,text=True)
  if r.returncode:raise RuntimeError(mode+' '+r.stdout[-1000:]+r.stderr[-1000:])
  try:return json.loads(r.stdout)
  except:raise RuntimeError(mode+' '+r.stdout[-1500:]+r.stderr[-1000:])
 out={'install':call('install')};assert out['install']['ok'],out
 if kind=='upgrade':
  out['seed']=call('seed');out['before']=call('snapshot');out['upload']=call('native-upload',candidate);assert out['upload']['ok'],out['upload']
 out['migrate']=call('migrate');assert out['migrate']['ok'],out['migrate'];out['finalize']=call('finalize');out['status']=call('status');assert out['status']['versao']=='1.39.0' and out['status']['structure_ready'],out['status'];assert out['status']['contrato']=='8.4.0';assert out['status']['callback_preservada'];assert not out['status']['gtm_agendado']
 if kind=='upgrade':
  assert all(out['status']['conteudo_padrao'].values()),out['status']['conteudo_padrao'];out['after']=call('snapshot');(root/'evidence/native-cycle-debug.json').write_text(json.dumps(out,indent=2));assert out['before']==out['after'],(out['before'],out['after']);assert out['status']['vazio_preservado'] and out['status']['procedencia_preservada'];assert out['status']['cursor']['ate']==1500000123
 out['repeat']=call('migrate');assert out['repeat']['codigo']=='atual',out['repeat'];results[kind]=out
 print(kind, 'OK',flush=True)
results['candidate_sha256']=hashlib.sha256(candidate.read_bytes()).hexdigest();results['clock']='finalization delay accelerated in disposable state; separate fresh requests'
(root/'evidence/native-cycles.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
