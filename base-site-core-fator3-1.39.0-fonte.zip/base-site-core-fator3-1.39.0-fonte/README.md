# Fator3 Site Core 1.39.0 — fonte

Código em work/plugin/base-site-core-fator3/. Instruções em build/README.md. Consulte o relatório: entrega com pendências de homologação e bloqueio para produção até adaptador Google. Este ZIP não é instalável no WordPress.
