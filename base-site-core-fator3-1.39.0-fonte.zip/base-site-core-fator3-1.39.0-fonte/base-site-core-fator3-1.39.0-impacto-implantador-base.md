# Impacto de base-site-core-fator3 1.39.0 em implantador-base

Revisão 2 · 20/10/2026 · Etapa: entrega · Situação: aberto
Base Core 1.38.0; alvo previsto 1.39.0, instalador final ainda não gerado. Destinatário: implantador-base 2.10.0, conforme impacto recebido. Classificação: validacao-coordenada. Pedidos core 231, 232 e 235.

## Mudanças e consequência

Contrato administrativo passa a 8.4.0: f3base_pipedrive acrescenta parceiros_plataforma (plataforma → ID de alternativa) e campos_fixos (chave CRM → ID ou texto), vazios por padrão; mapa_campos permite objetivo textual. Campos fixos exigem catálogo da conta e só entram no POST de um novo lead. Não são aplicados em PATCH de oportunidade existente.

mapeamento.campanhas das integrações de anúncio aceita tanto o nome textual legado quanto objeto com nome, parceiro (ID da alternativa) e objetivo (texto). Quem reproduzir configuração deve preservar objetos e listas vazias conforme o schema publicado.

O Core terá duas novas abilities administrativas de estado/recuperação de conversões. O transporte Google depende de adaptador externo, ainda ausente no Google 0.12.0. O navegador deixa de emitir generate_lead/Ads Contato nesta versão. A implantação em produção deve aguardar a configuração e homologação do transporte servidor; material conserva seus eventos.

## Ação e aceite

Responsável Implantador: ler o contrato vivo 8.4.0, preservar mapas existentes e validar merge/CAS/simulação/readback dos novos valores. Não preencher IDs de uma conta em outra. Não ativar destinos nem reinterpretar a ausência do adaptador como prontidão. Nenhum arquivo compartilhado foi alterado nesta rodada.

## Evidência e limites

Análise do impacto 2.10.0 recebido e da implementação Core. Testes integrados do Implantador não executados nesta rodada; nenhum pacote alheio alterado. Atualizar este documento com hash do instalador no fechamento.

## Fechamento da implementação Core

Instalador 1.39.0: e0ab847ebb1f2490656e19300f7254431ce8c6be6d095e0432b68d1b1cda9938 (SHA-256), 2004862 bytes. Implementação e contrato no Core concluídos; aceite integrado pendente. Instalação limpa e upgrade direto da 1.38 passaram em WordPress 7.1.3/PHP 8.3.6. Google continua 0.12.0 no Site-Teste; nenhum acompanhamento alterado. 188 checagens locais, fornecedores simulados. A revisão 1 acima registra a proposta inicial; este fechamento substitui a previsão de instalador ainda não gerado.
