

(function (window, document) {
	'use strict';

	var dados = window.f3baseTrackingDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CAMINHO = String(dados.caminho || 'nenhum');
	var carregado = false;

	window.dataLayer = window.dataLayer || [];

	

	function permiteTags() {
		if (window.f3baseConsentimento && typeof window.f3baseConsentimento.permiteTags === 'function') {
			return window.f3baseConsentimento.permiteTags();
		}

		return true;
	}

	

	function inserir(id, src) {
		if (document.getElementById(id)) {
			return;
		}

		var tag = document.createElement('script');

		tag.id = id;
		tag.async = true;
		tag.src = src;

		var primeiro = document.getElementsByTagName('script')[0];

		if (primeiro && primeiro.parentNode) {
			primeiro.parentNode.insertBefore(tag, primeiro);
		} else {
			document.head.appendChild(tag);
		}
	}

	function gtag() {
		window.dataLayer.push(arguments);
	}

	if (typeof window.gtag !== 'function') {
		window.gtag = gtag;
	}

	

	function carregarGtm() {
		window.dataLayer.push({
			event: 'gtm.js',
			'gtm.start': new Date().getTime()
		});

		inserir('f3base-gtm', String(dados.origemGoogle) + 'gtm.js?id=' + encodeURIComponent(String(dados.gtm)));
	}

	

	function carregarGoogleDireto() {
		var ga4 = String(dados.ga4 || '');
		var ads = dados.ads && typeof dados.ads === 'object' ? String(dados.ads.id || '') : '';
		var primeiro = ga4 || ads;

		if (!primeiro) {
			return;
		}

		inserir('f3base-gtag', String(dados.origemGoogle) + 'gtag/js?id=' + encodeURIComponent(primeiro));

		window.gtag('js', new Date());

		if (ga4) {
			window.gtag('config', ga4);
		}

		if (ads) {
			window.gtag('config', ads);
		}
	}

	

	function carregarMeta() {
		var pixel = dados.meta && typeof dados.meta === 'object' ? String(dados.meta.pixelId || '') : '';

		if (!pixel) {
			return;
		}

		if (!window.fbq) {
			var fila = function () {
				if (fila.callMethod) {
					fila.callMethod.apply(fila, arguments);
				} else {
					fila.queue.push(arguments);
				}
			};

			fila.push = fila;
			fila.loaded = true;
			fila.version = '2.0';
			fila.queue = [];

			window.fbq = fila;
			window._fbq = window._fbq || fila;
		}

		inserir('f3base-meta-pixel', String(dados.meta.origem));

		window.fbq('init', pixel);
		window.fbq('track', 'PageView');
	}

	

	function carregarLinkedin() {
		var parceiro = dados.linkedin && typeof dados.linkedin === 'object' ? String(dados.linkedin.partnerId || '') : '';

		if (!parceiro) {
			return;
		}

		window._linkedin_partner_id = parceiro;
		window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];

		if (window._linkedin_data_partner_ids.indexOf(parceiro) === -1) {
			window._linkedin_data_partner_ids.push(parceiro);
		}

		inserir('f3base-linkedin-insight', String(dados.linkedin.origem));
	}


	


	var COMPORTAMENTO = dados.comportamento && typeof dados.comportamento === 'object'
		? dados.comportamento
		: { eventos: {}, prefixoSecao: '' };

	var EVENTOS = COMPORTAMENTO.eventos && typeof COMPORTAMENTO.eventos === 'object'
		? COMPORTAMENTO.eventos
		: {};

	var emitidos = {};
	var instrumentado = false;

	


	var RESUMO = dados.resumo && typeof dados.resumo === 'object'
		? dados.resumo
		: { ativo: false, endpoint: '', token: '', maximo: 0 };

	var resumoDaSessao = {};
	var linhasDoResumo = 0;
	var resumoEnviado = false;

	


	var CHAVE_VISITANTE = 'f3base_visitante';
	var CHAVE_SESSAO = 'f3base_sessao';

	

	var CHAVE_EXCLUSAO = 'f3base_exclusao_pendente';

	var registroDaSessao = [];
	var visitante = '';
	var sessao = '';
	var gastasNaVisita = 0;
	var cortadasNaVisita = 0;

	

	var pendentes = [];

	

	var filaSerializada = '[]';

	

	var despachando = [];

	


	var travessiasDaVisita = {};
	var chavesDeTravessia = 0;

	

	var nascimento = (window.performance && window.performance.timeOrigin)
		? window.performance.timeOrigin
		: Date.now();

	

	function sorteado() {
		var bytes;
		var i;
		var saida = '';

		try {
			if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
				bytes = new window.Uint8Array(16);
				window.crypto.getRandomValues(bytes);

				for (i = 0; i < bytes.length; i++) {
					saida += ('0' + bytes[i].toString(16)).slice(-2);
				}

				return saida;
			}
		} catch (erro) {
			 
		}

		return '';
	}

	

	function apelidoGuardado() {
		var guardado;

		try {
			guardado = window.localStorage.getItem(CHAVE_VISITANTE);
		} catch (erro) {
			return '';
		}

		return (guardado && /^[a-f0-9]{32}$/.test(guardado)) ? guardado : '';
	}

	

	function podeIdentificar() {
		return permiteTags();
	}

	

	function apelidoDoVisitante() {
		var guardado = apelidoGuardado();

		if ('' !== guardado) {
			return guardado;
		}

		if (!podeIdentificar()) {
			return '';
		}

		guardado = sorteado();

		if ('' === guardado) {
			return '';
		}

		try {
			window.localStorage.setItem(CHAVE_VISITANTE, guardado);
		} catch (erro) {
			

			return '';
		}

		return guardado;
	}

	

	function visitaCorrente() {
		var janela = janelaDaVisita();
		var agora = Date.now();
		var guardada;
		var fila;

		try {
			guardada = JSON.parse(String(window.localStorage.getItem(CHAVE_SESSAO) || 'null'));
		} catch (erro) {
			guardada = null;
		}

		if (guardada && /^[a-f0-9]{32}$/.test(String(guardada.id)) && (agora - Number(guardada.visto || 0)) < janela) {
			fila = pendentesGuardados(guardada.pendentes, agora, janela);

			return {
				id: String(guardada.id),
				gastas: Math.max(0, Number(guardada.gastas || 0)),
				travessias: contadoresGuardados(guardada.travessias),
				acumulado: acumuladoGuardado(guardada.acumulado),
				

				cortadas: Math.max(0, Number(guardada.cortadas || 0)) + fila.vencidas,
				pendentes: fila.lotes
			};
		}

		

		return { id: sorteado(), gastas: 0, travessias: {}, cortadas: 0, pendentes: [], acumulado: null };
	}

	

	function acumuladoGuardado(bruto) {
		var eventos;
		var metricas;

		if (!bruto || 'object' !== typeof bruto || !/^\/[A-Za-z0-9\/_\-.~%]*$/.test(String(bruto.caminho || ''))) {
			return null;
		}

		eventos = linhasGuardadas(bruto.eventos);
		metricas = totaisGuardados(bruto.metricas);

		if (!eventos.length && !metricas.length) {
			return null;
		}

		return { caminho: String(bruto.caminho), eventos: eventos, metricas: metricas };
	}

	

	function janelaDaVisita() {
		return numeroDoLimiar('pagina', 'inatividade_min', 30) * 60 * 1000;
	}

	

	function pendentesGuardados(bruto, agora, janela) {
		var lotes = [];
		var vencidas = 0;
		var i;
		var lote;
		var eventos;
		var metricas;

		if (!bruto || !bruto.length) {
			return { lotes: lotes, vencidas: vencidas };
		}

		for (i = 0; i < bruto.length; i++) {
			lote = bruto[i];

			if (!lote || 'object' !== typeof lote || !/^[a-f0-9]{32}$/.test(String(lote.id))) {
				continue;
			}

			eventos = linhasGuardadas(lote.eventos);
			metricas = totaisGuardados(lote.metricas);

			if ((agora - Number(lote.nascido || 0)) >= janela) {
				vencidas = vencidas + eventos.length;

				continue;
			}

			if (!eventos.length && !metricas.length) {
				continue;
			}

			lotes.push({
				id: String(lote.id),
				nascido: Number(lote.nascido),
				

				origem: origemGuardada(lote.origem),
				caminho: String(lote.caminho || '/'),
				metricas: metricas,
				eventos: eventos,
				cortados: Math.max(0, Math.floor(Number(lote.cortados || 0)) || 0)
			});
		}

		return { lotes: lotes, vencidas: vencidas };
	}

	

	function origemGuardada(bruto) {
		var origem = Number(bruto);

		if (!isFinite(origem) || origem <= 0) {
			return 0;
		}

		return Math.round(origem);
	}

	

	function linhasGuardadas(bruto) {
		var saida = [];
		var i;
		var linha;

		if (!bruto || !bruto.length) {
			return saida;
		}

		for (i = 0; i < bruto.length && saida.length < Number(RESUMO.maximoLog || 0); i++) {
			linha = bruto[i];

			if (!linha || 'object' !== typeof linha || !/^[a-z-]+$/.test(String(linha.gatilho))) {
				continue;
			}

			saida.push({
				gatilho: String(linha.gatilho),
				detalhe: detalheDe(linha.detalhe),
				valor: isFinite(Number(linha.valor)) ? Number(linha.valor) : 0,
				ocorrencia: Math.max(0, Math.floor(Number(linha.ocorrencia)) || 0),
				ms: Math.max(0, Math.floor(Number(linha.ms)) || 0)
			});
		}

		return saida;
	}

	

	function totaisGuardados(bruto) {
		var saida = [];
		var i;
		var total;

		if (!bruto || !bruto.length) {
			return saida;
		}

		for (i = 0; i < bruto.length && saida.length < Number(RESUMO.maximo || 0); i++) {
			total = bruto[i];

			if (!total || 'object' !== typeof total || !/^[a-z-]+$/.test(String(total.gatilho))) {
				continue;
			}

			saida.push({
				gatilho: String(total.gatilho),
				detalhe: detalheDe(total.detalhe),
				contagem: Math.max(1, Math.floor(Number(total.contagem)) || 1),
				soma: isFinite(Number(total.soma)) ? Number(total.soma) : 0
			});
		}

		return saida;
	}

	

	function contadoresGuardados(bruto) {
		var limpos = {};
		var quantas = 0;
		var teto = Number(RESUMO.maximoVisita || 0);
		var chave;
		var valor;

		if (!bruto || 'object' !== typeof bruto) {
			return limpos;
		}

		for (chave in bruto) {
			if (Object.prototype.hasOwnProperty.call(bruto, chave)) {
				valor = Math.floor(Number(bruto[chave]));

				if (isFinite(valor) && valor > 0 && quantas < teto) {
					limpos[chave] = valor;
					quantas = quantas + 1;
				}
			}
		}

		return limpos;
	}

	

	function caminhoDaPagina() {
		return String(window.location.pathname || '/');
	}

	

	function guardarVisita() {
		if ('' === sessao) {
			return;
		}

		try {
			

			window.localStorage.setItem(
				CHAVE_SESSAO,
				'{"id":' + JSON.stringify(sessao)
					+ ',"gastas":' + JSON.stringify(gastasNaVisita)
					+ ',"travessias":' + JSON.stringify(travessiasDaVisita)
					+ ',"cortadas":' + JSON.stringify(cortadasNaVisita)
					

					+ ',"acumulado":' + JSON.stringify({
						caminho: caminhoDaPagina(),
						eventos: registroDaSessao,
						metricas: totaisAcumulados()
					})
					+ ',"pendentes":' + filaSerializada
					+ ',"visto":' + JSON.stringify(Date.now())
					+ '}'
			);
		} catch (erro) {
			 
		}
	}

	

	function serializarFila() {
		try {
			filaSerializada = JSON.stringify(pendentes);
		} catch (erro) {
			filaSerializada = '[]';
		}
	}

	

	function apararFila() {
		var teto = Math.max(1, Number(RESUMO.maximoVisita || 0));

		while (pendentes.length > teto) {
			cortadasNaVisita = cortadasNaVisita + pendentes[0].eventos.length;
			pendentes.shift();
		}
	}

	

	function contarTravessia(gatilho, detalhe) {
		var chave = caminhoDaPagina() + '|' + gatilho + '|' + detalheDe(detalhe);

		if (!Object.prototype.hasOwnProperty.call(travessiasDaVisita, chave)) {
			if (chavesDeTravessia >= Number(RESUMO.maximoVisita || 0)) {
				return 0;
			}

			travessiasDaVisita[chave] = 0;
			chavesDeTravessia = chavesDeTravessia + 1;
		}

		travessiasDaVisita[chave] = travessiasDaVisita[chave] + 1;

		

		guardarVisita();

		return travessiasDaVisita[chave];
	}

	

	function exclusaoPendente() {
		var guardado;

		try {
			guardado = window.localStorage.getItem(CHAVE_EXCLUSAO);
		} catch (erro) {
			return '';
		}

		return (guardado && /^[a-f0-9]{32}$/.test(guardado)) ? guardado : '';
	}

	

	function apagarChavesLocais() {
		try {
			window.localStorage.removeItem(CHAVE_VISITANTE);
			window.localStorage.removeItem(CHAVE_SESSAO);
			window.localStorage.removeItem(CHAVE_EXCLUSAO);
		} catch (erro) {
			 
		}
	}

	

	function pedirExclusao(apelido) {
		var alvo = String(RESUMO.esquecer || '');
		var corpo;

		if ('' === apelido || '' === alvo) {
			return;
		}

		corpo = JSON.stringify({ token: String(RESUMO.token || ''), visitante: apelido });

		

		try {
			window.localStorage.setItem(CHAVE_EXCLUSAO, apelido);
		} catch (erro) {
			 
		}

		if (confirmaEntrega()) {
			try {
				window.fetch(alvo, {
					method: 'POST',
					keepalive: true,
					credentials: 'omit',
					headers: { 'Content-Type': 'application/json' },
					body: corpo
				}).then(function (resposta) {
					var status = Number((resposta && resposta.status) || 0);

					if (status >= 200 && status < 300) {
						apagarChavesLocais();
					}
				})['catch'](function () {
					

				});

				return;
			} catch (erro) {
				 
			}
		}

		try {
			if (window.navigator && typeof window.navigator.sendBeacon === 'function') {
				window.navigator.sendBeacon(alvo, new window.Blob([ corpo ], { type: 'application/json' }));
			}
		} catch (erro) {
			 
		}
	}

	

	function esquecerVisitante() {
		pedirExclusao(visitante);

		visitante = '';
		sessao = '';
		registroDaSessao = [];

		

		pendentes = [];

		

		travessiasDaVisita = {};
		chavesDeTravessia = 0;
		cortadasNaVisita = 0;
		resumoDaSessao = {};
		linhasDoResumo = 0;
		despachando = [];

		serializarFila();
	}

	

	function registrar(gatilho, detalhe, valor, ocorrencia) {
		if (!RESUMO.ativo || '' === visitante || '' === sessao) {
			return;
		}

		

		if (gastasNaVisita >= Number(RESUMO.maximoVisita || 0)) {
			cortadasNaVisita = cortadasNaVisita + 1;

			return;
		}

		if (registroDaSessao.length >= Number(RESUMO.maximoLog || 0)) {
			selarLote();
		}

		gastasNaVisita = gastasNaVisita + 1;

		registroDaSessao.push({
			gatilho: gatilho,
			detalhe: detalhe,
			valor: valor,
			ocorrencia: ocorrencia,
			ms: Math.max(0, Math.round(Date.now() - nascimento))
		});

		guardarVisita();
	}

	

	function detalheDe(valor) {
		var texto = (undefined === valor || null === valor) ? '' : String(valor);

		return /^[A-Za-z0-9][A-Za-z0-9._-]{0,59}$/.test(texto) ? texto : '';
	}

	

	function acumular(gatilho, valores) {
		var detalhe;
		var soma;
		var chave;

		if (!RESUMO.ativo) {
			return;
		}

		detalhe = detalheDe(valores[0]);
		soma = ('' !== detalhe && valores.length > 1 && 'number' === typeof valores[1] && isFinite(valores[1]))
			? valores[1]
			: 0;

		chave = gatilho + '|' + detalhe;

		if (!Object.prototype.hasOwnProperty.call(resumoDaSessao, chave)) {
			if (linhasDoResumo >= Number(RESUMO.maximo || 0)) {
				return;
			}

			resumoDaSessao[chave] = { gatilho: gatilho, detalhe: detalhe, contagem: 0, soma: 0 };
			linhasDoResumo = linhasDoResumo + 1;
		}

		resumoDaSessao[chave].contagem = resumoDaSessao[chave].contagem + 1;
		resumoDaSessao[chave].soma = resumoDaSessao[chave].soma + soma;

		

		guardarVisita();
	}

	

	function totaisAcumulados() {
		var lista = [];
		var chave;

		for (chave in resumoDaSessao) {
			if (Object.prototype.hasOwnProperty.call(resumoDaSessao, chave)) {
				lista.push(resumoDaSessao[chave]);
			}
		}

		return lista;
	}

	

	function corpoDoLote(lote) {
		return {
			token: String(RESUMO.token || ''),
			lote: lote.id,
			

			origem: lote.origem,
			caminho: lote.caminho,
			metricas: lote.metricas,
			

			visitante: visitante,
			sessao: sessao,
			eventos: lote.eventos,
			cortados: lote.cortados
		};
	}

	

	function bytesDe(texto) {
		var total = 0;
		var i;
		var codigo;

		for (i = 0; i < texto.length; i++) {
			codigo = texto.charCodeAt(i);

			if (codigo < 0x80) {
				total = total + 1;
			} else if (codigo < 0x800) {
				total = total + 2;
			} else if (codigo >= 0xD800 && codigo <= 0xDBFF) {
				total = total + 4;
				i = i + 1;
			} else {
				total = total + 3;
			}
		}

		return total;
	}

	

	function cabeNoCorpo(lote) {
		var teto = Number(RESUMO.maximoBytes || 0);

		if (teto < 1) {
			return true;
		}

		return bytesDe(JSON.stringify(corpoDoLote(lote))) <= teto;
	}

	

	function selarLote() {
		var acumulado = registroDaSessao;
		var totais = totaisAcumulados();

		

		if (!totais.length && !acumulado.length) {
			return;
		}

		registroDaSessao = [];
		resumoDaSessao = {};
		linhasDoResumo = 0;

		selar(caminhoDaPagina(), totais, acumulado);
	}

	

	function selar(caminho, metricas, restantes) {
		var lote;

		do {
			lote = {
				id: sorteado(),
				nascido: Date.now(),
				

				origem: Math.round(nascimento),
				caminho: caminho,
				metricas: metricas,
				eventos: [],
				cortados: cortadasNaVisita
			};

			

			metricas = [];
			cortadasNaVisita = 0;

			while (restantes.length > 0) {
				lote.eventos.push(restantes[0]);

				if (!cabeNoCorpo(lote)) {
					lote.eventos.pop();

					break;
				}

				restantes.shift();
			}

			

			if (!lote.eventos.length && restantes.length > 0) {
				restantes.shift();
				lote.cortados = lote.cortados + 1;
			}

			if (lote.eventos.length > 0 || lote.metricas.length > 0 || lote.cortados > 0) {
				pendentes.push(lote);
			}
		} while (restantes.length > 0);

		apararFila();
		serializarFila();

		guardarVisita();
	}

	

	function confirmaEntrega() {
		try {
			return 'function' === typeof window.fetch
				&& 'function' === typeof window.Request
				&& ('keepalive' in window.Request.prototype);
		} catch (erro) {
			return false;
		}
	}

	

	function esquecerLote(lote) {
		var restam = [];
		var i;

		for (i = 0; i < pendentes.length; i++) {
			if (pendentes[i] !== lote) {
				restam.push(pendentes[i]);
			}
		}

		pendentes = restam;

		serializarFila();

		guardarVisita();
	}

	

	function emVoo(lote) {
		var i;

		for (i = 0; i < despachando.length; i++) {
			if (despachando[i] === lote) {
				return true;
			}
		}

		return false;
	}

	

	function pousar(lote) {
		var restam = [];
		var i;

		for (i = 0; i < despachando.length; i++) {
			if (despachando[i] !== lote) {
				restam.push(despachando[i]);
			}
		}

		despachando = restam;
	}

	

	function recusaPermanente(status) {
		return 400 === status || 413 === status;
	}

	

	function concluirLote(lote, status) {
		if (status >= 200 && status < 300) {
			esquecerLote(lote);

			return;
		}

		if (recusaPermanente(status)) {
			

			cortadasNaVisita = cortadasNaVisita + lote.eventos.length;

			esquecerLote(lote);

			return;
		}

		

	}

	

	function despacharLote(lote) {
		var corpo;
		var alvo = String(RESUMO.endpoint);
		var aceito;

		

		if (emVoo(lote)) {
			return;
		}

		corpo = JSON.stringify(corpoDoLote(lote));

		if (confirmaEntrega()) {
			try {
				despachando.push(lote);

				

				window.fetch(alvo, {
					method: 'POST',
					keepalive: true,
					credentials: 'omit',
					headers: { 'Content-Type': 'application/json' },
					body: corpo
				}).then(function (resposta) {
					pousar(lote);
					concluirLote(lote, Number((resposta && resposta.status) || 0));
				})['catch'](function () {
					

					pousar(lote);
				});

				return;
			} catch (erro) {
				

				pousar(lote);
			}
		}

		if (!window.navigator || typeof window.navigator.sendBeacon !== 'function') {
			return;
		}

		try {
			aceito = window.navigator.sendBeacon(alvo, new window.Blob([corpo], { type: 'application/json' }));
		} catch (erro) {
			 
			aceito = false;
		}

		

		if (aceito) {
			esquecerLote(lote);
		}
	}

	

	function despacharPendentes() {
		var fila = pendentes.slice();
		var i;

		if (!RESUMO.ativo || !RESUMO.endpoint) {
			return;
		}

		for (i = 0; i < fila.length; i++) {
			despacharLote(fila[i]);
		}
	}

	

	function enviarResumo() {
		

		if (resumoEnviado || !RESUMO.ativo || !RESUMO.endpoint) {
			return;
		}

		 
		resumoEnviado = true;

		selarLote();
		despacharPendentes();

		

		resumoEnviado = false;
	}

	

	function declaracao(gatilho) {
		var nome;

		for (nome in EVENTOS) {
			if (Object.prototype.hasOwnProperty.call(EVENTOS, nome) && EVENTOS[nome].gatilho === gatilho) {
				return { nome: nome, dados: EVENTOS[nome] };
			}
		}

		return null;
	}

	

	function limiar(gatilho, chave, reserva) {
		var d = declaracao(gatilho);
		var lista = d && d.dados.limiar && d.dados.limiar[chave];

		return (lista && lista.length) ? lista : reserva;
	}

	function numeroDoLimiar(gatilho, chave, reserva) {
		var lista = limiar(gatilho, chave, null);
		var valor = lista ? parseFloat(lista[0]) : NaN;

		return isNaN(valor) ? reserva : valor;
	}

	

	function podeEmitir(nome, teto) {
		emitidos[nome] = (emitidos[nome] || 0) + 1;

		return emitidos[nome] <= teto;
	}

	

	function emitir(gatilho, valores) {
		var d = declaracao(gatilho);
		var objeto;
		var limpos = {};
		var i;
		var chave;

		if (!d || !podeEmitir(d.nome, d.dados.teto)) {
			return false;
		}

		for (i = 0; i < d.dados.parametros.length && i < valores.length; i++) {
			if (undefined !== valores[i] && null !== valores[i]) {
				limpos[d.dados.parametros[i]] = valores[i];
			}
		}

		objeto = { event: d.nome };

		for (chave in limpos) {
			if (Object.prototype.hasOwnProperty.call(limpos, chave)) {
				objeto[chave] = limpos[chave];
			}
		}

		acumular(gatilho, valores);

		

		if ('rolagem' !== gatilho && 'interseccao' !== gatilho) {
			registrar(
				gatilho,
				detalheDe(valores[0]),
				(valores.length > 1 && 'number' === typeof valores[1] && isFinite(valores[1])) ? valores[1] : 0,
				1
			);
		}

		

		if (CAMINHO === 'nenhum') {
			return true;
		}

		try {
			window.dataLayer.push(objeto);
		} catch (erro) {
			 
		}

		if (typeof window.gtag === 'function') {
			try {
				window.gtag('event', d.nome, limpos);
			} catch (erro) {
				 
			}
		}

		return true;
	}

	

	function hostDe(url) {
		try {
			return new window.URL(String(url), window.location.href).hostname || '';
		} catch (erro) {
			return '';
		}
	}

	

	function instrumentarRolagem() {
		var GATILHO = 'rolagem';
		var marcos = limiar(GATILHO, 'marcos', []).map(Number).filter(function (n) {
			return !isNaN(n);
		});
		var vistos = {};
		

		var dentro = {};
		

		var tetoDeTravessias = numeroDoLimiar(GATILHO, 'travessias_por_sessao', 30);
		

		var histerese = numeroDoLimiar(GATILHO, 'histerese_pp', 5);

		if (!declaracao(GATILHO) || !marcos.length) {
			return;
		}

		

		function medir() {
			var doc = document.documentElement;
			var corpo = document.body;
			var altura = Math.max(
				(doc && doc.scrollHeight) || 0,
				(corpo && corpo.scrollHeight) || 0
			);
			var visivel = window.innerHeight || (doc && doc.clientHeight) || 0;
			var rolado = window.pageYOffset || (doc && doc.scrollTop) || 0;
			var util = altura - visivel;
			var percentual;
			var vez;
			var i;

			

			if (util > 0) {
				percentual = (rolado / util) * 100;
			} else if ('complete' === document.readyState) {
				percentual = 100;
			} else {
				return;
			}

			

			for (i = 0; i < marcos.length; i++) {
				if (percentual >= marcos[i]) {
					if (!dentro[marcos[i]]) {
						dentro[marcos[i]] = true;
						vez = contarTravessia(GATILHO, String(marcos[i]));

						if (vez > 0 && vez <= tetoDeTravessias) {
							registrar(GATILHO, String(marcos[i]), 0, vez);
						} else {
							

							cortadasNaVisita = cortadasNaVisita + 1;
						}
					}

					if (!vistos[marcos[i]]) {
						vistos[marcos[i]] = true;
						emitir(GATILHO, [ marcos[i] ]);
					}

					continue;
				}

				

				if (percentual < marcos[i] - histerese) {
					dentro[marcos[i]] = false;
				}
			}
		}

		window.addEventListener('scroll', medir, { passive: true });

		

		window.addEventListener('load', medir);
		window.addEventListener('resize', medir, { passive: true });

		if (typeof window.ResizeObserver === 'function') {
			try {
				new window.ResizeObserver(medir).observe(document.documentElement);
			} catch (erro) {
				 
			}
		}

		medir();
	}

	

	function instrumentarPaginaVista() {
		var GATILHO = 'pagina';

		if (!declaracao(GATILHO)) {
			return;
		}

		emitir(GATILHO, []);
	}

	

	function instrumentarSecoes() {
		var GATILHO = 'interseccao';
		var prefixo = String(COMPORTAMENTO.prefixoSecao || '');
		var visivel = numeroDoLimiar(GATILHO, 'visivel', 0.5);
		

		var saida = numeroDoLimiar(GATILHO, 'saida', visivel);
		var faixas;
		var vistas = {};
		

		var observados = [];
		var dentroDaVista = [];
		var tetoPorSecao = numeroDoLimiar(GATILHO, 'travessias_por_sessao', 30);
		var observador;
		var alvos;
		var i;

		

		function indiceDoAlvo(alvo) {
			var k;

			for (k = 0; k < observados.length; k++) {
				if (observados[k] === alvo) {
					return k;
				}
			}

			return -1;
		}

		if (!declaracao(GATILHO) || '' === prefixo || typeof window.IntersectionObserver !== 'function') {
			return;
		}

		

		if (!(saida >= 0) || saida >= visivel) {
			saida = visivel;
		}

		

		faixas = saida < visivel ? [ 0, saida, visivel ] : [ 0, visivel ];

		function nomeDaSecao(elemento) {
			var tokens = String(elemento.className || '').split(/\s+/);
			var j;

			for (j = 0; j < tokens.length; j++) {
				if (tokens[j].indexOf(prefixo) === 0 && tokens[j].length > prefixo.length) {
					return tokens[j].slice(prefixo.length);
				}
			}

			return '';
		}

		

		

		observador = new window.IntersectionObserver(function (entradas) {
			var j;
			var secao;
			var razao;
			var vez;
			var qual;

			for (j = 0; j < entradas.length; j++) {
				secao = nomeDaSecao(entradas[j].target);
				qual = indiceDoAlvo(entradas[j].target);

				if ('' === secao || qual < 0) {
					continue;
				}

				

				razao = ('number' === typeof entradas[j].intersectionRatio && isFinite(entradas[j].intersectionRatio))
					? entradas[j].intersectionRatio
					: (entradas[j].isIntersecting ? visivel : 0);

				

				if (!entradas[j].isIntersecting || razao < saida) {
					dentroDaVista[qual] = false;

					continue;
				}

				

				if (razao < visivel) {
					continue;
				}

				if (dentroDaVista[qual]) {
					continue;
				}

				dentroDaVista[qual] = true;
				vez = contarTravessia(GATILHO, secao);

				if (vez > 0 && vez <= tetoPorSecao) {
					registrar(GATILHO, secao, 0, vez);
				} else {
					cortadasNaVisita = cortadasNaVisita + 1;
				}

				if (!vistas[secao]) {
					vistas[secao] = true;
					emitir(GATILHO, [ secao ]);
				}
			}
		}, { threshold: faixas });

		alvos = document.querySelectorAll('[class*="' + prefixo + '"]');

		for (i = 0; i < alvos.length; i++) {
			if ('' !== nomeDaSecao(alvos[i])) {
				observados.push(alvos[i]);
				dentroDaVista.push(false);
				observador.observe(alvos[i]);
			}
		}
	}

	

	function instrumentarLinksExternos() {
		var GATILHO = 'clique-externo';

		if (!declaracao(GATILHO)) {
			return;
		}

		document.addEventListener('click', function (evento) {
			var alvo = evento.target;
			var destino;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && 'A' === alvo.tagName && alvo.getAttribute('href')) {
					break;
				}

				alvo = alvo.parentNode;
			}

			if (!alvo || alvo === document.body || 'A' !== alvo.tagName) {
				return;
			}

			destino = hostDe(alvo.getAttribute('href'));

			if ('' === destino || destino === window.location.hostname) {
				return;
			}

			emitir(GATILHO, [ destino ]);
		}, true);
	}

	

	function instrumentarFriccao() {
		var GATILHO = 'clique-repetido';
		

		var alvoCliques = numeroDoLimiar(GATILHO, 'cliques', 4);
		var janela = numeroDoLimiar(GATILHO, 'janela_ms', 1200);
		var raio = numeroDoLimiar(GATILHO, 'raio_px', 24);
		var interativo = 'interativo' === String(limiar(GATILHO, 'alvo', [''])[0]);
		var ultimo = null;

		if (!declaracao(GATILHO) || alvoCliques < 1 || janela <= 0 || raio <= 0) {
			return;
		}

		function controle(elemento) {
			if (!elemento || typeof elemento.closest !== 'function') {
				return null;
			}

			return elemento.closest('a[href],button,input,select,textarea,summary,[role="button"],[role="link"],[tabindex]');
		}

		document.addEventListener('click', function (evento) {
			var alvo = interativo ? controle(evento.target) : evento.target;
			var agora = Date.now();
			var x = evento.clientX || 0;
			var y = evento.clientY || 0;

			if (!alvo) {
				ultimo = null;
				return;
			}

			if (
				ultimo &&
				ultimo.alvo === alvo &&
				(agora - ultimo.quando) <= janela &&
				Math.abs(x - ultimo.x) <= raio &&
				Math.abs(y - ultimo.y) <= raio
			) {
				ultimo.contagem += 1;
				ultimo.quando = agora;
			} else {
				ultimo = { alvo: alvo, x: x, y: y, quando: agora, contagem: 1 };
			}

			if (ultimo.contagem >= alvoCliques) {
				emitir(GATILHO, [ ultimo.contagem ]);
				ultimo = null;
			}
		}, true);
	}

	

	function origemDoErro(arquivo) {
		var texto = String(arquivo || '');
		var host;

		if ('' === texto || /^[a-z-]+-extension:/i.test(texto) || 0 === texto.indexOf('about:')) {
			return 'ambiente';
		}

		host = hostDe(texto);

		if ('' === host) {
			return 'ambiente';
		}

		return host === window.location.hostname ? 'site' : 'terceiro';
	}

	

	function instrumentarErros() {
		var GATILHO = 'erro';
		var vistos = {};

		if (!declaracao(GATILHO) || 'site' !== String(limiar(GATILHO, 'origem', [''])[0])) {
			return;
		}

		window.addEventListener('error', function (evento) {
			var arquivo = evento && evento.filename ? String(evento.filename) : '';
			var linha = evento && evento.lineno ? parseInt(evento.lineno, 10) : 0;
			var caminho;
			var chave;

			if ('site' !== origemDoErro(arquivo)) {
				return;
			}

			try {
				caminho = new window.URL(arquivo, window.location.href).pathname;
			} catch (erro) {
				return;
			}

			chave = caminho + ':' + linha;

			if (vistos[chave]) {
				return;
			}

			vistos[chave] = true;

			emitir(GATILHO, [ caminho.slice(0, 100), linha ]);
		});
	}

	

	function instrumentarVitais() {
		var GATILHO = 'desempenho';
		var vitais = limiar(GATILHO, 'vitais', []);
		var duracaoMinima = numeroDoLimiar(GATILHO, 'duracao_minima_ms', 16);
		

		var medidos = { LCP: null, CLS: null, INP: null, TTFB: null };
		var relatado = false;

		if (!declaracao(GATILHO) || !vitais.length || typeof window.PerformanceObserver !== 'function') {
			return;
		}

		function observar(tipo, aoEntrar, extras) {
			var opcoes = { type: tipo, buffered: true };
			var chave;

			for (chave in extras) {
				if (Object.prototype.hasOwnProperty.call(extras, chave)) {
					opcoes[chave] = extras[chave];
				}
			}

			try {
				new window.PerformanceObserver(function (lista) {
					var entradas = lista.getEntries();
					var i;

					for (i = 0; i < entradas.length; i++) {
						aoEntrar(entradas[i]);
					}
				}).observe(opcoes);
			} catch (erro) {
				 
			}
		}

		observar('largest-contentful-paint', function (entrada) {
			medidos.LCP = entrada.startTime;
		});

		observar('layout-shift', function (entrada) {
			if (!entrada.hadRecentInput) {
				medidos.CLS = (null === medidos.CLS ? 0 : medidos.CLS) + entrada.value;
			}
		});

		observar('event', function (entrada) {
			if (entrada.interactionId && (null === medidos.INP || entrada.duration > medidos.INP)) {
				medidos.INP = entrada.duration;
			}
		}, { durationThreshold: duracaoMinima });

		try {
			var navegacao = window.performance.getEntriesByType('navigation')[0];

			if (navegacao) {
				medidos.TTFB = navegacao.responseStart;
			}
		} catch (erro) {
			 
		}

		function relatar() {
			var i;
			var chave;
			var valor;

			if (relatado) {
				return;
			}

			relatado = true;

			for (i = 0; i < vitais.length; i++) {
				chave = vitais[i];
				valor = medidos[chave];

				if (null === valor || typeof valor !== 'number' || isNaN(valor)) {
					continue;
				}

				emitir(GATILHO, [
					chave,
					'CLS' === chave ? Math.round(valor * 1000) / 1000 : Math.round(valor)
				]);
			}
		}

		document.addEventListener('visibilitychange', function () {
			if ('hidden' === document.visibilityState) {
				relatar();
			}
		});

		window.addEventListener('pagehide', relatar);
	}

	

	function instrumentar() {
		if (instrumentado) {
			return;
		}

		instrumentado = true;

		instrumentarPaginaVista();
		instrumentarRolagem();
		instrumentarSecoes();
		instrumentarLinksExternos();
		instrumentarFriccao();
		instrumentarErros();
		instrumentarVitais();
		instrumentarResumo();
	}

	

	function instrumentarResumo() {
		if (!RESUMO.ativo) {
			return;
		}

		document.addEventListener('visibilitychange', function () {
			if ('hidden' === document.visibilityState) {
				enviarResumo();
			}
		});

		window.addEventListener('pagehide', enviarResumo);
	}

	

	function iniciarResumo() {
		var visita;

		

		if (!RESUMO.ativo) {
			return;
		}

		

		if ('' !== sessao) {
			if ('' === visitante) {
				visitante = apelidoDoVisitante();
			}

			return;
		}

		visitante = apelidoDoVisitante();

		visita = visitaCorrente();

		sessao = visita.id;
		gastasNaVisita = visita.gastas;

		

		travessiasDaVisita = visita.travessias;
		chavesDeTravessia = Object.keys(travessiasDaVisita).length;
		cortadasNaVisita = visita.cortadas;

		

		pendentes = visita.pendentes;

		apararFila();
		serializarFila();

		

		if (visita.acumulado) {
			selar(visita.acumulado.caminho, visita.acumulado.metricas, visita.acumulado.eventos);
		}

		guardarVisita();

		

		despacharPendentes();
	}

	function carregar() {
		

		if ('' !== exclusaoPendente()) {
			pedirExclusao(exclusaoPendente());
		}

		


		

		if (carregado || !permiteTags()) {
			return;
		}

		

		if (CAMINHO === 'nenhum' && !RESUMO.ativo) {
			return;
		}

		carregado = true;

		iniciarResumo();

		

		instrumentar();

		if (CAMINHO === 'gtm') {
			carregarGtm();
			return;
		}

		if (CAMINHO === 'direto') {
			carregarGoogleDireto();
			carregarMeta();
			carregarLinkedin();
		}
	}

	

	document.addEventListener('f3base-consentimento', function () {
		

		if (!permiteTags()) {
			esquecerVisitante();

			return;
		}

		

		if (carregado) {
			iniciarResumo();

			return;
		}

		carregar();
	});

	window.f3baseTracking = {
		caminho: function () {
			return CAMINHO;
		},
		carregar: carregar,
		permiteTags: permiteTags,
		eventos: function () {
			return EVENTOS;
		},
		emitidos: function () {
			return emitidos;
		},
		resumo: function () {
			return resumoDaSessao;
		}
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', carregar);
	} else {
		carregar();
	}
}(window, document));
