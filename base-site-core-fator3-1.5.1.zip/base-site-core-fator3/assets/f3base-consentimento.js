

(function (window, document) {
	'use strict';

	var dados = window.f3baseConsentimentoDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CATEGORIAS = Array.isArray(dados.categorias) && dados.categorias.length
		? dados.categorias
		: ['analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization'];

	

	function verdadeiro(valor) {
		return valor !== false && valor !== 0 && valor !== '' && valor !== '0'
			&& valor !== null && valor !== undefined && valor !== 'false';
	}

	var COOKIE = String(dados.cookie || 'f3base_consentimento');
	var TTL_DIAS = parseInt(dados.ttlDias, 10) > 0 ? parseInt(dados.ttlDias, 10) : 180;
	var PRE_APROVADO = String(dados.padrao || 'pre-aprovado') === 'pre-aprovado';
	var TEXTOS = dados.textos && typeof dados.textos === 'object' ? dados.textos : {};

	var ID_BANNER = String(dados.idBanner || 'f3base-consentimento-banner');
	var SELETOR_CONTROLE = String(dados.seletorControle || '[data-f3base-consentimento]');

	var banner = null;
	var aviso = null;
	var abridor = null;

	window.dataLayer = window.dataLayer || [];

	function gtag() {
		window.dataLayer.push(arguments);
	}

	if (typeof window.gtag !== 'function') {
		window.gtag = gtag;
	}

	function lerCookie(nome) {
		var partes = String(document.cookie || '').split(';');
		var i;
		var atual;

		for (i = 0; i < partes.length; i++) {
			atual = partes[i].replace(/^\s+/, '');
			if (atual.indexOf(nome + '=') === 0) {
				return decodeURIComponent(atual.substring(nome.length + 1));
			}
		}

		return '';
	}

	function gravarCookie(nome, valor, dias) {
		var seguro = window.location.protocol === 'https:' ? '; Secure' : '';
		document.cookie = nome + '=' + encodeURIComponent(valor) +
			'; Max-Age=' + (dias * 86400) +
			'; Path=/; SameSite=Lax' + seguro;
	}

	function decisaoGravada() {
		var valor = lerCookie(COOKIE);

		return (valor === 'granted' || valor === 'denied') ? valor : '';
	}

	function estadoAtual() {
		var decisao = decisaoGravada();

		if (decisao) {
			return decisao;
		}

		return PRE_APROVADO ? 'granted' : 'denied';
	}

	function mapa(estado) {
		var saida = {};
		var i;

		for (i = 0; i < CATEGORIAS.length; i++) {
			saida[CATEGORIAS[i]] = estado;
		}

		saida.functionality_storage = 'granted';
		saida.security_storage = 'granted';

		return saida;
	}

	function aplicarPadrao() {
		window.gtag('consent', 'default', mapa(estadoAtual()));
	}

	function atualizar(estado) {
		window.gtag('consent', 'update', mapa(estado));
		window.dataLayer.push({
			event: 'f3base_consentimento',
			f3base_consentimento_estado: estado
		});
	}

	

	function definir(estado) {
		var normalizado = estado === 'granted' ? 'granted' : 'denied';

		gravarCookie(COOKIE, normalizado, TTL_DIAS);
		atualizar(normalizado);
		anunciar(normalizado);
		sincronizarBanner();
		fecharAviso();
		fechar();

		return normalizado;
	}

	

	function anunciar(estado) {
		try {
			document.dispatchEvent(new CustomEvent('f3base-consentimento', {
				detail: { estado: estado }
			}));
		} catch (erro) {
			 
		}
	}

	function botao(rotulo, aoClicar, classe) {
		var elemento = document.createElement('button');

		elemento.type = 'button';
		elemento.className = classe;
		elemento.textContent = rotulo;
		elemento.addEventListener('click', aoClicar);

		return elemento;
	}

	

	function construirBanner() {
		var faixa = document.createElement('div');
		var caixa = document.createElement('div');
		var titulo = document.createElement('h2');
		var texto = document.createElement('p');
		var estado = document.createElement('p');
		var acoes = document.createElement('div');

		faixa.id = ID_BANNER;
		faixa.className = 'f3base-consentimento-banner';
		faixa.setAttribute('role', 'dialog');
		faixa.setAttribute('aria-modal', 'false');
		faixa.setAttribute('aria-label', String(TEXTOS.titulo || 'Consentimento'));
		faixa.setAttribute('tabindex', '-1');
		faixa.hidden = true;

		caixa.className = 'f3base-consentimento-caixa';

		titulo.className = 'f3base-consentimento-titulo';
		titulo.textContent = String(TEXTOS.titulo || '');

		texto.className = 'f3base-consentimento-texto';
		texto.textContent = String(TEXTOS.explicacao || '');

		estado.className = 'f3base-consentimento-estado';

		acoes.className = 'f3base-consentimento-acoes';
		acoes.appendChild(botao(String(TEXTOS.aceitar || 'Permitir'), function () {
			definir('granted');
		}, 'f3base-consentimento-aceitar'));
		acoes.appendChild(botao(String(TEXTOS.recusar || 'Desligar'), function () {
			definir('denied');
		}, 'f3base-consentimento-recusar'));
		acoes.appendChild(botao(String(TEXTOS.fechar || 'Fechar'), function () {
			fechar();
		}, 'f3base-consentimento-fechar'));

		caixa.appendChild(titulo);
		caixa.appendChild(texto);
		caixa.appendChild(estado);

		if (dados.politicaUrl) {
			var link = document.createElement('a');
			link.className = 'f3base-consentimento-politica';
			link.href = String(dados.politicaUrl);
			link.textContent = String(TEXTOS.politica || 'Política de Privacidade');
			caixa.appendChild(link);
		}

		caixa.appendChild(acoes);
		faixa.appendChild(caixa);
		document.body.appendChild(faixa);

		banner = { faixa: faixa, estado: estado };

		sincronizarBanner();

		return banner;
	}

	function sincronizarBanner() {
		if (!banner) {
			return;
		}

		banner.estado.textContent = estadoAtual() === 'granted'
			? String(TEXTOS.estadoAtivo || '')
			: String(TEXTOS.estadoNegado || '');
	}

	

	function marcarControles(aberto) {
		var controles;
		var i;

		try {
			controles = document.querySelectorAll(SELETOR_CONTROLE);
		} catch (erro) {
			return;
		}

		for (i = 0; i < controles.length; i++) {
			controles[i].setAttribute('aria-expanded', aberto ? 'true' : 'false');
		}
	}

	

	function reservarEspaco(aberto) {
		var raiz = document.documentElement;
		var altura;

		if (!raiz || !raiz.style) {
			return;
		}

		if (!aberto) {
			raiz.style.setProperty('--f3base-banner-altura', '0px');
			raiz.removeAttribute('data-f3base-banner');
			return;
		}

		altura = (banner && banner.faixa && banner.faixa.offsetHeight) || 0;

		raiz.style.setProperty('--f3base-banner-altura', altura + 'px');
		raiz.setAttribute('data-f3base-banner', 'aberto');
	}

	function abrir(origem) {
		if (!banner) {
			construirBanner();
		}

		abridor = origem || abridor;

		sincronizarBanner();
		banner.faixa.hidden = false;
		marcarControles(true);
		reservarEspaco(true);

		try {
			banner.faixa.focus();
		} catch (erro) {
			 
		}
	}

	

	function fechar() {
		if (!banner) {
			return;
		}

		banner.faixa.hidden = true;
		marcarControles(false);
		reservarEspaco(false);

		if (abridor && typeof abridor.focus === 'function') {
			try {
				abridor.focus();
			} catch (erro) {
				 
			}
		}

		abridor = null;
	}

	function fecharAviso() {
		if (aviso && aviso.parentNode) {
			aviso.parentNode.removeChild(aviso);
			aviso = null;
		}
	}

	function mostrarAviso() {
		if (!verdadeiro(dados.avisoPrimeiraVisita)) {
			return;
		}

		if (decisaoGravada()) {
			return;
		}

		try {
			if (window.localStorage.getItem('f3base_aviso_visto') === '1') {
				return;
			}
			window.localStorage.setItem('f3base_aviso_visto', '1');
		} catch (erro) {
			 
		}

		aviso = document.createElement('div');
		aviso.className = 'f3base-consentimento-aviso';
		aviso.setAttribute('role', 'status');

		var texto = document.createElement('span');
		texto.textContent = String(TEXTOS.aviso || '');
		aviso.appendChild(texto);

		if (dados.politicaUrl) {
			var link = document.createElement('a');
			link.href = String(dados.politicaUrl);
			link.textContent = String(TEXTOS.politica || '');
			aviso.appendChild(link);
		}

		aviso.appendChild(botao(String(TEXTOS.avisoOk || 'Ok'), fecharAviso, 'f3base-consentimento-aviso-ok'));
		aviso.appendChild(botao(String(TEXTOS.recusar || 'Desligar'), function () {
			definir('denied');
		}, 'f3base-consentimento-aviso-recusar'));

		document.body.appendChild(aviso);
	}

	function ligarControles() {
		document.addEventListener('click', function (evento) {
			var alvo = evento.target;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && alvo.matches && alvo.matches(SELETOR_CONTROLE)) {
					evento.preventDefault();
					abrir(alvo);
					return;
				}
				alvo = alvo.parentNode;
			}
		});
	}

	

	function ligarEscape() {
		document.addEventListener('keydown', function (evento) {
			if (!banner || banner.faixa.hidden) {
				return;
			}

			if (evento.key === 'Escape' || evento.keyCode === 27) {
				fechar();
			}
		});
	}

	function iniciar() {
		if (verdadeiro(dados.controleRodape)) {
			construirBanner();
			ligarControles();
			ligarEscape();
		}

		mostrarAviso();
	}

	aplicarPadrao();

	window.f3baseConsentimento = {
		estado: estadoAtual,
		definir: definir,
		abrir: abrir,
		fechar: fechar,
		permiteTags: function () {
			return estadoAtual() === 'granted';
		}
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', iniciar);
	} else {
		iniciar();
	}
}(window, document));
