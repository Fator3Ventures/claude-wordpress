<?php
/** Fotografia do access.log: hoje é parcial e nunca é gravado no histórico. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Acessos_Atuais {
	public static function ler(): array {
		$c = F3Base_Modulo_Acessos_Servidor::config();
		$saida = array( 'dia' => wp_date( 'Y-m-d' ), 'atualizado' => time(), 'linhas' => array(), 'erro' => '', 'ignoradas' => 0 );
		if ( empty( $c['ligado'] ) ) { $saida['erro'] = 'Leitura de hoje desligada junto com a coleta de acessos.'; return $saida; }
		try {
			$padrao = F3Base_Modulo_Acessos_Servidor::resolver_padrao( $c['padrao_do_log'] );
			$pastas = array();
			foreach ( @glob( dirname( $padrao ), GLOB_ONLYDIR ) ?: array() as $pasta ) {
				$real = @realpath( $pasta );
				if ( false !== $real ) { $pastas[ $real ] = true; }
			}
			if ( count( $pastas ) !== 1 ) { throw new RuntimeException( 'O log atual exige um único diretório acessível deste site. Verifique o padrão de log.' ); }
			$arquivo = key( $pastas ) . '/access.log';
			if ( ! @is_file( $arquivo ) || ! @is_readable( $arquivo ) ) { throw new RuntimeException( 'Log atual ausente ou sem leitura: ' . $arquivo ); }
			$f = @fopen( $arquivo, 'rb' );
			if ( false === $f ) { throw new RuntimeException( 'Não foi possível abrir o log atual: ' . $arquivo ); }
			try {
				$stat = fstat( $f );
				if ( false === $stat || $stat['size'] > F3Base_Modulo_Acessos_Servidor::MAX_BYTES_ARQUIVO ) { throw new RuntimeException( 'Log atual excede o limite de 96 MiB ou não pode ser inspecionado. Use coleta externa para este volume.' ); }
				$restam = (int) $stat['size']; $agregados = array(); $caminhos = array(); $n = 0; $longa = false;
				$limite = (int) ini_get( 'max_execution_time' );
				$prazo = microtime( true ) + ( $limite > 0 ? max( 1, min( F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA, intdiv( $limite, 3 ) ) ) : F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA );
				while ( $restam > 0 ) {
					if ( microtime( true ) > $prazo ) { throw new RuntimeException( 'Leitura do log atual excedeu o tempo disponível. Use coleta externa para este volume.' ); }
					$bruta = fgets( $f, min( 32769, $restam + 1 ) );
					if ( false === $bruta ) { throw new RuntimeException( 'Log atual truncado ou leitura interrompida. Atualize novamente.' ); }
					$restam -= strlen( $bruta );
					if ( ! str_ends_with( $bruta, "\n" ) ) { $longa = true; continue; }
					++$n;
					if ( $longa ) { ++$saida['ignoradas']; $longa = false; continue; }
					$data = false;
					if ( preg_match( '~^\S+ \S+ \S+ \[([^\]]+)\] ~', $bruta, $m ) ) { $data = DateTimeImmutable::createFromFormat( '!d/M/Y:H:i:s O', $m[1] ); }
					$falhas = DateTimeImmutable::getLastErrors();
					if ( false === $data || ( $falhas && ( $falhas['warning_count'] || $falhas['error_count'] ) ) ) { ++$saida['ignoradas']; continue; }
					if ( $data->setTimezone( wp_timezone() )->format( 'Y-m-d' ) !== $saida['dia'] ) { continue; }
					$r = F3Base_Modulo_Acessos_Servidor::linha( $bruta, $c['caminhos_excluidos'] );
					if ( null === $r ) { ++$saida['ignoradas']; continue; }
					$a = $r['agente']; $p = $r['caminho'];
					if ( '' !== $p ) {
						if ( ! isset( $caminhos[ $a ][ $p ] ) && count( $caminhos[ $a ] ?? array() ) >= F3Base_Modulo_Acessos_Servidor::TETO_CAMINHOS_POR_DIA ) { $r['caminho'] = ''; $r['classe_caminho'] = 'outro'; }
						else { $caminhos[ $a ][ $p ] = true; }
					}
					$chave = wp_json_encode( array_slice( $r, 0, 5 ) );
					if ( isset( $agregados[ $chave ] ) ) { ++$agregados[ $chave ]['contagem']; } else { $agregados[ $chave ] = $r; }
					if ( count( $agregados ) > F3Base_Modulo_Acessos_Servidor::TETO_AGREGADOS ) { throw new RuntimeException( 'Teto de agregados do log atual excedido. Use coleta externa para este volume.' ); }
				}
				clearstatcache( true, $arquivo );
				$agora = @stat( $arquivo );
				if ( ! $agora || $agora['ino'] !== $stat['ino'] || $agora['dev'] !== $stat['dev'] || $agora['size'] < $stat['size'] || wp_date( 'Y-m-d' ) !== $saida['dia'] ) { throw new RuntimeException( 'Log atual rotacionado, truncado ou dia alterado durante a leitura. Atualize novamente.' ); }
				if ( $saida['ignoradas'] > $n / 2 ) { throw new RuntimeException( 'Formato do log atual não reconhecido na maioria das linhas.' ); }
				$saida['linhas'] = array_values( $agregados );
			} finally { fclose( $f ); }
		} catch ( Throwable $erro ) { $saida['erro'] = $erro->getMessage(); }
		return $saida;
	}
}
