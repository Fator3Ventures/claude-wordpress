<?php
/** Conversões de material: intenção, destinos e reservas independentes do contato. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Conversoes_Conteudo {
    const GA4='download_material';
    const META='MaterialDownload';
    public static function catalogo(array $c): array {
        $labels=array('ga4'=>'GA4 — evento de material','meta'=>'Meta — evento de material','google_ads'=>'Google Ads — conversão de material','linkedin'=>'LinkedIn — conversão de material');
        $sub=array();$props=array();foreach($labels as $key=>$label){$sub[$key]=array('tipo'=>'booleano','rotulo'=>$label,'descricao'=>'Ativa somente a conversão de material neste destino, respeitando consentimento, modo de teste e identificadores próprios.','impacto'=>'Desligado por padrão. Não reaproveita a conversão de contato.');$props[$key]=array('type'=>'boolean');}
        $schema=array('type'=>'object','additionalProperties'=>false,'properties'=>$props,'required'=>array_keys($labels));
        $c['f3base_conversoes_conteudo']=array('rotulo'=>'Conversões de material','descricao'=>'Escolha quais plataformas recebem o aceite de formulários do regime conteúdo. GA4: download_material; Meta: MaterialDownload. Google Ads e LinkedIn exigem a ação própria de material.','operavel'=>true,'secao'=>'medicao','campo'=>'grupo','autoload'=>false,'padrao'=>array_fill_keys(array_keys($labels),false),'subcampos'=>$sub,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>static function($v)use($labels){if(!is_array($v)||array_diff(array_keys($v),array_keys($labels))){return 'Informe os quatro destinos de material.';}foreach($labels as $k=>$unused){if(!isset($v[$k])||!is_bool($v[$k])){return 'Cada destino de material deve ser verdadeiro ou falso.';}}return '';});
        $c['f3base_google_ads']['padrao']['conteudo_conversion_label']='';
        $c['f3base_google_ads']['subcampos']['conteudo_conversion_label']=array('tipo'=>'texto','rotulo'=>'Rótulo da conversão de material','descricao'=>'Ação exclusiva para material, na mesma conta AW.','impacto'=>'Vazio ou com destino de material desligado, não envia conversão de material ao Google Ads. O rótulo de contato nunca serve de substituto.','exemplo'=>'Rótulo da ação Material na sua conta.');
        $c['f3base_linkedin_conteudo_conversion_id']=array('rotulo'=>'LinkedIn — conversão de material','descricao'=>'ID exclusivo da conversão de material.','operavel'=>true,'secao'=>'medicao','campo'=>'texto','autoload'=>false,'padrao'=>'','impacto'=>'Vazio ou com destino de material desligado, não envia conversão de material ao LinkedIn. O ID de contato nunca serve de substituto.','exemplo'=>'Somente os dígitos da ação Material no Campaign Manager.','sanitiza'=>array(F3Base_Options::class,'sanitiza_partner_id'),'schema_config'=>array('type'=>'string','pattern'=>'^[0-9]*$','maxLength'=>30),'schema_entrada'=>array('type'=>'string','pattern'=>'^[0-9]*$','maxLength'=>30),'recusa'=>static fn($v)=>is_string($v)&&preg_match('/^[0-9]{0,30}$/D',$v)?'':'Informe somente dígitos ou deixe vazio.');
        return $c;
    }
    public static function habilitado(string $destino): bool {return (F3Base_Options::ler('f3base_conversoes_conteudo')[$destino]??false)===true;}
    public static function publico(): array {return (array)F3Base_Options::ler('f3base_conversoes_conteudo')+array('ga4Event'=>self::GA4,'metaEvent'=>self::META,'adsLabel'=>F3Base_Options::ler('f3base_google_ads')['conteudo_conversion_label']??'','linkedinId'=>F3Base_Options::ler('f3base_linkedin_conteudo_conversion_id'));}
    public static function evento_meta(array $dados): string {return ($dados['metodo']??$dados['method']??'')==='conteudo'?self::META:'Lead';}
    public static function sessao(string $sessao,string $formulario): string {return substr(hash('sha256','material|'.$sessao.'|'.$formulario),0,32);}
    public static function migrar(): bool {
        global $wpdb;$a=F3Base_Aquisicoes::tabela();$l=F3Base_Leads_Repositorio::tabela();$q=F3Base_Capi_Fila::tabela();
        // Só a reserva antiga coincide com a sessão original: reexecução não gera novo domínio.
        if(false===$wpdb->query($wpdb->prepare("UPDATE %i a JOIN %i l ON l.record_id=a.record_id SET a.sessao=LEFT(SHA2(CONCAT('material|',l.sessao,'|',l.formulario),256),32) WHERE l.metodo='conteudo' AND a.sessao=l.sessao",$a,$l))){return false;}
        // Não transforma eventos históricos, nem reenvia os já aceitos. Suspende trabalho legado ainda não despachado.
        return false!==$wpdb->query($wpdb->prepare("UPDATE %i q JOIN %i l ON l.record_id=q.record_id SET q.estado='suspenso',q.motivo='evento_material_legado',q.reserva='' WHERE l.metodo='conteudo' AND q.evento_nome='Lead' AND q.estado IN ('pendente','suspenso','reservado') AND q.cancelado=0",$q,$l));
    }
}
