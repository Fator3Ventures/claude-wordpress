<?php
/** Optional local SDK. Public identifiers only; no network, visitor data or writes. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Conversoes_Contexto {
    public const CONTRATO='site-conversion-purposes/1.0.0';
    private static function resposta(string $code,?array $data=null): array {
        return array('ok'=>$code==='ok','code'=>$code,'contract'=>self::CONTRATO,'provider'=>'base-site-core-fator3','data'=>$data);
    }
    public static function capabilities(): array {
        return self::resposta('ok',array('contract_version'=>'1.0.0','schema_revision'=>'1','methods'=>array('capabilities','snapshot'),
            'capabilities'=>array('conversion.purposes.read'),'pagination'=>false,
            'schemas'=>array('capabilities'=>'docs/schemas/conversion-capabilities.json','snapshot_input'=>'docs/schemas/conversion-snapshot-input.json','snapshot'=>'docs/schemas/conversion-snapshot.json')));
    }
    public static function schema(string $name): array {
        if(!in_array($name,array('capabilities','snapshot-input','snapshot','ability-snapshot'),true)){return array();}
        $path=F3BASE_PLUGIN_DIR.'docs/schemas/conversion-'.$name.'.json';$data=is_readable($path)?json_decode((string)file_get_contents($path),true):null;
        return is_array($data)?$data:array();
    }
    /** Compare actual filter boundaries, rather than attributing every normalization to a filter. */
    private static function efetivo(string $name): array {
        $traces=array();$hooks=array('pre_option_'.$name,'pre_option','default_option_'.$name,'option_'.$name);$callbacks=array();
        foreach ($hooks as $hook) {
            $before=static function($v,...$args)use(&$traces,$hook,$name){
                if ($hook!=='pre_option'||($args[0]??null)===$name) { $traces[$hook]['before']=$v; } return $v;
            };
            $after=static function($v,...$args)use(&$traces,$hook,$name){
                if ($hook!=='pre_option'||($args[0]??null)===$name) { $traces[$hook]['after']=$v; } return $v;
            };
            add_filter($hook,$before,PHP_INT_MIN,3);add_filter($hook,$after,PHP_INT_MAX,3);$callbacks[$hook]=array($before,$after);
        }
        try { $value=F3Base_Options::ler($name); }
        finally { foreach ($callbacks as $hook=>$c) { remove_filter($hook,$c[0],PHP_INT_MIN);remove_filter($hook,$c[1],PHP_INT_MAX); } }
        $changed=false;
        foreach ($traces as $hook=>$trace) {
            if (!array_key_exists('before',$trace)||!array_key_exists('after',$trace)||$trace['before']===$trace['after']) { continue; }
            $after=$trace['after'];
            if (str_starts_with($hook,'pre_option') && $after===false) { continue; }
            if (F3Base_Options::equivalente(F3Base_Options::sanitizar($name,$after),$value)) { $changed=true; }
        }
        return array('value'=>$value,'filtered'=>$changed);
    }
    private static function procedencia(string $name,array $all): array {
        $f=$all['raw'][$name];$records=$all['raw'][F3Base_Options::OPTION_PROVENIENCIA]['valor'];$entry=is_array($records)?($records[$name]??null):null;
        $known=is_array($entry)&&in_array($entry['origem']??'',F3Base_Options::origens(),true);
        $confirmed=$known&&is_string($entry['revisao']??null)&&hash_equals($f['revisao'],$entry['revisao']);
        $expected=$f['existe']?F3Base_Options::sanitizar($name,$f['valor']):(F3Base_Options::declaracao($name)['padrao']??null);
        $different=!F3Base_Options::equivalente($expected,$all['effective'][$name]);$filtered=$different&&$all['filtered'][$name];
        return array('recorded_origin'=>$known?$entry['origem']:null,'channel'=>$known&&in_array($entry['canal']??null,array('php','ability','admin','cli','mcp'),true)?$entry['canal']:null,
            'recorded_at'=>$known&&!empty($entry['em'])&&is_numeric($entry['em'])?gmdate('c',(int)$entry['em']):null,
            'record_status'=>$confirmed?'confirmed':($entry!==null?'unconfirmed':($f['existe']?'unknown':'default')),
            'effective_source'=>$filtered?'filtered':($different?'unknown':($f['existe']?'configured':'default')),'changed_by_filter'=>$filtered?true:($different?null:false));
    }

    private static function fotografia(): array {
        $context=F3Base_Medicao_Contexto::snapshot();
        if(empty($context['ok'])){throw new RuntimeException($context['code']??'unreadable');}
        $all=array('raw'=>array(),'effective'=>array(),'filtered'=>array(),'revisions'=>array());
        foreach(array('f3base_conversoes_conteudo','f3base_google_ads','f3base_linkedin_conteudo_conversion_id',F3Base_Options::OPTION_PROVENIENCIA) as $name){
            $raw=F3Base_Options::fotografia_bruta($name);if($raw['erro']){throw new RuntimeException('unreadable');}
            $all['raw'][$name]=$raw;$all['revisions'][$name]=$raw['revisao'];
            if($name===F3Base_Options::OPTION_PROVENIENCIA){continue;}
            $effective=self::efetivo($name);$all['effective'][$name]=$effective['value'];$all['filtered'][$name]=$effective['filtered'];
        }
        $v=$all['effective'];$slots=$context['data']['slots'];$purposes=array();
        foreach(array('contact'=>'generate_lead','material'=>F3Base_Conversoes_Conteudo::GA4) as $purpose=>$event){
            $destinations=array();
            foreach(array('ga4','meta','google_ads','linkedin') as $target){
                $slot=$slots[$target];$ids=$slot['effective']['fields'];
                $provenance=array(array('field'=>'destination')+$slot['provenance']);
                $enabled=$slot['state']!=='disabled';
                if($purpose==='material'){
                    $enabled=$enabled&&($v['f3base_conversoes_conteudo'][$target]??false)===true;
                    $provenance[]=array('field'=>'enabled')+self::procedencia('f3base_conversoes_conteudo',$all);
                    if($target==='google_ads'){
                        $value=$v['f3base_google_ads']['conteudo_conversion_label']??'';
                        $ids['conversion_label']=is_string($value)&&strlen($value)<=F3Base_Options::TAMANHOS['tag_id']&&F3Base_Options::sanitiza_id_de_tag($value,'')===$value?$value:null;
                        $provenance[]=array('field'=>'conversion_label')+self::procedencia('f3base_google_ads',$all);
                    }elseif($target==='linkedin'){
                        $value=$v['f3base_linkedin_conteudo_conversion_id'];
                        $ids['conversion_id']=is_string($value)&&preg_match('/^[0-9]{0,30}$/D',$value)?$value:null;
                        $provenance[]=array('field'=>'conversion_id')+self::procedencia('f3base_linkedin_conteudo_conversion_id',$all);
                    }
                }
                $required=array('ga4'=>array('measurement_id'),'google_ads'=>array('conversion_id','conversion_label'),'linkedin'=>array('partner_id','conversion_id'),'meta'=>array($slot['emission']['transport']==='servidor'?'server_pixel_id':'pixel_id'))[$target];
                $configured=true;foreach($required as $key){if(!is_string($ids[$key]??null)||$ids[$key]===''){$configured=false;}}
                $destinations[$target]=array('enabled'=>$enabled,'configured'=>$configured,'identifiers'=>$ids,'provenance'=>$provenance);
            }
            $purposes[]=array('purpose'=>$purpose,'ga4_event'=>$event,'meta_event'=>$purpose==='material'?F3Base_Conversoes_Conteudo::META:'Lead','destinations'=>$destinations);
        }
        return array('data'=>array('scope'=>'site_configuration','measurement_revision'=>$context['data']['revision'],'runtime_verified'=>false,'remote_access_verified'=>false,'purposes'=>$purposes),'guard'=>$all['revisions']);
    }
    public static function snapshot(array $input=array()): array {
        $schema=self::schema('snapshot-input');if(!$schema){return self::resposta('unsupported');}
        if(is_wp_error(rest_validate_value_from_schema($input,$schema))){return self::resposta('invalid_input');}
        if($input['contract']!==self::CONTRATO){return self::resposta('unsupported');}
        try{
            $a=self::fotografia();$b=self::fotografia();if(!F3Base_Options::equivalente($a,$b)){return self::resposta('revision_conflict');}
            $data=$b['data'];$data['revision']=hash('sha256',(string)wp_json_encode(F3Base_Auditoria::ordenar($data)));
            if(array_key_exists('expected_revision',$input)&&!hash_equals($data['revision'],$input['expected_revision'])){return self::resposta('revision_conflict');}
            $data['observed_at']=gmdate('c');$out=self::resposta('ok',$data);$schema=self::schema('snapshot');
            return !$schema?self::resposta('unsupported'):(is_wp_error(rest_validate_value_from_schema($out,$schema))?self::resposta('unreadable'):$out);
        }catch(Throwable $e){return self::resposta($e instanceof RuntimeException&&$e->getMessage()==='revision_conflict'?'revision_conflict':'unreadable');}
    }
    public static function registrar(): void {
        if(!function_exists('wp_register_ability')){return;}
        F3Base_Servicos::registrar_ability('f3base/conversoes-contexto-ler',array('label'=>'Conversões por finalidade','description'=>'Leitura local opcional '.self::CONTRATO.'; contato e material separados, sem credenciais ou efeitos.','category'=>F3BASE_PREFIXO,
            'input_schema'=>self::schema('snapshot-input'),'output_schema'=>self::schema('ability-snapshot'),
            'execute_callback'=>static fn($input=array())=>current_user_can('manage_options')?self::snapshot($input):self::resposta('not_authorized'),
            'permission_callback'=>static fn()=>current_user_can('manage_options'),
            'meta'=>array('show_in_rest'=>true,'mcp'=>array('public'=>true,'type'=>'tool'),'annotations'=>array('readonly'=>true,'destructive'=>false,'idempotent'=>true))));
    }
}
