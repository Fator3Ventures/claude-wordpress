> Atualização 1.37.0: consulte RELEASE-1.37.0.md e PIPEDRIVE-1.37.md; base direta 1.36.0, contrato administrativo 8.2.0. Evidências atuais no relatório externo; provas históricas abaixo mantêm seu escopo original.

# Instruções do plugin

Leia DOCUMENTACAO.md, AGENTES-1.36.0.md e CONVERSOES-SDK-1.36.md. Documentos anteriores são históricos quando houver divergência. Normas comuns revisão 4.
