> Atualização 1.37.0: consulte RELEASE-1.37.0.md e PIPEDRIVE-1.37.md; base direta 1.36.0, contrato administrativo 8.2.0. Evidências atuais no relatório externo; provas históricas abaixo mantêm seu escopo original.

# Documentação do pacote

Índice vigente: DOCUMENTACAO.md. Leia RELEASE-1.36.0.md e AGENTES-1.36.0.md.
