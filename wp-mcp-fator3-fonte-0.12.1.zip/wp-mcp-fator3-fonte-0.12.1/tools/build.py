#!/usr/bin/env python3
"""Deterministic WordPress distribution; no third-party Python dependencies."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SILENCE = b'<?php\n// Silence is golden.\n'
STAMP = (2020, 1, 1, 0, 0, 0)


def version():
    value = (ROOT / 'VERSION').read_text().strip()
    if not re.fullmatch(r'\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?', value):
        raise ValueError('Invalid VERSION')
    return value


def inventory(source=None):
    source = source or ROOT / 'fontes/wp-mcp-fator3'
    manifest = json.loads((ROOT / 'tools/runtime-manifest.json').read_text())
    names = manifest['files']
    if len(names) != len(set(names)):
        raise ValueError('Duplicate manifest entry')
    result = {}
    for name in names:
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name:
            raise ValueError('Unsafe manifest entry: ' + name)
        file = source / name
        if file.is_symlink() or not file.is_file():
            raise ValueError('Required regular file missing: ' + name)
        result[name] = file.read_bytes()
    # Excluded development material stays in the source package. Unexpected
    # files in runtime directories fail rather than silently enter production.
    for file in source.rglob('*'):
        name = file.relative_to(source).as_posix()
        if file.is_symlink():
            raise ValueError('Symlink in source: ' + name)
        if not file.is_file():
            continue
        if name.split('/')[0] in {'tests', 'docs', 'maintenance'}:
            continue
        if name in {'README.md', 'CHANGELOG.md'}:
            continue
        if name not in result:
            raise ValueError('Unlisted runtime file: ' + name)
    main = result['wp-mcp-fator3.php'].decode()
    header = re.search(r'^ \* Version:\s+(\S+)', main, re.M)
    constant = re.search(r"define\( 'F3_MCP_FILES_VERSION', '([^']+)' \);", main)
    if not header or not constant or header[1] != version() or constant[1] != version():
        raise ValueError('VERSION, plugin header and constant must agree')
    if (source / 'README.md').read_text().splitlines()[0] != '# WP MCP Fator3 ' + version():
        raise ValueError('README version differs from VERSION')
    first_release = re.search(r'^## (\S+)', (source / 'CHANGELOG.md').read_text(), re.M)
    if not first_release or first_release[1] != version():
        raise ValueError('Changelog version differs from VERSION')
    directories = {PurePosixPath('.')}
    for name in result:
        directories.update(PurePosixPath(name).parents)
    for directory in directories:
        result.setdefault(str(directory / 'index.php'), SILENCE)
    return {manifest['root'] + '/' + n: data for n, data in sorted(result.items())}


def write_zip(destination, members):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            entry = zipfile.ZipInfo(name, STAMP)
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, data, compresslevel=9)


def audit(archive_path, expected=None):
    expected = inventory() if expected is None else expected
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(expected):
            raise ValueError('Archive inventory differs from runtime manifest')
        if archive.testzip() is not None:
            raise ValueError('Archive integrity error')
        for name, data in expected.items():
            if archive.read(name) != data:
                raise ValueError('Archive differs from source: ' + name)
    return {
        'version': version(), 'file': Path(archive_path).name,
        'bytes': Path(archive_path).stat().st_size,
        'sha256': hashlib.sha256(Path(archive_path).read_bytes()).hexdigest(),
        'files': len(expected),
        'php_files': sum(n.endswith('.php') for n in expected),
        'silence_indices': sum(d == SILENCE for d in expected.values()),
        'members_sha256': {n: hashlib.sha256(d).hexdigest() for n, d in expected.items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--audit', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    path = args.audit or args.out or ROOT / 'dist' / ('wp-mcp-fator3-' + version() + '.zip')
    if not args.audit:
        write_zip(path, inventory())
    report = audit(path)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'members_sha256'}))


if __name__ == '__main__':
    main()
