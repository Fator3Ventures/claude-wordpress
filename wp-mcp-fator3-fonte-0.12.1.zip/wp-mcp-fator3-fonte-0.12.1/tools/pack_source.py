#!/usr/bin/env python3
"""Build the current source package without labs or nested release archives."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
import build


def inventory():
    root = build.ROOT
    result = {}
    for item in ['VERSION', 'README.md', 'fontes', 'tools', 'docs', 'evidencias']:
        path = root / item
        if not path.exists():
            raise ValueError('Missing source item: ' + item)
        candidates = [path] if path.is_file() else path.rglob('*')
        for file in candidates:
            relative = file.relative_to(root)
            if '__pycache__' in relative.parts or file.suffix == '.pyc':
                continue
            if file.is_symlink():
                raise ValueError('Symlink in sources: ' + str(relative))
            if not file.is_file():
                continue
            if file.suffix in {'.zip', '.log', '.sqlite', '.sqlite3'} or file.name == 'fixture-private.json':
                raise ValueError('Laboratory/archive material in source: ' + str(relative))
            result['wp-mcp-fator3-fonte-' + build.version() + '/' + relative.as_posix()] = file.read_bytes()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    # Validate runtime and version consistency before packaging development files.
    build.inventory()
    destination = args.out or build.ROOT / 'dist' / ('wp-mcp-fator3-fonte-' + build.version() + '.zip')
    members = inventory()
    build.write_zip(destination, members)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() or set(archive.namelist()) != set(members):
            raise ValueError('Invalid source archive')
        if any(archive.read(name) != data for name, data in members.items()):
            raise ValueError('Source archive differs from working files')
    print(json.dumps({'version': build.version(), 'file': destination.name,
                      'files': len(members), 'bytes': destination.stat().st_size,
                      'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
