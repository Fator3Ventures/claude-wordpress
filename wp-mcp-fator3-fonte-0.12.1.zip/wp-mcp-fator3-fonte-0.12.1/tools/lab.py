#!/usr/bin/env python3
"""Standalone, disposable WordPress regression laboratory for the final ZIP."""
from pathlib import Path, PurePosixPath
import argparse
import base64
import concurrent.futures
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
import build

ROOT = Path(__file__).resolve().parents[1]
PRIMARY = '/wp-json/mcp/wp-mcp-fator3'
LEGACY = '/wp-json/mcp/wp-mcp-ultimate'


def extract(archive, destination):
    with zipfile.ZipFile(archive) as source:
        for member in source.infolist():
            name = PurePosixPath(member.filename)
            if name.is_absolute() or '..' in name.parts or '\\' in member.filename or (member.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Unsafe archive member')
        source.extractall(destination)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


class Client:
    def __init__(self, origin, checks, label):
        self.origin, self.checks, self.label = origin, checks, label
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

    def check(self, name, condition, detail=None):
        row = {'suite': self.label, 'test': name, 'pass': bool(condition)}
        if not condition:
            row['detail'] = detail
            print('FAIL', self.label, name, detail, flush=True)
        self.checks.append(row)

    def request(self, path, data=None, headers=None, method=None):
        headers = dict(headers or {})
        if isinstance(data, dict):
            data = urllib.parse.urlencode(data).encode()
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
        url = path if path.startswith('http') else self.origin + path
        if not url.startswith(self.origin + '/'):
            raise ValueError('Laboratory HTTP cannot leave its local origin')
        try:
            response = self.opener.open(urllib.request.Request(url, data=data, headers=headers, method=method), timeout=25)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            raw = response.read()
            try:
                parsed = json.loads(raw)
            except (ValueError, UnicodeDecodeError):
                parsed = {}
            return response.status, dict(response.headers), parsed, raw

    def rpc(self, path, method='tools/list', authorization=None, session=None, params=None):
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'}
        if authorization:
            headers['Authorization'] = authorization
        if session:
            headers.update({'Mcp-Session-Id': session, 'MCP-Protocol-Version': '2025-06-18'})
        return self.request(path, json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params or {}}).encode(), headers)

    def initialize(self, path, auth):
        code, headers, data, raw = self.rpc(path, 'initialize', auth, params={'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'f3-stable-lab','version':'1'}})
        return code, headers.get('Mcp-Session-Id'), data


def auths(fixture):
    basic = 'Basic ' + base64.b64encode((fixture['username'] + ':' + fixture['password']).encode()).decode()
    return basic, 'Bearer ' + fixture['token']


def smoke(client, fixture, full=True):
    basic, bearer = auths(fixture)
    cookie = '; '.join(k+'='+v for k,v in fixture['cookies'].items())
    for path in ['/', '/auth-fixture/', '/wp-json/']:
        code, _, _, _ = client.request(path)
        client.check('anonymous public ' + path, code == 200, code)
    for path in ['/', '/wp-json/wp/v2/types']:
        code, _, _, _ = client.request(path, headers={'Authorization':'Bearer invalid'})
        client.check('invalid Bearer on public ' + path, code == 200, code)
    code, _, _, _ = client.request('/', headers={'Cookie':cookie})
    client.check('logged-in home', code == 200, code)
    paths = [PRIMARY, LEGACY, '/index.php?rest_route=/mcp/wp-mcp-fator3', '/index.php?rest_route=/mcp/wp-mcp-ultimate']
    for path in paths:
        code, headers, _, _ = client.rpc(path)
        client.check('anonymous MCP challenge ' + path, code == 401 and 'resource_metadata=' in headers.get('WWW-Authenticate',''), code)
        client.check('MCP error is not cacheable ' + path, any(x in headers.get('Cache-Control','').lower() for x in ['no-store','no-cache']),headers.get('Cache-Control'))
        keys = ['bad_scope','bad_site','bad_resource','bad_payload'] if full else []
        for label, token in [('invalid','invalid')] + [(key, fixture[key]) for key in keys]:
            code, headers, _, _ = client.rpc(path, authorization='Bearer '+token)
            client.check(label + ' denied ' + path, code == 401 and 'resource_metadata=' in headers.get('WWW-Authenticate',''), code)
        for name, authorization in [('Basic', basic), ('legacy Bearer', bearer), ('bound Bearer','Bearer '+fixture['bound_token'])]:
            code, session, data = client.initialize(path, authorization)
            client.check(name + ' initialize ' + path, code == 200 and bool(session) and data.get('result',{}).get('serverInfo',{}).get('version') == build.version(), code)
            code, headers, data, _ = client.rpc(path, authorization=authorization, session=session)
            names = {t.get('name') for t in data.get('result',{}).get('tools',[])}
            expected = {'wp-mcp-ultimate-discover-abilities','wp-mcp-ultimate-get-ability-info','wp-mcp-ultimate-execute-ability'}
            client.check(name + ' three metatools ' + path, code == 200 and names == expected, code)
            client.check('MCP response is not cacheable ' + name + ' ' + path, any(x in headers.get('Cache-Control','').lower() for x in ['no-store','no-cache']), headers.get('Cache-Control'))
        # An authenticated call followed by an anonymous call must not replay it.
        code, headers, _, _ = client.rpc(path)
        client.check('anonymous after authenticated request remains denied ' + path, code == 401, code)
    for path in [PRIMARY+'?rest_route=/wp/v2/users/me', LEGACY+'?rest_route=/wp/v2/users/me', '/wp-json/wp/v2/users/me']:
        code, _, data, _ = client.request(path, headers={'Authorization':bearer})
        client.check('MCP scope excludes users/me ' + path, code == 401 and data.get('code') == 'rest_not_logged_in', code)
    for path in [PRIMARY+'?rest_route=/wp/v2/users', LEGACY+'?rest_route=/wp/v2/users']:
        code1, _, data1, _ = client.request(path)
        code2, _, data2, _ = client.request(path, headers={'Authorization':bearer})
        client.check('users override preserves anonymous representation ' + path, code1 == code2 and data1 == data2, code2)
        code, _, data, _ = client.request(path+'&context=edit', headers={'Authorization':bearer})
        client.check('users override denies edit context ' + path, code == 401 and data.get('code') == 'rest_forbidden_context', code)
    code, _, data, _ = client.request(PRIMARY, {'rest_route':'/wp/v2/users/me'}, {'Authorization':bearer})
    client.check('POST override has no MCP identity', code == 404 and data.get('code') == 'rest_user_invalid_id', code)
    for path in [PRIMARY+'-other', LEGACY+'/other']:
        code, _, _, _ = client.rpc(path, authorization=bearer)
        client.check('Similar route cannot use MCP token ' + path, code in [401,403,404], code)
    code, _, data, _ = client.request('/wp-admin/admin-ajax.php?action=heartbeat', headers={'Authorization':bearer})
    client.check('Bearer does not authorize admin AJAX', code in [200,400] and data.get('success') is not True, code)
    for path in [PRIMARY, LEGACY]:
        code, _, data, _ = client.rpc(path, authorization=basic, session=fixture['session'])
        client.check('Pre-existing session works ' + path, code == 200 and 'result' in data, code)
    code, session, _ = client.initialize(PRIMARY, bearer)
    code, _, data, _ = client.rpc(PRIMARY, 'tools/call', bearer, session, {'name':'wp-mcp-ultimate-discover-abilities','arguments':{}})
    discovered=data.get('result',{}).get('structuredContent',{}).get('abilities',[])
    client.check('Discover Abilities returns a catalog',code==200 and bool(discovered),code)
    code, _, data, _ = client.rpc(PRIMARY, 'tools/call', bearer, session, {'name':'wp-mcp-ultimate-get-ability-info','arguments':{'ability_name':'system/capabilities'}})
    detail=data.get('result',{}).get('structuredContent',{})
    client.check('Get Ability Info returns the schema',code==200 and detail.get('name')=='system/capabilities' and 'input_schema' in detail,code)
    code, _, data, _ = client.rpc(PRIMARY, 'tools/call', bearer, session, {'name':'wp-mcp-ultimate-execute-ability','arguments':{'ability_name':'system/capabilities','parameters':{}}})
    capabilities = data.get('result',{}).get('structuredContent',{}).get('data',{})
    client.check('Read ability executes through metatool', code == 200 and capabilities.get('success') is True and capabilities.get('plugin_version') == build.version(), code)
    admin_path='/wp-admin/tools.php?page=wp-mcp-fator3&tab=connection'
    code, headers, _, raw = client.request(admin_path, headers={'Cookie':cookie})
    if code == 302 and headers.get('X-Redirect-By') == 'Yoast SEO' and urllib.parse.urlparse(headers.get('Location','')).query == 'page=wpseo_installation_successful_free':
        welcome, _, _, _ = client.request(headers['Location'],headers={'Cookie':cookie})
        client.check('Yoast first activation welcome is handled',welcome == 200,welcome)
        code, headers, _, raw = client.request(admin_path,headers={'Cookie':cookie})
    client.check('Admin configuration page renders', code == 200 and b'f3-mcp-admin' in raw, code)


def oauth(client, fixture):
    _, bearer = auths(fixture)
    for path in [PRIMARY, LEGACY]:
        _, headers, _, _ = client.rpc(path)
        match = re.search(r'resource_metadata="([^"]+)"', headers.get('WWW-Authenticate',''))
        client.check('Resource metadata advertised ' + path, bool(match))
        if match:
            code, _, data, _ = client.request(match[1])
            client.check('Metadata resource matches ' + path, code == 200 and data.get('resource') == client.origin+path, code)
    code, _, data, _ = client.request('/wp-mcp-oauth/token', {'grant_type':'refresh_token','client_id':fixture['client_id'],'refresh_token':fixture['refresh'],'resource':client.origin+PRIMARY})
    client.check('Pre-existing refresh grant rotates', code == 200 and bool(data.get('access_token')), code)
    if data.get('access_token'):
        code, session, _ = client.initialize(PRIMARY, 'Bearer '+data['access_token'])
        client.check('Refreshed token authenticates', code == 200 and bool(session), code)
    verifier = 'A'*64
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
    params = {'client_id':fixture['client_id'],'redirect_uri':'http://127.0.0.1:49151/callback','response_type':'code','scope':'mcp','state':'f3-stable','code_challenge':challenge,'code_challenge_method':'S256','resource':client.origin+PRIMARY}
    cookie = '; '.join(k+'='+v for k,v in fixture['cookies'].items())
    code, _, _, raw = client.request('/wp-mcp-oauth/authorize?'+urllib.parse.urlencode(params), headers={'Cookie':cookie})
    nonce = re.search(rb'name="_wpnonce" value="([^"]+)"', raw)
    client.check('Consent page and nonce', code == 200 and bool(nonce), code)
    if not nonce:
        return
    code, headers, _, _ = client.request('/wp-mcp-oauth/authorize', params|{'_wpnonce':nonce[1].decode(),'wp_mcp_oauth_consent':'allow'}, {'Cookie':cookie})
    grant_code = urllib.parse.parse_qs(urllib.parse.urlparse(headers.get('Location','')).query).get('code',[''])[0]
    client.check('Consent issues authorization code', code == 302 and bool(grant_code), code)
    if not grant_code:
        return
    grant = {'grant_type':'authorization_code','code':grant_code,'client_id':fixture['client_id'],'redirect_uri':params['redirect_uri'],'code_verifier':verifier,'resource':client.origin+PRIMARY}
    code, _, data, _ = client.request('/wp-mcp-oauth/token', grant)
    client.check('PKCE exchange succeeds', code == 200 and bool(data.get('access_token')), code)
    if data.get('access_token'):
        code, session, _ = client.initialize(PRIMARY,'Bearer '+data['access_token'])
        client.check('PKCE access token authenticates', code == 200 and bool(session), code)
    code, _, data, _ = client.request('/wp-mcp-oauth/token', grant)
    client.check('Authorization code is single-use', code == 400 and data.get('error') == 'invalid_grant', code)


def distribution(client, archive):
    with zipfile.ZipFile(archive) as source:
        for name in source.namelist():
            if name.endswith('/index.php'):
                code, _, _, body = client.request('/wp-content/plugins/'+name[:-len('index.php')])
                client.check('Silent directory '+name, code == 200 and body == b'', code)
            if name.endswith(('.css','.js')):
                code, _, _, body = client.request('/wp-content/plugins/'+name)
                client.check('Asset bytes '+name, code == 200 and body == source.read(name), code)
    for name in ['tests/expected-abilities.json','tests/upstream/e2e/wp-auth.js','docs/INSTALACAO.md','README.md','CHANGELOG.md']:
        code, _, _, _ = client.request('/wp-content/plugins/wp-mcp-fator3/'+name)
        client.check('Removed development file '+name, code == 404, code)


def race(client, fixture, wp):
    basic, _ = auths(fixture)
    target = wp/'wp-content/f3-concurrent.txt'
    target.write_text('original')
    digest = hashlib.sha256(b'original').hexdigest()
    code, session, _ = client.initialize(PRIMARY,basic)
    def write(pair):
        path, content = pair
        c = Client(client.origin, [], 'worker')
        _, _, data, _ = c.rpc(path,'tools/call',basic,session,{'name':'wp-mcp-ultimate-execute-ability','arguments':{'ability_name':'files/write','parameters':{'path':str(target),'content':content,'expected_sha256':digest}}})
        return data.get('result',{}).get('structuredContent',{}).get('data',{})
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        results = list(pool.map(write,[(PRIMARY,'first'),(LEGACY,'second')]))
    client.check('Shared SHA-256 conflict across aliases', sum(r.get('success') is True for r in results)==1 and sum(r.get('error_code')=='file_conflict' for r in results)==1, [{'success':r.get('success'),'code':r.get('error_code')} for r in results])
    client.check('Winning content persisted', target.read_text() in ['first','second'])
    target.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--wordpress', type=Path, required=True)
    parser.add_argument('--sqlite', type=Path, required=True)
    parser.add_argument('--zip', type=Path, required=True)
    parser.add_argument('--baseline', type=Path, action='append', default=[])
    parser.add_argument('--extra-plugin', type=Path, action='append', default=[])
    parser.add_argument('--php', required=True)
    parser.add_argument('--php-ini')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    work = args.work.resolve()
    if work.exists() and any(work.iterdir()):
        parser.error('--work must be a new empty directory')
    work.mkdir(parents=True,exist_ok=True)
    (work/'.f3-disposable-lab').write_text('Disposable WordPress regression laboratory\n')
    extract(args.wordpress,work)
    wp = work/'wordpress'
    extract(args.sqlite,wp/'wp-content/plugins')
    extract(args.zip,wp/'wp-content/plugins')
    for path in args.extra_plugin:
        extract(path,wp/'wp-content/plugins')
    sqlite = wp/'wp-content/plugins/sqlite-database-integration'
    dropin = (sqlite/'db.copy').read_text().replace('{SQLITE_IMPLEMENTATION_FOLDER_PATH}',str(sqlite)).replace('{SQLITE_PLUGIN}','sqlite-database-integration/load.php')
    (wp/'wp-content/db.php').write_text(dropin)
    (wp/'wp-config.php').write_text('''<?php
define('WP_HOME',getenv('F3_TEST_ORIGIN'));define('WP_SITEURL',getenv('F3_TEST_ORIGIN'));
define('DB_NAME','f3_stable_lab');define('DB_USER','local');define('DB_PASSWORD','');define('DB_HOST','localhost');define('DB_CHARSET','utf8');define('DB_COLLATE','');
$table_prefix='f3stable_';
define('F3_STABLE_DISPOSABLE_LAB',true);define('F3_DELETE_POST_DISPOSABLE_LAB',true);
define('WP_DEBUG',true);define('WP_DEBUG_LOG',true);define('WP_DEBUG_DISPLAY',false);define('WP_DISABLE_FATAL_ERROR_HANDLER',true);
define('DISABLE_WP_CRON',true);define('WP_HTTP_BLOCK_EXTERNAL',true);define('WP_ENVIRONMENT_TYPE','local');define('FS_METHOD','direct');
define('AUTH_KEY','disposable-local-auth-key');define('SECURE_AUTH_KEY','disposable-local-secure-key');define('LOGGED_IN_KEY','disposable-local-login-key');define('NONCE_KEY','disposable-local-nonce-key');
if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';
''')
    mu = wp/'wp-content/mu-plugins'
    mu.mkdir(exist_ok=True)
    (mu/'f3-lab-offline.php').write_text("<?php add_filter('pre_wp_mail','__return_false');add_filter('pre_http_request',static function($r,$args,$url){return in_array(parse_url($url,PHP_URL_HOST),['127.0.0.1','localhost'],true)?$r:new WP_Error('lab_offline','External network disabled.');},1,3);")
    with socket.socket() as reservation:
        reservation.bind(('127.0.0.1',0))
        port = reservation.getsockname()[1]
    origin = 'http://127.0.0.1:'+str(port)
    php = [str(Path(args.php).resolve())]+(['-c',str(Path(args.php_ini).resolve())] if args.php_ini else [])
    env = os.environ.copy() | {'F3_LAB_ROOT':str(work),'F3_TEST_ORIGIN':origin,'PHP_CLI_SERVER_WORKERS':'4'}
    def cli(action,*params):
        process = subprocess.run(php+[str(ROOT/'tools/lab/fixture.php'),action]+[str(p) for p in params],env=env,capture_output=True,text=True,timeout=90)
        if process.returncode:
            raise RuntimeError('CLI '+action+' failed: '+process.stderr[-1800:])
        # Third-party activation may emit notices before the last JSON line.
        for line in reversed(process.stdout.splitlines()):
            if not line.startswith('F3_LAB_RESULT '):
                continue
            try:
                value = json.loads(line[len('F3_LAB_RESULT '):])
                if action == 'cleanup' and (work/'fixture-private.json').exists():
                    raise RuntimeError('Private fixture survived cleanup')
                return value
            except ValueError:
                pass
        raise RuntimeError('CLI '+action+' returned no JSON')
    environment = cli('install')
    checks, upgrades = [], []
    def contracts():
        result=subprocess.run(php+[str(ROOT/'tools/lab/auth-contracts.php')],env=env,capture_output=True,text=True,timeout=30)
        data=json.loads(result.stdout)
        for row in data['checks']:
            checks.append({'suite':'auth-contracts',**row})
        if result.returncode:
            print('FAIL auth-contracts',data['passed'],data['total'],flush=True)
    log = (work/'http-server.log').open('w')
    server = subprocess.Popen(php+['-S','127.0.0.1:'+str(port),'-t',str(wp),str(ROOT/'tools/lab/router.php')],env=env,stdout=log,stderr=log,start_new_session=True)
    try:
        for _ in range(100):
            try:
                with socket.create_connection(('127.0.0.1',port),.1):
                    break
            except OSError:
                time.sleep(.03)
        cli('prepare')
        fixture = json.loads((work/'fixture-private.json').read_text())
        client = Client(origin,checks,'clean-install')
        info = cli('inspect', ROOT/'fontes/wp-mcp-fator3/tests/expected-abilities.json')
        client.check('All 100 own abilities retained',info['abilities_present'] and info['expected_count']==100)
        contracts()
        smoke(client,fixture)
        oauth(client,fixture)
        distribution(client,args.zip)
        race(client,fixture,wp)
        cli('cleanup')
        for baseline in args.baseline:
            installed = cli('upgrade',baseline.resolve())
            before = cli('prepare')
            fixture = json.loads((work/'fixture-private.json').read_text())
            result = cli('upgrade',args.zip.resolve())
            info = cli('inspect',ROOT/'fontes/wp-mcp-fator3/tests/expected-abilities.json')
            client = Client(origin,checks,'upgrade-'+before['version'])
            client.check('WordPress native replacement',result['success'] and result['native_installer'] and info['version']==build.version())
            for key in ['state_preserved','options_preserved','backup_readable','application_password_present','abilities_present','tests_absent','docs_absent']:
                client.check(key,info[key])
            basic,bearer = auths(fixture)
            for path in [PRIMARY,LEGACY]:
                for name,authorization in [('Basic',basic),('Bearer',bearer)]:
                    code,session,data=client.initialize(path,authorization)
                    client.check('Existing '+name+' authenticates '+path,code==200 and bool(session),code)
                code,_,data,_=client.rpc(path,authorization=basic,session=fixture['session'])
                client.check('Existing session survives '+path,code==200 and 'result'in data,code)
            oauth(client,fixture)
            distribution(client,args.zip)
            upgrades.append({'from':before['version'],'to':info['version'],'native_installer':True,'state_preserved':info['state_preserved'],'options_preserved':info['options_preserved']})
            cli('cleanup')
        if args.extra_plugin:
            main_files=[]
            for extra in args.extra_plugin:
                with zipfile.ZipFile(extra)as package:
                    options=[n for n in package.namelist()if n.count('/')==1 and n.endswith('.php') and b'Plugin Name:' in package.read(n)[:8192]]
                    if len(options)!=1:raise ValueError('Cannot identify plugin entrypoint: '+extra.name)
                    main_files.append(options[0])
            activated=cli('activate',*main_files)
            cli('prepare');fixture=json.loads((work/'fixture-private.json').read_text())
            client=Client(origin,checks,'ecosystem')
            client.check('All supplied integration plugins active',all(activated.values()))
            if 'wp-super-cache/wp-cache.php' in main_files:
                cache=cli('enable-cache')
                environment['page_cache']=cache
                client.check('WP Super Cache enabled with real drop-in',cache['enabled'] and cache['super_cache'] and cache['dropin'])
                for _ in range(2):
                    client.request('/auth-fixture/')
                cached=list((wp/'wp-content/cache').rglob('*auth-fixture*'))
                client.check('Public fixture enters page cache',bool(cached))
            info=cli('inspect',ROOT/'fontes/wp-mcp-fator3/tests/expected-abilities.json')
            environment['integration_plugins']=info['active_plugins']
            smoke(client,fixture)
            oauth(client,fixture)
            race(client,fixture,wp)
            cli('invalidate')
            basic,bearer=auths(fixture)
            for path in [PRIMARY,LEGACY]:
                for label,authorization in [('revoked Basic',basic),('expired Bearer',bearer),('revoked Bearer','Bearer '+fixture['bound_token'])]:
                    code,_,_,_=client.rpc(path,authorization=authorization)
                    client.check(label+' denied '+path,code==401,code)
            cli('cleanup')
        debug=wp/'wp-content/debug.log'
        fatal_lines=[] if not debug.exists()else [line for line in debug.read_text(errors='replace').splitlines()if 'Fatal error' in line or 'Uncaught ' in line]
        Client(origin,checks,'runtime').check('No PHP fatal in this laboratory run',not fatal_lines,len(fatal_lines))
    except Exception as error:
        Client(origin,checks,'harness').check('Laboratory completed',False,type(error).__name__+': '+str(error)[-1800:])
    finally:
        try:cli('cleanup')
        except Exception:pass
        os.killpg(server.pid,signal.SIGTERM)
        server.wait(timeout=10)
        log.close()
    report={'version':build.version(),'installer_sha256':hashlib.sha256(args.zip.read_bytes()).hexdigest(),'environment':environment,
            'http_server':'PHP built-in, four workers','passed':sum(c['pass']for c in checks),'total':len(checks),'checks':checks,'upgrades':upgrades,
            'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [args.wordpress,args.sqlite,args.zip]+args.baseline+args.extra_plugin}}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k]for k in ['version','passed','total','environment']}))
    raise SystemExit(0 if report['passed']==report['total']else 1)


if __name__=='__main__':
    main()
