#!/usr/bin/env python3
"""Verify final distribution, bounded negative cases and baseline equivalence."""
from pathlib import Path
import argparse
import json
import re
import subprocess
import tempfile
import zipfile
import build


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zip', type=Path, required=True)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--php', required=True)
    parser.add_argument('--php-ini')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    checks = []

    def check(name, ok):
        checks.append({'test': name, 'pass': bool(ok)})

    expected = build.inventory()
    build.audit(args.zip, expected)
    check('Archive matches all allowed source files and generated indices', True)
    with tempfile.TemporaryDirectory(prefix='f3-package-') as temp:
        temp = Path(temp)
        build.write_zip(temp / 'again.zip', expected)
        check('Rebuild is byte-identical', args.zip.read_bytes() == (temp / 'again.zip').read_bytes())
        variants = {
            'missing_runtime': {n: d for n, d in expected.items() if not n.endswith('/includes/OAuth/BearerAuth.php')},
            'missing_index': {n: d for n, d in expected.items() if n != 'wp-mcp-fator3/index.php'},
            'test_added': expected | {'wp-mcp-fator3/tests/test.php': b'<?php'},
            'document_added': expected | {'wp-mcp-fator3/docs/private.md': b'fixture'},
            'modified_runtime': expected | {'wp-mcp-fator3/core/bootstrap.php': b'<?php'},
            'wrong_root': {n.replace('wp-mcp-fator3/', 'wrong/', 1): d for n, d in expected.items()},
        }
        for kind, members in variants.items():
            path = temp / (kind + '.zip')
            build.write_zip(path, members)
            try:
                build.audit(path, expected)
            except ValueError:
                check('Reject ' + kind, True)
            else:
                check('Reject ' + kind, False)
        php = [args.php] + (['-c', args.php_ini] if args.php_ini else [])
        syntax = []
        for name, data in expected.items():
            if name.endswith('.php'):
                process = subprocess.run(php + ['-l'], input=data, capture_output=True)
                syntax.append({'file': name, 'pass': process.returncode == 0})
        check('All distributed PHP passes syntax check', all(x['pass'] for x in syntax))
    with zipfile.ZipFile(args.baseline) as baseline:
        old = {n: baseline.read(n) for n in baseline.namelist() if not n.endswith('/')}
    old_main = old['wp-mcp-fator3/wp-mcp-fator3.php'].decode()
    old_version = re.search(r'^ \* Version:\s+(\S+)', old_main, re.M)[1]
    wanted_main = old_main.replace('Version:           ' + old_version, 'Version:           ' + build.version(), 1)
    wanted_main = wanted_main.replace("define( 'F3_MCP_FILES_VERSION', '" + old_version + "' );", "define( 'F3_MCP_FILES_VERSION', '" + build.version() + "' );", 1)
    check('Only header and version constant change in entrypoint', expected['wp-mcp-fator3/wp-mcp-fator3.php'] == wanted_main.encode())
    unchanged = [n for n, d in expected.items() if n != 'wp-mcp-fator3/wp-mcp-fator3.php' and d != build.SILENCE]
    check('All other executable files and assets match homologated rc.2', all(old.get(n) == expected[n] for n in unchanged))
    removed = sorted(set(old) - set(expected))
    check('Only tests removed from the rc.2 distribution', bool(removed) and all(n.startswith('wp-mcp-fator3/tests/') for n in removed))
    report = {
        'version': build.version(), 'baseline_version': old_version,
        'passed': sum(x['pass'] for x in checks), 'total': len(checks), 'checks': checks,
        'php_lint': {'passed': sum(x['pass'] for x in syntax), 'total': len(syntax), 'files': syntax},
        'unchanged_runtime_members': len(unchanged), 'removed_members': removed,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['version', 'passed', 'total', 'unchanged_runtime_members']}))
    raise SystemExit(0 if report['passed'] == report['total'] else 1)


if __name__ == '__main__':
    main()
