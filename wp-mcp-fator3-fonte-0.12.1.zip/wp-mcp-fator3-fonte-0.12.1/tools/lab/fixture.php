<?php
/** CLI fixtures for the isolated laboratory created by tools/lab.py. */
if (PHP_SAPI !== 'cli') exit(2);
define('DONOTCACHEPAGE', true);
$f3_lab_root = getenv('F3_LAB_ROOT');
if (!$f3_lab_root || !is_file($f3_lab_root . '/.f3-disposable-lab')) exit(2);
$f3_lab_action = $argv[1] ?? '';
if ($f3_lab_action === 'install') define('WP_INSTALLING', true);
$_SERVER['HTTP_HOST'] = parse_url(getenv('F3_TEST_ORIGIN'), PHP_URL_HOST) . ':' . parse_url(getenv('F3_TEST_ORIGIN'), PHP_URL_PORT);
$_SERVER['REQUEST_URI'] = '/';
require $f3_lab_root . '/wordpress/wp-load.php';
if (!defined('F3_STABLE_DISPOSABLE_LAB') || !F3_STABLE_DISPOSABLE_LAB) exit(2);
use WpMcpUltimate\OAuth\TokenStore;
use WpMcpUltimate\Server\Transport\Infrastructure\SessionManager;
use Fator3\McpFiles\StateStore;
if ($f3_lab_action !== 'install') wp_set_current_user(1);
$f3_lab_private = $f3_lab_root . '/fixture-private.json';
function output_fixture($value) { echo 'F3_LAB_RESULT ' . json_encode($value, JSON_UNESCAPED_SLASHES) . "\n"; }
try {
    if ($f3_lab_action === 'install') {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        if (!is_blog_installed()) wp_install('Fator3 stable lab', 'f3-lab-admin', 'lab@example.invalid', false, '', bin2hex(random_bytes(24)));
        wp_set_current_user(1);
        update_option('permalink_structure', '/%postname%/');
        update_option('active_plugins', ['wp-mcp-fator3/wp-mcp-fator3.php']);
        flush_rewrite_rules(false);
        wp_insert_post(['post_type'=>'page','post_title'=>'Auth fixture','post_name'=>'auth-fixture','post_status'=>'publish','post_content'=>'Public regression page.']);
        output_fixture(['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION]);
    } elseif ($f3_lab_action === 'upgrade') {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        ob_start();
        $upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
        $result = $upgrader->install($argv[2], ['overwrite_package'=>true,'clear_update_cache'=>false]);
        ob_end_clean();
        if (is_wp_error($result)) throw new RuntimeException($result->get_error_code() . ': ' . $result->get_error_message());
        if ($result !== true) throw new RuntimeException('Native WordPress installer failed');
        $header = get_plugin_data(WP_PLUGIN_DIR . '/wp-mcp-fator3/wp-mcp-fator3.php', false, false);
        output_fixture(['success'=>true,'version_on_disk'=>$header['Version'],'native_installer'=>true]);
    } elseif ($f3_lab_action === 'prepare') {
        if (is_file($f3_lab_private)) throw new RuntimeException('A private fixture already exists; clean it first');
        $app = WP_Application_Passwords::create_new_application_password(1, ['name'=>'F3 disposable upgrade fixture']);
        if (is_wp_error($app)) throw new RuntimeException($app->get_error_code());
        $user = wp_get_current_user(); $expires = time()+7200;
        $client = 'f3-stable-' . bin2hex(random_bytes(5));
        TokenStore::save_client($client, ['client_name'=>'F3 local regression','redirect_uris'=>['http://127.0.0.1:49151/callback'],'created'=>time()]);
        $data = ['version'=>F3_MCP_FILES_VERSION,'username'=>$user->user_login,'password'=>$app[0],'uuid'=>$app[1]['uuid'],'client_id'=>$client];
        $base = ['user_id'=>1,'client_id'=>$client,'scope'=>'mcp'];
        foreach (['token'=>$base,'bound_token'=>$base+['site_id'=>1,'resource'=>Fator3\McpFiles\ConnectionEndpoints::url()],
            'bad_scope'=>array_replace($base,['scope'=>'admin']),'bad_site'=>$base+['site_id'=>999],
            'bad_resource'=>$base+['resource'=>'https://foreign.example/mcp'],'bad_payload'=>array_replace($base,['scope'=>['mcp']])] as $key=>$payload) {
            $data[$key] = TokenStore::generate_token(); TokenStore::store_access_token($data[$key], $payload);
        }
        $data['refresh'] = TokenStore::generate_token(); TokenStore::store_refresh_token($data['refresh'], $base);
        $data['session'] = SessionManager::create_session(1, ['protocolVersion'=>'2025-06-18']);
        $data['auth_session'] = WP_Session_Tokens::get_instance(1)->create($expires);
        $data['logged_session'] = WP_Session_Tokens::get_instance(1)->create($expires);
        $data['cookies'] = [AUTH_COOKIE=>wp_generate_auth_cookie(1,$expires,'auth',$data['auth_session']),LOGGED_IN_COOKIE=>wp_generate_auth_cookie(1,$expires,'logged_in',$data['logged_session'])];
        update_option('f3_mcp_files_enabled', true); update_option('f3_mcp_db_writes', false);
        $target = WP_CONTENT_DIR . '/f3-upgrade-fixture.txt'; file_put_contents($target,'before');
        $write = wp_get_ability('files/write')->execute(['path'=>$target,'content'=>'after','expected_sha256'=>hash('sha256','before')]);
        if (is_wp_error($write) || empty($write['success']) || empty($write['backup_id'])) throw new RuntimeException('Cannot create backup fixture');
        $data['backup_id'] = $write['backup_id'];
        $data['state_hashes'] = [];
        foreach (['backups','backup-index','audit'] as $kind) foreach (glob(StateStore::directory($kind).'/*.php') ?: [] as $file) $data['state_hashes'][$file] = hash_file('sha256',$file);
        $data['options'] = ['f3_mcp_files_enabled'=>(bool)get_option('f3_mcp_files_enabled'),'f3_mcp_db_writes'=>(bool)get_option('f3_mcp_db_writes')];
        file_put_contents($f3_lab_private, json_encode($data)); chmod($f3_lab_private,0600);
        output_fixture(['version'=>$data['version'],'backup_created'=>true,'state_records'=>count($data['state_hashes'])]);
    } elseif ($f3_lab_action === 'inspect') {
        $data = json_decode(file_get_contents($f3_lab_private),true); $unchanged = true;
        foreach ($data['state_hashes'] as $file=>$hash) if (!is_file($file) || hash_file('sha256',$file)!==$hash) $unchanged = false;
        $options = true; foreach ($data['options'] as $key=>$value) if ((bool)get_option($key)!==$value) $options = false;
        $expected = json_decode(file_get_contents($argv[2]),true);
        $backup = Fator3\McpFiles\Backups::metadata($data['backup_id']);
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $plugins=[];foreach(get_option('active_plugins',[])as$file){$d=get_plugin_data(WP_PLUGIN_DIR.'/'.$file,false,false);$plugins[$file]=$d['Version'];}
        output_fixture(['version'=>F3_MCP_FILES_VERSION,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,
            'state_preserved'=>$unchanged,'options_preserved'=>$options,'backup_readable'=>!is_wp_error($backup)&&($backup['sha256']??'')===hash('sha256','before'),
            'abilities_present'=>!array_diff($expected,array_keys(wp_get_abilities())),'expected_count'=>count($expected),
            'active_plugins'=>$plugins,'tests_absent'=>!file_exists(F3_MCP_FILES_DIR.'tests'),'docs_absent'=>!file_exists(F3_MCP_FILES_DIR.'docs'),
            'application_password_present'=>WP_Application_Passwords::get_user_application_password(1,$data['uuid'])!==null]);
    } elseif ($f3_lab_action === 'activate') {
        require_once ABSPATH.'wp-admin/includes/plugin.php'; $results=[];
        foreach (array_slice($argv,2) as $plugin) {
            $r=activate_plugin($plugin); if(is_wp_error($r))throw new RuntimeException($plugin.': '.$r->get_error_code());
            $results[$plugin]=is_plugin_active($plugin);
        }
        output_fixture($results);
    } elseif ($f3_lab_action === 'enable-cache') {
        if (!function_exists('wp_cache_enable')) throw new RuntimeException('WP Super Cache is not active');
        wp_cache_enable();
        wp_super_cache_enable();
        wp_cache_setting('wp_cache_mod_rewrite', 0);
        wp_cache_setting('wp_cache_not_logged_in', 2);
        output_fixture(['enabled'=>(bool)$GLOBALS['cache_enabled'],'super_cache'=>(bool)$GLOBALS['super_cache_enabled'],
            'mode'=>'simple PHP','skip_logged_in'=>$GLOBALS['wp_cache_not_logged_in'],
            'dropin'=>is_file(WP_CONTENT_DIR.'/advanced-cache.php')]);
    } elseif ($f3_lab_action === 'invalidate') {
        $data=json_decode(file_get_contents($f3_lab_private),true);
        WP_Application_Passwords::delete_application_password(1,$data['uuid']);
        update_option('_transient_timeout_f3_mcp_oauth_at_'.hash('sha256',$data['token']),time()-60);
        delete_transient('f3_mcp_oauth_at_'.hash('sha256',$data['bound_token']));
        output_fixture(['revoked_password'=>true,'expired_token'=>true]);
    } elseif ($f3_lab_action === 'cleanup') {
        if(is_file($f3_lab_private)){
            $data=json_decode(file_get_contents($f3_lab_private),true);WP_Application_Passwords::delete_application_password(1,$data['uuid']);
            foreach (['auth_session','logged_session']as$key)WP_Session_Tokens::get_instance(1)->destroy($data[$key]);
            foreach (['token','bound_token','bad_scope','bad_site','bad_resource','bad_payload']as$key)delete_transient('f3_mcp_oauth_at_'.hash('sha256',$data[$key]));
            delete_transient('f3_mcp_oauth_rt_'.hash('sha256',$data['refresh']));
            $clients=get_option('f3_mcp_oauth_clients',[]);unset($clients[$data['client_id']]);update_option('f3_mcp_oauth_clients',$clients,false);
            SessionManager::delete_session(1,$data['session']);unlink($f3_lab_private);
        }
        output_fixture(['cleanup'=>true]);
    } else throw new RuntimeException('Unknown action');
} catch (Throwable $error) {
    fwrite(STDERR, get_class($error).': '.$error->getMessage()."\n"); exit(1);
}
