<?php
if(PHP_SAPI!=='cli')exit(2);
define('DONOTCACHEPAGE',true);
$f3_lab_root=getenv('F3_LAB_ROOT');
if(!$f3_lab_root||!is_file($f3_lab_root.'/.f3-disposable-lab'))exit(2);
$_SERVER['HTTP_HOST']=parse_url(getenv('F3_TEST_ORIGIN'),PHP_URL_HOST).':'.parse_url(getenv('F3_TEST_ORIGIN'),PHP_URL_PORT);
$_SERVER['REQUEST_URI']='/';
require $f3_lab_root.'/wordpress/wp-load.php';
if(!defined('F3_STABLE_DISPOSABLE_LAB')||!F3_STABLE_DISPOSABLE_LAB)exit(2);
use WpMcpUltimate\OAuth\BearerAuth as Auth;
use Fator3\McpFiles\{ConnectionEndpoints as E,ConnectionStatus as S};
$fixture=json_decode(file_get_contents($f3_lab_root.'/fixture-private.json'),true);$checks=[];
function check_auth($name,$ok){global$checks;$checks[]=['test'=>$name,'pass'=>(bool)$ok];}
check_auth('no determine_current_user callback',has_filter('determine_current_user',[Auth::class,'authenticate'])===false);
check_auth('REST priority retained',has_filter('rest_authentication_errors',[Auth::class,'authenticate_rest'])===95);
check_auth('legacy callback is inert',Auth::authenticate(false)===false&&Auth::authenticate(17)===17);
$_SERVER['HTTP_AUTHORIZATION']='Bearer '.$fixture['token'];
$guard=static function($url){if(doing_filter('determine_current_user'))throw new RuntimeException('MCP reentered URL resolution while determining user');return$url;};add_filter('rest_url',$guard);
unset($GLOBALS['current_user']);$user=wp_get_current_user();check_auth('early user resolution does not invoke REST URLs',$user->ID===0);remove_filter('rest_url',$guard);
S::snapshot();$_SERVER['REQUEST_URI']='/wp-json/mcp/wp-mcp-fator3';$_GET=$_POST=[];wp_set_current_user(0);
check_auth('direct call outside REST filter is inert',Auth::authenticate_rest(null)===null&&get_current_user_id()===0);
$call=static fn($result=null)=>apply_filters('rest_authentication_errors',$result);
$error=new WP_Error('other_auth_failure','Preserve original failure',['status'=>403]);check_auth('prior auth error retained',$call($error)===$error);check_auth('prior successful auth retained',$call(true)===true);check_auth('prior false result retained',Auth::authenticate_rest(false)===false);
// REST endpoint filters legitimately inspect capabilities; current user is ready.
$count=0;$endpoints=static function($routes)use(&$count){$count++;current_user_can('edit_posts');return$routes;};add_filter('rest_endpoints',$endpoints);$result=$call();check_auth('user-dependent endpoint filter authenticates once',$result===true&&get_current_user_id()===1&&$count>0&&$count<8);remove_filter('rest_endpoints',$endpoints);
// Explicit re-entry is ignored; outer authentication completes normally.
wp_set_current_user(0);$nested=0;$hook=static function($url)use(&$nested){$nested++;apply_filters('rest_authentication_errors',null);return$url;};add_filter('rest_url',$hook);$r=$call();remove_filter('rest_url',$hook);check_auth('nested authentication cannot recurse',$r===true&&get_current_user_id()===1&&$nested>0&&$nested<20);
wp_set_current_user(0);$throw=static function(){throw new RuntimeException('deliberate test exception');};add_filter('rest_url',$throw);$caught=false;try{$call();}catch(RuntimeException$e){$caught=true;}remove_filter('rest_url',$throw);$r=$call();check_auth('guard resets after exception',$caught&&$r===true&&get_current_user_id()===1);
wp_set_current_user(0);$_SERVER['HTTP_AUTHORIZATION']='';$_SERVER['REDIRECT_HTTP_AUTHORIZATION']='Bearer '.$fixture['token'];$r=$call();check_auth('FastCGI redirected authorization works',$r===true&&get_current_user_id()===1);unset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']);
foreach(['Bearer ','Bearer bad token',"Bearer bad\r\nX-Header: value",['Bearer invalid'],str_repeat('x',9000)]as$header){wp_set_current_user(0);$_SERVER['HTTP_AUTHORIZATION']=$header;$call();check_auth('malformed header ignored without identity',get_current_user_id()===0);}
$_SERVER['HTTP_AUTHORIZATION']='Bearer '.$fixture['bad_payload'];wp_set_current_user(0);$call();check_auth('malformed payload denied without TypeError',get_current_user_id()===0);
// Ownership is checked against the effective registry, even for exact aliases.
$_SERVER['HTTP_AUTHORIZATION']='Bearer '.$fixture['token'];
foreach(['foreign','missing']as$mode){
 wp_set_current_user(0);$change=static function($routes)use($mode){if($mode==='missing')unset($routes[E::PRIMARY]);else foreach($routes[E::PRIMARY]as&$endpoint)if(is_array($endpoint)&&isset($endpoint['callback']))$endpoint['callback']='__return_true';return$routes;};
 add_filter('rest_endpoints',$change,100);$call();remove_filter('rest_endpoints',$change,100);check_auth($mode.' endpoint cannot gain MCP identity',get_current_user_id()===0);
}
wp_set_current_user(1);$expected=json_decode(file_get_contents(__DIR__.'/../../fontes/wp-mcp-fator3/tests/expected-abilities.json'),true);check_auth('all 100 existing abilities retained',count($expected)===100&&!array_diff($expected,array_keys(wp_get_abilities())));
$s=S::snapshot();check_auth('both routes retain same transport',rest_get_server()->get_routes()[E::PRIMARY][0]['callback']===rest_get_server()->get_routes()[E::LEGACY][0]['callback']);
$r=['passed'=>count(array_filter($checks,fn($x)=>$x['pass'])),'total'=>count($checks),'checks'=>$checks];echo wp_json_encode($r,JSON_PRETTY_PRINT);exit($r['passed']===$r['total']?0:1);
