<?php
// Router for PHP's local development server, never included in the plugin ZIP.
$root = rtrim($_SERVER['DOCUMENT_ROOT'], '/');
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/');
$file = realpath($root . $path);
if ($file && str_starts_with($file, $root . '/') && is_file($file)) return false;
if ($file && str_starts_with($file, $root . '/') && is_dir($file) && is_file($file.'/index.php')) { require $file.'/index.php'; return true; }
// Static plugin paths use a real missing-file response instead of WordPress's
// canonical URL guessing. Existing files above remain directly testable.
if (str_starts_with($path, '/wp-content/plugins/')) { http_response_code(404); return true; }
require $root . '/index.php';
