# WP MCP Fator3 0.12.1 — fontes

Versão estável baseada na **0.12.1-rc.2 homologada pelo usuário**. O instalador mantém o comportamento funcional da base, com novo número de versão e exclusão dos arquivos de testes da instalação pública.

## Pacotes e instalação

Instale `wp-mcp-fator3-0.12.1.zip` pelo painel do WordPress, escolhendo substituir o plugin atual. Este pacote de fontes não é o ZIP instalável. O guia completo está em [docs/ATUALIZACAO.md](docs/ATUALIZACAO.md).

A URL principal continua `/wp-json/mcp/wp-mcp-fator3`; o alias `/wp-json/mcp/wp-mcp-ultimate` permanece funcional. São preservados os três metatools e as 100 abilities próprias. Leia o [README do plugin](fontes/wp-mcp-fator3/README.md) para requisitos e comportamento.

## Estrutura

| Caminho | Conteúdo |
|---|---|
| `VERSION` | Número da versão corrente, conferido pelo build |
| `fontes/wp-mcp-fator3/` | Código, licença, changelog e testes de desenvolvimento |
| `tools/build.py` | Build determinístico e auditoria do instalador |
| `tools/runtime-manifest.json` | Lista explícita de arquivos de execução |
| `tools/check_package.py` | Comparação com a rc.2, testes negativos e lint PHP |
| `tools/lab.py` | Laboratório WordPress descartável, HTTP, OAuth, upgrade e integração |
| `tools/lab/` | Fixtures, contratos de autenticação e roteador local |
| `tools/pack_source.py` | Empacotamento determinístico das fontes |
| `docs/` | Plano, atualização, validação e referência ao histórico |
| `evidencias/` | Resultados desta rodada, com ambiente e hashes |

## Gerar o instalador

Requer Python 3.10+ com biblioteca padrão. Execute na raiz deste pacote:

```bash
python3 tools/build.py --out dist/wp-mcp-fator3-0.12.1.zip --report evidencias/installer.json
python3 tools/build.py --audit dist/wp-mcp-fator3-0.12.1.zip
```

A pasta `dist/` é criada pelo comando; não integra o pacote de fontes. O build seleciona os arquivos do manifesto, gera índices de silêncio nos diretórios distribuídos e fixa ordem, permissões e datas do ZIP. Testes, documentos e ferramentas não entram no instalador. Arquivos inesperados nos diretórios de execução ou arquivos obrigatórios ausentes interrompem o build.

`VERSION`, cabeçalho PHP, constante de versão, README e primeira entrada do changelog devem concordar. Em futuras versões, atualize-os em conjunto; a auditoria rejeita inconsistências. Os nomes dos artefatos padrão são derivados de `VERSION`.

## Auditar pacote e equivalência à base

Requer PHP com as extensões da instalação WordPress. Informe o executável real em `PHP_BIN` e o ZIP original em `RC2_ZIP`:

```bash
python3 tools/check_package.py --zip dist/wp-mcp-fator3-0.12.1.zip \
  --baseline "$RC2_ZIP" --php "$PHP_BIN" --out evidencias/package.json
```

Use `--php-ini /caminho/php.ini` se necessário. A comparação permite exatamente a mudança de cabeçalho e constante no arquivo principal. Os demais arquivos de execução e assets devem coincidir byte a byte com a rc.2. A suíte verifica a reconstrução e rejeita seis pacotes deliberadamente inválidos.

## Laboratório autônomo

Insumos externos: ZIP do WordPress, ZIP do SQLite Database Integration para o banco descartável e um PHP com `pdo_sqlite`, `sqlite3`, `mysqli`, `mbstring`, DOM/XML, cURL e as demais extensões exigidas pelo WordPress. Python não precisa de pacotes externos. A rodada desta entrega usou Linux; o teste concorrente usa os quatro workers do servidor PHP local.

Defina `WP_ZIP`, `SQLITE_ZIP` e `PHP_BIN` com caminhos absolutos. `--work` deve apontar para uma pasta nova e vazia:

```bash
python3 tools/lab.py --work /tmp/f3-mcp-stable-lab \
  --wordpress "$WP_ZIP" --sqlite "$SQLITE_ZIP" \
  --zip dist/wp-mcp-fator3-0.12.1.zip --php "$PHP_BIN" \
  --out evidencias/http.json
```

Esse comando funciona sem Core, cache ou Yoast. Instala o ZIP final em WordPress real, cria apenas dados locais descartáveis, bloqueia e-mail/requisições externas do WordPress e exercita o canal via HTTP. O servidor escuta somente em `127.0.0.1` e é encerrado ao terminar. As credenciais temporárias não entram no relatório; os insumos de laboratório não integram o instalador nem as fontes.

Para reproduzir também os três upgrades, acrescente os instaladores originais:

```bash
python3 tools/lab.py --work /tmp/f3-mcp-upgrade-lab \
  --wordpress "$WP_ZIP" --sqlite "$SQLITE_ZIP" \
  --zip dist/wp-mcp-fator3-0.12.1.zip --php "$PHP_BIN" \
  --baseline "$MCP_0120_ZIP" --baseline "$MCP_RC1_ZIP" --baseline "$RC2_ZIP" \
  --out evidencias/http-upgrade.json
```

O runner utiliza `Plugin_Upgrader` do WordPress com substituição de pacote, cria as credenciais antes de cada atualização e verifica o estado depois. Instala cada base pelo mesmo mecanismo antes de promover para a estável. Não usa sobreposição de arquivos como prova de upgrade.

Para a integração adicional, acrescente ao comando:

```bash
--extra-plugin "$CORE_ZIP" --extra-plugin "$SUPER_CACHE_ZIP" --extra-plugin "$YOAST_ZIP"
```

As versões usadas estão no relatório. O runner identifica o arquivo principal de cada plugin, ativa-os no laboratório e habilita o WP Super Cache no modo PHP simples, ignorando usuários logados. Confere cache de página pública e autenticação/respostas protegidas. Não altera configurações de hospedagem ou plugins em produção.

## Reproduzir o pacote de fontes

```bash
python3 tools/pack_source.py --out dist/wp-mcp-fator3-fonte-0.12.1.zip
```

Não entram `dist/`, laboratórios, runtimes, caches de Python nem cópias históricas aninhadas. As evidências JSON da rodada ficam junto à suíte; uma nova execução pode substituí-las com os seus resultados.

## Cobertura e histórico

[Validação desta entrega](docs/VALIDACAO.md) distingue os testes executados agora da homologação informada pelo usuário. [Histórico](docs/HISTORICO.md) identifica os ZIPs originais e seus hashes. Os scripts antigos em [tests/](fontes/wp-mcp-fator3/tests/README.md) continuam disponíveis como regressões específicas, com seus limites documentados.
