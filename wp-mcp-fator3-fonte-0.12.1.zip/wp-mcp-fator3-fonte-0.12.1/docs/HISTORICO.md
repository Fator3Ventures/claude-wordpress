# Histórico e proveniência

A base desta entrega é a rc.2 homologada pelo usuário. O histórico completo, com fontes, relatórios da rc.1 e scripts de integração anteriores, permanece no artefato original `wp-mcp-fator3-fonte-0.12.1-rc.2.zip`, entregue separadamente e preservado sem alterações. Ele não é necessário para reconstruir o instalador estável; serve como referência e como insumo para comparações de regressão.

| Artefato preservado | SHA-256 |
|---|---|
| wp-mcp-fator3-fonte-0.12.1-rc.2.zip | 2959c5c2ebdf9d23252aa19bd685f7b82bef740b57a2e11f2cc45011a7385dfc |
| wp-mcp-fator3-0.12.1-rc.2.zip | d40fe539256566d3623a6a734cf6ebbc8bedda5628f333537cc558e712146ecf |

Foram retiradas do pacote de fontes corrente as cópias aninhadas de fontes antigas, evidências históricas repetidas e workflows/scripts de rodadas anteriores dependentes do Core. Os testes úteis continuam em fontes/wp-mcp-fator3/tests; a suíte corrente está em tools/. O changelog preserva a evolução funcional e os créditos/licenças permanecem no código e em LICENSE.

Os relatórios históricos descrevem apenas suas próprias rodadas. A pendência de homologação registrada na rc.1/rc.2 foi encerrada pela confirmação do usuário. O relatório da 0.12.1 separa essa confirmação dos novos testes de regressão locais.
