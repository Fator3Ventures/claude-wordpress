# WP MCP Fator3 0.12.1 — relatório de entrega

**Data:** 21/09/2026  
**Status:** versão estável construída e validada localmente.  
**Base:** 0.12.1-rc.2 homologada pelo usuário.  
**Instalador validado:** `wp-mcp-fator3-0.12.1.zip`.

## Resultado

Implementado o plano aprovado. O instalador final preserva o código funcional da rc.2, os assets, as 100 abilities próprias, os três metatools e as duas URLs de conexão. O arquivo principal muda exatamente o cabeçalho e a constante de versão para 0.12.1. Nenhuma instalação em produção foi realizada nesta entrega.

A homologação da rc.2 é a confirmação fornecida pelo usuário. Os resultados abaixo são de uma nova rodada local sobre o ZIP final; não incluem como novos os 253 testes da rc.1, os 13 cenários anexados à rc.2 nem números de outras versões do Core.

## Alterações implementadas

| Item do plano | Entrega |
|---|---|
| F3-01 | Base original identificada por hash; manifesto e comparação exata dos arquivos |
| F3-02 | Remoção dos 15 membros de `tests/` do instalador; testes preservados nas fontes |
| F3-03 | Build determinístico, auditoria de conteúdo e seis casos negativos de pacote |
| F3-04 | README, changelog, atualização e comandos autônomos de reprodução corrigidos |
| F3-05 | Laboratório parametrizado de WordPress real e matriz do canal no ZIP final |
| F3-06 | Homologação da rc.2 registrada como concluída, conforme o usuário |
| F3-07 | Substituição por `Plugin_Upgrader` e preservação de credenciais, sessão, opções e acervo |
| F3-08 | Integração com Core 1.9.1, WP Super Cache 3.1.3 e Yoast 28.4, todos ativos |
| F3-09 | Fontes correntes sem árvores históricas aninhadas; original da rc.2 preservado e referenciado |

O pacote tem **159 arquivos**, dos quais **156 PHP**, e **45 índices de silêncio**. A rc.2 tinha 48 índices; três pertenciam à árvore de testes retirada. Licença, autoload, views, classes, CSS e JavaScript permanecem. Os **113 arquivos de execução/assets/licença**, excetuado o arquivo principal e os índices gerados, coincidem byte a byte com a rc.2. O diff do arquivo principal foi conferido sem normalização genérica de strings.

## Verificações executadas

| Conjunto | Aprovadas/total |
|---|---:|
| Auditoria, reconstrução e testes negativos do pacote | 12/12 |
| Sintaxe de todos os PHP distribuídos | 156/156 |
| Instalação limpa: HTTP, OAuth, catálogo, arquivos e concorrência | 157/157 |
| Contratos PHP de autenticação e inicialização | 22/22 |
| Atualização nativa 0.12.0 → 0.12.1 | 77/77 |
| Atualização nativa rc.1 → 0.12.1 | 77/77 |
| Atualização nativa rc.2 → 0.12.1 | 77/77 |
| Core + WP Super Cache + Yoast, com cache ativo | 114/114 |
| Ausência de fatal PHP na execução final | 1/1 |
| **Total da suíte de integração/HTTP/contratos** | **525/525** |

As contagens de lint são apresentadas separadamente; a auditoria do pacote inclui um critério agregado para esse lint. O total de integração inclui testes CLI de estado e de contratos, além das requisições HTTP.

Foram verificados: páginas públicas e home logada; configurações administrativas; Bearer inválido, expirado, revogado ou com vínculo incorreto; Basic por senha de aplicação; sessão anterior à atualização; OAuth com consentimento, PKCE, código de uso único e refresh; duas URLs e formato `rest_route`; tentativas de desviar o token MCP para a API comum; rota semelhante, ausente ou pertencente a callback de terceiro; consulta antecipada de usuário, reentrada e recuperação da guarda após exceção; catálogo e execução de leitura; arquivos removidos, assets e índices; gravações simultâneas através dos dois aliases.

Em cada upgrade, o runner criou credenciais e uma sessão na versão de origem, substituiu o plugin pelo instalador nativo e reutilizou o estado. Foram preservados senha de aplicação, Bearer, cliente/refresh OAuth, sessão MCP, preferências, backup legível e hashes dos registros de backup/auditoria existentes. O diretório atualizado ficou sem testes e documentos de desenvolvimento. Duas gravações concorrentes com o mesmo `expected_sha256` produziram uma gravação aceita e um `file_conflict` identificável.

Na integração, o WP Super Cache gerou cache para a página pública de teste. Respostas MCP válidas e de erro mantiveram cabeçalhos de não armazenamento/cache; uma chamada anônima posterior à autenticada continuou recusada. Foi tratado o redirecionamento único do Yoast para sua tela de instalação bem-sucedida antes de conferir novamente a tela do Fator3. Nenhuma mudança funcional do MCP foi necessária.

## Ambiente e limites

- WordPress **7.1** e PHP **8.3.6**, em Linux, com quatro workers do servidor HTTP local do PHP.
- SQLite Database Integration **3.0.2** apenas como banco do laboratório.
- Base Site Core Fator3 **1.9.1**, WP Super Cache **3.1.3** e Yoast **28.4** na etapa de convivência.
- WP Super Cache habilitado em modo PHP simples, com drop-in real e sem cache para usuários logados (`wp_cache_not_logged_in=2`).
- Requisições externas e e-mail do WordPress bloqueados. O laboratório não reproduz CDN, proxy reverso, cache de objeto externo, Apache/Nginx, MySQL, multisite ou todas as configurações de hospedagem.

O roteador de laboratório serve arquivos existentes, executa `index.php` nos diretórios e responde 404 para caminhos estáticos de plugin inexistentes, evitando a adivinhação de URLs canônicas do WordPress. A prova dos índices vale para essa configuração; não certifica o `DirectoryIndex` de uma hospedagem específica. Um índice vazio não bloqueia acesso direto a outros arquivos existentes.

Não foi repetida a matriz de ambiente mínimo WordPress 6.7/PHP 8.0 nem a combinação completa do incidente com Elementor, PRO Elements e gladdia. O plano permite reaproveitar a base homologada para alterações de empacotamento; os arquivos funcionais foram comprovadamente preservados. Essas combinações não constituem nova pendência de homologação nesta entrega. A interface foi validada por HTTP, sem nova revisão visual em navegador.

Durante a preparação da suíte, foram corrigidos problemas do próprio laboratório: colisão de variável com o bootstrap WordPress, tratamento de tipos de opções, isolamento do cache nas fixtures CLI, resposta para arquivos estáticos ausentes e redirecionamento inicial do Yoast. Os resultados finais acima pertencem à execução concluída com a suíte corrigida; tentativas interrompidas não foram somadas.

## Instalação e conexão

Envie **wp-mcp-fator3-0.12.1.zip** em **Plugins → Adicionar plugin → Enviar plugin** e escolha **Substituir o atual pelo enviado**. Mantenha o plugin ativo. Não use a exclusão/desinstalação do Fator3 como método de atualização.

| Uso | URL padrão mantida |
|---|---|
| Principal | `https://seu-dominio/wp-json/mcp/wp-mcp-fator3` |
| Compatibilidade | `https://seu-dominio/wp-json/mcp/wp-mcp-ultimate` |

O slug `wp-mcp-fator3` e o arquivo `wp-mcp-fator3.php` permanecem. Conectores existentes podem continuar com suas credenciais e URL. Em instalação por query ou subdiretório, copie a URL efetiva do painel. O guia `docs/ATUALIZACAO.md`, incluído nas fontes, cobre confirmação da atualização, migração antiga e recuperação para a rc.2.

## Rastreabilidade e reprodução

SHA-256 do instalador final:

`ef18f3ac5e18b89362ada4386b5397060cf8714faba44c2c7de32e3156353a53`

Tamanho: **273573 bytes**. Os relatórios `evidencias/installer.json`, `package.json`, `http.json` e `provenance.json` incluem inventário, hashes, casos individuais, ambiente e resultados. Não incluem credenciais nem logs HTTP brutos. O README das fontes documenta os comandos de build, auditoria e laboratório; os scripts recebem os insumos externos por parâmetro. WordPress, SQLite, PHP e os plugins de integração não são redistribuídos neste pacote de fontes.

| Insumo da rodada | SHA-256 |
|---|---|
| `wordpress.zip` | `d1ae02b5ae18428031ffc3943659fa87ab361d827f4aa804adf9276e4dc75df6` |
| `sqlite.zip` | `1602e75577ad9b3a7e3e4a6a44a81b9541cdee2124d48928faf61c6fd3cd4f74` |
| `wp-mcp-fator3-0.12.1.zip` | `ef18f3ac5e18b89362ada4386b5397060cf8714faba44c2c7de32e3156353a53` |
| `wp-mcp-fator3-0.12.0.zip` | `29d44f0e86b95c11a079635059dd45216cd387a9fc32357d0463d6315b2fc491` |
| `wp-mcp-fator3-0.12.1-rc.1.zip` | `6aede0a4add8f72b373c878703f7719ff44892ac9377ccbee960f33ab61cf02b` |
| `wp-mcp-fator3-0.12.1-rc.2.zip` | `d40fe539256566d3623a6a734cf6ebbc8bedda5628f333537cc558e712146ecf` |
| `base-site-core-fator3-1.9.1.zip` | `ccb717a580f3afe72e3daab2075aa3b198b8ac56303a9b384c8cd62a36c4881e` |
| `wp-super-cache.3.1.3.zip` | `e2773f2146be15c088d5fa4e6280d433b6c08c4d155257be5580b0d69dfcf270` |
| `wordpress-seo.28.4.zip` | `93eba5afc65149967a4bb4906bc8fdebf92f4a65ee02bec97f5c01a7e14e7028` |

O arquivo original `wp-mcp-fator3-fonte-0.12.1-rc.2.zip` continua preservado separadamente, com hash `2959c5c2ebdf9d23252aa19bd685f7b82bef740b57a2e11f2cc45011a7385dfc`. Ele contém o histórico completo. As fontes estáveis não dependem dele para gerar o instalador; o ZIP instalável da rc.2 é insumo da comparação com a base.
