# Atualização para WP MCP Fator3 0.12.1

A 0.12.1 é a versão estável derivada da rc.2 homologada. Mantém o código funcional da base; atualiza a versão e o empacotamento. O instalador distribui execução, assets, licença e índices de silêncio. Testes e documentação permanecem no pacote de fontes.

## Instalar ou substituir

1. No WordPress, abra **Plugins → Adicionar plugin → Enviar plugin**.
2. Envie **wp-mcp-fator3-0.12.1.zip**. Se já estiver instalado, escolha **Substituir o atual pelo enviado**.
3. Mantenha o plugin ativo. Confirme que a lista de plugins mostra **0.12.1**.
4. Abra **Ferramentas → MCP Fator3 → Conexão**, execute o teste HTTP e confirme uma leitura pelo conector existente.

Pasta e arquivo principal permanecem `wp-mcp-fator3/wp-mcp-fator3.php`. A substituição nativa retira os arquivos antigos do pacote e preserva os dados externos ao diretório do plugin. Foram testadas atualização de 0.12.0, 0.12.1-rc.1 e 0.12.1-rc.2, além de instalação limpa; o relatório registra os resultados e ambiente.

Não use a ação **Excluir** do WordPress para atualizar o Fator3: ela executa o desinstalador. Upload por FTP que apenas sobrepõe arquivos pode conservar `tests/` e documentação antiga; prefira a substituição nativa acima. Não foi adicionada uma rotina de limpeza que apague diretórios arbitrários no site.

## Conectores existentes

| Finalidade | URL padrão |
|---|---|
| Principal | `https://seu-dominio/wp-json/mcp/wp-mcp-fator3` |
| Alias compatível | `https://seu-dominio/wp-json/mcp/wp-mcp-ultimate` |

Ambas acessam o mesmo transporte e compartilham credenciais, permissões e sessões. Não é necessário recriar o conector, regenerar token nem trocar a URL antiga. Para novas configurações, copie a URL principal exibida no painel. Em instalações por query, subdiretório ou com personalizações, o painel apresenta a URL efetiva produzida pelo WordPress.

Permanecem OAuth, senhas de aplicação e os nomes dos três metatools. Backups, auditoria, configurações e catálogo de abilities mantêm seus contratos.

## Instalações antigas com Ultimate separado

Atualize primeiro o Fator3 e mantenha-o ativo; depois desative e exclua somente o Ultimate separado. O Fator3 já integra o núcleo e protege os dados compatíveis durante essa transição. A implementação integrada entra em uso após a desativação do Ultimate. Essa sequência é orientação herdada da consolidação; a matriz desta rodada concentra-se nos upgrades 0.12.0/rc.1/rc.2, sem alegar uma nova execução da migração original de dois plugins.

## Recuperação

Se for necessário voltar à base homologada, envie o ZIP original **wp-mcp-fator3-0.12.1-rc.2.zip** pela mesma tela e confirme a substituição. Essa versão mantém as duas URLs e os mesmos formatos de credenciais e dados. A 0.12.1 não acrescenta migração de banco nem mudança de formato de estado. Em caso de erro que impeça acesso ao painel, restaure a pasta do plugin e o backup do site pelo procedimento de recuperação da hospedagem.

## Índices e arquivos públicos

Os 45 índices de silêncio correspondem aos diretórios do instalador atual. A retirada de `tests/` elimina também seus três índices, presentes nos 48 da rc.2. Um índice vazio evita listagem apenas quando o servidor o reconhece como índice; ele não é um controle de acesso aos outros arquivos do diretório. O plugin não altera regras globais do Apache ou Nginx. O laboratório e seus limites estão descritos em [VALIDACAO.md](VALIDACAO.md).
