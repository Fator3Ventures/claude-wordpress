# Plano — WP MCP Fator3 0.12.1, baseado na rc.2

**Data:** 15/09/2026  
**Base de desenvolvimento:** `wp-mcp-fator3-fonte-0.12.1-rc.2.zip`  
**Base instalável:** `wp-mcp-fator3-0.12.1-rc.2.zip`  
**Situação da base:** rc.2 homologada, conforme confirmação do usuário.  
**Próxima entrega:** `0.12.1` estável, com validação das alterações desta evolução.

## 1. Direcionamento

Adotar a rc.2 homologada como base oficial, consolidar seu empacotamento e corrigir as instruções de manutenção. A próxima entrega será diretamente a **0.12.1 estável**. A homologação informada pelo usuário encerra a pendência herdada da rc.2; os testes desta evolução verificarão as alterações e a integridade do novo instalador.

O escopo funcional preserva as 100 abilities próprias, os três metatools, as duas URLs, as credenciais e os contratos existentes. As melhorias de URL, configuração e UX entregues na 0.12.0 continuam na base. Nenhuma alteração do plugin instalado foi realizada na elaboração deste plano.

## 2. O que a rc.2 efetivamente acrescentou

Os dois anexos foram extraídos e comparados com a rc.1 produzida anteriormente. O instalador foi reconstruído pelo script fornecido, em uma pasta temporária, e seu conteúdo binário ficou idêntico ao ZIP anexado.

| Item | Constatação | Consequência para a próxima versão |
|---|---|---|
| Código funcional | Na árvore `fontes/wp-mcp-fator3`, somente `wp-mcp-fator3.php` difere da rc.1: cabeçalho e constante de versão | Preservar a correção de autenticação já existente e rastrear qualquer mudança adicional |
| Autenticação Bearer | `BearerAuth.php` é idêntico ao da rc.1 | A rc.2 não acrescenta uma nova correção de autenticação |
| Instalador | Exclui `docs/`, `maintenance/`, `README.md`, `CHANGELOG.md` e nomes de instruções internos | Manter essa separação entre instalação e documentação de desenvolvimento |
| Diretórios | Inclui 48 `index.php` de silêncio | Preservar a geração automática para todos os diretórios que permanecerem no instalador |
| Contagem PHP | 117 arquivos PHP preexistentes e 48 índices, totalizando 165 | Tratar a contagem como inventário da rc.2; recalcular após ajustar o pacote |
| Build | `suite/pacotes-191.py` gera um ZIP determinístico; a reconstrução coincidiu com o anexo | Manter a reprodução exata como critério de aceite |
| Integração anexada | Há 13 cenários registrados, predominantemente do Core 1.9.1, com verificações de pacote, diretórios e carregamento do canal | Conservar a evidência com seu escopo e complementar a validação específica do MCP |
| Homologação | O usuário confirmou a homologação da rc.2 após a elaboração inicial deste plano | Considerar a base homologada e atualizar a documentação corrente que ainda apresenta a pendência histórica |

**Precisão da evidência:** os 253 testes da rc.1, os 13 cenários anexados à rc.2 e os resultados gerais do Core representam rodadas e escopos distintos. Nesta análise foram executadas comparação de arquivos, inspeção dos scripts, auditoria estrutural e reconstrução do ZIP. Não foi executada uma nova matriz HTTP de autenticação nesta análise. A homologação da rc.2 foi confirmada pelo usuário posteriormente e é adotada como estado atual da base.

## 3. Pontos identificados para esta evolução

### 3.1 Testes ainda fazem parte da instalação pública

O instalador contém 15 arquivos sob `tests/`, somando 81.023 bytes descompactados. São testes PHP, scripts JavaScript, o catálogo esperado em JSON e índices. As referências encontradas a `tests/expected-abilities.json` estão nos próprios testes; a leitura do código de execução não identificou dependência desse diretório.

**Proposta:** manter os testes nas fontes e nas evidências; excluir `tests/` do instalador. Verificar a ausência de dependências pelo carregamento real do ZIP resultante e pela execução do catálogo. Isso reduz arquivos desnecessários em produção. A presença desses arquivos, isoladamente, não comprova uma vulnerabilidade explorável.

### 3.2 Documentação atual desatualizada

O README externo identifica corretamente a rc.2. Dentro de `fontes/wp-mcp-fator3`, o README e a primeira entrada do changelog ainda identificam a rc.1. Os relatórios antigos são úteis como histórico, mas falta uma entrada corrente que explique a evolução rc.1 → rc.2 homologada → 0.12.1 estável.

**Proposta:** atualizar os documentos correntes, registrar o escopo de cada rodada e manter os relatórios históricos com sua identificação original. Usar o número da versão de lançamento como entrada única para o build e conferir sua consistência no cabeçalho, constante, nomes de artefatos e manifesto.

### 3.3 Reprodução depende de caminhos e insumos do Core

`suite/BACKLOG-191.md` referencia `suite/bancada-wp/...` e `suite/verificar.sh`, que não existem nessa distribuição do canal. Os scripts presentes estão diretamente em `suite/`. A suíte também depende de instaladores e ambiente do Core. O README externo contém um comando de build válido, confirmado nesta análise.

**Proposta:** oferecer um roteiro autônomo de build e testes do MCP. Documentar a suíte de integração com o Core como uma execução adicional, com os insumos externos exigidos. Substituir caminhos fixos das rodadas anteriores por parâmetros de fonte, instalador, versão, diretório de laboratório e runtime.

### 3.4 Verificação HTTP do novo empacotamento

Um `index.php` vazio evita a listagem quando o servidor o reconhece como índice. Isso não restringe o acesso direto a outro arquivo com nome conhecido. A seleção do índice depende de `DirectoryIndex`, conforme a [documentação do Apache](https://httpd.apache.org/docs/2.4/mod/mod_dir.html#directoryindex).

**Proposta:** manter os índices e testar separadamente listagem de diretórios, ausência dos arquivos excluídos e disponibilidade dos assets necessários. Documentar a configuração de servidor utilizada, sem acrescentar regras globais de hospedagem ao plugin.

## 4. Plano de execução

**P0:** necessário para aceitar a versão estável. **P1:** melhoria de manutenção e distribuição incluída nesta proposta. **P2:** organização opcional, executada após os itens de aceite.

| ID | Prioridade | Trabalho | Resultado verificável |
|---|---|---|---|
| F3-01 | P0 | Fixar a rc.2 como base, guardar hashes e inventário, comparar cada mudança posterior | Manifesto identifica fonte, instalador, versão e arquivos alterados |
| F3-02 | P1 | Ajustar o build para distribuir apenas os arquivos necessários à execução e a licença; excluir testes e materiais internos | ZIP sem `tests/`, documentos internos, ferramentas de build ou evidências; assets e autoload funcionam |
| F3-03 | P0 | Auditar o artefato final e sua reconstrução | Dois builds com os mesmos insumos produzem o mesmo SHA-256; arquivo obrigatório ausente ou arquivo proibido incluído causa falha |
| F3-04 | P1 | Atualizar README, changelog, guia de atualização e comandos de reprodução | A documentação identifica a versão corrente e todos os comandos locais apontam para arquivos existentes |
| F3-05 | P0 | Preparar execução autônoma da matriz de autenticação sobre o instalador final | Relatório novo com ambiente, versão, hash do ZIP, resultados e pendências; execução independente do pacote do Core |
| F3-06 | Concluído na base | Incorporar a homologação da rc.2 confirmada pelo usuário | Documentos correntes registram a base homologada; relatórios antigos mantêm sua identificação histórica |
| F3-07 | P0 | Validar atualização e compatibilidade | Atualização por instalador nativo preserva credenciais, sessões, configurações e acervo; ambas as URLs funcionam |
| F3-08 | P0 | Conferir convivência com o Core, WP Super Cache e Yoast | Canal autentica e executa uma leitura com a combinação ativa; páginas públicas e respostas protegidas mantêm o comportamento esperado |
| F3-09 | P2 | Reduzir cópias históricas no pacote de fontes corrente | Histórico preservado em artefato separado ou Git; fonte atual e testes continuam reproduzíveis |

### Etapa A — base e distribuição

Executar F3-01 a F3-04. O build deve selecionar explicitamente os diretórios e arquivos permitidos, gerar os índices depois da seleção e validar a raiz `wp-mcp-fator3/`. Os arquivos funcionais comuns ao fonte e ao instalador devem ter hashes iguais. Alterações legítimas de código entram no diff e na revisão; não devem ser ocultadas por normalização genérica de strings de versão.

A remoção de testes exige preservar o catálogo esperado na suíte de desenvolvimento. Manter LICENSE, CSS, JavaScript, views, autoload, classes, arquivo principal e desinstalador necessários. A contagem de índices acompanha os diretórios efetivamente distribuídos.

### Etapa B — regressão do canal

Executar F3-05 sobre o ZIP produzido na etapa A, em instalação descartável, e registrar F3-06 como concluído na base. Os testes verificam que a retirada de artefatos e a atualização de versão preservam o funcionamento do canal. A autenticação permanece em `rest_authentication_errors`, preservando o resultado de outros mecanismos e verificando se o Bearer está sendo usado, de acordo com o [contrato do WordPress](https://developer.wordpress.org/reference/hooks/rest_authentication_errors/).

Se aparecer uma falha funcional, registrar requisição, resposta e stack trace sem segredos; corrigir o caso identificado e repetir os cenários afetados. Registrar a cobertura efetivamente executada. A homologação da base permanece válida; ampliar os testes apenas para cobrir as alterações ou investigar uma regressão concreta.

### Etapa C — atualização e integração

Executar F3-07 e F3-08. Criar as credenciais e a sessão MCP antes da atualização e reutilizá-las depois. Conferir por HTTP a ausência dos documentos antigos e dos testes removidos. A prova de upgrade do Core anexada à rc.2 não substitui a prova de atualização do próprio canal.

A instalação deve substituir o plugin pelo mecanismo nativo do WordPress. Métodos que apenas sobrepõem arquivos precisam de orientação específica para evitar resíduos. Não acrescentar uma rotina que apague diretórios não identificados nem modificar dados de operação para limpar artefatos de desenvolvimento.

### Etapa D — entrega

Gerar diretamente a **0.12.1 estável** e seus relatórios, após verificar as alterações desta evolução. O build deve usar a versão final, conferir o diff e validar o artefato que será efetivamente distribuído. F3-09 pode ser realizado nessa etapa, preservando a rastreabilidade.

## 5. Matriz de aceite

| Área | Casos obrigatórios | Aceite |
|---|---|---|
| Público | Home, página interna e raiz REST sem cookies; home e `wp/v2/types` com Bearer inválido | 200 e ausência de fatal |
| MCP sem credencial | Duas URLs, sem Authorization | 401 com desafio Bearer e endereço de metadados correto |
| MCP inválido | Token inválido, expirado, revogado e com vínculo incorreto de site/recurso/escopo | Recusa sem 500 e sem atribuição de identidade |
| MCP válido | Bearer e senha de aplicação; `initialize` seguido de `tools/list` com sessão | Resposta válida e os três metatools esperados |
| Limite da credencial | `rest_route` em GET e POST desviando para `wp/v2/users`/`users/me`; rota semelhante, ausente ou ocupada por outro callback | Token MCP não autentica a API comum nem o callback de terceiros; leitura pública continua com representação anônima |
| Inicialização | Consulta antecipada do usuário, filtros que consultam permissões e reentrada | Sem resolução prematura de rota, recursão ou perda da guarda após exceção |
| Administrador | Home logada e página de configurações | Funcionamento preservado; caso com cookie registrado separadamente |
| URLs | Alias Ultimate, principal Fator3 e formato `rest_route` | Mesmo transporte e regras de autenticação; sem redirecionamento de credenciais |
| Catálogo | Inventário, descoberta, informações e uma operação de leitura | 100 abilities próprias presentes; complementos podem acrescentar outras |
| Atualização | Base 0.12.0, rc.1 e rc.2 para 0.12.1 estável; instalação limpa | Slug e arquivo principal mantidos; credenciais/sessões válidas continuam utilizáveis; dados preservados |
| Arquivos | Duas gravações com o mesmo `expected_sha256`, através das duas URLs | Uma gravação aceita e um conflito identificável; acervo de backup e auditoria preservado |
| Distribuição | ZIP final, índices, arquivos excluídos, assets e comparação fonte/instalador | Conteúdo permitido, integridade válida, reprodução determinística e comportamento HTTP verificado |
| Cache e integração | Canal com Core, WP Super Cache e Yoast ativos; respostas MCP autenticadas e erros | Sem resposta protegida reutilizada entre usuários/requisições; cabeçalhos e respostas conferidos por HTTP |

A matriz orienta a regressão do novo pacote. Reaproveitar a homologação da rc.2 e selecionar os conjuntos de execução conforme os arquivos e comportamentos alterados. Ambientes de referência:

- **Ambiente mínimo suportado:** WordPress 6.7/PHP 8.0, incluindo o caminho de compatibilidade da Abilities API.
- **Integração da rc.2:** WordPress 6.9, PHP 8.3.6, Apache, Core 1.9.1, WP Super Cache 3.1.3 e Yoast 28.4, conforme a evidência anexada.
- **Incidente:** WordPress 7.1, PHP 8.3.30, Apache, Elementor 4.2.4, PRO Elements 4.2.2 e gladdia-llms-txt 1.0.0; controle sem Elementor e comparação com Elementor isolado.

A lista conserva as versões registradas na análise anterior e serve de referência para regressão. A confirmação do usuário estabelece a rc.2 como homologada; este plano não atribui a essa confirmação detalhes de ambiente ou contagens de testes adicionais. Para alterações restritas ao empacotamento, validar o instalador final e os fluxos afetados. A combinação do incidente será retomada se uma nova alteração funcional ou falha concreta exigir essa investigação.

## 6. Preservação dos contratos e divisão de responsabilidade

- Continuam válidas `/wp-json/mcp/wp-mcp-fator3` e `/wp-json/mcp/wp-mcp-ultimate`, além do formato por query produzido pelo WordPress.
- Permanecem o slug `wp-mcp-fator3`, o arquivo `wp-mcp-fator3.php`, os identificadores do servidor e os nomes dos metatools/abilities.
- OAuth, senhas de aplicação, preferências, backups, auditoria e locks mantêm seus dados e regras. A atualização não regenera credenciais.
- A organização das telas da 0.12.0, JSONs recolhidos e diagnóstico de conexão permanecem na base.
- O MCP conserva sua função de transporte e execução autorizada. As políticas de SEO, llms e cache do site continuam pertencendo aos plugins responsáveis; as tarefas do implantador continuam no seu fluxo de implantação.

## 7. Entregáveis previstos

1. **Instalador estável:** `wp-mcp-fator3-0.12.1.zip`.
2. **Fontes:** código corrente, testes, build e documentação compatíveis com o instalador entregue.
3. **Evidências:** resultados da rodada, versões e hashes, cobertura, pendências e logs sem segredos.
4. **Guia de atualização:** sequência de substituição, validação das duas URLs e recuperação em caso de falha.
5. **Histórico separado**, se F3-09 for executado, com referências que permitam recuperar as versões anteriores.

O plano não define meta de redução percentual do ZIP: a rc.2 já tem cerca de 301 kB. O critério principal é distribuir os arquivos necessários e manter build/testes reproduzíveis.

## 8. Homologação da base e condição de entrega

O usuário confirmou que a **rc.2 já foi homologada** e autorizou que a próxima versão seja estável. Essa confirmação atualiza o estado do projeto e encerra a pendência anterior de homologação, inclusive a referência a gladdia como condição para a liberação.

Atualizar README, changelog e relatório corrente para registrar essa conclusão. Preservar os relatórios históricos como retrato de suas respectivas rodadas. A condição para entregar a 0.12.1 é verificar as alterações previstas neste plano e o ZIP final, preservando o comportamento da base homologada.

## 9. Referências locais e hashes da base

| Arquivo | SHA-256 |
|---|---|
| `wp-mcp-fator3-fonte-0.12.1-rc.2.zip` | `2959c5c2ebdf9d23252aa19bd685f7b82bef740b57a2e11f2cc45011a7385dfc` |
| `wp-mcp-fator3-0.12.1-rc.2.zip` | `d40fe539256566d3623a6a734cf6ebbc8bedda5628f333537cc558e712146ecf` |

Referências dentro do ZIP de fontes: `README.md`; `fontes/wp-mcp-fator3/wp-mcp-fator3.php`; `fontes/wp-mcp-fator3/core/includes/OAuth/BearerAuth.php`; `suite/pacotes-191.py`; `suite/verificar-canal-191.py`; `suite/BACKLOG-191.md`; `suite/backlog-191.py`; `evidencias/pacote-rc2.json`; `evidencias/integracao-core-canal.json`; `evidencias/relatorio-tabela-A-1.9.1.md`.
