# WP MCP Fator3 0.12.1

Distribuição estável baseada na rc.2 homologada. Plugin único com servidor MCP, OAuth, conteúdo, arquivos e banco de dados, preservando 100 abilities próprias e os três metatools.

Requisitos: WordPress 6.7+ e PHP 8.0+. A Abilities API integrada atende versões anteriores ao WordPress 6.9; versões posteriores usam a API nativa. O WordPress não precisa de Composer, Node ou Python para executar o plugin.

## Instalar ou atualizar

Envie `wp-mcp-fator3-0.12.1.zip` em Plugins → Adicionar plugin → Enviar plugin e escolha substituir o atual. Pasta e arquivo principal permanecem `wp-mcp-fator3/wp-mcp-fator3.php`. As credenciais e os dados existentes são preservados.

Abra Ferramentas → MCP Fator3 → Conexão e execute o teste HTTP. Confirme também uma leitura no conector existente. [Guia de atualização](../../docs/ATUALIZACAO.md).

## Conexão

| Uso | URL com permalinks amigáveis |
|---|---|
| Principal | `https://seu-dominio/wp-json/mcp/wp-mcp-fator3` |
| Compatibilidade | `https://seu-dominio/wp-json/mcp/wp-mcp-ultimate` |

Os aliases compartilham servidor, sessões e permissões. Sem permalinks amigáveis ou com rota personalizada, copie a URL efetiva mostrada no painel. OAuth e senhas de aplicação continuam disponíveis. As ferramentas expostas são Discover Abilities, Get Ability Info e Execute Ability; complementos podem ampliar o catálogo de abilities.

## Alterações desta versão

- Entrega estável após confirmação da homologação da rc.2 pelo usuário.
- Instalador com arquivos de execução e licença; testes ficam nas fontes.
- Índices de silêncio gerados para os diretórios distribuídos.
- Build determinístico, inventário explícito e auditoria contra o fonte.
- Suíte autônoma para o ZIP final, atualização nativa e regressão do canal.
- Documentação atualizada e referências ao histórico preservadas.

O código funcional e os assets da rc.2 são preservados; o arquivo principal muda apenas o cabeçalho e a constante de versão. Permanecem as correções de autenticação, unslash, exclusão, lixeira, leitura de logs, diretórios vazios, locks por arquivo e conflito `expected_sha256`.

## Instalações antigas com Ultimate separado

Atualize o Fator3 primeiro e mantenha-o ativo; depois desative e exclua somente o Ultimate separado. Essa sequência permite preservar as credenciais diante do desinstalador antigo. A correção do núcleo integrado entra em uso depois da desativação do Ultimate. Não exclua o Fator3 para atualizar.

## Desenvolvimento

Use o README da raiz do pacote de fontes para build e testes. Documentos históricos e cópias completas de versões anteriores estão referenciados em [HISTORICO.md](../../docs/HISTORICO.md). As evidências da 0.12.1 identificam explicitamente os testes executados nesta rodada.
