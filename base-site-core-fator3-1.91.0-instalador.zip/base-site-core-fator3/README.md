# Fator3 Site Core 1.91.0

Versão 1.91.0. A continuação GA4 respeita o executor de 15 minutos. O Core corrige a seleção de nomes do Google Play, a agenda com WP Activity Log, a medição no toque e o diagnóstico de wp_mail. Consulte docs/RELEASE-1.91.0.md.

Instalação nova ou atualização da 1.90.0. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.43.0.

Índice de operação em docs/DOCUMENTACAO.md.
