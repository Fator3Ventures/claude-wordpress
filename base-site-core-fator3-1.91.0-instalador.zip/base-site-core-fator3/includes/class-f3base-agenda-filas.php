<?php
/** Alterações pontuais no cron nativo para os seis ganchos das filas do Site Core. */
declare(strict_types=1);
defined('ABSPATH') || exit;

final class F3Base_Agenda_Filas {
    private const FILTROS = [
        'pre_schedule_event' => ['agendar', 3],
        'pre_reschedule_event' => ['reagendar', 3],
        'pre_unschedule_event' => ['remover', 5],
    ];
    private static bool $iniciada = false;
    private static array $reposicionados = [];

    public static function iniciar(): void {
        if (self::$iniciada) { return; }
        self::$iniciada = true;
        foreach (self::FILTROS as $nome => [$metodo, $args]) {
            add_filter($nome, [self::class, 'ordenar_se_necessario'], PHP_INT_MIN, 1);
            add_filter($nome, [self::class, $metodo], PHP_INT_MAX, $args);
        }
        if (did_action('wp_loaded')) { self::reposicionar(); }
        else { add_action('wp_loaded', [self::class, 'reposicionar'], PHP_INT_MAX); }
    }

    private static function posteriores(string $filtro): array {
        global $wp_filter;
        $grupo = $wp_filter[$filtro]->callbacks[PHP_INT_MAX] ?? [];
        $chave = self::class . '::' . self::FILTROS[$filtro][0];
        if (array_key_last($grupo) === $chave) { return []; }
        $pos = array_search($chave, array_keys($grupo), true);
        return $pos === false ? [] : array_slice($grupo, $pos + 1);
    }

    private static function nomes_posteriores(string $filtro): array {
        $nomes = [];
        $posteriores = self::posteriores($filtro);
        foreach ($posteriores as $cb) {
            $f = $cb['function'];
            try {
                $r = is_array($f) ? new ReflectionMethod($f[0], $f[1]) : new ReflectionFunction(Closure::fromCallable($f));
                $arquivo = wp_normalize_path((string) $r->getFileName());
                $pasta = trailingslashit(wp_normalize_path(WP_PLUGIN_DIR));
                $plugin = str_starts_with($arquivo, $pasta) ? explode('/', substr($arquivo, strlen($pasta)))[0] : 'fora_do_diretorio_de_plugins';
            } catch (Throwable $e) { $plugin = 'origem_indeterminada'; }
            $nomes[$plugin] = true;
        }
        return $nomes;
    }

    private static function ordenar(string $filtro): void {
        $posteriores = self::posteriores($filtro);
        if (!$posteriores) { return; }
        self::$reposicionados[$filtro] = (self::$reposicionados[$filtro] ?? []) + self::nomes_posteriores($filtro);
        [$metodo, $args] = self::FILTROS[$filtro];
        remove_filter($filtro, [self::class, $metodo], PHP_INT_MAX);
        add_filter($filtro, [self::class, $metodo], PHP_INT_MAX, $args);
    }

    public static function reposicionar(): void {
        foreach (array_keys(self::FILTROS) as $filtro) { self::ordenar($filtro); }
    }

    public static function ordenar_se_necessario($pre) {
        self::ordenar(current_filter());
        return $pre;
    }

    public static function diagnostico(): array {
        $filtros = [];
        foreach (self::FILTROS as $filtro => [$metodo]) {
            $filtros[$filtro] = [
                'registrado' => has_filter($filtro, [self::class, $metodo]) === PHP_INT_MAX,
                'callbacks_posteriores_agora' => array_keys(self::nomes_posteriores($filtro)),
                'plugins_reposicionados' => array_keys(self::$reposicionados[$filtro] ?? []),
            ];
        }
        return ['origem'=>F3Base_Execucoes::origem(),
                'perfil'=>class_exists('F3Base_Perfil_Publico', false) && F3Base_Perfil_Publico::ativo() ? 'publico' : 'completo',
                'filtros'=>$filtros];
    }

    public static function reagendar($pre, $evento, bool $com_erro) {
        if ($pre !== null || !isset(F3Base_Fila::RECORRENCIAS[$evento->hook])) { return $pre; }
        $intervalo = (int) $evento->interval;
        if ($intervalo < 1) { return $com_erro ? new WP_Error('invalid_schedule', 'Recorrência sem intervalo.') : false; }
        $agora = time();
        $proximo = $agora + $intervalo;
        if ($evento->timestamp < $agora) { $proximo -= ($agora - $evento->timestamp) % $intervalo; }
        return wp_schedule_event($proximo, $evento->schedule, $evento->hook, $evento->args, $com_erro);
    }

    public static function agendar($pre, $evento, bool $com_erro) {
        if ($pre !== null || !isset(F3Base_Fila::RECORRENCIAS[$evento->hook])) { return $pre; }
        $evento = apply_filters('schedule_event', $evento);
        if (!$evento) { return $com_erro ? new WP_Error('schedule_event_false', 'Evento recusado.') : false; }
        return self::alterar($evento->hook, (int)$evento->timestamp, $evento->args, $evento, $com_erro);
    }

    public static function remover($pre, $hora, string $hook, array $args, bool $com_erro) {
        if ($pre !== null || !isset(F3Base_Fila::RECORRENCIAS[$hook])) { return $pre; }
        if ($args === F3Base_Fila::ANTECIPAR && $hora <= time()
            && (wp_doing_cron() || (defined('WP_CLI') && WP_CLI))
            && !has_action($hook)) {
            return $com_erro ? new WP_Error('fila_sem_executor', 'Ocorrência preservada até o carregamento do trabalhador.') : false;
        }
        return self::alterar($hook, (int)$hora, $args, null, $com_erro);
    }

    private static function invalidar_cache(): void {
        wp_cache_delete('cron', 'options');
        wp_cache_delete('alloptions', 'options');
        wp_cache_delete('notoptions', 'options');
    }

    private static function alterar(string $hook, int $hora, array $args, ?object $evento, bool $com_erro) {
        global $wpdb;
        $chave = md5(serialize($args));
        $operacao = $evento ? 'agendar' : 'remover';
        for ($i = 0; $i < 16; ++$i) {
            $raw = $wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s', $wpdb->options, 'cron'));
            if ($wpdb->last_error) { break; }
            $cron = $raw === null ? [] : maybe_unserialize($raw);
            if (!is_array($cron)) { break; }
            $antes = $cron[$hora][$hook][$chave] ?? null;
            $depois = $evento ? ['schedule'=>$evento->schedule, 'args'=>$args] : null;
            if ($evento && $evento->schedule) { $depois['interval'] = (int)$evento->interval; }
            if ($antes === $depois) {
                self::invalidar_cache();
                do_action('f3base_fila_agenda_medida', $hook, $hora, $operacao, 'ja_persistido');
                return true;
            }
            if ($evento && !$evento->schedule) {
                $agora = time();
                $min = $hora < $agora + 600 ? 0 : $hora - 600;
                $max = max($agora, $hora) + 600;
                foreach ($cron as $t => $hooks) {
                    if (is_numeric($t) && $t >= $min && $t <= $max && isset($hooks[$hook][$chave])) {
                        return $com_erro ? new WP_Error('duplicate_event', 'Evento único já presente na janela.') : false;
                    }
                }
            }
            unset($cron['version']);
            if ($evento) {
                $cron[$hora][$hook][$chave] = $depois;
                uksort($cron, 'strnatcasecmp');
            } else {
                unset($cron[$hora][$hook][$chave]);
                if (!$cron[$hora][$hook]) { unset($cron[$hora][$hook]); }
                if (!$cron[$hora]) { unset($cron[$hora]); }
            }
            $cron['version'] = 2;
            if ($raw === null) {
                $salvo = (int)add_option('cron', $cron, '', true);
            } else {
                $salvo = $wpdb->query($wpdb->prepare(
                    'UPDATE %i SET option_value=%s WHERE option_name=%s AND BINARY option_value=BINARY %s',
                    $wpdb->options, maybe_serialize($cron), 'cron', $raw
                ));
            }
            self::invalidar_cache();
            if ($salvo === false) { break; }
            if ($salvo === 1) {
                if ($raw !== null) {
                    $anterior = maybe_unserialize($raw);
                    do_action('update_option_cron', $anterior, $cron, 'cron');
                    do_action('updated_option', 'cron', $anterior, $cron);
                }
                do_action('f3base_fila_agenda_medida', $hook, $hora, $operacao, 'gravado');
                return true;
            }
            // Outra escrita ganhou entre leitura e UPDATE. Refazer só o delta deste evento.
            usleep(random_int(500, 2500));
        }
        do_action('f3base_fila_agenda_medida', $hook, $hora, $operacao, 'falha_persistencia');
        return $com_erro ? new WP_Error('could_not_set', 'A alteração da agenda não foi confirmada pelo banco.') : false;
    }
}
