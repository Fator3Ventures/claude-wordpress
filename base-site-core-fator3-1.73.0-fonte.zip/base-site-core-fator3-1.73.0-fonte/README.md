# Fator3 Site Core 1.73.0 — fonte

Base vigente: 1.72.1. PHP mínimo 8.3 e WordPress mínimo 7.1.4. Documentação funcional: `work/plugin/base-site-core-fator3/docs/RELEASE-1.73.0.md`.

- `work/plugin/base-site-core-fator3/`: runtime que gera o instalador.
- `history/1.72.1-runtime/`: base exata para a prova de migração; não é versão oferecida para operação ou downgrade.
- `tests/`: testes nativos e acervo histórico identificado.
- `evidence/1730/`: resultados sanitizados desta rodada, inventário e hashes.
- `RELATORIO-PRE-FECHAMENTO.md`: relatório interno anterior ao fechamento; o relatório externo contém os hashes finais dos ZIPs.

## Gerar os arquivos

Com Python 3.11+, execute `python3 build/reproduzir-instalador.py /caminho/fora-do-fonte/base-site-core-fator3-1.73.0-instalador.zip` e `python3 build/empacotar-fonte.py /caminho/fora-do-fonte/base-site-core-fator3-1.73.0-fonte.zip`. As entradas são ordenadas, datas/permissões fixas e sem ZIP aninhado. O empacotador de fonte confere o runtime contra o manifesto; mudanças exigem atualizar o manifesto e repetir os testes pertinentes.

Nenhum segredo de instalação, banco de laboratório ou dependência instalada acompanha os pacotes. O ambiente nativo validado usou PHP 8.4.27, WordPress 7.1.4 e MariaDB 11.8.6. A execução no PHP mínimo 8.3 e a aceitação em fornecedor real permanecem discriminadas no relatório.
