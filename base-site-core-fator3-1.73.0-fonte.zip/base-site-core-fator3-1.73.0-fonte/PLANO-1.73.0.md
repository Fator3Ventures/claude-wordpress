# Core 1.73.0 — plano executado

Base 1.72.1. Pedidos core 371, 372, 373. Normas revisão 5. Implementar modo por formulário e marcação com captura cifrada/consentimento/recibo; CAPI aceita gravação com aviso e prova por evento; IMAP transitório configurável. Sem alteração de APIs consumidas dos acompanhantes. Validação local limpa/atualização e instalação no Site-Teste autorizadas. Fornecedor real e produção Korvena exigem homologação com ativos correspondentes.

## Encerramento

Implementação concluída e instalada no Site-Teste. Contrato 8.35.0. 179 verificações nativas e 9 verificações IMAP remotas passaram. Homologação Meta/queda DreamHost real e inspeção visual permanecem pendentes conforme relatório. Nenhum encaminhamento técnico individual necessário nos acompanhantes anexos; Pipedrive 0.8.0 observado por atualização concorrente ao final.
