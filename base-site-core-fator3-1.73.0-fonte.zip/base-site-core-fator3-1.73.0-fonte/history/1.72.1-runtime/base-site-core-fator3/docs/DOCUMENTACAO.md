# Documentação vigente — Core 1.72.1

Contrato administrativo 8.34.0. Base de atualização 1.72.0. Para operar as telas de configuração, leia GUIA-PAINEL.md. Consulte RELEASE-1.72.1.md para conferir a correção do painel duplicado.

| Necessidade | Documento |
| --- | --- |
| Velocidade da página, custo do Core, vitais e limites da amostra | MEDICAO-DESEMPENHO.md |
| Separar vitais conforme o código carregado na visita | VITAIS-VERSAO.md |
| Configuração pelo painel | GUIA-PAINEL.md |
| Release e instruções para agentes | RELEASE-1.72.1.md, AGENTES-1.72.1.md |
| Marcas, conta/nome de campanha, canal e piso | CAMPANHAS-MARCAS-PERFIL-1.62.md |
| Acervos Google/Meta, GSC consultas e prova individual de e-mail | ACERVOS-E-EMAIL-1.61.1.md |
| Sessões, apps, redes e presença paga nos logs | SESSOES-1.61.md |
| Regras orgânicas e catálogo IA configurável | CANAIS-ORGANICOS-1.61.md |
| Reconciliação de eventos comerciais e limites Google/LinkedIn | RECONCILIACAO-COMERCIAL-1.59.md |
| Operação curta, prontidão, marcas, SMTP, avisos e edição por caminho | OPERACAO-1.58.md |
| Identidade, WhatsApp, resposta e desfechos | CONTATOS-COMERCIAL-1.58.md |
| Abandono, revisão de formulário e relatório | FORMULARIOS-ABANDONO-1.58.md |
| Google 1.1 e prévias de conversão | CONVERSOES-1.58.md |
| Contrato comercial 1.2, concessões e capacidades efetivas | QUALIDADE-DESTINOS-1.58.md |
| Teste sob demanda e limpeza | CAMINHO-LEAD-1.60.md, CAMINHO-LEAD-1.58.md |
| Consumidor do acervo Meta Ads | META-ADS-CORE-1.60.md, META-ADS-CORE-1.58.md |
| Especificação e uso | INSTRUCOES-DO-PLUGIN.md, README.md, LEADS-E-FORMULARIOS.md |
| Configuração e ajuda por campo | CONFIGURACAO.md, AJUDA-OPCOES.md, dados/configuracao-schema.json |
| Contratos e schemas executáveis | CONTRACTS.md, dados/abilities-*.json, dados/contrato.json, schemas/*.json |
| Operação e recuperação | OPERACAO-E-RECUPERACAO.md, CRON-DIAGNOSTICO-1.31.md |
| Contatos externos e atribuição manual | CONTATOS-EXTERNOS-1.54.md |
| Sessões, IMAP e provas cron | OPERACAO-1.55.md |
| Acervo GA4 e exclusão Instagram | ACERVO-GA4-1.57.md, INSTAGRAM-EXCLUSAO-1.57.md |
| Conversas WhatsApp e Instagram | CONVERSAS-1.56.md |
| Correio por site e dependências | EMAIL-SITE-1.53.md, DEPENDENCIAS-EMAIL-1.53.md |
| Iscas e política de avisos | FORMULARIOS-SINAIS-1.53.md |
| Credenciais | CREDENCIAIS-1.60.md, CREDENCIAIS-1.51.md |
| Pipedrive | PIPEDRIVE.md, PIPEDRIVE-1.37.md, PIPEDRIVE-OPERACAO.md, ORCAMENTO-PIPEDRIVE.md |
| Meta e LinkedIn | META-ACESSO-1.28.md, META-TRANSPORTE-1.19.md, LINKEDIN-LEAD-SYNC.md |
| Dados, retenção e consentimento | DICIONARIO-DADOS.md, RETENCAO-1.45.md, FORMULARIOS-TENTATIVAS-1.44.md |
| Base preservada e histórico | RELEASE-1.59.0.md, AGENTES-1.59.0.md, RELEASE-1.58.0.md, AGENTES-1.58.0.md, RELEASE-1.57.1.md, AGENTES-1.57.1.md, history/RELEASE-*.md |
| Normas da manutenção | NORMA-01-instrucoes-agentes-plugins-fator3.md, NORMA-02-padrao-desenvolvimento-plugins-fator3.md |
| Provas e limitações | VALIDACAO.md e relatório externo da entrega |

`f3base/documentacao-ler` sem argumentos fornece a lista exata instalada. Leia cada arquivo com `arquivo`, `linha` e `limite` (até 200), continuando em `proxima_linha`; confira SHA-256 e versão. O índice inclui os demais guias vigentes, schemas e histórico disponível. Leitura documental não faz HTTP, grava configuração ou repara cron.

As notas 1.60 prevalecem para pedidos 322 e 330–334. A 1.59 continua vigente para reconciliação comercial, com capacidades e concessões efetivas. Guias históricos documentam o comportamento de suas bases. Existência de ability não é homologação de fornecedor.
