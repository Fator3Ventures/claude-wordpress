> Consolidação 1.57.1: leia RELEASE-1.57.1.md para as correções e campos opcionais dos pedidos 312/313. Base direta canônica 1.57.0.

# Fator3 Site Core 1.57.1

Comece em DOCUMENTACAO.md e AGENTES-1.57.1.md. Pedidos 312/313 em RELEASE-1.57.1.md, ACERVO-GA4-1.57.md e INSTAGRAM-EXCLUSAO-1.57.md. Pedidos anteriores 307–311 permanecem documentados em history/RELEASE-1.56.0.md e CONVERSAS-1.56.md; contatos externos do pedido 302 em CONTATOS-EXTERNOS-1.54.md. Contrato administrativo 8.22.1, cliente pipedrive-api-client/1.0.0 preservado.
