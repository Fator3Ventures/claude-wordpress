# Teste sob demanda do caminho do lead — Core 1.58.0

Pedido core 322. A rota valida a persistência e os transportes autorizados de um contato de teste, mantém um diário por salto e tenta a limpeza dos objetos que criou. É execução sob demanda; não há canário diário. O aceite ponta a ponta permanece parcial quando qualquer salto/limpeza estiver bloqueado, incerto ou pendente.

## Prévia e execução

`f3base/caminho-lead-testar` exige `manage_options` e `f3base_gerir_leads`. Informe `formulario`; `campos` pode fornecer valores exigidos pela definição. Nome, e-mail e empresa recebem valores sintéticos com `[TESTE F3BASE]` quando esses papéis existem. `nativo` aceita vazio, `meta` ou `linkedin`; atribuição opcional é explícita. O contato nativo é sintético, sem sessão, e não testa a API nativa da plataforma.

`simular:true` é o padrão. Retorna plano, bloqueios e `revisao`, sem criar registros. Para aplicar, use a mesma entrada, `simular:false`, a revisão SHA-256 recebida e `chave_operacao` (8–128 caracteres conforme schema). Mudança de formulário/configuração invalida a prévia. A mesma chave e intenção consultam o mesmo recibo; reaproveitar a chave para outra intenção é recusado.

O ID do teste é devolvido antes dos efeitos. Consulte `f3base/caminho-lead-recibo-ler` com `id`, sob administração/leitura de contatos. O recibo público contém IDs, resultados, códigos, instantes e limpezas, sem os campos pessoais da entrada. A entrada fica cifrada enquanto necessária e é limpa ao encerrar.

## Saltos e limites

| Salto | Alcance |
| --- | --- |
| Captura | Validação dos campos e repositório real do Core; não comprova navegador, desafio antispam ou integração nativa externa. |
| Aviso Slack | Somente transporte app configurado com leitura/exclusão autoral; IDs e prova são guardados. |
| Aviso e-mail | Bloqueado antes do envio enquanto a exclusão individual da caixa não puder ser comprovada. |
| Aviso webhook | Bloqueado antes do envio sem contrato de limpeza do receptor. |
| Pipedrive | Só integração ativa e site autorizado; consulta objeto criado, campos comerciais e atividade vinculada. |
| E-mail automático | Bloqueado antes do envio pela ausência de exclusão individual segura da cópia Smart BCC. |
| Conversões | Somente prévia por destino; os IDs do teste são bloqueados nas filas/transportes reais. |

Pipedrive real só pode ser exercitado em `ctooffice.com.br` e `korvena.com.br`, conforme decisão do dono. Site-Teste recebe o salto bloqueado por esse limite ou por integração desligada. Não ativar a integração ou conceder conta para contornar o bloqueio.

A homologação é uma autorização temporária restrita ao registro em execução. A opção global `f3base_pipedrive.homologacao` conserva seu valor antes, durante e depois, evitando que filas de outros contatos sejam afetadas. Isso equivale ao escopo solicitado sem abrir uma janela global para terceiros.

## Diário e limpeza

Cada salto é reservado duravelmente antes de produzir efeito. Um processo interrompido após a reserva passa a `incerto`, sem repetir o efeito. O worker continua o mesmo ciclo lógico pelas próximas passagens e mantém o recibo consultável; “mesmo ciclo” não significa uma única requisição HTTP. O atraso normal de preparação da comunicação é respeitado.

Limpeza usa apenas IDs registrados no diário, com releitura de autoria. Slack usa a operação de apagar mensagens de teste. Contato local é eliminado pelo fluxo próprio; Pipedrive usa seu diário de objetos e prova de propriedade. Pessoa/organização preexistentes não são apagadas; organização só é elegível se o teste a criou. Falha ou incerteza de exclusão fica visível; não declarar ausência de resíduos sem prova. Não repetir criação externa para tentar compensar limpeza falha.

`f3base/caminho-lead-limpar` permite reautorizar somente a limpeza após suspensão, revogação ou resultado parcial. Exige `manage_options` e `f3base_gerir_leads`; recebe `id` de 64 caracteres hexadecimais. A simulação é padrão e devolve uma revisão SHA-256. Para agir, enviar a revisão e uma `chave_operacao` de 8–128 caracteres. O administrador atual assume a autorização de limpeza dos IDs conhecidos; captura e envios não são retomados. Resultados confirmados ou incertos são preservados, e um DELETE já reservado não é repetido. Um bloqueio conhecido de limpeza pode ser reavaliado. A operação não depende da entrada cifrada original, que pode já ter sido descartada ou estar ilegível.

Os estados finais distinguem `concluido` e `com_pendencias`. Enquanto e-mail/webhook não dispuserem de contrato de limpeza segura, o teste completo termina com pendências explícitas mesmo que os demais saltos e limpezas tenham sucesso. O pedido não está integralmente homologado por esse resultado. Recebimento e limpeza real em conta/Slack/caixa exigem execução autorizada e evidência do responsável.
