> Consolidação 1.57.1: leia RELEASE-1.57.1.md para as correções e campos opcionais dos pedidos 312/313. Base direta canônica 1.57.0.

# Validação 1.57.1

O relatório externo descreve as provas efetivamente concluídas e suas limitações. request-312.php usa SDK Meta original, webhook assinado sintético, consumidor Core real, exclusão, leitura do tombstone, mesmo recibo na repetição, transação aberta e retomada. request-313.php usa SDK Google original e transporte controlado para trinta dias, paridade com ga/run-report, paginação, vazios/lacunas, retomada, qualidade, cota e revogação. review-1570.php exercita publicação, persistência, transação sem commit implícito, retenção finita e interface. permissions-1570.php e docs-1570.php verificam autorização e documentação, também com MCP real.

Instalação limpa e atualização direta usam Plugin_Upgrader nativo. Evidências do fonte informam WordPress/PHP e o escopo de cada fixture. Testes com fornecedores interceptados não comprovam credenciais ou dados reais. O aceite real GA4 de trinta dias, ausência/declaração de (other) em fator3.com.br e homologações de conversas com fornecedor continuam dependentes dos ambientes autorizados e configurados. Não presumir publicação da frota nem envio comercial.
