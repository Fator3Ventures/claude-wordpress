# Meta Ads — campanhas, parceiros e contatos no Core 1.58.0

Consumidor de `meta-ads-reader/1.0.0`, entregue pelo Fator3 MCP Meta 0.13.0. Referência: impacto Meta 0.13.0 → Core, revisão 2, Meta20(e). Não é um novo número de pedido Core.

## Responsabilidades e autorização

O Meta coleta e conserva os fatos diários de anúncios. O Core lê esse acervo pelo cliente registrado no hook `f3_meta_register_ads_consumers` e acrescenta a relação local com contatos e o parceiro explicitamente configurado. Não acessa opções, tabelas ou tokens privados do Meta; não faz Graph, não agenda coleta, não cria campanhas e não concede acesso automaticamente. A configuração permanece desligada por padrão.

Configuração e estado exigem `manage_options`. O relatório exige também `f3base_ler_leads`, inclusive na chamada direta PHP e na ability. O fornecedor revalida a concessão, sua origem administrativa, o transporte usado na concessão e a seleção da conta. Expiração do token não apaga nem impede por si só a leitura local já concedida; revogação ou troca de identidade bloqueia a leitura. O SDK pode registrar auditoria local da consulta; isso não altera a configuração nem os anúncios.

## Configuração

1. No MCP Meta, selecione a conta de anúncios e obtenha o acervo pelo fluxo próprio de coleta/backfill/agendas. Verifique a cobertura e os campos disponíveis.
2. Configure `f3base_meta_ads` pelo fluxo administrativo do Core, com revisão corrente. A conta é uma string numérica sem `act_`.
3. Em Ferramentas → Fator3 MCP Meta → Consumidores de anúncios, conceda a leitura ao consumidor `base-site-core-fator3` para a mesma conexão/conta. Não presuma a revisão da concessão; consulte-a antes de salvar.
4. Consulte `f3base/meta-ads-status`. `pronto` depende de configuração e concessão, não comprova uma coleta real nem dados completos no acervo.

Exemplo de valor da option:

```json
{
  "ativo": true,
  "revisao": 1,
  "conexao": "conta-meta",
  "conta_id": "1234567890123456",
  "parceiros": [
    {
      "campanha_id": "2345678901234567",
      "parceiro_id": "parceiro-codigo-estavel",
      "rotulo": "Parceiro"
    }
  ]
}
```

Cada campanha aparece no máximo uma vez no mapa. `parceiro_id` é o identificador estável escolhido pelo administrador; `rotulo` é texto de apresentação. O mapa pertence à conta selecionada, e campanhas sem mapa retornam `sem_mapa_explicito`. O Core não infere parceiro pelo nome da campanha. O campo `revisao` começa em 0 com a leitura desligada e deve ser positivo ao habilitar. Aumente-o em cada alteração de seleção ou mapa, junto com o novo valor da option. O Core recusa diminuir ou reutilizar a geração ao mudar os valores; restaurar A depois de A → B também exige uma nova geração. Ela é persistida atomicamente com a seleção e compõe a revisão do consumidor. Modificar a configuração exige renovar a concessão Meta. Alterar a conta não reutiliza autorização nem paginação anteriores.

## Consulta e continuação

`f3base/meta-ads-relatorio-ler` recebe `de` e `ate` (AAAA-MM-DD), `limite` entre 1 e 100 (padrão 50) e `cursor` opcional. O período aceita até 366 dias; a leitura local de contatos examina no máximo 10.000 registros no período expandido necessário para os fusos. Acima desse limite retorna `reduza_periodo_contatos`, sem produzir contagens parciais.

```json
{"de":"2026-09-01","ate":"2026-09-30","limite":50}
```

Passe `proximo_cursor` como `cursor`, mantendo datas e limite. A continuação é firmada e vincula seleção, revisão da configuração, revisão da coorte de contatos, concessão e geração do histórico Meta. Tem validade de um dia. Nunca concatene páginas depois de `history_changed`, `revision_conflict`, `contatos_alterados`, `configuracao_alterada` ou `cursor_expired`: descarte o conjunto e inicie novamente sem cursor. A resposta de falha não contém linhas aproveitáveis.

`pagina_final:true` significa que terminou a paginação das observações armazenadas para a seleção. Não comprova cobertura de todos os dias nem de todos os dados disponíveis no fornecedor. O Core não copia esse acervo para uma segunda tabela: uma revisita Meta substitui a observação na identidade canônica, e a nova consulta reflete a revisão sem acumular gasto novamente.

## Identidade, valores e relação com contatos

O relatório consulta exclusivamente o nível `campaign`. A identidade Meta inclui conexão, conta, nível, entidade, dia, atribuição, moeda e fuso. `row_id`, `observations`, `first_seen`, `last_seen`, `coverage`, `selection`, `currency` e `timezone` acompanham cada linha. Nomes permanecem rótulos do instante observado.

O Core acrescenta `relacao_core`, com plataforma `meta_ads`, conta, campanha, parceiro e contagem de contatos. Só relaciona contatos aceitos, fora da lixeira/exclusão, sem marca de teste ou audiência excluída, com conta e campanha identificadas no registro. Não atribui uma conta ausente por coincidência de nome. O dia do contato é o instante da captura convertido ao fuso da linha Meta. Isso não reproduz a janela de atribuição da plataforma.

`registros_aceitos` conta registros. `pessoas_por_identificadores` agrupa e-mail/telefone exatos no recorte de cada linha, incluindo ligações transitivas; não prova identidade civil. Registros sem identificador contam individualmente em `sem_identificador`. Nenhum e-mail, telefone, hash desses dados ou `record_id` é retornado pelo relatório. As contagens são por linha e não devem ser somadas entre dias/moedas para obter pessoas únicas do período.

Dinheiro e contagens do fornecedor permanecem strings. O Core não converte moedas e não agrega automaticamente as páginas. Uma campanha com observações em moedas ou fusos distintos conserva linhas distintas. Alcance e frequência não são somáveis entre dias/entidades. `actions`, `results`, `cost_per_action_type` e `cost_per_result` preservam os tipos originais; o agregado `lead` pode se sobrepor a `leads_native` e `leads_website` e não deve ser somado a eles. Não existe escolha artificial de resultado principal.

Ausência corrente permanece `null`. `last_available_fields` mantém cada último valor não nulo com seu instante próprio; `last_successful_observation` é uma observação integral anterior. Nenhum deles substitui silenciosamente o valor corrente. Um dia sem linhas não gera zero nem apaga linhas antigas: confira `last_seen` e cobertura antes de concluir que não houve gasto/resultado.

## Falhas, operação e reversão

Sem seleção ou SDK, retorna `configuracao_pendente` ou `sdk_ausente`. Sem concessão, retorna `grant_revoked`. Mudança de conta/identidade/configuração pode retornar `revision_conflict` ou erro de concessão; reautorize no Meta depois de conferir a seleção. Resposta incompatível não produz dados ou totais parciais. Leituras limitadas ou indisponíveis mantêm motivo explícito.

Não há tabela, cron ou migração de dados próprios deste consumidor. Desligar `f3base_meta_ads.ativo` interrompe novas consultas, sem apagar o acervo Meta. Antes de reverter o Core para 1.57.1, desligue a configuração e revogue a concessão do consumidor no Meta. A base anterior não registra o leitor; dados Meta permanecem sob sua política.

## Validação

`tests/meta-ads-0130.php` exercita WordPress nativo e o SDK/armazenamento reais do Meta 0.13.0 com observações sintéticas: concessão explícita, 30 dias paginados, moedas separadas, exclusão do nível anúncio, relação por IDs/fuso/parceiro, revisão de dia sem duplicação, valor anterior datado, revogação, identidade alterada e continuação consistente. HTTP e e-mail externos são bloqueados. A execução coordenada final desta rodada aprovou 41 verificações, incluindo geração monotônica e rejeição de restauração de revisão antiga, com SDK Meta 0.13.0 e MCP 0.34.0 reais no WordPress descartável; evidência em `evidence/1580/meta-ads-0130.json` no fonte. Os 30 dias e os contatos são sintéticos, sem HTTP ao fornecedor nem envio de e-mail. A primeira tentativa detectou a ausência de `connection_id` no envelope de ingestão da fixture; corrigida a entrada de teste, a suíte foi repetida com aprovação. O runtime não foi flexibilizado para aceitar uma partição divergente.

A comparação real dos mesmos 30 dias contra Ads Manager em ctooffice.com.br e korvena.com.br continua dependente de implantação, conta/credencial e autorização do operador/frota. As fixtures e o Site-Teste sem conta não substituem esse aceite.
