<?php

declare (strict_types=1);
namespace F3BaseEmailVendor\DI\Definition;

/**
 * @author Matthieu Napoli <matthieu@mnapoli.fr>
 */
class AutowireDefinition extends ObjectDefinition
{
}
