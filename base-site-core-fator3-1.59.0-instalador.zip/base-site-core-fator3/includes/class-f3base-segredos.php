<?php
/** Segredos de terceiros cifrados no banco, vinculados ao site e ao nome da opção. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Segredos {
    const PREFIXO='f3sec:v1:';
    private static array $avisos=array();
    public static function avisos_normalizacao(string $v): array {
        if($v===trim($v)){return array();}$out=array(array('regra'=>'espacos_extremidades','motivo'=>'Espaços nas extremidades foram removidos da credencial usada.'));
        if(preg_match('/^[\r\n\t ]*[\r\n]|[\r\n][\r\n\t ]*$/D',$v)){$out[]=array('regra'=>'quebra_linha_extremidade','motivo'=>'Quebra de linha na extremidade foi removida.');}return $out;
    }
    public static function avisos_leitura(string $n): array {return self::$avisos[$n]??array();}
    private static function normalizar(string $n,string $v): string {self::$avisos[$n]=self::avisos_normalizacao($v);return trim($v);}
    const NOMES=array('f3base_email_site_senha','f3base_email_novo_lead_smtp_senha','f3base_meta_crm_token','f3base_pipedrive_webhook_segredo','f3base_slack_bot_token','f3base_avisos_webhook_url','f3base_avisos_webhook_chave','f3base_slack_webhook','f3base_clarity_api_token','f3base_meta_capi_token','f3base_pipedrive_token','f3base_anuncios_meta_token','f3base_anuncios_google_chave','f3base_anuncios_linkedin_token','f3base_anuncios_linkedin_client_secret');
    public static function recusar(string $nome,$v): string {if(!is_string($v)){return 'Informe uma credencial textual.';}$v=trim($v);if(strlen($v)>8192||preg_match('/[\x00-\x1f\x7f]/',$v)){return 'Credencial inválida: remova controles e confira o valor.';}if(in_array($nome,array('f3base_email_novo_lead_smtp_senha','f3base_email_site_senha'),true)){return '';}if($nome==='f3base_avisos_webhook_url'){return $v===''||F3Base_Avisos::webhook_url_valida($v)?'':'Use URL HTTPS pública, sem credenciais, porta, query ou fragmento.';}if($nome==='f3base_avisos_webhook_chave'&&$v!==''&&!preg_match('/^[A-Za-z0-9_-]{32,256}$/D',$v)){return 'Use chave aleatória de 32 a 256 caracteres: letras, números, hífen ou sublinhado.';}if($nome==='f3base_slack_webhook'){return $v===''||F3Base_Avisos::url_valida($v)?'':'Use a URL HTTPS exata de Incoming Webhook do Slack, sem porta, credenciais, query ou fragmento.';}if(self::gerenciado($nome)&&$v!==''&&(preg_match('/\s/u',$v)||preg_match('~^(?:https?://|(?:Bearer|Basic)[ :]|x-api-token:|api[_-]?token[:=])~i',$v))){return 'Cole somente a credencial, sem espaços internos, URL ou prefixo de cabeçalho. Depois verifique o acesso à conta.';}return F3Base_Credenciais::formato($nome,$v);}
    public static function motivo_seguro(string $nome,$valor): array {$m=self::recusar($nome,$valor);return array('codigo'=>$m===''?'formato_local_aceito':(!is_string($valor)?'credencial_tipo_invalido':(strlen($valor)>8192?'credencial_tamanho_excedido':(preg_match('/[\x00-\x1f\x7f]/',$valor)?'credencial_controles':'credencial_conteudo_invalido'))),'motivo'=>$m);}
    public static function gerenciado(string $nome): bool{return in_array($nome,self::NOMES,true);}
    public static function chave(string $nome): string {return hash_hkdf('sha256',wp_salt('secure_auth'),32,'f3base:segredos:v1:'.$nome,'f3base-secretbox');}
    public static function cifrar(string $nome,string $valor): string {
        $valor=trim($valor);if($valor===''){return '';}
        if(!self::gerenciado($nome)||!function_exists('sodium_crypto_secretbox')){throw new RuntimeException('cifra_indisponivel');}
        $nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return self::PREFIXO.base64_encode($nonce.sodium_crypto_secretbox($valor,$nonce,self::chave($nome)));
    }
    public static function abrir(string $nome,?string $cipher=null): string {
        self::$avisos[$nome]=array();
        if($cipher===null){$proposta=F3Base_Options::segredo_proposto($nome);if($proposta!==null){return self::normalizar($nome,$proposta);}}
        $cipher=$cipher??get_option($nome,'');if(!is_string($cipher)||$cipher===''||!self::gerenciado($nome)||!str_starts_with($cipher,self::PREFIXO)||!function_exists('sodium_crypto_secretbox_open')){return '';}
        $v=base64_decode(substr($cipher,strlen(self::PREFIXO)),true);
        if($v===false||strlen($v)<SODIUM_CRYPTO_SECRETBOX_NONCEBYTES+SODIUM_CRYPTO_SECRETBOX_MACBYTES){return '';}
        try{$p=sodium_crypto_secretbox_open(substr($v,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),substr($v,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),self::chave($nome));return is_string($p)?self::normalizar($nome,$p):'';}catch(Throwable $e){return '';}
    }
    public static function status(string $nome): array {
        $v=get_option($nome,'');$present=is_string($v)&&$v!=='';
        return array('presente'=>$present,'versao'=>$present&&str_starts_with($v,self::PREFIXO)?1:null,'estado'=>!$present?'ausente':(self::abrir($nome)!==''?'disponivel':'recadastrar'));
    }
}
