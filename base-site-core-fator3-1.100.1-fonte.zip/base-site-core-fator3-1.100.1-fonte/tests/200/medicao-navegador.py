"""Exercita os controles de Medição em um WordPress local com e sem JavaScript."""
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from playwright.sync_api import sync_playwright

sessao = json.loads(Path(sys.argv[1]).read_text())
base = sessao['origem']
assert urlsplit(base).hostname == '127.0.0.1' and os.environ.get('F3LAB_DB') == 'core_200_medicao'
rota = base + '/wp-admin/admin.php?page=f3base-medicao'
saida = []
with sync_playwright() as pw:
    chrome = pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-sandbox','--disable-dev-shm-usage'])
    for usar_js in (True, False):
        ctx = chrome.new_context(java_script_enabled=usar_js,locale='pt-BR')
        ctx.add_cookies([{'name':k,'value':v,'url':base} for k,v in sessao['cookies'].items()])
        ctx.route('**/*',lambda r:r.continue_() if urlsplit(r.request.url).hostname=='127.0.0.1' else r.abort())
        pg = ctx.new_page()
        pg.set_default_timeout(15000)
        def ativar(controle):
            if usar_js: controle.click()
            else:
                controle.focus()
                controle.press('Enter')
            pg.wait_for_load_state('domcontentloaded')
        pg.goto(rota+'&area=conteudo')
        ativar(pg.locator('.f3-switch button[value=artigo]'))
        assert pg.locator('.f3-switch button[value=artigo]').get_attribute('aria-pressed')=='true'
        ativar(pg.get_by_role('link',name='Conversão',exact=True))
        pg.locator('select[name=visao]').select_option('formularios')
        ativar(pg.get_by_role('button',name='Atualizar relatório'))
        assert parse_qs(urlsplit(pg.url).query)['visao']==['formularios']
        assert pg.locator('select[name=visao]').input_value()=='formularios'
        pg.goto(base+'/wp-admin/admin.php?page=f3base-relatorios&visao=formularios&de=2026-11-15&ate=2026-11-18')
        qs = parse_qs(urlsplit(pg.url).query)
        assert qs['area']==['conversao'] and qs['visao']==['formularios'] and qs['de']==['2026-11-15'] and qs['ate']==['2026-11-18']
        pg.goto(rota+'&area=comportamento&visao=tempo')
        assert pg.locator('select[name=visao]').input_value()=='tempo'
        pg.locator('select[name=visao]').select_option('sessoes')
        ativar(pg.get_by_role('button',name='Atualizar relatório'))
        assert pg.locator('select[name=visao]').input_value()=='sessoes'
        saida.append('Troca de análise, período e destinos históricos '+('com JS' if usar_js else 'sem JS'))
        if usar_js:
            detalhe = pg.locator('details').filter(has=pg.locator('summary',has_text='Gerenciar períodos de teste conhecidos'))
            detalhe.locator('summary').first.click()
            assert detalhe.locator('tbody tr:visible').count()==20
            detalhe.get_by_role('button',name='Próxima',exact=True).click()
            assert detalhe.locator('tbody tr:visible').count()==6
            detalhe.get_by_role('searchbox').fill('qa-core-200-medicao-14')
            assert detalhe.locator('tbody tr:visible').count()==1
            assert detalhe.locator('.f3-list-total').inner_text()=='1–1 de 1'
            detalhe.get_by_role('searchbox').fill('Palavra que não está nas anotações')
            assert detalhe.locator('.f3-list-total').inner_text()=='0 resultados'
            saida.append('26 anotações em páginas de 20 e 6, busca por uma linha e estado sem correspondências')
            editar=detalhe.locator('p',has_text='qa-core-200-medicao-14').get_by_role('link',name='Editar',exact=True)
            editar.click()
            perigo=pg.locator('details.f3-danger')
            perigo.locator('summary').click()
            confirmar=perigo.get_by_role('checkbox',name='Confirmar exclusão')
            assert confirmar.is_visible() and not confirmar.is_checked()
            perigo.get_by_role('button',name='Excluir anotação').click()
            assert confirmar.evaluate('(c) => c.validity.valueMissing')
            confirmar.check()
            perigo.get_by_role('button',name='Excluir anotação').click()
            assert pg.locator('.f3-result[role=status]').inner_text().startswith('Alteração registrada')
            assert pg.locator('p',has_text='qa-core-200-medicao-14').count()==0
            saida.append('Anotação editável, confirmação obrigatória, exclusão local gravada e recibo de resultado')
        ctx.close()
    chrome.close()
print(json.dumps({'wordpress':'7.1.4','verificadas':saida},ensure_ascii=False,indent=2))
