"""Confere o plugin ativo em disco com os membros do instalador usado na prova."""
from pathlib import Path
import hashlib, json, sys, zipfile

arquivo, plugin, destino=map(Path,sys.argv[1:4])
sha=lambda dados:hashlib.sha256(dados).hexdigest()
with zipfile.ZipFile(arquivo) as z:
    nomes={n.removeprefix('base-site-core-fator3/'):n for n in z.namelist() if not n.endswith('/')}
    disco={p.relative_to(plugin).as_posix() for p in plugin.rglob('*') if p.is_file()}
    if disco!=set(nomes): raise SystemExit('Inventário em disco divergente do instalador.')
    for nome,entrada in nomes.items():
        if (plugin/nome).read_bytes()!=z.read(entrada): raise SystemExit('Conteúdo divergente: '+nome)
    dados={'instalador':arquivo.name,'sha256':sha(arquivo.read_bytes()),'bytes':arquivo.stat().st_size,'arquivos_identicos':len(nomes),'wordpress':sys.argv[4],'php':sys.argv[5],'aviso_ativo':'aviso-ensaio.php','materiais_sinteticos':27}
    destino.write_text(json.dumps(dados,ensure_ascii=False,indent=2)+'\n')
