#!/usr/bin/env bash
# Executar somente numa instalação WordPress descartável com servidor HTTP local ativo.
set -euo pipefail
dir=$(cd "$(dirname "$0")" && pwd)
: "${QA_SITE:?Diretório raiz do WordPress descartável}"
: "${F3_ZIP_FINAL:?Caminho do instalador definitivo}"
: "${F3_QA_CHROME:?Executável do Chromium para o Playwright}"
: "${QA_SAIDA200:?Diretório das evidências}"
: "${QA_CADERNO200:?Destino do caderno HTML}"
cli(){ wp --path="$QA_SITE" --user=1 "$@"; }
cli eval 'if(wp_get_environment_type()!=="local" || DB_NAME!=="core_200_visuais" || wp_parse_url(home_url(),PHP_URL_HOST)!=="127.0.0.1") throw new RuntimeException("Ambiente local descartável obrigatório.");'
export F3LAB_DB=core_200_visuais PYTHONDONTWRITEBYTECODE=1
mkdir -p "$QA_SAIDA200"
cli plugin install "$F3_ZIP_FINAL" --force --activate
cli eval 'F3Base_Zelador::atualizacao_urgente(); if(F3Base_Instalacao::resumo()["estado"]!=="concluida") throw new RuntimeException("Instalação incompleta");'
cp "$dir/aviso-ensaio.php" "$QA_SITE/wp-content/plugins/aviso-ensaio.php"
cli plugin activate aviso-ensaio --quiet
cli option update blogname 'Site de homologação' --quiet
cli option update show_avatars 0 --quiet
cli user update 1 --display_name=Operador --quiet
cli user meta update 1 show_welcome_panel 0 --quiet
cli eval-file "$dir/materiais.php"
python3 "$dir/identidade.py" "$F3_ZIP_FINAL" "$QA_SITE/wp-content/plugins/base-site-core-fator3" "$QA_SAIDA200/origem.json" "$(cli core version)" "$(php -r 'echo PHP_VERSION;')"
QA_SESSAO200=$(mktemp)
export QA_SESSAO200
trap 'rm -f "$QA_SESSAO200"' EXIT
cli eval-file "$dir/sessao.php" > "$QA_SESSAO200"
for QA_MODO200 in oficial tema sem-js expandido; do
 export QA_MODO200
 esquema=fresh
 [[ "$QA_MODO200" != tema ]] || esquema=modern
 cli user meta update 1 admin_color "$esquema" --quiet
 python3 "$dir/capturar.py"
done
python3 "$dir/conferir.py" "$QA_SAIDA200" "$F3_ZIP_FINAL"
python3 "$dir/caderno.py" "$QA_SAIDA200" "$QA_CADERNO200"
