"""Capturas e medição das telas administrativas do Core em WordPress real de loopback."""
from pathlib import Path
from urllib.parse import urlsplit
from io import BytesIO
import json,os,re,sys,hashlib
from PIL import Image
from playwright.sync_api import sync_playwright
from rotas import ROUTES

if os.environ.get('F3LAB_DB')!='core_200_visuais': raise SystemExit('Instalação local obrigatória')
base=Path(__file__).resolve().parent
out=Path(os.environ['QA_SAIDA200'])
sessao=json.loads(Path(os.environ['QA_SESSAO200']).read_text())
origin=sessao['origem']
if urlsplit(origin).hostname!='127.0.0.1': raise SystemExit('Use loopback.')
medir=(base/'medir.js').read_text()
modo=os.environ.get('QA_MODO200','oficial')
group_filter=os.environ.get('QA_GRUPO200','')
routes=[x for x in ROUTES if not group_filter or x[1]==group_filter or x[0]==group_filter]
if not routes:raise SystemExit('Grupo desconhecido')
default_heights={360:800,768:960,1440:1000}
out.mkdir(exist_ok=True,parents=True)
images=out/'capturas'
images.mkdir(exist_ok=True)
proof_path=out/'origem.json'
tested_hash=json.loads(proof_path.read_text())['sha256'] if os.environ.get('F3_ZIP_FINAL') and proof_path.exists() else None
dest=out/(modo+'.json')
results=json.loads(dest.read_text()) if dest.exists() else {}
def save():
    tmp=dest.with_suffix('.tmp')
    tmp.write_text(json.dumps(results,ensure_ascii=False,indent=1)+'\n')
    tmp.replace(dest)

def foco(pg):
    selectors={"nav":".f3-nav a","botao":"button:not([disabled]),.button:not([disabled])","campo":"input:not([type=hidden],[type=submit],[disabled]),select:not([disabled]),textarea:not([disabled])","resumo":"summary"}
    data={}
    # Localiza um representante visível e utiliza Shift+Tab, Tab pelo teclado real.
    for kind,selector in selectors.items():
        locator=pg.locator('.f3-ui').first.locator(selector)
        index=locator.evaluate_all("""xs=>xs.findIndex(e=>e.checkVisibility({contentVisibilityAuto:true,visibilityProperty:true})&&e.getBoundingClientRect().height>0&&!e.closest('fieldset[disabled]')&&!e.disabled)""")
        if index<0: continue
        h=locator.nth(index)
        h.focus()
        pg.keyboard.press('Shift+Tab')
        pg.keyboard.press('Tab')
        data[kind]=h.evaluate("""el=>{const s=getComputedStyle(el);return {teclado:document.activeElement===el,visivel:el.matches(':focus-visible'),largura:parseFloat(s.outlineWidth),estilo:s.outlineStyle,cor:s.outlineColor};}""")
    pg.evaluate("()=>{document.activeElement.blur();window.scrollTo(0,0)}")
    return data

def picture(pg,key,width,conteudo=False):
    if conteudo:
        pg.evaluate("""() => {const e=document.querySelector('.f3-nav');if(e)window.scrollTo(0,Math.max(0,e.getBoundingClientRect().bottom+window.scrollY-65));}""")
    else: pg.evaluate('window.scrollTo(0,0)')
    img=Image.open(BytesIO(pg.screenshot(animations='disabled',timeout=30000))).convert('RGB')
    f=images/(key+'-'+str(width)+('-conteudo' if conteudo else '')+'.webp')
    img.save(f,'WEBP',quality=85,method=4)
    return {'arquivo':f.relative_to(out).as_posix(),'pixels':list(img.size),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}

with sync_playwright() as pw:
    chrome=pw.chromium.launch(executable_path=os.environ.get('F3_QA_CHROME','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=chrome.new_context(viewport={'width':1440,'height':1000},locale='pt-BR',timezone_id='America/Sao_Paulo',java_script_enabled=modo!='sem-js',device_scale_factor=1)
    ctx.add_cookies([{'name':k,'value':v,'url':origin} for k,v in sessao['cookies'].items()])
    # Bloqueia rede externa também no processo de navegador.
    ctx.route('**/*', lambda route: route.continue_() if urlsplit(route.request.url).hostname=='127.0.0.1' else route.abort())
    pg=ctx.new_page()
    pg.set_default_timeout(16000)
    pg.on('dialog', lambda d:d.accept())
    if modo=='oficial':
        response=pg.goto(origin+'/wp-admin/index.php',wait_until='load')
        styles=pg.evaluate("""()=>Array.from(document.styleSheets).map(s=>s.href||'').filter(x=>x.includes('/plugins/base-site-core-fator3/')).map(x=>new URL(x).pathname.split('/base-site-core-fator3/').pop())""")
        (out/'painel-wordpress.json').write_text(json.dumps({'pagina':'wp-admin/index.php','http':response.status,'folhas_do_core':styles},ensure_ascii=False,indent=2)+'\n')
    for key,grupo,label,path in routes:
        resp=pg.goto(origin+path,wait_until='load',timeout=45000)
        res={'grupo':grupo,'subaba':label,'url':path,'http':resp.status if resp else 0,'medicoes':[],'chromium':chrome.version,'instalador_sha256':tested_hash}
        results[key]=res
        if modo=='expandido':
            res['blocos_abertos']=pg.evaluate("""()=>{const nodes=Array.from(document.querySelectorAll('.f3-ui details'));nodes.forEach(e=>e.open=true);return nodes.length;}""")
        for larg in ([360,768,1440] if modo in ('oficial','ensaio','expandido') else [1440]):
            pg.set_viewport_size({'width':larg,'height':default_heights[larg]})
            pg.evaluate('document.fonts.ready')
            m=pg.evaluate(medir,dict(largura=larg,grupo=grupo,aba=label))
            if m['campos_sensiveis']: raise RuntimeError('Campo sigiloso preenchido num ambiente sintético: '+key)
            if modo=='oficial':
                m['captura']=picture(pg,key,larg)
                if larg==360: m['conteudo']=picture(pg,key,larg,True)
                pg.evaluate('window.scrollTo(0,0)')
            if modo=='tema' and key in ('cfg-inicio','med-geral'): m['captura']=picture(pg,key+'-moderno',larg)
            res['medicoes'].append(m)
        if modo in ('oficial','ensaio'):
            res['foco']=foco(pg)
            if key=='cont-conteudos' and pg.locator('.f3-list-tools').count():
                form=pg.locator('.f3-list-tools').first
                total=form.locator('.f3-list-total').inner_text()
                next_page=form.locator('a').filter(has_text='Próxima')
                if next_page.count():
                    next_page.first.click()
                    current=pg.locator('.f3-list-tools .f3-list-total').inner_text()
                    search=pg.locator('.f3-list-tools input[type=search]')
                    search.fill('material-de-ensaio-12')
                    search.press('Enter')
                    pg.wait_for_load_state()
                    section=pg.locator('.f3-table-scroll').last
                    res['lista_grande']={'primeira':total,'segunda':current,'resultado_busca':section.locator('tbody tr').count(),'termo_encontrado':'material-de-ensaio-12.txt' in section.inner_text()}

        if modo=='sem-js':
            # O navegador segue o link real de subaba/grupo com JavaScript desativado.
            target=pg.locator('.f3-nav a:not([aria-current])').first
            if target.count():
                href=target.get_attribute('href')
                with pg.expect_navigation(wait_until='domcontentloaded'): target.click()
                res['navegacao_html']=urlsplit(pg.url).query==urlsplit(href).query
            else: res['navegacao_html']=False
        save()
        print(modo,key,flush=True)
    ctx.close(); chrome.close()
