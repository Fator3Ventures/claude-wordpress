"""Publica um caderno HTML offline, com capturas WebP incorporadas e auditadas."""
from base64 import b64encode
from hashlib import sha256
from html import escape
from io import BytesIO
from pathlib import Path
from PIL import Image
import json,sys

d,destino=map(Path,sys.argv[1:3])
def read(n):return json.loads((d/(n+'.json')).read_text())
matrix,of,theme=map(read,['matriz','oficial','tema'])
orig=matrix['origem']
e=escape
routes=matrix['rotas']
groups={x['grupo']:[] for x in routes}
for r in routes:groups[r['grupo']].append(r)
count=sum(1 for r in routes for c in r['criterios'].values() if c['atendido'])
criteria=[c['titulo'] for c in routes[0]['criterios'].values()]
def figure(data,name,class_name=''):
    image=(d/data['arquivo']).read_bytes()
    if sha256(image).hexdigest()!=data['sha256'] or list(Image.open(BytesIO(image)).size)!=data['pixels']:
        raise ValueError('Fotografia divergente: '+data['arquivo'])
    mime='data:image/webp;base64,'+b64encode(image).decode()
    w,h=data['pixels']
    return f'<figure class="{class_name}"><figcaption>{e(name)} <span>{w} × {h} px</span></figcaption><a href="#ampliar" class="ampliar" aria-label="Ampliar {e(name,quote=True)}"><img loading="lazy" width="{w}" height="{h}" alt="{e(name,quote=True)}" src="{mime}"></a></figure>'
parts=['''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fator3 Site Core 1.100.1 · Prova visual</title><style>
:root{color-scheme:light;--ink:#142c38;--blue:#176b76;--pale:#e8f3f1;--rule:#cbdad9;--paper:#fff;--muted:#465c64}*{box-sizing:border-box}body{margin:0;background:#f3f6f5;font:16px/1.5 system-ui,sans-serif;color:var(--ink)}main,header>div{max-width:1370px;margin:auto;padding:22px clamp(16px,3.3vw,50px)}header{background:#10333f;color:white;border-bottom:6px solid #47b49c}header>div{padding-top:48px;padding-bottom:42px}h1,h2,h3,p{margin:0 0 .6em}h1{font:600 clamp(32px,5vw,65px)/1.08 Georgia,serif;letter-spacing:-.035em}header small{text-transform:uppercase;letter-spacing:.12em}h2{font:500 clamp(25px,3vw,40px)/1.15 Georgia,serif;margin-top:.5em}h3{font-size:23px}a{color:#075e72;text-underline-offset:3px}a:focus-visible,summary:focus-visible,button:focus-visible{outline:3px solid #b14800;outline-offset:3px}code{font-size:.85em;overflow-wrap:anywhere}.meta{display:flex;gap:12px 30px;flex-wrap:wrap;margin-top:22px}.meta span{font-size:14px;color:#dff0ec}.indices,.screen,.paleta{border:1px solid var(--rule);background:var(--paper);border-radius:9px;margin:18px 0;padding:clamp(14px,2.3vw,32px)}.indexgrid{display:grid;gap:1.5em;grid-template-columns:repeat(auto-fit,minmax(175px,1fr))}ul{padding-left:1.2em}.indexgrid ul{margin:.3em 0}.indexgrid b{display:block}.matrix{overflow-x:auto;margin:14px 0}table{width:100%;border-collapse:collapse;font-size:12px;text-align:center}th,td{padding:5px;border:1px solid var(--rule)}th:first-child{text-align:left;min-width:175px;position:sticky;left:0;background:#fff}thead th{background:#e6eeed}.pass{color:#075647;background:#eef8f4}.fail{color:#8d271d;background:#fcece7}.criteria{columns:2;column-gap:25px;padding-left:1.5em;font-size:14px}.criteria li{break-inside:avoid}.gallery{display:grid;grid-template-columns:minmax(0,.48fr) minmax(0,.48fr) minmax(0,.78fr) minmax(0,1.32fr);gap:14px}figure{margin:0;min-width:0}figcaption{font-size:13px;font-weight:650;margin:0 0 5px;color:var(--ink)}figcaption span{display:block;color:var(--muted);font-size:11px;font-weight:500}figure img{width:100%;height:auto;display:block;outline:1px solid var(--rule);border-radius:3px}.ampliar{display:block;cursor:zoom-in;min-height:40px}.meta2{font-size:13px;color:var(--muted)}.screen{scroll-margin:10px}.toscroll{margin:40px 0 8px}summary{cursor:pointer;font-weight:650;padding:.55em 0}.details-list{list-style:decimal;padding-left:1.6em}.details-list li{padding:3px}.details-list b{margin-right:5px}.back{display:inline-block;margin-top:16px}.paleta .gallery{grid-template-columns:repeat(2,minmax(0,1fr))}dialog{border:0;border-radius:8px;padding:10px;max-width:97vw;max-height:96vh;background:#f6f8f7}dialog::backdrop{background:#0b1924c7}dialog img{display:block;max-width:min(92vw,1440px);height:auto}dialog button{position:sticky;top:0;display:block;margin:0 0 .4em auto;padding:8px 15px;cursor:pointer}footer{border-top:1px solid var(--rule);font-size:13px;padding:18px 0;color:var(--muted)}
@media(max-width:900px){.gallery{grid-template-columns:1fr 1fr}.criteria{columns:1}}@media(max-width:560px){.gallery,.paleta .gallery{grid-template-columns:1fr 1fr;gap:12px}.gallery figure:nth-child(n+3){grid-column:1/-1}.paleta .gallery figure{grid-column:1/-1}.screen{padding:10px}.indexgrid{grid-template-columns:1fr 1fr}.indices{padding:13px}th,td{padding:4px}}
</style><header><div><small>Homologação de interface · WordPress</small><h1>Fator3 Site Core</h1><p>Prova visual da versão 1.100.1</p>''']
parts.append(f'<div class="meta"><span>{len(routes)} rotas administrativas</span><span>360, 768 e 1440 px</span><span>{count} de {len(routes)*12} conferências atendidas</span></div></div></header><main>')
parts.append('<section class="indices" id="indice"><h2>Índice das capturas</h2><p>Selecione a subaba e amplie qualquer imagem. No telefone, a segunda captura mostra o conteúdo abaixo da navegação.</p><nav class="indexgrid" aria-label="Grupos e capturas">')
for name,items in groups.items():
    parts.append('<div><b>'+e(name)+'</b><ul>'+''.join(f'<li><a href="#{e(r["rota"])}">{e(r["subaba"])}</a></li>' for r in items)+'</ul></div>')
parts.append('</nav><a class="back" href="#aceite">Matriz de aceite</a> · <a href="#paleta">Esquema Moderno</a></section>')
parts.append(f'<section class="indices" id="aceite"><h2>Matriz de aceite</h2><p>WordPress {e(orig["wordpress"])} · PHP {e(orig["php"])} · Chromium {e(matrix["chromium"])}. Plugin de ensaio ativo nas capturas. O WordPress do laboratório usa os rótulos nativos em inglês. As telas do Core usam português. O banco local contém 27 materiais sintéticos para testar a página de Conteúdo privado.</p><p class="meta2">Instalador <code>{e(orig["instalador"])}</code><br>SHA-256 <code>{e(orig["sha256"])}</code><br>{orig["arquivos_identicos"]} arquivos instalados conferidos byte a byte.</p>')
parts.append('<ol class="criteria">'+''.join('<li>'+e(s)+'</li>' for s in criteria)+'</ol><p class="meta2">✓ = atendido. Cada célula traz a medição no título e cada rota inclui a leitura completa abaixo das capturas.</p><div class="matrix" tabindex="0" role="region" aria-label="Matriz de critérios"><table><thead><tr><th>Grupo / subaba</th>'+''.join(f'<th title="{e(s)}">{n}</th>' for n,s in enumerate(criteria,1))+'</tr></thead><tbody>')
for r in routes:
    parts.append('<tr><th><a href="#'+r['rota']+'">'+e(r['grupo']+' / '+r['subaba'])+'</a></th>')
    parts.extend('<td class="'+('pass' if c['atendido'] else 'fail')+'" title="'+e(c['conferencia'],quote=True)+'">'+('✓' if c['atendido'] else 'Falha')+'</td>' for c in r['criterios'].values())
    parts.append('</tr>')
parts.append('</tbody></table></div></section>')
for grupo,items in groups.items():
    parts.append('<h2 class="toscroll">'+e(grupo)+'</h2>')
    for r in items:
        key=r['rota']; parts.append(f'<article id="{key}" class="screen"><h3>{e(r["subaba"])}</h3><p class="meta2"><code>{e(r["consulta"])}</code></p><div class="gallery">')
        for m in of[key]['medicoes']:
            w=m['largura']
            parts.append(figure(m['captura'],str(w)+' px · '+r['subaba']))
            if m.get('conteudo'):parts.append(figure(m['conteudo'],'Conteúdo · '+r['subaba']))
        parts.append('</div><details><summary>Conferência dos 12 critérios</summary><ol class="details-list">')
        for c in r['criterios'].values():
            parts.append('<li><b>'+e(c['titulo'])+'</b>'+('Atendido. ' if c['atendido'] else 'Falhou. ')+e(c['conferencia'])+'</li>')
        parts.append('</ol></details><a class="back" href="#indice">Voltar ao índice</a></article>')
parts.append('<section id="paleta" class="paleta"><h2>Esquema Moderno</h2><p>Capturas após alterar o esquema na conta local do WordPress. A matriz registra a cor calculada para cada rota.</p><div class="gallery">')
for key in ['cfg-inicio','med-geral']:
    parts.append(figure(theme[key]['medicoes'][0]['captura'],theme[key]['grupo']+' · Moderno'))
parts.append('</div></section><footer>Acervo de capturas e medições da versão 1.100.0.</footer></main><dialog aria-label="Captura ampliada"><button type="button" autofocus>Fechar</button><img alt=""></dialog><script>const dlg=document.querySelector("dialog");document.querySelectorAll(".ampliar").forEach(a=>a.addEventListener("click",ev=>{ev.preventDefault();const img=a.querySelector("img"),zoom=dlg.querySelector("img");zoom.src=img.src;zoom.alt=img.alt;dlg.showModal()}));dlg.querySelector("button").onclick=()=>dlg.close();dlg.addEventListener("click",e=>{if(e.target===dlg)dlg.close()});</script></html>')
destino.write_text(''.join(parts))
print(destino.name,destino.stat().st_size,'bytes')
