"""Gera a matriz dos 12 critérios a partir do Chromium e do ZIP testado."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,re,sys
from rotas import ROUTES,groups

guia=('Folha comum','Cabeçalho','Aviso e divisor','Navegação','Cores do esquema','Selos de estado','Rótulos e campos','Tabelas e listas','Largura','Alvos de toque','Foco pelo teclado','Folha do Core')
def load(path):return json.loads(path.read_text())
def main():
    d,zpath=map(Path,sys.argv[1:3])
    of,tema,sem,aberto,origem,painel=[load(d/(n+'.json')) for n in ['oficial','tema','sem-js','expandido','origem','painel-wordpress']]
    oficial='15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b'
    if hashlib.sha256(zpath.read_bytes()).hexdigest()!=origem['sha256']:raise ValueError('Instalador diferente do instalado')
    with ZipFile(zpath) as z:
        comum=z.read('base-site-core-fator3/assets/f3-ui.css')
        dom=z.read('base-site-core-fator3/assets/f3base-admin-dominio.css').decode()
    comum_sha=hashlib.sha256(comum).hexdigest()
    clean=re.sub(r'/\*.*?\*/','',dom,flags=re.S)
    # O breakpoint oficial separa larguras de tela; não define cor, raio nem espaço.
    clean=re.sub(r'@media\s*\(\s*max-width\s*:\s*782px\s*\)', '@media', clean)
    literals=re.findall(r'#[a-fA-F\d]{3,8}\b|\b\d+(?:\.\d+)?px\b|\b(?:rgb|hsl)a?\(',clean)
    redef=re.findall(r'(--f3-[\w-]+)\s*:',dom)
    folhas=['assets/f3-ui.css','assets/f3base-admin-dominio.css']
    ids={k for k,_,_,_ in ROUTES}
    if {frozenset(of),frozenset(tema),frozenset(sem),frozenset(aberto)}!={frozenset(ids)}:raise ValueError('Ensaio incompleto')
    matriz=[]
    for key,grupo,aba,url in ROUTES:
        r=of[key];ms=r['medicoes'];v=ms[-1];mt=tema[key]['medicoes'][0];sn=sem[key]
        if any(x[key].get('instalador_sha256')!=origem['sha256'] for x in [of,tema,sem,aberto]):
            raise ValueError('Medição de outra instalação: '+key)
        exp=aberto[key]['medicoes']; detalha=aberto[key]['blocos_abertos']
        def ok(m):return m['cor']==m['cor_ativa'] and all(c==m['cor'] for c in m['tracos'])
        def fieldall(k):return sorted({i for m in ms+exp for i in m[k]})
        foco=r['foco'];result={}
        def criterion(n,passed,note):
            result[str(n)]={'titulo':guia[n-1],'atendido':bool(passed),'conferencia':note}
        criterion(1,comum_sha==oficial and len(comum)==11886 and v['folhas']==folhas and painel=={'pagina':'wp-admin/index.php','http':200,'folhas_do_core':[]},f'{len(comum)} bytes. Carregamento em ordem na tela do Core e ausente no Painel nativo.')
        criterion(2,r['http']==200 and not v['erro_critico'] and v['raiz'] and v['nome']=='Fator3 Site Core' and v['descricao'] and '1.100.1' in v['versao'],v['nome']+' · '+v['descricao']+' · '+v['versao'])
        criterion(3,all(m['hr_apos'] and m['aviso'] for m in ms) and sn['medicoes'][0]['aviso'],'Divisor imediatamente após o header; aviso visível e externo nas três larguras e sem JavaScript.')
        expected=[] if key=='tecnica' else [aba]
        sets=v['conjuntos'];names=v['rotulos_conjuntos']
        nav=v['navs']==1 and v['grupos']==list(groups) and v['grupos_ativos']==[grupo] and v['abas_ativas']==expected and all(n<=7 for n in sets) and (len(sets)<=1 or all(names)) and not v['niveis_extras']
        criterion(4,nav and sn['navegacao_html'],f'{len(v["grupos"])} grupos; subabas por conjunto {sets}. Navegação por link sem JavaScript: {sn["navegacao_html"]}.')
        criterion(5,ok(mt) and ok(v) and mt['tema']=='modern' and v['tema']=='fresh' and v['cor']!=mt['cor'],f'Padrão {v["cor"]}; Moderno {mt["cor"]}. Correspondência do fundo e do traço quando presente.')
        bad=fieldall('selos_antigos')+fieldall('selos_sem_estado')
        criterion(6,not bad,f'{v["selos"]} selos. '+('Estado legado/inválido: '+', '.join(bad) if bad else 'Nenhuma classe antiga ou modificador inválido.'))
        labels=fieldall('rotulos');criterion(7,not any(m['form_tables'] for m in ms+exp) and not labels,f'{v["campos"]} campos à entrada e {exp[-1]["campos"]} com {detalha} blocos abertos. '+(' · '.join(labels) if labels else 'Estrutura dos rótulos e ausência de form-table verificadas.'))
        tbl=fieldall('tabelas_fora')+fieldall('listas_sem_ferramentas'); extra=r.get('lista_grande'); valid=True
        if key=='cont-conteudos': valid=extra and '27' in extra['primeira'] and '27' in extra['segunda'] and extra['termo_encontrado'] and extra['resultado_busca']==1
        criterion(8,not tbl and valid,f'{v["tabelas"]} tabelas. '+(' · '.join(tbl) if tbl else 'Envoltório e ferramentas conferidos.')+(' 27 materiais: busca de 1 e segunda página verificadas.' if valid and extra else ''))
        sizes=[m['largura'] for m in ms];criterion(9,sizes==[360,768,1440] and all(m['largura']==m['documento'] for m in ms+exp),' / '.join(str(m['documento'])+' de '+str(m['largura'])+' px' for m in ms))
        small=ms[:2]+exp[:2];low=[x for m in small for k in ['controles_baixos','nav_baixa'] for x in m[k]];criterion(10,not low,' · '.join(low[:3]) if low else '360 e 768 px. Altura mínima da navegação: '+str(min(m['altura_nav_minima'] for m in small))+' px. '+('Controles: '+str(min(m['altura_controle_minima'] for m in small if m['altura_controle_minima'] is not None))+' px.' if any(m['altura_controle_minima'] is not None for m in small) else 'Tela sem controles de formulário/botões visíveis.'))
        criterion(11,'nav' in foco and all(f['teclado'] and f['visivel'] and f['largura']>=2 and f['estilo']!='none' for f in foco.values()),', '.join(k+' '+str(v['largura'])+' px' for k,v in foco.items())+'.')
        criterion(12,not literals and not redef,'Folha de domínio verificada no instalador. Literais hex/rgb/hsl/px: '+str(len(literals))+'. Tokens comuns redefinidos: '+str(len(redef))+'. O breakpoint de 782 px é medido separadamente.')
        matriz.append({'rota':key,'grupo':grupo,'subaba':aba,'consulta':url,'criterios':result})
    output={'versao':'1.100.1','origem':origem,'chromium':of[ROUTES[0][0]]['chromium'],'folha_comum_sha256':comum_sha,'criterios':12,'rotas':matriz}
    (d/'matriz.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
    erros=[item['rota']+': '+','.join(n for n,v in item['criterios'].items() if not v['atendido']) for item in matriz if not all(v['atendido'] for v in item['criterios'].values())]
    print(str(len(matriz))+' rotas, '+str(len(matriz)*12)+' verificações; '+str(len(erros))+' rotas com falha.')
    if erros:print('\n'.join(erros));sys.exit(1)
if __name__=='__main__':main()
