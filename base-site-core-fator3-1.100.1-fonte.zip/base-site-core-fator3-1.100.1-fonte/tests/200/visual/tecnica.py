"""QA complementar de Informações técnicas. Recebe a sessão local de sessao.php por stdin."""
import json
import os
import sys
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright


def navegar(pagina, controle):
    with pagina.expect_navigation(wait_until="domcontentloaded"):
        controle.click()


def verificar_sessoes(pagina, resultado):
    raiz = pagina.locator(".wrap.f3-ui")
    secoes = raiz.locator('details[id^="tecnica-"]')
    ids = secoes.evaluate_all("(itens) => itens.map(item => item.id)")
    assert raiz.count() == 1 and len(ids) == len(set(ids)) >= 7
    for destino in ids:
        assert raiz.locator(f'a[href="#{destino}"]').count() == 1
    assert raiz.locator("#tecnica-estado-operacional[open]").count()
    assert not raiz.locator(".f3-pill").filter(has_text="WARN").count()
    assert not raiz.locator("table.form-table").count()
    assert not raiz.locator("table").evaluate_all(
        "tabelas=>tabelas.some(t=>!t.closest('.f3-table-scroll'))"
    )
    resultado.update({
        "secoes_com_ancora": len(ids),
        "cartoes_saude": raiz.locator("#tecnica-estado-operacional .f3-cards .f3-card").count(),
        "selos": raiz.locator(".f3-pill").count(),
        "tabelas_com_rolagem": raiz.locator("table").count(),
    })
    for chave in ("f3base-arquivo-publico", "f3base-previa-tipo", "f3base-previa-id"):
        assert raiz.locator("#" + chave).evaluate("e=>e.labels.length && e.closest('.f3-field')!==null")
    resultado["campos_de_publicacao_rotulados"] = 3


def verificar_lista(pagina, resultado):
    secoes = pagina.locator('details[id^="tecnica-"]')
    secoes.evaluate_all("(itens)=>itens.forEach(item=>item.open=true)")
    filtro = pagina.locator("form:has(input[name=busca_modulos])")
    assert filtro.count() == 1
    navegar(pagina, filtro.get_by_role("link", name="Próxima"))
    assert "pagina_modulos=2" in pagina.url
    navegar(pagina, filtro.get_by_role("link", name="Anterior"))
    filtro.locator("input[name=busca_modulos]").fill("zzzz-sem-modulo")
    navegar(pagina, filtro.get_by_role("button", name="Buscar"))
    assert pagina.get_by_text("Nenhum módulo corresponde à busca.", exact=False).is_visible()
    assert pagina.locator("#tecnica-modulos").evaluate("e=>e.open")
    navegar(pagina, pagina.get_by_text("Limpar busca", exact=True))
    resultado["lista_de_modulos"] = ["próxima", "anterior", "busca vazia", "limpar busca"]


def verificar_acao(pagina, tipo, papel):
    caixa = pagina.locator("#tecnica-arquivos-publicos")
    caixa.evaluate("e=>e.open=true")
    caixa.locator("#f3base-previa-tipo").select_option(tipo)
    navegar(pagina, caixa.get_by_role("button", name="Gerar prévia e explicar seleção"))
    aviso = pagina.locator(f'.f3-result[role="{papel}"]')
    assert aviso.is_visible()
    if papel == "alert":
        assert "Conteúdo não integra" in aviso.inner_text()
        assert aviso.evaluate("e=>e.classList.contains('is-error')")
    aviso.get_by_role("button", name="Dispensar").click()
    aviso.wait_for(state="hidden", timeout=3500)
    assert pagina.evaluate("()=>document.activeElement!==document.body"), pagina.evaluate(
        "()=>[document.activeElement.tagName,document.querySelector('.f3-groups [aria-current]')?.outerHTML]"
    )


def conferir(pagina, origem):
    resultado = {"ambiente": "WordPress local, Chromium", "larguras_com_secoes_abertas": []}
    pagina.goto(origem + "/wp-admin/admin.php?page=base-site-core-fator3&aba=tecnica",
                wait_until="domcontentloaded", timeout=45000)
    verificar_sessoes(pagina, resultado)
    verificar_lista(pagina, resultado)
    # As prévias são compostas no WordPress local. Nenhuma ação de verificar publicação ou regenerar.
    verificar_acao(pagina, "llms", "status")
    verificar_acao(pagina, "markdown", "alert")
    resultado["previas"] = ["sucesso com status", "erro com alerta e motivo", "dispensa com foco"]
    for largura in (360, 768, 1440):
        pagina.set_viewport_size({"width": largura, "height": 900})
        pagina.locator('details[id^="tecnica-"]').evaluate_all("(itens)=>itens.forEach(e=>e.open=true)")
        pagina.wait_for_function("(w)=>document.documentElement.clientWidth===w", arg=largura)
        pagina.evaluate("()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))")
        documento = pagina.evaluate("document.documentElement.scrollWidth")
        assert documento == largura, (largura, documento)
        resultado["larguras_com_secoes_abertas"].append({"janela": largura, "documento": documento})
    return resultado


dados = json.load(sys.stdin)
origem = dados["origem"]
if urlsplit(origem).hostname != "127.0.0.1":
    raise ValueError("Este ensaio requer WordPress descartável em loopback.")
with sync_playwright() as pw:
    navegador = pw.chromium.launch(
        executable_path=os.environ.get("F3_QA_CHROME", "/usr/bin/chromium"),
        args=["--no-sandbox", "--disable-dev-shm-usage"],
    )
    contexto = navegador.new_context(viewport={"width": 1440, "height": 960})
    contexto.add_cookies([{"name": k, "value": v, "url": origem} for k, v in dados["cookies"].items()])
    pagina = contexto.new_page()
    pagina.route("**/*", lambda rota: rota.continue_() if rota.request.url.startswith(origem + "/") else rota.abort())
    print(json.dumps(conferir(pagina, origem), ensure_ascii=False, indent=2))
    navegador.close()
