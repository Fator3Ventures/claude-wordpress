# Homologação visual do Core 1.100.1

O ensaio abre 24 rotas de administração em Chromium. As larguras são 360, 768 e 1440 pixels CSS, com escala de dispositivo 1. Cada rota tem três capturas no início da página e uma captura de conteúdo após a navegação, no telefone. Duas capturas adicionais registram o esquema Moderno. As 12 conferências ficam em `evidence/2001/visual/matriz.json`. O caderno HTML contém as imagens e abre offline.

## Reprodução

Use WordPress 7.1.4, PHP 8.3 ou superior, WP-CLI, MariaDB e Chromium com Python, Playwright e Pillow. O processo de captura é local e o diretório de trabalho deve ser descartável. Sirva o WordPress em uma URL HTTP de loopback, em `127.0.0.1`, com `WP_ENVIRONMENT_TYPE=local` e banco `core_200_visuais`. Ative o usuário administrador de ID 1. Use valores sintéticos, bloqueie e-mail por `pre_wp_mail` e intercepte `pre_http_request` para destinos externos. Desative o cron de rede. O coletor do navegador também bloqueia as requisições externas.

1. Instale previamente os companheiros MCP, Google, Meta, LinkedIn e Pipedrive nas versões da coorte desta entrega. Mantenha o WordPress e o servidor HTTP em funcionamento.
2. Configure as variáveis no comando abaixo com os caminhos absolutos existentes no seu ambiente. A pasta de provas recebe JSON e WebP. O caderno fica fora dela.
3. Execute o coletor. Ele reinstala o ZIP no site de ensaio, comprova a identidade de todos os arquivos com o instalador e ativa um segundo plugin que mostra um aviso em todas as telas. A sessão do navegador fica em arquivo temporário restrito. O ensaio cadastra 27 materiais sintéticos por operação idempotente do Core e abre a segunda página e o resultado de uma busca.
4. A coleta usa os esquemas Padrão e Moderno, navegação por teclado, outro contexto com JavaScript desligado e uma leitura com os blocos recolhíveis abertos. O último passo compara as medições com os 12 critérios e gera o caderno.

```sh
QA_SITE=/caminho/wp \
F3_ZIP_FINAL=/pacotes/base-site-core-fator3-1.100.1-instalador.zip \
F3_QA_CHROME=/caminho/chromium \
QA_SAIDA200=/provas/visual \
QA_CADERNO200=/entrega/base-site-core-fator3-1.100.1-prova-visual.html \
bash coletar.sh
```

A aba técnica não tem segundo nível. Os demais grupos mostram a subaba corrente. A matriz de foco considera os controles existentes na rota. O caderno mostra as três larguras lado a lado e inclui uma segunda vista do telefone. Uma página pode ser maior verticalmente que os trechos registrados.

As rotas e seu agrupamento ficam em `rotas.py`. As medições feitas pelo navegador se encontram em `medir.js`. A referência da folha comum é o SHA-256 da versão 1.0.0 documentada no guia visual. O relatório produz falha se esse valor, os arquivos instalados ou algum critério divergirem.
