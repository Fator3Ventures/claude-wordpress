<?php
if (DB_NAME !== 'core_200_visuais' || wp_get_environment_type() !== 'local') { throw new RuntimeException('Laboratório visual obrigatório'); }
$ate=time()+3600;
$token=WP_Session_Tokens::get_instance(1)->create($ate);
echo wp_json_encode(['origem'=>get_site_url(),'cookies'=>[AUTH_COOKIE=>wp_generate_auth_cookie(1,$ate,'auth',$token),LOGGED_IN_COOKIE=>wp_generate_auth_cookie(1,$ate,'logged_in',$token)]]);
