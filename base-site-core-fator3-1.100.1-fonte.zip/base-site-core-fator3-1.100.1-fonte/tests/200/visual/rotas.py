from urllib.parse import urlencode
groups={
 'Configurações': [('cfg-'+s,label,{'page':'base-site-core-fator3','secao':s}) for s,label in [
  ('inicio','Visão geral'),('conexoes','Conexões e entregas'),('contato','Contato'),('medicao','Medição e anúncios'),
  ('conteudo','Conteúdo e IA'),('seo','SEO'),('consentimento','Consentimento'),('privacidade','Privacidade e segurança')]],
 'Contatos': [('cont-'+s,label,{'page':'f3base-'+s}) for s,label in [('leads','Contatos'),('formularios','Formulários'),('conteudos','Conteúdo privado')]],
 'Medição': [('med-'+s,label,{'page':'f3base-medicao','area':s}) for s,label in [
  ('geral','Visão geral'),('conteudo','Conteúdo'),('sessoes','Sessões'),('aquisicao','Aquisição'),('agentes','IA e robôs'),
  ('conversao','Conversão'),('ga4','Acervo GA4'),('clarity','Clarity'),('tecnico','Técnico')]],
 'Operação': [('op-'+s,label,{'page':'f3base-operacao','fila':s if s!='execucoes' else ''}) for s,label in [('execucoes','Execuções'),('entregas','Entregas ao Pipedrive'),('avisos','Avisos à equipe')]],
 'Informações técnicas':[('tecnica','Informações técnicas',{'page':'base-site-core-fator3','aba':'tecnica'})]
}
ROUTES = [(key,grp,label,'/wp-admin/admin.php?'+urlencode(pars)) for grp,entries in groups.items() for key,label,pars in entries]
