<?php
/**
 * Plugin Name: Aviso de homologação visual
 * Description: Aviso sintético usado no laboratório local de interface.
 * Version: 1.0.0
 */
if (wp_get_environment_type() === 'local' && DB_NAME === 'core_200_visuais') {
    add_action('admin_notices', static function () {
        echo '<div id="ensaio-aviso-externo" class="notice notice-info"><p>Homologação visual. Este aviso pertence ao plugin de ensaio.</p></div>';
    });
}
