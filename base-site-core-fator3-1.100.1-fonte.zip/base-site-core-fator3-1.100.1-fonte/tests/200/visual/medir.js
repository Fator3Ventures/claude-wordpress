({largura,grupo,aba}) => {
  const root = document.querySelector('.wrap.f3-ui') || document.querySelector('#wpbody-content .wrap') || document.body;
  const qs = (s,p=root)=>Array.from(p.querySelectorAll(s));
  const visible = e=>e.checkVisibility({contentVisibilityAuto:true,visibilityProperty:true}) && e.getBoundingClientRect().height>0;
  const text = e=>(e?.textContent||'').trim().replace(/\s+/g,' ');
  const tag = e=>[e.tagName.toLowerCase(),e.className,e.name||''].map(x=>String(x||'').trim()).filter(Boolean).join(' ').slice(0,95);
  const heading = root.querySelector('header.f3-heading');
  const divider = root.querySelector('hr.wp-header-end');
  const notice = document.querySelector('#ensaio-aviso-externo');
  const ns=qs('nav.f3-nav');
  const groups=qs('.f3-groups a'), subtabs=qs('.f3-subtabs a');
  const sets=qs('.f3-subtabs');
  const fieldSelector='select,textarea,input:not([type=hidden],[type=submit],[type=button],[type=reset],[type=checkbox],[type=radio],[type=color],[type=range],[type=file],[type=image])';
  const fields=qs(fieldSelector).filter(visible);
  const controls=[...fields,...qs('.button,button,input[type=submit]').filter(visible)];
  const labels=[];
  const badHeights = controles => controles.filter(e=>e.getBoundingClientRect().height<39.5).map(e=>tag(e)+' = '+e.getBoundingClientRect().height+' px');
  for (const e of fields) {
    const label = e.labels?.[0];
    if(!label || !visible(label)) {
      if (!e.getAttribute('aria-label') && !e.getAttribute('aria-labelledby')) labels.push(tag(e)+': sem rótulo');
      continue;
    }
    let bottom=label.getBoundingClientRect().bottom;
    if(label.contains(e)){
      const walker=document.createTreeWalker(label,NodeFilter.SHOW_TEXT);const items=[];let node;
      while(node=walker.nextNode()){if(!node.textContent.trim()||e.contains(node))continue;const r=document.createRange();r.selectNodeContents(node);for(const rect of r.getClientRects())if(rect.height)items.push(rect.bottom);}
      if(!items.length)continue;
      bottom=Math.max(...items);
    }
    if(bottom>e.getBoundingClientRect().top+2) labels.push(tag(e)+': rótulo lateral');
  }
  const longTables=qs('table').map(t=>({t,linhas:t.tBodies[0]?.rows.length||0})).filter(t=>t.linhas>20);
  const longWithout=longTables.filter(({t})=>{
    const area=t.closest('.f3-section, details, .f3-card')||root;
    const box=area.querySelector('.f3-list-tools')||t.closest('.f3-table-scroll')?.previousElementSibling;
    return !box || !box.querySelector('input[type=search],input[type=text]') || !area.querySelector('.f3-list-total') || !/(anterio|próxim)/i.test(text(area));
  }).map(({t,linhas})=>tag(t)+': '+linhas+' linhas');
  const probe=document.createElement('i');probe.style.color='var(--wp-admin-theme-color,#2271b1)';root.appendChild(probe);const expectedColor=getComputedStyle(probe).color;probe.remove();
  const activeG=groups.find(e=>e.hasAttribute('aria-current')), activeS=subtabs.filter(e=>e.hasAttribute('aria-current'));
  const gcol=activeG?getComputedStyle(activeG).backgroundColor:null;
  const scol=activeS.map(e=>getComputedStyle(e).borderBottomColor);
  const overlays=qs('*').filter(e=>visible(e)&&e.getBoundingClientRect().right>largura+2&&!e.closest('.f3-table-scroll,pre,:is(.screen-reader-text,.hidden)')).slice(0,8).map(tag);
  const extraNav=qs('.nav-tab-wrapper,.f3c-subnav,.f3base-indice,.f3m-subnav,.f3c-navegacao-agrupada');
  const legacy=qs('[class*="f3base-chip"],[class*="f3base-config-status"],.f3c-selo,.f3m-chip,.f3base-teste');
  const pills=qs('.f3-pill');
  const s=[...document.styleSheets].map(a=>a.href||'').filter(a=>a.includes('/plugins/base-site-core-fator3/')).map(a=>new URL(a).pathname.split('/base-site-core-fator3/').pop());
  return {raiz:root.classList.contains('f3-ui'),nome:text(heading?.querySelector('h1')),descricao:text(heading?.querySelector('p')),versao:text(heading?.querySelector('.f3-version')),
    aviso:!!notice&&visible(notice)&&!heading?.contains(notice),hr_apos:!!heading&&!!divider&&heading.nextElementSibling===divider,navs:ns.length,rotulos_conjuntos:sets.map(e=>text(e.querySelector('.f3-subtabs-label'))),
    grupos:groups.map(text),grupos_ativos:groups.filter(e=>e.hasAttribute('aria-current')).map(text),abas_ativas:activeS.map(text),conjuntos:sets.map(e=>e.querySelectorAll('a').length),
    niveis_extras:extraNav.map(tag),tema:document.body.className.match(/admin-color-([\w-]+)/)?.[1],cor:expectedColor,cor_ativa:gcol,tracos:scol,
    selos:pills.length,selos_antigos:legacy.map(tag).slice(0,5),selos_sem_estado:pills.filter(e=>Array.from(e.classList).some(c=>c.startsWith('is-')&&!/^is-(ok|warn|error|info)$/.test(c))).map(tag).slice(0,8),
    form_tables:qs('.form-table').length,campos:fields.length,rotulos:labels.slice(0,8),
    tabelas:qs('table').length,tabelas_fora:qs('table').filter(t=>!t.closest('.f3-table-scroll')).map(tag).slice(0,8),
    listas_longas:longTables.length,listas_sem_ferramentas:longWithout.slice(0,6),
    largura:innerWidth,documento:document.documentElement.scrollWidth,excedentes:overlays,
    nav_baixa:[...groups,...subtabs].filter(visible).filter(e=>e.getBoundingClientRect().height<43.5).map(text),
    controles_baixos:badHeights(controls).slice(0,12),folhas:s,
    altura_controle_minima:controls.length?Math.min(...controls.map(e=>e.getBoundingClientRect().height)):null, altura_nav_minima:[...groups,...subtabs].length?Math.min(...[...groups,...subtabs].filter(visible).map(e=>e.getBoundingClientRect().height)):null,campos_sensiveis:qs('input[type=password]').filter(e=>e.value).length,
    titulo_pagina:document.title,erro_critico:!!document.querySelector('body#error-page')||text(root).includes('There has been a critical error')
  };
}
