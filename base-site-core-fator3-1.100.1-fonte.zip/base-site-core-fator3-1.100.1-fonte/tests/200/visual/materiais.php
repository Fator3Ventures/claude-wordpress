<?php
/** Catálogo descartável para provar a lista de mais de vinte registros no navegador. */
if (DB_NAME !== 'core_200_visuais' || wp_get_environment_type() !== 'local') { throw new RuntimeException('Laboratório visual obrigatório.'); }
for ($n=1; $n<=27; $n++) {
    $nome=sprintf('material-de-ensaio-%02d.txt',$n);
    $bytes=sprintf("Documento sintético %02d. Laboratório local.\n",$n);
    $r=F3Base_Arquivos_Servico::cadastrar(['nome'=>$nome,'base64'=>base64_encode($bytes),'sha256'=>hash('sha256',$bytes),'idempotency_key'=>'prova-visual-2000-'.$nome]);
    if (empty($r['ok'])) { throw new RuntimeException('Material sintético indisponível: '.($r['codigo']??'desconhecido')); }
}
