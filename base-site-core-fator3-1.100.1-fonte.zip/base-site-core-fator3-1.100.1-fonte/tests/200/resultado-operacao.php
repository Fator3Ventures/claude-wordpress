<?php
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_200_operacao') { throw new RuntimeException('Laboratório obrigatório.'); }
$user = get_current_user_id();
$ate = time()+240;
$token = WP_Session_Tokens::get_instance($user)->create($ate);
$logged = wp_generate_auth_cookie($user,$ate,'logged_in',$token);
$_COOKIE[LOGGED_IN_COOKIE]=$logged;
echo wp_json_encode(['url'=>admin_url('admin-post.php'),'cookies'=>[AUTH_COOKIE=>wp_generate_auth_cookie($user,$ate,'auth',$token),LOGGED_IN_COOKIE=>$logged],'nonce'=>wp_create_nonce('f3base-slack-manutencao')]);
