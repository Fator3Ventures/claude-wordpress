<?php
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_200_provas') {
    throw new RuntimeException('Somente no laboratório isolado.');
}
$resultados = [];
$exigir = static function ($valor, string $rotulo) use (&$resultados) {
    if (!$valor) throw new RuntimeException($rotulo);
    $resultados[] = $rotulo;
};
$render = static function () {
    ob_start();
    F3Base_Interface::cabecalho('Contatos','Consulte os contatos.');
    F3Base_Interface::grupo_contatos('f3base-leads');
    return ob_get_clean();
};
$exigir(is_user_logged_in() && current_user_can('manage_options'), 'Administrador local disponível');
$h = $render();
$exigir(substr_count($h,'<h1>Fator3 Site Core</h1>') === 1 && substr_count($h,'wp-header-end') === 1, 'Cabeçalho único e sentinela após a versão');
$exigir(str_contains($h,'aria-current="true">Contatos') && str_contains($h,'aria-current="page">Contatos'), 'Grupo e subaba ativos identificados');
$exigir(substr_count($h,'<a ') === 8, 'Cinco grupos e três subabas para o administrador');
$u = wp_insert_user(['user_login'=>'ensaio-shell-'.wp_generate_uuid4(),'user_pass'=>wp_generate_password(),'role'=>'subscriber']);
if (is_wp_error($u)) throw new RuntimeException('Usuário de ensaio indisponível');
try {
    $usuario = wp_set_current_user($u);
    $usuario->add_cap('f3base_ler_leads');
    $h = $render();
    $exigir(substr_count($h,'<a ') === 1 && str_contains($h,'f3base-leads') && !str_contains($h,'f3-subtabs'), 'Leitura de contatos mostra apenas o grupo autorizado e omite subaba única');
    $usuario->remove_cap('f3base_ler_leads');
    $usuario->add_cap('f3base_gerir_formularios');
    $h = $render();
    $exigir(substr_count($h,'<a ') === 3 && !str_contains($h,'f3base-leads') && str_contains($h,'f3base-conteudos'), 'Gestão de formulários mostra os dois destinos autorizados');
} finally {
    wp_set_current_user(1);
    require_once ABSPATH.'wp-admin/includes/user.php';
    wp_delete_user($u);
}
$handle = 'base-site-core-fator3-f3-ui';
F3Base_Interface::enfileirar('edit.php');
F3Base_Interface::enfileirar('tools_page_f3base-outro-plugin');
$exigir(!wp_style_is($handle) && !has_action('wp_enqueue_scripts', [F3Base_Interface::class,'enfileirar']), 'Folha ausente em outra tela administrativa e sem hook no frontend');
F3Base_Interface::enfileirar('site-core_page_f3base-operacao');
$exigir(wp_style_is($handle) && wp_style_is('base-site-core-fator3-admin') && wp_styles()->registered['base-site-core-fator3-admin']->deps === [$handle], 'Operação enfileira o par com a dependência correta');
echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'total'=>count($resultados),'verificacoes'=>$resultados], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
