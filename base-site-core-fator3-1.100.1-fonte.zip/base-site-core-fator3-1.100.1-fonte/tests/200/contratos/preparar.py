"""Prepara as provas oficiais em um diretório temporário fora da instalação WordPress."""
import argparse
from pathlib import Path
from zipfile import ZipFile

parser = argparse.ArgumentParser()
parser.add_argument("destino", type=Path)
parser.add_argument("google_fonte", type=Path)
parser.add_argument("mcp_fonte", type=Path)
args = parser.parse_args()
dest = args.destino
old = Path(__file__).resolve().parents[2] / '199'


def preparar(nome, fonte, mudancas=()):
    for de, para in mudancas:
        if de not in fonte:
            raise ValueError(f'{nome}: trecho de origem ausente: {de}')
        fonte = fonte.replace(de, para)
    path = dest / nome
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(fonte)


def oficial(zip_path, sufixo):
    with ZipFile(zip_path) as pacote:
        arquivos = [n for n in pacote.namelist() if n.endswith('/' + sufixo)]
        if len(arquivos) != 1:
            raise ValueError(sufixo)
        return pacote.read(arquivos[0]).decode()


# As provas históricas continuam exercitando os binários anteriores na mesma base.
for nome in ('google.php', 'google-bootstrap.php'):
    mudancas = [('core_199_google','core_200_google')]
    if nome == 'google.php':
        mudancas.extend([
            ("'0.41.0' && F3BASE_PLUGIN_VERSAO === '1.98.0'", "'0.42.0' && F3BASE_PLUGIN_VERSAO === '1.98.0'"),
            ("'0.41.0' && version_compare(F3BASE_PLUGIN_VERSAO,'1.99.0','>=')", "'0.42.0' && F3BASE_PLUGIN_VERSAO === '1.100.1'"),
            ('Google vigente com a base Core 1.98','Google 0.42.0 com a base Core 1.98'),
        ])
    preparar(nome, (old / nome).read_text(), mudancas)

for nome in ('provas-439.php','retomada-439.php','fronteira-janela.php','qa-core-439/cenarios.php','qa-core-439/qa-core-439.php'):
    mudancas = [] if nome.endswith('cenarios.php') else [('core_199_provas','core_200_provas')]
    if nome.endswith('qa-core-439.php'):
        mudancas.append(("!$qa439_local && $qa439_host !== 'fator3-teste-mcp-1.dreamhosters.com'", "!$qa439_local || $qa439_host !== '127.0.0.1'"))
    preparar(nome, (old / nome).read_text(), mudancas)

preparar('google-fila.php', oficial(args.google_fonte,'native/outbox042.php'), [
    ("['release42_upgrade', 'release42_clean']", "['core_200_google']"),
    ("F3BASE_PLUGIN_VERSAO !== '1.99.0'", "F3BASE_PLUGIN_VERSAO !== '1.100.1'"),
])
preparar('google-cursor.php', oficial(args.google_fonte,'native/cursor042.php'), [('release42_clean','core_200_google')])
preparar('mcp/carencia.php', oficial(args.mcp_fonte,'release0540/carencia.php'), [('1.99.0','1.100.1')])
preparar('mcp/transporte.php', oficial(args.mcp_fonte,'release0540/transporte.php'))
preparar('release0300/common.php', oficial(args.mcp_fonte,'release0300/common.php'))
