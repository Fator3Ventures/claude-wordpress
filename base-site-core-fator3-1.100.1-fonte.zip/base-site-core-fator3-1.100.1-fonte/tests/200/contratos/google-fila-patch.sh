set -euo pipefail
evid="$root/S/evidence/2001/contratos"
stage=$(mktemp -d "$site/contratos.XXXXXX")
mkdir -p "$evid"
google_fonte=("$root"/../upload-base/wp-mcp-google-fator3-0.42.0-fonte*.zip)
mcp_fonte=("$root"/../upload-base/wp-mcp-fator3-0.54.0-fonte*.zip)
python3 "$root/S/tests/200/contratos/preparar.py" "$stage" "${google_fonte[0]}" "${mcp_fonte[0]}"
wpcli plugin install "$F3_ZIP_FINAL" --force --activate
wpcli eval 'F3Base_Zelador::atualizacao_urgente();'
RELEASE42_PHASE=clean RELEASE42_RESULT="$stage/google-fila.json" wpcli eval-file "$stage/google-fila.php"
for fase in start resume; do
 CURSOR42_PHASE="$fase" CURSOR42_EVIDENCE="$stage/google-cursor-$fase.json" wpcli eval-file "$stage/google-cursor.php"
done
cp "$stage"/google-{fila,cursor-{resume,start}}.json "$evid/"
