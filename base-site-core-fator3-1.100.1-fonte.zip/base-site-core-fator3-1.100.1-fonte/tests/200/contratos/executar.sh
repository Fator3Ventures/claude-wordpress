set -euo pipefail
evid="$root/S/evidence/2001/contratos"
stage=$(mktemp -d "$site/contratos.XXXXXX")
mkdir -p "$evid"
google_fonte=("$root"/../upload-base/wp-mcp-google-fator3-0.42.0-fonte*.zip)
mcp_fonte=("$root"/../upload-base/wp-mcp-fator3-0.54.0-fonte*.zip)
python3 "$root/S/tests/200/contratos/preparar.py" "$stage" "${google_fonte[0]}" "${mcp_fonte[0]}"
instalar_core() {
 if [[ -n "${F3_ZIP_FINAL:-}" ]]; then
  wpcli plugin install "$F3_ZIP_FINAL" --force --activate > "$site/log/contrato-core-final.log"
  wpcli eval 'F3Base_Zelador::atualizacao_urgente();'
 else
  usar_candidato
 fi
 wpcli eval 'if (F3BASE_PLUGIN_VERSAO!=="1.100.1"||F3Base_Instalacao::resumo()["estado"]!=="concluida") throw new RuntimeException("Core não está pronto");'
}
if [[ "$suite" == google ]]; then
 g40="${F3_GOOGLE_040:?Informe o instalador histórico Google 0.40.0}"
 g42=("$root"/../upload-base/wp-mcp-google-fator3-0.42.0-instalador*.zip)
 base="$root/../c199/base/base-site-core-fator3-1.98.0-instalador.zip"
 test "$(sha256sum "$g40" | cut -d' ' -f1)" = dedded6ec02dbed38bb75f028720a222ec9b6f9335b80e3aa600b44d284da030
 wpcli plugin install "$base" --force --activate > "$site/log/contrato-core-anterior.log"
 wpcli plugin install "$g40" --force --activate > "$site/log/contrato-google-anterior.log"
 export F3_CORE_GOOGLE_PREFIXO="core200-google-$(date +%s)-$$"
 F3_CORE_GOOGLE_FASE=historico F3_CORE_GOOGLE_RESULTADO="$stage/google-origem.json" wpcli eval-file "$stage/google.php"
 wpcli plugin install "${g42[0]}" --force --activate > "$site/log/contrato-google-atual.log"
 F3_CORE_GOOGLE_FASE=anterior F3_CORE_GOOGLE_RESULTADO="$stage/google-pendentes.json" wpcli eval-file "$stage/google.php"
 instalar_core
 F3_CORE_GOOGLE_FASE=atual F3_CORE_GOOGLE_RESULTADO="$stage/google-retomada.json" wpcli eval-file "$stage/google.php"
 sonda="$wp/wp-content/mu-plugins/ensaio-core200-publico.php"
 cp "$stage/google-bootstrap.php" "$sonda"
 curl -fsS "http://$F3BASE_HOST/?f3_teste_google_bootstrap=1" > "$stage/google-bootstrap.json"
 rm "$sonda"
 python3 - "$stage/google-bootstrap.json" <<'PY'
import json,sys
from pathlib import Path
r=json.loads(Path(sys.argv[1]).read_text())
assert r=={'core':'1.100.1','google':'0.42.0','perfil_publico':True,'publicacao':True,'encerramento':True},r
PY
 RELEASE42_PHASE=clean RELEASE42_RESULT="$stage/google-fila.json" wpcli eval-file "$stage/google-fila.php"
 for fase in start resume; do
  CURSOR42_PHASE="$fase" CURSOR42_EVIDENCE="$stage/google-cursor-$fase.json" wpcli eval-file "$stage/google-cursor.php"
 done
elif [[ "$suite" == provas ]]; then
 instalar_core
 for proof in provas-439 retomada-439 fronteira-janela; do
  wpcli eval "require '$stage/$proof.php';" > "$stage/$proof.json"
 done
 wpcli eval-file "$root/S/tests/200/contratos/shell.php" > "$stage/shell.json"
 wpcli eval-file "$root/S/tests/200/contratos/isolamento-http.php" > "$stage/shell-http.json"
 F3_MCP_FASE=corrigida wpcli eval-file "$stage/mcp/carencia.php" > "$stage/mcp-apresentacao.json"
 touch "$wp/f3-disposable-lab.marker"
 LAB_ALLOW_LOCAL_HTTP=1 F3_WP_ROOT="$wp/wp-load.php" LAB_HOME="http://$F3BASE_HOST" F3_EVIDENCE="$stage" "$kit/php" "$stage/mcp/transporte.php" > "$site/log/contrato-http.log"
else
 echo 'Escolha a suíte google ou provas' >&2
 exit 2
fi
for arquivo in "$stage"/*.json; do
 python3 -m json.tool "$arquivo" >/dev/null
 cp "$arquivo" "$evid/"
done
if [[ -n "${F3_ZIP_FINAL:-}" ]]; then
 python3 - "$F3_ZIP_FINAL" "$wp/wp-content/plugins" "$suite" "$evid" <<'PY'
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json,sys
zip_path,plugins,suite,evid=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3],Path(sys.argv[4])
with ZipFile(zip_path) as z:
    arquivos={n for n in z.namelist() if not n.endswith('/')}
    instalados={p.relative_to(plugins).as_posix() for p in (plugins/'base-site-core-fator3').rglob('*') if p.is_file()}
    assert arquivos == instalados
    for nome in arquivos:
        assert z.read(nome) == (plugins/nome).read_bytes(),nome
r={'core':'1.100.1','suite':suite,'instalador':zip_path.name,'sha256':sha256(zip_path.read_bytes()).hexdigest(),'arquivos_identicos':len(arquivos)}
(evid/('instalador-'+suite+'.json')).write_text(json.dumps(r,indent=2)+'\n')
PY
fi
