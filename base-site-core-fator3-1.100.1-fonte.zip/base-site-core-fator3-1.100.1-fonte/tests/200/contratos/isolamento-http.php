<?php
/** Carregamento real das duas folhas na navegação pública e administrativa. */
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_200_provas' || wp_parse_url(home_url(), PHP_URL_HOST) !== '127.0.0.1' || !current_user_can('manage_options')) {
    throw new RuntimeException('Somente no laboratório de contratos.');
}
$uid = get_current_user_id();
$tokens = WP_Session_Tokens::get_instance($uid);
$ate = time() + 300;
$sessao = $tokens->create($ate);
try {
    $cookie = AUTH_COOKIE.'='.wp_generate_auth_cookie($uid,$ate,'auth',$sessao).'; '.LOGGED_IN_COOKIE.'='.wp_generate_auth_cookie($uid,$ate,'logged_in',$sessao);
    $rotas = [
        'site' => [home_url('/'), false, false],
        'painel_wordpress' => [admin_url('index.php'), true, false],
        'operacao_core' => [admin_url('admin.php?page=f3base-operacao'), true, true],
        'conteudo_privado_core' => [admin_url('admin.php?page=f3base-conteudos'), true, true],
    ];
    $evidencia = [];
    foreach ($rotas as $id => [$url, $painel, $core]) {
        $resp = wp_remote_get($url, ['timeout'=>30, 'redirection'=>0, 'headers'=>$painel ? ['Cookie'=>$cookie] : []]);
        if (is_wp_error($resp)) throw new RuntimeException($id.': '.$resp->get_error_code());
        $status = wp_remote_retrieve_response_code($resp);
        $html = wp_remote_retrieve_body($resp);
        $comum = strpos($html, '/base-site-core-fator3/assets/f3-ui.css');
        $dominio = strpos($html, '/base-site-core-fator3/assets/f3base-admin-dominio.css');
        $script = strpos($html, '/base-site-core-fator3/assets/f3base-interface.js');
        if ($status !== 200 || ($comum !== false) !== $core || ($dominio !== false) !== $core || ($script !== false) !== $core ||
            ($core && ($comum > $dominio || substr_count($html, '<h1>Fator3 Site Core</h1>') !== 1))) {
            throw new RuntimeException('Folhas, script ou cabeçalho divergentes em '.$id.' (HTTP '.$status.').');
        }
        $evidencia[$id] = ['http'=>$status,'folha_comum'=>$comum!==false,'folha_dominio'=>$dominio!==false,'script_de_avisos'=>$script!==false];
    }
    echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'rotas'=>$evidencia], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
} finally {
    $tokens->destroy($sessao);
}
