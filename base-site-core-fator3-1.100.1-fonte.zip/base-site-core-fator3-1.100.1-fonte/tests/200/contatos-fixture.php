<?php
/** Preparação exclusiva da instalação local e descartável usada pelo ensaio de Contatos. */
if (DB_NAME !== 'core_200_contatos' || wp_get_environment_type() !== 'local' || wp_parse_url(home_url(),PHP_URL_HOST) !== '127.0.0.1') {
    throw new RuntimeException('Este ensaio exige o banco e o endereço do laboratório de Contatos.');
}
$defs = [];
for ($i=1;$i<=25;$i++) {
    $defs[] = ['id'=>'amostra-'.$i,'titulo'=>sprintf('Formulário de ensaio %02d',$i),'regime'=>'registro','ligado'=>false,
        'campos'=>[['nome'=>'email','rotulo'=>'E-mail','tipo'=>'email','papel'=>'email','obrigatorio'=>true]]];
}
$motivo = F3Base_Formularios::recusar($defs);
if ($motivo) throw new RuntimeException($motivo);
$result = F3Base_Options::gravar('f3base_formularios',$defs,F3Base_Options::ORIGEM_PADRAO,F3Base_Options::revisao('f3base_formularios'));
if (F3Base_Options::ler('f3base_formularios')!=$defs) throw new RuntimeException(wp_json_encode($result));
global $wpdb;
for ($i=1;$i<=28;$i++) {
    $id = md5('arquivo-contatos-200-'.$i);
    $wpdb->replace(F3Base_Leads_Repositorio::tabela('arquivos_leads'),['id'=>$id,'finalidade'=>'conteudo','nome'=>sprintf('Arquivo de ensaio %02d.txt',$i),
        'mime'=>'text/plain','bytes'=>10,'sha256'=>hash('sha256',$id),'criado_em'=>time()+$i,'estado'=>'ativo']);
    if ($wpdb->last_error) throw new RuntimeException('Não foi possível criar a amostra de metadados.');
}
foreach (['sem_marca','teste','lixeira'] as $grupo) {
    $id = md5('contato-200-'.$grupo);
    $wpdb->replace(F3Base_Leads_Repositorio::tabela(),['record_id'=>$id,'formulario'=>'amostra-1','metodo'=>'formulario','captura'=>'aceito','classe_trafego'=>$grupo==='teste'?'teste':'nao_marcado',
        'lixeira'=>(int)($grupo==='lixeira'),'criado_em'=>current_time('mysql',true),'atualizado_em'=>current_time('mysql',true),'nome'=>'Contato de ensaio '.$grupo,
        'email'=>'contato@example.invalid','pagina'=>'/amostra','dados'=>'{}','anexos'=>'[]','payload_hash'=>hash('sha256',$id)]);
    if ($wpdb->last_error) throw new RuntimeException('Não foi possível criar o contato de ensaio.');
}
$ate = time()+1800;
$token = WP_Session_Tokens::get_instance(1)->create($ate);
echo wp_json_encode(['url'=>admin_url('admin.php'), 'cookies'=>[AUTH_COOKIE=>wp_generate_auth_cookie(1,$ate,'auth',$token),LOGGED_IN_COOKIE=>wp_generate_auth_cookie(1,$ate,'logged_in',$token)]]);
