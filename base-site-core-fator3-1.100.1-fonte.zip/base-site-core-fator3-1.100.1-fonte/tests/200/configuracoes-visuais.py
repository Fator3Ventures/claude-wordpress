"""Aceite de Configurações com Chromium real. Recebe sessão descartável local pela entrada padrão."""
import json
import os
import sys
from urllib.parse import parse_qs, urlsplit
from playwright.sync_api import sync_playwright

session = json.load(sys.stdin)
origin = session["origem"]
if urlsplit(origin).hostname not in {"localhost", "127.0.0.1"}:
    raise RuntimeError("O ensaio exige WordPress descartável em loopback.")
base = origin + "/wp-admin/admin.php?page=base-site-core-fator3"
config_sections = ["inicio","conexoes","contato","medicao","medicao-tags","medicao-meta","medicao-coleta",
                   "medicao-testes","medicao-gsc","medicao-ga4","medicao-clarity","conteudo","consentimento","privacidade","seo"]
integrations = ["f3base_pipedrive","f3base_email_site","f3base_email_novo_lead","f3base_anuncios_meta",
                "f3base_anuncios_google","f3base_anuncios_linkedin","avisos","qualidade","credenciais","f3base_avisos_tecnicos"]
routes = [(section, "&secao="+section) for section in config_sections] + [
    (name,"&secao=conexoes&integracao="+name) for name in integrations]
evidence = {"rotas":{}, "interacoes":{}}

with sync_playwright() as automation:
    browser = automation.chromium.launch(executable_path=os.getenv("F3_QA_CHROME","/usr/bin/chromium"),
                                         args=["--no-sandbox","--disable-dev-shm-usage"])
    context = browser.new_context(locale="pt-BR", viewport={"width":360,"height":800})
    context.add_cookies([{"name":name,"value":value,"url":origin} for name,value in session["cookies"].items()])
    context.route("**/*", lambda route: route.continue_() if urlsplit(route.request.url).hostname==urlsplit(origin).hostname else route.abort())
    page = context.new_page()
    errors=[]
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.set_default_timeout(10000)
    for key,query in routes:
        res=page.goto(base+query,wait_until="load")
        root=page.locator(".wrap.f3-ui")
        assert res.status==200 and root.count()==1,key
        root.locator("details").evaluate_all("xs=>xs.forEach(e=>e.open=true)")
        data=root.evaluate("""n=>{
          const controls=[...n.querySelectorAll('input:not([type=hidden]):not([type=submit]),select,textarea')];
          return {campos:controls.length,controles_sem_nome:controls.filter(e=>!e.labels?.length&&!e.getAttribute('aria-labelledby')).length,
            form_tables:n.querySelectorAll('table.form-table').length,cartoes:n.querySelectorAll('.f3-cards>.f3-card').length,
            tabelas_externas:[...n.querySelectorAll('table')].filter(t=>!t.closest('.f3-table-scroll')).length,
            grupos:n.querySelectorAll('.f3-groups a').length,ativo:n.querySelector('.f3-groups [aria-current]')?.textContent};}""")
        data["larguras"]={}
        for width in [360,768,1440]:
            page.set_viewport_size({"width":width,"height":850})
            data["larguras"][width]=page.evaluate("document.documentElement.scrollWidth")
            assert data["larguras"][width]==width,(key,width,data["larguras"])
        assert data["grupos"]==5 and data["ativo"]=="Configurações" and not data["form_tables"],(key,data)
        assert not data["controles_sem_nome"] and not data["tabelas_externas"],(key,data)
        evidence["rotas"][key]=data
    page.goto(base+"&secao=conexoes",wait_until="load")
    card=page.locator(".f3-cards a",has_text="Pipedrive")
    with page.expect_navigation(): card.click()
    detail=page.locator("#f3base-integ-dominio")
    anchor=detail.evaluate("e=>e.closest('details').id")
    index=page.locator("[data-f3base-indice-caixa]")
    index.locator("summary").click()
    index.locator('a[href="#'+anchor+'"]').click()
    assert detail.evaluate("e=>e.closest('details').open && document.activeElement===e.closest('details').querySelector('summary')")
    with page.expect_navigation(): page.get_by_role("link",name="Voltar a Conexões e entregas",exact=True).click()
    assert page.locator(".f3-cards a").count()==len(integrations)
    evidence["interacoes"]["indice_ancora_foco_e_voltar"]=True
    page.goto(base+"&aba=operacao&fila=avisos&pagina=2",wait_until="load")
    assert parse_qs(urlsplit(page.url).query)=={"page":["f3base-operacao"],"fila":["avisos"],"pagina":["2"]}
    evidence["interacoes"]["redirecionamento_com_parametros"]=True
    page.goto(base+"&secao=conexoes&integracao=f3base_avisos_tecnicos",wait_until="load")
    selector='[name="valores[f3base_avisos_tecnicos][carencia_por_codigo_minutos][token_vencendo]"]'
    sibling='[name="valores[f3base_avisos_tecnicos][carencia_por_codigo_minutos][agenda_parada]"]'
    original=page.locator(selector).input_value()
    other=page.locator(sibling).input_value()
    change="41" if original!="41" else "42"
    def submit(value,button):
        page.locator(selector).fill(value)
        with page.expect_navigation(): page.get_by_role("button",name=button,exact=True).click()
        result=page.locator(".f3-result")
        assert result.is_visible() and result.get_attribute("role")=="status"
        assert page.locator(sibling).input_value()==other
        return page.locator(selector).input_value()
    assert submit(change,"Simular alteração")==original
    assert submit(change,"Salvar política")==change
    assert submit(original,"Salvar política")==original
    page.locator(".f3-result button[data-f3-dismiss]").click()
    assert not page.locator(".f3-result").is_visible()
    evidence["interacoes"]["simulacao_escrita_releitura_restauracao_e_dispensar"]=True
    assert not errors,errors
    evidence["erros_javascript"]=len(errors)
    browser.close()
print(json.dumps(evidence,ensure_ascii=False,indent=2))
