<?php
/** Dados sintéticos apenas na transação do WordPress de bancada. */
if (wp_get_environment_type()!=='local' || DB_NAME!=='core_200_operacao') { throw new RuntimeException('Banco de ensaio obrigatório'); }
global $wpdb;
$wpdb->query('START TRANSACTION');
try {
    $marca = 'qa_painel_200';
    for ($i=1; $i<=24; ++$i) {
        $chave = hash('sha256', $marca . $i);
        $contato = substr($chave,0,32);
        $linhas = [
            F3Base_Execucoes::tabela()=>['origem'=>'manual','run_id'=>$chave,'entrada'=>'ensaio','inicio'=>$i,'codigo'=>$marca,'dados'=>'{}'],
            F3Base_Pipedrive_Fila::tabela()=>['chave'=>$chave,'record_id'=>$contato,'conta'=>'ensaio','journal'=>'{}','proxima'=>0,'capturado_em'=>$i,'atualizado_em'=>$i,'codigo'=>$marca],
            F3Base_Avisos::tabela()=>['chave'=>$chave,'record_id'=>$contato,'destino'=>'ensaio','payload'=>'{}','criada_em'=>$i,'atualizada_em'=>$i,'codigo'=>$marca],
            F3Base_Operacao_Intencoes::tabela()=>['chave'=>$chave,'escopo'=>$chave,'tarefa'=>'ensaio','hook'=>'ensaio','argumentos'=>'[]','ocorrencia_em'=>$i,'criada_em'=>$i,'atualizada_em'=>$i,'codigo'=>$marca],
        ];
        foreach($linhas as $tabela=>$linha) { if (!$wpdb->insert($tabela,$linha)) { throw new RuntimeException($wpdb->last_error); } }
    }
    $consultas=[
        'execucoes'=>fn($p,$q)=>F3Base_Execucoes::listar(['pagina'=>$p,'origem'=>'manual'],$q),
        'entregas'=>fn($p,$q)=>F3Base_Pipedrive_Fila::consultar(['pagina'=>$p,'estado'=>'pendente'],$q),
        'avisos'=>fn($p,$q)=>F3Base_Avisos::consultar(['pagina'=>$p,'incluir_partes'=>false,'estado'=>'pendente'],$q),
        'intencoes'=>fn($p,$q)=>F3Base_Operacao_Intencoes::painel($p,$q),
    ];
    foreach ($consultas as $nome=>$consultar) {
        $a=$consultar(1,$marca);$b=$consultar(2,$marca);$v=$consultar(1,'zzz%_impossivel');
        $itens=$nome==='intencoes'?'itens':'linhas';
        $id=match($nome){'intencoes'=>'intencao','execucoes'=>'run_id',default=>'chave'};
        if ($a['total']!==24 || $b['total']!==24 || count($a[$itens])!==20 || count($b[$itens])!==4 || $v['total']!==0
            || array_intersect(array_column($a[$itens],$id),array_column($b[$itens],$id))) { throw new RuntimeException($nome.' divergiu, total '.json_encode([$a['total'],$b['total'],$v['total']]).' '.$wpdb->last_error); }
        $provas[$nome]=['correspondencias'=>24,'primeira'=>20,'segunda'=>4,'repetidas'=>0,'busca_sem_correspondencia'=>0];
    }
} finally { $wpdb->query('ROLLBACK'); }
echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'listas'=>$provas],JSON_PRETTY_PRINT);
