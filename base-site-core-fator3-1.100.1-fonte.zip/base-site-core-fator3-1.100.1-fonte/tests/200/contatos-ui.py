"""Exercita o painel de Contatos, sem saída de rede ou e-mail do laboratório."""
import json
import os
from pathlib import Path
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright

if os.environ.get('F3LAB_DB') != 'core_200_contatos':
    raise RuntimeError('O ensaio requer um WordPress local descartável de Contatos.')
dados=json.loads(Path(os.environ['F3_CONTATOS_SESSAO']).read_text())
url=urlsplit(dados['url'])
assert url.hostname=='127.0.0.1' and url.scheme=='http'
provas=[]
def verificar(nome,estado):
    if not estado: raise AssertionError(nome)
    provas.append(nome)

with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.environ.get('F3_QA_CHROME','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':360,'height':800},locale='pt-BR')
    ctx.add_cookies([{'name':k,'value':v,'url':'http://'+url.netloc} for k,v in dados['cookies'].items()])
    page=ctx.new_page()
    page.route('**/*',lambda route: route.continue_() if urlsplit(route.request.url).hostname=='127.0.0.1' else route.abort())
    def abrir(suffix):
        page.goto(dados['url']+'?page='+suffix,wait_until='domcontentloaded')
    abrir('f3base-formularios')
    lista=page.locator('.f3base-editor')
    verificar('25 formulários e uma página de 20',lista.locator('tbody tr').count()==20 and lista.locator('.f3-list-total').inner_text()=='1–20 de 25')
    lista.get_by_role('button',name='Próxima').click()
    verificar('segunda página com cinco formulários',lista.locator('tbody tr').count()==5 and lista.locator('.f3-list-total').inner_text()=='21–25 de 25')
    lista.get_by_label('Buscar formulário').fill('amostra-23')
    verificar('busca por ID no catálogo inteiro',lista.locator('tbody tr').count()==1 and 'ensaio 23' in lista.locator('tbody tr').inner_text())
    lista.get_by_role('button',name='Editar').click()
    verificar('edição do item filtrado correto',lista.get_by_label('ID estável').input_value()=='amostra-23')
    lista.get_by_label('Título',exact=True).fill('Título editado no ensaio')
    with page.expect_navigation(wait_until='domcontentloaded'):
        page.get_by_role('button',name='Validar e visualizar').click()
    page.locator('.f3-result').first.wait_for()
    verificar('simulação mostra a prévia editada',page.locator('.f3-result[role=status]').count()==1 and 'Título editado' in page.locator('h2',has_text='Prévia de').inner_text())
    with page.expect_navigation(wait_until='domcontentloaded'):
        page.get_by_role('button',name='Salvar formulário',exact=True).click()
    verificar('salvamento e retorno ao ID do editor','formulario=amostra-23' in page.url and lista.get_by_label('Título',exact=True).input_value()=='Título editado no ensaio')
    verificar('editor sem estilos inline e com rótulos ligados',lista.locator('[style]').count()==0 and lista.locator('input:not([type=hidden]),select,textarea').evaluate_all('(ns)=>ns.every(n=>n.labels.length>0&&n.labels[0].htmlFor===n.id)'))
    lista.locator('details.f3-danger').last.locator('summary').click()
    page.once('dialog',lambda dialog:dialog.dismiss())
    lista.get_by_role('button',name='Remover definição').click()
    verificar('cancelamento preserva a definição',lista.get_by_label('ID estável').input_value()=='amostra-23')
    abrir('f3base-conteudos')
    materiais=page.locator('section',has=page.get_by_role('heading',name='Materiais disponíveis'))
    verificar('28 materiais e primeira página',materiais.locator('tbody tr').count()==25 and materiais.locator('.f3-list-total').inner_text()=='1–25 de 28')
    with page.expect_navigation(wait_until='domcontentloaded'):
        materiais.get_by_role('link',name='Próxima').click()
    verificar('segunda página de materiais',materiais.locator('tbody tr').count()==3 and materiais.get_by_role('link',name='Anterior').count()==1)
    materiais.get_by_label('Buscar por nome ou ID').fill('ensaio 07')
    with page.expect_navigation(wait_until='domcontentloaded'):
        materiais.get_by_role('button',name='Buscar material').click()
    verificar('busca de materiais reinicia página',materiais.locator('tbody tr').count()==1 and 'ensaio 07' in materiais.locator('tbody tr').inner_text())
    abrir('f3base-leads')
    for view,marker in [('Testes','teste'),('Lixeira','lixeira'),('Contatos','sem_marca')]:
        with page.expect_navigation(wait_until='domcontentloaded'):
            page.locator('.f3-switch').get_by_role('button',name=view).click()
        verificar('visão '+view,page.locator('.f3-switch [aria-pressed=true]').inner_text()==view and page.get_by_role('link',name='Contato de ensaio '+marker).count()==1)
    with page.expect_navigation(wait_until='domcontentloaded'):
        page.get_by_role('link',name='Contato de ensaio sem_marca').click()
    verificar('ficha reúne a jornada e tabelas contidas',page.locator('dl.f3-details').count()>0 and page.locator('.f3-ui table').evaluate_all('(ns)=>ns.every(t=>t.closest(".f3-table-scroll"))'))
    verificar('ficha com rótulos explícitos',page.locator('.f3-ui input:not([type=hidden]):not([type=submit]),.f3-ui select,.f3-ui textarea').evaluate_all('(ns)=>ns.every(n=>n.id&&n.labels&&Array.from(n.labels).some(l=>l.htmlFor===n.id))'))
    page.get_by_label('Atendimento',exact=True).select_option('respondido')
    with page.expect_navigation(wait_until='domcontentloaded'):
        page.get_by_role('button',name='Salvar atendimento').click()
    verificar('gravação protegida da ficha',page.locator('select[name=atendimento]').input_value()=='respondido')
    largura=page.evaluate('({largura:innerWidth,documento:document.documentElement.scrollWidth})')
    verificar('ficha sem transbordo a 360 px',largura['largura']==largura['documento'])
    browser.close()
print(json.dumps({'cenarios':provas,'total':len(provas),'largura_ficha':largura,'origem':'WordPress de loopback com metadados e contatos sintéticos'},ensure_ascii=False,indent=2))
