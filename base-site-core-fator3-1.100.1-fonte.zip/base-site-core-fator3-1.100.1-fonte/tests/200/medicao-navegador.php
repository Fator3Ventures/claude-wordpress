<?php
/** Fixtures exclusivamente locais para as ações de alternar, filtrar e paginar no navegador. */
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_200_medicao') throw new RuntimeException('Somente o banco local de Medição.');
global $wpdb;
$prefixo = 'qa-core-200-medicao-';
$tabela = F3Base_Editorial::tabela('medicao_anotacoes');
if (getenv('F3_MEDICAO_LIMPAR') === '1') {
    foreach ($wpdb->get_results($wpdb->prepare('SELECT id,revisao FROM %i WHERE chave LIKE %s',$tabela,$wpdb->esc_like($prefixo).'%'),ARRAY_A) as $item) {
        if (!F3Base_Inteligencia::anotacao_excluir(array_map('intval',$item))['ok']) throw new RuntimeException('Falha na limpeza de fixture');
    }
    return;
}
for ($i=1;$i<=26;$i++) {
    $chave = $prefixo.str_pad((string)$i,2,'0',STR_PAD_LEFT);
    if ($wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE chave=%s',$tabela,$chave))) continue;
    $r = F3Base_Inteligencia::anotar(['chave'=>$chave,'de'=>wp_date('Y-m-d'),'ate'=>wp_date('Y-m-d'),'motivo'=>'Ensaio descartável','excluir'=>false]);
    if (!$r['ok']) throw new RuntimeException('Não foi possível criar anotação de ensaio.');
}
$ate=time()+600;
$token=WP_Session_Tokens::get_instance(1)->create($ate);
echo wp_json_encode(['origem'=>get_site_url(),'cookies'=>[AUTH_COOKIE=>wp_generate_auth_cookie(1,$ate,'auth',$token),LOGGED_IN_COOKIE=>wp_generate_auth_cookie(1,$ate,'logged_in',$token)]]);
