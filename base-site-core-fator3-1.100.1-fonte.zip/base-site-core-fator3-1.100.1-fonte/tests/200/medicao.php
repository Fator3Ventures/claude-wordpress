<?php
/** Abertura no WordPress local do conteúdo de cada rota, com os controles sem JavaScript. */
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_200_medicao') throw new RuntimeException('Somente banco descartável de Medição.');
wp_set_current_user(1);
$registros = [];
function conferir_medicao($ok, string $msg): void {
    if (!$ok) throw new RuntimeException($msg.' ('.http_build_query($_GET).')');
}
foreach (F3Base_Medicao_Editorial_UI::AREAS + ['comportamento'=>'Sessões'] as $area=>$nome) {
    $analises = F3Base_Medicao_Editorial_UI::analises($area);
    $rotas = $area === 'comportamento' ? F3Base_Medicao_Interface::VISOES['comportamento'] : $analises;
    foreach ($rotas ?: [''=>'Área'] as $visao=>$rotulo) {
        $_GET = ['page'=>'f3base-medicao','area'=>$area,'visao'=>$visao];
        $_REQUEST = $_GET;
        ob_start();
        F3Base_Medicao_Interface::render();
        $html = ob_get_clean();
        $doc = new DOMDocument();
        $doc->loadHTML('<?xml encoding="UTF-8">'.$html, LIBXML_NOERROR|LIBXML_NOWARNING|LIBXML_NONET);
        $x = new DOMXPath($doc);
        $procurar = static fn($consulta) => $x->query($consulta);
        conferir_medicao($procurar('//h1')->length===1 && trim($procurar('//h1')->item(0)->textContent)==='Fator3 Site Core','Título único do pacote');
        conferir_medicao($procurar('//nav/div[@class="f3-groups"]/a')->length === 5,'Cinco grupos');
        conferir_medicao($procurar('//nav/div[@class="f3-subtabs"]/a')->length === 9,'Nove áreas');
        conferir_medicao($procurar('//nav/div[@class="f3-subtabs"]//span[@class="f3-subtabs-label"]')->length === 2,'Dois conjuntos identificados');
        conferir_medicao($procurar('//nav/div[@class="f3-subtabs"]//a[@aria-current]')->item(0)->textContent === $nome,'Subaba ativa');
        conferir_medicao($procurar('//table[not(ancestor::div[contains(@class,"f3-table-scroll")])]')->length === 0,'Rolagem das tabelas');
        foreach ($procurar('//select | //textarea | //input[not(@type="hidden") and not(@type="submit") and not(@type="button")]') as $campo) {
            $id = $campo->getAttribute('id');
            conferir_medicao($id !== '' && $procurar('//label[@for="'.$id.'"]')->length===1,'Rótulo explícito do campo '.$campo->getAttribute('name'));
        }
        if (count($analises)>5) {
            $opcoes=$procurar('//select[@name="visao"]/option');
            conferir_medicao($opcoes->length === count($analises),'Análises no campo de filtros');
            conferir_medicao($procurar('//select[@name="visao"]/option[@selected]')->item(0)->getAttribute('value')===$visao,'Análise selecionada');
        } elseif (count($analises)>1) {
            conferir_medicao($procurar('//form[@class="f3-switch"]/button')->length === count($analises),'Análises no alternador de visão');
            conferir_medicao($procurar('//form[@class="f3-switch"]/button[@aria-pressed="true"]')->item(0)->getAttribute('value')===$visao,'Visão selecionada');
        }
        $registros[] = $area.($visao?' / '.$visao:'');
    }
}
foreach (['aba'=>'acessos'] as $k=>$v) {
    $_GET=['page'=>'f3base-medicao',$k=>$v]; $_REQUEST=$_GET;
    ob_start(); F3Base_Medicao_Interface::render(); $html=ob_get_clean();
    conferir_medicao(str_contains($html,'id="f3base-acessos-filtros"'),'URL antiga de Acessos');
    $registros[]='aba=acessos';
}
echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'rotas'=>count($registros),'verificadas'=>$registros],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)."\n";
