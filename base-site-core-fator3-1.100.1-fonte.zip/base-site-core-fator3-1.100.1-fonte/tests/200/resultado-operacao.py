"""Exercita somente uma operação inexistente, sem contato com Slack."""
import json,sys,urllib.request,urllib.parse
import re
req=json.load(sys.stdin)
assert urllib.parse.urlsplit(req['url']).hostname == '127.0.0.1'
data=urllib.parse.urlencode({'action':'f3base_slack_manutencao','operacao':'acao_de_ensaio_inexistente','_wpnonce':req['nonce']}).encode()
request=urllib.request.Request(req['url'],data,headers={'Cookie':'; '.join(f'{k}={v}' for k,v in req['cookies'].items())})
with urllib.request.urlopen(request) as resp:
    html = resp.read().decode('utf-8')
    assert resp.status==200 and re.search(r'<header class="f3-heading">\s*<h1>Fator3 Site Core</h1>', html)
    assert re.search(r'<a [^<>]*aria-current="true"[^<>]*>Operação</a>', html)
    assert re.search(r'<pre[^>]*>[\s\S]*?acao_invalida[\s\S]*?</pre>', html)
    assert 'assets/f3-ui.css' in html
    print(json.dumps({'http':200,'ativo':'Operação','resultado':'acao_invalida','folha_carregada':True,'servico_externo':False},ensure_ascii=False))
