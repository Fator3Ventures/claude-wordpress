<?php
/** Executar em nova requisição WP-CLI depois de instalar e ativar o ZIP oficial. */
if (wp_get_environment_type() !== 'local' || !in_array(DB_NAME, ['core_200_limpa','core_200_troca'], true)) {
    throw new RuntimeException('Use uma instalação local descartável.');
}
$esperada = '1.100.1';
F3Base_Zelador::atualizacao_urgente();
$estado = F3Base_Instalacao::resumo();
if (($estado['versao_alvo'] ?? '') !== $esperada || ($estado['estado'] ?? '') !== 'concluida'
    || ($estado['falhas'] ?? -1) !== 0 || empty($estado['confirmada_no_executor_em'])) {
    throw new RuntimeException('Ciclo não confirmado: '.wp_json_encode($estado));
}
$limpa = DB_NAME === 'core_200_limpa';
$base = getenv('F3_BASE_ENSAIO') ?: '1.100.0';
if (!$limpa && ($estado['versao_anterior'] ?? '') !== $base) {
    throw new RuntimeException('A instalação de troca não partiu da base indicada.');
}
if (!$limpa && (F3Base_Options::ler('f3base_avisos_tecnicos')['atraso_minutos'] ?? 0) !== 77) {
    throw new RuntimeException('A política persistida na base foi alterada durante a instalação.');
}
$registradas = array_filter(array_keys(wp_get_abilities()), static fn($nome) => str_starts_with($nome, 'f3base/'));
$contrato = ['versao'=>F3Base_Config_Contrato::VERSAO,'piso'=>F3Base_Config_Perfil::ID,
    'options_operaveis'=>count(array_filter(F3Base_Options::proprias(), [F3Base_Options::class,'operavel'])),
    'abilities'=>count($registradas)];
$verificar = ['f3base/incidentes-tecnicos-ler'=>[], 'f3base/documentacao-ler'=>[]];
$acesso = [];
foreach ([1, 0] as $id) {
    wp_set_current_user($id);
    foreach ($verificar as $nome => $args) {
        $ability = wp_get_ability($nome);
        if (!$ability) { throw new RuntimeException('Habilidade ausente: '.$nome); }
        $res = $ability->check_permissions($args);
        if (($res === true) !== ($id === 1 && $limpa)) { throw new RuntimeException('Autorização inesperada: '.$nome); }
        $acesso[$id === 1 ? 'admin_local_sem_conexao' : 'anonimo'][$nome] = is_wp_error($res) ? $res->get_error_code() : $res;
    }
}
echo wp_json_encode(['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'bits'=>PHP_INT_SIZE*8,
    'instalacao'=>array_intersect_key($estado,array_flip(['versao_alvo','versao_anterior','estado','falhas','iniciado_em','confirmada_no_executor_em'])),
    'etapas'=>count($estado['etapas']),'contrato'=>$contrato,'permissoes'=>$acesso,'opcao_anterior_preservada'=>$limpa ? null : true],JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
