# Ensaios de e-mail dos incidentes técnicos

Use as duas versões oficiais em bancos descartáveis do WordPress, com correio e HTTP externo interceptados. O banco de comparação e de execução da suíte chama-se `core_199_provas`. Os scripts assumem administrador local e `WP_ENVIRONMENT_TYPE=local`.

1. Na 1.98.0, execute `wp --user=1 eval "require '/caminho/base-439.php';"`. O mesmo incidente de agenda é aberto e recuperado em segundos. O interceptor deve capturar abertura e recuperação.
2. Atualize o mesmo WordPress para a versão em teste. Execute `wp --user=1 eval "require '/caminho/provas-439.php';"`. O ensaio publica pelo filtro PHP dos produtores, lê pelas mesmas rotinas de `f3base/incidentes-tecnicos-ler` e compara os registros com chamadas reais a `wp_mail` interceptadas antes do transporte. Retorna código de erro se uma expectativa falhar.
3. Execute `wp --user=1 eval "require '/caminho/retomada-439.php';"`. Em banco isolado, o observador usado pelo zelador processa uma abertura vencida mesmo sem republicação do produtor. A segunda passagem verifica a deduplicação. O caso dispensa expiração do transiente apenas no WordPress descartável.

## Site-Teste

Apenas para a homologação do pacote, compacte a pasta `qa-core-439/` com ela como raiz do ZIP e confira o hash. A instalação é temporária e exige acesso administrativo. O plugin limita o host ao Site-Teste ou ao banco local da suíte. Confirme a ausência de uma instalação anterior e das opções de comando, resultado e leitura antes de começar.

Após instalar o Core e confirmar a versão e o executor, ative a fixture e grave o valor literal `executar-439` na opção exclusiva `f3qa439_comando`. Essa operação exige `manage_options`. A escrita dispara os cenários fechados no mesmo pedido. Leia `f3qa439_resultado`, confira `ok=true`, os recibos e os três IDs em `amostra_para_leitura`. Leia os três registros pela operação pública administrativa `f3base/incidentes-tecnicos-ler`, com paginação quando necessário. Atualize `f3qa439_comando` para `limpar-439` e confira `registros_proprios_restantes=0` na resposta armazenada em `f3qa439_resultado`. Exclua as opções de comando e resultado, desative e remova a fixture.

Os testes envelhecem somente as referências sintéticas que criaram. No caso de 31 minutos, a primeira observação local e a abertura pendente são envelhecidas em conjunto. Na janela de 24 horas, somente o fim da janela do ensaio é adiantado para o instante anterior à leitura. Os dois mecanismos evitam mudar o relógio do WordPress. O endereço de ensaio é fornecido em memória e cada referência tem um interceptor seletivo. O escopo da prova termina na aceitação pelo transporte WordPress interceptado. Nenhuma mensagem deve ser entregue a uma caixa postal. O histórico e as opções alheias permanecem fora da limpeza.
