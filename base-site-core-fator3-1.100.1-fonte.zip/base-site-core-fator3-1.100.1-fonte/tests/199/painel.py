"""Percorre o formulário de política no wp-admin de uma instalação local descartável."""
from pathlib import Path
from urllib.parse import urlsplit
import json
import os
from playwright.sync_api import sync_playwright

if os.environ.get('F3LAB_DB') != 'core_199_painel':
    raise RuntimeError('Use a instalação de painel descartável.')
dados = json.loads(Path(os.environ['F3_439_SESSAO']).read_text())
url = urlsplit(dados['url'])
if url.scheme != 'http' or url.hostname != '127.0.0.1' or not url.path.startswith('/wp-admin/'):
    raise RuntimeError('O ensaio exige wp-admin de loopback.')

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=os.environ.get('F3_QA_CHROME','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
    context = browser.new_context(viewport={'width':1440,'height':1000})
    context.add_cookies([{'name':k,'value':v,'url':'http://'+url.netloc} for k,v in dados['cookies'].items()])
    pg = context.new_page()
    pg.route('**/*',lambda route: route.continue_() if urlsplit(route.request.url).hostname=='127.0.0.1' else route.abort())
    pg.goto(dados['url'], wait_until='domcontentloaded',timeout=30000)
    form = pg.locator('form:has(input[name="area"][value="avisos-tecnicos"])')
    def field(s):
        return form.locator('input[name="valores[f3base_avisos_tecnicos]'+s+'"]')
    def show(node):
        node.evaluate("e=>{for(let n=e.parentElement;n;n=n.parentElement)if(n.tagName==='DETAILS')n.open=true;}")
    def submitted(button):
        el=form.get_by_role('button',name=button,exact=True)
        show(el)
        with pg.expect_navigation(wait_until='domcontentloaded'): el.click()
        return pg.locator('p[role=status].notice-inline').inner_text()
    grace=field('[carencia_por_codigo_minutos][agenda_parada]')
    group=field('[janela_agrupamento_horas]')
    unchanged=field('[carencia_por_codigo_minutos][canal_indisponivel]')
    key_fields=form.locator('input[name*="[carencia_por_codigo_minutos]"]')
    assert grace.count()==1 and key_fields.count()>2
    baseline=[grace.input_value(),group.input_value(),unchanged.input_value()]
    assert baseline==['30','24','30'],baseline
    def edit():
        show(grace); show(group)
        grace.fill('41'); group.fill('12')
    telas = []
    for largura in (360,782,1440):
        pg.set_viewport_size({'width':largura, 'height':900})
        show(grace)
        leitura = key_fields.evaluate_all("""campos => {
            const iguais = [];
            const falhas = [];
            for(const c of campos){
                const label = document.querySelector('label[for="' + CSS.escape(c.id) + '"]');
                c.scrollIntoView({block:'center',inline:'nearest'});
                const caixa=c.getBoundingClientRect(), rotulo=label?.getBoundingClientRect();
                const codigo=c.name.split('[').pop().replace(']','');
                const x = window.innerWidth;
                const noCampo = caixa.left>=-1 && caixa.right<=x+1 && caixa.width>0;
                const noRotulo = rotulo && rotulo.left>=-1 && rotulo.right<=x+1 && rotulo.width>0 && label.innerText.trim().length>0;
                c.focus({preventScroll:true});
                if(noCampo && noRotulo && document.activeElement===c && window.scrollX===0){ iguais.push(codigo); }
                else { falhas.push({codigo,campo:[caixa.left,caixa.right],rotulo:rotulo?[rotulo.left,rotulo.right]:null,deslocamento_horizontal:window.scrollX}); }
            }
            return {visiveis:iguais.length,total:campos.length,falhas,largura_documento:document.documentElement.scrollWidth};
        }""")
        assert leitura['visiveis']==leitura['total'] and not leitura['falhas'],(largura,leitura)
        telas.append({'viewport':largura,**leitura})
    edit()
    sim=submitted('Simular alteração')
    after_sim=[grace.input_value(),group.input_value(),unchanged.input_value()]
    assert after_sim==baseline,(sim,after_sim)
    edit()
    saved=submitted('Salvar política')
    pg.reload(wait_until='domcontentloaded')
    after_save=[grace.input_value(),group.input_value(),unchanged.input_value()]
    assert after_save==['41','12','30'],(saved,after_save)
    print(json.dumps({'navegador':'Chromium','telas':telas,'campos_carencia':key_fields.count(),'inicial':baseline,'apos_simulacao':after_sim,
          'apos_salvar_e_reabrir':after_save,'mensagem_simulacao':sim,'mensagem_salvar':saved},ensure_ascii=False,indent=2))
