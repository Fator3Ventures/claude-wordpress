<?php
/** WP-CLI num WordPress descartável. Não envia e-mails. */
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_199_config') {
    throw new RuntimeException('Laboratório de configuração do Core 1.99 obrigatório.');
}
$opcao = 'f3base_avisos_tecnicos';
$dec = F3Base_Options::declaracao($opcao);
$fotos = static fn() => F3Base_Options::fotografia('f3base_avisos_tecnicos');
$original = $fotos();
$registros = [];
$checar = static function ($nome, $valor) use (&$registros) {
    if (!$valor) { throw new RuntimeException($nome); }
    $registros[] = $nome;
};
$legado = ['email'=>'ensaio@example.invalid','antecedencia_dias'=>42,'atraso_minutos'=>91,'resumo_diario'=>false,
    'imap_falhas_consecutivas'=>5,'imap_sem_leitura_minutos'=>22,'imap_codigos_passageiros'=>['imap_prazo_excedido'],'robots_sem_confirmacao_minutos'=>230];
try {
    // Representação bruta da 1.98.0, antes de existirem os dois campos.
    update_option($opcao,$legado);
    $foto = $fotos();
    $checar('valores legados preservados', F3Base_Options::equivalente(array_intersect_key($foto['valor'],$legado),$legado));
    $mapa = $foto['valor']['carencia_por_codigo_minutos'];
    $urgentes = ['autorizacao_recusada','credencial_recusada','credencial_invalida','concessao_revogada','destino_tecnico_ausente','site_fora_do_ar'];
    $checar('todos os códigos têm padrão',count($mapa) === count(F3Base_Incidentes::CODIGOS));
    foreach (F3Base_Incidentes::CODIGOS as $codigo) {
        $checar('padrão '.$codigo,F3Base_Alertas_Operacionais::carencia_minutos($codigo) === (in_array($codigo,$urgentes,true) ? 0 : 30));
    }
    $checar('janela padrão 24h', F3Base_Alertas_Operacionais::janela_agrupamento_horas() === 24);
    $req = ['nome'=>$opcao, 'revisao_esperada'=>$foto['revisao'], 'operacoes'=>[
        ['operacao'=>'definir','caminho'=>'/carencia_por_codigo_minutos/agenda_parada','valor'=>41],
        ['operacao'=>'definir','caminho'=>'/janela_agrupamento_horas','valor'=>12],
    ]];
    $sim = F3Base_Core_Config_Mcp::escrever($req+['simular'=>true]);
    $checar('simulação MCP sem gravação', ($sim['simulado']??false) && !empty($sim['alteraria']) && $fotos()['revisao'] === $foto['revisao']);
    $aplicado = F3Base_Core_Config_Mcp::escrever($req+['simular'=>false]);
    $checar('gravação parcial MCP com revisão', ($aplicado['persisted']??false) && F3Base_Alertas_Operacionais::carencia_minutos('agenda_parada') === 41 && F3Base_Alertas_Operacionais::janela_agrupamento_horas() === 12);
    $obsoleta = F3Base_Core_Config_Mcp::escrever($req+['simular'=>false]);
    $checar('revisão obsoleta recusada', empty($obsoleta['persisted']));
    $foto = $fotos();
    $checar('opções irmãs preservadas', F3Base_Options::equivalente(array_intersect_key($foto['valor'],$legado),$legado));
    $invalidos = [
        ['/carencia_por_codigo_minutos/agenda_parada',-1], ['/carencia_por_codigo_minutos/agenda_parada',10081],
        ['/carencia_por_codigo_minutos/agenda_parada','30'], ['/carencia_por_codigo_minutos/codigo_inexistente',35],
        ['/janela_agrupamento_horas',721], ['/janela_agrupamento_horas',-1],
    ];
    foreach ($invalidos as [$caminho,$novo]) {
        $r=F3Base_Core_Config_Mcp::escrever(['nome'=>$opcao,'simular'=>false,'revisao_esperada'=>$foto['revisao'],'operacoes'=>[['operacao'=>'definir','caminho'=>$caminho,'valor'=>$novo]]]);
        $checar('valor inválido recusado '.$caminho.' '.wp_json_encode($novo), empty($r['persisted']) && $fotos()['revisao'] === $foto['revisao']);
    }
    $_GET['integracao']=$opcao; $_GET['secao']='conexoes';
    ob_start(); F3Base_Integracoes::render(); $html=ob_get_clean();
    $doc=new DOMDocument(); @$doc->loadHTML($html); $xp=new DOMXPath($doc);
    $form=$xp->query("//form[input[@name='area' and @value='avisos-tecnicos']]")->item(0);
    $checar('formulário protegido com nonce e revisão', $form && $xp->query(".//input[@name='_wpnonce']",$form)->length === 1 && str_contains($html,$foto['revisao']));
    $checar('um campo numérico rotulado para cada código e a janela', $xp->query(".//input[@type='number']",$form)->length === 1+count($mapa));
    $checar('botões de simular e salvar presentes',$xp->query(".//input[@name='simular']",$form)->length===1 && $xp->query(".//input[@name='submit']",$form)->length===1);
    $enviar = ['email'=>$legado['email'],'janela_agrupamento_horas'=>'0','carencia_por_codigo_minutos'=>array_map('strval',$foto['valor']['carencia_por_codigo_minutos'])];
    $enviar['carencia_por_codigo_minutos']['agenda_parada']='17';
    $painel = ['area'=>'avisos-tecnicos','valores'=>[$opcao=>$enviar],'revisoes'=>[$opcao=>$foto['revisao']]];
    $ret = F3Base_Config_Central::processar($painel+['simular'=>'1']);
    $checar('simulação do painel', ($ret['ok']??false) && !$ret['salvas'] && $fotos()['revisao'] === $foto['revisao']);
    $ret = F3Base_Config_Central::processar($painel);
    $checar('painel grava carência e desativa agrupamento', ($ret['ok']??false) && F3Base_Alertas_Operacionais::carencia_minutos('agenda_parada')===17 && F3Base_Alertas_Operacionais::janela_agrupamento_horas()===0);
    $ret = F3Base_Config_Central::processar($painel);
    $checar('painel recusa conflito de revisão', ($ret['http']??0) === 409);
    $checar('painel mantém parâmetros de IMAP/robots e destino',F3Base_Options::equivalente(array_intersect_key($fotos()['valor'],$legado),$legado));
    $atual=$fotos();
    $painel['revisoes'][$opcao]=$atual['revisao'];
    unset($painel['valores'][$opcao]['carencia_por_codigo_minutos']['agenda_parada']);
    $ret = F3Base_Config_Central::processar($painel);
    $checar('painel recusa mapa truncado',($ret['http']??0)===400 && $fotos()['revisao']===$atual['revisao']);
    wp_set_current_user(0);
    $ret = F3Base_Config_Central::processar($painel);
    $checar('painel recusa acesso anônimo',($ret['http']??0)===403);
    wp_set_current_user(1);
    echo wp_json_encode(['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'plugin'=>F3BASE_PLUGIN_VERSAO,'contrato'=>F3Base_Config_Contrato::VERSAO,'verificacoes'=>$registros,'aprovadas'=>count($registros)], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
} finally {
    wp_set_current_user(1);
    update_option($opcao,$original['valor']);
}
