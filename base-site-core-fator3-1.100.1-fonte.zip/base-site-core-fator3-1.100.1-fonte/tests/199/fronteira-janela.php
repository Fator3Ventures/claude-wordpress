<?php
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_199_provas' || !current_user_can('manage_options')) {
    throw new RuntimeException('Instalação descartável de provas obrigatória');
}
$cfg = F3Base_Options::ler('f3base_avisos_tecnicos');
$cfg['email'] = 'qa-core-439@example.invalid';
$cfg['resumo_diario'] = false;
$cfg['carencia_por_codigo_minutos']['agenda_parada'] = 30;
$cfg['janela_agrupamento_horas'] = 24;
add_filter('pre_option_f3base_avisos_tecnicos', static fn() => $cfg, PHP_INT_MAX);
$corpos = [];
add_filter('pre_wp_mail', static function ($anterior, $mail) use (&$corpos) {
    $corpos[] = $mail['message'];
    return true;
}, PHP_INT_MIN, 2);
$resultados = [];
foreach ([-1,0] as $diferenca) {
    $recurso = 'qa439-fronteira-'.$diferenca.'-'.wp_generate_uuid4();
    $ref = hash_hmac('sha256', $recurso, wp_salt('auth'));
    $key = 'f3base_incidente_v1_'.hash('sha256', 'canal|agenda_parada|'.$ref);
    $publicar = static fn($estado) => apply_filters('f3base_incidente_publicar_v1', null,
        ['pacote'=>'canal','codigo'=>'agenda_parada','recurso'=>$recurso,'estado'=>$estado]);
    try {
        $publicar('aberto');
        $r = get_option($key);
        $r['observado_em'] = $r['fila'][0]['observado_em'] = time() - 1900;
        update_option($key, $r, false);
        $publicar('aberto');
        $publicar('recuperado');
        $publicar('aberto');
        $r = get_option($key);
        $fim = time() - 60;
        $r['agrupamento']['inicio_em'] = $fim - DAY_IN_SECONDS;
        $r['agrupamento']['ate'] = $fim;
        $r['observado_em'] = $r['fila'][0]['observado_em'] = $fim + $diferenca - 1800;
        update_option($key, $r, false);
        delete_transient('f3base_incidentes_revisados');
        F3Base_Incidentes::observar();
        $publicar('recuperado');
        $r = get_option($key);
        $esperado = $diferenca < 0 ? ['aberto','recuperado','agrupado'] : ['aberto','recuperado','aberto','recuperado'];
        $fases = array_column($r['fases_enviadas'], 'fase');
        $mails = count(array_filter($corpos, static fn($corpo) => str_contains($corpo, $ref)));
        if ($esperado !== $fases || $mails !== count($esperado) || $r['fila']) throw new RuntimeException(wp_json_encode([$diferenca,$fases,$mails]));
        $resultados[] = ['elegibilidade_menos_fim_segundos'=>$diferenca,'fases'=>$fases,'mensagens_interceptadas'=>$mails];
    } finally {
        delete_option($key);
    }
}
echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'ok'=>true,'casos'=>$resultados], JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
