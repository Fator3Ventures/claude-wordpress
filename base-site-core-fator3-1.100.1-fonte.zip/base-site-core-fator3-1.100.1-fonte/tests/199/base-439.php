<?php
if (wp_get_environment_type()!=='local' || DB_NAME!=='core_199_provas' || !current_user_can('manage_options') || F3BASE_PLUGIN_VERSAO!=='1.98.0') {
    throw new RuntimeException('Base oficial local necessária.');
}
$recurso='qa439-prova-da-base';
$ref=hash_hmac('sha256',$recurso,wp_salt('auth'));
$key='f3base_incidente_v1_'.hash('sha256','canal|agenda_parada|'.$ref);
if (get_option($key,null)!==null) { throw new RuntimeException('Registro pré-existente.'); }
$cfg=F3Base_Options::ler('f3base_avisos_tecnicos');$cfg['email']='qa-core-439@example.invalid';
add_filter('pre_option_f3base_avisos_tecnicos',static fn()=>$cfg,PHP_INT_MAX);
$fases=[];
add_filter('pre_wp_mail',static function($pre,$mail)use(&$fases,$ref){
    if (str_contains($mail['message'],$ref)) { $fases[]=$mail['subject'];return true; }
    return $pre;
},PHP_INT_MIN,2);
try {
    foreach (['aberto','recuperado'] as $fase) {
        $r=apply_filters('f3base_incidente_publicar_v1',null,['pacote'=>'canal','codigo'=>'agenda_parada','recurso'=>$recurso,'estado'=>$fase]);
        if (empty($r['ok'])) {throw new RuntimeException('Fluxo da base indisponível');}
    }
    if (count($fases)!==2) { throw new RuntimeException('O caso relatado não foi reproduzido na base'); }
    echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'intervalo_menor_que_30_minutos'=>true,'mensagens_interceptadas'=>$fases],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
} finally { delete_option($key); }
