set -euo pipefail
usar_candidato
wpcli eval "require '$PWD/S/tests/199/provas-439.php';" > "$PWD/S/evidence/1990/provas-439-local.json"
wpcli eval "require '$PWD/S/tests/199/retomada-439.php';" > "$PWD/S/evidence/1990/retomada-439-local.json"
