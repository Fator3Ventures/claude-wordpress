<?php
/** Testa o produtor interno pelas entradas normais observar/acompanhar em banco descartável. */
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_199_google') throw new RuntimeException('Banco descartável obrigatório');
$checks = [];
$assert = static function($valor, string $nome) use (&$checks) {
    if (!$valor) throw new RuntimeException($nome);
    $checks[] = $nome;
};
$assuntos = [];
add_filter('pre_wp_mail',static function ($v,$args) use (&$assuntos) {
    $assuntos[] = $args['subject'];
    return true;
},1,2);
add_filter('pre_http_request',static fn()=>new WP_Error('offline','Sem tráfego externo no ensaio.'),PHP_INT_MIN);
$chave = static fn(string $codigo) => 'f3base_incidente_v1_'.hash('sha256','core|'.$codigo.'|'.hash_hmac('sha256','captacao-meta',wp_salt('auth')));
$generico = 'captacao_meta_indisponivel';
$credencial = 'credencial_invalida';
$config = F3Base_Options::ler('f3base_anuncios_meta');
$config['ativo'] = true;
update_option('f3base_anuncios_meta',$config);
$avisos = F3Base_Options::ler('f3base_avisos_tecnicos');
$avisos['email'] = 'ensaio@example.invalid';
update_option('f3base_avisos_tecnicos',$avisos);
$base = ['ativado_em'=>time(),'ultimo_inicio'=>time(),'ultima_execucao_agendada'=>time(),'ultimo_sucesso_completo'=>time()];
$estado = static function (array $falha, ?array $legado = null) use ($base) {
    $s = get_option('f3base_anuncios_estado',[]);
    $s['meta'] = $falha + $base + ['alerta'=>$legado ?? $s['meta']['alerta'] ?? []];
    update_option('f3base_anuncios_estado',$s);
};
$alerta = static fn() => get_option('f3base_anuncios_estado',[])['meta']['alerta'] ?? [];
$incidente = static fn(string $codigo) => (array)get_option($chave($codigo),[]);
delete_option($chave($generico));
delete_option($chave($credencial));
$estado(['estado'=>'pendente','codigo'=>'falha_de_ensaio'],[]);
F3Base_Captacao_Operacao::acompanhar();
$id = $alerta()['ativo'];
$assert($id !== '' && $incidente($generico)['estado'] === 'aberto' && !$assuntos,'Falha de captação abriu com carência');
$estado(['estado'=>'verificada','codigo'=>'']);
F3Base_Captacao_Operacao::observar();
$assert($incidente($generico)['estado'] === 'recuperado' && $incidente($generico)['suprimido_por_carencia'] && !$assuntos,'Falha técnica curta suprimida na central');
$assert($alerta()['incidentes'][$id]['fechamento']['estado'] === 'registrada','Recibo de fechamento no histórico da captação');
$falha_credencial = ['estado'=>'pendente','codigo'=>'graph_acesso_recusado','diagnostico_graph'=>[
    'codigo'=>'graph_acesso_recusado','em'=>time(),'http'=>400,'graph_code'=>190,
]];
$estado(['estado'=>'pendente','codigo'=>'graph_acesso_recusado','diagnostico_graph'=>['codigo'=>'graph_acesso_recusado','em'=>time(),'http'=>503]]);
F3Base_Captacao_Operacao::observar();
$assert($incidente($generico)['estado'] === 'aberto' && !$assuntos,'HTTP 503 segue no incidente transitório');
$estado(['codigo'=>'formularios_parcialmente_disponiveis'] + $falha_credencial);
$assert(F3Base_Captacao_Operacao::diagnostico()['codigo_incidente'] === $credencial,'Graph 190 da mesma execução reconhecido na coleta parcial');
$estado($falha_credencial);
F3Base_Captacao_Operacao::acompanhar();
$assert($incidente($generico)['estado'] === 'recuperado' && $incidente($credencial)['estado'] === 'aberto' && count($assuntos) === 1,'Graph 190 atual fecha falha genérica e dispara credencial imediatamente');
$estado(['estado'=>'verificada','codigo'=>'']);
F3Base_Captacao_Operacao::observar();
F3Base_Captacao_Operacao::acompanhar();
$assert(array_column($incidente($credencial)['fases_enviadas'],'fase') === ['aberto','recuperado'] && count($assuntos) === 2,'Recuperação do token comunicada exatamente uma vez');
foreach (['processado', 'incerto'] as $resultado) {
    $marca = 'legado-'.$resultado;
    $item = ['id'=>$marca, 'inicio'=>time()-500,'fim'=>null,'causa'=>'codigo_antigo','estado_abertura'=>'falha',
        'abertura'=>['estado'=>'tentada','resultado'=>['estado'=>$resultado]],'fechamento'=>['estado'=>'pendente']];
    $estado(['estado'=>'verificada','codigo'=>''],['schema'=>2,'ativo'=>$marca,'incidentes'=>[$marca=>$item]]);
    F3Base_Captacao_Operacao::acompanhar();
    F3Base_Captacao_Operacao::acompanhar();
    $assert(count($assuntos) === 3, 'Recuperação legada somente com abertura processada · '.$resultado);
}
// A mudança de versão pode ocorrer depois da central persistir mas antes de o produtor ler o recibo.
$estado(['estado'=>'pendente','codigo'=>'falha_de_ensaio'],[]);
F3Base_Captacao_Operacao::observar();
$a = $alerta(); $primeiro = $a['ativo'];
$a['incidentes'][$primeiro]['abertura']['estado'] = 'confirmacao_central';
$estado(['estado'=>'pendente','codigo'=>'falha_de_ensaio'],$a);
F3Base_Captacao_Operacao::acompanhar();
$assert($alerta()['ativo'] === $primeiro && $alerta()['incidentes'][$primeiro]['abertura']['estado'] === 'registrada' && count($assuntos) === 3,'Recibo reapresentado preserva o episódio e evita duplicata');
$estado(['estado'=>'verificada','codigo'=>'']);
F3Base_Captacao_Operacao::observar();
$historico = $alerta()['incidentes'];
$historico[$primeiro]['fechamento']['estado'] = 'confirmacao_central';
$estado(['estado'=>'pendente','codigo'=>'falha_de_ensaio'],['schema'=>3,'ativo'=>'','incidentes'=>$historico]);
F3Base_Captacao_Operacao::acompanhar();
$assert($alerta()['ativo'] !== $primeiro && $incidente($generico)['estado'] === 'aberto'
    && $alerta()['incidentes'][$primeiro]['fechamento']['estado'] === 'registrada','Fechamento retomado antes da abertura nova do recurso');
$retido = ['id'=>'legado-retido','inicio'=>time()-800,'fim'=>time()-30,'duracao_segundos'=>770,'causa'=>'falha_legada',
    'abertura'=>['estado'=>'tentada','resultado'=>['estado'=>'processado']],
    'fechamento'=>['estado'=>'pendente','tentar_apos'=>time()+300]];
$estado($falha_credencial,['schema'=>2,'ativo'=>'','incidentes'=>['legado-retido'=>$retido]]);
F3Base_Captacao_Operacao::observar();
$a = $alerta(); $novo = $a['ativo'];
$assert($novo !== '' && $a['incidentes'][$novo]['abertura']['estado'] === 'pendente' && count($assuntos) === 3,
    'Nova abertura aguarda a recuperação legada adiada e confirmada');
$a['incidentes']['legado-retido']['fechamento']['tentar_apos'] = time()-1;
$estado($falha_credencial,$a);
F3Base_Captacao_Operacao::acompanhar();
F3Base_Captacao_Operacao::acompanhar();
$assert($alerta()['incidentes'][$novo]['abertura']['estado'] === 'registrada' && count($assuntos) === 4 && ($incidente($credencial)['agrupamento']['repeticoes'] ?? 0) === 1
    && str_contains($assuntos[3],'Captação Meta recuperada'),'Retomada libera a recuperação legada antes da nova abertura, uma vez');
echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'wp'=>get_bloginfo('version'),'php'=>PHP_VERSION,'total'=>count($checks),
    'verificacoes'=>$checks,'tentativas_de_email_interceptadas'=>count($assuntos)],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
