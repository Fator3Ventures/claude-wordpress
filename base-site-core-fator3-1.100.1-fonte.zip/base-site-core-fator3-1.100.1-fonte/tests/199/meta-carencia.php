<?php
/** Requer WordPress local isolado, Core da rodada e pacote Meta 0.31 ativo. */
use Fator3\Meta\Store;
use Fator3\Meta\Worker;

if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_199_revisao') {
    throw new RuntimeException('Execute no laboratório Core 199 de revisão.');
}
$cfg = F3Base_Options::ler('f3base_avisos_tecnicos');
$cfg['email'] = 'core-revisao@example.invalid';
if (empty(F3Base_Options::gravar('f3base_avisos_tecnicos',$cfg)['persisted'])) {
    throw new RuntimeException('Configuração temporária recusada.');
}
$provas = [];
$verificar = static function(string $nome, bool $ok) use (&$provas): void {
    if (!$ok) { throw new RuntimeException($nome); }
    $provas[$nome] = true;
};
$rede = 0;
add_filter('pre_http_request', static function($anterior) use (&$rede) {
    ++$rede;
    return new WP_Error('teste_local_sem_http');
}, 1);
$mensagens = [];
add_filter('pre_wp_mail', static function($prev,$args) use (&$mensagens) {
    $mensagens[] = $args['message'];
    return true;
}, PHP_INT_MAX, 2);
$seed = substr(wp_generate_password(10,false,false),0,10);
$conexao = 'con-'.strtolower($seed);
$agenda = 'ag-'.strtolower($seed);
$outra = 'exp-'.strtolower($seed);
$conta = static function($id,$expira) {
    return ['id'=>$id,'label'=>$id,'enabled'=>true,'token'=>'amostra-local','expires_at'=>$expira,'assets'=>[],'authorization_revision'=>1,'credential_generation'=>1];
};
$registro = static function($tipo,$id) {
    $recurso = hash('sha256',$tipo.'|'.$id);
    $ref = hash_hmac('sha256',$recurso,wp_salt('auth'));
    return [get_option('f3base_incidente_v1_'.hash('sha256','meta|agenda_parada|'.$ref),[]),$ref];
};
$contar = static function($ref) use (&$mensagens) {
    return count(array_filter($mensagens,static fn($msg)=>str_contains($msg,$ref)));
};
Store::put('connection',$conexao,$conta($conexao,time()+86400));
$ficha = ['enabled'=>true,'label'=>$agenda,'query'=>['connection_id'=>$conexao,'report'=>'daily_account_insights','channel'=>'instagram'],
    'interval_minutes'=>60,'next_at'=>time()+3600,'last_run_status'=>'failed','last_code'=>'asset_access_denied',
    'last_error'=>['code'=>'asset_access_denied','auth_scope'=>'resource','observed_at'=>time()-3600],
    'collection_failure_since'=>time()-3600,'collection_observation_started_at'=>time()-30*3600];
Store::put('schedule',$agenda,$ficha);
Worker::notify();
[$r,$ref] = $registro('schedule_overdue',$agenda);
$verificar('uma_hora_sem_incidente_de_agenda', !$r && $contar($ref) === 0);
$ficha['collection_failure_since'] = time()-27*3600;
Store::put('schedule',$agenda,$ficha,Store::get('schedule',$agenda)['revision']);
Worker::notify();
[$r,$ref] = $registro('schedule_overdue',$agenda);
$verificar('push_recusa_de_recurso_mantem_carencia', ($r['estado']??'') === 'aberto' && ($r['codigo_carencia']??'') === 'agenda_parada' && $contar($ref) === 0);
// Em Meta .31, token_rejected da rota do ativo também pode sobreviver a /me saudável.
$ficha['last_code'] = 'token_rejected';
$ficha['last_error']['code'] = 'token_rejected';
Store::put('schedule',$agenda,$ficha,Store::get('schedule',$agenda)['revision']);
F3Base_Incidentes_Provedores::meta();
[$semProva] = $registro('schedule_overdue',$agenda);
$verificar('rejeicao_no_ativo_sem_confirmacao_do_token', $semProva['codigo_carencia'] === 'agenda_parada' && $contar($ref) === 0);
Store::put('collection_failure',$conexao,['code'=>'grant_revoked','authorization_revision'=>1,'credential_generation'=>1,'observed_at'=>time(),'auth_scope'=>'connection']);
F3Base_Incidentes_Provedores::meta();
[$atual,$mesmaRef] = $registro('schedule_overdue',$agenda);
$verificar('pull_revogacao_promove_mesma_abertura', $atual['episodio'] === $r['episodio'] && $atual['codigo_carencia'] === 'concessao_revogada' && $ref === $mesmaRef && $contar($ref) === 1);
Worker::notify();
F3Base_Incidentes_Provedores::meta();
$verificar('observacoes_repetidas_sem_duplicar', $contar($ref) === 1);
Store::put('connection',$outra,$conta($outra,time()-60));
Worker::notify();
[$exp,$refExp] = $registro('connection_authorization_failed',$outra);
$verificar('push_credencial_vencida_imediata', $exp['codigo_carencia'] === 'credencial_recusada' && $contar($refExp) === 1);
$verificar('classificacao_sem_http', $rede === 0);
echo wp_json_encode(['wordpress'=>get_bloginfo('version'),'core'=>F3BASE_PLUGIN_VERSAO,'meta'=>\Fator3\Meta\Config::VERSION,'verificacoes'=>$provas,'http'=>$rede],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
