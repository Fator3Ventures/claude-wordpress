set -euo pipefail
wpcli eval "require '$PWD/S/tests/199/base-439.php';" >"$PWD/S/evidence/1990/provas-439-base.json"
