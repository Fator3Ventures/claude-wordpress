<?php
/** Contrato Core/Google com o armazenamento e o publicador reais em WordPress descartável. */
use Fator3\McpGoogle\Automation\AccessIncidents;
use Fator3\McpGoogle\Automation\Alerts;
use Fator3\McpGoogle\Connections;
use Fator3\McpGoogle\Records;
use Fator3\McpGoogle\TechnicalNotices;

if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_199_google'
    || wp_parse_url(home_url(),PHP_URL_HOST) !== '127.0.0.1') {
    throw new RuntimeException('Execute somente na base descartável core_199_google, em loopback.');
}
wp_set_current_user(1);
Connections::select('default');
$fase = getenv('F3_CORE_GOOGLE_FASE');
$caminho = getenv('F3_CORE_GOOGLE_RESULTADO');
if (!$caminho) {
    throw new RuntimeException('Informe o arquivo JSON de resultado.');
}
$codigo = 'integracao_indisponivel';
$prefixo = getenv('F3_CORE_GOOGLE_PREFIXO') ?: 'core199-google';
$id = static fn(string $nome) => hash('sha256', $prefixo.'-'.$nome);
$perfis = [];
$verificar = static function(bool $ok, string $nome) use (&$perfis) {
    if (!$ok) {
        throw new RuntimeException($nome);
    }
    $perfis[] = $nome;
};
$assuntos = [];
$incerto = false;
add_filter('pre_wp_mail', static function($pre, $args) use (&$assuntos, &$incerto) {
    $assuntos[] = $args['subject'];
    if ($incerto) {
        throw new RuntimeException('Transporte local interrompido após reserva.');
    }
    return true;
}, 1, 2);
add_filter('pre_http_request',static fn() => new WP_Error('offline','Ensaio sem saída para o fornecedor.'),PHP_INT_MIN);
$destino = static function(string $email) {
    $config = (array)get_option('f3base_avisos_tecnicos', []);
    $config['email'] = $email;
    update_option('f3base_avisos_tecnicos',$config);
};
$destino('ensaio@example.invalid');

$chave = static function(string $recurso) use ($codigo) {
    $opaco = hash_hmac('sha256', 'default/'.$recurso, wp_salt('auth'));
    return 'f3base_incidente_v1_'.hash('sha256','google|'.$codigo.'|'.$opaco);
};
$estado = static fn(string $recurso) => (array)get_option($chave($recurso),[]);
$aviso = static fn(string $recurso) => Records::get('technicalnotice', hash('sha256','default|'.$codigo.'|'.$recurso));
$abrir = static fn(string $recurso, int $geracao) => TechnicalNotices::publish($codigo, $recurso, true, ['access_generation'=>$geracao]);
$fechar = static fn(string $recurso, int $geracao, string $motivo) => TechnicalNotices::publish($codigo, $recurso, false, ['access_generation'=>$geracao,'access_closure'=>$motivo]);
$evento = static fn(string $recurso, int $geracao, string $situacao) => [
    'pacote'=>'google','codigo'=>$codigo,'recurso'=>'default/'.$recurso,'geracao_acesso'=>$geracao,'estado'=>$situacao
];
$projetar = static function(string $recurso, int $geracao, string $status) {
    $linha = [
        'id'=>$recurso,'connection_id'=>'default','event'=>'access','resource'=>'ensaio-local','status'=>$status,
        'created_at'=>time()-90000,'updated_at'=>time(),'generation'=>$geracao,'context'=>[]
    ];
    if (in_array($status,['nao_usado','consolidado'],true)) {
        $linha['resolution_reason'] = $status;
        $linha['notify_recovery'] = false;
    }
    if (empty(Records::put('incident', $recurso, $linha)['success'])) {
        throw new RuntimeException('Falha ao gravar o incidente de ensaio no produtor.');
    }
};
$url = 'https://analyticsadmin.googleapis.com/v1beta/accounts/'.sprintf('%u',crc32($prefixo)).'/accessBindings';
$legado = hash('sha256', 'default|access|'.$url);
if ($fase === 'historico') {
    $verificar(F3_MCP_GOOGLE_VERSION === '0.40.0' && F3BASE_PLUGIN_VERSAO === '1.98.0','Base de origem em 0.40.0 e 1.98.0');
    Alerts::observe('access',$url,true,'http_403','Diagnóstico de acesso');
    $registro = Records::get('incident',$legado);
    $verificar(($registro['status'] ?? '') === 'open','Diagnóstico antigo criado pelo Google');
    $registro['updated_at'] = $registro['created_at'] = time()-90000;
    Records::put('incident',$legado,$registro);
    F3Base_Incidentes_Provedores::google();
    $verificar($estado($legado)['estado'] === 'aberto' && count($assuntos) === 1,'Abertura antiga gravada com o mesmo recurso');
} elseif ($fase === 'anterior') {
    $verificar(F3_MCP_GOOGLE_VERSION === '0.41.0' && F3BASE_PLUGIN_VERSAO === '1.98.0','Google vigente com a base Core 1.98');
    $verificar(!has_filter('f3base_incidente_acesso_encerrar_v1'),'Core anterior sem consumidor de encerramento administrativo');
    AccessIncidents::tick();
    $verificar(Records::get('incident',$legado)['status'] === 'nao_usado' && $aviso($legado)['status'] === 'awaiting_access_core','Manutenção encerrou o diagnóstico com 25 horas e guardou a operação');
    $push = $id('push'); $abrir($push,1);
    $fechar($push,2,'nao_usado');
    $verificar($estado($push)['estado'] === 'aberto' && $aviso($push)['status'] === 'awaiting_access_core','Emissor mantém fechamento aguardando a atualização do Core');
    $pull = $id('pull');
    $projetar($pull,1,'open');
    F3Base_Incidentes_Provedores::google();
    $projetar($pull,2,'consolidado');
    $verificar($estado($pull)['estado'] === 'aberto' && !$aviso($pull),'Registro originado exclusivamente do coletor');
    $incerto = true;
    $reserva = $id('reserva');
    $abrir($reserva,1);
    $incerto = false;
    $verificar(!empty($estado($reserva)['fila'][0]['reserva']),'Transporte interrompido deixou uma reserva histórica');
    $fechar($reserva,2,'consolidado');
    $destino('');
    $pendente = $id('abertura-pendente');
    $abrir($pendente,1);
    $verificar(($estado($pendente)['fila'][0]['entrega'] ?? '') === 'pendente','Abertura antiga sem destino');
    $fechar($pendente,2,'nao_usado');
    $destino('ensaio@example.invalid');
} elseif ($fase === 'atual') {
    $verificar(F3_MCP_GOOGLE_VERSION === '0.41.0' && version_compare(F3BASE_PLUGIN_VERSAO,'1.99.0','>='),'Google e Core vigentes em execução');
    $verificar((bool)has_filter('f3base_incidente_acesso_encerrar_v1'),'Consumidor registrado pelo bootstrap normal');
    TechnicalNotices::dispatch();
    F3Base_Incidentes_Provedores::google();
    TechnicalNotices::dispatch();
    F3Base_Incidentes_Provedores::google();
    foreach ([$legado=>'nao_usado', $id('push')=>'nao_usado', $id('pull')=>'consolidado', $id('abertura-pendente')=>'nao_usado'] as $recurso=>$motivo) {
        $r = $estado($recurso);
        $verificar(($r['estado'] ?? '') === 'recuperado' && $r['motivo_encerramento'] === $motivo && $r['acao_humana'] === false && empty($r['fila']), 'Encerramento na mesma referência com motivo '.$motivo.' ('.substr($recurso,0,8).')');
        if ($recurso !== $id('pull')) {
            $verificar($aviso($recurso)['status'] === 'accepted' && empty($aviso($recurso)['queue']),'Produtor confirmou a persistência ('.substr($recurso,0,8).')');
        }
    }
    $reserva = $id('reserva');
    $registro = $estado($reserva);
    $token = $registro['fila'][0]['reserva'] ?? '';
    $verificar($registro['estado'] === 'recuperado' && $token !== '' && !empty($registro['fila'][0]['dispensar_retentativa']),'Encerramento silencioso preservou reserva incerta');
    $reconciliacao = F3Base_Incidentes::reconciliar(['id'=>substr($chave($reserva),-64), 'reserva'=>$token,'resultado'=>'nao_enviado']);
    $verificar(!empty($reconciliacao['ok']) && empty($estado($reserva)['fila']),'Conciliação de aviso dispensado encerrou a reserva');
    $verificar(count($assuntos) === 0,'Acertos históricos e reprocessamento sem novo e-mail');
    $atrasado = F3Base_Incidentes::publicar($evento($id('push'),1,'aberto'));
    $verificar(($atrasado['estado'] ?? '') === 'observacao_superada' && count($assuntos) === 0,'Entrega antiga não reabre referência encerrada');
    $abrir($id('push'),3);
    $verificar($estado($id('push'))['estado'] === 'aberto','Falha de geração superior abre novo episódio');
    $incidente_ordinario = $id('ordinario');
    $projetar($incidente_ordinario,1,'open');
    F3Base_Incidentes_Provedores::google();
    $r = $estado($incidente_ordinario);
    $verificar($r['estado'] === 'aberto' && count($assuntos) === 0,'PULL reconhece falha e aguarda 30 minutos de observação');
    // Avança somente o relógio persistido do episódio e de sua abertura no banco descartável.
    $r['observado_em'] = $r['fila'][0]['observado_em'] = time() - 31 * MINUTE_IN_SECONDS;
    update_option($chave($incidente_ordinario), $r, false);
    F3Base_Incidentes_Provedores::google();
    $verificar(count($assuntos) === 1 && array_column($estado($incidente_ordinario)['fases_enviadas'],'fase') === ['aberto'],'Após a carência uma abertura comprovada foi aceita');
    $projetar($incidente_ordinario,2,'resolved');
    F3Base_Incidentes_Provedores::google();
    $verificar($estado($incidente_ordinario)['estado'] === 'recuperado' && !isset($estado($incidente_ordinario)['motivo_encerramento']),'Recuperação comprovada utiliza o caminho ordinário');
    $verificar(count($assuntos) === 2 && array_column($estado($incidente_ordinario)['fases_enviadas'],'fase') === ['aberto','recuperado'],'Recuperação genuína foi aceita após a abertura');
    $fora_de_ordem = $id('resolucao-antes-da-abertura');
    F3Base_Incidentes::publicar($evento($fora_de_ordem,4,'recuperado'));
    $tardia = F3Base_Incidentes::publicar($evento($fora_de_ordem,3,'aberto'));
    $verificar(($tardia['estado'] ?? '') === 'observacao_superada','Recuperação ordinária de geração 4 precede observação atrasada de geração 3');
    $invalido = apply_filters('f3base_incidente_acesso_encerrar_v1',null,[
        'pacote'=>'google','codigo'=>'autorizacao_recusada','recurso'=>'default/service-account-key-metadata',
        'estado'=>'recuperado','acao_humana'=>false,'motivo_encerramento'=>'nao_usado','geracao_acesso'=>2,
    ]);
    $verificar(is_array($invalido) && ($invalido['ok'] ?? true) === false,'IAM recusado no canal silencioso');
} else {
    throw new RuntimeException('Fase de teste desconhecida');
}
file_put_contents($caminho,wp_json_encode(['fase'=>$fase,'google'=>F3_MCP_GOOGLE_VERSION,
    'core'=>F3BASE_PLUGIN_VERSAO,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'verificacoes'=>$perfis,
    'total'=>count($perfis),'tentativas_de_email_interceptadas'=>count($assuntos)],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n");
echo count($perfis)." verificações aprovadas\n";
