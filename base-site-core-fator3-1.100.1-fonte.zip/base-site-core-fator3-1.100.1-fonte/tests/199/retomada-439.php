<?php
if (wp_get_environment_type()!=='local'||DB_NAME!=='core_199_provas'||!current_user_can('manage_options')) {
    throw new RuntimeException('Banco isolado de provas necessário.');
}
$para='qa-core-439@example.invalid';
$cfg=F3Base_Options::ler('f3base_avisos_tecnicos');
$cfg['email']=$para; $cfg['resumo_diario']=false;
add_filter('pre_option_f3base_avisos_tecnicos',static fn()=>$cfg,PHP_INT_MAX);
$recurso='qa439-rechecagem-automatica-local';
$ref=hash_hmac('sha256',$recurso,wp_salt('auth'));
$key='f3base_incidente_v1_'.hash('sha256','canal|agenda_parada|'.$ref);
if (get_option($key,null)!==null) throw new RuntimeException('Registro de ensaio pré-existente');
$count=0;
add_filter('pre_wp_mail',static function($pre,$mail)use($ref,&$count){
    if (str_contains($mail['message'],$ref)) {++$count;return true;} return $pre;
},PHP_INT_MIN,2);
try {
    apply_filters('f3base_incidente_publicar_v1',null,['pacote'=>'canal','codigo'=>'agenda_parada','recurso'=>$recurso,'estado'=>'aberto']);
    if ($count) throw new RuntimeException('Abertura antecipada');
    $r=get_option($key);
    foreach (['desde','observado_em','alterado_em'] as $k) $r[$k]=time()-1860;
    foreach (['desde','observado_em','em'] as $k) $r['fila'][0][$k]=time()-1860;
    update_option($key,$r,false);
    delete_transient('f3base_incidentes_revisados');
    F3Base_Incidentes::observar();
    $r=get_option($key);
    if ($count!==1 || array_column($r['fases_enviadas']??[],'fase')!==['aberto']) throw new RuntimeException('Observador não retomou a abertura');
    delete_transient('f3base_incidentes_revisados');
    F3Base_Incidentes::observar();
    if ($count!==1) throw new RuntimeException('Observador repetiu a entrega');
    echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'passagens_observador'=>2,'aberturas_sem_republicar'=>1,'duplicatas'=>0],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
} finally { delete_option($key); }
