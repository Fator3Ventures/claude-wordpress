set -euo pipefail
pacote="$PWD/out/base-site-core-fator3-1.99.0-instalador.zip"
wpcli plugin install "$pacote" --force --activate
wpcli eval 'F3Base_Zelador::atualizacao_urgente();$r=F3Base_Instalacao::resumo();if($r["estado"]!=="concluida"||$r["falhas"])throw new RuntimeException("Ciclo incompleto");'
wpcli eval "require '$PWD/S/tests/199/provas-439.php';" > "$PWD/S/evidence/1990/provas-439-local.json"
wpcli eval "require '$PWD/S/tests/199/retomada-439.php';" > "$PWD/S/evidence/1990/retomada-439-local.json"
python3 - "$pacote" <<'PY'
import hashlib, json, pathlib, sys
root=pathlib.Path('S/evidence/1990')
suite=json.loads((root/'provas-439-local.json').read_text())
retomada=json.loads((root/'retomada-439-local.json').read_text())
assert suite['ok'] and suite['registros_proprios_restantes']==0 and len(suite['casos'])==8
assert retomada['aberturas_sem_republicar']==1 and retomada['duplicatas']==0
v={'instalador': pathlib.Path(sys.argv[1]).name, 'sha256':hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest(),'casos':len(suite['casos']),'retomada_observador':True}
(root/'provas-439-instalador.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(v))
PY
