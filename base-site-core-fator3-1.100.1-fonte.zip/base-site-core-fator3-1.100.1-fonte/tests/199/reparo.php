<?php
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_199_integrado') {
    throw new RuntimeException('Use a instalação integrada descartável.');
}
final class Core199TabelaEnsaio {
    public const ESQUEMA_VERSAO = 1;
    public static function montar() {
        global $wpdb;
        $t = $wpdb->prefix.'f3base_qa199_reparo';
        return F3Base_Esquema::instalar(__CLASS__, __FUNCTION__, static fn() => $wpdb->query(
            $wpdb->prepare('CREATE TABLE IF NOT EXISTS %i (id BIGINT PRIMARY KEY)', $t)
        ));
    }
}
global $wpdb;
$t = $wpdb->prefix.'f3base_qa199_reparo';
$avisos = [];
add_filter('pre_wp_mail', static function ($pre, $envio) use (&$avisos) {
    if (str_contains($envio['subject'], 'estrutura_ausente') || str_contains($envio['subject'], 'Estrutura do Site Core')) {
        $avisos[] = $envio['subject'];
    }
    return true;
}, 1, 2);
$estado = (array)get_option(F3Base_Esquema::OPTION, []);
$estado['_donos'][$t] = [Core199TabelaEnsaio::class, 'montar'];
update_option(F3Base_Esquema::OPTION, $estado);
$oculto = $wpdb->suppress_errors();
try {
    if ($wpdb->query($wpdb->prepare('INSERT INTO %i (id) VALUES (1)', $t)) !== false) { throw new RuntimeException('Fixture já existente.'); }
    F3Base_Esquema::observar();
    F3Base_Esquema::registrar_falhas();
    $reparo = F3Base_Esquema::reparar();
    $ref = hash_hmac('sha256', $t, wp_salt('auth'));
    $k = 'f3base_incidente_v1_'.hash('sha256','core|estrutura_ausente|'.$ref);
    $r = get_option($k);
    if (!in_array($t,$reparo['reparadas'],true) || !$r['suprimido_por_carencia'] || $r['estado'] !== 'recuperado' || $avisos) {
        throw new RuntimeException(wp_json_encode(['reparo'=>$reparo,'registro'=>$r,'avisos'=>$avisos]));
    }
    echo wp_json_encode(['reparo'=>'concluido','estado'=>$r['estado'],'suprimido_por_carencia'=>true,'emails'=>count($avisos)]);
} finally {
    $wpdb->suppress_errors($oculto);
    $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i',$t));
    if (isset($k)) { delete_option($k); }
}
