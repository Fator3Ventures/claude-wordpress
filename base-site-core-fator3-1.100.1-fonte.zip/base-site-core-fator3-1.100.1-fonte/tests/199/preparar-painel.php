<?php
if (DB_NAME!=='core_199_painel' || wp_get_environment_type()!=='local') { throw new RuntimeException('Laboratório de painel obrigatório'); }
$cfg = F3Base_Options::ler('f3base_avisos_tecnicos');
$cfg['email'] = 'ensaio@example.invalid';
$cfg['carencia_por_codigo_minutos']['agenda_parada'] = 30;
$cfg['janela_agrupamento_horas'] = 24;
$gravado = F3Base_Options::gravar('f3base_avisos_tecnicos',$cfg,F3Base_Options::ORIGEM_PADRAO,F3Base_Options::revisao('f3base_avisos_tecnicos'));
if (empty($gravado['persisted'])) { throw new RuntimeException('Preparação da configuração recusada'); }
$ate = time()+1800;
$token = WP_Session_Tokens::get_instance(1)->create($ate);
$dados = [
 'url'=>admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=f3base_avisos_tecnicos'),
 'cookies'=>[AUTH_COOKIE=>wp_generate_auth_cookie(1,$ate,'auth',$token),LOGGED_IN_COOKIE=>wp_generate_auth_cookie(1,$ate,'logged_in',$token)],
];
echo wp_json_encode($dados);
