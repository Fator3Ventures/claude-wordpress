<?php
if (wp_get_environment_type()!=='local'||DB_NAME!=='core_199_provas'||!current_user_can('manage_options')) {
    throw new RuntimeException('Use a instalação descartável de provas.');
}
require_once dirname(__FILE__).'/qa-core-439/qa-core-439.php';
$r = F3QA439_Cenarios::executar();
echo wp_json_encode($r, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
if (!$r['ok'] || $r['registros_proprios_restantes']!==0) { exit(1); }
