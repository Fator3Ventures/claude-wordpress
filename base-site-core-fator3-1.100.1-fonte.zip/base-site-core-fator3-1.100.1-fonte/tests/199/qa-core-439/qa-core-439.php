<?php
/**
 * Plugin Name: Ensaio temporário do pedido Core 439
 * Version: 1.0.0
 * Description: Executa cenários fechados de incidentes somente no Site-Teste ou no banco descartável do ensaio.
 */
declare(strict_types=1);
defined('ABSPATH') || exit;
$qa439_local = wp_get_environment_type() === 'local' && defined('DB_NAME') && DB_NAME === 'core_199_provas';
$qa439_host = wp_parse_url(home_url(), PHP_URL_HOST);
if (!$qa439_local && $qa439_host !== 'fator3-teste-mcp-1.dreamhosters.com') { return; }
require_once __DIR__ . '/cenarios.php';

// Uma referência de ensaio que sobreviva a uma interrupção continua protegida em outros processos.
add_filter('pre_wp_mail', [F3QA439_Cenarios::class,'interceptar'], PHP_INT_MIN, 2);
// Em laboratório, o bloqueio global de rede aceita por padrão. Preserve a recusa do cenário de falha.
add_filter('pre_wp_mail', static function ($pre, $args) {
    $ref = hash_hmac('sha256', 'ensaio-core-439-20261120-falha', wp_salt('auth'));
    return str_contains((string)($args['message'] ?? ''), $ref) ? false : $pre;
}, PHP_INT_MAX, 2);
function f3qa439_comando($valor): void {
    if (!in_array($valor,['executar-439','limpar-439'],true) || !current_user_can('manage_options') || !defined('F3BASE_PLUGIN_VERSAO')
        || version_compare(F3BASE_PLUGIN_VERSAO,'1.99.0','<') || !F3Base_Pipedrive_Fila::travar_linha('qa-core-439-suite')) {
        return;
    }
    try {
        $resultado = $valor === 'limpar-439'
            ? ['limpeza'=>true,'registros_proprios_restantes'=>F3QA439_Cenarios::limpar_leitura()]
            : F3QA439_Cenarios::executar(true);
        update_option('f3qa439_resultado', $resultado, false);
    } finally {
        F3Base_Pipedrive_Fila::liberar_linha('qa-core-439-suite');
    }
}
add_action('add_option_f3qa439_comando', static function ($nome,$valor) { f3qa439_comando($valor); },10,2);
add_action('update_option_f3qa439_comando', static function ($antes,$valor) { f3qa439_comando($valor); },10,2);

register_deactivation_hook(__FILE__,[F3QA439_Cenarios::class,'limpar_leitura']);
