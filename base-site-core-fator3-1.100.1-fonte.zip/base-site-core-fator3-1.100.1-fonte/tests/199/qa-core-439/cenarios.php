<?php
declare(strict_types=1);
defined('ABSPATH') || exit;

final class F3QA439_Cenarios {
    private const CASOS = ['breve','duradoura','imediata','falha','agrupada','curtas','legado','incerta'];
    private const DESTINO = 'qa-core-439@example.invalid';
    private static array $refs = [];
    private static array $mensagens = [];
    private static array $resultados = [];
    private static bool $executando = false;

    private static function recurso(string $caso): string { return 'ensaio-core-439-20261120-'.$caso; }
    private static function codigo(string $caso): string {
        return in_array($caso,['imediata','falha','incerta'],true) ? 'credencial_invalida' : 'agenda_parada';
    }
    private static function ref(string $caso): string {
        return self::$refs[$caso] ??= hash_hmac('sha256',self::recurso($caso),wp_salt('auth'));
    }
    private static function id(string $caso): string {
        return hash('sha256','canal|'.self::codigo($caso).'|'.self::ref($caso));
    }
    private static function key(string $caso): string { return 'f3base_incidente_v1_'.self::id($caso); }
    private static function exigir(bool $ok,string $mensagem): void {
        if (!$ok) { throw new RuntimeException($mensagem); }
    }
    public static function interceptar($pre,array $args) {
        $texto = (string)($args['message']??'');
        foreach (self::CASOS as $caso) {
            if (!str_contains($texto,self::ref($caso))) { continue; }
            $aceita = $caso !== 'falha';
            // Fora da execução, silencia somente as referências fixas deste plugin.
            if (self::$executando) {
                self::$mensagens[$caso][] = ['assunto'=>(string)($args['subject']??''),
                    'aceita'=>$aceita && $caso !== 'incerta',
                    'contagem_no_corpo'=>preg_match('/(?:epis[oó]dios|reincid[eê]ncias|repeti[çc][õo]es|ocorr[eê]ncias|contagem)[^\n]{0,100}\b2\b|\b2 (?:epis[oó]dios|reincid[eê]ncias|repeti[çc][õo]es|ocorr[eê]ncias)/iu',$texto) === 1];
                if ($caso === 'incerta') { throw new RuntimeException('Incerteza sintética no transporte.'); }
            }
            return $aceita;
        }
        // Segunda barreira no processo de teste, inclusive se o formato da mensagem mudar.
        if (self::$executando && in_array(self::DESTINO,(array)($args['to']??[]),true)) {
            throw new RuntimeException('Mensagem de ensaio sem referência reconhecida.');
        }
        return $pre;
    }
    private static function publicar(string $caso,string $estado): array {
        $r = apply_filters('f3base_incidente_publicar_v1',null,['pacote'=>'canal','codigo'=>self::codigo($caso),
            'recurso'=>self::recurso($caso),'estado'=>$estado,'acao_humana'=>true]);
        self::exigir(is_array($r),'Ausência de consumidor PHP.');
        return $r;
    }
    private static function listar(string $caso): array {
        $id = self::id($caso);
        $cursor = '';
        do {
            $pagina = F3Base_Incidentes::listar(['apos'=>$cursor]);
            self::exigir(!empty($pagina['ok']),'Leitura de incidentes indisponível.');
            foreach ($pagina['itens'] as $item) { if ($item['id'] === $id) { return $item; } }
            $proximo = $pagina['proximo'] ?? '';
            self::exigir($proximo === '' || strcmp($proximo,$cursor)>0,'Cursor de incidentes repetido.');
            $cursor = $proximo;
        } while ($cursor !== '');
        throw new RuntimeException('Referência de ensaio ausente na consulta.');
    }
    private static function gravar(string $caso,array $registro): void {
        $key = self::key($caso);
        update_option($key,$registro,false);
        self::exigir(get_option($key) === $registro,'Falha ao preparar dado sintético.');
    }
    private static function envelhecer(string $caso,int $segundos): void {
        $registro = get_option(self::key($caso),[]);
        self::exigir(($registro['estado']??'') === 'aberto','Referência a envelhecer deve estar aberta.');
        foreach (['desde','observado_em'] as $k) { $registro[$k] = time()-$segundos; }
        foreach ($registro['fila'] as &$item) {
            if ($item['estado'] === 'aberto' && $item['entrega'] === 'pendente') {
                foreach (['desde','em','observado_em'] as $k) { $item[$k] = time()-$segundos; }
            }
        }
        unset($item);
        self::gravar($caso,$registro);
    }
    private static function fases(array $v): array { return array_column($v['fases_enviadas']??[],'fase'); }
    private static function correio(string $caso): array { return self::$mensagens[$caso]??[]; }
    private static function concluir(string $caso,array $v): void {
        self::$resultados[$caso] = [
            'estado'=>$v['estado'],'suprimido_por_carencia'=>$v['suprimido_por_carencia']??false,
            'duracao_segundos'=>$v['duracao_segundos']??null,'fases'=>self::fases($v),
            'contagens'=>array_column($v['fases_enviadas']??[],'contagem'),
            'tentativas_wp_mail'=>count(self::correio($caso)),
            'aceitas_no_interceptor'=>count(array_filter(self::correio($caso),static fn($m)=>$m['aceita'])),
        ];
    }
    private static function breve(): void {
        $nome='breve';
        self::publicar($nome,'aberto');
        self::exigir(!self::correio($nome),'Aviso durante a carência.');
        self::envelhecer($nome,125);
        self::publicar($nome,'recuperado');
        $r=self::listar($nome);
        self::exigir(!self::correio($nome) && !self::fases($r) && ($r['suprimido_por_carencia']??false) === true
            && $r['duracao_segundos']>=125 && $r['duracao_segundos']<1800,'Episódio breve incorreto.');
        self::concluir($nome,$r);
    }
    private static function duradoura(): void {
        $nome='duradoura';
        self::publicar($nome,'aberto');
        self::envelhecer($nome,1790);
        self::publicar($nome,'aberto');
        self::exigir(!self::correio($nome),'Abertura antes do fim da carência.');
        self::envelhecer($nome,1860);
        self::publicar($nome,'aberto');
        self::publicar($nome,'aberto');
        self::exigir(count(self::correio($nome))===1,'Persistência deve emitir uma só abertura.');
        self::publicar($nome,'recuperado');
        self::publicar($nome,'recuperado');
        $r=self::listar($nome);
        self::exigir(count(self::correio($nome))===2 && self::fases($r)===['aberto','recuperado'],'Par do episódio persistente incorreto.');
        self::concluir($nome,$r);
    }
    private static function imediata(): void {
        $nome='imediata';
        self::publicar($nome,'aberto');
        self::exigir(count(self::correio($nome))===1 && self::fases(self::listar($nome))===['aberto'],'A credencial não avisou na primeira passagem.');
        self::publicar($nome,'recuperado');
        $r=self::listar($nome);
        self::exigir(self::fases($r)===['aberto','recuperado'],'Recuperação da credencial ausente.');
        self::concluir($nome,$r);
    }
    private static function falha(): void {
        $nome='falha';
        self::publicar($nome,'aberto'); self::publicar($nome,'recuperado');
        $r=self::listar($nome);
        self::exigir(count(self::correio($nome))===1 && !self::fases($r) && !$r['entregas_pendentes'],'Entrega recusada gerou recuperação ou fila obsoleta.');
        self::concluir($nome,$r);
    }
    private static function agrupada(): void {
        $nome='agrupada';
        for ($i=0;$i<3;$i++) {
            self::publicar($nome,'aberto');
            self::envelhecer($nome,1860);
            // A segunda ocorrência se encerra antes da próxima passagem do observador.
            if ($i !== 1) { self::publicar($nome,'aberto'); }
            self::publicar($nome,'recuperado');
        }
        self::exigir(count(self::correio($nome))===2,'Reincidências enviaram pares individuais.');
        $r=get_option(self::key($nome)); $r['agrupamento']['ate']=time()-1;
        self::gravar($nome,$r); self::publicar($nome,'recuperado'); self::publicar($nome,'recuperado');
        $r=self::listar($nome); $fases=self::fases($r); $f=$r['fases_enviadas']??[];
        self::exigir($fases===['aberto','recuperado','agrupado'] && end($f)['contagem']===2 && count(self::correio($nome))===3,'Resumo de reincidências incorreto.');
        self::exigir(self::correio($nome)[2]['contagem_no_corpo'],'Resumo sem contagem no corpo entregue ao transporte.');
        self::concluir($nome,$r);
    }
    private static function curtas(): void {
        $nome='curtas';
        for ($i=0;$i<3;$i++) { self::publicar($nome,'aberto'); self::publicar($nome,'recuperado'); }
        $r=self::listar($nome);
        self::exigir(!self::correio($nome) && !self::fases($r) && !$r['entregas_pendentes'],'Reincidência de episódios breves gerou aviso.');
        self::concluir($nome,$r);
    }
    private static function legado(): void {
        $nome='legado'; $agora=time();
        $r=['pacote'=>'canal','codigo'=>self::codigo($nome),'recurso_ref'=>self::ref($nome),
            'rota'=>F3Base_Incidentes::ROTAS['canal'],'desde'=>$agora-7200,'alterado_em'=>$agora-3600,
            'estado'=>'aberto','acao_humana'=>true,'vence_em'=>null,'fila'=>[],
            'ultimo_envio'=>['fase'=>'aberto','codigo'=>'aceito_wp_mail','em'=>$agora-3600]];
        self::gravar($nome,$r); self::publicar($nome,'recuperado');
        $r=self::listar($nome);
        self::exigir(count(self::correio($nome))===1 && self::fases($r)===['aberto','recuperado'],'Abertura aceita pela 1.98.0 perdeu o recibo ou duplicou a abertura.');
        self::concluir($nome,$r);
    }
    private static function incerta(): void {
        $nome='incerta';
        self::publicar($nome,'aberto');
        $r=self::listar($nome);
        self::exigir(!empty($r['reserva']),'Reserva incerta não disponível.');
        self::publicar($nome,'recuperado');
        self::exigir(count(self::correio($nome))===1,'Recuperação antes da reconciliação.');
        $recon=F3Base_Incidentes::reconciliar(['id'=>$r['id'],'reserva'=>$r['reserva'],'resultado'=>'nao_enviado']);
        self::exigir(!empty($recon['ok']),'Reconciliação da reserva recusada.');
        self::publicar($nome,'recuperado'); $r=self::listar($nome);
        self::exigir(!self::fases($r) && count(self::correio($nome))===1 && !$r['entregas_pendentes'],'Reconciliação negativa deixou reenvio.');
        self::concluir($nome,$r);
    }
    public static function limpar_leitura(): int {
        $proprios = get_option('f3qa439_leitura',[]);
        $restantes=0;
        foreach (['breve','duradoura','imediata'] as $caso) {
            $id=$proprios[$caso]??null;
            if ($id !== self::id($caso)) { continue; }
            $key=self::key($caso); $item=get_option($key,[]);
            if (($item['recurso_ref']??null) === self::ref($caso)) { delete_option($key); }
            if (get_option($key,null)!==null) { ++$restantes; }
        }
        if (!$restantes) { delete_option('f3qa439_leitura'); }
        return $restantes;
    }
    public static function executar(bool $manter_para_leitura=false): array {
        if (!current_user_can('manage_options')) { return ['ok'=>false,'motivo'=>'sem_permissao']; }
        $caso='preparo'; $criadas=[]; $manter=[]; $bloquear = static fn() => new WP_Error('qa439_sem_http');
        $cfg=F3Base_Options::ler('f3base_avisos_tecnicos');
        $cfg['email']=self::DESTINO;
        $config=static fn()=>$cfg;
        self::$resultados=[]; self::$mensagens=[]; self::$executando=true;
        try {
            // Sobrescreve apenas o destinatário no processo que executa o ensaio.
            add_filter('pre_option_f3base_avisos_tecnicos',$config,PHP_INT_MAX);
            self::exigir(F3Base_Alertas_Operacionais::destinatario()===self::DESTINO,'Destino de ensaio indisponível.');
            add_filter('pre_http_request',$bloquear,PHP_INT_MAX);
            foreach (self::CASOS as $caso) {
                if (get_option(self::key($caso),null)!==null) {
                    throw new RuntimeException('Referência de ensaio pré-existente; preservada.');
                }
                $criadas[]=$caso;
                self::$caso();
            }
            $r=['ok'=>true,'core'=>F3BASE_PLUGIN_VERSAO,'casos'=>self::$resultados];
            if ($manter_para_leitura) {
                foreach (['breve','duradoura','imediata'] as $referencia) { $manter[$referencia]=self::id($referencia); }
                if (!add_option('f3qa439_leitura',$manter,'',false)) {
                    $manter=[];
                    throw new RuntimeException('Não foi possível reservar as referências para leitura.');
                }
                $r['amostra_para_leitura']=$manter;
            }
        } catch(Throwable $erro) {
            $r=['ok'=>false,'core'=>F3BASE_PLUGIN_VERSAO,'caso'=>$caso,'erro'=>substr($erro->getMessage(),0,300),
                'casos_aprovados'=>self::$resultados,'tentativas_no_caso'=>count(self::correio($caso))];
        } finally {
            foreach ($criadas as $caso) { if (!isset($manter[$caso])) { delete_option(self::key($caso)); } }
            remove_filter('pre_option_f3base_avisos_tecnicos',$config,PHP_INT_MAX);
            remove_filter('pre_http_request',$bloquear,PHP_INT_MAX);
            self::$executando=false;
        }
        $r['registros_proprios_restantes']=count(array_filter($criadas,static fn($nome)=>get_option(self::key($nome),null)!==null));
        return $r;
    }
}
