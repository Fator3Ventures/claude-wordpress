<?php
/** Sonda somente de leitura. Copiar temporariamente em mu-plugins do WordPress descartável. */
if (!defined('ABSPATH') || wp_get_environment_type() !== 'local' || DB_NAME !== 'core_199_google'
    || ($_SERVER['REMOTE_ADDR'] ?? '') !== '127.0.0.1' || ($_GET['f3_teste_google_bootstrap'] ?? '') !== '1') return;

add_action('init', static function () {
    wp_send_json([
        'core' => F3BASE_PLUGIN_VERSAO,
        'google' => F3_MCP_GOOGLE_VERSION,
        'perfil_publico' => F3Base_Perfil_Publico::ativo(),
        'publicacao' => (bool) has_filter('f3base_incidente_publicar_v1'),
        'encerramento' => (bool) has_filter('f3base_incidente_acesso_encerrar_v1'),
    ]);
}, -900);
