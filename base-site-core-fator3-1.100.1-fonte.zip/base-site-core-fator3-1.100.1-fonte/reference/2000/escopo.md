# Rodada de 20/11/2026

O pedido visual reúne os vinte ajustes da aba do Core e as doze conferências da seção 7 do guia comum. O anexo não atribui um novo número a esse trabalho. A linha de base efetivamente usada foi o fonte oficial 1.99.0, SHA-256 `9ab280444550f8c785b5f3c0cc69bb451b460e6a2da58cda569fbc91c0b2cc33`. A documentação de levantamento descreve 1.98.0. O trabalho começou sobre os comportamentos da 1.99.0, incluindo o editor de carência de avisos técnicos.

O retorno do MCP 0.54.0 encerra sua parte no pedido Core 439 / MCP 91. O relatório Google 0.42.0 confirma o encerramento do desenvolvimento do pedido Google 59 e acrescenta o avanço paginado do produtor. O Core recebe ambos pelos contratos existentes. O acompanhamento de campo do pedido 439 e a validação dos episódios históricos do Google continuam com a frota.

A comparação entre a folha compartilhada 1.0.0 e a medição em Chromium identificou um ponto para Site Geral | Todos. O documento pede 40 px para campos no breakpoint móvel. A folha entrega esse mínimo aos botões, mas mantém em 36 px a regra de campo. O Core usa localmente o token compartilhado de altura no controle editável e mantém os bytes da folha canônica. Uma futura revisão comum pode aplicar o mínimo às entradas editáveis e de busca em todos os pacotes. As medidas finais da versão estão na prova visual.
