# Fator3 Site Core — ajustes de tela

O Fator3 Site Core 1.98.0 é o pacote com mais diferenças internas: seis folhas de administração, três famílias de classes e uma tela que abre sem a folha das outras. A entrega troca as seis pela folha comum e uma folha própria, põe o mesmo cabeçalho e os mesmos grupos em todas as telas e tira os campos de `form-table`. Slugs, capacidades, rotas e options não mudam.

## Navegação

Os cinco grupos aparecem iguais em todas as telas, nesta ordem; o grupo ativo é a página de menu aberta, e cada grupo só aparece para quem tem a capacidade da página.

| grupo | página | subabas | o que hoje é terceiro nível |
| --- | --- | --- | --- |
| Configurações | `base-site-core-fator3` | os dois conjuntos com rótulo de hoje: Visão geral · Conexões e entregas · Contato · Medição e anúncios, e Conteúdo e IA · SEO · Consentimento · Privacidade e segurança | os sete itens de Conexões e entregas (Pipedrive, E-mail do site e os demais) viram cartões-índice na subaba; "Grupos desta área" vira blocos recolhíveis com âncora |
| Contatos | `f3base-leads`, `f3base-formularios`, `f3base-conteudos` | Contatos · Formulários · Conteúdo privado | Contatos · Testes · Lixeira vira alternador de visão no cartão da lista |
| Medição | `f3base-medicao` | os dois conjuntos com rótulo de hoje, com as nove áreas | as análises de cada área viram alternador de visão quando são até cinco, ou um campo "Análise" no cartão de filtros quando são mais (Conversão tem dez) |
| Operação | `f3base-operacao` | Execuções · Entregas ao Pipedrive · Avisos à equipe | não há |
| Informações técnicas | `base-site-core-fator3&aba=tecnica` | sem subabas: seções recolhíveis com índice de âncoras | não há |

`base-site-core-fator3&aba=operacao` e `page=f3base-relatorios` continuam abrindo, por redirecionamento.

## Ajustes

| # | onde | hoje | muda para |
| --- | --- | --- | --- |
| 1 | carga das folhas: `includes/class-f3base-interface.php` linha 62; `includes/bootstrap-hooks.php` linhas 129, 422, 434 e 531; `admin/class-f3base-admin-tela.php` linha 149; `admin/class-f3base-admin-medicao.php` linha 94 | seis folhas carregadas por listas de páginas diferentes; `f3base-operacao` fica sem `f3base-interface.css` | um ponto único carrega `assets/f3-ui.css` e a folha própria em toda página `base-site-core-fator3` e `f3base-*` |
| 2 | folhas `admin/assets/f3base-admin.css`, `f3base-interface.css`, `f3base-painel.css`, `f3base-config143.css`, `assets/f3base-medicao-editorial.css` e `assets/f3base-contatos.css` | 37,7 KB em seis arquivos | uma folha própria só com o que é do Core (editor de formulário, gráficos da Medição, jornada do contato), sem regra de cabeçalho, navegação, cartão, selo ou tabela |
| 3 | raiz `div.wrap.f3base-tela.f3c-painel` | largura máxima de 1560 px (`.f3c-painel`) ou 1200 px (`--f3base-largura`) | acrescentar `f3-ui` e retirar a largura própria: vale 1320 px |
| 4 | cabeçalho, `F3Base_Interface::cabecalho` (`includes/class-f3base-interface.php` linha 6) | `header.f3c-header` com `div`; h1 muda por tela ("Contatos", "Formulários", "Relatórios") com `span.f3c-produto` acima; peso 600; selo `f3base-versao` azul de raio 12 px, ou cinza de raio 4 px sem a folha | `header.f3-heading` sem `div`; h1 sempre "Fator3 Site Core", no peso nativo; descrição por tela; `span.f3-version`; `f3c-produto` sai |
| 5 | `hr.wp-header-end` | só em `admin/class-f3base-admin-tela.php` | emitido pelo próprio `cabecalho()`, em todas as telas |
| 6 | título da Medição: `includes/class-f3base-medicao-interface.php` linha 23 e `includes/class-f3base-medicao-editorial-ui.php` linhas 18, 19 e 26 | cabeçalho "Relatórios"; o menu e a aba do navegador dizem "Medição" | o grupo ativo "Medição" nomeia a área; "Relatórios" sai do cabeçalho |
| 7 | primeiro nível: `nav.nav-tab-wrapper.f3base-abas.f3c-grupos` (`admin/class-f3base-admin-tela.php` linha 252) e `nav.f3c-grupos` nas outras telas | três conjuntos diferentes de pílulas, de 34 px, com classes `nav-tab` do WordPress misturadas | `nav.f3-nav` com `div.f3-groups` e os cinco grupos; sem `nav-tab` |
| 8 | segundo nível: `f3c-subnav`, `f3c-navegacao-agrupada`, `f3m-subnav` | traço de 2 px `#2271b1`, texto `#31526a`, 13 px | `div.f3-subtabs`, com `span.f3-subtabs-label` em cada conjunto com rótulo |
| 9 | terceiro nível: a segunda `f3c-navegacao-agrupada` de Conexões e entregas e `nav.f3base-indice` | sete links e um índice lateral | cartões-índice (`f3-cards`) e blocos recolhíveis (`f3-collapsible`) |
| 10 | cartões: `f3base-config-grupo` e `f3base-tecnica-secao` (raio 0, sombra), `f3base-bloco` e `f3base-saude-card` (raio 4 px), `f3base-config-card` e `f3m-card` (raio 6 px), `f3c-cartao` (raio 8 px, 18 px) | sete desenhos | `f3-section` no cartão de assunto; `f3-card` no item repetido (diretório de configurações, saúde dos módulos); `details.f3-collapsible` no grupo recolhível |
| 11 | selos: `f3base-chip--ativo`, `--degradado`, `--inativo` e `--aviso`; `f3c-selo` com `is-ok`, `is-warn`, `is-info` e `is-error`; `f3base-config-status--ok` e `--error`; `f3m-chip`; `f3base-teste` | cinco desenhos; um selo de Informações técnicas diz "WARN" | `f3-pill` com classe de estado; "degradado" e "aviso" viram `is-warn` com o texto "Atenção"; `f3base-config-status` vira `f3-callout` |
| 12 | formulários de Configurações: `table.form-table` dentro de `details.f3base-config-grupo` | 87 dos 90 campos de Conexões e entregas com o rótulo à esquerda | `f3-grid` de `f3-field`: rótulo acima, nota abaixo |
| 13 | barra de salvar `f3base-savebar` (`admin/assets/f3base-painel.css`) | fixa na janela, com `left` de 160, 36 ou 0 px conforme o menu do wp-admin | `f3-savebar`, presa ao pé do formulário |
| 14 | tabelas `widefat striped` em `f3c-table-scroll`, `f3c-rolagem`, `f3base-tabela-rolagem`, `f3base-editor` e `f3base-jornada` | cinco invólucros; em Operação pelo submenu e em Formulários a tabela não rola no próprio bloco; cabeçalho sem fundo e peso 400 em Configurações e Operação, `#f0f0f1` ou `#f6f7f7` e peso 600 na Medição | um invólucro, `f3-table-scroll`; cabeçalho `#f6f7f7`, peso 600 |
| 15 | Formulários (`page=f3base-formularios`) | tabela solta, sem cartão, em `f3base-editor` de 1080 px | tabela dentro de `f3-section`, com `f3-list-tools` |
| 16 | filtros da Medição (`form.f3m-filters`) | campos de 25 a 27 px de altura abaixo de 782 px | `f3-grid is-wide` de `f3-field`; 40 px abaixo de 782 px |
| 17 | lista de estado `dl.f3base-state-list` (`admin/assets/f3base-config143.css`) | colunas `minmax(150px,30%) 1fr`; numa tela de 507 px a lista vai até 686 px e fica cortada | `dl.f3-details`, que cai para uma coluna abaixo de 600 px |
| 18 | tela antiga de Relatórios integrados (`includes/class-f3base-relatorios.php` linha 407) | `div.wrap` com h1 próprio, sem cabeçalho nem classes do Core; o endereço hoje redireciona para Medição › Conversão | sai do pacote se não é mais alcançada; se é, recebe o cabeçalho e a navegação comuns |
| 19 | atributos `style="white-space:pre-wrap"` em `includes/class-f3base-leads-admin.php` (dois), `class-f3base-integracoes.php`, `class-f3base-relatorios.php` e `class-f3base-medicao-editorial-ui.php` | cinco estilos embutidos | classe na folha própria |
| 20 | itens de navegação abaixo de 782 px | 26 a 34 px de altura | 44 px, pela folha comum |

## Já está conforme

- Configurações, Informações técnicas e Operação já têm o `hr.wp-header-end`.
- Contatos e Medição já põem o rótulo acima do campo.
- Informações técnicas já usa seções recolhidas com índice.
- `f3base-painel.css` já usa variáveis com a paleta do wp-admin; basta trocar pelos nomes `--f3-*`.

## Aceite

As seis telas abrem com o mesmo cabeçalho, os mesmos cinco grupos e as medidas do guia; `page=f3base-operacao` fica igual às outras; a conferência da seção 7 do guia vem preenchida por tela, com as capturas a 360, 768 e 1440 px.
