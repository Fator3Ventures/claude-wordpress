# Situação dos pedidos do Site Core após a entrega 1.99.0

O pedido Core 439 foi atendido em desenvolvimento. A frota acompanha os sete dias seguintes à implantação, comparando episódios e recibos conforme a política configurada. O próximo número disponível no arquivo de pedidos recebido em 20/11/2026 é 440.

O aceite de campo do pedido 438 foi conferido em 20/11/2026, no Core 1.98.0 que a Engagia já operava. O HTML de /precos/ servido com HIT continha os dois IDs e a leitura de estado confirmou ambas as ofertas publicadas. A conferência foi de leitura e está em evidence/1990/engagia-438.json.

A prova no Site-Teste aprovou os oito cenários do pedido 439. O MCP 0.53.0 mascara o valor numérico de `token_vencendo` na leitura remota. O mesmo campo está disponível no wp-admin como **Token perto do vencimento**. O retorno ao mantenedor do canal acompanha esta entrega.
