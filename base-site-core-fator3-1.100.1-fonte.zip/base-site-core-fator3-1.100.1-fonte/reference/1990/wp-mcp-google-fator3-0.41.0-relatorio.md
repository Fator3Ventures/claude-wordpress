# Entrega — Fator3 MCP Google 0.41.0

Revisão 1 · 20/11/2026 · Implementação e correção · **com-pendencias**

## 1. De onde esta versão entra

Instalação limpa ou atualização direta do Google 0.40.0. Esta entrega implementa os quatro itens do **Pedido MCP Google 59**, da lista de 20/11/2026. A sequência de desenvolvimento passa ao número 60. O aceite operacional do pedido 59 fica no estado da frota. Os pedidos 57 e 58 já foram entregues em versões anteriores.

A base do Google é o instalador 0.40.0 de SHA-256 `dedded6ec02dbed38bb75f028720a222ec9b6f9335b80e3aa600b44d284da030` e o fonte `800d0fbaa35a2c00085e0356605d05925697b9741dc30685b3b39401e788dd89`. O cabeçalho exige WordPress 7.1.4 e PHP 8.3. A bancada executou WordPress 7.1.4, PHP 8.4.27 e MariaDB 11.8.6. No Site-Teste, a instalação da 0.41.0 ocorreu em WordPress 7.1.5 e PHP 8.3.37.

Foram lidos integralmente `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, ambos revisão 5 de 02/11/2026. Também foram conferidos a regra comum, a aba do Google, a lista mais recente de pedidos, os fontes e relatórios dos dois acompanhantes anexados e o checklist de encerramento.

## 2. Convivência e encaminhamentos

| Pacote | Base verificada | Resultado e ordem de troca |
|---|---|---|
| Fator3 MCP Google | 0.40.0 → 0.41.0 | O produtor encerra o episódio local e guarda o fechamento silencioso até a central suportá-lo. O Google pode ser atualizado primeiro. |
| Fator3 Site Core | 1.98.0 oficial e cópia experimental da mesma base | O oficial atende as aberturas e recuperações efetivas. Para retirar silenciosamente as referências antigas da central, o mantenedor deve incorporar o contrato do impacto e disponibilizar a sua versão. O executor Google retomará a fila. |
| Fator3 MCP | 0.52.0 fornecido | Transporte, autorização, descoberta e leitura paginada por HTTP exercitados no conjunto oficial. Durante esta rodada, o Site-Teste recebeu MCP 0.53.0 por uma atualização de terceiros. As dez definições de operação consultadas para a troca continuaram compatíveis. O relatório e os fontes recebidos para a bancada referem-se à 0.52.0. |
| Acompanhantes da frota | Meta 0.30.0 na leitura inicial e 0.31.0 no Site-Teste antes da troca, LinkedIn 0.26.0 e Pipedrive 0.12.0 onde presente | O inventário distingue as atualizações de terceiros. O pedido altera a fronteira Google–Core. |

O catálogo registra **311 habilidades**, com 123 leituras, 188 escritas e 46 definições de configuração. Contratos de configuração 4.0.0, catálogo 3.0.0, execução 2.0.0 e armazenamento 2.0.0. A opção existente `f3_mcp_google_alerts` ganha o campo opcional `access_recheck_hours`. A configuração mantém a revisão por conexão.

**Impacto para o Site Core.** O documento [wp-mcp-google-fator3-0.41.0-impacto-base-site-core-fator3.md](wp-mcp-google-fator3-0.41.0-impacto-base-site-core-fator3.md) fornece o patch testado, o contrato do filtro `f3base_incidente_acesso_encerrar_v1` e os critérios de aceite. No 1.98.0 oficial, comunicar uma recuperação convencional produz e-mail mesmo com `acao_humana=false`. Por isso o Google conserva o encerramento em `awaiting_access_core` e a referência antiga ainda pode aparecer aberta na central. O Core com o patch consome a fila, registra o motivo sob a referência original e ignora transições obsoletas. Foram feitas 31 verificações em WordPress, das quais 3 na base, 10 no Core oficial e 18 na cópia experimental. Os 213 arquivos do Google, os 1.288 do Core e os 481 do MCP coincidiram com seus instaladores após restaurar a cópia oficial do Core na bancada.

O SHA-256 do instalador Core 1.98.0 é `419dab4e9e822ed5a77239dcaef5598554cf50700c633f9625a0dcf91cbb7d5b` e o do fonte é `88e5e4a2c5fdc2507ad0669165079923872c3cd008ca15c159c0b892905c3951`. Para o MCP 0.52.0, os hashes são `44e5cfbff907a50cfd50ee4c5d5789055393f4965931d54ae24b09c60c4f8e9f` e `ae24e51083ab4ff6f0591ca43d008562d8efca783fb6054cc2d722a8b665f0de`, respectivamente.

## 3. Mudanças e evidências

| Pedidos MCP Google 59 | Comportamento entregue | Prova |
|---|---|---|
| 1. Erro de consulta avulsa | A leitura direta devolve o erro 403 ao agente. Em `ga/conformidade` com `check_access_bindings=true`, a resposta geral conserva o resultado e registra a recusa em `auth.access_bindings.http_status=403` com `status=permission_denied`. Só a execução operacional com origem de agenda ou concessão reconhecida pode abrir incidente de acesso. | Na 0.40.0, conta e propriedade recusadas elevaram o total de zero para dois. Na 0.41.0, a mesma consulta manteve o total inicial e o chamador recebeu o 403. Em banco novo, a contagem ficou em zero. |
| 2. Rechecagem e falta de uso | O executor revalida identidade, autorização, destino e recurso. O intervalo padrão é 6 h e pode ser ajustado entre 1 e 168 h por conexão. As sondas não renovam a contagem de uso. Após 24 h sem uso por agenda, o recurso é retirado e o episódio final é marcado `nao_usado` em silêncio. | Agenda GA4 real no executor WordPress, recusa persistente, recuperação automática e prova de silêncio com relógio de teste antecipado em banco descartável. O fluxo utiliza leitura mínima, debug ou validação autorizada. Uma entrega real por `/mp/collect` depende do sucesso da próxima entrega legítima para comprovar a recuperação desse endpoint. |
| 3. Conta e propriedade do mesmo episódio | A conexão, o principal, o vínculo da agenda e a família da API delimitam o episódio. Cada recurso continua sendo verificado individualmente. A recuperação de uma propriedade mantém aberto o episódio quando a conta continua recusada. | Dois membros no mesmo incidente e separação de vínculos distintos. Consultas manuais, resposta JSON inválida, revogação e concessão alterada têm cobertura. Uma lista vazia válida pode comprovar que voltou a permissão de listá-la. |
| 4. Recusa IAM | Depois da recusa de `iam.serviceAccountKeys.get`, o executor da conexão tenta uma vez por hora até obter prova válida da chave ativa. Na primeira leitura válida, encerra o incidente e volta ao ritmo normal de 6 h. Desativar a integração pausa as consultas automáticas. | 27 verificações após a atualização e 29 na instalação limpa, incluindo recusa, falha transitória, horário ainda não vencido, pausa, retomada e preservação do mesmo incidente no Core. |

Os intervalos marcam a próxima tentativa elegível. A consulta ocorre na passagem seguinte do executor do site. Para testar os intervalos, a bancada antecipou os horários dos registros de teste e acionou o gancho normal de execução. O HTTP do Google e o transporte de e-mail foram interceptados. Mensagens aceitas por `wp_mail` em campo são registros de submissão. A confirmação da caixa postal exige observação do destinatário.

## 4. Instalação e prova da troca

Instalar o ZIP identificado na seção 8. Na distribuição pela frota, conferir o SHA-256 servido pelo repositório raw e usar `expected_slug=wp-mcp-google-fator3` e `expected_sha256` na operação de instalação. O endereço previsto para publicação é [o instalador 0.41.0](https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/wp-mcp-google-fator3-0.41.0-instalador.zip).

| Verificação própria | Resultado | Evidência no fonte |
|---|---|---|
| Instalação limpa e atualização | O Google iniciou sozinho num banco novo. A primeira leitura confirmou 26 documentos e armazenamento pronto. Passaram 37 verificações de operação isolada. Foram 27 verificações de acesso na atualização e 27 na instalação limpa. A atualização conservou a conexão, os vínculos e os dois incidentes da 0.40.0 até o primeiro processamento. | `evidence/041/clean-first.json`, `smoke-clean-isolated.json`, `access-upgrade.json`, `access-clean.json` |
| Prontidão e permissões | `google/status` confirmou 0.41.0 e 311 habilidades. `google/integration-status` com `compact=true` retornou `read_success=true`. `google/storage-status` retornou `ready=true`. O assinante recebeu 403 via MCP para consulta privada e configuração e teve acesso ao painel recusado. | `permissions-upgrade.json`, `permissions-clean.json` |
| Documentação e painel | 26 documentos inteiros por MCP autenticado, 90 páginas e 124 verificações por instalação, incluindo hash, paginação e autorização. No painel real, o administrador simulou 6 → 4 h, confirmou a permanência do valor 6, aplicou 4, releu em nova requisição e restaurou 6. | `docs-upgrade.json`, `docs-clean.json`, `ui.json` |
| PHP e empacotamento | 1.389 testes e 16.549 asserções no PHP 8.4.27, zero falhas ou pulos. Lint dos 209 PHP do instalador. Duas gerações independentes produziram bytes iguais. | `unit84.json`, `lint.json`, `package.json`, `docs-build.txt` |

**Site-Teste.** O Site-Teste recebeu o mesmo instalador verificado na bancada. O SHA-256 e os 1.011.268 bytes foram reconferidos no staging. A operação confirmou atualização 0.40.0 → 0.41.0 e ativação. Antes da troca foram preservados os 28 registros de configuração Google e as duas tabelas do plugin em cópias privadas no próprio ambiente. A atualização terminou em 20/11 às 14h24 de Brasília com o plugin ativo. Em requisições novas, a página inicial e a API REST responderam HTTP 200. O armazenamento estava pronto, o contrato legível, as 311 habilidades registradas e o total de incidentes abertos era zero. Dos 26 documentos indexados, o Site-Teste devolveu integralmente `GUIA-0.41.0.md` e `AVISOS-RENOVACAO.md`, e o SHA-256 de cada documento coincidiu com o da sua cópia incluída no instalador. O staging próprio foi removido. A versão do Google foi a única a mudar entre os dois inventários imediatamente adjacentes à instalação. Um marcador de homologação de terceiros passou de ativo para inativo durante a janela. A operação Google não atuou sobre ele. Evidência sanitizada em `evidence/041/site-teste.json`.

**Campo anterior à troca.** Em 20/11, às 14h04 de Brasília, Pauta e Prática, Desenvolvimento de Softwares e Taberium já tinham os seis incidentes de conta/propriedade recuperados na 0.40.0. A recuperação IAM do Taberium estava registrada às 12h12min50s de Brasília, após a repetição manual descrita no pedido. Esses registros preservam o histórico anterior à 0.41.0. Em CTO Office, a auditoria do executor registrou três verificações GA4 bem-sucedidas e zero verificações periódicas Ads entre 19/11 às 02h20 e 20/11 às 14h04. A verificação de campo foi de leitura. A evidência foi sanitizada em `evidence/041/campo.json`.

## 5. Banco, migração e recuperação

O esquema de tabelas permanece na versão 2.0.0. Os novos campos de acompanhamento usam registros de incidente e configuração existentes. O executor percorre os incidentes antigos em lotes. Ao identificar a mesma URL numa recusa operacional, vincula o legado ao episódio consolidado. Se a leitura agendada da URL já funciona, usa esse sucesso. Um registro sem evidência de uso agendado termina como `nao_usado` após a janela. Para a sincronização externa, conserva a referência original e a fila de avisos. A identidade de conexão separa os dados do executor e do IAM.

A versão anterior desconhece esses motivos e as transições pendentes. Restaurar apenas arquivos PHP não desfaz e-mails aceitos, concessões no Google ou mudanças gravadas. Para recuperar dados, use a cópia coerente de arquivos, banco, configurações e chaves e confira os avisos e recibos antes de retomar a operação. Correções após publicação exigem nova versão.

## 6. O que permanece pendente

- **Mantenedor do Core.** Incorporar o encerramento silencioso e comprovar que a referência antiga saiu da central e que um fechamento `nao_usado` não submeteu e-mail. O Google já implementa a parte produtora e retoma a fila quando o contrato estiver disponível.
- **Operação do Site-Teste.** Disponibilizar uma credencial Google de teste e um recurso com permissão reversível para observar a recusa e a recuperação pelo provedor real. O Site-Teste estava sem credencial Google configurada. As chamadas controladas de aceitação estão comprovadas em WordPress com HTTP de laboratório.
- **Frota e titular do CTO Office.** Acompanhar até 22/11/2026 às 02h20 de Brasília o aceite dos pedidos 57 e 58. Na janela consultada ainda faltava uma conversão real com resultado individual. A condição de aceite não reabre esses itens para desenvolvimento.
- **Limites da bancada.** O PHP disponível localmente foi o 8.4.27. A suíte usou o executor de asserções compatível do projeto. O painel foi exercitado por HTTP autenticado. A captura visual por largura de tela ficou pendente porque o navegador local não conseguiu iniciar. Campanhas, ingestão comercial, edição de planilhas, uso do Cloud Shell e entrega em caixa postal real ficaram fora das provas desta rodada. A bancada terminou com os três plugins ativos e armazenamento pronto. Os três bancos de ensaio foram descartados. O inventário final registrou zero incidentes, jobs, agendas, avisos técnicos e senhas de aplicação de ensaio.

## 7. Credenciais e configuração do dono

A mudança usa a identidade já selecionada na conexão. O intervalo de rechecagem fica em **Ferramentas → Fator3 MCP Google → Incidentes**. No MCP, leia a revisão em `google/configuration-schema`, simule `google/configure-alerts` com `dry_run=true` e aplique com a revisão corrente. A política de 24 h e o intervalo IAM de 1 h são independentes desse campo. Para IAM, confira `last_attempt`, `next_attempt` e `metadata_state` em `google/service-account-key-status`. A leitura de metadados exige `iam.serviceAccountKeys.get` para a identidade ativa. A conta não precisa receber permissão de listar vínculos só para evitar avisos de diagnóstico.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | [wp-mcp-google-fator3-0.41.0-instalador.zip](wp-mcp-google-fator3-0.41.0-instalador.zip) | 1011268 | `47dea7ac080799dfd41cf7583c97a1959daefa0d50b0da490d8219c315bd4d76` |
| Fonte | [wp-mcp-google-fator3-0.41.0-fonte.zip](wp-mcp-google-fator3-0.41.0-fonte.zip) | 23280395 | `be55b406d34dca1fefa84b1393a6420e82621e82c67d0cacc1dfac506a670f28` |

Este é o relatório externo canônico. A cópia no fonte antecede o cálculo da identidade definitiva desse ZIP.
