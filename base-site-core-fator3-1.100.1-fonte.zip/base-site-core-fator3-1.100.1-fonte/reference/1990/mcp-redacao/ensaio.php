<?php
/** WP-CLI, somente em cópia WordPress local com os dois plugins ativos. */
use Fator3\McpFiles\SafeOutput;

if (wp_get_environment_type() !== 'local' || !in_array(wp_parse_url(home_url(), PHP_URL_HOST), ['127.0.0.1','localhost','::1','[::1]'], true)) {
    throw new RuntimeException('O ensaio exige ambiente local em loopback.');
}
$fase = getenv('F3_MCP_FASE');
if (!in_array($fase, ['oficial','proposta'], true) || !current_user_can('manage_options')) {
    throw new RuntimeException('Informe a fase oficial ou proposta e execute como administrador local.');
}
$opcao = 'f3base_avisos_tecnicos';
$campo = 'carencia_por_codigo_minutos';
$codigo = 'token_vencendo';
$folha = "/$campo/$codigo";
$mascara = '[redigido]';
$contrato = 'f3base/config-core-ler';
$habilidade = wp_get_ability($contrato);
if (!$habilidade || F3BASE_PLUGIN_VERSAO !== '1.99.0') {
    throw new RuntimeException('Instale Core 1.99.0 e MCP 0.53.0 na cópia descartável.');
}
$verificacoes = [];
$checar = static function ($nome, $condicao) use (&$verificacoes) {
    if (!$condicao) throw new RuntimeException($nome);
    $verificacoes[] = $nome;
};
$apresentar = static function ($resultado, $entrada, $ability = 'f3base/config-core-ler') {
    $contexto = SafeOutput::call_context('wp-mcp-ultimate/execute-ability', [
        'ability_name'=>$ability, 'parameters'=>$entrada,
    ]);
    // Mesmo envelope e decodificação JSON da apresentação pública no ToolsHandler.
    $envelope = json_decode(wp_json_encode(['data'=>$resultado]), false, 512, JSON_THROW_ON_ERROR);
    $resposta = SafeOutput::presentation($envelope, $contexto);
    return [json_decode(wp_json_encode($resposta['value']), true)['data'], $resposta['metadata']];
};
$entrada = ['nome'=>$opcao];
$saida = F3Base_Core_Config_Mcp::ler($entrada + ['caminhos'=>["/$campo",$folha,"/$campo/agenda_parada"]]);
if (is_wp_error($saida)) throw new RuntimeException($saida->get_error_message());
$efetivo = F3Base_Alertas_Operacionais::carencia_minutos($codigo);
$trecho = ['existe'=>true, 'valor'=>$efetivo];
$projetado = $saida['opcoes'][$opcao]['caminhos'];
$checar('Core retorna número no mapa e no ponteiro folha', $projetado["/$campo"]['valor'][$codigo] === $efetivo && $projetado[$folha] === $trecho);
[$apresentado, $meta] = $apresentar($saida,$entrada);
$caminhos = $apresentado['opcoes'][$opcao]['caminhos'];
$proposta = $fase === 'proposta';
$checar('comportamento do mapa na fase', $caminhos["/$campo"]['valor'][$codigo] === ($proposta ? $efetivo : $mascara));
$checar('comportamento da folha na fase', $caminhos[$folha] === ($proposta ? $trecho : $mascara));
$checar('controle vizinho', $caminhos["/$campo/agenda_parada"] === $projetado["/$campo/agenda_parada"]);
$checar('metadados das duas redações', $meta['total'] === ($proposta ? 0 : 2));
$completo = F3Base_Core_Config_Mcp::ler($entrada);
foreach (['valor','valor_efetivo','padrao_declarado'] as $origem) {
    $valor = $completo['opcoes'][$opcao][$origem][$campo][$codigo];
    $checar("leitura $origem", is_int($valor) && $apresentar($completo,$entrada)[0]['opcoes'][$opcao][$origem][$campo][$codigo] === ($proposta ? $valor : $mascara));
}
$mapa = static fn($valor) => ['opcoes'=>[$opcao=>['valor'=>[$campo=>[$codigo=>$valor,'access_token'=>'credencial-sintetica']]]]];
$mapaVisivel = static fn($res) => $res['opcoes'][$opcao]['valor'][$campo];
foreach ([-1,10081,'30','credencial-sintetica',true,null,[30]] as $i=>$invalido) {
    $ap = $mapaVisivel($apresentar($mapa($invalido), $entrada)[0]);
    $checar("valor inválido e credencial vizinha $i", $ap[$codigo] === $mascara && $ap['access_token'] === $mascara);
}
foreach ([0,10080] as $limite) {
    $ap = $mapaVisivel($apresentar($mapa($limite), $entrada)[0]);
    $checar("limite $limite", $ap[$codigo] === ($proposta ? $limite : $mascara) && $ap['access_token'] === $mascara);
}
foreach ([
    ['existe'=>true,'valor'=>30,'extra'=>'credencial-sintetica'],
    ['existe'=>false,'valor'=>30],
    ['existe'=>true,'valor'=>'30'],
    ['existe'=>true,'valor'=>['dado'=>'credencial-sintetica']],
    ['existe'=>true,'valor'=>10081],
    ['valor'=>30],
] as $i=>$invalido) {
    $r = ['opcoes'=>[$opcao=>['caminhos'=>[$folha=>$invalido]]]];
    $checar("envelope inválido $i",$apresentar($r,$entrada)[0]['opcoes'][$opcao]['caminhos'][$folha] === $mascara);
}
foreach ([[$entrada,'f3base/config-core-escrever'],[$entrada,'outro/ler'],[[],$contrato],[['nome'=>'f3base_outra'],$contrato]] as $i=>[$e,$nome]) {
    $checar("contexto não contratado $i", $mapaVisivel($apresentar($mapa(30),$e,$nome)[0])[$codigo] === $mascara);
}
$r = ['opcoes'=>[$opcao=>['outro'=>[$campo=>[$codigo=>30]]]]];
$checar('caminho de resposta não contratado', $apresentar($r,$entrada)[0]['opcoes'][$opcao]['outro'][$campo][$codigo] === $mascara);
$r = ['opcoes'=>['f3base_outra'=>['valor'=>[$campo=>[$codigo=>30]]]]];
$checar('opção diferente no conteúdo', $apresentar($r,$entrada)[0]['opcoes']['f3base_outra']['valor'][$campo][$codigo] === $mascara);
$fonte = WP_PLUGIN_DIR.'/wp-mcp-fator3/includes/Release014.php';
echo wp_json_encode([
    'fase'=>$fase, 'wp'=>get_bloginfo('version'), 'php'=>PHP_VERSION, 'core'=>F3BASE_PLUGIN_VERSAO,
    'contrato'=>$saida['contract_version'], 'arquivo_mcp_sha256'=>hash_file('sha256',$fonte),
    'minutos_core'=>$efetivo, 'minutos_mcp'=>$caminhos["/$campo"]['valor'][$codigo], 'folha_mcp'=>$caminhos[$folha],
    'redacoes_nesta_projecao'=>$meta['total'], 'total'=>count($verificacoes), 'verificacoes'=>$verificacoes,
],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), PHP_EOL;
