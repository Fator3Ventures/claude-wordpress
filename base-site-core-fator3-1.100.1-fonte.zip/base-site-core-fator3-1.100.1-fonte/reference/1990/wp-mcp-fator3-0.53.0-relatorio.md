# Entrega — Fator3 MCP 0.53.0

20/11/2026, horário de Brasília. **Pedidos MCP 90.** O MCP passa a confirmar a ausência persistente do marcador horário antes de abrir `agenda_parada`. O Site Core 1.98.0 recebe a abertura e a recuperação.

## 1. Base de migração

Instalação limpa e atualização direta da 0.52.0. Foram conferidos os arquivos oficiais dessa base. O instalador tem SHA-256 `44e5cfbff907a50cfd50ee4c5d5789055393f4965931d54ae24b09c60c4f8e9f` e o fonte tem SHA-256 `ae24e51083ab4ff6f0591ca43d008562d8efca783fb6054cc2d722a8b665f0de`. As duas normas centrais do projeto foram lidas integralmente na revisão 5, de 02/11/2026, com a regra comum, a aba do MCP, os pacotes e o pedido de 20/11.

Requisitos mínimos de WordPress 7.1.4 e PHP 8.3. Bancada com WordPress 7.1.4, PHP 8.4.27 e MariaDB 11.8.6. O Site-Teste executou WordPress 7.1.5 e PHP 8.3.37.

## 2. Convivência e contratos

Na preparação do instalador e na primeira ativação em bancada, a coorte incluía Site Core 1.98.0, Google 0.40.0, Meta 0.30.0, LinkedIn 0.26.0 e Pipedrive 0.12.0. O SHA-256 do instalador do Core fornecido é `419dab4e9e822ed5a77239dcaef5598554cf50700c633f9625a0dcf91cbb7d5b`. O registro da bancada contém 172 habilidades próprias do MCP. As entradas de `system/maintenance-configure` e `system/maintenance-preview` aceitam a nova chave opcional. A descoberta de `system/maintenance-policy` documenta a janela e o estado da observação. As rotas, os nomes de operações e o contrato de publicação `incidentes/1` continuam os mesmos.

Durante a homologação do MCP, o Site-Teste recebeu Google 0.41.0 e Meta 0.31.0. A leitura final de `system/health` confirmou os seis provedores ativos e o registro de ferramentas pronto. As operações `google/documentation` e `meta/documentation` foram descobertas e lidas pelo canal 0.53.0; as respostas informaram 0.41.0 e 0.31.0. O arquivo de notas do instalador identifica a matriz usada em sua preparação. Em uma segunda bancada, o mesmo ZIP do MCP foi instalado com esses dois pacotes atualizados e o Core 1.98.0. Passaram 10 verificações de instalação, 22 de agenda e 9 de política, além das consultas autenticadas `google/configuration-schema`, `meta/configuration-schema` e `f3base/incidentes-tecnicos-ler`. Os 172 nomes e schemas próprios do canal coincidiram com o catálogo de preparação. Os hashes dos acompanhantes, as versões e os resultados constam em `evidencias/0530/coorte-final.json`.

O MCP determina quando há evidência para abrir ou recuperar o incidente do recurso `marcador-wordpress`. O Core 1.98.0 já aceita o campo `desde`, registra o episódio e administra a entrega de e-mail. A correção utiliza esse contrato existente. O pedido Core 439 citado pela frota segue sob responsabilidade de seu mantenedor. Esta entrega resolve a origem do alerta no canal e não encerra o pedido do Core. Os quatro conectores de domínio e o Implantador não exigem mudança para consumir o canal. A alteração não impõe ordem especial para a troca dos acompanhantes.

## 3. Alteração e comprovação do pedido

Na 0.52.0, o observador tratava qualquer estado diferente de ativo como agenda parada. Foi possível reproduzir, em WordPress com o Core 1.98.0, uma abertura e uma recuperação com intervalo de um segundo, ambas produzidas pela WP-CLI.

Na 0.53.0, o canal verifica o marcador `f3_mcp_cron_observed` ao encerrar uma requisição elegível. A primeira ausência inicia a contagem. Outra requisição precisa confirmar a ausência depois do intervalo configurado. Por padrão, o intervalo é de 300 segundos. Uma leitura inconclusiva não comprova ausência. A execução do marcador e o reagendamento bem-sucedido interrompem a contagem. A passagem do próprio marcador e a WP-CLI não publicam abertura. Um marcador ativo em leitura posterior encerra um incidente aberto. O Core recebe em `desde` o horário da primeira ausência confirmada.

| Verificação na bancada | Resultado |
|---|---|
| Limite de 5 minutos | Repetir a leitura na mesma requisição ou aos 299 segundos preservou a espera. Duas requisições paralelas no limite produziram uma abertura. |
| Execução do evento | O comando nativo `wp cron event run` executou o marcador. O teste também fez uma leitura HTTP enquanto outro processo executava o marcador. O canal não publicou incidente nessas passagens. |
| Reagendamento e recuperação | A reposição do marcador antes da confirmação interrompeu a contagem. Após uma ausência confirmada, o Core recebeu a recuperação e conservou o primeiro horário da falta. |
| Janela ajustável | A bancada verificou o valor padrão, os dois limites, valores fora da faixa, simulação, conflito de revisão e aplicação da política. Uma janela de 601 segundos abriu no limite configurado. |
| Instalação e dados existentes | O WordPress ativou o MCP isolado em instalação limpa e atualizou o ZIP da 0.52.0 com a coorte. Uma nova requisição conferiu versão, saúde, agenda e dados de conexão, opções e expirações OAuth preservados. |

Na bancada as fronteiras temporais foram ensaiadas com um relógio controlado apenas no código de teste do MCP. Os registros de antes e depois, a configuração e os casos paralelos ficam em `evidencias/0530/` e os procedimentos em `tools/release0530/`.

### Ausência deliberada no Site-Teste

O ensaio usou o marcador real e a janela padrão. Antes da remoção havia uma única ocorrência horária, com argumentos vazios, prevista para **14h48min56s de Brasília**. A operação de cron conferiu a revisão e retirou apenas essa ocorrência. Uma guarda temporária preparou a reposição e interceptou exclusivamente as mensagens técnicas de abertura e recuperação do recurso testado.

| Horário de Brasília em 20/11 | Observação |
|---|---|
| 14h18min25s | Primeira ausência. O MCP iniciou a espera. A consulta do Core permaneceu sem incidente. |
| 14h21min17s | A agenda ainda estava ausente. A amostra permaneceu `pending` e o Core continuou sem abertura. |
| 14h23min27s | Outra requisição confirmou a falta. O Core registrou a abertura 302 segundos após a primeira ausência, com `desde=1795195105`. |
| 14h23min41s | Após a reposição da ocorrência original, o Core registrou a recuperação. O episódio durou 316 segundos desde a primeira falta; as duas notificações foram interceptadas no site, com zero entregas pendentes. |

A leitura final confirmou uma única ocorrência às 14h48min56s, com os mesmos argumentos e recorrência. A conferência encontrou zero ocorrências de reposição temporária, zero opções de controle do ensaio, nenhum auxiliar instalado e nenhum registro sintético remanescente no Core. As leituras de cada fase foram preservadas em `evidencias/0530/site-teste-agenda.json`.

## 4. Instalação, testes de acesso e prontidão

Em WordPress limpo, envie o ZIP instalador, ative o plugin e abra **Ferramentas → Fator3 MCP**. Para distribuir após a publicação, a frota confere o SHA-256 da seção 8 e executa `plugins/upload` com `expected_slug=wp-mcp-fator3`, `expected_sha256`, `overwrite=true` e `activate=true`. O endereço previsto para o instalador é:

`https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/wp-mcp-fator3-0.53.0-instalador.zip`

No Site-Teste, a transferência de quatro partes reconstituiu um ZIP de 974586 bytes com o mesmo SHA-256 do pacote entregue. A operação `plugins/upload-base64` de ID `3f5dd31b0ae373a4cc889be460ea61fa` retornou `version_before=0.52.0`, `version_after=0.53.0`, `applied=true`, `active=true` e `recovery_status=applied`. O identificador da pré-imagem de arquivos é `a7d601e976464b023f4ef9bd`. A página inicial e o índice REST devolveram HTTP 200 antes e depois. Uma leitura posterior verificou a ausência do ZIP de estágio.

| Verificação | Resultado |
|---|---|
| Arquivos do WordPress | Os 481 arquivos das duas árvores instaladas em bancada coincidiram byte a byte com o ZIP final. Os 474 arquivos PHP passaram pelo lint. O verificador documental concluiu 208 verificações. |
| Documentação pelo canal | No Site-Teste, três leituras paginadas de `system/guide` reconstruíram os 4000 bytes de `release-0530`, SHA-256 `a2a3c2884785aa8a36a41398a982fb02d5fbdeb2a9248db04c3f72280fdc0146`. Na bancada, os testes autenticados verificaram descoberta, schema, paginação e rejeição de revisão desatualizada após a migração. |
| Autenticação | As quatro chamadas às rotas `/wp-json/mcp/wp-mcp-fator3` e `/wp-json/mcp/wp-mcp-ultimate`, sem credencial ou com Bearer inválido, receberam HTTP 401 na bancada e no Site-Teste. No Site-Teste, as quatro respostas trouxeram desafio Bearer. |
| Painel de manutenção | As sete abas foram verificadas a 360, 768 e 1440 px. O painel recusou 299 segundos, simulou 500 e preservou os 300 gravados. O teste de acesso de editor obteve HTTP 403. As 21 capturas do navegador estão em `evidencias/0530/painel/`. |

Ao fim do ensaio, uma requisição independente confirmou MCP 0.53.0, saúde e registro de ferramentas válidos, marcador ativo e zero recuperações pendentes. O valor lido da janela permaneceu em 300 segundos.

## 5. Banco de dados e recuperação

O canal conserva o schema de persistência 2. A observação ocupa um registro de estado do site, identificado por `automation/agenda-sample`, nas tabelas existentes. Esse registro guarda o estado, os instantes e a revisão da política aplicada. A opção `f3_mcp_automatic_maintenance` recebe o novo campo quando o administrador salva uma política. Uma instalação que ainda não o gravou usa o valor padrão de 300 segundos. A nova janela não altera a seleção de um lote de retenção pendente. A publicação conserva a fila do MCP para as transições que aguardam o Core.

A pré-imagem da atualização cobre os arquivos do canal. As observações gravadas pelo MCP, os recibos de operação e o histórico ou envio de avisos do Core têm persistência própria. Uma correção de software depois da instalação usa outra versão.

## 6. Aceite de campo pendente

O pedido 90 exige sete dias de cron CLI a cada 15 minutos nos 14 sites. A frota inicia a janela por site após instalar e conferir o ZIP desta versão. Acompanhe em `f3base/incidentes-tecnicos-ler` os episódios de `pacote=canal`, `codigo=agenda_parada`. Para cada recuperação, confira a diferença em segundos entre `alterado_em` e `desde` e registre o número de episódios abaixo de 300 segundos. O aceite exige zero. Registre a cobertura dos 14 sites, a cadência do cron e o período coberto.

O Core 1.98.0 apresenta o último estado por recurso. Colete as leituras durante a janela e confronte a sequência com os recibos em `f3base/email-wordpress-fila-ler`. A distribuição e a coleta na frota permanecem pendentes. O Site-Teste e a bancada cobrem a comprovação técnica desta rodada.

## 7. Permissões e configuração

A conta administradora pode simular a política em **Ferramentas → Fator3 MCP → Manutenção** ou por `system/maintenance-configure` em conexão de Manutenção. Aplique com a revisão devolvida e releia por `system/maintenance-policy`. A janela aceita de 300 a 86.400 segundos. A mudança reutiliza a autorização administrativa já existente e o destino de avisos técnicos configurado no Core. As conexões com fornecedores e suas credenciais não precisam de intervenção.

## 8. Identidade dos arquivos

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| wp-mcp-fator3-0.53.0-instalador.zip | 974586 | `8403d4b5ce901bb3261d00823508b3c7f12507e2283a4d42c5d9822a7463c2a7` |
| wp-mcp-fator3-0.53.0-fonte.zip | 5336609 | `7d45bba94249bd0b9ef687a285809b20e81ef5dc1b5a7a8503bb7d5b9c587c84` |

Digest SHA-256 do inventário de runtime: `74c2c5f950cc77cf0306fde8662d2b630e45722912418b1c875b5bb8ac30d0c5`.

O instalador foi reconstruído a partir do fonte entregue e conferido byte a byte.
