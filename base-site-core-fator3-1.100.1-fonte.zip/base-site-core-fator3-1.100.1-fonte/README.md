# Fonte do Fator3 Site Core 1.100.1

O código instalável está em `work/plugin/base-site-core-fator3/`. A implementação visual partiu do fonte oficial da 1.99.0. A correção desta entrega parte da árvore da 1.100.0 efetivamente instalada no Site-Teste. Os três guias visuais recebidos, os relatórios dos acompanhantes e a identidade dos pacotes estão em `reference/2000/`. O relatório canônico externo identifica os dois ZIPs. O documento `RELATORIO-PRE-FECHAMENTO.md` é sua cópia anterior ao fechamento do fonte.

## Reprodução do instalador

Na raiz deste diretório, use Python 3, zlib 1.3.2 e PHP de 64 bits a partir de 8.3. O manifesto fixa caminhos, tamanho e SHA-256 dos arquivos de runtime. Depois de conferir os arquivos, os seguintes comandos recompõem os ZIPs.

```sh
F3BASE_PHP=php python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.100.1-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.100.1-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.100.1-fonte.zip
```

## Verificações

A correção da versão instalada 1.100.0 ajusta os dois emissores de selos neutros no painel técnico. As provas do patch estão em `evidence/2001/`. A matriz original de 287/288 foi preservada em `evidence/2000/visual/`.

Os roteiros desta versão ficam em `tests/200/` e as saídas das duas etapas em `evidence/2000/` e `evidence/2001/`. Use um WordPress descartável com e-mail e HTTP externo interceptados. Os testes conferem o banco de laboratório esperado. O instalador exclui as fixtures de desenvolvimento e as capturas.

- Instalação limpa e trocas a partir da 1.100.0 e da 1.99.0. Ao repetir o ensaio com esta última, defina F3_BASE_ENSAIO=1.99.0. O teste `instalacao.php` verifica a conclusão do ciclo, o contrato registrado, as capacidades e a configuração anterior do cenário de atualização.
- Operação. `listas-operacao.php` cria 24 registros sintéticos por lista dentro de uma transação e verifica busca, paginação e IDs antes de revertê-la. O par `resultado-operacao.php` / `.py` verifica por HTTP a apresentação de uma ação de ensaio inválida, sem chamar o Slack.
- Contatos, Medição e Configurações. Há ensaios em WordPress e Chromium para navegação, operações do painel e acessibilidade. Credenciais ou cookies temporários da bancada só são usados durante os ensaios.
- Integrações. Os casos de `contratos/` verificam os incidentes com carência, a leitura do campo pelo MCP 0.54.0 e os encerramentos de acessos e a fila paginada do Google 0.42.0.
- Conferência visual. Consulte a matriz e as capturas finais em `evidence/2001/visual/`. O caderno HTML entregue ao lado do relatório permite consultar as imagens por tela e largura sem acesso a um site externo.
