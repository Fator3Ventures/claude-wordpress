/* Avisos de ações administrativas, inclusive os produzidos após o carregamento. */
document.addEventListener('click', function (event) {
    const button = event.target instanceof Element && event.target.closest('button[data-f3-dismiss]');
    const result = button && button.closest('.f3-ui .f3-result');
    if (!result) {
        return;
    }
    const root = result.closest('.f3-ui');
    const heading = Array.from(root.querySelectorAll('h2')).find(function (item) {
        return (result.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_FOLLOWING)
            && !item.closest('details:not([open]), [hidden], [inert]') && item.getClientRects().length;
    });
    result.hidden = true;
    if (heading) {
        heading.tabIndex = -1;
        heading.focus();
        if (document.activeElement === heading) {
            return;
        }
    }
    const active = root.querySelector('.f3-groups [aria-current]');
    if (active) {
        active.focus();
    }
});
