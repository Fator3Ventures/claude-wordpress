(function () {
    'use strict';
    const painel = document.querySelector('.f3base-medicao');
    if (!painel) return;

    painel.addEventListener('click', function (evento) {
        const botao = evento.target.closest('[data-f3m-copy]');
        if (!botao) return;
        const valor = botao.dataset.f3mCopy;
        let aviso = painel.querySelector('#f3m-status');
        if (!aviso) {
            aviso = document.createElement('p');
            aviso.id = 'f3m-status';
            aviso.setAttribute('role', 'status');
            botao.after(aviso);
        }
        const manual = () => { aviso.textContent = 'Selecione e copie o ID: ' + valor; };
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(valor).then(function () { aviso.textContent = 'ID da sessão copiado.'; }, manual);
        } else manual();
    });

}());
