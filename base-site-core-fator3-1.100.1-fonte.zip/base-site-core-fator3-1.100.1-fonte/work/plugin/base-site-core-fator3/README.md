# Fator3 Site Core 1.100.1

Consulte docs/DOCUMENTACAO.md, docs/GUIA-PAINEL.md e docs/RELEASE-1.100.0.md para operar as telas administrativas e verificar o ciclo da versão.
