<?php
/** Ferramentas das listas paginadas do painel de Operação. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

final class F3Base_Admin_Lista {
    public static function texto(string $campo): string {
        $valor = $_GET[$campo] ?? '';
        return is_string($valor) ? sanitize_text_field(wp_unslash($valor)) : '';
    }

    /** Colunas vêm exclusivamente do código que define a tabela do painel. */
    public static function filtro(string $termo, array $colunas): string {
        if ($termo === '') { return ''; }
        global $wpdb;
        $padrao = '%' . $wpdb->esc_like($termo) . '%';
        $partes = [];
        foreach ($colunas as $coluna) {
            $partes[] = $wpdb->prepare('%i LIKE %s', $coluna, $padrao);
        }
        return ' AND (' . implode(' OR ', $partes) . ')';
    }

    public static function busca(string $campo, string $titulo, string $fila, ?array $seletor = null): void {
        echo '<form method="get" class="f3-list-tools" action="' . esc_url(admin_url('admin.php')) . '">';
        echo '<input type="hidden" name="page" value="f3base-operacao">';
        if ($fila !== '') { echo '<input type="hidden" name="fila" value="' . esc_attr($fila) . '">'; }
        echo '<label class="f3-field" for="' . esc_attr($campo) . '">' . esc_html($titulo) . '<input id="' . esc_attr($campo) . '" name="' . esc_attr($campo) . '" type="search" value="' . esc_attr(self::texto($campo)) . '"></label>';
        if ($seletor !== null) {
            [$chave, $rotulo, $opcoes] = $seletor;
            echo '<label class="f3-field" for="' . esc_attr($chave) . '">' . esc_html($rotulo) . '<select name="' . esc_attr($chave) . '" id="' . esc_attr($chave) . '">';
            foreach ($opcoes as $valor => $nome) {
                echo '<option value="' . esc_attr($valor) . '"' . selected(self::texto($chave), $valor, false) . '>' . esc_html($nome) . '</option>';
            }
            echo '</select></label>';
        }
        echo '<button class="button">Filtrar lista</button></form>';
    }

    public static function paginacao(string $chave, int $pagina, int $total, int $tamanho): void {
        $inicio = ($pagina - 1) * $tamanho + 1;
        $fim = min($total, $pagina * $tamanho);
        $intervalo = $inicio > $total ? sprintf('0 de %s', number_format_i18n($total))
            : sprintf('%s–%s de %s', number_format_i18n($inicio), number_format_i18n($fim), number_format_i18n($total));
        echo '<div class="f3-list-tools"><span class="f3-list-total">' . esc_html($intervalo) . '</span>';
        if ($pagina > 1) { echo '<a class="button" href="' . esc_url(add_query_arg($chave, $pagina-1)) . '">Anterior</a>'; }
        if ($fim < $total) { echo '<a class="button" href="' . esc_url(add_query_arg($chave, $pagina+1)) . '">Próxima</a>'; }
        echo '</div>';
    }
}
