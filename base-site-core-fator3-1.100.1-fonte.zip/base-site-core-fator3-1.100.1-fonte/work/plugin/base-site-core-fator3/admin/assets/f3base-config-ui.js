/*! F3 Base — edição administrativa. GPL-2.0-or-later. */
(() => {
    'use strict';
    const forms = new Map();
    const dirty = new Set();
    function values(form) {
        return JSON.stringify(Array.from(new FormData(form)).filter(([name]) => /^(f3base\[|f3base_apagar\[|valores\[|config\[|segredos\[|apagar\[|mapeamento$|formularios$)/.test(name)));
    }
    // Snapshot after every footer script has drawn its controls (structured editors, date fields).
    function snapshot() {
        for (const form of document.querySelectorAll('.f3base-form, [data-f3base-edicao], .f3base-tela form[method=post], .f3base-conexoes form[method=post]')) forms.set(form, values(form));
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', snapshot); else snapshot();
    function changed(event) {
        const form = event.target.closest('form');
        if (!forms.has(form)) return;
        const editing = values(form) !== forms.get(form);
        if (editing) dirty.add(form); else dirty.delete(form);
        const status = form.querySelector('[data-f3base-situacao]');
        if (status) {
            const message = editing ? 'Alterações não salvas' : '';
            if (status.textContent !== message) status.textContent = message;
        }
    }
    document.addEventListener('input', changed);
    document.addEventListener('change', changed);
    document.addEventListener('submit', event => { if (!event.defaultPrevented) dirty.delete(event.target); });
    window.addEventListener('beforeunload', event => { if (dirty.size) { event.preventDefault(); event.returnValue = ''; } });
    let first;
    for (const error of document.querySelectorAll('.f3base-erro-campo')) {
        const row = error.closest('.f3base-grupo-bloco, tr');
        if (!row) continue;
        for (const control of row.querySelectorAll('input:not([type=hidden]), textarea, select')) {
            control.setAttribute('aria-invalid', 'true');
            const ids = new Set((control.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean));
            ids.add(error.id); control.setAttribute('aria-describedby', [...ids].join(' '));
            first ??= control;
        }
        for (let block = row.closest('details'); block; block = block.parentElement.closest('details')) block.open = true;
    }
    first?.focus();
    document.addEventListener('click', event => {
        const button = event.target.closest('[data-f3base-admin-email]');
        const field = button?.form?.querySelector('[name="f3base[f3base_contato][email_leads][]"]');
        if (field) { field.value = button.dataset.f3baseAdminEmail; field.dispatchEvent(new Event('input', {bubbles:true})); field.focus(); }
    });

    const search = document.getElementById('f3base-busca-config');
    if (search) {
        const normal = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
        const cards = [...document.querySelectorAll('[data-f3base-busca]')].map(card => [card, normal(card.dataset.f3baseBusca)]);
        const clear = document.getElementById('f3base-busca-limpar');
        const status = document.getElementById('f3base-busca-status');
        function filter() {
            const words = normal(search.value).trim().split(/\s+/).filter(Boolean);
            let count = 0;
            for (const [card, text] of cards) { card.hidden = !words.every(word => text.includes(word)); if (!card.hidden) count++; }
            for (const group of document.querySelectorAll('[data-f3base-grupo]')) group.hidden = !group.querySelector('[data-f3base-busca]:not([hidden])');
            clear.hidden = !search.value;
            status.textContent = !words.length ? '' : count === 0 ? 'Nenhuma configuração encontrada. Tente outro termo ou limpe a busca.' : count === 1 ? '1 configuração encontrada.' : `${count} configurações encontradas.`;
        }
        search.addEventListener('input', filter);
        search.form?.addEventListener('submit', event => { event.preventDefault(); filter(); });
        clear.addEventListener('click', () => { search.value = ''; filter(); search.focus(); });
        filter();
    }

    function resetRow(row) {
        for (const control of row.querySelectorAll('input, select, textarea')) {
            if (control.type === 'checkbox' || control.type === 'radio') { control.checked = false; control.defaultChecked = false; }
            else if (control.tagName === 'SELECT') control.selectedIndex = 0;
            else control.value = '';
        }
    }
    document.addEventListener('click', event => {
        const remove = event.target.closest('[data-remover-linha]');
        if (remove) {
            const row = remove.closest('tr');
            if (!row?.closest('[data-f3base-repetidor]')) return;
            const neighbor = row.nextElementSibling || row.previousElementSibling;
            if (neighbor) row.remove(); else resetRow(row);
            const control = (neighbor || row).querySelector('input, select, textarea');
            control?.dispatchEvent(new Event('input', {bubbles:true})); control?.focus(); return;
        }
        const add = event.target.closest('[data-adicionar-linha]');
        if (!add) return;
        const table = [...(add.form?.querySelectorAll('[data-f3base-repetidor]') || [])].find(t => t.dataset.f3baseRepetidor === add.dataset.adicionarLinha);
        const body = table?.tBodies[0];
        if (!body?.rows.length) return;
        const row = body.rows[body.rows.length - 1].cloneNode(true);
        const indexes = [...body.querySelectorAll('[name]')].map(el => Number(el.name.match(/\[(\d+)\]/)?.[1] || 0));
        const index = Math.max(0, ...indexes) + 1;
        const ids = new Map();
        for (const el of row.querySelectorAll('[id]')) { const original = el.id; el.id = `${original.replace(/-clone-\d+$/, '')}-clone-${index}`; ids.set(original, el.id); }
        for (const el of row.querySelectorAll('[for], [aria-describedby], [aria-labelledby]')) {
            for (const attr of ['for','aria-describedby','aria-labelledby']) if (el.hasAttribute(attr)) el.setAttribute(attr, el.getAttribute(attr).split(/\s+/).map(id => ids.get(id) || id).join(' '));
        }
        for (const control of row.querySelectorAll('[name]')) control.name = control.name.replace(/\[\d+\]/, `[${index}]`);
        resetRow(row); body.append(row);
        const field = row.querySelector('input, select, textarea'); field?.dispatchEvent(new Event('input', {bubbles:true})); field?.focus();
    });

    // Open the whole chain when arriving through a bookmark or the area index.
    function focusFragment(hash, focus) {
        if (!hash) return;
        let id;
        try { id = decodeURIComponent(hash.slice(1)); } catch { return; }
        const target = document.getElementById(id);
        if (!target) return;
        for (let block = target.closest('details'); block; block = block.parentElement?.closest('details')) {
            block.open = true;
        }
        if (focus) {
            const heading = target.matches('details') ? target.querySelector(':scope > summary') : target;
            if (heading) {
                if (!heading.matches('a,button,input,select,textarea,summary,[tabindex]')) heading.tabIndex = -1;
                heading.focus({preventScroll:true});
            }
        }
    }
    document.addEventListener('click', event => {
        const link = event.target.closest('.f3-ui a[href^="#"]');
        if (link) focusFragment(link.hash, true);
    });
    window.addEventListener('hashchange', () => focusFragment(location.hash, true));
    focusFragment(location.hash, Boolean(location.hash));

    const type = document.getElementById('f3base-nav-tipo');
    const select = document.getElementById('f3base-nav-id');
    const find = document.getElementById('f3base-nav-pesquisar');
    const next = document.getElementById('f3base-nav-proxima');
    const term = document.getElementById('f3base-nav-busca');
    const status = document.getElementById('f3base-nav-status');
    if (!type || !select || !find || !next || !term || !status) return;
    let page = 1, sequence = 0, controller;
    function filterType() {
        for (const option of select.options) option.hidden = !!option.dataset.tipo && option.dataset.tipo !== type.value;
        if (type.value === 'tema' || select.selectedOptions[0]?.hidden) select.value = '0';
    }
    function invalidate() { sequence++; controller?.abort(); page = 1; next.hidden = true; find.disabled = false; status.textContent = ''; }
    type.addEventListener('change', () => { invalidate(); filterType(); });
    term.addEventListener('input', invalidate); filterType();
    async function load(number) {
        if (type.value === 'tema') { status.textContent = 'Selecione Menu clássico ou Bloco para pesquisar.'; return; }
        const ticket = ++sequence, kind = type.value;
        controller?.abort(); controller = new AbortController();
        const url = new URL(find.dataset.url);
        url.search = new URLSearchParams({action:'f3base_navegacao_buscar',nonce:find.dataset.nonce,tipo:kind,busca:term.value,pagina:String(number)});
        find.disabled = true; next.disabled = true; status.textContent = 'Pesquisando referências…';
        try {
            const response = await fetch(url, {credentials:'same-origin', signal:controller.signal}); const data = await response.json();
            if (ticket !== sequence) return;
            if (!response.ok || !data.ok || !Array.isArray(data.itens)) throw Error();
            const selected = select.selectedOptions[0]?.cloneNode(true); const current = select.value;
            select.replaceChildren(new Option('Selecione uma referência', '0'));
            if (selected && current !== '0' && selected.dataset.tipo === kind) select.append(selected);
            for (const item of data.itens) {
                if (String(item.id) === current) continue;
                const option = new Option(`${item.id} — ${item.nome}`, String(item.id)); option.dataset.tipo = kind; select.append(option);
            }
            select.value = current || '0'; page = number; next.hidden = !data.proxima_pagina;
            status.textContent = `Página ${number}: ${data.itens.length} referência(s). Selecione uma referência e salve para aplicar.`;
        } catch (error) { if (ticket === sequence && error.name !== 'AbortError') status.textContent = 'Pesquisa indisponível. Tente novamente.'; }
        finally { if (ticket === sequence) { find.disabled = false; next.disabled = false; } }
    }
    find.addEventListener('click', () => load(1)); next.addEventListener('click', () => load(page + 1));
    term.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); load(1); } });
})();

document.addEventListener('click', async function(event) {
    const button = event.target.closest('[data-email-simular]');
    if (!button || button.disabled) return;
    const field = button.closest('[data-f3base-campo]');
    const status = field.querySelector('[role="status"]');
    const labels = {valido:'Válido', corrigido:'Corrigido', nao_verificado:'Não verificado', invalido:'Inválido'};
    button.disabled = true;
    status.textContent = 'Consultando o domínio…';
    try {
        const body = new URLSearchParams({action:'f3base_email_simular', _ajax_nonce:button.dataset.emailSimular,
            valor:field.querySelector('#f3base-email-amostra').value, correcoes:field.querySelector('textarea').value});
        const response = await fetch(window.ajaxurl, {method:'POST', credentials:'same-origin', body});
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.mensagem || 'A simulação falhou.');
        status.textContent = [labels[result.classe],result.corrigido,result.motivo].join(' · ');
    } catch (error) {
        status.textContent = error.message;
    } finally {
        button.disabled = false;
    }
});

/* Index long, fully rendered tables without changing dataset pagination or form fields. */
(() => {
    let tableIndex = 0;
    function prepare(root = document) {
        root.querySelectorAll('.f3-ui table.widefat').forEach(table => {
            let scroll = table.parentElement;
            if (!scroll.classList.contains('f3-table-scroll')) {
                scroll = document.createElement('div');
                scroll.className = 'f3-table-scroll';
                table.before(scroll);
                scroll.appendChild(table);
            }
            scroll.tabIndex = 0;
            scroll.setAttribute('role', 'region');
            if (!scroll.hasAttribute('aria-label')) scroll.setAttribute('aria-label', 'Tabela de dados');
            if (table.hasAttribute('data-f3-paginado') || table.querySelector('input, select, textarea, button:not([data-f3m-copy])')) return;
            const rows = Array.from(table.tBodies[0]?.rows || []);
            if (rows.length <= 20) return;
            table.setAttribute('data-f3-paginado', 'cliente');
            const tools = document.createElement('div');
            tools.className = 'f3-list-tools';
            const label = document.createElement('label');
            label.textContent = 'Buscar nesta tabela ';
            const field = document.createElement('input');
            field.type = 'search';
            field.id = 'f3base-busca-tabela-' + (++tableIndex);
            label.htmlFor = field.id;
            label.append(field);
            const count = document.createElement('span');
            count.className = 'f3-list-total';
            count.setAttribute('aria-live', 'polite');
            const back = document.createElement('button');
            const next = document.createElement('button');
            back.type = next.type = 'button';
            back.className = next.className = 'button';
            back.textContent = 'Anterior'; next.textContent = 'Próxima';
            let page = 0;
            function update() {
                const query = field.value.trim().toLocaleLowerCase();
                const found = rows.filter(row => row.textContent.toLocaleLowerCase().includes(query));
                page = Math.max(0, Math.min(page, Math.ceil(found.length / 20) - 1));
                const visible = new Set(found.slice(page * 20, (page + 1) * 20));
                rows.forEach(row => { row.hidden = !visible.has(row); });
                count.textContent = found.length ? (page * 20 + 1) + '–' + Math.min((page + 1) * 20, found.length) + ' de ' + found.length : '0 resultados';
                back.hidden = next.hidden = found.length <= 20;
                back.disabled = page === 0;
                next.disabled = (page + 1) * 20 >= found.length;
            }
            field.addEventListener('input', () => { page = 0; update(); });
            back.addEventListener('click', () => { page--; update(); });
            next.addEventListener('click', () => { page++; update(); });
            tools.append(label, count, back, next);
            scroll.before(tools); update();
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => prepare()); else prepare();
    document.addEventListener('f3base-acessos-atualizados', event => {
        if (event.target instanceof Element && event.target.closest('.f3-ui')) prepare(event.target);
    });
})();
