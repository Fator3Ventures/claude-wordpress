# Validação — 0.17.0

Escopo: pedidos 33–35. Base Google 0.16.0. WordPress 7.1.2/PHP 8.3.6/MySQL 8.0.46; Core 1.46.1 e MCP 0.25.0 fornecidos, Meta/LinkedIn 0.4.1 como sentinelas no upgrade.

`tools/release017.py` verifica inventário, lint, contratos, documentação, rótulos e cenários nativos: limpo, upgrade 0.16 com rollback/reaplicação, Google ativado primeiro e isolado. Transporte MCP HTTP real local; Google simulado. Testes verificam erro inicial, diagnóstico, incidente, auditoria, cron sem prova anterior, alteração de autorização, preservação por destino e confirmação assíncrona pelo Core fornecido. Evidência corrente: evidence/017. O relatório externo contém contagens e limites efetivos.

Não corresponde à reexecução do gate integral histórico PHPUnit/tools/validate.py. Não comprova propagação real na Data Manager, atribuição comercial, dois dias reais de renovação, multisite ou PHP-FPM. A validação inicial usa validateOnly e não coleta conversões.
