# ADR 001 — Repositório e executor de tarefas

Revisão 0.17.0: vínculo de destino Core 1.41 incorporado; estrutura de fila e fechamento preservadas. Evidência corrente: `evidence/015` e relatório externo.

Atualização 0.14.0: base direta Google 0.13.0; adaptador Core de entrega 1.0.0 e leitura de transporte negociada 1.1.0, sem fila Google paralela. Prontidão é por conexão e exige verificação; resultado incerto não permite repetição automática. Evidências correntes e limites no relatório 0.14.0; as seções versionadas anteriores abaixo são históricas.

Decisão vigente na **0.13.0**: manter o repositório próprio indexado e o worker compartilhado por MCP, WP-Cron e WP-CLI.

A tabela `{prefix}f3_google_records` usa metadados indexados, proprietário/geração da lease, confirmação por leitura e commits transacionais de resultado/cursor. A tabela `{prefix}f3_google_cron` mantém passagens/incidentes e projeções por origem. Limites cooperativos e cursores controlam manutenção e histórico.

A instalação limpa cria diretamente o schema atual; a atualização utiliza os registros da 0.12.0. Não existem fases históricas de cópia/verificação ou fallback de registros em options. As proteções correntes — recuperação fora do banco, drenagem, contexto, geração, orçamento, lease e validação da intenção — permanecem.

A reconciliação de um evento terminal cujo resumo ainda não foi gravado é necessária no funcionamento atual. Ela preserva o resultado sem repetir o job nem a chamada Google. Escrita despachada sem conclusão confirmada permanece `unknown` e requer consulta/reconciliação do destino.

O custo da decisão é manter schema, SQL, concorrência e recuperação. A suíte nativa verifica WordPress e MySQL reais; o dublê unitário não demonstra a semântica transacional do servidor. Não há promessa de execução remota exatamente uma vez. Nenhuma tabela ou ação de outro plugin é apagada.

Action Scheduler foi avaliado em uma release anterior; não integra o runtime e não é uma dependência desta bancada. O leitor PHP GSC continua independente da fila: uma consulta do Core não fabrica passagem cron Google.
