# Fechamento documental — 0.17.0

Documentação instalada compilada de fontes editáveis; 286 habilidades e 36 opções preservadas. O catálogo português em docs/labels-pt-br.json compila para Ability.php, sem novo arquivo de runtime. Inventário igual ao da base: rollback não deixa arquivos novos.

O instalador entregue é o mesmo candidato testado. O relatório externo é canônico e contém o hash do fonte. A cópia interna precede o ZIP fonte. Evidências de outras versões são históricas. Nenhum documento de impacto ao Core é necessário: Core 1.46.1 fornecido já implementa a reconciliação pública utilizada.
