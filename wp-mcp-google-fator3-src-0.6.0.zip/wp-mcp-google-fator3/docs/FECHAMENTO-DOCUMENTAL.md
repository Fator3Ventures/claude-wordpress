# Matriz de entrega — 0.6.0

Esta matriz liga a implementação ao plano integral e aos oito pedidos adicionais. A orientação de 30/09 substitui as dependências do manual indisponível: perfis são genéricos, explícitos e versionados. Nenhuma configuração particular de agência é inventada ou aplicada automaticamente.

O instalador e os fontes pertencem à mesma versão. Os nomes dos testes abaixo são arquivos em `tests/`; as sondas nativas ficam em `integration/` na raiz do pacote-fonte. Resultados e limites estão em [VALIDACAO.md](VALIDACAO.md).

| Frente | Implementação entregue | Evidência principal |
|---|---|---|
| M0 | Base 0.4.0, build reproduzível, dependências de desenvolvimento fixadas, laboratório nativo e decisão do executor | `composer.lock`, inventários, [ADR 001](ADR-001-FILA.md), `performance.php` |
| A1 | Classificação central de 627 métodos/versões; consultas POST; recusa de wildcard de escrita e de método desconhecido | `NextFoundationTest`, `GenericTest`, `ResourcePolicyTest` |
| A2 | Contexto congelado, identidade, ator, destinos, revisão e idempotência; mudança de defaults não redireciona trabalho | `QueueIntentTest`, `JobApprovalTest`, `concurrency-mysql.php` |
| A3 | Efeito remoto separado do sucesso de execução; continuação após criação vinculada; reconciliação de escrita incerta | `BlendSheetsTest`, `HistoryAndOutcomeTest`, `concurrency-mysql.php` |
| A4 | Contrato de execução 2.0.0, erros estruturados, selftest e adaptador MCP com `isError` | `ReleaseContractsTest`, `mcp-channel.php` |
| A5 | Preparação, token de uso único, intenção/ator/site/contexto vinculados e diário antes do envio | `NextFoundationTest`, `JobApprovalTest`, `concurrency-mysql.php` |
| A6 | Allowlist de runtime, 16 índices, ausência de docs/referências públicas, sem `.htaccess`; lifecycle com segredo sempre removido na desinstalação | `build/build.py`, `package-http.py`, `upgrader-mysql.php`, `uninstall-multisite.php` |
| A7 | 280 habilidades registradas, versão em todas, catálogo consultável e estado local sem consultas Google implícitas | `documentation.php`, `OperationalStateTest`, `mcp-channel.php` |
| A8 | Oito pedidos conciliados na tabela abaixo | Guias, contratos e evidências das respectivas frentes |
| B1 | Service Account padrão, credencial candidata cifrada, promoção validada e ativa preservada em falha | `UxConfigurationTest`, `ConfigurationTest`, `ReleaseContractsTest` |
| B2 | Repositório indexado, migração em lotes e verificação antes da troca; origem preservada | `repository-mysql.php`, `migration-failures.php`, [Migração](MIGRACAO.md) |
| B3 | Worker com prazo e limite por passagem, concorrência, cota por tentativa, itens/resultados separados e limpeza retomável | `QueueIntentTest`, `SiteWorkflowTest`, `concurrency-mysql.php`, `executor-scope.php` |
| B4 | Painel de operações, filtros, resumo legível, alvos, cancelamento, reconciliação e agendas; JSON recolhível | `admin-forms.php`, `browser.mjs`, `HistoryAndOutcomeTest` |
| B5 | Revisão por leitura agrupada, cache por contexto e inicialização sem hidratar jobs | `performance.php`, `OperationalStateTest` |
| B6 | Executor comum, `executar-vencidos`, WP-CLI com usuário explícito e consulta genérica somente leitura | `cli-mysql.php`, `executor-scope.php`, `GenericTest` |
| B7 | Leitura optativa do Measurement ID do Core; descoberta completa e única; bindings e default coerentes | `ReviewCoreTest`, `UpdateCoreTest`, [Guia](GUIA-0.6.0.md) |
| B8 | Perfil configurável/versionado, diff, retenção primeiro, grafia exata e leitura de conformidade | `GenericProfileTest`, `GAAdminTest`, [Schema](profile-schema.json) |
| B9 | Auditoria indexada, hash/marcador exclusivo e ambiguidade, revisão/cursor, lacunas, falha observável, exportação JSON/CSV e escrita Sheets separada | `audit-markers.php`, `audit-performance.php`, `repository-mysql.php`, `HistoryAndOutcomeTest` |
| B10 | Status agregado, observações de APIs/cotas, contadores locais e modelos de relatório autodescritivos | `OperationalStateTest`, `ReleaseContractsTest`, [Modelos](report-templates.json) |
| C1 | Política por recurso/operação, prévia de impacto, cobertura do executor genérico e escritas compostas | `ResourcePolicyTest`, `ReviewCoreTest` |
| C2 | Modelos portáteis sem segredos, parâmetros, plano e revisão; sem ativar credencial ou alertas | `ReleaseContractsTest`, `admin-forms.php` |
| C3 | Alertas optativos, registro/e-mail separados, recuperação, intervalo e bloqueio de reenvio incerto | `OperationalStateTest`, `ReleaseContractsTest`, `repository-mysql.php` |
| C4 | Classes separadas para apresentação, credenciais, armazenamento e execução; contrato derivado; WPCS/PHPCompatibility | `phpcs.xml.dist`, `composer.lock`, `documentation.php`, catálogo gerado |
| C5 | Preparação GSC, inspeção imediata/fila e conferência de migração com destinos públicos protegidos | `SiteWorkflowTest`, `public-transport.php`, `EmptyPutTest` |
| C6 | Atualizador nativo, origem optativa, HTTPS/host/hash/versão/compatibilidade e substituição do pacote antigo | `UpgradeTest`, `upgrader-mysql.php`, `package-http.py` |

## Oito pedidos adicionais

| Pedido | Resultado na 0.6.0 |
|---|---|
| 1. Fechamento do pacote | Documentação e referências acompanham os fontes, fora do runtime público. Script revisado disponível por download autenticado. Todas as 16 pastas do instalador contêm `index.php`. |
| 2. `ga/aplicar-perfil` | Perfil como dado validado, sem criar propriedade; retenção primeiro e somente diferenças. `method` e acentos são aceitos; o administrador define as dimensões/métrica. Inclui `ga/list-custom-dimensions`. |
| 3. `ga/conformidade` | Leitura com diff, `auth.configured`, `data_streams` e `streamEnabled`. O 403 de `accessBindings` não reprova todo o diagnóstico nem é usado para presumir o papel Editor. |
| 4. Vínculo Core | `vincular_site_core:true` em planejamento/configuração lê a opção do Core, resolve os recursos e grava bindings/default. Integração optativa para manter o plugin genérico. |
| 5. GSC | `gsc/preparar-site` e `gsc/migracao-conferir`, com parâmetros explícitos, pendências e resultados por etapa. Sem dependência dos parágrafos do manual indisponível. |
| 6. Vencidos | `google/executar-vencidos`, WP-CLI e `google/status.cron.agendas_vencidas`; mesmo worker, sem depender de visitas para execução explícita. |
| 7. Metadados | `meta.fator3.version:0.6.0` em todas as 280 habilidades, incluindo as 132 da base. |
| 8. Auditoria | `desde_revisao`, filtros/cursor, exportação local paginada e exportação Sheets como escrita própria confirmada. |

## Implantação posterior à entrega

O pacote não atualiza a frota, concede acessos Google, envia e-mail real ou escolhe a origem de distribuição por conta própria. Inventário de produção, permissões reais, piloto e lotes usam o mesmo artefato validado. PHP 8.0/WordPress 6.4 permanecem pisos declarados; a execução nativa deste laboratório ocorreu em PHP 8.3/WordPress 7.1, sem afirmar que todas as combinações foram ensaiadas.

## Pedidos adicionais 8–11

| Pedido | Entrega 0.6.0 | Prova |
|---|---|---|
| 8 | Importação diária final por página/dia, replay de três dias, retomada e estado no status | `integration/daily-core.php`, Core 1.18.0 real, Google simulado |
| 9 | Provedor/contrato do canal, perfil na bridge e alvo, atualizadores coordenados | `integration/channel-013.php`, `updater-channel-013.php` |
| 10 | Barreira de migração antes do despacho; auditoria de chamada admitida antes da cópia; saúde recuperada com lacuna preservada | `integration/migration-admission.php`, dois processos e MySQL real |
| 11 | 106 métodos GTM, rotas tipadas, publicação/reversão com diário e diagnóstico | `tests/NextReleaseTest.php`; sem publicação em contêiner Google real |

A implementação não usa IDs de frota nem depende de um padrão externo. A homologação dos aceites em fator3/korvena/contêiner de teste real permanece uma etapa de implantação autorizada pelo responsável.
