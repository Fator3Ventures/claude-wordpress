# ADR 001 — Repositório e executor de tarefas

Data: 01/10/2026. Versão: 0.6.0. Decisão: manter repositório próprio indexado e um worker compartilhado por MCP, WP-Cron e WP-CLI.

## Contexto

A 0.4.0 guardava tarefas e resultados em opções. A evolução exige contexto imutável, confirmação de intenção, estado `unknown` para escrita interrompida, reconciliação explícita, migração retomável e resultados paginados. Claims impedem trabalhadores simultâneos; não garantem uma única execução remota diante de uma falha entre o Google e o commit local.

## Experimento

Foi instalado Action Scheduler 4.2.0 como dependência exclusiva do laboratório, com licença GPLv3 e requisito declarado WordPress 6.9. O plugin mantém piso WordPress 6.4 com polyfill de Abilities compatível. O Action Scheduler não integra o instalador nem suas dependências de execução.

No WordPress 7.1/MySQL 8.0.46, o experimento gravou 50 ações, verificou claims de dez ações sem sobreposição, liberação/retomada, início/conclusão e limpeza de um grupo preservando o de outro consumidor. Seus estados nativos são `pending`, `in-progress`, `complete`, `failed` e `canceled`; `blocked` e `unknown` exigiriam estado adicional do plugin.

O experimento de armazenamento observou 104 consultas para admitir 50 ações no Action Scheduler e 50 no repositório próprio. Esses números comparam primitivas de armazenamento, não workers equivalentes com todas as funcionalidades. Tempos e memória são medidas de uma fixture local, disponíveis na evidência, sem promessa de desempenho em produção. Não foi ensaiada a negociação entre duas versões diferentes da biblioteca; a preservação de outro consumidor foi ensaiada por grupo.

## Decisão e consequências

Adotar a tabela `{prefixo}f3_google_records`, com consultas de metadados, leases com proprietário/geração, commits transacionais de resultado/cursor, registros independentes e limpeza limitada. A migração, confirmação e recuperação ficam no mesmo modelo de dados, preservando as opções de origem até a verificação.

O custo é manter schema, consultas, migração, concorrência e recuperação no plugin. A suíte inclui falhas reais de SQL, corrupção, interrupção de processos, disputa entre executores e persistência nativa. O Action Scheduler continua sendo uma alternativa para revisão futura; não existe uma cópia privada dele a atualizar no runtime.

Não prometer execução remota exatamente uma vez: leituras abandonadas podem retomar; escritas despachadas sem conclusão ficam incertas e requerem consulta ao destino. Nenhuma tabela ou ação de outro plugin é apagada.

Evidências no pacote-fonte: `integration/scheduler-comparison.php`, `evidence/scheduler-comparison-final.txt`, `evidence/concurrency-mysql-final.txt` e `evidence/repository-mysql-final.txt`, relativos à raiz do pacote-fonte.
