# Catálogo de habilidades — 0.6.0

Gerado por `build/export-contracts.php`. 280 habilidades: 107 de leitura e 173 de escrita. A disponibilidade depende da conexão e é revalidada na execução.

| Habilidade | Modo | Descrição |
|---|---|---|
| `ads/add-audience-to-campaign` | write | Aplica add-audience-to-campaign via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/add-keywords` | write | Aplica add-keywords via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/add-label` | write | Aplica add-label via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/add-negative-keywords` | write | Aplica add-negative-keywords via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/apply-label` | write | Aplica apply-label via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-ad-group` | write | Aplica create-ad-group via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-asset` | write | Aplica create-asset via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-asset-group` | write | Aplica create-asset-group via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-billing-setup` | write | Aplica create-billing-setup via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. Este método não aceita validateOnly: dry_run=true é recusado antes da gravação. |
| `ads/create-budget` | write | Aplica create-budget via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-campaign` | write | Aplica create-campaign via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-conversion-action` | write | Aplica create-conversion-action via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-experiment` | write | Aplica create-experiment via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-responsive-search-ad` | write | Aplica create-responsive-search-ad via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-user-list` | write | Aplica create-user-list via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/get-campaign` | read | Consulta GAQL de leitura de campaign, com paginação e limite explícitos. |
| `ads/get-customer` | read | Detalhes de uma única conta do Google Ads: nome, moeda, fuso horário, status e se é gerenciadora (MCC) ou de teste. |
| `ads/get-resource-metadata` | read | Descobre quais campos um recurso GAQL aceita: selecionáveis, filtráveis, ordenáveis, e quais métricas/segmentos combinam com ele. Use sempre antes de montar uma consulta em ads/search — não chute nomes de campo. A resposta fica em cache por 24 horas. |
| `ads/invite-user` | write | Aplica invite-user via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. Este método não aceita validateOnly: dry_run=true é recusado antes da gravação. |
| `ads/link-asset` | write | Aplica link-asset via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/list-accessible-customers` | read | Lista os IDs de cliente do Google Ads acessíveis pela credencial configurada. Use antes de qualquer outra rota quando não souber o customer_id. Com with_details (padrão), também traz nome, moeda, fuso e se cada conta é gerenciadora (MCC) ou de teste. |
| `ads/list-assets` | read | Consulta GAQL de leitura de asset, com paginação e limite explícitos. |
| `ads/list-audiences` | read | Consulta GAQL de leitura de audience, com paginação e limite explícitos. |
| `ads/list-conversion-actions` | read | Consulta GAQL de leitura de conversion_action, com paginação e limite explícitos. |
| `ads/list-customer-clients` | read | Lista as contas-cliente sob uma conta gerenciadora (MCC) do Google Ads: id, nome, nível na hierarquia, se também é gerenciadora, status, moeda, fuso e se está oculta. |
| `ads/list-experiments` | read | Consulta GAQL de leitura de experiment, com paginação e limite explícitos. |
| `ads/list-resources` | read | Lista os recursos GAQL válidos (campaign, ad_group, search_term_view, etc.), filtrando por um trecho do nome. Use para descobrir o recurso certo antes de chamar get-resource-metadata ou search. |
| `ads/list-users` | read | Consulta GAQL de leitura de customer_user_access, com paginação e limite explícitos. |
| `ads/mutate` | write | Executa googleAds:mutate com mutateOperations oficiais, inclusive operações de serviços combinados e IDs temporários negativos. operations usa a estrutura MutateOperation da API. dry_run envia validateOnly; partial_failure preserva resultados e erros individuais. Para serviços ausentes de MutateOperation, use google/execute-action. |
| `ads/remove-ad` | write | Aplica remove-ad via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-ad-group` | write | Aplica remove-ad-group via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-campaign` | write | Aplica remove-campaign via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-keywords` | write | Aplica remove-keywords via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-negative-keywords` | write | Aplica remove-negative-keywords via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-user` | write | Aplica remove-user via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. Este método não aceita validateOnly: dry_run=true é recusado antes da gravação. |
| `ads/schedule-experiment` | write | Agenda um experimento já criado com braços e datas configurados. Retorna a operação assíncrona da Google. dry_run usa validateOnly. |
| `ads/search` | read | Executa uma consulta GAQL de leitura contra a Google Ads API, com paginação automática até o teto de linhas configurado. Informe "query" pronta OU "resource" + "fields" para montar a consulta. Sempre devolve a consulta final usada, mesmo em erro. |
| `ads/update-ad-group` | write | Aplica update-ad-group via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-ad-status` | write | Aplica update-ad-status via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-budget` | write | Aplica update-budget via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-campaign` | write | Aplica update-campaign via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-conversion-action` | write | Aplica update-conversion-action via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-keyword` | write | Aplica update-keyword via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-user-access` | write | Aplica update-user-access via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. Este método não aceita validateOnly: dry_run=true é recusado antes da gravação. |
| `ads/upload-click-conversions` | write | Envia ClickConversion para a conta selecionada. A API exige partialFailure=true; erros por conversão ficam explícitos na resposta. dry_run usa validateOnly. |
| `ads/upload-customer-match` | write | Executa create → addOperations → run de OfflineUserDataJob, com SHA-256 e retorno da operação assíncrona. Disponível para integrações Ads elegíveis existentes; desde abril de 2026 a Google exige Data Manager API para a maioria das novas integrações. dry_run precisa de job_resource_name existente e valida cada chamada sem criar/executar o job. |
| `ga/add-user` | write | Executa analyticsadmin.properties.accessBindings.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"user":"pessoa@empresa.com","roles":["predefinedRoles/editor"]}. roles vazia remove o vínculo na atualização. Requer analytics.manage.users e papel de administrador. |
| `ga/aplicar-perfil` | write | Simula por padrão. Aplica diferenças com retenção primeiro, sem criar propriedade nem remover definições extras. Exige hash da simulação ao aplicar. |
| `ga/archive-audience` | write | Executa analyticsadmin.properties.audiences.archive na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Criação: displayName, description, membershipDurationDays e filterClauses oficiais. Atualização: campos permitidos pela API, como displayName/description/eventTrigger. |
| `ga/archive-custom-dimension` | write | Executa analyticsadmin.properties.customDimensions.archive na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parameterName":"lead_type","displayName":"Tipo de lead","scope":"EVENT"}. |
| `ga/archive-custom-metric` | write | Executa analyticsadmin.properties.customMetrics.archive na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parameterName":"lead_score","displayName":"Pontuação","scope":"EVENT","measurementUnit":"STANDARD"}. |
| `ga/check-compatibility` | read | Verifica se uma combinação de dimensões, métricas e filtros é válida no GA4 antes de gastar cota com run-report. Params: property_id (opcional), dimensions (required), metrics (required), dimension_filter, metric_filter, compatibility_filter, format (opcionais). |
| `ga/conformidade` | read | Compara perfil configurável com propriedade existente. Só leitura. Retorna diff, auth.configured, streams e streamEnabled sem impor valores omitidos. |
| `ga/create-annotation` | write | Executa analyticsadmin.properties.reportingDataAnnotations.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"title":"Lançamento","color":"BLUE","annotationDate":{"year":2026,"month":9,"day":8}}; admite annotationDateRange em vez de annotationDate. |
| `ga/create-audience` | write | Executa analyticsadmin.properties.audiences.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Criação: displayName, description, membershipDurationDays e filterClauses oficiais. Atualização: campos permitidos pela API, como displayName/description/eventTrigger. |
| `ga/create-custom-dimension` | write | Executa analyticsadmin.properties.customDimensions.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parameterName":"lead_type","displayName":"Tipo de lead","scope":"EVENT"}. |
| `ga/create-custom-metric` | write | Executa analyticsadmin.properties.customMetrics.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parameterName":"lead_score","displayName":"Pontuação","scope":"EVENT","measurementUnit":"STANDARD"}. |
| `ga/create-google-ads-link` | write | Executa analyticsadmin.properties.googleAdsLinks.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"customerId":"1234567890","adsPersonalizationEnabled":true}. Requer os papéis correspondentes também no Google Ads. |
| `ga/create-key-event` | write | Executa analyticsadmin.properties.keyEvents.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"eventName":"generate_lead","countingMethod":"ONCE_PER_EVENT"}; atualizações aceitam countingMethod e defaultValue. |
| `ga/create-mp-secret` | write | Executa analyticsadmin.properties.dataStreams.measurementProtocolSecrets.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Servidor"}. secretValue só sai no retorno da criação; não é persistido pelo plugin. |
| `ga/create-property` | write | Executa analyticsadmin.properties.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parent":"accounts/123","displayName":"Site","timeZone":"America/Sao_Paulo","currencyCode":"BRL"}. |
| `ga/create-web-stream` | write | Executa analyticsadmin.properties.dataStreams.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Site","webStreamData":{"defaultUri":"https://seu-site"}}. A criação fixa type=WEB_DATA_STREAM. |
| `ga/delete-account` | write | Executa analyticsadmin.accounts.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Provisionamento: {"account":{"displayName":"Empresa","regionCode":"BR"},"redirectUri":"https://seu-site/retorno"}. redirectUri precisa estar registrado no projeto OAuth. |
| `ga/delete-annotation` | write | Executa analyticsadmin.properties.reportingDataAnnotations.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"title":"Lançamento","color":"BLUE","annotationDate":{"year":2026,"month":9,"day":8}}; admite annotationDateRange em vez de annotationDate. |
| `ga/delete-google-ads-link` | write | Executa analyticsadmin.properties.googleAdsLinks.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"customerId":"1234567890","adsPersonalizationEnabled":true}. Requer os papéis correspondentes também no Google Ads. |
| `ga/delete-key-event` | write | Executa analyticsadmin.properties.keyEvents.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"eventName":"generate_lead","countingMethod":"ONCE_PER_EVENT"}; atualizações aceitam countingMethod e defaultValue. |
| `ga/delete-mp-secret` | write | Executa analyticsadmin.properties.dataStreams.measurementProtocolSecrets.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Servidor"}. secretValue só sai no retorno da criação; não é persistido pelo plugin. |
| `ga/delete-property` | write | Executa analyticsadmin.properties.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parent":"accounts/123","displayName":"Site","timeZone":"America/Sao_Paulo","currencyCode":"BRL"}. |
| `ga/delete-web-stream` | write | Executa analyticsadmin.properties.dataStreams.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Site","webStreamData":{"defaultUri":"https://seu-site"}}. A criação fixa type=WEB_DATA_STREAM. |
| `ga/get-account-summaries` | read | Lista todas as contas e propriedades do Google Analytics 4 acessíveis pela credencial configurada (Admin API, com paginação seguida até o fim). Sem parâmetros. |
| `ga/get-metadata` | read | Lista as dimensões e métricas disponíveis para relatórios GA4: catálogo universal (sem property_id/padrão) ou catálogo de uma propriedade, com as customizadas. Use antes de run-report para achar nomes válidos. Params: property_id (opcional), custom_only (opcional, padrão true), query (opcional, filtra por nome/descrição). |
| `ga/get-property-details` | read | Devolve os detalhes de uma propriedade GA4: nome de exibição, fuso horário, moeda, categoria do setor e datas de criação/atualização. Params: property_id (opcional; usa a propriedade padrão configurada em Ferramentas > MCP Google quando ausente). |
| `ga/get-settings` | read | Retorna propriedade, conta, retenção, atribuição, Google Signals, streams e medição avançada, eventos-chave, dimensões, métricas, anotações, públicos, vínculos Ads, usuários e metadados de segredos MP. Segredos são mascarados. Erros parciais ficam explícitos em errors; paginação completa ou truncamento informado. |
| `ga/list-custom-dimensions` | read | Lista as dimensões da propriedade existente com paginação completa. Não modifica nomes ou definições. |
| `ga/list-google-ads-links` | read | Lista os vínculos entre uma propriedade GA4 e contas do Google Ads (Admin API, com paginação seguida até o fim). Params: property_id (opcional; usa a propriedade padrão). |
| `ga/list-profiles` | read | Lista perfis configuráveis da conexão, sem consultas ao Google. |
| `ga/list-property-annotations` | read | Lista as anotações de uma propriedade GA4 — notas sobre lançamentos, campanhas de marketing ou variações de tráfego, marcadas em datas ou períodos específicos (Admin API v1alpha). Params: property_id (opcional; usa a propriedade padrão). |
| `ga/list-users` | read | Lista accessBindings de parent=accounts/123 ou properties/123; property_id usa a propriedade padrão. Inclui todas as páginas, com limite explícito e token de continuação. |
| `ga/profile-schema` | read | Schema versionado de perfis configuráveis. Não inclui padrões de agência. |
| `ga/provision-account` | write | Gera um ticket de criação de conta GA4 e a URL oficial dos termos. A conta só será criada quando uma pessoa aceitar os termos nessa URL. |
| `ga/remove-user` | write | Executa analyticsadmin.properties.accessBindings.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"user":"pessoa@empresa.com","roles":["predefinedRoles/editor"]}. roles vazia remove o vínculo na atualização. Requer analytics.manage.users e papel de administrador. |
| `ga/run-conversions-report` | read | Executa um relatório de conversões, custo de anúncio e ROAS do GA4 (v1alpha runReport com conversionSpec). Use no lugar de run-report para conversões/anúncio. Params: date_ranges, dimensions, metrics, conversion_spec (required); property_id, dimension_filter, metric_filter, order_bys, limit, offset, currency_code, return_property_quota, format (opcionais). |
| `ga/run-funnel-report` | read | Executa um relatório de funil GA4 (v1alpha runFunnelReport): progressão dos usuários por uma sequência de passos, com desdobramento e próxima ação opcionais. Sem date_ranges, usa os últimos 30 dias. Params: property_id (opcional), funnel_steps (required), date_ranges, funnel_breakdown, funnel_next_action, segments, return_property_quota, format (opcionais; padrão raw). |
| `ga/run-realtime-report` | read | Executa um relatório em tempo real do GA4 (últimos ~30 minutos de atividade). Só aceita dimensões/métricas realtime — sem métricas customizadas. Params: property_id (opcional), dimensions (required), metrics (required), dimension_filter, metric_filter, order_bys, limit, offset, minute_ranges, return_property_quota, format (opcionais). |
| `ga/run-report` | read | Executa um relatório GA4 (Data API runReport): dimensões, métricas, filtros, ordenação e período livres. Ver a description de cada parâmetro para exemplos de JSON. Params: date_ranges, dimensions, metrics (required); property_id, dimension_filter, metric_filter, order_bys, limit, offset, currency_code, keep_empty_rows, return_property_quota, format (opcionais). |
| `ga/save-profile` | write | Salva definição local versionada; não altera Google. expected_revision evita sobrescrever outro editor. |
| `ga/send-event` | write | Envia até 25 eventos de um web stream ao Measurement Protocol. debug=true usa somente /debug/mp/collect: valida o payload e não coleta eventos. A validação não confirma api_secret. Em produção, HTTP 2xx confirma recebimento HTTP, sem garantir processamento/inclusão nos relatórios. O segredo não é persistido. |
| `ga/update-annotation` | write | Executa analyticsadmin.properties.reportingDataAnnotations.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"title":"Lançamento","color":"BLUE","annotationDate":{"year":2026,"month":9,"day":8}}; admite annotationDateRange em vez de annotationDate. |
| `ga/update-attribution` | write | Executa analyticsadmin.properties.updateAttributionSettings na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"reportingAttributionModel":"PAID_AND_ORGANIC_CHANNELS_DATA_DRIVEN"}. |
| `ga/update-audience` | write | Executa analyticsadmin.properties.audiences.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Criação: displayName, description, membershipDurationDays e filterClauses oficiais. Atualização: campos permitidos pela API, como displayName/description/eventTrigger. |
| `ga/update-data-retention` | write | Executa analyticsadmin.properties.updateDataRetentionSettings na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"eventDataRetention":"FOURTEEN_MONTHS","resetUserDataOnNewActivity":true}. |
| `ga/update-enhanced-measurement` | write | Executa analyticsadmin.properties.dataStreams.updateEnhancedMeasurementSettings na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"streamEnabled":true,"scrollsEnabled":true,"outboundClicksEnabled":true}. |
| `ga/update-google-signals` | write | Executa analyticsadmin.properties.updateGoogleSignalsSettings na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"state":"GOOGLE_SIGNALS_ENABLED"}; o consentimento exigido pela Google continua aplicável. |
| `ga/update-key-event` | write | Executa analyticsadmin.properties.keyEvents.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"eventName":"generate_lead","countingMethod":"ONCE_PER_EVENT"}; atualizações aceitam countingMethod e defaultValue. |
| `ga/update-property` | write | Executa analyticsadmin.properties.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parent":"accounts/123","displayName":"Site","timeZone":"America/Sao_Paulo","currencyCode":"BRL"}. |
| `ga/update-user` | write | Executa analyticsadmin.properties.accessBindings.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"user":"pessoa@empresa.com","roles":["predefinedRoles/editor"]}. roles vazia remove o vínculo na atualização. Requer analytics.manage.users e papel de administrador. |
| `ga/update-web-stream` | write | Executa analyticsadmin.properties.dataStreams.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Site","webStreamData":{"defaultUri":"https://seu-site"}}. A criação fixa type=WEB_DATA_STREAM. |
| `google/ability-catalog` | read | Catálogo paginado do registro desta versão, com efeitos e schemas opcionais. Consulta local. |
| `google/alerts` | read | Consulta configuração e incidentes locais. Não envia mensagens. |
| `google/apply-template` | write | Valida, mapeia e compara modelo. Aplicação exige revisão e hash da prévia; usa gravação verificada e compensação. |
| `google/approve-job` | write | Vincula uma preparação a um único job de exportação. O token é consumido para delegação e não é armazenado nos parâmetros. |
| `google/audit` | read | Lê a auditoria local com filtros e retenção configurável. before/after refletem snapshots disponíveis e limitados; segredos e identificadores de Customer Match são removidos. |
| `google/audit-export` | read | Exportação paginada JSON ou CSV pela resposta autenticada. Sem arquivo público. CSV neutraliza fórmulas. Use next_cursor para completar a janela. |
| `google/audit-to-sheet` | write | Exporta até 100 eventos de uma janela fixada por export_cursor, com células literais e política do destino. Exige google/prepare-operation. Retorna próximo cursor e cobertura; não altera google/audit. |
| `google/blend` | read | Combina consultas GA4, Ads e Search Console por date, campaign ou page. Preserva linhas sem par e períodos comparados; recusa chaves duplicadas para não multiplicar métricas. |
| `google/cancel-job` | write | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/check-update` | read | Consulta somente a origem explicitamente configurada. Distingue ausência de atualização, incompatibilidade e falha de consulta. |
| `google/cleanup-jobs` | write | Remove detalhes encerrados após retenção; preserva deduplicação e resultados desconhecidos. |
| `google/configuration-schema` | read | Contrato versionado de opções, tipos, limites, dependências, operações e valores atuais. Segredos são sempre ocultos. Não consulta o Google. |
| `google/configure` | write | Planeja ou aplica configuração local verificada com serviços e recursos existentes; não cria propriedades Google. |
| `google/configure-alerts` | write | Ativa observação e e-mail mediante configuração explícita. Revalida intervalo e destinatários; a aceitação do envio não comprova entrega. |
| `google/configure-gsc-import` | write | Agenda diária de dados finais por página e dia. Reenvia os últimos três dias finais; exige importador Core e administrador. |
| `google/configure-local` | write | Auditar leituras locais e excluir dados públicos na desinstalação são optativos. Credenciais são sempre removidas na desinstalação. |
| `google/configure-policy` | write | Aplica a política após consultar o impacto por google/plan-policy. Exige revisão e hash da prévia; padrões não concedem acesso. |
| `google/configure-update-origin` | write | Define manifesto HTTPS e hosts confiáveis. Não publica pacote nem ativa atualização automática. |
| `google/create-connection` | write | Cria uma conexão local vazia para configuração no painel. |
| `google/create-job` | write | Enfileira tarefa persistente. Use idempotency_key para repetir o pedido sem duplicar. Escritas interrompidas não são repetidas. |
| `google/delete-job` | write | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/disconnect` | write | Remove tokens locais mantendo o cliente. revoke=true revoga também a autorização do usuário no projeto Google, afetando outros sites. |
| `google/executar-vencidos` | write | Executa agendas e tarefas elegíveis sem depender de visita ao site. Por padrão atua somente na conexão selecionada. Mesmo worker, autorização, prazo de 20 s e teto de 25 itens. |
| `google/execute-action` | write | Executa o id exato de google/list-actions usando parâmetros e corpo definidos no documento oficial. A URL é construída pelo plugin. Gravações são imediatas; dry_run só funciona quando o método aceita validateOnly. Audita estados disponíveis antes/depois. |
| `google/execute-read` | read | Executa apenas métodos classificados como consulta, incluindo POST de relatórios. Recusa mutações antes do envio. |
| `google/export-template` | read | Exporta somente serviços, vínculos, limites e política. Recursos parametrizados por padrão; nunca inclui credenciais ou alertas. |
| `google/export-to-sheet` | write | Executa query, blend ou queries e grava uma aba por relatório, substituindo valores ou anexando linhas. Células são literais, sem executar fórmulas. Aceita planilha compartilhada, Drive compartilhado ou criação via OAuth/delegação. |
| `google/get-job` | read | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/get-schedule` | read | Consulta parâmetros, estado e revisão de uma agenda da conexão, sem executá-la. |
| `google/gsc-import-status` | read | Consulta local da agenda e dos últimos dias conferidos e importados. |
| `google/list-accounts` | read | Lista, num formato só, as propriedades do GA4 e as contas do Google Ads que a credencial alcança. Use os account_id devolvidos em google/query. Cache de 10 minutos. Substitui o list_accounts do Porter. |
| `google/list-actions` | read | Lista os métodos das dez APIs Google a partir dos documentos oficiais, com cache de 24 h e paginação. task procura palavras no texto em inglês; o id completo identifica a execução. request_schema usa referências em schemas[api]. |
| `google/list-connections` | read | Lista conexões e vínculos sem segredos. |
| `google/list-fields` | read | Descobre as métricas e dimensões que google/query aceita num conector. No GA4 vem do catálogo da própria API (com as personalizadas da propriedade, se informada); no Google Ads vem do catálogo curado do plugin. Substitui o list_fields do Porter. |
| `google/list-jobs` | read | Resumos paginados por conexão, estado, tarefa e período de criação. Não carrega resultados dos jobs. |
| `google/mcp-read` | read | Executa exclusivamente habilidades classificadas como consulta; recusa mutações antes da execução. |
| `google/mcp-write` | write | Executa habilidades de mutação com os mesmos gates, políticas e confirmações. |
| `google/migrate-storage` | write | Copia e verifica um lote; preserva a origem. A fila permanece pausada até a verificação final. |
| `google/plan-configuration` | read | Planeja ou aplica configuração local verificada com serviços e recursos existentes; não cria propriedades Google. |
| `google/plan-policy` | read | Prévia local dos padrões excluídos e contextos pendentes invalidados pela mudança. Não altera permissões. |
| `google/plan-template` | read | Valida, mapeia e compara modelo. Aplicação exige revisão e hash da prévia; usa gravação verificada e compensação. |
| `google/policy-discover-resources` | read | Consulta administrativa dos recursos acessíveis à identidade. Exige manage_options e não concede acesso operacional. |
| `google/preflight` | read | Leituras reais por serviço e recurso. Distingue passed, failed, skipped e not_configured. |
| `google/prepare-job` | write | Calcula os efeitos da exportação persistida, sem escrita remota. Retorna confirmation_token para google/approve-job.approval_token. |
| `google/prepare-operation` | write | Calcula pedidos sem enviá-los e emite token vinculado de uso único. A preparação não atesta aprovação humana. |
| `google/query` | read | Relatório unificado de GA4, Google Ads ou Search Console: métricas por dimensão, num período, com filtros, ordenação e comparação com o período anterior. Devolve colunas e linhas posicionais. Substitui o query_data do Porter. |
| `google/reconcile-job` | write | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/report-templates` | read | Modelos disponíveis para relatórios e monitoramento. |
| `google/resource-policy` | read | Consulta a política da conexão e sua cobertura, sem segredos nem consultas externas. |
| `google/run-job` | write | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/run-report` | read | Executa modelo com período e comparação opcional. alert avalia queda numérica e não atribui causa. |
| `google/schedule-report` | write | Cria ou atualiza agenda de leituras. enabled=false pausa. Atualizações exigem a revisão de google/get-schedule. Resultados ficam em jobs, sem enviar notificações externas. |
| `google/selftest` | read | Roda a bateria de verificação do plugin sem sair para a rede: cifra dos segredos, assinatura JWT, lista de hosts, portão, presets de data, tradução de filtros, catálogo do Ads e montagem das consultas. Devolve passed, failed e o detalhe de cada checagem. |
| `google/status` | read | Diagnóstico da integração Google: canal aberto, conectores ligados, modo de autenticação e identidade da credencial, versão da Ads API, limites e rotas registradas. Nunca devolve segredo. Substitui whoami e list_connectors. |
| `google/storage-status` | read | Consulta local da migração e do armazenamento ativo. |
| `google/sync-gsc-core` | write | Executa uma página pendente da agenda autorizada; o cron e executar-vencidos usam a mesma operação. |
| `gsc/add-site` | write | Adiciona a propriedade à lista da credencial. A verificação de propriedade é separada. |
| `gsc/delete-site` | write | Remove a propriedade da lista da credencial; não exclui o site. |
| `gsc/delete-sitemap` | write | Remove um sitemap da lista da Search Console; não remove o arquivo do site. |
| `gsc/ensure-sitemap` | write | Confere o sitemap registrado, verifica publicação e envia se ausente. Retorna estado de processamento separado de indexação. |
| `gsc/get-site` | read | Obtém a permissão da credencial na propriedade. |
| `gsc/inspect-url` | read | Inspeciona a versão indexada de uma URL. Não solicita indexação. |
| `gsc/inspect-urls` | write | Persiste até 500 URLs. auto executa 1–5 URLs únicas na chamada; queued apenas enfileira. Compartilha worker, prazo e cota com cron e CLI. |
| `gsc/list-sitemaps` | read | Lista sitemaps enviados, opcionalmente filtrados por índice. |
| `gsc/list-sites` | read | Lista propriedades Search Console e suas permissões. |
| `gsc/migracao-conferir` | read | Somente leitura: pares origem/destino, redirects limitados, canônicas conhecidas, rastreamento e impressões. Não recomenda apagar redirects por ausência de dados. |
| `gsc/preparar-site` | write | Fluxo genérico com simulação por padrão: acesso, publicação/registro de sitemap, vínculo opcional e inspeções persistidas. Não altera DNS nem cria propriedade. |
| `gsc/query` | read | Consulta desempenho orgânico: métricas nativas, dimensões, filtros e paginação até 25.000 linhas. |
| `gsc/submit-sitemap` | write | Envia um sitemap à Search Console. |
| `gtm/bulk-update-workspace` | write | Applies multiple entity changes to a workspace in one call. When creating new entities, their entity IDs must be unique and in correct format. That is, they must start with "new_" and followed by number, e.g. "new_1", "new_2". Example body snippet to create myNewTag under myNewFolder is: ``` "changes": [ { "folder": { "folderId": "new_1", "name": "myNewFolder", ... }, "changeStatus": "added" }, { "tag": { "tagId": "new_2", "name": "myNewTag", "parentFolderId": "new_1", ... }, "changeStatus": "added" } ] ``` |
| `gtm/combine-container` | write | Combines Containers. |
| `gtm/create-built-in-variable` | write | Creates one or more GTM Built-In Variables. |
| `gtm/create-client` | write | Creates a GTM Client. |
| `gtm/create-container` | write | Creates a Container. |
| `gtm/create-environment` | write | Creates a GTM Environment. |
| `gtm/create-folder` | write | Creates a GTM Folder. |
| `gtm/create-gtag-config` | write | Creates a Google tag config. |
| `gtm/create-tag` | write | Creates a GTM Tag. |
| `gtm/create-template` | write | Creates a GTM Custom Template. |
| `gtm/create-transformation` | write | Creates a GTM Transformation. |
| `gtm/create-trigger` | write | Creates a GTM Trigger. |
| `gtm/create-user-permission` | write | Creates a user's Account & Container access. |
| `gtm/create-variable` | write | Creates a GTM Variable. |
| `gtm/create-version-workspace` | write | Creates a Container Version from the entities present in the workspace, deletes the workspace, and sets the base container version to the newly created version. |
| `gtm/create-workspace` | write | Creates a Workspace. |
| `gtm/create-zone` | write | Creates a GTM Zone. |
| `gtm/delete-built-in-variable` | write | Deletes one or more GTM Built-In Variables. |
| `gtm/delete-client` | write | Deletes a GTM Client. |
| `gtm/delete-container` | write | Deletes a Container. |
| `gtm/delete-environment` | write | Deletes a GTM Environment. |
| `gtm/delete-folder` | write | Deletes a GTM Folder. |
| `gtm/delete-gtag-config` | write | Deletes a Google tag config. |
| `gtm/delete-tag` | write | Deletes a GTM Tag. |
| `gtm/delete-template` | write | Deletes a GTM Template. |
| `gtm/delete-transformation` | write | Deletes a GTM Transformation. |
| `gtm/delete-trigger` | write | Deletes a GTM Trigger. |
| `gtm/delete-user-permission` | write | Removes a user from the account, revoking access to it and all of its containers. |
| `gtm/delete-variable` | write | Deletes a GTM Variable. |
| `gtm/delete-version` | write | Deletes a Container Version. |
| `gtm/delete-workspace` | write | Deletes a Workspace. |
| `gtm/delete-zone` | write | Deletes a GTM Zone. |
| `gtm/diagnostico` | read | Compara os IDs do contêiner publicado com os slots locais do Core e identifica configuração de consentimento. Conteúdo dinâmico é reportado como inconclusivo. |
| `gtm/entities-folder` | read | List all entities in a GTM Folder. |
| `gtm/get-account` | read | Gets a GTM Account. |
| `gtm/get-client` | read | Gets a GTM Client. |
| `gtm/get-container` | read | Gets a Container. |
| `gtm/get-destination` | read | Gets a Destination. |
| `gtm/get-environment` | read | Gets a GTM Environment. |
| `gtm/get-folder` | read | Gets a GTM Folder. |
| `gtm/get-gtag-config` | read | Gets a Google tag config. |
| `gtm/get-publication` | read | Consulta local do diário, sem repetir escritas. |
| `gtm/get-status-workspace` | read | Finds conflicting and modified entities in the workspace. |
| `gtm/get-tag` | read | Gets a GTM Tag. |
| `gtm/get-template` | read | Gets a GTM Template. |
| `gtm/get-transformation` | read | Gets a GTM Transformation. |
| `gtm/get-trigger` | read | Gets a GTM Trigger. |
| `gtm/get-user-permission` | read | Gets a user's Account & Container access. |
| `gtm/get-variable` | read | Gets a GTM Variable. |
| `gtm/get-version` | read | Gets a Container Version. |
| `gtm/get-workspace` | read | Gets a Workspace. |
| `gtm/get-zone` | read | Gets a GTM Zone. |
| `gtm/import-from-gallery-template` | write | Imports a GTM Custom Template from Gallery. |
| `gtm/latest-version-header` | read | Gets the latest container version header |
| `gtm/link-destination` | write | Adds a Destination to this Container and removes it from the Container to which it is currently linked. |
| `gtm/list-accounts` | read | Lists all GTM Accounts that a user has access to. |
| `gtm/list-built-in-variables` | read | Lists all the enabled Built-In Variables of a GTM Container. |
| `gtm/list-clients` | read | Lists all GTM Clients of a GTM container workspace. |
| `gtm/list-containers` | read | Lists all Containers that belongs to a GTM Account. |
| `gtm/list-destinations` | read | Lists all Destinations linked to a GTM Container. |
| `gtm/list-environments` | read | Lists all GTM Environments of a GTM Container. |
| `gtm/list-folders` | read | Lists all GTM Folders of a Container. |
| `gtm/list-gtag-config` | read | Lists all Google tag configs in a Container. |
| `gtm/list-tags` | read | Lists all GTM Tags of a Container. |
| `gtm/list-templates` | read | Lists all GTM Templates of a GTM container workspace. |
| `gtm/list-transformations` | read | Lists all GTM Transformations of a GTM container workspace. |
| `gtm/list-triggers` | read | Lists all GTM Triggers of a Container. |
| `gtm/list-user-permissions` | read | List all users that have access to the account along with Account and Container user access granted to each of them. |
| `gtm/list-variables` | read | Lists all GTM Variables of a Container. |
| `gtm/list-version-headers` | read | Lists all Container Versions of a GTM Container. |
| `gtm/list-workspaces` | read | Lists all Workspaces that belong to a GTM Container. |
| `gtm/list-zones` | read | Lists all GTM Zones of a GTM container workspace. |
| `gtm/live-version` | read | Gets the live (i.e. published) container version |
| `gtm/lookup-container` | read | Looks up a Container by destination ID or tag ID. |
| `gtm/move-entities-to-folder-folder` | write | Moves entities to a GTM Folder. If {folder_id} in the request path equals 0, this will instead move entities out of the folder they currently belong to. |
| `gtm/move-tag-id-container` | write | Move Tag ID out of a Container. |
| `gtm/publicar` | write | Simular é o padrão. A publicação exige expected_fingerprint da prévia. Reversão republica a versão indicada; criação de versão substitui o workspace. |
| `gtm/publish-version` | write | Publishes a Container Version. |
| `gtm/quick-preview-workspace` | write | Quick previews a workspace by creating a fake container version from all entities in the provided workspace. |
| `gtm/reauthorize-environment` | write | Re-generates the authorization code for a GTM Environment. |
| `gtm/resolve-conflict-workspace` | write | Resolves a merge conflict for a workspace entity by updating it to the resolved entity passed in the request. |
| `gtm/revert-built-in-variable` | write | Reverts changes to a GTM Built-In Variables in a GTM Workspace. |
| `gtm/revert-client` | write | Reverts changes to a GTM Client in a GTM Workspace. |
| `gtm/revert-folder` | write | Reverts changes to a GTM Folder in a GTM Workspace. |
| `gtm/revert-tag` | write | Reverts changes to a GTM Tag in a GTM Workspace. |
| `gtm/revert-template` | write | Reverts changes to a GTM Template in a GTM Workspace. |
| `gtm/revert-transformation` | write | Reverts changes to a GTM Transformation in a GTM Workspace. |
| `gtm/revert-trigger` | write | Reverts changes to a GTM Trigger in a GTM Workspace. |
| `gtm/revert-variable` | write | Reverts changes to a GTM Variable in a GTM Workspace. |
| `gtm/revert-zone` | write | Reverts changes to a GTM Zone in a GTM Workspace. |
| `gtm/reverter` | write | Simular é o padrão. A publicação exige expected_fingerprint da prévia. Reversão republica a versão indicada; criação de versão substitui o workspace. |
| `gtm/set-latest-version` | write | Sets the latest version used for synchronization of workspaces when detecting conflicts and errors. |
| `gtm/snippet-container` | read | Gets the tagging snippet for a Container. |
| `gtm/sync-workspace` | write | Syncs a workspace to the latest container version by updating all unmodified workspace entities and displaying conflicts for modified entities. |
| `gtm/undelete-version` | write | Undeletes a Container Version. |
| `gtm/update-account` | write | Updates a GTM Account. |
| `gtm/update-client` | write | Updates a GTM Client. |
| `gtm/update-container` | write | Updates a Container. |
| `gtm/update-environment` | write | Updates a GTM Environment. |
| `gtm/update-folder` | write | Updates a GTM Folder. |
| `gtm/update-gtag-config` | write | Updates a Google tag config. |
| `gtm/update-tag` | write | Updates a GTM Tag. |
| `gtm/update-template` | write | Updates a GTM Template. |
| `gtm/update-transformation` | write | Updates a GTM Transformation. |
| `gtm/update-trigger` | write | Updates a GTM Trigger. |
| `gtm/update-user-permission` | write | Updates a user's Account & Container access. |
| `gtm/update-variable` | write | Updates a GTM Variable. |
| `gtm/update-version` | write | Updates a Container Version. |
| `gtm/update-workspace` | write | Updates a Workspace. |
| `gtm/update-zone` | write | Updates a GTM Zone. |
| `siteverification/get-token` | read | Obtém o token e o método de verificação. Instalar arquivo, meta tag ou DNS é tarefa separada. |
| `siteverification/list` | read | Lista sites e domínios verificados pela credencial. |
| `siteverification/update-owners` | write | Substitui a lista completa de proprietários; a API exige preservar o proprietário autenticado. |
| `siteverification/verify` | write | Confirma um token já instalado e torna a credencial proprietária verificada. |
