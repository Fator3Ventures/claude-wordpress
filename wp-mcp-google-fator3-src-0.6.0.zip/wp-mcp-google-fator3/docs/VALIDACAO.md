# Validação da versão 0.6.0

Data: 01/10/2026. Ambiente: PHP 8.3.6, WordPress 7.1 e MySQL 8.0.46; canal Fator3 0.13.0 e importador Site Core 1.18.0. As APIs Google e a distribuição foram simuladas. Nenhuma alteração foi implantada em produção.

As evidências desta release ficam em `evidence/` do pacote-fonte. O histórico da 0.5.0 está em [VALIDACAO-0.5.0.md](history/VALIDACAO-0.5.0.md) e não substitui os resultados atuais.

- Suíte unitária/regressão: **964 testes e 11.707 asserções aprovados**, incluindo criação de tag/gatilho/variável, publicação e reversão com Service Account sintética. Resultado em `unit-final.txt`.
- Estilo e compatibilidade PHP 8.0+: zero erros e avisos; `phpcs-final.json`; sintaxe: `php-lint-final.json`.
- Importação com serviço/banco reais do Core, incluindo artigo catalogado e visão editorial com cliques, impressões e posição até D-3: `daily-core-final.txt`.
- Canal e perfis reais: `channel-013-final.txt`; atualizadores reais: `updater-channel-013-final.txt`.
- Migração concorrente: `migration-admission-final.txt`; chamadas admitidas e recusadas, cópia e recuperação histórica.
- Persistência: 25 verificações com funções reais do WordPress/SQLite. Repositório, concorrência e painel: sondas MySQL incluídas no pacote-fonte. Navegador: 38 verificações aprovadas de teclado, cópia, rótulos e layout móvel. Downloads de seis documentos e do Cloud Shell conferidos byte a byte; acesso anônimo e nonce inválido recusados.
- Pacote: 100 verificações HTTP locais com Apache, autoindex habilitado e `AllowOverride None`; todos os 17 diretórios com índice, Markdown/script público ausente e recursos PHP protegidos. PUT vazio: três caminhos retornaram 204, com `Content-Length: 0` e zero bytes. Inventário e SHA-256 acompanham a entrega.

A validação local comprova os contratos exercitados. Falta homologar chamadas às contas Google reais, o aceite editorial por artigo no site alvo, permissões da Service Account no GTM e comportamento de tags/consentimento no navegador. O diagnóstico GTM é estático. Compatibilidade com toda combinação de PHP/WordPress/MariaDB não foi executada; o piso declarado continua PHP 8.0 e Abilities API compatível.
