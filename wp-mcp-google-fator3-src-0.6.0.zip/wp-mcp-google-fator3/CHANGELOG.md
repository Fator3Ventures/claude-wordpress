# Histórico

## 0.6.0 — 2026-10-01

- Entrega integral dos pedidos 8–11 sobre a base 0.5.0.
- Importação diária Search Console → Site Core com checkpoints, autorização revalidada, replay dos três últimos dias finais e estado em `google/status.gsc_import`.
- Provedor e `policy_contract:1` no canal 0.13.0, autorização do alvo final nas bridges e compatibilidade do atualizador nativo com os dois formatos de manifesto.
- Admissão serializada com migração: operações admitidas finalizam sua auditoria antes da cópia; chamadas novas recebem erro temporário antes do despacho. Recuperação da saúde preserva a lacuna histórica.
- Catálogo Tag Manager v2 completo (106 métodos), rotas tipadas, níveis de escopos, prévia/publicação/reversão e diagnóstico estático da versão publicada.
- Publicação interrompida não se repete automaticamente; registros retornam versão anterior, criada e substituição do workspace.
- Configuração GTM optativa; Service Account permanece prioritária. Documentação versionada e Cloud Shell com API Tag Manager disponíveis por download autenticado.
- Mantém as entregas anteriores, a correção do PUT vazio e o fechamento do instalador sem `.htaccess`.

## 0.5.0 — 2026-09-30

Entrega única integral. Critérios, evidências e limites de homologação em `docs/VALIDACAO.md`. Sem implantação automática em produção.

- Mantém Service Account em primeiro e separa autenticações; preserva credencial ativa durante a preparação/validação da candidata.
- Acrescenta telas de operações, agendas, perfis, política, modelos, alertas e distribuição; revisões e nonces protegem formulários; JSONs ficam recolhíveis.
- Publica execução/configuração/catálogo 2.0.0, 167 habilidades e metadados de versão; corrige distinção entre leitura, escrita local e efeito remoto.
- Entrega `ga/aplicar-perfil`, `ga/conformidade`, schema/lista/gravação de perfis genéricos e `ga/list-custom-dimensions`; compara grafia, aplica retenção primeiro e relê cada etapa.
- Resolve vínculo opcional pelo Measurement ID do Site Core sem criar propriedade e com compensação verificada em falhas.
- Entrega `gsc/preparar-site`, `gsc/migracao-conferir`, inspeção imediata de até cinco URLs únicas e fila para até 500; preserva `Content-Length: 0` no PUT vazio.
- Exige preparação/confirmacão vinculada nas escritas sensíveis; registra tentativas, retorna resultados parciais/incertos e recusa repetição automática.
- Migra opções para repositório indexado com cópia/verificação/retomada; commits de resultados/cursor, leases e escopo por conexão impedem os reenvios cobertos pelos testes.
- Acrescenta executor compartilhado de vencidos, revisão de agendas, paginação de resultados, retenção e limpeza com prévia/limite por passagem.
- Publica políticas de recurso com prévia de impacto, modelos sem segredos, alertas optativos e metadados executáveis de relatórios.
- Acrescenta auditoria por hash de configuração/marcador exclusivo, detecção de ambiguidade, revisão/cursor, exportação JSON/CSV autenticada e ação separada de exportação literal para Sheets.
- Endurece consultas públicas/atualização com DNS fixado, recusa de IPs especiais, limites e validação de cada redirecionamento; atualizador exige origem explícita, hash, versão e estrutura coerentes.
- Retira documentos e scripts textuais do instalador, preservando-os nos fontes; inclui índice em todos os diretórios, sem `.htaccess`; download Cloud Shell continua autenticado.
- Desativação cancela ambos os executores e remove caches de tokens. Desinstalação sempre remove segredos e preserva por padrão dados públicos sanitizados; purge é optativo por site.
- Documentação atual e catálogos gerados substituem instruções antigas; guias históricos ficam em `docs/history/`.

**Incompatibilidades:** escritas sensíveis da 0.4.0 precisam de confirmação; atualização de agenda precisa de revisão; jobs legados sem contexto exigem revisão; contrato padrão de configuração passa a 2.0.0. Projeções 1.x não restauram o comportamento antigo de escrita.

## 0.4.0 — 2026-09-14

- Reorganiza configuração em quatro áreas com ajuda contextual, navegação responsiva e formulários utilizáveis sem JavaScript.
- Prioriza Service Account em conexões novas; preserva OAuth existente e separa os métodos por painel.
- Separa preparação e ativação explícita, com validação de token e revisão contra alterações concorrentes.
- Impede callback OAuth antigo de sobrescrever configuração recente; preserva feedback ao administrador após retorno REST.
- Centraliza gravações verificadas; valor igual, falha, restauração e campo omitido possuem tratamento distinto.
- Unifica controles de serviço e GA4 padrão; oferece sugestões de recursos, entrada manual e detecção de sitemap.
- Isola diagnóstico e descoberta por usuário, conexão e revisão. Corrige afirmação indevida de ausência de servidor MCP.
- Expõe edição dos quatro limites e contrato 1.1.0 com metadados de interface; mantém consulta explícita 1.0.0.
- Preserva criptografia, múltiplas conexões, selftest e correção do PUT vazio.
- Validação: 858 testes e 9.173 asserções; 34 verificações WordPress/SQLite; três PUTs HTTP; 12 combinações de tela/largura em Chrome, com sete verificações interativas. Google simulado; sem implantação em produção.

## 0.3.1 — 2026-09-14

- Corrige primeira gravação de `false` em opção ausente: usa `add_option()` após leitura de existência, sob trava, com confirmação direta no banco.
- Preserva sucesso sem alteração para valores já iguais; inserção recusada continua retornando `f3_google_option_persistence`.
- Acrescenta `google/configuration-schema`, contrato `1.0.0` com 22 opções/itens derivados, escopo, tipos, limites, valores atuais seguros, dependências e operações permitidas.
- Reutiliza limites de `Options`, perfis e validadores de `Setup`, limites de `Connections` e schemas do registro ativo de habilidades.
- Distingue valor ausente, valor efetivo, leitura não confirmada e segredo indecifrável. Não expõe segredos, cifras ou hashes de credenciais.
- Total: 132 habilidades (47 leituras, 85 escritas). Não modifica o Core nem libera escrita genérica de opções.
- Validação: 821 testes, 8.943 asserções; 25 verificações WordPress/SQLite, três PUTs em HTTP local e nove cenários Cloud Shell simulados.

## 0.3.0 — 2026-09-13

- Corrige selftest: execução, aprovação e verificações puladas têm campos distintos; reprovação não é sobrescrita por Response::ok().
- Adiciona gravações verificadas, confirmação direta no banco, resultados por operação, erros de cifra e compensação de lotes; painel e OAuth conferem persistência.
- Cifra access tokens no cache, invalida cache legado e serializa renovação.
- Separa desconexão local e revogação OAuth explícita; preserva configuração do cliente.
- Adiciona seleção de serviços/perfis, importação de credenciais, configuração assistida e até 20 conexões locais.
- Acrescenta diagnóstico por recurso, telemetria HTTP sem corpos/segredos, Retry-After, classificação de quota e orçamento de tentativas.
- Substitui auditoria em lista única por registros independentes com inserção exclusiva e retenção configurável.
- Acrescenta sitemap acompanhado, inspeção em lote com cache/cota/prioridade, jobs persistentes, agendas e seis modelos de relatório.
- Preserva PUT vazio com Content-Length: 0 e todas as habilidades anteriores. Total: 131 habilidades (46 leituras, 85 escritas).
- Inclui script Cloud Shell revisado e original de referência; projeto explícito, reuso de chaves e rotação opt-in.
- Validação: 805 testes, 8.730 asserções; 20 verificações com funções WordPress/SQLite, três PUTs por HTTP local e nove cenários Cloud Shell simulados.

## 0.2.1 — 2026-09-09

- Corrige HTTP 411 em `gsc/submit-sitemap`: o cliente HTTP envia `Content-Length: 0` em PUT com corpo vazio.
- Aplica a correção também a `gsc/add-site` e a métodos PUT sem corpo executados por `google/execute-action`.
- Preserva corpos JSON, formulários e uploads com conteúdo; mantém o contrato sem corpo da Search Console.
- Inclui testes de regressão e reprodução HTTP local com o transporte Requests/Fsockopen do WordPress.

## 0.2.0 — 2026-09-08

- Preserva as 21 habilidades e configurações da 0.1.0; acrescenta 93 habilidades.
- Adiciona Search Console, Site Verification, GA Admin em escrita, Ads em escrita, Measurement Protocol, blend e exportação para Sheets/Drive.
- Expõe catálogo e executor baseados em nove documentos oficiais, com 521 métodos no conjunto validado.
- Acrescenta anotações de escrita, auditoria before/after redigida, validateOnly Ads, erros acionáveis e diagnóstico de APIs/escopos.
- Resolve contas por nome e wildcard; inclui conversões customizadas Ads, catálogos completos e isolamento de caches por credencial/delegação.
- Corrige colisão de IDs numéricos em fanout, paginação incompleta/cíclica, repetição indevida de gravações e codificação de objetos JSON vazios.
- Conserva integração com as três metatools e URL do servidor WP MCP Fator3.

## 0.1.0 — base recebida

21 habilidades de leitura Analytics/Ads/camada unificada, service account e OAuth de usuário, cifra, configuração administrativa, portão geral e auditoria de metadados.
