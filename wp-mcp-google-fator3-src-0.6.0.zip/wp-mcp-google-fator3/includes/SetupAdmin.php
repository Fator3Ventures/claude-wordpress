<?php
/**
 * Guided forms share the same writers used by agents and manual configuration.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class SetupAdmin {

	public static function init(): void {
		foreach ( array( 'save', 'import', 'create' ) as $action ) {
			add_action( 'admin_post_f3_google_setup_' . $action, static fn () => self::handle( $action ) );
		}
	}
	public static function handle( string $action ): void {
		Admin::guard( 'f3_google_setup_' . $action );
		if ( 'create' === $action ) {
			$id     = Admin::posted( 'new_id' );
			$result = Connections::create( $id, Admin::posted( 'label' ) );
			Admin::require_saved( $result );
			Connections::select( $id );
			wp_safe_redirect( Admin::url( 'created', 'connection', 'service_account' ) );
			exit;
		}
		if ( 'import' === $action ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Missing -- Upload metadata is checked for error, size and is_uploaded_file() before a bounded local read. POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
			$file = $_FILES['credential'] ?? array();
			$max  = Auth\Configuration::JSON_MAX_BYTES;
			if ( ! is_array( $file ) || ( $file['error'] ?? 1 ) !== UPLOAD_ERR_OK || ! is_string( $file['tmp_name'] ?? null ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
				Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_credential_upload', 'Envie um arquivo JSON de até 1 MiB. Confira também o limite de upload do servidor.' ) ) );
				return;
			}
			if ( filesize( $file['tmp_name'] ) > $max ) {
				Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' ) ) );
				return;
			}
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Bounded read of a verified local upload, never a remote URL.
			$json      = file_get_contents( $file['tmp_name'], false, null, 0, $max + 1 );
			$result    = Auth\Configuration::import( is_string( $json ) ? $json : '', Admin::method(), '1' === Admin::posted( 'activate' ), Admin::posted_revision() );
			$activated = '1' === Admin::posted( 'activate' );
			Admin::saved( $result, $activated ? 'activated' : 'saved' );
			return;
		}
		$input = array(
			'bindings'        => array(),
			'validate_access' => '1' === Admin::posted( 'validate_access' ),
		);
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
		if ( isset( $_POST['services_present'] ) || isset( $_POST['services'] ) ) {
			$input['services'] = array();
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Missing -- Structured input is validated by the shared schema/credential writer; text sanitization would corrupt JSON or the key. POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
			foreach ( (array) wp_unslash( $_POST['services'] ?? array() ) as $service => $level ) {
				if ( ! is_string( $level ) ) {
					Admin::require_saved( Response::fail( new \WP_Error( 'f3_google_setup_input', 'Perfil de serviço inválido.' ) ) );
					return;
				}
				if ( '' !== $level ) {
					$input['services'][ $service ] = $level;
				}
			}
		}
		foreach ( array_keys( Setup::BINDING_RULES ) as $key ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST handlers verify capability and nonce in Admin::guard() before invoking this helper.
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$value = Admin\Resources::normalize( $key, Admin::posted( $key ) );
			if ( is_wp_error( $value ) ) {
				Admin::require_saved( Response::fail( $value ) );
				return;
			}
			$input['bindings'][ $key ] = $value;
		}
		if ( null !== Admin::posted_revision() ) {
			$input['expected_revision'] = Admin::posted_revision();
		}
		Admin::saved( Setup::apply( $input ) );
	}
	/** Compatibility entry point now prepares credentials without activating another method. */
	public static function import( string $json ): array {
		return Auth\Configuration::import( $json );
	}
	public static function render(): void {
		Admin\Screen::services();
	}
}
