<?php
/**
 * CLI is an authenticated adapter of the same abilities, never an auth bypass.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Cli {

	public static function init(): void {
		if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( 'WP_CLI' ) ) {
			return;
		}
		foreach ( array(
			'status'    => 'google/status',
			'preflight' => 'google/preflight',
			'run-due'   => 'google/executar-vencidos',
			'get-job'   => 'google/get-job',
			'run-job'   => 'google/run-job',
			'cleanup'   => 'google/cleanup-jobs',
		) as $command => $ability ) {
			\WP_CLI::add_command(
				'mcp-google ' . $command,
				static function ( array $args, array $assoc ) use ( $ability ): void {
					if ( 'json' !== ( $assoc['format'] ?? 'json' ) ) {
						\WP_CLI::error( 'Este comando oferece somente --format=json.' );
						return;
					}
					if ( ! get_current_user_id() || ! current_user_can( Options::capability() ) ) {
						\WP_CLI::error( 'Informe --user com um administrador autorizado.' );
						return;
					}
					$decoded = isset( $assoc['input'] ) ? json_decode( $assoc['input'] ) : (object) array();
					if ( ! is_object( $decoded ) ) {
						\WP_CLI::error( '--input deve ser um objeto JSON.' );
						return;
					}$input = json_decode( wp_json_encode( $decoded ), true );
					$entry  = wp_get_ability( $ability );
					if ( ! $entry ) {
						Plugin::register_abilities();
						$entry = wp_get_ability( $ability );
					}$result = $entry ? $entry->execute( $input ) : Response::fail( 'Habilidade indisponível.' );
					if ( is_wp_error( $result ) ) {
						$result = Response::fail( $result );
					}\WP_CLI::line( wp_json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) );
					if ( empty( $result['success'] ) ) {
						\WP_CLI::halt( 1 );
					}
				},
				array(
					'shortdesc' => 'Executa ' . $ability . ' com a autorização do usuário WordPress.',
					'synopsis'  => array(
						array(
							'type'        => 'assoc',
							'name'        => 'format',
							'description' => 'Formato de saída: json.',
							'options'     => array( 'json' ),
							'default'     => 'json',
							'optional'    => true,
						),
						array(
							'type'        => 'assoc',
							'name'        => 'input',
							'description' => 'Objeto de parâmetros da habilidade, incluindo connection_id quando necessário.',
							'optional'    => true,
						),
					),
				)
			);
		}
	}
}
