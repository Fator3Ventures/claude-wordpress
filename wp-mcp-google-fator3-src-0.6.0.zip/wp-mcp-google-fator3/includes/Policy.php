<?php
/**
 * Per-connection resource policy, enforced at the common HTTP boundary.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Policy {
	public const OPTION                   = 'f3_mcp_google_resource_policy';
	private static int $administrative    = 0;
	private static array $created         = array();
	private static ?array $preview_policy = null;
	private const SHEETS_REQUESTS         = array( 'addSheet', 'updateSheetProperties', 'deleteSheet', 'updateCells', 'appendCells', 'repeatCell', 'updateBorders', 'appendDimension', 'insertDimension', 'deleteDimension', 'updateDimensionProperties', 'autoResizeDimensions', 'mergeCells', 'unmergeCells', 'setBasicFilter', 'clearBasicFilter', 'sortRange', 'copyPaste', 'cutPaste' );
	/** Access to a returned ID is confined to this continuation and its authorized parent. */
	public static function with_created( string $id, string $parent_id, callable $callback ): array {
		if ( 'restricted' === ( self::current()['mode'] ?? 'identity' ) && ( '' === $parent_id || ! self::permitted( 'drive', $parent_id ) || empty( self::current()['services']['drive']['allow_create'] ) ) ) {
			return Response::fail( self::denied( 'Criação exige pasta pai autorizada e allow_create no Drive.' ) );
		}
		$prior                                     = self::$created;
		self::$created[ Connections::id() ][ $id ] = true;
		try {
			return $callback();
		} finally {
			self::$created = $prior;
		}
	}
	public static function current(): array {
		return self::$preview_policy ?? (array) Options::get( self::OPTION, array( 'mode' => 'identity' ) );
	}
	public static function schema(): array {
		$services = array();
		foreach ( array( 'ga', 'ads', 'gsc', 'sheets', 'drive', 'siteverification', 'gtm' ) as $service ) {
			$services[ $service ] = array(
				'type'                 => 'object',
				'additionalProperties' => false,
				'properties'           => array(
					'resources'    => array(
						'type'     => 'array',
						'items'    => array( 'type' => 'string' ),
						'maxItems' => 200,
					),
					'operations'   => array(
						'type'     => 'array',
						'items'    => array( 'type' => 'string' ),
						'maxItems' => 200,
					),
					'allow_create' => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'recipients'   => array(
						'type'     => 'array',
						'items'    => array( 'type' => 'string' ),
						'maxItems' => 100,
					),
				),
			);
		}
		return array(
			'type'                 => 'object',
			'required'             => array( 'mode' ),
			'additionalProperties' => false,
			'properties'           => array(
				'mode'     => array(
					'type' => 'string',
					'enum' => array( 'identity', 'restricted' ),
				),
				'services' => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'properties'           => $services,
				),
			),
		);
	}
	public static function validate( $policy ) {
		if ( ! is_array( $policy ) || array_diff( array_keys( $policy ), array( 'mode', 'services' ) ) || ! in_array( $policy['mode'] ?? null, array( 'identity', 'restricted' ), true ) || ( isset( $policy['services'] ) && ! is_array( $policy['services'] ) ) ) {
			return new \WP_Error( 'f3_google_policy_input', 'Política inválida.' );
		}
		foreach ( $policy['services'] ?? array() as $service => $rule ) {
			if ( ! isset( self::schema()['properties']['services']['properties'][ $service ] ) || ! is_array( $rule ) || array_diff( array_keys( $rule ), array( 'resources', 'operations', 'allow_create', 'recipients' ) ) ) {
				return new \WP_Error( 'f3_google_policy_input', 'Serviço ou regra desconhecida.' );
			}
			foreach ( array( 'resources', 'operations', 'recipients' ) as $field ) {
				if ( isset( $rule[ $field ] ) && ( ! is_array( $rule[ $field ] ) || count( $rule[ $field ] ) > ( 'recipients' === $field ? 100 : 200 ) ) ) {
					return new \WP_Error( 'f3_google_policy_input', 'Listas da política excedem o limite.' );
				}
				foreach ( $rule[ $field ] ?? array() as $value ) {
					if ( ! is_string( $value ) || '' === trim( $value ) || str_contains( $value, '*' ) || strlen( $value ) > 512 ) {
						return new \WP_Error( 'f3_google_policy_input', 'Use recursos e operações explícitos, sem wildcard.' );
					}
					if ( 'recipients' === $field && ! is_email( $value ) ) {
						return new \WP_Error( 'f3_google_policy_input', 'Destinatário inválido.' );
					}
				}
			}
			if ( isset( $rule['allow_create'] ) && ! is_bool( $rule['allow_create'] ) ) {
				return new \WP_Error( 'f3_google_policy_input', 'allow_create deve ser booleano.' );
			}
		}
		return $policy;
	}
	public static function admin_discovery( array $input ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return Response::fail( new \WP_Error( 'f3_google_policy_forbidden', 'Gerenciar a política exige manage_options.' ) );
		}
		++self::$administrative;
		try {
			$result = Unified\Query::accounts(
				array(
					'connector' => $input['connector'] ?? 'all',
					'refresh'   => true,
				)
			);
			Audit::log( 'policy:administrative-discovery', Connections::id(), array( 'status' => ! empty( $result['success'] ) ? 'ok' : 'error' ) );
			return $result + array(
				'scope'                      => 'identity_available_resources',
				'operational_access_granted' => false,
			);
		} finally {
			--self::$administrative;
		}
	}
	public static function permitted( string $service, string $resource_id ): bool {
		if ( in_array( $service, array( 'sheets', 'drive' ), true ) && isset( self::$created[ Connections::id() ][ $resource_id ] ) ) {
			return true;
		}
		$policy = self::current();
		if ( 'identity' === ( $policy['mode'] ?? 'identity' ) ) {
			return true;
		}
		if ( 'ga' === $service && ctype_digit( $resource_id ) ) {
			$resource_id = 'properties/' . $resource_id;
		}
		if ( 'ads' === $service ) {
			$resource_id = preg_replace( '~^customers/~', '', $resource_id );
		}
		foreach ( $policy['services'][ $service ]['resources'] ?? array() as $allowed ) {
			if ( 'ga' === $service && ctype_digit( $allowed ) ) {
				$allowed = 'properties/' . $allowed;
			}
			if ( 'ads' === $service ) {
				$allowed = preg_replace( '~^customers/~', '', $allowed );
			}
			if ( $allowed === $resource_id ) {
				return true;
			}
		}
		return false;
	}
	private static function denied( string $reason ): \WP_Error {
		return new \WP_Error(
			'f3_google_policy_denied',
			$reason,
			array(
				'operation_outcome' => 'not_applied',
				'retryable'         => false,
			)
		);
	}
	public static function check_http( string $verb, string $url, ?array $body, array $opts ): ?\WP_Error {
		$policy = self::current();
		if ( str_starts_with( $url, Http\GoogleClient::HOST_GTM . '/' ) && Channel::maintenance() ) {
			return null;
		}
		if ( 'restricted' !== ( $policy['mode'] ?? 'identity' ) ) {
			return null;
		}
		$mode = $opts['mode'] ?? 'read';
		if ( 0 === strpos( $url, Http\GoogleClient::HOST_TOKEN ) || str_contains( $url, '/$discovery/' ) || str_contains( $url, '/discovery/' ) ) {
			return null;
		}
		if ( self::$administrative && 'read' === $mode ) {
			return null;
		}
		$connector = $opts['connector'] ?? '';
		$method    = $opts['operation_id'] ?? '';
		$decoded   = rawurldecode( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		if ( '' === $connector ) {
			foreach ( array(
				'analytics'          => 'ga',
				'googleads'          => 'ads',
				'tagmanager.'        => 'gtm',
				'sheets.'            => 'sheets',
				'/webmasters/'       => 'gsc',
				'searchconsole.'     => 'gsc',
				'/drive/'            => 'drive',
				'/siteVerification/' => 'siteverification',
			) as $part => $service ) {
				if ( str_contains( $url, $part ) ) {
					$connector = $service;
					break;
				}
			}
		}
		$rule = $policy['services'][ $connector ] ?? array();
		if ( ! $rule ) {
			return self::denied( 'Serviço sem recursos autorizados na política.' );
		}
		if ( isset( $rule['operations'] ) && $rule['operations'] && ( '' === $method || ! in_array( $method, $rule['operations'], true ) ) ) {
			return self::denied( 'Método fora da lista de operações permitidas.' );
		}
		if ( '' === $method || ! self::covered( $method ) ) {
			return self::denied( 'Método sem mapeamento de alcance no modo restrito. Consulte a cobertura da política.' );
		}
		if ( 'write' === $mode && 'sheets' === $connector ) {
			if ( 'sheets.spreadsheets.batchUpdate' === $method ) {
				foreach ( $body['requests'] ?? array() as $request ) {
					$request = (array) $request;
					if ( 1 !== count( $request ) || ! in_array( key( $request ), self::SHEETS_REQUESTS, true ) ) {
						return self::denied( 'Suboperação Sheets sem mapeamento aprovado no modo restrito.' );
					}
				}
			}
			if ( self::has_formula( $body ?? array() ) || ( in_array( $method, array( 'sheets.spreadsheets.values.update', 'sheets.spreadsheets.values.append', 'sheets.spreadsheets.values.batchUpdate' ), true ) && 'RAW' !== ( $body['valueInputOption'] ?? $opts['query']['valueInputOption'] ?? '' ) ) ) {
				return self::denied( 'No modo restrito, gravação de células exige valores literais (RAW), sem fórmulas ou fontes externas.' );
			}
		}
		if ( 'write' === $mode && 'googleads.customers.googleAds.mutate' === $method ) {
			foreach ( $body['mutateOperations'] ?? array() as $operation ) {
				$keys = array_keys( (array) $operation );
				if ( 1 !== count( $keys ) || ! preg_match( '/^(campaign|campaignBudget|adGroup|adGroupAd|adGroupCriterion|campaignCriterion|conversionAction|asset|adGroupAsset|campaignAsset|assetGroup|experiment|label|adGroupLabel|campaignLabel|userList)Operation$/D', $keys[0] ) ) {
					return self::denied( 'Suboperação Ads sem mapeamento aprovado no modo restrito.' );
				}
			}
		}
		$resource_ids = array();
		if ( 'gtm' === $connector ) {
			if ( preg_match( '~/accounts/[0-9]+/containers/[0-9]+~', $decoded, $gtm ) ) {
				$resource_ids[] = array( 'gtm', ltrim( $gtm[0], '/' ) );
			} elseif ( preg_match( '~/accounts/[0-9]+~', $decoded, $gtm ) ) {
				$resource_ids[] = array( 'gtm', ltrim( $gtm[0], '/' ) );
			}
		}
		if ( 'ga' === $connector && 'measurementprotocol.collect' === $method ) {
			$resource_ids[] = array( 'ga', 'measurementIds/' . ( $opts['query']['measurement_id'] ?? '' ) );
		}
		if ( 'ga' === $connector && preg_match( '~/properties/([0-9]+)~', $decoded, $m ) ) {
			$resource_ids[] = array( 'ga', 'properties/' . $m[1] );
		}
		if ( 'ads' === $connector && preg_match( '~/customers/([0-9]+)~', $decoded, $m ) ) {
			$resource_ids[] = array( 'ads', $m[1] );
		}
		if ( 'sheets' === $connector && preg_match( '~/spreadsheets/([^/:]+)~', $decoded, $m ) ) {
			$resource_ids[] = array( 'sheets', $m[1] );
		}
		if ( 'drive' === $connector && preg_match( '~/files/([^/]+)~', $decoded, $m ) ) {
			$resource_ids[] = array( 'drive', $m[1] );
		}
		if ( 'gsc' === $connector && preg_match( '~/sites/(.+?)(?:/(?:sitemaps|searchAnalytics)|$)~', $decoded, $m ) ) {
			$resource_ids[] = array( 'gsc', $m[1] );
		}
		self::references( $body ?? array(), $resource_ids, $connector );
		self::references( (array) ( $opts['query'] ?? array() ), $resource_ids, $connector );
		if ( 'ga' === $connector && preg_match( '~/accounts/([0-9]+)~', $decoded, $m ) ) {
			$resource_ids[] = array( 'ga', 'accounts/' . $m[1] );
		}
		if ( 'siteverification' === $connector && preg_match( '~/webResource/(.+)$~', $decoded, $m ) ) {
			$resource_ids[] = array( 'siteverification', 'webResources/' . $m[1] );
		}
		// Operational discovery is filtered on the way out; it never grants access.
		$catalog = 'read' === $mode && ( ( 'analyticsdata.properties.getMetadata' === $method && str_ends_with( $decoded, '/properties/0/metadata' ) ) || 'googleads.googleAdsFields.search' === $method || str_ends_with( $decoded, '/accountSummaries' ) || str_ends_with( $decoded, '/sites' ) || 'siteVerification.webResource.list' === $method || str_ends_with( $decoded, 'customers:listAccessibleCustomers' ) || preg_match( '~/drive/v[23]/files$~', $decoded ) );
		if ( ! $resource_ids && ! $catalog ) {
			return self::denied( 'O método não possui recurso verificável no modo restrito.' );
		}
		foreach ( $resource_ids as [$service, $resource_id] ) {
			if ( 'analyticsdata.properties.getMetadata' === $method && 'properties/0' === $resource_id ) {
				continue;
			}
			if ( ! self::permitted( $service, $resource_id ) ) {
				return self::denied( 'Recurso fora da política: ' . $service );
			}
		}
		if ( 'write' === $mode && ( 'POST' === $verb ) && ( preg_match( '/\.(create|insert)$/', $method ) || ( 'ads' === $connector && self::has_creation( $body ?? array() ) ) ) && empty( $rule['allow_create'] ) ) {
			return self::denied( 'Criação exige allow_create e contexto pai autorizado.' );
		}
		if ( 'write' === $mode && ( preg_match( '/permissions|accessBindings|owners|UserAccess/', $method . $url ) || self::contains_access( $body ?? array() ) ) ) {
			foreach ( self::recipients( $body ?? array() ) as $email ) {
				if ( ! in_array( $email, $rule['recipients'] ?? array(), true ) ) {
					return self::denied( 'Destinatário fora da política de compartilhamento.' );
				}
			}
			if ( self::public_sharing( $body ?? array() ) ) {
				return self::denied( 'Compartilhamento público ou por domínio indisponível no modo restrito.' );
			}
		}
		return null;
	}
	private static function has_formula( array $body ): bool {
		foreach ( $body as $key => $value ) {
			if ( in_array( $key, array( 'formulaValue', 'dataSource', 'dataSourceId', 'dataSourceFormula' ), true ) ) {
				return true;
			}
			if ( 'pasteData' === $key ) {
				return true;
			}
			if ( ( is_array( $value ) || is_object( $value ) ) && self::has_formula( (array) $value ) ) {
				return true;
			}
		}
		return false;
	}
	/** Local impact snapshot; no discovery and no permissions are granted by this preview. */
	public static function plan( array $input ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return Response::fail( new \WP_Error( 'f3_google_policy_forbidden', 'Gerenciar a política exige manage_options.' ) );
		}
		$policy = self::validate( $input['policy'] ?? null );
		if ( is_wp_error( $policy ) ) {
			return Response::fail( $policy );
		}
		$revision = Settings::revision();
		if ( is_wp_error( $revision ) ) {
			return Response::fail( $revision );
		}
		$changed              = self::current() !== $policy;
		$blocked              = array();
		$bindings             = (array) Options::get( Connections::BINDINGS, array() );
		$prior                = self::$preview_policy;
		self::$preview_policy = $policy;
		try {
			foreach ( array(
				'ga_property_id'  => 'ga',
				'ads_customer_id' => 'ads',
				'gsc_site_url'    => 'gsc',
				'spreadsheet_id'  => 'sheets',
			) as $key => $service ) {
				if ( ! empty( $bindings[ $key ] ) && ! self::permitted( $service, (string) $bindings[ $key ] ) ) {
					$blocked[] = array(
						'binding'  => $key,
						'resource' => $bindings[ $key ],
					);
				}
			}
		} finally {
			self::$preview_policy = $prior;
		}
		$counts = array(
			'jobs'      => 0,
			'schedules' => 0,
		);
		if ( $changed ) {
			if ( Storage\Migration::active() ) {
				foreach ( array(
					'job'      => array( 'pending', 'running', 'dispatching', 'approval_required', 'blocked' ),
					'schedule' => array( 'enabled' ),
				) as $kind => $states ) {
					foreach ( $states as $state ) {
						$n = Storage\Repository::count_filtered(
							$kind,
							array(
								'connection_id' => Connections::id(),
								'state'         => $state,
							)
						);
						if ( is_wp_error( $n ) ) {
							return Response::fail( $n );
						}
						$counts[ 'job' === $kind ? 'jobs' : 'schedules' ] += $n;
					}
				}
			} else {
				foreach ( array(
					'job'      => 1001,
					'schedule' => 101,
				) as $kind => $limit ) {
					foreach ( Records::list( $kind, $limit ) as $record ) {
						if ( ( $record['connection_id'] ?? 'default' ) !== Connections::id() ) {
							continue;
						}
						if ( 'schedule' === $kind ? ! empty( $record['enabled'] ) : in_array( $record['status'] ?? '', array( 'pending', 'running', 'dispatching', 'approval_required', 'blocked' ), true ) ) {
							++$counts[ 'job' === $kind ? 'jobs' : 'schedules' ];
						}
					}
				}
			}
		}
		$impact              = array(
			'policy'                  => $policy,
			'changed'                 => $changed,
			'defaults_outside_policy' => $blocked,
			'contexts_invalidated'    => $counts,
			'invalidation'            => 'Mudança de política invalida contextos pendentes; agendas devem ser revistas e salvas, jobs recriados com nova intenção.',
			'revision'                => $revision,
		);
		$impact['plan_hash'] = Automation\FrozenInput::hash( array( $policy, $revision, Connections::id(), get_current_user_id() ) );
		return Response::ok( $impact + array( 'remote_writes_performed' => false ) );
	}
	public static function configure( array $input ): array {
		$plan = self::plan( $input );
		if ( ! $plan['success'] ) {
			return $plan;
		}
		if ( $plan['changed'] && ( ! is_string( $input['expected_plan_hash'] ?? null ) || ! hash_equals( $plan['plan_hash'], $input['expected_plan_hash'] ) ) ) {
			return Response::fail( new \WP_Error( 'f3_google_policy_preview_required', 'Consulte google/plan-policy e confirme o plan_hash antes de alterar o alcance.' ) );
		}
		return Settings::save( array( self::OPTION => $plan['policy'] ), array(), array(), $input['expected_revision'] ?? null );
	}
	private static function contains_access( array $body ): bool {
		foreach ( $body as $key => $value ) {
			if ( preg_match( '/permissions|accessBindings|owners|UserAccess/i', (string) $key ) ) {
				return true;
			}
			if ( ( is_array( $value ) || is_object( $value ) ) && self::contains_access( (array) $value ) ) {
				return true;
			}
		}
		return false;
	}
	private static function public_sharing( array $body ): bool {
		foreach ( $body as $key => $value ) {
			if ( 'type' === $key && in_array( $value, array( 'anyone', 'domain' ), true ) ) {
				return true;
			}
			if ( ( is_array( $value ) || is_object( $value ) ) && self::public_sharing( (array) $value ) ) {
				return true;
			}
		}
		return false;
	}
	private static function has_creation( array $body ): bool {
		foreach ( $body as $key => $value ) {
			if ( 'create' === $key ) {
				return true;
			}
			if ( ( is_array( $value ) || is_object( $value ) ) && self::has_creation( (array) $value ) ) {
				return true;
			}
		}
		return false;
	}
	public static function filter_accounts( array $rows ): array {
		if ( self::$administrative || 'restricted' !== ( self::current()['mode'] ?? 'identity' ) ) {
			return $rows;
		}
		return array_values(
			array_filter(
				$rows,
				static function ( $row ): bool {
					$service = array(
						'ga4'            => 'ga',
						'google-ads'     => 'ads',
						'search-console' => 'gsc',
					)[ $row['connector'] ?? '' ] ?? '';
					return self::permitted( $service, (string) ( $row['account_id'] ?? '' ) );
				}
			)
		);
	}
	private static function references( array $body, array &$out, string $connector ): void {
		foreach ( $body as $key => $value ) {
			if ( is_array( $value ) || is_object( $value ) ) {
				$value = (array) $value;
				if ( 'parents' === $key ) {
					foreach ( $value as $id ) {
						if ( is_string( $id ) ) {
							$out[] = array( 'drive', $id );
						}
					}
				}
				self::references( $value, $out, $connector );
				continue;
			}
			if ( ! is_string( $value ) && ! is_int( $value ) ) {
				continue;
			}
			$value = (string) $value;
			if ( 'ga' === $connector && preg_match( '~^accounts/([0-9]+)(?:/|$)~', $value, $m ) ) {
				$out[] = array( 'ga', 'accounts/' . $m[1] );
			} elseif ( preg_match( '~^properties/([0-9]+)(?:/|$)~', $value, $m ) ) {
				$out[] = array( 'ga', 'properties/' . $m[1] );
			} elseif ( preg_match( '~^customers/([0-9]+)(?:/|$)~', $value, $m ) ) {
				$out[] = array( 'ads', $m[1] );
			} elseif ( in_array( $key, array( 'siteUrl', 'site_url' ), true ) ) {
				$out[] = array( 'gsc', $value );
			} elseif ( in_array( $key, array( 'customerId', 'customer_id' ), true ) ) {
				$out[] = array( 'ads', $value );
			} elseif ( in_array( $key, array( 'spreadsheetId', 'destinationSpreadsheetId', 'spreadsheet_id' ), true ) ) {
				$out[] = array( 'sheets', $value );
			} elseif ( 'siteverification' === $connector && 'identifier' === $key ) {
				$out[] = array( 'siteverification', $value );
			} elseif ( in_array( $key, array( 'addParents', 'removeParents' ), true ) ) {
				foreach ( explode( ',', $value ) as $parent_id ) {
					$out[] = array( 'drive', trim( $parent_id ) );
				}
			} elseif ( in_array( $key, array( 'fileId', 'folderId', 'targetId' ), true ) ) {
				$out[] = array( 'drive', $value );
			}
		}
	}
	private static function recipients( array $body ): array {
		$out = array();
		foreach ( $body as $key => $value ) {
			if ( is_array( $value ) || is_object( $value ) ) {
				$out = array_merge( $out, self::recipients( (array) $value ) );
			} elseif ( is_string( $value ) && in_array( $key, array( 'emailAddress', 'email_address', 'email', 'user', 'owner' ), true ) ) {
				$out[] = $value;
			} elseif ( is_string( $value ) && is_email( $value ) ) {
				$out[] = $value;
			}
		}
		return $out;
	}
	public static function covered( string $method ): bool {
		if ( str_starts_with( $method, 'tagmanager.' ) ) {
			return ! is_wp_error( Operation::method( 'tag-manager', $method ) ) && ! preg_match( '/combine|move_tag_id|destinations|lookup|user_permissions|accounts\.list/', $method );
		}
		return 'measurementprotocol.collect' === $method || (bool) preg_match( '/^(analyticsadmin\.(accountSummaries\.list|accounts\.(get|delete|accessBindings\.(get|list|create|patch|delete))|properties\.(create|get|patch|delete|getDataRetentionSettings|updateDataRetentionSettings|getGoogleSignalsSettings|updateGoogleSignalsSettings|getAttributionSettings|updateAttributionSettings|keyEvents\.(list|get|create|patch|delete)|audiences\.(list|get|create|patch|archive)|googleAdsLinks\.(list|get|create|patch|delete)|reportingDataAnnotations\.(list|get|create|patch|delete)|customDimensions\.(list|get|create|patch|archive)|customMetrics\.(list|get|create|patch|archive)|dataStreams\.(measurementProtocolSecrets\.(get|list|create|delete)|list|get|create|patch|delete|getEnhancedMeasurementSettings|updateEnhancedMeasurementSettings|getDataRedactionSettings|updateDataRedactionSettings)|accessBindings\.(list|get|create|patch|delete)))|analyticsdata\.properties\.(runReport|batchRunReports|runRealtimeReport|runPivotReport|batchRunPivotReports|runFunnelReport|checkCompatibility|getMetadata)|webmasters\.(sites\.(get|list|add|delete)|sitemaps\.(get|list|submit|delete)|searchanalytics\.query)|searchconsole\.urlInspection\.index\.inspect|sheets\.spreadsheets\.(get|batchUpdate|values\.(get|batchGet|update|append|clear|batchUpdate))|drive\.files\.(get|list|create|update)|drive\.permissions\.(get|list|create|update|delete)|siteVerification\.webResource\.(get|list|getToken|insert|update)|googleads\.googleAdsFields\.search|googleads\.customers\.(listAccessibleCustomers|googleAds\.(search|searchStream|mutate)|(campaigns|campaignBudgets|adGroups|adGroupAds|adGroupCriteria|campaignCriteria|conversionActions|assets|adGroupAssets|campaignAssets|assetGroups|experiments|labels|adGroupLabels|campaignLabels|customerUserAccessInvitations|customerUserAccesses|userLists|billingSetups)\.mutate|experiments\.scheduleExperiment|uploadClickConversions|offlineUserDataJobs\.(create|addOperations|run)))$/D', $method );
	}
	public static function filter( string $url, array $data, array $opts ): array {
		if ( self::$administrative || 'restricted' !== ( self::current()['mode'] ?? 'identity' ) ) {
			return $data;
		}
		if ( isset( $data['accountSummaries'] ) ) {
			$filtered = array();
			foreach ( $data['accountSummaries'] as $account ) {
				$account['propertySummaries'] = array_values( array_filter( $account['propertySummaries'] ?? array(), static fn ( $p ) => self::permitted( 'ga', $p['property'] ?? '' ) ) );
				if ( $account['propertySummaries'] ) {
					$filtered[] = $account;
				}
			}
			$data['accountSummaries'] = $filtered;
		}
		foreach ( array(
			'siteEntry' => array( 'gsc', 'siteUrl' ),
			'files'     => array( 'drive', 'id' ),
		) as $key => [$service, $field] ) {
			if ( isset( $data[ $key ] ) ) {
				$data[ $key ] = array_values( array_filter( $data[ $key ], static fn ( $item ) => self::permitted( $service, $item[ $field ] ?? '' ) ) );
			}
		}
		if ( isset( $data['items'] ) && str_contains( $url, '/siteVerification/' ) ) {
			$data['items'] = array_values( array_filter( $data['items'], static fn ( $item ) => self::permitted( 'siteverification', (string) ( $item['site']['identifier'] ?? '' ) ) || self::permitted( 'siteverification', 'webResources/' . ( $item['id'] ?? '' ) ) ) );
		}
		if ( str_contains( $url, 'googleads.googleapis.com' ) ) {
			if ( isset( $data['results'] ) ) {
				$data['results'] = array_values(
					array_filter(
						$data['results'],
						static function ( $row ): bool {
							$refs = array();
							self::references( (array) $row, $refs, 'ads' );
							foreach ( $refs as [$service, $id] ) {
								if ( ! self::permitted( $service, $id ) ) {
									return false;
								}
							}
							return true;
						}
					)
				);
			} elseif ( array_values( $data ) === $data ) {
				foreach ( $data as &$batch ) {
					if ( is_array( $batch ) ) {
						$batch = self::filter( $url, $batch, $opts );
					}
				}
				unset( $batch );
			}
		}
		if ( isset( $data['resourceNames'] ) && str_contains( $url, 'listAccessibleCustomers' ) ) {
			$data['resourceNames'] = array_values( array_filter( $data['resourceNames'], static fn ( $id ) => self::permitted( 'ads', $id ) ) );
		}
		return $data;
	}
	public static function coverage(): array {
		$catalog = require __DIR__ . '/Data/Operations.php';
		$out     = array();
		foreach ( $catalog as $api => $methods ) {
			foreach ( $methods as $method => $contract ) {
				if ( self::covered( $method ) ) {
					$out[ $api ][] = $method;
				}
			}
		}
		$out['measurement-protocol'] = array( 'measurementprotocol.collect' );
		return array(
			'version'               => '1.0.0',
			'methods'               => $out,
			'unknown_methods'       => 'denied',
			'sheets_batch_requests' => self::SHEETS_REQUESTS,
			'formula_writes'        => 'denied_in_restricted_mode',
			'compound_requests'     => 'nested references and recipients are checked; created IDs stay confined to their approved parent and continuation',
		);
	}
	public static function register(): void {
		Ability::register(
			'google/resource-policy',
			'any',
			array(
				'label'       => 'Google: política de recursos',
				'description' => 'Consulta a política da conexão e sua cobertura, sem segredos nem consultas externas.',
				'callback'    => static fn () => Response::ok(
					array(
						'policy'                   => self::current(),
						'schema'                   => self::schema(),
						'revision'                 => Settings::revision(),
						'coverage'                 => self::coverage(),
						'defaults_are_permissions' => false,
					)
				),
			)
		);
		Ability::register(
			'google/plan-policy',
			'any',
			array(
				'label'        => 'Google: impacto da política',
				'description'  => 'Prévia local dos padrões excluídos e contextos pendentes invalidados pela mudança. Não altera permissões.',
				'input_schema' => array(
					'required'   => array( 'policy' ),
					'properties' => array( 'policy' => self::schema() ),
				),
				'callback'     => array( self::class, 'plan' ),
			)
		);
		Ability::register(
			'google/configure-policy',
			'any',
			array(
				'label'        => 'Google: configurar política de recursos',
				'description'  => 'Aplica a política após consultar o impacto por google/plan-policy. Exige revisão e hash da prévia; padrões não concedem acesso.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'policy', 'expected_revision', 'expected_plan_hash' ),
					'properties' => array(
						'policy'             => self::schema(),
						'expected_revision'  => array( 'type' => 'string' ),
						'expected_plan_hash' => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'configure' ),
			)
		);
		Ability::register(
			'google/policy-discover-resources',
			'any',
			array(
				'label'        => 'Google: descobrir recursos para configurar política',
				'description'  => 'Consulta administrativa dos recursos acessíveis à identidade. Exige manage_options e não concede acesso operacional.',
				'input_schema' => array( 'properties' => array( 'connector' => array( 'type' => 'string' ) ) ),
				'callback'     => array( self::class, 'admin_discovery' ),
			)
		);
	}
}
