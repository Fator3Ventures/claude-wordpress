<?php
/**
 * MySQL/MariaDB repository. Queries of metadata never deserialize payloads.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Storage;

use Fator3\McpGoogle\{
	Records, Response
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Repository {

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'f3_google_records';
	}
	public static function install() {
		global $wpdb;
		$table   = self::table();
		$collate = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE IF NOT EXISTS $table (
   sequence bigint unsigned NOT NULL AUTO_INCREMENT,
   kind varchar(24) NOT NULL, record_id varchar(100) NOT NULL,
   connection_id varchar(40) NOT NULL DEFAULT 'default', actor bigint unsigned NOT NULL DEFAULT 0,
   state varchar(32) NOT NULL DEFAULT '', task varchar(80) NOT NULL DEFAULT '',
   target varchar(512) NOT NULL DEFAULT '', mode varchar(8) NOT NULL DEFAULT '',
   due_at bigint NOT NULL DEFAULT 0, priority smallint NOT NULL DEFAULT 5,
   created_at bigint NOT NULL DEFAULT 0, updated_at bigint NOT NULL DEFAULT 0, expires_at bigint NOT NULL DEFAULT 0,
   owner varchar(64) NOT NULL DEFAULT '', lease_until bigint NOT NULL DEFAULT 0,
   generation bigint unsigned NOT NULL DEFAULT 1, digest char(64) NOT NULL, payload longtext NOT NULL,
   PRIMARY KEY (sequence), UNIQUE KEY kind_id (kind,record_id),
   KEY due_queue (kind,state,due_at,priority,sequence), KEY connection_queue (kind,connection_id,state,due_at),
   KEY audit_filter (kind,task,state,sequence), KEY retention (kind,state,expires_at), KEY ownership (kind,owner,lease_until)
  ) ENGINE=InnoDB $collate";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		return false === $wpdb->query( $sql ) ? self::error( 'schema', 'Não foi possível criar o repositório indexado.' ) : true;
	}
	private static function error( string $code, string $message ): \WP_Error {
		return new \WP_Error( 'f3_google_repository_' . $code, $message, array( 'operation_outcome' => 'not_applied' ) );
	}
	private static function check(): ?\WP_Error {
		global $wpdb;
		return '' !== (string) $wpdb->last_error ? self::error( 'read', 'Não foi possível consultar o repositório.' ) : null;
	}
	public static function row( string $kind, string $id, bool $payload = true ) {
		global $wpdb;
		Records::key( $kind, $id );
		$fields = $payload ? '*' : 'sequence,kind,record_id,connection_id,actor,state,task,target,mode,due_at,priority,created_at,updated_at,expires_at,owner,lease_until,generation,digest';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT ' . $fields . ' FROM ' . self::table() . ' WHERE kind=%s AND record_id=%s', $kind, $id ), ARRAY_A );
		return self::check() ?? $row;
	}
	public static function get( string $kind, string $id ) {
		$row = self::row( $kind, $id );
		if ( null === $row || is_wp_error( $row ) ) {
			return $row;
		}
		$value = json_decode( $row['payload'], true );
		if ( ! is_array( $value ) || ! hash_equals( $row['digest'], hash( 'sha256', $row['payload'] ) ) ) {
			return self::error( 'corrupt', 'Registro inválido; execução suspensa para revisão.' );
		}
		return $value;
	}
	private static function values( string $kind, string $id, array $record ): array {
		$json = wp_json_encode( $record );
		if ( ! is_string( $json ) ) {
			throw new \InvalidArgumentException( 'Registro não serializável.' );
		}
		return array(
			'kind'          => $kind,
			'record_id'     => $id,
			'connection_id' => (string) ( $record['connection_id'] ?? 'default' ),
			'actor'         => (int) ( $record['user_id'] ?? $record['user'] ?? 0 ),
			'state'         => (string) ( $record['status'] ?? $record['extra']['status'] ?? ( $record['enabled'] ?? false ? 'enabled' : '' ) ),
			'task'          => (string) ( $record['task'] ?? $record['action'] ?? '' ),
			'target'        => (string) ( $record['target'] ?? '' ),
			'mode'          => (string) ( $record['extra']['mode'] ?? '' ),
			'due_at'        => (int) ( $record['run_after'] ?? $record['next_run'] ?? 0 ),
			'priority'      => (int) ( $record['priority'] ?? 5 ),
			'created_at'    => (int) ( $record['created_at'] ?? time() ),
			'updated_at'    => (int) ( $record['updated_at'] ?? time() ),
			'expires_at'    => (int) ( $record['expires_at'] ?? 0 ),
			'digest'        => hash( 'sha256', $json ),
			'payload'       => $json,
		);
	}
	public static function insert( string $kind, string $id, array $record ): bool {
		global $wpdb;
		Records::key( $kind, $id );
		$v      = self::values( $kind, $id, $record );
		$fields = implode( ',', array_keys( $v ) );
		$marks  = implode( ',', array_fill( 0, count( $v ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		return 1 === $wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO ' . self::table() . " ($fields) VALUES ($marks)", array_values( $v ) ) );
	}
	/** CAS updates are also used to fence an expired worker before dispatch. */
	public static function put( string $kind, string $id, array $record, ?int $generation = null, ?string $owner = null ): array {
		global $wpdb;
		$row = self::row( $kind, $id, false );
		if ( is_wp_error( $row ) ) {
			return Response::fail( $row );
		}
		if ( null === $row ) {
			if ( null !== $generation ) {
				return Response::fail( self::error( 'conflict', 'Registro mudou.' ) );
			}
			if ( ! self::insert( $kind, $id, $record ) ) {
				return Response::fail( self::error( 'write', 'Inserção não confirmada.' ) );
			}
			return array(
				'success'   => true,
				'persisted' => true,
				'changed'   => true,
			);
		}
		$v        = self::values( $kind, $id, $record );
		$expected = $generation ?? (int) $row['generation'];
		if ( $v['digest'] === $row['digest'] && null === $owner && $expected === (int) $row['generation'] ) {
			return array(
				'success'   => true,
				'persisted' => true,
				'changed'   => false,
			);
		}
		unset( $v['kind'], $v['record_id'] );
		$sets = array();
		$args = array();
		foreach ( $v as $key => $value ) {
			$sets[] = "$key=%s";
			$args[] = $value;
		}
		$args[] = $kind;
		$args[] = $id;
		$args[] = $expected;
		$where  = 'kind=%s AND record_id=%s AND generation=%d';
		if ( null !== $owner ) {
			$where .= ' AND owner=%s AND lease_until>%d';
			$args[] = $owner;
			$args[] = time();
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$n = $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET ' . implode( ',', $sets ) . ', generation=generation+1 WHERE ' . $where, $args ) );
		if ( 1 !== $n ) {
			return Response::fail( self::error( 'conflict', 'Gravação não confirmada: registro ou proprietário mudou.' ) );
		}
		$verified = self::row( $kind, $id, false );
		if ( is_wp_error( $verified ) || null === $verified || $verified['digest'] !== $v['digest'] ) {
			return Response::fail( self::error( 'verification', 'Não foi possível confirmar a gravação.' ) );
		}
		return array(
			'success'    => true,
			'persisted'  => true,
			'changed'    => true,
			'generation' => (int) $verified['generation'],
		);
	}
	public static function remove( string $kind, string $id ): array {
		global $wpdb;
		Records::key( $kind, $id );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$n = $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE kind=%s AND record_id=%s', $kind, $id ) );
		return false === $n ? Response::fail( self::error( 'write', 'Remoção recusada.' ) ) : array(
			'success'   => true,
			'persisted' => true,
			'changed'   => $n > 0,
		);
	}
	/** Fixed metadata filters; caller strings can never become SQL identifiers. */
	public static function select( string $kind, array $filters = array(), int $limit = 100, int $offset = 0, bool $newest = true, bool $payload = false ) {
		global $wpdb;
		$where   = array( 'kind=%s' );
		$args    = array( $kind );
		$allowed = array( 'connection_id', 'actor', 'state', 'task', 'record_id', 'owner', 'target', 'mode' );
		foreach ( $filters as $key => $value ) {
			if ( in_array( $key, $allowed, true ) ) {
				$where[] = "$key=%s";
				$args[]  = $value;
			} elseif ( 'id_prefix' === $key ) {
				$where[] = 'record_id LIKE %s';
				$args[]  = $wpdb->esc_like( (string) $value ) . '%';
			} elseif ( in_array( $key, array( 'due_before', 'sequence_after', 'sequence_before', 'expires_before', 'created_after', 'created_before' ), true ) ) {
				$column  = array(
					'due_before'      => 'due_at',
					'sequence_after'  => 'sequence',
					'sequence_before' => 'sequence',
					'expires_before'  => 'expires_at',
					'created_after'   => 'created_at',
					'created_before'  => 'created_at',
				)[ $key ];
				$where[] = $column . ( in_array( $key, array( 'sequence_after', 'created_after' ), true ) ? '>%d' : '<=%d' );
				$args[]  = (int) $value;
			}
		}
		$args[] = max( 1, min( 10000, $limit ) );
		$args[] = max( 0, $offset );
		$fields = $payload ? '*' : 'sequence,kind,record_id,connection_id,actor,state,task,target,mode,due_at,priority,created_at,updated_at,expires_at,owner,lease_until,generation,digest';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT ' . $fields . ' FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY sequence ' . ( $newest ? 'DESC' : 'ASC' ) . ' LIMIT %d OFFSET %d', $args ), ARRAY_A );
		return self::check() ?? $rows;
	}
	public static function count_filtered( string $kind, array $filters = array() ) {
		global $wpdb;
		$where = array( 'kind=%s' );
		$args  = array( $kind );
		foreach ( $filters as $key => $value ) {
			if ( in_array( $key, array( 'connection_id', 'state', 'task', 'actor' ), true ) ) {
				$where[] = $key . '=%s';
				$args[]  = $value;
			} elseif ( 'due_before' === $key ) {
				$where[] = 'due_at<=%d';
				$args[]  = (int) $value;
			}
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$n = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where ), $args ) );
		return self::check() ?? (int) $n;
	}
	public static function count( string $kind, ?string $state = null ) {
		global $wpdb;
		$sql  = 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE kind=%s';
		$args = array( $kind );
		if ( null !== $state ) {
			$sql   .= ' AND state=%s';
			$args[] = $state;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$n = $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
		return self::check() ?? (int) $n;
	}
	/** Select eligible or abandoned work using only indexed metadata. */
	public static function eligible( int $limit = 100, ?string $connection = null ): array|\WP_Error {
		global $wpdb;
		$sql  = 'SELECT record_id,connection_id,priority,due_at FROM ' . self::table() . " WHERE kind='job' AND state IN ('pending','running','dispatching') AND due_at<=%d AND (owner='' OR lease_until<=%d)";
		$args = array( time(), time() );
		if ( null !== $connection ) {
			$sql   .= ' AND connection_id=%s';
			$args[] = $connection;
		}
		$sql   .= ' ORDER BY due_at ASC,priority DESC,sequence ASC LIMIT %d';
		$args[] = max( 1, min( 1000, $limit ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
		return self::check() ?? $rows;
	}
	/** Public bootstrap needs one existence lookup, without hydrating job/schedule data. */
	public static function has_work(): bool|\WP_Error {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$found = $wpdb->get_var( 'SELECT 1 FROM ' . self::table() . " WHERE kind IN ('job','schedule') LIMIT 1" );
		return self::check() ?? null !== $found;
	}
	/** Commit an item and its cursor atomically while holding the worker's fence. */
	public static function commit_item( string $id, string $owner, int $generation, array $job, int $index, array $item ): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			return Response::fail( self::error( 'transaction', 'Transação indisponível.' ) );
		}
		try {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT owner,lease_until,generation FROM ' . self::table() . ' WHERE kind=%s AND record_id=%s FOR UPDATE', 'job', $id ), ARRAY_A );
			if ( ! $row || $row['owner'] !== $owner || (int) $row['lease_until'] <= time() || (int) $row['generation'] !== $generation ) {
				return Response::fail( self::error( 'conflict', 'Resultado recusado: a execução perdeu a propriedade da tarefa.' ) );
			}
			$item_id = \Fator3\McpGoogle\Automation\Results::id( $id, $index );
			$old     = self::get( 'item', $item_id );
			if ( is_wp_error( $old ) ) {
				return Response::fail( $old );
			}
			if ( null !== $old ) {
				return Response::fail( self::error( 'conflict', 'Resultado já confirmado; consulte o cursor durável.' ) );
			}
			if ( ! self::insert(
				'item',
				$item_id,
				array(
					'task'          => $id,
					'index'         => $index,
					'result'        => $item,
					'connection_id' => $job['connection_id'],
					'created_at'    => time(),
				)
			) ) {
				return Response::fail( self::error( 'write', 'Resultado não persistido.' ) );
			}
			$saved = self::put( 'job', $id, $job, $generation, $owner );
			if ( ! $saved['success'] ) {
				return $saved;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				return Response::fail( self::error( 'commit', 'Confirmação da transação indisponível; consulte o cursor durável.' ) );
			}
			return $saved;
		} finally {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
			$wpdb->query( 'ROLLBACK' );
		}
	}
	/** A table result and its metadata become visible in the same fenced transaction. */
	public static function commit_result( string $id, string $owner, int $generation, array $job, array $chunks ): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			return Response::fail( self::error( 'transaction', 'Transação indisponível.' ) );
		}
		try {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT owner,lease_until,generation FROM ' . self::table() . ' WHERE kind=%s AND record_id=%s FOR UPDATE', 'job', $id ), ARRAY_A );
			if ( ! $row || $row['owner'] !== $owner || (int) $row['lease_until'] <= time() || (int) $row['generation'] !== $generation ) {
				return Response::fail( self::error( 'conflict', 'Resultado recusado: lease ou revisão mudou.' ) );
			}
			foreach ( $chunks as $chunk_id => $chunk ) {
				if ( ! self::insert( 'result', $chunk_id, $chunk ) ) {
					return Response::fail( self::error( 'write', 'Resultado extenso não persistido.' ) );
				}
			}
			$saved = self::put( 'job', $id, $job, $generation, $owner );
			if ( ! $saved['success'] ) {
				return $saved;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				return Response::fail( self::error( 'commit', 'Confirmação indisponível; consulte o estado durável.' ) );
			}
			return $saved;
		} finally {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
			$wpdb->query( 'ROLLBACK' );
		}
	}
	public static function claim( string $kind, string $id, int $ttl = 60 ) {
		global $wpdb;
		$owner = bin2hex( random_bytes( 24 ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$n = $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET owner=%s,lease_until=%d,generation=generation+1 WHERE kind=%s AND record_id=%s AND (owner=%s OR lease_until<=%d)', $owner, time() + $ttl, $kind, $id, '', time() ) );
		return 1 === $n ? array(
			'owner' => $owner,
			'row'   => self::row( $kind, $id, false ),
		) : null;
	}
	public static function release( string $kind, string $id, string $owner ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET owner=%s,lease_until=0 WHERE kind=%s AND record_id=%s AND owner=%s', '', $kind, $id, $owner ) );
	}
	public static function renew( string $kind, string $id, string $owner, int $ttl = 60 ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		return 1 === $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET lease_until=GREATEST(lease_until+1,%d) WHERE kind=%s AND record_id=%s AND owner=%s AND lease_until>%d', time() + $ttl, $kind, $id, $owner, time() ) );
	}
}
