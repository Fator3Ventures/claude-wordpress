<?php
/**
 * Bounded audit window with exclusive revision and authenticated export.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Storage;

use Fator3\McpGoogle\{
	Ability, Audit, Confirmation, Connections, Options, Response, Sheets\Export
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class AuditReader {

	public static function page( array $input ): array {
		if ( ! Migration::active() ) {
			return Response::fail( new \WP_Error( 'f3_google_audit_migration', 'Conclua a migração para consultar revisões indexadas.' ) );
		}
		$limit   = max( 1, min( 100, (int) ( $input['limit'] ?? 30 ) ) );
		$filters = array( 'connection_id' => Connections::id() );
		if ( isset( $input['connection'] ) && Connections::id() !== $input['connection'] ) {
			return Response::fail( new \WP_Error( 'f3_google_audit_connection', 'Selecione a conexão da consulta explicitamente.' ) );
		}
		foreach ( array(
			'action'     => 'task',
			'target'     => 'target',
			'user'       => 'actor',
			'status'     => 'state',
			'mode'       => 'mode',
			'connection' => 'connection_id',
		) as $from => $to ) {
			if ( isset( $input[ $from ] ) ) {
				$filters[ $to ] = $input[ $from ];
			}
		}
		$dates = DateFilter::parse( $input, 'f3_google_audit_dates' );
		if ( is_wp_error( $dates ) ) {
			return Response::fail( $dates );
		}
		$filters += $dates;
		$since    = (string) ( $input['desde_revisao'] ?? '0' );
		$origin   = $since;
		$marker   = null;
		if ( isset( $input['cursor'] ) ) {
			$cursor = self::decode( (string) $input['cursor'] );
			if ( null === $cursor ) {
				return Response::fail( new \WP_Error( 'f3_google_audit_cursor', 'Cursor inválido ou expirado.' ) );
			}
			if ( array_diff_assoc( $filters, $cursor['filters'] ) || ( $cursor['connection_id'] ?? null ) !== Connections::id() || ( $cursor['actor'] ?? null ) !== get_current_user_id() ) {
				return Response::fail( new \WP_Error( 'f3_google_audit_cursor', 'Não altere filtros durante a paginação.' ) );
			}
			if ( isset( $input['desde_revisao'] ) && ( $cursor['requested_revision'] ?? $cursor['origin'] ) !== $input['desde_revisao'] ) {
				return Response::fail( new \WP_Error( 'f3_google_audit_cursor', 'Não altere a revisão durante a paginação.' ) );
			}
			$marker  = $cursor['configuration_marker'] ?? null;
			$filters = $cursor['filters'];
			$since   = $cursor['after'];
			$ceiling = $cursor['ceiling'];
			$origin  = $cursor['origin'] ?? $cursor['after'];
		} else {
			$resolved = self::resolve_revision( $since );
			if ( empty( $resolved['success'] ) ) {
				return $resolved;
			}
			$since  = $resolved['after'];
			$origin = $since;
			$marker = $resolved['configuration_marker'];
			$last   = Repository::select( 'audit', array( 'connection_id' => Connections::id() ), 1 );
			if ( is_wp_error( $last ) ) {
				return Response::fail( $last );
			}
			$ceiling = (string) ( $last[0]['sequence'] ?? 0 );
		}
		$rows = Repository::select(
			'audit',
			$filters + array(
				'sequence_after'  => (int) $since,
				'sequence_before' => (int) $ceiling,
			),
			$limit + 1,
			0,
			false,
			true
		);
		if ( is_wp_error( $rows ) ) {
			return Response::fail( $rows );
		}
		$more    = count( $rows ) > $limit;
		$rows    = array_slice( $rows, 0, $limit );
		$entries = array();
		$after   = $since;
		foreach ( $rows as $row ) {
			$value = json_decode( $row['payload'], true );
			if ( ! is_array( $value ) || ! hash_equals( $row['digest'], hash( 'sha256', $row['payload'] ) ) ) {
				return Response::fail( new \WP_Error( 'f3_google_audit_corrupt', 'Entrada de auditoria ilegível; cobertura incompleta.' ) );
			}
			$value             = Audit::redact( $value );
			$value['revision'] = (string) $row['sequence'];
			$entries[]         = $value;
			$after             = (string) $row['sequence'];
		}
		$first = Repository::select( 'audit', array( 'connection_id' => Connections::id() ), 1, 0, false );
		if ( is_wp_error( $first ) ) {
			return Response::fail( $first );
		}
		$health        = Audit::health();
		$gap           = (int) $origin < (int) get_option( 'f3_mcp_google_audit_removed_through', 0 );
		$window        = array(
			'filters'              => $filters,
			'origin'               => $origin,
			'requested_revision'   => $cursor['requested_revision'] ?? (string) ( $input['desde_revisao'] ?? '0' ),
			'configuration_marker' => $marker,
			'ceiling'              => $ceiling,
			'connection_id'        => Connections::id(),
			'actor'                => get_current_user_id(),
			'expires'              => time() + 3600,
		);
		$next          = $more ? self::encode( $window + array( 'after' => $after ) ) : null;
		$export_cursor = self::encode( $window + array( 'after' => $since ) );
		return Response::ok(
			array(
				'entries'              => $entries,
				'configuration_marker' => $marker,
				'coverage_start'       => isset( $first[0] ) ? array(
					'revision' => (string) $first[0]['sequence'],
					'time'     => gmdate( 'c', (int) $first[0]['created_at'] ),
				) : null,
				'legacy_association'   => 'unavailable',
				'count'                => count( $entries ),
				'desde_revisao'        => $origin,
				'page_after_revision'  => $since,
				'export_cursor'        => $export_cursor,
				'window_end_revision'  => $ceiling,
				'last_revision'        => $after,
				'next_cursor'          => $next,
				'complete'             => ! $more && ! $gap && 'no_failure_observed' === $health['state'],
				'audit_health'         => $health,
				'retention_gap'        => $gap,
				'capacity'             => Options::limit( Options::AUDIT_RETENTION ),
			)
		);
	}
	/** Resolve a hash only when exactly one retained, confirmed configuration event exists. */
	private static function resolve_revision( string $revision ): array {
		if ( preg_match( '/^[a-f0-9]{64}$/D', $revision ) ) {
			$filters = array( 'id_prefix' => $revision . '_' );
		} elseif ( preg_match( '/^event:([a-zA-Z0-9_-]{1,100})$/D', $revision, $match ) ) {
			$filters = array( 'record_id' => $match[1] );
		} elseif ( ctype_digit( $revision ) && strlen( $revision ) <= 18 ) {
			return array(
				'success'              => true,
				'after'                => $revision,
				'configuration_marker' => null,
			);
		} else {
			return Response::fail( new \WP_Error( 'f3_google_audit_revision', 'Use hash de configuração, marcador event: ou cursor decimal não negativo de até 18 dígitos.' ) );
		}
		$rows = Repository::select(
			'audit',
			$filters + array(
				'connection_id' => Connections::id(),
				'task'          => 'configuration:saved',
			),
			21,
			0,
			false
		);
		if ( is_wp_error( $rows ) ) {
			return Response::fail( $rows );
		}
		if ( ! $rows ) {
			return Response::fail(
				new \WP_Error( 'f3_google_audit_revision_unavailable', 'Marcador ausente, expurgado ou anterior ao registro de revisões. Não é possível reconstruir esta fronteira.' ),
				array(
					'complete'             => false,
					'coverage'             => 'unavailable',
					'configuration_marker' => null,
				)
			);
		}
		if ( count( $rows ) > 1 ) {
			return Response::fail(
				new \WP_Error( 'f3_google_audit_revision_ambiguous', 'A revisão possui mais de um marcador. Escolha explicitamente um identificador de evento.' ),
				array(
					'complete'             => false,
					'coverage'             => 'ambiguous',
					'candidates_truncated' => count( $rows ) > 20,
					'candidates'           => array_map(
						static fn ( $row ) => array(
							'marker'   => 'event:' . $row['record_id'],
							'revision' => (string) $row['sequence'],
							'time'     => gmdate( 'c', (int) $row['created_at'] ),
						),
						array_slice( $rows, 0, 20 )
					),
				)
			);
		}
		$row   = $rows[0];
		$entry = Repository::get( 'audit', $row['record_id'] );
		if ( is_wp_error( $entry ) ) {
			return Response::fail( $entry );
		}
		if ( ! is_array( $entry ) || empty( $entry['configuration_revision'] ) || empty( $entry['configuration_change_id'] ) || ! str_starts_with( $row['record_id'], $entry['configuration_revision'] . '_' ) ) {
			return Response::fail(
				new \WP_Error( 'f3_google_audit_revision_unavailable', 'Este evento não possui associação confirmada à configuração.' ),
				array(
					'complete' => false,
					'coverage' => 'unavailable',
				)
			);
		}
		return array(
			'success'              => true,
			'after'                => (string) $row['sequence'],
			'configuration_marker' => array(
				'marker'                  => 'event:' . $row['record_id'],
				'revision'                => (string) $row['sequence'],
				'configuration_revision'  => $entry['configuration_revision'],
				'configuration_change_id' => $entry['configuration_change_id'],
			),
		);
	}
	private static function encode( array $value ): string {
		$json = wp_json_encode( $value );
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Data transport encoding for a signed cursor or authenticated download; never executable PHP.
		return rtrim( strtr( base64_encode( $json ), '+/', '-_' ), '=' ) . '.' . hash_hmac( 'sha256', $json, wp_salt( 'nonce' ) );
	}
	private static function decode( string $cursor ): ?array {
		$parts = explode( '.', $cursor );
		if ( count( $parts ) !== 2 ) {
			return null;
		}
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Data transport encoding for a signed cursor or authenticated download; never executable PHP.
		$json = base64_decode( strtr( $parts[0], '-_', '+/' ), true );
		if ( ! is_string( $json ) || ! hash_equals( hash_hmac( 'sha256', $json, wp_salt( 'nonce' ) ), $parts[1] ) ) {
			return null;
		}
		$v = json_decode( $json, true );
		return is_array( $v ) && ( $v['expires'] ?? 0 ) >= time() ? $v : null;
	}
	public static function export( array $input ): array {
		$format = $input['format'] ?? 'json';
		if ( ! in_array( $format, array( 'json', 'csv' ), true ) ) {
			return Response::fail( new \WP_Error( 'f3_google_audit_format', 'Use json ou csv.' ) );
		}
		$page = self::page( $input );
		if ( ! $page['success'] ) {
			return $page;
		}
		if ( 'json' === $format ) {
			$text = wp_json_encode( $page['entries'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
		} else {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- In-memory php://temp stream for CSV encoding; no filesystem or remote target.
			$fp     = fopen( 'php://temp', 'r+' );
			$fields = array( 'revision', 'id', 'time', 'action', 'target', 'user', 'connection_id', 'plugin_version', 'configuration_revision', 'configuration_change_id', 'extra' );
			fputcsv( $fp, $fields );
			foreach ( $page['entries'] as $entry ) {
				$row = array();
				foreach ( $fields as $field ) {
					$value = $entry[ $field ] ?? '';
					$value = is_array( $value ) ? wp_json_encode( $value, JSON_UNESCAPED_UNICODE ) : (string) $value;
					$row[] = preg_match( '/^[\s\x00-\x1f]*[=+@-]/u', $value ) ? "'" . $value : $value;
				}
				fputcsv( $fp, $row );
			}
			rewind( $fp );
			$text = stream_get_contents( $fp );
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- In-memory php://temp stream for CSV encoding; no filesystem or remote target.
			fclose( $fp );
		}
		unset( $page['entries'] );
		return $page + array(
			'format'         => $format,
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Data transport encoding for a signed cursor or authenticated download; never executable PHP.
			'content_base64' => base64_encode( $text ),
			'bytes'          => strlen( $text ),
			'sha256'         => hash( 'sha256', $text ),
			'filename'       => 'google-audit-' . $page['window_end_revision'] . '.' . $format,
			'delivery'       => 'authenticated_response',
		);
	}
	/** Export one stable, authorized audit page through the literal-cell Sheets writer. */
	public static function to_sheet( array $input ): array {
		$required = Confirmation::require_confirmation();
		if ( null !== $required ) {
			return Response::fail( $required );
		}
		if ( empty( $input['cursor'] ) ) {
			return Response::fail( new \WP_Error( 'f3_google_audit_window', 'Consulte google/audit e informe export_cursor para fixar a janela.' ) );
		}
		$page = self::page(
			array(
				'cursor' => $input['cursor'],
				'limit'  => $input['limit'] ?? 100,
			)
		);
		if ( ! $page['success'] ) {
			return $page;
		}
		$fields = array( 'revision', 'id', 'time', 'action', 'target', 'user', 'connection_id', 'plugin_version', 'configuration_revision', 'configuration_change_id', 'extra' );
		$rows   = array();
		foreach ( $page['entries'] as $entry ) {
			$row = array();
			foreach ( $fields as $field ) {
				$value = $entry[ $field ] ?? '';
				$row[] = is_array( $value ) ? wp_json_encode( $value, JSON_UNESCAPED_UNICODE ) : $value;
			}
			$rows[] = $row;
		}
		$table       = array(
			'success'   => true,
			'columns'   => array_map(
				static fn ( $field ) => array(
					'id'    => $field,
					'label' => $field,
					'type'  => 'dimension',
					'kind'  => 'string',
				),
				$fields
			),
			'rows'      => $rows,
			'row_count' => count( $rows ),
			'accounts'  => array(),
		);
		$destination = array_intersect_key( $input, array_flip( array( 'spreadsheet_id', 'title', 'tab_name', 'mode', 'shared_drive_folder_id', 'share_with', 'share_role' ) ) );
		$result      = Export::from_tables( $destination, array( $table ) );
		return $result + array(
			'audit_window'           => array_intersect_key( $page, array_flip( array( 'desde_revisao', 'window_end_revision', 'last_revision', 'next_cursor', 'complete', 'retention_gap' ) ) ),
			'audit_entries_exported' => ! empty( $result['success'] ) ? count( $rows ) : null,
		);
	}
	public static function register(): void {
		Ability::register(
			'google/audit-to-sheet',
			'sheets',
			array(
				'label'        => 'Google: exportar auditoria para Sheets',
				'description'  => 'Exporta até 100 eventos de uma janela fixada por export_cursor, com células literais e política do destino. Exige google/prepare-operation. Retorna próximo cursor e cobertura; não altera google/audit.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'cursor' ),
					'properties' => array(
						'cursor'                 => array( 'type' => 'string' ),
						'limit'                  => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
						),
						'spreadsheet_id'         => array( 'type' => 'string' ),
						'shared_drive_folder_id' => array( 'type' => 'string' ),
						'title'                  => array( 'type' => 'string' ),
						'tab_name'               => array( 'type' => 'string' ),
						'mode'                   => array(
							'type' => 'string',
							'enum' => array( 'replace', 'append' ),
						),
						'share_with'             => array(
							'type'  => 'array',
							'items' => array( 'type' => 'string' ),
						),
						'share_role'             => array(
							'type' => 'string',
							'enum' => array( 'reader', 'commenter', 'writer' ),
						),
					),
				),
				'callback'     => array( self::class, 'to_sheet' ),
			)
		);
		Ability::register(
			'google/audit-export',
			'any',
			array(
				'label'        => 'Google: exportar auditoria',
				'description'  => 'Exportação paginada JSON ou CSV pela resposta autenticada. Sem arquivo público. CSV neutraliza fórmulas. Use next_cursor para completar a janela.',
				'input_schema' => array(
					'properties' => array(
						'format'        => array(
							'type' => 'string',
							'enum' => array( 'json', 'csv' ),
						),
						'desde_revisao' => array(
							'type'        => 'string',
							'description' => 'Hash de configuração, marcador event: ou cursor decimal exclusivo.',
						),
						'cursor'        => array( 'type' => 'string' ),
						'limit'         => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
						),
						'action'        => array( 'type' => 'string' ),
						'target'        => array( 'type' => 'string' ),
						'user'          => array( 'type' => 'integer' ),
						'status'        => array( 'type' => 'string' ),
						'mode'          => array( 'type' => 'string' ),
						'from'          => array( 'type' => 'string' ),
						'to'            => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'export' ),
			)
		);
	}
}
