<?php
/**
 * Strict UTC/date-time windows shared by local history readers.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Storage;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class DateFilter {

	public static function parse( array $input, string $error_code = 'f3_google_dates' ): array|\WP_Error {
		$filters = array();
		foreach ( array(
			'from' => 'created_after',
			'to'   => 'created_before',
		) as $key => $field ) {
			if ( ! isset( $input[ $key ] ) ) {
				continue;
			}
			$text = (string) $input[ $key ];
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $text ) ) {
				$text .= 'to' === $key ? 'T23:59:59Z' : 'T00:00:00Z';
			}
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-](?:0\d|1[0-4]):[0-5]\d)$/D', $text ) ) {
				return new \WP_Error( $error_code, 'Use uma data válida YYYY-MM-DD ou RFC3339 com fuso horário.' );
			}
			try {
				$date   = new \DateTimeImmutable( $text );
				$errors = \DateTimeImmutable::getLastErrors();
				if ( false !== $errors && ( $errors['warning_count'] || $errors['error_count'] ) ) {
					throw new \InvalidArgumentException();
				}
				$filters[ $field ] = $date->getTimestamp() - ( 'from' === $key ? 1 : 0 );
			} catch ( \Throwable $error ) {
				return new \WP_Error( $error_code, 'Datas inválidas.' );
			}
		}
		if ( isset( $filters['created_after'], $filters['created_before'] ) && $filters['created_after'] >= $filters['created_before'] ) {
			return new \WP_Error( $error_code, 'O início não pode ser posterior ao fim.' );
		}
		return $filters;
	}
}
