<?php
/**
 * Credential preparation and explicit activation shared by every admin entry point.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Auth;

use Fator3\McpGoogle\{Options, Settings, Connections, Response};
use Fator3\McpGoogle\Http\GoogleClient;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Configuration {

	public const JSON_MAX_BYTES = 1048576;
	private static function fail( string $code, string $message ): array {
		return Response::fail(
			new \WP_Error( $code, $message ),
			array(
				'persisted' => false,
				'changed'   => false,
			)
		);
	}
	public static function import( string $json, ?string $method = null, bool $activate = false, ?string $expected = null ): array {
		if ( strlen( $json ) > self::JSON_MAX_BYTES ) {
			return self::fail( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' );
		}
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			return self::fail( 'f3_google_credential_json', 'JSON inválido. Envie o arquivo de credenciais completo.' );
		}
		$detected = ( $data['type'] ?? '' ) === 'service_account' ? 'service_account' : ( isset( $data['web'] ) ? 'oauth' : '' );
		if ( '' === $detected || ( null !== $method && $method !== $detected ) ) {
			return self::fail( 'f3_google_credential_type', 'O tipo do JSON não corresponde ao método selecionado. Abra a aba correspondente ao arquivo.' );
		}
		if ( 'service_account' === $detected ) {
			return self::save_sa( $json, null, $activate, $expected );
		}
		$web = $data['web'];
		if ( ! is_array( $web ) || ! is_string( $web['client_id'] ?? null ) || ! is_string( $web['client_secret'] ?? null ) || '' === $web['client_id'] || '' === $web['client_secret'] ) {
			return self::fail( 'f3_google_oauth_client_json', 'Envie o JSON de um cliente OAuth do tipo aplicativo Web.' );
		}
		if ( ! in_array( OAuthFlow::redirect_uri(), (array) ( $web['redirect_uris'] ?? array() ), true ) ) {
			return self::fail( 'f3_google_oauth_redirect', 'Cadastre o callback exibido na aba OAuth no cliente Web e baixe o JSON atualizado.' );
		}
		return self::save_oauth( $web['client_id'], $web['client_secret'], $expected );
	}
	public static function save_sa( string $json, ?string $subject = null, bool $activate = false, ?string $expected = null ): array {
		if ( ! current_user_can( Options::capability() ) ) {
			return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' );
		}
		$revision = $expected ?? Settings::revision();
		if ( is_wp_error( $revision ) ) {
			return Response::fail( $revision );
		}
		if ( strlen( $json ) > self::JSON_MAX_BYTES ) {
			return self::fail( 'f3_google_credential_size', 'O JSON excede o limite de 1 MiB.' );
		}
		$prior = Candidate::read( 'service_account' );
		if ( is_wp_error( $prior ) ) {
			return Response::fail( $prior );
		}
		$values  = $prior['values'] ?? array( Options::SA_SUBJECT => Options::get( Options::SA_SUBJECT, '' ) );
		$secrets = $prior['secrets'] ?? array( Options::SA_JSON => Options::get_secret( Options::SA_JSON ) );
		if ( null !== $subject ) {
			if ( '' !== $subject && ! is_email( $subject ) ) {
				return self::fail( 'f3_google_sa_subject', 'Informe e-mail válido.' );
			} $values[ Options::SA_SUBJECT ] = $subject;
		}
		if ( '' !== trim( $json ) ) {
			$key = ServiceAccount::validate_key( $json );
			if ( is_wp_error( $key ) ) {
				return Response::fail( $key );
			} $secrets[ Options::SA_JSON ] = wp_json_encode( $key );
		}
		if ( '' === ( $secrets[ Options::SA_JSON ] ?? '' ) ) {
			return self::fail( 'f3_google_candidate_missing', 'Importe uma chave antes de ativar.' );
		}
		$saved = Candidate::save( 'service_account', $values, $secrets, $revision );
		return $activate && ! empty( $saved['success'] ) ? Candidate::promote( 'service_account', $saved['revision'] ) : $saved;
	}
	public static function save_oauth( string $id, string $secret, ?string $expected = null ): array {
		if ( ! current_user_can( Options::capability() ) ) {
			return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' );
		}
		if ( '' === trim( $id ) ) {
			return self::fail( 'f3_google_oauth_client', 'Informe o Client ID do aplicativo Web.' );
		}
		$prior = Candidate::read( 'oauth' );
		if ( is_wp_error( $prior ) ) {
			return Response::fail( $prior );
		}
		$values  = $prior['values'] ?? array(
			Options::OAUTH_CLIENT_ID => Options::get( Options::OAUTH_CLIENT_ID, '' ),
			Options::OAUTH_EMAIL     => Options::get( Options::OAUTH_EMAIL, '' ),
			Options::OAUTH_SCOPES    => Options::get( Options::OAUTH_SCOPES, array() ),
		);
		$secrets = $prior['secrets'] ?? array(
			Options::OAUTH_CLIENT_SECRET => Options::get_secret( Options::OAUTH_CLIENT_SECRET ),
			Options::OAUTH_REFRESH_TOKEN => Options::get_secret( Options::OAUTH_REFRESH_TOKEN ),
		);
		if ( $id !== $values[ Options::OAUTH_CLIENT_ID ] || ( '' !== $secret && $secret !== $secrets[ Options::OAUTH_CLIENT_SECRET ] ) ) {
			unset( $secrets[ Options::OAUTH_REFRESH_TOKEN ], $values[ Options::OAUTH_EMAIL ], $values[ Options::OAUTH_SCOPES ] );
		}
		$values[ Options::OAUTH_CLIENT_ID ] = $id;
		if ( '' !== $secret ) {
			$secrets[ Options::OAUTH_CLIENT_SECRET ] = $secret;
		}
		return Candidate::save( 'oauth', $values, $secrets, $expected );
	}
	public static function activate( string $mode, ?string $expected = null ): array {
		if ( ! in_array( $mode, Options::AUTH_MODES, true ) ) {
			return self::fail( 'f3_google_auth_mode', 'Método inválido.' );
		}
		return Candidate::promote( $mode, $expected );
	}
	public static function clear( string $mode, ?string $expected = null ): array {
		if ( ! current_user_can( Options::capability() ) ) {
			return self::fail( 'f3_google_forbidden', 'Permissão insuficiente.' );
		}
		if ( ! in_array( $mode, Options::AUTH_MODES, true ) ) {
			return self::fail( 'f3_google_auth_mode', 'Método inválido.' );
		}
		$names   = 'service_account' === $mode ? array( Options::SA_JSON, Options::SA_SUBJECT ) : array( Options::OAUTH_CLIENT_ID, Options::OAUTH_CLIENT_SECRET, Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES );
		$names[] = Candidate::name( $mode );
		return Settings::save( array(), array(), $names, $expected );
	}
}
