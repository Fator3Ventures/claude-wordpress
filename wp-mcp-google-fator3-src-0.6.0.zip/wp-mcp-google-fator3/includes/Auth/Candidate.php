<?php
/**
 * Encrypted candidates never replace the active credential before validation.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Auth;

use Fator3\McpGoogle\{Connections, Options, Preflight, Response, Settings};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Candidate {

	public const SA    = 'f3_mcp_google_candidate_sa';
	public const OAUTH = 'f3_mcp_google_candidate_oauth';
	public static function name( string $mode ): string {
		return 'service_account' === $mode ? self::SA : self::OAUTH;
	}
	public static function read( string $mode ) {
		$name  = self::name( $mode );
		$error = Options::secret_problem( $name );
		if ( null !== $error ) {
			return $error;
		}$json = Options::get_secret( $name );
		if ( '' === $json ) {
			return null;
		}$data = json_decode( $json, true );
		return is_array( $data ) && ( $data['mode'] ?? null ) === $mode ? $data : new \WP_Error( 'f3_google_candidate_corrupt', 'Credencial candidata ilegível.' );
	}
	public static function state( string $mode ): array {
		$data = self::read( $mode );
		return array(
			'present'  => null !== $data,
			'readable' => ! is_wp_error( $data ),
			'ready'    => is_array( $data ) && ( 'service_account' === $mode ? ! empty( $data['secrets'][ Options::SA_JSON ] ) : ! empty( $data['secrets'][ Options::OAUTH_REFRESH_TOKEN ] ) ),
			'revision' => is_array( $data ) ? $data['revision'] : null,
			'identity' => is_array( $data ) ? self::identity( $data ) : null,
		);
	}
	private static function identity( array $data ): ?string {
		if ( 'oauth' === $data['mode'] ) {
			return $data['values'][ Options::OAUTH_EMAIL ] ?? null;
		}$key = json_decode( $data['secrets'][ Options::SA_JSON ] ?? '', true );
		return $key['client_email'] ?? null;
	}
	public static function save( string $mode, array $values, array $secrets, ?string $expected = null ): array {
		$old = self::read( $mode );
		if ( is_array( $old ) && $old['values'] === $values && $old['secrets'] === $secrets ) {
			return Settings::save( array(), array(), array(), $expected ) + array(
				'candidate' => self::state( $mode ),
				'activated' => false,
			);
		}
		$data   = array(
			'mode'       => $mode,
			'values'     => $values,
			'secrets'    => $secrets,
			'revision'   => bin2hex( random_bytes( 16 ) ),
			'created_at' => time(),
		);
		$result = Settings::save( array(), array( self::name( $mode ) => wp_json_encode( $data ) ), array(), $expected );
		return $result + array(
			'candidate' => self::state( $mode ),
			'activated' => false,
		);
	}
	public static function preview( array $data, callable $callback ) {
		return Connections::preview_credentials(
			$data['values'] + array(
				Options::AUTH_MODE   => $data['mode'],
				Settings::AUTH_READY => true,
			),
			$data['secrets'],
			$callback
		);
	}
	public static function promote( string $mode, ?string $expected = null ): array {
		if ( ! current_user_can( Options::capability() ) ) {
			return Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão insuficiente.' ) );
		}
		$revision = Settings::revision();
		if ( is_wp_error( $revision ) ) {
			return Response::fail( $revision );
		}if ( null !== $expected && ! hash_equals( $revision, $expected ) ) {
			return Settings::conflict();
		}
		$data = self::read( $mode );
		if ( is_wp_error( $data ) ) {
			return Response::fail( $data );
		}if ( null === $data ) {
			return Response::fail( new \WP_Error( 'f3_google_candidate_missing', 'Prepare uma credencial candidata antes de ativar.' ) );
		}
		if ( apply_filters( 'f3_mcp_google_auth_mode', $mode ) !== $mode ) {
			return Response::fail( new \WP_Error( 'f3_google_auth_override', 'Método controlado por código.' ) );
		}
		$checked = self::preview(
			$data,
			static function (): array {
				$provider = Credentials::current();
				if ( is_wp_error( $provider ) ) {
					return Response::fail( $provider );
				}$token = $provider->get_access_token( Credentials::scopes_for( 'any' ) );
				if ( is_wp_error( $token ) || ! is_string( $token ) || '' === $token ) {
					return Response::fail( is_wp_error( $token ) ? $token : new \WP_Error( 'f3_google_token', 'Token inválido.' ) );
				}
				$bindings = (array) Options::get( Connections::BINDINGS, array() );
				$services = array();
				foreach ( array(
					'ga_property_id'  => 'ga',
					'ads_customer_id' => 'ads',
					'gsc_site_url'    => 'gsc',
					'spreadsheet_id'  => 'sheets',
				) as $key => $service ) {
					if ( ! empty( $bindings[ $key ] ) ) {
						$services[] = $service;
					}
				}
				if ( ! $services ) {
					return Response::ok(
						array(
							'authentication_validated'  => true,
							'resource_access_validated' => false,
							'resource_validation'       => 'no_bindings',
						)
					);
				}
				$test = Preflight::run(
					array(
						'services' => $services,
						'bindings' => $bindings,
					)
				);
				if ( empty( $test['all_checks_passed'] ) ) {
					return Response::fail(
						new \WP_Error( 'f3_google_candidate_access', 'A candidata não confirmou acesso aos recursos vinculados; credencial ativa preservada.' ),
						array(
							'preflight'                 => $test,
							'resource_access_validated' => false,
						)
					);
				}
				return Response::ok(
					array(
						'authentication_validated'  => true,
						'resource_access_validated' => true,
						'preflight'                 => $test,
					)
				);
			}
		);
		$current = Settings::revision();
		if ( is_wp_error( $current ) ) {
			return Response::fail( $current );
		}if ( ! hash_equals( $revision, $current ) ) {
			return Settings::conflict() + array( 'active_preserved' => true );
		}
		if ( ! $checked['success'] ) {
			return $checked + array(
				'persisted'        => false,
				'active_preserved' => true,
			);
		}
		$values = $data['values'] + array(
			Options::AUTH_MODE   => $mode,
			Settings::AUTH_READY => true,
		);
		$saved  = Settings::save( $values, $data['secrets'], array( self::name( $mode ) ), $revision );
		return $saved + array(
			'authentication_validated'  => true,
			'resource_access_validated' => $checked['resource_access_validated'],
			'activated'                 => ! empty( $saved['success'] ),
			'auth_mode'                 => $mode,
		);
	}
	public static function oauth_value( string $name, bool $secret = false ): string {
		$data = self::read( 'oauth' );
		if ( is_array( $data ) ) {
			return (string) ( $data[ $secret ? 'secrets' : 'values' ][ $name ] ?? '' );
		}return $secret ? Options::get_secret( $name ) : (string) Options::get( $name, '' );
	}
}
