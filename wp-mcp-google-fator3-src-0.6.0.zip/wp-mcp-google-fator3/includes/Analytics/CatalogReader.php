<?php
/**
 * Complete Admin API lists shared by profiles and resource binding.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Analytics;

use Fator3\McpGoogle\Generic\ExecuteAction;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class CatalogReader {

	public static function list( string $method, array $path, string $key, string $api = 'analytics-admin-v1beta' ) {
		$items = array();
		$seen  = array();
		$token = '';
		for ( $page = 0; $page < 100; ++$page ) {
			$query = array( 'pageSize' => 200 );
			if ( '' !== $token ) {
				$query['pageToken'] = $token;
			}
			$r = ExecuteAction::call( $api, 'analyticsadmin.' . $method, $path, $query, null, array( 'mode' => 'read' ) );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			if ( isset( $r[ $key ] ) && ! is_array( $r[ $key ] ) ) {
				return new \WP_Error( 'f3_google_catalog_shape', 'Listagem com formato inesperado.' );
			}
			foreach ( $r[ $key ] ?? array() as $item ) {
				$items[] = $item;
			}
			$token = (string) ( $r['nextPageToken'] ?? '' );
			if ( '' === $token ) {
				return $items;
			}
			if ( isset( $seen[ $token ] ) ) {
				return new \WP_Error( 'f3_google_pagination', 'A API repetiu um page token; catálogo incompleto.' );
			}
			$seen[ $token ] = true;
		}
		return new \WP_Error( 'f3_google_pagination_limit', 'Catálogo excedeu 100 páginas; nenhum vínculo foi escolhido.' );
	}
}
