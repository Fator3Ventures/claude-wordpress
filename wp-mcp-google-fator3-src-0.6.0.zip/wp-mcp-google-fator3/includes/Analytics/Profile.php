<?php
/**
 * Generic, explicit GA4 desired state. No agency policy or property creation.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Analytics;

use Fator3\McpGoogle\{
	Ability, Auth\Credentials, Connections, Generic\ExecuteAction, Lock, Operation, Options, Records, Response, Settings
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Profile {

	public const VERSION   = '1.0.0';
	private const SETTINGS = array(
		'retention'            => array( 'DataRetentionSettings', 'dataRetentionSettings', false, 'v1beta' ),
		'enhanced_measurement' => array( 'EnhancedMeasurementSettings', 'enhancedMeasurementSettings', true, 'v1alpha' ),
		'google_signals'       => array( 'GoogleSignalsSettings', 'googleSignalsSettings', false, 'v1alpha' ),
		'data_redaction'       => array( 'DataRedactionSettings', 'dataRedactionSettings', true, 'v1alpha' ),
		'attribution'          => array( 'AttributionSettings', 'attributionSettings', false, 'v1alpha' ),
	);
	public static function schema(): array {
		static $schema;
		$schema = $schema ?? require __DIR__ . '/../Data/ProfileSchema.php';
		return $schema;
	}
	public static function validate( $profile ) {
		if ( ! is_array( $profile ) || ! $profile || ( $profile['schema_version'] ?? self::VERSION ) !== self::VERSION ) {
			return self::error( 'Perfil exige objeto não vazio e schema_version 1.0.0.' );
		}
		$schema = self::schema();
		foreach ( $profile as $section => $value ) {
			if ( 'schema_version' === $section ) {
				continue;
			}
			if ( ! isset( $schema[ $section ] ) ) {
				return self::error( 'Seção desconhecida: ' . $section );
			}
			$issue = self::shape( $value, $schema[ $section ], $section );
			if ( null !== $issue ) {
				return self::error( $issue );
			}
			if ( in_array( $section, array( 'custom_dimensions', 'custom_metrics' ), true ) ) {
				$seen = array();
				foreach ( $value as $definition ) {
					$key = $definition['scope'] . ':' . $definition['parameterName'];
					if ( isset( $seen[ $key ] ) ) {
						return self::error( 'Definição duplicada: ' . $key );
					}
					$seen[ $key ] = true;
					$max          = 'USER' === $definition['scope'] ? 24 : 40;
					if ( ! preg_match( '/^[A-Za-z][A-Za-z0-9_]{0,' . ( $max - 1 ) . '}$/D', $definition['parameterName'] ) ) {
						return self::error( 'parameterName inválido: ' . $key );
					}
					if ( ! preg_match( '/^\p{L}[\p{L}\p{N}_ ]{0,81}$/uD', $definition['displayName'] ) ) {
						return self::error( 'displayName exige 1–82 letras, números, espaços ou sublinhados.' );
					}
					if ( isset( $definition['disallowAdsPersonalization'] ) && 'USER' !== $definition['scope'] ) {
						return self::error( 'disallowAdsPersonalization só é aplicável ao escopo USER.' );
					}
					if ( 'CURRENCY' === ( $definition['measurementUnit'] ?? '' ) && empty( $definition['restrictedMetricType'] ) ) {
						return self::error( 'Métrica CURRENCY exige restrictedMetricType.' );
					}
					if ( ! empty( $definition['restrictedMetricType'] ) && 'CURRENCY' !== ( $definition['measurementUnit'] ?? '' ) ) {
						return self::error( 'restrictedMetricType exige measurementUnit CURRENCY.' );
					}
				}
			}
		}
		if ( count( array_diff( array_keys( $profile ), array( 'schema_version' ) ) ) === 0 ) {
			return self::error( 'Selecione ao menos uma seção do perfil.' );
		}
		return $profile;
	}
	private static function shape( $value, array $schema, string $path ): ?string {
		$type  = $schema['type'] ?? 'object';
		$valid = array(
			'object'  => is_array( $value ),
			'array'   => is_array( $value ) && array_values( $value ) === $value,
			'string'  => is_string( $value ),
			'boolean' => is_bool( $value ),
			'integer' => is_int( $value ),
			'number'  => is_int( $value ) || is_float( $value ),
		)[ $type ] ?? false;
		if ( ! $valid || ( isset( $schema['enum'] ) && ! in_array( $value, $schema['enum'], true ) ) ) {
			return 'Tipo ou valor inválido: ' . $path;
		}
		if ( is_string( $value ) && mb_strlen( $value ) > ( $schema['maxLength'] ?? 4096 ) ) {
			return 'Texto excede limite: ' . $path;
		}
		if ( 'object' === $type ) {
			foreach ( $schema['required'] ?? array() as $key ) {
				if ( ! array_key_exists( $key, $value ) ) {
					return 'Campo obrigatório: ' . $path . '.' . $key;
				}
			}
			foreach ( $value as $key => $item ) {
				if ( ! isset( $schema['properties'][ $key ] ) ) {
					return 'Campo não configurável: ' . $path . '.' . $key;
				}
				$issue = self::shape( $item, $schema['properties'][ $key ], $path . '.' . $key );
				if ( null !== $issue ) {
					return $issue;
				}
			}
		}
		if ( 'array' === $type ) {
			if ( count( $value ) > 100 ) {
				return 'Limite de 100 itens: ' . $path;
			}
			foreach ( $value as $i => $item ) {
				$issue = self::shape( $item, $schema['items'], $path . '.' . $i );
				if ( null !== $issue ) {
					return $issue;
				}
			}
		}
		return null;
	}
	public static function plan( array $input ): array {
		$property = PropertyId::normalize( $input['property_id'] ?? '' );
		if ( is_wp_error( $property ) ) {
			return Response::fail( $property );
		}
		if ( isset( $input['profile'], $input['profile_id'] ) ) {
			return Response::fail( self::error( 'Escolha profile ou profile_id.' ) );
		}
		$profile = $input['profile'] ?? ( isset( $input['profile_id'] ) ? ( Records::get( 'profile', self::id( (string) $input['profile_id'] ) )['profile'] ?? null ) : null );
		$profile = self::validate( $profile );
		if ( is_wp_error( $profile ) ) {
			return Response::fail( $profile );
		}
		$stream_id = (string) ( $input['stream_id'] ?? '' );
		$stream    = preg_match( '/^[0-9]+$/D', $stream_id ) ? $property . '/dataStreams/' . $stream_id : $stream_id;
		if ( '' !== $stream && ! preg_match( '~^' . preg_quote( $property, '~' ) . '/dataStreams/[0-9]+$~D', $stream ) ) {
			return Response::fail( self::error( 'stream_id deve pertencer à propriedade.' ) );
		}
		foreach ( self::SETTINGS as $section => $meta ) {
			if ( isset( $profile[ $section ] ) && $meta[2] && '' === $stream ) {
				return Response::fail( self::error( 'stream_id obrigatório para ' . $section ) );
			}
		}
		$revision = Settings::revision();
		if ( is_wp_error( $revision ) ) {
			return Response::fail( $revision );
		}
		$property_data = ExecuteAction::call( 'analytics-admin-v1beta', 'analyticsadmin.properties.get', array( 'name' => $property ), array(), null, array( 'mode' => 'read' ) );
		if ( is_wp_error( $property_data ) ) {
			return Response::fail( $property_data );
		}
		$streams = CatalogReader::list( 'properties.dataStreams.list', array( 'parent' => $property ), 'dataStreams' );
		if ( is_wp_error( $streams ) ) {
			return Response::fail( $streams );
		}
		if ( '' !== $stream && ! in_array( $stream, array_column( $streams, 'name' ), true ) ) {
			return Response::fail( self::error( 'Stream não encontrado na propriedade acessível.' ) );
		}
		$selected = null;
		foreach ( $streams as $candidate ) {
			if ( ( $candidate['name'] ?? '' ) === $stream ) {
				$selected = $candidate;
				break;
			}
		}
		if ( null !== $selected && ( $selected['type'] ?? ( isset( $selected['webStreamData'] ) ? 'WEB_DATA_STREAM' : '' ) ) !== 'WEB_DATA_STREAM' ) {
			return Response::fail( self::error( 'O perfil exige um stream Web para configurações de medição e redação.' ) );
		}
		$changes  = array();
		$observed = array();
		$checks   = array();
		$enabled  = null;
		$complete = true;
		foreach ( self::SETTINGS as $section => [ $suffix, $resource, $is_stream, $version ] ) {
			// Conformidade always observes streamEnabled, including false, without forcing a desired value.
			if ( ! isset( $profile[ $section ] ) && ! ( 'enhanced_measurement' === $section && '' !== $stream ) ) {
				continue;
			}
			$name   = ( $is_stream ? $stream : $property ) . '/' . $resource;
			$prefix = 'analyticsadmin.properties.' . ( $is_stream ? 'dataStreams.' : '' );
			$before = ExecuteAction::call( 'analytics-admin-' . $version, $prefix . 'get' . $suffix, array( 'name' => $name ), array(), null, array( 'mode' => 'read' ) );
			if ( is_wp_error( $before ) ) {
				$complete = false;
				$checks[] = self::unverified( $section, $before );
				continue;
			}
			$observed[ $section ] = $before;
			if ( 'enhanced_measurement' === $section ) {
				$enabled = $before['streamEnabled'] ?? null;
			}
			$diff     = self::fields( $profile[ $section ] ?? array(), $before );
			$checks[] = array(
				'section'  => $section,
				'status'   => $diff ? 'different' : 'already',
				'desired'  => $profile[ $section ] ?? null,
				'observed' => $before,
			);
			if ( $diff ) {
				$changes[] = self::change( $section, 'analytics-admin-' . $version, $prefix . 'update' . $suffix, array( 'name' => $name ), $diff, $before, 'update', 'retention' === $section && self::reduces( $before, $diff ) );
			}
		}
		foreach ( array(
			'custom_dimensions' => 'customDimensions',
			'custom_metrics'    => 'customMetrics',
		) as $section => $resource ) {
			if ( ! isset( $profile[ $section ] ) ) {
				continue;
			}
			$items = CatalogReader::list( 'properties.' . $resource . '.list', array( 'parent' => $property ), $resource );
			if ( is_wp_error( $items ) ) {
				$complete = false;
				$checks[] = self::unverified( $section, $items );
				continue;
			}
			$observed[ $section ] = $items;
			$index                = array();
			foreach ( $items as $item ) {
				$key = ( $item['scope'] ?? '' ) . ':' . ( $item['parameterName'] ?? '' );
				if ( isset( $index[ $key ] ) ) {
					return Response::fail( self::error( 'Catálogo ambíguo: ' . $key ) );
				}
				$index[ $key ] = $item;
			}
			foreach ( $profile[ $section ] as $wanted ) {
				$key      = $wanted['scope'] . ':' . $wanted['parameterName'];
				$before   = $index[ $key ] ?? null;
				$body     = null === $before ? $wanted : self::fields( $wanted, $before );
				$checks[] = array(
					'section'  => $section . ':' . $key,
					'status'   => null === $before ? 'missing' : ( $body ? 'different' : 'already' ),
					'desired'  => $wanted,
					'observed' => $before,
				);
				if ( $body ) {
					unset( $body['name'] );
					if ( null !== $before ) {
						unset( $body['scope'], $body['parameterName'] );
					}
					if ( $body ) {
						$changes[] = self::change( $section . ':' . $key, 'analytics-admin-v1beta', 'analyticsadmin.properties.' . $resource . ( null === $before ? '.create' : '.patch' ), null === $before ? array( 'parent' => $property ) : array( 'name' => $before['name'] ), $body, $before, null === $before ? 'create' : 'update' );
					}
				}
			}
		}
		$auth = array(
			'configured'      => Credentials::is_configured(),
			'access_bindings' => array(
				'status'      => 'not_requested',
				'http_status' => null,
			),
			'role'            => null,
			'role_verified'   => false,
			'scopes'          => array(
				'requested' => Credentials::scopes_for( 'ga' ),
				'granted'   => 'oauth' === Options::auth_mode() ? (array) Options::get( Options::OAUTH_SCOPES, array() ) : null,
				'source'    => 'oauth' === Options::auth_mode() ? 'stored_oauth_consent' : 'service_account_requested_scopes',
			),
		);
		if ( ! empty( $input['check_access_bindings'] ) && ! \Fator3\McpGoogle\Confirmation::capturing() ) {
			$access = CatalogReader::list( 'properties.accessBindings.list', array( 'parent' => $property ), 'accessBindings', 'analytics-admin-v1alpha' );
			if ( is_wp_error( $access ) ) {
				$data                    = (array) $access->get_error_data();
				$status                  = (int) ( $data['http_status'] ?? $data['status'] ?? 0 );
				$auth['access_bindings'] = array(
					'status'        => 403 === $status ? 'permission_denied' : 'unavailable',
					'http_status'   => $status ? $status : null,
					'error_code'    => $access->get_error_code(),
					'native_reason' => $data['reason'] ?? null,
					'role_inferred' => false,
				);
			} else {
				$auth['access_bindings'] = array(
					'status'        => 'available',
					'http_status'   => 200,
					'role_inferred' => false,
				);
			}
			// 403 proves lack of this capability; it does not prove the Editor role.
		}
		$hash = hash( 'sha256', wp_json_encode( array( $revision, $property, $stream, $profile, $observed, $streams ) ) );
		return Response::ok(
			array(
				'profile_schema_version' => self::VERSION,
				'property_id'            => $property,
				'stream_id'              => $stream,
				'profile'                => $profile,
				'auth'                   => $auth,
				'data_streams'           => $streams,
				'streamEnabled'          => $enabled,
				'complete'               => $complete,
				'conformant'             => $complete ? ! $changes : null,
				'checks'                 => $checks,
				'changes'                => $changes,
				'observed'               => $observed,
				'plan_hash'              => $hash,
				'revision'               => $revision,
				'property_creation'      => false,
				'operation_outcome'      => 'not_applied',
			)
		);
	}
	private static function unverified( string $section, \WP_Error $error ): array {
		$status = (int) ( $error->get_error_data()['status'] ?? 0 );
		return array(
			'section'     => $section,
			'status'      => in_array( $status, array( 404, 501 ), true ) ? 'unsupported' : 'not_verified',
			'error_code'  => $error->get_error_code(),
			'http_status' => $status ? $status : null,
		);
	}
	private static function fields( array $wanted, array $before ): array {
		$diff = array();
		foreach ( $wanted as $key => $value ) {
			if ( ( ! array_key_exists( $key, $before ) && false !== $value ) || ( array_key_exists( $key, $before ) && $before[ $key ] !== $value ) ) {
				$diff[ $key ] = $value;
			}
		}
		return $diff;
	}
	private static function change( string $section, string $api, string $method, array $path, array $body, ?array $before, string $action, bool $sensitive = false ): array {
		return array(
			'section'     => $section,
			'api'         => $api,
			'method'      => $method,
			'path_params' => $path,
			'query'       => 'update' === $action ? array( 'updateMask' => implode( ',', array_keys( $body ) ) ) : array(),
			'body'        => $body,
			'before'      => $before,
			'action'      => $action,
			'sensitive'   => $sensitive || false !== strpos( $method, 'GoogleSignals' ),
		);
	}
	public static function reduces( array $before, array $after ): bool {
		$months = array(
			'TWO_MONTHS'          => 2,
			'FOURTEEN_MONTHS'     => 14,
			'TWENTY_SIX_MONTHS'   => 26,
			'THIRTY_EIGHT_MONTHS' => 38,
			'FIFTY_MONTHS'        => 50,
		);
		foreach ( array( 'eventDataRetention', 'userDataRetention' ) as $field ) {
			if ( isset( $after[ $field ] ) && ( ! isset( $months[ $before[ $field ] ?? '' ] ) || ( $months[ $after[ $field ] ] ?? 0 ) < $months[ $before[ $field ] ] ) ) {
				return true;
			}
		}
		return false;
	}
	public static function apply( array $input ): array {
		$input = Operation::normalize( $input );
		if ( is_wp_error( $input ) ) {
			return Response::fail( $input );
		}
		$lock = Lock::acquire( 'profile:' . Connections::id() . ':' . (string) ( $input['property_id'] ?? '' ), 180 );
		if ( null === $lock ) {
			return Response::fail( new \WP_Error( 'f3_google_profile_busy', 'Outra aplicação está em andamento.' ), array( 'operation_outcome' => 'not_applied' ) );
		}
		try {
			$plan = self::plan( $input );
			if ( ! $plan['success'] || ( $input['dry_run'] ?? true ) ) {
				return $plan;
			}
			if ( ! $plan['complete'] ) {
				return Response::fail(
					new \WP_Error( 'f3_google_profile_incomplete', 'Todas as seções precisam ser verificadas antes da aplicação.' ),
					array(
						'operation_outcome' => 'not_applied',
						'plan'              => $plan,
					)
				);
			}
			if ( ! $plan['changes'] ) {
				return $plan;
			}
			if ( ! isset( $input['expected_plan_hash'] ) || ! hash_equals( $plan['plan_hash'], (string) $input['expected_plan_hash'] ) ) {
				return Response::fail(
					new \WP_Error( 'f3_google_profile_changed', 'Refaça a simulação e informe expected_plan_hash; o estado ou o perfil mudou.' ),
					array(
						'operation_outcome' => 'not_applied',
						'plan'              => $plan,
					)
				);
			}
			if ( count( $plan['changes'] ) > 1 || in_array( true, array_column( $plan['changes'], 'sensitive' ), true ) ) {
				$required = \Fator3\McpGoogle\Confirmation::require_confirmation();
				if ( null !== $required ) {
					return Response::fail( $required );
				}
			}
			$validated = \Fator3\McpGoogle\Confirmation::validate_calls( $plan['changes'] );
			if ( null !== $validated ) {
				return Response::fail( $validated );
			}
			$results = array();
			foreach ( $plan['changes'] as $step ) {
				$r = ExecuteAction::call( $step['api'], $step['method'], $step['path_params'], $step['query'], $step['body'] );
				if ( ! is_wp_error( $r ) && ! \Fator3\McpGoogle\Confirmation::capturing() ) {
					$verified = self::readback( $step, $r );
					if ( is_wp_error( $verified ) || self::fields( $step['body'], $verified ) ) {
						$r = new \WP_Error(
							'f3_google_profile_verification',
							'Etapa enviada, mas estado desejado não confirmado; demais etapas suspensas.',
							array(
								'operation_outcome' => 'unknown',
								'section'           => $step['section'],
							)
						);
					}
				}
				$outcome   = Operation::result( is_wp_error( $r ) ? Response::fail( $r ) : Response::ok( array( 'data' => $r ) ), 'write' );
				$results[] = array(
					'section' => $step['section'],
					'result'  => $outcome,
				);
				if ( empty( $outcome['success'] ) ) {
					return Response::fail(
						new \WP_Error( 'f3_google_profile_interrupted', 'Aplicação interrompida. Consulte a conformidade antes de uma nova aplicação.' ),
						array(
							'results'           => $results,
							'operation_outcome' => count( $results ) > 1 ? 'partial' : $outcome['operation_outcome'],
							'retryable'         => false,
						)
					);
				}
			}
			return Response::ok(
				array(
					'results'           => $results,
					'applied'           => count( $results ),
					'operation_outcome' => 'applied',
					'retryable'         => false,
					'recovery'          => array( 'action' => 'ga/conformidade' ),
				)
			);
		} finally {
			Lock::release( $lock );
		}
	}
	private static function readback( array $step, array $response ) {
		$method = $step['method'];
		if ( isset( self::SETTINGS[ $step['section'] ] ) ) {
			$method = str_replace( '.update', '.get', $method );
			return ExecuteAction::call( $step['api'], $method, $step['path_params'] );
		}
		$name   = $step['path_params']['name'] ?? $response['name'] ?? '';
		$parent = $step['path_params']['parent'] ?? '';
		if ( '' === $name || ( '' !== $parent && ! str_starts_with( $name, $parent . '/' ) ) ) {
			return new \WP_Error( 'f3_google_profile_readback', 'A API não retornou o identificador criado sob a propriedade esperada.' );
		}
		return ExecuteAction::call( $step['api'], preg_replace( '/\.(create|patch)$/', '.get', $method ), array( 'name' => $name ) );
	}
	private static function id( string $id ): string {
		return hash( 'sha256', Connections::id() . '|' . $id );
	}
	public static function save( array $input ): array {
		if ( ! preg_match( '/^[a-z][a-z0-9_-]{0,63}$/D', (string) ( $input['profile_id'] ?? '' ) ) ) {
			return Response::fail( self::error( 'profile_id inválido.' ) );
		}
		$profile = self::validate( $input['profile'] ?? null );
		if ( is_wp_error( $profile ) ) {
			return Response::fail( $profile );
		}
		$id   = self::id( $input['profile_id'] );
		$lock = Lock::acquire( 'profile-definition:' . $id );
		if ( null === $lock ) {
			return Response::fail( self::error( 'Perfil ocupado.' ) );
		}
		try {
			$old      = Records::get( 'profile', $id );
			$revision = $old['revision'] ?? '';
			if ( ( $input['expected_revision'] ?? '' ) !== $revision ) {
				return Settings::conflict();
			}
			$record = array(
				'profile_id'    => $input['profile_id'],
				'connection_id' => Connections::id(),
				'profile'       => $profile,
				'revision'      => hash( 'sha256', wp_json_encode( $profile ) ),
			);
			$saved  = Records::put( 'profile', $id, $record );
			return empty( $saved['success'] ) ? $saved : Response::ok( $record );
		} finally {
			Lock::release( $lock );
		}
	}
	private static function error( string $message ): \WP_Error {
		return new \WP_Error( 'f3_google_profile_input', $message, array( 'operation_outcome' => 'not_applied' ) );
	}
	public static function register(): void {
		$properties = array(
			'property_id'           => array( 'type' => 'string' ),
			'stream_id'             => array( 'type' => 'string' ),
			'profile_id'            => array( 'type' => 'string' ),
			'profile'               => array( 'type' => 'object' ),
			'check_access_bindings' => array(
				'type'    => 'boolean',
				'default' => false,
			),
		);
		Ability::register(
			'ga/conformidade',
			'ga',
			array(
				'label'        => 'GA4: conferir perfil',
				'description'  => 'Compara perfil configurável com propriedade existente. Só leitura. Retorna diff, auth.configured, streams e streamEnabled sem impor valores omitidos.',
				'input_schema' => array( 'properties' => $properties ),
				'callback'     => array( self::class, 'plan' ),
			)
		);
		Ability::register(
			'ga/aplicar-perfil',
			'ga',
			array(
				'label'        => 'GA4: aplicar perfil',
				'description'  => 'Simula por padrão. Aplica diferenças com retenção primeiro, sem criar propriedade nem remover definições extras. Exige hash da simulação ao aplicar.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => $properties + array(
						'dry_run'            => array(
							'type'    => 'boolean',
							'default' => true,
						),
						'simular'            => array( 'type' => 'boolean' ),
						'expected_plan_hash' => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'apply' ),
			)
		);
		Ability::register(
			'ga/profile-schema',
			'any',
			array(
				'label'       => 'GA4: contrato dos perfis',
				'description' => 'Schema versionado de perfis configuráveis. Não inclui padrões de agência.',
				'callback'    => static fn () => Response::ok(
					array(
						'schema_version' => self::VERSION,
						'sections'       => self::schema(),
					)
				),
			)
		);
		Ability::register(
			'ga/save-profile',
			'any',
			array(
				'label'        => 'GA4: salvar perfil local',
				'description'  => 'Salva definição local versionada; não altera Google. expected_revision evita sobrescrever outro editor.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'profile_id', 'profile' ),
					'properties' => array(
						'profile_id'        => array( 'type' => 'string' ),
						'profile'           => array( 'type' => 'object' ),
						'expected_revision' => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'save' ),
			)
		);
		Ability::register(
			'ga/list-profiles',
			'any',
			array(
				'label'       => 'GA4: perfis locais',
				'description' => 'Lista perfis configuráveis da conexão, sem consultas ao Google.',
				'callback'    => static fn () => Response::ok( array( 'profiles' => array_values( array_filter( Records::list( 'profile', 100 ), static fn ( $p ) => ( $p['connection_id'] ?? '' ) === Connections::id() ) ) ) ),
			)
		);
	}
}
