<?php
/**
 * Channel SDK integration.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Channel {
	public const PROVIDER = 'wp-mcp-google-fator3';
	public static function init(): void {
		add_action(
			'f3_mcp_register_providers',
			static function ( $version = 1 ): void {
				if ( 1 === $version && class_exists( '\\Fator3\\McpFiles\\ExtensionContract' ) ) {
					\Fator3\McpFiles\ExtensionContract::register( self::PROVIDER, F3_MCP_GOOGLE_VERSION, array( 'ga/', 'ads/', 'google/', 'gsc/', 'siteverification/', 'gtm/' ) );
				}
			}
		);
	}
	/** The final ability is authorized independently from its executor. */
	public static function maintenance(): bool {
		return class_exists( '\\Fator3\\McpFiles\\ConnectionContext' ) && ( \Fator3\McpFiles\ConnectionContext::get()['profile'] ?? '' ) === 'maintenance';
	}
	public static function authorize( string $name, array $input, bool $read ) {
		if ( class_exists( '\\Fator3\\McpFiles\\AuthorizationPolicy' ) ) {
			return \Fator3\McpFiles\AuthorizationPolicy::check( $name, $input, $read );
		}
		return true;
	}
}
