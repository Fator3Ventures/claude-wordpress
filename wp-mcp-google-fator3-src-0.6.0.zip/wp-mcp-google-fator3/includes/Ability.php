<?php
/**
 * Registrador padrão das habilidades.
 *
 * Toda rota `ga/*`, `ads/*` e `google/*` passa por aqui em vez de chamar
 * `wp_register_ability()` direto. O motivo é que quatro coisas precisam ser
 * iguais em todas elas e são exatamente as que se esquece de repetir:
 * `meta.mcp.public` (sem isso o WP MCP Ultimate não expõe a rota),
 * `permission_callback` (sem isso a rota fica aberta a qualquer usuário
 * autenticado), o portão do `Gate` no início da execução e o registro de
 * auditoria no fim. Centralizar também garante que uma exceção vire resposta de
 * erro em vez de HTTP 500 no meio de uma sessão MCP.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Ability {
	private static array $admin_definitions = array();
	/** Called only inside the nonce-checked local administrator flow. */
	public static function execute_admin( string $name, array $input ) {
		if ( ! Gate::administrative_allowed( $name ) || ! isset( self::$admin_definitions[ $name ] ) ) {
			return Response::fail( new \WP_Error( 'f3_google_admin_context', 'Operação administrativa local não autorizada.' ) );
		}
		$ability = new \WP_Ability( $name, self::$admin_definitions[ $name ] );
		return $ability->execute( $input );
	}
	/**
	 * Registra uma habilidade com os padrões da casa.
	 *
	 * @param string $name      Ex.: 'ga/run-report'.
	 * @param string $connector 'ga' | 'ads' | 'any' — usado pelo Gate.
	 * @param array  $args      label, description, input_schema, output_schema
	 *                          (opcional), callback, meta (opcional).
	 */
	public static function register( string $name, string $connector, array $args ): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		$mode     = 'write' === ( $args['mode'] ?? 'read' ) ? 'write' : 'read';
		$callback = $args['callback'] ?? null;
		if ( ! is_callable( $callback ) ) {
			return;
		}
		$input_schema = isset( $args['input_schema'] ) && is_array( $args['input_schema'] )
		? $args['input_schema']
		: array();
		// O esquema de entrada é sempre um objeto fechado: o WordPress 6.9+
		// valida a entrada contra ele antes de executar, e `additionalProperties
		// = false` faz um parâmetro com nome errado falhar na hora, em vez de
		// ser silenciosamente ignorado e produzir um relatório errado.
		$input_schema['type'] = 'object';
		if ( ! isset( $input_schema['properties'] ) || ! is_array( $input_schema['properties'] ) ) {
			$input_schema['properties'] = array();
		}
		$input_schema['additionalProperties'] = false;
		if ( 'write' === $mode ) {
			$input_schema['properties']['confirmation_token'] = array(
				'type'        => 'string',
				'description' => 'Token opaco de uso único emitido por google/prepare-operation para escritas sensíveis.',
			);
		}
		$input_schema['properties']['connection_id'] = array(
			'type'        => 'string',
			'description' => 'Conexão Google; omissão usa a conexão padrão, ou a conexão do job em execução.',
		);
		$output_schema                               = isset( $args['output_schema'] ) && is_array( $args['output_schema'] )
		? $args['output_schema']
		: array(
			'type'       => 'object',
			'properties' => array(
				'success' => array( 'type' => 'boolean' ),
				'message' => array( 'type' => 'string' ),
			),
		);
		$meta                                        = isset( $args['meta'] ) && is_array( $args['meta'] ) ? $args['meta'] : array();
		$remote_effect                               = self::local_read( $name ) ? 'none' : $mode;
		if ( in_array( $name, array( 'google/configure-gsc-import', 'ga/save-profile', 'google/create-connection', 'google/configure-policy', 'google/configure-alerts', 'google/configure-update-origin', 'google/configure-local', 'google/apply-template', 'google/cancel-job', 'google/delete-job', 'google/reconcile-job', 'google/cleanup-jobs', 'google/migrate-storage' ), true ) ) {
			$remote_effect = 'none';
		}
		if ( in_array( $name, array( 'google/sync-gsc-core', 'gsc/inspect-urls', 'google/configure', 'google/create-job', 'google/schedule-report', 'google/prepare-operation', 'google/prepare-job', 'google/approve-job' ), true ) ) {
			$remote_effect = 'read';
		}
		$meta['fator3'] = array_merge(
			(array) ( $meta['fator3'] ?? array() ),
			array(
				'version'                    => F3_MCP_GOOGLE_VERSION,
				'provider'                   => Channel::PROVIDER,
				'policy_contract'            => 1,
				'connector'                  => $connector,
				'execution_contract_version' => '2.0.0',
				'mode'                       => $mode,
				'remote_effect'              => $remote_effect,
				'local_effect'               => 'write' === $mode ? 'write' : 'none',
			)
		);
		$meta['mcp']    = array_merge(
			array(
				'public' => true,
				'type'   => 'tool',
			),
			isset( $meta['mcp'] ) && is_array( $meta['mcp'] ) ? $meta['mcp'] : array()
		);
		// As anotações refletem efeitos possíveis; a confirmação pertence ao agente.
		$meta['annotations']              = array(
			'readonly'    => 'read' === $mode,
			'destructive' => 'write' === $mode && ( Confirmation::sensitive( $name ) || in_array( $name, array( 'google/execute-action', 'google/mcp-write' ), true ) ),
			'idempotent'  => 'read' === $mode,
		);
		$definition                       = array(
			'label'               => (string) ( $args['label'] ?? $name ),
			'description'         => (string) ( $args['description'] ?? '' ),
			'category'            => 'google',
			'input_schema'        => $input_schema,
			'output_schema'       => $output_schema,
			'permission_callback' => static function ( $input = array() ) use ( $connector ): bool {
				$id = (string) ( self::normalize_input( $input )['connection_id'] ?? Connections::id() );
				$permitted = Connections::run( $id, static fn () => Gate::permission( $connector ) );
				return true === $permitted;
			},
			'execute_callback'    => static function ( $input = array() ) use ( $name, $connector, $callback, $mode ): array {
				return Connections::run( (string) ( self::normalize_input( $input )['connection_id'] ?? Connections::id() ), static fn () => Storage\Admission::run( $name, static fn () => self::run( $name, $connector, $callback, $input, $mode ) ) );
			},
			'meta'                => $meta,
		);
		self::$admin_definitions[ $name ] = $definition;
		wp_register_ability( $name, $definition );
	}
	/**
	 * Executa a habilidade: normaliza a entrada, aplica o portão, cronometra,
	 * converte exceção em erro e audita.
	 *
	 * @param string   $name      Nome da habilidade.
	 * @param string   $connector Conector para o Gate.
	 * @param callable $callback  Implementação da rota.
	 * @param mixed    $input     Entrada crua vinda do servidor MCP.
	 */
	private static function run( string $name, string $connector, callable $callback, $input, string $mode = 'read' ): array {
		$input = Operation::normalize( self::normalize_input( $input ) );
		if ( is_wp_error( $input ) ) {
			return Response::fail( $input, array( 'operation_outcome' => 'not_applied' ) );
		}
		if ( in_array( $name, array( 'google/execute-action', 'google/execute-read' ), true ) ) {
			$operation = Operation::method( (string) ( $input['api'] ?? '' ), (string) ( $input['method'] ?? '' ) );
			if ( is_wp_error( $operation ) ) {
				return Response::fail( $operation, array( 'operation_outcome' => 'not_applied' ) );
			}
			if ( 'google/execute-read' === $name && 'read' !== $operation['mode'] ) {
				return Response::fail( new \WP_Error( 'f3_google_read_required', 'execute-read aceita somente consultas classificadas.' ), array( 'operation_outcome' => 'not_applied' ) );
			}
			$mode      = $operation['mode'];
			$connector = Generic\Discovery::connector( Generic\Discovery::canonical( (string) $input['api'] ) );
		}
		if ( 'write' === $mode && Operation::wildcard( $input ) ) {
			Audit::log(
				$name,
				'*',
				array(
					'status'        => 'denied',
					'mode'          => $mode,
					'remote_effect' => 'gsc/inspect-urls' === $name ? 'read' : $mode,
					'local_effect'  => 'write' === $mode ? 'write' : 'none',
				)
			);
			return Response::fail(
				new \WP_Error( 'f3_google_write_wildcard', 'Escritas exigem alvos explícitos. Use a descoberta para preparar os identificadores.' ),
				array(
					'operation_outcome' => 'not_applied',
					'retryable'         => false,
				)
			);
		}
		$target  = self::target( $input );
		$dry_run = ! empty( $input['dry_run'] ) || ( 'ga/send-event' === $name && ! empty( $input['debug'] ) ) || ( 'google/execute-action' === $name && ( ! empty( $input['body']['validateOnly'] ) || ! empty( $input['query']['validateOnly'] ) ) );
		if ( 'write' === $mode ) {
			Audit::begin();
		}
		$remote_mode   = 'gsc/inspect-urls' === $name ? 'read' : $mode;
		$profile_error = Operation::profile( $connector, $remote_mode );
		$gate          = Gate::check( $connector ) ?? ( null !== $profile_error ? Response::fail( $profile_error ) : null );
		if ( null !== $gate ) {
			Audit::log(
				$name,
				$target,
				array(
					'status'  => 'denied',
					'mode'    => $mode,
					'dry_run' => $dry_run,
				) + ( 'write' === $mode ? Audit::finish() : array() )
			);
			return $gate;
		}
		if ( ! Confirmation::authorized() ) {
			Confirmation::reset_observations();
		}
		$started = microtime( true );
		try {
			$invoke = static fn () => self::invoke( $name, $mode, $connector, $callback, $input );
			$result = isset( $input['confirmation_token'] ) && ! Confirmation::capturing() ? Confirmation::execute( $name, $input, $invoke ) : $invoke();
			if ( is_wp_error( $result ) ) {
				$result = Response::fail( $result );
			} elseif ( ! is_array( $result ) ) {
				$result = Response::fail(
					new \WP_Error(
						'f3_google_bad_result',
						__( 'A habilidade não devolveu uma resposta válida.', 'wp-mcp-google-fator3' )
					)
				);
			}
		} catch ( \Throwable $e ) {
			// A mensagem da exceção pode ter passado por um trecho que
			// manipulava credencial; passa pelo filtro antes de sair.
			$result = Response::fail(
				new \WP_Error(
					'f3_google_exception',
					sprintf(
						/* translators: %s: mensagem da exceção. */
						__( 'Falha interna ao executar a habilidade: %s', 'wp-mcp-google-fator3' ),
						self::scrub( $e->getMessage() )
					)
				)
			);
		}
		if ( 'google/selftest' === $name && ! array_key_exists( 'execution_success', $result ) ) {
			$result['execution_success'] = false;
			$result['checks_passed']     = false;
		}
		if ( ( ! Storage\Migration::paused() || Storage\Admission::can_write() ) && ( 'read' !== $mode || empty( $result['success'] ) || ! self::local_read( $name ) || Options::get( Options::AUDIT_LOCAL_READS, false ) ) ) {
			Audit::log(
				$name,
				$target,
				array(
					'ms'      => (int) round( ( microtime( true ) - $started ) * 1000 ),
					'rows'    => self::rows_in( $result ),
					'status'  => ! empty( $result['success'] ) ? 'ok' : 'erro',
					'mode'    => $mode,
					'dry_run' => $dry_run,
				) + ( 'write' === $mode ? Audit::finish() + array(
					'result' => array(
						'success'    => ! empty( $result['success'] ),
						'error_code' => $result['error_code'] ?? null,
					),
				) : array() )
			);
			if ( null !== Audit::last_failure() ) {
				$result['audit_warning'] = Audit::last_failure();
			}
		}
		return Operation::result( $result, $mode, $dry_run );
	}
	public static function local_read( string $name ): bool {
		return in_array( $name, array( 'gtm/get-publication', 'google/gsc-import-status', 'google/status', 'google/ability-catalog', 'google/configuration-schema', 'google/resource-policy', 'google/plan-policy', 'google/plan-template', 'google/report-templates', 'google/list-connections', 'google/list-jobs', 'google/get-job', 'google/get-schedule', 'google/alerts', 'google/audit', 'google/audit-export', 'google/storage-status', 'google/update-status', 'google/export-template', 'ga/list-profiles', 'ga/profile-schema' ), true );
	}
	/** Resolve seletor nomeado antes de chamar a operação; * é fanout explícito. */
	private static function invoke( string $name, string $mode, string $connector, callable $callback, array $input ) {
		$key = array(
			'ga'  => 'property_id',
			'ads' => 'customer_id',
			'gsc' => 'site_url',
		)[ $connector ] ?? '';
		if ( '' === $key || ! isset( $input[ $key ] ) || ! is_scalar( $input[ $key ] ) || '' === trim( (string) $input[ $key ] ) ) {
			return $callback( $input );
		}
		$ids = Unified\Accounts::resolve_many( $connector, array( (string) $input[ $key ] ) );
		if ( is_wp_error( $ids ) ) {
			return $ids;
		}
		if ( '*' !== (string) $input[ $key ] && 1 === count( $ids ) ) {
			$input[ $key ] = $ids[0];
			return $callback( $input );
		}
		$results = array();
		$ok      = true;
		foreach ( $ids as $id ) {
			$item         = $input;
			$item[ $key ] = $id;
			// Cada alvo tem sua auditoria completa, além da entrada de fanout.
			if ( 'write' === $mode ) {
				Audit::begin();
			}
			try {
				$result = $callback( $item );
				$result = is_wp_error( $result ) ? Response::fail( $result ) : $result;
			} catch ( \Throwable $e ) {
				$result = Response::fail( self::scrub( $e->getMessage() ) );
			}
			$snapshots = 'write' === $mode ? Audit::finish() : array();
			$results[] = array(
				'account_id' => $id,
				'result'     => $result,
			);
			$ok        = $ok && ! empty( $result['success'] );
			Audit::log(
				$name,
				$id,
				array(
					'mode'    => $mode,
					'status'  => ! empty( $result['success'] ) ? 'ok' : 'erro',
					'dry_run' => ! empty( $input['dry_run'] ),
				) + $snapshots
			);
		}
		return array(
			'success' => $ok,
			'message' => count( $results ) . ' alvo(s) executado(s).',
			'results' => $results,
		);
	}
	/**
	 * Vários clientes MCP mandam o objeto de parâmetros como string JSON; o
	 * `execute-ability` do Ultimate já decodifica, mas uma chamada direta à
	 * habilidade (WP-CLI, outro servidor) pode não fazer isso.
	 *
	 * @param mixed $input Entrada crua.
	 */
	private static function normalize_input( $input ): array {
		if ( is_string( $input ) ) {
			$decoded = json_decode( $input, true );
			$input   = is_array( $decoded ) ? $decoded : array();
		}
		return is_array( $input ) ? $input : array();
	}
	/**
	 * Alvo da operação para o log: a propriedade GA ou a conta Ads.
	 */
	private static function target( array $input ): string {
		foreach ( array( 'property_id', 'customer_id', 'site_url', 'spreadsheet_id', 'name', 'resource' ) as $key ) {
			if ( isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) ) {
				$value = trim( (string) $input[ $key ] );
				if ( '' !== $value ) {
					return $value;
				}
			}
		}
		return '-';
	}
	/**
	 * Quantas linhas a resposta devolveu, para o log.
	 */
	private static function rows_in( array $result ): int {
		if ( isset( $result['row_count'] ) && is_numeric( $result['row_count'] ) ) {
			return (int) $result['row_count'];
		}
		if ( isset( $result['rows'] ) && is_array( $result['rows'] ) ) {
			return count( $result['rows'] );
		}
		return 0;
	}
	/**
	 * Remove qualquer segredo configurado de um texto antes de ele sair.
	 *
	 * Defesa em profundidade: nenhum caminho conhecido põe credencial numa
	 * mensagem de exceção, mas o custo de garantir é baixo e o de errar é uma
	 * chave privada num transcript de conversa.
	 */
	public static function scrub( string $text ): string {
		if ( '' === $text ) {
			return $text;
		}
		foreach ( Options::secret_names() as $name ) {
			$secret = Options::get_secret( $name );
			if ( Options::SA_JSON === $name ) {
				$key = json_decode( $secret, true );
				if ( is_array( $key ) && ! empty( $key['private_key'] ) ) {
					$text = str_replace( array( (string) $key['private_key'], str_replace( "\n", '\\n', (string) $key['private_key'] ) ), '[redigido]', $text );
				}
			}
			if ( strlen( $secret ) >= 8 && false !== strpos( $text, $secret ) ) {
				$text = str_replace( $secret, '[redigido]', $text );
			}
		}
		foreach ( (array) Options::get( Options::TOKEN_INDEX, array() ) as $key ) {
			if ( ! is_string( $key ) || 0 !== strpos( $key, Auth\Credentials::CACHE_PREFIX ) ) {
				continue;
			}
			$token = Auth\Credentials::cached( $key, false );
			if ( is_string( $token ) && strlen( $token ) >= 8 ) {
				$text = str_replace( $token, '[token redigido]', $text );
			}
		}
		return $text;
	}
}
