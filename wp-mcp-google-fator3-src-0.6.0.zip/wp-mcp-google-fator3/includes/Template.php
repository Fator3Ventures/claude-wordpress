<?php
/**
 * Portable configuration is an allowlisted model, never an option dump.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Template {

	public const VERSION = '1.0.0';
	public static function export( array $input ): array {
		$services   = (array) Options::get( Connections::SERVICES, array() );
		$bindings   = (array) Options::get( Connections::BINDINGS, array() );
		$parameters = array();
		foreach ( $bindings as $key => &$value ) {
			if ( ! array_key_exists( $key, Setup::BINDING_RULES ) ) {
				unset( $bindings[ $key ] );
				continue;
			}
			if ( '' !== $value && empty( $input['include_resource_ids'] ) ) {
				$parameters[ $key ] = array(
					'type'        => 'string',
					'description' => 'Recurso existente para ' . $key,
				);
				$value              = '${' . $key . '}';
			}
		}
		unset( $value );
		$limits = array();
		foreach ( Options::LIMITS as $name => $rule ) {
			$limits[ $name ] = Options::limit( $name );
		}
		$policy = Policy::current();
		foreach ( array_keys( $policy['services'] ?? array() ) as $service ) {
			unset( $policy['services'][ $service ]['recipients'] );
		}
		if ( empty( $input['include_resource_ids'] ) ) {
			foreach ( array_keys( $policy['services'] ?? array() ) as $service ) {
				$rule = &$policy['services'][ $service ];
				foreach ( $rule['resources'] ?? array() as $i => $value ) {
					$key                     = 'policy_' . $service . '_' . $i;
					$parameters[ $key ]      = array(
						'type'        => 'string',
						'description' => 'Recurso autorizado de ' . $service,
					);
					$rule['resources'][ $i ] = '${' . $key . '}';
				}
				unset( $rule['recipients'] );
			}
			unset( $rule );
		}
		return Response::ok(
			array(
				'template'         => array(
					'schema_version' => self::VERSION,
					'services'       => $services,
					'bindings'       => $bindings,
					'limits'         => $limits,
					'policy'         => $policy,
					'parameters'     => $parameters,
				),
				'secrets_included' => false,
				'alerts_included'  => false,
			)
		);
	}
	public static function plan( array $input ): array {
		$template = $input['template'] ?? null;
		$mapping  = $input['mapping'] ?? array();
		if ( ! is_array( $template ) || ! is_array( $mapping ) || ( $template['schema_version'] ?? null ) !== self::VERSION || array_diff( array_keys( $template ), array( 'schema_version', 'services', 'bindings', 'limits', 'policy', 'parameters' ) ) ) {
			return self::fail( 'Modelo inválido ou versão incompatível.' );
		}
		if ( strlen( wp_json_encode( $template ) ) > 262144 ) {
			return self::fail( 'Modelo excede 256 KiB.' );
		}
		$parameters = $template['parameters'] ?? array();
		if ( ! is_array( $parameters ) || count( $parameters ) > 200 || array_diff( array_keys( $mapping ), array_keys( $parameters ) ) ) {
			return self::fail( 'Mapeamento contém parâmetros desconhecidos.' );
		}
		foreach ( $parameters as $key => $definition ) {
			if ( ! preg_match( '/^[a-zA-Z][a-zA-Z0-9_]{0,100}$/D', (string) $key ) || ! is_array( $definition ) || array_diff( array_keys( $definition ), array( 'type', 'description' ) ) || ( $definition['type'] ?? '' ) !== 'string' || ( isset( $definition['description'] ) && ! is_string( $definition['description'] ) ) ) {
				return self::fail( 'Declaração de parâmetro inválida.' );
			}
		}
		foreach ( $mapping as $key => $value ) {
			if ( ! is_string( $value ) || strlen( $value ) > 2048 ) {
				return self::fail( 'Mapeamento exige valores textuais de até 2048 bytes.' );
			}
		}
		$resolve  = static function ( $value ) use ( &$resolve, $mapping ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $key => $item ) {
					$value[ $key ] = $resolve( $item );
				}
				return $value;
			}
			if ( is_string( $value ) && preg_match( '/^\$\{([a-zA-Z0-9_]+)\}$/D', $value, $m ) ) {
				return $mapping[ $m[1] ] ?? new \WP_Error( 'f3_google_template_mapping', 'Mapeie o recurso ' . $m[1] . '.' );
			}
			return $value;
		};
		$resolved = $resolve( $template );
		$check    = static function ( $value ) use ( &$check ): ?\WP_Error {
			if ( is_wp_error( $value ) ) {
				return $value;
			}
			if ( is_array( $value ) ) {
				foreach ( $value as $v ) {
					$e = $check( $v );
					if ( null !== $e ) {
						return $e;
					}
				}
			}
			return null;
		};
		$error    = $check( $resolved );
		if ( null !== $error ) {
			return Response::fail( $error );
		}
		$plan = Setup::plan( array_intersect_key( $resolved, array_flip( array( 'services', 'bindings' ) ) ) );
		if ( ! $plan['success'] ) {
			return $plan;
		}
		$values = $plan['values'];
		foreach ( $resolved['limits'] ?? array() as $name => $value ) {
			$rule = Options::LIMITS[ $name ] ?? null;
			if ( null === $rule || ! is_int( $value ) || $value < $rule['minimum'] || $value > $rule['maximum'] ) {
				return self::fail( 'Limite desconhecido ou fora do intervalo: ' . $name );
			}
			$values[ $name ] = $value;
		}
		if ( isset( $resolved['policy'] ) ) {
			$policy = Policy::validate( $resolved['policy'] );
			if ( is_wp_error( $policy ) ) {
				return Response::fail( $policy );
			}
			$values[ Policy::OPTION ] = $policy;
		}
		$impact = isset( $values[ Policy::OPTION ] ) ? Policy::plan( array( 'policy' => $values[ Policy::OPTION ] ) ) : null;
		if ( null !== $impact && ! $impact['success'] ) {
			return $impact;
		}
		$revision = Settings::revision();
		if ( is_wp_error( $revision ) ) {
			return Response::fail( $revision );
		}
		$changes = array();
		foreach ( $values as $name => $value ) {
			$before    = Options::get( $name, null );
			$changes[] = array(
				'option'  => $name,
				'before'  => $before,
				'after'   => $value,
				'changed' => $before !== $value,
			);
		}
		return Response::ok(
			array(
				'revision'                => $revision,
				'values'                  => $values,
				'changes'                 => $changes,
				'plan_hash'               => hash( 'sha256', wp_json_encode( array( $revision, $values ) ) ),
				'remote_writes_performed' => false,
				'policy_impact'           => $impact,
				'access_policy_changed'   => isset( $values[ Policy::OPTION ] ) && Policy::current() !== $values[ Policy::OPTION ],
				'credentials_promoted'    => false,
				'alerts_enabled'          => false,
			)
		);
	}
	public static function apply( array $input ): array {
		$plan = self::plan( $input );
		if ( ! $plan['success'] ) {
			return $plan;
		}
		if ( ! isset( $input['expected_revision'], $input['expected_plan_hash'] ) || $input['expected_revision'] !== $plan['revision'] || $input['expected_plan_hash'] !== $plan['plan_hash'] ) {
			return Settings::conflict();
		}
		if ( isset( $plan['values'][ Policy::OPTION ] ) && ! current_user_can( 'manage_options' ) ) {
			return Response::fail( new \WP_Error( 'f3_google_policy_forbidden', 'Alterar política exige manage_options.' ) );
		}
		return Settings::save( $plan['values'], array(), array(), $plan['revision'] );
	}
	private static function fail( string $message ): array {
		return Response::fail( new \WP_Error( 'f3_google_template_input', $message ) );
	}
	public static function register(): void {
		Ability::register(
			'google/export-template',
			'any',
			array(
				'label'        => 'Google: exportar modelo de configuração',
				'description'  => 'Exporta somente serviços, vínculos, limites e política. Recursos parametrizados por padrão; nunca inclui credenciais ou alertas.',
				'input_schema' => array(
					'properties' => array(
						'include_resource_ids' => array(
							'type'    => 'boolean',
							'default' => false,
						),
					),
				),
				'callback'     => array( self::class, 'export' ),
			)
		);
		$properties = array(
			'template'           => array( 'type' => 'object' ),
			'mapping'            => array( 'type' => 'object' ),
			'expected_revision'  => array( 'type' => 'string' ),
			'expected_plan_hash' => array( 'type' => 'string' ),
		);
		foreach ( array(
			'plan-template'  => 'plan',
			'apply-template' => 'apply',
		) as $route => $method ) {
			Ability::register(
				'google/' . $route,
				'any',
				array(
					'label'        => 'Google: ' . $route,
					'description'  => 'Valida, mapeia e compara modelo. Aplicação exige revisão e hash da prévia; usa gravação verificada e compensação.',
					'mode'         => 'apply' === $method ? 'write' : 'read',
					'input_schema' => array(
						'required'   => array( 'template' ),
						'properties' => $properties,
					),
					'callback'     => array( self::class, $method ),
				)
			);
		}
	}
}
