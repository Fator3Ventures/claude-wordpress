<?php
/**
 * Optional Site Core adapter; the Google plugin also works independently.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class CoreBinding {

	public static function source() {
		$values = array();
		foreach ( array( 'f3base_ga4_measurement_id', 'f3base_gtm_container_id' ) as $name ) {
			$state = Options::stored( $name );
			if ( ! $state['success'] ) {
				return new \WP_Error( 'f3_google_core_read', 'Não foi possível ler os identificadores do Site Core.' );
			}
			$values[ $name ] = $state['exists'] ? trim( (string) $state['value'] ) : '';
		}
		$values['revision'] = hash( 'sha256', wp_json_encode( $values ) );
		return $values;
	}
	public static function resolve() {
		$source = self::source();
		if ( is_wp_error( $source ) ) {
			return $source;
		}
		if ( '' !== $source['f3base_gtm_container_id'] ) {
			return new \WP_Error( 'f3_google_core_gtm_active', 'O Site Core usa GTM. Informe o recurso GA4 explicitamente; o measurement ID direto está inativo.' );
		}
		$id = $source['f3base_ga4_measurement_id'];
		if ( ! preg_match( '/^G-[A-Z0-9]+$/D', $id ) ) {
			return new \WP_Error( 'f3_google_core_measurement_missing', 'O Site Core não possui measurement ID GA4 válido.' );
		}
		$accounts = Analytics\CatalogReader::list( 'accountSummaries.list', array(), 'accountSummaries' );
		if ( is_wp_error( $accounts ) ) {
			return $accounts;
		}
		$matches    = array();
		$properties = array();
		foreach ( $accounts as $account ) {
			foreach ( $account['propertySummaries'] ?? array() as $property ) {
				if ( isset( $property['property'] ) ) {
					$properties[ $property['property'] ] = true;
				}
			}
		}
		foreach ( array_keys( $properties ) as $property ) {
			$streams = Analytics\CatalogReader::list( 'properties.dataStreams.list', array( 'parent' => $property ), 'dataStreams' );
			if ( is_wp_error( $streams ) ) {
				return $streams;
			}
			foreach ( $streams as $stream ) {
				if ( ( $stream['webStreamData']['measurementId'] ?? null ) === $id ) {
					$matches[ $stream['name'] ] = array(
						'ga_property_id'    => $property,
						'ga_stream_id'      => $stream['name'],
						'ga_measurement_id' => $id,
					);
				}
			}
		}
		if ( 1 !== count( $matches ) ) {
			return new \WP_Error(
				count( $matches ) > 1 ? 'f3_google_core_ambiguous' : 'f3_google_core_not_found',
				'Não foi encontrado um único stream acessível para o measurement ID.',
				array(
					'matches'  => count( $matches ),
					'complete' => true,
				)
			);
		}
		$now = self::source();
		if ( is_wp_error( $now ) ) {
			return $now;
		}
		if ( $now['revision'] !== $source['revision'] ) {
			return new \WP_Error( 'f3_google_core_changed', 'Os identificadores do Site Core mudaram durante a descoberta.' );
		}
		return array(
			'bindings' => reset( $matches ),
			'source'   => array(
				'adapter'        => 'site-core',
				'measurement_id' => $id,
				'revision'       => $source['revision'],
			),
		);
	}
}
