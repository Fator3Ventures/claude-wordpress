<?php
/**
 * Shared operation semantics, independent from caller-supplied HTTP options.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Operation {

	/** @return array|\WP_Error */
	public static function method( string $api, string $method ) {
		$api = Generic\Discovery::canonical( $api );
		if ( is_wp_error( $api ) ) {
			return $api;
		}
		static $catalog = null;
		$catalog        = $catalog ?? require __DIR__ . '/Data/Operations.php';
		return $catalog[ $api ][ $method ] ?? new \WP_Error( 'f3_google_operation_unclassified', 'Método sem classificação aprovada nesta versão. Atualize o catálogo do pacote antes de executar.' );
	}

	public static function profile( string $connector, string $mode ): ?\WP_Error {
		$profiles = Options::get( Connections::SERVICES, null );
		if ( 'write' === $mode && is_array( $profiles ) && 'read' === ( $profiles[ $connector ] ?? '' ) ) {
			return new \WP_Error(
				'f3_google_service_read_only',
				'O serviço está configurado para leitura.',
				array(
					'operation_outcome' => 'not_applied',
					'retryable'         => false,
				)
			);
		}
		return null;
	}

	/** Wildcards are discovery selectors, never authorization for remote writes. */
	public static function wildcard( array $input, bool $path_context = false ): bool {
		$targets = array( 'name', 'parent', 'resource', 'resourceName', 'property_id', 'customer_id', 'site_url', 'spreadsheet_id', 'fileId', 'spreadsheetId', 'siteUrl', 'customerId', 'account_id', 'property', 'customer' );
		foreach ( $input as $key => $value ) {
			$target = $path_context || in_array( (string) $key, $targets, true );
			if ( is_array( $value ) && self::wildcard( $value, $target || 'path_params' === $key ) ) {
				return true;
			}
			if ( $target && is_string( $value ) && false !== strpos( $value, '*' ) ) {
				return true;
			}
		}
		return false;
	}

	/** Canonicalize explicitly supported simulation aliases before audit/gates. */
	public static function normalize( array $input ) {
		if ( array_key_exists( 'simular', $input ) ) {
			if ( ! is_bool( $input['simular'] ) || ( array_key_exists( 'dry_run', $input ) && $input['dry_run'] !== $input['simular'] ) ) {
				return new \WP_Error( 'f3_google_simulation_conflict', 'simular e dry_run devem ser booleanos iguais quando enviados juntos.' );
			}
			$input['dry_run'] = $input['simular'];
			unset( $input['simular'] );
		}
		return $input;
	}

	/** A rejection needs operation-specific evidence; HTTP 4xx alone is insufficient. */
	public static function http_failure( string $method, string $url, int $status, $body, array $opts ): string {
		if ( 'write' !== ( $opts['mode'] ?? '' ) ) {
			return 'not_applicable';
		}
		$error = is_array( $body ) && is_array( $body['error'] ?? null ) ? $body['error'] : array();
		if ( (int) ( $error['code'] ?? 0 ) !== $status ) {
			return 'unknown';
		}
		$path = explode( '?', $url, 2 )[0];
		// Sheets validates the complete batch before any subrequest is applied.
		// Reference: <https://developers.google.com/workspace/sheets/api/guides/batch>.
		if ( 'POST' === $method && 'sheets.spreadsheets.batchUpdate' === ( $opts['operation_id'] ?? '' ) && preg_match( '~^https://sheets\.googleapis\.com/v4/spreadsheets/[^/:]+:batchUpdate$~D', $path ) && 400 === $status && 'INVALID_ARGUMENT' === ( $error['status'] ?? '' ) ) {
			return 'not_applied';
		}
		// A single permission creation denied for missing file permissions did not grant access.
		// Reference: <https://developers.google.com/workspace/drive/api/guides/handle-errors#insufficientFilePermissions>.
		$reasons = array_column( (array) ( $error['errors'] ?? array() ), 'reason' );
		if ( 'POST' === $method && 'drive.permissions.create' === ( $opts['operation_id'] ?? '' ) && preg_match( '~^https://www\.googleapis\.com/drive/v3/files/[^/]+/permissions$~D', $path ) && 403 === $status && array( 'insufficientFilePermissions' ) === array_values( array_unique( $reasons ) ) ) {
			return 'not_applied';
		}
		return 'unknown';
	}

	/** Aggregate observed remote effects without turning executor success into write success. */
	public static function aggregate( array $outcomes ): string {
		$effects = array_values( array_unique( array_diff( $outcomes, array( 'not_applicable' ) ) ) );
		if ( in_array( 'unknown', $effects, true ) ) {
			return 'unknown';
		}
		if ( in_array( 'partial', $effects, true ) || count( $effects ) > 1 ) {
			return 'partial';
		}
		return $effects ? $effects[0] : 'not_applicable';
	}

	/** Normalize legacy outcomes conservatively, retaining aliases for old readers. */
	public static function result( array $result, string $mode, bool $dry_run = false ): array {
		$known = array();
		foreach ( array( $result['operation_outcome'] ?? null, $result['details']['operation_outcome'] ?? null, $result['details']['outcome'] ?? null ) as $value ) {
			if ( in_array( $value, array( 'applied', 'not_applied', 'partial', 'unknown', 'not_applicable' ), true ) ) {
				$known[] = $value;
			}
		}
		if ( ! empty( $result['uncertain'] ) || ! empty( $result['outcome_uncertain'] ) ) {
			$known[] = 'unknown';
		}
		$known   = array_unique( $known );
		$outcome = count( $known ) > 1 ? 'unknown' : ( $known ? reset( $known ) : null );
		if ( 'read' === $mode ) {
			$outcome = 'not_applicable';
		} elseif ( null === $outcome ) {
			$outcome = $dry_run ? 'not_applied' : ( ! empty( $result['partial_failure'] ) ? 'partial' : ( ! empty( $result['success'] ) ? 'applied' : 'unknown' ) );
		}
		$result['operation_outcome'] = $outcome;
		$result['retryable']         = ! in_array( $outcome, array( 'unknown', 'partial' ), true ) && (bool) ( $result['retryable'] ?? $result['details']['retryable'] ?? false );
		if ( in_array( $outcome, array( 'unknown', 'partial' ), true ) ) {
			$result['recovery'] = array( 'action' => 'reconcile_target' );
		}
		return $result;
	}
}
