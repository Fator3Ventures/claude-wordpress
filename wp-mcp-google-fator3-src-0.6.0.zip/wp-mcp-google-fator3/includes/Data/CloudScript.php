<?php
/**
 * Protected Cloud Shell reference; emitted only after Admin::guard().
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return <<<'F3_CLOUD_SCRIPT_RESOURCE'
#!/usr/bin/env bash
# Cloud Shell: PROJETO=seu-id bash googlecloudscript.txt site1 site2
# Reutiliza projeto, contas e arquivos de chave existentes. Sem projeto implícito.
# ROTACIONAR_CHAVES=1 cria uma chave adicional, preservando os arquivos anteriores.
set -Eeuo pipefail
umask 077
: "${PROJETO:?Defina PROJETO com o ID do projeto Google Cloud.}"
[[ "$PROJETO" =~ ^[a-z][a-z0-9-]{4,28}[a-z0-9]$ ]] || { echo 'ID de projeto inválido.' >&2; exit 2; }
(( $# > 0 )) || { echo 'Informe os apelidos dos sites como argumentos: teste1 teste2.' >&2; exit 2; }
command -v gcloud >/dev/null
command -v python3 >/dev/null
SITES=("$@")
for SITE in "${SITES[@]}"; do
  [[ "$SITE" =~ ^[a-z][a-z0-9-]{0,22}$ ]] || { echo "Apelido inválido: $SITE" >&2; exit 2; }
done
DIRETORIO_CHAVES="${DIRETORIO_CHAVES:-$HOME/wp-mcp-chaves/$PROJETO}"
mkdir -p "$DIRETORIO_CHAVES"
chmod 700 "$DIRETORIO_CHAVES"
ERRO_TEMP="$(mktemp)"
CHAVE_TEMP=''
trap 'rm -f "$ERRO_TEMP"; if [[ -n "$CHAVE_TEMP" ]]; then rm -f "$CHAVE_TEMP"; fi' EXIT
if ! gcloud projects describe "$PROJETO" --format='value(projectId)' > /dev/null 2>"$ERRO_TEMP"; then
  if grep -Eq 'NOT_FOUND|not found|does not exist' "$ERRO_TEMP"; then
    gcloud projects create "$PROJETO" --name="${NOME_PROJETO:-WP MCP Fator3}"
  else
    cat "$ERRO_TEMP" >&2
    echo 'Falha ao consultar o projeto. Confira a conta e as permissões.' >&2
    exit 1
  fi
fi
if [[ -n "${SEGUNDO_DONO:-}" ]]; then
  gcloud projects add-iam-policy-binding "$PROJETO" --member="user:$SEGUNDO_DONO" --role=roles/owner --quiet
fi
gcloud services enable analyticsadmin.googleapis.com analyticsdata.googleapis.com googleads.googleapis.com searchconsole.googleapis.com siteverification.googleapis.com sheets.googleapis.com drive.googleapis.com tagmanager.googleapis.com --project="$PROJETO"
for SITE in "${SITES[@]}"; do
  SA_ID="wp-mcp-$SITE"
  SA="$SA_ID@$PROJETO.iam.gserviceaccount.com"
  if ! gcloud iam service-accounts describe "$SA" --project="$PROJETO" > /dev/null 2>"$ERRO_TEMP"; then
    if grep -Eq 'NOT_FOUND|not found|does not exist' "$ERRO_TEMP"; then
      gcloud iam service-accounts create "$SA_ID" --display-name="WP MCP $SITE" --project="$PROJETO"
    else
      cat "$ERRO_TEMP" >&2; exit 1
    fi
  fi
  CHAVE="$DIRETORIO_CHAVES/$SITE.json"
  if [[ -f "$CHAVE" && "${ROTACIONAR_CHAVES:-0}" != 1 ]]; then
    python3 - "$CHAVE" "$SA" "$PROJETO" <<'PY'
import json,sys
with open(sys.argv[1]) as f: key=json.load(f)
if key.get('client_email') != sys.argv[2] or key.get('project_id') != sys.argv[3] or not key.get('private_key'):
    raise SystemExit('O JSON existente não corresponde ao site/projeto ou está incompleto. Nenhum arquivo foi substituído.')
PY
    echo "Reutilizado: $SITE — $SA"
    continue
  fi
  for TENTATIVA in 1 2 3 4 5 6 7 8; do
    if CHAVES_EXISTENTES="$(gcloud iam service-accounts keys list --iam-account="$SA" --managed-by=user --project="$PROJETO" --format='value(name)' 2>"$ERRO_TEMP")"; then break; fi
    if (( TENTATIVA == 8 )) || ! grep -Eq 'NOT_FOUND|not found|does not exist|UNAVAILABLE|RESOURCE_EXHAUSTED' "$ERRO_TEMP"; then cat "$ERRO_TEMP" >&2; exit 1; fi
    sleep "${ESPERA_PROPAGACAO:-15}"
  done
  if [[ -n "$CHAVES_EXISTENTES" && "${ROTACIONAR_CHAVES:-0}" != 1 ]]; then
    echo "$SITE: há chave remota e não há JSON local. A chave privada não pode ser baixada novamente." >&2
    echo 'Use o JSON original ou escolha explicitamente ROTACIONAR_CHAVES=1.' >&2
    exit 1
  fi
  CHAVE_TEMP="$(mktemp "$DIRETORIO_CHAVES/.nova-chave-XXXXXX.json")"
  OK=0
  for TENTATIVA in 1 2 3 4 5 6 7 8; do
    if gcloud iam service-accounts keys create "$CHAVE_TEMP" --iam-account="$SA" --project="$PROJETO" 2>"$ERRO_TEMP"; then OK=1; break; fi
    if ! grep -Eq 'NOT_FOUND|not found|does not exist' "$ERRO_TEMP"; then cat "$ERRO_TEMP" >&2; echo 'A chave não foi confirmada. Confira as chaves remotas antes de repetir a criação.' >&2; exit 1; fi
    (( TENTATIVA < 8 )) && sleep "${ESPERA_PROPAGACAO:-15}"
  done
  if (( OK != 1 )); then cat "$ERRO_TEMP" >&2; echo "Falha temporária persistente ao criar chave de $SITE." >&2; exit 1; fi
  python3 - "$CHAVE_TEMP" "$SA" <<'PY'
import json,sys
with open(sys.argv[1]) as f: key=json.load(f)
if key.get('client_email') != sys.argv[2] or not key.get('private_key'):
    raise SystemExit('Google não devolveu uma chave válida. Confira as chaves remotas antes de repetir.')
PY
  if [[ -f "$CHAVE" ]]; then
    # Retém o arquivo anterior; migração dos sites e remoção da chave antiga são etapas explícitas.
    CHAVE="$DIRETORIO_CHAVES/$SITE-$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM.json"
  fi
  # A publicação local é exclusiva: nunca substitui uma chave criada em paralelo.
  python3 - "$CHAVE_TEMP" "$CHAVE" <<'PYMOVE'
import os,sys
os.link(sys.argv[1],sys.argv[2])
os.unlink(sys.argv[1])
PYMOVE
  CHAVE_TEMP=''
  chmod 600 "$CHAVE"
  echo "Criado: $SITE — $SA — $CHAVE"
done
python3 - "$PROJETO" "$DIRETORIO_CHAVES" "${SITES[@]}" <<'PY'
import json,sys,pathlib
project,folder,*sites=sys.argv[1:]
manifest={'project_id':project,'sites':[{'alias':s,'service_account':f'wp-mcp-{s}@{project}.iam.gserviceaccount.com'} for s in sites], 'next_steps':['Conceder acesso aos recursos no GA4, Ads e Search Console.','Compartilhar as planilhas necessárias com a service account.','Importar o JSON no painel MCP Google e executar o teste de acesso.']}
p=pathlib.Path(folder)/'manifest.json'
p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('Manifesto:',p)
PY
printf '\nProjeto: %s\nChaves em: %s\n' "$PROJETO" "$DIRETORIO_CHAVES"
echo 'As APIs habilitadas não concedem permissões sobre propriedades, contas ou arquivos.'
if [[ "${BAIXAR_CHAVES:-0}" == 1 ]]; then
  command -v cloudshell >/dev/null
  cloudshell download "$DIRETORIO_CHAVES"
fi
F3_CLOUD_SCRIPT_RESOURCE;
