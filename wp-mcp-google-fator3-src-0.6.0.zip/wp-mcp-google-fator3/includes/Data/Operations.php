<?php
/**
 * Generated from pinned discovery fixtures by build/compile-operations.py.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return json_decode(
	<<<'F3_OPERATION_CATALOG'
{
  "analytics-admin-v1alpha": {
    "analyticsadmin.accountSummaries.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.accessBindings.batchCreate": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.accounts.accessBindings.batchDelete": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.accounts.accessBindings.batchGet": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.accessBindings.batchUpdate": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.accounts.accessBindings.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.accounts.accessBindings.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.accounts.accessBindings.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.accessBindings.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.accessBindings.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.accounts.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.accounts.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.getDataSharingSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.accounts.provisionAccountTicket": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.accounts.runAccessReport": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsadmin.accounts.searchChangeHistoryEvents": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsadmin.properties.accessBindings.batchCreate": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.accessBindings.batchDelete": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.accessBindings.batchGet": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.accessBindings.batchUpdate": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.accessBindings.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.accessBindings.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.accessBindings.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.accessBindings.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.accessBindings.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.acknowledgeUserDataCollection": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.adSenseLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.adSenseLinks.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.adSenseLinks.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.adSenseLinks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.audiences.archive": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.audiences.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.audiences.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.audiences.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.audiences.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.bigQueryLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.bigQueryLinks.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.bigQueryLinks.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.bigQueryLinks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.bigQueryLinks.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.calculatedMetrics.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.calculatedMetrics.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.calculatedMetrics.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.calculatedMetrics.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.calculatedMetrics.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.channelGroups.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.channelGroups.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.channelGroups.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.channelGroups.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.channelGroups.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.conversionEvents.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.conversionEvents.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.conversionEvents.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.conversionEvents.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.conversionEvents.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.createRollupProperty": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customDimensions.archive": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customDimensions.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customDimensions.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.customDimensions.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.customDimensions.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.customMetrics.archive": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customMetrics.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customMetrics.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.customMetrics.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.customMetrics.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.dataStreams.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.dataStreams.eventCreateRules.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.dataStreams.eventCreateRules.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.dataStreams.eventCreateRules.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.eventCreateRules.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.eventCreateRules.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.eventEditRules.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.dataStreams.eventEditRules.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.dataStreams.eventEditRules.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.eventEditRules.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.eventEditRules.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.eventEditRules.reorder": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.dataStreams.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.getDataRedactionSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.getEnhancedMeasurementSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.getGlobalSiteTag": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.sKAdNetworkConversionValueSchema.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.dataStreams.sKAdNetworkConversionValueSchema.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.dataStreams.sKAdNetworkConversionValueSchema.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.sKAdNetworkConversionValueSchema.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.sKAdNetworkConversionValueSchema.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.updateDataRedactionSettings": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.updateEnhancedMeasurementSettings": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinkProposals.approve": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinkProposals.cancel": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinkProposals.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinkProposals.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinkProposals.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinkProposals.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinks.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinks.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.displayVideo360AdvertiserLinks.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.expandedDataSets.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.expandedDataSets.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.expandedDataSets.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.expandedDataSets.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.expandedDataSets.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.firebaseLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.firebaseLinks.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.firebaseLinks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.getAttributionSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.getDataRetentionSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.getGoogleSignalsSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.getReportingIdentitySettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.getUserProvidedDataSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.googleAdsLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.googleAdsLinks.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.googleAdsLinks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.googleAdsLinks.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.keyEvents.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.keyEvents.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.keyEvents.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.keyEvents.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.keyEvents.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.provisionSubproperty": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.reportingDataAnnotations.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.reportingDataAnnotations.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.reportingDataAnnotations.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.reportingDataAnnotations.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.reportingDataAnnotations.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.rollupPropertySourceLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.rollupPropertySourceLinks.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.rollupPropertySourceLinks.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.rollupPropertySourceLinks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.runAccessReport": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsadmin.properties.searchAds360Links.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.searchAds360Links.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.searchAds360Links.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.searchAds360Links.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.searchAds360Links.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.submitUserDeletion": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.subpropertyEventFilters.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.subpropertyEventFilters.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.subpropertyEventFilters.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.subpropertyEventFilters.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.subpropertyEventFilters.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.subpropertySyncConfigs.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.subpropertySyncConfigs.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.subpropertySyncConfigs.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.updateAttributionSettings": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.updateDataRetentionSettings": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.updateGoogleSignalsSettings": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.updateReportingIdentitySettings": {
      "mode": "write",
      "verb": "PATCH"
    }
  },
  "analytics-admin-v1beta": {
    "analyticsadmin.accountSummaries.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.accounts.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.getDataSharingSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.accounts.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.accounts.provisionAccountTicket": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.accounts.runAccessReport": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsadmin.accounts.searchChangeHistoryEvents": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsadmin.properties.acknowledgeUserDataCollection": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.conversionEvents.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.conversionEvents.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.conversionEvents.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.conversionEvents.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.conversionEvents.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customDimensions.archive": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customDimensions.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customDimensions.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.customDimensions.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.customDimensions.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.customMetrics.archive": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customMetrics.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.customMetrics.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.customMetrics.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.customMetrics.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.dataStreams.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.dataStreams.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.dataStreams.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.firebaseLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.firebaseLinks.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.firebaseLinks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.getDataRetentionSettings": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.googleAdsLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.googleAdsLinks.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.googleAdsLinks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.googleAdsLinks.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.keyEvents.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsadmin.properties.keyEvents.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "analyticsadmin.properties.keyEvents.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.keyEvents.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.keyEvents.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsadmin.properties.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "analyticsadmin.properties.runAccessReport": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsadmin.properties.updateDataRetentionSettings": {
      "mode": "write",
      "verb": "PATCH"
    }
  },
  "analytics-data-v1alpha": {
    "analyticsdata.properties.audienceLists.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsdata.properties.audienceLists.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.audienceLists.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.audienceLists.query": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.chat": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsdata.properties.getMetadata": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.getPropertyQuotasSnapshot": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.recurringAudienceLists.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsdata.properties.recurringAudienceLists.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.recurringAudienceLists.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.reportTasks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsdata.properties.reportTasks.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.reportTasks.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.reportTasks.query": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.runFunnelReport": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.runReport": {
      "mode": "read",
      "verb": "POST"
    }
  },
  "analytics-data-v1beta": {
    "analyticsdata.properties.audienceExports.create": {
      "mode": "write",
      "verb": "POST"
    },
    "analyticsdata.properties.audienceExports.get": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.audienceExports.list": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.audienceExports.query": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.batchRunPivotReports": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.batchRunReports": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.checkCompatibility": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.getMetadata": {
      "mode": "read",
      "verb": "GET"
    },
    "analyticsdata.properties.runPivotReport": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.runRealtimeReport": {
      "mode": "read",
      "verb": "POST"
    },
    "analyticsdata.properties.runReport": {
      "mode": "read",
      "verb": "POST"
    }
  },
  "google-ads": {
    "googleads.audienceInsights.listInsightsEligibleDates": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.AdGroupCriterionCustomizers.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.CampaignGoalConfigs.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.CustomerCustomizers.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.Goals.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.accountBudgetProposals.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.accountLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.accountLinks.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupAdLabels.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupAds.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupAds.removeAutomaticallyCreatedAssets": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupAssetSets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupAssets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupBidModifiers.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupCriteria.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupCriterionLabels.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupCustomizers.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroupLabels.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adGroups.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.adParameters.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.ads.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assetGenerations.generateImages": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assetGenerations.generateText": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assetGroupAssets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assetGroupListingGroupFilters.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assetGroupSignals.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assetGroups.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assetSetAssets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assetSets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.assets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.audiences.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.batchJobs.addOperations": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.batchJobs.listResults": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.batchJobs.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.batchJobs.run": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.biddingDataExclusions.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.biddingSeasonalityAdjustments.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.biddingStrategies.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.billingSetups.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignAssetSets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignAssets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignBidModifiers.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignBudgets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignConversionGoals.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignCriteria.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignCustomizers.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignDrafts.listAsyncErrors": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.campaignDrafts.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignDrafts.promote": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignGroups.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignLabels.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaignSharedSets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaigns.enablePMaxBrandGuidelines": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.campaigns.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.conversionActions.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.conversionCustomVariables.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.conversionGoalCampaignConfigs.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.conversionValueRuleSets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.conversionValueRules.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.createCustomerClient": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customAudiences.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customConversionGoals.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customInterests.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerAssetSets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerAssets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerClientLinks.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerConversionGoals.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerLabels.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerManagerLinks.moveManagerLink": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerManagerLinks.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerNegativeCriteria.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerSkAdNetworkConversionValueSchemas.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerUserAccessInvitations.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customerUserAccesses.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.customizerAttributes.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.dataLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.dataLinks.remove": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.dataLinks.update": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.experimentArms.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.experiments.endExperiment": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.experiments.graduateExperiment": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.experiments.listExperimentAsyncErrors": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.experiments.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.experiments.promoteExperiment": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.experiments.scheduleExperiment": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.generateAdGroupThemes": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateAudienceCompositionInsights": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateAudienceDefinition": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateAudienceOverlapInsights": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateBenchmarksMetrics": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateCreatorInsights": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateInsightsFinderReport": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateKeywordForecastMetrics": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateKeywordHistoricalMetrics": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateKeywordIdeas": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateReachForecast": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateShareablePreviews": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.generateSuggestedTargetingInsights": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateTargetingSuggestionMetrics": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.generateTrendingInsights": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.getIdentityVerification": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.googleAds.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.googleAds.search": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.googleAds.searchStream": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.incentives.applyIncentive": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.invoices.list": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.keywordPlanAdGroupKeywords.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.keywordPlanAdGroups.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.keywordPlanCampaignKeywords.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.keywordPlanCampaigns.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.keywordPlans.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.labels.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.listAccessibleCustomers": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.localServices.appendLeadConversation": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.localServicesLeads.provideLeadFeedback": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.multiPartyAuthReview.resolve": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.offlineUserDataJobs.addOperations": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.offlineUserDataJobs.create": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.offlineUserDataJobs.run": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.operations.cancel": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.operations.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "googleads.customers.operations.get": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.operations.list": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.operations.wait": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.paymentsAccounts.list": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.productLinkInvitations.create": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.productLinkInvitations.remove": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.productLinkInvitations.update": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.productLinks.create": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.productLinks.remove": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.recommendationSubscriptions.mutateRecommendationSubscription": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.recommendations.apply": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.recommendations.dismiss": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.recommendations.generate": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.remarketingActions.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.removeCampaignAutomaticallyCreatedAsset": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.reservations.bookCampaigns": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.reservations.quoteCampaigns": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.searchAudienceInsightsAttributes": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.sharedCriteria.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.sharedSets.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.smartCampaignSettings.getSmartCampaignStatus": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.customers.smartCampaignSettings.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.startIdentityVerification": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.suggestBrands": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.suggestKeywordThemes": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.suggestSmartCampaignAd": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.suggestSmartCampaignBudgetOptions": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.suggestTravelAssets": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.customers.thirdPartyAppAnalyticsLinks.regenerateShareableLinkId": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.uploadCallConversions": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.uploadClickConversions": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.uploadConversionAdjustments": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.uploadUserData": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.userListCustomerTypes.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.userLists.mutate": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.youTubeVideoUploads.remove": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.customers.youTubeVideoUploads.update": {
      "mode": "write",
      "verb": "POST"
    },
    "googleads.generateConversionRates": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.geoTargetConstants.suggest": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.googleAdsFields.get": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.googleAdsFields.search": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.incentives.fetchIncentive": {
      "mode": "read",
      "verb": "GET"
    },
    "googleads.keywordThemeConstants.suggest": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.listBenchmarksAvailableDates": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.listBenchmarksLocations": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.listBenchmarksProducts": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.listBenchmarksSources": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.listPlannableLocations": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.listPlannableProducts": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.listPlannableUserInterests": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.listPlannableUserLists": {
      "mode": "read",
      "verb": "POST"
    },
    "googleads.media.upload": {
      "mode": "write",
      "verb": "POST"
    }
  },
  "search-console": {
    "searchconsole.urlInspection.index.inspect": {
      "mode": "read",
      "verb": "POST"
    },
    "searchconsole.urlTestingTools.mobileFriendlyTest.run": {
      "mode": "write",
      "verb": "POST"
    },
    "webmasters.searchanalytics.query": {
      "mode": "read",
      "verb": "POST"
    },
    "webmasters.sitemaps.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "webmasters.sitemaps.get": {
      "mode": "read",
      "verb": "GET"
    },
    "webmasters.sitemaps.list": {
      "mode": "read",
      "verb": "GET"
    },
    "webmasters.sitemaps.submit": {
      "mode": "write",
      "verb": "PUT"
    },
    "webmasters.sites.add": {
      "mode": "write",
      "verb": "PUT"
    },
    "webmasters.sites.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "webmasters.sites.get": {
      "mode": "read",
      "verb": "GET"
    },
    "webmasters.sites.list": {
      "mode": "read",
      "verb": "GET"
    }
  },
  "site-verification": {
    "siteVerification.webResource.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "siteVerification.webResource.get": {
      "mode": "read",
      "verb": "GET"
    },
    "siteVerification.webResource.getToken": {
      "mode": "read",
      "verb": "POST"
    },
    "siteVerification.webResource.insert": {
      "mode": "write",
      "verb": "POST"
    },
    "siteVerification.webResource.list": {
      "mode": "read",
      "verb": "GET"
    },
    "siteVerification.webResource.patch": {
      "mode": "write",
      "verb": "PATCH"
    },
    "siteVerification.webResource.update": {
      "mode": "write",
      "verb": "PUT"
    }
  },
  "sheets": {
    "sheets.spreadsheets.batchUpdate": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.create": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.developerMetadata.get": {
      "mode": "read",
      "verb": "GET"
    },
    "sheets.spreadsheets.developerMetadata.search": {
      "mode": "read",
      "verb": "POST"
    },
    "sheets.spreadsheets.get": {
      "mode": "read",
      "verb": "GET"
    },
    "sheets.spreadsheets.getByDataFilter": {
      "mode": "read",
      "verb": "POST"
    },
    "sheets.spreadsheets.sheets.copyTo": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.values.append": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.values.batchClear": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.values.batchClearByDataFilter": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.values.batchGet": {
      "mode": "read",
      "verb": "GET"
    },
    "sheets.spreadsheets.values.batchGetByDataFilter": {
      "mode": "read",
      "verb": "POST"
    },
    "sheets.spreadsheets.values.batchUpdate": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.values.batchUpdateByDataFilter": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.values.clear": {
      "mode": "write",
      "verb": "POST"
    },
    "sheets.spreadsheets.values.get": {
      "mode": "read",
      "verb": "GET"
    },
    "sheets.spreadsheets.values.update": {
      "mode": "write",
      "verb": "PUT"
    }
  },
  "drive": {
    "drive.about.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.accessproposals.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.accessproposals.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.accessproposals.resolve": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.approvals.approve": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.approvals.cancel": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.approvals.comment": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.approvals.decline": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.approvals.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.approvals.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.approvals.reassign": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.approvals.start": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.apps.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.apps.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.changes.getStartPageToken": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.changes.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.changes.watch": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.channels.stop": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.comments.create": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.comments.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "drive.comments.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.comments.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.comments.update": {
      "mode": "write",
      "verb": "PATCH"
    },
    "drive.drives.create": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.drives.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "drive.drives.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.drives.hide": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.drives.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.drives.unhide": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.drives.update": {
      "mode": "write",
      "verb": "PATCH"
    },
    "drive.files.copy": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.files.create": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.files.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "drive.files.download": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.files.emptyTrash": {
      "mode": "write",
      "verb": "DELETE"
    },
    "drive.files.export": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.files.generateCseToken": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.files.generateIds": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.files.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.files.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.files.listLabels": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.files.modifyLabels": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.files.update": {
      "mode": "write",
      "verb": "PATCH"
    },
    "drive.files.watch": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.operations.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.permissions.create": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.permissions.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "drive.permissions.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.permissions.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.permissions.update": {
      "mode": "write",
      "verb": "PATCH"
    },
    "drive.replies.create": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.replies.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "drive.replies.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.replies.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.replies.update": {
      "mode": "write",
      "verb": "PATCH"
    },
    "drive.revisions.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "drive.revisions.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.revisions.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.revisions.update": {
      "mode": "write",
      "verb": "PATCH"
    },
    "drive.teamdrives.create": {
      "mode": "write",
      "verb": "POST"
    },
    "drive.teamdrives.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "drive.teamdrives.get": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.teamdrives.list": {
      "mode": "read",
      "verb": "GET"
    },
    "drive.teamdrives.update": {
      "mode": "write",
      "verb": "PATCH"
    }
  },
  "tag-manager": {
    "tagmanager.accounts.containers.combine": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.destinations.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.destinations.link": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.destinations.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.environments.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.environments.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.environments.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.environments.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.environments.reauthorize": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.environments.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.lookup": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.move_tag_id": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.snippet": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.version_headers.latest": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.version_headers.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.versions.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.versions.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.versions.live": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.versions.publish": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.versions.set_latest": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.versions.undelete": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.versions.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.built_in_variables.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.built_in_variables.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.built_in_variables.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.built_in_variables.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.bulk_update": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.clients.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.clients.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.clients.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.clients.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.clients.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.clients.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.create_version": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.folders.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.folders.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.folders.entities": {
      "mode": "read",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.folders.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.folders.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.folders.move_entities_to_folder": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.folders.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.folders.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.getStatus": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.quick_preview": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.resolve_conflict": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.sync": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.tags.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.tags.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.tags.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.tags.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.tags.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.tags.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.templates.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.templates.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.templates.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.templates.import_from_gallery": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.templates.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.templates.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.templates.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.transformations.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.transformations.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.transformations.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.transformations.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.transformations.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.transformations.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.triggers.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.triggers.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.triggers.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.triggers.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.triggers.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.triggers.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.variables.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.variables.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.variables.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.variables.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.variables.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.variables.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.containers.workspaces.zones.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.zones.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.containers.workspaces.zones.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.zones.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.containers.workspaces.zones.revert": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.containers.workspaces.zones.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.update": {
      "mode": "write",
      "verb": "PUT"
    },
    "tagmanager.accounts.user_permissions.create": {
      "mode": "write",
      "verb": "POST"
    },
    "tagmanager.accounts.user_permissions.delete": {
      "mode": "write",
      "verb": "DELETE"
    },
    "tagmanager.accounts.user_permissions.get": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.user_permissions.list": {
      "mode": "read",
      "verb": "GET"
    },
    "tagmanager.accounts.user_permissions.update": {
      "mode": "write",
      "verb": "PUT"
    }
  }
}
F3_OPERATION_CATALOG
	,
	true
);
