<?php
/**
 * Generated from the pinned Tag Manager v2 Discovery document.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return json_decode(
	<<<'F3_GTM_DISCOVERY'
{
  "schemas": {
    "ContainerVersion": {
      "properties": {
        "containerId": {
          "description": "GTM Container ID.",
          "type": "string"
        },
        "folder": {
          "description": "The folders in the container that this version was taken from.",
          "items": {
            "$ref": "Folder"
          },
          "type": "array"
        },
        "transformation": {
          "type": "array",
          "items": {
            "$ref": "Transformation"
          },
          "description": "The transformations in the container that this version was taken from."
        },
        "description": {
          "description": "Container version description.",
          "type": "string"
        },
        "trigger": {
          "items": {
            "$ref": "Trigger"
          },
          "type": "array",
          "description": "The triggers in the container that this version was taken from."
        },
        "accountId": {
          "type": "string",
          "description": "GTM Account ID."
        },
        "customTemplate": {
          "items": {
            "$ref": "CustomTemplate"
          },
          "description": "The custom templates in the container that this version was taken from.",
          "type": "array"
        },
        "container": {
          "$ref": "Container",
          "description": "The container that this version was taken from."
        },
        "fingerprint": {
          "description": "The fingerprint of the GTM Container Version as computed at storage time. This value is recomputed whenever the container version is modified.",
          "type": "string"
        },
        "containerVersionId": {
          "description": "The Container Version ID uniquely identifies the GTM Container Version.",
          "type": "string"
        },
        "gtagConfig": {
          "items": {
            "$ref": "GtagConfig"
          },
          "type": "array",
          "description": "The Google tag configs in the container that this version was taken from."
        },
        "tag": {
          "items": {
            "$ref": "Tag"
          },
          "description": "The tags in the container that this version was taken from.",
          "type": "array"
        },
        "builtInVariable": {
          "items": {
            "$ref": "BuiltInVariable"
          },
          "description": "The built-in variables in the container that this version was taken from.",
          "type": "array"
        },
        "deleted": {
          "description": "A value of true indicates this container version has been deleted.",
          "type": "boolean"
        },
        "name": {
          "type": "string",
          "description": "Container version display name."
        },
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI",
          "type": "string"
        },
        "client": {
          "type": "array",
          "items": {
            "$ref": "Client"
          },
          "description": "The clients in the container that this version was taken from."
        },
        "path": {
          "description": "GTM Container Version's API relative path.",
          "type": "string"
        },
        "zone": {
          "type": "array",
          "description": "The zones in the container that this version was taken from.",
          "items": {
            "$ref": "Zone"
          }
        },
        "variable": {
          "type": "array",
          "items": {
            "$ref": "Variable"
          },
          "description": "The variables in the container that this version was taken from."
        }
      },
      "type": "object",
      "description": "Represents a Google Tag Manager Container Version.",
      "id": "ContainerVersion"
    },
    "Transformation": {
      "description": "Represents a Google Tag Manager Transformation.",
      "properties": {
        "accountId": {
          "type": "string",
          "description": "GTM Account ID."
        },
        "containerId": {
          "description": "GTM Container ID.",
          "type": "string"
        },
        "parameter": {
          "type": "array",
          "items": {
            "$ref": "Parameter"
          },
          "description": "The transformation's parameters."
        },
        "transformationId": {
          "type": "string",
          "description": "The Transformation ID uniquely identifies the GTM transformation."
        },
        "notes": {
          "description": "User notes on how to apply this transformation in the container.",
          "type": "string"
        },
        "path": {
          "description": "GTM transformation's API relative path.",
          "type": "string"
        },
        "parentFolderId": {
          "type": "string",
          "description": "Parent folder id."
        },
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI",
          "type": "string"
        },
        "type": {
          "description": "Transformation type.",
          "type": "string"
        },
        "name": {
          "description": "Transformation display name.",
          "type": "string"
        },
        "fingerprint": {
          "type": "string",
          "description": "The fingerprint of the GTM Transformation as computed at storage time. This value is recomputed whenever the transformation is modified."
        },
        "workspaceId": {
          "type": "string",
          "description": "GTM Workspace ID."
        }
      },
      "id": "Transformation",
      "type": "object"
    },
    "BuiltInVariable": {
      "properties": {
        "workspaceId": {
          "type": "string",
          "description": "GTM Workspace ID."
        },
        "name": {
          "description": "Name of the built-in variable to be used to refer to the built-in variable.",
          "type": "string"
        },
        "type": {
          "enumDescriptions": [
            "",
            "",
            "",
            "",
            "",
            "For web or mobile.",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "For web or mobile.",
            "",
            "For web or mobile.",
            "For web or mobile.",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
          ],
          "type": "string",
          "enum": [
            "builtInVariableTypeUnspecified",
            "pageUrl",
            "pageHostname",
            "pagePath",
            "referrer",
            "event",
            "clickElement",
            "clickClasses",
            "clickId",
            "clickTarget",
            "clickUrl",
            "clickText",
            "firstPartyServingUrl",
            "formElement",
            "formClasses",
            "formId",
            "formTarget",
            "formUrl",
            "formText",
            "errorMessage",
            "errorUrl",
            "errorLine",
            "newHistoryUrl",
            "oldHistoryUrl",
            "newHistoryFragment",
            "oldHistoryFragment",
            "newHistoryState",
            "oldHistoryState",
            "historySource",
            "containerVersion",
            "debugMode",
            "randomNumber",
            "containerId",
            "appId",
            "appName",
            "appVersionCode",
            "appVersionName",
            "language",
            "osVersion",
            "platform",
            "sdkVersion",
            "deviceName",
            "resolution",
            "advertiserId",
            "advertisingTrackingEnabled",
            "htmlId",
            "environmentName",
            "ampBrowserLanguage",
            "ampCanonicalPath",
            "ampCanonicalUrl",
            "ampCanonicalHost",
            "ampReferrer",
            "ampTitle",
            "ampClientId",
            "ampClientTimezone",
            "ampClientTimestamp",
            "ampClientScreenWidth",
            "ampClientScreenHeight",
            "ampClientScrollX",
            "ampClientScrollY",
            "ampClientMaxScrollX",
            "ampClientMaxScrollY",
            "ampTotalEngagedTime",
            "ampPageViewId",
            "ampPageLoadTime",
            "ampPageDownloadTime",
            "ampGtmEvent",
            "eventName",
            "firebaseEventParameterCampaign",
            "firebaseEventParameterCampaignAclid",
            "firebaseEventParameterCampaignAnid",
            "firebaseEventParameterCampaignClickTimestamp",
            "firebaseEventParameterCampaignContent",
            "firebaseEventParameterCampaignCp1",
            "firebaseEventParameterCampaignGclid",
            "firebaseEventParameterCampaignSource",
            "firebaseEventParameterCampaignTerm",
            "firebaseEventParameterCurrency",
            "firebaseEventParameterDynamicLinkAcceptTime",
            "firebaseEventParameterDynamicLinkLinkid",
            "firebaseEventParameterNotificationMessageDeviceTime",
            "firebaseEventParameterNotificationMessageId",
            "firebaseEventParameterNotificationMessageName",
            "firebaseEventParameterNotificationMessageTime",
            "firebaseEventParameterNotificationTopic",
            "firebaseEventParameterPreviousAppVersion",
            "firebaseEventParameterPreviousOsVersion",
            "firebaseEventParameterPrice",
            "firebaseEventParameterProductId",
            "firebaseEventParameterQuantity",
            "firebaseEventParameterValue",
            "videoProvider",
            "videoUrl",
            "videoTitle",
            "videoDuration",
            "videoPercent",
            "videoVisible",
            "videoStatus",
            "videoCurrentTime",
            "scrollDepthThreshold",
            "scrollDepthUnits",
            "scrollDepthDirection",
            "elementVisibilityRatio",
            "elementVisibilityTime",
            "elementVisibilityFirstTime",
            "elementVisibilityRecentTime",
            "requestPath",
            "requestMethod",
            "clientName",
            "queryString",
            "serverPageLocationUrl",
            "serverPageLocationPath",
            "serverPageLocationHostname",
            "visitorRegion",
            "analyticsClientId",
            "analyticsSessionId",
            "analyticsSessionNumber"
          ],
          "description": "Type of built-in variable."
        },
        "accountId": {
          "type": "string",
          "description": "GTM Account ID."
        },
        "containerId": {
          "type": "string",
          "description": "GTM Container ID."
        },
        "path": {
          "type": "string",
          "description": "GTM BuiltInVariable's API relative path."
        }
      },
      "description": "Built-in variables are a special category of variables that are pre-created and non-customizable. They provide common functionality like accessing properties of the gtm data layer, monitoring clicks, or accessing elements of a page URL.",
      "id": "BuiltInVariable",
      "type": "object"
    },
    "RevertTagResponse": {
      "description": "The result of reverting a tag in a workspace.",
      "type": "object",
      "id": "RevertTagResponse",
      "properties": {
        "tag": {
          "description": "Tag as it appears in the latest container version since the last workspace synchronization operation. If no tag is present, that means the tag was deleted in the latest container version.",
          "$ref": "Tag"
        }
      }
    },
    "ListEnabledBuiltInVariablesResponse": {
      "id": "ListEnabledBuiltInVariablesResponse",
      "properties": {
        "builtInVariable": {
          "type": "array",
          "description": "All GTM BuiltInVariables of a GTM container.",
          "items": {
            "$ref": "BuiltInVariable"
          }
        },
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        }
      },
      "description": "A list of enabled built-in variables.",
      "type": "object"
    },
    "GalleryReference": {
      "properties": {
        "galleryTemplateId": {
          "type": "string",
          "description": "ID for the gallery template that is generated once during first sync and travels with the template redirects."
        },
        "owner": {
          "description": "The name of the owner for the community gallery template.",
          "type": "string"
        },
        "version": {
          "description": "The version of the community gallery template.",
          "type": "string"
        },
        "repository": {
          "type": "string",
          "description": "The name of the repository for the community gallery template."
        },
        "isModified": {
          "type": "boolean",
          "description": "If a user has manually edited the community gallery template."
        },
        "host": {
          "type": "string",
          "description": "The name of the host for the community gallery template."
        },
        "signature": {
          "description": "The signature of the community gallery template as computed at import time. This value is recomputed whenever the template is updated from the gallery.",
          "type": "string"
        },
        "templateDeveloperId": {
          "type": "string",
          "description": "The developer id of the community gallery template. This value is set whenever the template is created from the gallery."
        }
      },
      "type": "object",
      "description": "Represents the link between a custom template and an entry on the Community Template Gallery site.",
      "id": "GalleryReference"
    },
    "CreateContainerVersionRequestVersionOptions": {
      "type": "object",
      "description": "Options for new container versions.",
      "id": "CreateContainerVersionRequestVersionOptions",
      "properties": {
        "name": {
          "description": "The name of the container version to be created.",
          "type": "string"
        },
        "notes": {
          "description": "The notes of the container version to be created.",
          "type": "string"
        }
      }
    },
    "ZoneChildContainer": {
      "id": "ZoneChildContainer",
      "type": "object",
      "properties": {
        "publicId": {
          "type": "string",
          "description": "The child container's public id."
        },
        "nickname": {
          "description": "The zone's nickname for the child container.",
          "type": "string"
        }
      },
      "description": "Represents a child container of a Zone."
    },
    "GetContainerSnippetResponse": {
      "id": "GetContainerSnippetResponse",
      "type": "object",
      "properties": {
        "snippet": {
          "type": "string",
          "description": "Tagging snippet for a Container."
        },
        "containerConfig": {
          "description": "Server container config param for manually provisioning a tagging server.",
          "type": "string"
        }
      }
    },
    "VariableFormatValue": {
      "id": "VariableFormatValue",
      "properties": {
        "convertTrueToValue": {
          "$ref": "Parameter",
          "description": "The value to convert if a variable value is true."
        },
        "convertToBoolean": {
          "description": "The option to convert a variable value to a boolean.",
          "type": "boolean"
        },
        "convertNullToValue": {
          "$ref": "Parameter",
          "description": "The value to convert if a variable value is null."
        },
        "convertUndefinedToValue": {
          "description": "The value to convert if a variable value is undefined.",
          "$ref": "Parameter"
        },
        "convertToNumber": {
          "enumDescriptions": [
            "",
            "The option to convert a variable value to a number with a period as the decimal separator.",
            "The option to convert a variable value to a number with a comma as the decimal separator.",
            "The option to convert a variable value to a number with automatic decimal separator detection."
          ],
          "type": "string",
          "enum": [
            "decimalSeparatorTypeUnspecified",
            "period",
            "comma",
            "automatic"
          ],
          "description": "The option to convert a variable value to a number."
        },
        "caseConversionType": {
          "type": "string",
          "enum": [
            "none",
            "lowercase",
            "uppercase"
          ],
          "description": "The option to convert a string-type variable value to either lowercase or uppercase.",
          "enumDescriptions": [
            "",
            "The option to convert a variable value to lowercase.",
            "The option to convert a variable value to uppercase."
          ]
        },
        "convertFalseToValue": {
          "description": "The value to convert if a variable value is false.",
          "$ref": "Parameter"
        }
      },
      "type": "object"
    },
    "ZoneTypeRestriction": {
      "id": "ZoneTypeRestriction",
      "properties": {
        "enable": {
          "description": "True if type restrictions have been enabled for this Zone.",
          "type": "boolean"
        },
        "whitelistedTypeId": {
          "description": "List of type public ids that have been whitelisted for use in this Zone.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "type": "object",
      "description": "Represents a Zone's type restrictions."
    },
    "Workspace": {
      "id": "Workspace",
      "properties": {
        "fingerprint": {
          "description": "The fingerprint of the GTM Workspace as computed at storage time. This value is recomputed whenever the workspace is modified.",
          "type": "string"
        },
        "workspaceId": {
          "description": "The Workspace ID uniquely identifies the GTM Workspace.",
          "type": "string"
        },
        "name": {
          "type": "string",
          "description": "Workspace display name."
        },
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI",
          "type": "string"
        },
        "description": {
          "description": "Workspace description.",
          "type": "string"
        },
        "containerId": {
          "description": "GTM Container ID.",
          "type": "string"
        },
        "path": {
          "description": "GTM Workspace's API relative path.",
          "type": "string"
        },
        "accountId": {
          "description": "GTM Account ID.",
          "type": "string"
        }
      },
      "type": "object",
      "description": "Represents a Google Tag Manager Container Workspace."
    },
    "Folder": {
      "id": "Folder",
      "type": "object",
      "properties": {
        "containerId": {
          "type": "string",
          "description": "GTM Container ID."
        },
        "folderId": {
          "type": "string",
          "description": "The Folder ID uniquely identifies the GTM Folder."
        },
        "name": {
          "description": "Folder display name.",
          "type": "string"
        },
        "accountId": {
          "type": "string",
          "description": "GTM Account ID."
        },
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI",
          "type": "string"
        },
        "path": {
          "type": "string",
          "description": "GTM Folder's API relative path."
        },
        "notes": {
          "type": "string",
          "description": "User notes on how to apply this folder in the container."
        },
        "workspaceId": {
          "type": "string",
          "description": "GTM Workspace ID."
        },
        "fingerprint": {
          "type": "string",
          "description": "The fingerprint of the GTM Folder as computed at storage time. This value is recomputed whenever the folder is modified."
        }
      },
      "description": "Represents a Google Tag Manager Folder."
    },
    "RevertClientResponse": {
      "type": "object",
      "properties": {
        "client": {
          "description": "Client as it appears in the latest container version since the last workspace synchronization operation. If no client is present, that means the client was deleted in the latest container version.",
          "$ref": "Client"
        }
      },
      "description": "The result of reverting a client in a workspace.",
      "id": "RevertClientResponse"
    },
    "RevertTransformationResponse": {
      "type": "object",
      "description": "The result of reverting a transformation in a workspace.",
      "properties": {
        "transformation": {
          "description": "Transformation as it appears in the latest container version since the last workspace synchronization operation. If no transformation is present, that means the transformation was deleted in the latest container version.",
          "$ref": "Transformation"
        }
      },
      "id": "RevertTransformationResponse"
    },
    "RevertTriggerResponse": {
      "type": "object",
      "properties": {
        "trigger": {
          "$ref": "Trigger",
          "description": "Trigger as it appears in the latest container version since the last workspace synchronization operation. If no trigger is present, that means the trigger was deleted in the latest container version."
        }
      },
      "id": "RevertTriggerResponse",
      "description": "The result of reverting a trigger in a workspace."
    },
    "TeardownTag": {
      "description": "Represents a tag that fires after another tag in order to tear down dependencies.",
      "id": "TeardownTag",
      "properties": {
        "tagName": {
          "description": "The name of the teardown tag.",
          "type": "string"
        },
        "stopTeardownOnFailure": {
          "description": "If true, fire the teardown tag if and only if the main tag fires successfully. If false, fire the teardown tag regardless of main tag firing status.",
          "type": "boolean"
        }
      },
      "type": "object"
    },
    "ListGtagConfigResponse": {
      "type": "object",
      "properties": {
        "gtagConfig": {
          "items": {
            "$ref": "GtagConfig"
          },
          "description": "All Google tag configs in a Container.",
          "type": "array"
        },
        "nextPageToken": {
          "type": "string",
          "description": "Continuation token for fetching the next page of results."
        }
      },
      "id": "ListGtagConfigResponse"
    },
    "ListAccountsResponse": {
      "type": "object",
      "properties": {
        "nextPageToken": {
          "type": "string",
          "description": "Continuation token for fetching the next page of results."
        },
        "account": {
          "type": "array",
          "items": {
            "$ref": "Account"
          },
          "description": "List of GTM Accounts that a user has access to."
        }
      },
      "description": "List Accounts Response.",
      "id": "ListAccountsResponse"
    },
    "CreateBuiltInVariableResponse": {
      "properties": {
        "builtInVariable": {
          "description": "List of created built-in variables.",
          "type": "array",
          "items": {
            "$ref": "BuiltInVariable"
          }
        }
      },
      "type": "object",
      "id": "CreateBuiltInVariableResponse"
    },
    "RevertFolderResponse": {
      "properties": {
        "folder": {
          "description": "Folder as it appears in the latest container version since the last workspace synchronization operation. If no folder is present, that means the folder was deleted in the latest container version.",
          "$ref": "Folder"
        }
      },
      "id": "RevertFolderResponse",
      "description": "The result of reverting folder changes in a workspace.",
      "type": "object"
    },
    "RevertZoneResponse": {
      "type": "object",
      "description": "The result of reverting a zone in a workspace.",
      "id": "RevertZoneResponse",
      "properties": {
        "zone": {
          "description": "Zone as it appears in the latest container version since the last workspace synchronization operation. If no zone is present, that means the zone was deleted in the latest container version.",
          "$ref": "Zone"
        }
      }
    },
    "Container": {
      "id": "Container",
      "type": "object",
      "description": "Represents a Google Tag Manager Container, which specifies the platform tags will run on, manages workspaces, and retains container versions.",
      "properties": {
        "usageContext": {
          "type": "array",
          "items": {
            "enumDescriptions": [
              "",
              "",
              "",
              "",
              "",
              "",
              "",
              ""
            ],
            "type": "string",
            "enum": [
              "usageContextUnspecified",
              "web",
              "android",
              "ios",
              "androidSdk5",
              "iosSdk5",
              "amp",
              "server"
            ]
          },
          "description": "List of Usage Contexts for the Container. Valid values include: web, android, or ios."
        },
        "path": {
          "type": "string",
          "description": "GTM Container's API relative path."
        },
        "tagIds": {
          "type": "array",
          "description": "All Tag IDs that refer to this Container.",
          "items": {
            "type": "string"
          }
        },
        "name": {
          "description": "Container display name.",
          "type": "string"
        },
        "fingerprint": {
          "type": "string",
          "description": "The fingerprint of the GTM Container as computed at storage time. This value is recomputed whenever the account is modified."
        },
        "containerId": {
          "description": "The Container ID uniquely identifies the GTM Container.",
          "type": "string"
        },
        "notes": {
          "type": "string",
          "description": "Container Notes."
        },
        "accountId": {
          "type": "string",
          "description": "GTM Account ID."
        },
        "domainName": {
          "items": {
            "type": "string"
          },
          "type": "array",
          "description": "List of domain names associated with the Container."
        },
        "features": {
          "$ref": "ContainerFeatures",
          "description": "Read-only Container feature set."
        },
        "taggingServerUrls": {
          "description": "List of server-side container URLs for the Container. If multiple URLs are provided, all URL paths must match.",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "publicId": {
          "description": "Container Public ID.",
          "type": "string"
        },
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI",
          "type": "string"
        }
      }
    },
    "MergeConflict": {
      "description": "Represents a merge conflict.",
      "id": "MergeConflict",
      "properties": {
        "entityInBaseVersion": {
          "description": "The base version entity (since the latest sync operation) that has conflicting changes compared to the workspace. If this field is missing, it means the workspace entity is deleted from the base version.",
          "$ref": "Entity"
        },
        "entityInWorkspace": {
          "$ref": "Entity",
          "description": "The workspace entity that has conflicting changes compared to the base version. If an entity is deleted in a workspace, it will still appear with a deleted change status."
        }
      },
      "type": "object"
    },
    "ListUserPermissionsResponse": {
      "id": "ListUserPermissionsResponse",
      "properties": {
        "userPermission": {
          "description": "All GTM UserPermissions of a GTM Account.",
          "type": "array",
          "items": {
            "$ref": "UserPermission"
          }
        },
        "nextPageToken": {
          "type": "string",
          "description": "Continuation token for fetching the next page of results."
        }
      },
      "type": "object",
      "description": "List user permissions response."
    },
    "QuickPreviewResponse": {
      "id": "QuickPreviewResponse",
      "properties": {
        "compilerError": {
          "type": "boolean",
          "description": "Were there compiler errors or not."
        },
        "containerVersion": {
          "description": "The quick previewed container version.",
          "$ref": "ContainerVersion"
        },
        "syncStatus": {
          "$ref": "SyncStatus",
          "description": "Whether quick previewing failed when syncing the workspace to the latest container version."
        }
      },
      "description": "Response to quick previewing a workspace.",
      "type": "object"
    },
    "ListContainerVersionsResponse": {
      "description": "List container versions response.",
      "properties": {
        "containerVersionHeader": {
          "items": {
            "$ref": "ContainerVersionHeader"
          },
          "type": "array",
          "description": "All container version headers of a GTM Container."
        },
        "nextPageToken": {
          "type": "string",
          "description": "Continuation token for fetching the next page of results."
        }
      },
      "type": "object",
      "id": "ListContainerVersionsResponse"
    },
    "Tag": {
      "properties": {
        "monitoringMetadata": {
          "description": "A map of key-value pairs of tag metadata to be included in the event data for tag monitoring. Notes: - This parameter must be type MAP. - Each parameter in the map are type TEMPLATE, however cannot contain variable references. ",
          "$ref": "Parameter"
        },
        "liveOnly": {
          "type": "boolean",
          "description": "If set to true, this tag will only fire in the live environment (e.g. not in preview or debug mode)."
        },
        "tagFiringOption": {
          "description": "Option to fire this tag.",
          "type": "string",
          "enum": [
            "tagFiringOptionUnspecified",
            "unlimited",
            "oncePerEvent",
            "oncePerLoad"
          ],
          "enumDescriptions": [
            "",
            "Tag can be fired multiple times per event.",
            "Tag can only be fired per event but can be fired multiple times per load (e.g., app load or page load).",
            "Tag can only be fired per load (e.g., app load or page load)."
          ]
        },
        "fingerprint": {
          "description": "The fingerprint of the GTM Tag as computed at storage time. This value is recomputed whenever the tag is modified.",
          "type": "string"
        },
        "setupTag": {
          "type": "array",
          "description": "The list of setup tags. Currently we only allow one.",
          "items": {
            "$ref": "SetupTag"
          }
        },
        "scheduleEndMs": {
          "description": "The end timestamp in milliseconds to schedule a tag.",
          "format": "int64",
          "type": "string"
        },
        "tagManagerUrl": {
          "type": "string",
          "description": "Auto generated link to the tag manager UI"
        },
        "monitoringMetadataTagNameKey": {
          "description": "If non-empty, then the tag display name will be included in the monitoring metadata map using the key specified.",
          "type": "string"
        },
        "parentFolderId": {
          "description": "Parent folder id.",
          "type": "string"
        },
        "path": {
          "type": "string",
          "description": "GTM Tag's API relative path."
        },
        "name": {
          "description": "Tag display name.",
          "type": "string"
        },
        "firingTriggerId": {
          "description": "Firing trigger IDs. A tag will fire when any of the listed triggers are true and all of its blockingTriggerIds (if any specified) are false.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "containerId": {
          "type": "string",
          "description": "GTM Container ID."
        },
        "blockingTriggerId": {
          "description": "Blocking trigger IDs. If any of the listed triggers evaluate to true, the tag will not fire.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "paused": {
          "type": "boolean",
          "description": "Indicates whether the tag is paused, which prevents the tag from firing."
        },
        "parameter": {
          "items": {
            "$ref": "Parameter"
          },
          "description": "The tag's parameters.",
          "type": "array"
        },
        "priority": {
          "description": "User defined numeric priority of the tag. Tags are fired asynchronously in order of priority. Tags with higher numeric value fire first. A tag's priority can be a positive or negative value. The default value is 0.",
          "$ref": "Parameter"
        },
        "teardownTag": {
          "description": "The list of teardown tags. Currently we only allow one.",
          "type": "array",
          "items": {
            "$ref": "TeardownTag"
          }
        },
        "workspaceId": {
          "description": "GTM Workspace ID.",
          "type": "string"
        },
        "consentSettings": {
          "$ref": "TagConsentSetting",
          "description": "Consent settings of a tag."
        },
        "notes": {
          "type": "string",
          "description": "User notes on how to apply this tag in the container."
        },
        "accountId": {
          "type": "string",
          "description": "GTM Account ID."
        },
        "type": {
          "description": "GTM Tag Type.",
          "type": "string"
        },
        "scheduleStartMs": {
          "type": "string",
          "description": "The start timestamp in milliseconds to schedule a tag.",
          "format": "int64"
        },
        "tagId": {
          "description": "The Tag ID uniquely identifies the GTM Tag.",
          "type": "string"
        }
      },
      "description": "Represents a Google Tag Manager Tag.",
      "type": "object",
      "id": "Tag"
    },
    "AccountAccess": {
      "type": "object",
      "properties": {
        "permission": {
          "description": "Whether the user has no access, user access, or admin access to an account.",
          "type": "string",
          "enum": [
            "accountPermissionUnspecified",
            "noAccess",
            "user",
            "admin"
          ],
          "enumDescriptions": [
            "",
            "",
            "",
            ""
          ]
        }
      },
      "description": "Defines the Google Tag Manager Account access permissions.",
      "id": "AccountAccess"
    },
    "ListZonesResponse": {
      "type": "object",
      "id": "ListZonesResponse",
      "properties": {
        "zone": {
          "items": {
            "$ref": "Zone"
          },
          "description": "All GTM Zones of a GTM Container.",
          "type": "array"
        },
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        }
      }
    },
    "Zone": {
      "properties": {
        "accountId": {
          "description": "GTM Account ID.",
          "type": "string"
        },
        "typeRestriction": {
          "description": "This Zone's type restrictions.",
          "$ref": "ZoneTypeRestriction"
        },
        "workspaceId": {
          "description": "GTM Workspace ID.",
          "type": "string"
        },
        "tagManagerUrl": {
          "type": "string",
          "description": "Auto generated link to the tag manager UI"
        },
        "fingerprint": {
          "type": "string",
          "description": "The fingerprint of the GTM Zone as computed at storage time. This value is recomputed whenever the zone is modified."
        },
        "childContainer": {
          "description": "Containers that are children of this Zone.",
          "type": "array",
          "items": {
            "$ref": "ZoneChildContainer"
          }
        },
        "notes": {
          "description": "User notes on how to apply this zone in the container.",
          "type": "string"
        },
        "path": {
          "description": "GTM Zone's API relative path.",
          "type": "string"
        },
        "zoneId": {
          "description": "The Zone ID uniquely identifies the GTM Zone.",
          "type": "string"
        },
        "boundary": {
          "$ref": "ZoneBoundary",
          "description": "This Zone's boundary."
        },
        "containerId": {
          "type": "string",
          "description": "GTM Container ID."
        },
        "name": {
          "type": "string",
          "description": "Zone display name."
        }
      },
      "type": "object",
      "id": "Zone",
      "description": "Represents a Google Tag Manager Zone's contents."
    },
    "SyncWorkspaceResponse": {
      "id": "SyncWorkspaceResponse",
      "properties": {
        "syncStatus": {
          "$ref": "SyncStatus",
          "description": "Indicates whether synchronization caused a merge conflict or sync error."
        },
        "mergeConflict": {
          "type": "array",
          "description": "The merge conflict after sync. If this field is not empty, the sync is still treated as successful. But a version cannot be created until all conflicts are resolved.",
          "items": {
            "$ref": "MergeConflict"
          }
        }
      },
      "description": "A response after synchronizing the workspace to the latest container version.",
      "type": "object"
    },
    "SyncStatus": {
      "id": "SyncStatus",
      "description": "The status of a workspace after synchronization.",
      "type": "object",
      "properties": {
        "mergeConflict": {
          "type": "boolean",
          "description": "Synchornization operation detected a merge conflict."
        },
        "syncError": {
          "description": "An error occurred during the synchronization operation.",
          "type": "boolean"
        }
      }
    },
    "GetWorkspaceStatusResponse": {
      "properties": {
        "workspaceChange": {
          "description": "Entities that have been changed in the workspace.",
          "type": "array",
          "items": {
            "$ref": "Entity"
          }
        },
        "mergeConflict": {
          "description": "The merge conflict after sync.",
          "type": "array",
          "items": {
            "$ref": "MergeConflict"
          }
        }
      },
      "type": "object",
      "description": "The changes that have occurred in the workspace since the base container version.",
      "id": "GetWorkspaceStatusResponse"
    },
    "Parameter": {
      "id": "Parameter",
      "properties": {
        "map": {
          "description": "This map parameter's parameters (must have keys; keys must be unique).",
          "items": {
            "$ref": "Parameter"
          },
          "type": "array"
        },
        "list": {
          "description": "This list parameter's parameters (keys will be ignored).",
          "type": "array",
          "items": {
            "$ref": "Parameter"
          }
        },
        "isWeakReference": {
          "description": "Whether or not a reference type parameter is strongly or weakly referenced. Only used by Transformations.",
          "type": "boolean"
        },
        "type": {
          "enumDescriptions": [
            "",
            "May include variable references.",
            "",
            "",
            "",
            "",
            "",
            ""
          ],
          "type": "string",
          "enum": [
            "typeUnspecified",
            "template",
            "integer",
            "boolean",
            "list",
            "map",
            "triggerReference",
            "tagReference"
          ],
          "description": "The parameter type. Valid values are: - boolean: The value represents a boolean, represented as 'true' or 'false' - integer: The value represents a 64-bit signed integer value, in base 10 - list: A list of parameters should be specified - map: A map of parameters should be specified - template: The value represents any text; this can include variable references (even variable references that might return non-string types) - trigger_reference: The value represents a trigger, represented as the trigger id - tag_reference: The value represents a tag, represented as the tag name "
        },
        "value": {
          "type": "string",
          "description": "A parameter's value (may contain variable references). as appropriate to the specified type."
        },
        "key": {
          "type": "string",
          "description": "The named key that uniquely identifies a parameter. Required for top-level parameters, as well as map values. Ignored for list values."
        }
      },
      "type": "object",
      "description": "Represents a Google Tag Manager Parameter."
    },
    "RevertTemplateResponse": {
      "type": "object",
      "id": "RevertTemplateResponse",
      "description": "The result of reverting a template in a workspace.",
      "properties": {
        "template": {
          "$ref": "CustomTemplate",
          "description": "Template as it appears in the latest container version since the last workspace synchronization operation. If no template is present, that means the template was deleted in the latest container version."
        }
      }
    },
    "GtagConfig": {
      "type": "object",
      "id": "GtagConfig",
      "properties": {
        "gtagConfigId": {
          "type": "string",
          "description": "The ID uniquely identifies the Google tag config."
        },
        "accountId": {
          "description": "Google tag account ID.",
          "type": "string"
        },
        "path": {
          "type": "string",
          "description": "Google tag config's API relative path."
        },
        "parameter": {
          "description": "The Google tag config's parameters.",
          "type": "array",
          "items": {
            "$ref": "Parameter"
          }
        },
        "containerId": {
          "description": "Google tag container ID.",
          "type": "string"
        },
        "type": {
          "type": "string",
          "description": "Google tag config type."
        },
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI",
          "type": "string"
        },
        "workspaceId": {
          "description": "Google tag workspace ID. Only used by GTM containers. Set to 0 otherwise.",
          "type": "string"
        },
        "fingerprint": {
          "type": "string",
          "description": "The fingerprint of the Google tag config as computed at storage time. This value is recomputed whenever the config is modified."
        }
      },
      "description": "Represents a Google tag configuration."
    },
    "FolderEntities": {
      "type": "object",
      "properties": {
        "trigger": {
          "type": "array",
          "description": "The list of triggers inside the folder.",
          "items": {
            "$ref": "Trigger"
          }
        },
        "variable": {
          "items": {
            "$ref": "Variable"
          },
          "description": "The list of variables inside the folder.",
          "type": "array"
        },
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        },
        "tag": {
          "items": {
            "$ref": "Tag"
          },
          "description": "The list of tags inside the folder.",
          "type": "array"
        }
      },
      "description": "Represents a Google Tag Manager Folder's contents.",
      "id": "FolderEntities"
    },
    "ListEnvironmentsResponse": {
      "properties": {
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        },
        "environment": {
          "description": "All Environments of a GTM Container.",
          "type": "array",
          "items": {
            "$ref": "Environment"
          }
        }
      },
      "description": "List Environments Response.",
      "id": "ListEnvironmentsResponse",
      "type": "object"
    },
    "RevertBuiltInVariableResponse": {
      "id": "RevertBuiltInVariableResponse",
      "properties": {
        "enabled": {
          "description": "Whether the built-in variable is enabled after reversion.",
          "type": "boolean"
        }
      },
      "type": "object",
      "description": "The result of reverting a built-in variable in a workspace."
    },
    "PublishContainerVersionResponse": {
      "id": "PublishContainerVersionResponse",
      "type": "object",
      "description": "Publish container version response.",
      "properties": {
        "compilerError": {
          "description": "Compiler errors or not.",
          "type": "boolean"
        },
        "containerVersion": {
          "description": "The container version created.",
          "$ref": "ContainerVersion"
        }
      }
    },
    "Variable": {
      "properties": {
        "notes": {
          "type": "string",
          "description": "User notes on how to apply this variable in the container."
        },
        "type": {
          "description": "GTM Variable Type.",
          "type": "string"
        },
        "name": {
          "type": "string",
          "description": "Variable display name."
        },
        "disablingTriggerId": {
          "description": "For mobile containers only: A list of trigger IDs for disabling conditional variables; the variable is enabled if one of the enabling trigger is true while all the disabling trigger are false. Treated as an unordered set.",
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "enablingTriggerId": {
          "type": "array",
          "description": "For mobile containers only: A list of trigger IDs for enabling conditional variables; the variable is enabled if one of the enabling triggers is true while all the disabling triggers are false. Treated as an unordered set.",
          "items": {
            "type": "string"
          }
        },
        "containerId": {
          "description": "GTM Container ID.",
          "type": "string"
        },
        "parentFolderId": {
          "type": "string",
          "description": "Parent folder id."
        },
        "path": {
          "type": "string",
          "description": "GTM Variable's API relative path."
        },
        "fingerprint": {
          "type": "string",
          "description": "The fingerprint of the GTM Variable as computed at storage time. This value is recomputed whenever the variable is modified."
        },
        "workspaceId": {
          "type": "string",
          "description": "GTM Workspace ID."
        },
        "parameter": {
          "items": {
            "$ref": "Parameter"
          },
          "description": "The variable's parameters.",
          "type": "array"
        },
        "scheduleEndMs": {
          "type": "string",
          "description": "The end timestamp in milliseconds to schedule a variable.",
          "format": "int64"
        },
        "tagManagerUrl": {
          "type": "string",
          "description": "Auto generated link to the tag manager UI"
        },
        "formatValue": {
          "$ref": "VariableFormatValue",
          "description": "Option to convert a variable value to other value."
        },
        "accountId": {
          "description": "GTM Account ID.",
          "type": "string"
        },
        "variableId": {
          "description": "The Variable ID uniquely identifies the GTM Variable.",
          "type": "string"
        },
        "scheduleStartMs": {
          "description": "The start timestamp in milliseconds to schedule a variable.",
          "type": "string",
          "format": "int64"
        }
      },
      "description": "Represents a Google Tag Manager Variable.",
      "type": "object",
      "id": "Variable"
    },
    "ContainerFeatures": {
      "id": "ContainerFeatures",
      "type": "object",
      "properties": {
        "supportTransformations": {
          "description": "Whether this Container supports transformations.",
          "type": "boolean"
        },
        "supportVariables": {
          "type": "boolean",
          "description": "Whether this Container supports variables."
        },
        "supportVersions": {
          "description": "Whether this Container supports Container versions.",
          "type": "boolean"
        },
        "supportEnvironments": {
          "type": "boolean",
          "description": "Whether this Container supports environments."
        },
        "supportUserPermissions": {
          "description": "Whether this Container supports user permissions managed by GTM.",
          "type": "boolean"
        },
        "supportGtagConfigs": {
          "type": "boolean",
          "description": "Whether this Container supports Google tag config."
        },
        "supportFolders": {
          "description": "Whether this Container supports folders.",
          "type": "boolean"
        },
        "supportBuiltInVariables": {
          "description": "Whether this Container supports built-in variables",
          "type": "boolean"
        },
        "supportTriggers": {
          "description": "Whether this Container supports triggers.",
          "type": "boolean"
        },
        "supportTemplates": {
          "type": "boolean",
          "description": "Whether this Container supports templates."
        },
        "supportWorkspaces": {
          "description": "Whether this Container supports workspaces.",
          "type": "boolean"
        },
        "supportClients": {
          "description": "Whether this Container supports clients.",
          "type": "boolean"
        },
        "supportTags": {
          "type": "boolean",
          "description": "Whether this Container supports tags."
        },
        "supportZones": {
          "description": "Whether this Container supports zones.",
          "type": "boolean"
        }
      }
    },
    "Destination": {
      "id": "Destination",
      "description": "Represents a Google Tag Destination.",
      "type": "object",
      "properties": {
        "path": {
          "description": "Destination's API relative path.",
          "type": "string"
        },
        "fingerprint": {
          "description": "The fingerprint of the Google Tag Destination as computed at storage time. This value is recomputed whenever the destination is modified.",
          "type": "string"
        },
        "destinationId": {
          "type": "string",
          "description": "Destination ID."
        },
        "destinationLinkId": {
          "type": "string",
          "description": "The Destination link ID uniquely identifies the Destination."
        },
        "name": {
          "type": "string",
          "description": "Destination display name."
        },
        "containerId": {
          "type": "string",
          "description": "GTM Container ID."
        },
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI.",
          "type": "string"
        },
        "accountId": {
          "description": "GTM Account ID.",
          "type": "string"
        }
      }
    },
    "ContainerVersionHeader": {
      "properties": {
        "accountId": {
          "description": "GTM Account ID.",
          "type": "string"
        },
        "numGtagConfigs": {
          "type": "string",
          "description": "Number of Google tag configs in the container version."
        },
        "containerVersionId": {
          "description": "The Container Version ID uniquely identifies the GTM Container Version.",
          "type": "string"
        },
        "numVariables": {
          "type": "string",
          "description": "Number of variables in the container version."
        },
        "name": {
          "type": "string",
          "description": "Container version display name."
        },
        "numZones": {
          "description": "Number of zones in the container version.",
          "type": "string"
        },
        "numClients": {
          "type": "string",
          "description": "Number of clients in the container version."
        },
        "path": {
          "description": "GTM Container Version's API relative path.",
          "type": "string"
        },
        "numTags": {
          "type": "string",
          "description": "Number of tags in the container version."
        },
        "numTriggers": {
          "description": "Number of triggers in the container version.",
          "type": "string"
        },
        "containerId": {
          "type": "string",
          "description": "GTM Container ID."
        },
        "deleted": {
          "description": "A value of true indicates this container version has been deleted.",
          "type": "boolean"
        },
        "numCustomTemplates": {
          "description": "Number of custom templates in the container version.",
          "type": "string"
        },
        "numTransformations": {
          "description": "Number of transformations in the container version.",
          "type": "string"
        }
      },
      "description": "Represents a Google Tag Manager Container Version Header.",
      "id": "ContainerVersionHeader",
      "type": "object"
    },
    "ListVariablesResponse": {
      "id": "ListVariablesResponse",
      "description": "List Variables Response.",
      "properties": {
        "nextPageToken": {
          "type": "string",
          "description": "Continuation token for fetching the next page of results."
        },
        "variable": {
          "type": "array",
          "description": "All GTM Variables of a GTM Container.",
          "items": {
            "$ref": "Variable"
          }
        }
      },
      "type": "object"
    },
    "AccountFeatures": {
      "id": "AccountFeatures",
      "properties": {
        "supportMultipleContainers": {
          "type": "boolean",
          "description": "Whether this Account supports multiple Containers."
        },
        "supportUserPermissions": {
          "type": "boolean",
          "description": "Whether this Account supports user permissions managed by GTM."
        }
      },
      "type": "object"
    },
    "ListContainersResponse": {
      "id": "ListContainersResponse",
      "description": "List Containers Response.",
      "type": "object",
      "properties": {
        "container": {
          "type": "array",
          "description": "All Containers of a GTM Account.",
          "items": {
            "$ref": "Container"
          }
        },
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        }
      }
    },
    "RevertVariableResponse": {
      "type": "object",
      "id": "RevertVariableResponse",
      "properties": {
        "variable": {
          "description": "Variable as it appears in the latest container version since the last workspace synchronization operation. If no variable is present, that means the variable was deleted in the latest container version.",
          "$ref": "Variable"
        }
      },
      "description": "The result of reverting a variable in a workspace."
    },
    "Environment": {
      "type": "object",
      "id": "Environment",
      "description": "Represents a Google Tag Manager Environment. Note that a user can create, delete and update environments of type USER, but can only update the enable_debug and url fields of environments of other types.",
      "properties": {
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI",
          "type": "string"
        },
        "containerId": {
          "description": "GTM Container ID.",
          "type": "string"
        },
        "path": {
          "description": "GTM Environment's API relative path.",
          "type": "string"
        },
        "containerVersionId": {
          "description": "Represents a link to a container version.",
          "type": "string"
        },
        "description": {
          "type": "string",
          "description": "The environment description. Can be set or changed only on USER type environments."
        },
        "type": {
          "enumDescriptions": [
            "Points to a user defined environment.",
            "Points to the current live container version.",
            "Points to the latest container version.",
            "Automatically managed environment that points to a workspace preview or version created by a workspace."
          ],
          "type": "string",
          "enum": [
            "user",
            "live",
            "latest",
            "workspace"
          ],
          "description": "The type of this environment."
        },
        "name": {
          "type": "string",
          "description": "The environment display name. Can be set or changed only on USER type environments."
        },
        "authorizationCode": {
          "description": "The environment authorization code.",
          "type": "string"
        },
        "workspaceId": {
          "type": "string",
          "description": "Represents a link to a quick preview of a workspace."
        },
        "url": {
          "description": "Default preview page url for the environment.",
          "type": "string"
        },
        "fingerprint": {
          "description": "The fingerprint of the GTM environment as computed at storage time. This value is recomputed whenever the environment is modified.",
          "type": "string"
        },
        "enableDebug": {
          "description": "Whether or not to enable debug by default for the environment.",
          "type": "boolean"
        },
        "environmentId": {
          "description": "GTM Environment ID uniquely identifies the GTM Environment.",
          "type": "string"
        },
        "accountId": {
          "description": "GTM Account ID.",
          "type": "string"
        },
        "authorizationTimestamp": {
          "description": "The last update time-stamp for the authorization code.",
          "format": "google-datetime",
          "type": "string"
        }
      }
    },
    "ListTransformationsResponse": {
      "type": "object",
      "id": "ListTransformationsResponse",
      "properties": {
        "transformation": {
          "items": {
            "$ref": "Transformation"
          },
          "description": "All GTM Transformations of a GTM Container.",
          "type": "array"
        },
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        }
      }
    },
    "ListClientsResponse": {
      "properties": {
        "client": {
          "description": "All GTM Clients of a GTM Container.",
          "items": {
            "$ref": "Client"
          },
          "type": "array"
        },
        "nextPageToken": {
          "type": "string",
          "description": "Continuation token for fetching the next page of results."
        }
      },
      "id": "ListClientsResponse",
      "type": "object"
    },
    "ListTemplatesResponse": {
      "properties": {
        "template": {
          "description": "All GTM Custom Templates of a GTM Container.",
          "type": "array",
          "items": {
            "$ref": "CustomTemplate"
          }
        },
        "nextPageToken": {
          "type": "string",
          "description": "Continuation token for fetching the next page of results."
        }
      },
      "id": "ListTemplatesResponse",
      "type": "object"
    },
    "ListTriggersResponse": {
      "type": "object",
      "id": "ListTriggersResponse",
      "description": "List triggers response.",
      "properties": {
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        },
        "trigger": {
          "items": {
            "$ref": "Trigger"
          },
          "type": "array",
          "description": "All GTM Triggers of a GTM Container."
        }
      }
    },
    "CustomTemplate": {
      "properties": {
        "containerId": {
          "description": "GTM Container ID.",
          "type": "string"
        },
        "templateId": {
          "description": "The Custom Template ID uniquely identifies the GTM custom template.",
          "type": "string"
        },
        "path": {
          "description": "GTM Custom Template's API relative path.",
          "type": "string"
        },
        "tagManagerUrl": {
          "type": "string",
          "description": "Auto generated link to the tag manager UI"
        },
        "name": {
          "description": "Custom Template display name.",
          "type": "string"
        },
        "accountId": {
          "description": "GTM Account ID.",
          "type": "string"
        },
        "workspaceId": {
          "description": "GTM Workspace ID.",
          "type": "string"
        },
        "galleryReference": {
          "description": "A reference to the Community Template Gallery entry.",
          "$ref": "GalleryReference"
        },
        "fingerprint": {
          "description": "The fingerprint of the GTM Custom Template as computed at storage time. This value is recomputed whenever the template is modified.",
          "type": "string"
        },
        "templateData": {
          "type": "string",
          "description": "The custom template in text format."
        }
      },
      "description": "Represents a Google Tag Manager Custom Template's contents.",
      "type": "object",
      "id": "CustomTemplate"
    },
    "ProposedChange": {
      "properties": {
        "changes": {
          "type": "array",
          "items": {
            "$ref": "Entity"
          },
          "description": "The list of workspace changes to be applied."
        }
      },
      "type": "object",
      "id": "ProposedChange"
    },
    "ZoneBoundary": {
      "id": "ZoneBoundary",
      "properties": {
        "condition": {
          "description": "The conditions that, when conjoined, make up the boundary.",
          "items": {
            "$ref": "Condition"
          },
          "type": "array"
        },
        "customEvaluationTriggerId": {
          "description": "Custom evaluation trigger IDs. A zone will evaluate its boundary conditions when any of the listed triggers are true.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "description": "Represents a Zone's boundaries.",
      "type": "object"
    },
    "Client": {
      "id": "Client",
      "type": "object",
      "properties": {
        "clientId": {
          "description": "The Client ID uniquely identifies the GTM client.",
          "type": "string"
        },
        "priority": {
          "description": "Priority determines relative firing order.",
          "type": "integer",
          "format": "int32"
        },
        "accountId": {
          "description": "GTM Account ID.",
          "type": "string"
        },
        "fingerprint": {
          "description": "The fingerprint of the GTM Client as computed at storage time. This value is recomputed whenever the client is modified.",
          "type": "string"
        },
        "parameter": {
          "description": "The client's parameters.",
          "type": "array",
          "items": {
            "$ref": "Parameter"
          }
        },
        "workspaceId": {
          "description": "GTM Workspace ID.",
          "type": "string"
        },
        "path": {
          "description": "GTM client's API relative path.",
          "type": "string"
        },
        "type": {
          "type": "string",
          "description": "Client type."
        },
        "name": {
          "type": "string",
          "description": "Client display name."
        },
        "tagManagerUrl": {
          "description": "Auto generated link to the tag manager UI",
          "type": "string"
        },
        "parentFolderId": {
          "type": "string",
          "description": "Parent folder id."
        },
        "notes": {
          "type": "string",
          "description": "User notes on how to apply this tag in the container."
        },
        "containerId": {
          "description": "GTM Container ID.",
          "type": "string"
        }
      }
    },
    "Entity": {
      "description": "A workspace entity that may represent a tag, trigger, variable, or folder in addition to its status in the workspace.",
      "type": "object",
      "id": "Entity",
      "properties": {
        "client": {
          "description": "The client being represented by the entity.",
          "$ref": "Client"
        },
        "customTemplate": {
          "description": "The custom template being represented by the entity.",
          "$ref": "CustomTemplate"
        },
        "tag": {
          "description": "The tag being represented by the entity.",
          "$ref": "Tag"
        },
        "gtagConfig": {
          "$ref": "GtagConfig",
          "description": "The gtag config being represented by the entity."
        },
        "zone": {
          "$ref": "Zone",
          "description": "The zone being represented by the entity."
        },
        "folder": {
          "description": "The folder being represented by the entity.",
          "$ref": "Folder"
        },
        "variable": {
          "description": "The variable being represented by the entity.",
          "$ref": "Variable"
        },
        "changeStatus": {
          "enumDescriptions": [
            "",
            "The entity has never been changed.",
            "The entity is added to the workspace.",
            "The entity is deleted from the workspace.",
            "The entity has been updated in the workspace."
          ],
          "type": "string",
          "enum": [
            "changeStatusUnspecified",
            "none",
            "added",
            "deleted",
            "updated"
          ],
          "description": "Represents how the entity has been changed in the workspace."
        },
        "trigger": {
          "$ref": "Trigger",
          "description": "The trigger being represented by the entity."
        },
        "transformation": {
          "$ref": "Transformation",
          "description": "The transformation being represented by the entity."
        },
        "builtInVariable": {
          "description": "The built in variable being represented by the entity.",
          "$ref": "BuiltInVariable"
        }
      }
    },
    "UserPermission": {
      "type": "object",
      "id": "UserPermission",
      "description": "Represents a user's permissions to an account and its container.",
      "properties": {
        "containerAccess": {
          "description": "GTM Container access permissions.",
          "items": {
            "$ref": "ContainerAccess"
          },
          "type": "array"
        },
        "emailAddress": {
          "type": "string",
          "description": "User's email address."
        },
        "accountAccess": {
          "$ref": "AccountAccess",
          "description": "GTM Account access permissions."
        },
        "accountId": {
          "type": "string",
          "description": "The Account ID uniquely identifies the GTM Account."
        },
        "path": {
          "description": "GTM UserPermission's API relative path.",
          "type": "string"
        }
      }
    },
    "Trigger": {
      "properties": {
        "limit": {
          "description": "Limit of the number of GTM events this Timer Trigger will fire. If no limit is set, we will continue to fire GTM events until the user leaves the page. Only valid for Timer triggers.",
          "$ref": "Parameter"
        },
        "waitForTagsTimeout": {
          "$ref": "Parameter",
          "description": "How long to wait (in milliseconds) for tags to fire when 'waits_for_tags' above evaluates to true. Only valid for Form Submission and Link Click triggers."
        },
        "checkValidation": {
          "description": "Whether or not we should only fire tags if the form submit or link click event is not cancelled by some other event handler (e.g. because of validation). Only valid for Form Submission and Link Click triggers.",
          "$ref": "Parameter"
        },
        "uniqueTriggerId": {
          "$ref": "Parameter",
          "description": "Globally unique id of the trigger that auto-generates this (a Form Submit, Link Click or Timer listener) if any. Used to make incompatible auto-events work together with trigger filtering based on trigger ids. This value is populated during output generation since the tags implied by triggers don't exist until then. Only valid for Form Submit, Link Click and Timer triggers."
        },
        "visiblePercentageMin": {
          "description": "A visibility trigger minimum percent visibility. Only valid for AMP Visibility trigger.",
          "$ref": "Parameter"
        },
        "containerId": {
          "type": "string",
          "description": "GTM Container ID."
        },
        "visibilitySelector": {
          "description": "A visibility trigger CSS selector (i.e. \"#id\"). Only valid for AMP Visibility trigger.",
          "$ref": "Parameter"
        },
        "path": {
          "type": "string",
          "description": "GTM Trigger's API relative path."
        },
        "workspaceId": {
          "description": "GTM Workspace ID.",
          "type": "string"
        },
        "continuousTimeMinMilliseconds": {
          "$ref": "Parameter",
          "description": "A visibility trigger minimum continuous visible time (in milliseconds). Only valid for AMP Visibility trigger."
        },
        "intervalSeconds": {
          "$ref": "Parameter",
          "description": "Time between Timer Events to fire (in seconds). Only valid for AMP Timer trigger."
        },
        "name": {
          "description": "Trigger display name.",
          "type": "string"
        },
        "filter": {
          "items": {
            "$ref": "Condition"
          },
          "type": "array",
          "description": "The trigger will only fire iff all Conditions are true."
        },
        "triggerId": {
          "description": "The Trigger ID uniquely identifies the GTM Trigger.",
          "type": "string"
        },
        "waitForTags": {
          "description": "Whether or not we should delay the form submissions or link opening until all of the tags have fired (by preventing the default action and later simulating the default action). Only valid for Form Submission and Link Click triggers.",
          "$ref": "Parameter"
        },
        "autoEventFilter": {
          "type": "array",
          "items": {
            "$ref": "Condition"
          },
          "description": "Used in the case of auto event tracking."
        },
        "totalTimeMinMilliseconds": {
          "$ref": "Parameter",
          "description": "A visibility trigger minimum total visible time (in milliseconds). Only valid for AMP Visibility trigger."
        },
        "verticalScrollPercentageList": {
          "$ref": "Parameter",
          "description": "List of integer percentage values for scroll triggers. The trigger will fire when each percentage is reached when the view is scrolled vertically. Only valid for AMP scroll triggers."
        },
        "maxTimerLengthSeconds": {
          "description": "Max time to fire Timer Events (in seconds). Only valid for AMP Timer trigger.",
          "$ref": "Parameter"
        },
        "interval": {
          "description": "Time between triggering recurring Timer Events (in milliseconds). Only valid for Timer triggers.",
          "$ref": "Parameter"
        },
        "horizontalScrollPercentageList": {
          "description": "List of integer percentage values for scroll triggers. The trigger will fire when each percentage is reached when the view is scrolled horizontally. Only valid for AMP scroll triggers.",
          "$ref": "Parameter"
        },
        "tagManagerUrl": {
          "type": "string",
          "description": "Auto generated link to the tag manager UI"
        },
        "eventName": {
          "$ref": "Parameter",
          "description": "Name of the GTM event that is fired. Only valid for Timer triggers."
        },
        "parentFolderId": {
          "description": "Parent folder id.",
          "type": "string"
        },
        "notes": {
          "description": "User notes on how to apply this trigger in the container.",
          "type": "string"
        },
        "fingerprint": {
          "type": "string",
          "description": "The fingerprint of the GTM Trigger as computed at storage time. This value is recomputed whenever the trigger is modified."
        },
        "accountId": {
          "type": "string",
          "description": "GTM Account ID."
        },
        "type": {
          "enumDescriptions": [
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
          ],
          "description": "Defines the data layer event that causes this trigger.",
          "type": "string",
          "enum": [
            "eventTypeUnspecified",
            "pageview",
            "domReady",
            "windowLoaded",
            "customEvent",
            "triggerGroup",
            "init",
            "consentInit",
            "serverPageview",
            "always",
            "firebaseAppException",
            "firebaseAppUpdate",
            "firebaseCampaign",
            "firebaseFirstOpen",
            "firebaseInAppPurchase",
            "firebaseNotificationDismiss",
            "firebaseNotificationForeground",
            "firebaseNotificationOpen",
            "firebaseNotificationReceive",
            "firebaseOsUpdate",
            "firebaseSessionStart",
            "firebaseUserEngagement",
            "formSubmission",
            "click",
            "linkClick",
            "jsError",
            "historyChange",
            "timer",
            "ampClick",
            "ampTimer",
            "ampScroll",
            "ampVisibility",
            "youTubeVideo",
            "scrollDepth",
            "elementVisibility"
          ]
        },
        "visiblePercentageMax": {
          "description": "A visibility trigger maximum percent visibility. Only valid for AMP Visibility trigger.",
          "$ref": "Parameter"
        },
        "selector": {
          "description": "A click trigger CSS selector (i.e. \"a\", \"button\" etc.). Only valid for AMP Click trigger.",
          "$ref": "Parameter"
        },
        "customEventFilter": {
          "items": {
            "$ref": "Condition"
          },
          "type": "array",
          "description": "Used in the case of custom event, which is fired iff all Conditions are true."
        },
        "parameter": {
          "description": "Additional parameters.",
          "type": "array",
          "items": {
            "$ref": "Parameter"
          }
        }
      },
      "description": "Represents a Google Tag Manager Trigger",
      "type": "object",
      "id": "Trigger"
    },
    "SetupTag": {
      "type": "object",
      "id": "SetupTag",
      "properties": {
        "tagName": {
          "type": "string",
          "description": "The name of the setup tag."
        },
        "stopOnSetupFailure": {
          "type": "boolean",
          "description": "If true, fire the main tag if and only if the setup tag fires successfully. If false, fire the main tag regardless of setup tag firing status."
        }
      },
      "description": "Represents a reference to atag that fires before another tag in order to set up dependencies."
    },
    "ListTagsResponse": {
      "description": "List Tags Response.",
      "type": "object",
      "properties": {
        "nextPageToken": {
          "type": "string",
          "description": "Continuation token for fetching the next page of results."
        },
        "tag": {
          "type": "array",
          "items": {
            "$ref": "Tag"
          },
          "description": "All GTM Tags of a GTM Container."
        }
      },
      "id": "ListTagsResponse"
    },
    "ListDestinationsResponse": {
      "type": "object",
      "properties": {
        "destination": {
          "type": "array",
          "description": "All Destinations linked to a GTM Container.",
          "items": {
            "$ref": "Destination"
          }
        },
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        }
      },
      "id": "ListDestinationsResponse"
    },
    "ContainerAccess": {
      "description": "Defines the Google Tag Manager Container access permissions.",
      "properties": {
        "permission": {
          "enumDescriptions": [
            "",
            "",
            "",
            "",
            "",
            ""
          ],
          "type": "string",
          "enum": [
            "containerPermissionUnspecified",
            "noAccess",
            "read",
            "edit",
            "approve",
            "publish"
          ],
          "description": "List of Container permissions."
        },
        "containerId": {
          "description": "GTM Container ID.",
          "type": "string"
        }
      },
      "type": "object",
      "id": "ContainerAccess"
    },
    "ListWorkspacesResponse": {
      "description": "A list of workspaces in a container.",
      "type": "object",
      "properties": {
        "workspace": {
          "items": {
            "$ref": "Workspace"
          },
          "description": "All Workspaces of a GTM Container.",
          "type": "array"
        },
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        }
      },
      "id": "ListWorkspacesResponse"
    },
    "TagConsentSetting": {
      "type": "object",
      "id": "TagConsentSetting",
      "properties": {
        "consentStatus": {
          "enumDescriptions": [
            "Default value where user has not specified any setting on it.",
            "Tag doesn't require any additional consent settings.",
            "Tag requires additional consent settings."
          ],
          "description": "The tag's consent status. If set to NEEDED, the runtime will check that the consent types specified by the consent_type field have been granted.",
          "type": "string",
          "enum": [
            "notSet",
            "notNeeded",
            "needed"
          ]
        },
        "consentType": {
          "$ref": "Parameter",
          "description": "The type of consents to check for during tag firing if in the consent NEEDED state. This parameter must be of type LIST where each list item is of type STRING."
        }
      }
    },
    "BulkUpdateWorkspaceResponse": {
      "type": "object",
      "id": "BulkUpdateWorkspaceResponse",
      "properties": {
        "changes": {
          "type": "array",
          "description": "The entities that were added or updated during the bulk-update. Does not include entities that were deleted or updated by the system.",
          "items": {
            "$ref": "Entity"
          }
        }
      }
    },
    "ListFoldersResponse": {
      "id": "ListFoldersResponse",
      "properties": {
        "folder": {
          "items": {
            "$ref": "Folder"
          },
          "description": "All GTM Folders of a GTM Container.",
          "type": "array"
        },
        "nextPageToken": {
          "description": "Continuation token for fetching the next page of results.",
          "type": "string"
        }
      },
      "type": "object",
      "description": "List Folders Response."
    },
    "Account": {
      "description": "Represents a Google Tag Manager Account.",
      "id": "Account",
      "properties": {
        "path": {
          "description": "GTM Account's API relative path.",
          "type": "string"
        },
        "fingerprint": {
          "type": "string",
          "description": "The fingerprint of the GTM Account as computed at storage time. This value is recomputed whenever the account is modified."
        },
        "accountId": {
          "description": "The Account ID uniquely identifies the GTM Account.",
          "type": "string"
        },
        "shareData": {
          "type": "boolean",
          "description": "Whether the account shares data anonymously with Google and others. This flag enables benchmarking by sharing your data in an anonymous form. Google will remove all identifiable information about your website, combine the data with hundreds of other anonymous sites and report aggregate trends in the benchmarking service."
        },
        "name": {
          "description": "Account display name.",
          "type": "string"
        },
        "tagManagerUrl": {
          "type": "string",
          "description": "Auto generated link to the tag manager UI"
        },
        "features": {
          "description": "Read-only Account feature set",
          "$ref": "AccountFeatures"
        }
      },
      "type": "object"
    },
    "Condition": {
      "id": "Condition",
      "type": "object",
      "description": "Represents a predicate.",
      "properties": {
        "type": {
          "description": "The type of operator for this condition.",
          "type": "string",
          "enum": [
            "conditionTypeUnspecified",
            "equals",
            "contains",
            "startsWith",
            "endsWith",
            "matchRegex",
            "greater",
            "greaterOrEquals",
            "less",
            "lessOrEquals",
            "cssSelector",
            "urlMatches"
          ],
          "enumDescriptions": [
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
          ]
        },
        "parameter": {
          "type": "array",
          "description": "A list of named parameters (key/value), depending on the condition's type. Notes: - For binary operators, include parameters named arg0 and arg1 for specifying the left and right operands, respectively. - At this time, the left operand (arg0) must be a reference to a variable. - For case-insensitive Regex matching, include a boolean parameter named ignore_case that is set to true. If not specified or set to any other value, the matching will be case sensitive. - To negate an operator, include a boolean parameter named negate boolean parameter that is set to true. ",
          "items": {
            "$ref": "Parameter"
          }
        }
      }
    },
    "CreateContainerVersionResponse": {
      "description": "Create container versions response.",
      "properties": {
        "containerVersion": {
          "description": "The container version created.",
          "$ref": "ContainerVersion"
        },
        "newWorkspacePath": {
          "description": "Auto generated workspace path created as a result of version creation. This field should only be populated if the created version was not a quick preview.",
          "type": "string"
        },
        "compilerError": {
          "type": "boolean",
          "description": "Compiler errors or not."
        },
        "syncStatus": {
          "$ref": "SyncStatus",
          "description": "Whether version creation failed when syncing the workspace to the latest container version."
        }
      },
      "id": "CreateContainerVersionResponse",
      "type": "object"
    }
  },
  "name": "tagmanager",
  "protocol": "rest",
  "title": "Tag Manager API",
  "ownerDomain": "google.com",
  "kind": "discovery#restDescription",
  "servicePath": "",
  "parameters": {
    "prettyPrint": {
      "description": "Returns response with indentations and line breaks.",
      "default": "true",
      "location": "query",
      "type": "boolean"
    },
    "$.xgafv": {
      "location": "query",
      "enumDescriptions": [
        "v1 error format",
        "v2 error format"
      ],
      "type": "string",
      "enum": [
        "1",
        "2"
      ],
      "description": "V1 error format."
    },
    "uploadType": {
      "location": "query",
      "description": "Legacy upload protocol for media (e.g. \"media\", \"multipart\").",
      "type": "string"
    },
    "callback": {
      "location": "query",
      "description": "JSONP",
      "type": "string"
    },
    "access_token": {
      "location": "query",
      "type": "string",
      "description": "OAuth access token."
    },
    "oauth_token": {
      "description": "OAuth 2.0 token for the current user.",
      "location": "query",
      "type": "string"
    },
    "upload_protocol": {
      "description": "Upload protocol for media (e.g. \"raw\", \"multipart\").",
      "location": "query",
      "type": "string"
    },
    "alt": {
      "location": "query",
      "enumDescriptions": [
        "Responses with Content-Type of application/json",
        "Media download with context-dependent Content-Type",
        "Responses with Content-Type of application/x-protobuf"
      ],
      "description": "Data format for response.",
      "type": "string",
      "enum": [
        "json",
        "media",
        "proto"
      ],
      "default": "json"
    },
    "key": {
      "location": "query",
      "description": "API key. Your API key identifies your project and provides you with API access, quota, and reports. Required unless you provide an OAuth 2.0 token.",
      "type": "string"
    },
    "quotaUser": {
      "location": "query",
      "description": "Available to use for quota purposes for server-side applications. Can be any arbitrary string assigned to a user, but should not exceed 40 characters.",
      "type": "string"
    },
    "fields": {
      "description": "Selector specifying which fields to include in a partial response.",
      "type": "string",
      "location": "query"
    }
  },
  "mtlsRootUrl": "https://tagmanager.mtls.googleapis.com/",
  "ownerName": "Google",
  "canonicalName": "Tag Manager",
  "discoveryVersion": "v1",
  "rootUrl": "https://tagmanager.googleapis.com/",
  "description": "This API allows clients to access and modify container and tag configuration.",
  "auth": {
    "oauth2": {
      "scopes": {
        "https://www.googleapis.com/auth/tagmanager.edit.containerversions": {
          "description": "Manage your Google Tag Manager container versions"
        },
        "https://www.googleapis.com/auth/tagmanager.edit.containers": {
          "description": "Manage your Google Tag Manager container and its subcomponents, excluding versioning and publishing"
        },
        "https://www.googleapis.com/auth/tagmanager.manage.accounts": {
          "description": "View and manage your Google Tag Manager accounts"
        },
        "https://www.googleapis.com/auth/tagmanager.delete.containers": {
          "description": "Delete your Google Tag Manager containers"
        },
        "https://www.googleapis.com/auth/tagmanager.publish": {
          "description": "Publish your Google Tag Manager container versions"
        },
        "https://www.googleapis.com/auth/tagmanager.readonly": {
          "description": "View your Google Tag Manager container and its subcomponents"
        },
        "https://www.googleapis.com/auth/tagmanager.manage.users": {
          "description": "Manage user permissions of your Google Tag Manager account and container"
        }
      }
    }
  },
  "icons": {
    "x32": "http://www.google.com/images/icons/product/search-32.gif",
    "x16": "http://www.google.com/images/icons/product/search-16.gif"
  },
  "batchPath": "batch",
  "version": "v2",
  "documentationLink": "https://developers.google.com/tag-manager",
  "id": "tagmanager:v2",
  "basePath": "",
  "resources": {
    "accounts": {
      "resources": {
        "containers": {
          "methods": {
            "move_tag_id": {
              "httpMethod": "POST",
              "parameters": {
                "path": {
                  "description": "GTM Container's API relative path.",
                  "type": "string",
                  "pattern": "^accounts/[^/]+/containers/[^/]+$",
                  "location": "path",
                  "required": true
                },
                "copyTermsOfService": {
                  "type": "boolean",
                  "description": "Must be set to true to accept all terms of service agreements copied from the current tag to the newly created tag. If this bit is false, the operation will fail.",
                  "location": "query"
                },
                "copySettings": {
                  "type": "boolean",
                  "location": "query",
                  "description": "Whether or not to copy tag settings from this tag to the new tag."
                },
                "tagId": {
                  "location": "query",
                  "type": "string",
                  "description": "Tag ID to be removed from the current Container."
                },
                "tagName": {
                  "location": "query",
                  "type": "string",
                  "description": "The name for the newly created tag."
                },
                "copyUsers": {
                  "location": "query",
                  "type": "boolean",
                  "description": "Whether or not to copy users from this tag to the new tag."
                },
                "allowUserPermissionFeatureUpdate": {
                  "type": "boolean",
                  "description": "Must be set to true to allow features.user_permissions to change from false to true. If this operation causes an update but this bit is false, the operation will fail.",
                  "location": "query"
                }
              },
              "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}:move_tag_id",
              "path": "tagmanager/v2/{+path}:move_tag_id",
              "response": {
                "$ref": "Container"
              },
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.edit.containers"
              ],
              "parameterOrder": [
                "path"
              ],
              "description": "Move Tag ID out of a Container.",
              "deprecated": true,
              "id": "tagmanager.accounts.containers.move_tag_id"
            },
            "lookup": {
              "description": "Looks up a Container by destination ID or tag ID.",
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.edit.containers",
                "https://www.googleapis.com/auth/tagmanager.readonly"
              ],
              "path": "tagmanager/v2/accounts/containers:lookup",
              "httpMethod": "GET",
              "parameters": {
                "destinationId": {
                  "description": "Destination ID linked to a GTM Container, e.g. AW-123456789. Only one of destination_id or tag_id should be set.",
                  "type": "string",
                  "location": "query"
                },
                "tagId": {
                  "type": "string",
                  "description": "Tag ID for a GTM Container, e.g. GTM-123456789. Only one of destination_id or tag_id should be set.",
                  "location": "query"
                }
              },
              "parameterOrder": [],
              "id": "tagmanager.accounts.containers.lookup",
              "response": {
                "$ref": "Container"
              },
              "flatPath": "tagmanager/v2/accounts/containers:lookup"
            },
            "update": {
              "httpMethod": "PUT",
              "parameters": {
                "fingerprint": {
                  "location": "query",
                  "type": "string",
                  "description": "When provided, this fingerprint must match the fingerprint of the container in storage."
                },
                "path": {
                  "pattern": "^accounts/[^/]+/containers/[^/]+$",
                  "location": "path",
                  "required": true,
                  "type": "string",
                  "description": "GTM Container's API relative path."
                }
              },
              "description": "Updates a Container.",
              "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}",
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.edit.containers"
              ],
              "response": {
                "$ref": "Container"
              },
              "parameterOrder": [
                "path"
              ],
              "path": "tagmanager/v2/{+path}",
              "request": {
                "$ref": "Container"
              },
              "id": "tagmanager.accounts.containers.update"
            },
            "create": {
              "request": {
                "$ref": "Container"
              },
              "path": "tagmanager/v2/{+parent}/containers",
              "description": "Creates a Container.",
              "httpMethod": "POST",
              "parameters": {
                "parent": {
                  "description": "GTM Account's API relative path.",
                  "pattern": "^accounts/[^/]+$",
                  "type": "string",
                  "location": "path",
                  "required": true
                }
              },
              "flatPath": "tagmanager/v2/accounts/{accountsId}/containers",
              "response": {
                "$ref": "Container"
              },
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.edit.containers"
              ],
              "parameterOrder": [
                "parent"
              ],
              "id": "tagmanager.accounts.containers.create"
            },
            "snippet": {
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.edit.containers",
                "https://www.googleapis.com/auth/tagmanager.readonly"
              ],
              "httpMethod": "GET",
              "parameters": {
                "path": {
                  "location": "path",
                  "required": true,
                  "type": "string",
                  "pattern": "^accounts/[^/]+/containers/[^/]+$",
                  "description": "Container snippet's API relative path."
                }
              },
              "id": "tagmanager.accounts.containers.snippet",
              "description": "Gets the tagging snippet for a Container.",
              "parameterOrder": [
                "path"
              ],
              "path": "tagmanager/v2/{+path}:snippet",
              "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}:snippet",
              "response": {
                "$ref": "GetContainerSnippetResponse"
              }
            },
            "combine": {
              "httpMethod": "POST",
              "parameters": {
                "allowUserPermissionFeatureUpdate": {
                  "type": "boolean",
                  "location": "query",
                  "description": "Must be set to true to allow features.user_permissions to change from false to true. If this operation causes an update but this bit is false, the operation will fail."
                },
                "path": {
                  "pattern": "^accounts/[^/]+/containers/[^/]+$",
                  "location": "path",
                  "required": true,
                  "description": "GTM Container's API relative path.",
                  "type": "string"
                },
                "containerId": {
                  "description": "ID of container that will be merged into the current container.",
                  "type": "string",
                  "location": "query"
                },
                "settingSource": {
                  "type": "string",
                  "enum": [
                    "settingSourceUnspecified",
                    "current",
                    "other"
                  ],
                  "enumDescriptions": [
                    "",
                    "Keep the current container config setting after combine",
                    "Use config setting from the other tag after combine"
                  ],
                  "description": "Specify the source of config setting after combine",
                  "location": "query"
                }
              },
              "path": "tagmanager/v2/{+path}:combine",
              "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}:combine",
              "response": {
                "$ref": "Container"
              },
              "parameterOrder": [
                "path"
              ],
              "description": "Combines Containers.",
              "deprecated": true,
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.edit.containers"
              ],
              "id": "tagmanager.accounts.containers.combine"
            },
            "delete": {
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.delete.containers"
              ],
              "id": "tagmanager.accounts.containers.delete",
              "parameterOrder": [
                "path"
              ],
              "httpMethod": "DELETE",
              "parameters": {
                "path": {
                  "description": "GTM Container's API relative path.",
                  "pattern": "^accounts/[^/]+/containers/[^/]+$",
                  "location": "path",
                  "required": true,
                  "type": "string"
                }
              },
              "path": "tagmanager/v2/{+path}",
              "description": "Deletes a Container.",
              "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}"
            },
            "list": {
              "id": "tagmanager.accounts.containers.list",
              "flatPath": "tagmanager/v2/accounts/{accountsId}/containers",
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.edit.containers",
                "https://www.googleapis.com/auth/tagmanager.readonly"
              ],
              "parameterOrder": [
                "parent"
              ],
              "httpMethod": "GET",
              "parameters": {
                "pageToken": {
                  "location": "query",
                  "type": "string",
                  "description": "Continuation token for fetching the next page of results."
                },
                "parent": {
                  "pattern": "^accounts/[^/]+$",
                  "type": "string",
                  "description": "GTM Account's API relative path.",
                  "location": "path",
                  "required": true
                }
              },
              "description": "Lists all Containers that belongs to a GTM Account.",
              "response": {
                "$ref": "ListContainersResponse"
              },
              "path": "tagmanager/v2/{+parent}/containers"
            },
            "get": {
              "id": "tagmanager.accounts.containers.get",
              "path": "tagmanager/v2/{+path}",
              "response": {
                "$ref": "Container"
              },
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.edit.containers",
                "https://www.googleapis.com/auth/tagmanager.readonly"
              ],
              "description": "Gets a Container.",
              "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}",
              "parameterOrder": [
                "path"
              ],
              "httpMethod": "GET",
              "parameters": {
                "path": {
                  "type": "string",
                  "pattern": "^accounts/[^/]+/containers/[^/]+$",
                  "location": "path",
                  "required": true,
                  "description": "GTM Container's API relative path."
                }
              }
            }
          },
          "resources": {
            "version_headers": {
              "methods": {
                "list": {
                  "httpMethod": "GET",
                  "parameters": {
                    "parent": {
                      "type": "string",
                      "location": "path",
                      "required": true,
                      "description": "GTM Container's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+$"
                    },
                    "includeDeleted": {
                      "description": "Also retrieve deleted (archived) versions when true.",
                      "type": "boolean",
                      "location": "query"
                    },
                    "pageToken": {
                      "type": "string",
                      "location": "query",
                      "description": "Continuation token for fetching the next page of results."
                    }
                  },
                  "parameterOrder": [
                    "parent"
                  ],
                  "path": "tagmanager/v2/{+parent}/version_headers",
                  "response": {
                    "$ref": "ListContainerVersionsResponse"
                  },
                  "description": "Lists all Container Versions of a GTM Container.",
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/version_headers",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.edit.containerversions",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ],
                  "id": "tagmanager.accounts.containers.version_headers.list"
                },
                "latest": {
                  "id": "tagmanager.accounts.containers.version_headers.latest",
                  "parameterOrder": [
                    "parent"
                  ],
                  "httpMethod": "GET",
                  "parameters": {
                    "parent": {
                      "type": "string",
                      "location": "path",
                      "required": true,
                      "description": "GTM Container's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+$"
                    }
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/version_headers:latest",
                  "response": {
                    "$ref": "ContainerVersionHeader"
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ],
                  "description": "Gets the latest container version header",
                  "path": "tagmanager/v2/{+parent}/version_headers:latest"
                }
              }
            },
            "destinations": {
              "methods": {
                "get": {
                  "path": "tagmanager/v2/{+path}",
                  "response": {
                    "$ref": "Destination"
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ],
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/destinations/{destinationsId}",
                  "httpMethod": "GET",
                  "parameters": {
                    "path": {
                      "location": "path",
                      "required": true,
                      "pattern": "^accounts/[^/]+/containers/[^/]+/destinations/[^/]+$",
                      "type": "string",
                      "description": "Google Tag Destination's API relative path."
                    }
                  },
                  "parameterOrder": [
                    "path"
                  ],
                  "id": "tagmanager.accounts.containers.destinations.get",
                  "description": "Gets a Destination.",
                  "deprecated": true
                },
                "list": {
                  "parameterOrder": [
                    "parent"
                  ],
                  "httpMethod": "GET",
                  "parameters": {
                    "parent": {
                      "location": "path",
                      "required": true,
                      "pattern": "^accounts/[^/]+/containers/[^/]+$",
                      "description": "GTM parent Container's API relative path.",
                      "type": "string"
                    }
                  },
                  "id": "tagmanager.accounts.containers.destinations.list",
                  "response": {
                    "$ref": "ListDestinationsResponse"
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ],
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/destinations",
                  "description": "Lists all Destinations linked to a GTM Container.",
                  "path": "tagmanager/v2/{+parent}/destinations"
                },
                "link": {
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ],
                  "deprecated": true,
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/destinations:link",
                  "response": {
                    "$ref": "Destination"
                  },
                  "id": "tagmanager.accounts.containers.destinations.link",
                  "description": "Adds a Destination to this Container and removes it from the Container to which it is currently linked.",
                  "parameterOrder": [
                    "parent"
                  ],
                  "httpMethod": "POST",
                  "parameters": {
                    "allowUserPermissionFeatureUpdate": {
                      "description": "Must be set to true to allow features.user_permissions to change from false to true. If this operation causes an update but this bit is false, the operation will fail.",
                      "location": "query",
                      "type": "boolean"
                    },
                    "destinationId": {
                      "type": "string",
                      "location": "query",
                      "description": "Destination ID to be linked to the current container."
                    },
                    "parent": {
                      "pattern": "^accounts/[^/]+/containers/[^/]+$",
                      "type": "string",
                      "location": "path",
                      "required": true,
                      "description": "GTM parent Container's API relative path."
                    }
                  },
                  "path": "tagmanager/v2/{+parent}/destinations:link"
                }
              }
            },
            "workspaces": {
              "methods": {
                "getStatus": {
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ],
                  "httpMethod": "GET",
                  "parameters": {
                    "path": {
                      "location": "path",
                      "required": true,
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "description": "GTM Workspace's API relative path.",
                      "type": "string"
                    }
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/status",
                  "response": {
                    "$ref": "GetWorkspaceStatusResponse"
                  },
                  "id": "tagmanager.accounts.containers.workspaces.getStatus",
                  "parameterOrder": [
                    "path"
                  ],
                  "path": "tagmanager/v2/{+path}/status",
                  "description": "Finds conflicting and modified entities in the workspace."
                },
                "delete": {
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.delete.containers"
                  ],
                  "id": "tagmanager.accounts.containers.workspaces.delete",
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}",
                  "path": "tagmanager/v2/{+path}",
                  "parameterOrder": [
                    "path"
                  ],
                  "description": "Deletes a Workspace.",
                  "httpMethod": "DELETE",
                  "parameters": {
                    "path": {
                      "location": "path",
                      "required": true,
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "type": "string",
                      "description": "GTM Workspace's API relative path."
                    }
                  }
                },
                "sync": {
                  "path": "tagmanager/v2/{+path}:sync",
                  "parameterOrder": [
                    "path"
                  ],
                  "id": "tagmanager.accounts.containers.workspaces.sync",
                  "response": {
                    "$ref": "SyncWorkspaceResponse"
                  },
                  "description": "Syncs a workspace to the latest container version by updating all unmodified workspace entities and displaying conflicts for modified entities.",
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}:sync",
                  "httpMethod": "POST",
                  "parameters": {
                    "path": {
                      "type": "string",
                      "description": "GTM Workspace's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "location": "path",
                      "required": true
                    }
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ]
                },
                "quick_preview": {
                  "id": "tagmanager.accounts.containers.workspaces.quick_preview",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containerversions"
                  ],
                  "description": "Quick previews a workspace by creating a fake container version from all entities in the provided workspace.",
                  "response": {
                    "$ref": "QuickPreviewResponse"
                  },
                  "parameterOrder": [
                    "path"
                  ],
                  "httpMethod": "POST",
                  "parameters": {
                    "path": {
                      "description": "GTM Workspace's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "type": "string",
                      "location": "path",
                      "required": true
                    }
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}:quick_preview",
                  "path": "tagmanager/v2/{+path}:quick_preview"
                },
                "update": {
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}",
                  "request": {
                    "$ref": "Workspace"
                  },
                  "id": "tagmanager.accounts.containers.workspaces.update",
                  "description": "Updates a Workspace.",
                  "response": {
                    "$ref": "Workspace"
                  },
                  "path": "tagmanager/v2/{+path}",
                  "parameterOrder": [
                    "path"
                  ],
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ],
                  "httpMethod": "PUT",
                  "parameters": {
                    "fingerprint": {
                      "type": "string",
                      "description": "When provided, this fingerprint must match the fingerprint of the workspace in storage.",
                      "location": "query"
                    },
                    "path": {
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "description": "GTM Workspace's API relative path.",
                      "type": "string",
                      "location": "path",
                      "required": true
                    }
                  }
                },
                "create": {
                  "id": "tagmanager.accounts.containers.workspaces.create",
                  "parameterOrder": [
                    "parent"
                  ],
                  "description": "Creates a Workspace.",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ],
                  "response": {
                    "$ref": "Workspace"
                  },
                  "httpMethod": "POST",
                  "parameters": {
                    "parent": {
                      "location": "path",
                      "required": true,
                      "description": "GTM parent Container's API relative path.",
                      "type": "string",
                      "pattern": "^accounts/[^/]+/containers/[^/]+$"
                    }
                  },
                  "path": "tagmanager/v2/{+parent}/workspaces",
                  "request": {
                    "$ref": "Workspace"
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces"
                },
                "create_version": {
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containerversions"
                  ],
                  "response": {
                    "$ref": "CreateContainerVersionResponse"
                  },
                  "id": "tagmanager.accounts.containers.workspaces.create_version",
                  "httpMethod": "POST",
                  "parameters": {
                    "path": {
                      "description": "GTM Workspace's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "type": "string",
                      "location": "path",
                      "required": true
                    }
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}:create_version",
                  "parameterOrder": [
                    "path"
                  ],
                  "request": {
                    "$ref": "CreateContainerVersionRequestVersionOptions"
                  },
                  "path": "tagmanager/v2/{+path}:create_version",
                  "description": "Creates a Container Version from the entities present in the workspace, deletes the workspace, and sets the base container version to the newly created version."
                },
                "get": {
                  "path": "tagmanager/v2/{+path}",
                  "description": "Gets a Workspace.",
                  "parameterOrder": [
                    "path"
                  ],
                  "response": {
                    "$ref": "Workspace"
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}",
                  "httpMethod": "GET",
                  "parameters": {
                    "path": {
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "description": "GTM Workspace's API relative path.",
                      "location": "path",
                      "required": true,
                      "type": "string"
                    }
                  },
                  "id": "tagmanager.accounts.containers.workspaces.get",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ]
                },
                "bulk_update": {
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/bulk_update",
                  "path": "tagmanager/v2/{+path}/bulk_update",
                  "httpMethod": "POST",
                  "parameters": {
                    "path": {
                      "type": "string",
                      "description": "GTM Workspace's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "location": "path",
                      "required": true
                    }
                  },
                  "response": {
                    "$ref": "BulkUpdateWorkspaceResponse"
                  },
                  "request": {
                    "$ref": "ProposedChange"
                  },
                  "parameterOrder": [
                    "path"
                  ],
                  "description": "Applies multiple entity changes to a workspace in one call. When creating new entities, their entity IDs must be unique and in correct format. That is, they must start with \"new_\" and followed by number, e.g. \"new_1\", \"new_2\". Example body snippet to create myNewTag under myNewFolder is: ``` \"changes\": [ { \"folder\": { \"folderId\": \"new_1\", \"name\": \"myNewFolder\", ... }, \"changeStatus\": \"added\" }, { \"tag\": { \"tagId\": \"new_2\", \"name\": \"myNewTag\", \"parentFolderId\": \"new_1\", ... }, \"changeStatus\": \"added\" } ] ```",
                  "id": "tagmanager.accounts.containers.workspaces.bulk_update",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ]
                },
                "resolve_conflict": {
                  "httpMethod": "POST",
                  "parameters": {
                    "path": {
                      "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                      "description": "GTM Workspace's API relative path.",
                      "type": "string",
                      "location": "path",
                      "required": true
                    },
                    "fingerprint": {
                      "type": "string",
                      "location": "query",
                      "description": "When provided, this fingerprint must match the fingerprint of the entity_in_workspace in the merge conflict."
                    }
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ],
                  "description": "Resolves a merge conflict for a workspace entity by updating it to the resolved entity passed in the request.",
                  "request": {
                    "$ref": "Entity"
                  },
                  "path": "tagmanager/v2/{+path}:resolve_conflict",
                  "parameterOrder": [
                    "path"
                  ],
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}:resolve_conflict",
                  "id": "tagmanager.accounts.containers.workspaces.resolve_conflict"
                },
                "list": {
                  "httpMethod": "GET",
                  "parameters": {
                    "parent": {
                      "type": "string",
                      "location": "path",
                      "required": true,
                      "description": "GTM parent Container's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+$"
                    },
                    "pageToken": {
                      "location": "query",
                      "type": "string",
                      "description": "Continuation token for fetching the next page of results."
                    }
                  },
                  "path": "tagmanager/v2/{+parent}/workspaces",
                  "parameterOrder": [
                    "parent"
                  ],
                  "description": "Lists all Workspaces that belong to a GTM Container.",
                  "id": "tagmanager.accounts.containers.workspaces.list",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ],
                  "response": {
                    "$ref": "ListWorkspacesResponse"
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces"
                }
              },
              "resources": {
                "tags": {
                  "methods": {
                    "list": {
                      "id": "tagmanager.accounts.containers.workspaces.tags.list",
                      "description": "Lists all GTM Tags of a Container.",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "path": "tagmanager/v2/{+parent}/tags",
                      "response": {
                        "$ref": "ListTagsResponse"
                      },
                      "httpMethod": "GET",
                      "parameters": {
                        "pageToken": {
                          "description": "Continuation token for fetching the next page of results.",
                          "type": "string",
                          "location": "query"
                        },
                        "parent": {
                          "description": "GTM Workspace's API relative path.",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$"
                        }
                      },
                      "parameterOrder": [
                        "parent"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/tags"
                    },
                    "update": {
                      "description": "Updates a GTM Tag.",
                      "parameterOrder": [
                        "path"
                      ],
                      "request": {
                        "$ref": "Tag"
                      },
                      "httpMethod": "PUT",
                      "parameters": {
                        "path": {
                          "description": "GTM Tag's API relative path.",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/tags/[^/]+$"
                        },
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of the tag in storage.",
                          "location": "query",
                          "type": "string"
                        }
                      },
                      "path": "tagmanager/v2/{+path}",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.tags.update",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/tags/{tagsId}",
                      "response": {
                        "$ref": "Tag"
                      }
                    },
                    "create": {
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/tags",
                      "response": {
                        "$ref": "Tag"
                      },
                      "parameterOrder": [
                        "parent"
                      ],
                      "description": "Creates a GTM Tag.",
                      "id": "tagmanager.accounts.containers.workspaces.tags.create",
                      "path": "tagmanager/v2/{+parent}/tags",
                      "request": {
                        "$ref": "Tag"
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "type": "string",
                          "description": "GTM Workspace's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "location": "path",
                          "required": true
                        }
                      }
                    },
                    "delete": {
                      "parameterOrder": [
                        "path"
                      ],
                      "description": "Deletes a GTM Tag.",
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/tags/[^/]+$",
                          "description": "GTM Tag's API relative path.",
                          "location": "path",
                          "required": true
                        }
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/tags/{tagsId}",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.tags.delete",
                      "path": "tagmanager/v2/{+path}"
                    },
                    "revert": {
                      "id": "tagmanager.accounts.containers.workspaces.tags.revert",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/tags/{tagsId}:revert",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Reverts changes to a GTM Tag in a GTM Workspace.",
                      "response": {
                        "$ref": "RevertTagResponse"
                      },
                      "path": "tagmanager/v2/{+path}:revert",
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "POST",
                      "parameters": {
                        "path": {
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "description": "GTM Tag's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/tags/[^/]+$"
                        },
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of thetag in storage.",
                          "location": "query",
                          "type": "string"
                        }
                      }
                    },
                    "get": {
                      "path": "tagmanager/v2/{+path}",
                      "parameterOrder": [
                        "path"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/tags/{tagsId}",
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "description": "GTM Tag's API relative path.",
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/tags/[^/]+$",
                          "location": "path",
                          "required": true
                        }
                      },
                      "response": {
                        "$ref": "Tag"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.tags.get",
                      "description": "Gets a GTM Tag."
                    }
                  }
                },
                "built_in_variables": {
                  "methods": {
                    "create": {
                      "path": "tagmanager/v2/{+parent}/built_in_variables",
                      "description": "Creates one or more GTM Built-In Variables.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/built_in_variables",
                      "id": "tagmanager.accounts.containers.workspaces.built_in_variables.create",
                      "response": {
                        "$ref": "CreateBuiltInVariableResponse"
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "parameterOrder": [
                        "parent"
                      ],
                      "httpMethod": "POST",
                      "parameters": {
                        "type": {
                          "enumDescriptions": [
                            "",
                            "",
                            "",
                            "",
                            "",
                            "For web or mobile.",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "For web or mobile.",
                            "",
                            "For web or mobile.",
                            "For web or mobile.",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                          ],
                          "type": "string",
                          "enum": [
                            "builtInVariableTypeUnspecified",
                            "pageUrl",
                            "pageHostname",
                            "pagePath",
                            "referrer",
                            "event",
                            "clickElement",
                            "clickClasses",
                            "clickId",
                            "clickTarget",
                            "clickUrl",
                            "clickText",
                            "firstPartyServingUrl",
                            "formElement",
                            "formClasses",
                            "formId",
                            "formTarget",
                            "formUrl",
                            "formText",
                            "errorMessage",
                            "errorUrl",
                            "errorLine",
                            "newHistoryUrl",
                            "oldHistoryUrl",
                            "newHistoryFragment",
                            "oldHistoryFragment",
                            "newHistoryState",
                            "oldHistoryState",
                            "historySource",
                            "containerVersion",
                            "debugMode",
                            "randomNumber",
                            "containerId",
                            "appId",
                            "appName",
                            "appVersionCode",
                            "appVersionName",
                            "language",
                            "osVersion",
                            "platform",
                            "sdkVersion",
                            "deviceName",
                            "resolution",
                            "advertiserId",
                            "advertisingTrackingEnabled",
                            "htmlId",
                            "environmentName",
                            "ampBrowserLanguage",
                            "ampCanonicalPath",
                            "ampCanonicalUrl",
                            "ampCanonicalHost",
                            "ampReferrer",
                            "ampTitle",
                            "ampClientId",
                            "ampClientTimezone",
                            "ampClientTimestamp",
                            "ampClientScreenWidth",
                            "ampClientScreenHeight",
                            "ampClientScrollX",
                            "ampClientScrollY",
                            "ampClientMaxScrollX",
                            "ampClientMaxScrollY",
                            "ampTotalEngagedTime",
                            "ampPageViewId",
                            "ampPageLoadTime",
                            "ampPageDownloadTime",
                            "ampGtmEvent",
                            "eventName",
                            "firebaseEventParameterCampaign",
                            "firebaseEventParameterCampaignAclid",
                            "firebaseEventParameterCampaignAnid",
                            "firebaseEventParameterCampaignClickTimestamp",
                            "firebaseEventParameterCampaignContent",
                            "firebaseEventParameterCampaignCp1",
                            "firebaseEventParameterCampaignGclid",
                            "firebaseEventParameterCampaignSource",
                            "firebaseEventParameterCampaignTerm",
                            "firebaseEventParameterCurrency",
                            "firebaseEventParameterDynamicLinkAcceptTime",
                            "firebaseEventParameterDynamicLinkLinkid",
                            "firebaseEventParameterNotificationMessageDeviceTime",
                            "firebaseEventParameterNotificationMessageId",
                            "firebaseEventParameterNotificationMessageName",
                            "firebaseEventParameterNotificationMessageTime",
                            "firebaseEventParameterNotificationTopic",
                            "firebaseEventParameterPreviousAppVersion",
                            "firebaseEventParameterPreviousOsVersion",
                            "firebaseEventParameterPrice",
                            "firebaseEventParameterProductId",
                            "firebaseEventParameterQuantity",
                            "firebaseEventParameterValue",
                            "videoProvider",
                            "videoUrl",
                            "videoTitle",
                            "videoDuration",
                            "videoPercent",
                            "videoVisible",
                            "videoStatus",
                            "videoCurrentTime",
                            "scrollDepthThreshold",
                            "scrollDepthUnits",
                            "scrollDepthDirection",
                            "elementVisibilityRatio",
                            "elementVisibilityTime",
                            "elementVisibilityFirstTime",
                            "elementVisibilityRecentTime",
                            "requestPath",
                            "requestMethod",
                            "clientName",
                            "queryString",
                            "serverPageLocationUrl",
                            "serverPageLocationPath",
                            "serverPageLocationHostname",
                            "visitorRegion",
                            "analyticsClientId",
                            "analyticsSessionId",
                            "analyticsSessionNumber"
                          ],
                          "location": "query",
                          "repeated": true,
                          "description": "The types of built-in variables to enable."
                        },
                        "parent": {
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "description": "GTM Workspace's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$"
                        }
                      }
                    },
                    "revert": {
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "path": "tagmanager/v2/{+path}/built_in_variables:revert",
                      "httpMethod": "POST",
                      "parameters": {
                        "path": {
                          "description": "GTM BuiltInVariable's API relative path.",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$"
                        },
                        "type": {
                          "enumDescriptions": [
                            "",
                            "",
                            "",
                            "",
                            "",
                            "For web or mobile.",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "For web or mobile.",
                            "",
                            "For web or mobile.",
                            "For web or mobile.",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                          ],
                          "location": "query",
                          "description": "The type of built-in variable to revert.",
                          "type": "string",
                          "enum": [
                            "builtInVariableTypeUnspecified",
                            "pageUrl",
                            "pageHostname",
                            "pagePath",
                            "referrer",
                            "event",
                            "clickElement",
                            "clickClasses",
                            "clickId",
                            "clickTarget",
                            "clickUrl",
                            "clickText",
                            "firstPartyServingUrl",
                            "formElement",
                            "formClasses",
                            "formId",
                            "formTarget",
                            "formUrl",
                            "formText",
                            "errorMessage",
                            "errorUrl",
                            "errorLine",
                            "newHistoryUrl",
                            "oldHistoryUrl",
                            "newHistoryFragment",
                            "oldHistoryFragment",
                            "newHistoryState",
                            "oldHistoryState",
                            "historySource",
                            "containerVersion",
                            "debugMode",
                            "randomNumber",
                            "containerId",
                            "appId",
                            "appName",
                            "appVersionCode",
                            "appVersionName",
                            "language",
                            "osVersion",
                            "platform",
                            "sdkVersion",
                            "deviceName",
                            "resolution",
                            "advertiserId",
                            "advertisingTrackingEnabled",
                            "htmlId",
                            "environmentName",
                            "ampBrowserLanguage",
                            "ampCanonicalPath",
                            "ampCanonicalUrl",
                            "ampCanonicalHost",
                            "ampReferrer",
                            "ampTitle",
                            "ampClientId",
                            "ampClientTimezone",
                            "ampClientTimestamp",
                            "ampClientScreenWidth",
                            "ampClientScreenHeight",
                            "ampClientScrollX",
                            "ampClientScrollY",
                            "ampClientMaxScrollX",
                            "ampClientMaxScrollY",
                            "ampTotalEngagedTime",
                            "ampPageViewId",
                            "ampPageLoadTime",
                            "ampPageDownloadTime",
                            "ampGtmEvent",
                            "eventName",
                            "firebaseEventParameterCampaign",
                            "firebaseEventParameterCampaignAclid",
                            "firebaseEventParameterCampaignAnid",
                            "firebaseEventParameterCampaignClickTimestamp",
                            "firebaseEventParameterCampaignContent",
                            "firebaseEventParameterCampaignCp1",
                            "firebaseEventParameterCampaignGclid",
                            "firebaseEventParameterCampaignSource",
                            "firebaseEventParameterCampaignTerm",
                            "firebaseEventParameterCurrency",
                            "firebaseEventParameterDynamicLinkAcceptTime",
                            "firebaseEventParameterDynamicLinkLinkid",
                            "firebaseEventParameterNotificationMessageDeviceTime",
                            "firebaseEventParameterNotificationMessageId",
                            "firebaseEventParameterNotificationMessageName",
                            "firebaseEventParameterNotificationMessageTime",
                            "firebaseEventParameterNotificationTopic",
                            "firebaseEventParameterPreviousAppVersion",
                            "firebaseEventParameterPreviousOsVersion",
                            "firebaseEventParameterPrice",
                            "firebaseEventParameterProductId",
                            "firebaseEventParameterQuantity",
                            "firebaseEventParameterValue",
                            "videoProvider",
                            "videoUrl",
                            "videoTitle",
                            "videoDuration",
                            "videoPercent",
                            "videoVisible",
                            "videoStatus",
                            "videoCurrentTime",
                            "scrollDepthThreshold",
                            "scrollDepthUnits",
                            "scrollDepthDirection",
                            "elementVisibilityRatio",
                            "elementVisibilityTime",
                            "elementVisibilityFirstTime",
                            "elementVisibilityRecentTime",
                            "requestPath",
                            "requestMethod",
                            "clientName",
                            "queryString",
                            "serverPageLocationUrl",
                            "serverPageLocationPath",
                            "serverPageLocationHostname",
                            "visitorRegion",
                            "analyticsClientId",
                            "analyticsSessionId",
                            "analyticsSessionNumber"
                          ]
                        }
                      },
                      "response": {
                        "$ref": "RevertBuiltInVariableResponse"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.built_in_variables.revert",
                      "description": "Reverts changes to a GTM Built-In Variables in a GTM Workspace.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/built_in_variables:revert",
                      "parameterOrder": [
                        "path"
                      ]
                    },
                    "delete": {
                      "path": "tagmanager/v2/{+path}",
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "description": "GTM BuiltInVariable's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/built_in_variables$",
                          "type": "string"
                        },
                        "type": {
                          "description": "The types of built-in variables to delete.",
                          "location": "query",
                          "type": "string",
                          "enum": [
                            "builtInVariableTypeUnspecified",
                            "pageUrl",
                            "pageHostname",
                            "pagePath",
                            "referrer",
                            "event",
                            "clickElement",
                            "clickClasses",
                            "clickId",
                            "clickTarget",
                            "clickUrl",
                            "clickText",
                            "firstPartyServingUrl",
                            "formElement",
                            "formClasses",
                            "formId",
                            "formTarget",
                            "formUrl",
                            "formText",
                            "errorMessage",
                            "errorUrl",
                            "errorLine",
                            "newHistoryUrl",
                            "oldHistoryUrl",
                            "newHistoryFragment",
                            "oldHistoryFragment",
                            "newHistoryState",
                            "oldHistoryState",
                            "historySource",
                            "containerVersion",
                            "debugMode",
                            "randomNumber",
                            "containerId",
                            "appId",
                            "appName",
                            "appVersionCode",
                            "appVersionName",
                            "language",
                            "osVersion",
                            "platform",
                            "sdkVersion",
                            "deviceName",
                            "resolution",
                            "advertiserId",
                            "advertisingTrackingEnabled",
                            "htmlId",
                            "environmentName",
                            "ampBrowserLanguage",
                            "ampCanonicalPath",
                            "ampCanonicalUrl",
                            "ampCanonicalHost",
                            "ampReferrer",
                            "ampTitle",
                            "ampClientId",
                            "ampClientTimezone",
                            "ampClientTimestamp",
                            "ampClientScreenWidth",
                            "ampClientScreenHeight",
                            "ampClientScrollX",
                            "ampClientScrollY",
                            "ampClientMaxScrollX",
                            "ampClientMaxScrollY",
                            "ampTotalEngagedTime",
                            "ampPageViewId",
                            "ampPageLoadTime",
                            "ampPageDownloadTime",
                            "ampGtmEvent",
                            "eventName",
                            "firebaseEventParameterCampaign",
                            "firebaseEventParameterCampaignAclid",
                            "firebaseEventParameterCampaignAnid",
                            "firebaseEventParameterCampaignClickTimestamp",
                            "firebaseEventParameterCampaignContent",
                            "firebaseEventParameterCampaignCp1",
                            "firebaseEventParameterCampaignGclid",
                            "firebaseEventParameterCampaignSource",
                            "firebaseEventParameterCampaignTerm",
                            "firebaseEventParameterCurrency",
                            "firebaseEventParameterDynamicLinkAcceptTime",
                            "firebaseEventParameterDynamicLinkLinkid",
                            "firebaseEventParameterNotificationMessageDeviceTime",
                            "firebaseEventParameterNotificationMessageId",
                            "firebaseEventParameterNotificationMessageName",
                            "firebaseEventParameterNotificationMessageTime",
                            "firebaseEventParameterNotificationTopic",
                            "firebaseEventParameterPreviousAppVersion",
                            "firebaseEventParameterPreviousOsVersion",
                            "firebaseEventParameterPrice",
                            "firebaseEventParameterProductId",
                            "firebaseEventParameterQuantity",
                            "firebaseEventParameterValue",
                            "videoProvider",
                            "videoUrl",
                            "videoTitle",
                            "videoDuration",
                            "videoPercent",
                            "videoVisible",
                            "videoStatus",
                            "videoCurrentTime",
                            "scrollDepthThreshold",
                            "scrollDepthUnits",
                            "scrollDepthDirection",
                            "elementVisibilityRatio",
                            "elementVisibilityTime",
                            "elementVisibilityFirstTime",
                            "elementVisibilityRecentTime",
                            "requestPath",
                            "requestMethod",
                            "clientName",
                            "queryString",
                            "serverPageLocationUrl",
                            "serverPageLocationPath",
                            "serverPageLocationHostname",
                            "visitorRegion",
                            "analyticsClientId",
                            "analyticsSessionId",
                            "analyticsSessionNumber"
                          ],
                          "enumDescriptions": [
                            "",
                            "",
                            "",
                            "",
                            "",
                            "For web or mobile.",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "For web or mobile.",
                            "",
                            "For web or mobile.",
                            "For web or mobile.",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                          ],
                          "repeated": true
                        }
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Deletes one or more GTM Built-In Variables.",
                      "id": "tagmanager.accounts.containers.workspaces.built_in_variables.delete",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/built_in_variables"
                    },
                    "list": {
                      "path": "tagmanager/v2/{+parent}/built_in_variables",
                      "httpMethod": "GET",
                      "parameters": {
                        "parent": {
                          "description": "GTM Workspace's API relative path.",
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "location": "path",
                          "required": true
                        },
                        "pageToken": {
                          "description": "Continuation token for fetching the next page of results.",
                          "location": "query",
                          "type": "string"
                        }
                      },
                      "description": "Lists all the enabled Built-In Variables of a GTM Container.",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "response": {
                        "$ref": "ListEnabledBuiltInVariablesResponse"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/built_in_variables",
                      "id": "tagmanager.accounts.containers.workspaces.built_in_variables.list",
                      "parameterOrder": [
                        "parent"
                      ]
                    }
                  }
                },
                "gtag_config": {
                  "methods": {
                    "get": {
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/gtag_config/{gtag_configId}",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.gtag_config.get",
                      "response": {
                        "$ref": "GtagConfig"
                      },
                      "description": "Gets a Google tag config.",
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "type": "string",
                          "description": "Google tag config's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/gtag_config/[^/]+$"
                        }
                      },
                      "parameterOrder": [
                        "path"
                      ],
                      "path": "tagmanager/v2/{+path}"
                    },
                    "update": {
                      "path": "tagmanager/v2/{+path}",
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "PUT",
                      "parameters": {
                        "path": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/gtag_config/[^/]+$",
                          "description": "Google tag config's API relative path.",
                          "location": "path",
                          "required": true,
                          "type": "string"
                        },
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of the config in storage.",
                          "location": "query",
                          "type": "string"
                        }
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/gtag_config/{gtag_configId}",
                      "description": "Updates a Google tag config.",
                      "id": "tagmanager.accounts.containers.workspaces.gtag_config.update",
                      "request": {
                        "$ref": "GtagConfig"
                      },
                      "response": {
                        "$ref": "GtagConfig"
                      }
                    },
                    "create": {
                      "response": {
                        "$ref": "GtagConfig"
                      },
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "description": "Workspace's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string"
                        }
                      },
                      "request": {
                        "$ref": "GtagConfig"
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/gtag_config",
                      "path": "tagmanager/v2/{+parent}/gtag_config",
                      "parameterOrder": [
                        "parent"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.gtag_config.create",
                      "description": "Creates a Google tag config."
                    },
                    "delete": {
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/gtag_config/[^/]+$",
                          "description": "Google tag config's API relative path."
                        }
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/gtag_config/{gtag_configId}",
                      "id": "tagmanager.accounts.containers.workspaces.gtag_config.delete",
                      "path": "tagmanager/v2/{+path}",
                      "description": "Deletes a Google tag config.",
                      "parameterOrder": [
                        "path"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ]
                    },
                    "list": {
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "path": "tagmanager/v2/{+parent}/gtag_config",
                      "response": {
                        "$ref": "ListGtagConfigResponse"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/gtag_config",
                      "id": "tagmanager.accounts.containers.workspaces.gtag_config.list",
                      "httpMethod": "GET",
                      "parameters": {
                        "parent": {
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string",
                          "description": "Workspace's API relative path."
                        },
                        "pageToken": {
                          "location": "query",
                          "description": "Continuation token for fetching the next page of results.",
                          "type": "string"
                        }
                      },
                      "parameterOrder": [
                        "parent"
                      ],
                      "description": "Lists all Google tag configs in a Container."
                    }
                  }
                },
                "transformations": {
                  "methods": {
                    "revert": {
                      "description": "Reverts changes to a GTM Transformation in a GTM Workspace.",
                      "response": {
                        "$ref": "RevertTransformationResponse"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/transformations/{transformationsId}:revert",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "httpMethod": "POST",
                      "parameters": {
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of the transformation in storage.",
                          "type": "string",
                          "location": "query"
                        },
                        "path": {
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/transformations/[^/]+$",
                          "description": "GTM Transformation's API relative path."
                        }
                      },
                      "id": "tagmanager.accounts.containers.workspaces.transformations.revert",
                      "path": "tagmanager/v2/{+path}:revert",
                      "parameterOrder": [
                        "path"
                      ]
                    },
                    "delete": {
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.transformations.delete",
                      "parameterOrder": [
                        "path"
                      ],
                      "path": "tagmanager/v2/{+path}",
                      "description": "Deletes a GTM Transformation.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/transformations/{transformationsId}",
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/transformations/[^/]+$",
                          "description": "GTM Transformation's API relative path."
                        }
                      }
                    },
                    "list": {
                      "id": "tagmanager.accounts.containers.workspaces.transformations.list",
                      "httpMethod": "GET",
                      "parameters": {
                        "parent": {
                          "description": "GTM Workspace's API relative path.",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$"
                        },
                        "pageToken": {
                          "type": "string",
                          "location": "query",
                          "description": "Continuation token for fetching the next page of results."
                        }
                      },
                      "response": {
                        "$ref": "ListTransformationsResponse"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/transformations",
                      "path": "tagmanager/v2/{+parent}/transformations",
                      "parameterOrder": [
                        "parent"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "description": "Lists all GTM Transformations of a GTM container workspace."
                    },
                    "create": {
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Creates a GTM Transformation.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/transformations",
                      "response": {
                        "$ref": "Transformation"
                      },
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string",
                          "description": "GTM Workspace's API relative path.",
                          "location": "path",
                          "required": true
                        }
                      },
                      "parameterOrder": [
                        "parent"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.transformations.create",
                      "request": {
                        "$ref": "Transformation"
                      },
                      "path": "tagmanager/v2/{+parent}/transformations"
                    },
                    "update": {
                      "path": "tagmanager/v2/{+path}",
                      "httpMethod": "PUT",
                      "parameters": {
                        "path": {
                          "description": "GTM Transformation's API relative path.",
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/transformations/[^/]+$",
                          "location": "path",
                          "required": true
                        },
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of the transformation in storage.",
                          "type": "string",
                          "location": "query"
                        }
                      },
                      "id": "tagmanager.accounts.containers.workspaces.transformations.update",
                      "description": "Updates a GTM Transformation.",
                      "request": {
                        "$ref": "Transformation"
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "response": {
                        "$ref": "Transformation"
                      },
                      "parameterOrder": [
                        "path"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/transformations/{transformationsId}"
                    },
                    "get": {
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "path": "tagmanager/v2/{+path}",
                      "parameterOrder": [
                        "path"
                      ],
                      "description": "Gets a GTM Transformation.",
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "description": "GTM Transformation's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/transformations/[^/]+$",
                          "type": "string"
                        }
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/transformations/{transformationsId}",
                      "response": {
                        "$ref": "Transformation"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.transformations.get"
                    }
                  }
                },
                "templates": {
                  "methods": {
                    "import_from_gallery": {
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/templates:import_from_gallery",
                      "response": {
                        "$ref": "CustomTemplate"
                      },
                      "description": "Imports a GTM Custom Template from Gallery.",
                      "path": "tagmanager/v2/{+parent}/templates:import_from_gallery",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "parameterOrder": [
                        "parent"
                      ],
                      "httpMethod": "POST",
                      "parameters": {
                        "galleryRepository": {
                          "description": "Repository of the Gallery template to import",
                          "location": "query",
                          "type": "string"
                        },
                        "gallerySha": {
                          "description": "SHA version of the Gallery template to import. Defaulted to the latest SHA version if not provided.",
                          "location": "query",
                          "type": "string"
                        },
                        "galleryOwner": {
                          "description": "Owner of the Gallery template to import",
                          "location": "query",
                          "type": "string"
                        },
                        "parent": {
                          "description": "GTM Workspace's API relative path.",
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "location": "path",
                          "required": true
                        },
                        "acknowledgePermissions": {
                          "location": "query",
                          "description": "Must be set to true to allow Gallery template to be imported into the workspace. If this bit is false, the import operation will fail.",
                          "type": "boolean"
                        }
                      },
                      "id": "tagmanager.accounts.containers.workspaces.templates.import_from_gallery"
                    },
                    "list": {
                      "path": "tagmanager/v2/{+parent}/templates",
                      "httpMethod": "GET",
                      "parameters": {
                        "pageToken": {
                          "type": "string",
                          "location": "query",
                          "description": "Continuation token for fetching the next page of results."
                        },
                        "parent": {
                          "type": "string",
                          "description": "GTM Workspace's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "location": "path",
                          "required": true
                        }
                      },
                      "parameterOrder": [
                        "parent"
                      ],
                      "description": "Lists all GTM Templates of a GTM container workspace.",
                      "response": {
                        "$ref": "ListTemplatesResponse"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/templates",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.templates.list"
                    },
                    "get": {
                      "id": "tagmanager.accounts.containers.workspaces.templates.get",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "path": "tagmanager/v2/{+path}",
                      "description": "Gets a GTM Template.",
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/templates/[^/]+$",
                          "description": "GTM Custom Template's API relative path.",
                          "location": "path",
                          "required": true,
                          "type": "string"
                        }
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/templates/{templatesId}",
                      "response": {
                        "$ref": "CustomTemplate"
                      },
                      "parameterOrder": [
                        "path"
                      ]
                    },
                    "update": {
                      "path": "tagmanager/v2/{+path}",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "httpMethod": "PUT",
                      "parameters": {
                        "fingerprint": {
                          "type": "string",
                          "location": "query",
                          "description": "When provided, this fingerprint must match the fingerprint of the templates in storage."
                        },
                        "path": {
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/templates/[^/]+$",
                          "location": "path",
                          "required": true,
                          "description": "GTM Custom Template's API relative path."
                        }
                      },
                      "response": {
                        "$ref": "CustomTemplate"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/templates/{templatesId}",
                      "request": {
                        "$ref": "CustomTemplate"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.templates.update",
                      "parameterOrder": [
                        "path"
                      ],
                      "description": "Updates a GTM Template."
                    },
                    "create": {
                      "description": "Creates a GTM Custom Template.",
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "description": "GTM Workspace's API relative path.",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$"
                        }
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/templates",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "response": {
                        "$ref": "CustomTemplate"
                      },
                      "request": {
                        "$ref": "CustomTemplate"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.templates.create",
                      "path": "tagmanager/v2/{+parent}/templates",
                      "parameterOrder": [
                        "parent"
                      ]
                    },
                    "delete": {
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "path": "tagmanager/v2/{+path}",
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/templates/[^/]+$",
                          "description": "GTM Custom Template's API relative path.",
                          "type": "string"
                        }
                      },
                      "id": "tagmanager.accounts.containers.workspaces.templates.delete",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/templates/{templatesId}",
                      "description": "Deletes a GTM Template.",
                      "parameterOrder": [
                        "path"
                      ]
                    },
                    "revert": {
                      "path": "tagmanager/v2/{+path}:revert",
                      "httpMethod": "POST",
                      "parameters": {
                        "path": {
                          "description": "GTM Custom Template's API relative path.",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/templates/[^/]+$"
                        },
                        "fingerprint": {
                          "location": "query",
                          "type": "string",
                          "description": "When provided, this fingerprint must match the fingerprint of the template in storage."
                        }
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.templates.revert",
                      "parameterOrder": [
                        "path"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/templates/{templatesId}:revert",
                      "response": {
                        "$ref": "RevertTemplateResponse"
                      },
                      "description": "Reverts changes to a GTM Template in a GTM Workspace."
                    }
                  }
                },
                "clients": {
                  "methods": {
                    "get": {
                      "description": "Gets a GTM Client.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/clients/{clientsId}",
                      "id": "tagmanager.accounts.containers.workspaces.clients.get",
                      "response": {
                        "$ref": "Client"
                      },
                      "path": "tagmanager/v2/{+path}",
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "description": "GTM Client's API relative path.",
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/clients/[^/]+$"
                        }
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ]
                    },
                    "delete": {
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/clients/[^/]+$",
                          "type": "string",
                          "description": "GTM Client's API relative path.",
                          "location": "path",
                          "required": true
                        }
                      },
                      "path": "tagmanager/v2/{+path}",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/clients/{clientsId}",
                      "id": "tagmanager.accounts.containers.workspaces.clients.delete",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Deletes a GTM Client."
                    },
                    "revert": {
                      "id": "tagmanager.accounts.containers.workspaces.clients.revert",
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "POST",
                      "parameters": {
                        "path": {
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "description": "GTM Client's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/clients/[^/]+$"
                        },
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of the client in storage.",
                          "location": "query",
                          "type": "string"
                        }
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/clients/{clientsId}:revert",
                      "response": {
                        "$ref": "RevertClientResponse"
                      },
                      "description": "Reverts changes to a GTM Client in a GTM Workspace.",
                      "path": "tagmanager/v2/{+path}:revert"
                    },
                    "list": {
                      "path": "tagmanager/v2/{+parent}/clients",
                      "id": "tagmanager.accounts.containers.workspaces.clients.list",
                      "description": "Lists all GTM Clients of a GTM container workspace.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/clients",
                      "response": {
                        "$ref": "ListClientsResponse"
                      },
                      "httpMethod": "GET",
                      "parameters": {
                        "parent": {
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string",
                          "description": "GTM Workspace's API relative path."
                        },
                        "pageToken": {
                          "description": "Continuation token for fetching the next page of results.",
                          "location": "query",
                          "type": "string"
                        }
                      },
                      "parameterOrder": [
                        "parent"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ]
                    },
                    "update": {
                      "response": {
                        "$ref": "Client"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/clients/{clientsId}",
                      "description": "Updates a GTM Client.",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "path": "tagmanager/v2/{+path}",
                      "request": {
                        "$ref": "Client"
                      },
                      "httpMethod": "PUT",
                      "parameters": {
                        "path": {
                          "type": "string",
                          "description": "GTM Client's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/clients/[^/]+$"
                        },
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of the client in storage.",
                          "type": "string",
                          "location": "query"
                        }
                      },
                      "parameterOrder": [
                        "path"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.clients.update"
                    },
                    "create": {
                      "request": {
                        "$ref": "Client"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.clients.create",
                      "description": "Creates a GTM Client.",
                      "response": {
                        "$ref": "Client"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/clients",
                      "parameterOrder": [
                        "parent"
                      ],
                      "path": "tagmanager/v2/{+parent}/clients",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "description": "GTM Workspace's API relative path."
                        }
                      }
                    }
                  }
                },
                "zones": {
                  "methods": {
                    "list": {
                      "parameterOrder": [
                        "parent"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/zones",
                      "description": "Lists all GTM Zones of a GTM container workspace.",
                      "httpMethod": "GET",
                      "parameters": {
                        "parent": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string",
                          "description": "GTM Workspace's API relative path.",
                          "location": "path",
                          "required": true
                        },
                        "pageToken": {
                          "description": "Continuation token for fetching the next page of results.",
                          "location": "query",
                          "type": "string"
                        }
                      },
                      "response": {
                        "$ref": "ListZonesResponse"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.zones.list",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "path": "tagmanager/v2/{+parent}/zones"
                    },
                    "create": {
                      "request": {
                        "$ref": "Zone"
                      },
                      "response": {
                        "$ref": "Zone"
                      },
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "type": "string",
                          "description": "GTM Workspace's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$"
                        }
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Creates a GTM Zone.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/zones",
                      "id": "tagmanager.accounts.containers.workspaces.zones.create",
                      "path": "tagmanager/v2/{+parent}/zones",
                      "parameterOrder": [
                        "parent"
                      ]
                    },
                    "update": {
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/zones/{zonesId}",
                      "response": {
                        "$ref": "Zone"
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "httpMethod": "PUT",
                      "parameters": {
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of the zone in storage.",
                          "type": "string",
                          "location": "query"
                        },
                        "path": {
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "description": "GTM Zone's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/zones/[^/]+$"
                        }
                      },
                      "path": "tagmanager/v2/{+path}",
                      "request": {
                        "$ref": "Zone"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.zones.update",
                      "description": "Updates a GTM Zone.",
                      "parameterOrder": [
                        "path"
                      ]
                    },
                    "revert": {
                      "httpMethod": "POST",
                      "parameters": {
                        "path": {
                          "description": "GTM Zone's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/zones/[^/]+$",
                          "type": "string"
                        },
                        "fingerprint": {
                          "location": "query",
                          "description": "When provided, this fingerprint must match the fingerprint of the zone in storage.",
                          "type": "string"
                        }
                      },
                      "path": "tagmanager/v2/{+path}:revert",
                      "parameterOrder": [
                        "path"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/zones/{zonesId}:revert",
                      "description": "Reverts changes to a GTM Zone in a GTM Workspace.",
                      "response": {
                        "$ref": "RevertZoneResponse"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.zones.revert"
                    },
                    "get": {
                      "path": "tagmanager/v2/{+path}",
                      "response": {
                        "$ref": "Zone"
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/zones/{zonesId}",
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/zones/[^/]+$",
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "description": "GTM Zone's API relative path."
                        }
                      },
                      "parameterOrder": [
                        "path"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.zones.get",
                      "description": "Gets a GTM Zone."
                    },
                    "delete": {
                      "description": "Deletes a GTM Zone.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/zones/{zonesId}",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "location": "path",
                          "required": true,
                          "description": "GTM Zone's API relative path.",
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/zones/[^/]+$"
                        }
                      },
                      "path": "tagmanager/v2/{+path}",
                      "id": "tagmanager.accounts.containers.workspaces.zones.delete",
                      "parameterOrder": [
                        "path"
                      ]
                    }
                  }
                },
                "variables": {
                  "methods": {
                    "list": {
                      "id": "tagmanager.accounts.containers.workspaces.variables.list",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "parameterOrder": [
                        "parent"
                      ],
                      "description": "Lists all GTM Variables of a Container.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/variables",
                      "httpMethod": "GET",
                      "parameters": {
                        "pageToken": {
                          "type": "string",
                          "location": "query",
                          "description": "Continuation token for fetching the next page of results."
                        },
                        "parent": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "description": "GTM Workspace's API relative path."
                        }
                      },
                      "response": {
                        "$ref": "ListVariablesResponse"
                      },
                      "path": "tagmanager/v2/{+parent}/variables"
                    },
                    "create": {
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/variables",
                      "parameterOrder": [
                        "parent"
                      ],
                      "response": {
                        "$ref": "Variable"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.variables.create",
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "description": "GTM Workspace's API relative path."
                        }
                      },
                      "description": "Creates a GTM Variable.",
                      "path": "tagmanager/v2/{+parent}/variables",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "request": {
                        "$ref": "Variable"
                      }
                    },
                    "update": {
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/variables/{variablesId}",
                      "response": {
                        "$ref": "Variable"
                      },
                      "path": "tagmanager/v2/{+path}",
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "PUT",
                      "parameters": {
                        "path": {
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/variables/[^/]+$",
                          "description": "GTM Variable's API relative path."
                        },
                        "fingerprint": {
                          "type": "string",
                          "location": "query",
                          "description": "When provided, this fingerprint must match the fingerprint of the variable in storage."
                        }
                      },
                      "description": "Updates a GTM Variable.",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.variables.update",
                      "request": {
                        "$ref": "Variable"
                      }
                    },
                    "get": {
                      "path": "tagmanager/v2/{+path}",
                      "id": "tagmanager.accounts.containers.workspaces.variables.get",
                      "response": {
                        "$ref": "Variable"
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/variables/[^/]+$",
                          "location": "path",
                          "required": true,
                          "description": "GTM Variable's API relative path.",
                          "type": "string"
                        }
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/variables/{variablesId}",
                      "description": "Gets a GTM Variable.",
                      "parameterOrder": [
                        "path"
                      ]
                    },
                    "revert": {
                      "path": "tagmanager/v2/{+path}:revert",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Reverts changes to a GTM Variable in a GTM Workspace.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/variables/{variablesId}:revert",
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "POST",
                      "parameters": {
                        "path": {
                          "type": "string",
                          "description": "GTM Variable's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/variables/[^/]+$",
                          "location": "path",
                          "required": true
                        },
                        "fingerprint": {
                          "location": "query",
                          "description": "When provided, this fingerprint must match the fingerprint of the variable in storage.",
                          "type": "string"
                        }
                      },
                      "response": {
                        "$ref": "RevertVariableResponse"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.variables.revert"
                    },
                    "delete": {
                      "description": "Deletes a GTM Variable.",
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "location": "path",
                          "required": true,
                          "description": "GTM Variable's API relative path.",
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/variables/[^/]+$"
                        }
                      },
                      "id": "tagmanager.accounts.containers.workspaces.variables.delete",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/variables/{variablesId}",
                      "parameterOrder": [
                        "path"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "path": "tagmanager/v2/{+path}"
                    }
                  }
                },
                "folders": {
                  "methods": {
                    "list": {
                      "description": "Lists all GTM Folders of a Container.",
                      "parameterOrder": [
                        "parent"
                      ],
                      "httpMethod": "GET",
                      "parameters": {
                        "parent": {
                          "location": "path",
                          "required": true,
                          "description": "GTM Workspace's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string"
                        },
                        "pageToken": {
                          "location": "query",
                          "description": "Continuation token for fetching the next page of results.",
                          "type": "string"
                        }
                      },
                      "id": "tagmanager.accounts.containers.workspaces.folders.list",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/folders",
                      "response": {
                        "$ref": "ListFoldersResponse"
                      },
                      "path": "tagmanager/v2/{+parent}/folders"
                    },
                    "delete": {
                      "path": "tagmanager/v2/{+path}",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/folders/{foldersId}",
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/folders/[^/]+$",
                          "type": "string",
                          "description": "GTM Folder's API relative path.",
                          "location": "path",
                          "required": true
                        }
                      },
                      "description": "Deletes a GTM Folder.",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.folders.delete"
                    },
                    "revert": {
                      "id": "tagmanager.accounts.containers.workspaces.folders.revert",
                      "description": "Reverts changes to a GTM Folder in a GTM Workspace.",
                      "response": {
                        "$ref": "RevertFolderResponse"
                      },
                      "parameterOrder": [
                        "path"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/folders/{foldersId}:revert",
                      "httpMethod": "POST",
                      "parameters": {
                        "fingerprint": {
                          "type": "string",
                          "location": "query",
                          "description": "When provided, this fingerprint must match the fingerprint of the tag in storage."
                        },
                        "path": {
                          "description": "GTM Folder's API relative path.",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/folders/[^/]+$"
                        }
                      },
                      "path": "tagmanager/v2/{+path}:revert"
                    },
                    "entities": {
                      "response": {
                        "$ref": "FolderEntities"
                      },
                      "description": "List all entities in a GTM Folder.",
                      "parameterOrder": [
                        "path"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/folders/{foldersId}:entities",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.folders.entities",
                      "path": "tagmanager/v2/{+path}:entities",
                      "httpMethod": "POST",
                      "parameters": {
                        "pageToken": {
                          "description": "Continuation token for fetching the next page of results.",
                          "location": "query",
                          "type": "string"
                        },
                        "path": {
                          "description": "GTM Folder's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/folders/[^/]+$",
                          "type": "string"
                        }
                      }
                    },
                    "update": {
                      "description": "Updates a GTM Folder.",
                      "request": {
                        "$ref": "Folder"
                      },
                      "response": {
                        "$ref": "Folder"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/folders/{foldersId}",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.folders.update",
                      "httpMethod": "PUT",
                      "parameters": {
                        "fingerprint": {
                          "type": "string",
                          "location": "query",
                          "description": "When provided, this fingerprint must match the fingerprint of the folder in storage."
                        },
                        "path": {
                          "description": "GTM Folder's API relative path.",
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/folders/[^/]+$"
                        }
                      },
                      "parameterOrder": [
                        "path"
                      ],
                      "path": "tagmanager/v2/{+path}"
                    },
                    "create": {
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "description": "GTM Workspace's API relative path.",
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$"
                        }
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/folders",
                      "path": "tagmanager/v2/{+parent}/folders",
                      "response": {
                        "$ref": "Folder"
                      },
                      "parameterOrder": [
                        "parent"
                      ],
                      "request": {
                        "$ref": "Folder"
                      },
                      "description": "Creates a GTM Folder.",
                      "id": "tagmanager.accounts.containers.workspaces.folders.create",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ]
                    },
                    "get": {
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "type": "string",
                          "description": "GTM Folder's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/folders/[^/]+$",
                          "location": "path",
                          "required": true
                        }
                      },
                      "id": "tagmanager.accounts.containers.workspaces.folders.get",
                      "path": "tagmanager/v2/{+path}",
                      "parameterOrder": [
                        "path"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "response": {
                        "$ref": "Folder"
                      },
                      "description": "Gets a GTM Folder.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/folders/{foldersId}"
                    },
                    "move_entities_to_folder": {
                      "httpMethod": "POST",
                      "parameters": {
                        "tagId": {
                          "description": "The tags to be moved to the folder.",
                          "type": "string",
                          "repeated": true,
                          "location": "query"
                        },
                        "path": {
                          "type": "string",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/folders/[^/]+$",
                          "description": "GTM Folder's API relative path."
                        },
                        "variableId": {
                          "repeated": true,
                          "location": "query",
                          "type": "string",
                          "description": "The variables to be moved to the folder."
                        },
                        "triggerId": {
                          "type": "string",
                          "description": "The triggers to be moved to the folder.",
                          "location": "query",
                          "repeated": true
                        }
                      },
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "request": {
                        "$ref": "Folder"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.folders.move_entities_to_folder",
                      "path": "tagmanager/v2/{+path}:move_entities_to_folder",
                      "description": "Moves entities to a GTM Folder. If {folder_id} in the request path equals 0, this will instead move entities out of the folder they currently belong to.",
                      "parameterOrder": [
                        "path"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/folders/{foldersId}:move_entities_to_folder"
                    }
                  }
                },
                "triggers": {
                  "methods": {
                    "revert": {
                      "id": "tagmanager.accounts.containers.workspaces.triggers.revert",
                      "parameterOrder": [
                        "path"
                      ],
                      "path": "tagmanager/v2/{+path}:revert",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Reverts changes to a GTM Trigger in a GTM Workspace.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/triggers/{triggersId}:revert",
                      "response": {
                        "$ref": "RevertTriggerResponse"
                      },
                      "httpMethod": "POST",
                      "parameters": {
                        "path": {
                          "description": "GTM Trigger's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/triggers/[^/]+$",
                          "type": "string",
                          "location": "path",
                          "required": true
                        },
                        "fingerprint": {
                          "description": "When provided, this fingerprint must match the fingerprint of the trigger in storage.",
                          "location": "query",
                          "type": "string"
                        }
                      }
                    },
                    "delete": {
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/triggers/{triggersId}",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "httpMethod": "DELETE",
                      "parameters": {
                        "path": {
                          "description": "GTM Trigger's API relative path.",
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/triggers/[^/]+$",
                          "location": "path",
                          "required": true
                        }
                      },
                      "path": "tagmanager/v2/{+path}",
                      "parameterOrder": [
                        "path"
                      ],
                      "description": "Deletes a GTM Trigger.",
                      "id": "tagmanager.accounts.containers.workspaces.triggers.delete"
                    },
                    "get": {
                      "description": "Gets a GTM Trigger.",
                      "path": "tagmanager/v2/{+path}",
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "id": "tagmanager.accounts.containers.workspaces.triggers.get",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/triggers/{triggersId}",
                      "response": {
                        "$ref": "Trigger"
                      },
                      "parameterOrder": [
                        "path"
                      ],
                      "httpMethod": "GET",
                      "parameters": {
                        "path": {
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/triggers/[^/]+$",
                          "description": "GTM Trigger's API relative path.",
                          "type": "string"
                        }
                      }
                    },
                    "create": {
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Creates a GTM Trigger.",
                      "id": "tagmanager.accounts.containers.workspaces.triggers.create",
                      "httpMethod": "POST",
                      "parameters": {
                        "parent": {
                          "description": "GTM Workspace's API relative path.",
                          "location": "path",
                          "required": true,
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "type": "string"
                        }
                      },
                      "parameterOrder": [
                        "parent"
                      ],
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/triggers",
                      "path": "tagmanager/v2/{+parent}/triggers",
                      "request": {
                        "$ref": "Trigger"
                      },
                      "response": {
                        "$ref": "Trigger"
                      }
                    },
                    "update": {
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers"
                      ],
                      "description": "Updates a GTM Trigger.",
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/triggers/{triggersId}",
                      "response": {
                        "$ref": "Trigger"
                      },
                      "id": "tagmanager.accounts.containers.workspaces.triggers.update",
                      "request": {
                        "$ref": "Trigger"
                      },
                      "parameterOrder": [
                        "path"
                      ],
                      "path": "tagmanager/v2/{+path}",
                      "httpMethod": "PUT",
                      "parameters": {
                        "path": {
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "description": "GTM Trigger's API relative path.",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+/triggers/[^/]+$"
                        },
                        "fingerprint": {
                          "type": "string",
                          "description": "When provided, this fingerprint must match the fingerprint of the trigger in storage.",
                          "location": "query"
                        }
                      }
                    },
                    "list": {
                      "httpMethod": "GET",
                      "parameters": {
                        "pageToken": {
                          "location": "query",
                          "type": "string",
                          "description": "Continuation token for fetching the next page of results."
                        },
                        "parent": {
                          "location": "path",
                          "required": true,
                          "type": "string",
                          "pattern": "^accounts/[^/]+/containers/[^/]+/workspaces/[^/]+$",
                          "description": "GTM Workspace's API relative path."
                        }
                      },
                      "path": "tagmanager/v2/{+parent}/triggers",
                      "description": "Lists all GTM Triggers of a Container.",
                      "id": "tagmanager.accounts.containers.workspaces.triggers.list",
                      "parameterOrder": [
                        "parent"
                      ],
                      "scopes": [
                        "https://www.googleapis.com/auth/tagmanager.edit.containers",
                        "https://www.googleapis.com/auth/tagmanager.readonly"
                      ],
                      "response": {
                        "$ref": "ListTriggersResponse"
                      },
                      "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/workspaces/{workspacesId}/triggers"
                    }
                  }
                }
              }
            },
            "environments": {
              "methods": {
                "delete": {
                  "parameterOrder": [
                    "path"
                  ],
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ],
                  "id": "tagmanager.accounts.containers.environments.delete",
                  "httpMethod": "DELETE",
                  "parameters": {
                    "path": {
                      "description": "GTM Environment's API relative path.",
                      "type": "string",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/environments/[^/]+$",
                      "location": "path",
                      "required": true
                    }
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/environments/{environmentsId}",
                  "description": "Deletes a GTM Environment.",
                  "path": "tagmanager/v2/{+path}"
                },
                "list": {
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/environments",
                  "response": {
                    "$ref": "ListEnvironmentsResponse"
                  },
                  "id": "tagmanager.accounts.containers.environments.list",
                  "description": "Lists all GTM Environments of a GTM Container.",
                  "httpMethod": "GET",
                  "parameters": {
                    "pageToken": {
                      "location": "query",
                      "description": "Continuation token for fetching the next page of results.",
                      "type": "string"
                    },
                    "parent": {
                      "type": "string",
                      "pattern": "^accounts/[^/]+/containers/[^/]+$",
                      "location": "path",
                      "required": true,
                      "description": "GTM Container's API relative path."
                    }
                  },
                  "path": "tagmanager/v2/{+parent}/environments",
                  "parameterOrder": [
                    "parent"
                  ],
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ]
                },
                "reauthorize": {
                  "response": {
                    "$ref": "Environment"
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/environments/{environmentsId}:reauthorize",
                  "description": "Re-generates the authorization code for a GTM Environment.",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.publish"
                  ],
                  "parameterOrder": [
                    "path"
                  ],
                  "id": "tagmanager.accounts.containers.environments.reauthorize",
                  "request": {
                    "$ref": "Environment"
                  },
                  "path": "tagmanager/v2/{+path}:reauthorize",
                  "httpMethod": "POST",
                  "parameters": {
                    "path": {
                      "description": "GTM Environment's API relative path.",
                      "type": "string",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/environments/[^/]+$",
                      "location": "path",
                      "required": true
                    }
                  }
                },
                "update": {
                  "path": "tagmanager/v2/{+path}",
                  "request": {
                    "$ref": "Environment"
                  },
                  "httpMethod": "PUT",
                  "parameters": {
                    "fingerprint": {
                      "description": "When provided, this fingerprint must match the fingerprint of the environment in storage.",
                      "type": "string",
                      "location": "query"
                    },
                    "path": {
                      "type": "string",
                      "description": "GTM Environment's API relative path.",
                      "location": "path",
                      "required": true,
                      "pattern": "^accounts/[^/]+/containers/[^/]+/environments/[^/]+$"
                    }
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ],
                  "description": "Updates a GTM Environment.",
                  "id": "tagmanager.accounts.containers.environments.update",
                  "response": {
                    "$ref": "Environment"
                  },
                  "parameterOrder": [
                    "path"
                  ],
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/environments/{environmentsId}"
                },
                "get": {
                  "id": "tagmanager.accounts.containers.environments.get",
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/environments/{environmentsId}",
                  "httpMethod": "GET",
                  "parameters": {
                    "path": {
                      "type": "string",
                      "location": "path",
                      "required": true,
                      "description": "GTM Environment's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/environments/[^/]+$"
                    }
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ],
                  "parameterOrder": [
                    "path"
                  ],
                  "response": {
                    "$ref": "Environment"
                  },
                  "description": "Gets a GTM Environment.",
                  "path": "tagmanager/v2/{+path}"
                },
                "create": {
                  "id": "tagmanager.accounts.containers.environments.create",
                  "description": "Creates a GTM Environment.",
                  "request": {
                    "$ref": "Environment"
                  },
                  "response": {
                    "$ref": "Environment"
                  },
                  "httpMethod": "POST",
                  "parameters": {
                    "parent": {
                      "location": "path",
                      "required": true,
                      "type": "string",
                      "description": "GTM Container's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+$"
                    }
                  },
                  "parameterOrder": [
                    "parent"
                  ],
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/environments",
                  "path": "tagmanager/v2/{+parent}/environments",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ]
                }
              }
            },
            "versions": {
              "methods": {
                "delete": {
                  "id": "tagmanager.accounts.containers.versions.delete",
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/versions/{versionsId}",
                  "parameterOrder": [
                    "path"
                  ],
                  "description": "Deletes a Container Version.",
                  "path": "tagmanager/v2/{+path}",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containerversions"
                  ],
                  "httpMethod": "DELETE",
                  "parameters": {
                    "path": {
                      "location": "path",
                      "required": true,
                      "type": "string",
                      "description": "GTM ContainerVersion's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/versions/[^/]+$"
                    }
                  }
                },
                "undelete": {
                  "id": "tagmanager.accounts.containers.versions.undelete",
                  "path": "tagmanager/v2/{+path}:undelete",
                  "httpMethod": "POST",
                  "parameters": {
                    "path": {
                      "type": "string",
                      "location": "path",
                      "required": true,
                      "description": "GTM ContainerVersion's API relative path.",
                      "pattern": "^accounts/[^/]+/containers/[^/]+/versions/[^/]+$"
                    }
                  },
                  "description": "Undeletes a Container Version.",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containerversions"
                  ],
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/versions/{versionsId}:undelete",
                  "parameterOrder": [
                    "path"
                  ],
                  "response": {
                    "$ref": "ContainerVersion"
                  }
                },
                "update": {
                  "id": "tagmanager.accounts.containers.versions.update",
                  "request": {
                    "$ref": "ContainerVersion"
                  },
                  "parameterOrder": [
                    "path"
                  ],
                  "httpMethod": "PUT",
                  "parameters": {
                    "fingerprint": {
                      "location": "query",
                      "type": "string",
                      "description": "When provided, this fingerprint must match the fingerprint of the container version in storage."
                    },
                    "path": {
                      "pattern": "^accounts/[^/]+/containers/[^/]+/versions/[^/]+$",
                      "description": "GTM ContainerVersion's API relative path.",
                      "type": "string",
                      "location": "path",
                      "required": true
                    }
                  },
                  "description": "Updates a Container Version.",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containerversions"
                  ],
                  "response": {
                    "$ref": "ContainerVersion"
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/versions/{versionsId}",
                  "path": "tagmanager/v2/{+path}"
                },
                "set_latest": {
                  "parameterOrder": [
                    "path"
                  ],
                  "path": "tagmanager/v2/{+path}:set_latest",
                  "httpMethod": "POST",
                  "parameters": {
                    "path": {
                      "pattern": "^accounts/[^/]+/containers/[^/]+/versions/[^/]+$",
                      "description": "GTM ContainerVersion's API relative path.",
                      "type": "string",
                      "location": "path",
                      "required": true
                    }
                  },
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/versions/{versionsId}:set_latest",
                  "description": "Sets the latest version used for synchronization of workspaces when detecting conflicts and errors.",
                  "response": {
                    "$ref": "ContainerVersion"
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers"
                  ],
                  "id": "tagmanager.accounts.containers.versions.set_latest"
                },
                "publish": {
                  "path": "tagmanager/v2/{+path}:publish",
                  "id": "tagmanager.accounts.containers.versions.publish",
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/versions/{versionsId}:publish",
                  "parameterOrder": [
                    "path"
                  ],
                  "description": "Publishes a Container Version.",
                  "response": {
                    "$ref": "PublishContainerVersionResponse"
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.publish"
                  ],
                  "httpMethod": "POST",
                  "parameters": {
                    "fingerprint": {
                      "description": "When provided, this fingerprint must match the fingerprint of the container version in storage.",
                      "type": "string",
                      "location": "query"
                    },
                    "path": {
                      "pattern": "^accounts/[^/]+/containers/[^/]+/versions/[^/]+$",
                      "type": "string",
                      "description": "GTM ContainerVersion's API relative path.",
                      "location": "path",
                      "required": true
                    }
                  }
                },
                "get": {
                  "parameterOrder": [
                    "path"
                  ],
                  "description": "Gets a Container Version.",
                  "httpMethod": "GET",
                  "parameters": {
                    "containerVersionId": {
                      "location": "query",
                      "description": "The GTM ContainerVersion ID. Specify published to retrieve the currently published version.",
                      "type": "string"
                    },
                    "path": {
                      "type": "string",
                      "description": "GTM ContainerVersion's API relative path.",
                      "location": "path",
                      "required": true,
                      "pattern": "^accounts/[^/]+/containers/[^/]+/versions/[^/]+$"
                    }
                  },
                  "path": "tagmanager/v2/{+path}",
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.edit.containerversions",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ],
                  "id": "tagmanager.accounts.containers.versions.get",
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/versions/{versionsId}",
                  "response": {
                    "$ref": "ContainerVersion"
                  }
                },
                "live": {
                  "id": "tagmanager.accounts.containers.versions.live",
                  "parameterOrder": [
                    "parent"
                  ],
                  "flatPath": "tagmanager/v2/accounts/{accountsId}/containers/{containersId}/versions:live",
                  "description": "Gets the live (i.e. published) container version",
                  "path": "tagmanager/v2/{+parent}/versions:live",
                  "response": {
                    "$ref": "ContainerVersion"
                  },
                  "httpMethod": "GET",
                  "parameters": {
                    "parent": {
                      "description": "GTM Container's API relative path.",
                      "location": "path",
                      "required": true,
                      "pattern": "^accounts/[^/]+/containers/[^/]+$",
                      "type": "string"
                    }
                  },
                  "scopes": [
                    "https://www.googleapis.com/auth/tagmanager.edit.containers",
                    "https://www.googleapis.com/auth/tagmanager.readonly"
                  ]
                }
              }
            }
          }
        },
        "user_permissions": {
          "methods": {
            "list": {
              "httpMethod": "GET",
              "parameters": {
                "parent": {
                  "location": "path",
                  "required": true,
                  "description": "GTM Account's API relative path.",
                  "pattern": "^accounts/[^/]+$",
                  "type": "string"
                },
                "pageToken": {
                  "description": "Continuation token for fetching the next page of results.",
                  "type": "string",
                  "location": "query"
                }
              },
              "parameterOrder": [
                "parent"
              ],
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.manage.users"
              ],
              "flatPath": "tagmanager/v2/accounts/{accountsId}/user_permissions",
              "id": "tagmanager.accounts.user_permissions.list",
              "response": {
                "$ref": "ListUserPermissionsResponse"
              },
              "path": "tagmanager/v2/{+parent}/user_permissions",
              "description": "List all users that have access to the account along with Account and Container user access granted to each of them."
            },
            "delete": {
              "flatPath": "tagmanager/v2/accounts/{accountsId}/user_permissions/{user_permissionsId}",
              "path": "tagmanager/v2/{+path}",
              "parameterOrder": [
                "path"
              ],
              "id": "tagmanager.accounts.user_permissions.delete",
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.manage.users"
              ],
              "description": "Removes a user from the account, revoking access to it and all of its containers.",
              "httpMethod": "DELETE",
              "parameters": {
                "path": {
                  "pattern": "^accounts/[^/]+/user_permissions/[^/]+$",
                  "description": "GTM UserPermission's API relative path.",
                  "location": "path",
                  "required": true,
                  "type": "string"
                }
              }
            },
            "create": {
              "description": "Creates a user's Account & Container access.",
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.manage.users"
              ],
              "id": "tagmanager.accounts.user_permissions.create",
              "path": "tagmanager/v2/{+parent}/user_permissions",
              "flatPath": "tagmanager/v2/accounts/{accountsId}/user_permissions",
              "response": {
                "$ref": "UserPermission"
              },
              "parameterOrder": [
                "parent"
              ],
              "httpMethod": "POST",
              "parameters": {
                "parent": {
                  "description": "GTM Account's API relative path.",
                  "location": "path",
                  "required": true,
                  "pattern": "^accounts/[^/]+$",
                  "type": "string"
                }
              },
              "request": {
                "$ref": "UserPermission"
              }
            },
            "update": {
              "httpMethod": "PUT",
              "parameters": {
                "path": {
                  "pattern": "^accounts/[^/]+/user_permissions/[^/]+$",
                  "location": "path",
                  "required": true,
                  "type": "string",
                  "description": "GTM UserPermission's API relative path."
                }
              },
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.manage.users"
              ],
              "response": {
                "$ref": "UserPermission"
              },
              "flatPath": "tagmanager/v2/accounts/{accountsId}/user_permissions/{user_permissionsId}",
              "request": {
                "$ref": "UserPermission"
              },
              "parameterOrder": [
                "path"
              ],
              "id": "tagmanager.accounts.user_permissions.update",
              "description": "Updates a user's Account & Container access.",
              "path": "tagmanager/v2/{+path}"
            },
            "get": {
              "httpMethod": "GET",
              "parameters": {
                "path": {
                  "pattern": "^accounts/[^/]+/user_permissions/[^/]+$",
                  "description": "GTM UserPermission's API relative path.",
                  "location": "path",
                  "required": true,
                  "type": "string"
                }
              },
              "id": "tagmanager.accounts.user_permissions.get",
              "description": "Gets a user's Account & Container access.",
              "flatPath": "tagmanager/v2/accounts/{accountsId}/user_permissions/{user_permissionsId}",
              "parameterOrder": [
                "path"
              ],
              "response": {
                "$ref": "UserPermission"
              },
              "path": "tagmanager/v2/{+path}",
              "scopes": [
                "https://www.googleapis.com/auth/tagmanager.manage.users"
              ]
            }
          }
        }
      },
      "methods": {
        "get": {
          "id": "tagmanager.accounts.get",
          "path": "tagmanager/v2/{+path}",
          "parameterOrder": [
            "path"
          ],
          "description": "Gets a GTM Account.",
          "httpMethod": "GET",
          "parameters": {
            "path": {
              "type": "string",
              "location": "path",
              "required": true,
              "description": "GTM Account's API relative path.",
              "pattern": "^accounts/[^/]+$"
            }
          },
          "flatPath": "tagmanager/v2/accounts/{accountsId}",
          "scopes": [
            "https://www.googleapis.com/auth/tagmanager.edit.containers",
            "https://www.googleapis.com/auth/tagmanager.manage.accounts",
            "https://www.googleapis.com/auth/tagmanager.readonly"
          ],
          "response": {
            "$ref": "Account"
          }
        },
        "list": {
          "flatPath": "tagmanager/v2/accounts",
          "scopes": [
            "https://www.googleapis.com/auth/tagmanager.edit.containers",
            "https://www.googleapis.com/auth/tagmanager.manage.accounts",
            "https://www.googleapis.com/auth/tagmanager.readonly"
          ],
          "response": {
            "$ref": "ListAccountsResponse"
          },
          "httpMethod": "GET",
          "parameters": {
            "includeGoogleTags": {
              "type": "boolean",
              "description": "Also retrieve accounts associated with Google Tag when true.",
              "location": "query"
            },
            "pageToken": {
              "location": "query",
              "description": "Continuation token for fetching the next page of results.",
              "type": "string"
            }
          },
          "parameterOrder": [],
          "id": "tagmanager.accounts.list",
          "path": "tagmanager/v2/accounts",
          "description": "Lists all GTM Accounts that a user has access to."
        },
        "update": {
          "scopes": [
            "https://www.googleapis.com/auth/tagmanager.manage.accounts"
          ],
          "description": "Updates a GTM Account.",
          "parameterOrder": [
            "path"
          ],
          "flatPath": "tagmanager/v2/accounts/{accountsId}",
          "response": {
            "$ref": "Account"
          },
          "httpMethod": "PUT",
          "parameters": {
            "fingerprint": {
              "location": "query",
              "description": "When provided, this fingerprint must match the fingerprint of the account in storage.",
              "type": "string"
            },
            "path": {
              "description": "GTM Account's API relative path.",
              "type": "string",
              "location": "path",
              "required": true,
              "pattern": "^accounts/[^/]+$"
            }
          },
          "id": "tagmanager.accounts.update",
          "path": "tagmanager/v2/{+path}",
          "request": {
            "$ref": "Account"
          }
        }
      }
    }
  },
  "revision": "20260928",
  "baseUrl": "https://tagmanager.googleapis.com/"
}
F3_GTM_DISCOVERY
	,
	true
);
