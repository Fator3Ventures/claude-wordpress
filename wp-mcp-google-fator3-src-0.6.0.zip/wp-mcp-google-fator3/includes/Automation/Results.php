<?php
/**
 * Job items are independent records: pagination does not load preceding results.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{
	Records, Storage\Migration, Storage\Repository
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Results {

	public static function id( string $job, int $index ): string {
		return hash( 'sha256', $job ) . '_' . sprintf( '%06d', $index );
	}
	public static function put( string $job, int $index, array $result ): array {
		return Records::put(
			'item',
			self::id( $job, $index ),
			array(
				'task'       => $job,
				'index'      => $index,
				'result'     => $result,
				'created_at' => time(),
			)
		);
	}
	public static function page( string $job, int $offset, int $limit ): array {
		$out = array();
		for ( $i = $offset;$i < $offset + $limit;++$i ) {
			$record = Records::get( 'item', self::id( $job, $i ) );
			if ( null === $record ) {
				break;
			}
			$out[] = $record['result'];
		}
		return $out;
	}
	public static function chunk_id( string $job, string $field, int $chunk ): string {
		return hash( 'sha256', $job . '|' . $field ) . '_' . sprintf( '%06d', $chunk );
	}
	/** Split table rows before persisting the job. Each chunk is fetched independently. */
	public static function externalize( array &$job ): array {
		$records = array();
		foreach ( array( 'rows', 'page_changes' ) as $field ) {
			if ( ! isset( $job['result'][ $field ] ) || ! is_array( $job['result'][ $field ] ) ) {
				continue;
			}
			$rows                          = array_values( $job['result'][ $field ] );
			$job['result_pages'][ $field ] = array(
				'count'      => count( $rows ),
				'chunk_size' => 100,
			);
			foreach ( array_chunk( $rows, 100 ) as $index => $values ) {
				$records[ self::chunk_id( $job['id'], $field, $index ) ] = array(
					'task'          => $job['id'],
					'field'         => $field,
					'index'         => $index,
					'rows'          => $values,
					'connection_id' => $job['connection_id'] ?? 'default',
					'created_at'    => $job['updated_at'] ?? $job['created_at'] ?? 0,
				);
			}
			unset( $job['result'][ $field ] );
		}
		return $records;
	}
	public static function rows( array $job, string $field, int $offset, int $limit ): array {
		$meta = $job['result_pages'][ $field ] ?? null;
		if ( null === $meta ) {
			return array_slice( $job['result'][ $field ] ?? array(), $offset, $limit );
		}
		$end = min( $meta['count'], $offset + $limit );
		$out = array();
		for ( $cursor = $offset;$cursor < $end; ) {
			$chunk  = (int) floor( $cursor / $meta['chunk_size'] );
			$record = Records::get( 'result', self::chunk_id( $job['id'], $field, $chunk ) );
			if ( null === $record || ! isset( $record['rows'] ) ) {
				throw new \RuntimeException( 'f3_google_result_missing' );
			}
			$within = $cursor % $meta['chunk_size'];
			$take   = min( $end - $cursor, $meta['chunk_size'] - $within );
			$slice  = array_slice( $record['rows'], $within, $take );
			if ( count( $slice ) !== $take ) {
				throw new \RuntimeException( 'f3_google_result_incomplete' );
			}
			$out     = array_merge( $out, $slice );
			$cursor += $take;
		}
		return $out;
	}
}
