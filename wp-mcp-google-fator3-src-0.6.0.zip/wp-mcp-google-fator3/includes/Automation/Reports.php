<?php
/**
 * Reusable report definitions and numerical monitoring without causal claims.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{
	Ability, Connections, Options, Response, Unified\DateRange, Unified\Query
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Reports {

	private static function queries(): array {
		return array(
			'traffic'            => array(
				'connector'  => 'ga4',
				'metrics'    => array( 'sessions', 'activeUsers' ),
				'dimensions' => array( 'date' ),
			),
			'organic-pages'      => array(
				'connector'  => 'search-console',
				'metrics'    => array( 'clicks', 'impressions', 'ctr', 'position' ),
				'dimensions' => array( 'page' ),
			),
			'organic-queries'    => array(
				'connector'  => 'search-console',
				'metrics'    => array( 'clicks', 'impressions', 'ctr', 'position' ),
				'dimensions' => array( 'query' ),
			),
			'organic-page-drops' => array(
				'connector'          => 'search-console',
				'metrics'            => array( 'clicks', 'impressions', 'ctr', 'position' ),
				'dimensions'         => array( 'page' ),
				'compare_date_range' => 'previous_period',
			),
			'low-ctr-queries'    => array(
				'connector'  => 'search-console',
				'metrics'    => array( 'clicks', 'impressions', 'ctr', 'position' ),
				'dimensions' => array( 'query' ),
				'filters'    => array(
					array(
						'field'    => 'impressions',
						'operator' => 'gte',
						'value'    => 100,
					),
					array(
						'field'    => 'ctr',
						'operator' => 'lt',
						'value'    => 0.02,
					),
				),
			),
			'campaigns'          => array(
				'connector'  => 'google-ads',
				'metrics'    => array( 'clicks', 'impressions', 'cost', 'conversions' ),
				'dimensions' => array( 'campaign_name' ),
			),
		);
	}
	public static function templates(): array {
		$descriptions = array(
			'traffic'            => 'Sessões e usuários ativos por dia no Analytics.',
			'organic-pages'      => 'Cliques, impressões, CTR e posição por página no Search Console.',
			'organic-queries'    => 'Consultas de pesquisa e seu desempenho orgânico.',
			'organic-page-drops' => 'Variação de cliques por página em relação ao período anterior, sem atribuição causal.',
			'low-ctr-queries'    => 'Consultas com pelo menos 100 impressões e CTR abaixo de 2%.',
			'campaigns'          => 'Cliques, impressões, custo e conversões por campanha no Ads.',
		);
		$out          = array();
		foreach ( self::queries() as $id => $query ) {
			$metrics    = array(
				'ga4'            => array( 'sessions' ),
				'search-console' => array( 'clicks', 'impressions' ),
				'google-ads'     => array( 'clicks', 'impressions', 'cost', 'conversions' ),
			)[ $query['connector'] ];
			$out[ $id ] = $query + array(
				'description'                => $descriptions[ $id ],
				'default_date_range'         => 'last_28_days',
				'default_compare_date_range' => $query['compare_date_range'] ?? null,
				'limit'                      => 1000,
				'alert_schema'               => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'required'             => array( 'metric' ),
					'properties'           => array(
						'metric'           => array(
							'type' => 'string',
							'enum' => $metrics,
						),
						'minimum_baseline' => array(
							'type'    => 'number',
							'minimum' => 1,
							'default' => 10,
						),
						'drop_percent'     => array(
							'type'    => 'number',
							'minimum' => 1,
							'maximum' => 100,
							'default' => 30,
						),
					),
				),
				'overrides'                  => array( 'accounts', 'date_range', 'compare', 'compare_date_range', 'alert' ),
			);
		}
		return $out;
	}
	/** The catalog and execution use the same defaults; metadata never enters a query. */
	public static function definition( array $input ) {
		$id       = $input['template'] ?? 'traffic';
		$template = self::templates()[ $id ] ?? null;
		if ( null === $template ) {
			return new \WP_Error( 'f3_google_report_template', 'Modelo desconhecido.' );
		}
		$query               = self::queries()[ $id ];
		$query['date_range'] = $input['date_range'] ?? $template['default_date_range'];
		$query['limit']      = $template['limit'];
		if ( array_key_exists( 'compare', $input ) ) {
			if ( ! is_bool( $input['compare'] ) ) {
				return new \WP_Error( 'f3_google_report_compare', 'compare deve ser booleano.' );
			}
			if ( $input['compare'] ) {
				$query['compare_date_range'] = 'previous_period';
			} else {
				unset( $query['compare_date_range'] );
			}
		}
		if ( isset( $input['compare_date_range'] ) ) {
			$query['compare_date_range'] = $input['compare_date_range'];
		}
		if ( isset( $input['alert'] ) ) {
			$rule   = $input['alert'];
			$schema = $template['alert_schema']['properties'];
			if ( ! is_array( $rule ) || array_diff( array_keys( $rule ), array_keys( $schema ) ) || ! in_array( $rule['metric'] ?? '', $schema['metric']['enum'], true ) ) {
				return new \WP_Error( 'f3_google_report_alert', 'Regra ou métrica de comparação inválida; consulte report-templates.' );
			}
			foreach ( array( 'minimum_baseline', 'drop_percent' ) as $key ) {
				$value = $rule[ $key ] ?? $schema[ $key ]['default'];
				if ( ( ! is_int( $value ) && ! is_float( $value ) ) || ! is_finite( (float) $value ) || $value < $schema[ $key ]['minimum'] || ( isset( $schema[ $key ]['maximum'] ) && $value > $schema[ $key ]['maximum'] ) ) {
					return new \WP_Error( 'f3_google_report_alert', 'Limiar fora dos limites publicados.' );
				}
			}
		}
		return $query;
	}
	public static function run( array $input ): array {
		$template = self::definition( $input );
		if ( is_wp_error( $template ) ) {
			return Response::fail( $template );
		}
		$bindings = (array) Options::get( Connections::BINDINGS, array() );
		$key      = array(
			'ga4'            => 'ga_property_id',
			'search-console' => 'gsc_site_url',
			'google-ads'     => 'ads_customer_id',
		)[ $template['connector'] ];
		$accounts = $input['accounts'] ?? ( ! empty( $bindings[ $key ] ) ? array( $bindings[ $key ] ) : array() );
		if ( ! is_array( $accounts ) || ! $accounts ) {
			return Response::fail( new \WP_Error( 'f3_google_report_account', 'Informe accounts ou configure o recurso padrão.' ) );
		}
		$query                          = $template + array( 'accounts' => $accounts );
		$result                         = Query::run( $query );
		$result['template']             = $input['template'] ?? 'traffic';
		$result['fetched_at']           = gmdate( 'c' );
		$result['comparison_semantics'] = 'Períodos e métricas mantêm as definições do serviço; variação não determina causa.';
		if ( 'organic-page-drops' === ( $input['template'] ?? '' ) && ! empty( $result['success'] ) ) {
			$result['page_changes'] = self::page_changes( $result );
		}
		$result['connection_id'] = Connections::id();
		if ( ! empty( $input['alert'] ) ) {
			$result['monitor'] = self::monitor( $query, $input['alert'] );
		}
		return $result;
	}
	private static function page_changes( array $table ): array {
		$ids = array_flip( array_column( $table['columns'], 'id' ) );
		if ( ! isset( $ids['page'], $ids['clicks'], $ids['date_range_name'] ) ) {
			return array();
		}
		$groups = array();
		foreach ( $table['rows'] as $row ) {
			$page                       = $row[ $ids['page'] ];
			$period                     = $row[ $ids['date_range_name'] ];
			$groups[ $page ][ $period ] = ( $groups[ $page ][ $period ] ?? 0 ) + $row[ $ids['clicks'] ];
		}
		$out = array();
		foreach ( $groups as $page => $values ) {
			$current  = $values['current'] ?? null;
			$previous = $values['previous'] ?? null;
			$out[]    = array(
				'page'                 => $page,
				'current_clicks'       => $current,
				'previous_clicks'      => $previous,
				'change_percent'       => null !== $current && $previous > 0 ? 100 * ( $current - $previous ) / $previous : null,
				'both_periods_present' => null !== $current && null !== $previous,
			);
		}
		usort( $out, static fn ( $a, $b ) => ( $a['change_percent'] ?? INF ) <=> ( $b['change_percent'] ?? INF ) );
		return $out;
	}
	private static function monitor( array $query, $rule ): array {
		$metric     = is_array( $rule ) ? (string) ( $rule['metric'] ?? '' ) : '';
		$definition = array_values( array_filter( self::templates(), static fn ( $item ) => $item['connector'] === $query['connector'] ) )[0];
		$schema     = $definition['alert_schema']['properties'];
		$allowed    = array( $query['connector'] => $schema['metric']['enum'] );
		if ( ! in_array( $metric, $allowed[ $query['connector'] ], true ) ) {
			return array(
				'evaluated' => false,
				'reason'    => 'Métrica não suportada para comparação aditiva.',
			);
		}
		$range = DateRange::resolve( $query['date_range'] );
		if ( is_wp_error( $range ) ) {
			return array(
				'evaluated' => false,
				'reason'    => 'Período inválido.',
			);
		}
		$prior = DateRange::compare( $range, $query['compare_date_range'] ?? 'previous_period' );
		if ( is_wp_error( $prior ) ) {
			return array(
				'evaluated' => false,
				'reason'    => 'Comparação inválida.',
			);
		}
		unset( $query['compare_date_range'] );
		$query['metrics']    = array( $metric );
		$query['dimensions'] = array();
		$totals              = array();
		$warnings            = array();
		foreach ( array( $range, $prior ) as $period ) {
			$query['date_range'] = array(
				'from' => $period['from'],
				'to'   => $period['to'],
			);
			$table               = Query::run( $query );
			if ( empty( $table['success'] ) || ! empty( $table['truncated'] ) || count( $table['accounts'] ?? array() ) !== count( $query['accounts'] ) ) {
				return array(
					'evaluated' => false,
					'reason'    => 'Dados incompletos ou com ressalvas; consulte o relatório.',
				);
			}
			$warnings = array_merge( $warnings, $table['warnings'] ?? array() );
			$index    = array_search( $metric, array_column( $table['columns'], 'id' ), true );
			if ( false === $index ) {
				return array(
					'evaluated' => false,
					'reason'    => 'Métrica ausente.',
				);
			}
			$totals[] = array_sum( array_column( $table['rows'], $index ) );
		}
		$minimum   = max( 1, (float) ( $rule['minimum_baseline'] ?? $schema['minimum_baseline']['default'] ) );
		$threshold = max( 1, min( 100, (float) ( $rule['drop_percent'] ?? $schema['drop_percent']['default'] ) ) );
		if ( $totals[1] < $minimum ) {
			return array(
				'evaluated' => false,
				'reason'    => 'Base insuficiente.',
				'current'   => $totals[0],
				'previous'  => $totals[1],
			);
		}
		$delta = 100 * ( $totals[0] - $totals[1] ) / $totals[1];
		return array(
			'evaluated'          => true,
			'triggered'          => $delta <= -$threshold,
			'metric'             => $metric,
			'current'            => $totals[0],
			'previous'           => $totals[1],
			'change_percent'     => $delta,
			'threshold_percent'  => $threshold,
			'warnings'           => array_values( array_unique( $warnings ) ),
			'causal_attribution' => null,
		);
	}
	public static function register(): void {
		Ability::register(
			'google/report-templates',
			'any',
			array(
				'label'       => 'Google: modelos de relatório',
				'description' => 'Modelos disponíveis para relatórios e monitoramento.',
				'callback'    => static fn () => Response::ok( array( 'templates' => self::templates() ) ),
			)
		);
		Ability::register(
			'google/run-report',
			'any',
			array(
				'label'        => 'Google: relatório por modelo',
				'description'  => 'Executa modelo com período e comparação opcional. alert avalia queda numérica e não atribui causa.',
				'input_schema' => array(
					'properties' => array(
						'template'           => array(
							'type' => 'string',
							'enum' => array_keys( self::templates() ),
						),
						'accounts'           => array(
							'type'  => 'array',
							'items' => array( 'type' => 'string' ),
						),
						'date_range'         => array( 'type' => array( 'string', 'object' ) ),
						'compare'            => array( 'type' => 'boolean' ),
						'compare_date_range' => array( 'type' => array( 'string', 'object' ) ),
						'alert'              => array(
							'type'                 => 'object',
							'additionalProperties' => false,
							'required'             => array( 'metric' ),
							'properties'           => array(
								'metric'           => array( 'type' => 'string' ),
								'minimum_baseline' => array(
									'type'    => 'number',
									'minimum' => 1,
									'default' => 10,
								),
								'drop_percent'     => array(
									'type'    => 'number',
									'minimum' => 1,
									'maximum' => 100,
									'default' => 30,
								),
							),
						),
					),
				),
				'callback'     => array( self::class, 'run' ),
			)
		);
	}
}
