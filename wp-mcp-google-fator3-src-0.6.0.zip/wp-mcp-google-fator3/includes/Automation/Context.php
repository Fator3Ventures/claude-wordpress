<?php
/**
 * A queued operation never acquires new defaults or another identity silently.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{Auth\Credentials, Connections, Options, Settings};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Context {

	public static function capture() {
		$revision = Settings::execution_revision();
		if ( is_wp_error( $revision ) ) {
			return $revision;
		}
		return array(
			'schema_version'      => '2.0.0',
			'site'                => home_url(),
			'connection_id'       => Connections::id(),
			'actor'               => get_current_user_id(),
			'identity'            => Credentials::execution_identity(),
			'revision'            => $revision,
			'bindings'            => (array) Options::get( Connections::BINDINGS, array() ),
			'ga_default_property' => Options::get( Options::GA_DEFAULT_PROPERTY, '' ),
			'services'            => Options::get( Connections::SERVICES, null ),
			'captured_at'         => time(),
		);
	}
	public static function validate( array $context ): ?\WP_Error {
		$revision = Settings::execution_revision();
		if ( is_wp_error( $revision ) ) {
			return $revision;
		}
		if ( ( $context['site'] ?? null ) !== home_url() || ( $context['connection_id'] ?? null ) !== Connections::id() || ( $context['identity'] ?? null ) !== Credentials::execution_identity() || ( $context['revision'] ?? null ) !== $revision ) {
			return new \WP_Error(
				'f3_google_job_context_changed',
				'Identidade ou política mudaram. Revise a tarefa antes de criar outra intenção.',
				array(
					'operation_outcome' => 'not_applied',
					'retryable'         => false,
				)
			);
		}
		return null;
	}
}
