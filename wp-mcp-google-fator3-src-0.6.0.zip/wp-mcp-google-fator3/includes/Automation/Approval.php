<?php
/**
 * Transfer a prepared export intention to one persisted job.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{Ability, Confirmation, Connections, Gate, Lock, Records, Response, Storage\Migration, Storage\Repository};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Approval {

	public static function action( array $input, bool $approve ): array {
		$gate = Gate::check( 'sheets' );
		if ( null !== $gate ) {
			return $gate;
		}
		$id = (string) ( $input['job_id'] ?? '' );
		if ( ! preg_match( '/^[A-Za-z0-9_-]{1,100}$/D', $id ) ) {
			return Response::fail( new \WP_Error( 'f3_google_job_input', 'job_id inválido.' ) );
		}
		$indexed = Migration::active();
		$lease   = $indexed ? Repository::claim( 'job', $id, 120 ) : Lock::acquire( 'job:' . $id, 120 );
		if ( null === $lease ) {
			return Response::fail( new \WP_Error( 'f3_google_job_busy', 'Job em execução ou alteração.' ) );
		}
		try {
			$job = Records::get( 'job', $id );
			if ( null === $job || Connections::id() !== $job['connection_id'] || get_current_user_id() !== $job['user_id'] ) {
				return Response::fail( new \WP_Error( 'f3_google_job_permission', 'Prepare o job na conexão e com o usuário que o criou.' ) );
			}
			if ( 'export' !== $job['task'] || ! in_array( $job['status'], array( 'approval_required', 'pending' ), true ) ) {
				return Response::fail( new \WP_Error( 'f3_google_job_approval_state', 'Somente uma exportação ainda não despachada pode receber aprovação.' ) );
			}
			$context = Context::validate( $job['context'] ?? array() );
			if ( null !== $context ) {
				return Response::fail( $context );
			}
			if ( ! $approve ) {
				return Confirmation::for_job(
					$id,
					static fn () => Confirmation::prepare(
						array(
							'ability'    => 'google/export-to-sheet',
							'parameters' => $job['parameters'],
						)
					)
				) + array( 'job_id' => $id );
			}
			$delegated = Confirmation::delegate_job( (string) ( $input['approval_token'] ?? '' ), 'google/export-to-sheet', $job['parameters'], $id );
			if ( empty( $delegated['success'] ) ) {
				return $delegated;
			}
			$job['confirmation_record'] = $delegated['confirmation_record'];
			$job['approval']            = array(
				'actor'        => get_current_user_id(),
				'at'           => time(),
				'bound_to_job' => true,
			);
			$job['status']              = 'pending';
			$job['updated_at']          = time();
			$saved                      = $indexed ? Repository::put( 'job', $id, $job, (int) $lease['row']['generation'], $lease['owner'] ) : Records::put( 'job', $id, $job );
			if ( $saved['success'] ) {
				Jobs::schedule_tick();
			}
			return $saved + array(
				'job_id'                  => $id,
				'status'                  => $saved['success'] ? 'pending' : 'approval_not_persisted',
				'remote_writes_performed' => false,
			);
		} finally {
			if ( $indexed ) {
				Repository::release( 'job', $id, $lease['owner'] );
			} else {
				Lock::release( $lease );
			}
		}
	}

	public static function register(): void {
		foreach ( array(
			'prepare-job' => false,
			'approve-job' => true,
		) as $route => $approve ) {
			Ability::register(
				'google/' . $route,
				'any',
				array(
					'label'        => 'Google: ' . $route,
					'description'  => $approve ? 'Vincula uma preparação a um único job de exportação. O token é consumido para delegação e não é armazenado nos parâmetros.' : 'Calcula os efeitos da exportação persistida, sem escrita remota. Retorna confirmation_token para google/approve-job.approval_token.',
					'mode'         => 'write',
					'input_schema' => array(
						'required'   => $approve ? array( 'job_id', 'approval_token' ) : array( 'job_id' ),
						'properties' => array(
							'job_id'         => array( 'type' => 'string' ),
							'approval_token' => array( 'type' => 'string' ),
						),
					),
					'callback'     => static fn ( array $input ) => self::action( $input, $approve ),
				)
			);
		}
	}
}
