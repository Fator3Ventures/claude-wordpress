<?php
/**
 * Due-work service shared by cron, CLI and authenticated agents.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{
	Ability, Connections, Lock, Options, Records, Response, Storage\Migration, Storage\Repository
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Executor {
	public static function run( array $input = array() ): array {
		$connections = ! empty( $input['all_connections'] ) ? array_keys( Connections::registry() ) : array( Connections::id() );
		if ( Migration::paused() ) {
			return Response::fail( new \WP_Error( 'f3_google_storage_paused', 'Fila pausada para migração.' ) );
		}
		$lock = Lock::acquire( 'jobs-tick', 60 );
		if ( null === $lock ) {
			return Response::ok(
				array(
					'executed'          => 0,
					'reason'            => 'executor_busy',
					'operation_outcome' => 'not_applied',
				)
			);
		}
		try {
			return Execution::run(
				static function () use ( $input, $connections ): array {
					$dispatched_at = time();
					foreach ( $connections as $cid ) {
						Connections::run(
							$cid,
							static function () {
								$health = self::status();
								if ( null !== $health['agendas_vencidas'] ) {
									Alerts::observe( 'cron_late', 'executor', ( $health['oldest_delay_seconds'] ?? 0 ) > 300, 'cron_due', 'Dispare o executor por cron externo ou google/executar-vencidos.' );
								}
							}
						);
					}
					$scheduled     = self::dispatch( $connections );
					$count         = 0;
					$seen          = array();
					$worker_errors = array();
					$outcomes      = array();
					$budget        = max( 1, min( 25, (int) ( $input['max_items'] ?? 25 ) ) );
					while ( $count < $budget && Execution::remaining() >= 1 ) {
						$pending = self::due( $connections );
						if ( is_wp_error( $pending ) ) {
							return Response::fail( $pending );
						}
						$progress = false;
						foreach ( $pending as $job ) {
							if ( $count >= $budget || Execution::remaining() < 1 ) {
								break;
							}
							$r                      = Connections::run( $job['connection'], static fn () => Worker::run( $job['id'], 1 ) );
							$outcomes[ $job['id'] ] = $r['operation_outcome'] ?? 'unknown';
							$seen[ $job['id'] ]     = $r['status'] ?? $r['job']['status'] ?? 'unknown';
							if ( empty( $r['success'] ) || in_array( $seen[ $job['id'] ], array( 'failed', 'unknown', 'blocked' ), true ) ) {
								$worker_errors[ $job['id'] ] = $r['error_code'] ?? $r['reason'] ?? $seen[ $job['id'] ];
							}
							if ( ! empty( $r['executed'] ) ) {
								++$count;
								$progress = true;
							}
						}
						if ( ! $progress ) {
							break;
						}
					}
					foreach ( $connections as $connection ) {
						if ( Execution::remaining() < 2 ) {
							break;
						}
						Connections::run( $connection, static fn () => Alerts::dispatch() );
					}
					$imports = array();
					foreach ( $connections as $cid ) {
						if ( Execution::remaining() < 3 ) {
							break;
						}
						$imports[ $cid ] = Connections::run( $cid, static fn () => \Fator3\McpGoogle\SearchConsole\Daily::tick() );
					}
					$state     = array(
						'connections' => $connections,
						'at'          => time(),
						'started_at'  => $dispatched_at,
						'items'       => $count,
						'jobs'        => count( $seen ),
						'reason'      => Execution::remaining() < 1 ? 'deadline' : ( $count >= $budget ? 'item_budget' : 'no_due_work' ),
					);
					$remaining = array();
					$agendas   = 0;
					foreach ( $connections as $cid ) {
						$health            = Connections::run( $cid, static fn () => self::status() );
						$remaining[ $cid ] = array(
							'jobs'              => $health['jobs'] ?? null,
							'agendas_vencidas'  => $health['agendas_vencidas'],
							'blocked_schedules' => $health['blocked_schedules'],
							'read_error'        => $health['read_error'] ?? null,
						);
						$agendas          += (int) $health['agendas_vencidas'];
					}
					$state['success']       = ! in_array( false, array_column( $imports, 'success' ), true ) && ! $worker_errors && ! in_array( false, array_map( static fn ( $r ) => is_array( $r ) && ! empty( $r['success'] ), $scheduled ), true );
					$state['worker_errors'] = $worker_errors;
					$saved                  = array( 'success' => true );
					foreach ( $connections as $cid ) {
						$one = Options::set( 'f3_mcp_google_executor_last_' . $cid, $state );
						if ( ! $one['success'] ) {
							$saved = $one;
						}
						if ( $state['success'] ) {
							$last = Options::set( 'f3_mcp_google_executor_success_' . $cid, $state['at'] );
							if ( ! $last['success'] ) {
								$saved = $last;
							}
						}
					}
					return $saved['success'] ? Response::ok(
						array(
							'gsc_imports'       => $imports,
							'executed'          => $count,
							'operation_outcome' => \Fator3\McpGoogle\Operation::aggregate( $outcomes ),
							'job_outcomes'      => $outcomes,
							'jobs'              => $seen,
							'schedules'         => $scheduled,
							'pass'              => $state,
							'agendas_vencidas'  => $agendas,
							'work_remaining'    => $remaining,
						)
					) : $saved;
				}
			);
		} finally {
			Lock::release( $lock );
		}
	}
	private static function due( array $connections ) {
		if ( Migration::active() ) {
			$out = array();
			foreach ( $connections as $connection ) {
				$rows = Repository::eligible( 25, $connection );
				if ( is_wp_error( $rows ) ) {
					return $rows;
				}
				foreach ( $rows as $row ) {
					$out[] = array(
						'id'         => $row['record_id'],
						'connection' => $row['connection_id'],
						'priority'   => (int) $row['priority'],
						'due'        => (int) $row['due_at'],
					);
				}
			}
		} else {
			$out = array();
			foreach ( Records::list( 'job', 1000, false ) as $id => $job ) {
				if ( in_array( $job['status'], array( 'pending', 'running', 'dispatching' ), true ) && $job['run_after'] <= time() ) {
					$out[] = array(
						'id'         => $id,
						'connection' => $job['connection_id'],
						'priority'   => $job['priority'],
						'due'        => $job['run_after'],
					);
				}
			}
		}
		$out = array_values( array_filter( $out, static fn ( $job ) => in_array( $job['connection'], $connections, true ) ) );
		usort(
			$out,
			static function ( $a, $b ) {
				$due = $a['due'] <=> $b['due'];
				return 0 !== $due ? $due : ( $b['priority'] <=> $a['priority'] );
			}
		);
		// Interleave connections; each job advances once before any job repeats.
		$groups = array();
		foreach ( $out as $job ) {
			$groups[ $job['connection'] ][] = $job;
		}
		$fair = array();
		while ( $groups ) {
			foreach ( $groups as $connection => &$jobs ) {
				$fair[] = array_shift( $jobs );
				if ( ! $jobs ) {
					unset( $groups[ $connection ] );
				}
			}
			unset( $jobs );
		}
		return $fair;
	}
	private static function dispatch( array $connections ): array {
		$lock = Lock::acquire( 'schedules', 60 );
		if ( null === $lock ) {
			return array(
				'_executor' => array(
					'success'    => false,
					'error_code' => 'f3_google_schedules_busy',
				),
			);
		}
		$out = array();
		try {
			$rows = null;
			if ( Migration::active() ) {
				$rows = array();
				foreach ( $connections as $connection ) {
					$selected = Repository::select(
						'schedule',
						array(
							'connection_id' => $connection,
							'state'         => 'enabled',
							'due_before'    => time(),
						),
						100,
						0,
						false
					);
					if ( is_wp_error( $selected ) ) {
						return array(
							'_executor' => array(
								'success'    => false,
								'error_code' => $selected->get_error_code(),
							),
						);
					}
					$rows = array_merge( $rows, $selected );
				}
			}
			$ids = null !== $rows ? array_column( $rows, 'record_id' ) : Records::ids( 'schedule', 100 );
			foreach ( $ids as $id ) {
				if ( Execution::remaining() < 1 ) {
					break;
				}
				$schedule = Records::get( 'schedule', $id );
				if ( ! in_array( $schedule['connection_id'], $connections, true ) || empty( $schedule['enabled'] ) || isset( $schedule['blocked_reason'] ) || $schedule['next_run'] > time() ) {
					continue;
				}
				$actor = get_current_user_id();
				try {
					wp_set_current_user( (int) $schedule['user_id'] );
					$created = Connections::run(
						$schedule['connection_id'],
						static function () use ( $schedule, $id ): array {
							if ( ! user_can( $schedule['user_id'], Options::capability() ) || ! isset( $schedule['context'] ) ) {
								return Response::fail( new \WP_Error( 'f3_google_schedule_blocked', 'Agenda exige revisão de autorização/contexto.' ) );
							}
							$changed = Context::validate( $schedule['context'] );
							if ( null !== $changed ) {
								return Response::fail( $changed );
							}
							return Jobs::create(
								array(
									'task'            => $schedule['task'],
									'parameters'      => $schedule['parameters'],
									'idempotency_key' => 'schedule:' . $id . ':' . $schedule['next_run'],
								)
							);
						}
					);
				} finally {
					wp_set_current_user( $actor );
				}
				if ( ! empty( $created['success'] ) ) {
					$schedule['last_job_id'] = $created['job_id'];
					$schedule['next_run']    = time() + $schedule['interval_seconds'];
				} else {
					$schedule['status']         = 'blocked';
					$schedule['blocked_reason'] = $created['error_code'] ?? 'dispatch_failed';
				}
				$saved      = Records::put( 'schedule', $id, $schedule );
				$out[ $id ] = $saved['success'] ? $created : $saved;
			}
		} finally {
			Lock::release( $lock );
		}
		return $out;
	}
	public static function status(): array {
		$base = array(
			'executor'                 => 'wp-cron',
			'requires_trigger'         => true,
			'disabled_builtin_trigger' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
			'next_run'                 => function_exists( 'wp_next_scheduled' ) ? wp_next_scheduled( Jobs::HOOK ) : null,
			'observed_at'              => time(),
			'last_pass'                => get_option( 'f3_mcp_google_executor_last_' . Connections::id(), null ),
			'last_success'             => get_option( 'f3_mcp_google_executor_success_' . Connections::id(), null ),
			'schedule_observation'     => get_option( 'f3_mcp_google_cron_schedule', null ),
			'connection_id'            => Connections::id(),
			'agendas_vencidas'         => null,
			'blocked_schedules'        => null,
			'oldest_due_at'            => null,
			'oldest_delay_seconds'     => null,
			'storage'                  => Migration::state(),
		);
		try {
			$due     = 0;
			$blocked = 0;
			$oldest  = null;
			if ( Migration::active() ) {
				foreach ( array( 'enabled', 'blocked' ) as $state ) {
					$filters = array(
						'connection_id' => Connections::id(),
						'state'         => $state,
						'due_before'    => time(),
					);
					$n       = Repository::count_filtered( 'schedule', $filters );
					if ( is_wp_error( $n ) ) {
						return $base + array( 'read_error' => $n->get_error_code() );
					}
					$due += $n;
					if ( 'blocked' === $state ) {
						$blocked = $n;
					}
					$rows = Repository::select( 'schedule', $filters, 10000 );
					if ( is_wp_error( $rows ) ) {
						return $base + array( 'read_error' => $rows->get_error_code() );
					}
					foreach ( $rows as $row ) {
						$oldest = null === $oldest ? (int) $row['due_at'] : min( $oldest, (int) $row['due_at'] );
					}
				}
				$counts = array();
				foreach ( array( 'pending', 'approval_required', 'running', 'dispatching', 'blocked', 'unknown', 'failed', 'completed' ) as $state ) {
					$n = Repository::count_filtered(
						'job',
						array(
							'connection_id' => Connections::id(),
							'state'         => $state,
						)
					);
					if ( is_wp_error( $n ) ) {
						return $base + array( 'read_error' => $n->get_error_code() );
					}
					$counts[ $state ] = $n;
				}
				$base['jobs']                  = $counts;
				$base['execution_in_progress'] = ( $counts['running'] + $counts['dispatching'] ) > 0;
			} else {
				foreach ( Records::list( 'schedule', 1000 ) as $schedule ) {
					if ( ( $schedule['connection_id'] ?? 'default' ) !== Connections::id() || empty( $schedule['enabled'] ) || $schedule['next_run'] > time() ) {
						continue;
					}
					++$due;
					if ( isset( $schedule['blocked_reason'] ) ) {
						++$blocked;
					}
					$oldest = null === $oldest ? $schedule['next_run'] : min( $oldest, $schedule['next_run'] );
				}
			}
			$daily = \Fator3\McpGoogle\SearchConsole\Daily::status();
			if ( ! empty( $daily['due'] ) ) {
				++$due;
				$oldest = null === $oldest ? (int) ( $daily['next_run'] ?? time() ) : min( $oldest, (int) ( $daily['next_run'] ?? time() ) );
				if ( 'failed' === $daily['status'] ) {
					++$blocked;
				}
			}
			$base['gsc_import_due']       = $daily['due'];
			$base['agendas_vencidas']     = $due;
			$base['blocked_schedules']    = $blocked;
			$base['oldest_due_at']        = $oldest;
			$base['oldest_delay_seconds'] = null === $oldest ? 0 : max( 0, time() - $oldest );
			$base['health']               = $due ? ( $blocked === $due ? 'blocked' : 'due' ) : 'idle';
		} catch ( \Throwable $e ) {
			$base['read_error'] = 'f3_google_repository_read';
		}
		return $base;
	}
	public static function cleanup( array $input = array() ): array {
		if ( ! Migration::active() ) {
			return Response::fail( new \WP_Error( 'f3_google_storage_migration', 'Limpeza exige repositório indexado.' ) );
		}
		if ( $input['dry_run'] ?? true ) {
			$candidates = array();
			foreach ( array( 'completed', 'failed', 'cancelled', 'reconciled' ) as $state ) {
				$rows = Repository::select(
					'job',
					array(
						'connection_id'  => Connections::id(),
						'state'          => $state,
						'expires_before' => time(),
					),
					100,
					0,
					false
				);
				if ( is_wp_error( $rows ) ) {
					return Response::fail( $rows );
				}
				foreach ( $rows as $row ) {
					if ( (int) $row['expires_at'] > 0 ) {
						$candidates[] = array(
							'job_id'     => $row['record_id'],
							'status'     => $row['state'],
							'expires_at' => (int) $row['expires_at'],
						);
					}
				}
			}
			return Response::ok(
				array(
					'dry_run'                      => true,
					'connection_id'                => Connections::id(),
					'job_candidates'               => $candidates,
					'removed_records'              => 0,
					'max_records_per_pass'         => 100,
					'final_eligibility_rechecked'  => true,
					'unknown_and_active_preserved' => true,
					'auxiliary_cleanup'            => 'Expired summaries, deduplication, telemetry, quotas and resolved confirmations are checked during execution.',
				)
			);
		}
		$removed = 0;
		$jobs    = 0;
		foreach ( array( 'completed', 'failed', 'cancelled', 'reconciled' ) as $state ) {
			$rows = Repository::select(
				'job',
				array(
					'connection_id'  => Connections::id(),
					'state'          => $state,
					'expires_before' => time(),
				),
				100,
				0,
				false
			);
			if ( is_wp_error( $rows ) ) {
				return Response::fail( $rows );
			}
			foreach ( $rows as $row ) {
				if ( $removed >= 100 ) {
					break 2;
				}
				if ( (int) $row['expires_at'] <= 0 ) {
					continue;
				}
				$lease = Repository::claim( 'job', $row['record_id'], 60 );
				if ( null === $lease ) {
					continue;
				}
				try {
					$job = Records::get( 'job', $row['record_id'] );
					if ( null === $job || ! in_array( $job['status'], array( 'completed', 'failed', 'cancelled', 'reconciled' ), true ) ) {
						continue;
					}
					$r = Operations::remove_details( $job, 100 - $removed );
					if ( ! $r['success'] ) {
						return $r;
					}
					$removed += $r['removed_records'];
					$jobs    += ! empty( $r['complete'] ) ? 1 : 0;
				} finally {
					Repository::release( 'job', $row['record_id'], $lease['owner'] );
				}
			}
		}
		foreach ( array( 'summary', 'dedupe', 'telemetry', 'quota', 'confirmation' ) as $kind ) {
			if ( $removed >= 100 ) {
				break;
			}
			$filters = array(
				'connection_id'  => Connections::id(),
				'expires_before' => time(),
			);
			$rows    = Repository::select( $kind, $filters, 100, 0, false );
			if ( is_wp_error( $rows ) ) {
				return Response::fail( $rows );
			}
			foreach ( $rows as $row ) {
				if ( $removed >= 100 ) {
					break;
				}
				if ( (int) $row['expires_at'] <= 0 ) {
					continue;
				}
				$id     = $row['record_id'];
				$record = Records::get( $kind, $id );
				if ( null === $record ) {
					continue;
				}
				if ( in_array( $kind, array( 'summary', 'dedupe' ), true ) && null !== Records::get( 'job', $id ) ) {
					continue;
				}
				if ( 'summary' === $kind && in_array( $record['status'] ?? '', array( 'unknown', 'failed' ), true ) ) {
					continue;
				}
				if ( 'confirmation' === $kind ) {
					if ( 'prepared' !== ( $record['status'] ?? '' ) && ( 'finished' !== ( $record['status'] ?? '' ) || in_array( $record['outcome'] ?? 'unknown', array( 'unknown', 'partial' ), true ) || ( $record['created_at'] ?? time() ) > time() - Options::limit( Options::JOB_SUMMARY_DAYS ) * 86400 ) ) {
						continue;
					}
					$lock = Lock::acquire( 'confirmation:' . $id, 30 );
					if ( null === $lock ) {
						continue;
					}
					try {
						$current = Records::get( $kind, $id );
						if ( $current !== $record ) {
							continue;
						}
						$children_left = false;
						foreach ( array( 'attempt', 'continuation' ) as $child_kind ) {
							$children = Repository::select( $child_kind, array( 'id_prefix' => $id . '_' ), max( 1, 101 - $removed ), 0, false );
							if ( is_wp_error( $children ) ) {
								return Response::fail( $children );
							}
							foreach ( $children as $child ) {
								if ( $removed >= 100 ) {
									$children_left = true;
									break;
								}
								$deleted = Records::remove( $child_kind, $child['record_id'] );
								if ( ! $deleted['success'] ) {
									return $deleted;
								}
								++$removed;
							}
						}
						if ( $children_left || $removed >= 100 ) {
							continue;
						}
						$r = Records::remove( $kind, $id );
					} finally {
						Lock::release( $lock );
					}
				} else {
					$r = Records::remove( $kind, $id );
				}
				if ( ! $r['success'] ) {
					return $r;
				}
				++$removed;
			}
		}
		return Response::ok(
			array(
				'removed_jobs'                   => $jobs,
				'removed_records'                => $removed,
				'max_records'                    => 100,
				'more_possible'                  => $removed >= 100,
				'active_deduplication_preserved' => true,
				'unresolved_unknown_preserved'   => true,
			)
		);
	}
	public static function register(): void {
		Ability::register(
			'google/executar-vencidos',
			'any',
			array(
				'label'        => 'Google: executar tarefas vencidas',
				'description'  => 'Executa agendas e tarefas elegíveis sem depender de visita ao site. Por padrão atua somente na conexão selecionada. Mesmo worker, autorização, prazo de 20 s e teto de 25 itens.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => array(
						'max_items'       => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 25,
						),
						'all_connections' => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'false executa somente a conexão selecionada; true inclui todas as conexões deste site.',
						),
					),
				),
				'callback'     => array( self::class, 'run' ),
			)
		);
		Ability::register(
			'google/cleanup-jobs',
			'any',
			array(
				'label'        => 'Google: limpar histórico vencido',
				'description'  => 'Remove detalhes encerrados após retenção; preserva deduplicação e resultados desconhecidos.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => array(
						'dry_run' => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => 'true apresenta candidatos sem remover; false executa até 100 remoções com revalidação.',
						),
					),
				),
				'callback'     => array( self::class, 'cleanup' ),
			)
		);
	}
}
