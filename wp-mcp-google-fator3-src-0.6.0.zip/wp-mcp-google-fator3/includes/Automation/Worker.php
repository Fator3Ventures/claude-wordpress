<?php
/**
 * Shared bounded worker for inline inspection, MCP, WP-Cron and CLI.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{
	Auth\Credentials, Connections, Gate, Lock, Operation, Options, Preflight, Records, Response, SearchConsole\Workflow, Sheets\Export, Storage\Migration, Storage\Repository, Unified\Query
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Worker {

	public static function run( string $id, int $max_items = 25 ): array {
		return Execution::active() ? self::work( $id, $max_items ) : Execution::run( static fn () => self::work( $id, $max_items ) );
	}
	private static function work( string $id, int $max_items ): array {
		if ( Migration::paused() ) {
			return Response::fail( new \WP_Error( 'f3_google_storage_paused', 'Fila pausada para migração.' ) );
		}
		$indexed = Migration::active();
		$lease   = $indexed ? Repository::claim( 'job', $id, 60 ) : Lock::acquire( 'job:' . $id, 60 );
		if ( null === $lease ) {
			$observed = Records::get( 'job', $id );
			if ( null === $observed ) {
				return Response::fail( new \WP_Error( 'f3_google_job_missing', 'Job inexistente.' ), array( 'operation_outcome' => 'not_applied' ) );
			}
			return Response::ok(
				array(
					'operation_outcome' => self::outcome( $observed ),
					'executed'          => false,
					'reason'            => null === $observed ? 'job_missing' : 'job_busy',
					'job'               => null === $observed ? null : Jobs::view( $observed ),
					'complete'          => false,
				)
			);
		}
		$owner      = $indexed ? $lease['owner'] : null;
		$generation = $indexed ? (int) $lease['row']['generation'] : null;
		$save       = static function ( array $job ) use ( $indexed, $id, $owner, &$generation ): array {
			$r = $indexed ? Repository::put( 'job', $id, $job, $generation, $owner ) : Records::put( 'job', $id, $job );
			if ( ! empty( $r['success'] ) && isset( $r['generation'] ) ) {
				$generation = $r['generation'];
			}
			return $r;
		};
		$prior_user = get_current_user_id();
		$steps      = 0;
		$reason     = null;
		try {
			$job = Records::get( 'job', $id );
			if ( null === $job ) {
				return Response::fail( new \WP_Error( 'f3_google_job_missing', 'Job inexistente.' ) );
			}
			if ( in_array( $job['status'], array( 'completed', 'failed', 'cancelled', 'reconciled', 'unknown', 'blocked' ), true ) ) {
				return self::observed( $job, false, $job['blocked_reason'] ?? null );
			}
			if ( in_array( $job['status'], array( 'dispatching', 'running' ), true ) && ! empty( $job['write'] ) ) {
				$job['status']  = 'unknown';
				$job['message'] = 'Despacho anterior sem resultado confirmado; reconcilie o destino.';
				$saved          = $save( $job );
				return $saved['success'] ? self::observed( $job, false, 'reconcile_target' ) : $saved;
			}
			if ( 'export' === $job['task'] && empty( $job['confirmation_record'] ) ) {
				$job['status'] = 'approval_required';
				$saved         = $save( $job );
				return $saved['success'] ? self::observed( $job, false, 'prepare_and_approve_job' ) : $saved;
			}
			if ( ! isset( $job['context'] ) ) {
				$job['status']         = 'blocked';
				$job['blocked_reason'] = 'legacy_context_required';
				$saved                 = $save( $job );
				return $saved['success'] ? self::observed( $job, false, $job['blocked_reason'] ) : $saved;
			}
			if ( ! user_can( (int) $job['user_id'], Options::capability() ) || ! Options::is_enabled() ) {
				$job['status']         = 'blocked';
				$job['blocked_reason'] = 'authorization_required';
				$saved                 = $save( $job );
				return $saved['success'] ? self::observed( $job, false, $job['blocked_reason'] ) : $saved;
			}
			if ( $job['run_after'] > time() ) {
				return self::observed( $job, false, 'backoff' );
			}
			wp_set_current_user( (int) $job['user_id'] );
			return Connections::run(
				$job['connection_id'],
				function () use ( &$job, $id, $max_items, $indexed, $owner, $save, &$generation, &$steps, &$reason ): array {
					$context = Context::validate( $job['context'] );
					if ( null !== $context ) {
						$job['status']         = 'blocked';
						$job['blocked_reason'] = $context->get_error_code();
						$saved                 = $save( $job );
						return $saved['success'] ? self::observed( $job, false, $job['blocked_reason'] ) : $saved;
					}
					$item_limit = min( 25, max( 1, $max_items ) );
					for ( $n = 0;$n < $item_limit;++$n ) {
						if ( Execution::remaining() < 1 ) {
							$reason = 'deadline';
							break;
						}
						if ( $indexed && ! Repository::renew( 'job', $id, $owner, 60 ) ) {
							$reason = 'lease_lost';
							break;
						}
						$job['status']     = 'running';
						$job['updated_at'] = time();
						++$job['attempts'];
						$saved = $save( $job );
						if ( ! $saved['success'] ) {
							return $saved + array(
								'job_id'   => $id,
								'observed' => Jobs::view( Records::get( 'job', $id ) ?? array() ),
							);
						}
						$guard = function ( bool $write = false ) use ( &$job, $save ): ?\WP_Error {
							if ( Migration::paused() ) {
								return new \WP_Error( 'f3_google_storage_paused', 'Migração iniciada; novo despacho recusado.', array( 'operation_outcome' => 'not_applied' ) );
							}
							if ( ! user_can( (int) $job['user_id'], Options::capability() ) || ! Options::is_enabled() ) {
								return new \WP_Error( 'f3_google_forbidden', 'Autorização revogada antes do envio.', array( 'operation_outcome' => 'not_applied' ) );
							}
							$context = Context::validate( $job['context'] );
							if ( null !== $context ) {
								return $context;
							}
							if ( $write ) {
								$job['status']          = 'dispatching';
								$job['dispatch_intent'] = array(
									'at'      => time(),
									'cursor'  => $job['cursor'],
									'attempt' => $job['attempts'],
								);
							}
							$job['updated_at'] = time();
							$saved             = $save( $job );
							return $saved['success'] ? null : new \WP_Error( 'f3_google_job_fenced', 'Propriedade da execução ou persistência perdida; envio recusado.', array( 'operation_outcome' => 'not_applied' ) );
						};
						try {
							$result = Execution::run( static fn () => self::execute( $job ), max( 1, Execution::remaining() + 2 ), $guard );
						} catch ( \Throwable $error ) {
							$result = Response::fail( new \WP_Error( 'f3_google_job_exception', 'Execução interrompida.', array( 'operation_outcome' => ! empty( $job['dispatch_intent'] ) ? 'unknown' : 'not_applied' ) ) );
						}
						$result     = Operation::result( $result, $job['write'] ? 'write' : 'read' );
						$item       = null;
						$item_index = $job['cursor'];
						$ok         = ! empty( $result['success'] );
						$blocked    = in_array( $result['error_code'] ?? '', array( 'f3_google_confirmation_changed', 'f3_google_confirmation_required', 'f3_google_job_context_changed', 'f3_google_auth_not_active', 'f3_google_forbidden', 'f3_google_service_disabled', 'f3_google_policy_denied', 'f3_google_job_fenced' ), true );
						if ( $blocked ) {
							$job['status']         = 'blocked';
							$job['blocked_reason'] = $result['error_code'];
							$job['last_error']     = $result;
							$reason                = $job['blocked_reason'];
						} elseif ( ! $ok && ! $job['write'] && ! empty( $result['retryable'] ) && ( $job['attempts'] < 4 || in_array( $result['error_code'] ?? '', array( 'f3_google_inspection_budget', 'f3_google_deadline', 'f3_google_inspection_busy' ), true ) ) ) {
							$job['status']     = 'pending';
							$job['run_after']  = time() + max( 1, (int) ( $result['details']['retry_after'] ?? 60 ) );
							$job['last_error'] = $result;
							$reason            = 'backoff';
							if ( in_array( $result['error_code'] ?? '', array( 'f3_google_inspection_budget', 'f3_google_deadline', 'f3_google_inspection_busy' ), true ) ) {
								--$job['attempts'];
							}
						} elseif ( 'inspect-urls' === $job['task'] ) {
							$item = array(
								'url'    => $job['parameters']['urls'][ $job['cursor'] ],
								'result' => $result,
							);
							++$job['cursor'];
							++$steps;
							$job['attempts']     = 0;
							$job['result_count'] = $job['cursor'];
							$job['status']       = $job['cursor'] < count( $job['parameters']['urls'] ) ? 'pending' : 'completed';
							$job['run_after']    = time();
							$passed              = ( $job['summary']['passed'] ?? 0 ) + ( $ok ? 1 : 0 );
							$job['summary']      = array(
								'total'             => count( $job['parameters']['urls'] ),
								'processed'         => $job['cursor'],
								'passed'            => $passed,
								'failed'            => $job['cursor'] - $passed,
								'all_checks_passed' => 'completed' === $job['status'] && $passed === $job['cursor'],
							);
						} else {
							$job['result'] = $result;
							++$steps;
							$job['status'] = $job['write'] && in_array( $result['operation_outcome'], array( 'unknown', 'partial' ), true ) ? 'unknown' : ( $ok ? 'completed' : 'failed' );
						}
						$job['updated_at'] = time();
						if ( in_array( $job['status'], array( 'completed', 'cancelled', 'failed' ), true ) ) {
							$job['expires_at'] = time() + \Fator3\McpGoogle\Options::limit( \Fator3\McpGoogle\Options::JOB_DETAIL_DAYS ) * 86400;
						}
						$saved = null;
						if ( null !== $item ) {
							if ( $indexed ) {
								$saved = Repository::commit_item( $id, $owner, $generation, $job, $item_index, $item );
								if ( ! empty( $saved['success'] ) ) {
									$generation = $saved['generation'];
								}
							} else {
								$stored = Results::put( $id, $item_index, $item );
								if ( ! $stored['success'] ) {
									return $stored + array(
										'job_id' => $id,
										'reason' => 'result_not_persisted',
									);
								}
							}
						}
						if ( null === $item && isset( $job['result'] ) ) {
							$chunks = Results::externalize( $job );
							if ( $chunks ) {
								if ( $indexed ) {
									$saved = Repository::commit_result( $id, $owner, $generation, $job, $chunks );
									if ( ! empty( $saved['success'] ) ) {
										$generation = $saved['generation'];
									}
								} else {
									foreach ( $chunks as $chunk_id => $chunk ) {
										$stored = Records::put( 'result', $chunk_id, $chunk );
										if ( ! $stored['success'] ) {
											return $stored + array(
												'job_id' => $id,
												'reason' => 'result_not_persisted',
											);
										}
									}
								}
							}
						}
						$saved = $saved ?? $save( $job );
						if ( ! $saved['success'] ) {
							return $saved + array(
								'job_id'   => $id,
								'reason'   => 'progress_not_persisted',
								'observed' => Jobs::view( Records::get( 'job', $id ) ?? array() ),
							);
						}
						if ( in_array( $job['task'], array( 'preflight', 'report', 'sitemap' ), true ) ) {
							Alerts::result( 'sitemap' === $job['task'] ? 'sitemap_error' : 'scheduled_check', $job['task'] . '|' . ( $job['parameters']['site_url'] ?? $job['parameters']['template'] ?? $id ), $result );
						}
						if ( 'pending' !== $job['status'] || null !== $reason ) {
							break;
						}
					}
					if ( null === $reason && 'pending' === $job['status'] ) {
						$reason = 'item_budget';
					}
					return self::observed( $job, $steps > 0, $reason );
				}
			);
		} finally {
			wp_set_current_user( $prior_user );
			if ( $indexed ) {
				Repository::release( 'job', $id, $owner );
			} else {
				Lock::release( $lease );
			}
		}
	}
	private static function execute( array $job ): array {
		$gate = Gate::check( 'any' );
		if ( null !== $gate ) {
			return $gate;
		}
		$p = $job['parameters'];
		switch ( $job['task'] ) {
			case 'inspect-urls':
				$gate = Gate::check( 'gsc' );
				return $gate ?? Workflow::inspect(
					array(
						'site_url'       => $p['site_url'],
						'inspection_url' => $p['urls'][ $job['cursor'] ],
						'refresh'        => $p['refresh'] ?? false,
						'language_code'  => $p['language_code'] ?? 'pt-BR',
					)
				);
			case 'query':
				return Query::run( $p );
			case 'export':
				return \Fator3\McpGoogle\Confirmation::execute_job( $job['id'], $job['confirmation_record'] ?? '', 'google/export-to-sheet', $p, static fn () => Export::run( $p ) );
			case 'sitemap':
				$gate = Gate::check( 'gsc' );
				return $gate ?? Workflow::sitemap( $p );
			case 'report':
				return Reports::run( $p );
			case 'preflight':
				return Preflight::run( $p );
		}
		return Response::fail( new \WP_Error( 'f3_google_job_task', 'Tarefa desconhecida.' ) );
	}
	/** Result of the job's remote intent, independent of successful local execution. */
	public static function outcome( array $job ): string {
		if ( empty( $job['write'] ) ) {
			return 'not_applicable';
		}
		if ( isset( $job['result']['operation_outcome'] ) ) {
			return Operation::result( $job['result'], 'write' )['operation_outcome'];
		}
		return in_array( $job['status'] ?? '', array( 'unknown', 'running', 'dispatching', 'completed', 'reconciled' ), true ) ? 'unknown' : 'not_applied';
	}

	private static function observed( array $job, bool $executed, ?string $reason ): array {
		$total    = 'inspect-urls' === $job['task'] ? count( $job['parameters']['urls'] ) : 1;
		$complete = in_array( $job['status'], array( 'completed', 'failed', 'cancelled' ), true );
		return Response::ok(
			array(
				'job'               => Jobs::view( $job ),
				'job_id'            => $job['id'],
				'operation_outcome' => self::outcome( $job ),
				'status'            => $job['status'],
				'executed'          => $executed,
				'complete'          => $complete,
				'remaining'         => max( 0, $total - ( 'inspect-urls' === $job['task'] ? $job['cursor'] : ( $complete ? 1 : 0 ) ) ),
				'reason'            => $reason,
				'next_eligible_at'  => 'pending' === $job['status'] ? $job['run_after'] : null,
				'resume'            => array(
					'ability' => 'google/run-job',
					'job_id'  => $job['id'],
				),
			)
		);
	}
}
