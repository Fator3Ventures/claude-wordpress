<?php
/**
 * Resolve selectors at admission; names and defaults cannot retarget queued work.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{Connections, Options, Policy, Unified\Accounts, Unified\DateRange, Unified\Query};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class FrozenInput {

	public static function hash( array $value ): string {
		$canonical = static function ( $item ) use ( &$canonical ) {
			if ( is_array( $item ) ) {
				if ( array_values( $item ) !== $item ) {
					ksort( $item );
				}foreach ( $item as &$child ) {
					$child = $canonical( $child );
				}unset( $child );
			}return $item;
		};
		return hash( 'sha256', wp_json_encode( $canonical( $value ) ) );
	}
	public static function resolve( string $task, array $params, bool $dates = true ) {
		if ( 'query' === $task ) {
			return self::query( $params, $dates );
		}
		if ( 'report' === $task ) {
			$definition = Reports::definition( $params );
			if ( is_wp_error( $definition ) ) {
				return $definition;
			}
			$definition['accounts'] = $params['accounts'] ?? array();
			$query                  = self::query( $definition, $dates );
			if ( is_wp_error( $query ) ) {
				return $query;
			}
			foreach ( array( 'accounts', 'date_range', 'compare_date_range' ) as $key ) {
				if ( isset( $query[ $key ] ) ) {
					$params[ $key ] = $query[ $key ];
				}
			}
			return $params;
		}
		if ( 'export' === $task ) {
			foreach ( array( 'query', 'blend' ) as $kind ) {
				if ( isset( $params[ $kind ] ) ) {
					$params[ $kind ] = self::resolve( $kind, $params[ $kind ], $dates );
					if ( is_wp_error( $params[ $kind ] ) ) {
						return $params[ $kind ];
					}
				}
			}
			foreach ( $params['queries'] ?? array() as $i => $entry ) {
				$kind  = isset( $entry['blend'] ) ? 'blend' : 'query';
				$query = self::resolve( $kind, $entry[ $kind ] ?? $entry, $dates );
				if ( is_wp_error( $query ) ) {
					return $query;
				}$params['queries'][ $i ] = isset( $entry[ $kind ] ) ? array_replace( $entry, array( $kind => $query ) ) : $query;
			}
		}
		if ( 'blend' === $task ) {
			foreach ( $params['queries'] ?? array() as $i => $source ) {
				if ( ! is_array( $source ) ) {
					return new \WP_Error( 'f3_google_blend_query', 'Cada consulta deve ser um objeto.' );
				}
				$query = $source['query'] ?? $source;
				foreach ( array( 'date_range', 'compare_date_range', 'filters' ) as $common ) {
					if ( ! isset( $query[ $common ] ) && isset( $params[ $common ] ) ) {
						$query[ $common ] = $params[ $common ];
					}
				}
				$query = self::query( $query, $dates );
				if ( is_wp_error( $query ) ) {
					return $query;
				}
				$params['queries'][ $i ] = isset( $source['query'] ) ? array_replace( $source, array( 'query' => $query ) ) : $query;
			}
		}
		return $params;
	}
	private static function query( array $input, bool $dates ) {
		$connector = Query::connector( $input['connector'] ?? '' );
		if ( is_wp_error( $connector ) ) {
			return $connector;
		}
		$selectors = $input['accounts'] ?? $input['account_id'] ?? array();
		$selectors = is_string( $selectors ) ? array( $selectors ) : $selectors;
		if ( ! is_array( $selectors ) || ! $selectors ) {
			return new \WP_Error( 'f3_google_job_accounts', 'Informe recursos explícitos ou selecione os padrões antes de criar a tarefa.' );
		}
		$ids = Accounts::resolve_many( $connector, $selectors );
		if ( is_wp_error( $ids ) ) {
			return $ids;
		}
		if ( ! $ids || count( $ids ) > 25 ) {
			return new \WP_Error( 'f3_google_job_accounts', 'A descoberta deve resolver de 1 a 25 recursos completos. Divida lotes maiores.' );
		}
		$service = array(
			'ga4'            => 'ga',
			'google-ads'     => 'ads',
			'search-console' => 'gsc',
		)[ $connector ] ?? '';
		foreach ( $ids as $id ) {
			if ( ! Policy::permitted( $service, $id ) ) {
				return new \WP_Error( 'f3_google_policy_denied', 'Um recurso da tarefa está fora da política.' );
			}
		}
		$input['accounts'] = $ids;
		unset( $input['account_id'] );
		$range = DateRange::resolve( $input['date_range'] ?? 'last_28_days' );
		if ( is_wp_error( $range ) ) {
			return $range;
		}if ( $dates ) {
			$input['date_range'] = array(
				'from' => $range['from'],
				'to'   => $range['to'],
			);
		}
		if ( isset( $input['compare_date_range'] ) ) {
			$compare = DateRange::compare( $range, $input['compare_date_range'] );
			if ( is_wp_error( $compare ) ) {
				return $compare;
			}if ( $dates ) {
				$input['compare_date_range'] = array(
					'from' => $compare['from'],
					'to'   => $compare['to'],
				);
			}
		}
		return $input;
	}
}
