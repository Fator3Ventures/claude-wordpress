<?php
/**
 * Local operational controls; uncertain writes require recorded reconciliation.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{
	Ability, Audit, Connections, Lock, Records, Response, Storage\Migration, Storage\Repository
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Operations {

	public static function listing( array $input = array() ): array {
		$limit   = max( 1, min( 100, (int) ( $input['limit'] ?? 30 ) ) );
		$offset  = max( 0, (int) ( $input['offset'] ?? 0 ) );
		$filters = array( 'connection_id' => Connections::id() );
		$dates   = \Fator3\McpGoogle\Storage\DateFilter::parse( $input, 'f3_google_job_dates' );
		if ( is_wp_error( $dates ) ) {
			return Response::fail( $dates );
		}
		$filters += $dates;
		foreach ( array(
			'status' => 'state',
			'task'   => 'task',
		) as $from => $to ) {
			if ( isset( $input[ $from ] ) ) {
				$filters[ $to ] = $input[ $from ];
			}
		}
		if ( Migration::active() ) {
			$rows = Repository::select( 'job', $filters, $limit + 1, $offset );
			if ( is_wp_error( $rows ) ) {
				return Response::fail( $rows );
			}
			$more = count( $rows ) > $limit;
			$out  = array();
			foreach ( array_slice( $rows, 0, $limit ) as $row ) {
				$out[] = array(
					'id'            => $row['record_id'],
					'task'          => $row['task'],
					'status'        => $row['state'],
					'connection_id' => $row['connection_id'],
					'user_id'       => (int) $row['actor'],
					'updated_at'    => (int) $row['updated_at'],
					'run_after'     => (int) $row['due_at'],
					'recovery'      => self::recovery( $row['state'] ),
				);
			}
			$schedule_rows = Repository::select( 'schedule', array( 'connection_id' => Connections::id() ), 100 );
			if ( is_wp_error( $schedule_rows ) ) {
				return Response::fail( $schedule_rows );
			}
			$schedules = array();
			foreach ( $schedule_rows as $row ) {
				$schedules[] = Records::get( 'schedule', $row['record_id'] );
			}
		} else {
			$out       = array();
			$schedules = array();
			foreach ( Records::list( 'job', 1000 ) as $job ) {
				if ( ( $job['connection_id'] ?? 'default' ) !== Connections::id() || ( isset( $input['status'] ) && $job['status'] !== $input['status'] ) || ( isset( $input['task'] ) && $job['task'] !== $input['task'] ) ) {
					continue;
				}
				if ( ( isset( $dates['created_after'] ) && ( $job['created_at'] ?? 0 ) <= $dates['created_after'] ) || ( isset( $dates['created_before'] ) && ( $job['created_at'] ?? 0 ) > $dates['created_before'] ) ) {
					continue;
				}
				$out[] = array_intersect_key( $job, array_flip( array( 'id', 'task', 'status', 'connection_id', 'user_id', 'updated_at', 'run_after' ) ) ) + array( 'recovery' => self::recovery( $job['status'] ) );
			}
			$more = count( $out ) > $offset + $limit;
			$out  = array_slice( $out, $offset, $limit );
			foreach ( Records::list( 'schedule', 100 ) as $schedule ) {
				if ( ( $schedule['connection_id'] ?? 'default' ) === Connections::id() ) {
					$schedules[] = $schedule;
				}
			}
		}
		foreach ( $schedules as &$schedule ) {
			unset( $schedule['context'], $schedule['parameters'] );
		}
		unset( $schedule );
		return Response::ok(
			array(
				'jobs'          => $out,
				'schedules'     => $schedules,
				'next_offset'   => $more ? $offset + count( $out ) : null,
				'metadata_only' => Migration::active(),
			)
		);
	}
	private static function recovery( string $status ): array {
		if ( 'approval_required' === $status ) {
			return array(
				'action'          => 'prepare_and_approve',
				'ability'         => 'google/prepare-job',
				'automatic_retry' => false,
			);
		}
		if ( 'unknown' === $status ) {
			return array(
				'action'          => 'reconcile_target',
				'ability'         => 'google/reconcile-job',
				'automatic_retry' => false,
			);
		}
		if ( 'blocked' === $status ) {
			return array(
				'action'          => 'review_context_and_create_new_intent',
				'automatic_retry' => false,
			);
		}
		return array( 'action' => 'pending' === $status ? 'google/run-job' : 'google/get-job' );
	}
	public static function action( string $route, array $input ): array {
		$id = (string) ( $input['job_id'] ?? '' );
		if ( ! preg_match( '/^[A-Za-z0-9_-]{1,100}$/D', $id ) ) {
			return Response::fail( new \WP_Error( 'f3_google_job_input', 'job_id inválido.' ) );
		}
		$job = Records::get( 'job', $id );
		if ( null === $job && 'get-job' === $route ) {
			$summary = Records::get( 'summary', $id );
			if ( null !== $summary && ( $summary['connection_id'] ?? 'default' ) === Connections::id() ) {
				return Response::ok(
					array(
						'job'               => $summary,
						'details_available' => false,
						'summary_only'      => true,
					)
				);
			}
		}
		if ( null === $job || ( $job['connection_id'] ?? 'default' ) !== Connections::id() ) {
			return Response::fail( new \WP_Error( 'f3_google_job_missing', 'Job não encontrado nesta conexão.' ) );
		}
		if ( 'get-job' === $route ) {
			return Response::ok( array( 'job' => Jobs::view( $job, $input['offset'] ?? 0, $input['limit'] ?? 20, $input['include_input'] ?? false ) ) );
		}
		if ( 'run-job' === $route ) {
			return Worker::run( $id );
		}
		$indexed = Migration::active();
		$lease   = $indexed ? Repository::claim( 'job', $id ) : Lock::acquire( 'job:' . $id, 60 );
		if ( null === $lease ) {
			return Response::fail( new \WP_Error( 'f3_google_job_busy', 'Execução em andamento; aguarde antes de alterar.' ) );
		}
		try {
			$job = Records::get( 'job', $id );
			if ( null === $job ) {
				return Response::fail( new \WP_Error( 'f3_google_job_missing', 'Job inexistente.' ) );
			}
			if ( 'delete-job' === $route ) {
				if ( ! in_array( $job['status'], array( 'completed', 'failed', 'cancelled', 'reconciled' ), true ) ) {
					return Response::fail( new \WP_Error( 'f3_google_job_unresolved', 'Encerre ou reconcilie o job antes de remover seus detalhes.' ) );
				}
				return self::remove_details( $job );
			}
			if ( 'reconcile-job' === $route ) {
				if ( ! in_array( $job['status'], array( 'unknown', 'dispatching', 'running' ), true ) || empty( $job['write'] ) ) {
					return Response::fail( new \WP_Error( 'f3_google_job_reconciliation', 'Somente uma escrita interrompida pode ser reconciliada.' ) );
				}
				$outcome  = $input['observed_outcome'] ?? '';
				$evidence = trim( (string) ( $input['evidence'] ?? '' ) );
				if ( ! in_array( $outcome, array( 'applied', 'not_applied', 'partial' ), true ) || strlen( $evidence ) < 10 || strlen( $evidence ) > 2000 ) {
					return Response::fail( new \WP_Error( 'f3_google_job_reconciliation', 'Registre applied, not_applied ou partial e uma evidência de 10–2000 caracteres.' ) );
				}
				$job['status']         = 'reconciled';
				$job['reconciliation'] = array(
					'actor'            => get_current_user_id(),
					'at'               => time(),
					'observed_outcome' => $outcome,
					'evidence'         => Audit::redact( $evidence ),
					'automatic_replay' => false,
				);
			} else {
				if ( in_array( $job['status'], array( 'unknown', 'dispatching' ), true ) || ( 'running' === $job['status'] && ! empty( $job['write'] ) ) ) {
					return Response::fail( new \WP_Error( 'f3_google_job_unresolved', 'Reconcilie o efeito remoto antes de encerrar esta escrita.' ) );
				}
				$job['status']       = 'cancelled';
				$job['cancellation'] = array(
					'actor'                     => get_current_user_id(),
					'at'                        => time(),
					'completed_items_preserved' => true,
				);
			}
			$job['updated_at'] = time();
			$job['expires_at'] = time() + \Fator3\McpGoogle\Options::limit( \Fator3\McpGoogle\Options::JOB_DETAIL_DAYS ) * 86400;
			$saved             = $indexed ? Repository::put( 'job', $id, $job, (int) $lease['row']['generation'], $lease['owner'] ) : Records::put( 'job', $id, $job );
			return $saved + array(
				'job'                     => Jobs::view( $job ),
				'remote_writes_performed' => false,
			);
		} finally {
			if ( $indexed ) {
				Repository::release( 'job', $id, $lease['owner'] );
			} else {
				Lock::release( $lease );
			}
		}
	}
	/** Delete at most budget child records and resume until all details are gone. */
	public static function remove_details( array $job, int $budget = 100 ): array {
		if ( ! in_array( $job['status'], array( 'completed', 'failed', 'cancelled', 'reconciled' ), true ) ) {
			return Response::fail( new \WP_Error( 'f3_google_job_unresolved', 'Tarefa não encerrada.' ) );
		}
		$summary                       = array_intersect_key( $job, array_flip( array( 'id', 'connection_id', 'user_id', 'task', 'status', 'created_at', 'updated_at', 'summary', 'input_hash', 'request_hash', 'reconciliation' ) ) );
		$summary['details_removed_at'] = time();
		$summary['expires_at']         = 'failed' === $job['status'] ? 0 : max( time() + 86400, ( $job['updated_at'] ?? time() ) + \Fator3\McpGoogle\Options::limit( \Fator3\McpGoogle\Options::JOB_SUMMARY_DAYS ) * 86400 );
		$saved                         = Records::put( 'summary', $job['id'], $summary );
		if ( ! $saved['success'] ) {
			return $saved;
		}
		$job['details_removal_started'] = true;
		$job['expires_at']              = time();
		$saved                          = Records::put( 'job', $job['id'], $job );
		if ( ! $saved['success'] ) {
			return $saved;
		}
		$removed = 0;
		$budget  = max( 1, min( 100, $budget ) );
		foreach ( array( 'item', 'result' ) as $kind ) {
			if ( Migration::active() ) {
				$rows = Repository::select( $kind, array( 'task' => $job['id'] ), $budget - $removed + 1 );
				if ( is_wp_error( $rows ) ) {
					return Response::fail( $rows );
				}
				$ids = array_column( $rows, 'record_id' );
			} else {
				$ids = array();
				if ( 'item' === $kind ) {
					for ( $i = 0;$i < ( $job['result_count'] ?? 0 );++$i ) {
						$id = Results::id( $job['id'], $i );
						if ( null !== Records::get( $kind, $id ) ) {
							$ids[] = $id;
						}
					}
				} else {
					foreach ( $job['result_pages'] ?? array() as $field => $meta ) {
						$chunk_count = (int) ceil( $meta['count'] / $meta['chunk_size'] );
						for ( $i = 0;$i < $chunk_count;++$i ) {
							$id = Results::chunk_id( $job['id'], $field, $i );
							if ( null !== Records::get( $kind, $id ) ) {
								$ids[] = $id;
							}
						}
					}
				}
			}
			foreach ( $ids as $id ) {
				if ( $removed >= $budget ) {
					return Response::ok(
						array(
							'removed_records' => $removed,
							'complete'        => false,
							'job_id'          => $job['id'],
							'reason'          => 'cleanup_budget',
						)
					);
				}
				$r = Records::remove( $kind, $id );
				if ( ! $r['success'] ) {
					return $r;
				}
				++$removed;
			}
		}
		if ( $removed >= $budget ) {
			return Response::ok(
				array(
					'removed_records' => $removed,
					'complete'        => false,
					'job_id'          => $job['id'],
					'reason'          => 'cleanup_budget',
				)
			);
		}
		$r = Records::remove( 'job', $job['id'] );
		return $r + array(
			'removed_records'         => $removed + 1,
			'complete'                => $r['success'],
			'deduplication_preserved' => true,
			'summary_preserved'       => true,
		);
	}
	public static function register(): void {
		foreach ( array( 'get-job', 'run-job', 'cancel-job', 'delete-job', 'reconcile-job' ) as $route ) {
			Ability::register(
				'google/' . $route,
				'any',
				array(
					'label'        => 'Google: ' . $route,
					'description'  => 'Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita.',
					'mode'         => 'get-job' === $route ? 'read' : 'write',
					'input_schema' => array(
						'required'   => array( 'job_id' ),
						'properties' => array(
							'job_id'           => array( 'type' => 'string' ),
							'offset'           => array(
								'type'    => 'integer',
								'minimum' => 0,
							),
							'limit'            => array(
								'type'    => 'integer',
								'minimum' => 1,
								'maximum' => 100,
							),
							'include_input'    => array( 'type' => 'boolean' ),
							'observed_outcome' => array(
								'type' => 'string',
								'enum' => array( 'applied', 'not_applied', 'partial' ),
							),
							'evidence'         => array(
								'type'      => 'string',
								'minLength' => 10,
								'maxLength' => 2000,
							),
						),
					),
					'callback'     => static fn ( array $input ) => self::action( $route, $input ),
				)
			);
		}
		Ability::register(
			'google/list-jobs',
			'any',
			array(
				'label'        => 'Google: listar operações',
				'description'  => 'Resumos paginados por conexão, estado, tarefa e período de criação. Não carrega resultados dos jobs.',
				'input_schema' => array(
					'properties' => array(
						'status' => array( 'type' => 'string' ),
						'task'   => array(
							'type' => 'string',
							'enum' => Jobs::TASKS,
						),
						'from'   => array(
							'type'        => 'string',
							'description' => 'Início inclusivo: YYYY-MM-DD em UTC ou RFC3339 com fuso.',
						),
						'to'     => array(
							'type'        => 'string',
							'description' => 'Fim inclusivo: YYYY-MM-DD em UTC ou RFC3339 com fuso.',
						),
						'offset' => array(
							'type'    => 'integer',
							'minimum' => 0,
						),
						'limit'  => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
						),
					),
				),
				'callback'     => array( self::class, 'listing' ),
			)
		);
	}
}
