<?php
/**
 * GTM resource abilities generated from reviewed, pinned schemas.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\TagManager;

use Fator3\McpGoogle\{
	Ability, Generic\Discovery, Generic\ExecuteAction, Operation
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Abilities {
	public static function route( string $method ): string {
		$parts    = explode( '.', $method );
		$action   = array_pop( $parts );
		$resource = array_pop( $parts );
		$singular = array(
			'accounts'           => 'account',
			'containers'         => 'container',
			'workspaces'         => 'workspace',
			'tags'               => 'tag',
			'triggers'           => 'trigger',
			'variables'          => 'variable',
			'built_in_variables' => 'built-in-variable',
			'folders'            => 'folder',
			'templates'          => 'template',
			'environments'       => 'environment',
			'versions'           => 'version',
			'version_headers'    => 'version-header',
			'user_permissions'   => 'user-permission',
			'clients'            => 'client',
			'zones'              => 'zone',
			'transformations'    => 'transformation',
			'destinations'       => 'destination',
			'gtag_config'        => 'gtag-config',
		);
		$action   = strtolower( preg_replace( '/([a-z])([A-Z])/', '$1-$2', str_replace( '_', '-', $action ) ) );
		return 'gtm/' . $action . '-' . ( 'list' === $action ? str_replace( '_', '-', $resource ) : ( $singular[ $resource ] ?? str_replace( '_', '-', $resource ) ) );
	}
	public static function register(): void {
		foreach ( Discovery::methods( Api::document() ) as $id => $method ) {
			$properties = array();
			$required   = array();
			foreach ( $method['parameters'] ?? array() as $name => $schema ) {
				$properties[ $name ] = Api::schema( $schema );
				if ( ! empty( $schema['repeated'] ) ) {
					$properties[ $name ] = array(
						'type'  => 'array',
						'items' => $properties[ $name ],
					);
				}
				if ( ! empty( $schema['required'] ) ) {
					$required[] = $name;
				}
			}
			if ( isset( $method['request'] ) ) {
				$properties['body'] = Api::schema( $method['request'] );
				$required[]         = 'body';
			}
			$operation = Operation::method( 'tag-manager', $id );
			$mode      = $operation['mode'];
			if ( 'write' === $mode ) {
				$properties['dry_run'] = array(
					'type'        => 'boolean',
					'description' => 'Publicação permite prévia; os demais métodos seguem o suporte validateOnly do contrato nativo.',
				);
			}
			if ( 'tagmanager.accounts.containers.versions.publish' === $id ) {
				$properties['expected_fingerprint'] = array( 'type' => 'string' );
			}
			Ability::register(
				self::route( $id ),
				'gtm',
				array(
					'label'        => 'GTM: ' . self::route( $id ),
					'description'  => $method['description'] ?? $id,
					'mode'         => $mode,
					'input_schema' => array(
						'properties' => $properties,
						'required'   => $required,
					),
					'callback'     => static function ( array $input ) use ( $id, $method ): array {
						$path = array();
						$query = array();
						foreach ( $method['parameters'] ?? array() as $name => $schema ) {
							if ( ! array_key_exists( $name, $input ) ) {
								continue;
							}
							if ( 'path' === $schema['location'] ) {
								$path[ $name ] = $input[ $name ];
							} else {
								$query[ $name ] = $input[ $name ];
							}
						}
						return ExecuteAction::run(
							array(
								'api'         => 'tag-manager',
								'method'      => $id,
								'path_params' => $path,
								'query'       => $query,
							) + array_intersect_key( $input, array_flip( array( 'body', 'dry_run', 'expected_fingerprint' ) ) )
						);
					},
				)
			);
		}
		Publish::register();
		Diagnostic::register();
	}
}
