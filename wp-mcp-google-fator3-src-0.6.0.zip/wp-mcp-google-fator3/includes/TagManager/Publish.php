<?php
/**
 * Read-only previews and journaled GTM publications.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\TagManager;

use Fator3\McpGoogle\{
	Ability, Audit, Auth\Credentials, Connections, Lock, Records, Response, Settings
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Publish {
	private static bool $publishing = false;
	private const COLLECTIONS       = array(
		'tag'             => 'tags',
		'trigger'         => 'triggers',
		'variable'        => 'variables',
		'builtInVariable' => 'built_in_variables',
		'folder'          => 'folders',
		'customTemplate'  => 'templates',
		'client'          => 'clients',
		'gtagConfig'      => 'gtag_config',
		'transformation'  => 'transformations',
		'zone'            => 'zones',
	);
	public static function authorized(): bool {
		return self::$publishing;
	}
	public static function content( array $version ): array {
		$out = array();
		foreach ( self::COLLECTIONS as $field => $resource ) {
			$values = array_map( array( self::class, 'clean' ), $version[ $field ] ?? array() );
			usort( $values, static fn ( $a, $b ) => strcmp( wp_json_encode( $a ), wp_json_encode( $b ) ) );
			$out[ $field ] = $values;
		}
		return $out;
	}
	private static function clean( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}
		if ( array_values( $value ) === $value ) {
			return array_map( array( self::class, 'clean' ), $value );
		}
		foreach ( array( 'path', 'accountId', 'containerId', 'workspaceId', 'fingerprint', 'tagManagerUrl' ) as $key ) {
			unset( $value[ $key ] );
		}
		ksort( $value );
		foreach ( $value as &$item ) {
			$item = self::clean( $item );
		}
		unset( $item );
		return $value;
	}
	private static function hash( $value ): string {
		return hash( 'sha256', wp_json_encode( $value ) );
	}
	private static function failed( string $code, string $message, array $extra = array() ): array {
		return Response::fail( new \WP_Error( $code, $message ), $extra + array( 'operation_outcome' => 'not_applied' ) );
	}
	/** A 404 means no published version only after the container itself is readable. */
	private static function live( string $container ) {
		$live = Api::call( 'containers.versions.live', array( 'parent' => $container ) );
		if ( is_wp_error( $live ) && 404 === ( $live->get_error_data()['status'] ?? null ) ) {
			$info = Api::call( 'containers.get', array( 'path' => $container ) );
			if ( is_wp_error( $info ) ) {
				return $info;}
			if ( ( $info['path'] ?? '' ) !== $container ) {
				return new \WP_Error( 'f3_google_gtm_container', 'Contêiner não confirmado.' );}
			return array();
		}
		return is_array( $live ) && isset( $live['containerVersion'] ) ? $live['containerVersion'] : $live;
	}
	public static function snapshot( string $path, bool $workspace ) {
		$pattern = $workspace ? '~^(accounts/[0-9]+/containers/[0-9]+)/workspaces/[0-9]+$~D' : '~^(accounts/[0-9]+/containers/[0-9]+)/versions/[0-9]+$~D';
		if ( ! preg_match( $pattern, $path, $match ) ) {
			return new \WP_Error( 'f3_google_gtm_path', 'Caminho GTM inválido.' );
		}
		$container = $match[1];
		$live      = self::live( $container );
		if ( is_wp_error( $live ) ) {
			return $live;
		}
		// Unwrap responses from older API adapters as well.
		if ( isset( $live['containerVersion'] ) ) {
			$live = $live['containerVersion'];
		}
		$target = Api::call( $workspace ? 'containers.workspaces.get' : 'containers.versions.get', array( 'path' => $path ) );
		if ( is_wp_error( $target ) ) {
			return $target;
		}
		if ( $workspace ) {
			$status = Api::call( 'containers.workspaces.getStatus', array( 'path' => $path ) );
			if ( is_wp_error( $status ) ) {
				return $status;
			}
			if ( ! empty( $status['mergeConflict'] ) ) {
				return new \WP_Error( 'f3_google_gtm_conflict', 'Resolva os conflitos do workspace antes de publicar.' );
			}
			$info = Api::call( 'containers.get', array( 'path' => $container ) );
			if ( is_wp_error( $info ) ) {
				return $info;
			}
			foreach ( self::COLLECTIONS as $field => $resource ) {
				if ( in_array( $field, array( 'client', 'transformation' ), true ) && ! in_array( 'server', $info['usageContext'] ?? array(), true ) ) {
					continue;
				}
				if ( 'zone' === $field && empty( $info['features']['supportZones'] ) && empty( $live['zone'] ) ) {
					continue;
				}
				$items = Api::all( 'containers.workspaces.' . $resource . '.list', $path, $field );
				if ( is_wp_error( $items ) ) {
					return $items;
				}
				$target[ $field ] = $items;
			}
		}
		return array(
			'container' => $container,
			'path'      => $path,
			'live'      => $live,
			'target'    => $target,
			'workspace' => $workspace,
		);
	}
	public static function preview( array $snapshot, array $input ) {
		$revision = Settings::execution_revision();
		if ( is_wp_error( $revision ) ) {
			return $revision;
		}
		$live   = self::content( $snapshot['live'] );
		$target = self::content( $snapshot['target'] );
		$diff   = array();
		foreach ( $target as $kind => $items ) {
			$before  = array_map( 'wp_json_encode', $live[ $kind ] );
			$after   = array_map( 'wp_json_encode', $items );
			$removed = array_values( array_diff( $before, $after ) );
			$added   = array_values( array_diff( $after, $before ) );
			if ( $removed || $added ) {
				$diff[ $kind ] = array(
					'before' => array_map( static fn ( $v ) => json_decode( $v, true ), $removed ),
					'after'  => array_map( static fn ( $v ) => json_decode( $v, true ), $added ),
				);
			}
		}
		return array(
			'dry_run'                                => true,
			'container_path'                         => $snapshot['container'],
			'target_path'                            => $snapshot['path'],
			'previous_version_id'                    => $snapshot['live']['containerVersionId'] ?? null,
			'expected_fingerprint'                   => self::hash( array( home_url(), Connections::id(), Credentials::execution_identity(), get_current_user_id(), $revision, $snapshot['path'], $snapshot['live']['containerVersionId'] ?? null, $snapshot['live']['fingerprint'] ?? '', $snapshot['target']['fingerprint'] ?? '', $live, $target, $input['name'] ?? '', $input['notes'] ?? '' ) ),
			'diff'                                   => $diff,
			'changed'                                => (bool) $diff,
			'operation_outcome'                      => 'not_applied',
			'workspace_replaced_on_version_creation' => $snapshot['workspace'],
			'concurrency_guarantee'                  => 'rechecked_snapshot; Google publish fingerprint protects target version, not live head',
		);
	}
	public static function workspace( array $input ): array {
		return self::run( $input, true );
	}
	public static function version( array $input ): array {
		if ( ! empty( $input['query'] ) || ! empty( $input['body'] ) ) {
			return self::failed( 'f3_google_gtm_publish_parameters', 'Use expected_fingerprint da simulação; query e body não são aceitos no fluxo de publicação.' );
		}
		$input['path'] = $input['path'] ?? $input['path_params']['path'] ?? '';
		return self::run( $input, false );
	}
	public static function run( array $input, bool $workspace ): array {
		$path        = (string) ( $input['path'] ?? '' );
		$dry         = ! array_key_exists( 'dry_run', $input ) || true === $input['dry_run'];
		$fingerprint = (string) ( $input['expected_fingerprint'] ?? '' );
		if ( ! $dry && ! preg_match( '/^[a-f0-9]{64}$/D', $fingerprint ) ) {
			return self::failed( 'f3_google_gtm_preview_required', 'Simule primeiro e informe expected_fingerprint.' );
		}
		$lock = Lock::acquire( 'gtm-publish:' . preg_replace( '~/(workspaces|versions)/.*$~', '', $path ), 3600 );
		if ( null === $lock ) {
			return self::failed(
				'f3_google_gtm_busy',
				'Há uma publicação em andamento.',
				array(
					'retryable'      => true,
					'retry_after_ms' => 5000,
				)
			);
		}
		try {
			$id       = self::hash( array( Connections::id(), $path, $fingerprint ) );
			$previous = $dry ? null : Records::get( 'gtmpublish', $id );
			if ( null !== $previous ) {
				if ( ( $previous['actor'] ?? null ) !== get_current_user_id() ) {
					return self::failed( 'f3_google_gtm_owner', 'Publicação pertence a outro usuário.' );
				}
				return self::result( $previous ) + array( 'replayed' => true );
			}
			$snapshot = self::snapshot( $path, $workspace );
			if ( is_wp_error( $snapshot ) ) {
				return Response::fail( $snapshot, array( 'operation_outcome' => 'not_applied' ) );
			}
			$preview = self::preview( $snapshot, $input );
			if ( is_wp_error( $preview ) ) {
				return Response::fail( $preview, array( 'operation_outcome' => 'not_applied' ) );
			}
			if ( $dry ) {
				return Response::ok( $preview );
			}
			if ( ! hash_equals( $preview['expected_fingerprint'], $fingerprint ) ) {
				return self::failed(
					'f3_google_gtm_stale_preview',
					'O conteúdo ou a versão publicada mudou. Execute nova simulação.',
					array(
						'conflict'            => true,
						'current_fingerprint' => $preview['expected_fingerprint'],
					)
				);
			}
			$row = array(
				'id'                   => $id,
				'connection_id'        => Connections::id(),
				'actor'                => get_current_user_id(),
				'created_at'           => time(),
				'container_path'       => $snapshot['container'],
				'source_path'          => $path,
				'previous_version_id'  => $preview['previous_version_id'],
				'state'                => 'prepared',
				'operation_outcome'    => 'not_applied',
				'expected_fingerprint' => $fingerprint,
			);
			if ( ! Records::insert( 'gtmpublish', $id, $row ) ) {
				return self::failed( 'f3_google_gtm_journal', 'Não foi possível reservar o registro de publicação.' );
			}
			Audit::before(
				array(
					'container_path'       => $snapshot['container'],
					'published_version_id' => $preview['previous_version_id'],
					'fingerprint'          => $snapshot['live']['fingerprint'] ?? null,
				)
			);
			$version = $snapshot['target'];
			if ( $workspace ) {
				$row['state']             = 'creating_version';
				$row['operation_outcome'] = 'unknown';
				if ( ! Records::put( 'gtmpublish', $id, $row )['success'] ) {
					return self::failed( 'f3_google_gtm_journal', 'Registro anterior à criação não confirmado.' );
				}
				$created = Api::call(
					'containers.workspaces.create_version',
					array( 'path' => $path ),
					array(),
					array(
						'name'  => $input['name'] ?? 'Publicado pelo MCP Google',
						'notes' => $input['notes'] ?? '',
					)
				);
				if ( is_wp_error( $created ) ) {
					return self::finish( $row, 'unknown', $created->get_error_code() );
				}
				$version                   = $created['containerVersion'] ?? array();
				$row['new_workspace_path'] = $created['newWorkspacePath'] ?? null;
				$row['new_version_id']     = $version['containerVersionId'] ?? null;
				$row['new_version_path']   = $version['path'] ?? null;
				if ( ! empty( $created['compilerError'] ) || ! empty( $created['syncStatus']['mergeConflict'] ) || ! empty( $created['syncStatus']['syncError'] ) || empty( $version['path'] ) || self::content( $version ) !== self::content( $snapshot['target'] ) ) {
					return self::finish( $row, 'version_created_not_published', 'f3_google_gtm_version_mismatch' );
				}
			}
			$row['new_version_id']   = $version['containerVersionId'] ?? null;
			$row['new_version_path'] = $version['path'] ?? $path;
			// Check the live head again after version creation. The API has no atomic live-head CAS.
			$live = self::live( $snapshot['container'] );
			if ( is_wp_error( $live ) || ( $live['containerVersionId'] ?? null ) !== $preview['previous_version_id'] || ( $live['fingerprint'] ?? '' ) !== ( $snapshot['live']['fingerprint'] ?? '' ) ) {
				return self::finish( $row, $workspace ? 'version_created_not_published' : 'not_published', 'f3_google_gtm_live_changed' );
			}
			$row['state']             = 'publishing';
			$row['operation_outcome'] = 'unknown';
			if ( ! Records::put( 'gtmpublish', $id, $row )['success'] ) {
				return self::finish( $row, $workspace ? 'version_created_not_published' : 'not_published', 'f3_google_gtm_journal' );
			}
			self::$publishing = true;
			try {
				$published = Api::call( 'containers.versions.publish', array( 'path' => $row['new_version_path'] ), array( 'fingerprint' => $version['fingerprint'] ?? '' ) );
			} finally {
				self::$publishing = false;
			}
			if ( is_wp_error( $published ) ) {
				return self::finish( $row, 'unknown', $published->get_error_code() );
			}
			if ( ! empty( $published['compilerError'] ) ) {
				return self::finish( $row, $workspace ? 'version_created_not_published' : 'not_published', 'f3_google_gtm_compiler' );
			}
			$confirmed = self::live( $snapshot['container'] );
			if ( is_wp_error( $confirmed ) || ( $confirmed['containerVersionId'] ?? null ) !== $row['new_version_id'] ) {
				return self::finish( $row, 'unknown', 'f3_google_gtm_publish_unconfirmed' );
			}
			Audit::after(
				array(
					'published_version_id' => $row['new_version_id'],
					'previous_version_id'  => $row['previous_version_id'],
				)
			);
			return self::finish( $row, 'published' );
		} finally {
			Lock::release( $lock );
		}
	}
	private static function finish( array $row, string $state, ?string $code = null ): array {
		$row['state']             = $state;
		$row['updated_at']        = time();
		$row['error_code']        = $code;
		$row['operation_outcome'] = 'published' === $state ? 'applied' : ( 'version_created_not_published' === $state ? 'partial' : ( 'not_published' === $state ? 'not_applied' : 'unknown' ) );
		$saved                    = Records::put( 'gtmpublish', $row['id'], $row );
		$result                   = self::result( $row );
		if ( ! $saved['success'] ) {
			$result['journal_warning'] = $saved['error_code'] ?? 'f3_google_gtm_journal';
		}
		Audit::after(
			array(
				'state'                => $state,
				'previous_version_id'  => $row['previous_version_id'],
				'published_version_id' => 'published' === $state ? $row['new_version_id'] : null,
				'created_version_id'   => $row['new_version_id'] ?? null,
			)
		);
		return $result;
	}
	private static function result( array $row ): array {
		return array(
			'success'             => 'published' === $row['state'],
			'publication_id'      => $row['id'],
			'state'               => $row['state'],
			'container_path'      => $row['container_path'],
			'previous_version_id' => $row['previous_version_id'],
			'new_version_id'      => $row['new_version_id'] ?? null,
			'new_version_path'    => $row['new_version_path'] ?? null,
			'new_workspace_path'  => $row['new_workspace_path'] ?? null,
			'operation_outcome'   => $row['operation_outcome'],
			'error_code'          => $row['error_code'] ?? null,
			'retryable'           => false,
			'message'             => 'published' === $row['state'] ? 'Versão publicada e conferida.' : 'Publicação não confirmada. Consulte o registro e a versão publicada antes de uma nova escrita.',
		);
	}
	public static function register(): void {
		foreach ( array(
			'publicar' => true,
			'reverter' => false,
		) as $name => $workspace ) {
			Ability::register(
				'gtm/' . $name,
				'gtm',
				array(
					'label'        => 'GTM: ' . $name,
					'mode'         => 'write',
					'description'  => 'Simular é o padrão. A publicação exige expected_fingerprint da prévia. Reversão republica a versão indicada; criação de versão substitui o workspace.',
					'input_schema' => array(
						'required'   => array( 'path' ),
						'properties' => array(
							'path'                 => array( 'type' => 'string' ),
							'simular'              => array(
								'type'    => 'boolean',
								'default' => true,
							),
							'dry_run'              => array( 'type' => 'boolean' ),
							'expected_fingerprint' => array( 'type' => 'string' ),
							'name'                 => array(
								'type'      => 'string',
								'maxLength' => 256,
							),
							'notes'                => array(
								'type'      => 'string',
								'maxLength' => 4096,
							),
						),
					),
					'callback'     => static fn ( array $i )=>self::run( $i, $workspace ),
				)
			);
		}
		Ability::register(
			'gtm/get-publication',
			'gtm',
			array(
				'label'        => 'GTM: consultar publicação',
				'description'  => 'Consulta local do diário, sem repetir escritas.',
				'input_schema' => array(
					'required'   => array( 'publication_id' ),
					'properties' => array(
						'publication_id' => array(
							'type'    => 'string',
							'pattern' => '^[a-f0-9]{64}$',
						),
					),
				),
				'callback'     => static function ( array $i ): array {
							$row = Records::get( 'gtmpublish', $i['publication_id'] );
					if ( ! $row || ( $row['connection_id'] ?? '' ) !== Connections::id() || ( $row['actor'] ?? 0 ) !== get_current_user_id() ) {
						return self::failed( 'f3_google_gtm_publication_missing', 'Publicação não encontrada para esta identidade.' );
					}
					return Response::ok( array( 'publication' => self::result( $row ) ) );
				},
			)
		);
	}
}
