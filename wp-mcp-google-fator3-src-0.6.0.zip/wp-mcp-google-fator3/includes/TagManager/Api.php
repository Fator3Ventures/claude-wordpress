<?php
/**
 * Typed facade over pinned Discovery contracts.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\TagManager;

use Fator3\McpGoogle\{
	Generic\Discovery, Generic\ExecuteAction, Options, Connections
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Api {
	public const PREFIX = 'tagmanager.accounts.';
	public static function call( string $method, array $path = array(), array $query = array(), ?array $body = null ) {
		return ExecuteAction::call( 'tag-manager', self::PREFIX . $method, $path, $query, $body );
	}
	public static function container( array $input ) {
		$path = $input['container_path'] ?? Options::get( Connections::BINDINGS, array() )['gtm_container_path'] ?? '';
		return is_string( $path ) && preg_match( '~^accounts/[0-9]+/containers/[0-9]+$~D', $path ) ? $path : new \WP_Error( 'f3_google_gtm_container', 'Informe container_path como accounts/123/containers/456.' );
	}
	public static function all( string $method, string $parent_path, string $field ) {
		$out   = array();
		$seen  = array();
		$query = array();
		do {
			$page = self::call( $method, array( 'parent' => $parent_path ), $query );
			if ( is_wp_error( $page ) ) {
				return $page;
			}
			if ( isset( $page[ $field ] ) && ! is_array( $page[ $field ] ) ) {
				return new \WP_Error( 'f3_google_gtm_response', 'Coleção inválida na resposta GTM.' );
			}
			$out  = array_merge( $out, $page[ $field ] ?? array() );
			$next = $page['nextPageToken'] ?? '';
			if ( count( $out ) > 20000 || count( $seen ) > 100 || ( $next && isset( $seen[ $next ] ) ) ) {
				return new \WP_Error( 'f3_google_gtm_pagination', 'Paginação incompleta; reduza o escopo antes de publicar.' );
			}
			$seen[ $next ] = true;
			$query         = array( 'pageToken' => $next );
		} while ( $next );
		return $out;
	}
	public static function document(): array {
		static $doc;
		if ( null === $doc ) {
			$doc = require __DIR__ . '/../Data/TagManager.php';}
		return $doc;
	}
	/** JSON Schema expansion for local registration; execution also validates official types. */
	public static function schema( array $node, array $seen = array() ): array {
		if ( isset( $node['$ref'] ) ) {
			$name = $node['$ref'];
			if ( isset( $seen[ $name ] ) ) {
				return array(
					'type'                 => 'object',
					'additionalProperties' => true,
				);
			}
			$seen[ $name ] = true;
			$node          = self::document()['schemas'][ $name ] ?? array( 'type' => 'object' );
		}
		$out = array_intersect_key( $node, array_flip( array( 'type', 'description', 'enum', 'pattern' ) ) );
		if ( isset( $node['properties'] ) ) {
			foreach ( $node['properties'] as $key => $value ) {
				$out['properties'][ $key ] = self::schema( $value, $seen );
			}
			$out['additionalProperties'] = isset( $node['additionalProperties'] ) ? self::schema( $node['additionalProperties'], $seen ) : false;
		}
		if ( isset( $node['items'] ) ) {
			$out['items'] = self::schema( $node['items'], $seen );
		}
		return $out;
	}
}
