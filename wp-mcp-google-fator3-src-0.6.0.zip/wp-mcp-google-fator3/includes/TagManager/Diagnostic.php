<?php
/**
 * Static evidence from the published container and this site's Core slots.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\TagManager;

use Fator3\McpGoogle\{
	Ability, Response
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Diagnostic {
	private static function option( string $key ) {
		return class_exists( '\\F3Base_Options' ) ? \F3Base_Options::ler( $key ) : get_option( $key, '' );
	}
	public static function slots(): array {
		$ads = self::option( 'f3base_google_ads' );
		return array(
			'ga4'        => (string) self::option( 'f3base_ga4_measurement_id' ),
			'google_ads' => is_array( $ads ) ? (string) ( $ads['conversion_id'] ?? '' ) : '',
			'meta'       => (string) self::option( 'f3base_meta_pixel_id' ),
			'linkedin'   => (string) self::option( 'f3base_linkedin_partner_id' ),
		);
	}
	public static function analyze( array $version, array $slots ): array {
		$constants = array();
		foreach ( $version['variable'] ?? array() as $v ) {
			if ( ( $v['type'] ?? '' ) === 'c' ) {
				foreach ( $v['parameter'] ?? array() as $p ) {
					if ( ( $p['key'] ?? '' ) === 'value' && is_string( $p['value'] ?? null ) ) {
						$constants[ $v['name'] ] = $p['value'];
					}
				}
			}
		}
		$matches    = array();
		$consent    = array();
		$unresolved = array();
		foreach ( $version['tag'] ?? array() as $tag ) {
			// IDs must be found in tag parameters, never metadata such as tagId or name.
			$json = (string) wp_json_encode( $tag['parameter'] ?? array() );
			foreach ( $constants as $name => $value ) {
				$json = str_replace( '{{' . $name . '}}', $value, $json );
			}
			$dynamic = str_contains( $json, '{{' ) || ( $tag['type'] ?? '' ) === 'html';
			if ( $dynamic ) {
				$unresolved[] = array(
					'tag_id' => $tag['tagId'] ?? null,
					'name'   => $tag['name'] ?? '',
					'reason' => ( $tag['type'] ?? '' ) === 'html' ? 'custom_html_not_executed' : 'dynamic_variable',
				);
			}
			foreach ( $slots as $service => $expected ) {
				if ( '' !== $expected && preg_match( '~(?<![A-Za-z0-9_-])' . preg_quote( $expected, '~' ) . '(?![A-Za-z0-9_-])~', $json ) ) {
					$matches[ $service ][] = array(
						'tag_id'             => $tag['tagId'] ?? null,
						'name'               => $tag['name'] ?? '',
						'state'              => $dynamic ? 'potential_match' : 'literal_match',
						'paused'             => ! empty( $tag['paused'] ),
						'firing_trigger_ids' => $tag['firingTriggerId'] ?? array(),
					);
				}
			}
			if ( isset( $tag['consentSettings'] ) || preg_match( '/consent|ad_storage|analytics_storage|ad_user_data|ad_personalization/i', $json ) ) {
				$consent[] = array(
					'tag_id'   => $tag['tagId'] ?? null,
					'name'     => $tag['name'] ?? '',
					'type'     => $tag['type'] ?? '',
					'settings' => $tag['consentSettings'] ?? null,
					'evidence' => 'static_configuration',
				);
			}
		}
		$out = array();
		foreach ( $slots as $service => $id ) {
			$out[ $service ] = array(
				'expected_id' => $id,
				'state'       => '' === $id ? 'not_configured' : ( ! empty( $matches[ $service ] ) ? 'matches_found' : ( $unresolved ? 'unresolved' : 'not_found' ) ),
				'matches'     => $matches[ $service ] ?? array(),
			);
		}
		return array(
			'version_id'       => $version['containerVersionId'] ?? null,
			'slots'            => $out,
			'consent_tags'     => $consent,
			'unresolved_tags'  => $unresolved,
			'runtime_verified' => false,
			'scope'            => 'published_version_static_analysis',
			'limitations'      => array( 'A literal match does not prove tag firing or delivery.', 'Dynamic variables and custom HTML require runtime verification.', 'Consent configuration is not proof of consent behavior in the browser.' ),
		);
	}
	public static function run( array $input ): array {
		$container = Api::container( $input );
		if ( is_wp_error( $container ) && empty( $input['container_path'] ) ) {
			$public = (string) self::option( 'f3base_gtm_container_id' );
			if ( preg_match( '/^GTM-[A-Z0-9]+$/D', $public ) ) {
				$found = Api::call( 'containers.lookup', array(), array( 'tagId' => $public ) );
				if ( is_wp_error( $found ) ) {
					return Response::fail( $found );
				}
				$container = Api::container( array( 'container_path' => $found['path'] ?? '' ) );
			}
		}
		if ( is_wp_error( $container ) ) {
			return Response::fail( $container );
		}
		$live = Api::call( 'containers.versions.live', array( 'parent' => $container ) );
		if ( is_wp_error( $live ) ) {
			return Response::fail( $live );
		}
		return Response::ok(
			array(
				'container_path' => $container,
				'core_available' => class_exists( '\\F3Base_Options' ),
			) + self::analyze( $live, self::slots() )
		);
	}
	public static function register(): void {
		Ability::register(
			'gtm/diagnostico',
			'gtm',
			array(
				'label'        => 'GTM: diagnóstico da versão publicada',
				'description'  => 'Compara os IDs do contêiner publicado com os slots locais do Core e identifica configuração de consentimento. Conteúdo dinâmico é reportado como inconclusivo.',
				'input_schema' => array( 'properties' => array( 'container_path' => array( 'type' => 'string' ) ) ),
				'callback'     => array( self::class, 'run' ),
			)
		);
	}
}
