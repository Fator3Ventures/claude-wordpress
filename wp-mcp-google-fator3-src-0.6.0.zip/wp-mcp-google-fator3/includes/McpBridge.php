<?php
/**
 * Adds independently annotated query/mutation tools to a compatible MCP channel.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class McpBridge {
	public static function init(): void {
		add_filter(
			'mcp_adapter_default_server_config',
			static function ( array $config ): array {
				$config['tools'] = array_values( array_unique( array_merge( $config['tools'] ?? array(), array( 'google/mcp-read', 'google/mcp-write' ) ) ) );
				return $config;
			}
		);
	}
	public static function dispatch( array $input, bool $write ): array {
		$name       = (string) ( $input['ability'] ?? '' );
		$parameters = $input['parameters'] ?? array();
		if ( ! is_array( $parameters ) || in_array( $name, array( 'google/mcp-read', 'google/mcp-write' ), true ) ) {
			return self::failure( 'f3_google_mcp_input', 'Habilidade ou parâmetros inválidos.' );
		}
		$ability = wp_get_ability( $name );
		if ( ! $ability || 'google' !== $ability->get_category() ) {
			return self::failure( 'f3_google_mcp_ability', 'Esta ferramenta executa somente habilidades Google.' );
		}
		$meta = $ability->get_meta();
		$mode = $meta['fator3']['mode'] ?? null;
		if ( in_array( $name, array( 'google/execute-action', 'google/execute-read' ), true ) ) {
			$op = Operation::method( (string) ( $parameters['api'] ?? '' ), (string) ( $parameters['method'] ?? '' ) );
			if ( is_wp_error( $op ) ) {
				return self::failure( $op->get_error_code(), $op->get_error_message() );
			}
			$mode = $op['mode'];
		}
		if ( ( $write ? 'write' : 'read' ) !== $mode ) {
			return self::failure( 'f3_google_mcp_mode', 'A operação não pertence a esta ferramenta. Use a ferramenta de consulta ou mutação correspondente.' );
		}
		$parameters['connection_id'] = $input['connection_id'] ?? Connections::id();
		$allowed                     = Channel::authorize( $name, $parameters, 'read' === $mode );
		if ( is_wp_error( $allowed ) ) {
			return self::failure( $allowed->get_error_code(), $allowed->get_error_message() );
		}
		$result = $ability->execute( $parameters );
		if ( is_wp_error( $result ) ) {
			$result = Response::fail( $result );
		}
		if ( ! is_array( $result ) ) {
			return self::failure( 'f3_google_mcp_result', 'Resultado inválido.' );
		}
		if ( empty( $result['success'] ) ) {
			$result['error'] = $result['message'] ?? 'Operação reprovada.';
		}
		return $result;
	}
	private static function failure( string $code, string $message ): array {
		return Response::fail( new \WP_Error( $code, $message ) ) + array( 'error' => $message );
	}
	public static function register(): void {
		foreach ( array(
			'read'  => false,
			'write' => true,
		) as $mode => $write ) {
			Ability::register(
				'google/mcp-' . $mode,
				'any',
				array(
					'label'        => $write ? 'Google: executar mutação' : 'Google: executar consulta',
					'description'  => $write ? 'Executa habilidades de mutação com os mesmos gates, políticas e confirmações.' : 'Executa exclusivamente habilidades classificadas como consulta; recusa mutações antes da execução.',
					'mode'         => $write ? 'write' : 'read',
					'input_schema' => array(
						'required'   => array( 'ability' ),
						'properties' => array(
							'ability'    => array( 'type' => 'string' ),
							'parameters' => array( 'type' => 'object' ),
						),
					),
					'callback'     => static fn ( array $input ) => self::dispatch( $input, $write ),
					'meta'         => array(
						'fator3'      => array( 'executes_ability' => true ),
						'annotations' => array(
							'readonly'    => ! $write,
							'destructive' => $write,
						),
					),
				)
			);
		}
	}
}
