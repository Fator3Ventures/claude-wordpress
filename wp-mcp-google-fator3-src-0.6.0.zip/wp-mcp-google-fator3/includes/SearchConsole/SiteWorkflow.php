<?php
/**
 * Generic site preparation and read-only migration observations.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\SearchConsole;

use Fator3\McpGoogle\{
	Ability, Automation\Execution, Automation\Jobs, Generic\ExecuteAction, Http\PublicPage, Operation, Response, Settings, Setup
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class SiteWorkflow {

	public static function prepare( array $input ): array {
		return Execution::run( static fn () => self::prepare_steps( $input ) );
	}
	private static function prepare_steps( array $input ): array {
		$input = Operation::normalize( $input );
		if ( is_wp_error( $input ) ) {
			return Response::fail( $input );
		}
		$site = Api::site( $input['site_url'] ?? '' );
		if ( is_wp_error( $site ) ) {
			return Response::fail( $site );
		}
		$sitemap = (string) ( $input['sitemap_url'] ?? '' );
		$urls    = $input['urls'] ?? array();
		if ( ! is_array( $urls ) || count( $urls ) > 500 || ! Workflow::belongs( $sitemap, $site ) ) {
			return Response::fail( new \WP_Error( 'f3_google_prepare_site_input', 'Informe sitemap pertencente à propriedade e até 500 URLs explícitas.' ) );
		}
		foreach ( $urls as $url ) {
			if ( ! is_string( $url ) || ! Workflow::belongs( $url, $site ) ) {
				return Response::fail( new \WP_Error( 'f3_google_prepare_site_input', 'Todas as URLs devem pertencer à propriedade.' ) );
			}
		}
		$revision = null;
		if ( ! empty( $input['save_binding'] ) ) {
			if ( ! isset( $input['expected_revision'] ) || ! is_string( $input['expected_revision'] ) ) {
				return Response::fail( new \WP_Error( 'f3_google_revision_required', 'save_binding exige expected_revision obtida no contrato de configuração.' ) );
			}
			$revision = Settings::revision();
			if ( is_wp_error( $revision ) ) {
				return Response::fail( $revision );
			}
			if ( ! hash_equals( $revision, $input['expected_revision'] ) ) {
				return Settings::conflict();
			}
		}
		$hosts  = array_values( array_unique( array_merge( array( (string) wp_parse_url( $sitemap, PHP_URL_HOST ) ), array_map( static fn ( $url ) => (string) wp_parse_url( $url, PHP_URL_HOST ), $urls ) ) ) );
		$steps  = array();
		$access = ExecuteAction::call( 'search-console', 'webmasters.sites.get', array( 'siteUrl' => $site ), array(), null, array( 'mode' => 'read' ) );
		if ( is_wp_error( $access ) || ! in_array( $access['permissionLevel'] ?? '', array( 'siteOwner', 'siteFullUser' ), true ) ) {
			return Response::ok(
				array(
					'ready'             => false,
					'steps'             => array(
						array(
							'step'   => 'access',
							'status' => 'blocked',
							'result' => is_wp_error( $access ) ? Response::fail( $access ) : $access,
						),
					),
					'pending'           => array( 'grant_or_verify_property' ),
					'dns_changed'       => false,
					'operation_outcome' => 'not_applied',
					'message'           => 'Conceda acesso à propriedade existente ou conclua sua verificação no Google.',
				)
			);
		}
		$steps[]   = array(
			'step'             => 'access',
			'status'           => 'passed',
			'permission_level' => $access['permissionLevel'],
		);
		$published = PublicPage::fetch( $sitemap, $hosts, 0 );
		$valid     = ! empty( $published['success'] ) && 200 === ( $published['http_status'] ?? 0 ) && preg_match( '/<(?:[A-Za-z]+:)?(?:sitemapindex|urlset)[\s>]/', (string) ( $published['body'] ?? '' ) );
		unset( $published['body'] );
		$steps[] = array(
			'step'   => 'published_sitemap',
			'status' => $valid ? 'passed' : 'failed',
			'result' => $published,
		);
		$check   = Workflow::sitemap(
			array(
				'site_url'    => $site,
				'sitemap_url' => $sitemap,
				'check_only'  => true,
			)
		);
		$steps[] = array(
			'step'   => 'registered_sitemap',
			'status' => $check['success'] ? 'checked' : 'failed',
			'result' => $check,
		);
		if ( ! $valid || ! $check['success'] ) {
			return Response::fail(
				new \WP_Error( 'f3_google_prepare_site_blocked', 'Pré-requisitos do sitemap não confirmados.' ),
				array(
					'steps'             => $steps,
					'ready'             => false,
					'operation_outcome' => 'not_applied',
				)
			);
		}
		if ( $input['dry_run'] ?? true ) {
			return Response::ok(
				array(
					'dry_run'           => true,
					'steps'             => $steps,
					'planned'           => array(
						'submit_sitemap' => ! empty( $check['submission_required'] ),
						'inspect_urls'   => array_values( array_unique( $urls ) ),
						'save_binding'   => ! empty( $input['save_binding'] ),
					),
					'ready'             => false,
					'dns_changed'       => false,
					'operation_outcome' => 'not_applied',
				)
			);
		}
		if ( null !== $revision ) {
			$current = Settings::revision();
			if ( is_wp_error( $current ) ) {
				return Response::fail( $current );
			}
			if ( ! hash_equals( $revision, $current ) ) {
				return Settings::conflict();
			}
		}
		if ( ! empty( $check['submission_required'] ) ) {
			$sent    = Abilities::run(
				'submit-sitemap',
				array(
					'site_url'    => $site,
					'sitemap_url' => $sitemap,
				)
			);
			$steps[] = array(
				'step'   => 'submit_sitemap',
				'status' => $sent['success'] ? 'applied' : 'failed',
				'result' => $sent,
			);
			if ( ! $sent['success'] ) {
				return Response::fail(
					new \WP_Error( 'f3_google_prepare_site_interrupted', 'Submissão não confirmada. Consulte o sitemap antes de repetir.' ),
					array(
						'steps'             => $steps,
						'operation_outcome' => $sent['operation_outcome'] ?? 'unknown',
					)
				);
			}
		}
		$after   = Workflow::sitemap(
			array(
				'site_url'    => $site,
				'sitemap_url' => $sitemap,
				'check_only'  => true,
			)
		);
		$steps[] = array(
			'step'   => 'registration_check',
			'result' => $after,
		);
		if ( ! empty( $input['save_binding'] ) ) {
			$saved   = Setup::apply(
				array(
					'bindings'          => array(
						'gsc_site_url' => $site,
						'sitemap_url'  => $sitemap,
					),
					'expected_revision' => $revision,
					'validate_access'   => false,
				)
			);
			$steps[] = array(
				'step'   => 'binding',
				'result' => $saved,
			);
			if ( ! $saved['success'] ) {
				return Response::fail(
					new \WP_Error( 'f3_google_prepare_site_partial', 'Sitemap processado; vínculo local não persistido.' ),
					array(
						'steps'             => $steps,
						'operation_outcome' => 'partial',
					)
				);
			}
		}
		$job = $urls ? Jobs::inspect(
			array(
				'site_url'        => $site,
				'urls'            => $urls,
				'execution_mode'  => $input['execution_mode'] ?? 'auto',
				'idempotency_key' => $input['idempotency_key'] ?? '',
			)
		) : null;
		return Response::ok(
			array(
				'steps'              => $steps,
				'inspection'         => $job,
				'ready'              => ! empty( $after['success'] ) && ! empty( $after['registered'] ) && ( null === $job || ! empty( $job['success'] ) ),
				'indexing_confirmed' => false,
				'dns_changed'        => false,
				'operation_outcome'  => ! empty( $check['submission_required'] ) ? 'applied' : 'not_applied',
				'message'            => 'Registro de sitemap e indexação são estados independentes.',
			)
		);
	}
	public static function migration( array $input ): array {
		return Execution::run( static fn () => self::migration_steps( $input ) );
	}
	private static function migration_steps( array $input ): array {
		$source = Api::site( $input['source_site_url'] ?? '' );
		$target = Api::site( $input['target_site_url'] ?? '' );
		$pairs  = $input['pairs'] ?? null;
		if ( is_wp_error( $source ) || is_wp_error( $target ) || ! is_array( $pairs ) || ! $pairs || count( $pairs ) > 25 ) {
			return Response::fail( new \WP_Error( 'f3_google_migration_input', 'Informe propriedades existentes e entre 1 e 25 pares.' ) );
		}
		if ( ! \Fator3\McpGoogle\Policy::permitted( 'gsc', $source ) || ! \Fator3\McpGoogle\Policy::permitted( 'gsc', $target ) ) {
			return Response::fail( new \WP_Error( 'f3_google_policy_denied', 'Propriedade fora da política.' ) );
		}
		$range = \Fator3\McpGoogle\Unified\DateRange::resolve( $input['date_range'] ?? 'last_28_days' );
		if ( is_wp_error( $range ) ) {
			return Response::fail( $range );
		}
		$hosts = array();
		foreach ( $pairs as $pair ) {
			if ( ! is_array( $pair ) || ! Workflow::belongs( (string) ( $pair['source_url'] ?? '' ), $source ) || ! Workflow::belongs( (string) ( $pair['target_url'] ?? '' ), $target ) ) {
				return Response::fail( new \WP_Error( 'f3_google_migration_input', 'Cada URL precisa pertencer à propriedade informada.' ) );
			}
			$hosts[] = (string) wp_parse_url( $pair['source_url'], PHP_URL_HOST );
			$hosts[] = (string) wp_parse_url( $pair['target_url'], PHP_URL_HOST );
		}
		$hosts    = array_values( array_unique( $hosts ) );
		$results  = array();
		$complete = true;
		foreach ( $pairs as $pair ) {
			if ( Execution::remaining() < 1 ) {
				$complete = false;
				break;
			}
			$item = array(
				'source_url' => $pair['source_url'],
				'target_url' => $pair['target_url'],
			);
			foreach ( array(
				'source' => $source,
				'target' => $target,
			) as $side => $site ) {
				$url  = $pair[ $side . '_url' ];
				$live = PublicPage::fetch( $url, $hosts );
				unset( $live['body'] );
				$indexed       = Workflow::inspect(
					array(
						'site_url'       => $site,
						'inspection_url' => $url,
					)
				);
				$stats         = ExecuteAction::call(
					'search-console',
					'webmasters.searchanalytics.query',
					array( 'siteUrl' => $site ),
					array(),
					array(
						'startDate'             => $range['from'],
						'endDate'               => $range['to'],
						'dimensions'            => array( 'page' ),
						'dimensionFilterGroups' => array(
							array(
								'filters' => array(
									array(
										'dimension'  => 'page',
										'operator'   => 'equals',
										'expression' => $url,
									),
								),
							),
						),
						'rowLimit'              => 1,
					),
					array( 'mode' => 'read' )
				);
				$item[ $side ] = array(
					'live'                      => $live,
					'indexed'                   => $indexed,
					'impressions'               => is_wp_error( $stats ) ? null : ( $stats['rows'][0]['impressions'] ?? null ),
					'search_analytics_observed' => ! is_wp_error( $stats ) && ! empty( $stats['rows'] ),
					'coverage'                  => 'Search Analytics pode omitir dados; ausência de linhas não comprova zero impressões.',
					'date_range'                => $range,
					'error'                     => is_wp_error( $stats ) ? Response::fail( $stats ) : null,
				);
				if ( empty( $live['success'] ) || empty( $indexed['success'] ) || is_wp_error( $stats ) ) {
					$complete = false;
				}
			}
			$results[] = $item;
		}
		return Response::ok(
			array(
				'results'                      => $results,
				'complete'                     => $complete,
				'observed_at'                  => gmdate( 'c' ),
				'recheck_after'                => gmdate( 'c', time() + max( 1, min( 90, (int) ( $input['recheck_days'] ?? 7 ) ) ) * 86400 ),
				'redirect_removal_recommended' => false,
				'writes_performed'             => false,
				'operation_outcome'            => 'not_applicable',
				'message'                      => 'HTTP atual, estado indexado e dados de pesquisa têm coberturas e datas distintas. Nenhum redirect é alterado.',
			)
		);
	}
	public static function register(): void {
		Ability::register(
			'gsc/preparar-site',
			'gsc',
			array(
				'label'        => 'Search Console: preparar site',
				'description'  => 'Fluxo genérico com simulação por padrão: acesso, publicação/registro de sitemap, vínculo opcional e inspeções persistidas. Não altera DNS nem cria propriedade.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'site_url', 'sitemap_url' ),
					'properties' => array(
						'site_url'          => array( 'type' => 'string' ),
						'sitemap_url'       => array( 'type' => 'string' ),
						'urls'              => array(
							'type'     => 'array',
							'items'    => array( 'type' => 'string' ),
							'maxItems' => 500,
						),
						'dry_run'           => array(
							'type'    => 'boolean',
							'default' => true,
						),
						'simular'           => array( 'type' => 'boolean' ),
						'save_binding'      => array( 'type' => 'boolean' ),
						'expected_revision' => array( 'type' => 'string' ),
						'execution_mode'    => array(
							'type' => 'string',
							'enum' => array( 'auto', 'queued' ),
						),
						'idempotency_key'   => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'prepare' ),
			)
		);
		Ability::register(
			'gsc/migracao-conferir',
			'gsc',
			array(
				'label'        => 'Search Console: conferir migração',
				'description'  => 'Somente leitura: pares origem/destino, redirects limitados, canônicas conhecidas, rastreamento e impressões. Não recomenda apagar redirects por ausência de dados.',
				'input_schema' => array(
					'required'   => array( 'source_site_url', 'target_site_url', 'pairs' ),
					'properties' => array(
						'source_site_url' => array( 'type' => 'string' ),
						'target_site_url' => array( 'type' => 'string' ),
						'pairs'           => array(
							'type'     => 'array',
							'maxItems' => 25,
							'items'    => array(
								'type'                 => 'object',
								'required'             => array( 'source_url', 'target_url' ),
								'properties'           => array(
									'source_url' => array( 'type' => 'string' ),
									'target_url' => array( 'type' => 'string' ),
								),
								'additionalProperties' => false,
							),
						),
						'date_range'      => array( 'type' => array( 'string', 'object' ) ),
						'recheck_days'    => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 90,
						),
					),
				),
				'callback'     => array( self::class, 'migration' ),
			)
		);
	}
}
