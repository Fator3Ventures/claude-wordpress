<?php
/**
 * Resumable final page/date snapshots for the Site Core importer.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\SearchConsole;

use Fator3\McpGoogle\{
	Ability, Audit, Auth\Credentials, Automation\Execution, Automation\Jobs, Connections, Gate, Lock, Options, Records, Response, Settings, Storage\Admission
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Daily {
	public const OPTION     = 'f3_mcp_google_gsc_import';
	private const PAGE_SIZE = 1000;
	public static function schema(): array {
		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'required'             => array( 'enabled' ),
			'properties'           => array(
				'enabled'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'site_url'   => array( 'type' => 'string' ),
				'start_date' => array(
					'type'   => 'string',
					'format' => 'date',
				),
			),
		);
	}
	public static function available(): bool {
		return is_callable( array( 'F3Base_Inteligencia', 'gsc_importar' ) );
	}
	private static function today(): \DateTimeImmutable {
		return new \DateTimeImmutable( 'today', new \DateTimeZone( 'America/Los_Angeles' ) );
	}
	public static function configure( array $input ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::error( 'f3_google_forbidden', 'Configuração exige manage_options.' );
		}
		$config = $input['configuration'] ?? array();
		if ( ! is_array( $config ) || ! is_bool( $config['enabled'] ?? null ) || array_diff( array_keys( $config ), array( 'enabled', 'site_url', 'start_date' ) ) ) {
			return self::error( 'f3_google_gsc_import_input', 'Configuração de importação inválida.' );
		}
		if ( $config['enabled'] ) {
			if ( ! self::available() ) {
				return self::error( 'f3_google_gsc_import_core', 'Site Core com f3base/gsc-importar é necessário.' );
			}
			$site = Api::site( $config['site_url'] ?? Options::get( Connections::BINDINGS, array() )['gsc_site_url'] ?? '' );
			if ( is_wp_error( $site ) ) {
				return Response::fail( $site );
			}
			if ( 'sc-domain:' . strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ) !== $site && rtrim( $site, '/' ) . '/' !== home_url( '/' ) ) {
				return self::error( 'f3_google_gsc_import_site', 'A propriedade deve corresponder ao domínio ou prefixo deste site.' );
			}
			$config['site_url'] = $site;
			$date               = $config['start_date'] ?? self::today()->modify( '-30 days' )->format( 'Y-m-d' );
			$parsed             = \DateTimeImmutable::createFromFormat( '!Y-m-d', $date, new \DateTimeZone( 'America/Los_Angeles' ) );
			if ( ! $parsed || $parsed->format( 'Y-m-d' ) !== $date || $parsed < self::today()->modify( '-16 months' ) || $parsed > self::today()->modify( '-3 days' ) ) {
				return self::error( 'f3_google_gsc_import_date', 'start_date deve estar entre os últimos 16 meses e D-3, no calendário do Search Console.' );
			}
			$config['start_date'] = $date;
			$gate                 = Gate::check( 'gsc' );
			if ( null !== $gate ) {
				return $gate;
			}
		}
		$lock = Lock::acquire( 'gsc-daily:' . Connections::id(), 60 );
		if ( null === $lock ) {
			return self::error( 'f3_google_gsc_import_busy', 'Importação em execução.' );
		}
		try {
			$saved = Settings::save( array( self::OPTION => $config ), array(), array(), $input['expected_revision'] ?? null );
			if ( ! $saved['success'] ) {
				return $saved;
			}
			$previous = Records::get( 'gscdaily', Connections::id() );
			if ( $previous && ( $previous['configuration_hash'] ?? '' ) === self::hash( $config ) && ( $previous['actor'] ?? 0 ) === get_current_user_id() && ( $previous['identity'] ?? '' ) === Credentials::execution_identity() && ( $previous['channel'] ?? null ) === self::channel_origin() ) {
				if ( $config['enabled'] ) {
					Jobs::schedule_tick();
				}
				return $saved + array( 'gsc_import' => self::status() );
			}
			$state     = array(
				'connection_id'      => Connections::id(),
				'configuration_hash' => self::hash( $config ),
				'actor'              => get_current_user_id(),
				'identity'           => Credentials::execution_identity(),
				'site'               => home_url( '/' ),
				'created_at'         => time(),
				'next_run'           => time(),
				'status'             => $config['enabled'] ? 'pending' : 'disabled',
				'channel'            => self::channel_origin(),
			);
			$persisted = Records::put( 'gscdaily', Connections::id(), $state );
			if ( ! $persisted['success'] ) {
				return Response::fail(
					new \WP_Error( 'f3_google_gsc_import_state', 'Configuração salva, mas a agenda não foi confirmada.' ),
					array(
						'configuration_persisted' => true,
						'schedule_persisted'      => false,
					)
				);
			}
			if ( $config['enabled'] ) {
				Jobs::schedule_tick();
			}
			return $saved + array( 'gsc_import' => self::status() );
		} finally {
			Lock::release( $lock );
		}
	}
	private static function hash( $value ): string {
		return hash( 'sha256', wp_json_encode( $value ) );
	}
	private static function channel_origin(): ?array {
		if ( Gate::administrative_allowed( 'google/configure-gsc-import' ) || ! class_exists( '\\Fator3\\McpFiles\\ConnectionContext' ) ) {
			return null;
		}
		$c = \Fator3\McpFiles\ConnectionContext::get();
		return is_array( $c ) ? array_intersect_key( $c, array_flip( array( 'connection_id', 'user_id', 'profile', 'abilities', 'expires', 'policy_version' ) ) ) : null;
	}
	public static function enabled(): bool {
		foreach ( Connections::registry() as $id => $metadata ) {
			$on = Connections::run( $id, static fn()=> ! empty( Options::get( self::OPTION, array() )['enabled'] ) );
			if ( true === $on ) {
				return true;
			}
		}
		return false;
	}
	public static function status(): array {
		$config = Options::get( self::OPTION, array( 'enabled' => false ) );
		$state  = Records::get( 'gscdaily', Connections::id() ) ?? array();
		return array(
			'enabled'               => ! empty( $config['enabled'] ),
			'core_available'        => self::available(),
			'configuration'         => $config,
			'status'                => $state['status'] ?? 'not_configured',
			'due'                   => ! empty( $config['enabled'] ) && ( $state['next_run'] ?? 0 ) <= time(),
			'next_run'              => $state['next_run'] ?? null,
			'last_attempt'          => $state['last_attempt'] ?? null,
			'last_success'          => $state['last_success'] ?? null,
			'last_checked_day'      => $state['last_checked_day'] ?? null,
			'last_imported_day'     => $state['last_imported_day'] ?? null,
			'current_day'           => $state['day'] ?? null,
			'next_row'              => $state['offset'] ?? 0,
			'last_error'            => $state['last_error'] ?? null,
			'last_empty_day'        => $state['last_empty_day'] ?? null,
			'rows_imported'         => $state['rows_imported'] ?? 0,
			'target_day'            => self::today()->modify( '-3 days' )->format( 'Y-m-d' ),
			'calendar'              => 'America/Los_Angeles',
			'replay_final_days'     => 3,
			'cron_requires_trigger' => true,
			'coverage'              => 'API-returned rows; completeness of all search activity is not guaranteed',
		);
	}
	public static function tick(): array {
		$config = Options::get( self::OPTION, array() );
		if ( empty( $config['enabled'] ) ) {
			return Response::ok(
				array(
					'skipped' => true,
					'reason'  => 'disabled',
				)
			);
		}
		$lock = Lock::acquire( 'gsc-daily:' . Connections::id(), 60 );
		if ( null === $lock ) {
			return Response::ok(
				array(
					'skipped' => true,
					'reason'  => 'busy',
				)
			);
		}
		try {
			$state = Records::get( 'gscdaily', Connections::id() );
			if ( ! $state || ( $state['configuration_hash'] ?? '' ) !== self::hash( $config ) ) {
				return self::error( 'f3_google_gsc_import_config_changed', 'Reconfigure a importação para confirmar a agenda.' );
			}
			if ( ( $state['next_run'] ?? 0 ) > time() ) {
				return Response::ok(
					array(
						'skipped' => true,
						'reason'  => 'not_due',
					)
				);
			}
			$actor = get_current_user_id();
			wp_set_current_user( (int) $state['actor'] );
			try {
				$origin = $state['channel'] ?? null;
				if ( $origin ) {
					if ( ! class_exists( '\\Fator3\\McpFiles\\Persistence' ) || ! class_exists( '\\Fator3\\McpFiles\\ConnectionContext' ) ) {
						return self::fail_state( $state, 'f3_google_gsc_import_origin', 'Canal que autorizou a agenda indisponível.' );
					}
					$current = \Fator3\McpFiles\Persistence::get( 'connections', $origin['connection_id'] );
					$visible = is_array( $current ) ? array_intersect_key( $current, array_flip( array( 'connection_id', 'user_id', 'profile', 'abilities', 'expires', 'policy_version' ) ) ) : null;
					if ( $visible !== $origin || ( $current['_storage']['status'] ?? '' ) !== 'active' || ( ! empty( $current['expires'] ) && $current['expires'] <= time() ) || ! \Fator3\McpFiles\ConnectionContext::credential_active( $origin['connection_id'], (int) $state['actor'] ) ) {
						return self::fail_state( $state, 'f3_google_gsc_import_origin', 'A autorização original foi revogada ou alterada. Reconfigure a agenda.' );
					}
				}
				if ( ! current_user_can( 'manage_options' ) || ! current_user_can( Options::capability() ) || ( $state['site'] ?? '' ) !== home_url( '/' ) || ( $state['identity'] ?? '' ) !== Credentials::execution_identity() ) {
					return self::fail_state( $state, 'f3_google_gsc_import_identity', 'Identidade ou permissões mudaram. Reconfigure a agenda.' );
				}
				if ( ! self::available() ) {
					return self::fail_state( $state, 'f3_google_gsc_import_core', 'Importador do Site Core indisponível.' );
				}
				$gate = Gate::check( 'gsc' );
				if ( null !== $gate ) {
					return self::fail_state( $state, $gate['error_code'] ?? 'f3_google_disabled', $gate['message'] ?? 'Acesso indisponível.' );
				}
				return Admission::run( 'google/sync-gsc-core', static fn()=>self::page( $config, $state ) );
			} finally {
				wp_set_current_user( $actor );
			}
		} finally {
			Lock::release( $lock );
		}
	}
	private static function page( array $config, array $state ): array {
		$today = self::today();
		$final = $today->modify( '-3 days' )->format( 'Y-m-d' );
		if ( empty( $state['day'] ) ) {
			$state['day']       = empty( $state['last_checked_day'] ) ? $config['start_date'] : min( $state['last_checked_day'], $today->modify( '-5 days' )->format( 'Y-m-d' ) );
			$state['day']       = max( $config['start_date'], $state['day'] );
			$state['offset']    = 0;
			$state['cycle_end'] = $final;
		}
		if ( $state['day'] > $final ) {
			$state['next_run'] = time() + 3600;
			return self::save( $state );
		}
		$state['last_attempt'] = time();
		$state['status']       = 'running';
		$state['extracted_at'] = $state['extracted_at'] ?? time();
		$result                = Api::query(
			array(
				'site_url'         => $config['site_url'],
				'start_date'       => $state['day'],
				'end_date'         => $state['day'],
				'dimensions'       => array( 'date', 'page' ),
				'data_state'       => 'final',
				'search_type'      => 'web',
				'aggregation_type' => 'byPage',
				'row_limit'        => self::PAGE_SIZE,
				'start_row'        => $state['offset'],
			)
		);
		if ( is_wp_error( $result ) ) {
			return self::fail_state( $state, $result->get_error_code(), $result->get_error_message() );
		}
		$native = $result['rows'] ?? array();
		if ( ! is_array( $native ) ) {
			return self::fail_state( $state, 'f3_google_gsc_import_response', 'Resposta de linhas inválida.' );
		}
		$lines = array();
		foreach ( $native as $row ) {
			if ( ! is_array( $row ) || ! is_array( $row['keys'] ?? null ) || count( $row['keys'] ) !== 2 || $row['keys'][0] !== $state['day'] || ! is_string( $row['keys'][1] ) || ! is_numeric( $row['clicks'] ?? null ) || ! is_numeric( $row['impressions'] ?? null ) || ! is_numeric( $row['position'] ?? null ) ) {
				return self::fail_state( $state, 'f3_google_gsc_import_response', 'Dimensões da resposta divergem do dia consultado.' );
			}
			$lines[] = array(
				'dia'        => $row['keys'][0],
				'url'        => $row['keys'][1],
				'cliques'    => $row['clicks'],
				'impressoes' => $row['impressions'],
				'posicao'    => $row['position'],
			);
		}
		$payload = array(
			'propriedade' => $config['site_url'],
			'pesquisa'    => 'web',
			'escopo'      => 'paginas',
			'dimensoes'   => array( 'date', 'page' ),
			'estado'      => 'final',
			'extraido_em' => $state['extracted_at'],
			'fonte'       => 'wp-mcp-google-fator3/' . F3_MCP_GOOGLE_VERSION,
			'cobertura'   => array(
				'completa'      => false,
				'limite_linhas' => self::PAGE_SIZE,
				'truncada'      => count( $native ) === self::PAGE_SIZE,
				'observacao'    => 'Página de consulta final por dia. A API omite linhas e não garante todos os resultados. Ausência de linha não representa zero.',
			),
			'filtros'     => array(),
			'linhas'      => array(),
		);
		$batches = array();
		$batch   = array();
		foreach ( $lines as $line ) {
			$candidate           = $payload;
			$candidate['linhas'] = array_merge( $batch, array( $line ) );
			if ( strlen( wp_json_encode( $candidate ) ) > 1000000 && $batch ) {
				$batches[] = $batch;
				$batch     = array();
			}
			$batch[] = $line;
		}
		if ( $batch ) {
			$batches[] = $batch;
		}
		foreach ( $batches as $batch ) {
			$payload['linhas'] = $batch;
			// Calls the same public Core service registered as f3base/gsc-importar; the captured administrator is revalidated on every pass.
			$import = \F3Base_Inteligencia::gsc_importar( $payload );
			Audit::log(
				'gsc:core-import',
				$config['site_url'],
				array(
					'status'        => ! empty( $import['ok'] ) ? 'ok' : 'error',
					'rows'          => count( $batch ),
					'day'           => $state['day'],
					'mode'          => 'read',
					'remote_effect' => 'read',
					'local_effect'  => 'write',
				)
			);
			if ( empty( $import['ok'] ) ) {
				return self::fail_state( $state, 'f3_google_gsc_import_rejected', 'Site Core recusou o lote: ' . ( $import['codigo'] ?? $import['error_code'] ?? 'invalid_response' ) );
			}
		}
		if ( $lines ) {
			$state['last_imported_day'] = $state['day'];
			$state['rows_imported']     = ( $state['rows_imported'] ?? 0 ) + count( $lines );
		}
		$state['offset'] += count( $native );
		unset( $state['last_error'] );
		$state['next_run'] = time();
		if ( count( $native ) < self::PAGE_SIZE ) {
			if ( 0 === $state['offset'] ) {
				$state['last_empty_day'] = $state['day'];
			}
			$state['last_checked_day'] = $state['day'];
			$next                      = ( new \DateTimeImmutable( $state['day'] ) )->modify( '+1 day' )->format( 'Y-m-d' );
			$state['offset']           = 0;
			unset( $state['extracted_at'] );
			if ( $next > $state['cycle_end'] ) {
				unset( $state['day'] );
				$state['status']       = 'completed';
				$state['last_success'] = time();
				$state['next_run']     = $today->modify( '+1 day' )->setTime( 6, 0 )->getTimestamp();
			} else {
				$state['day']    = $next;
				$state['status'] = 'pending';
			}
		} else {
			$state['status'] = 'pending';
		}
		return self::save( $state ) + array(
			'imported_rows' => count( $lines ),
			'queried_rows'  => count( $native ),
		);
	}
	private static function save( array $state ): array {
		$r = Records::put( 'gscdaily', Connections::id(), $state );
		return $r['success'] ? Response::ok(
			array(
				'state'    => $state['status'],
				'next_run' => $state['next_run'],
			)
		) : $r;
	}
	private static function fail_state( array $state, string $code, string $message ): array {
		$state['status']       = 'failed';
		$state['last_attempt'] = time();
		$state['next_run']     = time() + 900;
		$state['last_error']   = array(
			'code'    => $code,
			'message' => Ability::scrub( $message ),
		);
		$saved                 = self::save( $state );
		return self::error( $code, $message ) + array( 'state_persisted' => ! empty( $saved['success'] ) );
	}
	private static function error( string $code, string $message ): array {
		return Response::fail( new \WP_Error( $code, $message ), array( 'operation_outcome' => 'not_applied' ) );
	}
	public static function register(): void {
		Ability::register(
			'google/configure-gsc-import',
			'any',
			array(
				'label'        => 'Google: configurar importação Search Console → Core',
				'mode'         => 'write',
				'description'  => 'Agenda diária de dados finais por página e dia. Reenvia os últimos três dias finais; exige importador Core e administrador.',
				'input_schema' => array(
					'required'   => array( 'configuration', 'expected_revision' ),
					'properties' => array(
						'configuration'     => self::schema(),
						'expected_revision' => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'configure' ),
			)
		);
		Ability::register(
			'google/gsc-import-status',
			'any',
			array(
				'label'       => 'Google: estado da importação Search Console',
				'description' => 'Consulta local da agenda e dos últimos dias conferidos e importados.',
				'callback'    => static fn()=>Response::ok( self::status() ),
			)
		);
		Ability::register(
			'google/sync-gsc-core',
			'any',
			array(
				'label'       => 'Google: continuar importação Search Console',
				'mode'        => 'write',
				'description' => 'Executa uma página pendente da agenda autorizada; o cron e executar-vencidos usam a mesma operação.',
				'callback'    => static fn()=>Execution::run( static fn()=>self::tick() ),
			)
		);
	}
}
