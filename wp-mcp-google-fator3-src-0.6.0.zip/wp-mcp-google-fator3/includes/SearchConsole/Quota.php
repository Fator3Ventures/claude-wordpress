<?php
/**
 * Reserve every actual URL Inspection attempt, including retries and generic calls.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\SearchConsole;

use Fator3\McpGoogle\{Lock, Options};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Quota {

	/** Read-only rolling local budget, distinct from Google's shared quota. */
	public static function state(): array {
		$site = (string) ( Options::get( \Fator3\McpGoogle\Connections::BINDINGS, array() )['gsc_site_url'] ?? '' );
		$base = array(
			'source'             => 'local_attempt_reservations',
			'unit'               => 'http_attempts',
			'scope'              => 'this_wordpress_site_and_property',
			'google_quota_known' => false,
			'observed_at'        => time(),
			'site_url'           => $site,
			'minute_limit'       => 25,
			'day_limit'          => Options::limit( Options::INSPECTION_BUDGET ),
		);
		if ( '' === $site ) {
			return $base + array(
				'available' => false,
				'reason'    => 'default_property_not_configured',
			);
		}
		if ( ! \Fator3\McpGoogle\Policy::permitted( 'gsc', $site ) ) {
			return array(
				'available' => false,
				'reason'    => 'property_outside_policy',
			);
		}
		$stored = Options::stored( 'f3_mcp_google_quota_' . hash( 'sha256', $site ) );
		if ( ! $stored['success'] ) {
			return $base + array(
				'available' => false,
				'reason'    => 'quota_read_failed',
			);
		}
		$events = array_values( array_filter( (array) ( $stored['value']['events'] ?? array() ), static fn ( $t ) => is_int( $t ) && $t > time() - 86400 ) );
		sort( $events );
		$minute = array_values( array_filter( $events, static fn ( $t ) => $t > time() - 60 ) );
		$next   = max( count( $minute ) >= 25 ? $minute[0] + 60 : time(), count( $events ) >= $base['day_limit'] ? $events[0] + 86400 : time() );
		return $base + array(
			'available'            => true,
			'attempts_last_minute' => count( $minute ),
			'attempts_last_day'    => count( $events ),
			'remaining_minute'     => max( 0, 25 - count( $minute ) ),
			'remaining_day'        => max( 0, $base['day_limit'] - count( $events ) ),
			'next_eligible_at'     => $next,
			'window_type'          => 'rolling',
			'window_seconds'       => array( 60, 86400 ),
		);
	}
	public static function reserve( string $site ): ?\WP_Error {
		$lock = Lock::acquire( 'inspection-quota:' . $site, 30 );
		if ( null === $lock ) {
			return new \WP_Error(
				'f3_google_inspection_busy',
				'Reserva de cota ocupada.',
				array(
					'retryable'   => true,
					'retry_after' => 1,
				)
			);
		}
		try {
			$key   = 'f3_mcp_google_quota_' . hash( 'sha256', $site );
			$state = Options::stored( $key );
			if ( ! $state['success'] ) {
				return new \WP_Error( 'f3_google_quota_read', 'Não foi possível ler a cota local.' );
			}
			$events = array_values( array_filter( (array) ( $state['value']['events'] ?? array() ), static fn ( $t ) => is_int( $t ) && $t > time() - 86400 ) );
			sort( $events );
			$minute = array_values( array_filter( $events, static fn ( $t ) => $t > time() - 60 ) );
			$budget = min( 1000, Options::limit( Options::INSPECTION_BUDGET ) );
			if ( count( $events ) >= $budget || count( $minute ) >= 25 ) {
				$next = count( $minute ) >= 25 ? $minute[0] + 60 : $events[0] + 86400;
				return new \WP_Error(
					'f3_google_inspection_budget',
					'Limite local de tentativas atingido.',
					array(
						'retryable'         => true,
						'retry_after'       => max( 1, $next - time() ),
						'next_eligible_at'  => $next,
						'operation_outcome' => 'not_applied',
					)
				);
			}
			$events[] = time();
			$saved    = Options::set(
				$key,
				array(
					'events'         => $events,
					'window_seconds' => 86400,
				)
			);
			return $saved['success'] ? null : new \WP_Error( 'f3_google_quota_persistence', 'Reserva de cota não persistida.' );
		} finally {
			Lock::release( $lock );
		}
	}
}
