<?php
/**
 * Sitemap reconciliation and cached inspection, using the existing API operations.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\SearchConsole;

use Fator3\McpGoogle\{
	Ability, Auth\Credentials, Connections, Gate, Generic\ExecuteAction, Lock, Options, Response
};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Workflow {

	public static function sitemap( array $input ): array {
		$bindings = (array) Options::get( Connections::BINDINGS, array() );
		$site     = Api::site( $input['site_url'] ?? $bindings['gsc_site_url'] ?? '' );
		if ( is_wp_error( $site ) ) {
			return Response::fail( $site );
		}
		$url = (string) ( $input['sitemap_url'] ?? $bindings['sitemap_url'] ?? '' );
		if ( '' === $url ) {
			if ( defined( 'WPSEO_VERSION' ) ) {
				$url = home_url( '/sitemap_index.xml' );
			} elseif ( function_exists( 'wp_sitemaps_get_server' ) ) {
				$server = wp_sitemaps_get_server();
				if ( $server && $server->sitemaps_enabled() ) {
					$url = $server->index->get_index_url();
				}
			}
		}
		if ( ! self::belongs( $url, $site ) ) {
			return Response::fail( new \WP_Error( 'f3_google_sitemap_property', 'Informe sitemap HTTP/HTTPS pertencente à propriedade selecionada.' ) );
		}
		$lock = Lock::acquire( 'sitemap:' . Credentials::identity_key() . ':' . $site . ':' . $url, 300 );
		if ( null === $lock ) {
			return Response::fail( new \WP_Error( 'f3_google_sitemap_busy', 'Este sitemap já está sendo processado.' ) );
		}
		try {
			$path  = array(
				'siteUrl'  => $site,
				'feedpath' => $url,
			);
			$prior = ExecuteAction::call( 'search-console', 'webmasters.sitemaps.get', $path, array(), null, array( 'mode' => 'read' ) );
			if ( ! is_wp_error( $prior ) && empty( $input['force'] ) ) {
				return self::state( $site, $url, false, $prior );
			}
			if ( is_wp_error( $prior ) && 404 !== (int) ( $prior->get_error_data()['status'] ?? 0 ) ) {
				return Response::fail( $prior );
			}
			if ( ! empty( $input['check_only'] ) ) {
				return Response::ok(
					array(
						'site_url'            => $site,
						'sitemap_url'         => $url,
						'registered'          => ! is_wp_error( $prior ),
						'submission_required' => is_wp_error( $prior ),
						'submitted'           => false,
					)
				);
			}
			// Public reads share pinned DNS, destination checks and a bounded body.
			if ( wp_parse_url( $url, PHP_URL_HOST ) !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
				return Response::fail( new \WP_Error( 'f3_google_sitemap_host', 'A descoberta acompanhada aceita o sitemap deste site. Use gsc/submit-sitemap para outro host autorizado.' ) );
			}
			$document = \Fator3\McpGoogle\Http\PublicPage::fetch( $url, array( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ), 0 );
			if ( empty( $document['success'] ) || 200 !== (int) ( $document['http_status'] ?? 0 ) || ! preg_match( '/<(?:[A-Za-z]+:)?(?:sitemapindex|urlset)[\s>]/', (string) ( $document['body'] ?? '' ) ) ) {
				return Response::fail( new \WP_Error( 'f3_google_sitemap_unavailable', 'O sitemap publicado não respondeu HTTP 200 com início XML reconhecível.' ) );
			}
			$result = Abilities::run(
				'submit-sitemap',
				array(
					'site_url'    => $site,
					'sitemap_url' => $url,
				)
			);
			if ( empty( $result['success'] ) ) {
				return $result;
			}
			$after = ExecuteAction::call( 'search-console', 'webmasters.sitemaps.get', $path, array(), null, array( 'mode' => 'read' ) );
			return self::state( $site, $url, true, $after );
		} finally {
			Lock::release( $lock );
		}
	}
	private static function state( string $site, string $url, bool $submitted, $data ): array {
		return Response::ok(
			array(
				'site_url'           => $site,
				'sitemap_url'        => $url,
				'submitted'          => $submitted,
				'registered'         => ! is_wp_error( $data ),
				'processing_state'   => is_wp_error( $data ) ? 'unconfirmed' : ( ! empty( $data['isPending'] ) ? 'pending' : ( ! empty( $data['errors'] ) ? 'errors' : ( array_key_exists( 'isPending', $data ) || ! empty( $data['lastDownloaded'] ) ? 'processed' : 'unknown' ) ) ),
				'google'             => is_wp_error( $data ) ? null : $data,
				'verification_error' => is_wp_error( $data ) ? Response::fail( $data ) : null,
				'checked_at'         => gmdate( 'c' ),
			),
			'Estado da submissão; a indexação das URLs é independente.'
		);
	}
	public static function belongs( string $url, string $site ): bool {
		if ( ! filter_var( $url, FILTER_VALIDATE_URL ) || ! in_array( wp_parse_url( $url, PHP_URL_SCHEME ), array( 'http', 'https' ), true ) || wp_parse_url( $url, PHP_URL_USER ) || wp_parse_url( $url, PHP_URL_FRAGMENT ) ) {
			return false;
		}
		if ( 0 === strpos( $site, 'sc-domain:' ) ) {
			$host   = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
			$domain = strtolower( substr( $site, 10 ) );
			return $host === $domain || str_ends_with( $host, '.' . $domain );
		}
		return 0 === strpos( $url, rtrim( $site, '/' ) . '/' );
	}
	public static function inspect( array $input ): array {
		$site = (string) ( $input['site_url'] ?? Options::get( Connections::BINDINGS, array() )['gsc_site_url'] ?? '' );
		$url  = (string) ( $input['inspection_url'] ?? '' );
		if ( ! self::belongs( $url, $site ) ) {
			return Response::fail( new \WP_Error( 'f3_google_inspection_property', 'A URL precisa pertencer à propriedade selecionada.' ) );
		}
		if ( ! \Fator3\McpGoogle\Policy::permitted( 'gsc', $site ) ) {
			return Response::fail( new \WP_Error( 'f3_google_policy_denied', 'Propriedade fora da política.' ) );
		}
		$key = 'f3_mcp_google_inspect_' . hash( 'sha256', Credentials::identity_key() . '|' . $site . '|' . $url . '|' . ( $input['language_code'] ?? 'pt-BR' ) );
		if ( empty( $input['refresh'] ) ) {
			$cached = get_transient( $key );
			if ( is_array( $cached ) ) {
				\Fator3\McpGoogle\Telemetry::add( 'cache_hits' );
				$cached['cached'] = true;
				return $cached;
			}
		}
		$result               = Abilities::run(
			'inspect-url',
			array(
				'site_url'       => $site,
				'inspection_url' => $url,
				'language_code'  => $input['language_code'] ?? 'pt-BR',
			)
		);
		$result['cached']     = false;
		$result['checked_at'] = gmdate( 'c' );
		if ( ! empty( $result['success'] ) ) {
			set_transient( $key, $result, 86400 );
		}
		return $result;
	}
	public static function register(): void {
		Ability::register(
			'gsc/ensure-sitemap',
			'gsc',
			array(
				'label'        => 'Search Console: acompanhar sitemap',
				'description'  => 'Confere o sitemap registrado, verifica publicação e envia se ausente. Retorna estado de processamento separado de indexação.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => array(
						'site_url'    => array( 'type' => 'string' ),
						'sitemap_url' => array( 'type' => 'string' ),
						'force'       => array( 'type' => 'boolean' ),
						'check_only'  => array( 'type' => 'boolean' ),
					),
				),
				'callback'     => array( self::class, 'sitemap' ),
			)
		);
	}
}
