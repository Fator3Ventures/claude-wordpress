<?php
/**
 * Explicit public hosts, pinned DNS and bounded redirect chains for GSC workflows.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Http;

use Fator3\McpGoogle\Automation\Execution;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class PublicPage {

	private static function public_ip( string $ip ): bool {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
			return false;
		}
		$packed = inet_pton( $ip );
		if ( false === $packed ) {
			return false;
		}
		// PHP's flags omit shared-address, benchmarking, documentation and multicast ranges.
		// Conservative public-unicast subset of IANA special-purpose registries.
		// Reference: <https://www.iana.org/assignments/iana-ipv6-special-registry/>.
		$blocked = strlen( $packed ) === 4 ? array( '0.0.0.0/8', '100.64.0.0/10', '192.0.0.0/24', '192.0.2.0/24', '198.18.0.0/15', '198.51.100.0/24', '203.0.113.0/24', '224.0.0.0/4', '240.0.0.0/4' ) : array( '2001::/23', '2001:db8::/32', '2002::/16', '3fff::/20' );
		if ( strlen( $packed ) === 16 && ( ord( $packed[0] ) & 0xe0 ) !== 0x20 ) {
			return false;
		}
		foreach ( $blocked as $cidr ) {
			[$network, $bits] = explode( '/', $cidr );
			$base             = inet_pton( $network );
			$bytes            = intdiv( (int) $bits, 8 );
			$rest             = (int) $bits % 8;
			if ( substr( $packed, 0, $bytes ) === substr( $base, 0, $bytes ) && ( ! $rest || ( ( ord( $packed[ $bytes ] ) ^ ord( $base[ $bytes ] ) ) & ( 0xff << ( 8 - $rest ) ) ) === 0 ) ) {
				return false;
			}
		}
		return true;
	}
	public static function validate( string $url, array $hosts ) {
		$p = wp_parse_url( $url );
		if ( ! is_array( $p ) || ! in_array( $p['scheme'] ?? '', array( 'http', 'https' ), true ) || empty( $p['host'] ) || isset( $p['user'] ) || isset( $p['pass'] ) || isset( $p['fragment'] ) || ( isset( $p['port'] ) && ! in_array( $p['port'], array( 80, 443 ), true ) ) ) {
			return new \WP_Error( 'f3_google_public_url', 'URL pública HTTP/HTTPS inválida.' );
		}
		$host = strtolower( $p['host'] );
		if ( str_ends_with( $host, '.' ) || str_starts_with( $host, '[' ) ) {
			return new \WP_Error( 'f3_google_public_host', 'Formato de host não permitido.' );
		}
		if ( ! in_array( $host, array_map( 'strtolower', $hosts ), true ) ) {
			return new \WP_Error( 'f3_google_public_host', 'Host fora da lista explicitamente autorizada.' );
		}
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			$ips = array( $host );
		} else {
			$records = apply_filters( 'f3_mcp_google_public_dns', null, $host );
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- DNS failure is explicitly returned as a structured error; resolver warnings must not leak into JSON.
			$records = null === $records ? (array) @dns_get_record( $host, DNS_A | DNS_AAAA ) : $records;
			$ips     = array();
			foreach ( $records as $record ) {
				if ( isset( $record['ip'] ) ) {
					$ips[] = $record['ip'];
				} elseif ( isset( $record['ipv6'] ) ) {
					$ips[] = $record['ipv6'];
				}
			}
		}
		if ( ! $ips ) {
			return new \WP_Error( 'f3_google_public_dns', 'Não foi possível resolver o host público.' );
		}
		foreach ( $ips as $ip ) {
			if ( ! is_string( $ip ) || ! self::public_ip( $ip ) ) {
				return new \WP_Error( 'f3_google_public_private', 'Endereços privados ou reservados são recusados.' );
			}
		}
		return array(
			'host' => $host,
			'ip'   => $ips[0],
			'port' => $p['port'] ?? ( 'https' === $p['scheme'] ? 443 : 80 ),
		);
	}
	public static function fetch( string $url, array $hosts, int $max_redirects = 5, int $max_bytes = 262144, array $schemes = array( 'http', 'https' ) ): array {
		$max_bytes      = max( 1, min( 33554432, $max_bytes ) );
		$max_redirects  = max( 0, min( 5, $max_redirects ) );
		$chain          = array();
		$seen           = array();
		$current        = $url;
		$redirect_limit = min( 5, max( 0, $max_redirects ) );
		for ( $i = 0;$i <= $redirect_limit;++$i ) {
			if ( isset( $seen[ $current ] ) ) {
				return array(
					'success'    => false,
					'error_code' => 'f3_google_redirect_loop',
					'chain'      => $chain,
				);
			}
			$seen[ $current ] = true;
			if ( ! in_array( wp_parse_url( $current, PHP_URL_SCHEME ), $schemes, true ) ) {
				return array(
					'success'    => false,
					'error_code' => 'f3_google_public_scheme',
					'chain'      => $chain,
				);
			}
			$destination = self::validate( $current, $hosts );
			if ( is_wp_error( $destination ) ) {
				return array(
					'success'    => false,
					'error_code' => $destination->get_error_code(),
					'message'    => $destination->get_error_message(),
					'chain'      => $chain,
				);
			}
			$deadline = Execution::check();
			if ( null !== $deadline ) {
				return array(
					'success'    => false,
					'error_code' => $deadline->get_error_code(),
					'chain'      => $chain,
				);
			}
			$timeout = is_finite( Execution::remaining() ) ? (int) ( Execution::remaining() * 1000 ) : 10000;
			$mock    = apply_filters( 'f3_mcp_google_public_response', null, $current, $destination, $timeout, $max_bytes );
			if ( null !== $mock ) {
				$body      = substr( (string) ( $mock['body'] ?? '' ), 0, $max_bytes );
				$headers   = $mock['headers'] ?? array();
				$status    = (int) ( $mock['status'] ?? 0 );
				$ok        = ! empty( $mock['success'] );
				$error     = 0;
				$truncated = strlen( (string) ( $mock['body'] ?? '' ) ) > $max_bytes;
			} else {
				if ( ! function_exists( 'curl_init' ) ) {
					return array(
						'success'    => false,
						'error_code' => 'f3_google_public_transport',
						'message'    => 'A consulta pública exige cURL com resolução fixada.',
						'chain'      => $chain,
					);
				}
				$body      = '';
				$headers   = array();
				$truncated = false;
				// phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init -- Pinned DNS with CURLOPT_RESOLVE and manual redirect validation are required for SSRF protection.
				$curl = curl_init( $current );
				$ip   = str_contains( $destination['ip'], ':' ) ? '[' . $destination['ip'] . ']' : $destination['ip'];
				// phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt_array -- Pinned DNS with CURLOPT_RESOLVE and manual redirect validation are required for SSRF protection.
				curl_setopt_array(
					$curl,
					array(
						CURLOPT_RETURNTRANSFER    => false,
						CURLOPT_FOLLOWLOCATION    => false,
						CURLOPT_PROTOCOLS         => CURLPROTO_HTTP | CURLPROTO_HTTPS,
						CURLOPT_PROXY             => '',
						CURLOPT_SSL_VERIFYPEER    => true,
						CURLOPT_SSL_VERIFYHOST    => 2,
						CURLOPT_CONNECTTIMEOUT_MS => min( 5000, $timeout ),
						CURLOPT_TIMEOUT_MS        => min( 10000, $timeout ),
						CURLOPT_RESOLVE           => array( $destination['host'] . ':' . $destination['port'] . ':' . $ip ),
						CURLOPT_USERAGENT         => 'WP-MCP-Google/' . F3_MCP_GOOGLE_VERSION,
						CURLOPT_WRITEFUNCTION     => static function ( $handle, string $chunk ) use ( &$body, &$truncated, $max_bytes ): int {
							$space = min( 33554432, $max_bytes ) - strlen( $body );
							if ( strlen( $chunk ) > $space ) {
								$body .= substr( $chunk, 0, $space );
								$truncated = true;
								return 0;
							}
							$body .= $chunk;
							return strlen( $chunk );
						},
						CURLOPT_HEADERFUNCTION    => static function ( $handle, string $line ) use ( &$headers ): int {
							$p = explode( ':', $line, 2 );
							if ( 2 === count( $p ) ) {
								$headers[ strtolower( trim( $p[0] ) ) ] = trim( $p[1] );
							}
							return strlen( $line );
						},
					)
				);
				// phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec -- Pinned DNS with CURLOPT_RESOLVE and manual redirect validation are required for SSRF protection.
				$ok = curl_exec( $curl );
				// phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo -- Pinned DNS with CURLOPT_RESOLVE and manual redirect validation are required for SSRF protection.
				$status = (int) curl_getinfo( $curl, CURLINFO_RESPONSE_CODE );
				// phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_errno -- Pinned DNS with CURLOPT_RESOLVE and manual redirect validation are required for SSRF protection.
				$error = curl_errno( $curl );
				// phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close -- Pinned DNS with CURLOPT_RESOLVE and manual redirect validation are required for SSRF protection.
				curl_close( $curl );
			}
			$chain[] = array(
				'url'         => $current,
				'status'      => $status,
				'location'    => $headers['location'] ?? null,
				'observed_at' => gmdate( 'c' ),
			);
			if ( false === $ok && ! $truncated ) {
				return array(
					'success'        => false,
					'error_code'     => 'f3_google_public_transport',
					'transport_code' => $error,
					'chain'          => $chain,
				);
			}
			if ( in_array( $status, array( 301, 302, 303, 307, 308 ), true ) && isset( $headers['location'] ) ) {
				if ( $i >= $max_redirects ) {
					return array(
						'success'    => false,
						'error_code' => 'f3_google_redirect_limit',
						'chain'      => $chain,
					);
				}
				$current = preg_match( '~^[a-z][a-z0-9+.-]*://~i', $headers['location'] ) ? $headers['location'] : \WP_Http::make_absolute_url( $headers['location'], $current );
				continue;
			}
			$canonical = null;
			if ( preg_match( '/<link\b[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']+)/i', $body, $m ) || preg_match( '/<link\b[^>]*href=["\']([^"\']+)["\'][^>]*rel=["\']canonical["\']/i', $body, $m ) ) {
				$canonical = html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' );
			}
			return array(
				'success'        => $status >= 200 && $status < 400,
				'chain'          => $chain,
				'final_url'      => $current,
				'http_status'    => $status,
				'live_canonical' => $canonical,
				'body'           => $body,
				'truncated'      => $truncated,
				'observed_at'    => gmdate( 'c' ),
				'source'         => 'live_http',
			);
		}
		return array(
			'success'    => false,
			'error_code' => 'f3_google_redirect_limit',
			'chain'      => $chain,
		);
	}
}
