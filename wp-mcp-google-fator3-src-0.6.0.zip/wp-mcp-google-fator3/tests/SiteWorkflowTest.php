<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Auth\Credentials, Connections, CoreBinding, Http\PublicPage, Options, SearchConsole\SiteWorkflow, SearchConsole\Workflow, Settings};
use PHPUnit\Framework\TestCase;
final class SiteWorkflowTest extends TestCase {
 protected function setUp(): void {$GLOBALS['f3_test_options']=array();$GLOBALS['f3_test_transients']=array();$GLOBALS['f3_test_write_fail']=array();$GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;FakeHttp::reset();}
 public function test_revision_required_and_stale_refused_before_network(): void {
  $input=array('site_url'=>'https://example.test/','sitemap_url'=>'https://example.test/sitemap.xml','save_binding'=>true,'dry_run'=>false);
  $this->assertSame('f3_google_revision_required',SiteWorkflow::prepare($input)['error_code']);
  $this->assertSame('f3_google_configuration_conflict',SiteWorkflow::prepare($input+array('expected_revision'=>'stale'))['error_code']);$this->assertCount(0,FakeHttp::$requests);
 }
 public function test_migration_validates_dates_before_network_and_accepts_http_source(): void {
  $this->assertTrue(Workflow::belongs('http://old.test/page','http://old.test/'));
  $this->assertFalse(Workflow::belongs('http://old.test.evil/page','http://old.test/'));
  $r=SiteWorkflow::migration(array('source_site_url'=>'http://old.test/','target_site_url'=>'https://new.test/','pairs'=>array(array('source_url'=>'http://old.test/a','target_url'=>'https://new.test/a')),'date_range'=>'bad-range'));
  $this->assertFalse($r['success']);$this->assertCount(0,FakeHttp::$requests);
 }
 public function test_core_change_after_write_restores_original_values(): void {
  update_option('f3base_ga4_measurement_id','G-OLD');Options::set(Options::GA_DEFAULT_PROPERTY,'123');$source=CoreBinding::source();$revision=Settings::revision();$calls=0;
  $guard=static function()use($source,&$calls){++$calls;if(2===$calls){update_option('f3base_ga4_measurement_id','G-NEW');}return CoreBinding::source()['revision']===$source['revision']?null:new \WP_Error('f3_google_core_changed','Fonte alterada.');};
  $r=Settings::save(array(Options::GA_DEFAULT_PROPERTY=>'456'),array(),array(),$revision,$guard);
  $this->assertFalse($r['success']);$this->assertTrue($r['restored']);$this->assertSame('123',Options::get(Options::GA_DEFAULT_PROPERTY));$this->assertSame($revision,Settings::revision());$this->assertSame('G-NEW',get_option('f3base_ga4_measurement_id'));
 }
 public function test_each_redirect_revalidates_host_and_dns_before_transport(): void {
  $hits=array();$dns=static fn($unused,$host)=>array(array('ip'=>'93.184.216.34'));
  $http=static function($unused,$url)use(&$hits){$hits[]=$url;return array('success'=>true,'status'=>302,'headers'=>array('location'=>'http://127.0.0.1/private'));};
  add_filter('f3_mcp_google_public_dns',$dns,10,2);add_filter('f3_mcp_google_public_response',$http,10,2);
  try{$r=PublicPage::fetch('https://example.test/a',array('example.test','127.0.0.1'));}finally{remove_filter('f3_mcp_google_public_dns',$dns,10);remove_filter('f3_mcp_google_public_response',$http,10);}
  $this->assertFalse($r['success']);$this->assertSame('f3_google_public_private',$r['error_code']);$this->assertCount(1,$hits);
 }
 public function test_public_dns_with_one_private_address_is_refused_before_transport(): void {
  $dns=static fn()=>array(array('ip'=>'93.184.216.34'),array('ip'=>'10.0.0.1'));add_filter('f3_mcp_google_public_dns',$dns);
  try{$r=PublicPage::validate('https://example.test/',array('example.test'));}finally{remove_filter('f3_mcp_google_public_dns',$dns);}
  $this->assertSame('f3_google_public_private',$r->get_error_code());
 }
 public function test_denied_policy_cannot_read_cached_inspection(): void {
  $site='https://example.test/';$url=$site.'a';$key='f3_mcp_google_inspect_'.hash('sha256',Credentials::identity_key().'|'.$site.'|'.$url.'|pt-BR');set_transient($key,array('success'=>true,'private_result'=>'cached'),600);
  Options::set(\Fator3\McpGoogle\Policy::OPTION,array('mode'=>'restricted','services'=>array('gsc'=>array('resources'=>array('https://other.test/')))));
  $r=Workflow::inspect(array('site_url'=>$site,'inspection_url'=>$url));$this->assertSame('f3_google_policy_denied',$r['error_code']);$this->assertArrayNotHasKey('private_result',$r);
 }
}
