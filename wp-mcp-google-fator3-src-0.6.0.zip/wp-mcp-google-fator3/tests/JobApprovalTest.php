<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\{Auth\Credentials, Automation\Approval, Automation\Jobs, Automation\Worker, Connections, Generic\Discovery, Options, Plugin, Records};
use PHPUnit\Framework\TestCase;

final class JobApprovalTest extends TestCase {

	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = $GLOBALS['f3_test_user_caps'] = array();
		$GLOBALS['f3_test_caps'] = true;
		$GLOBALS['f3_test_user'] = 1;
		FakeHttp::reset();
		Options::batch_verified( array( Options::ENABLED => true, Options::GA_ENABLED => true, Options::AUTH_MODE => 'oauth', Options::OAUTH_CLIENT_ID => 'test.apps.googleusercontent.com' ), array( Options::OAUTH_CLIENT_SECRET => 'synthetic-secret', Options::OAUTH_REFRESH_TOKEN => 'synthetic-refresh' ) );
		foreach ( array( 'sheets' => 'sheets-v4', 'drive' => 'drive-v3' ) as $api => $fixture ) {
			set_transient( Discovery::cache_key( $api ), json_decode( file_get_contents( __DIR__ . '/fixtures/discovery/' . $fixture . '.json' ), true ), 3600 );
		}
		for ( $i = 0; $i < 8; ++$i ) { FakeHttp::push( '/token', 200, array( 'access_token' => 'synthetic-token', 'expires_in' => 3600 ) ); }
		Plugin::register_abilities();
	}

	private function create( string $key ): array {
		return Jobs::create( array( 'task' => 'export', 'idempotency_key' => $key, 'parameters' => array( 'spreadsheet_id' => 'sheet-existing', 'query' => array( 'connector' => 'ga4', 'accounts' => array( '123' ), 'metrics' => array( 'sessions' ), 'date_range' => array( 'from' => '2026-08-01', 'to' => '2026-08-02' ) ) ) ) );
	}

	private function reads(): void {
		FakeHttp::push( ':runReport', 200, array( 'metricHeaders' => array( array( 'name' => 'sessions', 'type' => 'TYPE_INTEGER' ) ), 'rows' => array( array( 'metricValues' => array( array( 'value' => '10' ) ) ) ), 'rowCount' => 1 ) );
		FakeHttp::push( '/v4/spreadsheets/sheet-existing?', 200, array( 'spreadsheetId' => 'sheet-existing', 'sheets' => array( array( 'properties' => array( 'sheetId' => 0, 'title' => 'Relatório', 'gridProperties' => array( 'rowCount' => 1000, 'columnCount' => 26 ) ) ) ) ), array(), 'GET' );
		FakeHttp::push( '/values/', 200, array( 'values' => array( array( 'sessions' ), array( 5 ) ) ), array(), 'GET' );
	}

	private function mutations(): array {
		return array_values( array_filter( FakeHttp::$requests, static fn( $r ) => 'GET' !== $r['method'] && ! str_contains( $r['url'], '/token' ) && ! str_contains( $r['url'], ':runReport' ) ) );
	}

	public function test_export_waits_for_bound_approval_and_cannot_replay(): void {
		$created = $this->create( 'export' );
		$this->assertSame( 'approval_required', $created['status'] );
		$waiting = Worker::run( $created['job_id'] );
		$this->assertSame( 'prepare_and_approve_job', $waiting['reason'] );
		$this->assertSame( 0, FakeHttp::count() );
		for ( $i = 0; $i < 3; ++$i ) { $this->reads(); }
		$prepared = Approval::action( array( 'job_id' => $created['job_id'] ), false );
		$this->assertTrue( $prepared['success'], json_encode( $prepared ) );
		$approved = Approval::action( array( 'job_id' => $created['job_id'], 'approval_token' => $prepared['confirmation_token'] ), true );
		$this->assertTrue( $approved['success'], json_encode( $approved ) );
		$this->assertStringNotContainsString( $prepared['confirmation_token'], wp_json_encode( $GLOBALS['f3_test_options'] ) );
		$this->assertCount( 0, $this->mutations() );
		Options::set( Connections::BINDINGS, array( 'ga_property_id' => 'properties/999' ) );
		FakeHttp::push( ':batchUpdate', 200, array( 'spreadsheetId' => 'sheet-existing', 'replies' => array( array() ) ), array(), 'POST' );
		FakeHttp::push( '/values/', 200, array( 'values' => array( array( 'sessions' ), array( 10 ) ) ), array(), 'GET' );
		$result = Worker::run( $created['job_id'] );
		$this->assertSame( 'completed', $result['status'], json_encode( $result ) );
		$this->assertCount( 1, $this->mutations() );
		$this->assertArrayNotHasKey( 'confirmation_record', $result['job'] );
		$requests = FakeHttp::count();
		Worker::run( $created['job_id'] );
		$this->assertSame( $requests, FakeHttp::count() );
		$this->assertFalse( Approval::action( array( 'job_id' => $created['job_id'], 'approval_token' => $prepared['confirmation_token'] ), true )['success'] );
	}

	public function test_approval_is_bound_to_job_actor_and_expiry(): void {
		$first = $this->create( 'first' ); $second = $this->create( 'second' );
		$this->reads();
		$p = Approval::action( array( 'job_id' => $first['job_id'] ), false );
		$this->assertTrue( $p['success'], json_encode( $p ) );
		$r = Approval::action( array( 'job_id' => $second['job_id'], 'approval_token' => $p['confirmation_token'] ), true );
		$this->assertSame( 'f3_google_confirmation_changed', $r['error_code'] );
		wp_set_current_user( 2 );
		$r = Approval::action( array( 'job_id' => $first['job_id'], 'approval_token' => $p['confirmation_token'] ), true );
		$this->assertSame( 'f3_google_job_permission', $r['error_code'] );
		wp_set_current_user( 1 );
		$id = hash( 'sha256', $p['confirmation_token'] ); $record = Records::get( 'confirmation', $id ); $record['expires_at'] = time() - 1; Records::put( 'confirmation', $id, $record );
		$r = Approval::action( array( 'job_id' => $first['job_id'], 'approval_token' => $p['confirmation_token'] ), true );
		$this->assertSame( 'f3_google_confirmation_changed', $r['error_code'] );
		$this->assertCount( 0, $this->mutations() );
	}
}
