<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\{Analytics\DataApi, Auth\Credentials, Confirmation, Generic\Discovery, Generic\ExecuteAction, Http\GoogleClient, Options, Policy, Unified\Query};
use PHPUnit\Framework\TestCase;

final class ResourcePolicyTest extends TestCase {
	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_user'] = 1;
		FakeHttp::reset();
		Options::batch_verified( array( Options::ENABLED => true, Options::GA_ENABLED => true, Options::ADS_ENABLED => true, Options::AUTH_MODE => 'oauth', Options::OAUTH_CLIENT_ID => 'test.apps.googleusercontent.com' ), array( Options::OAUTH_CLIENT_SECRET => 'synthetic', Options::OAUTH_REFRESH_TOKEN => 'synthetic', Options::ADS_DEVELOPER_TOKEN => 'synthetic' ) );
		foreach ( array( 'google-ads' => 'googleads-v25', 'sheets' => 'sheets-v4' ) as $api => $fixture ) { set_transient( Discovery::cache_key( $api ), json_decode( file_get_contents( __DIR__ . '/fixtures/discovery/' . $fixture . '.json' ), true ), 3600 ); }
		Options::set( Policy::OPTION, array( 'mode' => 'restricted', 'services' => array( 'ads' => array( 'resources' => array( '1111111111' ), 'allow_create' => true ), 'sheets' => array( 'resources' => array( 'allowed' ) ), 'ga' => array( 'resources' => array( 'properties/123' ) ), 'drive' => array( 'resources' => array( 'file', 'parent' ) ) ) ) );
	}

	public function test_nested_native_objects_cannot_reference_another_ads_customer(): void {
		$r = ExecuteAction::call( 'google-ads', 'googleads.customers.googleAds.mutate', array( 'customerId' => '1111111111' ), array(), array( 'mutateOperations' => array( array( 'campaignOperation' => array( 'update' => array( 'resourceName' => 'customers/2222222222/campaigns/7', 'status' => 'PAUSED' ), 'updateMask' => 'status' ) ) ) ) );
		$this->assertSame( 'f3_google_policy_denied', $r->get_error_code() );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_nested_native_remove_still_requires_confirmation(): void {
		$r = ExecuteAction::call( 'google-ads', 'googleads.customers.googleAds.mutate', array( 'customerId' => '1111111111' ), array(), array( 'mutateOperations' => array( array( 'campaignOperation' => array( 'remove' => 'customers/1111111111/campaigns/7' ) ) ) ) );
		$this->assertSame( 'f3_google_confirmation_required', $r->get_error_code() );
		$this->assertSame( 0, FakeHttp::count() );
		$this->assertTrue( Confirmation::sensitive( 'mutate', array( 'mutateOperations' => array( (object) array( 'create' => new \stdClass() ), (object) array( 'create' => new \stdClass() ) ) ) ) );
	}

	public function test_query_parents_and_nested_destinations_are_checked(): void {
		$r = Policy::check_http( 'PATCH', GoogleClient::HOST_GOOGLE . '/drive/v3/files/file', array(), array( 'connector' => 'drive', 'mode' => 'write', 'operation_id' => 'drive.files.update', 'query' => array( 'addParents' => 'parent,foreign' ) ) );
		$this->assertSame( 'f3_google_policy_denied', $r->get_error_code() );
		$r = Policy::check_http( 'POST', GoogleClient::HOST_SHEETS . '/v4/spreadsheets/allowed:batchUpdate', array( 'requests' => array( (object) array( 'copySheetToSpreadsheet' => (object) array( 'destinationSpreadsheetId' => 'foreign' ) ) ) ), array( 'connector' => 'sheets', 'mode' => 'write', 'operation_id' => 'sheets.spreadsheets.batchUpdate' ) );
		$this->assertSame( 'f3_google_policy_denied', $r->get_error_code() );
	}

	public function test_named_data_api_obeys_the_same_operation_allowlist(): void {
		Options::set( Policy::OPTION, array( 'mode' => 'restricted', 'services' => array( 'ga' => array( 'resources' => array( 'properties/123' ), 'operations' => array( 'analyticsdata.properties.getMetadata' ) ) ) ) );
		$r = DataApi::run_report( 'properties/123', array() );
		$this->assertSame( 'f3_google_policy_denied', $r->get_error_code() );
		$this->assertSame( 0, FakeHttp::count() );
		FakeHttp::push( '/metadata', 200, array( 'dimensions' => array() ) );
		$r = GoogleClient::get( GoogleClient::HOST_GA_DATA . '/v1beta/properties/0/metadata', array(), array( 'auth' => false, 'connector' => 'ga', 'mode' => 'read', 'operation_id' => 'analyticsdata.properties.getMetadata' ) );
		$this->assertSame( array( 'dimensions' => array() ), $r );
	}

	public function test_old_unrestricted_account_cache_is_filtered_again(): void {
		$rows = array( array( 'connector' => 'ga4', 'account_id' => 'properties/123', 'name' => 'Allowed' ), array( 'connector' => 'ga4', 'account_id' => 'properties/456', 'name' => 'Private name' ) );
		set_transient( Query::ACCOUNTS_CACHE . 'ga_' . Credentials::identity_key(), $rows, 3600 );
		$r = Query::accounts( array( 'connector' => 'ga4' ) );
		$this->assertTrue( $r['success'], json_encode( $r ) );
		$this->assertStringNotContainsString( 'Private name', json_encode( $r ) );
		$this->assertSame( '', Query::account_name( 'ga', 'properties/456' ) );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_unknown_methods_and_missing_mapping_fail_closed(): void {
		$this->assertFalse( Policy::covered( 'googleads.customers.futureMethod' ) );
		$this->assertTrue( Policy::covered( 'googleads.customers.campaigns.mutate' ) );
		$r = Policy::check_http( 'POST', GoogleClient::HOST_ADS . '/v25/customers/1111111111/newMethod', array(), array( 'connector' => 'ads', 'mode' => 'write' ) );
		$this->assertSame( 'f3_google_policy_denied', $r->get_error_code() );
		$this->assertNotEmpty( Policy::coverage()['methods']['google-ads'] );
	}
	public function test_compound_sheets_refuses_unknown_requests_and_formula_paths_before_network(): void {
		$opts = array( 'connector' => 'sheets', 'mode' => 'write', 'operation_id' => 'sheets.spreadsheets.batchUpdate' );
		$url = GoogleClient::HOST_SHEETS . '/v4/spreadsheets/allowed:batchUpdate';
		foreach ( array( array( 'addDataSource' => array() ), array( 'updateCells' => array( 'rows' => array( array( 'values' => array( array( 'userEnteredValue' => array( 'formulaValue' => '=IMPORTRANGE("foreign","A1")' ) ) ) ) ) ) ) ) as $request ) {
			$this->assertSame( 'f3_google_policy_denied', Policy::check_http( 'POST', $url, array( 'requests' => array( $request ) ), $opts )->get_error_code() );
		}
		$this->assertNull( Policy::check_http( 'POST', $url, array( 'requests' => array( array( 'updateCells' => array( 'rows' => array( array( 'values' => array( array( 'userEnteredValue' => array( 'stringValue' => '=literal' ) ) ) ) ) ) ) ) ), $opts ) );
		$this->assertCount( 0, FakeHttp::$requests );
	}

	public function test_policy_requires_impact_preview_and_rejects_stale_revision(): void {
		Options::set( \Fator3\McpGoogle\Connections::BINDINGS, array( 'ga_property_id' => '123' ) );
		$policy = array( 'mode' => 'restricted', 'services' => array( 'ga' => array( 'resources' => array( 'properties/456' ) ) ) );
		$preview = Policy::plan( array( 'policy' => $policy ) );
		$this->assertTrue( $preview['success'] );
		$this->assertSame( '123', $preview['defaults_outside_policy'][0]['resource'] );
		$this->assertSame( 'f3_google_policy_preview_required', Policy::configure( array( 'policy' => $policy, 'expected_revision' => $preview['revision'] ) )['error_code'] );
		$input = array( 'policy' => $policy, 'expected_revision' => $preview['revision'], 'expected_plan_hash' => $preview['plan_hash'] );
		$this->assertTrue( Policy::configure( $input )['success'] );
		$this->assertFalse( Policy::configure( $input )['success'] );
		$this->assertCount( 0, FakeHttp::$requests );
	}

}
