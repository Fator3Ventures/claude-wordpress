<?php
/** 0.6.0 regressions through the registered abilities and HTTP boundary. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Ability, Audit, Auth\Credentials, Connections, Generic\Discovery, Generic\ExecuteAction, Options, Plugin, Records, Response, Settings, Storage\Admission, Storage\Migration, TagManager\Api, TagManager\Publish, TagManager\Diagnostic, TagManager\Abilities};
use PHPUnit\Framework\TestCase;
final class NextReleaseTest extends TestCase {
    private const C='accounts/1/containers/2'; private const W=self::C.'/workspaces/3';
    protected function setUp():void{
        $GLOBALS['f3_test_options']=array();$GLOBALS['f3_test_transients']=array();$GLOBALS['f3_test_write_fail']=array();$GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;FakeHttp::reset();
        Options::batch_verified(array(Options::ENABLED=>true,Options::GA_ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'test.apps.googleusercontent.com',Connections::SERVICES=>array('gtm'=>'admin','gsc'=>'read')),array(Options::OAUTH_CLIENT_SECRET=>'synthetic-secret',Options::OAUTH_REFRESH_TOKEN=>'synthetic-refresh'));
        for($n=0;$n<7;$n++){FakeHttp::push('oauth2.googleapis.com/token',200,array('access_token'=>'synthetic-token','expires_in'=>3600));}
        static $private;
        if(null===$private){$key=openssl_pkey_new(array('private_key_bits'=>2048));openssl_pkey_export($key,$private);}
        Options::batch_verified(array(Options::AUTH_MODE=>'service_account'),array(Options::SA_JSON=>json_encode(array('type'=>'service_account','client_id'=>'123','client_email'=>'synthetic@example.iam.gserviceaccount.com','private_key'=>$private,'token_uri'=>'https://oauth2.googleapis.com/token'))));
        Plugin::register_abilities();
    }
    private function version(string $id='4',array $tags=array()):array{return array('path'=>self::C.'/versions/'.$id,'containerVersionId'=>$id,'fingerprint'=>'version-'.$id,'tag'=>$tags);}
    private function snapshot(array $tags=array(),string $liveId='4'):void{
        FakeHttp::push('/versions:live',200,$this->version($liveId));
        FakeHttp::push('/workspaces/3',200,array('path'=>self::W,'fingerprint'=>'workspace-3'),array(),'GET');
        FakeHttp::push('/workspaces/3/status',200,array());
        FakeHttp::push('/containers/2',200,array('path'=>self::C,'usageContext'=>array('web')),array(),'GET');
        foreach(array('tags'=>'tag','triggers'=>'trigger','variables'=>'variable','built_in_variables'=>'builtInVariable','folders'=>'folder','templates'=>'customTemplate','gtag_config'=>'gtagConfig') as $resource=>$field){FakeHttp::push('/workspaces/3/'.$resource,200,array($field=>$field==='tag'?$tags:array()));}
    }
    public function test_migration_refuses_before_callback_without_creating_audit_gap():void{
        foreach(array('drain','copy','verify','failed') as $phase){Options::set(Migration::OPTION,array('phase'=>$phase));$called=false;Ability::register('google/probe-migration','any',array('callback'=>static function()use(&$called){$called=true;return Response::ok();}));$r=wp_get_ability('google/probe-migration')->execute(array());$this->assertSame('f3_google_storage_migrating',$r['error_code']);$this->assertSame(15000,$r['retry_after_ms']);$this->assertFalse($called);$this->assertSame('no_failure_observed',Audit::health()['state']);}
        $this->assertCount(0,FakeHttp::$requests);
    }
    public function test_admitted_call_can_finish_audit_in_drain_but_new_call_cannot():void{
        $r=Admission::run('google/probe',static function(){Options::set(Migration::OPTION,array('phase'=>'drain'));Audit::log('probe');return Audit::last_failure();});
        $this->assertNull($r);$this->assertCount(1,Audit::recent());
        $this->assertSame('f3_google_storage_migrating',Admission::run('google/probe',static fn()=>array())['error_code']);
    }
    public function test_successful_append_recovers_health_and_keeps_historical_gap():void{
        Options::set(Migration::OPTION,array('phase'=>'verify'));Audit::log('legacy-call');$this->assertSame('failed',Audit::health()['state']);
        Options::delete(Migration::OPTION);Audit::log('new-call');$h=Audit::health();$this->assertSame('recovered',$h['state']);$this->assertTrue($h['historical_gap']);$this->assertSame('storage_migration',$h['cause']);$this->assertStringStartsWith('event:',$h['verified_event']);
    }
    public function test_gtm_entire_catalog_has_typed_abilities_and_channel_metadata():void{
        $methods=Discovery::methods(Api::document());$this->assertCount(106,$methods);
        foreach($methods as $id=>$method){$a=wp_get_ability(Abilities::route($id));$this->assertNotNull($a,$id);$meta=$a->get_meta();$this->assertSame('wp-mcp-google-fator3',$meta['fator3']['provider']);$this->assertSame(1,$meta['fator3']['policy_contract']);}
        $r=Discovery::catalog(array('api'=>'gtm','task'=>'tag manager container'));$this->assertGreaterThan(50,$r['total']);
        $this->assertTrue(wp_get_ability('google/mcp-read')->get_meta()['fator3']['executes_ability']);
    }
    public function test_gtm_native_creation_uses_typed_body_and_correct_endpoint():void{
        FakeHttp::push('/workspaces/3/tags',200,array('tagId'=>'10','name'=>'Example'),array(),'POST');
        $r=wp_get_ability('gtm/create-tag')->execute(array('parent'=>self::W,'body'=>array('name'=>'Example','type'=>'html','parameter'=>array(array('type'=>'template','key'=>'html','value'=>'<span>test</span>')))));
        $this->assertTrue($r['success'],json_encode($r));$writes=array_values(array_filter(FakeHttp::$requests,static fn($r)=>$r['method']==='POST'&&!str_contains($r['url'],'oauth2')));$this->assertCount(1,$writes);$this->assertSame('Example',json_decode($writes[0]['body'],true)['name']);
    }
    public function test_gtm_simulation_compares_live_and_makes_no_remote_write():void{
        $tag=array('tagId'=>'9','name'=>'Test','type'=>'html');$this->snapshot(array($tag));$r=wp_get_ability('gtm/publicar')->execute(array('path'=>self::W,'simular'=>true));
        $this->assertTrue($r['success'],json_encode($r));$this->assertArrayHasKey('tag',$r['diff']);$this->assertSame('4',$r['previous_version_id']);$this->assertSame(64,strlen($r['expected_fingerprint']));
        foreach(FakeHttp::$requests as $request){if(!str_contains($request['url'],'oauth2')){$this->assertSame('GET',$request['method']);}}
    }
    public function test_publish_rejects_stale_preview_before_version_creation():void{
        $this->snapshot();$r=wp_get_ability('gtm/publicar')->execute(array('path'=>self::W,'simular'=>false,'expected_fingerprint'=>str_repeat('a',64)));
        $this->assertSame('f3_google_gtm_stale_preview',$r['error_code'],json_encode($r));foreach(FakeHttp::$requests as $request){$this->assertStringNotContainsString(':create_version',$request['url']);}
    }
    public function test_publish_and_revert_journal_previous_and_new_versions():void{
        $tag=array('tagId'=>'9','name'=>'Test','type'=>'html');$this->snapshot(array($tag));$preview=wp_get_ability('gtm/publicar')->execute(array('path'=>self::W));$this->assertTrue($preview['success'],json_encode($preview));
        $this->snapshot(array($tag));FakeHttp::push(':create_version',200,array('containerVersion'=>$this->version('5',array($tag)),'newWorkspacePath'=>self::C.'/workspaces/6'),array(),'POST');FakeHttp::push('/versions:live',200,$this->version());FakeHttp::push('/versions/5:publish',200,array('containerVersion'=>$this->version('5',array($tag))),array(),'POST');FakeHttp::push('/versions:live',200,$this->version('5',array($tag)));
        $r=wp_get_ability('gtm/publicar')->execute(array('path'=>self::W,'simular'=>false,'expected_fingerprint'=>$preview['expected_fingerprint']));$this->assertTrue($r['success'],json_encode($r));$this->assertSame('4',$r['previous_version_id']);$this->assertSame('5',$r['new_version_id']);
        $n=count(FakeHttp::$requests);$repeat=wp_get_ability('gtm/publicar')->execute(array('path'=>self::W,'simular'=>false,'expected_fingerprint'=>$preview['expected_fingerprint']));$this->assertTrue($repeat['replayed']);$this->assertSame($n,count(FakeHttp::$requests));
        FakeHttp::push('/versions:live',200,$this->version('5',array($tag)));FakeHttp::push('/versions/4',200,$this->version());$p=wp_get_ability('gtm/reverter')->execute(array('path'=>self::C.'/versions/4'));$this->assertTrue($p['success'],json_encode($p));
        FakeHttp::push('/versions:live',200,$this->version('5',array($tag)));FakeHttp::push('/versions/4',200,$this->version());FakeHttp::push('/versions:live',200,$this->version('5',array($tag)));FakeHttp::push('/versions/4:publish',200,array('containerVersion'=>$this->version()),array(),'POST');FakeHttp::push('/versions:live',200,$this->version());
        $r=wp_get_ability('gtm/reverter')->execute(array('path'=>self::C.'/versions/4','simular'=>false,'expected_fingerprint'=>$p['expected_fingerprint']));$this->assertTrue($r['success'],json_encode($r));$this->assertSame('5',$r['previous_version_id']);$this->assertSame('4',$r['new_version_id']);$this->assertSame('gtm/reverter',Audit::recent(1)[0]['action']);$this->assertSame('5',Audit::recent(1)[0]['extra']['before']['published_version_id']);
    }
    public function test_generic_publish_cannot_bypass_preview():void{
        $r=ExecuteAction::call('gtm','tagmanager.accounts.containers.versions.publish',array('path'=>self::C.'/versions/4'));$this->assertSame('f3_google_gtm_preview_required',$r->get_error_code());$this->assertCount(0,FakeHttp::$requests);
        $r=wp_get_ability('google/execute-action')->execute(array('api'=>'gtm','method'=>'tagmanager.accounts.containers.versions.publish','path_params'=>array('path'=>self::C.'/versions/4'),'dry_run'=>false));$this->assertSame('f3_google_gtm_preview_required',$r['error_code']);$this->assertCount(0,FakeHttp::$requests);
    }
    public function test_diagnostic_distinguishes_literal_dynamic_and_not_found():void{
        $version=array('tag'=>array(array('tagId'=>'1','name'=>'GA','type'=>'gaawc','parameter'=>array(array('key'=>'measurementId','value'=>'G-TEST'))),array('tagId'=>'2','name'=>'Consent','type'=>'html','parameter'=>array(array('key'=>'html','value'=>'{{runtime}} analytics_storage')))));
        $r=Diagnostic::analyze($version,array('ga4'=>'G-TEST','meta'=>'123','linkedin'=>''));$this->assertSame('literal_match',$r['slots']['ga4']['matches'][0]['state']);$this->assertSame('unresolved',$r['slots']['meta']['state']);$this->assertSame('not_configured',$r['slots']['linkedin']['state']);$this->assertFalse($r['runtime_verified']);$this->assertCount(1,$r['consent_tags']);
    }
    public function test_new_service_is_opt_in_on_legacy_connections():void{
        Options::delete(Connections::SERVICES);
        $this->assertFalse(Connections::enabled('gtm'));
        $this->assertSame(array(),Connections::scopes('gtm'));
        $this->assertFalse(in_array('https://www.googleapis.com/auth/tagmanager.publish',Credentials::scopes_for('any'),true));
    }
    public function test_diagnostic_does_not_match_numeric_metadata_as_tracking_id():void{
        $r=Diagnostic::analyze(array('tag'=>array(array('tagId'=>'123','name'=>'123','type'=>'gaawc','parameter'=>array(array('key'=>'measurementId','value'=>'G-OTHER'))))),array('meta'=>'123'));
        $this->assertSame('not_found',$r['slots']['meta']['state']);
    }
    public function test_first_publication_preview_requires_readable_container():void{
        FakeHttp::push('/versions:live',404,array('error'=>array('message'=>'not found')));
        FakeHttp::push('/containers/2',200,array('path'=>self::C,'usageContext'=>array('web')));
        $this->snapshot();$r=wp_get_ability('gtm/publicar')->execute(array('path'=>self::W));
        $this->assertTrue($r['success'],json_encode($r));$this->assertNull($r['previous_version_id']);
    }
    public function test_unknown_version_creation_is_never_automatically_repeated():void{
        $this->snapshot();$p=wp_get_ability('gtm/publicar')->execute(array('path'=>self::W));
        $this->snapshot();FakeHttp::push(':create_version',503,array('error'=>array('message'=>'unavailable')),array(),'POST');
        $input=array('path'=>self::W,'simular'=>false,'expected_fingerprint'=>$p['expected_fingerprint']);
        $r=wp_get_ability('gtm/publicar')->execute($input);$this->assertFalse($r['success']);$this->assertSame('unknown',$r['operation_outcome']);
        $n=count(FakeHttp::$requests);$again=wp_get_ability('gtm/publicar')->execute($input);$this->assertTrue($again['replayed']);$this->assertSame($n,count(FakeHttp::$requests));
    }

    public function test_service_account_creates_tag_trigger_variable_and_audits_each():void{
        foreach(array('trigger'=>array('type'=>'pageview'),'variable'=>array('type'=>'c','parameter'=>array(array('type'=>'template','key'=>'value','value'=>'G-TEST'))),'tag'=>array('type'=>'html','parameter'=>array(array('type'=>'template','key'=>'html','value'=>'<span>test</span>')))) as $type=>$body){
            FakeHttp::push('/workspaces/3/'.$type.'s',200,array($type.'Id'=>'19','name'=>'Synthetic'),array(),'POST');
            $r=wp_get_ability('gtm/create-'.$type)->execute(array('parent'=>self::W,'body'=>array('name'=>'Synthetic')+$body));$this->assertTrue($r['success'],json_encode($r));
        }
        $actions=array_column(Audit::recent(10),'action');foreach(array('tag','trigger','variable') as $type){$this->assertContains('gtm/create-'.$type,$actions);}
        $tokens=array_values(array_filter(FakeHttp::$requests,static fn($r)=>str_contains($r['url'],'oauth2.googleapis.com/token')));$this->assertNotEmpty($tokens);
        $body=$tokens[0]['body'];if(is_string($body)){parse_str($body,$body);}$parts=explode('.',$body['assertion']);$claims=json_decode(base64_decode(strtr($parts[1],'-_','+/')),true);
        $this->assertSame('synthetic@example.iam.gserviceaccount.com',$claims['iss']);$this->assertStringContainsString('tagmanager.edit.containers',$claims['scope']);
    }

}
