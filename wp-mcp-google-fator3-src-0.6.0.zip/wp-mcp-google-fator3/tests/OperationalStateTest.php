<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\{Automation\Alerts, Automation\Executor, Auth\Credentials, Connections, Gate, Http\GoogleClient, Options, Plugin, Policy, Records, Settings, Telemetry, Unified\Abilities};
use PHPUnit\Framework\TestCase;

final class OperationalStateTest extends TestCase {
	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = $GLOBALS['f3_test_write_fail'] = array();
		$GLOBALS['f3_test_caps'] = true; $GLOBALS['f3_test_user'] = 1;
		FakeHttp::reset();
		Options::set( Options::ENABLED, true );
		Plugin::register_abilities();
	}

	public function test_expired_cache_preserves_observations_for_other_apis(): void {
		FakeHttp::push( '/accountSummaries', 200, array() );
		GoogleClient::get( GoogleClient::HOST_GA_ADMIN . '/v1beta/accountSummaries', array(), array( 'auth' => false ) );
		delete_transient( 'f3_mcp_google_api_' . Credentials::identity_key() );
		FakeHttp::push( '/drive/v3/files', 403, array( 'error' => array( 'status' => 'PERMISSION_DENIED' ) ) );
		GoogleClient::get( GoogleClient::HOST_GOOGLE . '/drive/v3/files', array(), array( 'auth' => false ) );
		$state = GoogleClient::api_status();
		$this->assertTrue( $state['analytics-admin']['enabled'] );
		$this->assertSame( 'permission_denied', $state['drive']['status'] );
		Options::set( Policy::OPTION, array( 'mode' => 'restricted' ) );
		$this->assertTrue( GoogleClient::api_status()['analytics-admin']['context_changed'] );
		$this->assertTrue( GoogleClient::api_status()['analytics-admin']['stale'] );
	}

	public function test_interrupted_request_is_counted_before_a_response_exists(): void {
		$url = GoogleClient::HOST_GA_DATA . '/v1beta/properties/123:runReport';
		Telemetry::started( $url, array( 'mode' => 'read' ) );
		$state = Telemetry::state();
		$this->assertSame( 1, $state['counters']['http_attempts'] );
		$this->assertSame( 0, $state['apis']['analytics-data']['completed'] );
		Telemetry::finished( $url, new \WP_Error( 'fixture_timeout', 'Timeout' ), 0.125 );
		$state = Telemetry::state();
		$this->assertSame( 1, $state['counters']['http_attempts'] );
		$this->assertSame( 1, $state['counters']['http_errors'] );
		$this->assertSame( 1, $state['apis']['analytics-data']['completed'] );
		$this->assertSame( 125, $state['apis']['analytics-data']['duration_ms'] );
	}

	public function test_cache_index_failure_never_leaves_an_unindexed_token(): void {
		$GLOBALS['f3_test_write_fail'][ Options::TOKEN_INDEX ] = true;
		$key = Credentials::CACHE_PREFIX . 'unindexed-fixture';
		try {
			Credentials::remember( $key, 'synthetic-token', 300 );
			$this->assertFalse( get_transient( $key ) );
			$this->assertSame( '', Credentials::cached( $key ) );
		} finally { $GLOBALS['f3_test_write_fail'] = array(); }
	}

	public function test_bounded_cache_index_evicts_the_corresponding_transient(): void {
		for ( $i = 0; $i < 21; ++$i ) { Credentials::remember( Credentials::CACHE_PREFIX . 'fixture-' . $i, 'synthetic-token', 300 ); }
		$this->assertCount( 20, Options::get( Options::TOKEN_INDEX ) );
		$this->assertFalse( get_transient( Credentials::CACHE_PREFIX . 'fixture-0' ) );
		$this->assertSame( 'synthetic-token', Credentials::cached( Credentials::CACHE_PREFIX . 'fixture-20' ) );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_quota_observations_do_not_infer_limits_or_cross_connections(): void {
		Telemetry::quota( GoogleClient::HOST_GA_DATA . '/v1beta/properties/123:runReport', array( 'propertyQuota' => array( 'tokensPerHour' => array( 'consumed' => 4, 'remaining' => 300 ), 'tokensPerDay' => array( 'remaining' => 800 ), 'unknownGroup' => array( 'remaining' => 9 ) ) ) );
		$state = Telemetry::quotas();
		$this->assertFalse( $state['global_google_quota_known'] );
		$this->assertCount( 1, $state['observations'] );
		$quota = $state['observations'][0]['observations']['tokensPerHour'];
		$this->assertSame( 'tokens', $quota['unit'] );
		$this->assertSame( 4, $quota['consumed_by_request'] );
		$this->assertSame( 300, $quota['remaining_after_request'] );
		$this->assertNull( $quota['limit'] );
		$this->assertNull( $state['observations'][0]['observations']['tokensPerDay']['consumed_by_request'] );
		Connections::create( 'other', 'Other' );
		$this->assertSame( array(), Connections::run( 'other', static fn() => Telemetry::quotas() )['observations'] );
		Options::set( Policy::OPTION, array( 'mode' => 'restricted' ) );
		$this->assertSame( array(), Telemetry::quotas()['observations'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_status_all_connections_and_cron_backlog_are_local(): void {
		Connections::create( 'other', 'Other' );
		Records::put( 'schedule', 'late', array( 'enabled' => true, 'connection_id' => 'default', 'next_run' => time() - 600, 'blocked_reason' => 'review_required' ) );
		$state = Abilities::status( array( 'scope' => 'all_connections' ) );
		$this->assertTrue( $state['success'], json_encode( $state ) );
		$this->assertCount( 2, $state['connections'] );
		$connections = array_column( $state['connections'], null, 'connection_id' );
		$this->assertSame( 1, $connections['default']['cron']['agendas_vencidas'] );
		$this->assertSame( 'blocked', $connections['default']['cron']['health'] );
		$this->assertSame( 0, $connections['other']['cron']['agendas_vencidas'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_closed_channel_allows_only_explicit_admin_local_actions(): void {
		Options::set( Options::ENABLED, false );
		$this->assertFalse( wp_get_ability( 'google/export-template' )->execute( array() )['success'] );
		$r = Gate::administrative( 'google/export-template', static fn() => wp_get_ability( 'google/export-template' )->execute( array() ) );
		$this->assertTrue( $r['success'], json_encode( $r ) );
		$r = Gate::administrative( 'google/status', static fn() => wp_get_ability( 'google/status' )->execute( array() ) );
		$this->assertFalse( $r['success'] );
		$this->assertFalse( Gate::permission( 'any' ) );
		$this->assertSame( 0, FakeHttp::count() );
	}
}
