<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Auth\Credentials, Automation\Context, Automation\FrozenInput, Automation\Jobs, Connections, Options, Records, Settings};
use PHPUnit\Framework\TestCase;
final class QueueIntentTest extends TestCase {
 protected function setUp(): void {
  $GLOBALS['f3_test_options']=array();$GLOBALS['f3_test_transients']=array();$GLOBALS['f3_test_write_fail']=array();$GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;FakeHttp::reset();
  Options::batch_verified(array(Options::ENABLED=>true,Options::GA_ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'test.apps.googleusercontent.com'),array(Options::OAUTH_CLIENT_SECRET=>'synthetic-secret',Options::OAUTH_REFRESH_TOKEN=>'synthetic-refresh'));
 }
 public function test_repeated_intention_uses_frozen_job_without_resolving_new_defaults(): void {
  Options::set(Connections::BINDINGS,array('ga_property_id'=>'123'));
  $input=array('task'=>'report','parameters'=>array('template'=>'traffic'),'idempotency_key'=>'same');
  $r=Jobs::create($input);$this->assertTrue($r['success'],json_encode($r));$job=Records::get('job',$r['job_id']);
  $this->assertSame(array('properties/123'),$job['parameters']['accounts']);$this->assertIsArray($job['parameters']['date_range']);
  Options::set(Connections::BINDINGS,array('ga_property_id'=>'456'));
  $repeat=Jobs::create($input);$this->assertTrue($repeat['success']);$this->assertFalse($repeat['created']);$this->assertSame($job,Records::get('job',$r['job_id']));$this->assertNull(Context::validate($job['context']));$this->assertCount(0,FakeHttp::$requests);
 }
 public function test_changed_intention_with_same_key_is_refused(): void {
  $input=array('task'=>'query','parameters'=>array('connector'=>'ga4','accounts'=>array('123'),'date_range'=>'last_7_days'),'idempotency_key'=>'key');
  $this->assertTrue(Jobs::create($input)['success']);$input['parameters']['accounts']=array('456');$this->assertSame('f3_google_job_key_conflict',Jobs::create($input)['error_code']);
 }
 public function test_nested_blend_queries_and_recurring_dates_are_frozen_correctly(): void {
  $query=array('connector'=>'ga4','accounts'=>array('123'),'metrics'=>array('sessions'));
  $blend=array('queries'=>array(array('query'=>$query,'prefix'=>'a'),array('query'=>$query,'prefix'=>'b')),'date_range'=>'last_7_days');
  $r=FrozenInput::resolve('export',array('blend'=>$blend));$this->assertIsArray($r);$this->assertIsArray($r['blend']['queries'][0]['query']['date_range']);
  $schedule=Jobs::schedule(array('task'=>'query','parameters'=>$query+array('date_range'=>'last_7_days')));$this->assertTrue($schedule['success'],json_encode($schedule));$this->assertSame('last_7_days',$schedule['schedule']['parameters']['date_range']);
  $this->assertSame(array('properties/123'),$schedule['schedule']['parameters']['accounts']);
 }
 public function test_rotation_keeps_service_account_principal_but_new_account_blocks(): void {
  $pair=openssl_pkey_new(array('private_key_bits'=>2048));openssl_pkey_export($pair,$private);
  $key=array('type'=>'service_account','project_id'=>'synthetic','private_key'=>$private,'private_key_id'=>'initial','token_uri'=>'https://oauth2.googleapis.com/token');
  $key['client_id']='123';$key['client_email']='test@example.iam.gserviceaccount.com';
  Options::set(Options::AUTH_MODE,'service_account');Options::set_secret(Options::SA_JSON,json_encode($key));
  $ctx=Context::capture();$cache=Credentials::identity_key();$key['private_key_id']='rotated';Options::set_secret(Options::SA_JSON,json_encode($key));
  $this->assertNotSame($cache,Credentials::identity_key());$this->assertNull(Context::validate($ctx));
  $key['client_id']='456';Options::set_secret(Options::SA_JSON,json_encode($key));$this->assertSame('f3_google_job_context_changed',Context::validate($ctx)->get_error_code());
 }
 public function test_invalid_recurring_date_is_refused_before_any_http(): void {
  $r=Jobs::schedule(array('task'=>'query','parameters'=>array('connector'=>'ga4','accounts'=>array('123'),'date_range'=>'invalid')));$this->assertFalse($r['success']);$this->assertCount(0,FakeHttp::$requests);
 }
 public function test_report_catalog_defaults_and_frozen_comparison_share_execution_definition(): void {
  $catalog=\Fator3\McpGoogle\Automation\Reports::templates();
  $query=\Fator3\McpGoogle\Automation\Reports::definition(array('template'=>'organic-page-drops'));
  $this->assertSame($catalog['organic-page-drops']['default_date_range'],$query['date_range']);
  $this->assertSame('previous_period',$query['compare_date_range']);$this->assertArrayNotHasKey('alert_schema',$query);$this->assertArrayNotHasKey('description',$query);
  $frozen=FrozenInput::resolve('report',array('template'=>'organic-page-drops','accounts'=>array('https://example.test/'),'date_range'=>array('from'=>'2026-09-10','to'=>'2026-09-16')));
  $this->assertSame(array('from'=>'2026-09-03','to'=>'2026-09-09'),$frozen['compare_date_range']);
  $recurring=FrozenInput::resolve('report',array('template'=>'organic-page-drops','accounts'=>array('https://example.test/'),'date_range'=>'last_7_days'),false);
  $this->assertSame('previous_period',$recurring['compare_date_range']);
  $invalid=\Fator3\McpGoogle\Automation\Reports::run(array('template'=>'traffic','accounts'=>array('123'),'alert'=>array('metric'=>'ctr')));
  $this->assertSame('f3_google_report_alert',$invalid['error_code']);$this->assertCount(0,FakeHttp::$requests);
 }

}
