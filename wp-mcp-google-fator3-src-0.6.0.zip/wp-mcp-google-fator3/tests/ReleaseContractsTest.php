<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Auth\Candidate, Confirmation, Connections, McpBridge, Options, Plugin, Policy, Records, Settings, Template};
use Fator3\McpGoogle\{Automation\Jobs, Automation\Operations, Generic\Discovery, Http\GoogleClient, Http\PublicPage};
use PHPUnit\Framework\TestCase;
final class ReleaseContractsTest extends TestCase {
 protected function setUp(): void {
  $GLOBALS['f3_test_options']=array();$GLOBALS['f3_test_transients']=array();$GLOBALS['f3_test_write_fail']=array();$GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user_caps']=array();$GLOBALS['f3_test_user']=1;FakeHttp::reset();
  Options::batch_verified(array(Options::ENABLED=>true,Options::GA_ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'test.apps.googleusercontent.com'),array(Options::OAUTH_CLIENT_SECRET=>'synthetic-secret',Options::OAUTH_REFRESH_TOKEN=>'synthetic-refresh'));
  foreach(array('analytics-admin-v1alpha'=>'analyticsadmin-v1alpha','analytics-admin-v1beta'=>'analyticsadmin-v1beta','search-console'=>'searchconsole-v1','sheets'=>'sheets-v4','drive'=>'drive-v3') as $api=>$file){set_transient(Discovery::cache_key($api),json_decode(file_get_contents(__DIR__.'/fixtures/discovery/'.$file.'.json'),true),600);}
  FakeHttp::push('oauth2.googleapis.com/token',200,array('access_token'=>'synthetic-token','expires_in'=>3600));Plugin::register_abilities();
 }
 private function no_mutations(): void {foreach(FakeHttp::$requests as $r){if(str_contains($r['url'],'/token')){continue;}$this->assertSame('GET',$r['method']);}}
 private function delete_input(): array {return array('api'=>'search-console','method'=>'webmasters.sitemaps.delete','path_params'=>array('siteUrl'=>'https://example.test/','feedpath'=>'https://example.test/sitemap.xml'));}
 private function prepared(array $params): array {for($i=0;$i<6;++$i){FakeHttp::push('/sitemaps/',200,array('path'=>'https://example.test/sitemap.xml'),array(),'GET');}$r=Confirmation::prepare(array('ability'=>'google/execute-action','parameters'=>$params));$this->assertTrue($r['success'],json_encode($r));return $r;}
 public function test_prepare_delete_performs_no_remote_write_and_replay_is_refused(): void {
  $params=$this->delete_input();$p=$this->prepared($params);$this->no_mutations();
  FakeHttp::push('/sitemaps/',204,'',array(),'DELETE');$r=wp_get_ability('google/execute-action')->execute($params+array('confirmation_token'=>$p['confirmation_token']));
  $this->assertTrue($r['success'],json_encode($r));$this->assertSame('applied',$r['operation_outcome']);$count=FakeHttp::count();
  $replay=wp_get_ability('google/execute-action')->execute($params+array('confirmation_token'=>$p['confirmation_token']));$this->assertSame('f3_google_confirmation_used',$replay['error_code']);$this->assertSame($count,FakeHttp::count());
  $attempts=Records::list('attempt');$this->assertCount(1,$attempts);$this->assertSame('applied',reset($attempts)['operation_outcome']);
 }
 public function test_changed_actor_body_revision_and_expiry_refuse_before_write(): void {
  $params=$this->delete_input();$p=$this->prepared($params);$signed=$params+array('confirmation_token'=>$p['confirmation_token']);
  wp_set_current_user(2);$this->assertSame('f3_google_confirmation_changed',wp_get_ability('google/execute-action')->execute($signed)['error_code']);wp_set_current_user(1);
  $changed=$signed;$changed['path_params']['feedpath']='https://example.test/other.xml';$this->assertSame('f3_google_confirmation_changed',wp_get_ability('google/execute-action')->execute($changed)['error_code']);
  Options::set(Connections::BINDINGS,array('gsc_site_url'=>'https://changed.test/'));$this->assertSame('f3_google_confirmation_changed',wp_get_ability('google/execute-action')->execute($signed)['error_code']);
  $record=Records::get('confirmation',hash('sha256',$p['confirmation_token']));$record['expires_at']=time()-1;Records::put('confirmation',hash('sha256',$p['confirmation_token']),$record);Options::delete(Connections::BINDINGS);
  $this->assertSame('f3_google_confirmation_changed',wp_get_ability('google/execute-action')->execute($signed)['error_code']);
  $this->no_mutations();
 }
 public function test_unconfirmed_delete_denied_on_generic_and_read_mcp_tool(): void {
  $r=wp_get_ability('google/execute-action')->execute($this->delete_input());$this->assertSame('f3_google_confirmation_required',$r['error_code']);
  $m=McpBridge::dispatch(array('ability'=>'google/execute-action','parameters'=>$this->delete_input()),false);$this->assertSame('f3_google_mcp_mode',$m['error_code']);$this->assertArrayHasKey('error',$m);$this->no_mutations();
 }
 public function test_retention_increase_without_extra_confirmation_but_reduction_denied(): void {
  $url=GoogleClient::HOST_GA_ADMIN.'/v1beta/properties/123/dataRetentionSettings';
  FakeHttp::push('dataRetentionSettings',200,array('eventDataRetention'=>'TWO_MONTHS'));
  GoogleClient::get($url,array(),array('auth'=>false,'mode'=>'read'));
  FakeHttp::push('dataRetentionSettings',200,array('eventDataRetention'=>'FOURTEEN_MONTHS'));
  $r=GoogleClient::request('PATCH',$url,array('eventDataRetention'=>'FOURTEEN_MONTHS'),array('auth'=>false,'mode'=>'write'));$this->assertFalse(is_wp_error($r));
  FakeHttp::push('dataRetentionSettings',200,array('eventDataRetention'=>'FOURTEEN_MONTHS'));GoogleClient::get($url,array(),array('auth'=>false,'mode'=>'read'));
  $r=GoogleClient::request('PATCH',$url,array('eventDataRetention'=>'TWO_MONTHS'),array('auth'=>false,'mode'=>'write'));$this->assertSame('f3_google_confirmation_required',$r->get_error_code());
 }
 public function test_restricted_policy_denies_target_and_related_resources(): void {
  Options::set(Policy::OPTION,array('mode'=>'restricted','services'=>array('sheets'=>array('resources'=>array('allowed')),'ga'=>array('resources'=>array('properties/123')))));
  $r=Policy::check_http('POST',GoogleClient::HOST_SHEETS.'/v4/spreadsheets/allowed:batchUpdate',array('requests'=>array(array('copySheetToSpreadsheet'=>array('destinationSpreadsheetId'=>'denied')))),array('mode'=>'write','connector'=>'sheets','operation_id'=>'sheets.spreadsheets.batchUpdate'));
  $this->assertSame('f3_google_policy_denied',$r->get_error_code());
  $r=Policy::check_http('GET',GoogleClient::HOST_GA_ADMIN.'/v1beta/properties/456',null,array('mode'=>'read','connector'=>'ga','operation_id'=>'analyticsadmin.properties.get'));$this->assertSame('f3_google_policy_denied',$r->get_error_code());$this->assertCount(0,FakeHttp::$requests);
 }
 public function test_candidate_failure_preserves_active_credentials(): void {
  Candidate::save('oauth',array(Options::OAUTH_CLIENT_ID=>'candidate.apps.googleusercontent.com'),array(Options::OAUTH_CLIENT_SECRET=>'candidate-secret',Options::OAUTH_REFRESH_TOKEN=>'candidate-refresh'));
  FakeHttp::reset();FakeHttp::push('oauth2.googleapis.com/token',400,array('error'=>'invalid_grant','error_description'=>'revoked'));
  $r=Candidate::promote('oauth');$this->assertFalse($r['success']);$this->assertTrue($r['active_preserved']);$this->assertSame('synthetic-refresh',Options::get_secret(Options::OAUTH_REFRESH_TOKEN));$this->assertTrue(Candidate::state('oauth')['present']);
 }
 public function test_inspection_works_with_read_profile_and_inline_deduplication(): void {
  Options::set(Connections::SERVICES,array('gsc'=>'read'));
  foreach(array(1,2) as $i){FakeHttp::push('index:inspect',200,array('inspectionResult'=>array('indexStatusResult'=>array('verdict'=>'PASS'))));}
  $params=array('site_url'=>'https://example.test/','urls'=>array('https://example.test/one','https://example.test/two','https://example.test/one'),'idempotency_key'=>'one');
  $r=wp_get_ability('gsc/inspect-urls')->execute($params);$this->assertTrue($r['success'],json_encode($r));$this->assertSame('completed',$r['status']);$this->assertCount(2,$r['job']['results']);$count=FakeHttp::count();
  $repeat=wp_get_ability('gsc/inspect-urls')->execute($params);$this->assertFalse($repeat['created']);$this->assertSame($count,FakeHttp::count());
 }
 public function test_unknown_job_cannot_be_deleted_or_replayed_and_requires_evidence(): void {
  $job=array('id'=>'uncertain','task'=>'sitemap','status'=>'unknown','write'=>true,'connection_id'=>'default','user_id'=>1,'cursor'=>0,'parameters'=>array());Records::put('job','uncertain',$job);
  $this->assertFalse(Operations::action('delete-job',array('job_id'=>'uncertain'))['success']);
  $this->assertFalse(Operations::action('reconcile-job',array('job_id'=>'uncertain','observed_outcome'=>'not_applied','evidence'=>'short'))['success']);
  $r=Operations::action('reconcile-job',array('job_id'=>'uncertain','observed_outcome'=>'applied','evidence'=>'Conferido no destino pelo operador.'));$this->assertTrue($r['success']);$this->assertSame('reconciled',$r['job']['status']);$this->assertCount(0,FakeHttp::$requests);
 }
 /** @dataProvider private_urls */
 public function test_public_fetch_rejects_private_and_host_confusion(string $url,string $host): void {$this->assertTrue(is_wp_error(PublicPage::validate($url,array($host))));}
 public static function private_urls(): array {return array(array('http://127.0.0.1/x','127.0.0.1'),array('http://169.254.169.254/x','169.254.169.254'),array('http://10.0.0.1/x','10.0.0.1'),array('https://example.test@127.0.0.1/','127.0.0.1'),array('http://[::ffff:127.0.0.1]/','[::ffff:127.0.0.1]'),array('http://127.0.0.1./','127.0.0.1.'));}
}
