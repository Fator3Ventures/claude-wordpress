<?php
/** @package Fator3\McpGoogle\Tests */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Sheets\Export;
use Fator3\McpGoogle\Unified\Blend;
use PHPUnit\Framework\TestCase;

final class BlendSheetsTest extends TestCase {

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;
		FakeHttp::reset();
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'oauth' );
		Options::set( Options::OAUTH_CLIENT_ID, 'test.apps.googleusercontent.com' );
		Options::set( Options::OAUTH_EMAIL, 'test@example.test' );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'test-client-secret' );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'test-refresh-token' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'test-developer-token' );
		$scopes = array();
		foreach ( array( 'ga', 'ads', 'sheets', 'drive', 'gsc' ) as $connector ) {
			$list = Credentials::scopes_for( $connector );
			Credentials::remember( Credentials::cache_key( $list ), 'test-access-token', 3600 );
			$scopes = array_merge( $scopes, $list );
		}
		$scopes = array_values( array_unique( $scopes ) );
		Options::set( Options::OAUTH_SCOPES, $scopes );
		foreach ( $scopes as $scope ) {
			Credentials::remember( Credentials::cache_key( array( $scope ) ), 'test-access-token', 3600 );
		}
		foreach ( array( 'sheets' => 'sheets-v4', 'drive' => 'drive-v3', 'search-console' => 'searchconsole-v1' ) as $api => $fixture ) {
			$doc = json_decode( (string) file_get_contents( __DIR__ . '/fixtures/discovery/' . $fixture . '.json' ), true );
			$this->assertIsArray( $doc );
			set_transient( Discovery::cache_key( $api ), $doc, 86400 );
		}
		if ( null === wp_get_ability( 'google/blend' ) ) {
			Blend::register();
		}
		if ( null === wp_get_ability( 'google/export-to-sheet' ) ) {
			Export::register();
		}
	}

	private function table( string $connector, array $columns, array $rows, bool $compare = false ): array {
		$table = array(
			'success' => true, 'connector' => $connector,
			'columns' => array_map( static function ( string $id ): array { return array( 'id' => $id, 'label' => $id, 'type' => in_array( $id, array( 'sessions', 'clicks', 'ctr' ), true ) ? 'metric' : 'dimension', 'kind' => 'string' ); }, $columns ),
			'rows' => $rows, 'row_count' => count( $rows ), 'accounts' => array( array( 'account_id' => $connector . '-1' ) ), 'warnings' => array(), 'truncated' => false,
			'date_range' => array( 'from' => '2026-08-01', 'to' => '2026-08-31', 'name' => 'custom' ),
		);
		if ( $compare ) {
			$table['compare_date_range'] = array( 'from' => '2026-07-01', 'to' => '2026-07-31', 'name' => 'custom' );
		}
		return $table;
	}

	public function test_full_join_normalizes_dates_campaign_and_keeps_unmatched_rows(): void {
		$ga  = $this->table( 'ga4', array( 'date', 'sessionCampaignName', 'sessions' ), array( array( '20260801', 'Brand', 20 ), array( '20260802', 'Only GA', 5 ) ) );
		$ads = $this->table( 'google-ads', array( 'date', 'campaign_name', 'clicks' ), array( array( '2026-08-01', 'Brand', 7 ), array( '2026-08-03', 'Only Ads', 9 ) ) );
		$r = Blend::combine( array( array( 'prefix' => 'ga4', 'table' => $ga ), array( 'prefix' => 'ads', 'table' => $ads ) ), array( 'on' => array( 'date', 'campaign' ) ) );
		$this->assertTrue( $r['success'], $r['message'] );
		$this->assertSame( array( 'date', 'campaign', 'ga4.sessions', 'ads.clicks' ), array_column( $r['columns'], 'id' ) );
		$this->assertSame( array( array( '2026-08-01', 'Brand', 20, 7 ), array( '2026-08-02', 'Only GA', 5, null ), array( '2026-08-03', 'Only Ads', null, 9 ) ), $r['rows'] );
		$this->assertSame( array( 'ga4' => 1, 'ads' => 1 ), $r['unmatched'] );
		$this->assertCount( 2, $r['warnings'] );
	}

	public function test_page_url_join_preserves_period_identity_even_when_dates_overlap(): void {
		$cols = array( 'date_range_name', 'date', 'pagePath', 'sessions' );
		$ga = $this->table( 'ga4', $cols, array( array( 'current', '20260801', '/produto', 50 ), array( 'previous', '20260801', '/produto', 40 ) ), true );
		$gsc = $this->table( 'search-console', array( 'date_range_name', 'date', 'page', 'clicks' ), array( array( 'current', '2026-08-01', 'https://example.test/produto?q=1#top', 8 ), array( 'previous', '2026-08-01', 'https://example.test/produto', 6 ) ), true );
		$r = Blend::combine( array( array( 'prefix' => 'ga4', 'table' => $ga ), array( 'prefix' => 'gsc', 'table' => $gsc ) ), array( 'on' => array( 'date', 'page' ) ) );
		$this->assertTrue( $r['success'], $r['message'] );
		$this->assertSame( array( array( 'current', '2026-08-01', '/produto', 50, 8 ), array( 'previous', '2026-08-01', '/produto', 40, 6 ) ), $r['rows'] );
		$this->assertArrayHasKey( 'compare_date_range', $r );
		$this->assertSame( array(), $r['warnings'] );
	}

	public function test_duplicate_keys_never_fan_out_or_sum_average_metrics(): void {
		$ga = $this->table( 'ga4', array( 'date', 'sessions' ), array( array( '20260801', 10 ), array( '20260801', 15 ) ) );
		$ads = $this->table( 'google-ads', array( 'date', 'ctr' ), array( array( '2026-08-01', 0.1 ), array( '2026-08-01', 0.2 ) ) );
		$r = Blend::combine( array( array( 'prefix' => 'ga', 'table' => $ga ), array( 'prefix' => 'ads', 'table' => $ads ) ) );
		$this->assertFalse( $r['success'] );
		$this->assertSame( 'f3_google_blend_duplicate_key', $r['error_code'] );
		$this->assertSame( array( '2026-08-01' ), $r['duplicate_key'] );
		$this->assertArrayNotHasKey( 'rows', $r );
	}

	public function test_page_normalization_collision_is_reported_instead_of_summed(): void {
		$ga = $this->table( 'ga4', array( 'pagePath', 'sessions' ), array( array( '/p', 10 ) ) );
		$gsc = $this->table( 'search-console', array( 'page', 'clicks' ), array( array( 'https://example.test/p?a=1', 2 ), array( 'https://example.test/p?a=2', 3 ) ) );
		$r = Blend::combine( array( array( 'prefix' => 'ga', 'table' => $ga ), array( 'prefix' => 'gsc', 'table' => $gsc ) ), array( 'on' => array( 'page' ) ) );
		$this->assertSame( 'f3_google_blend_duplicate_key', $r['error_code'] );
	}

	public function test_inner_and_left_joins_report_excluded_unmatched_sources(): void {
		$tables = array( array( 'prefix' => 'ga', 'table' => $this->table( 'ga4', array( 'date', 'sessions' ), array( array( '20260801', 1 ) ) ) ), array( 'prefix' => 'ads', 'table' => $this->table( 'google-ads', array( 'date', 'clicks' ), array( array( '2026-08-02', 2 ) ) ) ) );
		$inner = Blend::combine( $tables, array( 'join' => 'inner' ) );
		$this->assertSame( 0, $inner['row_count'] );
		$this->assertCount( 2, $inner['warnings'] );
		$left = Blend::combine( $tables, array( 'join' => 'left' ) );
		$this->assertSame( array( array( '2026-08-01', 1, null ) ), $left['rows'] );
	}

	public function test_mixed_comparisons_and_invalid_dates_are_rejected(): void {
		$ga = $this->table( 'ga4', array( 'date', 'sessions' ), array( array( '20260801', 1 ) ) );
		$ads = $this->table( 'google-ads', array( 'date_range_name', 'date', 'clicks' ), array( array( 'current', '2026-08-01', 1 ) ), true );
		$r = Blend::combine( array( array( 'prefix' => 'ga', 'table' => $ga ), array( 'prefix' => 'ads', 'table' => $ads ) ) );
		$this->assertSame( 'f3_google_blend_periods', $r['error_code'] );
		$bad = $this->table( 'ga4', array( 'date', 'sessions' ), array( array( '20260231', 1 ) ) );
		$r = Blend::combine( array( array( 'prefix' => 'bad', 'table' => $bad ), array( 'prefix' => 'ga', 'table' => $ga ) ) );
		$this->assertSame( 'f3_google_blend_date', $r['error_code'] );
	}

	public function test_empty_sources_keep_schema_and_propagate_truncation(): void {
		$ga = $this->table( 'ga4', array( 'date', 'sessions' ), array() );
		$ads = $this->table( 'google-ads', array( 'date', 'clicks' ), array( array( '2026-08-01', 10 ) ) );
		$ads['truncated'] = true;
		$ads['warnings'][] = 'Limite atingido';
		$r = Blend::combine( array( array( 'prefix' => 'ga', 'table' => $ga ), array( 'prefix' => 'ads', 'table' => $ads ) ) );
		$this->assertTrue( $r['success'] );
		$this->assertSame( array( array( '2026-08-01', null, 10 ) ), $r['rows'] );
		$this->assertTrue( $r['truncated'] );
		$this->assertCount( 3, $r['warnings'] );
	}

	private function query(): array {
		return array( 'connector' => 'ga4', 'accounts' => array( 'properties/123456' ), 'dimensions' => array( 'date' ), 'metrics' => array( 'sessions' ), 'date_range' => array( 'from' => '2026-08-01', 'to' => '2026-08-31' ) );
	}

	private function ga( array $rows = array( array( '20260801', 10 ) ), string $dimension = 'date' ): void {
		FakeHttp::push( ':runReport', 200, array( 'dimensionHeaders' => array( array( 'name' => $dimension ) ), 'metricHeaders' => array( array( 'name' => 'sessions', 'type' => 'TYPE_INTEGER' ) ), 'rows' => array_map( static function ( array $row ): array { return array( 'dimensionValues' => array( array( 'value' => (string) $row[0] ) ), 'metricValues' => array( array( 'value' => (string) $row[1] ) ) ); }, $rows ), 'rowCount' => count( $rows ) ) );
	}

	private function metadata( array $titles = array( 'Relatório' ), string $id = 'sheet-existing' ): void {
		$sheets = array();
		foreach ( $titles as $i => $title ) {
			$sheets[] = array( 'properties' => array( 'sheetId' => $i, 'title' => $title, 'sheetType' => 'GRID', 'gridProperties' => array( 'rowCount' => 1000, 'columnCount' => 26 ) ) );
		}
		FakeHttp::push( '/v4/spreadsheets/' . $id . '?', 200, array( 'spreadsheetId' => $id, 'properties' => array( 'title' => 'Planilha' ), 'sheets' => $sheets ) );
	}

	private function snapshot( array $values = array() ): void {
		FakeHttp::push( '/values/', 200, array( 'values' => $values ) );
	}

	private function approved_export( array $input ): array {
		$p = \Fator3\McpGoogle\Confirmation::prepare( array( 'ability' => 'google/export-to-sheet', 'parameters' => $input ) );
		$this->assertTrue( $p['success'], json_encode( $p ) );
		$this->assertCount( 0, $this->mutations(), 'A preparação não grava planilhas nem permissões.' );
		return wp_get_ability( 'google/export-to-sheet' )->execute( $input + array( 'confirmation_token' => $p['confirmation_token'] ) );
	}

	private function mutations(): array {
		return array_values( array_filter( FakeHttp::$requests, static function ( array $r ): bool { return 'GET' !== $r['method'] && false === strpos( $r['url'], ':runReport' ); } ) );
	}

	public function test_export_replace_is_one_atomic_batch_and_audits_real_snapshots(): void {
		$this->ga();
		$this->metadata();
		$this->snapshot( array( array( 'old', 'value' ), array( 'before', 99 ) ) );
		FakeHttp::push( ':batchUpdate', 200, array( 'spreadsheetId' => 'sheet-existing', 'replies' => array( array() ) ) );
		$this->snapshot( array( array( 'date', 'sessions' ), array( '20260801', 10 ) ) );
		$r = wp_get_ability( 'google/export-to-sheet' )->execute( array( 'query' => $this->query(), 'spreadsheet_id' => 'sheet-existing' ) );
		$this->assertTrue( $r['success'], $r['message'] );
		$mutations = $this->mutations();
		$this->assertCount( 1, $mutations );
		$body = json_decode( $mutations[0]['body'], true );
		$this->assertSame( 'userEnteredValue', $body['requests'][0]['updateCells']['fields'] );
		$this->assertSame( array( 'sheetId' => 0 ), $body['requests'][0]['updateCells']['range'] );
		$this->assertSame( 10, $body['requests'][0]['updateCells']['rows'][1]['values'][1]['userEnteredValue']['numberValue'] );
		$this->assertFalse( $r['partial'] );
		$this->assertSame( 1, $r['tabs'][0]['rows_exported'] );
		$audit = Audit::recent( 1 )[0]['extra'];
		$this->assertArrayHasKey( 'before', $audit );
		$this->assertArrayHasKey( 'after', $audit );
		$this->assertSame( 'sheet-existing', $audit['before']['spreadsheet_id'] );
		$this->assertStringContainsString( 'before', (string) wp_json_encode( $audit['before'] ) );
		$this->assertStringContainsString( '20260801', (string) wp_json_encode( $audit['after'] ) );
	}

	public function test_export_append_checks_header_and_does_not_duplicate_it(): void {
		$this->ga();
		$this->metadata();
		$this->snapshot( array( array( 'date', 'sessions' ), array( '20260731', 9 ) ) );
		$this->snapshot( array( array( 'date', 'sessions' ) ) );
		FakeHttp::push( ':batchUpdate', 200, array( 'replies' => array( array() ) ) );
		$this->snapshot( array( array( 'date', 'sessions' ), array( '20260731', 9 ), array( '20260801', 10 ) ) );
		$r = Export::run( array( 'query' => $this->query(), 'spreadsheet_id' => 'sheet-existing', 'mode' => 'append' ) );
		$this->assertTrue( $r['success'], $r['message'] );
		$body = json_decode( $this->mutations()[0]['body'], true );
		$this->assertArrayHasKey( 'appendCells', $body['requests'][0] );
		$this->assertCount( 1, $body['requests'][0]['appendCells']['rows'] );
		$this->assertSame( '2026-08-01', $body['requests'][0]['appendCells']['rows'][0]['values'][0]['userEnteredValue']['stringValue'] );
		$this->assertFalse( $r['tabs'][0]['header_written'] );
	}

	public function test_export_append_header_mismatch_refuses_before_any_write(): void {
		$this->ga();
		$this->metadata();
		$this->snapshot( array( array( 'date', 'clicks' ), array( '20260731', 9 ) ) );
		$this->snapshot( array( array( 'date', 'clicks' ) ) );
		$r = Export::run( array( 'query' => $this->query(), 'spreadsheet_id' => 'sheet-existing', 'mode' => 'append' ) );
		$this->assertSame( 'f3_google_export_header', $r['error_code'] );
		$this->assertFalse( $r['partial'] );
		$this->assertCount( 0, $this->mutations() );
	}

	public function test_multiple_tabs_added_and_written_together_with_literal_formula_text(): void {
		for ( $phase = 0; $phase < 3; ++$phase ) {
		$this->ga( array( array( '=IMPORTXML("https://example.test","//x")', 10 ) ), 'pagePath' );
		$this->ga();
		$this->metadata( array( 'Sheet1' ) );
		}
		FakeHttp::push( ':batchUpdate', 200, array( 'replies' => array( array(), array(), array(), array() ) ) );
		$this->snapshot();
		$this->snapshot();
		$q = $this->query();
		$q['dimensions'] = array( 'pagePath' );
		$r = $this->approved_export( array( 'queries' => array( array( 'query' => $q, 'tab_name' => "D'água" ), array( 'query' => $this->query(), 'tab_name' => 'Datas' ) ), 'spreadsheet_id' => 'sheet-existing' ) );
		$this->assertTrue( $r['success'], $r['message'] );
		$this->assertCount( 1, $this->mutations() );
		$body = json_decode( $this->mutations()[0]['body'], true );
		$this->assertCount( 4, $body['requests'] );
		$this->assertSame( "D'água", $body['requests'][0]['addSheet']['properties']['title'] );
		$this->assertSame( '=IMPORTXML("https://example.test","//x")', $body['requests'][1]['updateCells']['rows'][1]['values'][0]['userEnteredValue']['stringValue'] );
		$this->assertStringNotContainsString( 'formulaValue', (string) wp_json_encode( $body ) );
		$this->assertStringContainsString( "'D''água'!A1:B51", rawurldecode( implode( '\n', array_column( FakeHttp::$requests, 'url' ) ) ) );
	}

	public function test_internal_table_adapter_preserves_literal_audit_cells_without_querying(): void {
		$table = $this->table( 'audit', array( 'action', 'target' ), array( array( '=HYPERLINK(1)', '@target' ) ) );
		\Fator3\McpGoogle\Ability::register( 'sheets/test-audit-rows', 'sheets', array( 'mode' => 'write', 'callback' => static fn( $input ) => Export::from_tables( $input, array( $table ) ) ) );
		for ( $i = 0; $i < 3; ++$i ) { $this->metadata( array( 'Sheet1' ) ); }
		FakeHttp::push( ':batchUpdate', 200, array( 'replies' => array( array(), array() ) ) );
		$this->snapshot();
		$input = array( 'spreadsheet_id' => 'sheet-existing' );
		$prepared = \Fator3\McpGoogle\Confirmation::prepare( array( 'ability' => 'sheets/test-audit-rows', 'parameters' => $input ) );
		$this->assertTrue( $prepared['success'], json_encode( $prepared ) );
		$this->assertCount( 0, $this->mutations() );
		$result = wp_get_ability( 'sheets/test-audit-rows' )->execute( $input + array( 'confirmation_token' => $prepared['confirmation_token'] ) );
		$this->assertTrue( $result['success'], json_encode( $result ) );
		$body = json_decode( $this->mutations()[0]['body'], true );
		$this->assertSame( '=HYPERLINK(1)', $body['requests'][1]['updateCells']['rows'][1]['values'][0]['userEnteredValue']['stringValue'] );
		$this->assertStringNotContainsString( 'formulaValue', json_encode( $body ) );
		$this->assertStringNotContainsString( 'analyticsdata', implode( ' ', array_column( FakeHttp::$requests, 'url' ) ) );
	}

	public function test_invalid_email_duplicate_tabs_and_dry_run_refuse_before_network(): void {
		foreach ( array(
			array( 'query' => $this->query(), 'share_with' => array( 'invalid email' ) ),
			array( 'query' => $this->query(), 'dry_run' => true ),
			array( 'queries' => array( array( 'query' => $this->query(), 'tab_name' => 'SAME' ), array( 'query' => $this->query(), 'tab_name' => 'same' ) ) ),
		) as $input ) {
			$r = Export::run( $input + array( 'spreadsheet_id' => 'sheet-existing' ) );
			$this->assertFalse( $r['success'] );
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_export_and_blend_refuse_non_admin_without_network(): void {
		$GLOBALS['f3_test_caps'] = false;
		$r = Export::run( array( 'query' => $this->query(), 'spreadsheet_id' => 'sheet-existing' ) );
		$this->assertSame( 'f3_google_forbidden', $r['error_code'] );
		$r = Blend::run( array( 'queries' => array( $this->query(), $this->query() ) ) );
		$this->assertSame( 'f3_google_forbidden', $r['error_code'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_oauth_create_then_permission_denial_returns_created_id_and_confirmed_writes(): void {
		for ( $phase = 0; $phase < 3; ++$phase ) { $this->ga(); }
		FakeHttp::push( '/v4/spreadsheets', 200, array( 'spreadsheetId' => 'sheet-created' ), array(), 'POST' );
		for ( $phase = 0; $phase < 2; ++$phase ) { $this->metadata( array( 'Sheet1' ), 'sheet-created' ); }
		FakeHttp::push( ':batchUpdate', 200, array( 'replies' => array( array(), array() ) ) );
		FakeHttp::push( '/permissions', 403, array( 'error' => array( 'code' => 403, 'message' => 'The user does not have sufficient permissions for this file.', 'errors' => array( array( 'reason' => 'insufficientFilePermissions' ) ) ) ) );
		$this->snapshot( array( array( 'date', 'sessions' ), array( '20260801', 10 ) ) );
		$r = $this->approved_export( array( 'query' => $this->query(), 'title' => 'Novo relatório', 'share_with' => array( 'reader@example.test' ) ) );
		$this->assertFalse( $r['success'] );
		$this->assertTrue( $r['partial'] );
		$this->assertFalse( $r['outcome_uncertain'] );
		$this->assertSame( 'partial', $r['operation_outcome'] );
		$attempts = \Fator3\McpGoogle\Records::list( 'attempt' );
		$this->assertCount( 3, $attempts );
		$this->assertContains( 'sheet-created', array_column( array_column( $attempts, 'resources' ), 'spreadsheetId' ) );
		$this->assertCount( 1, \Fator3\McpGoogle\Records::list( 'continuation' ) );
		$this->assertSame( 'sheet-created', $r['spreadsheet_id'] );
		$this->assertSame( array( 'create_spreadsheet', 'write_tabs' ), array_column( $r['writes'], 'operation' ) );
		$this->assertSame( 'share:reader@example.test', $r['failed_operation'] );
		$write = $this->mutations()[2];
		$this->assertStringContainsString( 'sendNotificationEmail=false', $write['url'] );
		$this->assertSame( 'reader', json_decode( $write['body'], true )['role'] );
		$this->assertCount( 3, $this->mutations() );
	}

	public function test_created_sheet_changed_between_planning_and_dispatch_stops_the_continuation(): void {
		for ( $phase = 0; $phase < 3; ++$phase ) { $this->ga(); }
		FakeHttp::push( '/v4/spreadsheets', 200, array( 'spreadsheetId' => 'sheet-created' ), array(), 'POST' );
		$this->metadata( array( 'Sheet1' ), 'sheet-created' );
		$this->metadata( array( 'Relatório' ), 'sheet-created' );
		$this->snapshot();
		$r = $this->approved_export( array( 'query' => $this->query(), 'title' => 'Novo relatório' ) );
		$this->assertFalse( $r['success'], json_encode( $r ) );
		$this->assertSame( 'f3_google_confirmation_request_changed', $r['error_code'] );
		$this->assertSame( 'partial', $r['operation_outcome'] );
		$this->assertSame( 'sheet-created', $r['spreadsheet_id'] );
		$this->assertSame( array( 'create_spreadsheet' ), array_column( $r['writes'], 'operation' ) );
		$this->assertCount( 1, $this->mutations() );
		$continuations = \Fator3\McpGoogle\Records::list( 'continuation' );
		$continuation = reset( $continuations );
		$this->assertSame( 'default', $continuation['connection_id'] );
		$this->assertSame( $continuation['confirmation_id'], $continuation['task'] );
	}

	public function test_failed_continuation_persistence_returns_created_id_without_any_followup_write(): void {
		for ( $phase = 0; $phase < 3; ++$phase ) { $this->ga(); }
		$input = array( 'query' => $this->query(), 'title' => 'Novo relatório' );
		$p = \Fator3\McpGoogle\Confirmation::prepare( array( 'ability' => 'google/export-to-sheet', 'parameters' => $input ) );
		$this->assertTrue( $p['success'], json_encode( $p ) );
		FakeHttp::push( '/v4/spreadsheets', 200, array( 'spreadsheetId' => 'sheet-created' ), array(), 'POST' );
		$this->metadata( array( 'Sheet1' ), 'sheet-created' );
		$id = hash( 'sha256', $p['confirmation_token'] ) . '_1';
		$GLOBALS['f3_test_write_fail'][ \Fator3\McpGoogle\Records::key( 'continuation', $id ) ] = true;
		try {
			$r = wp_get_ability( 'google/export-to-sheet' )->execute( $input + array( 'confirmation_token' => $p['confirmation_token'] ) );
			$this->assertFalse( $r['success'], json_encode( $r ) );
			$this->assertSame( 'f3_google_attempt_persistence', $r['error_code'] );
			$this->assertSame( 'partial', $r['operation_outcome'] );
			$this->assertSame( 'sheet-created', $r['spreadsheet_id'] );
			$this->assertCount( 1, $this->mutations() );
			$this->assertNull( \Fator3\McpGoogle\Records::get( 'continuation', $id ) );
		} finally { $GLOBALS['f3_test_write_fail'] = array(); }
	}

	public function test_shared_drive_folder_is_verified_and_drive_creates_in_that_parent(): void {
		Options::set( \Fator3\McpGoogle\Policy::OPTION, array( 'mode' => 'restricted', 'services' => array( 'ga' => array( 'resources' => array( 'properties/123456' ) ), 'drive' => array( 'resources' => array( 'shared-folder' ), 'allow_create' => true ), 'sheets' => array( 'resources' => array() ) ) ) );
		for ( $phase = 0; $phase < 3; ++$phase ) { $this->ga(); }
		for ( $phase = 0; $phase < 3; ++$phase ) { FakeHttp::push( '/files/shared-folder?', 200, array( 'id' => 'shared-folder', 'mimeType' => 'application/vnd.google-apps.folder', 'driveId' => 'shared-drive', 'capabilities' => array( 'canAddChildren' => true ) ) ); }
		FakeHttp::push( '/files?', 200, array( 'id' => 'sheet-created', 'parents' => array( 'shared-folder' ), 'driveId' => 'shared-drive' ), array(), 'POST' );
		for ( $phase = 0; $phase < 2; ++$phase ) { $this->metadata( array( 'Sheet1' ), 'sheet-created' ); }
		FakeHttp::push( ':batchUpdate', 200, array( 'replies' => array( array(), array() ) ) );
		$this->snapshot();
		$r = $this->approved_export( array( 'query' => $this->query(), 'shared_drive_folder_id' => 'shared-folder' ) );
		$this->assertTrue( $r['success'], $r['message'] );
		$this->assertTrue( $r['created'] );
		$this->assertFalse( \Fator3\McpGoogle\Policy::permitted( 'sheets', 'sheet-created' ), 'A autorização temporária não amplia a política persistida.' );
		$body = json_decode( $this->mutations()[0]['body'], true );
		$this->assertSame( array( 'shared-folder' ), $body['parents'] );
		$this->assertSame( 'application/vnd.google-apps.spreadsheet', $body['mimeType'] );
	}

	public function test_my_drive_folder_is_not_mistaken_for_shared_drive(): void {
		$this->ga();
		FakeHttp::push( '/files/shared-folder?', 200, array( 'id' => 'shared-folder', 'mimeType' => 'application/vnd.google-apps.folder', 'capabilities' => array( 'canAddChildren' => true ) ) );
		$r = \Fator3\McpGoogle\Confirmation::prepare( array( 'ability' => 'google/export-to-sheet', 'parameters' => array( 'query' => $this->query(), 'shared_drive_folder_id' => 'shared-folder' ) ) );
		$this->assertSame( 'f3_google_prepare_incomplete', $r['error_code'] );
		$this->assertCount( 0, $this->mutations() );
	}

	public function test_service_account_has_no_my_drive_creation_path(): void {
		Options::set( Options::AUTH_MODE, 'service_account' );
		$pair = openssl_pkey_new( array( 'private_key_bits' => 2048 ) );
		openssl_pkey_export( $pair, $key );
		Options::set_secret( Options::SA_JSON, (string) wp_json_encode( array( 'type' => 'service_account', 'client_email' => 'robot@test.iam.gserviceaccount.com', 'private_key' => $key, 'token_uri' => 'https://oauth2.googleapis.com/token' ) ) );
		$r = Export::run( array( 'query' => $this->query() ) );
		$this->assertSame( 'f3_google_service_account_storage', $r['error_code'] );
		$this->assertStringContainsString( 'spreadsheet_id', $r['message'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_failed_atomic_write_does_not_clear_or_retry_the_sheet(): void {
		$this->ga();
		$this->metadata();
		$this->snapshot( array( array( 'old' ), array( 'preserve me' ) ) );
		FakeHttp::push( ':batchUpdate', 400, array( 'error' => array( 'code' => 400, 'message' => 'Invalid request', 'status' => 'INVALID_ARGUMENT' ) ) );
		$r = Export::run( array( 'query' => $this->query(), 'spreadsheet_id' => 'sheet-existing' ) );
		$this->assertFalse( $r['success'] );
		$this->assertFalse( $r['partial'] );
		$this->assertCount( 1, $this->mutations() );
		$this->assertStringNotContainsString( ':batchClear', (string) wp_json_encode( FakeHttp::$requests ) );
	}

	public function test_blend_run_uses_real_query_path_and_injects_join_dimension(): void {
		$this->ga();
		$this->ga( array( array( '20260801', 20 ) ) );
		$q = $this->query();
		unset( $q['dimensions'] );
		$r = Blend::run( array( 'queries' => array( array( 'query' => $q, 'prefix' => 'first' ), array( 'query' => $q, 'prefix' => 'second' ) ) ) );
		$this->assertTrue( $r['success'], $r['message'] );
		$this->assertSame( array( array( '2026-08-01', 10, 20 ) ), $r['rows'] );
		$this->assertSame( array( array( 'name' => 'date' ) ), json_decode( FakeHttp::$requests[0]['body'], true )['dimensions'] );
	}

	public function test_export_blend_keeps_unmatched_values_empty_instead_of_zero(): void {
		for ( $phase = 0; $phase < 3; ++$phase ) {
		$this->ga( array( array( '20260801', 10 ) ) );
		$this->ga( array( array( '20260802', 20 ) ) );
		$this->metadata( array( 'Sheet1' ) );
		}
		FakeHttp::push( ':batchUpdate', 200, array( 'replies' => array( array(), array() ) ) );
		$this->snapshot();
		$q = $this->query();
		$r = $this->approved_export( array( 'blend' => array( 'queries' => array( array( 'query' => $q, 'prefix' => 'first' ), array( 'query' => $q, 'prefix' => 'second' ) ) ), 'spreadsheet_id' => 'sheet-existing' ) );
		$this->assertTrue( $r['success'], $r['message'] );
		$this->assertCount( 2, $r['warnings'] );
		$body = json_decode( $this->mutations()[0]['body'] );
		$rows = $body->requests[1]->updateCells->rows;
		$this->assertEquals( new \stdClass(), $rows[1]->values[2] );
		$this->assertEquals( new \stdClass(), $rows[2]->values[1] );
		$this->assertSame( 10, $rows[1]->values[1]->userEnteredValue->numberValue );
		$this->assertSame( 20, $rows[2]->values[2]->userEnteredValue->numberValue );
	}

	public function test_uncertain_write_reports_possible_effects_and_is_never_retried(): void {
		$this->ga();
		$this->metadata();
		$this->snapshot( array( array( 'old' ), array( 'preserve me' ) ) );
		FakeHttp::push( ':batchUpdate', 503, array( 'error' => array( 'code' => 503, 'message' => 'Backend unavailable', 'status' => 'UNAVAILABLE' ) ) );
		$r = Export::run( array( 'query' => $this->query(), 'spreadsheet_id' => 'sheet-existing', 'mode' => 'replace' ) );
		$this->assertFalse( $r['success'] );
		$this->assertTrue( $r['partial'] );
		$this->assertTrue( $r['outcome_uncertain'] );
		$this->assertSame( 'sheet-existing', $r['spreadsheet_id'] );
		$this->assertSame( array(), $r['writes'] );
		$this->assertCount( 1, $this->mutations() );
		$this->assertStringContainsString( 'Não repita automaticamente', $r['retry_advice'] );
	}
	public function test_unconfirmed_creation_and_sharing_never_write_a_partial_export(): void {
		foreach ( array( array( 'title' => 'New' ), array( 'spreadsheet_id' => 'existing', 'share_with' => array( 'reader@example.test' ) ) ) as $destination ) {
			$r = Export::run( array( 'query' => $this->query() ) + $destination );
			$this->assertSame( 'f3_google_confirmation_required', $r['error_code'] );
			$this->assertSame( 'not_applied', $r['operation_outcome'] );
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_denied_late_recipient_blocks_preparation_before_file_creation(): void {
		Options::set( \Fator3\McpGoogle\Policy::OPTION, array( 'mode' => 'restricted', 'services' => array( 'ga' => array( 'resources' => array( 'properties/123456' ) ), 'drive' => array( 'resources' => array( 'folder' ), 'allow_create' => true, 'recipients' => array( 'allowed@example.test' ) ), 'sheets' => array( 'resources' => array() ) ) ) );
		$this->ga();
		FakeHttp::push( '/files/folder?', 200, array( 'id' => 'folder', 'mimeType' => 'application/vnd.google-apps.folder', 'driveId' => 'drive', 'capabilities' => array( 'canAddChildren' => true ) ), array(), 'GET' );
		$r = \Fator3\McpGoogle\Confirmation::prepare( array( 'ability' => 'google/export-to-sheet', 'parameters' => array( 'query' => $this->query(), 'shared_drive_folder_id' => 'folder', 'share_with' => array( 'denied@example.test' ) ) ) );
		$this->assertFalse( $r['success'] );
		$this->assertCount( 0, $this->mutations() );
		$this->assertCount( 0, \Fator3\McpGoogle\Records::list( 'confirmation' ) );
	}

}
