<?php
/** Release-plan regressions; no real Google access. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Ability, Audit, Connections, Gate, Operation, Options, Plugin, Records, Response, Settings};
use Fator3\McpGoogle\Generic\{Discovery, ExecuteAction};
use Fator3\McpGoogle\Http\GoogleClient;
use PHPUnit\Framework\TestCase;
final class NextFoundationTest extends TestCase {
	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = array(); $GLOBALS['f3_test_transients'] = array(); $GLOBALS['f3_test_write_fail'] = array(); $GLOBALS['f3_test_caps'] = true;
		FakeHttp::reset();
		Options::batch_verified( array( Options::ENABLED => true, Options::GA_ENABLED => true, Options::AUTH_MODE => 'oauth', Options::OAUTH_CLIENT_ID => 'test.apps.googleusercontent.com' ), array( Options::OAUTH_CLIENT_SECRET => 'synthetic-secret', Options::OAUTH_REFRESH_TOKEN => 'synthetic-refresh' ) );
		foreach ( array( 'analytics-admin-v1beta' => 'analyticsadmin-v1beta', 'analytics-data-v1beta' => 'analyticsdata-v1beta', 'search-console' => 'searchconsole-v1', 'sheets' => 'sheets-v4' ) as $api => $file ) {
			set_transient( Discovery::cache_key( $api ), json_decode( file_get_contents( __DIR__ . '/fixtures/discovery/' . $file . '.json' ), true ), 600 );
		}
		Plugin::register_abilities();
	}
	private function token(): void { FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'synthetic-token', 'expires_in' => 3600 ) ); }
	public function test_existing_and_new_metadata_have_current_version(): void {
		$abilities = wp_get_abilities(); $count = 0;
		foreach ( $abilities as $ability ) {
			if ( 'google' !== $ability->get_category() ) { continue; }
			$this->assertSame( F3_MCP_GOOGLE_VERSION, $ability->get_meta()['fator3']['version'] ); ++$count;
		}
		$this->assertGreaterThanOrEqual( 134, $count );
	}
	public function test_ads_missing_token_is_not_configured_not_approved(): void {
		Options::set( Options::ADS_ENABLED, true );
		$r = \Fator3\McpGoogle\SelfTest::run();
		$config = array_values( array_filter( $r['checks'], static fn( $check ) => 'config' === $check['name'] ) )[0];
		$this->assertSame( 'not_configured', $config['status'] ); $this->assertFalse( $r['checks_passed'] ); $this->assertTrue( $r['execution_success'] );
	}
	public function test_unactivated_credential_keeps_actionable_code(): void {
		Options::set( Settings::AUTH_READY, false );
		$this->assertSame( 'f3_google_auth_not_active', Gate::check( 'ga' )['error_code'] );
	}
	/** @dataProvider wildcards */
	public function test_writes_refuse_wildcards_before_discovery_or_callback( array $input ): void {
		$calls = 0;
		Ability::register( 'ga/test-next-write', 'ga', array( 'mode' => 'write', 'callback' => static function() use ( &$calls ) { ++$calls; return Response::ok(); } ) );
		$result = wp_get_ability( 'ga/test-next-write' )->execute( $input );
		$this->assertSame( 'f3_google_write_wildcard', $result['error_code'] );
		$this->assertSame( 'not_applied', $result['operation_outcome'] );
		$this->assertSame( 0, $calls ); $this->assertSame( 0, FakeHttp::count() );
	}
	public static function wildcards(): array { return array( array( array( 'property_id' => '*' ) ), array( array( 'property_id' => '*', 'dry_run' => true ) ), array( array( 'path_params' => array( 'parent' => 'properties/*' ) ) ), array( array( 'body' => array( 'requests' => array( array( 'resourceName' => 'properties/*' ) ) ) ) ) ); }
	public function test_wildcard_in_text_or_field_mask_is_not_a_resource_selector(): void { $this->assertFalse( Operation::wildcard( array( 'body' => array( 'text' => '*', 'updateMask' => '*' ) ) ) ); }
	public function test_unknown_discovery_method_is_not_auto_authorized(): void { $this->assertSame( 'f3_google_operation_unclassified', Operation::method( 'search-console', 'new.method' )->get_error_code() ); }
	public function test_read_profile_accepts_generic_get_without_snapshot(): void {
		Options::set( Connections::SERVICES, array( 'gsc' => 'read' ) ); $this->token();
		FakeHttp::push( '/webmasters/v3/sites', 200, array( 'siteEntry' => array() ) );
		$result = wp_get_ability( 'google/execute-action' )->execute( array( 'api' => 'search-console', 'method' => 'webmasters.sites.list' ) );
		$this->assertTrue( $result['success'], $result['message'] ); $this->assertSame( 'not_applicable', $result['operation_outcome'] );
		$this->assertCount( 2, FakeHttp::$requests ); $this->assertSame( 'read', Audit::recent( 1 )[0]['extra']['mode'] );
		$this->assertArrayNotHasKey( 'before', Audit::recent( 1 )[0]['extra'] );
	}
	public function test_read_profile_accepts_inspection_post(): void {
		Options::set( Connections::SERVICES, array( 'gsc' => 'read' ) ); $this->token();
		FakeHttp::push( 'index:inspect', 200, array( 'inspectionResult' => array() ) );
		$r = wp_get_ability( 'google/execute-read' )->execute( array( 'api' => 'search-console', 'method' => 'searchconsole.urlInspection.index.inspect', 'body' => array( 'siteUrl' => 'https://example.test/', 'inspectionUrl' => 'https://example.test/page' ) ) );
		$this->assertTrue( $r['success'], $r['message'] ); $this->assertSame( 'POST', FakeHttp::last()['method'] );
	}
	public function test_read_route_rejects_post_mutation_without_network(): void {
		$r = wp_get_ability( 'google/execute-read' )->execute( array( 'api' => 'sheets', 'method' => 'sheets.spreadsheets.create', 'body' => array() ) );
		$this->assertSame( 'f3_google_read_required', $r['error_code'] ); $this->assertSame( 0, FakeHttp::count() );
	}
	public function test_internal_mode_override_cannot_turn_mutation_into_read(): void {
		Options::set( Connections::SERVICES, array( 'sheets' => 'read' ) );
		$r = ExecuteAction::call( 'sheets', 'sheets.spreadsheets.create', array(), array(), array(), array( 'mode' => 'read' ) );
		$this->assertTrue( is_wp_error( $r ) ); $this->assertSame( 'f3_google_service_read_only', $r->get_error_code() ); $this->assertSame( 0, FakeHttp::count() );
	}
	public function test_bad_json_after_write_is_unknown_and_never_retryable(): void {
		FakeHttp::push( '/test', 200, '{"truncated":' );
		$error = GoogleClient::request( 'POST', GoogleClient::HOST_SHEETS . '/test', array(), array( 'auth' => false, 'mode' => 'write' ) );
		$r = Operation::result( Response::fail( $error ), 'write' );
		$this->assertSame( 'unknown', $r['operation_outcome'] ); $this->assertFalse( $r['retryable'] ); $this->assertSame( 'reconcile_target', $r['recovery']['action'] ); $this->assertCount( 1, FakeHttp::$requests );
	}
	/** @dataProvider outcomes */
	public function test_legacy_outcomes_are_normalized( array $input, string $expected ): void { $this->assertSame( $expected, Operation::result( $input, 'write' )['operation_outcome'] ); }
	public static function outcomes(): array { return array( array( array( 'details' => array( 'outcome' => 'unknown' ) ), 'unknown' ), array( array( 'uncertain' => true ), 'unknown' ), array( array( 'outcome_uncertain' => true ), 'unknown' ), array( array( 'operation_outcome' => 'applied', 'uncertain' => true ), 'unknown' ), array( array( 'success' => false, 'partial_failure' => true ), 'partial' ), array( array( 'success' => true ), 'applied' ) ); }
	public function test_simulation_alias_conflict_and_false_preservation(): void {
		$this->assertSame( array( 'dry_run' => false ), Operation::normalize( array( 'simular' => false ) ) );
		$this->assertTrue( is_wp_error( Operation::normalize( array( 'simular' => true, 'dry_run' => false ) ) ) );
	}
	public function test_dimension_reader_follows_pages_and_keeps_unicode(): void {
		$this->token(); FakeHttp::push( 'customDimensions', 200, array( 'customDimensions' => array( array( 'parameterName' => 'method', 'displayName' => 'Método' ) ), 'nextPageToken' => 'page2' ) );
		FakeHttp::push( 'customDimensions', 200, array( 'customDimensions' => array( array( 'parameterName' => 'custom', 'displayName' => 'Personalização' ) ) ) );
		$r = wp_get_ability( 'ga/list-custom-dimensions' )->execute( array( 'property_id' => '123' ) );
		$this->assertTrue( $r['success'], $r['message'] ); $this->assertTrue( $r['complete'] ); $this->assertSame( 2, $r['count'] ); $this->assertSame( 'Método', $r['dimensions'][0]['displayName'] );
		$this->assertStringContainsString( 'pageToken=page2', FakeHttp::last()['url'] );
	}
	public function test_repeated_page_token_never_reports_complete(): void {
		$this->token(); for ( $i = 0; $i < 2; ++$i ) { FakeHttp::push( 'customDimensions', 200, array( 'customDimensions' => array(), 'nextPageToken' => 'same' ) ); }
		$r = wp_get_ability( 'ga/list-custom-dimensions' )->execute( array( 'property_id' => '123' ) );
		$this->assertFalse( $r['success'] ); $this->assertFalse( $r['complete'] ); $this->assertSame( 'f3_google_pagination', $r['error_code'] );
	}
	public function test_audit_cleanup_and_short_read_have_bounded_payload_cost(): void {
		$loads = 0; $hooks = array();
		for ( $i = 0; $i < 1000; ++$i ) {
			$id = sprintf( '%020d', $i ); Records::insert( 'audit', $id, array( 'id' => $id, 'time' => '2026-09-29 00:00:00' ) );
			$hook = 'pre_option_' . Records::key( 'audit', $id ); $cb = static function( $value ) use ( &$loads ) { ++$loads; return $value; }; add_filter( $hook, $cb ); $hooks[] = array( $hook, $cb );
		}
		try {
			Audit::log( 'test-next' ); $this->assertLessThanOrEqual( 2, $loads ); $loads = 0;
			$entries = Audit::recent( 30 ); $this->assertCount( 30, $entries ); $this->assertLessThanOrEqual( 30, $loads );
			$this->assertCount( 1000, Records::ids( 'audit', 1100 ) );
		} finally { foreach ( $hooks as [ $hook, $cb ] ) { remove_filter( $hook, $cb ); } }
	}
	public function test_public_hook_registration_does_not_read_job_payload(): void {
		$loads = 0; $key = Records::key( 'job', 'public-test' ); $GLOBALS['f3_test_options'][ $key ] = array( 'results' => array_fill( 0, 500, str_repeat( 'x', 1000 ) ) );
		$cb = static function( $value ) use ( &$loads ) { ++$loads; return $value; }; add_filter( 'pre_option_' . $key, $cb );
		try { \Fator3\McpGoogle\Automation\Jobs::init(); $this->assertSame( 0, $loads ); } finally { remove_filter( 'pre_option_' . $key, $cb ); }
	}
}
