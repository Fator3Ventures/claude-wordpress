<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Analytics\Profile, Connections, CoreBinding, Options, Plugin, Settings, Setup};
use Fator3\McpGoogle\Generic\Discovery;
use PHPUnit\Framework\TestCase;
final class GenericProfileTest extends TestCase {
 protected function setUp(): void {
  $GLOBALS['f3_test_options']=array(); $GLOBALS['f3_test_transients']=array(); $GLOBALS['f3_test_write_fail']=array(); $GLOBALS['f3_test_caps']=true; FakeHttp::reset();
  Options::batch_verified(array(Options::ENABLED=>true,Options::GA_ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'test.apps.googleusercontent.com'),array(Options::OAUTH_CLIENT_SECRET=>'synthetic-secret',Options::OAUTH_REFRESH_TOKEN=>'synthetic-refresh'));
  foreach(array('v1alpha','v1beta') as $version) { set_transient(Discovery::cache_key('analytics-admin-'.$version), json_decode(file_get_contents(__DIR__.'/fixtures/discovery/analyticsadmin-'.$version.'.json'),true),600); }
  FakeHttp::push('oauth2.googleapis.com/token',200,array('access_token'=>'synthetic-token','expires_in'=>3600)); Plugin::register_abilities();
 }
 private function reads(array $dimensions=array(),array $retention=array(), bool $stream=false): void {
  FakeHttp::push('/v1beta/properties/123',200,array('name'=>'properties/123'));
  FakeHttp::push('dataStreams',200,array('dataStreams'=>array(array('name'=>'properties/123/dataStreams/456','webStreamData'=>array('measurementId'=>'G-ABC')))));
  if($retention) { FakeHttp::push('dataRetentionSettings',200,$retention); }
  if($stream) { FakeHttp::push('enhancedMeasurementSettings',200,array('streamEnabled'=>false)); }
  FakeHttp::push('customDimensions',200,array('customDimensions'=>$dimensions));
 }
 private function definition(): array { return array('parameterName'=>'method','scope'=>'EVENT','displayName'=>'Método'); }
 public function test_profile_rejects_unknown_sections_fields_and_duplicates(): void {
  foreach(array(array('agency_standard'=>true),array('retention'=>array('name'=>'x')),array('custom_dimensions'=>array($this->definition(),$this->definition())),array('custom_dimensions'=>array(array('parameterName'=>'bad name','scope'=>'EVENT','displayName'=>'X'))),array('schema_version'=>'2.0.0')) as $profile) { $this->assertTrue(is_wp_error(Profile::validate($profile))); }
  $this->assertCount(0,FakeHttp::$requests);
 }
 public function test_accent_correction_updates_existing_and_preserves_extras(): void {
  $this->reads(array(array('name'=>'properties/123/customDimensions/9','parameterName'=>'method','scope'=>'EVENT','displayName'=>'Metodo'),array('name'=>'properties/123/customDimensions/10','parameterName'=>'extra','scope'=>'EVENT','displayName'=>'Extra')),array(),true);
  $r=Profile::plan(array('property_id'=>'123','stream_id'=>'456','profile'=>array('custom_dimensions'=>array($this->definition()))));
  $this->assertTrue($r['success'],$r['message']); $this->assertCount(1,$r['changes']); $this->assertSame('update',$r['changes'][0]['action']); $this->assertSame(array('displayName'=>'Método'),$r['changes'][0]['body']); $this->assertSame(false,$r['streamEnabled']); $this->assertSame('properties/123/customDimensions/9',$r['changes'][0]['path_params']['name']);
 }
 public function test_default_simulation_never_creates_missing_dimensions(): void {
  $this->reads(); $r=Profile::apply(array('property_id'=>'123','profile'=>array('custom_dimensions'=>array($this->definition()))));
  $this->assertTrue($r['success'],$r['message']); $this->assertSame('create',$r['changes'][0]['action']);
  $requests=array_filter(FakeHttp::$requests,static fn($x)=>false===strpos($x['url'],'/token')); foreach($requests as $request) {$this->assertSame('GET',$request['method']);}
 }
 public function test_retention_is_first_and_reduction_is_sensitive(): void {
  $this->reads(array(),array('eventDataRetention'=>'FOURTEEN_MONTHS'));
  $r=Profile::plan(array('property_id'=>'123','profile'=>array('custom_dimensions'=>array($this->definition()),'retention'=>array('eventDataRetention'=>'TWO_MONTHS'))));
  $this->assertTrue($r['success'],$r['message']); $this->assertSame('retention',$r['changes'][0]['section']); $this->assertTrue($r['changes'][0]['sensitive']);
 }
 public function test_stale_plan_is_refused_before_remote_mutation(): void {
  $this->reads(); $r=Profile::apply(array('property_id'=>'123','profile'=>array('custom_dimensions'=>array($this->definition())),'dry_run'=>false,'expected_plan_hash'=>'outdated'));
  $this->assertSame('f3_google_profile_changed',$r['error_code']); $this->assertSame('not_applied',$r['operation_outcome']);
 }
 public function test_access_bindings_403_is_auth_capability_not_profile_failure(): void {
  $this->reads(); FakeHttp::push('oauth2.googleapis.com/token',200,array('access_token'=>'user-management-token','expires_in'=>3600)); FakeHttp::push('accessBindings',403,array('error'=>array('message'=>'permission denied','code'=>403)));
  $r=Profile::plan(array('property_id'=>'123','profile'=>array('custom_dimensions'=>array()),'check_access_bindings'=>true));
  $this->assertTrue($r['success'],$r['message']); $this->assertSame('permission_denied',$r['auth']['access_bindings']['status']); $this->assertSame(403,$r['auth']['access_bindings']['http_status']); $this->assertFalse($r['auth']['role_verified']); $this->assertNull($r['auth']['role']); $this->assertTrue($r['auth']['configured']);
 }
 public function test_profiles_are_local_revisioned_and_connection_scoped(): void {
  $input=array('profile_id'=>'example','profile'=>array('custom_dimensions'=>array($this->definition()))); $r=Profile::save($input); $this->assertTrue($r['success']);
  $this->assertFalse(Profile::save($input)['success']); $this->assertTrue(Profile::save($input+array('expected_revision'=>$r['revision']))['success']); $this->assertCount(0,FakeHttp::$requests);
 }
 public function test_core_gtm_stops_before_discovery(): void { update_option('f3base_ga4_measurement_id','G-ABC');update_option('f3base_gtm_container_id','GTM-ABC');$r=CoreBinding::resolve();$this->assertSame('f3_google_core_gtm_active',$r->get_error_code());$this->assertCount(0,FakeHttp::$requests); }
 public function test_core_is_opt_in_and_binds_unique_paginated_match(): void {
  update_option('f3base_ga4_measurement_id','G-ABC'); $r=Setup::plan(array());$this->assertTrue($r['success']);$this->assertCount(0,FakeHttp::$requests);
  FakeHttp::push('accountSummaries',200,array('accountSummaries'=>array(array('propertySummaries'=>array(array('property'=>'properties/123'))))));
  FakeHttp::push('dataStreams',200,array('dataStreams'=>array(),'nextPageToken'=>'two'));
  FakeHttp::push('dataStreams',200,array('dataStreams'=>array(array('name'=>'properties/123/dataStreams/456','webStreamData'=>array('measurementId'=>'G-ABC')))));
  $r=Setup::apply(array('vincular_site_core'=>true,'validate_access'=>false));$this->assertTrue($r['success'],$r['message']);$this->assertSame('123',Options::get(Options::GA_DEFAULT_PROPERTY));$this->assertSame('properties/123/dataStreams/456',Options::get(Connections::BINDINGS)['ga_stream_id']);
 }
 public function test_core_duplicate_match_does_not_write(): void {
  update_option('f3base_ga4_measurement_id','G-ABC');FakeHttp::push('accountSummaries',200,array('accountSummaries'=>array(array('propertySummaries'=>array(array('property'=>'properties/123'))))));
  FakeHttp::push('dataStreams',200,array('dataStreams'=>array(array('name'=>'properties/123/dataStreams/456','webStreamData'=>array('measurementId'=>'G-ABC')),array('name'=>'properties/123/dataStreams/789','webStreamData'=>array('measurementId'=>'G-ABC')))));
  $r=Setup::apply(array('vincular_site_core'=>true,'validate_access'=>false));$this->assertSame('f3_google_core_ambiguous',$r['error_code']);$this->assertNull(Options::get(Options::GA_DEFAULT_PROPERTY));
 }
 public function test_apply_accent_change_reads_back_and_second_application_writes_nothing(): void {
  $old=array('name'=>'properties/123/customDimensions/9','parameterName'=>'method','scope'=>'EVENT','displayName'=>'Metodo');$wanted=$old;$wanted['displayName']='Método';
  $input=array('property_id'=>'123','profile'=>array('custom_dimensions'=>array($this->definition())));
  $this->reads(array($old));$plan=Profile::plan($input);$this->assertTrue($plan['success']);
  $this->reads(array($old));FakeHttp::push('/token',200,array('access_token'=>'synthetic-edit-token','expires_in'=>3600));FakeHttp::push('/customDimensions/9',200,$wanted,array(),'PATCH');FakeHttp::push('/customDimensions/9',200,$wanted,array(),'GET');
  $applied=Profile::apply($input+array('dry_run'=>false,'expected_plan_hash'=>$plan['plan_hash']));$this->assertTrue($applied['success'],json_encode($applied));
  $this->reads(array($wanted));$again=Profile::apply($input+array('dry_run'=>false));$this->assertTrue($again['success']);$this->assertTrue($again['conformant']);$this->assertSame('already',$again['checks'][0]['status']);
  $writes=array_filter(FakeHttp::$requests,static fn($r)=>in_array($r['method'],array('PATCH','PUT','DELETE'),true));$this->assertCount(1,$writes);
 }
 public function test_failed_required_read_does_not_claim_conformity_or_write(): void {
  FakeHttp::push('/v1beta/properties/123',200,array('name'=>'properties/123'));
  FakeHttp::push('dataStreams',200,array('dataStreams'=>array()));
  FakeHttp::push('dataRetentionSettings',403,array('error'=>array('code'=>403,'message'=>'denied')));
  $r=Profile::plan(array('property_id'=>'123','profile'=>array('retention'=>array('eventDataRetention'=>'FOURTEEN_MONTHS'))));
  $this->assertTrue($r['success']);$this->assertFalse($r['complete']);$this->assertNull($r['conformant']);$this->assertSame('not_verified',$r['checks'][0]['status']);
 }
 public function test_invalid_metric_and_display_name_are_rejected_without_network(): void {
  $r=Profile::validate(array('custom_metrics'=>array(array('scope'=>'EVENT','parameterName'=>'amount','displayName'=>'Amount','measurementUnit'=>'CURRENCY'))));$this->assertTrue(is_wp_error($r));
  $r=Profile::validate(array('custom_dimensions'=>array(array('scope'=>'EVENT','parameterName'=>'method','displayName'=>'1 Invalid'))));$this->assertTrue(is_wp_error($r));$this->assertCount(0,FakeHttp::$requests);
 }

}
