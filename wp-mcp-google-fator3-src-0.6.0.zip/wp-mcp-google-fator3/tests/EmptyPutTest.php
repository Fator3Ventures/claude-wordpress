<?php
/** Regressões de enquadramento HTTP para PUT sem corpo. */
declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Http\GoogleClient;
use PHPUnit\Framework\TestCase;

final class EmptyPutTest extends TestCase {
	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = $GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps'] = true;
		FakeHttp::reset();
	}

	/** @dataProvider empty_puts */
	public function test_empty_put_declares_zero_length( string $method, ?array $body, array $options ): void {
		FakeHttp::push( '/empty-put-test', 204, '' );
		$result = GoogleClient::request( $method, GoogleClient::HOST_GSC . '/empty-put-test', $body, $options + array( 'auth' => false, 'mode' => 'write' ) );
		$this->assertSame( array(), $result );
		$request = FakeHttp::last();
		$this->assertSame( 'PUT', $request['method'] );
		$this->assertSame( '', $request['body'] );
		$this->assertSame( '0', $request['headers']['Content-Length'] ?? null );
		$this->assertCount( 1, FakeHttp::$requests );
	}

	public static function empty_puts(): array {
		return array(
			'absent body' => array( 'PUT', null, array() ),
			'lowercase method' => array( 'put', null, array() ),
			'empty raw body' => array( 'PUT', null, array( 'raw_body' => '', 'content_type' => 'text/plain' ) ),
			'empty form' => array( 'PUT', array(), array( 'form' => true ) ),
		);
	}

	/** @dataProvider requests_with_payload */
	public function test_payload_is_preserved_without_zero_length( string $method, ?array $body, array $options, $expected ): void {
		FakeHttp::push( '/payload-test', 200, array() );
		$invoke = static fn() => GoogleClient::request( $method, GoogleClient::HOST_GSC . '/payload-test', $body, $options + array( 'auth' => false, 'mode' => 'write' ) );
		if ( 'DELETE' === $method ) {
			\Fator3\McpGoogle\Options::set( \Fator3\McpGoogle\Options::ENABLED, true );
			// Exercise the actual framing through a registered, confirmed write, not a gate bypass.
			\Fator3\McpGoogle\Ability::register( 'gsc/framing-delete', 'any', array( 'mode' => 'write', 'callback' => static fn() => \Fator3\McpGoogle\Response::ok( $invoke() ) ) );
			$p = \Fator3\McpGoogle\Confirmation::prepare( array( 'ability' => 'gsc/framing-delete', 'parameters' => array() ) );
			$this->assertTrue( $p['success'], json_encode( $p ) );
			$result = wp_get_ability( 'gsc/framing-delete' )->execute( array( 'confirmation_token' => $p['confirmation_token'] ) );
			$this->assertTrue( $result['success'], json_encode( $result ) );
		} else { $invoke(); }
		$request = FakeHttp::last();
		$this->assertSame( $expected, $request['body'] );
		$this->assertArrayNotHasKey( 'Content-Length', $request['headers'] );
	}

	public static function requests_with_payload(): array {
		return array(
			'empty JSON object' => array( 'PUT', array(), array(), '{}' ),
			'JSON payload' => array( 'PUT', array( 'name' => 'sitemap' ), array(), '{"name":"sitemap"}' ),
			'raw zero byte as text' => array( 'PUT', null, array( 'raw_body' => '0', 'content_type' => 'text/plain' ), '0' ),
			'raw payload' => array( 'PUT', null, array( 'raw_body' => 'abc', 'content_type' => 'text/plain' ), 'abc' ),
			'form payload' => array( 'PUT', array( 'x' => '1' ), array( 'form' => true ), array( 'x' => '1' ) ),
			'GET without body' => array( 'GET', null, array(), null ),
			'DELETE without body' => array( 'DELETE', null, array(), null ),
			'POST JSON' => array( 'POST', array( 'x' => 1 ), array(), '{"x":1}' ),
			'PATCH JSON' => array( 'PATCH', array( 'x' => 1 ), array(), '{"x":1}' ),
		);
	}
}
