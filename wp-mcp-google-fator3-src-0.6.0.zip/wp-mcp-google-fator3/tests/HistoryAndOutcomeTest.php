<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Automation\Operations, Connections, Operation, Records, Storage\DateFilter};
use PHPUnit\Framework\TestCase;
final class HistoryAndOutcomeTest extends TestCase {
 protected function setUp():void {
  $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=array();
  $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;
  Connections::select('default');FakeHttp::reset();
 }
 public function test_history_day_boundaries_and_connection_are_exact():void {
  $start=strtotime('2026-09-24T00:00:00Z');
  foreach(array('before'=>array($start-1,'default','query'),'first'=>array($start,'default','query'),'last'=>array($start+86399,'default','query'),'after'=>array($start+86400,'default','query'),'foreign'=>array($start,'other','query'),'other_task'=>array($start,'default','report')) as $id=>$v){
   Records::put('job',$id,array('id'=>$id,'created_at'=>$v[0],'connection_id'=>$v[1],'task'=>$v[2],'status'=>'completed','updated_at'=>$v[0],'run_after'=>$v[0]));
  }
  $page=Operations::listing(array('from'=>'2026-09-24','to'=>'2026-09-24','task'=>'query','limit'=>1));
  $this->assertTrue($page['success']);$this->assertCount(1,$page['jobs']);$this->assertSame(1,$page['next_offset']);
  $next=Operations::listing(array('from'=>'2026-09-24','to'=>'2026-09-24','task'=>'query','limit'=>1,'offset'=>1));
  $ids=array_merge(array_column($page['jobs'],'id'),array_column($next['jobs'],'id'));sort($ids);
  $this->assertSame(array('first','last'),$ids);$this->assertNull($next['next_offset']);$this->assertSame(0,FakeHttp::count());
 }
 public function test_dates_reject_rollover_missing_zone_and_reversed_ranges():void {
  foreach(array(array('from'=>'2026-02-30'),array('from'=>'2026-09-24T12:00:00'),array('from'=>'2026-09-25','to'=>'2026-09-24')) as $input){
   $this->assertInstanceOf(\WP_Error::class,DateFilter::parse($input));
   $this->assertSame('f3_google_job_dates',Operations::listing($input)['error_code']);
  }
  $time=DateFilter::parse(array('from'=>'2026-09-24T03:00:00+03:00','to'=>'2026-09-24T00:00:00Z'));
  $this->assertSame(strtotime('2026-09-24T00:00:00Z')-1,$time['created_after']);
 }
 public function test_only_conclusive_operation_specific_rejections_are_not_applied():void {
  $sheets='https://sheets.googleapis.com/v4/spreadsheets/sheet:batchUpdate';
  $body=array('error'=>array('code'=>400,'status'=>'INVALID_ARGUMENT'));
  $opts=array('mode'=>'write','operation_id'=>'sheets.spreadsheets.batchUpdate');
  $this->assertSame('not_applied',Operation::http_failure('POST',$sheets,400,$body,$opts));
  foreach(array(array('PUT',$sheets,400,$body,$opts),array('POST',str_replace('sheets.googleapis.com','example.test',$sheets),400,$body,$opts),array('POST',$sheets,403,$body,$opts),array('POST',$sheets,400,array(),$opts),array('POST',$sheets,400,$body,array('mode'=>'write','operation_id'=>'sheets.spreadsheets.create'))) as $case){$this->assertSame('unknown',Operation::http_failure(...$case));}
  $drive='https://www.googleapis.com/drive/v3/files/file/permissions';$denied=array('error'=>array('code'=>403,'errors'=>array(array('reason'=>'insufficientFilePermissions'))));$permission=array('mode'=>'write','operation_id'=>'drive.permissions.create');
  $this->assertSame('not_applied',Operation::http_failure('POST',$drive,403,$denied,$permission));
  $denied['error']['errors'][]=array('reason'=>'unknown');
  $this->assertSame('unknown',Operation::http_failure('POST',$drive,403,$denied,$permission));
  $this->assertSame('not_applicable',Operation::http_failure('GET',$drive,403,$denied,array('mode'=>'read')));
 }
 public function test_job_admission_and_executor_success_are_not_remote_write_success():void {
  $worker=\Fator3\McpGoogle\Automation\Worker::class;
  $this->assertSame('not_applicable',$worker::outcome(array('write'=>false,'status'=>'completed')));
  $this->assertSame('not_applied',$worker::outcome(array('write'=>true,'status'=>'pending')));
  $this->assertSame('unknown',$worker::outcome(array('write'=>true,'status'=>'unknown')));
  $this->assertSame('partial',$worker::outcome(array('write'=>true,'status'=>'unknown','result'=>array('success'=>false,'operation_outcome'=>'partial'))));
  $this->assertSame('not_applicable',Operation::aggregate(array('not_applicable')));
  $this->assertSame('partial',Operation::aggregate(array('applied','not_applied','not_applicable')));
  $this->assertSame('unknown',Operation::aggregate(array('applied','unknown')));
 }

 public function test_redaction_does_not_count_as_authentication_cache_usage():void {
  $credentials=\Fator3\McpGoogle\Auth\Credentials::class;
  $credentials::remember($credentials::CACHE_PREFIX.'redaction-fixture','synthetic-access-token',300);
  $before=\Fator3\McpGoogle\Telemetry::state()['counters']['cache_hits']??0;
  $clean=\Fator3\McpGoogle\Audit::redact(array('message'=>'synthetic-access-token','details'=>array('value'=>'synthetic-access-token')));
  $this->assertSame('[token redigido]',$clean['message']);
  $this->assertSame($before,\Fator3\McpGoogle\Telemetry::state()['counters']['cache_hits']??0);
  $credentials::cached($credentials::CACHE_PREFIX.'redaction-fixture');
  $this->assertSame($before+1,\Fator3\McpGoogle\Telemetry::state()['counters']['cache_hits']);
 }

}
