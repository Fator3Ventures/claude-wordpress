<?php
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\Admin;
if(($argv[1]??'')==='child'){
 $mode=$argv[3]??'valid';wp_set_current_user($mode==='anonymous'?0:1);$script=$argv[2]==='script';$action=$script?'f3_mcp_google_script':'f3_mcp_google_documentation';
 $_GET=['document'=>$argv[2],'_wpnonce'=>$mode==='bad_nonce'?'invalid':wp_create_nonce($action)];$_REQUEST=$_GET;$_POST=[];
 if($script)Admin::handle_script();else Admin::handle_documentation();exit(99);
}
$checks=[];function verify($name,$ok){global $checks;$checks[$name]=(bool)$ok;if(!$ok)throw new RuntimeException($name);}
function download($file,$mode='valid'){$p=proc_open([getenv('F3_TEST_PHP')?:PHP_BINARY,__FILE__,'child',$file,$mode],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);return ['exit'=>proc_close($p),'body'=>$out,'stderr'=>$err];}
$documents=require __DIR__.'/../wp-mcp-google-fator3/includes/Data/Documentation.php';
foreach(Admin::documents() as $name=>$label){$r=download($name);verify('authenticated_exact_'.$name,$r['exit']===0&&$r['body']===$documents[$name]);}
$guide='GUIA-'.F3_MCP_GOOGLE_VERSION.'.md';foreach(['anonymous','bad_nonce'] as $mode){$r=download($guide,$mode);verify($mode.'_does_not_disclose_document',!str_contains($r['body'],'# Guia')&&$r['body']!==$documents[$guide]);}
$script=download('script');verify('cloud_shell_exact_and_updated',$script['body']===rtrim(file_get_contents(__DIR__.'/../wp-mcp-google-fator3/reference/googlecloudscript.txt'))&&str_contains($script['body'],'tagmanager.googleapis.com'));
echo json_encode(['wordpress'=>get_bloginfo('version'),'version'=>F3_MCP_GOOGLE_VERSION,'checks'=>$checks],JSON_PRETTY_PRINT)."\n";
