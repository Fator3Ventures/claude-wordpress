<?php
/** Real subprocess races and crash recovery; all Google HTTP is intercepted. */
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';
require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Options,Records,Settings,Generic\Discovery,Storage\Repository,Automation\Jobs,Automation\Worker};
wp_set_current_user(1);
add_filter('home_url',static fn()=>'https://example.test/');
$dir=__DIR__.'/../evidence/process-race';if(!is_dir($dir)){mkdir($dir,0700,true);}
$mode=$argv[3]??'normal';$log=$dir.'/http.jsonl';
add_filter('f3_mcp_google_public_dns',static fn()=>array(array('ip'=>'93.184.216.34')));
add_filter('f3_mcp_google_public_response',static fn()=>array('success'=>true,'status'=>200,'body'=>'<?xml version="1.0"?><sitemapindex></sitemapindex>'));
add_filter('pre_http_request',static function($pre,$args,$url)use($mode,$log){
 $status=200;
 if(str_contains($url,'oauth2.googleapis.com/token')){if('fence'===$mode){file_put_contents(dirname($log).'/fence-wait','waiting');$until=microtime(true)+10;while(!is_file(dirname($log).'/fence-release')&&microtime(true)<$until){usleep(10000);}}$data=array('access_token'=>'synthetic-race-token','expires_in'=>3600);}
 elseif(str_contains($url,'index:inspect')){file_put_contents($log,json_encode(array('pid'=>getmypid(),'method'=>'inspection'))."\n",FILE_APPEND|LOCK_EX);if('crash-read'===$mode){exit(86);}usleep(250000);$data=array('inspectionResult'=>array('indexStatusResult'=>array('verdict'=>'PASS')));}
 elseif(str_contains($url,'/sitemaps/')){if('PUT'===$args['method']){file_put_contents($log,json_encode(array('pid'=>getmypid(),'method'=>'PUT','content_length'=>$args['headers']['Content-Length']??null))."\n",FILE_APPEND|LOCK_EX);if('crash-write'===$mode){exit(87);}$status=204;$data=array();}elseif('DELETE'===$args['method']){file_put_contents($log,json_encode(array('pid'=>getmypid(),'method'=>'DELETE'))."\n",FILE_APPEND|LOCK_EX);if('crash-confirm'===$mode){exit(89);}usleep(250000);$status=204;$data=array();}elseif(str_contains($url,'confirm.xml')){$data=array('path'=>'https://example.test/confirm.xml');}else{$status=404;$data=array('error'=>array('message'=>'missing'));}}
 else{throw new RuntimeException('Unexpected network: '.$url);}
 return array('response'=>array('code'=>$status),'headers'=>array(),'body'=>json_encode($data));
},10,3);
if(in_array($argv[1]??'',array('worker','confirm'),true)){
 $deadline=microtime(true)+10;while(!is_file($argv[4])&&microtime(true)<$deadline){usleep(10000);}if(!is_file($argv[4])){exit(88);}
 $result='confirm'===$argv[1]?wp_get_ability('google/execute-action')->execute(json_decode(file_get_contents($argv[2]),true)):Worker::run($argv[2],1);echo json_encode($result)."\n";exit(!empty($result['success'])?0:1);
}
$checks=array();function verify(string $label,bool $ok):void{global $checks;$checks[$label]=$ok;if(!$ok){throw new RuntimeException($label);}}
function launch(string $job,string $mode,string $barrier,string $action='worker'):array{
 $pipes=array();$proc=proc_open(array(getenv('F3_TEST_PHP')?:PHP_BINARY,__FILE__,$action,$job,$mode,$barrier),array(0=>array('pipe','r'),1=>array('pipe','w'),2=>array('pipe','w')),$pipes);fclose($pipes[0]);return array($proc,$pipes);
}
function finish(array $handle):array{[$proc,$pipes]=$handle;$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);return array('exit'=>proc_close($proc),'output'=>$out,'stderr'=>$err);}
function count_calls(string $method):int{global $log;$lines=is_file($log)?file($log,FILE_IGNORE_NEW_LINES):array();return count(array_filter($lines,static fn($line)=>(json_decode($line,true)['method']??'')===$method));}
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'f3_mcp_google_lock_%'");wp_cache_flush();Repository::install();Options::set('f3_mcp_google_storage',array('phase'=>'indexed'));$wpdb->query("DELETE FROM ".Repository::table()." WHERE kind IN ('job','schedule','dedupe','quota')");
Options::batch_verified(array(Options::ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'race.apps.googleusercontent.com',Settings::AUTH_READY=>true,\Fator3\McpGoogle\Policy::OPTION=>array('mode'=>'identity'),\Fator3\McpGoogle\Connections::SERVICES=>array('gsc'=>'write')),array(Options::OAUTH_CLIENT_SECRET=>'synthetic',Options::OAUTH_REFRESH_TOKEN=>'synthetic'));
$doc=json_decode(file_get_contents(__DIR__.'/../wp-mcp-google-fator3/tests/fixtures/discovery/searchconsole-v1.json'),true);set_transient(Discovery::cache_key('search-console'),$doc,600);
file_put_contents($log,'');$barrier=$dir.'/start';@unlink($barrier);
$input=array('task'=>'inspect-urls','parameters'=>array('site_url'=>'https://race.test/','urls'=>array('https://race.test/'.bin2hex(random_bytes(4)))));$job=Jobs::create($input);verify('race_admitted',$job['success']);
$a=launch($job['job_id'],'normal',$barrier);$b=launch($job['job_id'],'normal',$barrier);file_put_contents($barrier,'go');$one=finish($a);$two=finish($b);
file_put_contents($dir.'/workers.json',json_encode(array($one,$two)));
verify('both_workers_returned',0===$one['exit']&&0===$two['exit']);$stored=Records::get('job',$job['job_id']);verify('one_http_and_one_result',1===count_calls('inspection')&&'completed'===$stored['status']&&1===$stored['result_count']);
$input['parameters']['urls']=array('https://race.test/crash-'.bin2hex(random_bytes(4)));$job=Jobs::create($input);$crashed=finish(launch($job['job_id'],'crash-read',$barrier));verify('read_crash_observed',86===$crashed['exit']&&'running'===Records::get('job',$job['job_id'])['status']);
$wpdb->query($wpdb->prepare('UPDATE '.Repository::table().' SET lease_until=%d WHERE kind=%s AND record_id=%s',time()-1,'job',$job['job_id']));$resumed=finish(launch($job['job_id'],'normal',$barrier));verify('read_crash_retry_commits_once',0===$resumed['exit']&&1===Records::get('job',$job['job_id'])['result_count']&&3===count_calls('inspection'));
$job=Jobs::create(array('task'=>'sitemap','parameters'=>array('site_url'=>'https://example.test/','sitemap_url'=>'https://example.test/wp-sitemap.xml')));verify('write_admitted',$job['success']);
$crashed=finish(launch($job['job_id'],'crash-write',$barrier));file_put_contents($dir.'/write-crash-result.json',json_encode(array($crashed,Records::get('job',$job['job_id']))));verify('write_crash_after_dispatch',87===$crashed['exit']&&'dispatching'===Records::get('job',$job['job_id'])['status']&&1===count_calls('PUT'));
$wpdb->query($wpdb->prepare('UPDATE '.Repository::table().' SET lease_until=%d WHERE kind=%s AND record_id=%s',time()-1,'job',$job['job_id']));$resumed=finish(launch($job['job_id'],'normal',$barrier));verify('uncertain_write_never_replayed',0===$resumed['exit']&&'unknown'===Records::get('job',$job['job_id'])['status']&&1===count_calls('PUT'));
// Suspend the old process during token acquisition, replace its lease, then resume it.
\Fator3\McpGoogle\Auth\Credentials::invalidate_cache();@unlink($dir.'/fence-wait');@unlink($dir.'/fence-release');
$input['parameters']['urls']=array('https://race.test/fence-'.bin2hex(random_bytes(4)));$job=Jobs::create($input);$before=count_calls('inspection');$old=launch($job['job_id'],'fence',$barrier);
$until=microtime(true)+10;while(!is_file($dir.'/fence-wait')&&microtime(true)<$until){usleep(10000);}verify('old_worker_suspended_before_api',is_file($dir.'/fence-wait'));
$wpdb->query($wpdb->prepare('UPDATE '.Repository::table().' SET lease_until=%d WHERE kind=%s AND record_id=%s',time()-1,'job',$job['job_id']));$new=finish(launch($job['job_id'],'normal',$barrier));file_put_contents($dir.'/fence-release','resume');$old=finish($old);
file_put_contents($dir.'/fence-results.json',json_encode(array($new,$old)));
verify('old_worker_refused_after_lease_replacement',0===$new['exit']&&0===count_calls('inspection')-$before&&0===Records::get('job',$job['job_id'])['result_count']);
$pending=Records::get('job',$job['job_id']);$pending['run_after']=time()-1;Records::put('job',$job['job_id'],$pending);$resumed=finish(launch($job['job_id'],'normal',$barrier));verify('new_owner_can_resume_after_token_lock_released',0===$resumed['exit']&&1===count_calls('inspection')-$before&&1===Records::get('job',$job['job_id'])['result_count']);
$params=array('api'=>'search-console','method'=>'webmasters.sitemaps.delete','path_params'=>array('siteUrl'=>'https://example.test/','feedpath'=>'https://example.test/confirm.xml'));
$prepared=\Fator3\McpGoogle\Confirmation::prepare(array('ability'=>'google/execute-action','parameters'=>$params));verify('confirmation_prepared',$prepared['success']);$input_file=$dir.'/confirmation-input.json';file_put_contents($input_file,json_encode($params+array('confirmation_token'=>$prepared['confirmation_token'])));chmod($input_file,0600);
@unlink($barrier);$a=launch($input_file,'normal',$barrier,'confirm');$b=launch($input_file,'normal',$barrier,'confirm');file_put_contents($barrier,'go');$a=finish($a);$b=finish($b);
verify('concurrent_confirmation_one_remote_write',1===count_calls('DELETE')&&($a['exit']===0||$b['exit']===0)&&($a['exit']!==0||$b['exit']!==0));
$replay=finish(launch($input_file,'normal',$barrier,'confirm'));verify('finished_confirmation_replay_refused',1===$replay['exit']&&1===count_calls('DELETE'));
$prepared=\Fator3\McpGoogle\Confirmation::prepare(array('ability'=>'google/execute-action','parameters'=>$params));file_put_contents($input_file,json_encode($params+array('confirmation_token'=>$prepared['confirmation_token'])));$crash=finish(launch($input_file,'crash-confirm',$barrier,'confirm'));$id=hash('sha256',$prepared['confirmation_token']);verify('confirmation_crash_persists_consumed_intent',89===$crash['exit']&&'consumed'===Records::get('confirmation',$id)['status']);
// Expire only the abandoned local lock; the consumed confirmation remains durable.
$key='f3_mcp_google_lock_'.hash('sha256','confirmation:'.$id);$lock=get_option($key);$lock['expires']=time()-1;update_option($key,$lock,false);
$replay=finish(launch($input_file,'normal',$barrier,'confirm'));verify('crashed_confirmation_never_replayed',1===$replay['exit']&&2===count_calls('DELETE'));unlink($input_file);
echo json_encode(array('checks'=>$checks,'processes'=>14,'google_http'=>'simulated','external_mail'=>false),JSON_PRETTY_PRINT)."\n";
