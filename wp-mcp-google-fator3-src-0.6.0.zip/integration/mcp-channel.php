<?php
declare(strict_types=1);
$root=dirname(__DIR__);$mu=$root.'/mysql-wordpress/wp-content/mu-plugins/f3-integration-loader.php';if(!is_dir(dirname($mu))){mkdir(dirname($mu),0700,true);}
$channel=getenv('F3_MCP_CHANNEL')?:dirname($root).'/critique-sources/wp-mcp-fator3-fonte-0.12.1/fontes/wp-mcp-fator3/wp-mcp-fator3.php';
file_put_contents($mu,"<?php\nrequire ".var_export($root.'/wp-mcp-google-fator3/wp-mcp-google-fator3.php',true).";\nrequire ".var_export($channel,true).";\n");
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';
try{require $root.'/mysql-wordpress/wp-load.php';}finally{unlink($mu);}
use Fator3\McpGoogle\{Options,Connections};
wp_set_current_user(1);Options::set(Options::ENABLED,true);rest_get_server();
$server=\WpMcpUltimate\Server\McpAdapter::instance()->get_server('wp-mcp-ultimate-server');if(!$server){throw new RuntimeException('MCP server absent');}
$handler=new \WpMcpUltimate\Server\Handlers\Tools\ToolsHandler($server);$catalog=$handler->list_tools();
file_put_contents($root.'/evidence/mcp-tools.json',json_encode($catalog,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
$checks=array();function verify(string $name,bool $ok):void{global $checks;$checks[$name]=$ok;if(!$ok){throw new RuntimeException($name);}}
$tools=array_column($catalog['tools'],null,'name');$read=null;$write=null;
foreach($tools as $name=>$entry){if(str_contains($name,'google')&&str_ends_with($name,'mcp-read')){$read=$name;}if(str_contains($name,'google')&&str_ends_with($name,'mcp-write')){$write=$name;}}
verify('separate_google_tools_registered',null!==$read&&null!==$write);
verify('read_annotation_true',true===($tools[$read]['annotations']['readOnlyHint']??null));verify('write_annotation_false',false===($tools[$write]['annotations']['readOnlyHint']??null));
$called=$handler->call_tool(array('params'=>array('name'=>$read,'arguments'=>array('ability'=>'google/status'))),1);file_put_contents($root.'/evidence/mcp-status.json',json_encode($called,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
verify('status_through_real_channel',!empty($called['structuredContent']['success']));
$denied=$handler->call_tool(array('params'=>array('name'=>$read,'arguments'=>array('ability'=>'gsc/submit-sitemap','parameters'=>array('site_url'=>'https://example.test/','sitemap_url'=>'https://example.test/sitemap.xml')))),2);
verify('mutation_refused_by_read_tool',true===($denied['isError']??false)&&'f3_google_mcp_mode'===($denied['structuredContent']['error_code']??''));
Options::set(Options::ENABLED,false);$closed=$handler->call_tool(array('params'=>array('name'=>$read,'arguments'=>array('ability'=>'google/status'))),3);verify('closed_channel_external_error',true===($closed['isError']??false));Options::set(Options::ENABLED,true);
$routes=rest_get_server()->get_routes();verify('canonical_and_legacy_routes',isset($routes['/mcp/wp-mcp-fator3'])&&isset($routes['/mcp/wp-mcp-ultimate']));
$abilities=array_filter(wp_get_abilities(),static fn($a)=>'google'===$a->get_category());$versions=array_unique(array_map(static fn($a)=>$a->get_meta()['fator3']['version']??null,$abilities));verify('all_google_metadata_versions',array_values($versions)===array(F3_MCP_GOOGLE_VERSION));
echo json_encode(array('channel_version'=>F3_MCP_FILES_VERSION,'google_abilities'=>count($abilities),'checks'=>$checks),JSON_PRETTY_PRINT)."\n";
