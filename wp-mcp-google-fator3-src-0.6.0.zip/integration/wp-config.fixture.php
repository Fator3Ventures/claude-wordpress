<?php
define('WP_DEFAULT_THEME','f3-fixture');
 define('DB_NAME','f3_google_next');define('DB_USER','root');define('DB_PASSWORD','');
 define('DB_HOST','127.0.0.1:33071');
 define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');$table_prefix='wp_';
 define('WP_DEBUG',true);define('WP_DEBUG_DISPLAY',false);define('WP_DEBUG_LOG',true);
 define('WP_HOME','http://127.0.0.1:38041');define('WP_SITEURL','http://127.0.0.1:38041');
 define('DISABLE_WP_CRON',true);define('WP_AUTO_UPDATE_CORE',false);define('AUTOMATIC_UPDATER_DISABLED',true);
 define('AUTH_KEY','disposable-google-test-auth');define('SECURE_AUTH_KEY','disposable-google-test-secure');
 define('LOGGED_IN_KEY','disposable-google-test-login');define('NONCE_KEY','disposable-google-test-nonce');
 define('AUTH_SALT','disposable-google-salt-auth');define('SECURE_AUTH_SALT','disposable-google-salt-secure');
 define('LOGGED_IN_SALT','disposable-google-salt-login');define('NONCE_SALT','disposable-google-salt-nonce');
 if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';
