<?php
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';
require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Audit, Options, Records, Storage\Migration, Storage\Repository, Storage\AuditReader};
wp_set_current_user(1);$wpdb->query('DROP TABLE IF EXISTS '.Repository::table());$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'f3_mcp_google_%' OR option_name LIKE '_transient_f3_mcp_google_%' OR option_name LIKE '_transient_timeout_f3_mcp_google_%'");wp_cache_flush();
$checks=array();function verify(string $name,bool $ok): void {global $checks;$checks[$name]=$ok;if(!$ok){throw new RuntimeException($name);}}
for($i=0;$i<240;++$i){Records::insert('audit',sprintf('%020d',$i),array('id'=>sprintf('%020d',$i),'action'=>'test','time'=>gmdate('Y-m-d H:i:s'),'created_at'=>time(),'extra'=>array('mode'=>'read','status'=>'ok'),'large'=>str_repeat('x',4096)));}
Records::insert('job','legacy-read',array('id'=>'legacy-read','task'=>'report','status'=>'pending','write'=>false,'result'=>array('rows'=>array_map(static fn($i)=>array($i,str_repeat('x',200)),range(0,249))),'created_at'=>1));Records::insert('job','legacy-write',array('id'=>'legacy-write','status'=>'running','write'=>true));
$r=Migration::begin();verify('migration_pauses_and_copies_batch',$r['success']&&Migration::paused());
verify('origin_frozen',!Records::insert('audit','during-migration',array('x'=>1)));
for($i=0;$i<20&&!Migration::active();++$i){$r=Migration::step(37);if(!$r['success']){throw new RuntimeException(json_encode($r));}}
verify('migration_switched_after_verification',Migration::active());verify('counts_verified',242===(int)$r['verified']);
verify('legacy_source_preserved',242===(int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE 'f3_mcp_google_record_%'"));
verify('legacy_read_blocked','blocked'===Records::get('job','legacy-read')['status']);verify('legacy_inflight_write_unknown','unknown'===Records::get('job','legacy-write')['status']);
$old=Records::get('job','legacy-read');verify('legacy_report_rows_externalized',!isset($old['result']['rows'])&&250===$old['result_pages']['rows']['count']);verify('report_page_crosses_chunk_boundary',range(95,104)===array_column(\Fator3\McpGoogle\Automation\Results::rows($old,'rows',95,10),0));
$metadata=Repository::select('audit',array(),30);verify('metadata_page_no_payload',30===count($metadata)&&!isset($metadata[0]['payload']));
$lease=Repository::claim('job','legacy-read',60);verify('lease_acquired',null!==$lease);verify('second_worker_excluded',null===Repository::claim('job','legacy-read',60));
$wpdb->query($wpdb->prepare('UPDATE '.Repository::table().' SET lease_until=%d WHERE kind=%s AND record_id=%s',time()-1,'job','legacy-read'));
$new=Repository::claim('job','legacy-read',60);verify('expired_worker_replaced',null!==$new&&$new['owner']!==$lease['owner']);
$stale=Repository::put('job','legacy-read',array('status'=>'dispatching'),(int)$lease['row']['generation'],$lease['owner']);verify('stale_worker_fenced',!$stale['success']);
$job=Records::get('job','legacy-read');$job['status']='dispatching';$saved=Repository::put('job','legacy-read',$job,(int)$new['row']['generation'],$new['owner']);verify('owner_dispatch_cas',$saved['success']);Repository::release('job','legacy-read',$new['owner']);
Options::set(Options::AUDIT_RETENTION,1000);$page=AuditReader::page(array('limit'=>25,'desde_revisao'=>'0'));verify('audit_cursor_window',$page['success']&&25===$page['count']&&null!==$page['next_cursor']);
Audit::log('new-after-window');$next=AuditReader::page(array('cursor'=>$page['next_cursor'],'limit'=>25));verify('stable_window',$next['window_end_revision']===$page['window_end_revision']&&$next['entries'][0]['revision']>$page['last_revision']);
verify('cursor_tamper_refused',!AuditReader::page(array('cursor'=>$page['next_cursor'].'a'))['success']);
Audit::log('=HYPERLINK(1)','@target');$csv=AuditReader::export(array('format'=>'csv','desde_revisao'=>$next['window_end_revision']));$text=base64_decode($csv['content_base64']);verify('csv_formula_neutralized',str_contains($text,"'=HYPERLINK")&&str_contains($text,"'@target"));
$lease=Repository::claim('job','legacy-read',60);verify('same_second_lease_renewal',Repository::renew('job','legacy-read',$lease['owner'],60));Repository::release('job','legacy-read',$lease['owner']);
Options::batch_verified(array(Options::ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::GA_ENABLED=>true,Options::OAUTH_CLIENT_ID=>'synthetic.apps.googleusercontent.com',\Fator3\McpGoogle\Settings::AUTH_READY=>true),array(Options::OAUTH_CLIENT_SECRET=>'synthetic-secret',Options::OAUTH_REFRESH_TOKEN=>'synthetic-refresh'));
$discovery=json_decode(file_get_contents(__DIR__.'/../wp-mcp-google-fator3/tests/fixtures/discovery/searchconsole-v1.json'),true);set_transient(\Fator3\McpGoogle\Generic\Discovery::cache_key('search-console'),$discovery,600);
$requests=array();add_filter('pre_http_request',static function($pre,$args,$url) use(&$requests){$requests[]=array($args['method'],$url,$args['body']??null);if(str_contains($url,'oauth2.googleapis.com/token')){$data=array('access_token'=>'synthetic-token','expires_in'=>3600);}elseif(str_contains($url,'index:inspect')){usleep(200000);$data=array('inspectionResult'=>array('indexStatusResult'=>array('verdict'=>'PASS')));}elseif(str_contains($url,'sheets.googleapis.com/')){if(str_contains($url,':batchUpdate')){$data=array('replies'=>array(array(),array()));}elseif(str_contains($url,'/values/')){$data=array('values'=>array());}else{$data=array('spreadsheetId'=>'sheet-existing','sheets'=>array(array('properties'=>array('sheetId'=>0,'title'=>'Sheet1'))));}}else{throw new RuntimeException('Unexpected network request: '.$url);}return array('response'=>array('code'=>200),'headers'=>array(),'body'=>json_encode($data));},10,3);
$urls=array();for($i=0;$i<500;++$i){$urls[]='https://example.test/page-'.$i;}
$created=\Fator3\McpGoogle\Automation\Jobs::create(array('task'=>'inspect-urls','parameters'=>array('site_url'=>'https://example.test/','urls'=>$urls),'idempotency_key'=>'performance-500'));verify('worker_admission',$created['success']);
$before=microtime(true);$worked=\Fator3\McpGoogle\Automation\Worker::run($created['job_id']);$elapsed=microtime(true)-$before;
verify('worker_20_to_25_items_first_pass',$worked['success']&&$worked['job']['cursor']>=20&&$worked['job']['cursor']<=25&&$worked['job']['summary']['passed']>=20);
verify('worker_stays_within_deadline',$elapsed<20);
$stored=Records::get('job',$created['job_id']);verify('job_does_not_embed_results',empty($stored['results'])&&25===$stored['result_count']);
verify('result_page_only_requested_items',5===count(\Fator3\McpGoogle\Automation\Results::page($created['job_id'],10,5)));
$lease=Repository::claim('job',$created['job_id'],60);$row=Repository::row('job',$created['job_id'],false);$next=$stored;$next['cursor']=26;$next['result_count']=26;
$wpdb->query($wpdb->prepare('UPDATE '.Repository::table().' SET lease_until=%d WHERE kind=%s AND record_id=%s',time()-1,'job',$created['job_id']));
$commit=Repository::commit_item($created['job_id'],$lease['owner'],(int)$row['generation'],$next,25,array('url'=>'late','result'=>array('success'=>true)));
verify('expired_worker_cannot_store_result',!$commit['success']&&null===Repository::get('item',\Fator3\McpGoogle\Automation\Results::id($created['job_id'],25)));
verify('failed_item_commit_preserves_cursor',25===Records::get('job',$created['job_id'])['cursor']);Repository::release('job',$created['job_id'],$lease['owner']);
$quota=\Fator3\McpGoogle\Automation\Worker::run($created['job_id']);file_put_contents(__DIR__.'/../evidence/quota-debug.json',json_encode($quota));verify('minute_quota_stops_next_http',$quota['success']&&25===$quota['job']['cursor']&&'backoff'===$quota['reason']);

$sheetdoc=json_decode(file_get_contents(__DIR__.'/../wp-mcp-google-fator3/tests/fixtures/discovery/sheets-v4.json'),true);set_transient(\Fator3\McpGoogle\Generic\Discovery::cache_key('sheets'),$sheetdoc,600);
$window=AuditReader::page(array('action'=>'=HYPERLINK(1)','limit'=>100));verify('audit_export_cursor_present',!empty($window['export_cursor'])&&1===$window['count']);
$params=array('cursor'=>$window['export_cursor'],'spreadsheet_id'=>'sheet-existing');
$pre=\Fator3\McpGoogle\Confirmation::prepare(array('ability'=>'google/audit-to-sheet','parameters'=>$params));verify('audit_sheets_prepared',$pre['success']);
$mutations=static function() use (&$requests){return array_values(array_filter($requests,static fn($r)=>str_contains($r[1],':batchUpdate')));};
verify('audit_preparation_no_write',0===count($mutations()));
Audit::log('=HYPERLINK(1)','new-outside-window');
$exported=wp_get_ability('google/audit-to-sheet')->execute($params+array('confirmation_token'=>$pre['confirmation_token']));verify('audit_sheets_confirmed',$exported['success']);
verify('audit_sheets_stable_coverage',1===$exported['audit_entries_exported']&&$window['window_end_revision']===$exported['audit_window']['window_end_revision']&&$exported['audit_window']['complete']);
$writes=$mutations();$body=json_decode($writes[0][2],true);
verify('audit_sheets_literal_cells',1===count($writes)&&'=HYPERLINK(1)'===$body['requests'][1]['updateCells']['rows'][1]['values'][3]['userEnteredValue']['stringValue']&&!str_contains($writes[0][2],'formulaValue'));
$cursor=$window['export_cursor'];wp_set_current_user(0);verify('audit_cursor_actor_bound',!AuditReader::page(array('cursor'=>$cursor))['success']);wp_set_current_user(1);

$job=array('id'=>'report-commit','task'=>'report','status'=>'running','connection_id'=>'default','created_at'=>time(),'updated_at'=>time(),'result'=>array('rows'=>array_map(static fn($i)=>array($i),range(0,249))));
Records::insert('job',$job['id'],array_diff_key($job,array('result'=>true)));$lease=Repository::claim('job',$job['id'],60);$job['status']='completed';$chunks=\Fator3\McpGoogle\Automation\Results::externalize($job);
$bad=Repository::commit_result($job['id'],'wrong-owner',(int)$lease['row']['generation'],$job,$chunks);verify('table_result_fenced_before_chunks',!$bad['success']&&0===Repository::count_filtered('result',array('task'=>$job['id'])));
$good=Repository::commit_result($job['id'],$lease['owner'],(int)$lease['row']['generation'],$job,$chunks);verify('table_result_atomic_commit',$good['success']&&3===Repository::count_filtered('result',array('task'=>$job['id']))&&!isset(Records::get('job',$job['id'])['result']['rows']));Repository::release('job',$job['id'],$lease['owner']);
$cleanup_job=array('id'=>'cleanup-150','task'=>'inspect-urls','status'=>'completed','connection_id'=>'default','user_id'=>1,'result_count'=>150,'expires_at'=>time()-1,'created_at'=>time()-40*86400,'updated_at'=>time()-31*86400);Records::insert('job',$cleanup_job['id'],$cleanup_job);
for($i=0;$i<150;++$i){\Fator3\McpGoogle\Automation\Results::put($cleanup_job['id'],$i,array('url'=>'https://example.test/'.$i,'result'=>array('success'=>true)));}
Records::insert('dedupe',$cleanup_job['id'],array('expires_at'=>time()+86400));Records::insert('dedupe',$created['job_id'],array('expires_at'=>time()-1));
$clean=\Fator3\McpGoogle\Automation\Executor::cleanup(array('dry_run'=>false));verify('cleanup_bound_100',$clean['success']&&100===$clean['removed_records']&&null!==Records::get('job',$cleanup_job['id'])&&50===Repository::count_filtered('item',array('task'=>$cleanup_job['id'])));
$clean=\Fator3\McpGoogle\Automation\Executor::cleanup(array('dry_run'=>false));verify('cleanup_resumes_without_losing_reservation',$clean['success']&&null===Records::get('job',$cleanup_job['id'])&&null!==Records::get('summary',$cleanup_job['id'])&&null!==Records::get('dedupe',$cleanup_job['id']));
verify('cleanup_preserves_active_and_unknown',null!==Records::get('dedupe',$created['job_id'])&&'unknown'===Records::get('job','legacy-write')['status']);
Options::set(\Fator3\McpGoogle\Automation\Alerts::OPTION,array('enabled'=>true,'email_enabled'=>true,'recipients'=>array('synthetic@example.test'),'events'=>array('access'),'minimum_interval'=>60));
for($i=0;$i<120;++$i){Records::insert('incident','other-'.$i,array('connection_id'=>'other','task'=>'notify_pending','email_state'=>'pending','run_after'=>time()-1));}
$mail_count=0;add_filter('pre_wp_mail',static function($result)use(&$mail_count){++$mail_count;return true;});
\Fator3\McpGoogle\Automation\Alerts::observe('access','resource-one',true,'denied','Conferir permissão.');\Fator3\McpGoogle\Automation\Alerts::dispatch();\Fator3\McpGoogle\Automation\Alerts::dispatch();
verify('alerts_connection_isolation_and_deduplication',1===$mail_count&&'accepted'===\Fator3\McpGoogle\Automation\Alerts::state()['incidents'][0]['email_state']);
\Fator3\McpGoogle\Automation\Alerts::observe('access','resource-two',true,'denied','Conferir permissão.');$incident_id=hash('sha256','default|access|resource-two');Records::insert('mail',$incident_id.'_1',array('status'=>'dispatching'));\Fator3\McpGoogle\Automation\Alerts::dispatch();
verify('crashed_email_is_unknown_without_replay',1===$mail_count&&'unknown'===Records::get('incident',$incident_id)['email_state']);
\Fator3\McpGoogle\Automation\Alerts::observe('access','resource-one',false,'recovered','Conferir permissão.');\Fator3\McpGoogle\Automation\Alerts::dispatch();verify('recovery_obeys_notification_interval',1===$mail_count);
echo json_encode(array('wordpress'=>get_bloginfo('version'),'mysql'=>$wpdb->get_var('SELECT VERSION()'),'checks'=>$checks,'worker_seconds'=>$elapsed,'peak_memory_bytes'=>memory_get_peak_usage(true)),JSON_PRETTY_PRINT)."\n";
