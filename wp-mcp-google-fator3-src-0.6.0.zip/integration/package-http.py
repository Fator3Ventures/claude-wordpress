"""Disposable Apache/PHP verification, including autoindex enabled and upgrade replacement."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,socket,subprocess,tempfile,time,urllib.request,urllib.error,zipfile
p=argparse.ArgumentParser();p.add_argument('--apache',required=True);p.add_argument('--modules',required=True);p.add_argument('--library-path',required=True);p.add_argument('--zip',required=True);p.add_argument('--old-zip',required=True);p.add_argument('--output',required=True);a=p.parse_args()
results=[]
with tempfile.TemporaryDirectory(prefix='f3-google-package-') as tmp:
 d=Path(tmp);d.chmod(0o755);www=d/'www';www.mkdir(mode=0o755)
 with zipfile.ZipFile(a.zip) as z: z.extractall(www)
 for x in www.rglob('*'):x.chmod(0o755 if x.is_dir() else 0o644)
 sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
 modules=Path(a.modules)
 config=[f'ServerRoot "{d}"',f'PidFile "{d}/apache.pid"',f'Listen 127.0.0.1:{port}','ServerName localhost','User www-data','Group www-data',f'ErrorLog "{d}/error.log"']
 for name in ['mpm_prefork','authz_core','dir','autoindex','mime']: config.append(f'LoadModule {name}_module "{modules}/mod_{name}.so"')
 config += [f'LoadModule php_module "{modules}/libphp8.3.so"',f'TypesConfig /etc/mime.types',f'DocumentRoot "{www}"',f'<Directory "{www}">','Require all granted','Options Indexes FollowSymLinks','AllowOverride None','DirectoryIndex index.php','</Directory>','<FilesMatch "\\.php$">','SetHandler application/x-httpd-php','</FilesMatch>']
 (d/'httpd.conf').write_text('\n'.join(config)+'\n')
 env=os.environ.copy();env['LD_LIBRARY_PATH']=a.library_path
 proc=subprocess.Popen([a.apache,'-f',str(d/'httpd.conf'),'-DFOREGROUND'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:
  base=f'http://127.0.0.1:{port}'
  def get(path):
   try:
    with urllib.request.urlopen(base+path,timeout=3) as r:return r.status,r.read(),r.url
   except urllib.error.HTTPError as e:return e.code,e.read(),e.url
  for i in range(80):
   if proc.poll() is not None:raise RuntimeError(proc.communicate()[1].decode()+(d/'error.log').read_text())
   try:get('/');break
   except urllib.error.URLError:time.sleep(.05)
  for stage in ['clean','replacement']:
   if stage=='replacement':
    shutil.rmtree(www/'wp-mcp-google-fator3')
    with zipfile.ZipFile(a.old_zip) as z:z.extractall(www)
    assert (www/'wp-mcp-google-fator3/docs').exists()
    shutil.rmtree(www/'wp-mcp-google-fator3')
    with zipfile.ZipFile(a.zip) as z:z.extractall(www)
    for x in www.rglob('*'):x.chmod(0o755 if x.is_dir() else 0o644)
   root=www/'wp-mcp-google-fator3'
   for directory in [root]+[x for x in root.rglob('*') if x.is_dir()]:
    path='/'+directory.relative_to(www).as_posix()
    for suffix in ['','/']:
     status,body,url=get(path+suffix);assert status==200 and body==b'',(stage,path,status,body[:200]);results.append({'stage':stage,'path':path+suffix,'status':status,'bytes':len(body),'final_url':url})
   for path in ['README.md','CHANGELOG.md','CONTRACTS.md','THIRD-PARTY-NOTICES.md','docs/','reference/','reference/googlecloudscript.txt','docs/GUIA-0.4.0.md']:
    status,body,url=get('/wp-mcp-google-fator3/'+path);assert status==404,(path,status);results.append({'stage':stage,'path':path,'status':status})
   for path in ['includes/Data/CloudScript.php','includes/Data/Operations.php','includes/Data/Documentation.php','includes/Data/TagManager.php']:
    status,body,url=get('/wp-mcp-google-fator3/'+path);assert status==200 and body==b'';results.append({'stage':stage,'path':path,'status':status,'bytes':len(body)})
   for path in ['LICENSE.txt','THIRD-PARTY-NOTICES.txt','assets/admin.css','assets/admin.js']:
    status,body,url=get('/wp-mcp-google-fator3/'+path);assert status==200 and body==(root/path).read_bytes();results.append({'stage':stage,'path':path,'status':status,'bytes':len(body)})
 finally:
  proc.terminate()
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
Path(a.output).write_text(json.dumps({'passed':True,'environment':'local Apache 2.4/PHP 8.3, mod_autoindex enabled, AllowOverride None','upgrade_test':'directory replacement model; not a real WordPress Plugin_Upgrader invocation','checks':len(results),'results':results},indent=2)+'\n')
print(json.dumps({'passed':True,'checks':len(results)}))
