<?php
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Options,Audit,Records,Storage\Admission,Storage\Migration};
wp_set_current_user(1);Options::batch_verified([Options::ENABLED=>true,Options::GA_ENABLED=>true,Fator3\McpGoogle\Connections::SERVICES=>['ga'=>'admin'],Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'synthetic'],[Options::OAUTH_CLIENT_SECRET=>'synthetic',Options::OAUTH_REFRESH_TOKEN=>'synthetic']);
$dir=__DIR__.'/../evidence/migration-race';if(!is_dir($dir))mkdir($dir,0700,true);
if(($argv[1]??'')==='child'){Admission::run('google/probe',static function()use($dir){file_put_contents($dir.'/entered','1');$end=microtime(true)+10;while(!is_file($dir.'/release')&&microtime(true)<$end)usleep(10000);Audit::log('migration-race-admitted');if(Audit::last_failure())throw new RuntimeException('admitted audit failed');});exit(0);}
$checks=[];function verify($n,$v){global $checks;$checks[$n]=(bool)$v;if(!$v)throw new RuntimeException($n);}
Options::delete(Migration::OPTION);foreach(['entered','release'] as $f)@unlink($dir.'/'.$f);
$p=proc_open([getenv('F3_TEST_PHP')?:PHP_BINARY,__FILE__,'child'],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$end=microtime(true)+10;while(!is_file($dir.'/entered')&&microtime(true)<$end)usleep(10000);verify('child_admitted',is_file($dir.'/entered'));
$r=Migration::begin();verify('migration_waits_for_admitted_call',Migration::state()['phase']==='drain');
$http=0;add_filter('pre_http_request',static function()use(&$http){++$http;return new WP_Error('network_forbidden');});
$r=wp_get_ability('ga/conformidade')->execute(['property_id'=>'123']);verify('new_call_refused_before_remote',is_array($r)&&($r['error_code']??'')==='f3_google_storage_migrating'&&$r['retry_after_ms']===15000&&$http===0);
file_put_contents($dir.'/release','1');$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);verify('admitted_call_audited_before_swap',proc_close($p)===0);
for($n=0;$n<20&&!Migration::active();$n++)Migration::step(100);
verify('migration_completed',Migration::active());verify('audit_health_not_failed',Audit::health()['state']==='no_failure_observed');
$events=Records::list('audit',100);verify('admitted_event_migrated',count(array_filter($events,static fn($e)=>$e['action']==='migration-race-admitted'))===1);
Options::set('f3_mcp_google_audit_health_default',['state'=>'failed','at'=>Migration::state()['started_at'],'phase'=>'append']);delete_transient('f3_mcp_google_audit_health_default');Audit::log('post-migration');$h=Audit::health();verify('prior_gap_recovered_with_cause',$h['state']==='recovered'&&$h['cause']==='storage_migration'&&$h['historical_gap']===true);
echo json_encode(['database'=>$wpdb->get_var('SELECT VERSION()'),'checks'=>$checks],JSON_PRETTY_PRINT)."\n";
