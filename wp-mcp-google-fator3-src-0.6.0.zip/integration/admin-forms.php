<?php
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/wp-admin/tools.php';require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Admin,Admin\OperationsScreen,Options,Policy,Settings,Crypto,Connections};
wp_set_current_user(1);Options::set(Options::ENABLED,true);$checks=array();$http=0;
add_filter('pre_http_request',static function()use(&$http){++$http;return new WP_Error('fixture_network_forbidden','No external network');});
function verify(string $name,bool $ok):void{global $checks;$checks[$name]=$ok;if(!$ok){throw new RuntimeException($name);}}
class FixtureRedirect extends RuntimeException{}class FixtureDie extends RuntimeException{}
add_filter('wp_redirect',static function($url){throw new FixtureRedirect($url);});add_filter('wp_die_handler',static fn()=>static function($message){throw new FixtureDie(is_string($message)?$message:'wp_die');});
function submit(array $fields,bool $nonce=true):array{
 $_POST=$fields+array('action'=>'f3_google_operation','connection_id'=>'default','section'=>'operations','_wpnonce'=>$nonce?wp_create_nonce('f3_google_operation'):'invalid');$_REQUEST=$_POST;
 try{OperationsScreen::handle();}catch(FixtureRedirect $e){}catch(FixtureDie $e){return array('wp_die'=>true);}
 $cipher=get_transient(Admin::feedback_key('operation'));$text=Crypto::decrypt($cipher);return json_decode($text,true);
}
function render(string $section,string $method='service_account'):string{$_POST=array();$_GET=array('page'=>Admin::SLUG,'section'=>$section,'method'=>$method,'connection_id'=>'default');ob_start();Admin::render();return (string)ob_get_clean();}
$revision=Settings::revision();$sa=render('connection');$oauth=render('connection','oauth');file_put_contents(__DIR__.'/../evidence/admin-connection.html',$sa);file_put_contents(__DIR__.'/../evidence/admin-oauth.html',$oauth);verify('exclusive_auth_forms',str_contains($sa,'name="sa_json"')&&!str_contains($sa,'name="oauth_client_secret"')&&str_contains($oauth,'name="oauth_client_secret"')&&!str_contains($oauth,'name="sa_json"'));verify('tab_switch_does_not_change_configuration',$revision===Settings::revision());
foreach(array('operations','profiles','controls','advanced') as $section){
 $html=render($section);file_put_contents(__DIR__.'/../evidence/admin-'.$section.'.html',$html);$doc=new DOMDocument();libxml_use_internal_errors(true);$doc->loadHTML('<?xml encoding="utf-8" ?>'.$html);libxml_clear_errors();$xpath=new DOMXPath($doc);$ids=array();$duplicate=false;foreach($xpath->query('//*[@id]') as $node){$id=$node->getAttribute('id');if(isset($ids[$id])){$duplicate=true;}$ids[$id]=true;}verify($section.'_unique_ids',!$duplicate);
 $forms=$xpath->query('//form[@method="post"]');$nonces=true;foreach($forms as $form){if(0===$xpath->query('.//input[@name="_wpnonce"]',$form)->length){$nonces=false;}}verify($section.'_nonce_on_all_actions',$forms->length>0&&$nonces);
 verify($section.'_json_collapsed',0===$xpath->query('//pre[not(ancestor::details)]')->length);
 $targets=true;foreach($xpath->query('//*[@data-copy-target]') as $button){if(!isset($ids[$button->getAttribute('data-copy-target')])){$targets=false;}}verify($section.'_copy_targets_exist',$targets);
}
$before=Policy::current();$plan=submit(array('operation'=>'save-policy','policy_mode'=>'restricted','ga_resources'=>'properties/123456'));verify('policy_form_prepares_without_saving',!empty($plan['apply_policy'])&&$before===Policy::current());
$saved=submit(array('operation'=>'apply-policy','reference'=>$plan['reference']));verify('policy_form_applies_reviewed_intent',!empty($saved['result']['success'])&&'restricted'===Policy::current()['mode']);
$plan=submit(array('operation'=>'save-policy','policy_mode'=>'identity'));Options::set(Options::HTTP_TIMEOUT,31);$stale=submit(array('operation'=>'apply-policy','reference'=>$plan['reference']));verify('stale_policy_form_refused',empty($stale['result']['success'])&&'restricted'===Policy::current()['mode']);
$before=Settings::revision();$bad=submit(array('operation'=>'save-policy','policy_mode'=>'identity'),false);verify('invalid_nonce_stops_change',!empty($bad['wp_die'])&&$before===Settings::revision());
$agenda=submit(array('operation'=>'save-schedule','task'=>'preflight','parameters_json'=>'{}','interval_seconds'=>'3600','schedule_enabled'=>'1'));verify('schedule_created_from_panel',!empty($agenda['result']['success']));$schedule=$agenda['result']['schedule'];
$paused=submit(array('operation'=>'save-schedule','schedule_id'=>$schedule['id'],'schedule_revision'=>$schedule['revision'],'task'=>'preflight','parameters_json'=>'{}','interval_seconds'=>'3600'));verify('schedule_paused_from_panel',!empty($paused['result']['success'])&&false===$paused['result']['schedule']['enabled']);
$stale=submit(array('operation'=>'save-schedule','schedule_id'=>$schedule['id'],'schedule_revision'=>$schedule['revision'],'task'=>'preflight','parameters_json'=>'{}','interval_seconds'=>'3600','schedule_enabled'=>'1'));verify('stale_schedule_form_refused','f3_google_schedule_conflict'===($stale['result']['error_code']??''));
Options::set(Options::ENABLED,false);$local=submit(array('operation'=>'save-local','expected_revision'=>Settings::revision(),'audit_local_reads'=>'1'));verify('local_controls_work_with_channel_closed',!empty($local['result']['success']));
wp_set_current_user(0);$before=Settings::revision();$bad=submit(array('operation'=>'save-local','audit_local_reads'=>'0'));verify('anonymous_action_denied',!empty($bad['wp_die'])&&$before===Settings::revision());wp_set_current_user(1);
verify('configuration_flows_no_google_calls',0===$http);echo json_encode(array('wordpress'=>get_bloginfo('version'),'checks'=>$checks,'browser_keyboard_test'=>false),JSON_PRETTY_PRINT)."\n";
