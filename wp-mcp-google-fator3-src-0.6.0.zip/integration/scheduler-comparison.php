<?php
/** Bounded experiment; no production tables or real Google tasks are used. */
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';
wp_set_current_user(1);$checks=array();$http=0;
add_filter('pre_http_request',static function()use(&$http){++$http;return new WP_Error('fixture_network_forbidden','No network');});
add_filter('action_scheduler_allow_async_request_runner',static fn()=>false);
function verify(string $label,bool $ok):void{global $checks;$checks[$label]=$ok;if(!$ok){throw new RuntimeException($label);}}
$start=microtime(true);$memory=memory_get_usage(true);$queries=$wpdb->num_queries;
update_option('action_scheduler_migration_status','complete');
require getenv('F3_ACTION_SCHEDULER')?:__DIR__.'/../tools/action-scheduler-comparison/vendor/woocommerce/action-scheduler/action-scheduler.php';
$store=ActionScheduler::store();$group='f3-comparison-'.bin2hex(random_bytes(4));
$load=array('seconds'=>microtime(true)-$start,'queries'=>$wpdb->num_queries-$queries,'memory_bytes'=>memory_get_usage(true)-$memory);
$ids=array();$start=microtime(true);$queries=$wpdb->num_queries;
for($i=0;$i<50;++$i){$ids[]=as_schedule_single_action(time()-1,'f3_comparison_read',array('item'=>$i),$group);}
verify('as_50_actions_persisted',50===count(array_filter($ids)));
$admission=array('seconds'=>microtime(true)-$start,'queries'=>$wpdb->num_queries-$queries);
$first=$store->stake_claim(10,new DateTime('now',new DateTimeZone('UTC')),array('f3_comparison_read'),$group);
$second=$store->stake_claim(10,new DateTime('now',new DateTimeZone('UTC')),array('f3_comparison_read'),$group);
verify('as_claims_do_not_overlap',10===count($first->get_actions())&&10===count($second->get_actions())&&!array_intersect($first->get_actions(),$second->get_actions()));
$first_ids=$first->get_actions();$store->release_claim($first);$resumed=$store->stake_claim(10,new DateTime('now',new DateTimeZone('UTC')),array('f3_comparison_read'),$group);
verify('as_released_claim_can_resume',10===count(array_intersect($first_ids,$resumed->get_actions())));
$sample=$resumed->get_actions()[0];$store->log_execution($sample);verify('as_execution_running','in-progress'===$store->get_status($sample));$store->mark_complete($sample);verify('as_completion_recorded','complete'===$store->get_status($sample));
$statuses=array_keys($store->get_status_labels());verify('as_custom_recovery_requires_plugin_state',!in_array('blocked',$statuses,true)&&!in_array('unknown',$statuses,true));
$store->release_claim($second);$store->release_claim($resumed);
$other=as_schedule_single_action(time()+3600,'f3_foreign_fixture',array(),'foreign-comparison');foreach($ids as $id){$store->delete_action($id);}verify('as_group_cleanup_preserves_other_consumer','pending'===$store->get_status($other));$store->delete_action($other);
require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\Storage\Repository;
verify('indexed_repository_available',true===Repository::install());
$start=microtime(true);$queries=$wpdb->num_queries;$memory=memory_get_usage(true);
for($i=0;$i<50;++$i){verify('indexed_admission_'.$i,Repository::insert('job',$group.'_'.$i,array('task'=>'query','connection_id'=>'comparison','status'=>'pending','run_after'=>time()-1,'created_at'=>time(),'parameters'=>array('item'=>$i))));}
$indexed=array('seconds'=>microtime(true)-$start,'queries'=>$wpdb->num_queries-$queries,'memory_bytes'=>memory_get_usage(true)-$memory);
$a=Repository::claim('job',$group.'_0');$b=Repository::claim('job',$group.'_0');verify('indexed_claim_exclusive',null!==$a&&null===$b);Repository::release('job',$group.'_0',$a['owner']);
for($i=0;$i<50;++$i){Repository::remove('job',$group.'_'.$i);}
echo json_encode(array('wordpress'=>get_bloginfo('version'),'action_scheduler'=>array('version'=>'4.2.0','license'=>'GPLv3','requires_wordpress'=>'6.9','load'=>$load,'admission_50'=>$admission,'native_statuses'=>$statuses),'indexed_repository'=>array('admission_50'=>$indexed),'checks'=>$checks,'comparability'=>'Storage primitive experiment, not equal full-feature workers. Indexed context, results, unknown recovery and migration have separate fault/concurrency probes.','google_requests'=>0,'intercepted_background_http'=>$http),JSON_PRETTY_PRINT)."\n";
