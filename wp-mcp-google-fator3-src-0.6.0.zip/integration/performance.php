<?php
/** Compare the actual 0.4.0 and candidate code in separate WordPress processes. */
declare(strict_types=1);
if(!isset($argv[1])){
 $runs=array();foreach(array('old','new') as $variant){$pipes=array();$p=proc_open(array(getenv('F3_TEST_PHP')?:PHP_BINARY,__FILE__,$variant),array(1=>array('pipe','w'),2=>array('pipe','w')),$pipes);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);if(proc_close($p)!==0){throw new RuntimeException($err.$out);}$runs[$variant]=json_decode($out,true,512,JSON_THROW_ON_ERROR);}
 $runs['revision_query_reduction']=1-$runs['new']['revision_10']['queries']/$runs['old']['revision_10']['queries'];
 $runs['checks']=array('revision_queries_reduced_at_least_70_percent'=>$runs['revision_query_reduction']>=0.70,'public_bootstrap_no_job_deserialization'=>$runs['new']['public_jobs_init']['job_option_reads']===0,'old_fixture_did_deserialize_job'=>$runs['old']['public_jobs_init']['job_option_reads']>0);
 if(in_array(false,$runs['checks'],true)){throw new RuntimeException(json_encode($runs));}echo json_encode($runs,JSON_PRETTY_PRINT)."\n";exit;
}
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';wp_set_current_user(1);
add_filter('pre_http_request',static fn()=>new WP_Error('fixture_network_forbidden','No network'));
$path=$argv[1]==='old'?(getenv('F3_GOOGLE_BASE_SOURCE')?:__DIR__.'/../../review-040/wp-mcp-google-fator3-src-0.4.0/wp-mcp-google-fator3'):__DIR__.'/../wp-mcp-google-fator3';require $path.'/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Settings,Options,Automation\Jobs};
$queries=$wpdb->num_queries;$start=microtime(true);for($i=0;$i<10;++$i){$r=Settings::revision();if(is_wp_error($r)){throw new RuntimeException($r->get_error_message());}}
$out=array('version'=>$argv[1],'loaded_source'=>(new ReflectionClass(Settings::class))->getFileName(),'wordpress'=>get_bloginfo('version'),'revision_10'=>array('queries'=>$wpdb->num_queries-$queries,'seconds'=>microtime(true)-$start));
$old_storage=get_option('f3_mcp_google_storage');delete_option('f3_mcp_google_storage');
$fixture='f3_mcp_google_record_job_zz-perf-fixture';update_option($fixture,array('results'=>array_fill(0,500,str_repeat('x',1000))),'no');
$reads=0;add_filter('pre_option',static function($pre,$name)use(&$reads){if(str_starts_with($name,'f3_mcp_google_record_job_')){++$reads;}return $pre;},10,2);
wp_clear_scheduled_hook(Jobs::HOOK);Jobs::init();$reads=0;$queries=$wpdb->num_queries;$start=microtime(true);Jobs::init();$out['public_jobs_init']=array('job_option_reads'=>$reads,'queries'=>$wpdb->num_queries-$queries,'seconds'=>microtime(true)-$start,'scenario'=>'cron already scheduled, 500 KB legacy job payload');
delete_option($fixture);if(false!==$old_storage){update_option('f3_mcp_google_storage',$old_storage,false);}echo json_encode($out)."\n";
