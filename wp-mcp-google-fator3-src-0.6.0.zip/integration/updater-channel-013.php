<?php
declare(strict_types=1);
$root=dirname(__DIR__);$channel=getenv('F3_MCP_CHANNEL')?:dirname($root).'/review-post-050/extracted/wp-mcp-fator3-0.13.0.nao-homologado/wp-mcp-fator3/wp-mcp-fator3.php';$mu=$root.'/mysql-wordpress/wp-content/mu-plugins/f3-integration-loader.php';file_put_contents($mu,"<?php require ".var_export($root.'/wp-mcp-google-fator3/wp-mcp-google-fator3.php',true)."; require ".var_export($channel,true).";");
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';try{require $root.'/mysql-wordpress/wp-load.php';}finally{unlink($mu);}
require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';require_once ABSPATH.'wp-admin/includes/class-automatic-upgrader-skin.php';
use Fator3\McpGoogle\{Options,Updater};use Fator3\McpFiles\{Persistence,StateStore,UpdateChannel};
Persistence::install();wp_set_current_user(1);$checks=[];
function verify($name,$ok){global $checks;$checks[$name]=(bool)$ok;if(!$ok)throw new RuntimeException($name);}
$plugin='wp-mcp-google-fator3/wp-mcp-google-fator3.php';$url='https://93.184.216.34/google.zip';$bytes=file_get_contents($root.'/evidence/google-development-only.zip');$hash=hash('sha256',$bytes);
$own=['schema_version'=>'1.0.0','plugin'=>'wp-mcp-google-fator3','version'=>'0.6.0','sha256'=>$hash,'requires_php'=>'8.0','requires_wordpress'=>'6.9','package_url'=>$url];
Options::set(Updater::OPTION,['enabled'=>true,'manifest_url'=>'https://93.184.216.34/manifest.json','allowed_hosts'=>['93.184.216.34']]);
add_filter('f3_mcp_google_public_dns',static fn()=>[['ip'=>'93.184.216.34']]);
add_filter('f3_mcp_google_public_response',static fn($pre,$requested)=>['success'=>true,'status'=>200,'body'=>str_ends_with($requested,'json')?json_encode($own):$bytes],10,2);
$native=0;$body=$bytes;add_filter('pre_http_request',static function($pre,$args,$requested)use(&$native,&$body){++$native;return ['response'=>['code'=>200],'headers'=>[],'body'=>$body];},10,3);
$upgrader=new Plugin_Upgrader(new Automatic_Upgrader_Skin());delete_option('f3_mcp_update_channels');delete_transient('f3_mcp_google_update_manifest');
$ownzip=$upgrader->download_package($url,false,['plugin'=>$plugin]);if(is_wp_error($ownzip))fwrite(STDERR,$ownzip->get_error_code().':'.$ownzip->get_error_message().PHP_EOL);verify('standalone_download_not_intercepted_by_channel',is_string($ownzip)&&is_file($ownzip)&&hash_file('sha256',$ownzip)===$hash&&$native===0);unlink($ownzip);
$channels=['wp-mcp-google-fator3'=>['url'=>'https://93.184.216.34/channel.json','package_hosts'=>[]]];update_option('f3_mcp_update_channels',$channels,false);
$manifest=['schema_version'=>1,'package'=>'wp-mcp-google-fator3','plugin'=>$plugin,'version'=>'0.6.0','url'=>$url,'sha256'=>$hash,'requires'=>['wordpress'=>'6.9','php'=>'8.0'],'tested'=>['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'evidence'=>'synthetic test']];
StateStore::put('update-manifests','wp-mcp-google-fator3|'.hash('sha256',serialize($channels['wp-mcp-google-fator3'])),['manifest'=>$manifest,'expires'=>time()+300,'time'=>time()]);
verify('update_uri_matches_channel_filter',get_plugin_data($root.'/wp-mcp-google-fator3/wp-mcp-google-fator3.php',false,false)['UpdateURI']==='https://fator3.com.br/plugins/wp-mcp-google-fator3');
$check=Updater::check();verify('channel_selected_as_single_owner',!empty($check['success'])&&$check['owner']==='channel');
$offer=apply_filters('update_plugins_fator3.com.br',false,[],$plugin,[]);verify('native_update_offer_from_channel',is_array($offer)&&$offer['package']===$url);
$zip=$upgrader->download_package($url,false,['plugin'=>$plugin]);verify('native_download_channel_hash_verified',is_string($zip)&&is_file($zip)&&hash_file('sha256',$zip)===$hash&&$native===1);unlink($zip);
$body='bad';$bad=$upgrader->download_package($url,false,['plugin'=>$plugin]);verify('channel_bad_hash_refused',is_wp_error($bad)&&$bad->get_error_code()==='package_hash_conflict');
$tmp=wp_tempnam('manual-google.zip');file_put_contents($tmp,'manual upload');$manual=$upgrader->download_package($tmp,false,['plugin'=>$plugin]);verify('manual_upload_allowed_with_configured_channel',$manual===$tmp);unlink($tmp);
$other=apply_filters('upgrader_pre_download',false,$url,null,['plugin'=>'base-site-core-fator3/base-site-core-fator3.php']);verify('other_packages_keep_channel_handler',is_wp_error($other)&&$other->get_error_code()==='update_channel_unconfigured');
echo json_encode(['channel'=>F3_MCP_FILES_VERSION,'checks'=>$checks],JSON_PRETTY_PRINT)."\n";
