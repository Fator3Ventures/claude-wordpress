<?php
/** Configuration-to-audit boundaries on native WordPress/MySQL. No Google requests. */
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Audit,Options,Connections,Settings,Storage\Repository,Storage\AuditReader};
wp_set_current_user(1);$checks=array();function verify(string $label,bool $ok):void{global $checks;$checks[$label]=$ok;if(!$ok){throw new RuntimeException($label);}}
Repository::install();Options::set('f3_mcp_google_storage',array('phase'=>'indexed'));Options::set(Options::AUDIT_RETENTION,1000);$wpdb->query('DELETE FROM '.Repository::table()." WHERE kind='audit'");Options::set('f3_mcp_google_audit_removed_through',0);Options::set(Options::GA_ENABLED,false);delete_option('f3_mcp_google_audit_health_default');delete_transient('f3_mcp_google_audit_health_default');
add_filter('pre_http_request',static fn()=>new WP_Error('fixture_network_forbidden','No network'));
Repository::insert('audit','old-unassociated',array('id'=>'old-unassociated','created_at'=>time(),'action'=>'old','connection_id'=>'default'));
$a=Settings::save(array(Options::GA_ENABLED=>true));
verify('verified_save_returns_hash_and_marker',$a['success']&&$a['persisted']&&preg_match('/^[a-f0-9]{64}$/',$a['revision'])&&str_starts_with($a['audit_marker'],'event:'));
Audit::log('after-a');Audit::log('after-a-2');
$page=AuditReader::page(array('desde_revisao'=>$a['revision'],'limit'=>1));
verify('hash_resolves_exclusive_configuration_marker',$page['success']&&$page['configuration_marker']['marker']===$a['audit_marker']&&$page['entries'][0]['action']==='after-a');
verify('new_event_carries_config_association',$page['entries'][0]['configuration_revision']===$a['revision']&&$page['entries'][0]['configuration_change_id']===$a['configuration_change_id']);
Audit::log('outside-window');$next=AuditReader::page(array('cursor'=>$page['next_cursor'],'limit'=>100));
verify('fixed_window_does_not_grow',$next['success']&&array_column($next['entries'],'action')===array('after-a-2')&&$next['window_end_revision']===$page['window_end_revision']);
$export=AuditReader::export(array('cursor'=>$page['export_cursor'],'format'=>'csv'));
verify('export_preserves_marker_and_window',$export['success']&&$export['configuration_marker']===$page['configuration_marker']&&$export['window_end_revision']===$page['window_end_revision']&&str_contains(base64_decode($export['content_base64']),'configuration_revision'));
verify('changed_revision_rejected_with_cursor','f3_google_audit_cursor'===(AuditReader::page(array('cursor'=>$page['next_cursor'],'desde_revisao'=>'0'))['error_code']??''));
Connections::create('marker-other','Marker other');$foreign=Connections::run('marker-other',static fn()=>AuditReader::page(array('desde_revisao'=>$a['audit_marker'])));
verify('marker_is_connection_scoped','f3_google_audit_revision_unavailable'===($foreign['error_code']??''));
$b=Settings::save(array(Options::GA_ENABLED=>false));$a2=Settings::save(array(Options::GA_ENABLED=>true));
verify('aba_current_configuration_has_new_change_id',$a2['success']&&$a2['configuration_change_id']!==$a['configuration_change_id']&&$a2['audit_marker']!==$a['audit_marker']);
// Imported/restored or repeated hashes must still never silently select the last event.
Audit::log('configuration:saved','default',array('status'=>'ok'),array('revision'=>$a['revision'],'change_id'=>'repeated-fixture'));
$duplicate=Audit::last_marker();$ambiguous=AuditReader::page(array('desde_revisao'=>$a['revision']));
verify('repeated_hash_returns_safe_candidates','f3_google_audit_revision_ambiguous'===($ambiguous['error_code']??'')&&count($ambiguous['candidates'])===2&&in_array($duplicate,array_column($ambiguous['candidates'],'marker'),true));
$explicit=AuditReader::page(array('desde_revisao'=>$a['audit_marker']));verify('explicit_marker_resolves_ambiguity',$explicit['success']&&$explicit['configuration_marker']['marker']===$a['audit_marker']);
$missing=AuditReader::page(array('desde_revisao'=>str_repeat('f',64)));verify('missing_revision_unavailable',!$missing['success']&&$missing['coverage']==='unavailable'&&!$missing['complete']);
Repository::remove('audit',substr($duplicate,6));$expired=AuditReader::page(array('desde_revisao'=>$duplicate));verify('removed_marker_unavailable','f3_google_audit_revision_unavailable'===($expired['error_code']??''));
$all=AuditReader::page(array('desde_revisao'=>'0','limit'=>100));$old=array_values(array_filter($all['entries'],static fn($e)=>$e['id']==='old-unassociated'))[0];
verify('legacy_event_not_given_fabricated_revision',!array_key_exists('configuration_revision',$old)&&$all['legacy_association']==='unavailable'&&isset($all['coverage_start']['time']));
$fail=static function($q){return str_starts_with($q,'INSERT IGNORE INTO '.Repository::table())&&str_contains($q,"'audit'")?'INSERT INTO f3_missing_fixture_table VALUES (1)':$q;};
$wpdb->suppress_errors(true);add_filter('query',$fail);$saved=Settings::save(array(Options::GA_ENABLED=>false));remove_filter('query',$fail);$wpdb->suppress_errors(false);
verify('audit_failure_does_not_reverse_saved_config',$saved['success']&&$saved['persisted']&&$saved['audit_marker']===null&&$saved['audit_warning']['error_code']==='f3_google_audit_persistence');
verify('cursor_overflow_rejected','f3_google_audit_revision'===(AuditReader::page(array('desde_revisao'=>str_repeat('9',30)))['error_code']??''));
echo json_encode(array('wordpress'=>get_bloginfo('version'),'checks'=>$checks,'google_requests'=>0),JSON_PRETTY_PRINT)."\n";
