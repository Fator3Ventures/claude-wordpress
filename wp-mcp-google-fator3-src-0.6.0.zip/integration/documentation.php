<?php
/** Validate published examples against the native WordPress validator and live abilities. */
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';
require __DIR__.'/../mysql-wordpress/wp-load.php';
require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Plugin,Configuration};
wp_set_current_user(1);wp_get_abilities();
$http=0;add_filter('pre_http_request',static function()use(&$http){++$http;return new WP_Error('fixture_network_forbidden','No external calls');});
$root=__DIR__.'/../wp-mcp-google-fator3/';$checks=array();$errors=array();
function verify(string $label,bool $ok,?string $message=null):void{global $checks,$errors;$checks[$label]=$ok;if(!$ok){$errors[$label]=$message??'Mismatch';}}
function canonical($value){if(is_object($value)){$value=(array)$value;}if(is_array($value)){if(array_values($value)!==$value){ksort($value);}foreach($value as &$item){$item=canonical($item);}unset($item);}return $value;}
$catalog=json_decode(file_get_contents($root.'docs/ability-catalog.json'),true,512,JSON_THROW_ON_ERROR);
$live=array_filter(wp_get_abilities(),static fn($a)=>'google'===$a->get_category());
verify('catalog_count',count($live)===$catalog['total']);
verify('catalog_version',F3_MCP_GOOGLE_VERSION===$catalog['plugin_version']);
foreach($live as $entry){
 $name=$entry->get_name();$saved=$catalog['abilities'][$name]??null;
 // Core adds platform defaults such as meta.public; compare every declared plugin field.
 $meta=$entry->get_meta();$declared_meta=array_intersect_key($meta,(array)($saved['meta']??array()));
 $same_meta=canonical($saved['meta']??null)===canonical($declared_meta);$same_input=canonical($saved['input_schema']??null)===canonical($entry->get_input_schema());$same_output=canonical($saved['output_schema']??null)===canonical($entry->get_output_schema());
 verify('catalog_'.$name,is_array($saved)&&$same_meta&&$same_input&&$same_output,json_encode(array('meta'=>$same_meta,'input'=>$same_input,'output'=>$same_output)));
}
$examples=json_decode(file_get_contents($root.'docs/examples.json'),true,512,JSON_THROW_ON_ERROR);
foreach($examples['examples'] as $i=>$example){
 $entry=wp_get_ability($example['ability']);$result=$entry?rest_validate_value_from_schema($example['parameters'],$entry->get_input_schema(),'parameters'):new WP_Error('missing','Missing ability');
 verify('example_'.($i+1).'_'.$example['ability'],true===$result,is_wp_error($result)?$result->get_error_message():null);
}
$definitions=json_decode(file_get_contents($root.'docs/configuration-definitions.json'),true,512,JSON_THROW_ON_ERROR);
verify('configuration_option_count',count($definitions['options'])===count(Configuration::definitions()));
verify('no_google_calls',0===$http);
echo json_encode(array('wordpress'=>get_bloginfo('version'),'checks'=>$checks,'errors'=>$errors),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
exit($errors?1:0);
