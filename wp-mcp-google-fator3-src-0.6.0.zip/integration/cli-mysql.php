<?php
/** Actual WP-CLI parser, output/exit codes and a concurrent native worker. */
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';
require __DIR__.'/../mysql-wordpress/wp-load.php';
require_once __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Options,Settings,Connections,Policy,Records,Storage\Repository,Automation\Jobs,Automation\Worker,Generic\Discovery};
wp_set_current_user(1);add_filter('home_url',static fn()=>'https://example.test/');
if('worker'===($argv[1]??'')){$result=Worker::run($argv[2],1);echo json_encode($result);exit(!empty($result['success'])?0:1);}
file_put_contents(__DIR__.'/../evidence/cli-trace.jsonl','');$checks=array();function verify(string $name,bool $ok):void{global $checks;$checks[$name]=$ok;if(!$ok){throw new RuntimeException($name);}}
$root=dirname(__DIR__);$log=$root.'/evidence/cli-http.jsonl';file_put_contents($log,'');
$loader=$root.'/mysql-wordpress/wp-content/mu-plugins/f3-cli-probe.php';
$source=$root.'/wp-mcp-google-fator3/wp-mcp-google-fator3.php';
$php=getenv('F3_TEST_PHP')?:PHP_BINARY;
$code='<?php require_once '.var_export($source,true).';'."\n";
$code.='add_filter("home_url",static fn()=>"https://example.test/");'."\n";
$code.='add_filter("pre_http_request",static function($pre,$args,$url){if(str_contains($url,"/token")){$body=array("access_token"=>"synthetic-cli-token","expires_in"=>3600);}elseif(str_contains($url,"index:inspect")){file_put_contents('.var_export($log,true).',"inspection\n",FILE_APPEND|LOCK_EX);usleep(400000);$body=array("inspectionResult"=>array("indexStatusResult"=>array("verdict"=>"PASS")));}else{return new WP_Error("fixture_network_forbidden","No external network");}return array("response"=>array("code"=>200),"headers"=>array(),"body"=>json_encode($body));},10,3);';
file_put_contents($loader,$code);
function launch_cli(string $command,?int $user=1,string $json='{}'):array{
 global $php,$root;$args=array($php,'-d','extension=phar',$root.'/tools/wp-cli.phar','--allow-root','--path='.$root.'/mysql-wordpress');
 if(null!==$user){$args[]='--user='.$user;}$args[]='mcp-google';$args[]=$command;$args[]='--input='.$json;
 $p=proc_open($args,array(0=>array('pipe','r'),1=>array('pipe','w'),2=>array('pipe','w')),$pipes);fclose($pipes[0]);return array($p,$pipes);
}
function finish_cli(array $handle):array{[$p,$pipes]=$handle;$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$result=array('exit'=>proc_close($p),'data'=>json_decode($out,true),'stdout'=>$out,'stderr'=>$err);file_put_contents(__DIR__.'/../evidence/cli-trace.jsonl',json_encode($result)."\n",FILE_APPEND);return $result;}
try{
 delete_option('f3_mcp_google_quota_'.hash('sha256','https://example.test/'));
 Repository::install();Options::set('f3_mcp_google_storage',array('phase'=>'indexed'));$wpdb->query('DELETE FROM '.Repository::table()." WHERE kind IN ('job','schedule','dedupe','quota')");
 Options::batch_verified(array(Options::ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'cli.apps.googleusercontent.com',Settings::AUTH_READY=>true,Policy::OPTION=>array('mode'=>'identity'),Connections::SERVICES=>array('gsc'=>'read')),array(Options::OAUTH_CLIENT_SECRET=>'synthetic-cli-secret',Options::OAUTH_REFRESH_TOKEN=>'synthetic-cli-refresh'));
 set_transient(Discovery::cache_key('search-console'),json_decode(file_get_contents($root.'/wp-mcp-google-fator3/tests/fixtures/discovery/searchconsole-v1.json'),true),600);
 $r=finish_cli(launch_cli('status'));file_put_contents($root.'/evidence/cli-first-command.json',json_encode($r));verify('actual_cli_status_json',0===$r['exit']&&!empty($r['data']['success']));
 $r=finish_cli(launch_cli('status',null));verify('cli_requires_explicit_authorized_user',1===$r['exit']&&str_contains($r['stderr'],'--user'));
 $r=finish_cli(launch_cli('status',1,'[]'));verify('cli_rejects_array_input',1===$r['exit']&&str_contains($r['stderr'],'objeto JSON'));
 $r=finish_cli(launch_cli('get-job'));verify('native_schema_error_is_json_and_exit_1',1===$r['exit']&&false===($r['data']['success']??null)&&isset($r['data']['error_code']));
 $r=finish_cli(launch_cli('status',1,'{"connection_id":"missing"}'));verify('unknown_connection_refused',1===$r['exit']&&false===($r['data']['success']??null));
 $r=finish_cli(launch_cli('cleanup'));verify('cleanup_defaults_to_preview',0===$r['exit']&&!empty($r['data']['dry_run']));
 $r=finish_cli(launch_cli('run-due',1,'{"max_items":1}'));verify('bounded_due_pass_json',0===$r['exit']&&!empty($r['data']['success']));
 $created=Jobs::create(array('task'=>'inspect-urls','parameters'=>array('site_url'=>'https://example.test/','urls'=>array('https://example.test/cli-race'))));verify('race_job_admitted',!empty($created['success']));
 $cli=launch_cli('run-job',1,json_encode(array('job_id'=>$created['job_id'])));
 $p=proc_open(array($php,__FILE__,'worker',$created['job_id']),array(0=>array('pipe','r'),1=>array('pipe','w'),2=>array('pipe','w')),$pipes);fclose($pipes[0]);$native=finish_cli(array($p,$pipes));$cli=finish_cli($cli);
 $lines=file($log,FILE_IGNORE_NEW_LINES);$job=Records::get('job',$created['job_id']);verify('cli_native_worker_share_claim_and_commit',1===count($lines)&&1===$job['cursor']&&'completed'===$job['status']&&0===$cli['exit']&&0===$native['exit']);
 $r=finish_cli(launch_cli('get-job',1,json_encode(array('job_id'=>$created['job_id']))));verify('cli_reads_durable_result',0===$r['exit']&&'completed'===$r['data']['job']['status']);
 verify('cli_output_hides_credentials',!str_contains($r['stdout'],'synthetic-cli-secret')&&!str_contains($r['stdout'],'synthetic-cli-refresh'));
 echo json_encode(array('wp_cli'=>'2.12.0','wordpress'=>get_bloginfo('version'),'checks'=>$checks,'google_http'=>'intercepted'),JSON_PRETTY_PRINT)."\n";
}finally{unlink($loader);}
