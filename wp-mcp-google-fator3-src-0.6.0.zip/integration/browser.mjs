import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.F3_PLAYWRIGHT_MODULE || 'playwright');
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const evidence = path.join(root, 'evidence');
const css = fs.readFileSync(path.join(root, 'wp-mcp-google-fator3/assets/admin.css'), 'utf8');
const js = fs.readFileSync(path.join(root, 'wp-mcp-google-fator3/assets/admin.js'), 'utf8');
const checks = {};
function verify(name, value) { checks[name] = !!value; if (!value) throw new Error(name); }
const browser = await chromium.launch({executablePath: process.env.F3_CHROME || path.join(root, 'tools/browser-stable/chrome-headless-shell-linux64/chrome-headless-shell'), args:['--no-sandbox'], headless:true});
try {
  const context = await browser.newContext({viewport:{width:1280,height:1000},permissions:['clipboard-read','clipboard-write']});
  const page = await context.newPage(); const errors = [];page.on('pageerror', e=>errors.push(e.message));
  async function screen(section) {
    const html = fs.readFileSync(path.join(evidence, `admin-${section}.html`), 'utf8');
    await page.route('https://plugin.example.test/**', route=>route.fulfill({contentType:'text/html',body:`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><style>body{font:14px Arial,sans-serif;background:#f0f0f1;margin:24px}.button{font:inherit;padding:6px 12px;cursor:pointer;color:#135e96;background:white;border:1px solid #135e96;border-radius:3px}input,textarea,select{font:inherit;padding:5px}table{width:100%;border-collapse:collapse}th,td{padding:9px;text-align:left}a{color:#135e96}${css}</style></head><body>${html}<script>${js}</script></body></html>`}));
    await page.goto(`https://plugin.example.test/${section}`);
    verify(`${section}_single_heading`,await page.locator('h1').count()===1);
    verify(`${section}_json_initially_collapsed`,await page.locator('pre:visible').count()===0);
    verify(`${section}_form_controls_labeled`,await page.locator('input:not([type=hidden]),textarea,select').evaluateAll(nodes=>nodes.every(n=>n.labels?.length||n.getAttribute('aria-label'))));
    await page.keyboard.press('Tab');verify(`${section}_keyboard_reaches_control`,await page.evaluate(()=>document.activeElement!==document.body));
    await page.unroute('https://plugin.example.test/**');
  }
  for (const section of ['connection','oauth','operations','profiles','controls','advanced']) {
    await screen(section);
    if(section==='operations') {
      const detail = page.locator('details').filter({has:page.locator('[data-copy-target]')}).last();
      const summary = detail.locator('summary').first();await summary.focus();await page.keyboard.press('Enter');
      verify('details_opens_by_keyboard',await detail.getAttribute('open')!==null);
      await page.keyboard.press('Tab');verify('copy_button_receives_keyboard_focus',await detail.locator('[data-copy-target]').evaluate(n=>document.activeElement===n));
      await page.keyboard.press('Enter');await page.waitForFunction(()=>document.querySelector('#f3-live').textContent==='Conteúdo copiado.');
      verify('native_clipboard_matches_json',await page.evaluate(()=>navigator.clipboard.readText())===await detail.locator('pre').textContent());
      verify('copy_keeps_focus',await detail.locator('[data-copy-target]').evaluate(n=>document.activeElement===n));
      await page.evaluate(()=>Object.defineProperty(navigator,'clipboard',{value:undefined,configurable:true}));
      await page.keyboard.press('Enter');verify('clipboard_fallback_selects_content',await page.evaluate(()=>window.getSelection().toString())===await detail.locator('pre').textContent());
      await summary.focus();await page.keyboard.press('Enter');verify('details_closes_by_keyboard',await detail.getAttribute('open')===null);
    }
    if(section==='connection'||section==='operations'||section==='controls') await page.screenshot({path:path.join(evidence,`browser-${section}.png`),fullPage:true});
    await page.setViewportSize({width:390,height:844});
    verify(`${section}_mobile_no_horizontal_overflow`,await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1));
    if(section==='operations') await page.screenshot({path:path.join(evidence,'browser-operations-mobile.png'),fullPage:true});
    await page.setViewportSize({width:1280,height:1000});
  }
  verify('no_javascript_errors',errors.length===0);
  await context.close();
  const plain = await browser.newContext({javaScriptEnabled:false,viewport:{width:1280,height:1000}});
  const nojs = await plain.newPage();await nojs.setContent(fs.readFileSync(path.join(evidence,'admin-operations.html'),'utf8'));
  const summary=nojs.locator('details > summary').first();await summary.focus();await nojs.keyboard.press('Enter');verify('native_details_works_without_javascript',await summary.locator('..').getAttribute('open')!==null);
  await plain.close();
  fs.writeFileSync(path.join(evidence,'browser-latest.json'),JSON.stringify({browser:browser.version(),checks,scope:'Native WordPress-rendered HTML and plugin assets; form controllers independently exercised by admin-forms.php. No Google/network calls.'},null,2)+'\n');
  console.log(JSON.stringify({checks:Object.keys(checks).length,passed:true}));
} finally {await browser.close();}
