<?php
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Http\PublicPage,Storage\AuditReader,Options};
$checks=array();$requests=array();$responses=array();$ips=array('public.test'=>array('93.184.216.34'));
function verify(string $label,bool $ok):void{global $checks;if(!$ok){throw new RuntimeException($label);} $checks[$label]=true;}
add_filter('f3_mcp_google_public_dns',static function($prior,$host)use(&$ips){return array_map(static fn($ip)=>array(str_contains($ip,':')?'ipv6':'ip'=>$ip),$ips[$host]??array());},10,2);
add_filter('f3_mcp_google_public_response',static function($prior,$url)use(&$requests,&$responses){$requests[]=$url;return $responses[$url]??array('success'=>false,'status'=>0);},10,2);
foreach(array('127.0.0.1','10.0.0.1','169.254.169.254','100.64.0.1','198.18.0.1','192.0.2.1','224.0.0.1','::1','fc00::1','fe80::1','::ffff:127.0.0.1','64:ff9b::7f00:1','2001:db8::1','2002:7f00:1::','3fff::1') as $ip){$ips['public.test']=array($ip);verify('blocked_address_'.$ip,is_wp_error(PublicPage::validate('https://public.test/',array('public.test'))));}
$ips['public.test']=array('93.184.216.34','127.0.0.1');verify('mixed_public_private_dns_refused',is_wp_error(PublicPage::validate('https://public.test/',array('public.test'))));$ips['public.test']=array('93.184.216.34');
$responses=array('https://public.test/a'=>array('success'=>true,'status'=>301,'headers'=>array('location'=>'/b')),'https://public.test/b'=>array('success'=>true,'status'=>200,'body'=>'<link rel="canonical" href="https://public.test/b">'));
$r=PublicPage::fetch('https://public.test/a',array('public.test'));verify('relative_redirect_uses_native_wordpress_resolution',$r['success']&&2===count($r['chain'])&&'https://public.test/b'===$r['live_canonical']);
$responses['https://public.test/b']=array('success'=>true,'status'=>302,'headers'=>array('location'=>'http://127.0.0.1/'));$before=count($requests);$r=PublicPage::fetch('https://public.test/a',array('public.test'));verify('redirect_to_unlisted_host_stops_before_dispatch',!$r['success']&&2===count($requests)-$before);
$responses['https://public.test/b']=array('success'=>true,'status'=>302,'headers'=>array('location'=>'/a'));$r=PublicPage::fetch('https://public.test/a',array('public.test'));verify('loop_refused','f3_google_redirect_loop'===$r['error_code']);
$responses['https://public.test/b']=array('success'=>true,'status'=>200,'body'=>str_repeat('x',100));$r=PublicPage::fetch('https://public.test/a',array('public.test'),5,32);verify('body_limit_is_explicit',$r['truncated']&&32===strlen($r['body']));$r=PublicPage::fetch('https://public.test/a',array('public.test'),0);verify('redirect_budget_respected','f3_google_redirect_limit'===$r['error_code']);
$responses['https://public.test/a']=array('success'=>false,'status'=>0);$r=PublicPage::fetch('https://public.test/a',array('public.test'));verify('transport_failure_is_not_success',!$r['success']&&'f3_google_public_transport'===$r['error_code']);
Options::set('f3_mcp_google_storage',array('phase'=>'indexed'));foreach(array('2026-02-30','yesterday','2026-09-30T24:00:00Z','2026-09-30T12:30:00') as $date){$r=AuditReader::page(array('from'=>$date));verify('strict_audit_date_'.$date,!$r['success']&&'f3_google_audit_dates'===$r['error_code']);}
$r=AuditReader::page(array('from'=>'2026-09-30','to'=>'2026-09-29'));verify('reversed_audit_range_refused',!$r['success']&&'f3_google_audit_dates'===$r['error_code']);
echo json_encode(array('checks'=>$checks,'transport'=>'DNS and response fixtures; WordPress URL resolver is real'),JSON_PRETTY_PRINT)."\n";
