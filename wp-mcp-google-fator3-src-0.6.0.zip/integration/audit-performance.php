<?php
/** Indexed audit load and failure observability on native WordPress/MySQL. */
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Audit,Ability,Options,Connections,Plugin,Storage\Repository,Storage\AuditReader};
wp_set_current_user(1);$checks=array();$bench=array();function verify(string $label,bool $ok):void{global $checks;$checks[$label]=$ok;if(!$ok){throw new RuntimeException($label);}}
Repository::install();Options::set('f3_mcp_google_storage',array('phase'=>'indexed'));Options::set(Options::ENABLED,true);delete_option('f3_mcp_google_audit_health_default');delete_transient('f3_mcp_google_audit_health_default');
add_filter('pre_http_request',static fn()=>new WP_Error('fixture_network_forbidden','No network'));
foreach(array(100,1000,5000) as $size){
 $wpdb->query('DELETE FROM '.Repository::table()." WHERE kind='audit'");Options::set(Options::AUDIT_RETENTION,$size);Options::set('f3_mcp_google_audit_removed_through',0);
 for($i=0;$i<$size;++$i){Repository::insert('audit','load-'.$i,array('created_at'=>time(),'action'=>'fixture','connection_id'=>'default','extra'=>array('mode'=>'read','status'=>'ok'),'large'=>str_repeat('x',4096)));}
 $sql=array();$capture=static function($q)use(&$sql){$sql[]=$q;return $q;};add_filter('query',$capture);$queries=$wpdb->num_queries;$before=microtime(true);Audit::log('append-benchmark');$append=array('queries'=>$wpdb->num_queries-$queries,'seconds'=>microtime(true)-$before);remove_filter('query',$capture);
 $payload_selects=array_filter($sql,static fn($q)=>preg_match('/^SELECT\b/i',$q)&&str_contains($q,Repository::table())&&(str_contains($q,'payload')||str_contains($q,'SELECT *')));verify('append_'.$size.'_does_not_load_history_payload',0===count($payload_selects));
 $read_sql=array();$read_capture=static function($q)use(&$read_sql){$read_sql[]=$q;return $q;};add_filter('query',$read_capture);$queries=$wpdb->num_queries;$before=microtime(true);$page=AuditReader::page(array('limit'=>30));$read=array('queries'=>$wpdb->num_queries-$queries,'seconds'=>microtime(true)-$before,'decoded_entries'=>count($page['entries']));remove_filter('query',$read_capture);file_put_contents(__DIR__.'/../evidence/audit-query-count.json',json_encode(['size'=>$size,'read'=>$read,'queries'=>$read_sql],JSON_PRETTY_PRINT));verify('read_'.$size.'_bounded_sql',$read['queries']<=16);verify('read_'.$size.'_bounded_30',$page['success']&&30===count($page['entries']));$bench[$size]=array('append'=>$append,'read_30'=>$read);
}
// Bound includes fresh migration state and cold credential/configuration options.
// Later samples may reuse configuration/token cache; larger retention must not add SQL.
verify('read_cost_does_not_grow_with_retention',max(array_column(array_column($bench,'read_30'),'queries'))<=$bench[100]['read_30']['queries']+2);
verify('append_cost_independent_of_retention',max(array_column(array_column($bench,'append'),'queries'))-min(array_column(array_column($bench,'append'),'queries'))<=2);
add_action('wp_abilities_api_init',static function(){Ability::register('google/audit-failure-fixture','any',array('label'=>'Fixture','description'=>'Synthetic local write','connector'=>'any','mode'=>'write','callback'=>static fn()=>array('success'=>true,'operation_outcome'=>'applied')));});
$fail=static function($q){return str_starts_with($q,'INSERT IGNORE INTO '.Repository::table())&&str_contains($q,"'audit'")?'INSERT INTO f3_missing_fixture_table VALUES (1)':$q;};
$wpdb->suppress_errors(true);add_filter('query',$fail);$result=wp_get_ability('google/audit-failure-fixture')->execute(array());remove_filter('query',$fail);$wpdb->suppress_errors(false);
verify('audit_failure_preserves_remote_outcome',!empty($result['success'])&&'applied'===$result['operation_outcome']);verify('audit_failure_returned_to_caller','f3_google_audit_persistence'===($result['audit_warning']['error_code']??''));verify('audit_failure_durable','failed'===Audit::health()['state']);
Audit::log('after-failure');verify('success_does_not_hide_history_gap','recovered'===Audit::health()['state']&&true===Audit::health()['historical_gap']&&false===AuditReader::page(array('limit'=>100))['complete']);
Connections::create('audit-other','Audit other');verify('append_failure_connection_isolated','no_failure_observed'===Connections::run('audit-other',static fn()=>Audit::health())['state']);
delete_option('f3_mcp_google_audit_health_default');delete_transient('f3_mcp_google_audit_health_default');echo json_encode(array('wordpress'=>get_bloginfo('version'),'checks'=>$checks,'benchmarks'=>$bench,'google_requests'=>0),JSON_PRETTY_PRINT)."\n";
