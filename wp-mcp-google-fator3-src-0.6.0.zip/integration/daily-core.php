<?php
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';
require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
$core=getenv('F3_CORE_SOURCE')?:dirname(__DIR__,2).'/review-post-050/extracted/base-site-core-fator3-1.18.0/base-site-core-fator3/includes/';
require_once dirname(rtrim($core,'/')).'/base-site-core-fator3.php';
use Fator3\McpGoogle\{Options,Connections,Settings,Records,SearchConsole\Daily,Automation\Jobs};
wp_set_current_user(1);F3Base_Editorial::instalar();F3Base_Inteligencia::instalar();
Options::batch_verified([Options::ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'synthetic.apps.googleusercontent.com',Connections::SERVICES=>['gsc'=>'read']],[Options::OAUTH_CLIENT_SECRET=>'synthetic-secret',Options::OAUTH_REFRESH_TOKEN=>'synthetic-refresh']);
$checks=[];$queries=[];$rows=[];$malformed=false;
function verify($name,$ok){global $checks;$checks[$name]=(bool)$ok;if(!$ok)throw new RuntimeException($name);}
add_filter('pre_http_request',static function($pre,$args,$url)use(&$queries,&$rows,&$malformed){
 $body=null;if(str_contains($url,'$discovery'))$body=json_decode(file_get_contents(__DIR__.'/../wp-mcp-google-fator3/tests/fixtures/discovery/searchconsole-v1.json'),true);
 elseif(str_contains($url,'oauth2.googleapis.com/token'))$body=['access_token'=>'synthetic-token','expires_in'=>3600];
 elseif(str_contains($url,'searchAnalytics/query')){$q=json_decode($args['body'],true);$queries[]=$q;$body=['rows'=>$rows];}
 else return new WP_Error('unexpected_http',$url);
 return ['response'=>['code'=>200],'headers'=>[],'body'=>json_encode($body)];
},10,3);
update_option('f3base_llms',['ligado'=>false],false);
$post_id=wp_insert_post(['post_type'=>'post','post_status'=>'publish','post_title'=>'Synthetic daily import article','post_content'=>'Fixture']);
verify('core_article_catalogued',F3Base_Editorial::catalogar($post_id));$article_url=get_permalink($post_id);
$day=(new DateTimeImmutable('today',new DateTimeZone('America/Los_Angeles')))->modify('-5 days')->format('Y-m-d');
$conf=['enabled'=>true,'site_url'=>'sc-domain:127.0.0.1','start_date'=>$day];
$r=Daily::configure(['configuration'=>$conf,'expected_revision'=>Settings::revision()]);verify('schedule_configured',!empty($r['success']));verify('cron_scheduled',(bool)wp_next_scheduled(Jobs::HOOK));
$table=F3Base_Editorial::tabela('gsc_diario');
for($n=0;$n<3;$n++){
 $d=(new DateTimeImmutable($day))->modify("+$n day")->format('Y-m-d');$rows=[['keys'=>[$d,$article_url],'clicks'=>4+$n,'impressions'=>40+$n,'position'=>2.5]];
 $r=Daily::tick();if(empty($r['success'])){fwrite(STDERR,json_encode($r).PHP_EOL);}verify('daily_import_'.$n,!empty($r['success']));
}
verify('three_final_rows_persisted',(int)$wpdb->get_var("SELECT COUNT(*) FROM $table")===3);$status=Daily::status();verify('last_day_is_d_minus_3',$status['last_imported_day']===$d&&$status['status']==='completed');
foreach($queries as $q)verify('query_final_page_date',strtolower($q['dataState']??'')==='final'&&array_map('strtolower',$q['dimensions'])===['date','page']);
$view=F3Base_Editorial_Relatorios::consultar(['de'=>$day,'ate'=>$d,'visao'=>'gsc','post_id'=>$post_id]);verify('editorial_gsc_view_has_article_metrics',!empty($view['ok'])&&count($view['paginas'])===1&&(int)$view['paginas'][0]['post_id']===$post_id&&(float)$view['paginas'][0]['cliques']===15.0&&(float)$view['paginas'][0]['impressoes']===123.0&&(float)$view['paginas'][0]['posicao_media']===2.5);
$before=Records::get('gscdaily','default');Daily::configure(['configuration'=>$conf,'expected_revision'=>Settings::revision()]);verify('unchanged_config_preserves_checkpoint',Records::get('gscdaily','default')===$before);
$before['next_run']=time()-1;Records::put('gscdaily','default',$before);$rows=[['keys'=>[$day,$article_url],'clicks'=>8,'impressions'=>50,'position'=>1.5]];Daily::tick();verify('replay_starts_three_final_days_back',end($queries)['startDate']===$day);verify('replay_is_upsert',(int)$wpdb->get_var("SELECT COUNT(*) FROM $table")===3&&(float)$wpdb->get_var($wpdb->prepare("SELECT cliques FROM $table WHERE dia=%s",$day))===8.0);
$s=Records::get('gscdaily','default');$current=$s['day'];$rows=[['keys'=>[$current,$article_url],'clicks'=>100,'impressions'=>1,'position'=>1]];$r=Daily::tick();verify('core_business_error_not_success',empty($r['success'])&&$r['error_code']==='f3_google_gsc_import_rejected');$failed=Records::get('gscdaily','default');verify('rejected_page_does_not_advance',$failed['day']===$current&&$failed['offset']===0);
$failed['next_run']=0;Records::put('gscdaily','default',$failed);$rows=[['keys'=>[$current,$article_url],'clicks'=>2]];$r=Daily::tick();verify('missing_metrics_not_invented',empty($r['success'])&&$r['error_code']==='f3_google_gsc_import_response');
$s=Records::get('gscdaily','default');$s['next_run']=0;Records::put('gscdaily','default',$s);$rows=[];$r=Daily::tick();verify('empty_day_not_imported_as_zero',!empty($r['success'])&&(int)$wpdb->get_var("SELECT COUNT(*) FROM $table")===3);
$s=Records::get('gscdaily','default');$s['next_run']=0;$s['identity']='changed';Records::put('gscdaily','default',$s);$count=count($queries);$r=Daily::tick();verify('credential_change_stops_before_query',empty($r['success'])&&count($queries)===$count);
Options::delete(Daily::OPTION);
echo json_encode(['wordpress'=>get_bloginfo('version'),'core'=>'1.18.0','google_responses'=>'simulated','checks'=>$checks],JSON_PRETTY_PRINT)."\n";
