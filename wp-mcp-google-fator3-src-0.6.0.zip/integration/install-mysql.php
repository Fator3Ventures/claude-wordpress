<?php
$db=new mysqli('127.0.0.1','root','',null,33071);
$db->query('CREATE DATABASE IF NOT EXISTS f3_google_next CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
define('WP_INSTALLING',true);$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';
require __DIR__.'/../mysql-wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';
add_filter('pre_wp_mail','__return_true');
if(!is_blog_installed())wp_install('Google disposable integration lab','google-lab','lab@example.invalid',false,'',bin2hex(random_bytes(24)));
echo json_encode(['wordpress'=>get_bloginfo('version'),'mysql'=>$wpdb->get_var('SELECT VERSION()')]);
