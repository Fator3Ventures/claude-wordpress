<?php
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';require __DIR__.'/../mysql-wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';
foreach($wpdb->tables('ms_global') as $name=>$table){$wpdb->$name=$table;}
add_filter('pre_wp_mail','__return_true');add_filter('pre_http_request',static fn()=>new WP_Error('fixture_network_forbidden','No network'));
install_network();
if(!$wpdb->get_var("SELECT id FROM {$wpdb->site} WHERE id=1")){$r=populate_network(1,'127.0.0.1','lab@example.test','Disposable network','/',false);if(is_wp_error($r)&&'no_wildcard_dns'!==$r->get_error_code()){throw new RuntimeException($r->get_error_message());}}
echo "Disposable WordPress network tables ready.\n";
