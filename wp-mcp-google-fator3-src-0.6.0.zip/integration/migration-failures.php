<?php
/** Corrupt source/destination and refused writes on the real WordPress database. */
declare(strict_types=1);
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';
require __DIR__.'/../mysql-wordpress/wp-load.php';require __DIR__.'/../wp-mcp-google-fator3/wp-mcp-google-fator3.php';
use Fator3\McpGoogle\{Options,Records,Storage\Migration,Storage\Repository};
wp_set_current_user(1);$checks=array();
function verify(string $label,bool $ok):void{global $checks;if(!$ok){throw new RuntimeException($label);} $checks[$label]=true;}
function reset_source():void{global $wpdb;$wpdb->query('DROP TABLE IF EXISTS '.Repository::table());$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'f3_mcp_google_record_%' OR option_name LIKE 'f3_mcp_google_lock_%'");delete_option(Migration::OPTION);wp_cache_flush();}
function finish_migration():void{for($i=0;$i<10&&!Migration::active();++$i){$r=Migration::step(2);if(!$r['success']){throw new RuntimeException(json_encode($r));}}}
reset_source();Records::insert('audit','one',array('action'=>'one','created_at'=>10));update_option(Records::key('audit','two'),'broken-source');
$r=Migration::begin();verify('corrupt_source_blocks_switch',!$r['success']&&'failed'===Migration::state()['phase']&&!Migration::active());verify('corrupt_source_is_preserved','broken-source'===get_option(Records::key('audit','two')));
update_option(Records::key('audit','two'),array('action'=>'two','created_at'=>20));finish_migration();verify('repair_resumes_without_duplicate',Migration::active()&&2===Repository::count('audit'));
reset_source();Records::insert('audit','one',array('action'=>'one','created_at'=>10));$r=Migration::begin();verify('copy_requires_separate_verification','verify'===Migration::state()['phase']);
$wpdb->query("UPDATE ".Repository::table()." SET payload='{}' WHERE kind='audit'");$r=Migration::step();verify('corrupt_destination_blocks_switch',!$r['success']&&!Migration::active());verify('destination_corruption_does_not_delete_source',is_array(get_option(Records::key('audit','one'))));
Repository::remove('audit','one');Repository::insert('audit','one',get_option(Records::key('audit','one')));finish_migration();verify('verified_repair_can_resume',Migration::active());
reset_source();Records::insert('audit','one',array('action'=>'one','created_at'=>10));
$deny=static function($sql){return str_starts_with($sql,'INSERT IGNORE INTO '.Repository::table())?'SELECT * FROM f3_intentional_missing_table':$sql;};add_filter('query',$deny);$wpdb->suppress_errors(true);$r=Migration::begin();remove_filter('query',$deny);$wpdb->suppress_errors(false);
verify('refused_insert_keeps_source_and_pauses',!$r['success']&&Migration::paused()&&is_array(get_option(Records::key('audit','one'))));finish_migration();verify('insert_failure_resumes_and_verifies',Migration::active()&&1===Repository::count('audit'));
echo json_encode(array('checks'=>$checks,'source_preserved'=>true),JSON_PRETTY_PRINT)."\n";
