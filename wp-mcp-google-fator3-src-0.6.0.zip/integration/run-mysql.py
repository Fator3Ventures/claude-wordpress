#!/usr/bin/env python3
"""Disposable native probes. --fresh initializes an isolated temporary MySQL datadir.
Never point these probes at production: they replace their own fixture records.
"""
import pathlib, os, subprocess, time, socket, sys, tempfile
root = pathlib.Path(__file__).resolve().parent.parent
runtime = pathlib.Path(os.environ.get('F3_TEST_RUNTIME', '/workspace/scratch/351cd9518840/runtime1150'))
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = str(runtime / 'root/usr/lib/x86_64-linux-gnu')
php = os.environ.get('F3_TEST_PHP', str(runtime / 'php'))
env['F3_TEST_PHP'] = php
mysqld = os.environ.get('F3_TEST_MYSQLD', str(runtime / 'root/usr/sbin/mysqld'))
basedir = os.environ.get('F3_TEST_MYSQL_BASEDIR', str(runtime / 'root/usr'))
fresh = '--fresh' in sys.argv
scripts = [s for s in sys.argv[1:] if s != '--fresh']
private = tempfile.TemporaryDirectory(prefix='f3-google-mysql-') if fresh else None
datadir = pathlib.Path(private.name) if private else root / 'mysql-data'
common = [mysqld, '--no-defaults', '--basedir=' + basedir, '--datadir=' + str(datadir),
          '--user=root', '--skip-log-bin', '--innodb-redo-log-capacity=268435456']
if fresh:
    initialized = subprocess.run(common + ['--initialize-insecure'], env=env, capture_output=True, text=True)
    if initialized.returncode:
        raise RuntimeError(initialized.stderr)
    scripts.insert(0, 'install-mysql.php')
for name in ('f3-cli-probe.php', 'f3-integration-loader.php'):
    (root / 'mysql-wordpress/wp-content/mu-plugins' / name).unlink(missing_ok=True)
log = datadir / 'probe.log'
server = subprocess.Popen(common + ['--socket=', '--port=33071', '--bind-address=127.0.0.1',
          '--mysqlx=0', '--pid-file=' + str(datadir / 'probe.pid'), '--secure-file-priv=',
          '--innodb-fast-shutdown=0', '--log-error=' + str(log)], env=env, start_new_session=True)
try:
    for _ in range(100):
        if server.poll() is not None:
            raise RuntimeError(log.read_text()[-3000:])
        try:
            with socket.create_connection(('127.0.0.1', 33071), .1):
                break
        except OSError:
            time.sleep(.1)
    for script in scripts:
        result = subprocess.run([php, str(root / 'integration' / script)], capture_output=True, text=True, env=env)
        for name in ('f3-cli-probe.php', 'f3-integration-loader.php'):
            (root / 'mysql-wordpress/wp-content/mu-plugins' / name).unlink(missing_ok=True)
        (root / 'evidence' / (pathlib.Path(script).stem + '-final.txt')).write_text(result.stdout + '\n' + result.stderr)
        print(script + ': ' + str(result.returncode), flush=True)
        if result.returncode:
            print(result.stdout, result.stderr)
            sys.exit(result.returncode)
finally:
    server.terminate()
    server.wait(timeout=30)
    if private:
        private.cleanup()
