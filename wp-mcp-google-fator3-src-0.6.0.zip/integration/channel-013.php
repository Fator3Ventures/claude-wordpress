<?php
declare(strict_types=1);
$root=dirname(__DIR__);$channel=getenv('F3_MCP_CHANNEL')?:dirname($root).'/review-post-050/extracted/wp-mcp-fator3-0.13.0.nao-homologado/wp-mcp-fator3/wp-mcp-fator3.php';
$mu=$root.'/mysql-wordpress/wp-content/mu-plugins/f3-integration-loader.php';
file_put_contents($mu,"<?php require ".var_export($root.'/wp-mcp-google-fator3/wp-mcp-google-fator3.php',true)."; require ".var_export($channel,true).";");
$_SERVER['HTTP_HOST']='127.0.0.1:38041';$_SERVER['REQUEST_URI']='/';try{require $root.'/mysql-wordpress/wp-load.php';}finally{unlink($mu);}
use Fator3\McpGoogle\{Options,Ability,Connections,Policy,Updater,Gate};
use Fator3\McpFiles\{Persistence,ConnectionContext,Providers,UpdateChannel};
wp_set_current_user(1);Persistence::install();Options::set(Options::ENABLED,true);$checks=[];$http=0;
function verify($name,$ok){global $checks;$checks[$name]=(bool)$ok;if(!$ok)throw new RuntimeException($name);}
function profile($name,$abilities=[]){Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'profile'=>$name,'abilities'=>$abilities,'expires'=>0,'policy_version'=>1,'status'=>'active','time'=>time()]);}
function errorcode($r){return is_wp_error($r)?$r->get_error_code():($r['error_code']??'');}
add_filter('pre_http_request',static function()use(&$http){++$http;return new WP_Error('network_forbidden','No network expected');});
profile('read');rest_get_server();verify('provider_registered',Providers::known('wp-mcp-google-fator3'));
$a=wp_get_ability('google/status');verify('google_adherent',!empty($a->get_meta()['fator3']['adherent']));$r=$a->execute([]);verify('read_profile_status',!is_wp_error($r)&&!empty($r['success']));
$r=wp_get_ability('google/mcp-read')->execute(['ability'=>'google/status']);verify('read_profile_direct_bridge',!is_wp_error($r)&&!empty($r['success']));
foreach(['google/mcp-write'=>['ability'=>'gsc/submit-sitemap'],'gtm/create-tag'=>['parent'=>'accounts/1/containers/2/workspaces/3','body'=>['name'=>'x','type'=>'html']],'google/configure-local'=>[]] as $name=>$input){$a=wp_get_ability($name);$r=$a->check_permissions($input);verify('read_denies_'.$name,is_wp_error($r)||!$r);}
profile('custom',['google/mcp-read']);$r=wp_get_ability('google/mcp-read')->execute(['ability'=>'google/status']);verify('bridge_authorizes_final_target','profile_denied'===errorcode($r));
profile('custom',['google/mcp-read','google/status']);$r=wp_get_ability('google/mcp-read')->execute(['ability'=>'google/status']);verify('custom_explicit_target_works',!is_wp_error($r)&&!empty($r['success']));
profile('maintenance');Options::set(Policy::OPTION,['mode'=>'restricted','resources'=>[]]);verify('maintenance_full_gtm_policy',null===Policy::check_http('POST','https://tagmanager.googleapis.com/tagmanager/v2/accounts/1/containers/2/workspaces/3/tags',[],[]));
$requires=new ReflectionMethod(Fator3\McpGoogle\Confirmation::class,'requires');$requires->setAccessible(true);verify('maintenance_no_extra_confirmation',!$requires->invoke(null,'https://tagmanager.googleapis.com/tagmanager/v2/accounts/1/containers/2/workspaces/3/tags/4',[],['method'=>'DELETE']));
profile('unconfigured');$local=Gate::administrative('ga/list-profiles',static fn()=>Ability::execute_admin('ga/list-profiles',[]));verify('local_admin_screen_independent_of_mcp_profile',!is_wp_error($local)&&!empty($local['success']));
$denied=Ability::execute_admin('ga/list-profiles',[]);verify('local_admin_entry_requires_internal_context','f3_google_admin_context'===errorcode($denied));
verify('no_remote_dispatch_for_permission_checks',0===$http);
$meta=wp_get_ability('google/mcp-read')->get_meta();verify('bridge_declares_executor',!empty($meta['fator3']['executes_ability']));
verify('canonical_legacy_routes',isset(rest_get_server()->get_routes()['/mcp/wp-mcp-fator3'])&&isset(rest_get_server()->get_routes()['/mcp/wp-mcp-ultimate']));
echo json_encode(['wordpress'=>get_bloginfo('version'),'channel'=>F3_MCP_FILES_VERSION,'checks'=>$checks],JSON_PRETTY_PRINT)."\n";
