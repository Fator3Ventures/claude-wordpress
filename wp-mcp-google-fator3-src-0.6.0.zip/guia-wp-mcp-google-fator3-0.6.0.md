# Guia — WP MCP Google Fator3 0.6.0

Candidato da próxima release única. Confira VALIDACAO.md (`VALIDACAO.md` no pacote-fonte) para saber quais verificações estão concluídas e quais ainda impedem a publicação. O pacote é genérico e não depende de manual de configuração de uma agência.

## Configurar a conexão

1. Abra **Ferramentas → MCP Google** e selecione a conexão. Service Account aparece primeiro e é o padrão para uma nova configuração. O método ativo de uma instalação anterior é preservado.
2. Em **Conexão**, importe a chave JSON da Service Account. O plugin prepara uma candidata cifrada; salvar a candidata não substitui a credencial em uso.
3. Conceda à identidade técnica os acessos necessários nos serviços Google. Obter token não comprova acesso a uma propriedade. Use o script Cloud Shell revisado como referência para criar projeto/conta/chave; o plugin não o executa.
4. Escolha explicitamente **ativar** a candidata. A ativação verifica autenticação e os recursos já vinculados. Uma reprovação preserva a credencial ativa e apresenta o diagnóstico.
5. Em **Serviços e recursos**, habilite somente os serviços e níveis necessários. Prefira leitura quando a instalação não precisar alterar o Google. Selecione ou informe os recursos existentes.
6. Em **Diagnóstico**, execute o teste de acesso e confira cada resultado. `not_configured` e `skipped` não significam aprovação. A abertura das telas e do contrato não faz essas consultas Google automaticamente.

Para OAuth, abra a área **OAuth de usuário**, configure Client ID/Secret e o callback exibido e autorize os serviços escolhidos. A autorização prepara a candidata; a ativação continua explícita. Não configure duas identidades ativas na mesma conexão. Conexões diferentes podem usar métodos diferentes.

Client Secret, chave privada, refresh token, access token e developer token não são reexibidos no painel ou nas respostas de configuração. Deixe um campo secreto vazio quando a operação indicar preservação; para remover, use a ação explícita. Uma falha de cifra ou persistência não produz aviso de “salvo”.

Google Ads exige configuração própria de developer token e, quando aplicável, conta administradora (`login customer ID`). Esses campos não substituem a autorização da identidade ao recurso. O acesso efetivo depende também da versão/API e permissões da conta.

## Entender as telas

| Área | Uso |
|---|---|
| Conexão | Método ativo, candidata, importação e ativação; OAuth separado; desconexão local e revogação diferenciadas |
| Serviços e recursos | Perfis de acesso, descoberta, bindings e opções do Ads |
| Diagnóstico | Resultado por serviço/recurso, data e contexto da observação |
| Operações | Jobs, aprovação de exportações, execução/consulta/cancelamento/reconciliação, agendas, incidentes e auditoria |
| Perfis GA4 | Definições locais, revisão, comparação e preparação da aplicação |
| Controles | Política, modelos portáteis, alertas e origem de atualização |
| Avançado | Canal, limites, retenções e contrato técnico |

Os JSONs ficam em áreas expansíveis e têm botão de cópia. Os formulários funcionam sem JavaScript; cópia e aviso de alterações pendentes são complementos. A navegação entre métodos não altera a credencial. Cada envio usa nonce e, nas alterações de configuração, revisão para evitar sobrepor outra edição.

O diagnóstico do transporte consulta os recursos detectáveis do canal. Rotas REST existentes não são prova de que um servidor MCP as expõe. O painel informa o que conseguiu observar; não exibe como fato uma falha de detecção quando a integração é reconhecida. A versão do WordPress fica na documentação técnica, sem ocupar a lista de pré-requisitos do formulário.

## URL MCP e contratos para agentes

Preferir `/wp-json/mcp/wp-mcp-fator3`. O alias `/wp-json/mcp/wp-mcp-ultimate` pertence ao canal MCP Fator3; a compatibilidade foi exercitada com o canal 0.13.0. O complemento Google preserva seu callback OAuth e não modifica plugins de transporte.

Comece por `google/status`, `google/configuration-schema` e `google/ability-catalog`. O catálogo é paginado (até 100 itens) e informa a versão em todas as habilidades. `include_schemas:true` inclui schemas de entrada/saída. Use `next_offset` até terminar a leitura. O contrato de configuração não expõe segredos nem exige repetir regras de validação no implantador.

A documentação gerada está em CATALOGO.md (`CATALOGO.md` no pacote-fonte), ability-catalog.json (`ability-catalog.json` no pacote-fonte) e configuration-definitions.json (`configuration-definitions.json` no pacote-fonte). configuration-example.json (`configuration-example.json` no pacote-fonte) é uma fixture sintética sem credenciais e não descreve o estado de um site real.

## Perfis GA4 configuráveis

Um perfil é um objeto versionado que declara somente o estado desejado. As seções suportadas são retenção, medição otimizada, Google Signals, redação de dados, atribuição, dimensões e métricas personalizadas. Consulte `ga/profile-schema`; campos não suportados são recusados antes da rede.

Não existe perfil universal aplicado automaticamente. Salve uma definição em `ga/save-profile` ou envie `profile` diretamente. Ao alterar uma definição existente, forneça `expected_revision` de `ga/list-profiles`.

Exemplo ilustrativo, sem pretensão de padrão universal:

```json
{
  "schema_version": "1.0.0",
  "retention": {"eventDataRetention": "FOURTEEN_MONTHS"},
  "custom_dimensions": [
    {"parameterName": "method", "scope": "EVENT", "displayName": "Método"}
  ]
}
```

1. Consulte `ga/conformidade` com `property_id`, `stream_id` quando houver seções de stream, e `profile_id` ou `profile`.
2. Leia `complete`, `conformant`, `checks`, `changes`, `auth.configured`, `data_streams` e `streamEnabled`. Os estados do diff incluem `already`, `missing`, `different`, `unsupported` e `not_verified`.
3. `ga/aplicar-perfil` simula por padrão. `simular` é alias de `dry_run`; se ambos forem enviados, precisam coincidir.
4. Para aplicar, envie `dry_run:false` e o `expected_plan_hash` da comparação. Múltiplas mudanças, redução de retenção e operações sensíveis exigem também `google/prepare-operation` e o token retornado.
5. A retenção é aplicada primeiro. Cada etapa é relida; divergência interrompe as próximas. Consulte novamente a conformidade após falha parcial/incerta.

A aplicação não cria propriedade/stream, não apaga definições extras e compara a grafia exata de `displayName`. Uma dimensão existente com “Metodo” pode ser corrigida para “Método” sem duplicar o parâmetro. Um 403 opcional em `accessBindings` informa falta daquela capacidade; não comprova que o papel é Editor. O campo `role` permanece desconhecido sem evidência.

## Vincular ao Site Core

A integração é optativa: `vincular_site_core:true` em `google/plan-configuration` e `google/configure`. O plugin lê `f3base_ga4_measurement_id`, pesquisa propriedades/streams acessíveis e exige uma correspondência única e completa. Grava o binding de propriedade, stream e Measurement ID, mantendo `ga_default_property` coerente.

Sem essa opção, configurar outros campos não inicia descoberta no Google. Core ausente, ID inválido, correspondência ambígua, paginação incompleta e mudança da fonte são estados próprios. O plugin não modifica a configuração de tracking do Core. Se GTM estiver ativo, o Measurement ID direto pode estar inativo; informe o destino explicitamente. Um binding divergente precisa aparecer como mudança explícita na prévia.

## Search Console e sitemaps

`gsc/preparar-site` coordena acesso à propriedade existente, consulta do sitemap publicado, consulta/submissão quando necessária, confirmação do registro, vínculo local optativo e inspeções. Envie `site_url` e `sitemap_url`; `dry_run` é verdadeiro por padrão. `save_binding:true` exige `expected_revision`. O fluxo não cria propriedade, não altera DNS e não garante indexação.

`gsc/inspect-urls` aceita até 500 URLs. `auto` processa até cinco URLs únicas na própria chamada quando há tempo e cota; lotes maiores retornam job persistido. `queued` apenas enfileira. Continue pelo mesmo `job_id`; consulte `remaining`, `next_eligible_at` e os resultados paginados.

`gsc/migracao-conferir` recebe propriedades de origem/destino e até 25 pares de URLs. Informa cadeia HTTP atual, canônica observada, estado indexado, impressões e cobertura temporal. Ausência de linhas de Search Analytics não prova zero impressões. Não recomenda remover redirecionamentos com base nessa ausência e não muda redirects.

As consultas a páginas públicas limitam tamanho, tempo e redirecionamentos; validam todos os hosts/IPs e fixam o endereço resolvido no transporte. Endereços privados, reservados, compartilhados e destinos fora da lista são recusados. Origem HTTP é admitida quando pertinente à migração; downloads de atualização permanecem exclusivamente HTTPS.

PUTs vazios de Search Console preservam `Content-Length: 0`. Para investigar um novo HTTP 411, confira domínio, versão do complemento Google e resultado HTTP; a versão de outro plugin não identifica o código desse transporte.

## Jobs, agendas e sites sem visitas

O painel Operações filtra por tarefa, estado e período de criação em UTC, além da conexão. O painel e as habilidades usam o mesmo worker. Nenhuma tarefa depende de uma sessão aberta no navegador. WP-Cron precisa de disparo: sites atendidos por cache podem acumular agendas vencidas mesmo com a configuração correta.

`google/executar-vencidos` executa uma passagem na conexão selecionada; `all_connections:true` inclui todas as conexões deste WordPress. O resultado diferencia ocorrências despachadas, itens processados, bloqueios e trabalho restante. `google/status.cron` informa `agendas_vencidas`, atraso, próxima execução e última passagem/sucesso.

Uma agenda aceita consultas, relatórios ou preflight; exportações mutáveis não são agendas recorrentes automáticas. Atualizações usam a revisão de `google/get-schedule`. Pausar é gravar `enabled:false`; dados já produzidos permanecem consultáveis.

Exemplos WP-CLI, substituindo caminho, usuário e IDs:

```sh
wp --path=/caminho/wordpress --user=administrador mcp-google status --input='{"connection_id":"default"}'
wp --path=/caminho/wordpress --user=administrador mcp-google run-due --input='{"connection_id":"default","max_items":25}'
wp --path=/caminho/wordpress --user=administrador mcp-google get-job --input='{"job_id":"ID_RETORNADO"}'
wp --path=/caminho/wordpress --user=administrador mcp-google cleanup --input='{"dry_run":true}'
```

O adaptador recusa execução sem usuário autorizado e retorna JSON/código de saída. O adaptador foi exercitado com WP-CLI 2.12.0, incluindo concorrência com o worker nativo. Use `--input` para fornecer parâmetros; `--json` é um atalho global de saída do WP-CLI e não recebe o corpo de entrada. Para cron do servidor, configure um disparador por minuto com caminho/usuário corretos e trava contra sobreposição, usando `wp cron event run --due-now`. Só desabilite o disparador por visita após verificar o externo. O plugin não altera essa configuração do servidor.

Em `unknown`, confira o recurso Google e use `google/reconcile-job` com resultado observado e evidência. Reconciliação não repete a escrita. Depois de resolver, uma nova intenção deve ter outra chave quando os parâmetros forem diferentes.

## Políticas, modelos, alertas e auditoria

A política limita recursos e operações; bindings apenas escolhem defaults. Consulte a política atual, prepare a mudança em `google/plan-policy` e aplique a revisão/hash revisados. A prévia informa defaults fora do alcance e contextos que precisarão ser revistos. Uma política local não reduz as permissões da chave no Google.

Modelos portáteis parametrizam recursos e excluem segredos/identidades/alertas. Mapeie os parâmetros no destino, consulte `google/plan-template` e aplique com revisão/hash. Nenhum modelo ativa credencial ou e-mail automaticamente.

Alertas operacionais começam desligados. Habilite registro e e-mail separadamente em Controles. Eventos de acesso, atraso de executor, sitemap e verificações agendadas têm recuperação e intervalo mínimo. Não há envio real durante os testes fornecidos; “accepted” indica aceitação pelo `wp_mail`, sem comprovar entrega.

`google/audit` aceita `desde_revisao` (hash de configuração, `audit_marker` retornado ao salvar ou sequência decimal exclusiva), cursor e filtros de ação, alvo, usuário, estado, modo, conexão e datas. Hashes repetidos retornam candidatos: escolha um marcador exato. Marcadores ausentes ou expurgados retornam cobertura indisponível. Cada página informa `configuration_marker` e início do histórico retido; eventos antigos não recebem associação retroativa. Use datas `YYYY-MM-DD` ou RFC3339 com fuso; intervalos invertidos e datas normalizadas inválidas são recusados. `google/audit-export` exporta até 100 eventos por página, em JSON/CSV, com hash. Siga o cursor para completar a janela; `retention_gap` avisa que parte do histórico já foi removida. `google/audit-to-sheet` é uma escrita separada e exige preparação/confirmação. Falha de persistência do log aparece em `audit_warning` na chamada afetada e em `google/status.audit_health`; consultas do histórico deixam `complete:false`. Um registro posterior bem-sucedido não apaga essa lacuna.

## Atualização e dados locais

O instalador não inclui README, CHANGELOG, CONTRACTS, docs, referências ou scripts legíveis diretamente por HTTP. A documentação completa acompanha fontes/documentação; o script revisado é entregue pelo painel autenticado. Índices silenciosos protegem listagens quando o servidor reconhece `index.php`; não substituem controle de acesso a arquivos existentes. Não há `.htaccess` no plugin.

A origem de atualização é configurada por administrador. Não há URL de distribuição inventada ou ativa por padrão. Manifesto/pacote devem permanecer em hosts permitidos, por HTTPS, com hash e versão correspondentes. O fluxo usa o atualizador nativo do WordPress. Upload manual com substituição permanece disponível.

Atualizar preserva opções e credenciais. Desativar cancela executores e limpa tokens temporários, preservando credenciais duráveis. Desinstalar remove sempre segredos e mantém por padrão configuração pública/histórico sanitizado, com tarefas pausadas. A limpeza adicional é optativa. Reinstalar exige credenciais e revisão dos trabalhos; não revoga nada no Google nem remove dados de outros plugins.

## Search Console diário → Site Core

Em **Operações**, habilite a importação diária, informe a propriedade exata deste site e a data inicial. A função exige Site Core com o importador `f3base/gsc-importar` (validado com 1.18.0), permissão de administrador e acesso Search Console na conexão Google. O padrão é buscar os últimos 30 dias, limitado aos 16 meses anteriores e a D-3. A ativação é optativa e não muda os dados existentes.

Em cada passagem, o executor avança uma página/dia. Consulte `google/gsc-import-status` ou `google/status.gsc_import`; `last_checked_day` pode ser maior que `last_imported_day` quando a API não trouxe linhas. O primeiro preenchimento pode exigir várias passagens. Sites sem visitas precisam de disparo externo de WP-Cron ou WP-CLI; cache não dispara tarefas sozinho. Use `google/executar-vencidos` ou `google/sync-gsc-core` para avançar imediatamente dentro do orçamento. Troca de credencial/autor, revogação ou mudança do perfil exige reconfiguração da agenda.

## Google Tag Manager

1. Na aba **Service Account**, prepare e ative a chave como nos demais serviços. Habilite Tag Manager API no projeto e conceda acesso ao e-mail técnico na conta/contêiner GTM. Não há contêiner predefinido no plugin.
2. Em **Serviços e recursos**, habilite Tag Manager: Leitura, Edição/publicação ou Administração. Administração inclui contas, usuários e exclusão de contêineres; o nível da conexão não substitui as permissões concedidas no Google. OAuth continua como alternativa em aba própria e precisa autorizar os novos escopos.
3. Descubra `gtm/list-accounts`, `gtm/list-containers` e `gtm/list-workspaces`. O caminho `accounts/123/containers/456` usa IDs da API; `GTM-…` é o ID público. O diagnóstico também pode resolver o ID público salvo no Site Core.
4. Use as rotas tipadas de tags, gatilhos, variáveis, pastas, modelos, ambientes, versões, permissões e workspaces. O catálogo cobre também recursos server-side, zonas e configurações Google Tag quando a conta os suporta.
5. Simule `gtm/publicar` com `path` do workspace. Confira o diff e guarde `expected_fingerprint`. Aplique com o mesmo `path`, `simular:false` e fingerprint. Mudanças desde a prévia exigem nova simulação.
6. Guarde `previous_version_id` e `new_workspace_path`. Para voltar, simule `gtm/reverter` com `path:"accounts/123/containers/456/versions/ID_ANTERIOR"` e aplique com o fingerprint retornado.
7. Se houver `operation_outcome:unknown`, consulte `gtm/get-publication`, `gtm/live-version` e `google/audit` antes de decidir outra escrita. A mesma intenção não repete a publicação automaticamente.

`gtm/diagnostico` compara a versão publicada com os slots GA4, Ads, Meta e LinkedIn lidos deste Site Core. Informa tags pausadas, gatilhos e configuração de consentimento. Variáveis dinâmicas e HTML personalizado são inconclusivos; encontrar um ID literal não prova disparo, entrega de eventos nem comportamento do consentimento no navegador.

## Canal, migração e documentação

O canal 0.13.0 aplica os perfis às habilidades e às ferramentas diretas. Manutenção tem acesso integral GTM; Leitura recusa escrita; Personalizado precisa autorizar a bridge e o alvo. O painel local continua protegido pela sessão administrativa e pelos nonces, sem depender de um perfil MCP para configurar o plugin.

Durante migração, respeite `retry_after_ms` e consulte `google/storage-status`. Uma lacuna antiga de auditoria fica identificada como histórica mesmo depois da recuperação da gravação atual.

No rodapé do painel, expanda **Documentação desta versão** para baixar guia, contratos e histórico autenticados. Nenhum Markdown ou script operacional precisa ficar exposto diretamente por HTTP no diretório do plugin. Use o pacote-fonte para o acervo completo e as evidências.

---

# Validação da versão 0.6.0

Data: 01/10/2026. Ambiente: PHP 8.3.6, WordPress 7.1 e MySQL 8.0.46; canal Fator3 0.13.0 e importador Site Core 1.18.0. As APIs Google e a distribuição foram simuladas. Nenhuma alteração foi implantada em produção.

As evidências desta release ficam em `evidence/` do pacote-fonte. O histórico da 0.5.0 está em VALIDACAO-0.5.0.md (`history/VALIDACAO-0.5.0.md` no pacote-fonte) e não substitui os resultados atuais.

- Suíte unitária/regressão: **964 testes e 11.707 asserções aprovados**, incluindo criação de tag/gatilho/variável, publicação e reversão com Service Account sintética. Resultado em `unit-final.txt`.
- Estilo e compatibilidade PHP 8.0+: zero erros e avisos; `phpcs-final.json`; sintaxe: `php-lint-final.json`.
- Importação com serviço/banco reais do Core, incluindo artigo catalogado e visão editorial com cliques, impressões e posição até D-3: `daily-core-final.txt`.
- Canal e perfis reais: `channel-013-final.txt`; atualizadores reais: `updater-channel-013-final.txt`.
- Migração concorrente: `migration-admission-final.txt`; chamadas admitidas e recusadas, cópia e recuperação histórica.
- Persistência: 25 verificações com funções reais do WordPress/SQLite. Repositório, concorrência e painel: sondas MySQL incluídas no pacote-fonte. Navegador: 38 verificações aprovadas de teclado, cópia, rótulos e layout móvel. Downloads de seis documentos e do Cloud Shell conferidos byte a byte; acesso anônimo e nonce inválido recusados.
- Pacote: 100 verificações HTTP locais com Apache, autoindex habilitado e `AllowOverride None`; todos os 17 diretórios com índice, Markdown/script público ausente e recursos PHP protegidos. PUT vazio: três caminhos retornaram 204, com `Content-Length: 0` e zero bytes. Inventário e SHA-256 acompanham a entrega.

A validação local comprova os contratos exercitados. Falta homologar chamadas às contas Google reais, o aceite editorial por artigo no site alvo, permissões da Service Account no GTM e comportamento de tags/consentimento no navegador. O diagnóstico GTM é estático. Compatibilidade com toda combinação de PHP/WordPress/MariaDB não foi executada; o piso declarado continua PHP 8.0 e Abilities API compatível.

---

# Atualização direta, migração e recuperação — 0.6.0

## Antes de substituir a 0.4.0

Faça backup do banco e do pacote anterior. Confira personalizações externas na pasta do plugin e mantenha-as fora dela: a substituição nativa remove o diretório antigo. Não use extração por cima como caminho de atualização homologado. Não execute `uninstall.php` durante uma atualização.

A configuração anterior permanece na conexão `default`. OAuth ativo não é convertido para Service Account. Ausência de política preserva o alcance da identidade anterior; novas conexões começam restritas. A nova preferência de limpeza pública na desinstalação começa desativada.

## Migração do armazenamento

O repositório fica em `{prefixo}f3_google_records`, com índices para conexão, estado, vencimento, auditoria e retenção. Jobs, agendas, itens, resultados, deduplicação e diários têm registros independentes. Resultados tabulares são armazenados em blocos; listagens consultam metadados.

A transição segue `drain → copy → verify → indexed`. Desde `drain`, novas chamadas são recusadas com `f3_google_storage_migrating` e `retry_after_ms:15000`. Operações admitidas antes da transição finalizam sua auditoria; a migração aguarda as leases antes da cópia. Consultas locais e a retomada permanecem disponíveis. A origem nas opções é preservada. O cursor é persistido por registro, e a troca ocorre somente após releitura, hash e contagens compatíveis. Corrupção/falha mantém `failed` e não ativa uma cópia incompleta.

O cron `f3_mcp_google_storage_step` avança lotes. Consulte `google/storage-status`; `google/migrate-storage` retoma um lote sob autorização. Em falha, investigue `failed_record` e o erro antes de continuar. Não elimine dados de origem para fazer uma divergência desaparecer. Repare a causa e repita a verificação.

Jobs antigos sem contexto autorizado viram `blocked`; escritas antigas em andamento viram `unknown`. Agendas antigas sem contexto ficam desativadas para revisão. Eles não passam a usar uma credencial diferente implicitamente.

## Confirmar a atualização

1. Confira versão, conexão e estado da migração.
2. Execute diagnóstico dos recursos usados no site, com autorização de acesso real.
3. Redescubra as habilidades no cliente MCP e adapte escritas sensíveis ao contrato 2.0.0.
4. Verifique os diretórios/URLs antigas de documentação após a substituição. Limpe caches externos que ainda sirvam cópias antigas; o plugin não controla CDN/backup.
5. Valide o disparador de cron num período sem visitas e confira `agendas_vencidas`.
6. Revise agendas/jobs bloqueados e a política antes de criar novas intenções.

## Reversão

Não copie o ZIP antigo por cima do novo nem force jobs incertos a `pending`. A versão antiga não lê o novo repositório. Uma reversão operacional exige backup coerente anterior à migração e revisão dos efeitos remotos produzidos desde esse backup. Restaurar o banco não desfaz alterações no Google.

Para uma falha de job, preserve IDs, contexto, cursor, resultado e auditoria. Consulte o destino. `reconcile-job` registra a conclusão observada sem repetir a ação. Resultado parcial pode exigir correção manual ou nova intenção limitada ao que falta.

## Inventário de remoção

| Ação | Credenciais duráveis | Tokens temporários | Configuração pública / histórico | Agendas/jobs |
|---|---|---|---|---|
| Substituição/atualização | Preservados | Reutilizados ou renovados conforme contexto | Preservados/migrados | Contexto antigo sem prova exige revisão |
| Desativação | Preservados | Removidos | Preservados | Cron de jobs e migração cancelado |
| Desinstalação padrão | Removidos, inclusive candidatas | Removidos | Preservados e sanitizados | Pausados; escritas em andamento ficam incertas |
| Desinstalação com purge | Removidos | Removidos | Dados próprios removidos | Registros próprios removidos |

Em multisite, a rotina percorre os sites e respeita a preferência de purge de cada um. Remove caches próprios de rede identificados, sem apagar tabelas/opções/cron de outros plugins e sem revogação remota.

GTM e a importação diária ficam optativos na 0.6.0. A atualização não ativa serviços novos nem agenda importações. Com canal 0.13.0, configure os perfis das conexões antes de usar as ferramentas. Para auditoria antiga com falha, uma nova gravação confirmada informa `recovered` e mantém `historical_gap:true`; os eventos perdidos não são inventados.

---

# Matriz de entrega — 0.6.0

Esta matriz liga a implementação ao plano integral e aos oito pedidos adicionais. A orientação de 30/09 substitui as dependências do manual indisponível: perfis são genéricos, explícitos e versionados. Nenhuma configuração particular de agência é inventada ou aplicada automaticamente.

O instalador e os fontes pertencem à mesma versão. Os nomes dos testes abaixo são arquivos em `tests/`; as sondas nativas ficam em `integration/` na raiz do pacote-fonte. Resultados e limites estão em VALIDACAO.md (`VALIDACAO.md` no pacote-fonte).

| Frente | Implementação entregue | Evidência principal |
|---|---|---|
| M0 | Base 0.4.0, build reproduzível, dependências de desenvolvimento fixadas, laboratório nativo e decisão do executor | `composer.lock`, inventários, ADR 001 (`ADR-001-FILA.md` no pacote-fonte), `performance.php` |
| A1 | Classificação central de 627 métodos/versões; consultas POST; recusa de wildcard de escrita e de método desconhecido | `NextFoundationTest`, `GenericTest`, `ResourcePolicyTest` |
| A2 | Contexto congelado, identidade, ator, destinos, revisão e idempotência; mudança de defaults não redireciona trabalho | `QueueIntentTest`, `JobApprovalTest`, `concurrency-mysql.php` |
| A3 | Efeito remoto separado do sucesso de execução; continuação após criação vinculada; reconciliação de escrita incerta | `BlendSheetsTest`, `HistoryAndOutcomeTest`, `concurrency-mysql.php` |
| A4 | Contrato de execução 2.0.0, erros estruturados, selftest e adaptador MCP com `isError` | `ReleaseContractsTest`, `mcp-channel.php` |
| A5 | Preparação, token de uso único, intenção/ator/site/contexto vinculados e diário antes do envio | `NextFoundationTest`, `JobApprovalTest`, `concurrency-mysql.php` |
| A6 | Allowlist de runtime, 16 índices, ausência de docs/referências públicas, sem `.htaccess`; lifecycle com segredo sempre removido na desinstalação | `build/build.py`, `package-http.py`, `upgrader-mysql.php`, `uninstall-multisite.php` |
| A7 | 280 habilidades registradas, versão em todas, catálogo consultável e estado local sem consultas Google implícitas | `documentation.php`, `OperationalStateTest`, `mcp-channel.php` |
| A8 | Oito pedidos conciliados na tabela abaixo | Guias, contratos e evidências das respectivas frentes |
| B1 | Service Account padrão, credencial candidata cifrada, promoção validada e ativa preservada em falha | `UxConfigurationTest`, `ConfigurationTest`, `ReleaseContractsTest` |
| B2 | Repositório indexado, migração em lotes e verificação antes da troca; origem preservada | `repository-mysql.php`, `migration-failures.php`, Migração (`MIGRACAO.md` no pacote-fonte) |
| B3 | Worker com prazo e limite por passagem, concorrência, cota por tentativa, itens/resultados separados e limpeza retomável | `QueueIntentTest`, `SiteWorkflowTest`, `concurrency-mysql.php`, `executor-scope.php` |
| B4 | Painel de operações, filtros, resumo legível, alvos, cancelamento, reconciliação e agendas; JSON recolhível | `admin-forms.php`, `browser.mjs`, `HistoryAndOutcomeTest` |
| B5 | Revisão por leitura agrupada, cache por contexto e inicialização sem hidratar jobs | `performance.php`, `OperationalStateTest` |
| B6 | Executor comum, `executar-vencidos`, WP-CLI com usuário explícito e consulta genérica somente leitura | `cli-mysql.php`, `executor-scope.php`, `GenericTest` |
| B7 | Leitura optativa do Measurement ID do Core; descoberta completa e única; bindings e default coerentes | `ReviewCoreTest`, `UpdateCoreTest`, Guia (`GUIA-0.6.0.md` no pacote-fonte) |
| B8 | Perfil configurável/versionado, diff, retenção primeiro, grafia exata e leitura de conformidade | `GenericProfileTest`, `GAAdminTest`, Schema (`profile-schema.json` no pacote-fonte) |
| B9 | Auditoria indexada, hash/marcador exclusivo e ambiguidade, revisão/cursor, lacunas, falha observável, exportação JSON/CSV e escrita Sheets separada | `audit-markers.php`, `audit-performance.php`, `repository-mysql.php`, `HistoryAndOutcomeTest` |
| B10 | Status agregado, observações de APIs/cotas, contadores locais e modelos de relatório autodescritivos | `OperationalStateTest`, `ReleaseContractsTest`, Modelos (`report-templates.json` no pacote-fonte) |
| C1 | Política por recurso/operação, prévia de impacto, cobertura do executor genérico e escritas compostas | `ResourcePolicyTest`, `ReviewCoreTest` |
| C2 | Modelos portáteis sem segredos, parâmetros, plano e revisão; sem ativar credencial ou alertas | `ReleaseContractsTest`, `admin-forms.php` |
| C3 | Alertas optativos, registro/e-mail separados, recuperação, intervalo e bloqueio de reenvio incerto | `OperationalStateTest`, `ReleaseContractsTest`, `repository-mysql.php` |
| C4 | Classes separadas para apresentação, credenciais, armazenamento e execução; contrato derivado; WPCS/PHPCompatibility | `phpcs.xml.dist`, `composer.lock`, `documentation.php`, catálogo gerado |
| C5 | Preparação GSC, inspeção imediata/fila e conferência de migração com destinos públicos protegidos | `SiteWorkflowTest`, `public-transport.php`, `EmptyPutTest` |
| C6 | Atualizador nativo, origem optativa, HTTPS/host/hash/versão/compatibilidade e substituição do pacote antigo | `UpgradeTest`, `upgrader-mysql.php`, `package-http.py` |

## Oito pedidos adicionais

| Pedido | Resultado na 0.6.0 |
|---|---|
| 1. Fechamento do pacote | Documentação e referências acompanham os fontes, fora do runtime público. Script revisado disponível por download autenticado. Todas as 16 pastas do instalador contêm `index.php`. |
| 2. `ga/aplicar-perfil` | Perfil como dado validado, sem criar propriedade; retenção primeiro e somente diferenças. `method` e acentos são aceitos; o administrador define as dimensões/métrica. Inclui `ga/list-custom-dimensions`. |
| 3. `ga/conformidade` | Leitura com diff, `auth.configured`, `data_streams` e `streamEnabled`. O 403 de `accessBindings` não reprova todo o diagnóstico nem é usado para presumir o papel Editor. |
| 4. Vínculo Core | `vincular_site_core:true` em planejamento/configuração lê a opção do Core, resolve os recursos e grava bindings/default. Integração optativa para manter o plugin genérico. |
| 5. GSC | `gsc/preparar-site` e `gsc/migracao-conferir`, com parâmetros explícitos, pendências e resultados por etapa. Sem dependência dos parágrafos do manual indisponível. |
| 6. Vencidos | `google/executar-vencidos`, WP-CLI e `google/status.cron.agendas_vencidas`; mesmo worker, sem depender de visitas para execução explícita. |
| 7. Metadados | `meta.fator3.version:0.6.0` em todas as 280 habilidades, incluindo as 132 da base. |
| 8. Auditoria | `desde_revisao`, filtros/cursor, exportação local paginada e exportação Sheets como escrita própria confirmada. |

## Implantação posterior à entrega

O pacote não atualiza a frota, concede acessos Google, envia e-mail real ou escolhe a origem de distribuição por conta própria. Inventário de produção, permissões reais, piloto e lotes usam o mesmo artefato validado. PHP 8.0/WordPress 6.4 permanecem pisos declarados; a execução nativa deste laboratório ocorreu em PHP 8.3/WordPress 7.1, sem afirmar que todas as combinações foram ensaiadas.

## Pedidos adicionais 8–11

| Pedido | Entrega 0.6.0 | Prova |
|---|---|---|
| 8 | Importação diária final por página/dia, replay de três dias, retomada e estado no status | `integration/daily-core.php`, Core 1.18.0 real, Google simulado |
| 9 | Provedor/contrato do canal, perfil na bridge e alvo, atualizadores coordenados | `integration/channel-013.php`, `updater-channel-013.php` |
| 10 | Barreira de migração antes do despacho; auditoria de chamada admitida antes da cópia; saúde recuperada com lacuna preservada | `integration/migration-admission.php`, dois processos e MySQL real |
| 11 | 106 métodos GTM, rotas tipadas, publicação/reversão com diário e diagnóstico | `tests/NextReleaseTest.php`; sem publicação em contêiner Google real |

A implementação não usa IDs de frota nem depende de um padrão externo. A homologação dos aceites em fator3/korvena/contêiner de teste real permanece uma etapa de implantação autorizada pelo responsável.
