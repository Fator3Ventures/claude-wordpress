# WP MCP Google Fator3 0.6.0 - pacote-fonte

Entrega integral de 01/10/2026. Este ZIP nao e instalavel: mantenha fora da pasta publica do WordPress.

- wp-mcp-google-fator3/: codigo, testes, composer.lock, build, README, CHANGELOG, CONTRACTS, docs e referencias Cloud Shell original/revisada.
- integration/: sondas locais e instrucoes. Exigem banco e WordPress descartaveis; consulte o README antes de executar.
- evidence/: resultados da versao 0.6.0 e inventario do instalador.
- fixtures/: instalador Google 0.4.0, fontes do canal 0.13.0 e Site Core 1.18.0, somente para reproduzir os ensaios. Nao sao instaladores desta release.
- guia-wp-mcp-google-fator3-0.6.0.md: guia consolidado.

PHP, MySQL, WordPress, navegador e vendor nao estao incluidos. Instale as dependencias de desenvolvimento pelo composer.lock. Nenhuma chamada a conta Google real ou implantacao em producao foi realizada.
