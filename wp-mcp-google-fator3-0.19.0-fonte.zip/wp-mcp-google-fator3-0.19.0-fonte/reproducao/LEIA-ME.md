# Reprodução — Google 0.19.0

Base direta: 0.18.1. O runtime do fonte corresponde ao instalador separado; nenhum ZIP é aninhado. Evidências atuais em `plugin/wp-mcp-google-fator3/evidence/019`. Diretórios anteriores são históricos.

## Dependências

Linux amd64, Python 3, PHP 8.3.6 e MySQL 8.0.46. `runtime-dependencies.json` fixa os 30 pacotes oficiais por hash. Execute `python3 download-runtime.py /caminho/novo/runtime` nesta pasta. Não instala serviços do sistema. Use `usr/bin/php8.3` com `LD_LIBRARY_PATH` para `usr/lib/x86_64-linux-gnu` e um php.ini com as extensões ctype, fileinfo, tokenizer, phar, mbstring, mysqlnd, mysqli, pdo, pdo_mysql, dom, xml, simplexml, xmlreader, xmlwriter, curl, zip, iconv e posix. O laboratório gera esse ini; para PHPUnit/gate, use um wrapper com esses mesmos módulos.

WordPress: https://wordpress.org/wordpress-7.1.2.tar.gz e https://wordpress.org/wordpress-7.1.3.tar.gz. WP-CLI: https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar (2.12.0 na execução; verificar hash porque a URL pode avançar). Instaladores: Google 0.18.1, candidato Google 0.19.0, MCP 0.29.1, Core 1.49.1, Meta 0.8.0 e LinkedIn 0.9.0. Os hashes e as versões da execução constam de `evidence/019/validation019.json` e `inputs.json`; não substitua versões silenciosamente.

## Execução

1. Em `plugin/wp-mcp-google-fator3`, execute `composer install` com o lock entregue e `php vendor/bin/phpunit --log-junit /caminho/unit.xml`. Referência desta rodada: PHPUnit 9.6.37; 1.169 testes e 14.384 asserções.
2. Execute `npm ci --prefix reproducao/jsdom` a partir da raiz do fonte. Exporte `NODE_PATH` para o `node_modules` resultante (jsdom 27.4.0).
3. Crie dois manifestos usando `mkmanifest.py`: mínimo WordPress 7.1.2 e atual 7.1.3. Declare `runtime`, `wordpress`, `candidate`, `baseline`, `mcp`, `core`, `baseline_mcp`, `baseline_core`, `meta`, `linkedin` e `wp_cli`. A base Google é sempre 0.18.1 e os acompanhantes são os atuais. Runtime é diretório; os demais são arquivos. Compare hashes com as evidências, inclusive o instalador candidato.
4. Execute `python3 tools/release019.py --manifest min.json --manifest-current atual.json --manifest-upgrade atual.json --work-base /caminho/novo/labs --evidence /caminho/novo/evidence --php /caminho/php-wrapper`. O gate contempla clean, clean-713, upgrade, google-first e isolated. Pode usar `--only` para casos individuais, sem declarar os casos omitidos como executados. Não reutilize diretórios não vazios.
5. O gate confere bytes do instalador contra o runtime, fixa identidade de ferramentas/testes, faz lint e contratos e executa WordPress/MySQL reais. Transporte Google é sintético e HTTP externo/e-mail são bloqueados. Processos são encerrados. A atualização exercita MCP HTTP, rollback e reaplicação, com inventário exato dos acompanhantes. As instalações limpas integradas têm Core/MCP; o cenário de atualização inclui também Meta/LinkedIn; isolated contém apenas Google.
6. `tests/native/capture-contracts019.php` reproduz a captura do catálogo da base, usando temporariamente o instalador 0.18.1 como `candidate`. `tests/fixtures/contracts0181.json` contém o catálogo nativo com MCP 0.29.1. É necessário comparar no mesmo ambiente: o MCP acrescenta idempotency_key e campos de resultado ausentes do export unitário.

## Limites

As respostas Google simuladas provam o comportamento local, inclusive rejeição sem gravação e preservação de concessões/provas/fila. Não homologam credencial real, atribuição comercial ou acesso efetivo a contas Google. A inspeção jsdom testa o DOM e interações; não é uma avaliação visual de navegador. A situação do Site-Teste e as provas remotas constam do relatório e de `site-teste019.json`. A ausência de chave de teste mantém o aceite real do pedido 36 pendente do responsável pelas credenciais.
