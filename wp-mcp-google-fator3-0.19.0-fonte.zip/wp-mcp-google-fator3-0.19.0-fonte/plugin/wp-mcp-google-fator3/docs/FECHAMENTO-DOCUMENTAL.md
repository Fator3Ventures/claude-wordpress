# Fechamento documental — 0.19.0

Release baseada diretamente na 0.18.1, com o pedido Google 36. Valida credenciais antes da gravação, apresenta identidade e comprovantes, orienta a troca de conta e preserva os vínculos na rotação de chave da mesma identidade. As 287 habilidades anteriores mantêm seus esquemas; três operações administrativas elevam o catálogo a 290 habilidades. A opção protegida de comprovantes eleva o total a 37. O contrato de configuração permanece 4.0.0.

Acompanhantes desta bancada: Core 1.49.1, MCP 0.29.1, Meta 0.8.0 e LinkedIn 0.9.0. Evidências correntes em `evidence/019`; o relatório externo registra os resultados e limites efetivamente observados, inclusive a ausência de chave Google real para homologação comercial. Não se presume ausência de efeito a partir de `retryable`.

O instalador entregue deve corresponder byte a byte à árvore e ao candidato validados. O relatório externo é canônico e contém o hash do fonte; a cópia interna precede seu fechamento. Evidências históricas são preservadas em seus diretórios. Não há modificação de Core ou outros plugins, nem impacto técnico que exija encaminhamento a seus mantenedores.
