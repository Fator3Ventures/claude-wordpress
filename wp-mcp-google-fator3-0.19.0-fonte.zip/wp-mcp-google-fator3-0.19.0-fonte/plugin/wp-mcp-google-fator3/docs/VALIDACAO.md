# Validação 0.19.0

Pedido Google 36. Testes em tests/CredentialSafety019Test.php e tests/native/credentials019.php. Matriz em tools/release019.py: WordPress 7.1.2 e 7.1.3, PHP 8.3.6, MySQL 8.0.46; instalação limpa, atualização direta 0.18.1, ordem Google primeiro e plugin isolado. Os resultados finais, hashes e limites estão em evidence/019 e no relatório externo da release.

Cobertura: formatos, credencial revogada simulada, cache de token, corrida de revisão, rollback, grants de consumidor, prova de conversão/validade, fila preservada, identidade diferente com prévia, developer token, nome default, HTML/DOM, recusa de não administrador, documentação paginada e compatibilidade com a regra de idempotência MCP 0.29.1.

Google e e-mail interceptados nos laboratórios. Isso não comprova chave real revogada, permissão comercial, atribuição ou gasto. Site-Teste sem credencial Google na leitura inicial; homologação do fornecedor depende de chave de teste. Provas antigas permanecem explicitamente históricas no fonte; somente evidence/019 corresponde a esta rodada. Nenhum teste de navegador visual completo é afirmado.
