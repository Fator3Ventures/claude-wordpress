# Fator3 MCP Meta 0.9.0

Implementação do Pedido MCP Meta 15, base aceita 0.8.0. Credenciais são conferidas antes da persistência; rotação da mesma identidade e mudanças compatíveis regravam agendas atomicamente. Troca de identidade tem simulação, revisão e confirmação vinculada. Campos orientados, identidade/app/validade/permissões visíveis e 35 operações administrativas.

Código canônico: `build/common`, `build/meta`, `build/assets`; documentação instalada em `build/docs/meta`. Runtime `plugin/wp-mcp-meta-fator3` deve ser idêntico ao instalador. Testes/evidências da rodada: `tests/native/release090.php`, `release090-metadata.php`, `tests/dom/credential090.cjs` e `evidence/0.9.0`. Evidências históricas não representam testes novos. Entradas em `inputs/0.9.0` e planejamento em `planning/RELEASE-090.md`.

Build: `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`. Empacotamento: `python3 tools/package-source.py --output-dir /diretorio/externo`. O fonte não é instalável e não contém ZIP aninhado; somente o instalador entra no WordPress.

Reprodução nativa: `tools/build-isolated090-probe.py --baseline <runtime-080> --candidate <runtime-090> --output <fora-do-fonte>`. O controlador temporário em tests/site cria prefixo/tabelas e diretório próprios, bloqueia HTTP/e-mail externos e permite suítes fixas, mínimo, atualização e limpeza. Nunca instalar esses auxiliares em produção. O teste de credenciais usa apenas respostas HTTP sintéticas; as provas com fornecedor real ficam com o operador.

DOM: jsdom 27.4.0, `node tests/dom/credential090.cjs <fixture-ui090.json> build/assets/admin.js tests/credential-fields090.json <evidence.json>`. A fixture é gerada por tests/native/ui090.php em WordPress isolado. O relatório principal traz as versões, resultados efetivos, limites, bytes/hashes e estado final do Site-Teste. Respostas e encerramentos de impactos pertencem a esse relatório; nenhum impacto deve ser emitido só para anunciar esta versão.
