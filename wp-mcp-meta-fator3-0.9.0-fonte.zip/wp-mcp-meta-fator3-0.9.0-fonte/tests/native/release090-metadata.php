<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
require_once __DIR__.'/lab-helpers.php';
use Fator3\Meta as M;
wp_set_current_user(1);
$checks=[];$http=0;
function verify050($name,$ok){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$ok];if(!$ok)echo 'FAILED: '.$name."\n";}
function state050(){global $wpdb;return hash('sha256',serialize([$wpdb->get_results('SELECT bucket,record_key,revision,payload,updated_at,expires_at FROM '.M\Store::table().' ORDER BY bucket,record_key',ARRAY_A),$wpdb->get_results('SELECT * FROM '.M\History::table().' ORDER BY row_key',ARRAY_A),$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%' AND option_name NOT IN ('f3_meta_schema','f3_meta_queue_migration','f3_meta_queue_settled','f3_meta_worker_schedule_attempt') ORDER BY option_name",ARRAY_A)]));}
if(getenv('F3_LAB_ORIGIN')==='upgrade')verify050('upgrade preserves exact stored records, history, options and ciphertext',hash_equals(trim(file_get_contents(getenv('F3_LAB_ROOT').'/baseline-state.sha256')),state050()));
verify050('effective version in a fresh PHP process',M\Config::VERSION===lab_version());
$before=state050();
add_filter('pre_http_request',function($v)use(&$http){$http++;return new WP_Error('unexpected_http','No provider access for metadata');},1);
$labels=M\AbilityLabels::all();$abilities=[];
foreach(wp_get_abilities() as $name=>$a)if(str_starts_with($name,'meta/'))$abilities[$name]=$a;
verify050('35 public ability identifiers (33 preserved + meta/health)',count($abilities)===35&&isset($abilities['meta/health'])&&array_diff(array_map(fn($s)=>'meta/'.$s,array_keys(M\Schemas::all())),array_keys($abilities))===[]);
$base=json_decode(file_get_contents(dirname(__DIR__).'/baseline-input-schemas080.json'),true);
$now090=M\Schemas::all();unset($now090['switch-identity']);
verify050('All 34 previous input schemas remain identical to accepted 0.8.0',$now090===$base);
verify050('meta/health input is a closed empty object',M\Schemas::all()['health']===['type'=>'object','properties'=>[],'required'=>[],'additionalProperties'=>false]);
verify050('35 distinct explicit labels',count(array_unique(array_column($labels,'label')))===35);
foreach($abilities as $name=>$a){$op=substr($name,5);verify050($name.' Portuguese label and description',$a->get_label()===$labels[$op]['label']&&$a->get_description()===$labels[$op]['description']&&!preg_match('/(?<![\w-])'.preg_quote($op,'/').'(?![\w-])/u',$a->get_label())&&str_starts_with($a->get_label(),'Meta: '));}
if(getenv('F3_LAB_ORIGIN')==='upgrade'){
 $base=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline-abilities.json'),true);
 foreach($abilities as $name=>$a){if(in_array($name,['meta/health','meta/audit','meta/documentation'],true))continue;$meta=$a->get_meta();$meta['fator3']['version']='0.6.0';verify050($name.' preserved schema and functional metadata',['input'=>$a->get_input_schema(),'output'=>$a->get_output_schema(),'meta'=>$meta]===$base[$name]);}
}
$index=M\Api::dispatch('documentation',['document'=>'index']);verify050('documentation dispatch permitted for administrator',$index['success']);$documents=[];
foreach($index['data']['documents'] as $d){$offset=0;$text='';$pages=0;do{$i=['document'=>$d['document'],'offset'=>$offset,'limit_bytes'=>257,'expected_revision'=>$d['sha256']];$v=M\Api::dispatch('documentation',$i);if(!$v['success'])throw new RuntimeException('Document failed');$p=$v['data'];$text.=$p['content'];$offset=$p['next_offset'];$pages++;}while($offset!==null);verify050('document '.$d['document'].' complete with stable hash/version',hash('sha256',$text)===$d['sha256']&&strlen($text)===$d['bytes']&&$p['plugin_version']===lab_version());$documents[]=$d+['pages'=>$pages];}
$docLabels=M\Documentation::read(['document'=>'abilities-pt-br.json','limit_bytes'=>65536]);verify050('document labels equal actual registration',json_decode($docLabels['content'],true)===$labels);
verify050('metadata and documentation cause no HTTP or Meta persistence',$http===0&&state050()===$before);
foreach([['document'=>'../wp-config.php'],['document'=>'README.md','offset'=>1],['document'=>'README.md','expected_revision'=>str_repeat('0',64)]] as $i){$res=M\Api::dispatch('documentation',$i);verify050('document confinement/revision '.json_encode($i),!$res['success']);}
$subscriber=wp_create_user('meta050_subscriber',wp_generate_password(),'meta050@example.invalid');(new WP_User($subscriber))->set_role('subscriber');wp_set_current_user($subscriber);
foreach($abilities as $name=>$a)verify050($name.' subscriber denied',is_wp_error($a->check_permissions([]))||$a->check_permissions([])===false);
foreach(['status','list-connections','save-connection','documentation'] as $op){$req=new WP_REST_Request('POST','/f3-meta/v1/'.$op);$req->set_header('Content-Type','application/json');$req->set_body('{}');verify050($op.' REST 403 for subscriber',rest_do_request($req)->get_status()===403);}
wp_set_current_user(1);
if(class_exists('Fator3\\McpFiles\\Admin')){
 $ui=[];
 foreach(['connections','history'] as $tab){$_GET=['page'=>'wp-mcp-fator3','tab'=>$tab];ob_start();\Fator3\McpFiles\Admin::render();$html=ob_get_clean();$dom=new DOMDocument();@$dom->loadHTML('<?xml encoding="UTF-8">'.$html);$xp=new DOMXPath($dom);$found=[];
  foreach($abilities as $name=>$a){$q=$tab==='history'?'//select[@id="f3-filter-ability"]/option[@value="'.$name.'"]':'//label[@data-choice][input[@value="'.$name.'"]]/span';$nodes=$xp->query($q);$text=$nodes->length?trim($nodes->item(0)->textContent):'';$found[$name]=str_contains($text,$a->get_label());}
  verify050('MCP '.$tab.' contains 35 translated choices',count(array_filter($found))===35);$ui[$tab]=['matched'=>count(array_filter($found)),'total'=>35];
 }
 $providers=[];foreach(get_plugins() as $file=>$data)if(is_plugin_active($file))$providers[$file]=$data['Version'];
 $expected070=[];foreach(['wp-mcp-fator3/wp-mcp-fator3.php','base-site-core-fator3/base-site-core-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php','wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php'] as $f)$expected070[$f]=lab_companion($f);
verify050('active companion versions equal the extracted installers',array_intersect_key($providers,$expected070)==$expected070&&!in_array(null,$expected070,true));
}else verify050('Meta clean isolated without companion',count(get_option('active_plugins'))===1);
$result=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'origin'=>getenv('F3_LAB_ORIGIN'),'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'documents'=>$documents,'http_calls'=>$http,'ui'=>$ui??null,'providers'=>$providers??[]];
file_put_contents(getenv('F3_LAB_ROOT').'/evidence/release090-metadata.json',wp_json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));echo json_encode(['total'=>$result['total'],'failed'=>$result['failed']])."\n";if($result['failed'])exit(1);
