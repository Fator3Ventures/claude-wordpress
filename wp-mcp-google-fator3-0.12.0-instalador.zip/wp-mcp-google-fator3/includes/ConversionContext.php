<?php
/** Administrative exposure of the optional local conversion context. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if (!defined('ABSPATH')) { exit; }

final class ConversionContext {
    public static function read(array $input): array {
        // Also protect direct invocation of this callback, outside the registrar.
        return Connections::run((string)($input['connection_id'] ?? Connections::id()), static function () use ($input): array {
            $gate = Gate::check('any');
            if ($gate !== null) { return $gate; }
            $profile = Operation::profile('any', 'read');
            if ($profile !== null) { return Response::fail($profile); }
            unset($input['connection_id']);
            $context = CoreConversions::snapshot($input);
            $data = ['core_conversion_context'=>$context];
            if (!$context['ok']) {
                return Response::fail(new \WP_Error('f3_google_core_conversion_'.$context['code'],
                    'Não foi possível ler o contexto público de conversões: '.$context['code'].'.'), $data);
            }
            return Response::ok($data, 'Configuração local de conversões; acesso e entrega no fornecedor não verificados.');
        });
    }

    public static function register(): void {
        Ability::register('google/conversion-context', 'any', [
            'label'=>'Google: contexto local de conversões',
            'description'=>'Lê contato e material pelo contrato público opcional do Core. Exige administração e canal autorizado; dispensa credencial Google. Não cria recursos nem comprova entrega.',
            'input_schema'=>['properties'=>[
                'expected_revision'=>['type'=>'string', 'pattern'=>'^[a-f0-9]{64}$', 'description'=>'Revisão de conversões esperada; divergência recusa a leitura.'],
            ]],
            'output_schema'=>['type'=>'object', 'properties'=>[
                'success'=>['type'=>'boolean'], 'message'=>['type'=>'string'], 'error_code'=>['type'=>'string'],
                'core_conversion_context'=>CoreConversions::response_schema(),
            ]],
            'callback'=>[self::class, 'read'],
        ]);
    }
}
