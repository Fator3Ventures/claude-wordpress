<?php
/**
 * Due-work service shared by cron, CLI and authenticated agents.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Ability, Connections, Lock, Options, Records, Response, Storage\State, Storage\Repository
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Executor {
    public static function run( array $input = array() ): array {
        return \Fator3\McpGoogle\Recovery::run(static fn()=>self::run_admitted($input));
    }
    private static function run_admitted(array $input): array {
        $admission=Lock::acquire_result('jobs-tick',60);
        if (!$admission['success']) {
            if (CronHistory::busy($admission)) return self::yielded($input);
            return Response::fail(new \WP_Error($admission['code'],'Não foi possível adquirir a admissão do executor.'),['cause_code'=>$admission['cause_code'],'execution_success'=>false,'work_success'=>null,'executed'=>0]);
        }
        try {
            $r=Execution::run(static fn()=>self::run_locked($input,$admission['lock']));
        }
        finally {
            Lock::release($admission['lock']);
        }
        $repair=ExecutorSchedule::ensure('executor');
        $r['executor_repair']=$repair;
        $r['executor_schedule_success']=$repair['success']??false;
        $maintenance=CronHistory::cleanup();
        $r['maintenance']=$maintenance;
        $r['maintenance_success']=$maintenance['success']??null;
        return $r;
    }
    private static function yielded(array $input,?array $frame=null): array {
        $connections=!empty($input['all_connections'])?array_keys(Connections::registry()):[Connections::id()];
        $frame=$frame??CronHistory::begin($connections,'google/executar-vencidos');
        $results=[];
        foreach ($connections as $cid) $results[$cid]=['state'=>'yielded','reason_code'=>'executor_busy','success'=>null,'connection_examined'=>false,'items'=>0,'jobs'=>0,'schedules'=>0,'alerts'=>0];
        $history=CronHistory::finish($frame,$results,'yielded');
        $r=['state'=>'yielded','reason'=>'executor_busy','execution_success'=>true,'work_success'=>null,'connection_examined'=>false,'executed'=>0,'items'=>0,
            'pass'=>['run_id'=>$frame['run_id'],'at'=>$frame['at'],'origem'=>$frame['origem'],'state'=>'yielded','success'=>null,'items'=>0,'connections'=>$connections,'results'=>$history['passes']],
            'observability_error'=>$history['observability_error'],'history_status'=>self::history_status($history['passes'],$connections)];
        return $history['observability_error']?Response::fail(new \WP_Error('f3_google_cron_persistence','Passagem cedida; falha real ao registrar o histórico.'),$r):Response::ok($r);
    }
    private static function history_status(array $passes,array $connections): string {
        if (count($passes)!==count($connections)) return 'unconfirmed';
        $states=array_column($passes,'history_status');
        return in_array('unconfirmed',$states,true)?'unconfirmed':(in_array('pending',$states,true)?'pending':'confirmed');
    }
    private static function run_locked(array $input,array $lock): array {
        $connections = ! empty( $input['all_connections'] ) ? array_keys( Connections::registry() ) : array( Connections::id() );
        $reconciliation_errors=[];
        foreach ($connections as $cid) {
            if (Execution::remaining()<1) break;
            $reconciled=CronHistory::reconcile($cid);
            if (!$reconciled['success'] && !CronHistory::busy($reconciled)) $reconciliation_errors[$cid]=$reconciled;
        }
        $frame = CronHistory::begin( $connections, 'google/executar-vencidos' );
        $results = array();
        foreach ( $connections as $cid ) {
            $results[ $cid ] = array(
                'connection_examined' => false,
                'success' => null,
                'items' => 0,
                'jobs' => 0,
                'schedules' => 0,
                'alerts' => 0,
                'state' => 'not_examined',
            );
        }
        $r = array();
        try {
            $storage_paused = ! $frame['errors'] && (null !== State::guard());
            if ($frame['errors'] && !array_filter($frame['errors'],static fn($e)=>!CronHistory::busy($e))) return self::yielded($input,$frame);
            if ($reconciliation_errors) {
                $r=Response::fail(new \WP_Error('f3_google_cron_persistence','Reconciliação local do histórico não confirmada.'),['reconciliation_errors'=>$reconciliation_errors]);
            }
            elseif ( $frame['errors'] ) {
                $r = Response::fail( new \WP_Error( 'f3_google_cron_persistence', 'Entrada do executor não confirmada.' ) );
            }
            elseif ( $storage_paused ) {
                $r = Response::fail( new \WP_Error( 'f3_google_storage_unavailable', 'A estrutura atual do armazenamento está indisponível.' ) );
            }
            elseif (!Lock::owned($lock)) {
                $r=Response::fail(new \WP_Error('f3_google_lock_lost','Admissão do executor perdida antes do despacho.'));
            }
            else {
                $r = \Fator3\McpGoogle\Recovery::run(
                    static function () use ( $input, $connections, &$results ) {
                    return Execution::run(
                        static function () use ( $input, $connections, &$results ): array {
                        $scheduled = array();
                        $seen = array();
                        $outcomes = array();
                        $errors = array();
                        $count = 0;
                        foreach ( $connections as $cid ) {
                            if ( Execution::remaining() < 1 ) {
                                break;
                            }
                            $results[ $cid ]['connection_examined'] = true;
                            $results[ $cid ]['success'] = true;
                            $one = self::dispatch( array( $cid ) );
                            $scheduled[ $cid ] = $one;
                            $results[ $cid ]['schedules'] = count( $one );
                            foreach ( $one as $id => $sr ) {
                                if ( empty( $sr['success'] ) ) {
                                    $results[ $cid ]['success'] = false;
                                    $errors[ $cid . ':' . $id ] = $sr['error_code'] ?? 'schedule_failed';
                                }
                            }
                        }
                        $budget = max( 1, min( 25, (int) ( $input['max_items'] ?? 25 ) ) );
                        $examined = array_keys( array_filter( $results, static fn( $s )=>$s['connection_examined'] ) );
                        while ( $count < $budget && Execution::remaining() >= 1 && $examined ) {
                            $pending = self::due( $examined );
                            if ( is_wp_error( $pending ) ) {
                                foreach ( $examined as $cid ) {
                                    $results[ $cid ]['success'] = false;
                                }
                                return Response::fail( $pending );
                            }
                            $progress = false;
                            foreach ( $pending as $job ) {
                                if ( $count >= $budget || Execution::remaining() < 1 ) {
                                    break;
                                }
                                $cid = $job['connection'];
                                $w = Connections::run( $cid, static fn()=>Worker::run( $job['id'], 1 ) );
                                ++$results[ $cid ]['jobs'];
                                $seen[ $job['id'] ] = $w['status'] ?? $w['job']['status'] ?? 'unknown';
                                $outcomes[ $job['id'] ] = $w['operation_outcome'] ?? 'unknown';
                                if ( empty( $w['success'] ) || in_array( $seen[ $job['id'] ], array( 'failed', 'unknown', 'blocked' ), true ) ) {
                                    $results[ $cid ]['success'] = false;
                                    $errors[ $job['id'] ] = $w['error_code'] ?? $seen[ $job['id'] ];
                                }
                                if ( ! empty( $w['executed'] ) ) {
                                    ++$count;
                                    ++$results[ $cid ]['items'];
                                    $progress = true;
                                }
                            }
                            if ( ! $progress ) {
                                break;
                            }
                        }
                        foreach ( $examined as $cid ) {
                            if ( Execution::remaining() < 2 ) {
                                break;
                            }
                            $results[ $cid ]['alerts'] = Connections::run( $cid, static fn()=>Alerts::dispatch() );
                        }
                        $reason = Execution::remaining() < 1 ? 'deadline' : ( $count >= $budget ? 'item_budget' : 'no_due_work' );
                        foreach ( $results as &$state ) {
                            $state['state'] = $state['connection_examined'] ? ( false === $state['success'] ? 'failed' : ( $state['items'] ? 'completed' : $reason ) ) : 'budget_not_examined';
                        }
                        unset( $state );
                        $remaining = array();
                        $due = 0;
                        foreach ( $connections as $cid ) {
                            $health = Connections::run( $cid, static fn()=>self::status() );
                            $remaining[ $cid ] = array_intersect_key( $health, array_flip( array( 'jobs', 'agendas_vencidas', 'blocked_schedules', 'read_error' ) ) );
                            $due += (int) $health['agendas_vencidas'];
                        }
                        $data = array(
                            'executed' => $count,
                            'operation_outcome' => \Fator3\McpGoogle\Operation::aggregate( $outcomes ),
                            'job_outcomes' => $outcomes,
                            'jobs' => $seen,
                            'schedules' => $scheduled,
                            'worker_errors' => $errors,
                            'agendas_vencidas' => $due,
                            'work_remaining' => $remaining,
                            'reason' => $reason,
                        );
                        return $errors ? Response::fail( new \WP_Error( 'f3_google_executor_checks', 'A passagem teve trabalhos reprovados.' ), $data ) : Response::ok( $data );
                        }
                    );
                    }
                );
            }
        }
        catch ( \Throwable $e ) {
            $r = Response::fail( new \WP_Error( 'f3_google_executor_exception', 'Executor interrompido por falha local.' ) );
        }
        if ( empty( $r['success'] ) ) {
            foreach ( $results as &$s ) {
                if ( ! $s['connection_examined'] ) {
                    $s['state'] = $r['error_code'] ?? 'failed';
                    $s['reason_code'] = $r['error_code'] ?? 'executor_blocked';
                    $s['success'] = false;
                }
            }
            unset( $s );
        }
        $history = CronHistory::finish( $frame, $results );
        $r['maintenance']=$history['maintenance']??null;
        $r['maintenance_success']=$history['maintenance']['success']??null;
        $pass = array(
            'run_id' => $frame['run_id'],
            'at' => $frame['at'],
            'origem' => $frame['origem'],
            'success' => ! empty( $r['success'] ),
            'items' => (int) ( $r['executed'] ?? 0 ),
            'connections' => $connections,
            'results' => $history['passes'],
        );
        $r['pass'] = $pass;
        $r['execution_success'] = true;
        $r['work_success']=!empty($r['success']);
        $r['history_status']=self::history_status($history['passes'],$connections);
        if ( $history['observability_error'] ) {
            return Response::fail(
                new \WP_Error( 'f3_google_cron_persistence', 'Resultado do trabalho disponível; histórico não confirmado.' ),
                array(
                    'work_result' => $r,
                    'history_status'=>$r['history_status'],
                    'pass' => $pass,
                    'observability_error' => $history['observability_error'],
                    'execution_success' => true,
                    'work_success' => ! empty( $r['success'] ),
                )
            );
        }
        return $r;
    }
    private static function due( array $connections ) {
        $out = array();
        foreach ( $connections as $connection ) {
            $rows = Repository::eligible( 25, $connection );
            if ( is_wp_error( $rows ) ) {
                return $rows;
            }
            foreach ( $rows as $row ) {
                $out[] = array(
                    'id' => $row['record_id'],
                    'connection' => $row['connection_id'],
                    'priority' => (int) $row['priority'],
                    'due' => (int) $row['due_at'],
                );
            }
        }
        $out = array_values( array_filter( $out, static fn ( $job ) => in_array( $job['connection'], $connections, true ) ) );
        usort(
            $out,
            static function ( $a, $b ) {
            $due = $a['due'] <=> $b['due'];
            return 0 !== $due ? $due : ( $b['priority'] <=> $a['priority'] );
            }
        );
        // Interleave connections; each job advances once before any job repeats.
        $groups = array();
        foreach ( $out as $job ) {
            $groups[ $job['connection'] ][] = $job;
        }
        $fair = array();
        while ( $groups ) {
            foreach ( $groups as $connection => &$jobs ) {
                $fair[] = array_shift( $jobs );
                if ( ! $jobs ) {
                    unset( $groups[ $connection ] );
                }
            }
            unset( $jobs );
        }
        return $fair;
    }
    private static function dispatch( array $connections ): array {
        $lock = Lock::acquire( 'schedules', 60 );
        if ( null === $lock ) {
            return array(
                '_executor' => array(
                    'success' => false,
                    'error_code' => 'f3_google_schedules_busy',
                ),
            );
        }
        $out = array();
        try {
            $rows = null;
            $rows = array();
            foreach ( $connections as $connection ) {
                $selected = Repository::select(
                    'schedule',
                    array(
                        'connection_id' => $connection,
                        'state' => 'enabled',
                        'due_before' => time(),
                    ),
                    100,
                    0,
                    false
                );
                if ( is_wp_error( $selected ) ) {
                    return array(
                        '_executor' => array(
                            'success' => false,
                            'error_code' => $selected->get_error_code(),
                        ),
                    );
                }
                $rows = array_merge( $rows, $selected );
            }
            $ids = null !== $rows ? array_column( $rows, 'record_id' ) : Records::ids( 'schedule', 100 );
            foreach ( $ids as $id ) {
                if ( Execution::remaining() < 1 ) {
                    break;
                }
                $schedule = Records::get( 'schedule', $id );
                if ( ! in_array( $schedule['connection_id'], $connections, true ) || empty( $schedule['enabled'] ) || isset( $schedule['blocked_reason'] ) || $schedule['next_run'] > time() ) {
                    continue;
                }
                $actor = get_current_user_id();
                try {
                    wp_set_current_user( (int) $schedule['user_id'] );
                    $created = Connections::run(
                        $schedule['connection_id'],
                        static function () use ( $schedule, $id ): array {
                        if ( ! Options::user_authorized( (int) $schedule['user_id'] ) || ! isset( $schedule['context'] ) ) {
                            return Response::fail( new \WP_Error( 'f3_google_schedule_blocked', 'Agenda exige revisão de autorização/contexto.' ) );
                        }
                        $changed = Context::validate( $schedule['context'] );
                        if ( null !== $changed ) {
                            return Response::fail( $changed );
                        }
                        return Jobs::create(
                            array(
                                'task' => $schedule['task'],
                                'parameters' => $schedule['parameters'],
                                'idempotency_key' => 'schedule:' . $id . ':' . $schedule['next_run'],
                            )
                        );
                        }
                    );
                }
                finally {
                    wp_set_current_user( $actor );
                }
                if ( ! empty( $created['success'] ) ) {
                    $schedule['last_job_id'] = $created['job_id'];
                    $schedule['next_run'] = time() + $schedule['interval_seconds'];
                }
                else {
                    $schedule['status'] = 'blocked';
                    $schedule['blocked_reason'] = $created['error_code'] ?? 'dispatch_failed';
                }
                $saved = Records::put( 'schedule', $id, $schedule );
                $out[ $id ] = $saved['success'] ? $created : $saved;
            }
        }
        finally {
            Lock::release( $lock );
        }
        return $out;
    }
    private static function schedule_observation(array $status): ?array {
        $rows=array_values(array_filter($status['observations'],static fn($r)=>$r['hook']===Jobs::HOOK));
        usort($rows,static fn($a,$b)=>[$b['at'],$b['id']]<=>[$a['at'],$a['id']]);
        return $rows[0]??get_option('f3_mcp_google_cron_schedule',null);
    }
    public static function status(): array {
        $scheduling=Scheduling::status();
        $base = array(
            'requires_trigger' => true,
            'disabled_builtin_trigger' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
            'next_run' => $scheduling['checks']['executor']['next_run'],
            'observed_at' => time(),
            'schedule_observation' => self::schedule_observation($scheduling),
            'scheduling'=>$scheduling,
            'connection_id' => Connections::id(),
            'health'=>'degraded','work_health'=>'unknown',
            'agendas_vencidas' => null,
            'blocked_schedules' => null,
            'oldest_due_at' => null,
            'oldest_delay_seconds' => null,
            'storage' => State::status(),
        );
        $base += CronHistory::summary( Connections::id() );
        try {
            $due = 0;
            $blocked = 0;
            $oldest = null;
            foreach ( array( 'enabled', 'blocked' ) as $state ) {
                $filters = array(
                    'connection_id' => Connections::id(),
                    'state' => $state,
                    'due_before' => time(),
                );
                $n = Repository::count_filtered( 'schedule', $filters );
                if ( is_wp_error( $n ) ) {
                    return $base + array( 'read_error' => $n->get_error_code() );
                }
                $due += $n;
                if ( 'blocked' === $state ) {
                    $blocked = $n;
                }
                $rows = Repository::select( 'schedule', $filters, 10000 );
                if ( is_wp_error( $rows ) ) {
                    return $base + array( 'read_error' => $rows->get_error_code() );
                }
                foreach ( $rows as $row ) {
                    $oldest = null === $oldest ? (int) $row['due_at'] : min( $oldest, (int) $row['due_at'] );
                }
            }
            $counts = array();
            foreach ( array( 'pending', 'approval_required', 'running', 'dispatching', 'blocked', 'unknown', 'failed', 'completed' ) as $state ) {
                $n = Repository::count_filtered(
                    'job',
                    array(
                        'connection_id' => Connections::id(),
                        'state' => $state,
                    )
                );
                if ( is_wp_error( $n ) ) {
                    return $base + array( 'read_error' => $n->get_error_code() );
                }
                $counts[ $state ] = $n;
            }
            $base['jobs'] = $counts;
            $base['execution_in_progress'] = ( $counts['running'] + $counts['dispatching'] ) > 0;
            $base['agendas_vencidas'] = $due;
            $base['blocked_schedules'] = $blocked;
            $base['oldest_due_at'] = $oldest;
            $base['oldest_delay_seconds'] = null === $oldest ? 0 : max( 0, time() - $oldest );
            $base['work_health'] = $due ? ( $blocked === $due ? 'blocked' : 'due' ) : 'idle';
            $base['health']=$scheduling['active_errors']||!$scheduling['read_success']?'degraded':$base['work_health'];
        }
        catch ( \Throwable $e ) {
            $base['read_error'] = 'f3_google_repository_read';
        }
        return $base;
    }
    public static function cleanup( array $input = array() ): array {
        if ( $input['dry_run'] ?? true ) {
            $candidates = array();
            foreach ( array( 'completed', 'failed', 'cancelled', 'reconciled' ) as $state ) {
                $rows = Repository::select(
                    'job',
                    array(
                        'connection_id' => Connections::id(),
                        'state' => $state,
                        'expires_before' => time(),
                    ),
                    100,
                    0,
                    false
                );
                if ( is_wp_error( $rows ) ) {
                    return Response::fail( $rows );
                }
                foreach ( $rows as $row ) {
                    if ( (int) $row['expires_at'] > 0 ) {
                        $candidates[] = array(
                            'job_id' => $row['record_id'],
                            'status' => $row['state'],
                            'expires_at' => (int) $row['expires_at'],
                        );
                    }
                }
            }
            return Response::ok(
                array(
                    'dry_run' => true,
                    'connection_id' => Connections::id(),
                    'job_candidates' => $candidates,
                    'removed_records' => 0,
                    'max_records_per_pass' => 100,
                    'final_eligibility_rechecked' => true,
                    'unknown_and_active_preserved' => true,
                    'auxiliary_cleanup' => 'Expired summaries, deduplication, telemetry, quotas and resolved confirmations are checked during execution.',
                )
            );
        }
        $removed = 0;
        $jobs = 0;
        foreach ( array( 'completed', 'failed', 'cancelled', 'reconciled' ) as $state ) {
            $rows = Repository::select(
                'job',
                array(
                    'connection_id' => Connections::id(),
                    'state' => $state,
                    'expires_before' => time(),
                ),
                100,
                0,
                false
            );
            if ( is_wp_error( $rows ) ) {
                return Response::fail( $rows );
            }
            foreach ( $rows as $row ) {
                if ( $removed >= 100 ) {
                    break 2;
                }
                if ( (int) $row['expires_at'] <= 0 ) {
                    continue;
                }
                $lease = Repository::claim( 'job', $row['record_id'], 60 );
                if ( null === $lease ) {
                    continue;
                }
                try {
                    $job = Records::get( 'job', $row['record_id'] );
                    if ( null === $job || ! in_array( $job['status'], array( 'completed', 'failed', 'cancelled', 'reconciled' ), true ) ) {
                        continue;
                    }
                    $r = Operations::remove_details( $job, 100 - $removed );
                    if ( ! $r['success'] ) {
                        return $r;
                    }
                    $removed += $r['removed_records'];
                    $jobs += ! empty( $r['complete'] ) ? 1 : 0;
                }
                finally {
                    Repository::release( 'job', $row['record_id'], $lease['owner'] );
                }
            }
        }
        foreach ( array( 'summary', 'dedupe', 'telemetry', 'quota', 'confirmation' ) as $kind ) {
            if ( $removed >= 100 ) {
                break;
            }
            $filters = array(
                'connection_id' => Connections::id(),
                'expires_before' => time(),
            );
            $rows = Repository::select( $kind, $filters, 100, 0, false );
            if ( is_wp_error( $rows ) ) {
                return Response::fail( $rows );
            }
            foreach ( $rows as $row ) {
                if ( $removed >= 100 ) {
                    break;
                }
                if ( (int) $row['expires_at'] <= 0 ) {
                    continue;
                }
                $id = $row['record_id'];
                $record = Records::get( $kind, $id );
                if ( null === $record ) {
                    continue;
                }
                if ( in_array( $kind, array( 'summary', 'dedupe' ), true ) && null !== Records::get( 'job', $id ) ) {
                    continue;
                }
                if ( 'summary' === $kind && in_array( $record['status'] ?? '', array( 'unknown', 'failed' ), true ) ) {
                    continue;
                }
                if ( 'confirmation' === $kind ) {
                    if ( 'prepared' !== ( $record['status'] ?? '' ) && ( 'finished' !== ( $record['status'] ?? '' ) || in_array( $record['outcome'] ?? 'unknown', array( 'unknown', 'partial' ), true ) || ( $record['created_at'] ?? time() ) > time() - Options::limit( Options::JOB_SUMMARY_DAYS ) * 86400 ) ) {
                        continue;
                    }
                    $lock = Lock::acquire( 'confirmation:' . $id, 30 );
                    if ( null === $lock ) {
                        continue;
                    }
                    try {
                        $current = Records::get( $kind, $id );
                        if ( $current !== $record ) {
                            continue;
                        }
                        $children_left = false;
                        foreach ( array( 'attempt', 'continuation' ) as $child_kind ) {
                            $children = Repository::select( $child_kind, array( 'id_prefix' => $id . '_' ), max( 1, 101 - $removed ), 0, false );
                            if ( is_wp_error( $children ) ) {
                                return Response::fail( $children );
                            }
                            foreach ( $children as $child ) {
                                if ( $removed >= 100 ) {
                                    $children_left = true;
                                    break;
                                }
                                $deleted = Records::remove( $child_kind, $child['record_id'] );
                                if ( ! $deleted['success'] ) {
                                    return $deleted;
                                }
                                ++$removed;
                            }
                        }
                        if ( $children_left || $removed >= 100 ) {
                            continue;
                        }
                        $r = Records::remove( $kind, $id );
                    }
                    finally {
                        Lock::release( $lock );
                    }
                }
                else {
                    $r = Records::remove( $kind, $id );
                }
                if ( ! $r['success'] ) {
                    return $r;
                }
                ++$removed;
            }
        }
        return Response::ok(
            array(
                'removed_jobs' => $jobs,
                'removed_records' => $removed,
                'max_records' => 100,
                'more_possible' => $removed >= 100,
                'active_deduplication_preserved' => true,
                'unresolved_unknown_preserved' => true,
            )
        );
    }
    public static function register(): void {
        Ability::register(
            'google/executar-vencidos',
            'any',
            array(
                'label' => 'Google: executar tarefas vencidas',
                'description' => 'Executa agendas e tarefas elegíveis sem depender de visita ao site. Por padrão atua somente na conexão selecionada. Mesmo worker, autorização, prazo de 20 s e teto de 25 itens.',
                'mode' => 'write',
                'output_schema'=>['type'=>'object','properties'=>[
                        'state'=>['type'=>'string'],'execution_success'=>['type'=>'boolean'],'work_success'=>['type'=>['boolean','null']],
                        'executed'=>['type'=>'integer'],'history_status'=>['type'=>'string','enum'=>['confirmed','pending','unconfirmed']],
                        'connection_examined'=>['type'=>'boolean'],'observability_error'=>['type'=>['object','null']],
                        'executor_repair'=>['type'=>'object'],'executor_schedule_success'=>['type'=>'boolean'],'work_result'=>['type'=>'object'],'pass'=>['type'=>'object'],'maintenance'=>\Fator3\McpGoogle\Storage\Maintenance::schema()]],
                'input_schema' => array(
                    'properties' => array(
                        'max_items' => array(
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 25,
                        ),
                        'all_connections' => array(
                            'type' => 'boolean',
                            'default' => false,
                            'description' => 'false executa somente a conexão selecionada; true inclui todas as conexões deste site.',
                        ),
                    ),
                ),
                'callback' => array( self::class, 'run' ),
            )
        );
        Ability::register(
            'google/cleanup-jobs',
            'any',
            array(
                'label' => 'Google: limpar histórico vencido',
                'description' => 'Remove detalhes encerrados após retenção; preserva deduplicação e resultados desconhecidos.',
                'mode' => 'write',
                'input_schema' => array(
                    'properties' => array(
                        'dry_run' => array(
                            'type' => 'boolean',
                            'default' => true,
                            'description' => 'true apresenta candidatos sem remover; false executa até 100 remoções com revalidação.',
                        ),
                    ),
                ),
                'callback' => array( self::class, 'cleanup' ),
            )
        );
    }
}
