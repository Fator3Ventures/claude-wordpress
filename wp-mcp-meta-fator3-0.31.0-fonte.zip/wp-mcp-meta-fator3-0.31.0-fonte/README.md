# Fator3 MCP Meta 0.31.0

Pedidos MCP Meta 33 · atualização direta da 0.30.0. A versão isola falhas por métrica, recupera a mesma coleta e repõe dias sem dados. A política de tentativas está em **Suporte → Diagnóstico** e no MCP. Compatível com WordPress 7.1.4+ e PHP 8.3+ de 64 bits.

- `build/meta`, `build/common`, `build/docs/meta`: código e manuais editáveis.
- `plugin/wp-mcp-meta-fator3`: cópia exata do runtime instalado.
- `tests/lab/RODADA-031.md`: reprodução com instalação limpa, migração, cinco acompanhantes e browser.
- `evidence/031`: resultados desta edição; pastas numeradas anteriores guardam o histórico.
- O relatório na raiz contém o roteiro de atualização e de aceite em campo; o relatório externo registra os hashes finais.

Faça o build com `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`. O instalador fica em `build/dist`. Para empacotar o fonte em outra pasta, use `python3 tools/package-source.py /caminho/saida` após preparar a cópia do relatório. Apenas o instalador vai ao WordPress.
