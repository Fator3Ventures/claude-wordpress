<?php
/** Gerado por build/bootstrap-methods.php. Somente registro; handlers carregados no hook correspondente. */
if(!defined('ABSPATH')){exit;}
return [
'F3Base_Admin_Medicao'=>static function():void{

		add_action( 'admin_menu', array( 'F3Base_Admin_Medicao', 'registrar_menu' ) );
		add_action( 'admin_post_f3base_acessos_somar', array( 'F3Base_Admin_Acessos', 'somar' ) );
		add_action( 'admin_enqueue_scripts', array( 'F3Base_Admin_Medicao', 'enfileirar' ) );
	
},
'F3Base_Admin_Saude'=>static function():void{

		add_action( 'admin_post_' . 'f3base_operar', array( 'F3Base_Admin_Saude', 'operar' ) ); 
},
'F3Base_Admin_Tela'=>static function():void{

		add_action( 'admin_menu', array( 'F3Base_Admin_Tela', 'registrar_menu' ) );
		add_action( 'admin_post_' . 'f3base_salvar', array( 'F3Base_Admin_Tela', 'salvar' ) );
		add_action( 'admin_enqueue_scripts', array( 'F3Base_Admin_Tela', 'enfileirar' ) );add_action('wp_ajax_f3base_form_renovar',array(F3Base_Admin_Entrada::class,'renovar'));
		add_action( 'admin_enqueue_scripts', static function (): void { if ( ( $_GET['page'] ?? '' ) === 'base-site-core-fator3' ) { wp_enqueue_script( 'f3base-admin1120', F3BASE_PLUGIN_URL . 'admin/assets/f3base-admin1120.js', array(), F3BASE_PLUGIN_VERSAO, true ); } } );
		add_filter( 'plugin_action_links_' . plugin_basename( F3BASE_PLUGIN_ARQUIVO ), array( 'F3Base_Admin_Tela', 'links_de_acao' ) );
	
},
'F3Base_Agentes'=>static function():void{

        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('agentes-relatorio','Agentes e buscadores: requisições, conteúdo e frequência',array('F3Base_Agentes','consultar'),F3Base_Agentes::schema());});
        add_action('admin_post_f3base_agentes_csv',array('F3Base_Agentes','csv'));
    
},
'F3Base_Analise'=>static function():void{

        add_action('rest_api_init',static function(){register_rest_route(F3BASE_REST_NAMESPACE,'/analise',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array('F3Base_Analise','receber_seguro')));});
        add_action('wp_enqueue_scripts',array('F3Base_Analise','enfileirar'),30);
        add_filter('render_block',array('F3Base_Analise','inspecionar_recursos'),30);
        add_filter('the_content',array('F3Base_Analise','inspecionar_recursos'),30);
        add_action('f3base_leads_resumo',array('F3Base_Analise','reter'));
    
},
'F3Base_Anuncios'=>static function():void{

        add_action('rest_api_init',static function(){register_rest_route('f3base/v1','/anuncios/google',array('methods'=>'POST','callback'=>array('F3Base_Anuncios','google'),'permission_callback'=>'__return_true'));});
        add_action('f3base_anuncios_consultar',array('F3Base_Anuncios','consultar'));add_action('f3base_leads_resumo',array('F3Base_Anuncios','limpar'));
        add_action('f3base_zelador',array('F3Base_Anuncios','conferir_agenda_1'),91);
        add_action('updated_option',array('F3Base_Anuncios','mudou'),31,3);add_action('added_option',static fn($n,$v)=>F3Base_Anuncios::mudou($n,null,$v),31,2);
        F3Base_Bootstrap::iniciar('F3Base_Linkedin');F3Base_Bootstrap::iniciar('F3Base_Anuncios_Catalogo');F3Base_Bootstrap::iniciar('F3Base_Captacao_Operacao');add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('anuncios-verificar','Estado das origens, cadência e recuperação, sem consultar a rede',array('F3Base_Anuncios','diagnostico'));
            F3Base_Servicos::ability('anuncios-consultar-agora','Consulta limitada à origem Meta autorizada; pode importar contatos',static fn($e)=>!empty($e['simular'])?array('ok'=>true,'persisted'=>false,'simular'=>true,'diagnostico'=>F3Base_Anuncios::diagnostico()):F3Base_Anuncios::consultar(),array('simular'=>array('type'=>'boolean','default'=>true)),array('simular'),false);
            F3Base_Servicos::ability('anuncios-google-reconciliar','Ingerir lote Google autorizado; não executa GAQL',array('F3Base_Anuncios','reconciliar'),array('simular'=>array('type'=>'boolean'),'revisao'=>array('type'=>'string'),'conta_id'=>array('type'=>'string'),'de'=>array('type'=>'integer'),'ate'=>array('type'=>'integer'),'cursor'=>array('type'=>'string','maxLength'=>200),'ultimo_lote'=>array('type'=>'boolean'),'equivalencia_ids_confirmada'=>array('type'=>'boolean'),'executor'=>array('type'=>'string','maxLength'=>100),'itens'=>array('type'=>'array','maxItems'=>100,'items'=>array('type'=>'object','additionalProperties'=>true))),array('simular','revisao','conta_id','de','ate','cursor','ultimo_lote','equivalencia_ids_confirmada','executor','itens'),false);
        });
    
},
'F3Base_Anuncios_Catalogo'=>static function():void{

        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('contato-marcar-teste','Marcar contato como teste, preservando trilha e cancelando pendências',array('F3Base_Anuncios_Catalogo','marcar_teste'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'revisao'=>array('type'=>'integer'),'motivo'=>array('type'=>'string','maxLength'=>500),'simular'=>array('type'=>'boolean','default'=>true)),array('record_id'),false));
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('anuncios-contato-reavaliar','Reavaliar papéis e elegibilidade local sem reenviar entregas confirmadas',array('F3Base_Anuncios_Catalogo','reavaliar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'revisao'=>array('type'=>'integer'),'simular'=>array('type'=>'boolean','default'=>true)),array('record_id'),false));
    
},
'F3Base_Anuncios_Selecao'=>static function():void{
add_action('wp_ajax_f3base_anuncios_catalogo',static function(){check_ajax_referer('f3base-anuncios-catalogo');$e=wp_unslash($_POST);$source=sanitize_key($e['origem']??'');if($source==='f3base_anuncios_linkedin'){$r=F3Base_Linkedin_Integracoes::executar(sanitize_key($e['integracao_id']??''),static fn()=>F3Base_Anuncios_Selecao::consultar($e));}else{$r=F3Base_Anuncios_Selecao::consultar($e);}wp_send_json($r);});
},
'F3Base_Artigos'=>static function():void{

        add_action('init',static function(){
            wp_register_script('f3base-artigos-editor',F3BASE_PLUGIN_URL.'assets/f3base-artigos-editor.js',array('wp-blocks','wp-element','wp-block-editor','wp-components','wp-server-side-render'),F3BASE_PLUGIN_VERSAO,true);
            register_block_type('f3base/artigo-indice',array('api_version'=>3,'editor_script'=>'f3base-artigos-editor','attributes'=>array('titulo'=>array('type'=>'string','default'=>'Neste artigo'),'aberto'=>array('type'=>'boolean','default'=>true)),'render_callback'=>array('F3Base_Artigos','indice')));
            register_block_type('f3base/artigo-compartilhar',array('api_version'=>3,'editor_script'=>'f3base-artigos-editor','render_callback'=>array('F3Base_Artigos','compartilhar')));
        });
        add_filter('the_content',array('F3Base_Artigos','marcar'),12);
        add_filter('script_loader_tag',static function($html,$handle){if(!str_starts_with($handle,'f3base')){return $html;}if(class_exists('WP_HTML_Tag_Processor')){$p=new WP_HTML_Tag_Processor($html);while($p->next_tag('SCRIPT')){$p->set_attribute('data-no-optimize','1');}return $p->get_updated_html();}return $html;},20,2);
        add_filter('wp_inline_script_attributes',static function($attrs){if(str_starts_with((string)($attrs['id']??''),'f3base')){$attrs['data-no-optimize']='1';}return $attrs;});
    
},
'F3Base_Ativos_Publicos'=>static function():void{

        add_action('updated_option',array('F3Base_Ativos_Publicos','alterada'),300,3);
        add_action('added_option',static function($n,$v){F3Base_Ativos_Publicos::alterada($n,null,$v);},300,2);
        add_action('shutdown',array('F3Base_Ativos_Publicos','publicar'),5);
        add_action('f3base_zelador',array('F3Base_Ativos_Publicos','recuperar'),3);
        add_action('f3base_zelador',array('F3Base_Ativos_Publicos','podar'),4);
        add_action('wp_head',array('F3Base_Ativos_Publicos','bootstrap'),2);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('ativos-publicos-ler','Estado da configuração e dos módulos públicos pré-gerados',array('F3Base_Ativos_Publicos','ler'));});
    
},
'F3Base_Autoria'=>static function():void{

        add_filter('the_author',static fn($name)=>F3Base_Autoria::proteger((int)get_the_ID())?F3Base_Autoria::publico()['name']:$name);
        add_filter('get_the_author_display_name',static fn($name,$id)=>F3Base_Autoria::proteger((int)get_the_ID(),(int)$id)?F3Base_Autoria::publico()['name']:$name,10,2);
        add_filter('author_link',static fn($url,$id)=>F3Base_Autoria::proteger((int)get_the_ID(),(int)$id)?(F3Base_Autoria::publico()['url']??home_url('/')):$url,10,2);
        add_filter('oembed_response_data',static function($data,$post){if(F3Base_Autoria::proteger((int)$post->ID)){$data['author_name']=F3Base_Autoria::publico()['name'];$data['author_url']=F3Base_Autoria::publico()['url']??home_url('/');}return $data;},10,2);
        add_filter('redirect_canonical',static function($url){$id=(int)get_query_var('author');return $id&&F3Base_Autoria::proteger(0,$id)?home_url('/'):$url;});
    
},
'F3Base_Avisos'=>static function():void{

        add_action('f3base_lead_persistido',array('F3Base_Avisos','capturado'));
        add_action('f3base_lead_eliminando',static fn($id)=>F3Base_Avisos::cancelar($id));
        add_action('f3base_avisos_processar',array('F3Base_Avisos','executar'));
        add_action('f3base_zelador',array('F3Base_Avisos','recuperar_agenda'),PHP_INT_MAX-3);add_action('f3base_leads_resumo',array('F3Base_Avisos','recuperar'));
        add_action('f3base_retencao_limpeza',array('F3Base_Avisos','podar'));
        add_action('admin_post_f3base_avisos_salvar',array('F3Base_Avisos','salvar'));
        add_action('admin_post_f3base_avisos_reenviar',array('F3Base_Avisos','reenviar_tela'));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('avisos-fila-ler','Avisos externos e contingência por e-mail, sem payload nem segredo',array('F3Base_Avisos','consultar'),array('pagina'=>array('type'=>'integer','minimum'=>1),'estado'=>array('type'=>'string','enum'=>array (
  0 => 'pendente',
  1 => 'reservado',
  2 => 'enviando',
  3 => 'entregue',
  4 => 'falhou',
  5 => 'incerto',
  6 => 'cancelado',
  7 => 'suprimido',
  8 => 'suspenso',
)),'record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'teste'=>array('type'=>'boolean'),'origem'=>array('type'=>'string','enum'=>array('contato','teste_conexao'))));
            F3Base_Servicos::ability('avisos-reenviar','Prévia e reenvio explícito de aviso externo; incerto exige aceite de duplicação',array('F3Base_Avisos','reenviar'),array('chave'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true),'aceitar_possivel_duplicacao'=>array('type'=>'boolean'),'usar_destino_atual'=>array('type'=>'boolean')),array('chave'),false);
        });
    
},
'F3Base_Cache_Orcamento'=>static function():void{
add_action('f3base_retencao_limpeza',array('F3Base_Cache_Orcamento','limpar'));
},
'F3Base_Cache_Reaquecimento'=>static function():void{

  add_action('f3base_cache_reaquecer',array('F3Base_Cache_Reaquecimento','processar'));
  add_action('f3base_zelador',array('F3Base_Cache_Reaquecimento','conferir_agenda_1'),60);
  add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('cache-reaquecimento-ler','Ler configuração e resultados do reaquecimento, sem executar requisições',array('F3Base_Cache_Reaquecimento','consultar'),array()));
 
},
'F3Base_Caminho_Lead'=>static function():void{

        add_action('f3base_zelador',array('F3Base_Caminho_Lead','recuperar_agenda'),96);
        add_action('f3base_caminho_lead_processar',array('F3Base_Caminho_Lead','processar'),10,1);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('caminho-lead-testar','Teste sob demanda com prévia, revisão e recibo; nenhum envio de conversão e nenhuma repetição incerta',array('F3Base_Caminho_Lead','testar'),F3Base_Caminho_Lead::schema_entrada(),array('formulario'),false);F3Base_Servicos::ability('caminho-lead-limpar','Retoma somente limpeza autorizada de IDs conhecidos, com prévia e revisão; não repete efeitos incertos',array('F3Base_Caminho_Lead','limpar'),F3Base_Caminho_Lead::schema_limpeza(),array('id'),false);F3Base_Servicos::ability('caminho-lead-recibo-ler','Resultado dos saltos e limpezas do teste, sem campos pessoais',array('F3Base_Caminho_Lead','ler'),array('id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$')),array('id'));});
    
},
'F3Base_Campanhas_Origem'=>static function():void{
add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('campanhas-origem-simular','Simular fontes de conta e nome da campanha usando somente o acervo local concedido, sem gravar contato nem enviar ao CRM',array('F3Base_Campanhas_Origem','simular'),array('parametros'=>array('type'=>'object','additionalProperties'=>true),'configuracao'=>F3Base_Campanhas_Origem::schema()),array('parametros'),true,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));});
},
'F3Base_Canais_Organicos'=>static function():void{
add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('canais-organicos-simular','Simular regras e catálogo IA candidatos, ou contatos dos últimos 30 dias, sem gravar nem chamar o CRM',array('F3Base_Canais_Organicos','simular'),array('parametros'=>array('type'=>'object','additionalProperties'=>true),'regras'=>F3Base_Canais_Organicos::schema(),'catalogo_ia'=>F3Base_Canais_Organicos::schema_ia(),'contatos_30_dias'=>array('type'=>'boolean'),'pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>10000)));});
},
'F3Base_Captacao_Operacao'=>static function():void{

        add_action('f3base_zelador',array('F3Base_Captacao_Operacao','conferir_agenda_1'),96);
        add_action('f3base_captacao_monitorar',static function(){F3Base_Recuperacao::executar(static function(){F3Base_Captacao_Operacao::reavaliar();F3Base_Captacao_Operacao::acompanhar();F3Base_Fila::agendar('f3base_captacao_monitorar',time()+300);});});
    
},
'F3Base_Captura_Contexto'=>static function():void{

        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/contexto-diagnostico',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array('F3Base_Captura_Contexto','diagnostico_publico'))));
        add_action('f3base_leads_resumo',array('F3Base_Captura_Contexto','limpar_diagnostico'));
        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/leads/contexto',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array('F3Base_Captura_Contexto','finalizar'))));
    
},
'F3Base_Clarity'=>static function():void{

        add_action('admin_post_f3base_clarity_testar',array(F3Base_Admin_Clarity::class,'enviar'));
        add_action('f3base_clarity_retomar',array('F3Base_Clarity','cron'));
        add_action('f3base_zelador',array('F3Base_Clarity','agendar'),45);add_action('f3base_clarity_coletar',array('F3Base_Clarity','cron'));add_action('wp_abilities_api_init',array('F3Base_Clarity','registrar'));
        add_action('updated_option',array('F3Base_Clarity','alteracao'),20,3);add_action('added_option',static function($n,$v){F3Base_Clarity::alteracao($n,null,$v);},20,2);
        add_action('admin_post_f3base_clarity_csv',array('F3Base_Clarity','csv'));
    
},
'F3Base_Config_UI'=>static function():void{
F3Base_Bootstrap::iniciar('F3Base_Anuncios_Selecao');add_action('admin_post_f3base_config_central',array('F3Base_Config_UI','salvar_central'));add_action('admin_menu',array('F3Base_Config_UI','menu'),1200);
        add_action('admin_enqueue_scripts',static function(){if(!str_contains((string)($_GET['page']??''),'f3base')&&($_GET['page']??'')!=='base-site-core-fator3'){return;}wp_enqueue_style('f3base-config143',F3BASE_PLUGIN_URL.'admin/assets/f3base-config143.css',array(),F3BASE_PLUGIN_VERSAO);wp_enqueue_script('f3base-config143',F3BASE_PLUGIN_URL.'admin/assets/f3base-config143.js',array(),F3BASE_PLUGIN_VERSAO,true);});
    
},
'F3Base_Configuracao_Atual'=>static function():void{

        add_action('wp_abilities_api_init', array('F3Base_Configuracao_Atual', 'abilities'));
        add_action('f3base_leads_resumo', array(F3Base_Resposta_Visitante::class, 'processar_pendentes'));
        F3Base_Bootstrap::iniciar('F3Base_Publicidade');
        F3Base_Bootstrap::iniciar('F3Base_Evolucao');
        F3Base_Bootstrap::iniciar('F3Base_Politica');
        F3Base_Bootstrap::iniciar('F3Base_Analise');
        F3Base_Bootstrap::iniciar('F3Base_Relatorios');
        F3Base_Bootstrap::iniciar('F3Base_Configuracao_Medicao');
    
},
'F3Base_Configuracao_Medicao'=>static function():void{

        foreach(array('added_option','updated_option') as $hook){add_action($hook,static function($n){if(is_string($n)&&isset(F3Base_Configuracao_Medicao::avisos()[$n])){F3Base_Configuracao_Medicao::reavaliar_avisos();}},220,1);}
        add_action('admin_post_f3base_aviso_dispensar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-aviso-dispensar');F3Base_Configuracao_Medicao::dispensar_aviso(array('nome'=>sanitize_key($_POST['nome']??'')));wp_safe_redirect(wp_get_referer()?:admin_url('admin.php?page=base-site-core-fator3&aba=tecnica'));exit;});
        F3Base_Bootstrap::iniciar('F3Base_Tracking_Diagnostico');F3Base_Bootstrap::iniciar('F3Base_Sessao_Contexto');F3Base_Bootstrap::iniciar('F3Base_Canais_Organicos');
        F3Base_Bootstrap::iniciar('F3Base_Confirmacao');F3Base_Bootstrap::iniciar('F3Base_Clarity');F3Base_Bootstrap::iniciar('F3Base_Meta_Transporte');F3Base_Bootstrap::iniciar('F3Base_Ofertas_Medicao');
        F3Base_Bootstrap::iniciar('F3Base_Medicao_Editorial_UI');F3Base_Bootstrap::iniciar('F3Base_Editorial');F3Base_Bootstrap::iniciar('F3Base_Inteligencia');F3Base_Bootstrap::iniciar('F3Base_Redes_Robos');
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('configuracao-aviso-dispensar','Dispensar um aviso de configuração ativo',array('F3Base_Configuracao_Medicao','dispensar_aviso'),array('nome'=>array('type'=>'string')),array('nome'),false);
            F3Base_Servicos::ability('acessos-legado-ler','Consultar agregados arquivados fora dos totais atuais',array(F3Base_Acessos_Legado::class,'consultar'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>10000)));
            F3Base_Servicos::ability('medicao-saude-ler','Diagnóstico da coleta e lacunas observadas',array(F3Base_Medicao_Saude::class,'consultar'));
            F3Base_Servicos::ability('llms-reprocessar','Reprocessar manualmente a geração editorial',static fn()=>F3Base_Llms_Cobertura::executar(5,true),array(),array(),false);
            foreach(array('conteudos-relatorio'=>'conteudo','sessoes-listar'=>'sessoes','sessao-detalhar'=>'sessao','aquisicao-relatorio'=>'aquisicao') as $nome=>$visao){$schema=F3Base_Editorial_Relatorios::schema();unset($schema['visao']);F3Base_Servicos::ability($nome,'Medição editorial: '.$visao,static fn($e)=>F3Base_Editorial_Relatorios::consultar(array_merge($e,array('visao'=>$visao))),$schema,$visao==='sessao'?array('sessao'):array());}
            F3Base_Servicos::ability('medicao-editorial','Conteúdo, aquisição e sessões observadas',array(F3Base_Editorial_Relatorios::class,'consultar'),F3Base_Editorial_Relatorios::schema());
        });
    
},
'F3Base_Configuracoes_Hub'=>static function():void{
 F3Base_Bootstrap::iniciar('F3Base_Config_UI');
        add_action('init',static function(){
            if(is_admin()&&($_GET['page']??'')==='f3base-integracoes'&&($_SERVER['REQUEST_METHOD']??'GET')==='GET'&&current_user_can('manage_options')){
                $args=array_intersect_key(wp_unslash($_GET),array_flip(array('integracao','pagina','estado')));
                wp_safe_redirect(add_query_arg($args,F3Base_Configuracoes_Hub::url('conexoes')));exit;
            }
        });
        add_action('admin_menu',static function(){remove_submenu_page('f3base-leads','f3base-integracoes');},1000);
    
},
'F3Base_Confirmacao'=>static function():void{
add_action('template_redirect',array('F3Base_Confirmacao','pagina'),-999);
},
'F3Base_Contatos_Externos'=>static function():void{

        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('contato-externo-registrar','Registrar contato externo cifrado; simula por padrão, sem avisos, e-mail ou conversões',array('F3Base_Contatos_Externos','registrar'),F3Base_Contatos_Externos::propriedades(),array('idempotency_key','metodo','nome','primeiro_contato_em'),false,'manage_options',array('F3Base_Contatos_Externos','pode'));
            F3Base_Contatos_Sessoes::registrar_ability();
        });
    
},
'F3Base_Conteudo_Instrumentacao'=>static function():void{
add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('conteudo-instrumentacao-ler','Auditoria de seções, CTAs e formulários do conteúdo publicado',array('F3Base_Conteudo_Instrumentacao','consultar'),array('pagina'=>array('type'=>'integer','minimum'=>1),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>5),'tipo'=>array('type'=>'string','enum'=>array('page','post')),'post_id'=>array('type'=>'integer','minimum'=>1),'url'=>array('type'=>'string','format'=>'uri'))));
},
'F3Base_Conteudo_Privado'=>static function():void{

		add_action( 'admin_post_f3base_conteudo', array( 'F3Base_Conteudo_Privado', 'download' ) );
		add_action( 'admin_post_nopriv_f3base_conteudo', array( 'F3Base_Conteudo_Privado', 'download' ) );
	
},
'F3Base_Conversoes_Fila'=>static function():void{

		add_action(
			'wp_abilities_api_init',
			static function (): void {
				$destino = array( 'type' => 'string', 'enum' => array (
  0 => 'ga4',
  1 => 'google_ads',
  2 => 'linkedin',
) );
				F3Base_Servicos::ability(
					'conversoes-fila-ler',
					'Resumo da fila de conversões pelo servidor por destino, estado e motivo; sem dados pessoais e sem consultar fornecedores',
					array( 'F3Base_Conversoes_Fila', 'ler' ),
					array(
						'dias'    => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 90, 'default' => 30 ),
						'destino' => $destino,
						'amostra' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 20, 'default' => 5 ),
					)
				);
				F3Base_Servicos::ability(
					'conversoes-bloqueadas-reavaliar',
					'Simular ou antecipar a reavaliação de conversões bloqueadas de um destino; o envio continua no worker com todas as guardas',
					array( 'F3Base_Conversoes_Fila', 'reavaliar' ),
					array(
						'destino'   => $destino,
						'codigo'    => array( 'type' => 'string', 'pattern' => '^[a-z][a-z0-9_]{0,79}$' ),
						'limite'    => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500, 'default' => 100 ),
						'confirmar' => array( 'type' => 'boolean', 'default' => false ),
					),
					array( 'destino' ),
					false
				);
			}
		);
	
},
'F3Base_Conversoes_Servidor'=>static function():void{

        add_action('f3base_lead_persistido',array('F3Base_Conversoes_Servidor','capturar'));
        add_action('f3base_conversoes_servidor',array('F3Base_Conversoes_Servidor','processar'));
        add_action('f3base_zelador',array('F3Base_Conversoes_Servidor','conferir_agenda_1'),98);
        add_action('f3base_lead_eliminando',static function($id){global $wpdb;$wpdb->update(F3Base_Conversoes_Servidor::tabela(),array('estado'=>'cancelado','codigo'=>'registro_eliminado'),array('record_id'=>$id));});
        add_action('wp_abilities_api_init',static function(){
            $id=array('type'=>'string','pattern'=>'^[a-f0-9]{32}$');
            F3Base_Servicos::ability('linkedin-conversao-previa','Prévia privada de conversão LinkedIn de um registro, inclusive de teste; não enfileira nem envia',array(F3Base_Linkedin_Conversoes::class,'previa'),array('record_id'=>$id),array('record_id'));
            F3Base_Servicos::ability('conversoes-entregas-ler','Estado privado de conversões por registro; não consulta fornecedores',array('F3Base_Conversoes_Servidor','ler'),array('record_id'=>$id),array('record_id'));
            F3Base_Servicos::ability('conversoes-recuperar','Simular ou agendar conversões perdidas sem repetir entregas ou resultados incertos',array('F3Base_Conversoes_Servidor','recuperar'),array('record_id'=>$id,'confirmar'=>array('type'=>'boolean','default'=>false),'vincular_destinos'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('ga4'=>array('type'=>'string','minLength'=>1,'maxLength'=>191),'google_ads'=>array('type'=>'string','minLength'=>1,'maxLength'=>191),'linkedin'=>array('type'=>'string','minLength'=>1,'maxLength'=>191))),'nao_entregues_confirmados'=>array('type'=>'array','uniqueItems'=>true,'items'=>array('type'=>'string','enum'=>array('ga4','google_ads','linkedin','meta')))),array('record_id'),false);
        });
    
},
'F3Base_Credenciais'=>static function():void{

        add_action('updated_option',array('F3Base_Credenciais','registrar'),5,3);add_action('added_option',static fn($n,$v)=>F3Base_Credenciais::registrar($n,null,$v),5,2);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('credenciais-ler','Identidades e ajuda das credenciais; nunca retorna valores secretos',array('F3Base_Credenciais','ler'),array('nome'=>array('type'=>'string','enum'=>array (
  0 => 'f3base_email_site_senha',
  1 => 'f3base_email_novo_lead_smtp_senha',
  2 => 'f3base_meta_crm_token',
  3 => 'f3base_pipedrive_webhook_segredo',
  4 => 'f3base_slack_bot_token',
  5 => 'f3base_avisos_webhook_url',
  6 => 'f3base_avisos_webhook_chave',
  7 => 'f3base_slack_webhook',
  8 => 'f3base_clarity_api_token',
  9 => 'f3base_meta_capi_token',
  10 => 'f3base_pipedrive_token',
  11 => 'f3base_anuncios_meta_token',
  12 => 'f3base_anuncios_google_chave',
  13 => 'f3base_anuncios_linkedin_token',
  14 => 'f3base_anuncios_linkedin_client_secret',
))));F3Base_Servicos::ability('credenciais-verificar','Verificar candidata sem gravar; mudança de identidade requer confirmação',array('F3Base_Credenciais','previa'),array('nome'=>array('type'=>'string','enum'=>array (
  0 => 'f3base_email_site_senha',
  1 => 'f3base_email_novo_lead_smtp_senha',
  2 => 'f3base_meta_crm_token',
  3 => 'f3base_pipedrive_webhook_segredo',
  4 => 'f3base_slack_bot_token',
  5 => 'f3base_avisos_webhook_url',
  6 => 'f3base_avisos_webhook_chave',
  7 => 'f3base_slack_webhook',
  8 => 'f3base_clarity_api_token',
  9 => 'f3base_meta_capi_token',
  10 => 'f3base_pipedrive_token',
  11 => 'f3base_anuncios_meta_token',
  12 => 'f3base_anuncios_google_chave',
  13 => 'f3base_anuncios_linkedin_token',
  14 => 'f3base_anuncios_linkedin_client_secret',
)),'credential'=>array('type'=>'string','maxLength'=>8192),'revisao_esperada'=>array('type'=>'string'),'confirmacao'=>array('type'=>'string','maxLength'=>100),'usar_salva'=>array('type'=>'boolean','default'=>false)),array('nome','revisao_esperada'),false);});
        add_action('wp_ajax_f3base_credenciais_previa',array('F3Base_Credenciais','ajax'));
    
},
'F3Base_Cta_Inventario'=>static function():void{
add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('ctas-inventariar','Inspeciona lote de conteúdo salvo para CTAs com destino inválido, sem HTTP ou renderização',array('F3Base_Cta_Inventario','consultar'),array('apos_id'=>array('type'=>'integer','minimum'=>0),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>50)));});
},
'F3Base_Email_Alerta'=>static function():void{

        add_action('f3base_zelador',array('F3Base_Email_Alerta','conferir_agenda_1'),92);
        add_action('f3base_email_site_saude',static function(){try{F3Base_Email_Alerta::observar();F3Base_Email_Site::continuacoes();}finally{F3Base_Fila::agendar('f3base_email_site_saude',time()+300);}});
    
},
'F3Base_Email_Historico'=>static function():void{

        add_filter('f3base_options_catalogo',static function($c){$props=['ativo'=>['type'=>'boolean'],'janela_horas'=>['type'=>'integer','minimum'=>1,'maximum'=>720],'intervalo_minutos'=>['type'=>'integer','minimum'=>5,'maximum'=>1440]];$c['f3base_email_historico']=F3Base_Conversas::catalogo_grupo('f3base_email_historico','Conferência de e-mail no Pipedrive',F3Base_Email_Historico::padroes(),$props,static fn($v)=>'');$c['f3base_email_historico']['descricao']='Message-ID individual, remetente, destinatário, pessoa e lead. Política fotografada antes do SMTP; mensagens antigas sem prova ficam não conferidas.';return $c;});
        add_filter('cron_schedules',static function($s){$s['f3base_email_historico_5m']=['interval'=>300,'display'=>'Conferência de e-mail a cada cinco minutos'];return $s;});add_action('f3base_email_historico_conferir',['F3Base_Email_Historico','processar']);add_action('f3base_zelador',array('F3Base_Email_Historico','conferir_agenda_1'),125);
    
},
'F3Base_Email_Limpeza'=>static function():void{

        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('email-legado-limpar','Simular ou eliminar resíduos do e-mail antigo após conferir a configuração corrente',array('F3Base_Email_Limpeza','executar'),array('simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$')),array(),false);});
    
},
'F3Base_Email_Novo_Lead'=>static function():void{

        add_action('f3base_email_novo_lead_processar',array('F3Base_Email_Novo_Lead','processar'));
        add_action('f3base_zelador',array('F3Base_Email_Novo_Lead','conferir_agenda_1'),98);
        add_action('f3base_lead_eliminando',array('F3Base_Email_Novo_Lead','cancelar'));
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('email-novo-lead-homologar','Autoriza uma única intenção e-mail automático ao novo lead de teste por até uma hora; caixa deve constar na lista de caixas autorizadas deste site',array('F3Base_Email_Novo_Lead','homologar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'confirmar'=>array('type'=>'boolean')),array('record_id','confirmar'),false);F3Base_Servicos::ability('email-novo-lead-ler','Estado privado do e-mail e-mail automático ao novo lead; sem corpo ou credenciais',array('F3Base_Email_Novo_Lead','ler'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$')),array('record_id'));});
    
},
'F3Base_Email_Novo_Lead_UI'=>static function():void{
add_action('admin_post_f3base_email_teste',array('F3Base_Email_Novo_Lead_UI','teste'));add_action('admin_post_f3base_credencial_complementar',array('F3Base_Email_Novo_Lead_UI','salvar'));
},
'F3Base_Email_Site'=>static function():void{

        add_action('updated_option',array(F3Base_Email_Site_Config::class,'mudou'),40,3);add_action('added_option',static fn($n,$v)=>F3Base_Email_Site_Config::mudou($n,null,$v),40,2);
        add_action('f3base_zelador',array('F3Base_Email_Site','conferir_agenda_1'),91);
        add_action('f3base_email_site_consultar',array('F3Base_Email_Site','cron'));
        add_action('f3base_retencao_limpeza',array('F3Base_Email_Site','podar_pendentes'),20,0);
        add_filter('wp_privacy_personal_data_exporters',static function($list){$list['f3base-email-pendente']=array('exporter_friendly_name'=>'E-mails pendentes de autenticação','callback'=>array('F3Base_Email_Site','exportar_pendentes'));return $list;});
        add_filter('wp_privacy_personal_data_erasers',static function($list){$list['f3base-email-pendente']=array('eraser_friendly_name'=>'E-mails pendentes de autenticação','callback'=>array('F3Base_Email_Site','apagar_pendentes'));return $list;});
        add_action('wp_abilities_api_init',static function(){
            $sim=array('type'=>'boolean','default'=>true);$rev=array('type'=>'string','pattern'=>'^[a-f0-9]{64}$');$uid=array('type'=>'integer','minimum'=>1,'maximum'=>4294967295);$record=array('type'=>'string','pattern'=>'^[a-f0-9]{32}$');
            F3Base_Servicos::ability('email-caixa-verificar','Verificar IMAP/TLS e pastas; simulação padrão, aplicação cria pastas ausentes sem importar ou mover',array('F3Base_Email_Site','verificar'),array('simular'=>$sim),array(),false);
            F3Base_Servicos::ability('email-caixa-consultar','Consultar caixa; simulação padrão sem gravar ou mover',array('F3Base_Email_Site','consultar'),array('simular'=>$sim,'revisao'=>$rev,'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>10)),array(),false,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));
            F3Base_Servicos::ability('email-registros-ler','Ler mensagens cifradas, descartes e resultados por contato',array('F3Base_Email_Site','ler'),array('record_id'=>$record,'pagina'=>array('type'=>'integer','minimum'=>1),'classe'=>array('type'=>'string','enum'=>array('aceito','suspeito','descartado'))),array(),true,'f3base_ler_leads',static fn()=>current_user_can('f3base_ler_leads'));
            F3Base_Servicos::ability('email-reprocessar','Reexaminar UID da INBOX; histórico exige opção explícita e revisão',array('F3Base_Email_Site','reprocessar'),array('uid'=>$uid,'uidvalidity'=>$uid,'importar_historico'=>array('type'=>'boolean','default'=>false),'simular'=>$sim,'revisao'=>$rev),array('uid','uidvalidity'),false,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));
            F3Base_Servicos::ability('email-enviar','Prévia ou envio SMTP a contato deste site, revisão obrigatória no envio',array(F3Base_Email_Envio::class,'executar'),array('record_id'=>$record,'assunto'=>array('type'=>'string','minLength'=>1,'maxLength'=>500),'texto'=>array('type'=>'string','minLength'=>1,'maxLength'=>20000),'simular'=>$sim,'revisao'=>$rev),array('record_id','assunto','texto'),false,'f3base_enviar_email',static fn()=>current_user_can('f3base_enviar_email')&&current_user_can('f3base_ler_leads'));
        });
    
},
'F3Base_Email_Wordpress'=>static function():void{

        add_filter('auto_plugin_update_send_email',array('F3Base_Email_Wordpress','plugins'),20,2);
        add_filter('auto_theme_update_send_email',array('F3Base_Email_Wordpress','temas'),20,2);
        add_filter('auto_core_update_send_email',array('F3Base_Email_Wordpress','nucleo'),20,2);
        add_filter('auto_core_update_email',array('F3Base_Email_Wordpress','email_nucleo'),20,2);
        add_filter('recovery_mode_email',array('F3Base_Email_Wordpress','recuperacao'),20);
        add_filter('pre_wp_mail',array('F3Base_Email_Wordpress','suprimir'),PHP_INT_MIN,2);
    
},
'F3Base_Esquema'=>static function():void{

        add_filter('query',array('F3Base_Esquema','consulta'),PHP_INT_MIN);
        add_action('shutdown',array('F3Base_Esquema','observar'),1);
        add_action('shutdown',array('F3Base_Esquema','registrar_falhas'),2);
        add_action('f3base_esquema_reparar',array('F3Base_Esquema','reparar'));
    
},
'F3Base_Estado_Inventario'=>static function():void{
add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('estado-inventario-ler','Inventário fechado de estado, propriedade, backup, retenção e desinstalação',array('F3Base_Estado_Inventario','consultar')));
},
'F3Base_Evolucao'=>static function():void{

        F3Base_Bootstrap::iniciar('F3Base_Testes');
        F3Base_Bootstrap::iniciar('F3Base_Ofertas');
        F3Base_Bootstrap::iniciar('F3Base_Interface');
        F3Base_Bootstrap::iniciar('F3Base_Protecao');
        F3Base_Bootstrap::iniciar('F3Base_Servidor');
        add_action('f3base_acessos_somar',array(F3Base_Acessos_Repeticao::class,'limpar'),1);
        add_action('wp_enqueue_scripts',array(F3Base_Atribuicao::class,'enfileirar'),5);
    
},
'F3Base_Formulario_Antispam'=>static function():void{
add_action('admin_post_f3base_sinais_salvar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-sinais');$values=array();$current=F3Base_Options::ler('f3base_formularios_sinais');foreach(array_keys($current) as $name){$values[$name]=array('suspeito'=>isset($_POST['sinais'][$name]['suspeito']),'aviso'=>isset($_POST['sinais'][$name]['aviso']),'spam'=>isset($_POST['sinais'][$name]['spam']));}$r=F3Base_Options::pelo_canal('admin',static fn()=>F3Base_Options::gravar('f3base_formularios_sinais',$values,'edicao-manual',sanitize_text_field($_POST['revisao']??'')));set_transient('f3base_integracao_resultado_'.get_current_user_id(),$r,300);wp_safe_redirect(F3Base_Configuracoes_Hub::url('conexoes','avisos'));exit;});
},
'F3Base_Formulario_Complementos'=>static function():void{

        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('contato-complemento-reconciliar','Reagendar somente uma atualização após conferir o destino; não repete a captura inicial',array('F3Base_Formulario_Complementos','reconciliar'),array('chave'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'destino'=>array('type'=>'string','enum'=>array('email','slack','crm')),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'confirmar'=>array('type'=>'boolean'),'aceitar_duplicacao'=>array('type'=>'boolean')),array('chave','destino'),false));
        add_action('f3base_complementos_processar',array('F3Base_Formulario_Complementos','processar'));
        add_action('f3base_lead_eliminando',array('F3Base_Formulario_Complementos','eliminar'));
        add_action('f3base_leads_resumo',static function(){global $wpdb;$n=$wpdb->get_var($wpdb->prepare("SELECT MIN(proxima) FROM %i WHERE estado IN ('pendente','enviando')",F3Base_Formulario_Complementos::tabela()));if($n!==null){F3Base_Fila::agendar('f3base_complementos_processar',max(time()+1,(int)$n));}});
    
},
'F3Base_Formulario_Tentativas'=>static function():void{

        add_action('rest_api_init',static function(){register_rest_route(F3BASE_REST_NAMESPACE,'/formularios/tentativas',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>static function(WP_REST_Request $req){if($req->get_header('origin')&&!F3Base_Testes::origem_propria($req->get_header('origin'))){return F3Base_Formularios::resposta(array('ok'=>false,'codigo'=>'origem_invalida'),403);}if(strlen($req->get_body())>65536){return F3Base_Formularios::resposta(array('ok'=>false,'codigo'=>'corpo_excedido'),413);}$input=$req->get_json_params();$r=is_array($input)?F3Base_Formulario_Tentativas::receber($input):array('ok'=>false,'codigo'=>'tentativa_invalida');return F3Base_Formularios::resposta($r,$r['http']??($r['ok']?200:400));}));});
        add_action('f3base_retencao_limpeza',array('F3Base_Formulario_Tentativas','limpar'));add_action('f3base_retencao_limpeza',array('F3Base_Formulario_Antispam','limpar'));
        add_action('f3base_leads_resumo',array('F3Base_Formulario_Tentativas','limpar'));
        add_filter('wp_privacy_personal_data_erasers',static function($a){$a['f3base-formulario-tentativas']=array('eraser_friendly_name'=>'Tentativas barradas nos formulários Core','callback'=>array('F3Base_Formulario_Tentativas','apagar_titular'));return $a;});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::registrar_ability('f3base/formularios-tentativas-ler',array('label'=>'Ler tentativas barradas dos formulários','description'=>'Leitura privada de campo, estado, regra e valor digitado, por sessão e instância. Valores somente com f3base_ler_leads; retenção própria e sem repasse a integrações.','category'=>F3BASE_PREFIXO,'input_schema'=>array('type'=>'object','additionalProperties'=>false,'properties'=>F3Base_Formulario_Tentativas::filtros()),'output_schema'=>F3Base_Formulario_Tentativas::schema_saida(),'permission_callback'=>static fn()=>current_user_can('f3base_ler_leads'),'execute_callback'=>array('F3Base_Formulario_Tentativas','consultar'),'meta'=>array('mcp'=>array('public'=>true),'annotations'=>array('readonly'=>true,'idempotent'=>true,'destructive'=>false))));});
    
},
'F3Base_Formularios'=>static function():void{


		add_action( 'init', array( 'F3Base_Formularios', 'registrar' ) );
		add_action( 'rest_api_init', array( 'F3Base_Formularios', 'rotas' ) );
		add_action( 'admin_post_f3base_formulario', array( 'F3Base_Formularios', 'post' ) );
		add_action( 'admin_post_nopriv_f3base_formulario', array( 'F3Base_Formularios', 'post' ) );
		add_action( 'admin_post_f3base_confirmacao', array( 'F3Base_Formularios', 'confirmacao' ) );
		add_action( 'admin_post_nopriv_f3base_confirmacao', array( 'F3Base_Formularios', 'confirmacao' ) );
	
},
'F3Base_Ga4'=>static function():void{

        add_filter('f3base_options_catalogo',static function($c){$d=F3Base_Conversas::catalogo_grupo('f3base_ga4_acervo','Acervo GA4 — coleta diária e retroativa',F3Base_Ga4::defaults(),F3Base_Ga4::props(),array('F3Base_Ga4','validar'));$d['descricao']='Métricas GA4 no banco local, sem prazo por padrão. Exige concessão no MCP Google. Fuso deve corresponder à propriedade. Não ativa conversões.';$d['secao']='medicao-ga4';$d['subcampos']=array('revisitar_dias'=>array('tipo'=>'inteiro','rotulo'=>'Dias recentes para reconciliação','minimo'=>1,'maximo'=>90),'limite_pagina'=>array('tipo'=>'inteiro','rotulo'=>'Linhas por página','minimo'=>1,'maximo'=>1000),'ativo'=>array('tipo'=>'booleano','rotulo'=>'Habilitar coleta'),'propriedade'=>array('tipo'=>'texto','rotulo'=>'Propriedade (properties/123)'),'inicio'=>array('tipo'=>'texto','rotulo'=>'Coletar desde (AAAA-MM-DD; vazio: últimos 30 dias)'),'horario'=>array('tipo'=>'texto','rotulo'=>'Horário no fuso da propriedade'),'fuso'=>array('tipo'=>'texto','rotulo'=>'Fuso da propriedade GA4'),'recortes'=>array('tipo'=>'multiescolha','rotulo'=>'Recortes','opcoes'=>array('resumo'=>'Resumo','paginas'=>'Páginas','aquisicao'=>'Origem, mídia e campanha','dispositivos'=>'Dispositivos','paises'=>'Países','cidades'=>'Países e cidades','eventos'=>'Eventos e eventos-chave')));$c['f3base_ga4_acervo']=$d;$c['f3base_ga4_estado']=array('rotulo'=>'Estado da coleta GA4','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;});
        add_action('f3base_zelador',array('F3Base_Ga4','agendar'),121);add_action('f3base_ga4_coletar',array('F3Base_Ga4','coletar'));add_action('f3base_ga4_continuar',array('F3Base_Ga4','coletar'));add_action('wp_abilities_api_init',array('F3Base_Ga4','registrar'));
        add_action('updated_option',array('F3Base_Ga4','mudou'),211,3);
        add_action('f3base_retencao_limpeza',array(F3Base_Ga4_Acervo::class,'limpar'),99);
    
},
'F3Base_Google_Acervo'=>static function():void{

        add_filter('f3base_options_catalogo',static function($c){$c['f3base_google_ads_acervo']=F3Base_Conversas::catalogo_grupo('f3base_google_ads_acervo','Google Ads — acervo local',F3Base_Google_Acervo::padroes(),F3Base_Google_Acervo::props(),['F3Base_Google_Acervo','validar']);$c['f3base_google_ads_acervo']['secao']='integracoes';$c['f3base_google_ads_acervo']['descricao']='Seleciona conta e conexão do leitor. Autorize a coleta e o leitor no MCP Google; nenhuma concessão é automática.';return $c;});
        add_action('f3base_zelador',array('F3Base_Google_Acervo','conferir_agenda_1'),125);add_action('f3base_google_cliques',['F3Base_Google_Acervo','enriquecer']);
        add_action('wp_abilities_api_init',['F3Base_Google_Acervo','registrar']);
    
},
'F3Base_Google_Conversoes'=>static function():void{

        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('google-conversao-previa','Prévia privada com hashes e motivos, inclusive para contato de teste; sem enfileirar ou enviar',array('F3Base_Google_Conversoes','previa'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$')),array('record_id'));});
    
},
'F3Base_Gsc'=>static function():void{

        add_action('f3base_zelador',array('F3Base_Gsc','agendar'),120);add_action('f3base_gsc_coletar',array('F3Base_Gsc','coletar'));add_action('f3base_gsc_continuar',array('F3Base_Gsc','coletar'));add_action('wp_abilities_api_init',array('F3Base_Gsc','registrar'));
        add_action('updated_option',static function($name){if(in_array($name,array('f3base_gsc_property','f3base_gsc','timezone_string','gmt_offset'),true)){F3Base_Gsc::invalidar_curso('configuracao_alterada');F3Base_Options::atualizar_estado('f3base_gsc_estado',static fn($s)=>array_merge($s,array('proxima_tentativa'=>0)));wp_clear_scheduled_hook('f3base_gsc_coletar');F3Base_Gsc::agendar();}},210,1);
    
},
'F3Base_Gsc_Consultas'=>static function():void{

        add_action('f3base_zelador',array('F3Base_Gsc_Consultas','agendar'),120);add_action('f3base_gsc_consultas_coletar',array('F3Base_Gsc_Consultas','coletar'));add_action('f3base_gsc_consultas_continuar',array('F3Base_Gsc_Consultas','coletar'));add_action('wp_abilities_api_init',array('F3Base_Gsc_Consultas','registrar'));
        add_action('updated_option',static function($name){if(in_array($name,array('f3base_gsc_property','f3base_gsc_consultas','timezone_string','gmt_offset'),true)){F3Base_Gsc_Consultas::invalidar_curso('configuracao_alterada');F3Base_Options::atualizar_estado('f3base_gsc_consultas_estado',static fn($s)=>array_merge($s,array('proxima_tentativa'=>0)));wp_clear_scheduled_hook('f3base_gsc_consultas_coletar');F3Base_Gsc_Consultas::agendar();}},210,1);
    
},
'F3Base_Integracoes'=>static function():void{

        F3Base_Bootstrap::iniciar('F3Base_Credenciais');
        add_action('admin_menu',static fn()=>add_submenu_page('f3base-leads','Integrações','Integrações','manage_options','f3base-integracoes',array('F3Base_Integracoes','render')),20);
        add_action('admin_post_f3base_integracoes_salvar',array('F3Base_Integracoes','salvar'));add_action('admin_post_f3base_pipedrive_reenviar',array('F3Base_Integracoes','reagendar'));add_action('admin_post_f3base_integracoes_verificar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-integracoes-verificar');$r=F3Base_Integracoes::verificar();set_transient('f3base_integracao_resultado_'.get_current_user_id(),array('ok'=>!empty($r['ok']),'codigo'=>$r['codigo']??'','motivo'=>F3Base_Pipedrive_Alertas::motivo($r['codigo']??'').' Próxima tentativa: '.(!empty($r['proxima_tentativa'])?wp_date('d/m/Y H:i:s T',$r['proxima_tentativa']):'rotina diária')),300);wp_safe_redirect(admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=f3base_pipedrive'));exit;});
        add_action('updated_option',array('F3Base_Integracoes','mudou'),30,3);add_action('added_option',static fn($n,$v)=>F3Base_Integracoes::mudou($n,null,$v),30,2);
        add_action('f3base_integracoes_verificar',static fn()=>F3Base_Integracoes::verificar(true));add_action('f3base_integracoes_reverificar',static fn()=>F3Base_Integracoes::verificar(true));
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('pipedrive-avisos-ler','Avisos incertos, esgotados ou sem destinatários',array(F3Base_Pipedrive_Alertas::class,'consultar'),array('estado'=>array('type'=>'string','enum'=>array('incerto','esgotado','sem_destinatarios')),'pagina'=>array('type'=>'integer','minimum'=>1)));F3Base_Servicos::ability('pipedrive-verificar','Estado de verificação da conta, sem efeito',array('F3Base_Integracoes','diagnostico'));F3Base_Servicos::ability('integracoes-verificar-agora','Verifica acesso remoto e atualiza catálogos, sem criar contatos',static fn()=>F3Base_Integracoes::verificar(false),array(),array(),false);F3Base_Servicos::ability('integracoes-ler','Consultar estado, filas e configuração de integrações sem efeitos',array('F3Base_Integracoes','diagnostico'));F3Base_Servicos::ability('pipedrive-processar','Executar lote limitado da fila Pipedrive',array(F3Base_Pipedrive_Fila::class,'processar'),array(),array(),false);F3Base_Servicos::ability('pipedrive-previa','Prévia privada dos dados elegíveis, sem envio externo',static function($e){$lead=F3Base_Leads_Repositorio::obter($e['record_id']);return $lead?array('ok'=>true,'previa'=>F3Base_Pipedrive_Configuracao::previa($lead)):array('ok'=>false,'codigo'=>'registro_ausente');},array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$')),array('record_id'));});
        add_action('f3base_zelador',array('F3Base_Integracoes','conferir_agenda_1'),91);
        F3Base_Bootstrap::iniciar('F3Base_Pipedrive_Fila');F3Base_Bootstrap::iniciar('F3Base_Pipedrive_Eliminacao');F3Base_Bootstrap::iniciar('F3Base_Anuncios');
    
},
'F3Base_Inteligencia'=>static function():void{

        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('ia-referencias-ler','Referências observadas com origem e evidência',array('F3Base_Inteligencia','referencias'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'post_id'=>array('type'=>'integer','minimum'=>0),'provedor'=>array('type'=>'string'),'origem'=>array('type'=>'string'),'pagina'=>array('type'=>'integer','minimum'=>1)));
            F3Base_Servicos::ability('ia-referencia-gravar','Criar ou revisar referência observada, sem consultar a URL da evidência',array('F3Base_Inteligencia','referencia_gravar'),F3Base_Inteligencia::schema_referencia(),array('chave','provedor','observado_em','tipo','url','evidencia','evidencia_tipo','origem','revisao_estado'),false);
            F3Base_Servicos::ability('ia-referencia-excluir','Excluir referência observada pela revisão',array('F3Base_Inteligencia','referencia_excluir'),array('id'=>array('type'=>'integer','minimum'=>1),'revisao'=>array('type'=>'integer','minimum'=>1)),array('id','revisao'),false);
            F3Base_Servicos::ability('medicao-anotacao-gravar','Anotar dias de testes e excluir explicitamente de análises',array('F3Base_Inteligencia','anotar'),array('chave'=>array('type'=>'string','maxLength'=>128),'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'motivo'=>array('type'=>'string','maxLength'=>500),'excluir'=>array('type'=>'boolean'),'revisao'=>array('type'=>'integer','minimum'=>1)),array('chave','de','ate','motivo','excluir'),false);
            F3Base_Servicos::ability('medicao-anotacao-excluir','Excluir anotação pela revisão, preservando auditoria',array('F3Base_Inteligencia','anotacao_excluir'),array('id'=>array('type'=>'integer','minimum'=>1),'revisao'=>array('type'=>'integer','minimum'=>1)),array('id','revisao'),false);
            F3Base_Servicos::ability('gsc-importar','Importar fotografia autorizada page/date ou total de propriedade',array('F3Base_Inteligencia','gsc_importar'),F3Base_Inteligencia::schema_gsc(),array('propriedade','pesquisa','escopo','dimensoes','estado','extraido_em','fonte','cobertura','filtros','linhas'),false);
        });
        add_action('admin_post_f3base_inteligencia_gravar',array('F3Base_Inteligencia','admin_gravar'));
    
},
'F3Base_Interface'=>static function():void{

        add_action('admin_post_f3base_medicao_csv',array(F3Base_Medicao_Interface::class,'csv'));
        add_action('admin_enqueue_scripts',static function(){if(in_array($_GET['page']??'',array('base-site-core-fator3','f3base-formularios','f3base-leads','f3base-medicao','f3base-relatorios'),true)){wp_enqueue_style('f3base-interface',F3BASE_PLUGIN_URL.'admin/assets/f3base-interface.css',array(),F3BASE_PLUGIN_VERSAO);}});
        add_action('admin_enqueue_scripts',static function(){if(($_GET['page']??'')==='base-site-core-fator3'){wp_enqueue_script('f3base-config-ui',F3BASE_PLUGIN_URL.'admin/assets/f3base-config-ui.js',array(),F3BASE_PLUGIN_VERSAO,true);}});
        add_action('admin_menu',static function(){global $submenu;foreach($submenu['base-site-core-fator3']??array() as $item){if(is_string($item[0]??null)&&preg_match('/leads?\s*\(conting[eê]ncia\)/iu',wp_strip_all_tags($item[0]))){remove_submenu_page('base-site-core-fator3',$item[2]);}}},999);
    
},
'F3Base_Leads_Admin'=>static function():void{

		add_action( 'admin_menu', array( 'F3Base_Leads_Admin', 'menu' ), 9 );
        add_action('admin_init',array('F3Base_Leads_Admin','salvar_formulario_prg'));
		add_action( 'wp_abilities_api_init', array( 'F3Base_Leads_Admin', 'abilities' ) );
		add_action( 'admin_post_f3base_exportar_registro', array( 'F3Base_Leads_Admin', 'exportar_zip' ) );
		add_action( 'admin_post_f3base_anexo', array( 'F3Base_Leads_Admin', 'anexo' ) );
        add_action('admin_enqueue_scripts',static function(){if(str_starts_with((string)($_GET['page']??''),'f3base-')){wp_enqueue_style('f3base-contatos',F3BASE_PLUGIN_URL.'assets/f3base-contatos.css',array(),F3BASE_PLUGIN_VERSAO);}});
		add_action( 'admin_post_f3base_csv', array( 'F3Base_Leads_Admin', 'csv' ) );
		add_filter(
			'wp_privacy_personal_data_exporters',
			static function ( $a ) {
				$a['f3base-contatos-proprios'] = array(
					'exporter_friendly_name' => 'Contatos Core',
					'callback'               => array( 'F3Base_Leads_Admin', 'exportar' ),
				);
				return $a;
			}
		);
		add_filter(
			'wp_privacy_personal_data_erasers',
			static function ( $a ) {
				$a['f3base-contatos-proprios'] = array(
					'eraser_friendly_name' => 'Contatos Core',
					'callback'             => array( 'F3Base_Leads_Admin', 'apagar' ),
				);
				return $a;
			}
		);
		add_action( 'f3base_leads_resumo', array( 'F3Base_Leads_Admin', 'reter' ) );
		add_action(
			'admin_init',
			static function (): void {
				$role = get_role( 'administrator' );
				if ( $role ) {
					foreach ( array( 'f3base_ler_leads', 'f3base_gerir_leads', 'f3base_gerir_formularios', 'f3base_exportar_leads', 'f3base_baixar_anexos' ) as $c ) {
						if ( ! $role->has_cap( $c ) ) {
								$role->add_cap( $c );
						}
					}
				} }
		);
		add_action(
			'enqueue_block_editor_assets',
			static function (): void {
				wp_enqueue_script( 'f3base-formulario-bloco', F3BASE_PLUGIN_URL . 'assets/f3base-formulario-bloco.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor' ), F3BASE_PLUGIN_VERSAO, true );
			}
		);
	
},
'F3Base_Leads_Notificacoes'=>static function():void{

		add_action('f3base_leads_avisos',array('F3Base_Leads_Notificacoes','lote'));
        add_action( 'f3base_leads_resumo', array( 'F3Base_Leads_Notificacoes', 'resumo' ) );
		add_action('f3base_zelador',array('F3Base_Leads_Notificacoes','conferir_agenda_1'),
			50
		);
	
},
'F3Base_Linkedin'=>static function():void{

        add_action('updated_option',array('F3Base_Linkedin','mudou'),32,3);add_action('added_option',static fn($n,$v)=>F3Base_Linkedin::mudou($n,null,$v),32,2);add_action('f3base_linkedin_consultar',static fn()=>F3Base_Linkedin_Integracoes::todas('consultar'));
        add_action('f3base_zelador',array('F3Base_Linkedin','conferir_agenda_1'),91);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('anuncios-linkedin-acesso-verificar','Conferir token e formulários LinkedIn sem ler respostas pessoais',static fn($e)=>F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static fn()=>F3Base_Linkedin::verificar($e)),array('integracao_id'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array(),false);F3Base_Servicos::ability('anuncios-linkedin-consultar','Importar uma página de respostas LinkedIn autorizadas',static fn($e)=>F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static fn()=>($e['simular']??true)!==false?array('ok'=>true,'simular'=>true,'diagnostico'=>F3Base_Linkedin::diagnostico()):F3Base_Linkedin::consultar()),array('integracao_id'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array(),false);});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('anuncios-linkedin-cliente-alterar','Prévia e troca explícita por integração LinkedIn',array(F3Base_Linkedin_Transicao::class,'executar'),array('integracao_id'=>array('type'=>'string'),'cliente'=>array('type'=>'string','enum'=>array('core','linkedin_plugin')),'connection_id'=>array('type'=>'string'),'conta_id'=>array('type'=>'string'),'formularios'=>array('type'=>'array','items'=>array('type'=>'string')),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'chave_operacao'=>array('type'=>'string')),array('integracao_id','cliente','connection_id'),false);});
        F3Base_Bootstrap::iniciar('F3Base_Linkedin_Webhook');F3Base_Bootstrap::iniciar('F3Base_Linkedin_Admin');
    
},
'F3Base_Linkedin_Admin'=>static function():void{
add_action('admin_post_f3base_linkedin',array('F3Base_Linkedin_Admin','post'));
},
'F3Base_Linkedin_Webhook'=>static function():void{

        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/anuncios/linkedin/notificacoes',array('methods'=>array('GET','POST'),'permission_callback'=>'__return_true','callback'=>array('F3Base_Linkedin_Webhook','receber'))));
        add_action('f3base_linkedin_notificacoes',static fn()=>F3Base_Linkedin_Webhook::todas('processar'));add_action('f3base_linkedin_assinaturas',static fn()=>F3Base_Linkedin_Webhook::todas('manutencao'));add_action('f3base_zelador',array('F3Base_Linkedin_Webhook','conferir_agenda_1'),92);
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('anuncios-linkedin-webhook-configurar','Gerenciar assinaturas próprias LinkedIn; consulta e simulação por padrão',static fn($e)=>F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static fn()=>F3Base_Linkedin_Webhook::configurar($e)),array('integracao_id'=>array('type'=>'string'),'acao'=>array('type'=>'string','enum'=>array('consultar','ativar','desativar','reconciliar')),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'chave_operacao'=>array('type'=>'string','maxLength'=>128)),array(),false));
    
},
'F3Base_Llms_Arquivo'=>static function():void{

		add_action( 'f3base_llms_regenerar', static fn()=>F3Base_Llms_Cobertura::executar(5) );
		add_action( 'wp_loaded', array( 'F3Base_Llms_Arquivo', 'visita' ), 30 );
		add_action( 'save_post', array( 'F3Base_Llms_Arquivo', 'post' ), 99, 2 );
		add_action( 'before_delete_post', array( 'F3Base_Llms_Arquivo', 'revogar' ) );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( 'F3Base_Llms_Arquivo', 'meta' ), 99, 4 ); }
		add_action( 'updated_option', array( 'F3Base_Llms_Arquivo', 'opcao' ), 99, 3 );
		add_action(
			'added_option',
			static function ( $n, $v ): void {
				F3Base_Llms_Arquivo::opcao( $n, null, $v );
			},
			99,
			2
		);
		add_action(
			'deleted_option',
			static function ( $n ): void {
				F3Base_Llms_Arquivo::opcao( $n, null, null );
			},
			99
		);
		foreach ( array( 'wpseo_saved_postdata', 'wpseo_saved_indexable', 'set_object_terms', 'edited_term', 'delete_term' ) as $hook ) {
            add_action($hook, static function():void { $c=F3Base_Options::ler('f3base_llms'); $atuais=F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache($c); $ids=array_column($atuais,'id'); $g=(array)get_option('f3base_llms_geracao_publicada',array()); $retirado=false; foreach($g['itens']??array() as $i){if(!in_array($i['id']??0,$ids,true)){$retirado=true;break;}} F3Base_Llms_Arquivo::alterar($retirado); },99);
        }
        add_action('switch_theme',array('F3Base_Llms_Arquivo','revogar'),99);
	
},
'F3Base_Llms_Cobertura'=>static function():void{

        add_action('f3base_llms_converter_lote',F3Base_Operacao::callback('f3base_llms_converter_lote',static fn()=>F3Base_Llms_Cobertura::executar(5)));
        F3Base_Bootstrap::iniciar('F3Base_Llms_Mapa');
    
},
'F3Base_Llms_Mapa'=>static function():void{

        add_action('save_post',array('F3Base_Llms_Mapa','invalidar'),1);
        add_action('transition_post_status',array('F3Base_Llms_Mapa','transicao'),1,3);
        add_action('wpseo_saved_postdata',array('F3Base_Llms_Mapa','invalidar'),1);
        foreach(array('added_post_meta','updated_post_meta','deleted_post_meta') as $h){add_action($h,array('F3Base_Llms_Mapa','meta'),1,4);}
        add_action('before_delete_post',array('F3Base_Llms_Mapa','invalidar'),1);
        add_action('updated_option',array('F3Base_Llms_Mapa','opcao'),1,3);
    
},
'F3Base_Marcas'=>static function():void{

        add_action('f3base_marcas_inspecionar',static function(){try{return F3Base_Marcas::processar();}finally{if(F3Base_Options::ler('f3base_marcas_vigiadas')){F3Base_Fila::agendar('f3base_marcas_inspecionar',time()+300);}}});
        add_action('f3base_zelador',array('F3Base_Marcas','conferir_agenda_1'),96);
        add_action('save_post',static function($id,$p){if(in_array($p->post_type,array('page','post'),true)&&F3Base_Options::ler('f3base_marcas_vigiadas')){F3Base_Options::atualizar_estado('f3base_marcas_inspecao',static function($s){$s['revisao']='';return $s;});F3Base_Fila::agendar('f3base_marcas_inspecionar',time()+60);}},10,2);
    
},
'F3Base_Medicao_Editorial_UI'=>static function():void{
add_action('admin_post_f3base_editorial_csv',array('F3Base_Medicao_Editorial_UI','csv'));add_action('admin_enqueue_scripts',static function(){if(($_GET['page']??'')==='f3base-medicao'){wp_enqueue_style('f3base-medicao-editorial',F3BASE_PLUGIN_URL.'assets/f3base-medicao-editorial.css',array(),F3BASE_PLUGIN_VERSAO);wp_enqueue_script('f3base-medicao-editorial',F3BASE_PLUGIN_URL.'assets/f3base-medicao-editorial.js',array(),F3BASE_PLUGIN_VERSAO,true);}});
},
'F3Base_Meta_Acesso'=>static function():void{

        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('anuncios-meta-acesso-verificar','Verificar acesso Meta sem ativar importação; repetir para continuar catálogo',array('F3Base_Meta_Acesso','verificar'),array('revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array('revisao'),false));
        add_action('admin_post_f3base_meta_acesso',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-meta-acesso');F3Base_Meta_Acesso::verificar(array('simular'=>false,'revisao'=>sanitize_text_field($_POST['revisao']??'')));wp_safe_redirect(admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=f3base_anuncios_meta'));exit;});
    
},
'F3Base_Meta_Ads'=>static function():void{

        add_filter('f3base_options_catalogo',static function($c){$d=F3Base_Conversas::catalogo_grupo('f3base_meta_ads','Meta Ads — campanhas e parceiros',F3Base_Meta_Ads::padroes(),F3Base_Meta_Ads::props(),array('F3Base_Meta_Ads','validar_alteracao'));$d['descricao']='Lê o acervo local do MCP Meta, com concessão explícita por conexão/conta. IDs de campanha identificam o parceiro; nomes são apenas rótulos. Não cria coleta nem concede acesso automaticamente.';$d['secao']='integracoes';$c['f3base_meta_ads']=$d;return $c;});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('meta-ads-status','Estado da concessão local Meta Ads e seleção do consumidor Core, sem Graph',array('F3Base_Meta_Ads','status'));F3Base_Servicos::ability('meta-ads-relatorio-ler','Histórico diário por campanha e relação com contatos e parceiros; cursor consistente, moedas e cobertura preservadas',array('F3Base_Meta_Ads','consultar'),F3Base_Meta_Ads::schema(),array('de','ate'),true,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));});
    
},
'F3Base_Meta_Monitoramento'=>static function():void{

        add_filter('f3base_options_catalogo',static function($c){$c['f3base_meta_monitoramento']=F3Base_Conversas::catalogo_grupo('f3base_meta_monitoramento','Meta — alterações e recebimento de eventos',F3Base_Meta_Monitoramento::padroes(),F3Base_Meta_Monitoramento::props(),['F3Base_Meta_Monitoramento','validar']);$c['f3base_meta_monitoramento']['secao']='integracoes';$c['f3base_meta_monitoramento_estado']=['rotulo'=>'Recibos de incidentes Meta','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>[],'autoload'=>false,'sanitiza'=>[F3Base_Servicos::class,'identidade']];return $c;});
        add_action('f3base_zelador',array('F3Base_Meta_Monitoramento','conferir_agenda_1'),125);add_action('f3base_meta_monitorar',['F3Base_Meta_Monitoramento','monitorar']);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('meta-monitoramento-status','Estado da concessão de monitoramento Meta',['F3Base_Meta_Monitoramento','status']);F3Base_Servicos::ability('meta-monitoramento-ler','Histórico local de alterações, contagens e EMQ, com paginação',['F3Base_Meta_Monitoramento','ler'],F3Base_Meta_Monitoramento::schema(),['de','ate','report']);$s=F3Base_Meta_Monitoramento::schema();unset($s['report'],$s['dataset_id']);$s['plataforma']=['type'=>'string','enum'=>['google_ads','meta_ads']];$s['conta_id']=['type'=>'string','pattern'=>'^[0-9]{1,40}$'];F3Base_Servicos::ability('anuncios-alteracoes-ler','Alterações por conta, dia, entidade e campo; autoria exige dados pessoais',['F3Base_Meta_Monitoramento','alteracoes'],$s,['de','ate','plataforma']);});
    
},
'F3Base_Meta_Transporte'=>static function():void{

        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/meta-eventos',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array('F3Base_Meta_Transporte','receber'))));
        add_action('wp_enqueue_scripts',array('F3Base_Meta_Transporte','enfileirar'),31);
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('meta-entregas-ler','Eventos Meta por rota e dia; evidência local separada da plataforma',array('F3Base_Meta_Transporte','relatorio'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'modo'=>array('type'=>'string','enum'=>array('resumo','eventos')),'pagina'=>array('type'=>'integer','minimum'=>1)));
            F3Base_Servicos::ability('meta-homologacao-registrar','Registrar evidência externa para avaliar elegibilidade do modo servidor',array('F3Base_Meta_Transporte','homologar'),array('inicio'=>array('type'=>'string','format'=>'date'),'fim'=>array('type'=>'string','format'=>'date'),'evidencia_url'=>array('type'=>'string','maxLength'=>2048),'credencial_validada'=>array('type'=>'boolean'),'catalogo_equivalente'=>array('type'=>'boolean'),'sem_meta_terceiros'=>array('type'=>'boolean'),'eventos'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(array (
  0 => 'PageView',
  1 => 'Lead',
  2 => 'MaterialDownload',
),array('type'=>'object','required'=>array('elegiveis','pixel','servidor','deduplicados','descartes_inexplicados'),'additionalProperties'=>false,'properties'=>array_fill_keys(array('elegiveis','pixel','servidor','deduplicados','descartes_inexplicados'),array('type'=>'integer','minimum'=>0)))))) ,array('inicio','fim','evidencia_url','credencial_validada','catalogo_equivalente','sem_meta_terceiros','eventos'),false);
        });
    
},
'F3Base_Midia_Prontidao'=>static function():void{
add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('midia-prontidao-ler','Prontidão local por plataforma e destino, com fontes, motivos e ações; não chama fornecedores',array('F3Base_Midia_Prontidao','ler'));});
},
'F3Base_Ofertas'=>static function():void{

        add_action('wp_head',array('F3Base_Ofertas','marcador'),PHP_INT_MAX);
        add_action('f3base_ofertas_verificar',F3Base_Operacao::callback('f3base_ofertas_verificar',array('F3Base_Ofertas','cron')));
        add_action('save_post',array('F3Base_Ofertas','agendar'));
        add_action('switch_theme',array('F3Base_Ofertas','agendar'));
        add_action('updated_option',static function($nome){if(in_array($nome,array('f3base_seo_entidade','active_plugins','permalink_structure'),true)||str_starts_with($nome,'theme_mods_')){F3Base_Ofertas::agendar();}},10,1);
        add_action('f3base_zelador',array('F3Base_Ofertas','conferir_agenda_1'));
    
},
'F3Base_Ofertas_Medicao'=>static function():void{

        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('ofertas-diagnosticar','Inspecionar marcações de ofertas em HTML informado, sem executar nem buscar páginas',array('F3Base_Ofertas_Medicao','diagnosticar'),array('html'=>array('type'=>'string','maxLength'=>262144)),array('html'));});
    
},
'F3Base_Perfil_Desempenho'=>static function():void{

		add_action( 'init', array( 'F3Base_Perfil_Desempenho', 'ativar' ), 1 );
	
},
'F3Base_Pipedrive_Eliminacao'=>static function():void{
add_action('f3base_pipedrive_processar',array('F3Base_Pipedrive_Eliminacao','processar'),20);
},
'F3Base_Pipedrive_Fila'=>static function():void{

        add_action('f3base_pipedrive_alertas',array(F3Base_Pipedrive_Orcamento::class,'monitorar'),20);add_action('f3base_pipedrive_processar',array(F3Base_Pipedrive_Orcamento::class,'monitorar'),20);
        add_action('f3base_lead_persistido',array('F3Base_Pipedrive_Fila','capturado'));add_action('f3base_pipedrive_processar',array('F3Base_Pipedrive_Fila','processar'));
        add_action('f3base_leads_resumo',array('F3Base_Pipedrive_Fila','compactar'));
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('pipedrive-reconciliar','Resolver pessoa incerta, selecionar lead próprio ou adicionar e-mail alternativo por decisão administrativa',array('F3Base_Pipedrive_Fila','reconciliar'),array('chave'=>array('type'=>'string'),'revisao'=>array('type'=>'string'),'acao'=>array('type'=>'string','enum'=>array('pessoa','lead','email_alternativo')),'referencia_remota'=>array('type'=>'string'),'prova_remota'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true),'confirmar'=>array('type'=>'boolean'),'adicionar_email_alternativo'=>array('type'=>'boolean','default'=>false)),array('chave','revisao','acao','referencia_remota'),false);F3Base_Servicos::ability('pipedrive-atividade-reparar','Reconciliar somente a atividade complementar',array('F3Base_Pipedrive_Fila','reparar_atividade'),array('chave'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array('chave','revisao'),false);F3Base_Servicos::ability('pipedrive-fila-ler','Fila paginada e vínculos técnicos, sem dados pessoais',array('F3Base_Pipedrive_Fila','consultar'),array('compacto'=>array('type'=>'boolean','default'=>false),'pagina'=>array('type'=>'integer','minimum'=>1),'estado'=>array('type'=>'string','enum'=>array('pendente','enviando','incerto','revisao','suspenso','falhou','entregue','cancelado','cancelando'))));F3Base_Servicos::ability('pipedrive-reenviar','Reagenda uma entrega; resultados incertos continuam sujeitos à reconciliação',array('F3Base_Pipedrive_Fila','reenviar'),array('chave'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean'),'executar_agora'=>array('type'=>'boolean','default'=>false)),array('chave','revisao','simular'),false);});
        add_action('f3base_zelador',array('F3Base_Pipedrive_Fila','conferir_agenda_1'),90);
    
},
'F3Base_Politica'=>static function():void{
 add_action('admin_post_f3base_politica',array('F3Base_Politica','salvar')); 
},
'F3Base_Pos_Atualizacao'=>static function():void{

        add_action('f3base_zelador',array('F3Base_Pos_Atualizacao','agendar'),99);add_action('f3base_pos_atualizacao_verificar',array('F3Base_Pos_Atualizacao','executar'));
    
},
'F3Base_Primeira_Resposta'=>static function():void{

        add_action('f3base_primeira_resposta_processar',static function(){try{return F3Base_Primeira_Resposta::processar();}finally{if(F3Base_Primeira_Resposta::config()['ativo']){F3Base_Fila::agendar('f3base_primeira_resposta_processar',time()+300);}}});
        add_action('f3base_zelador',array('F3Base_Primeira_Resposta','conferir_agenda_1'),96);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('contato-primeira-resposta-atualizar','Consultar resposta da equipe; padrão simulado; guarda somente instante e fonte',array('F3Base_Primeira_Resposta','atualizar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'simular'=>array('type'=>'boolean','default'=>true)),array('record_id'),false);});
    
},
'F3Base_Protecao'=>static function():void{

        add_filter('rest_pre_dispatch',array('F3Base_Protecao','usuarios'),9,3);
        add_filter('xmlrpc_enabled',static fn($v)=>empty(F3Base_Protecao::config()['xmlrpc_desativado'])?$v:false);
        add_filter('xmlrpc_methods',static fn($v)=>empty(F3Base_Protecao::config()['xmlrpc_desativado'])?$v:array());
        add_filter('wp_headers',static function($h){if(!empty(F3Base_Protecao::config()['xmlrpc_desativado'])){foreach(array_keys($h) as $k){if(strtolower($k)==='x-pingback'){unset($h[$k]);}}}return $h;});
        add_filter('login_errors',static fn($v)=>!empty(F3Base_Protecao::config()['login_generico'])?'Não foi possível entrar. Confira seus dados e tente novamente.':$v);
        add_action('init',static function(){if(!empty(F3Base_Protecao::config()['xmlrpc_desativado'])){remove_action('wp_head','rsd_link');remove_action('wp_head','wlwmanifest_link');if(defined('XMLRPC_REQUEST')&&XMLRPC_REQUEST){status_header(403);nocache_headers();header('Content-Type: text/plain; charset=utf-8');echo 'XML-RPC desativado neste site.';exit;}}},-100);
    
},
'F3Base_Publicidade'=>static function():void{

        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('contato-publicidade-negar','Registrar negativa explícita do contato sem alterar medição ou apagar entregas históricas',array('F3Base_Publicidade','negar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'revisao'=>array('type'=>'integer'),'motivo'=>array('type'=>'string','minLength'=>1,'maxLength'=>500),'simular'=>array('type'=>'boolean','default'=>true)),array('record_id','revisao','motivo'),false));
        add_action('admin_post_f3base_publicidade_negar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão');}check_admin_referer('f3base-publicidade');$r=F3Base_Recuperacao::executar(array('F3Base_Publicidade','negar'),array('record_id'=>sanitize_key($_POST['record_id']??''),'revisao'=>(int)($_POST['revisao']??0),'motivo'=>sanitize_textarea_field(wp_unslash($_POST['motivo']??'')),'simular'=>false));wp_die(esc_html($r['codigo']??'operacao_indisponivel'),'Publicidade',array('back_link'=>true));});
    
},
'F3Base_Qualidade'=>static function():void{
F3Base_Bootstrap::iniciar('F3Base_Qualidade_Catalogo');F3Base_Bootstrap::iniciar('F3Base_Captura_Contexto');add_action('f3base_leads_resumo',array('F3Base_Qualidade','limpar_transitorios'));
        add_action('f3base_qualidade_processar',static function(){F3Base_Recuperacao::executar(static fn()=>F3Base_Qualidade::atualizar(array('interno'=>true)));});
        add_action('f3base_zelador',array('F3Base_Qualidade','conferir_agenda_1'),95);
        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/pipedrive/qualidade',array('methods'=>'POST','permission_callback'=>array('F3Base_Qualidade','autenticar'),'callback'=>array('F3Base_Qualidade','receber'))));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('contatos-qualidade-ler','Etapas atuais, histórico e estado do retorno à Meta',array('F3Base_Qualidade','ler'),array('record_id'=>array('type'=>'string'),'pagina'=>array('type'=>'integer','minimum'=>1),'etapa'=>array('type'=>'string')));
            F3Base_Servicos::ability('contato-qualidade-indicar','Indicar etapa comercial; simulação por padrão',array('F3Base_Qualidade','indicar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'etapa'=>array('type'=>'string'),'ocorreu_em'=>array('type'=>'integer'),'motivo'=>array('type'=>'string','maxLength'=>500),'revisao'=>array('type'=>'string'),'retirar_fixa'=>array('type'=>'boolean'),'cancelar_pendentes'=>array('type'=>'boolean'),'simular'=>array('type'=>'boolean')),array('record_id','etapa'),false);
            F3Base_Servicos::ability('contatos-qualidade-atualizar','Atualizar captação, CRM e retorno em lote limitado',array('F3Base_Qualidade','atualizar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'simular'=>array('type'=>'boolean')),array(),false);
            F3Base_Servicos::ability('contatos-qualidade-indicar-lote','Indicar etapas em até cinquenta contatos, com revisões individuais',array('F3Base_Qualidade','indicar_lote'),array('itens'=>array('type'=>'array','maxItems'=>50,'items'=>array('type'=>'object','properties'=>array('record_id'=>array('type'=>'string'),'revisao'=>array('type'=>'string')))),'etapa'=>array('type'=>'string'),'ocorreu_em'=>array('type'=>'integer'),'motivo'=>array('type'=>'string','maxLength'=>500),'simular'=>array('type'=>'boolean')),array('itens','etapa'),false);
            F3Base_Servicos::ability('qualidade-meta-reenviar','Reativar explicitamente um envio suspenso, preservando o destino',array('F3Base_Qualidade','reenviar_meta'),array('chave'=>array('type'=>'string'),'revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean')),array('chave'),false);
            F3Base_Servicos::ability('qualidade-crm-vincular','Associar negócio existente por decisão explícita do operador',array('F3Base_Qualidade','vincular_negocio'),array('record_id'=>array('type'=>'string'),'negocio_id'=>array('type'=>'string'),'revisao'=>array('type'=>'string'),'confirmar'=>array('type'=>'boolean'),'motivo'=>array('type'=>'string','maxLength'=>500),'simular'=>array('type'=>'boolean')),array('record_id','negocio_id'),false);
            F3Base_Servicos::ability('meta-crm-verificar','Verificar leitura do dataset sem enviar conversão',array('F3Base_Qualidade','verificar'),array('simular'=>array('type'=>'boolean')),array(),false);
        });
        add_action('admin_post_f3base_qualidade',array('F3Base_Qualidade','post'));
    
},
'F3Base_Qualidade_Catalogo'=>static function():void{

        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('qualidade-catalogo-carregar','Carregar funis e etapas da conta Pipedrive verificada; simulação sem HTTP',array('F3Base_Qualidade_Catalogo','carregar'),array('simular'=>array('type'=>'boolean','default'=>true)),array(),false);
            F3Base_Servicos::ability('qualidade-ler','Ler configuração e catálogo local de qualidade, sem consulta remota',array('F3Base_Qualidade_Catalogo','ler'),array('incluir_catalogo'=>array('type'=>'boolean','default'=>false)));
        });
    
},
'F3Base_Qualidade_Destinos'=>static function():void{

        add_action('f3base_qualidade_destinos_processar',static function(){try{return F3Base_Qualidade_Destinos::processar();}finally{F3Base_Fila::agendar('f3base_qualidade_destinos_processar',time()+300);}});add_action('f3base_zelador',array('F3Base_Qualidade_Destinos','conferir_agenda_1'),98);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('qualidade-conversoes-previa','Prévia comercial por etapa e destino; nenhuma ação de contato é reutilizada',array('F3Base_Qualidade_Destinos','previa'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'etapa'=>array('type'=>'string','maxLength'=>60),'ocorreu_em'=>array('type'=>'integer','minimum'=>1)),array('record_id','etapa'));});
    
},
'F3Base_Redes_Robos'=>static function():void{

        add_action('f3base_redes_robos_atualizar',F3Base_Operacao::callback('f3base_redes_robos_atualizar',array('F3Base_Redes_Robos','atualizar')));
        add_action('f3base_zelador',array('F3Base_Redes_Robos','conferir_agenda_1'),110);
    
},
'F3Base_Relatorios'=>static function():void{

        add_action('admin_menu',static function(){add_submenu_page('f3base-leads','Relatórios integrados','Relatórios','manage_options','f3base-relatorios',array(F3Base_Medicao_Interface::class,'render'));});
        add_action('admin_init',static function(){if(($_GET['page']??'')==='f3base-relatorios'&&current_user_can('manage_options')){$v=sanitize_key($_GET['visao']??'resultados');$area='conversao';if(!in_array($v,array (
  0 => 'meta_ads',
  1 => 'ga4',
  2 => 'telefones_normalizacao',
  3 => 'intencoes',
  4 => 'primeira_resposta',
  5 => 'identidade',
  6 => 'desfechos',
  7 => 'comercial',
  8 => 'ofertas',
  9 => 'resumo',
  10 => 'resultados',
  11 => 'campanhas',
  12 => 'formularios',
  13 => 'blocos',
  14 => 'qualidade',
  15 => 'operacao',
  16 => 'materiais',
  17 => 'demanda',
  18 => 'metodos',
  19 => 'superficies',
),true)){$v='resultados';}if($v==='ga4'){$area='ga4';}elseif($v==='campanhas'){$area='aquisicao';}elseif($v==='blocos'){$area='comportamento';}elseif($v==='qualidade'){$area='tecnico';}$e=F3Base_Medicao_Interface::filtros($_GET);wp_safe_redirect(add_query_arg(array_merge($e,array('page'=>'f3base-medicao','area'=>$area,'visao'=>$v)),admin_url('admin.php')));exit;}});
        add_action('admin_post_f3base_relatorio_csv',array('F3Base_Relatorios','csv'));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('relatorios-integrados-ler','Relatórios por página, campanha, formulário, conteúdo, qualidade e operação; cobertura e comparação',array('F3Base_Relatorios','consultar'),F3Base_Audiencia::dimensoes_schema()+array('google_ads_cursor'=>array('type'=>'string','maxLength'=>20000),'google_ads_dataset'=>array('type'=>'string','enum'=>array('customer','campaign','ad_group','ad','search_terms')),'meta_ads_cursor'=>array('type'=>'string','maxLength'=>100000),'ga4_propriedade'=>array('type'=>'string','pattern'=>'^properties/[1-9][0-9]{0,19}$'),'ga4_recorte'=>array('type'=>'string','enum'=>array_keys(F3Base_Ga4::recortes())),'ga4_revisao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'ga4_revisao_anterior'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'campanha_historica'=>array('type'=>'string','maxLength'=>191),'escopo_campanhas'=>array('type'=>'string','enum'=>array('atribuicao','historico')),'superficie'=>array('type'=>'string','enum'=>array('conteudo','menu','flutuante','elementor','cabecalho','barra_fixa','nao_informada')),'agrupamento'=>array('type'=>'string','enum'=>array('anuncio','campanha')),'canal'=>F3Base_Editorial_Relatorios::schema()['canal'],'tipo'=>F3Base_Editorial_Relatorios::schema()['tipo'],'automacao'=>F3Base_Editorial_Relatorios::schema()['automacao'],'method'=>array('type'=>'string'),'anotacoes'=>array('type'=>'boolean'),'segmento'=>array('enum'=>array (
  0 => 'sem_testes',
  1 => 'somente_testes',
  2 => 'todos',
)),'plataforma'=>array('type'=>'string'),'conta_id'=>array('type'=>'string'),'campanha_id'=>array('type'=>'string'),'grupo_id'=>array('type'=>'string'),'anuncio_id'=>array('type'=>'string'),'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'visao'=>array('enum'=>array (
  0 => 'meta_ads',
  1 => 'ga4',
  2 => 'telefones_normalizacao',
  3 => 'intencoes',
  4 => 'primeira_resposta',
  5 => 'identidade',
  6 => 'desfechos',
  7 => 'comercial',
  8 => 'ofertas',
  9 => 'resumo',
  10 => 'resultados',
  11 => 'campanhas',
  12 => 'formularios',
  13 => 'blocos',
  14 => 'qualidade',
  15 => 'operacao',
  16 => 'materiais',
  17 => 'demanda',
  18 => 'metodos',
  19 => 'superficies',
)),'caminho'=>array('type'=>'string'),'formulario'=>array('type'=>'string'),'metodo'=>array('enum'=>array('','formulario','whatsapp_formulario','conteudo','whatsapp_cta','contato_cta','anuncio_meta','anuncio_google','anuncio_linkedin','whatsapp_conversa','instagram_conversa')),'comparar'=>array('type'=>'boolean'),'pagina'=>array('type'=>'integer','minimum'=>1),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>200)));
            F3Base_Servicos::ability('lead-jornada-ler','Eventos observados antes do contato; sessão e carregamentos não comprovam sequência entre abas',array('F3Base_Relatorios','jornada'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'visao'=>array('type'=>'string','enum'=>array('atual','aviso'),'default'=>'atual'),'historico_pagina'=>array('type'=>'integer','minimum'=>1)),array('record_id'),true,'f3base_ler_leads',static fn()=>current_user_can('f3base_ler_leads'));
        });
    
},
'F3Base_Resumo_Operacional'=>static function():void{
add_action('wp_abilities_api_init',static function(){
        F3Base_Servicos::ability('resumo-operacional-ler','Resumo operacional local até 4 KB; validade desconhecida é null e listas excedentes têm detalhe',array('F3Base_Resumo_Operacional','ler'),array('campos'=>array('type'=>'array','uniqueItems'=>true,'maxItems'=>12,'items'=>array('type'=>'string','enum'=>array('pacotes','atualizacao','recuperacao','cron_24h','avisos','perfil','caixa','filas','prontidao','credenciais','contatos','limite')))));
        F3Base_Servicos::ability('credenciais-resumo-ler','Validade observada de credenciais Core e pacotes pelos contratos locais, sem valores secretos ou HTTP',array('F3Base_Resumo_Operacional','credenciais'));
    });
},
'F3Base_SMTP_Prova'=>static function():void{

        add_filter('f3base_options_catalogo',static function($c){$c['f3base_email_smtp_prova']=array('rotulo'=>'Prova SMTP da caixa','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;});
        add_action('admin_post_f3base_smtp_provar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão',403);}check_admin_referer('f3base_smtp_provar');F3Base_SMTP_Prova::verificar();wp_safe_redirect(admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=f3base_email_site'));exit;});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('email-smtp-verificar','Provar conexão, TLS e AUTH sem DATA; grava recibo técnico válido por 15 minutos',array('F3Base_SMTP_Prova','verificar'),array('simular'=>array('type'=>'boolean','enum'=>array(true),'default'=>true),'smtp_porta'=>array('type'=>'integer','enum'=>array(465,587)),'smtp_seguranca'=>array('type'=>'string','enum'=>array('ssl','tls'))),array(),false);});
    
},
'F3Base_Saude'=>static function():void{
add_action('admin_notices',static function(){if(current_user_can('manage_options')&&in_array($_GET['page']??'',array('base-site-core-fator3','f3base-integracoes'),true)&&empty(F3Base_Execucoes::resumo()['cron_servidor_ativo'])){echo '<div class="notice notice-warning"><p>Nenhuma passagem CLI foi observada nas últimas duas horas. Isso não comprova que o cron da hospedagem esteja desligado; confira o histórico de execução.</p></div>';}});
		add_filter( 'site_status_tests', array( 'F3Base_Saude', 'testes_do_site' ) );
		add_filter( 'debug_information', array( 'F3Base_Saude', 'informacoes' ) );
	
},
'F3Base_Schema_Verificacao'=>static function():void{

		add_action( 'f3base_schema_verificar', array( 'F3Base_Schema_Verificacao', 'cron' ) );
		add_action( 'wp', array( 'F3Base_Schema_Verificacao', 'agendar' ), 30 );
	
},
'F3Base_Servidor'=>static function():void{

        add_action('f3base_servidor_reverificar',array('F3Base_Servidor','reverificar'));
        add_action('f3base_zelador',array('F3Base_Servidor','conferir_agenda_1'),90);
        add_action('wp_abilities_api_init',static function():void {
            F3Base_Servicos::ability('servidor-aplicar','Consultar, aplicar ou remover somente as regras próprias do servidor, com revisão e restauração',array('F3Base_Servidor','executar'),array('acao'=>array('type'=>'string','enum'=>array('consultar','aplicar','remover')),'revisao_esperada'=>array('type'=>'string')),array(),false);
        });
        add_action('rest_api_init',static function():void {
            register_rest_route(F3BASE_REST_NAMESPACE,'/servidor-sonda',array('methods'=>'GET','permission_callback'=>'__return_true','callback'=>static function($r){
                $eco=$r->get_param('eco');$eco=is_scalar($eco)?(string)$eco:''; if(!preg_match('/^[a-f0-9]{24}$/D',$eco)){return new WP_Error('sonda_invalida','Sonda inválida.',array('status'=>400));}
                $res=new WP_REST_Response(array('ok'=>true,'eco'=>$eco));$res->header('Cache-Control','no-store, private');$res->header('X-Robots-Tag','noindex, nofollow');return $res;
            }));
        });
    
},
'F3Base_Sessao_Admin'=>static function():void{

        add_filter('auth_cookie_expiration', array('F3Base_Sessao_Admin', 'expiracao'), 10000, 3);
    
},
'F3Base_Sessao_Contexto'=>static function():void{
add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('contexto-sessao-simular','Simular app e classe de rede com catálogo candidato; sem HTTP ou gravação',array('F3Base_Sessao_Contexto','simular'),array('ip'=>array('type'=>'string','maxLength'=>45),'user_agent'=>array('type'=>'string','maxLength'=>500),'x_requested_with'=>array('type'=>'string','maxLength'=>150),'config'=>F3Base_Sessao_Contexto::schema()));});
},
'F3Base_Sessoes'=>static function():void{

        add_action('f3base_sessoes_indexar',array('F3Base_Sessoes','indexar'));
        add_action('f3base_retencao_limpeza',array('F3Base_Sessoes','reter'));
        add_action('f3base_lead_eliminando',array('F3Base_Sessoes','eliminar'));
    
},
'F3Base_Slack'=>static function():void{
F3Base_Slack::iniciar_operacao();F3Base_Bootstrap::iniciar('F3Base_Slack_Manutencao');
        add_action('wp_ajax_f3base_slack_canais',static function(){check_ajax_referer('f3base-slack-canais');wp_send_json(F3Base_Slack::canais(array('revisao'=>sanitize_text_field($_POST['revisao']??''),'cursor'=>sanitize_text_field($_POST['cursor']??''))));});
        add_action('admin_post_f3base_slack_verificar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-slack-verificar');$r=F3Base_Slack::verificar(array('simular'=>false,'postar_teste'=>!empty($_POST['postar_teste']),'revisao'=>sanitize_text_field($_POST['revisao']??'')));set_transient('f3base_slack_teste_'.get_current_user_id(),$r,300);wp_safe_redirect(admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=avisos'));exit;});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('slack-verificar','Verifica credencial; postar_teste envia mensagem marcada somente quando solicitado',array('F3Base_Slack','verificar'),array('simular'=>array('type'=>'boolean','default'=>true),'postar_teste'=>array('type'=>'boolean','default'=>false),'revisao'=>array('type'=>'string')),array(),false);});
    
},
'F3Base_Sondas_Http'=>static function():void{

        add_action('f3base_zelador',array('F3Base_Sondas_Http','preparar'),99);
        add_action('f3base_retencao_limpeza',array('F3Base_Sondas_Http','podar'));
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('medicao-sondas-ler','Sondas e requisições técnicas observadas pelo WordPress',array('F3Base_Sondas_Http','consultar'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'pagina'=>array('type'=>'integer','minimum'=>1),'caminho'=>array('type'=>'string','maxLength'=>190),'metodo'=>array('type'=>'string','enum'=>array('GET','HEAD')),'status'=>array('type'=>'integer','minimum'=>0,'maximum'=>599),'classe'=>array('type'=>'string','enum'=>array('teste','nao_marcado','invalida')))));
    
},
'F3Base_Testes'=>static function():void{
 add_action('template_redirect',array('F3Base_Testes','pagina'),-1000); 
},
'F3Base_Tracking_Diagnostico'=>static function():void{

        add_action('f3base_zelador',array('F3Base_Tracking_Diagnostico','reconciliar'),25);
        add_action('updated_option',static function($n){if($n==='f3base_gtm_container_id'){F3Base_Tracking_Diagnostico::reconciliar();}},25);
        add_action('f3base_gtm_verificar',array('F3Base_Tracking_Diagnostico','coletar'));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('tracking-encerrar-gtm','Encerrar tarefa GTM sem contêiner, com revisão e auditoria',array('F3Base_Tracking_Diagnostico','encerrar'),array('revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array('revisao'),false);
            F3Base_Servicos::ability('tracking-diagnostico','Slots configurados e última inspeção do GTM, sem HTTP',array('F3Base_Tracking_Diagnostico','ler'));
            F3Base_Servicos::ability('tracking-verificar-gtm','Inspecionar uma cópia limitada do contêiner público, sem executar JavaScript',static function(){return current_user_can('manage_options')?F3Base_Tracking_Diagnostico::coletar():array('ok'=>false,'codigo'=>'sem_permissao');},array(),array(),false);
        });
    
},
'F3Base_Vitais'=>static function():void{

        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::registrar_ability('f3base/vitais-ler',array('label'=>'Desempenho de campo por caminho e métrica','description'=>'p75 das últimas amostras por carregamento, atribuição INP/LCP e contagem de automação e legado excluídos. Leitura local sem coleta.','category'=>F3BASE_PREFIXO,'input_schema'=>array('type'=>'object','additionalProperties'=>false,'properties'=>F3Base_Vitais::filtros_schema()),'output_schema'=>array('type'=>'object','properties'=>array('ok'=>array('type'=>'boolean'),'codigo'=>array('type'=>'string'),'linhas'=>array('type'=>'array','items'=>array('type'=>'object','required'=>array('metrica','amostras','p75','excluidas_automacao','excluidas_legado'),'properties'=>array('metrica'=>array('type'=>'string'),'amostras'=>array('type'=>'integer'),'p75'=>array('type'=>array('number','null')),'excluidas_automacao'=>array('type'=>'integer'),'excluidas_legado'=>array('type'=>'integer'),'alvos'=>array('type'=>'array'),'scripts'=>array('type'=>'array'),'fase_dominante'=>array('type'=>array('string','null'))))))),'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>array('F3Base_Vitais','consultar'),'meta'=>array('mcp'=>array('public'=>true,'type'=>'tool'),'annotations'=>array('readonly'=>true,'idempotent'=>true,'destructive'=>false))));
        });
    
},
'F3Base_Whatsapp_Conversa'=>static function():void{

        add_filter('f3base_options_catalogo',static function($c){$c['f3base_whatsapp_site']=F3Base_Conversas::catalogo_grupo('f3base_whatsapp_site','Conversas WhatsApp pela ponte Slack',F3Base_Whatsapp_Conversa::padroes(),F3Base_Whatsapp_Conversa::props(),array('F3Base_Whatsapp_Conversa','validar'));$c['f3base_whatsapp_site_estado']=array('rotulo'=>'Cursor de conversas WhatsApp','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;});
        add_action('updated_option',array('F3Base_Whatsapp_Conversa','mudou'),40,3);add_action('added_option',static fn($n,$v)=>F3Base_Whatsapp_Conversa::mudou($n,null,$v),40,2);
        add_action('f3base_whatsapp_conversa_coletar',static function(){try{F3Base_Whatsapp_Conversa::coletar();}finally{if(!empty(F3Base_Whatsapp_Conversa::cfg()['ativo'])){F3Base_Fila::agendar('f3base_whatsapp_conversa_coletar',time()+300);}}});
        add_action('f3base_zelador',array('F3Base_Whatsapp_Conversa','conferir_agenda_1'),92);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('whatsapp-conversa-verificar','Provar leitura Slack e envelope da ponte, sem importar ou avisar',array('F3Base_Whatsapp_Conversa','verificar'),array('simular'=>array('type'=>'boolean','enum'=>array(true),'default'=>true)));F3Base_Servicos::ability('whatsapp-conversa-consultar','Simular ou processar janela incremental da ponte Slack',array('F3Base_Whatsapp_Conversa','consultar'),array('simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'reler_janela'=>array('type'=>'boolean','default'=>false)),array(),false);});
    
},
'F3Base_Wp_Mail'=>static function():void{

        add_filter('pre_wp_mail',array('F3Base_Wp_Mail','interceptar'),PHP_INT_MAX,2);
        add_action('f3base_zelador',array('F3Base_Wp_Mail','conferir_agenda_1'),96);
        add_action('f3base_wp_mail_processar',static function(){try{return F3Base_Wp_Mail::processar();}finally{if(F3Base_Email_Site::cfg()['wp_mail_pela_caixa']){F3Base_Fila::agendar('f3base_wp_mail_processar',time()+300);}}});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('email-wordpress-fila-ler','Ler recibos SMTP e retenções por cota, sem assunto, corpo ou destinatários',array('F3Base_Wp_Mail','ler'),array('pagina'=>array('type'=>'integer','minimum'=>1)),array(),true);});
    
},
'F3Base_Zelador'=>static function():void{

        add_filter('pre_get_ready_cron_jobs',array('F3Base_Zelador','filtrar'),20);
        add_action('wp_loaded',array('F3Base_Zelador','passagem'),PHP_INT_MAX-5);
        add_action('f3base_zelador_tick',array('F3Base_Zelador','executar'));
        add_action('updated_option',array('F3Base_Zelador','opcao'),200,3);
        add_action('added_option',array('F3Base_Zelador','adicionada'),200,2);
    
},
];
