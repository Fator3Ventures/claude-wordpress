(() => {
  'use strict';
  const root = document.querySelector('.f3-google');
  if (!root) return;
  root.classList.add('f3-js');
  const status = root.querySelector('#f3-live');
  // Small inventories are already rendered by PHP. Without JS all rows stay available.
  function localInventory(container, rows, label, groups = []) {
    const toolbar = document.createElement('div');
    toolbar.className = 'f3-list-controls';
    const field = document.createElement('label');
    field.append(label);
    const input = document.createElement('input');
    input.type = 'search';
    field.append(input);
    const total = document.createElement('output');
    total.setAttribute('aria-live', 'polite');
    const button = text => {
      const control = document.createElement('button');
      control.type = 'button';
      control.className = 'button';
      control.textContent = text;
      return control;
    };
    const previous = button('Anterior');
    const next = button('Próxima');
    toolbar.append(field, total, previous, next);
    container.before(toolbar);
    let offset = 0;
    const normalize = text => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR');
    const records = rows.map(row => [row, normalize(row.textContent)]);
    function render() {
      const query = normalize(input.value.trim());
      const matches = records.filter(([, text]) => text.includes(query));
      const visible = new Set(matches.slice(offset, offset + 20).map(([row]) => row));
      for (const row of rows) row.hidden = !visible.has(row);
      for (const group of groups) group.hidden = !group.querySelector('li:not([hidden])');
      total.textContent = matches.length ? (offset + 1) + '–' + Math.min(offset + 20, matches.length) + ' de ' + matches.length : '0 de 0';
      previous.disabled = offset === 0;
      next.disabled = offset + 20 >= matches.length;
    }
    input.addEventListener('input', () => { offset = 0; render(); });
    previous.addEventListener('click', () => { offset -= 20; render(); });
    next.addEventListener('click', () => { offset += 20; render(); });
    render();
  }
  root.querySelectorAll('.f3-table-wrap table:not([data-server-page])').forEach(table => {
    const wrap = table.closest('.f3-table-wrap');
    const name = wrap.getAttribute('aria-label') || wrap.closest('section')?.querySelector('h2, h3')?.textContent || 'tabela';
    wrap.tabIndex = 0;
    localInventory(wrap, Array.from(table.tBodies[0].rows), 'Buscar em ' + name);
  });
  const docs = root.querySelector('.f3-doc-groups');
  if (docs) localInventory(docs, [...docs.querySelectorAll('.f3-doc-list li')], 'Buscar documento', docs.querySelectorAll('.f3-doc-group'));
  root.querySelectorAll('[data-copy-target]').forEach(button => {
    button.addEventListener('click', async () => {
      const node = document.getElementById(button.dataset.copyTarget);
      if (!node) return;
      try {
        if (!navigator.clipboard) throw new Error('clipboard unavailable');
        await navigator.clipboard.writeText(node.textContent);
        status.textContent = 'Conteúdo copiado.';
        const label = button.textContent;
        button.textContent = 'Copiado';
        setTimeout(() => { button.textContent = label; }, 1800);
      } catch {
        const range = document.createRange();
        range.selectNodeContents(node);
        const selection = window.getSelection();
        selection.removeAllRanges(); selection.addRange(range);
        status.textContent = 'Conteúdo selecionado. Use o comando de copiar do navegador.';
      }
    });
  });
  root.querySelectorAll('[data-service-select]').forEach(select => {
    const fields = root.querySelector(`[data-service-fields="${select.dataset.serviceSelect}"]`);
    if (!fields) return;
    const sync = () => {
      fields.hidden = !select.value;
      fields.querySelectorAll('input,select,textarea').forEach(input => { input.disabled = !select.value; });
    };
    sync();
    select.addEventListener('change', sync);
  });
  const dirty = new Set();
  root.querySelectorAll('form.f3-form:not([data-no-dirty])').forEach(form => {
    form.addEventListener('input', () => dirty.add(form));
    form.addEventListener('change', () => dirty.add(form));
    form.addEventListener('submit', event => {
      const others = [...dirty].filter(item => item !== form);
      if (others.length && !window.confirm('Há alterações não salvas em outra seção. Continuar descarta essas alterações.')) { event.preventDefault(); return; }
      dirty.clear();
    });
  });
  window.addEventListener('beforeunload', event => {
    if (!dirty.size) return;
    event.preventDefault(); event.returnValue = '';
  });

  let nextFieldId = 0;
  root.addEventListener('click', event => {
    const button = event.target.closest('[data-add-profile-row],[data-remove-row]');
    if (!button) return;
    const group = button.closest('[data-profile-rows]');
    const rows = [...group.querySelectorAll(':scope > .f3-profile-row')];
    if (!rows.length) return;

    if (button.hasAttribute('data-remove-row')) {
      const row = button.closest('.f3-profile-row');
      if (rows.length > 1) {
        const index = rows.indexOf(row);
        row.remove();
        (rows[index + 1] || rows[index - 1]).querySelector('input,select,button').focus();
      } else {
        row.querySelectorAll('input,select').forEach(field => { field.value = ''; });
        row.querySelector('input,select').focus();
      }
    } else {
      if (rows.length >= 100) return;
      const last = rows[rows.length - 1];
      const next = Math.max(...rows.map(row => Number(row.dataset.rowIndex))) + 1;
      const prefix = group.dataset.profileRows;
      const before = `${prefix}[${last.dataset.rowIndex}]`;
      const after = `${prefix}[${next}]`;
      const copy = last.cloneNode(true);
      copy.dataset.rowIndex = String(next);
      const labels = new Map([...copy.querySelectorAll('label[for]')].map(label => [label.htmlFor, label]));
      for (const field of copy.querySelectorAll('input,select')) {
        if (field.name.startsWith(before)) field.name = after + field.name.slice(before.length);
        const label = labels.get(field.id);
        field.id = 'f3-profile-added-' + (++nextFieldId);
        if (label) label.htmlFor = field.id;
        field.value = '';
      }
      for (const nested of copy.querySelectorAll('[data-profile-rows]')) {
        nested.dataset.profileRows = after + nested.dataset.profileRows.slice(before.length);
      }
      copy.querySelector('legend').textContent = last.querySelector('legend').textContent.replace(/ · \d+$/, ' · ' + (next + 1));
      group.insertBefore(copy, button);
      copy.querySelector('input,select').focus();
    }
    const form = group.closest('form');
    if (form) form.dispatchEvent(new Event('change', { bubbles: true }));
  });
})();
