# Atualização — WP MCP Fator3 0.12.0

A 0.12.0 atualiza o mesmo plugin da 0.11.0. Pasta e arquivo principal: `wp-mcp-fator3/wp-mcp-fator3.php`. Requisitos mantidos: WordPress 6.7+ e PHP 8.0+.

## Instalação

1. No WordPress, abra Plugins → Adicionar plugin → Enviar plugin.
2. Envie `wp-mcp-fator3-0.12.0.zip` e escolha substituir a versão atual.
3. Abra Ferramentas → MCP Fator3 → Conexão. Confira o registro local e execute “Testar comunicação HTTP”.
4. No conector existente, use Discover Abilities e execute uma leitura, como `system/capabilities`, para confirmar o acesso a partir desse cliente.

Não é necessário excluir o Fator3, recriar credenciais ou reconfigurar conectores já instalados. Os complementos Google MCP e Base Site Core continuam separados. Para uma instalação antiga que ainda tem o Ultimate separado, siga `INSTALACAO.md`: primeiro atualize e mantenha o Fator3 ativo, depois desative e exclua somente o Ultimate.

## Endereços

| Finalidade | Exemplo com permalinks amigáveis |
|---|---|
| Conexões novas | `https://seu-dominio/wp-json/mcp/wp-mcp-fator3` |
| Compatibilidade | `https://seu-dominio/wp-json/mcp/wp-mcp-ultimate` |

A rota antiga é atendida diretamente pelo mesmo transporte, sem redirecionamento. Não há prazo de remoção nesta versão. Sessões, permissões e catálogo são compartilhados. Filtros de rota personalizada são preservados; a interface mostra a URL efetiva. Em subdiretórios ou sem permalinks, copie a URL produzida pelo painel.

`system/capabilities.endpoint` passa a informar o endereço principal. Os campos adicionais `legacy_endpoint` e `endpoints` identificam compatibilidade e registro local. O identificador interno do servidor e os nomes dos três metatools permanecem iguais. O catálogo próprio continua com 100 abilities: 97 operacionais e três meta-habilidades. Complementos podem ampliar esse inventário.

OAuth mantém issuer, clientes e endpoints de autorização, token e registro. O documento `/.well-known/oauth-protected-resource` permanece associado ao recurso antigo; cada rota anuncia seu documento específico no desafio `WWW-Authenticate`. Aliases do mesmo site são aceitos no parâmetro `resource`; destinos arbitrários são recusados. Tokens antigos válidos continuam aceitos, sem extensão de validade. Bearer não autentica rotas WordPress comuns ou rotas ocupadas por outro callback.

## Telas e diagnóstico

- **Conexão:** URL principal, compatibilidade recolhida, seleção da forma de autenticação e configurações por cliente.
- **Acesso e limites:** canal de arquivos/banco, escrita SQL e restrições efetivas de constantes, filtros e permissões.
- **Diagnóstico e atividade:** registro do servidor, rotas, ferramentas, último teste, armazenamento e auditoria.

A mensagem “Servidor MCP não detectado” era um falso negativo: a tela procurava uma função global, mas ela pertence ao namespace `Fator3\McpFiles`. A nova tela usa o diagnóstico compartilhado. Componente carregado, registro de rota e comunicação HTTP são estados separados. A versão do WordPress não aparece como pré-requisito visual; permanece nos requisitos de instalação e no diagnóstico para agentes.

Os JSONs começam fechados. Expanda “Ver configuração para…” para consultar e copiar. OAuth e senha de aplicação continuam disponíveis simultaneamente; a seleção apenas muda as instruções e os exemplos. O modelo sem segredo indica os campos a preencher. A senha é exibida somente na criação; revogar limpa senha, Base64 e JSONs derivados, e recarregar não recupera o texto anterior. A interface confirma a existência real da senha, não apenas um UUID salvo.

O teste HTTP é iniciado pelo usuário e parte do próprio servidor. Usa uma senha temporária exclusiva, protegida pelo mesmo lock das operações de credencial do painel, e a remove ao terminar. Verifica `initialize`, `notifications/initialized` e `tools/list`, com verificação TLS e sem seguir redirecionamentos. Distingue timeout, DNS, TLS, 401, 403, 404 e ferramentas ausentes. Um teste de loopback bem-sucedido não comprova o acesso do cliente externo, seu segredo configurado ou o fluxo OAuth desse produto. O último resultado expira em 15 minutos e é invalidado por alterações relevantes de configuração/credencial/versão.

As preferências são conferidas após gravar, incluindo ausência de mudança, veto e sobreposição por filtros. Fechar o canal bloqueia as operações de arquivos/banco sujeitas a esse controle; outras abilities mantêm suas permissões próprias.

A auditoria estruturada é paginada em 20 entradas na tela; o histórico legado fica separado. A consulta limita a leitura a 10 mil arquivos de metadados ou 16 MiB, com erro explícito ao exceder esse limite. Conteúdos de backups não são abertos para listar a auditoria. A retenção pode ser administrada por `audit/prune`; não é executada automaticamente ao abrir a página. O painel exibe o diretório privado efetivo e o acervo legado separadamente.

## Funcionalidades preservadas

Permanecem as correções de `plugins/delete`, unslash, `files/read` com filtros e paginação, remoção de diretórios vazios, lixeira de tipos personalizados, revisão de conteúdo, SQL com confirmação, idempotência, planos, backups e locks por arquivo. Leitura, SHA-256, backup e substituição continuam protegidos pela mesma operação; duas gravações concorrentes com o mesmo hash deixam uma vencedora e um `file_conflict` identificável, inclusive entre as duas URLs.

## Retorno à 0.11.0

O pacote não converte em massa os dados existentes. Para voltar à 0.11.0 em homologação, substitua o pacote mantendo os dados. A 0.11.0 atende somente `/wp-json/mcp/wp-mcp-ultimate`: conectores criados com a URL Fator3 precisarão usar o endereço antigo durante o rollback. Tokens já expirados ou senhas revogadas não voltam a ser válidos.

## Referências dos exemplos

Os formatos foram conferidos nas documentações de [Claude Code](https://code.claude.com/docs/en/mcp) e [Cursor](https://cursor.com/docs/mcp). O exemplo de Claude Desktop/stdio usa a ponte `mcp-remote` executada no computador do cliente; ela não é uma dependência do servidor WordPress. Esta entrega valida o protocolo em laboratório e não certifica o fluxo de interface de cada aplicativo cliente.
