<?php
declare(strict_types=1);

namespace WpMcpUltimate\OAuth;

/**
 * Resolves an `Authorization: Bearer <token>` header issued by our own
 * token endpoint into a WordPress user, so OAuth-authenticated requests
 * reach the MCP transport's existing current_user_can() checks exactly
 * like Application Password (Basic Auth) requests already do.
 */
final class BearerAuth {

	public static function init(): void {
		add_filter( 'determine_current_user', array( self::class, 'authenticate' ), 20 );
        // A user may have been resolved before REST registration. Retry after
        // registration, before cookie auth, without granting tokens to collisions.
        add_filter('rest_authentication_errors', [self::class, 'authenticate_rest'], 95);
	}

    public static function authenticate_rest($result) {
        if (!empty($result) || get_current_user_id()) return $result;
        $user_id = self::authenticate(0);
        if ($user_id) { wp_set_current_user($user_id); return true; }
        return $result;
    }

	/**
	 * @param int|false $user_id
	 * @return int|false
	 */
	public static function authenticate( $user_id ) {
		// Another auth method (cookie, Application Password) already resolved a user.
		if ( ! empty( $user_id ) ) {
			return $user_id;
		}

		// Tokens are consented for MCP access only, so they must not
		// authenticate arbitrary WordPress requests (wp/v2 REST, admin-ajax).
		if ( ! self::is_mcp_request() ) {
			return $user_id;
		}

		$header = self::get_authorization_header();
		if ( '' === $header || 0 !== stripos( $header, 'Bearer ' ) ) {
			return $user_id;
		}

		$token   = trim( substr( $header, 7 ) );
		$payload = '' !== $token ? TokenStore::get_access_token( $token ) : null;

		if ( ! $payload || empty( $payload['user_id'] ) ) {
			return $user_id;
		}

        if (isset($payload['site_id']) && (int)$payload['site_id'] !== get_current_blog_id()) return $user_id;
        if (isset($payload['resource']) && is_wp_error(\Fator3\McpFiles\ConnectionEndpoints::resource($payload['resource']))) return $user_id;
        if (isset($payload['scope']) && !in_array('mcp', explode(' ', $payload['scope']), true)) return $user_id;
        return (int) $payload['user_id'];
	}

	/**
	 * Whether this request will actually be dispatched to the MCP REST route.
	 *
	 * This must mirror how WordPress resolves the route, not just what the
	 * URL path looks like: WP::parse_request() gives $_POST/$_GET precedence
	 * over the rewrite-derived value, so `rest_route` in the query string
	 * overrides the pretty-permalink match. Checking only REQUEST_URI would
	 * let `POST /wp-json/mcp/wp-mcp-ultimate?rest_route=/wp/v2/users` — which
	 * dispatches to wp/v2 — still authenticate with an MCP-scoped token.
	 */
	private static function is_mcp_request(): bool {
        $route = \Fator3\McpFiles\ConnectionEndpoints::request_route();
        return null !== $route && \Fator3\McpFiles\ConnectionEndpoints::is_registered($route);
	}

	private static function get_authorization_header(): string {
		if ( ! empty( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] ) );
		}

		// Some hosts (e.g. behind FastCGI/PHP-FPM) strip the Authorization
		// header unless redirected via .htaccess; check the redirected copy too.
		if ( ! empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) );
		}

		return '';
	}
}
