# WP MCP Fator3 0.12.0

Plugin único que substitui o complemento Fator3 0.8.0 e o WP MCP Ultimate separado. Mantém a pasta `wp-mcp-fator3` e o arquivo principal `wp-mcp-fator3.php`, permitindo atualizar o complemento pelo painel do WordPress.

Inclui o núcleo do [WP MCP Ultimate 2.1.0](https://github.com/AgriciDaniel/wp-mcp-ultimate/commit/d5eff50ff3d5609fa491dfb9af7946c261b00c89), as correções integradas no upstream, a correção de perda de barras em conteúdo e o plano Fator3 0.9.0. Esta é uma distribuição Fator3, não uma release oficial do Ultimate.

Requisitos: **WordPress 6.7+ e PHP 8.0+**. O pacote inclui a Abilities API para WordPress anterior ao 6.9; a partir do 6.9 usa a API nativa. Não exige Composer, Node ou outro plugin no servidor.

## Novidades da 0.12.0

URL principal `/wp-json/mcp/wp-mcp-fator3`, com a URL antiga `/wp-json/mcp/wp-mcp-ultimate` atendida diretamente como alias. As duas usam o mesmo servidor, sessões, permissões e catálogo. OAuth e senhas de aplicação existentes continuam válidos até a expiração ou revogação normal.

Painel unificado em Conexão, Acesso e limites, e Diagnóstico e atividade. JSONs recolhidos por padrão, cópia com feedback, estado correto das credenciais, diagnóstico por evidência local e teste HTTP explícito. O falso aviso de servidor ausente foi corrigido; a versão do WordPress saiu dos pré-requisitos visuais.

Leia [atualização 0.12.0](docs/ATUALIZACAO-0.12.0.md) e [validação 0.12.0](docs/VALIDACAO-0.12.0.md). O catálogo próprio permanece com 100 abilities, incluindo os três metatools.

## Novidades da 0.11.0

Correções de exclusão, SQL, confirmação, opções e erros MCP; locks comuns para leitura/comparação/backup/gravação; revisão de conteúdo; 27 abilities novas para diagnóstico, temas/plugins, blocos, upsert, recuperação, arquivos, planos, auditoria e backups. A rota e os três metatools permanecem os mesmos.

Leia [contratos e atualização](docs/ATUALIZACAO-0.11.0.md) e [validação](docs/VALIDACAO-0.11.0.md). São 100 abilities próprias, preservando as 73 da base; o WordPress e complementos podem acrescentar outras.

## Atualizar uma instalação com os dois plugins

1. Em **Plugins → Adicionar plugin → Enviar plugin**, envie `wp-mcp-fator3-0.12.0.zip` e escolha **Substituir o atual pelo enviado**. Mantenha o Fator3 ativo.
2. **Depois** desative e exclua apenas o WP MCP Ultimate separado. O Fator3 deve continuar ativo durante a exclusão: ele protege as credenciais contra o desinstalador antigo.
3. Abra **Ferramentas → MCP Fator3 → Conexão** e execute **Testar comunicação HTTP**. No conector, descubra as habilidades e execute `files/selftest` com o canal aberto.

Não exclua o Ultimate antes de atualizar o Fator3. O desinstalador antigo apaga configurações, senhas de aplicação que ele gerencia e dados OAuth. Se isso já aconteceu, será necessário configurar novamente a conexão; dados apagados não podem ser recuperados pela migração.

Na coexistência temporária, o Fator3 usa o núcleo externo e mostra um aviso. As correções do núcleo integrado entram em uso na requisição seguinte à desativação do Ultimate. Veja [as instruções completas](docs/INSTALACAO.md).

## Funcionalidades e conexão

- 58 habilidades do Ultimate para conteúdo, mídia, usuários, comentários, menus, widgets, plugins, opções e diagnóstico.
- Habilidades de arquivos herdadas: `files/list`, `read`, `write`, `patch`, `delete`, `backups`, `restore`, `fetch` e `selftest`.
- Três habilidades de banco: `db/schema`, `db/query` e `db/execute`, com prévia, token de confirmação e backup das linhas antes da escrita.
- Autenticação por Application Password e servidor OAuth com PKCE S256, descoberta e registro dinâmico de clientes.

A URL principal é `/wp-json/mcp/wp-mcp-fator3`; `/wp-json/mcp/wp-mcp-ultimate` continua disponível por compatibilidade. Em instalações sem links permanentes amigáveis, utilize a URL que o painel mostrar. As três ferramentas MCP continuam sendo **Discover Abilities**, **Get Ability Info** e **Execute Ability**; há 97 habilidades operacionais por trás delas, além das três meta-habilidades. Habilidades registradas pelo WordPress ou por outros plugins podem ampliar o inventário.

A atualização preserva o estado dos canais, a auditoria e os backups do Fator3. A migração transfere a posse das configurações e credenciais do Ultimate; os valores das senhas e tokens não são regenerados. Tokens mantêm sua expiração original.

## Exclusão de conteúdo na 0.9.3

`content/delete-post` agora usa a operação de lixeira explicitamente para qualquer tipo de post, incluindo tipos personalizados, quando `force=false` ou o parâmetro é omitido. Se a lixeira estiver desativada (`EMPTY_TRASH_DAYS=0`), retorna falha sem excluir. Um item já na lixeira permanece nela. Exclusão definitiva exige o booleano `force=true`.

```json
{"id":123,"force":false}
```

O schema e a descrição expostos pelo conector explicam essas condições. Filtros de veto são respeitados, e a resposta de sucesso verifica o estado final do registro. As permissões existentes continuam aplicadas. [Contrato e validação da 0.9.3](docs/ATUALIZACAO-0.9.3.md).

## Diretórios vazios na 0.9.2

`files/delete` agora oferece `rmdir` com `empty_dir=true`:

```json
{"path":"wp-content/uploads/pasta-vazia","empty_dir":true}
```

A opção aceita somente diretórios existentes e vazios. Arquivos ocultos, links dentro da pasta e subpastas contam como conteúdo. Um link simbólico usado como diretório final é recusado. A operação registra `rmdir` na auditoria e retorna `backup_id` vazio; `files/restore` continua destinado a arquivos. As regras de permissão e confinamento existentes se aplicam antes da remoção. [Contrato e validação da 0.9.2](docs/ATUALIZACAO-0.9.2.md).

## Leitura de logs na 0.9.1

`files/read` aceita `tail_lines` para ler do fim, `offset` em linhas e `limit` para paginação. `grep` filtra primeiro; é literal e sensível a maiúsculas/minúsculas, ou PCRE com `grep_regex=true`.

```json
{"path":"/home/usuario/site/wp-content/debug.log","tail_lines":100,"grep":"PHP Fatal error"}
```

Para a página anterior, mantenha os parâmetros e use `next_offset` como `offset`. Com `tail_lines`, o deslocamento conta do fim; sem ele, conta do início. O conteúdo sempre volta na ordem original. Só `path` continua lendo o arquivo integralmente. A leitura parcial permite arquivos acima de 16 MiB e mantém esse teto por resposta; `sha256` cobre o trecho devolvido. [Contrato, exemplos e validação da 0.9.1](docs/ATUALIZACAO-0.9.1.md).

`plugins/delete`, herdado do Ultimate, agora carrega as funções de filesystem do WordPress e trata falhas sem abrir formulário administrativo na resposta MCP.

## Contrato de arquivos herdado da 0.9.0

Por padrão, `files/*` aceita caminhos absolutos e relativos a `ABSPATH`, incluindo `..`, e alcança o sistema de arquivos permitido ao usuário do PHP e por `open_basedir`. A lista padrão de nomes bloqueados fica vazia. `files/list` sem caminho lista `ABSPATH`.

O canal aberto pode ler `wp-config.php` e chaves alcançáveis pelo PHP, e pode gravar PHP em uploads. Esse alcance é o comportamento solicitado para 0.9.0 e aparece no painel. Permanecem as capacidades `edit_themes` + `manage_options`, o botão de fechar o canal, `DISALLOW_FILE_EDIT`, `DISALLOW_FILE_MODS`, a rejeição de wrappers de stream e bytes nulos e a proteção de autoedição.

Escritas usam backup automático por padrão e checagem de sintaxe para `.php`. Exclusões de arquivos podem ser restauradas; diretórios vazios podem ser removidos com `files/delete` e `empty_dir=true`, sem backup de conteúdo; diretórios com conteúdo são recusados. A restauração verifica SHA-256, sintaxe PHP e guarda o destino anterior antes de sobrescrevê-lo. As opções explícitas de backup existentes foram mantidas.

Para manter um site no escopo antigo, adicione ao `wp-config.php` **antes da atualização**:

```php
define( 'F3_MCP_FILES_CONFINE', 'wp' );
```

Isso restaura raízes de temas, plugins e mu-plugins e a lista clássica de nomes bloqueados. Sob confinamento, informe uma raiz permitida em `files/list`; `ABSPATH` pode ficar fora do escopo.

Filtros preservados: `f3_mcp_files_roots` (vazio abre; lista não vazia confina), `f3_mcp_files_denied_basenames`, `f3_mcp_files_allowed_extensions`, `f3_mcp_files_denied_extensions`, `f3_mcp_files_protect_self`, `f3_mcp_files_max_bytes` e `f3_mcp_files_enabled`. Uma lista de raízes configurada, mas sem diretório válido, recusa acesso. O teto padrão é 16 MiB na leitura integral/escrita e por resposta na leitura parcial; downloads têm teto de 32 MiB, ajustável pelos filtros existentes.

`files/fetch` mantém as verificações de URL e rede interna. Abertura de caminhos de arquivos não remove a proteção contra SSRF.

## Conteúdo e barras

O pacote aplica `wp_slash()` no limite de escrita das APIs do WordPress que o exigem. Posts e páginas preservam escapes de JSON/Gutenberg e barras literais, inclusive depois de vários patches. O ajuste também cobre os campos textuais auditados de mídia, comentários e usuários; senhas de usuários permanecem no formato bruto exigido pelo WordPress.

Conteúdo já corrompido por versões anteriores precisa de restauração por backup/revisão ou correção específica. A atualização evita novas perdas; não tenta adivinhar quais textos antigos eram escapes.

## Testes e manutenção

As verificações executadas, o tratamento dos PRs abertos e os limites da validação estão em [RELATORIO.md](docs/RELATORIO.md), com resultados estruturados em `docs/validation.json`. O inventário preservado está em `tests/expected-abilities.json`.

Os scripts em `tests/` devem ser executados **somente em WordPress descartável**. Os arquivos em `tests/upstream/` e `docs/upstream/` são referências do projeto de origem. `maintenance/upstream-workflows/` guarda os workflows upstream já atualizados pelos PRs #7/#11; não são executados pelo WordPress e ainda usam a estrutura do repositório Ultimate.

Licença GPL-2.0-or-later. Autoria original e licença preservadas em `LICENSE` e nos arquivos do núcleo.
