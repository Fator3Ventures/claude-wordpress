# Ajuda das opções — Core 1.27.0

Gerada do catálogo executável e da ajuda efetiva. Não contém valores configurados no site.

## f3base_contato

```json
{
    "rotulo": "Contato, avisos e WhatsApp",
    "descricao": "Defina os avisos da equipe, o destino do WhatsApp e a instrumentação dos botões.",
    "campo": "grupo",
    "subcampos": {
        "flutuante": {
            "tipo": "booleano",
            "rotulo": "Ativar WhatsApp flutuante",
            "descricao": "Ícone fixo no canto inferior direito em todas as páginas públicas.",
            "impacto": "Ativado com um número válido, publica um link de WhatsApp independente do menu e do layout. Desativado, o plugin não publica esse ícone. Os botões do tema são definidos pelo próprio layout.",
            "exemplo": "Marque para manter o contato disponível durante a rolagem no computador e no celular.",
            "ajuda": {
                "funcionamento": "Ativado com um número válido, publica um link de WhatsApp independente do menu e do layout. Desativado, o plugin não publica esse ícone. Os botões do tema são definidos pelo próprio layout.",
                "escolha": "Ative para oferecer acesso direto ao WhatsApp em páginas elegíveis.",
                "vantagens": "Mantém o atendimento acessível durante a navegação.",
                "limitacoes": "Clique direto é intenção; não informa nome/e-mail e não cria pessoa no CRM.",
                "exemplo": "Ativado com número completo; o visitante abre o aplicativo de WhatsApp.",
                "vazio": "Desmarcado oculta o botão; preserva número e mensagem."
            }
        },
        "whatsapp_e164": {
            "tipo": "texto",
            "rotulo": "Número de WhatsApp",
            "descricao": "Código do país, DDD e número, somente dígitos.",
            "impacto": "Define o destino do WhatsApp flutuante quando ele estiver ativado. Preencher o número não insere nem altera botões no menu ou no conteúdo. O clique instrumentado respeita o consentimento e os canais configurados.",
            "exemplo": "Ilustrativo: 5511900000000 — o 55 do país, o 11 do DDD e o número, sem espaço, traço ou parêntese.",
            "ajuda": {
                "funcionamento": "Define o destino do WhatsApp flutuante quando ele estiver ativado. Preencher o número não insere nem altera botões no menu ou no conteúdo. O clique instrumentado respeita o consentimento e os canais configurados.",
                "escolha": "Informe país, DDD e telefone do atendimento.",
                "vantagens": "Todos os botões que herdam o contato usam o mesmo destino.",
                "limitacoes": "Número incorreto pode encaminhar a outra pessoa. Não comprova conta WhatsApp ativa.",
                "exemplo": "5511900000000",
                "vazio": "Vazio deixa o destino sem configuração; não cria número automaticamente."
            }
        },
        "mensagem_padrao": {
            "tipo": "textarea",
            "rotulo": "Mensagem que abre a conversa",
            "descricao": "Texto já escrito na conversa quando o visitante chega ao WhatsApp.",
            "impacto": "Preenchida, é este texto que aparece escrito na conversa antes de o visitante digitar qualquer coisa — é onde se diz de qual página ele veio. Vazia, o site usa uma frase própria com o nome do site: o botão funciona igual, e só o texto inicial muda.",
            "exemplo": "Ilustrativo: \"Olá! Vim pelo site e gostaria de falar com a equipe.\"",
            "ajuda": {
                "funcionamento": "Preenchida, é este texto que aparece escrito na conversa antes de o visitante digitar qualquer coisa — é onde se diz de qual página ele veio. Vazia, o site usa uma frase própria com o nome do site: o botão funciona igual, e só o texto inicial muda.",
                "escolha": "Use uma saudação curta, que o visitante pode editar no WhatsApp.",
                "vantagens": "Facilita iniciar a conversa.",
                "limitacoes": "O texto no link não comprova que a mensagem foi enviada. Não inclua dados sensíveis.",
                "exemplo": "Olá, gostaria de conhecer os serviços.",
                "vazio": "Vazio abre o destino sem texto inicial."
            }
        },
        "email_leads": {
            "tipo": "emails",
            "rotulo": "Quem recebe os avisos internos (até cinco)",
            "descricao": "E-mails da equipe, um por linha. A lista do formulário prevalece quando definida. Sem destinatário, o contato é salvo e o aviso fica desconfigurado.",
            "impacto": "E-mails da equipe, um por linha. A lista do formulário prevalece quando definida. Sem destinatário, o contato é salvo e o aviso fica desconfigurado.",
            "ajuda": {
                "funcionamento": "Recebe os avisos internos. Na primeira configuração, copia o e-mail da administração do WordPress. Formulário com lista própria usa sua lista; o resumo horário usa a lista geral.",
                "escolha": "Use uma caixa acompanhada pela equipe comercial. A ação Usar e-mail da administração preenche o campo para revisão, sem salvar.",
                "vantagens": "Começa com um endereço existente e centraliza formulários sem lista própria.",
                "limitacoes": "Uma caixa técnica pode não ser acompanhada pelo atendimento. Alterar o e-mail do WordPress depois não atualiza este campo. Endereço válido não comprova entrega.",
                "exemplo": "contato@example.com e comercial@example.com, um por linha; até cinco destinatários.",
                "vazio": "Nenhum destinatário geral; formulários com lista própria continuam usando essa lista."
            }
        },
        "avisar_por_clique": {
            "tipo": "booleano",
            "rotulo": "Enviar aviso interno de clique",
            "descricao": "Avisa sobre clique registrado, inclusive sem nome/e-mail. Desligar mantém o registro. Até 30 avisos por hora; pendentes entram no resumo horário.",
            "impacto": "Avisa sobre clique registrado, inclusive sem nome/e-mail. Desligar mantém o registro. Até 30 avisos por hora; pendentes entram no resumo horário.",
            "ajuda": {
                "funcionamento": "Envia aviso interno quando um CTA de contato é registrado. O clique representa intenção de contato.",
                "escolha": "Ative se a equipe precisa acompanhar cliques; desative se o volume de intenção atrapalha o atendimento de envios.",
                "vantagens": "Dá visibilidade a contatos iniciados fora do formulário.",
                "limitacoes": "Clique não comprova conversa, pessoa identificada ou venda. Há limite de avisos individuais e resumo horário.",
                "exemplo": "Um clique em WhatsApp pode gerar aviso; o registro permanece quando o aviso está desligado.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "avisar_por_formulario": {
            "tipo": "booleano",
            "rotulo": "Enviar aviso interno de formulário recebido",
            "descricao": "Envia aviso após salvar um envio aceito. Falha no e-mail mantém o contato. A lista de destinatários pode ser definida em cada formulário.",
            "impacto": "Envia aviso após salvar um envio aceito. Falha no e-mail mantém o contato. A lista de destinatários pode ser definida em cada formulário.",
            "ajuda": {
                "funcionamento": "Notifica a equipe sobre envios aceitos. Suspeitos e testes suprimidos permanecem no registro, sem aviso comercial.",
                "escolha": "Mantenha ativo quando o e-mail participa do atendimento.",
                "vantagens": "Facilita responder a uma solicitação com dados fornecidos pelo visitante.",
                "limitacoes": "Não substitui a consulta da fila de contatos. A resposta automática ao visitante tem controle separado.",
                "exemplo": "Formulário sem destinatários próprios usa a lista geral; lista própria vazia não herda.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "classes_cta": {
            "tipo": "linhas",
            "rotulo": "Classes adicionais de botões de contato",
            "descricao": "Classes CSS sem ponto, uma por linha; exemplo: f3capital-acao-whatsapp. A marcação não altera o link e o método segue o destino.",
            "impacto": "Classes CSS sem ponto, uma por linha; exemplo: f3capital-acao-whatsapp. A marcação não altera o link e o método segue o destino.",
            "ajuda": {
                "funcionamento": "Reconhece links dentro de contêineres com as classes informadas. Não muda destinos nem identifica campos de formulário.",
                "escolha": "Use quando os blocos existentes já têm uma classe estável de contato.",
                "vantagens": "Instrumenta blocos existentes sem recriar os links.",
                "limitacoes": "Classes genéricas podem marcar links que não são contatos. Para botões sem href, declare data-f3base-destino.",
                "exemplo": "acao-comercial, sem ponto inicial. Preserve data-f3base-lead existente para manter a série histórica.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "historico_sem_decisao": {
            "tipo": "enum",
            "rotulo": "Histórico com referência de consentimento perdida",
            "descricao": "Aplica-se quando a referência registrada não é localizada. Preserva negativas e revogações conhecidas.",
            "impacto": "Permitir usa os dados históricos disponíveis e indica a evidência ausente; negar restringe apresentação e reenvio sem apagar dados.",
            "exemplo": "Uma referência removida por retenção não impede o atendimento no modo permitir. A mudança não reenvia contatos automaticamente.",
            "opcoes": {
                "permitir": "Exibir e permitir reenvio do histórico",
                "negar": "Restringir o histórico"
            },
            "ajuda": {
                "funcionamento": "Permitir usa os dados históricos disponíveis e indica a evidência ausente; negar restringe apresentação e reenvio sem apagar dados.",
                "escolha": "Escolha uma das alternativas exibidas. Cada alternativa muda o funcionamento descrito acima; uma opção gravada é preservada nas atualizações.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "Uma referência removida por retenção não impede o atendimento no modo permitir. A mudança não reenvia contatos automaticamente.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "carimbar_whatsapp_por_destino": {
            "tipo": "booleano",
            "rotulo": "Reconhecer links para este WhatsApp",
            "descricao": "Marca automaticamente links HTTPS para o número configurado, sem alterar o destino.",
            "impacto": "Ative para incluir links sem classe de CTA. Links wa.me/message continuam exigindo marca explícita.",
            "exemplo": "https://wa.me/5511900000000 deve corresponder exatamente ao número completo do site.",
            "ajuda": {
                "funcionamento": "Ative para incluir links sem classe de CTA. Links wa.me/message continuam exigindo marca explícita.",
                "escolha": "Ative quando links sem classe apontarem exatamente ao número configurado.",
                "vantagens": "Instrumenta links existentes sem recriá-los.",
                "limitacoes": "Links encurtados wa.me/message não revelam o número e exigem marca explícita.",
                "exemplo": "https://wa.me/5511900000000 corresponde ao número do site.",
                "vazio": "Desmarcado mantém somente marcações explícitas e componentes do Core."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Defina os avisos da equipe, o destino do WhatsApp e a instrumentação dos botões.",
        "escolha": "Ajuste este campo conforme a operação de Contato, avisos e WhatsApp neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Configure os e-mails da equipe e ative o aviso de formulário; mantenha o aviso de clique desligado se apenas envios completos exigirem atendimento.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_ga4_measurement_id

```json
{
    "rotulo": "Google Analytics 4 — ID da métrica",
    "descricao": "Identificador do fluxo de dados da propriedade do Google Analytics.",
    "campo": "texto",
    "impacto": "Preenchido, o site passa a carregar o Google Analytics e a enviar para lá as páginas vistas, os contatos e o comportamento que ele já mede: profundidade de rolagem, seções alcançadas, cliques que saem do site, sinais de dificuldade, erros de página e tempo de carregamento. Vazio, nada disso chega ao Google Analytics — o site continua guardando o resumo próprio, e a análise completa, com público, origem de tráfego e comparação de períodos, deixa de existir.",
    "exemplo": "Ilustrativo, na forma que o próprio Google usa na documentação: G-XXXXXXXXXX. O valor real aparece no fluxo de dados da propriedade.",
    "ajuda": {
        "funcionamento": "Preenchido, o site passa a carregar o Google Analytics e a enviar para lá as páginas vistas, os contatos e o comportamento que ele já mede: profundidade de rolagem, seções alcançadas, cliques que saem do site, sinais de dificuldade, erros de página e tempo de carregamento. Vazio, nada disso chega ao Google Analytics — o site continua guardando o resumo próprio, e a análise completa, com público, origem de tráfego e comparação de períodos, deixa de existir.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Envia eventos elegíveis à propriedade selecionada.",
        "limitacoes": "GTM ou tema podem enviar à mesma propriedade; evite duplicidade.",
        "exemplo": "G-EXEMPLO123",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    }
}
```

## f3base_gtm_container_id

```json
{
    "rotulo": "Google Tag Manager — ID do contêiner",
    "descricao": "Identificador do contêiner do Gerenciador de Tags.",
    "campo": "texto",
    "impacto": "Preenchido, publica o contêiner e objetos de evento, além das tags diretas configuradas. Confira tags repetidas no contêiner: podem duplicar eventos. Vazio não carrega GTM nem cria seus objetos; os slots diretos permanecem independentes.",
    "exemplo": "Ilustrativo, na forma que o próprio Google usa na documentação: GTM-XXXXXXX. O valor real aparece no painel do contêiner.",
    "ajuda": {
        "funcionamento": "Adiciona o GTM aos slots diretos configurados. Não suprime GA4, Google Ads, Meta, LinkedIn ou Clarity.",
        "escolha": "Configure somente se o contêiner for necessário; confira tags e gatilhos para evitar eventos repetidos.",
        "vantagens": "Permite gestão de tags pelo contêiner autorizado.",
        "limitacoes": "O Core não controla tags independentes dentro do GTM; confira consentimento e duplicidade.",
        "exemplo": "GTM-EXEMPLO",
        "vazio": "Vazio não injeta GTM nem objetos de evento do Core para o contêiner; preserva as tags diretas."
    }
}
```

## f3base_google_ads

```json
{
    "rotulo": "Google Ads — conversão",
    "descricao": "A conta e a ação de conversão que recebem o clique no botão de contato.",
    "campo": "grupo",
    "subcampos": {
        "conversion_id": {
            "tipo": "texto",
            "rotulo": "ID de conversão",
            "descricao": "O identificador da conta de Google Ads que recebe a conversão.",
            "impacto": "Preenchido junto com o rótulo, o clique no botão de contato passa a ser registrado como conversão na conta do Google Ads, e as campanhas passam a otimizar por ele em vez de otimizar por cliques. Faltando este campo, nenhuma conversão é enviada ao Google Ads e o investimento continua sendo decidido sem saber quem procurou contato.",
            "exemplo": "Ilustrativo, na forma que o próprio Google usa na documentação: AW-000000000. O valor real aparece na ação de conversão da conta.",
            "ajuda": {
                "funcionamento": "O identificador da conta de Google Ads que recebe a conversão.",
                "escolha": "Informe o AW- da conta de destino.",
                "vantagens": "Direciona conversões à conta correta.",
                "limitacoes": "Não identifica um anúncio individual; isso vem dos IDs/UTMs da visita.",
                "exemplo": "AW-123456789",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "conversion_label": {
            "tipo": "texto",
            "rotulo": "Rótulo da conversão",
            "descricao": "A segunda metade do endereço da conversão: qual ação da conta recebe o clique.",
            "impacto": "É ele que diz QUAL ação de conversão recebe o clique. Preenchido junto com o ID, a conversão chega à ação certa. Vazio, nada é enviado: um envio sem rótulo chegaria à conta sem dizer a que ação pertence, e o relatório de campanha não teria onde somá-lo.",
            "exemplo": "Ilustrativo: rotulo-da-acao-de-conversao. O valor real é gerado pelo Google junto com a ação e aparece ao lado do ID de conversão.",
            "ajuda": {
                "funcionamento": "A segunda metade do endereço da conversão: qual ação da conta recebe o clique.",
                "escolha": "Copie o rótulo da ação de conversão escolhida na mesma conta.",
                "vantagens": "Separa a ação Contato de outras conversões da conta.",
                "limitacoes": "Rótulo incorreto pode impedir a recepção mesmo com AW- válido.",
                "exemplo": "Use o rótulo real da ação; vazio não cria uma ação automaticamente.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "A conta e a ação de conversão que recebem o clique no botão de contato.",
        "escolha": "Copie o identificador/token da propriedade e conta corretas; confirme o serviço no diagnóstico antes de medir conversões.",
        "vantagens": "Centraliza a identificação e evita editar o tema a cada alteração de conta.",
        "limitacoes": "Identificador válido não comprova entrega. Evite a mesma tag simultaneamente no Core, tema e GTM. Token deve ficar restrito à administração.",
        "exemplo": "Use a conta do site e faça um envio marcado como teste; confira recebimento no serviço autorizado.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_meta_pixel_id

```json
{
    "rotulo": "Meta — Pixel",
    "descricao": "Identificador do Pixel usado por campanhas de Facebook e Instagram.",
    "campo": "texto",
    "impacto": "Preenchido, o site publica o Pixel da Meta e envia a ele as páginas vistas e o contato — é o que permite às campanhas de Facebook e Instagram saber o que aconteceu depois do clique no anúncio. Vazio, nenhum código da Meta existe na página e essas campanhas otimizam sem resultado de volta.",
    "exemplo": "Ilustrativo: 000000000000000 — somente dígitos. O valor real aparece no Gerenciador de Eventos da Meta.",
    "ajuda": {
        "funcionamento": "Preenchido, o site publica o Pixel da Meta e envia a ele as páginas vistas e o contato — é o que permite às campanhas de Facebook e Instagram saber o que aconteceu depois do clique no anúncio. Vazio, nenhum código da Meta existe na página e essas campanhas otimizam sem resultado de volta.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Identifica o pixel de destino para eventos e CAPI configurados.",
        "limitacoes": "ID público não é token nem prova recebimento; CAPI exige credencial separada.",
        "exemplo": "123456789012345",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    }
}
```

## f3base_meta_capi_token

```json
{
    "rotulo": "Meta — token do envio de servidor",
    "descricao": "Credencial do conjunto de dados do Pixel, usada para enviar o contato do servidor.",
    "campo": "segredo",
    "impacto": "Preenchido, o contato passa a ser enviado também do servidor para a Meta, com o mesmo identificador de evento que o navegador manda — é essa identidade que faz os dois caminhos contarem uma conversão só, e é ela que recupera as conversões que o navegador perde por bloqueio ou por falha de rede. Vazio, existe apenas o envio pelo navegador, e o que ele perder está perdido.",
    "exemplo": "Este campo não tem exemplo de valor, porque um valor de exemplo aqui seria uma credencial. O token é gerado no Gerenciador de Eventos da Meta, nas configurações do conjunto de dados do Pixel. Ele é o único campo desta tela que nunca viaja no arquivo de configuração do pacote: é gravado só aqui, ou pelo canal de manutenção.",
    "ajuda": {
        "funcionamento": "Preenchido, o contato passa a ser enviado também do servidor para a Meta, com o mesmo identificador de evento que o navegador manda — é essa identidade que faz os dois caminhos contarem uma conversão só, e é ela que recupera as conversões que o navegador perde por bloqueio ou por falha de rede. Vazio, existe apenas o envio pelo navegador, e o que ele perder está perdido.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    }
}
```

## f3base_linkedin_partner_id

```json
{
    "rotulo": "LinkedIn — identificador de parceiro",
    "descricao": "Identificador da conta de anúncios do LinkedIn.",
    "campo": "texto",
    "impacto": "Preenchido, o site publica a etiqueta do LinkedIn e passa a registrar as páginas vistas por quem chega de campanhas de lá. Vazio, nenhum código do LinkedIn existe na página e as campanhas do canal ficam sem retorno de audiência.",
    "exemplo": "Ilustrativo: 0000000 — somente dígitos. O valor real aparece no Campaign Manager do LinkedIn.",
    "ajuda": {
        "funcionamento": "Preenchido, o site publica a etiqueta do LinkedIn e passa a registrar as páginas vistas por quem chega de campanhas de lá. Vazio, nenhum código do LinkedIn existe na página e as campanhas do canal ficam sem retorno de audiência.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Identifica a conta do Insight Tag.",
        "limitacoes": "Não é a ID de conversão nem autorização à Lead Sync API.",
        "exemplo": "123456",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    }
}
```

## f3base_linkedin_conversion_id

```json
{
    "rotulo": "LinkedIn — conversão",
    "descricao": "Identificador da conversão do LinkedIn disparada no clique do botão de contato.",
    "campo": "texto",
    "impacto": "Preenchido, o clique no botão de contato passa a ser registrado como conversão no LinkedIn, e as campanhas de lá passam a otimizar por contato. Vazio, o identificador de parceiro sozinho registra apenas visitas: nenhuma conversão é declarada.",
    "exemplo": "Ilustrativo: 00000000 — somente dígitos. O valor real é gerado ao criar a conversão no Campaign Manager do LinkedIn.",
    "ajuda": {
        "funcionamento": "Preenchido, o clique no botão de contato passa a ser registrado como conversão no LinkedIn, e as campanhas de lá passam a otimizar por contato. Vazio, o identificador de parceiro sozinho registra apenas visitas: nenhuma conversão é declarada.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Associa conversão à regra cadastrada no LinkedIn.",
        "limitacoes": "Regra e conta precisam corresponder; não importa contatos nativos.",
        "exemplo": "654321",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    }
}
```

## f3base_atribuicao

```json
{
    "rotulo": "Origem do contato",
    "descricao": "Qual campanha leva o crédito pelo contato, e por quanto tempo ela o mantém.",
    "campo": "grupo",
    "subcampos": {
        "modelo": {
            "tipo": "enum",
            "rotulo": "Campanha que leva o crédito",
            "descricao": "A primeira que trouxe o visitante, ou a última antes do contato.",
            "impacto": "Escolher a primeira visita credita quem descobriu o cliente, e favorece campanhas de topo; escolher a última credita quem estava lá no momento do contato, e favorece campanhas de retomada. O relatório de cada canal muda com esta escolha, e comparar dois períodos com escolhas diferentes compara coisas diferentes.",
            "exemplo": "Ilustrativo: a primeira visita, que é o padrão deste site.",
            "opcoes": {
                "first-touch": "a primeira visita — a campanha que descobriu o cliente",
                "last-touch": "a última visita — a campanha que fechou o contato"
            },
            "ajuda": {
                "funcionamento": "Escolher a primeira visita credita quem descobriu o cliente, e favorece campanhas de topo; escolher a última credita quem estava lá no momento do contato, e favorece campanhas de retomada. O relatório de cada canal muda com esta escolha, e comparar dois períodos com escolhas diferentes compara coisas diferentes.",
                "escolha": "Sessão acompanha a navegação; primeiro toque valoriza descoberta; último toque valoriza a origem mais recente observada.",
                "vantagens": "Permite uma comparação consistente entre campanhas.",
                "limitacoes": "Mudar modelo não reescreve histórico e não prova causalidade.",
                "exemplo": "Primeiro toque: descoberta via Instagram, conversão posterior por navegação direta.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "ttl_dias": {
            "tipo": "inteiro",
            "rotulo": "Por quantos dias a origem é lembrada",
            "descricao": "Prazo em que a origem do visitante continua guardada no navegador dele.",
            "impacto": "É a janela em que o visitante pode sumir e voltar sem perder a origem. Um prazo curto credita como direto quem voltou depois dele; um prazo longo mantém a campanha antiga levando o crédito muito depois de ela ter deixado de influenciar a decisão.",
            "exemplo": "Ilustrativo: 30, o prazo que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "É a janela em que o visitante pode sumir e voltar sem perder a origem. Um prazo curto credita como direto quem voltou depois dele; um prazo longo mantém a campanha antiga levando o crédito muito depois de ela ter deixado de influenciar a decisão.",
                "escolha": "Escolha quantos dias conservar uma origem no navegador com consentimento.",
                "vantagens": "Reconhece retornos dentro da janela configurada.",
                "limitacoes": "Não é retenção do banco; bloqueio/limpeza de cookies ou outro dispositivo quebra o vínculo.",
                "exemplo": "30 dias de atribuição.",
                "vazio": "Zero é recusado quando abaixo do mínimo do schema; não significa retenção ilimitada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Qual campanha leva o crédito pelo contato, e por quanto tempo ela o mantém.",
        "escolha": "Use primeiro toque para analisar a descoberta e último toque para a campanha mais recente observada.",
        "vantagens": "Conserva a origem durante navegação interna, dentro da janela e do consentimento.",
        "limitacoes": "A janela de atribuição não é a retenção do banco. Cookie bloqueado, outra origem/dispositivo e ausência de consentimento reduzem o vínculo.",
        "exemplo": "Uma campanha de Instagram pode continuar identificada no formulário de uma página interna; não identifica a pessoa em outro dispositivo.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_verificacao_google

```json
{
    "rotulo": "Verificação de domínio — Google",
    "descricao": "Código que comprova ao Google que este domínio é seu.",
    "campo": "texto",
    "impacto": "Preenchido, o site publica no cabeçalho a etiqueta que comprova a posse do domínio, e a propriedade do Search Console pode ser verificada — é o que destrava o relatório de busca e o envio de sitemap. Vazio, nenhuma etiqueta é publicada; a verificação por DNS continua sendo uma alternativa que dispensa este campo.",
    "exemplo": "Ilustrativo: valor-de-verificacao-do-console. O valor real é fornecido pelo Search Console ao escolher a verificação por etiqueta HTML.",
    "ajuda": {
        "funcionamento": "Preenchido, o site publica no cabeçalho a etiqueta que comprova a posse do domínio, e a propriedade do Search Console pode ser verificada — é o que destrava o relatório de busca e o envio de sitemap. Vazio, nenhuma etiqueta é publicada; a verificação por DNS continua sendo uma alternativa que dispensa este campo.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Publica a verificação HTML administrada pelo Core.",
        "limitacoes": "Não cria propriedade nem concede acesso ao Search Console.",
        "exemplo": "token-fornecido-pelo-search-console",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    }
}
```

## f3base_verificacao_meta

```json
{
    "rotulo": "Verificação de domínio — Meta",
    "descricao": "Código que comprova à Meta que este domínio é seu.",
    "campo": "texto",
    "impacto": "Preenchido, o site publica a etiqueta que reivindica o domínio no Gerenciador de Negócios — é o que permite controlar quem pode anunciar com links deste site e configurar eventos de página. Vazio, nenhuma etiqueta é publicada e o domínio permanece sem dono declarado para a Meta.",
    "exemplo": "Ilustrativo: valor-de-verificacao-do-dominio. O valor real é fornecido pelo Gerenciador de Negócios ao reivindicar o domínio.",
    "ajuda": {
        "funcionamento": "Preenchido, o site publica a etiqueta que reivindica o domínio no Gerenciador de Negócios — é o que permite controlar quem pode anunciar com links deste site e configurar eventos de página. Vazio, nenhuma etiqueta é publicada e o domínio permanece sem dono declarado para a Meta.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Publica a marca de verificação do domínio.",
        "limitacoes": "Não comprova permissões de leads, pixel ou páginas.",
        "exemplo": "token-fornecido-pelo-business-manager",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    }
}
```

## f3base_consentimento

```json
{
    "rotulo": "Consentimento",
    "descricao": "O que o site faz antes de o visitante decidir, e como ele muda de ideia depois.",
    "campo": "grupo",
    "subcampos": {
        "padrao": {
            "tipo": "enum",
            "rotulo": "O que vale antes de o visitante decidir",
            "descricao": "A posição do site na primeira visita, antes de qualquer clique do visitante.",
            "impacto": "Em pré-aprovado, a medição começa na primeira visita e quem recusa interrompe a partir do clique: os números cobrem quase todo mundo. Em negado, nada é carregado até o aceite, e os números passam a cobrir só quem aceitou — a diferença aparece como queda de tráfego no relatório, sem que o tráfego tenha caído. A escolha é jurídica antes de ser técnica. O QUE A RECUSA TARDIA NÃO DESFAZ: ela vale do clique em diante e não apaga o que já foi enviado. Google Analytics e Google Ads recebem a recusa como atualização de consentimento e passam a operar sem armazenamento no dispositivo; o que já chegou ao Google permanece com ele. Pixel da Meta e Insight Tag do LinkedIn não têm mecanismo equivalente: se o script deles já carregou nesta página, recusar não o descarrega — ele fica ali até a navegação seguinte. O que este site garante a partir da recusa é que nenhum evento novo é enviado a eles, e que na página seguinte eles não voltam a ser carregados. Em negado nada disso chega a carregar, e é por isso que nesse modo o script de consentimento é servido bloqueando o carregamento da página: ali a ordem é a garantia, e ela custa os 5.085 bytes comprimidos desse script no caminho crítico da página.",
            "exemplo": "Ilustrativo: pré-aprovado, que é a posição deste site.",
            "opcoes": {
                "pre-aprovado": "pré-aprovado — a medição começa e o visitante pode recusar",
                "negado": "negado — nada é medido até o visitante aceitar"
            },
            "ajuda": {
                "funcionamento": "Em pré-aprovado, a medição começa na primeira visita e quem recusa interrompe a partir do clique: os números cobrem quase todo mundo. Em negado, nada é carregado até o aceite, e os números passam a cobrir só quem aceitou — a diferença aparece como queda de tráfego no relatório, sem que o tráfego tenha caído. A escolha é jurídica antes de ser técnica. O QUE A RECUSA TARDIA NÃO DESFAZ: ela vale do clique em diante e não apaga o que já foi enviado. Google Analytics e Google Ads recebem a recusa como atualização de consentimento e passam a operar sem armazenamento no dispositivo; o que já chegou ao Google permanece com ele. Pixel da Meta e Insight Tag do LinkedIn não têm mecanismo equivalente: se o script deles já carregou nesta página, recusar não o descarrega — ele fica ali até a navegação seguinte. O que este site garante a partir da recusa é que nenhum evento novo é enviado a eles, e que na página seguinte eles não voltam a ser carregados. Em negado nada disso chega a carregar, e é por isso que nesse modo o script de consentimento é servido bloqueando o carregamento da página: ali a ordem é a garantia, e ela custa os 5.085 bytes comprimidos desse script no caminho crítico da página.",
                "escolha": "Pré-aprovado ou exigir aceite afetam o estado inicial conforme a política vigente do site.",
                "vantagens": "Define comportamento antes da primeira decisão.",
                "limitacoes": "Alterar valor não é aprovação jurídica nem autoriza ampliar a coleta automaticamente.",
                "exemplo": "Exigir aceite aguarda a ação do visitante.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "controle_rodape": {
            "tipo": "booleano",
            "rotulo": "Link de revisão no rodapé",
            "descricao": "Instrumento permanente para o visitante rever a decisão dele.",
            "impacto": "Ligado, toda página ganha no rodapé um link que reabre a decisão — é o caminho pelo qual quem aceitou pode recusar depois, e a demonstração de que a escolha é reversível. Desligado, o visitante que mudar de ideia não tem por onde: a decisão dele fica presa até o prazo abaixo vencer.",
            "exemplo": "Ilustrativo: ligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "Ligado, toda página ganha no rodapé um link que reabre a decisão — é o caminho pelo qual quem aceitou pode recusar depois, e a demonstração de que a escolha é reversível. Desligado, o visitante que mudar de ideia não tem por onde: a decisão dele fica presa até o prazo abaixo vencer.",
                "escolha": "Mantenha acesso persistente às preferências para consulta e revogação.",
                "vantagens": "O visitante pode mudar a escolha após fechar o painel.",
                "limitacoes": "Se desligar, o tema deve oferecer outro controle acessível.",
                "exemplo": "Preferências de privacidade no rodapé.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "aviso_primeira_visita": {
            "tipo": "booleano",
            "rotulo": "Aviso na primeira visita",
            "descricao": "Faixa não bloqueante exibida a quem chega pela primeira vez.",
            "impacto": "Ligado, quem chega pela primeira vez vê uma faixa na base da página avisando que o site mede a navegação; ela não bloqueia a leitura, não espera resposta e oferece o controle do rodapé. O link da política de privacidade aparece quando houver uma página pública válida. Desligado — que é como o site é entregue —, o único ponto de decisão visível é o link do rodapé, que está em toda página publicada. Este campo NÃO decide o que é medido: a medição segue a política de consentimento acima, e o registro por visitante nasce onde ela permite medir, com ou sem a faixa.",
            "exemplo": "Ilustrativo: desligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "Ligado, quem chega pela primeira vez vê uma faixa na base da página avisando que o site mede a navegação; ela não bloqueia a leitura, não espera resposta e oferece o controle do rodapé. O link da política de privacidade aparece quando houver uma página pública válida. Desligado — que é como o site é entregue —, o único ponto de decisão visível é o link do rodapé, que está em toda página publicada. Este campo NÃO decide o que é medido: a medição segue a política de consentimento acima, e o registro por visitante nasce onde ela permite medir, com ou sem a faixa.",
                "escolha": "Ative se a política exige mostrar a explicação na entrada.",
                "vantagens": "Torna a escolha mais visível.",
                "limitacoes": "A abertura ocupa a tela; mantenha ações claras em dispositivos pequenos.",
                "exemplo": "Painel abre na primeira visita elegível.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "ttl_dias": {
            "tipo": "inteiro",
            "rotulo": "Por quantos dias a decisão vale",
            "descricao": "Prazo em que a recusa e o novo aceite continuam guardados no navegador.",
            "impacto": "É o prazo em que a recusa continua sendo respeitada sem perguntar de novo. Vencido, o visitante volta à posição padrão do site e é medido outra vez até recusar de novo. Prazo curto pergunta demais; prazo longo mantém a decisão por mais tempo do que ela costuma ser lembrada.",
            "exemplo": "Ilustrativo: 180, o prazo que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "É o prazo em que a recusa continua sendo respeitada sem perguntar de novo. Vencido, o visitante volta à posição padrão do site e é medido outra vez até recusar de novo. Prazo curto pergunta demais; prazo longo mantém a decisão por mais tempo do que ela costuma ser lembrada.",
                "escolha": "Defina por quanto tempo lembrar a escolha de consentimento.",
                "vantagens": "Evita repetir a pergunta a cada página.",
                "limitacoes": "Outra versão de política pode exigir nova decisão; o prazo não substitui revogação.",
                "exemplo": "180 dias de escolha lembrada.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "modo": {
            "tipo": "enum",
            "rotulo": "Modo de consentimento",
            "descricao": "Legado preserva a política vigente. Granular solicita decisões separadas de medição e publicidade; cookies antigos não comprovam escolhas granulares.",
            "impacto": "Legado preserva a política vigente. Granular solicita decisões separadas de medição e publicidade; cookies antigos não comprovam escolhas granulares.",
            "exemplo": "Granular mediante mudança explícita.",
            "opcoes": {
                "legado": "Legado",
                "granular": "Por categoria"
            },
            "ajuda": {
                "funcionamento": "Legado preserva a política vigente. Granular solicita decisões separadas de medição e publicidade; cookies antigos não comprovam escolhas granulares.",
                "escolha": "Legado preserva a política única; por categorias separa medição e publicidade.",
                "vantagens": "Expõe escolhas distintas ao visitante.",
                "limitacoes": "Tags fora do Core precisam respeitar as mesmas categorias.",
                "exemplo": "Recusar publicidade mantém formulário funcional.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "politica_versao": {
            "tipo": "texto",
            "rotulo": "Versão da política",
            "descricao": "Identifica a política declarada. O runtime combina a versão com a assinatura das regras vigentes; mudanças incompatíveis solicitam nova decisão sem atribuir consentimento retroativo.",
            "impacto": "Identifica a política declarada. O runtime combina a versão com a assinatura das regras vigentes; mudanças incompatíveis solicitam nova decisão sem atribuir consentimento retroativo.",
            "exemplo": "1",
            "ajuda": {
                "funcionamento": "Identifica a política declarada. O runtime combina a versão com a assinatura das regras vigentes; mudanças incompatíveis solicitam nova decisão sem atribuir consentimento retroativo.",
                "escolha": "Troque a versão ao mudar materialmente as finalidades e o texto aprovado.",
                "vantagens": "Permite distinguir decisões de políticas diferentes.",
                "limitacoes": "Trocar a cada atualização causaria novas solicitações desnecessárias.",
                "exemplo": "2026-09",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "gtm_separacao_verificada": {
            "tipo": "booleano",
            "rotulo": "Contêiner GTM respeita as categorias",
            "descricao": "Marque somente após conferir as regras do contêiner. Sem essa confirmação, o modo granular só carrega GTM com medição e publicidade autorizadas.",
            "impacto": "Marque somente após conferir as regras do contêiner. Sem essa confirmação, o modo granular só carrega GTM com medição e publicidade autorizadas.",
            "exemplo": "Desmarcado até verificar o contêiner.",
            "ajuda": {
                "funcionamento": "Marque somente após conferir as regras do contêiner. Sem essa confirmação, o modo granular só carrega GTM com medição e publicidade autorizadas.",
                "escolha": "Marque apenas depois de testar a separação de tags por categoria no GTM.",
                "vantagens": "Registra uma pré-condição operacional para o contêiner.",
                "limitacoes": "É declaração do operador; não inspeciona automaticamente todas as tags do GTM.",
                "exemplo": "Teste recusa de publicidade antes de marcar.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "painel": {
            "tipo": "enum",
            "rotulo": "Apresentação do painel de consentimento",
            "descricao": "Padrão oferece estilos completos. Tema herda o desenho do site: exige CSS, contraste, foco e navegação por teclado adequados.",
            "impacto": "O modo tema não muda consentimento nem categorias.",
            "exemplo": "Use tema apenas com estilos conferidos em celular e teclado.",
            "opcoes": {
                "padrao": "Padrão do plugin",
                "tema": "Estilo fornecido pelo tema"
            },
            "ajuda": {
                "funcionamento": "O modo tema não muda consentimento nem categorias.",
                "escolha": "Escolha o regime conforme a política aprovada do site e teste aceitar, recusar e revogar cada categoria.",
                "vantagens": "Mantém a decisão do visitante separada da captura funcional do formulário.",
                "limitacoes": "Revogar interrompe novos envios controlados pelo Core. Tags instaladas pelo tema ou pelo GTM exigem configuração correspondente.",
                "exemplo": "Use tema apenas com estilos conferidos em celular e teclado.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "O que o site faz antes de o visitante decidir, e como ele muda de ideia depois.",
        "escolha": "Escolha o regime conforme a política aprovada do site e teste aceitar, recusar e revogar cada categoria.",
        "vantagens": "Mantém a decisão do visitante separada da captura funcional do formulário.",
        "limitacoes": "Revogar interrompe novos envios controlados pelo Core. Tags instaladas pelo tema ou pelo GTM exigem configuração correspondente.",
        "exemplo": "Em modo por categorias, recusar publicidade impede Pixel/Ads mesmo quando medição estiver permitida.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_retencao_meses

```json
{
    "rotulo": "Guarda dos contatos recebidos (meses)",
    "descricao": "Por quanto tempo os registros de contato ficam no site antes da limpeza automática.",
    "campo": "inteiro",
    "impacto": "É o prazo que a limpeza automática usa: passado ele, o registro do contato vai para a lixeira e depois é eliminado, com o número de registros anotado. Um prazo longo mantém disponível o histórico comercial e mantém dado pessoal guardado por mais tempo do que a finalidade justifica; um prazo curto faz o contrário. O prazo declarado aqui governa a limpeza mesmo quando o site não tem uma página de política de privacidade. ZERO NÃO É ACEITO e não vira nada: a gravação é RECUSADA e o prazo anterior continua valendo — o mínimo é um mês.",
    "exemplo": "Ilustrativo: 12, o prazo que este site usa por padrão.",
    "ajuda": {
        "funcionamento": "É o prazo que a limpeza automática usa: passado ele, o registro do contato vai para a lixeira e depois é eliminado, com o número de registros anotado. Um prazo longo mantém disponível o histórico comercial e mantém dado pessoal guardado por mais tempo do que a finalidade justifica; um prazo curto faz o contrário. O prazo declarado aqui governa a limpeza mesmo quando o site não tem uma página de política de privacidade. ZERO NÃO É ACEITO e não vira nada: a gravação é RECUSADA e o prazo anterior continua valendo — o mínimo é um mês.",
        "escolha": "Defina por quanto tempo a operação precisa manter contatos, considerando também as retenções próprias de eventos e logs.",
        "vantagens": "Limita crescimento e acúmulo de dados pessoais antigos.",
        "limitacoes": "Dados eliminados pelo processo de retenção deixam de participar das análises; exportações externas têm sua própria gestão.",
        "exemplo": "Ilustrativo: 12, o prazo que este site usa por padrão.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_acessos

```json
{
    "rotulo": "Acessos do servidor",
    "descricao": "Contagem dos logs fechados em Medição → Acessos.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Somar acessos do servidor",
            "descricao": "Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.",
            "impacto": "Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.",
            "exemplo": "Ligado.",
            "ajuda": {
                "funcionamento": "Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.",
                "escolha": "Ative para somar os logs deste site.",
                "vantagens": "Inclui robôs e respostas que não executam JavaScript.",
                "limitacoes": "Exige arquivo legível pelo PHP e executor periódico.",
                "exemplo": "Desligar preserva os agregados anteriores.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "padrao_do_log": {
            "tipo": "texto",
            "rotulo": "Padrão dos arquivos de log",
            "descricao": "Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.",
            "impacto": "Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.",
            "exemplo": "~/logs/exemplo.com.br/https/access.log.*",
            "ajuda": {
                "funcionamento": "Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.",
                "escolha": "Use o diretório exclusivo deste domínio, com arquivos datados.",
                "vantagens": "Permite retomada e substituição idempotente da contribuição por arquivo.",
                "limitacoes": "Diretório de vários domínios mistura tráfego; o Core o recusa quando detectável.",
                "exemplo": "/caminho/deste-site/access.log.*",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "caminhos_excluidos": {
            "tipo": "lista",
            "rotulo": "Prefixos excluídos do detalhe",
            "descricao": "Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.",
            "impacto": "Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.",
            "exemplo": "/wp-admin/, /wp-json/mcp/",
            "ajuda": {
                "funcionamento": "Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.",
                "escolha": "Exclua prefixos privados ou estritamente técnicos.",
                "vantagens": "Reduz exposição de caminhos que contenham identificadores pessoais.",
                "limitacoes": "As contagens excluídas não têm detalhe por URL; reclassificação exige logs disponíveis.",
                "exemplo": "/wp-admin/; lista vazia é preservada.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "retencao_horaria_dias": {
            "tipo": "inteiro",
            "rotulo": "Retenção horária de agentes em dias",
            "descricao": "Mantém contagens por hora UTC de 1 a 90 dias, dentro da retenção diária. Padrão de 30 dias. Não guarda IP nem User-Agent bruto.",
            "impacto": "Permite comparar horários de busca; aumenta o agregado armazenado.",
            "exemplo": "30 dias",
            "ajuda": {
                "funcionamento": "Permite comparar horários de busca; aumenta o agregado armazenado.",
                "escolha": "Use 30 dias como janela inicial para comparar horários de agentes.",
                "vantagens": "Permite observar concentração de requisições por hora UTC.",
                "limitacoes": "Agregado não guarda caminho ou método nessa granularidade; máximo de 90 dias.",
                "exemplo": "30 dias de horas e 25 meses de resumo diário.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "retencao_meses": {
            "tipo": "inteiro",
            "rotulo": "Retenção do agregado em meses",
            "descricao": "Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.",
            "impacto": "Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.",
            "exemplo": "25 meses.",
            "ajuda": {
                "funcionamento": "Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.",
                "escolha": "Escolha o horizonte de comparações do agregado diário.",
                "vantagens": "Reduz crescimento do banco mantendo histórico útil.",
                "limitacoes": "Prazo menor elimina agregados antigos; não altera a retenção do host.",
                "exemplo": "6 mantém aproximadamente seis meses de agregados.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "padroes_hospedagem": {
            "tipo": "lista",
            "rotulo": "Marcadores de agentes da hospedagem",
            "descricao": "Textos literais presentes no User-Agent identificam tráfego declarado da hospedagem. IP compartilhado não é prova de origem.",
            "impacto": "Textos literais presentes no User-Agent identificam tráfego declarado da hospedagem. IP compartilhado não é prova de origem.",
            "exemplo": "Use somente marcadores confirmados nos logs.",
            "ajuda": {
                "funcionamento": "Textos literais presentes no User-Agent identificam tráfego declarado da hospedagem. IP compartilhado não é prova de origem.",
                "escolha": "Informe marcas literais conhecidas do User-Agent da hospedagem.",
                "vantagens": "Separa sondas da hospedagem dos buscadores.",
                "limitacoes": "Marca declarada não autentica o operador; não use texto genérico como bot.",
                "exemplo": "Um marcador documentado pelo provedor, por linha.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Contagem dos logs fechados em Medição → Acessos.",
        "escolha": "Informe somente logs deste site que o PHP pode ler e exclusões deliberadas de caminhos técnicos.",
        "vantagens": "Permite analisar respostas HTTP, robôs e 404 mesmo sem executar JavaScript.",
        "limitacoes": "Requisições não equivalem a sessões. O log comum não contém o cookie de teste; exclusões e regras de classificação mudam a comparação histórica.",
        "exemplo": "Uma lista de exclusões vazia conserva todos os caminhos elegíveis; a atualização não a substitui.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_sessao

```json
{
    "rotulo": "Sessão de login",
    "descricao": "Prazo dos novos logins pelo formulário nativo. O diagnóstico informa o valor efetivo.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Manter login ao fechar o navegador",
            "descricao": "Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.",
            "impacto": "Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.",
            "exemplo": "Ligado.",
            "ajuda": {
                "funcionamento": "Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.",
                "escolha": "Ative quando a equipe deve continuar autenticada ao reabrir o navegador.",
                "vantagens": "Evita autenticações repetidas de usuários autorizados.",
                "limitacoes": "Maior persistência exige cuidado em computadores compartilhados; não revoga sessões existentes.",
                "exemplo": "Desligar afeta novos logins, não a sessão analítica do visitante.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "dias": {
            "tipo": "inteiro",
            "rotulo": "Duração das novas sessões em dias",
            "descricao": "Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.",
            "impacto": "Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.",
            "exemplo": "90 dias.",
            "ajuda": {
                "funcionamento": "Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.",
                "escolha": "Escolha o prazo de autenticação WordPress conforme o uso e o risco.",
                "vantagens": "Evita exigir login frequente da equipe.",
                "limitacoes": "Prazo longo expõe sessões em computadores compartilhados; não trata sessão analítica.",
                "exemplo": "14 dias de login.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "modo": {
            "tipo": "enum",
            "rotulo": "Política das sessões",
            "descricao": "Legado conserva o prazo único e Lembrar-me. Por perfil respeita a escolha de lembrar e usa a regra mais restritiva aplicável. Novas sessões apenas.",
            "impacto": "Legado conserva o prazo único e Lembrar-me. Por perfil respeita a escolha de lembrar e usa a regra mais restritiva aplicável. Novas sessões apenas.",
            "exemplo": "Por perfil após revisar as regras.",
            "opcoes": {
                "legado": "Legado",
                "por-perfil": "Por papel ou capacidade"
            },
            "ajuda": {
                "funcionamento": "Legado conserva o prazo único e Lembrar-me. Por perfil respeita a escolha de lembrar e usa a regra mais restritiva aplicável. Novas sessões apenas.",
                "escolha": "Escolha prazo único ou regras por perfil/capacidade.",
                "vantagens": "Por perfil permite um prazo menor para funções sensíveis.",
                "limitacoes": "Regras sobrepostas usam a mais restritiva; a opção não muda senhas ou permissões.",
                "exemplo": "Uma regra de administradores pode usar prazo menor que a dos editores.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "regras": {
            "tipo": "json",
            "rotulo": "Regras de duração por perfil",
            "descricao": "Lista de regras com papel ou capacidade, dias e nucleo. A regra mais curta prevalece; manage_options sempre respeita o teto do núcleo. Nenhuma sessão existente é revogada.",
            "impacto": "Lista de regras com papel ou capacidade, dias e nucleo. A regra mais curta prevalece; manage_options sempre respeita o teto do núcleo. Nenhuma sessão existente é revogada.",
            "exemplo": "[{\"papel\":\"editor\",\"capacidade\":\"\",\"dias\":14,\"nucleo\":false}]",
            "ajuda": {
                "funcionamento": "Lista de regras com papel ou capacidade, dias e nucleo. A regra mais curta prevalece; manage_options sempre respeita o teto do núcleo. Nenhuma sessão existente é revogada.",
                "escolha": "Use papel/capacidade e duração para grupos que realmente precisam de exceção.",
                "vantagens": "A regra mais restritiva prevalece quando há sobreposição.",
                "limitacoes": "Altera novas sessões; não amplia permissões de usuário.",
                "exemplo": "Administradores com prazo menor que editores.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Prazo dos novos logins pelo formulário nativo. O diagnóstico informa o valor efetivo.",
        "escolha": "Escolha a duração de autenticação adequada a cada papel/capacidade e considere computadores compartilhados.",
        "vantagens": "Permite manter sessões de editores sem aplicar o mesmo prazo a todos os usuários.",
        "limitacoes": "Esta opção trata login WordPress, não o identificador de sessão analítica dos visitantes. Prazo longo aumenta exposição em equipamentos perdidos.",
        "exemplo": "Uma regra de administrador pode conservar o prazo do núcleo enquanto assinantes usam prazo próprio.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_comportamento

```json
{
    "rotulo": "Resumo de comportamento no próprio site",
    "descricao": "O resumo que o site guarda por conta própria sobre como as páginas são usadas.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Guardar o resumo no site",
            "descricao": "O resumo é somado por dia e por página, sem identificar visitante.",
            "impacto": "Ligado, ao sair de cada página o navegador envia uma vez os totais daquela visita — marcos de rolagem, seções vistas, cliques para fora, sinais de dificuldade, erros e tempo de carregamento — e o site os soma na linha do dia. É o que faz o quadro desta tela ter números sem depender de conta nenhuma de fornecedor. Desligado, nada é enviado nem guardado, e o quadro fica permanentemente vazio; o envio ao Google Analytics, quando configurado, não muda.",
            "exemplo": "Ilustrativo: ligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "O resumo é somado por dia e por página, sem identificar visitante.",
                "escolha": "Ative para observar interações consentidas no próprio site.",
                "vantagens": "Relaciona páginas e ações a sessões e formulários.",
                "limitacoes": "Bloqueios, recusa e saída abrupta reduzem cobertura; contagem não equivale a pessoas.",
                "exemplo": "Desativar interrompe novas coletas, preservando a retenção já definida.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "retencao_dias": {
            "tipo": "inteiro",
            "rotulo": "Por quantos dias o resumo é guardado",
            "descricao": "Prazo depois do qual as linhas antigas do resumo são apagadas pela limpeza automática.",
            "impacto": "A limpeza que já roda no site apaga as linhas mais antigas que este prazo. Um prazo maior permite comparar períodos distantes e faz a tabela crescer; um prazo menor mantém a tabela pequena e impede a comparação com o mesmo mês do ano passado. Este quadro não é arquivo histórico: quem precisa de série longa a tem no Google Analytics.",
            "exemplo": "Ilustrativo: 90, o prazo que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "A limpeza que já roda no site apaga as linhas mais antigas que este prazo. Um prazo maior permite comparar períodos distantes e faz a tabela crescer; um prazo menor mantém a tabela pequena e impede a comparação com o mesmo mês do ano passado. Este quadro não é arquivo histórico: quem precisa de série longa a tem no Google Analytics.",
                "escolha": "Escolha o período de agregados para tendências locais.",
                "vantagens": "Permite comparar volume sem guardar todos os detalhes pelo mesmo prazo.",
                "limitacoes": "Retenção não recupera eventos já eliminados.",
                "exemplo": "90 dias de agregados.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "retencao_eventos_dias": {
            "tipo": "inteiro",
            "rotulo": "Por quantos dias o registro detalhado é guardado",
            "descricao": "Prazo do registro que guarda visitante, sessão e horário de cada acontecimento — mais curto que o do resumo, e nunca maior.",
            "impacto": "O site guarda duas coisas diferentes. O RESUMO soma por dia e por página e não identifica ninguém; o REGISTRO DETALHADO guarda, para cada acontecimento, um apelido sorteado do navegador do visitante, o identificador da visita e o horário com precisão de milésimo — é ele que responde quanto tempo a pessoa levou para descer a página e se ela voltou e leu de novo. Por guardar isso, ele é dado pessoal, ainda que o apelido não diga quem a pessoa é: o prazo dele é curto de propósito e nunca pode passar o do resumo. Vencido o prazo, as linhas detalhadas são apagadas pela mesma limpeza automática e o resumo continua, porque ele não identifica ninguém.",
            "exemplo": "Ilustrativo: 30, o prazo que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "O site guarda duas coisas diferentes. O RESUMO soma por dia e por página e não identifica ninguém; o REGISTRO DETALHADO guarda, para cada acontecimento, um apelido sorteado do navegador do visitante, o identificador da visita e o horário com precisão de milésimo — é ele que responde quanto tempo a pessoa levou para descer a página e se ela voltou e leu de novo. Por guardar isso, ele é dado pessoal, ainda que o apelido não diga quem a pessoa é: o prazo dele é curto de propósito e nunca pode passar o do resumo. Vencido o prazo, as linhas detalhadas são apagadas pela mesma limpeza automática e o resumo continua, porque ele não identifica ninguém.",
                "escolha": "Defina a janela de detalhe necessária para cruzar a jornada com o lead.",
                "vantagens": "Prazo menor reduz dados pessoais e tamanho do banco.",
                "limitacoes": "Eventos expirados não aparecem nas notas CRM; agregados têm prazo separado.",
                "exemplo": "30 dias de eventos individuais.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "dias_no_painel": {
            "tipo": "inteiro",
            "rotulo": "Período mostrado no quadro",
            "descricao": "Quantos dias o quadro desta tela soma ao exibir os números.",
            "impacto": "Muda apenas o que esta tela mostra, nunca o que é guardado. Um período curto revela o efeito de uma mudança recente; um período longo dilui o dia atípico e mostra a tendência. O número aparece ao lado de cada total, para que ninguém leia o quadro sem saber de quantos dias ele fala. O TETO DELE É O PRAZO DO RESUMO, o campo duas linhas acima — e os quadros que vêm do REGISTRO DETALHADO cobrem o prazo DELE, que é o campo logo acima e é sempre menor ou igual: pedir aqui mais dias do que o registro guarda continua valendo para a série do agregado, e a tela Medição avisa quando os dois períodos divergem.",
            "exemplo": "Ilustrativo: 28, o período que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "Muda apenas o que esta tela mostra, nunca o que é guardado. Um período curto revela o efeito de uma mudança recente; um período longo dilui o dia atípico e mostra a tendência. O número aparece ao lado de cada total, para que ninguém leia o quadro sem saber de quantos dias ele fala. O TETO DELE É O PRAZO DO RESUMO, o campo duas linhas acima — e os quadros que vêm do REGISTRO DETALHADO cobrem o prazo DELE, que é o campo logo acima e é sempre menor ou igual: pedir aqui mais dias do que o registro guarda continua valendo para a série do agregado, e a tela Medição avisa quando os dois períodos divergem.",
                "escolha": "Escolha a janela inicial usada no painel de comportamento.",
                "vantagens": "Foca a leitura no período operacional relevante.",
                "limitacoes": "Não muda retenção nem coleta; período sem dados permanece indisponível.",
                "exemplo": "Últimos 30 dias.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "tempo_ativo": {
            "tipo": "booleano",
            "rotulo": "Estimar tempo ativo por bloco",
            "descricao": "Conta somente o bloco predominante com página visível e atividade recente. A estimativa não comprova atenção humana.",
            "impacto": "Conta somente o bloco predominante com página visível e atividade recente. A estimativa não comprova atenção humana.",
            "exemplo": "Ligado em instalações novas; a escolha já gravada é preservada.",
            "ajuda": {
                "funcionamento": "Conta somente o bloco predominante com página visível e atividade recente. A estimativa não comprova atenção humana.",
                "escolha": "Ative para medir intervalos de atividade observada com consentimento.",
                "vantagens": "Acrescenta contexto às páginas e jornadas.",
                "limitacoes": "Tempo ativo estimado não comprova leitura ou atenção.",
                "exemplo": "Uma aba oculta deixa de acumular tempo ativo.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "O resumo que o site guarda por conta própria sobre como as páginas são usadas.",
        "escolha": "Ajuste coleta e retenções ao período que precisa analisar, conferindo o tamanho do banco e a cobertura.",
        "vantagens": "Permite relacionar seções, formulários, erros e métricas a sessões observadas no próprio site.",
        "limitacoes": "Tempo ativo é estimado. Retenção detalhada menor que o período consultado reduz a jornada; contagens não são pessoas identificadas.",
        "exemplo": "Guarde eventos detalhados por 30 dias e agregados por 90; um relatório anterior a 30 dias não terá toda a jornada.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_origem_confiavel

```json
{
    "rotulo": "Como o site descobre o endereço do visitante",
    "descricao": "Quando o site está atrás de CDN ou proxy, o endereço real chega num cabeçalho.",
    "campo": "grupo",
    "subcampos": {
        "cabecalho": {
            "tipo": "texto",
            "rotulo": "Cabeçalho em que este site confia",
            "descricao": "Nome do cabeçalho que a sua CDN ou proxy escreve com o endereço do visitante.",
            "impacto": "Preenchido, o limite de envios por visitante passa a contar cada visitante separadamente mesmo atrás de CDN. Vazio — que é o padrão e é a posição segura —, o site conta pelo endereço da conexão: atrás de CDN esse endereço é o mesmo para todo mundo, e um único visitante intenso pode esgotar o limite do site inteiro. Preencher com o nome errado é pior que deixar vazio: o visitante passaria a escolher em que balde ele conta.",
            "exemplo": "Ilustrativo: X-Forwarded-For, ou CF-Connecting-IP em sites atrás da Cloudflare. Só preencha o cabeçalho que a sua hospedagem confirmar.",
            "ajuda": {
                "funcionamento": "Nome do cabeçalho que a sua CDN ou proxy escreve com o endereço do visitante.",
                "escolha": "Selecione apenas o cabeçalho documentado pelo proxy que está diante deste site.",
                "vantagens": "Permite aplicar cotas ao endereço recebido pelo proxy confiável.",
                "limitacoes": "Confiar em cabeçalho enviado diretamente pelo visitante permite falsificação.",
                "exemplo": "Vazio mantém REMOTE_ADDR.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "saltos": {
            "tipo": "inteiro",
            "rotulo": "Em que posição da lista está o endereço do visitante",
            "descricao": "Usado apenas quando o cabeçalho acima está preenchido.",
            "impacto": "É a POSIÇÃO contada do fim da lista do cabeçalho: 1 é o último elemento, que é o único escrito pelo seu próprio proxy. Um número menor que o real faz o site ler um endereço que o visitante escreveu; um número maior faz a leitura falhar e voltar ao endereço da conexão.",
            "exemplo": "Ilustrativo: 1, quando há uma única CDN na frente do site.",
            "ajuda": {
                "funcionamento": "É a POSIÇÃO contada do fim da lista do cabeçalho: 1 é o último elemento, que é o único escrito pelo seu próprio proxy. Um número menor que o real faz o site ler um endereço que o visitante escreveu; um número maior faz a leitura falhar e voltar ao endereço da conexão.",
                "escolha": "Informe a quantidade de proxies confirmados entre visitante e WordPress.",
                "vantagens": "Seleciona a posição correta no cabeçalho de origem.",
                "limitacoes": "Número errado permite atribuir IP do proxy ou valor falsificado.",
                "exemplo": "Um proxy documentado: um salto.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "redes_confiaveis": {
            "tipo": "lista",
            "rotulo": "De quais endereços os seus proxies falam com o site",
            "descricao": "Faixas de IP da sua CDN ou do seu balanceador, uma por linha, em notação de endereço ou de rede.",
            "impacto": "Preenchidas, só o pedido que chega de uma dessas faixas tem o cabeçalho acima lido; os outros voltam a contar pelo endereço da conexão. VAZIAS — que é como o site é entregue —, o cabeçalho acima é lido de QUALQUER conexão, e a tela emite um aviso apontando este campo: cabeçalho é texto que qualquer cliente manda, e quem alcança o servidor por fora da CDN escolhe em que balde do limite ele conta e qual endereço o site envia aos fornecedores de anúncio. É esta lista que fecha essa porta, e ela só é fechada por quem declara as faixas.",
            "exemplo": "Ilustrativo: 198.51.100.0/24 numa linha e 203.0.113.7 na outra. Só declare faixa que a sua hospedagem confirmar.",
            "ajuda": {
                "funcionamento": "Faixas de IP da sua CDN ou do seu balanceador, uma por linha, em notação de endereço ou de rede.",
                "escolha": "Cadastre somente redes verificadas da CDN/proxy.",
                "vantagens": "Restringe quem pode fornecer o cabeçalho de origem.",
                "limitacoes": "Faixas amplas aceitam origens não controladas; manter a lista requer operação.",
                "exemplo": "192.0.2.0/24 ilustra CIDR; não é uma rede real do seu proxy.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Quando o site está atrás de CDN ou proxy, o endereço real chega num cabeçalho.",
        "escolha": "Preencha somente quando a hospedagem documentar o proxy, o cabeçalho e suas redes confiáveis.",
        "vantagens": "Recupera o endereço de origem para cotas e diagnóstico quando existe um proxy comprovado.",
        "limitacoes": "Confiar em cabeçalho enviado pelo visitante permite falsificar a origem. Não use esta opção para excluir testes por IP e horário.",
        "exemplo": "Sem proxy confirmado, deixe cabeçalho e redes vazios e utilize REMOTE_ADDR.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_robots

```json
{
    "rotulo": "Robots.txt do plugin",
    "descricao": "Alterna entre o gerador do plugin e o arquivo físico original, com backup e restauração.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Utilizar o robots.txt do plugin",
            "descricao": "Ligado, guarda o original e verifica a entrega pública. Se a hospedagem interceptar a rota virtual, mantém um arquivo físico gerenciado e atualizado automaticamente.",
            "impacto": "Publica as regras do WordPress e dos plugins, com o sitemap disponível. O WP-Cron confirma a resposta HTTP e atualiza o arquivo gerenciado a cada hora e após mudanças reconhecidas de configuração. Desligado, retira somente o arquivo que ainda corresponde ao conteúdo gerado e restaura o original. Edições externas são preservadas. Sem original anterior, não cria um ao desligar. O diagnóstico informa falhas, conflitos e verificações pendentes.",
            "exemplo": "Ilustrativo: ligado, com o sitemap do núcleo ou do plugin de SEO.",
            "ajuda": {
                "funcionamento": "Ligado, guarda o original e verifica a entrega pública. Se a hospedagem interceptar a rota virtual, mantém um arquivo físico gerenciado e atualizado automaticamente.",
                "escolha": "Ative quando o Core for responsável pela política robots deste site.",
                "vantagens": "Mantém a política e uma reserva recuperável do original.",
                "limitacoes": "Não restringe acesso privado e não obriga bots a obedecer.",
                "exemplo": "A reserva reconhecida fica na pasta privada do Core.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Alterna entre o gerador do plugin e o arquivo físico original, com backup e restauração.",
        "escolha": "Mantenha um único responsável pelo robots.txt e confira a resposta pública após reconciliar.",
        "vantagens": "Centraliza regras do site e respeita arquivo de propriedade externa.",
        "limitacoes": "robots.txt não protege informação privada nem obriga um robô a cumprir a instrução. Proteger documentos exige regra de acesso do servidor.",
        "exemplo": "Uma documentação bloqueada por Require all denied continua protegida mesmo se o robô ignorar robots.txt.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_llms

```json
{
    "rotulo": "Arquivo llms.txt para leitores automáticos",
    "descricao": "Índice curto que apresenta o site a assistentes e agentes que o leem.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Publicar o llms.txt",
            "descricao": "Serve o arquivo em /llms.txt quando não existe um arquivo físico na raiz.",
            "impacto": "Ligado, o endereço /llms.txt passa a responder com um índice curto das páginas escolhidas — oferece contexto e links aos assistentes que consultam esse arquivo, sem garantir uso ou citação. Desligado, o endereço deixa de responder e a leitura automática volta a depender de rastreamento comum. Um arquivo físico na raiz do site sempre tem precedência sobre esta chave.",
            "exemplo": "Ilustrativo: ligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "Serve o arquivo em /llms.txt quando não existe um arquivo físico na raiz.",
                "escolha": "Ative para publicar o índice dos conteúdos públicos elegíveis.",
                "vantagens": "Oferece um ponto de descoberta em texto.",
                "limitacoes": "Não garante leitura nem citação por IA; depende da publicação da geração.",
                "exemplo": "Confira /llms.txt e o diagnóstico de entrega.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "introducao": {
            "tipo": "textarea",
            "rotulo": "Primeira frase do arquivo",
            "descricao": "Uma linha dizendo do que este site trata.",
            "impacto": "Preenchida, é a primeira frase que um leitor automático encontra, e ela resume o contexto do site. Vazia, o site usa a apresentação abaixo e, se ela também estiver vazia, a descrição cadastrada nas configurações gerais do WordPress — que serve, mas foi escrita para outra finalidade.",
            "exemplo": "Ilustrativo: \"Consultoria de operações para indústrias de médio porte, com atendimento em todo o país.\"",
            "ajuda": {
                "funcionamento": "Uma linha dizendo do que este site trata.",
                "escolha": "Escreva uma frase factual curta sobre o site.",
                "vantagens": "Dá contexto imediato ao leitor do índice.",
                "limitacoes": "Texto promocional impreciso também será publicado.",
                "exemplo": "Consultoria de tecnologia para empresas em crescimento.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "apresentacao": {
            "tipo": "textarea",
            "rotulo": "Apresentação do negócio",
            "descricao": "Um parágrafo dizendo o que o site é, para quem e com que oferta.",
            "impacto": "Descreve o site antes da lista de links quando o campo acima está vazio. Com a primeira frase preenchida, é ELA que sai, e este parágrafo fica de reserva; com os dois vazios, o arquivo usa a descrição cadastrada no WordPress. O texto oferece contexto ao leitor, sem garantir citações ou presença em respostas de assistentes.",
            "exemplo": "Ilustrativo: \"Somos uma consultoria de operações industriais para fábricas de 50 a 500 funcionários. Fazemos diagnóstico de linha, redesenho de processo e acompanhamento de indicadores, com contrato mensal e equipe em campo.\"",
            "ajuda": {
                "funcionamento": "Um parágrafo dizendo o que o site é, para quem e com que oferta.",
                "escolha": "Resuma público, oferta e finalidade do negócio.",
                "vantagens": "Ajuda a interpretar os links do índice.",
                "limitacoes": "Não substitui conteúdo das páginas nem comprova serviços não publicados.",
                "exemplo": "A empresa presta consultoria e mantém artigos públicos de tecnologia.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "modo": {
            "tipo": "enum",
            "rotulo": "Como a lista é formada",
            "descricao": "A escolha entre listar só o que foi escolhido na entrega e listar também o que for publicado depois.",
            "impacto": "Listando apenas o escolhido na entrega, o arquivo é previsível e toda página criada depois fica de fora para sempre. Listando apenas o publicado, ele acompanha o site e perde a ordem que alguém escolheu. Com os dois — que é como este site é entregue —, a curadoria vem primeiro e o resto entra em seguida: o arquivo continua vivo quando o site cresce, sem perder a ordem escolhida.",
            "exemplo": "Ilustrativo: os dois eixos juntos, com a lista escolhida na entrega à frente do que for publicado depois.",
            "opcoes": {
                "curada": "apenas a lista escolhida na entrega",
                "automatica": "apenas o conteúdo publicado dos tipos abaixo",
                "curada-mais-automatica": "os dois: a lista escolhida primeiro, o publicado em seguida"
            },
            "ajuda": {
                "funcionamento": "A escolha entre listar só o que foi escolhido na entrega e listar também o que for publicado depois.",
                "escolha": "Escolha curadoria fixa ou inclusão dos conteúdos publicados elegíveis.",
                "vantagens": "Curadoria oferece controle; enumeração acompanha novas publicações.",
                "limitacoes": "Enumeração amplia volume; curadoria precisa manutenção manual.",
                "exemplo": "Um site editorial pode enumerar artigos; uma página institucional pode usar curadoria.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "tipos": {
            "tipo": "multiescolha",
            "rotulo": "Tipos de conteúdo enumerados",
            "descricao": "Selecione os tipos públicos disponíveis neste site. Usado nos modos que enumeram o conteúdo publicado.",
            "impacto": "Os tipos marcados participam da lista automática do llms.txt e do llms-full.txt. Conteúdos privados, com senha ou noindex continuam excluídos. Desmarcar todos esvazia a seleção automática; os itens de curadoria continuam seguindo o modo escolhido.",
            "exemplo": "Ilustrativo: as páginas e os artigos do blog, que é como este site é entregue.",
            "opcoes": {
                "attachment": "Media (attachment)",
                "page": "Pages (page)",
                "post": "Posts (post)"
            },
            "ajuda": {
                "funcionamento": "Selecione os tipos públicos disponíveis neste site. Usado nos modos que enumeram o conteúdo publicado.",
                "escolha": "Selecione os tipos públicos com conteúdo editorial relevante.",
                "vantagens": "Permite incluir artigos e páginas sem conteúdo técnico repetitivo.",
                "limitacoes": "Só atua em modos que enumeram; não torna posts privados públicos.",
                "exemplo": "page e post; anexos continuam sujeitos à elegibilidade.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "markdown": {
            "tipo": "booleano",
            "rotulo": "Publicar páginas em Markdown",
            "descricao": "Disponibiliza versões de leitura das páginas públicas selecionadas e as anuncia no HTML.",
            "impacto": "Ligado, os links locais do índice apontam para alternativas Markdown. Conteúdo privado, com senha ou noindex fica fora. Desligado, os links apontam para o HTML. A conversão inclui o conteúdo editorial salvo; blocos dinâmicos e shortcodes não são executados.",
            "exemplo": "Ilustrativo: uma página de serviços ganha a alternativa /servicos/index.md.",
            "ajuda": {
                "funcionamento": "Ligado, os links locais do índice apontam para alternativas Markdown. Conteúdo privado, com senha ou noindex fica fora. Desligado, os links apontam para o HTML. A conversão inclui o conteúdo editorial salvo; blocos dinâmicos e shortcodes não são executados.",
                "escolha": "Ative para disponibilizar a representação Markdown individual.",
                "vantagens": "Facilita consumo do conteúdo público por agentes.",
                "limitacoes": "Não torna conteúdo privado público; geração acima do orçamento responde 503 temporário.",
                "exemplo": "/pagina.md quando a rota e a página forem elegíveis.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "full": {
            "tipo": "booleano",
            "rotulo": "Publicar também o texto integral",
            "descricao": "Serve /llms-full.txt com o conteúdo completo de cada item listado, em Markdown e sem resumo.",
            "impacto": "Ligado, o endereço /llms-full.txt passa a responder com o texto integral das mesmas páginas — reúne o corpo completo em um único arquivo, preservando títulos, listas, links e código. Usa a mesma seleção pública do índice e não corta textos pelo limite de palavras dos resumos. É uma segunda cópia do site em texto puro, com o custo de banda e de superfície que isso traz. Ligado é o padrão. Quando desligado, o endereço não responde: nenhum hook é registrado e a rota não existe.",
            "exemplo": "Ilustrativo: ligado, publica /llms-full.txt. Desligue quando não desejar reunir o conteúdo integral em um só arquivo.",
            "ajuda": {
                "funcionamento": "Ligado, o endereço /llms-full.txt passa a responder com o texto integral das mesmas páginas — reúne o corpo completo em um único arquivo, preservando títulos, listas, links e código. Usa a mesma seleção pública do índice e não corta textos pelo limite de palavras dos resumos. É uma segunda cópia do site em texto puro, com o custo de banda e de superfície que isso traz. Ligado é o padrão. Quando desligado, o endereço não responde: nenhum hook é registrado e a rota não existe.",
                "escolha": "Ative para publicar o índice integral dos conteúdos públicos elegíveis.",
                "vantagens": "Fornece texto completo usando o mesmo conversor do Markdown individual.",
                "limitacoes": "Pode aumentar tamanho e custo de geração; arquivos privados e noindex continuam excluídos.",
                "exemplo": "Novo site usa ativado; escolha false já gravada permanece false.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "indexavel": {
            "tipo": "booleano",
            "rotulo": "Deixar o arquivo ser indexado",
            "descricao": "Controla o cabeçalho X-Robots-Tag na resposta do arquivo.",
            "impacto": "Ligado, não solicita exclusão dos índices. Desligado, envia X-Robots-Tag: noindex para indexadores que respeitam a diretiva. Isso não bloqueia leitura, não é controle de treinamento de IA e não protege conteúdo. Alternativas Markdown usam noindex e apontam a página HTML canônica. As respostas usam cache interno com invalidação e exigem revalidação HTTP.",
            "exemplo": "Ilustrativo: ligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "Ligado, não solicita exclusão dos índices. Desligado, envia X-Robots-Tag: noindex para indexadores que respeitam a diretiva. Isso não bloqueia leitura, não é controle de treinamento de IA e não protege conteúdo. Alternativas Markdown usam noindex e apontam a página HTML canônica. As respostas usam cache interno com invalidação e exigem revalidação HTTP.",
                "escolha": "Escolha se as representações textuais podem ser indexadas.",
                "vantagens": "Permite controlar a descoberta das cópias textuais.",
                "limitacoes": "Não remove a página HTML dos buscadores nem garante indexação.",
                "exemplo": "Desligado mantém a representação com diretivas de não indexação.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "entrega": {
            "tipo": "enum",
            "rotulo": "Entrega do índice",
            "descricao": "Arquivo gerado reduz o trabalho do PHP; requer raiz gravável e cabeçalhos do servidor configurados.",
            "impacto": "Arquivo gerado reduz o trabalho do PHP; requer raiz gravável e cabeçalhos do servidor configurados.",
            "exemplo": "Dinâmica é o padrão.",
            "opcoes": {
                "dinamica": "Dinâmica",
                "arquivo_gerado": "Arquivo gerado"
            },
            "ajuda": {
                "funcionamento": "Arquivo gerado publica llms.txt para entrega direta pelo servidor. Dinâmica produz a resposta pelo WordPress.",
                "escolha": "Prefira Arquivo gerado em sites públicos com diretório gravável. Use Dinâmica quando a hospedagem ou o acesso exigir a aplicação.",
                "vantagens": "Arquivo gerado evita executar WordPress a cada leitura; Dinâmica permite controlar a resposta pela aplicação.",
                "limitacoes": "Arquivo gerado depende das tarefas de atualização e dos cabeçalhos do servidor. Dinâmica consome processamento e também pode passar por cache.",
                "exemplo": "Com cadência de uma hora, configure cron periódico em sites com poucas visitas. Publicação e entrega HTTP são verificadas separadamente.",
                "vazio": "Ausente usa Arquivo gerado. Escolha Dinâmica já gravada é preservada."
            }
        },
        "atualizacao_intervalo_segundos": {
            "tipo": "inteiro",
            "rotulo": "Intervalo de atualização",
            "descricao": "Atualização periódica. Sem visitas é necessário cron real.",
            "impacto": "Atualização periódica. Sem visitas é necessário cron real.",
            "exemplo": "Atualizar a cada hora.",
            "ajuda": {
                "funcionamento": "Atualização periódica. Sem visitas é necessário cron real.",
                "escolha": "Escolha a frequência de preparação do índice conforme o ritmo editorial.",
                "vantagens": "Evita reconstruir todo o índice em cada leitura.",
                "limitacoes": "Depende de executor; cron atrasado pode atrasar conteúdo atualizado.",
                "exemplo": "3600 segundos para atualização horária.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "atualizar_por_visita": {
            "tipo": "booleano",
            "rotulo": "Verificar atualização nas visitas",
            "descricao": "Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.",
            "impacto": "Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.",
            "exemplo": "Ativado.",
            "ajuda": {
                "funcionamento": "Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.",
                "escolha": "Use como apoio em sites com tráfego; mantenha executor externo para horários previsíveis.",
                "vantagens": "Ajuda a disparar a preparação quando há visitas.",
                "limitacoes": "Não garante cadência em site sem acessos.",
                "exemplo": "Cron a cada cinco minutos continua sendo o executor da operação.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "blocos_interface": {
            "tipo": "blocos",
            "rotulo": "Blocos de interface excluídos da conversão",
            "descricao": "Selecione os blocos de interface que serão omitidos na conversão Markdown. Valores já salvos são preservados quando o bloco está indisponível.",
            "ajuda": {
                "funcionamento": "Exclui da conversão em Markdown os tipos de bloco selecionados. Não remove o bloco da página visual.",
                "escolha": "Marque elementos de navegação e interface repetitivos; mantenha os blocos que contêm conteúdo editorial relevante.",
                "vantagens": "Reduz repetição e deixa o documento convertido mais legível.",
                "limitacoes": "Excluir um contêiner pode excluir também seu conteúdo. Confira a prévia da conversão após mudar a lista.",
                "exemplo": "Exclua um bloco de navegação recorrente; não exclua grupos usados para textos dos serviços.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "cabecalhos_servidor": {
            "tipo": "booleano",
            "rotulo": "Gerenciar cabeçalhos do arquivo",
            "descricao": "A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.",
            "impacto": "A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.",
            "exemplo": "A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.",
            "ajuda": {
                "funcionamento": "A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.",
                "escolha": "Aplique as regras gerenciadas somente quando o servidor e as permissões forem compatíveis.",
                "vantagens": "Permite entregar arquivos gerados com os cabeçalhos previstos.",
                "limitacoes": "Preferência salva não comprova regra aplicada nem resposta HTTP do cache.",
                "exemplo": "Conferir Operação → publicação e cabeçalhos após aplicar.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Índice curto que apresenta o site a assistentes e agentes que o leem.",
        "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
        "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
        "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
        "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_redirects

```json
{
    "rotulo": "Redirects declarados",
    "descricao": "Pares origem/destino do próprio site aplicados antes do 404, além do redirecionamento por slug antigo.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Pares origem/destino do próprio site aplicados antes do 404, além do redirecionamento por slug antigo.",
        "escolha": "Cadastre pares exatos e simule antes de aplicar. Query é preservada por padrão; o destino vence colisões de parâmetros.",
        "vantagens": "Mantém links antigos e a origem publicitária durante mudança de endereço.",
        "limitacoes": "Preservar query envia seus parâmetros também ao destino externo. Status permanente pode ficar em caches; evite encadeamentos e laços.",
        "exemplo": "/contato/ para /#contato preserva UTMs e confere a âncora no HTML servido.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_google_carregamento

```json
{
    "rotulo": "Carregamento das tags Google",
    "descricao": "Controla a inserção de gtag.js direto; não se aplica ao GTM.",
    "campo": "grupo",
    "subcampos": {
        "modo": {
            "tipo": "enum",
            "rotulo": "Momento do carregamento",
            "descricao": "Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política.",
            "impacto": "Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política.",
            "exemplo": "Imediato para preservar a medição.",
            "opcoes": {
                "imediato": "Imediato",
                "apos_interacao": "Após interação ou prazo",
                "ocioso": "Após load, em tempo ocioso ou prazo"
            },
            "ajuda": {
                "funcionamento": "Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política.",
                "escolha": "Escolha Imediato ou Após interação conforme a política de medição.",
                "vantagens": "Adiar reduz disputa de recursos na abertura.",
                "limitacoes": "Visitas curtas podem terminar antes da tag; o GTM mantém política própria.",
                "exemplo": "Após interação antecipa no primeiro gesto e respeita o teto.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "teto_segundos": {
            "tipo": "inteiro",
            "rotulo": "Prazo após load, em segundos",
            "descricao": "Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.",
            "impacto": "Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.",
            "exemplo": "Aguardar até cinco segundos.",
            "ajuda": {
                "funcionamento": "Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.",
                "escolha": "Defina a espera máxima contada depois do load.",
                "vantagens": "Garante liberação mesmo sem gesto em visitas longas.",
                "limitacoes": "Aumentar a espera pode reduzir cobertura de visitas breves.",
                "exemplo": "5 significa até cinco segundos; consentimento continua obrigatório.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Controla a inserção de gtag.js direto; não se aplica ao GTM.",
        "escolha": "Imediato libera após consentimento; Após interação usa gesto ou prazo; Ocioso aguarda load e uma oportunidade livre, com prazo máximo próprio.",
        "vantagens": "Adiar reduz competição com os recursos da abertura; o teto atende páginas em que não há interação.",
        "limitacoes": "Visitas muito curtas podem terminar antes da liberação. O modo não controla tags que não foram instaladas pelo Core.",
        "exemplo": "Após interação, teto de 5 segundos: o primeiro toque libera antes do prazo; recusa de publicidade continua prevalecendo.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_seo_entidade

```json
{
    "rotulo": "Entidade de SEO",
    "descricao": "Propriedades de entidade e serviços usados para estender o grafo do plugin de SEO. sameAs vazio fica vazio.",
    "campo": "grupo",
    "subcampos": {
        "nome": {
            "tipo": "texto",
            "rotulo": "Nome",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Nome público da organização, igual ao divulgado no site.",
                "vantagens": "Consolida a identidade institucional.",
                "limitacoes": "Não substitui razão social ou validação de marca.",
                "exemplo": "Empresa Exemplo",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "same_as": {
            "tipo": "json",
            "rotulo": "Same as",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Informe os perfis oficiais da mesma organização.",
                "vantagens": "Conecta identificadores institucionais existentes.",
                "limitacoes": "Uma resposta HTTP 200 não comprova identidade; não use perfil de parceiro.",
                "exemplo": "https://www.linkedin.com/company/empresa-exemplo/",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "area_servida": {
            "tipo": "json",
            "rotulo": "Area servida",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Liste regiões nas quais o serviço é realmente prestado.",
                "vantagens": "Explicita o alcance geográfico.",
                "limitacoes": "Não invente filial, endereço ou cobertura sem comprovação.",
                "exemplo": "Brasil; São Paulo",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "conhece_sobre": {
            "tipo": "json",
            "rotulo": "Conhece sobre",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Liste assuntos que a organização aborda no conteúdo publicado.",
                "vantagens": "Descreve especialidades sem alterar o texto editorial.",
                "limitacoes": "Não é uma lista de palavras-chave para aumentar artificialmente relevância.",
                "exemplo": "Planejamento financeiro",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "ponto_de_contato": {
            "tipo": "json",
            "rotulo": "Ponto de contato",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Declare o canal institucional e sua finalidade de atendimento.",
                "vantagens": "Distingue suporte, comercial e outros contatos oficiais.",
                "limitacoes": "Não cria formulário nem altera destinatários dos avisos.",
                "exemplo": "Atendimento comercial; +55 11 90000-0000",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "organizacao_mae": {
            "tipo": "json",
            "rotulo": "Organizacao mae",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Preencha apenas se existir relação societária/organizacional publicada.",
                "vantagens": "Representa hierarquia legítima.",
                "limitacoes": "Não equivale a parceiro comercial; relações circulares são recusadas.",
                "exemplo": "Nome e URL pública da holding",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "servicos": {
            "tipo": "json",
            "rotulo": "Servicos",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Declare serviços com página pública correspondente e ofertas verificáveis.",
                "vantagens": "Relaciona catálogo, conteúdo e preços publicados.",
                "limitacoes": "Oferta exige prova de conteúdo e ausência de emissor concorrente; configuração não garante emissão.",
                "exemplo": "Consultoria, página 123; R$ 239/mês quando publicado",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "faq_schema": {
            "tipo": "booleano",
            "rotulo": "Faq schema",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Ative somente para perguntas e respostas visíveis no conteúdo elegível.",
                "vantagens": "Representa FAQ publicado no mesmo documento.",
                "limitacoes": "Não garante resultado destacado; conteúdo oculto não vira FAQ válido.",
                "exemplo": "Pergunta: Como funciona? Resposta visível na página.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "razao_social": {
            "tipo": "texto",
            "rotulo": "Razão social",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Use o nome jurídico exato quando adequado à identificação pública.",
                "vantagens": "Distingue marca e entidade legal.",
                "limitacoes": "Não valida cadastro fiscal automaticamente.",
                "exemplo": "Empresa Exemplo Ltda.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "cnpj": {
            "tipo": "texto",
            "rotulo": "CNPJ",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Informe somente CNPJ válido da organização declarada.",
                "vantagens": "Ajuda a distinguir organizações com nomes semelhantes.",
                "limitacoes": "Validação matemática não comprova situação cadastral.",
                "exemplo": "Use o CNPJ público da própria empresa; não um número de demonstração no site real.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "descricao": {
            "tipo": "texto",
            "rotulo": "Descrição",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Resuma a atividade institucional em linguagem objetiva.",
                "vantagens": "Dá contexto ao nome da organização.",
                "limitacoes": "Não muda automaticamente a descrição de cada página no Yoast.",
                "exemplo": "Consultoria para empresas de serviços.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "email": {
            "tipo": "texto",
            "rotulo": "E-mail",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Use endereço institucional público para o grafo da organização.",
                "vantagens": "Explicita o canal público.",
                "limitacoes": "Não é a lista privada de destinatários de leads.",
                "exemplo": "contato@example.org",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "telefone": {
            "tipo": "texto",
            "rotulo": "Telefone E.164",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Use telefone público da organização com código de país.",
                "vantagens": "Padroniza o contato no grafo.",
                "limitacoes": "Não habilita WhatsApp nem modifica a captura de cliques.",
                "exemplo": "+55 11 90000-0000",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "endereco": {
            "tipo": "json",
            "rotulo": "Endereço",
            "descricao": "Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.",
            "impacto": "Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.",
            "exemplo": "{\"cidade\":\"São Paulo\",\"uf\":\"SP\",\"pais\":\"BR\"}",
            "ajuda": {
                "funcionamento": "Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.",
                "escolha": "Preencha endereço real e publicado, respeitando a política do site.",
                "vantagens": "Permite identificar uma localização institucional.",
                "limitacoes": "Não transforme área de atendimento em endereço fictício.",
                "exemplo": "Cidade e estado reais da organização",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "organizacoes_filhas": {
            "tipo": "json",
            "rotulo": "Organizações filhas",
            "descricao": "Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.",
            "impacto": "Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.",
            "exemplo": "[]",
            "ajuda": {
                "funcionamento": "Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.",
                "escolha": "Informe organizações vinculadas com relação publicada.",
                "vantagens": "Permite representar o grupo sem duplicar identidades.",
                "limitacoes": "Lista não cria sites nem comprova vínculo societário.",
                "exemplo": "Uma subsidiária com nome e URL próprios",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "autoria": {
            "tipo": "enum",
            "rotulo": "Autoria padrão",
            "descricao": "Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência.",
            "impacto": "Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência.",
            "exemplo": "Usuário preserva a autoria atual.",
            "opcoes": {
                "usuario": "Usuário",
                "organizacao": "Institucional"
            },
            "ajuda": {
                "funcionamento": "Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência.",
                "escolha": "Institucional apresenta a organização; Usuário conserva autoria pessoal legítima.",
                "vantagens": "Separa responsabilidade editorial da conta usada para editar.",
                "limitacoes": "post_author não é alterado; login técnico não deve servir como nome público.",
                "exemplo": "Institucional para páginas corporativas; pessoa publicada para artigo assinado.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "pessoas": {
            "tipo": "json",
            "rotulo": "Pessoas por página",
            "ajuda": {
                "funcionamento": "Pessoas por página",
                "escolha": "Declare pessoas publicamente apresentadas e páginas que comprovam a relação.",
                "vantagens": "Preserva autores e membros legítimos da equipe no grafo.",
                "limitacoes": "Não publica automaticamente contas WordPress nem inventa emprego ou formação.",
                "exemplo": "Pessoa com página de equipe e perfil profissional oficial.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Propriedades de entidade e serviços usados para estender o grafo do plugin de SEO. sameAs vazio fica vazio.",
        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_cabecalhos

```json
{
    "rotulo": "Cabeçalhos de resposta",
    "descricao": "Cabeçalhos de segurança emitidos no front-end. O COOP EMITIDO É O VALOR GRAVADO, dentro do vocabulário fechado do cabeçalho: fora de same-origin-allow-popups o navegador corta a relação com a janela que o CTA abre, o módulo fecha degradado NOMEANDO essa consequência, e nada é recusado. HSTS desligado por padrão.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Cabeçalhos de segurança emitidos no front-end. O COOP EMITIDO É O VALOR GRAVADO, dentro do vocabulário fechado do cabeçalho: fora de same-origin-allow-popups o navegador corta a relação com a janela que o CTA abre, o módulo fecha degradado NOMEANDO essa consequência, e nada é recusado. HSTS desligado por padrão.",
        "escolha": "Selecione valores compatíveis com embeds, autenticação, publicidade e protocolos realmente usados pelo site.",
        "vantagens": "Define respostas de segurança no escopo administrado pelo plugin.",
        "limitacoes": "Cache/CDN pode responder sem executar PHP. HSTS exige HTTPS estável e tem efeito persistente no navegador.",
        "exemplo": "Após mudar uma política, teste a home em HIT/MISS e as integrações afetadas; opção gravada não é prova HTTP.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_cadencia

```json
{
    "rotulo": "Cadência do modo somente-relatório",
    "descricao": "Periodicidade, gatilho por número de ajustes, mecanismo e nome do hook. Gravada pelo implantador e LIDA pelo módulo de cadência do site-core, que é quem engancha o evento e conta os ajustes.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Periodicidade, gatilho por número de ajustes, mecanismo e nome do hook. Gravada pelo implantador e LIDA pelo módulo de cadência do site-core, que é quem engancha o evento e conta os ajustes.",
        "escolha": "Periodicidade e quantidade de ajustes são gatilhos independentes. Nenhuma e zero deixam ambos desligados.",
        "vantagens": "Cria uma fotografia local de módulos, configurações e conteúdo demonstrativo para revisão da equipe.",
        "limitacoes": "Não envia relatório por e-mail, não mantém histórico completo e não corrige automaticamente divergências. Cron pode atrasar em sites sem tráfego.",
        "exemplo": "A última execução, seu resultado e próxima agenda aparecem em Operação e saude-ler → cadencia.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_formularios

```json
{
    "rotulo": "Formulários próprios",
    "descricao": "Definições revisionadas. Editor em Contatos → Formulários.",
    "campo": "json",
    "ajuda": {
        "funcionamento": "Definições revisionadas. Editor em Contatos → Formulários.",
        "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
        "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
        "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
        "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_testes

```json
{
    "rotulo": "Testes de agentes e operadores",
    "descricao": "Testes de agentes e operadores",
    "campo": "grupo",
    "subcampos": {
        "habilitado": {
            "tipo": "booleano",
            "rotulo": "Identificar tráfego de teste",
            "descricao": "Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.",
            "impacto": "Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.",
            "exemplo": "Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.",
            "ajuda": {
                "funcionamento": "Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.",
                "escolha": "Ative para separar visitas e envios de homologação. Agentes devem visitar /f3base-teste/ em cada navegador/origem ou enviar X-F3Base-Teste: 1.",
                "vantagens": "Permite manter os registros de teste consultáveis e excluí-los dos totais comerciais.",
                "limitacoes": "A marca é uma declaração, não autenticação. Cookies não atravessam subdomínios ou outro cliente HTTP. Não altera consentimento.",
                "exemplo": "Visite a página de ativação, confira a confirmação e faça o teste. A marca dura 365 dias; reativar renova o prazo. Use Sair do modo de teste ao terminar.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "excluir_relatorios": {
            "tipo": "booleano",
            "rotulo": "Excluir testes dos relatórios por padrão",
            "descricao": "Os registros continuam disponíveis em Somente testes e Todos.",
            "impacto": "Os registros continuam disponíveis em Somente testes e Todos.",
            "exemplo": "Os registros continuam disponíveis em Somente testes e Todos.",
            "ajuda": {
                "funcionamento": "Os registros continuam disponíveis em Somente testes e Todos.",
                "escolha": "Mantenha marcado para os totais comerciais.",
                "vantagens": "Evita inflar campanhas e conversões com homologação.",
                "limitacoes": "Depende de o agente marcar o cliente; não identifica testes de outro navegador.",
                "exemplo": "Consulte Somente testes para validar a operação.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ga4_ids": {
            "tipo": "linhas",
            "rotulo": "IDs GA4 autorizados para homologação",
            "descricao": "Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.",
            "impacto": "Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.",
            "exemplo": "Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.",
            "ajuda": {
                "funcionamento": "Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.",
                "escolha": "Autorize somente propriedades de homologação verificadas.",
                "vantagens": "Permite conferir transporte sem misturar o destino comercial.",
                "limitacoes": "ID válido não comprova filtros de desenvolvedor; valide na conta.",
                "exemplo": "G-XXXXXXXXXX de uma propriedade própria de testes.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "gtm_homologado": {
            "tipo": "booleano",
            "rotulo": "Contêiner GTM verificado para testes",
            "descricao": "Só permita após provar que o contêiner suprime tags comerciais e separa destinos.",
            "impacto": "Só permita após provar que o contêiner suprime tags comerciais e separa destinos.",
            "exemplo": "Só permita após provar que o contêiner suprime tags comerciais e separa destinos.",
            "ajuda": {
                "funcionamento": "Só permita após provar que o contêiner suprime tags comerciais e separa destinos.",
                "escolha": "Marque somente após verificar as tags internas do contêiner.",
                "vantagens": "Permite executar um contêiner preparado para homologação.",
                "limitacoes": "O Core não inspeciona nem controla todas as tags criadas dentro do GTM.",
                "exemplo": "Deixe desligado se o contêiner ainda envia para produção.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "capi_test_event_code": {
            "tipo": "texto",
            "rotulo": "Código Meta Test Events",
            "descricao": "Código do ambiente de teste da Meta. Não habilita o pixel no navegador.",
            "impacto": "Código do ambiente de teste da Meta. Não habilita o pixel no navegador.",
            "exemplo": "Código do ambiente de teste da Meta. Não habilita o pixel no navegador.",
            "ajuda": {
                "funcionamento": "Código do ambiente de teste da Meta. Não habilita o pixel no navegador.",
                "escolha": "Use o código obtido no Test Events da Meta.",
                "vantagens": "Distingue o ensaio do envio comercial no destino.",
                "limitacoes": "Pode expirar e não habilita o pixel do navegador por si só.",
                "exemplo": "Copie o código atual da ferramenta de testes.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "email_destinatarios": {
            "tipo": "emails",
            "rotulo": "Destinatários de homologação",
            "descricao": "Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.",
            "impacto": "Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.",
            "exemplo": "Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.",
            "ajuda": {
                "funcionamento": "Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.",
                "escolha": "Cadastre até cinco caixas autorizadas a receber os ensaios.",
                "vantagens": "Evita avisar a equipe comercial a cada teste.",
                "limitacoes": "Caixa válida não comprova entrega e não habilita resposta automática ao visitante.",
                "exemplo": "qa@example.com; lista vazia suprime o aviso de teste.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "destinos": {
            "tipo": "grupo",
            "rotulo": "Envio de testes por destino",
            "subcampos": {
                "gtm": {
                    "tipo": "enum",
                    "rotulo": "GTM",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "ga4": {
                    "tipo": "enum",
                    "rotulo": "GA4",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "google_ads": {
                    "tipo": "enum",
                    "rotulo": "GOOGLE_ADS",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir (sem destino de teste homologado)"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "meta": {
                    "tipo": "enum",
                    "rotulo": "META",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir (sem destino de teste homologado)"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "linkedin": {
                    "tipo": "enum",
                    "rotulo": "LINKEDIN",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir (sem destino de teste homologado)"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "clarity": {
                    "tipo": "enum",
                    "rotulo": "CLARITY",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir (sem destino de teste homologado)"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "capi": {
                    "tipo": "enum",
                    "rotulo": "CAPI",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "email": {
                    "tipo": "enum",
                    "rotulo": "EMAIL",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "slack": {
                    "tipo": "enum",
                    "rotulo": "SLACK",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "webhook": {
                    "tipo": "enum",
                    "rotulo": "WEBHOOK",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                }
            },
            "ajuda": {
                "funcionamento": "Envio de testes por destino",
                "escolha": "Defina Suprimir ou Marcar para cada serviço.",
                "vantagens": "Permite homologar um serviço mantendo os demais suprimidos.",
                "limitacoes": "Marcar exige suporte e configuração de testes no destino.",
                "exemplo": "Meta suprimida e GA4 marcado somente na propriedade autorizada.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Testes de agentes e operadores",
        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
        "exemplo": "Ative /f3base-teste/ no mesmo navegador antes do envio. O cookie dura 365 dias; visitas comuns não renovam o prazo. Use ?sair=1 para remover a marca; agentes HTTP usam X-F3Base-Teste: 1 na própria requisição.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_eventos_destinos

```json
{
    "rotulo": "Eventos de comportamento por destino",
    "descricao": "Eventos de comportamento por destino",
    "campo": "grupo",
    "subcampos": {
        "ga4_f3base_saida": {
            "tipo": "booleano",
            "rotulo": "GA4 direto — Saída: duração e profundidade",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ga4_f3base_rolagem_salto": {
            "tipo": "booleano",
            "rotulo": "GA4 direto — Salto de rolagem",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ga4_f3base_clique_interno": {
            "tipo": "booleano",
            "rotulo": "GA4 direto — Clique interno",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ga4_f3base_clique_inerte": {
            "tipo": "booleano",
            "rotulo": "GA4 direto — Clique sem ação observada",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "data_layer_f3base_saida": {
            "tipo": "booleano",
            "rotulo": "dataLayer / GTM — Saída: duração e profundidade",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "data_layer_f3base_rolagem_salto": {
            "tipo": "booleano",
            "rotulo": "dataLayer / GTM — Salto de rolagem",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "data_layer_f3base_clique_interno": {
            "tipo": "booleano",
            "rotulo": "dataLayer / GTM — Clique interno",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "data_layer_f3base_clique_inerte": {
            "tipo": "booleano",
            "rotulo": "dataLayer / GTM — Clique sem ação observada",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Eventos de comportamento por destino",
        "escolha": "Ajuste este campo conforme a operação de Eventos de comportamento por destino neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_protecao

```json
{
    "rotulo": "Proteção pública",
    "descricao": "Proteção pública",
    "campo": "grupo",
    "subcampos": {
        "usuarios_rest_restritos": {
            "tipo": "booleano",
            "rotulo": "Restringir usuários na API pública",
            "descricao": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "impacto": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "exemplo": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "ajuda": {
                "funcionamento": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
                "escolha": "Ative para restringir enumeração pública e evitar autoria que revele o login.",
                "vantagens": "Protege REST público, oEmbed, feed e links de autoria elegíveis.",
                "limitacoes": "Não remove nomes escritos manualmente pelo tema; autores públicos legítimos permanecem.",
                "exemplo": "Se o slug de autor coincide com login, usa nome e URL públicos do site.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "xmlrpc_desativado": {
            "tipo": "booleano",
            "rotulo": "Desativar XML-RPC",
            "descricao": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "impacto": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "exemplo": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "ajuda": {
                "funcionamento": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
                "escolha": "Desative XML-RPC se nenhum publicador depende dele.",
                "vantagens": "Reduz uma superfície de publicação não utilizada.",
                "limitacoes": "Clientes que usam XML-RPC deixam de funcionar; REST autenticada é independente.",
                "exemplo": "Um publicador exclusivamente REST não precisa de XML-RPC.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "login_generico": {
            "tipo": "booleano",
            "rotulo": "Usar mensagem genérica no login",
            "descricao": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "impacto": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "exemplo": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "ajuda": {
                "funcionamento": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
                "escolha": "Use mensagem genérica na falha de login.",
                "vantagens": "Reduz a confirmação pública de nomes de usuário.",
                "limitacoes": "Não limita tentativas nem substitui autenticação forte.",
                "exemplo": "Usuário inexistente e senha incorreta recebem mensagem equivalente.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Proteção pública",
        "escolha": "Mantenha ligado quando a integração correspondente não precisar de acesso; confira os publicadores do site antes de desligar XML-RPC.",
        "vantagens": "Reduz enumeração pública e superfícies que o site não utiliza, preservando permissões REST e MCP legítimas.",
        "limitacoes": "Uma integração que realmente publique por XML-RPC depende desse protocolo. Mensagem genérica não substitui senha forte nem limita tentativas.",
        "exemplo": "Um cliente que usa REST autenticada continua sujeito às capabilities do WordPress.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_servidor

```json
{
    "rotulo": "Diretórios do servidor",
    "descricao": "Diretórios do servidor",
    "campo": "grupo",
    "subcampos": {
        "bloquear_listagem": {
            "tipo": "booleano",
            "rotulo": "Proteger diretórios e templates do tema",
            "descricao": "Instalação nova aplica regras próprias quando suportado. Impede listagem e leitura HTTP dos templates HTML. A prova HTTP confirma o resultado; escolhas existentes são preservadas.",
            "impacto": "Instalação nova aplica regras próprias quando suportado. Impede listagem e leitura HTTP dos templates HTML. A prova HTTP confirma o resultado; escolhas existentes são preservadas.",
            "exemplo": "Instalação nova aplica regras próprias quando suportado. Impede listagem e leitura HTTP dos templates HTML. A prova HTTP confirma o resultado; escolhas existentes são preservadas.",
            "ajuda": {
                "funcionamento": "Instalação nova aplica regras próprias quando suportado. Impede listagem e leitura HTTP dos templates HTML. A prova HTTP confirma o resultado; escolhas existentes são preservadas.",
                "escolha": "Ative somente após decidir bloquear a listagem na raiz e aplique a alteração em Operação.",
                "vantagens": "Evita que diretórios sem página inicial exibam os arquivos pelo servidor.",
                "limitacoes": "Depende de AllowOverride e do suporte a Options; a gravação exige verificação e pode precisar de restauração.",
                "exemplo": "Padrão desligado nesta versão; ativar a preferência por si só não edita .htaccess.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Diretórios do servidor",
        "escolha": "Ajuste este campo conforme a operação de Diretórios do servidor neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Habilite a preferência de cabeçalhos, consulte o plano em Operação e aplique com a revisão conferida; a preferência sozinha não escreve regras.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_carregamento_destinos

```json
{
    "rotulo": "Carregamento por destino",
    "descricao": "Carregamento por destino",
    "campo": "grupo",
    "subcampos": {
        "ativo": {
            "tipo": "booleano",
            "rotulo": "Política de carregamento por destino",
            "descricao": "Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.",
            "impacto": "Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.",
            "exemplo": "Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.",
            "ajuda": {
                "funcionamento": "Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.",
                "escolha": "Ative se Meta ou LinkedIn precisam de política própria de carregamento.",
                "vantagens": "Permite adiar cada SDK com o mesmo contrato de consentimento.",
                "limitacoes": "A configuração não controla SDK instalado diretamente pelo tema.",
                "exemplo": "Herdar acompanha a política Google; exceções têm prazo próprio.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "meta": {
            "tipo": "enum",
            "rotulo": "Meta",
            "descricao": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "impacto": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "exemplo": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "opcoes": {
                "herdar": "Herdar Google",
                "imediato": "Após consentimento",
                "apos_interacao": "Após interação",
                "ocioso": "Após load, em tempo ocioso ou prazo"
            },
            "ajuda": {
                "funcionamento": "Herdar usa modo e prazo Google. Imediato libera após consentimento; Após interação usa gesto ou prazo; Ocioso aguarda load, tempo livre ou prazo.",
                "escolha": "Escolha uma exceção apenas para este destino quando precisar de outra cadência.",
                "vantagens": "Permite reduzir competição com os recursos iniciais da página.",
                "limitacoes": "Visitas curtas podem terminar antes da carga; timers podem atrasar em abas suspensas. Consentimento continua obrigatório.",
                "exemplo": "Ocioso, prazo próprio de 3 segundos.",
                "vazio": "Campo ausente herda Google; a atualização preserva o valor configurado."
            }
        },
        "meta_teto_segundos": {
            "tipo": "inteiro",
            "rotulo": "Prazo próprio de Meta (segundos)",
            "descricao": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "impacto": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "ajuda": {
                "funcionamento": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "escolha": "Use Herdar para acompanhar a política Google existente; grave uma exceção apenas quando o destino precisar de outro prazo de liberação.",
                "vantagens": "Aplica a mesma regra de fila, interação e consentimento a Meta, LinkedIn e Clarity.",
                "limitacoes": "Uma exceção imediata pode aumentar trabalho na abertura. Alterar esta opção não modifica um contêiner GTM independente.",
                "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "linkedin": {
            "tipo": "enum",
            "rotulo": "Linkedin",
            "descricao": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "impacto": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "exemplo": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "opcoes": {
                "herdar": "Herdar Google",
                "imediato": "Após consentimento",
                "apos_interacao": "Após interação",
                "ocioso": "Após load, em tempo ocioso ou prazo"
            },
            "ajuda": {
                "funcionamento": "Herdar usa modo e prazo Google. Imediato libera após consentimento; Após interação usa gesto ou prazo; Ocioso aguarda load, tempo livre ou prazo.",
                "escolha": "Escolha uma exceção apenas para este destino quando precisar de outra cadência.",
                "vantagens": "Permite reduzir competição com os recursos iniciais da página.",
                "limitacoes": "Visitas curtas podem terminar antes da carga; timers podem atrasar em abas suspensas. Consentimento continua obrigatório.",
                "exemplo": "Ocioso, prazo próprio de 3 segundos.",
                "vazio": "Campo ausente herda Google; a atualização preserva o valor configurado."
            }
        },
        "linkedin_teto_segundos": {
            "tipo": "inteiro",
            "rotulo": "Prazo próprio de Linkedin (segundos)",
            "descricao": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "impacto": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "ajuda": {
                "funcionamento": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "escolha": "Use Herdar para acompanhar a política Google existente; grave uma exceção apenas quando o destino precisar de outro prazo de liberação.",
                "vantagens": "Aplica a mesma regra de fila, interação e consentimento a Meta, LinkedIn e Clarity.",
                "limitacoes": "Uma exceção imediata pode aumentar trabalho na abertura. Alterar esta opção não modifica um contêiner GTM independente.",
                "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "clarity": {
            "tipo": "enum",
            "rotulo": "Clarity",
            "descricao": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "impacto": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "exemplo": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "opcoes": {
                "herdar": "Herdar Google",
                "imediato": "Após consentimento",
                "apos_interacao": "Após interação",
                "ocioso": "Após load, em tempo ocioso ou prazo"
            },
            "ajuda": {
                "funcionamento": "Herdar usa modo e prazo Google. Imediato libera após consentimento; Após interação usa gesto ou prazo; Ocioso aguarda load, tempo livre ou prazo.",
                "escolha": "Escolha uma exceção apenas para este destino quando precisar de outra cadência.",
                "vantagens": "Permite reduzir competição com os recursos iniciais da página.",
                "limitacoes": "Visitas curtas podem terminar antes da carga; timers podem atrasar em abas suspensas. Consentimento continua obrigatório.",
                "exemplo": "Ocioso, prazo próprio de 3 segundos.",
                "vazio": "Campo ausente herda Google; a atualização preserva o valor configurado."
            }
        },
        "clarity_teto_segundos": {
            "tipo": "inteiro",
            "rotulo": "Prazo próprio de Clarity (segundos)",
            "descricao": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "impacto": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "ajuda": {
                "funcionamento": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "escolha": "Use Herdar para acompanhar a política Google existente; grave uma exceção apenas quando o destino precisar de outro prazo de liberação.",
                "vantagens": "Aplica a mesma regra de fila, interação e consentimento a Meta, LinkedIn e Clarity.",
                "limitacoes": "Uma exceção imediata pode aumentar trabalho na abertura. Alterar esta opção não modifica um contêiner GTM independente.",
                "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Carregamento por destino",
        "escolha": "Use Herdar para acompanhar a política Google existente; grave uma exceção apenas quando o destino precisar de outro prazo de liberação.",
        "vantagens": "Aplica a mesma regra de fila, interação e consentimento a Meta, LinkedIn e Clarity.",
        "limitacoes": "Uma exceção imediata pode aumentar trabalho na abertura. Alterar esta opção não modifica um contêiner GTM independente.",
        "exemplo": "Meta em Herdar acompanha Após interação; LinkedIn pode ter exceção Imediato se essa for a decisão do site.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_redirects_hosts

```json
{
    "rotulo": "Hosts HTTPS permitidos nos redirects",
    "descricao": "Lista vazia permite apenas destinos internos. Informe hosts exatos, sem caminhos ou curingas.",
    "campo": "linhas",
    "ajuda": {
        "funcionamento": "Lista vazia permite apenas destinos internos. Informe hosts exatos, sem caminhos ou curingas.",
        "escolha": "Declare apenas hostnames externos HTTPS autorizados, sem protocolo, caminho ou curinga.",
        "vantagens": "Permite destinos externos controlados e verificação de cada salto.",
        "limitacoes": "Subdomínio precisa de entrada própria. Lista vazia proíbe destinos externos; o plugin não adiciona hosts da frota automaticamente.",
        "exemplo": "example.com não autoriza sub.example.com nem example.com.outro.test.",
        "vazio": "Lista vazia é uma escolha explícita e é preservada."
    }
}
```

## f3base_classificacao_acessos

```json
{
    "rotulo": "Classificação de acessos",
    "descricao": "Classificação de acessos",
    "campo": "grupo",
    "subcampos": {
        "ativo": {
            "tipo": "booleano",
            "rotulo": "Classificação atual de acessos",
            "descricao": "Registra versão da regra, corrige slugs longos e separa evidência de automação.",
            "impacto": "Registra versão da regra, corrige slugs longos e separa evidência de automação.",
            "exemplo": "Registra versão da regra, corrige slugs longos e separa evidência de automação.",
            "ajuda": {
                "funcionamento": "Registra versão da regra, corrige slugs longos e separa evidência de automação.",
                "escolha": "Mantenha ativo para classificar assinaturas atuais e evidências de automação.",
                "vantagens": "Distingue robô conhecido, navegador provável e desconhecido.",
                "limitacoes": "User-Agent pode ser imitado; não prova identidade humana.",
                "exemplo": "OpenAI, Claude e Gemini recebem famílias próprias quando a assinatura é observada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "repeticao": {
            "tipo": "booleano",
            "rotulo": "Analisar repetição em janela de 24 horas",
            "descricao": "Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.",
            "impacto": "Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.",
            "exemplo": "Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.",
            "ajuda": {
                "funcionamento": "Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.",
                "escolha": "Ative quando padrões temporais ajudarem a investigar automação.",
                "vantagens": "Acrescenta evidência de repetição em janela limitada.",
                "limitacoes": "Periodicidade também pode ter causa legítima; não bloqueia o visitante.",
                "exemplo": "Oito intervalos regulares podem sinalizar automação suspeita.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Classificação de acessos",
        "escolha": "Mantenha classificação e repetição ligadas para distinguir evidências; investigue os resultados antes de sugerir ações no conteúdo.",
        "vantagens": "Separa robôs reconhecidos, navegador provável e desconhecidos, sem promover todo UA desconhecido a humano.",
        "limitacoes": "Assinatura de navegador pode ser imitada. Periodicidade é indício, não prova de pessoa/robô; reprocessar exige logs ainda disponíveis.",
        "exemplo": "Scrapy entra como automação genérica. Um navegador com intervalos exatos recebe evidência separada de repetição.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_navegacao

```json
{
    "rotulo": "Navegação do site",
    "descricao": "Escolha quem administra a navegação e, se necessário, a referência publicada. O tema continua responsável por exibi-la.",
    "campo": "grupo",
    "subcampos": {
        "schema": {
            "tipo": "inteiro",
            "rotulo": "Versão do formato",
            "ajuda": {
                "funcionamento": "Versão do formato",
                "escolha": "Versão do contrato, fixada em 1. Não é uma preferência visual.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        },
        "tipo": {
            "tipo": "enum",
            "rotulo": "Origem da navegação",
            "opcoes": {
                "tema": "Administrada pelo tema",
                "menu_classico": "Menu clássico",
                "bloco": "Bloco de navegação"
            },
            "ajuda": {
                "funcionamento": "Origem da navegação",
                "escolha": "Use Tema quando não precisar entregar uma referência ao consumidor. Escolha Menu clássico ou Bloco conforme o conteúdo existente.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        },
        "id": {
            "tipo": "inteiro",
            "rotulo": "Referência selecionada",
            "ajuda": {
                "funcionamento": "Referência selecionada",
                "escolha": "Pesquise pelo nome e confira o ID e o tipo. IDs de termos e posts pertencem a espaços diferentes.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Escolha quem administra a navegação e, se necessário, a referência publicada. O tema continua responsável por exibi-la.",
        "escolha": "Tema usa a navegação já administrada pelo tema. Menu clássico seleciona um termo nav_menu; Bloco seleciona wp_navigation publicado.",
        "vantagens": "Aceita menu clássico sem criar bloco órfão.",
        "limitacoes": "A referência não altera templates, localizações nem prova uso no cabeçalho.",
        "exemplo": "Menu clássico — 92: Principal. Confirme a associação e a página renderizada.",
        "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
    }
}
```

## f3base_pipedrive

```json
{
    "rotulo": "Pipedrive",
    "descricao": "Preferência deste site. Configure em Contatos → Integrações. Ativação depende de conta e acesso confirmados.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Conecta novos registros elegíveis à origem ou destino configurado; não envia histórico anterior à ativação.",
        "escolha": "Configure conta, escopo, credencial e mapeamentos; habilite depois de conferir a política do site.",
        "vantagens": "Mantém os contatos organizados com identidade nativa e estado de entrega.",
        "limitacoes": "Disponibilidade externa e cadência podem atrasar os registros; consulte o diagnóstico e os limites da origem.",
        "exemplo": "Ativo=false prepara a configuração sem iniciar a captura ou entrega.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_anuncios_meta

```json
{
    "rotulo": "Meta — formulários nativos",
    "descricao": "Preferência deste site. Configure em Contatos → Integrações. Ativação depende de conta e acesso confirmados.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Conecta novos registros elegíveis à origem ou destino configurado; não envia histórico anterior à ativação.",
        "escolha": "Configure conta, escopo, credencial e mapeamentos; habilite depois de conferir a política do site.",
        "vantagens": "Mantém os contatos organizados com identidade nativa e estado de entrega.",
        "limitacoes": "Disponibilidade externa e cadência podem atrasar os registros; consulte o diagnóstico e os limites da origem.",
        "exemplo": "Ativo=false prepara a configuração sem iniciar a captura ou entrega.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_anuncios_google

```json
{
    "rotulo": "Google Ads — formulários nativos",
    "descricao": "Preferência deste site. Configure em Contatos → Integrações. Ativação depende de conta e acesso confirmados.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Conecta novos registros elegíveis à origem ou destino configurado; não envia histórico anterior à ativação.",
        "escolha": "Configure conta, escopo, credencial e mapeamentos; habilite depois de conferir a política do site.",
        "vantagens": "Mantém os contatos organizados com identidade nativa e estado de entrega.",
        "limitacoes": "Disponibilidade externa e cadência podem atrasar os registros; consulte o diagnóstico e os limites da origem.",
        "exemplo": "Ativo=false prepara a configuração sem iniciar a captura ou entrega.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_anuncios_linkedin

```json
{
    "rotulo": "LinkedIn — acesso à API necessário",
    "descricao": "Preferência deste site. Configure em Contatos → Integrações. Ativação depende de conta e acesso confirmados.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Conecta novos registros elegíveis à origem ou destino configurado; não envia histórico anterior à ativação.",
        "escolha": "Configure conta, escopo, credencial e mapeamentos; habilite depois de conferir a política do site.",
        "vantagens": "Mantém os contatos organizados com identidade nativa e estado de entrega.",
        "limitacoes": "Disponibilidade externa e cadência podem atrasar os registros; consulte o diagnóstico e os limites da origem.",
        "exemplo": "Ativo=false prepara a configuração sem iniciar a captura ou entrega.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_avisos_webhook_url

```json
{
    "rotulo": "URL do receptor JSON",
    "descricao": "Contatos → Integrações → Avisos. O dono cola o segredo; vazio mantém, apagar é explícito. Valor cifrado e nunca reapresentado.",
    "campo": "segredo",
    "impacto": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
    "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
    "ajuda": {
        "funcionamento": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
        "escolha": "Ajuste este campo conforme a operação de URL do receptor JSON neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_avisos_webhook_chave

```json
{
    "rotulo": "Chave HMAC do receptor JSON",
    "descricao": "Contatos → Integrações → Avisos. O dono cola o segredo; vazio mantém, apagar é explícito. Valor cifrado e nunca reapresentado.",
    "campo": "segredo",
    "impacto": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
    "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
    "ajuda": {
        "funcionamento": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
        "escolha": "Ajuste este campo conforme a operação de Chave HMAC do receptor JSON neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_slack_webhook

```json
{
    "rotulo": "Webhook de entrada do Slack",
    "descricao": "Contatos → Integrações → Avisos. O dono cola o segredo; vazio mantém, apagar é explícito. Valor cifrado e nunca reapresentado.",
    "campo": "segredo",
    "impacto": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
    "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
    "ajuda": {
        "funcionamento": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
        "escolha": "Ajuste este campo conforme a operação de Webhook de entrada do Slack neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_clarity_api_token

```json
{
    "rotulo": "Token de exportação do Clarity",
    "descricao": "Cole o token gerado em Settings → Data Export do projeto acima. É cifrado no servidor e nunca reapresentado. Salve primeiro; depois use Testar token e coletar agora.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Campo em Site Core → Configurações → Medição e anúncios → Clarity. Autoriza o servidor a consultar o histórico analítico do Clarity. É separado do ID público que instala a tag no navegador. O token é cifrado e não reaparece no formulário, relatório ou contrato.",
        "escolha": "No Clarity, abra o projeto deste site → Settings → Data Export → Generate new API token. Cole somente o token aqui, salve e use Testar token e coletar agora. Não envie a credencial ao agente.",
        "vantagens": "Permite cadastrar a credencial diretamente no wp-admin e preservar o acervo local, sem depender do canal para transportar segredos.",
        "limitacoes": "O teste consome uma das duas consultas manuais reservadas por dia, dentro de dez por projeto. Oito ficam para a coleta automática. Outros consumidores compartilham a cota do fornecedor. O vínculo ao projeto é local; a API não informa a identidade do projeto na resposta.",
        "exemplo": "Preencha o ID do projeto e seu token, salve e teste. A consulta das últimas 24 horas por URL aparece em Medição → Clarity. Trocar o ID exige cadastrar novamente o token do projeto correspondente.",
        "vazio": "Campo vazio mantém o token salvo; marque Apagar o valor gravado para removê-lo. Sem token vinculado não há coleta de exportação. A tag depende do ID e do consentimento, separadamente."
    }
}
```

## f3base_pipedrive_token

```json
{
    "rotulo": "Credencial de pipedrive token",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    }
}
```

## f3base_anuncios_meta_token

```json
{
    "rotulo": "Credencial de anuncios meta token",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    }
}
```

## f3base_anuncios_google_chave

```json
{
    "rotulo": "Credencial de anuncios google chave",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    }
}
```

## f3base_anuncios_linkedin_token

```json
{
    "rotulo": "Credencial de anuncios linkedin token",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    }
}
```

## f3base_avisos

```json
{
    "rotulo": "Canal dos avisos internos",
    "descricao": "E-mail, Slack ou webhook JSON; e-mail pode acompanhar o destino externo; novas capturas guardam a escolha. Regras de clique e formulário são comuns. Contatos anteriores não são reenviados ao mudar o canal.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "E-mail, Slack ou webhook JSON; e-mail pode acompanhar o destino externo; novas capturas guardam a escolha. Regras de clique e formulário são comuns. Contatos anteriores não são reenviados ao mudar o canal.",
        "escolha": "Ajuste este campo conforme a operação de Canal dos avisos internos neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_medicao_editorial

```json
{
    "rotulo": "Conteúdo, audiência e IA",
    "descricao": "Retenção e qualidade dos relatórios editoriais.",
    "campo": "grupo",
    "subcampos": {
        "retencao_meses": {
            "tipo": "inteiro",
            "rotulo": "Meses de agregados editoriais",
            "descricao": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
            "impacto": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
            "exemplo": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
            "ajuda": {
                "funcionamento": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
                "escolha": "Ajuste este campo conforme a operação de Meses de agregados editoriais neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "excluir_automacao": {
            "tipo": "booleano",
            "rotulo": "Excluir automação da audiência",
            "descricao": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
            "impacto": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
            "exemplo": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
            "ajuda": {
                "funcionamento": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "aplicar_anotacoes": {
            "tipo": "booleano",
            "rotulo": "Aplicar exclusões de períodos anotados",
            "descricao": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
            "impacto": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
            "exemplo": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
            "ajuda": {
                "funcionamento": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "redes_oficiais": {
            "tipo": "booleano",
            "rotulo": "Conferir listas oficiais dos robôs",
            "descricao": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
            "impacto": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
            "exemplo": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
            "ajuda": {
                "funcionamento": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ip_log_confiavel": {
            "tipo": "booleano",
            "rotulo": "Log contém o IP de origem confiável",
            "descricao": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
            "impacto": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
            "exemplo": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
            "ajuda": {
                "funcionamento": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Retenção e qualidade dos relatórios editoriais.",
        "escolha": "Ajuste este campo conforme a operação de Conteúdo, audiência e IA neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_meta_auto_config

```json
{
    "rotulo": "Configuração automática do Pixel Meta",
    "descricao": "Ligado preserva a configuração automática da Meta. Desligue para solicitar autoConfig=false antes do init; PageView e Lead explícitos continuam. Isso não remove o script nem garante melhoria de desempenho.",
    "impacto": "Desligar pode reduzir recursos automáticos do Pixel.",
    "exemplo": "Mantenha ligado, salvo decisão explícita de controlar os eventos automáticos.",
    "campo": "booleano",
    "ajuda": {
        "funcionamento": "Desligar pode reduzir recursos automáticos do Pixel.",
        "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
        "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
        "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
        "exemplo": "Mantenha ligado, salvo decisão explícita de controlar os eventos automáticos.",
        "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
    }
}
```

## f3base_clarity_project_id

```json
{
    "rotulo": "Projeto Microsoft Clarity",
    "descricao": "ID público do projeto; vazio mantém o Clarity inativo. Carrega somente com medição permitida e fora de testes. O script pode aumentar trabalho e tráfego; confira CSP e qualidade em uma amostra real. O token de exportação é separado.",
    "impacto": "Oferece mapas e gravações no fornecedor; não comprova identificação de pessoas.",
    "exemplo": "Copie somente o ID exibido pelo projeto Clarity.",
    "campo": "texto",
    "ajuda": {
        "funcionamento": "Oferece mapas e gravações no fornecedor; não comprova identificação de pessoas.",
        "escolha": "Ajuste este campo conforme a operação de Projeto Microsoft Clarity neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Copie somente o ID exibido pelo projeto Clarity.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_confirmacao_hosts

```json
{
    "rotulo": "Hosts externos de confirmação autorizados",
    "descricao": "Um host por linha, sem esquema ou caminho. Só HTTPS; vazio permite somente este site. Páginas externas para conteúdo/WhatsApp devem exibir o link temporário recebido em f3base_continuar.",
    "campo": "linhas",
    "ajuda": {
        "funcionamento": "Um host por linha, sem esquema ou caminho. Só HTTPS; vazio permite somente este site. Páginas externas para conteúdo/WhatsApp devem exibir o link temporário recebido em f3base_continuar.",
        "escolha": "Informe somente os itens que se aplicam a este site. Confira os itens existentes antes de removê-los.",
        "vantagens": "A lista explícita permite revisar o conjunto aplicado sem editar arquivos do plugin.",
        "limitacoes": "Itens ausentes não são acrescentados por atualizações. Uma lista vazia pode suspender a função que depende dela.",
        "exemplo": "",
        "vazio": "Lista vazia é uma escolha explícita e é preservada."
    }
}
```

## f3base_clarity

```json
{
    "rotulo": "Histórico analítico do Clarity",
    "descricao": "Coletas móveis independentes de 24, 48 e 72 horas. Reduzir a retenção elimina consultas antigas na próxima limpeza. Zero preserva o acervo sem expiração automática. Não inclui gravações individuais.",
    "campo": "grupo",
    "subcampos": {
        "coleta_ativa": {
            "tipo": "booleano",
            "rotulo": "Coletar diariamente quando houver token vinculado",
            "descricao": "Sem projeto/token, nenhuma chamada. Até oito tentativas automáticas/dia; reserva local de duas manuais.",
            "ajuda": {
                "funcionamento": "Sem projeto/token, nenhuma chamada. Até oito tentativas automáticas/dia; reserva local de duas manuais.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ativado aplica a função; desativado preserva a escolha desligada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "retencao_meses": {
            "tipo": "inteiro",
            "rotulo": "Retenção do acervo em meses (0: preservar)",
            "descricao": "Política independente da retenção editorial. Reduzir apaga definitivamente consultas anteriores ao corte.",
            "ajuda": {
                "funcionamento": "Política independente da retenção editorial. Reduzir apaga definitivamente consultas anteriores ao corte.",
                "escolha": "Ajuste este campo conforme a operação de Retenção do acervo em meses (0: preservar) neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Coletas móveis independentes de 24, 48 e 72 horas. Reduzir a retenção elimina consultas antigas na próxima limpeza. Zero preserva o acervo sem expiração automática. Não inclui gravações individuais.",
        "escolha": "Ajuste este campo conforme a operação de Histórico analítico do Clarity neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_meta_capi_pixel_id

```json
{
    "rotulo": "Pixel/dataset da Meta no servidor",
    "descricao": "Destino independente da tag direta. Vazio herda o Pixel direto; preencha quando o Pixel vier do GTM. Trocar destino invalida a homologação e não redireciona a fila antiga.",
    "campo": "texto",
    "ajuda": {
        "funcionamento": "Destino independente da tag direta. Vazio herda o Pixel direto; preencha quando o Pixel vier do GTM. Trocar destino invalida a homologação e não redireciona a fila antiga.",
        "escolha": "Ajuste este campo conforme a operação de Pixel/dataset da Meta no servidor neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_meta_transporte

```json
{
    "rotulo": "Transporte dos eventos Meta",
    "descricao": "Navegador usa o Pixel. Ambos acrescenta CAPI com mesmo event_id. Servidor exige homologação por site e desliga o Pixel direto. GA4 continua pela tag.",
    "campo": "grupo",
    "subcampos": {
        "modo": {
            "tipo": "enum",
            "rotulo": "Como enviar à Meta",
            "descricao": "A mudança para servidor exige equivalência, sete dias completos e provas externas por evento. Tag em GTM/tema exige conferência própria.",
            "opcoes": {
                "navegador": "Navegador",
                "ambos": "Pixel e servidor",
                "servidor": "Somente servidor homologado"
            },
            "ajuda": {
                "funcionamento": "A mudança para servidor exige equivalência, sete dias completos e provas externas por evento. Tag em GTM/tema exige conferência própria.",
                "escolha": "Escolha uma das alternativas exibidas. Cada alternativa muda o funcionamento descrito acima; uma opção gravada é preservada nas atualizações.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "Navegador ou Pixel e servidor ou Somente servidor homologado",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "eventos": {
            "tipo": "multiescolha",
            "rotulo": "Eventos com rota servidor",
            "descricao": "Somente PageView e Lead. A atualização preserva Lead CAPI existente sem ativar PageView no servidor automaticamente.",
            "opcoes": {
                "PageView": "Página vista (PageView)",
                "Lead": "Contato (Lead)"
            },
            "ajuda": {
                "funcionamento": "Somente PageView e Lead. A atualização preserva Lead CAPI existente sem ativar PageView no servidor automaticamente.",
                "escolha": "Informe somente os itens que se aplicam a este site. Confira os itens existentes antes de removê-los.",
                "vantagens": "A lista explícita permite revisar o conjunto aplicado sem editar arquivos do plugin.",
                "limitacoes": "Itens ausentes não são acrescentados por atualizações. Uma lista vazia pode suspender a função que depende dela.",
                "exemplo": "",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Navegador usa o Pixel. Ambos acrescenta CAPI com mesmo event_id. Servidor exige homologação por site e desliga o Pixel direto. GA4 continua pela tag.",
        "escolha": "Ajuste este campo conforme a operação de Transporte dos eventos Meta neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_meta_janela

```json
{
    "rotulo": "Janelas externas da Meta conferidas",
    "descricao": "Conferência operacional das regras oficiais, válida por 90 dias. Sem conferência, a fila mantém 1 hora. Nunca excede sete dias da ocorrência; ambos também respeita deduplicação, com margem de cinco minutos. Alterar não prolonga filas existentes.",
    "campo": "grupo",
    "subcampos": {
        "confirmada": {
            "tipo": "booleano",
            "rotulo": "Limites conferidos na documentação oficial",
            "ajuda": {
                "funcionamento": "Limites conferidos na documentação oficial",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ativado aplica a função; desativado preserva a escolha desligada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "aceitacao_segundos": {
            "tipo": "inteiro",
            "rotulo": "Idade máxima aceita, em segundos",
            "ajuda": {
                "funcionamento": "Idade máxima aceita, em segundos",
                "escolha": "Ajuste este campo conforme a operação de Idade máxima aceita, em segundos neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "deduplicacao_segundos": {
            "tipo": "inteiro",
            "rotulo": "Janela de deduplicação, em segundos",
            "ajuda": {
                "funcionamento": "Janela de deduplicação, em segundos",
                "escolha": "Ajuste este campo conforme a operação de Janela de deduplicação, em segundos neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "conferida_em": {
            "tipo": "texto",
            "rotulo": "Data da conferência (AAAA-MM-DD)",
            "ajuda": {
                "funcionamento": "Data da conferência (AAAA-MM-DD)",
                "escolha": "Ajuste este campo conforme a operação de Data da conferência (AAAA-MM-DD) neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "fonte": {
            "tipo": "texto",
            "rotulo": "URL oficial conferida",
            "ajuda": {
                "funcionamento": "URL oficial conferida",
                "escolha": "Ajuste este campo conforme a operação de URL oficial conferida neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Conferência operacional das regras oficiais, válida por 90 dias. Sem conferência, a fila mantém 1 hora. Nunca excede sete dias da ocorrência; ambos também respeita deduplicação, com margem de cinco minutos. Alterar não prolonga filas existentes.",
        "escolha": "Ajuste este campo conforme a operação de Janelas externas da Meta conferidas neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_gsc_property

```json
{
    "rotulo": "Propriedade do Google Search Console",
    "descricao": "Propriedade autorizada no MCP Google: sc-domain:exemplo.com ou prefixo HTTPS que abrange este site. O Core não recebe a credencial Google.",
    "impacto": "Permite medir impressões, cliques e posição orgânica. Não vincula buscas a pessoas, sessões ou citações de IA.",
    "exemplo": "sc-domain:exemplo.com abrange www.exemplo.com; https://exemplo.com/blog/ só abrange esse caminho.",
    "campo": "texto",
    "ajuda": {
        "funcionamento": "Permite medir impressões, cliques e posição orgânica. Não vincula buscas a pessoas, sessões ou citações de IA.",
        "escolha": "Prefira a propriedade de domínio que inclui este site; use prefixo URL quando a autorização cobre só uma seção.",
        "vantagens": "A propriedade de domínio conserva também URLs de outros hosts no acervo, sem atribuí-las ao site atual.",
        "limitacoes": "Exige autorização no MCP Google. Os dados são agregados; não identificam visitantes ou a busca de uma pessoa.",
        "exemplo": "sc-domain:exemplo.com abrange www.exemplo.com; https://exemplo.com/blog/ só abrange esse caminho.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_gsc

```json
{
    "rotulo": "Coleta orgânica do Search Console",
    "descricao": "Coleta diária de páginas web com dados finais. Últimos três dias disponíveis são revisitados. O histórico local não expira automaticamente. Exige MCP Google 0.7, autorização e transição da conexão concluída.",
    "campo": "grupo",
    "subcampos": {
        "ativo": {
            "tipo": "booleano",
            "rotulo": "Coletar quando autorizado",
            "descricao": "Sem propriedade, SDK e concessão, não há consulta remota. Desligar preserva o acervo.",
            "ajuda": {
                "funcionamento": "Sem propriedade, SDK e concessão, não há consulta remota. Desligar preserva o acervo.",
                "escolha": "Ative depois de conferir a propriedade e a concessão. Escolha um horário com cron ativo; um início anterior amplia a recuperação histórica.",
                "vantagens": "Mantém histórico local por página e permite reprocessar dias sem somar fotografias repetidas.",
                "limitacoes": "Depende da cobertura, cotas e atraso do Google. Ampliar o período aumenta o número de passagens; ausência de linhas não comprova zero acessos.",
                "exemplo": "05:00 executa no fuso do WordPress. Início vazio recupera os últimos 30 dias finalizáveis, em lotes.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "horario": {
            "tipo": "texto",
            "rotulo": "Horário local diário",
            "descricao": "Padrão 05:00 no fuso do WordPress. É previsão: depende de um disparo do cron.",
            "ajuda": {
                "funcionamento": "Padrão 05:00 no fuso do WordPress. É previsão: depende de um disparo do cron.",
                "escolha": "Ative depois de conferir a propriedade e a concessão. Escolha um horário com cron ativo; um início anterior amplia a recuperação histórica.",
                "vantagens": "Mantém histórico local por página e permite reprocessar dias sem somar fotografias repetidas.",
                "limitacoes": "Depende da cobertura, cotas e atraso do Google. Ampliar o período aumenta o número de passagens; ausência de linhas não comprova zero acessos.",
                "exemplo": "05:00 executa no fuso do WordPress. Início vazio recupera os últimos 30 dias finalizáveis, em lotes.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "inicio": {
            "tipo": "texto",
            "rotulo": "Início da série (AAAA-MM-DD)",
            "descricao": "Vazio começa nos últimos 30 dias finalizáveis. Um início anterior exige mais passagens para preencher as lacunas.",
            "ajuda": {
                "funcionamento": "Vazio começa nos últimos 30 dias finalizáveis. Um início anterior exige mais passagens para preencher as lacunas.",
                "escolha": "Ative depois de conferir a propriedade e a concessão. Escolha um horário com cron ativo; um início anterior amplia a recuperação histórica.",
                "vantagens": "Mantém histórico local por página e permite reprocessar dias sem somar fotografias repetidas.",
                "limitacoes": "Depende da cobertura, cotas e atraso do Google. Ampliar o período aumenta o número de passagens; ausência de linhas não comprova zero acessos.",
                "exemplo": "05:00 executa no fuso do WordPress. Início vazio recupera os últimos 30 dias finalizáveis, em lotes.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Coleta diária de páginas web com dados finais. Últimos três dias disponíveis são revisitados. O histórico local não expira automaticamente. Exige MCP Google 0.7, autorização e transição da conexão concluída.",
        "escolha": "Ative depois de conferir a propriedade e a concessão. Escolha um horário com cron ativo; um início anterior amplia a recuperação histórica.",
        "vantagens": "Mantém histórico local por página e permite reprocessar dias sem somar fotografias repetidas.",
        "limitacoes": "Depende da cobertura, cotas e atraso do Google. Ampliar o período aumenta o número de passagens; ausência de linhas não comprova zero acessos.",
        "exemplo": "05:00 executa no fuso do WordPress. Início vazio recupera os últimos 30 dias finalizáveis, em lotes.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```
