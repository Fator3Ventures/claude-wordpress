# Documentação

O índice vigente é [DOCUMENTACAO.md](DOCUMENTACAO.md), Core 1.27.0. Leia RELEASE-1.27.0.md e COMUNICACAO-CONTATOS-1.27.md antes dos guias históricos.
