# Core 1.27.0 → GOOGLE 0.8.2

Nenhuma alteração de código requerida ou aplicada no plugin companheiro. Matriz de referência: MCP 0.19.0 e MCP Google 0.8.2. Mínimos contratuais atuais permanecem estáveis; sufixos de pré-release continuam recusados.

SDK search-console-reader/1.0.0, grant, effective_status e consulta/commit não mudam. A correção de retomada conserva a elegibilidade da intenção; não elimina quota externa nem recria concessões. Não interpretar ausência de credencial/coleta como sucesso. Guardas Core/Google permanecem independentes; backup conjunto precisa de cada protocolo de pausa, dreno e reconciliação.

A padronização dos avisos não usa o companheiro para enviar mensagens nem expõe credenciais. Snapshot cifrado dentro de f3base_leads.dados; duas colunas aditivas de clique em f3base_analise. Incluí-los no backup do banco Core. Nenhum contrato de tabela do companheiro muda.

Primeiro GET agenda a migração, sem trabalho pesado. A finalização posterior reconcilia servidor e consolida marcadores com recibo. Âncoras 1260 e 1250 permanecem para retorno imediato; rollback de arquivos não desfaz entregas externas. Leia RELEASE-1.27.0.md e a validação da entrega para os limites dos testes locais.
