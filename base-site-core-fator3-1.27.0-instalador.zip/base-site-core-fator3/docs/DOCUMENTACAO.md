# Documentação instalada — Core 1.27.0

Caminho: wp-content/plugins/base-site-core-fator3/docs/DOCUMENTACAO.md. Canal: `f3base/documentacao-ler`, com arquivo/linha/limite (até 200), hash e continuação. Requer manage_options, inclusive em recuperação.

| Documento | Conteúdo |
|---|---|
| RELEASE-1.27.0.md | Pedidos 159, 165, 166 e 167, padronização dos três canais e atualização/retorno |
| AGENTES-1.27.0.md / INSTRUCOES-DO-PLUGIN.md | Instrução corrente, contratos e backup conjunto |
| COMUNICACAO-CONTATOS-1.27.md | Resumo comum, cortes, cobertura, privacidade e consulta do snapshot |
| AVISOS-WEBHOOK-1.26.md | Slack, JSON HMAC, configuração, fila e desinstalação |
| INSTRUMENTACAO-1.26.md | Catálogo e auditoria por URL renderizada |
| VALIDACAO.md | Cenários locais e limites da homologação |
| IMPACTO-1.27.0-MCP.md / IMPACTO-1.27.0-GOOGLE.md | Relatórios para os responsáveis pelos companheiros |
| AJUDA-OPCOES.md / dados/ajuda-opcoes.json | Ajuda gerada do catálogo executável |
| CONTRACTS.md / dados/configuracao-schema.json / dados/abilities-*.json | Contratos atuais |
| DICIONARIO-DADOS.md / dados/contrato.json | Tabelas e semântica |
| dados/estado-inventario.json | Propriedade fechada, backup, retenção e marcadores |
| PIPEDRIVE.md / ORIGENS-ANUNCIOS.md | Integrações e atribuição |
| MEDICAO-1.25.md / ESTADO-1.25.md | Recursos anteriores, com complementos/substituições descritos na release atual |

Guias de outras versões são históricos e não sobrepõem as instruções atuais. Documentação não implica ativação de serviço. Não contém credenciais reais.
