# Comunicação de contatos — e-mail, Slack e Pipedrive

## Conteúdo comum e leitura humana

A hierarquia do e-mail é a referência. Cada contato tem estas seções, na mesma ordem nos três canais:

| Seção | Informações |
|---|---|
| Contato | Nome, e-mail, telefone, empresa, cargo, LinkedIn, respostas com rótulos históricos e serviços de interesse disponíveis. |
| Acontecimento | Método, data/hora e fuso, formulário, título/endereço da página, destino e aparelho com limites de identificação. |
| Comportamento | Cobertura em palavras, duração observada, tempo ativo, páginas/carregamentos, retorno/visitas e percurso por página: horário, tempo ativo, rolagem, seções e cliques nomeados. |
| Origem | Atribuição autorizada, plataforma, campanha/anúncio e toques observados. |
| Dados técnicos | Identificador do contato, sessão, dimensões disponíveis, consentimento e qualidade. IP/user agent só quando a autorização atual permite, como no e-mail anterior. |

Títulos, rótulos em negrito, parágrafos, quebras de linha e link autenticado para o contato são comuns. E-mail usa HTML com alternativa texto; Slack usa Block Kit/mrkdwn e a nota Pipedrive usa HTML sem depender do CSS do e-mail. Assunto/envelope, formatação nativa e marcador técnico de idempotência do CRM diferem; os dados humanos não. Campos estruturados da pessoa/oportunidade continuam conforme os mapas configurados. O novo pedido não liga Pipedrive ou Slack automaticamente.

Contatos → Integrações → Avisos oferece prévia legível dos três canais. Antes do preparo, a prévia se identifica como provisória e não persiste/envia nada. Não distribuir segredos, links públicos de arquivos privados ou o conteúdo bruto de cookies. O webhook JSON assinado conserva `f3base.aviso.v1` e suas três seções; ele não é o adaptador Slack/Pipedrive.

## Momento do preparo

- `corte_eventos_em`: captura do contato, UTC em segundos.
- `recebimento_ate`: captura + 10 segundos. Só entram eventos ocorridos até a captura e recebidos até esse limite, mesmo quando a fila roda muito depois.
- `preparado_em`: instante do preparo confirmado no banco, antes de qualquer transporte.
- `hash`: SHA-256 das seções canônicas. IDs dos eventos utilizados e projeção por carregamento ficam no snapshot cifrado.

A captura não espera dez segundos na requisição do visitante. O preparo é assíncrono. Clique e tentativa de formulário disparam flush do comportamento/análise sem aguardar a rede nem criar outro generate_lead. Com executor a cada minuto, a primeira oportunidade costuma ser 10–70 segundos após a captura, além de fila, recuo, quota e rede. Cada destino mantém sua agenda; CRM pode ter cadência diferente. WP-Cron por visitas não garante prazo.

Eventos recebidos em oito segundos podem entrar; em onze, ficam fora. Evento ocorrido após a captura fica fora mesmo se recebido antes do fim da janela. Eventos antigos sem horário de recepção não entram no snapshot e recebem diagnóstico de cobertura. A visão atual pode ser mais completa que o aviso, dentro da retenção.

## Consistência, privacidade e reenvio

`f3base_leads.dados.comunicacao_envio` contém versão 1, hash, horário e cifra `f3com:v1:`; sodium secretbox com chave derivada do salt secure_auth. Escrita compare-and-swap preserva modificações concorrentes do contato. Chave/cifra inválida bloqueia preparo/envio e expõe código seguro. Não exportar a cifra como relatório humano.

`f3base/lead-jornada-ler` com `record_id` e `visao:"aviso"` retorna as seções, cortes/hash e projeção efetivamente preparada. Exige leitura de leads. Sem snapshot, retorna `resumo_ainda_nao_preparado`, sem substituir pela visão atual. O padrão `visao:"atual"` preserva a consulta da jornada corrente. A leitura operacional da fila não expõe o resumo pessoal.

Retentativas e novos ciclos autorizados usam o mesmo snapshot por contato. Chegada tardia não edita nem reabre mensagem entregue. Verificam-se teste, eliminação, consentimento e destino antes do transporte. Se o consentimento ficou mais restritivo, a projeção da próxima entrega é reduzida, marcada `restricao_posterior` e `hash_efetivo`; não é possível retirar uma cópia já entregue de outro serviço. Mudança para autorização mais ampla não reconstitui dados ausentes no snapshot.

A eliminação do contato limpa `dados` e cancela/limpa a fila local; logo elimina também o snapshot. Retenção e backup acompanham o contato, não a janela bruta de eventos. Resumo preservado é uma observação histórica no instante da captura; não significa que os eventos detalhados ainda estejam disponíveis. Fila Slack terminal continua com 90 dias. Restore conserva guardas; nunca supor que pendência antiga não chegou ao destino.

## Interpretação e tamanho

Tempo observado é intervalo entre observações, não duração comprovada de leitura; tempo ativo soma parcelas registradas. Abas simultâneas recebem ressalva. Sem medição/sessão/eventos retidos ou em formulário nativo, mostrar a razão, nunca fabricar zero ou sequência.

Contador em `f3base_audiencia_v1`, separado entre normal/teste e atualizado por sessão do mesmo navegador. Guarda até 64 IDs recentes para deduplicar abas/BFCache; valor máximo 1.000.000. No contato: `contexto.audiencia.visitas`, `visitas_minimo`, `visitas_desde`, `visitas_fonte=contador_local_navegador`. Não prova pessoa distinta nem funciona entre navegadores. Histórico anterior sem contador informa mínimo conhecido ou quantidade indisponível. Limpeza/recusa do consentimento apaga o contador; não se correlaciona por IP. Armazenamento indisponível limita a memória ao carregamento.

A seleção acontece uma vez antes da renderização. Até oito carregamentos: entrada, último carregamento observado e maiores tempos ativos, novamente em ordem cronológica. Informa omissões e link ao registro. Limites da leitura: 500 eventos e 100 cliques. Respostas muito extensas recebem corte explícito comum, preservando orçamento para comportamento; o registro mantém a resposta completa. Slack respeita 20 blocos e 3.000 caracteres por bloco textual, sem menções involuntárias. A nota tem orçamento comum abaixo de 30.000 caracteres no cenário extremo validado.

Resumo horário de e-mail/Slack: uma linha por contato com nome, tempo observado, ativo, páginas, cobertura e link. Slack conserva até 50 contatos por lote. A hora de espera não amplia o corte da jornada. CRM continua recebendo nota individual; não cria oportunidade agrupada.
