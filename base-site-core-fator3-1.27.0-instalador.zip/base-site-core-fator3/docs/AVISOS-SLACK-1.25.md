> Complemento vigente na 1.27.0: RELEASE-1.27.0.md e COMUNICACAO-CONTATOS-1.27.md têm precedência para conteúdo, cortes e retomada.

# Avisos de contatos — Slack, Core 1.25

## Configuração

Contatos → Integrações → Avisos: escolha e-mail, Slack ou ambos. Padrão e-mail. O dono cria um Incoming Webhook no aplicativo Slack e cola sua URL no campo de segredo. O canal é o vinculado pelo Slack àquele webhook. O agente pode ler estado definido/ausente, saúde, fila e prévia; nunca a credencial. Campo vazio mantém o segredo; apagar é uma ação explícita. O valor fica cifrado com chave derivada dos salts WordPress. Backup que contém banco e salts permite decifrá-lo.

Aceita somente HTTPS, host exato `hooks.slack.com`, caminho `/services/<parte>/<parte>/<parte>`, sem usuário/senha, porta, query ou fragmento; transporte sem redirecionamento. Instalar/ligar Slack não reenvia o histórico. Pendências conservam destino/ciclo. Trocar credencial exige escolha explícita no reenvio de pendências antigas.

Mesmas regras de clique/formulário dos avisos internos; anúncio nativo segue o aviso de envio aceito. Em Testes configure Slack como suprimir (padrão) ou marcar. Marcar prefixa `[TESTE]`. Contingência respeita a política e os destinatários de e-mail de teste, sem entregar a caixas comerciais por engano.

## Entrega e contingência

Captura grava `dados.aviso_intencao` junto ao contato; o hook `f3base_lead_persistido` enfileira, fora do transporte HTTP do formulário. Recuperação limitada busca intenções não enfileiradas nos últimos 90 dias. A fila `f3base_avisos_fila` usa chave por contato/canal/ciclo, payload cifrado, lease, reserva atômica e terminal auditável. Não inclui URL pública de anexo ou concessão privada.

200 com corpo `ok` confirma; 429 respeita Retry-After; 5xx usa recuo limitado; demais 3xx/4xx são permanentes. Até cinco tentativas. Timeout/queda após início do transporte/resultado não persistido ficam incertos. Não repetir automaticamente mensagem possivelmente aceita. O webhook não fornece confirmação idempotente consultável.

Cadência local: uma mensagem por segundo/destino. Após 30 mensagens individuais por hora/classe/destino, excesso segue em resumo da hora seguinte, até 50 contatos por lote. Cada mensagem tem até 20 blocos, cada seção até 3.000 caracteres; truncamento é indicado e aponta ao WordPress. Valores são escapados para impedir menções involuntárias.

Slack exclusivo não manda e-mail em sucesso. Segredo ausente, falha permanente, esgotamento ou incerteza acionam contingência por e-mail uma vez por ciclo. Em ambos, o e-mail já enviado não se repete. Sem destinatário ou confirmação do e-mail, consultar saúde/contingência; não declarar a equipe avisada.

`f3base/avisos-fila-ler` é leitura autorizada/paginada. `f3base/avisos-reenviar` simula por padrão; aplicar exige revisão. Incerto/suspenso exige `aceitar_possivel_duplicacao:true`; destino trocado exige `usar_destino_atual:true`. Aplicação cria novo ciclo, mantendo evidência anterior. A prévia da tela não envia.

Retenção terminal: 90 dias. Pendências não são podadas por esse prazo. Eliminação cancela e limpa payloads locais, mas não apaga mensagem já entregue ao Slack. Restore/desinstalação suspendem trabalho pendente; não presumir que uma mensagem antiga não chegou. Uma reserva de contingência sem resultado demanda revisão, sem novo envio automático.

O resumo espera dez segundos de recepção; com executor por minuto, elegibilidade/primeira oportunidade em cerca de 10–70 s, além de recuo/cota/rede. WP-Cron por visita não garante latência. Dois sites no mesmo canal têm cadência local independente; o Retry-After externo regula a concorrência entre sites.

Referências oficiais consultadas em 08/10/2026: https://docs.slack.dev/messaging/sending-messages-using-incoming-webhooks/ ; https://docs.slack.dev/apis/web-api/rate-limits/ ; https://docs.slack.dev/reference/block-kit/blocks/section-block/ . Limites locais e contingência são decisões do Core.
