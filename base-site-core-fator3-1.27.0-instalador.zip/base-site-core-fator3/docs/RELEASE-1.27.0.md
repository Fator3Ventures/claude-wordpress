# Fator3 Site Core 1.27.0 — 09/10/2026

Base de manutenção: WordPress novo ou Core 1.26.0. Não há bloqueio por versão de origem. Contrato de configuração/documentação 6.3.0. Matriz de integração: MCP 0.19.0 e MCP Google 0.8.2; mínimos contratuais mantidos, versões com sufixo recusadas.

## Entregas e rastreabilidade

| Pedido | Implementação | Como conferir |
|---|---|---|
| 159 | Reconhece `concluida_uma_vez` + `concluida_em` do 1110. Retira releases anteriores incompletas comprovadamente superadas; recibo antes da remoção e DELETE condicionado à revisão. Mantém âncoras 1250/1260 e estados sem prova. | `atualizacao.consolidacao` no diagnóstico; recibo contém estado, falhas, cursores, hash, revisão e motivo. |
| 165 | Recuperação não renova o prazo de intenção existente. Espera durável é registrada sob reserva antes do fechamento do checkpoint. Falhas reais de persistência/agenda não viram sucesso. | `esperas` em saúde/como-usar/Operação; alerta após 900 s de atraso elegível; reconciliação simulável descrita abaixo. |
| 166 | Exclui somente o skip-link de núcleo com ID, classes e fragmento esperados. Agrupa mensagem WhatsApp pelo `text` decodificado uma vez, sem normalizar caixa/pontuação. Rótulo visível separado, informativo. | `interfaces_operacionais_excluidas`, `textos_whatsapp_repetidos`, `rotulos_whatsapp_repetidos` e `mensagens_whatsapp_indisponiveis`. |
| 167 | Comportamento com duração observada/ativa, páginas cronológicas, rolagem, seções, cliques nomeados, retorno/contador e cobertura. Resumo horário por contato, janela fixa de recepção e corte explícito. | `lead-jornada-ler` com `visao: aviso`, comparação com mensagem e prévia. |
| Pedido adicional de 09/10 | E-mail, Slack e nota Pipedrive usam um único resumo persistido por contato, seguindo hierarquia do e-mail. Inclui dados presentes nos demais canais, como serviços, identificador e contexto de comportamento. | Mesmas cinco seções, rótulos, valores e cortes; adaptadores HTML/Slack sem consulta separada da jornada. |

Nenhum desses pedidos foi adiado. A recepção nos serviços reais e a auditoria das URLs da frota são homologações, não resultados presumidos a partir do laboratório.

## Recuperar esperas sem escrever no banco

1. Consultar `f3base/saude-ler`: tarefa, ocorrência, motivo, última falha, início, prazo, atraso, reserva, último progresso e presença da agenda. Uma quota futura não é atraso.
2. Simular `f3base/executar-pendentes` com `{"tarefas":["migracao"],"reconciliar_esperas":true,"simular":true}`. A ação exige uma tarefa por simulação.
3. Aplicar os mesmos parâmetros com `simular:false` e `revisao` exatamente recebida. Reserva ativa ou revisão divergente recusam a operação. Isso conserva o prazo e confirma o despertador; não executa callback nem ignora quotas, guardas ou credenciais.
4. Executar `{"tarefas":["migracao"],"limite":1}`. Conferir separadamente conclusão estrutural e finalização posterior, agendada pelo menos 60 s depois. Depois conferir `servidor-aplicar` com `acao: consultar` e as demais tarefas.
5. Intenção suspensa/esgotada tem ação própria. Envio incerto não é reenviado automaticamente. Se persistência/agenda continuam recusadas, tratar a causa diagnosticada; não apagar opções nem avançar marcadores à mão.

`intencao_persistida`, `agendamento_confirmado` e `execucao_realizada` são fatos diferentes. CLI, HTTP cron e ação manual conservam autoria e histórico próprios. O alerta não prova que o cron da hospedagem esteja desligado.

## Ajuste explícito do plano pelo pedido adicional

O plano inicial propunha contexto cifrado por ciclo na fila Slack. Com a padronização dos três canais, a unidade passa a ser **o contato**: `dados.comunicacao_envio`, cifrado, com versão, hash, cortes e evidências da jornada. Não foi adicionada a coluna `contexto_envio` à fila. `lead-jornada-ler` oferece `visao: atual|aviso`, sem seletor de ciclo; ciclos de reenvio usam o mesmo resumo do contato. A fila continua registrando cada ciclo/resultado separadamente.

Mensagens já entregues não são alteradas nem reenviadas pela atualização. Mensagens sem resumo anterior recebem o padrão novo na próxima entrega elegível; o Core não afirma reconstruir o conteúdo exato de avisos antigos. Consentimento que ficou mais restritivo reduz a próxima entrega; o hash efetivo e a ressalva identificam essa exceção. Não ampliar novamente o resumo ao receber eventos tardios. Consulte COMUNICACAO-CONTATOS-1.27.md.

## Instalação, retorno e dados

A troca somente agenda o trabalho; primeiro GET não faz migração/reconciliação/consolidação síncronas. A migração adiciona `clique_rotulo` e `clique_destino` em `f3base_analise`, sem DDL destrutivo. Captura comum e leitura toleram a estrutura anterior; clique nomeado antes da migração responde 503 estruturado e entra na retentativa existente. Verificação de estrutura confirma as duas colunas.

Marcador desta release: `f3base_release_1270`. Mantidos `1260` para retorno e `1250` como dependência de prontidão da 1.26 em atualização pendente. Snapshot usa JSON já existente no contato e não exige mudança de estrutura de terceiros. Retorno de arquivos não restaura banco nem desfaz e-mails/mensagens/notas entregues. Usar os protocolos de pausa, backup e reconciliação existentes.

Documentação, schemas, inventário e instruções aos agentes acompanham o instalador. Nenhum arquivo de MCP, Google, tema ou implantador é alterado. Veja os relatórios de impacto específicos.
