# Validação — Core 1.27.0

Executada em laboratório em 09/10/2026: WordPress 7.1.2, PHP 8.3.6, MariaDB 10.11.14, HTTP PHP com quatro workers, Chromium 153 e fontes finais MCP 0.19.0 / Google 0.8.2. Dados sintéticos; destinos externos bloqueados. Nenhum site ou conta de produção foi usado.

Scripts e evidências no ZIP fonte, `suite/versao-1270/`. Testes de releases anteriores foram adaptados e executados novamente; evidência antiga não é contada como nova.

| Área | Resultado conferido | Evidência |
|---|---|---|
| Instalação nova | Estrutura, padrões, fila suprimida em teste e finalização assíncrona | instalacao-nova.json |
| Upgrade 1.26 → 1.27 | Pipeline MCP real, primeira troca aplicada, primeiro GET abaixo de 2 s no laboratório, tags e captura durante migração, procedência/lista vazia preservadas | ciclo-instalacao.json |
| Retorno | Rollback de arquivos antes e após finalização mantém captura e âncoras | ciclo-instalacao.json |
| Comunicação | Mesmo conteúdo em e-mail, Slack e produtor da nota Pipedrive; 10 s, corte 8/11 s, retentativa idêntica, redução de consentimento, cifra, cobertura e tamanho | comunicacao.json |
| Slack | Sucesso, 403/429/5xx/timeout, reenvio, cancelamento, suspensão, contingência e resumo de 50 | avisos.json |
| Webhook | Contrato v1 preservado, HMAC, segredo, retry, rotação, contingência e limites | webhook.json |
| Consolidação/auditoria | 1110 real, release superada, recibo antes da remoção, conflito concorrente, skip-link exato e WhatsApp decodificado | auditoria-consolidacao.json |
| Executor | Leituras não adiam prazos; quatro tarefas retomam, quotas e revisões preservadas, cron recusado não vira sucesso, falha real de escrita, dois processos/um callback | operacao.json |
| Navegador | Sessões/abas/BFCache sem duplicação, contagem separada em teste, consentimento, clique interno nomeado, formulário e flush de coleta; e-mail sem estouro no celular | navegador.json, email-desktop.png, email-celular.png |
| Telas | Três abas renderizam com prova de tokens; diagnóstico na aba Operação; prévia comum sem warnings | telas.json |
| Companheiros | Duas ordens frias, contratos, autenticação da documentação e guardas independentes | companheiros-reais.json |
| Google | SDK real, concessão não padrão, cron sem usuário, commit no acervo e falha estrutural; transporte remoto simulado | google-sdk.json |
| Regressões | Prova de cache 403/404 grande, cron sem usuário, instrumentação, referências e números preservados | funcional.json |
| Pacote | PHP lint, CRC, fontes iguais ao instalador, minificados com manifesto, docs/schemas/inventário | lint.json, pacote.json |

## Limites das provas

E-mail e Slack passam pelos respectivos fluxos de envio com transporte interceptado. Pipedrive é validado pelo contexto e produtor efetivamente usados na nota; não foi criada pessoa, oportunidade ou nota numa conta real. Campos estruturados seguem os mapas anteriores. Recepção/renderização no cliente de e-mail, workspace Slack e conta Pipedrive continuam a ser homologação do dono.

No teste do executor, a migração executa callback real; editorial, cache e Clarity usam callbacks controlados para isolar retomada/agendamento. Isso não comprova sucesso de coleta remota ou configuração do servidor. A escrita recusada é injetada na query real; `escrita_sem_confirmacao` testa preservação do código por exceção injetada. A interrupção é representada por estado durável incompleto, sem matar um processo durante I/O.

A finalização de 60 s é exercitada envelhecendo somente o checkpoint do fixture. Instalação nova e atualização têm bancos/content dirs separados. O servidor PHP local não substitui Apache, proxy, WP Super Cache, cron e latência reais da frota. Não foram feitos PageSpeed, DebugView, aparelho físico ou novos ensaios remotos.
