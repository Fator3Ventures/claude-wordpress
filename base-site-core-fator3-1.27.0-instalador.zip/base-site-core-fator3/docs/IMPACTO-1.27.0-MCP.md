# Core 1.27.0 → MCP 0.19.0

Nenhuma alteração de código requerida ou aplicada no plugin companheiro. Matriz de referência: MCP 0.19.0 e MCP Google 0.8.2. Mínimos contratuais atuais permanecem estáveis; sufixos de pré-release continuam recusados.

Novos parâmetros na ability f3base/executar-pendentes: reconciliar_esperas, simular, revisao. Uma tarefa por reconciliação, simular por padrão; apply exige revisão. Campos de esperas em saúde/como-usar não alteram o protocolo MCP. lead-jornada-ler ganha visao atual|aviso com permissão de leitura de leads. Regenerar descoberta do schema se o cliente mantiver cache. Não aumentar timeout nem escrever opções diretamente para contornar uma espera.

A padronização dos avisos não usa o companheiro para enviar mensagens nem expõe credenciais. Snapshot cifrado dentro de f3base_leads.dados; duas colunas aditivas de clique em f3base_analise. Incluí-los no backup do banco Core. Nenhum contrato de tabela do companheiro muda.

Primeiro GET agenda a migração, sem trabalho pesado. A finalização posterior reconcilia servidor e consolida marcadores com recibo. Âncoras 1260 e 1250 permanecem para retorno imediato; rollback de arquivos não desfaz entregas externas. Leia RELEASE-1.27.0.md e a validação da entrega para os limites dos testes locais.
