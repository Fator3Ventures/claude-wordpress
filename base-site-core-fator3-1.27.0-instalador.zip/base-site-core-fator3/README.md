# Fator3 Site Core 1.27.0

Instalação nova ou atualização a partir da 1.26.0 como referência de manutenção, sem bloqueio por versão. A troca agenda a migração; o primeiro GET não executa reconciliação de servidor ou consolidação.

E-mail, Slack e nota Pipedrive compartilham um resumo legível por contato, incluindo comportamento e cobertura. Inclui também as correções dos pedidos 159, 165 e 166 e a conclusão do 167. Contrato 6.3.0; matriz MCP 0.19.0 / MCP Google 0.8.2. Não altera companheiros, tema ou implantador.

[Documentação instalada](docs/DOCUMENTACAO.md) · [Release](docs/RELEASE-1.27.0.md) · [Comunicação dos contatos](docs/COMUNICACAO-CONTATOS-1.27.md) · [Agentes](docs/AGENTES-1.27.0.md) · [Validação](docs/VALIDACAO.md).

Documentação e schemas acompanham o instalador e podem ser lidos por f3base/documentacao-ler com permissão administrativa, inclusive em recuperação. Guias antigos são históricos; a instrução corrente tem precedência. Segredos são inseridos pelo dono na tela. Não há reenvio automático do histórico.
