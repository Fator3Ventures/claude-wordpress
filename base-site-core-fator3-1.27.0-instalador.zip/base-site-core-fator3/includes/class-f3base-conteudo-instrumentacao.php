<?php
/** Read-only inspection of saved content and resolved reusable components. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Conteudo_Instrumentacao {
    public static function iniciar(): void {add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('conteudo-instrumentacao-ler','Auditoria de seções, CTAs e formulários do conteúdo publicado',array(__CLASS__,'consultar'),array('pagina'=>array('type'=>'integer','minimum'=>1),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>5),'tipo'=>array('type'=>'string','enum'=>array('page','post')),'post_id'=>array('type'=>'integer','minimum'=>1),'url'=>array('type'=>'string','format'=>'uri'))));}
    /** Public URLs include the actual theme output. Search and 404 are representative routes. */
    public static function consultar($e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $e=is_array($e)?$e:array();$lim=max(1,min(5,(int)($e['limite']??5)));$pag=max(1,(int)($e['pagina']??1));
        $routes=array();if(empty($e['tipo'])&&empty($e['post_id'])){
            $routes[home_url('/')]=array('tipo'=>'home','post_id'=>(int)get_option('page_on_front'),'http_esperado'=>200);
            $blog=get_option('page_for_posts')?get_permalink((int)get_option('page_for_posts')):get_post_type_archive_link('post');
            if($blog&&$blog!==home_url('/')){$routes[$blog]=array('tipo'=>'arquivo_posts','post_id'=>(int)get_option('page_for_posts'),'http_esperado'=>200);}
            elseif(get_option('show_on_front')==='posts'){$routes[home_url('/')]['tipo']='home_e_arquivo_posts';}
            $routes[add_query_arg('s','f3base-auditoria',home_url('/'))]=array('tipo'=>'busca_representativa','post_id'=>0,'http_esperado'=>200);
            $routes[home_url('/f3base-auditoria-rota-inexistente-'.substr(hash('sha256',home_url('/')),0,16).'/')]=array('tipo'=>'404_representativa','post_id'=>0,'http_esperado'=>404);
        }
        $args=array('post_type'=>isset($e['tipo'])&&in_array($e['tipo'],array('page','post'),true)?$e['tipo']:array('page','post'),'post_status'=>'publish','has_password'=>false,'posts_per_page'=>-1,'fields'=>'ids','orderby'=>'ID','order'=>'ASC');if(!empty($e['post_id'])){$args['p']=(int)$e['post_id'];}
        $q=new WP_Query($args);foreach($q->posts as $id){$url=get_permalink($id);if(!isset($routes[$url])){$routes[$url]=array('tipo'=>get_post_type($id),'post_id'=>$id,'http_esperado'=>200);}}
        if(!empty($e['url'])){if(!isset($routes[$e['url']])){return array('ok'=>false,'codigo'=>'url_fora_do_catalogo_publicado');}$routes=array($e['url']=>$routes[$e['url']]);}
        $total=count($routes);$page=array_slice($routes,($pag-1)*$lim,$lim,true);$out=array();$deadline=microtime(true)+20;
        foreach($page as $url=>$meta){$http=F3Base_Http_Publico::buscar($url,2097152,$deadline,'GET',array('X-F3Base-Teste'=>'1'),false);$complete=isset($http['corpo'])&&($http['codigo']??'')!=='resposta_truncada'&&(int)($http['status']??0)===$meta['http_esperado'];
            $row=self::html((string)($http['corpo']??''),$url);$row=$meta+$row;$row['http']=(int)($http['status']??0);$row['codigo_http']=$http['codigo']??'http_indisponivel';$row['cobertura_completa']=$complete&&$row['cobertura_completa'];
            if(!$complete){$row['componentes_nao_inspecionados'][]=array('motivo'=>'resposta_http_nao_completa_ou_status_inesperado');}$row['composicao_tema_inspecionada']=$row['cobertura_completa'];$out[$url]=$row;
        }
        return array('ok'=>true,'fonte'=>'html_publico_renderizado','somente_leitura'=>true,'pagina'=>$pag,'proxima_pagina'=>$pag*$lim<$total?$pag+1:null,'total_urls'=>$total,'por_url'=>$out,'linhas'=>array_values($out),'cobertura_completa'=>count($out)>0&&!in_array(false,array_column($out,'cobertura_completa'),true),'limites'=>array('urls_por_chamada'=>5,'orcamento_segundos'=>20,'bytes_por_url'=>2097152,'nos_por_url'=>15000),'cobertura'=>'HTML servido, incluindo templates e partes do tema; faixas editoriais excluem os controles de consentimento do Core, listados à parte; não executa JavaScript nem prova visibilidade em pixels. Busca e 404 são amostras das rotas dinâmicas. GETs públicos sem sessão, marcados X-F3Base-Teste: 1; podem aparecer nos acessos de teste. O Core diagnostica faixas sem seção; a correção do tema cabe ao seu responsável.');
    }
    public static function html(string $html,string $url): array {
        $r=array('url'=>$url,'primeiro_nivel_sem_secao'=>array(),'secoes_aninhadas'=>array(),'secoes_repetidas'=>array(),'textos_whatsapp_repetidos'=>array(),'rotulos_whatsapp_repetidos'=>array(),'mensagens_whatsapp_indisponiveis'=>array(),'formularios'=>array(),'conflitos_superficie'=>array(),'componentes_nao_inspecionados'=>array(),'nos_examinados'=>0,'interfaces_operacionais_excluidas'=>array(),'cobertura_completa'=>false);
        if($html===''||!class_exists('DOMDocument')||!preg_match('/<body\b/i',$html)||!preg_match('~</html\s*>~i',$html)){$r['componentes_nao_inspecionados'][]=array('motivo'=>'documento_html_incompleto_ou_dom_indisponivel');return $r;}
        $dom=new DOMDocument();$old=libxml_use_internal_errors(true);$loaded=$dom->loadHTML('<?xml encoding="UTF-8">'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($old);
        $body=$dom->getElementsByTagName('body')->item(0);if(!$loaded||!$body){$r['componentes_nao_inspecionados'][]=array('motivo'=>'body_indisponivel');return $r;}
        $xp=new DOMXPath($dom);$seen=array();self::elemento($body,array(),$r,$seen,$xp,0,false);
        foreach($seen as $name=>$paths){if(count($paths)>1){$r['secoes_repetidas'][]=array('secao'=>$name,'ocorrencias'=>$paths);}}
        $texts=array();self::links($html,$texts,'documento',$r);foreach($texts as $text=>$paths){if(count($paths)>1){$r['textos_whatsapp_repetidos'][]=array('texto'=>$text,'ocorrencias'=>$paths);}}
        foreach($xp->query('//*[@data-f3base-formulario]') as $el){self::formulario($el->getAttribute('data-f3base-formulario'),$r,$el->getNodePath());}
        $r['cobertura_completa']=empty($r['componentes_nao_inspecionados']);return $r;
    }
    private static function elemento(DOMElement $el,array $parents,array &$r,array &$seen,DOMXPath $xp,int $depth,bool $reported): void {
        if(++$r['nos_examinados']>15000||$depth>80){if(!$r['componentes_nao_inspecionados']){$r['componentes_nao_inspecionados'][]=array('motivo'=>'limite_de_nos_ou_profundidade');}return;}
        if(in_array(strtolower($el->tagName),array('script','style','link','meta','template','noscript'),true)||$el->hasAttribute('hidden')||$el->getAttribute('aria-hidden')==='true'){return;}
        $classes=preg_split('/\s+/',$el->getAttribute('class'));
        if(strtolower($el->tagName)==='a'&&$el->getAttribute('id')==='wp-skip-link'&&in_array('skip-link',$classes,true)&&in_array('screen-reader-text',$classes,true)&&str_starts_with($el->getAttribute('href'),'#')){$r['interfaces_operacionais_excluidas'][]=array('caminho'=>$el->getNodePath(),'motivo'=>'link_de_salto_do_wordpress');return;}
        if($el->getAttribute('id')==='f3base-consentimento-banner'||in_array('f3base-consentimento-rodape',preg_split('/\s+/',$el->getAttribute('class')),true)){$r['interfaces_operacionais_excluidas'][]=array('caminho'=>$el->getNodePath(),'motivo'=>'controle_de_consentimento_do_core');return;}
        preg_match_all('/(?:^|\s)f3base-secao-([a-z][a-z0-9_-]{0,79})(?=\s|$)/',$el->getAttribute('class'),$m);$names=array_values(array_unique($m[1]));$path=$el->getNodePath();
        foreach($names as $n){$seen[$n][]=$path;if($parents){$r['secoes_aninhadas'][]=array('secao'=>$n,'ancestrais'=>$parents,'caminho'=>$path);}}
        $marked=array_merge($parents,$names);$own='';foreach($el->childNodes as $child){if($child instanceof DOMText){$own.=trim($child->textContent);}}
        $meaningful=$own!==''||in_array(strtolower($el->tagName),array('img','svg','video','audio','iframe','form','input','button','hr'),true);
        $hasSection=$xp->query('.//*[contains(@class,"f3base-secao-")]',$el)->length>0;
        $content=trim((string)$el->textContent)!==''||$xp->query('.//img|.//svg|.//video|.//iframe|.//form',$el)->length>0;
        if(!$marked&&!$reported&&($meaningful||($el->tagName!=='body'&&!$hasSection&&$content))){$r['primeiro_nivel_sem_secao'][]=array('caminho'=>$path,'elemento'=>$el->tagName,'motivo'=>'faixa_sem_ancestral_com_secao');$reported=true;}
        foreach($el->childNodes as $child){if($child instanceof DOMElement){self::elemento($child,$marked,$r,$seen,$xp,$depth+1,$reported);}}
    }
    public static function analisar(WP_Post $p): array {
        $r=array('post_id'=>$p->ID,'tipo'=>$p->post_type,'url'=>get_permalink($p),'primeiro_nivel_sem_secao'=>array(),'secoes_aninhadas'=>array(),'secoes_repetidas'=>array(),'textos_whatsapp_repetidos'=>array(),'rotulos_whatsapp_repetidos'=>array(),'mensagens_whatsapp_indisponiveis'=>array(),'formularios'=>array(),'conflitos_superficie'=>array(),'componentes_nao_inspecionados'=>array(),'componentes_resolvidos'=>array(),'blocos_examinados'=>0);
        $seen=array();$texts=array();self::blocos(parse_blocks($p->post_content),array(),array(),0,$r,$seen,$texts,'conteudo');
        foreach($seen as $name=>$paths){if(count($paths)>1){$r['secoes_repetidas'][]=array('secao'=>$name,'ocorrencias'=>$paths);}}
        foreach($texts as $text=>$paths){if(count($paths)>1){$r['textos_whatsapp_repetidos'][]=array('texto'=>$text,'ocorrencias'=>$paths);}}
        $intro=array();foreach($r['formularios'] as $f){if($f['regime']==='whatsapp'&&$f['texto_efetivo']!==''){$intro[$f['texto_efetivo']][]=$f['caminho'].'@'.$f['id'];}}$r['introducoes_whatsapp_repetidas']=array();foreach($intro as $text=>$paths){if(count($paths)>1){$r['introducoes_whatsapp_repetidas'][]=array('texto'=>$text,'ocorrencias'=>$paths);}}
        $r['cobertura_completa']=empty($r['componentes_nao_inspecionados']);$r['composicao_tema_inspecionada']=false;return $r;
    }
    private static function blocos(array $blocks,array $parents,array $refs,int $depth,array &$r,array &$seen,array &$texts,string $base): void {
        foreach($blocks as $i=>$b){$path=$base.'.'.$i;if(++$r['blocos_examinados']>2000||$depth>12){$r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'limite_de_inspecao');return;}
            if(empty($b['blockName'])&&trim($b['innerHTML']??'')===''){continue;}$attr=$b['attrs']??array();$class=(string)($attr['className']??'');$names=array();preg_match_all('/(?:^|\s)f3base-secao-([a-z][a-z0-9_-]{0,79})(?=\s|$)/',$class,$matches);$names=$matches[1];
            if(($b['blockName']??'')==='f3base/formulario'&&!empty($attr['secao'])&&preg_match('/^[a-z][a-z0-9_-]{0,79}$/D',(string)$attr['secao'])){$names[]=$attr['secao'];}
            $names=array_values(array_unique($names));if(!$parents&&$depth===0&&!$names){$r['primeiro_nivel_sem_secao'][]=array('caminho'=>$path,'bloco'=>$b['blockName']??'html');}
            foreach($names as $n){$seen[$n][]=$path;if($parents){$r['secoes_aninhadas'][]=array('secao'=>$n,'ancestrais'=>$parents,'caminho'=>$path);}}
            if(($b['blockName']??'')==='f3base/formulario'){self::formulario((string)($attr['id']??''),$r,$path);}
            // innerHTML omits the child block markup: no double counting across nesting.
            self::links((string)($b['innerHTML']??''),$texts,$path,$r);self::shortcodes((string)($b['innerHTML']??''),$r,$path);
            $kind=$b['blockName']??'';$ref='';$content=null;
            if($kind==='core/block'){$ref='bloco:'.(int)($attr['ref']??0);$obj=get_post((int)($attr['ref']??0));if($obj&&$obj->post_type==='wp_block'&&$obj->post_status==='publish'&&!$obj->post_password){$content=$obj->post_content;}}
            elseif($kind==='core/template-part'){$ref='parte:'.($attr['theme']??get_stylesheet()).'//'.($attr['slug']??'');$obj=get_block_template(substr($ref,6),'wp_template_part');if($obj&&($obj->status??'publish')==='publish'){$content=$obj->content;}}
            if($ref!==''){
                if(in_array($ref,$refs,true)){$r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'ciclo','componente'=>$ref);}
                elseif($content===null){$r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'referencia_indisponivel','componente'=>$ref);}
                else{$r['componentes_resolvidos'][]=$ref;self::blocos(parse_blocks($content),array_merge($parents,$names),array_merge($refs,array($ref)),$depth+1,$r,$seen,$texts,$path.'@'.$ref);}
            }else{$type=WP_Block_Type_Registry::get_instance()->get_registered($kind);if($type&&$type->is_dynamic()&&!in_array($kind,array('f3base/formulario','core/group','core/paragraph','core/buttons','core/button'),true)){$r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'componente_dinamico','bloco'=>$kind);}}
            if(!empty($b['innerBlocks'])){self::blocos($b['innerBlocks'],array_merge($parents,$names),$refs,$depth+1,$r,$seen,$texts,$path);}
        }
    }
    private static function links(string $html,array &$texts,string $path,array &$r): void {
        if($html===''||!class_exists('DOMDocument')){return;}$dom=new DOMDocument();$old=libxml_use_internal_errors(true);$dom->loadHTML('<?xml encoding="UTF-8"><html><body>'.$html.'</body></html>',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($old);
        $xp=new DOMXPath($dom);foreach($xp->query('//*[@class or @data-f3base-superficie]') as $el){$valid=array('conteudo','menu','flutuante','elementor','cabecalho','barra_fixa');$decl=array();$attr=$el->getAttribute('data-f3base-superficie');if(in_array($attr,$valid,true)&&!$el->hasAttribute('data-f3base-superficie-inferida')){$decl[]=$attr;}preg_match_all('/(?:^|\s)f3base-superficie-([a-z_]+)(?=\s|$)/',$el->getAttribute('class'),$m);$decl=array_values(array_unique(array_merge($decl,array_intersect($m[1],$valid))));if(count($decl)>1){$r['conflitos_superficie'][]=array('caminho'=>$path,'elemento'=>$el->tagName,'valores'=>$decl,'regra'=>'atributo explícito, depois primeira classe válida; corrigir conteúdo');}}
        $labels=array();
        foreach($dom->getElementsByTagName('a') as $node){
            $url=$node->getAttribute('href');$d=F3Base_Leads_Contexto::destino($url);if(empty($d['valido'])||($d['tipo']??'')!=='whatsapp'){continue;}
            $where=array('caminho'=>$path.':'.$node->getNodePath(),'destino'=>F3Base_Contato_Apresentacao::url($url));$label=trim(preg_replace('/\s+/u',' ',$node->textContent));if($label!==''){$labels[$label][]=$where;}
            $values=array();$invalid=false;foreach(explode('&',(string)wp_parse_url($url,PHP_URL_QUERY)) as $pair){$pair=explode('=',$pair,2);$key=urldecode($pair[0]);if($key==='text'){$raw=$pair[1]??'';if(preg_match('/%(?![a-f0-9]{2})/i',$raw)){$invalid=true;}$values[]=urldecode($raw);}elseif(str_starts_with($key,'text[')){$invalid=true;}}
            if($invalid||count($values)!==1||$values[0]===''||!mb_check_encoding($values[0],'UTF-8')){$r['mensagens_whatsapp_indisponiveis'][]=$where+array('motivo'=>$invalid||count($values)>1?'parametro_text_ambiguo_ou_invalido':'mensagem_ausente');continue;}
            $texts[$values[0]][]=$where;
        }
        foreach($labels as $label=>$places){if(count($places)>1){$r['rotulos_whatsapp_repetidos'][]=array('rotulo'=>$label,'ocorrencias'=>$places,'classificacao'=>'informativo');}}
    }
    private static function shortcodes(string $content,array &$r,string $path): void {if(preg_match_all('/\[f3base_formulario\b([^\]]*)\]/',$content,$m)){foreach($m[1] as $x){$a=shortcode_parse_atts($x);self::formulario((string)($a['id']??''),$r,$path.'@shortcode');}}}
    private static function formulario(string $id,array &$r,string $path): void {
        foreach(F3Base_Options::ler('f3base_formularios') as $f){if(($f['id']??'')!==$id){continue;}$cfg=F3Base_Options::ler('f3base_contato');$own=trim((string)($f['mensagem_whatsapp']??''));$r['formularios'][]=array('id'=>$id,'caminho'=>$path,'regime'=>$f['regime'],'texto_efetivo'=>$own!==''?$own:trim((string)($cfg['mensagem_padrao']??'')),'herdado'=>$own==='','continuacao_automatica'=>!empty($f['whatsapp_automatico']));return;}
        $r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'formulario_ausente','id'=>$id);
    }
}
