<?php
/** Coleta adicional limitada, sem conteúdo digitado, com consentimento e idempotência. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Analise {
    const TABELA='f3base_analise';
    const HISTORICO='f3base_atendimento_historico';
    public static function tabela(): string { global $wpdb;return $wpdb->prefix.self::TABELA; }
    public static function iniciar(): void {
        add_action('rest_api_init',static function(){register_rest_route(F3BASE_REST_NAMESPACE,'/analise',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array(__CLASS__,'receber')));});
        add_action('wp_enqueue_scripts',array(__CLASS__,'enfileirar'),30);
        add_action(F3Base_Leads_Notificacoes::EVENTO,array(__CLASS__,'reter'));
    }
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();$t=self::tabela();$h=$wpdb->prefix.self::HISTORICO;
        dbDelta("CREATE TABLE {$t} (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 evento char(32) NOT NULL,
 visitante char(32) NOT NULL,
 sessao char(32) NOT NULL,
 classe_trafego varchar(16) NOT NULL DEFAULT 'nao_marcado',
 navegacao char(32) NOT NULL,
 navegacao_anterior char(32) NOT NULL DEFAULT '',
 automacao varchar(20) NOT NULL DEFAULT 'nao_identificada',
 automacao_motivos varchar(190) NOT NULL DEFAULT '',
 automacao_regra varchar(40) NOT NULL DEFAULT '',
 post_id bigint unsigned NOT NULL DEFAULT 0,
 tipo_conteudo varchar(32) NOT NULL DEFAULT '',
 representacao varchar(20) NOT NULL DEFAULT 'html',
 aquisicao_regra varchar(40) NOT NULL DEFAULT '',
 aquisicao_evidencia varchar(64) NOT NULL DEFAULT '',
 aquisicao_conflitos varchar(190) NOT NULL DEFAULT '',
 canal varchar(32) NOT NULL DEFAULT 'direto_desconhecido',
 origem_ia varchar(24) NOT NULL DEFAULT '',
 entrada varchar(190) NOT NULL DEFAULT '',
 inicio_sessao bigint unsigned NOT NULL DEFAULT 0,
 tipo varchar(20) NOT NULL,
 caminho varchar(190) NOT NULL,
 formulario varchar(80) NOT NULL DEFAULT '',
 formulario_revisao varchar(64) NOT NULL DEFAULT '',
 correlacao varchar(64) NOT NULL DEFAULT '',
 dispositivo varchar(16) NOT NULL,
 largura_faixa varchar(12) NOT NULL DEFAULT '',
 navegador varchar(16) NOT NULL DEFAULT '',
 sistema varchar(12) NOT NULL DEFAULT '',
 retorno varchar(10) NOT NULL DEFAULT '',
 aparelho varchar(16) NOT NULL DEFAULT '',
 criado_em bigint unsigned NOT NULL,
 recebido_em bigint unsigned NOT NULL,
 qualidade varchar(16) NOT NULL,
 oferta_id varchar(80) NOT NULL DEFAULT '',
 oferta_tipo varchar(16) NOT NULL DEFAULT '',
 oferta_instancia char(32) NOT NULL DEFAULT '',
 detalhe varchar(64) NOT NULL DEFAULT '',
 clique_rotulo varchar(160) NOT NULL DEFAULT '',
 clique_destino varchar(190) NOT NULL DEFAULT '',
 valor double NOT NULL DEFAULT 0,
 sequencia int unsigned NOT NULL DEFAULT 1,
 atribuicao text NOT NULL,
 payload_hash char(64) NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY evento (evento),
 KEY periodo (criado_em,tipo),
 KEY trafego_periodo (classe_trafego,criado_em,tipo),
 KEY sessao (sessao,criado_em),
 KEY navegacao (navegacao,tipo),
 KEY conteudo_periodo (post_id,criado_em),
 KEY inicio_sessao (inicio_sessao,sessao),
 KEY tipo_periodo (tipo_conteudo,criado_em),
 KEY visitante (visitante),
 KEY correlacao (correlacao)
) {$cc};");
        if($wpdb->last_error){return false;}
        dbDelta("CREATE TABLE {$h} (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 record_id char(32) NOT NULL,
 revisao bigint unsigned NOT NULL,
 anterior varchar(20) NOT NULL,
 atual varchar(20) NOT NULL,
 em bigint unsigned NOT NULL,
 operador bigint unsigned NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY alteracao (record_id,revisao),
 KEY periodo (em)
) {$cc};");
        return !$wpdb->last_error && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($h)))===$h;
    }
    public static function caminho(string $url): string {return F3Base_Editorial::caminho($url);}
    /** Leitura e escrita de atribuição pelo contrato comum. */
    /** Cookies auxiliares podem surgir entre dois flushes; a origem continua imutável. */
    public static function origem_imutavel($json): string {
        $v=is_string($json)?json_decode($json,true):$json;
        $limpar=static function($a) use (&$limpar){if(!is_array($a)){return $a;}unset($a['fbc'],$a['fbp']);foreach($a as $k=>$x){$a[$k]=$limpar($x);}ksort($a);return $a;};
        return wp_json_encode($limpar(self::atribuicao(is_array($v)?$v:array())));
    }
    public static function atribuicao($v): array { return F3Base_Atribuicao::normalizar($v); }
    public static function enfileirar(): void {
        if(F3Base_Audiencia::pagina_excluida() || !F3Base_Modulo_Comportamento::ligado() || !wp_script_is('f3base-tracking','enqueued')){return;}
        wp_enqueue_script('f3base-analise',F3BASE_PLUGIN_URL.'assets/f3base-analise.min.js',array('f3base-tracking'),F3BASE_PLUGIN_VERSAO,array('in_footer'=>true,'strategy'=>'defer'));
        wp_localize_script('f3base-analise','f3baseAnaliseDados',array('endpoint'=>rest_url(F3BASE_REST_NAMESPACE.'/analise'),'token'=>F3Base_Modulo_Endpoint_Leads::emitir_token(),'rotaToken'=>rest_url(F3BASE_REST_NAMESPACE.'/comportamento/token'),'caminho'=>self::caminho((string)get_permalink(get_queried_object_id()))?:self::caminho(wp_unslash($_SERVER['REQUEST_URI']??'/'))));
    }
    private static function resposta(int $status,array $d): WP_REST_Response {
        $r=new WP_REST_Response($d,$status);$r->header('Cache-Control','no-store, private');
        if(in_array($status,array(429,503),true)){$r->header('Retry-After','15');}return $r;
    }
    /** Diagnóstico limitado, sem SQL, corpo, endereço de rede ou informação pessoal. */
    public static function diagnosticar(string $codigo,string $classe,int $confirmados,string $operacao=''): void {
        F3Base_Options::atualizar_estado('f3base_analise_saude',static function($v) use($codigo,$classe,$confirmados,$operacao){
            $v=is_array($v)?$v:array();$key=$classe.':'.$codigo;$v['contagens'][$key]=(int)($v['contagens'][$key]??0)+1;
            $v['ultima']=array('codigo'=>$codigo,'classe_trafego'=>$classe,'confirmados'=>$confirmados,'operacao'=>$operacao,'em'=>time(),'versao'=>F3BASE_PLUGIN_VERSAO);
            if($classe!=='teste'){$v['ultima_operacional']=$v['ultima'];}
            return $v;
        });
    }
    /** INSERT disputa a chave única; só uma linha comprovada pode confirmar duplicata. */
    public static function persistir(array $row): array {
        if(($row['tipo']??'')==='clique_interno'&&!self::cliques_prontos()){return array('ok'=>false,'codigo'=>'estrutura_cliques_pendente','status'=>503,'operacao'=>'estrutura');}

        global $wpdb;$t=self::tabela();$prev=$wpdb->suppress_errors(true);
        try {
            $old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE evento=%s',$t,$row['evento']),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'leitura','status'=>503);}
            if(!$old){
                if(!F3Base_Leads_Repositorio::quota('analise-sessao|'.$row['sessao'],1000,time()+DAY_IN_SECONDS)){return F3Base_Leads_Repositorio::quota_erro()?array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'quota','status'=>503):array('ok'=>false,'codigo'=>'limite_sessao','status'=>429);}
                if(false!==$wpdb->insert($t,$row)){F3Base_Editorial::marcar_dia((int)$row['criado_em']);return array('ok'=>true);}
                $erro=$wpdb->last_error;
                $old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE evento=%s',$t,$row['evento']),ARRAY_A);
                if(!$old||$wpdb->last_error){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>stripos($erro,'deadlock')!==false?'deadlock':(stripos($erro,'lock wait')!==false?'lock_timeout':'insercao'),'status'=>503);}
            }
            if(hash_equals($old['payload_hash'],$row['payload_hash'])){return array('ok'=>true,'duplicado'=>true);}
            $same=true;foreach(array('sessao','visitante','navegacao','tipo','caminho','detalhe','classe_trafego','formulario','formulario_revisao','correlacao','dispositivo','atribuicao','oferta_id','oferta_tipo','oferta_instancia') as $k){$same=$same&&($k==='atribuicao'?self::origem_imutavel($old[$k])===self::origem_imutavel($row[$k]):(string)$old[$k]===(string)$row[$k]);}
            if($same&&(float)$old['valor']===(float)$row['valor']&&(int)$old['sequencia']===(int)$row['sequencia']&&(int)$old['criado_em']===(int)$row['criado_em']){return array('ok'=>true,'duplicado'=>true);}
            if($row['tipo']==='vital'&&$same){
                if((int)$old['sequencia']>$row['sequencia']){return array('ok'=>true,'superado'=>true);}
                if((int)$old['sequencia']===$row['sequencia']){return array('ok'=>false,'codigo'=>'evento_conflitante','status'=>409);}
                $ok=$wpdb->query($wpdb->prepare('UPDATE %i SET valor=%f,sequencia=%d,payload_hash=%s,recebido_em=%d WHERE evento=%s AND sequencia<%d',$t,$row['valor'],$row['sequencia'],$row['payload_hash'],time(),$row['evento'],$row['sequencia']));
                if(false===$ok){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'atualizacao_vital','status'=>503);}
                $saved=$wpdb->get_row($wpdb->prepare('SELECT sequencia,payload_hash FROM %i WHERE evento=%s',$t,$row['evento']),ARRAY_A);
                if(!$saved||$wpdb->last_error){return array('ok'=>false,'codigo'=>'persistencia_falhou','operacao'=>'confirmacao_vital','status'=>503);}
                if((int)$saved['sequencia']>$row['sequencia']||hash_equals($saved['payload_hash'],$row['payload_hash'])){return array('ok'=>true);}
            }
            return array('ok'=>false,'codigo'=>'evento_conflitante','status'=>409);
        } finally { $wpdb->suppress_errors($prev); }
    }
    public static function cliques_prontos(): bool {global $wpdb;$cols=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i WHERE Field IN (%s,%s)',self::tabela(),'clique_rotulo','clique_destino'));return !$wpdb->last_error&&count($cols??array())===2;}
    public static function receber(WP_REST_Request $req): WP_REST_Response {
        if(F3Base_Audiencia::editor()){return self::resposta(403,array('ok'=>false,'codigo'=>'medicao_nao_permitida','confirmados'=>array()));}
        $request=bin2hex(random_bytes(8));$confirmed=array();
        if(strlen($req->get_body())>32768){return self::resposta(413,array('ok'=>false,'codigo'=>'corpo_grande','confirmados'=>array()));}
        $e=$req->get_json_params();
        if(!is_array($e)||array_diff(array_keys($e),array('token','medicao','eventos'))||!is_string($e['token']??null)||!is_array($e['eventos']??null)||!array_is_list($e['eventos'])||count($e['eventos'])>20||!$e['eventos']){return self::resposta(400,array('ok'=>false,'codigo'=>'entrada_invalida','confirmados'=>array()));}
        if(!F3Base_Modulo_Endpoint_Leads::validar_token($e['token'])){return self::resposta(403,array('ok'=>false,'codigo'=>'token_invalido','confirmados'=>array()));}
        if(($e['medicao']??null)!==true||!F3Base_Modulo_Consentimento::permite_categoria('medicao')||!F3Base_Modulo_Comportamento::ligado()){return self::resposta(403,array('ok'=>false,'codigo'=>'medicao_nao_permitida','confirmados'=>array()));}
        $origin=$req->get_header('origin');if($origin&&strtolower((string)wp_parse_url($origin,PHP_URL_HOST))!==strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST))){return self::resposta(403,array('ok'=>false,'codigo'=>'origem_invalida','confirmados'=>array()));}
        $rows=array();foreach($e['eventos'] as $v){
            if(!is_array($v)){return self::resposta(400,array('ok'=>false,'codigo'=>'evento_invalido','confirmados'=>array()));}
            $marca=F3Base_Testes::resolver($v,$req);if(empty($marca['ok'])){return self::resposta(400,$marca+array('confirmados'=>array()));}
            $v['contexto_teste']=$marca['contexto_teste'];$r=self::validar($v);
            if(isset($r['erro'])){return self::resposta(400,array('ok'=>false,'codigo'=>$r['erro'],'evento'=>$v['evento']??'','confirmados'=>array()));}if(F3Base_Audiencia::caminho_tecnico($r['caminho'])){return self::resposta(403,array('ok'=>false,'codigo'=>'medicao_nao_permitida','confirmados'=>array()));}$rows[]=$r;
        }
        if(count(array_unique(array_column($rows,'classe_trafego')))>1){return self::resposta(400,array('ok'=>false,'codigo'=>'lote_misto','confirmados'=>array()));}
        $classe=$rows[0]['classe_trafego'];$origem=F3Base_Modulo_Endpoint_Leads::origem();$key='analise|'.hash_hmac('sha256',wp_json_encode($origem),wp_salt('auth')).'|'.floor(time()/600);
        if(!F3Base_Leads_Repositorio::quota($key,300,time()+600)){if(F3Base_Leads_Repositorio::quota_erro()){self::diagnosticar('persistencia_falhou',$classe,0,'quota');return self::resposta(503,array('ok'=>false,'codigo'=>'persistencia_falhou','confirmados'=>array(),'request_id'=>$request));}return self::resposta(429,array('ok'=>false,'codigo'=>'limite_origem','confirmados'=>array()));}
        foreach($rows as $row){
            $r=self::persistir($row);
            if(empty($r['ok'])){self::diagnosticar($r['codigo'],$classe,count($confirmed),$r['operacao']??'');return self::resposta($r['status'],array('ok'=>false,'codigo'=>$r['codigo'],'evento'=>$row['evento'],'confirmados'=>$confirmed,'salvos'=>count($confirmed),'parcial'=>(bool)$confirmed,'request_id'=>$request,'classe_trafego'=>$classe));}
            $confirmed[]=array('evento'=>$row['evento'],'sequencia'=>$row['sequencia']);
        }
        self::diagnosticar('confirmado',$classe,count($confirmed));
        return self::resposta(200,array('ok'=>true,'persisted'=>true,'confirmados'=>$confirmed,'salvos'=>count($confirmed),'request_id'=>$request,'classe_trafego'=>$classe));
    }
    public static function validar($v): array {
        $campos=array('evento','visitante','sessao','navegacao','tipo','caminho','formulario','formulario_revisao','correlacao','dispositivo','criado_em','detalhe','valor','sequencia','atribuicao','contexto_teste','sinais','navegacao_anterior','oferta','largura','max_touch_points','retorno','clique_rotulo','clique_destino');
        if(!is_array($v)||array_diff(array_keys($v),$campos)){return array('erro'=>'campo_desconhecido');}
        foreach(array('evento','visitante','sessao','navegacao') as $n){if(!F3Base_Leads_Contexto::sessao($v[$n]??null)){return array('erro'=>'identificador_invalido');}}
        if(!in_array($v['tipo']??'',array('pagina','form_vista','form_inicio','form_tentativa','form_erro','vital','oferta_exibida','oferta_aberta','oferta_fechada','clique_interno'),true)||!in_array($v['dispositivo']??'',array('movel','desktop'),true)||!is_string($v['caminho']??null)||!self::caminho($v['caminho'])){return array('erro'=>'contexto_invalido');}
        if(isset($v['largura'])&&(!is_int($v['largura'])||$v['largura']<0||$v['largura']>20000)){return array('erro'=>'contexto_invalido');}
        if(isset($v['retorno'])&&!in_array($v['retorno'],array_merge(array(''),F3Base_Audiencia::RETORNOS),true)){return array('erro'=>'contexto_invalido');}
        if(isset($v['max_touch_points'])&&(!is_int($v['max_touch_points'])||$v['max_touch_points']<0||$v['max_touch_points']>20)){return array('erro'=>'contexto_invalido');}
        if($v['tipo']==='pagina'&&!in_array($v['detalhe']??'',array('','ancora'),true)){return array('erro'=>'detalhe_invalido');}
        foreach(array('formulario'=>80,'formulario_revisao'=>64,'correlacao'=>64,'detalhe'=>64) as $k=>$max){if(isset($v[$k])&&(!is_string($v[$k])||strlen($v[$k])>$max||($v[$k]!==''&&!preg_match('/^[A-Za-z0-9_.:-]+$/D',$v[$k])))){return array('erro'=>'detalhe_invalido');}}
        if(str_starts_with($v['tipo'],'form_')){if(empty($v['formulario'])||empty($v['correlacao'])||!F3Base_Formularios::obter($v['formulario'])){return array('erro'=>'formulario_invalido');}}
        $o=isset($v['oferta'])?F3Base_Ofertas_Medicao::validar($v['oferta']):null;if((isset($v['oferta'])&&!$o)||(in_array($v['tipo'],F3Base_Ofertas_Medicao::EVENTOS,true)&&(!$o||!F3Base_Formularios::obter($v['formulario']??'')))){return array('erro'=>'oferta_invalida');}
        if(($v['tipo']==='oferta_aberta'&&!in_array($v['detalhe']??'',array('rolagem','saida','tempo','clique'),true))||($v['tipo']==='oferta_fechada'&&!in_array($v['detalhe']??'',array('botao','esc','fora','navegacao'),true))||($v['tipo']==='oferta_exibida'&&($v['detalhe']??'')!=='')){return array('erro'=>'oferta_evento_invalido');}
        if($v['tipo']==='clique_interno'){
            if(!is_string($v['clique_rotulo']??null)||mb_strlen($v['clique_rotulo'])>160||!is_string($v['clique_destino']??null)||strlen($v['clique_destino'])>190||!self::caminho($v['clique_destino'])||str_starts_with($v['clique_destino'],'//')||preg_match('~[?#]|/f3base/(?:arquivo|download)~i',$v['clique_destino'])){return array('erro'=>'clique_invalido');}
        }elseif(isset($v['clique_rotulo'])||isset($v['clique_destino'])){return array('erro'=>'clique_fora_do_evento');}
        $valor=$v['valor']??0;$seq=$v['sequencia']??1;
        if(!is_numeric($valor)||!is_finite((float)$valor)||(float)$valor<0||(float)$valor>3600000||!is_int($seq)||$seq<1||$seq>60){return array('erro'=>'valor_invalido');}
        if($v['tipo']==='vital'&&!in_array($v['detalhe']??'',array('LCP','CLS','INP','TTFB'),true)){return array('erro'=>'vital_invalido');}
        if(!F3Base_Audiencia::sinais_validos($v['sinais']??array())||(!empty($v['navegacao_anterior'])&&!F3Base_Leads_Contexto::sessao($v['navegacao_anterior']))){return array('erro'=>'sinais_invalidos');}
        $a=$v['atribuicao']??array();if(!F3Base_Atribuicao::validar($a)){return array('erro'=>'atribuicao_invalida');}
        $stamp=$v['criado_em']??null;if(!is_int($stamp)){return array('erro'=>'horario_invalido');}
        $valid=$stamp>=time()-F3Base_Modulo_Comportamento::retencao_eventos_dias()*DAY_IN_SECONDS&&$stamp<=time()+300;
        $row=array_merge(array('formulario'=>'','formulario_revisao'=>'','correlacao'=>'','detalhe'=>''),array_intersect_key($v,array_flip(array('evento','visitante','sessao','navegacao','tipo','formulario','formulario_revisao','correlacao','dispositivo','detalhe'))));
        if($v['tipo']==='clique_interno'){$row['clique_rotulo']=sanitize_text_field($v['clique_rotulo']);$row['clique_destino']=self::caminho($v['clique_destino']);}
        $row+=array('oferta_id'=>$o['id']??'','oferta_tipo'=>$o['tipo']??'','oferta_instancia'=>$o['instancia']??'');
        $hints=array_filter(array('mobile'=>$_SERVER['HTTP_SEC_CH_UA_MOBILE']??null,'max_touch_points'=>$v['max_touch_points']??null),static fn($x)=>$x!==null);
        $row+=array('sistema'=>F3Base_Audiencia::sistema(null,$hints),'retorno'=>$v['retorno']??'','aparelho'=>F3Base_Contato_Apresentacao::aparelho((string)($_SERVER['HTTP_USER_AGENT']??''),$hints)['tipo'],'largura_faixa'=>F3Base_Audiencia::faixa_largura((int)($v['largura']??0)),'navegador'=>F3Base_Audiencia::navegador(),'classe_trafego'=>!empty($v['contexto_teste'])?'teste':'nao_marcado','caminho'=>self::caminho($v['caminho']),'criado_em'=>$valid?$stamp:time(),'recebido_em'=>time(),'qualidade'=>$valid?'cliente':'servidor','valor'=>(float)$valor,'sequencia'=>$seq,'atribuicao'=>wp_json_encode(self::atribuicao($a)),'payload_hash'=>hash('sha256',wp_json_encode(F3Base_Auditoria::ordenar($v))));
        $orig=self::atribuicao($a)['sessao_origem']??self::atribuicao($a);$canal=F3Base_Audiencia::canal($orig);$conteudo=F3Base_Editorial::resolver($row['caminho'],$row['criado_em']);
        $row+=F3Base_Audiencia::automacao($v['sinais']??array())+array('navegacao_anterior'=>$v['navegacao_anterior']??'','post_id'=>$conteudo['post_id'],'tipo_conteudo'=>$conteudo['tipo'],'representacao'=>$conteudo['representacao'],'canal'=>$canal['canal'],'aquisicao_regra'=>$canal['regra'],'aquisicao_evidencia'=>$canal['evidencia'],'aquisicao_conflitos'=>$canal['conflitos'],'origem_ia'=>$canal['origem_ia'],'entrada'=>$orig['entrada']??'','inicio_sessao'=>(($orig['inicio_conhecido']??'')==='1'&&(int)($orig['inicio_em']??0)>0&&(int)$orig['inicio_em']<=$row['criado_em']+300)?(int)$orig['inicio_em']:0);return $row;
    }
    public static function reter(): void {if(!F3Base_Editorial::antes_retencao()){return;}global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE criado_em<%d',self::tabela(),F3Base_Editorial::corte_retencao()));}
    public static function esquecer(string $visitante): void {global $wpdb;$wpdb->delete(self::tabela(),array('visitante'=>$visitante));}
    public static function eliminar_lead(array $lead): bool {global $wpdb;if(false===$wpdb->delete($wpdb->prefix.self::HISTORICO,array('record_id'=>$lead['record_id']))){return false;}return empty($lead['sessao']) || false!==$wpdb->delete(self::tabela(),array('sessao'=>$lead['sessao']));}
}
