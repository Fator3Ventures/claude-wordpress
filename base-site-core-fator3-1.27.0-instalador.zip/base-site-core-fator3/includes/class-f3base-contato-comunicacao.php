<?php
/** One immutable, encrypted contact presentation shared by mail, Slack and CRM. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Contato_Comunicacao {
    const VERSAO=1;
    const ESPERA=10;
    private static function chave(): string {return hash_hkdf('sha256',wp_salt('secure_auth'),32,'f3base:comunicacao:v1');}
    private static function cifrar(array $a): string {$n=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);return 'f3com:v1:'.base64_encode($n.sodium_crypto_secretbox(wp_json_encode($a),$n,self::chave()));}
    private static function abrir(string $raw): ?array {
        if(!str_starts_with($raw,'f3com:v1:')){return null;}$b=base64_decode(substr($raw,9),true);if(!$b||strlen($b)<40){return null;}
        try{$v=sodium_crypto_secretbox_open(substr($b,24),substr($b,0,24),self::chave());$a=$v===false?null:json_decode($v,true);return is_array($a)?$a:null;}catch(Throwable $e){return null;}
    }
    public static function prazo(array $lead): int {return (int)strtotime($lead['criado_em'].' UTC')+self::ESPERA;}
    public static function ler(array $lead): ?array {return self::abrir((string)($lead['dados']['comunicacao_envio']['cifrado']??''));}
    /** Persistence happens before any transport. Re-reading never widens the reception window. */
    public static function preparar(array $lead,bool $persistir=true): array {
        if(!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])||($lead['captura']??'')==='eliminado'){return array('ok'=>false,'codigo'=>'registro_nao_elegivel');}
        $saved=self::ler($lead);
        if($saved){return array('ok'=>true,'codigo'=>'resumo_congelado','apresentacao'=>self::restricoes($saved,$lead));}
        if(!empty($lead['dados']['comunicacao_envio'])){return array('ok'=>false,'codigo'=>'resumo_cifrado_indisponivel');}
        $due=self::prazo($lead);if($persistir&&time()<$due){return array('ok'=>false,'codigo'=>'aguardando_eventos_do_contato','tentar_em'=>$due);}
        $a=F3Base_Contato_Apresentacao::montar($lead,true,$due);
        if(empty($a['jornada']['ok'])){return array('ok'=>false,'codigo'=>$a['jornada']['codigo']??'jornada_indisponivel');}
        $a['comunicacao']=array('versao'=>self::VERSAO,'corte_eventos_em'=>$a['corte_em'],'recebimento_ate'=>$due,'preparado_em'=>time(),'provisoria'=>!$persistir);
        $a['secoes_comunicacao']=self::compactar(F3Base_Contato_Apresentacao::secoes($a));
        // Keep identifiers and the page projection for an exact, authorized comparison.
        $a['jornada']['eventos_utilizados']=array_map(static fn($v)=>array('fonte'=>$v['fonte']??'','id'=>$v['id']??''),$a['jornada']['eventos']??array());
        unset($a['journey'],$a['jornada']['eventos']);$a['comunicacao']['hash']=hash('sha256',wp_json_encode($a['secoes_comunicacao']));
        if(!$persistir){return array('ok'=>true,'codigo'=>'previa_provisoria','apresentacao'=>$a);}
        global $wpdb;$t=F3Base_Leads_Repositorio::tabela();
        for($i=0;$i<3;$i++){
            $row=$wpdb->get_row($wpdb->prepare('SELECT dados,lixeira,eliminacao_pendente FROM %i WHERE record_id=%s',$t,$lead['record_id']),ARRAY_A);
            if(!$row||$row['lixeira']||$row['eliminacao_pendente']){return array('ok'=>false,'codigo'=>'registro_nao_elegivel');}
            $d=json_decode($row['dados'],true);if(!is_array($d)){return array('ok'=>false,'codigo'=>'dados_contato_ilegivel');}
            if(isset($d['comunicacao_envio'])){$other=self::ler(array('dados'=>$d));return $other?array('ok'=>true,'codigo'=>'resumo_congelado','apresentacao'=>self::restricoes($other,array_merge($lead,array('dados'=>$d)))):array('ok'=>false,'codigo'=>'resumo_cifrado_indisponivel');}
            $d['comunicacao_envio']=array('versao'=>self::VERSAO,'hash'=>$a['comunicacao']['hash'],'preparado_em'=>time(),'cifrado'=>self::cifrar($a));
            $n=$wpdb->update($t,array('dados'=>wp_json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),array('record_id'=>$lead['record_id'],'dados'=>$row['dados'],'lixeira'=>0,'eliminacao_pendente'=>0));
            if($n===1){return array('ok'=>true,'codigo'=>'resumo_congelado','apresentacao'=>self::restricoes($a,array_merge($lead,array('dados'=>$d))));}
            if($n===false){break;}
        }
        return array('ok'=>false,'codigo'=>'resumo_persistencia_falhou');
    }
    /** Consent may become stricter after freezing; no destination can receive revoked detail. */
    private static function restricoes(array $a,array $lead): array {
        $now=F3Base_Contato_Apresentacao::consentimento($lead['dados']);$before=$a['consentimento_historico']??array();
        if((!empty($before['medicao'])&&!$now['medicao'])||(!empty($before['publicidade'])&&!$now['publicidade'])){
            $fresh=F3Base_Contato_Apresentacao::montar($lead,true,(int)$a['comunicacao']['recebimento_ate']);
            // Permission reduction only, never refresh retained behavior with newly arrived data.
            if(!$now['medicao']){$a['jornada']=$fresh['jornada'];$a['atribuicao']=array();}
            elseif(!$now['publicidade']){$a['atribuicao']=F3Base_Contato_Apresentacao::atribuicao($a['atribuicao'],false);}
            $a['consentimento_atual']=$fresh['consentimento_atual'];$a['consentimento_historico']=$now;$a['qualidade'][]='Dados reduzidos por alteração de consentimento após o preparo.';
            unset($a['secoes_comunicacao']);$a['secoes_comunicacao']=self::compactar(F3Base_Contato_Apresentacao::secoes($a));$a['comunicacao']['restricao_posterior']=true;$a['comunicacao']['hash_efetivo']=hash('sha256',wp_json_encode($a['secoes_comunicacao']));
        }
        return $a;
    }
    public static function previa(array $lead): array {$r=self::preparar($lead,false);return $r['apresentacao']??F3Base_Contato_Apresentacao::montar($lead,false);}
    /** Common budget: every renderer shows the same fields and the same explicit cuts. */
    public static function compactar(array $sections): array {
        $out=array();foreach($sections as $title=>$items){$budget=$title==='Comportamento'?6500:($title==='Contato'?4000:2500);$used=0;$cut=0;
            foreach($items as $label=>$values){$safeLabel=mb_substr((string)$label,0,120);$lines=array();
                foreach((array)$values as $v){$v=(string)$v;if(mb_strlen($v)>2000){$v=mb_substr($v,0,1880).' […] Texto resumido; conteúdo integral no registro do WordPress.';}$cost=mb_strlen(esc_html($safeLabel.$v))+80;
                    if($used+$cost>$budget){$cut++;continue;}$lines[]=$v;$used+=$cost;}
                if($lines){$out[$title][$safeLabel]=$lines;}
            }
            if($cut){$out[$title]['Cobertura do resumo']='Resumo limitado: '.$cut.' informação(ões) adicional(is) no registro do WordPress.';}
        }return $out;
    }
    public static function linha_resumo(array $a): string {
        $j=$a['jornada'];return mb_substr($a['nome']?:'Visitante',0,120).' · '.(isset($j['duracao_observada_segundos'])?self::tempo($j['duracao_observada_segundos']).' observados':'tempo não observado').' · '.(isset($j['tempo_ativo_total_ms'])?self::tempo($j['tempo_ativo_total_ms']/1000).' ativos':'atividade não observada').' · '.(isset($j['paginas_distintas'])?$j['paginas_distintas'].' página(s)':'páginas não observadas').' · '.F3Base_Contato_Apresentacao::rotulo($j['codigo']??'jornada_indisponivel');
    }
    public static function tempo(float $seconds): string {$s=max(0,(int)round($seconds));return $s>=3600?intdiv($s,3600).' h '.intdiv($s%3600,60).' min':($s>=60?intdiv($s,60).' min '.($s%60).' s':$s.' s');}
}
