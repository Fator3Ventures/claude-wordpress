<?php
/** Durable notification intent is part of each persisted lead. Visitor replies use their separate, opt-in workflow. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Leads_Notificacoes {
	const EVENTO = 'f3base_leads_resumo';
    const AVISOS='f3base_leads_avisos';
    public static function absorver_anteriores(int $corte): array {
        global $wpdb;$t=F3Base_Leads_Repositorio::tabela();
        $n=$wpdb->query($wpdb->prepare("UPDATE %i SET aviso='aguarda_resumo' WHERE aviso='pendente' AND criado_em<%s AND lixeira=0 AND eliminacao_pendente=0 LIMIT 100",$t,gmdate('Y-m-d H:i:s',$corte)));
        return array('ok'=>$n!==false,'concluido'=>$n!==false&&$n<100,'codigo'=>'avisos_anteriores','cursor'=>array('corte'=>$corte));
    }
    public static function destinatarios_do_contato(array $lead): array {
        $to=self::destinatarios($lead['dados']['destinatarios']??array());if($to){return $to;}
        $f=($lead['captura']??'')==='clique'?null:F3Base_Formularios::obter((string)($lead['formulario']??''));$to=self::destinatarios(is_array($f)?($f['destinatarios']??array()):array());if($to){return $to;}
        return self::destinatarios(F3Base_Options::ler('f3base_contato')['email_leads']??array());
    }
    public static function agendar(string $record): array {return F3Base_Fila::agendar_detalhe(self::AVISOS,time()+10);}
    public static function lote(): array {if(!F3Base_Leads_Repositorio::pronto()){return array('ok'=>false,'codigo'=>'aguardando_servico','tentar_em'=>time()+300);}global $wpdb;$ids=$wpdb->get_col($wpdb->prepare("SELECT record_id FROM %i WHERE aviso='pendente' AND criado_em<=%s AND lixeira=0 AND eliminacao_pendente=0 ORDER BY criado_em LIMIT 20",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s',time()-10)));foreach($ids as $id){self::enviar($id);}$next=$wpdb->get_var($wpdb->prepare("SELECT MIN(criado_em) FROM %i WHERE aviso='pendente' AND lixeira=0 AND eliminacao_pendente=0",F3Base_Leads_Repositorio::tabela()));if($next){$due=strtotime($next.' UTC')+10;F3Base_Fila::agendar(self::AVISOS,$due>time()?max(time()+1,$due):time()+60);}return array('ok'=>true,'examinados'=>count($ids));}
	public static function iniciar(): void {
		add_action(self::AVISOS,array(__CLASS__,'lote'));
        add_action( self::EVENTO, array( __CLASS__, 'resumo' ) );
		add_action(
			'init',
			static function (): void {
				if ( ! wp_next_scheduled( self::EVENTO ) ) {
					wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::EVENTO );
				} },
			50
		);
	}
    /** Mesmo assunto na prévia e no transporte; não reescreve o título escolhido. */
    public static function assunto(string $titulo, string $metodo, bool $teste=false, string $nome=''): string {
        $nome=mb_substr(trim(preg_replace('/[\r\n\x00-\x1f\x7f]+/u',' ',sanitize_text_field($nome))),0,100);
        $titulo=str_replace('{nome}',$nome!==''?$nome:'Visitante',$titulo);
        $titulo=sanitize_text_field($titulo);if(trim($titulo)===''){$titulo='Novo contato';}
        $site=sanitize_text_field(html_entity_decode(get_bloginfo('name'),ENT_QUOTES|ENT_HTML5,'UTF-8'));
        $normalizar=static fn($s)=>mb_strtolower(trim(preg_replace('/\s+/u',' ',html_entity_decode($s,ENT_QUOTES|ENT_HTML5,'UTF-8'))));
        $full=$normalizar($site);$tem=$full!==''&&preg_match('/(?<![\p{L}\p{N}])'.preg_quote($full,'/').'(?![\p{L}\p{N}])/u',$normalizar($titulo));
        $prefixo=$site!==''&&!$tem?'['.$site.'] ':'';
        $sufixo='';
        return mb_substr(($teste&&!preg_match('/^\[TESTE\]\s/iu',$titulo)?'[TESTE] ':'').$prefixo.$titulo.$sufixo,0,250);
    }
	public static function destinatarios( $v ): array {
		if ( is_string( $v ) ) {
			$v = array( $v );
		} return array_slice( array_values( array_unique( array_filter( (array) $v, static fn( $e )=>is_string( $e ) && is_email( $e ) && ! preg_match( '/[\r\n]/', $e ) ) ) ), 0, 5 );
	}
	public static function enviar( string $record ): array {
		global $wpdb;
		$t    = F3Base_Leads_Repositorio::tabela();
		$lead = F3Base_Leads_Repositorio::obter( $record );
		if ( ! $lead || 'pendente' !== $lead['aviso'] || 'suspeito' === $lead['captura'] || $lead['lixeira'] || $lead['eliminacao_pendente'] ) {
			return array( 'codigo' => 'nao_elegivel' ); }
		$teste = 'teste' === ( $lead['classe_trafego'] ?? 'nao_marcado' );
        if ( $teste && 'suprimir' === F3Base_Testes::politica( 'email', 'teste' ) ) {
            $wpdb->update($t,array('aviso'=>'suprimido_teste'),array('record_id'=>$record,'aviso'=>'pendente'));
            return array('codigo'=>'suprimido_teste');
        }
        $to = self::destinatarios( $teste ? F3Base_Testes::config()['email_destinatarios'] : self::destinatarios_do_contato($lead) );
		if ( ! $to ) {
			$wpdb->update(
				$t,
				array( 'aviso' => 'desconfigurado' ),
				array(
					'record_id' => $record,
					'aviso'     => 'pendente',
				)
			);
			return array( 'codigo' => 'destinatario_ausente' ); }
        $prepared=F3Base_Contato_Comunicacao::preparar($lead);if(empty($prepared['ok'])){$wpdb->update($t,array('aviso_erro'=>substr($prepared['codigo'],0,190)),array('record_id'=>$record,'aviso'=>'pendente'));self::agendar($record);return array('codigo'=>$prepared['codigo'],'tentar_em'=>$prepared['tentar_em']??time()+60);}
		$janela = (string) floor( time() / HOUR_IN_SECONDS );
		if ( ! F3Base_Leads_Repositorio::quota( 'email:' . ($teste?'teste:':'normal:') . $janela, 30, (int) ( (int) $janela + 2 ) * HOUR_IN_SECONDS ) ) {
			$wpdb->update($t,array('aviso'=>'aguarda_resumo'),array('record_id'=>$record,'aviso'=>'pendente'));return array( 'codigo' => 'aguarda_resumo' ); }
		if ( 1 !== $wpdb->update(
			$t,
			array(
				'aviso'    => 'enviando',
				'aviso_em' => time(),
			),
			array(
				'record_id' => $record,
				'aviso'     => 'pendente',
			)
		) ) {
			return array( 'codigo' => 'reservado' ); }
        $preparo_minimo=false;
		$host    = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$from    = 'site@' . preg_replace( '/^www\./', '', $host );
		$headers = array( 'From: ' . sanitize_text_field( get_bloginfo( 'name' ) ) . ' <' . $from . '>', 'X-F3base-Formulario: ' . sanitize_key( $lead['formulario'] ), 'X-F3base-Metodo: ' . sanitize_key( $lead['metodo'] ) );
		if ( $teste ) { $headers[] = 'X-F3Base-Teste: 1'; }
		if ( is_email( $lead['email'] ) && ! preg_match( '/[\r\n]/', $lead['email'] ) ) {
			$headers[] = 'Reply-To: ' . $lead['email']; }
        try {
		$titulo  = sanitize_text_field( (string) ( $lead['dados']['assunto'] ?? 'Novo contato' ) );
		$titulo=$lead['captura']==='clique'?'Clique: '.F3Base_Relatorios::rotulo((string)$lead['metodo']).' — '.(!empty($lead['dados']['snapshot']['pagina_titulo'])?$lead['dados']['snapshot']['pagina_titulo']:(F3Base_Contato_Apresentacao::url($lead['pagina'])?:'Página não informada')):$titulo;
		$assunto = self::assunto($titulo,(string)$lead['metodo'],$teste,(string)($lead['nome']??''));
        $a=$prepared['apresentacao'];$text=F3Base_Contato_Apresentacao::texto($a);$body=F3Base_Email::html($a);
        $meta=array('versao'=>$a['versao'],'montado_em'=>$a['montado_em'],'corte_em'=>$a['corte_em'],'corte'=>$a['journey_corte']);$stored=false;
        for($attempt=0;$attempt<3;$attempt++){$raw=$wpdb->get_row($wpdb->prepare('SELECT entrega,aviso,eliminacao_pendente,lixeira FROM %i WHERE record_id=%s',$t,$record),ARRAY_A);if(!$raw||$raw['aviso']!=='enviando'||$raw['eliminacao_pendente']||$raw['lixeira']){break;}$ent=json_decode((string)($raw['entrega']??''),true)?:array();$ent['aviso_resumo']=$meta;$n=$wpdb->update($t,array('entrega'=>wp_json_encode($ent)),array('record_id'=>$record,'aviso'=>'enviando','entrega'=>$raw['entrega'],'eliminacao_pendente'=>0,'lixeira'=>0));if($n===1||($n===0&&json_decode((string)($raw['entrega']??''),true)===$ent)){$stored=true;break;}}
        if(!$stored){$wpdb->update($t,array('aviso'=>'pendente'),array('record_id'=>$record,'aviso'=>'enviando'));self::agendar($record);return array('codigo'=>'resumo_persistencia_falhou');}
        } catch(Throwable $e){
            $assunto=self::assunto('Novo contato recebido',(string)$lead['metodo'],$teste,(string)($lead['nome']??''));
            $preparo_minimo=true;$text="Um contato foi registrado. A apresentação detalhada não pôde ser preparada. Consulte o registro no painel:\n".admin_url('admin.php?page=f3base-leads&record_id='.$record);
            $body=F3Base_Email::documento('<h1>Novo contato recebido</h1><p>'.nl2br(esc_html($text)).'</p>');
            $wpdb->update($t,array('aviso_erro'=>'corpo_minimo_preparacao_local'),array('record_id'=>$record,'aviso'=>'enviando'));
        }
		// A crash/timeout leaves sending -> uncertain; it is never retried silently.
        try {
            $ok=F3Base_Email::enviar($to,$assunto,$body,$text,$headers);
            $estado=$ok?'processado':'falhou';
        }catch(Throwable $e){$ok=false;$estado='incerto';}
			$wpdb->update(
				$t,
				array(
					'aviso'      => $estado,
					'aviso_em'   => time(),
					'aviso_erro' => $ok ? ($preparo_minimo?'corpo_minimo_preparacao_local':'') : 'transporte_sem_confirmacao',
				),
				array(
					'record_id' => $record,
					'aviso'     => 'enviando',
				)
			);
		return array(
			'codigo'      => $estado,
			'recebimento' => 'nao_comprovado',
		);
	}
	public static function reenviar( array $e ): array {
		if ( ! F3Base_Leads_Admin::pode( 'f3base_gerir_leads' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		$r = F3Base_Leads_Repositorio::obter( $e['record_id'] ?? '' );
		if ( ! $r || $r['eliminacao_pendente'] || $r['lixeira'] || 'suspeito' === $r['captura'] ) {
			return array(
				'ok'     => false,
				'codigo' => 'nao_elegivel',
			); }
		$rev = hash( 'sha256', $r['aviso'] . '|' . $r['aviso_em'] . '|' . $r['revisao'] );
		if ( ( ! ( $e['simular'] ?? true ) || isset( $e['revisao_esperada'] ) ) && ! hash_equals( $rev, (string) ( $e['revisao_esperada'] ?? '' ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'conflito',
			); }
		if ( ! in_array( $r['aviso'], array( 'falhou', 'incerto', 'desconfigurado', 'pendente' ), true ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'estado_nao_reenviavel',
			); }
		if ( $e['simular'] ?? true ) {
			return array(
				'ok'                      => true,
				'simulado'                => true,
				'estado'                  => $r['aviso'],
				'revisao'                 => $rev,
				'exige_aceite_duplicacao' => 'incerto' === $r['aviso'],
			); }
		if ( 'incerto' === $r['aviso'] && empty( $e['aceitar_possivel_duplicacao'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'reconciliar_transporte_ou_aceitar_duplicacao',
			); }
		global $wpdb;
		$ok = $wpdb->update(
			F3Base_Leads_Repositorio::tabela(),
			array(
				'aviso'    => 'pendente',
				'aviso_em' => time(),
			),
			array(
				'record_id' => $r['record_id'],
				'aviso'     => $r['aviso'],
				'aviso_em'  => $r['aviso_em'],
				'revisao'   => $r['revisao'],
			)
		);
		return 1 === $ok ? array(
			'ok'        => true,
			'resultado' => self::enviar( $r['record_id'] ),
		) : array(
			'ok'     => false,
			'codigo' => 'conflito',
		);
	}

    public static function resumo(): void {
        global $wpdb;$t=F3Base_Leads_Repositorio::tabela();$wpdb->query($wpdb->prepare("UPDATE %i SET aviso='incerto' WHERE aviso='enviando' AND aviso_em<%d",$t,time()-300));
        $corte=(int)floor(time()/HOUR_IN_SECONDS)*HOUR_IN_SECONDS;
        $ids=$wpdb->get_col($wpdb->prepare("SELECT record_id FROM %i WHERE aviso='aguarda_resumo' AND captura<>'suspeito' AND lixeira=0 AND eliminacao_pendente=0 AND criado_em<%s ORDER BY criado_em LIMIT 1000",$t,gmdate('Y-m-d H:i:s',$corte)));
        $groups=array();$presentations=array();foreach($ids as $id){$lead=F3Base_Leads_Repositorio::obter($id);if(!$lead){continue;}$test=$lead['classe_trafego']==='teste';if($test&&F3Base_Testes::politica('email','teste')==='suprimir'){$wpdb->update($t,array('aviso'=>'suprimido_teste'),array('record_id'=>$id,'aviso'=>'aguarda_resumo'));continue;}$to=self::destinatarios($test?F3Base_Testes::config()['email_destinatarios']:self::destinatarios_do_contato($lead));if(!$to){$wpdb->update($t,array('aviso'=>'desconfigurado','aviso_erro'=>'sem_destinatarios_no_resumo'),array('record_id'=>$id,'aviso'=>'aguarda_resumo'));continue;}$prep=F3Base_Contato_Comunicacao::preparar($lead);if(empty($prep['ok'])){continue;}$presentations[$id]=$prep['apresentacao'];$key=hash('sha256',wp_json_encode(array($test,$to)));$groups[$key]['to']=$to;$groups[$key]['test']=$test;$groups[$key]['ids'][]=$id;}
        foreach(array_slice($groups,0,30,true) as $key=>$g){if(!F3Base_Leads_Repositorio::quota('resumo:'.$corte.':'.$key,1,time()+2*DAY_IN_SECONDS)){continue;}$selected=array();foreach($g['ids'] as $id){if(1===$wpdb->update($t,array('aviso'=>'enviando','aviso_em'=>time()),array('record_id'=>$id,'aviso'=>'aguarda_resumo','lixeira'=>0,'eliminacao_pendente'=>0))){$selected[]=$id;}}if(!$selected){continue;}
            try{$texto=count($selected)." contatos destinados a esta equipe aguardam atendimento.\n";$body='<h1>Resumo de contatos</h1><p><strong>'.count($selected).'</strong> contatos destinados a esta equipe aguardam atendimento.</p>';
            foreach($selected as $id){$a=$presentations[$id];$line=F3Base_Contato_Comunicacao::linha_resumo($a);$texto.="\n".$line."\n".$a['registro_url']."\n";$body.='<p><strong>'.esc_html($line).'</strong><br><a href="'.esc_url($a['registro_url']).'">Consultar contato no WordPress</a></p>';}$html=F3Base_Email::documento($body);$ok=F3Base_Email::enviar($g['to'],($g['test']?'[TESTE] ':'').'Resumo de contatos — '.sanitize_text_field(get_bloginfo('name')),$html,$texto,array());$state=$ok?'resumo_processado':'falhou';}catch(Throwable $e){$state='incerto';}
            foreach($selected as $id){$wpdb->update($t,array('aviso'=>$state,'aviso_em'=>time()),array('record_id'=>$id,'aviso'=>'enviando'));}
        }F3Base_Arquivos_Privados::limpar_orfaos();
    }
}
