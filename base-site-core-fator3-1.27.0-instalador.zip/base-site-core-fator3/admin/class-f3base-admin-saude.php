<?php
/** Painel de operação: leituras explícitas separadas das ações administrativas. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Admin_Saude {
	public const ACAO = 'f3base_operar';
	public static function iniciar(): void {
		add_action( 'admin_post_' . self::ACAO, array( __CLASS__, 'operar' ) ); }

	public static function operar(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sem permissão.', '', array( 'response' => 403 ) ); }
		check_admin_referer( self::ACAO );
		$acao = sanitize_key( is_string( $_POST['operacao'] ?? null ) ? wp_unslash( $_POST['operacao'] ) : '' );
		$r    = array(
			'ok'     => false,
			'codigo' => 'operacao_nao_permitida',
		);
		if ( in_array( $acao, array( 'schema', 'llms_arquivo' ), true ) ) {
			$revisao = sanitize_text_field( wp_unslash( $_POST['revisao_esperada'] ?? '' ) );
			$r       = 'schema' === $acao ? F3Base_Schema_Verificacao::executar(
				array(
					'acao'             => 'verificar_publico',
					'revisao_esperada' => $revisao,
				)
			) : F3Base_Llms_Arquivo::executar(
				array(
					'acao'             => 'regenerar',
					'revisao_esperada' => $revisao,
				)
			);
		} elseif ( 'servidor' === $acao ) {
            $r=F3Base_Servidor::executar(array('acao'=>'aplicar','revisao_esperada'=>sanitize_text_field(wp_unslash($_POST['revisao_esperada']??''))));
        } elseif ( 'llms' === $acao ) { $r=F3Base_Llms_Cobertura::executar(5);
        } elseif ( 'reativar_intencao' === $acao ) {
            $r=F3Base_Operacao::executar_pendentes(array('tarefas'=>array(sanitize_key($_POST['tarefa']??'')),'intencao'=>sanitize_text_field(wp_unslash($_POST['intencao']??'')),'reativar_esgotada'=>true,'limite'=>1));
        } elseif ( 'pendentes' === $acao ) {
			$r = F3Base_Operacao::executar_pendentes(); } elseif ( in_array( $acao, array( 'acessos', 'capi', 'robots' ), true ) ) {
			$r = F3Base_Operacao::executar_uma( $acao, 'administracao', false ); } elseif ( 'publicacao' === $acao ) {
						$caminho = is_string( $_POST['caminho'] ?? null ) ? wp_unslash( $_POST['caminho'] ) : '/llms.txt';
						$r       = F3Base_Publicacao_Sonda::verificar(
							array(
								'caminho' => $caminho,
								'metodo'  => 'GET',
							)
						);
			} elseif ( 'previa' === $acao ) {
				$tipo = sanitize_key( is_string( $_POST['tipo'] ?? null ) ? wp_unslash( $_POST['tipo'] ) : '' );
				if ( in_array( $tipo, array( 'llms', 'full', 'robots', 'markdown' ), true ) ) {
					$post_id = isset( $_POST['post_id'] ) && is_scalar( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
					$r       = F3Base_Publicacao_Sonda::previa( $tipo, $post_id );
				}
			}
			if ( is_wp_error( $r ) ) {
				$r = array(
					'ok'     => false,
					'codigo' => $r->get_error_code(),
					'motivo' => $r->get_error_message(),
				); }
			// Evidência administrativa limitada e temporária; sem copiar corpos de leads ou segredos.
			if ( isset( $r['texto'] ) && strlen( $r['texto'] ) > 24000 ) {
				$r['texto']           = mb_strcut( $r['texto'], 0, 24000, 'UTF-8' );
				$r['previa_truncada'] = true; }
			if ( strlen( (string) wp_json_encode( $r ) ) > 65536 ) {
				$r = array(
					'ok'     => false,
					'codigo' => 'resultado_extenso',
					'motivo' => 'A resposta excede a prévia da tela. Consulte a operação pelo contrato com paginação.',
				); }
			set_transient( 'f3base_operacao_resultado_' . get_current_user_id(), $r, 5 * MINUTE_IN_SECONDS );
			wp_safe_redirect(
				add_query_arg(
					array(
						'page' => F3Base_Admin_Tela::SLUG,
						'aba'  => 'tecnica',
					),
					admin_url( 'admin.php' )
				)
			);
		exit;
	}

	private static function abrir_formulario( string $operacao ): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="f3base-operacao-form">';
		echo '<input type="hidden" name="action" value="' . esc_attr( self::ACAO ) . '"><input type="hidden" name="operacao" value="' . esc_attr( $operacao ) . '"><input type="hidden" name="_wpnonce" value="' . esc_attr( wp_create_nonce( self::ACAO ) ) . '">';
	}

    public static function render_execucoes(): void {
        $r=F3Base_Execucoes::resumo();$state=F3Base_Instalacao::resumo();
        echo '<section class="f3base-bloco"><h2>Passagens das tarefas do Site Core</h2><p>O cron do servidor está '.(!empty($r['cron_servidor_ativo'])?'<strong>com passagem CLI recente</strong>':'<strong>sem passagem CLI nas últimas duas horas</strong>').'. Esse sinal não inspeciona o crontab.</p><table class="widefat striped"><thead><tr><th>Origem</th><th>Última passagem</th><th>Passagens em 24 horas</th></tr></thead><tbody>';
        foreach(array('cli'=>array('CLI','cli'),'http_cron'=>array('HTTP / visita','http'),'manual'=>array('Ação manual','manual')) as $key=>$v){echo '<tr><th>'.esc_html($v[0]).'</th><td>'.esc_html($r['ultima_'.$v[1]]['local']??'Nenhuma observada').'</td><td>'.(int)($r['passagens_24h'][$key]??0).'</td></tr>';}
        echo '</tbody></table><p>'.(!empty($r['janela_completa'])?'Janela de 24 horas coberta pelo diário.':'O diário ainda não cobre 24 horas completas.').' Contagem por passagem, incluindo falhas e chamadas sem trabalho. As tarefas filhas não aumentam essa contagem.</p>';
        if(empty($state['concluido_em'])){echo '<p role="alert">Atualização pendente: '.esc_html($state['ultima_falha']['etapa']??'inicialização').'. '.esc_html($state['ultima_falha']['codigo']??'').'</p>';}
        $origin=sanitize_key($_GET['exec_origem']??'');$page=max(1,(int)($_GET['exec_pagina']??1));$input=array('pagina'=>$page);if(in_array($origin,array('cli','http_cron','manual'),true)){$input['origem']=$origin;}
        echo '<form method="get"><input type="hidden" name="page" value="base-site-core-fator3"><input type="hidden" name="aba" value="operacao"><label>Origem <select name="exec_origem">';foreach(array(''=>'Todas','cli'=>'CLI','http_cron'=>'HTTP / visita','manual'=>'Manual') as $key=>$label){echo '<option value="'.esc_attr($key).'" '.selected($origin,$key,false).'>'.esc_html($label).'</option>';}echo '</select></label> <button class="button">Filtrar histórico</button></form>';
        $history=F3Base_Execucoes::listar($input);echo '<h3>Histórico preservado</h3><div class="f3base-tabela-rolagem"><table class="widefat striped"><thead><tr><th>Início</th><th>Origem</th><th>Escopo</th><th>Resultado</th><th>Referência</th></tr></thead><tbody>';
        foreach($history['linhas']??array() as $row){echo '<tr><td>'.esc_html($row['inicio_formatado']['local']).'</td><td>'.esc_html($row['origem']).'</td><td>'.esc_html($row['tarefa']?:$row['entrada']).'</td><td>'.esc_html($row['codigo']).'</td><td><code>'.esc_html($row['run_id']).'</code></td></tr>';}
        echo '</tbody></table></div><p>';if($page>1){echo '<a class="button" href="'.esc_url(add_query_arg('exec_pagina',$page-1)).'">Anterior</a> ';}if(!empty($history['proxima_pagina'])){echo '<a class="button" href="'.esc_url(add_query_arg('exec_pagina',$page+1)).'">Próxima</a>';}echo '</p><details><summary>Como executar e recuperar</summary><p>Use <code>wp f3base pendentes executar --format=json</code> ou <code>f3base/executar-pendentes</code>. Até três tarefas por passagem, com orçamento compartilhado de 30 segundos. Saúde e consultas do histórico não executam tarefas.</p><p>Antes de restaurar banco/arquivos, leia e prepare a barreira em <code>f3base/operacao-recuperacao</code>. O Core informa quando seus trabalhos foram drenados. O MCP Google tem uma barreira independente. Leia <code>docs/OPERACAO-GSC-1.20.md</code>.</p></details></section>';
        self::intencoes();
    }

	public static function render( ?array $resumo = null ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return; }
		$r      = $resumo ?? F3Base_Saude::resumo();
		$ultima = get_transient( 'f3base_operacao_resultado_' . get_current_user_id() );
		if ( is_array( $ultima ) ) {
			delete_transient( 'f3base_operacao_resultado_' . get_current_user_id() );
			echo '<div class="notice notice-' . ( ! empty( $ultima['ok'] ) ? 'success' : 'warning' ) . '"><p>' . esc_html( (string) ( $ultima['motivo'] ?? $ultima['codigo'] ?? 'Operação concluída. Confira a evidência.' ) ) . '</p><details><summary>Resultado da operação</summary><pre>' . esc_html( (string) wp_json_encode( $ultima, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details></div>';
		}
		echo '<section class="f3base-bloco f3base-saude"><h2>Estado operacional</h2><p>Configuração salva, efeito aplicado e resposta pública verificada são etapas independentes. Os dados abaixo mostram o estado existente e a data da última execução.</p><div class="f3base-saude-grade">';
		$alvos = array( 'acessos-servidor', 'comportamento', 'meta-capi', 'consentimento', 'llms-txt-reserva', 'robots-txt', 'cache-publico' );
		foreach ( $r['modulos'] as $m ) {
			if ( ! in_array( $m['id'], $alvos, true ) ) {
				continue; }
			echo '<article class="f3base-saude-card"><h3>' . esc_html( $m['nome'] ) . '</h3><span class="f3base-estado f3base-estado--' . esc_attr( $m['estado'] ) . '">' . esc_html( ucfirst( $m['estado'] ) ) . '</span><p>' . esc_html( $m['motivo'] ) . '</p></article>';
		}
		echo '</div><h3>Agenda e últimas execuções</h3><div class="f3base-tabela-rolagem" tabindex="0" aria-label="Agenda das tarefas"><table class="widefat striped"><thead><tr><th>Tarefa</th><th>Próxima execução</th><th>Última tentativa</th><th>Último sucesso</th><th>Saldo observado</th><th>Situação</th></tr></thead><tbody>';
		$situacoes = array(
			'inativa'         => 'Inativa',
			'sem_agendamento' => 'Sem agendamento',
			'atrasada'        => 'Execução atrasada',
			'agendada'        => 'Agendada',
			'concluido'       => 'Concluída',
			'pendente'        => 'Pendente',
			'parcial'         => 'Parcial',
			'falha'           => 'Falhou',
			'em_execucao'     => 'Em execução',
		);
		foreach ( $r['agenda'] as $a ) {
			$u          = $a['ultima_execucao'];
			$fim        = (int) ( ! empty( $u['fim'] ) ? $u['fim'] : ( $u['inicio'] ?? 0 ) );
			$sucesso    = (int) ( $a['ultimo_sucesso']['fim'] ?? 0 );
			$saldo      = $a['saldo'] ?? array();
			$pendencias = ! empty( $saldo['conhecido'] ) ? (string) $saldo['quantidade'] . ' na última observação' : 'Ainda não medido';
			if ( ! empty( $saldo['observado_em'] ) ) {
				$pendencias .= ' (' . wp_date( 'd/m/Y H:i:s', (int) $saldo['observado_em'] ) . ')';
			}
			echo '<tr><th scope="row">' . esc_html( $a['rotulo'] ) . '</th><td>' . esc_html( $a['proxima_execucao'] ? wp_date( 'd/m/Y H:i:s', $a['proxima_execucao'] ) : 'Sem agendamento' ) . '</td><td>' . esc_html( $fim ? wp_date( 'd/m/Y H:i:s', $fim ) . ' — ' . ( $situacoes[ $u['status'] ?? '' ] ?? 'Consultar resultado' ) : 'Sem registro nesta versão' ) . '</td><td>' . esc_html( $sucesso ? wp_date( 'd/m/Y H:i:s', $sucesso ) : 'Ainda não confirmado' ) . '</td><td>' . esc_html( $pendencias ) . '</td><td>' . esc_html( $a['reservada'] ? 'Em execução' : ( $situacoes[ $a['codigo'] ] ?? 'Consultar resultado' ) ) . '</td></tr>';
		}
		echo '</tbody></table></div><p class="description">Saldo de acessos representa arquivos na última inspeção; na fila, inclui eventos que aguardam reconciliação. Sem observação não significa saldo zero. Agendar não confirma a execução. Sites com cache ou pouco tráfego dependem da frequência do executor configurado na hospedagem.</p>';
        $cadencia=F3Base_Modulo_Cadencia_Relatorio::consultar();$execucao=$cadencia['ultima_execucao'];
        echo '<h3>Relatório periódico local</h3><p>A cadência verifica os estados dos módulos, relê as configurações e conta conteúdo demonstrativo. Guarda o último resultado aqui e em <code>f3base/saude-ler → cadencia</code>. Não envia e-mail nem faz correções automáticas.</p>';
        echo '<p>Limiar de ajustes: '.esc_html((string)$cadencia['limiar_ajustes']).' (zero desliga esse gatilho). Acumulados: '.esc_html((string)$cadencia['ajustes_acumulados']).'. Próxima execução: '.esc_html($cadencia['proxima_execucao']?wp_date('d/m/Y H:i:s',$cadencia['proxima_execucao']):'Sem agendamento').'. Fuso: '.esc_html($cadencia['fuso']).'.</p>';
        if($execucao){echo '<p>Última execução: '.esc_html(wp_date('d/m/Y H:i:s',(int)$execucao['em'])).' — '.esc_html($execucao['resultado']??'não informado').'. Gatilho: '.esc_html($execucao['gatilho']??'').'. Duração: '.esc_html((string)($execucao['duracao_ms']??0)).' ms; atraso: '.esc_html((string)($execucao['atraso_segundos']??0)).' s.</p><dl>';foreach(array('modulos'=>'Módulos','options'=>'Configurações','demonstrativo'=>'Conteúdo demonstrativo','erro'=>'Erro observado') as $k=>$rotulo){if(!empty($execucao[$k])){echo '<dt><strong>'.esc_html($rotulo).'</strong></dt><dd>'.esc_html((string)$execucao[$k]).'</dd>';}}echo '</dl>';}else{echo '<p>Ainda não existe resultado registrado.</p>';}
        $servidor=F3Base_Servidor::consultar();
        echo '<h3>Publicação e regras do servidor</h3><p>Índices em preparo preservam a geração anterior. Aplicar compara a revisão, guarda backup privado, confere PHP e HTTP e tenta restaurar em caso de regressão. A ativação do plugin não altera o .htaccess.</p><p>Regras: '.esc_html($servidor['status']).'. A listagem da raiz só muda se sua preferência estiver ligada.</p>';
        self::abrir_formulario('llms');submit_button('Avançar preparação dos índices','secondary','submit',false);echo '</form>';
        self::abrir_formulario('servidor');echo '<input type="hidden" name="revisao_esperada" value="'.esc_attr($servidor['revisao']).'">';submit_button('Aplicar preferências ao servidor','secondary','submit',false);echo '</form>';
		self::abrir_formulario( 'pendentes' );
		echo '<button class="button">Executar tarefas vencidas</button></form></section>';F3Base_Configuracao_Medicao::avisos_html();
		echo '<section class="f3base-bloco"><h2>Inspeção dos arquivos públicos</h2><p>Verificar publicação consulta a resposta e registra a evidência. Reconciliar robots pode atualizar o arquivo gerenciado e é uma ação separada.</p><div class="f3base-acoes-publicacao">';
		self::abrir_formulario( 'publicacao' );
		echo '<label>Arquivo <select name="caminho"><option value="/robots.txt">robots.txt</option><option value="/llms.txt">llms.txt</option><option value="/llms-full.txt">llms-full.txt</option></select></label> <button class="button button-primary">Verificar publicação</button></form>';
		self::abrir_formulario( 'previa' );
		echo '<label>Prévia <select name="tipo"><option value="llms">llms.txt</option><option value="full">llms-full.txt</option><option value="robots">robots.txt</option><option value="markdown">Página em Markdown</option></select></label> <label>ID do conteúdo (opcional, obrigatório para Markdown) <input type="number" name="post_id" min="1" step="1" class="small-text"></label> <button class="button">Gerar prévia e explicar seleção</button></form>';
		self::abrir_formulario( 'robots' );
		echo '<button class="button">Reconciliar robots gerenciado</button></form></div>';
		echo '<details><summary>Responsáveis e evidências de publicação</summary><pre>' . esc_html( (string) wp_json_encode( F3Base_Publicacao_Sonda::resumo(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details></section>';
		echo '<section class="f3base-bloco"><h2>Schema e arquivo llms</h2>';
		foreach ( array(
			'schema'       => array( 'f3base_seo_entidade', 'Verificar schema publicado', F3Base_Schema_Verificacao::consultar() ),
			'llms_arquivo' => array( 'f3base_llms', 'Regenerar llms e verificar publicação', F3Base_Llms_Arquivo::consultar() ),
		) as $acao => $item ) {
			self::abrir_formulario( $acao );
			echo '<input type="hidden" name="revisao_esperada" value="' . esc_attr( F3Base_Options::revisao( $item[0] ) ) . '"><button class="button">' . esc_html( $item[1] ) . '</button></form><pre>' . esc_html( wp_json_encode( $item[2], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>';
		}
		echo '<h3>Auditoria de configuração</h3><pre>' . esc_html( wp_json_encode( $r['auditoria_configuracao'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>';
		echo '<p><a href="' . esc_url( add_query_arg( array( 'f3base_perfil' => wp_create_nonce( 'f3base_perfil' ) ), home_url( '/' ) ) ) . '">Medir a página inicial nesta sessão administrativa</a></p><pre>' . esc_html( wp_json_encode( get_transient( 'f3base_perfil_' . get_current_user_id() ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre></section>';
	}
    private static function intencoes(): void {
        $wait=F3Base_Operacao::esperas();echo '<section class="f3base-bloco"><h2>Diagnóstico de esperas</h2><p>Alerta após 15 minutos de atraso elegível. Quotas futuras permanecem como espera prevista. A simulação e a reconciliação delimitada estão disponíveis em f3base/executar-pendentes.</p><table class="widefat striped"><thead><tr><th>Tarefa / causa</th><th>Espera e prazo</th><th>Reserva e agenda</th><th>Último progresso</th></tr></thead><tbody>';
        foreach($wait['itens'] as $w){echo '<tr><td>'.esc_html($w['tarefa'].' · '.$w['causa']).'<br>'.esc_html($w['parada']?'Atraso sem progresso':$w['estado']).'</td><td>'.esc_html('Idade: '.$w['idade_segundos'].' s · atraso: '.$w['atraso_elegivel_segundos'].' s').'<br>'.esc_html(wp_date('d/m/Y H:i:s T',$w['tentar_em'])).'</td><td>'.esc_html(($w['reserva_ate']>time()?'Reserva ativa':'Sem reserva ativa').' · '.($w['agenda_confirmada']?'Agenda presente':'Agenda ausente')).'</td><td>'.esc_html($w['ultimo_progresso']?wp_date('d/m/Y H:i:s T',$w['ultimo_progresso']):'Não observado').'</td></tr>';}
        echo '</tbody></table></section>';
        $page=max(1,(int)($_GET['intencoes_pagina']??1));$r=F3Base_Operacao_Intencoes::resumo($page);echo '<section class="f3base-bloco"><h2>Intenções pendentes e esgotadas</h2><p>Oito falhas seguidas reduzem a repetição a uma tentativa por hora. A retomada abaixo reinicia um ciclo limitado; efeitos remotos incertos continuam sujeitos à reconciliação do módulo. O histórico é preservado.</p><table class="widefat striped"><thead><tr><th>Tarefa / ocorrência original</th><th>Estado / falhas</th><th>Próxima tentativa</th><th>Ação</th></tr></thead><tbody>';
        foreach($r['itens']??array() as $e){echo '<tr><td>'.esc_html(F3Base_Operacao::tarefas()[$e['id']]['rotulo']??$e['id']).'<br>'.esc_html(wp_date('d/m/Y H:i:s T',$e['timestamp'])).'<details><summary>Identificador</summary><code>'.esc_html($e['intencao']).'</code></details></td><td>'.esc_html(!empty($e['em_execucao'])?'Em execução':array('pendente'=>'Aguardando','esgotada'=>'Tentativas esgotadas','suspensa'=>'Suspensa para revisão')[$e['estado']]).' · '.(int)$e['falhas'].'</td><td>'.esc_html(wp_date('d/m/Y H:i:s T',$e['tentar_em'])).'</td><td>';if($e['estado']==='esgotada'){self::abrir_formulario('reativar_intencao');echo '<input type="hidden" name="tarefa" value="'.esc_attr($e['id']).'"><input type="hidden" name="intencao" value="'.esc_attr($e['intencao']).'"><button class="button">Retomar esta intenção</button></form>';}echo '</td></tr>';}
        echo '</tbody></table>';if($page>1){echo '<a href="'.esc_url(add_query_arg('intencoes_pagina',$page-1)).'">Anterior</a> ';}if(count($r['itens']??array())===100){echo '<a href="'.esc_url(add_query_arg('intencoes_pagina',$page+1)).'">Próxima</a>';}echo '</section>';
    }
}
