# Fonte — Fator3 MCP Meta 0.18.0

Base 0.17.0; Pedido 26. Código editável em build; build/build.py gera runtime e ZIP determinísticos. Defina F3_SOCIAL_PHP para PHP CLI compatível; lock tools/build-runtime0160.json. plugin contém runtime idêntico ao instalador final. Consulte planning/RELEASE-0180.md, tests/README-0180.md e evidence. Conteúdo em history é histórico e não implica reexecução. Nenhum laboratório compõe o instalador.
