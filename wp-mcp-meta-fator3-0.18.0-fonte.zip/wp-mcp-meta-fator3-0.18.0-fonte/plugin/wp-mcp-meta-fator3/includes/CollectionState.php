<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Collection diagnostics only. Never grants access or replaces a credential. */
final class CollectionState {
    public static function useful(array $row): bool {
        if(($row['availability']??'available')!=='available')return false;
        if(!isset($row['metric']))return (bool)$row;
        return ($row['value']??null)!==null||!empty($row['breakdowns'])||(bool)array_filter($row['source_values']??[],static fn($v)=>is_array($v)&&($v['value']??null)!==null);
    }
    public static function diagnostic(string $code,array $details=[]): array {
        $out=['code'=>$code,'http_status'=>null,'provider_code'=>null,'provider_subcode'=>null,'observed_at'=>time()];
        foreach(['http_status','provider_code','provider_subcode','observed_at','retry_after','authorization_revision','credential_generation'] as $key)
            if(isset($details[$key])&&is_int($details[$key])&&$details[$key]>=0)$out[$key]=$details[$key];
        foreach(['auth_scope','origin_code'] as $key)if(isset($details[$key])&&is_string($details[$key])&&preg_match('/^[a-z_]{1,64}$/D',$details[$key]))$out[$key]=$details[$key];
        if(is_bool($details['provider_is_transient']??null))$out['provider_is_transient']=$details['provider_is_transient'];
        if(is_array($details['connection_validation']??null))$out['connection_validation']=array_intersect_key($details['connection_validation'],array_flip(['http_status','provider_code','provider_subcode','provider_is_transient']));
        if(is_array($details['execution_budget']??null))$out['execution_budget']=array_intersect_key($details['execution_budget'],array_flip(['kind','scope','request_limit','requests_used','requests_remaining','started_at','deadline_at','seconds_remaining','observed_at','exhausted_by','replenishment']));
        return $out;
    }
    /** Read-only projection: a useful partial row is not proof that its error recovered. */
    public static function scheduleDiagnostic(array $v): array {
        $error=is_array($v['last_error']??null)?$v['last_error']:null;
        $at=is_int($error['observed_at']??null)&&$error['observed_at']>0?$error['observed_at']:null;
        $code=$v['last_code']??null;$status=$v['last_run_status']??null;
        $failed=$code!==null||in_array($status,['failed','partial'],true);
        $superseded=$error!==null&&!$failed&&($status==='complete'||($at!==null&&(int)($v['last_success_at']??0)>$at));
        return ['last_run_status'=>$status,'last_code'=>$code,'last_success_at'=>$v['last_success_at']??null,
            'last_error'=>$error,'last_error_at'=>$at,'last_error_superseded'=>$superseded,
            'last_error_state'=>$error===null?'none':($superseded?'superseded':($failed?'current':'unknown'))];
    }
    /** A resource refusal is insufficient. Confirm on the same saved credential's /me endpoint. */
    public static function classify(Fault $e,array $c): Fault {
        if(!in_array($e->reason,['token_rejected','asset_access_denied'],true))return $e;
        try{$r=Http::request($c,'me',['fields'=>'id'])['body'];if(empty($r['id']))return $e;}
        catch(Fault $validation){
            if(in_array($validation->reason,['token_rejected','asset_access_denied'],true)&&isset($validation->details['http_status']))
                return new Fault('not_authorized','A Meta recusou a credencial também na validação da conexão. Renove o token ou confira as permissões do aplicativo.',
                    $e->details+['auth_scope'=>'connection','origin_code'=>$e->reason,'connection_validation'=>$validation->details]);
            // Rate limits, network failures and stale credentials do not prove revocation.
            if(in_array($validation->reason,['revision_conflict','storage_unavailable','busy'],true))throw $validation;
        }
        return $e;
    }
    public static function storyFault(Fault $e,array $c,?string $publishedAt=null): Fault {
        $e=self::classify($e,$c);
        if(!in_array($e->reason,['asset_access_denied','upstream_validation','resource_not_found'],true))return $e;
        $at=$publishedAt===null?false:strtotime($publishedAt);
        $code=$at!==false&&$at<=time()-86400?'story_expired':'story_insights_unavailable';
        return new Fault($code,'Story ou insight indisponível neste recorte; a recusa não comprova revogação da conexão.',$e->details+['origin_code'=>$e->reason]);
    }
    public static function current(array $error,array $c): bool {
        return ($error['authorization_revision']??null)===$c['authorization_revision']&&($error['credential_generation']??null)===$c['credential_generation'];
    }
    public static function connectionFailure(array $c): ?array {
        $row=Store::get('collection_failure',$c['id']);return $row&&self::current($row['value'],$c)&&empty($row['value']['recovered_at'])?$row['value']:null;
    }
    /** Persist the newest observed error even after recovery; last_code describes current outcome. */
    public static function record(string $jobId,array $v,?array $c,bool $fresh=false): void {
        $error=$v['last_error']??null;
        if(!$error&&!empty($v['errors'])){$first=$v['errors'][0];$error=self::diagnostic($first['code']??'fields_unavailable',$first);}
        if($error)$error=self::diagnostic($error['code'],$error);
        $connectionId=$v['query']['connection_id'];
        Store::lock('connection:'.$connectionId,static function()use($jobId,$v,$c,$fresh,$error,$connectionId){
            try{$current=Connections::get($connectionId);}catch(Fault $e){if($e->reason==='not_configured')return;throw $e;}
            // An old job must not diagnose a replacement credential or identity.
            $same=$c&&self::current(Connections::checkpoint($c),$current);
            Store::lock('schedules',static function()use($jobId,$v,$current,$same,$fresh,$error,$connectionId){
                $diagnostic=$error?array_merge($error,Connections::checkpoint($current)):null;
                $global=$same&&($diagnostic['code']??null)==='not_authorized'&&($diagnostic['auth_scope']??null)==='connection';
                if($global){$prior=Store::get('collection_failure',$connectionId);Store::put('collection_failure',$connectionId,$diagnostic,$prior['revision']??0);}
                elseif($same&&$fresh&&empty($v['last_code'])){
                    $prior=Store::get('collection_failure',$connectionId);
                    if($prior&&self::current($prior['value'],$current)&&empty($prior['value']['recovered_at'])){$state=$prior['value'];$state['recovered_at']=time();Store::put('collection_failure',$connectionId,$state,$prior['revision']);
                        foreach(Store::list('schedule',0,100) as $row){$s=$row['value'];if(($s['query']['connection_id']??null)===$connectionId&&($s['last_error']['auth_scope']??null)==='connection'&&self::current($s['last_error'],$current)){$s['last_code']=null;$s['last_recovered_at']=time();Store::put('schedule',$row['key'],$s,$row['revision']);}}
                    }
                }
                foreach(Store::list('schedule',0,100) as $row){$s=$row['value'];if(($s['query']['connection_id']??null)!==$connectionId)continue;
                    $own=($v['schedule_id']??null)===$row['key']&&($s['last_job']??null)===$jobId;
                    if(!$global&&!$own)continue;if(!$same)continue;
                    if($own){if(($v['last_code']??null)==='budget_exhausted')ExecutionBudget::failure($s,new Fault('budget_exhausted','',($error??[])));else ExecutionBudget::progress($s);if(isset($v['last_budget']))$s['last_budget']=$v['last_budget'];}
                    $s['last_code']=$global?'not_authorized':$v['last_code'];
                    if($diagnostic)$s['last_error']=$diagnostic;
                    if($own){
                        if(!empty($v['last_useful_at']))$s['last_success_at']=max((int)($s['last_success_at']??0),(int)$v['last_useful_at']);
                        $s['last_run_status']=$v['outcome']??$v['status'];$s['last_successful_rows']=$v['successful_rows']??0;$s['unavailable_metrics']=$v['unavailable_metrics']??[];
                        if($v['status']==='partial'&&($v['successful_rows']??0)>0)$s['last_partial_at']=time();
                    }
                    Store::put('schedule',$row['key'],$s,$row['revision']);
                }
            });
        });
        self::audit('collection-run',$connectionId,$v['schedule_id']??null,$jobId,$v['last_code']??'ok',$error,$v['principal']);
    }
    public static function audit(string $op,string $connectionId,?string $scheduleId,?string $jobId,string $code,?array $error,array $principal): void {
        try{Store::put('audit',wp_generate_uuid4(),['operation'=>$op,'actor'=>['type'=>'user','id'=>(int)($principal['user_id']??0)],'transport'=>'collection_worker','connection_id'=>$connectionId,'schedule_id'=>$scheduleId,'job_id'=>$jobId,'code'=>$code,'last_error'=>$error,'at'=>time()],0,0);update_option(Config::KEY.'_audit_health','ok',false);}
        catch(\Throwable $e){update_option(Config::KEY.'_audit_health','failed',false);}
    }
}
