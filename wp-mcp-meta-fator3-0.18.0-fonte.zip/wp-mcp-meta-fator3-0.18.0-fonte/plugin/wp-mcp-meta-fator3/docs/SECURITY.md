# Segurança e dados — 0.18.0

Credenciais, resultados, cursores, diários e exportações são cifrados com chave derivada dos salts do site e do blog. Backup deve incluir banco e salts. Não há URL pública de exportação. Nunca coloque tokens em tickets, documentação ou capturas de tela. Trocar salts pode tornar os dados cifrados ilegíveis.

Ativos vazios significam nenhum ativo autorizado. Todas as entradas humanas exigem manage_options. Tarefas revalidam o usuário de origem, concessão do transporte, seleção e contexto antes do HTTP e antes da entrega persistente. Revogação suspende a coleta e impede leitura local. SDK de consumidor explicitamente concedido não depende de usuário WordPress autenticado.

HTTP usa hosts fixos, caminhos permitidos, TLS, nenhuma redireção, limite de tempo/bytes e quota local por conexão. Dados da API nunca são interpretados como instruções ou caminhos executáveis. CSV neutraliza prefixos de fórmula. Auditoria guarda operação, identidade e código; não guarda token, secret ou payload de leads.

Desativação e desinstalação preservam dados cifrados; removem somente cron deste plugin. Remoção definitiva de dados exige procedimento administrativo deliberado com backup. Não há limpeza automática de dados de outros plugins.

## Histórico — Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.


## Pedido 15 — contrato de credenciais 0.9.0

`save-connection`/`rotate-token`: a candidata é validada na Meta antes de escrever. Entradas existentes são preservadas, mas valores novos inválidos agora são recusados. `save-connection`, `rotate-token` e `switch-identity` anunciam efeito remoto de leitura e efeito local de escrita; todas exigem manage_options. Identificadores anteriores não são renomeados.

Nova `meta/switch-identity`: `{connection_id, expected_revision, token, dry_run, client_id?, client_secret?, expires_at?, confirmation?}`. Simulação obrigatória com dry_run=true devolve `persisted=false`, identity, schedules, connection_revision, confirmation e confirmation_expires_in=600. Execução com dry_run=false exige a confirmation da mesma candidata/revisão. O comprovante é cifrado/autenticado e específico do site, nunca contém o token em claro. Simulação faz HTTP de leitura e a auditoria usual; não grava conexão/agenda.

Gravações de conexão retornam `persisted`, connection pública, schedules_rebased (quantidade) e schedules_requiring_review (IDs). `token_identity` inclui os nomes confirmados, validade, scopes/extra_scopes e instante da conferência; nenhum segredo é retornado. Códigos estáveis: invalid_token_format, invalid_app_id, invalid_app_secret, app_proof_required, credential_app_mismatch, credential_identity_mismatch, credential_scopes_reduced, token_rejected, token_expired, asset_access_denied, validation_limit, confirmation_mismatch, invalid_cursor/cursor_expired, revision_conflict, storage_unavailable e persistence_unconfirmed. Mensagens são em português e não reproduzem corpo bruto da Meta.

`retryable` não prova ausência de efeitos. Em persistence_unconfirmed, releia conexão, agendas e auditoria antes de repetir. A confirmação consumida na troca deixa a revisão antiga inválida. Não reenvie segredos em logs/relatórios. Formatos e exemplos completos são os schemas instalados.


## Complemento 0.11.0 — pedidos 18/19

Consulte INSTAGRAM-MESSAGING.md para as operações administrativas de conversas, configuração, escopos, webhook e contrato local instagram-first-message/1.0.0. Core 1.56.0 registra o consumidor de ingestão; contatos exigem opt-in explícito nos dois pacotes. A eliminação coordenada é descrita em MESSAGE-PRIVACY.md; Core1.57.1 já integra esse SDK. Consulte STORY-ARCHIVE.md para novos campos/breakdowns, limites do arquivo privado, agenda horária e diagnóstico de supressão. Os 35 IDs anteriores são preservados e há seis operações aditivas (41).

## Eliminação explícita na 0.12.0

O SDK Messaging acrescenta privacyContract, privacyStatus, eraseLocalData e erasureReceipt, contrato instagram-message-erasure/1.0.0. A eliminação administrativa solicitada prevalece sobre retenção ilimitada; bloqueios pseudônimos e recibos permanecem. Nenhum processo automático apaga dados nem habilita contatos. Leia MESSAGE-PRIVACY.md para revisão, autorização atual, falhas parciais, cron e preservação de chaves.


## Meta Ads na 0.13.0

Pedido20 inclui leitura Ads: seleção explícita/ads_read, dias completos no fuso da conta, acervo cifrado sempre sem prazo, agendas e CSV/JSON. Canal ads, relatório ads_insights, nível selecionável. Consumidores locais exigem registro e concessão explícita, desligada por padrão. Leia META-ADS.md e META-ADS-READER.md. Nenhuma escrita em anúncios, alteração do LinkedIn ou ingestão comercial implícita. Pedido21 distingue coleta parcial de falha em COLLECTION-DIAGNOSTICS.md.

## Pedido 22 — tokens sem prefixo fixo

Na 0.15.0, save-connection, rotate-token e switch-identity retornam avisos estruturados em `avisos` (campo, codigo, motivo), tanto em sucesso quanto em erro. Token curto, aparência de App Secret, espaços internos e padrões incomuns de App ID/App Secret geram avisos, não recusa local. Espaços ASCII externos são aparados com aviso. Só vazio indispensável, mais de 16384 bytes e caracteres de controle impedem a conferência local. Campo de segredo vazio preserva o valor salvo; limpeza é explícita. A Meta confere app/identidade/escopos/ativos antes de gravar. CAS, geração monotônica, confirmação de troca e preservação após recusa permanecem.
