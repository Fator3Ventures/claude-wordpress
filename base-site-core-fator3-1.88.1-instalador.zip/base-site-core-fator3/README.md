# Fator3 Site Core 1.88.1

Versão 1.88.1. Catálogo comercial de aparelhos e projeção do perfil nos avisos de Slack. Consulte docs/RELEASE-1.88.1.md.

Instalação nova ou atualização da 1.87.3. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.41.0.

Índice de operação em docs/DOCUMENTACAO.md.
