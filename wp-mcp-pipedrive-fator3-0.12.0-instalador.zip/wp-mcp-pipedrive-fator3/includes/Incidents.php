<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Public, read-only Core contract. Never observes, publishes, retries or reconciles an incident. */
final class Incidents {
    private const ABILITY='f3base/incidentes-tecnicos-ler';
    private static function invalid(): never {throw new Fault('incidentes_contrato_invalido','A central retornou um diagnóstico incompatível. Confira a versão do Site Core.');}
    private static function hash(mixed $v):bool {return is_string($v)&&preg_match('/^[a-f0-9]{64}$/D',$v)===1;}
    public static function read(array $input=[]):array {
        Support::admin();
        $ability=function_exists('wp_has_ability')&&wp_has_ability(self::ABILITY)?wp_get_ability(self::ABILITY):null;
        if(!$ability)throw new Fault('incidentes_indisponiveis','A leitura de avisos técnicos exige o contrato público do Site Core.');
        $meta=$ability->get_meta();
        if(($meta['annotations']['readonly']??false)!==true)self::invalid();
        // WP_Ability::execute applies the target's own permission callback as well.
        try{$r=$ability->execute($input);}catch(\Throwable){throw new Fault('incidentes_leitura_falhou','Não foi possível ler a central. O estado dos incidentes não foi alterado.');}
        if(is_wp_error($r)||!is_array($r)||($r['ok']??false)!==true||($r['success']??true)!==true)throw new Fault('incidentes_leitura_falhou','A central não confirmou a leitura. Nenhuma recuperação foi presumida.');
        if(!isset($r['itens'])||!is_array($r['itens'])||!array_is_list($r['itens'])||count($r['itens'])>50||!is_bool($r['destino_configurado']??null)||!array_key_exists('proximo',$r))self::invalid();
        $next=$r['proximo'];$after=$input['apos']??'';
        if($next!==null&&(!self::hash($next)||strcmp($next,$after)<=0))self::invalid();
        $items=[];$seen=[];
        foreach($r['itens'] as $row){
            if(!is_array($row)||!is_string($row['pacote']??null))self::invalid();
            if($row['pacote']!=='pipedrive')continue;
            foreach(['id','recurso_ref'] as $key)if(!self::hash($row[$key]??null))self::invalid();
            if(isset($seen[$row['id']])||strcmp($row['id'],$after)<=0||($next!==null&&strcmp($row['id'],$next)>0))self::invalid();
            $seen[$row['id']]=true;
            if(!is_string($row['codigo']??null)||!preg_match('/^[a-z][a-z0-9_]{0,79}$/D',$row['codigo'])
                ||!in_array($row['estado']??null,['aberto','recuperado'],true)
                ||!is_int($row['entregas_pendentes']??null)||$row['entregas_pendentes']<0
                ||!array_key_exists('proxima_entrega',$row)||!in_array($row['proxima_entrega']??null,[null,'pendente','reservado'],true)
                ||!is_bool($row['acao_humana']??null))self::invalid();
            $item=array_intersect_key($row,array_flip(['id','codigo','recurso_ref','estado','acao_humana','entregas_pendentes','proxima_entrega']));
            foreach(['desde','alterado_em'] as $key){if(!is_int($row[$key]??null)||$row[$key]<1)self::invalid();$item[$key]=$row[$key];}
            $item['entrega_incerta']=$item['proxima_entrega']==='reservado';
            $item['reconciliacao']=$item['entrega_incerta']?'f3base/incidente-entrega-reconciliar':null;
            // The reservation is an opaque operation reference, needed for explicit reconciliation.
            if($item['entrega_incerta']){
                if(!is_string($row['reserva']??null)||!preg_match('/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/Di',$row['reserva']))self::invalid();
                $item['reserva']=$row['reserva'];
            }
            $items[]=$item;
        }
        return ['provider'=>SLUG,'version'=>VERSION,'origem'=>self::ABILITY,'itens'=>$items,'quantidade_nesta_pagina'=>count($items),'proximo_apos'=>$next,
            'fim'=>$next===null,'destino_configurado'=>$r['destino_configurado'],'chamada_externa'=>false];
    }
    /** Bounded local aggregation. A partial page is never represented as a global zero. */
    public static function summary():array {
        $n=['abertos'=>0,'recuperados'=>0,'entregas_pendentes'=>0,'entregas_incertas'=>0];$after=null;
        for($page=1;$page<=20;++$page){
            $r=self::read($after===null?[]:['apos'=>$after]);
            foreach($r['itens'] as $item){++$n[$item['estado']==='aberto'?'abertos':'recuperados'];$n['entregas_pendentes']+=$item['entregas_pendentes'];$n['entregas_incertas']+=(int)$item['entrega_incerta'];}
            $after=$r['proximo_apos'];if($after===null)break;
        }
        return $n+['completo'=>$after===null,'proximo_apos'=>$after,'destino_configurado'=>$r['destino_configurado']];
    }
    public static function panel():void {
        echo '<section class="f3pd-panel" id="f3pd-incidentes"><h2>Avisos técnicos da integração</h2><p>Consulte os incidentes que o Site Core já registrou para o Pipedrive. Uma entrega pendente ou incerta exige conferir o transporte; este resumo não envia avisos nem consulta o CRM.</p>';
        try{
            $s=self::summary();
            echo Admin::chip(!$s['completo']?'atencao':($s['abertos']?'erro':'info'),!$s['completo']?'Consulta parcial':($s['abertos']?'Há incidentes abertos':'Nenhum incidente aberto registrado'));
            echo '<dl class="f3pd-facts">';
            foreach(['abertos'=>'Abertos','recuperados'=>'Recuperados','entregas_pendentes'=>'Avisos na fila','entregas_incertas'=>'Entregas incertas'] as $key=>$title)echo '<div><dt>'.esc_html($title).($s['completo']?'':' (parcial)').'</dt><dd>'.esc_html((string)$s[$key]).'</dd></div>';
            echo '</dl><p>'.esc_html($s['destino_configurado']?'O destino técnico está configurado no Core. Isso não comprova recebimento na caixa postal.':'Configure o e-mail de avisos técnicos no Site Core. Os avisos continuam na fila enquanto não houver destino.').'</p>';
            if(!$s['completo'])echo '<p>Foram examinadas 20 páginas da central. Continue por <code>pipedrive/incidentes-ler</code> com o cursor <code>'.esc_html($s['proximo_apos']).'</code>; os números acima não são o total do histórico.</p>';
            echo '<p>A ausência de incidente registrado não confirma a autorização da conta. Confira a conexão na Visão geral.</p>';
        }catch(Fault $e){echo Admin::chip('atencao','Diagnóstico indisponível').'<p>'.esc_html($e->getMessage()).'</p>';}
        echo '<div class="f3pd-actions"><a class="button button-primary" href="'.esc_url(Admin::url('ajuda',['documento'=>'operacao'])).'">Consultar diagnóstico e recuperação</a><a class="button" href="'.esc_url(admin_url('admin.php?page=base-site-core-fator3')).'">Abrir Site Core</a></div></section>';
    }
}
