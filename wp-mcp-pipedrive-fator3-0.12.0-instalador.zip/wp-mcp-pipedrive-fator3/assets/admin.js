(() => {
  'use strict';
  const root=document.querySelector('.f3pd');if(!root)return;
  const editor=root.querySelector('.f3pd-editor');
  let dirty=false;
  const count = el => { if(el.tagName==='TEXTAREA' && el.maxLength===4000) el.nextElementSibling.textContent=Array.from(el.value).length+' / 4.000 caracteres'; };
  if(editor){
    editor.querySelectorAll('.f3pd-row textarea').forEach(count);
    editor.addEventListener('input',e=>{dirty=true;count(e.target);const box=e.target.closest('section');if(box?.id){const nav=editor.querySelector('[href="#'+box.id+'"]');if(nav && !nav.classList.contains('is-changed')){nav.classList.add('is-changed');nav.append(' · alterado');}}});
    editor.addEventListener('submit',()=>dirty=false);
    window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
    const fallback=editor.querySelector('.f3pd-add-server');if(fallback)fallback.hidden=true;
    editor.querySelectorAll('[data-rows]').forEach(group=>{
      const add=group.querySelector('.f3pd-add');add.hidden=false;
      add.addEventListener('click',()=>{
        const n=group.querySelectorAll('.f3pd-row').length;if(n>=50){add.disabled=true;return;}
        const row=group.querySelector('template').content.firstElementChild.cloneNode(true);
        row.querySelector('legend span').textContent=n+1;
        for(const el of row.querySelectorAll('[name],[id],[for]'))for(const k of ['name','id','for'])if(el.hasAttribute(k))el.setAttribute(k,el.getAttribute(k).replace('[999]','['+n+']').replace('-999-','-'+n+'-'));
        group.insertBefore(row,add);row.querySelectorAll('textarea').forEach(count);row.querySelector('input')?.focus();
      });
    });
  }
  root.querySelectorAll('[data-expira]').forEach(el=>{
    const tick=()=>{const left=Math.max(0,Number(el.dataset.expira)-Math.floor(Date.now()/1000));el.textContent=left?'('+Math.floor(left/60)+' min '+String(left%60).padStart(2,'0')+' s restantes)':'(expirada)';return left;};
    if(tick()){const timer=setInterval(()=>{if(!tick())clearInterval(timer);},1000);}
  });
  root.querySelectorAll('.f3pd-copy').forEach(btn=>{if(navigator.clipboard){btn.hidden=false;btn.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(btn.previousElementSibling.textContent);btn.textContent='Frase copiada';}catch{btn.textContent='Selecione e copie a frase acima';}});}});
})();

// Progressive enhancement for fully rendered local directories and reference tables.
(() => {
  const normalize = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR');
  document.querySelectorAll('.f3pd .f3pd-help-nav, .f3pd .f3pd-table').forEach(block => {
    const directory=block.classList.contains('f3pd-help-nav');
    const rows=[...block.querySelectorAll(directory?'li':'tbody > tr')];
    if(!rows.length || block.closest('#f3pd-recuperacao'))return;
    const controls=document.createElement('div');controls.className='f3pd-local-controls';
    const label=document.createElement('label');label.textContent=directory?'Buscar documento':'Buscar na tabela';
    const field=document.createElement('input');field.type='search';label.append(field);controls.append(label);
    const pager=document.createElement('div');pager.className='f3pd-pager';const count=document.createElement('strong');count.setAttribute('aria-live','polite');
    function button(title,delta){const b=document.createElement('button');b.type='button';b.className='button';b.textContent=title;b.addEventListener('click',()=>{page+=delta;render()});return b;}
    const prev=button('Anterior',-1), next=button('Próxima',1);pager.append(count,prev,next);controls.append(pager);block.before(controls);
    let page=0;const size=directory?12:20;
    function render(){const term=normalize(field.value.trim());const matches=rows.filter(row=>normalize(row.textContent).includes(term));const visible=new Set(matches.slice(page*size,(page+1)*size));rows.forEach(row=>{row.hidden=!visible.has(row)});
      if(directory)[...block.children].forEach(group=>{group.hidden=!group.querySelector('li:not([hidden])')});
      count.textContent=(matches.length?page*size+1:0)+'–'+Math.min((page+1)*size,matches.length)+' de '+matches.length;prev.disabled=page===0;next.disabled=(page+1)*size>=matches.length;}
    field.addEventListener('input',()=>{page=0;render()});render();
  });
})();
