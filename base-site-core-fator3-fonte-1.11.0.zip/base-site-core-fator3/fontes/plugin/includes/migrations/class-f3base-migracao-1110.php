<?php
/** EXCEPTIONAL adapter: loaded only by 1.11.0; remove in the following release.
 * Permanent repositories, rendering and privacy never depend on this class.
 * A completed marker survives deactivate/reactivate, reinstall and uninstall.
 */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Migracao_1110 {
	const VERSAO                     = '1.11.0';
	const OPTION                     = 'f3base_migracao_1110';
	private static array $capturados = array();
	public static function disponivel(): bool {
		return F3BASE_PLUGIN_VERSAO === self::VERSAO && empty( F3Base_Options::ler( self::OPTION )['concluida_em'] ); }
	public static function iniciar(): void {
		if ( F3BASE_PLUGIN_VERSAO !== self::VERSAO ) {
			return; }
		if ( ! did_action( 'init' ) ) {
			add_action( 'init', array( __CLASS__, 'iniciar' ), 7 );
			return; }
		add_action( 'wp_abilities_api_init', array( __CLASS__, 'registrar' ) );
		add_action(
			'admin_menu',
			static function (): void {
				add_submenu_page( 'f3base-leads', 'Migração única 1.11.0', 'Migração 1.11.0', 'manage_options', 'f3base-migracao', array( __CLASS__, 'tela' ) );
			}
		);
		if ( ! self::disponivel() ) {
			return; }
		add_action( 'wpcf7_after_flamingo', array( __CLASS__, 'apos_flamingo' ), 20 );
		add_action( 'wpcf7_submit', array( __CLASS__, 'ponte' ), 20, 2 );
	}
	public static function registrar(): void {
		F3Base_Release_1103::ability(
			'leads-migracao-1110',
			'Migração excepcional exclusiva de 1.11.0; conclusão irrepetível por site',
			array( __CLASS__, 'executar' ),
			array(
				'acao'                       => array(
					'type' => 'string',
					'enum' => array( 'consultar', 'simular', 'aplicar', 'verificar', 'concluir', 'resolver_ponte' ),
				),
				'revisao_esperada'           => array(
					'type'    => 'string',
					'pattern' => '^[a-f0-9]{64}$',
				),
				'reiniciar_varredura'        => array( 'type' => 'boolean' ),
				'evidencia_resolucao'        => array(
					'type'      => 'string',
					'minLength' => 12,
					'maxLength' => 500,
				),
				'aceite_operacao_sem_legado' => array( 'type' => 'boolean' ),
				'formularios_conferidos'     => array( 'type' => 'boolean' ),
				'rollback_conferido'         => array( 'type' => 'boolean' ),
			),
			array(),
			false
		);
		F3Base_Release_1103::ability(
			'formularios-cf7-planejar',
			'Ler definição CF7 e produzir proposta inativa para revisão',
			array( __CLASS__, 'planejar_formulario' ),
			array(
				'id' => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
			),
			array( 'id' )
		);
		F3Base_Release_1103::ability(
			'formularios-migrar-referencia',
			'Simular ou substituir shortcode CF7 com backup e revisão do conteúdo',
			array( __CLASS__, 'referencia' ),
			array(
				'post_id'          => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'cf7_id'           => array( 'type' => 'string' ),
				'formulario'       => array( 'type' => 'string' ),
				'revisao_esperada' => array( 'type' => 'string' ),
				'simular'          => array(
					'type'    => 'boolean',
					'default' => true,
				),
			),
			array( 'post_id', 'cf7_id', 'formulario' ),
			false
		);
	}
	private static function tipos(): array {
		return array( 'flamingo_inbound', 'flamingo_contact', F3Base_Modulo_Endpoint_Leads::CPT ); }
	public static function inventario(): array {
		global $wpdb;
		$tipos     = self::tipos();
		$p         = implode( ',', array_fill( 0, count( $tipos ), '%s' ) );
		$contagens = $wpdb->get_results( $wpdb->prepare( "SELECT post_type,post_status,COUNT(*) total FROM {$wpdb->posts} WHERE post_type IN ($p) GROUP BY post_type,post_status", $tipos ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Identifiers and SQL fragments are internally enumerated; all request values use prepared placeholders. Placeholder list is generated from the fixed internal source types and passed with matching values.
		$refs      = $wpdb->get_results( $wpdb->prepare( "SELECT ID,post_type,post_status,post_title FROM {$wpdb->posts} WHERE post_type<>%s AND post_type<>%s AND (post_content LIKE %s OR post_content LIKE %s) LIMIT 501", 'revision', 'wpcf7_contact_form', '%[contact-form-7%', '%wp:contact-form-7/%' ), ARRAY_A );
		$forms     = $wpdb->get_results( $wpdb->prepare( "SELECT ID,post_title FROM {$wpdb->posts} WHERE post_type=%s", 'wpcf7_contact_form' ), ARRAY_A );
		$themes    = array();
		foreach ( array_unique( array( get_stylesheet_directory(), get_template_directory() ) ) as $dir ) {
			if ( ! is_dir( $dir ) ) {
				continue;
			} $n = 0;
			foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) ) as $f ) {
				if ( ++$n > 3000 ) {
					$themes[] = array(
						'arquivo' => 'varredura',
						'codigo'  => 'limite_atingido',
					);
					break; }
				if ( $f->isLink() || ! $f->isFile() || ! in_array( strtolower( $f->getExtension() ), array( 'php', 'js', 'html', 'json' ), true ) || $f->getSize() > 2097152 ) {
					continue; }
				$txt = file_get_contents( $f->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading a bounded local package/theme file; no remote URL or visitor path is accepted.
				if ( preg_match( '/contact-form-7|wpcf7|Flamingo_/i', $txt ) ) {
					$themes[] = array(
						'arquivo' => basename( $dir ) . '/' . substr( $f->getPathname(), strlen( $dir ) + 1 ),
						'sha256'  => hash( 'sha256', $txt ),
					); }
			}
		}
		$widgets = array();
		foreach ( array( 'widget_text', 'widget_custom_html', 'widget_block' ) as $n ) {
			if ( preg_match( '/contact-form-7|wpcf7/i', wp_json_encode( get_option( $n, array() ) ) ) ) {
				$widgets[] = $n; }
		}
		return array(
			'fontes'         => $contagens,
			'formularios'    => $forms,
			'referencias'    => $refs,
			'temas'          => $themes,
			'widgets'        => $widgets,
			'truncado'       => count( $refs ) > 500,
			'plugins_ativos' => array_values( array_filter( (array) get_option( 'active_plugins', array() ), static fn( $s )=>str_starts_with( $s, 'contact-form-7/' ) || str_starts_with( $s, 'flamingo/' ) ) ),
		);
	}
	public static function snapshot( int $id ): ?array {
		$p = get_post( $id );
		if ( ! $p || ! in_array( $p->post_type, self::tipos(), true ) ) {
			return null; }
		$meta = get_post_meta( $id );
		foreach ( $meta as &$vs ) {
			$vs = array_map( 'maybe_unserialize', $vs );
		} unset( $vs );
		global $wpdb;
		$terms = $wpdb->get_results( $wpdb->prepare( "SELECT t.term_id,t.name,t.slug,tt.taxonomy FROM {$wpdb->term_relationships} tr JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE tr.object_id=%d ORDER BY tt.taxonomy,t.term_id", $id ), ARRAY_A );
		return array(
			'post'   => array(
				'ID'            => $p->ID,
				'post_type'     => $p->post_type,
				'post_status'   => $p->post_status,
				'post_date'     => $p->post_date,
				'post_date_gmt' => $p->post_date_gmt,
				'post_modified' => $p->post_modified,
				'post_title'    => $p->post_title,
				'post_content'  => $p->post_content,
				'post_author'   => $p->post_author,
			),
			'meta'   => $meta,
			'termos' => $terms,
		);
	}
	private static function chave( array $s ): string {
		return 'wp:' . $s['post']['post_type'] . ':' . $s['post']['ID']; }
	private static function dados( array $s ): array {
		$m      = $s['meta'];
		$v      = static fn( $k, $reserva_padrao = '' )=>$m[ $k ][0] ?? $reserva_padrao;
		$fields = (array) $v( '_fields', array() );
		foreach ( $m as $k => $values ) {
			if ( str_starts_with( $k, '_field_' ) ) {
				$fields[ substr( $k, 7 ) ] = $values[0]; }
		}
		if ( $s['post']['post_type'] === F3Base_Modulo_Endpoint_Leads::CPT ) { // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Comparison of runtime expressions; neither side is an assignable literal.
			$fields = array( 'registro_original' => $s['post']['post_content'] ); }
		$date = $s['post']['post_date_gmt'];
		if ( '0000-00-00 00:00:00' === $date ) {
			$date = get_gmt_from_date( $s['post']['post_date'] ); }
		return array(
			'campos'               => $fields,
			'legado'               => $s,
			'email'                => $v( '_from_email', $v( '_f3base_email' ) ),
			'nome'                 => $v( '_from_name', $v( '_f3base_nome' ) ),
			'metodo'               => 'legado_desconhecido',
			'metodo_justificativa' => 'Origem preservada; nenhum regime inferido sem evidência.',
			'captura'              => ( 'spam' === $s['post']['post_status'] ) ? 'suspeito' : 'aceito',
			'atendimento'          => ( 'spam' === $s['post']['post_status'] ) ? 'spam' : 'novo',
			'lixeira'              => 'trash' === $s['post']['post_status'],
			'criado_em'            => $date,
			'pagina'               => (string) ( $v( '_meta', array() )['url'] ?? $v( '_f3base_pagina' ) ),
			'correlacao'           => null,
			'notificar'            => false,
		);
	}
	public static function importar( int $id, bool $aplicar = true ): array {
		if ( ! self::disponivel() ) {
			return array(
				'ok'     => false,
				'codigo' => 'migracao_encerrada_ou_versao_incorreta',
			); }
		$s = self::snapshot( $id );
		if ( ! $s ) {
			return array(
				'ok'     => false,
				'codigo' => 'origem_ausente',
			); }
		$key  = self::chave( $s );
		$hash = F3Base_Leads_Repositorio::hash( $s );
		global $wpdb;
		if ( 'flamingo_contact' === $s['post']['post_type'] ) {
			$t = F3Base_Leads_Repositorio::tabela( 'contatos_legados' );
			$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE origem_chave=%s', $t, $key ), ARRAY_A );
			if ( $r && $r['eliminado'] ) {
				return array(
					'ok'     => true,
					'codigo' => 'eliminado_preservado',
				); }
			if ( $r && $r['origem_hash'] === $hash ) {
				return array(
					'ok'     => true,
					'codigo' => 'conferido',
				); }
			if ( ! $aplicar ) {
				return array(
					'ok'     => true,
					'codigo' => $r ? 'atualizar_contato' : 'importar_contato',
				); }
			$data = array(
				'origem_chave' => $key,
				'email'        => (string) ( $s['meta']['_email'][0] ?? '' ),
				'dados'        => wp_json_encode( $s ),
				'origem_hash'  => $hash,
			);
			$ok   = $r ? $wpdb->update(
				$t,
				$data,
				array(
					'id'          => $r['id'],
					'origem_hash' => $r['origem_hash'],
				)
			) : $wpdb->insert( $t, $data );
			return array(
				'ok'     => false !== $ok,
				'codigo' => 'contato_importado',
			);
		}
		$r = F3Base_Leads_Repositorio::por_origem( $key );
		if ( $r && 'eliminado' === $r['captura'] ) {
			return array(
				'ok'     => true,
				'codigo' => 'eliminado_preservado',
			); }
		if ( $r && hash_equals( $hash, $r['origem_hash'] ) ) {
			return array(
				'ok'        => true,
				'codigo'    => 'conferido',
				'record_id' => $r['record_id'],
			); }
		if ( $r && ( ! hash_equals( $r['importado_hash'], F3Base_Leads_Repositorio::hash( $r['dados'] ) ) || (int) $r['revisao'] > 1 ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'conflito_origem_destino',
				'id'     => $id,
			); }
		if ( ! $aplicar ) {
			return array(
				'ok'     => true,
				'codigo' => $r ? 'atualizar_legado' : 'importar_legado',
			); }
		$d = self::dados( $s );
		if ( $r ) {
			// CAS on the imported checksum and destination revision; never overwrite a moderated record.
			$ok = $wpdb->update(
				F3Base_Leads_Repositorio::tabela(),
				array(
					'dados'          => wp_json_encode( $d ),
					'origem_hash'    => $hash,
					'importado_hash' => F3Base_Leads_Repositorio::hash( $d ),
					'email'          => $d['email'],
					'nome'           => $d['nome'],
					'lixeira'        => $d['lixeira'] ? 1 : 0,
					'captura'        => $d['captura'],
					'atendimento'    => $d['atendimento'],
				),
				array(
					'record_id'   => $r['record_id'],
					'origem_hash' => $r['origem_hash'],
					'revisao'     => $r['revisao'],
				)
			);
			return array(
				'ok'        => 1 === $ok,
				'codigo'    => 1 === $ok ? 'delta_importado' : 'conflito',
				'record_id' => $r['record_id'],
			);
		}
		return F3Base_Leads_Repositorio::guardar( $d, null, $key, $hash, true );
	}
	public static function executar( $e = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		$estado = F3Base_Options::ler( self::OPTION );
		$foto   = F3Base_Options::fotografia( self::OPTION );
		$acao   = $e['acao'] ?? 'consultar';
		// This gate precedes any legacy query and any import side effect.
		if ( F3BASE_PLUGIN_VERSAO !== self::VERSAO || ! empty( $estado['concluida_em'] ) ) {
			return array(
				'ok'      => true,
				'codigo'  => ! empty( $estado['concluida_em'] ) ? 'migracao_concluida_uma_vez' : 'fora_da_versao_de_migracao',
				'estado'  => $estado,
				'revisao' => $foto['revisao'],
			); }
		if ( 'consultar' === $acao || 'simular' === $acao ) {
			return array(
				'ok'         => true,
				'simulado'   => 'simular' === $acao,
				'estado'     => $estado,
				'revisao'    => $foto['revisao'],
				'inventario' => self::inventario(),
				'lote'       => 50,
				'efeitos'    => 'Importação sem avisos e sem conversões. Legado preservado.',
			); }
		if ( ! in_array( $acao, array( 'aplicar', 'verificar', 'concluir', 'resolver_ponte' ), true ) || ! hash_equals( $foto['revisao'], (string) ( $e['revisao_esperada'] ?? '' ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'acao_ou_revisao_invalida',
			); }
		if ( ! F3Base_Leads_Repositorio::instalar() ) {
			return array(
				'ok'     => false,
				'codigo' => 'destino_indisponivel',
			); }
		$lease   = bin2hex( random_bytes( 16 ) );
		$reserva = F3Base_Options::atualizar_estado(
			self::OPTION,
			static function ( $s ) use ( $lease ) {
				if ( ! empty( $s['concluida_em'] ) || ( $s['lease_ate'] ?? 0 ) > time() ) {
					return null;
				} $s['lease']   = $lease;
				$s['lease_ate'] = time() + 120;
				$s['release']   = self::VERSAO;
				return $s;
			}
		);
		if ( empty( $reserva['persisted'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'migracao_ocupada',
			); }
		$state  = $reserva['lido'];
		$result = array();
		try {
			global $wpdb;
			if ( 'resolver_ponte' === $acao ) {
				if ( ! is_string( $e['evidencia_resolucao'] ?? null ) || strlen( $e['evidencia_resolucao'] ) < 12 ) {
					$result = array(
						'ok'     => false,
						'codigo' => 'evidencia_obrigatoria',
					); } else {
					$state['ponte_resolvida'] = array(
						'em'        => time(),
						'operador'  => get_current_user_id(),
						'evidencia' => sanitize_text_field( $e['evidencia_resolucao'] ),
						'falha'     => $state['falha_ponte'] ?? '',
					);
					$state['falha_ponte']     = '';
					$state['verificada_em']   = 0;
					$result                   = array(
						'ok'     => true,
						'codigo' => 'resolucao_registrada_exige_reconciliacao',
					); }
			} elseif ( 'concluir' === $acao ) {
				$inv = self::inventario();
				if ( ! empty( $state['falha_ponte'] ) || $inv['plugins_ativos'] || $inv['referencias'] || $inv['widgets'] || $inv['temas'] || $inv['truncado'] || empty( $e['aceite_operacao_sem_legado'] ) || empty( $e['formularios_conferidos'] ) || empty( $e['rollback_conferido'] ) || empty( $state['verificada_em'] ) ) {
					$result = array(
						'ok'         => false,
						'codigo'     => 'cutover_nao_conferido',
						'inventario' => $inv,
					); } elseif ( ( $state['fingerprint_verificada'] ?? '' ) !== self::fingerprint() ) {
					$state['verificada_em'] = 0;
					$result                 = array(
						'ok'     => false,
						'codigo' => 'origem_mudou_reconciliar_novamente',
					); } else {
						$state['concluida_em']  = time();
						$state['concluida_por'] = get_current_user_id();
						$state['codigo']        = 'concluida_uma_vez';
						$result                 = array(
							'ok'     => true,
							'codigo' => 'migracao_concluida_uma_vez',
						); }
			} else {
				$verify = 'verificar' === $acao;
				$key    = $verify ? 'cursor_verificacao' : 'cursor';
				if ( ! empty( $e['reiniciar_varredura'] ) ) {
					$state[ $key ] = 0;
					if ( $verify ) {
						$state['falhas_verificacao'] = array();
						$state['fingerprint_inicio'] = self::fingerprint(); }
				}
				if ( $verify && empty( $state[ $key ] ) ) {
					$state['fingerprint_inicio'] = self::fingerprint();
					$state['falhas_verificacao'] = array(); }
				$args  = array_merge( self::tipos(), array( (int) ( $state[ $key ] ?? 0 ) ) );
				$marks = implode( ',', array_fill( 0, count( self::tipos() ), '%s' ) );
				$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type IN ($marks) AND ID>%d ORDER BY ID LIMIT 51", $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identifiers and SQL fragments are internally enumerated; all request values use prepared placeholders.
				$mais  = count( $ids ) > 50;
				$ids   = array_slice( $ids, 0, 50 );
				$itens = array();
				foreach ( $ids as $id ) {
					$r      = self::importar( (int) $id, ! $verify );
					$codigo = $r['codigo'] ?? ( ! empty( $r['ok'] ) ? 'importado' : 'falhou' );
					if ( $verify && ! in_array( $codigo, array( 'conferido', 'eliminado_preservado' ), true ) ) {
						$r['ok'] = false; }
					$itens[] = array(
						'id'     => (int) $id,
						'ok'     => ! empty( $r['ok'] ),
						'codigo' => $codigo,
					);
					if ( empty( $r['ok'] ) ) {
						if ( $verify ) {
							$state['falhas_verificacao'][] = (int) $id;
						} else {
							break; }
					}
					$state[ $key ] = (int) $id;
				}
				$falhas = array_filter( $itens, static fn( $i )=> ! $i['ok'] );
				if ( $verify && ! $mais && ! $falhas && empty( $state['falhas_verificacao'] ) && $state['fingerprint_inicio'] === self::fingerprint() ) { // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Comparison of runtime expressions; neither side is an assignable literal.
					$state['verificada_em']          = time();
					$state['fingerprint_verificada'] = $state['fingerprint_inicio']; } elseif ( $verify ) {
					$state['verificada_em'] = 0; } else {
						$state['verificada_em'] = 0; }
					$state['ultima_acao']     = $acao;
					$state['ultima_execucao'] = time();
					$result                   = array(
						'ok'         => ! $falhas,
						'itens'      => $itens,
						'mais'       => $mais,
						'cursor'     => $state[ $key ] ?? 0,
						'verificada' => ! empty( $state['verificada_em'] ),
					);
			}
		} catch ( Throwable $err ) {
			$result = array(
				'ok'     => false,
				'codigo' => 'lote_interrompido',
			); }
		$state['lease']     = '';
		$state['lease_ate'] = 0;
		$save               = F3Base_Options::atualizar_estado(
			self::OPTION,
			static function ( $atual ) use ( $lease, $state ) {
				if ( ( $atual['lease'] ?? '' ) !== $lease ) {
					return null;
				} if ( ( $atual['falha_ponte_em'] ?? 0 ) > ( $state['falha_ponte_em'] ?? 0 ) ) {
					$state['falha_ponte']    = $atual['falha_ponte'];
					$state['falha_ponte_em'] = $atual['falha_ponte_em'];
					$state['verificada_em']  = 0;
					unset( $state['concluida_em'] );
				} return $state;
			}
		);
		return $result + array(
			'checkpoint_persistido' => ! empty( $save['persisted'] ),
			'revisao'               => $save['revisao'] ?? '',
			'estado'                => $state,
		);
	}
	/** Covers post meta and term changes, not just the ID watermark. No PII leaves this digest. */
	private static function fingerprint(): string {
		global $wpdb;
		$marks = implode( ',', array_fill( 0, count( self::tipos() ), '%s' ) );
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type IN ($marks) ORDER BY ID", self::tipos() ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Identifiers and SQL fragments are internally enumerated; all request values use prepared placeholders. Placeholder list is generated from the fixed internal source types and passed with matching values.
		$ctx   = hash_init( 'sha256' );
		foreach ( $ids as $id ) {
			hash_update( $ctx, (string) $id . '|' . F3Base_Leads_Repositorio::hash( self::snapshot( (int) $id ) ?? array() ) ); }
		return hash_final( $ctx );
	}
	public static function apos_flamingo( array $r ): void {
		if ( ! self::disponivel() || empty( $r['flamingo_inbound_id'] ) ) {
			return; }
		$id   = (int) $r['flamingo_inbound_id'];
		$copy = self::importar( $id );
		if ( ! empty( $copy['record_id'] ) ) {
			self::$capturados[] = $copy['record_id']; }
		if ( empty( $copy['ok'] ) ) {
			self::falha_ponte( 'importacao_flamingo_falhou' ); }
	}
	private static function falha_ponte( string $codigo ): void {
		F3Base_Options::atualizar_estado(
			self::OPTION,
			static function ( $s ) use ( $codigo ) {
				$s['falha_ponte']    = $codigo;
				$s['falha_ponte_em'] = time();
				$s['verificada_em']  = 0;
				return $s;
			}
		); }
	public static function ponte( $form, array $r ): void {
		if ( ! self::disponivel() || ! in_array( $r['status'] ?? '', array( 'spam', 'mail_sent', 'mail_failed' ), true ) || ! class_exists( 'WPCF7_Submission' ) ) {
			return; }
		$sub = WPCF7_Submission::get_instance();
		if ( ! $sub || $sub->get_meta( 'do_not_store' ) ) {
			return; }
		if ( self::$capturados ) {
			foreach ( self::$capturados as $record ) {
				self::anexos_ponte( $record, $sub, $form );
			} self::$capturados = array();
			return; }
		$fields = (array) $sub->get_posted_data();
		foreach ( $fields as $name => $value ) {
			if ( $form->scan_form_tags(
				array(
					'name'    => $name,
					'feature' => 'do-not-store',
				)
			) ) {
				unset( $fields[ $name ] ); }
		}
		$d   = array(
			'formulario' => 'cf7-' . $form->id(),
			'metodo'     => 'formulario',
			'captura'    => 'spam' === ( $r['status'] ?? '' ) ? 'suspeito' : 'aceito',
			'campos'     => $fields,
			'legado'     => array(
				'cf7_resultado' => $r,
				'formulario_id' => $form->id(),
				'consent'       => $sub->collect_consent(),
			),
			'pagina'     => (string) $sub->get_meta( 'url' ),
			'email'      => (string) ( $fields['your-email'] ?? '' ),
			'nome'       => (string) ( $fields['your-name'] ?? '' ),
			'notificar'  => false,
		);
		$key = 'cf7:' . $form->id() . ':' . $sub->get_posted_data_hash();
		$out = F3Base_Leads_Repositorio::guardar( $d, hash( 'sha256', $key ), $key, F3Base_Leads_Repositorio::hash( $d ), true );
		if ( empty( $out['ok'] ) ) {
			self::falha_ponte( 'persistencia_ponte_falhou' );
		} else {
			self::anexos_ponte( $out['record_id'], $sub, $form ); }
	}
	private static function anexos_ponte( string $record, $sub, $form ): void {
		$uploads = (array) $sub->uploaded_files();
		if ( ! $uploads ) {
			return; }
		if ( ! function_exists( 'wpcf7_upload_tmp_dir' ) ) {
			self::falha_ponte( 'temporario_cf7_nao_identificado' );
			return; }
		$lead = F3Base_Leads_Repositorio::obter( $record );
		if ( ! $lead ) {
			self::falha_ponte( 'registro_ponte_ausente' );
			return; }
		$anexos = $lead['anexos'];
		$novos  = array();
		foreach ( $uploads as $campo => $paths ) {
			if ( $form->scan_form_tags(
				array(
					'name'    => $campo,
					'feature' => 'do-not-store',
				)
			) ) {
				continue; }
			foreach ( (array) $paths as $path ) {
				if ( ! is_string( $path ) ) {
					self::falha_ponte( 'formato_anexo_cf7' );
					continue; }
				$hash = is_file( $path ) ? hash_file( 'sha256', $path ) : '';
				if ( array_filter( $anexos, static fn( $a )=>( $a['campo'] ?? '' ) === $campo && $a['sha256'] === $hash ) ) {
					continue; }
				$r = F3Base_Arquivos_Privados::copiar_legado( $path, wpcf7_upload_tmp_dir() );
				if ( ! $r['ok'] ) {
					self::falha_ponte( $r['codigo'] );
					continue; }
				$a          = $r['arquivo'];
				$a['campo'] = $campo;
				$novos[]    = $a;
				$anexos[]   = $a;
			}
		}
		if ( ! $novos ) {
			return; }
		global $wpdb;
		if ( ! F3Base_Arquivos_Privados::vincular( $novos, $record ) || false === $wpdb->update(
			F3Base_Leads_Repositorio::tabela(),
			array( 'anexos' => wp_json_encode( $anexos ) ),
			array(
				'record_id' => $record,
				'revisao'   => $lead['revisao'],
			)
		) ) {
			foreach ( $novos as $a ) {
				F3Base_Arquivos_Privados::eliminar( $a['id'] );
			} self::falha_ponte( 'vinculo_anexo_cf7_falhou' );
		}
	}
	public static function planejar_formulario( $e ): array {
		if ( ! current_user_can( 'manage_options' ) || ! self::disponivel() ) {
			return array(
				'ok'     => false,
				'codigo' => 'indisponivel',
			); }
		$id = (int) ( $e['id'] ?? 0 );
		$p  = get_post( $id );
		if ( ! $p || 'wpcf7_contact_form' !== $p->post_type ) {
			return array(
				'ok'     => false,
				'codigo' => 'formulario_ausente',
			); }
		$raw    = (string) get_post_meta( $id, '_form', true );
		$mail   = (array) get_post_meta( $id, '_mail', true );
		$mail2  = (array) get_post_meta( $id, '_mail_2', true );
		$msgs   = (array) get_post_meta( $id, '_messages', true );
		$f      = array(
			'id'          => 'cf7-' . $id,
			'titulo'      => $p->post_title,
			'regime'      => 'registro',
			'ligado'      => false,
			'confirmacao' => ! empty( $mail2['active'] ) ? wp_strip_all_tags( $mail2['body'] ?? '' ) : ( $msgs['mail_sent_ok'] ?? 'Obrigado. Contato registrado.' ),
			'campos'      => array(),
		);
		$avisos = array( 'Revisar HTML, rótulos, condicionais, regras de tema, destinatários e confirmação antes de ativar.' );
		if ( class_exists( 'WPCF7_ContactForm' ) ) {
			$cf = WPCF7_ContactForm::get_instance( $id );
			foreach ( $cf->scan_form_tags() as $tag ) {
				$tipo = $tag->basetype;
				if ( 'submit' === $tipo ) {
					$f['botao'] = $tag->values[0] ?? 'Enviar';
					continue; }
				if ( ! in_array( $tipo, F3Base_Formularios::TIPOS, true ) ) {
					$avisos[] = 'Campo exige conversão manual: ' . $tipo . ' ' . $tag->name;
					continue; }
				$c = array(
					'nome'        => $tag->name,
					'tipo'        => $tipo,
					'rotulo'      => $tag->name,
					'obrigatorio' => $tag->is_required(),
				);
				if ( in_array( $tipo, array( 'select', 'radio', 'checkbox' ), true ) ) {
					$c['opcoes'] = $tag->values; }
				if ( 'email' === $tipo ) {
					$c['papel'] = 'email'; }
				if ( 'your-name' === $tag->name ) {
					$c['papel'] = 'nome'; }
				$f['campos'][] = $c;
			}
		} else {
			$avisos[] = 'Ative CF7 para interpretar as tags antes de removê-lo, ou declare a definição no editor Core.'; }
		$to    = array_filter( array_map( 'trim', explode( ',', $mail['recipient'] ?? '' ) ) );
		$valid = F3Base_Leads_Notificacoes::destinatarios( $to );
		if ( count( $valid ) === count( $to ) ) {
			$f['destinatarios'] = $valid;
		} else {
			$avisos[] = 'Destinatários dinâmicos exigem configuração explícita.'; }
		return array(
			'ok'       => true,
			'proposta' => $f,
			'avisos'   => $avisos,
			'origem'   => array(
				'id'                  => $id,
				'form'                => $raw,
				'mail'                => $mail,
				'mail_2'              => $mail2,
				'messages'            => $msgs,
				'additional_settings' => get_post_meta( $id, '_additional_settings', true ),
			),
			'revisao'  => hash( 'sha256', $p->post_content . $raw . wp_json_encode( array( $mail, $mail2, $msgs ) ) ),
		);
	}
	public static function referencia( $e ): array {
		if ( ! current_user_can( 'manage_options' ) || ! self::disponivel() ) {
			return array(
				'ok'     => false,
				'codigo' => 'indisponivel',
			); }
		$p    = get_post( (int) ( $e['post_id'] ?? 0 ) );
		$form = F3Base_Formularios::obter( (string) ( $e['formulario'] ?? '' ) );
		if ( ! $p || ! $form ) {
			return array(
				'ok'     => false,
				'codigo' => 'origem_ou_destino_ausente',
			); }
		$hash = hash( 'sha256', $p->post_content );
		$sim  = $e['simular'] ?? true;
		if ( ( ! $sim || isset( $e['revisao_esperada'] ) ) && ! hash_equals( $hash, (string) ( $e['revisao_esperada'] ?? '' ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'conteudo_mudou',
			); }
		$novo = preg_replace_callback(
			'/' . get_shortcode_regex( array( 'contact-form-7' ) ) . '/s',
			static function ( $m ) use ( $e, $form ) {
				$a = shortcode_parse_atts( $m[3] );
				return '' === $m[1] && '' === $m[6] && (string) ( $a['id'] ?? '' ) === (string) $e['cf7_id'] ? '[f3base_formulario id="' . $form['id'] . '"]' : $m[0];
			},
			$p->post_content
		);
		if ( $sim ) {
			return array(
				'ok'       => true,
				'simulado' => true,
				'antes'    => $p->post_content,
				'depois'   => $novo,
				'revisao'  => $hash,
			); }
		if ( $novo === $p->post_content ) {
			return array(
				'ok'      => true,
				'changed' => false,
			); }
		add_post_meta(
			$p->ID,
			'_f3base_backup_cf7_1110',
			array(
				'em'         => time(),
				'sha256'     => $hash,
				'conteudo'   => $p->post_content,
				'formulario' => $form['id'],
			),
			false
		);
		$id = wp_update_post(
			array(
				'ID'           => $p->ID,
				'post_content' => $novo,
			),
			true
		);
		return array(
			'ok'          => ! is_wp_error( $id ) && get_post_field( 'post_content', $p->ID ) === $novo,
			'changed'     => ! is_wp_error( $id ),
			'backup_meta' => '_f3base_backup_cf7_1110',
		);
	}
	public static function tela(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		} echo '<div class="wrap"><h1>Migração única — somente 1.11.0</h1><p>Importe em lotes, migre as referências de formulário, desative CF7/Flamingo e confira a operação e a reversão. Concluir encerra definitivamente o importador neste site.</p>';
		if ( isset( $_POST['acao_migracao'] ) ) {
			check_admin_referer( 'f3base-migracao' );
			$r = self::executar(
				array(
					'acao'                       => sanitize_key( $_POST['acao_migracao'] ),
					'revisao_esperada'           => sanitize_text_field( $_POST['revisao'] ?? '' ),
					'reiniciar_varredura'        => isset( $_POST['reiniciar'] ),
					'aceite_operacao_sem_legado' => isset( $_POST['sem_legado'] ),
					'formularios_conferidos'     => isset( $_POST['formularios'] ),
					'rollback_conferido'         => isset( $_POST['rollback'] ),
				)
			);
			echo '<pre>' . esc_html( wp_json_encode( $r, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>';
		}
		$r = self::executar();
		echo '<pre>' . esc_html( wp_json_encode( $r, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre><form method="post">';
		wp_nonce_field( 'f3base-migracao' );
		echo '<input type="hidden" name="revisao" value="' . esc_attr( $r['revisao'] ) . '"><label><input type="checkbox" name="reiniciar"> Reconciliar desde o primeiro registro</label><p>';
		foreach ( array(
			'aplicar'   => 'Importar próximo lote',
			'verificar' => 'Verificar próximo lote',
			'concluir'  => 'Concluir uma única vez',
		) as $k => $v ) {
			echo '<button class="button" name="acao_migracao" value="' . esc_attr( $k ) . '">' . esc_html( $v ) . '</button> '; }
		echo '</p><label><input type="checkbox" name="sem_legado"> Operação provada sem os dois plugins</label> <label><input type="checkbox" name="formularios"> Formulários e avisos conferidos</label> <label><input type="checkbox" name="rollback"> Reversão de conteúdo e preservação dos novos contatos ensaiadas</label></form></div>';
	}
}
