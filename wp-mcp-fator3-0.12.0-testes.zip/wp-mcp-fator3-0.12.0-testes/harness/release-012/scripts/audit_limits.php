<?php
if(PHP_SAPI!=='cli')exit(2);
$dir=__DIR__.'/../audit-limit-fixture';define('F3_MCP_PRIVATE_DIR',$dir);
require __DIR__.'/../lab/wordpress/wp-load.php';if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);wp_set_current_user(1);
use Fator3\McpFiles\{StateStore,Audit};
$checks=[];function ca($n,$p){global$checks;$checks[]=['test'=>$n,'pass'=>(bool)$p];}
$bucket=StateStore::directory('audit');
try{
 for($i=0;$i<3;$i++){ $id='20260914120000-'.str_pad((string)$i,16,'0',STR_PAD_LEFT);StateStore::put('audit',$id,['id'=>$id,'time'=>gmdate('c'),'user'=>1,'ability'=>'fixture/test','target'=>'','success'=>true]); }
 $one=Audit::listing(['per_page'=>2]);$two=Audit::listing(['per_page'=>2,'before'=>$one['next_cursor']]);ca('audit chronological cursor preserved',count($one['entries'])===2&&$one['has_more']&&count($two['entries'])===1&&!$two['has_more']);
 foreach(glob($bucket.'/*.php')as$f)unlink($f);
 file_put_contents($bucket.'/large.php',str_repeat('x',65537));$r=Audit::listing([]);ca('oversized metadata identified',$r['error_code']==='audit_metadata_too_large');unlink($bucket.'/large.php');
 for($i=0;$i<257;$i++)file_put_contents($bucket.'/bytes-'.$i.'.php',str_repeat('x',65536));$r=Audit::listing([]);ca('total metadata byte limit identified',$r['error_code']==='audit_scan_limit');foreach(glob($bucket.'/*.php')as$f)unlink($f);
 for($i=0;$i<10001;$i++)touch($bucket.'/count-'.$i.'.php');$r=Audit::listing([]);ca('metadata file count limit identified',$r['error_code']==='audit_scan_limit');
}finally{foreach(glob($bucket.'/*.php')as$f)unlink($f);}
$r=['passed'=>count(array_filter($checks,fn($x)=>$x['pass'])),'total'=>count($checks),'checks'=>$checks];echo wp_json_encode($r,JSON_PRETTY_PRINT);exit($r['passed']===$r['total']?0:1);
