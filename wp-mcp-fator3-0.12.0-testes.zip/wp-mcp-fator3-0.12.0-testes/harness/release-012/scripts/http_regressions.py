from pathlib import Path
import subprocess,os,json,time,socket,base64,urllib.request,urllib.error,urllib.parse,shutil,re,hashlib,concurrent.futures,signal
root=Path.cwd();base=root/'release-012';wp=base/'lab/wordpress';php=[str(root/'rmdir/runtime/usr/bin/php8.3'),'-c',str(root/'delete-post/lab/php.ini')];origin='http://127.0.0.1:38012';env=os.environ.copy()|{'F3_TEST_ORIGIN':origin,'PHP_CLI_SERVER_WORKERS':'4'};checks=[]
# Credentials and MCP session really originate from the previous distribution.
shutil.copytree(root/'release-011/build/wp-mcp-fator3',wp/'wp-content/plugins/wp-mcp-fator3',dirs_exist_ok=True)
subprocess.run(php+[str(base/'scripts/http_setup.php')],env=env,check=True,capture_output=True)
auth=json.loads((base/'http-fixture.json').read_text())
shutil.copytree(base/'build/wp-mcp-fator3',wp/'wp-content/plugins/wp-mcp-fator3',dirs_exist_ok=True)
logs=(base/'results/http-server.log').open('w');server=subprocess.Popen(php+['-S','127.0.0.1:38012','-t',str(wp),str(base/'scripts/router.php')],env=env,stdout=logs,stderr=logs,start_new_session=True)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
basic='Basic '+base64.b64encode((auth['username']+':'+auth['password']).encode()).decode();cookie='; '.join(k+'='+v for k,v in auth['cookies'].items())
def req(path,data=None,headers=None,method=None):
 h=headers or {};url=path if path.startswith('http')else origin+path
 if isinstance(data,dict):data=urllib.parse.urlencode(data).encode();h={'Content-Type':'application/x-www-form-urlencoded'}|h
 r=urllib.request.Request(url,data=data,headers=h,method=method)
 try:
  with opener.open(r,timeout=35)as x:return x.status,dict(x.headers),x.read()
 except urllib.error.HTTPError as e:return e.code,dict(e.headers),e.read()
def jreq(*args,**kw):
 c,h,b=req(*args,**kw)
 try:j=json.loads(b)
 except:j={}
 return c,h,j
def rpc(path,method,params=None,session=None,authorization=basic,id=1):
 h={'Content-Type':'application/json','Accept':'application/json, text/event-stream'}
 if authorization:h['Authorization']=authorization
 if session:h|={'Mcp-Session-Id':session,'MCP-Protocol-Version':'2025-06-18'}
 d={'jsonrpc':'2.0','method':method,'params':params or {}}
 if id is not None:d['id']=id
 return jreq(path,json.dumps(d).encode(),h)
def check(n,v,detail=None):
 checks.append({'test':n,'pass':bool(v),**({}if v else {'detail':detail})});print(n,bool(v),flush=True)
def init(path,authorization=basic):
 c,h,b=rpc(path,'initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'f3-release-test','version':'1'}},authorization=authorization)
 return c,h.get('Mcp-Session-Id')or h.get('MCP-Session-Id'),b
new='/wp-json/mcp/wp-mcp-fator3';old='/wp-json/mcp/wp-mcp-ultimate'
try:
 deadline=time.monotonic()+8
 while time.monotonic()<deadline:
  try:s=socket.create_connection(('127.0.0.1',38012),timeout=.1);s.close();break
  except OSError:time.sleep(.03)
 check('credentials created on 0.11.0',auth['created_with']=='0.11.0')
 for path in [new,old,'/index.php?rest_route=/mcp/wp-mcp-fator3','/index.php?rest_route=/mcp/wp-mcp-ultimate']:
  c,s,b=init(path);check('Basic initialize '+path,c==200 and b.get('result',{}).get('serverInfo',{}).get('version')=='0.12.0',{'code':c,'body':b})
  c,h,b=rpc(path,'tools/list',session=s);check('three tools '+path,c==200 and len(b.get('result',{}).get('tools',[]))==3)
 c,h,b=rpc(old,'tools/list',session=auth['old_session']);check('pre-upgrade session preserved',c==200 and 'result'in b)
 c,h,b=rpc(new,'tools/list',session=auth['old_session']);check('session shared across aliases',c==200 and 'result'in b)
 for path in [new,old]:
  c,s,b=init(path,'Bearer '+auth['old_access_token']);check('pre-upgrade OAuth '+path,c==200 and 'result'in b)
  c,h,b=rpc(path,'tools/list',authorization=None);check('anonymous denied '+path,c==401)
  challenge=h.get('WWW-Authenticate','');match=re.search('resource_metadata="([^"]+)"',challenge);check('resource challenge '+path,bool(match),challenge)
  if match:
   c,h,b=jreq(match[1]);check('metadata resource '+path,c==200 and b.get('resource')==origin+path,b)
 c,h,b=jreq('/.well-known/oauth-protected-resource');check('legacy root metadata preserved',b.get('resource')==origin+old,b)
 for path in [new+'-evil',old+'/unrelated']:
  c,h,b=rpc(path,'tools/list',authorization='Bearer '+auth['old_access_token']);check('Bearer route confinement '+path,c in [401,403,404],c)
 c,h,b=jreq(new+'?rest_route=/wp/v2/users/me',headers={'Authorization':'Bearer '+auth['old_access_token']});check('GET route override does not authenticate WordPress user',c==401 and b.get('code')=='rest_not_logged_in',{'status':c,'body':b})
 # Refresh a pre-upgrade grant, then full authorization-code + PKCE exchange on new resource.
 c,h,b=jreq('/wp-mcp-oauth/token',{'grant_type':'refresh_token','client_id':auth['client_id'],'refresh_token':auth['old_refresh_token'],'resource':origin+new});check('legacy refresh on new resource',c==200 and 'access_token'in b)
 if 'access_token'in b:
  c,s,r=init(new,'Bearer '+b['access_token']);check('renewed token authenticates',c==200)
 verifier='A'*64;challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
 params={'client_id':auth['client_id'],'redirect_uri':'http://127.0.0.1:49151/callback','response_type':'code','scope':'mcp','state':'f3state','code_challenge':challenge,'code_challenge_method':'S256','resource':origin+new}
 c,h,html=req('/wp-mcp-oauth/authorize?'+urllib.parse.urlencode(params),headers={'Cookie':cookie});check('OAuth consent page',c==200 and b'name="resource"'in html,{'status':c,'bytes':len(html)})
 nonce=re.search(rb'name="_wpnonce" value="([^"]+)"',html)
 if nonce:
  c,h,b=req('/wp-mcp-oauth/authorize',params|{'_wpnonce':nonce[1].decode(),'wp_mcp_oauth_consent':'allow'},headers={'Cookie':cookie});q=urllib.parse.parse_qs(urllib.parse.urlparse(h.get('Location','')).query);code=q.get('code',[''])[0];check('OAuth consent grants code',c==302 and bool(code))
  if code:
   grant={'grant_type':'authorization_code','code':code,'client_id':auth['client_id'],'redirect_uri':params['redirect_uri'],'code_verifier':verifier,'resource':origin+new}
   c,h,b=jreq('/wp-mcp-oauth/token',grant);check('PKCE token exchange',c==200 and bool(b.get('access_token')))
   if b.get('access_token'):
    token=b['access_token'];refresh=b['refresh_token'];c,s,r=init(new,'Bearer '+token);check('new OAuth token works',c==200)
    c,h,b=jreq('/wp-mcp-oauth/token',grant);check('code cannot be reused',c==400 and b.get('error')=='invalid_grant')
    c,h,b=jreq('/wp-mcp-oauth/token',{'grant_type':'refresh_token','client_id':auth['client_id'],'refresh_token':refresh,'resource':'https://foreign.example/mcp'});check('foreign resource rejected',c==400 and b.get('error')=='invalid_target')
 c,h,html=req('/wp-admin/tools.php?page=wp-mcp-fator3&tab=connection',headers={'Cookie':cookie});check('authenticated admin page',c==200 and b'f3-mcp-admin'in html,c)
 match=re.search(rb'var f3McpAdmin = (\{.*?\});',html)
 if match:
  config=json.loads(match[1]);c,h,b=jreq('/wp-admin/admin-ajax.php',{'action':'wp_mcp_ultimate_test_connection','nonce':config['nonce'],'route':'/mcp/wp-mcp-fator3'},headers={'Cookie':cookie});check('real admin HTTP test',b.get('success')is True,b)
  def app_count():
   code="require 'release-012/lab/wordpress/wp-load.php'; echo count(WP_Application_Passwords::get_user_application_passwords(1));"
   return int(subprocess.run(php+['-r',code],env=env,check=True,capture_output=True).stdout)
  count_before=app_count()
  with concurrent.futures.ThreadPoolExecutor(2)as pool:
   simultaneous=list(pool.map(lambda route:jreq('/wp-admin/admin-ajax.php',{'action':'wp_mcp_ultimate_test_connection','nonce':config['nonce'],'route':route},headers={'Cookie':cookie})[2],['/mcp/wp-mcp-fator3','/mcp/wp-mcp-ultimate']))
  check('simultaneous HTTP tests both complete',all(r.get('success')is True for r in simultaneous),simultaneous)
  check('simultaneous tests clean only own credentials',app_count()==count_before)
 else:check('admin JavaScript config available',False)
 # Real concurrent writes through both endpoints use one lock/hash contract.
 target=wp/'wp-content/f3-http-012.txt';target.write_text('original');digest=hashlib.sha256(b'original').hexdigest();c,s,_=init(new)
 def mutate(path,content):
  return rpc(path,'tools/call',{'name':'wp-mcp-ultimate-execute-ability','arguments':{'ability_name':'files/write','parameters':{'path':str(target),'content':content,'expected_sha256':digest}}},session=s)[2]
 with concurrent.futures.ThreadPoolExecutor(2)as pool:out=list(pool.map(lambda x:mutate(*x),[(new,'first'),(old,'second')]))
 data=[r.get('result',{}).get('structuredContent',{}).get('data',{})for r in out];check('concurrent writes across aliases',sum(x.get('success')is True for x in data)==1 and sum(x.get('error_code')=='file_conflict'for x in data)==1,data)
 target.unlink(missing_ok=True)
 for path in [new,old]:
  c,h,body=req(path,headers={'Authorization':basic,'Accept':'text/event-stream'});check('GET keeps unsupported SSE contract '+path,c==405,c)
 c,delete_session,_=init(new)
 c,h,body=req(old,headers={'Authorization':basic,'Mcp-Session-Id':delete_session,'MCP-Protocol-Version':'2025-06-18'},method='DELETE');check('session DELETE accepted through legacy alias',c in [200,204],c)
 c,h,body=rpc(new,'tools/list',session=delete_session);check('deleted session unavailable through primary',body.get('error',{}).get('code')==-32602 and 'result'not in body,{'code':c,'body':body})
 if os.getenv('F3_RUN_BROWSER')=='1':
  r=subprocess.run(['node',str(base/'scripts/ui_test.cjs')],env=env,timeout=180,capture_output=True,text=True);print(r.stdout[-2000:],r.stderr[-1000:]);check('browser UI suite process',r.returncode==0)
 subprocess.run(php+[str(base/'scripts/http_setup.php'),'invalidate'],env=env,check=True,capture_output=True)
 for path in [new,old]:
  c,h,b=init(path);check('revoked application password denied '+path,c==401,c)
  c,h,b=init(path,'Bearer '+auth['old_access_token']);check('expired OAuth access token denied '+path,c==401,c)

finally:
 os.killpg(server.pid,signal.SIGTERM)
 try:server.wait(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL)
 logs.close();subprocess.run(php+[str(base/'scripts/http_setup.php'),'cleanup'],env=env,capture_output=True)
r={'passed':sum(c['pass']for c in checks),'total':len(checks),'checks':checks};(base/'results/http.json').write_text(json.dumps(r,indent=2));print('TOTAL',r['passed'],r['total']);raise SystemExit(0 if r['passed']==r['total']else 1)
