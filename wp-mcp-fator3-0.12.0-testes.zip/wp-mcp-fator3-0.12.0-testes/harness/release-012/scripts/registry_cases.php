<?php
if(PHP_SAPI!=='cli')exit(2);
require __DIR__.'/../lab/wordpress/wp-load.php';
if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);
wp_set_current_user(1);
use Fator3\McpFiles\{ConnectionEndpoints as E,ConnectionStatus as S};
$mode=$argv[1]??'pending';
if($mode==='disabled')add_filter('mcp_adapter_create_default_server','__return_false');
if($mode==='custom')add_filter('mcp_adapter_default_server_config',static function($c){$c['server_route_namespace']='f3-test';$c['server_route']='custom';return $c;});
if($mode==='missing-tool')add_filter('mcp_adapter_default_server_config',static function($c){array_pop($c['tools']);return $c;});
if(in_array($mode,['collision','late-collision'],true))add_action('rest_api_init',static function(){register_rest_route('mcp','wp-mcp-fator3',['methods'=>'GET','callback'=>static fn()=>['other'=>true],'permission_callback'=>'__return_true'],true);},$mode==='collision'?14:20);
$s=S::snapshot($mode!=='pending');
$pass=match($mode){'disabled'=>in_array('mcp_server_disabled',$s['errors'],true),'custom'=>!$s['errors']&&E::route()==='/f3-test/custom'&&count($s['endpoints'])===3,'missing-tool'=>in_array('mcp_tools_missing',$s['errors'],true),'collision','late-collision'=>in_array('mcp_route_conflict',$s['errors'],true),'pending'=>!$s['registry_checked']&&$s['core_loaded']&&$s['server_registered']===null,default=>false};
echo json_encode(['passed'=>(int)$pass,'total'=>1,'checks'=>[['test'=>$mode,'pass'=>$pass]]]+($pass?[]:['actual'=>$s]),JSON_PRETTY_PRINT)."\n";exit($pass?0:1);
