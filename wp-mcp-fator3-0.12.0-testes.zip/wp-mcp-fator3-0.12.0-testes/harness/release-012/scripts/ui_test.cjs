const fs=require('fs'),path=require('path');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
const base=path.join(process.cwd(),'release-012');const origin=process.env.F3_TEST_ORIGIN;const fixture=JSON.parse(fs.readFileSync(path.join(base,'http-fixture.json'),'utf8'));
(async()=>{
 const browser=await chromium.launch({executablePath:path.join(base,'runtime/chrome-headless-shell-linux64/chrome-headless-shell'),headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--no-zygote','--single-process']});
 const context=await browser.newContext({viewport:{width:1440,height:1100},permissions:['clipboard-read','clipboard-write']});
 await context.addCookies(Object.entries(fixture.cookies).map(([name,value])=>({name,value,domain:'127.0.0.1',path:'/',httpOnly:true,sameSite:'Lax'})));
 const page=await context.newPage();const errors=[],checks=[];page.on('pageerror',e=>errors.push(e.message));
 const check=(n,v)=>{checks.push({test:n,pass:!!v});console.log(n,!!v)};
 fs.mkdirSync(path.join(base,'results/screenshots'),{recursive:true});
 try{
  await page.goto(origin+'/wp-admin/tools.php?page=wp-mcp-fator3&tab=connection');
  await page.locator('#f3-json-claude-code').waitFor({state:'attached'});
  check('all JSON panels initially closed',await page.locator('.f3-config[open]').count()===0);
  check('canonical endpoint visible',(await page.locator('#f3-endpoint').innerText()).includes('/mcp/wp-mcp-fator3'));
  check('WordPress prerequisite not displayed',!(await page.locator('.f3-mcp-admin').innerText()).includes('WordPress Version'));
  await page.screenshot({path:path.join(base,'results/screenshots/connection-1440.png'),fullPage:true});
  const panels=page.locator('.f3-config');await panels.first().locator('summary').click();
  const config=JSON.parse(await page.locator('#f3-json-claude-code').innerText());check('Claude Code JSON uses http',config.mcpServers['wp-mcp-fator3'].type==='http');
  await page.locator('[data-copy="f3-json-claude-code"]').click();
  await page.waitForFunction(()=>document.querySelector('#f3-feedback').textContent.includes('copiado'));
  check('copy successful feedback',(await page.locator('#f3-feedback').innerText()).includes('copiado'));
  check('copied text is valid JSON',JSON.parse(await page.evaluate(()=>navigator.clipboard.readText())).mcpServers['wp-mcp-fator3'].url===config.mcpServers['wp-mcp-fator3'].url);
  await page.screenshot({path:path.join(base,'results/screenshots/json-expanded-1440.png'),fullPage:true});
  await page.evaluate(()=>{Object.defineProperty(navigator.clipboard,'writeText',{configurable:true,value:()=>Promise.reject(new Error('denied'))});});
  await page.locator('[data-copy="f3-json-claude-code"]').click();
  check('clipboard refusal has manual fallback',(await page.locator('#f3-feedback').innerText()).includes('selecionado'));
  await page.locator('#f3-auth-oauth').focus();await page.keyboard.press('ArrowRight');
  check('auth tabs keyboard navigation',await page.locator('#f3-auth-password').getAttribute('aria-selected')==='true'&&await page.locator('#f3-password-panel').isVisible());
  // If a previous interrupted test left a tracked fixture credential, revoke it first.
  if(await page.locator('#f3-revoke').isVisible()){await page.locator('#f3-revoke').click();await page.locator('#f3-revoke-yes').click();await page.locator('#f3-generate').waitFor({state:'visible'});}
  await page.locator('#f3-generate').click();await page.locator('#f3-key-output').waitFor({state:'visible'});
  const secret=await page.locator('#f3-key-value').innerText();const first=JSON.parse(await page.locator('#f3-json-claude-code').innerText()).mcpServers['wp-mcp-fator3'].headers.Authorization;
  check('generated credential fills JSON',secret.length>12&&!first.includes('BASE64_USUARIO'));
  await page.locator('#f3-revoke').click();await page.locator('#f3-revoke-yes').click();await page.locator('#f3-generate').waitFor({state:'visible'});
  check('revocation clears secret and every JSON',!(await page.content()).includes(secret)&&!(await page.content()).includes(first)&&await page.locator('#f3-key-value').innerText()==='');
  await page.locator('#f3-generate').click();await page.locator('#f3-key-output').waitFor({state:'visible'});
  const second=JSON.parse(await page.locator('#f3-json-claude-code').innerText()).mcpServers['wp-mcp-fator3'].headers.Authorization;
  check('regeneration replaces credential',second!==first&&!second.includes('BASE64_USUARIO'));
  await page.reload();await page.locator('#f3-auth-password').click();
  check('reload cannot recover plaintext',!(await page.content()).includes(second)&&!(await page.locator('#f3-key-output').isVisible()));
  await page.locator('#f3-revoke').click();await page.locator('#f3-revoke-yes').click();await page.locator('#f3-generate').waitFor({state:'visible'});
  for(const width of [375,768,1440])for(const tab of ['connection','files','diagnostics']){
   await page.setViewportSize({width,height:1000});await page.goto(origin+'/wp-admin/tools.php?page=wp-mcp-fator3&tab='+tab);
   const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+2);check('responsive '+tab+' '+width,!overflow);
   await page.screenshot({path:path.join(base,'results/screenshots/'+tab+'-'+width+'.png'),fullPage:true});
  }
  await page.setViewportSize({width:1440,height:1100});await page.goto(origin+'/wp-admin/tools.php?page=wp-mcp-fator3&tab=connection');
  await page.evaluate(()=>{document.documentElement.style.zoom='2'});check('200 percent layout',await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+2));
  await page.screenshot({path:path.join(base,'results/screenshots/connection-zoom200.png'),fullPage:true});
  const aria=await page.locator('.f3-mcp-admin').ariaSnapshot();check('accessible named navigation and tabs',aria.includes('navigation "Configurações do MCP"')&&aria.includes('tab "OAuth"'));
  fs.writeFileSync(path.join(base,'results/accessibility-tree.txt'),aria);
  check('no JavaScript errors',errors.length===0);
 }catch(e){checks.push({test:'browser flow completed',pass:false,error:e.message});console.error(e.message);}
 finally{await browser.close();}
 const report={passed:checks.filter(c=>c.pass).length,total:checks.length,checks,errors};fs.writeFileSync(path.join(base,'results/ui.json'),JSON.stringify(report,null,2));process.exitCode=report.passed===report.total?0:1;
})();
