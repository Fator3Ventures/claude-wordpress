from pathlib import Path
import subprocess,os,socket,time,shutil,json
r=Path.cwd();old=r/'release-011';base=r/'release-012';env=os.environ.copy()|{'LD_LIBRARY_PATH':str(old/'runtime/usr/lib/x86_64-linux-gnu'),'F3_TEST_WP_LOAD':str(old/'mysql-wp/wp-load.php')};php=[str(r/'rmdir/runtime/usr/bin/php8.3'),'-c',str(old/'php.ini')]
shutil.copytree(base/'build/wp-mcp-fator3',old/'mysql-wp/wp-content/plugins/wp-mcp-fator3',dirs_exist_ok=True)
srv=subprocess.Popen([str(old/'runtime/usr/sbin/mariadbd'),'--no-defaults','--basedir='+str(old/'runtime/usr'),'--datadir='+str(old/'mariadb-suite-data'),'--user=root','--bind-address=127.0.0.1','--port=33316','--socket=','--pid-file='+str(old/'mariadb.pid'),'--log-error='+str(old/'runtime/db-error.log'),'--innodb-use-native-aio=0','--innodb-buffer-pool-size=64M','--skip-log-bin'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 deadline=time.monotonic()+15
 while time.monotonic()<deadline:
  try:s=socket.create_connection(('127.0.0.1',33316),.1);s.close();break
  except OSError:time.sleep(.05)
 subprocess.run(php+[str(old/'scripts/install_mysql_wp.php')],env=env,check=True,capture_output=True)
 for name,cmd in [('contracts-mariadb-enabled',[str(old/'scripts/contracts.php')]),('contracts-mariadb-disabled',[str(old/'scripts/contracts.php'),'disabled']),('mariadb-extra',[str(old/'scripts/mysql_extra.php')])]:
  p=subprocess.run(php+cmd,env=env,capture_output=True,text=True,timeout=120);(base/'results'/f'{name}.json').write_text(p.stdout);d=json.loads(p.stdout);print(name,d['passed'],d['total'],p.stderr[-500:],flush=True)
finally:srv.terminate();srv.wait(timeout=15)
shutil.copytree(base/'build/wp-mcp-fator3',old/'wp67/wordpress/wp-content/plugins/wp-mcp-fator3',dirs_exist_ok=True)
php[2]=str(r/'delete-post/lab/php.ini');env['F3_TEST_WP_LOAD']=str(old/'wp67/wordpress/wp-load.php')
for mode in ['enabled','disabled']:
 p=subprocess.run(php+[str(old/'scripts/contracts.php'),mode],env=env,capture_output=True,text=True,timeout=120);(base/'results'/f'contracts-wp67-{mode}.json').write_text(p.stdout);d=json.loads(p.stdout);print('wp67',mode,d['passed'],d['total'],p.stderr[-500:],flush=True)
