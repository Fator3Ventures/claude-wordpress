<?php
// Router for the disposable PHP development server only.
$root=realpath(__DIR__.'/../lab/wordpress');$path=rawurldecode(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH));
$actual=realpath($root.$path);
if($actual&&str_starts_with($actual,$root.'/')&&is_file($actual))return false;
$_SERVER['SCRIPT_NAME']='/index.php';require $root.'/index.php';
