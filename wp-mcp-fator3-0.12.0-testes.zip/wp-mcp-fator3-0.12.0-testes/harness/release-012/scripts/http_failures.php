<?php
if(PHP_SAPI!=='cli')exit(2);
require __DIR__.'/../lab/wordpress/wp-load.php';
if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);
wp_set_current_user(1);
use Fator3\McpFiles\{ConnectionTest,ConnectionEndpoints as E,ConnectionStatus as S};
$checks=[];
function cf($n,$ok,$r=null){global $checks;$checks[]=['test'=>$n,'pass'=>(bool)$ok]+($ok?[]:['actual'=>$r]);}
$before=count(WP_Application_Passwords::get_user_application_passwords(1));
foreach(['timeout'=>'cURL error 28: operation timed out','dns'=>'cURL error 6: Could not resolve host','tls'=>'cURL error 60: SSL certificate problem',401=>401,403=>403,404=>404,302=>302,'tools'=>'tools','notify'=>'notify']as$mode=>$value){
 $calls=[];$hook=static function($pre,$args,$url)use(&$calls,$mode,$value){
  $rpc=json_decode($args['body'],true);$calls[]=['method'=>$rpc['method'],'tls'=>$args['sslverify'],'redirects'=>$args['redirection'],'url'=>$url];
  if(in_array($mode,['timeout','dns','tls'],true))return new WP_Error('http_request_failed',$value);
  $status=is_int($value)?$value:200;$result=['jsonrpc'=>'2.0','id'=>$rpc['id']??null,'result'=>['serverInfo'=>['name'=>'fixture'],'protocolVersion'=>'2025-06-18']];
  if($rpc['method']==='notifications/initialized')$status=$mode==='notify'?403:202;
  if($rpc['method']==='tools/list')$result['result']=['tools'=>[]];
  return ['headers'=>[],'response'=>['code'=>$status],'body'=>wp_json_encode($result),'cookies'=>[]];
 };
 add_filter('pre_http_request',$hook,10,3);$r=ConnectionTest::run(E::PRIMARY);remove_filter('pre_http_request',$hook,10);
 $expected=['timeout'=>'http_timeout_failed','dns'=>'http_dns_failed','tls'=>'http_tls_failed',401=>'test_auth_failed',403=>'test_forbidden',404=>'test_route_missing',302=>'test_redirect_refused','tools'=>'mcp_tools_missing','notify'=>'test_forbidden'][$mode];
 cf('HTTP failure '.$mode,($r['error_code']??'')===$expected,$r);
 cf('credential cleanup '.$mode,count(WP_Application_Passwords::get_user_application_passwords(1))===$before);
 cf('TLS and redirects guarded '.$mode,!array_filter($calls,fn($x)=>!$x['tls']||$x['redirects']!==0||$x['url']!==E::url(E::PRIMARY)));
 cf('local status survives HTTP failure '.$mode,S::snapshot()['core_loaded']&&S::snapshot()['tools_ready']);
}
$filter=static fn()=> 'https://foreign.example/mcp';add_filter('rest_url',$filter);$r=ConnectionTest::run(E::PRIMARY);remove_filter('rest_url',$filter);cf('foreign test origin rejected',$r['error_code']==='test_origin_mismatch',$r);
cf('test retains no credential',!str_contains(wp_json_encode(get_user_meta(1,'f3_mcp_connection_test',true)),'Authorization'));
$r=['passed'=>count(array_filter($checks,fn($x)=>$x['pass'])),'total'=>count($checks),'checks'=>$checks];echo wp_json_encode($r,JSON_PRETTY_PRINT);exit($r['passed']===$r['total']?0:1);
