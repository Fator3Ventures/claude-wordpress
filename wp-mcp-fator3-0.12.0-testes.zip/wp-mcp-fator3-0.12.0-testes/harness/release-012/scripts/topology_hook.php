<?php
// Disposable lab MU plugin; never shipped in the installable package.
$m=getenv('F3_TEST_TOPO');
if($m==='prefix')add_filter('rest_url_prefix',static fn()=>'api');
if($m==='plain')add_filter('pre_option_permalink_structure',static fn()=>'');
if($m==='custom')add_filter('mcp_adapter_default_server_config',static function($c){$c['server_route_namespace']='f3-test';$c['server_route']='custom';return$c;});
if($m==='disabled')add_filter('mcp_adapter_create_default_server','__return_false');
if($m==='collision')add_action('rest_api_init',static function(){register_rest_route('mcp','wp-mcp-fator3',['methods'=>['GET','POST'],'callback'=>static fn()=>['foreign_route'=>true,'user'=>get_current_user_id()],'permission_callback'=>'__return_true'],true);},14);
add_filter('rest_post_dispatch',static function($response){if($response instanceof WP_REST_Response){$response->header('X-F3-Lab-No-Cache',defined('DONOTCACHEPAGE')&&DONOTCACHEPAGE?'yes':'no');$response->header('X-F3-Lab-Cache-Enabled',!empty($GLOBALS['cache_enabled'])?'yes':'no');}return$response;},99);
