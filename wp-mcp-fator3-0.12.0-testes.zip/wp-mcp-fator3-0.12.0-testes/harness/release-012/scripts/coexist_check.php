<?php
if(PHP_SAPI!=='cli')exit(2);
$_SERVER['HTTP_HOST']='127.0.0.1:38012';$_SERVER['REQUEST_URI']='/';
require __DIR__.'/../lab/wordpress/wp-load.php';if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);wp_set_current_user(1);
use Fator3\McpFiles\ConnectionStatus as S;
$checks=[];function cc($n,$ok,$value=null){global$checks;$checks[]=['test'=>$n,'pass'=>(bool)$ok]+($ok?[]:['actual'=>$value]);}
$s=S::snapshot();cc('coexisting server routes and metatools',empty($s['errors']),$s);
$all=array_keys(wp_get_abilities());$own=json_decode(file_get_contents(__DIR__.'/../build/wp-mcp-fator3/tests/expected-abilities.json'),true);cc('100 own abilities retained',!array_diff($own,$all));
$groups=[];foreach(['google/','ga/','gsc/','ads/','f3base/']as$prefix){$groups[$prefix]=count(array_filter($all,fn($n)=>str_starts_with($n,$prefix)));cc('addon discovery '.$prefix,$groups[$prefix]>0,$groups);}
foreach(['google/status','f3base/config-core-ler']as$n){$r=wp_get_ability($n)->execute([]);cc('addon local ability '.$n,!is_wp_error($r),is_wp_error($r)?$r->get_error_message():null);}
cc('Yoast loaded',defined('WPSEO_VERSION'));cc('Super Cache loaded and enabled',function_exists('wp_cache_phase2')&&!empty($GLOBALS['cache_enabled'])&&defined('WP_CACHE')&&WP_CACHE);
// Fator3 styles are only enqueued on its own admin screen.
Fator3\McpFiles\Admin::assets('toplevel_page_wpseo_dashboard');cc('Fator3 CSS not enqueued on Yoast',!wp_style_is('f3-mcp-admin','enqueued'));
$report=['passed'=>count(array_filter($checks,fn($x)=>$x['pass'])),'total'=>count($checks),'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'yoast'=>defined('WPSEO_VERSION')?WPSEO_VERSION:null,'groups'=>$groups,'checks'=>$checks];echo wp_json_encode($report,JSON_PRETTY_PRINT);exit($report['passed']===$report['total']?0:1);
