from pathlib import Path
import os,subprocess,json,shutil
r=Path.cwd();b=r/'release-012';s=b/'build/wp-mcp-fator3';wp=b/'lab/wordpress';php=[str(r/'rmdir/runtime/usr/bin/php8.3'),'-c',str(r/'delete-post/lab/php.ini')];env=os.environ.copy()|{'F3_TEST_WP_LOAD':str(wp/'wp-load.php'),'F3_TEST_ORIGIN':'http://127.0.0.1:38012'}
shutil.copytree(s,wp/'wp-content/plugins/wp-mcp-fator3',dirs_exist_ok=True)
# Test own contracts in the isolated lab; coexistence was separately verified.
subprocess.run(php+['-r',"require 'release-012/lab/wordpress/wp-load.php';update_option('active_plugins',['wp-mcp-fator3/wp-mcp-fator3.php']);"],env=env,check=True,capture_output=True)
checks=[]
def run(n,args,direct=True):
 p=subprocess.run(php+args,env=env,capture_output=True,text=True,timeout=120)
 if direct:(b/'results'/f'{n}.json').write_text(p.stdout)
 else:(b/'results'/f'{n}-console.txt').write_text(p.stdout)
 d=json.loads((b/'results'/f'{n}.json').read_text());print(n,p.returncode,d.get('passed'),d.get('total'),p.stderr[-500:],flush=True);checks.append((n,p.returncode))
for n in ['unit','http_failures']:run(n.replace('_','-'),[str(b/'scripts'/f'{n}.php')])
for n in ['contracts','advanced']:run(n,[str(r/'release-011/scripts'/f'{n}.php')])
for mode in ['pending','disabled','custom','missing-tool','collision','late-collision']:run('registry-'+mode,[str(b/'scripts/registry_cases.php'),mode])
for mode in ['enabled','disabled']:run('delete-post-'+mode,[str(s/'tests/delete-post-093.php'),str(wp),mode,str(b/'results'/f'delete-post-{mode}.json')],False)
run('rmdir',[str(s/'tests/rmdir-092.php'),str(b/'results/rmdir.json')],False)
for mode in ['wp','edit','mods']:run('confine-'+mode,[str(s/'tests/confine.php'),str(wp),mode,str(b/'results'/f'confine-{mode}.json')],False)
files=[p for p in s.rglob('*.php')if 'tests'not in p.relative_to(s).parts];errors=[]
for f in files:
 p=subprocess.run(php+['-l',str(f)],capture_output=True,text=True)
 if p.returncode:errors.append({'file':str(f.relative_to(s)),'error':p.stdout+p.stderr})
(b/'results/php-lint.json').write_text(json.dumps({'files':len(files),'errors':errors},indent=2));print('lint',len(files),len(errors),flush=True)
raise SystemExit(1 if errors or any(code for n,code in checks)else 0)
