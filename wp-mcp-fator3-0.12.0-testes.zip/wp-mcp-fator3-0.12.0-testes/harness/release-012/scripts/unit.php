<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit(2);
require getenv('F3_TEST_WP_LOAD') ?: __DIR__.'/../lab/wordpress/wp-load.php';
if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);
wp_set_current_user(1);
use Fator3\McpFiles\{ConnectionEndpoints as E,ConnectionStatus as S,Admin,PathGuard,Database};
$checks=[];
function check012($name,$ok,$actual=null){global $checks;$checks[]=['test'=>$name,'pass'=>(bool)$ok]+($ok?[]:['actual'=>$actual]);}
$s=S::snapshot();check012('integrated registry ready',!$s['errors']&&$s['registry_checked'],$s);
check012('two aliases same callback',rest_get_server()->get_routes()[E::PRIMARY][0]['callback']===rest_get_server()->get_routes()[E::LEGACY][0]['callback']);
check012('exact three metatools',count($s['tools'])===3);
check012('namespace detector works',Fator3\McpFiles\f3_mcp_files_servidor_mcp_detectado());
$oldget=$_GET;$oldpost=$_POST;$olduri=$_SERVER['REQUEST_URI']??'';
foreach([E::PRIMARY,E::LEGACY]as$r){$_GET=['rest_route'=>$r];$_POST=[];check012('route matches '.$r,E::matches(E::request_route()));$_POST=['rest_route'=>'/wp/v2/users'];check012('POST route override '.$r,!E::matches(E::request_route()));}
foreach(['/mcp/wp-mcp-fator3-invalid','/mcp/wp-mcp-ultimate/other','/wp/v2/users']as$r)check012('route rejects '.$r,!E::matches($r));
$_GET=$oldget;$_POST=$oldpost;$_SERVER['REQUEST_URI']=$olduri;
foreach(E::routes()as$r){check012('resource '.$r,E::resource(E::url($r))===E::url($r));check012('metadata mapping '.$r,E::metadata_route(E::metadata_path($r))===$r);}
check012('legacy metadata resource',E::metadata_route('/.well-known/oauth-protected-resource')===E::LEGACY);
check012('foreign resource rejected',is_wp_error(E::resource('https://other.example/mcp')));
check012('non-string resource rejected',is_wp_error(E::resource(['x'])));
$settings=[PathGuard::OPTION_ENABLED=>get_option(PathGuard::OPTION_ENABLED,true),Database::OPTION_WRITES=>get_option(Database::OPTION_WRITES,true)];
try{
 $r=Admin::save('channel',false);check012('admin verified close',$r['success']&&!PathGuard::is_enabled(),$r);
 $r=Admin::save('channel',false);check012('admin unchanged',$r['success']&&!$r['changed'],$r);
 $r=Admin::save('channel',true);check012('admin verified reopen',$r['success']&&PathGuard::is_enabled(),$r);
 $veto=static fn($new,$old)=>$old;add_filter('pre_update_option_'.PathGuard::OPTION_ENABLED,$veto,10,2);$r=Admin::save('channel',false);remove_filter('pre_update_option_'.PathGuard::OPTION_ENABLED,$veto);check012('admin rejected write',!$r['success']&&PathGuard::is_enabled(),$r);
 add_filter('f3_mcp_files_enabled','__return_false');$r=Admin::save('channel',true);remove_filter('f3_mcp_files_enabled','__return_false');check012('admin reports override',$r['success']&&$r['overridden']&&!$r['effective'],$r);
 $r=Admin::save('database',false);check012('db writes false saved',$r['success']&&!Database::writes_enabled(),$r);
}finally{foreach($settings as$n=>$v)update_option($n,$v);}
foreach(['connection','files','diagnostics']as$tab){$_GET=['tab'=>$tab];ob_start();Admin::render();$html=ob_get_clean();check012('render '.$tab,str_contains($html,'f3-mcp-admin')&&!str_contains($html,'não detectado —'),substr($html,0,100));check012('WordPress requirement removed '.$tab,!str_contains($html,'Versão do WordPress')&&!str_contains($html,'WordPress Version'));file_put_contents(__DIR__.'/../results/render-'.$tab.'.html',$html);}
$_GET=$oldget;
$r=wp_get_ability('system/capabilities')->execute([]);check012('agent canonical and legacy URLs',$r['endpoint']===E::url()&&$r['legacy_endpoint']===E::url(E::LEGACY),$r);
$names=array_keys(wp_get_abilities());$expected=json_decode(file_get_contents(__DIR__.'/../build/wp-mcp-fator3/tests/expected-abilities.json'),true);check012('original own abilities retained',!array_diff($expected,$names));
$report=['passed'=>count(array_filter($checks,fn($x)=>$x['pass'])),'total'=>count($checks),'checks'=>$checks];echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n";exit($report['passed']===$report['total']?0:1);
