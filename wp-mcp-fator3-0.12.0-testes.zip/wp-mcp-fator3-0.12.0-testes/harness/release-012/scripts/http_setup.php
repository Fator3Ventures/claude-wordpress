<?php
if(PHP_SAPI!=='cli')exit(2);
require __DIR__.'/../lab/wordpress/wp-load.php';
if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);
wp_set_current_user(1);
$path=__DIR__.'/../http-fixture.json';
if(($argv[1]??'')==='invalidate'){
 $d=json_decode(file_get_contents($path),true);WP_Application_Passwords::delete_application_password(1,$d['app_uuid']);
 update_option('_transient_timeout_f3_mcp_oauth_at_'.hash('sha256',$d['old_access_token']),time()-60);exit;
}
if(($argv[1]??'')==='cleanup'){
 $d=json_decode(file_get_contents($path),true);WP_Application_Passwords::delete_application_password(1,$d['app_uuid']);
 foreach([$d['auth_token'],$d['logged_token']]as$t)WP_Session_Tokens::get_instance(1)->destroy($t);
 unlink($path);exit;
}
update_option('permalink_structure','/%postname%/');flush_rewrite_rules(false);
$r=WP_Application_Passwords::create_new_application_password(1,['name'=>'F3 012 pre-upgrade compatibility fixture']);
if(is_wp_error($r))throw new RuntimeException($r->get_error_message());
$user=wp_get_current_user();$expires=time()+7200;$at=WP_Session_Tokens::get_instance(1)->create($expires);$lt=WP_Session_Tokens::get_instance(1)->create($expires);
$client='f3-012-fixture-client';WpMcpUltimate\OAuth\TokenStore::save_client($client,['client_name'=>'Fator3 regression client','redirect_uris'=>['http://127.0.0.1:49151/callback'],'created'=>time()]);
$token=WpMcpUltimate\OAuth\TokenStore::generate_token();$refresh=WpMcpUltimate\OAuth\TokenStore::generate_token();$payload=['user_id'=>1,'client_id'=>$client,'scope'=>'mcp'];
WpMcpUltimate\OAuth\TokenStore::store_access_token($token,$payload);WpMcpUltimate\OAuth\TokenStore::store_refresh_token($refresh,$payload);
$session=WpMcpUltimate\Server\Transport\Infrastructure\SessionManager::create_session(1,['protocolVersion'=>'2025-06-18']);
$d=['created_with'=>F3_MCP_FILES_VERSION,'username'=>$user->user_login,'password'=>$r[0],'app_uuid'=>$r[1]['uuid'],'client_id'=>$client,'old_access_token'=>$token,'old_refresh_token'=>$refresh,'old_session'=>$session,'auth_token'=>$at,'logged_token'=>$lt,'cookies'=>[AUTH_COOKIE=>wp_generate_auth_cookie(1,$expires,'auth',$at),LOGGED_IN_COOKIE=>wp_generate_auth_cookie(1,$expires,'logged_in',$lt)]];
file_put_contents($path,json_encode($d));chmod($path,0600);echo "Disposable compatibility credentials created\n";
