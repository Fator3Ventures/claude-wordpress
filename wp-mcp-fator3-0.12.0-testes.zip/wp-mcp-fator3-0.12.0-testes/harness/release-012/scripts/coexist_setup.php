<?php
if(PHP_SAPI!=='cli')exit(2);
require __DIR__.'/../lab/wordpress/wp-load.php';if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';
foreach(['wp-mcp-google-fator3/wp-mcp-google-fator3.php','base-site-core-fator3/base-site-core-fator3.php','wp-super-cache/wp-cache.php','wordpress-seo/wp-seo.php']as$p){$r=activate_plugin($p);echo $p.' '.(is_wp_error($r)?$r->get_error_message():'activated')."\n";}
if(function_exists('wp_cache_enable')){wp_cache_enable();wp_super_cache_enable();}
