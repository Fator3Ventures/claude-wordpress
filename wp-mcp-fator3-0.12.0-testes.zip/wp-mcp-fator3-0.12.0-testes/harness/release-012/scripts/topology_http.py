from pathlib import Path
import os,subprocess,time,socket,json,urllib.request,urllib.error,base64,re,signal,shutil
r=Path.cwd();b=r/'release-012';wp=b/'lab/wordpress';php=[str(r/'rmdir/runtime/usr/bin/php8.3'),'-c',str(r/'delete-post/lab/php.ini')];checks=[]
mu=wp/'wp-content/mu-plugins/f3-topology.php';shutil.copyfile(b/'scripts/topology_hook.php',mu)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**k):return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
def req(url,body=None,headers=None):
 try:
  with opener.open(urllib.request.Request(url,data=body,headers=headers or{}),timeout=20)as x:return x.status,dict(x.headers),x.read()
 except urllib.error.HTTPError as e:return e.code,dict(e.headers),e.read()
def check(n,v,actual=None):checks.append({'test':n,'pass':bool(v),**({}if v else{'actual':actual})});print(n,bool(v),flush=True)
try:
 for mode in ['coexist','subdir','prefix','plain','custom','disabled','collision']:
  origin='http://127.0.0.1:38012'+('/site'if mode in ['subdir','prefix','plain']else'');env=os.environ.copy()|{'F3_TEST_ORIGIN':origin,'F3_TEST_TOPO':mode,'PHP_CLI_SERVER_WORKERS':'4'}
  subprocess.run(php+[str(b/'scripts/http_setup.php')],env=env,check=True,capture_output=True);a=json.loads((b/'http-fixture.json').read_text());basic='Basic '+base64.b64encode((a['username']+':'+a['password']).encode()).decode()
  p=subprocess.run(php+['-r',"require 'release-012/lab/wordpress/wp-load.php'; echo wp_json_encode(array_map([Fator3\\McpFiles\\ConnectionEndpoints::class,'url'],Fator3\\McpFiles\\ConnectionEndpoints::routes()));"],env=env,capture_output=True,check=True);urls=json.loads(p.stdout)
  log=(b/'results'/f'topology-{mode}.log').open('w');server=subprocess.Popen(php+['-S','127.0.0.1:38012','-t',str(wp),str(b/'scripts/router.php')],env=env,stdout=log,stderr=log,start_new_session=True)
  try:
   deadline=time.monotonic()+5
   while time.monotonic()<deadline:
    try:s=socket.create_connection(('127.0.0.1',38012),.1);s.close();break
    except OSError:time.sleep(.02)
   initialize=json.dumps({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'topology','version':'1'}}}).encode()
   if mode=='collision':
    c,h,body=req(urls[0],initialize,{'Authorization':'Bearer '+a['old_access_token'],'Content-Type':'application/json'});check('collision never receives MCP bearer identity',c==200 and json.loads(body).get('user')==0,{'code':c,'body':body.decode()});continue
   if mode=='disabled':
    c,h,body=req(urls[0],initialize,{'Authorization':basic,'Content-Type':'application/json'});check('disabled server HTTP missing',c==404,c);continue
   for url in urls:
    c,h,body=req(url,initialize,{'Content-Type':'application/json'});match=re.search('resource_metadata="([^"]+)"',h.get('WWW-Authenticate',''));check(mode+' anonymous challenge '+url,c==401 and bool(match),{'code':c,'header':h.get('WWW-Authenticate')})
    if match:
     c,mh,body=req(match[1]);data=json.loads(body);check(mode+' advertised resource '+url,c==200 and data.get('resource')==url and 'no-store'in mh.get('Cache-Control',''),{'code':c,'data':data,'headers':mh})
    for authname,auth in [('Basic',basic),('Bearer','Bearer '+a['old_access_token'])]:
     c,h,body=req(url,initialize,{'Authorization':auth,'Content-Type':'application/json'});data=json.loads(body);check(mode+' '+authname+' initialize '+url,c==200 and 'result'in data,{'code':c,'body':data})
     check(mode+' private no-cache '+authname+' '+url,'no-store'in h.get('Cache-Control','')and h.get('X-F3-Lab-No-Cache')=='yes',h)
    if mode=='coexist':
     c,h,body=req(url);check('Super Cache active on GET '+url,h.get('X-F3-Lab-Cache-Enabled')=='yes',h)
     c,h,body=req(url,initialize,{'Content-Type':'application/json'});check('authenticated response not reused for anonymous '+url,c==401,c)
   if mode=='coexist':
    files=list((wp/'wp-content/cache').rglob('*'));bad=[str(f)for f in files if f.is_file()and('wp-mcp-'in str(f)or 'oauth' in str(f))and f.stat().st_size>0];check('no MCP or OAuth cache payload generated',not bad,bad)
  finally:
   os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=5);log.close();subprocess.run(php+[str(b/'scripts/http_setup.php'),'cleanup'],env=env,capture_output=True)
finally:mu.unlink(missing_ok=True)
report={'passed':sum(x['pass']for x in checks),'total':len(checks),'checks':checks};(b/'results/topology-http.json').write_text(json.dumps(report,indent=2));print('TOTAL',report['passed'],report['total']);raise SystemExit(0 if report['passed']==report['total']else 1)
