<?php
declare(strict_types=1);
define('EMPTY_TRASH_DAYS', ($argv[1] ?? '') === 'disabled' ? 0 : 30);
require getenv('F3_TEST_WP_LOAD') ?: __DIR__.'/../../delete-post/lab/wordpress/wp-load.php';
if (!defined('F3_DELETE_POST_DISPOSABLE_LAB')) exit(2);
wp_set_current_user(1);
use Fator3\McpFiles\{Backups,StateStore,SqlGuard,ContentTools};
$checks=[]; $prefix='f3_011_'.bin2hex(random_bytes(4)); $posts=[]; $comments=[]; $options=[]; $table=$wpdb->prefix.$prefix;
function test($name,$condition,$actual=null){global $checks; $checks[]=['test'=>$name,'pass'=>(bool)$condition]+($condition?[]:['actual'=>$actual]);}
function ability($name,$args=[]){$a=wp_get_ability($name); if(!$a)return ['success'=>false,'error_code'=>'ability_missing'];$r=$a->execute($args);return is_wp_error($r)?['success'=>false,'error_code'=>$r->get_error_code(),'message'=>$r->get_error_message()]:$r;}
$dir=WP_CONTENT_DIR.'/'.$prefix;mkdir($dir);
try {
 foreach(['post','page','f3_test_custom'] as $type){
  if($type==='f3_test_custom')register_post_type($type,['public'=>true,'supports'=>['title','editor','revisions']]);
  $id=wp_insert_post(['post_type'=>$type,'post_title'=>$prefix,'post_status'=>'draft']);$posts[]=$id;
  $route=$type==='page'?'content/delete-page':'content/delete-post';
  $r=ability($route,['id'=>$id,'force'=>false]);$again=ability($route,['id'=>$id,'force'=>false]);
  test('trash '.$type, EMPTY_TRASH_DAYS?(!empty($r['success'])&& !empty($again['success'])&&get_post_status($id)==='trash'&&$again['changed']===false):($r['error_code']==='trash_disabled'&&get_post($id)),[$r,$again]);
  if(EMPTY_TRASH_DAYS){$un=ability('content/untrash',['id'=>$id]);test('untrash '.$type,$un['success']&&get_post_status($id)!=='trash',$un);}
  $r=ability($route,['id'=>$id,'force'=>true]);test('permanent '.$type,$r['success']&&!get_post($id),$r);
 }
 $parent=wp_insert_post(['post_type'=>'post','post_title'=>$prefix,'post_status'=>'draft']);$posts[]=$parent;
 $cid=(int)wp_insert_comment(['comment_post_ID'=>$parent,'comment_content'=>$prefix,'comment_approved'=>1]);$comments[]=$cid;
 $r=ability('comments/delete',['id'=>$cid,'force'=>false]);$r=ability('comments/delete',['id'=>$cid,'force'=>false]);
 test('comment trash contract',EMPTY_TRASH_DAYS?($r['success']&&get_comment($cid)->comment_approved==='trash'):($r['error_code']==='trash_disabled'&&get_comment($cid)),$r);
 $r=ability('comments/delete',['id'=>$cid,'force'=>true]);test('comment permanent',$r['success']&&!get_comment($cid),$r);
 $r=ability('content/delete-page',['id'=>$parent]);test('page type guard',$r['error_code']==='not_found',$r);
 if(EMPTY_TRASH_DAYS){
 $name=$prefix;$options[]=$name;update_option($name,'same');$r=ability('options/update',['name'=>$name,'value'=>'same']);test('option unchanged success',$r['success']&&$r['changed']===false,$r);
 $filter=static fn($v)=>'normalized';add_filter('sanitize_option_'.$name,$filter);$r=ability('options/update',['name'=>$name,'value'=>'requested']);remove_filter('sanitize_option_'.$name,$filter);test('option sanitized readback',$r['success']&&$r['new_value']==='normalized'&&$r['requested_value']==='requested'&&get_option($name)==='normalized',$r);
 $veto=static fn($new,$old)=>$old;add_filter('pre_update_option_'.$name,$veto,10,2);$r=ability('options/update',['name'=>$name,'value'=>'denied']);remove_filter('pre_update_option_'.$name,$veto);test('option veto',$r['error_code']==='option_write_rejected'&&get_option($name)==='normalized',$r);
 $r=ability('options/update',['name'=>$name,'key'=>'x','value'=>'wrong']);test('option scalar key conflict',$r['error_code']==='option_type_conflict',$r);
 $options[]=$name.'_new';$r=ability('options/update',['name'=>$name.'_new','key'=>'x','value'=>['nested'=>[true,null,3]]]);test('option missing array key',$r['success']&&get_option($name.'_new')===['x'=>['nested'=>[true,null,3]]],$r);
 foreach(["A  B","A\nB","A\tB","WHERE LIMIT 9"] as $value){$sql=$wpdb->prepare('SELECT %s AS value',$value);$r=ability('db/query',['sql'=>$sql,'limit'=>1]);test('SQL literal '.bin2hex($value),($r['rows'][0]['value']??null)===$value,$r);}
 test('SQL scan escapes',SqlGuard::scan("SELECT 'a\\\\b;  x' -- hi\n")['sql']==="SELECT 'a\\\\b;  x'");
 test('SQL unclosed refused',is_wp_error(SqlGuard::validate_select("SELECT 'bad")));
 test('SQL WHERE literal refused',is_wp_error(SqlGuard::validate_write("UPDATE test SET val='WHERE all'")));
 foreach(["SELECT * FROM t WHERE 'limit 1'='limit 1'","SELECT * FROM (SELECT * FROM t LIMIT 1) s","SELECT * FROM t LIMIT 900000",'SELECT * FROM t LIMIT 8, 9999'] as $sql){$limited=SqlGuard::enforce_limit($sql,2);test('outer LIMIT '.$sql,(bool)preg_match('/LIMIT 2(?: OFFSET 8)?$/',$limited),$limited);}
 $wpdb->query("CREATE TABLE `$table` (id INTEGER PRIMARY KEY, amount INTEGER, code VARCHAR(40) UNIQUE)");$wpdb->query("INSERT INTO `$table` (id,amount,code) VALUES (1,0,'a'),(2,10,'b'),(3,30,'c')");
 $r=ability('db/query',['sql'=>"SELECT id FROM `$table` WHERE 'limit 1'='limit 1'",'limit'=>1]);test('SQL actual row cap',count($r['rows']??[])===1,$r);
 $sql="UPDATE `$table` SET amount=amount+1 WHERE id=1";$prev=ability('db/execute',['sql'=>$sql]);test('DB preview generated',!empty($prev['confirm_token']),$prev);
 if(!empty($prev['confirm_token'])){
  $wpdb->query("UPDATE `$table` SET amount=100 WHERE id=1");$r=ability('db/execute',['sql'=>$sql,'confirm_token'=>$prev['confirm_token']]);test('DB changed state conflict',($r['error_code']??'')==='database_conflict'&&(int)$wpdb->get_var("SELECT amount FROM `$table` WHERE id=1")===100,$r);
  $prev=ability('db/execute',['sql'=>$sql]);$r=ability('db/execute',['sql'=>$sql,'confirm_token'=>$prev['confirm_token']]);$replay=ability('db/execute',['sql'=>$sql,'confirm_token'=>$prev['confirm_token']]);test('DB single use replay',$r['success']&&($replay['replayed']??false)&&(int)$wpdb->get_var("SELECT amount FROM `$table` WHERE id=1")===101,[$r,$replay]);
  $prev=ability('db/execute',['sql'=>$sql]);$state=StateStore::get('db-confirmations',$prev['confirm_token']);$state['expires']=time()-1;StateStore::put('db-confirmations',$prev['confirm_token'],$state);$r=ability('db/execute',['sql'=>$sql,'confirm_token'=>$prev['confirm_token']]);test('DB expiry',$r['error_code']==='confirmation_expired',$r);
  $sql="REPLACE INTO `$table` (id,amount,code) VALUES (1,999,'b')";$prev=ability('db/execute',['sql'=>$sql]);test('REPLACE multiple unique conflicts',($prev['affected_rows']??0)===2,$prev);
  if(!empty($prev['confirm_token'])){$r=ability('db/execute',['sql'=>$sql,'confirm_token'=>$prev['confirm_token']]);$b=!empty($r['backup_id'])?Backups::metadata($r['backup_id']):null;test('REPLACE backed up old rows',$r['success']&&is_array($b)&&count($b['rows'])===2,[$r,$b]);}
 }
 $p=$dir.'/sample.txt';file_put_contents($p,'old');$hash=hash_file('sha256',$p);$r=ability('files/write',['path'=>$p,'content'=>'new','expected_sha256'=>$hash,'idempotency_key'=>$prefix.'_write']);test('files write full contract',$r['success']&&!empty($r['backup_id'])&&file_get_contents($p)==='new',$r);
 $r2=ability('files/write',['path'=>$p,'content'=>'new','expected_sha256'=>$hash,'idempotency_key'=>$prefix.'_write']);test('files idempotent replay',($r2['replayed']??false)&&$r2['backup_id']===$r['backup_id'],$r2);
 $bad=ability('files/write',['path'=>$p,'content'=>'oops','expected_sha256'=>$hash]);test('files conflict identifiable',($bad['error_code']??'')==='file_conflict'&&($bad['conflict']??false)&&file_get_contents($p)==='new',$bad);
 $rest=ability('files/restore',['backup_id'=>$r['backup_id'],'expected_sha256'=>hash('sha256','new')]);test('restore with precondition',$rest['success']&&file_get_contents($p)==='old',$rest);
 $copy=ability('files/copy',['source'=>$p,'destination'=>$dir.'/copied.txt','expected_sha256'=>hash('sha256','old')]);test('copy',$copy['success']&&file_get_contents($dir.'/copied.txt')==='old',$copy);
 $move=ability('files/move',['source'=>$dir.'/copied.txt','destination'=>$dir.'/moved.txt']);test('move',$move['success']&&!file_exists($dir.'/copied.txt')&&file_exists($dir.'/moved.txt'),$move);
 $mk=ability('files/mkdir',['path'=>$dir.'/a/b','parents'=>true]);$rm=ability('files/delete',['path'=>$dir.'/a/b','empty_dir'=>true]);test('mkdir and empty rmdir',$mk['success']&&$rm['success'],[$mk,$rm]);
 $stat=ability('files/stat',['path'=>$p]);test('stat hash',$stat['sha256']===hash('sha256','old'),$stat);
 $list=ability('files/list',['path'=>$dir,'per_page'=>1]);test('listing pagination',count($list['entries'])===1&&$list['has_more'],$list);
 $log=$dir.'/log.txt';file_put_contents($log,"first\nsecond\n");$read=ability('files/read',['path'=>$log,'cursor'=>'','byte_limit'=>6]);test('cursor first',$read['content']==="first\n"&&!empty($read['next_cursor']),$read);
 if(!empty($read['next_cursor'])){$read2=ability('files/read',['path'=>$log,'cursor'=>$read['next_cursor']]);test('cursor second',$read2['content']==="second\n",$read2);file_put_contents($log,"third\n",FILE_APPEND);$read3=ability('files/read',['path'=>$log,'cursor'=>$read2['next_cursor']]);test('cursor append',$read3['content']==="third\n",$read3);file_put_contents($log,"x\n");$rot=ability('files/read',['path'=>$log,'cursor'=>$read3['next_cursor']]);test('cursor truncate',$rot['error_code']==='file_rotated',$rot);}
 file_put_contents($log,"one\nerror here\nlast\n");$tail=ability('files/read',['path'=>$log,'tail_lines'=>1]);$grep=ability('files/read',['path'=>$log,'grep'=>'error']);test('legacy tail grep',$tail['content']==="last\n"&&$grep['content']==="error here\n",[$tail,$grep]);
 $search=ability('files/search',['path'=>$dir,'grep'=>'error']);test('file search',count($search['matches']??[])===1,$search);
 $content="PREFIX\n<!-- wp:group {\"className\":\"outer\"} --><div class=\"outer\"><!-- wp:paragraph {\"x\": \"keep  spacing\"} --><p>A\\B</p><!-- /wp:paragraph --></div><!-- /wp:group -->\nTAIL";
 $up=ability('content/upsert',['external_ref'=>$prefix,'post_type'=>'page','content'=>$content,'title'=>'First']);$posts[]=$up['id']??0;$id=$up['id']??0;test('upsert created',$up['success']&&get_post_field('post_content',$id,'raw')===$content,$up);
 $up2=ability('content/upsert',['external_ref'=>$prefix,'post_type'=>'page','title'=>'Second','expected_revision'=>$up['revision']??'']);test('upsert same ID',$up2['success']&&$up2['id']===$id&&!$up2['created'],$up2);
 $stale=ability('content/update-page',['id'=>$id,'title'=>'Overwrite','expected_revision'=>$up['revision']]);test('content stale revision',$stale['error_code']==='content_conflict',$stale);
 $blocks=ability('content/blocks',['id'=>$id]);test('block tree and index',$blocks['success']&&count($blocks['index'])===2,$blocks);
 $edit=ability('content/edit-block',['id'=>$id,'block_path'=>[0,0],'attributes'=>['className'=>'local'],'expected_revision'=>$up2['revision']]);$saved=get_post_field('post_content',$id,'raw');test('localized block preservation',$edit['success']&&str_starts_with($saved,"PREFIX\n<!-- wp:group {\"className\":\"outer\"} --><div class=\"outer\">")&&str_ends_with($saved,"</div><!-- /wp:group -->\nTAIL")&&str_contains($saved,'<p>A\\B</p>'),$edit);
 $diff=ability('content/diff',['id'=>$id,'content'=>'Proposed']);test('content diff preview',$diff['success']&&$diff['changed']&&get_post_field('post_content',$id,'raw')===$saved,$diff);
 $disc=ability('wp-mcp-ultimate/discover-abilities',['prefix'=>'files/','per_page'=>2]);test('discovery pagination',count($disc['abilities']??[])===2&&!empty($disc['next_cursor']),$disc);
 $disc2=ability('wp-mcp-ultimate/discover-abilities',['prefix'=>'files/','per_page'=>2,'cursor'=>$disc['next_cursor']??'']);test('discovery continuation',($disc['abilities'][0]['name']??'')!==($disc2['abilities'][0]['name']??''),$disc2);
 $plan=ability('operations/plan',['steps'=>[['id'=>'one','ability'=>'files/write','parameters'=>['path'=>$dir.'/planned.txt','content'=>'plan']],['id'=>'two','ability'=>'files/copy','depends_on'=>['one'],'parameters'=>['source'=>['$ref'=>'one.path'],'destination'=>$dir.'/planned-copy.txt']]]]);test('plan create',$plan['success'],$plan);
 if(!empty($plan['plan_id'])){$ap=ability('operations/apply',['plan_id'=>$plan['plan_id'],'max_steps'=>1]);test('plan pause',($ap['plan']['status']??'')==='paused',$ap);$ap=ability('operations/apply',['plan_id'=>$plan['plan_id']]);test('plan resume',($ap['plan']['status']??'')==='complete'&&file_get_contents($dir.'/planned-copy.txt')==='plan',$ap);$ap2=ability('operations/apply',['plan_id'=>$plan['plan_id']]);test('plan replay',($ap2['plan']['status']??'')==='complete',$ap2);}
 $audit=ability('audit/list',['ability'=>'files/','per_page'=>3]);test('audit filtered page',count($audit['entries']??[])===3,$audit);
 $storage=ability('files/delete',['path'=>StateStore::directory('locks'),'empty_dir'=>true]);test('private lock protection',$storage['error_code']==='f3_private_storage',$storage);
 $backup=ability('backups/list',['per_page'=>1]);test('backup listing',count($backup['backups']??[])===1,$backup);
 if(!empty($backup['backups'][0]['id'])){$export=ability('backups/export',['backup_id'=>$backup['backups'][0]['id']]);test('backup export',$export['success']&&hash('sha256',base64_decode($export['content_base64']))===$export['sha256'],$export);}
 $health=ability('system/health');test('health',$health['success']&&$health['healthy'],$health);
 $themes=ability('themes/list');test('theme listing',$themes['success']&&count($themes['themes'])>0,$themes);$valid=ability('themes/validate',['stylesheet'=>get_stylesheet()]);test('active theme valid',$valid['success'],$valid);
 $r=ability('themes/activate',['stylesheet'=>get_stylesheet()]);test('theme activation no-op',$r['success']&&$r['changed']===false,$r);
 rest_get_server();$server=WpMcpUltimate\Server\McpAdapter::instance()->get_server('wp-mcp-ultimate-server');$tools=$server->get_tools();$execute='';foreach(array_keys($tools)as$name)if(str_contains($name,'execute-ability'))$execute=$name;$handler=new WpMcpUltimate\Server\Handlers\Tools\ToolsHandler($server);
 $r=$handler->call_tool(['params'=>['name'=>$execute,'arguments'=>['ability_name'=>'content/delete-post','parameters'=>['id'=>PHP_INT_MAX,'force'=>false]]]],1);test('MCP nested domain error',($r['isError']??false)&&($r['structuredContent']['data']['error_code']??'')==='not_found',$r);
 wp_set_current_user(0);$r=ability('files/write',['path'=>$p,'content'=>'denied']);test('anonymous denied',empty($r['success'])&&file_get_contents($p)==='old',$r);wp_set_current_user(1);
 }
} catch(Throwable $e){test('uncaught exception',false,$e->getMessage().' '.$e->getFile().':'.$e->getLine());}
finally{wp_set_current_user(1);foreach($posts as$id)if($id&&get_post($id))wp_delete_post($id,true);foreach($comments as$id)if(get_comment($id))wp_delete_comment($id,true);foreach($options as$name)delete_option($name);$wpdb->query("DROP TABLE IF EXISTS `$table`");if(is_dir($dir)){$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as$f){if($f->isDir())rmdir($f->getPathname());else unlink($f->getPathname());}rmdir($dir);}}
$report=['version'=>F3_MCP_FILES_VERSION,'wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'database'=>get_class($wpdb),'trash'=>EMPTY_TRASH_DAYS,'passed'=>count(array_filter($checks,fn($x)=>$x['pass'])),'total'=>count($checks),'checks'=>$checks];
echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PARTIAL_OUTPUT_ON_ERROR)."\n";
exit($report['passed']===$report['total']?0:1);
