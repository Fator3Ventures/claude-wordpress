<?php
$db=new mysqli('127.0.0.1','root','',null,33316);
$db->query('CREATE DATABASE IF NOT EXISTS f3_mcp_lab CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
define('WP_INSTALLING',true);$_SERVER['HTTP_HOST']='127.0.0.1:38011';$_SERVER['REQUEST_URI']='/';
require __DIR__.'/../mysql-wp/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';
if(!is_blog_installed())wp_install('Fator3 disposable MySQL lab','f3-admin','f3-lab@example.invalid',false,'',bin2hex(random_bytes(24)));
update_option('active_plugins',['wp-mcp-fator3/wp-mcp-fator3.php']);
echo 'WordPress '.get_bloginfo('version').' on '.$wpdb->get_var('SELECT VERSION()')."\n";
