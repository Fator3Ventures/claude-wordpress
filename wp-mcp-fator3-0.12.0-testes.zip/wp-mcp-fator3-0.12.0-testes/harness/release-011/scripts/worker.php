<?php
require getenv('F3_TEST_WP_LOAD') ?: __DIR__.'/../../delete-post/lab/wordpress/wp-load.php';
if(!defined('F3_DELETE_POST_DISPOSABLE_LAB'))exit(2);
wp_set_current_user(1);
use Fator3\McpFiles\{Locks,Result};
$args=json_decode(file_get_contents($argv[1]),true);
if(isset($args['timeout']))add_filter('f3_mcp_lock_timeout',static fn()=>$args['timeout']);
$execute=static function()use($args){$a=wp_get_ability($args['ability']);$r=$a->execute($args['parameters']);return is_wp_error($r)?Result::error($r):$r;};
if(isset($args['hold_path']))$r=Locks::files([$args['hold_path']],static function()use($args,$execute){file_put_contents($args['signal'],'locked');usleep((int)($args['hold_ms']??1000)*1000);return isset($args['ability'])?$execute():Result::ok();});
else $r=$execute();
echo json_encode($r,JSON_UNESCAPED_SLASHES|JSON_PARTIAL_OUTPUT_ON_ERROR)."\n";
