<?php
require getenv('F3_TEST_WP_LOAD');wp_set_current_user(1);
use Fator3\McpFiles\{Result,Backups,StateStore};
$checks=[];$t=$wpdb->prefix.'f3_db_extra';
function a($input){return Result::normalize(wp_get_ability('db/execute')->execute($input));}
function c($name,$pass,$value=null){global $checks;$checks[]=['test'=>$name,'pass'=>(bool)$pass]+($pass?[]:['actual'=>$value]);}
$wpdb->query("DROP TABLE IF EXISTS `$t`");$wpdb->query("CREATE TABLE `$t` (id INT PRIMARY KEY AUTO_INCREMENT, code VARCHAR(12) UNIQUE, amount INT, data VARBINARY(20)) ENGINE=InnoDB");
try {
 $wpdb->query("INSERT INTO `$t`(id,code,amount,data) VALUES (1,'old',0,UNHEX('FF00FE'))");
 $sql="UPDATE `$t` SET amount=amount+1 WHERE id=1";
 $pre=a(['sql'=>$sql]);$token=$pre['confirm_token'];$r=a(['sql'=>$sql,'confirm_token'=>$token]);$b=Backups::metadata($r['backup_id']);c('binary preimage faithful',base64_decode($b['rows'][0]['data']['data'])==="\xff\0\xfe",$b);
 $sql2="INSERT INTO `$t` (code,amount) VALUES ('new',7)";$p=a(['sql'=>$sql2]);$r=a(['sql'=>$sql2,'confirm_token'=>$p['confirm_token']]);c('INSERT auto increment',$r['success']&&(int)$wpdb->get_var("SELECT amount FROM `$t` WHERE code='new'")===7,$r);
 $long="REPLACE INTO `$t` (id,code,amount) VALUES (1,'value longer than column',99)";$p=a(['sql'=>$long]);$r=a(['sql'=>$long,'confirm_token'=>$p['confirm_token']]);c('strict truncation refused and rolled back',!$r['success']&&($r['rolled_back']??false)&&(int)$wpdb->get_var("SELECT amount FROM `$t` WHERE id=1")===1,$r);
 $wpdb->query("CREATE TRIGGER f3_fixture_trigger BEFORE UPDATE ON `$t` FOR EACH ROW SET NEW.amount=NEW.amount+5");$r=a(['sql'=>$sql]);c('trigger preview explicitly refused',$r['error_code']==='sql_trigger_unsupported',$r);$wpdb->query('DROP TRIGGER f3_fixture_trigger');
 $wpdb->query("ALTER TABLE `$t` ENGINE=MyISAM");$r=a(['sql'=>$sql]);c('nontransactional engine refused',$r['error_code']==='transaction_unavailable',$r);$wpdb->query("ALTER TABLE `$t` ENGINE=InnoDB");
 $p=a(['sql'=>$sql]);$state=StateStore::get('db-confirmations',$p['confirm_token']);$state['user']=999;StateStore::put('db-confirmations',$p['confirm_token'],$state);$r=a(['sql'=>$sql,'confirm_token'=>$p['confirm_token']]);c('confirmation owner bound',$r['error_code']==='confirmation_invalid',$r);
 $p=a(['sql'=>$sql]);$fail=static fn($q)=>$q==='START TRANSACTION'?'INVALID BEGIN FIXTURE':$q;add_filter('query',$fail);$r=a(['sql'=>$sql,'confirm_token'=>$p['confirm_token']]);remove_filter('query',$fail);c('BEGIN failure identified',$r['error_code']==='transaction_begin_failed',$r);
 $p=a(['sql'=>$sql]);$fail=static fn($q)=>$q==='COMMIT'?'INVALID COMMIT FIXTURE':$q;add_filter('query',$fail);$r=a(['sql'=>$sql,'confirm_token'=>$p['confirm_token']]);remove_filter('query',$fail);c('COMMIT ambiguity identified',$r['error_code']==='transaction_commit_uncertain'&&array_key_exists('applied',$r)&&$r['applied']===null,$r);$repeat=a(['sql'=>$sql,'confirm_token'=>$p['confirm_token']]);c('uncertain token not reexecuted',$repeat['error_code']==='confirmation_uncertain',$repeat);
 // Confirmations raced in separate PHP workers sharing this real MariaDB server.
 $p=a(['sql'=>$sql]);$before=(int)$wpdb->get_var("SELECT amount FROM `$t` WHERE id=1");$input=tempnam(sys_get_temp_dir(),'f3race');file_put_contents($input,json_encode(['ability'=>'db/execute','parameters'=>['sql'=>$sql,'confirm_token'=>$p['confirm_token']]]));
 $cmd=[PHP_BINARY,'-c',dirname(__DIR__).'/php.ini',__DIR__.'/worker.php',$input];$procs=[];$pipes=[];
 for($i=0;$i<2;$i++)$procs[$i]=proc_open($cmd,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes[$i]);
 $rs=[];for($i=0;$i<2;$i++){fclose($pipes[$i][0]);$rs[]=json_decode(stream_get_contents($pipes[$i][1]),true);fclose($pipes[$i][1]);fclose($pipes[$i][2]);proc_close($procs[$i]);}unlink($input);
 $after=(int)$wpdb->get_var("SELECT amount FROM `$t` WHERE id=1");c('concurrent confirmations execute once',$after===$before+1&&($rs[0]['success']??false)&&($rs[1]['success']??false)&&boolval($rs[0]['replayed']??false)!==boolval($rs[1]['replayed']??false),$rs);
} catch(Throwable $e){c('unexpected exception',false,$e->getMessage());}
finally{$wpdb->query('DROP TRIGGER IF EXISTS f3_fixture_trigger');$wpdb->query("DROP TABLE IF EXISTS `$t`");}
$r=['passed'=>count(array_filter($checks,fn($x)=>$x['pass'])),'total'=>count($checks),'checks'=>$checks];echo json_encode($r,JSON_PRETTY_PRINT|JSON_PARTIAL_OUTPUT_ON_ERROR)."\n";exit($r['passed']===$r['total']?0:1);
