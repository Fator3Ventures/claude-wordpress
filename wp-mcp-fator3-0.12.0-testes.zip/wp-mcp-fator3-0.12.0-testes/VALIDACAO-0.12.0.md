# Validação — WP MCP Fator3 0.12.0

Data: 14/09/2026. Base: pacote Fator3 0.11.0, SHA-256 `9923bab69799c530d493bcc85cc0dde6321fa2c3701f2215bc1c3b5f14ff1d4e`.

Resultado: **890 verificações aprovadas em 30 relatórios de suites**, além da análise de sintaxe dos **111 arquivos PHP de produção**, sem erro. As contagens incluem cenários repetidos em ambientes distintos; não representam 890 funcionalidades diferentes.

## Ambientes

| Ambiente | Uso |
|---|---|
| WordPress 6.9.4, PHP 8.3.6, SQLite | API nativa de abilities, HTTP real, OAuth, interface e regressões |
| WordPress 6.7.4, PHP 8.3.6, SQLite | Polyfill da Abilities API, contratos e lixeira desativada |
| WordPress 6.9.4, PHP 8.3.6, MariaDB 10.11.14 | SQL nativo, transações, pré-imagens e confirmação concorrente |
| Chrome Headless Shell 151.0.7922.34 via Playwright | Fluxos administrativos, cópia, credenciais, teclado, árvore de acessibilidade e capturas |

Os ambientes são descartáveis, isolados do site do usuário. Chamadas externas dos complementos foram bloqueadas no laboratório. Os pacotes Google e Base Site Core não foram alterados.

## Resultados por cenário

| Relatório no arquivo de evidências | Aprovados | Abrangência |
|---|---:|---|
| `unit.json` | 32/32 | Registro compartilhado, namespace, recursos OAuth, persistência e renderização |
| `registry-*.json` — seis relatórios | 6/6 | Registro pendente, servidor desabilitado, configuração customizada, metatool ausente e colisões antes/depois do registro |
| `http.json` | 44/44 | Credenciais e sessão criadas na 0.11.0, atualização, aliases, Basic, OAuth, PKCE, renovação, expiração/revogação, testes simultâneos e escrita concorrente |
| `http-failures.json` | 38/38 | Falhas injetadas via transporte HTTP WordPress: timeout, DNS, TLS, 401/403/404/302, notificação, ferramentas; remoção da senha temporária em cada cenário |
| `topology-http.json` | 73/73 | HTTP real na raiz, subdiretório, prefixo REST filtrado, query REST, rota customizada, servidor desabilitado e colisão; cache ativo |
| `ui.json` | 24/24 | JSON fechado/válido, cópia e recusa, teclado, gerar/revogar/regenerar/recarregar, larguras e ausência de erros JavaScript |
| `coexist.json` | 12/12 | Complementos carregados, discovery, chamadas locais Google/Base e CSS restrito |
| `audit-limits.json` | 4/4 | Cursor cronológico, limite por registro, limite de bytes e limite de arquivos |
| `contracts.json` + `contracts-disabled.json` | 81/81 | Arquivos, hash/backup, conteúdo, lixeira, SQL, opções, planos, idempotência e canal |
| `contracts-wp67-*.json` | 81/81 | Os mesmos contratos com polyfill e lixeira ativada/desativada |
| `contracts-mariadb-*.json` + `mariadb-extra.json` | 91/91 | SQL nativo, dados binários, auto incremento, rollback, triggers/engine recusados, falha de COMMIT e concorrência |
| `advanced.json` | 18/18 | Revisões, blocos, restauração, retenção e contratos adicionais da 0.11 |
| `integration.json` | 105/105 | Suite de integração herdada, com WordPress real |
| `files091.json` | 85/85 | Leitura parcial, filtros e exclusão de plugin |
| `upstream.json` | 10/10 | Regressões herdadas do núcleo, incluindo preservação de barras |
| `delete-post-enabled.json` + `delete-post-disabled.json` | 135/135 | Tipos personalizados, lixeira, vetos e exclusão definitiva explícita |
| `rmdir.json` | 38/38 | Diretórios vazios, links, conteúdo e conflito; filesystem real com stubs WordPress |
| `confine-*.json` — três relatórios | 13/13 | Confinamento e bloqueios de edição/modificações |

## Conexão e compatibilidade

As senhas de aplicação, tokens de acesso/renovação e sessão de compatibilidade foram criados usando o código da 0.11.0, antes de substituir a cópia instalada pelo código 0.12.0. A mesma senha e o mesmo token válido autenticaram pelas URLs antiga e nova. A sessão anterior respondeu por ambos os aliases.

O cliente de protocolo completou consentimento OAuth em página real do WordPress, troca de código com PKCE S256 e acesso ao MCP. A renovação de token legado para o novo recurso passou; reuso de código e recurso externo foram recusados. Senha revogada e token com prazo de armazenamento expirado retornaram HTTP 401 pelas duas URLs.

Os dois endpoints apresentam os mesmos metatools e callbacks. GET mantém o comportamento herdado de SSE não implementado (405). DELETE pela URL antiga encerrou a sessão criada na nova; a chamada seguinte recebeu o erro MCP herdado `-32602`, “Invalid or expired session”. Essa resposta de erro continua usando o envelope HTTP 200 da base; esta versão não redesenha o mapeamento global de erros do transporte.

Chamadas simultâneas de escrita com o mesmo `expected_sha256`, uma por cada endpoint, produziram exatamente um sucesso e um `file_conflict`. Dois testes HTTP administrativos simultâneos concluíram e removeram somente suas próprias senhas temporárias.

## Coexistência

Pacotes efetivamente usados: **WP MCP Google Fator3 0.3.1**, **Base Site Core Fator3 1.8.0**, **WP Super Cache 3.1.3** e **Yoast SEO 28.4**.

O registro preservou as 100 abilities próprias e descobriu os grupos Google Analytics (`ga/`), Google (`google/`), Search Console (`gsc/`), Ads (`ads/`) e Base (`f3base/`). `google/status` e `f3base/config-core-ler` executaram localmente. Isso confirma o acoplamento ao servidor MCP; não valida credenciais ou consultas reais às APIs Google.

Com WP Super Cache ativo, requests autenticados das duas rotas e os metadados OAuth retornaram proteção de cache. Uma chamada anônima posterior continuou recebendo 401, e não foi criado payload de cache para MCP/OAuth. Uma rota ocupada por callback de terceiro não recebeu a identidade de um token Bearer MCP. O CSS Fator3 não foi enfileirado na tela do Yoast.

## Interface e evidências

O pacote de evidências contém capturas das três abas em 375, 768 e 1440 px, JSON expandido/recolhido e layout com escala CSS de 200%. URLs e JSONs não provocaram transbordamento da página. O teste conferiu foco/seleção das abas por teclado, feedback de cópia e a árvore de acessibilidade. Nenhuma captura foi feita com senha de aplicação recém-gerada exposta.

O teste de cópia aguardou a conclusão assíncrona da Clipboard API antes da asserção. Falhas iniciais de preparação do navegador e expectativas incorretas do harness foram corrigidas; os relatórios entregues representam as execuções conclusivas. Em particular, Analytics usa o prefixo `ga/` e a invalidação de sessão mantém o envelope MCP da base.

## Limites da validação

- Não houve instalação, alteração nem teste no WordPress de produção do usuário.
- OAuth foi validado por cliente de protocolo no laboratório. Não houve teste ponta a ponta nas interfaces instaladas de Claude, Cursor ou outros conectores externos.
- Timeout/DNS/TLS foram simulados com `WP_Error` no transporte WordPress; confirmou-se `sslverify=true` e proibição de redirects. Não se realizou ensaio com certificado inválido em uma hospedagem pública real.
- Acessibilidade foi verificada por teclado e árvore do navegador. Não houve ensaio manual com NVDA/VoiceOver. A escala de 200% foi aplicada por CSS, não pelo zoom da interface de um navegador com janela.
- WordPress 6.7.4 e 6.9.4 foram testados em PHP 8.3.6. PHP 8.0 continua sendo o mínimo declarado, mas não foi executado nesta matriz. Multisite, proxy/CDN e todos os servidores web possíveis não foram certificados.
- Os testes de cache se referem ao WP Super Cache no modo PHP do laboratório; a configuração de cache/CDN do site precisa respeitar autenticação e exclusões MCP/OAuth.

O arquivo `manifest.json` nas evidências registra os hashes da árvore distribuída e o resumo dos relatórios. O ZIP instalável tem uma única raiz `wp-mcp-fator3/`; não contém WordPress de teste, senhas, runtimes, banco ou os outros plugins.
