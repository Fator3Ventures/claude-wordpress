# Evidências WP MCP Fator3 0.12.0

Consulte VALIDACAO-0.12.0.md para ambiente, resultados e limites. Este ZIP não deve ser instalado como plugin.

- JSONs: resultados das execuções conclusivas.
- screenshots/: capturas reais do WordPress no navegador, sem senhas expostas.
- manifest.json: hashes do pacote instalável e de cada arquivo, mudanças contra a 0.11.0 e contagens.
- harness/: scripts executados no laboratório; os testes herdados também estão no diretório tests/ do plugin.

## Reprodução

Use somente instalações descartáveis com F3_DELETE_POST_DISPOSABLE_LAB=true, PHP 8.3.6, WordPress 6.9.4/6.7.4 e SQLite ou MariaDB 10.11.14 conforme o relatório. Os scripts mantêm a organização de pastas do laboratório e caminhos dos runtimes: adapte-os à sua máquina antes de executar. Não são um instalador de WordPress ou de dependências.

Para testes herdados, os harnesses contracts.php e advanced.php aceitam F3_TEST_WP_LOAD apontando para wp-load.php. Os testes distribuídos no plugin documentam seus argumentos CLI. Os harnesses novos usam release-012/lab/wordpress, usuário administrador de teste ID 1, WP_ENVIRONMENT_TYPE=local, HTTP local em 127.0.0.1:38012 e quatro workers PHP.

http_regressions.py exige cópias dos pacotes 0.11.0 e 0.12.0 nas pastas build previstas: cria credenciais na base, troca a cópia instalada, executa HTTP/OAuth e remove as credenciais de teste. ui_test.cjs usa Playwright e Chrome Headless Shell 151.0.7922.34; ajuste o caminho do executável e CODEX_PRIMARY_RUNTIME_NODE_MODULES. ui_only.py mantém servidor e navegador no mesmo processo de orquestração.

topology_http.py pressupõe que coexist_setup.php já ativou os quatro complementos descritos no relatório. Seus ZIPs não são redistribuídos aqui. Não configure credenciais reais Google; as verificações dos complementos são locais. native_gate.py pressupõe um laboratório MariaDB inicializado e um segundo WordPress 6.7.4. As bases, runtimes, plugins externos e credenciais temporárias não acompanham este arquivo.

Os testes apagam seus próprios fixtures e podem alterar opções, posts, usuários, plugins e arquivos na instalação descartável. Não executar em produção.
