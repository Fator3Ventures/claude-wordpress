<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$automatic=AutomaticMaintenance::policy();$last=StateStore::get('automation','last');
$previewKey=is_string($_GET['automatic_preview']??null)?sanitize_text_field(wp_unslash($_GET['automatic_preview'])):'';
$preview=preg_match('/^[a-f0-9-]{36}$/D',$previewKey)?get_transient('f3_mcp_notice_'.get_current_user_id().'_'.$previewKey):false;
?>
<section class="f3-section" id="f3-automatic"><h2>Manutenção automática</h2>
<p>O WordPress verifica o acervo a cada 15 minutos, conforme a passagem do cron. Cópias sem dependências e resultados de operações concluídas são elegíveis após o prazo escolhido. Operações pendentes e comprovantes que impedem repetição ficam protegidos.</p>
<?php if (!empty($automatic['invalid'])): ?><p class="f3-callout is-error" role="alert">A política armazenada é inválida. A exclusão está pausada até salvar valores válidos.</p><?php endif; ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<?php Admin::nonce('f3_mcp_automatic_maintenance'); ?>
<input type="hidden" name="action" value="f3_mcp_automatic_maintenance"><input type="hidden" name="revision" value="<?php echo esc_attr(AutomaticMaintenance::revision()); ?>">
<p><input type="hidden" name="enabled" value="0"><label class="f3-check"><input type="checkbox" name="enabled" value="1" <?php checked($automatic['enabled']); ?>> Ativar limpeza automática</label></p>
<div class="f3-grid"><?php foreach ([
'backups_days'=>['Cópias e exportações (dias)',1,3650,'Inclui backups de arquivos, pré-imagens e cópias SQL. O padrão é 1 dia (24 horas).'],
'idempotency_days'=>['Resultados de operações (dias)',1,3650,'Expira o resultado volumoso. Um comprovante mínimo impede executar novamente a mesma chave.'],
'oauth_receipts_days'=>['Comprovantes OAuth vencidos (dias)',1,3650,'Tokens válidos e controles de reutilização de concessões ativas são preservados.'],
'audit_days'=>['Histórico de auditoria (dias)',0,3650,'Zero preserva o histórico. Um valor positivo permite retirar os registros mais antigos.'],
'refresh_notice_days'=>['Avisar antes do vencimento (dias)',1,3650,'O Core recebe um aviso quando a concessão OAuth entra neste prazo sem renovação.'],
'stall_passes'=>['Passagens sem avanço',1,96,'Avise quando a mesma seleção continuar parada por este número de passagens. Padrão: 3.'],
'cron_late_seconds'=>['Tolerância de atraso do cron (segundos)',1,86400,'O Core recebe um aviso quando a próxima passagem da manutenção excede esta tolerância.'],
'agenda_confirmation_seconds'=>['Intervalo para confirmar agenda parada (segundos)',AutomaticMaintenance::minimum('agenda_confirmation_seconds'),AutomaticMaintenance::maximum('agenda_confirmation_seconds'),'O canal abre o incidente após duas requisições distintas encontrarem o marcador ausente. O intervalo padrão entre elas é de 5 minutos.'],
] as $key=>$field): ?><div class="f3-field"><label for="f3-auto-<?php echo esc_attr($key); ?>"><?php echo esc_html($field[0]); ?></label>
<input type="number" required step="1" id="f3-auto-<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>" min="<?php echo (int)$field[1]; ?>" max="<?php echo (int)$field[2]; ?>" value="<?php echo (int)$automatic[$key]; ?>" aria-describedby="f3-auto-help-<?php echo esc_attr($key); ?>">
<?php Admin::help('f3-auto-help-'.$key,$field[3]); ?></div><?php endforeach; ?></div>
<div class="f3-savebar"><button class="button" name="intent" value="preview">Simular estes critérios</button><button class="button button-primary" name="intent" value="save">Salvar política</button></div>
<p class="description">A simulação preserva o acervo. Salvar ativa os critérios para as próximas passagens. Pausar a limpeza mantém os avisos técnicos.</p></form>
<?php if (is_array($preview) && isset($preview['automatic_preview'])): $r=$preview['automatic_preview']; ?>
<h3>Resultado da simulação</h3>
<?php if (empty($r['success'])): ?><p class="f3-callout is-error" role="alert"><?php echo esc_html($r['message']??'Não foi possível concluir a simulação.'); ?></p><?php else: ?>
<?php if (isset($r['policy']['agenda_confirmation_seconds'])): ?><p>Intervalo simulado para confirmar agenda parada: <strong><?php echo (int)$r['policy']['agenda_confirmation_seconds']; ?> segundos</strong>.</p><?php endif; ?>
<ul><?php foreach ($r['categories'] as $key=>$row): $labels=['oauth'=>'OAuth','oauth-tokens'=>'OAuth','idempotency'=>'Resultados de operações','backups'=>'Backups','sql_artifacts'=>'Cópias SQL','audit'=>'Auditoria']; ?><li><?php echo esc_html($labels[$key]??$key); ?>: <?php echo empty($row['success'])?'seleção indisponível':(int)($row['selected']??0).' selecionados'; ?><?php if (!empty($row['protected'])) echo ' · '.(int)$row['protected'].' protegidos'; ?><?php if (!empty($row['has_more'])) echo ' · existem outros lotes'; ?></li><?php endforeach; ?></ul>
<p>Esta simulação usa os critérios enviados. A política só muda ao salvar.</p><?php endif; endif; ?>
<?php
$next = wp_next_scheduled(AutomaticMaintenance::HOOK);
$last_status = $last['status'] ?? '';
$states = [
    'complete' => ['is-ok', 'Lote concluído'],
    'partial' => [!empty($last['stalled']) ? 'is-warn' : 'is-info', !empty($last['stalled']) ? 'Lote sem avanço' : 'Lote em continuação'],
    'paused' => ['', 'Limpeza pausada'],
    'failed' => ['is-error', 'Falha'],
    'invalid_policy' => ['is-error', 'Política inválida'],
    'running' => ['is-info', 'Em execução ou sem confirmação de término'],
];
[$tone, $label] = $states[$last_status] ?? ['is-warn', $last ? 'Estado não reconhecido' : 'Aguardando a primeira passagem'];
?>
<dl class="f3-details">
<dt>Próxima passagem prevista</dt><dd><?php if ($next): ?><span class="f3-pill is-info">Agendada</span> <?php echo esc_html(wp_date('d/m/Y H:i:s', $next)); ?>
<?php else: ?><span class="f3-pill is-warn">Agenda ausente</span><?php endif; ?></dd>
<dt>Última passagem</dt><dd><span class="f3-pill <?php echo esc_attr($tone); ?>"><?php echo esc_html($label); ?></span>
<?php if ($last): echo esc_html(wp_date('d/m/Y H:i:s', $last['finished_at'] ?? $last['started_at'])); endif; ?></dd>
</dl>
<p>Os avisos são entregues pelo e-mail técnico configurado no Fator3 Site Core. Cada emissão ou renovação OAuth concede 90 dias para a próxima renovação. Credenciais anteriores conservam a data gravada; o aviso solicita a ação de quem opera a conexão.</p>
<p><a href="<?php echo esc_url(add_query_arg('document','release-0500',Admin::url('help'))); ?>">Ver regras e diagnóstico da manutenção</a> · <a href="<?php echo esc_url(add_query_arg('document','release-0530',Admin::url('help'))); ?>">Como o canal confirma a ausência da agenda</a></p></section>
