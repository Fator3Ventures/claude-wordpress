<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$url=Admin::url('connections');
?>
<section class="f3-section"><a class="f3-back" href="<?php echo esc_url($url); ?>">← Clientes conectados</a><h2>Escolher conta WordPress</h2><p class="f3-lead">O cliente só poderá executar ações permitidas a esta conta.</p></section>
<section class="f3-section">
<form method="get" action="<?php echo esc_url(admin_url('tools.php')); ?>" class="f3-list-tools">
<input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="tab" value="connections"><input type="hidden" name="mode" value="<?php echo esc_attr($mode); ?>"><input type="hidden" name="choose_user" value="1">
<div class="f3-field"><label for="f3-user-search">Nome ou login</label><input id="f3-user-search" type="search" name="user_search" value="<?php echo esc_attr($user_search); ?>"></div><button class="button">Pesquisar contas</button>
</form>
<?php if(!$users): ?><p class="f3-empty">Nenhuma conta disponível nesta busca.</p><?php else:
    $total = count($users);
    $page = min(max(1, absint($_GET['pg'] ?? 1)), (int) ceil($total / 20));
    $users = array_slice($users, ($page - 1) * 20, 20);
?>
<ul class="f3-link-list"><?php foreach($users as $u): ?><li><a href="<?php echo esc_url(add_query_arg(['mode'=>$mode,'user_id'=>$u->ID],$url)); ?>"><?php echo esc_html($u->display_name.' · '.$u->user_login.' (#'.$u->ID.')'); ?></a></li><?php endforeach; ?></ul>
<?php Admin::pager($url, ['user_search'=>$user_search, 'mode'=>$mode, 'choose_user'=>1], $page, 20, $total); ?>
<p class="description">Até 100 resultados por busca. Refine o nome ou login para localizar outra conta.</p><?php endif; ?>
</section>
