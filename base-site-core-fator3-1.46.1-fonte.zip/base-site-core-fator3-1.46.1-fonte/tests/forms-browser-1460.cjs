const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
(async()=>{
 const c=(await import(process.env.F3BASE_CHROMIUM_PACKAGE)).default;
 const b=await chromium.launch({executablePath:process.env.F3BASE_CHROMIUM,args:c.args});const page=await b.newPage();const errors=[],sends=[];page.on('pageerror',e=>errors.push(e.message));let surface='page',mask=0,tokenFails=false;
 const html=fs.readFileSync(root+'/lab/render146/public-form.html','utf8');
 await page.route('https://fixture.test/**',async route=>{const r=route.request();if(r.url().endsWith('/token'))return tokenFails?route.fulfill({status:503,json:{ok:false}}):route.fulfill({json:{ok:true,token:Buffer.from(JSON.stringify({t:Math.floor(Date.now()/1000)})).toString('base64')+'.signed'}});
  if(/\/(enviar|complementar)$/.test(r.url())){const stage=r.url().endsWith('/complementar')?2:1;sends.push({stage,body:r.postData()});return route.fulfill({json:{ok:true,aceito:!(mask&6),record_id:'a'.repeat(32),etapa_pendente:surface==='stage2'&&stage===1,continuacao:'signed-continuation',revisao:'revision',mensagem:mask&6?'Recebemos seu envio para análise.':'Contato registrado.'}});}
  if(r.url().endsWith('/tentativas'))return route.fulfill({json:{ok:true}});return route.fulfill({contentType:'text/html',body:surface==='dialog'?html.replace('<form','<dialog open><form')+'</dialog>':html});
 });
 let cases=0;
 for(surface of ['page','dialog','content','stage2'])for(let wanted=0;wanted<8;wanted++){
  mask=surface==='stage2'?0:wanted;await page.goto('https://fixture.test/');await page.locator('form').evaluate((f,s)=>{f.dataset.endpoint='https://fixture.test/forms/';if(s!=='stage2')f.querySelector('[data-etapa="2"]')?.remove();if(s==='content')f.dataset.regime='conteudo';f.dataset.whatsappAutomatico='0';},surface);
  await page.evaluate(()=>{window.events=[];['inicio','tentativa','aceito','complemento-aceito','erro'].forEach(n=>document.addEventListener('f3base-formulario-'+n,e=>window.events.push(e.detail)));});await page.addScriptTag({path:root+'/work/plugin/base-site-core-fator3/assets/f3base-formularios.min.js'});
  const iscas=['website','ctodesenvolvimentofator3','comentario'];for(const key of iscas){const field=page.locator('[name="'+key+'"]');assert.equal(await field.getAttribute('tabindex'),'-1');assert(await field.evaluate(e=>e.closest('[aria-hidden="true"]')&&e.getBoundingClientRect().right<0));}
  assert(await page.locator('[name=ctodesenvolvimentofator3]').evaluate(e=>!e.id&&!e.labels.length&&!e.placeholder&&!e.parentElement.textContent.trim()));
  await page.locator('[name="campos[nome]"]').fill('Pessoa QA');await page.locator('[name="campos[email]"]').fill('qa@example.test');
  if(surface==='stage2'){const n=sends.length;await page.locator('[type=submit]').click();await page.waitForFunction(()=>!document.querySelector('[data-etapa="2"]').hidden);assert.equal(sends.length,n+1);mask=wanted;await page.locator('[name="campos[empresa]"]').fill('Empresa QA');}
  for(let n=0;n<3;n++)await page.locator('[name="'+iscas[n]+'"]').evaluate((e,value)=>{e.value=value;},wanted&(1<<n)?'private-browser-'+iscas[n]:'');
  const n=sends.length;await page.locator('[type=submit]').click();await page.waitForFunction(()=>!document.querySelector('form').hasAttribute('aria-busy'));assert.equal(sends.length,n+1,surface+'/'+wanted);
  for(let n=0;n<3;n++)assert.equal(sends.at(-1).body.includes('private-browser-'+iscas[n]),!!(wanted&(1<<n)));
  assert(!(await page.evaluate(()=>JSON.stringify(window.events))).includes('private-browser'));cases++;
 }
 surface='page';mask=0;tokenFails=true;await page.goto('https://fixture.test/');await page.locator('form').evaluate(f=>{f.dataset.endpoint='https://fixture.test/forms/';f.querySelector('[data-etapa="2"]').remove();});await page.addScriptTag({path:root+'/work/plugin/base-site-core-fator3/assets/f3base-formularios.min.js'});await page.locator('[name="campos[nome]"]').fill('Pessoa QA');await page.locator('[name="campos[email]"]').fill('qa@example.test');const n=sends.length;await page.locator('[type=submit]').click();await page.waitForFunction(()=>!document.querySelector('form').hasAttribute('aria-busy'));assert.equal(sends.length,n+1,'token renewal failure still submits');cases++;
 assert.deepEqual(errors,[]);fs.writeFileSync(root+'/evidence/forms-browser-1460.json',JSON.stringify({version:'1.46.0',engine:await b.version(),cases,forms:['page','dialog','content','stage2'],assertions:'isca markup/offscreen; 8 combinations each; multipart values; no values in events; failed token renewal submits',errors,limite:'Desktop Chromium; not Android autofill or Kwai WebView'},null,2));await b.close();console.log(cases+' browser form cases OK');
})().catch(e=>{console.error(e);process.exit(1)});
