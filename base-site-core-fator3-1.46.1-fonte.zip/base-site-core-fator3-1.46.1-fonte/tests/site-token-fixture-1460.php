<?php
/** Temporary, fixed Site-Teste fixture for the owner's 25h no-JS acceptance. */
if (!defined('ABSPATH')) { exit; }
add_action('f3base_qa146_token', static function () {
    if (!wp_doing_cron() || wp_parse_url(home_url('/'), PHP_URL_HOST) !== 'fator3-teste-mcp-1.dreamhosters.com') { return; }
    $form = F3Base_Formularios::obter('qa146-pagina');
    if (!$form) { return; }
    $d = array('f'=>$form['id'], 'r'=>F3Base_Formularios::revisao($form), 'p'=>14, 't'=>time()-25*HOUR_IN_SECONDS, 'interacao'=>true);
    $raw=base64_encode(wp_json_encode($d));
    file_put_contents(WP_CONTENT_DIR.'/f3-core-state/qa146-old-token.json', wp_json_encode(array('token'=>$raw.'.'.hash_hmac('sha256','formulario|'.$raw,wp_salt('nonce')), 'issued_at'=>$d['t'], 'age_hours'=>25)), LOCK_EX);
});
