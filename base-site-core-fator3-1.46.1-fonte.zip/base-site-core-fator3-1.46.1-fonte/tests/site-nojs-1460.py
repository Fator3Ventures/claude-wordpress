"""Authorized synthetic no-JS form probe on Site-Teste; all test destinations suppressed."""
from pathlib import Path
import json, os, sys, urllib.request, urllib.parse, uuid
origin=os.environ['F3BASE_QA_ORIGIN'].rstrip('/')
assert origin=='https://fator3-teste-mcp-1.dreamhosters.com'
headers={'Content-Type':'application/x-www-form-urlencoded','X-F3Base-Teste':'1','Origin':origin,'Referer':origin+'/','User-Agent':'F3Base-QA/1.46.0'}
def request(path,data):return urllib.request.Request(origin+path,urllib.parse.urlencode(data).encode(),headers,method='POST')
aged=len(sys.argv)>1 and sys.argv[1]=='25h'
sub=uuid.uuid4().hex
if aged:
 t=json.loads(Path(os.environ['F3BASE_QA_OLD_TOKEN']).read_text()); assert t['age_hours']==25
else:
 with urllib.request.urlopen(request('/wp-json/f3base/v1/formularios/token',{'formulario':'qa146-pagina','pagina':14,'submissao':sub}),timeout=30) as r:t=json.load(r)
 assert t['ok']
redirects=[]
class Redirects(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  redirects.append(code)
  return super().redirect_request(req,fp,code,msg,headers,newurl)
opener=urllib.request.build_opener(Redirects())
data={'action':'f3base_formulario','formulario':'qa146-pagina','submissao':sub,'token':t['token']+('' if aged else 'x'),'campos[nome]':'QA Core 146 sem JS','campos[email]':'qa146-aged@example.test' if aged else 'qa146-nojs@example.test','contexto_teste':'1'}
with opener.open(request('/wp-admin/admin-post.php',data),timeout=30) as r:status=r.status;body=r.read().decode()
result={'http_final':status,'redirect_status':redirects,'confirmation': ('Seu contato foi registrado.' in body if aged else 'Recebemos seu envio para análise.' in body),'no_whatsapp':'wa.me/' not in body,'case':'Token de 25h válido, POST HTML sem JavaScript' if aged else 'Token adulterado, POST HTML sem JavaScript, dados sintéticos de homologação'}
(Path(__file__).resolve().parents[1]/('evidence/site-aged-1460.json' if aged else 'evidence/site-nojs-1460.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False))
assert status==200 and 303 in redirects and result['confirmation'] and result['no_whatsapp'],result
print(json.dumps(result,ensure_ascii=False))
