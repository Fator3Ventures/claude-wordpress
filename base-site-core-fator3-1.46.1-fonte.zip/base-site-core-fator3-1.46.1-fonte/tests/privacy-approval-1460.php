<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$role=get_role('administrator');$role->add_cap('f3base_ler_leads');$role->add_cap('f3base_gerir_leads');
add_filter('pre_http_request',static fn()=>new WP_Error('fixture_no_network'),999);
add_filter('pre_wp_mail',static fn()=>true,999);
$page=wp_insert_post(array('post_title'=>'QA 146 privacy','post_type'=>'page','post_status'=>'publish'));$_SERVER['HTTP_REFERER']=get_permalink($page);
$form=array('id'=>'qa146private','titulo'=>'QA 146 private','ligado'=>true,'regime'=>'registro','pipedrive'=>true,'campos'=>array(array('nome'=>'nome','rotulo'=>'Nome','tipo'=>'text','papel'=>'nome','obrigatorio'=>true),array('nome'=>'email','rotulo'=>'Email','tipo'=>'email','papel'=>'email','obrigatorio'=>true),array('nome'=>'empresa','rotulo'=>'Empresa','tipo'=>'text','papel'=>'empresa','etapa'=>2)),'resposta_visitante'=>array('ativa'=>false));
$snap=array();foreach(array('f3base_formularios','f3base_pipedrive','f3base_pipedrive_token','f3base_pipedrive_estado','f3base_avisos','f3base_email_novo_lead',F3Base_Formulario_Tentativas::OPTION) as $n){$snap[$n]=get_option($n);}
raw('f3base_formularios',array($form));$form=F3Base_Formularios::obter($form['id']);$crm=F3Base_Options::ler('f3base_pipedrive');$crm['ativo']=true;$crm['dominio']='fixture146.pipedrive.com';$crm['homologacao']=true;raw('f3base_pipedrive',$crm);raw('f3base_pipedrive_token',F3Base_Segredos::cifrar('f3base_pipedrive_token','synthetic146'));
raw('f3base_pipedrive_estado',F3Base_Integracoes::revisoes('f3base_pipedrive','f3base_pipedrive_token')+array('estado'=>'verificado','dominio'=>$crm['dominio'],'conta_id'=>'146','instalacao'=>'qa','usuario_id'=>7));
$notice=F3Base_Options::ler('f3base_avisos');$notice['canal']='slack';raw('f3base_avisos',$notice);$mail=F3Base_Options::ler('f3base_email_novo_lead');$mail['ativo']=true;raw('f3base_email_novo_lead',$mail);
$privacy=F3Base_Options::ler(F3Base_Formulario_Tentativas::OPTION);$privacy['capturar_valores']=true;raw(F3Base_Formulario_Tentativas::OPTION,$privacy);
$ids=array();$input=static function()use(&$form,$page){return array('formulario'=>$form['id'],'token'=>F3Base_Formularios::emitir($form,'',$page,true),'submissao'=>bin2hex(random_bytes(16)),'campos'=>array('nome'=>'Pessoa QA','email'=>'qa@example.test'),'contexto_teste'=>true);};
for($mask=0;$mask<8;$mask++){
 $wpdb->query("DELETE FROM ".F3Base_Leads_Repositorio::tabela('leads_janelas')." WHERE chave LIKE 'form:%'");wp_set_current_user(0);$first=F3Base_Formularios::receber($input());check(!empty($first['aceito']),'277_stage2_initial_'.$mask);$ids[]=$first['record_id'];
 $e=array('formulario'=>$form['id'],'revisao'=>$first['revisao'],'continuacao'=>$first['continuacao'],'submissao'=>bin2hex(random_bytes(16)),'campos'=>array('empresa'=>'Empresa QA'));
 foreach(F3Base_Formulario_Antispam::ISCAS as $n=>$key){$e[$key]=$mask&(1<<$n)?'private-sentinel-'.$key:'';}
 if($mask===0){$form['titulo']='Revisão nova compatível';raw('f3base_formularios',array($form));$form=F3Base_Formularios::obter($form['id']);}
 $r=F3Base_Formulario_Complementos::receber($e);check(!empty($r['persisted'])&&$r['aceito']===!(bool)($mask&6),'277_stage2_combination_'.$mask);$lead=F3Base_Leads_Repositorio::obter($first['record_id']);
 if($mask===0){check(in_array('token_revisao_anterior',$lead['dados']['sinais'],true),'281_stage2_current_validation');}
 check(F3Base_Formulario_Antispam::privado($lead)===array(),'277_private_denied_anonymous_'.$mask);wp_set_current_user(1);
 if($mask){$private=F3Base_Formulario_Antispam::privado($lead);check(count($private[0]['campos'])===substr_count(decbin($mask),'1'),'277_stage2_private_'.$mask);$a=F3Base_Contato_Comunicacao::preparar($lead,false);check(!str_contains(wp_json_encode($a),'private-sentinel'),'277_no_private_in_presentation_'.$mask);}
 if($mask&6){
  $q=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s',F3Base_Pipedrive_Fila::tabela(),$lead['record_id']),ARRAY_A);check($q['estado']==='cancelado','279_stage2_queue_stopped_'.$mask);
  $approve=array('record_id'=>$lead['record_id'],'revisao_esperada'=>(int)$lead['revisao'],'alteracoes'=>array('captura'=>'aceito'),'entregar'=>false,'simular'=>false);$r=F3Base_Leads_Repositorio::atualizar($approve);check($r['persisted']&&!$r['entrega']['solicitar_entrega'],'279_approve_without_delivery_'.$mask);
  $lead=F3Base_Leads_Repositorio::obter($lead['record_id']);$approve['revisao_esperada']=(int)$lead['revisao'];$approve['entregar']=true;$r=F3Base_Leads_Repositorio::atualizar($approve);check($r['persisted']&&$r['entrega']['solicitar_entrega'],'279_later_delivery_'.$mask);
  $q=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s',F3Base_Pipedrive_Fila::tabela(),$lead['record_id']),ARRAY_A);check($q['estado']==='pendente'&&$q['codigo']==='aprovacao_confirmada','279_cancelled_queue_resumed_'.$mask);
  F3Base_Pipedrive_Fila::reconciliar_intencoes();check((int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE record_id=%s',F3Base_Pipedrive_Fila::tabela(),$lead['record_id']))===1,'279_one_crm_intent_'.$mask);
  $lead=F3Base_Leads_Repositorio::obter($lead['record_id']);$job=array('conta'=>$q['conta'],'journal'=>array('oportunidade'=>array('id'=>sprintf('00000000-0000-0000-0000-%012d',$mask),'tipo'=>'lead','nova'=>true),'nucleo_confirmado_em'=>time(),'pessoa'=>42));
  check(!F3Base_Email_Novo_Lead::elegivel($lead,$job),'279_test_still_requires_homologation_'.$mask);
  // Synthetic production-shaped record; network and mail are intercepted above.
  $normal=$lead;$normal['classe_trafego']='nao_marcado';unset($normal['dados']['contexto_teste']);check(F3Base_Email_Novo_Lead::elegivel($normal,$job),'279_email_after_crm_confirmation_'.$mask);
  check(F3Base_Email_Novo_Lead::enfileirar($normal,$job,array('nome'=>'Pessoa QA','email'=>'qa@example.test'),array()),'279_email_queue_'.$mask);F3Base_Email_Novo_Lead::enfileirar($normal,$job,array('nome'=>'Pessoa QA'),array());
  check((int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE record_id=%s',F3Base_Email_Novo_Lead::tabela(),$lead['record_id']))===1,'279_email_once_'.$mask);
 }
}
$privacy['capturar_valores']=false;raw(F3Base_Formulario_Tentativas::OPTION,$privacy);$iscas=F3Base_Formulario_Antispam::iscas(array('comentario'=>'private-sentinel'),array());check($iscas['iscas']['valores']===null&&$iscas['suspeito'],'277_switch_metadata_only');
$lead=F3Base_Leads_Repositorio::obter(end($ids));$lead['dados']['iscas_privadas'][0]['em']=F3Base_Retencao_Prazos::corte(F3Base_Formulario_Tentativas::OPTION)-1;$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($lead['dados'])),array('record_id'=>$lead['record_id']));check(F3Base_Formulario_Antispam::privado($lead)===array(),'277_expired_unreadable');F3Base_Formulario_Antispam::limpar();check(empty(F3Base_Leads_Repositorio::obter($lead['record_id'])['dados']['iscas_privadas']),'277_expired_removed');
$role->remove_cap('f3base_ler_leads');wp_set_current_user(0);wp_set_current_user(1);check(F3Base_Formulario_Antispam::privado(F3Base_Leads_Repositorio::obter($ids[1]))===array(),'277_manage_options_does_not_bypass_lead_cap');$role->add_cap('f3base_ler_leads');wp_set_current_user(0);wp_set_current_user(1);
foreach($ids as $id){check(F3Base_Leads_Repositorio::eliminar($id,'teste'),'277_privacy_delete_'.$id);check(!F3Base_Leads_Repositorio::obter($id),'277_private_deleted_'.$id);$wpdb->delete(F3Base_Pipedrive_Fila::tabela(),array('record_id'=>$id));$wpdb->delete(F3Base_Email_Novo_Lead::tabela(),array('record_id'=>$id));}
foreach($snap as $n=>$value){raw($n,$value);}wp_delete_post($page,true);evidence('privacy-approval-1460');
