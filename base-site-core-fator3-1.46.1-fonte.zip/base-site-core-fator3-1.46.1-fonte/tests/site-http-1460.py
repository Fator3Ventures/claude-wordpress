"""Explicit Site-Teste probes. Configure temporary forms and suppress test destinations first."""
from pathlib import Path
import os,sys,json,urllib.request,urllib.error,urllib.parse,uuid,time
origin=os.environ['F3BASE_QA_ORIGIN'].rstrip('/')
assert origin=='https://fator3-teste-mcp-1.dreamhosters.com'
root=Path(__file__).resolve().parents[1];out=root/'evidence/site-http-1460.json'
results=json.loads(out.read_text()) if out.exists() else []
headers={'Content-Type':'application/x-www-form-urlencoded','X-F3Base-Teste':'1','Referer':origin+'/','Origin':origin,'User-Agent':'F3Base-QA/1.46.0'}
def post(path,data):
 flat={}
 for k,v in data.items():
  if isinstance(v,dict):flat.update({k+'['+kk+']':vv for kk,vv in v.items()})
  else:flat[k]=('1' if v else '0') if isinstance(v,bool) else v
 req=urllib.request.Request(origin+path,urllib.parse.urlencode(flat).encode(),headers,method='POST')
 try:
  with urllib.request.urlopen(req,timeout=25) as r:return r.status,json.load(r)
 except urllib.error.HTTPError as e:return e.code,json.load(e)
phase=sys.argv[1]
surfaces={'1':['pagina','dialogo'],'2':['conteudo'],'3':['etapa2']}[phase]
for surface in surfaces:
 for mask in range(8):
  if any(x['surface']==surface and x['mask']==mask for x in results):continue
  form='qa146-'+surface;sub=uuid.uuid4().hex
  http,t=post('/wp-json/f3base/v1/formularios/token',{'formulario':form,'pagina':14,'submissao':sub});assert http==200 and t.get('ok'),(http,t)
  payload={'formulario':form,'token':t['token'],'submissao':sub,'campos':{'nome':'QA Core 146','email':'qa146@example.test'},'contexto_teste':True}
  values={key:'private-qa146-'+key if mask&(1<<n) else '' for n,key in enumerate(['website','ctodesenvolvimentofator3','comentario'])}
  if surface!='etapa2':payload.update(values)
  http,r=post('/wp-json/f3base/v1/formularios/enviar',payload)
  if r.get('record_id'):
   row={'surface':surface,'mask':mask,'record_id':r['record_id'],'first_http':http,'first_accepted':r.get('aceito'),'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'expected':not bool(mask&6),'completed':False};results.append(row);out.write_text(json.dumps(results,indent=2))
  assert r.get('persisted'),(http,r)
  if surface=='etapa2':
   assert r.get('aceito') and r.get('etapa_pendente'),r
   p={'formulario':form,'revisao':r['revisao'],'continuacao':r['continuacao'],'submissao':uuid.uuid4().hex,'campos':{'empresa':'QA Empresa 146'},**values}
   http,r=post('/wp-json/f3base/v1/formularios/complementar',p)
  row.update(http=http,accepted=r.get('aceito'),private_not_in_response='private-qa146' not in json.dumps(r),completed=bool(r.get('persisted')) and r.get('aceito')==row['expected'])
  out.write_text(json.dumps(results,indent=2));assert row['completed'] and row['private_not_in_response'],(surface,mask,http,r)
  print(surface,mask,http,'accepted' if r['aceito'] else 'suspect',flush=True)
print('phase',phase,'OK',flush=True)
