# Fator3 Site Core 1.46.1 — fonte

Runtime em work/plugin/base-site-core-fator3. Build e provas em build/README.md. Instalador separado; este ZIP não é instalável. Base direta 1.46.0. Evidências 1460 herdadas não representam reexecução no patch. Relatório atual na raiz; relatório/impacto da base em history/1.46.0.
