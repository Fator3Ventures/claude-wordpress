# Entrega — Fator3 Site Core 1.46.0

Revisão 2 · 22/10/2026 · implementação dos pedidos core 274–283 · **com-pendencias**. Funcionalidades implementadas e verificadas no escopo descrito; a homologação de fornecedores, dispositivos físicos e observação longitudinal permanece separada. Contrato administrativo 8.11.0; esquema estrutural do banco permanece 1.45.0. Horários operacionais do site em America/Sao_Paulo.

## 1. De onde a versão entra

Instalação limpa ou atualização direta de **1.45.0 para 1.46.0**, sem versão intermediária. Base: instalador 1.45.0, 2.152.375 bytes, SHA-256 `91620d8baadfd42911d624880838879501c722d20d37ecd734213541f920dc06`; fonte-base conferido, SHA-256 `c1b6bed0f6be31e45e7f41cd513b70fa03656d9013af8929443b6249f8577f18`.

Escopo recebido em Fator3 Site Core(20261022-050032).md: itens 274–282, com os acréscimos posteriores sobre tokens, iscas, aprovação e cache, e pedido adicional 283 recebido neste chat em 22/10. O pedido 263 e as correções das versões anteriores foram preservados. Não houve publicação no GitHub, implantação na frota nem alteração dos pedidos centrais.

## 2. Convivência

Site-Teste: WordPress 7.1.3, PHP 8.3.36, MySQL 8.0.41; Core 1.46.0 com MCP 0.25.0, Google 0.16.0, Meta 0.4.1, LinkedIn 0.4.1, WP Super Cache 3.1.4 e Yoast 28.7. Compatibilidade de transporte/catálogo e funcionamento local verificados; isso não prova autorização ou entrega real nas contas dos fornecedores. Não há mudança nova requerida do MCP Google nesta rodada.

Impacto pertinente: **implantador-base**, `acao-necessaria`, aberto ao destinatário. Arquivo `base-site-core-fator3-1.46.0-impacto-implantador-base.md`, revisão 2, emitido desde o planejamento e atualizado com comportamento e hashes. Abrange perfil mensal, escrita com cache agendado, cópias de formulários e dependência nova de antispam. Implantador 2.10.0 identificado pelo encaminhamento anterior; seu código/fallback não foi homologado nesta rodada. Documento preparado para o dono, sem envio a terceiros.

## 3. Mudanças e evidência

| Pedido | Resultado implementado | Evidência e limite |
|---|---|---|
| core 274 | Perfil piso-padrao-3.6, 92 condições, prazos mensais de 60 e operações concluídas de seis; históricos preservados. | `validado-localmente`, `validado-wordpress`: chaves/valores e perfil remoto com 92 verificações, 91 conformes, zero divergentes e P53 indeterminada por uso/contexto não confirmado. Não houve aplicação em massa. |
| core 275 | Persistência com cache_agendado retorna sucesso e conserva verificação pendente. Falha real continua falha. | `validado-wordpress`: gravação temporária de formulários retornou ok/success/persisted true, efeito cache_agendado, verification pending; restauração ao final. |
| core 276 | Eliminação relê seguidores; permite somente responsável/usuário verificado da credencial. Explica contagens e nomes dos campos que impedem apagar. Falha temporária aguarda. | `validado-localmente`: 19 verificações de exclusão com API simulada, incluindo seguidores permitidos/outro usuário, edição material, compartilhamento e prova antiga. `pendente`: conta real CTO/Korvena após implantação autorizada. |
| core 277 | Três iscas; website isolada aceita. Novas iscas tornam suspeito salvo. Valores cifrados, leitura com f3base_ler_leads, interruptor/retencão configuráveis, limpeza e eliminação; fora das apresentações externas. | `validado-localmente`, `validado-wordpress`: 8 combinações por superfície e segunda etapa; leitura privada e ausência na resposta pública. Chromium prova marcação/offscreen e multipart; não prova autofill Android/Kwai. Conteúdo privado do teste usa referência sintética indisponível: testa captura, não download de material. |
| core 278 | Nota inclui até cinco sessões anteriores, data/hora local, primeira página e canal/parceiro, sem parâmetros de clique ou identificadores técnicos nessa seção. | `validado-localmente`: limite, ordenação, ausência de histórico e remoção de query/identificadores; `pendente`: roteiro real de duas sessões em CTO com homologação. |
| core 279 | Suspeito com nome/contato válido cria intenção de aviso com motivo e link. Aprovação na tela/ability oferece entregar, simulação, auditoria e idempotência; retoma fila interrompida pela segunda etapa. | `validado-localmente`: aprovação sem entrega, entrega posterior, uma fila CRM, uma intenção de e-mail após confirmação de novo lead e proteções de teste. `validado-wordpress`: leitura/alteração pelo MCP. `pendente`: Slack ≤2 minutos, CRM e SMTP reais. Conversões históricas não são reenviadas. |
| core 280 | Projeção da fila troca identificadores por presença/HMAC; valores preservados só no banco para seleção/reconciliação. | `validado-localmente`: nenhuma exposição de e-mail/telefone/LinkedIn na projeção testada. `pendente`: releitura da fila de Korvena após troca. |
| core 281 | Token vencido válido, inclusive 25h, aceito com marca; revisão antiga valida campos atuais. Assinatura ausente/adulterada salva suspeito. Tempo não confiável; falha de renovação JS não bloqueia submissão. Reaquecimento anônimo opcional, teto horário e leitura de resultados. | `validado-localmente`: token 25h, revisão, assinatura, ausência, tempo, origem/cota e 11 verificações do reaquecimento. `validado-wordpress`: nova opção desligada, ability disponível e POST sem JavaScript com token válido de 25h aceito com marca; adulterado salvo suspeito. `pendente`: cache real reaquecido em Korvena.net; piloto 86400/14 dias da frota. |
| core 282 | Simular nunca chama executor, inclusive reativação. Resposta de estado próprio nomeia ação. Espera esgotada coberta por sucesso posterior pode ser encerrada com revisão, sem executar módulo. | `validado-localmente`: intenção esgotada real no WordPress descartável e comparação integral de estado/cron/intenções; conflito/ação explícita/encerramento. Site-Teste não tinha espera esgotada. `pendente`: ação documentada sobre a espera de fator3.com.br. |

| core 283 | Segue 301/302 HTTPS no mesmo host ou equivalentes Perplexity .com/.ai, preserva diagnóstico do destino recusado/HTTP/transporte e retenta fontes ausentes/falhas em lotes com recuo e continuação explícitos. | `validado-localmente`: 73 verificações, incluindo todas as 15 fontes e nova passagem diária. `validado-wordpress` e `fornecedor-real`: as duas fontes saíram de sem_lista para atual no Site-Teste via 302 → 200 real, com obtenção/validade. `pendente`: atualização autorizada de fator3.com.br e releitura após a passagem das 02:00. |

Sem CAPTCHA. Suspeito recebe confirmação de análise e não abre WhatsApp/libera conteúdo. Retenção das iscas segue f3base_formulario_tentativas.retencao_meses, padrão de 60 meses conforme decisão posterior da frota; conserva configuração existente. Desligar capturar_valores conserva metadados de classificação. Nome/campos atuais, arquivos e origem cruzada continuam validados.

O e-mail automático depende de configuração ativa e novo lead confirmado no CRM; testes continuam exigindo homologacao no CRM, caixa autorizada e email-novo-lead-homologar. Aprovação não contorna essas condições. Uma etapa suspeita não desfaz entrega comercial que já tenha ocorrido antes de seu recebimento.

## 4. Instalação e prova de prontidão

Laboratório: PHP 8.3.6, WordPress 7.1.3, MySQL 8.0.36. **605 verificações PHP**, lint de **228 arquivos PHP**, **33 casos de formulários em Chromium 153** e **26 verificações das telas de configuração**. Os provedores locais são simulados. Instalação nova e atualização direta pelo Plugin_Upgrader passaram usando exatamente o ZIP final da tabela de identidade; preservação de dados, opções, segredos, callback e repetição idempotente conferidas. A espera de finalização foi acelerada somente no estado descartável.

Site-Teste: backup privado do banco após preparar/drenar o Core, sem baixar o conteúdo sensível; a geração operacional foi retomada de 3 para 4. Backup 20.755.641 bytes, SHA-256 `c3b71ce3163304663febf52b3a15ea66d2d85c4cded7e70f75c54cc1d9f6bc4a`. O canal preservou também a pré-imagem dos arquivos. O backup é do Core pausado; os demais pacotes têm seus próprios fluxos de recuperação.

Troca por `files/upload-create`, nove partes de 256 KiB e `files/upload-finalize`, seguida de `plugins/upload-base64` com expected_slug=base-site-core-fator3, expected_sha256 da entrega, overwrite=true, activate=true e probe_timeout_seconds=30. Operação final de pacote `c4944d07388f71663ee1e7466d227d4a`: applied=true, versão 1.46.0 ativa e sondas anônimas de home/REST aprovadas antes/depois. Os candidatos privados receberam ajuste da descrição do perfil 3.6 e o pedido adicional 283 antes do fechamento. O ZIP final foi novamente instalado e repetiu os dois ciclos nativos. Nenhum candidato foi publicado como entrega.

Prontidão: `f3base/saude-ler` confirma versão 1.46.0, 18 etapas concluídas, zero falhas e Core operacional. Sonda HTTP por si só não comprova CRM/SMTP; os envios abaixo são prova adicional do domínio.

No Site-Teste foram enviados 32 contatos sintéticos: oito combinações de iscas em cada formulário de página, diálogo, conteúdo fechado e etapa 2. A leitura administrativa confirmou todos os valores privados esperados; as respostas públicas não continham esses valores. Os seis casos com as novas iscas em cada superfície foram suspeitos; vazio/website isolada foram aceitos. Conteúdo fechado usou referência sintética indisponível para testar captura, sem declarar download homologado.

Dois POSTs HTML sem JavaScript completaram HTTP 303 → 200: token adulterado salvou suspeito e mostrou confirmação de análise; token assinado de 25 horas salvou aceito com token_vencido. Ambos marcaram tempo não confiável. Um fixture de cron restrito ao Site-Teste produziu a assinatura antiga sem expor o segredo; arquivo, saída temporária e evento foram removidos após a prova. O token antigo não integra os artefatos.

A aprovação de um suspeito sintético por ability gravou auditoria e primeira intenção de entrega. Repetição com revisão atual devolveu ja_solicitada=true e solicitar_entrega=false. Pipedrive estava inativo e os destinos de teste foram suprimidos: não houve entrega real a fornecedor, e o teste não declara essa homologação.

Pedido 283: em 22/10/2026 às 03:02:24 −03, a coleta real das duas fontes seguiu 302 de www.perplexity.com para www.perplexity.ai e recebeu HTTP 200. PerplexityBot e Perplexity-User passaram de sem_lista para atual, obtida_em=1792648944 e valida_ate=1793253744. A cadeia ficou registrada em ultima_tentativa. Próxima recorrência diária preservada: 23/10 às 02:00 −03. A execução de teste foi uma ocorrência avulsa autorizada; a confirmação do ciclo diário em fator3.com.br continua com a frota.

Estado final: os **34 registros sintéticos foram eliminados pelo fluxo do Core**, sem pendência de exclusão local. Releitura dos quatro IDs de formulário retornou zero registros. As duas definições originais e a política de testes voltaram às revisões anteriores: formulários 9be7a8f66d346151ace10ac902c06824c1497e0f85e9c9f8d3d79d04ccb161bd e testes f256cac4bff8468b25c23b893666d705e6df0bccba3ce115af13aec64bd909bf. Nenhuma página remota foi criada. Core 1.46.0 ativo, geração 4 operacional, migração/finalização concluídas, zero esperas; reaquecimento desligado e TTL/preload preservados.

Documentação por MCP: leitura integral de `docs/RELEASE-1.46.0.md` e `docs/AGENTES-1.46.0.md` por `f3base/documentacao-ler`, com proxima_linha=null e hashes idênticos aos arquivos instalados. Schema 8.11.0 conferido pelo cabeçalho e hash do arquivo; descrição do perfil 3.6 conferida no catálogo atual. Hashes: release `b8580775058280a58299a46c55e3d595e02d567c8389ead38f7ce0f1314bdc1a`; agentes `fc057e28686753879cc9b0b1666b47a32fb1efd715ba14d8e860edbbbe850ded`; schema `8726de2564bcff9ea8ce6044e76c4aaba69a4afc7fcec0b8489a516b7f259e28`.

Para nova troca: faça backup coerente, preserve a guarda operacional, confira o SHA, instale pelo canal nativo e releia saúde/documentação. Reaquecimento vem desligado; o pacote não muda cache_max_time nem ativa preload. A frota aplica a decisão de 86400 e o piloto explicitamente.

## 5. Banco e volta de versão

Nenhuma tabela/coluna nova. Acrescenta opções de configuração/estado do reaquecimento; dados.iscas_privadas cifrados, sinais e auditoria de aprovação no contato; hashes por campo e diagnósticos no journal CRM. As intenções continuam duráveis e idempotentes. Limpeza remove valores expirados em lotes; pedido do titular/eliminação do registro remove os dados privados. Fluxo do pedido 263 mantém exclusão das tentativas da sessão.

Desativação remove o cron de reaquecimento. A recuperação do Core mantém os seus bloqueios e reconciliação. Para retorno à 1.45.0, pause as operações, restaure banco e arquivos coerentes e reconcilie efeitos externos antes de retomar. Substituir somente PHP não desfaz banco, mensagens ou CRM; nunca reenvie estado incerto automaticamente. Guarde o backup no ambiente privado do site.

## 6. Pendências de validação

- Frota/CTO/Korvena: exclusão CRM real com seguidores automáticos, nota de visita anterior, aprovação com entrega real, e-mail automático e aviso Slack em até dois minutos; Site-Teste não possui Pipedrive ativo e os destinos de teste foram suprimidos. Não foram aprovados contatos reais antigos.
- Frota/Android: autofill no Chrome Android e WebView do Kwai; não há dispositivo físico conectado. Medir os 14 dias posteriores à implantação, sem transformar fixture em observação real.
- Frota/cache: habilitar piloto de reaquecimento e TTL 86400 nos dois sites decididos, conferir artefato gerado/servido e ausência de novos eventos/robôs. Cache real da frota não foi alterado por este pacote.
- Frota/redes oficiais: implantar em fator3.com.br e conferir PerplexityBot/Perplexity-User após a primeira passagem diária das 02:00 e continuações. Site-Teste comprovou o redirecionamento real em 22/10 às 03:02:24 −03, sem alteração da frota. Nuvens entram na mesma fila; não são desativadas por desenho.
- Frota/operações: executar reconciliação documentada da espera esgotada de fator3.com.br. Site-Teste estava sem esgotadas; o caso foi exercitado no WordPress local descartável.
- Runtime: PHP mínimo 8.3.6 exercitado; cabeçalho conserva WordPress mínimo 7.1.2 da base, mas esta rodada executou 7.1.3. Não declara uma nova prova de 7.1.2 nem suporte a multisite.
- Implantador: conferir cópias e homologar o fallback conforme o impacto. Não bloqueia a implementação própria do Core.

## 7. Credenciais

Nenhuma credencial nova. Pipedrive continua usando `f3base_pipedrive_token`, domínio/usuário verificados e os mapeamentos existentes em Conexões. Slack usa `f3base_slack_bot_token` ou webhook já configurado. E-mail automático usa `f3base_email_novo_lead_smtp_senha`, remetente/SMTP, cota e caixas de homologação existentes. Este relatório não contém valores secretos; o dono não precisa preencher segredo para usar as mudanças locais de formulários/privacidade/perfil.

## 8. Identidade dos arquivos

| Arquivo final | Bytes | SHA-256 |
|---|---:|---|
| base-site-core-fator3-1.46.0-instalador.zip | 2175518 | b6de147c8e900c2cb9367bafb2dad6494372bbd81953c44b5e4d4990f8f34ad6 |
| base-site-core-fator3-1.46.0-fonte.zip | 3175636 | c213a8a7a8657ed188c0148dd4014942d45be67851adf15a5aa4db653e95aef0 |

[Instalador](base-site-core-fator3-1.46.0-instalador.zip) · [Fonte](base-site-core-fator3-1.46.0-fonte.zip) · [Impacto Implantador](base-site-core-fator3-1.46.0-impacto-implantador-base.md).

Instalador: raiz única base-site-core-fator3/, sem laboratório/testes/runtimes. Fonte: código, build, testes, evidências saneadas, documentação e cópia do relatório **anterior ao fechamento do fonte**; nessa cópia, tamanho/hash do próprio ZIP ficam a preencher no relatório externo. Esta é a versão externa canônica, completada após empacotar, sem reabrir o fonte e criar dependência circular. Arquivos internos não incluem bancos, credenciais, cookies, screenshots ou ZIPs aninhados.
