# Impacto — Core 1.46.0 para Fator3 Implantador

Revisão 2 · 22/10/2026 · Etapa entrega · aberto para o destinatário · acao-necessaria

Emissor base-site-core-fator3, base direta 1.45.0, alvo 1.46.0 entregue. Instalador base-site-core-fator3-1.46.0-instalador.zip, 2175518 bytes, SHA-256 `b6de147c8e900c2cb9367bafb2dad6494372bbd81953c44b5e4d4990f8f34ad6`. Destinatário implantador-base 2.10.0, identidade confirmada no impacto recebido da rodada anterior; seu código não foi examinado nesta rodada.

## Contrato e ação necessária

Pedidos core 274/275: contrato administrativo 8.11.0 e perfil piso-padrao-3.6 (revisão 2026-10-22-core-1.46.0), com 92 condições mensais; 60 meses, operações concluídas seis. Perfis históricos continuam disponíveis. A aplicação do piso é explícita e não ocorre pela simples instalação. Escrita persistida com cache_agendado agora é sucesso, com verificação pendente. Não repetir a escrita por esse motivo; conservar revisão/CAS e verificar o efeito depois.

Pedidos core 277/279/281: três iscas compartilhadas, valor privado cifrado e regra de suspeita descrita em RELEASE-1.46.0.md. Website isolada é aceita; novas iscas tornam suspeito com revisão humana. Token vencido válido é sinal informativo; assinatura inválida/ausente salva suspeito. A revisão atual valida os campos. Não conservar no fallback uma recusa por prazo/token ou website que contradiga o Core. O Core continua dono de captura/continuação/validação quando presente; não emitir dois coletores. A aprovação com entregar=true é uma intenção idempotente do contato, sem reenvio publicitário histórico.

Reaquecimento opcional: f3base_cache_reaquecimento, desligado por padrão; leitura f3base/cache-reaquecimento-ler. A implantação não altera implicitamente WP Super Cache. A frota aplica 86400 e reaquecimento no piloto decidido pelo dono, observando quatorze dias.

O encaminhamento anterior informa seis cópias compartilhadas, mas não enumera seus caminhos. O Implantador deve conferir seu manifesto e sincronizar as correspondentes afetadas. As referências abaixo são caminhos reais do Core, sem inventar caminhos do destinatário. A nova classe de antispam precisa acompanhar quem copiar sua chamada.

| Arquivo Core | SHA-256 |
|---|---|
| includes/class-f3base-formularios.php | a704d5fbbc0ae03ace60bc3402125865effc76817946d5c019fa5796a694f370 |
| includes/class-f3base-formulario-antispam.php | a9b295a81daf25a04a791969d9eac43e46eedd4baaa579e758e665e301aa50a1 |
| includes/class-f3base-formulario-complementos.php | d2f075dc27ff80fe27aebbc22045fa48ad0c6d6f25070b428d48f0e7e198a976 |
| assets/f3base-formularios.js | f7b4f739a4e01ff37d14f3c31628ebdef7c904d799e9abac446112cd68b24c83 |
| assets/f3base-formularios.min.js | f238c595feee209c7897947db6a8c28fabd346a66ca5b0104bf18043e0d0faab |
| includes/class-f3base-options.php | f0f90765b387eeaf7348cc024c57ee2fb3077d19776159bf32d1a76ceba55bc4 |
| includes/class-f3base-config-contrato.php | d058be5f1b6a85b0ca4e6c7a7abda2d21a04323d97a5c0509b67eb0a44c617a2 |
| includes/class-f3base-config-perfil.php | 422a81ff75883e8ed42b75b1130f624dc9b23a872f8591d26a1d04648232a80b |
| includes/class-f3base-core-config-mcp.php | 201b28eb53311e821f315554c7919d2cb6ab275c28343418821645ec5330f91f |
| docs/perfis/piso-padrao-3.6.json | 775dcd8a67a96f0859a41a0a836bc849fabbfd64b394ed3ccb824b6898e2a6fa |

## Prova e aceite

Core: 605 verificações PHP direcionadas, 33 casos de formulário em Chromium e 26 verificações da configuração; instalação nova e atualização 1.45→1.46 pelo instalador final. Site-Teste confirma escrita persistida/cache pendente, perfil novo e captura/leitura das iscas. Consulte o relatório principal para os resultados remotos e limites.

Responsável Implantador: conferir seis cópias, carregar dependência nova, usar schema/perfil mensal, testar página/diálogo/etapa 2, gravação sem repetição por cache pendente e Core como dono. Responsável frota: implantação autorizada e piloto de cache. Sem atualização ou aceite do código do Implantador nesta rodada. O Core não aguarda retorno do destinatário para entregar sua implementação.

Histórico: revisão 1 preparada no planejamento, antes das alterações compartilhadas; revisão 2 registra comportamento entregue, provas próprias e hashes finais. Documento preparado para o dono; não enviado a terceiros. Não existe ação nova requerida do MCP Google nesta rodada.
