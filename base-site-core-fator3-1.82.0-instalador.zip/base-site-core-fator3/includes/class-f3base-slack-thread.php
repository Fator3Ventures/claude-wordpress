<?php
/** Projeção do thread individual e atualização das respostas já confirmadas. */
declare(strict_types=1);
defined('ABSPATH') || exit;
final class F3Base_Slack_Thread {
    public const TIPOS=['principal','acontecimento','origem','visitas','links'];
    public static function mensagem(string $header,array $fields,?string $file=null): array {
        $blocks=[['type'=>'header','text'=>['type'=>'plain_text','text'=>mb_substr($header,0,150)]]];$fallback=[$header];$lines=[];
        foreach($fields as $k=>$v){
            $v=implode(', ',array_filter((array)$v,'is_scalar'));if(trim($v)===''){continue;}
            $label=F3Base_Avisos::texto((string)$k);$value=F3Base_Avisos::texto($v);
            $fallback[]=$k.': '.$v;
            if(preg_match('~^https?://[^\s<>|]+$~iD',$v)){$lines[]='<'.$value.'|'.$label.'>';}else{$lines[]='*'.$label.'*  '.$value;}
        }
        // Split on UTF-8 characters and keep room for the file and Slack's block limit.
        $body=implode("\n",$lines);
        foreach(mb_str_split(mb_substr($body,0,38000),2800) as $part){$blocks[]=['type'=>'section','text'=>['type'=>'mrkdwn','text'=>$part,'verbatim'=>true]];}
        if($file && preg_match('/^F[A-Z0-9]+$/D',$file)){$blocks[]=['type'=>'image','slack_file'=>['id'=>$file],'alt_text'=>'Imagem ou miniatura do anúncio de origem'];}
        return ['text'=>mb_substr(implode("\n",$fallback),0,39000),'blocks'=>$blocks,'unfurl_links'=>false,'unfurl_media'=>false,'reply_broadcast'=>false,'parse'=>'none'];
    }
    public static function titulo(array $a,array $creative=[]): string {
        $method=$a['metodo']; $native=$a['origem_nativa']['origem']??'';
        $prefix=(!empty($a['teste'])?'[TESTE] ':'').$a['site'].' · ';
        if ($method==='email' || $native==='email') { return $prefix.'Recebido por e-mail'; }
        $entry=$a['titulo_mensagem']??match ($native) {
            'meta'=>'Formulário Meta','linkedin'=>'Formulário LinkedIn','google'=>'Formulário Google',
            default=>match ($method) {
                'formulario','whatsapp_formulario'=>'Formulário Site','anuncio_meta'=>'Formulário Meta',
                'anuncio_linkedin'=>'Formulário LinkedIn','anuncio_google'=>'Formulário Google',
                default=>F3Base_Relatorios::rotulo($method),
            },
        };
        return $prefix.$entry.' · '.F3Base_Anuncio_Origem::origem_slack($a,$creative);
    }
    /** Edit only the original heading. Preserve the accepted snapshot, blocks and contact fields. */
    public static function corrigir_titulo(array $origin,array $a,array $fields): bool {
        $lock=F3Base_Trava::adquirir('slack-transporte',30);
        if (!$lock) { return false; }
        try {
            $parent=self::parte($origin['aviso'],'principal');
            if (!$parent || $parent['chave']!==$origin['principal'] || $parent['ts']!==$origin['thread_ts']
                || $parent['canal']!==$origin['canal'] || $parent['estado']!=='entregue') { return false; }
            $msg=F3Base_Contato_Comunicacao::abrir($parent['payload']);
            if (($msg['blocks'][0]['type']??'')!=='header' || !isset($msg['text'])) { return false; }
            $title=self::titulo($a,$fields); $lines=explode("\n",$msg['text'],2);
            $msg['text']=$title.(isset($lines[1])?"\n".$lines[1]:'');
            $msg['blocks'][0]['text']['text']=mb_substr($title,0,150);
            return self::editar_reservada($parent,$msg);
        } finally { F3Base_Trava::liberar($lock); }
    }
    public static function mensagens(array $a,array $crm=[],array $creative=[],?string $file=null,string $fileStatus=''): array {
        $n=$a['origem_nativa']??[];$src=F3Base_Anuncio_Origem::origem_slack($a,$creative);
        $main=['Nome'=>$a['nome']??'','E-mail'=>$a['email']??'','Telefone'=>$a['telefone']??'','Empresa'=>$a['empresa']??'','Cargo'=>$a['cargo']??'','Serviço de interesse'=>$a['servicos']??[],'WhatsApp'=>$a['whatsapp_link']??''];
        $out=[self::mensagem(self::titulo($a,$creative),$main)];
        $date=$n?($n['nativo_em']??''):($a['capturado_em']??'');
        $at=$date?strtotime($date.($n?'':' UTC')):false;
        $event=['Formulário'=>$a['formulario']??'','Hora do envio'=>$at?wp_date('d/m/Y H:i:s P',$at):'','Página'=>$a['pagina']??'','Assunto'=>$a['email_mensagem']['assunto']??'','Corpo do e-mail'=>$a['email_mensagem']['texto']??''];
        $event+=($a['respostas']??[]); 
        foreach($a['campos']??[] as $k=>$v){
            if(!in_array($v,$event,true) && !in_array((array)$v,(array)($a['respostas']??[]),true)){$event[$k]=$v;}
        }
        $nonempty=static fn($v)=>is_array($v)?(bool)array_filter($v,'is_scalar'):is_scalar($v)&&trim((string)$v)!=='';
        if(array_filter($event,$nonempty)||!empty($a['pagina_titulo'])){$out[1]=self::mensagem('Acontecimento'.(!empty($a['pagina_titulo'])?' · '.$a['pagina_titulo']:''),$event);}
        $t=$a['atribuicao']??[];$base=F3Base_Anuncio_Origem::base($a);
        $origin=['Origem'=>$t['utm_source']??'','Mídia'=>$t['utm_medium']??'','Campanha'=>$t['nome_campanha_origem']??$t['utm_campaign']??''];
        if(!$base && (strtolower((string)($t['utm_medium']??''))==='organic' || !empty($n['is_organic']))){$origin=['Origem'=>$n?($src.' (orgânico)'):'Site (orgânico)'];}
        if($base){$origin['Anúncio de origem']=$base['fields']['Plataforma'];$origin=array_replace($origin,$base['fields'],$creative);unset($origin['Plataforma']);}
        if ($a['metodo']!=='email' && $src!=='Orgânico') { $origin['Origem atribuída']=$src; }
        if($fileStatus){$origin['Arquivo']=$fileStatus;}
        if(array_filter($origin,$nonempty)){$out[2]=self::mensagem('Origem',$origin,$file);}
        $j=$a['jornada']??[];$vis=[];
        if(isset($j['visitas'])){$vis['Visitas anteriores']=(!empty($j['visitas_minimo'])?'Pelo menos ':'').max(0,(int)$j['visitas']-1);}
        if(isset($j['duracao_observada_segundos'])){$vis['Tempo observado']=F3Base_Contato_Comunicacao::tempo((float)$j['duracao_observada_segundos']);}
        if(isset($j['tempo_ativo_total_ms'])){$vis['Tempo ativo']=F3Base_Contato_Comunicacao::tempo($j['tempo_ativo_total_ms']/1000);}
        if(isset($j['paginas_distintas']) && ($j['codigo']??'')==='observado'){$vis['Páginas distintas']=$j['paginas_distintas'];}
        if(isset($crm['nova'])){$vis['Contato no CRM']=$crm['nova']?'Lead novo':'Contato repetido';}
        if($vis){$out[3]=self::mensagem('Visitas',$vis);}
        $links=array_filter(['Contato no WordPress'=>$a['registro_url']??'','Oportunidade no Pipedrive'=>$crm['url']??'']);
        if($links){$out[4]=self::mensagem('Links',$links);}
        return $out;
    }
    public static function parte(string $notice,string $type): ?array {
        global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE aviso=%s AND tipo=%s ORDER BY sequencia LIMIT 1',F3Base_Slack::tabela(),$notice,$type),ARRAY_A);
    }
    public static function editar(array $p,array $msg): bool {
        $lock=F3Base_Trava::adquirir('slack-transporte',30);if(!$lock){return false;}
        try {
            $fresh=self::parte($p['aviso'],$p['tipo']);
            if(!$fresh || $fresh['chave']!==$p['chave']){return false;}
            return self::editar_reservada($fresh,$msg);
        } finally {F3Base_Trava::liberar($lock);}
    }
    private static function editar_reservada(array $p,array $msg): bool {
        global $wpdb;
        if(!hash_equals($p['destino'],F3Base_Slack::destino())){return false;}
        if(!in_array($p['estado'],['pendente','entregue'],true)){return false;}
        if(F3Base_Contato_Comunicacao::abrir($p['payload'])===$msg){return true;}
        $where=['chave'=>$p['chave'],'estado'=>$p['estado'],'payload'=>$p['payload']];
        if($p['estado']==='entregue'){
            $token=F3Base_Segredos::abrir(F3Base_Slack::SEGREDO);if(!$token||!$p['ts']){return false;}
            $r=F3Base_Slack::api('chat.update',$token,['channel'=>$p['canal'],'ts'=>$p['ts'],'text'=>$msg['text'],'blocks'=>$msg['blocks']]);
            if(empty($r['ok'])){return false;}
        }
        return $wpdb->update(F3Base_Slack::tabela(),['payload'=>F3Base_Contato_Comunicacao::cifrar($msg)],$where)===1;
    }
    public static function retorno(array $original,array $lead,string $job): array {
        $pending=['estado'=>'pendente','codigo'=>'atualizacao_thread_pendente'];
        $crm=F3Base_Anuncio_Entrega::crm($lead,$job);if(!$crm){return $pending;}
        $prep=F3Base_Contato_Comunicacao::preparar($lead,false);if(empty($prep['ok'])){return $pending;}
        $messages=self::mensagens($prep['apresentacao'],$crm['opp']+['url'=>$crm['url']]);
        $links=self::parte($original['chave'],'links');$vis=self::parte($original['chave'],'visitas');
        // Uma resposta já publicada tem posição fixa no Slack. Reutilizar seu ts também na retomada de um aviso antigo.
        if (!$vis && isset($messages[3], $messages[4]) && ($links['estado'] ?? '') === 'entregue') {
            $combined = $messages[4];
            $combined['text'] = $messages[3]['text']."\n".$combined['text'];
            $combined['blocks'] = array_merge($messages[3]['blocks'], $combined['blocks']);
            return self::editar($links, $combined) ? ['estado'=>'entregue','codigo'=>'retorno_na_mesma_thread'] : $pending;
        }
        if(!$vis && isset($messages[3]) && $links){
            if(!F3Base_Slack::inserir_visitas($original,$links['principal'],$messages[3])){return $pending;}
            $vis=self::parte($original['chave'],'visitas');
        }
        if(!$links || !$vis || !self::editar($vis,$messages[3]) || !self::editar($links,$messages[4])){return $pending;}
        return ['estado'=>'entregue','codigo'=>'retorno_na_mesma_thread'];
    }
}
