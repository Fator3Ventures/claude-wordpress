<?php
/** Core 337/340: optional local Ads reader; credentials and collection remain in Google. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Google_Acervo {
    const OPTION='f3base_google_ads_acervo';const CONTRACT='google-ads-reader/1.0.0';const CONSUMER='base-site-core-fator3';
    private static $client=null;
    public static function padroes(): array{return ['ativo'=>false,'conexao'=>'','conta_id'=>'','revisao'=>0,'parceiros'=>[],'parceiro_padrao'=>['parceiro_id'=>'','rotulo'=>'']];}
    public static function props(): array{return ['parceiros'=>F3Base_Meta_Ads::props()['parceiros'],'parceiro_padrao'=>F3Base_Meta_Ads::props()['parceiro_padrao'],'ativo'=>['type'=>'boolean'],'conexao'=>F3Base_Meta_Ads::props()['conexao'],'conta_id'=>['type'=>'string','pattern'=>'^([0-9]{10})?$'],'revisao'=>['type'=>'integer','minimum'=>0,'maximum'=>2147483647]];}
    public static function opcoes(): array{return array_replace(self::padroes(),(array)F3Base_Options::ler(self::OPTION));}
    public static function validar($v): string {
        $e=rest_validate_value_from_schema($v,['type'=>'object','properties'=>self::props(),'additionalProperties'=>false]);if(is_wp_error($e))return $e->get_error_message();
        $v=array_replace(self::padroes(),$v);$old=self::opcoes();$err=F3Base_Meta_Ads::validar(array_replace(F3Base_Meta_Ads::padroes(),$v));if($err!=='')return $err;
        if($v['ativo']&&($v['conexao']===''||!preg_match('/^[0-9]{10}$/D',$v['conta_id'])||$v['revisao']<1))return 'Informe conexão, conta e revisão positiva.';
        if($v!==$old&&$v['revisao']<=$old['revisao'])return 'Aumente a revisão para alterar ou restaurar a seleção.';
        return '';
    }
    public static function configuracao(): array {
        $c=self::opcoes();$state=F3Base_Recuperacao::ler();
        return ['account_ids'=>$c['conta_id']!==''?[$c['conta_id']]:[],'revision'=>hash('sha256',wp_json_encode([$c,$state['geracao']??0])),'ready'=>$c['ativo']&&$c['conexao']!==''&&(bool)preg_match('/^[0-9]{10}$/D',$c['conta_id'])&&!empty($state['ok'])&&empty($state['pausado'])];
    }
    public static function descobrir($sdk,string $contract): void {
        if($contract!==self::CONTRACT||self::$client)return;
        try{$caps=$sdk::capabilities();if(($caps['contract']??'')!==self::CONTRACT||($caps['remote_calls']??null)!==false)return;$client=$sdk::register_consumer(self::CONSUMER,F3BASE_PLUGIN_VERSAO,self::CONTRACT,[__CLASS__,'configuracao']);if(is_object($client)&&is_callable([$client,'query'])&&is_callable([$client,'status']))self::$client=$client;}catch(Throwable $e){self::$client=null;}
    }
    public static function iniciar(): void {
        /* Catalog declaration belongs to F3Base_Options. */
        add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),125);add_action('f3base_google_cliques',[__CLASS__,'enriquecer']);
        add_action('wp_abilities_api_init',[__CLASS__,'registrar']);
    }
    public static function registrar(): void {
        F3Base_Servicos::ability('google-ads-anuncio-origem','Localiza o anúncio do contato e lê o criativo autorizado no Google Ads',[__CLASS__,'anuncio_origem'],
            ['ad_id'=>['type'=>'string','pattern'=>'^[1-9][0-9]{0,18}$'],'date'=>['type'=>'string','format'=>'date'],'gclid'=>['type'=>'string','minLength'=>1,'maxLength'=>1024]],[],true,'manage_options');
        F3Base_Servicos::ability('google-ads-acervo-status','Estado do leitor Google Ads, sem chamada ao fornecedor',[__CLASS__,'status']);
        F3Base_Servicos::ability('google-ads-acervo-ler','Lê dias do acervo Google Ads, com moeda, revisão e cobertura; GCLID somente por igualdade exata',[__CLASS__,'consultar'],self::schema(),['de','ate','dataset'],true,'manage_options');
    }
    public static function anuncio_origem(array $i): array {
        if (!current_user_can('manage_options') || !current_user_can('f3base_ler_leads')) { return self::erro('sem_permissao'); }
        return self::origem_conta(self::opcoes()['conta_id'], $i);
    }
    public static function origem_conta(string $account, array $i): array {
        $cfg=self::configuracao();
        if ($account === '' || !in_array($account, $cfg['account_ids'], true)) { return self::erro('conta_divergente'); }
        if (!$cfg['ready']) { return self::erro('configuracao_pendente'); }
        if (!self::$client || !is_callable([self::$client,'origin_ad'])) { return self::erro('sdk_ausente'); }
        $extension=self::$client->capabilities()['extensions']['origin_ad']??[];
        if (($extension['contract']??'')!=='google-ads-origin/1.0.0') { return self::erro('contrato_incompativel'); }
        if (array_diff(array_keys($i),['ad_id','date','gclid'])) { return self::erro('consulta_invalida'); }
        $sel=self::opcoes();
        try {
            $result=self::$client->origin_ad(['contract'=>$extension['contract'],'account_id'=>$sel['conta_id'],
                'connection_id'=>$sel['conexao'],'consumer_revision'=>$cfg['revision']]+$i);
            return self::configuracao()===$cfg && is_array($result)?$result:self::erro('configuracao_alterada');
        } catch (Throwable $e) {return self::erro('leitor_indisponivel');}
    }
    public static function schema(): array{return ['de'=>['type'=>'string','format'=>'date'],'ate'=>['type'=>'string','format'=>'date'],'dataset'=>['type'=>'string','enum'=>['clicks','customer','campaign','ad_group','ad','search_terms','changes']],'limite'=>['type'=>'integer','minimum'=>1,'maximum'=>1000,'default'=>500],'cursor'=>['type'=>'string','maxLength'=>20000],'gclid'=>['type'=>'string','minLength'=>1,'maxLength'=>1024]];}
    private static function erro(string $code): array{return ['ok'=>false,'codigo'=>$code,'linhas'=>[],'proximo_cursor'=>null,'http_fornecedor'=>false];}
    private static function chamar(string $method,array $i=[]): array {
        if(!self::$client)return ['success'=>false,'error_code'=>'sdk_ausente'];
        $deny=static fn()=>new WP_Error('google_acervo_local','Leitura exclusivamente local.');add_filter('pre_http_request',$deny,PHP_INT_MAX,3);
        try{$r=$method==='status'?self::$client->status():self::$client->query($i);return is_array($r)?$r:['success'=>false,'error_code'=>'resposta_sdk_invalida'];}catch(Throwable $e){return ['success'=>false,'error_code'=>'sdk_indisponivel'];}finally{remove_filter('pre_http_request',$deny,PHP_INT_MAX);}
    }
    /** Reuse an archived exact click only while the same capture, account and reader grant hold. */
    public static function campanha_do_clique(array $lead,array $touch): string {
        $v=json_decode($lead['google_ads']??'',true);
        if (($v['codigo']??'')!=='encontrado' || empty($v['clique']['campaign_name'])) { return ''; }
        $row=$v['clique']; $sel=self::opcoes(); $cfg=self::configuracao();
        $raw=$lead['dados']['atribuicao']??[];
        $at=strtotime($lead['criado_em'].' UTC');
        if (!$cfg['ready'] || ($v['configuracao']??'')!==$cfg['revision'] || ($row['account_id']??'')!==$sel['conta_id']
            || ($row['campaign_id']??null)!==($touch['campanha_id']??'') || empty($row['campaign_id'])
            || (!empty($touch['conta_id']) && $touch['conta_id']!==$sel['conta_id'])
            || ($v['origem_hash']??'')!==hash('sha256',wp_json_encode([$raw,$at])) || empty($raw['gclid'])) { return ''; }
        $r=self::chamar('query',['contract_version'=>'1.0.0','connection_id'=>$sel['conexao'],'account_id'=>$sel['conta_id'],
            'dataset'=>'clicks','date'=>$row['date'],'consumer_revision'=>$cfg['revision'],'limit'=>1]);
        return !empty($r['success']) && ($r['contract_version']??'')==='1.0.0' && self::configuracao()===$cfg
            ? mb_substr(sanitize_text_field($row['campaign_name']),0,300) : '';
    }
    /** Lookup on the capture date and the preceding closed day, using the local reader grant. */
    public static function campanha_local(string $account,string $campaign,int $at): string {
        $sel=self::opcoes();
        if ($campaign==='' || $account==='' || $account!==$sel['conta_id'] || !self::$client || !$at) { return ''; }
        $cfg=self::configuracao();
        if (!$cfg['ready']) { return ''; }
        $day=(new DateTimeImmutable('@'.$at))->setTimezone(wp_timezone());
        foreach ([$day,$day->modify('-1 day')] as $date) {
            $q=['contract_version'=>'1.0.0','connection_id'=>$sel['conexao'],'account_id'=>$account,
                'dataset'=>'campaign','date'=>$date->format('Y-m-d'),'consumer_revision'=>$cfg['revision'],'limit'=>1000];
            $seen=[];
            do {
                $r=self::chamar('query',$q);
                if (empty($r['success']) || ($r['contract_version']??'')!=='1.0.0' || self::configuracao()!==$cfg) { break; }
                foreach ($r['rows']??[] as $row) {
                    if (($row['account_id']??'')===$account && ($row['campaign_id']??'')===$campaign
                        && ($row['date']??'')===$q['date'] && ($row['dataset']??'')==='campaign' && !empty($row['campaign_name'])) {
                        return mb_substr(sanitize_text_field($row['campaign_name']),0,300);
                    }
                }
                $cursor=$r['next_cursor']??'';
                if (!$cursor || isset($seen[$cursor])) { break; }
                $seen[$cursor]=true; $q['cursor']=$cursor;
            } while (true);
        }
        return '';
    }
    public static function status(array $i=[]): array {
        if(!current_user_can('manage_options'))return self::erro('sem_permissao');
        return ['ok'=>true,'contrato'=>self::CONTRACT,'registrado'=>self::$client!==null,'configuracao'=>self::configuracao(),'conexao'=>self::opcoes()['conexao'],'sdk'=>self::chamar('status'),'http_fornecedor'=>false,'coleta'=>'Configurar e conceder no MCP Google.'];
    }
    private static function cursor(array $v): string {$s=base64_encode(wp_json_encode($v));return $s.'.'.hash_hmac('sha256',$s,wp_salt('auth'));}
    public static function consultar(array $i): array {
        if(!current_user_can('manage_options')||(($i['dataset']??'')!=='changes'&&!current_user_can('f3base_ler_leads')))return self::erro('sem_permissao');
        $r=self::pagina($i);if(($i['dataset']??'')==='changes'&&!current_user_can('f3base_ler_leads'))foreach($r['linhas'] as &$row){unset($row['author']);$row['old']=self::sem_autor($row['old']??null);$row['new']=self::sem_autor($row['new']??null);}unset($row);return $r;
    }
    private static function pagina(array $i): array {
        $e=rest_validate_value_from_schema($i,['type'=>'object','properties'=>self::schema(),'additionalProperties'=>false,'required'=>['de','ate','dataset']]);
        if(is_wp_error($e)||!F3Base_Gsc::data_valida($i['de']??'')||!F3Base_Gsc::data_valida($i['ate']??'')||$i['de']>$i['ate']||(new DateTimeImmutable($i['de']))->diff(new DateTimeImmutable($i['ate']))->days>365||isset($i['gclid'])&&$i['dataset']!=='clicks')return self::erro('consulta_invalida');
        $cfg=self::configuracao();$sel=self::opcoes();if(!$cfg['ready'])return self::erro('configuracao_pendente');
        $contacts=in_array($i['dataset'],['clicks','changes'],true)?['ok'=>true,'hash'=>'','rows'=>[]]:self::contatos($i['de'],$i['ate']);if(!$contacts['ok'])return self::erro($contacts['codigo']);
        $bind=hash('sha256',wp_json_encode([$cfg,$sel,$i['de'],$i['ate'],$i['dataset'],$i['limite']??500,$i['gclid']??null,$contacts['hash']]));$day=$i['de'];$provider=null;
        if(!empty($i['cursor'])){if(substr_count($i['cursor'],'.')!==1)return self::erro('cursor_invalido');[$body,$sig]=explode('.',$i['cursor']);if(!hash_equals(hash_hmac('sha256',$body,wp_salt('auth')),$sig))return self::erro('cursor_invalido');$plain=base64_decode($body,true);$c=$plain!==false?json_decode($plain,true):null;if(!is_array($c)||($c['binding']??'')!==$bind||($c['expires']??0)<time()||!F3Base_Gsc::data_valida((string)($c['date']??''))||$c['date']<$i['de']||$c['date']>$i['ate'])return self::erro('cursor_expirado_ou_alterado');$day=$c['date'];$provider=$c['provider'];}
        $q=['contract_version'=>'1.0.0','connection_id'=>$sel['conexao'],'account_id'=>$sel['conta_id'],'dataset'=>$i['dataset'],'date'=>$day,'consumer_revision'=>$cfg['revision'],'limit'=>$i['limite']??500];if($provider)$q['cursor']=$provider;
        $r=self::chamar('query',$q);if(empty($r['success']))return self::erro($r['error_code']??'sdk_indisponivel');
        if(($r['contract_version']??'')!=='1.0.0'||!is_array($r['rows']??null)||!array_key_exists('next_cursor',$r)||!is_array($r['coverage']??null))return self::erro('resposta_sdk_invalida');
        $rows=[];foreach($r['rows'] as $row){if(!is_array($row)||($row['account_id']??'')!==$sel['conta_id']||($row['date']??'')!==$day||($row['dataset']??'')!==$i['dataset'])return self::erro('linha_sdk_invalida');if(!isset($i['gclid'])||isset($row['gclid'])&&is_string($row['gclid'])&&hash_equals($i['gclid'],$row['gclid']))$rows[]=$row;}
        if(self::configuracao()!==$cfg||self::opcoes()!==$sel)return self::erro('configuracao_alterada');
        if($i['dataset']!=='clicks'&&$i['dataset']!=='changes'){foreach($rows as &$line){$line['relacao_core']=self::relacao($line,$sel,$contacts['rows']);}unset($line);}
        if($contacts['hash']!==''&&self::contatos($i['de'],$i['ate'])['hash']!==$contacts['hash'])return self::erro('contatos_alterados');
        $nextDay=$r['next_cursor']?$day:(new DateTimeImmutable($day))->modify('+1 day')->format('Y-m-d');
        $next=$nextDay<=$i['ate']?self::cursor(['binding'=>$bind,'date'=>$nextDay,'provider'=>$r['next_cursor'],'expires'=>time()+86400]):null;
        return ['ok'=>true,'contrato'=>self::CONTRACT,'conta_id'=>$sel['conta_id'],'data'=>$day,'dataset'=>$i['dataset'],'linhas'=>$rows,'proximo_cursor'=>$next,'revisao'=>$r['revision']??null,'extraido_em'=>$r['extracted_at']??null,'moeda'=>$r['currency']??null,'fuso'=>$r['time_zone']??null,'cobertura'=>$r['coverage'],'http_fornecedor'=>false,'totais_agregados'=>false,'gclid_filtro_exato'=>isset($i['gclid']),'limites'=>['Não somar revisões do mesmo recorte nem moedas distintas.','Ausência de linha não prova zero ou ausência de clique.','Termos agregados não são associados a GCLID.']];
    }

    private static function sem_autor($v) {if(!is_array($v))return $v;foreach($v as $k=>&$x){if(preg_match('/author|user.?email|actor|creator|email/i',(string)$k)){unset($v[$k]);}else{$x=self::sem_autor($x);}}unset($x);return $v;}
    private static function contatos(string $from,string $to): array {
        global $wpdb;$start=(new DateTimeImmutable($from))->modify('-1 day');$end=(new DateTimeImmutable($to))->modify('+2 days');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT record_id,criado_em,dados,google_ads FROM %i WHERE criado_em>=%s AND criado_em<%s AND captura='aceito' AND classe_trafego='nao_marcado' AND lixeira=0 AND eliminacao_pendente=0 ORDER BY record_id LIMIT 10001",F3Base_Leads_Repositorio::tabela(),$start->format('Y-m-d H:i:s'),$end->format('Y-m-d H:i:s')),ARRAY_A);
        if($wpdb->last_error||count($rows)>10000)return ['ok'=>false,'codigo'=>'contatos_indisponiveis_ou_limite','hash'=>null];
        $hash=hash('sha256',wp_json_encode($rows));foreach($rows as &$r){$r['dados']=json_decode($r['dados'],true)?:[];$r['google_ads']=json_decode($r['google_ads']??'',true)?:[];}unset($r);return ['ok'=>true,'hash'=>$hash,'rows'=>$rows];
    }
    private static function relacao(array $row,array $cfg,array $contacts): array {
        $campaign=$row['campaign_id']??'';$partners=array_column($cfg['parceiros'],null,'campanha_id');$partner=$partners[$campaign]??($cfg['parceiro_padrao']['parceiro_id']!==''?$cfg['parceiro_padrao']:null);
        global $wpdb;try{$tz=new DateTimeZone($row['time_zone']);$a=new DateTimeImmutable($row['date'],$tz);$b=$a->modify('+1 day');}catch(Throwable $e){return ['codigo'=>'fuso_invalido','contatos'=>null];}
        $n=0;$from=gmdate('Y-m-d H:i:s',$a->getTimestamp());$to=gmdate('Y-m-d H:i:s',$b->getTimestamp());$revision=self::configuracao()['revision'];
        foreach($contacts as $lead){if($lead['criado_em']<$from||$lead['criado_em']>=$to)continue;$d=$lead['dados'];if(!empty($d['contexto_teste'])||!empty($d['audiencia_excluida']))continue;$g=$lead['google_ads'];$raw=$d['atribuicao']??[];$v=F3Base_Atribuicao::normalizar($raw);
            $account=$raw['conta_id']??$raw['f3_ads_account_id']??'';$c=$v['campanha_id']??'';$group=$v['grupo_id']??'';$ad=$v['anuncio_id']??'';
            if(($g['codigo']??'')==='encontrado'&&($g['configuracao']??'')===$revision&&($g['origem_hash']??'')===hash('sha256',wp_json_encode([$raw,strtotime($lead['criado_em'].' UTC')]))){$x=$g['clique'];$account=$x['account_id'];$c=$x['campaign_id']??'';$group=$x['ad_group_id']??'';$ad=$x['ad_id']??'';}
            if($account!==$row['account_id']||($campaign!==''&&$c!==$campaign)||(!empty($row['ad_group_id'])&&$group!==$row['ad_group_id'])||(!empty($row['ad_id'])&&$ad!==$row['ad_id']))continue;
            if($row['dataset']==='search_terms')continue; // No per-click search term is provided by click_view.
            if($v['plataforma']==='google_ads')$n++;
        }
        return ['contatos_aceitos'=>$row['dataset']==='search_terms'?null:$n,'parceiro'=>$partner,'fonte_parceiro'=>isset($partners[$campaign])?'mapa_explicito_core':($partner?'mapa_conta_core':'sem_mapa'),'revisao_mapa'=>$cfg['revisao'],'unidade'=>'dia_da_captura_no_fuso_da_conta','termo_sem_vinculo_individual'=>true];
    }
    public static function projecao(?string $json,?array $source=null,?int $at=null): array {
        if(!current_user_can('f3base_ler_leads'))return ['codigo'=>'sem_permissao_dados_pessoais'];
        $v=json_decode($json??'',true);if(!is_array($v))return ['codigo'=>self::configuracao()['ready']?'ainda_nao_conferido':'configuracao_pendente'];if($source!==null&&($v['origem_hash']??'')!==hash('sha256',wp_json_encode([$source,$at])))return ['codigo'=>'origem_alterada'];unset($v['curso'],$v['origem_hash'],$v['encontrados']);
        if(($v['configuracao']??'')!==self::configuracao()['revision'])return ['codigo'=>'configuracao_alterada'];
        $sel=self::opcoes();$auth=self::chamar('query',['contract_version'=>'1.0.0','connection_id'=>$sel['conexao'],'account_id'=>$sel['conta_id'],'dataset'=>'clicks','date'=>$v['clique']['date']??gmdate('Y-m-d'),'consumer_revision'=>self::configuracao()['revision'],'limit'=>1]);if(empty($auth['success']))return ['codigo'=>$auth['error_code']??'sem_concessao'];return $v;
    }
    /** One local page per record; progress is persisted with the selected identity. No HTTP. */
    public static function enriquecer(): array {
        if(!self::configuracao()['ready'])return self::erro('configuracao_pendente');if(!F3Base_Recuperacao::entrar())return self::erro('core_em_recuperacao');
        $lock=F3Base_Trava::adquirir('google-cliques',120);if(!$lock){F3Base_Recuperacao::sair();return self::erro('ocupado');}
        try{global $wpdb;$n=0;$deadline=microtime(true)+12;
            foreach(['sessao','contato'] as $kind){$table=$kind==='sessao'?F3Base_Sessoes::tabela():F3Base_Leads_Repositorio::tabela();$where=$kind==='sessao'?"conflito=0 AND origem LIKE '%gclid%'":"lixeira=0 AND eliminacao_pendente=0 AND dados LIKE '%gclid%'";
                $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} AND google_em<%d ORDER BY google_em LIMIT 10",$table,time()-3600),ARRAY_A);
                foreach($rows as $row){if(microtime(true)>$deadline)break 2;$data=$kind==='sessao'?(json_decode($row['origem'],true)?:[]):(json_decode($row['dados'],true)['atribuicao']??[]);$gclid=$data['gclid']??'';if(!is_string($gclid)||$gclid===''){$key=$kind==='sessao'?['classe'=>$row['classe'],'sessao'=>$row['sessao'],'origem'=>$row['origem']]:['record_id'=>$row['record_id'],'dados'=>$row['dados']];$wpdb->update($table,['google_ads'=>null,'google_em'=>time()],$key);continue;}
                    $at=$kind==='sessao'?(int)$row['inicio']:strtotime($row['criado_em'].' UTC');$from=gmdate('Y-m-d',$at-86400);$to=gmdate('Y-m-d',$at+86400);$q=['de'=>$from,'ate'=>$to,'dataset'=>'clicks','gclid'=>$gclid,'limite'=>1000];$hash=hash('sha256',wp_json_encode([$data,$at]));$cfg=self::configuracao();$prev=json_decode($row['google_ads']??'',true)?:[];
                    if(($prev['configuracao']??'')===$cfg['revision']&&($prev['origem_hash']??'')===$hash&&!empty($prev['curso']))$q['cursor']=$prev['curso'];else $prev=[];
                    $r=self::pagina($q);$value=['codigo'=>$r['codigo']??'em_conferencia','conferido_em'=>time(),'configuracao'=>$cfg['revision'],'origem_hash'=>$hash,'fonte'=>self::CONTRACT,'curso'=>$r['proximo_cursor']??null];
                    if(!empty($r['ok'])){$found=$prev['encontrados']??[];foreach($r['linhas'] as $line){$key=$line['click_id']??hash('sha256',wp_json_encode($line));unset($line['gclid']);$found[$key]=$line;}$value['encontrados']=$found;$value['cobertura']=$prev['cobertura']??[];$value['cobertura'][$r['data']]=$r['cobertura'];$value['revisao_acervo']=$r['revisao'];$value['extraido_em']=$r['extraido_em'];
                        if(!$value['curso']){$value['codigo']=count($found)===1?'encontrado':(count($found)>1?'gclid_ambiguo':(count(array_filter($value['cobertura'],static fn($v)=>!empty($v['archived'])))===0?'sem_acervo':'gclid_sem_linha'));if(count($found)===1)$value['clique']=array_values($found)[0];unset($value['encontrados']);}}
                    // CAS includes original payload and selected GCLID to avoid overwriting an edit/erasure.
                    $key=$kind==='sessao'?['classe'=>$row['classe'],'sessao'=>$row['sessao'],'origem'=>$row['origem'],'conflito'=>0]:['record_id'=>$row['record_id'],'dados'=>$row['dados'],'lixeira'=>0,'eliminacao_pendente'=>0];
                    if(self::configuracao()===$cfg&&false!==$wpdb->update($table,['google_ads'=>wp_json_encode($value),'google_em'=>$value['curso']?1:time()],$key))$n++;
                }
            }return ['ok'=>true,'processados'=>$n,'http_fornecedor'=>false];
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function render_relatorios(array $r): void {
        echo '<h3>Acervos de anúncios</h3><p>Contas selecionadas na configuração de cada acervo. Período compartilhado; filtros de contatos acima não recortam as linhas dos fornecedores. Moedas, dias, cobertura e revisões são preservados separadamente.</p>';
        foreach(['google_ads'=>'Google Ads','meta_ads'=>'Meta Ads'] as $key=>$title){$v=$r[$key]??[];echo '<details><summary>'.esc_html($title).'</summary>';
            if(empty($v['ok']))echo '<p role="status">'.esc_html($v['codigo']??'indisponivel').'</p>';
            else{echo '<p>'.esc_html($v['data']??'Período selecionado').'</p>';$rows=[];foreach($v['linhas']??[] as $line){$row=$line['row']??$line;$rows[]=array_intersect_key($row,array_flip(['date','campaign_id','campaign_name','ad_group_id','ad_id','search_term','spend','cost_micros','clicks','impressions','conversions']))+['moeda'=>$line['currency']??$v['moeda']??null,'relacao_core'=>$line['relacao_core']??null];}F3Base_Relatorios::tabela($rows);echo '<p class="description">cost_micros usa milionésimos da moeda da conta. Página vazia não equivale a gasto zero.</p>';if(!empty($v['proximo_cursor']))echo '<a class="button" href="'.esc_url(add_query_arg($key.'_cursor',$v['proximo_cursor'])).'">Continuar '.esc_html($title).'</a>';}
            echo '</details>';
        }
    }
    public static function conferir_agenda_1(): void {if(self::configuracao()['ready']&&!wp_next_scheduled('f3base_google_cliques'))wp_schedule_event(time()+60,'hourly','f3base_google_cliques');if(!self::configuracao()['ready'])wp_clear_scheduled_hook('f3base_google_cliques');}
}
