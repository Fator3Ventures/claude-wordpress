"""Close the 0.22.0 source once: plugin tree (via build/package-source.py rules) plus this reproducao/ folder.

Usage: python3 reproducao/empacotar-fonte.py --installer <instalador.zip> --report <relatorio-pre-fechamento.md> --output <dir>/wp-mcp-google-fator3-0.22.0-fonte.zip

Kept outside plugin/ so the validated build/tools/tests identity of the release is not altered by packaging.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, zipfile

HERE = Path(__file__).resolve().parent
PLUGIN = HERE.parent / 'plugin' / 'wp-mcp-google-fator3'

def main():
    spec = importlib.util.spec_from_file_location('google_package_source', PLUGIN / 'build/package-source.py')
    packager = importlib.util.module_from_spec(spec); spec.loader.exec_module(packager)
    p = argparse.ArgumentParser(description=__doc__)
    for name in ['installer', 'report', 'output']: p.add_argument('--' + name, required=True, type=Path)
    a = p.parse_args()
    if a.output.exists(): raise ValueError('Refusing to overwrite a closed source')
    staging = a.output.with_suffix('.staging.zip')
    import sys
    sys.argv = ['package-source.py', '--installer', str(a.installer), '--report', str(a.report), '--output', str(a.output)]
    packager.main()
    a.output.rename(staging)
    with zipfile.ZipFile(staging) as src:
        entries = {i.filename: src.read(i.filename) for i in src.infolist()}
    staging.unlink()
    prefix = next(iter(entries)).split('/', 1)[0] + '/'
    for path in sorted(HERE.rglob('*')):
        if path.is_file() and 'node_modules' not in path.parts and '__pycache__' not in path.parts:
            if path.suffix == '.zip': raise ValueError('Nested ZIP is forbidden: ' + str(path))
            entries[prefix + 'reproducao/' + path.relative_to(HERE).as_posix()] = path.read_bytes()
    with zipfile.ZipFile(a.output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for name, data in sorted(entries.items()):
            item = zipfile.ZipInfo(name, (2026, 10, 16, 0, 0, 0)); item.external_attr = 0o100644 << 16; item.compress_type = zipfile.ZIP_DEFLATED
            out.writestr(item, data)
    print(json.dumps({'files': len(entries), 'bytes': a.output.stat().st_size, 'sha256': hashlib.sha256(a.output.read_bytes()).hexdigest()}))

if __name__ == '__main__':
    main()
