# Reprodução — Google 0.22.0

Base exata 0.21.0. Runtime165 arquivos; evidências correntes em plugin/wp-mcp-google-fator3/evidence/022. Evidências e scripts das versões anteriores são históricos. Nenhum ZIP aninhado.

Ambiente: Linux amd64, Python3, PHP8.3.6, MySQL8.0.46, WordPress7.1.2/7.1.3 e WP-CLI2.12.0. Dependências fixadas em runtime-dependencies.json; download-runtime.py baixa um runtime isolado, sem serviço do sistema. Composer install com lock instala PHPUnit9.6.37. npm ci --prefix reproducao/jsdom instala jsdom27.4.0; exporte NODE_PATH apontando esse node_modules antes da matriz.

Instaladores: Google0.21→0.22; Core1.58.0, MCP0.34.0, Meta0.13.0, LinkedIn0.11.0 originais. Pipedrive0.2.0 fica só no inventário local porque exige PHP8.3.36. Relatório0.3.0 também foi lido; sua presença ativa no Site-Teste não equivale a execução nativa no PHP8.3.6.

1. Em plugin/wp-mcp-google-fator3, execute php vendor/bin/phpunit --log-junit /novo/evidence/unit-junit.xml. Para os módulos PHP isolados, use wrapper equivalente a tools/lab.py.
2. Execute php build/export-contracts.php --check e python3 build/check-docs.py.
3. Gere candidato com python3 build/build.py candidate --output /candidatos/google022.zip. Compare SHA-256 com o relatório e validation022.json.
4. mkmanifest.py gera entradas com caminho local e hash. Use min/current/upgrade correspondentes às versões e hashes registrados em validation022.json; base Google0.21 e baseline_core/mcp iguais aos acompanhantes atuais. Não baixe versões flutuantes.
5. Execute tools/release022.py com --manifest /min.json --manifest-current /current.json --manifest-upgrade /upgrade.json --work-base /novo/labs --evidence /novo/evidence --php /php-wrapper. O gate cobre clean, clean-713, upgrade, google-first e isolated. Pode separar --only em dois processos, desde que identidade e bytes sejam iguais; consolidar022.py comprova essa igualdade e cada relatório filho.
6. Para o patch Core, use tools/lab.py com manifesto current em laboratório separado, scripts tests/native/apply-core022.php e tests/native/requests022.php. O primeiro exige SHA-256 do arquivo Core original e troca apenas aquele arquivo nesse ambiente descartável. O segundo detecta e testa o consumidor adicional. Os testes de coexistência continuam usando o Core original.

O patch e arquivo completo estão em integration/core323; não são uma release oficial Core. Teste de cron, cooldown, revogação e prova expirada é separado. Fornecedores são interceptados; nenhuma prova sintética comprova efeito comercial.

Fechamento: o instalador aprovado é copiado sem recompressão. Escreva o relatório como cópia anterior ao fechamento do fonte e execute empacotar-fonte.py. Preencha o hash do fonte apenas no relatório externo após o ZIP. Não reabra bytes de versão instalada. historical-site-test-refusal021.php pertence ao aceite anterior e não foi executado na0.22.

Preliminares não entram nos totais finais. Corrigidos fixtures de tokens/constantes, capacidade do usuário nativo e a agregação do resultado de renovação comercial no executor. A primeira matriz interrompeu o DOM por NODE_PATH ausente; a matriz final usa a dependência fixada. O teste unitário de renovação cobre o agregador real, evitando marcar sucesso como falha no cron.
