<?php
/**
 * Registrador padrão das habilidades.
 *
 * Toda rota `ga/*`, `ads/*` e `google/*` passa por aqui em vez de chamar
 * `wp_register_ability()` direto. O motivo é que quatro coisas precisam ser
 * iguais em todas elas e são exatamente as que se esquece de repetir:
 * `meta.mcp.public` (sem isso o WP MCP Ultimate não expõe a rota),
 * `permission_callback` (sem isso a rota fica aberta a qualquer usuário
 * autenticado), o portão do `Gate` no início da execução e o registro de
 * auditoria no fim. Centralizar também garante que uma exceção vire resposta de
 * erro em vez de HTTP 500 no meio de uma sessão MCP.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Ability {
    private static array $admin_definitions = array();
    /** Called only inside the nonce-checked local administrator flow. */
    public static function execute_admin( string $name, array $input ) {
        if ( ! Gate::administrative_allowed( $name ) || ! isset( self::$admin_definitions[ $name ] ) ) {
            return Response::fail( new \WP_Error( 'f3_google_admin_context', 'Operação administrativa local não autorizada.' ) );
        }
        $ability = new \WP_Ability( $name, self::$admin_definitions[ $name ] );
        return $ability->execute( $input );
    }
    /**
	 * Registra uma habilidade com os padrões da casa.
	 *
	 * @param string $name      Ex.: 'ga/run-report'.
	 * @param string $connector 'ga' | 'ads' | 'any' — usado pelo Gate.
	 * @param array  $args      label, description, input_schema, output_schema
	 *                          (opcional), callback, meta (opcional).
	 */
    public static function register( string $name, string $connector, array $args ): void {
        if ( ! function_exists( 'wp_register_ability' ) ) {
            return;
        }
        $mode = 'write' === ( $args['mode'] ?? 'read' ) ? 'write' : 'read';
        $callback = $args['callback'] ?? null;
        if ( ! is_callable( $callback ) ) {
            return;
        }
        $input_schema = isset( $args['input_schema'] ) && is_array( $args['input_schema'] )
        ? $args['input_schema']
        : array();
        // O esquema de entrada é sempre um objeto fechado: o WordPress 6.9+
        // valida a entrada contra ele antes de executar, e `additionalProperties
        // = false` faz um parâmetro com nome errado falhar na hora, em vez de
        // ser silenciosamente ignorado e produzir um relatório errado.
        $input_schema['type'] = 'object';
        if ( ! isset( $input_schema['properties'] ) || ! is_array( $input_schema['properties'] ) ) {
            $input_schema['properties'] = array();
        }
        $input_schema['additionalProperties'] = false;
        if ( 'write' === $mode && 'google/configure' !== $name ) {
            $input_schema['properties']['confirmation_token'] = array(
                'type' => 'string',
                'description' => 'Token opaco de uso único emitido por google/prepare-operation para escritas sensíveis.',
            );
        }
        $input_schema['properties']['connection_id'] = array(
            'type' => 'string',
            'description' => 'Conexão Google; omissão usa a conexão padrão, ou a conexão do job em execução.',
        );
        $output_schema = isset( $args['output_schema'] ) && is_array( $args['output_schema'] )
        ? $args['output_schema']
        : array(
            'type' => 'object',
            'properties' => array(
                'success' => array( 'type' => 'boolean' ),
                'message' => array( 'type' => 'string' ),
            ),
        );
        $meta = isset( $args['meta'] ) && is_array( $args['meta'] ) ? $args['meta'] : array();
        $remote_effect = self::local_read( $name ) ? 'none' : $mode;
        if ( in_array( $name, array( 'google/configure-stage-conversion', 'google/rename-connection', 'google/configure-conversion-delivery', 'google/configure-consumer', 'google/recovery', 'ga/save-profile', 'google/create-connection', 'google/configure-policy', 'google/configure-alerts', 'google/configure-update-origin', 'google/configure-local', 'google/apply-template', 'google/cancel-job', 'google/delete-job', 'google/reconcile-job', 'google/cleanup-jobs', 'google/maintenance' ), true ) ) {
            $remote_effect = 'none';
        }
        if ( in_array( $name, array( 'google/verify-stage-conversion', 'google/reconcile-stage-conversion', 'google/plan-identity-change', 'google/switch-identity', 'google/verify-conversion-delivery', 'gsc/inspect-urls', 'google/configure', 'google/create-job', 'google/schedule-report', 'google/prepare-operation', 'google/prepare-job', 'google/approve-job' ), true ) ) {
            $remote_effect = 'read';
        }
        $meta['fator3'] = array_merge(
            (array) ( $meta['fator3'] ?? array() ),
            array(
                'version' => F3_MCP_GOOGLE_VERSION,
                'provider' => Channel::PROVIDER,
                'policy_contract' => 1,
                'connector' => $connector,
                'execution_contract_version' => '2.0.0',
                'mode' => $mode,
                'remote_effect' => $remote_effect,
                'local_effect' => 'write' === $mode ? 'write' : 'none',
            )
        );
        $meta['mcp'] = array_merge(
            array(
                'public' => true,
                'type' => 'tool',
            ),
            isset( $meta['mcp'] ) && is_array( $meta['mcp'] ) ? $meta['mcp'] : array()
        );
        // As anotações refletem efeitos possíveis; a confirmação pertence ao agente.
        $meta['annotations'] = array(
            'readonly' => 'read' === $mode,
            'destructive' => 'write' === $mode && ( Confirmation::sensitive( $name ) || in_array( $name, array( 'google/execute-action', 'google/mcp-write', 'google/configure', 'google/apply-template' ), true ) ),
            'idempotent' => 'read' === $mode,
        );
        $definition = array(
            'label' => LabelsPT::ability($name,(string) ($args['label']??$name)),
            'description' => LabelsPT::description( $name, (string) ( $args['description'] ?? '' ) ),
            'category' => 'google',
            'input_schema' => $input_schema,
            'output_schema' => $output_schema,
            'permission_callback' => static function ( $input = array() ) use ( $connector, $name ): bool {
            if ( 'google/documentation' === $name ) { return Documentation::allowed(); }
            $id = (string) ( self::normalize_input( $input )['connection_id'] ?? Connections::id() );
            $permitted = Connections::run( $id, static fn () => Gate::permission( $connector ) );
            return true === $permitted;
            },
            'execute_callback' => static function ( $input = array() ) use ( $name, $connector, $callback, $mode ): array {
            if ( 'google/documentation' === $name ) { return Delivery::guard(Operation::result(Documentation::read(self::normalize_input($input)), 'read'), $name); }
            $result = Connections::run( (string) ( self::normalize_input( $input )['connection_id'] ?? Connections::id() ), static fn () => Storage\Admission::run( $name, static fn () => self::run( $name, $connector, $callback, $input, $mode ) ) );
            return Delivery::guard( 'google/selftest' === $name && ! array_key_exists( 'execution_success', $result ) ? SelfTest::execution_error( $result ) : $result, $name );
            },
            'meta' => $meta,
        );
        self::$admin_definitions[ $name ] = $definition;
        wp_register_ability( $name, $definition );
    }
    /**
	 * Executa a habilidade: normaliza a entrada, aplica o portão, cronometra,
	 * converte exceção em erro e audita.
	 *
	 * @param string   $name      Nome da habilidade.
	 * @param string   $connector Conector para o Gate.
	 * @param callable $callback  Implementação da rota.
	 * @param mixed    $input     Entrada crua vinda do servidor MCP.
	 */
    private static function run( string $name, string $connector, callable $callback, $input, string $mode = 'read' ): array {
        $input = Operation::normalize( self::normalize_input( $input ) );
        if ( is_wp_error( $input ) ) {
            return Response::fail( $input, array( 'operation_outcome' => 'not_applied' ) );
        }
        if ( in_array( $name, array( 'google/execute-action', 'google/execute-read' ), true ) ) {
            $operation = Operation::method( (string) ( $input['api'] ?? '' ), (string) ( $input['method'] ?? '' ) );
            if ( is_wp_error( $operation ) ) {
                return Response::fail( $operation, array( 'operation_outcome' => 'not_applied' ) );
            }
            if ( 'google/execute-read' === $name && 'read' !== $operation['mode'] ) {
                return Response::fail( new \WP_Error( 'f3_google_read_required', 'execute-read aceita somente consultas classificadas.' ), array( 'operation_outcome' => 'not_applied' ) );
            }
            $mode = $operation['mode'];
            $connector = Generic\Discovery::connector( Generic\Discovery::canonical( (string) $input['api'] ) );
        }
        if ( 'write' === $mode && Operation::wildcard( $input ) ) {
            Audit::log(
                $name,
                '*',
                array(
                    'status' => 'denied',
                    'mode' => $mode,
                    'remote_effect' => 'gsc/inspect-urls' === $name ? 'read' : $mode,
                    'local_effect' => 'write' === $mode ? 'write' : 'none',
                )
            );
            return Response::fail(
                new \WP_Error( 'f3_google_write_wildcard', 'Escritas exigem alvos explícitos. Use a descoberta para preparar os identificadores.' ),
                array(
                    'operation_outcome' => 'not_applied',
                    'retryable' => false,
                )
            );
        }
        $target = self::target( $input );
        $dry_run = ! empty( $input['dry_run'] ) || ( 'ga/send-event' === $name && ! empty( $input['debug'] ) ) || ( 'google/execute-action' === $name && ( ! empty( $input['body']['validateOnly'] ) || ! empty( $input['query']['validateOnly'] ) ) );
        if ( 'write' === $mode ) {
            Audit::begin();
        }
        $remote_mode = 'gsc/inspect-urls' === $name ? 'read' : $mode;
        $profile_error = Operation::profile( $connector, $remote_mode );
        $gate = Gate::check( $connector ) ?? ( null !== $profile_error ? Response::fail( $profile_error ) : null );
        if ( null !== $gate ) {
            Audit::log(
                $name,
                $target,
                array(
                    'status' => 'denied',
                    'mode' => $mode,
                    'dry_run' => $dry_run,
                ) + ( 'write' === $mode ? Audit::finish() : array() )
            );
            return $gate;
        }
        if ( ! Confirmation::authorized() ) {
            Confirmation::reset_observations();
        }
        $started = microtime( true );
        try {
            $invoke = static fn () => self::invoke( $name, $mode, $connector, $callback, $input );
            $result = isset( $input['confirmation_token'] ) && ! Confirmation::capturing() ? Confirmation::execute( $name, $input, $invoke ) : $invoke();
            if ( is_wp_error( $result ) ) {
                $result = Response::fail( $result );
            }
            elseif ( ! is_array( $result ) ) {
                $result = Response::fail(
                    new \WP_Error(
                        'f3_google_bad_result',
                        __( 'A habilidade não devolveu uma resposta válida.', 'wp-mcp-google-fator3' )
                    )
                );
            }
        }
        catch ( \Throwable $e ) {
            // A mensagem da exceção pode ter passado por um trecho que
            // manipulava credencial; passa pelo filtro antes de sair.
            $result = Response::fail(
                new \WP_Error(
                    'f3_google_exception',
                    sprintf(
                        /* translators: %s: mensagem da exceção. */
                        __( 'Falha interna ao executar a habilidade: %s', 'wp-mcp-google-fator3' ),
                        self::scrub( $e->getMessage() )
                    )
                )
            );
        }
        if ( 'google/selftest' === $name && ! array_key_exists( 'execution_success', $result ) ) {
            $result = SelfTest::execution_error( $result );
        }
        if ( ( 'read' !== $mode || empty( $result['success'] ) || ! self::local_read( $name ) || Options::get( Options::AUDIT_LOCAL_READS, false ) ) ) {
            Audit::log(
                $name,
                $target,
                array(
                    'ms' => (int) round( ( microtime( true ) - $started ) * 1000 ),
                    'rows' => self::rows_in( $result ),
                    'status' => ! empty( $result['success'] ) ? 'ok' : 'erro',
                    'mode' => $mode,
                    'dry_run' => $dry_run,
                ) + ( 'write' === $mode ? Audit::finish() + array(
                        'result' => array(
                            'success' => ! empty( $result['success'] ),
                            'error_code' => $result['error_code'] ?? null,
                        ),
                    ) : array() )
            );
            if ( null !== Audit::last_failure() ) {
                $result['audit_warning'] = Audit::last_failure();
            }
        }
        return Operation::result( $result, $mode, $dry_run );
    }
    public static function local_read( string $name ): bool {
        return in_array( $name, array( 'google/stage-conversion-status', 'google/conversion-delivery-status', 'google/readiness-status', 'google/documentation', 'google/conversion-context', 'gtm/get-publication', 'google/integration-status', 'google/recovery-status', 'google/status', 'google/ability-catalog', 'google/configuration-schema', 'google/resource-policy', 'google/plan-policy', 'google/plan-template', 'google/report-templates', 'google/list-connections', 'google/list-jobs', 'google/get-job', 'google/get-schedule', 'google/alerts', 'google/audit', 'google/audit-export', 'google/storage-status', 'google/update-status', 'google/export-template', 'ga/list-profiles', 'ga/profile-schema' ), true );
    }
    /** Resolve seletor nomeado antes de chamar a operação; * é fanout explícito. */
    private static function invoke( string $name, string $mode, string $connector, callable $callback, array $input ) {
        $key = array(
            'ga' => 'property_id',
            'ads' => 'customer_id',
            'gsc' => 'site_url',
        )[ $connector ] ?? '';
        if ( '' === $key || ! isset( $input[ $key ] ) || ! is_scalar( $input[ $key ] ) || '' === trim( (string) $input[ $key ] ) ) {
            return $callback( $input );
        }
        $ids = Unified\Accounts::resolve_many( $connector, array( (string) $input[ $key ] ) );
        if ( is_wp_error( $ids ) ) {
            return $ids;
        }
        if ( '*' !== (string) $input[ $key ] && 1 === count( $ids ) ) {
            $input[ $key ] = $ids[0];
            return $callback( $input );
        }
        $results = array();
        $ok = true;
        foreach ( $ids as $id ) {
            $item = $input;
            $item[ $key ] = $id;
            // Cada alvo tem sua auditoria completa, além da entrada de fanout.
            if ( 'write' === $mode ) {
                Audit::begin();
            }
            try {
                $result = $callback( $item );
                $result = is_wp_error( $result ) ? Response::fail( $result ) : $result;
            }
            catch ( \Throwable $e ) {
                $result = Response::fail( self::scrub( $e->getMessage() ) );
            }
            $snapshots = 'write' === $mode ? Audit::finish() : array();
            $results[] = array(
                'account_id' => $id,
                'result' => $result,
            );
            $ok = $ok && ! empty( $result['success'] );
            Audit::log(
                $name,
                $id,
                array(
                    'mode' => $mode,
                    'status' => ! empty( $result['success'] ) ? 'ok' : 'erro',
                    'dry_run' => ! empty( $input['dry_run'] ),
                ) + $snapshots
            );
        }
        return array(
            'success' => $ok,
            'message' => count( $results ) . ' alvo(s) executado(s).',
            'results' => $results,
        );
    }
    /**
	 * Vários clientes MCP mandam o objeto de parâmetros como string JSON; o
	 * `execute-ability` do Ultimate já decodifica, mas uma chamada direta à
	 * habilidade (WP-CLI, outro servidor) pode não fazer isso.
	 *
	 * @param mixed $input Entrada crua.
	 */
    private static function normalize_input( $input ): array {
        if ( is_string( $input ) ) {
            $decoded = json_decode( $input, true );
            $input = is_array( $decoded ) ? $decoded : array();
        }
        return is_array( $input ) ? $input : array();
    }
    /**
	 * Alvo da operação para o log: a propriedade GA ou a conta Ads.
	 */
    private static function target( array $input ): string {
        foreach ( array( 'property_id', 'customer_id', 'site_url', 'spreadsheet_id', 'name', 'resource' ) as $key ) {
            if ( isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) ) {
                $value = trim( (string) $input[ $key ] );
                if ( '' !== $value ) {
                    return $value;
                }
            }
        }
        return '-';
    }
    /**
	 * Quantas linhas a resposta devolveu, para o log.
	 */
    private static function rows_in( array $result ): int {
        if ( isset( $result['row_count'] ) && is_numeric( $result['row_count'] ) ) {
            return (int) $result['row_count'];
        }
        if ( isset( $result['rows'] ) && is_array( $result['rows'] ) ) {
            return count( $result['rows'] );
        }
        return 0;
    }
    /**
	 * Remove qualquer segredo configurado de um texto antes de ele sair.
	 *
	 * Defesa em profundidade: nenhum caminho conhecido põe credencial numa
	 * mensagem de exceção, mas o custo de garantir é baixo e o de errar é uma
	 * chave privada num transcript de conversa.
	 */
    public static function scrub( string $text ): string {
        if ( '' === $text ) {
            return $text;
        }
        foreach ( Options::secret_names() as $name ) {
            $secret = Options::get_secret( $name );
            if ( Options::SA_JSON === $name ) {
                $key = json_decode( $secret, true );
                if ( is_array( $key ) && ! empty( $key['private_key'] ) ) {
                    $text = str_replace( array( (string) $key['private_key'], str_replace( "\n", '\\n', (string) $key['private_key'] ) ), '[redigido]', $text );
                }
            }
            if ( strlen( $secret ) >= 8 && false !== strpos( $text, $secret ) ) {
                $text = str_replace( $secret, '[redigido]', $text );
            }
        }
        foreach ( (array) Options::get( Options::TOKEN_INDEX, array() ) as $key ) {
            if ( ! is_string( $key ) || 0 !== strpos( $key, Auth\Credentials::CACHE_PREFIX ) ) {
                continue;
            }
            $token = Auth\Credentials::cached( $key, false );
            if ( is_string( $token ) && strlen( $token ) >= 8 ) {
                $text = str_replace( $token, '[token redigido]', $text );
            }
        }
        return $text;
    }
}

// BEGIN GENERATED PORTUGUESE LABELS
final class LabelsPT {
    public static function catalog(): array {
        static $catalog=null;
        if ($catalog===null) $catalog=json_decode(<<<'F3_LABELS_PT'
{
  "abilities": {
    "ads/add-audience-to-campaign": "Adicionar público à campanha",
    "ads/add-keywords": "Adicionar palavras-chave",
    "ads/add-label": "Criar marcador",
    "ads/add-negative-keywords": "Adicionar palavras-chave negativas",
    "ads/apply-label": "Aplicar marcador",
    "ads/create-ad-group": "Criar grupo de anúncios",
    "ads/create-asset": "Criar recurso de anúncio",
    "ads/create-asset-group": "Criar grupo de recursos",
    "ads/create-billing-setup": "Criar configuração de faturamento",
    "ads/create-budget": "Criar orçamento de campanha",
    "ads/create-campaign": "Criar campanha",
    "ads/create-conversion-action": "Criar ação de conversão",
    "ads/create-experiment": "Criar experimento",
    "ads/create-responsive-search-ad": "Criar anúncio responsivo de pesquisa",
    "ads/create-user-list": "Criar lista de usuários",
    "ads/get-campaign": "Consultar campanha",
    "ads/get-customer": "Consultar conta de anúncios",
    "ads/get-resource-metadata": "Consultar campos do recurso de anúncios",
    "ads/invite-user": "Convidar usuário",
    "ads/link-asset": "Vincular recurso de anúncio",
    "ads/list-accessible-customers": "Listar contas de anúncios acessíveis",
    "ads/list-assets": "Listar recursos de anúncios",
    "ads/list-audiences": "Listar públicos de anúncios",
    "ads/list-conversion-actions": "Listar ações de conversão",
    "ads/list-customer-clients": "Listar contas vinculadas",
    "ads/list-experiments": "Listar experimentos",
    "ads/list-resources": "Listar tipos de recursos de anúncios",
    "ads/list-users": "Listar usuários da conta de anúncios",
    "ads/mutate": "Alterar recursos de anúncios em lote",
    "ads/remove-ad": "Remover anúncio",
    "ads/remove-ad-group": "Remover grupo de anúncios",
    "ads/remove-campaign": "Remover campanha",
    "ads/remove-keywords": "Remover palavras-chave",
    "ads/remove-negative-keywords": "Remover palavras-chave negativas",
    "ads/remove-user": "Remover usuário da conta de anúncios",
    "ads/schedule-experiment": "Agendar experimento",
    "ads/search": "Consultar dados do Google Ads",
    "ads/update-ad-group": "Atualizar grupo de anúncios",
    "ads/update-ad-status": "Atualizar estado do anúncio",
    "ads/update-budget": "Atualizar orçamento de campanha",
    "ads/update-campaign": "Atualizar campanha",
    "ads/update-conversion-action": "Atualizar ação de conversão",
    "ads/update-keyword": "Atualizar palavra-chave",
    "ads/update-user-access": "Atualizar acesso do usuário",
    "ads/upload-click-conversions": "Importar conversões de clique",
    "ads/upload-customer-match": "Importar lista de clientes para correspondência",
    "ga/add-user": "Adicionar usuário ao Analytics",
    "ga/aplicar-perfil": "Aplicar perfil do Analytics",
    "ga/archive-audience": "Arquivar público do Analytics",
    "ga/archive-custom-dimension": "Arquivar dimensão personalizada",
    "ga/archive-custom-metric": "Arquivar métrica personalizada",
    "ga/check-compatibility": "Verificar compatibilidade de dimensões e métricas",
    "ga/conformidade": "Verificar conformidade do Analytics",
    "ga/create-annotation": "Criar anotação de relatório",
    "ga/create-audience": "Criar público do Analytics",
    "ga/create-custom-dimension": "Criar dimensão personalizada",
    "ga/create-custom-metric": "Criar métrica personalizada",
    "ga/create-google-ads-link": "Criar vínculo com Google Ads",
    "ga/create-key-event": "Criar evento principal",
    "ga/create-mp-secret": "Criar segredo do protocolo de medição",
    "ga/create-property": "Criar propriedade do Analytics",
    "ga/create-web-stream": "Criar fluxo de dados da Web",
    "ga/delete-account": "Excluir conta do Analytics",
    "ga/delete-annotation": "Excluir anotação de relatório",
    "ga/delete-google-ads-link": "Excluir vínculo com Google Ads",
    "ga/delete-key-event": "Excluir evento principal",
    "ga/delete-mp-secret": "Excluir segredo do protocolo de medição",
    "ga/delete-property": "Excluir propriedade do Analytics",
    "ga/delete-web-stream": "Excluir fluxo de dados da Web",
    "ga/get-account-summaries": "Consultar resumos das contas do Analytics",
    "ga/get-metadata": "Consultar dimensões e métricas disponíveis",
    "ga/get-property-details": "Consultar detalhes da propriedade do Analytics",
    "ga/get-settings": "Consultar configurações do Analytics",
    "ga/list-custom-dimensions": "Listar dimensões personalizadas",
    "ga/list-google-ads-links": "Listar vínculos com Google Ads",
    "ga/list-profiles": "Listar perfis do Analytics",
    "ga/list-property-annotations": "Listar anotações da propriedade",
    "ga/list-users": "Listar usuários do Analytics",
    "ga/profile-schema": "Consultar estrutura do perfil do Analytics",
    "ga/provision-account": "Preparar criação de conta do Analytics",
    "ga/remove-user": "Remover usuário do Analytics",
    "ga/run-conversions-report": "Gerar relatório de conversões",
    "ga/run-funnel-report": "Gerar relatório de funil",
    "ga/run-realtime-report": "Gerar relatório em tempo real",
    "ga/run-report": "Gerar relatório do Analytics",
    "ga/save-profile": "Salvar perfil do Analytics",
    "ga/send-event": "Enviar evento pelo protocolo de medição",
    "ga/update-annotation": "Atualizar anotação de relatório",
    "ga/update-attribution": "Atualizar configurações de atribuição",
    "ga/update-audience": "Atualizar público do Analytics",
    "ga/update-data-retention": "Atualizar retenção de dados",
    "ga/update-enhanced-measurement": "Atualizar medição otimizada",
    "ga/update-google-signals": "Atualizar sinais do Google",
    "ga/update-key-event": "Atualizar evento principal",
    "ga/update-property": "Atualizar propriedade do Analytics",
    "ga/update-user": "Atualizar usuário do Analytics",
    "ga/update-web-stream": "Atualizar fluxo de dados da Web",
    "google/ability-catalog": "Consultar catálogo de habilidades Google",
    "google/alerts": "Consultar alertas e incidentes",
    "google/apply-template": "Aplicar modelo de configuração",
    "google/approve-job": "Aprovar tarefa agendada",
    "google/audit": "Consultar auditoria Google",
    "google/audit-export": "Exportar auditoria Google",
    "google/audit-to-sheet": "Exportar auditoria para planilha",
    "google/blend": "Combinar dados de relatórios",
    "google/cancel-job": "Cancelar tarefa",
    "google/check-update": "Verificar atualização do plugin Google",
    "google/cleanup-jobs": "Limpar histórico de tarefas",
    "google/configuration-schema": "Consultar estrutura da configuração Google",
    "google/configure": "Configurar conexão Google",
    "google/configure-alerts": "Configurar alertas Google",
    "google/configure-consumer": "Configurar integração com Site Core",
    "google/configure-conversion-delivery": "Configurar entrega de conversões",
    "google/configure-local": "Configurar preferências locais",
    "google/configure-policy": "Configurar permissões por recurso",
    "google/configure-update-origin": "Configurar origem das atualizações",
    "google/conversion-context": "Consultar contexto de conversões do Site Core",
    "google/conversion-delivery-status": "Consultar prontidão da entrega de conversões",
    "google/create-connection": "Criar conexão Google",
    "google/create-job": "Criar tarefa Google",
    "google/delete-job": "Excluir tarefa Google",
    "google/disconnect": "Desconectar conta Google",
    "google/documentation": "Consultar documentação Google",
    "google/executar-vencidos": "Executar tarefas vencidas",
    "google/execute-action": "Executar operação de escrita Google",
    "google/execute-read": "Executar operação de leitura Google",
    "google/export-template": "Exportar modelo de configuração",
    "google/export-to-sheet": "Exportar relatório para planilha",
    "google/get-job": "Consultar tarefa Google",
    "google/get-schedule": "Consultar agendamento de relatório",
    "google/integration-status": "Consultar integração com Site Core",
    "google/list-accounts": "Listar contas Google",
    "google/list-actions": "Listar operações Google disponíveis",
    "google/list-connections": "Listar conexões Google",
    "google/list-fields": "Listar campos disponíveis para consulta",
    "google/list-jobs": "Listar tarefas Google",
    "google/maintenance": "Consultar manutenção do armazenamento",
    "google/mcp-read": "Executar habilidade Google de leitura",
    "google/mcp-write": "Executar habilidade Google de escrita",
    "google/plan-configuration": "Planejar configuração Google",
    "google/plan-policy": "Planejar permissões por recurso",
    "google/plan-template": "Planejar aplicação de modelo",
    "google/policy-discover-resources": "Descobrir recursos para autorização",
    "google/preflight": "Verificar requisitos da conexão Google",
    "google/prepare-job": "Preparar tarefa Google",
    "google/prepare-operation": "Preparar operação Google",
    "google/query": "Consultar dados Google",
    "google/readiness-status": "Consultar prontidão operacional",
    "google/reconcile-job": "Reconciliar resultado de tarefa",
    "google/recovery": "Executar recuperação do armazenamento",
    "google/recovery-status": "Consultar recuperação do armazenamento",
    "google/report-templates": "Listar modelos de relatórios",
    "google/resource-policy": "Consultar permissões por recurso",
    "google/run-job": "Executar tarefa Google",
    "google/run-report": "Gerar relatório Google",
    "google/schedule-report": "Agendar relatório Google",
    "google/selftest": "Testar conexão Google",
    "google/status": "Consultar estado do plugin Google",
    "google/storage-status": "Consultar estado do armazenamento",
    "google/verify-conversion-delivery": "Verificar destino de conversões",
    "gsc/add-site": "Adicionar propriedade ao Search Console",
    "gsc/delete-site": "Excluir propriedade do Search Console",
    "gsc/delete-sitemap": "Excluir mapa do site",
    "gsc/ensure-sitemap": "Garantir envio do mapa do site",
    "gsc/get-site": "Consultar propriedade do Search Console",
    "gsc/inspect-url": "Inspecionar endereço no índice do Google",
    "gsc/inspect-urls": "Inspecionar endereços em lote",
    "gsc/list-sitemaps": "Listar mapas do site",
    "gsc/list-sites": "Listar propriedades do Search Console",
    "gsc/migracao-conferir": "Conferir migração do Search Console",
    "gsc/preparar-site": "Preparar site no Search Console",
    "gsc/query": "Consultar desempenho de pesquisa",
    "gsc/submit-sitemap": "Enviar mapa do site",
    "gtm/bulk-update-workspace": "Atualizar área de trabalho em lote",
    "gtm/combine-container": "Combinar contêiner",
    "gtm/create-built-in-variable": "Criar variável integrada",
    "gtm/create-client": "Criar cliente",
    "gtm/create-container": "Criar contêiner",
    "gtm/create-environment": "Criar ambiente",
    "gtm/create-folder": "Criar pasta",
    "gtm/create-gtag-config": "Criar configuração da tag do Google",
    "gtm/create-tag": "Criar tag",
    "gtm/create-template": "Criar modelo",
    "gtm/create-transformation": "Criar transformação",
    "gtm/create-trigger": "Criar acionador",
    "gtm/create-user-permission": "Criar permissão de usuário",
    "gtm/create-variable": "Criar variável",
    "gtm/create-version-workspace": "Criar versão da área de trabalho",
    "gtm/create-workspace": "Criar área de trabalho",
    "gtm/create-zone": "Criar zona",
    "gtm/delete-built-in-variable": "Excluir variável integrada",
    "gtm/delete-client": "Excluir cliente",
    "gtm/delete-container": "Excluir contêiner",
    "gtm/delete-environment": "Excluir ambiente",
    "gtm/delete-folder": "Excluir pasta",
    "gtm/delete-gtag-config": "Excluir configuração da tag do Google",
    "gtm/delete-tag": "Excluir tag",
    "gtm/delete-template": "Excluir modelo",
    "gtm/delete-transformation": "Excluir transformação",
    "gtm/delete-trigger": "Excluir acionador",
    "gtm/delete-user-permission": "Excluir permissão de usuário",
    "gtm/delete-variable": "Excluir variável",
    "gtm/delete-version": "Excluir versão",
    "gtm/delete-workspace": "Excluir área de trabalho",
    "gtm/delete-zone": "Excluir zona",
    "gtm/diagnostico": "Diagnosticar configuração do Tag Manager",
    "gtm/entities-folder": "Listar itens da pasta",
    "gtm/get-account": "Consultar conta",
    "gtm/get-client": "Consultar cliente",
    "gtm/get-container": "Consultar contêiner",
    "gtm/get-destination": "Consultar destino",
    "gtm/get-environment": "Consultar ambiente",
    "gtm/get-folder": "Consultar pasta",
    "gtm/get-gtag-config": "Consultar configuração da tag do Google",
    "gtm/get-publication": "Consultar publicação do Tag Manager",
    "gtm/get-status-workspace": "Consultar estado da área de trabalho",
    "gtm/get-tag": "Consultar tag",
    "gtm/get-template": "Consultar modelo",
    "gtm/get-transformation": "Consultar transformação",
    "gtm/get-trigger": "Consultar acionador",
    "gtm/get-user-permission": "Consultar permissão de usuário",
    "gtm/get-variable": "Consultar variável",
    "gtm/get-version": "Consultar versão",
    "gtm/get-workspace": "Consultar área de trabalho",
    "gtm/get-zone": "Consultar zona",
    "gtm/import-from-gallery-template": "Importar modelo da galeria",
    "gtm/latest-version-header": "Consultar resumo da versão mais recente",
    "gtm/link-destination": "Vincular destino",
    "gtm/list-accounts": "Listar contas",
    "gtm/list-built-in-variables": "Listar variáveis integradas",
    "gtm/list-clients": "Listar clientes",
    "gtm/list-containers": "Listar contêineres",
    "gtm/list-destinations": "Listar destinos",
    "gtm/list-environments": "Listar ambientes",
    "gtm/list-folders": "Listar pastas",
    "gtm/list-gtag-config": "Listar configuração da tag do Google",
    "gtm/list-tags": "Listar tags",
    "gtm/list-templates": "Listar modelos",
    "gtm/list-transformations": "Listar transformações",
    "gtm/list-triggers": "Listar acionadores",
    "gtm/list-user-permissions": "Listar permissões de usuários",
    "gtm/list-variables": "Listar variáveis",
    "gtm/list-version-headers": "Listar resumos de versões",
    "gtm/list-workspaces": "Listar áreas de trabalho",
    "gtm/list-zones": "Listar zonas",
    "gtm/live-version": "Consultar versão em produção",
    "gtm/lookup-container": "Localizar contêiner",
    "gtm/move-entities-to-folder-folder": "Mover itens para pasta",
    "gtm/move-tag-id-container": "Mover identificador de tag entre contêineres",
    "gtm/publicar": "Publicar área de trabalho",
    "gtm/publish-version": "Publicar versão",
    "gtm/quick-preview-workspace": "Visualizar área de trabalho rapidamente",
    "gtm/reauthorize-environment": "Reautorizar ambiente",
    "gtm/resolve-conflict-workspace": "Resolver conflito da área de trabalho",
    "gtm/revert-built-in-variable": "Reverter variável integrada",
    "gtm/revert-client": "Reverter cliente",
    "gtm/revert-folder": "Reverter pasta",
    "gtm/revert-tag": "Reverter tag",
    "gtm/revert-template": "Reverter modelo",
    "gtm/revert-transformation": "Reverter transformação",
    "gtm/revert-trigger": "Reverter acionador",
    "gtm/revert-variable": "Reverter variável",
    "gtm/revert-zone": "Reverter zona",
    "gtm/reverter": "Reverter publicação do Tag Manager",
    "gtm/set-latest-version": "Definir versão mais recente",
    "gtm/snippet-container": "Obter trecho de instalação do contêiner",
    "gtm/sync-workspace": "Sincronizar área de trabalho",
    "gtm/undelete-version": "Restaurar versão",
    "gtm/update-account": "Atualizar conta",
    "gtm/update-client": "Atualizar cliente",
    "gtm/update-container": "Atualizar contêiner",
    "gtm/update-environment": "Atualizar ambiente",
    "gtm/update-folder": "Atualizar pasta",
    "gtm/update-gtag-config": "Atualizar configuração da tag do Google",
    "gtm/update-tag": "Atualizar tag",
    "gtm/update-template": "Atualizar modelo",
    "gtm/update-transformation": "Atualizar transformação",
    "gtm/update-trigger": "Atualizar acionador",
    "gtm/update-user-permission": "Atualizar permissão de usuário",
    "gtm/update-variable": "Atualizar variável",
    "gtm/update-version": "Atualizar versão",
    "gtm/update-workspace": "Atualizar área de trabalho",
    "gtm/update-zone": "Atualizar zona",
    "siteverification/get-token": "Obter código de verificação do site",
    "siteverification/list": "Listar sites verificados",
    "siteverification/update-owners": "Atualizar proprietários do site",
    "siteverification/verify": "Verificar propriedade do site",
    "google/rename-connection": "Renomear conexão Google",
    "google/plan-identity-change": "Simular troca de identidade Google",
    "google/switch-identity": "Trocar identidade Google"
  },
  "operations": {
    "analyticsadmin.accountSummaries.list": {
      "label": "Listar resumos das contas",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.accountSummaries.list."
    },
    "analyticsadmin.accounts.accessBindings.create": {
      "label": "Criar acessos da conta",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.accounts.accessBindings.create."
    },
    "analyticsadmin.accounts.accessBindings.delete": {
      "label": "Excluir acessos da conta",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.accounts.accessBindings.delete."
    },
    "analyticsadmin.accounts.accessBindings.get": {
      "label": "Consultar acessos da conta",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.accounts.accessBindings.get."
    },
    "analyticsadmin.accounts.accessBindings.list": {
      "label": "Listar acessos da conta",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.accounts.accessBindings.list."
    },
    "analyticsadmin.accounts.accessBindings.patch": {
      "label": "Atualizar acessos da conta",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.accounts.accessBindings.patch."
    },
    "analyticsadmin.accounts.delete": {
      "label": "Excluir contas",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.accounts.delete."
    },
    "analyticsadmin.accounts.get": {
      "label": "Consultar contas",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.accounts.get."
    },
    "analyticsadmin.properties.accessBindings.create": {
      "label": "Criar acessos da propriedade",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.accessBindings.create."
    },
    "analyticsadmin.properties.accessBindings.delete": {
      "label": "Excluir acessos da propriedade",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.accessBindings.delete."
    },
    "analyticsadmin.properties.accessBindings.get": {
      "label": "Consultar acessos da propriedade",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.accessBindings.get."
    },
    "analyticsadmin.properties.accessBindings.list": {
      "label": "Listar acessos da propriedade",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.accessBindings.list."
    },
    "analyticsadmin.properties.accessBindings.patch": {
      "label": "Atualizar acessos da propriedade",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.accessBindings.patch."
    },
    "analyticsadmin.properties.audiences.archive": {
      "label": "Arquivar públicos",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.audiences.archive."
    },
    "analyticsadmin.properties.audiences.create": {
      "label": "Criar públicos",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.audiences.create."
    },
    "analyticsadmin.properties.audiences.get": {
      "label": "Consultar públicos",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.audiences.get."
    },
    "analyticsadmin.properties.audiences.list": {
      "label": "Listar públicos",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.audiences.list."
    },
    "analyticsadmin.properties.audiences.patch": {
      "label": "Atualizar públicos",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.audiences.patch."
    },
    "analyticsadmin.properties.create": {
      "label": "Criar propriedades",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.create."
    },
    "analyticsadmin.properties.customDimensions.archive": {
      "label": "Arquivar dimensões personalizadas",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.customDimensions.archive."
    },
    "analyticsadmin.properties.customDimensions.create": {
      "label": "Criar dimensões personalizadas",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.customDimensions.create."
    },
    "analyticsadmin.properties.customDimensions.get": {
      "label": "Consultar dimensões personalizadas",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.customDimensions.get."
    },
    "analyticsadmin.properties.customDimensions.list": {
      "label": "Listar dimensões personalizadas",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.customDimensions.list."
    },
    "analyticsadmin.properties.customDimensions.patch": {
      "label": "Atualizar dimensões personalizadas",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.customDimensions.patch."
    },
    "analyticsadmin.properties.customMetrics.archive": {
      "label": "Arquivar métricas personalizadas",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.customMetrics.archive."
    },
    "analyticsadmin.properties.customMetrics.create": {
      "label": "Criar métricas personalizadas",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.customMetrics.create."
    },
    "analyticsadmin.properties.customMetrics.get": {
      "label": "Consultar métricas personalizadas",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.customMetrics.get."
    },
    "analyticsadmin.properties.customMetrics.list": {
      "label": "Listar métricas personalizadas",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.customMetrics.list."
    },
    "analyticsadmin.properties.customMetrics.patch": {
      "label": "Atualizar métricas personalizadas",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.customMetrics.patch."
    },
    "analyticsadmin.properties.dataStreams.create": {
      "label": "Criar fluxos de dados",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.dataStreams.create."
    },
    "analyticsadmin.properties.dataStreams.delete": {
      "label": "Excluir fluxos de dados",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.dataStreams.delete."
    },
    "analyticsadmin.properties.dataStreams.get": {
      "label": "Consultar fluxos de dados",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.dataStreams.get."
    },
    "analyticsadmin.properties.dataStreams.getDataRedactionSettings": {
      "label": "Consultar configurações de ocultação de dados das fluxos de dados",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.dataStreams.getDataRedactionSettings."
    },
    "analyticsadmin.properties.dataStreams.getEnhancedMeasurementSettings": {
      "label": "Consultar configurações de medição otimizada das fluxos de dados",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.dataStreams.getEnhancedMeasurementSettings."
    },
    "analyticsadmin.properties.dataStreams.list": {
      "label": "Listar fluxos de dados",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.dataStreams.list."
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.create": {
      "label": "Criar segredos do protocolo de medição",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.dataStreams.measurementProtocolSecrets.create."
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.delete": {
      "label": "Excluir segredos do protocolo de medição",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.dataStreams.measurementProtocolSecrets.delete."
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.get": {
      "label": "Consultar segredos do protocolo de medição",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.dataStreams.measurementProtocolSecrets.get."
    },
    "analyticsadmin.properties.dataStreams.measurementProtocolSecrets.list": {
      "label": "Listar segredos do protocolo de medição",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.dataStreams.measurementProtocolSecrets.list."
    },
    "analyticsadmin.properties.dataStreams.patch": {
      "label": "Atualizar fluxos de dados",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.dataStreams.patch."
    },
    "analyticsadmin.properties.dataStreams.updateDataRedactionSettings": {
      "label": "Atualizar configurações de ocultação de dados das fluxos de dados",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.dataStreams.updateDataRedactionSettings."
    },
    "analyticsadmin.properties.dataStreams.updateEnhancedMeasurementSettings": {
      "label": "Atualizar configurações de medição otimizada das fluxos de dados",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.dataStreams.updateEnhancedMeasurementSettings."
    },
    "analyticsadmin.properties.delete": {
      "label": "Excluir propriedades",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.delete."
    },
    "analyticsadmin.properties.get": {
      "label": "Consultar propriedades",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.get."
    },
    "analyticsadmin.properties.getAttributionSettings": {
      "label": "Consultar configurações de atribuição das propriedades",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.getAttributionSettings."
    },
    "analyticsadmin.properties.getDataRetentionSettings": {
      "label": "Consultar configurações de retenção de dados das propriedades",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.getDataRetentionSettings."
    },
    "analyticsadmin.properties.getGoogleSignalsSettings": {
      "label": "Consultar configurações de sinais do Google das propriedades",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.getGoogleSignalsSettings."
    },
    "analyticsadmin.properties.googleAdsLinks.create": {
      "label": "Criar vínculos com Google Ads",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.googleAdsLinks.create."
    },
    "analyticsadmin.properties.googleAdsLinks.delete": {
      "label": "Excluir vínculos com Google Ads",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.googleAdsLinks.delete."
    },
    "analyticsadmin.properties.googleAdsLinks.list": {
      "label": "Listar vínculos com Google Ads",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.googleAdsLinks.list."
    },
    "analyticsadmin.properties.googleAdsLinks.patch": {
      "label": "Atualizar vínculos com Google Ads",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.googleAdsLinks.patch."
    },
    "analyticsadmin.properties.keyEvents.create": {
      "label": "Criar eventos principais",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.keyEvents.create."
    },
    "analyticsadmin.properties.keyEvents.delete": {
      "label": "Excluir eventos principais",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.keyEvents.delete."
    },
    "analyticsadmin.properties.keyEvents.get": {
      "label": "Consultar eventos principais",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.keyEvents.get."
    },
    "analyticsadmin.properties.keyEvents.list": {
      "label": "Listar eventos principais",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.keyEvents.list."
    },
    "analyticsadmin.properties.keyEvents.patch": {
      "label": "Atualizar eventos principais",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.keyEvents.patch."
    },
    "analyticsadmin.properties.patch": {
      "label": "Atualizar propriedades",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.patch."
    },
    "analyticsadmin.properties.reportingDataAnnotations.create": {
      "label": "Criar anotações de relatórios",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.reportingDataAnnotations.create."
    },
    "analyticsadmin.properties.reportingDataAnnotations.delete": {
      "label": "Excluir anotações de relatórios",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.reportingDataAnnotations.delete."
    },
    "analyticsadmin.properties.reportingDataAnnotations.get": {
      "label": "Consultar anotações de relatórios",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.reportingDataAnnotations.get."
    },
    "analyticsadmin.properties.reportingDataAnnotations.list": {
      "label": "Listar anotações de relatórios",
      "description": "Habilidade: google/execute-read. Método: analyticsadmin.properties.reportingDataAnnotations.list."
    },
    "analyticsadmin.properties.reportingDataAnnotations.patch": {
      "label": "Atualizar anotações de relatórios",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.reportingDataAnnotations.patch."
    },
    "analyticsadmin.properties.updateAttributionSettings": {
      "label": "Atualizar configurações de atribuição das propriedades",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.updateAttributionSettings."
    },
    "analyticsadmin.properties.updateDataRetentionSettings": {
      "label": "Atualizar configurações de retenção de dados das propriedades",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.updateDataRetentionSettings."
    },
    "analyticsadmin.properties.updateGoogleSignalsSettings": {
      "label": "Atualizar configurações de sinais do Google das propriedades",
      "description": "Habilidade: google/execute-action. Método: analyticsadmin.properties.updateGoogleSignalsSettings."
    },
    "analyticsdata.properties.getMetadata": {
      "label": "Consultar dimensões e métricas disponíveis",
      "description": "Habilidade: google/execute-read. Método: analyticsdata.properties.getMetadata."
    },
    "analyticsdata.properties.runFunnelReport": {
      "label": "Gerar relatório de funil",
      "description": "Habilidade: google/execute-read. Método: analyticsdata.properties.runFunnelReport."
    },
    "analyticsdata.properties.runReport": {
      "label": "Gerar relatório padrão",
      "description": "Habilidade: google/execute-read. Método: analyticsdata.properties.runReport."
    },
    "analyticsdata.properties.batchRunPivotReports": {
      "label": "Gerar relatórios de tabela dinâmica em lote",
      "description": "Habilidade: google/execute-read. Método: analyticsdata.properties.batchRunPivotReports."
    },
    "analyticsdata.properties.batchRunReports": {
      "label": "Gerar relatórios padrão em lote",
      "description": "Habilidade: google/execute-read. Método: analyticsdata.properties.batchRunReports."
    },
    "analyticsdata.properties.checkCompatibility": {
      "label": "Verificar compatibilidade de dimensões e métricas",
      "description": "Habilidade: google/execute-read. Método: analyticsdata.properties.checkCompatibility."
    },
    "analyticsdata.properties.runPivotReport": {
      "label": "Gerar relatório de tabela dinâmica",
      "description": "Habilidade: google/execute-read. Método: analyticsdata.properties.runPivotReport."
    },
    "analyticsdata.properties.runRealtimeReport": {
      "label": "Gerar relatório em tempo real",
      "description": "Habilidade: google/execute-read. Método: analyticsdata.properties.runRealtimeReport."
    },
    "googleads.customers.adGroupAds.mutate": {
      "label": "Alterar anúncios dos grupos",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.adGroupAds.mutate."
    },
    "googleads.customers.adGroupAssets.mutate": {
      "label": "Alterar recursos dos grupos de anúncios",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.adGroupAssets.mutate."
    },
    "googleads.customers.adGroupCriteria.mutate": {
      "label": "Alterar critérios dos grupos de anúncios",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.adGroupCriteria.mutate."
    },
    "googleads.customers.adGroupLabels.mutate": {
      "label": "Alterar marcadores dos grupos de anúncios",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.adGroupLabels.mutate."
    },
    "googleads.customers.adGroups.mutate": {
      "label": "Alterar grupos de anúncios",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.adGroups.mutate."
    },
    "googleads.customers.assetGroups.mutate": {
      "label": "Alterar grupos de recursos",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.assetGroups.mutate."
    },
    "googleads.customers.assets.mutate": {
      "label": "Alterar recursos de anúncios",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.assets.mutate."
    },
    "googleads.customers.billingSetups.mutate": {
      "label": "Alterar configurações de faturamento",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.billingSetups.mutate."
    },
    "googleads.customers.campaignAssets.mutate": {
      "label": "Alterar recursos das campanhas",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.campaignAssets.mutate."
    },
    "googleads.customers.campaignBudgets.mutate": {
      "label": "Alterar orçamentos das campanhas",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.campaignBudgets.mutate."
    },
    "googleads.customers.campaignCriteria.mutate": {
      "label": "Alterar critérios das campanhas",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.campaignCriteria.mutate."
    },
    "googleads.customers.campaignLabels.mutate": {
      "label": "Alterar marcadores das campanhas",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.campaignLabels.mutate."
    },
    "googleads.customers.campaigns.mutate": {
      "label": "Alterar campanhas",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.campaigns.mutate."
    },
    "googleads.customers.conversionActions.mutate": {
      "label": "Alterar ações de conversão",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.conversionActions.mutate."
    },
    "googleads.customers.customerUserAccessInvitations.mutate": {
      "label": "Alterar convites de acesso à conta",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.customerUserAccessInvitations.mutate."
    },
    "googleads.customers.customerUserAccesses.mutate": {
      "label": "Alterar acessos de usuários à conta",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.customerUserAccesses.mutate."
    },
    "googleads.customers.experiments.mutate": {
      "label": "Alterar experimentos",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.experiments.mutate."
    },
    "googleads.customers.experiments.scheduleExperiment": {
      "label": "Agendar experimentos",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.experiments.scheduleExperiment."
    },
    "googleads.customers.googleAds.mutate": {
      "label": "Alterar dados do Google Ads",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.googleAds.mutate."
    },
    "googleads.customers.googleAds.search": {
      "label": "Pesquisar dados do Google Ads",
      "description": "Habilidade: google/execute-read. Método: googleads.customers.googleAds.search."
    },
    "googleads.customers.googleAds.searchStream": {
      "label": "Pesquisar em fluxo dados do Google Ads",
      "description": "Habilidade: google/execute-read. Método: googleads.customers.googleAds.searchStream."
    },
    "googleads.customers.labels.mutate": {
      "label": "Alterar marcadores",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.labels.mutate."
    },
    "googleads.customers.listAccessibleCustomers": {
      "label": "Listar contas de anúncios acessíveis",
      "description": "Habilidade: google/execute-read. Método: googleads.customers.listAccessibleCustomers."
    },
    "googleads.customers.offlineUserDataJobs.addOperations": {
      "label": "Adicionar operações às tarefas de importação de dados de usuários",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.offlineUserDataJobs.addOperations."
    },
    "googleads.customers.offlineUserDataJobs.create": {
      "label": "Criar tarefas de importação de dados de usuários",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.offlineUserDataJobs.create."
    },
    "googleads.customers.offlineUserDataJobs.run": {
      "label": "Executar tarefas de importação de dados de usuários",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.offlineUserDataJobs.run."
    },
    "googleads.customers.uploadClickConversions": {
      "label": "Importar conversões de clique",
      "description": "Habilidade: ads/upload-click-conversions. Método: googleads.customers.uploadClickConversions."
    },
    "googleads.customers.userLists.mutate": {
      "label": "Alterar listas de usuários",
      "description": "Habilidade: google/execute-action. Método: googleads.customers.userLists.mutate."
    },
    "googleads.googleAdsFields.search": {
      "label": "Pesquisar campos do Google Ads",
      "description": "Habilidade: google/execute-read. Método: googleads.googleAdsFields.search."
    },
    "searchconsole.urlInspection.index.inspect": {
      "label": "Inspecionar endereço no índice do Google",
      "description": "Habilidade: google/execute-read. Método: searchconsole.urlInspection.index.inspect."
    },
    "webmasters.searchanalytics.query": {
      "label": "Consultar desempenho de pesquisa",
      "description": "Habilidade: google/execute-read. Método: webmasters.searchanalytics.query."
    },
    "webmasters.sitemaps.delete": {
      "label": "Excluir mapas do site",
      "description": "Habilidade: google/execute-action. Método: webmasters.sitemaps.delete."
    },
    "webmasters.sitemaps.get": {
      "label": "Consultar mapas do site",
      "description": "Habilidade: google/execute-read. Método: webmasters.sitemaps.get."
    },
    "webmasters.sitemaps.list": {
      "label": "Listar mapas do site",
      "description": "Habilidade: google/execute-read. Método: webmasters.sitemaps.list."
    },
    "webmasters.sitemaps.submit": {
      "label": "Enviar mapas do site",
      "description": "Habilidade: google/execute-action. Método: webmasters.sitemaps.submit."
    },
    "webmasters.sites.add": {
      "label": "Adicionar propriedades Search Console",
      "description": "Habilidade: google/execute-action. Método: webmasters.sites.add."
    },
    "webmasters.sites.delete": {
      "label": "Excluir propriedades Search Console",
      "description": "Habilidade: google/execute-action. Método: webmasters.sites.delete."
    },
    "webmasters.sites.get": {
      "label": "Consultar propriedades Search Console",
      "description": "Habilidade: google/execute-read. Método: webmasters.sites.get."
    },
    "webmasters.sites.list": {
      "label": "Listar propriedades Search Console",
      "description": "Habilidade: google/execute-read. Método: webmasters.sites.list."
    },
    "siteVerification.webResource.get": {
      "label": "Consultar sites verificados",
      "description": "Habilidade: google/execute-read. Método: siteVerification.webResource.get."
    },
    "siteVerification.webResource.getToken": {
      "label": "Obter código de verificação do site",
      "description": "Habilidade: google/execute-read. Método: siteVerification.webResource.getToken."
    },
    "siteVerification.webResource.insert": {
      "label": "Verificar propriedade dos sites verificados",
      "description": "Habilidade: google/execute-action. Método: siteVerification.webResource.insert."
    },
    "siteVerification.webResource.list": {
      "label": "Listar sites verificados",
      "description": "Habilidade: google/execute-read. Método: siteVerification.webResource.list."
    },
    "siteVerification.webResource.update": {
      "label": "Atualizar sites verificados",
      "description": "Habilidade: google/execute-action. Método: siteVerification.webResource.update."
    },
    "sheets.spreadsheets.batchUpdate": {
      "label": "Atualizar em lote planilhas",
      "description": "Habilidade: google/execute-action. Método: sheets.spreadsheets.batchUpdate."
    },
    "sheets.spreadsheets.get": {
      "label": "Consultar planilhas",
      "description": "Habilidade: google/execute-read. Método: sheets.spreadsheets.get."
    },
    "sheets.spreadsheets.values.append": {
      "label": "Acrescentar valores às células",
      "description": "Habilidade: google/execute-action. Método: sheets.spreadsheets.values.append."
    },
    "sheets.spreadsheets.values.batchGet": {
      "label": "Consultar em lote células",
      "description": "Habilidade: google/execute-action. Método: sheets.spreadsheets.values.batchGet."
    },
    "sheets.spreadsheets.values.batchUpdate": {
      "label": "Atualizar em lote células",
      "description": "Habilidade: google/execute-action. Método: sheets.spreadsheets.values.batchUpdate."
    },
    "sheets.spreadsheets.values.clear": {
      "label": "Limpar células",
      "description": "Habilidade: google/execute-action. Método: sheets.spreadsheets.values.clear."
    },
    "sheets.spreadsheets.values.get": {
      "label": "Consultar células",
      "description": "Habilidade: google/execute-read. Método: sheets.spreadsheets.values.get."
    },
    "sheets.spreadsheets.values.update": {
      "label": "Atualizar células",
      "description": "Habilidade: google/execute-action. Método: sheets.spreadsheets.values.update."
    },
    "drive.files.create": {
      "label": "Criar arquivos",
      "description": "Habilidade: google/execute-action. Método: drive.files.create."
    },
    "drive.files.get": {
      "label": "Consultar arquivos",
      "description": "Habilidade: google/execute-read. Método: drive.files.get."
    },
    "drive.files.list": {
      "label": "Listar arquivos",
      "description": "Habilidade: google/execute-read. Método: drive.files.list."
    },
    "drive.files.update": {
      "label": "Atualizar arquivos",
      "description": "Habilidade: google/execute-action. Método: drive.files.update."
    },
    "drive.permissions.create": {
      "label": "Criar permissões de arquivos",
      "description": "Habilidade: google/execute-action. Método: drive.permissions.create."
    },
    "drive.permissions.delete": {
      "label": "Excluir permissões de arquivos",
      "description": "Habilidade: google/execute-action. Método: drive.permissions.delete."
    },
    "drive.permissions.get": {
      "label": "Consultar permissões de arquivos",
      "description": "Habilidade: google/execute-read. Método: drive.permissions.get."
    },
    "drive.permissions.list": {
      "label": "Listar permissões de arquivos",
      "description": "Habilidade: google/execute-read. Método: drive.permissions.list."
    },
    "drive.permissions.update": {
      "label": "Atualizar permissões de arquivos",
      "description": "Habilidade: google/execute-action. Método: drive.permissions.update."
    },
    "tagmanager.accounts.containers.create": {
      "label": "Criar contêineres",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.create."
    },
    "tagmanager.accounts.containers.delete": {
      "label": "Excluir contêineres",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.delete."
    },
    "tagmanager.accounts.containers.environments.create": {
      "label": "Criar ambientes",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.environments.create."
    },
    "tagmanager.accounts.containers.environments.delete": {
      "label": "Excluir ambientes",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.environments.delete."
    },
    "tagmanager.accounts.containers.environments.get": {
      "label": "Consultar ambientes",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.environments.get."
    },
    "tagmanager.accounts.containers.environments.list": {
      "label": "Listar ambientes",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.environments.list."
    },
    "tagmanager.accounts.containers.environments.reauthorize": {
      "label": "Reautorizar ambientes",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.environments.reauthorize."
    },
    "tagmanager.accounts.containers.environments.update": {
      "label": "Atualizar ambientes",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.environments.update."
    },
    "tagmanager.accounts.containers.get": {
      "label": "Consultar contêineres",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.get."
    },
    "tagmanager.accounts.containers.list": {
      "label": "Listar contêineres",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.list."
    },
    "tagmanager.accounts.containers.snippet": {
      "label": "Obter trecho de instalação dos contêineres",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.snippet."
    },
    "tagmanager.accounts.containers.update": {
      "label": "Atualizar contêineres",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.update."
    },
    "tagmanager.accounts.containers.version_headers.latest": {
      "label": "Consultar mais recentes resumos de versões",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.version_headers.latest."
    },
    "tagmanager.accounts.containers.version_headers.list": {
      "label": "Listar resumos de versões",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.version_headers.list."
    },
    "tagmanager.accounts.containers.versions.delete": {
      "label": "Excluir versões",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.versions.delete."
    },
    "tagmanager.accounts.containers.versions.get": {
      "label": "Consultar versões",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.versions.get."
    },
    "tagmanager.accounts.containers.versions.live": {
      "label": "Consultar em produção versões",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.versions.live."
    },
    "tagmanager.accounts.containers.versions.publish": {
      "label": "Publicar versões",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.versions.publish."
    },
    "tagmanager.accounts.containers.versions.set_latest": {
      "label": "Definir mais recentes versões",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.versions.set_latest."
    },
    "tagmanager.accounts.containers.versions.undelete": {
      "label": "Restaurar versões",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.versions.undelete."
    },
    "tagmanager.accounts.containers.versions.update": {
      "label": "Atualizar versões",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.versions.update."
    },
    "tagmanager.accounts.containers.workspaces.built_in_variables.create": {
      "label": "Criar variáveis integradas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.built_in_variables.create."
    },
    "tagmanager.accounts.containers.workspaces.built_in_variables.delete": {
      "label": "Excluir variáveis integradas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.built_in_variables.delete."
    },
    "tagmanager.accounts.containers.workspaces.built_in_variables.list": {
      "label": "Listar variáveis integradas",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.built_in_variables.list."
    },
    "tagmanager.accounts.containers.workspaces.built_in_variables.revert": {
      "label": "Reverter variáveis integradas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.built_in_variables.revert."
    },
    "tagmanager.accounts.containers.workspaces.bulk_update": {
      "label": "Atualizar em lote áreas de trabalho",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.bulk_update."
    },
    "tagmanager.accounts.containers.workspaces.clients.create": {
      "label": "Criar clientes",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.clients.create."
    },
    "tagmanager.accounts.containers.workspaces.clients.delete": {
      "label": "Excluir clientes",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.clients.delete."
    },
    "tagmanager.accounts.containers.workspaces.clients.get": {
      "label": "Consultar clientes",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.clients.get."
    },
    "tagmanager.accounts.containers.workspaces.clients.list": {
      "label": "Listar clientes",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.clients.list."
    },
    "tagmanager.accounts.containers.workspaces.clients.revert": {
      "label": "Reverter clientes",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.clients.revert."
    },
    "tagmanager.accounts.containers.workspaces.clients.update": {
      "label": "Atualizar clientes",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.clients.update."
    },
    "tagmanager.accounts.containers.workspaces.create": {
      "label": "Criar áreas de trabalho",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.create."
    },
    "tagmanager.accounts.containers.workspaces.create_version": {
      "label": "Criar versão das áreas de trabalho",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.create_version."
    },
    "tagmanager.accounts.containers.workspaces.delete": {
      "label": "Excluir áreas de trabalho",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.delete."
    },
    "tagmanager.accounts.containers.workspaces.folders.create": {
      "label": "Criar pastas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.folders.create."
    },
    "tagmanager.accounts.containers.workspaces.folders.delete": {
      "label": "Excluir pastas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.folders.delete."
    },
    "tagmanager.accounts.containers.workspaces.folders.entities": {
      "label": "Listar itens das pastas",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.folders.entities."
    },
    "tagmanager.accounts.containers.workspaces.folders.get": {
      "label": "Consultar pastas",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.folders.get."
    },
    "tagmanager.accounts.containers.workspaces.folders.list": {
      "label": "Listar pastas",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.folders.list."
    },
    "tagmanager.accounts.containers.workspaces.folders.move_entities_to_folder": {
      "label": "Mover itens para pastas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.folders.move_entities_to_folder."
    },
    "tagmanager.accounts.containers.workspaces.folders.revert": {
      "label": "Reverter pastas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.folders.revert."
    },
    "tagmanager.accounts.containers.workspaces.folders.update": {
      "label": "Atualizar pastas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.folders.update."
    },
    "tagmanager.accounts.containers.workspaces.get": {
      "label": "Consultar áreas de trabalho",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.get."
    },
    "tagmanager.accounts.containers.workspaces.getStatus": {
      "label": "Consultar estado da área de trabalho",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.getStatus."
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.create": {
      "label": "Criar configurações da tag do Google",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.gtag_config.create."
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.delete": {
      "label": "Excluir configurações da tag do Google",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.gtag_config.delete."
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.get": {
      "label": "Consultar configurações da tag do Google",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.gtag_config.get."
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.list": {
      "label": "Listar configurações da tag do Google",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.gtag_config.list."
    },
    "tagmanager.accounts.containers.workspaces.gtag_config.update": {
      "label": "Atualizar configurações da tag do Google",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.gtag_config.update."
    },
    "tagmanager.accounts.containers.workspaces.list": {
      "label": "Listar áreas de trabalho",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.list."
    },
    "tagmanager.accounts.containers.workspaces.quick_preview": {
      "label": "Visualizar rapidamente áreas de trabalho",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.quick_preview."
    },
    "tagmanager.accounts.containers.workspaces.resolve_conflict": {
      "label": "Resolver conflitos das áreas de trabalho",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.resolve_conflict."
    },
    "tagmanager.accounts.containers.workspaces.sync": {
      "label": "Sincronizar áreas de trabalho",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.sync."
    },
    "tagmanager.accounts.containers.workspaces.tags.create": {
      "label": "Criar tags",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.tags.create."
    },
    "tagmanager.accounts.containers.workspaces.tags.delete": {
      "label": "Excluir tags",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.tags.delete."
    },
    "tagmanager.accounts.containers.workspaces.tags.get": {
      "label": "Consultar tags",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.tags.get."
    },
    "tagmanager.accounts.containers.workspaces.tags.list": {
      "label": "Listar tags",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.tags.list."
    },
    "tagmanager.accounts.containers.workspaces.tags.revert": {
      "label": "Reverter tags",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.tags.revert."
    },
    "tagmanager.accounts.containers.workspaces.tags.update": {
      "label": "Atualizar tags",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.tags.update."
    },
    "tagmanager.accounts.containers.workspaces.templates.create": {
      "label": "Criar modelos",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.templates.create."
    },
    "tagmanager.accounts.containers.workspaces.templates.delete": {
      "label": "Excluir modelos",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.templates.delete."
    },
    "tagmanager.accounts.containers.workspaces.templates.get": {
      "label": "Consultar modelos",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.templates.get."
    },
    "tagmanager.accounts.containers.workspaces.templates.import_from_gallery": {
      "label": "Importar da galeria modelos",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.templates.import_from_gallery."
    },
    "tagmanager.accounts.containers.workspaces.templates.list": {
      "label": "Listar modelos",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.templates.list."
    },
    "tagmanager.accounts.containers.workspaces.templates.revert": {
      "label": "Reverter modelos",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.templates.revert."
    },
    "tagmanager.accounts.containers.workspaces.templates.update": {
      "label": "Atualizar modelos",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.templates.update."
    },
    "tagmanager.accounts.containers.workspaces.transformations.create": {
      "label": "Criar transformações",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.transformations.create."
    },
    "tagmanager.accounts.containers.workspaces.transformations.delete": {
      "label": "Excluir transformações",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.transformations.delete."
    },
    "tagmanager.accounts.containers.workspaces.transformations.get": {
      "label": "Consultar transformações",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.transformations.get."
    },
    "tagmanager.accounts.containers.workspaces.transformations.list": {
      "label": "Listar transformações",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.transformations.list."
    },
    "tagmanager.accounts.containers.workspaces.transformations.revert": {
      "label": "Reverter transformações",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.transformations.revert."
    },
    "tagmanager.accounts.containers.workspaces.transformations.update": {
      "label": "Atualizar transformações",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.transformations.update."
    },
    "tagmanager.accounts.containers.workspaces.triggers.create": {
      "label": "Criar acionadores",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.triggers.create."
    },
    "tagmanager.accounts.containers.workspaces.triggers.delete": {
      "label": "Excluir acionadores",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.triggers.delete."
    },
    "tagmanager.accounts.containers.workspaces.triggers.get": {
      "label": "Consultar acionadores",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.triggers.get."
    },
    "tagmanager.accounts.containers.workspaces.triggers.list": {
      "label": "Listar acionadores",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.triggers.list."
    },
    "tagmanager.accounts.containers.workspaces.triggers.revert": {
      "label": "Reverter acionadores",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.triggers.revert."
    },
    "tagmanager.accounts.containers.workspaces.triggers.update": {
      "label": "Atualizar acionadores",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.triggers.update."
    },
    "tagmanager.accounts.containers.workspaces.update": {
      "label": "Atualizar áreas de trabalho",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.update."
    },
    "tagmanager.accounts.containers.workspaces.variables.create": {
      "label": "Criar variáveis",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.variables.create."
    },
    "tagmanager.accounts.containers.workspaces.variables.delete": {
      "label": "Excluir variáveis",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.variables.delete."
    },
    "tagmanager.accounts.containers.workspaces.variables.get": {
      "label": "Consultar variáveis",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.variables.get."
    },
    "tagmanager.accounts.containers.workspaces.variables.list": {
      "label": "Listar variáveis",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.variables.list."
    },
    "tagmanager.accounts.containers.workspaces.variables.revert": {
      "label": "Reverter variáveis",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.variables.revert."
    },
    "tagmanager.accounts.containers.workspaces.variables.update": {
      "label": "Atualizar variáveis",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.variables.update."
    },
    "tagmanager.accounts.containers.workspaces.zones.create": {
      "label": "Criar zonas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.zones.create."
    },
    "tagmanager.accounts.containers.workspaces.zones.delete": {
      "label": "Excluir zonas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.zones.delete."
    },
    "tagmanager.accounts.containers.workspaces.zones.get": {
      "label": "Consultar zonas",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.zones.get."
    },
    "tagmanager.accounts.containers.workspaces.zones.list": {
      "label": "Listar zonas",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.containers.workspaces.zones.list."
    },
    "tagmanager.accounts.containers.workspaces.zones.revert": {
      "label": "Reverter zonas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.zones.revert."
    },
    "tagmanager.accounts.containers.workspaces.zones.update": {
      "label": "Atualizar zonas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.containers.workspaces.zones.update."
    },
    "tagmanager.accounts.get": {
      "label": "Consultar contas",
      "description": "Habilidade: google/execute-read. Método: tagmanager.accounts.get."
    },
    "tagmanager.accounts.update": {
      "label": "Atualizar contas",
      "description": "Habilidade: google/execute-action. Método: tagmanager.accounts.update."
    },
    "datamanager.events.ingest": {
      "label": "Importar conversões pela Data Manager",
      "description": "Habilidade: google/verify-conversion-delivery. Método: datamanager.events.ingest."
    },
    "datamanager.requestStatus.retrieve": {
      "label": "Consultar confirmação do processamento de conversões",
      "description": "Uso interno pela reconciliação do Site Core. Consulte a prontidão com google/conversion-delivery-status. Método: datamanager.requestStatus.retrieve."
    },
    "measurementprotocol.collect": {
      "label": "Enviar eventos pelo protocolo de medição",
      "description": "Habilidade: ga/send-event. Método: measurementprotocol.collect."
    }
  },
  "descriptions": {
    "gtm/bulk-update-workspace": "Aplica várias alterações de entidades a uma área de trabalho numa só chamada. Entidades novas usam IDs temporários no formato \"new_<número>\" (por exemplo \"new_1\", \"new_2\"), que podem ser referenciados entre si, como uma tag criada dentro de uma pasta nova.",
    "gtm/combine-container": "Combina dois contêineres, mesclando as entidades do contêiner indicado neste contêiner.",
    "gtm/create-built-in-variable": "Ativa uma ou mais variáveis integradas na área de trabalho.",
    "gtm/create-client": "Cria um cliente do contêiner de servidor.",
    "gtm/create-container": "Cria um contêiner.",
    "gtm/create-environment": "Cria um ambiente do contêiner.",
    "gtm/create-folder": "Cria uma pasta da área de trabalho.",
    "gtm/create-gtag-config": "Cria uma configuração da tag do Google.",
    "gtm/create-tag": "Cria uma tag da área de trabalho.",
    "gtm/create-template": "Cria um modelo personalizado da área de trabalho.",
    "gtm/create-transformation": "Cria uma transformação da área de trabalho.",
    "gtm/create-trigger": "Cria um acionador da área de trabalho.",
    "gtm/create-user-permission": "Concede a um usuário acesso à conta e aos contêineres do Tag Manager.",
    "gtm/create-variable": "Cria uma variável da área de trabalho.",
    "gtm/create-version-workspace": "Cria uma versão do contêiner com as entidades da área de trabalho, exclui a área de trabalho e define a nova versão como base do contêiner.",
    "gtm/create-workspace": "Cria uma área de trabalho do contêiner.",
    "gtm/create-zone": "Cria uma zona da área de trabalho.",
    "gtm/delete-built-in-variable": "Desativa uma ou mais variáveis integradas na área de trabalho.",
    "gtm/delete-client": "Exclui um cliente do contêiner de servidor.",
    "gtm/delete-container": "Exclui um contêiner.",
    "gtm/delete-environment": "Exclui um ambiente do contêiner.",
    "gtm/delete-folder": "Exclui uma pasta da área de trabalho.",
    "gtm/delete-gtag-config": "Exclui uma configuração da tag do Google.",
    "gtm/delete-tag": "Exclui uma tag da área de trabalho.",
    "gtm/delete-template": "Exclui um modelo personalizado da área de trabalho.",
    "gtm/delete-transformation": "Exclui uma transformação da área de trabalho.",
    "gtm/delete-trigger": "Exclui um acionador da área de trabalho.",
    "gtm/delete-user-permission": "Remove um usuário da conta, revogando o acesso a ela e a todos os seus contêineres.",
    "gtm/delete-variable": "Exclui uma variável da área de trabalho.",
    "gtm/delete-version": "Exclui uma versão do contêiner.",
    "gtm/delete-workspace": "Exclui uma área de trabalho do contêiner.",
    "gtm/delete-zone": "Exclui uma zona da área de trabalho.",
    "gtm/entities-folder": "Lista as entidades (tags, acionadores e variáveis) contidas numa pasta da área de trabalho.",
    "gtm/get-account": "Consulta uma conta do Tag Manager.",
    "gtm/get-client": "Consulta um cliente do contêiner de servidor.",
    "gtm/get-container": "Consulta um contêiner.",
    "gtm/get-destination": "Consulta um destino vinculado ao contêiner.",
    "gtm/get-environment": "Consulta um ambiente do contêiner.",
    "gtm/get-folder": "Consulta uma pasta da área de trabalho.",
    "gtm/get-gtag-config": "Consulta uma configuração da tag do Google.",
    "gtm/get-status-workspace": "Identifica as entidades alteradas e as que estão em conflito na área de trabalho.",
    "gtm/get-tag": "Consulta uma tag da área de trabalho.",
    "gtm/get-template": "Consulta um modelo personalizado da área de trabalho.",
    "gtm/get-transformation": "Consulta uma transformação da área de trabalho.",
    "gtm/get-trigger": "Consulta um acionador da área de trabalho.",
    "gtm/get-user-permission": "Consulta o acesso de um usuário à conta e aos contêineres do Tag Manager.",
    "gtm/get-variable": "Consulta uma variável da área de trabalho.",
    "gtm/get-version": "Consulta uma versão do contêiner.",
    "gtm/get-workspace": "Consulta uma área de trabalho do contêiner.",
    "gtm/get-zone": "Consulta uma zona da área de trabalho.",
    "gtm/import-from-gallery-template": "Importa um modelo personalizado da Galeria de modelos da comunidade para a área de trabalho.",
    "gtm/latest-version-header": "Consulta o resumo da versão mais recente do contêiner.",
    "gtm/link-destination": "Vincula um destino a este contêiner e o desvincula do contêiner ao qual estava ligado.",
    "gtm/list-accounts": "Lista as contas do Tag Manager a que a credencial tem acesso.",
    "gtm/list-built-in-variables": "Lista as variáveis integradas ativadas na área de trabalho.",
    "gtm/list-clients": "Lista os clientes da área de trabalho.",
    "gtm/list-containers": "Lista os contêineres de uma conta do Tag Manager.",
    "gtm/list-destinations": "Lista os destinos vinculados a um contêiner.",
    "gtm/list-environments": "Lista os ambientes de um contêiner.",
    "gtm/list-folders": "Lista as pastas da área de trabalho.",
    "gtm/list-gtag-config": "Lista as configurações da tag do Google na área de trabalho.",
    "gtm/list-tags": "Lista as tags da área de trabalho.",
    "gtm/list-templates": "Lista os modelos personalizados da área de trabalho.",
    "gtm/list-transformations": "Lista as transformações da área de trabalho.",
    "gtm/list-triggers": "Lista os acionadores da área de trabalho.",
    "gtm/list-user-permissions": "Lista os usuários com acesso à conta, com as permissões de conta e de contêiner de cada um.",
    "gtm/list-variables": "Lista as variáveis da área de trabalho.",
    "gtm/list-version-headers": "Lista os resumos de todas as versões do contêiner.",
    "gtm/list-workspaces": "Lista as áreas de trabalho de um contêiner.",
    "gtm/list-zones": "Lista as zonas da área de trabalho.",
    "gtm/live-version": "Consulta a versão publicada (em produção) do contêiner.",
    "gtm/lookup-container": "Localiza um contêiner pelo ID de destino ou pelo ID de tag.",
    "gtm/move-entities-to-folder-folder": "Move entidades para uma pasta da área de trabalho. Com folder_id igual a 0, retira as entidades da pasta em que estão.",
    "gtm/move-tag-id-container": "Remove um ID de tag do contêiner.",
    "gtm/publish-version": "Publica uma versão do contêiner, que passa a ser a versão em produção.",
    "gtm/quick-preview-workspace": "Gera uma prévia rápida da área de trabalho, criando uma versão provisória do contêiner com todas as suas entidades, sem publicar.",
    "gtm/reauthorize-environment": "Gera um novo código de autorização para um ambiente do contêiner, invalidando o anterior.",
    "gtm/resolve-conflict-workspace": "Resolve um conflito de mesclagem de uma entidade da área de trabalho, substituindo-a pela entidade resolvida enviada no pedido.",
    "gtm/revert-built-in-variable": "Desfaz as alterações feitas em variáveis integradas na área de trabalho.",
    "gtm/revert-client": "Desfaz as alterações feitas em um cliente do contêiner de servidor.",
    "gtm/revert-folder": "Desfaz as alterações feitas em uma pasta da área de trabalho.",
    "gtm/revert-tag": "Desfaz as alterações feitas em uma tag da área de trabalho.",
    "gtm/revert-template": "Desfaz as alterações feitas em um modelo personalizado da área de trabalho.",
    "gtm/revert-transformation": "Desfaz as alterações feitas em uma transformação da área de trabalho.",
    "gtm/revert-trigger": "Desfaz as alterações feitas em um acionador da área de trabalho.",
    "gtm/revert-variable": "Desfaz as alterações feitas em uma variável da área de trabalho.",
    "gtm/revert-zone": "Desfaz as alterações feitas em uma zona da área de trabalho.",
    "gtm/set-latest-version": "Define a versão mais recente usada na sincronização das áreas de trabalho para detectar conflitos e erros.",
    "gtm/snippet-container": "Obtém o trecho de código de instalação do contêiner.",
    "gtm/sync-workspace": "Sincroniza a área de trabalho com a versão mais recente do contêiner: atualiza as entidades não alteradas e aponta conflitos nas alteradas.",
    "gtm/undelete-version": "Restaura uma versão do contêiner excluída.",
    "gtm/update-account": "Atualiza uma conta do Tag Manager.",
    "gtm/update-client": "Atualiza um cliente do contêiner de servidor.",
    "gtm/update-container": "Atualiza um contêiner.",
    "gtm/update-environment": "Atualiza um ambiente do contêiner.",
    "gtm/update-folder": "Atualiza uma pasta da área de trabalho.",
    "gtm/update-gtag-config": "Atualiza uma configuração da tag do Google.",
    "gtm/update-tag": "Atualiza uma tag da área de trabalho.",
    "gtm/update-template": "Atualiza um modelo personalizado da área de trabalho.",
    "gtm/update-transformation": "Atualiza uma transformação da área de trabalho.",
    "gtm/update-trigger": "Atualiza um acionador da área de trabalho.",
    "gtm/update-user-permission": "Atualiza o acesso de um usuário à conta e aos contêineres do Tag Manager.",
    "gtm/update-variable": "Atualiza uma variável da área de trabalho.",
    "gtm/update-version": "Atualiza o nome e as notas de uma versão do contêiner.",
    "gtm/update-workspace": "Atualiza uma área de trabalho do contêiner.",
    "gtm/update-zone": "Atualiza uma zona da área de trabalho."
  }
}
F3_LABELS_PT
,true,512,JSON_THROW_ON_ERROR);
        return $catalog;
    }
    public static function ability(string $name,string $fallback): string {return self::catalog()['abilities'][$name]??$fallback;}
    /** Reviewed Portuguese description; provider Discovery text is only a fallback. */
    public static function description(string $name,string $fallback): string {return self::catalog()['descriptions'][$name]??$fallback;}
}
