# Validação — 0.22.0

A release é verificada com suíte unitária completa, contratos nativos da base exata 0.21.0, instalação limpa em WP7.1.2/7.1.3, upgrade direto, Google primeiro e produtor isolado. Acompanhantes originais Core1.58.0/MCP0.34.0/Meta0.13.0/LinkedIn0.11.0. O teste adicional do patch Core é identificado separadamente. As contagens, hashes e resultados finais constam das evidências e do relatório externo.

Core323 usa consumidor real e Google real com HTTP interceptado: consentimento/tempo, concessão por ação, enhanced, evento estável, zero BRL, reserva, incerteza, deduplicação e consulta. Nenhum ensaio sintético é homologação Google real. O Site-Teste recebe apenas o Google e tem seu inventário registrado no relatório.
