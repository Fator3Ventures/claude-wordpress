# Atualização e recuperação — 0.22.0

Limpa ou direta da 0.21.0. Mesmo slug, opções e tabelas. Faça backup de arquivos/banco/salts e preserve credenciais, provas e recibos. Nunca desinstale para atualizar.

Nenhuma concessão comercial nasce automaticamente. Configure cada ação explicitamente e valide-a. Reverter para 0.21.0 exige suspender o consumidor comercial no Core; preservar recibos incertos e não repetir ingestão. Não há modificação automática dos acompanhantes. O patch Core entregue no fonte é integração separada.
