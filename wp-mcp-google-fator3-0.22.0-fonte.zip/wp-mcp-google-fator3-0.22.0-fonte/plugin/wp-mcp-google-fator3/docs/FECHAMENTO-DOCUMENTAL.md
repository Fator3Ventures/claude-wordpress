# Fechamento documental — 0.22.0

Catálogo e schemas gerados do runtime; documentos incorporados em PHP protegido. Guia corrente, exemplos, payload comercial e índice MCP pertencem à mesma versão. Candidato validado é promovido byte a byte; fonte inclui relatório pré-fechamento sem seu próprio hash. Relatório externo registra hashes finais e diferenças entre bancada e Site-Teste.
