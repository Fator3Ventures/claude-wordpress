# Contratos públicos entre plugins — 0.12.0

## Versão 0.22.0 — Pedidos Core 323

Base direta 0.21.0. O contrato opcional `site-conversion-delivery/1.2.0` atende ações Google Ads comerciais por etapa, com concessão independente para `site-core-quality` / `crm_stage`. Mantém aquisição 1.0/1.1, conversões otimizadas e pedidos Google 39–42. São 294 habilidades (113 leitura, 181 escrita), 38 opções, sem nova tabela ou segredo.

Core 1.58.0 implementa o consumidor de conversões otimizadas (Core 316) e o envio comercial (Core 323). Acompanhantes recebidos: MCP 0.34.0, Meta 0.13.0, LinkedIn 0.11.0; Pipedrive 0.2.0 disponível em pacote. O Site-Teste é inventariado separadamente. Nenhum mínimo próprio ou ordem de ativação dos acompanhantes foi imposto.

A aceitação inicial pela Data Manager é `incerto`. O produtor fornece `site-stage-conversion-reconcile/1.0.0`, consulta sem reenvio. Core 1.58.0 original ainda não consome essa confirmação comercial; o fonte desta entrega inclui implementação proposta em patch para esse consumidor, ensaiada separadamente. Não confundir esse ensaio com o pacote Core original nem com implantação no Site-Teste.


Cada consumidor decide por capacidade e contrato, sem trava de instalação por versão. Ausência, esquema inválido e conflito tornam indisponível a operação dependente; os demais serviços continuam administráveis. Não há importação de opções privadas nem reparo automático de outro plugin.

| Dono | Interface | Uso Google |
|---|---|---|
| Core | `F3Base_Medicao_Contexto`, `site-measurement-context/1.0.0` | Contexto dos seis slots e catálogo de eventos |
| MCP | `Fator3\McpFiles\PackageDistribution`, `package-distribution/1.0.0` | Seleção, manifesto e guarda da origem |
| MCP | `Fator3\McpFiles\ExecutorRegistry`, `executor-registration/1.0.0` | Declaração explícita das bridges Google |
| Google | `search-console-reader/1.0.0` | Leitor GSC para consumidores com concessão explícita; contrato preservado |

Os schemas Core são cópias integrais dos quatro arquivos `measurement-*.json` publicados no fonte Core 1.33.0 recebido. Estão em `docs/contracts/core-measurement/`, compilados por `build/compile-core-measurement.py` em PHP protegido. Validação inclui envelope, tipos, slots, revisão, eventos e campos permitidos. Dados de formulário fora desse catálogo são recusados. Não há dependência de arquivos Core no filesystem em runtime.

O adaptador consulta `capabilities()` e `snapshot()`; o catálogo usa `events()` com `expected_revision`, 100 itens por página e até 20 páginas. Revisa o snapshot ao concluir. Revisão incompatível, repetição, ausência de progresso ou orçamento excedido não produzem catálogo completo. O catálogo descreve eventos; não prova emissão/recebimento nem cria tags/conversões.

`google/configure` resolve o Measurement ID efetivo somente quando solicitado. IDs explícitos continuam disponíveis sem Core. A leitura é repetida após descoberta e antes de persistir o vínculo. Configurado, efetivo, proveniência, escopo e revisão são distintos; fotografia administrativa não certifica o ID servido a cada visitante. A confirmação otimista não trava escritores Core nem promete atomicidade entre plugins. GTM inclui `meta_server` separado de `meta`, conforme o contexto público.

Distribuição consulta o SDK e o recibo público `f3_mcp_distribution_selection`. Canal MCP selecionado mantém precedência sobre a origem própria. Se o produtor ficar inativo, o recibo mantém a intenção MCP e bloqueia fallback. Sem prova de seleção, a origem é desconhecida; salvar explicitamente uma origem própria cria consentimento local. O Google não lê `f3_mcp_update_channels`, chama `UpdateChannel` nem remove filtros alheios. A consulta da seleção não usa rede; o manifesto é uma operação separada. Guardas revalidam seleção/revisão antes do download/instalação. ZIP manual continua independente desse canal.

As bridges declaram provedor, modo e seis prefixos próprios no hook `f3_mcp_register_executors`. A autorização da bridge não concede o alvo. Leitura não executa escrita simulada, e nenhuma bridge Google aceita executor aninhado ou alvo Core/Meta/LinkedIn. Na ausência da capacidade nova permanece o percurso público de servidor nas combinações que o oferecem; uma declaração recusada não é contornada por fallback.

Core, MCP, Google, Meta e LinkedIn são donos independentes. Google não guarda tokens nem executa coletores sociais. Meta Ads segue no conector externo do agente. As fixtures sociais desta release exercitam isolamento, sem representar implementação/homologação desses plugins. Escritor Sheets social e SDK de leads Ads permanecem fora desta entrega.

## Contrato de medição preservado: contato e material (Pedido Core 222)

O SDK site-measurement-context/1.0.0 mantém seis slots e enumeração fechada. O slot google_ads.conversion_label refere-se a contato; não representa material. O Core 1.35.0 emite download_material por seus emissores, mas não o anuncia neste SDK. Sua configuração de material está no contrato administrativo Core 8.1.0.

Uma receita de material deve usar explicitamente download_material e identificadores próprios por finalidade. Não convertê-lo em generate_lead, nem reaproveitar o label de contato. Consultas GA4 por eventName podem usar download_material explicitamente; o catálogo incompleto não significa ausência do evento no fornecedor. A criação de evento-chave, ação Ads ou publicação GTM é decisão explícita do dono, com os gates existentes. O Google não infere nem cria essas ações ao ler contexto.

Na 0.12.0, `google/conversion-context` usa separadamente o contrato opcional `site-conversion-purposes/1.0.0`, entregue desde Core 1.36.0 e conferido na 1.38.0. Os schemas do contrato antigo permanecem intactos. Veja CONVERSOES.md para entrada, erros e limites.

## Conversões e tipagem na 0.12.0

Consulte [CONVERSOES.md](CONVERSOES.md) para `google/conversion-context`, o bloco adicional GTM e `effective_value` booleano (Pedido MCP Google 26). O contrato de medição existente permanece.


## Atualização 0.20.0

Pedidos 37/38: retenção 0 sem prazo e SDK ga4-reader/1.0.0. Valores explícitos da base 0.19.0 permanecem; manutenção protege os registros presentes quando configurada retenção ilimitada. GSC não muda. O SDK GA4 não implementa o acervo do Core. Consulte o guia 0.20.0 e SDK-PHP para concessão, cotas, limites e uso.
