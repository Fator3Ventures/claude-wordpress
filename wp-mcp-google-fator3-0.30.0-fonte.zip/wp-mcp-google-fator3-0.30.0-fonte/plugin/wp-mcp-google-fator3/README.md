# Fator3 MCP Google 0.30.0

Para configurar a conexão, interpretar um diagnóstico, exportar a auditoria em duas abas ou aplicar uma limpeza, siga o [guia de operação](docs/GUIA-0.30.0.md). Para retomar uma pesquisa interrompida ou identificar as páginas já confirmadas, consulte o [manual do planejador](docs/PLANEJADOR.md).


O plugin conecta WordPress a GA4, Google Ads, Search Console, Tag Manager, Sheets, Drive e Site Verification. Cada conexão reúne uma identidade Google, seus serviços, os recursos padrão e a política de acesso. O MCP Fator3 expõe as operações para agentes. O painel e a documentação também funcionam localmente.

## Primeira configuração

1. Instale o ZIP em **Plugins → Adicionar plugin**. Use WordPress 7.1.4 ou superior e PHP 8.3 ou superior. Para atualizar a 0.29.0, substitua a instalação existente pelo instalador da 0.30.0.
2. Abra **Ferramentas → Fator3 MCP Google**. Confira a conexão selecionada no topo. Em **Conexão → Identidade**, prepare e valide a conta de serviço ou o OAuth. Ative o método que será usado.
3. Em **Conexão → Serviços e recursos**, escolha os serviços, os níveis de operação e os recursos padrão. Use **Revisar alterações** para conferir o efeito. Reduções de acesso passam pela confirmação já existente.
4. Em **Conexão → Permissões**, restrinja os recursos que a identidade pode consultar ou alterar. Para operar pelo MCP, habilite o canal em **Avançado → Limites e auditoria**.
5. Abra **Avançado → Diagnóstico** e execute a verificação do recurso desejado. A leitura local de prontidão indica a próxima ação. A verificação remota exige credencial e permissão do Google.

## Manuais instalados

| Tarefa | Documento |
|---|---|
| Configurar o painel, os destinos e o acervo | GUIA-0.30.0.md |
| Pesquisar palavras-chave, paginar e cruzar com GSC | PLANEJADOR.md |
| Descobrir operações, parâmetros e erros | AGENT-GUIDE.md, ability-catalog.json |
| Consultar configuração e contratos de integração | configuration-definitions.json, CONTRATOS-PUBLICOS.md, SDK-PHP.md |
| Operar entregas e renovações | CONVERSOES.md, AVISOS-RENOVACAO.md |
| Acompanhar coleta, recuperação e atualização | ACERVO-ADS-GSC.md, ACOMPANHAMENTO-CRON.md, MIGRACAO.md |

O painel oferece os documentos ao fim de cada aba. Pelo MCP, chame `google/documentation` com `{}` para obter o índice e as instruções de paginação. As operações que acessam configurações ou dados exigem administrador autorizado. As credenciais devem ser informadas nos campos próprios do painel.
