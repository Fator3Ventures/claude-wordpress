# Verificação da instalação · 0.30.0

Em uma nova requisição, confira a versão com `google/status`, leia a prontidão com `google/readiness-status` e descubra o guia da release com `google/documentation`. Confira a identidade e os recursos em cada conexão. O Site-Teste pode ter serviços desligados ou credenciais ausentes; registre a condição encontrada antes de testar consultas.

No código-fonte, `tools/release030.py` executa instalação isolada, convivência com MCP e os plugins de canais disponíveis, atualização direta da 0.29.0 e navegação em WordPress descartável. O laboratório aceita a combinação sem Core para comprovar a autonomia do Google e o transporte MCP. A versão 1.72.0 do Core é conferida no Site-Teste; seu ZIP não estava disponível nesta rodada para repetição local. O relatório externo separa os ambientes e resultados efetivamente executados.

Os testes OAuth verificam troca de Client ID, segredo vazio, retorno de consentimento desatualizado, desconexão de ambas as autorizações, reversão da gravação em falha e isolamento entre conexões. A ativação testa o acesso a um contêiner GTM com respostas sintéticas. O navegador verifica os formulários reais, textos, identidades, segredos ocultos, retorno da gravação, modo sem JavaScript e telas de 1440 × 900 e 390 × 844. Nenhuma resposta sintética comprova acesso a uma conta real do Google.
