# FECHAMENTO-DOCUMENTAL · 0.30.0

O guia GUIA-0.30.0.md descreve as telas atuais. Para instalação, atualização ou correção use MIGRACAO.md. O catálogo e os schemas instalados descrevem as interfaces vigentes.

## Referência técnica e histórico de contratos

# Fechamento documental — 0.26.0

Catálogo e opções são gerados do runtime. Guia, especificação do acervo, SDK, exemplos e índice MCP usam a mesma versão. Dados PHP protegidos levam a documentação no instalador; o fonte contém os editáveis e geradores. Candidato aprovado é promovido sem recompressão. O relatório no fonte antecede seu fechamento; bytes e SHA finais do fonte constam somente no relatório externo. Nenhum ZIP aninhado.
