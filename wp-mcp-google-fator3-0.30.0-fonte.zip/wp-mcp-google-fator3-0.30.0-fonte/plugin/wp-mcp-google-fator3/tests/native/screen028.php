<?php
require __DIR__.'/common.php';
require_once ABSPATH.'wp-admin/includes/template.php';
use Fator3\McpGoogle\{Admin,Options as O,Connections as C,Ads\Archive};
C::create('visualqa','Conta de demonstração');
C::run('visualqa',static function(){
 O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,C::SERVICES=>['ads'=>'read','gsc'=>'read'],C::BINDINGS=>['ads_customer_id'=>'1234567890']]);
 O::set(Archive::CONFIG,['1234567890'=>['enabled'=>false,'datasets'=>['campaign'],'backfill_days'=>45,'revisit_days'=>3]]);
});
$dir=getenv('F3_FIXTURE_ROOT').'/preview';wp_mkdir_p($dir);
$css=file_get_contents(ABSPATH.WPINC.'/css/buttons.min.css').file_get_contents(ABSPATH.'wp-admin/css/common.min.css').file_get_contents(F3_MCP_GOOGLE_DIR.'assets/admin.css');
$js=file_get_contents(F3_MCP_GOOGLE_DIR.'assets/admin.js');
foreach(['identity'=>['section'=>'connection'],'services'=>['section'=>'connection','connection_panel'=>'services'],'permissions'=>['section'=>'connection','connection_panel'=>'permissions'],'conversions'=>['section'=>'conversions'],'archive'=>['section'=>'archive'],'diagnostics'=>['section'=>'diagnostics']] as $view=>$params) {
 $_SERVER['REQUEST_METHOD']='GET'; $_GET=$params+['connection_id'=>'visualqa']; $_POST=[];
 ob_start();Admin::render();$html=ob_get_clean();
 // Only the disposable rendered example is written. Strip form tokens and disable submitting to its expired lab.
 $html=preg_replace('/(<input[^>]*name="_wpnonce"[^>]*value=")[^"]+/', '$1', $html);
 $html=preg_replace('/_wpnonce=[^"&]+/','_wpnonce=',$html);
 file_put_contents($dir.'/'.$view.'.html','<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>'.$css.'</style></head><body class="wp-admin"><div style="max-width:1220px;margin:auto;padding:12px">'.$html.'</div><script>'.$js.'</script></body></html>');
 verifyLab('Captured disposable '.$view.' view',str_contains($html,'Fator3 MCP Google'));
}
finishLab('screen028');
