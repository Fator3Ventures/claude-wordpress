<?php
/** Reproduction only. Run against the immutable 0.27.0 ZIP in the disposable lab. */
require __DIR__.'/common.php';
require_once ABSPATH.'wp-admin/includes/template.php';
use Fator3\McpGoogle\{Admin,Options,ConversionDelivery as D,Ads\Archive,Ads\PlannerRequest};
verifyLab('Actual 0.27.0',F3_MCP_GOOGLE_VERSION==='0.27.0');
$_GET=['section'=>'diagnostics'];$_SERVER['REQUEST_METHOD']='GET';ob_start();Admin::render();$html=ob_get_clean();
verifyLab('Diagnostic link opens limits screen',str_contains($html,'<h2>Controle do site</h2>')&&!str_contains($html,'<h2>Verificar a conexão</h2>'));
Options::set(Archive::CONFIG,['1234567890'=>['enabled'=>false,'datasets'=>['campaign'],'backfill_days'=>45,'revisit_days'=>3]]);
$_GET=['section'=>'archive','archive_account'=>'1234567890'];ob_start();Admin::render();$html=ob_get_clean();
verifyLab('Saved 45/3 selection presented as 90/7',str_contains($html,'name="archive_backfill" value="90"')&&str_contains($html,'name="archive_revisit" value="7"'));
Options::set(D::CONFIG,array_replace(D::defaults(),['customer_id'=>'1234567890']));
$before=D::status(); $_GET=['section'=>'conversions'];$_SERVER['REQUEST_METHOD']='POST';
$_POST=['action_kind'=>'unknown','revision'=>$before['revision'],'_wpnonce'=>wp_create_nonce('f3-google-conversions')];
$_REQUEST=$_POST;ob_start();Admin::render();ob_end_clean();$after=D::status();
verifyLab('Unknown conversion action overwrites saved destination',($before['config']['customer_id']??'')==='1234567890'&&($after['config']['customer_id']??'x')==='',$after['config']['customer_id']??null);
verifyLab('Malformed provider row accepted as keyword null',PlannerRequest::result('metrics',['results'=>[[]]],'BRL')['rows'][0]['keyword']===null);
try { \Fator3\McpGoogle\Policy::administrative_read(static fn()=>[]); $type_error=false; } catch(TypeError $e) { $type_error=true; }
verifyLab('Administrative discovery fails with TypeError',$type_error);
$cache_key=(new ReflectionMethod(\Fator3\McpGoogle\Admin\ResourceChoices::class,'key'))->invoke(null,'action','1234567890');
verifyLab('Resource-choice cache rejects generated key',!\Fator3\McpGoogle\Cache::set($cache_key,['items'=>[]],60));
finishLab('review028-base');
