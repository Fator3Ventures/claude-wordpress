<?php
require __DIR__.'/common.php';
require_once ABSPATH.'wp-admin/includes/template.php';
use Fator3\McpGoogle\{Admin,Options as O,Connections as C,Settings,Policy,ConversionDelivery as D,Ads\Archive,Ads\PlannerAccess as Access,Ads\PlannerRequest as Wire,Admin\ResourceChoices as Choices};

function page028(string $section,array $params=[],array $post=[]): string {
    $_GET=['section'=>$section]+$params; $_POST=$post; $_REQUEST=$post+$_GET;
    $_SERVER['REQUEST_METHOD']=$post?'POST':'GET'; ob_start();Admin::render();return ob_get_clean();
}
function xpath028(string $html): DOMXPath { $dom=new DOMDocument();@$dom->loadHTML('<?xml encoding="UTF-8">'.$html);return new DOMXPath($dom); }
function call028(string $name,array $input): array {
    $r=wp_get_ability($name)->execute($input);
    return is_wp_error($r)?['success'=>false,'error_code'=>$r->get_error_code()]:$r;
}
function catalog028(): array {
    return array_column(call028('google/ability-catalog',['prefix'=>'ads/keyword-'])['abilities'],null,'name');
}
O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'12345-review.apps.googleusercontent.com',Settings::AUTH_READY=>true,
 C::BINDINGS=>['ads_customer_id'=>'1234567890'],C::SERVICES=>['ads'=>'read','ga'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]]],
 [O::OAUTH_CLIENT_SECRET=>'fixture-client',O::OAUTH_REFRESH_TOKEN=>'fixture-refresh',O::ADS_DEVELOPER_TOKEN=>'fixture-token']);
$requests=[];$mode='ok';$malformed=false;
$fixture=function($pre,$args,$url)use(&$requests,&$mode,&$malformed) {
 $requests[]=$url;
 if (str_contains($url,'/token')) { $body=['access_token'=>'fixture-access','expires_in'=>3600]; }
 elseif (str_contains($url,'googleAds:search')) {
  $query=json_decode($args['body'],true)['query'];
  if (str_contains($query,'conversion_action')) {
   if ($mode==='error') return ['response'=>['code'=>403],'headers'=>[],'body'=>'{"error":{"message":"fixture denied"}}'];
   $body=['results'=>[['conversionAction'=>['resourceName'=>'customers/1234567890/conversionActions/7','name'=>$mode==='partial'?'Partial':'Compra']]]];
   if($mode==='partial')$body['nextPageToken']='page';
  } else { $body=['fieldMask'=>'customer.currency_code,customer.test_account','results'=>[['customer'=>['currencyCode'=>'BRL','testAccount'=>false]]]]; }
 } elseif(str_contains($url,':generateKeywordIdeas')) {
  $next=isset(json_decode($args['body'],true)['pageToken']);
  $body=$next ? ['results'=>[$malformed?['text'=>'','keywordIdeaMetrics'=>[]]:['text'=>'segunda']]] : ['nextPageToken'=>'two','results'=>[['text'=>'primeira']]];
 } else {return $pre;}
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];
};
add_filter('pre_http_request',$fixture,1,3);
$map=['diagnostics'=>'Verificar a conexão','operations'=>'Execução das tarefas','controls'=>'Modelos de configuração','services'=>'Serviços e recursos'];
foreach ($map as $alias=>$title) {
 $html=page028($alias);verifyLab('Alias opens intended section '.$alias,str_contains($html,'<h2>'.$title.'</h2>'));
}
$identity=page028('connection');verifyLab('Identity view excludes unused service and policy forms',!str_contains($identity,'name="services_present"') && !str_contains($identity,'name="policy_mode"'));
$html=page028('advanced',['advanced_panel'=>'unknown']);verifyLab('Unknown advanced panel selects fallback and shows it',str_contains($html,'<h2>Controle do site</h2>')&&preg_match('~aria-current="page">Limites e auditoria~',$html)===1);
$nonce=wp_create_nonce('f3-google-conversions');O::set(D::CONFIG,array_replace(D::defaults(),['customer_id'=>'1234567890']));
$before=D::status();$post=['_wpnonce'=>$nonce,'revision'=>$before['revision'],'connection_id'=>'default'];
foreach (['unknown','', ['x']] as $kind) {
 $html=page028('conversions',[],['action_kind'=>$kind]+$post);
 verifyLab('Unrecognized command preserves destination '.get_debug_type($kind).json_encode($kind),D::status()['revision']===$before['revision']&&str_contains($html,'Ação de conversão desconhecida'));
}
$html=page028('conversions',[],['action_kind'=>'configure','connection_id'=>'different']+$post);
verifyLab('Connection mismatch preserves destination',str_contains($html,'conexão do formulário mudou')&&D::status()['revision']===$before['revision']);
$html=page028('conversions',[],['action_kind'=>'configure','revision'=>'stale']+$post);
verifyLab('Stale form cannot save',D::status()['revision']===$before['revision']);
verifyLab('Local navigation and refusals call no provider',$requests===[],$requests);
O::set(Archive::CONFIG,['1234567890'=>['enabled'=>false,'datasets'=>['campaign'],'backfill_days'=>45,'revisit_days'=>3],
 '2222222222'=>['enabled'=>false,'datasets'=>['changes'],'backfill_days'=>15,'revisit_days'=>2]]);
foreach (['1234567890'=>[45,3,'campaign'],'2222222222'=>[15,2,'changes']] as $id=>$expected) {
 $xp=xpath028(page028('archive',['archive_account'=>(string)$id]));
 $base='//form[.//input[@name="archive_operation" and @value="collection"]]';
 verifyLab('Current account bound and readonly '.$id,$xp->query($base.'//input[@name="archive_account" and @readonly]')->item(0)->getAttribute('value')===(string)$id);
 verifyLab('Current collection ranges '.$id,(int)$xp->query($base.'//input[@name="archive_backfill"]')->item(0)->getAttribute('value')===$expected[0]&&(int)$xp->query($base.'//input[@name="archive_revisit"]')->item(0)->getAttribute('value')===$expected[1]);
 $checked=$xp->query($base.'//input[@name="archive_datasets[]" and @checked]');
 verifyLab('Current data selection '.$id,$checked->length===1&&$checked->item(0)->getAttribute('value')===$expected[2]);
}
$bad=page028('archive',['archive_account'=>'1111111111']);verifyLab('Unknown account never opens a write form',str_contains($bad,'não está cadastrada')&&!str_contains($bad,'name="archive_operation"'));
verifyLab('New account starts without an active grant',xpath028(page028('archive',['archive_account'=>'new']))->query('//input[@name="archive_enabled" and @checked]')->length===0);
$a=Choices::load('action','1234567890');
verifyLab('Complete resource choices are cached',!empty($a['complete'])&&(Choices::items('action','1234567890')[0]['name']??'')==='Compra',$a);
$n=count($requests); $a=Choices::items('action','1234567890');verifyLab('Reading choices calls no provider',count($requests)===$n);
foreach (['partial','error'] as $mode) {
 $r=Choices::load('action','1234567890');
 verifyLab('Unusable refresh preserves previous complete list '.$mode,(empty($r['success'])||empty($r['complete']))&&Choices::items('action','1234567890')[0]['name']==='Compra');
}
$mode='ok';verifyLab('Resource list is isolated by parent',Choices::items('action','2222222222')===[]);
$n=count($requests); page028('conversions',[],['action_kind'=>'resources-ads','customer_id'=>'1234567890','enabled'=>'on']+$post);
verifyLab('Ads list never contacts GA',!array_filter(array_slice($requests,$n),fn($u)=>str_contains($u,'analytics'))&&D::status()['revision']===$before['revision']);
foreach (['unknown','explorer','basic'] as $level) {
 O::set(Access::OPTION,['level'=>$level,'scope'=>Access::scope()]);$catalog=catalog028();
 verifyLab('Catalog matches planner gate '.$level,$catalog['ads/keyword-ideas']['available']===($level==='basic')&&$catalog['ads/keyword-archive']['available']===true);
}
foreach ([['metrics',['results'=>[['text'=>'']]]],['metrics',['results'=>[['text'=>'x','keywordMetrics'=>['averageCpcMicros'=>'unknown']]]]],['ideas',['nextPageToken'=>[]]],['themes',['unusableAdGroups'=>'unexpected']],['forecast',['campaignForecastMetrics'=>['clicks'=>'NAN']]]] as [$kind,$body]) {
 verifyLab('Reject malformed provider '.json_encode($body),Wire::validate_response($kind,$body)?->get_error_code()==='f3_google_keyword_response');
}
foreach (['ideas','metrics','themes','forecast'] as $kind) { verifyLab('Valid empty protobuf response '.$kind,Wire::validate_response($kind,[])===null); }
$malformed=true;$r=call028('ads/keyword-ideas',['keywords'=>['consulta']]);
verifyLab('Malformed page returns stable cursor',($r['error_code']??'')==='f3_google_keyword_response'&&isset($r['resume_id']),$r);
$read=call028('ads/keyword-archive',['archive_id'=>$r['resume_id']]);verifyLab('Bad page never enters the archive',$read['row_count']===1&&$read['complete']===false);
$malformed=false;$r=call028('ads/keyword-ideas',['resume_id'=>$r['resume_id']]);verifyLab('Resume after corrected response keeps both rows once',$r['complete']===true&&array_column($r['rows'],'keyword')===['primeira','segunda']);
$archive_id=$r['archive_id']; $key='1234567890-'.$archive_id;
$old=\Fator3\McpGoogle\Ads\ArchiveStore::get('keywordread',$key);
$old['observed_at']='2025-11-01T23:55:00+00:00';
\Fator3\McpGoogle\Ads\ArchiveStore::put('keywordread',$key,$old);
$table=\Fator3\McpGoogle\Storage\Repository::table();
verifyLab('New checkpoint preserves observation date in SQL',(int)$wpdb->get_var($wpdb->prepare("SELECT created_at FROM $table WHERE kind='keywordread' AND record_id=%s",$key))===strtotime($old['observed_at']));
$wpdb->update($table,['created_at'=>strtotime('2025-11-02 00:05:00 UTC')],['kind'=>'keywordread','record_id'=>$key]);
$lookup=call028('ads/keyword-archive',['from'=>'2025-11-01','to'=>'2025-11-01']);
verifyLab('Older receipt found by observation date despite later checkpoint',in_array($archive_id,array_column($lookup['reads'],'archive_id'),true),$lookup);
$lookup=call028('ads/keyword-archive',['from'=>'2025-11-02','to'=>'2025-11-02']);
verifyLab('Following day does not include the old observation',!in_array($archive_id,array_column($lookup['reads'],'archive_id'),true));
$lookup=call028('ads/keyword-archive',['from'=>'2025-11-02','to'=>'2025-11-01']);
verifyLab('Inverted date range rejected',($lookup['error_code']??'')==='f3_google_keyword_date');
remove_filter('pre_http_request',$fixture,1);
finishLab('review028',['provider'=>'synthetic','non_admin_and_nonce'=>'covered by browser and installed docs suites']);
