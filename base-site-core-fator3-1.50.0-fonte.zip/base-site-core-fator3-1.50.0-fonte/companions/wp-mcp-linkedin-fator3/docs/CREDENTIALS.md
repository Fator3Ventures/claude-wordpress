# Autorização e renovação — 0.9.0

Token manual continua sendo padrão. O novo fluxo OAuth pelo navegador é opcional e usa retorno no próprio site: `https://SEU-SITE/wp-admin/admin-post.php?action=f3_linkedin_oauth_callback`. Cadastre exatamente esse endereço no aplicativo do LinkedIn. Salve a conexão com ID e chave secreta, selecione as permissões necessárias e clique Autorizar no LinkedIn. O retorno exige sessão administrativa atual e state aleatório, de uso único, vinculado a usuário, sessão, conexão e revisão, com validade de dez minutos. O endereço público da autorização sai em `consent_url`; os tokens nunca saem na resposta.

O aplicativo só recebe refresh token quando o programa/produto e a aprovação do LinkedIn permitem. O fluxo não promete renovação para aplicativos sem essa habilitação. Troca de código e refresh são POST HTTPS sem redirecionamento. Tokens e segredo são armazenados cifrados; configuração pública informa apenas disponibilidade, validade e geração.

`save-connection` adiciona refresh_token, refresh_expires_at e clear_refresh_token. Campo vazio preserva o segredo salvo; remoção é explícita. Alterar manualmente token, ID ou segredo do app limpa o refresh anterior se não vier novo refresh na mesma gravação, impedindo associação silenciosa à credencial antiga. Salvar somente nome/configuração após renovação mantém o token efetivo novo.

## Renovação e observação

Manutenção horária tenta renovar a partir de três dias antes de expires_at. O cron depende de tráfego ou cron real. `refresh-token` permite tentativa administrativa com expected_revision. Expiração desconhecida (0) não permite agendar aviso/renovação; informe a validade ou autorize pelo fluxo. Conexão pausada não renova. Exige administrador responsável ainda autorizado.

Em sucesso, guarda novo token/validade e refresh quando retornado. Usa sobreposição cifrada ligada ao token/app-base: incrementa credential_generation e conserva a revisão de autorização da conexão. Assim permanecem seleções, concessões, cursores, agendas e diário de assinaturas existentes. Nenhuma chamada de criação de assinatura é feita. Prévia de escrita emitida antes da troca de geração deve ser refeita.

Em falha, conserva o token atual e abre incidente local, com código sanitizado, contador e próxima tentativa. Retentativa: 5 minutos em progressão exponencial limitada a um dia; a manutenção horária determina quando de fato ocorre. Envia aviso a admin_email com deduplicação por validade/tipo. Falha de e-mail fica registrada e permite nova tentativa após um dia. Nunca inclui segredo no e-mail.

Sem refresh, o painel mostra dias restantes e disponibilidade; a manutenção avisa admin_email quando entrar nas janelas de 14 e 3 dias, e após vencimento. Se o site ficar sem cron e saltar uma janela, envia o aviso correspondente ao prazo observado, sem inventar envio retroativo.

`linkedin/status.data.access_lifecycle` informa connections (connection_id, days_remaining, expires_at, refresh_configured, refresh_expires_at, credential_generation, last_refresh_at, last_result, failures, next_attempt, incident, notices, scopes), next_maintenance e oauth_callback. `inspect-token` verifica no provedor e guarda somente prova pública; status não chama o LinkedIn. Secrets nunca são preenchidos no formulário.

Nova autorização OAuth ou troca manual incrementa a revisão de conexão, conserva os registros e exige reconfirmação administrativa das concessões e do vínculo do diário conforme o contrato Lead Reader. Isso difere da renovação automática, que mantém a autorização vigente. Não se presume que uma nova autorização represente a mesma identidade remota. Core continua dono da ingestão comercial.

## Recuperação

Confira incidente e próxima tentativa, produtos/escopos liberados, segredo do app e validade do refresh. Reautorize quando necessário. Não remova concessões ou diário para sanar timeout. Preserve as salts do WordPress junto do backup cifrado. Voltar a 0.4.1 ignora a sobreposição renovada; pode voltar ao token-base antigo. Antes de rollback, faça backup completo e planeje credencial manual válida/reautorização; consulte MIGRATION.md.

Consulte FIELD-HELP.md para nomes exatos. O escopo rw_conversions foi acrescido ao consentimento opcional; r_ads também é obrigatório para CAPI. Conceder Lead Sync não concede conversões.
