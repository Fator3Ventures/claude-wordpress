# Configuração LinkedIn — 0.9.0

Na aba Conexão, cadastre o token, ID do aplicativo e chave secreta quando disponíveis. Em Ativos, selecione Páginas, contas de Anúncios e contas de Formulários separadamente, pelos nomes. A versão mensal da API (padrão 202609) fica em Diagnóstico > configuração avançada. IDs continuam sendo strings nos contratos. Lead Sync aceita somente SPONSORED e requer formulários explicitamente selecionados por conta. `r_ads`/`rw_ads` não implicam acesso a respostas: Lead Sync precisa do produto e permissão específicos do LinkedIn.

Tokens e client_secret são cifrados. Secret é usado para challenge/notificação; token para consultas e assinaturas. Configure client_id/application_id para rastreabilidade da transição; valores configurados não comprovam remotamente a titularidade do aplicativo. Token vazio mantém o atual. Toda mudança da conexão incrementa a revisão e exige reconfirmar concessões.

Registrar consumidor não autoriza acesso. Administrador concede permissões metadata, responses, verify e/ou subscriptions, formulários selecionados e callback HTTPS do próprio site. Formulários vazios não concedem acesso. Releia get-connection/get-grant; list-grants é paginada e retorna next_offset. O SDK concedido funciona com usuário zero e não exige sessão humana.

A versão não muda o seletor de provedor do Core. Preserve credencial e concessão antigas até concluir drenagem do diário de assinaturas. Não substitua aliases ou remova registros como tentativa de resolver timeout.

A seleção dos usuários WordPress usa nomes e busca paginada. Não concede `manage_options`. Token/chave vazios mantêm os valores cifrados. Marcar remover é uma alteração explícita. A gravação da aba Conexão não envia ativos/formulários: os mantém. Descoberta não marca novos ativos. Na falha da origem, a seleção anterior continua disponível, identificada como nome indisponível quando necessário. Salvar seleção usa a revisão capturada ao abrir Ativos; conflito exige reabrir e revisar.

## Complementos da 0.5.0

Consulte CREDENTIALS.md para refresh e autorização pelo navegador. Para as novas escritas, ID e segredo do app são obrigatórios para introspecção. Renovação automática aumenta somente credential_generation, sem alterar revisão/concessões. A frase anterior sobre mudança de conexão refere-se a gravação manual/configuração, não à sobreposição automática de token.

## Auditoria de serviço
Nenhuma credencial, campo ou concessão nova na 0.7.0. A concessão CAPI existente continua explícita. status/capabilities mostram service_audit; no MCP 0.27.0 a parte central é indisponível. Instalar a atualização não reconfirma grants nem reemite diários.
