# Fator3 Site Core 1.50.0 — fonte

Base direta 1.49.1; pedidos 292 e 293. Contrato administrativo 8.15.0, 145 abilities. Runtime em `work/plugin/base-site-core-fator3`, igual byte a byte ao instalador desta entrega. Este ZIP não é instalável.

`build/README.md` explica a reprodução. `tests/request-292*.php` cobre confirmação de resultado, concorrência real no banco, diagnóstico e reconciliação. `tests/request-293*.php` cobre formatos, recusas remotas, confirmação de identidade, preservação de estado, segurança e apresentação pelo redator real do MCP. `tests/dom-1500.cjs` cobre o fluxo de confirmação no DOM.

`evidence/1500/` contém as provas desta rodada. Pastas de evidências anteriores e `history/` são históricas, não reexecuções da 1.50.0. Resultados preliminares, quando preservados, são identificados como tal. O relatório externo especifica a identidade final e os limites da homologação.

`companions/` contém cópias intactas dos instaladores MCP 0.29.1, Google 0.19.0, LinkedIn 0.9.0 e Meta 0.8.0 usados localmente. Não são alterações nem entregas desses pacotes; não entram no instalador. Identidades e comparação com os fontes recebidos em `evidence/1500/inputs.json`; relatórios recebidos em `inputs/1500/`.

Sem banco, credenciais reais, cookies, runtime baixado, node_modules ou ZIP aninhado. A ferramenta `tests/site-qa-1500.php` é temporária, restrita ao Site-Teste, com HTTP simulado e sem gravação de configuração; não entra no instalador. A cópia do relatório na raiz é anterior ao fechamento do fonte; o relatório externo contém sua identidade final.
