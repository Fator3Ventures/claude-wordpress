# Fonte do Fator3 Site Core 1.96.0

Base oficial 1.95.0. O runtime instalável está em `work/plugin/base-site-core-fator3/`. A documentação de operação desta versão é `docs/RELEASE-1.96.0.md` nessa árvore. O relatório interno `RELATORIO-PRE-FECHAMENTO.md` antecede o cálculo do hash do próprio fonte.

## Reproduzir a entrega

Na raiz desta árvore, com Python 3 e PHP de 64 bits a partir de 8.3, execute os comandos abaixo. A compressão de referência usou zlib 1.3.2.

```sh
F3BASE_PHP=php python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.96.0-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.96.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.96.0-fonte.zip
```

## Reproduzir as provas

Use três instalações descartáveis WordPress 7.1.4 em loopback com WP-CLI, PHP 8.3 ou 8.4, MariaDB, administrador ID 1 e `WP_ENVIRONMENT_TYPE=local`. Use os instaladores identificados em `evidence/1960/conjunto.json`. Desative o disparo automático do WP-Cron. Intercepte o correio e as requisições externas, preservando as respostas sintéticas das fixtures. Todos os comandos de inspeção usam WP-CLI na raiz da instalação, com `--user=1`. Os testes que leem o URL esperam `http://127.0.0.1:33795`. A implantação compartilhada não usa as fixtures.

1. No banco `core_196_clean`, ative somente o instalador final e execute `wp eval-file tests/196/instalacao.php`. Confira o alvo, as etapas e a confirmação em processo posterior.
2. No banco `core_196_migracao`, instale Core 1.95.0 e os cinco acompanhantes atuais. Execute `wp eval-file tests/196/prazo.php`. A fixture grava datas e confirma a abertura dos avisos antigos na base. Instale o ZIP 1.96.0 com `wp plugin install CAMINHO --force --activate`, confira `instalacao.php` e execute `prazo.php` novamente. A segunda execução cobre a primeira coleta, as datas de 73 observações horárias, duas conexões, destinos de duração distinta, simulação de atraso de renovação e validades longas.
3. No banco `core_196_google`, ative as seis versões finais, em estado novo. Execute `F3_PHASE39=core-patch F3_RESULT39=/tmp/filas.json wp eval-file tests/196/provas-google.php`. O nome da fase é do ensaio Google original. A execução utiliza a edição oficial do Core. A fixture simula OAuth, GA4, Ads e respostas de recibos e correio. No banco de migração, execute a mesma prova com PHP 8.4 e `F3_EXTRA196` apontando para o caminho absoluto de `tests/196/filas-anteriores.php`. As condições adicionais preparam registros nos estados que podiam vir da 1.95.0.
4. No WordPress integrado, `wp eval-file tests/193/produtores.php` verifica Meta e cron. Para Google, LinkedIn e Pipedrive, aponte `F3BASE_SITE` para o wp-load.php do banco de migração e execute `php -S 127.0.0.1:33795 tests/196/contratos.php`. Consulte /wp-admin/tools.php nesse servidor, verifique cinco mensagens e a recusa de leitura ao visitante. Interrompa o servidor ao concluir.
5. Para a verificação visual da superfície de avisos, acesse Configurações → Conexões e entregas → Avisos como administrador local. As capturas e medidas das três larguras estão em `evidence/1960/ui/`. Para consultar a descrição técnica do prazo, leia `f3base/config-core-contrato-v1` com `nome=f3base_avisos_tecnicos`.
6. Descarte as três instalações de ensaio e seus bancos ao concluir. Consulte `evidence/1960/site-teste.json` para a homologação compartilhada e `reference/1960/` para o pedido, planejamento e os impactos recebido e devolvido. As evidências anteriores no fonte são históricas.
