# Encerramento da 0.10.0 · 13/11/2026
- Normas das fontes: instrucoes-agentes-plugins-fator3.md e padrao-desenvolvimento-plugins-fator3.md, revisões 5 de 02/11/2026. Pedido 12 e último fonte/instalador identificados e comparados.
- Slug, basename, provider, permissões, menu, schema de banco 1 e 22 nomes públicos preservados. Schema de whatsapp-registrar e documentação instalados atualizados. Mínimos: WP 7.1.4 e PHP 8.3.
- Instalação limpa e troca direta da 0.9.0 com dados preenchidos, releitura em novo processo e replay de recibo antigo. Sem ensaio de downgrade. Convivência com cinco acompanhantes oficiais, sem patch e sem encaminhamento técnico para outro pacote.
- Dados de teste do fornecedor somente em memória na bancada, rede e e-mail bloqueados. Nada semeado no CRM nem no WordPress compartilhado. Dados locais do plugin verificados antes e após a atualização. O cadastro fixado de origem do Core usa outro recurso.
- Relatório com prova, limites e estado de homologação. Instalador só com runtime; fonte com raiz única, código, testes, evidência sanitizada, normas, pedido e relatório anterior ao fechamento. Fonte e instalador sem ZIP aninhado, tamanhos e hashes definitivos no relatório externo.
- Frota: distribuição raw e instalação em produção não executadas; aceite comercial e comunicação ao SDR após teste real. O Pedido 12 não foi encerrado na lista oficial.
