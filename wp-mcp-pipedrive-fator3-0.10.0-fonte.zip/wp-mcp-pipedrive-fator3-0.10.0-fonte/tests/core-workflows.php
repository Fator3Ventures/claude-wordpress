<?php
/** Public Core contract and real HTTP encoder, synthetic provider only. */
use Fator3\Pipedrive\{Api,CoreClient,Configuration,Support};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))throw new RuntimeException('Disposable only');
wp_set_current_user(1);$checks=[];$check=static function($n,$ok)use(&$checks){$checks[]=['name'=>$n,'passed'=>(bool)$ok];};$calls=[];$leadId=wp_generate_uuid4();$lead=['id'=>$leadId,'title'=>'QA','person_id'=>88,'add_time'=>'2026-10-01T00:00:00Z','is_archived'=>false,'label_ids'=>[]];$activity=null;
$c=Configuration::defaults();$c['habilitada']=true;$c['fuso']='UTC';$c['dias']=[1,2,3,4,5,6,7];$c['periodos']=[['codigo'=>'dia','hora'=>'09:30']];$c['tipo_whatsapp']='whatsapp';$c['toques']=[['codigo'=>'t1','atraso_minutos'=>0,'base'=>'entrada','texto_id'=>'m1','etiqueta_id'=>'']];$c['lost_reasons']=['Motivo de teste'];$c['textos']=[['codigo'=>'m1','texto'=>'QA approved']];$old=get_option(Configuration::OPTION,null);update_option(Configuration::OPTION,Support::json($c),false);
$filter=static function($pre,$args,$url)use(&$calls,&$lead,&$activity,$leadId){$parts=wp_parse_url($url);$p=$parts['path'];$method=$args['method']??'GET';$body=isset($args['body'])?json_decode($args['body'],true):[];parse_str($parts['query']??'',$q);if(($parts['host']??'')!=='api.pipedrive.com')return new WP_Error('qa','blocked');$calls[]=[$method,$p];$d=[];$a=[];
 if($p==='/v1/leads/'.$leadId){if($method==='PATCH')$lead=array_replace($lead,$body);$d=$lead;}
 elseif($p==='/api/v2/activities'&&$method==='POST'){$activity=$body+['id'=>700,'person_id'=>$body['participants'][0]['person_id']??null];$d=$activity;}
 elseif($p==='/api/v2/activities'){$d=$activity?[$activity]:[];$a=['next_cursor'=>null];}
 elseif($p==='/api/v2/activities/700'){if($method==='PATCH')$activity=array_replace($activity,$body);$d=$activity;}
 else return new WP_Error('qa','unknown');
 return ['response'=>['code'=>200],'headers'=>['x-daily-ratelimit-token-remaining'=>'9000'],'body'=>wp_json_encode(['success'=>true,'data'=>$d,'additional_data'=>$a])];};
add_filter('pre_http_request',$filter,101,3);
try{$before=CoreClient::status()['orcamento']['consumido'];$i=['lead_id'=>$leadId,'mensagem'=>'QA via Core','toque'=>'t1','proximo'=>'Combinar horário','chave_idempotencia'=>'core090-'.bin2hex(random_bytes(6))];$r=Api::dispatch('whatsapp-registrar',$i);if(!$r['success'])throw new RuntimeException('whatsapp Core: '.$r['code']);$check('original_core_create_activity',$r['success']&&$activity['lead_id']===$leadId);$n=count($calls);$check('original_core_replay',Api::dispatch('whatsapp-registrar',$i)===$r&&count($calls)===$n);$check('v2_primary_via_original_core',($activity['participants']??[])===[['person_id'=>88,'primary'=>true]]&&$activity['person_id']===88);$check('clean_note_via_original_core',!str_contains($activity['note'],'F3PD1:'));$check('original_core_synthetic_note',str_contains($activity['note'],'QA via Core'));$check('original_core_utc_date',preg_match('/^\d{4}-\d\d-\d\d$/',$activity['due_date'])&&$activity['due_time']==='09:30');$p=Api::dispatch('lead-encerrar',['lead_id'=>$leadId,'mensagem'=>'QA final','archive_reason'=>'Fora do perfil']);$r=Api::dispatch('operacao-aplicar',['previa_id'=>$p['data']['previa_id']]);$check('original_core_close',$r['success']&&$activity['done']&&$lead['is_archived']);$writes=count(array_filter($calls,fn($x)=>$x[0]!=='GET'));$gets=count($calls)-$writes;$check('original_core_budget_exact',CoreClient::status()['orcamento']['consumido']-$before===$gets*20+$writes*10);$check('fixed_host_paths',!array_filter($calls,fn($x)=>!str_starts_with($x[1],'/v1/')&&!str_starts_with($x[1],'/api/v2/')));

// Verify the ACTUAL Core classifies its HTTP bytes; no canned Core envelope in this regression.
$rawCount=0;$dealCases=[];$first=random_int(260000,290000);
$ambiguous=static function($pre,$args,$url)use(&$rawCount,&$dealCases){
 $host=wp_parse_url($url,PHP_URL_HOST);$path=wp_parse_url($url,PHP_URL_PATH);$id=(int)basename($path);
 if($host!=='api.pipedrive.com'||$path!=='/api/v2/deals/'.$id||!array_key_exists($id,$dealCases))return $pre;
 ++$rawCount;$method=$args['method']??'GET';
 $body=$method==='GET'?wp_json_encode(['success'=>true,'data'=>['id'=>$id,'status'=>'open','is_archived'=>false]]):$dealCases[$id];
 return ['response'=>['code'=>200],'headers'=>['x-daily-ratelimit-token-remaining'=>'9000'],'body'=>$body];
};
add_filter('pre_http_request',$ambiguous,102,3);
try{
 foreach(['ilegivel'=>'{','acima_do_limite'=>str_repeat('X',524289)] as $name=>$body){
  $id=++$first;$dealCases[$id]=$body;
  $preview=Api::dispatch('negocio-perder',['negocio_id'=>$id,'lost_reason'=>'Motivo de teste']);
  $check('core_2xx_previa_'.$name,$preview['code']==='previa_criada');
  $pid=$preview['data']['previa_id']??str_repeat('0',32);$before=$rawCount;
  $r=Api::dispatch('operacao-aplicar',['previa_id'=>$pid]);
  $account=CoreClient::status()['conta'];$marker=\Fator3\Pipedrive\Store::CANONICAL_PENDING.hash('sha256',Support::digest($account).':deal:'.$id);
  $check('core_2xx_incerto_'.$name,$r['code']==='resultado_parcial_ou_incerto'&&$rawCount>$before);
  $check('core_2xx_marcador_persistido_'.$name,get_option($marker)===$pid);
  $n=$rawCount;$replay=Api::dispatch('operacao-aplicar',['previa_id'=>$pid]);
  $check('core_2xx_recibo_sem_reenvio_'.$name,$replay===$r&&$n===$rawCount);
 }
}finally{remove_filter('pre_http_request',$ambiguous,102);}
}finally{remove_filter('pre_http_request',$filter,101);if($old===null)delete_option(Configuration::OPTION);else update_option(Configuration::OPTION,$old,false);}
return ['checks'=>$checks,'passed'=>count(array_filter($checks,fn($c)=>$c['passed'])),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'core_http_intercepted'=>count($calls),'supplier_http'=>0];
