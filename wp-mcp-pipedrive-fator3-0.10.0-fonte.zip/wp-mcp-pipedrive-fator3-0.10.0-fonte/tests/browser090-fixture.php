<?php
/** MU fixture only for the isolated browser test. Never install on another WordPress. */
if(!defined('ABSPATH') || !defined('DB_NAME') || DB_NAME!=='f3pipqa_0900_browser' || !defined('WP_HTTP_BLOCK_EXTERNAL') || !WP_HTTP_BLOCK_EXTERNAL || !defined('WP_HOME') || WP_HOME!=='http://127.0.0.1:18490')return;
add_action('plugins_loaded',static function(){
    require_once dirname(ABSPATH).'/tests/fixture050.php';
    $f=new ReleaseFixture();
    $f->data['/v1/activityTypes']=[['key_string'=>'whatsapp','name'=>'WhatsApp']];
    $f->data['/v1/leadLabels']=[['id'=>'11111111-0000-0000-0000-000000000001','name'=>'Etiqueta QA']];
    $f->data['/v1/dealFields']=[['key'=>'title','name'=>'Título']];
    (new ReflectionProperty(\Fator3\Pipedrive\CoreClient::class,'client'))->setValue(null,$f);
    add_action('shutdown',static function()use($f){
        if(!is_user_logged_in()||!current_user_can('manage_options'))return;
        $stats=['gets'=>count($f->requests),'writes'=>$f->writes,'drafts'=>(int)$GLOBALS['wpdb']->get_var('SELECT COUNT(*) FROM '.\Fator3\Pipedrive\Store::table('ops'))];
        file_put_contents(dirname(ABSPATH).'/browser090-counts.jsonl',json_encode($stats)."\n",FILE_APPEND|LOCK_EX);
    });
});
