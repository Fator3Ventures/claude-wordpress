<?php
/** Native WordPress + DB; a scoped CRM fixture models the two provider pagination contracts. */
use Fator3\Pipedrive\{Api,Configuration,CoreClient,Store,Support};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))throw new RuntimeException('Disposable only');
require_once ABSPATH.'wp-admin/includes/user.php';wp_set_current_user(1);$checks=[];$metrics=[];
$ok=static function($name,$value)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$value];};
$f=new class {
 public array $leads=[],$activities=[],$calls=[];public string $fail='',$rev='qa-090';public bool $oversize=false;
 public function status(){return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>true,'conta'=>['dominio'=>'qa.pipedrive.com','conta_id'=>99,'usuario_id'=>3],'revisao'=>$this->rev,'orcamento'=>['teto'=>100000,'consumido'=>count($this->calls)*20,'reservado'=>0]]];}
 public function request($method,$path,$q,$body,$ctx){
   if($method!=='GET')throw new RuntimeException('effect forbidden');$this->calls[]=[$path,$q];
   if($this->fail===$path)return ['success'=>false,'code'=>'resultado_incerto','remote_dispatched'=>true,'data'=>['http_status'=>503,'body'=>null]];
   $v2=$path==='/api/v2/activities';
   $rows=$v2?$this->activities:$this->leads;
   if(isset($q['lead_id']))$rows=array_values(array_filter($rows,static fn($a)=>($a['lead_id']??null)===$q['lead_id']));
   $offset=(int)($q['start']??$q['cursor']??0);$limit=$q['limit'];
   if($this->oversize&&$v2&&$limit>125)return ['success'=>false,'code'=>'resposta_excedeu_limite','remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>null]];
   $data=array_slice($rows,$offset,$limit);$end=$offset+count($data);$more=$end<count($rows);
   $p=$v2?['next_cursor'=>$more?(string)$end:null]:['pagination'=>['more_items_in_collection'=>$more,'next_start'=>$more?$end:null]];
   return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>$data,'additional_data'=>$p]]];
 }
};
$ref=new ReflectionProperty(CoreClient::class,'client');$old=$ref->getValue();$ref->setValue(null,$f);
$oldConfig=get_option(Configuration::OPTION,null);$table=Store::table('ops');$http=0;
$block=function()use(&$http){++$http;return new WP_Error('test_no_external','External requests forbidden');};add_filter('pre_http_request',$block,PHP_INT_MAX);
$clock='2026-11-10T14:30:00Z';$uuid=static fn($n)=>sprintf('09000000-0000-4000-8000-%012d',$n);
$seed=static function($n)use($f,$uuid){$f->leads=[];$f->activities=[];$f->calls=[];foreach(range(1,$n) as $j)$f->leads[]=['id'=>$uuid($j),'add_time'=>'2026-11-01T06:30:00Z','is_archived'=>false,'label_ids'=>[]];};
$queue=static fn($i=[])=>Api::dispatch('cadencia-fila',$i);
try{
 $c=Configuration::defaults();$c['habilitada']=true;$c['fuso']='UTC';$c['dias']=[1,2,3,4,5,6,7];$c['janela']=['inicio'=>'00:00','fim'=>'23:59'];$c['periodos']=[['codigo'=>'m','hora'=>'09:00']];$c['tipo_whatsapp']='whatsapp';$c['textos']=[['codigo'=>'m','texto'=>'Mensagem sintética']];$c['toques']=[['codigo'=>'t1','base'=>'entrada','texto_id'=>'m','etiqueta_id'=>'','atraso_minutos'=>0]];
 Configuration::save(Configuration::validate($c),Configuration::read()['revisao']);
 foreach([201,1000] as $n){
  $seed($n);foreach([1,$n] as $j)$f->activities[]=['id'=>$j,'lead_id'=>$uuid($j),'type'=>'whatsapp','done'=>true,'note'=>'Histórico sintético.'];$ids=[];$sumDue=0;$params=['agora'=>$clock];$pages=0;$bounded=true;
  do{$r=$queue($params);$d=$r['data'];if($r['code']!=='ok'||empty($d['pagina_completa'])||$d['avaliados']<1||++$pages>30)break;
    $ids=array_merge($ids,array_column($d['itens'],'lead_id'));$bounded=$bounded&&$d['avaliados']===count($d['itens'])&&$d['devidos']===$d['avaliados']-(((array)$d['motivos_pagina'])['atividade_concluida']??0)&&$d['custo']['chamadas']<=100;
    $sumDue+=$d['devidos'];$cursor=$d['proximo_cursor'];if(!$cursor)break;$params=['cursor'=>$cursor];
  }while(true);
  $ok('all_'.$n.'_exact_order_distinct',$ids===array_column($f->leads,'id')&&$d['fim_da_fila']===true&&$d['total_visivel']===$n&&$sumDue===$n-2);
  $ok('budget_and_due_'.$n,$bounded&&!array_filter($f->calls,fn($q)=>$q[0]==='/api/v2/activities'&&!isset($q[1]['lead_id'])&&$q[1]['limit']!==50));
  $metrics['fila_'.$n]=['paginas'=>$pages,'chamadas'=>count($f->calls),'unidades'=>count($f->calls)*20];
  $c['feriados']=["2027-01-0".($n===201?'1':'2')];$r=Api::dispatch('configuracao-simular',['regras'=>$c,'revisao_esperada'=>Configuration::read()['revisao'],'agora'=>$clock]);$p=$r['data'];
  $ok('sample_'.$n,$r['code']==='simulacao_criada'&&$p['simulacao']['avaliados']===20&&$p['simulacao']['devidos']===19&&$p['simulacao']['amostra']&&$p['simulacao']['total_visivel']===null&&isset($p['expira_em_utc']));
  $apply=Api::dispatch('operacao-aplicar',['previa_id'=>$p['previa_id'],'confirmacao'=>$p['confirmacao_exigida']]);
  $ok('sample_applied_'.$n,$apply['code']==='configuracao_salva'&&Configuration::read()['regras']['feriados']===$c['feriados']);
 }
 if(defined('F3_PIPEDRIVE_TEST_QUEUE_MUTANT'))return ['checks'=>$checks];
 $seed(200);for($j=1;$j<=5000;$j++)$f->activities[]=['id'=>$j,'lead_id'=>null,'type'=>'call','done'=>true];
 $r=$queue(['agora'=>$clock]);$ok('R9_11_calls',$r['data']['devidos']===200&&count($f->calls)===11&&$r['data']['custo']['estimativa_unidades']===220);$metrics['R9']=$r['data']['custo'];
 $f->calls=[];$f->oversize=true;$r=$queue(['agora'=>$clock]);$attempts=array_values(array_filter($f->calls,fn($x)=>$x[0]==='/api/v2/activities'));$ok('oversize_shrinks_at_same_cursor',$r['data']['devidos']===200&&array_column(array_column(array_slice($attempts,0,3),1),'limit')===[500,250,125]&&!isset($attempts[2][1]['cursor'])&&$r['data']['custo']['chamadas']===43);$f->oversize=false;
 $seed(3);$f->activities=[['id'=>901,'type'=>'whatsapp','lead_id'=>$uuid(1),'done'=>true,'note'=>''],['id'=>902,'type'=>'whatsapp','lead_id'=>$uuid(2),'done'=>true],['id'=>903,'type'=>'whatsapp','lead_id'=>$uuid(2),'done'=>false]];
 $r=$queue(['agora'=>$clock,'limite'=>2,'filtro'=>'devidos']);$d=$r['data'];$cur=$d['proximo_cursor'];
 $ok('empty_due_page_continues',$r['code']==='ok'&&$d['itens']===[]&&$d['avaliados']===2&&$d['devidos']===0&&$d['fim_da_fila']===false&&$cur&&((array)$d['motivos_pagina'])===['atividade_concluida'=>1,'atividade_whatsapp_duplicada'=>1]);
 $r=$queue(['cursor'=>$cur]);$ok('final_page_after_empty',$r['data']['fim_da_fila']&&array_column($r['data']['itens'],'lead_id')===[$uuid(3)]&&$r['data']['total_visivel']===3);
 $actorId=wp_insert_user(['user_login'=>'fila090_'.bin2hex(random_bytes(4)),'user_pass'=>wp_generate_password(),'role'=>'administrator']);wp_set_current_user($actorId);$ok('cursor_other_admin',$queue(['cursor'=>$cur])['code']==='cursor_invalido');wp_set_current_user(1);wp_delete_user($actorId);
 $orig=$cur[6];$bad=substr_replace($cur,$orig==='x'?'y':'x',6,1);$ok('cursor_tamper',$queue(['cursor'=>$bad])['code']==='cursor_invalido');
 $opened=Support::open(strtr($cur,'-_','+/'));$opened['exp']=time()-1;$expired=rtrim(strtr(Support::seal($opened),'+/','-_'),'=');$ok('cursor_expired',$queue(['cursor'=>$expired])['code']==='cursor_invalido');
 $ok('cursor_filter_mismatch',$queue(['cursor'=>$cur,'filtro'=>'todos'])['code']==='cursor_invalido');$ok('cursor_clock_mismatch',$queue(['cursor'=>$cur,'agora'=>'2026-11-11T14:30:00Z'])['code']==='cursor_invalido');
 $f->rev='other';$ok('cursor_context_mismatch',$queue(['cursor'=>$cur])['code']==='cursor_invalido');$f->rev='qa-090';
 array_shift($f->leads);$r=$queue(['cursor'=>$cur]);$ok('offset_shift_detected',$r['code']==='coleta_parcial'&&in_array('colecao_concorrente',$r['data']['motivos'],true)&&$r['data']['devidos']===null&&$r['data']['proximo_cursor']===null);
 $seed(3);$f->fail='/api/v2/activities';$r=$queue(['agora'=>$clock]);$ok('source_failure_not_zero',$r['code']==='coleta_parcial'&&$r['data']['devidos']===null&&$r['data']['fim_da_fila']===null&&!array_filter($r['data']['itens'],fn($x)=>$x['devido']));
 $before=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE state='ready'");$r=Api::dispatch('configuracao-simular',['regras'=>$c,'revisao_esperada'=>Configuration::read()['revisao']]);$ok('source_failure_no_preview',$r['code']==='coleta_parcial'&&!isset($r['data']['previa_id'])&&$before===(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE state='ready'"));
 $f->fail='';$seed(201);for($j=1;$j<=51;$j++)$f->activities[]=['id'=>$j,'lead_id'=>$uuid(100+$j),'type'=>'whatsapp','done'=>true,'note'=>'Finalizada'];
 $r=$queue(['agora'=>$clock,'limite'=>40,'max_chamadas'=>10]);$d=$r['data'];$firstCost=count($f->calls);$continued=$queue(['cursor'=>$d['proximo_cursor'],'max_chamadas'=>10]);$later=array_slice($f->calls,$firstCost);
 $ok('dense_switches_to_scoped',$d['pagina_completa']&&$d['avaliados']===8&&$d['devidos']===8&&$firstCost===10&&$continued['data']['avaliados']===9&&!array_filter($later,fn($r)=>$r[0]==='/api/v2/activities'&&!isset($r[1]['lead_id'])));
 $c['textos'][0]['texto']=str_repeat('X',2200);Configuration::save($c,Configuration::read()['revisao']);$r=$queue(['cursor'=>$d['proximo_cursor']]);$ok('cursor_other_rules',$r['code']==='cursor_invalido');
 $seed(201);$r=$queue(['agora'=>$clock]);$n=$r['data']['avaliados'];$nextPage=$queue(['cursor'=>$r['data']['proximo_cursor']]);$ok('response_byte_budget_keeps_next_lead',$n>0&&$n<200&&array_column($nextPage['data']['itens'],'lead_id')[0]===$uuid($n+1));
 $f->fail='';$f->activities=$f->leads=[];$r=Api::dispatch('configuracao-simular',['regras'=>$c,'revisao_esperada'=>Configuration::read()['revisao']]);$ok('verified_empty_account',$r['code']==='simulacao_criada'&&$r['data']['simulacao']['fim_da_fila']&&$r['data']['simulacao']['avaliados']===0&&!$r['data']['simulacao']['amostra']);
 $ok('no_external_request',$http===0);
}finally{$ref->setValue(null,$old);remove_filter('pre_http_request',$block,PHP_INT_MAX);if($oldConfig===null)delete_option(Configuration::OPTION);else update_option(Configuration::OPTION,$oldConfig,false);}
return ['passed'=>count(array_filter($checks,fn($c)=>$c['passed'])),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'checks'=>$checks,'metricas'=>$metrics,'http_externo'=>$http];
