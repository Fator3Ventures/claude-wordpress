<?php
/** Safety and usability of local wp-admin. Requires a disposable native WordPress installation. */
use Fator3\Pipedrive\{Admin,AdminDocument,AdminForms,AdminRules,Configuration,CoreClient,Store,Support};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))throw new RuntimeException('Isolated WordPress required');
// Fault injection happens in temporary class copies, before autoload, in this disposable PHP process.
if(getenv('F3_QA_MUTACAO_PAINEL')==='1'){
    $mutants=[
        'AdminForms'=>["if(\$claimed==='new')","if(\$claimed!=='conflict')"],
        'AdminDocument'=>['if(strlen($source)<=24000)return [$source];','if(strlen($source)>24000)return [substr($source,0,24000)];']
    ];
    foreach($mutants as $cls=>[$find,$change]){
        if(class_exists('Fator3\\Pipedrive\\'.$cls,false))throw new RuntimeException('Classe carregada antes da mutação.');
        $original=file_get_contents(\Fator3\Pipedrive\ROOT.'/includes/'.$cls.'.php');
        $code=str_replace($find,$change,$original,$n);if($n!==1)throw new RuntimeException('Mutation target not unique');
        $path=tempnam(sys_get_temp_dir(),'f3pd-mut');try{file_put_contents($path,$code);require $path;}finally{unlink($path);}
    }
}
require_once __DIR__.'/fixture050.php';wp_set_current_user(1);$checks=[];$ok=static function($name,$pass)use(&$checks){$checks[$name]=(bool)$pass;};
$client=new ReflectionProperty(CoreClient::class,'client');$prior=$client->getValue();$f=new ReleaseFixture();$client->setValue(null,$f);
$state=[$_GET,$_POST,$_REQUEST,$_SERVER['REQUEST_METHOD']??'GET'];
try{
 $long="# Guia\n\n";for($n=1;$n<=15;++$n)$long.="## Seção $n\n\n".str_repeat('Observação de teste. ',210)."\n\n";$long.="### Fim\n\n```php\n## inerte\n```\n";
 $pages=AdminDocument::pages($long);$ok('guia_30kb_sem_truncagem',strlen($long)>30000&&count($pages)>1&&implode('',$pages)===$long);$html=implode('',array_map([AdminDocument::class,'render'],$pages));$ok('todas_as_partes_formatadas',substr_count($html,'<article')===count($pages)&&str_contains($html,'<pre tabindex="0"><code>## inerte</code></pre>')&&str_contains($html,'Seção 15'));
 $html=AdminDocument::render("## Local\n\n[Guia](PANEL.md) · [Seção](#local) · [Docs](https://developers.pipedrive.com/) · [Inseguro](javascript:alert) · [Fora](../../wp-config.php) · <script>bloqueado</script>");
 $ok('links_resolvidos_com_allowlist',str_contains($html,'documento=painel')&&str_contains($html,'href="#local"')&&str_contains($html,'href="https://developers.pipedrive.com/"'));
 $ok('documento_sem_execucao',!str_contains($html,'javascript:')&&!str_contains($html,'wp-config.php')&&!str_contains($html,'<script>'));
 $rules=Configuration::read();$post=['f3_pipedrive_action'=>'rules_simulate','_wpnonce'=>wp_create_nonce('f3pd_rules_edit'),'f3pd_tentativa'=>AdminForms::token(),'modo'=>'json','regras_json'=>wp_json_encode(Configuration::defaults()),'revisao_esperada'=>$rules['revisao'],'form_completo'=>'1'];
 $submit=static function($p){$_POST=wp_slash($p);$_REQUEST=$_POST;return AdminForms::submit();};
 $url=$submit($post);parse_str(parse_url($url,PHP_URL_QUERY),$_GET);$s=AdminForms::state();$reads=count($f->requests);$ok('prepara_prev_somente_no_post',!empty($s['preview'])&&$reads>0);
 $again=$submit($post);$ok('mesma_tentativa_mesma_previa_sem_custo',$again===$url&&AdminForms::state()['preview']===$s['preview']&&count($f->requests)===$reads);
 $tampered=$post;$tampered['regras_json']='{}';$denied=$submit($tampered);$ok('reenvio_com_outros_dados_nao_executa',str_contains($denied,'alterada=1')&&count($f->requests)===$reads);
 $token=$_GET['tentativa'];$_GET['tentativa']=substr($token,0,-1).($token[-1]==='0'?'1':'0');$ok('tentativa_adulterada_sem_dados',!isset(AdminForms::state()['preview']));$_GET['tentativa']=$token;
 wp_set_current_user(2);$ok('sessao_de_outro_ator_sem_dados',!isset(AdminForms::state()['preview']));wp_set_current_user(1);
 $ok('regras_inalteradas_apos_simulacao',Configuration::read()['revisao']===$rules['revisao']);
}finally{$client->setValue(null,$prior);[$_GET,$_POST,$_REQUEST,$_SERVER['REQUEST_METHOD']]=$state;}
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count(array_filter($checks,static fn($b)=>!$b))];
