<?php
/**
 * Microbenchmark PHP CLI, sem WordPress inicializado, rede ou banco.
 * php tests/bench-audit070.php /caminho/para/plugin/wp-mcp-pipedrive-fator3
 * Execute a mesma entrada sobre as duas árvores, usando o mesmo PHP e extensões.
 * A medição cobre Insights::audit, suas cinco listas/validação, consultas de status e a redução.
 */
declare(strict_types=1);
if (PHP_SAPI!=='cli'||PHP_VERSION_ID<80300||count($argv)!==2||defined('ABSPATH')) exit(2);
$plugin=realpath($argv[1]); if ($plugin===false||basename($plugin)!=='wp-mcp-pipedrive-fator3') exit(2);
define('ABSPATH',__DIR__.'/');
function register_activation_hook(...$args) {}
function add_action(...$args) {}
function is_user_logged_in() { return true; }
function current_user_can($cap) { return $cap==='manage_options'; }
function is_wp_error($v) { return false; }
function wp_json_encode($v,$flags=0) { return json_encode($v,$flags); }
function get_current_blog_id() { return 1; }
function get_current_user_id() { return 1; }
function home_url($p='/') { return 'https://bench.example.test'.$p; }
function rest_validate_value_from_schema(...$args) { return true; }
function rest_sanitize_boolean($v) { return (bool)$v; }
$wpdb=new class {
    public string $options='bench_pipedrive_options', $last_error='', $config='';
    public function prepare($sql,$key) { return $key; }
    public function get_var($key) { return $this->config; }
};
require $plugin.'/wp-mcp-pipedrive-fator3.php';
require_once __DIR__.'/fixture050.php';
use Fator3\Pipedrive\{Configuration,CoreClient,Insights};
$c=Configuration::defaults();
$c['auditoria']=['campos_origem'=>['f1','f2','f3','f4'],'separador_titulo'=>' / ','etapas'=>[['id'=>1,'alerta_minutos'=>120,'primeira'=>true]],'tipos_reuniao'=>['meeting']];
$wpdb->config=json_encode($c);
$provider=new class {
    public array $rows=[];
    public int $calls=0;
    private ReleaseFixture $base;
    public function __construct() { $this->base=new ReleaseFixture(); }
    public function status(){ return $this->base->status(); }
    public function request($m,$p,$q,$b,$context) {
        if ($m!=='GET') throw new LogicException('Only reads allowed');
        ++$this->calls; $this->base->spent+=20;
        $off=(int)($q['start']??$q['cursor']??0); $rows=$this->rows[$p]??[]; $size=$q['limit']; $more=$off+$size<count($rows);
        $page=str_starts_with($p,'/api/v2/')?['next_cursor'=>$more?(string)($off+$size):null]:['pagination'=>['more_items_in_collection'=>$more,'next_start'=>$more?$off+$size:null]];
        return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>array_slice($rows,$off,$size),'additional_data'=>$page],'saldo_conta'=>null]];
    }
};
for ($j=1;$j<=2000;++$j) {
    $uid=sprintf('7a000000-0000-4000-8000-%012d',$j);
    $provider->rows['/v1/leads'][]=['id'=>$uid,'title'=>'QA / Registro','f1'=>1,'f2'=>2,'f3'=>3,'f4'=>4];
    $provider->rows['/api/v2/deals'][]=['id'=>$j,'status'=>'open','stage_id'=>1,'stage_change_time'=>'2026-11-05T14:00:00Z'];
    $provider->rows['/api/v2/activities'][]=['id'=>$j,'lead_id'=>$uid,'deal_id'=>$j,'type'=>'meeting','done'=>$j%100===0,'due_date'=>$j%100===0?'2026-11-04':'2026-11-06'];
}
(new ReflectionProperty(CoreClient::class,'client'))->setValue(null,$provider);
function audit_bench_run() { return Insights::audit(['agora'=>'2026-11-05T16:00:00Z']); }
audit_bench_run(); // Warm CPU, autoload and PHP filesystem caches outside the timed sample.
$provider->calls=0;
$start=hrtime(true); $result=audit_bench_run(); $ms=(hrtime(true)-$start)/1e6;
$data=$result['data'];
if (!$data['coleta_completa']||!$data['avaliacao_completa']||count($data['itens'])!==40||$provider->calls!==62) exit(3);
echo json_encode(['version'=>Fator3\Pipedrive\VERSION,'php'=>PHP_VERSION,'records'=>6000,'read_calls'=>$provider->calls,
    'findings'=>count($data['itens']),'findings_sha256'=>hash('sha256',json_encode($data['itens'])),'elapsed_ms'=>round($ms,3)]),"\n";
