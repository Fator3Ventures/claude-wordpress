<?php
use Fator3\Pipedrive\{WhatsAppNote,Fault};
if(!defined('F3_PIPEDRIVE_DISPOSABLE'))exit(2);
$c=['fuso'=>'America/Sao_Paulo','nota'=>['prefixo'=>'','formato'=>'Y-m-d\TH:i:sP','autor'=>'nós']];
$i=['mensagem'=>'Olá <b> & você?','proximo'=>'Marcar <hora>'];
$when=strtotime('2026-11-13T16:20:00Z');
$first=WhatsAppNote::compose('',$i,$when,$c);$expected='<p>[IA]</p><p>13/11 13h20, nós: Olá &lt;b&gt; &amp; você?</p><p>Próximo: Marcar &lt;hora&gt;</p>';
$checks=['nota_nova_exata'=>$first===$expected];
$second=WhatsAppNote::compose($first,['mensagem'=>'Posso às 14h.','autor'=>'João','proximo'=>'Confirmar sexta'],$when,$c);
$checks['nota_existente_e_rodape_trocado']=$second==='<p>[IA]</p><p>13/11 13h20, nós: Olá &lt;b&gt; &amp; você?</p><p>13/11 13h20, João: Posso às 14h.</p><p>Próximo: Confirmar sexta</p>';
$old='<div><b>[IA]</b>&nbsp;07/11 10h42, nós: antiga <a href="https://example.test">referência</a><br>[IA] 07/11 11h00, Lia: A expressão [IA] e Próximo: foi citada.<br><strong>Próximo:</strong> desatualizado</div>';
$res=WhatsAppNote::compose($old,$i,$when,$c);
$checks['historico_html_preservado']=str_contains($res,'<a href="https://example.test">referência</a>');
$checks['prefixos_operacionais_removidos']=!str_contains($res,'[IA] 07/')&&!str_contains($res,'<b>[IA]</b>');
$checks['citacao_literal_preservada']=str_contains($res,'A expressão [IA] e Próximo: foi citada.');
$checks['substitui_rodape_html']=!str_contains($res,'desatualizado')&&str_ends_with($res,'<p>Próximo: Marcar &lt;hora&gt;</p>');
$old="Conversa manual\n[IA] 05/11 10h00, nós: Oi\nPróximo: antigo";
$res=WhatsAppNote::compose($old,$i,$when,$c);$checks['texto_plano_preservado']=str_contains($res,'Conversa manual')&&str_contains($res,'05/11 10h00, nós: Oi')&&!str_contains($res,'antigo');
$res=WhatsAppNote::compose('<blockquote>Próximo: citado pelo contato</blockquote>',$i,$when,$c);
$checks['bloco_citado_preservado']=str_contains($res,'<blockquote>Próximo: citado pelo contato</blockquote>');
$checks['reescrita_do_provedor_aceita']=WhatsAppNote::layoutDigest($first)===WhatsAppNote::layoutDigest(str_replace(['<p>','</p>'],['<div>','</div>'],$first));
$checks['rodape_fundido_detectado']=WhatsAppNote::layoutDigest($first)!==WhatsAppNote::layoutDigest(str_replace('</p><p>Próximo:',' Próximo:',$first));
foreach(['ausente'=>['mensagem'=>'Oi'],'branco'=>['proximo'=>' ','mensagem'=>'Oi'],'multilinha'=>['proximo'=>"A\nB",'mensagem'=>'Oi'],'autor_multilinha'=>['autor'=>"A\nB"]+$i] as $name=>$bad){
 try{WhatsAppNote::validate($bad);$checks[$name]=false;}catch(Fault $e){$checks[$name]=$e->reason==='entrada_invalida';}
}
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count($checks)-count(array_filter($checks))];
