<?php
/** Isolated WordPress, domain capability, schema, native REST and MCP authorization boundary. */
use Fator3\Pipedrive\{Api,Policy,Fault,Configuration,Store};
global $wpdb;if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_'))throw new RuntimeException('Disposable only');
wp_set_current_user(1);$checks=[];$http=0;
$net=static function()use(&$http){++$http;return new WP_Error('no_http','Test.');};add_filter('pre_http_request',$net);
try{
 foreach(['/v1/users','/v1/mailbox/mailMessages','/v1/mailbox/mailThreads','/v1/deals','/v1/leads/merge','https://invalid.test/v1/leads'] as $p){
  try{Policy::route('GET',$p);$checks['deny_'.$p]=false;}catch(Fault $e){$checks['deny_'.$p]=$e->reason==='caminho_fora_da_lista';}
 }
 foreach(['pendencias-ler','recuperacao-previa','recuperacao-confirmar'] as $op){$a=wp_get_ability('pipedrive/'.$op);$meta=$a?$a->get_meta():[];$checks[$op.'_catalog_effects']=($meta['annotations']['readonly']??null)===($op==='pendencias-ler')&&($meta['fator3']['remote_effect']??null)===($op==='pendencias-ler'?'none':'read');}
 $checks['mcp_without_authenticated_policy_denied']=Api::dispatch('documentacao-ler',[],true)['code']==='nao_autorizado';
 $resp=rest_do_request(new WP_REST_Request('GET','/f3-pipedrive/v1/documentacao-ler'));
 $checks['administrator_native_help']=$resp->get_status()===200&&($resp->get_data()['success']??false);
 $checks['client_cannot_request_native_confirmation']=Api::dispatch('operacao-aplicar',['previa_id'=>str_repeat('a',32),'origem'=>'painel'])['code']==='entrada_invalida';
 // A second administrator-saving request must not overwrite the newer stored revision.
 $savedOption=get_option(Configuration::OPTION,null);require_once __DIR__.'/fixture050.php';$fc=new ReleaseFixture();
 $prop=new ReflectionProperty(\Fator3\Pipedrive\CoreClient::class,'client');$oldClient=$prop->getValue();$prop->setValue(null,$fc);
 $priorPost=$_POST;$priorRequest=$_REQUEST;$ids=[];
 try{
  $rules=Configuration::defaults();update_option(Configuration::OPTION,\Fator3\Pipedrive\Support::json($rules),false);
  $revision=Configuration::read()['revisao'];$nextRules=$rules;$nextRules['feriados']=['2030-03-12'];
  $sim=Api::dispatch('configuracao-simular',['revisao_esperada'=>$revision,'regras'=>$nextRules]);$sid=$sim['data']['previa_id']??'';if(!$sid)throw new RuntimeException('Expected config preview');$ids[]=$sid;
  $wrong=Api::dispatch('recuperacao-confirmar',['previa_id'=>$sid,'confirmacao'=>'texto incorreto']);
  $checks['recovery_wrong_phrase_refused']=$wrong['code']==='confirmacao_ausente'&&Store::get($sid)['state']==='ready';
  $other=$rules;$other['feriados']=['2030-12-20'];$current=Configuration::save($other,$revision);$denied=false;
  try{Configuration::save($nextRules,$revision);}catch(Fault $e){$denied=$e->reason==='revisao_conflitante';}
  $checks['stale_direct_save_cannot_overwrite']=$denied&&Configuration::read()['revisao']===$current['revisao'];
  $r=Api::dispatch('operacao-aplicar',['previa_id'=>$sid,'confirmacao'=>$sim['data']['confirmacao_exigida']]);
  $checks['stale_preview_rejected_before_claim']=$r['code']==='revisao_conflitante'&&Store::get($sid)['state']==='ready'&&Configuration::read()['revisao']===$current['revisao'];
  $rules=Configuration::read()['regras'];$rev=Configuration::read()['revisao'];$token=\Fator3\Pipedrive\AdminForms::token();
  $_POST=$_REQUEST=wp_slash(['f3_pipedrive_action'=>'rules_simulate','form_completo'=>'1','modo'=>'json','revisao_esperada'=>$rev,'regras_json'=>wp_json_encode($rules),'_wpnonce'=>wp_create_nonce('f3pd_rules_edit'),'f3pd_tentativa'=>$token]);
  $t=Store::table('ops');$beforeCount=(int)$wpdb->get_var("SELECT COUNT(*) FROM $t");$beforeCalls=count($fc->requests);
  $url=\Fator3\Pipedrive\AdminForms::submit();$afterCount=(int)$wpdb->get_var("SELECT COUNT(*) FROM $t");$afterCalls=count($fc->requests);$again=\Fator3\Pipedrive\AdminForms::submit();
  $checks['same_POST_one_preview_one_cost']=$url===$again&&$afterCount===$beforeCount+1&&$afterCount===(int)$wpdb->get_var("SELECT COUNT(*) FROM $t")&&$afterCalls>$beforeCalls&&$afterCalls===count($fc->requests);
  delete_option('f3_pd_form_'.substr($token,0,43));delete_transient('f3_pd_form_'.$token);
  $long=str_repeat("## Seção com acento\n\nParágrafo de documentação.\n\n",710);
  $pages=\Fator3\Pipedrive\AdminDocument::pages($long);
  $checks['long_guide_readable_in_sections']=count($pages)>1&&implode('',$pages)===$long&&array_reduce($pages,static fn($ok,$page)=>$ok&&str_contains(\Fator3\Pipedrive\AdminDocument::render($page),'<h3'),true);
 }finally{
  $_POST=$priorPost;$_REQUEST=$priorRequest;$prop->setValue(null,$oldClient);
  foreach($ids as $id){$wpdb->delete(Store::table('ops'),['previa_id'=>$id]);$wpdb->delete(Store::table('journal'),['previa_id'=>$id]);}
  if($savedOption===null)delete_option(Configuration::OPTION);else update_option(Configuration::OPTION,$savedOption,false);
 }
 wp_set_current_user(0);foreach(['pendencias-ler','configuracao-ler','recuperacao-confirmar'] as $op){$checks[$op.'_anonymous_denied']=Api::dispatch($op)['code']==='nao_autorizado';}
 $resp=rest_do_request(new WP_REST_Request('GET','/f3-pipedrive/v1/pendencias-ler'));$checks['anonymous_blocked_on_rest']=in_array($resp->get_status(),[401,403],true);
 $checks['no_http']=$http===0;
}finally{wp_set_current_user(1);remove_filter('pre_http_request',$net);}
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count($checks)-count(array_filter($checks)),'supplier_http'=>$http];
