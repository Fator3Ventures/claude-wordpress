<?php
/** Regression of the 0.8.0/1.78.0 adapter probe, with real WordPress receipts and markers. */
use Fator3\Pipedrive\{Api,Configuration,CoreClient,Store,Support};
global $wpdb;
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||F3_PIPEDRIVE_DISPOSABLE!==true||!str_starts_with($wpdb->prefix,'f3pipqa_'))throw new RuntimeException('Disposable only');
wp_set_current_user(1);require_once __DIR__.'/fixture050.php';
$fixture=new ReleaseFixture();
$client=new class($fixture) {
    public array $raw=[];public int $sends=0;
    public function __construct(public ReleaseFixture $f){}
    public function status(){return $this->f->status();}
    public function request($method,$path,$query,$body,$ctx){
        if($method==='GET')return $this->f->request($method,$path,$query,$body,$ctx);
        ++$this->sends;return $this->raw;
    }
};
$ref=new ReflectionProperty(CoreClient::class,'client');$old=$ref->getValue();$ref->setValue(null,$client);
$prior=get_option(Configuration::OPTION,null);$cfg=Configuration::defaults();$cfg['lost_reasons']=['fixture'];update_option(Configuration::OPTION,Support::json($cfg),false);
$checks=[];$ids=[];$keys=[];$http=0;
$guard=static function()use(&$http){++$http;return new WP_Error('test_http','No provider HTTP.');};add_filter('pre_http_request',$guard);
try{
 $n=0;
 foreach([
    'invalid_2xx'=>['resultado_incerto',200,null,true],
    'oversized_2xx'=>['resposta_excedeu_limite',200,null,true],
    'malformed_success'=>['ok',200,null,true],
    'missing_data'=>['ok',200,['success'=>true],true],
    'ambiguous_408'=>['fornecedor_recusou',408,null,true],
    'server_503'=>['resultado_incerto',503,null,true],
    'known_422'=>['fornecedor_recusou',422,null,false]
 ] as $name=>[$code,$status,$body,$uncertain]){
    $id=900000+(++$n);$path='/api/v2/deals/'.$id;$fixture->data[$path]=['id'=>$id,'status'=>'open','is_archived'=>false];
    $scope=Support::digest($fixture->status()['data']['conta']).':deal:'.$id;
    $marker=Store::CANONICAL_PENDING.hash('sha256',$scope);$keys[]=$marker;
    $client->raw=['success'=>$code==='ok','code'=>$code,'remote_dispatched'=>true,'data'=>['http_status'=>$status,'body'=>$body,'saldo_conta'=>null]];
    $preview=Api::dispatch('negocio-perder',['negocio_id'=>$id,'lost_reason'=>'fixture']);$pid=$preview['data']['previa_id']??'';
    if(!$pid)throw new RuntimeException('Fixture preview: '.$preview['code']);$ids[]=$pid;$input=['previa_id'=>$pid];
    $before=$client->sends;$result=Api::dispatch('operacao-aplicar',$input);
    $checks[$name.'_decision']=$result['code']===($uncertain?'resultado_parcial_ou_incerto':'operacao_recusada')&&$result['data']['reconciliacao_necessaria']===$uncertain&&$client->sends===$before+1;
    $checks[$name.'_stored_marker']=$uncertain ? get_option($marker) === $pid : get_option($marker)===false;
    $checks[$name.'_receipt_saved']=Store::get($pid)['state']==='done' && Api::dispatch('operacao-aplicar',$input)===$result && $client->sends===$before+1;
    if($name==='invalid_2xx'){
       update_option('f3_qa_090_uncertain_restart',['id'=>$pid,'marker'=>$marker,'path'=>$path,'hash'=>Support::digest($result)],false);
       $ids=array_diff($ids,[$pid]);$keys=array_diff($keys,[$marker]);
    }
    if($uncertain){
       $rp=Api::dispatch('api-previa',['metodo'=>'DELETE','caminho'=>$path]);$rid=$rp['data']['previa_id']??'';if($rid)$ids[]=$rid;
       $rr=$rid?Api::dispatch('api-aplicar',['previa_id'=>$rid]):$rp;
       $checks[$name.'_blocks_independent_write']=$rr['code']==='reconciliacao_necessaria'&&$client->sends===$before+1;
    }
 }
 $checks['no_provider_http']=$http===0;
}finally{
 foreach($keys as $k)delete_option($k);
 foreach($ids as $id){$wpdb->delete(Store::table('ops'),['previa_id'=>$id]);$wpdb->delete(Store::table('journal'),['previa_id'=>$id]);}
 $ref->setValue(null,$old);if($prior===null)delete_option(Configuration::OPTION);else update_option(Configuration::OPTION,$prior,false);remove_filter('pre_http_request',$guard);
}
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count($checks)-count(array_filter($checks)),'supplier_http'=>$http];
