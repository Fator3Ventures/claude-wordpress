<?php
/** WP/InnoDB boundary with synthetic CRM. Tests never run on the shared site. */
use Fator3\Pipedrive\{Api,CoreClient,Configuration,Store,Support,Progress};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))throw new RuntimeException('Disposable only');
require_once __DIR__.'/fixture050.php';wp_set_current_user(1);$items=[];$test=static function($name,$out)use(&$items){$items[]=['name'=>$name,'passed'=>(bool)$out];};
$f=new ReleaseFixture();$transport=new class($f){
    public bool $badRead=false;public bool $badWrite=false;public bool $swapped=false;
    public function __construct(public $f){}
    public function status(){$s=$this->f->status();if($this->swapped)$s['data']['conta']['conta_id']=402;return $s;}
    public function request($m,$path,$q,$b,$ctx){$v=$this->f->request($m,$path,$q,$b,$ctx);
        if($this->badRead&&$m==='GET'&&preg_match('~/activities/\d+$~',$path))$v['data']['body']['data']['note']='resposta incorreta';
        if($this->badWrite&&$m==='PATCH')return ['success'=>false,'code'=>'resultado_incerto','remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>null,'saldo_conta'=>null]];
        return $v;}
};
$prop=new ReflectionProperty(CoreClient::class,'client');$prev=$prop->getValue();$prop->setValue(null,$transport);$old=get_option(Configuration::OPTION,null);
$c=Configuration::defaults();$c['lost_reasons']=['fixture'];$c['habilitada']=true;$c['tipo_whatsapp']='whatsapp';$c['dias']=[1,2,3,4,5,6,7];$c['periodos']=[['codigo'=>'manha','hora'=>'09:30']];$c['textos']=[['codigo'=>'m','texto'=>'Teste']];$c['toques']=[['codigo'=>'t1','base'=>'entrada','atraso_minutos'=>0,'texto_id'=>'m','etiqueta_id'=>''],['codigo'=>'t2','base'=>'ultimo_registro','atraso_minutos'=>60,'texto_id'=>'m','etiqueta_id'=>'']];
$ok=static function($r){if(!$r['success'])throw new RuntimeException($r['code'].' '.$r['message']);return $r['data'];};
$run=substr(bin2hex(random_bytes(6)),0,12);$id='90000000-0000-4000-8000-'.$run;
$sent=['lead_id'=>$id,'mensagem'=>'privado-sintetico-'.$run,'toque'=>'t1','proximo'=>'Combinar horário','chave_idempotencia'=>'recovery-'.$run];
$account=$transport->status()['data']['conta'];$lead=['id'=>$id,'person_id'=>561,'is_archived'=>false,'label_ids'=>[],'add_time'=>'2026-11-01T12:00:00Z'];$f->data['/v1/leads/'.$id]=$lead;
$prepare=fn($r)=>$ok(Api::dispatch('recuperacao-previa',$r));$confirm=fn($p)=>Api::dispatch('recuperacao-confirmar',['previa_id'=>$p['previa_id'],'confirmacao'=>$p['confirmacao_exigida']]);
try{
    update_option(Configuration::OPTION,Support::json($c),false);
    $transport->badRead=true;$original=Api::dispatch('whatsapp-registrar',$sent);$receipt=$original['previa_id']??'';
    $test('incerta_com_marcador',!$original['success']&&$original['data']['reconciliacao_necessaria']&&strlen($receipt)===32);
    $writes=$f->writes;$calls=count($f->requests);
    $pending=$ok(Api::dispatch('pendencias-ler',['limite'=>50]));$test('listar_sem_http',count($f->requests)===$calls&&in_array($receipt,array_column($pending['itens'],'origem_id'),true));
    $test('lista_sem_mensagem_e_sem_prova_cifrada',!str_contains(Support::json($pending),$sent['mensagem'])&&!str_contains(Support::json($pending),'prova_recuperacao'));
    $test('nota_incorreta_nao_soluciona',Api::dispatch('recuperacao-previa',['origem_id'=>$receipt])['code']==='recuperacao_inconclusiva');
    $transport->swapped=true;$foreignList=$ok(Api::dispatch('pendencias-ler',['limite'=>50]));$test('outra_conta_nao_enumera',!in_array($receipt,array_column($foreignList['itens'],'origem_id'),true));
    $test('outra_conta_nao_revisa',!Api::dispatch('recuperacao-previa',['origem_id'=>$receipt])['success']);$transport->swapped=false;$transport->badRead=false;
    $activityPath='/api/v2/activities/'.end($f->data['/api/v2/activities'])['id'];
    $savedNote=$f->data[$activityPath]['note'];$f->data[$activityPath]['note']=str_replace('</p><p>Próximo:',' Próximo:',$savedNote);
    $test('rodape_fundido_nao_libera',Api::dispatch('recuperacao-previa',['origem_id'=>$receipt])['code']==='recuperacao_inconclusiva');
    $f->data[$activityPath]['note']=$savedNote;
    $p=$prepare(['origem_id'=>$receipt]);$test('resolucao_somente_efeito_integral',$p['resolucao']==='efeito_confirmado'&&$p['toque_preservado']==='t1');
    $duplicate=$prepare(['origem_id'=>$receipt]);$test('frase_obrigatoria',Api::dispatch('recuperacao-confirmar',['previa_id'=>$p['previa_id'],'confirmacao'=>'Confirmo'])['code']==='confirmacao_ausente');
    $transport->swapped=true;$test('troca_conta_entre_previa_e_confirmacao',$confirm($p)['code']==='contexto_alterado');$transport->swapped=false;
    $admin2=wp_insert_user(['user_login'=>'recup_'.$run,'user_pass'=>wp_generate_password(40),'role'=>'administrator']);if(is_wp_error($admin2))throw new RuntimeException('create fixture admin');
    wp_set_current_user($admin2);$test('outro_admin_recusado',$confirm($p)['code']==='previa_de_outro_usuario');
    $other=$ok(Api::dispatch('pendencias-ler'));$test('outro_admin_nao_lista',!in_array($receipt,array_column($other['itens'],'origem_id'),true));wp_set_current_user(1);
    $j=Store::table('journal');$fail=static fn($sql)=>str_starts_with($sql,'INSERT')&&str_contains($sql,$j)&&str_contains($sql,'recuperacao-confirmar')?'INSERT INTO qa_missing_recuperacao090 VALUES (1)':$sql;
    add_filter('query',$fail);$hide=$wpdb->suppress_errors(true);try{$res=$confirm($p);}finally{remove_filter('query',$fail);$wpdb->suppress_errors($hide);}
    $test('falha_auditoria_reverte_movimentos',$res['code']==='persistencia_falhou'&&Store::get($p['previa_id'])['state']==='ready'&&Progress::stored($account,$id)===null);
    $pending=$ok(Api::dispatch('pendencias-ler',['limite'=>50]));$test('falha_auditoria_preserva_marcador',in_array($receipt,array_column($pending['itens'],'origem_id'),true));
    $before=Store::get($receipt)['result'];$res=$confirm($p);$ok($res);$cursor=Progress::stored($account,$id);
    $test('resolucao_atomica_sem_reenvio',$cursor['touch']==='t1'&&$f->writes===$writes&&$res['code']==='recuperacao_confirmada');
    $test('recibo_original_imutavel',Store::get($receipt)['result']===$before&&Api::dispatch('whatsapp-registrar',$sent)===$original);
    $calls=count($f->requests);$test('replay_recibo_sem_get_ou_write',$confirm($p)===$res&&count($f->requests)===$calls);
    $test('segunda_previa_concorrente_nao_aplicavel',!$confirm($duplicate)['success']);
    $journal=$ok(Api::dispatch('registro-ler',['limite'=>100]));$test('diario_exibe_decisao_sem_prova_privada',in_array('pipedrive/recuperacao-confirmar',array_column($journal['itens'],'caminho'),true)&&!str_contains(Support::json($journal),'prova_recuperacao'));
    $activityId=$cursor['activity_id'];$key='/api/v2/activities/'.$activityId;$f->data[$key]['note'].='<p>Acréscimo manual de bancada.</p>';
    $p=$prepare(['lead_id'=>$id]);$test('revisao_exibe_toque_anterior',$p['resolucao']==='realinhar_nota'&&$p['toque_preservado']==='t1');
    $f->data[$key]['note'].='<p>Nova edição paralela.</p>';$test('mudanca_depois_da_previa_recusada',$confirm($p)['code']==='estado_alterado');
    $p=$prepare(['lead_id'=>$id]);$ok($confirm($p));$now=Progress::read($account,$id,$f->data[$key]);$test('realinhamento_preserva_indice_data_e_identidade',$now['time']===$cursor['time']&&$now['touch']===$cursor['touch']&&$now['receipt_id']===$receipt&&$f->writes===$writes);
    $f->data['/api/v2/activities']=[];$test('atividade_excluida_nao_realinha',Api::dispatch('recuperacao-previa',['lead_id'=>$id])['code']==='recuperacao_inconclusiva');
    $marker=Store::CANONICAL_PENDING.hash('sha256',Support::digest($account).':lead:'.$id);
    add_option($marker,$receipt,'',false);$raw=$wpdb->get_var($wpdb->prepare("SELECT metadata FROM $j WHERE previa_id=%s",$receipt));$meta=json_decode($raw,true);unset($meta['prova_recuperacao']);$wpdb->update($j,['metadata'=>Support::json($meta)],['previa_id'=>$receipt]);
    $f->revision.='_revisao_seguinte';$leg=$ok(Api::dispatch('pendencias-ler',['limite'=>50]));$row=array_values(array_filter($leg['itens'],fn($x)=>$x['origem_id']===$receipt));
    $test('legado_visivel_apos_migracao_sem_inventar_prova',count($row)===1&&$row[0]['situacao']==='sem_prova_de_intencao'&&Api::dispatch('recuperacao-previa',['origem_id'=>$receipt])['code']==='recuperacao_inconclusiva');
    delete_option($marker);$test('nenhuma_escrita_na_recuperacao',$f->writes===$writes);
    // The supplier changed the deal, but the Core could not parse its response.
    $f->data['/api/v2/deals/62191']=['id'=>62191,'status'=>'open','is_archived'=>false];
    $loss=$ok(Api::dispatch('negocio-perder',['negocio_id'=>62191,'lost_reason'=>'fixture']));
    $transport->badWrite=true;$failed=Api::dispatch('operacao-aplicar',['previa_id'=>$loss['previa_id']]);$transport->badWrite=false;
    $test('negocio_2xx_ilegivel_exige_reconciliacao',$failed['code']==='resultado_parcial_ou_incerto');
    $w=$f->writes;$f->data['/api/v2/deals/62191']['lost_reason']='outro motivo';
    $test('negocio_com_motivo_divergente_recusado',Api::dispatch('recuperacao-previa',['origem_id'=>$loss['previa_id']])['code']==='recuperacao_inconclusiva');
    $f->data['/api/v2/deals/62191']['lost_reason']='fixture';
    $p=$prepare(['origem_id'=>$loss['previa_id']]);$ok($confirm($p));$test('negocio_somente_desfecho_correto_sem_reaplicar',$p['resolucao']==='efeito_confirmado'&&$p['registro_id']==='62191'&&$f->writes===$w);
    $archivedId='90000001-0000-4000-8000-'.$run;$path='/v1/leads/'.$archivedId;
    $archive=['id'=>$archivedId,'title'=>'Mesmo valor','is_archived'=>true,'archive_time'=>'2026-11-01T12:00:00Z','archive_reason'=>'fixture'];$f->data[$path]=$archive;
    $edit=$ok(Api::dispatch('lead-arquivado-editar',['lead_id'=>$archivedId,'campos'=>['title'=>'Mesmo valor']]));
    $transport->badWrite=true;$res=Api::dispatch('operacao-aplicar',['previa_id'=>$edit['previa_id']]);$transport->badWrite=false;
    $f->data[$path]=$archive; // provider still reports the original state after the first uncertain PATCH
    $test('arquivo_com_estado_original_nao_prova_ciclo_concluido',$res['code']==='resultado_parcial_ou_incerto'&&Api::dispatch('recuperacao-previa',['origem_id'=>$edit['previa_id']])['code']==='recuperacao_inconclusiva');
    delete_option(Store::CANONICAL_PENDING.hash('sha256',Support::digest($account).':lead:'.$archivedId));
}finally{$prop->setValue(null,$prev);if($old===null)delete_option(Configuration::OPTION);else update_option(Configuration::OPTION,$old,false);wp_set_current_user(1);if(!empty($admin2)&&!is_wp_error($admin2)){require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($admin2);}}
return ['checks'=>$items,'passed'=>count(array_filter($items,fn($x)=>$x['passed'])),'failed'=>count(array_filter($items,fn($x)=>!$x['passed']))];
