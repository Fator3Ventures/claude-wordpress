<?php
declare(strict_types=1);

/** Release documentation as a user contract: exercise WP's reader, routes and semantics.
 * No writes to the installed docs; mutation experiments only edit copies in memory.
 */
use Fator3\Pipedrive\{Api,Configuration,Documentation,Retention};
use const Fator3\Pipedrive\{ROOT,VERSION};

if (!defined('F3_PIPEDRIVE_DISPOSABLE') || !str_starts_with($wpdb->prefix, 'f3pipqa_0900')) {
    throw new RuntimeException('Disposable WordPress required.');
}
wp_set_current_user(1);
$checks = []; $docs = []; $pages = 0;
$check = static function(string $name, bool $passed) use (&$checks): void { $checks[$name] = $passed; };
$calls = 0; $guard = static function($pre) use (&$calls) { ++$calls; return new WP_Error('unexpected_http'); };
add_filter('pre_http_request', $guard, 1);
try {
    foreach (Documentation::DOCUMENTS as $id => $file) {
        $text = ''; $sha = null; $offset = 0; $ok = true;
        do {
            $args = ['documento'=>$id, 'limite_bytes'=>991, 'offset'=>$offset];
            if ($sha !== null) $args['sha256_esperado'] = $sha;
            $r = Api::dispatch('documentacao-ler', $args);
            $d = $r['data'];
            if (!$r['success'] || !is_array($d) || $d['offset'] !== $offset || $d['version'] !== VERSION
                || $d['origem'] !== 'local' || $sha !== null && $d['sha256'] !== $sha || !mb_check_encoding($d['conteudo'], 'UTF-8')) {
                $ok = false; break;
            }
            ++$pages; $text .= $d['conteudo']; $sha = $d['sha256']; $offset = $d['proximo_offset'];
            if ($offset !== null && ($offset !== strlen($text) || $d['fim'] || $d['conteudo'] === '' || $offset > $d['total_bytes'])) {
                $ok = false; break;
            }
        } while ($offset !== null);
        $docs[$id] = $text;
        $check("leitura_integral_$id", $ok && $d['fim'] && hash('sha256',$text) === $sha && $sha === hash_file('sha256', ROOT.'/docs/'.$file));
    }
    $routes = rest_get_server()->get_routes();
    $schemas = Api::schemas(); $docsSchemas = json_decode($docs['schemas'],true);
    $check('schemas_instalados_iguais_ao_registro', $docsSchemas['version']===VERSION && $docsSchemas['input']===$schemas && $docsSchemas['output']===Api::outputSchema());
    $check('limite_integridade_na_continuacao', Api::dispatch('documentacao-ler',['documento'=>'uso','offset'=>1,'sha256_esperado'=>str_repeat('0',64)])['code']==='documento_alterado');
    $check('percurso_confinado', Api::dispatch('documentacao-ler',['documento'=>'../wp-config.php'])['code']==='documento_invalido');
    // Verify syntax, catalog, runnable configuration and narrative continuation from the SAME documents read above.
    $audit = static function(array $d) use ($schemas,$routes): array {
        $fail = [];
        $assert = static function(bool $ok,string $tag) use (&$fail):void { if (!$ok) $fail[]=$tag; };
        preg_match_all('/^\| `([a-z0-9-]+)` \| (GET|POST) \|/m',$d['especificacao'],$rows,PREG_SET_ORDER);
        $expected=array_keys($schemas);sort($expected);
        $seen=[];
        foreach($rows as $row){
            $seen[]=$row[1];$registrations=$routes['/f3-pipedrive/v1/'.$row[1]]??[];
            $assert((bool)array_filter($registrations,static fn($reg)=>!empty($reg['methods'][$row[2]])),'metodo_'.$row[1]);
        }
        sort($seen);$assert($seen===$expected,'catalogo');
        $q=$schemas['cadencia-fila']['properties']['limite'];
        preg_match('/\| Leads por página da fila [^|]+\| (\d+) a (\d+);/u',$d['especificacao'],$m);
        $assert(isset($m[2]) && (int)$m[1]===$q['minimum'] && (int)$m[2]===$q['maximum'],'limite_fila');
        preg_match('/\| Recibo comum \| (\d+) dias \|/u',$d['especificacao'],$m);
        $assert(isset($m[1]) && (int)$m[1]===Retention::RECEIPT_DAYS,'prazo_recibo');
        $assert(str_contains($d['contratos'],'`lead_sem_pessoa`') && str_contains($d['contratos'],'`recuperacao_inconclusiva`'),'codigos_de_acao');
        $assert(!preg_match('/\b(?:delete_option|wp option delete|DELETE FROM)\b/i',$d['operacao']),'recuperacao_sem_comando_destrutivo');
        foreach($d as $id=>$text){
            if(!str_ends_with(Documentation::DOCUMENTS[$id],'.md'))continue;
            preg_match_all('/\[[^\]\n]+\]\(([^)\s]+)\)/u',$text,$links);
            foreach($links[1] as $url){
                $safe=str_starts_with($url,'#') || in_array($url,Documentation::DOCUMENTS,true)
                    || preg_match('~^https://[^\s\x00-\x1f]+$~D',$url);
                $assert((bool)$safe,'link_'.$id);
            }
            preg_match_all('/^\x60\x60\x60json\R(.+?)\R\x60\x60\x60/ms',$text,$blocks);
            foreach($blocks[1] as $json){
                try { json_decode($json,true,512,JSON_THROW_ON_ERROR); } catch(Throwable) { $assert(false,'json_'.$id); }
            }
        }
        preg_match('/^\x60\x60\x60json\R(.+?)\R\x60\x60\x60/ms',$d['painel'],$block);
        $sample=json_decode($block[1]??'',true);
        try {Configuration::validate($sample??[]);$valid=true;}catch(Throwable){$valid=false;}
        $assert($valid && ($sample['habilitada']??false)===true,'exemplo_configuravel');
        preg_match_all('/^\x60\x60\x60json\R(.+?)\R\x60\x60\x60/ms',$d['uso'],$u);
        $queue=$sent=$empty=[];
        foreach($u[1] as $block){
            $v=json_decode($block,true);if(!is_array($v))continue;
            if(isset($v['texto_aprovado']))$queue=$v;
            if(isset($v['chave_idempotencia']))$sent=$v;
            if(isset($v['pagina_completa']))$empty=$v;
        }
        $assert(!empty($sent['proximo']),'exemplo_tem_proximo');
        $assert($queue&&$sent&&$queue['lead_id']===$sent['lead_id']&&$queue['toque']===$sent['toque']&&$queue['texto_aprovado']===$sent['mensagem'],'envio_corresponde_fila');
        $assert($empty&&$empty['pagina_completa']===true&&$empty['itens']===[]&&$empty['devidos']===0&&$empty['avaliados']>0&&$empty['fim_da_fila']===false&&!empty($empty['proximo_cursor']),'vazia_tem_continuacao');
        return $fail;
    };
    $failures = $audit($docs);
    $check('manual_sem_divergencia', $failures===[]);
    $mutations=[
        ['especificacao','1 a 200; padrão 200','1 a 250; padrão 200','limite_fila'],
        ['especificacao','| `cadencia-fila` | GET |','| `cadencia-fila` | POST |','metodo_cadencia-fila'],
        ['contratos','`lead_sem_pessoa`','lead sem pessoa','codigos_de_acao'],
        ['fluxos','[exemplos de paginação](USAGE.md)','[exemplos de paginação](javascript:alert)','link_fluxos'],
        ['operacao','não deve ser enviada outra vez','deve usar wp option delete','recuperacao_sem_comando_destrutivo'],
        ['uso','"toque":"primeiro","chave_idempotencia"','"toque":"segundo","chave_idempotencia"','envio_corresponde_fila'],
        ['uso','"fim_da_fila":false,"proximo_cursor":"CURSOR_DEVOLVIDO"','"fim_da_fila":true,"proximo_cursor":null','vazia_tem_continuacao'],
        ['especificacao','| Recibo comum | 180 dias |','| Recibo comum | 90 dias |','prazo_recibo'],
    ];
    foreach ($mutations as [$id,$from,$to,$tag]) {
        $copy=$docs;$copy[$id]=str_replace($from,$to,$copy[$id],$n);
        $check("defeito_detectado_$tag", $n>0 && in_array($tag,$audit($copy),true));
    }
    wp_set_current_user(0);$check('leitor_sem_administrador_negado',Api::dispatch('documentacao-ler',[])['code']==='nao_autorizado');
} finally {
    wp_set_current_user(1);remove_filter('pre_http_request',$guard,1);
}
$check('manual_sem_http',$calls===0);
return ['checks'=>$checks,'passed'=>count(array_filter($checks)), 'failed'=>count(array_filter($checks,static fn($v)=>!$v)),'pages'=>$pages,'divergencias'=>$failures??[]];
