<?php
/** QA only: refuse every outgoing HTTP request. Tests may supply a synthetic response earlier. */
defined('ABSPATH') || exit;
add_filter('pre_http_request', static function($pre, $args, $url) {
    if ($pre !== false) return $pre;
    return new WP_Error('f3_qa_external_network_blocked','Bancada sem acesso a rede externa.');
}, PHP_INT_MAX, 3);
add_filter('pre_wp_mail', '__return_true', PHP_INT_MAX);
