<?php
$root=$argv[1]??'';
if(!is_file(dirname($root).'/marker')||trim(file_get_contents(dirname($root).'/marker'))!=='f3-pipedrive-disposable-0900-d848899a8f83')exit(2);
define('ABSPATH',rtrim($root,'/').'/');require ABSPATH.'wp-load.php';
if($wpdb->prefix!=='f3pipqa_0900c_'||home_url('/')!=='http://127.0.0.1:18491/')exit(3);
$name='f3pip_ret_'.substr(hash('sha256',DB_NAME.'|'.$wpdb->options),0,48);
if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 1)',$name))!=='1')exit(4);
fwrite(STDOUT,"LOCKED\n");fflush(STDOUT);fgets(STDIN);
$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$name));
