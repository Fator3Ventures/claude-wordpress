<?php
/** Follow escrituras090 in a fresh interpreter: prove an uncertain receipt still gates further dispatch. */
use Fator3\Pipedrive\{Api,Configuration,CoreClient,Store,Support};
global $wpdb;
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_'))throw new RuntimeException('Disposable only');
wp_set_current_user(1);require_once __DIR__.'/fixture050.php';$f=new ReleaseFixture();$ref=new ReflectionProperty(CoreClient::class,'client');$old=$ref->getValue();$ref->setValue(null,$f);
$name='f3_qa_090_uncertain_restart';$s=get_option($name);if(!is_array($s))throw new RuntimeException('Execute escritas090.php before this suite.');
try{
 $row=Store::get($s['id']);$r=Api::dispatch('operacao-aplicar',['previa_id'=>$s['id']]);$f->data[$s['path']]=['id'=>basename($s['path']),'status'=>'open','is_archived'=>false];
 $p=Api::dispatch('api-previa',['metodo'=>'DELETE','caminho'=>$s['path']]);$rid=$p['data']['previa_id']??'';$wr=$rid?Api::dispatch('api-aplicar',['previa_id'=>$rid]):$p;
 $c=['replayed_same_receipt'=>$r['code']==='resultado_parcial_ou_incerto'&&Support::digest($r)===$s['hash'],'saved_state_done'=>$row['state']==='done','marker_survives_process'=>get_option($s['marker'])===$s['id'],'new_attempt_denied'=>$wr['code']==='reconciliacao_necessaria','no_new_write'=>$f->writes===0];
}finally{
 foreach(array_filter([$s['id'],$rid??null]) as $i){$wpdb->delete(Store::table('ops'),['previa_id'=>$i]);$wpdb->delete(Store::table('journal'),['previa_id'=>$i]);}
 delete_option($s['marker']);delete_option($name);$ref->setValue(null,$old);
}
return ['checks'=>$c,'passed'=>count(array_filter($c)),'failed'=>count($c)-count(array_filter($c)),'supplier_http'=>0];
