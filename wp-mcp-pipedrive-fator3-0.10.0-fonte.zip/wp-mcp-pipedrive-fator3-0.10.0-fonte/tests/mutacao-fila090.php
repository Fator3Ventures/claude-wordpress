<?php
/** Negative control for the full-coverage test. Never changes the installed plugin. */
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))throw new RuntimeException('Disposable only');
if(class_exists('Fator3\\Pipedrive\\Cadence',false))throw new RuntimeException('Use a fresh CLI process.');
$original=file_get_contents(\Fator3\Pipedrive\ROOT.'/includes/Cadence.php');
$code=str_replace("\$end=\$p['next']===null&&\$evaluated===count(\$leads);","\$end=\$evaluated===count(\$leads);",$original,$matches);
if($matches!==1)throw new RuntimeException('Mutation target missing or ambiguous');
$temp=tempnam(sys_get_temp_dir(),'f3qa-fila090-');
try{
 if($temp===false||file_put_contents($temp,$code)!==strlen($code))throw new RuntimeException('Isolated mutation copy unavailable');
 require $temp;
 define('F3_PIPEDRIVE_TEST_QUEUE_MUTANT',true);
 $negative=require __DIR__.'/fila090.php';
 $failures=array_column(array_filter($negative['checks'],fn($c)=>!$c['passed']),'name');
 $caught=in_array('all_201_exact_order_distinct',$failures,true)&&in_array('all_1000_exact_order_distinct',$failures,true);
 return ['mutacao'=>'ignorar_continuacao_da_fonte_ao_fechar_pagina','detectada'=>$caught,'testes_que_reprovaram'=>$failures,'passed'=>(int)$caught,'failed'=>(int)!$caught];
}finally{if(is_string($temp)&&is_file($temp))unlink($temp);}
