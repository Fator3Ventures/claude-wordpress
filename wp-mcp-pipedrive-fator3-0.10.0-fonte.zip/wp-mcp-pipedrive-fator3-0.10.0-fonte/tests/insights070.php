<?php
/** Public read operations in disposable WordPress, using synthetic provider pages only. */
use Fator3\Pipedrive\{Api,Configuration,CoreClient,Support};

if (!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900')) throw new RuntimeException('Disposable only');
require_once __DIR__.'/fixture050.php';

$checks=[];
$check=static function(string $name,bool $passed) use (&$checks): void { $checks[]=compact('name','passed'); };
$previousUser=get_current_user_id(); wp_set_current_user(1);
$previousConfig=get_option(Configuration::OPTION,null);
$provider=new class {
    public array $rows=[], $requests=[];
    public int $pageSize=100, $writes=0;
    public ?string $breakSource=null;
    private ReleaseFixture $base;
    public function __construct() { $this->base=new ReleaseFixture(); }
    public function status() { return $this->base->status(); }
    public function request($method,$path,$query,$body,$context): array {
        $this->requests[]=[$method,$path];
        if ($method!=='GET') { ++$this->writes; throw new LogicException('Read sent a write'); }
        $this->base->spent+=20;
        $offset=(int)($query['start']??$query['cursor']??0);
        $rows=$this->rows[$path]??[];
        $n=min((int)$query['limit'],$this->pageSize);
        $more=$offset+$n<count($rows);
        $page=str_starts_with($path,'/api/v2/')?['next_cursor'=>$more?(string)($offset+$n):null]:
            ['pagination'=>['more_items_in_collection'=>$more,'next_start'=>$more?$offset+$n:null]];
        if ($path===$this->breakSource) $page=[];
        return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>array_slice($rows,$offset,$n),'additional_data'=>$page],'saldo_conta'=>null]];
    }
};
$http=0;
$block=static function() use (&$http) { ++$http; return new WP_Error('qa_network_blocked','Synthetic tests only'); };
add_filter('pre_http_request',$block,PHP_INT_MIN);
$client=new ReflectionProperty(CoreClient::class,'client'); $original=$client->getValue(); $client->setValue(null,$provider);
$call=static function(string $op,array $input) {
    $r=Api::dispatch($op,$input);
    if (!$r['success']) throw new RuntimeException($op.' failed: '.$r['code']);
    return $r['data'];
};
$audit=static fn()=>$call('auditoria',['agora'=>'2026-11-05T16:00:00Z']);
$count=static fn($entity='leads')=>$call('contar-por-campo',['entidade'=>$entity,'campo'=>'origem']);
$uuid=static fn(int $n)=>sprintf('7a000000-0000-4000-8000-%012d',$n);
$lead=static fn(int $n)=>['id'=>$uuid($n),'title'=>'QA / Unidade','origem'=>1,'origem2'=>2,'origem3'=>3,'origem4'=>4];
$deal=static fn(int $id)=>['id'=>$id,'status'=>'open','stage_id'=>30,'stage_change_time'=>'2026-11-05T16:00:00Z'];
$find=static function(array $rows,string $entity,int|string $id,string $rule) {
    foreach ($rows as $item) if ($item['entidade']===$entity&&$item['id']===$id&&$item['regra']===$rule) return $item;
    return null;
};
try {
    $config=Configuration::defaults();
    $config['auditoria']=['campos_origem'=>['origem','origem2','origem3','origem4'],'separador_titulo'=>' / ','etapas'=>[['id'=>30,'alerta_minutos'=>60,'primeira'=>true]],'tipos_reuniao'=>['meeting'],'nome_pessoa'=>['habilitada'=>true,'palavras_empresa'=>['ltda'],'ignorar_palavras'=>[],'minimo_tokens'=>2]];
    update_option(Configuration::OPTION,Support::json($config),false);

    // A malformed end marker leaves one genuine positive and no evidence about other leads.
    $provider->rows=['/v1/leads'=>[$lead(1),$lead(2)],'/api/v2/deals'=>[$deal(1),$deal(2)],'/api/v2/activities'=>[
        ['id'=>1,'lead_id'=>strtoupper($uuid(1)),'deal_id'=>1,'type'=>'meeting','done'=>0,'due_date'=>'2026-11-04']
    ]];
    $provider->breakSource='/api/v2/activities';
    $d=$audit();
    $check('partial_activities_no_false_absence',!$find($d['itens'],'lead',$uuid(2),'sem_proxima_atividade')&&($find($d['itens_nao_avaliados'],'lead',$uuid(2),'sem_proxima_atividade')['motivo']??'')==='colecao_atividades_incompleta');
    $check('partial_activities_positive_preserved',!$find($d['itens_nao_avaliados'],'lead',$uuid(1),'sem_proxima_atividade')&&$find($d['itens'],'negocio',1,'reuniao_vencida_primeira_etapa')!==null);
    $check('partial_activities_meeting_unknown',($find($d['itens_nao_avaliados'],'negocio',2,'reuniao_vencida_primeira_etapa')['motivo']??'')==='colecao_atividades_incompleta');
    $check('partial_activities_flags_cost',!$d['avaliacao_completa']&&!$d['coleta_completa']&&in_array('paginacao_incompleta',$d['motivos'],true)&&$d['custo']['chamadas']===5);

    $provider->breakSource='/api/v2/persons';
    $d=$audit();
    $check('unrelated_partial_source_keeps_provable_absence',$find($d['itens'],'lead',$uuid(2),'sem_proxima_atividade')!==null&&!$d['coleta_completa']&&!$d['avaliacao_completa']);
    $provider->breakSource=null;
    $provider->rows['/v1/leads'][]=$lead(3);
    $provider->rows['/api/v2/activities']=[
        ['id'=>1,'lead_id'=>$uuid(1),'done'=>false,'due_date'=>'2026-02-30'],
        ['id'=>2,'lead_id'=>$uuid(2),'done'=>'false','due_date'=>'2026-11-06'],
        ['id'=>3,'lead_id'=>$uuid(2),'done'=>0,'due_date'=>'2026-11-06'],
        ['id'=>4,'lead_id'=>$uuid(3),'done'=>true,'due_date'=>'2026-11-06'],
        ['id'=>5,'type'=>'meeting','deal_id'=>1,'due_date'=>'2026-11-04','due_time'=>['private marker']],
        ['id'=>6,'type'=>'meeting','deal_id'=>2,'due_date'=>'2026-11-04','done'=>true],
    ];
    $d=$audit();
    $check('malformed_date_is_unknown_not_absent',($find($d['itens_nao_avaliados'],'lead',$uuid(1),'sem_proxima_atividade')['motivo']??'')==='dados_atividade_invalidos'&&!$find($d['itens'],'lead',$uuid(1),'sem_proxima_atividade'));
    $check('positive_wins_over_malformed_candidate',!$find($d['itens_nao_avaliados'],'lead',$uuid(2),'sem_proxima_atividade')&&!$find($d['itens'],'lead',$uuid(2),'sem_proxima_atividade'));
    $check('closed_activity_does_not_count',$find($d['itens'],'lead',$uuid(3),'sem_proxima_atividade')!==null);
    $check('meeting_clock_shape_is_unknown',($find($d['itens_nao_avaliados'],'negocio',1,'reuniao_vencida_primeira_etapa')['motivo']??'')==='dados_reuniao_invalidos');
    $check('past_completed_meeting_still_flags_first_stage',$find($d['itens'],'negocio',2,'reuniao_vencida_primeira_etapa')!==null);
    $check('invalid_fields_do_not_invent_pagination_failure',$d['coleta_completa']&&!$d['avaliacao_completa']&&$d['motivos']===[]&&!str_contains(wp_json_encode($d),'private marker'));

    // 1,001 identical contact links must not evict the unrelated stage finding.
    $provider->rows=['/api/v2/persons'=>[['id'=>9,'name'=>'Sintético QA','org_id'=>8]],'/api/v2/organizations'=>[['id'=>8,'name'=>'Sintético QA']],
        '/api/v2/deals'=>[array_replace($deal(90),['stage_change_time'=>null,'add_time'=>'2026-11-01T10:00:00Z'])]];
    for ($n=1;$n<=1001;++$n) {
        $provider->rows['/v1/leads'][]=$lead($n)+['organization_id'=>['value'=>8],'person_id'=>['id'=>9]];
        $provider->rows['/api/v2/activities'][]=['id'=>$n,'lead_id'=>$uuid($n),'done'=>false,'due_date'=>'2026-12-01'];
    }
    $d=$audit();
    $check('duplicate_org_findings_do_not_exhaust_capacity',$d['coleta_completa']&&$d['avaliacao_completa']&&count($d['itens'])===3&&$find($d['itens'],'organizacao',8,'nome_igual_pessoa')!==null&&$find($d['itens'],'organizacao',8,'nome_pessoa_vinculada')!==null);
    $check('stage_date_survives_duplicate_contact_links',$d['datas_etapas']===[['negocio_id'=>90,'fonte'=>'add_time','entrada_em_utc'=>'2026-11-01T10:00:00Z']]&&$find($d['itens'],'negocio',90,'etapa_sem_avanco')!==null);
    $check('audit_regression_large_fixture_read_pages_only',$d['custo']['chamadas']===25&&!str_contains(wp_json_encode($d),'Sintético'));

    $provider->rows=['/api/v2/deals'=>[]];
    for ($n=1;$n<=2002;++$n) $provider->rows['/api/v2/deals'][]=array_replace($deal($n),['stage_change_time'=>$n<=1001?'2026-11-01T10:00:00Z':'invalid','add_time'=>'2026-10-01T00:00:00Z']);
    $d=$audit();
    $check('bounded_findings_and_exact_date_evidence',count($d['itens'])===1000&&array_column($d['itens'],'id')===array_column($d['datas_etapas'],'negocio_id'));
    $check('bounded_unassessed_no_invalid_stage_fallback',count($d['itens_nao_avaliados'])===1000&&$d['itens_nao_avaliados'][0]['id']===1002&&$d['itens_nao_avaliados'][0]['motivo']==='data_etapa_indisponivel');
    $check('truncation_declared_once_and_both_flags_false',$d['motivos']===['limite_de_saida']&&!$d['coleta_completa']&&!$d['avaliacao_completa']);

    // Empty catalog rows may be keyed by the field key; entity rows always require their real ID.
    $provider->rows=['/v1/dealFields'=>[['key'=>'origem','field_type'=>'set']],'/v1/leads'=>[
        ['id'=>$uuid(1),'origem'=>['id'=>7,'label'=>'PRIVATE_LABEL']],
        ['id'=>$uuid(2),'origem'=>[['id'=>7],['value'=>8],7]],
        ['id'=>$uuid(3),'origem'=>'8, 9'], ['id'=>$uuid(4),'origem'=>['label'=>'7']],
        ['id'=>$uuid(5),'origem'=>[true,8]], ['id'=>$uuid(6),'origem'=>[8,'18446744073709551616']],
    ],'/v1/leads/archived'=>[['id'=>strtoupper($uuid(1)),'origem'=>8]]];
    $d=$count();
    $check('options_accept_wrappers_csv_and_dedupe_per_record',array_column($d['grupos'],'quantidade','valor')===['opcao:7'=>2,'opcao:8'=>2,'opcao:9'=>1]);
    $check('unreadable_options_no_partial_group_or_label',$d['total_observado']===6&&in_array('opcao_ilegivel',$d['motivos'],true)&&!str_contains(wp_json_encode($d),'PRIVATE_LABEL'));
    $check('duplicate_uuid_across_active_archive_casefolded',!$d['coleta_completa']&&in_array('colecao_concorrente',$d['motivos'],true));
    $provider->rows=['/v1/dealFields'=>[['key'=>'origem','field_type'=>'set']],'/api/v2/deals'=>[['key'=>100,'origem'=>3]]];
    $d=$count('negocios');
    $check('entity_key_never_substitutes_record_id',$d['total_observado']===0&&$d['grupos']===[]&&!$d['coleta_completa']&&in_array('resposta_incompleta',$d['motivos'],true));
    $provider->rows['/api/v2/deals']=[['id'=>'18446744073709551616','origem'=>3]];
    $d=$count('negocios');
    $check('oversized_entity_id_never_aliases_another_record',$d['total_observado']===0&&!$d['coleta_completa']&&in_array('identidade_ilegivel',$d['motivos'],true));
    // Late, smaller keys can displace early ones; surviving groups retain their exact counts.
    $provider->rows=['/v1/dealFields'=>[['id'=>1,'key'=>'origem','field_type'=>'set']],'/v1/leads'=>[]];
    $expected=[];
    foreach (range(251,1) as $n) {
        $provider->rows['/v1/leads'][]=['id'=>$uuid($n),'origem'=>[$n,251]];
        $expected['opcao:'.$n]=$n===251?251:1;
    }
    ksort($expected);
    $d=$count();
    $check('groups_cap_keeps_sorted_first_200_exact',array_column($d['grupos'],'quantidade','valor')===array_slice($expected,0,200,true));
    $check('groups_truncation_reports_partial_total',$d['motivos']===['limite_de_grupos']&&!$d['coleta_completa']&&$d['total_observado']===251);
    $check('read_operations_zero_writes_zero_network',$provider->writes===0&&$http===0);
} finally {
    $client->setValue(null,$original);
    remove_filter('pre_http_request',$block,PHP_INT_MIN);
    if ($previousConfig===null) delete_option(Configuration::OPTION);
    else update_option(Configuration::OPTION,$previousConfig,false);
    wp_set_current_user($previousUser);
}
$passed=count(array_filter($checks,static fn($c)=>$c['passed']));
return ['checks'=>$checks,'passed'=>$passed,'failed'=>count($checks)-$passed,'supplier_http'=>$http];
