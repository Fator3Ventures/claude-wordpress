<?php
use Fator3\Pipedrive\{Api,Retention,Store,Support,CoreClient,Admin};
if (!defined('F3_PIPEDRIVE_DISPOSABLE') || !str_starts_with($wpdb->prefix,'f3pipqa_')) { throw new RuntimeException('Isolated prefix required'); }
wp_set_current_user(1);$checks=[];$check=static function($n,$v)use(&$checks){$checks[]=['name'=>$n,'passed'=>(bool)$v];};
$call=static fn($op,$i=[])=>Api::dispatch($op,$i);
$wpdb->delete($wpdb->options,['option_name'=>Retention::OPTION]);
delete_option(Store::CLEANUP_OPTION); // Force this synthetic maintenance opportunity.
$before=$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->options}");
$p=$call('retencao-ler')['data'];$s=$call('status');
$check('default_unlimited',$p['diario_dias']===0 && $p['diario_sem_prazo'] && $p['recibos_dias']===180);
$check('read_no_config_write',$before===$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->options}") && $p['origem']==='padrao');
$check('status_even_without_core',($s['data']['retencao']['diario_dias']??-1)===0);
$fixture=new class {
 public int $calls=0;public int $writes=0;public array $record=['id'=>912,'content'=>'QA retention'];
 public function capabilities(){return ['contract'=>'pipedrive-api-client/1.0.0'];}
 public function status(){return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>true,'conta'=>['dominio'=>'fixture.pipedrive.com','conta_id'=>1,'usuario_id'=>2],'revisao'=>'retention-fixture','orcamento'=>['teto'=>3000,'consumido'=>0,'reservado'=>0],'saldo_conta'=>null]];}
 public function request($m,$p,$q,$b,$c){++$this->calls;if($m!=='GET'){++$this->writes;$this->record=array_replace($this->record,$b);}return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>$this->record],'saldo_conta'=>null]];}
};
$registry=new class($fixture){public function __construct(public $client){}public function register_consumer(...$a){return $this->client;}};
CoreClient::register($registry,'pipedrive-api-client/1.0.0');
$ops=Store::table('ops');$journal=Store::table('journal');$ids=[];
$seed=static function($state,$age,$retain)use($wpdb,$ops,$journal,&$ids){$id=bin2hex(random_bytes(16));$ids[]=$id;$wpdb->insert($ops,['previa_id'=>$id,'actor_id'=>1,'binding'=>CoreClient::binding(CoreClient::status()),'state'=>$state,'created'=>time()-$age*DAY_IN_SECONDS,'expires'=>time()-1,'retain_until'=>time()+$retain,'payload'=>'','result'=>$state==='done'?Support::seal(['fixture'=>true]):'']);$meta=['previa_id'=>$id,'metodo'=>'PUT','caminho'=>'/v1/notes/912','classe'=>'registro','status'=>$state==='running'?'em_execucao':'ok','chaves_alteradas'=>['content'],'saldo_depois'=>null];$wpdb->insert($journal,['previa_id'=>$id,'created'=>time()-$age*DAY_IN_SECONDS,'metadata'=>Support::json($meta)]);return $id;};
$old=$seed('done',400,-1);$pending=$seed('running',400,-1);$recent=$seed('done',2,10000);
$line=static fn($id)=>$wpdb->get_row($wpdb->prepare("SELECT * FROM $journal WHERE previa_id=%s",$id),ARRAY_A);
$oldBefore=$line($old);$pendingBefore=$line($pending);
$preview=$call('api-previa',['metodo'=>'PUT','caminho'=>'/v1/notes/912','corpo'=>['content'=>'QA changed']]);
$check('old_line_after_preview',$preview['success'] && $line($old)===$oldBefore);
$check('receipt_purged_independently',!$wpdb->get_var($wpdb->prepare("SELECT previa_id FROM $ops WHERE previa_id=%s",$old)));
$apply=$call('api-aplicar',['previa_id'=>$preview['data']['previa_id']]);
$check('old_line_after_apply',$apply['success'] && $line($old)===$oldBefore);
$check('uncertain_preserved_unlimited',$line($pending)===$pendingBefore);
$check('journal_advertises_unlimited',$call('registro-ler')['data']['sem_prazo']===true);
$rev=$p['revisao'];$count=$fixture->calls;
$missing=$call('retencao-configurar',['diario_dias'=>30,'revisao_esperada'=>$rev]);
$check('finite_requires_confirmation',!$missing['success'] && $missing['code']==='confirmacao_ausente');
foreach([-1,36501,1.5,'180',null] as $n=>$invalid){$r=$call('retencao-configurar',['diario_dias'=>$invalid,'revisao_esperada'=>$rev,'confirmar_expurgo'=>true]);$check('invalid_days_'.$n,!$r['success']);}
$r=$call('retencao-configurar',['diario_dias'=>30,'revisao_esperada'=>$rev,'confirmar_expurgo'=>true]);$finite=$r['data'];
$check('finite_persisted_and_reread',$r['success'] && $r['persisted'] && $finite===$call('retencao-ler')['data']);
$check('config_no_purge_no_provider',$line($old)===$oldBefore && $fixture->calls===$count);
$check('stale_revision_refused',$call('retencao-configurar',['diario_dias'=>0,'revisao_esperada'=>$rev])['code']==='revisao_conflitante');
Store::cleanup();
$check('finite_expired_line_removed',$line($old)===null);
$check('finite_keeps_running_and_recent',$line($pending)===$pendingBefore && $line($recent)!==null);
$r=$call('retencao-configurar',['diario_dias'=>0,'revisao_esperada'=>$finite['revisao']]);
$check('unlimited_explicit',$r['success'] && $r['data']['origem']==='configurado');
$check('aba_revision_changed',$r['data']['revisao']!==$rev);
$old2=$seed('done',1000,-1);$old2Before=$line($old2);Store::cleanup();$check('unlimited_again_preserves',$line($old2)===$old2Before);
$nochange=$call('retencao-configurar',['diario_dias'=>0,'revisao_esperada'=>$r['data']['revisao']]);
$check('nochange_verified',$nochange['success'] && !$nochange['changed'] && $nochange['persisted'] && $nochange['data']['revisao']===$r['data']['revisao']);
$raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",Retention::OPTION));
$wpdb->update($wpdb->options,['option_value'=>'corrupt'],['option_name'=>Retention::OPTION]);
$bad=$call('api-previa',['metodo'=>'PUT','caminho'=>'/v1/notes/912','corpo'=>['content'=>'QA refused']]);
$check('corrupt_policy_no_delete',$bad['code']==='retencao_invalida' && $line($old2)===$old2Before);
$wpdb->update($wpdb->options,['option_value'=>$raw],['option_name'=>Retention::OPTION]);
$check('reactivation_keeps_policy',(function()use($raw,$wpdb){Store::install();return $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",Retention::OPTION))===$raw;})());
// Administrative form: nonce, optimistic revision, finite choice, invalid nonce.
$_SERVER['REQUEST_METHOD']='POST';$_POST=['f3_pipedrive_action'=>'retention','diario_dias'=>'730','revisao_esperada'=>$call('retencao-ler')['data']['revisao'],'confirmar_expurgo'=>'1','_wpnonce'=>wp_create_nonce('f3_pipedrive_retention')];$_REQUEST=$_POST;
$_POST['f3pd_tentativa']=\Fator3\Pipedrive\AdminForms::token();$_REQUEST=$_POST;
$url=\Fator3\Pipedrive\AdminForms::submit();parse_str(parse_url($url,PHP_URL_QUERY),$_GET);$_SERVER['REQUEST_METHOD']='GET';
ob_start();Admin::page();$html=ob_get_clean();$check('panel_posts_same_policy',$call('retencao-ler')['data']['diario_dias']===730 && str_contains($html,'Política persistida'));
$die=static fn()=>static function(){throw new RuntimeException('nonce_refused');};add_filter('wp_die_handler',$die);
$_POST['_wpnonce']='invalid';$_REQUEST=$_POST;$caught=false;ob_start();try{\Fator3\Pipedrive\AdminForms::submit();}catch(RuntimeException $e){$caught=$e->getMessage()==='nonce_refused';}ob_end_clean();remove_filter('wp_die_handler',$die);
$check('panel_invalid_nonce_refused',$caught && $call('retencao-ler')['data']['diario_dias']===730);
$_SERVER['REQUEST_METHOD']='GET';$_POST=$_REQUEST=[];
$policy=$call('retencao-ler')['data'];$call('retencao-configurar',['diario_dias'=>0,'revisao_esperada'=>$policy['revisao']]);
// A different MySQL connection holds the lock while cleanup/configuration try to enter.
$cmd=escapeshellarg(PHP_BINARY).' '.escapeshellarg(__DIR__.'/retention-lock-worker.php').' '.escapeshellarg(rtrim(ABSPATH,'/'));
$pipes=[];$proc=proc_open($cmd,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
$ready=is_resource($proc)?trim(fgets($pipes[1])):'';
$r=$call('retencao-configurar',['diario_dias'=>0,'revisao_esperada'=>$call('retencao-ler')['data']['revisao']]);
$check('concurrent_config_blocked',$ready==='LOCKED' && $r['code']==='retencao_ocupada');
$blocked=false;try{Store::cleanup();}catch(Fator3\Pipedrive\Fault $e){$blocked=$e->reason==='retencao_ocupada';}
$check('concurrent_cleanup_blocked',$blocked && $line($old2)===$old2Before);
if(is_resource($proc)){fwrite($pipes[0],"release\n");fclose($pipes[0]);stream_get_contents($pipes[1]);fclose($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[2]);$check('lock_worker_closed',proc_close($proc)===0 && $err==='');}
$subscriber=wp_create_user('retention_subscriber',wp_generate_password(30),'retention@example.test');wp_set_current_user($subscriber);
$check('unauthorized_read',$call('retencao-ler')['code']==='nao_autorizado');
$check('unauthorized_write',$call('retencao-configurar',['diario_dias'=>0,'revisao_esperada'=>$rev])['code']==='nao_autorizado');
wp_set_current_user(1);
$_GET['aba']='diario';ob_start();Admin::page();$html=ob_get_clean();file_put_contents(dirname(ABSPATH).'/panel020.html',$html);
$check('panel_labels_and_nonce',str_contains($html,'sem prazo')&&str_contains($html,'revisao_esperada')&&str_contains($html,'_wpnonce'));
return ['checks'=>$checks,'passed'=>count(array_filter($checks,fn($c)=>$c['passed'])),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'fixture_requests'=>$fixture->calls,'fixture_writes'=>$fixture->writes,'supplier_http'=>0,'runtime'=>['wp'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'mysql'=>$wpdb->db_version()]];
