<?php
/** Two separate PHP workers compete for one durable preview, no supplier calls. */
$root=$argv[1]??'';$id=$argv[2]??'';
if (!is_file(dirname($root).'/marker') || trim(file_get_contents(dirname($root).'/marker'))!=='f3-pipedrive-disposable-0900-d848899a8f83'
    || !preg_match('/^[a-f0-9]{32}$/D',$id)) { exit(2); }
define('ABSPATH',$root.'/');require ABSPATH.'wp-load.php';if($wpdb->prefix!=='f3pipqa_0900c_'||home_url('/')!=='http://127.0.0.1:18491/')exit(3);if(!defined('Fator3\\Pipedrive\\VERSION')){
    $prototype=dirname($root).'/prototype/wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php';if(!is_file($prototype))exit(3);require $prototype;
}
wp_set_current_user(1);
usleep(200000);
$result=\Fator3\Pipedrive\Store::claim($id,['previa_id'=>$id,'metodo'=>'PATCH','caminho'=>'/v1/leads/00000000-0000-4000-8000-000000000001','classe'=>'registro','status'=>'em_execucao','chaves_alteradas'=>[],'saldo_depois'=>null]);
echo $result?'claimed':'not_claimed';
