<?php
declare(strict_types=1);
/** php tests/mutacoes-travas090.php /path/to/disposable/wordpress; native WordPress runtime in private clones. */
if(PHP_SAPI!=='cli'||$argc!==2)exit(2);
$site=realpath($argv[1]);$marker=dirname((string)$site).'/marker';
if(!$site||is_link($marker)||!is_file($marker)||!preg_match('/^f3-pipedrive-disposable-0900-[a-z0-9-]+$/D',trim((string)file_get_contents($marker))))exit(3);
$slug='wp-mcp-pipedrive-fator3';$source=__DIR__.'/../plugin/'.$slug;
$tmp=sys_get_temp_dir().'/f3p-mutex-'.bin2hex(random_bytes(8));mkdir($tmp,0700);
$scan=getenv('PHP_INI_SCAN_DIR');$originalScan=$scan===false?'':$scan;
$report=[];
try{
    $dst=$tmp.'/plugins/'.$slug;mkdir($dst,0700,true);
    foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST) as $f){
        $rest=substr($f->getPathname(),strlen($source));$target=$dst.$rest;
        if($f->isDir())mkdir($target,0700);else copy($f->getPathname(),$target);
    }
    $mutants=[
      'retencao_global_durante_http'=>['Workflows.php','return self::execute($id,$p,$snapshot,$s,$scope,$c);','return Retention::locked(static fn()=>self::execute($id,$p,$snapshot,$s,$scope,$c));','second_entity_finishes_while_first_waits'],
      'expurgo_sem_mutex'=>['Store.php','},true);','}) ();','busy_optional_cleanup_defers_without_expiring'],
    ];
    mkdir($tmp.'/ini');
    file_put_contents($tmp.'/prepend.php',"<?php define('WP_PLUGIN_DIR',".var_export($tmp.'/plugins',true).");");
    file_put_contents($tmp.'/ini/99-mutator.ini',"auto_prepend_file=\"".$tmp."/prepend.php\"\n");
    // Propagate the same runtime to the concurrency worker created by the suite.
    putenv('PHP_INI_SCAN_DIR='.($originalScan===''?'':$originalScan.PATH_SEPARATOR).$tmp.'/ini');
    $boot="<?php define('F3_PIPEDRIVE_DISPOSABLE',true);require ".var_export($site.'/wp-load.php',true).";".
        "if(!defined('Fator3\\Pipedrive\\ROOT')||realpath(Fator3\\Pipedrive\\ROOT)!==realpath(".var_export($dst,true)."))exit(6);".
        '$result=require '.var_export(__DIR__.'/travas090.php',true).';echo "MUTATION_RESULT=".json_encode($result)."\\n";';
    file_put_contents($tmp.'/run.php',$boot);
    foreach($mutants as $name=>[$filename,$from,$to,$expected]){
        $rel='/includes/'.$filename;$original=(string)file_get_contents($source.$rel);
        if(substr_count($original,$from)!==1)throw new RuntimeException("Mutação incompatível: ".$name);
        $patched=str_replace($from,$to,$original);
        if($name==='expurgo_sem_mutex'){
            $open='Retention::locked(static function (): void {';if(substr_count($patched,$open)!==2)throw new RuntimeException('Ponto da mutação do mutex alterado.');
            $pos=strpos($patched,$open);$patched=substr_replace($patched,'(static function (): void {',$pos,strlen($open));
        }
        file_put_contents($dst.$rel,$patched);
        $cmd=proc_open([PHP_BINARY,$tmp.'/run.php'],[0=>['file','/dev/null','r'],1=>['pipe','w'],2=>['file',$tmp.'/errors','a']],$pipes);
        if(!is_resource($cmd))throw new RuntimeException('Falha ao iniciar cópia experimental.');
        $out=stream_get_contents($pipes[1]);fclose($pipes[1]);$exit=proc_close($cmd);
        if($exit!==0||!preg_match('/^MUTATION_RESULT=(.+)$/m',(string)$out,$m))throw new RuntimeException("Teste da árvore mutada incompleto: $name, exit=$exit");
        $r=json_decode($m[1],true,512,JSON_THROW_ON_ERROR);$fails=array_column(array_filter($r['checks'],fn($c)=>!$c['passed']),'name');
        $report[]=['mutacao'=>$name,'detectado'=>in_array($expected,$fails,true),'falhas'=>$fails];
        file_put_contents($dst.$rel,$original);
    }
}finally{
    if($scan===false)putenv('PHP_INI_SCAN_DIR');else putenv('PHP_INI_SCAN_DIR='.$scan);
    foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST)as$f){if($f->isDir())rmdir($f->getPathname());else unlink($f->getPathname());}rmdir($tmp);
}
echo json_encode($report,JSON_UNESCAPED_SLASHES),"\n";
exit(count(array_filter($report,fn($c)=>$c['detectado']))===count($mutants)?0:1);
