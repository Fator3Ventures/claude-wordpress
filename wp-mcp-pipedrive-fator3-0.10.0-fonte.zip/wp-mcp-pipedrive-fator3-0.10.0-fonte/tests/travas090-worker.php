<?php
declare(strict_types=1);
if (PHP_SAPI!=='cli' || $argc!==4) exit(2);
$wpTestRoot=realpath($argv[1]);$marker=dirname((string)$wpTestRoot).'/marker';
if (!$wpTestRoot || !is_file($marker) || is_link($marker) || !preg_match('/^f3-pipedrive-disposable-0900-[a-z0-9-]+$/D',trim((string)file_get_contents($marker)))) exit(3);
define('F3_PIPEDRIVE_DISPOSABLE',true); require $wpTestRoot.'/wp-load.php';
if (!str_starts_with($wpdb->prefix,'f3pipqa_0900') || home_url('/')!=='http://127.0.0.1:18491/' || !defined('WP_HTTP_BLOCK_EXTERNAL') || !WP_HTTP_BLOCK_EXTERNAL) exit(4);
wp_set_current_user(1);require __DIR__.'/travas090-fixture.php';
$out=f3qa090_messaging($argv[2],$argv[3],true);echo 'QA_RESULT '.json_encode($out),"\n";
