<?php
/** R6: two WordPress processes; one stays stopped inside supplier PATCH/POST while the other progresses. */
use Fator3\Pipedrive\{Api,Configuration,CoreClient,Retention,Store,Support};
if (!defined('F3_PIPEDRIVE_DISPOSABLE') || !str_starts_with($wpdb->prefix,'f3pipqa_0900') || home_url('/')!=='http://127.0.0.1:18491/') throw new RuntimeException('Disposable only');
require_once __DIR__.'/travas090-fixture.php';wp_set_current_user(1);
$checks=[];$check=static function(string $n,bool $ok)use(&$checks){$checks[]=['name'=>$n,'passed'=>$ok];};
$ops=Store::table('ops');$log=Store::table('journal');$saved=[];
foreach ([Configuration::OPTION,Retention::OPTION,Store::CLEANUP_OPTION] as $opt)$saved[$opt]=get_option($opt,null);
$readyIds=[];$refs=[];$markers=[];$proc=null;$pipes=[];$stats=[];
$markerValue=static fn(string $k)=>$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$k));
$markerFor=static fn(string $lead)=>Store::CANONICAL_PENDING.hash('sha256',Support::digest((new ReleaseFixture())->status()['data']['conta']).':lead:'.$lead);
$mk=static function(string $state,int $expires,int $retained,string $body='qa-evidence')use($ops,$wpdb,&$refs):string{
    $r=bin2hex(random_bytes(16));$refs[]=$r;
    $i=$wpdb->insert($ops,['previa_id'=>$r,'actor_id'=>1,'binding'=>str_repeat('7',64),'state'=>$state,'created'=>time()-365*DAY_IN_SECONDS,'expires'=>$expires,'retain_until'=>$retained,'payload'=>$body,'result'=>'']);if($i!==1)throw new RuntimeException('seed ops');return $r;
};
$row=static fn(string $id)=>$wpdb->get_row($wpdb->prepare("SELECT * FROM $ops WHERE previa_id=%s",$id),ARRAY_A);
$journal=static fn(string $id)=>$wpdb->get_var($wpdb->prepare("SELECT metadata FROM $log WHERE previa_id=%s",$id));
$seedJ=static function(string $id)use($wpdb,$log){if($wpdb->insert($log,['previa_id'=>$id,'created'=>time()-200*DAY_IN_SECONDS,'metadata'=>'{"status":"qa"}'])!==1)throw new RuntimeException('seed log');};
$rand=str_pad((string)random_int(1,99999999),8,'0',STR_PAD_LEFT);$leadA="90000000-0000-4000-8000-0001".$rand;$leadB="90000000-0000-4000-8000-0002".$rand;
$account=(new ReleaseFixture())->status()['data']['conta'];$mkA=$markerFor($leadA);$mkB=$markerFor($leadB);
try {
    $cfg=Configuration::defaults();$cfg['habilitada']=true;$cfg['tipo_whatsapp']='wa_qa';$cfg['dias']=[1,2,3,4,5,6,7];$cfg['fuso']='UTC';$cfg['periodos']=[['codigo'=>'manha','hora'=>'09:30']];$cfg['textos']=[['codigo'=>'m','texto'=>'Teste']];$cfg['toques']=[['codigo'=>'t1','base'=>'entrada','atraso_minutos'=>0,'texto_id'=>'m','etiqueta_id'=>'']];
    update_option(Configuration::OPTION,Support::json($cfg),false);
    Retention::configure(['diario_dias'=>2,'revisao_esperada'=>Retention::read()['revisao'],'confirmar_expurgo'=>true]);
    delete_option(Store::CLEANUP_OPTION);
    // The only public trigger in this test is a composite operation.
    $expired=$mk('ready',time()-1,time()+3600);
    $oldDone=$mk('done',time()-1,time()-1,'');$seedJ($oldDone);
    $pinned=$mk('done',time()-1,time()-1,'');$seedJ($pinned);
    $pinnedKey=Store::CANONICAL_PENDING.hash('sha256','qa-'.$pinned);add_option($pinnedKey,$pinned,'',false);$markers[]=$pinnedKey;
    $proc=proc_open([PHP_BINARY,__DIR__.'/travas090-worker.php',ABSPATH,$leadA,'travas-090-a-'.$rand],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
    if(!is_resource($proc))throw new RuntimeException('Could not launch worker');
    stream_set_timeout($pipes[1],12);
    $line=trim((string)fgets($pipes[1]));
    if(!preg_match('/^QA_DISPATCH ([a-f0-9]{32})$/D',$line,$m))throw new RuntimeException('Worker did not reach transport: '.substr($line,0,200));
    $aid=$m[1];$refs[]=$aid;$markers[]=$mkA;$markers[]=$mkB;
    $check('composed_only_expires_ready_and_clears_payload',$row($expired)['state']==='expired'&&$row($expired)['payload']==='');
    $check('composed_only_removes_old_receipt_and_journal',$row($oldDone)===null&&$journal($oldDone)===null);
    $check('composed_only_preserves_pinned_receipt_and_journal',$row($pinned)!==null&&$journal($pinned)!==null);
    $check('worker_has_persistent_guard_and_running_receipt',$markerValue($mkA)===$aid&&$row($aid)['state']==='running');
    // Force expiry while A is in-flight: a finite journal and a due cleanup still must not discard evidence.
    $wpdb->update($ops,['expires'=>time()-10,'retain_until'=>time()-10],['previa_id'=>$aid]);
    $wpdb->update($log,['created'=>time()-200*DAY_IN_SECONDS],['previa_id'=>$aid]);
    $pre=$row($aid);$preJ=$journal($aid);$cleanupRan=true;
    try{Store::cleanup();}catch(Fator3\Pipedrive\Fault $e){if($e->reason!=='retencao_ocupada')throw $e;$cleanupRan=false;}
    $check('active_expired_claim_and_checkpoint_survive_purge',$cleanupRan&&$pre!==null&&$pre['payload']!==''&&$pre===$row($aid)&&$preJ!==null&&$preJ===$journal($aid));
    $late=$mk('ready',time()-1,time()+3600);
    $second=f3qa090_messaging($leadB,'travas-090-b-'.$rand,false);if(!empty($second['receipt']))$refs[]=$second['receipt'];
    $stats['second']=$second['code'];$check('second_entity_finishes_while_first_waits',$second['code']==='operacao_concluida'&&$second['writes']===1);
    $check('rate_limit_defers_second_purge',$row($late)['state']==='ready');
    $fp=new ReflectionProperty(CoreClient::class,'client');$oldClient=$fp->getValue();$fixture=new ReleaseFixture();
    try {$fp->setValue(null,$fixture);$preview=Api::dispatch('api-previa',['metodo'=>'POST','caminho'=>'/v1/leadLabels','corpo'=>['name'=>'Etiqueta local da bancada','color'=>'red']]);}
    finally {$fp->setValue(null,$oldClient);}
    if(!empty($preview['data']['previa_id']))$refs[]=$preview['data']['previa_id'];
    $check('raw_preview_can_run_during_another_entity_dispatch',($preview['code']??null)==='previa_criada'&&$fixture->writes===0);
    $same=f3qa090_messaging($leadA,'travas-090-same-'.$rand,false);
    $check('same_entity_parallel_refused_without_mutation',$same['code']==='operacao_ocupada'&&$same['writes']===0);
    fwrite($pipes[0],"QA_RELEASE\n");fclose($pipes[0]);unset($pipes[0]);
    $line=trim((string)fgets($pipes[1]));$first=str_starts_with($line,'QA_RESULT ')?json_decode(substr($line,10),true):[];
    $check('first_entity_finishes_once',$first['code']==='operacao_concluida'&&$first['writes']===1&&$row($aid)['state']==='done'&&$markerValue($mkA)===null);
    fclose($pipes[1]);$errors=stream_get_contents($pipes[2]);fclose($pipes[2]);$exit=proc_close($proc);$proc=null;$pipes=[];
    $check('worker_clean_exit',$exit===0&&$errors==='');
    $leadC="90000000-0000-4000-8000-0003".$rand;
    $beforeStale=(int)$wpdb->get_var("SELECT COUNT(*) FROM $ops");$cfg['feriados']=['2031-01-01'];
    $stale=f3qa090_messaging($leadC,'travas-090-stale-'.$rand,false,static function()use($cfg) {Configuration::save($cfg,Configuration::read()['revisao']);});
    $check('updated_rules_during_preflight_refuse_before_first_dispatch',$stale['code']==='revisao_conflitante'&&$stale['writes']===0&&$markerValue($markerFor($leadC))===null&&(int)$wpdb->get_var("SELECT COUNT(*) FROM $ops")===$beforeStale);
    $fixture=new ReleaseFixture();$fixture->data['/v1/leads/'.$leadC]=['id'=>$leadC,'title'=>'Fixture','is_archived'=>false];
    $proxy=new class($fixture){public int $remaining=-1;public function __construct(public ReleaseFixture $fixture){}public function status(){return $this->fixture->status();}
        public function request($method,$path,$query,$body,$context){
            if($method==='GET'&&$this->remaining>0&&--$this->remaining===0){$c=Configuration::read();$rule=$c['regras'];$rule['archive_reasons']=[];Configuration::save($rule,$c['revisao']);}
            return $this->fixture->request($method,$path,$query,$body,$context);
        }};
    $prop=new ReflectionProperty(CoreClient::class,'client');$prevClient=$prop->getValue();
    try {$prop->setValue(null,$proxy);
        $preview=Api::dispatch('api-previa',['caminho'=>'/v1/leads/'.$leadC,'metodo'=>'PATCH','corpo'=>['is_archived'=>true,'archive_reason'=>$cfg['archive_reasons'][0]]]);
        if(!$preview['success'])throw new RuntimeException('Prévia da prova de revisão indisponível: '.$preview['code']);
        $rawId=$preview['data']['previa_id'];$refs[]=$rawId;$proxy->remaining=2;
        $raw=Api::dispatch('api-aplicar',['previa_id'=>$rawId]);
        $check('archive_guard_revision_rechecked_after_supplier_reads',$raw['code']==='revisao_conflitante'&&$fixture->writes===0&&$row($rawId)['state']==='ready');
    }finally {$prop->setValue(null,$prevClient);}
    // Short retention mutex protects purge, but a busy maintenance opportunity does not block commercial operations.
    $pendingBatch=$mk('ready',time()-1,time()+3600);delete_option(Store::CLEANUP_OPTION);
    $proc=proc_open([PHP_BINARY,__DIR__.'/retention-lock-worker.php',rtrim(ABSPATH,'/')],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
    if(!is_resource($proc))throw new RuntimeException('Could not launch retention worker');
    stream_set_timeout($pipes[1],6);if(trim((string)fgets($pipes[1]))!=='LOCKED')throw new RuntimeException('Retention worker did not acquire mutex');
    Store::maybeCleanup();$check('busy_optional_cleanup_defers_without_expiring',$row($pendingBatch)['state']==='ready');
    $blocked=false;try{Store::cleanup();}catch(Fator3\Pipedrive\Fault $e){$blocked=$e->reason==='retencao_ocupada';}
    $check('explicit_cleanup_respects_other_connection_mutex',$blocked&&$row($pendingBatch)['state']==='ready');
    fwrite($pipes[0],"release\n");fclose($pipes[0]);fclose($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[2]);$rc=proc_close($proc);$proc=null;$pipes=[];
    Store::maybeCleanup();$check('deferred_cleanup_runs_after_mutex_release',$rc===0&&$err===''&&$row($pendingBatch)['state']==='expired');
    // All writes remain eligible for a later batch; each pass bounds modified row counts.
    for($i=0;$i<102;++$i)$readyIds[]=$mk('ready',time()-5,time()+3600);
    $countReady=static function()use(&$readyIds,$ops,$wpdb){$ph=implode(',',array_fill(0,count($readyIds),'%s'));return(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $ops WHERE state='ready' AND previa_id IN ($ph)",...$readyIds));};
    Store::cleanup();$left=$countReady();$check('single_batch_cannot_expire_more_than_100_of_102',$left>=2&&$left<102);
    Store::cleanup();$check('following_batch_drains_remainder',$countReady()===0);
    // Redacted proof is not exposed to a journal reader.
    $add=$mk('done',time()+30,time()+3600,'');$seedJ($add);$wpdb->update($log,['metadata'=>Support::json(['previa_id'=>$add,'status'=>'qa','prova_recuperacao'=>'private-fixture'])],['previa_id'=>$add]);$public=Store::journal(['limite'=>5]);
    $publicRow=array_values(array_filter($public['itens'],static fn($r)=>($r['previa_id']??'')===$add))[0]??[];
    $check('journal_omits_encrypted_recovery_proof',($publicRow['status']??null)==='qa'&&!array_key_exists('prova_recuperacao',$publicRow));
}finally{
    if(is_resource($proc)){if(isset($pipes[0])&&is_resource($pipes[0])){fwrite($pipes[0],"QA_RELEASE\n");fclose($pipes[0]);}foreach([1,2]as $k)if(isset($pipes[$k])&&is_resource($pipes[$k])){stream_get_contents($pipes[$k]);fclose($pipes[$k]);}proc_close($proc);}
    foreach([$leadA,$leadB] as $lead)$refs[]=substr(Fator3\Pipedrive\Progress::identity($account,$lead),0,32);
    foreach($refs as $id){$wpdb->delete($log,['previa_id'=>$id]);$wpdb->delete($ops,['previa_id'=>$id]);}
    foreach($markers as $k)delete_option($k);
    foreach($saved as $k=>$v){if($v===null)delete_option($k);else update_option($k,$v,false);}
}
$passed=count(array_filter($checks,fn($r)=>$r['passed']));
return ['checks'=>$checks,'passed'=>$passed,'failed'=>count($checks)-$passed,'observed'=>$stats,'transport'=>'two PHP processes, shared MySQL, synthetic supplier'];
