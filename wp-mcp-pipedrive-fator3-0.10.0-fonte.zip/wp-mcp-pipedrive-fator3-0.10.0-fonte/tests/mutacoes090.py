#!/usr/bin/env python3
"""Plant one fault in a private runtime copy, run the corresponding real WordPress suite, require the named failure."""
import argparse,json,subprocess,tempfile,shutil
from pathlib import Path
src=Path(__file__).resolve().parents[1]
slug='wp-mcp-pipedrive-fator3'
cases={
 'P0_2xx_indefinido_recusado':('CoreClient',"$code = $definitive ? 'fornecedor_recusou' : 'resultado_incerto';","$code = ($definitive || $http===200) ? 'fornecedor_recusou' : 'resultado_incerto';",'escritas090','invalid_2xx_decision'),
 'P2_consentimento_ignorado':('Recovery',"if(!hash_equals(self::phrase($id),$i['confirmacao']))","if(false)",'policy090','recovery_wrong_phrase_refused'),
 'P4_POST_duplicado':('AdminForms',"hash_equals($existing,$digest)?'replay':'conflict'","hash_equals($existing,$digest)?'new':'conflict'",'policy090','same_POST_one_preview_one_cost'),
 'P5_guia_longo_sem_paginar':('AdminDocument','if(strlen($source)<=24000)return [$source];','return [$source];','policy090','long_guide_readable_in_sections'),
 'm06_lista_aberta':('Policy',"'/v1/activityTypes','/v1/users/me'","'/v1/activityTypes','/v1/users/me','/v1/users','/v1/mailbox/mailMessages'",'policy090','deny_/v1/users'),
 'm11_gravacao_sem_revisao':('Configuration',"if(!hash_equals($old['revisao'],$revision))","if(false)",'policy090','stale_direct_save_cannot_overwrite'),
 'm15_aplicacao_sem_revisao':('Workflows',"if(!hash_equals($cfg['revisao'],$p['config_revision']))","if(false)",'policy090','stale_preview_rejected_before_claim')
}
def run(site,php):
    site=site.resolve();marker=site.parent/'marker'
    if not marker.is_file() or marker.is_symlink() or not marker.read_text().strip().startswith('f3-pipedrive-disposable-0900-'):raise ValueError('Disposable WordPress required')
    results=[]
    with tempfile.TemporaryDirectory(prefix='f3p-test-mut-') as tmp:
        tmp=Path(tmp);plugin=tmp/'plugins'/slug
        shutil.copytree(src/'plugin'/slug,plugin);boot=tmp/'run.php'
        boot.write_text("""<?php
define('F3_PIPEDRIVE_DISPOSABLE',true);define('WP_PLUGIN_DIR',$argv[1]);require $argv[2].'/wp-load.php';
if(!str_starts_with($wpdb->prefix,'f3pipqa_0900')||wp_parse_url(home_url(),PHP_URL_HOST)!=='127.0.0.1'||realpath(\\Fator3\\Pipedrive\\ROOT)!==realpath($argv[1].'/wp-mcp-pipedrive-fator3'))exit(3);
require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
wp_set_current_user(1);$r=require $argv[3];echo json_encode($r),"\\n";
""")
        for name,(cls,a,b,suite,expect) in cases.items():
            f=plugin/'includes'/(cls+'.php');original=f.read_text()
            if original.count(a)!=1:raise ValueError('Mutation not unique: '+name)
            try:
                f.write_text(original.replace(a,b))
                cmd=[str(php),str(boot),str(plugin.parent),str(site),str(src/'tests'/(suite+'.php'))]
                r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
                if r.returncode:raise ValueError(name+': runtime error '+r.stderr[-450:]+r.stdout[-300:])
                result=json.loads(r.stdout.rstrip().splitlines()[-1]);fails=[k for k,v in result['checks'].items() if not v]
                if expect not in fails:raise ValueError(name+': expected failing assertion '+expect+'; got '+str(fails))
                results.append({'mutation':name,'detected':True,'assertion':expect,'suite':suite})
            finally:f.write_text(original)
    return results
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--site',type=Path,required=True);ap.add_argument('--php',type=Path,required=True)
    args=ap.parse_args();print(json.dumps(run(args.site,args.php.resolve()),indent=2))
