# Operação e recuperação — 0.10.0

Sem cron, fila em segundo plano, webhook ou HTTP próprio. Desativar e desinstalar não chamam a API e preservam tabelas e opções.

## Armazenamento

`{prefixo}f3_pipedrive_operations` guarda uma linha por prévia, recibo ou progresso. A chave tem 32 hexadecimais: aleatória para prévias, derivada por HMAC para mensagens de WhatsApp e para o progresso de cada lead. `payload` e `result` são cifrados com AES-256-GCM; a chave de cifra deriva dos salts do WordPress.

| Estado | Significado |
| --- | --- |
| `ready` | Prévia criada, ainda não aplicada. Vence em 15 minutos. |
| `running` | A aplicação começou. Se permanecer assim, o resultado é incerto. |
| `done` | Recibo gravado; o conteúdo da prévia foi apagado. |
| `expired` | Prévia vencida; o conteúdo foi apagado na limpeza. |
| `progress` | Progresso da cadência de um lead. Não é uma prévia e não pode ser aplicado. |

A prévia guarda o corpo a enviar e o hash do estado lido, sem a cópia do estado. O progresso guarda identidade HMAC, ID da atividade, código do toque, instante, resumo da nota e ID do recibo; não guarda a mensagem.

`{prefixo}f3_pipedrive_journal` guarda uma linha por tentativa de escrita: ID sequencial, ID da prévia, instante UTC e metadados (método, caminho, classe, estado, chaves alteradas, etapas, HTTP e saldo). Em `api-aplicar` o caminho traz o ID do registro. Novas operações compostas guardam também o alvo identificável, quando houver, e a sequência de etapas. Linhas históricas podem não ter o ID do alvo. Mudanças de estrutura registram nomes e opções. Nenhum conteúdo de nota ou valor de campo pessoal entra no diário.

## Retenção e limpeza

| Dado | Prazo |
| --- | --- |
| Prévia | 15 minutos |
| Recibo comum | 180 dias desde a criação da prévia |
| Recibo de WhatsApp | sem expurgo, para impedir registro duplicado |
| Progresso da cadência e recibo de recuperação que sustenta esse progresso | sem expurgo |
| Diário | sem prazo por padrão; de 1 a 36.500 dias se configurado |

A limpeza é oportunista nas prévias e nas escritas, inclusive nas operações compostas. Não há cron. Para a mesma revisão da política, o intervalo é de pelo menos 60 segundos entre lotes, cada qual com até 100 linhas por categoria. Se a trava oportunista estiver ocupada, o lote é pulado. Assim, sem chamadas elegíveis, o dado vencido permanece no banco, embora uma prévia expirada já não possa ser aplicada. O registro de tentativas em execução e as evidências de pendências são preservados. Ler ajuda, status, diário ou política não dispara expurgo; salvar a política não apaga imediatamente as linhas antigas. Aumentar o prazo mais tarde não recupera o que já saiu.

## Travas

A trava de mensagem protege a chave de idempotência; a de entidade protege o mesmo lead ou negócio. A política e o expurgo usam uma trava local curta de retenção. O plugin não mantém essa trava enquanto espera o HTTP do fornecedor. Outro lead consegue prosseguir até o cliente do Core; lá existe um controle separado, por instalação. Isso não garante que dois HTTP sejam enviados ao mesmo tempo.

Se uma tentativa receber `operacao_ocupada` ou `retencao_ocupada`, confira primeiro a operação e o recibo. Repetir o **mesmo identificador** permite recuperar o resultado já gravado. Uma etapa despachada e sem comprovação não deve ser enviada outra vez.

## Uma tentativa por prévia

A passagem de `ready` para `running` e a criação da linha do diário são confirmadas na mesma transação InnoDB antes do envio. Duas execuções não adquirem a mesma prévia. Depois da chamada, recibo, diário e, em `whatsapp-registrar`, o progresso são gravados em outra transação. Se essa gravação falhar, a operação fica `running` e o marcador de pendência permanece. Nunca volte `running` para `ready`.

Nas operações compostas, cada etapa é confirmada no diário antes da seguinte. Um marcador de pendência (opção `f3_pd_pending_v2_<hash>`, com o ID da prévia como valor) é criado antes da primeira escrita e retirado quando todas as etapas têm resultado certo.

## Recuperação

### Escrita com resposta incompleta

Um HTTP 2xx com JSON ilegível ou mais de 512 KiB pode corresponder a uma escrita já aplicada. Em `api-aplicar`, guarde o ID e o recibo, leia o diário e consulte o registro exato por `api-ler`. Posicione cada etapa como comprovada, comprovadamente ausente ou desconhecida. A falta do corpo da resposta ou de permissão para ver o registro não prova ausência. Só uma confirmação independente de ausência e uma nova ordem justificam uma nova tentativa.

### Operação composta com pendência

1. Entre com o administrador e a conta usados na operação. Consulte `pipedrive/pendencias-ler {"limite":20}` e o histórico de `pipedrive/registro-ler`. Para outras páginas, passe `data.proximo_apos_id` como `apos_id`, até ele ser nulo. Marcadores históricos com evidência insuficiente podem aparecer como `sem_prova_de_intencao` ou `alvo_nao_identificavel`; em ambos os casos, preserve-os. Após atualizar da 0.8.0, um marcador da revisão antiga só pode ser exposto se as evidências permitirem atribuí-lo ao mesmo administrador e à conta atual; sem intenção verificável não é liberado. Um resultado vazio refere-se ao escopo consultado; não prova que todas as contas estejam livres de pendências. Preserve o ID do recibo da operação original.
2. Gere uma revisão do caso com `pipedrive/recuperacao-previa {"origem_id":"ID_DO_RECIBO_ORIGINAL"}`. Substitua o marcador pelo ID de 32 caracteres hexadecimais. O plugin verifica o alvo e lê evidências da conta pelo Core. Em `recuperacao_revisada`, confira `data.registro_id`, `data.resolucao`, `data.previa_id`, `data.confirmacao_exigida` e `data.validade_segundos`. A ação não cria nem exclui atividades, não altera o negócio e não envia mensagem.
3. O desfecho `efeito_confirmado` exige que o registro atual corresponda à intenção comprovada; `nao_despachado` exige evidência de ausência de despacho nas etapas e estado inicial compatível. Com `recuperacao_inconclusiva`, mantenha o bloqueio. Confira as etapas, o acesso e o estado do registro; preserve a evidência para o responsável pela conta. Uma edição manual, exclusão ou mudança de conta não autoriza presumir o que ocorreu.
4. Se a prévia permitir uma resolução, confira a entidade e o efeito local descrito. Depois da decisão do responsável, envie a `pipedrive/recuperacao-confirmar` o **ID da nova prévia** em `previa_id` e a frase que ela forneceu em `confirmacao`. Ela vale 15 minutos. A confirmação confere outra vez conta, ator e evidência; não reenvia a operação comercial.
5. Releia a pendência, o diário e a fila do lead quando aplicável. Em `recuperacao_confirmada`, o recibo de resolução e a linha do diário identificam o desfecho local. Uma prévia já confirmada devolve o mesmo recibo, mantendo o escopo de conta e ator. A decisão de recuperação é registrada separadamente da tentativa original. Preserve ambos os recibos. Uma resolução que perdeu validade exige nova avaliação. Não libere a entidade apagando registros do banco.

### Nota alterada ou progresso incompatível

Se a fila indicar `progresso_divergente` após uma edição humana, confira a atividade e o histórico. Para pedir uma prévia de realinhamento, use `pipedrive/recuperacao-previa {"lead_id":"00000000-0000-4000-8000-000000000001"}` com o UUID real. O desfecho `realinhar_nota` exige um recibo de progresso verificável, o mesmo lead aberto e a mesma atividade única, aberta e do tipo configurado. A operação conserva o toque e o instante do último registro e adota o resumo atualizado da nota; a confirmação requer a frase da prévia. Se a atividade tiver sido apagada, for duplicada ou pertencer a outro lead, não atribua avanço pela semelhança do texto.

`progresso_incompativel` indica que o último toque conhecido não existe nas regras: confira os códigos e corrija a configuração por simulação e aplicação. `historico_sem_marcador` significa que o plugin não conseguiu provar o último toque; confira a política de adoção descrita em [Fluxos](WORKFLOWS.md).

### Recibos expirados ou ilegíveis

Uma prévia vencida não autoriza assumir que um efeito comercial nunca existiu. Confira a chave original, o diário e o fornecedor. Se os salts do WordPress mudaram, preserve o banco e restaure a chave correta por procedimento autorizado de recuperação; sem ela, os dados cifrados não podem ser usados para destravar outra operação.

## Identificadores de lead e pendências de versões anteriores

O mesmo UUID, em qualquer combinação de maiúsculas e minúsculas, usa a mesma trava e o mesmo marcador. Marcadores criados até a 0.7.0 são preservados. Se o recibo ou a prévia cifrada ainda identifica o registro, o bloqueio vale só para aquele lead e aquela conta. Sem essa evidência, o plugin examina no máximo 64 marcadores antigos e até 256 grafias do UUID; se não conseguir provar que o marcador é de outro registro, recusa a escrita com `reconciliacao_necessaria`. Com mais de 64 marcadores antigos, recusa as escritas em leads até a reconciliação.

## Instalação e atualização

Atualização direta 0.9.0 → 0.10.0. A troca preserva tabelas, estados, regras, revisão e prazos, e não ativa conexão nem cadência. Se for interrompida, preserve banco, salts, recibos e tentativas pendentes; confira os arquivos, a versão em nova requisição e a saúde do WordPress. A correção vem em nova versão; não há downgrade. Uma cópia de segurança recupera dados locais e não desfaz o que foi executado no fornecedor.

## Aceite pendente

O aceite do Pedido MCP Pipedrive 11 em korvena.com.br requer uma pessoa vinculada, lead de teste criado e excluído no mesmo trabalho, nota sem marcador novo, participante principal conferido e repetição com o recibo original. Os ensaios sintéticos não substituem esse aceite.
