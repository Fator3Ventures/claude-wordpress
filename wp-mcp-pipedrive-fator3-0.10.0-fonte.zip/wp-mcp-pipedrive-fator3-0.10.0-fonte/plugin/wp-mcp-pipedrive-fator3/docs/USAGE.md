# Uso — 0.10.0

Exemplos sintéticos. As respostas em trechos mostram somente os campos necessários à decisão; IDs, custos e contagens variam por conta e chamada. Substitua os IDs por registros autorizados. Leia o schema no catálogo: o transporte MCP pode acrescentar campos de controle próprios.

## Diagnóstico e leitura

`pipedrive/status {}` não faz HTTP. Com a operação autorizada, `data` traz `provider`, `version`, `contrato_exigido`, `registro_cliente`, `documentacao`, `chamada_externa`, `contract`, `autorizado`, `conta`, `revisao`, `orcamento`, `saldo_conta` e `retencao`.

`pipedrive/api-ler {"caminho":"/v1/dealFields","query":{"limit":100,"start":0}}` consulta o catálogo de campos. O resultado tem `data.http_status`, `data.body` e `data.saldo_conta`. Coleção vazia não é erro. Siga a paginação do fornecedor. `saldo_conta: null` não significa orçamento ilimitado.

## Ciclo da cadência

**1. Ler a fila.** `pipedrive/cadencia-fila` com um instante opcional:

```json
{"agora":"2026-11-10T15:00:00Z"}
```

Um item devido:

```json
{"lead_id":"00000000-0000-4000-8000-000000000001","toque":"primeiro","devido_em_utc":"2026-11-09T12:30:00Z","periodo":"manha","texto_aprovado":"Texto aprovado da primeira mensagem.","devido":true,"motivo":null,"acao":"mensagem","politica_canal":{"encerramento":true,"arquivamento":true,"regras":[]},"origem_progresso":"etiqueta_ou_inicio","texto_id":"abertura"}
```

Antes de usar os itens, confira `data.pagina_completa`, os motivos e o custo. Com `{"limite":10,"filtro":"devidos"}`, uma página completa pode trazer estes campos:

```json
{"itens":[],"avaliados":10,"devidos":0,"pagina_completa":true,"fim_da_fila":false,"proximo_cursor":"CURSOR_DEVOLVIDO"}
```

Nesse caso, consulte `cadencia-fila {"limite":10,"filtro":"devidos","cursor":"CURSOR_DEVOLVIDO"}` substituindo o marcador pelo valor real, sem mudar os filtros. Pare no fim confirmado. Se a fonte falhar, não registre contatos nem some um subtotal como se fosse o total da conta.

**2. Enviar pelo canal.** O envio é feito fora deste plugin.

**3. Registrar.** `pipedrive/whatsapp-registrar`, com uma chave de idempotência por mensagem:

```json
{"lead_id":"00000000-0000-4000-8000-000000000001","mensagem":"Texto aprovado da primeira mensagem.","proximo":"Perguntar qual horário funciona para a conversa.","toque":"primeiro","chave_idempotencia":"envio-2026-11-10-0001"}
```

Resposta, com os identificadores substituídos:

```json
{"success":true,"code":"operacao_concluida","message":"Operação concluída; recibo persistido.","previa_id":"ID_DO_RECIBO","applied":true,"data":{"entrada_digest":"HMAC_DA_ENTRADA","operacao":"whatsapp-registrar","id":"00000000-0000-4000-8000-000000000001","etapas":[{"etapa":"criar_whatsapp","success":true,"code":"ok","http_status":200,"remote_dispatched":true}],"atividade_id":101,"reconciliacao_necessaria":false}}
```

A resposta real traz ainda `data.proximo_periodo_utc`, o prazo gravado na atividade. A nota recebe uma linha no formato `<p>[IA] DD/MM HHhMM, nós: Texto aprovado da primeira mensagem.</p>`, sem marcador.

**4. Repetir com segurança.** A mesma entrada com a mesma chave devolve o mesmo recibo e não escreve de novo. A mesma chave com outro texto devolve `idempotencia_conflitante`.

**5. Encerrar.** `pipedrive/lead-encerrar` prepara:

```json
{"lead_id":"00000000-0000-4000-8000-000000000001","mensagem":"Encerramento combinado com o lead.","archive_reason":"Sem resposta após cadência"}
```

```json
{"success":true,"code":"previa_criada","message":"Revise e use pipedrive/operacao-aplicar em até 15 minutos.","data":{"previa_id":"ID_DA_PREVIA","operacao":"lead-encerrar","classe":"registro","id":"00000000-0000-4000-8000-000000000001","chaves":[],"config_revisao":"REVISAO_DAS_REGRAS","arquivo_data_original":null,"mutacoes_estimadas":2,"atomicidade":"Operação lógica com recibo por etapa; o fornecedor não oferece transação entre endpoints.","custo_previa_unidades":60}}
```

`pipedrive/operacao-aplicar {"previa_id":"ID_DA_PREVIA"}` executa as etapas `atualizar_whatsapp` e `arquivar` e devolve `operacao_concluida`. Quando o lead não tem atividade de WhatsApp, a primeira etapa é `criar_whatsapp`.

## Alterar um campo de lead

Obtenha no catálogo a chave real do campo (40 hexadecimais) e os IDs das opções; o ID numérico do campo não substitui a chave.

```json
{"metodo":"PATCH","caminho":"/v1/leads/00000000-0000-4000-8000-000000000001","corpo":{"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa":152}}
```

Envie a `pipedrive/api-previa`. A resposta traz `previa_id`, `expira_em`, `estado_atual`, `corpo_a_enviar`, `classe`, `se_desfaz`, `reversao`, `opcoes_a_remover`, `resumo`, `confirmacao_exigida`, `custo_estimado`. Revise e envie `pipedrive/api-aplicar {"previa_id":"ID_DEVOLVIDO"}`. Confira com um GET do lead e com `pipedrive/registro-ler {}`. Repetir o mesmo ID devolve o mesmo recibo, dentro da retenção e enquanto usuário, conta e revisão continuarem os mesmos. A prévia vence aos 15 minutos.

## Estrutura

Prévia de etiqueta:

```json
{"metodo":"POST","caminho":"/v1/leadLabels","corpo":{"name":"Teste pipedrive-operacao (apagar)","color":"blue"}}
```

Depois da ordem do dono, chame `api-aplicar` com `previa_id` e `confirmacao` copiados da resposta. A frase tem a forma `Confirmo por ordem do dono de DD/MM/AAAA: POST /v1/leadLabels; chaves: name, color; prévia DIGEST16`. A confirmação é obrigatória também para excluir etiqueta, campo ou filtro. Remova a etiqueta sintética pela mesma sequência, com DELETE e o UUID dela.

Para opções de campo, envie todas as que devem permanecer, com `id` e `label`. Para retirar uma existente, liste o ID em `remover_opcoes`. Omitir uma por engano devolve `opcao_seria_apagada`, com as opções afetadas, e nada é enviado. Uma opção nova leva `label` sem `id`.

## Distinguir ausência de informação de problema confirmado

Chame `pipedrive/auditoria {"max_chamadas":20}`. Se o limite interromper a leitura das atividades, a resposta pode trazer `code: coleta_parcial` e este trecho em `data`:

```json
{"coleta_completa":false,"avaliacao_completa":false,"itens_nao_avaliados":[{"entidade":"lead","id":"00000000-0000-4000-8000-000000000001","regra":"sem_proxima_atividade","motivo":"colecao_atividades_incompleta"}]}
```

Esse lead precisa de verificação. Só uma ocorrência em `itens` indica falta de atividade segundo os registros visíveis.

## Diário

`pipedrive/registro-ler {"limite":50}` devolve `itens` e `proximo_antes_id`; use esse valor em `antes_id` para a página seguinte. A ordem é por ID decrescente. Cada item traz `instante_utc`, `metodo`, `caminho`, `classe`, `status`, `chaves_alteradas` e, conforme a operação, `http_status`, `saldo_depois`, `etapas` e `estrutura`. O diário não contém nome, e-mail, telefone, conteúdo de nota nem valor de campo pessoal.

## Recuperar sem reenviar

1. Execute `pipedrive/pendencias-ler {"limite":20}` com o administrador da operação. A listagem não faz HTTP. Localize o recibo de origem e confira o alvo também no diário.
2. Em `pipedrive/recuperacao-previa`, use `{"origem_id":"ID_DO_RECIBO_ORIGINAL"}` para a pendência, ou `{"lead_id":"UUID_DO_LEAD"}` para conferir uma nota editada. Forneça exatamente um dos dois. O Core é usado para releituras. Se não houver prova conclusiva, não aplique.
3. Para uma resolução mostrada e aprovada, chame `pipedrive/recuperacao-confirmar {"previa_id":"ID_DA_PREVIA_DE_RECUPERACAO","confirmacao":"FRASE_EXATA_DA_PREVIA"}`. Os marcadores precisam ser substituídos pelos valores reais. A operação confirma a decisão local, preserva o histórico e não repete a escrita no Pipedrive. Veja os limites em [Operação e recuperação](OPERATIONS.md).

## Retenção

1. `pipedrive/retencao-ler {}`. Anote `data.revisao` e confira `diario_dias`.
2. Diário sem prazo: `pipedrive/retencao-configurar {"diario_dias":0,"revisao_esperada":"HASH_LIDO"}`.
3. Prazo de 730 dias: `{"diario_dias":730,"revisao_esperada":"HASH_LIDO","confirmar_expurgo":true}`. As linhas anteriores ao corte ficam elegíveis nas limpezas seguintes, exceto tentativas em execução e registros com pendência.
4. Releia `retencao-ler` e confira `persisted`, a política e a nova revisão. Diante de `revisao_conflitante`, releia antes de reenviar.

O diário sem prazo não prolonga a validade de prévias, travas ou recibos.

## Relatório agregado

`pipedrive/relatorio` é leitura. Usa somente GET pelo cliente do Core, consumidor `operacao`. Não cria diário, recibo, cache, configuração ou cron. Pelo REST: GET `/wp-json/f3-pipedrive/v1/relatorio`. Não há formulário no painel.

Exemplo de 30 dias, em America/Sao_Paulo:

```json
{"data_inicio":"2026-09-28","data_fim":"2026-10-27","limite_plano":1500,"max_chamadas":100}
```

O limite 1500 é fictício: use o valor confirmado em Configurações → Empresa → Uso, no Pipedrive. Ele não é descoberto pela API nem inferido do nome do plano. Sem ele, `limite`, `percentual` e `saldo` vêm nulos, com `limite_plano_nao_informado`; `total` continua disponível se a coleta ativa for completa. O orçamento de API é outra medida.

### Período e contagem

Datas civis reais, inclusivas, em fuso IANA (padrão America/Sao_Paulo), até 3.660 dias. O fim é convertido para o início do dia seguinte no fuso; datas do fornecedor sem offset são UTC. Com `criterio_leads: criacao` (padrão), entram os leads abertos e arquivados criados no período, por `add_time`. Com `criterio_leads: arquivamento`, os arquivados usam `archive_time` e os abertos continuam por criação; sem essa data o relatório fica parcial, sem substituí-la pela de atualização. Negócios por funil e etapa usam criação. Ganhos e perdas usam `won_time` e `lost_time`, inclusive de negócios arquivados. O relatório descreve o estado atual: não é histórico de transições nem fotografia da conta na data final.

`leads.grupos` cruza estado, parceiro, unidade, canal, campanha, ponto de conversão e motivo de arquivamento; some `quantidade` para obter marginais. Um campo de múltipla escolha vira um conjunto ordenado: o registro conta uma vez no conjunto. `negocios.por_funil_etapa` cruza IDs de funil e etapa, estado e arquivamento. `negocios.por_resultado_motivo` agrupa ganhos e perdas. Não existe motivo nativo de ganho: sem o campo personalizado `motivo_ganho`, a categoria é `sem_campo`.

`uso_plano` ignora o período: soma leads ativos e negócios abertos, ganhos e perdidos que não estejam arquivados nem excluídos. Duplicata ou estado divergente durante a paginação impede declarar total fechado.

### Campos e proteção de dados

O catálogo `/v1/dealFields` é lido por páginas. A descoberta é por nome exato, sem acento e sem diferença de caixa: Parceiro, Unidade, Canal, Campanha, Ponto de conversão e Motivo de ganho. Nome ambíguo ou ausente gera pendência; `campos` aceita a chave de 40 hexadecimais para resolver. `campos.canal: channel` seleciona o canal nativo, que não é presumido igual ao campo Canal.

Tipos aceitos como dimensão: `enum`, `set`, `varchar`, `varchar_auto` e `text`. Não saem títulos, nomes, e-mails, telefones, IDs de pessoas, leads ou negócios, respostas brutas, textos de motivos nem rótulos livres. Opções conhecidas saem como `opcao:ID`; funis e etapas, como IDs. Texto e opção desconhecida viram `categoria:` seguido de um HMAC estável por site, conta e dimensão. Isso protege o texto e não é anonimização estatística: trate agregados pequenos com cuidado. Trocar os salts altera esses códigos.

Para distinguir motivos conhecidos sem devolver texto, informe um dicionário, usado só em memória:

```json
{"data_inicio":"2026-09-28","data_fim":"2026-10-27","limite_plano":1500,"categorias":[{"dimensao":"motivo_arquivamento","valor":"Sem interesse","codigo":1},{"dimensao":"motivo_perda","valor":"Preço","codigo":2}]}
```

A correspondência é exata e o retorno é `codigo:1` e `codigo:2`. Até 200 entradas, valor de até 500 caracteres e código inteiro positivo. O mesmo par dimensão e valor não pode apontar para códigos diferentes. Campo não preenchido sai como `sem_valor`; campo não mapeado, como `sem_campo`.

### Completude e custo

São cinco fontes em sequência: catálogo, leads abertos, leads arquivados, negócios ativos e negócios arquivados, em páginas de 100. `fontes` traz páginas, registros e conclusão de cada uma. `coleta_completa` indica o fim válido das cinco; `completo` exige ainda ausência de pendências. Com `code: relatorio_parcial`, os agregados são parciais: todo contador com sufixo `_observados` é subtotal, e fonte não concluída não autoriza ler zero como ausência.

Limites: 100 chamadas por padrão (de 1 a 120), 45 segundos por padrão (de 1 a 120), 12.000 registros, 200 grupos e 32.000 bytes de dimensões. Exceder qualquer um interrompe com parcial. Não há retomada: executar de novo relê tudo e consome orçamento de novo.

O Core debita 20 unidades locais por GET enviado. `custo.gasto` soma os envios confirmados; envio incerto devolve `gasto` nulo, com `minimo`, `maximo` e `envio_incerto`. Não use a diferença do saldo global como custo desta leitura, porque pode haver consumo concorrente.
