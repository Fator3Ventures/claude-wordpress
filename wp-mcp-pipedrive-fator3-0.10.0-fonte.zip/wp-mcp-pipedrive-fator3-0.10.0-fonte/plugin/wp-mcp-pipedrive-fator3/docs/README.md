# Fator3 MCP Pipedrive 0.10.0

Operações administrativas na conta Pipedrive, com o token guardado no Fator3 Site Core. Este pacote não armazena token, não faz HTTP próprio, não envia WhatsApp e não interfere nas filas de entrega de leads. Todo acesso exige `manage_options`.

A versão tem 22 operações `pipedrive/*` (11 de leitura e 11 de escrita) e 12 documentos instalados. As permissões de uma conexão podem limitar as operações que aparecem na sua descoberta.

## Por onde começar

| Quero | Documento | ID |
| --- | --- | --- |
| Configurar pelo WordPress, do primeiro acesso à confirmação | [PANEL.md](PANEL.md) | `painel` |
| Instalar, autorizar no Core e saber o que fica gravado no site | [CONFIGURATION.md](CONFIGURATION.md) | `configuracao` |
| Operar como agente: qual operação usar, em que ordem e o que nunca fazer | [AGENT-GUIDE.md](AGENT-GUIDE.md) | `agentes` |
| Ver chamadas completas com entrada e saída | [USAGE.md](USAGE.md) | `uso` |
| Entender regras, cadência, fila, encerramento, auditoria e contagem | [WORKFLOWS.md](WORKFLOWS.md) | `fluxos` |
| Saber o que fazer diante de um código de erro | [CONTRACTS.md](CONTRACTS.md) | `contratos` |
| Recuperar uma escrita incerta, uma pendência ou um progresso divergente | [OPERATIONS.md](OPERATIONS.md) | `operacao` |
| Consultar listas fechadas de caminhos, corpos e limites | [SPECIFICATION.md](SPECIFICATION.md) | `especificacao` |
| Conferir tipos e limites de cada parâmetro | [schemas.json](schemas.json) | `schemas` |
| Ver o que mudou nesta versão e nas anteriores | [CHANGELOG.md](CHANGELOG.md) | `release` |
| Ver as regras com que uma instalação nova começa | [regras-iniciais.json](regras-iniciais.json) | `regras-iniciais` |

## Índice

| ID | Arquivo | Assunto |
| --- | --- | --- |
| index | [README.md](README.md) | Este índice |
| painel | [PANEL.md](PANEL.md) | Configurar pelo WordPress, revisar e confirmar |
| configuracao | [CONFIGURATION.md](CONFIGURATION.md) | Requisitos, instalação, autorização e dados gravados |
| agentes | [AGENT-GUIDE.md](AGENT-GUIDE.md) | Sequência de trabalho e regras para agentes |
| uso | [USAGE.md](USAGE.md) | Exemplos de chamadas e relatório agregado |
| fluxos | [WORKFLOWS.md](WORKFLOWS.md) | Regras, cadência, operações compostas, auditoria e contagem |
| contratos | [CONTRACTS.md](CONTRACTS.md) | Contrato Core, transporte, REST e códigos de retorno |
| operacao | [OPERATIONS.md](OPERATIONS.md) | Armazenamento, travas, retenção e recuperação |
| especificacao | [SPECIFICATION.md](SPECIFICATION.md) | Operações, listas fechadas e limites |
| release | [CHANGELOG.md](CHANGELOG.md) | Notas da 0.10.0 e histórico |
| regras-iniciais | [regras-iniciais.json](regras-iniciais.json) | Regras iniciais, sem configuração comercial presumida |
| schemas | [schemas.json](schemas.json) | Schemas gerados do runtime |

## Ler pelo MCP

1. Descubra `pipedrive/documentacao-ler` no catálogo e leia seu schema.
2. Chame `{}` para receber este índice, ou `{"documento":"uso"}` para um documento.
3. Se `data.fim` for `false`, repita a chamada com `offset` igual a `data.proximo_offset` e `sha256_esperado` igual a `data.sha256`.
4. Pare quando `data.fim` for `true`.

Peça de 256 a 24.000 bytes por página (`limite_bytes`; padrão 16.000). A resposta pode conter menos bytes no fim do documento ou para preservar um caractere UTF-8. `data.sha256` identifica o documento inteiro: se ele mudar entre páginas, a resposta é `documento_alterado` e a leitura recomeça do offset zero. Continuação sem `sha256_esperado` devolve `revisao_exigida`. Os IDs são fechados; qualquer outro valor devolve `documento_invalido`.

A leitura é estática: não consulta o Core nem o fornecedor, não verifica token e não cria tabelas, opções ou agendamentos. Funciona com a operação comercial desautorizada.

## Ler pelo WordPress

Ferramentas → Fator3 MCP Pipedrive → Ajuda. Escolha um guia e navegue por suas seções. O limite de 24.000 bytes corresponde a uma página do leitor documental; não é um limite para o tamanho de um guia. Consulte o [guia do painel](PANEL.md) para a primeira configuração.

## Dois diários diferentes

`pipedrive/registro-ler` lê o diário local das tentativas de escrita deste plugin. `pipedrive/auditoria` lê dados da conta pelo Core e aponta anomalias em leads e negócios. O primeiro funciona sem autorização comercial; o segundo consome orçamento.
