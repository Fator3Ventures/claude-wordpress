# Configuração — 0.10.0

## Requisitos

WordPress 7.1.4 ou superior, PHP 8.3 ou superior de 64 bits, OpenSSL com AES-256-GCM, mbstring e banco MySQL ou MariaDB com InnoDB. Site único: a ativação recusa multisite. As versões efetivamente executadas nos testes estão no relatório de entrega.

Para usar a conta Pipedrive, o Fator3 Site Core precisa fornecer o contrato `pipedrive-api-client/1.0.0`. Sem o Core, um administrador ainda abre a ajuda, consulta o diário e ajusta a retenção. Google, Meta e LinkedIn não são necessários.

## Instalar ou atualizar

1. Confira o SHA-256 do instalador contra o relatório de entrega.
2. Instale `wp-mcp-pipedrive-fator3-0.10.0-instalador.zip` nos sites-porta definidos pelo dono ou pela frota. O ZIP de fonte não é instalável.
3. Em instalação limpa, a ativação cria as duas tabelas próprias e grava o schema 1.
4. Na atualização direta da 0.9.0, preserve o banco, os salts do WordPress e a configuração do Core. A troca mantém regras, prazos, recibos e pendências, e não concede autorização comercial.

## Autorizar no Site Core

1. A credencial fica no Core (`f3base_pipedrive_token`), pela tela e pela verificação dele. Nenhum token entra no chat nem neste plugin.
2. Pelo contrato de configuração do Core, ative `f3base_pipedrive_operacao.ativo=true` e conceda acesso ao consumidor `wp-mcp-pipedrive-fator3` no site autorizado, preservando as concessões de outros consumidores. Consulte o schema efetivo de `f3base/config-core-escrever` e confira a configuração relida. Este plugin não grava opções de outros plugins.
3. Autorize as rotas `pipedrive/*` na conexão MCP. O registro do provider não concede perfil, e autorização de leitura não libera as operações de escrita.

## Conferir

Chame `pipedrive/status {}` ou abra a Visão geral. A leitura é local, sem HTTP.

| Campo de `data` | O que conferir |
| --- | --- |
| `registro_cliente` | `registrado` quando o Core entregou o cliente; `core_indisponivel` ou `contrato_invalido` caso contrário. |
| `conta` | Domínio, `conta_id` e `usuario_id` esperados para este site. |
| `revisao` | Identifica conta, credencial e autorização; muda quando qualquer uma delas muda. |
| `orcamento` | `teto`, `consumido` e `reservado`, em unidades locais do Core. |
| `saldo_conta` | `restante` e `lido_em`, ou `null` quando o Core ainda não leu o saldo. `null` não significa saldo ilimitado. |
| `retencao` | Política local do diário; vem mesmo com a operação desautorizada. |

Sem contrato, o código é `core_indisponivel`. Sem concessão, `operacao_nao_autorizada`. Nos dois casos `success` é `false` e `data` ainda traz a versão, o registro do cliente e a retenção. A interface mostra o diagnóstico, sem pedir token e sem reparo automático.

## Orçamento

O orçamento de operação (padrão de 3.000 unidades por dia UTC, reserva de 20 por GET e 10 por escrita, piso de saldo de 3.000, pausa remota e recuperação) pertence ao Core. Este plugin sempre consulta o cliente e não mantém cota paralela. Prévias, revalidações, fila, auditoria, contagem, relatório e simulação de regras consomem GETs. Revogar a autorização no Core suspende novas operações e a releitura de recibos vinculados à conta; a documentação, o diário e a retenção continuam disponíveis.

## O que este plugin grava no site

| Onde | Conteúdo |
| --- | --- |
| Tabela `{prefixo}f3_pipedrive_operations` | Prévias, recibos cifrados e o progresso da cadência por lead. |
| Tabela `{prefixo}f3_pipedrive_journal` | Uma linha por tentativa de escrita, sem conteúdo de nota nem valor de campo pessoal. |
| Opção `f3_pipedrive_operation_rules` | Regras de operação em JSON. Só existe depois da primeira aplicação; antes disso valem as regras iniciais. |
| Opção `f3_pipedrive_retention` | Política de retenção do diário. Só existe depois da primeira configuração; ausente, o diário não tem prazo. |
| Opção `f3_pipedrive_cleanup_after` | Guarda o intervalo da limpeza oportunista; não é agenda de cron. |
| Tentativas de formulário `f3_pd_form_` | Comprovantes locais por sessão para evitar reenvio. O resultado temporário cifrado pode ser relido por 15 minutos; um formulário vence em 30 minutos. |
| Opção `f3_pipedrive_schema` | Versão do schema das tabelas (1). |
| Opções `f3_pd_pending_v2_<hash>` | Uma por registro com escrita pendente de reconciliação; o valor é o ID da prévia. Marcadores de versões anteriores usam `f3_pd_pending_<hash>`. |

Todas as opções têm autoload desativado. Os recibos e o progresso são cifrados com chave derivada dos salts do WordPress: inclua as duas tabelas, as opções e os salts nas cópias de segurança. Trocar os salts torna ilegíveis os recibos e o progresso existentes.

Use as operações de recuperação descritas em [Operação e recuperação](OPERATIONS.md). Apagar um marcador isolado pode deixar o recibo e a cadência inconsistentes.

## Desativar e desinstalar

Desativar não altera dados. Desinstalar também não: as tabelas e as opções acima permanecem no banco, sem chamada ao fornecedor. Não há rotina de remoção de dados nesta versão.

## Política de retenção

Ferramentas → Fator3 MCP Pipedrive → Diário e retenção. O campo aceita 0 (sem prazo) ou de 1 a 36.500 dias. Prazo finito exige marcar a autorização de expurgo futuro. O formulário usa revisão e nonce e só confirma depois de reler o valor persistido. Salvar não executa expurgo. Os prazos de recibos e prévias não são editáveis.

Pelo MCP: `pipedrive/retencao-ler {}` e depois `pipedrive/retencao-configurar` com a `revisao` recebida. Ler não cria a opção. Atualizar ou reativar o plugin não substitui uma escolha já salva nem apaga linhas. Uma política ilegível falha fechada, sem escolher prazo destrutivo.

## Parâmetros do relatório

`pipedrive/relatorio` não grava configuração. `campos`, `categorias` e `limite_plano` valem só na requisição. Nome de campo ambíguo exige a chave explícita. O motivo de ganho é um campo personalizado.

## Alterar regras

Ferramentas → Fator3 MCP Pipedrive → Regras de operação. O guia `painel` descreve os campos, a simulação e a confirmação; o guia `fluxos` descreve cada grupo de regras.

## Conferência após atualizar

1. `pipedrive/documentacao-ler {"documento":"release"}` deve devolver `version` 0.10.0 e o hash do documento instalado.
2. `pipedrive/configuracao-ler {}` e `pipedrive/retencao-ler {}` devem devolver as mesmas regras, revisões e prazos de antes da troca.
3. `pipedrive/status {}` mostra a autorização do Core, que é independente da atualização.
4. Prévias criadas antes da troca devem ser refeitas: a versão do consumidor participa da revisão do Core.
