# Especificação — 0.10.0

As 22 operações `pipedrive/*` exigem `manage_options` no WordPress, pelo painel, pelo REST e pelo MCP. A conexão MCP precisa ainda de autorização para a operação. As operações que consultam a conta usam somente o cliente do Site Core.

## Operações

"Local" é o que a operação grava neste site. "Conta" é o que ela faz no Pipedrive pelo Core.

| Operação | REST | Local | Conta | Finalidade |
| --- | --- | --- | --- | --- |
| `documentacao-ler` | GET | nada | nada | Índice e documentos instalados, por páginas. |
| `status` | GET | nada | nada | Contrato, autorização, conta, orçamento, saldo e retenção. |
| `registro-ler` | GET | nada | nada | Diário local das tentativas de escrita. |
| `pendencias-ler` | GET | nada | nada | Lista casos locais no escopo do administrador e da conta autorizada. |
| `recuperacao-previa` | POST | cria prévia quando conclusiva | leitura | Confronta a pendência ou o progresso com o registro atual. |
| `recuperacao-confirmar` | POST | resolução auditada | leitura | Relê a evidência e confirma somente a resolução local apresentada. |
| `retencao-ler` | GET | nada | nada | Política de retenção e sua revisão. |
| `retencao-configurar` | POST | grava a política | nada | Define o prazo do diário. |
| `configuracao-ler` | GET | nada | nada | Regras em vigor, revisão e origem. |
| `configuracao-simular` | POST | cria prévia | leitura | Avalia uma amostra de até 20 leads com as regras candidatas. |
| `cadencia-fila` | GET | nada | leitura | Avalia uma página de leads abertos; devolve o próximo cursor quando há continuação. |
| `whatsapp-registrar` | POST | recibo e progresso | escrita | Registra na atividade uma mensagem já enviada. |
| `lead-encerrar` | POST | cria prévia | leitura | Prepara linha final, conclusão da atividade e arquivamento. |
| `negocio-perder` | POST | cria prévia | leitura | Prepara a perda de um negócio aberto. |
| `lead-arquivado-editar` | POST | cria prévia | leitura | Prepara desarquivar, editar e rearquivar. |
| `operacao-aplicar` | POST | recibo | escrita | Aplica a prévia de regras ou de operação composta. |
| `api-ler` | POST | nada | leitura | GET da lista fechada. |
| `api-previa` | POST | cria prévia | leitura | Prepara uma escrita da lista fechada. |
| `api-aplicar` | POST | recibo | escrita | Aplica a prévia de `api-previa`. |
| `auditoria` | GET | nada | leitura | Anomalias em leads e negócios, por ID e regra. |
| `contar-por-campo` | GET | nada | leitura | Contagem de registros por valor de um campo. |
| `relatorio` | GET | nada | leitura | Agregados do período, sem dados individuais. |

A aplicação de uma prévia de regras por `operacao-aplicar` grava só neste site. O namespace REST é `/wp-json/f3-pipedrive/v1/`.

## Limites

| Limite | Valor | O que acontece ao exceder |
| --- | --- | --- |
| Validade de uma prévia | 15 minutos | `previa_expirada`; gere outra. |
| Recibo comum | 180 dias | A repetição pelo ID deixa de devolver o recibo. |
| Recibo de WhatsApp e progresso da cadência | sem expurgo | — |
| Diário | sem prazo, ou de 1 a 36.500 dias | Linhas vencidas saem nas limpezas seguintes. |
| Corpo de uma escrita | 65.536 bytes | `corpo_excedeu_limite`. |
| Resposta do fornecedor | 524.288 bytes | `resposta_excedeu_limite`. |
| Página de documento | de 256 a 24.000 bytes; padrão 16.000 | Continue por `proximo_offset`. |
| Página do diário | de 1 a 100 linhas; padrão 50 | Continue por `proximo_antes_id`. |
| Chamadas por coleta (`max_chamadas`) | de 1 a 120; padrão 100 | `limite_de_coleta` em `motivos`; coleta parcial. |
| Tempo por coleta (`tempo_maximo_segundos`) | de 1 a 120; padrão 45 | `limite_de_coleta` em `motivos`; coleta parcial. |
| Página de atividades na fila | Até 500 na consulta ao Core | Respostas grandes exigem páginas menores, dentro do teto da coleta. |
| Registros por coleta | 12.000 | `limite_de_coleta` em `motivos`; coleta parcial. |
| Leads por página da fila (`limite`) | 1 a 200; padrão 200 | A conta pode ter mais leads. Continue por `proximo_cursor`, mesmo se a página filtrada estiver vazia. |
| Leads simulados por prévia de regras | Até 20 | O alcance da amostra acompanha a prévia. Não extrapole o número de devidos para a conta inteira. |
| Ocorrências da auditoria | 1.000 confirmadas e 1.000 não avaliadas | `limite_de_saida` em `motivos`. |
| Grupos da contagem | 200 | `limite_de_grupos` em `motivos`. |
| Relatório | 12.000 registros, 200 grupos, 32.000 bytes de dimensões, período de até 3.660 dias | Relatório parcial com a pendência correspondente. |
| Catálogo de campos em `api-previa` | 20 páginas de 500 | `limite_de_leitura`. |
| Mensagem | de 1 a 4.000 caracteres | Recusa pelo schema. |
| Chave de idempotência | de 8 a 128 caracteres | Recusa pelo schema. |
| Texto aprovado depois das variáveis | 16.000 bytes | Item da fila com `texto_excedeu_limite`. |
| Objeto de regras | 65.536 bytes; 50 toques, 50 textos, 24 períodos, 366 feriados | `configuracao_invalida`. |
| Espera por uma trava | 1 segundo | `operacao_ocupada` ou `retencao_ocupada`; nada foi enviado. |

A fila e a simulação não criam contato comercial. A fila só consulta. A simulação grava uma prévia local de uso único após validar a amostra ou confirmar que a conta visível está vazia. O limite de uma página não significa falha de coleta. Uma origem incompleta impede concluir a simulação.

## Lista GET

* `/v1/leads/{uuid}`, `/v1/leads`, `/v1/leads/archived`; as listas aceitam `filter_id`, `limit` (de 1 a 500) e `start`.
* `/v1/dealFields`, `/v1/personFields`, `/v1/organizationFields`, `/v1/activityFields`, `/v1/noteFields`; `limit` e `start`.
* `/v1/filters` (`type`), `/v1/filters/{id}`, `/v1/leadLabels`, `/v1/activityTypes`, `/v1/users/me`.
* `/v1/notes/{id}`, `/v1/notes` (`lead_id`, `deal_id`, `person_id`, `org_id`, `limit`, `start`).
* `/api/v2/deals/{id}`, `/api/v2/persons/{id}`, `/api/v2/organizations/{id}`, `/api/v2/activities/{id}`.
* `/api/v2/deals`, `/api/v2/deals/archived`, `/api/v2/persons`, `/api/v2/organizations`, `/api/v2/pipelines`, `/api/v2/stages`: `limit` e `cursor`. `/api/v2/activities` aceita ainda `lead_id` e `deal_id`.

IDs de lead e de etiqueta são UUID; os demais são inteiros positivos. A query vem em objeto separado do caminho. Nenhum caminho aceita URL absoluta, query embutida, barras codificadas, travessia ou `merge`. As chaves `ids`, `api_token`, `access_token`, `token`, `authorization`, `headers`, `url` e `host` são recusadas em qualquer nível da query e do corpo.

## Lista de escrita

| Classe | Método | Caminho |
| --- | --- | --- |
| registro | PATCH | `/v1/leads/{uuid}` |
| registro | PUT | `/v1/notes/{id}` |
| registro | DELETE | `/v1/leads/{uuid}`, `/v1/notes/{id}`, `/api/v2/persons/{id}`, `/api/v2/organizations/{id}`, `/api/v2/deals/{id}`, `/api/v2/activities/{id}` |
| estrutura | POST | `/v1/dealFields`, `/v1/personFields`, `/v1/organizationFields` |
| estrutura | PUT, DELETE | `/v1/dealFields/{id}`, `/v1/personFields/{id}`, `/v1/organizationFields/{id}` |
| estrutura | POST | `/v1/filters`, `/v1/leadLabels` |
| estrutura | PUT, DELETE | `/v1/filters/{id}` |
| estrutura | PATCH, DELETE | `/v1/leadLabels/{uuid}` |

Os corpos também são listas fechadas.

| Recurso | Chaves aceitas |
| --- | --- |
| Lead | `title`, `owner_id`, `label_ids`, `person_id`, `organization_id`, `value`, `expected_close_date`, `visible_to`, `was_seen`, `is_archived`, `archive_reason`, `origin_id`, `channel`, `channel_id` e chaves personalizadas de 40 hexadecimais, com os sufixos `_currency`, `_start`, `_end` e `_until`. |
| Nota | `content` e `pinned_to_deal_flag`, `pinned_to_person_flag`, `pinned_to_organization_flag`, `pinned_to_lead_flag`. |
| Campo novo | `name`, `field_type`, `options`. |
| Campo existente | `name`, `options`, `remover_opcoes`. |
| Filtro novo | `name`, `type`, `conditions`. |
| Filtro existente | `name`, `conditions`. |
| Etiqueta | `name`, `color`. |

DELETE não recebe corpo. Arquivar um lead (`is_archived: true`) exige `archive_reason` presente na lista aprovada das regras; um canal protegido pelas regras também impede o arquivamento por esta rota.

Campos e etiquetas existentes são localizados no catálogo GET permitido; não há GET de etiqueta individual. Não existe busca nem escrita genérica fora dessas listas.

## Integridade

PUT de campo com `options` compara os IDs atuais com os recebidos. IDs existentes omitidos precisam constar, exatamente, em `remover_opcoes`; a lista e os nomes aparecem na prévia, e esse controle local é retirado do corpo enviado. IDs desconhecidos ou repetidos são recusados. Omitir `options` por inteiro conserva as opções atuais.

Operações de estrutura exigem a frase literal devolvida pela prévia, com a data em America/Sao_Paulo, o método e o caminho, as chaves e um digest da prévia. A frase não prova que o dono autorizou: quem aplica precisa ter a ordem.

A prévia fica vinculada ao administrador, ao site, à conta, ao usuário Pipedrive e à revisão do Core. A aplicação revalida a autorização e relê o estado; se o registro mudou, devolve `estado_alterado`. O fornecedor não oferece compare-and-swap: uma alteração de terceiros entre a última leitura e a escrita não é detectável.

A exclusão não é desfeita por este plugin. Confira na conta a lixeira e o prazo de recuperação antes de excluir. Excluir campo ou opção destrói valores.

## Fora do escopo

Criação livre de registros, merge, exclusão em massa, webhooks, caixa de e-mail, arquivos, usuários, cobrança e escrita em funis, etapas e tipos de atividade. Envio de WhatsApp. Agendamento: a fila é calculada sob demanda e não há cron. Endpoints v2 de campos não são usados.
