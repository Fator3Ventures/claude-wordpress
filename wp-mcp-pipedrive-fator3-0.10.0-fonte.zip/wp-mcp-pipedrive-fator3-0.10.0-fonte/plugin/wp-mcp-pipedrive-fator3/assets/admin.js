(() => {
  'use strict';
  const root=document.querySelector('.f3pd');if(!root)return;
  const editor=root.querySelector('.f3pd-editor');
  let dirty=false;
  const count = el => { if(el.tagName==='TEXTAREA' && el.maxLength===4000) el.nextElementSibling.textContent=Array.from(el.value).length+' / 4.000 caracteres'; };
  if(editor){
    editor.querySelectorAll('.f3pd-row textarea').forEach(count);
    editor.addEventListener('input',e=>{dirty=true;count(e.target);const box=e.target.closest('section');if(box?.id){const nav=editor.querySelector('[href="#'+box.id+'"]');if(nav && !nav.classList.contains('is-changed')){nav.classList.add('is-changed');nav.append(' · alterado');}}});
    editor.addEventListener('submit',()=>dirty=false);
    window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
    const fallback=editor.querySelector('.f3pd-add-server');if(fallback)fallback.hidden=true;
    editor.querySelectorAll('[data-rows]').forEach(group=>{
      const add=group.querySelector('.f3pd-add');add.hidden=false;
      add.addEventListener('click',()=>{
        const n=group.querySelectorAll('.f3pd-row').length;if(n>=50){add.disabled=true;return;}
        const row=group.querySelector('template').content.firstElementChild.cloneNode(true);
        row.querySelector('legend span').textContent=n+1;
        for(const el of row.querySelectorAll('[name],[id],[for]'))for(const k of ['name','id','for'])if(el.hasAttribute(k))el.setAttribute(k,el.getAttribute(k).replace('[999]','['+n+']').replace('-999-','-'+n+'-'));
        group.insertBefore(row,add);row.querySelectorAll('textarea').forEach(count);row.querySelector('input')?.focus();
      });
    });
  }
  root.querySelectorAll('[data-expira]').forEach(el=>{
    const tick=()=>{const left=Math.max(0,Number(el.dataset.expira)-Math.floor(Date.now()/1000));el.textContent=left?'('+Math.floor(left/60)+' min '+String(left%60).padStart(2,'0')+' s restantes)':'(expirada)';return left;};
    if(tick()){const timer=setInterval(()=>{if(!tick())clearInterval(timer);},1000);}
  });
  root.querySelectorAll('.f3pd-copy').forEach(btn=>{if(navigator.clipboard){btn.hidden=false;btn.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(btn.previousElementSibling.textContent);btn.textContent='Frase copiada';}catch{btn.textContent='Selecione e copie a frase acima';}});}});
})();
