<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Bounded request-scoped reader. All supplier transport and budget belong to Core. */
final class Collection {
    public array $status;public int $calls=0,$rows=0;public array $issues=[];private float $began;private int $max,$seconds;
    public function __construct(array $i=[]){$this->status=CoreClient::status();$this->began=microtime(true);$this->max=$i['max_chamadas']??100;$this->seconds=$i['tempo_maximo_segundos']??45;}
    public function request(string $path,array $q=[]): array {
        if($this->calls>=$this->max||microtime(true)-$this->began>$this->seconds)throw new Fault('limite_de_coleta','Limite de chamadas ou tempo atingido.');
        Policy::route('GET',$path,$q);++$this->calls;$r=CoreClient::request('GET',$path,$q,[],$this->status);
        if(!$r['success'])throw new Fault($r['code'],$r['message']);
        $b=$r['data']['body'];if(!is_array($b)||!array_key_exists('data',$b))throw new Fault('resposta_incompleta','Resposta sem dados.');return $b;
    }
    /** A successful GET for another record is not a usable precondition for a write. */
    public static function record($record,string $expected): array {
        if(!is_array($record)||array_is_list($record)||(!is_int($record['id']??null)&&!is_string($record['id']??null))||strcasecmp((string)$record['id'],$expected)!==0)throw new Fault('estado_incompleto','A resposta não confirmou a identidade do registro solicitado.');
        return $record;
    }
    public function one(string $path): array {return self::record($this->request($path)['data'],basename($path));}
    private static function rowIdentity(mixed $row, string $path): string {
        if (!is_array($row)) throw new Fault('resposta_incompleta','Registro inválido.');
        $catalog=in_array($path,['/v1/dealFields','/v1/personFields','/v1/organizationFields','/v1/activityFields','/v1/noteFields'],true);
        $key=$row['id']??($catalog?($row['key']??null):null);
        if ($key===null) throw new Fault('resposta_incompleta','Registro sem identidade.');
        if (!is_int($key)&&!is_string($key)) throw new Fault('identidade_ilegivel','Identidade fora do contrato.');
        $id=(string)$key;
        if (str_starts_with($path,'/v1/leads')) {
            if (!preg_match('/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/iD',$id)) throw new Fault('identidade_ilegivel','Identidade fora do contrato.');
            return strtolower($id);
        }
        if (str_starts_with($path,'/api/v2/') && (!ctype_digit($id)||(int)$id<1||(string)(int)$id!==$id)) {
            throw new Fault('identidade_ilegivel','Identidade fora do contrato.');
        }
        if ($id==='') throw new Fault('identidade_ilegivel','Identidade fora do contrato.');
        return $id;
    }
    /** One validated page; retries only an oversized GET, at the same position. */
    public function page(string $path,array $query): array {
        $v2=str_starts_with($path,'/api/v2/');
        do {
            try {$body=$this->request($path,$query);break;}
            catch(Fault $e) {
                if($e->reason!=='resposta_excedeu_limite'||$query['limit']<=1)throw $e;
                $query['limit']=max(1,intdiv($query['limit'],2));
            }
        } while(true);
        $rows=$body['data'];$meta=$body['additional_data']??null;
        if(!is_array($rows)||!array_is_list($rows)||count($rows)>$query['limit']||!is_array($meta))throw new Fault('resposta_incompleta','Página de registros inválida.');
        $seen=[];
        foreach($rows as $row) {
            $id=self::rowIdentity($row,$path);
            if(isset($seen[$id]))throw new Fault('colecao_concorrente','Identificador repetido na página.');
            if(++$this->rows>12000)throw new Fault('limite_de_coleta','Limite de registros por leitura atingido.');
            $seen[$id]=true;
        }
        if($v2) {
            if(!array_key_exists('next_cursor',$meta))throw new Fault('paginacao_incompleta','Fonte não declarou o fim do cursor.');
            $next=$meta['next_cursor'];if($next==='')$next=null;
            if($next!==null&&(!is_string($next)||$next===($query['cursor']??null)))throw new Fault('paginacao_incompleta','Cursor inválido.');
        } else {
            $p=$meta['pagination']??null;
            if(!is_bool($p['more_items_in_collection']??null))throw new Fault('paginacao_incompleta','Fonte não declarou o fim da página.');
            $next=$p['more_items_in_collection']?($p['next_start']??false):null;
            if($next!==null&&(!is_int($next)||$next!==$query['start']+count($rows)))throw new Fault('paginacao_incompleta','A posição de continuação deixaria lacunas.');
        }
        if($next!==null&&!$rows)throw new Fault('paginacao_incompleta','Página vazia com continuação.');
        return ['rows'=>$rows,'next'=>$next,'limit'=>$query['limit']];
    }
    public function remainingCalls(): int {return max(0,$this->max-$this->calls);}
    public function hasTime(): bool {return microtime(true)-$this->began<$this->seconds;}
    public function all(string $path,array $query=[]): array {
        $out=[];$seen=[];$cursors=[];$v2=str_starts_with($path,'/api/v2/');$q=$query+['limit'=>100];if(!$v2)$q['start']=0;
        try {do{
            $b=$this->request($path,$q);$rows=$b['data']??[];
            if(!is_array($rows)||!array_is_list($rows))throw new Fault('resposta_incompleta','Coleção inválida.');
            foreach($rows as $row){$id=self::rowIdentity($row,$path);if(isset($seen[$id]))throw new Fault('colecao_concorrente','Identificador repetido durante paginação.');$seen[$id]=true;if(++$this->rows>12000)throw new Fault('limite_de_coleta','Limite de registros.');$out[]=$row;}
            $a=$b['additional_data']??[];if(!is_array($a))throw new Fault('paginacao_incompleta','Metadados de paginação inválidos.');
            if($v2){if(!array_key_exists('next_cursor',$a))throw new Fault('paginacao_incompleta','Cursor final ausente.');$next=$a['next_cursor'];$more=$next!==null&&$next!=='';if($more&&(!is_string($next)||isset($cursors[$next])))throw new Fault('paginacao_incompleta','Cursor inválido ou repetido.');if($more){$cursors[$next]=true;$q['cursor']=$next;}}
            else{$p=$a['pagination']??[];if(!is_bool($p['more_items_in_collection']??null))throw new Fault('paginacao_incompleta','Fim de paginação não declarado.');$more=$p['more_items_in_collection'];$next=$p['next_start']??null;if($more&&(!is_int($next)||$next<=$q['start']))throw new Fault('paginacao_incompleta','Offset inválido.');if($more)$q['start']=$next;}
            if($more&&!$rows)throw new Fault('paginacao_incompleta','Página vazia com continuação.');
        }while($more);}catch(Fault $e){$this->issues[]=$e->reason;}
        return $out;
    }
    public function complete(): void {if($this->issues)throw new Fault('coleta_incompleta','A escrita exige leitura completa.',['motivos'=>array_values(array_unique($this->issues))]);}
    public function result(array $data): array {
        $spent=null;try{$end=CoreClient::status();if(!hash_equals(CoreClient::binding($end),CoreClient::binding($this->status)))$this->issues[]='contexto_alterado';$spent=max(0,$end['orcamento']['consumido']-$this->status['orcamento']['consumido']);}catch(Fault $e){$this->issues[]=$e->reason;}
        return ['success'=>true,'code'=>$this->issues?'coleta_parcial':'ok','message'=>'Leitura concluída; confira cobertura e custo.','data'=>$data+['coleta_completa'=>!$this->issues,'motivos'=>array_values(array_unique($this->issues)), 'custo'=>['consumidor'=>'operacao','chamadas'=>$this->calls,'estimativa_unidades'=>$this->calls*20,'gasto_observado'=>$spent], 'cobertura'=>'Registros visíveis à credencial Core; paginação não constitui snapshot transacional.']];
    }
    public static function field(array $r,string $key){return $r[$key]??$r['custom_fields'][$key]??null;}
    public static function instant($v): ?int {if(!is_string($v)||!preg_match('/^\d{4}-\d\d-\d\d[ T]\d\d:\d\d(?::\d\d(?:\.\d{1,6})?)?(?:Z|[+-]\d\d:\d\d)?$/D',$v))return null;try{$date=new \DateTimeImmutable($v,new \DateTimeZone('UTC'));$errors=\DateTimeImmutable::getLastErrors();return $errors&&($errors['warning_count']||$errors['error_count'])?null:$date->getTimestamp();}catch(\Throwable $e){return null;}}
}
