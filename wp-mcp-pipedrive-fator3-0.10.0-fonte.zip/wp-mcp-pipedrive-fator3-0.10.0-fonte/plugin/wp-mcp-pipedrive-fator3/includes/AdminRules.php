<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Forms only translate input. The same domain validation, account binding and receipts serve MCP and wp-admin. */
final class AdminRules {
    private const DAYS=[1=>'Segunda',2=>'Terça',3=>'Quarta',4=>'Quinta',5=>'Sexta',6=>'Sábado',7=>'Domingo'];
    private const GROUPS=['habilitada'=>'Ativação','fuso'=>'Fuso horário','dias'=>'Dias da semana','janela'=>'Janela diária','periodos'=>'Períodos','feriados'=>'Feriados','tipo_whatsapp'=>'Tipo de atividade','archive_reasons'=>'Motivos de arquivamento','lost_reasons'=>'Motivos de perda','toques'=>'Toques','textos'=>'Textos aprovados','exclusoes'=>'Exclusões','auditoria'=>'Auditoria','nota'=>'Formato da nota','variaveis'=>'Variáveis','canais'=>'Canais','espera_entrega'=>'Espera de entrega','adocao'=>'Adoção de histórico'];
    private const ADVANCED=['exclusoes','auditoria','nota','variaveis','canais','espera_entrega','adocao'];
    public static function post(string $action,array $post): array {
        $mode=Admin::text($post,'modo')==='json'?'json':'guiado';
        $saved=Configuration::read();
        $data=array_diff_key(wp_unslash($post),array_flip(['_wpnonce','_wp_http_referer','f3pd_tentativa']));
        if(strlen(Support::json($data))>180000)throw new Fault('entrada_excessiva','O formulário excedeu o limite de edição. Reduza a entrada.');
        foreach(['textos','toques'] as $group)if(array_key_exists($group,$post))self::rows($post,$group);
        $state=['form'=>$data,'mode'=>$mode];
        try{
            if($action==='rules_apply'){
                $id=Admin::text($post,'previa_id');
                if(!preg_match('/^[a-f0-9]{32}$/D',$id))throw new Fault('previa_invalida','Identificador de prévia inválido.');
                if(Admin::text($post,'ordem')!=='1')return ['message'=>'Confirme que recebeu a ordem do dono para esta prévia.','preview'=>$id,'mode'=>$mode];
                $r=Workflows::applySettings(['previa_id'=>$id]);return ['ok'=>$r['success'],'message'=>$r['message']];
            }
            if(!hash_equals($saved['revisao'],Admin::text($post,'revisao_esperada')))throw new Fault('revisao_conflitante','As regras mudaram depois que você abriu a tela. Recarregue as regras atuais e revise as diferenças.');
            if($action==='rules_rows')return ['ok'=>true,'message'=>'Linhas disponíveis para as próximas etapas e textos.','extra'=>true]+$state;
            if($action==='rules_catalog'){
                $status=CoreClient::status();$options=[];
                foreach(['tipo_whatsapp'=>'/v1/activityTypes','etiqueta_id'=>'/v1/leadLabels','campo'=>'/v1/dealFields'] as $name=>$path){
                    $q=$name==='campo'?['start'=>0,'limit'=>100]:[];Policy::route('GET',$path,$q);$r=CoreClient::request('GET',$path,$q,[],$status);
                    if(!$r['success'])throw new Fault('catalogo_indisponivel',$r['message']);
                    $rows=$r['data']['body']['data']??null;if(!is_array($rows)||!array_is_list($rows))throw new Fault('catalogo_indisponivel','Catálogo ilegível. Os dados digitados foram preservados.');
                    foreach(array_slice($rows,0,100) as $row){$value=$row[$name==='tipo_whatsapp'?'key_string':($name==='campo'?'key':'id')]??null;if(is_scalar($value))$options[$name][(string)$value]=mb_substr((string)($row['name']??$value),0,180);}
                }
                return ['ok'=>true,'message'=>'Catálogos consultados: até 100 itens por lista. Os dados da conta aparecem como sugestões, sem mudar suas regras.','options'=>$options,'binding'=>CoreClient::binding($status)]+$state;
            }
            $candidate=self::candidate($post,$saved['regras'],$mode);
            if($action==='rules_validate')return ['ok'=>true,'message'=>'Campos válidos. Nenhuma regra salva. O próximo passo é simular na conta.']+$state;
            $r=Api::dispatch('configuracao-simular',['regras'=>$candidate,'revisao_esperada'=>$saved['revisao']]);
            if(!$r['success'])return ['message'=>$r['message']]+$state;
            if($r['code']!=='simulacao_criada')return ['message'=>'Coleta incompleta. Nenhuma prévia aplicável foi criada. Motivos: '.implode(', ',$r['data']['motivos']??[]).'.']+$state;
            $d=$r['data'];$sim=$d['simulacao'];$rows=$sim['itens']??[];
            return ['preview'=>$d['previa_id'],'sample'=>['avaliados'=>$sim['avaliados']??count($rows),'devidos'=>$sim['devidos']??count(array_filter($rows,static fn($row)=>!empty($row['devido']))),'custo'=>$sim['custo']??[],'amostra'=>!empty($sim['amostra'])||isset($sim['fim_da_fila'])&&!$sim['fim_da_fila']]]+$state;
        }catch(Fault $e){return ['message'=>$e->getMessage()]+$state;}
    }
    public static function render(array $state=[]): void {
        Support::admin();$response=Api::dispatch('configuracao-ler');
        if(!$response['success']){Admin::notice($response['message']);return;}
        $saved=$response['data'];$form=wp_slash($state['form']??[]);$posted=array_key_exists('revisao_esperada',$form);
        $mode=($state['mode']??Admin::text($_GET,'modo'))==='json'?'json':'guiado';
        if(isset($state['preview'])){
            try{self::confirmation(self::retryReview($state['preview'],$saved['revisao']),$saved['regras'],$mode,$state['sample']??null);}
            catch(Fault $e){Admin::notice($e->getMessage());}
        }
        echo '<section class="f3pd-panel"><p class="f3pd-overline">Configuração · 1 de 3</p><h2>Regras de operação</h2><p>Defina quando um lead pode receber o próximo contato e quais textos o operador pode usar. O plugin registra mensagens já enviadas; habilitar a cadência não envia WhatsApp.</p>';
        echo '<dl class="f3pd-facts">';foreach(['Regras em vigor'=>$saved['origem']==='configurado'?'Configuração salva':'Padrão inicial','Cadência'=>$saved['regras']['habilitada']?'Habilitada':'Desligada','Toques configurados'=>count($saved['regras']['toques'])] as $k=>$v)echo '<div><dt>'.esc_html($k).'</dt><dd>'.esc_html((string)$v).'</dd></div>';echo '</dl></section>';
        echo '<form class="f3pd-editor" method="post" action="'.esc_url(Admin::url('regras',['modo'=>$mode])).'">';AdminForms::fields('f3pd_rules_edit');
        $revision=$posted?Admin::text($form,'revisao_esperada'):$saved['revisao'];
        echo '<input type="hidden" name="modo" value="'.esc_attr($mode).'"><input type="hidden" name="revisao_esperada" value="'.esc_attr($revision).'">';
        if($mode==='json'){
            $default=wp_json_encode($saved['regras'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            echo '<section class="f3pd-panel"><h2>Configuração completa</h2><p>Edite a configuração integral. Omitir um grupo opcional o remove quando a prévia é confirmada.</p>';
            self::area('regras_json','Objeto de regras',$posted?Admin::text($form,'regras_json'):$default,'JSON completo, até 64 KiB após validação. Não inclua tokens nem dados de clientes.',18,true);
            echo '<a href="'.esc_url(Admin::url('regras')).'">Voltar ao editor guiado</a></section>';
        }else{
            $options=[];if(isset($state['binding']))try{if(hash_equals($state['binding'],CoreClient::binding(CoreClient::status())))$options=$state['options']??[];}catch(Fault){}
            self::guided($saved['regras'],$form,$posted,$options,!empty($state['extra']));
        }
        echo '<input type="hidden" name="form_completo" value="1"><section class="f3pd-panel f3pd-toolbar"><p><strong>Revisar alterações</strong> · Validar não consulta a conta. Simular usa o orçamento do Site Core (20 unidades estimadas por leitura) e cria uma prévia válida por 15 minutos.</p><div class="f3pd-actions"><button class="button button-secondary" name="f3_pipedrive_action" value="rules_validate">Validar campos</button><button class="button button-primary" name="f3_pipedrive_action" value="rules_simulate">Simular na conta</button><a href="'.esc_url(Admin::url('regras',['modo'=>$mode])).'">Recarregar regras atuais</a></div></section></form>';
    }
    private static function lines(string $text): array {
        return array_values(array_filter(array_map('trim',preg_split('/\R/u',$text)?:[]),static fn($v)=>$v!==''));
    }
    public static function candidate(array $post,array $current,string $mode): array {
        if(Admin::text($post,'form_completo')!=='1')throw new Fault('formulario_incompleto','O formulário chegou incompleto. Recarregue a página.');
        if($mode==='json'){
            $text=Admin::text($post,'regras_json');if(strlen($text)>131072)throw new Fault('configuracao_invalida','O texto JSON excedeu 128 KiB. O objeto de regras deve caber em 64 KiB.');
            try{$decoded=json_decode($text,false,64,JSON_THROW_ON_ERROR);if(!$decoded instanceof \stdClass)throw new \JsonException();$v=json_decode($text,true,64,JSON_THROW_ON_ERROR);}catch(\JsonException $e){throw new Fault('json_invalido','Informe um objeto JSON válido. Confira aspas, vírgulas e chaves.');}
        }else{
            foreach(['fuso','inicio','fim','periodos','feriados','tipo_whatsapp','archive_reasons','lost_reasons'] as $key)if(!isset($post[$key])||!is_string($post[$key]))throw new Fault('formulario_incompleto','Um campo do formulário está ausente ou inválido. Recarregue a página.');
            $v=$current;$v['habilitada']=Admin::text($post,'habilitada')==='1';$v['fuso']=trim(Admin::text($post,'fuso'));
            $days=$post['dias']??[];if(!is_array($days)||!array_is_list($days))throw new Fault('configuracao_invalida','Seleção de dias inválida.');
            $v['dias']=[];foreach($days as $day){if(!is_string($day)||!preg_match('/^[1-7]$/D',$day))throw new Fault('configuracao_invalida','Dia da semana inválido.');$v['dias'][]=(int)$day;}
            $v['janela']=['inicio'=>Admin::text($post,'inicio'),'fim'=>Admin::text($post,'fim')];$v['tipo_whatsapp']=trim(Admin::text($post,'tipo_whatsapp'));
            $v['periodos']=[];foreach(self::lines(Admin::text($post,'periodos')) as $line){if(!preg_match('/^([a-z0-9_-]{1,40})\s+([0-2][0-9]:[0-5][0-9])$/D',$line,$m))throw new Fault('configuracao_invalida','Em Períodos, use um código e um horário por linha, como manha 09:30.');$v['periodos'][]=['codigo'=>$m[1],'hora'=>$m[2]];}
            $holidays=self::lines(Admin::text($post,'feriados'));if($holidays||array_key_exists('feriados',$v))$v['feriados']=$holidays;
            foreach(['archive_reasons','lost_reasons'] as $key)$v[$key]=self::lines(Admin::text($post,$key));
            if(array_key_exists('textos',$post)){
                $v['textos']=[];foreach(self::rows($post,'textos') as $row){
                    $code=trim($row['codigo']??'');$txt=$row['texto']??'';
                    if(($row['remover']??'')==='1'||$code===''&&$txt==='')continue;
                    if($code===''||trim($txt)==='')throw new Fault('texto_invalido','Em Textos aprovados, indique o código e a mensagem de cada linha.');
                    $v['textos'][]=['codigo'=>$code,'texto'=>$txt];
                }
            }
            if(array_key_exists('toques',$post)){
                $old=array_column($current['toques'],null,'codigo');
                $v['toques']=[];foreach(self::rows($post,'toques') as $row){
                    if(($row['remover']??'')==='1')continue;
                    $code=trim($row['codigo']??'');$text=trim($row['texto_id']??'');$delay=trim($row['atraso_minutos']??'');$label=trim($row['etiqueta_id']??'');$orig=$row['original']??'';
                    if($code===''&&$text===''&&$delay===''&&$label===''&&$orig==='')continue;
                    if($code===''||$text===''||!ctype_digit($delay)||strlen($delay)>6)throw new Fault('toque_invalido','Em Sequência de toques, informe código, código do texto aprovado e espera em minutos (use 0 para imediato).');
                    $v['toques'][]=['codigo'=>$code,'texto_id'=>$text,'atraso_minutos'=>(int)$delay,'base'=>$row['base']??'','etiqueta_id'=>$label]+($old[$orig]??[]);
                }
            }
            foreach(self::ADVANCED as $k){
                if(!array_key_exists('grupo_'.$k,$post))continue;
                $json=trim(Admin::text($post,'grupo_'.$k));
                if($json===''&&!in_array($k,['auditoria','exclusoes'],true)){unset($v[$k]);continue;}
                try{$obj=json_decode($json,true,64,JSON_THROW_ON_ERROR);if(!is_array($obj))throw new \JsonException();$v[$k]=$obj;}catch(\JsonException){throw new Fault('json_invalido','Confira o JSON do grupo '.self::GROUPS[$k].'.');}
            }
        }
        return Configuration::validate($v);
    }
    private static function guided(array $c,array $form,bool $posted,array $options,bool $extra): void {
        $v=static fn($key,$fallback)=>$posted?Admin::text($form,$key):$fallback;
        echo '<nav class="f3pd-group-nav" aria-label="Grupos de regras">';foreach(['calendario'=>'Calendário','sequencia'=>'Toques e textos','motivos'=>'Motivos','avancado'=>'Avançado'] as $id=>$label)echo '<a href="#f3pd-'.esc_attr($id).'">'.esc_html($label).'</a>';echo '</nav>';
        echo '<section class="f3pd-panel" id="f3pd-calendario"><h2>Cadência e calendário</h2><p>Os horários abaixo seguem o fuso escolhido. Escolha os dias e períodos nos quais o operador pode agir.</p>';
        $enabled=$posted?Admin::text($form,'habilitada')==='1':$c['habilitada'];
        echo '<p><label><input type="checkbox" name="habilitada" value="1" '.checked($enabled,true,false).' aria-describedby="f3pd-enable-help"> Habilitar cadência</label></p><p id="f3pd-enable-help" class="description">Para habilitar, configure dias, períodos, tipo de atividade e ao menos um toque com texto aprovado. Complete a seção Toques e textos abaixo.</p><div class="f3pd-grid">';
        self::field('fuso','Fuso horário',$v('fuso',$c['fuso']),'Exemplo: America/Sao_Paulo ou UTC.');self::field('tipo_whatsapp','Tipo de atividade WhatsApp',$v('tipo_whatsapp',$c['tipo_whatsapp']),'Código do tipo de atividade na conta Pipedrive.');echo '</div><p><button class="button" name="f3_pipedrive_action" value="rules_catalog" formnovalidate>Consultar tipos, etiquetas e campos na conta</button> <span class="description">Até 3 leituras (60 unidades estimadas).</span></p>';
        foreach($options as $name=>$list){echo '<datalist id="f3pd-list-'.esc_attr($name).'">';foreach($list as $val=>$label)echo '<option value="'.esc_attr((string)$val).'">'.esc_html($label).'</option>';echo '</datalist>';}
        if(!empty($options['campo'])){echo '<details><summary>Chaves de campos da conta</summary><ul>';foreach($options['campo'] as $k=>$nomeCampo)echo '<li>'.esc_html($nomeCampo).' · <code>'.esc_html((string)$k).'</code></li>';echo '</ul></details>';}
        echo '<fieldset><legend>Dias úteis da cadência</legend><div class="f3pd-week">';$days=$posted?(is_array($form['dias']??null)?$form['dias']:[]):array_map('strval',$c['dias']);foreach(self::DAYS as $n=>$label)echo '<label><input type="checkbox" name="dias[]" value="'.(int)$n.'" '.checked(in_array((string)$n,$days,true),true,false).'> '.esc_html($label).'</label>';echo '</div></fieldset><div class="f3pd-grid">';
        self::field('inicio','Início da janela',$v('inicio',$c['janela']['inicio']),'Hora local de início.','time');self::field('fim','Fim da janela',$v('fim',$c['janela']['fim']),'No mesmo dia, após o início.','time');echo '</div><div class="f3pd-grid">';
        self::area('periodos','Períodos',$v('periodos',implode("\n",array_map(static fn($p)=>$p['codigo'].' '.$p['hora'],$c['periodos']))),'Um código e um horário por linha. Exemplo: manha 09:30.',4);
        self::area('feriados','Feriados',$v('feriados',implode("\n",$c['feriados']??[])),'Uma data por linha, no formato AAAA-MM-DD. Esses dias ficam fora da cadência.',4);echo '</div></section>';
        self::sequence($c,$form,$posted,$extra);
        echo '<section class="f3pd-panel" id="f3pd-motivos"><h2>Motivos permitidos</h2><p>Use um motivo por linha, como deve aparecer na conta. Somente motivos presentes na lista podem ser usados pelo fluxo correspondente.</p><div class="f3pd-grid">';
        self::area('archive_reasons','Arquivamento de leads',$v('archive_reasons',implode("\n",$c['archive_reasons'])),'Usados ao concluir e arquivar um lead.',5);self::area('lost_reasons','Perda de negócios',$v('lost_reasons',implode("\n",$c['lost_reasons'])),'Uma lista vazia impede registrar perda por este fluxo.',5);echo '</div></section>';
        echo '<section class="f3pd-panel" id="f3pd-avancado"><details><summary>Regras avançadas por grupo</summary><p>Para políticas de exclusão, auditoria e condições especiais, edite o JSON apenas do grupo necessário. Um grupo opcional vazio permanece ausente.</p>';
        foreach(self::ADVANCED as $k){
            $value=$posted?Admin::text($form,'grupo_'.$k):(isset($c[$k])?wp_json_encode($c[$k],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT):'');
            self::area('grupo_'.$k,self::GROUPS[$k],$value,'Formato do grupo no guia de contratos.',3,true);
        }
        echo '</details><p><a href="'.esc_url(Admin::url('regras',['modo'=>'json'])).'">Configuração completa (JSON)</a> · <a href="'.esc_url(Admin::url('ajuda',['documento'=>'fluxos'])).'">Consultar formatos e exemplos</a></p></section>';
    }
    /** Blank new rows are ignored. Existing variant/prazo/acao fields are retained by original code. */
    private static function rows(array $source,string $key): array {
        $rows=$source[$key]??[];if(!is_array($rows)||count($rows)>51)throw new Fault('formulario_invalido','Limite de 50 linhas por lista.');
        $clean=[];
        foreach($rows as $row){
            if(!is_array($row)||array_filter($row,static fn($v)=>!is_string($v)))throw new Fault('formulario_invalido','Linha de sequência inválida.');
            $clean[]=array_map('wp_unslash',$row);
        }
        return $clean;
    }
    private static function sequence(array $c,array $form,bool $posted,bool $extra): void {
        echo '<section class="f3pd-panel" id="f3pd-sequencia"><h2>Toques e textos</h2><p>Cadastre um texto com código próprio, por exemplo <code>boas_vindas</code>. Em cada toque, informe esse código e quando a etapa deve ocorrer. A ordem das linhas define a sequência.</p>';
        foreach(['textos'=>'Textos aprovados','toques'=>'Sequência de toques'] as $key=>$title){
            $rows=$posted&&isset($form[$key])?self::rows($form,$key):$c[$key];
            if(!$rows||$extra||!$posted||!empty(end($rows)['codigo'])){if(count($rows)<50)$rows[]=[];}
            echo '<div data-rows="'.esc_attr($key).'"><h3>'.esc_html($title).'</h3>';
            foreach($rows as $n=>$row)self::row($key,$n,$row);
            echo '<template>';self::row($key,999,[]);echo '</template><button type="button" class="button f3pd-add" hidden>Adicionar '.($key==='textos'?'texto':'toque').'</button></div>';
        }
        echo '<button class="button f3pd-add-server" name="f3_pipedrive_action" value="rules_rows" formnovalidate>Adicionar linhas para edição</button></section>';
    }
    private static function row(string $key,int $n,array $row):void {
        $prefix=$key.'['.$n.']';$id='f3pd-'.$key.'-'.$n.'-';
        echo '<fieldset class="f3pd-row"><legend>'.($key==='toques'?'Toque':'Texto').' <span>'.($n+1).'</span></legend><div class="f3pd-grid">';
        $string=static function($k,$label,$type='text',$extra='')use($row,$id,$prefix){
            $v=(string)($row[$k]??'');$tag=$id.$k;
            echo '<label for="'.esc_attr($tag).'">'.esc_html($label).'<input id="'.esc_attr($tag).'" type="'.esc_attr($type).'" name="'.esc_attr($prefix.'['.$k.']').'" value="'.esc_attr($v).'" '.$extra.'></label>';
        };
        $string('codigo','Código '.($key==='toques'?'do toque':'do texto'),'text','maxlength="40"');
        if($key==='textos'){
            echo '<label for="'.esc_attr($id.'texto').'">Mensagem aprovada<textarea id="'.esc_attr($id.'texto').'" rows="3" maxlength="4000" name="'.esc_attr($prefix.'[texto]').'">'.esc_textarea((string)($row['texto']??'')).'</textarea><small aria-hidden="true" class="f3pd-count"></small></label>';
        }else{
            $string('texto_id','Código do texto aprovado','text','maxlength="40"');$string('atraso_minutos','Espera em minutos','number','min="0" max="525600"');
            echo '<label>Contar a partir de<select name="'.esc_attr($prefix.'[base]').'">';foreach(['entrada'=>'Entrada do lead','ultimo_registro'=>'Último registro'] as $k=>$v)echo '<option value="'.$k.'" '.selected($row['base']??'entrada',$k,false).'>'.esc_html($v).'</option>';echo '</select></label>';
            $string('etiqueta_id','Etiqueta (opcional)','text','list="f3pd-list-etiqueta_id" maxlength="36"');
            echo '<input type="hidden" name="'.esc_attr($prefix.'[original]').'" value="'.esc_attr((string)($row['original']??$row['codigo']??'')).'">';
        }
        echo '</div><label><input type="checkbox" name="'.esc_attr($prefix.'[remover]').'" value="1" '.checked(($row['remover']??'')==='1',true,false).'> Remover esta linha ao aplicar</label></fieldset>';
    }
    private static function field(string $name,string $label,string $value,string $help,string $type='text'): void {
        echo '<div class="f3pd-field"><label class="f3pd-label" for="f3pd-'.esc_attr($name).'">'.esc_html($label).'</label><input type="'.esc_attr($type).'" id="f3pd-'.esc_attr($name).'" name="'.esc_attr($name).'" value="'.esc_attr($value).'" '.($name==='tipo_whatsapp'?'list="f3pd-list-tipo_whatsapp"':'').' aria-describedby="f3pd-'.esc_attr($name).'-help"><p class="description" id="f3pd-'.esc_attr($name).'-help">'.esc_html($help).'</p></div>';
    }
    private static function area(string $name,string $label,string $value,string $help,int $rows,bool $code=false): void {
        echo '<div class="f3pd-field"><label class="f3pd-label" for="f3pd-'.esc_attr($name).'">'.esc_html($label).'</label><textarea id="f3pd-'.esc_attr($name).'" name="'.esc_attr($name).'" rows="'.$rows.'" class="'.($code?'f3pd-code':'').'" aria-describedby="f3pd-'.esc_attr($name).'-help">'.esc_textarea($value).'</textarea><p class="description" id="f3pd-'.esc_attr($name).'-help">'.esc_html($help).'</p></div>';
    }
    /** Recover only the current actor's unclaimed config preview; never simulate or revive it. */
    private static function retryReview(string $id,string $revision): array {
        $row=Store::get($id); // Includes actor check.
        if($row['state']==='running')throw new Fault('resultado_incerto','Esta prévia já foi iniciada. Confira o diário antes de tentar novamente.');
        if($row['state']!=='ready' || (int)$row['expires']<=time())throw new Fault('previa_indisponivel','Esta prévia não está disponível para correção. Consulte o diário antes de iniciar outra simulação.');
        $p=Support::open($row['payload']);
        if(($p['workflow']??null)!=='configuracao')throw new Fault('operacao_invalida','A tela de regras aceita somente uma prévia de configuração.');
        if(!hash_equals($revision,$p['config_revision']))throw new Fault('revisao_conflitante','As regras mudaram. Recarregue a configuração atual e simule novamente.');
        if(!hash_equals($row['binding'],CoreClient::binding(CoreClient::status())))throw new Fault('contexto_alterado','A conta ou autorização mudou. Confira a conexão antes de simular novamente.');
        return ['previa_id'=>$id,'confirmacao_exigida'=>$p['confirmacao'],'regras'=>$p['input'],'expira'=>$row['expires']];
    }
    private static function confirmation(array $review,array $old,string $mode,?array $sample): void {
        echo '<section class="f3pd-panel f3pd-confirm"><p class="f3pd-overline">Configuração · 2 de 3</p><h2>Revisar prévia antes de aplicar</h2>';
        if($sample!==null){
            echo '<p>'.($sample['amostra']?'A simulação cobriu uma amostra. Os números abaixo valem apenas para os leads avaliados.':'O cálculo abaixo descreve a cobertura observada nesta simulação.').'</p><dl class="f3pd-facts">';
            foreach(['Leads avaliados'=>$sample['avaliados'],'Com ação devida'=>$sample['devidos'],'Custo estimado'=>($sample['custo']['estimativa_unidades']??0).' unidades','Leituras pelo Site Core'=>$sample['custo']['chamadas']??0] as $k=>$v)echo '<div><dt>'.esc_html($k).'</dt><dd>'.esc_html((string)$v).'</dd></div>';echo '</dl>';
        }
        echo '<p>Prévia válida até <time datetime="'.esc_attr(gmdate('c',(int)$review['expira'])).'">'.esc_html(wp_date('d/m/Y H:i:s T',(int)$review['expira'])).'</time> <span data-expira="'.(int)$review['expira'].'"></span>.</p><div class="f3pd-table" role="region" tabindex="0" aria-label="Comparação de regras"><table class="widefat striped"><thead><tr><th>Regra</th><th>Em vigor</th><th>Depois de aplicar</th></tr></thead><tbody>';
        $diff=false;foreach(self::GROUPS as $key=>$label){
            $was=$old[$key]??null;$will=$review['regras'][$key]??null;if(Support::digest($was)===Support::digest($will))continue;$diff=true;
            $display=static fn($v)=>$v===null?'Não configurado':(is_bool($v)?($v?'Habilitada':'Desligada'):(is_array($v)?wp_json_encode($v,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):(string)$v));
            echo '<tr><th scope="row">'.esc_html($label).'</th><td><pre>'.esc_html($display($was)).'</pre></td><td><pre>'.esc_html($display($will)).'</pre></td></tr>';
        }
        if(!$diff)echo '<tr><td colspan="3">Nenhuma diferença de conteúdo.</td></tr>';echo '</tbody></table></div>';
        echo '<h3>Aplicar estas regras · 3 de 3</h3><p>A aplicação salva as regras locais e altera os próximos cálculos da cadência. Não envia mensagem nem altera os leads no Pipedrive.</p><form method="post" action="'.esc_url(Admin::url('regras',['modo'=>$mode])).'">';
        AdminForms::fields('f3pd_apply_'.$review['previa_id']);
        echo '<input type="hidden" name="modo" value="'.esc_attr($mode).'"><input type="hidden" name="f3_pipedrive_action" value="rules_apply"><input type="hidden" name="previa_id" value="'.esc_attr($review['previa_id']).'"><p><label><input type="checkbox" name="ordem" value="1" required> Recebi a ordem do dono para aplicar estas regras.</label></p><div class="f3pd-actions"><button class="button button-primary">Aplicar regras simuladas</button><a href="'.esc_url(Admin::url('regras',['modo'=>$mode])).'">Voltar às regras em vigor</a></div></form><details><summary>Aplicar pelo MCP</summary><p>Para aplicar por operação remota, use a prévia e a frase literal. A confirmação no painel não dispensa essa exigência.</p><code class="f3pd-phrase">'.esc_html($review['confirmacao_exigida']).'</code><button class="button f3pd-copy" type="button" hidden>Copiar frase</button></details></section>';
    }
}
