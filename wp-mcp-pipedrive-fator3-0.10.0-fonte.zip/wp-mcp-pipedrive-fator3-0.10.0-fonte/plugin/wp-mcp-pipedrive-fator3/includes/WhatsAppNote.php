<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Edits reserved metadata across inline HTML without flattening the customer's history. */
final class WhatsAppNote {
    private const BREAK_TAG='~^<(?:br\b|/?(?:p|div|li|h[1-6]|blockquote|tr)\b)~i';
    private const OLD_DATE='(?:\d{2}/\d{2}(?:/\d{4})? \d{2}h\d{2}|\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}),';
    private static function escape(string $s):string{return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
    private static function line(string $s):string{return trim(preg_replace('/[\s\p{Z}]+/u',' ',$s)??'');}

    public static function validate(array $i):void {
        foreach(['proximo','mensagem','autor'] as $k){
            if($k==='autor'&&!isset($i[$k]))continue;
            if(!isset($i[$k])||self::line($i[$k])===''||($k!=='mensagem'&&preg_match('/[\r\n\p{Zl}\p{Zp}\x{0085}]/u',$i[$k]))){
                throw new Fault('entrada_invalida','Informe mensagem e proximo; o próximo passo e o nome do autor devem ocupar uma linha.');
            }
        }
    }
    /** Tokenize once. A logical line may contain several text tokens separated by inline markup. */
    private static function scan(string $html, bool $strip, array $prefixes=[]):array {
        $out=[];$rows=[];$parts=[];$visible='';$quoteDepth=0;
        $flush=static function()use(&$parts,&$visible,&$out,&$rows,$strip,$prefixes,&$quoteDepth):void{
            $line=self::line($visible);
            if($line!=='')$rows[]=$line;
            $cut=0;
            if($strip&&!$quoteDepth&&$line!==''){
                if(preg_match('/^[\s\p{Z}]*Próximo\s*:/iu',$visible))$cut=strlen($visible);
                else foreach($prefixes as $prefix){
                    $rx='~^[\s\p{Z}]*(?:'.preg_quote($prefix,'~').'[\s\p{Z}]*)+(?='.($prefix==='[IA]'?'$|':'').self::OLD_DATE.')~iu';
                    if(preg_match($rx,$visible,$m)){$cut=strlen($m[0]);break;}
                }
            }
            foreach($parts as [$index,$decoded]){
                if(!$cut)break;
                $n=min(strlen($decoded),$cut);
                if($n)$out[$index]=self::escape(substr($decoded,$n));
                $cut-=$n;
            }
            $parts=[];$visible='';
        };
        foreach(wp_html_split($html) as $i=>$token){
            if($i%2===1){
                if(preg_match(self::BREAK_TAG,$token))$flush();
                if(preg_match('~^<blockquote\b~i',$token))++$quoteDepth;
                elseif(preg_match('~^</blockquote\b~i',$token))$quoteDepth=max(0,$quoteDepth-1);
                $out[]=$token;continue;
            }
            foreach(preg_split('/(\r\n|\r|\n)/',$token,-1,PREG_SPLIT_DELIM_CAPTURE) as $j=>$part){
                if($j%2===1){$flush();$out[]=$part;continue;}
                if($part==='')continue;
                $decoded=html_entity_decode($part,ENT_QUOTES|ENT_HTML5,'UTF-8');
                $parts[]=[count($out),$decoded];$visible.=$decoded;$out[]=$part;
            }
        }
        $flush();return [implode('',$out),$rows];
    }
    public static function layoutDigest(string $note):string{
        return hash('sha256',Support::json(self::scan($note,false)[1]));
    }
    public static function compose(string $previous,array $input,int $at,array $rules):string{
        self::validate($input);
        $config=$rules['nota']??[];
        $prefixes=array_unique(array_filter(['[IA]',$config['prefixo']??''],static fn($x)=>$x!==''));
        // Remove our exact generated wrappers without leaving empty paragraphs on each touch.
        $header='<p>[IA]</p>';
        if(str_starts_with($previous,$header))$previous=substr($previous,strlen($header));
        $previous=preg_replace('~<p>Próximo: [^<>]*</p>\s*\z~u','',$previous)??$previous;
        [$history]=self::scan($previous,true,$prefixes);
        // Browsers collapse bare newlines in plain-text histories; keep their visual line boundaries.
        if(!preg_match('~<[a-z][^>]*>~i',$history))$history=str_replace(["\r\n","\r","\n"],['<br>','<br>','<br>'],$history);
        $stamp=Rules::local($at,$rules)->format('d/m H\hi');
        $author=self::line($input['autor']??($config['autor']??'nós'));
        return $header.$history.'<p>'.self::escape($stamp.', '.$author.': '.self::line($input['mensagem'])).'</p><p>Próximo: '.self::escape(self::line($input['proximo'])).'</p>';
    }
}
