<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

final class Insights {
    private const AUDIT_LIMIT = 1000;
    private const GROUP_LIMIT = 200;
    private array $findings = [], $unassessed = [], $stageDates = [];

    private function __construct(private readonly Collection $reader) {}

    private static function issue(Collection $reader, string $reason): void {
        if (!in_array($reason,$reader->issues,true)) $reader->issues[]=$reason;
    }

    /** Accept an ID, never an option label, boolean, float or overflowing integer. */
    private static function linkedId(mixed $value): ?int {
        if (is_array($value)) $value=$value['id']??$value['value']??null;
        if (is_int($value)) return $value>0?$value:null;
        if (!is_string($value)||!ctype_digit($value)) return null;
        $digits=ltrim($value,'0');
        $id=(int)$digits;
        return $id>0 && (string)$id===$digits ? $id : null;
    }

    private static function optionIds(mixed $value): ?array {
        $values=is_string($value)?explode(',',$value):(is_array($value)&&array_is_list($value)?$value:[$value]);
        $ids=[];
        foreach ($values as $option) {
            $id=self::linkedId(is_string($option)?trim($option):$option);
            if ($id===null) return null;
            $ids[$id]=true;
        }
        return array_keys($ids);
    }

    /** Retain the same first 200 lexical keys as a full sort, with fixed memory. */
    private static function countGroup(string $key, array &$groups, \SplPriorityQueue $largest, Collection $r): void {
        if (isset($groups[$key])) { ++$groups[$key]; return; }
        if (count($groups)>=self::GROUP_LIMIT) {
            self::issue($r,'limite_de_grupos');
            if (strcmp($key,$largest->top())>=0) return;
            unset($groups[$largest->extract()]);
        }
        $groups[$key]=1;
        $largest->insert($key,$key);
    }

    public static function count(array $i): array {
        $r=new Collection($i);
        $type=$i['entidade'];
        $field=$i['campo'];
        $map=['leads'=>['/v1/dealFields','/v1/leads','/v1/leads/archived'],'negocios'=>['/v1/dealFields','/api/v2/deals','/api/v2/deals/archived'],'pessoas'=>['/v1/personFields','/api/v2/persons'],'organizacoes'=>['/v1/organizationFields','/api/v2/organizations']];
        $paths=$map[$type];
        $catalog=$r->all(array_shift($paths));
        $r->complete();
        $found=null;
        foreach ($catalog as $f) {
            if (($f['key']??$f['field_code']??null)===$field) { $found=$f; break; }
        }
        if (!$found) throw new Fault('campo_indisponivel','Campo não encontrado no catálogo da entidade.');

        $seen=[]; $groups=[]; $largest=new \SplPriorityQueue(); $total=0; $empty=0;
        foreach ($paths as $path) {
            foreach ($r->all($path) as $row) {
                $id=strtolower((string)$row['id']);
                if (isset($seen[$id])) { self::issue($r,'colecao_concorrente'); continue; }
                $seen[$id]=true;
                ++$total;
                $v=Collection::field($row,$field);
                if ($v===null||$v===''||$v===[]) { $keys=['vazio']; ++$empty; }
                elseif (in_array($found['field_type']??'',['enum','set'],true)) {
                    $ids=self::optionIds($v);
                    if ($ids===null) { self::issue($r,'opcao_ilegivel'); continue; }
                    $keys=array_map(static fn($oid)=>'opcao:'.$oid,$ids);
                } else {
                    $keys=['categoria:'.hash_hmac('sha256',Support::json([$r->status['conta'],$type,$field,$v]),wp_salt('auth'))];
                }
                foreach ($keys as $key) self::countGroup($key,$groups,$largest,$r);
            }
        }
        ksort($groups);
        $out=[];
        foreach ($groups as $key=>$n) $out[]=['valor'=>$key,'quantidade'=>$n];
        return $r->result(['entidade'=>$type,'campo'=>$field,'grupos'=>$out,'total_observado'=>$total,'vazios'=>$empty,'arquivados_incluidos'=>in_array($type,['leads','negocios'],true),'semantica_multiplos'=>'Cada opção conta uma vez por registro; a soma de múltipla escolha pode exceder total_observado.','arquivo_contatos'=>'Pessoas e organizações não possuem coleção de arquivo nesta API; registros excluídos não entram.']);
    }

    /** Cap unique records before emission. Date evidence is attached only to a returned finding. */
    private function record(string $entity, int|string $id, string $rule, ?string $why=null): bool {
        if ($why===null) $list=&$this->findings;
        else $list=&$this->unassessed;
        $key=$entity.':'.$id.':'.$rule;
        if (isset($this->findings[$key])||isset($list[$key])) return false;
        if ($why===null) unset($this->unassessed[$key]);
        if (count($list)>=self::AUDIT_LIMIT) { self::issue($this->reader,'limite_de_saida'); return false; }
        $row=['entidade'=>$entity,'id'=>$id,'regra'=>$rule];
        if ($why!==null) $row['motivo']=$why;
        $list[$key]=$row;
        return true;
    }

    private static function due(mixed $date, mixed $clock): ?int {
        if (!is_string($date)||!is_string($clock)||!preg_match('/^\d{4}-\d\d-\d\d$/D',$date)||
            !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/D',$clock)) return null;
        return Collection::instant($date.' '.$clock);
    }

    /** Positive evidence wins over uncertain rows attached to the same record. */
    private function activityIndex(array $activities,array $types,int $now,bool $complete): array {
        $next=[]; $meetings=[]; $leadsComplete=$complete; $dealsComplete=$complete;
        foreach ($activities as $a) {
            $date=$a['due_date']??null;
            $lead=$a['lead_id']??null;
            if ($lead!==null && $lead!=='') {
                if (!is_string($lead)||!preg_match('/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/iD',$lead)) {
                    $leadsComplete=false; self::issue($this->reader,'vinculo_atividade_ilegivel');
                } elseif ($date!==null && $date!=='' && !in_array($a['done']??null,[true,1,'1'],true)) {
                    $key=strtolower($lead);
                    $open=in_array($a['done']??null,[false,0,'0'],true);
                    if ($open && self::due($date,'00:00')!==null) $next[$key]=true;
                    else $next[$key]??=false;
                }
            }

            $deal=$a['deal_id']??null;
            if ($deal===null || $deal==='' || !$types) continue;
            $id=self::linkedId($deal);
            if ($id===null) { $dealsComplete=false; self::issue($this->reader,'vinculo_atividade_ilegivel'); continue; }
            $type=$a['type']??null;
            if (is_string($type)&&$type!==''&&!in_array($type,$types,true)) continue;
            $due=self::due($date,$a['due_time']??'23:59:59');
            if ($due!==null && $due>=$now) continue;
            if ($due!==null && in_array($type,$types,true)) $meetings[$id]=true;
            else $meetings[$id]??=false;
        }
        return [$next,$meetings,$leadsComplete,$dealsComplete];
    }

    private function leads(array $leads,array $orgs,array $people,array $next,bool $complete,array $c): array {
        $pairs=[];
        foreach ($leads as $lead) {
            $id=$lead['id'];
            foreach ($c['campos_origem'] as $j=>$key) {
                $v=Collection::field($lead,$key);
                if ($v===null||$v===''||$v===[]) $this->record('lead',$id,'origem_ausente_'.($j+1));
            }
            $active=$next[strtolower((string)$id)]??null;
            if ($active!==true) {
                $why=$active===false?'dados_atividade_invalidos':(!$complete?'colecao_atividades_incompleta':null);
                $this->record('lead',$id,'sem_proxima_atividade',$why);
            }

            if ($c['separador_titulo']!=='') {
                $title=$lead['title']??'';
                if (!is_string($title)) $this->record('lead',$id,'titulo_fora_do_padrao','titulo_ilegivel');
                else {
                    $parts=explode($c['separador_titulo'],$title,3);
                    if (count($parts)!==2||trim($parts[0])===''||trim($parts[1])==='') $this->record('lead',$id,'titulo_fora_do_padrao');
                }
            }

            $oid=self::linkedId($lead['organization_id']??null); $pid=self::linkedId($lead['person_id']??null);
            if (!$oid||!$pid) continue;
            if (!isset($orgs[$oid],$people[$pid])) { self::issue($this->reader,'contato_vinculado_nao_visivel'); continue; }
            if (isset($pairs[$oid][$pid])) continue;
            $pairs[$oid][$pid]=true;
            $org=$orgs[$oid]['name']??null; $person=$people[$pid]['name']??null;
            if (!is_string($org)||!is_string($person)||trim($org)===''||trim($person)==='') {
                $this->record('organizacao',$oid,'nome_igual_pessoa','nome_vinculado_indisponivel');
            } elseif (mb_strtolower(trim($org))===mb_strtolower(trim($person))) {
                $this->record('organizacao',$oid,'nome_igual_pessoa');
            }
        }
        return $pairs;
    }

    private function names(array $orgs,array $people,array $pairs,array $rule): void {
        if (empty($rule['habilitada'])) return;
        foreach ($people as $pid=>$person) {
            $oid=self::linkedId($person['org_id']??$person['organization_id']??null);
            if ($oid!==null && isset($orgs[$oid])) $pairs[$oid][$pid]=true;
        }
        foreach ($pairs as $oid=>$linked) {
            $org=$orgs[$oid]['name']??null;
            $missing=false; $match=false;
            foreach ($linked as $pid=>$_) {
                $name=$people[$pid]['name']??null;
                if (!is_string($org)||!is_string($name)||trim($org)===''||trim($name)==='') { $missing=true; continue; }
                if (self::personName($org,$name,$rule)) { $match=true; break; }
            }
            if ($match) $this->record('organizacao',$oid,'nome_pessoa_vinculada');
            elseif ($missing) $this->record('organizacao',$oid,'nome_pessoa_vinculada','nome_vinculado_indisponivel');
        }
    }

    private function deals(array $deals,array $stages,array $meetings,bool $complete,int $now): void {
        foreach ($deals as $deal) {
            $id=$deal['id'];
            if (($deal['status']??'')!=='open') continue;
            $stage=$stages[self::linkedId($deal['stage_id']??null)??0]??null;
            if (!$stage) { self::issue($this->reader,'etapa_sem_regra'); continue; }
            $source=($deal['stage_change_time']??null)===null?'add_time':'stage_change_time';
            $last=Collection::instant($deal[$source]??null);
            if ($last===null) $this->record('negocio',$id,'etapa_sem_avanco','data_etapa_indisponivel');
            elseif ($now-$last>$stage['alerta_minutos']*60 && $this->record('negocio',$id,'etapa_sem_avanco')) {
                $this->stageDates[]=['negocio_id'=>$id,'fonte'=>$source,'entrada_em_utc'=>gmdate('Y-m-d\TH:i:s\Z',$last)];
            }
            if (!$stage['primeira']) continue;
            $overdue=$meetings[$id]??null;
            if ($overdue===true) $this->record('negocio',$id,'reuniao_vencida_primeira_etapa');
            elseif ($overdue===false || !$complete) {
                $this->record('negocio',$id,'reuniao_vencida_primeira_etapa',$overdue===false?'dados_reuniao_invalidos':'colecao_atividades_incompleta');
            }
        }
    }

    public static function audit(array $i): array {
        $r=new Collection($i);
        $audit=new self($r);
        $cfg=Configuration::read(); $c=$cfg['regras']['auditoria'];
        $now=isset($i['agora'])?Collection::instant($i['agora']):time();
        if ($now===null) throw new Fault('entrada_invalida','Instante inválido.');

        $leads=$r->all('/v1/leads'); $deals=$r->all('/api/v2/deals');
        $before=count($r->issues);
        $activities=$r->all('/api/v2/activities');
        $complete=count($r->issues)===$before;
        [$next,$meetings,$leadsComplete,$dealsComplete]=$audit->activityIndex($activities,$c['tipos_reuniao'],$now,$complete);
        unset($activities);
        $orgs=array_column($r->all('/api/v2/organizations'),null,'id');
        $people=array_column($r->all('/api/v2/persons'),null,'id');
        if (count($c['campos_origem'])!==4) self::issue($r,'quatro_campos_origem_nao_configurados');
        if ($c['separador_titulo']==='') self::issue($r,'regra_titulo_nao_configurada');
        if (!$c['etapas']) self::issue($r,'alertas_etapas_nao_configurados');

        $pairs=$audit->leads($leads,$orgs,$people,$next,$leadsComplete,$c);
        $audit->names($orgs,$people,$pairs,$c['nome_pessoa']??[]);
        $audit->deals($deals,array_column($c['etapas'],null,'id'),$meetings,$dealsComplete,$now);
        $result=$r->result(['itens'=>array_values($audit->findings),'itens_nao_avaliados'=>array_values($audit->unassessed),'datas_etapas'=>$audit->stageDates,'revisao'=>$cfg['revisao'],'agora_utc'=>gmdate('Y-m-d\TH:i:s\Z',$now)]);
        $result['data']['avaliacao_completa']=$result['data']['coleta_completa']&&!$audit->unassessed;
        return $result;
    }

    private static function words(string $v): array {return preg_split('/[^\p{L}\p{N}]+/u',mb_strtolower(trim($v)),-1,PREG_SPLIT_NO_EMPTY)?:[];}
    public static function personName(string $org,string $person,array $rule): bool {
        $a=self::words($org);$b=self::words($person);
        foreach($rule['palavras_empresa'] as $word){$tokens=self::words($word);if($tokens&&str_contains(' '.implode(' ',$a).' ',' '.implode(' ',$tokens).' '))return false;}
        $ignore=[];foreach($rule['ignorar_palavras'] as $word)$ignore=array_merge($ignore,self::words($word));
        $a=array_values(array_diff($a,$ignore));$b=array_values(array_diff($b,$ignore));
        if(count(array_unique($a))<$rule['minimo_tokens']||count(array_unique($b))<$rule['minimo_tokens'])return false;
        return in_array($b[0],$a,true)&&in_array($b[count($b)-1],$a,true)&&count(array_unique(array_intersect($a,$b)))>=$rule['minimo_tokens'];
    }

}
