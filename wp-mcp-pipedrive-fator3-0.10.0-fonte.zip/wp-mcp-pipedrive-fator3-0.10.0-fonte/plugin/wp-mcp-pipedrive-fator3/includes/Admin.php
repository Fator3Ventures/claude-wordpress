<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** WordPress admin only. Each section loads its own data; navigation never writes. */
final class Admin {
    private const TABS=['visao'=>'Visão geral','regras'=>'Regras de operação','diario'=>'Diário e retenção','ajuda'=>'Ajuda'];
    private const HELP=[
        'Começar a configurar'=>['painel'=>'Guia do painel','configuracao'=>'Configurar a integração','regras-iniciais'=>'Regras iniciais'],
        'Operar e investigar'=>['fluxos'=>'Cadência e operações','uso'=>'Exemplos de uso','operacao'=>'Operar e recuperar','release'=>'Notas da versão'],
        'Consultar a referência'=>['agentes'=>'Guia para agentes','contratos'=>'Contratos e permissões','schemas'=>'Schemas JSON','especificacao'=>'Especificação','index'=>'Índice técnico']
    ];
    public static function menu(): void {
        $hook=add_management_page('Fator3 MCP Pipedrive','Fator3 MCP Pipedrive','manage_options',SLUG,[self::class,'page']);
        if($hook){
            add_action('load-'.$hook,[AdminForms::class,'handle']);
            add_action('admin_enqueue_scripts',static function($screen)use($hook){
                if($screen!==$hook)return;
                wp_enqueue_style('f3-pipedrive-admin',plugins_url('assets/admin.css',ROOT.'/'.SLUG.'.php'),[],VERSION);
                wp_enqueue_script('f3-pipedrive-admin',plugins_url('assets/admin.js',ROOT.'/'.SLUG.'.php'),[],VERSION,true);
            });
        }
    }
    public static function url(string $tab,array $extra=[]): string {return add_query_arg(['page'=>SLUG,'aba'=>$tab]+$extra,admin_url('tools.php'));}
    public static function text(array $source,string $key,string $default=''): string {return isset($source[$key])&&is_string($source[$key])?wp_unslash($source[$key]):$default;}
    public static function notice(string $message,bool $ok=false): void {
        echo '<div class="notice inline '.($ok?'notice-success':'notice-error').'" role="'.($ok?'status':'alert').'"><p>'.esc_html($message).'</p></div>';
    }
    public static function page(): void {
        if(!current_user_can('manage_options'))wp_die('Acesso administrativo necessário.');
        $tab=self::text($_GET,'aba');
        if(!isset(self::TABS[$tab]))$tab=isset($_GET['documento'])?'ajuda':(isset($_GET['antes_id'])?'diario':'visao');
        echo '<div class="wrap f3pd"><header class="f3pd-head"><p class="f3pd-kicker">Integrações · CRM</p><h1>Fator3 MCP Pipedrive</h1><p>Configure a cadência comercial e acompanhe as operações desta instalação. <span class="f3pd-version">Versão '.esc_html(VERSION).'</span></p></header><nav class="nav-tab-wrapper f3pd-tabs" aria-label="Seções do Pipedrive">';
        foreach(self::TABS as $id=>$title)echo '<a class="nav-tab'.($tab===$id?' nav-tab-active':'').'" '.($tab===$id?'aria-current="page" ':'').'href="'.esc_url(self::url($id)).'">'.esc_html($title).'</a>';
        echo '</nav><main class="f3pd-body">';
        $state=AdminForms::state();
        if(isset($state['message']))self::notice($state['message'],!empty($state['ok']));
        match($tab){'regras'=>AdminRules::render($state),'diario'=>self::journal(),'ajuda'=>self::help(),default=>self::overview()};
        echo '</main></div>';
    }
    private static function overview(): void {
        $status=Api::dispatch('status');$cfg=Api::dispatch('configuracao-ler');$s=is_array($status['data'])?$status['data']:[];
        $ready=$status['success'];$rules=$cfg['success']?$cfg['data']['regras']:null;
        $title=$ready?'Operação autorizada':match($status['code']){'core_indisponivel'=>'Cliente do Site Core indisponível','operacao_nao_autorizada'=>'Autorização pendente',default=>'Verificação necessária'};
        echo '<section class="f3pd-panel f3pd-attention"><h2>Precisa de atenção</h2><p>';
        if(!$ready)echo 'A conexão operacional ainda não permite consultar a conta.';
        elseif(empty($rules['habilitada']))echo 'A cadência está desligada. Complete e simule as regras para começar.';
        else echo 'A cadência está habilitada.';
        if($ready){$pending=Api::dispatch('pendencias-ler',['limite'=>5]);if($pending['success']){
            $items=$pending['data']['itens']??[];echo '<br>Pendências locais visíveis para esta conta e operador: <strong>'.count($items).(!empty($pending['data']['proximo_apos_id'])?' ou mais':'').'</strong>.';
        }else echo '<br>Pendências locais: não avaliadas ('.esc_html($pending['message']).').';}
        echo '</p><p>Leads com progresso divergente: não avaliados nesta tela. <a href="'.esc_url(self::url('diario').'#f3pd-recuperacao').'">Consultar pendências e escritas recentes</a>.</p></section>';
        echo '<section class="f3pd-panel"><div class="f3pd-overline">Conexão com a conta</div><h2>'.esc_html($title).'</h2><p>'.esc_html($ready?'O Site Core disponibilizou o cliente Pipedrive para esta instalação. Esta leitura é local.':($status['code']==='core_indisponivel'?'Esta instalação ainda não recebeu o cliente Pipedrive do Site Core.':$status['message'])).'</p>';
        if(!$ready)echo '<p>Confira a instalação do Site Core, a credencial da conta e a autorização do consumidor <code>operacao</code> no site que acessa o CRM.</p>';
        echo '<dl class="f3pd-facts">';
        $facts=['Conta'=>$ready?($s['conta']['dominio']??'Não informada'):'Indisponível','Cadência'=>$rules===null?'Regras indisponíveis':($rules['habilitada']?'Habilitada':'Desligada'),'Orçamento de operação'=>$ready?number_format_i18n($s['orcamento']['consumido']).' de '.number_format_i18n($s['orcamento']['teto']).' unidades':'Indisponível'];
        foreach($facts as $k=>$v)echo '<div><dt>'.esc_html($k).'</dt><dd>'.esc_html((string)$v).'</dd></div>';
        echo '</dl>';
        if($ready){$limit=(int)$s['orcamento']['teto'];$spent=(int)$s['orcamento']['consumido'];$reserved=(int)($s['orcamento']['reservado']??0);if($limit>0)echo '<p><label>Orçamento local utilizado <progress value="'.min($spent+$reserved,$limit).'" max="'.$limit.'"></progress></label> · '.esc_html(number_format_i18n(max(0,$limit-$spent-$reserved))).' unidades disponíveis.</p>';
            echo '<p>Saldo da conta no último retorno do fornecedor: '.esc_html(isset($s['saldo_conta']['restante'])?number_format_i18n($s['saldo_conta']['restante']):'não informado').'.</p>';}
        echo '<details><summary>Detalhes do contrato</summary><p>Contrato exigido: <code>'.esc_html(CONTRACT).'</code>. Registro do cliente: '.esc_html((string)($s['registro_cliente']??'indisponível')).'. A autorização e o token são mantidos no Fator3 Site Core.</p></details></section>';
        if(!$cfg['success'])self::notice($cfg['message']);
        echo '<section class="f3pd-panel"><h2>Próximos passos</h2><ul class="f3pd-links">';
        foreach([['regras','Configurar regras','Revise os horários, motivos e textos antes de simular a cadência.'],['diario','Consultar o diário','Confira tentativas de escrita e o prazo de conservação do histórico.'],['ajuda','Documentação instalada','Leia o guia do painel e os exemplos da versão instalada.']] as [$tab,$label,$desc])echo '<li><a href="'.esc_url(self::url($tab)).'">'.esc_html($label).'</a><span>'.esc_html($desc).'</span></li>';
        echo '</ul></section>';
        if($ready){$log=Api::dispatch('registro-ler',['limite'=>3]);if($log['success']){
            echo '<section class="f3pd-panel"><h2>Últimas escritas locais</h2>';
            if(empty($log['data']['itens']))echo '<p>Nenhuma tentativa registrada.</p>';else{echo '<ul>';foreach($log['data']['itens'] as $item)echo '<li>'.esc_html(wp_date('d/m H:i T',strtotime($item['instante_utc']))).' · '.esc_html(self::label(basename((string)($item['caminho']??'')))).' · '.esc_html(self::label($item['status']??'')).'</li>';echo '</ul>';}
            echo '</section>';}}
    }
    private static function journal(): void {
        $before=self::text($_GET,'antes_id');$i=['limite'=>20];if($before!=='')$i['antes_id']=ctype_digit($before)?(int)$before:0;
        $category=self::text($_GET,'classe');$result=self::text($_GET,'resultado');$filters=[];
        foreach(['classe'=>$category,'resultado'=>$result] as $k=>$v)if($v!=='')$filters[$k]=$v;
        echo '<section class="f3pd-panel"><h2>Registro de escritas</h2><p>Confira a sequência e o resultado das tentativas. Os filtros abaixo se aplicam aos 20 registros desta página.</p><form method="get" action="'.esc_url(admin_url('tools.php')).'" class="f3pd-actions"><input type="hidden" name="page" value="'.esc_attr(SLUG).'"><input type="hidden" name="aba" value="diario">';
        foreach(['classe'=>['registro'=>'Registro comercial','estrutura'=>'Estrutura ou configuração'],'resultado'=>['operacao_concluida'=>'Operação concluída','resultado_parcial_ou_incerto'=>'Exige reconciliação','operacao_recusada'=>'Operação recusada','em_execucao'=>'Em execução']] as $key=>$choices){
            echo '<label>'.($key==='classe'?'Classe':'Resultado').' <select name="'.esc_attr($key).'"><option value="">Todos</option>';foreach($choices as $k=>$label)echo '<option value="'.esc_attr($k).'" '.selected($filters[$key]??'',$k,false).'>'.esc_html($label).'</option>';echo '</select></label>';
        }
        echo '<button class="button">Filtrar página</button></form>';
        $r=Api::dispatch('registro-ler',$i);
        if(!$r['success'])self::notice($r['message']);else{
            $items=array_filter($r['data']['itens'],static fn($v)=>($category===''||($v['classe']??'')===$category)&&($result===''||($v['status']??'')===$result));
            if(!$items)echo '<p class="f3pd-empty">Nenhuma tentativa de escrita nesta página para a seleção atual.</p>';
            else{
                echo '<div class="f3pd-table" role="region" aria-label="Tentativas de escrita" tabindex="0"><table class="widefat striped"><thead><tr><th>Quando</th><th>Operação</th><th>Resultado</th><th>Registro e etapas</th></tr></thead><tbody>';
                $binding=null;$account=null;try{$status=CoreClient::status();$account=$status['conta'];$binding=Support::digest($account);}catch(Fault){}
                foreach($items as $item){
                    $time=strtotime($item['instante_utc']);$label=self::label((string)($item['status']??''));
                    echo '<tr><td>'.esc_html($time?wp_date('d/m/Y H:i T',$time):'—').'<small>'.esc_html($item['instante_utc']).'</small></td><td><strong>'.esc_html(self::label(basename((string)($item['caminho']??'')))).'</strong><small>'.esc_html(trim(($item['metodo']??'').' '.($item['caminho']??''))).'</small></td><td><span class="f3pd-pill">'.esc_html($label).'</span></td><td>';
                    self::entity($item,$account,$binding);
                    echo '<details><summary>Detalhes da tentativa</summary><p>Prévia: <code>'.esc_html((string)($item['previa_id']??'—')).'</code></p><p>Chaves: '.esc_html(implode(', ',$item['chaves_alteradas']??[])?:'—').'</p>';
                    if(!empty($item['etapas'])){echo '<ol>';foreach($item['etapas'] as $step)echo '<li>'.esc_html(self::label((string)($step['etapa']??''))).': '.esc_html(self::label((string)($step['code']??'sem confirmação'))).'</li>';echo '</ol>';}
                    echo '</details></td></tr>';
                }
                echo '</tbody></table></div>';
            }
            if($r['data']['proximo_antes_id']!==null)echo '<p><a href="'.esc_url(self::url('diario',['antes_id'=>$r['data']['proximo_antes_id']]+$filters)).'">Registros anteriores</a></p>';
        }
        echo '</section>';AdminRecovery::render();
        $policy=Api::dispatch('retencao-ler');echo '<section class="f3pd-panel"><details><summary>Retenção do diário</summary><p>O prazo controla a próxima limpeza. Reduzir o prazo não remove entradas neste momento.</p>';
        if(!$policy['success'])self::notice($policy['message']);else{
            $p=$policy['data'];echo '<form method="post" action="'.esc_url(self::url('diario')).'">';AdminForms::fields('f3_pipedrive_retention');
            echo '<input type="hidden" name="f3_pipedrive_action" value="retention"><input type="hidden" name="revisao_esperada" value="'.esc_attr($p['revisao']).'"><label class="f3pd-label" for="f3pd-days">Dias de conservação</label><input id="f3pd-days" type="number" min="0" max="36500" step="1" required name="diario_dias" aria-describedby="f3pd-days-help" value="'.esc_attr((string)$p['diario_dias']).'"><p id="f3pd-days-help" class="description">0 = sem prazo. Prazo atual: '.($p['diario_sem_prazo']?'sem prazo':esc_html((string)$p['diario_dias']).' dias').'.</p>';
            echo '<p><label><input type="checkbox" name="confirmar_expurgo" value="1"> Para prazo finito, autorizo excluir entradas vencidas nas próximas limpezas.</label></p><p>Ampliar o prazo depois não recupera registros excluídos. Recibos necessários à reconciliação são preservados.</p>';submit_button('Salvar retenção','secondary');echo '</form>';
        }echo '</details></section>';
    }
    private static function label(string $code):string {
        return match($code){'whatsapp-registrar'=>'Registrar WhatsApp','lead-encerrar'=>'Encerrar lead','negocio-perder'=>'Registrar perda','lead-arquivado-editar'=>'Editar lead arquivado','resultado_parcial_ou_incerto'=>'Exige reconciliação','operacao_concluida'=>'Concluída','operacao_recusada'=>'Recusada','configuracao_salva'=>'Regras salvas','resultado_incerto'=>'Resultado incerto','ok'=>'Concluído','enviada'=>'Enviada',''=>'Não informado',default=>ucfirst(str_replace(['_','-'],' ',$code))};
    }
    private static function entity(array $item,?array $account,?string $binding):void {
        $id=(string)($item['registro_id']??'');$kind=$item['entidade']??'';
        if(!in_array($kind,['lead','deal'],true)||!preg_match('/^[0-9a-f-]{1,40}$/Di',$id))return;
        $title=($kind==='lead'?'Lead ':'Negócio ').$id;
        if($binding===null||!hash_equals($binding,(string)($item['conta_resumo']??''))){echo esc_html($title);return;}
        $url='https://'.$account['dominio'].($kind==='lead'?'/leads/inbox/':'/deal/').rawurlencode($id);
        echo '<a href="'.esc_url($url).'" rel="noreferrer">'.esc_html($title).'</a>';
    }
    private static function help(): void {
        $id=self::text($_GET,'documento','painel');$offset=self::text($_GET,'offset','0');$hash=self::text($_GET,'revisao');
        $labels=array_merge(...array_values(self::HELP));
        echo '<section class="f3pd-panel"><h2>Documentação instalada</h2><p>Escolha um assunto. A consulta é local e funciona mesmo sem autorização do CRM.</p><p><a href="#f3pd-help-current">Ir ao documento selecionado</a></p><nav class="f3pd-help-nav" aria-label="Documentos">';
        foreach(self::HELP as $title=>$group){
            echo '<div><h3>'.esc_html($title).'</h3><ul>';
            foreach($group as $key=>$label)echo '<li><a '.($key===$id?'aria-current="page" ':'').'href="'.esc_url(self::url('ajuda',['documento'=>$key])).'">'.esc_html($label).'</a></li>';
            echo '</ul></div>';
        }
        echo '</nav></section><section class="f3pd-panel" id="f3pd-help-current" tabindex="-1"><h2>'.esc_html($labels[$id]??'Documento').'</h2>';
        $guide=str_ends_with(Documentation::DOCUMENTS[$id]??'', '.md');
        $args=['documento'=>$id,'offset'=>ctype_digit($offset)?(int)$offset:-1,'limite_bytes'=>$guide?24000:16000];if($hash!=='')$args['sha256_esperado']=$hash;
        $r=Api::dispatch('documentacao-ler',$args);if(!$r['success']){
            self::notice($r['message']);
            if(($offset!=='0'||$hash!=='') && isset($labels[$id]))echo '<a href="'.esc_url(self::url('ajuda',['documento'=>$id])).'">Voltar ao início do documento</a>';
        }else{
            $d=$r['data'];echo '<p class="description">Versão '.esc_html($d['version']).' · '.esc_html(number_format_i18n($d['total_bytes'])).' bytes no documento.</p>';
            if($guide && $d['offset']===0){
                // Read the installed guide against one revision, then paginate at semantic boundaries.
                try{
                    $content=$d['conteudo'];$next=$d['proximo_offset'];
                    while($next!==null){$chunk=Documentation::read(['documento'=>$id,'offset'=>$next,'limite_bytes'=>24000,'sha256_esperado'=>$d['sha256']]);$content.=$chunk['conteudo'];$next=$chunk['proximo_offset'];}
                    $pages=AdminDocument::pages($content);$input=self::text($_GET,'parte','1');
                    if(!ctype_digit($input)||(int)$input<1||(int)$input>count($pages)||((int)$input>1&&$hash===''))throw new Fault('parte_invalida','Parte indisponível. Reabra o documento pelo índice.');
                    $page=(int)$input;
                    if(count($pages)>1)echo '<p>Parte '.$page.' de '.count($pages).'</p>';
                    echo AdminDocument::render($pages[$page-1]);
                    foreach([$page-1=>'Parte anterior',$page+1=>'Ler próxima parte'] as $n=>$label)if($n>=1&&$n<=count($pages))echo '<a class="button" href="'.esc_url(self::url('ajuda',['documento'=>$id,'parte'=>$n,'revisao'=>$d['sha256']]).'#f3pd-help-current').'">'.esc_html($label).'</a> ';
                }catch(Fault $e){self::notice($e->getMessage());}
            }else{
                echo '<pre class="f3pd-document f3pd-source" tabindex="0">'.esc_html($d['conteudo']).'</pre>';
                if($d['proximo_offset']!==null)echo '<a class="button" href="'.esc_url(self::url('ajuda',['documento'=>$id,'offset'=>$d['proximo_offset'],'revisao'=>$d['sha256']])).'">Ler próxima parte</a>';
                if($d['offset']>0)echo ' <a href="'.esc_url(self::url('ajuda',['documento'=>$id])).'">Voltar ao início do documento</a>';
            }
        }echo '</section>';
    }
}
