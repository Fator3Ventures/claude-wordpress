<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Local retention policy. Reads never initialize or repair storage. */
final class Retention {
    public const OPTION = 'f3_pipedrive_retention';
    public const RECEIPT_DAYS = 180;

    private static function snapshot(): array {
        global $wpdb;
        $raw = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s", self::OPTION));
        if ($wpdb->last_error !== '') {
            throw new Fault('armazenamento_indisponivel', 'Não foi possível ler a política de retenção.');
        }
        $value = $raw === null ? null : json_decode($raw, true);
        if ($raw !== null && (!is_array($value) || !is_int($value['diario_dias'] ?? null)
            || $value['diario_dias'] < 0 || $value['diario_dias'] > 36500
            || !is_string($value['alterado_em'] ?? null) || !is_int($value['alterado_por'] ?? null)
            || !is_string($value['geracao'] ?? null) || !preg_match('/^[a-f0-9]{32}$/D', $value['geracao']))) {
            throw new Fault('retencao_invalida', 'Política de retenção ilegível. Preserve os dados e restaure a configuração; nenhum expurgo foi autorizado.');
        }
        return ['raw'=>$raw, 'value'=>$value, 'revision'=>Support::digest([get_current_blog_id(), $wpdb->options, self::OPTION, $raw])];
    }

    public static function read(): array {
        Support::admin();
        $s = self::snapshot();
        $days = $s['value']['diario_dias'] ?? 0;
        return ['diario_dias'=>$days, 'diario_sem_prazo'=>$days === 0, 'recibos_dias'=>self::RECEIPT_DAYS,
            'previas_segundos'=>900, 'revisao'=>$s['revision'], 'origem'=>$s['raw'] === null ? 'padrao' : 'configurado',
            'alterado_em'=>$s['value']['alterado_em'] ?? null, 'alterado_por'=>$s['value']['alterado_por'] ?? null,
            'limpeza'=>'Prévia, aplicação e registro de WhatsApp verificam a limpeza local: no máximo um lote por minuto por política, até 100 linhas por categoria. Sem novas operações, o expurgo aguarda. Consultas e configuração da retenção não expurgam. Tentativas em execução e pendências são preservadas.'];
    }

    /** One connection-scoped mutex for policy writes and the dependent purge. */
    public static function locked(callable $callback, bool $opportunistic=false) {
        global $wpdb;
        $name = 'f3pip_ret_' . substr(hash('sha256', DB_NAME . '|' . $wpdb->options), 0, 48);
        $got = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, $opportunistic ? 0 : 1));
        if ($opportunistic && (string)$got === '0') { return null; }
        if ((string)$got !== '1') {
            throw new Fault('retencao_ocupada', 'Não foi possível adquirir a trava de retenção. Nenhuma nova limpeza foi iniciada.');
        }
        try { return $callback(); }
        finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name)); }
    }

    public static function configure(array $input): array {
        Support::admin();
        $days = $input['diario_dias'] ?? null;
        if (!is_int($days) || $days < 0 || $days > 36500 || !is_string($input['revisao_esperada'] ?? null)) {
            throw new Fault('entrada_invalida', 'Informe dias entre 0 e 36500 e a revisão lida. Zero significa sem prazo.');
        }
        if ($days > 0 && ($input['confirmar_expurgo'] ?? false) !== true) {
            throw new Fault('confirmacao_ausente', 'Prazo finito permite excluir linhas antigas nas próximas limpezas. Informe confirmar_expurgo=true após revisar esse efeito.');
        }
        return self::locked(static function () use ($input, $days) {
            global $wpdb;
            $s = self::snapshot();
            if (!hash_equals($s['revision'], $input['revisao_esperada'])) {
                throw new Fault('revisao_conflitante', 'A política mudou. Leia novamente antes de configurar.', ['revisao_atual'=>$s['revision']]);
            }
            if ($s['raw'] !== null && $s['value']['diario_dias'] === $days) {
                return ['success'=>true, 'code'=>'sem_alteracao', 'message'=>'Política já persistida; nenhum expurgo executado.',
                    'data'=>self::read(), 'changed'=>false, 'persisted'=>true];
            }
            $value = ['diario_dias'=>$days, 'alterado_em'=>gmdate('Y-m-d\TH:i:s\Z'),
                'alterado_por'=>get_current_user_id(), 'geracao'=>bin2hex(random_bytes(16))];
            $raw = Support::json($value);
            if ($s['raw'] === null) {
                $changed = $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'off')", self::OPTION, $raw));
            } else {
                $changed = $wpdb->query($wpdb->prepare("UPDATE {$wpdb->options} SET option_value=%s,autoload='off' WHERE option_name=%s AND BINARY option_value=BINARY %s", $raw, self::OPTION, $s['raw']));
            }
            wp_cache_delete(self::OPTION, 'options');
            wp_cache_delete('notoptions', 'options');
            wp_cache_delete('alloptions', 'options');
            if ($changed !== 1 || self::snapshot()['raw'] !== $raw) {
                throw new Fault('persistencia_incerta', 'A gravação não foi confirmada. Releia a política antes de tentar novamente.');
            }
            return ['success'=>true, 'code'=>'retencao_configurada', 'message'=>'Política persistida e relida. Nenhuma linha foi excluída por esta configuração.',
                'data'=>self::read(), 'changed'=>true, 'persisted'=>true];
        });
    }
}
