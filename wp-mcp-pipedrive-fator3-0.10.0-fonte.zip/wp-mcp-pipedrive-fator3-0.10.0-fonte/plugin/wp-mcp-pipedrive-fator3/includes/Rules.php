<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Pure, bounded rule evaluation. Never writes configuration or provider state. */
final class Rules {
    public static function local(int $at,array $c): \DateTimeImmutable {
        return (new \DateTimeImmutable('@'.$at))->setTimezone(new \DateTimeZone($c['fuso']));
    }
    public static function working(\DateTimeImmutable $day,array $c): bool {
        return in_array((int)$day->format('N'),$c['dias'],true)&&!in_array($day->format('Y-m-d'),$c['feriados']??[],true);
    }
    public static function clock(\DateTimeImmutable $day,string $time): \DateTimeImmutable {
        [$h,$m]=array_map('intval',explode(':',$time));return $day->setTime($h,$m);
    }
    public static function within(int $at,array $c): bool {
        $d=self::local($at,$c);return self::working($d,$c)&&$d->format('H:i')>=$c['janela']['inicio']&&$d->format('H:i')<=$c['janela']['fim'];
    }
    public static function businessDeadline(int $base,int $minutes,array $c): int {
        $day=self::local($base,$c)->setTime(0,0);$remaining=$minutes*60;
        for($n=0;$n<3660;$n++,$day=$day->modify('+1 day')){
            if(!self::working($day,$c))continue;
            $start=max($base,self::clock($day,$c['janela']['inicio'])->getTimestamp());$end=self::clock($day,$c['janela']['fim'])->getTimestamp();
            if($start>=$end)continue;
            if($remaining<=$end-$start)return $start+$remaining;
            $remaining-=$end-$start;
        }
        throw new Fault('calendario_sem_prazo','Prazo não encontrado em dez anos de calendário.');
    }
    public static function deadline(int $base,array $touch,array $c): array {
        return match($touch['prazo']??'periodo'){
            'minutos_uteis'=>['instante'=>self::businessDeadline($base,$touch['atraso_minutos'],$c),'periodo'=>null],
            'primeiro_periodo_dia_util_seguinte'=>Cadence::slot(self::local($base,$c)->modify('+1 day')->setTime(0,0)->getTimestamp(),$c),
            default=>Cadence::slot($base+$touch['atraso_minutos']*60,$c)
        };
    }
    public static function matches(array $lead,array $condition): bool {
        $v=Collection::field($lead,$condition['campo']);$empty=$v===null||$v===''||$v===[];
        if($condition['operador']==='presente')return !$empty;
        if($condition['operador']==='ausente')return $empty;
        foreach(is_array($v)&&array_is_list($v)?$v:[$v] as $value){if(is_array($value))$value=$value['id']??$value['value']??null;if(!is_scalar($value))continue;foreach($condition['valores'] as $wanted)if((string)$value===(string)$wanted)return true;}
        return false;
    }
    public static function channel(array $lead,array $c): array {
        $out=['encerramento'=>true,'arquivamento'=>true,'regras'=>[]];
        foreach($c['canais']??[] as $rule)if(self::matches($lead,$rule['condicao'])){
            $out['encerramento']=$out['encerramento']&&$rule['permitir_encerramento'];$out['arquivamento']=$out['arquivamento']&&$rule['permitir_arquivamento'];$out['regras'][]=$rule['codigo'];
        }
        return $out;
    }
    public static function closure(array $lead,array $c,bool $archiveOnly=false): void {
        $r=self::channel($lead,$c);if(!$r['arquivamento']||(!$archiveOnly&&!$r['encerramento']))throw new Fault('canal_protegido','As regras deste canal impedem encerramento/arquivamento.');
    }
    public static function text(array $lead,array $touch,array $c): array {
        $id=$touch['texto_id'];foreach($touch['variantes']??[] as $v)if(self::matches($lead,$v['condicao'])){$id=$v['texto_id'];break;}
        $text=array_column($c['textos'],'texto','codigo')[$id];$missing=[];
        if(array_key_exists('variaveis',$c)){
            $map=array_column($c['variaveis'],null,'codigo');
            $text=preg_replace_callback('/\{([a-z0-9_-]{1,40})\}/',static function($m)use($lead,$map,&$missing){
                $rule=$map[$m[1]]??null;$v=$rule?Collection::field($lead,$rule['campo']):null;
                if(is_array($v)&&array_is_list($v)&&!array_filter($v,static fn($x)=>!is_scalar($x)))$v=implode(', ',$v);
                if(!is_scalar($v)||trim((string)$v)===''){$missing[]=$m[1];return '';}
                $v=preg_replace('/^[\s\p{Z}]+|[\s\p{Z}]+$/u','',wp_strip_all_tags((string)$v));
                if($v===null||$v===''){$missing[]=$m[1];return '';}
                if($rule['parte']==='primeiro_nome')$v=preg_split('/\s+/u',$v)[0];return $v;
            },$text);
        }
        if($missing||strlen($text)>16000)return ['id'=>$id,'texto'=>null,'motivo'=>$missing?'variavel_indisponivel':'texto_excedeu_limite'];
        return ['id'=>$id,'texto'=>$text,'motivo'=>null];
    }
    public static function noteLine(string $message,int $now,array $c): string {
        $n=$c['nota']??['prefixo'=>'[IA]','formato'=>'d/m H\hi','autor'=>'nós'];
        $line=($n['prefixo']!==''?$n['prefixo'].' ':'').self::local($now,$c)->format($n['formato']).', '.$n['autor'].': '.$message;
        return htmlspecialchars($line,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    }
    public static function adoption(array $lead,?array $activity,array $c,int $labelIndex,int $now): ?array {
        $rule=$c['adocao']??[];if(empty($rule['habilitada'])||!$activity)return null;
        // Only explicitly identified outbound lines; never infer a touch by counting arbitrary notes.
        $note=preg_replace('~<(?:br\s*/?|/p|/div)>~i',"\n",(string)($activity['note']??''));$note=html_entity_decode(wp_strip_all_tags($note),ENT_QUOTES|ENT_HTML5,'UTF-8');
        $prefix=preg_quote($rule['prefixo'],'~');$author=preg_quote($rule['autor'],'~');$rows=[];$year=(int)self::local($now,$c)->format('Y');$created=Collection::instant($lead['add_time']??null);
        foreach(explode("\n",$note) as $line){
            if(!preg_match('~^\s*'.$prefix.'\s*(\d{2})/(\d{2})(?:/(\d{4}))? (\d{2})h(\d{2}),\s*'.$author.':\s*(.+)$~u',trim($line),$m))continue;
            $y=$m[3]!==''?(int)$m[3]:$year;$date=\DateTimeImmutable::createFromFormat('!Y-m-d H:i',sprintf('%04d-%s-%s %s:%s',$y,$m[2],$m[1],$m[4],$m[5]),new \DateTimeZone($c['fuso']));$errors=\DateTimeImmutable::getLastErrors();
            if(!$date||($errors&&($errors['warning_count']||$errors['error_count'])))continue;
            if($m[3]===''&&$date->getTimestamp()>$now){$date=$date->modify('-1 year');if($date->format('d/m')!==$m[1].'/'.$m[2])continue;}
            $at=$date->getTimestamp();if($at>$now||$at<$now-$rule['max_idade_dias']*DAY_IN_SECONDS||($created!==null&&$at<$created))continue;
            $indices=[];foreach($rule['toques_por_texto'] as $map)if(str_contains($m[6],$map['trecho']))$indices[]=array_search($map['toque'],array_column($c['toques'],'codigo'),true);
            $indices=array_values(array_unique($indices));$index=count($indices)===1?$indices[0]:(count($indices)===0?$labelIndex:-1);
            $rows[]=['indice'=>$index,'instante'=>$at];
        }
        if(!$rows)return null;usort($rows,static fn($a,$b)=>$b['instante']<=>$a['instante']);$latest=$rows[0];
        if($latest['indice']<0||$latest['indice']<$labelIndex)return null;
        foreach($rows as $row)if($row['instante']===$latest['instante']&&$row['indice']!==$latest['indice'])return null;
        return ['indice'=>$latest['indice']+1,'ultimo'=>$latest['instante'],'ambiguo'=>false,'origem'=>'nota_adotada'];
    }
}
