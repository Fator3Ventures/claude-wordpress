<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
final class Cadence {
    public static function marker(string $lead,string $touch,int $time,string $key): string {
        $data=$touch.':'.$time.':'.hash('sha256',$key);
        return '[F3PD1:'.$data.':'.hash_hmac('sha256',$lead.':'.$data,wp_salt('auth')).']';
    }
    public static function progress(array $lead,?array $activity,array $c,?int $now=null,?array $account=null): array {
        $now??=time();$n=-1;$last=null;$codes=array_column($c['toques'],'codigo');
        foreach($c['toques'] as $i=>$t)if($t['etiqueta_id']!==''&&in_array($t['etiqueta_id'],$lead['label_ids']??[],true))$n=max($n,$i);
        $note=(string)($activity['note']??'');
        preg_match_all('/\[F3PD1:([a-z0-9_-]{1,40}):(\d{10,11}):([a-f0-9]{64}):([a-f0-9]{64})\]/',$note,$matches,PREG_SET_ORDER);
        foreach($matches as $m){$index=array_search($m[1],$codes,true);if($index!==false&&hash_equals(hash_hmac('sha256',$lead['id'].':'.$m[1].':'.$m[2].':'.$m[3],wp_salt('auth')),$m[4])&&$index>=$n){$n=$index;$last=max($last??0,(int)$m[2]);}}
        $origin=$last!==null?'marcador':'etiqueta_ou_inicio';
        $local=$account!==null?Progress::read($account,(string)$lead['id'],$activity):null;
        if($local!==null){
            $index=array_search($local['touch'],$codes,true);
            if($index===false)throw new Fault('progresso_incompativel','O toque registrado não existe nas regras atuais. Reconcilie a configuração.');
            if($index>=$n){$n=$index;$last=$local['time'];$origin='registro_local';}
        }
        if($last===null){$adopted=Rules::adoption($lead,$activity,$c,$n,$now);if($adopted!==null)return $adopted;}
        return ['indice'=>$n+1,'ultimo'=>$last,'ambiguo'=>$note!==''&&$n===-1,'origem'=>$origin];
    }
    public static function slot(int $target,array $c): array {
        $zone=new \DateTimeZone($c['fuso']);$day=(new \DateTimeImmutable('@'.$target))->setTimezone($zone)->setTime(0,0);$periods=$c['periodos'];usort($periods,static fn($a,$b)=>strcmp($a['hora'],$b['hora']));
        for($d=0;$d<3660;$d++,$day=$day->modify('+1 day')){
            if(!Rules::working($day,$c))continue;
            foreach($periods as $p){[$h,$m]=array_map('intval',explode(':',$p['hora']));$at=$day->setTime($h,$m)->getTimestamp();if($at>=$target)return ['instante'=>$at,'periodo'=>$p['codigo']];}
        }
        throw new Fault('configuracao_invalida','Não há próximo período no calendário.');
    }
    public static function evaluate(array $lead,array $activities,array $c,int $now,?array $account=null): array {
        $out=['lead_id'=>$lead['id'],'toque'=>null,'devido_em_utc'=>null,'periodo'=>null,'texto_aprovado'=>null,'devido'=>false,'motivo'=>null,'acao'=>'mensagem','politica_canal'=>Rules::channel($lead,$c)];
        if(!$c['habilitada']){$out['motivo']='configuracao_pendente';return $out;}
        if(!empty($lead['is_archived'])){$out['motivo']='lead_arquivado';return $out;}
        if(array_intersect($lead['label_ids']??[],$c['exclusoes']['etiquetas'])){$out['motivo']='etiqueta_excluida';return $out;}
        foreach($c['exclusoes']['campos'] as $rule){if(Rules::matches($lead,['campo'=>$rule['campo'],'operador'=>'igual','valores'=>$rule['valores']])){$out['motivo']=$rule['regra'];return $out;}}
        $wa=array_values(array_filter($activities,static fn($a)=>(string)($a['lead_id']??'')===(string)$lead['id']&&($a['type']??'')===$c['tipo_whatsapp']));
        if(count($wa)>1){$out['motivo']='atividade_whatsapp_duplicada';return $out;}
        $a=$wa[0]??null;if($a&&!empty($a['done'])){$out['motivo']='atividade_concluida';return $out;}
        $progress=self::progress($lead,$a,$c,$now,$account);$index=$progress['indice'];
        if($progress['ambiguo']){$out['motivo']='historico_sem_marcador';return $out;}
        $out['origem_progresso']=$progress['origem'];
        $wait=$c['espera_entrega']??[];
        if(!empty($wait['habilitada'])&&Rules::matches($lead,$wait['condicao'])){
            $since=$wait['campo_desde']!==''?Collection::instant(Collection::field($lead,$wait['campo_desde'])):$progress['ultimo'];
            if($since===null||$since>$now){$out['motivo']='instante_entrega_indisponivel';return $out;}
            $review=$since+$wait['rever_minutos']*60;$end=$since+$wait['encerrar_minutos']*60;$closing=$now>=$end;
            $out['acao']=$closing?'encerrar':'verificar_entrega';$out['estado_espera']=$now<$review?'aguardando_verificacao':($closing?'limite_sem_entrega':'verificar_sem_entrega');
            $out['rever_em_utc']=gmdate('Y-m-d\TH:i:s\Z',$review);$out['limite_em_utc']=gmdate('Y-m-d\TH:i:s\Z',$end);
            return self::due($out,['instante'=>$closing?$end:$review,'periodo'=>null],$c,$now);
        }
        if(!isset($c['toques'][$index])){$out['motivo']='cadencia_concluida';return $out;}
        $t=$c['toques'][$index];$base=$t['base']==='entrada'?Collection::instant($lead['add_time']??null):$progress['ultimo'];
        if($base===null){$out['motivo']='instante_base_indisponivel';return $out;}
        $slot=Rules::deadline($base,$t,$c);$text=Rules::text($lead,$t,$c);
        $out['toque']=$t['codigo'];$out['acao']=$t['acao']??'mensagem';$out['texto_id']=$text['id'];$out['texto_aprovado']=$text['texto'];
        $out=self::due($out,$slot,$c,$now);
        if($text['motivo']!==null){$out['motivo']=$text['motivo'];$out['devido']=false;}
        return $out;
    }
    private static function due(array $out,array $slot,array $c,int $now): array {
        $out['periodo']=$slot['periodo'];$out['devido_em_utc']=gmdate('Y-m-d\TH:i:s\Z',$slot['instante']);
        $within=Rules::within($now,$c);$out['devido']=$within&&$slot['instante']<=$now;
        $out['motivo']=$out['devido']?null:($within?'aguardando_prazo':'fora_da_janela');
        if($out['acao']==='encerrar'&&(!$out['politica_canal']['encerramento']||!$out['politica_canal']['arquivamento'])){$out['devido']=false;$out['texto_aprovado']=null;$out['motivo']='canal_protegido';}
        return $out;
    }

    private const CURSOR_TTL = 900;
    private const RESPONSE_BYTES = 96000;

    /** Read activities only for this lead, or once for a whole small lead population. */
    private static function activities(Collection $r,array $targets,string $type,?string $lead=null,?array $first=null): array {
        $q=['limit'=>500];if($lead!==null)$q['lead_id']=$lead;
        $out=[];$seen=[];$positions=[];
        do {
            $p=$first??$r->page('/api/v2/activities',$q);$first=null;$q['limit']=$p['limit'];
            foreach($p['rows'] as $a) {
                $key=(string)$a['id'];
                if(isset($seen[$key]))throw new Fault('colecao_concorrente','Atividade repetida entre páginas.');
                $seen[$key]=true;
                if(!is_string($a['type']??null)||$a['type']===''||($lead!==null&&(!is_string($a['lead_id']??null)||strcasecmp($a['lead_id'],$lead)!==0)))throw new Fault('estado_incompleto','A lista não confirmou o tipo ou o vínculo da atividade.');
                if($a['type']!==$type)continue;
                if(!array_key_exists('lead_id',$a)||($a['lead_id']!==null&&!is_string($a['lead_id'])))throw new Fault('estado_incompleto','Atividade sem informação de vínculo.');
                $id=strtolower((string)$a['lead_id']);
                if(!isset($targets[$id]))continue;
                // A second distinct WhatsApp activity is already a block; no note or extra detail is needed.
                if(count($out[$id]??[])>=2)continue;
                $a['lead_id']=$targets[$id];$out[$id][]=$a;
            }
            $next=$p['next'];
            if($next!==null){if(isset($positions[$next]))throw new Fault('paginacao_incompleta','Cursor de atividade repetido.');$positions[$next]=true;$q['cursor']=$next;}
        }while($next!==null);
        foreach($out as $id=>$matches) {
            if(count($matches)!==1)continue;
            $a=$matches[0];
            if(!array_key_exists('note',$a)||!array_key_exists('done',$a))$a=$r->one('/api/v2/activities/'.$a['id']);
            if(!is_string($a['lead_id']??null)||strcasecmp($a['lead_id'],$id)!==0||($a['type']??null)!==$type||!array_key_exists('note',$a)||!in_array($a['done']??null,[true,false,1,0],true)||($a['note']!==null&&!is_string($a['note'])))throw new Fault('estado_incompleto','A atividade não confirmou vínculo, situação e histórico.');
            $a['lead_id']=$targets[$id];$out[$id]=[$a];
        }
        return $out;
    }
    private static function cursor(string $token): array {
        try {
            if(!preg_match('/^[a-zA-Z0-9_-]{1,2048}$/D',$token))throw new \RuntimeException();
            $b64=strtr($token,'-_','+/');$raw=base64_decode($b64,true);
            if($raw===false||rtrim(base64_encode($raw),'=')!==$b64)throw new \RuntimeException();
            $s=Support::open($b64);
            if(($s['tag']??null)!=='cadencia-fila/1'||!is_int($s['exp']??null)||$s['exp']<=time()||!is_int($s['offset']??null)||$s['offset']<1||!is_string($s['anchor']??null))throw new \RuntimeException();
            return $s;
        }catch(\Throwable $e){throw new Fault('cursor_invalido','Cursor inválido ou expirado. Reinicie a leitura da fila.');}
    }
    private static function blockedRow(string $id,string $reason): array {
        return ['lead_id'=>$id,'devido'=>false,'texto_aprovado'=>null,'motivo'=>$reason];
    }
    public static function queue(array $i,?array $candidate=null,?Collection $reader=null): array {
        $cfg=Configuration::read();$c=$candidate??$cfg['regras'];$reader??=new Collection($i);
        $state=isset($i['cursor'])?self::cursor($i['cursor']):null;
        $limit=$i['limite']??($state['limit']??200);$filter=$i['filtro']??($state['filter']??'todos');
        $now=isset($i['agora'])?Collection::instant($i['agora']):($state['now']??time());
        if($now===null)throw new Fault('entrada_invalida','agora deve ser RFC3339 UTC.');
        $binding=Support::digest([CoreClient::binding($reader->status),get_current_user_id(),$cfg['revisao'],$candidate===null?'corrente':Support::digest($candidate),$filter,$limit,$now]);
        if($state!==null&&!hash_equals($binding,(string)($state['binding']??'')))throw new Fault('cursor_invalido','Conta, usuário, regras, filtro, limite ou instante mudaram. Reinicie a fila.');
        $offset=$state['offset']??0;$end=null;$next=null;$items=[];$byReason=[];$evaluated=0;$due=0;$bytes=0;$leads=[];$anchor=null;
        try {
            // Include one overlapping record on continuation so a shift at the boundary cannot silently skip a lead.
            $p=$reader->page('/v1/leads',['start'=>max(0,$offset-($state!==null?1:0)),'limit'=>$limit+($state!==null?1:0)]);
            $leads=$p['rows'];
            if($state!==null){
                $overlap=array_shift($leads);
                if(!$overlap||strcasecmp((string)$overlap['id'],$state['anchor'])!==0)throw new Fault('colecao_concorrente','A posição anterior mudou; reinicie a leitura da fila.');
                if(!$leads&&$p['next']!==null){$p=$reader->page('/v1/leads',['start'=>$offset,'limit'=>$limit]);$leads=$p['rows'];}
            }
            $targets=[];foreach($leads as $l)$targets[strtolower($l['id'])]=$l['id'];
            // A complete one-page account can use a single sweep. A multi-page account probes a bounded page before switching to lead-specific reads.
            $global=$candidate===null&&$state===null&&$p['next']===null&&count($leads)>8&&$c['habilitada'];
            $batch=$global?self::activities($reader,$targets,$c['tipo_whatsapp']):[];
            $targeted=$state['targeted']??false;
            if(!$global&&!$targeted&&$c['habilitada']&&count($leads)>8) {
                // One bounded probe per page for sparse accounts. Once density is known, only scoped reads.
                try {
                    $probe=$reader->page('/api/v2/activities',['limit'=>50]);
                    $targeted=$probe['next']!==null;
                    if(!$targeted){$global=true;$batch=self::activities($reader,$targets,$c['tipo_whatsapp'],null,$probe);}
                }catch(Fault $e){
                    if($e->reason!=='resposta_excedeu_limite')throw $e;
                    $global=false;$targeted=true;
                }
            }
            foreach($leads as $l) {
                if($evaluated>0&&(!$reader->hasTime()||(!$global&&$c['habilitada']&&$reader->remainingCalls()===0)))break;
                $id=$l['id'];$rows=[];
                try {
                    if($c['habilitada']){
                        Workflows::checkPending(Support::digest($reader->status['conta']).':lead:'.strtolower($id));
                        $list=$global?$batch:self::activities($reader,[strtolower($id)=>$id],$c['tipo_whatsapp'],$id);
                        $rows=$list[strtolower($id)]??[];
                    }
                    $row=self::evaluate($l,$rows,$c,$now,$reader->status['conta']);
                }catch(Fault $e){
                    if(!in_array($e->reason,['reconciliacao_necessaria','progresso_divergente','progresso_incompativel'],true)) {
                        if($e->reason==='limite_de_coleta'&&$evaluated>0)break;
                        throw $e;
                    }
                    $row=self::blockedRow($id,$e->reason);
                }
                $show=$filter!=='devidos'||$row['devido'];
                if($show){
                    $size=strlen(Support::json($row));if($evaluated>0&&$bytes+$size>self::RESPONSE_BYTES)break;
                    $bytes+=$size;$items[]=$row;
                }
                $reason=$row['devido']?'devido':($row['motivo']??'nao_devido');
                $byReason[$reason]=1+($byReason[$reason]??0);
                ++$evaluated;$due+=(int)$row['devido'];$anchor=$id;
            }
            $end=$p['next']===null&&$evaluated===count($leads);
            if(!$end&&!$evaluated)throw new Fault('limite_de_coleta','Não foi possível avaliar o primeiro lead com os limites atuais.');
            if(!hash_equals($cfg['revisao'],Configuration::read()['revisao']))throw new Fault('revisao_conflitante','As regras mudaram durante a leitura.');
            if(!$end&&$candidate===null){
                $payload=['tag'=>'cadencia-fila/1','binding'=>$binding,'exp'=>$state['exp']??(time()+self::CURSOR_TTL),'limit'=>$limit,'filter'=>$filter,'now'=>$now,'offset'=>$offset+$evaluated,'anchor'=>$anchor,'targeted'=>$targeted];
                $next=rtrim(strtr(Support::seal($payload),'+/','-_'),'=');
            }
        }catch(Fault $e){$reader->issues[]=$e->reason;}
        $r=$reader->result(['itens'=>$items,'revisao'=>$cfg['revisao'],'simulada'=>$candidate!==null,'agora_utc'=>gmdate('Y-m-d\TH:i:s\Z',$now)]);
        $complete=$r['data']['coleta_completa'];
        if(!$complete){
            // Do not expose a candidate or advance after an incomplete source read.
            $r['data']['itens']=$filter==='devidos'?[]:array_map(static fn($l)=>self::blockedRow($l['id'],'coleta_incompleta'),$leads);
            $due=$end=$next=null;$evaluated=0;$byReason=[];
        }
        $r['data']+=['pagina_completa'=>$complete,'fim_da_fila'=>$end,'proximo_cursor'=>$next,'avaliados'=>$evaluated,'devidos'=>$due,'motivos_pagina'=>(object)$byReason,'total_visivel'=>$end===true?$offset+$evaluated:null,'amostra'=>$candidate!==null&&$end!==true];
        return $r;
    }
}
