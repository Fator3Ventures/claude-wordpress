<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** One authenticated cursor per account/lead, stored atomically with the operation receipt. */
final class Progress {
    public static function identity(array $account,string $lead): string {
        return hash_hmac('sha256',Support::canonical(['cadence/1',$account,strtolower($lead)]),wp_salt('auth'));
    }
    public static function noteDigest(string $note): string {
        // The provider can normalize HTML. Compare visible text, including old signed markers.
        $note=preg_replace('~<br\b[^>]*>|</(?:p|div|li|h[1-6])\s*>~i',"\n",$note)??$note;
        $text=html_entity_decode(wp_strip_all_tags($note),ENT_QUOTES|ENT_HTML5,'UTF-8');
        return hash('sha256',trim(preg_replace('/[\s\x{00a0}]+/u',' ',$text)??$text));
    }
    public static function stored(array $account,string $lead): ?array {
        global $wpdb;$identity=self::identity($account,$lead);$table=Store::table('ops');
        $row=$wpdb->get_row($wpdb->prepare("SELECT state,binding,result FROM $table WHERE previa_id=%s",substr($identity,0,32)),ARRAY_A);
        if($wpdb->last_error!=='')throw new Fault('armazenamento_indisponivel','Não foi possível ler o progresso da cadência.');
        if($row===null)return null;
        if($row['state']!=='progress'||!hash_equals($identity,$row['binding']))throw new Fault('registro_ilegivel','Identidade do progresso divergente. Preserve o registro local.');
        $p=Support::open($row['result']);
        if(($p['identity']??null)!==$identity||!is_int($p['time']??null)||!is_string($p['touch']??null)||!is_string($p['note_digest']??null))throw new Fault('registro_ilegivel','Progresso privado incompleto.');
        return $p;
    }
    public static function read(array $account,string $lead,?array $activity): ?array {
        $p=self::stored($account,$lead);
        if($p===null)return null;
        if(!$activity||(int)($activity['id']??0)!==($p['activity_id']??null)||!hash_equals($p['note_digest'],self::noteDigest((string)($activity['note']??''))))throw new Fault('progresso_divergente','A atividade ou seu histórico mudou. Reconcilie o progresso antes de registrar outro toque.');
        return $p;
    }
    public static function prepare(array $account,string $lead,array $activity,string $touch,int $time,string $receipt): array {
        return ['identity'=>self::identity($account,$lead),'activity_id'=>(int)$activity['id'],'touch'=>$touch,'time'=>$time,'note_digest'=>self::noteDigest((string)$activity['note']),'receipt_id'=>$receipt];
    }
    /** Caller owns the lead lock and an open Store::finish transaction. No independent commit. */
    public static function persist(array $p): void {
        global $wpdb;$table=Store::table('ops');$key=substr($p['identity'],0,32);
        $row=$wpdb->get_row($wpdb->prepare("SELECT state,binding FROM $table WHERE previa_id=%s FOR UPDATE",$key),ARRAY_A);
        if($wpdb->last_error!==''||($row&&($row['state']!=='progress'||$row['binding']!==$p['identity'])))throw new Fault('resultado_incerto','O progresso não confirmou sua identidade.');
        $sealed=Support::seal($p);
        $data=['actor_id'=>0,'binding'=>$p['identity'],'state'=>'progress','created'=>$p['time'],'expires'=>0,'retain_until'=>PHP_INT_MAX,'payload'=>'','result'=>$sealed];
        $written=$row?$wpdb->update($table,$data,['previa_id'=>$key]):$wpdb->insert($table,['previa_id'=>$key]+$data);
        if($written===false||$wpdb->get_var($wpdb->prepare("SELECT result FROM $table WHERE previa_id=%s",$key))!==$sealed)throw new Fault('resultado_incerto','Progresso não persistido; mantenha a pendência para reconciliação.');
    }
}
