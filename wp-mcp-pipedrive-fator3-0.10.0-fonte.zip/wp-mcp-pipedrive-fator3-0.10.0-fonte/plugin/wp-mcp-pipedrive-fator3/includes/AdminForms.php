<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** The GET displays a short-lived result. Only POST can claim a signed, session-bound attempt. */
final class AdminForms {
    private const PREFIX='f3_pd_form_';
    private const TTL=1800;
    private static function sign(string $part): string {
        return substr(hash_hmac('sha256',get_current_blog_id().'|'.get_current_user_id().'|'.wp_get_session_token().'|'.$part,wp_salt('nonce')),0,40);
    }
    public static function token(): string {
        $part=time().'-'.bin2hex(random_bytes(16));return $part.'-'.self::sign($part);
    }
    public static function fields(string $nonce): void {
        wp_nonce_field($nonce);echo '<input type="hidden" name="f3pd_tentativa" value="'.esc_attr(self::token()).'">';
    }
    private static function valid(string $token): bool {
        if(!preg_match('/^(\d{10})-([0-9a-f]{32})-([0-9a-f]{40})$/D',$token,$m))return false;
        return (int)$m[1]<=time()&&(int)$m[1]+self::TTL>time()&&hash_equals(self::sign($m[1].'-'.$m[2]),$m[3]);
    }
    private static function prune(): void {
        global $wpdb;
        // Only our expired, tiny claims. Private rendered results use expiring encrypted transients.
        $names=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name BETWEEN %s AND %s ORDER BY option_name LIMIT 32",self::PREFIX.'0000000000',self::PREFIX.(time()-self::TTL).'-z'));
        foreach($names as $name)delete_option($name);
    }
    public static function state(): array {
        $token=Admin::text($_GET,'tentativa');if($token==='')return [];
        if(!self::valid($token))return ['message'=>'Esta tentativa expirou ou pertence a outra sessão. Reabra a seção e confira o estado atual.'];
        if(Admin::text($_GET,'alterada')==='1')return ['message'=>'Este formulário já foi enviado com outros dados. Revise os valores em vigor e use o formulário atual.'];
        $sealed=get_transient(self::PREFIX.$token);
        if(!is_string($sealed))return ['message'=>'O resultado desta tentativa ainda não está disponível ou expirou. Atualizar esta página não repete a ação. Confira o diário antes de iniciar outra tentativa.'];
        try{return Support::open($sealed);}catch(Fault){return ['message'=>'Não foi possível reler esta tentativa. Confira o diário.'];}
    }
    /** Returns a local redirect target so native WP and integration tests use the same controller. */
    public static function submit(): string {
        Support::admin();
        $post=$_POST;$action=Admin::text($post,'f3_pipedrive_action');
        $nonce=match($action){
            'rules_validate','rules_simulate','rules_rows','rules_catalog'=>'f3pd_rules_edit',
            'rules_apply'=>'f3pd_apply_'.Admin::text($post,'previa_id'),
            'retention'=>'f3_pipedrive_retention',
            'recovery_preview','recovery_confirm'=>'f3_pd_recovery',
            default=>null
        };
        if($nonce===null)wp_die('Ação administrativa desconhecida.','',['response'=>400]);
        check_admin_referer($nonce);
        $token=Admin::text($post,'f3pd_tentativa');
        if(!self::valid($token))wp_die('Este formulário expirou. Volte à configuração e confira a versão em vigor antes de enviar.','',['response'=>403,'back_link'=>true]);
        $tab=str_starts_with($action,'rules_')?'regras':'diario';$query=['tentativa'=>$token];
        if($tab==='regras')$query['modo']=Admin::text($post,'modo')==='json'?'json':'guiado';
        self::prune();
        $key=self::PREFIX.substr($token,0,43);
        $data=$post;unset($data['_wpnonce'],$data['_wp_http_referer']);
        $digest=Support::digest($data);
        try{
            $claimed=Workflows::lock('form:'.$key,static function()use($key,$digest){
                $existing=get_option($key,false);
                if($existing!==false)return is_string($existing)&&hash_equals($existing,$digest)?'replay':'conflict';
                if(!add_option($key,$digest,'',false))throw new Fault('formulario_ocupado','A tentativa já foi iniciada; confira o resultado.');
                return 'new';
            });
        }catch(Fault){$claimed='replay';}
        if($claimed==='conflict')$query['alterada']='1';
        if($claimed==='new'){
            try{
                if($tab==='regras')$state=AdminRules::post($action,$post);
                elseif($action==='retention'){
                    $days=Admin::text($post,'diario_dias');
                    $r=Api::dispatch('retencao-configurar',['diario_dias'=>ctype_digit($days)&&strlen($days)<=5?(int)$days:$days,'revisao_esperada'=>Admin::text($post,'revisao_esperada'),'confirmar_expurgo'=>Admin::text($post,'confirmar_expurgo')==='1']);
                    $state=['message'=>$r['message'],'ok'=>$r['success']];
                }else $state=AdminRecovery::post($action,$post);
            }catch(Fault $e){$state=['message'=>$e->getMessage()];}
            catch(\Throwable){$state=['message'=>'A tentativa foi interrompida. Confira o diário antes de retomar.'];}
            set_transient(self::PREFIX.$token,Support::seal($state),15*MINUTE_IN_SECONDS);
        }
        return Admin::url($tab,$query);
    }
    public static function handle(): void {
        if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')return;
        wp_safe_redirect(self::submit(),303);exit;
    }
}
