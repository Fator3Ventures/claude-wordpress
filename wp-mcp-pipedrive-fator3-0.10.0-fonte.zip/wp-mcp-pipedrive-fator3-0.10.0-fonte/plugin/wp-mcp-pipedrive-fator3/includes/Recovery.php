<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Local reconciliation. Provider access is exclusively GET; no "release anyway". */
final class Recovery {
    public static function schemas(): array {
        $obj=static fn($fields,$required=[])=>['type'=>'object','properties'=>$fields,'required'=>$required,'additionalProperties'=>false];
        $id=['type'=>'string','pattern'=>'^[a-f0-9]{32}$'];
        return [
            'pendencias-ler'=>$obj(['limite'=>['type'=>'integer','minimum'=>1,'maximum'=>50],'apos_id'=>['type'=>'integer','minimum'=>0]]),
            'recuperacao-previa'=>$obj(['origem_id'=>$id+['description'=>'ID da operação que deixou o bloqueio; escolha somente um identificador.'],'lead_id'=>['type'=>'string','pattern'=>'^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$','description'=>'Lead cujo progresso já confirmado diverge após edição da nota.']]),
            'recuperacao-confirmar'=>$obj(['previa_id'=>$id,'confirmacao'=>['type'=>'string','minLength'=>1,'maxLength'=>200]],['previa_id','confirmacao'])];
    }
    public static function descriptions(): array {return [
        'pendencias-ler'=>'Lista bloqueios do operador na conta e autorização atuais, sem HTTP e sem alterar o estado.',
        'recuperacao-previa'=>'Confira um bloqueio ou divergência usando GET na conta. Somente uma solução comprovada gera prévia local de 15 minutos.',
        'recuperacao-confirmar'=>'Revalida conta, regras, recibo e registro e confirma a resolução no WordPress. Nunca repete a escrita no Pipedrive.'];}
    public static function writes(string $op): bool {return in_array($op,['recuperacao-previa','recuperacao-confirmar'],true);}
    public static function dispatch(string $op,array $i): array {Support::admin();return match($op){
        'pendencias-ler'=>self::listing($i),'recuperacao-previa'=>self::preview($i),'recuperacao-confirmar'=>self::confirm($i)
    };}
    private static function ok(string $code,string $message,array $data): array {return ['success'=>true,'code'=>$code,'message'=>$message,'data'=>$data];}
    private static function unknown(string $why): never {throw new Fault('recuperacao_inconclusiva',$why.' O bloqueio ou progresso anterior foi preservado.');}
    private static function scope(array $s,string $kind,string $id): string {return Support::digest($s['conta']).':'.$kind.':'.strtolower($id);}
    private static function phrase(string $id): string {return 'Confirmo a recuperação local da prévia '.$id;}
    /** Authenticated intent saved before the first write; no Pipedrive note or reason content in the journal. */
    public static function intent(string $id,array $p,array $snapshot,array $s,array $c,int $time,?string $expectedNote): array {
        $op=$p['workflow'];$in=$p['input'];$lead=$snapshot['registro'];$a=$snapshot['atividade']??null;
        $proof=['id'=>$id,'binding'=>CoreClient::binding($s),'op'=>$op,'target'=>(string)($in['lead_id']??$in['negocio_id']),
            'before'=>Support::digest($snapshot),'time'=>$time];
        if($op==='negocio-perder')$proof['reason']=Support::digest($in['lost_reason']);
        elseif($op==='lead-arquivado-editar'){
            $proof['reason']=Support::digest($lead['archive_reason']);$proof['archive_before']=$lead['archive_time'];$proof['fields']=[];
            foreach($in['campos'] as $key=>$v)$proof['fields'][$key]=Support::digest($v);
        }else{
            $proof+=['type'=>$c['tipo_whatsapp'],'previous_activity'=>$a?(int)$a['id']:null,'person'=>$a?null:($lead['person_id']??null),
                'note'=>Progress::noteDigest($expectedNote)];
            if($op==='whatsapp-registrar'){$proof['touch']=$in['toque'];$proof['note_layout']=WhatsAppNote::layoutDigest($expectedNote);}
            else $proof['reason']=Support::digest($in['archive_reason']);
        }
        return $proof;
    }
    private static function markers(array $s,int $after,int $limit,?string $id=null): array {
        global $wpdb;$ops=Store::table('ops');$journal=Store::table('journal');
        $sql="SELECT p.option_id,p.option_name,p.option_value AS operation_id,o.binding,o.state,o.payload,o.result,j.metadata
              FROM {$wpdb->options} p JOIN $ops o ON o.previa_id=p.option_value LEFT JOIN $journal j ON j.previa_id=o.previa_id
              WHERE p.option_name LIKE %s AND p.option_id>%d AND o.actor_id=%d";
        $args=[$wpdb->esc_like(Store::PENDING_PREFIX).'%', $after,get_current_user_id()];
        if($id!==null){$sql.=' AND o.previa_id=%s';$args[]=$id;}
        $args[]=$limit;$rows=$wpdb->get_results($wpdb->prepare($sql.' ORDER BY p.option_id LIMIT %d',...$args),ARRAY_A);
        if(!is_array($rows)||$wpdb->last_error!=='')throw new Fault('armazenamento_indisponivel','Não foi possível consultar as pendências locais.');
        return $rows;
    }
    private static function decode(array $m,array $s): array {
        $meta=json_decode($m['metadata']??'',true);$auth=null;
        if(is_string($meta['prova_recuperacao']??null)){
            try{$v=Support::open($meta['prova_recuperacao']);if(($v['id']??null)===$m['operation_id']&&($v['binding']??null)===$m['binding'])$auth=$v;}catch(Fault $e){}
        }
        $entity=$auth?[($auth['op']==='negocio-perder'?'deal':'lead'),$auth['target']]:Store::legacyEntity($m);
        $op=$auth['op']??null;
        if($entity){
            [$kind,$id]=$entity;$scope=self::scope($s,$kind,$id);
            $original=Support::digest($s['conta']).':'.$kind.':'.$id;
            if(!in_array($m['option_name'],[Store::CANONICAL_PENDING.hash('sha256',$scope),Store::PENDING_PREFIX.hash('sha256',$scope),Store::PENDING_PREFIX.hash('sha256',$original)],true)){$entity=null;$auth=null;$op=null;}
            elseif(!$op){$op=str_replace('pipedrive/','',(string)($meta['caminho']??''));if(!in_array($op,['whatsapp-registrar','lead-encerrar','lead-arquivado-editar','negocio-perder'],true))$op=null;}
        }
        $steps=[];foreach($meta['etapas']??[] as $v)if(is_array($v))$steps[]=array_intersect_key($v,array_flip(['etapa','success','code','http_status','remote_dispatched']));
        return [$entity,$auth,$op,$steps];
    }
    private static function listing(array $i): array {
        $s=CoreClient::status();$limit=$i['limite']??20;$after=$i['apos_id']??0;$items=[];$more=false;
        // A version/authorization change can replace the binding. Never expose a historical
        // case unless its authenticated entity and marker hash prove this account.
        $rows=self::markers($s,$after,101);$more=count($rows)>100;
        foreach(array_slice($rows,0,100) as $m){
            [$entity,$auth,$op,$steps]=self::decode($m,$s);
            if(!$entity&&$m['binding']!==CoreClient::binding($s)){$after=(int)$m['option_id'];continue;}
            if(count($items)===$limit){$more=true;break;}
            $after=(int)$m['option_id'];
            $items[]=['origem_id'=>$m['operation_id'],'entidade'=>$entity[0]??null,'registro_id'=>$entity[1]??null,'operacao'=>$op,'etapas'=>$steps,
                'situacao'=>$entity===null?'alvo_nao_identificavel':($auth?'disponivel_para_conferencia':'sem_prova_de_intencao')];
        }
        return self::ok('ok','Bloqueios locais desta conta e administrador. Divergência de nota é conferida por lead.',['itens'=>$items,'proximo_apos_id'=>$more?$after:null]);
    }
    private static function target(array $i,array $s): array {
        if((isset($i['origem_id'])?1:0)+(isset($i['lead_id'])?1:0)!==1)throw new Fault('entrada_invalida','Informe apenas origem_id ou lead_id.');
        if(isset($i['lead_id']))return ['lead',strtolower($i['lead_id']),null,null,null,[]];
        $rows=self::markers($s,0,2,$i['origem_id']);
        if(count($rows)!==1)self::unknown('Não há um único marcador identificável para a operação no escopo atual.');
        [$entity,$proof,$op,$steps]=self::decode($rows[0],$s);if(!$entity||!$proof)self::unknown('A tentativa anterior não preservou toda a evidência de intenção necessária.');
        return [$entity[0],strtolower($entity[1]),$rows[0],$proof,$op,$steps];
    }
    private static function activity(Collection $r,string $lead,string $type): ?array {
        $list=$r->all('/api/v2/activities',['lead_id'=>$lead]);$r->complete();
        $found=[];foreach($list as $row){
            if(!is_string($row['lead_id']??null)||strcasecmp($row['lead_id'],$lead)!==0||!is_string($row['type']??null))self::unknown('A listagem retornou atividade sem identidade de lead e tipo verificáveis.');
            if($row['type']===$type)$found[]=$row;
        }
        if(count($found)>1)self::unknown('Há mais de uma atividade do tipo esperado.');
        if(!$found)return null;
        $a=$r->one('/api/v2/activities/'.(int)$found[0]['id']);
        if(!is_string($a['lead_id']??null)||strcasecmp($a['lead_id'],$lead)!==0||($a['type']??null)!==$type||!is_string($a['note']??null)||!is_bool($a['done']??null))self::unknown('O detalhe da atividade não confirmou vínculo, nota e conclusão.');
        return $a;
    }
    private static function check(array $request,array $s): array {
        [$kind,$id,$marker,$proof,$op,$steps]=self::target($request,$s);$revision=Configuration::read();$c=$revision['regras'];$reader=new Collection();
        if(CoreClient::binding($reader->status)!==CoreClient::binding($s))throw new Fault('contexto_alterado','A conta mudou durante a releitura.');
        $progress=null;$activity=null;
        $record=$reader->one(($kind==='deal'?'/api/v2/deals/':'/v1/leads/').$id);
        if(!$marker){
            Workflows::checkPending(self::scope($s,$kind,$id));
            $p=Progress::stored($s['conta'],$id);if(!$p||!is_string($p['receipt_id']??null))self::unknown('O lead não tem progresso local comprovado.');
            $origin=Store::get($p['receipt_id']);
            if(!in_array($origin['state'],['done','running'],true))self::unknown('O recibo anterior não comprova a operação.');
            if(isset($p['validated_by'])){
                // This value only enters the authenticated, account/lead-bound progress envelope
                // inside our successful resolution transaction. The ordinary audit receipt may expire.
                if(!is_string($p['validated_by'])||!preg_match('/^[0-9a-f]{32}$/D',$p['validated_by']))self::unknown('A decisão anterior não está identificada.');
                $entity=Store::legacyEntity($origin+['operation_id'=>$p['receipt_id']]);
                if($entity===null||$entity[0]!=='lead'||strcasecmp($entity[1],$id)!==0)self::unknown('A origem não identifica este lead.');
            }else{
                if($origin['state']!=='done')self::unknown('O recibo anterior não confirmou o desfecho.');
                $receipt=Store::receiptFor($origin,'whatsapp-registrar');
                if(!$receipt['success']||strcasecmp((string)($receipt['data']['id']??''),$id)!==0||(int)($receipt['data']['atividade_id']??0)!==$p['activity_id'])self::unknown('O recibo não confirma o último toque e a atividade.');
            }
            if(!in_array($p['touch'],array_column($c['toques'],'codigo'),true)||($record['is_archived']??null)!==false||$c['tipo_whatsapp']==='')self::unknown('Regras ou estado do lead são incompatíveis com o progresso.');
            $activity=self::activity($reader,$id,$c['tipo_whatsapp']);
            if(!$activity||(int)$activity['id']!==$p['activity_id']||$activity['done'])self::unknown('Atividade ausente, substituída ou concluída.');
            $new=Progress::noteDigest($activity['note']);if(hash_equals($new,$p['note_digest']))self::unknown('A nota já corresponde ao progresso confirmado.');
            $outcome='realinhar_nota';$progress=$p;$progress['note_digest']=$new;$original=$p['receipt_id'];$op='whatsapp-registrar';$markerName=null;
        }else{
            $original=$marker['operation_id'];$markerName=$marker['option_name'];
            $snapshot=['registro'=>$record];$ok=false;
            if($op==='negocio-perder')$ok=($record['status']??null)==='lost'&&array_key_exists('lost_reason',$record)&&Support::digest($record['lost_reason'])===$proof['reason'];
            elseif($op==='lead-arquivado-editar'){
                // An initially archived lead may already show the desired fields when the FIRST
                // unarchive is still uncertain. That same snapshot cannot prove a completed cycle.
                $byStep=array_column($steps,null,'etapa');
                $archive=$byStep['rearquivar']??[];
                $newArchive=isset($record['archive_time'])&&Collection::instant($record['archive_time'])!==null&&$record['archive_time']!==$proof['archive_before'];
                $ok=($byStep['desarquivar']['success']??false)===true
                    &&($byStep['editar']['remote_dispatched']??null)===true
                    &&($archive['remote_dispatched']??null)===true&&(($archive['success']??false)===true||$newArchive)
                    &&($record['is_archived']??null)===true&&isset($record['archive_reason'])&&Support::digest($record['archive_reason'])===$proof['reason'];
                foreach($proof['fields'] as $key=>$hash)if(!array_key_exists($key,$record)||Support::digest($record[$key])!==$hash)$ok=false;
            }elseif(in_array($op,['whatsapp-registrar','lead-encerrar'],true)){
                if($c['tipo_whatsapp']!==$proof['type'])self::unknown('O tipo de atividade configurado mudou.');
                $activity=self::activity($reader,$id,$proof['type']);$snapshot['atividade']=$activity;
                $ok=$activity!==null&&$activity['done']===($op==='lead-encerrar')&&Progress::noteDigest($activity['note'])===$proof['note'];
                if($ok&&isset($proof['note_layout']))$ok=hash_equals($proof['note_layout'],WhatsAppNote::layoutDigest($activity['note']));
                if($ok&&$proof['previous_activity']!==null)$ok=(int)$activity['id']===$proof['previous_activity'];
                elseif($ok){
                    $primary=array_values(array_filter((array)($activity['participants']??[]),static fn($v)=>is_array($v)&&($v['primary']??$v['primary_flag']??false)===true));
                    $ok=count($primary)===1&&(int)($primary[0]['person_id']??0)===$proof['person']&&(int)($activity['person_id']??0)===$proof['person'];
                }
                if($ok&&$op==='lead-encerrar')$ok=($record['is_archived']??null)===true&&isset($record['archive_reason'])&&Support::digest($record['archive_reason'])===$proof['reason'];
                if($ok&&$op==='whatsapp-registrar'){
                    $ok=($record['is_archived']??null)===false&&in_array($proof['touch'],array_column($c['toques'],'codigo'),true);
                    if($ok)$progress=Progress::prepare($s['conta'],$id,$activity,$proof['touch'],$proof['time'],$original);
                }
            }
            if($ok)$outcome='efeito_confirmado';
            elseif($steps&&count(array_filter($steps,static fn($v)=>($v['remote_dispatched']??null)===false))===count($steps)&&Support::digest($snapshot)===$proof['before'])$outcome='nao_despachado';
            else self::unknown('A conta não confirma o efeito integral nem há prova de que nenhuma etapa foi despachada.');
        }
        $reader->complete();if(CoreClient::binding(CoreClient::status())!==CoreClient::binding($s))throw new Fault('contexto_alterado','A conta mudou durante a conferência.');
        $data=['entidade'=>$kind,'registro_id'=>$id,'origem_id'=>$original,'operacao'=>$op,'resolucao'=>$outcome,'toque_preservado'=>$progress['touch']??null,'atividade_id'=>$activity['id']??null];
        return ['resumo'=>$data,'marker'=>$markerName,'progress'=>$progress,'revision'=>$revision['revisao'],
            'digest'=>Support::digest([$data,$markerName,$revision['revisao'],$record,$activity,$progress,isset($p)?$p:null,$steps])];
    }
    private static function preview(array $i): array {
        Store::ready();$s=CoreClient::status();Store::maybeCleanup();[$kind,$id]=self::target($i,$s);
        return Workflows::lock(self::scope($s,$kind,$id),static function()use($s,$i){
            $checked=self::check($i,$s);$id=bin2hex(random_bytes(16));$phrase=self::phrase($id);
            Store::create($id,CoreClient::binding($s),['workflow'=>'recuperacao','request'=>$i,'digest'=>$checked['digest'],'scope'=>[$checked['resumo']['entidade'],$checked['resumo']['registro_id']]]);
            return self::ok('recuperacao_revisada','Confira o registro e o desfecho. A confirmação modifica somente o estado local.',
                $checked['resumo']+['previa_id'=>$id,'confirmacao_exigida'=>$phrase,'validade_segundos'=>900]);
        });
    }
    private static function replay(array $row,string $id): array {
        $result=Support::open($row['result']);
        if(($result['code']??null)!=='recuperacao_confirmada'||($result['previa_id']??null)!==$id)throw new Fault('operacao_invalida','O recibo pertence a outra operação.');
        return $result;
    }
    private static function confirm(array $i): array {
        Store::ready();$s=CoreClient::status();$id=$i['previa_id'];$binding=CoreClient::binding($s);
        $row=Store::get($id);
        if(!hash_equals($row['binding'],$binding))throw new Fault('contexto_alterado','A conta ou a autorização mudou.');
        if(!hash_equals(self::phrase($id),$i['confirmacao']))throw new Fault('confirmacao_ausente','Use a confirmação exata da prévia de recuperação.');
        if($row['state']==='done')return self::replay($row,$id);
        if($row['state']!=='ready'||(int)$row['expires']<=time())throw new Fault('previa_expirada','A prévia de recuperação não está mais disponível.');
        Store::maybeCleanup();$p=Support::open($row['payload']);if(($p['workflow']??null)!=='recuperacao')throw new Fault('operacao_invalida','A prévia pertence a outra operação.');
        return Workflows::lock(self::scope($s,$p['scope'][0],$p['scope'][1]),static function()use($id,$s,$binding,$p){
            $row=Store::get($id);if($row['state']==='done')return self::replay($row,$id);
            $current=self::check($p['request'],$s);
            if(!hash_equals($current['digest'],$p['digest']))throw new Fault('estado_alterado','O estado difere da prévia. Refaça a conferência.');
            return Configuration::withRevision($current['revision'],static fn()=>self::commit($id,$binding,Support::digest($s['conta']),$current));
        });
    }
    private static function commit(string $id,string $binding,string $accountDigest,array $verified): array {
        global $wpdb;$ops=Store::table('ops');$journal=Store::table('journal');$marker=$verified['marker'];$data=$verified['resumo'];
        if($marker!==null){
            $engine=$wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS WHERE Name = %s',$wpdb->options),ARRAY_A);
            if(strcasecmp((string)($engine['Engine']??''),'InnoDB')!==0)throw new Fault('armazenamento_indisponivel','As opções precisam aceitar transações antes de liberar o marcador.');
        }
        $result=self::ok('recuperacao_confirmada','Resolução registrada no WordPress. Nenhuma escrita foi enviada ao Pipedrive.',$data)+['previa_id'=>$id];
        $audit=['previa_id'=>$id,'caminho'=>'pipedrive/recuperacao-confirmar','metodo'=>'LOCAL','classe'=>'registro','status'=>'recuperacao_confirmada','ator_id'=>get_current_user_id(),'conta_resumo'=>$accountDigest]+$data;
        $sealed=Support::seal($result);
        if($wpdb->query('START TRANSACTION')===false)throw new Fault('armazenamento_indisponivel','Falha ao iniciar a transação local.');
        try{
            $n=$wpdb->query($wpdb->prepare("UPDATE $ops SET state='done',result=%s,payload='' WHERE previa_id=%s AND state='ready' AND expires>%d AND binding=%s AND actor_id=%d",
                $sealed,$id,time(),$binding,get_current_user_id()));
            if($n!==1)throw new Fault('previa_expirada','A prévia expirou ou foi consumida.');
            if($verified['progress']!==null){
                $cursor=$verified['progress'];$cursor['validated_by']=$id;Progress::persist($cursor);
            }
            if($wpdb->insert($journal,['previa_id'=>$id,'created'=>time(),'metadata'=>Support::json($audit)])!==1)throw new Fault('persistencia_falhou','Não foi possível registrar a decisão.');
            if($marker!==null&&$wpdb->delete($wpdb->options,['option_name'=>$marker,'option_value'=>$data['origem_id']])!==1)throw new Fault('estado_alterado','O marcador mudou antes da confirmação.');
            if($wpdb->query('COMMIT')===false)throw new Fault('persistencia_incerta','Confirmação local incerta. Reconsulte a mesma prévia.');
        }catch(\Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
        if($marker!==null){wp_cache_delete($marker,'options');wp_cache_delete('alloptions','options');wp_cache_delete('notoptions','options');}
        return self::replay(Store::get($id),$id);
    }
}
