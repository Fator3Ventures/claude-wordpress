<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Published handshake; no fallback to Core private options or HTTP. */
final class CoreClient {
    private static ?object $client = null;
    private static string $registration = 'core_indisponivel';
    public static function register($registry, $contract = null): void {
        if ($contract !== CONTRACT || !is_object($registry) || !is_callable([$registry,'register_consumer'])) { return; }
        try {
            $client = $registry->register_consumer(SLUG, VERSION, CONTRACT, static fn()=>['ready'=>true,'revision'=>VERSION,'provider'=>SLUG]);
            if (is_wp_error($client) || !is_object($client)) { return; }
            foreach (['capabilities','status','request'] as $method) {
                if (!is_callable([$client,$method])) { return; }
            }
            $caps = $client->capabilities();
            if (!is_array($caps) || ($caps['contract'] ?? '') !== CONTRACT) { return; }
            self::$client = $client; self::$registration = 'registrado';
        } catch (\Throwable $e) { self::$registration = 'contrato_invalido'; }
    }
    public static function registration(): string { return self::$registration; }
    private static function client(): object {
        if (!self::$client) { throw new Fault('core_indisponivel','O Site Core ainda não forneceu o contrato pipedrive-api-client/1.0.0 compatível.'); }
        return self::$client;
    }
    public static function status(): array {
        Support::admin();
        try { $raw = self::client()->status(); }
        catch (Fault $e) { throw $e; }
        catch (\Throwable $e) { throw new Fault('contrato_invalido','Não foi possível ler o estado do cliente Core.'); }
        $r = Support::guardResult($raw); $d = $r['data'] ?? null;
        if (!is_array($d) || ($d['contract'] ?? null) !== CONTRACT) { throw new Fault('contrato_invalido','Contrato de status incompatível.'); }
        if (($d['autorizado'] ?? false) !== true) { throw new Fault('operacao_nao_autorizada',Support::message('operacao_nao_autorizada')); }
        $account = $d['conta'] ?? [];
        if (!is_array($account) || !is_numeric($account['conta_id'] ?? null) || !is_numeric($account['usuario_id'] ?? null)
            || !is_string($account['dominio'] ?? null) || !preg_match('/^[a-z0-9-]+\.pipedrive\.com$/D', $account['dominio'])
            || !is_string($d['revisao'] ?? null) || $d['revisao'] === '' || strlen($d['revisao']) > 200) {
            throw new Fault('contrato_invalido','Identidade ou revisão ausente no status do Core.');
        }
        $budget = $d['orcamento'] ?? [];
        foreach (['teto','consumido','reservado'] as $key) {
            if (!is_int($budget[$key] ?? null) || $budget[$key] < 0) { throw new Fault('contrato_invalido','Orçamento incompatível no status do Core.'); }
        }
        return ['contract'=>CONTRACT,'autorizado'=>true,'conta'=>array_intersect_key($account,array_flip(['dominio','conta_id','usuario_id'])),
            'revisao'=>$d['revisao'],'orcamento'=>array_intersect_key($budget,array_flip(['teto','consumido','reservado'])),
            'saldo_conta'=>self::balance($d['saldo_conta'] ?? null)];
    }
    public static function balance($b): ?array {
        if ($b === null) { return null; }
        if (!is_array($b) || !is_int($b['restante'] ?? null) || $b['restante'] < 0 || !is_string($b['lido_em'] ?? null)
            || !preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|\+00:00)$/D',$b['lido_em'])) { return null; }
        return ['restante'=>$b['restante'],'lido_em'=>$b['lido_em']];
    }
    public static function binding(array $s): string { return Support::digest([$s['conta'],$s['revisao'],get_current_blog_id(),home_url('/')]); }
    public static function request(string $method, string $path, array $query, array $body, array $status, ?string $preview = null): array {
        Support::admin();
        $current = self::status();
        if (!hash_equals(self::binding($status),self::binding($current))) { throw new Fault('contexto_alterado',Support::message('contexto_alterado')); }
        $context = ['provider'=>SLUG,'consumer'=>'operacao','contract'=>CONTRACT,'actor_id'=>get_current_user_id(),'revisao_esperada'=>$current['revisao']];
        if ($preview !== null) { $context['previa_id'] = $preview; }
        try { $raw = self::client()->request($method,$path,$query,$body,$context); }
        catch (\Throwable $e) {
            return ['success'=>false,'code'=>'resultado_incerto','message'=>'O cliente interrompeu a resposta. Reconcilie o efeito antes de qualquer nova escrita.','data'=>['http_status'=>null,'body'=>null,'saldo_conta'=>null],'remote_dispatched'=>null];
        }
        if (is_wp_error($raw)) {
            // WP_Error without explicit transport evidence is uncertain for writes.
            $code = Support::knownCode((string)$raw->get_error_code());
            $info = $raw->get_error_data();
            $sent = is_array($info) && ($info['remote_dispatched'] ?? null) === false ? false : null;
            return ['success'=>false,'code'=>$sent === false ? $code : 'resultado_incerto','message'=>Support::message($code),'data'=>['http_status'=>null,'body'=>null,'saldo_conta'=>null],'remote_dispatched'=>$sent];
        }
        if (!is_array($raw) || !is_bool($raw['success'] ?? null)) {
            return self::uncertain();
        }
        $d = $raw['data'] ?? [];
        if (!is_array($d)) { return self::uncertain(); }
        $http = $d['http_status'] ?? null;
        $sent = $raw['remote_dispatched'] ?? null;
        if ($sent === false && !$raw['success']) {
            $code = Support::knownCode((string)($raw['code'] ?? ''));
            return ['success'=>false,'code'=>$code,'message'=>Support::message($code),'data'=>['http_status'=>null,'body'=>null,'saldo_conta'=>self::balance($d['saldo_conta'] ?? null)],'remote_dispatched'=>false];
        }
        // A transport receipt proves dispatch. A successful HTTP status alone does not prove a mutation.
        if (!is_int($http) || $http < 100 || $http > 599 || $sent !== true || !array_key_exists('body',$d)) {
            return self::uncertain();
        }
        $data = ['http_status'=>$http, 'body'=>null, 'saldo_conta'=>self::balance($d['saldo_conta'] ?? null)];
        $upstream = $raw['code'] ?? '';
        $okHttp = $http >= 200 && $http < 300;
        $body = $d['body'];
        $validBody = $http === 204 || (is_array($body) && array_key_exists('data',$body) && ($body['success'] ?? true) === true);
        if ($upstream === 'resposta_excedeu_limite') {
            $code = 'resposta_excedeu_limite';
        } elseif (!$raw['success'] || !$okHttp || !$validBody) {
            // A 2xx response with unreadable content, a timeout, or an explicit Core uncertainty
            // must keep the entity pinned. Never echo an upstream error body.
            $definitive = $http >= 400 && $http < 500 && $http !== 408 && $upstream !== 'resultado_incerto';
            $code = $definitive ? 'fornecedor_recusou' : 'resultado_incerto';
        } else {
            $safe = Support::safe($body);
            if (strlen(Support::json($safe)) <= 524288) {
                $data['body'] = $safe;
                return ['success'=>true,'code'=>'ok','message'=>'Operação concluída.','data'=>$data,'remote_dispatched'=>true];
            }
            $code = 'resposta_excedeu_limite';
        }
        $message = match ($code) {
            'resposta_excedeu_limite'=>'Resposta maior que 512 KiB. Reduza a página de leitura; em escrita, reconcilie antes de repetir.',
            'resultado_incerto'=>'A requisição foi despachada, mas o resultado não foi confirmado.',
            default=>'O fornecedor recusou a requisição. Consulte o status HTTP.'
        };
        return ['success'=>false,'code'=>$code,'message'=>$message,'data'=>$data,'remote_dispatched'=>true];
    }
    private static function uncertain(): array {
        return ['success'=>false,'code'=>'resultado_incerto','message'=>'Resposta incompatível; reconcilie antes de nova escrita.','data'=>['http_status'=>null,'body'=>null,'saldo_conta'=>null],'remote_dispatched'=>null];
    }
}
