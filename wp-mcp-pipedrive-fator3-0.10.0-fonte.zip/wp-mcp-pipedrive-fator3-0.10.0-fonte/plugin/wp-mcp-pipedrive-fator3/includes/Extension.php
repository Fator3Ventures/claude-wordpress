<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
final class Extension {
    public static function schemas(): array {
        $o=static fn($p=[],$r=[])=>['type'=>'object','properties'=>$p,'required'=>$r,'additionalProperties'=>false];
        $id=['type'=>'string','pattern'=>'^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$'];$hash=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        $read=['max_chamadas'=>['type'=>'integer','minimum'=>1,'maximum'=>120],'tempo_maximo_segundos'=>['type'=>'integer','minimum'=>1,'maximum'=>120]];
        $clock=['agora'=>['type'=>'string','pattern'=>'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$','description'=>'Instante de simulação/leitura; não altera o relógio de escrita.']];
        $message=['type'=>'string','minLength'=>1,'maxLength'=>4000];
        static $schemas;
        return $schemas??=[
            'configuracao-ler'=>$o(),
            'configuracao-simular'=>$o(['regras'=>Configuration::schema(),'revisao_esperada'=>$hash]+$clock+$read,['regras','revisao_esperada']),
            'operacao-aplicar'=>$o(['previa_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{32}$'],'confirmacao'=>['type'=>'string','maxLength'=>500]],['previa_id']),
            'cadencia-fila'=>$o(['limite'=>['type'=>'integer','minimum'=>1,'maximum'=>200,'description'=>'Máximo de leads avaliados por página (padrão 200).'],
                'filtro'=>['type'=>'string','enum'=>['todos','devidos'],'description'=>'Filtra a apresentação, sem alterar o ponto de continuação.'],
                'cursor'=>['type'=>'string','minLength'=>1,'maxLength'=>2048,'description'=>'Cursor devolvido pela página anterior; use em até 15 minutos.']]+$clock+$read),
            'whatsapp-registrar'=>$o(['lead_id'=>$id,'mensagem'=>$message,'proximo'=>['type'=>'string','minLength'=>1,'maxLength'=>4000,'description'=>'Obrigatório para gravar: o que dizer no próximo contato. Omita apenas ao consultar um recibo anterior à 0.10.0.'],'autor'=>['type'=>'string','minLength'=>1,'maxLength'=>80,'description'=>'Nome do contato, quando necessário. Na ausência usa o autor configurado (padrão: nós).'],'toque'=>['type'=>'string','pattern'=>'^[a-z0-9_-]{1,40}$'],'chave_idempotencia'=>['type'=>'string','minLength'=>8,'maxLength'=>128]],['lead_id','mensagem','toque','chave_idempotencia']),
            'lead-encerrar'=>$o(['lead_id'=>$id,'mensagem'=>$message,'archive_reason'=>['type'=>'string','minLength'=>1,'maxLength'=>500]],['lead_id','mensagem','archive_reason']),
            'negocio-perder'=>$o(['negocio_id'=>['type'=>'integer','minimum'=>1],'lost_reason'=>['type'=>'string','minLength'=>1,'maxLength'=>500]],['negocio_id','lost_reason']),
            'lead-arquivado-editar'=>$o(['lead_id'=>$id,'campos'=>['type'=>'object','minProperties'=>1,'description'=>'Lista de corpo do lead da API; is_archived e archive_reason são reservados à operação.']],['lead_id','campos']),
            'auditoria'=>$o($clock+$read),
            'contar-por-campo'=>$o(['entidade'=>['type'=>'string','enum'=>['leads','negocios','pessoas','organizacoes']],'campo'=>['type'=>'string','pattern'=>'^(?:[a-f0-9]{40}|[a-z][a-z0-9_]{0,49})$']]+$read,['entidade','campo'])
        ]+Recovery::schemas();
    }
    public static function writes(string $op): bool {if(isset(Recovery::schemas()[$op]))return Recovery::writes($op);return !in_array($op,['configuracao-ler','cadencia-fila','auditoria','contar-por-campo'],true)&&isset(self::schemas()[$op]);}
    public static function descriptions(): array {return [
        'configuracao-ler'=>'Regras operacionais e revisão; leitura local sem inicialização automática.',
        'configuracao-simular'=>'Simula as regras em até 20 leads visíveis; mostra alcance e custo e cria prévia local por 15 minutos. Salvar exige a frase de ordem do dono via operacao-aplicar.',
        'operacao-aplicar'=>'Aplica prévia composta uma vez; revalida conta, regras e estado. Recibo por etapas e bloqueio de efeitos incertos.',
        'cadencia-fila'=>'Página de leads avaliados, próxima ação e motivo. O filtro de devidos pode retornar página vazia com continuação. Falha na leitura não libera itens.',
        'whatsapp-registrar'=>'Registra uma mensagem já enviada. Informe proximo em toda escrita nova: a nota começa com [IA] e termina com Próximo:. A chave permanente protege contra repetição.',
        'lead-encerrar'=>'Prévia: linha final, concluir atividade e arquivar com motivo aprovado. Aplique com operacao-aplicar.',
        'negocio-perder'=>'Prévia de perda de negócio com motivo da option; lista vazia exige configuração aprovada. Aplique com operacao-aplicar.',
        'lead-arquivado-editar'=>'Prévia de desarquivar, editar e rearquivar com motivo original; datas no recibo e tentativa de rearquivar após erro.',
        'auditoria'=>'Anomalias por IDs e regras, sem nome, e-mail, telefone ou título. Regras/prazos configuráveis e cobertura explícita.',
        'contar-por-campo'=>'Contagem paginada de leads/negócios inclusive arquivo, pessoas ou organizações. Opções por IDs e texto livre em HMAC; vazios, completude e custo.'
    ]+Recovery::descriptions();}
    public static function dispatch(string $op,array $i): array {if(isset(Recovery::schemas()[$op]))return Recovery::dispatch($op,$i);return match($op){
        'configuracao-ler'=>['success'=>true,'code'=>'ok','message'=>'Configuração local.','data'=>Configuration::read()],
        'configuracao-simular'=>Workflows::simulate($i),'operacao-aplicar'=>Workflows::apply($i),
        'cadencia-fila'=>Cadence::queue($i),'whatsapp-registrar'=>Workflows::whatsapp($i),
        'lead-encerrar','negocio-perder','lead-arquivado-editar'=>Workflows::preview($op,$i),
        'auditoria'=>Insights::audit($i),'contar-por-campo'=>Insights::count($i)
    };}
}
