# Fator3 MCP 0.45.0

Servidor MCP para WordPress. Consulte e atualize o SEO de categorias e tags em `content/get-term-seo` e `content/update-term-seo`. Veja o procedimento de backup e verificação em **Ajuda → Termos**. Acesse **Ferramentas → Fator3 MCP** para conectar um cliente, definir o perfil de acesso ou consultar a atividade. Em **Arquivos e banco**, revise o canal, a escrita SQL, o limite por arquivo e os critérios de retenção. Em **Diagnóstico**, confira o cron, as sessões e a proteção HTTP do armazenamento.

Instale `wp-mcp-fator3-0.45.0-instalador.zip` em WordPress 7.1.4 ou superior com PHP 8.3 ou superior. Esta versão admite atualização direta da 0.44.0. Confira a versão em `system/health`. Em **Ajuda → Notas desta versão**, leia as mudanças e os procedimentos de verificação. Os mesmos documentos estão disponíveis por `system/guide`.

As senhas de aplicação continuam com o alcance nativo do WordPress. O perfil da conexão controla as chamadas MCP. A descoberta aceita paginação explícita com `per_page` e `cursor` e mantém o comportamento da 0.43.0 quando o limite é omitido.
