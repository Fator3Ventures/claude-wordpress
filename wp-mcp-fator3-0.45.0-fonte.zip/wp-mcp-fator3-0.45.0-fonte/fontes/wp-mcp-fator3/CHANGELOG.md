# Changelog

## 0.45.0

- Pedidos MCP 80. Consulta e atualização do SEO de categorias e tags com revisão, backup privado e reconstrução do índice do termo pelo Yoast.

## 0.44.0

- Sete abas no painel, salvamento conjunto do acesso a arquivos e banco e preferências de exclusão.
- Consulta por provedor, projeção de campos e informações de uso dos parâmetros.
- Rotação de sessões por conexão, histórico recente de incidentes do cron e documentação integrada ao PHP do servidor.

## 0.43.0

- Pedidos MCP 79. Na Ajuda, o atalho “Notas desta versão” usa a versão carregada pelo WordPress para abrir as notas correspondentes.

## 0.42.0

- Pedido MCP 78. A simulação de pré-imagens aceita o slug do plugin, expõe o limite de idade desde a primeira página e fornece um cursor quando o inventário está incompleto.

## 0.41.0

- Registro de atividade: filtros agrupados por evento e período, busca por identificador de habilidade e paginação que preserva acentos, caracteres especiais e datas em UTC.
- `connections/list` verifica as políticas da página e as credenciais correspondentes em lote.
- `connections/update` grava o nome do cliente e devolve o recibo original quando a mesma conexão autorizada repete uma confirmação já concluída.

## 0.40.0

- Separados listagem, edição de acesso, emissão de senha e revogação no painel. Proteção contra sobrescrita, formulário truncado e edição concorrente.
- Uma consulta agrupada para sessões; diagnóstico de rotas somente nas telas que o exibem.
- Fonte de manifesto aceita URL previamente gravada e preserva as outras entradas. Ajuda com busca por seção e manual de administração atualizado.

## 0.39.0

- Pedido 77: pré-imagem privada só das linhas selecionadas, confirmação com selection-guard/2 e restauração transacional com verificação da pós-imagem.

## 0.38.0

- Inicialização sob demanda da auditoria de serviço: evita abrir o catálogo administrativo no login e em páginas públicas.
- Preserva registro no primeiro evento, REST, administração, cron, CLI e catálogo explícito; protege reentrada e chamadas anteriores a init.
- Validação com Core 1.63.0, Google 0.24.0, Meta 0.17.0 e LinkedIn 0.13.0; Pipedrive 0.5.0 considerado com seus requisitos próprios.

## 0.37.0 — 2026-10-29
+- Pedido MCP 75: decodifica bytes Apache de UTF-8 válido antes de mascarar, normalizar, agrupar e filtrar logs; conserva trechos inválidos e escapes de controle/literais.
+- Cursor de logs /3: reiniciar paginação anterior por mudança de agrupamento. Core 1.60.0 considerado; aceites de frota 70/74 registrados no relatório.
+
## 0.36.0 — 2026-10-28

- Pedido70: descoberta do domínio sem www, parsing Apache/mod_fcgid e amostras curtas mascaradas.
- Pedido74: carregamento correto da API administrativa de exclusão de usuários, releitura e diagnóstico sanitizado; duas fases, backup e replay preservados.
- Documentação e convivência com Meta0.14.0.

## 0.35.0 — 2026-10-28

- Admite explicitamente site-core-quality na identidade da auditoria de serviço LinkedIn, além de site-core-conversions; evento, recibo, leitor e painel compartilham a validação.
- Preserva prova da concessão, origem do descritor/introspector, digest e posse administrativa; nenhum consumidor arbitrário ou payload pessoal é aceito.
- Sem migração, importação retroativa, reenvio ou mudança do produtor. Compatibilidade examinada com Core1.59.0, Google0.22.0 e LinkedIn0.12.0.

## 0.34.0 — 2026-10-28

- Pedidos 69–73: diagnósticos compactos, logs da hospedagem, recibos duráveis de upload, metadados/poda de pré-imagens e sonda da cópia servida.

## 0.33.0 — 2026-10-25

Pedido MCP 68: contexto da chamada para lido de escrita aplicada, mensagens públicas de instrumentação e nomes de chaves herdadas. Exceções limitadas por caminho/tipo, mantendo máscaras de segredos e seus caminhos. Core 1.54.0 como acompanhante atual; sem alteração de autorização ou banco.

## 0.32.0

- Core 301 / impacto 1.53.0 r2: regras token_* preservadas somente nos caminhos publicados de política e com exatamente dois booleanos.
- Core 300: validação coordenada de descoberta, perfis/capacidades, simulação e recibos incertos de correio.
- Preserva redação de segredos, caminhos no envelope e regressão do pedido MCP 67.

## 0.31.0

Pedido MCP 67: redação por nomes/componentes e tipos diagnósticos, caminhos de mascaramento no envelope MCP. Corrige passagens sem expor senha/token.

## 0.30.1

- Corrige media/get: devolve revisão consistente sob trava de leitura para alimentar media/convert. Prova do fluxo público ler → converter → reler; pacote 0.30.0 preservado após o achado no Site-Teste.

## 0.30.0

- Pedido 66: media/convert cria WebP a partir de JPEG/PNG, copia título/alt/legenda, gera e verifica derivados; preserva a origem. Revisão obrigatória, trava, hashes, economia e reversão por media/delete.

## 0.29.1

- Conserva recibos retryable quando efeitos faltam, são desconhecidos ou parciais; libera somente applied=false explícito sem sinal contraditório.
- Considera todos os termos pesquisados, inclusive após o 12º.
- Exige nonce verificado em admin-post GET e permite habilidade aderente com nonce, preservando permissão do domínio.

## 0.29.0

- M1: tela administrativa de provedor aderente executa a própria habilidade com o MCP ativo (manage_options, sem transporte MCP, contexto wp-admin/admin-ajax/admin-post com nonce ou REST com cookie e nonce); habilidades do MCP, executores e duas fases mantêm a política.
- M2: busca da descoberta sem acento nem caixa, vários termos em qualquer ordem; filtros antes da política, uma avaliação de política por habilidade e identidade resolvida uma vez por listagem.
- M3: descrições de parâmetros das metatools e das habilidades próprias em português.
- M4: falha retryable sem efeito não consome a idempotency_key.
- M5: system/guide com query pesquisa a documentação instalada e devolve cursor de leitura por seção.
- M6: descoberta com filtro provider e include_schemas (até 25 por página).
- M7: aba Conexões sem aviso de PHP para conexão sem rótulo; leitores de auditoria ausentes sem aviso get_registered.
- Sem migração, opção, credencial ou cron novo.

## 0.28.0

- Pedido 65: contrato mutation-service-audit/1.0.0, recibo de persistência exata, referência de serviço e leitor administrativo integrado ao LinkedIn 0.7.0.
- Registro distingue serviço de identidade humana; concessão vigente, perfil e projeções técnicas fechadas.
- Sem migração, reenvio ou importação retroativa.

## 0.27.0

- Pedido MCP 63: rótulos públicos em português, compartilhados pelo catálogo e painel; chave de idempotência do transporte em português.
- Pedido MCP 64: CIMD aceita capacidades adicionais sem habilitar concessões extras; diagnóstico administrativo por tela e system/oauth-diagnostics.
- Convivência com Core 1.47.0 e LinkedIn 0.6.0; principal de serviço permanece proposta coordenada, sem alterar o contrato humano.

## 0.26.1 — 2026-10-22
- Contrato mutation-audit/1.0.0 e adaptador público LinkedIn 0.5.0.
- Registro central recebe ações do painel e correlaciona tentativas MCP por operation_id.
- Consulta antes/depois sob principal e ativo original, com redação de segredos.
- B22/CIMD documentado como encerrado no Site-Teste em 21/10/2026.
- Base MCP 0.25.0; matriz Core 1.46.1, Google 0.17.0, Meta 0.4.1 e LinkedIn 0.5.0.

## 0.25.0 — 2026-10-21
- Pedido 62: administração organizada por assunto, navegação por URL e ajuda individual em português.
- Habilidades e tipos selecionáveis, pesquisa sem perda de seleção e identidades com nomes.
- Datas em UTC com segundos, filtros de resultado e estados selecionáveis.
- Atualizações locais alteram apenas o MCP; preservação dos canais alheios e controle de revisão.
- Limite global por arquivo editável e documentação instalada paginada.
- Contratos públicos e regras de autenticação, SQL e recuperação preservados.

## 0.24.0 — 2026-10-17

- Pedido MCP 61: preserva cache_bypass_verified estritamente booleano na projeção pública recursiva, sem alterar a proteção de SQL/options e segredos.
- Documentação instalada e atualização direta 0.23.0.

## 0.23.0 — 2026-10-16

- Preserva schema e valor de idempotency_key dos produtores; revalida autorização sob lock antes do replay.
- Conserva diagnósticos públicos tipados, protege segredos aninhados e normaliza revision_conflict.
- Documentação instalada allowlisted e paginada por bytes, com hash/revisão e leitura sem auditoria.
- Instalação limpa e atualização direta da 0.22.0; contratos de integração existentes mantidos.

## 0.22.0 — 2026-10-15

- Negociação plural CIMD, diagnóstico privado e autenticação pública coerente com o endpoint de token.
- Registro público de bridges executor-registration/1.0.0, autorização raiz e restrições por provedor/alvo.
- Registro e seleção de origem package-distribution/1.0.0.
- Ativação nativa para plugins novos/inativos e reativação técnica para atualização ativa, com evidências separadas.
- Atualização direta de 0.21.0; Core 1.31.0 para 1.33.0, sem versão intermediária.

## 0.21.1

- Remove exigência de versões/presença dos companheiros nas ofertas de atualização.
- Remove importadores históricos de credenciais, sessões, auditoria, estado e acervo anterior.
- Preserva formatos atuais e identidade SDK; mantém políticas, backups e operações da 0.21.0.
- Atualiza integração e testes com Core 1.32.0 e Google 0.8.4; Google 0.8.5 continua condicionado ao pacote final.

## 0.21.0 — 2026-10-12

- Pedidos 56–59: hierarquia Yoast preservada, indexable órfão em duas fases, poda por IDs/exclusões e tokens elegíveis antes do limite.
- Prévia de rollback de pacote, bytes removidos por lote e conflitos de seleção explícitos.
- Cron mcp-cron-marker/2: prova atual, intenção de ciclo de vida, gravação serializada e diagnóstico sem reparo no bootstrap.
- Integração Core 1.30.0/Google 0.8.3; plano Google 0.8.4 coberto por fixtures de contrato, pendente de pacote final.

## 0.20.0 — 2026-10-11

- Pedidos 47 e 49–55: proteção legada, nicename, backup em fluxo, revisões persistidas, indexables existentes, termos, reparação em duas fases e imagens sociais URL/ID.
- Diagnóstico verificado do cron próprio, sem replay de callbacks.
- Compatibilidade local Core 1.30.0 e Google 0.8.3; consulte RELEASE-020.md e relatório para escopo e limites.

## 0.19.0 — 2026-10-08

- Pedido 47: reconhecimento conservador de proteção Apache equivalente, preservando bytes e resposta HTTP.
- Pedido 48: ativação/sondas de pacotes com timeout 1–30 s (padrão 15); verificação inconclusiva preserva pacote, pré-imagem e diário.
- Novas rotas plugins/operation-status e plugins/reconcile; sentinela não reverte timeout nem executor interrompido após instalação completa.
- Compatibilidade avaliada com Core 1.25.0 e Google 0.8.2; contratos anteriores mantidos.

## 0.18.0 — 2026-10-08

- 42: `backups/legacy-status` e `backups/legacy-retire`; retirada vazia em duas fases, sem afetar aliases MCP.
- 43: reparação dos arquivos de proteção do acervo legado existente, na ativação e verificações; não recria diretórios retirados.
- 44: inventário limitado e retomável de todas as fontes conhecidas, poda por seleção congelada e cursor estável; remoção de índices antigos e tombstones contra reimportação.
- 45: compactação de tokens expirados, limpeza física de comprovantes após 30 dias e preservação da detecção de refresh reutilizado enquanto o grant estiver ativo.
- 46: `content/delete-term`, com identidade explícita, duas fases, backup privado e prova por releitura. Apenas termos vazios ou com relações com posts inexistentes; taxonomias ausentes exigem confirmação explícita do tipo de objeto.

## 0.17.0 — 2026-10-07

- `ReleaseState` substitui `Upgrade015`/`Upgrade016`: inicialização serializada, schema independente da versão do pacote e credenciais preservadas.
- Mantém marcador histórico da 0.16.0 para recuperação do pacote anterior; novo checkpoint em migration.
- `system/probe`: `contexto_teste` e `X-F3Base-Teste`, conflitos identificáveis, classe de tráfego de saída. Sondas operacionais internas marcadas como teste.
- Recusa anônima nas duas URLs mantém 401, registra uma entrada de auditoria por requisição e não polui error.log.
- Documentação do Update URI corrigida; matriz local Core 1.24.0/Google 0.8.0, contratos preservados.

# Histórico de versões

## 0.16.0

- Inicialização do registro antes da composição do servidor, proteção contra reentrada e diagnóstico sem efeitos colaterais.
- Inventário SQL retomável; retenção por política ou IDs, seleção congelada, referências, quarentena e tombstones.
- `db/execute.backup_scope:selected_tables` para DML elegível; restore limitado ao manifesto.
- `roles/delete` e `roles/restore`; edição e atribuição sob coordenação comum.
- Configuração de retenção na tela e em `system/settings-update`; ajuda e schemas atualizados.
- Instalação limpa ou atualização 0.15.0; Core 1.22.1 e Google 0.7.1.

# Changelog

## 0.21.0 — 2026-10-12

- Pedidos 56–59: hierarquia Yoast preservada, indexable órfão em duas fases, poda por IDs/exclusões e tokens elegíveis antes do limite.
- Prévia de rollback de pacote, bytes removidos por lote e conflitos de seleção explícitos.
- Cron mcp-cron-marker/2: prova atual, intenção de ciclo de vida, gravação serializada e diagnóstico sem reparo no bootstrap.
- Integração Core 1.30.0/Google 0.8.3; plano Google 0.8.4 coberto por fixtures de contrato, pendente de pacote final.

As entradas abaixo são o histórico das versões anteriores. O relatório da release registra os testes executados; as entradas de versões anteriores são históricas.

## 0.15.0 — 2026-10-01

- Isolamento dos filtros/ciclo MCP e SDK `server-integration/1.0.0`, com diagnóstico local sem inicialização recursiva.
- Diagnóstico local pode ser consultado antes de WP_Rewrite existir, sem inicialização antecipada de URLs.
- `plugins/list`: campos e prefixos aplicados ao retorno nativo; `file` preservado e `plugin` disponível como identificador canônico.
- Campos nativos dos complementos, como `label` do Google, preservados até o callback do provedor.
- Bridge Google 0.6 preservada; ferramenta direta distinta de execução aninhada, sem bypass de perfil ou gates Google.
- `selection-guard/2` para SQL: linhas/dependências, simulação temporária, locks MySQL, backup integral e conflitos identificáveis. Matriz e limites em `docs/SQL-GUARD.md`.
- Recuperação preserva estado MCP por inventário; dados Google retornam ao mesmo snapshot que suas options.
- Instalação limpa/atualização da 0.14.0; recibos preservados e confirmações SQL antigas identificadas. Sem migração de plugins predecessores.
- Marca Fator3 MCP, três artefatos principais e documentação revisada. Relatório registra testes locais e validação no site de testes.

## 0.14.0

Manutenção plena, migração protegida, consultas e exportação SQL, dump/restore, administração WordPress, cron, temas, ZIP e documentação autenticada. Consulte docs/OPERACAO.md e o guia/relatório da entrega.

## 0.13.0 — histórico

- Contexto autenticado, perfis por credencial, persistência InnoDB e política nas habilidades aderentes.
- MCP dual 2025-11-25/2026-07-28; coexistência dos recursos/servidor Elementor.
- Correções de concorrência/CAS, binários/gzip/offset, patches/revisões/slashing, exclusões e SQL redigido/controlado.
- Atualização de pacote com pré-imagem, staging, ativação em PHP novo, sonda e recuperação independente; canal próprio configurável.
- Metadados, SEO pela API Yoast, ícone/regeneração de mídia, planos, transferências, manutenção e ajuda embarcada.
- UI de conexões/perfis, migração, operações, histórico e configuração expansível; tabelas com rolagem em telas pequenas, estados e datas legíveis.
- Recuperação captura ENOSPC sem fatal de inicialização, preserva diário/pré-imagem e expõe diagnóstico limitado à requisição em system/health.
- Invalidação OPcache cobre scripts removidos na troca/rollback e ocorre antes das sondas de mutação PHP; runtime MU existente é atualizado após substituição do fonte.
- Contratos modificados exigem a migração documentada. Este registro não declara release publicada nem aceite concluído.

## 0.12.1 — 2026-09-21

- Versão estável baseada na rc.2 homologada pelo usuário.
- Exclui tests/ do instalador e mantém a suíte no pacote de fontes.
- Preserva o runtime da rc.2, alterando somente o número da versão.
- Build determinístico com inventário explícito, verificação de bytes e testes negativos de pacote.
- Roteiro autônomo para validação HTTP, atualização nativa e preservação de credenciais e dados.
- Documentação corrente atualizada; histórico referenciado separadamente.

## 0.12.1-rc.2 — 2026-09-15

- Retira documentos internos e maintenance/ do instalador.
- Acrescenta índices PHP de silêncio aos diretórios distribuídos.
- Mantém a implementação funcional da rc.1 e inclui evidências de integração com Core, WP Super Cache e Yoast.
- Homologação posteriormente confirmada pelo usuário, autorizando a versão estável.

> As entradas abaixo descrevem rodadas históricas. Pendências de homologação nelas registradas foram encerradas pela confirmação da rc.2 pelo usuário; documentos citados estão no arquivo histórico original.

## 0.12.1-rc.1 — 2026-09-15

- Remove a autenticação Bearer de `determine_current_user`; resolve usuário, rota e token somente na etapa REST apropriada.
- Corrige o fatal de `get_rest_url()` com `$wp_rewrite` ainda não inicializado, reproduzido com Elementor + PRO Elements.
- Lê o cabeçalho antes de acessar o resolvedor; protege contra reentrada, inclusive ao ocorrer exceção.
- Preserva resultados anteriores de autenticação e recusa payloads inválidos ou usuários inexistentes.
- Mantém aliases, verificação da rota efetiva, armazenamento, credenciais, sessões, catálogo e telas da 0.12.0.
- 253 verificações direcionadas aprovadas; 117 arquivos PHP sem erro de sintaxe.
- Candidata: validação com gladdia-llms-txt 1.0.0 e ambiente completo do incidente permanece pendente.
- Relatório: docs/CORRECAO-0.12.1-rc.1.md.

## 0.12.0 — 2026-09-14

- URL principal Fator3 e alias Ultimate direto no mesmo transporte, com sessões e credenciais preservadas.
- Resolvedor único para URLs, filtros, subdiretórios, REST por query e descoberta OAuth por recurso.
- Bearer limitado às rotas realmente pertencentes ao servidor, inclusive em conflitos de registro.
- Diagnóstico compartilhado corrige o falso negativo de namespace e separa registro local de teste HTTP.
- Teste HTTP com TLS verificado, sem redirecionamento de credencial, erros identificáveis e senhas temporárias exclusivas sob lock.
- Três abas em português, JSONs recolhidos, cópia verificável, fluxo de gerar/revogar sem valores antigos e layout responsivo.
- Persistência de opções conferida, caminhos reais de backups e auditoria paginada com limite de leitura.
- Remove a versão do WordPress dos pré-requisitos visuais; mantém WordPress 6.7+ e PHP 8.0+ nos metadados.
- Mantém 100 abilities próprias, os três metatools e as correções da 0.11.0.
- Guia: docs/ATUALIZACAO-0.12.0.md. Evidências: docs/VALIDACAO-0.12.0.md.

## 0.11.0

- Consolida as três etapas do roadmap da 0.9.3 em uma atualização.
- Lock por caminho comum a todas as operações de arquivo, comparação SHA-256 sob lock, backups protegidos e conflitos identificáveis.
- Contrato explícito de lixeira em páginas/comentários/mídia; opções com readback; SQL preservando literais e LIMIT externo.
- Confirmações SQL consumíveis, expiração, vínculo a usuário/site/pré-imagem, transação verificada e backup de REPLACE.
- Falhas propagadas a MCP isError; validação também no polyfill.
- 27 abilities para conteúdo/blocos, arquivos, temas/plugins, diagnóstico, planos, auditoria e backups.
- URL, identidade de atualização, credenciais/migração e três metatools preservados.
- Detalhes: docs/ATUALIZACAO-0.11.0.md; evidências: docs/VALIDACAO-0.11.0.md.


## 0.9.3 — 2026-09-11

- `content/delete-post`: usa `wp_trash_post()` com `force=false` ou omitido, corrigindo exclusão definitiva indevida de tipos personalizados.
- Verifica `EMPTY_TRASH_DAYS` antes da operação: lixeira desativada retorna falha sem fallback para exclusão definitiva.
- Chamadas sem força sobre itens já na lixeira retornam sucesso sem alterações; exclusão definitiva exige o booleano `force=true`.
- Trata `WP_Error`, vetos e retornos verdadeiros sem mudança de estado; confirma a existência/ausência do registro antes de anunciar sucesso.
- Atualiza descrição e schema; mantém permissões, nome da ability, formato de resposta, endpoint e três metatools.
- Inclui reprodução do defeito da 0.9.2 e 135 verificações em WordPress real 6.9.4, com lixeira ativada e desativada; 98 arquivos PHP passaram na análise de sintaxe.

## 0.9.2 — 2026-09-11

- `files/delete`: adiciona `empty_dir=true` para remover exclusivamente diretórios vazios usando `rmdir`, com registro na auditoria.
- Preserva o modo anterior de arquivos, incluindo SHA-256 e backup; o novo modo não gera backup de diretórios.
- Recusa diretórios com conteúdo, inclusive arquivos ocultos, links e subpastas; `rmdir` nativo também verifica o vazio no momento da remoção.
- Valida o destino real pelo PathGuard e preserva a entrada original para evitar remover o destino de um link simbólico final.
- Mantém capacidades, canal fechado, confinamento, proteção do próprio plugin, URL e três metatools.
- Inclui 38 verificações locais com filesystem real e stubs das funções WordPress.

## 0.9.1 — 2026-09-08

- `plugins/delete`: carrega `wp-admin/includes/file.php` antes de acessar credenciais/filesystem; corrige a função indefinida herdada do Ultimate.
- Falta de credenciais e falhas de conexão devolvem erro estruturado sem emitir formulário FTP/SSH ou encerrar a requisição MCP. Sucesso exige retorno `true` do WordPress.
- Limpa o cache de plugins após excluir, evitando uma segunda exclusão com inventário desatualizado na mesma requisição.
- `files/read`: adiciona `tail_lines`, `offset`, `limit`, `grep` e `grep_regex`, com schemas expostos pelas metatools existentes.
- Leitura por blocos, inclusive do fim para o início, permite consultar logs acima do limite de leitura integral. Preserva linhas completas, LF/CRLF, a ordem original e o teto de bytes da resposta.
- Paginação informa `returned_lines`, `has_more` e `next_offset`; o hash parcial identifica seu escopo em `sha256_scope`.
- Chamadas apenas com `path` mantêm o contrato anterior. Slug, arquivo principal, endpoint, opções e autenticação preservados.

## 0.9.0 — 2026-09-08

- Plugin único, mantendo o slug e o arquivo principal Fator3 e incorporando Ultimate 2.1.0 no commit `d5eff50ff3d5609fa491dfb9af7946c261b00c89`.
- Migração de configurações, Application Passwords e dados OAuth antes do desinstalador do Ultimate; backups e opções Fator3 preservados.
- Compatibilidade temporária com o Ultimate ativo, seguida de carga autônoma depois da desativação.
- Arquivos sem confinamento de caminho por padrão; suporte a absolutos e `..`, filtros de raízes e constante `F3_MCP_FILES_CONFINE='wp'`.
- Proteção de autoedição, capacidades, kill-switch, constantes de bloqueio e sintaxe PHP preservados. Rejeição de raízes inválidas, wrappers e bytes nulos.
- Backup de exclusão preservado; restauração com integridade, sintaxe e backup do destino; falhas de backup e escritas incompletas impedem a operação.
- Correção de unslash em criação, atualização e patch de posts/páginas e nos campos auditados de mídia, comentários e usuários.
- Patch literal limitado de páginas trata `$1` e barras como texto literal.
- Painel único com aba de conexão, banner permanente de alcance e diagnóstico de registro MCP. Test Connection verifica as três ferramentas.
- Falta de uma classe de habilidades passa a gerar diagnóstico sem derrubar as outras rotas REST.
- Preservadas as melhorias dos PRs abertos #7, #9, #11 e #14 já integradas no upstream via #16, incluindo as correções posteriores aos patches originais.
- Auto-teste atualizado ao contrato 0.9.0 e regressões em WordPress nativo e com polyfill.

## Base anterior

O complemento fornecido é 0.8.0. Já aceitava qualquer extensão, possuía backups antes de exclusões e tinha as três rotas SQL com confirmação em duas fases. Essas funcionalidades foram mantidas.
