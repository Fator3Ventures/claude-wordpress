<?php
/** Typed category and tag metadata through the Yoast taxonomy API. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class TermSeo {
    private const FIELDS = ['title' => 'wpseo_title', 'description' => 'wpseo_desc', 'indexing' => 'wpseo_noindex'];

    public static function register(): void {
        $target = [
            'taxonomy' => ['type' => 'string', 'enum' => ['category', 'post_tag'], 'description' => 'Use category para categorias e post_tag para tags.'],
            'term_id' => Registry::integer(1),
        ];
        $text = ['type' => 'string', 'maxLength' => 4096];
        $fields = [
            'title' => $text + ['description' => 'Título SEO do arquivo. Vazio restaura o modelo do Yoast.'],
            'description' => $text + ['description' => 'Metadescrição SEO do arquivo. Vazio restaura o padrão do Yoast.'],
            'indexing' => ['type' => 'string', 'enum' => ['default', 'index', 'noindex'], 'description' => 'default herda a configuração da taxonomia.'],
        ];
        $write = $target + [
            'values' => ['type' => 'object', 'properties' => $fields, 'minProperties' => 1, 'additionalProperties' => false],
            'expected_revision' => ['type' => 'string', 'pattern' => '^[a-f0-9]{64}$', 'description' => 'Revisão retornada por content/get-term-seo para este termo.'],
        ];
        Registry::add('content/get-term-seo', 'Consulta o título SEO, a metadescrição e a regra de indexação da categoria ou tag no Yoast. Retorna a revisão para gravação.', $target, array_keys($target), [self::class, 'read'], [self::class, 'permission']);
        Registry::add('content/update-term-seo', 'Atualiza os campos SEO enviados para a categoria ou tag, salva a pré-imagem e reconstrói o índice Yoast do termo. A descrição editorial é preservada.', $write, array_keys($write), [self::class, 'update'], [self::class, 'permission'], false);
    }

    public static function permission(array $input): bool {
        return TermUpdate::permission($input) && (!defined('WPSEO_VERSION') || current_user_can('wpseo_manage_options') || current_user_can('wpseo_edit_advanced_metadata'));
    }

    private static function state(array $input) {
        if (!defined('WPSEO_VERSION') || !function_exists('YoastSEO') || !is_callable(['WPSEO_Taxonomy_Meta', 'get_term_meta']) || !is_callable(['WPSEO_Taxonomy_Meta', 'set_values'])) {
            return new \WP_Error('seo_provider_unavailable', 'A API de termos do Yoast SEO está indisponível.');
        }
        $term = get_term((int) $input['term_id'], $input['taxonomy']);
        if (!$term instanceof \WP_Term) return new \WP_Error('term_not_found', 'Termo ausente na taxonomia informada.');
        $meta = \WPSEO_Taxonomy_Meta::get_term_meta($term, $term->taxonomy);
        if (!is_array($meta) || array_diff(self::FIELDS, array_keys($meta))) return new \WP_Error('seo_provider_incompatible', 'O Yoast retornou campos de termo incompatíveis.');
        ksort($meta);
        $values = [];
        foreach (self::FIELDS as $field => $key) $values[$field] = (string) $meta[$key];
        $data = [
            'taxonomy' => $term->taxonomy, 'term_id' => (int) $term->term_id, 'term_taxonomy_id' => (int) $term->term_taxonomy_id,
            'provider' => 'yoast-seo', 'provider_version' => WPSEO_VERSION, 'values' => $values,
            'revision' => hash('sha256', serialize([get_current_blog_id(), home_url(), $term->taxonomy, $term->term_taxonomy_id, $term->term_id, $meta])),
        ];
        return [$meta, $data];
    }

    public static function read(array $input): array {
        $state = self::state($input);
        return is_wp_error($state) ? Result::error($state) : Result::ok($state[1]);
    }

    private static function index_matches(array $rows, array $data): bool {
        if (count($rows) !== 1 || $rows[0]['object_sub_type'] !== $data['taxonomy']) return false;
        $row = $rows[0];
        $values = $data['values'];
        $robots = $row['is_robots_noindex'] === null ? 'default' : ((int) $row['is_robots_noindex'] ? 'noindex' : 'index');
        return (string) $row['title'] === $values['title'] && (string) $row['description'] === $values['description'] && $robots === $values['indexing'];
    }

    public static function update(array $input): array {
        return Locks::run(['taxonomy-terms:' . get_current_blog_id() => LOCK_EX, 'option:' . get_current_blog_id() . ':wpseo_taxonomy_meta' => LOCK_EX], static function () use ($input) {
            $id = (int) $input['term_id'];
            $taxonomy = $input['taxonomy'];
            wp_cache_delete_multiple(['wpseo_taxonomy_meta', 'alloptions', 'notoptions'], 'options');
            $state = self::state($input);
            if (is_wp_error($state)) return Result::error($state);
            [$meta, $before] = $state;
            if (!hash_equals($before['revision'], $input['expected_revision'])) {
                return Result::fail('revision_conflict', 'O SEO mudou. Releia o termo antes de gravar.', ['conflict' => true, 'current_revision' => $before['revision']]);
            }
            $ready = SeoIndexables::preflight($id, 'term');
            if (is_wp_error($ready)) return Result::error($ready);
            $rows = SeoIndexables::rows($id, false, 'term');
            if ($rows && $rows[0]['object_sub_type'] !== $taxonomy) return Result::fail('seo_indexable_mismatch', 'A taxonomia do índice diverge do termo.');
            $wanted = $meta;
            foreach ($input['values'] as $field => $value) $wanted[self::FIELDS[$field]] = $value;
            if ($meta === $wanted && self::index_matches($rows, $before)) {
                return Result::ok($before + ['changed' => false, 'persisted' => true, 'indexable_rebuilt' => false]);
            }

            $backup = Backups::create_snapshot('content/update-term-seo', $before + ['indexable_id' => $rows ? (int) $rows[0]['id'] : null]);
            if (is_wp_error($backup)) return Result::error($backup);
            $receipt = ['backup_id' => $backup];
            try {
                if ($meta !== $wanted) {
                    // Yoast validates the whole record. Retain untouched keys verbatim, including keys introduced by extensions.
                    $guard = static function ($new, $old) use ($taxonomy, $id, $input) {
                        $record = $old[$taxonomy][$id] ?? [];
                        foreach (array_keys($input['values']) as $field) {
                            $key = self::FIELDS[$field];
                            if (isset($new[$taxonomy][$id][$key])) $record[$key] = $new[$taxonomy][$id][$key];
                            else unset($record[$key]);
                        }
                        $merged = is_array($old) ? $old : [];
                        if ($record) $merged[$taxonomy][$id] = $record;
                        else {
                            unset($merged[$taxonomy][$id]);
                            if (empty($merged[$taxonomy])) unset($merged[$taxonomy]);
                        }
                        return $merged;
                    };
                    add_filter('pre_update_option_wpseo_taxonomy_meta', $guard, PHP_INT_MAX, 2);
                    try { \WPSEO_Taxonomy_Meta::set_values($id, $taxonomy, $wanted); }
                    finally { remove_filter('pre_update_option_wpseo_taxonomy_meta', $guard, PHP_INT_MAX); }
                }
                wp_cache_delete_multiple(['wpseo_taxonomy_meta', 'alloptions', 'notoptions'], 'options');
                $after = self::state($input);
                if (is_wp_error($after)) return Result::fail('seo_readback_failed', 'Releitura do termo indisponível. Consulte o backup.', $receipt + ['applied' => null]);
                $changed = $after[0] !== $meta;
                $rebuilt = SeoIndexables::rebuild($id, $rows ? (int) $rows[0]['id'] : null, 'term');
                $indexed = $rebuilt && self::index_matches(SeoIndexables::rows($id, false, 'term'), $after[1]);
                $result = $after[1] + $receipt + ['changed' => $changed, 'applied' => $changed, 'persisted' => $after[0] === $wanted, 'indexable_rebuilt' => $indexed];
                if (!$result['persisted']) return Result::fail('seo_fields_filtered', 'O provedor gravou valores diferentes dos solicitados. Consulte a releitura e o backup.', $result);
                if (!$indexed) return Result::fail('seo_indexable_unconfirmed', 'Confira o backup e repita a leitura antes de tentar recompor o índice.', $result);
                return Result::ok($result);
            } catch (\Throwable $error) {
                return Result::fail('seo_update_unconfirmed', 'O Yoast interrompeu a operação. Releia o termo e consulte o backup.', $receipt + ['applied' => null]);
            }
        });
    }
}
