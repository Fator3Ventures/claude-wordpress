# Auditoria de serviços de mutação

Versão documentada: 0.45.0.

Identificador do contrato: Registro de escritas de serviço — mutation-service-audit/1.0.0.

Implementado no Fator3 MCP 0.28.0 com LinkedIn 0.7.0; Pedido MCP 65 / LinkedIn 8(d). Independente do contrato humano mutation-audit/1.0.0. Na 0.35.0, admite também o consumidor comercial site-core-quality do LinkedIn0.12.0/Core323. Aquisição e etapas conservam suas identidades; não há alteração de fila ou payload no MCP.

## Registro PHP local e origem

O listener de eventos é instalado durante o bootstrap. A descoberta/decoração das abilities e o hook `f3_mcp_register_mutation_service_audit` são executados uma vez por requisição, quando houver demanda: contexto administrativo, cron ou WP-CLI em `wp_loaded`, início da API REST, catálogo solicitado por outro consumidor, consulta administrativa ou primeiro evento de serviço. Login e páginas públicas sem essa demanda não abrem o catálogo. O primeiro evento inicializa o contrato antes de persistir e de devolver o recibo ao produtor. Há proteção contra reentrada e chamadas anteriores a `init`; descritor, origem PHP, leitor decorado, concessão e digest continuam validados. Não há ferramenta de registro, emissão, introspecção ou execução de PHP remoto.

Descritor fechado admitido nesta versão:
```json
{"contract":"mutation-service-audit/1.0.0","provider":"wp-mcp-linkedin-fator3","event_contract":"linkedin-service-mutation/1.0.0","event_hook":"f3_linkedin_service_mutation_recorded","reader":"linkedin/get-service-write-operation","introspector":"f3_linkedin_introspect_service_grant"}
```

MCP confere provedor registrado, metadados de versão, leitor público somente leitura com política decorada e esquema fechado, além da origem dos dois pontos de entrada públicos em includes/ServiceAuditPublic.php do plugin instalado. Outro provedor ou contrato requer adaptação explícita; não há descoberta arbitrária de funções ou tabelas privadas.

`$registrar($descriptor)` devolve contract/provider/registered após admissão. `$consultar($provider, [])` consulta a admissão atual. Com a identidade completa abaixo, devolve também recorded e event_sha256, somente quando a concessão vigente comprova o evento e seu hash coincide com o registro persistido. São chamadas PHP locais de leitura; identidade é referência, não credencial.

## Identidade e evento

Identidade fechada: provider=wp-mcp-linkedin-fator3, consumer_id=site-core-conversions ou site-core-quality, principal_ref, grant_revision e operation_id. As três últimas referências têm 64 hex minúsculos. O evento tem esses cinco campos e contract=linkedin-service-mutation/1.0.0, operation=send-conversion-event|send-conversion-events, state=dispatching|confirmed|uncertain|rejected, before_sha256 e after_sha256 (este pode ser null).

O introspector público do domínio deve devolver contract, valid=true, identidade integral, evento técnico integral e event_sha256. MCP valida esquema, identidade, projeção e digest exatos sob lock da referência. Campo adicional é recusado. O digest ordena recursivamente as chaves dos objetos, preserva listas, codifica JSON UTF-8 sem espaços com Unicode/barras sem escape e calcula SHA-256. Exemplo: o snapshot {"status":"nao_enviado"} é codificado exatamente com esses bytes; o evento segue a mesma regra.

Chave: `service:` + SHA-256 de site_id, provider, principal_ref e operation_id separados por NUL. Metadados incluem principal_type=service e user=0 mesmo com usuário incidental. Não se assume o administrador concedente, OAuth ou Application Password. A concessão/revisão fica opaca; outra revisão não pode apropriar-se de referência existente. Duplicata exata não regrava registro. Não se armazenam snapshots, payload, contato, ID de conta/regra, segredo ou texto do fornecedor.

## Leitura administrativa

Descubra `audit/get-service-operation`, somente leitura, manage_options e perfil permitindo esta habilidade **e** o leitor LinkedIn. Exemplo (substitua as referências por valores de audit/list):
```json
{"ability_name":"audit/get-service-operation","parameters":{"provider":"wp-mcp-linkedin-fator3","consumer_id":"site-core-conversions","principal_ref":"<64 hex>","grant_revision":"<64 hex>","operation_id":"<64 hex>"}}
```

O Registro exibe “Serviço — site-core-conversions” ou “Serviço — site-core-quality”, conforme a identidade original, principal e concessão opacos e “Consultar recibo de serviço”. A tela usa autenticação administrativa nativa, com escopo temporário restrito ao leitor; não concede perfil MCP nem contorna a propriedade da concessão do domínio. Outra pessoa/conexão não herda acesso por conhecer a referência. Acesso por Application Password/OAuth continua sujeito ao perfil. O leitor LinkedIn exige propriedade vigente, administrador concedente ainda autorizado, ativo/regra API e prova local de escopos/conexão/revisão válidos.

Resposta: contract, audit_id, principal_type, identity, state, reference_state, reference_current, snapshot_source=provider_public_reader, redacted=true, before e after. Before é status=nao_enviado. After contém somente status, code simbólico, http, non_delivery_proven e retry_after opcional. Incerteza retorna null. A projeção e seus hashes são conferidos; dados inesperados falham fechados. Consulta não chama LinkedIn nem renova tokens. A auditoria normal da consulta pode registrar metadados de acesso; não há efeito comercial.

## Falhas, retenção e recuperação

Concessão revogada, revisão/ativo alterados, escopo sem prova ou leitor ausente bloqueiam detalhes e confirmação atual; a referência histórica permanece. Revogação remota é conhecida apenas depois de observada pelo domínio. Erros públicos são simbólicos, sem exceções/payload: service_identity_invalid, service_not_found, service_authority_unavailable, service_read_denied, service_result_invalid e service_read_failed.

Provider registrado não equivale a evento persistido. Falha de gravação não confirma recorded e não muda sucesso/incerteza comercial, nem autoriza reenvio. Replay confirmado/incerto não repete POST ou hook. Sem backfill, importação ou reemissão automática. Nenhuma concessão nova é criada pela instalação. Use o diário do provedor para reconciliar falhas; nunca repetir efeito só para recuperar auditoria.

Referências ficam no bucket audit, sob a retenção administrativa normal (prévia e confirmação), sem tabela nova. Retenção remove a referência, não o recibo nem o efeito comercial. Voltar ao MCP 0.27.0 desabilita consumo/leitura de serviço, preservando dados; não desfaz envio. Documentos históricos com “proposta pendente” descrevem versões anteriores. A contraproposta LinkedIn 0.7.0 está aceita nesta versão; evidências e limites constam do relatório externo.
