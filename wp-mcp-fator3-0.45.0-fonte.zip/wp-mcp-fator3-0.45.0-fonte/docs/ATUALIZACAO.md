# Instalação e atualização — Fator3 MCP

Versão documentada: 0.45.0. O plugin requer WordPress 7.1.4 e PHP 8.3. A atualização direta parte da 0.44.0. Conexões, concessões OAuth, sessões, recibos, prévias e backups continuam no mesmo banco. O schema de dados é o 2.

O cabeçalho declara `Update URI: https://fator3.com.br/plugins/wp-mcp-fator3`. Esse valor identifica o pacote; não há feed de atualização automática nesse endereço.

## Instalar ou atualizar

1. Instalação limpa: envie `wp-mcp-fator3-0.45.0-instalador.zip` pelo painel de plugins, ative e configure a conexão em **Ferramentas → Fator3 MCP**. A primeira ativação abre o canal de arquivos e banco e libera a escrita SQL; ajuste em **Arquivos e banco** se o site exigir outro padrão.
2. Frota: confira o SHA-256 dos bytes servidos pela URL raw contra o relatório externo. Use `plugins/upload` com `expected_slug` igual a `wp-mcp-fator3`, o `expected_sha256` conferido, `overwrite` e `activate`. O Site-Teste também aceita `plugins/upload-base64` com a mesma conferência.
3. Se a instalação ficar pendente, consulte `plugins/operation-status` e reconcilie pelo ID.

## Conferir a troca

Em nova requisição:

```json
{"ability_name":"system/health","parameters":{"compact":true}}
```

Resposta: chaves `plugin_version`, `healthy`.

Confira `plugin_version` igual a `0.45.0` e `healthy` verdadeiro. Depois leia as notas instaladas:

```json
{"ability_name":"system/guide","parameters":{"document":"release-0450"}}
```

Resposta: chaves `content`, `has_more`.

Na tela, **Ferramentas → Fator3 MCP → Ajuda → Notas desta versão** abre o mesmo documento. Um administrador com conexão de Manutenção confere os perfis com `connections/list`.

## Depois da troca

- Para revisar as cópias que a atualização guardou, siga o procedimento de `release-0420` e percorra o cursor do inventário.
- Para recuperar dados, confira o estado observado e os backups correspondentes. O procedimento de recuperação de linhas SQL com pré-imagem está em `release-0390`.
- Correções do software instalado seguem em nova versão.

## Desativar e excluir

Desativar interrompe o atendimento MCP e remove o evento de cron próprio. Senhas de aplicação são nativas do WordPress e continuam válidas no REST nativo e no XML-RPC com as capacidades da conta. Revogue na conta WordPress as senhas que devem deixar de funcionar.

Por padrão, ao excluir pelo WordPress, as tabelas, opções, backups, armazenamento privado e senhas permanecem. Reinstalar no mesmo site reencontra esses dados. Revise as credenciais antes de reabrir o acesso.

Para remover os dados em um site individual, abra Diagnóstico, habilite a preferência de remover dados ao excluir e salve antes de desativar e excluir. A exclusão nessa posição apaga as tabelas e opções próprias, os agendamentos e as pastas privadas reconhecidas do MCP, inclusive os backups. Entradas desconhecidas na raiz privada são preservadas. As senhas de aplicação nativas do WordPress permanecem nas duas posições da preferência. Revogue essas senhas na conta WordPress antes da exclusão para encerrar seu uso. Em multisite, a limpeza destrutiva por essa preferência fica desabilitada.

O relatório externo identifica o instalador, os ambientes de teste e a situação da entrega.
