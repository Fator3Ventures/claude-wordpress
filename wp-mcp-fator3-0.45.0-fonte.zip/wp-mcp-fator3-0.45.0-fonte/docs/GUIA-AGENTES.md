# Guia para agentes — Fator3 MCP

Versão documentada: 0.45.0. Roteiro para descobrir, ler, diagnosticar, executar e verificar.

## O que o servidor oferece

O servidor publica 3 ferramentas: `wp-mcp-ultimate-discover-abilities`, `wp-mcp-ultimate-get-ability-info`, `wp-mcp-ultimate-execute-ability`. Toda habilidade do WordPress é chamada por `wp-mcp-ultimate-execute-ability`, com `ability_name` e `parameters`. Uma conexão com «Expor executor de leitura» recebe também `wp-mcp-ultimate-execute-readonly-ability`. Acompanhantes podem publicar ferramentas próprias.

Consulte o resumo por provedor para conhecer as leituras e escritas instaladas.

Toda resposta de habilidade é um objeto com `success` e `data`. Dentro de `data` vêm o resultado, `request_id` e `result_contract` (valor 2). Em recusa, `success` é falso e `error_code` identifica o motivo; decida pelo código, o texto de `message` pode mudar.

## Sequência de entrada

### 1. Confirme a versão e a saúde

Use a leitura compacta na abertura da sessão.

```json
{"ability_name":"system/health","parameters":{"compact":true}}
```

Resposta: chaves `healthy`, `plugin_version`, `recovery`.

A resposta padrão inclui ambiente, armazenamento, cron e ocupação. O bloco de cron resume os incidentes nas últimas 24 horas; para ler os incidentes retidos, peça `fields:["cron"]` com o modo compacto desativado. Para um bloco específico, peça `fields`:

```json
{"ability_name":"system/health","parameters":{"fields":["storage"]}}
```

Resposta: chave `storage`.

`system/health` exige uma conta com `manage_options`.

### 2. Liste a documentação instalada

```json
{"ability_name":"system/guide","parameters":{}}
```

Resposta: chaves `documents`, `topics`.

Cada item tem ID, título, tipo, descrição e próxima ação. Comece pelo [índice](indice).

### 3. Encontre a habilidade pelo assunto

Comece com o resumo por provedor.

```json
{"tool":"wp-mcp-ultimate-discover-abilities","arguments":{"summary":true}}
```

Resposta: chave `providers`.

Para encontrar uma habilidade, informe o assunto.

```json
{"tool":"wp-mcp-ultimate-discover-abilities","arguments":{"query":"documentacao","readonly":true}}
```

Resposta: chaves `abilities`, `total`, `catalog_sha256`.

Sem parâmetros, a descoberta devolve todas as habilidades visíveis. Com apenas filtros, ela devolve a seleção integral. Para limitar o tamanho, informe `per_page` e avance pelo cursor com a mesma seleção.

Filtros disponíveis:

| Parâmetro | Efeito |
|---|---|
| `query` | Termos em nome, rótulo, descrição, categoria e provedor, sem diferença de acento ou caixa. Todos precisam aparecer |
| `prefix` | Início exato do nome, por exemplo `content/` |
| `provider` | Slug do pacote, por exemplo `wp-mcp-fator3` |
| `readonly` | Com verdadeiro, selecione leituras; com falso, escritas. Sem filtro, as duas classes podem aparecer. |
| `per_page` e `cursor` | A paginação é opcional. Peça de 1 a 200 itens e continue com o cursor. |
| `fields` | Projeta os campos selecionados em cada habilidade. |
| `compact` | Esvazia as descrições. Os demais campos permanecem |
| `include_schemas` | Acrescenta os schemas de entrada e saída; limita a página a 25 itens |
| `if_catalog_sha256` | Com o hash de uma leitura anterior e os mesmos filtros, catálogo igual devolve `unchanged:true` e lista vazia |

Para percorrer um namespace com custo previsível:

```json
{"tool":"wp-mcp-ultimate-discover-abilities","arguments":{"prefix":"content/","compact":true,"per_page":10}}
```

Resposta: chaves `abilities`, `has_more`, `next_cursor`.

### 4. Leia o contrato antes de chamar

```json
{"tool":"wp-mcp-ultimate-get-ability-info","arguments":{"ability_name":"system/guide"}}
```

Resposta: chaves `input_schema`, `output_schema`, `availability`.

`system/guide` com `ability` devolve o mesmo contrato:

```json
{"ability_name":"system/guide","parameters":{"ability":"content/list-posts"}}
```

Resposta: chaves `ability`, `input_schema`, `output_schema`.

Consulte a descrição dos campos e os resultados esperados antes de montar uma chamada.

### 5. Pesquise e leia a documentação

```json
{"ability_name":"system/guide","parameters":{"query":"revogar acesso","limit":5}}
```

Resposta: chaves `matches`, `total_matches`.

Cada resultado traz `document_id`, `section`, `cursor` e `document_sha256`. Todos os termos precisam estar na mesma seção. `limit` vai de 1 a 50; o padrão é 20.

Para ler um documento inteiro, abra por `document` e continue com `next_cursor` até `has_more` ser falso:

```json
{"ability_name":"system/guide","parameters":{"document":"atualizacao","byte_limit":1024}}
```

Resposta: chaves `content`, `has_more`, `next_cursor`, `document_sha256`.

`byte_limit` aceita de 256 a 32.768; o padrão é 8.192. O cursor carrega o hash do documento: se o pacote mudar no meio da leitura, a resposta é `guide_revision_conflict` e a leitura recomeça. Envie `expected_sha256` para exigir uma revisão específica.

O manual inteiro também pode ser lido por `topic:"all"`. As páginas preservam o conteúdo em UTF-8; reúna os trechos na ordem e valide o hash final.

Um identificador fora da lista é recusado:

```json
{"ability_name":"system/guide","parameters":{"document":"../wp-config"}}
```

Resposta: `error_code` `guide_document_not_found`.

### 6. Execute e confira

Depois de uma escrita, leia o alvo de volta pela habilidade de leitura correspondente e confira o evento no registro:

```json
{"ability_name":"audit/list","parameters":{"per_page":5}}
```

Resposta: chaves `entries`, `has_more`.

## Sessões

Cada `initialize` abre uma sessão. Por padrão, ao atingir 32 sessões em uma conexão, o servidor encerra a menos recente daquela conexão e cria outra. Outras conexões da mesma conta mantêm suas sessões.

Ao terminar o trabalho, encerre a sessão com uma requisição HTTP DELETE ao endereço MCP, com o cabeçalho `Mcp-Session-Id`. Um administrador libera sessões revogando o cliente em **Clientes**.

## O que cada perfil alcança

Exemplos para quatro combinações de conta e perfil. O perfil se soma às capacidades da conta WordPress: os dois precisam permitir.

| Chamada | Administrador, Manutenção | Administrador, Leitura | Editor, Conteúdo | Administrador, Personalizado |
|---|---|---|---|---|
| `system/guide` | permitido | permitido | permitido | permitido |
| `system/health` | permitido | permitido | `permission_denied` | permitido |
| `system/settings` | permitido | `permission_denied` | `permission_denied` | `profile_denied` |
| `connections/list` | permitido | `permission_denied` | `permission_denied` | `profile_denied` |
| `audit/list` | permitido | `profile_denied` | `profile_denied` | `profile_denied` |
| `content/list-posts` | permitido | permitido | permitido | permitido |
| `files/list` | permitido | `profile_denied` | `profile_denied` | `profile_denied` |

O perfil Personalizado do teste listava `system/health`, `system/guide` e `content/list-posts`. `system/guide` exige `edit_posts`.

## Códigos de recusa frequentes

| Código | Significado | O que fazer |
|---|---|---|
| `profile_denied` | A habilidade está fora do perfil da conexão | Use outra conexão ou peça ao administrador a mudança do perfil |
| `permission_denied` | A conta WordPress não tem a capacidade exigida | Use uma conta com a capacidade |
| `guide_document_not_found` | Identificador de documento fora da lista | Liste os documentos |
| `guide_input_invalid` | Combinação de parâmetros de `system/guide` não aceita | `query` combina só com `document` e `limit`; `ability` vai sozinho; `document` e `topic` não se combinam |
| `guide_revision_conflict` | O documento mudou durante a leitura | Recomece sem cursor |
| `cursor_invalid` | Cursor de outro documento, filtro, usuário ou conexão | Recomece a paginação |
| `catalog_changed` | O catálogo mudou durante a descoberta paginada | Recomece a descoberta |
| `result_size_limit` | A resposta passou de 2 MiB | Peça uma página menor |

## Limites desta instalação

`system/capabilities` devolve os limites vigentes em `limits`. Confira os valores nessa chamada antes de preparar arquivos, consultas SQL ou planos.

## Escritas com prévia

`db/execute`, `connections/update`, `connections/revoke` e `system/settings-update` trabalham em duas chamadas: a primeira devolve `preview:true`, `confirm_token` e `expires_at`; a segunda repete os mesmos parâmetros com o `confirm_token`. Diante de `operation_uncertain`, consulte `operations/status` com o `operation_id` antes de repetir.
