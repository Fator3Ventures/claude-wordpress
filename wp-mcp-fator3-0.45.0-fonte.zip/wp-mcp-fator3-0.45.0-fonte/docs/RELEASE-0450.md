# SEO de categorias e tags

O Pedidos MCP 80 acrescenta duas habilidades de conteúdo. A atualização direta parte da versão 0.44.0. O servidor continua exigindo WordPress 7.1.4 e PHP 8.3. O Yoast SEO 28.8 foi a referência para a API de termos e o serviço de reconstrução. O servidor também funciona em sites que operam sem Yoast. Nesses sites, as duas habilidades retornam `seo_provider_unavailable` a uma conta com permissão sobre o termo.

## Gravar e conferir

Use `content/get-term-seo` com a taxonomia e o identificador do termo. Copie a revisão da resposta. Em `content/update-term-seo`, repita o alvo, informe essa revisão em `expected_revision` e envie em `values` apenas os campos que deseja mudar. A resposta traz os valores relidos, a revisão vigente e, quando houve gravação ou reparação do índice, a referência do backup privado. O campo `indexable_rebuilt` confirma a reconstrução do registro do termo pelo Yoast. Consulte [Termos](termos) para restaurar uma pré-imagem e verificar a página pública.

A regra `default` usa as preferências da taxonomia. O título e a metadescrição aceitam texto vazio para voltar ao modelo configurado. A URL, os vínculos dos posts e a descrição editorial do termo são preservados. A leitura devolve valores armazenados. Modelos, filtros do tema e cache intervêm no HTML entregue ao visitante. Confira a tag no cabeçalho em uma nova requisição.

## Convivência

A matriz desta edição inclui Base Site Core 1.81.1, Google 0.34.0, Meta 0.24.1, LinkedIn 0.21.0 e Pipedrive 0.9.0. Os contratos dos serviços de anúncios e CRM seguem nos respectivos plugins. A operação de termos pertence ao servidor MCP e ao Yoast instalado no mesmo WordPress. A edição mantém o schema de dados 2, os perfis de conexão, a autenticação e os parâmetros de descoberta já utilizados pelos clientes.
