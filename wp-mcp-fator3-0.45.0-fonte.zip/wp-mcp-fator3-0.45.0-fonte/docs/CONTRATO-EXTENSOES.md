# Extensões do Fator3 MCP

Versão documentada: 0.45.0.

A política de habilidades permanece `policy_contract:1`. Registre provedor/versão/prefixos durante `f3_mcp_register_providers` e forneça os mesmos metadados às abilities. Registro não concede capacidades WordPress nem perfil de conexão. O permission_callback decorado aplica a política, inclusive se uma habilidade aderente chegar por outra porta, com uma exceção desde a 0.29.0 descrita em "Chamada nativa de administrador".

O contrato canônico do servidor, seus filtros, identidade, diagnóstico e ferramentas diretas está em [SERVER-INTEGRATION.md](SERVER-INTEGRATION.md). O mapa de hooks internos está em `server-hook-map.json`; não use hooks genéricos `mcp_adapter_*` para configurar o Fator3.

A matriz de referência atual inclui Google 0.16.0, Core 1.43.0 e Meta/LinkedIn 0.4.1. Para contribuir com o servidor, use `f3_mcp_default_server_config`, valide a identidade `contract:server-integration/1.0.0` e contribua somente as abilities registradas. A união por nome evita duplicação com o adaptador de compatibilidade do canal.

Uma fachada PHP Core → Google não deve ser publicada como executor MCP nem depender de usuário 0 receber perfil. Desligar o transporte MCP não administra o serviço local dos complementos. Configurações e concessões permanecem com seus donos. Consulte os relatórios de impacto entregues com o fonte.

## Referências de mutação

Contrato opcional mutation-audit/1.0.0: documentação integral em MUTATION-AUDIT. Registro de descritor/leitor público pelo provedor instalado, referência por operação e consulta autorizada sob principal original. Não é requisito de ativação ou trava por versão dos plugins.

## Chamada nativa de administrador

Desde a 0.29.0, a tela administrativa do próprio provedor pode executar sua habilidade aderente pelo Abilities API com o MCP ativo. A política de conexão é dispensada, sem gravação de política, somente quando: a habilidade é do provedor aderente (não do MCP) e não é executor; o usuário tem `manage_options`; não existe senha de aplicativo, OAuth ou identidade de job na requisição; nenhum `tools/call` está aberto e a rota não é endpoint MCP; e a requisição web é tela wp-admin em GET/HEAD (só habilidades de leitura), admin-post/admin-ajax depois de `check_admin_referer`/`check_ajax_referer` aceito, ou REST com cookie de login e nonce `wp_rest` válido. O `permission_callback` do provedor continua decidindo. Chamadas de PHP fora desses contextos (WP-CLI e linha de comando, cron, front-end, usuário 0) seguem a política: uma fachada não deve depender de usuário 0 receber perfil. O provedor que quiser tratar a recusa em contexto não administrativo deve exibir o código devolvido (`profile_denied` ou `connection_context_required`) com orientação ao administrador.

## Correções 0.29.1

admin-post GET exige nonce verificado, como POST. Para liberar uma chave após falha retryable, declarar applied=false explicitamente; persisted/changed/partial, quando presentes, devem ser false. Ausência/null não prova inexistência de efeito. Nenhuma alteração obrigatória no provedor; sem prova o MCP preserva/reproduz o recibo.
