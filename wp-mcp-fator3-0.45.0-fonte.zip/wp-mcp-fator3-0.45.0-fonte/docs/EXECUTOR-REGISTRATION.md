# Registro de executores

Versão documentada: 0.45.0.

Identificador do contrato: executor-registration/1.0.0.

Produtor: `Fator3\McpFiles\ExecutorRegistry`, MCP 0.22.0. Cooperação PHP entre plugins instalados e confiáveis. Não é uma ferramenta MCP que receba callbacks ou identidade do usuário.

## Assinaturas

```php
ExecutorRegistry::capabilities(): array;
ExecutorRegistry::register(array $descriptor); // true ou WP_Error
ExecutorRegistry::status(): array;
ExecutorRegistry::finalize(): array;
```

`capabilities` e `status` são locais e não inicializam a Abilities API, não fazem HTTP e não concedem acesso. `status` retorna `finalized`, `admitted`, `pending` e `errors`. Antes da finalização, `admitted` é vazio.

Registre o provedor pelo `f3_mcp_register_providers` e `ExtensionContract::register`. Registre as abilities pelo ciclo WordPress. Declare os executores no hook `f3_mcp_register_executors`, que recebe a string do contrato. Ele roda após o término do registro de abilities, quando o servidor compõe seu catálogo. `finalize` precoce ou reentrante somente observa; não força o ciclo. Registro tardio retorna `executor_registry_closed`. Cada request recompõe as declarações, sem privilégios persistidos.

```php
add_action('f3_mcp_register_executors', static function ($contract) {
    if ($contract !== 'executor-registration/1.0.0') return;
    \Fator3\McpFiles\ExecutorRegistry::register([
        'contract' => $contract,
        'ability' => 'meuprovedor/mcp-read',
        'provider' => 'meu-plugin',
        'mode' => 'read',
        'allowed_targets' => ['names' => ['meuprovedor/status'], 'prefixes' => []],
    ]);
});
```

O exemplo pressupõe provedor e abilities já registrados. O descritor não registra uma ability. O registro interno preserva `meta.mcp.public:false` explícito; somente a ausência do campo recebe o padrão público. A ability executora precisa ser pública, aderente à política 1, decorada pelo MCP, ter `meta.fator3.executes_ability:true`, `meta.fator3.mode` igual ao modo declarado e `annotations.readonly` booleano coerente. Provedor e versão vêm do registro efetivo, não de argumentos MCP.

`allowed_targets` exige ambas as listas `names` e `prefixes`. Prefixo é um namespace registrado completo, como `meuprovedor/`, sem curinga. Todas as entradas precisam pertencer ao mesmo provedor. Listas vazias autorizam zero alvos. Campos adicionais, callbacks, modos desconhecidos e identidades conflitantes são recusados. Declarações equivalentes são deduplicadas; conflito bloqueia a identidade durante o request. O schema completo está em `schemas/executor-descriptor.schema.json`.

## Autorização

Somente a chamada raiz de uma ferramenta admitida no servidor Fator3, autenticada por OAuth ou senha de aplicação, abre o contexto interno. O contexto vincula bridge, usuário, conexão e política; alterações desta política invalidam o alvo. O contexto fecha em `finally`, inclusive em exceções. Uma declaração PHP não concede um perfil, capability WordPress, consentimento ou acesso a APIs remotas.

Leitura recusa bridge de escrita, inclusive simulação. Personalizado exige a bridge e o alvo. O alvo é revalidado quanto a provedor, allowlist, efeito, permissão WordPress e perfil. Executor não pode ser alvo, incluindo a própria bridge e metatools. Os gates nativos de serviço, recurso, credencial, revisão, confirmação e idempotência continuam no provedor.

O filtro `f3_mcp_default_server_config` também só admite contribuições executoras validadas por este registro. Não pode contornar uma declaração recusada.

## Google 0.8.5 e próximo consumidor

A adaptação delimitada reconhece os metadados aderentes da versão 0.8.5 entregue e gera descritores para `google/mcp-read` e `google/mcp-write`. Usa os seis prefixos registrados do provedor: `ga/`, `ads/`, `google/`, `gsc/`, `siteverification/` e `gtm/`. Os mesmos validadores e controles genéricos processam esses descritores; não existe exceção nominal no autorizador raiz.

Uma declaração explícita válida tem precedência sobre a adaptação e não duplica a ferramenta. Declaração explícita inválida não recebe fallback. Google 0.8.6 pode declarar suas bridges no hook público, detectando capacidade, sem comparar números de versão MCP. Sua integração real permanece pendente do pacote. Os nomes, schemas e grants atuais Google não são renomeados nem importados.

Códigos públicos incluem `executor_contract_unsupported`, `executor_descriptor_invalid`, `executor_provider_unavailable`, `executor_provider_mismatch`, `executor_targets_invalid`, `executor_target_forbidden`, `executor_conflict`, `executor_ability_invalid`, `executor_registration_failed` e `executor_registry_closed`. Não contêm credenciais nem argumentos da chamada.
