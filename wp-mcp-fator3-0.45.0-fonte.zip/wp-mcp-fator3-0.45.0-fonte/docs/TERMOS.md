# Termos e taxonomias

Versão documentada: 0.45.0.

## Exclusão tipada de termo

`content/delete-term` apaga um único termo vazio ou ligado exclusivamente a posts inexistentes. Exige perfil Manutenção, manage_options e, se a taxonomia estiver registrada, a capacidade nativa delete_terms.

Informe `taxonomy` e exatamente um identificador: `term_id` é a identidade em terms; `term_taxonomy_id` é a identidade em term_taxonomy. Os valores “tt 3”, “tt 4” etc. da demanda são term_taxonomy_id, não term_id. Nome e slug não são identificadores de exclusão.

Exemplo de prévia baseado no pedido, a ser conferido novamente no site antes de confirmar:

```json
{"ability_name":"content/delete-term","parameters":{"taxonomy":"elementor_library_type","term_taxonomy_id":3,"allow_unregistered":true,"object_type":"post"}}
```

`allow_unregistered:true` e `object_type:post` são obrigatórios quando o provedor da taxonomia não está registrado. O administrador deve confirmar que se trata de taxonomia de posts. Para taxonomia registrada, tipos de objeto não reconhecidos como post types são recusados. Os IDs relatados em fator3.com.br e korvena.com.br não são embutidos no código nem presumidos como atuais.

A primeira chamada retorna resumo, ambos os IDs, quantidade de relações, órfãos de posts e `confirm_token`, com validade de dez minutos. Metadados privados não aparecem no resumo. Repita **os mesmos argumentos** acrescentando o token. Alteração do termo, metadados ou relações entre as fases invalida a confirmação. Repetir confirmação concluída retorna o recibo, sem novo efeito.

Antes de apagar, salva backup privado com as linhas de terms, term_taxonomy, termmeta e term_relationships. A escrita usa a conexão MySQL original e uma transação InnoDB; conexão perdida não é substituída por outra para continuar a exclusão. Releitura dentro da transação e após commit confirma as quatro ausências. A resposta traz `backup_id` e `readback.term_absent`, `term_taxonomy_absent`, `relationships_absent` e `termmeta_absent`.

O backup pode ser inspecionado/exportado pelas rotas de backups conforme permissão. É pré-imagem para recuperação assistida; esta versão não adiciona uma rota automática de restauração de termos. Não usa `db/execute` nem dump integral para esta operação.

Relações com posts existentes, termo padrão, termo compartilhado entre taxonomias, termo com filhos e tabelas não InnoDB são recusados. Limite: 1.000 relações, 1.000 metadados e 4 MiB de pré-imagem. A existência real do post determina órfão; o campo count do termo não basta.

A exclusão é SQL restrita às quatro tabelas e aos IDs selecionados, seguida de invalidação de cache; não chama hooks de exclusão de provedores. Não realoca posts, não altera outros termos e não faz limpeza global de term_relationships. Uma relação cujo próprio term_taxonomy_id já não exista demanda outra reconciliação: não é incluída silenciosamente. Por isso, as seis linhas órfãs citadas em Korvena só entram se pertencerem ao termo escolhido.


## SEO de uma categoria ou tag

Uma conta com permissão de edição do termo e de metadados avançados do Yoast pode ler o SEO pelo MCP. A conexão também precisa autorizar a habilidade. Para gravar, use um perfil de Conteúdo, Manutenção ou Personalizado autorizado a escrever no alvo.

1. Descubra o ID e a taxonomia do termo. Categorias usam `category` e tags usam `post_tag`. Em `content/get-term-seo`, informe `taxonomy` e `term_id`. Anote `values` e `revision`.
2. Chame `content/update-term-seo` com os mesmos identificadores, a revisão em `expected_revision` e, por exemplo, `"values":{"description":"Artigos sobre arquitetura e engenharia de software."}`. Os campos aceitos são `title`, `description` e `indexing`. A indexação aceita `index`, `noindex` e `default`. Uma string vazia em título ou descrição restaura o modelo do Yoast.
3. Confira `persisted`, `indexable_rebuilt` e a releitura. Se o índice já refletia os valores, a resposta informa `changed:false` e `indexable_rebuilt:false`. Em conflito, releia e revise as alterações antes de repetir. Uma falha após a gravação pode incluir `backup_id` e os valores já aplicados.
4. Abra a URL do termo em nova requisição com o cache contornado. Confira o conteúdo de `meta[name="description"]` no HTML e o valor da descrição editorial pela API de termos do WordPress. O tema e os modelos do Yoast podem alterar o que aparece na página.
5. Para recuperar o SEO prévio, consulte a pré-imagem pelo fluxo autorizado de backups. Releia a revisão vigente e envie os campos originais de `values` pela mesma habilidade. Confira novamente a resposta e o HTML.
