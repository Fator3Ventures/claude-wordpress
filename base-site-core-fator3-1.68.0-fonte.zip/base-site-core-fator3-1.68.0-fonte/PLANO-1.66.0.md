# Core 1.66.0 — plano da rodada

Planejamento registrado em 31/10/2026, antes da implementação. Base 1.65.1, SHA-256 059d7da03484eb3d9eb7327f49787144466f451fcf51730ea0357d92c03f168a. Nova rodada minor; contrato administrativo 8.30.0 e SDKs publicados preservados. Na abertura, o instalador alvo ainda não estava gerado.

Implementar 354(k,l), 363(a–c) e 364(a–c), com regressão de HTML, persistência em processos distintos, contrato de medição, catálogo antes/depois do bootstrap e contextos público/REST/MCP/cron/CLI. Testar instalação limpa e atualização direta. O 362 foi encerrado pela frota, segundo a entrada recebida; preservar sua regressão.

O impacto Google 0.25.1 recebido será resolvido pela projeção compatível 1.0.0, sem mudança do consumidor ou das configurações. A resposta e suas provas ficam no relatório desta entrega; nenhum novo contrato ou pedido a outro pacote foi identificado. Meta 0.18 e LinkedIn 0.14 mantêm suas APIs; não modificar acompanhantes.

Metas de bytes da rodada anterior e aceites da frota permanecem rastreados. A implementação desta rodada prioriza as três regressões enumeradas na nova lista; nenhuma prova sintética será apresentada como medição de fator3.com.br ou entrega comercial.

## Fechamento da execução

Os três pedidos foram implementados. Instalador 1.66.0: 4218989 bytes, SHA-256 `0f796b2001478fe32e5ce47b5851f79148e6a1eebac7087c39a603a587692830`. Instalação limpa e atualização direta passaram no WordPress 7.1.2 e 7.1.4/PHP 8.3.6. Catálogo comparado nos cinco contextos de bancada, política validada em 49.152 combinações discretas e 180 variações individuais de prazo; 64 comparações de HTML preservadas.

O mesmo ZIP foi aplicado no Site-Teste (PHP 8.3.36/WordPress 7.1.4). Ciclo e pós-verificação concluídos automaticamente, contexto de medição legível, configurações conferidas por hash, cache público vigente e ZIP temporário removido. Página: 53,374 / 59,122 / 52,983 ms próprios; login: 10,317 / 10,312 / 10,220 ms. Provas e limites constam de `base-site-core-fator3-1.66.0-relatorio.md` e `evidence/1660`. Não houve publicação na frota nem novo encaminhamento técnico a outro pacote.
