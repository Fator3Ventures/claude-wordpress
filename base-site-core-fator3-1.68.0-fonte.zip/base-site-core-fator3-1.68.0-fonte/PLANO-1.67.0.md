# Core 1.67.0 — plano da rodada

Planejamento registrado em 01/11/2026, antes da implementação. Base publicada e imutável: Core 1.66.0, fonte SHA-256 `280a7fa4e706c5f1af3034bd1d11dc8dd466cf33958a4a33ebb4a24ad16b3b0c`, instalador `0f796b2001478fe32e5ce47b5851f79148e6a1eebac7087c39a603a587692830`. Nova rodada minor, somente Core. Slug, basename, SDKs e configurações existentes preservados.

Implementar integralmente os pedidos 365, 366 e 367 da lista recebida em 01/11: inventário explícito dos estados internos sem ocultar opções desconhecidas; descoberta/prova do cache servido e coerência do estado atual de cabeçalhos com o pós-atualização; observação local de Lead/MaterialDownload por event_id, rota e classe de tráfego, com recebimento externo separado e comparação por dia sem dados pessoais.

Primeiro reproduzir as regressões na base 1.66.0. Validar instalação limpa e atualização direta no WordPress 7.1.4 e mínimo declarado 7.1.2; PHP 8.3; migração aditiva, idempotência, privacidade, consentimento, deduplicação, paginação, cache de 24 horas e regressões anteriores. Testar o artefato final no Site-Teste autorizado, sem gerar contatos ou eventos comerciais e sem publicar na frota. Preservar o aceite recebido de 354/362/363/364, incluindo as 64 comparações de HTML.

Acompanhantes recebidos: Google 0.26.0 e Meta 0.19.0. Ler e considerar seus relatórios e contratos; não modificar seus pacotes. MCP 0.38.0, LinkedIn 0.14.0 e Pipedrive 0.5.0 conforme instalação observada. Nenhuma alteração de contrato de outro pacote foi identificada na abertura; se surgir impacto concreto, registrar o encaminhamento antes da implementação afetada.

Entregar fonte completo, instalador e relatório português na ordem exigida pelas normas do projeto. Não confundir provas locais com aceite da frota nem disparo do navegador com recebimento na Meta. Metas anteriores de bytes permanecem rastreadas e só serão encerradas com medidas correspondentes. As provas dos doze sites e do próximo contato real dependem da operação da frota, fora desta instalação de teste.

Aditamento durante a validação: a prova de relatório após desinstalar e reinstalar revelou tabelas auxiliares ausentes com checkpoint concluído. Incluída marca explícita de reinstalação, preservação do recibo anterior e verificação física de todas as tabelas após o novo ciclo.

Retomada em 01/11/2026: confirmada diferença de contexto CLI/público causada pelo global wpsc_ignore_tracking_parameters não exportado pelo WP Super Cache 3.1.4 no carregamento CLI. Ajustar somente a consulta do Core com leitura literal restrita da configuração existente quando o global estiver ausente; não executar o arquivo nem presumir habilitação. Acrescentar regressão de contexto e repetir os ciclos do ZIP final. Sem mudança no contrato de acompanhantes.
