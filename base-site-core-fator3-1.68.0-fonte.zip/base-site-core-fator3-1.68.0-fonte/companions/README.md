# Acompanhantes considerados — Core 1.67.0

MCP 0.38.0, Google 0.26.0, Meta 0.19.0 e LinkedIn 0.14.0 foram ativados juntos em WordPress 7.1.4/PHP 8.3.6. Novos ZIPs e relatórios recebidos estão identificados em `inputs/1670/manifest.json`; pacotes dos acompanhantes não integram o fonte e não foram modificados.

Google 0.26.0 corrige o consumo do transporte `ambos` e sua validação de saída. Meta 0.19.0 corrige estatísticas por dataset/dia, cobertura parcial e disponibilidade de EMQ; o Core lê o SDK oficial e seus acervos concedidos. O ensaio Meta desta rodada usou o SDK/armazenamento real 0.19.0 com dados sintéticos e bloqueio de HTTP; não afirma entrega ao fornecedor. Pipedrive 0.5.0 exige PHP 8.3.36 e sua convivência é observada no Site-Teste, sem teste comercial.

Não há novo impacto individual: contratos administrativo 8.30.0, contexto de medição 1.0.0 e finalidades de conversão 1.1.0 permanecem. A saída Meta acrescenta observações locais e comparação por dia, sem retirar campos ou alterar o SDK de outro pacote. Consulte o relatório externo para instalação, versões efetivamente observadas e limites.

## Histórico anterior

# Acompanhantes considerados — Core 1.66.0

MCP 0.38.0, Google 0.25.1, Meta 0.18.0 e LinkedIn 0.14.0 foram ativados juntos em WordPress 7.1.4/PHP 8.3.6. Os ZIPs e relatórios novos recebidos estão identificados por tamanho e SHA-256 em `inputs/1660/packages.json`; não integram o fonte. Não modificar os pacotes dos outros responsáveis.

O SDK Meta 0.18 foi exercitado com dados/concessões locais e bloqueio de HTTP. Google 0.25.1 leu o contexto Core e o transporte de conversões no Site-Teste, sem chamada ao fornecedor. LinkedIn 0.14 teve ativação, convivência e extensão de contexto observadas; entrega comercial não foi reensaiada. Pipedrive 0.5 requer PHP 8.3.36 e ficou inativo apenas na bancada PHP 8.3.6.

No Site-Teste, WordPress 7.1.4/PHP 8.3.36, os cinco acompanhantes permaneceram ativos com Core 1.66.0. A pós-verificação automática confirmou a conta Pipedrive; não se criou contato de teste nem nova entrega. O relatório distingue integração local, leitura operacional e aceite comercial. Contratos Core administrativo 8.30.0, medição 1.0.0 e finalidades de conversão 1.1.0 preservados. O impacto Google 0.25.1 foi resolvido na projeção Core, sem novo encaminhamento.

## Histórico anterior

# Acompanhantes considerados — Core 1.65.0

Na retomada de 31/10/2026: MCP 0.38.0, Google 0.24.0, Meta 0.17.0 e LinkedIn 0.13.0 ativos na bancada PHP 8.3.6 / WordPress 7.1.4. Pipedrive 0.5.0 não foi ativado nessa bancada por exigir PHP 8.3.36. Após autorização explícita, o Site-Teste confirmou os cinco acompanhantes e Core 1.65.0 ativos, com PHP 8.3.36 / WordPress 7.1.4. O comparativo remoto com/sem Core e Pipedrive passou no limite de 100 ms pela diferença dos mínimos. O pós-check Pipedrive confirmou a conta, sem ensaio de entrega de contato. Não houve homologação de SDKs comerciais. Consulte o relatório atual e evidence/1650. Nenhum acompanhante foi alterado ou redistribuído. Ciclos nativos do Core também passaram no piso WordPress 7.1.2.

## Registro histórico — Core 1.63.0

Base canônica Core 1.62.0. Pacotes separados, sem alterações ou redistribuição. Novos insumos: inputs/1630/packages.json. MCP/Google/LinkedIn mantêm os pacotes originais da base. Contratos SDK não mudam nesta entrega.

| Pacote | Versão | Verificação |
| --- | --- | --- |
| wp-mcp-fator3 | 0.37.0 | Autorização, catálogo, documentação integral e canal do Site-Teste. |
| wp-mcp-google-fator3 | 0.24.0 | SDK/armazenamento originais; transporte sintético em bancada. |
| wp-mcp-meta-fator3 | 0.17.0 | SDK/armazenamento originais, grants, acervos e monitoramento sintéticos. |
| wp-mcp-linkedin-fator3 | 0.13.0 | Bootstrap e convivência; cliente preservado. |
| wp-mcp-pipedrive-fator3 | 0.5.0 | Exige PHP 8.3.36; fica inativo no laboratório PHP 8.3.6. A prova com o pacote ativo usa a bancada isolada do Site-Teste. |

Matriz local: WordPress 7.1.3 e piso 7.1.2, PHP 8.3.6, MySQL 8.0.46. Instalação limpa, atualização direta 1.62.0, repetição e reativação usam o ZIP final. Nenhum transporte comercial real em testes. As versões ativas no Site-Teste, resultados e pendências efetivamente observados estão no relatório e em evidence/1630; a presença do harness não afirma sua execução.
