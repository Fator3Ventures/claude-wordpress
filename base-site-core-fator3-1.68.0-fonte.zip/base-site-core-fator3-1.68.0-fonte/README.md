# Fator3 Site Core 1.68.0 — fonte

Runtime em work/plugin/base-site-core-fator3, idêntico ao instalador final. Base imutável 1.67.0, contrato 8.31.0. Leia PLANO-1.68.0.md e docs/RELEASE-1.68.0.md. Evidências atuais em evidence/1680. Histórico preservado não representa teste repetido nesta rodada. Nenhum laboratório, banco, credencial ou pacote acompanhante incluído. Pendência 369(d): nome de campanha ausente da resposta depende de novo método público do LinkedIn.
