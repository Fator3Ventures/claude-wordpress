# Correção do escopo — Core 1.65.1

31/10/2026 · continuação do mesmo ciclo, incremento patch conforme orientação do dono.

Base imutável: Core 1.65.0, instalador SHA-256 f99d5cf933da2490baebe1d7fbe48d71a98d6b0ae00f51c0748267a471e8ed42. Contrato administrativo 8.30.0; preservar interfaces de fornecedores, slug, dados, configurações e coleta de todas as visitas elegíveis.

Estado em 31/10/2026: implementação concluída e instalador 1.65.1 ativo no Site-Teste, com 4206718 bytes e SHA-256 059d7da03484eb3d9eb7327f49787144466f451fcf51730ea0357d92c03f168a. Instalação limpa e atualização direta aprovadas em WordPress 7.1.2 e 7.1.4/PHP 8.3.6; 64 comparações de CTA, 44 verificações P2 e 44 de formulário nativo aprovadas. O primeiro cache da home após a troca já referenciou os ativos públicos (362 aprovado). O aceite de até 100 ms em fator3.com.br e as demais provas de campo continuam pendentes; consultar o relatório externo 1.65.1 para números, limites e evidência. Metas de bytes não são declaradas cumpridas por esta implementação.

## Falha da entrega anterior

P2 foi entregue parcialmente sem autorização de redução de escopo. O receio de perder eventos durante carregamento dinâmico foi registrado como desvio, mas precisava ter sido resolvido por implementação e regressão. Não houve impedimento de credencial ou fornecedor para esse trabalho. A instalação e os testes da 1.65.0 não encerram esse requisito.

## Trabalho desta correção

1. Separar a medição de formulário do coletor geral e carregá-la quando houver formulário, mantendo o código funcional independente.
2. Retirar o carregamento incondicional de ofertas ligado à análise. Preservar a API síncrona usada pelo tema, IDs de instância, limites de frequência, consentimento, marca de teste e eventos dinâmicos.
3. Preparar os módulos no build, selecionar os estáticos no WordPress e detectar recursos dinâmicos no navegador. Impedir downloads duplicados e registrar eventos no intervalo de carga sem armazenar valores de campos.
4. Preservar CSS condicionado à renderização, configurações públicas reduzidas, dados compartilháveis sem tokens e os mecanismos já implementados em P1/P3/P4/P5/P8/P9.
5. Conferir as demais frentes do plano 1.65.0 contra implementação e evidência. Corrigir lacunas de implementação encontradas; não converter requisitos em melhorias opcionais.

## Aceite

- Página sem formulário/oferta não solicita os módulos específicos correspondentes.
- Formulário inicial ou dinâmico, inclusive acima da dobra: primeiro foco/clique, validação, tentativa, aceite, complemento e abandono preservados.
- Oferta inserida e aberta/fechada durante carga: instância e sequência preservadas, sem duplicação; frequência continua síncrona.
- Consentimento pendente/negado/revogado, exclusão e modo teste impedem efeitos indevidos. Mudança de contexto limpa observações não autorizadas.
- Paridade de eventos/campos/horários nos roteiros, fonte e minificado; medição de custo com repetições e reporte da variabilidade.
- Instalação limpa e atualização direta 1.65.0 → 1.65.1, documentação corrente, regressões pertinentes e ensaios reais possíveis no Site-Teste.

## Fronteiras

Nenhuma alteração necessária em contratos de outro plugin foi identificada para a separação do JavaScript público. Não emitir impacto apenas para anunciar a versão. Tema continua dono da apresentação/gatilhos das ofertas; a API pública existente será preservada. Alterações de frota, campanhas e produção seguem sua atribuição própria. Aceites que dependem de 24 horas reais não podem ser declarados antecipadamente.

## Ampliação solicitada em 31/10/2026 — 354(h–j) e 362

354: contar a profundidade real com pre_render_block/render_block, carimbar apenas raízes efetivas e template-part do cabeçalho; cache de the_content entre requisições por conteúdo, revisão de contato e superfície, TTL até uma hora, invalidação em save_post e troca de contato; diagnóstico com raízes e bytes por fase. Repetir as 64 comparações de HTML. Aceite de campo exige três amostras <=100 ms próprios em fator3.com.br; números enviados pelo dono são evidência recebida, não medida desta execução.

362: publicar os ativos e confirmar manifesto vigente antes de confirmar o ciclo; impedir prova de cabeçalhos/cache se manifesto não estiver vigente. Validar a primeira cópia da home na próxima atualização do Site-Teste.
