from pathlib import Path
import os,subprocess,json,shutil,zipfile,hashlib
root=Path(__file__).resolve().parents[1]
# This script is launched inside run-lab.py so MySQL and PHP share a network namespace.
BASE_VER=os.environ.get('F3BASE_BASE_VERSION','1.63.0');TARGET_VER=os.environ.get('F3BASE_TARGET_VERSION','1.64.0');CONTRACT=os.environ.get('F3BASE_TARGET_CONTRACT','8.29.0')
known_bases={
 '1.67.0':'d781cdbccfb00fc3224385e4e12e8e67bf4a06b58e2c1f1d6a686bca3df94c6b',
 '1.66.0':'0f796b2001478fe32e5ce47b5851f79148e6a1eebac7087c39a603a587692830',
 '1.65.1':'059d7da03484eb3d9eb7327f49787144466f451fcf51730ea0357d92c03f168a',
 '1.65.0':'f99d5cf933da2490baebe1d7fbe48d71a98d6b0ae00f51c0748267a471e8ed42',
 '1.64.0':'e8c34d1cfbd347f6947e4e208fed92c11579c735f843d6c2e002c4fe29ce6588',
 '1.63.0':'afd99c56edc9445f7498e010d3123d8497fd0dd335b3cc283b5156c7de855c5b',
 '1.62.0':'3dcbae9b1e22b915ac32ae3074cec1ed15706d4a475a9cf5d5b9e12663922646',
 '1.61.1':'9cfbab0b667c877c3c14b9d6704c827665d20d7b34ff4c9b9d915d6b3c9bd6d3',
 '1.61.0':'77f914d180bafb9432e6e8dea332bf57ad6839e63670ccd282c3c8469703f4f1',
 '1.60.0':'1dc4e94305ea55394024d6527bc06b46209f0ae51a55f734853763bcb232e27c',
 '1.59.0':'8f3992e89b44f53a59e0e2af314ff8548fe2aadfcc06afe30e395610b1b7c832',
 '1.58.0':'71bf6497a2f2e2c605baf64f0f82c273201915039506b58ac220fc572afbd5e4',
 '1.57.1':'ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62',
}
assert BASE_VER in known_bases, 'Supported bases are canonical Core 1.58.0 and the separately exercised 1.57.1 direct upgrade.'
base=Path(os.environ.get('F3BASE_BASE_ZIP',str(root/'release'/f'base-site-core-fator3-{BASE_VER}-instalador.zip')))
BASE_SHA=os.environ.get('F3BASE_BASE_SHA256',known_bases[BASE_VER])
assert base.is_file(), 'Supply the canonical base installer with F3BASE_BASE_ZIP; it is not bundled in the source.'
assert hashlib.sha256(base.read_bytes()).hexdigest() == BASE_SHA
candidate=Path(os.environ.get('F3BASE_CANDIDATE',str(root/'release'/f'base-site-core-fator3-{TARGET_VER}-instalador.zip')))
assert candidate.is_file(), 'Build the exact installer before the native-cycle proof.'
candidate_sha=hashlib.sha256(candidate.read_bytes()).hexdigest()
lab=Path(os.environ.get('F3BASE_LAB_DIR',str(root/'lab')))
results={}
evidence_dir=root/os.environ.get('F3BASE_EVIDENCE_DIR','evidence/1620');evidence_dir.mkdir(parents=True,exist_ok=True)
for kind in os.environ.get('F3BASE_CYCLE_KINDS','fresh,upgrade').split(','):
 assert kind in {'fresh','upgrade'}, kind
 content=lab/f'content-{kind}'
 if content.exists():shutil.rmtree(content)
 content.mkdir();(content/'plugins').mkdir()
 shutil.copytree(lab/'wordpress/wp-content/mu-plugins',content/'mu-plugins');shutil.copytree(lab/'wordpress/wp-content/themes',content/'themes')
 with zipfile.ZipFile(candidate if kind=='fresh' else base) as z:
  z.extractall(content/'plugins')
  for entry in z.infolist():
   if not entry.is_dir():assert (content/'plugins'/entry.filename).read_bytes()==z.read(entry),entry.filename
 env=dict(os.environ,F3BASE_LAB_DB=os.environ.get('F3BASE_LAB_DB','core_lab')+'_'+kind,F3BASE_LAB_CONTENT=str(content))
 def call_script(script,mode,*args):
  r=subprocess.run([str(root/'build/php'),str(root/'tests'/script),mode,*map(str,args)],env=env,capture_output=True,text=True)
  if r.returncode:raise RuntimeError(mode+' '+r.stdout[-1000:]+r.stderr[-1000:])
  try:return json.loads(r.stdout)
  except:raise RuntimeError(mode+' '+r.stdout[-1500:]+r.stderr[-1000:])
 def call(mode,*args):return call_script('cycle-1370.php',mode,*args)
 def current(mode,expected=TARGET_VER):return call_script('cycle-1590.php',mode,expected)
 out={'install':call('install')};assert out['install']['ok'],out
 assert out['install']['versao']==(TARGET_VER if kind=='fresh' else BASE_VER),out['install']
 if kind=='upgrade':
  out['seed']=call('seed')
  if BASE_VER in {'1.58.0','1.59.0','1.60.0','1.61.0','1.61.1','1.62.0','1.63.0','1.64.0','1.65.0','1.65.1','1.66.0','1.67.0'}:
   out['base_tables_seed']=current('seed',BASE_VER);assert out['base_tables_seed']['ok'],out['base_tables_seed']
  if TARGET_VER=='1.67.0':out['meta_legacy_seed']=call_script('cycle-1670.php','seed')
  if TARGET_VER=='1.68.0':out['reproduction_1680']=call_script('reproduce-1680.php','probe')
  out['before']=call('snapshot');out['upload']=call('native-upload',candidate);assert out['upload']['ok'],out['upload']
 if TARGET_VER in {'1.65.0','1.65.1','1.66.0','1.67.0','1.68.0'}:
  cli=subprocess.run([str(root/'build/php'),str(root/'dependencies/wp-cli.phar'),'--allow-root','--path='+str(lab/'wordpress'),'cron','event','run','--due-now'],env=env,capture_output=True,text=True,timeout=180)
  assert cli.returncode==0,cli.stdout[-1500:]+cli.stderr[-1500:]
  status=call('status');assert status['urgente']==TARGET_VER and status['ciclo']['finalizacao_em'],status
  out['migrate']={'ok':True,'via':'WP-CLI 2.12.0 nativo --due-now','primeira_passagem_confirmada':True}
  if kind=='upgrade':assert status['carregamento']['clarity']=='imediato' and status['carregamento']['meta']=='herdar' and status['carregamento']['linkedin']=='imediato',status['carregamento']
 else:
  out['migrate']=call('migrate-executor' if kind=='upgrade' and TARGET_VER=='1.64.0' else 'migrate')
 print(json.dumps(out['migrate']),flush=True);assert out['migrate']['ok'],out['migrate'];out['finalize']=call('finalize');out['status']=call('status');assert out['status']['versao']==TARGET_VER and out['status']['structure_ready'],out['status'];assert out['status']['contrato']==CONTRACT;assert out['status']['tentativas_prontas'];assert out['status']['callback_preservada'];assert not out['status']['gtm_agendado'];assert out['status']['ga4_tabelas'] and out['status']['ga4_desligado'] and out['status']['ga4_retencao']==0 and out['status']['instagram_outbox']
 if TARGET_VER=='1.67.0':out['meta_schema_after']=call_script('cycle-1670.php','upgrade' if kind=='upgrade' else 'fresh')
 if kind=='upgrade':
  assert out['status']['vital_legado']['automacao']=='legado_desconhecido' and out['status']['vital_legado']['atribuicao'] is None and float(out['status']['vital_legado']['valor'])==13000;assert all(out['status']['conteudo_padrao'].values()),out['status']['conteudo_padrao'];out['email']=call('email-check');out['after']=call('snapshot');(evidence_dir/'native-cycle-debug.json').write_text(json.dumps(out,indent=2));assert out['before']==out['after'],(out['before'],out['after']);assert out['status']['vazio_preservado'] and out['status']['procedencia_preservada'] and out['status']['textos_acrescentados_corretamente'],out['status'];assert out['status']['cursor']['ate']==1500000123
 if 'base_tables_seed' in out:
  out['base_tables_after_upgrade']=current('snapshot');assert out['base_tables_after_upgrade']['tables']==out['base_tables_seed']['tables'],out['base_tables_after_upgrade']
  out['new_tables_seed']=out['base_tables_after_upgrade']
 else:
  out['new_tables_seed']=current('seed');assert out['new_tables_seed']['ok'],out['new_tables_seed']
 out['repeat']=call('migrate');assert out['repeat']['codigo']=='atual',out['repeat']
 out['new_tables_after_repeat']=current('snapshot');assert out['new_tables_after_repeat']['tables']==out['new_tables_seed']['tables']
 # Native uninstall leaves commercial/test receipts; only pending work is suspended.
 # Reactivation exercises dbDelta over these populated tables, in another request.
 out['uninstall']=current('uninstall');assert out['uninstall']['ok'],out['uninstall']
 out['reactivate']=current('reactivate');assert out['reactivate']['ok'],out['reactivate']
 out['refinalize']=call('finalize');assert out['refinalize']['ok'],out['refinalize']
 if TARGET_VER=='1.67.0':out['reinstall_structure']=call_script('cycle-1670.php','reinstall')
 out['new_tables_after_reinstall']=current('snapshot');assert out['new_tables_after_reinstall']['tables']==out['uninstall']['tables'],out['new_tables_after_reinstall']
 assert hashlib.sha256(candidate.read_bytes()).hexdigest()==candidate_sha, 'Candidate changed during native-cycle proof.'
 results[kind]=out
 print(kind, 'OK',flush=True)
results['candidate_sha256']=candidate_sha;results['base_sha256']=BASE_SHA;results['base_version']=BASE_VER;results['target_version']=TARGET_VER;results['target_contract']=CONTRACT;results['clock']=f'Native first cron passage confirms {TARGET_VER}; legacy finalization helper follows idempotently in a separate request'
(evidence_dir/('native-cycles-'+TARGET_VER.replace('.','')+'.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2))
