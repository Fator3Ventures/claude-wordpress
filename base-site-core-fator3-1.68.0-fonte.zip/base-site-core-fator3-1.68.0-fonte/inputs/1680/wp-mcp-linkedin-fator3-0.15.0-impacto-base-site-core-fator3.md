# Impacto — LinkedIn 0.15.0 → Fator3 Site Core

Revisão 3, rodada de 02/11/2026. Etapa entrega, situação **aberto**. Classificações `acao-necessaria` e `validacao-coordenada`; natureza contrato/comportamento Lead Sync. Emissor `wp-mcp-linkedin-fator3`, base aceita 0.14.0, alvo implementado 0.15.0. Destinatário `base-site-core-fator3` 1.67.0 examinado. Instalador emissor: 345084 bytes, SHA-256 `e12b2b468b71c53d7ecc67c55f758ee1af5ba2b24082f9b12046c66944169e85`.

## Pedidos LinkedIn 19 e 20 / Core 368

O produtor usa `leadNotifications?q=criteria&owner=(value:(sponsoredAccount:…))` na listagem e na procura anterior à criação. `leadFormResponses?q=owner` permanece. Falhas anteriores ao POST têm `remote_effect:none` e `ownership_key` quando calculável; uma repetição já despachada conserva seu efeito confirmado/incerto. Core deve preservar essa distinção em seu diário.

Getter e finder normalizam as bordas de strings em `response.raw.formResponse.answers[*].answerDetails.textQuestionAnswer.answer` com `trim`; identidade, milissegundos, espaços internos, opções múltiplas e valores não textuais permanecem. Isso incorpora a correção local enviada pela frota. Registros antigos do Core não são reescritos pelo produtor: responsável Core deve conferir o próximo lead e recuperar eventual janela em `conteudo_conflitante`, usando a identidade existente e evitando contato duplicado.

## Pedido LinkedIn 21 / Core 369

Contrato publicado **linkedin-lead-reader/1.2.0**, aditivo a 1.0/1.1. `all_forms_accounts` é um array de IDs de contas, separadamente na conexão e na concessão. A conexão precisa selecionar a conta em `assets.leads`. Todos na concessão exige todos na conexão, consumidor registrado em 1.2, permissões `metadata`, `responses`, `verify`, `subscriptions` e callback HTTPS do próprio site. Configuração por simulação/confirmação vinculada às revisões; credenciais continuam exclusivamente no produtor. Nenhuma concessão antiga é ampliada automaticamente.

O catálogo inclui ID, versão e data de criação retornados por `leadForms`; a autorização efetiva passa a incluir o formulário. A descoberta percorre páginas com checkpoint; em cada inclusão cria a assinatura na mesma passagem com chave estável por consumidor/conexão/conta/formulário/versão. A consulta `effective_status` retorna a seleção efetiva. `lead-discovery-status` expõe andamento e falhas. Outra assinatura/intenção existente não é adotada silenciosamente; erros e incerteza permanecem visíveis e pedem reconciliação pelo fluxo existente.

Hook PHP local `f3_linkedin_lead_form_discovered($event)`, emitido após persistência atômica de evento/checkpoint. Campos: `contract`, `event_id`, `sequence`, `consumer_id`, `connection_id`, `account_id`, `credential_revision`, `grant_revision`, `form_id`, `form_version`, `created_at_ms`, `discovered_at` e `subscription`. Esta contém `ownership_key`, `subscription_id`, `state`, `remote_effect`, `operation_revision` quando disponíveis, e `code` em falha. Evento não contém resposta de lead, contato ou segredo. Assinatura falha não equivale a webhook confirmado.

Recuperação pelo método público `$reader->list_form_events(['connection_id'=>…,'account_id'=>…,'after'=>0])`: `events`, `next_after`, `has_more`, revisões e `delivery:at_least_once`, até 50 eventos por página. Core deve persistir eventos/checkpoint, deduplicar por event_id, conferir a autorização atual e continuar até has_more false. Um mesmo formulário/versão pode ter novo evento após mudança de recibo/revisão. Não reutilizar checkpoint entre consumidores, contas ou conexões. O hook sozinho não é garantia de entrega. Registro local em `linkedin/audit`, campo `form_discovery`.

## Ação do responsável Core

O Core 1.67.0 examinado registra contrato 1.1 e mantém lista própria explícita de formulários; não consome esse evento. Para o aceite do pedido 369: oferecer todos os formulários na integração, registrar 1.2, validar consumidor/conta/conexão/revisões, incorporar formulário/versão à seleção antes de aceitar a notificação, conservar o recibo e recuperar eventos após interrupção. Não criar assinatura equivalente com outra chave quando o produtor fornece a assinatura; não acessar tabelas/options/classes privadas LinkedIn. A decisão comercial de deduplicar e ingerir continua no Core.

Sequência: instalar LinkedIn 0.15.0; Core implementar consumo aditivo; habilitar seleção na conexão/concessão/integração por autorização explícita; criar formulário em conta autorizada e enviar lead de teste. Até essa adoção, usar a seleção explícita existente. Não há bloqueio global para instalar o LinkedIn ou operar os fluxos anteriores.

## Evidências e aceite

Provas próprias do produtor: 28 verificações dirigidas no WordPress 7.1.4 integrado; 27 no WordPress 6.4/PHP 8.1.2; autorização, revogação antes do envio, descoberta paginada, versão nova, assinatura na mesma passagem, evento/Registro, recuperação após falha entre INSERT e checkpoint sem POST duplicado, transporte MCP e isolamento entre consumidores. DOM autenticado aprovou seleção/preview/cancelamento/confirmação. Site-Teste ativo na 0.15.0, com sondas 200 e autotestes; sem conta LinkedIn configurada.

Aceite conjunto **pendente**: formulário novo descoberto e autorizado, assinatura única confirmada, inclusão observada na seleção própria do Core e lead aceito uma única vez pelo webhook. Evidências reais de ctooffice dos pedidos 19/20 são recebidas da frota, não nova homologação executada nesta rodada. A manutenção LinkedIn não alterou Core nem marcou Core 368/369 como concluídos. Arquivo entregue ao dono; não enviado a terceiros.

## Histórico

- Revisão 1: planejamento antes da implementação; contrato proposto e dependência do consumidor identificados.
- Revisão 2: contrato implementado; confirmação por revisão, outbox atômico e recuperação definidos; limites de execução e convivência explicitados.
- Revisão 3: hash do instalador, provas locais, documentação e Site-Teste acrescentados. Produtor entregue; adoção e aceite Core permanecem abertos.
