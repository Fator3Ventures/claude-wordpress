# Fonte — Fator3 MCP Meta 0.5.0

Entrega do Pedido MCP Meta 12. O instalador atualiza diretamente a 0.4.1. Este fonte não é instalável.

## Estrutura

- `plugin/wp-mcp-meta-fator3/`: runtime idêntico ao instalador e ao testado.
- `build/`: templates PHP, textos editáveis, assets e compilador determinístico. `meta/AbilityLabels.php` é a fonte única dos 33 rótulos/descrições. O build gera o catálogo JSON e a documentação compilada.
- `tests/native/release050.php`: catálogo nativo, preservação, permissões, documentos e listas MCP; `suite.php`, `release030.php` e `release040.php` mantêm regressões Meta herdadas. Números nos nomes de testes indicam sua origem histórica. Os trechos históricos de LinkedIn não são executados nesta matriz.
- `tests/site/meta050-qa.php`: sonda administrativa temporária usada no Site-Teste; excluída após o teste e ausente do instalador.
- `tools/lab.py`: laboratórios independentes com MySQL/WordPress real e fornecedores bloqueados ou simulados. Cada execução usa diretório novo e encerra somente seus processos.
- `evidence/`: evidências atuais e sanitizadas. `inputs/` contém documentos recebidos. `PLAN.md` registra análise anterior à implementação.

## Reprodução do instalador

Python 3 e PHP 8.3.6 de 64 bits foram usados nesta rodada. Defina `F3_SOCIAL_PHP` para seu executável PHP e, quando necessário, as bibliotecas do runtime em `LD_LIBRARY_PATH`. Execute `python3 build/build.py`. A saída fica em `build/dist/wp-mcp-meta-fator3-0.5.0-instalador.zip`; o SHA-256 deve coincidir com o relatório. Não coloque dependências de laboratório ou ZIPs dentro do fonte final.

A compilação confere cobertura dos schemas, unicidade e formato dos rótulos. O build não consulta WordPress nem fornecedores. O plugin instalado não precisa de Python, compilador ou ferramentas de desenvolvimento.

## Reproduzir os testes

1. Prepare PHP/MySQL e os arquivos oficiais descritos em `tools/dependencies050.json`; ajuste apenas os caminhos locais, preservando os hashes. O runtime emprestado é somente uma dependência binária; nenhum laboratório anterior foi modificado.
2. Disponibilize o instalador-base Meta 0.4.1 e os instaladores recebidos Core 1.47.0, MCP 0.27.0, Google 0.17.0 e LinkedIn 0.6.0. Não estão aninhados neste ZIP.
3. Construa o instalador. Execute `python3 tools/lab.py --manifest tools/dependencies050.json --workdir /caminho/novo-limpo --order meta-only`.
4. Para atualização integrada: `python3 tools/lab.py --manifest tools/dependencies050.json --workdir /caminho/novo-upgrade --order meta-integrated --origin upgrade`.
5. Confira `evidence/release050.json`, `native-tests.json` e `environment.json` de cada laboratório. As 329 verificações da entrega somam execuções nos dois cenários, não casos únicos. HTTP comercial é simulado/bloqueado; e-mail não é enviado.

O upgrade local substitui a árvore pelo ZIP em processo separado e confirma estado em PHP novo; a troca nativa pelo instalador MCP foi comprovada no Site-Teste. Testes de HTML/DOM usam o painel real; não equivalem a revisão visual de layout em navegador. WordPress 6.4/PHP 8.1.2 são mínimos herdados com evidência na entrega anterior, não reexecutados aqui. Não use bancos de produção para fabricar instalação limpa.

## Fechamento

O instalador foi fechado e reproduzido byte a byte antes de empacotar o fonte. `tools/package-source.py --output-dir /caminho/fora-do-fonte` recusa ZIP aninhado e sobrescrita de fonte fechado. A cópia interna do relatório é anterior ao fechamento: o hash final do fonte consta somente no relatório externo. Fonte e instalador não incluem banco, credenciais, sessões nem capturas do navegador.
