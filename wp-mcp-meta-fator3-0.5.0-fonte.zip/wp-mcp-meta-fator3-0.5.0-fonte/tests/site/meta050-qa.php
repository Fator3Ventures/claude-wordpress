<?php
/** Temporary fixed-scope acceptance probe; never part of the installer. */
add_action('wp_abilities_api_init',static function(){
 wp_register_ability('meta/qa-release050',['label'=>'Meta: verificar tradução nesta rodada','description'=>'Verificação temporária e administrativa de metadados, DOM e preservação; sem acesso a fornecedores.','category'=>'meta','input_schema'=>['type'=>'object','properties'=>new stdClass(),'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>static function(){
  if(!current_user_can('manage_options'))return new WP_Error('forbidden','Permissão insuficiente.');
  $labels=[];$contracts=[];
  foreach(wp_get_abilities() as $name=>$a){if(!str_starts_with($name,'meta/')||$name==='meta/qa-release050')continue;$labels[$name]=['label'=>$a->get_label(),'description'=>$a->get_description()];$meta=$a->get_meta();unset($meta['fator3']['version']);$contracts[$name]=['input'=>$a->get_input_schema(),'output'=>$a->get_output_schema(),'meta'=>$meta];}
  ksort($contracts);ksort($labels);$ui=[];$old=$_GET;
  try{foreach(['connections','history'] as $tab){$_GET=['page'=>'wp-mcp-fator3','tab'=>$tab];ob_start();\Fator3\McpFiles\Admin::render();$html=ob_get_clean();$dom=new DOMDocument();@$dom->loadHTML('<?xml encoding="UTF-8">'.$html);$xp=new DOMXPath($dom);$matched=0;
    foreach($labels as $name=>$text){$q=$tab==='history'?'//select[@id="f3-filter-ability"]/option[@value="'.$name.'"]':'//label[@data-choice][input[@value="'.$name.'"]]/span';$nodes=$xp->query($q);if($nodes->length&&str_contains($nodes->item(0)->textContent,$text['label']))$matched++;}
    $ui[$tab]=['matched'=>$matched,'expected'=>count($labels)];
  }}finally{$_GET=$old;}
  global $wpdb;
  $records=$wpdb->get_results('SELECT * FROM '.\Fator3\Meta\Store::table()." WHERE bucket<>'audit' ORDER BY bucket,record_key",ARRAY_A);
  $history=$wpdb->get_results('SELECT * FROM '.\Fator3\Meta\History::table().' ORDER BY row_key',ARRAY_A);
  $options=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%' AND option_name<>'f3_meta_audit_health' ORDER BY option_name",ARRAY_A);
  $cron=[];foreach(_get_cron_array() as $ts=>$hooks)foreach($hooks as $hook=>$events)if(str_starts_with($hook,'f3_meta_'))$cron[$ts][$hook]=$events;
  return ['version'=>\Fator3\Meta\Config::VERSION,'total'=>count($labels),'labels'=>$labels,'contracts_sha256'=>hash('sha256',serialize($contracts)),'data_sha256'=>hash('sha256',serialize([$records,$history,$options])),'records'=>count($records),'history_rows'=>count($history),'cron'=>$cron,'ui'=>$ui,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION];
 },'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>true,'destructive'=>false,'idempotent'=>true],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>\Fator3\Meta\Config::VERSION,'mode'=>'read','policy_contract'=>1,'remote_effect'=>'none','local_effect'=>'none']]]);
},30);
