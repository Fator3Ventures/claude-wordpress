# Planejamento — Fator3 MCP Meta 0.5.0

Revisão 1 · 22/10/2026 · implementação. Normas comuns revisão 4, lidas integralmente.
Base: 0.4.1, instalador SHA-256 719e3db7bb55f58cd08c2e78420e06374a6a4b08fad693e849677783ddc82de2. Alvo previsto: 0.5.0; instalador ainda não gerado nesta etapa.

## Escopo
Pedidos MCP Meta 12(a,b,c): 33 rótulos e descrições em português, específicos por ação, sem alterar identificadores. Registro nativo será a fonte para o MCP e suas telas; catálogo textual instalado gerado da mesma fonte. Preservar schemas, callbacks, autorização, opções, conexões, agendas, histórico e métricas.

## Análise de fronteiras antes da implementação
MCP 0.27.0 lê get_label/get_description no registro público; Clientes conectados e Registro usam Admin::ability_label. Não exige tradução paralela ou adaptação do MCP. Core 1.47.0, Google 0.17.0 e LinkedIn 0.6.0 não consomem rótulos como chave de contrato; identidades e comportamento Meta permanecem iguais. Não foi identificado impacto técnico que exija encaminhamento individual. Implantador não recebido: não avaliado; sem risco técnico concreto identificado nesta alteração de metadados. Zero impactos previstos.

## Validação prevista
Comparar todos os IDs, schemas, metadados funcionais e implementação de execução com a base. Bloquear build com rótulo ausente/duplicado. Instalação limpa isolada, atualização direta da 0.4.1 com acompanhantes vigentes, permissão administrativa e documentação integral. No Site-Teste, inventário inicial/final, atualização serial com pré-imagem e hash, descoberta das 33 abilities, renderização das listas administrativas, leitura MCP paginada e autoteste. Fornecedores não serão chamados para esta mudança de metadados.

## Evidências recebidas
A aba atual encerrou Meta 10/11 na 0.4.1. O relatório anterior que deixava Meta 11 pendente é histórico; prevalece o aceite recebido de 21/10. Não repetir homologação Porter como se fosse teste próprio. Pendências reais de rotação/histórico/Story e assinante (frota 20) continuam distintas desta alteração.
