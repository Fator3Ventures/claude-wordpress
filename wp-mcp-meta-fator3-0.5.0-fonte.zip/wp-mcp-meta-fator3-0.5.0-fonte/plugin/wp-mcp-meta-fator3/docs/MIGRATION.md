# Atualização 0.4.1 → 0.5.0

A base direta desta release é 0.4.1. Também admite instalação nova. Use o ZIP instalador com a pasta estável `wp-mcp-meta-fator3/`; não execute a desinstalação. Faça backup dos arquivos e banco e confira o SHA-256 do relatório antes da troca.

A 0.5.0 altera rótulos e descrições das habilidades e sua documentação. Não muda schema, formato de cifra, identificadores, parâmetros, permissões, conexões, agendas, coletas ou histórico. Não exige recadastrar credenciais, reautorizar planos ou recriar perfis MCP. Os campos opcionais de agenda existentes na 0.4.1 permanecem válidos.

Após a troca, em uma nova requisição, confira `meta/status`, `meta/selftest`, a descoberta `meta/` e `meta/documentation` com `document=index`. A versão deve ser 0.5.0 e as 33 habilidades devem ter rótulos em português. Reabra Clientes conectados e Registro para carregar os textos novos.

Reversão de arquivos para a 0.4.1 restaura os rótulos anteriores. Não desfaz coletas, auditoria nem efeitos realizados após a troca. Preserve backup coordenado, salts e dados atuais; não restaure um banco antigo sobre filas vivas. Os comprovantes e limites dos testes constam no relatório da entrega.

## Histórico anterior

Na rodada anterior, 0.4.0 foi intermediária apenas no Site-Teste e 0.4.1 foi a entrega final, com correções de apresentação do diagnóstico. Isso não estabelece uma etapa intermediária para atualizar da 0.4.1 à 0.5.0.
