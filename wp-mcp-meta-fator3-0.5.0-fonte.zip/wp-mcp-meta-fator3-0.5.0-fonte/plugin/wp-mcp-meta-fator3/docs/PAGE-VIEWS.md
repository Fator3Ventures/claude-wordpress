# Visualizações do perfil da Página — Meta 11

A 0.4.0 inclui `page_views_total` no catálogo `page_insights`. A consulta diária é:

```json
{"connection_id":"conexao-selecionada","channel":"facebook","account_id":"ID_DA_PAGINA_AUTORIZADA","report":"page_insights","date_from":"2026-10-12","date_to":"2026-10-18","granularity":"day","fields":["page_views_total"]}
```

Na interface escolha esses valores pelos seletores e datas; IDs são apenas parte do contrato MCP. A Graph recebe `metric=page_views_total`, `period=day` e uma janela por dia. A versão efetiva da conexão acompanha a resposta. Zero remoto é conservado; ausência ou rejeição produzem valor null e cobertura incompleta, com diagnóstico sanitizado e código/subcódigo quando existentes. Não há substituição por `page_media_view` nem equivalência inferida com visualizações de mídia.

O catálogo conserva `requires_remote_validation` e a disponibilidade condicional em v24.0. A métrica precisa ser aceita para o ativo e a credencial da consulta; a tradução das habilidades não altera esse comportamento.

## Evidência recebida e limites

O documento de pedidos recebido registra Meta 11 aceito na 0.4.1 em 21/10/2026: comparação diária com Porter em CTO Office e Korvena. O aceite foi informado pela frota; não foi reexecutado na 0.5.0. O relatório anterior da 0.4.1 ainda marcava essa comparação como pendente e foi superado pela aba atual de pedidos nesse ponto.

A validação recebida não comprova disponibilidade universal em qualquer Página ou versão da API. Novas conexões precisam validar identidade, permissões e resposta efetiva. Zero remoto permanece zero; ausência ou rejeição permanece indisponibilidade. Meta 9 continua encerrado conforme o relato anterior.
