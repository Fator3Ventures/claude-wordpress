# Base Site Core Fator3 — 1.14.0

Esta pasta contém o código exato do instalador, documentação instalada, testes e evidências. `PLANO-APROVADO.md` é a especificação histórica de entrada; o estado entregue está em `RELATORIO-1.14.0.md`.

## Instalar

Use o ZIP `base-site-core-fator3-1.14.0.zip` pelo WordPress. Caminhos suportados: site novo, base 1.12.0 concluída ou 1.13.0 concluída. Não executar os scripts de bancada em um site real. Fazer snapshot por site antes de atualizar. As regras do servidor exigem operação explícita com revisão, backup e sonda; não são aplicadas silenciosamente pela ativação.

A documentação completa está em `fontes/plugin/docs/DOCUMENTACAO.md` e acompanha o plugin instalado. Use `f3base/documentacao-ler` ou leitura autenticada dos arquivos. Sua publicação HTTP é bloqueada. Guias de métricas, banco, campanhas, testes de agentes, migração e recuperação estão nesse índice.

## Build dos assets

Node.js e npm são dependências apenas de desenvolvimento. A versão do Terser está fixada no package-lock.

```sh
node suite/build-assets/build.cjs fontes/plugin
node suite/build-assets/build.cjs fontes/plugin --check
node suite/build-assets/verificar.cjs fontes/plugin
```

`montar-release.py` gera ZIP e manifesto a partir do código conferido. Não altera os fontes. O manifesto por arquivo permite conferir o conteúdo independentemente dos metadados de tempo do ZIP.

## Testes

`suite/versao-1140` contém os cenários reproduzíveis. Eles exigem uma instalação WordPress descartável, banco MySQL/InnoDB real e arquivo de guarda `.f3base-bancada-110` na raiz. `dados.php` apaga tabelas sintéticas: jamais aponte para produção. O mu-plugin de exemplo em `suite/versao-1140/fixtures/fixture.php` intercepta e-mails e requisições externas; `smtp.py` fornece uma caixa local dedicada, sem entrega comercial.

O runner usado na execução foi `lab.py`, com binários e WordPress montados sob `runtime1140/` e `lab1140/` na raiz de trabalho definida por `F3BASE_TEST_WORKSPACE` (fallback: quatro níveis acima dos scripts). Esses binários, banco temporário e credenciais locais não são distribuídos. Para reproduzir, forneça os pré-requisitos nessas pastas ou invoque os PHP diretamente com `F3BASE_SITE` apontando à bancada guardada. Não acrescente a guarda a um site real. `upgrade.py` também exige os pacotes de referência 1.12.0/1.13.0 nas pastas `work/core-1.12.0/fontes/plugin` e `work/core-1.13.0/fontes/plugin`, obtidos dos instaladores arquivados dessas releases.

Versões executadas: WordPress 7.1, PHP 8.3.6, MySQL 8.0.46, Apache 2.4.58, Chromium 154.0.8037.57. Os scripts de navegador documentam a localização do Playwright e do executável usados. Ajuste esses caminhos ao ambiente de desenvolvimento; nenhuma dependência de teste vai no plugin WordPress.

As evidências detalhadas preservadas representam as rodadas indicadas. `fechamento-observado.json` registra as execuções finais resumidas. O arquivo histórico de bordas contém duas falhas corrigidas na própria fixture (padrão SQL e cruzamento da meia-noite); não é o resultado final. As provas externas estão separadas no relatório; os testes locais não comprovam recepção em contas de publicidade nem entrega em caixas comerciais.
