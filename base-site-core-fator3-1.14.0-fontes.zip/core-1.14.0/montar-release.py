"""Build the installer and per-file manifest from this source tree (Python 3)."""
from pathlib import Path
import hashlib,json,zipfile,argparse
parser=argparse.ArgumentParser();parser.add_argument('--saida',default='dist');args=parser.parse_args()
root=Path(__file__).resolve().parent;plugin=root/'fontes/plugin';dest=Path(args.saida).resolve();dest.mkdir(parents=True,exist_ok=True);rows=[]
with zipfile.ZipFile(dest/'base-site-core-fator3-1.14.0.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(plugin.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(plugin).as_posix();body=p.read_bytes();info=zipfile.ZipInfo('base-site-core-fator3/'+rel,(2026,9,28,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,body);rows.append({'arquivo':rel,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
manifest={'versao':'1.14.0','arquivos':rows,'nota':'O build usa timestamps fixos. O conteúdo por arquivo corresponde ao instalador entregue; seu hash ZIP pode diferir por metadados do empacotamento original.'};(dest/'manifesto-1.14.0.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'arquivos':len(rows),'saida':str(dest)}))
