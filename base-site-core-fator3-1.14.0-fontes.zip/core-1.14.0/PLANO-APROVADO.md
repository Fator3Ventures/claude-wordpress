# Plano final de implementação — próxima versão do F3 Base

Consolidado em 27/09/2026 sobre o pacote 1.13.0 e os três anexos recebidos: Markdown colado.md, Encaminhamento ao pacote Base Site Core Fator3 — achados em fator3.com.br.md e Recomendações.md. **Estado: especificação final para implementar e homologar; código da nova versão ainda não implementado.** A numeração será definida no fechamento da release.

**Entrega única:** um pacote completo, com ordem interna de implementação e implantação sequencial nos sites; nenhuma release parcial/intermediária. Não depender de solicitação à DreamHost. Pipedrive, demais CRM, webhooks comerciais, ingresso de leads nativos das plataformas e sincronização de custos/vendas ficam fora desta release. Contratos, captura e relatórios de anúncios com destino ao site estão incluídos.

A seção 17 consolida os cinco achados de fator3.com.br e os dois relatos adicionais, sem duplicar os itens 42, 43 e 47. Acrescenta proteção da documentação instalada, classificação de acessos, redirects externos controlados e correção/diagnóstico do transporte de análise. Os cinco 503 foram reportados em testes, o primeiro antes de alterações; não são apresentados aqui como incidente confirmado de visitantes humanos.

**Leitura para implementação:** seções 1–17 especificam comportamento e aceites; seção 18 registra a avaliação R1–R14; seção 19 fixa padrões e efeitos de atualização; seção 20 define entrega, implantação e reversão; seção 21 distingue decisões do dono de tarefas operacionais. As regras revisadas foram incorporadas nos próprios trechos afetados, sem exigir que o implementador escolha entre propostas conflitantes.

**Pendências do dono não bloqueiam a construção:** endereços comerciais e identificação do submenu são dados de operação; o controle de listagem da raiz será implementado desligado até confirmação da reversão do corte anterior. A cadência preserva os valores existentes e o padrão atual. Publicação de anúncio de teste e ativação de filtros externos exigem definição operacional antes dessas ações, sem bloquear a homologação técnica em ambiente controlado.

## Escopo fechado da implementação

1. Preencher o destinatário interno padrão com o e-mail administrativo do próprio site WordPress.
2. Usar **Arquivo gerado** como padrão de Entrega do índice.
3. Reescrever a ajuda de todos os campos de Configurações com funcionamento, orientação de escolha, vantagens, limitações e exemplo.
4. Dividir Configurações em seis sub-abas, renderizando somente o conteúdo da selecionada.
5. Remover a classificação de suspeito baseada exclusivamente em envio rápido de formulário.
6. Identificar testes por cookie ativado ao visitar uma página do plugin ou por cabeçalho HTTP simples, sem credencial e sem início obrigatório pelo MCP; excluir esse tráfego por padrão dos relatórios que suportam a identificação, com consulta reversível.
7. Preservar a identificação das chamadas ao MCP por rota e propagar a marca explícita nos testes disparados pelas ferramentas, com cobertura documentada para chamadas HTTP, execução interna e retentativas.
8. Implementar atribuição por plataforma, conta, campanha e anúncio para contatos capturados no site, unificando clique, formulário e análise. Documentar limites de leads nativos e mensageria externa, que não serão importados/sincronizados nesta release.
9. Reorganizar Medição em cinco áreas de consulta, com resumo inicial, filtros coerentes e detalhamento sob demanda; centralizar a navegação analítica hoje distribuída entre Medição e Contatos.
10. Distribuir documentação de dados, métricas, consultas e cruzamentos com plataformas dentro do plugin instalado, permitindo que agentes construam análises próprias por banco, abilities e serviços externos.
11. Remover a entrada Leads (contingência) de F3 Base e centralizar o tratamento de contatos, formulários e materiais no menu Contatos, com revisão da lista, detalhe, filtros, exportação e edição dos formulários.
12. Corrigir preservação de campanhas nos redirects, atribuição dos formulários e identificação dos CTAs sem `href` e em contêineres.
13. Unificar a política de carregamento por destino, renovar tokens antes do envio e revisar o transporte da análise com evidência de cobertura e desempenho.
14. Publicar llms.txt com cabeçalhos gerenciados e manter a geração pública utilizável durante a reconversão, incluindo llms-full.txt e Markdown.
15. Corrigir o grafo de autoria, pessoas, serviços e FAQ; alinhar o padrão de FAQ à decisão do dono e melhorar as provas de sameAs.
16. Acrescentar controles por site contra enumeração pública, corrigir o CSS do consentimento e explicitar navegação, valores herdados, perfil e resultado da cadência.
17. Manter CRM/Pipedrive e webhooks comerciais fora da release; concluir os itens restantes de contatos sem reabrir aceites anteriores já concluídos.
18. Proteger a documentação de leitura HTTP anônima mantendo o conteúdo completo no plugin instalado e disponível ao agente por arquivo e canal autenticado.
19. Corrigir a classificação de acessos e acrescentar evidência de automação repetitiva sem tratar user agent como prova de pessoa.
20. Permitir destino HTTPS externo com hosts declarados e fragmento no destino dos redirects, em conjunto com a preservação de query.
21. Corrigir a dependência bloqueante da análise e tratar concorrência, confirmação parcial e diagnóstico de falhas de persistência, distinguindo defeito de pacote e causa ainda não demonstrada dos 503 reportados.
22. Completar requisitos de WP Super Cache, preservar séries de form_id, corrigir classificação de slugs longos e documentar efeitos por site, mudanças de regra e reversão para a 1.13.0.

Os novos padrões valem para instalação nova e campos ainda ausentes. Valores existentes, inclusive listas vazias, escolhas desligadas e entrega dinâmica explicitamente gravada, permanecem. “Padrão” não será tratado como uma ordem para substituir escolhas em toda a frota.

Os caminhos suportados continuam sendo instalação nova ou atualização de uma base 1.12.0 ou posterior concluída, incluindo atualização direta da 1.13.0. Não reintroduzir compatibilidade anterior à 1.12.0, importadores antigos ou reinicialização da política de permissões. A documentação revisada deve acompanhar o instalador.

## Diagnóstico da 1.13.0

| Pedido | Estado observado | Consequência para a implementação |
|---|---|---|
| E-mail de avisos | `f3base_contato.email_leads` tem padrão vazio. Clique e formulário consultam essa configuração; a lista específica do formulário prevalece quando declarada. | Definir o padrão na configuração e na instalação, não apenas mostrar um exemplo no campo. |
| Entrega do índice | O catálogo declara `dinamica`; `sanitiza_llms()` também usa esse valor literal quando a chave está ausente. | Trocar o padrão e eliminar a divergência entre leitura, sanitização, interface e publicação. |
| Ajuda | O componente mostra apenas `impacto` e `exemplo`. Há textos genéricos, repetição da descrição e exemplos ausentes. | Acrescentar estrutura editorial e revisar o conteúdo campo a campo. |
| Comprimento da tela | Quatro seções aparecem integralmente na mesma página, com links de âncora. A seção de privacidade reúne também llms.txt e SEO. | Criar navegação real por sub-abas e redistribuir os grupos. |
| Salvamento | Já existe um formulário por seção e revisão por opção. O redirecionamento volta à página principal. | Preservar as proteções e retornar à sub-aba de origem, inclusive após erro ou conflito. |
| Acessos MCP | `/wp-json/mcp/` consta das exclusões padrão; o parser normaliza `rest_route` e subdiretórios. A visão padrão de conteúdo não inclui essas rotas, mas os agregados técnicos conservam a contagem. | Preservar a regra e as configurações existentes; tratar separadamente as requisições e registros de teste gerados por uma ferramenta. |
| Navegação analítica | Medição oferece Comportamento/Acessos; Comportamento renderiza comparação, tempo, acionamentos, visitas, profundidade, vitais e saídas em sequência. Os relatórios integrados estão documentados em Contatos → Relatórios. | Reorganizar por objetivo de consulta, carregar a análise selecionada e evitar telas concorrentes para o mesmo indicador. |
| Documentação para agentes | Há índice instalado, guia de relatórios e leitura paginada por ability. O guia descreve relações e limites, mas não oferece um dicionário completo de colunas e um contrato estruturado para cruzamentos externos. | Ampliar a documentação existente e validar as consultas contra o schema efetivamente distribuído. |
| Leads e formulários | Lista usa texto livre para estados fechados; detalhe expõe JSON antes dos controles; CSV consulta sem os filtros da lista. Editor mostra todas as definições abertas e o JSON completo. | Listagem operacional, controles adequados, detalhe legível, exportação do recorte e editor por formulário. |
| Leads (contingência) | Submenu reportado pelo dono. No pacote local 1.13.0 não foi localizado registro desse submenu/CPT, embora constantes e comentários históricos permaneçam. | Confirmar a origem na instalação que o exibe e garantir menu final sem essa entrada; preservar os registros e evitar reintrodução de fluxo antigo. |

Inventário do catálogo carregado em bancada: **26 opções declaradas operáveis e 81 campos**; **21 opções e 76 campos** pertencem às seções exibidas em Configurações. A política do site pode reduzir esse conjunto. Entre os 76, seis têm impacto ou exemplo incompleto: `email_leads`, `avisar_por_clique`, `avisar_por_formulario` e `classes_cta` de `f3base_contato`; `f3base_llms.blocos_interface`; `f3base_seo_entidade.pessoas`.

Os cinco itens operáveis sem seção nessa tela são `f3base_redirects`, `f3base_cabecalhos`, `f3base_nav_id`, `f3base_cadencia` e `f3base_formularios`. Não serão incluídos como editores genéricos apenas para preencher abas. Seus pontos de operação e permissões permanecem; Formulários terá um link contextual na sub-aba Contato.

## 1. Destinatário interno padrão

### Comportamento

- Fonte: `get_option('admin_email')` do site atual. É a opção usada pelo campo **Administration Email Address** do WordPress. Não usar o e-mail do usuário conectado, do administrador da rede ou `new_admin_email`, que pode representar alteração ainda pendente.
- Validar o endereço e preencher uma lista com um destinatário, mantendo o limite existente de cinco. O valor precisa aparecer efetivamente no controle, nunca apenas como placeholder.
- **Copiar o endereço na inicialização do campo**, como padrão configurado. Depois disso, mudar o e-mail administrativo do WordPress não troca silenciosamente o destinatário dos leads.
- Disponibilizar uma ação secundária **Usar e-mail da administração**, que preenche o endereço vigente e marca o formulário como alterado. A gravação só ocorre em **Salvar contato**.
- Se o endereço administrativo estiver ausente ou inválido, informar que falta um destinatário válido. Não inventar um endereço nem declarar o aviso como configurado.
- Preservar `avisar_por_clique` e `avisar_por_formulario`. Configurar destinatários não reativa avisos que o operador desligou.
- A resposta automática ao visitante continua sendo outra configuração, desligada por padrão.
- `saude-ler`, `como-usar` e a tela devem mostrar origem do destinatário e situação do aviso. Aviso habilitado sem destinatário efetivo válido fica degradado/desconfigurado; avaliar a precedência por formulário para não acusar falha onde há lista própria. Um endereço válido não comprova transporte nem leitura pela equipe.
- A medição do anexo informa chave já gravada nos 14 sites, vazia em 12. O novo padrão não preenche esses vazios. E-mail administrativo técnico permanece o padrão solicitado para instalação nova; o implantador pode gravar o endereço comercial informado pelo dono. Essa escrita operacional não exige nova funcionalidade do Core.

### Inicialização e atualização

| Estado encontrado | Resultado |
|---|---|
| Instalação nova | Inicializar o campo com o endereço administrativo válido e registrar origem padrão. |
| Opção existente sem a chave `email_leads` | Acrescentar o padrão, preservando os demais valores do grupo, sob revisão e com retomada segura. |
| Um ou mais destinatários gravados | Preservar exatamente a escolha válida. |
| Vazio explícito (`''` ou `[]`) | Preservar. Não é possível deduzir que o vazio tenha sido acidental. Exibir orientação e a ação de preenchimento. |
| Dado inválido/corrompido | Diagnosticar, sem sobrescrever silenciosamente como se fosse chave ausente. |

O catálogo deve declarar o mesmo padrão usado pela inicialização. A rotina de instalação deve materializar o destinatário uma única vez, de forma idempotente, evitando que um padrão aparentemente configurado acompanhe mudanças futuras de `admin_email` sem uma ação do operador.

### Precedência e avisos existentes

1. Um formulário que declara `destinatarios` usa essa lista; uma lista explicitamente vazia não herda a lista geral.
2. Formulário sem essa chave usa `f3base_contato.email_leads`.
3. Clique usa `f3base_contato.email_leads`.

Não reescrever `dados.destinatarios` de contatos já registrados nem reenviar mensagens por causa da atualização. O aviso individual usa o destino registrado no contato. O resumo horário existente usa a lista geral vigente; essa distinção deve constar da ajuda de avisos. A inicialização não deve disparar e-mail de teste ou de instalação.

### Texto da ajuda

**Como funciona:** define quem recebe os avisos internos de contatos. Na configuração inicial, usamos o e-mail da administração do WordPress. Cada formulário pode ter uma lista própria. O resumo horário usa esta lista geral.

**Quando escolher:** mantenha o endereço administrativo se essa caixa também recebe as solicitações comerciais; substitua pela equipe responsável quando o atendimento tiver outra caixa.

**Vantagens:** permite começar com um destinatário já cadastrado e centraliza os avisos dos formulários que não possuem lista própria.

**Limitações:** uma caixa usada só para manutenção pode não ser acompanhada pela equipe comercial. Preencher o endereço não comprova entrega pelo serviço de e-mail. Depois de salvo, ele não acompanha automaticamente mudanças do e-mail administrativo.

**Exemplo:** `contato@example.com` e `comercial@example.com`, um por linha. Para suspender avisos sem interromper os registros, use os controles de aviso por clique e por formulário.

**Vazio:** nenhum destinatário geral está configurado; formulários com lista própria continuam seguindo essa lista.

## 2. Entrega do índice: Arquivo gerado

### Comportamento

- Padrão da chave `f3base_llms.entrega`: **`arquivo_gerado`**. Manter o outro valor permitido, **`dinamica`**.
- Aplicar o padrão quando a opção ou essa chave estiver ausente. Preservar uma escolha explícita por `dinamica`, mesmo que coincida com o padrão da versão anterior.
- Fazer `sanitiza_llms()` usar o padrão declarado para chave ausente. Revisar também os valores de reserva em `F3Base_Llms_Arquivo::ativo()` e consumidores, evitando mais de uma definição concorrente.
- Atualizar o exemplo atual “Dinâmica é o padrão”, o contrato apresentado aos agentes e a documentação instalada.
- Garantir que uma instalação nova acione a preparação/agendamento do arquivo pelo ciclo de publicação existente. O aceite não se limita à opção aparecer selecionada.
- Respeitar os requisitos existentes: publicação habilitada, site público, ausência de outro publicador concorrente e ausência de exigência de acesso dinâmico.
- Não sobrescrever um `llms.txt` externo. Sem permissão de escrita ou com impedimento de publicação, mostrar o motivo e a ação aplicável, sem informar que o arquivo está publicado.
- Separar **modo configurado**, **arquivo gerado** e **entrega HTTP verificada**. Uma falha não deve trocar a preferência para Dinâmica silenciosamente. Se a rota dinâmica responder durante a pendência, o diagnóstico deve identificá-la corretamente.

### Texto da ajuda

**Como funciona:** escolhe como o índice público `llms.txt` é entregue. O conteúdo continua sendo produzido a partir das regras de publicação do plugin.

| Opção | Vantagens | Limitações / quando considerar a outra opção |
|---|---|---|
| **Arquivo gerado — padrão** | Permite que o servidor entregue o índice sem executar o WordPress a cada leitura. | Exige escrita no diretório de publicação e configuração correta dos cabeçalhos no servidor. O arquivo depende de regeneração para refletir mudanças. |
| **Dinâmica** | Evita manter um arquivo físico e permite que o WordPress controle a resposta. | Executa o processamento da aplicação quando a requisição chega ao WordPress; a carga e a atualização percebida também dependem dos caches envolvidos. |

**Quando escolher:** prefira Arquivo gerado quando o site for público e a hospedagem permitir publicação e validação do arquivo. Use Dinâmica quando as restrições da hospedagem ou do acesso exigirem resposta pela aplicação.

**Exemplo:** com atualização de uma hora, o arquivo depende da execução das tarefas agendadas. Visitas atendidas inteiramente pelo cache não executam PHP; em sites com poucas visitas, configure a execução periódica do cron. A verificação pública confirma o que está sendo servido.

Não prometer atualização instantânea, melhoria de posição em buscadores ou leitura garantida por serviços de IA. As regras atuais de exclusão de conteúdo privado, protegido ou não publicável permanecem obrigatórias.

## 3. Sub-abas de Configurações

Manter as abas principais **Configurações**, **Informações técnicas** e **Operação**. Dentro de Configurações, adotar a organização abaixo. As contagens representam o catálogo da 1.13.0 e servem como referência, não como limite fixo para futuras opções.

| Sub-aba | Identificador | Grupos e opções | Campos atuais |
|---|---|---|---:|
| Contato | `contato` | `f3base_contato`: registro e avisos, WhatsApp, instrumentação; link para Formulários. | 7 |
| Medição e anúncios | `medicao` | GA4, GTM, Google Ads, Meta Pixel/CAPI, LinkedIn, atribuição, verificações Google/Meta, carregamento por destino, acessos do servidor e comportamento local. | 24 na base |
| Consentimento | `consentimento` | `f3base_consentimento`. | 7 |
| Privacidade e segurança | `privacidade` | `f3base_retencao_meses`, `f3base_sessao`, `f3base_origem_confiavel`; incluir o grupo de proteção pública da seção 16.9. | 8 na base |
| Conteúdo e IA | `conteudo` | `f3base_llms`, `f3base_robots`. | 13 |
| SEO | `seo` | `f3base_seo_entidade`. | 17 |

Na sub-aba Medição, agrupar visualmente Contas e integrações, Origem e carregamento, e Medição local. Na sub-aba SEO, agrupar os dados relacionados da entidade. A ajuda detalhada começa recolhida. Os próprios campos continuam visíveis na sub-aba selecionada.

### Navegação e gravação

- URL: `admin.php?page=base-site-core-fator3&aba=configuracoes&secao=contato`, com identificador validado contra a lista de sub-abas.
- Usar links reais e `aria-current="page"`. Navegação e salvamento funcionam sem JavaScript, por teclado e em tela estreita. Não adotar o padrão ARIA de abas dinâmicas para links que navegam entre páginas.
- Sem `secao`, abrir Contato quando houver campos permitidos; senão, a primeira sub-aba disponível. Identificador desconhecido recebe o mesmo tratamento seguro.
- Exibir somente sub-abas com campos autorizados pela política. Se nenhuma estiver disponível, manter a explicação existente e o acesso apropriado à gestão em Operação.
- Renderizar somente a sub-aba ativa no HTML; não apenas ocultar todas as demais por CSS.
- Um formulário por sub-aba, com botão específico: **Salvar contato**, **Salvar medição e anúncios**, etc. Evitar aparência de “salvar tudo”.
- Preservar nonce, `manage_options`, política de opções, revisão esperada por opção, leitura após gravação e apresentação de resultados parciais.
- Enviar a sub-aba de origem em campo oculto validado. No handler da tela, aceitar apenas opções pertencentes àquela sub-aba. Os demais canais mantêm seu próprio contrato.
- Salvar uma sub-aba não altera as outras; campos ausentes do POST não significam desmarcar ou limpar. Checkboxes desmarcados da própria sub-aba continuam sendo enviados explicitamente.
- Após sucesso, erro ou conflito, voltar à mesma sub-aba. Rascunho e mensagem devem ficar associados ao formulário de origem, sem recuperar conteúdo na sub-aba errada. Segredos continuam mascarados e fora do rascunho.
- Com JavaScript, avisar antes de abandonar alterações não salvas. Após salvar, não mostrar alerta indevido. Sem JavaScript, os links e formulários continuam utilizáveis e a regra de salvar por sub-aba permanece visível.
- Manter os identificadores dos campos e links contextuais para diagnóstico. Não acrescentar diagnósticos longos ao fim de cada formulário.

### Fonte única

Usar a declaração de seções do catálogo como fonte da navegação, do agrupamento, da validação do POST e da documentação. Cada opção exibida deve pertencer a exatamente uma sub-aba; um grupo não será repartido entre formulários que gravem versões diferentes do mesmo objeto. Novas opções sem seção explícita devem ser identificadas na validação do catálogo.

## 4. Ajuda completa e útil

### Estrutura editorial

Manter **Como funciona e exemplo** como resumo expansível. Fora dele, conservar uma definição breve do campo. Dentro, usar conteúdo específico:

| Bloco | Pergunta respondida |
|---|---|
| Como funciona | O que muda ao configurar e quais recursos dependem disso? |
| Quando usar | Em qual situação essa escolha ajuda? |
| Vantagens | Qual benefício concreto a opção oferece? |
| Limitações | Que custo, dependência ou perda de cobertura acompanha a escolha? |
| Exemplo | Qual configuração plausível ilustra o efeito? |
| Vazio, desligado ou padrão | O que acontece sem configuração ou ao desativar? |

Em seletores, comparar os valores disponíveis; não explicar apenas o recomendado. Em campos de identidade, endereço ou identificador, explicar a finalidade e a consequência de omitir ou preencher errado. Não inventar “contras” artificiais: “Limitações” pode indicar dependência, manutenção ou restrição real.

### Regras de conteúdo

- Cobrir todos os 76 campos atualmente exibíveis, inclusive os seis com ajuda incompleta. A regra deve acompanhar o catálogo quando novos campos forem adicionados.
- Cada explicação deve refletir o consumidor atual. Por exemplo, revisar a ajuda de GA4: os relatórios integrados da 1.13.0 existem sem que isso transforme GA4 em requisito para toda análise do plugin.
- Explicar a diferença entre captura, aviso interno e resposta ao visitante; entre sessão de navegação/medição e sessão de login; entre configuração salva e efeito publicamente confirmado.
- Para Modo de consentimento, explicar efeitos de cada valor real do catálogo sobre coleta e cobertura dos relatórios, sem prometer conformidade jurídica automática.
- Para Blocos de interface excluídos, explicar o benefício de retirar menus/elementos repetitivos e o risco de excluir conteúdo relevante. Exemplificar com um bloco registrado e deixar claro que lista vazia não equivale a “usar seleção padrão”.
- Para Classes adicionais de botões, mostrar classe sem ponto e esclarecer que instrumentar um botão não troca seu destino nem transforma todo contato em WhatsApp.
- Para retenção, indicar unidade, dados atingidos e perda de histórico ao expurgar. Para tags após interação, explicar a troca entre carga inicial e cobertura de visitas curtas.
- Usar exemplos fictícios sem dados pessoais, valores de clientes ou credenciais. Segredos devem mostrar **Onde obter**, nunca um token fictício que pareça preenchido.
- Não colocar exemplos em `value` nem como substituto visual de configuração. O e-mail administrativo padrão é um valor efetivo e deve ser distinguido dos exemplos.
- Evitar duplicar a descrição nos blocos de funcionamento e vantagens. Não usar o mesmo texto genérico em todos os campos de SEO.

### Implementação da ajuda

Acrescentar metadados editoriais estruturados ao catálogo, por exemplo `ajuda.funcionamento`, `ajuda.quando_usar`, `ajuda.vantagens`, `ajuda.limitacoes`, `ajuda.exemplo` e `ajuda.se_ausente`, com comparações opcionais para seletores. Eles são documentação, não novas configurações gravadas no banco.

Adaptar o renderizador para essa estrutura e gerar a documentação instalada a partir da mesma fonte. Rever os consumidores atuais de `impacto` e `exemplo` antes de substituí-los, incluindo verificações estáticas e serviços de consulta. Se esses campos continuarem no catálogo público, derivá-los da estrutura editorial, sem manter cópias textuais independentes.

## 5. Frentes técnicas de uma entrega única

| Frente | Mudança | Arquivos principais |
|---|---|---|
| A — Padrões | Declarar os novos padrões, resolver ausências, inicializar e preservar escolhas. | `includes/trait-f3base-options-catalogo.php`, `includes/trait-f3base-options-validacao.php`, `includes/class-f3base-configuracao-atual.php`, `includes/class-f3base-instalacao.php`. |
| B — Publicação | Alinhar leitura do modo e garantir agendamento, estado e verificação do arquivo padrão. | `includes/class-f3base-llms-arquivo.php` e pontos existentes de reconciliação/publicação. |
| C — Sub-abas | Definir seções, redistribuir grupos, renderizar a selecionada e preservar origem no salvamento. | `includes/class-f3base-options.php`, catálogo, `admin/class-f3base-admin-tela.php`, `admin/assets/f3base-admin.css` e JavaScript administrativo. |
| D — Ajuda | Escrever conteúdo por campo e renderizar blocos estruturados. | Catálogo, `includes/class-f3base-configuracao-atual.php`, renderizador administrativo. |
| E — Antispam | Separar sinal de velocidade da decisão de suspeita e testar preenchimento automático. | `includes/class-f3base-formularios.php`, cliente JavaScript e documentação de formulários. |
| F — Marcação de teste | Criar página que ativa cookie, aceitar cabeçalho HTTP simples, classificar a coleta e atualizar o armazenamento; propagar o contexto explícito nas ferramentas que executam testes. | Resolvedor comum de marcação, rota de ativação/saída, instalação, endpoints de leads/formulários/comportamento/análise, persistência de vitais/agregados e contratos das abilities envolvidas. |
| G — Relatórios e efeitos | Aplicar o segmento em todas as fontes necessárias, numeradores, denominadores, CSV e abilities; impedir conversões externas de teste pelo Core; preservar a separação entre rotas MCP e visitas públicas. | `includes/class-f3base-relatorios.php`, `includes/class-f3base-acessos-relatorio.php`, `includes/class-f3base-modulo-acessos-servidor.php`, telas de Medição/Contatos, coletores, carregadores de tags, fila de envio e avisos. |
| G2 — Atribuição de publicidade | Unificar o contrato de contatos do site, preservar IDs até o lead e organizar a visão por anúncio conforme a seção 12. | Cliente de atribuição compartilhado, leads/formulários/análise, schema, relatórios e documentação de campanhas; sem adaptadores de leads nativos nesta release. |
| G3 — Navegação de Medição | Centralizar a análise em cinco áreas, preservar filtros e carregar somente a consulta selecionada conforme a seção 13. | `admin/class-f3base-admin-medicao.php`, `admin/class-f3base-admin-acessos.php`, entrada de relatórios de Contatos, serviço de relatórios e assets administrativos. |
| G4 — Leads e formulários | Consolidar menu Contatos, revisar lista/detalhe, alinhar CSV e criar navegação/editor por formulário conforme a seção 15. | `includes/class-f3base-leads-admin.php`, repositório/abilities de leads, `includes/class-f3base-formularios.php`, editor de formulários e assets administrativos; registros de menu e referências do plugin. |
| H — Documentação | Gerar referência, dicionário/contrato de dados, definições de métricas e consultas reproduzíveis; atualizar guias e acesso dos agentes conforme a seção 14. | Documentação existente, `docs/DICIONARIO-DADOS.md`, `docs/METRICAS.md`, `docs/CRUZAMENTOS-PUBLICIDADE.md`, `docs/CONSULTAS-EXEMPLO.sql`, `docs/dados/contrato.json`, índice/allowlist de documentação e geradores. |
| J — Integridade e transporte | Incorporar as correções de redirects, atribuição, CTA, carregamento, token e envio analítico da seção 16; compartilhar os contratos com F/G/G2. | Redirects, leads/formulários, tracking, análise e serviços de marcação. |
| K — Publicação e grafo | Completar B com cabeçalhos e gerações LLMS; corrigir autoria, pessoas, ofertas, FAQ e provas HTTP. | Publicação/cobertura LLMS, schema, catálogo, verificadores e tarefa llms. |
| L — Proteção e operação | Controles de proteção pública, navegação sem vínculo, origem dos valores, perfil versionado, cadência e consentimento. | Catálogo/validação, config-core, perfil, módulos de proteção/consentimento/cadência e documentação. |
| I — Validação e pacote | Executar os aceites originais e os novos, registrar evidências e empacotar instalador e fontes. | Suíte do projeto, relatório e manifesto da nova release. |

As letras identificam frentes, não uma sequência obrigatória. A ordem de prioridade revisada está na seção 16.3. J/K/L ampliam as frentes existentes; não criam implementações concorrentes de atribuição, publicação ou configuração.

Implementar primeiro os quatro contratos comuns: marca de teste, atribuição, política por destino e leitura de padrão/herança. As demais frentes os consomem. A entrega só é liberada com o conjunto completo aprovado; controles por módulo permitem isolamento operacional, sem transformar aceite reprovado em recurso entregue.

A identificação de testes acrescenta alterações de schema e agregação, detalhadas na seção 9. A preparação dos padrões deve distinguir ausência de valor explícito pelo dado bruto, e não por `empty()` aplicado à leitura já normalizada. Escritas devem usar as rotinas de configuração com revisão; conflito exige releitura, sem substituir a revisão automaticamente.

O controle de versão da instalação precisa reconhecer a 1.13.0 concluída e continuar aceitando atualização direta da 1.12.0. Não repetir a conversão da política de listas que já foi concluída. Não reativar gestão por agentes, reabrir permissões ou preencher listas vazias durante esse ajuste.

## 6. Aceites para a release

| ID | Cenário | Resultado esperado |
|---|---|---|
| E1 | Instalação nova com `admin_email` válido | Campo preenchido com o endereço do site, origem padrão e um destinatário efetivo. Nenhum e-mail disparado pela instalação. |
| E2 | Atualizar 1.12.0 e 1.13.0 com destinatário próprio, vazio explícito ou chave ausente | Preservar próprio e vazio; preencher apenas ausente; execução repetida não muda escolhas. |
| E3 | WordPress tem mudança de e-mail pendente | Usar `admin_email`, não `new_admin_email`; mudança posterior do endereço não redireciona o destino já salvo. |
| E4 | Usar ação de e-mail administrativo | Preenche sem gravar; exige Salvar; inválido gera orientação, sem destinatário inventado. |
| E5 | Clique e formulários com lista própria, ausente e vazia | Precedência correta; flags de aviso respeitadas; até cinco endereços; registros anteriores não são reescritos nem reenviados. |
| I1 | Opção LLMS inteira ausente e grupo existente sem `entrega` | Ambos resolvem `arquivo_gerado` em catálogo, leitura, sanitização, tela e consulta pelo canal. |
| I2 | Modo `dinamica` explicitamente salvo | Atualização e gravação de outras sub-abas o preservam. |
| I3 | Site público elegível e diretório gravável | Publicação inicial agendada/executada, conteúdo esperado e prova HTTP separada do salvamento. |
| I4 | Diretório não gravável, arquivo externo, site privado ou publicador concorrente | Nenhum arquivo indevido criado/sobrescrito; impedimento correto, sem falso sucesso nem mudança silenciosa de modo. |
| I5 | Alteração de conteúdo e execução do cron | Arquivo atualizado pelo ciclo existente; retirada de conteúdo não publicável permanece eficaz. |
| A1 | Abrir cada sub-aba | Apenas seus controles estão no HTML; URL direta, voltar/avançar e atualização da página preservam a navegação. |
| A2 | Salvar sub-aba com checkbox desmarcado e lista vazia | Valores da própria aba persistem corretamente; opções das demais não mudam. |
| A3 | Erro de validação ou revisão concorrente | Volta à sub-aba correta, preserva rascunho permitido e apresenta resultado real, inclusive parcial. |
| A4 | Política Todas, Selecionadas e Nenhuma | Só opções permitidas aparecem e podem ser gravadas; política e gestão pelo canal não mudam na atualização. |
| A5 | Teclado, tela estreita e JavaScript desativado | Navegação e formulários utilizáveis; foco e rótulos corretos; ajuda expansível acessível. |
| A6 | Alterações não salvas com JavaScript | Aviso ao sair; ausência de falso aviso após gravação bem-sucedida. |
| H1 | Inventário completo dos campos exibíveis | Todos têm ajuda específica e completa; seletores comparam alternativas; exemplos não preenchem controles. |
| H2 | Conteúdo da ajuda contra código e documentação | Sem “Dinâmica é o padrão”, exemplos genéricos vazios ou afirmação de que GA4 é necessário aos relatórios locais. |
| D1 | Instalar o ZIP em WordPress limpo | Guias, dicionário, métricas, contrato JSON e consultas atualizados presentes e legíveis por arquivo e por `f3base/documentacao-ler`, sem dados do site de desenvolvimento; conferir também os aceites da seção 14. |

E-mails de teste devem ser interceptados em bancada. A homologação de interface precisa incluir navegador real; verificações de HTML ou sintaxe não substituem teclado e inspeção visual. A prova de publicação deve distinguir a bancada controlada da hospedagem real.

O aceite final usa Site-Teste com WordPress **7.1.2 e MySQL 8.0**, versões relatadas pela revisão da frota e a confirmar no preflight. Chromium/navegador real, transporte de e-mail controlado e canal autenticado fazem parte da homologação. A bancada local identificada nesta revisão usa WordPress 7.1; suas leituras/SQLite não substituem essa prova. Os e-mails de transporte real usam destinatário aprovado e não são disparados por esta preparação.

## 7. Evidência desta preparação

Foram lidos o relatório e o manifesto publicados da 1.13.0, o catálogo e os consumidores envolvidos. Os 133 arquivos locais do instalador conferem com os hashes do manifesto local da entrega. O inventário de opções foi obtido com o catálogo carregado na bancada WordPress existente, sem exibir valores de configuração. O código local do WordPress confirma que Administration Email Address usa `admin_email` e que `new_admin_email` pode estar pendente.

Esta preparação não executou os aceites da próxima versão, não produziu um novo instalador e não alterou os sites da frota.

## 8. Ajuste da regra antispam de velocidade

### Evidência e decisão

Na 1.13.0, `F3Base_Formularios::receber()` marca como suspeito tanto um honeypot preenchido quanto um envio com token de interação emitido há menos de três segundos. O cliente solicita esse token no primeiro evento `input`; se isso não aconteceu, solicita no próprio envio. Assim, a medida é o intervalo desde a emissão do token, e não uma medida confiável de quanto tempo a pessoa levou preenchendo o formulário.

Inferência a partir desse fluxo: preenchimento automático, formulário curto ou ausência do evento `input` esperado podem resultar em um contato legítimo classificado como suspeito. Não foi medida a frequência desses casos em produção.

**Decisão para esta release:** tempo inferior a três segundos, isoladamente, deixa de alterar a classificação, suspender avisos ou impedir a entrega de conteúdo. Não introduzir atraso artificial nem um novo limiar arbitrário.

### Regras de execução

- Manter assinatura/validade/revisão do token, validação de campos, limite de tentativas, deduplicação e honeypot.
- Token inválido e limite excedido continuam sendo recusas próprias. A rapidez não supera essas validações.
- Registrar `tempo_curto` apenas como sinal diagnóstico no contato, junto da versão da regra. Medir o intervalo a partir do token validado pelo servidor; não confiar em horário enviado pelo navegador.
- No fluxo sem token de interação, deixar o intervalo como desconhecido. Não usar a idade do token do HTML em cache como tempo de preenchimento.
- A decisão de suspeita atual passa a depender da isca preenchida; documentar os sinais e a regra efetiva. Uma futura combinação de sinais exigirá nova regra explícita e avaliação de falsos positivos.
- Preservar as classificações históricas e suas razões. Não promover automaticamente contatos antigos com `tempo_curto` nem disparar avisos retroativos.
- Expor contagens de suspeitos por motivo, período e versão da regra em saúde. O único caso de tempo_curto informado pelo anexo não permite estimar taxa de falso positivo ou spam, nem identificar a origem do envio por coincidência de data.
- Marcação de teste e suspeita de spam são dimensões independentes. O modo de teste deve permitir exercitar as proteções, sem desabilitar antispam, validações ou quotas.

O ajuste remove uma heurística fraca. Ele não constitui uma proteção nova contra bots que reproduzem o fluxo público. Integração com CAPTCHA ou serviço externo antispam não faz parte deste acréscimo.

## 9. Marcação simples das ações de teste dos agentes

### 9.1 Decisão do dono e finalidade

Por decisão do dono, a marcação passa a ser declarativa e dispensa credencial temporária, assinatura, autenticação específica, emissão de sessão pelo MCP e tabela de credenciais. O objetivo é separar as ações de manutenção e teste dos relatórios. Não é necessário comprovar a identidade de quem se marcou como teste.

O comportamento será o mesmo para um agente de IA ou um operador humano. O modo não concede acesso administrativo, não libera conteúdo protegido nem altera as permissões do site. Autenticação das operações administrativas, antispam, validação dos formulários e consentimento da medição continuam aplicáveis.

A abordagem por horário/IP fica fora da exclusão automática: conector e navegador podem usar IPs diferentes, e visitantes reais podem compartilhar IP e horário com testes. A nova marca acompanha o próprio cliente e os eventos que ele gera.

### 9.2 Navegador: visitar a página e ativar o cookie

1. Antes de testar, a IA abre a rota **/f3base-teste/** no navegador que utilizará.
2. A página grava **f3base_teste=1**, sem login, código, token ou chamada prévia ao MCP.
3. A página lê o cookie de volta e mostra **Modo de teste ativo — validade de 1 hora**. Se o navegador não aceitar o cookie, informa que a ativação não ocorreu.
4. A IA navega e testa normalmente nesse navegador.
5. Ao terminar, usa **Sair do modo de teste**, que remove o cookie. A expiração cobre o encerramento esquecido.

A página é uma rota do plugin, fora dos menus, sitemap e relatórios, com `noindex`, sem tags de marketing e fora do cache. A visita ativa somente o navegador que a realizou. Uma chamada HTTP feita pelo MCP não grava cookie em outro navegador.

Ativação/saída definem `DONOTCACHEPAGE`, além de private/no-store, e entram nas exclusões requeridas do WP Super Cache. Essa configuração externa é aplicada e verificada na mesma rodada da instalação. Não acrescentar o cookie de teste à lista que faz bypass de todas as páginas.

Usar cookie restrito ao host e ao caminho do site, `SameSite=Lax`, `Secure` em HTTPS e `Max-Age=3600`. O cookie é um marcador público, legível pelo JavaScript da instrumentação, sem `HttpOnly`. Isso permite reconhecer o modo antes de publicar eventos e preservá-lo nas filas. Não há segredo em seu valor.

Novas visitas à página renovam o prazo. Não é necessário armazenar sessão, IP, usuário ou identificador de agente no banco para ativar esse modo. Recomendar navegador/perfil dedicado ao teste, pois as abas do mesmo perfil e site compartilham o cookie.

**Responsabilidade operacional:** cada agente deve abrir a página de ativação antes da primeira navegação de teste de cada trabalho, no próprio site e navegador que utilizará, e conferir a confirmação. Uma ativação vale para as páginas seguintes enquanto o cookie estiver presente e dentro da validade de uma hora; não é necessário reabrir a ativação a cada página. Reativar ao trocar de site/host, usar um novo perfil/contexto de navegador, limpar cookies ou atingir a expiração. Se o trabalho ultrapassar uma hora, renovar antes de continuar os testes.

Registrar essa rotina em `INSTRUCOES-DO-PLUGIN.md`, na documentação instalada e na orientação `como-usar` acessível pelo canal. Instrução resumida ao agente: “Antes de navegar ou testar, abra /f3base-teste/ no mesmo navegador e confira Modo de teste ativo; renove quando necessário e saia ao terminar. Em clientes HTTP, envie X-F3Base-Teste: 1 em cada requisição de teste.”

O Core aplica a marca recebida e confirma sua leitura. Atividade de um agente que ignorou essa rotina permanece não marcada; não inferir silenciosamente uma identificação por IP ou acesso recente ao MCP.

### 9.3 Chamadas HTTP: cabeçalho simples

Scripts e ferramentas que controlam os cabeçalhos podem enviar:

```http
X-F3Base-Teste: 1
```

O Core reconhece essa requisição como teste. Não existe troca de credencial ou ativação anterior. A ferramenta deve enviar o cabeçalho em todas as requisições de teste ao próprio site, inclusive submissões e chamadas de coleta; colocá-lo somente na requisição que baixa o HTML não o replica automaticamente nos pedidos seguintes.

Um cliente que mantém cookies também pode usar o fluxo de ativação. A documentação instalada deve orientar a escolha: cookie para navegação no browser; cabeçalho para scripts e clientes HTTP. O MCP pode informar esses caminhos e consultar os resultados, mas não é uma dependência da ativação.

### 9.4 Contrato comum de marcação, filas e cache

- Persistir `classe_trafego = nao_marcado | teste`. A marca indica uma declaração do cliente; não afirmar identidade autenticada ou “IA comprovada”.
- Resolver a marca com uma função comum usada nos endpoints e nas filas. Aceitar somente os valores previstos, sem tratar qualquer texto não vazio como verdadeiro.
- Nas requisições gerais, o cabeçalho explícito `X-F3Base-Teste: 1` marca teste; `0` declara normal; na ausência do cabeçalho, consultar o cookie, que só marca teste quando seu valor é exatamente `1`. Valor de cabeçalho fora de `0|1` retorna erro de validação no endpoint que o recebe.
- Para eventos enfileirados, o cliente captura um booleano `contexto_teste` no momento do evento. Ele viaja nos contratos internos de coleta, inclusive nos lotes enviados por `sendBeacon`, que não permite o mesmo controle de cabeçalhos de um cliente HTTP comum.
- Nos coletores, a marca explícita do evento enfileirado prevalece sobre o estado atual do cookie. Cabeçalhos de lotes devem concordar com as marcas explícitas dos itens; divergência retorna erro identificado. Separar lotes normais e de teste.
- Assim, um evento de teste continua sendo teste se for enviado depois da expiração do cookie; um evento normal enfileirado antes da ativação continua normal. Retentativas e revisões preservam a classe original e a deduplicação.
- Ao entrar/sair do modo, separar filas e renovar contexto de navegação/sessão quando a medição estiver autorizada. Evitar que a mesma sessão de cálculo una etapas comerciais e sintéticas.
- A resposta dos coletores deve informar a classificação aplicada, permitindo conferir o funcionamento sem um protocolo de autorização adicional.
- A rota de ativação e a saída usam `private, no-store` e exclusões no cache/CDN. O HTML público continua compartilhável e o cliente consulta o cookie local antes de carregar tags controladas pelo Core.
- Não criar uma exclusão global de cache para qualquer visitante com esse cookie: o teste também precisa exercitar páginas servidas por HIT. Não colocar estado de um visitante no HTML compartilhado.
- Se o cookie expirou ou foi removido, os novos eventos voltam a não marcados; o histórico conserva a classificação persistida. Exibir o estado atual para o agente, sem criar revogação de credenciais no servidor.

O booleano adicional e o cabeçalho são marcações declarativas por decisão de produto. Eles não substituem o token de validade do formulário nem os controles administrativos existentes.

### 9.5 Filtro e armazenamento

Na sub-aba **Medição e anúncios**, oferecer **Excluir tráfego de teste identificado dos relatórios**, ativado por padrão. Nos relatórios, disponibilizar **Sem testes**, **Somente testes** e **Todos**. Não exigir identificação individual de execução nesta versão.

Guardar os registros e aplicar a exclusão na apresentação. Informar segmento, quantidade excluída e início da cobertura. A política vale para telas, CSV e abilities. `nao_marcado` não significa humano: é simplesmente a ausência da marca de teste.

| Fonte | Alteração requerida |
|---|---|
| Leads | Gravar classe na captura, inclusive sem sessão de medição; índice adequado a período/segmento. |
| Eventos detalhados e análise adicional | Gravar classe na ingestão; mantê-la nas retentativas e atualizações. |
| Vitais | Registrar classe da amostra; revisões de valor não alteram sua procedência. |
| Agregados de comportamento | Separar a classe antes de somar e incluí-la na identidade do agregado. |
| Atendimento, concessões e downloads | Usar a classe do contato/registro ao qual os indicadores estão vinculados. |

A classificação de teste é independente de `aceito/suspeito`, da marca manual de spam e da lixeira. Contatos de teste continuam acessíveis na lista e no detalhe, com identificação visível e o mesmo filtro.

O esquema acrescenta a classificação às fontes necessárias, mas não cria tabela de sessões/segredos de teste. A retenção segue os prazos existentes; expirar o cookie não apaga registros nem retira a marca histórica.

### 9.6 Cálculo e histórico

- Filtrar visitas, sessões, cliques, envios, funil, campanhas, vitais, atendimento e materiais de forma consistente. Numeradores e denominadores devem usar o mesmo segmento.
- Aplicar o segmento antes dos limites de leitura/paginação das fontes. Testes excluídos não devem consumir o teto do relatório normal.
- Incluir o segmento na chave de cache do relatório e aplicá-lo também à comparação entre períodos. Totais excluídos devem ser obtidos sem carregar todos os payloads.
- Registros anteriores à funcionalidade permanecem `nao_marcado`. Não classificá-los retrospectivamente por horário/IP.
- A seleção **Todos** recupera a visão completa dentro da retenção, sem restauração de dados.
- Este escopo não depende de classificação manual posterior nem de recomposição de sessões antigas. Não prometer separação de dados que já foram agregados sem a marca.

### 9.7 Logs brutos do servidor

A identificação de uma chamada ao endpoint MCP pela rota já é possível sem cookie ou cabeçalho de teste; a seção 9.10 detalha sua cobertura. A limitação a seguir se refere à identificação de testes nas demais requisições, como visitas a páginas públicas.

O formato de log atual não contém a marca de teste em cada linha. Não solicitar mudança de LogFormat à hospedagem nesta entrega. Se uma fonte já trouxer marcador confiável, o parser pode reconhecê-lo; caso contrário, apresentar **Segmentação de testes indisponível nesta fonte** e manter o total bruto separado. Não descontar visitas por estimativa de IP/horário, nem simular cobertura em HIT. Não copiar cabeçalhos Cookie ou dados de autenticação para criar esse recurso.

PSI remoto e robôs não ativam automaticamente o cookie. Lighthouse controlado pelo agente deve usar a marca quando o ambiente permitir. Para fontes antigas/sem marca, o relatório de análise explicita sessões/janelas de trabalho conhecidas e a limitação; não descarta dias inteiros do relatório comercial por padrão. Eventual recorte que exclua um dia é análise identificada, com volume removido informado.

### 9.8 Conversões externas e avisos

Manter captura local permitida pelo consentimento. Oferecer política por destino na sub-aba Medição e anúncios, com padrões seguros e efeito efetivo visível. A exclusão local funciona independentemente dessas integrações; a marca não configura filtros nas plataformas externas.

| Destino | Opções e comportamento | Padrão |
|---|---|---|
| GA4 | `suprimir` ou `marcar`; marcar envia debug_mode=true somente aos IDs GA4 configurados para homologação. | `suprimir` até a operação configurar e verificar o filtro da propriedade ou usar propriedade exclusiva de teste. |
| Google Ads | Suprimir conversões, remarketing e encaminhamento comercial de testes pelo Core. Debug do GA4 não é isolamento de Google Ads. | Suprimir. |
| Meta Pixel / LinkedIn no navegador | `suprimir` ou envio identificado para destino de teste explicitamente configurado. A marca local ou um parâmetro customizado não garante exclusão no fornecedor. | Suprimir; sem destino de teste válido, envio de homologação fica desconfigurado. |
| Meta CAPI | `suprimir` ou Test Events com test_event_code válido e política própria; conferir o resultado no destino. | Suprimir. Não herdar liberação do pixel nem despachar como produção quando falta código. |
| E-mail interno | `suprimir` ou `marcar` com destinatário de teste autorizado, assunto [TESTE] e cabeçalho X-F3Base-Teste: 1. | Suprimir, registrando suprimido_teste. |
| Resposta automática ao visitante | Testes ficam suprimidos; prova de transporte é operação administrativa separada com destinatário definido. | Suprimir; o comportamento normal configurado dos formulários é preservado. |

**GA4:** debug_mode, sozinho, não exclui eventos dos relatórios. Validar o filtro de tráfego de desenvolvedor primeiro em Testing, onde os dados continuam disponíveis; só o estado Active aplica a exclusão permanente. Usar DebugView como prova após ativação; não exigir presença na Realtime/Data API como aceite de dados que devem ser filtrados. O efeito não é retroativo e a propagação deve ser observada. Marcar em produção durante Testing é ação de homologação identificada, com contaminação limitada e registrada; rotina normal permanece suprimida até o filtro estar comprovado. Esta é a correção técnica ao padrão GA4=marcar sugerido em R5.

Configurar o filtro no Admin do GA4 com operador autorizado; a referência pública da Admin API consultada não expõe um recurso equivalente a Developer Traffic data filters. `subpropertyEventFilters` não substitui esse filtro. Não prometer criação pelo conector sem uma capacidade comprovada. Um passo de interface executado por agente autorizado também serve; não é intrinsecamente uma tarefa que só o dono possa realizar.

O carregador consulta a marca antes de carregar/disparar, mesmo com HTML em HIT; filas conservam a política de teste e revalidam permissões/destino antes do envio. Separar GA4 de Ads por roteamento explícito; liberar GA4 não libera todos os destinos de gtag. GTM compartilhado só é carregado em teste se o contêiner comprovar o bloqueio das tags comerciais e o roteamento correto; caso contrário, manter supressão e explicar a dependência. Não perder deduplicação browser/CAPI nos caminhos homologados.

Scripts inseridos por tema, outros plugins e regras do Meta Event Setup Tool exigem verificação própria; revisar a pendência 87 ao testar o pixel de korvena.com.br. Filtrar relatório local não remove eventos externos anteriores. A marca pública não permite escolher destinatário/conta, trocar política nem contornar autenticação, consentimento, antispam ou quotas. Testes de e-mail reais precisam mostrar resultado de transporte e entrega observado, sem confundir wp_mail aceito com chegada na caixa.

### 9.9 Desempenho e visitantes normais

A implementação deve aproveitar os scripts e coletores já utilizados pelo plugin. Para um visitante normal, a decisão é uma leitura local da marca e o fluxo habitual. O cookie de teste só é criado na ativação; não criar cookie adicional de teste em todos os visitantes.

- **Zero requisições adicionais de verificação** na navegação normal. Não consultar MCP, rota de status, API externa ou banco de sessões para decidir a classificação.
- Não carregar uma biblioteca ou arquivo JavaScript separado apenas para esse marcador. Reutilizar a instrumentação já carregada; não adicionar código de coleta a páginas que não o carregariam.
- No servidor, ler a marca da própria requisição e persistir a classe junto da gravação existente. Não acrescentar uma consulta SQL por evento para resolver o modo.
- Manter o cache compartilhado das páginas públicas: não adicionar `Vary: Cookie`, não definir `Set-Cookie` de teste na resposta de visitantes normais e não criar bypass global de cache por esse recurso. Somente as rotas de ativação/saída ficam fora do cache.
- Não acrescentar bloqueio de navegação, banner ou etapa de confirmação ao visitante normal. A confirmação aparece para quem ativou o teste.
- Ler o cookie de forma controlada e reutilizar o estado dentro da mesma operação/lote; evitar leitura por quadro de animação, movimento do ponteiro ou laço de polling. Reconhecer expiração e mudanças entre abas nos pontos necessários da coleta, sem congelar o estado durante toda a vida da página.
- A marca adiciona um pequeno processamento e um campo aos dados persistidos/coletados. A expectativa é ausência de impacto perceptível; “custo zero” ou milissegundos específicos exigiriam uma medição que ainda não existe.
- Homologar antes/depois com o mesmo site, conteúdo e condições: requisições, bytes, tempo de execução do JavaScript e entrega por cache. Conferir também os coletores e índices da nova dimensão; não atribuir variações de rede ou servidor ao cookie sem controle das condições.

A leitura tradicional de `document.cookie` é síncrona; isso reforça a regra de não colocá-la em ciclos de alta frequência. A página extra de ativação é uma ação do agente e não integra o carregamento dos visitantes comuns.

### 9.10 MCP: chamadas técnicas e testes disparados por ferramentas

**Evidência da base 1.13.0:** `F3Base_Modulo_Acessos_Servidor::EXCLUIDOS` contém `/wp-json/mcp/`. O parser reconhece a rota REST por `?rest_route=...` e o caminho relativo de instalações em subdiretório. O relatório de acessos abre em **Conteúdo**, que inclui páginas e descoberta; as rotas excluídas ficam fora desse conjunto. Suas contagens permanecem nos agregados técnicos e podem aparecer em **Mostrar todos**. Os relatórios integrados usam eventos, análise e leads; uma simples chamada ao endpoint MCP não equivale a um evento de navegação.

O relatório de entrega do WP MCP Fator3 0.12.1 documenta as URLs `/wp-json/mcp/wp-mcp-fator3` e `/wp-json/mcp/wp-mcp-ultimate`, ambas cobertas pelo prefixo. Essa é evidência documental das rotas; não confirma a configuração ou versão atualmente instalada em cada site. O inventário de rotas da combinação usada na homologação deve confirmar os endpoints efetivos e seus aliases, sem deduzir URLs a partir de nomes de ferramentas.

| Operação | Identificação e resultado |
|---|---|
| Consultar catálogo, ler conteúdo ou editar pelo MCP | Identificar a requisição técnica pela rota. Não exigir ativação de cookie nem criar visita, sessão ou conversão por causa dessa chamada. Preservar auditoria e contagem técnica. |
| Agente abrir página pública em outro navegador | Aplicar o fluxo de cookie da seção 9.2 nesse navegador. O acesso MCP não ativa nem renova seu cookie. |
| Ferramenta executar requisição HTTP de teste ao próprio site | Enviar `X-F3Base-Teste: 1` em cada requisição pertinente e persistir a classe nos dados produzidos. |
| Ability criar um evento ou contato de teste por chamada interna | Passar contexto explícito à mesma camada de captura, mesmo sem uma segunda requisição HTTP. |
| Integração registrar um contato real | Manter o tratamento normal quando não houver marca explícita de teste. A origem MCP, isoladamente, não transforma o contato em teste. |

**Contrato de propagação:**

- Inventariar as ferramentas/abilities do Core que fazem sondagens públicas, submissões sintéticas ou captura direta de eventos/contatos. Para cada caminho, indicar quem emite a requisição ou grava o registro, como recebe a intenção de teste e qual evidência comprova a marca aplicada.
- Nas abilities que executam esses testes e não permitem ao agente controlar cabeçalhos, acrescentar o argumento opcional booleano `contexto_teste`. `true` equivale à marca explícita de teste; não depender de o conector oferecer edição de cabeçalhos HTTP. Documentar o argumento no esquema e em `como-usar`.
- Resolver cookie, cabeçalho e argumento em uma função comum, seguindo a seção 9.4. Quando argumento e cabeçalho estiverem presentes, exigir concordância; conflito ou tipo inválido retorna erro identificado antes dos efeitos. Na ausência do argumento, usar o contexto válido da requisição; sem qualquer marca, permanecer `nao_marcado`.
- Passar o contexto resolvido explicitamente às chamadas internas e aos pedidos HTTP de teste. Não manter um estado global que marque outras operações, usuários, tarefas ou chamadas MCP posteriores.
- Preservar a classe original nas filas e retentativas pertinentes, mesmo depois que a chamada MCP terminou. A resposta da operação informa a classificação efetivamente aplicada; enfileiramento não deve ser apresentado como gravação concluída.
- Propagar o cabeçalho somente aos destinos autorizados do próprio site e verificar novamente o destino de redirecionamentos. Não acrescentá-lo indiscriminadamente a todas as chamadas HTTP do WordPress ou a serviços externos.
- O plugin que emite a requisição é responsável por transmiti-la com a marca. Quando essa emissão pertencer ao WP MCP Fator3 ou a outro componente, registrar a dependência e validar a integração real; o Core não controla automaticamente requisições emitidas por terceiros. A alternativa operacional já prevista é usar cliente HTTP com o cabeçalho ou o navegador com o cookie.
- Nenhuma marca altera autenticação, permissões, antispam, quotas ou consentimento. A supressão de avisos e conversões segue a seção 9.8. Auditar a operação administrativa conforme as regras existentes.

**Relatórios e atualização:**

Preservar a exclusão das rotas MCP na visão de visitantes e sua consulta nos totais técnicos. Não transformar o rótulo heurístico de User-Agent “humano” em prova de visita quando a rota é técnica. Verificar as mesmas regras em tela, CSV e consulta por ability, inclusive com filtros de erros e comparação entre períodos.

Preservar `f3base_acessos.caminhos_excluidos` explicitamente gravado, incluindo lista vazia. Rotas REST continuam classificáveis como API quando não estiverem na lista de exclusões; a atualização não deve repor silenciosamente a lista padrão para conseguir o resultado. Inventariar e corrigir lacunas de classificação efetivamente encontradas, sem ampliar exclusões a páginas públicas por semelhança textual com “mcp”.

A exclusão por rota continua funcionando nos logs atuais. Já a separação entre visita pública normal e teste nos logs depende do marcador por linha descrito na seção 9.7, inclusive em HIT. Sem essa cobertura, expor a limitação. Não usar o horário da chamada MCP ou seu IP para reclassificar visitas.

O aceite cobre o caminho completo da ferramenta ao registro e ao relatório. Ensinar o cabeçalho na documentação, sem comprovar sua propagação nos caminhos declarados como suportados, não atende à funcionalidade.

## 10. Aceites adicionais obrigatórios

| ID | Cenário | Resultado esperado |
|---|---|---|
| S1 | Formulário válido enviado em menos de três segundos, inclusive autofill | Aceito se passar pelas demais regras; rapidez isolada não suprime aviso ou conteúdo. |
| S2 | Honeypot preenchido, token inválido e quota excedida | Cada proteção conserva seu efeito e motivo próprios. |
| S3 | Sem JavaScript, HTML em cache, formulário curto e token renovado | Idade do HTML não vira tempo de preenchimento; ausência de medição de tempo não implica suspeita. |
| S4 | Atualização com contatos antigos suspeitos por tempo | Nenhuma promoção automática nem envio retroativo. |
| T1 | Abrir /f3base-teste/ sem login ou MCP | Cookie ativado diretamente e estado confirmado; nenhum código ou credencial solicitado. |
| T2 | MCP e navegador em redes diferentes | A visita à página no navegador correto ativa a marca sem depender de IP. |
| T3 | Agente e visitante real no mesmo IP e horário | Só o cliente marcado entra como teste. |
| T4 | Script envia X-F3Base-Teste: 1 sem ativação | Requisição classificada como teste; flag não concede acesso administrativo ou privado. |
| T5 | Cookie ausente/1/outro valor; cabeçalho ausente/0/1/inválido | Contrato e precedência respeitados; valores inválidos de cabeçalho tratados conforme a validação definida. |
| T6 | Cookie bloqueado, renovação, saída e expiração | Estado fiel ao navegador; renovação de uma hora; novos eventos após saída/expiração voltam a não marcados. |
| T7 | Página pública servida por HIT | Eventos segmentados sem vazar marca a outro visitante nem desativar cache globalmente. |
| T8 | Mudança de modo entre evento e descarga da fila, abas e bfcache | Classe de coleta preservada; lotes coerentes, deduplicação e sessões separadas. |
| T9 | Clique, formulário sem sessão, funil, campanha, vital e download | Marca aplicável persistida e usada pelos relatórios relacionados. |
| T10 | Sem testes / Somente testes / Todos | Volumes conciliam; taxas, p75 e sessões recalculados; UI, CSV e ability concordam. |
| T11 | Agregados, comparação e limites de consulta | Testes separados das somas normais e da leitura limitada; cobertura histórica informada. |
| T12 | Cookie removido depois da coleta | Registros antigos mantêm a marca e continuam disponíveis. |
| T13 | Tag direta, GTM, GA4 marcado, CAPI e retentativa durante teste | Padrão suprimido; políticas por destino respeitadas; GA4 isolado de Ads; filtro Testing não apresentado como exclusão ativa; Test Events/destino de teste comprovados. |
| T14 | E-mails de contatos de teste | Supressão registrada no padrão; marcar exige destinatário configurado e identifica assunto/cabeçalho; teste real segue autorização e prova de transporte. |
| T15 | Log bruto sem marca de teste | Fonte indica indisponibilidade de segmentação; nenhum desconto por horário/IP. |
| T16 | Instalação nova e atualização 1.12.0/1.13.0 com retomada | Migração idempotente da classe; histórico não marcado; políticas, listas e destinatários preservados. |
| T17 | Documentação instalada e fluxo do agente | Atribui a responsabilidade a cada agente; ensina ativar por trabalho/site/navegador, renovar após expiração e sair; HTTP com cabeçalho em cada requisição. |
| T18 | Visitante normal sem a marca | Zero chamadas adicionais de status/MCP/API, nenhum cookie de teste criado, nenhuma nova biblioteca ou etapa de navegação. |
| T19 | Cache público antes/depois | HIT compartilhado preservado; sem Vary: Cookie ou Set-Cookie de teste em visitantes normais; sem bypass global. |
| T20 | Medição de execução e coleta | Leitura local fora de ciclos de alta frequência, sem consulta SQL extra para resolver a marca; evidência comparável de requisições/bytes/JavaScript, sem promessa de custo zero. |
| M1 | Endpoints MCP efetivos e aliases, URL direta, rest_route e instalação em subdiretório | Fora da visão de visitas/conversão; contagens técnicas e auditoria preservadas; tela, CSV e ability concordam. |
| M2 | Lista de exclusões personalizada ou explicitamente vazia; erros MCP e rota pública de nome semelhante | Atualização preserva escolhas; REST continua técnico; filtros de erro não promovem MCP a visita; páginas públicas não são excluídas por semelhança textual. |
| M3 | Ferramenta dispara teste HTTP, inclusive redirecionamento | Marca chega ao destino autorizado do site e ao registro; não se propaga a terceiros nem vaza para operações seguintes. |
| M4 | Ability recebe contexto_teste true/false/ausente/inválido, com e sem cabeçalho | Contrato, precedência e conflitos respeitados; captura interna e HTTP produzem a mesma classe; resposta informa o resultado aplicado. |
| M5 | Lead real via integração e lead de teste sem sessão de navegador | Real permanece normal na ausência de marca; teste permanece acessível e sai dos indicadores padrão; avisos e conversões seguem a regra de teste. |
| M6 | Teste enfileirado/retentado após o fim da chamada MCP; navegador separado | Fila conserva a classe original; o navegador continua dependendo da própria ativação; nenhum vínculo inferido por IP/horário. |
| M7 | Logs com/sem marcador e páginas em HIT | MCP reconhecido pela rota; testes em páginas públicas segmentados somente com evidência já disponível; limitação explícita sem pedido de mudança à hospedagem. |

## 11. Referências e alcance das seções 8 a 10

Código consultado: `class-f3base-formularios.php`, `f3base-formularios.js`, `class-f3base-relatorios.php`, `class-f3base-analise.php`, `class-f3base-modulo-comportamento.php`, `class-f3base-vitais.php`, `class-f3base-modulo-acessos-servidor.php`, `class-f3base-acessos-relatorio.php`, `class-f3base-acessos-coleta.php`, `class-f3base-admin-acessos.php` e carregador de tracking, todos da base local 1.13.0.

Para as URLs MCP, foi consultado `wp-mcp-fator3-0.12.1-relatorio.md`, seção Instalação e conexão. Não foi feita inspeção das configurações efetivas dos sites da frota. A cobertura atual descrita em 9.10 é uma leitura do código e da documentação; os aceites M1–M7 são requisitos da próxima implementação, ainda não executados.

Referências consultadas durante a preparação:

- Google Analytics — [Filter out developer traffic](https://support.google.com/analytics/answer/13296662?hl=en): separação de tráfego de debug e distinção entre exclusão no processamento e filtros de relatório.
- Google Analytics — [Data filters](https://support.google.com/analytics/answer/13296761?hl=en): distinção entre tráfego interno por IP e tráfego de desenvolvedor.
- MDN — [Using HTTP cookies](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies): envio, escopo e atributos dos cookies.
- MDN — [Document.cookie](https://developer.mozilla.org/en-US/docs/Web/API/Document/cookie): leitura/escrita local e caráter síncrono da API, considerado no requisito de evitar acessos repetidos em ciclos de alta frequência.

Esta revisão incorpora a decisão explícita do dono de simplificar a marcação e dispensa a arquitetura anterior de credenciais. A confirmação verifica que a marca funciona no cliente e no coletor; não autentica o agente. As alterações estão no plano; implementação, homologação de cache/filas/tags, propagação nas ferramentas e validação dos logs da hospedagem permanecem pendentes.

## 12. Publicidade — origem por anúncio e organização dos leads

Preparação acrescentada após o dono informar o uso atual de Meta Ads/Instagram e a intenção de usar Google Ads e LinkedIn, com diversos anúncios em cada plataforma. O requisito é identificar a origem até o anúncio e manter os registros organizados. Esta seção propõe o contrato e o escopo; não conecta contas, importa leads nem publica anúncios.

### 12.1 Lacunas observadas na 1.13.0

- `f3base-leads.js` captura UTMs, `gclid`, `gbraid`, `wbraid`, `fbclid` e `li_fat_id`; o endpoint de cliques aceita esses campos, além dos identificadores da Meta previstos em seu contrato.
- `f3base-analise.js` captura apenas cinco UTMs e o domínio de referência, com origem por sessão. O formulário usa esse contexto. Seu endpoint aceita `gclid` e `fbclid`, mas não recebe esses dois pelo fluxo normal de análise nem aceita todos os demais identificadores do clique.
- `F3Base_Analise::atribuicao()` normaliza UTMs e referência, sem preservar IDs de anúncio. A visão Campanhas agrupa por fonte, meio, campanha e conteúdo e depende de pareamento com navegação/sessão; isso deixa contatos sem esse pareamento fora da contagem atribuída.
- Há opções existentes de primeiro/último toque e janela de 30 dias por padrão. Elas não devem ser substituídas silenciosamente; hoje não representam um contrato uniforme entre os fluxos.
- Inferência a partir do código: identificar a plataforma ou adicionar parâmetros ao anúncio, isoladamente, não garante que o ID do anúncio chegue ao formulário e ao relatório. O contrato completo precisa ser unificado.

### 12.2 Modelo comum

A interface organiza **Plataforma → Conta anunciante → Campanha → Grupo/conjunto, quando existir → Anúncio**. Preservar o tipo e os IDs nativos de cada entidade: as três plataformas não têm hierarquias idênticas. Marca/site receptor e canal de atendimento são dimensões separadas.

| Dimensão | Dados a preservar e regra |
|---|---|
| Plataforma publicitária | `meta_ads`, `google_ads`, `linkedin_ads` ou não identificada; separada da superfície Instagram, Facebook, Pesquisa, YouTube etc. |
| Conta e entidades | IDs nativos como strings, incluindo conta, campanha, conjunto/grupo, anúncio e criativo quando disponibilizado. Manter tipo de entidade e versão do mapeamento; nunca converter IDs longos em números JavaScript. |
| Identidade do anúncio | Chave contextual: site/organização receptora + plataforma + conta + escopo nativo necessário (campanha/grupo) + anúncio. Nomes iguais não fundem anúncios; renomear não cria outro anúncio. |
| Rótulos e material | Nome da campanha/anúncio no momento da captura, rótulo atual quando houver catálogo, formato e identificador editorial opcional da peça. O mesmo vídeo em dois anúncios continua representando dois anúncios. |
| Parâmetros de campanha | UTMs existentes, `utm_id`, `utm_source_platform` e campos próprios apenas onde não há portador padrão; mapeamento versionado conforme 12.3. |
| Identificadores de clique | Preservar os identificadores disponíveis de cada fornecedor, sem substituir um tipo por outro nem tratá-los como ID do anúncio. Guardar somente conforme a política aplicável à coleta. |
| Local da captura | No Core desta release, site e transporte observado. As receitas externas distinguem formulário nativo da plataforma e mensageria. Essa dimensão não substitui o método de contato existente nem implica importação local. |
| Registro externo | Documentar chaves para cruzamento por agentes: plataforma, conta e ID original. Ingresso, schema específico e deduplicação de leads nativos no Core ficam reservados para outra release. |
| Atribuição | Origem observada da sessão, primeiro contato de marketing e último contato de marketing identificável dentro da janela permitida; snapshot usado ao capturar o lead e modelo que recebeu o crédito. |
| Cobertura e teste | Origem da evidência (parâmetro recebido, API da plataforma ou informação manual), campos ausentes, início da cobertura, classe de teste e eventual sinal de teste nativo da plataforma. |

Campos sem evidência permanecem vazios/não identificados. UTMs recebidas em uma URL são informação declarada; não constituem confirmação autenticada da plataforma. Referer ou identificador isolado não basta para inventar campanha, anúncio, superfície ou venda atribuída.

A padronização não exige um formulário do site diferente para cada anúncio. O mesmo formulário recebe a atribuição da navegação e a grava no contato.

### 12.3 Como o ID do anúncio chega ao contato

**Anúncio com destino ao site**

Configurar parâmetros dinâmicos na plataforma para entregar IDs de campanha, conjunto/grupo e anúncio. Usar UTMs legíveis como apoio. Os IDs permanecem como chave dos agrupamentos.

| Plataforma | Configuração a documentar |
|---|---|
| Meta Ads | Parâmetros dinâmicos de campanha, conjunto e anúncio (`campaign.id`, `adset.id`, `ad.id`); usar `site_source_name` para distinguir a superfície quando informado. Normalizar `ig`/Instagram e `fb`/Facebook sem classificar toda a conta Meta como Instagram. |
| Google Ads | Auto-tagging e preservação dos identificadores de clique; ValueTrack `{campaignid}`, `{adgroupid}` e `{creative}` nos formatos que os suportam. Em Performance Max, respeitar a granularidade disponível, inclusive grupo de recursos, sem prometer identificação da combinação exata de imagens/títulos exibida. |
| LinkedIn Ads | Selecionar os parâmetros dinâmicos oferecidos no Campaign Manager: `ACCOUNT_ID`, `CAMPAIGN_ID`, `AD_SET_ID` e `AD_ID` na nomenclatura nova. Mapear as entidades da API pela semântica documentada, pois os nomes da interface e das APIs não são intercambiáveis automaticamente. |

**Contrato único de URL desta release:**

| Informação | Portador | Regra |
|---|---|---|
| Versão do molde | `f3_ads_v=1` | Identifica a interpretação de IDs nos campos manuais; versões desconhecidas são diagnosticadas. |
| Plataforma | `utm_source_platform` | Valores normalizados meta_ads, google_ads e linkedin_ads nos moldes do Core. |
| Origem/superfície | `utm_source` | Ex.: macro site_source_name da Meta; conservar origem declarada e normalização. |
| Campanha | `utm_id` | ID; utm_campaign continua rótulo legível. Não duplicar em f3_ads_campaign_id. |
| Anúncio | `utm_content` | ID do anúncio no molde v1. Campanha antiga sem molde conserva conteúdo literal; não reinterpretar automaticamente um nome como ID. |
| Palavra-chave | `utm_term` | Preservar significado de termo; não ocupar o campo globalmente com ID de conjunto. |
| Conta | `f3_ads_account_id` | ID explícito ou macro comprovadamente disponível. |
| Conjunto/grupo | `f3_ads_group_id` e `f3_ads_group_type` | Identidade/tipo próprios para não conflitar com palavra-chave e hierarquia de cada plataforma. |
| Posicionamento | `f3_ads_placement` | Opcional, somente quando informado com evidência. |

UTMs são reconhecidas pelo GA4 como dimensões manuais, mas um ID em utm_content/utm_id não vira automaticamente a dimensão nativa de anúncio/campanha de uma integração publicitária. Documentar o pareamento e a precedência da auto-tagging. O dado customizado pode ser enviado ao GA4 como parâmetro próprio, com dimensão registrada quando necessária; não prometer relatório pronto sem a configuração da propriedade.

Modelo Meta a documentar: `utm_source={{site_source_name}}&utm_medium=paid_social&utm_source_platform=meta_ads&utm_id={{campaign.id}}&utm_campaign={{campaign.name}}&utm_content={{ad.id}}&f3_ads_group_id={{adset.id}}&f3_ads_group_type=adset&f3_ads_account_id=ID_DA_CONTA&f3_ads_v=1`. Codificar valores e validar expansão na plataforma. Para Google, manter utm_term disponível a {keyword} e usar campos próprios para {adgroupid}; criativos/grupos só quando o formato os fornece. Não bloquear contato legítimo por atribuição incompleta.

O guia instalado terá modelos específicos por plataforma, valores de exemplo fictícios e instruções de teste do resultado expandido. IDs de conta sem macro suportada são configurados explicitamente; não inventar macros. Parâmetros que chegarem com chaves de macro literais são diagnosticados como não expandidos.

Reutilizar a captura existente, preservar parâmetros nos redirecionamentos e carregar a atribuição entre páginas somente enquanto permitido. Usar um contrato comum em clique, formulário, análise, filas, persistência e consulta. Não colocar dados pessoais na URL, não armazenar a query completa nem carregar SDK extra só para ler parâmetros.

Preservar separadamente a origem da sessão e os snapshots de marketing. Retorno direto não apaga o snapshot de marketing anterior, mas continua registrado como sessão direta/sem referência observada. O crédito exibido identifica modelo e janela; não mudar retroativamente o histórico sem dados. Respeitar consentimento, revogação, expiração e configurações já gravadas. Modelos futuros não devem ser apresentados como modelos já disponíveis na 1.13.0.

**Formulário preenchido dentro da plataforma**

Esses leads podem existir sem visita ao WordPress. UTMs não capturam esse envio. **Fora desta release:** endpoint/importador de leads nativos, adaptadores e sincronização automática. O guia para agentes explica como analisar a fonte externa com suas próprias chaves, sem apresentar o registro como capturado pelo Core e sem inventar sessão/IP/página. Uma integração futura deverá preservar origem, deduplicar por ID externo e separar submissões distintas da mesma pessoa; isso não é requisito de código ou gate desta entrega.

**Anúncio que abre Direct ou WhatsApp**

O Core só observa ações que chegam aos seus coletores. Um clique para mensageria deve permanecer indicador de intenção. Conversa/lead confirmado exige uma fonte externa, fora da captura desta release. Nas receitas de cruzamento, usar o contexto de anúncio fornecido por essa fonte; sem ele, manter atribuição desconhecida. Não estimar o anúncio por horário, texto genérico da conversa ou IP.

### 12.4 Relatórios e operação

- Criar detalhamento de campanhas até **Anúncios**, com filtros por site/marca, plataforma, conta, campanha, conjunto/grupo, anúncio, superfície, local de captura, período e classe de tráfego. Exibir nome e ID; nomes ausentes não impedem agrupamento por ID.
- No detalhe do contato, mostrar “Meta Ads → Instagram → Campanha X → Conjunto Y → Anúncio Z”, conforme os campos disponíveis, junto da evidência e do modelo usado. Sem IDs, exibir a cobertura parcial e não agrupar por nomes como se fossem identidade confirmada.
- Contar contatos do site atribuídos ao anúncio mesmo sem sessão de navegação quando há metadados válidos da captura. Separar esses volumes da taxa de conversão do site, cujo denominador são sessões observadas e elegíveis. Nas receitas de cruzamento externo, formulários nativos também ficam separados dessa taxa.
- Manter cliques de CTA, envios aceitos, suspeitos, spam e respondidos como indicadores distintos. O estado atual de atendimento não equivale a qualificação ou venda; novos estágios comerciais exigem escopo próprio.
- Documentar o cálculo externo de custo por lead somente com investimento por plataforma/conta/anúncio, período e moeda compatíveis. A tela local não ganha sincronização ou painéis de custo nesta release. Receita/ROAS também exigem dados comerciais; não deduzir pelo número de formulários.
- Preservar primeiro e último contato observados, sem duplicar o crédito integral do mesmo lead na soma de um único modelo. Mostrar modelo e janela em tela, CSV e ability; comparações de períodos usam a mesma regra e indicam cobertura.
- A atribuição local descreve os contatos observados e a regra de crédito. Não prova efeito causal do anúncio nem deve ser prometida como idêntica ao total atribuído pelas plataformas.
- A ausência de cookies, bloqueadores, troca de dispositivo ou parâmetros perdidos limita cobertura. Classificar como não identificado quando não houver evidência; não iniciar rastreamento entre os sites da frota por essa mudança.
- Testes locais do navegador/ferramenta entram na classe `teste`, fora dos relatórios padrão. Nas receitas externas, o agente usa os sinais de teste comprovados pela própria fonte. O cookie do navegador do agente não classifica os leads lidos na plataforma.

### 12.5 Escopo fechado e dependências externas

**Core:** contrato único de atribuição, dados de anúncio preservados até o contato, snapshots e indicadores de cobertura, relatório por anúncio e documentação operacional dos parâmetros. Índices e filtros devem atuar antes dos limites das consultas; listas/configurações atuais e histórico existente são preservados.

**Leads nativos e mensagens fora do site:** somente limites e receitas de consulta externa documentados nesta release, sem importador ou integração. Se um anúncio ativo tiver esse destino, identificar sua exclusão do alcance do Core; o operador não deve esperar que ele apareça na lista local de Contatos.

**Integrações adicionais:** sincronização de plataformas, importação de custos, conversões de qualificação/venda e CRM ficam fora desta entrega. O contrato de dados permite cruzamentos autorizados feitos pelos agentes sem espelhar tudo no WordPress.

**WP Super Cache:** ampliar a lista requerida com utm_id, utm_source_platform, gbraid, wbraid, li_fat_id e todos os f3_ads_* efetivamente definidos no molde v1. Acrescentar as rotas de ativação/saída de teste às exclusões; preservar entradas próprias e a recusa de ref. O requisito declara o delta, mas não edita wp-cache-config.php silenciosamente. A rotina da frota aplica o delta com hash/revisão, valida sintaxe e confere a configuração carregada. Excluir parâmetros da chave de cache só é correto se não alterarem o conteúdo da resposta; conferir que a atribuição é capturada no cliente sem imprimir IDs de uma visita no HTML compartilhado.

**Homologação publicitária:** Meta tem destino ativo informado; Google/LinkedIn usam fixtures e ambiente de teste enquanto não houver campanha elegível. Provar dois anúncios/IDs, expansão de macros, HIT e persistência até formulário. Alterar anúncio ativo é operação separada, autorizada e identificada; não é condição para implementar o contrato ou executar os aceites controlados. A nota de release distingue integração homologada com serviço real de contrato testado em bancada.

**Análise pelos agentes:** agentes com acesso autorizado ao banco do site e aos serviços publicitários podem cruzar os dados diretamente, sem exigir que o Core replique todos os dados externos ou ofereça uma tela para cada análise. A seção 14 documenta esse uso. Para um lead nativo aparecer na lista local de Contatos, ele precisa ser recebido/importado; para integrar um relatório externo do agente, pode ser lido na própria plataforma, com procedência e deduplicação explícitas. O relatório não deve apresentar um lead externo como registro já existente no WordPress.

### 12.6 Aceites de atribuição

| ID | Cenário | Resultado esperado |
|---|---|---|
| P1 | Dois anúncios da mesma campanha levam ao mesmo formulário | Cada lead conserva o ID correto; linhas separadas por anúncio em tela, CSV e ability. |
| P2 | Anúncios com mesmo nome, anúncio renomeado e IDs maiores que a precisão numérica do JavaScript | Sem fusão por nome, sem quebra de identidade por renomeação e sem perda de dígitos; contas/plataformas isoladas. |
| P3 | Clique, formulário e análise; parâmetros dinâmicos expandidos e ausentes | Contrato comum preserva UTMs/IDs suportados; lacunas e macros literais são identificadas; contato legítimo não é perdido. |
| P4 | Redirecionamento, cache HIT, navegação interna, volta direta, revogação e expiração | Atribuição persiste somente quando permitida; snapshot do lead e contexto de teste preservados; cache público continua compartilhado. |
| P5 | Guia de cruzamento com lead nativo sem visita ao site | Identifica fonte externa, chaves e limites; não anuncia captura local nem aumenta o denominador de sessões do site. |
| P6 | Fonte externa e dados locais usados pelo agente | Receita distingue chaves e reentregas sem inventar importador; testes/importações antigas não são reclassificados por inferência. |
| P7 | Conta Meta entrega em Instagram e Facebook; LinkedIn com entidades renomeadas; formato Google com granularidade limitada | Superfície e hierarquia fiéis à evidência; anúncio/conjunto não são inferidos de um campo com semântica diferente. |
| P8 | Mesma janela de relatório com testes, custos ausentes e origem parcial | Testes excluídos por padrão; sem custo/ROAS inventado; números e cobertura conciliam sob o mesmo modelo. |
| P9 | Pacote, catálogo e documentação finais | Nenhum endpoint/importador/CRM nativo não implementado é anunciado como disponível; o escopo externo está explícito. |

### 12.7 Referências e limites da pesquisa

Documentação oficial consultada em 24/09/2026:

- Meta — [Parâmetros dinâmicos de URL](https://www.facebook.com/business/help/2360940870872492). A abertura integral exigiu login; os parâmetros citados foram conferidos nos trechos indexados do domínio oficial. Conferir a expansão no anúncio antes da homologação.
- Meta — [Recuperação de leads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/lead-ads/retrieving) e [Webhooks de leads](https://developers.facebook.com/docs/graph-api/webhooks/getting-started/webhooks-for-leadgen/). A consulta recuperou trechos oficiais; o contrato completo do conector deve ser validado na implementação.
- Google — [Auto-tagging](https://support.google.com/google-ads/answer/3095550), [ValueTrack](https://support.google.com/google-ads/answer/6305348) e [Webhook de formulários](https://developers.google.com/google-ads/webhook/docs/implementation).
- LinkedIn — [Parâmetros de URL](https://www.linkedin.com/help/lms/answer/a5968064), [Mudanças na hierarquia](https://www.linkedin.com/help/lms/answer/a8323033), [Lead Sync](https://learn.microsoft.com/en-us/linkedin/marketing/lead-sync/leadsync?view=li-lms-2026-05) e [Click IDs](https://learn.microsoft.com/en-us/linkedin/marketing/conversions/enabling-first-party-cookies?view=li-lms-2026-05).

O código foi inspecionado localmente. Não houve consulta às contas de anúncios, coleta de dados pessoais de leads, alteração de campanhas ou implementação dessas mudanças.

## 13. Medição — navegação e usabilidade

### 13.1 Organização

Manter **Medição** como ponto de entrada dos indicadores e centralizar nela a navegação dos relatórios. **Contatos** concentra lista, detalhe, jornada, atendimento, formulários e conteúdo privado conforme a seção 15; seu acesso a Relatórios abre a área correspondente de Medição. As configurações de coleta permanecem em **Configurações → Medição e anúncios**, com link contextual. Reorganizar a navegação não concede permissões novas: manter as capabilities aplicáveis a relatório, contato e operação.

| Área | Pergunta principal | Conteúdo inicial e detalhamento |
|---|---|---|
| **Visão geral** | O que aconteceu no período? | Até cinco indicadores principais: sessões observadas, cliques de contato, envios aceitos, taxa de envio do site e contatos aguardando resposta. Uma tendência selecionável e links para aprofundar. Exibir cobertura; não somar requisições de servidor como visitantes. |
| **Aquisição** | De onde vieram os contatos? | Origens e campanhas dos contatos do site; abrir campanha, conjunto/grupo e anúncio. Filtros de plataforma, conta e superfície; nomes e IDs. Explicar a ausência de captura nativa/mensageria e oferecer o guia de cruzamentos externos. |
| **Conversão** | Onde o contato foi gerado ou interrompido? | Visões selecionáveis de páginas, formulários/funil, métodos, materiais e perfil de demanda. Link para os contatos correspondentes e atendimento. |
| **Comportamento** | Como ocorreu a navegação observada? | Visões selecionáveis de páginas/seções, tempo ativo, profundidade, saídas e acionamentos por sessão. Tabela detalhada de eventos sob demanda. |
| **Técnico** | Os dados e a experiência estão funcionando? | Visões selecionáveis de vitais, erros/fricção, acessos do servidor e estado da coleta. Diagnósticos e ações operacionais pertinentes. |

Usar um nível principal com essas cinco áreas. Dentro de uma área, escolher a análise por seletor ou lista contextual curta, exibindo uma análise por vez. Não empilhar todas as tabelas abaixo da navegação nem introduzir sucessivas barras de abas. A tabela acima também serve como inventário para mapear cada visão existente e evitar perda de funcionalidades.

A Visão geral abre por padrão. Dados externos sem integração ficam indisponíveis com explicação; não reservar grandes quadros vazios para futuras integrações. Nenhuma área depende de cadastrar todas as plataformas para funcionar. O indicador de pendências é um estoque no instante da consulta e deve indicar essa referência temporal; não compará-lo com um estoque passado sem histórico que sustente a comparação.

### 13.2 Filtros, navegação e leitura

- Cabeçalho comum com período, comparação e segmento de tráfego. **Sem testes** é o padrão definido na seção 9. Mostrar filtros aplicados, fuso e horário da atualização. Filtros de plataforma, conta, formulário e demais dimensões aparecem somente quando pertinentes.
- URL com área, visão e filtros validados, permitindo favoritos, voltar/avançar e acesso direto. Manter período/segmento ao navegar; não aplicar silenciosamente um filtro incompatível. Quando uma fonte não suporta o segmento, mostrar a limitação e seu total bruto separado.
- Abrir detalhes ao selecionar uma linha: campanha → anúncio → contatos, ou formulário → etapas → registros. Exibir caminho de navegação e retorno ao mesmo recorte/página da lista.
- Área ativa e análise selecionada devem ser as únicas consultadas/renderizadas, exceto as consultas limitadas do resumo. Tabelas ocultas por CSS não atendem ao requisito. Paginação e ordenação têm comportamento explícito.
- Uma ação **Atualizar relatório** por visão, preservando filtros. **Coletar logs** e outras operações ficam em Técnico com descrição própria; atualizar a consulta não deve parecer reprocessar/importar todo o histórico.
- Manter Atualizar e Exportar próximos ao resultado. A exportação informa recorte, segmento e se inclui todas as linhas filtradas ou somente a página; corte/limite não pode parecer resultado completo.
- Colunas iniciais essenciais; detalhes de IDs, evidência, fórmula e qualidade disponíveis ao expandir ou abrir o registro. Em Aquisição, nome e ID do anúncio continuam localizáveis sem depender de nomes exclusivos.
- Mostrar estado vazio com causa: nenhum dado no período, coleta desligada, histórico expirado, fonte sem integração, sem permissão ou consulta incompleta. Não substituir indisponibilidade por zero.
- Ajuda curta ao lado da métrica, com **Como é calculado** apontando à definição instalada. Não colocar documentação técnica extensa no fluxo principal.
- Usar links reais para navegação, indicação da página atual, rótulos consistentes e foco visível. Navegação/consulta devem funcionar por teclado e sem JavaScript; carregamento assíncrono pode melhorar a experiência sem ser requisito. Em tela estreita, manter a ordem e o acesso às cinco áreas.
- Estado de coleta crítico aparece resumido em qualquer área afetada, com link para Técnico. Seu diagnóstico completo não se repete em todos os relatórios.

O painel apresenta as consultas recorrentes e seus detalhamentos. A criação de relatórios arbitrários pelos agentes é atendida pelo contrato de dados da seção 14; não exige construir um editor de BI no WordPress.

### 13.3 Aceites de usabilidade

| ID | Cenário | Resultado esperado |
|---|---|---|
| U1 | Inventário das visões atuais e novas | Cada visão tem destino definido; Contatos encaminha para a mesma consulta analítica de Medição, sem cálculos duplicados. |
| U2 | Abrir Visão geral e cada área | Resumo limitado e uma análise por vez; ausência de consultas/HTML de tabelas de áreas inativas. |
| U3 | Aplicar período/segmento, abrir anúncio e voltar | Recorte e página de origem preservados; filtros incompatíveis e fontes sem segmentação identificados. |
| U4 | Navegação direta, teclado, tela estreita e JavaScript desligado | Áreas, filtros, paginação e exportação utilizáveis; estado ativo e foco identificáveis. |
| U5 | Coleta desativada, vazia, expirada ou incompleta | Mensagem específica e cobertura; nenhum zero enganoso nem impedimento a fontes independentes. |
| U6 | Indicador, tabela, CSV e ability sob o mesmo recorte | Valores e definições conciliam; horário, fuso, segmento e limites visíveis. |
| U7 | Atualizar relatório versus coletar logs | Ações distintas e resultados verificáveis; atualização da interface não dispara operação diferente da solicitada. |

Homologar os fluxos em navegador real com dados pequenos e volumosos, incluindo encontrar um anúncio, seus contatos e retornar ao recorte anterior. Registrar evidências de navegação e consultas executadas; não limitar a verificação à existência dos títulos das áreas.

## 14. Documentação integrada para análise por agentes

### 14.1 Objetivo e ponto de entrada

O agente deve conseguir partir apenas do plugin instalado, identificar a versão e entender o que cada dado representa, como consultá-lo e como cruzá-lo com serviços aos quais já possui acesso. Leituras diretas do banco são um caminho documentado, além das abilities de relatórios. A interface administrativa não delimita as análises possíveis.

A base 1.13.0 já distribui `DOCUMENTACAO.md`, `INSTRUCOES-DO-PLUGIN.md`, `CONTRACTS.md` e `docs/RELATORIOS.md`. A ability `f3base/documentacao-ler` fornece índice, versão, leitura paginada e SHA-256, mediante a permissão existente. Ampliar essa mesma entrada para os novos arquivos, incluindo JSON e SQL como conteúdo inerte; não criar outro índice concorrente.

**Distribuição final da seção 17.3:** manter documentos Markdown/JSON/SQL em `docs/`, protegidos por `docs/.htaccess` distribuído e reposto pelo próprio ZIP no ambiente Apache homologado. Mover os documentos da raiz e atualizar índice/mapa da ability com aliases lógicos. `index.php` sem saída em cada diretório não substitui a proteção dos arquivos. Não usar invólucros PHP nesta release; a proteção é parte do pacote, não remendo manual.

Fluxo documentado ao agente: identificar site/versão/schema → ler índice e contrato de dados → escolher consulta pronta ou leitura direta → obter fontes externas autorizadas quando necessário → alinhar unidades, períodos e chaves → produzir relatório com cobertura e critérios declarados. Consultar o banco ou o MCP não exige ativar o cookie de navegação; testes que geram eventos/contatos seguem a seção 9.

### 14.2 Entregáveis dentro do instalador

| Documento lógico instalado, com proteção conforme 17.3 | Conteúdo obrigatório |
|---|---|
| `DOCUMENTACAO.md` e `INSTRUCOES-DO-PLUGIN.md` | Índice completo, roteiro de análise e referências às versões. Acesso por arquivo e canal; diferença entre dado existente e recurso futuro. |
| `docs/DICIONARIO-DADOS.md` | Tabelas, colunas e campos JSON: tipo, unidade, significado, valores permitidos, origem, nulabilidade, chaves/índices, granularidade, retenção e versão de introdução. |
| `docs/dados/contrato.json` | Representação legível por máquina: versão do plugin/contrato/schema, tabelas lógicas, campos, enums, relações/cardinalidades, unidades temporais e referências às métricas. Não contém dados ou credenciais do site. |
| `docs/METRICAS.md` | Identificador estável de cada indicador, definição, fontes, filtros, deduplicação, numerador/denominador, dimensões, unidade, tratamento de ausência e compatibilidade de agregação. |
| `docs/CONSULTAS-EXEMPLO.sql` | Consultas SELECT parametrizadas e verificadas, com prefixo/site resolvidos no ambiente, período limitado e resultado esperado descrito. Exemplos de leads por anúncio, funil, cobertura e atendimento. |
| `docs/CRUZAMENTOS-PUBLICIDADE.md` | Mapeamento de IDs com Meta/Google/LinkedIn, granularidade, contas/sites, horários, moedas, deduplicação e receitas de cruzamento de investimento, anúncios e contatos. |
| `docs/RELATORIOS.md` e `CONTRACTS.md` | Navegação vigente, acesso por abilities, filtros/paginação/erros, limites, exemplos de entrada/saída e referências às definições comuns. |

Gerar o inventário estrutural a partir do schema e contratos efetivos da release; manter explicações semânticas revisadas e fórmulas verificadas contra os cálculos. Não gerar explicações apenas repetindo nomes de colunas. O empacotamento deve falhar se faltar documento catalogado ou se ele declarar campo, enum ou métrica implementada que não exista na versão entregue.

### 14.3 Granularidade e relacionamentos

O dicionário deve incluir ao menos as fontes abaixo, além das tabelas auxiliares efetivamente necessárias à release. Nomes abaixo são lógicos; o prefixo WordPress não pode ser fixado como `wp_`.

| Fonte atual | O que representa / cuidado para cruzar |
|---|---|
| `f3base_leads` | Um registro de contato ou intenção conforme método/captura. `record_id` identifica o registro; sessão e correlação são vínculos opcionais. |
| `f3base_eventos` | Eventos detalhados de sessão, com qualidade da âncora temporal; não são pessoas únicas nem novos leads. |
| `f3base_analise` | Eventos adicionais com navegação, instância/revisão de formulário e sequência; documentar sobreposição com eventos de página e vitais. |
| `f3base_comportamento` | Agregados por dimensões, regra e período; não reconstituem uma sessão nem devem ser somados aos eventos como ocorrências adicionais. |
| `f3base_vitais` | Amostra atualizável de métrica. Não possui vínculo de sessão nessa tabela da 1.13.0; cruzamentos com conversão usam somente a fonte vinculável declarada. |
| `f3base_acessos` | Contagens técnicas de requisições por dimensões do parser; não equivalem a usuários ou sessões de navegação. |
| `f3base_atendimento_historico` e concessões | Alterações por lead/revisão e acessos concedidos por lead/material. Pré-agregar cada relação de múltiplas linhas antes de juntar volumes comerciais. |

Documentar cardinalidade e condições das junções: cada lead tem no máximo uma sessão registrada, enquanto uma sessão pode ter vários leads e vários eventos; juntar leads e eventos apenas pela sessão multiplica as linhas, exigindo deduplicação ou pré-agregação conforme a métrica. Formulário exige revisão/instância quando aplicável; `correlacao` não é uma chave universal entre plataformas; `record_id` e IDs externos conservam seu escopo de origem. Não deduzir relacionamentos por proximidade de IP/horário ou supor que cookies de sites diferentes representem a mesma pessoa.

Explicitar campos em colunas e caminhos dentro de JSON, inclusive os novos IDs publicitários e `classe_trafego`. Diferenciar ausência histórica, campo não aplicável, dado indisponível e valor zero. O contrato instalado deve descrever somente o schema presente; não publicar o schema proposto desta preparação como se já estivesse na 1.13.0.

### 14.4 Definições reproduzíveis

Cada métrica deve informar quem entra e sai: testes, captura suspeita, spam, lixeira, eliminação pendente e registros sem vínculo. A regra pode variar por indicador, mas precisa estar nomeada; “leads”, “cliques de contato”, “envios aceitos” e “sessões convertidas” não podem ser sinônimos.

Documentar datas UTC/local, epoch em segundos ou milissegundos, datas de agregação, início inclusivo/fim exclusivo, relógio do cliente versus recebimento, atualização e atraso das fontes. Indicar janela de atribuição separadamente do período consultado e do prazo de retenção.

Taxas e percentis devem ser recalculados a partir dos insumos compatíveis. Não somar contagens de sessões distintas entre dimensões sobrepostas, não tirar média simples de percentuais com denominadores diferentes, nem combinar percentis diários como se fossem o percentil do período. Informar se a base permite cada cálculo.

O resumo de toda consulta fornecida pelo Core deve tornar verificáveis: versão da regra, recorte, fuso, segmento, filtros, origem, cobertura, momento da leitura, limites e eventual incompletude. Para relatórios próprios, recomendar que o agente acompanhe o resultado com os mesmos metadados. Reproduzir um indicador do painel exige a mesma regra; uma regra diferente é uma análise personalizada e deve ser identificada.

### 14.5 Cruzamento com Meta, Google e LinkedIn

- Identificar plataforma, conta anunciante e site/marca receptora antes de cruzar IDs. IDs são strings; nomes servem à leitura e podem mudar. Respeitar os escopos e tipos nativos documentados na seção 12.
- Para custo por anúncio, agregar os contatos localmente por conta/anúncio/período e obter gastos externos na mesma granularidade; só então unir os conjuntos. Juntar uma linha de gasto a cada lead e depois somar multiplica artificialmente o investimento.
- Conservar anúncios com gasto e nenhum lead, e leads cujo anúncio/custo não foi localizado. Expor a parcela não pareada; ausência de gasto conhecido não significa investimento zero.
- Registrar moeda, unidade monetária do campo, fuso da conta e período de atribuição. Se os cortes de dia não coincidirem e a fonte não oferecer detalhe para alinhá-los, declarar a diferença e usar um recorte compatível; não simular uma conversão exata de dados diários.
- Separar conversões declaradas pela plataforma dos envios observados no Core. Não somá-las para obter “total de leads”. Nas fontes externas já integradas entre si, usar a chave de origem para evitar duplicação; sem uma chave confiável, apresentar os conjuntos e a limitação separadamente. Esta release não importa leads nativos para o Core.
- Documentar atraso, atualização/revisão dos dados externos, exclusões de teste disponíveis e condições de uso de cada métrica. Relatórios próprios não devem prometer números idênticos aos painéis publicitários se modelos e janelas diferirem.
- Custos, formulários nativos e metadados de anúncios podem continuar nos serviços externos. O agente os consulta conforme seus acessos; a análise não exige espelhar tudo no banco WordPress. Um snapshot externo usado no cruzamento deve ter fonte, versão do contrato, consulta, horário e granularidade identificáveis.
- Manter catálogo de campos/API e referências oficiais por versão suportada. A mudança de nomenclatura do LinkedIn exige mapeamento semântico; copiar o rótulo “campaign” entre contratos não basta.
- Para análise direta, os exemplos usam SELECT e projeções necessárias. Alterações de estado/dados continuam seguindo as regras das operações correspondentes; não transformar a documentação em um endpoint genérico de execução SQL nem conceder novas permissões. Exemplos de relatórios usam dados fictícios e não expõem contatos ou segredos.

Receitas mínimas: custo por lead de site por anúncio; volume de leads nativos versus site sem duplicação; cobertura de atribuição; primeiro/último contato de marketing conforme modelo; tempo até primeira resposta. Cada receita declara entradas locais/externas, chaves, granularidade, fórmula, casos sem pareamento e limites. Indicadores comerciais que exigem dados ainda inexistentes são identificados como dependentes de fonte adicional.

### 14.6 Aceites de documentação e autonomia dos agentes

| ID | Cenário | Resultado esperado |
|---|---|---|
| DOC1 | Instalar o ZIP e ler apenas o plugin instalado | Índice, dicionário, métricas, SQL e JSON completos; nenhum recurso exige acesso ao repositório de desenvolvimento ou a este plano. |
| DOC2 | Ler por arquivo e por documentacao-ler, inclusive além de 200 linhas | Mesma versão/conteúdo, paginação íntegra e hash; catálogo inclui todos os documentos previstos, sem liberar caminhos arbitrários. |
| DOC3 | Schema e contratos efetivos comparados com a documentação | Colunas, campos JSON, tipos, enums, unidades, chaves e cardinalidades conferem; propostas não implementadas não aparecem como disponíveis. |
| DOC4 | Reproduzir por SQL um indicador do painel/ability | Resultado idêntico na mesma base/recorte/regra, incluindo teste, spam, lixeira, ausência de sessão e expiração. |
| DOC5 | Cruzar múltiplos eventos e contatos com gasto por anúncio | Nenhuma multiplicação do investimento ou do volume de leads; anúncios sem leads e leads sem custo permanecem identificados. |
| DOC6 | Receita do agente reúne dados locais e fonte externa | Chaves e fronteiras distinguem as fontes; nenhum lead externo aparece como importado pelo Core sem estar no banco; ausência de pareamento é explícita. |
| DOC7 | Prefixo diferente de wp_, contas distintas, IDs longos, fuso/moeda/unidade divergentes | Consulta preserva escopo e precisão; incompatibilidades são tratadas ou declaradas. |
| DOC8 | Navegação ponta a ponta e dados externos fictícios para receita | Captura local, persistência e relatório concordam; receita externa não exige importador nem apresenta dados fictícios como reais. |

Validar receitas na versão de banco suportada para produção; identificar separadamente resultados de laboratório SQLite. As verificações são específicas de semântica, integridade de pacote e risco de agregação, sem criar uma suíte genérica para cada parágrafo.

### 14.7 Evidência desta preparação

Foram lidos os renderizadores de Medição/Acessos, o leitor de documentação, o índice e as instruções instaladas, o guia de relatórios e as definições locais das fontes principais da 1.13.0. A recomendação de centralizar a navegação decorre da renderização sequencial observada e da distribuição atual dos relatórios. Ainda não houve inspeção visual de uma implementação nova.

A organização de links, rótulos e estado atual segue a referência [W3C WAI — Menu Structure](https://www.w3.org/WAI/tutorials/menus/structure/). As escolhas das cinco áreas e do contrato documental são decisões específicas para este produto.

Esta atualização altera o plano. Reorganização da interface, geração dos novos documentos, verificação das consultas e instalação da release ainda serão executadas.

## 15. Leads e formulários — centralização e usabilidade

### 15.1 Decisão de navegação e evidência

Por solicitação do dono, **F3 Base não deve apresentar Leads (contingência)**. O tratamento dos registros e a gestão de formulários devem ficar no menu específico já existente, **Contatos**.

O código local da 1.13.0 registra Contatos (`f3base-leads`), Formulários (`f3base-formularios`) e Conteúdo privado (`f3base-conteudos`). F3 Base registra Configurações. A busca no pacote não encontrou `register_post_type` nem o registro de Leads (contingência), mas encontrou constantes e comentários remanescentes. Isso não invalida a observação no site: a origem concreta do item exibido ainda precisa ser verificada no ambiente correspondente. Não atribuir o submenu a uma versão, plugin ou código adicional sem essa evidência.

| Local | Destino e função |
|---|---|
| **F3 Base → Configurações** | Configuração geral do plugin; mantém Informações técnicas e Operação nas áreas já previstas. |
| **Contatos → Leads** | Caixa de entrada, filtros, detalhe, jornada, atendimento, spam, testes e lixeira. É o destino inicial do menu Contatos. |
| **Contatos → Formulários** | Listagem, criação, edição, ativação, prévia e localização dos usos de cada formulário. |
| **Contatos → Conteúdo privado** | Materiais vinculados aos formulários, arquivos e estado de disponibilidade. |
| **Contatos → Relatórios** | Atalho para a análise correspondente em Medição, preservando o recorte aplicável. Não manter outra implementação dos mesmos relatórios. |

Parâmetros globais de contato/WhatsApp permanecem no ponto único de Configurações definido na seção 3. As telas de Contatos oferecem link direto para esses padrões e mostram o valor efetivo herdado. Regras específicas do formulário são editadas no próprio formulário. Não criar cópias de opções, caixas de entrada concorrentes ou mais de uma tela para a mesma definição.

A remoção da entrada de contingência é uma mudança de navegação. Nenhum registro, anexo, formulário, configuração ou concessão é apagado por ela. Não reintroduzir importadores nem escrita no CPT antigo; a base suportada continua sendo 1.12.0 ou posterior.

Na homologação, inventariar menus e callbacks do ambiente que apresenta o item, identificar seu responsável e remover o registro indevido no componente correspondente. No pacote, limpar referências históricas sem uso após conferir dependências. Não esconder apenas por CSS nem remover menus de terceiros indiscriminadamente. Não criar um fluxo permanente de compatibilidade anterior à base suportada para tratar o item.

### 15.2 Caixa de entrada de leads

**Entrada e filtros**

- Listagem com registros mais recentes primeiro, ordenação estável por data e ID, paginação e retorno ao recorte de origem. Ajustar consulta/cursor ao sentido da ordenação; mudança de filtros invalida o cursor anterior.
- Busca por nome/e-mail com rótulo claro. Estados de captura, atendimento e método usam seletores com os valores reais do contrato; formulários usam nome + ID. Datas usam controles próprios e fuso do site explícito.
- Oferecer atalhos de consulta para Todos, A responder, Suspeitos, Spam e Lixeira. São filtros sobre as dimensões existentes, sem criar novos estados comerciais.
- A classificação **Sem testes / Somente testes / Todos** é uma dimensão independente, com Sem testes por padrão e contagem/indicação do que foi excluído. Não confundir teste, suspeita de spam, método e estado de atendimento.
- Origem publicitária é filtro contextual conforme a seção 12: plataforma, campanha e anúncio identificados. Não exigir plataforma configurada para ler contatos sem atribuição.
- Exibir filtros aplicados, ação Limpar filtros e total coerente com o recorte. Falha de consulta e ausência de registros têm mensagens distintas; lista vazia não comprova que não existem leads.
- Manter filtros e posição ao abrir um registro, executar ação e retornar. O caminho vindo de Formulários abre os contatos desse formulário; o caminho vindo de um anúncio mantém sua identificação.

**Tabela e ações**

Colunas iniciais: data/hora, contato ou descrição da intenção, formulário/método, origem resumida e atendimento. Suspeita, teste e falha de aviso devem ter identificação textual localizável; detalhes técnicos ficam no registro. Usar rótulos de leitura, mantendo os códigos estáveis nos contratos dos agentes.

Clique sem cadastro aparece como **Clique de contato** ou equivalente com método/destino, sem inventar pessoa ou tratá-lo como formulário recebido. Contatos provenientes de integração exibem sua origem e o momento da captura quando disponível.

Disponibilizar ações claras conforme a permissão e o estado: abrir, marcar respondido, marcar spam, mover à lixeira e restaurar. Aprovar suspeito exige ação específica com explicação dos efeitos existentes. Salvar atendimento não pode modificar captura, lixeira ou outra dimensão por ausência de um campo no POST.

Exibir o resultado real de cada ação e preservar revisão otimista, proteção do POST e autorização. Recarregar após um POST concluído não repete a operação. Ações que enviam mensagens, quando oferecidas, precisam ser identificadas como envio; marcar respondido ou restaurar um contato não dispara e-mail/conversão automaticamente.

**Exportação**

O CSV atual é gerado sem receber os filtros da listagem; corrigir essa divergência. **Exportar resultados** deve usar o mesmo contrato de filtros, segmento e ordenação relevante da consulta, informando se abrange todo o recorte ou somente a página. Exportação geral, quando disponibilizada, é uma escolha explicitamente diferente. Preservar as permissões e o tratamento de células perigosas do CSV.

Definir recorte temporal de extração ou estratégia de consistência para exportações paginadas, evitando duplicação de linhas durante novas capturas. Respeitar limites e comunicar erro/incompletude; não finalizar uma extração parcial como completa.

### 15.3 Detalhe do contato

Organizar a leitura em blocos:

1. **Contato e solicitação:** nome/e-mail/telefone quando existentes, mensagem e respostas com os rótulos correspondentes ao snapshot/revisão.
2. **Origem:** formulário, página, plataforma, campanha/anúncio, evidência e atribuição disponível.
3. **Atendimento e avisos:** estado, histórico, falhas de transporte e ações pertinentes. Aviso interno e resposta ao visitante são identificados separadamente.
4. **Anexos e materiais:** nomes, tamanhos legíveis, estado e acesso autorizado.
5. **Jornada observada:** disponível quando os vínculos e a permissão permitem; ausência de sessão não impede abrir o contato.
6. **Detalhes técnicos**, recolhido: IDs, correlação, horários de referência, contexto técnico e JSON para diagnóstico.

Dados estruturados e ações operacionais aparecem antes do JSON. Horários são apresentados no fuso indicado, com referência UTC acessível nos detalhes. Campos ausentes, arquivos indisponíveis e histórico expirado têm indicação própria. Nenhuma renderização deve executar conteúdo enviado pelo visitante.

Manter acesso direto ao registro por ID e retorno à lista filtrada. Agrupar por e-mail é uma consulta de correspondência; não funde pessoas nem elimina solicitações distintas.

### 15.4 Listagem e editor de formulários

**Lista antes do editor**

A tela inicial mostra nome, ID, finalidade, Ativo/Inativo e usos detectados, com ações Novo, Editar, Duplicar, Prévia e Ver contatos. Carregar somente a definição escolhida para edição. Resultados de detecção de uso indicam seu alcance; não declarar ausência absoluta quando referências dinâmicas não puderem ser inspecionadas.

Novo formulário começa inativo e com resposta ao visitante desligada. Duplicar gera um novo ID, exige revisão das configurações e não ativa/envia nada. Inativar e remover são ações distintas. Antes de remover uma definição, mostrar os usos conhecidos e o efeito sobre blocos/shortcodes; preservar leads e snapshots históricos.

**Editor por formulário**

Organizar em **Geral**, **Campos**, **Após o envio** e **Avançado**, mantendo um rascunho local coerente ao alternar as seções:

- Geral: nome, finalidade, estado e instrução de inserção. O ID é estável; formulários já usados não devem ter o ID renomeado incidentalmente na edição comum.
- Campos: lista ordenada com resumo de rótulo, tipo e obrigatoriedade; editar um campo por vez. Reordenar com controles acessíveis Subir/Descer, além de eventual arraste. Remoção no rascunho deve poder ser desfeita antes de salvar.
- Após o envio: confirmação ao visitante, aviso interno, resposta automática opcional, WhatsApp ou material entregue. Mostrar somente controles aplicáveis à finalidade selecionada e explicar dependências.
- Avançado: identificadores, parâmetros técnicos e JSON do formulário selecionado. GUI e JSON editam a mesma definição; uma edição inválida não pode ser sobrescrita silenciosamente pela outra representação.

Usar seletores para tipos, papéis e finalidade; checkboxes para booleanos; editores de lista para opções; controle de e-mails para destinatários; escolha por nome para materiais privados, mantendo seu ID no dado. Rótulos técnicos como `regime`, `ativo` e valores internos não devem exigir conhecimento do contrato para operar.

O campo de destinatários distingue **Usar padrão do site**, **Destinatários próprios** e **Nenhum destinatário neste formulário**. Essas escolhas correspondem a chave ausente, lista preenchida e lista explicitamente vazia. Alterar outro campo não modifica essa escolha.

Configurações de anexo aparecem somente no tipo arquivo. Sem limite informado, aplicar a decisão já definida: nenhum teto de tamanho/extensão pelo plugin; mostrar limites efetivos do PHP/proxy conhecidos e informar quando algum limite externo não puder ser determinado. Não substituir vazio por 10 MiB.

Prévia utiliza o mesmo renderizador validado, sem gravar lead, enviar mensagens ou produzir conversão. Teste real é uma ação separada que segue a ativação do modo de teste da seção 9, com identificação do site/navegador.

**Validação e gravação**

Botão principal **Salvar formulário**, com erro junto ao campo e resumo dos erros. **Validar/Prévia** não deve ser apresentado como gravação. Indicar alterações não salvas e confirmar o resultado persistido.

A opção atual armazena o conjunto de definições. A edição de um formulário deve preservar os demais e todos os campos válidos não alterados. Se a revisão do conjunto mudar por outro operador/agente, apresentar conflito e manter o rascunho para comparação. Não trocar automaticamente a revisão esperada por uma atual e reenviar o conjunto antigo, pois isso sobrescreveria trabalho concorrente.

Tratar mudança de tipo/finalidade de modo explícito: não perder silenciosamente valores ao ocultar controles nem salvar combinações inválidas. O contrato, a normalização e a validação do servidor continuam sendo a fonte dos valores suportados. Publicação de formulário sem dados obrigatórios deve ser recusada com mensagem compreensível.

Se o editor visual depender de JavaScript, a ausência/falha do script precisa ser indicada, preservando o acesso à edição avançada validada; não mostrar um formulário aparentemente vazio pronto para substituir a configuração. Navegação, lista e demais controles essenciais mantêm funcionamento por teclado e tela estreita.

### 15.5 Conteúdo privado e documentação

Substituir a listagem JSON de materiais por tabela com nome, tamanho, estado e identificação dos vínculos conhecidos. A seleção do material no formulário deve usar essa mesma fonte. Manter autorização dos downloads e evitar exibir caminhos físicos ou URLs públicas de arquivos privados.

Atualizar guias instalados, instruções dos agentes, ajuda dos campos, screenshots/evidências da release e pontos de entrada por ability com a nova navegação. Documentar os filtros, defaults, ordenação/cursor, efeito das ações e edição com revisão. A GUI e os agentes devem operar sobre os mesmos serviços e invariantes, sem depender um do outro para executar a tarefa.

### 15.6 Aceites de leads e formulários

| ID | Cenário | Resultado esperado |
|---|---|---|
| LF1 | Instalação nova e atualização da base suportada | F3 Base sem Leads (contingência); Contatos concentra Leads, Formulários e Conteúdo privado; dados e permissões preservados. |
| LF2 | Ambiente que apresentava o submenu de contingência | Responsável identificado e registro indevido corrigido; ausência confirmada sem máscara CSS ou remoção indiscriminada de outros menus. |
| LF3 | Filtros fechados, busca, anúncio, teste, lixeira e datas | Controles adequados, recorte aplicado no servidor e fuso declarado; estados e dimensões não se confundem. |
| LF4 | Lista recente, paginação, abertura e retorno | Ordem estável, filtros/posição preservados e cursores coerentes; mudança de filtro não reutiliza cursor inválido. |
| LF5 | CSV de uma lista filtrada com várias páginas | Mesmos registros elegíveis do recorte declarado; sem inclusão silenciosa de toda a base, duplicação ou sucesso parcial. |
| LF6 | Detalhe com/sem sessão, anexo, origem publicitária e campo histórico | Leitura organizada e snapshot correto; indisponibilidades declaradas; JSON recolhido e acesso autorizado. |
| LF7 | Alterar atendimento, spam, captura e lixeira | Só a dimensão solicitada muda; revisão/conflito respeitados; nenhum envio/conversão ou repetição do POST não solicitado. |
| LF8 | Criar/duplicar/editar/inativar formulário | Um formulário por vez, IDs distintos/estáveis e demais definições preservadas; criação/duplicação inativas e sem mensagem automática. |
| LF9 | Destinatário herdado, próprio e vazio; arquivo sem limite | As três escolhas persistem; nenhuma lista vazia preenchida automaticamente e nenhum teto implícito de anexo introduzido. |
| LF10 | GUI/JSON, mudança de tipo, prévia e erro de validação | Definição única e rascunho preservado; erro localizado; prévia sem captura/envio; tipo/finalidade consistentes. |
| LF11 | Operador e agente alteram definições concorrentemente | Conflito legível sem sobrescrever outra alteração; revisão não é avançada silenciosamente no rascunho. |
| LF12 | Teclado, tela estreita, permissão parcial e JavaScript ausente/falho | Listas/ações acessíveis conforme capability; edição sem falsa perda de dados; documentação instalada corresponde ao fluxo entregue. |

O aceite inclui inspeção visual em navegador e jornadas completas: localizar um lead de um anúncio, responder operacionalmente, exportar o recorte, editar um formulário sem afetar os demais e conferir a captura posterior. A preparação acima foi baseada no código local; não alterou menus ou dados em produção.

## 16. Prioridades do pacote — revisão de 27/09/2026

### 16.1 Escopo e decisões preservadas

Fonte: anexo **Markdown colado.md**, recebido em 27/09/2026. São 22 itens, numerados 9, 17, 25, 30, 31, 32 e 34–49. Os números são do backlog do dono; lacunas na sequência não indicam itens descartados nesta revisão. Relatos e medições da frota são evidência fornecida pelo dono, não novas medições desta preparação.

- **Pipedrive/CRM e webhooks comerciais adiados.** O item 17 é uma consolidação de pendências, não autorização para retomar essa integração. Permanecem os avisos por e-mail e as funcionalidades de contatos já previstas. A reserva conceitual de `entrega` na especificação antiga não comprova uma coluna implementada no banco.
- **Aceites 19–22 já concluídos:** preservar os resultados relatados de 24/09; fazer regressão dos fluxos afetados, sem reabrir migração CF7/Flamingo ou suporte anterior à 1.12.0.
- **Estilo dos formulários pertence aos temas.** O pacote corrige semântica, reset e confirmação; não acrescenta opções de cor de rótulo, classe ou alinhamento de botão. O CSS do consentimento é outra responsabilidade e está incluído no item 45.
- **Listas vazias e escolhas explícitas permanecem.** A atualização não repete a substituição de lista vazia do item 29. O verificador de cache deve continuar cobrindo arquivos `.php` do WP Super Cache, além dos formatos efetivamente suportados; não reintroduzir a premissa exclusiva de `.html` do item 28.
- **FAQ padrão ligado**, conforme decisão transcrita no anexo. A migração não converte um `false` explícito em `true` silenciosamente. O novo perfil identifica divergências de escolhas existentes para correção deliberada pela operação.
- **Cadência da frota não decidida aqui.** Documentar primeiro o que ela produz; não selecionar mensal/quinzenal/nenhuma nem alterar o limiar de ajustes dos sites por inferência.
- As referências a documentos `claude/`, páginas privadas e ao Padrão no anexo são rastreabilidade. Esta revisão não afirma ter conferido conteúdos que não estavam anexados. Para fechar o perfil completo, usar sua versão aprovada efetiva; não reconstruir regras faltantes a partir de suposições.

### 16.2 Conferência do código e limites da evidência

Inspeção estática realizada nas fontes locais de `work/core-1.13.0/fontes/plugin`:

| Área | Constatação nesta preparação | Implicação |
|---|---|---|
| Atribuição de formulário, item 32 | A 1.13.0 já envia `a.atribuicao` quando `f3baseAnalise.contexto()` existe. A análise produz UTMs/referrer com `modelo: sessao`; o validador aceita `modelo`, mas não o vocabulário completo do clique. | O diagnóstico de ausência total de envio refere-se às versões anteriores relatadas. Na base atual falta unificar origem, primeiro toque, vocabulário e independência da camada de análise. |
| Meta/LinkedIn, item 31 | `carregar()` chama os dois carregadores diretamente; a política `googleCarregamento` governa o Google. | Corrigir o carregador compartilhado e o contrato por destino. |
| Análise, itens 37–38 | `emit()` agenda `flush` em 250 ms, e `boot()` também chama `flush()` imediatamente; a renovação só ocorre após 403 `token_invalido`. | Antecipar a validação temporal e mudar todos os pontos de descarga inicial, sem perder o evento capturado. Conferir também concorrência e confirmação parcial na seção 17.7. |
| FAQ, item 49 | `colher_details()` busca a pergunta em `attrs.summary`; catálogo tem `faq_schema: false`. | Ler o HTML realmente salvo e alinhar catálogo, perfil, ajuda e verificação. |
| Pessoas/CTA, itens 40 e 43 | `pessoas()` não acrescenta `worksFor`; `carimbar_cta()` verifica a classe somente no próprio link. | Corrigir os vínculos do grafo e a travessia de contêineres. |
| LLMS, item 35 | Verificação condicional prefere ETag e só tenta Last-Modified quando ETag está ausente. | Testar validadores separadamente; um ETag de compressão não deve impedir prova válida por data. |
| Cadência, item 48 | `executar()` registra resumo de módulos, options e conteúdo demonstrativo em `F3Base_Atividade::ULTIMA_CADENCIA`, com duração, resultado, erro e próxima execução. Não foi encontrado envio de e-mail nessa rotina. | Explicar que o destino atual é o registro de atividade; tornar esse resultado localizável, sem prometer relatório enviado. |
| Scripts, item 47 | Tracking solicita rodapé + defer; consentimento declara head com estratégia condicional; análise depende de tracking e usa só `true` para rodapé, sem strategy. | Dependente bloqueante confirmado no código; a seção 17.6 especifica o ajuste e a prova do HTML servido. |
| sameAs, item 9 | Existem `recurso_http_observado` e origens configuradas `core`, `yoast` ou `ambos`; terceiros ficam desconhecidos sem evidência. | Validar o resultado final e a cobertura, sem reimplementar como se esses recursos estivessem ausentes. |

Os demais comportamentos do anexo entram como defeitos/necessidades reportados com teste de reprodução especificado abaixo. Nenhum item é encerrado só por ter código correspondente ou por passar em inspeção estática.

### 16.3 Ordem e rastreabilidade

Prioridade 1: integridade dos contatos, continuidade da publicação e proteção pública. Prioridade 2: carregamento, grafo e contratos operacionais. Prioridade 3: acabamento e documentação, integrados às frentes que alteram. Essa ordem organiza o trabalho; todos os itens abaixo têm destino no escopo e nenhum desaparece por ter prioridade menor.

| Item | Prioridade / frente | Entrega e aceite mínimo |
|---|---|---|
| 9 | 2 — diagnóstico | `cache.evidencia` sem duplicação semântica de tokens; sameAs com origem e resultado HTTP discriminados. **BK09:** repetição, erro, redirect e origem desconhecida corretamente representados. |
| 17 | Escopo | CRM/webhooks adiados; pendências funcionais cobertas por 25, 32 e 34. **BK17:** release e documentação não anunciam Pipedrive disponível e não reabrem aceites já concluídos. |
| 25 | 3 — formulários | Sem `label for` inválido, reset somente após confirmação e robots coerente. **BK25:** rádio salvo no editor, envio aceito/recusado, repetição e confirmação sem JS. |
| 30 | 1 — atribuição | Redirect preserva query por padrão, com descarte por par. **BK30:** Location e verificador cobrem UTMs/click IDs, query de destino, repetição de parâmetros e ausência de laço. |
| 31 | 2 — carregamento | Meta e LinkedIn seguem política por destino com fila, interação/teto e consentimento. **BK31:** rede antes/depois da liberação, conversão sem duplicação, recusa e revogação. |
| 32 | 1 — atribuição | Mesmo serviço e contrato de origem no clique e formulário. **BK32:** campanha → navegação interna → formulário mantém primeiro toque com/sem análise local habilitada. |
| 34 | 1 — captura | Destino explícito para gatilho sem href. **BK34:** botão WhatsApp classificado corretamente; interno e destino inválido sem falso WhatsApp. |
| 35 | 1 — LLMS | Bloco gerenciado no servidor e prova HTTP por validador válido. **BK35:** gzip/identity, UTF-8, cache, robots, ativação/desativação e arquivo externo preservado. |
| 36 | 1 — LLMS | Geração anterior utilizável até troca coerente; tarefa llms retomável. **BK36:** atualização/cache em site sem tráfego não provoca 404 transitório dos recursos já publicados nem exposição de conteúdo retirado. |
| 37 | 2 — análise | Renovação preventiva de token e diagnóstico do TTL. **BK37:** HTML com token expirado não provoca o 403 evitável; renovação concorrente é única e eventos não se duplicam. |
| 38 | 2 — análise | Comparar formas de adiar o transporte antes de fixar a política. **BK38:** relatório com perda de visitas curtas, latência e janela de rede/CPU; escolha documentada com eventos deduplicados. |
| 39 | 2 — autoria | Retirar Person de usuário sem referência legítima na autoria institucional. **BK39:** artigo institucional sem autor residual; pessoas da equipe e autores legítimos preservados. |
| 40 | 2 — pessoas | `worksFor` referencia a Organization efetiva. **BK40:** vínculo resolvível, sem organização ou pessoa duplicadas nem emprego inferido sem declaração. |
| 41 | 2 — serviços | Oferta estruturada opcional, fiel ao preço exibido. **BK41:** preço, moeda e período corretos; sem oferta em serviço que não publica preço e sem duplicar a oferta do tema. |
| 42 | 2 — navegação | Sem vínculo explícito, navegação de blocos e clássica distinguíveis. **BK42:** salvar/ler 0, ID inválido, revisão, menu inline e menu clássico sem falso ok. |
| 43 | 1 — captura | Carimbo do servidor alcança links em contêiner marcado. **BK43:** core/button, menu e contêiner compatível com Elementor têm DOM correto antes do clique e um único registro após. |
| 44 | 1 — proteção | Três controles por site: usuários REST, XML-RPC e mensagem de login. **BK44:** bloqueio anônimo e autenticação/MCP legítimos funcionando; multicall/pingback realmente impedidos quando XML-RPC está desligado. |
| 45 | 3 — consentimento | CSS mínimo com variáveis, herança e fallback de contraste. **BK45:** banner, link, foco e controle do rodapé legíveis em temas claros/escuros e no caso Conselar. |
| 46 | 2 — configuração | Leitura com padrão, origem e chaves herdadas; perfil versionado no pacote. **BK46:** ausente, falso, zero, lista vazia e inválido não se confundem; leitura não grava. |
| 47 | 2 — carregamento | Scripts sem bloqueio desnecessário, dependências e primeiro evento preservados. **BK47:** verificar posição/atributo reais no HTML e ordem no navegador, com/sem cache e consentimento. |
| 48 | 3 — operação | Explicar conteúdo, destino, consulta e ausência de aviso da cadência atual. **BK48:** execução conhecida aparece por tela e canal com horários/resultado; nenhuma mensagem ou correção automática introduzida. |
| 49 | 2 — FAQ | Ler summary salvo, ligar FAQ à página e padrão true. **BK49:** bloco real do editor e grafo nas páginas 14/19 da Praxis, quando homologação no site estiver disponível. |

Os aceites BK complementam os das seções anteriores. Cenários citando sites são alvos de homologação, não alterações já executadas. A matriz deve acompanhar o relatório final com estado, evidência e eventual impedimento por item.

### 16.4 Captura, atribuição e formulário — itens 25, 30, 32, 34 e 43

**Redirects.** Acrescentar política por par, proposta `preservar_query: true`, com campo booleano e ajuda de efeito concreto. Em pares existentes sem a chave, preservar a query por padrão conforme pedido; `false` explícito descarta somente a query recebida, mantendo a query deliberadamente configurada no destino. As chaves da query do destino prevalecem em colisões; preservar os demais parâmetros recebidos, inclusive valores codificados, vazios e parâmetros repetidos. Não usar uma conversão que silenciosamente perca repetições ou altere nomes. Manter as proteções de destino, status e prevenção de laços; fragmentos não chegam ao servidor e não podem ser recuperados. Atualizar schema, sanitização, gravação e `redirects-verificar`, que deve executar uma origem com query de teste e apresentar Location esperado/observado sem dados pessoais.

**Atribuição comum.** Implementar a seção 12 como fonte única: clique, formulário e análise chamam o mesmo resolvedor e o mesmo validador versionado. A origem do formulário não pode depender de a análise comportamental estar habilitada. Preservar o primeiro toque e seu horário, além dos campos de último toque já previstos, com evidência e mesma regra de consentimento nos dois caminhos. Não basta aceitar chaves arbitrárias: declarar tipos, limites, campos opcionais e tratamento de valores desconhecidos. Ausência de consentimento/armazenamento/sessão deve continuar permitindo o contato e deixar a atribuição indisponível de forma explícita. Formulário sem JavaScript não ganha histórico de navegação por inferência. Não reescrever contatos antigos inventando campanhas ausentes.

**Gatilhos sem href.** Adotar `data-f3base-destino` como URL explícita, com precedência sobre `href`; atributo ausente usa href, atributo presente inválido produz diagnóstico próprio. Tema/integração que abre WhatsApp dinamicamente é responsável por expor o destino no momento do acionamento. O plugin normaliza e classifica pelo destino efetivo, validando protocolo/host e preservando a intenção do elemento. Não usar um rótulo de classe ou ausência de nome/e-mail como prova de WhatsApp. URLs com texto de mensagem devem ser sanitizadas: não copiar respostas pessoais da query `text` para o histórico comportamental. Clique, registro local e evento externo usam a mesma classificação.

**Carimbo do servidor.** Resolver a classe no próprio link ou ancestral conforme a regra pública do cliente, sem ampliar para todos os links da página. Usar travessia HTML que preserve contexto/nesting e atributos existentes; não regex que associe links de contêineres vizinhos. Respeitar `data-f3base-lead` já declarado, contêineres aninhados e marcação repetida. Documentar limites em HTML gerado só no cliente: nesses casos o carimbo JS continua necessário e o diagnóstico não deve fingir evidência no HTML inicial. As correções locais de tema só podem ser removidas após provar equivalência no site correspondente.

**Semântica e reset.** Grupo de rádio/checkbox usa fieldset + legend como nome do grupo e rótulo de cada opção; eliminar o label externo com destino inexistente. Depois de recebimento aceito confirmado, limpar valores preenchidos e arquivos, preservar confirmação/link de material ou WhatsApp e campos de configuração. Manter os dados em erro/resultado incerto. Separar o snapshot da submissão concluída da próxima: resposta duplicada conserva o mesmo resultado; uma nova edição intencional prepara novo ID/token e novos eventos sem gerar outro contato por um clique repetido. Não aplicar reset cego a todos os campos ocultos, consentimento persistido ou antispam. Alinhar meta robots e X-Robots-Tag da confirmação sem JS em `noindex, nofollow`, sem instrução `follow` contraditória.

### 16.5 Carregamento e coleta — itens 31, 37, 38 e 47

**Uma política por destino.** Reutilizar os modos e o teto já existentes para Google, acrescentando Meta e LinkedIn no mesmo serviço. GUI: política geral + exceção opcional por destino, com valores fechados; evitar três editores independentes com semânticas diferentes. Sem exceção gravada, Meta/LinkedIn herdam a política Google já escolhida, conforme pedido; registrar essa mudança de comportamento nas notas de atualização. Conservar a opção Google suportada desde 1.12 como entrada do contrato, sem manter um segundo carregador concorrente. O padrão numérico do teto deve vir do contrato efetivo e ser mostrado, não ficar oculto no JS.

Em `apos_interacao`, inicializar as filas locais de fbq/lintrk sem baixar scripts externos; liberar na primeira interação elegível ou no teto configurado, uma vez por destino. Interação e teto nunca substituem consentimento: revisar permissão e contexto de teste antes de carregar e antes de enviar. Revogação impede novos envios e descarta eventos que perderam permissão. Preservar ordem, timestamps e identificadores usados na deduplicação; page view/conversão não podem sair uma vez pela fila e novamente pelo callback do carregador. Tags instaladas por tema/GTM seguem o controle de seu proprietário: diagnosticar duplicidade e documentar o alcance, sem prometer que o Core adia código externo que não controla. Google, Meta e LinkedIn precisam ser testados também isoladamente.

**Token preventivo.** Compartilhar a lógica temporal de tracking com análise: ler o prefixo de expiração, aplicar pequena margem documentada e solicitar token novo antes do primeiro envio quando necessário. Essa leitura não valida a assinatura; o servidor continua validando tudo. Uma promessa de renovação em andamento atende os lotes concorrentes; aplicar timeout e retentativa limitada sem retirar da fila eventos ainda não confirmados. Manter o tratamento de 403 como recuperação excepcional de expiração/revogação entre checagem e envio. Não fazer renovação nem enviar análise antes de permissão. TTL de página superior ou desconhecido em relação à vida do token deve aparecer no diagnóstico, com fonte e incerteza; a renovação preventiva não exige reduzir automaticamente o cache do site.

**Separar captura de transporte.** Capturar a visita e os eventos desde que permitidos, sem depender de enviar HTTP no DOMContentLoaded. Comparar em bancada: (A) comportamento atual como referência; (B) primeira descarga após load com prazo; (C) descarga por visibilitychange para hidden, pagehide de reserva e prazo máximo para páginas longas. A alternativa C é candidata, não resultado já medido. Não escolher um prazo apenas para ficar fora da execução do PSI nem detectar Lighthouse para mudar a coleta. O objetivo é reduzir trabalho/rede na abertura preservando cobertura útil.

Medir visitas com saída em menos de 1 s, 1–3 s, 3–10 s e permanência longa, troca de aba/app, navegação interna, bfcache, offline e fechamento. Registrar visitas tentadas/recebidas, perdas/duplicações, atraso de chegada, requisições na abertura e indicadores de desempenho nas mesmas condições. Tokens de HTML velho também entram na matriz: renovação preventiva na saída pode não concluir a tempo, portanto sua agenda precisa ser avaliada junto ao transporte. O fechamento abrupto pode impedir qualquer callback; não prometer zero perda. Se a solução adiada comprometer cobertura sem compensação comprovada, registrar o resultado e ajustar a política antes de publicar.

Manter lotes pequenos e limites reais do transporte, IDs de eventos estáveis e deduplicação no servidor. `sendBeacon()` aceitar uma fila não comprova gravação; `fetch` com keepalive também pode perder a resposta ao encerrar. Não descartar como entregue um lote apenas por disparar a requisição. A fila persistida continua obedecendo consentimento, retenção e marca de teste; revogação a limpa. Analytics pode esperar; envio do formulário e confirmação de recebimento continuam imediatos e independentes.

**Scripts próprios.** Preferir ordem determinística com defer efetivo e/ou rodapé; async só quando não houver dependências. Conferir consentimento → tracking → análise e todos os consumidores, dados inline e inicialização tardia após DOMContentLoaded. Não forçar atributo por substituição textual sobre o HTML para contornar a árvore do WordPress. O primeiro `f3base_pagina_vista` permitido deve ocorrer uma única vez; sem consentimento, nenhuma tag externa deve vazar enquanto o controle carrega. O banner deve continuar disponível no momento necessário. A prova usa HTML público com cache HIT/MISS, atributo/posição reais, waterfall e console. A melhoria de web-vitals já solicitada continua preservada; não classificar o arquivo vendorizado minificado como sem minificação.

### 16.6 Publicação LLMS e cache — itens 9, 35 e 36

**Cabeçalhos do arquivo físico.** Gerenciar bloco próprio na raiz pública correta, preservando todos os blocos externos. Para Files llms.txt: ForceType text/plain; charset=utf-8; ExpiresActive Off quando mod_expires existir; remover Expires, definir Cache-Control único no-cache, max-age=0, must-revalidate e X-Robots-Tag conforme indexavel. Conferir a resposta efetiva para identity/gzip e evitar cabeçalhos duplicados.

**Aplicação explícita, nunca na ativação:** `f3base_llms.cabecalhos_servidor` tem padrão true, mas a instalação só registra pendente_aplicar. O efeito roda na ação autenticada de salvar/aplicar ou tarefa llms explicitamente invocada, com hash/revisão, backup protegido, escrita atômica, sonda e restauração conforme seção 20. Cron comum não aplica pela primeira vez. Desligamento da preferência e downgrade removem somente regras próprias pela mesma operação; não depender de hook de desativação ou da 1.13.0. Options -Indexes usa chave independente no bloco e permanece desligado até a confirmação da seção 21. Não solicitar alteração à DreamHost.

Tratar ausência de permissão, módulos e suporte a overrides como impedimento explícito, sem falso verified. Não deixar uma regra incompatível provocar erro no site: validar no ambiente suportado e prever restauração do bloco diante de regressão HTTP. Não escrever diretivas Apache em ambiente Nginx nem prometer configuração automática de servidor que o PHP não administra. A preferência arquivo_gerado permanece; o diagnóstico explica o impedimento e a alternativa dinâmica já disponível. Nenhuma regra manual passa a ser requisito oculto do fluxo normal suportado.

**Revalidação.** Fazer GET/HEAD e requisições condicionais com representação/Accept-Encoding consistentes. Tentar ETag e, quando disponível, Last-Modified em requisições separadas; a tentativa por data não envia If-None-Match. Aceitar 304 por If-Modified-Since quando o ETag de compressão falhar, registrando qual prova funcionou e a limitação do ETag. Não retirar o sufixo nem fabricar outro validador. Conferir corpo/hash da geração, UTF-8, política de cache, indexação e representação tanto gzip quanto identity. Content-Type correto sozinho não comprova o restante. Distinguir verificação pendente por prazo/execução de falha conclusiva de cabeçalho.

**Geração publicável e geração em preparo.** Uma invalidação comum inicia nova geração sem destruir a última geração válida. Converter em área temporária com manifesto, progresso, revisão e trava; só promover recursos concluídos e coerentes. Publicar os Markdown referenciados antes dos índices, conservar os arquivos ainda referenciados pela geração servida e evitar que llms.txt aponte para arquivos indisponíveis. llms-full.txt continua usando a última geração válida enquanto o novo conjunto é preparado, com idade/versão visíveis no diagnóstico. Não apresentar cobertura parcial como publicação completa nem alternar links Markdown para HTML apenas porque o lote começou.

**Retirada de conteúdo prevalece sobre retenção da geração.** Despublicação, proteção por senha, exclusão ou mudança de elegibilidade precisam retirar imediatamente o recurso e sua presença nos índices/full antigos. Reaproveitamento só vale para conteúdo ainda publicável. Se não for possível produzir uma versão antiga já saneada, suspender a representação afetada com estado explícito até reconstruir; jamais servir informação privada só para evitar uma interrupção. Na primeira instalação, não existe geração anterior: publicar após conversão inicial limitada/retomável e mostrar preparo com precisão, sem declarar um arquivo inexistente como disponível.

**Execução sem depender de visitas.** No salvamento, executar trabalho dentro de um orçamento pequeno, documentado e mensurável; após esse limite, agendar continuação e tentar disparo não bloqueante do cron pelo mecanismo WordPress. Falha de loopback não perde a fila. Acrescentar tarefa `llms` a `f3base/executar-pendentes`, com orçamento, cursor/progresso, trava, resultado de publicação e retomada após interrupção. Manter a tarefa no cron real recomendado para sites inteiramente cacheados; exibir último avanço, próxima tentativa, pendência e impedimento. Não fazer toda conversão sincronicamente na visita pública nem usar espera fixa de 90 s como sinal de conclusão. O agente deve aguardar estado/versão esperados antes de julgar ou reverter uma alteração.

**Cache e evidência.** No item 9, conferir a estrutura real antes de eliminar campos: remover somente a duplicação de `tokens` na representação documentada, mantendo uma fonte canônica e não confundindo políticas diferentes que tenham nome semelhante. Não expor valores de tokens no diagnóstico. Cobrir regressão dos itens 28/29: cache `.php`, evidência de HIT, verificação HTTP de exposição direta e listas explicitamente vazias preservadas. O teste de exposição usa recurso controlado e corpo esperado, na cadência de `cache.tokens`, sem executar PHP do cache por inclusão para produzir prova. Resultado de HIT não prova que o diretório está protegido. Na falta do arquivo ou diante de bloqueio que não corresponda ao contrato de corpo vazio, distinguir ausência de prova, acesso negado e exposição confirmada; não manter pendência infinita causada por uma extensão errada.

### 16.7 Dados estruturados — itens 9, 39, 40, 41 e 49

**Autoria institucional.** Quando autoria=organizacao, identificar o nó de usuário que o adaptador do plugin de SEO usou como autor e retirar apenas o Person residual sem referência legítima no grafo da página. Examinar referências por @id antes da remoção. Não eliminar todos os Person: equipe configurada, pessoas descritas e autores/revisores explicitamente utilizados permanecem. Reusar a Organization efetiva; evitar referências quebradas ou criação de outra marca. Exceções de tema existentes só saem depois do aceite do pacote no site e com coordenação da alteração correspondente.

**Equipe.** Para pessoas configuradas como integrantes da organização do site, emitir `worksFor: { @id: ... }` apontando para a Organization existente. Preservar relação explícita já válida; não ligar pessoa de terceiro por simples presença no grafo. Se não existir Organization resolvível, registrar a falta em vez de inventar identificador solto. Documentar que a configuração de pessoas da equipe implica vínculo com a marca; um caso que não represente esse vínculo deve ser declarado de outra forma.

**Oferta de serviço.** Acrescentar objeto opcional `servicos[].oferta`, com preço decimal, moeda e período tipado. Emitir `Service.offers` com Offer; usar PriceSpecification/UnitPriceSpecification conforme a semântica do período de cobrança, sem converter rótulo livre em propriedade Schema.org inexistente. Publicação vinculada à página que mostra o preço e a mesma unidade; ausência de preço exibido não autoriza usar zero ou criar oferta fictícia. Tratar preço único e recorrente separadamente, preservar precisão decimal e URLs/@ids estáveis. Deduplicar contra o grafo de terceiros. O exemplo Twinia é fixture de necessidade; a retirada da exceção do tema continua dependendo da prova de cobertura e do segundo site previsto no anexo, sem inventar esse segundo caso.

**FAQ real do editor.** Ler o `<summary>` do `innerHTML`/`innerContent` de `core/details`, com parser adequado à versão suportada do WordPress. Separar pergunta da resposta, percorrer blocos internos e ignorar pares vazios; não repetir a pergunta no texto da resposta. Restringir o grafo ao conteúdo público realmente apresentado naquela página. Reutilizar o WebPage do SEO: acrescentar FAQPage ao @type existente e mainEntity quando compatível; se o adaptador exigir nó próprio, dar identidade/url da página e relação isPartOf com o @id dela, sem nó órfão baseado na home. Evitar duplicação quando outra fonte já emite FAQ.

Mudar `faq_schema` para true no catálogo, reservas de sanitização, instalador/perfil, ajuda e documentação. Manter false explícito e mostrar divergência do perfil quando aplicável. A fixture obrigatória é um bloco salvo pelo editor, sem atributo summary no comentário; testar perguntas com marcação, blocos aninhados, par vazio, página sem FAQ e fonte concorrente. O aceite em Praxis 14/19 exige leitura do grafo servido e `schema-verificar`; não encerrar só com JSON unitário sintético. Dados estruturados válidos não prometem resultado destacado em buscadores.

**Prova de sameAs.** Expor para cada URL: origens configuradas, presença no grafo observado, página/@id de origem, horário, código HTTP inicial/final e cadeia de redirects. A regra pedida exige 200 sem redirecionamento; 200 após 301 não cumpre essa regra. Bloqueios 403/429, login, timeout e CAPTCHA ficam inconclusivos, com motivo, sem apagar automaticamente a configuração. `recurso_http_observado` comprova observação HTTP, não identidade da empresa nem conteúdo autenticado do perfil. Origem do grafo que não pôde ser atribuída ao Core/Yoast continua desconhecida, sem inventar autoria. Manter limites de requisição e proteção contra destinos internos no verificador.

### 16.8 Navegação, herança, perfil e cadência — itens 42, 46 e 48

**Navegação sem vínculo.** Aceitar 0 como valor canônico de sem navegação vinculada; vazio na GUI é normalizado de forma explícita para 0. Para tema clássico que administra seu menu, essa é a escolha proposta: **Navegação pelo tema**, sem exigir que o Core armazene um menu que não consome. Manter seleção de wp_navigation para consumidores que efetivamente usam esse vínculo. Se for necessário suportar referência explícita a menu clássico, ela exige contrato tipado que distinga `wp_navigation` de `nav_menu` e consumidor identificado; não sobrecarregar o inteiro atual. Não mapear um ID de revisão/página para um menu que por acaso tenha o mesmo número. A seção 17.2 esclarece o caso 92 e a descrição do catálogo.

Leitura distingue tipo esperado, objeto existente/publicado, vínculo ao cabeçalho e cobertura da inspeção. Um wp_navigation de reserva não prova uso pelo cabeçalho; blocos inline/HTML podem operar corretamente sem referência. Em tema clássico, localizar menus e posições registradas quando possível; sem evidência de uso dinâmico, responder não confirmado, sem falso ok nem certeza de erro. Um valor legado inválido gera aviso com o valor observado, sem ser apagado por leitura ou gravação de outra opção. Aceitar voltar de um ID válido para 0 pelas mesmas rotas de escrita.

**Origem dos valores.** `config-core-ler` passa a retornar padrão declarado, valor efetivo e `chaves_herdadas` por caminho, além da revisão e indicadores de validade. Calcular herança pelo dado bruto e existência da chave; `false`, 0, string vazia e lista vazia explícitos nunca são herança. Não expor segredos no valor bruto/padrão ou em exemplos; para campos protegidos, informar presença/origem e mascarar o conteúdo. `config-core-perfil-avaliar` utiliza essa mesma informação e separa valor divergente de valor coincidente porém herdado. Consulta não materializa defaults nem grava correção.

**Perfil do piso no pacote.** Distribuir arquivo estruturado versionado com ID, revisão, versão mínima do plugin, regras tipadas e origem da decisão. Catálogo define o padrão de instalação; perfil define a referência operacional: declarar precedência, sem duas fontes que se sobrescrevem. Incluir as decisões efetivamente disponíveis — como FAQ true — e cotejar o restante com a versão aprovada do Padrão antes de fechar o perfil completo. Não distribuir como oficial um perfil reconstruído só a partir desta lista de defeitos. Avaliar gera diferenças reproduzíveis; aplicar continua sendo operação explícita com política/revisão e não substitui vazio por lista.

**Cadência compreensível.** Documentar a releitura de módulos/options e censo de conteúdo demonstrativo, resultado, erro, gatilho, duração, atraso e próxima execução. Expor o registro em Operação e pelo canal, distinguindo último resultado de histórico completo e informando que não há aviso automático nessa rotina. Explicar periodicidade e gatilho após N ajustes separadamente. Nesta release preservar as configurações dos sites e o padrão atual de instalação: periodicidade nenhuma e apos_n_ajustes=0. Alterar a cadência da frota é decisão operacional posterior e não bloqueia a implementação.

### 16.9 Proteção pública e consentimento — itens 44 e 45

**Três controles independentes por site**, no grupo de Privacidade e segurança: Restringir usuários na API pública, Desativar XML-RPC e Usar mensagem genérica de login. O padrão é ligado para opções novas/ausentes; explicitar no release note o efeito na atualização e preservar qualquer escolha explícita contrária. As opções não alteram usuários, senhas, application passwords ou concessões do MCP.

Antes de instalar nos sites com publicação externa, inventariar o meio de acesso. A revisão cita Indexe em fator3 e korvena.com.br: consultar evidência de publicação/autenticação; se usa XML-RPC, preparar a opção específica desligada antes da ativação e registrar exceção. Ausência de log conclusivo exige teste controlado do publicador, não suposição. O teste REST usa autenticação e capabilities efetivas; cookie/Bearer, por si só, não prova autorização. Bloqueio XML-RPC inclui POST, multicall/pingback e retirada de X-Pingback/RSD/wlwmanifest pertinentes; não interferir em métodos REST legítimos.

Restringir `/wp/v2/users` ao anônimo, incluindo coleção, usuário individual, formas com `rest_route` e tentativas por embed/batch que reutilizem esses recursos; preservar rotas autenticadas e permissões nativas. Não bloquear a REST inteira. Para XML-RPC desligado, impedir de fato o processamento de todos os métodos, incluindo system.multicall, pingback e métodos públicos; o filtro `xmlrpc_enabled` sozinho não equivale ao bloqueio completo. Testar integrações que usem XML-RPC e permitir que o operador conserve a opção desligada quando necessário. A mensagem genérica no login não deve distinguir usuário inexistente de senha incorreta no texto exposto; preservar os códigos internos necessários ao núcleo sem devolvê-los como detalhe público discriminante.

Esses controles reduzem vetores específicos, não garantem que um nome de usuário nunca apareça publicamente. O anexo também cita RSS, oEmbed, slug, arquivo de autor e nome público: inventariar esses lugares no diagnóstico e documentar a correção editorial de nome público/nicename por site, pendência 82. Não renomear contas nem quebrar URLs de autor silenciosamente. Autoria institucional é tratada pelo item 39; a remoção de Person não resolve automaticamente todas as outras superfícies. Verificar acesso administrativo, editor e MCP autenticado após as proteções.

**CSS de consentimento.** Manter escopo do componente, baixa especificidade e variáveis para fonte, texto, superfície, links, borda e foco; herdar do tema quando a combinação é utilizável. Herança irrestrita não garante contraste: fornecer par de cores de fallback acessível e permitir integração pelo tema, sem impor botão branco isolado ou título invisível. Critério de aceite de texto normal é 4,5:1, incluindo links; manter distinção além da cor e foco visível. Conferir banner aberto/fechado, controle do rodapé, navegação por teclado, zoom e temas claros/escuros. Não reestilizar botões e links fora do consentimento. As compensações da Conselar só são retiradas após comparar o resultado real e validar todos os estados.

### 16.10 Fechamento, documentação instalada e evidências

Implementar primeiro os contratos compartilhados que as frentes consomem, sem duplicar clientes de atribuição, políticas de carga ou leitura de defaults. Os aceites combinados devem incluir:

1. Link antigo com UTMs/ID de anúncio → redirect → página interna → clique e formulário: atribuição e classificação equivalentes, sessão/correlação preservadas, consentimento e marca de teste respeitados.
2. Cache HIT com HTML acima da validade do token → primeira visita permitida → navegação/saída curta: nenhum 403 evitável, duplicação ou dependência de um carregador publicitário para receber o contato.
3. Atualização 1.12/1.13, nova instalação, troca de opção e purga: arquivo gerado com cabeçalhos corretos, geração LLMS coerente, tarefa retomável e retirada imediata de conteúdo privado.
4. Tema de blocos/clássico, menu inline e botões em contêiner: navegação sem vínculo aceita, carimbo anterior ao clique e captura correta sem CSS do tema transferido ao pacote.
5. Grafo completo com Organization, equipe, autoria e FAQ real do editor: vínculos resolvíveis, origem/HTTP distinguíveis, ausência de duplicações; oferta só onde houver preço exibido.
6. Opções de proteção ligadas/desligadas, aplicação por perfil e listas vazias: controles públicos eficazes, operação autenticada preservada e nenhuma alteração de configuração causada por uma leitura.

A documentação distribuída dentro do ZIP deve explicar os novos campos, defaults, precedência e comportamento de atualização; contratos de atribuição e destinos; filas, tokens e limites de cobertura; tarefas e gerações LLMS; campos de configuração herdados e perfil; proteção pública; cadência e critérios dos verificadores. Incluir receitas para o agente aguardar a conclusão de llms, interpretar inconclusivo e testar com a marca de teste. Exemplos de diagnóstico não expõem tokens, e-mails, mensagens de contatos ou segredos.

Acrescentar rastreabilidade BK09–BK49 ao relatório/manifesto da release, mantendo só os IDs presentes nesta matriz. Documentação/abilities não devem anunciar os recursos antes de implementados e verificados. Não definir número de release nem registrar correção em produção com base apenas nesta preparação. Implantação e retirada de exceções nos temas continuam fases posteriores à construção e à homologação do pacote.

### 16.11 Referências técnicas conferidas em 27/09/2026

- [WordPress — wp_enqueue_script](https://developer.wordpress.org/reference/functions/wp_enqueue_script/): estratégia efetiva considera a árvore de dependências; fundamenta a conferência do HTML servido do item 47.
- [WordPress — xmlrpc_enabled](https://developer.wordpress.org/reference/hooks/xmlrpc_enabled/): o filtro afeta métodos autenticados e não desliga sozinho toda a superfície XML-RPC, incluindo pingbacks.
- [Apache — mod_deflate / DeflateAlterETag](https://httpd.apache.org/docs/2.4/mod/mod_deflate.html): sufixo de compressão pode impedir 304 para o validador de conteúdo comprimido; não exige mudar globalmente a configuração de compressão para executar a verificação proposta.
- [Apache — mod_headers](https://httpd.apache.org/docs/2.4/mod/mod_headers.html): base para gerir cabeçalhos no escopo do arquivo; a disponibilidade de módulos/override depende da hospedagem e deve ser verificada.
- [MDN — sendBeacon](https://developer.mozilla.org/en-US/docs/Web/API/Navigator/sendBeacon): visibilitychange/hidden é o ponto recomendado para envio de análise ao fim da atividade; pagehide é alternativa, com limitações de confiabilidade, especialmente em dispositivos móveis. A escolha final do pacote depende do experimento do item 38.
- [Schema.org — worksFor](https://schema.org/worksFor) e [UnitPriceSpecification](https://schema.org/UnitPriceSpecification): semântica do vínculo de pessoa à organização e do preço por unidade/período.

**Estado desta revisão:** plano atualizado e confrontado parcialmente com o código 1.13.0. Não houve alteração de runtime, execução dos novos aceites, novo instalador, configuração Pipedrive ou mudança nos sites da frota.

## 17. Achados de fator3.com.br e confiabilidade da análise

### 17.1 Consolidação e prioridade

Fonte adicional: **Encaminhamento ao pacote Base Site Core Fator3 — achados em fator3.com.br.md**, revisão do site datada de 25/09/2026 e recebida em 27/09. Somam-se os relatos do dono de dependência bloqueante do script de análise e cinco respostas 503 em testes, a primeira anterior a qualquer alteração. Conforme o relato, nenhum visitante humano recebeu esses erros. Esta preparação não acessou access.log/HAR/banco de produção para verificar as cinco ocorrências.

| Demanda | Relação com o plano | Prioridade e decisão |
|---|---|---|
| Fator3 P1 — navegação clássica | Detalha BK42 | Aceitar 0 para navegação pelo tema, corrigir contrato efetivo e descrição; não criar vínculo fictício. |
| Fator3 P2 — documentação pública | Amplia seção 14 / proteção | Alta: documentação completa continua instalada, em formato protegido; acesso autenticado e por filesystem preservados. |
| Fator3 P3 — robôs contados como humanos | Amplia relatórios e qualidade | Alta: classificação positiva de navegador, robôs conhecidos e desconhecidos; repetição é evidência separada; impedir sugestão automática de redirect só pela contagem atual. |
| Fator3 P4 — destino externo e âncora | Amplia BK30 | Incluir suporte a HTTPS com allowlist explícita e fragmento no destino, sem cadastrar automaticamente hosts da frota. |
| Fator3 P5 — menu/Elementor e valor do CTA | Detalha BK43 | Cobrir hooks corretos e distinguir método, superfície e identificador do CTA. |
| Relato defer | Fecha o diagnóstico estático de BK47 | Dependência bloqueante confirmada; corrigir strategy da análise e validar a cadeia real. |
| Relato 503 | Novo aceite de confiabilidade, ligado a BK37/BK38 | Alta: investigar origem das respostas e corrigir riscos de concorrência/retentativa encontrados, sem declarar causa dos cinco casos já comprovada. |

P2, P3 e confiabilidade de análise entram na primeira frente de correções. Os demais seguem junto às frentes de navegação, redirects, captura e carregamento já previstas, sem duplicar trabalho. Não retirar exceções dos temas antes do aceite equivalente no pacote.

### 17.2 P1 — contrato de navegação que corresponde ao tema

Na base local, o catálogo inicial aceita minimum=0, mas `F3Base_Servicos::catalogo()` altera o schema efetivo para minimum=1 e `recusar()` só aceita wp_navigation publicado. A correção precisa atingir ambos; mudar apenas o catálogo inicial deixaria o defeito ativo.

O novo anexo identifica 92 como termo de menu clássico e o anterior o descreve como ID de revisão. Esses identificadores pertencem a tabelas/espaços distintos e podem coincidir numericamente; não concluir tipo ou uso pelo inteiro sozinho. Para fator3-tech, a evidência fornecida é `wp_nav_menu` na localização primary. A opção do Core não deve impedir o perfil de reconhecer essa navegação pelo tema.

Reescrever a descrição para informar quem consome o vínculo e quando ele é opcional. Retirar a afirmação incondicional de que zerar derruba o menu do topo. Manter o menu do tema e suas localizações; aceitar 0 pela ability/GUI e avaliar o perfil conforme tipo de tema/consumidor. Não mover configuração de menu para o Core apenas para satisfazer o perfil. Um consumidor específico, como um tema que leia a option, deve ter esse requisito documentado e verificado.

### 17.3 P2 — documentação completa, instalada e protegida

**Requisito preservado:** o agente consegue entender o plugin lendo sua instalação, mesmo sem acesso ao projeto de desenvolvimento. A documentação completa não será omitida do instalador. A requisição 200 a CONTRACTS.md é evidência fornecida pelo site; o código local confirma que o leitor atual depende dos arquivos Markdown distribuídos, mas esta preparação não repetiu a requisição pública.

**Empacotamento definido para Apache:** todos os documentos técnicos ficam em docs/, nos formatos Markdown/JSON/SQL originais. O ZIP inclui docs/.htaccess com Require all denied e index.php sem saída em cada diretório; preserva a proteção declarada de dados/. Esses arquivos oficiais constam do manifesto e são repostos em toda atualização. O Padrão deve distinguir proteção distribuída do remendo manual proibido.

Mover os documentos da raiz, atualizar links e manter aliases dos nomes aceitos pela ability. `documentacao-ler` conserva autorização, allowlist, paginação e hash. SQL/JSON permanecem inertes, e o agente continua lendo os arquivos diretamente pelo filesystem. Invólucros PHP ficam retirados do plano. Distribuição em servidor diferente do Apache exige proteção homologada antes da instalação nesse ambiente.

Remover apenas cópias obsoletas pertencentes ao manifesto; não deixar backup/ZIP público. Invalidar caches controlados e conferir URLs antigas/novas com plugin ativo e inativo: GET/HEAD deve retornar 403/404 sem documento, e diretórios não devem listar arquivos. index.php sozinho não protege arquivos conhecidos; verificar AllowOverride e a regra de acesso efetiva.

Usar navegador/sonda que alcance o servidor e recurso público de controle. 429 de ferramenta externa não comprova proteção. Preservar JS/CSS públicos e leitura autenticada com conteúdo idêntico ao arquivo; não embutir credenciais ou dados de produção.

### 17.4 P3 — classificação de acessos e evidência de automação

**Confirmado no código:** o classificador atual usa uma lista de padrões e atribui humano a tudo que sobra. `Scrapy`, UA que consiste em URL e UA vazio não estão explicitamente contemplados. O parser descarta IP e horário individual antes da agregação; os agregados existentes não permitem reconstruir repetição por IP ou a classificação corrigida sem os logs originais.

**Corrigir caminho antes do reprocessamento:** a expressão `[A-Za-z0-9_-]{60,}` também elimina slugs legítimos de artigos longos. Comprimento isolado deixa de determinar outro. Resolver caminhos públicos conhecidos por índice/cache limitado de permalinks e aplicar proteção específica a rotas privadas, e-mails e tokens, sem consulta SQL por linha de log. Manter normalização, privacidade e limites de armazenamento; truncamento não pode fundir caminhos distintos. Fixtures cobrem artigo com slug longo, Unicode, 404 legítimo, token real em rota privada, query sensível e instalações em subdiretório. Os 1.726 registros informados pela revisão são volume reportado; recuperação depende dos logs originais disponíveis.

**Nova regra:** avaliar primeiro agentes próprios/hospedagem declarados e robôs reconhecidos; acrescentar Scrapy, UA vazio e UA iniciado por http/https ao grupo genérico de automação, com motivo. Para o restante, exigir assinatura coerente de navegador/motor para classificar como navegador provável; UA não reconhecido fica desconhecido, sem virar humano por exclusão. UA pode ser imitado: a assinatura de Chrome no caso de forbidden.html não prova pessoa. A GUI deve usar rótulo de evidência, como Navegador provável, e documentar os códigos/versionamento; ajustar enums, filtros e consumidores para desconhecido não cair novamente em humano ou robô certo por default.

**Sinal de repetição separado:** durante leitura dos logs autorizados, calcular janelas limitadas por site, caminho, método/status e identificador temporário de origem derivado do IP por HMAC. Capturar quantidade, intervalos e periodicidade, com parâmetros versionados e limites de memória/armazenamento. Usar o endereço do log confiável, sem confiar em X-Forwarded-For arbitrário. Proposta: janela de até 24 h, suficiente para comparar rajadas horárias, com estado temporário descartado ao vencer; guardar no agregado a evidência resumida e a versão da regra, sem IP bruto nem histórico individual permanente. HMAC não transforma o sinal em prova de pessoa ou em dado anônimo irreversível; sua finalidade e retenção devem ser documentadas.

Mesmo IP pode representar NAT, empresa ou proxy. Repetição periódica aumenta suspeita de automação, não autoriza bloquear visitantes nem fundir sessões/leads. Testar padrões reais de recarregamento humano e robô disfarçado antes de fixar limiares. Essa informação não substitui a marca explícita de teste dos agentes da seção 9 e não é usada para excluir por IP todos os acessos próximos a uma chamada MCP.

**Relatórios e redirects:** mostrar separadamente navegador provável, automação reconhecida, suspeita de automação e desconhecido, com dimensões de evidência e teste bem definidas. Não somar uma suspeita como uma segunda requisição. O ranking de 404 pode sugerir investigação, mas nenhum par é criado só porque o agregado legado diz humano; exigir página de origem/demanda editorial, correspondência de destino e evidência como links ou Search Console. Preservar os totais técnicos, aplicar filtros sem excluir dados silenciosamente e documentar o efeito na comparação de períodos.

Versionar a classificação. Reprocessamento histórico só é possível com logs ainda disponíveis e janela declarada; reconstruir/substituir aquela janela de forma controlada para não somar tudo novamente. Sem logs, conservar os agregados como regra anterior e indicar a limitação. Os volumes de 1.055 e 393 do anexo permanecem relatos da regra antiga até reprocessamento comprovado.

### 17.5 P4 — redirects externos controlados e âncoras

**Decisão de implementação:** aceitar destino externo HTTPS em hosts explicitamente cadastrados pelo operador autorizado, com lista vazia por padrão significando nenhum host externo permitido. Aceitar fragmento no destino interno ou externo; a origem continua um caminho de requisição e não aceita fragmento, pois o navegador não o envia ao servidor.

Manter o formato dos pares válidos da base suportada e acrescentar a allowlist ao contrato efetivo da configuração. Não gravar automaticamente hosts de empresas do grupo. Comparar hostname normalizado por igualdade exata; subdomínios exigem declaração, sem comparação por sufixo que aprove domínios semelhantes. Rejeitar protocolos diferentes de HTTPS para externo, URLs relativas a protocolo, credenciais embutidas, controles/CRLF e destinos de rede privada. Validar origem/query/fragmento separadamente, sem reaproveitar o validador de path como se uma URL inteira fosse um caminho.

No runtime, permitir no `wp_safe_redirect` somente o destino autorizado para aquela operação, sem abrir globalmente redirecionamentos de outros plugins. Aplicar a política de query da seção 16.4 também ao externo: parâmetros configurados no destino prevalecem; preservar query é o padrão e o operador pode descartá-la por par. A ajuda explica que os parâmetros preservados seguem para o host externo. Construir query antes do fragmento; `/contato` → `/#contato` deve resultar no Location correto, inclusive com UTMs. Rejeitar laço que só muda fragmento mantendo o mesmo endereço requisitado, pois a próxima requisição perderá novamente o fragmento.

O verificador público deve aceitar identidade externa autorizada em vez de exigir post local/mesma marca; aplicar proteção de destinos e limites a cada salto. URL permitida que redireciona a host não autorizado não recebe verified. Fragmento não é confirmado por um 200 HTTP: quando a âncora é interna, conferir sua presença na página; para externo, informar se essa presença foi observada ou não pôde ser provada. Nunca executar no servidor scripts da página de destino para fabricar a prova.

Homologar os pares ventures/capital e contato do anexo, além de host não permitido, subdomínio enganoso, query codificada e ciclo. A prova de HTTP usa o servidor final, não apenas o retorno da validação da option. Depois de homologar os pares no Core, retirar a função equivalente do tema em uma alteração coordenada, conferindo status/Location, query e ausência de duas respostas/duplo redirect. Esta preparação não altera esses sites ou sua allowlist.

### 17.6 P5 e defer — superfícies de CTA e dependências reais

**CTA.** Além de atravessar o ancestral marcado em render_block/the_content (BK43), integrar `nav_menu_link_attributes` para menu clássico e `elementor/frontend/the_content` / `elementor/widget/render_content` quando o Elementor estiver presente. Reusar a mesma função de resolução e preservar atributos explícitos. Não depender de o mesmo HTML passar posteriormente por the_content. Filtros podem executar mais de uma vez; a marcação é idempotente, sem duplicar registro ou alterar classes/links.

Separar método, superfície e identificador do CTA. **Preservar data-f3base-lead e form_id existentes:** whatsapp automático, cta dos temas e IDs de formulário mantêm suas séries. A superfície ganha `data-f3base-superficie`, valores conteudo, menu, flutuante ou elementor conforme evidência, gravado em `dados.contexto.superficie` e enviado como `f3base_superficie`. `data-f3base-cta` mantém o identificador específico. Não inferir flutuante de qualquer widget/CSS nem sobrescrever atributos explícitos. Servidor e JS usam a mesma regra. A dimensão GA4 de superfície é opcional e deve ser criada antes da janela de análise.

O contrato/dicionário deve distinguir esse identificador de fluxo de um formulário real cadastrado: cliques de menu não entram na contagem de envios do editor só por ocupar campo semelhante. Preservar semântica dos registros históricos e indicar a versão da instrumentação quando necessário. A prova DOM pede atributo correto antes do clique nas superfícies renderizadas no servidor; widgets só montados no cliente usam prova após renderização, com essa cobertura declarada. A retirada dos filtros próprios dos temas exige ambos os aceites, DOM e registro final.

**Defer — causa confirmada no código local.** `F3Base_Analise::enfileirar()` chama wp_enqueue_script com dependência `f3base-tracking` e último argumento `true`: isso define rodapé, mas não strategy. Tracking solicita defer e depende de consentimento. O núcleo WordPress lido em bancada, em `WP_Scripts::filter_eligible_strategies()`, elimina as estratégias adiadas se um dependente carregado não declara nenhuma. Essa cadeia explica a perda de defer reportada quando o consentimento também é elegível; não é necessário supor erro no minificador.

Correção dirigida: declarar na análise argumentos com `in_footer=true` e `strategy=defer`, conservar as dependências e conferir consumidores restantes. Não mover todos para async nem remover a dependência só para obter um atributo. Revisar scripts inline after, inicialização, dados localizados e consumidores que possam continuar retirando a estratégia. Consentimento síncrono deliberado em algum modo deve ter sua necessidade validada, em vez de ser mascarado como bug corrigido. Verificar arquivos de fonte e minificado efetivamente servidos e invalidar somente caches necessários à release.

Defer muda execução/ordem, não garante que o download de todos os scripts ocorrerá depois do load nem resolve o transporte de análise sozinho. `boot()` também chama flush imediatamente: ajustar apenas o timer de 250 ms de emit deixaria a primeira requisição na abertura. Os aceites de BK38 e BK47 precisam ser feitos juntos, preservando consentimento e a primeira página vista.

### 17.7 Cinco 503 — investigação delimitada e correções de confiabilidade

**O que sabemos:** o usuário relata cinco erros na rota de análise durante testes, com a primeira ocorrência anterior a mudanças e sem erro recebido por visitante humano. O código da rota local devolve 503 `persistencia_falhou` quando `$wpdb->insert` retorna false. Isso é um caminho possível, não confirmação do corpo/status produzido pela hospedagem nos cinco casos; proxy, servidor ou outra camada também podem responder 503. Não atribuir causalidade às alterações posteriores nem descartar o defeito por ser teste.

**Risco concreto encontrado por inspeção:**

1. No cliente, flush urgente permite passar pela guarda busy; visibilitychange, pagehide e callbacks de vitais podem disparar o mesmo lote enquanto uma requisição anterior continua em andamento.
2. No servidor, a deduplicação faz SELECT por evento e depois INSERT, com UNIQUE KEY evento. Dois pedidos concorrentes podem ambos observar ausência e tentar inserir; o segundo perde a disputa e o código o classifica como falha 503.
3. O lote pode ser parcialmente persistido antes de um erro. O cliente mantém o lote em 503 e tenta novamente depois de 10 s, mas descarta o lote inteiro em 409. Uma atualização de vital que falha no banco também pode terminar como 409 no fluxo atual. Logo, erro permanente, disputa de duplicata e indisponibilidade real não estão suficientemente separados.

Essa sequência é uma hipótese verificável para parte dos 503; ainda não foi reproduzida nesta preparação nem ligada aos IDs das cinco requisições. Outras falhas de persistência — estrutura/permissão/tamanho, conexão, lock ou capacidade do banco — precisam ser diferenciadas pelo diagnóstico, sem escolher uma delas por palpite.

**Diagnóstico necessário para fechar a causa:** coletar corpo/código e Content-Type do erro, horário/fuso, endpoint, identificador da requisição, tamanho/quantidade do lote e contagem de eventos já confirmados. Correlacionar, quando os registros estiverem disponíveis, logs do endpoint, PHP, banco e proxy. Registrar classe técnica do erro SQL, operação e versão de schema com acesso restrito e expurgo de dados pessoais; não devolver SQL, segredos ou erro bruto do banco ao público. Se a resposta for HTML da infraestrutura, classificá-la como tal. Se os logs históricos já tiverem expirado, registrar causa histórica inconclusiva e comprovar as correções pelos cenários reproduzíveis, sem inventar uma conclusão retrospectiva.

**Mudanças planejadas:**

- Deduplicação atômica ou tratamento explícito de conflito da chave única: mesma identidade/hash persistidos retornam confirmação; mesmo ID com payload incompatível retorna conflito. Não converter toda falha de INSERT em duplicata nem usar INSERT IGNORE que esconda erros diferentes.
- Para vitais, atualização monotônica por sequência com tratamento de concorrência: evento antigo não substitui mais recente, erro de banco é indisponibilidade, e só conflito de identidade é 409.
- Coordenar fila, lote e pedidos em andamento no cliente. Saída urgente pode tentar entrega limitada quando necessário, mas não depende de uma variável busy para garantir unicidade; IDs estáveis e deduplicação no servidor continuam obrigatórios diante de resposta perdida.
- Respostas por evento, ou confirmação inequívoca do prefixo persistido, para que a fila retire apenas eventos confirmados. Conflito/erro de um evento não autoriza apagar os seguintes que não chegaram ao banco. O contrato deve declarar entrega parcial e confirmar duplicatas idênticas como recebidas.
- Em 429/503/falha de rede, usar espera progressiva com variação e limite, respeitar Retry-After quando presente e retomar sem tempestade de requisições. Tratar JSON e resposta não JSON; erros de cliente permanentes têm destino identificável e não são reenviados indefinidamente. Limites da fila, expiração e perdas devem ser contados.
- Exibir contadores de falha, recuperação, atraso e pendência na saúde operacional, com detalhe permitido ao agente. A exclusão de testes dos relatórios de marketing não exclui os 503 dos diagnósticos de saúde; o contexto teste continua disponível como filtro.

O endpoint de lead/formulário não deve depender do êxito do transporte analítico. Não transformar falha de análise em confirmação falsa de gravação, esconder erros só do console ou desativar a análise para fazer a medição de desempenho passar. O aceite cobre falha parcial, pedidos concorrentes iguais/diferentes, resposta perdida, token renovado, ordem de vitais, 429, 503 JSON e 503 de proxy sem JSON.

### 17.8 Aceites adicionais e critérios de encerramento

| ID | Cenário | Resultado esperado |
|---|---|---|
| FT-P1 | Tema clássico primary, ID 92 ambíguo e gravação de 0 | Menu permanece; contrato aceita ausência de vínculo; perfil explica o consumidor e não infere tipo pelo número. Complementa BK42. |
| FT-P2 | ZIP novo/atualização, plugin ativo/inativo, HTTP anônimo e agente autenticado | Conteúdo completo instalado, hash/paginação corretos, mapa físico legível e nenhum documento estático/backup exposto; caches antigos tratados. Complementa DOC1/DOC2. |
| FT-P3 | Scrapy, UA URL/vazio, navegadores, desconhecidos, periodicidade e NAT | Classes/motivos corretos, sem certeza falsa de humano; suspeita não duplica contagem nem cria redirect; migração/reprocessamento não duplica agregados. |
| FT-P4 | Interno com âncora, HTTPS permitido/proibido, query e redirect em cadeia | Location válido, segurança por host preservada, prova de fragmento distinta de HTTP e sem loop só de hash. Complementa BK30. |
| FT-P5 | Blocos, menu clássico, Elementor e CTA flutuante declarado | Carimbo antes do clique onde há HTML de servidor; método/superfície/CTA distintos e uma captura; explícitos preservados. Complementa BK43. |
| AN-DEFER | Cadeia consentimento → tracking → análise e consumidores adicionais | strategy efetiva observada, ordem correta, sem referência indefinida nem primeira visita perdida/duplicada. Complementa BK47. |
| AN-503A | Dois pedidos simultâneos para o mesmo evento/hash | Uma linha, ambos reconhecem persistência; sem 503 por colisão de duplicata. |
| AN-503B | Banco indisponível/erro real, colisão incompatível e atualização de vital | 503, conflito e recuperação distinguidos; sequência nova preservada; nenhuma falha mascarada como sucesso. |
| AN-503C | Lote parcialmente salvo e resposta perdida/não JSON | Apenas confirmações são removidas; eventos posteriores preservados e retentativas limitadas, sem duplicação. |
| AN-503D | Testes marcados e investigação dos cinco relatos | Falhas visíveis na saúde mesmo excluídas do marketing; causa histórica sustentada por evidência ou expressamente inconclusiva. |

A documentação instalada e o relatório de release devem registrar a mudança da regra de tráfego, limites da atribuição de humano/robô, formato protegido da documentação, regras de destinos externos, nomenclatura dos CTAs e semântica de confirmação/reenvio. Manter um mapa de itens repetidos entre os dois anexos, com uma correção e evidências compartilhadas.

**Estado desta análise:** os sete pedidos foram incorporados ao plano; fontes locais e a implementação WordPress de estratégias foram inspecionadas. Não foi executada reprodução de concorrência, inspeção da hospedagem ou alteração de runtime. Pipedrive permanece adiado.

## 18. Avaliação final das recomendações R1–R14

As leituras nos 14 sites e nos documentos da frota descritas em Recomendações.md são evidência fornecida pelo revisor, com horário de 27/09/2026. Nesta consolidação foram conferidos os trechos pertinentes da base local 1.13.0 e fontes oficiais; não foi repetido o inventário de produção nem acessados os 45 arquivos citados de claude/. O preflight da implantação atualiza os dados que podem ter mudado.

| Recomendação | Decisão | Incorporação e ajuste |
|---|---|---|
| R1 — entrega única | Incorporada | Quatro contratos comuns primeiro; controles por módulo; MySQL/navegador/HIT/MISS como aceite. Falha de gate não é resolvida omitindo o recurso da release. |
| R2 — efeitos na atualização | Incorporada | Matriz de padrões/efeitos nesta seção 19 e inventário por host no relatório de implantação. Ausência de dado por site permanece desconhecida, sem extrapolar a amostra. |
| R3 — destinatário | Incorporada | Admin_email no novo site; preservar vazios explícitos; saúde avalia lista efetiva e origem. E-mail comercial depende do dono, e sua gravação não depende da release. |
| R4 — envio rápido | Incorporada | Manter isca e validade; tempo_curto vira sinal; contagem por motivo. n=1 não estima falsos positivos nem identifica agente. |
| R5 — testes por destino | Incorporada com ajuste | Políticas configuráveis; padrão GA4 suprimir até preparação externa. debug_mode isolado e filtro Testing não limpam relatórios. CAPI tem política/test_event_code próprios; marcar pixel não autoriza produção. |
| R6 — anúncios e cache | Incorporada com ajuste | utm_id para campanha e utm_content para anúncio em molde versionado; utm_term preserva palavra-chave, grupo usa campo próprio. Documentar dimensões manuais do GA4 e completar WPSC; leads nativos fora. |
| R7 — raiz/LLMS/listagem | Incorporada com ajuste | Bloco gerenciado, ExpiresActive Off, aplicação explícita e sondas. Options -Indexes implementado com ativação pendente do dono. Falha/timeout não garante rollback automático. Não inferir permissões da raiz a partir de regra aceita em subdiretório. |
| R8 — docs em Apache | Incorporada | Markdown/JSON/SQL em docs/ com regra distribuída pelo ZIP e índices sem saída; substituir invólucros PHP. Atualizar Padrão para distinguir arquivo gerenciado de remendo. 429 não é prova de bloqueio. |
| R9 — caminhos longos | Incorporada | Corrigir antes do reprocessamento, preservando proteção de dados. Versão da regra e data de corte em comparações. |
| R10 — séries e janela | Incorporada com ajuste | form_id/data-f3base-lead preservados; superfície separada. Janelas seguem horários reais de mudança por site, sem fixar 25–28/09 arbitrariamente nem atribuir efeito composto só ao gtag.js. |
| R11 — proteção pública | Incorporada com ajuste | Três opções; testar publicador Indexe antes de instalar nos afetados. REST autenticada mantém permissões, e XML-RPC é bloqueado integralmente. Não prometer acesso só pela presença de cookie/Bearer. |
| R12 — homologação | Incorporada | WordPress 7.1.2/MySQL 8.0 confirmados no preflight; banco real, browser e transporte de e-mail autorizado. SQLite e inspeção de código são evidência complementar. |
| R13 — implantação/reversão | Incorporada com ajuste | Ordem Site-Teste → korvena.net.br → fator3/korvena.com.br → demais; mesma versão. Reversão testada, preservando capturas novas e proteção dos documentos. |
| R14 — documentos externos | Incorporada | Entregar alterações para Padrão, Conector, Orientação e estado da frota; só declarar atualização externa concluída após escrita/leitura verificadas. |

Dois trechos da conclusão do revisor exigem precisão: a resposta automática ao visitante já existe na base, opcional e desligada por padrão, e deve ser preservada onde configurada; não é correto descrevê-la como funcionalidade inexistente. Além disso, deixar de pedir intervenção à DreamHost não registra automaticamente aceite dos riscos Copper/alias privado: ficam limitações conhecidas, sem remediação nesta release e sem aceite presumido.

## 19. Padrões, efeitos e dependências da atualização

### 19.1 Contrato de configuração

Os nomes novos abaixo são o contrato-alvo a declarar no catálogo, sanitização, abilities, GUI, documentação e testes. Booleanos/enums usam controles adequados e revisão otimista. No grupo de testes, os destinos são separados. Gravar configuração não equivale a enviar e-mail, ativar filtro externo ou aplicar arquivo de servidor.

| Chave/regra | Padrão e precedência | Efeito/reversibilidade |
|---|---|---|
| f3base_contato.email_leads | Lista copiada de admin_email somente na instalação/ausência da chave; próprio/vazio explícito preservados. | Mudar depois é ação normal; não reenvia contatos antigos. |
| f3base_llms.entrega | arquivo_gerado para ausente; dinâmica explícita preservada. | Modo, arquivo e prova HTTP têm estados separados. |
| f3base_seo_entidade.faq_schema | true para ausente; false explícito preservado. | Perfil pode recomendar mudança, sem aplicá-la silenciosamente. |
| f3base_testes.habilitado | true. Cookie/header/contexto explícito, sem credencial. | Desligar não apaga marcas existentes nem libera filas comerciais de testes. |
| f3base_testes.excluir_relatorios | true. | Filtro reversível Sem testes/Somente testes/Todos; não muda retenção. |
| f3base_testes.destinos | GA4, Google Ads, Meta Pixel, LinkedIn, CAPI e e-mails suprimidos até configuração de homologação conforme 9.8. | Configuração por destino; nenhum fluxo público escolhe destinatário/conta. |
| f3base_protecao.usuarios_rest_restritos | true para ausente. | Restrição anônima; preservar permissões autenticadas. |
| f3base_protecao.xmlrpc_desativado | true para ausente. | Exceção false para integração comprovada, preparada antes da atualização. |
| f3base_protecao.login_generico | true para ausente. | Só apresentação pública do erro; autenticação permanece íntegra. |
| preservar_query em cada par | true quando ausente. | false explícito descarta query recebida, preservando a configurada no destino. |
| Hosts externos de redirects | Lista própria inicialmente vazia. | Vazio bloqueia externos; pares internos existentes continuam válidos. |
| f3base_carregamento_destinos | ativo=true; Meta/LinkedIn herdam política Google, com exceções explícitas. | Desligar política adicional restaura agenda de carga declarada, preservando consentimento e política de teste. |
| f3base_llms.cabecalhos_servidor | true como preferência; pendente_aplicar após instalar. | Aplicar/remover exige ação autenticada e prova; não alterar raiz no hook de ativação. |
| f3base_servidor.bloquear_listagem | false até decisão do dono sobre a raiz. | Controle implementado; ativação aplica Options -Indexes no bloco gerenciado, com sonda/restauração. |
| Regra de acessos | Nova versão por padrão, com identificação da regra em cada conjunto. | Controle operacional permite suspender/reverter classificador; não reclassifica histórico sem logs. |
| f3base_nav_id | Aceita 0, navegação pelo tema; ID publicado quando houver consumidor. | Não alterar menu nem preencher ID fictício; preservar valor até operação explícita. |
| Cadência | Manter gravado; novo site conserva nenhuma/0. | Não há decisão de periodicidade necessária para construir a release. |

Desligamento de módulo é medida de isolamento operacional. Estado e efeitos precisam ser claros: suspender coleta não elimina dados; desligar exclusão não apaga a marca; suspender gestão de servidor não remove regras sem ação verificada; não desligar antispam/autorização por conta do modo de teste. A política de canal e f3base_operaveis não são reconvertidas na migração.

### 19.2 Efeito na frota informada pelo revisor

| Mudança | Estado informado em 27/09 | Ao instalar | Operação subsequente |
|---|---|---|---|
| E-mail padrão | Chave presente nos 14; vazia em 12, preenchida em fator3/philon. | Nenhum destinatário é trocado. Saúde expõe desconfiguração onde houver aviso sem lista efetiva. | Gravar endereços após dado do dono; respeitar listas próprias dos formulários. |
| Arquivo gerado | Explícito nos 14. | Preferência inalterada; novo ciclo/diagnóstico pode ter efeito. | Aplicar e verificar cabeçalhos separadamente. |
| FAQ true | false em 13, true em praxiscorp. | Valores explícitos preservados. | Aplicar decisão já tomada do piso nos 13, por escrita com revisão; verificar grafo real. |
| Proteções | Novas chaves. | Padrões ligados salvo exceção previamente gravada. | Provar editor, MCP e publicadores; Indexe exige preflight nos dois sites citados. |
| Preservação de query | Pelo menos 74 pares: fator3 37, twinia 36, fator3capital 1; outros não contados. | Pares sem chave passam a preservar query. | Verificar recorte por site e revisar pares cujo destino não deve receber parâmetros. |
| Meta/LinkedIn após interação | Pixel informado só em korvena.com.br; LinkedIn ausente. | Mudança efetiva do pixel naquele site; contrato disponível nos demais. | Provar gesto/teto/consentimento e revisar Event Setup Tool. |
| Testes | Chaves novas; histórico sem marca. | Marca e filtro passam a valer para dados novos. | Atualizar instruções dos agentes; preparar integrações de homologação. |
| Antispam de rapidez | Um suspeito por tempo_curto reportado. | Novos envios rápidos seguem demais regras; histórico fica intacto. | Observar motivos e efeitos, sem promoção/envio retroativo. |
| Navegação | fator3=92, korvena.com.br=3, fator3grupo=4; capital/net.br=0. | 0 passa a ser aceito; nada é regravado automaticamente. | Conferir consumidor; gravar 0 onde o tema cuida da navegação. |
| WPSC | Faltas verificadas no Site-Teste; perfil semelhante informado para a frota. | Estado pode ficar failed enquanto requisitos não forem atendidos. | Ler e ajustar cada um dos 14 arquivos, sem afirmar que todos têm exatamente a mesma divergência. |
| Bloco da raiz | Regras atuais informadas como WordPress/WPSC. | Nenhuma escrita; preferência de cabeçalhos pendente. | Aplicação um site de cada vez; preservar quaisquer outros blocos que o preflight encontre. |
| form_id e superfície | Dimensão form_id criada nas 13 propriedades, segundo o relato. | Série existente preservada; superfície é campo novo. | Dimensão externa opcional; registrar início da cobertura. |
| Docs, caminhos e classes | Defeitos descritos no anexo. | ZIP protege docs e muda classificador/caminhos de dados novos. | Sondas e eventual reprocessamento controlado; marcar mudança da série. |

O relatório da implantação deve ter uma linha por **host efetivamente devolvido pelo conector**, com versão, defaults presentes/ausentes, delta, revisão anterior/posterior, arquivos alterados, UTC de ativação e provas. Não inventar a identidade dos demais sites nem extrapolar contagens agregadas para cada site. Gerar essa tabela do preflight, anexar ao relatório e preenchê-la a cada aplicação.

### 19.3 Dependências fora do ZIP

- **WP Super Cache:** aplicar delta de parâmetros/exclusões nos 14 wp-cache-config.php, mantendo personalizações. A lista completa vem do catálogo do Core; includes mínimos: utm_id, utm_source_platform, gbraid, wbraid, li_fat_id, f3_ads_v, f3_ads_account_id, f3_ads_group_id, f3_ads_group_type, f3_ads_placement e rotas de teste. Conferir ignore_tracking, exclusões, PHP válido, config carregada e HIT. Não acrescentar ref nem variar cache pelo marcador público de teste.
- **GA4:** inventariar IDs reais das propriedades e filtros existentes. Configuração de filtro de desenvolvedor, prova Testing/Active e eventual dimensão de superfície são tarefas da conta, com acesso autorizado. Enquanto não comprovadas, manter supressão padrão; a release local funciona sem elas.
- **Anúncios:** produzir modelos versionados. O operador escolhe anúncio de teste/conta e autoriza eventual alteração em anúncio ativo. Não mudar campanha comercial nesta preparação nem condicionar o código a gasto real.
- **Publicadores externos:** comprovar meio de acesso da Indexe; documentar exceção se XML-RPC for necessário. Nenhuma mudança em credenciais ou usuários é implícita.
- **Temas:** remover exceções somente após prova de equivalência no site: filtros de CTA, autoria institucional, oferta Twinia quando cumprir condição de saída, compensações de consentimento. Preservar arquivos personalizados não relacionados.
- **Padrão/Orientação/Conector/estado da frota:** atualizar versões, defaults/herança, bloco gerenciado e proteção distribuída, rotina de teste, cache, aceite externo, atribuição/superfície, redirects, tarefa llms, exceções e horários. Registrar a decisão já tomada de cookie sem credencial; não pedir autorização novamente para documentá-la. Conferir itens 69/75/87 nas versões atuais antes da rodada, sem alegar leitura que não ocorreu aqui.

Sem solicitação à hospedagem, permanecem fora da remediação: resposta 429 do Copper, eventual alias que exponha pasta privada e ausência de marca nos logs brutos. Não registrar esses riscos como aceitos sem manifestação específica. A pasta privada continua exigindo diagnóstico/prova de proteção; alias público demonstrado impede usá-la para dados privados até haver solução sob controle do site.

## 20. Implementação, homologação, implantação e reversão

### 20.1 Ordem e definição de pronto

1. Congelar contratos comuns, defaults, esquema e aliases de documentação. Inventariar todos os consumidores e o prefixo real das tabelas; migração deve ser idempotente/retomável de instalação nova, 1.12.0 e 1.13.0.
2. Implementar integridade de dados/filas/redirects, atribuição, proteção e geração LLMS; depois carregamento/schema e as telas, usando os mesmos contratos. Atualizar fontes minificadas, catálogo, perfil e docs junto a cada frente.
3. Executar a matriz de aceites completa no Site-Teste, com o conjunto final instalado. Concorrência/503 e conciliação SQL rodam em MySQL 8.0/InnoDB. Declarar versões reais de WordPress, PHP, banco, cache, tema e plugins relevantes.
4. Empacotar um instalador e suas fontes, manifesto com hashes, changelog, guia de migração/reversão e relatório por ID. Documentação dentro do ZIP deve corresponder ao schema e comportamento entregues.
5. Liberar o mesmo artefato para implantação sequencial. Nenhum item aplicável que altere dados/HTML público pode estar pendente/reprovado no gate de homologação. Limitação externa explicitamente fora do escopo não é convertida em falso aprovado; recursos sem configuração no site ficam desconfigurados/inativos com motivo.

Incluir todas as matrizes E/I/A/H/D, S/T/M, P/U/DOC/LF e BK/FT/AN; matriz de rastreabilidade associa os itens repetidos a uma única prova aplicável. Acrescentar os aceites finais abaixo. Não fabricar estimativa de horas/data sem equipe, baseline e medições; ordem e critério de pronto estão definidos e não exigem calendário escolhido pelo dono.

| ID | Prova final | Resultado obrigatório |
|---|---|---|
| FIN1 | Instalação nova, upgrade 1.12/1.13, repetição e interrupção | Schema/configuração consistentes; listas vazias e política preservadas; sem migração antiga repetida. |
| FIN2 | Configuração GA4 suprimir/marcar e filtro Testing/Active | Efeito externo corretamente identificado; produção normal sem debug involuntário; Ads/GTM não liberados pela escolha GA4. |
| FIN3 | Query do molde v1, WPSC e formulário | HIT/MISS conforme esperado, um contrato de atribuição, IDs corretos, palavra-chave preservada e cache compartilhado sem dados do visitante. |
| FIN4 | Aplicar/remover bloco da raiz e falha de sonda | Sem escrita na ativação; backup/revisão; restauração testada e evidência de resultado/erro; headers sem duplicação. |
| FIN5 | Options -Indexes ligado/desligado em teste | Alvos não listam quando ligado; conteúdo público e cache continuam funcionando; desligar remove só regra própria. Ativação na frota depende da seção 21. |
| FIN6 | ZIP/docs atualizado e plugin desativado | Nenhum documento antigo/novo exposto; ability e files/read mantêm conteúdo completo; 429 não contado como prova. |
| FIN7 | Slug longo, UA desconhecido, Scrapy, repetição e reprocessamento | Caminhos legítimos preservados; evidência de automação separada; sem duplicação e com versão da regra. |
| FIN8 | CTA conteúdo/menu/Elementor e comparação antes/depois | form_id estável; superfície nova correta; método segue destino; nenhuma conversão duplicada. |
| FIN9 | SMTP/caixa de teste e publicador externo | Transporte real comprovado no destino autorizado; Indexe/MCP/editor continuam funcionando segundo as permissões. |
| FIN10 | Ensaio de reversão para 1.13.0 após gerar dados novos | Nenhuma captura nova perdida; regras/filas/configuração tratadas; docs protegidos; incompatibilidades e limitações registradas. |
| FIN11 | Relatório antes/depois cruzando mudanças | Corte por UTC de cada site e versão; cobertura/n declarados, sem atribuição causal isolada de gtag.js ao conjunto da release. |

### 20.2 Protocolo do arquivo de servidor

Preflight lê o arquivo integral e o hash, identifica raiz pública/subdiretório, testa permissão e registra resposta de controle anterior à mudança. Escrita compara hash/revisão, guarda backup fora de área pública e modifica somente o bloco próprio. Não sobrescrever alteração concorrente. Não presumir permissões da raiz pela presença de mod_headers/Options em outro diretório.

Após gravar, sondar home, llms.txt identity/gzip, revalidação e recursos/diretórios afetados. Falha causada pela alteração restaura a versão anterior somente se o arquivo ainda corresponder à escrita da operação; conflito exige preservar as duas evidências e recuperação dirigida. O processo corrente deve tentar restaurar antes de retornar falha. Interrupção/fatal da própria requisição exige o caminho de recuperação por arquivo já preparado e testado, sem depender da página quebrada. Não prometer que qualquer timeout restaura sozinho.

Estado da operação separa gravado, aplicado e verificado. Falta de prova permanece pendente/inconclusiva e contém a ação de retomada. Home 200 servida por cache não basta para provar saúde do PHP/admin: incluir requisição dinâmica controlada. 429/erro pré-existente não é causado automaticamente pela nova regra; comparar controles antes/depois.

### 20.3 Rodada da frota com o mesmo pacote

Ordem informada: **Site-Teste → korvena.net.br → fator3 e korvena.com.br → demais dez**. O inventário confirma os 14 hosts e resolve aliases antes de escrever. A espera entre sites é por aceite; não representa uma release intermediária.

Para cada site: preflight e snapshot de opções/arquivos/versões; preparar exceções de integração necessárias; instalar o mesmo ZIP; aplicar o delta WPSC; invocar aplicação do bloco LLMS com sonda; gravar FAQ/nav/destinatários apenas conforme decisões/dados já disponíveis; verificar redirects com query, schema, privacidade, formulários, capture/avisos e HIT/MISS. Se índices de diretório ainda não foram autorizados, manter essa chave desligada e registrar.

Somente depois remover a exceção correspondente do tema e verificar de novo. Marcar horário UTC por componente e resultado por ID. Falha suspende o avanço aos próximos sites, preserva registros e segue o diagnóstico/isolamento ou a reversão comprovada. Não corrigir o defeito ocultando falha de saúde, regravando listas vazias ou apagando os dados de teste.

### 20.4 Reversão para a 1.13.0

O primeiro recurso operacional é isolar o módulo afetado com controle próprio. Downgrade binário é procedimento distinto, ensaiado no Site-Teste e aplicado com checkpoint. Restaurar backup integral antigo do banco apagaria contatos posteriores; isso não é a estratégia automática.

| Componente | Antes de voltar | Efeito conhecido na 1.13.0 |
|---|---|---|
| Leads, anexos e atendimento novos | Exportar/verificar checkpoint e manter registros/arquivos posteriores; evitar escrita concorrente durante adaptação. | Preservar formatos legíveis; nada é eliminado para simular estado anterior. |
| Colunas, índices e dimensões | Migrações aditivas; ensaiar leitura/escrita antiga. Mudança de chave de agregado exige projeção compatível ou suspensão da consulta afetada. | Não pressupor que schema mais novo é automaticamente compatível; 1.13 não conhece filtro de teste/regra nova. |
| Filas e HTML/JS | Pausar novos lotes, resolver/guardar pendentes com IDs, migrar payloads aceitos ou registrar incompatíveis sem descarte silencioso; purgar HTML/JS relevantes. | JavaScript novo aberto/cached pode enviar campos recusados; comprovar recuperação e evitar perda/retentativa infinita. |
| Opções e política do canal | Snapshot por chave; remover apenas chaves novas incompatíveis do objeto lido pela versão antiga, guardando-as para reaplicação. | Não reconverter f3base_operaveis nem preencher vazio. |
| Redirects | Exportar pares novos e restaurar contrato anterior; restabelecer exceção de tema quando necessária e previamente capturada. | 1.13 não suporta host externo/fragmento/preservar_query novo; o comportamento anterior reaparece. |
| Carregamento por destino | Guardar configuração nova e restaurar consumidores anteriores. | Meta/LinkedIn voltam à agenda antiga; registrar novo corte de medição. |
| nav_id=0 | Restaurar snapshot quando um consumidor antigo precisar; manter navegação efetiva do tema. | 1.13 pode ler 0, mas a rota antiga não o aceita para gravação; não inventar ID para satisfazê-la. |
| Bloco LLMS/servidor | Usar a versão nova para remover/reconciliar partes próprias e verificar antes do downgrade; guardar cópia/hash. | 1.13 não administra essas regras; a volta de cabeçalhos antigos deve ser registrada. |
| Documentação | Proteger previamente as URLs que o ZIP antigo voltará a instalar, por regra gerenciada restrita aos caminhos do plugin na raiz; provar acesso bloqueado e manter essa regra necessária. | Downgrade não pode reabrir os Markdown públicos. Não apagar indiscriminadamente toda proteção junto ao bloco LLMS. |
| Dados de teste e relatórios | Preservar marca nova e snapshot de métricas; documentar quais consultas antigas não a filtram. | Não apresentar relatório 1.13 como livre de testes nem comparável sem ajuste. |

O ensaio FIN10 verifica a combinação concreta de banco, instalador e dados após upgrade, incluindo nova captura. Se uma parte não puder ser adaptada sem perda/exposição, usar isolamento do módulo ou recuperação dirigida; não anunciar downgrade seguro sem essa prova. Reativação da versão nova deve reaplicar migrações de forma idempotente, sem somar agregados ou enviar mensagens novamente.

### 20.5 Preservação das séries e análise da pendência 75

Registrar UTC real por site para Google após interação, pixel, transporte de análise, regra de acessos e filtro de teste. A janela posterior ao gtag.js começa no instante em que essa política entrou e termina na próxima mudança material naquele site. 25–28/09 só pode ser usado se satisfizer esses limites e tiver amostra útil; não fixar datas futuras/contaminadas por conveniência.

Preservar as leituras de acompanhamento já planejadas de 01/10 e 22/10, mas identificar o que cada recorte mede. Após a atualização, o resultado observado é do conjunto de mudanças, com n, cobertura, dias/contextos de teste e intervalo explícitos. Para isolar efeito do transporte, usar experimento controlado da seção 16.5; antes/depois da frota sozinho não demonstra causalidade. Se a amostra restante for insuficiente, declarar insuficiência e acompanhar a nova janela, sem fabricar conclusão.

## 21. O que ainda depende do dono

### 21.1 Decisão de escopo ainda aberta

**Voltar a incluir bloqueio de listagem em toda a raiz por Options -Indexes.** A recomendação informa que esse escopo havia sido retirado em 15/09 e pede confirmação de sua reversão. Não deduzir essa autorização da decisão de não solicitar trabalho à DreamHost. Recomendação técnica: habilitar pelo bloco gerenciado, com prova/restauração. Até a confirmação, implementar/testar o controle com padrão false. Cabeçalhos LLMS e proteção dos próprios documentos continuam no escopo aprovado, sem depender dessa escolha. A decisão muda configuração de aplicação; não exige redesenhar a release.

### 21.2 Dados necessários para concluir itens na frota

| Dado do dono | Para quê | Comportamento enquanto não chega |
|---|---|---|
| E-mail comercial comum ou lista por site | Encaminhar avisos internos aos responsáveis; pendência 55. | Preservar valores atuais; mostrar desconfiguração efetiva; novo site usa admin_email conforme pedido. Nenhum endereço é inventado. |
| Site e localização/screenshot de Leads (contingência) | Localizar o callback responsável e concluir LF2. | Remover referências indevidas do pacote; manter investigação externa identificada. Se não for reproduzido, registrar não reproduzido com inventário, sem declarar remoção comprovada nem apagar o post 133. |

Esses dados não impedem implementar o plugin. O item LF2 só é fechado como correção observada depois de identificar o ambiente; enquanto isso, o release report separa o aceite do menu do pacote da reprodução do submenu externo.

### 21.3 Operações posteriores, sem nova decisão de arquitetura

- Criar/verificar/ativar filtro GA4 exige operador com permissão e execução autorizada; se for necessária uma autorização adicional na ocasião, apresentar propriedades, mudança e efeito irreversível de exclusão antes de executá-la. Até lá, supressão padrão mantém os testes fora do envio externo.
- Alterar anúncio Meta ativo exige identificar anúncio, parâmetros e aprovação da alteração. É homologação externa adicional; contrato/fixtures são entregues completos sem esse gasto/alteração.
- Cadência continua configurável, com valores preservados. Não escolher uma frequência nova para a frota neste plano.
- Atualizar estado da frota/Orientação para registrar a marca sem credencial apenas documenta uma decisão já tomada; não depende de nova confirmação.
- Equipe de implementação prepara preflight, perfis, testes, SQL, changelog e alterações documentais. A identidade dos responsáveis operacionais não deve ser atribuída a pessoas sem indicação.

### 21.4 Estado final e fontes da avaliação

Plano consolidado e pronto para implementação conforme os comportamentos e padrões acima. Nenhuma escrita em sites, campanhas, propriedades GA4, servidor ou código do plugin foi realizada por esta tarefa. A numeração da release, hashes do pacote e evidências de execução só serão preenchidos depois da construção e homologação.

Fontes técnicas adicionais conferidas em 27/09/2026:

- [Google Analytics — filtro de tráfego de desenvolvedor](https://support.google.com/analytics/answer/13296662?hl=en): estados Testing/Active, exclusão futura e permanência do efeito.
- [Google Analytics — DebugView](https://support.google.com/analytics/answer/7201382?hl=en): marca debug_mode e diagnóstico de eventos.
- [Google Analytics — parâmetros de campanhas](https://support.google.com/analytics/answer/10917952?hl=en): utm_term como palavra-chave e dimensões manuais de campanha.
- [Google Analytics Admin API](https://developers.google.com/analytics/devguides/config/admin/v1/rest): catálogo consultado sem recurso equivalente de filtro Developer Traffic; subpropertyEventFilters tem outra finalidade.
- [Apache — mod_expires](https://httpd.apache.org/docs/2.4/mod/mod_expires.html): geração de Expires/max-age e ExpiresActive Off. Permissões da raiz exigem prova no ambiente.
- [Meta — Using the API](https://developers.facebook.com/documentation/ads-commerce/conversions-api/using-the-api): trecho oficial indexado confirma test_event_code para teste. A abertura integral foi bloqueada; payload/resultado Test Events são conferidos no aceite do fornecedor, sem prometer comportamento não verificado aqui.
