const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {spawn}=require('node:child_process');const path=require('node:path');const fs=require('node:fs');
(async()=>{const root=path.resolve(process.env.F3BASE_TEST_WORKSPACE||path.resolve(__dirname,'../../../..'));const site=process.env.F3BASE_SITE;
const log=fs.openSync(path.join(__dirname,'evidencias/http-browser.log'),'w');const php=spawn(path.join(root,'runtime1140/php'),['-S','127.0.0.1:8140','-t',site,path.join(__dirname,'router.php')],{env:process.env,stdio:['ignore',log,log]});
let browser;const checks={},errors=[];
try{
 for(let i=0;i<80;i++){try{let r=await fetch('http://127.0.0.1:8140/wp-login.php');if(r.status===200)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 browser=await chromium.launch({executablePath:path.join(root,'runtime1140/headless/chrome-headless-shell-linux64/chrome-headless-shell'),headless:true,env:{...process.env,LD_LIBRARY_PATH:''},args:['--no-sandbox','--disable-dev-shm-usage']});const context=await browser.newContext();await context.route('**/*',route=>{if(new URL(route.request().url()).hostname!=='127.0.0.1')return route.abort();return route.continue();});
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8140/f3base-teste/');checks.cookie=await page.locator('#estado').innerText()==='Modo de teste ativo — validade de 1 hora';checks.cookie_path=(await context.cookies()).some(x=>x.name==='f3base_teste'&&x.path==='/'&&x.sameSite==='Lax');
 await page.goto('http://127.0.0.1:8140/f3base-teste/?sair=1');checks.cookie_exit=!(await context.cookies()).some(x=>x.name==='f3base_teste');
 await page.goto('http://127.0.0.1:8140/wp-login.php');await page.locator('#user_login').fill('fixture1140');await page.locator('#user_pass').fill('fixture-1140-only');await Promise.all([page.waitForURL('**/wp-admin/**'),page.locator('#wp-submit').click()]);checks.login=page.url().includes('/wp-admin/');
 for(const aba of ['contato','medicao','consentimento','privacidade','conteudo','seo']){await page.goto('http://127.0.0.1:8140/wp-admin/admin.php?page=base-site-core-fator3&subaba='+aba);checks['config_'+aba]=await page.locator('form.f3base-form').count()===1; if(aba==='contato')await page.screenshot({path:path.join(__dirname,'evidencias/config-contato-desktop.png'),fullPage:true});}
 await page.goto('http://127.0.0.1:8140/wp-admin/admin.php?page=f3base-formularios');checks.editor_visible=await page.getByRole('button',{name:'Novo formulário',exact:true}).count()>0;await page.screenshot({path:path.join(__dirname,'evidencias/formularios-desktop.png'),fullPage:true});

 // Isolated authoring exercise. New forms remain inactive; no messages leave the lab.
 await page.getByRole('button',{name:'Novo formulário',exact:true}).click();
 await page.getByLabel('Título',{exact:true}).fill('Fixture UX 1140');await page.getByLabel('Título',{exact:true}).press('Tab');
 checks.new_form_inactive=!(await page.getByLabel('Publicado',{exact:true}).isChecked());
 await page.getByRole('button',{name:'Adicionar campo',exact:true}).click();await page.getByLabel('Rótulo',{exact:true}).fill('Nome de teste');await page.getByLabel('Rótulo',{exact:true}).press('Tab');
 await Promise.all([page.waitForURL('**salvo=1'),page.getByRole('button',{name:'Salvar formulário',exact:true}).click()]);
 checks.saved_prg=page.url().includes('salvo=1')&&await page.getByText('Formulário salvo.',{exact:true}).count()===1;
 checks.editor_id_stable=await page.getByLabel('ID estável',{exact:false}).getAttribute('readonly')!==null;
 const conflict=await context.newPage();await conflict.goto(page.url());await page.getByLabel('Título',{exact:true}).fill('Fixture UX atualizado');await page.getByLabel('Título',{exact:true}).press('Tab');await Promise.all([page.waitForURL('**salvo=1'),page.getByRole('button',{name:'Salvar formulário',exact:true}).click()]);
 await conflict.getByLabel('Título',{exact:true}).fill('Rascunho concorrente');await conflict.getByLabel('Título',{exact:true}).press('Tab');await Promise.all([conflict.waitForLoadState('load'),conflict.getByRole('button',{name:'Salvar formulário',exact:true}).click()]);await conflict.waitForTimeout(300);checks.conflict_draft=await conflict.getByLabel('Título',{exact:true}).inputValue()==='Rascunho concorrente'&&await conflict.getByText('Conflito de revisão. Recarregue e compare.',{exact:true}).count()===1;await conflict.close();
 await page.goto('http://127.0.0.1:8140/wp-admin/admin.php?page=f3base-formularios');await page.getByRole('button',{name:'Duplicar',exact:true}).last().click();checks.duplicate_inactive=!(await page.getByLabel('Publicado',{exact:true}).isChecked());
 // Discard only the unsaved copy in this test.
 page.on('dialog',d=>d.accept());await page.goto('http://127.0.0.1:8140/wp-admin/admin.php?page=f3base-formularios');
 await page.goto('http://127.0.0.1:8140/wp-admin/admin.php?page=f3base-medicao&area=geral');checks.medicao=await page.getByText('Atualizar relatório',{exact:true}).count()>0;await page.screenshot({path:path.join(__dirname,'evidencias/medicao-desktop.png'),fullPage:true});await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(__dirname,'evidencias/medicao-mobile.png'),fullPage:true});
 checks.no_page_errors=errors.length===0;fs.writeFileSync(path.join(__dirname,'evidencias/browser.json'),JSON.stringify({browser:browser.version(),checks,errors},null,2));console.log(JSON.stringify({checks,errors}));if(Object.values(checks).some(x=>!x))process.exitCode=1;
}finally{if(browser)await browser.close();php.kill();fs.closeSync(log);}
})().catch(e=>{console.error(e);process.exitCode=1});
