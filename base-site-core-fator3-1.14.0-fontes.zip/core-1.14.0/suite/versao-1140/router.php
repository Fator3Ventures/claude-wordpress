<?php
$root=getenv('F3BASE_SITE');if(!$root||!is_file($root.'/.f3base-bancada-110')){http_response_code(403);exit;}
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);$real=realpath($root.$path);
$plugin=realpath($root.'/wp-content/plugins/base-site-core-fator3');
if($real&&(str_starts_with($real,$root.'/')||($plugin&&str_starts_with($real,$plugin.'/')))&&is_file($real)){return false;}
require $root.'/index.php';
