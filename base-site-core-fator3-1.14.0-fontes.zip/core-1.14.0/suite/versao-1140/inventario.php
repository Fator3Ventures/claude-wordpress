<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110'))exit(2);require $site.'/wp-load.php';
$tab=[];foreach($wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($wpdb->prefix.'f3base_').'%')) as $t){$tab[substr($t,strlen($wpdb->prefix))]=['colunas'=>$wpdb->get_results($wpdb->prepare('SHOW FULL COLUMNS FROM %i',$t),ARRAY_A),'indices'=>$wpdb->get_results($wpdb->prepare('SHOW INDEX FROM %i',$t),ARRAY_A)];}
$opts=[];foreach(F3Base_Options::catalogo() as $n=>$d){if(empty($d['operavel']))continue;$opts[$n]=array_intersect_key($d,array_flip(['rotulo','descricao','campo','subcampos','padrao']));foreach($opts[$n]['subcampos']??[] as $k=>$v){$opts[$n]['subcampos'][$k]=array_intersect_key($v,array_flip(['rotulo','descricao','impacto','tipo','opcoes','exemplo']));}}
$abi=[];foreach(wp_get_abilities() as $n=>$a){if(str_starts_with($n,'f3base/')){$abi[$n]=['descricao'=>$a->get_description(),'entrada'=>$a->get_input_schema()];}}
echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'schema_leads'=>F3Base_Leads_Repositorio::SCHEMA,'tabelas'=>$tab,'options'=>$opts,'abilities'=>$abi],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
