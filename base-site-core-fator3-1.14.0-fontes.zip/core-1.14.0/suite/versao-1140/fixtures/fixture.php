<?php
/** Install only into a disposable lab's mu-plugins. Never production. */
if (!is_file(ABSPATH.'.f3base-bancada-110')) { return; }
add_filter('pre_wp_mail',static function($pre,$args){$GLOBALS['f3base_fixture_mails'][]=$args;return true;},10,2);
add_filter('pre_http_request',static function($pre,$args,$url){
 if(getenv('F3BASE_LAB_HTTP')==='1' && parse_url($url,PHP_URL_HOST)==='127.0.0.1' && (int)parse_url($url,PHP_URL_PORT)===8140){return $pre;}
 return new WP_Error('fixture_externo_bloqueado','Rede externa bloqueada na bancada.');
},10,3);
add_filter('http_request_host_is_external',static fn($external,$host)=>$host==='127.0.0.1'?true:$external,10,2);
add_filter('http_allowed_safe_ports',static function($ports){$ports[]=8140;return $ports;});
