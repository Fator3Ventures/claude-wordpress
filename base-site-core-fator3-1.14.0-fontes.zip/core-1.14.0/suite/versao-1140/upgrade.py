"""Fresh WordPress databases plus real 1.12/1.13 binaries, sequential processes."""
from pathlib import Path
import os,subprocess,json,shutil,uuid
root=Path(os.environ.get('F3BASE_TEST_WORKSPACE',str(Path(__file__).resolve().parents[4]))); base=Path(os.environ['F3BASE_SITE']);php=root/'runtime1140/php';suite=Path(__file__).parent;out=[]
for ver in ['nova','1.12.0','1.13.0']:
 target=root/'lab1140'/('upgrade-'+ver);target.mkdir(exist_ok=True)
 for p in base.iterdir():
  if p.name in ['wp-config.php','wp-content','llms.txt','robots.txt','.htaccess']:continue
  dest=target/p.name
  if not dest.exists():dest.symlink_to(p,target_is_directory=p.is_dir())
 (target/'.f3base-bancada-110').touch()
 wc=target/'wp-content';(wc/'plugins').mkdir(parents=True,exist_ok=True);(wc/'mu-plugins').mkdir(exist_ok=True)
 shutil.copyfile(base/'wp-content/mu-plugins/fixture.php',wc/'mu-plugins/fixture.php')
 if not (wc/'themes').exists():(wc/'themes').symlink_to(base/'wp-content/themes')
 db='f3base_upgrade_'+ver.replace('.','_')+'_'+uuid.uuid4().hex[:8];config=(base/'wp-config.php').read_text().replace("'f3base1140'",repr(db));(target/'wp-config.php').write_text(config)
 mysql=[str(root/'runtime1140/root/usr/bin/mysql'),'--no-defaults','--protocol=TCP','-h','127.0.0.1','-P','3315','-u','root']
 subprocess.run(mysql+['-e',f'CREATE DATABASE {db} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;'],check=True)
 link=wc/'plugins/base-site-core-fator3'
 def install(version):
  if link.is_symlink():link.unlink()
  elif link.exists():shutil.rmtree(link)
  shutil.copytree(root/'work'/('core-'+version)/'fontes/plugin',link)
 install('1.14.0' if ver=='nova' else ver)
 env=os.environ|{'F3BASE_SITE':str(target),'F3BASE_ORIGEM':ver}
 for step in ['instalar','semear','atualizar','repetir','reverter','retornar']:
  if step=='atualizar':install('1.14.0')
  if step=='reverter':install('1.13.0')
  if step=='retornar':install('1.14.0')
  p=subprocess.run([str(php),str(suite/'upgrade.php'),step],env=env,capture_output=True,text=True)
  try:j=json.loads(p.stdout)
  except Exception:j={'stdout':p.stdout[-2500:],'stderr':p.stderr[-1500:]}
  out.append({'origem':ver,'passo':step,'exit':p.returncode,'resultado':j})
  print(ver,step,p.returncode,j.get('falhas',j.get('codigo','')))
  if p.returncode:break
(suite/'evidencias/upgrade.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(any(r['exit'] for r in out))
