from pathlib import Path
import asyncio,os,subprocess,json
S=Path(__file__).parent;R=S.parents[3];received=[]
async def smtp(reader,writer):
 writer.write(b'220 fixture SMTP\r\n');await writer.drain();data=False;body=[]
 while line:=await reader.readline():
  if data:
   if line==b'.\r\n':received.append(b''.join(body).decode(errors='replace'));writer.write(b'250 accepted\r\n');data=False;body=[]
   else:body.append(line)
  else:
   cmd=line.decode(errors='replace').strip().upper()
   if cmd.startswith(('EHLO','HELO')):writer.write(b'250-fixture\r\n250 8BITMIME\r\n')
   elif cmd=='DATA':data=True;writer.write(b'354 end with dot\r\n')
   elif cmd=='QUIT':writer.write(b'221 bye\r\n');await writer.drain();break
   else:writer.write(b'250 ok\r\n')
  await writer.drain()
 writer.close()
async def main():
 server=await asyncio.start_server(smtp,'127.0.0.1',8025)
 async with server:
  p=await asyncio.create_subprocess_exec(str(R/'runtime1140/php'),str(S/'smtp.php'),env=os.environ|{'F3BASE_SMTP_SINK':'1'},stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE);stdout,stderr=await p.communicate()
 result=json.loads(stdout);result['checks']['duas_mensagens_reais']=len(received)==2;result['checks']['marca_smtp']=any('X-F3Base-Teste: 1' in x and '[TESTE]' in x for x in received);result['checks']['caixa_teste_apenas']=sum('To: qa@example.test' in x for x in received)==1
 result['smtp']={'servidor':'127.0.0.1:8025','mensagens_aceitas':len(received),'fora_da_bancada':False,'limite':'Aceite SMTP local; não prova caixa comercial/fornecedor'};(S/'evidencias/smtp.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(result);return p.returncode or int(not all(result['checks'].values()))
raise SystemExit(asyncio.run(main()))
