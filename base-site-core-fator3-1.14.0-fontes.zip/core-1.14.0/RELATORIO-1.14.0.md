# Release 1.14.0 — implementação e validação

Instalador gerado e instalado no Site-Teste. Fontes e documentação correspondem ao mesmo pacote. A implantação na frota de produção não foi executada nesta entrega.

**Instalador:** `base-site-core-fator3-1.14.0.zip` — 167 arquivos; 798.975 bytes.  
**SHA-256:** `c9338c2fe8b55fe80ddfcafbd149db43fca99cbe68085b85b317bc4ee918f479`.

## Entregue

- Configurações divididas em seis sub-abas, ajuda com vantagens/limitações/exemplos, controles adequados e preservação de falso, zero e listas vazias. E-mail administrativo e Arquivo gerado são padrões para campos ausentes.
- Medição em cinco áreas, relatórios integrados, filtros de testes e anúncios, comparação, CSV completo e documentação de cálculos. Contatos concentra leads, formulários e materiais.
- Editor por formulário, IDs estáveis, criação/duplicação inativas, salvamento com redirecionamento e conflito que preserva o rascunho. Rapidez isolada não classifica formulário como spam.
- Identificação de testes por página/cookie ou cabeçalho, propagação explícita no MCP, classe preservada nas filas e supressão padrão de mensagens/conversões externas de teste.
- Atribuição comum a clique, formulário e análise: plataforma/conta/campanha/grupo/anúncio, IDs como strings, primeiro/último toque, limites de consentimento e cobertura explícita.
- Scripts com estratégia adiada coerente; transporte de análise com confirmações individuais, idempotência concorrente, renovação compartilhada de token e diagnóstico de 503. Web Vitals mantém a biblioteca vendorizada e a carga após load.
- Publicação LLMS por gerações, atualização limitada/retomável, regras de cabeçalhos com backup/revisão/sonda/recuperação; correções de CTA, redirects, schema e consentimento.
- Documentação completa dentro do plugin, protegida por HTTP e disponível ao agente por arquivo/canal autenticado. Dicionário, contrato JSON, cinco consultas SQL e receitas de cruzamento com publicidade incluídos.

## Provas realizadas

Bancada: WordPress 7.1; PHP 8.3.6 de 64 bits; MySQL 8.0.46/InnoDB; Apache 2.4.58; Chromium 154.0.8037.57. Instalação nova e atualização dos binários reais 1.12.0 e 1.13.0 foram exercitadas, incluindo repetição, interrupção e preservação de dados. O ensaio de concorrência usou 12 processos PHP e falhas induzidas de banco. Os testes de interface incluíram navegador, largura móvel, criação/edição, conflito e CSV. O SMTP local recebeu mensagens reais de PHPMailer; não houve envio para caixas externas.

O detalhamento de conjuntos e quantidades está no `docs/VALIDACAO.md` instalado. A suite inclui evidências detalhadas conservadas e `fechamento-observado.json` com os resumos das execuções finais. Não somar linhas/etapas como se fossem casos independentes. Falhas históricas de fixture estão identificadas e não representam o gate final.

Site-Teste: WordPress 7.1.2, PHP 8.3.30, MySQL 8/InnoDB, WP Super Cache 3.1.3, Yoast SEO 28.5, WP MCP 0.12.1 e tema F3 Base 1.6.7. A migração registrou origem 1.13.0 e conclusão; os valores anteriores foram preservados. A leitura de LLMS acrescenta o novo campo padrão `cabecalhos_servidor=true`. A gestão continua em Todas, com lista vazia preservada.

Foram aplicados somente o delta necessário do WP Super Cache e o bloco próprio de cabeçalhos LLMS, com revisão, backup e controle dinâmico antes/depois. Listagem da raiz continua desligada. Resultado: HIT comprovado, cabeçalhos públicos verificados e acesso direto ao arquivo PHP de cache com HTTP 200/corpo vazio. LLMS passou GET/HEAD, UTF-8, gzip/identity e revalidação 304; há nove representações disponíveis. A proteção dos documentos respondeu 404 sem entregar os arquivos, enquanto o asset de controle respondeu 200. Leitura autenticada do contrato confirmou hash e paginação.

Na captura sintética pública, o banco confirmou uma linha de análise após duas entregas do mesmo evento. O clique para `/contato/` foi classificado como `contato_cta`, com sessão, navegação, correlação, post_id=14 e anúncio preservados. Aviso e resposta constam como suprimidos por teste. Sob a campanha sintética: Sem testes retorna zero registros; Somente testes e Todos retornam um clique, uma sessão e um pareamento. Isso demonstra a exclusão reversível sem usar IP ou horário.

## Instalação e operação por site

1. Fazer snapshot das opções/arquivos e verificar que a origem está concluída em 1.12.0 ou 1.13.0. Para site novo, seguir a instalação normal.
2. Instalar o ZIP. Conferir `f3base/saude-ler`, política de gestão e configuração efetiva. Valores existentes não devem ser substituídos pelos novos padrões.
3. Mesclar os requisitos do WP Super Cache na configuração do próprio cache, preservando as demais entradas. Conferir as exclusões, incluindo `/f3base-teste/`, e os parâmetros de atribuição. Executar atualização/verificação pública do cache.
4. Consultar e aplicar o bloco LLMS por `f3base/servidor-aplicar` com revisão atual. A operação guarda backup privado e prepara recuperação CLI. A aplicação explícita é separada da instalação.
5. Conferir formulários/contatos, captura marcada, docs, redirects e schema. Somente depois prosseguir para o site seguinte. Não remover compensações do tema sem comparação no site correspondente.

Para os agentes: visitar `/f3base-teste/` em cada site/navegador de trabalho; renovar ao expirar uma hora e sair em `?sair=1`. Scripts usam `X-F3Base-Teste: 1` em cada requisição. O cookie não autentica nem concede privilégios. Chamadas MCP e navegador são contextos distintos. A captura de visitantes normais não faz uma chamada extra para descobrir a marca.

## Limites que permanecem explícitos

- Recepção e filtros em GA4/Ads/GTM/Meta/LinkedIn, caixas comerciais e publicador Indexe não foram certificados nas contas reais. No Site-Teste não há IDs de fornecedor configurados; a validação do pacote não autoriza criar anúncios ou liberar destinos externos.
- Não foram alterados os sites de produção, nem retiradas compensações da Conselar/Praxis ou de outros temas. Essas conferências pertencem à implantação por site.
- A causa histórica dos cinco 503 permanece inconclusiva. O teste induzido comprova o tratamento da release; não prova retrospectivamente aquele incidente. Não há promessa de nota PageSpeed nem de ganho causal isolado.
- Retorno binário à 1.13.0 passou com leitura/nova captura na base originalmente concluída em 1.13.0. Nas bases nova em 1.14.0 ou diretamente atualizada da 1.12.0, o instalador antigo recusou o estado. Nesses casos, usar isolamento do módulo/recuperação dirigida; não fabricar marcadores nem restaurar banco antigo sobre capturas novas. Filas, redirects externos e relatórios antigos exigem os cuidados do guia instalado.
- CRM/Pipedrive, webhooks comerciais, leads nativos das plataformas e custos/vendas permanecem fora do escopo. Nenhuma estimativa de ROAS é apresentada sem esses dados.

## Rastreabilidade do plano

A tabela liga cada ID à implementação e às evidências relacionadas. “Pacote” significa revisão do comportamento entregue e provas de bancada associadas; não declara que cada variação combinatória da linha foi repetida em todos os sites. “Operação externa” identifica a conferência dependente de site/conta que não é substituída por fixture.

| ID | Escopo | Evidência relacionada / limite |
|---|---|---|
| E1 | Instalação nova com `admin_email` válido | Pacote — dados, upgrade, SMTP. |
| E2 | Atualizar 1.12.0 e 1.13.0 com destinatário próprio, vazio explícito ou chave ausente | Pacote — dados, upgrade, SMTP. |
| E3 | WordPress tem mudança de e-mail pendente | Pacote — dados, upgrade, SMTP. |
| E4 | Usar ação de e-mail administrativo | Pacote — dados, upgrade, SMTP. |
| E5 | Clique e formulários com lista própria, ausente e vazia | Pacote — dados, upgrade, SMTP. |
| I1 | Opção LLMS inteira ausente e grupo existente sem `entrega` | Pacote — LLMS, HTTP, upgrade, Site-Teste. |
| I2 | Modo `dinamica` explicitamente salvo | Pacote — LLMS, HTTP, upgrade, Site-Teste. |
| I3 | Site público elegível e diretório gravável | Pacote — LLMS, HTTP, upgrade, Site-Teste. |
| I4 | Diretório não gravável, arquivo externo, site privado ou publicador concorrente | Pacote — LLMS, HTTP, upgrade, Site-Teste. |
| I5 | Alteração de conteúdo e execução do cron | Pacote — LLMS, HTTP, upgrade, Site-Teste. |
| A1 | Abrir cada sub-aba | Pacote — interface, navegador, upgrade. |
| A2 | Salvar sub-aba com checkbox desmarcado e lista vazia | Pacote — interface, navegador, upgrade. |
| A3 | Erro de validação ou revisão concorrente | Pacote — interface, navegador, upgrade. |
| A4 | Política Todas, Selecionadas e Nenhuma | Pacote — interface, navegador, upgrade. |
| A5 | Teclado, tela estreita e JavaScript desativado | Pacote — interface, navegador, upgrade. |
| A6 | Alterações não salvas com JavaScript | Pacote — interface, navegador, upgrade. |
| H1 | Inventário completo dos campos exibíveis | Pacote — catálogo instalado, interface. |
| H2 | Conteúdo da ajuda contra código e documentação | Pacote — catálogo instalado, interface. |
| D1 | Instalar o ZIP em WordPress limpo | Pacote — documentos, leitura autenticada, proteção HTTP. |
| S1 | Formulário válido enviado em menos de três segundos, inclusive autofill | Pacote — dados, formulários, confirmação HTTP. |
| S2 | Honeypot preenchido, token inválido e quota excedida | Pacote — dados, formulários, confirmação HTTP. |
| S3 | Sem JavaScript, HTML em cache, formulário curto e token renovado | Pacote — dados, formulários, confirmação HTTP. |
| S4 | Atualização com contatos antigos suspeitos por tempo | Pacote — dados, formulários, confirmação HTTP. |
| T1 | Abrir /f3base-teste/ sem login ou MCP | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T2 | MCP e navegador em redes diferentes | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T3 | Agente e visitante real no mesmo IP e horário | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T4 | Script envia X-F3Base-Teste: 1 sem ativação | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T5 | Cookie ausente/1/outro valor; cabeçalho ausente/0/1/inválido | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T6 | Cookie bloqueado, renovação, saída e expiração | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T7 | Página pública servida por HIT | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T8 | Mudança de modo entre evento e descarga da fila, abas e bfcache | Fila e retorno/pageshow controlados; não certifica todos os navegadores/bfcache. |
| T9 | Clique, formulário sem sessão, funil, campanha, vital e download | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T10 | Sem testes / Somente testes / Todos | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T11 | Agregados, comparação e limites de consulta | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T12 | Cookie removido depois da coleta | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T13 | Tag direta, GTM, GA4 marcado, CAPI e retentativa durante teste | Políticas locais validadas; recepção/filtro do fornecedor: operação externa. |
| T14 | E-mails de contatos de teste | PHPMailer e receptor SMTP local; caixa comercial: operação externa. |
| T15 | Log bruto sem marca de teste | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T16 | Instalação nova e atualização 1.12.0/1.13.0 com retomada | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T17 | Documentação instalada e fluxo do agente | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T18 | Visitante normal sem a marca | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T19 | Cache público antes/depois | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| T20 | Medição de execução e coleta | Pacote — dados, transporte, MCP, SMTP, navegador, Site-Teste. |
| M1 | Endpoints MCP efetivos e aliases, URL direta, rest_route e instalação em subdiretório | Pacote — MCP, dados, transporte, classificação de acessos. |
| M2 | Lista de exclusões personalizada ou explicitamente vazia; erros MCP e rota pública de nome semelhante | Pacote — MCP, dados, transporte, classificação de acessos. |
| M3 | Ferramenta dispara teste HTTP, inclusive redirecionamento | Pacote — MCP, dados, transporte, classificação de acessos. |
| M4 | Ability recebe contexto_teste true/false/ausente/inválido, com e sem cabeçalho | Pacote — MCP, dados, transporte, classificação de acessos. |
| M5 | Lead real via integração e lead de teste sem sessão de navegador | Pacote — MCP, dados, transporte, classificação de acessos. |
| M6 | Teste enfileirado/retentado após o fim da chamada MCP; navegador separado | Pacote — MCP, dados, transporte, classificação de acessos. |
| M7 | Logs com/sem marcador e páginas em HIT | Pacote — MCP, dados, transporte, classificação de acessos. |
| P1 | Dois anúncios da mesma campanha levam ao mesmo formulário | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| P2 | Anúncios com mesmo nome, anúncio renomeado e IDs maiores que a precisão numérica do JavaScript | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| P3 | Clique, formulário e análise; parâmetros dinâmicos expandidos e ausentes | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| P4 | Redirecionamento, cache HIT, navegação interna, volta direta, revogação e expiração | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| P5 | Guia de cruzamento com lead nativo sem visita ao site | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| P6 | Fonte externa e dados locais usados pelo agente | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| P7 | Conta Meta entrega em Instagram e Facebook; LinkedIn com entidades renomeadas; formato Google com granularidade limitada | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| P8 | Mesma janela de relatório com testes, custos ausentes e origem parcial | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| P9 | Pacote, catálogo e documentação finais | Pacote — dados, relatórios, contrato de atribuição, Site-Teste. |
| U1 | Inventário das visões atuais e novas | Pacote — interface, navegador, documentos, CSV. |
| U2 | Abrir Visão geral e cada área | Pacote — interface, navegador, documentos, CSV. |
| U3 | Aplicar período/segmento, abrir anúncio e voltar | Pacote — interface, navegador, documentos, CSV. |
| U4 | Navegação direta, teclado, tela estreita e JavaScript desligado | Pacote — interface, navegador, documentos, CSV. |
| U5 | Coleta desativada, vazia, expirada ou incompleta | Pacote — interface, navegador, documentos, CSV. |
| U6 | Indicador, tabela, CSV e ability sob o mesmo recorte | Pacote — interface, navegador, documentos, CSV. |
| U7 | Atualizar relatório versus coletar logs | Pacote — interface, navegador, documentos, CSV. |
| DOC1 | Instalar o ZIP e ler apenas o plugin instalado | Pacote — documentos, SQL, dicionário, receitas de cruzamento. |
| DOC2 | Ler por arquivo e por documentacao-ler, inclusive além de 200 linhas | Pacote — documentos, SQL, dicionário, receitas de cruzamento. |
| DOC3 | Schema e contratos efetivos comparados com a documentação | Pacote — documentos, SQL, dicionário, receitas de cruzamento. |
| DOC4 | Reproduzir por SQL um indicador do painel/ability | Pacote — documentos, SQL, dicionário, receitas de cruzamento. |
| DOC5 | Cruzar múltiplos eventos e contatos com gasto por anúncio | Receita documentada; sem importação de investimento ou custos reais. |
| DOC6 | Receita do agente reúne dados locais e fonte externa | Pacote — documentos, SQL, dicionário, receitas de cruzamento. |
| DOC7 | Prefixo diferente de wp_, contas distintas, IDs longos, fuso/moeda/unidade divergentes | Pacote — documentos, SQL, dicionário, receitas de cruzamento. |
| DOC8 | Navegação ponta a ponta e dados externos fictícios para receita | Dados sintéticos explícitos; sem integração comercial. |
| LF1 | Instalação nova e atualização da base suportada | Pacote — interface, navegador, CSV, dados. |
| LF2 | Ambiente que apresentava o submenu de contingência | Submenu não reproduzido no pacote 1.13.0 analisado; menu final centralizado e sem contingência. |
| LF3 | Filtros fechados, busca, anúncio, teste, lixeira e datas | Pacote — interface, navegador, CSV, dados. |
| LF4 | Lista recente, paginação, abertura e retorno | Pacote — interface, navegador, CSV, dados. |
| LF5 | CSV de uma lista filtrada com várias páginas | Pacote — interface, navegador, CSV, dados. |
| LF6 | Detalhe com/sem sessão, anexo, origem publicitária e campo histórico | Pacote — interface, navegador, CSV, dados. |
| LF7 | Alterar atendimento, spam, captura e lixeira | Pacote — interface, navegador, CSV, dados. |
| LF8 | Criar/duplicar/editar/inativar formulário | Pacote — interface, navegador, CSV, dados. |
| LF9 | Destinatário herdado, próprio e vazio; arquivo sem limite | Pacote — interface, navegador, CSV, dados. |
| LF10 | GUI/JSON, mudança de tipo, prévia e erro de validação | Pacote — interface, navegador, CSV, dados. |
| LF11 | Operador e agente alteram definições concorrentemente | Pacote — interface, navegador, CSV, dados. |
| LF12 | Teclado, tela estreita, permissão parcial e JavaScript ausente/falho | Pacote — interface, navegador, CSV, dados. |
| BK09 | `cache.evidencia` sem duplicação semântica de tokens; sameAs com origem e resultado HTTP discriminados. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK17 | CRM/webhooks adiados; pendências funcionais cobertas por 25, 32 e 34. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK25 | Sem `label for` inválido, reset somente após confirmação e robots coerente. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK30 | Redirect preserva query por padrão, com descarte por par. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK31 | Meta e LinkedIn seguem política por destino com fila, interação/teto e consentimento. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK32 | Mesmo serviço e contrato de origem no clique e formulário. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK34 | Destino explícito para gatilho sem href. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK35 | Bloco gerenciado no servidor e prova HTTP por validador válido. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK36 | Geração anterior utilizável até troca coerente; tarefa llms retomável. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK37 | Renovação preventiva de token e diagnóstico do TTL. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK38 | Comparar formas de adiar o transporte antes de fixar a política. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK39 | Retirar Person de usuário sem referência legítima na autoria institucional. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK40 | `worksFor` referencia a Organization efetiva. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK41 | Oferta estruturada opcional, fiel ao preço exibido. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK42 | Sem vínculo explícito, navegação de blocos e clássica distinguíveis. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK43 | Carimbo do servidor alcança links em contêiner marcado. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK44 | Três controles por site: usuários REST, XML-RPC e mensagem de login. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK45 | CSS mínimo com variáveis, herança e fallback de contraste. | Temas sintéticos claro/escuro e mobile; Conselar: operação externa. |
| BK46 | Leitura com padrão, origem e chaves herdadas; perfil versionado no pacote. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK47 | Scripts sem bloqueio desnecessário, dependências e primeiro evento preservados. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK48 | Explicar conteúdo, destino, consulta e ausência de aviso da cadência atual. | Pacote — LLMS/HTTP, SEO/CTA, transporte, interface, bordas conforme o item. |
| BK49 | Ler summary salvo, ligar FAQ à página e padrão true. | Bloco FAQ/schema em bancada; páginas específicas da Praxis: operação externa. |
| FT-P1 | Tema clássico primary, ID 92 ambíguo e gravação de 0 | Pacote — interface, HTTP, SEO/CTA, bordas. |
| FT-P2 | ZIP novo/atualização, plugin ativo/inativo, HTTP anônimo e agente autenticado | Pacote — interface, HTTP, SEO/CTA, bordas. |
| FT-P3 | Scrapy, UA URL/vazio, navegadores, desconhecidos, periodicidade e NAT | Pacote — interface, HTTP, SEO/CTA, bordas. |
| FT-P4 | Interno com âncora, HTTPS permitido/proibido, query e redirect em cadeia | Pacote — interface, HTTP, SEO/CTA, bordas. |
| FT-P5 | Blocos, menu clássico, Elementor e CTA flutuante declarado | Pacote — interface, HTTP, SEO/CTA, bordas. |
| AN-DEFER | Cadeia consentimento → tracking → análise e consumidores adicionais | Pacote — concorrência MySQL, transporte, Site-Teste. |
| AN-503A | Dois pedidos simultâneos para o mesmo evento/hash | Pacote — concorrência MySQL, transporte, Site-Teste. |
| AN-503B | Banco indisponível/erro real, colisão incompatível e atualização de vital | Pacote — concorrência MySQL, transporte, Site-Teste. |
| AN-503C | Lote parcialmente salvo e resposta perdida/não JSON | Pacote — concorrência MySQL, transporte, Site-Teste. |
| AN-503D | Testes marcados e investigação dos cinco relatos | Diagnóstico implementado; causa histórica dos cinco relatos inconclusiva. |
| FIN1 | Instalação nova, upgrade 1.12/1.13, repetição e interrupção | Pacote — upgrade, HTTP, dados, bordas, Site-Teste. |
| FIN2 | Configuração GA4 suprimir/marcar e filtro Testing/Active | Supressão e configuração local; Testing/Active em conta real: operação externa. |
| FIN3 | Query do molde v1, WPSC e formulário | Pacote — upgrade, HTTP, dados, bordas, Site-Teste. |
| FIN4 | Aplicar/remover bloco da raiz e falha de sonda | Pacote — upgrade, HTTP, dados, bordas, Site-Teste. |
| FIN5 | Options -Indexes ligado/desligado em teste | Ligado/desligado em Apache de bancada; padrão false preservado no Site-Teste. |
| FIN6 | ZIP/docs atualizado e plugin desativado | Pacote — upgrade, HTTP, dados, bordas, Site-Teste. |
| FIN7 | Slug longo, UA desconhecido, Scrapy, repetição e reprocessamento | Pacote — upgrade, HTTP, dados, bordas, Site-Teste. |
| FIN8 | CTA conteúdo/menu/Elementor e comparação antes/depois | Pacote — upgrade, HTTP, dados, bordas, Site-Teste. |
| FIN9 | SMTP/caixa de teste e publicador externo | SMTP local e MCP ativo; Indexe/caixa comercial: operação externa. |
| FIN10 | Ensaio de reversão para 1.13.0 após gerar dados novos | Retorno testado apenas na combinação de origem 1.13.0; demais bloqueios documentados. |
| FIN11 | Relatório antes/depois cruzando mudanças | Corte UTC do Site-Teste registrado, sem estudo causal de produção. |

## Artefatos

Instalador; fontes; manifesto por arquivo; checksums dos arquivos distribuídos; este relatório. O backup privado da instalação anterior foi preservado separadamente e não está dentro do pacote público de fontes.
