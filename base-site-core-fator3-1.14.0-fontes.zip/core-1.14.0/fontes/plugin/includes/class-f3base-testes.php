<?php
/** Marca declarativa de teste. Não concede permissões nem altera consentimento. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Testes {
    const COOKIE = 'f3base_teste';
    const CLASSES = array('nao_marcado', 'teste');
    const SEGMENTOS = array('sem_testes', 'somente_testes', 'todos');
    public static function padrao(): array {
        return array('habilitado'=>true, 'excluir_relatorios'=>true,
            'destinos'=>array('gtm'=>'suprimir','ga4'=>'suprimir','google_ads'=>'suprimir','meta'=>'suprimir','linkedin'=>'suprimir','capi'=>'suprimir','email'=>'suprimir'),
            'ga4_ids'=>array(), 'gtm_homologado'=>false, 'capi_test_event_code'=>'', 'email_destinatarios'=>array());
    }
    public static function config(): array {
        $v=get_option('f3base_testes',array());$v=is_array($v)?$v:array();$p=self::padrao();
        $v['destinos']=array_replace($p['destinos'],is_array($v['destinos']??null)?$v['destinos']:array());
        return array_replace($p,$v);
    }
    public static function iniciar(): void { add_action('template_redirect',array(__CLASS__,'pagina'),-1000); }
    /** Evento explícito prevalece sobre cookie; cabeçalho explícito exige concordância. */
    public static function resolver(array $entrada=array(), ?WP_REST_Request $req=null): array {
        $h=$req?($req->get_header('x-f3base-teste')??''):($_SERVER['HTTP_X_F3BASE_TESTE']??'');
        if(!is_string($h)||!in_array($h,array('','0','1'),true)){return array('ok'=>false,'codigo'=>'cabecalho_teste_invalido');}
        if(array_key_exists('contexto_teste',$entrada)&&!is_bool($entrada['contexto_teste'])){return array('ok'=>false,'codigo'=>'contexto_teste_invalido');}
        $explicit=array_key_exists('contexto_teste',$entrada);
        if($explicit&&$h!==''&&$entrada['contexto_teste']!==($h==='1')){return array('ok'=>false,'codigo'=>'contexto_teste_conflitante');}
        $test=$explicit?$entrada['contexto_teste']:($h!==''?$h==='1':($_COOKIE[self::COOKIE]??'')==='1');
        if(!self::config()['habilitado']&&!$explicit&&$h===''){$test=false;}
        return array('ok'=>true,'contexto_teste'=>$test,'classe_trafego'=>$test?'teste':'nao_marcado');
    }
    /** Mesma origem inclui esquema e porta. Nunca transmite a marca a fornecedores. */
    public static function origem_propria(string $url): bool {
        $a=wp_parse_url($url);$b=wp_parse_url(home_url('/'));
        if(!is_array($a)||!is_array($b)||isset($a['user'])||isset($a['pass'])){return false;}
        foreach(array(&$a,&$b) as &$p){$p['scheme']=strtolower($p['scheme']??'');$p['host']=strtolower($p['host']??'');$p['port']=$p['port']??($p['scheme']==='https'?443:80);}unset($p);
        return in_array($a['scheme'],array('http','https'),true)&&$a['scheme']===$b['scheme']&&$a['host']===$b['host']&&$a['port']===$b['port'];
    }
    public static function cabecalhos(string $url,bool $teste): array {
        return self::origem_propria($url)?array('X-F3Base-Teste'=>$teste?'1':'0'):array();
    }
    /** O catálogo expõe o argumento somente nas operações públicas inventariadas. */
    public static function ability(string $nome,array $args): array {
        if(!in_array($nome,array('f3base/publicacao-verificar','f3base/schema-verificar','f3base/llms-arquivo','f3base/redirects-verificar','f3base/config-core-verificar','f3base/servidor-aplicar'),true)){return $args;}
        $args['input_schema']['properties']['contexto_teste']=array('type'=>'boolean','description'=>'Marca declarativa desta operação; propaga somente ao próprio site e às suas retentativas. Não concede permissões.');
        $callback=$args['execute_callback'];
        $args['execute_callback']=static function($v=null)use($callback){
            $v=is_array($v)?$v:array();$marca=self::resolver($v);
            if(!$marca['ok']){return new WP_Error($marca['codigo'],'Contexto de teste inválido ou conflitante.',array('status'=>400));}
            $v['contexto_teste']=$marca['contexto_teste'];$r=$callback($v);
            if(is_array($r)){$r['contexto_operacao']=$marca;}
            return $r;
        };
        return $args;
    }
    public static function segmento(?string $v=null): string {
        if($v===null||$v===''){return self::config()['excluir_relatorios']?'sem_testes':'todos';}
        if(!in_array($v,self::SEGMENTOS,true)){throw new InvalidArgumentException('segmento_invalido');}
        return $v;
    }
    /** Fragmento SQL constante; nome de coluna apenas interno. */
    public static function sql(?string $segmento=null,string $coluna='classe_trafego'): string {
        if(!preg_match('/^[a-z_][a-z0-9_.]*$/D',$coluna)){throw new InvalidArgumentException('coluna_invalida');}
        $s=self::segmento($segmento);
        return $s==='todos'?'':" AND {$coluna}='".($s==='somente_testes'?'teste':'nao_marcado')."'";
    }
    public static function politica(string $destino,string $classe): string {
        if($classe!=='teste'){return 'normal';}
        $c=self::config();$p=$c['destinos'][$destino]??'suprimir';
        if($p!=='marcar'){return 'suprimir';}
        if($destino==='gtm'&&!empty($c['gtm_homologado'])){return 'marcar';}
        if($destino==='ga4'&&!empty($c['ga4_ids'])){return 'marcar';}
        if($destino==='capi'&&preg_match('/^[A-Za-z0-9_-]{1,100}$/D',$c['capi_test_event_code'])){return 'marcar';}
        if($destino==='email'&&array_filter($c['email_destinatarios'],'is_email')){return 'marcar';}
        // Pixel/LinkedIn/Ads não têm destino de teste homologado neste contrato.
        return 'suprimir';
    }
    public static function pagina(): void {
        $path=wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']??''),PHP_URL_PATH);
        $base=wp_parse_url(home_url('/f3base-teste/'),PHP_URL_PATH);
        if(rtrim((string)$path,'/')!==rtrim((string)$base,'/')){return;}
        if(!defined('DONOTCACHEPAGE')){define('DONOTCACHEPAGE',true);}
        status_header(200);nocache_headers();header('Cache-Control: private, no-store, max-age=0');header('X-Robots-Tag: noindex, nofollow');
        header('Content-Type: text/html; charset=UTF-8');header("Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'");
        $sair=isset($_GET['sair']);$ativo=!$sair&&self::config()['habilitado'];$cookiepath=trailingslashit((string)(wp_parse_url(home_url('/'),PHP_URL_PATH)?:'/'));
        setcookie(self::COOKIE,$ativo?'1':'',array('expires'=>$ativo?time()+3600:time()-3600,'path'=>$cookiepath,'secure'=>is_ssl(),'httponly'=>false,'samesite'=>'Lax'));
        echo '<!doctype html><html lang="pt-BR"><meta name="viewport" content="width=device-width"><title>F3 Base — teste</title><body><main><h1>Modo de teste</h1><p id="estado">'.($ativo?'Verificando o cookie…':'Modo de teste desativado.').'</p><p>Use este mesmo navegador. Renove após uma hora ou ao trocar de site/perfil.</p><p><a href="'.esc_url(home_url('/')).'">Abrir site</a> · <a href="'.esc_url(home_url('/f3base-teste/?sair=1')).'">Sair do modo de teste</a></p></main>';
        if($ativo){echo '<script>document.getElementById("estado").textContent=document.cookie.split(";").some(function(v){return v.trim()==="f3base_teste=1";})?"Modo de teste ativo — validade de 1 hora":"Ativação não ocorreu: o navegador não aceitou o cookie.";</script>';}
        echo '</body></html>';exit;
    }
    public static function seletor(string $valor): void {
        echo '<label>Tráfego <select name="segmento">';foreach(array('sem_testes'=>'Sem testes','somente_testes'=>'Somente testes','todos'=>'Todos') as $k=>$v){echo '<option value="'.esc_attr($k).'" '.selected($valor,$k,false).'>'.esc_html($v).'</option>'; }echo '</select></label> ';
    }
}
