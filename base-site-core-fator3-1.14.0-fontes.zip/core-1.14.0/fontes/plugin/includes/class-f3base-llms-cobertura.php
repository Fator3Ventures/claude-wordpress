<?php
/** Bounded, resumable generations. A published generation survives ordinary cache invalidation. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Llms_Cobertura {
    const EVENTO='f3base_llms_converter_lote';
    const ESTADO='f3base_llms_geracoes';
    const PUBLICADA='f3base_llms_geracao_publicada';
    private static bool $executando=false;
    private static bool $salvamento=false;
    public static function iniciar(): void {
        add_action(self::EVENTO,F3Base_Operacao::callback(self::EVENTO,static fn()=>self::executar(5)));
        add_action('save_post',static function($id):void { if(!wp_is_post_revision($id)&&!wp_is_post_autosave($id)){self::agendar();self::$salvamento=true;} },200);
        add_action('updated_option',static function($n):void { if(in_array($n,array('f3base_llms','permalink_structure','blog_public'),true)){self::agendar();self::$salvamento=true;} },200);
        add_action('shutdown',static function():void { if(self::$salvamento&&!self::$executando){self::executar(1);if(wp_next_scheduled(self::EVENTO)){spawn_cron();}} });
        add_action('init',array(__CLASS__,'agendar'),99);
    }
    private static function identidade(array $i): string { return hash('sha256',wp_json_encode(array($i['id']??0,$i['url']??''))); }
    public static function chave(array $i): string {
        return 'f3base_llms_item_'.hash('sha256',wp_json_encode(array(F3BASE_PLUGIN_VERSAO,$i['id']??0,$i['url']??'',$i['conteudo']??'',F3Base_Options::ler('f3base_llms')['blocos_interface']??array())));
    }
    private static function elegivel(array $i): bool {
        $id=(int)($i['id']??0);if(!$id){return true;}$p=get_post($id);
        return $p&&is_post_publicly_viewable($p)&&!$p->post_password&&!F3Base_Modulo_Noindex_Honrado::post_e_noindex($id);
    }
    /** Read only: current public eligibility prevails over the snapshot. */
    public static function publicados(array $atuais): array {
        $c=F3Base_Options::ler('f3base_llms');if(empty($c['markdown'])&&empty($c['full'])){return $atuais;}
        $g=(array)get_option(self::PUBLICADA,array());if(empty($g['itens'])){return array();}
        $permitidos=array();foreach($atuais as $i){if(self::elegivel($i)){$permitidos[self::identidade($i)]=true;}}
        return array_values(array_filter($g['itens'],static fn($i)=>isset($permitidos[self::identidade($i)])&&self::elegivel($i)));
    }
    public static function item(array $i,bool $converter=false): array {
        if(!self::elegivel($i)){return array('completo'=>false,'erros'=>array('conteudo_nao_publico'),'texto'=>'');}
        if(!$converter){
            if(isset($i['_f3base_representacao'])){return $i['_f3base_representacao'];}
            $g=(array)get_option(self::PUBLICADA,array());$ident=self::identidade($i);
            foreach($g['itens']??array() as $antigo){if(self::identidade($antigo)===$ident){return $antigo['_f3base_representacao'];}}
            return array('completo'=>false,'pendente'=>true,'erros'=>array(),'texto'=>'');
        }
        $key=self::chave($i);$r=get_transient($key);if(is_array($r)){return $r;}
        $r=F3Base_Llms_Conversor::converter((string)($i['conteudo']??''),(string)($i['url']??''),3);
        $r['revisao']=hash('sha256',$key);$r['em']=time();set_transient($key,$r,DAY_IN_SECONDS);return $r;
    }
    public static function disponiveis(array $itens): array {return array_values(array_filter($itens,static fn($i)=>!empty(self::item($i)['completo'])));}
    public static function resumo(array $itens): array {
        $lista=array();$ok=0;foreach($itens as $i){$r=self::item($i);$ok+=!empty($r['completo'])?1:0;$lista[]=array('id'=>$i['id']??0,'url'=>$i['url']??'','estado'=>!empty($r['completo'])?'disponivel':(!empty($r['pendente'])?'pendente':'incompleta'),'erros'=>$r['erros']??array(),'revisao'=>$r['revisao']??null);}
        $g=(array)get_option(self::PUBLICADA,array());$e=(array)get_option(self::ESTADO,array());
        return array('total'=>count($itens),'disponiveis'=>$ok,'parcial'=>$ok<count($itens),'itens'=>$lista,'geracao_publicada'=>$g['id']??null,'publicada_em'=>$g['em']??null,'idade_segundos'=>isset($g['em'])?max(0,time()-$g['em']):null,'preparo'=>array('id'=>$e['id']??null,'cursor'=>$e['cursor']??0,'total'=>$e['total']??0,'ultimo_avanco'=>$e['avanco']??null,'erro'=>$e['erro']??'','proxima_tentativa'=>wp_next_scheduled(self::EVENTO)?:null));
    }
    private static function agendar_em(int $quando): void {if(!wp_next_scheduled(self::EVENTO)){wp_schedule_single_event($quando,self::EVENTO);}}
    public static function agendar(): void {
        $c=F3Base_Options::ler('f3base_llms');if(empty($c['ligado'])||!F3Base_Llms::site_publico()){return;}
        $g=(array)get_option(self::PUBLICADA,array());$e=(array)get_option(self::ESTADO,array());
        $assinatura=hash('sha256',F3Base_Modulo_Cache_Publico::geracao().F3Base_Options::revisao('f3base_llms').F3BASE_PLUGIN_VERSAO);
        if(($g['assinatura']??'')!==$assinatura||!empty($e['pendente'])){self::agendar_em(time()+1);}
    }
    public static function lote(int $offset=0): void {self::executar(5);}
    public static function executar(int $orcamento=5): array {
        if(self::$executando){return array('ok'=>false,'codigo'=>'geracao_reservada');}
        $c=F3Base_Options::ler('f3base_llms');if(empty($c['ligado'])||!F3Base_Llms::site_publico()){return array('ok'=>true,'codigo'=>'recurso_desligado','restantes'=>0);}
        $l=@fopen(get_temp_dir().'f3base-llms-geracao-'.hash('sha256',ABSPATH).'.lock','c');if(!$l||!flock($l,LOCK_EX|LOCK_NB)){if($l){fclose($l);}return array('ok'=>false,'codigo'=>'geracao_reservada');}
        $lease=wp_generate_uuid4();$reserva=F3Base_Options::atualizar_estado('f3base_llms_trava',static fn($v)=>($v['ate']??0)>time()?null:array('id'=>$lease,'ate'=>time()+60));if(empty($reserva['persisted'])){flock($l,LOCK_UN);fclose($l);return array('ok'=>false,'codigo'=>'geracao_reservada');}
        self::$executando=true;$inicio=microtime(true);$fim=$inicio+max(1,min(10,$orcamento));
        try{
            $itens=F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache($c);$assinatura=hash('sha256',F3Base_Modulo_Cache_Publico::geracao().F3Base_Options::revisao('f3base_llms').F3BASE_PLUGIN_VERSAO);
            $id=hash('sha256',wp_json_encode(array($itens,$c,F3BASE_PLUGIN_VERSAO)));
            $atual=(array)get_option(self::PUBLICADA,array());
            if(($atual['id']??'')===$id){
                $atual['assinatura']=$assinatura;F3Base_Options::atualizar_estado(self::PUBLICADA,static fn()=>$atual);
                $pub=F3Base_Llms_Arquivo::gerar();wp_clear_scheduled_hook(self::EVENTO);$pendente=!empty($pub['estado']['pendente']);
                F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>array('id'=>$id,'cursor'=>count($itens),'total'=>count($itens),'pendente'=>$pendente,'avanco'=>time(),'erro'=>$pub['estado']['erro']??''));
                if($pendente){self::agendar_em(time()+30);}return array('ok'=>!$pendente,'codigo'=>$pendente?'indice_pendente':'geracao_atual','restantes'=>0,'parcial'=>$pendente,'geracao'=>$id);
            }
            $e=(array)get_option(self::ESTADO,array());
            if(($e['id']??'')!==$id){$e=array('id'=>$id,'cursor'=>0,'total'=>count($itens),'itens'=>array(),'bytes'=>0,'pendente'=>true,'inicio'=>time());}
            while($e['cursor']<count($itens)&&microtime(true)<$fim){
                $i=$itens[$e['cursor']];$r=self::item($i,true);$e['bytes']+=strlen($r['texto']??'');
                if($e['bytes']>F3Base_Llms_Conversor::MAX_BYTES){throw new RuntimeException('volume_geracao_excedido');}
                $i['_f3base_representacao']=$r;$i['conteudo']=!empty($r['texto'])?'[representacao_publicada]':'';$e['itens'][]=$i;++$e['cursor'];$e['avanco']=time();
                if(!F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>$e)['persisted']){throw new RuntimeException('progresso_nao_persistido');}
            }
            $restantes=count($itens)-$e['cursor'];
            if(!$restantes){
                if(hash('sha256',wp_json_encode(array(F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache($c),$c,F3BASE_PLUGIN_VERSAO)))!==$id||F3Base_Options::ler('f3base_llms')!==$c){throw new RuntimeException('contexto_alterado');}
                // Nunca troca uma geração completa por uma conversão incompleta.
                foreach($e['itens'] as $pos=>$convertido){if(empty($convertido['_f3base_representacao']['completo'])){
                    delete_transient(self::chave($itens[$pos]));$e['itens']=array_slice($e['itens'],0,$pos);$e['cursor']=$pos;$e['bytes']=array_sum(array_map(static fn($i)=>strlen($i['_f3base_representacao']['texto']??''),$e['itens']));$e['pendente']=true;$e['erro']='representacao_incompleta';
                    F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>$e);wp_clear_scheduled_hook(self::EVENTO);self::agendar_em(time()+60);
                    return array('ok'=>false,'codigo'=>'representacao_incompleta','parcial'=>true,'restantes'=>count($itens)-$pos,'geracao_preservada'=>$atual['id']??null);
                }}
                $g=array('id'=>$id,'assinatura'=>$assinatura,'em'=>time(),'itens'=>$e['itens']);
                if(!F3Base_Options::atualizar_estado(self::PUBLICADA,static fn()=>$g)['persisted']){throw new RuntimeException('promocao_nao_persistida');}
                // Representations are available before the physical index switches to their generation.
                $pub=F3Base_Llms_Arquivo::gerar();$e['pendente']=!empty($pub['estado']['pendente']);$e['erro']=$pub['estado']['erro']??'';$e['itens']=array();
                F3Base_Options::atualizar_estado(self::ESTADO,static fn()=>$e);wp_clear_scheduled_hook(self::EVENTO);
                if($e['pendente']){self::agendar_em(time()+30);}
                return array('ok'=>!$e['pendente'],'codigo'=>$e['pendente']?'indice_pendente':'geracao_publicada','geracao'=>$id,'restantes'=>0,'parcial'=>$e['pendente'],'duracao_ms'=>round((microtime(true)-$inicio)*1000),'cobertura'=>self::resumo($g['itens']));
            }
            self::agendar_em(time()+5);return array('ok'=>true,'codigo'=>'preparacao_parcial','geracao'=>$id,'parcial'=>true,'restantes'=>$restantes,'cursor'=>$e['cursor'],'duracao_ms'=>round((microtime(true)-$inicio)*1000));
        }catch(Throwable $erro){$codigo=in_array($erro->getMessage(),array('volume_geracao_excedido','progresso_nao_persistido','contexto_alterado','promocao_nao_persistida'),true)?$erro->getMessage():'geracao_falhou';F3Base_Options::atualizar_estado(self::ESTADO,static function($v)use($codigo){$v['erro']=$codigo;$v['pendente']=true;return $v;});self::agendar_em(time()+30);return array('ok'=>false,'codigo'=>$codigo,'parcial'=>true);}
        finally{F3Base_Options::atualizar_estado('f3base_llms_trava',static fn($v)=>($v['id']??'')===$lease?array():null);self::$executando=false;flock($l,LOCK_UN);fclose($l);}
    }
}
