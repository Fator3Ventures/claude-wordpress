# Validação — 1.14.0

Release de 28/09/2026. As evidências reproduzíveis acompanham as fontes em `suite/versao-1140/evidencias/`. Este documento identifica o ambiente e os limites das provas; o relatório de fechamento do pacote acrescenta a homologação do Site-Teste.

## Ambiente de bancada

WordPress 7.1, PHP 8.3.6 de 64 bits, MySQL 8.0.46/InnoDB, Apache 2.4.58 e Chromium 154.0.8037.57. Dados sintéticos. E-mails de integração interceptados, exceto sete verificações com PHPMailer e receptor SMTP local dedicado; nenhuma mensagem enviada para endereços externos. Os testes HTTP de regras de servidor usam Apache real, inclusive falha 500 e restauração.

| Conjunto | Provas |
|---|---|
| Dados e relatórios | 43 verificações: relações por sessão/navegação, classificação de teste, atribuição, consentimento, filtros antes dos limites, cobertura e contagens. |
| Documentação | 31 verificações: contrato das 16 tabelas, colunas reais, 19 campos de atribuição, leitura autenticada paginada, perfil tipado e execução/conciliação das cinco consultas SQL. |
| Interface | 64 verificações: seis sub-abas, ajudas, retorno da seção, controles fechados, cinco áreas de Medição, exportação/comparação de eventos e diagnósticos com sua própria janela. |
| MCP | 19 verificações de contrato/contexto de teste, propagação delimitada e configuração. |
| SEO e CTA | 19 verificações de grafo, FAQ e superfícies de acionamento. |
| Publicação LLMS | 21 verificações da geração, posse de arquivos, limites e estados de publicação. |
| Bordas | 17 verificações: CSV de 205 registros/103 testes, fórmula neutralizada, erro de leitura recusado, migração interrompida, UA desconhecido, Scrapy, slugs longos, retomada da repetição e leitura de cadência sem efeitos. |
| Concorrência | 9 verificações, com 12 processos PHP simultâneos em MySQL, idempotência, ordem de sequências e erros de persistência induzidos. |
| HTTP Apache | 34 verificações de GET/HEAD, gzip/identity, revalidação, cabeçalhos, documentação bloqueada, REST pública, XML-RPC e aplicação concorrente; 4 de restauração após 500; 12 de confirmação sem JS, query/fragmento de redirect e recuperação independente por CLI. |
| Navegador | 18 verificações do cookie, configuração, criação/edição de formulário, POST/redirect/GET, conflito preservando rascunho, duplicação inativa e Medição responsiva. |
| Transporte | 13 verificações e 18 navegações controladas comparando 1.13.0 e alternativas: saída curta, sem POST antes de load no fluxo normal, fila após 503 não JSON, renovação compartilhada, revogação, offline/online e sequência final de vital. |
| Consentimento | 8 verificações em viewport 390 × 844, temas sintéticos claro/escuro: contraste mínimo 4,5:1, alvo de 44 px, foco e escopo. Capturas também inspecionadas visualmente. |
| SMTP local | 7 verificações de envio interno normal, envio de teste explicitamente marcado e supressão padrão. |
| Instalação | 18 etapas com binários reais: site novo, upgrade de 1.12.0 e 1.13.0, repetição, retorno e preservação de capturas. A volta direta à 1.13.0 só passou na base originalmente concluída em 1.13.0; as outras combinações foram bloqueadas, conforme o guia de recuperação. |
| Sintaxe/assets | 131 arquivos PHP/JS sem erro de sintaxe; reconstrução determinística de sete assets e rejeição de ausência, desatualização e corrupção. Biblioteca vendorizada preservada. |

## Limites e operações externas

As falhas 503 reportadas anteriormente não tiveram sua causa histórica demonstrada. Falhas induzidas de banco comprovam o tratamento da release, não identificam retrospectivamente a origem daqueles cinco episódios. O transporte de navegador foi exercitado em ambiente controlado; não há promessa de nota PageSpeed ou ganho causal isolado.

O ensaio de temas não substitui a conferência das compensações específicas da Conselar. Nenhuma regra de tema é removida automaticamente. Filtros e recepção em GA4, GTM, Meta/LinkedIn e caixas comerciais dependem das contas/destinos configurados e de aceite próprio; testes locais não são apresentados como recepção nesses serviços. Não há sincronização de CRM, leads nativos nem custos/vendas.

O relatório da release separa provas do pacote, observações do Site-Teste e operações restantes por site. A implantação geral deve usar o mesmo ZIP, com snapshot, configuração efetiva, verificação pública e interrupção em caso de falha. Bloqueio de listagem na raiz permanece desligado por padrão. A 1.13.0 não sabe excluir testes dos novos relatórios; não a use para comparar séries sem ajustar a regra.
