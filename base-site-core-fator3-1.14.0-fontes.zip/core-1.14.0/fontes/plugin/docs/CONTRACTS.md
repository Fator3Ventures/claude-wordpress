# Contratos — plugin 1.14.0 / configuração 2.0.0

## Permissões e política

Operações administrativas exigem autenticação e capability. As abilities de relatórios, jornada, documentação e política exigem `manage_options`. O plugin não cria credenciais nem concede administração a outros papéis.

`f3base/config-core-politica-ler` retorna fotografias de `politica` e `gestao`, com valor, existência e revisão. `f3base/config-core-politica-escrever` aceita somente `politica`, `simular` (padrão true) e `revisao_esperada`. A escrita exige revisão atual e gestão por agentes habilitada. A simulação retorna `acrescimos` e `remocoes`. O contrato antigo de lista simples não é aceito por essa operação.

```json
{"politica":{"schema":1,"modo":"selecionadas","lista":["f3base_contato"]},"simular":true}
```

Modos `todas` e `nenhuma` exigem `lista:[]`; `selecionadas` exige itens únicos, elegíveis e não vazios. Somente a transformação inicial da base 1.12.0 interpreta lista simples vazia como `todas`. Uma lista explícita permanece explícita, mesmo se contém todos os itens atuais.

## Captura

POST `/wp-json/f3base/v1/lead` mantém schema fechado, token, quotas e deduplicação. `correlation_id` identifica a ação; a coluna persistida é `correlacao`. Sessão e navegação são 32 hex. O servidor classifica o método pelo destino e obtém IP, user agent e página do contexto da requisição. `cta` é um identificador estável limitado a 80 caracteres; `dispositivo` aceita `movel` ou `desktop` no contexto canônico. Sem medição autorizada, sessão/navegação/dispositivo não são persistidos como contexto analítico.

Formulários usam POST `/formularios/token` e `/formularios/enviar` dentro do mesmo namespace. Sem JS, usam `admin-post.php?action=f3base_formulario`. Token vincula formulário, revisão e página. Com JS, cada instância recebe uma chave nova, inclusive se o HTML veio de cache; retentativas mantêm a chave. O envio inclui atribuição de sessão, navegação e dispositivo quando disponíveis. O registro guarda snapshot da definição dos campos de opções fechadas para análise futura.

POST `/wp-json/f3base/v1/analise` aceita `token`, `medicao:true` e `eventos` (1–20). Limite de corpo: 32 KiB. Tipos: `pagina`, `form_vista`, `form_inicio`, `form_tentativa`, `form_erro`, `vital`. Identificadores: `evento`, `visitante`, `sessao`, `navegacao`; contexto: `caminho`, `formulario`, `formulario_revisao`, `correlacao`, `dispositivo`, `criado_em`, `detalhe`, `valor`, `sequencia`, `atribuicao`. Campos desconhecidos e valores digitados são recusados. O cliente envia lotes limitados por bytes.

Evento igual é idempotente. O mesmo ID com outro conteúdo é conflito, exceto revisão crescente de uma amostra de vital com identidade estável. A atualização é condicional e conserva a maior sequência. Horário fora da janela válida recebe âncora do servidor; a qualidade do horário fica registrada. Há quotas por origem (300 requisições/10 min) e sessão (1.000 eventos na janela). Rotas dinâmicas não devem ser armazenadas pelo cache.

## Relatórios e documentação

`f3base/relatorios-integrados-ler`: `de`, `ate` (YYYY-MM-DD, intervalo inclusivo de 1–90 dias), `visao`, `caminho`, `formulario`, `metodo`, `comparar`, `segmento`, `plataforma`, `conta_id`, `campanha_id`, `grupo_id`, `anuncio_id`, `pagina` e `limite` (1–200). Visões: `resultados`, `campanhas`, `formularios`, `blocos`, `qualidade`, `operacao`, `materiais`, `demanda`, `metodos`. Retorna período/fuso, totais, cobertura, avisos, linhas e próxima página. Filtros de formulário/método restringem contatos; denominadores continuam sessões da página observada. Caminhos externos são recusados.

`f3base/lead-jornada-ler`: `record_id` (32 hex). Até 500 eventos anteriores ao recebimento, com indicação de corte. Sem sessão ou sem eventos, não inventa uma jornada.

`f3base/documentacao-ler`: `arquivo`, `linha`, `limite` (1–200). Sem arquivo, índice. Caminhos não catalogados são recusados. `f3base/arquivos-privados-preparar` cria/testa a raiz configurada, sem enviar mensagens.

As abilities de consulta/gestão de leads e resposta opcional permanecem nos schemas publicados. O importador, o reparador histórico, o destino de gravação Flamingo/CPT e a resolução de destino CAPI anterior à base suportada foram retirados. A leitura do acervo já incorporado continua disponível.

`persisted` confirma armazenamento. `verified` no acesso direto ao cache exige corpo completo vazio com HTTP 200/403/404/410; 403 com HTML falha na expectativa de corpo. Hash igual ao arquivo prova exposição. 5xx, redirecionamento, truncamento e ausência de arquivo permanecem inconclusivos.

## Contratos adicionais da 1.14

`contexto_teste` é booleano; cabeçalho HTTP aceita 0/1. A classe armazenada é `teste` ou `nao_marcado`. Histórico sem marca permanece não marcado. Não existe token temporário para declarar teste. Dados operacionais de controle MCP são distintos de coleta pública; somente sondas explicitamente suportadas propagam o contexto.

Análise responde `confirmados:[{evento,sequencia}]`. Sucesso parcial confirma somente o que foi persistido. 400/409/413 são rejeições identificáveis; 403 token inválido permite uma renovação; 429 aplica Retry-After; 503 sinaliza falha de armazenamento e conserva os itens pendentes. Resposta não JSON não confirma recebimento. O cliente mantém no máximo 100 eventos/24 horas, retentativas com atraso e IDs estáveis, sem coleta antes da permissão. Limites/expiração/rejeição ficam no diagnóstico local. Não há promessa de entrega após encerramento do navegador.

Atribuição possui allowlist publicada em `dados/contrato.json`, limite de 500 caracteres por valor, IDs como strings, snapshots de primeiro/último toque e origem da sessão. Não guardar query inteira. `f3_ads_v=1` declara que utm_id identifica campanha e utm_content identifica anúncio. Sem esse contrato, os campos continuam rótulos e não viram IDs por aparência. utm_term é palavra-chave. fbclid sozinho não identifica Facebook versus Instagram. Consulte CRUZAMENTOS-PUBLICIDADE.md.

Relatórios retornam `regra`, `consultado_em`, `fontes`, `limites`, cobertura e linhas. Segmentos: `sem_testes` (padrão), `somente_testes`, `todos`. Os mesmos filtros e definições valem para GUI/ability/CSV. A API de leads vincula cursor ao filtro; reaproveitar cursor com filtro diferente é recusado.

Redirects têm `preservar_query:boolean` (padrão true). Destino externo exige HTTPS e host exato em allowlist; cada salto é revalidado na sonda. Sem prova do ID/name da âncora no HTML final, verificação fica pendente. Leitura do cadastro não executa HTTP.

Servidor usa revisão do arquivo e das preferências, trava de operação e backup privado. Conflito preserva o arquivo. O script de recuperação CLI exige o hash da escrita correspondente e funciona sem WordPress. Interrupção total do processo pode exigir execução manual; não é prometida reversão automática de qualquer timeout.
