# Base Site Core Fator3 — documentação instalada 1.14.0

Ponto de entrada da instalação em `wp-content/plugins/base-site-core-fator3/`. Todos os documentos técnicos estão em `docs/`, protegidos do acesso HTTP público por regras distribuídas para Apache. Acesso autenticado por `f3base/documentacao-ler` ou leitura de arquivos preserva o conteúdo integral. Em Nginx, uma regra equivalente é necessária; o pacote não configura a hospedagem.

| Documento relativo a docs/ | Conteúdo |
|---|---|
| INSTRUCOES-DO-PLUGIN.md | Roteiro do agente, marca de teste, configuração e verificação |
| README.md | Instalação, recursos e limites |
| CONFIGURACAO.md | Sub-abas, defaults, herança e política do canal |
| CONTRACTS.md | Schemas, permissões, unidades, erros e retentativas |
| LEADS-E-FORMULARIOS.md | Caixa de entrada, editor, captura, anexos e respostas |
| RELATORIOS.md | Telas, filtros, cobertura e coleta |
| DICIONARIO-DADOS.md | Tabelas, campos, granularidade e relacionamentos |
| dados/contrato.json | Contrato estrutural versionado para ferramentas |
| METRICAS.md | Fórmulas, numeradores, denominadores e exclusões |
| CONSULTAS-EXEMPLO.sql | Consultas SELECT parametrizadas e limites |
| CRUZAMENTOS-PUBLICIDADE.md | Meta, Google e LinkedIn: modelos de URL e cruzamentos por ID |
| OPERACAO-E-RECUPERACAO.md | Migração, cache, LLMS, servidor, recuperação e reversão |
| REFERENCIA-CATALOGO.md | Declarações reais de opções, módulos e abilities |
| perfis/piso-core-1140.json | Perfil parcial: não substitui o Padrão completo da frota |
| VALIDACAO.md | Ensaios da versão e limites da evidência |
| CHANGELOG.md | Histórico |

O leitor de documentação sem argumentos retorna o índice. `arquivo`, `linha` e `limite` permitem paginação de até 200 linhas, com SHA-256 e próxima linha. Os aliases históricos para documentos da raiz resolvem os documentos atuais em docs/. Caminhos arbitrários são recusados.

Instalação nova e atualização de base concluída 1.12.0 ou 1.13.0 são os caminhos suportados. Estado anterior sem origem confiável é bloqueado. A repetição da 1.14.0 é idempotente. Importadores CF7/Flamingo e reparadores anteriores à base não integram este runtime; o acervo já incorporado é preservado.
