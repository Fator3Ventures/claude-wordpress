# Base Site Core Fator3 1.14.0

Instale `base-site-core-fator3-1.14.0.zip` pelo WordPress; o ZIP de fontes não é instalável. Requisitos mínimos permanecem no cabeçalho do plugin. Faça backup restaurável antes de atualizar. Origens suportadas: site novo ou base 1.12.0/1.13.0 concluída.

A versão organiza Configurações em seis sub-abas, Medição em cinco áreas e contatos/formulários no menu Contatos. Inclui editor de formulário por vez, filtro de testes, atribuição por anúncio, documentação de dados instalada e tratamento robusto da coleta concorrente.

Defaults novos: destinatário interno usa Administration Email Address quando a chave ainda não existe; índice usa Arquivo gerado; FAQ acompanha o padrão atual; testes ficam fora dos relatórios comerciais e suprimidos nos destinos externos. Valores já gravados e listas vazias são preservados. Opções de proteção pública são explícitas e precisam de preflight de integrações XML-RPC. Bloqueio de listagem da raiz vem desligado.

Consulte DOCUMENTACAO.md para todos os contratos. O pacote não implanta configuração nas contas Meta/Google/LinkedIn, não integra CRM e não altera campanhas. Arquivo instalado não prova funcionamento de SMTP, publicador externo, cache ou regras de servidor: use OPERACAO-E-RECUPERACAO.md e a evidência de VALIDACAO.md.
