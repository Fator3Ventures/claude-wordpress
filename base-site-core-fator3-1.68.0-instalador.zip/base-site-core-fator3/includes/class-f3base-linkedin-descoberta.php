<?php
/** Additive 1.2 consumer: authoritative outbox, scoped checkpoint and producer receipt. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Descoberta {
    const MODO='todos_conta_autorizada';
    public static function ativa(array $cfg): bool {return ($cfg['formularios_modo']??'selecionados')===self::MODO;}
    public static function escopo(array $cfg): string {return hash('sha256',F3Base_Linkedin_Integracoes::consumer($cfg).'|'.$cfg['cliente'].'|'.$cfg['connection_id'].'|'.$cfg['conta_id']);}
    public static function formularios(array $cfg): array {
        $raw=get_option(F3Base_Linkedin::ESTADO,array());$state=$raw;if(isset($raw['integracoes'])){$state=array();foreach(F3Base_Linkedin_Integracoes::colecao() as $id=>$one){if(($one['uuid']??'')===($cfg['uuid']??'')){$state=$raw['integracoes'][$id]??array();break;}}}$s=$state['descoberta']??array();
        if(($s['escopo']??'')!==self::escopo($cfg)){return array();}
        return array_values(array_intersect(array_map('strval',array_keys($s['formularios']??array())),$s['autorizados']??array()));
    }
    public static function desde(string $form,array $state): int {
        $a=$state['aquisicao']??array();$base=max((int)($a['ativado_em']??time()),(int)($a['recibos_desde']??0));
        $created=(int)(($state['descoberta']['formularios'][$form]['created_at_ms']??0)/1000);
        return max($base,$created);
    }
    private static function vinculo(array $s): array {return array_intersect_key($s,array_flip(array('credential_revision','grant_revision')));}
    public static function configurar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        return F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static function()use($e){
            $cfg=F3Base_Linkedin::config();$mode=$e['formularios_modo']??'';$rev=F3Base_Options::revisao(F3Base_Linkedin::OPCAO);
            if(!in_array($mode,array('selecionados',self::MODO),true)){return array('ok'=>false,'codigo'=>'modo_invalido');}
            if(!F3Base_Linkedin_Integracoes::liberada()){return array('ok'=>false,'codigo'=>'transicao_pendente');}
            $proof=array();
            if($mode===self::MODO){
                if(!F3Base_Linkedin_Cliente::externo()){return array('ok'=>false,'codigo'=>'descoberta_requer_plugin_linkedin_0150');}
                $status=F3Base_Linkedin_Cliente::chamar('effective_status');if(empty($status['ok'])){return $status;}
                if(empty($status['data']['all_forms'])||($status['data']['descriptor']['contract']??'')!=='linkedin-lead-reader/1.2.0'){return array('ok'=>false,'codigo'=>'todos_formularios_sem_concessao');}
                $grant=\Fator3\LinkedIn\Api::dispatch('get-grant',array('consumer_id'=>F3Base_Linkedin_Integracoes::consumer(),'connection_id'=>$cfg['connection_id']));$g=$grant['data']['grant']??array();
                if(empty($grant['success'])||array_diff(array('metadata','responses','verify','subscriptions'),$g['permissions']??array())||($g['callback_url']??'')!==F3Base_Linkedin_Webhook::url()||empty($cfg['webhook']['ativo'])){return array('ok'=>false,'codigo'=>'descoberta_callback_ou_permissoes_pendentes');}
                $proof=self::vinculo($status['data']);
            }
            $target=$cfg;$target['formularios_modo']=$mode;
            $all=F3Base_Linkedin_Integracoes::colecao();$all[F3Base_Linkedin_Integracoes::id()]=$target;
            $err=F3Base_Linkedin_Integracoes::permitir_transicao(static fn()=>F3Base_Linkedin_Integracoes::validar(array('integracoes'=>$all)));
            if($err!==''){return array('ok'=>false,'codigo'=>'configuracao_recusada','motivo'=>$err);}
            $confirmation=hash_hmac('sha256',wp_json_encode(array($rev,$target,$proof,get_current_user_id())),wp_salt('nonce'));
            $preview=array('ok'=>true,'persisted'=>false,'simular'=>true,'revisao'=>$rev,'confirmacao'=>$confirmation,'formularios_modo'=>$mode,'revisoes'=>$proof,'efeito'=>$mode===self::MODO?'Incluir os formulários concedidos desta conta, desde o maior marco entre criação e ativação da importação.':'Usar apenas a lista salva; preservar histórico e recibos.');
            if(($e['simular']??true)!==false){return $preview;}
            if(!hash_equals($rev,(string)($e['revisao']??''))||!hash_equals($confirmation,(string)($e['confirmacao']??''))){return array('ok'=>false,'codigo'=>'previa_desatualizada');}
            $lock=F3Base_Trava::adquirir('linkedin-coleta:'.F3Base_Linkedin_Integracoes::id(),30);if(!$lock){return array('ok'=>false,'codigo'=>'worker_em_curso');}
            try{$r=F3Base_Linkedin_Integracoes::permitir_transicao(static fn()=>F3Base_Linkedin_Integracoes::salvar($target,$rev,F3Base_Options::ORIGEM_MANUAL));if(empty($r['persisted'])){return $r;}
                F3Base_Fila::agendar(F3Base_Linkedin::EVENTO,time()+5);return array('ok'=>true,'persisted'=>true,'codigo'=>'selecao_formularios_salva','formularios_modo'=>$mode);
            }finally{F3Base_Trava::liberar($lock);}
        });
    }
    /** Hook is a wake-up hint only. Data is re-read from the authorized public outbox. */
    public static function avisada(array $event): void {
        foreach(F3Base_Linkedin_Integracoes::colecao() as $cfg){if(!empty($cfg['ativo'])&&self::ativa($cfg)&&($event['consumer_id']??'')===F3Base_Linkedin_Integracoes::consumer($cfg)&&($event['connection_id']??'')===$cfg['connection_id']&&($event['account_id']??'')===$cfg['conta_id']){F3Base_Fila::agendar(F3Base_Linkedin::EVENTO,time()+1);break;}}
    }
    public static function atualizar(float $deadline): array {
        $lock=F3Base_Trava::adquirir('linkedin-descoberta:'.F3Base_Linkedin_Integracoes::id(),30);if(!$lock){return array('ok'=>false,'codigo'=>'descoberta_em_curso');}
        try{return self::atualizar_escopo($deadline);}finally{F3Base_Trava::liberar($lock);}
    }
    private static function atualizar_escopo(float $deadline): array {
        $cfg=F3Base_Linkedin::config();if(!self::ativa($cfg)){return array('ok'=>true,'codigo'=>'selecao_explicita','formularios_incluidos'=>0);}
        $execution=F3Base_Linkedin_Integracoes::revisao_execucao();$scope=self::escopo($cfg);$status=F3Base_Linkedin_Cliente::chamar('effective_status');
        if(empty($status['ok'])){return $status;}if(empty($status['data']['all_forms'])){return array('ok'=>false,'codigo'=>'todos_formularios_sem_concessao');}
        $binding=self::vinculo($status['data']);$state=F3Base_Linkedin_Integracoes::estado();$d=$state['descoberta']??array();
        if(($d['escopo']??'')!==$scope){$d=array('escopo'=>$scope,'after'=>0,'formularios'=>array());}
        $after=(int)($d['after']??0);$r=F3Base_Linkedin_Cliente::chamar('list_form_events',array('after'=>$after));if(empty($r['ok'])){return $r;}$page=$r['data'];
        if(self::vinculo($page)!==$binding||!is_int($page['next_after']??null)||$page['next_after']<$after||!is_bool($page['has_more']??null)||!is_array($page['events']??null)||count($page['events'])>50){return array('ok'=>false,'codigo'=>'descoberta_resposta_invalida');}
        $included=0;$partial=false;$last=$after;$processed=0;$receipts=array();$newForms=array();$rejected=0;
        foreach($page['events'] as $event){
            if(microtime(true)>$deadline-6||$processed>=5){$partial=true;break;}$processed++;
            $seq=$event['sequence']??null;$form=(string)($event['form_id']??'');$version=(string)($event['form_version']??'');
            if(!is_int($seq)||$seq<=$last||$seq>$page['next_after']||!ctype_digit($form)||!ctype_digit($version)||!preg_match('/^[0-9]{13}$/D',(string)($event['created_at_ms']??''))||($event['contract']??'')!=='linkedin-lead-reader/1.2.0'||($event['consumer_id']??'')!==F3Base_Linkedin_Integracoes::consumer()||($event['connection_id']??'')!==$cfg['connection_id']||($event['account_id']??'')!==$cfg['conta_id']){return array('ok'=>false,'codigo'=>'evento_descoberta_invalido');}
            $last=$seq;
            if(self::vinculo($event)!==$binding||!in_array($form,$status['data']['forms']??array(),true)){$rejected++;continue;}
            $created=F3Base_Linkedin::instante($event['created_at_ms']);if(!$created){return array('ok'=>false,'codigo'=>'criacao_formulario_invalida');}
            $sub=$event['subscription']??array();if(!is_array($sub)||(!empty($sub['ownership_key'])&&!preg_match('/^[a-f0-9]{64}$/D',(string)$sub['ownership_key']))||empty($sub['state'])||!in_array($sub['remote_effect']??'',array('none','unknown','confirmed','removed'),true)){return array('ok'=>false,'codigo'=>'descoberta_sem_recibo_assinatura');}
            // Persist metadata and receipt in the same Core checkpoint; never prepare a second POST.
            $first=!isset($d['formularios'][$form]);$old=$d['formularios'][$form]??array();
            $d['formularios'][$form]=array('form_id'=>$form,'form_version'=>$version,'created_at_ms'=>$event['created_at_ms'],'incluido_em'=>$old['incluido_em']??time(),'descoberto_em'=>$event['discovered_at']??time(),'event_id'=>$event['event_id']??'','sequence'=>$seq,'subscription'=>array_intersect_key($sub,array_flip(array('ownership_key','subscription_id','state','remote_effect','operation_revision','code'))));
            $key=hash('sha256',F3Base_Linkedin::contexto().'|'.$cfg['conta_id'].'|'.$form.'|'.$version);
            $receipts[$key]=array('form_id'=>$form,'form_version'=>$version,'contexto'=>F3Base_Linkedin::contexto(),'origem'=>'descoberta_produtor','em'=>time())+$d['formularios'][$form]['subscription'];
            if($first){$included++;$newForms[$form]=self::desde($form,array_replace($state,array('descoberta'=>$d)));}
        }
        $fresh=F3Base_Linkedin_Cliente::chamar('effective_status');if(empty($fresh['ok'])||empty($fresh['data']['all_forms'])||self::vinculo($fresh['data'])!==$binding||F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){return array('ok'=>false,'codigo'=>'revision_conflict');}
        unset($d['ultima_falha']);$d['after']=$partial?$last:$page['next_after'];$d['autorizados']=$fresh['data']['forms']??array();$d['revisoes']=$binding;$d['ultima_verificacao']=time();$d['formularios_incluidos_ultimo_lote']=$included;$d['eventos_obsoletos_ultimo_lote']=$rejected;$d['continuacao']=$partial||$page['has_more'];
        $save=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($d,$receipts,$newForms,$execution){if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){return null;}$s['descoberta']=$d;foreach($receipts as $key=>$receipt){$s['assinaturas_sdk'][$key]=$receipt;}foreach($newForms as $form=>$from){if(!isset($s['cursores'][$form])){$s['cursores'][$form]=array('desde'=>$from,'ate'=>$from,'proxima'=>0);}}return $s;});
        if(empty($save['persisted'])){return array('ok'=>false,'codigo'=>'descoberta_checkpoint_falhou');}
        return array('ok'=>true,'codigo'=>'descoberta_incorporada','formularios_incluidos'=>$included,'parcial'=>$d['continuacao']);
    }
}
