# Fonte do Fator3 Site Core 1.97.2

O código instalável está em `work/plugin/base-site-core-fator3/`. A implementação dos pedidos 432–437 partiu da 1.96.0. A homologação da 1.97.0 identificou correções de schema e promoção de lotes. A 1.97.2 acrescenta a renderização conjunta dos shortcodes. O relatório desta rodada é `RELATORIO-PRE-FECHAMENTO.md`. Os resultados correntes ficam em `evidence/1970/` e o patch experimental do canal em `reference/1970/`. Os demais diretórios de evidências são históricos.

## Build

Com Python 3, zlib 1.3.2 e PHP de 64 bits a partir de 8.3, execute na raiz deste fonte.

```sh
F3BASE_PHP=php python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.97.2-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.97.2-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.97.2-fonte.zip
```

Os catálogos são verificáveis com `F3BASE_SITE=/caminho/wp-load.php php build/gerar-catalogo-abilities.php --check` e `gerar-referencia-abilities.php --check`, em WordPress local com o Core final ativo.

## Ensaios reproduzíveis

Use WordPress 7.1.4, MariaDB, WP-CLI, administrador 1, `WP_ENVIRONMENT_TYPE=local`, uma URL de loopback e `DISABLE_WP_CRON=true`. Use bancos descartáveis distintos para instalação limpa e migração. O servidor HTTP do ensaio Markdown e o processo WP-CLI devem usar o mesmo banco e a mesma URL. Intercepte e-mail e HTTP externo. A fixture local de shortcode registra `perfil197` e devolve uma biografia pública somente na requisição anônima. O texto esperado contém “Perfil público”.

1. No banco `core_197_clean`, instale o ZIP final sozinho com `wp plugin install <arquivo> --force --activate`. Em nova requisição, execute `wp --user=1 eval-file tests/197/instalacao.php`.
2. No banco `core_197_aceite_troca`, ative os acompanhantes do relatório. Instale a versão-base, grave uma regra de sinal já existente e atualize com o ZIP final. Releia o sinal antigo e o padrão de e-mail. Execute o ensaio de instalação.
3. Na instalação integrada, rode `CASO197=cron wp --user=1 eval-file tests/197/rodada.php`. Repita nos modos `catalogo`, `markdown` e `email`. O último intercepta o receptor Slack em memória. Rode `tests/197/contrato-e-publicacao.php` para validar a saída administrativa contra o schema registrado e acompanhar a geração até a promoção.
4. Para as filas Google, configure `F3_PHASE39=core-patch`, `F3_RESULT39=/tmp/resultado.json` e `F3_EXTRA196` com o caminho absoluto de `tests/197/ads.php`. Execute `wp --user=1 eval-file tests/196/provas-google.php` no banco integrado. As respostas de fornecedor e de e-mail são sintéticas.
5. Em `core_197_clean`, execute `wp --user=1 --exec='ini_set("memory_limit","128M");' eval-file tests/197/volume.php`. Depois rode `tests/197/paridade-diaria.php` com WP-CLI. O segundo teste acrescenta 30 visualizações, compara os totais e linhas das duas visões com chamadas diárias independentes e exige o término do cursor.
6. Para verificar o impacto no MCP, aplique `reference/1970/mcp-051-diagnostico.patch` com `patch -p1` na cópia descartável do MCP 0.51.0. Execute `tests/197/impacto-canal.php` após a fixture de cron e reponha essa cópia. Use `tests/197/painel-html.py` e `painel.py` na tela local de avisos. Ambos usam `LAB197` como pasta privada com o arquivo temporário `browser-local.json` contendo URL local e cookies sintéticos do administrador. Descarte esse arquivo após o ensaio.

O relatório externo identifica os dois ZIPs finais. A cópia interna antecede o fechamento do fonte.

Para repetir a aprovação com o navegador, copie temporariamente `tests/197/shortcode-offline-local.php` e `tests/197/slack-aprovacao-local.php` ao diretório de mu-plugins do laboratório integrado. Execute `rodada.php` em modo `CASO197=email F3_EMAIL_UI197=preparar` e salve o JSON em `LAB197/email-painel-fixture.json`. Com o mesmo login local usado pelo teste de interface, rode `aprovacao-painel.py`. Passe o ID do JSON como `F3_REGISTRO_UI197` a `wp eval-file tests/197/aprovacao-conferir.php`. O teste verifica um único recibo após duas passagens da fila. Remova os mu-plugins do laboratório após o ensaio.
