# Fator3 Site Core 1.97.2

Leia docs/DOCUMENTACAO.md e docs/RELEASE-1.97.2.md para configurar o destino técnico e conferir agenda e catálogo.
