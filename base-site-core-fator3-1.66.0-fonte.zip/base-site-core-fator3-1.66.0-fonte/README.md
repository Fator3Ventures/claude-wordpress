# Fator3 Site Core 1.66.0 — fonte

Runtime em `work/plugin/base-site-core-fator3`. Base canônica imutável 1.65.1; contrato administrativo 8.30.0. Esta rodada implementa os pedidos 354(k,l), 363(a–c) e 364(a–c), preservando a correção 362 e a separação de recursos da 1.65.1. Leia `PLANO-1.66.0.md`, `build/README.md`, `work/plugin/base-site-core-fator3/docs/RELEASE-1.66.0.md` e o relatório externo. Evidências atuais: `evidence/1660`; insumos: `inputs/1660`. Pastas anteriores são histórico, não ensaios reexecutados nesta rodada. Não reaplique scripts de patch sobre o runtime final.

O fonte não contém bancos, credenciais, laboratórios prontos, pacotes acompanhantes, node_modules ou ZIPs aninhados. Forneça insumos oficiais e siga build/README.md. A existência de scripts históricos não significa reexecução. Aceites de campo não observados permanecem explicitamente identificados no relatório.
