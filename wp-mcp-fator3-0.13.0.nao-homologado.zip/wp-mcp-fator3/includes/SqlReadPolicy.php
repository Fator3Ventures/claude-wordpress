<?php
/** Intentionally bounded SQL grammar. Unknown syntax is refused before execution. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SqlReadPolicy {
    private const FUNCTIONS=['COUNT','SUM','MIN','MAX','AVG','COALESCE','IFNULL','NULLIF','CONCAT','CONCAT_WS','LOWER','UPPER','LENGTH','CHAR_LENGTH','TRIM','LTRIM','RTRIM','SUBSTRING','SUBSTR','REPLACE','ROUND','ABS','CEIL','FLOOR','DATE','YEAR','MONTH','DAY'];
    public static function tokens(string $sql) {
        $tokens=[];$offset=0;
        while($offset<strlen($sql)) {
            if(!preg_match('/\G\s*(?:(?<string>\'(?:[^\'\\\\]|\\\\.|\'\')*\')|(?<identifier>`[A-Za-z_][A-Za-z0-9_]*`)|(?<number>\d+(?:\.\d+)?)|(?<word>[A-Za-z_][A-Za-z0-9_]*)|(?<operator><=>|!=|<>|<=|>=|[(),.*+\/%=<>-]))/As',$sql,$m,0,$offset)) return new \WP_Error('sql_grammar_unsupported','SQL contém sintaxe fora do subconjunto permitido.');
            $offset+=strlen($m[0]);
            foreach(['string','identifier','number','word','operator'] as $kind) if(isset($m[$kind])&&$m[$kind]!=='') { $tokens[]=['kind'=>$kind,'value'=>$m[$kind]];break; }
            if(count($tokens)>8192)return new \WP_Error('sql_grammar_limit','SQL excede o orçamento de tokens.');
        }
        return $tokens;
    }
    public static function source(string $table,bool $read=true) {
        global $wpdb;
        if(!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D',$table))return new \WP_Error('sql_source_forbidden','Fonte SQL inválida.');
        $blocked=[$wpdb->users,$wpdb->usermeta];
        if($read) $blocked=array_merge($blocked,[$wpdb->options,$wpdb->postmeta,$wpdb->termmeta,$wpdb->commentmeta]);
        if(in_array($table,$blocked,true)||str_starts_with($table,$wpdb->prefix.'f3_mcp_')||!str_starts_with($table,$wpdb->prefix))return new \WP_Error('sql_source_forbidden','Fonte protegida ou externa. Use habilidades tipadas para usuários, options e metadados.');
        $type=$wpdb->get_var($wpdb->prepare('SELECT TABLE_TYPE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s',$table));
        if($wpdb->last_error||$type!=='BASE TABLE')return new \WP_Error('sql_source_forbidden','Views ou fontes não verificadas não são permitidas.');
        if($read) {
            $default=[$wpdb->posts,$wpdb->terms,$wpdb->term_taxonomy,$wpdb->term_relationships,$wpdb->comments,$wpdb->links];
            $allowed=apply_filters('f3_mcp_sql_read_tables',$default);
            if(!is_array($allowed)||!in_array($table,$allowed,true))return new \WP_Error('sql_source_unclassified','Tabela de extensão requer classificação explícita no servidor.');
        }
        return true;
    }
    public static function validate(string $sql) {
        global $wpdb;
        if(preg_match('/^(?:describe|desc)\s+`?([A-Za-z_][A-Za-z0-9_]*)`?$/iD',$sql,$m)) { $ok=self::source($m[1]);return is_wp_error($ok)?$ok:$sql; }
        if(preg_match('/^show\s+(?:index|indexes|columns)\s+from\s+`?([A-Za-z_][A-Za-z0-9_]*)`?$/iD',$sql,$m)) { $ok=self::source($m[1]);return is_wp_error($ok)?$ok:$sql; }
        if(strcasecmp(trim($sql),'SHOW TABLES')===0) return "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_TYPE='BASE TABLE'";
        if(preg_match('/^explain\s+(select\s+.+)$/isD',$sql,$m)) { $ok=self::validate($m[1]);return is_wp_error($ok)?$ok:'EXPLAIN '.$ok; }
        $tokens=self::tokens($sql);if(is_wp_error($tokens))return $tokens;
        if(strtoupper($tokens[0]['value']??'')!=='SELECT')return new \WP_Error('sql_grammar_unsupported','Use SELECT limitado, DESCRIBE ou SHOW INDEX/COLUMNS/TABLES.');
        $from=null;$depth=0;
        foreach($tokens as $i=>$token) {
            if($token['value']==='(')$depth++;if($token['value']===')')$depth--;
            if($depth<0||$depth>32)return new \WP_Error('sql_grammar_limit','Parênteses inválidos ou profundos.');
            if($token['kind']==='word'&&in_array(strtoupper($token['value']),['UNION','WITH','JOIN','SELECT','INTO','FOR','LOCK','PROCEDURE','OUTFILE','COLLATE','BINARY'],true)&&$i>0)return new \WP_Error('sql_grammar_unsupported','Subconsultas, JOIN, UNION e extensões de execução não estão habilitados para leitura genérica.');
            if($token['kind']==='word'&&strtoupper($token['value'])==='FROM') { if($depth!==0||$from!==null)return new \WP_Error('sql_grammar_unsupported','Uma única fonte física é necessária.');$from=$i; }
        }
        if($depth!==0||$from===null||$from<2)return new \WP_Error('sql_grammar_unsupported','SELECT exige projeção e uma tabela física.');
        $source=$tokens[$from+1]??[];
        if(!in_array($source['kind']??'', ['word','identifier'],true))return new \WP_Error('sql_source_forbidden','Fonte SQL inválida.');
        $table=trim($source['value'],'`');$ok=self::source($table);if(is_wp_error($ok))return $ok;
        $columns=$wpdb->get_col("DESCRIBE `{$table}`",0);if($wpdb->last_error||!$columns)return new \WP_Error('sql_columns_unavailable','Colunas não verificadas.');
        $allowed=[];foreach($columns as $col)if(!DataSafety::secret_key($col))$allowed[strtolower($col)]=$col;
        $alias=$table;$cursor=$from+2;
        if(strtoupper($tokens[$cursor]['value']??'')==='AS') { $cursor++;$alias=trim($tokens[$cursor++]['value']??'','`'); }
        elseif(isset($tokens[$cursor])&&in_array($tokens[$cursor]['kind'],['word','identifier'],true)&&!in_array(strtoupper($tokens[$cursor]['value']),['WHERE','GROUP','HAVING','ORDER','LIMIT'],true))$alias=trim($tokens[$cursor++]['value'],'`');
        if(!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D',$alias))return new \WP_Error('sql_alias_invalid','Alias inválido.');
        $output=[];$aliases=[];$keywords=['SELECT','FROM','AS','WHERE','AND','OR','NOT','IN','IS','NULL','TRUE','FALSE','LIKE','BETWEEN','GROUP','BY','HAVING','ORDER','ASC','DESC','LIMIT','OFFSET','DISTINCT'];
        for($i=0;$i<count($tokens);$i++) {
            $token=$tokens[$i];$v=$token['value'];$upper=strtoupper($v);
            if($i===$from+1||($i>$from+1&&$i<$cursor)) { $output[]=$v;continue; }
            if($v==='*') {
                if(strtoupper($tokens[$i-2]['value']??'')==='COUNT'&&($tokens[$i-1]['value']??'')==='(') {$output[]='*';continue;}
                if($i===1&&$i+1===$from) { $output[]=implode(',',array_map(static fn($c)=>'`'.$c.'`',array_values($allowed)));continue; }
                // Multiplication is allowed only with operands, never a qualified wildcard.
                if(($tokens[$i-1]['value']??'')==='.'||($tokens[$i-1]['value']??'')===',')return new \WP_Error('sql_projection_unsupported','Use colunas explícitas no lugar de curinga qualificado.');
            }
            if(in_array($token['kind'],['word','identifier'],true)) {
                $id=trim($v,'`');
                if($i<$from&&strtoupper($tokens[$i-1]['value']??'')==='AS') { $aliases[strtolower($id)]=true; $output[]='`'.$id.'`';continue; }
                if(($tokens[$i+1]['value']??'')==='(') { if(!in_array(strtoupper($id),self::FUNCTIONS,true)&&!in_array($upper,['IN','NOT'],true))return new \WP_Error('sql_function_forbidden','Função não permitida.'); }
                elseif(($tokens[$i+1]['value']??'')==='.') { if(!in_array(strtolower($id),[strtolower($table),strtolower($alias)],true))return new \WP_Error('sql_source_forbidden','Qualificador externo não permitido.'); }
                elseif(!in_array($upper,$keywords,true)&&!isset($allowed[strtolower($id)])&&!isset($aliases[strtolower($id)]))return new \WP_Error('f3_sql_sensitive_column','Coluna desconhecida ou protegida; use habilidade tipada.');
            }
            $output[]=$v;
        }
        return implode(' ',$output);
    }
}
