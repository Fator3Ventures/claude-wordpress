<?php
/** Durable preimages, signed recovery journal and bounded runtime verification. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;

final class Recovery {
    private static array $evidence=[];
    private static string $runtime_refresh='not_needed';
    /** Refresh an existing independent runtime after a package upgrade, without boot failure. */
    public static function refresh_existing_sentinel(): void {
        $copy=WPMU_PLUGIN_DIR.'/f3-mcp-recovery-runtime-v1.php';
        if(!is_file(WPMU_PLUGIN_DIR.'/000-f3-mcp-recovery.php'))return;
        try {
            $expected=hash_file('sha256',F3_MCP_FILES_DIR.'includes/RecoveryEngine.php');
            if(!is_file($copy)||hash_file('sha256',$copy)!==$expected) {
                self::install_sentinel();
                self::$runtime_refresh='updated_for_next_request';
            } else self::$runtime_refresh='current';
        } catch(\Throwable $error) { self::$runtime_refresh='failed'; }
    }
    public static function runtime_refresh_status(): string { return self::$runtime_refresh; }
    public static function directory(): string {return StateStore::directory('recovery-journals');}
    public static function install_sentinel(): void {
        $dir=WPMU_PLUGIN_DIR;if(!is_dir($dir)&&!wp_mkdir_p($dir))throw new \RuntimeException('MU plugin directory unavailable.');
        if(is_link($dir))throw new \RuntimeException('MU directory must not be linked.');
        $source=F3_MCP_FILES_DIR.'includes/RecoveryEngine.php';$copy=$dir.'/f3-mcp-recovery-runtime-v1.php';
        $bytes=(string)file_get_contents($source);
        if(!is_file($copy)||hash_file('sha256',$copy)!==hash('sha256',$bytes))Engine::atomic($copy,$bytes,0600);
        $loader="<?php\n/** WP MCP Fator3 recovery sentinel v1. */\nif (!defined('ABSPATH')) { exit; }\nrequire_once __DIR__.'/f3-mcp-recovery-runtime-v1.php';\n\\Fator3\\RecoveryV1\\Engine::register_worker(".var_export(self::directory(),true).");\n\\Fator3\\RecoveryV1\\Engine::sweep(".var_export(self::directory(),true).");\n";
        $path=$dir.'/000-f3-mcp-recovery.php';
        if(!is_file($path)||hash_file('sha256',$path)!==hash('sha256',$loader))Engine::atomic($path,$loader,0600);
    }
    public static function begin(string $target,?string $after,array $extra=[]): array {
        self::install_sentinel();$id=bin2hex(random_bytes(16));$dir=self::directory();$journal=$dir.'/'.$id.'.journal.php';
        $before=Engine::manifest($target);$preimage=$dir.'/'.$id.'.preimage';
        if($before!==null)Engine::copy($target,$preimage);
        $root=$extra['lock_root']??$target;$resources=['file:'.$root=>LOCK_EX];
        for($p=dirname($root);;$p=dirname($p)){$resources['file:'.$p]=$resources['file:'.$p]??LOCK_SH;if(dirname($p)===$p)break;}
        if(isset($extra['plugin']))$resources['option:'.get_current_blog_id().':active_plugins']=LOCK_EX;
        ksort($resources,SORT_STRING);$locks=[];
        foreach($resources as $key=>$mode)$locks[StateStore::directory('locks').'/'.hash('sha256',$key).'.php']=$mode;
        $state=$extra+['id'=>$id,'status'=>'armed','target'=>$target,'preimage'=>$preimage,'before_sha256'=>Engine::digest($before),'after_sha256'=>$after,'lease_until'=>time()+120,'locks'=>$locks,'time'=>time(),'user_id'=>get_current_user_id(),'connection_id'=>ConnectionContext::key()];
        Engine::write($journal,$state);$handle=fopen($journal.'.lease','c+b');
        if(!$handle||!flock($handle,LOCK_EX|LOCK_NB))throw new \RuntimeException('Recovery lease unavailable.');
        $backup=$before!==null?Backups::create_snapshot('recovery',['journal_id'=>$id,'target'=>$target,'before_sha256'=>$state['before_sha256'],'kind'=>$before['kind']]):null;
        if(is_wp_error($backup)){flock($handle,LOCK_UN);fclose($handle);throw new \RuntimeException('Preimage index unavailable.');}
        $state['backup_id']=$backup;Engine::write($journal,$state);
        return ['state'=>$state,'file'=>$journal,'lease'=>$handle];
    }
    public static function close(array &$operation,string $status): void {
        $operation['state']=array_replace($operation['state'],Engine::read($operation['file'])??[]);$operation['state']['status']=$status;$operation['state']['finished_at']=time();Engine::write($operation['file'],$operation['state']);Engine::finish_install($operation['file']);
    }
    public static function release(array $operation): void {if(is_resource($operation['lease'])){flock($operation['lease'],LOCK_UN);fclose($operation['lease']);}}
    public static function verified(array $probe): bool {return !empty($probe['success'])&&!empty($probe['passed'])&&!empty($probe['cache_bypass_verified']);}
    public static function runtime_path(string $path): bool {return in_array(strtolower(pathinfo($path,PATHINFO_EXTENSION)),['php','phtml','php5','php7','php8','phar','inc'],true);}
    /** Invoked inside the ordinary file sidecar lock; never calls the public restore ability. */
    public static function file(string $path,?string $content,callable $mutate,array $input=[]) {
        if(!self::runtime_path($path))return $mutate();
        if(array_key_exists('backup',$input)&&$input['backup']===false)return new \WP_Error('runtime_backup_required','PHP exige pré-imagem durável e sonda de execução.');
        $before=Probe::run();if(!self::verified($before))return new \WP_Error('runtime_baseline_failed','A sonda inicial não comprovou home/REST e PHP novo; arquivo não alterado.',['applied'=>false,'probe_before'=>$before]);
        $mode=$input['post_mode']??(is_file($path)?fileperms($path)&0777:(defined('FS_CHMOD_FILE')?FS_CHMOD_FILE:0644));
        $after=$content===null?null:Engine::digest(['kind'=>'file','files'=>[''=>['sha256'=>hash('sha256',$content),'bytes'=>strlen($content),'mode'=>$mode]]]);
        $op=self::begin($path,$after);$evidence=['operation_id'=>$op['state']['id'],'backup_id'=>$op['state']['backup_id'],'probe_before'=>$before];
        try {
            $result=$mutate();
            // Invalidate deletions/moves before the new-request probe, not after it.
            if(function_exists('opcache_invalidate'))@opcache_invalidate($path,true);
            $actual=Engine::digest(Engine::manifest($path));
            if($actual===$op['state']['before_sha256']){self::close($op,'unchanged');return $result;}
            if($actual!==$after){self::close($op,'recovery_required');return new \WP_Error('runtime_postimage_mismatch','Pós-imagem diverge da escrita pretendida; requer reconciliação.',$evidence+['applied'=>null,'recovery_status'=>'recovery_required']);}
            self::close($op,'applied');$probe=Probe::run();$evidence['probe_after']=$probe;
            if(is_wp_error($result)||$result===false||!self::verified($probe)){
                $restore=Engine::restore($op['file'],true);$evidence['recovery']=$restore;$evidence['probe_recovery']=Probe::run();
                return new \WP_Error($restore['status']==='rolled_back'?'runtime_verification_failed':$restore['status'],'Alteração não aprovada pela sonda; consulte o estado da recuperação.',$evidence+['applied'=>$restore['status']==='rolled_back'?false:null,'changed'=>$restore['status']==='rolled_back'?false:null,'attempted_change'=>true,'recovery_status'=>$restore['status']]);
            }
            self::close($op,'complete');self::$evidence[]=$evidence+['recovery_status'=>'applied'];return $result;
        } finally {self::release($op);}
    }
    public static function evidence(): array {$rows=self::$evidence;self::$evidence=[];return $rows;}
}
