<?php
/** Authenticated identity and per-connection restrictions, independent of MCP sessions. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ConnectionContext {
	private static ?array $identity = null;
	public static function init(): void {
		add_action('application_password_did_authenticate', static function($user,$item): void {
			self::$identity = ['user_id'=>(int)$user->ID,'connection_id'=>'app:'.$item['uuid'],'transport'=>'wordpress-application-password','legacy'=>(int)($item['created']??time()) < (int)get_option('f3_mcp_policy_installed_at',0)];
		}, 10, 2);
	}
	/** Called only after BearerAuth has validated the token and WP user. */
	public static function oauth(array $payload): void {
		self::$identity = ['user_id'=>(int)$payload['user_id'],'connection_id'=>!empty($payload['grant_id']) ? 'grant:'.$payload['grant_id'] : 'legacy-oauth:'.hash('sha256',serialize([$payload['user_id'],$payload['client_id']??''])),'grant_id'=>$payload['grant_id']??'','client_id'=>$payload['client_id']??'','transport'=>'oauth','legacy'=>empty($payload['grant_id'])||($payload['profile']??'')==='legacy','profile'=>$payload['profile']??null];
	}
	public static function credential_active(string $id,int $user): bool {
        if(str_starts_with($id,'app:'))return class_exists('WP_Application_Passwords') && is_array(\WP_Application_Passwords::get_user_application_password($user,substr($id,4)));
        if(str_starts_with($id,'grant:')){$g=Persistence::get('oauth-grants',substr($id,6));return $g&&($g['_storage']['status']??'')==='active'&&(int)($g['user_id']??0)===$user&&(!isset($g['expires'])||!$g['expires']||$g['expires']>time());}
        return true;
    }
    public static function get(): ?array {
		$user=get_current_user_id(); if (!$user) return null;
		$identity=self::$identity;
		if (!$identity || $identity['user_id']!==$user) $identity=['user_id'=>$user,'connection_id'=>'integration:user:'.$user,'transport'=>'wordpress-identity','legacy'=>false];
		if(!self::credential_active($identity['connection_id'],$user))return null;
        $row=Persistence::get('connections',$identity['connection_id']);
		if (!$row) {
			// New identities get no implicit administrative profile. A legacy credential
			// receives only the frozen pre-upgrade catalog during its migration window.
			$profile=$identity['profile']??(!empty($identity['legacy'])?'legacy':'unconfigured');
			$row=$identity+['profile'=>$profile,'status'=>'active','policy_version'=>1,'time'=>time(),'expires'=>$profile==='legacy'?(int)get_option('f3_mcp_policy_installed_at',time())+7*DAY_IN_SECONDS:0,'allow_backup_export'=>false];
			Persistence::put('connections',$identity['connection_id'],$row,true);
			$row=Persistence::get('connections',$identity['connection_id']);
		}
		if (($row['_storage']['status']??'')!=='active' || (int)$row['user_id']!==$user || !empty($row['expires']) && (int)$row['expires']<=time()) return null;
		if (!empty($identity['grant_id'])) {
			$grant=Persistence::get('oauth-grants',$identity['grant_id']);
			if (!$grant || ($grant['_storage']['status']??'')!=='active') return null;
		}
		if(($row['last_seen']??0)<time()-60)Persistence::touch_connection($identity['connection_id']);
        return array_replace($row,['transport'=>$identity['transport']]);
	}
	public static function key(): string { return (string)(self::get()['connection_id']??'unauthorized'); }
}

final class AuthorizationPolicy {
	public static function executor(\WP_Ability $ability): bool {
		$meta=$ability->get_meta(); $schema=$ability->get_input_schema();
		return !empty($meta['fator3']['executes_ability']) || in_array($ability->get_name(), ['wp-mcp-ultimate/execute-ability','wp-mcp-ultimate/execute-readonly-ability','mcp-adapter/execute-ability'],true) || isset($schema['properties']['ability_name']) && (isset($schema['properties']['parameters']) || isset($schema['properties']['input']));
	}
	public static function readonly(\WP_Ability $ability): bool {
		$meta=$ability->get_meta();
		return !self::executor($ability) && Providers::known((string)($meta['fator3']['provider']??'')) && !empty($meta['annotations']['readonly']);
	}
	public static function check(string $name, array $input=[], bool $read=false, bool $discovery=false) {
		$context=ConnectionContext::get();
		if (!$context) return new \WP_Error('connection_context_required','Identidade autenticada e perfil configurado são necessários para esta habilidade.');
		$profile=$context['profile']??'unconfigured';
		$allow=false;
		if ($profile==='legacy') $allow=in_array($name,(array)get_option('f3_mcp_legacy_catalog',[]),true);
		elseif ($profile==='maintenance') $allow=true;
		elseif ($profile==='read') $allow=$read && !preg_match('~^(files|db|users|backups|audit)/~',$name);
		elseif ($profile==='content') $allow=($read && !preg_match('~^(files|db|users|backups|audit)/~',$name)) || (bool)preg_match('~^(content|media|comments|menus|widgets)/~',$name);
		elseif ($profile==='custom') $allow=in_array($name,(array)($context['abilities']??[]),true);
		if (!$allow) return new \WP_Error('profile_denied','A habilidade não está autorizada no perfil desta conexão.');
		if (str_starts_with($name,'backups/export') && empty($context['allow_backup_export'])) return new \WP_Error('backup_export_denied','Exportar valores originais exige permissão explícita de recuperação.');
		if (!$discovery) {
            if(str_starts_with($name,'backups/export')&&isset($input['backup_id'])){
                $backup=Backups::metadata($input['backup_id'],false);if(is_wp_error($backup))return $backup;
                if(($backup['kind']??'')==='file'){$scope=self::check('files/read',['path'=>$backup['path']],true);if(is_wp_error($scope))return $scope;}
                elseif(($backup['connection_id']??'')!==$context['connection_id']&&empty($context['allow_foreign_backup_export']))return new \WP_Error('backup_scope_denied','Backup fora da conexão; migração/recuperação de outro acervo exige autorização adicional.');
            }
			if (!empty($context['post_types']) && str_starts_with($name,'content/')) {
				$type=!empty($input['id'])?get_post_type((int)$input['id']):($input['post_type']??(str_contains($name,'page')?'page':'post'));
				if (!in_array($type,(array)$context['post_types'],true)) return new \WP_Error('profile_post_type_denied','Tipo de conteúdo fora do perfil.');
			}
			if (str_starts_with($name,'files/') && $profile!=='legacy') {
				$roots=$context['roots']??[];
				if (!$roots) return new \WP_Error('profile_path_required','Configure raízes de arquivos explícitas para esta conexão.');
				$paths=[]; foreach(['path','source','destination'] as $key) if(isset($input[$key])) $paths[]=$input[$key];
				if ($name==='files/restore' && isset($input['backup_id'])) { $backup=Backups::metadata($input['backup_id'],false); if(is_wp_error($backup)) return $backup; $paths[]=$backup['path']??''; }
				foreach($paths as $requested) {
					$path=Locks::path((string)$requested); if(is_wp_error($path)) return $path; $inside=false;
					foreach($roots as $root) { $root=realpath($root); if($root && ($path===wp_normalize_path($root)||str_starts_with($path,rtrim(wp_normalize_path($root),'/').'/'))) $inside=true; }
					if(!$inside) return new \WP_Error('profile_path_denied','Caminho fora das raízes autorizadas.');
				}
			}
			if ($name==='db/execute' && $profile!=='legacy' && empty($context['database_write'])) return new \WP_Error('profile_database_write_denied','Escrita SQL exige permissão administrativa explícita.');
		}
		return true;
	}
	public static function freeze_legacy(): void {
		if (get_option('f3_mcp_legacy_catalog',null)!==null) return;
		$baseline=json_decode((string)file_get_contents(F3_MCP_FILES_DIR.'includes/legacy-abilities.json'),true);
		foreach(wp_get_abilities() as $ability) { $meta=$ability->get_meta(); if(empty($meta['fator3']['owned']) && !empty($meta['mcp']['public'])) $baseline[]=$ability->get_name(); }
		$baseline=array_values(array_unique($baseline)); sort($baseline); add_option('f3_mcp_legacy_catalog',$baseline,'',false);
	}
}

final class Providers {
	private static array $providers=[];
	public static function register(string $id,string $version,array $prefixes): void { self::$providers[$id]=['id'=>$id,'version'=>$version,'prefixes'=>$prefixes]; }
	public static function all(): array {return array_values(self::$providers);}
	public static function known(string $id): bool { return isset(self::$providers[$id]); }
	public static function metadata(string $name): array {
		foreach(self::$providers as $provider) foreach($provider['prefixes'] as $prefix) if(str_starts_with($name,$prefix)) return ['provider'=>$provider['id'],'version'=>$provider['version'],'result_contract'=>2];
		return ['provider'=>'unknown','version'=>null,'version_reason'=>'Provedor sem registro explícito.'];
	}
}
