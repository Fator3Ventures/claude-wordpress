<?php
/** Local administrator view. Values come from ConnectionsAdmin::render(). */
namespace Fator3\McpFiles;
$profiles = ['read'=>'Leitura','content'=>'Conteúdo','maintenance'=>'Manutenção','custom'=>'Personalizado','legacy'=>'Exceção Legado temporária'];
$states = ['active'=>'Ativa','revoked'=>'Revogada','expired'=>'Expirada','disabled'=>'Desabilitada'];
?>
<section class="f3-card">
<h2>Conexões e perfis</h2>
<p>O perfil limita o MCP e preserva as permissões do usuário WordPress. Use usuários de serviço por função. Integrações identificadas apenas pelo usuário compartilham a mesma política.</p>
<p>Legado é transitório. Crie a credencial substituta, teste no conector e só então revogue a antiga.</p>
<div class="f3-table-scroll" tabindex="0" role="region" aria-label="Conexões e perfis">
<table class="widefat striped f3-connections-table"><thead><tr><th>Identidade</th><th>Usuário</th><th>Perfil</th><th>Estado</th><th>Expira (UTC)</th><th>Último acesso (UTC)</th><th>Cliente / sessões</th><th>Migração</th><th>Ação</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr>
<td><code><?php echo esc_html($row['connection_id']); ?></code><br><?php echo esc_html($row['label']??''); ?></td>
<td><?php echo esc_html((string)$row['user_id']); ?></td>
<td><?php echo esc_html($profiles[$row['profile']??'']??'Sem perfil'); ?></td>
<td><?php echo esc_html($states[$row['status']??'active']??$row['status']); ?></td>
<td><?php echo esc_html(empty($row['expires'])?'—':gmdate('d/m/Y H:i',$row['expires'])); ?></td>
<td><?php echo esc_html(empty($row['last_seen'])?'Ainda não observado':gmdate('d/m/Y H:i',$row['last_seen'])); ?></td>
<td><?php echo esc_html(($row['client_id']??'Senha/integração').' · '.$session_counts[$row['connection_id']].' sessões legadas'); ?></td>
<td><?php echo esc_html(($row['replacement_connection_id']??'Sem substituta').' · '.($row['migration_owner']??'').' · '.($row['migration_deadline']??'')); ?></td>
<td><a href="<?php echo esc_url(add_query_arg('connection',$row['connection_id'],Admin::url('connections'))); ?>">Editar</a></td>
</tr>
<?php endforeach; ?>
</tbody></table></div>
<p>Até 50 conexões por página, das mais recentes para as antigas. Revogar uma concessão OAuth encerra sua família de tokens. A identidade legacy-oauth abrange usuário e cliente; não distingue credenciais que o histórico não identifica.</p>
<?php if ($more): ?><p><a class="button" href="<?php echo esc_url(add_query_arg('before_id',end($rows)['_row_id'],Admin::url('connections'))); ?>">Conexões anteriores</a></p><?php endif; ?>
</section>
<section class="f3-card">
<h2><?php echo $editing?'Editar identidade':'Configurar uma identidade'; ?></h2>
<?php if ($editing): ?><p>Valores atuais carregados. <a href="<?php echo esc_url(Admin::url('connections')); ?>">Configurar outra identidade ou emitir nova credencial</a></p><?php endif; ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<?php wp_nonce_field('f3_mcp_connection'); ?>
<input type="hidden" name="action" value="f3_mcp_connection">
<?php if ($editing): ?><input type="hidden" name="expected_policy_version" value="<?php echo esc_attr((string)($values['policy_version']??0)); ?>"><?php endif; ?>
<p><label>Usuário <select name="user_id">
<?php foreach ($users as $user): ?><option value="<?php echo esc_attr((string)$user->ID); ?>" <?php selected((int)($values['user_id']??0),(int)$user->ID); ?>><?php echo esc_html($user->user_login.' (#'.$user->ID.')'); ?></option><?php endforeach; ?>
</select></label></p>
<p><label>Identidade <input name="connection_id" class="regular-text" list="f3-identities" value="<?php echo esc_attr($values['connection_id']??''); ?>" <?php echo $editing?'readonly':''; ?>></label></p>
<datalist id="f3-identities">
<?php foreach ($users as $user): ?>
<option value="integration:user:<?php echo esc_attr((string)$user->ID); ?>">Integração do usuário <?php echo esc_html($user->user_login); ?></option>
<?php foreach (\WP_Application_Passwords::get_user_application_passwords($user->ID) as $app): ?><option value="app:<?php echo esc_attr($app['uuid']); ?>"><?php echo esc_html($user->user_login.' — '.$app['name']); ?></option><?php endforeach; ?>
<?php endforeach; ?>
<?php foreach ($rows as $row): ?><option value="<?php echo esc_attr($row['connection_id']); ?>"></option><?php endforeach; ?>
</datalist>
<p><label>Nome <input name="label" maxlength="128" value="<?php echo esc_attr($values['label']??''); ?>"></label></p>
<p><label>Perfil <select name="profile"><?php foreach ($profiles as $key=>$label): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($values['profile']??'read',$key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label></p>
<details><summary>Mapa de migração desta identidade</summary><p>Estes campos registram o trabalho do operador. Salvar não revoga ou testa a conexão.</p>
<?php foreach (['replacement_connection_id'=>'Identidade substituta','migration_owner'=>'Responsável operacional','migration_deadline'=>'Prazo UTC (ISO 8601)','migration_tasks'=>'Tarefas e estado da migração'] as $key=>$label): ?>
<p><label><?php echo esc_html($label); ?> <input class="regular-text" name="<?php echo esc_attr($key); ?>" maxlength="512" value="<?php echo esc_attr($values[$key]??''); ?>"></label></p>
<?php endforeach; ?>
</details>
<?php foreach (['roots'=>'Raízes absolutas de arquivos (uma por linha)','abilities'=>'Habilidades do perfil Personalizado','meta_keys'=>'Exceções de metadados não registrados (chaves exatas)','post_types'=>'Tipos de conteúdo permitidos (vazio: todos)'] as $key=>$label): ?>
<p><label><?php echo esc_html($label); ?><br><textarea name="<?php echo esc_attr($key); ?>" rows="3" class="large-text code"><?php echo esc_textarea(implode("\n",$values[$key]??[])); ?></textarea></label></p>
<?php endforeach; ?>
<?php foreach (['allow_backup_export'=>'Permitir exportar backups com os valores originais','allow_foreign_backup_export'=>'Incluir backups de outras conexões e legados (recuperação administrativa)','database_write'=>'Permitir escrita SQL administrativa','readonly_executor'=>'Expor Execute Readonly Ability'] as $key=>$label): ?>
<p><label><input type="checkbox" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(!empty($values[$key])); ?>> <?php echo esc_html($label); ?></label></p>
<?php endforeach; ?>
<p><label>Expira em (UTC) <input type="datetime-local" name="expires" value="<?php echo esc_attr(empty($values['expires'])?'':gmdate('Y-m-d\TH:i',$values['expires'])); ?>"></label></p>
<p><label>Justificativa da exceção Legado <textarea name="exception_reason"><?php echo esc_textarea($values['exception_reason']??''); ?></textarea></label></p>
<p><button class="button button-primary" name="intent" value="save">Salvar perfil</button>
<?php if (!$editing): ?><button class="button" name="intent" value="create">Emitir nova senha com este perfil</button><?php endif; ?>
<button class="button f3-danger" name="intent" value="revoke">Revogar esta identidade</button></p>
</form></section>
