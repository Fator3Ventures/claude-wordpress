<?php
if(!current_user_can('manage_options'))return;
echo '<section class="f3-card"><h2>Manual de operação instalado</h2><details><summary>Abrir manual</summary><pre style="white-space:pre-wrap">'.esc_html((string)file_get_contents(F3_MCP_FILES_DIR.'docs/OPERACAO.md')).'</pre></details></section>';
