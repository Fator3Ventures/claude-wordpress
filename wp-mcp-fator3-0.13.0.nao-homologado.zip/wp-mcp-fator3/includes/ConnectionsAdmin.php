<?php
/** Local administrator management. No secrets are displayed or accepted as identity. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class ConnectionsAdmin {
    public static function init(): void { add_action('admin_post_f3_mcp_connection',[self::class,'submit']); }
    public static function save(array $input): array {
        if(!current_user_can('manage_options'))return Result::fail('permission_denied','Permissão insuficiente.');
        $id=(string)($input['connection_id']??'');$user=(int)($input['user_id']??0);
        if(!$user||!get_userdata($user)||!current_user_can('edit_user',$user))return Result::fail('connection_user_invalid','Selecione um usuário que você possa gerenciar.');
        if(($input['intent']??'')==='create'){
            if(!wp_is_application_passwords_available_for_user($user))return Result::fail('application_password_unavailable','Senhas de aplicação indisponíveis para este usuário/ambiente.');
            if(empty($input['label']))return Result::fail('connection_label_required','Dê um nome que identifique o conector.');
            $created=\WP_Application_Passwords::create_new_application_password($user,['name'=>sanitize_text_field($input['label'])]);
            if(is_wp_error($created))return Result::fail('credential_creation_failed','WordPress recusou emissão da credencial.');
            [$password,$item]=$created;$next=$input;$next['intent']='save';$next['connection_id']='app:'.$item['uuid'];$result=self::save($next);
            if(empty($result['success'])){\WP_Application_Passwords::delete_application_password($user,$item['uuid']);return $result;}
            return $result+['application_password'=>$password,'user_login'=>get_userdata($user)->user_login,'credential_created'=>true];
        }
        if(str_starts_with($id,'app:')) {
            $uuid=substr($id,4);$item=\WP_Application_Passwords::get_user_application_password($user,$uuid);
            if(!$item && !(($input['intent']??'')==='revoke' && (int)(Persistence::get('connections',$id)['user_id']??0)===$user))return Result::fail('connection_credential_missing','Senha de aplicação não existe para esse usuário.');
        } elseif($id==='integration:user:'.$user) { /* Explicit server-side user mapping; not per-credential isolation. */ }
        elseif(str_starts_with($id,'grant:')) {
            $grant=Persistence::get('oauth-grants',substr($id,6));
            if(!$grant||(int)$grant['user_id']!==$user)return Result::fail('connection_grant_missing','Concessão não pertence ao usuário.');
        } elseif(str_starts_with($id,'legacy-oauth:')) {
            $old=Persistence::get('connections',$id);if(!$old||(int)$old['user_id']!==$user)return Result::fail('connection_invalid','Identidade legada não reconhecida.');
        } else return Result::fail('connection_invalid','Selecione uma identidade autenticada ou o usuário da integração.');
        return Locks::run(['connection:'.$id=>LOCK_EX],static function()use($input,$id,$user) {
            $old=Persistence::get('connections',$id)??['time'=>time()];
            if(isset($input['expected_policy_version']) && (int)$input['expected_policy_version'] !== (int)($old['policy_version']??0))return Result::fail('connection_policy_conflict','O perfil foi alterado em outra tela. Reabra a identidade antes de salvar ou revogar.',['conflict'=>true]);
            if(($input['intent']??'')==='revoke') {
                if(str_starts_with($id,'app:') && \WP_Application_Passwords::get_user_application_password($user,substr($id,4))) { $r=\WP_Application_Passwords::delete_application_password($user,substr($id,4));if(is_wp_error($r))return Result::fail('credential_revocation_failed','Não foi possível revogar a senha.'); }
                if(str_starts_with($id,'grant:')) { $key=substr($id,6);$grant=Persistence::get('oauth-grants',$key);$grant['status']='revoked';Persistence::put('oauth-grants',$key,$grant); }
                $old['status']='revoked';$old['user_id']=$user;$old['connection_id']=$id;Persistence::put('connections',$id,$old);
                try {Persistence::revoke_sessions($id);}catch(\Throwable $error){return Result::fail('session_revocation_pending','Identidade revogada; marcação das sessões pendente. As chamadas continuam bloqueadas pelo contexto.',['revoked'=>true,'connection_id'=>$id,'applied'=>true]);}
                return Result::ok(['changed'=>true,'revoked'=>true,'scope'=>str_starts_with($id,'legacy-oauth:')?'legacy_user_and_client':(str_starts_with($id,'integration:')?'wordpress_user_integration':'credential')]);
            }
            if(($old['_storage']['status']??'')==='revoked')return Result::fail('connection_revoked','Emita nova credencial; identidade revogada não pode ser reaberta.');
            $profile=(string)($input['profile']??'');
            if(!in_array($profile,['read','content','maintenance','custom','legacy'],true))return Result::fail('profile_invalid','Perfil inválido.');
            $expires=empty($input['expires'])?0:strtotime((string)$input['expires']);
            if($expires===false||$expires&&$expires<=time())return Result::fail('expiration_invalid','Expiração precisa estar no futuro.');
            if($profile==='legacy'&&(!$expires||empty($input['exception_reason'])))return Result::fail('legacy_exception_required','Legado exige justificativa e prazo explícitos.');
            $roots=[];foreach(preg_split('/\r?\n/',trim((string)($input['roots']??'')))?:[] as $path)if($path!=='') { $root=realpath(trim($path));if(!$root||!is_dir($root))return Result::fail('profile_root_invalid','Uma raiz não é diretório existente.');$roots[]=wp_normalize_path($root); }
            $abilities=preg_split('/[\s,]+/',trim((string)($input['abilities']??'')),-1,PREG_SPLIT_NO_EMPTY)?:[];
            foreach($abilities as $ability)if(!wp_get_ability($ability))return Result::fail('profile_ability_invalid','Habilidade não registrada.');
            $post_types=preg_split('/[\s,]+/',trim((string)($input['post_types']??'')),-1,PREG_SPLIT_NO_EMPTY)?:[];
            foreach($post_types as $type)if(!post_type_exists($type))return Result::fail('profile_post_type_invalid','Tipo de conteúdo não registrado.');
            $replacement=trim((string)($input['replacement_connection_id']??($old['replacement_connection_id']??'')));
            if($replacement!=='') {
                $next=Persistence::get('connections',$replacement);
                if($replacement===$id||!$next||($next['_storage']['status']??'')!=='active'||!current_user_can('edit_user',(int)$next['user_id']))return Result::fail('migration_replacement_invalid','Selecione uma identidade substituta ativa que você possa gerenciar.');
            }
            $deadline=trim((string)($input['migration_deadline']??($old['migration_deadline']??'')));
            if($deadline!==''&&strtotime($deadline)===false)return Result::fail('migration_deadline_invalid','Informe prazo UTC válido.');
            $row=['user_id'=>$user,'connection_id'=>$id,'profile'=>$profile,'status'=>'active','time'=>$old['time'],'policy_version'=>(int)($old['policy_version']??0)+1,'expires'=>$expires,'roots'=>$roots,'abilities'=>$abilities,'post_types'=>$post_types,'meta_keys'=>preg_split('/[\s,]+/',trim((string)($input['meta_keys']??'')),-1,PREG_SPLIT_NO_EMPTY)?:[],'allow_backup_export'=>!empty($input['allow_backup_export']),'allow_foreign_backup_export'=>!empty($input['allow_foreign_backup_export']),'database_write'=>!empty($input['database_write']),'readonly_executor'=>!empty($input['readonly_executor']),'exception_reason'=>sanitize_textarea_field($input['exception_reason']??''),'label'=>sanitize_text_field($input['label']??'')];
            $row+=['replacement_connection_id'=>$replacement,'migration_owner'=>sanitize_text_field($input['migration_owner']??($old['migration_owner']??'')),'migration_deadline'=>$deadline,'migration_tasks'=>sanitize_textarea_field($input['migration_tasks']??($old['migration_tasks']??''))];
            $row=array_replace($old,$row);
            Persistence::put('connections',$id,$row);
            return Result::ok(['changed'=>true,'persisted'=>true,'connection_id'=>$id,'profile'=>$profile]);
        });
    }
    public static function submit(): void {
        if(!current_user_can('manage_options'))wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer('f3_mcp_connection');
        $input=wp_unslash($_POST);$result=self::save($input);
        Audit::record('admin/connection',['name'=>$input['connection_id']??''],$result,0);
        if(!empty($result['credential_created'])){
            nocache_headers();$html='<h1>Credencial criada</h1><p>Copie agora. A senha não será exibida novamente.</p><p>Usuário: <code>'.esc_html($result['user_login']).'</code></p><p>Senha: <code>'.esc_html($result['application_password']).'</code></p><p>Identidade: <code>'.esc_html($result['connection_id']).'</code></p><p>Perfil: '.esc_html($result['profile']).'. Configure e teste o conector antes de revogar a credencial anterior.</p><p><a href="'.esc_url(Admin::url('connections')).'">Voltar às conexões</a></p>';
            wp_die($html,'Nova credencial',['response'=>200]);
        }
        $key=wp_generate_uuid4();set_transient('f3_mcp_notice_'.get_current_user_id().'_'.$key,['success'=>$result['success'],'message'=>$result['message']??($result['success']?'Conexão atualizada.':'Falha na atualização.')],60);
        wp_safe_redirect(add_query_arg('notice',$key,Admin::url('connections')));exit;
    }
    public static function render(): void {
        if (!current_user_can('manage_options')) return;
        $before = max(1, (int) ($_GET['before_id'] ?? PHP_INT_MAX));
        $rows = Persistence::listing('connections', [], 51, $before);
        $more = count($rows) > 50;
        $rows = array_slice($rows, 0, 50);
        $users = get_users(['number' => 100, 'orderby' => 'ID']);
        $editing = null;
        $id = sanitize_text_field(wp_unslash($_GET['connection'] ?? ''));
        if ($id !== '') {
            $candidate = Persistence::get('connections', $id);
            if ($candidate && current_user_can('edit_user', (int) $candidate['user_id'])) {
                $editing = $candidate;
                if (!in_array((int) $candidate['user_id'], array_map(static fn($u) => (int) $u->ID, $users), true)) {
                    $user = get_userdata((int) $candidate['user_id']);
                    if ($user) $users[] = $user;
                }
            }
        }
        $values = $editing ?? [];
        $session_counts = [];
        global $wpdb;
        $table = Persistence::table('sessions');
        foreach ($rows as $row) {
            $session_counts[$row['connection_id']] = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM `$table` WHERE connection_id=%s AND status='active' AND expires_at>%d",
                $row['connection_id'], time()
            ));
        }
        require __DIR__ . '/views/connections-form.php';
    }
}
