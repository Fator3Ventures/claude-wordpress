<?php
/** Resumable uploads and authorized backup streaming. Private bytes never enter audit metadata. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;

final class Transfers {
    private const PART_BYTES=262144;
    public static function register(): void {
        $id=['transfer_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{32}$']];$hash=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        Registry::add('files/upload-create','Inicia upload privado em partes de 256 KiB, até o limite do canal (16 MiB padrão). Vinculado à conexão/destino/hash, expira em 24h; no máximo quatro uploads ativos por conexão. Não altera o destino.',['path'=>Registry::string(),'total_bytes'=>Registry::integer(0,min(PathGuard::max_bytes(),16777216)),'sha256'=>$hash,'expected_sha256'=>$hash,'label'=>Registry::string(),'rotulo'=>Registry::string()],['path','total_bytes','sha256'],[self::class,'create'],[FileTools::class,'permission'],false);
        Registry::add('files/upload-part','Envia uma parte base64 com índice começando em zero. Repetir bytes idênticos é seguro; bytes diferentes no mesmo índice conflitam.',$id+['index'=>Registry::integer(0,1023),'content_base64'=>['type'=>'string','maxLength'=>349528]],['transfer_id','index','content_base64'],[self::class,'part'],[FileTools::class,'permission'],false);
        Registry::add('files/upload-status','Consulta índices recebidos, tamanho/hash e expiração sem expor bytes privados.',$id,['transfer_id'],[self::class,'status'],[FileTools::class,'permission']);
        Registry::add('files/upload-finalize','Monta as partes, confere hash, revalida perfil e grava pelo mesmo serviço de files/write, com lock, CAS, pré-imagem e sonda para PHP. Requer autorização para files/write.',$id,['transfer_id'],[self::class,'finish'],[FileTools::class,'permission'],false);
        Registry::add('files/upload-cancel','Cancela upload ainda não finalizado e remove somente suas partes privadas. Upload concluído não é desfeito.',$id,['transfer_id'],[self::class,'cancel'],[FileTools::class,'permission'],false);
        Registry::add('backups/export-part','Exporta JSON restaurável original em partes base64 de até 256 KiB. Pode conter segredos; base64 não cifra. Cursor vinculado à conexão, backup/hash e prazo. Permissão de exportação é reavaliada por chamada.',['backup_id'=>Registry::string(),'cursor'=>Registry::string(),'byte_limit'=>Registry::integer(1,self::PART_BYTES)],['backup_id'],[self::class,'export'],[FileTools::class,'permission']);
    }
    private static function directory(string $id): string {return StateStore::directory('transfers').'/'.$id;}
    private static function get(string $id,bool $allow_expired=false) {
        if(!preg_match('/^[a-f0-9]{32}$/D',$id))return new \WP_Error('transfer_invalid','Identificador de transferência inválido.');
        $state=StateStore::get('uploads',$id);
        if(!$state||$state['connection_id']!==ConnectionContext::key()||$state['user_id']!==get_current_user_id())return new \WP_Error('transfer_not_found','Transferência não pertence a esta conexão.');
        $permission=AuthorizationPolicy::check('files/write',['path'=>$state['path']],false);if(is_wp_error($permission))return $permission;
        if(!$allow_expired&&$state['status']!=='complete'&&$state['expires']<=time())return new \WP_Error('transfer_expired','Transferência expirada.');return $state;
    }
    public static function create(array $input): array {
        $permission=AuthorizationPolicy::check('files/write',['path'=>$input['path']],false);if(is_wp_error($permission))return Result::error($permission);
        $path=Locks::path($input['path']);if(is_wp_error($path))return Result::error($path);$ext=PathGuard::check_extension($path);if(is_wp_error($ext))return Result::error($ext);
        return Locks::run(['uploads-quota:'.ConnectionContext::key()=>LOCK_EX],static function()use($input,$path){
            global $wpdb;$table=Persistence::table('uploads');$count=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `$table` WHERE bucket='uploads' AND connection_id=%s AND (status='finalizing' OR (status='pending' AND expires_at>%d))",ConnectionContext::key(),time()));
            if($wpdb->last_error)return Result::fail('transfer_quota_unavailable','Não foi possível confirmar quota de transferências.');
            if((int)$count>=4)return Result::fail('transfer_capacity','Máximo de quatro uploads ativos por conexão.');
            $total=(int)$input['total_bytes'];if($total<0||$total>min(PathGuard::max_bytes(),16777216))return Result::fail('transfer_size_limit','Upload total limitado a 16 MiB.');$free=disk_free_space(StateStore::directory('transfers'));if($free!==false&&$free<$total*3+10485760)return Result::fail('transfer_disk_budget','Espaço insuficiente para partes, montagem e pré-imagem.');
            $id=bin2hex(random_bytes(16));if(!mkdir(self::directory($id),0700))return Result::fail('transfer_storage_failed','Diretório privado indisponível.');
            $state=['transfer_id'=>$id,'connection_id'=>ConnectionContext::key(),'user_id'=>get_current_user_id(),'status'=>'pending','path'=>$path,'total_bytes'=>$total,'sha256'=>$input['sha256'],'parts'=>[],'part_count'=>(int)ceil($total/self::PART_BYTES),'expected_sha256'=>$input['expected_sha256']??null,'label'=>$input['label']??null,'time'=>time(),'expires'=>time()+DAY_IN_SECONDS];
            StateStore::put('uploads',$id,$state);return Result::ok(['transfer_id'=>$id,'part_bytes'=>self::PART_BYTES,'part_count'=>$state['part_count'],'expires_at'=>gmdate('c',$state['expires']),'applied'=>false]);
        });
    }
    public static function part(array $input): array {
        return Locks::run(['upload:'.$input['transfer_id']=>LOCK_EX],static function()use($input){
            $s=self::get($input['transfer_id']);if(is_wp_error($s))return Result::error($s);if($s['status']!=='pending')return Result::fail('transfer_closed','Transferência não recebe mais partes.');
            $index=(int)$input['index'];if($index<0||$index>=$s['part_count'])return Result::fail('transfer_index_invalid','Índice fora do total esperado.');
            $bytes=base64_decode($input['content_base64'],true);$length=min(self::PART_BYTES,$s['total_bytes']-$index*self::PART_BYTES);
            if($bytes===false||strlen($bytes)!==$length)return Result::fail('transfer_part_size','Parte deve ter exatamente o tamanho anunciado para seu índice.');
            $hash=hash('sha256',$bytes);$path=self::directory($s['transfer_id']).'/'.$index.'.part';
            if(isset($s['parts'][$index]))return hash_equals($s['parts'][$index],$hash)&&is_file($path)&&hash_equals(hash_file('sha256',$path),$hash)?Result::ok(['changed'=>false,'index'=>$index,'sha256'=>$hash]):Result::fail('transfer_part_conflict','Índice já contém outros bytes.',['conflict'=>true]);
            Engine::atomic($path,$bytes,0600);$s['parts'][$index]=$hash;$s['updated_at']=time();StateStore::put('uploads',$s['transfer_id'],$s);
            return Result::ok(['changed'=>true,'index'=>$index,'sha256'=>$hash,'received'=>count($s['parts'])]);
        });
    }
    public static function status(array $input): array {
        $s=self::get($input['transfer_id']);if(is_wp_error($s))return Result::error($s);
        return Result::ok(array_intersect_key($s,array_flip(['transfer_id','status','total_bytes','sha256','part_count','expires']))+['received_indices'=>array_map('intval',array_keys($s['parts']))]);
    }
    public static function finish(array $input): array {
        return Locks::run(['upload:'.$input['transfer_id']=>LOCK_EX],static function()use($input){
            $s=self::get($input['transfer_id']);if(is_wp_error($s))return Result::error($s);
            if($s['status']==='complete')return array_replace($s['result'],['replayed'=>true]);if(!in_array($s['status'],['pending','finalizing'],true))return Result::fail('transfer_closed','Transferência encerrada.');
            if(count($s['parts'])!==$s['part_count'])return Result::fail('transfer_incomplete','Faltam partes.');
            $assembled=self::directory($s['transfer_id']).'/assembled.part';$out=fopen($assembled,'wb');if(!$out)return Result::fail('transfer_storage_failed','Montagem privada indisponível.');chmod($assembled,0600);$digest=hash_init('sha256');
            try{for($i=0;$i<$s['part_count'];$i++){$path=self::directory($s['transfer_id']).'/'.$i.'.part';$bytes=is_file($path)?file_get_contents($path):false;if($bytes===false||!hash_equals($s['parts'][$i],hash('sha256',$bytes)))return Result::fail('transfer_part_conflict','Parte ausente ou alterada.',['conflict'=>true]);hash_update($digest,$bytes);if(fwrite($out,$bytes)!==strlen($bytes))return Result::fail('transfer_storage_failed','Gravação incompleta da montagem.');}fflush($out);}finally{fclose($out);}
            if(!hash_equals($s['sha256'],hash_final($digest))||filesize($assembled)!==$s['total_bytes'])return Result::fail('transfer_hash_conflict','Digest/tamanho final diverge do anunciado.',['conflict'=>true]);
            return Locks::files([$s['path']],static function()use(&$s,$assembled){
                $permission=AuthorizationPolicy::check('files/write',['path'=>$s['path']],false);if(is_wp_error($permission))return Result::error($permission);
                $args=['path'=>$s['path'],'content_base64'=>base64_encode((string)file_get_contents($assembled)),'idempotency_key'=>'transfer:'.$s['transfer_id']];
                if($s['expected_sha256']!==null)$args['expected_sha256']=$s['expected_sha256'];if($s['label']!==null)$args['label']=$s['label'];
                $s['status']='finalizing';StateStore::put('uploads',$s['transfer_id'],$s);
                $r=Result::normalize(wp_get_ability('files/write')->execute($args));
                if(!empty($r['success'])){$s['status']='complete';$s['result']=$r;StateStore::put('uploads',$s['transfer_id'],$s);Engine::remove(self::directory($s['transfer_id']));}
                elseif(!empty($r['conflict'])){$s['status']='pending';StateStore::put('uploads',$s['transfer_id'],$s);}
                return $r;
            });
        });
    }
    public static function cancel(array $input): array {
        return Locks::run(['upload:'.$input['transfer_id']=>LOCK_EX],static function()use($input){$s=self::get($input['transfer_id'],true);if(is_wp_error($s))return Result::error($s);if($s['status']==='complete')return Result::ok(['changed'=>false,'status'=>'complete']);if($s['status']==='finalizing')return Result::fail('operation_uncertain','Finalização pendente de reconciliação.');$changed=$s['status']!=='cancelled';$s['status']='cancelled';StateStore::put('uploads',$s['transfer_id'],$s);if(is_dir(self::directory($s['transfer_id'])))Engine::remove(self::directory($s['transfer_id']));return Result::ok(['changed'=>$changed,'status'=>'cancelled']);});
    }
    public static function export(array $input): array {
        return Locks::run(['backups:'.get_current_blog_id()=>LOCK_SH],static function()use($input){
            $source=BackupExport::source($input['backup_id']);if(is_wp_error($source))return Result::error($source);$meta=$source['meta'];$file=$source['path'];
            $h=fopen($file,'rb');if(!$h)return Result::fail('backup_read_failed','Backup indisponível.');
            try {
                $header=fread($h,strlen(StateStore::HEADER));if($header!==StateStore::HEADER)return Result::fail('backup_corrupt','Envelope inválido.');
                $stat=fstat($h);$digest=hash_init('sha256');while(!feof($h)){$chunk=fread($h,65536);if($chunk===false)return Result::fail('backup_read_failed','Falha de leitura.');hash_update($digest,$chunk);}$sha=hash_final($digest);$size=$stat['size']-strlen(StateStore::HEADER);$offset=0;$expires=time()+900;
                if(!empty($input['cursor'])){$c=Cursor::decode($input['cursor']);if(is_wp_error($c))return Result::error($c);if(($c['kind']??'')!=='backup-export'||($c['id']??'')!==$input['backup_id']||($c['connection']??'')!==ConnectionContext::key()||($c['expires']??0)<time())return Result::fail('cursor_invalid','Cursor não pertence a esta conexão/backup ou expirou.');if(($c['sha256']??'')!==$sha)return Result::fail('backup_conflict','Backup mudou.',['conflict'=>true]);$offset=(int)$c['offset'];$expires=$c['expires'];}
                if($offset<0||$offset>$size)return Result::fail('cursor_invalid','Offset inválido.');$length=min($size-$offset,(int)($input['byte_limit']??self::PART_BYTES));fseek($h,strlen(StateStore::HEADER)+$offset);$bytes=$length?fread($h,$length):'';
                if($bytes===false||strlen($bytes)!==$length||array_intersect_key(fstat($h),array_flip(['dev','ino','size','mtime','ctime']))!==array_intersect_key($stat,array_flip(['dev','ino','size','mtime','ctime'])))return Result::fail('backup_conflict','Backup alterado durante leitura.',['conflict'=>true]);$next=$offset+$length;
                return Result::ok(['filename'=>$input['backup_id'].'.json','content_base64'=>base64_encode($bytes),'encoding'=>'base64','offset_bytes'=>$offset,'bytes'=>$length,'total_bytes'=>$size,'sha256'=>$sha,'part_sha256'=>hash('sha256',$bytes),'has_more'=>$next<$size,'next_cursor'=>$next<$size?Cursor::encode(['kind'=>'backup-export','id'=>$input['backup_id'],'connection'=>ConnectionContext::key(),'sha256'=>$sha,'offset'=>$next,'expires'=>$expires]):null,'backup_contains_sensitive_values'=>$meta['backup_contains_sensitive_values']??'unknown','notice'=>'Valores originais; base64 não é criptografia.']);
            }finally{fclose($h);}
        });
    }
}
