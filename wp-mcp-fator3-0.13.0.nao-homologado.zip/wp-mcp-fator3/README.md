# WP MCP Fator3 0.13.0

Fonte da próxima entrega única, **em desenvolvimento e sem homologação final**. Cabeçalho e constante identificam o alvo 0.13.0; a publicação estável depende do gate e ainda não foi realizada.

Servidor MCP integrado com OAuth e senhas de aplicação, perfis por conexão, ferramentas WordPress, arquivos, SQL controlado e recuperação. A URL principal permanece `/wp-json/mcp/wp-mcp-fator3`; o alias `/wp-json/mcp/wp-mcp-ultimate` é preservado. Copie a URL efetiva do painel em instalações por query/subdiretório.

Os três metatools continuam compatíveis. Descubra as habilidades e consulte o schema antes de executá-las. `system/guide` oferece o manual por tema; `system/capabilities` informa perfil/canais efetivos e `system/health` separa registro local de evidência de comunicação.

Documentação distribuída:

- `docs/OPERACAO.md`: contratos e exemplos implementados.
- `docs/CONTRATOS-INSTALADOS.json`: schemas após os decoradores.
- `docs/ATUALIZACAO.md`: migração, perfis e recuperação.
- `docs/COBERTURA-SEO.md`: responsabilidades de Yoast/Core/MCP.
- `docs/CONTRATO-EXTENSOES.md`: integração explícita de complementos.

Ambiente alvo: WordPress 7.1.2, PHP 8.3 e MySQL 8.0, single-site. O fluxo recuperável de pacotes exige filesystem direto e escrita em mu-plugins/acervo privado. O limite padrão de arquivos/ZIP é 16 MiB. Perfis não substituem capacidades WordPress nem isolam código PHP administrativo.

O núcleo Ultimate consolidado e a origem do adapter/schema são preservados com licenças e proveniência no fonte. Relatórios de teste estão no pacote de desenvolvimento. Nenhuma publicação de feed, atualização automática da frota ou rotação de credenciais ocorre apenas por instalar o código.
