<?php
/**
 * ErrorLogMcpErrorHandler class for logging MCP errors to PHP error log.
 *
 * @package McpAdapter
 */

declare( strict_types=1 );

namespace WpMcpUltimate\Server\Infrastructure\ErrorHandling;

/**
 * Class ErrorLogMcpErrorHandler
 *
 * This class handles error logging by writing logs to the PHP error log.
 *
 * @package WpMcpUltimate\Server\ErrorHandlers
 */
class ErrorLogMcpErrorHandler implements Contracts\McpErrorHandlerInterface {

	/**
	 * Log with context.
	 *
	 * @param string $message The log message.
	 * @param array $context Additional context data.
	 * @param string $type The type of log (e.g., 'error', 'info', etc.). Default is 'error'.
	 *
	 * @return void
	 */
	public function log( string $message, array $context = array(), string $type = 'error' ): void {
        // Callback exception messages and arbitrary context may contain credentials,
        // SQL or document content. Diagnostics accept only stable identifiers.
        $safe=[];
        foreach(['error_code','failure_reason','ability','ability_name','component_type','server_id','method'] as $key)if(isset($context[$key])&&is_string($context[$key])&&preg_match('~^[a-zA-Z0-9_./:-]{1,191}$~D',$context[$key]))$safe[$key]=$context[$key];
        $safe['user_id']=function_exists('get_current_user_id')?get_current_user_id():0;
        $safe['level']=in_array($type,['error','warning','info','debug'],true)?$type:'error';
        error_log('WP MCP Fator3: diagnostic '.wp_json_encode($safe));

	}
}
