<?php
/** Legacy protocol sessions. Identity is provided by authenticated credentials. */
declare(strict_types=1);
namespace WpMcpUltimate\Server\Transport\Infrastructure;
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\ConnectionContext;
use Fator3\McpFiles\Locks;
final class SessionManager {
    private static function timeout(): int { return max(60,(int)apply_filters('mcp_adapter_session_inactivity_timeout',DAY_IN_SECONDS)); }
    private static function key(int $user,string $id): string { return $user.':'.$id; }
    private static function import(int $user): void {
        if (Persistence::get('migration','sessions:'.$user)) return;
        $old=get_user_meta($user,'mcp_adapter_sessions',true);
        if(is_array($old)) foreach($old as $id=>$data) {
            if(!is_array($data) || (int)($data['last_activity']??0)+self::timeout()<=time()) continue;
            Persistence::put('sessions',self::key($user,(string)$id),$data+['session_id'=>$id,'user_id'=>$user,'status'=>'active','expires'=>(int)$data['last_activity']+self::timeout(),'legacy'=>true],true);
        }
        Persistence::put('migration','sessions:'.$user,['status'=>'complete','time'=>time()]);
    }
    public static function create_session(int $user,array $params=[], $error_handler=null) {
        if(!$user||!get_user_by('id',$user)) return false;
        $result=Locks::run(['session-user:'.$user=>LOCK_EX],static function() use($user,$params) {
            self::import($user); self::cleanup_expired_sessions($user);
            $max=max(1,min(128,(int)apply_filters('mcp_adapter_session_max_per_user',32)));
            if(count(Persistence::listing('sessions',['user_id'=>$user,'status'=>'active'],$max+1)) >= $max) return false;
            $id=wp_generate_uuid4(); $now=time();
            Persistence::put('sessions',self::key($user,$id),['session_id'=>$id,'user_id'=>$user,'connection_id'=>ConnectionContext::key(),'created_at'=>$now,'last_activity'=>$now,'client_params'=>array_intersect_key($params,['protocolVersion'=>true,'clientInfo'=>true,'capabilities'=>true]),'status'=>'active','expires'=>$now+self::timeout()],true);
            return $id;
        });
        return is_string($result)?$result:false;
    }
    public static function get_session(int $user,string $id) {
        if(!$user||!preg_match('/^[a-zA-Z0-9-]{1,128}$/D',$id)) return false;
        self::import($user); $row=Persistence::get('sessions',self::key($user,$id));
        if(!$row||($row['_storage']['status']??'')!=='active'||(int)($row['expires']??0)<=time()) return false;
        if(isset($row['connection_id']) && $row['connection_id']!==ConnectionContext::key()) return false;
        return $row;
    }
    public static function validate_session(int $user,string $id,$error_handler=null): bool {
        $row=self::get_session($user,$id); if(!$row) return false;
        if(time()-(int)$row['last_activity']>=60) {
            $result=Locks::run(['session:'.self::key($user,$id)=>LOCK_EX],static function() use($user,$id) {
                $row=self::get_session($user,$id); if(!$row) return false;
                $row['last_activity']=time(); $row['expires']=time()+self::timeout();
                Persistence::put('sessions',self::key($user,$id),$row); return true;
            });
            return true===$result;
        }
        return true;
    }
    public static function delete_session(int $user,string $id,$error_handler=null): bool {
        return true===Locks::run(['session:'.self::key($user,$id)=>LOCK_EX],static function()use($user,$id) { if(!self::get_session($user,$id))return false;return Persistence::delete('sessions',self::key($user,$id)); });
    }
    public static function get_all_user_sessions(int $user): array {
        if(!$user) return []; self::import($user); $out=[];
        foreach(Persistence::listing('sessions',['user_id'=>$user,'status'=>'active'],1000) as $row) if($row['expires']>time()) $out[$row['session_id']]=$row;
        return $out;
    }
    public static function cleanup_expired_sessions(int $user): int {
        $n=0;
        foreach(Persistence::listing('sessions',['user_id'=>$user,'status'=>'active'],1000) as $row) if($row['expires']<=time()) { Persistence::delete('sessions',self::key($user,$row['session_id']));$n++; }
        return $n;
    }
}
