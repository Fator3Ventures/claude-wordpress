<?php
/** One proposal/validation service for administrative and ability writes. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Redirects_Servico {
	const OPTION                     = 'f3base_redirects';
    const EVIDENCIA = 'f3base_redirects_evidencia_v2';
    const CONTRATO_PROVA = 2;
	private static array $historicos = array();
	public static function schema_lista(): array {
		return array(
			'type'     => 'array',
			'maxItems' => 200,
			'items'    => array(
				'type'                 => 'object',
				'required'             => array( 'de' ),
				'properties'           => array(
                    'preservar_query' => array('type'=>'boolean','default'=>true),
					'de'     => array(
						'type'      => 'string',
						'maxLength' => 2000,
					),
					'para'   => array(
						'type'      => 'string',
						'maxLength' => 2000,
					),
					'status' => array(
						'type' => 'integer',
						'enum' => array( 301, 302, 307, 308, 410 ),
					),
				),
				'additionalProperties' => true,
			),
		); }
	public static function registrar(): void {
		$rev   = array(
			'type'    => 'string',
			'pattern' => '^[a-f0-9]{64}$',
		);
		$lista = array(
			'type'     => 'array',
			'items'    => array( 'type' => 'string' ),
			'maxItems' => 200,
		);
		F3Base_Servicos::ability(
			'redirects-ler',
			'Ler redirects, revisão e restrições sem HTTP',
			array( __CLASS__, 'ler' ),
			array(
				'origens' => $lista,
				'pagina'  => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'limite'  => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => 50,
				),
			)
		);
		F3Base_Servicos::ability(
			'redirects-escrever',
			'Simular ou aplicar redirects com revisão e validação integral',
			array( __CLASS__, 'escrever' ),
			array(
				'operacao'               => array(
					'type' => 'string',
					'enum' => array( 'adicionar', 'alterar', 'remover', 'substituir_lista' ),
				),
				'pares'                  => self::schema_lista(),
				'origens'                => $lista,
				'revisao_esperada'       => $rev,
				'simular'                => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'sobrepor_conteudo_vivo' => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'adiar_purga'            => array(
					'type'    => 'boolean',
					'default' => false,
				),
			),
			array( 'operacao' ),
			false
		);
		F3Base_Servicos::ability(
			'redirects-verificar',
			'Consultar ou provar redirects por GET anônimo',
			array( __CLASS__, 'verificar' ),
			array(
				'acao'             => array(
					'type' => 'string',
					'enum' => array( 'consultar', 'verificar_publico' ),
				),
				'origens'          => $lista,
				'revisao_esperada' => $rev,
				'cursor'           => array(
					'type'    => 'integer',
					'minimum' => 0,
				),
			),
			array(),
			false
		);
		F3Base_Servicos::ability(
			'redirects-planejar-base-taxonomia',
			'Enumerar pares exatos de termos públicos para uma base antiga',
			array( __CLASS__, 'taxonomia' ),
			array(
				'taxonomia'        => array( 'type' => 'string' ),
				'de'               => array( 'type' => 'string' ),
				'para'             => array( 'type' => 'string' ),
				'revisao_esperada' => $rev,
			),
			array( 'taxonomia', 'de', 'para', 'revisao_esperada' )
		);
	}
	public static function caminho( $s ): ?string {
		if ( ! is_string( $s ) || strlen( $s ) > 500 || '' === $s || '/' !== $s[0] || str_starts_with( $s, '//' ) || preg_match( '/%(?![0-9a-f]{2})/i', $s ) ) {
			return null; }
		$dec = rawurldecode( $s );
		foreach ( array( $s, $dec ) as $p ) {
			if ( preg_match( '/[\x00-\x20\x7f\\\\?#]/', $p ) || str_contains( $p, '//' ) || preg_match( '~(?:^|/)[.]{1,2}(?:/|$)~', $p ) || preg_match( '//u', $p ) !== 1 ) {
				return null; }
		}
		// Reject double encoding of delimiters/controls instead of disagreeing with the server.
		if ( preg_match( '/%[0-9a-f]{2}/i', $dec ) || preg_match( '/%(?:2f|5c)/i', $s ) ) {
			return null; }
		return '/' . trim( $dec, '/' );
	}
    public static function externo(string $s): bool {
        $h=wp_parse_url($s,PHP_URL_HOST);return is_string($h)&&strtolower($h)!==strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST));
    }
    public static function absoluto(string $s): string {return wp_parse_url($s,PHP_URL_HOST)?$s:home_url($s);}
    public static function destino($s): ?string {
        if(!is_string($s)||strlen($s)>2000||$s===''||preg_match('/[\x00-\x20\x7f\\\\]/',$s)||preg_match('/%(?![a-f0-9]{2})/i',$s)||preg_match('/[\x00-\x1f\x7f]/',rawurldecode($s))){return null;}
        $p=wp_parse_url($s);if(!$p||isset($p['user'])||isset($p['pass'])||str_starts_with($s,'//')){return null;}
        $prefix='';if(isset($p['scheme'])||isset($p['host'])){
            $host=strtolower($p['host']??'');$own=strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST));
            if(!$host||($p['scheme']??'')!=='https'){if($host!==$own||($p['scheme']??'')!==wp_parse_url(home_url(),PHP_URL_SCHEME)){return null;}}
            if($host!==$own&&!in_array($host,F3Base_Options::ler('f3base_redirects_hosts'),true)){return null;}
            if(isset($p['port'])&&($host!==$own||(int)$p['port']!==(int)wp_parse_url(home_url(),PHP_URL_PORT))){return null;}
            $prefix=($p['scheme']??'https').'://'.$host.(isset($p['port'])?':'.$p['port']:'');
        }
        $path=self::caminho($p['path']??'/');if($path===null){return null;}if($path!=='/'&&str_ends_with($p['path']??'','/')){$path.='/';}
        return $prefix.$path.(isset($p['query'])?'?'.$p['query']:'').(isset($p['fragment'])?'#'.$p['fragment']:'');
    }
    /** QUERY_STRING survives WP Super Cache's stripping of tracking from REQUEST_URI. */
    public static function query_origem(): string {
        if (isset($_SERVER['QUERY_STRING']) && is_string($_SERVER['QUERY_STRING'])) { return wp_unslash($_SERVER['QUERY_STRING']); }
        return (string) (wp_parse_url(wp_unslash($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_QUERY) ?? '');
    }
    public static function query_valida(string $query): bool {
        return strlen($query) <= 8192 && !preg_match('/[\\x00-\\x20\\x7f\\\\]/', $query)
            && !preg_match('/[\\x00-\\x1f\\x7f]/', rawurldecode($query)) && !preg_match('/%(?![a-f0-9]{2})/i', $query);
    }
    /** Destination names win; preserve repeated raw pairs and a final fragment. Invalid source never cancels a valid redirect. */
    public static function preservar_query(string $destino, string $origem): ?string {
        $valid=self::destino($destino); if ($valid===null) { return null; }
        $p=wp_parse_url($valid); $source=(string)(wp_parse_url($origem,PHP_URL_QUERY)??'');
        if (!self::query_valida($source)) {
            return $valid;
        }
        $dst=$p['query']??''; $keys=array();
        foreach(explode('&',$dst) as $pair){if($pair!==''){$keys[urldecode(explode('=',$pair,2)[0])]=true;}}
        $pairs=$dst!==''?explode('&',$dst):array();
        foreach(explode('&',$source) as $pair){if($pair!==''&&!isset($keys[urldecode(explode('=',$pair,2)[0])])){$pairs[]=$pair;}}
        $base=explode('?',explode('#',$valid,2)[0],2)[0];
        return $base.($pairs?'?'.implode('&',$pairs):'').(isset($p['fragment'])?'#'.$p['fragment']:'');
    }
    /** Canonical and old-slug only: never restore arguments intentionally consumed by WordPress. */
    public static function query_nativa(string $url): string {
        $p=wp_parse_url($url); $home=wp_parse_url(home_url('/'));
        if (!$p || isset($p['user']) || isset($p['pass']) || strtolower($p['host']??'')!==strtolower($home['host']??'')) { return $url; }
        $scheme=$p['scheme']??''; $hs=$home['scheme']??'https';
        if (!in_array($scheme,array('http','https'),true) || ($hs==='https' && $scheme!=='https')) { return $url; }
        $port=(int)($p['port']??($scheme==='https'?443:80)); $hp=(int)($home['port']??($hs==='https'?443:80));
        if ($port!==$hp && !($hs==='http'&&$scheme==='https'&&$hp===80&&$port===443)) { return $url; }
        $source=self::query_origem(); if (!self::query_valida($source)) { return $url; }
        $pairs=array_filter(explode('&',$source),static fn($pair)=>in_array(urldecode(explode('=',$pair,2)[0]),F3Base_Atribuicao::CAMPOS,true));
        return self::preservar_query($url,'/?'.implode('&',$pairs))??$url;
    }

	public static function local( string $path ): array {
		$url = self::absoluto( explode('#',$path,2)[0] );
		$id  = url_to_postid( $url );
		$p   = $id ? get_post( $id ) : null;
		if ( $p && 'publish' === $p->post_status && '' === $p->post_password && is_post_type_viewable( $p->post_type ) && self::caminho( (string) wp_parse_url( get_permalink( $p ), PHP_URL_PATH ) ) === self::caminho( (string) wp_parse_url( $url, PHP_URL_PATH ) ) ) {
			return array(
				'publico' => true,
				'tipo'    => 'post',
				'id'      => $id,
			); }
		if ( '/' === $path && F3Base_Llms::site_publico() ) {
			return array(
				'publico' => true,
				'tipo'    => 'home',
			); }
		foreach ( get_taxonomies( array( 'public' => true ) ) as $tax ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $tax,
					'hide_empty' => false,
					'number'     => 201,
				)
			);
			if ( is_wp_error( $terms ) ) {
				continue; }
			foreach ( $terms as $t ) {
				$u = get_term_link( $t );
				if ( ! is_wp_error( $u ) && untrailingslashit( $u ) === untrailingslashit( $url ) ) {
					return array(
						'publico' => true,
						'tipo'    => 'termo',
						'id'      => $t->term_id,
					); }
			}
		}
		return array(
			'publico' => false,
			'tipo'    => 'nao_identificado',
		);
	}
	/** Snapshot before persistence also covers descendants when an ancestor moves. */
	public static function antes_atualizar( int $id, array $dados ): void {
		$p = get_post( $id );
		if ( ! $p || ! is_post_type_viewable( $p->post_type ) || ( $p->post_name === ( $dados['post_name'] ?? $p->post_name ) && (int) $p->post_parent === (int) ( $dados['post_parent'] ?? $p->post_parent ) ) ) { // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Comparison of runtime expressions; neither side is an assignable literal.
			return; }
		$posts = array( $p );
		if ( is_post_type_hierarchical( $p->post_type ) ) {
			$todos = get_posts(
				array(
					'post_type'        => $p->post_type,
					'post_status'      => 'any',
					'numberposts'      => -1,
					'orderby'          => 'ID',
					'order'            => 'ASC',
					'suppress_filters' => true,
				)
			);
			foreach ( $todos as $filho ) {
				if ( in_array( $id, array_map( 'intval', get_post_ancestors( $filho ) ), true ) ) {
					$posts[] = $filho; }
			}
		}
		$base = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		foreach ( $posts as $post ) {
			if ( 'publish' !== $post->post_status || $post->post_password ) {
				continue; }
			$url  = get_permalink( $post );
			$path = (string) wp_parse_url( (string) $url, PHP_URL_PATH );
			if ( $path && ( ! $base || str_starts_with( $path, $base . '/' ) ) ) {
				$normal = self::caminho( substr( $path, strlen( $base ) ) );
				if ( $normal ) {
					self::$historicos[ $id ][ $post->ID ] = $normal; }
			}
		}
	}
	public static function historico( int $id, WP_Post $depois, WP_Post $antes ): void {
		if ( ! is_post_type_viewable( $antes->post_type ) || 'publish' !== $antes->post_status || ( $antes->post_name === $depois->post_name && $antes->post_parent === $depois->post_parent ) ) {
			return; }
		foreach ( self::$historicos[ $id ] ?? array() as $pid => $antigo ) {
			if ( ! in_array( $antigo, get_post_meta( $pid, '_f3base_old_path', false ), true ) ) {
				add_post_meta( $pid, '_f3base_old_path', $antigo, false ); }
		}
		unset( self::$historicos[ $id ] );
		$url  = get_permalink( $antes );
		$base = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		$path = (string) wp_parse_url( (string) $url, PHP_URL_PATH );
		if ( $path && ( ! $base || str_starts_with( $path, $base . '/' ) ) ) {
			$path = self::caminho( substr( $path, strlen( $base ) ) );
			if ( $path && ! in_array( $path, get_post_meta( $id, '_f3base_old_path', false ), true ) ) {
				add_post_meta( $id, '_f3base_old_path', $path, false ); }
		}
		if ( $antes->post_name !== $depois->post_name && $antes->post_name ) {
			add_post_meta( $id, '_f3base_old_slug', $antes->post_name, false ); }
	}
	public static function validar( $pares ): array {
		$erros  = array();
		$avisos = array();
		$map    = array();
		$lista  = array();
		if ( ! is_array( $pares ) || ! array_is_list( $pares ) || count( $pares ) > 200 || strlen( (string) wp_json_encode( $pares ) ) > 131072 ) {
			return array(
				'ok'     => false,
				'erros'  => array( array( 'codigo' => 'lista_ou_limite_invalido' ) ),
				'avisos' => array(),
				'lista'  => array(),
			); }
		foreach ( $pares as $i => $p ) {
			if ( ! is_array( $p ) ) {
				$erros[] = array(
					'indice' => $i,
					'codigo' => 'par_invalido',
				);
				continue; }
            if(array_key_exists('preservar_query',$p)&&!is_bool($p['preservar_query'])){$erros[]=array('indice'=>$i,'codigo'=>'preservar_query_deve_ser_booleano');continue;}
			$de     = self::caminho( $p['de'] ?? null );
			$status = $p['status'] ?? 301;
			$para   = self::destino( $p['para'] ?? ( 410 === $status ? $de : null ) );
			if ( null === $de || null === $para || ! is_int( $status ) || ! in_array( $status, array( 301, 302, 307, 308, 410 ), true ) ) {
				$erros[] = array(
					'indice' => $i,
					'codigo' => 'caminho_ou_status_invalido',
				);
				continue; }
			if ( isset( $map[ $de ] ) ) {
				$erros[] = array(
					'indice' => $i,
					'codigo' => 'origem_duplicada',
					'de'     => $de,
				); }
			$map[ $de ]         = $p + array( 'status' => $status );
			$map[ $de ]['de']   = $de;
			$map[ $de ]['para'] = $para;
			$lista[]            = $map[ $de ];
		}
		foreach ( $map as $de => $p ) {
			$seen   = array();
			$at     = $de;
			$saltos = 0;
			while ( isset( $map[ $at ] ) && 410 !== $map[ $at ]['status'] ) {
				if ( isset( $seen[ $at ] ) ) {
					$erros[] = array(
						'codigo' => 'ciclo',
						'de'     => $de,
					);
					break; }
				if ( ++$saltos > 5 ) {
					$erros[] = array(
						'codigo' => 'cadeia_acima_do_limite',
						'de'     => $de,
					);
					break; }
				$seen[ $at ] = true;
                if(self::externo($map[$at]['para'])){break;}
				$at          = self::caminho( (string) wp_parse_url( $map[ $at ]['para'], PHP_URL_PATH ) ) ?? '';
			}
			if ( $saltos > 1 ) {
				$avisos[] = array(
					'codigo'        => 'cadeia',
					'de'            => $de,
					'destino_final' => $at,
					'saltos'        => $saltos,
				); }
		}
		return array(
			'ok'     => ! $erros,
			'lista'  => $lista,
			'erros'  => $erros,
			'avisos' => $avisos,
		);
	}
	public static function ler( $e = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::erro( 'sem_permissao' ); }
		$foto  = F3Base_Options::fotografia( self::OPTION );
		$bruto = get_option( self::OPTION, array() );
		$v     = self::validar( $bruto );
		$pares = $v['lista'];
		if ( ! empty( $e['origens'] ) ) {
			$pares = array_values( array_filter( $pares, static fn( $p )=>in_array( $p['de'], $e['origens'], true ) ) ); }
		$limite = max( 1, min( 50, (int) ( $e['limite'] ?? 50 ) ) );
		$pagina = max( 1, (int) ( $e['pagina'] ?? 1 ) );
		return array(
			'ok'              => ! $foto['erro'],
			'pares'           => array_slice( $pares, ( $pagina - 1 ) * $limite, $limite ),
			'total'           => count( $pares ),
			'pagina'          => $pagina,
			'limite'          => $limite,
			'revisao'         => $foto['revisao'],
			'operavel'        => F3Base_Options::operavel( self::OPTION ),
			'motivo'          => F3Base_Servicos::motivo_acesso( self::OPTION ),
			'diagnostico'     => $v['erros'],
			'avisos'          => $v['avisos'],
			'legado_invalido' => ! $v['ok'] ? $bruto : array(),
			'evidencia'       => self::evidencia(),
		);
	}
	public static function erro( string $codigo, array $mais = array() ): array {
		return array(
			'ok'        => false,
			'persisted' => false,
			'codigo'    => $codigo,
		) + $mais; }
	private static function observar( string $path, float $fim, bool $teste=false ): array {
		$url = self::absoluto( explode('#',$path,2)[0] );
		if ( ! wp_http_validate_url( $url ) ) {
			return array(
				'status' => 0,
				'codigo' => 'destino_nao_publico',
			); }
		$tempo = min( 3, $fim - microtime( true ) );
		if ( $tempo <= 0 ) {
			return array(
				'status' => 0,
				'codigo' => 'orcamento_esgotado',
			); }
		$r = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => $tempo,
				'redirection'         => 0,
				'limit_response_size' => 65536,
				'cookies'             => array(),
				'headers'             => array( 'Accept' => 'text/html' )+F3Base_Testes::cabecalhos($url,$teste),
			)
		);
		if ( is_wp_error( $r ) ) {
			return array(
				'status' => 0,
				'codigo' => 'http_inconclusivo',
			); }
		return array(
			'status'         => (int) wp_remote_retrieve_response_code( $r ),
			'location'       => (string) wp_remote_retrieve_header( $r, 'location' ),
			'x_redirect_by'  => (string) wp_remote_retrieve_header( $r, 'x-redirect-by' ),
			'em'             => time(),
			'sha256_prefixo' => hash( 'sha256', (string) wp_remote_retrieve_body( $r ) ),
		);
	}
	public static function escrever( $e ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::erro( 'sem_permissao' ); }
		if ( ! F3Base_Options::operavel( self::OPTION ) ) {
			return self::erro( F3Base_Servicos::motivo_acesso( self::OPTION ) ); }
		if ( ! is_array( $e ) || array_diff( array_keys( $e ), array( 'operacao', 'pares', 'origens', 'revisao_esperada', 'simular', 'sobrepor_conteudo_vivo', 'adiar_purga' ) ) ) {
			return self::erro( 'entrada_invalida' ); }
		foreach ( array( 'simular', 'sobrepor_conteudo_vivo', 'adiar_purga' ) as $k ) {
			if ( isset( $e[ $k ] ) && ! is_bool( $e[ $k ] ) ) {
				return self::erro( 'entrada_invalida' ); }
		}
		$foto = F3Base_Options::fotografia( self::OPTION );
		$rev  = $e['revisao_esperada'] ?? ( ( $e['simular'] ?? true ) ? $foto['revisao'] : '' );
		if ( ! is_string( $rev ) || ! preg_match( '/^[a-f0-9]{64}$/D', $rev ) || ! hash_equals( $foto['revisao'], $rev ) ) {
			return self::erro( 'conflito' ); }
		$antes     = get_option( self::OPTION, array() );
		$val_antes = self::validar( $antes );
		$op        = $e['operacao'] ?? '';
		// An explicit full replacement can repair invalid legacy rules; deltas cannot hide them.
		if ( ! $val_antes['ok'] && 'substituir_lista' !== $op ) {
			return self::erro( 'legado_invalido_exige_lista_completa', array( 'diagnostico' => $val_antes['erros'] ) ); }
		$map = array_column( $val_antes['lista'], null, 'de' );
		if ( 'substituir_lista' === $op ) {
			$depois = $e['pares'] ?? null; } elseif ( in_array( $op, array( 'adicionar', 'alterar' ), true ) ) {
			$n = self::validar( $e['pares'] ?? null );
			if ( ! $n['ok'] || count( $n['lista'] ) > 10 ) {
				return self::erro( 'lote_invalido', array( 'validacao' => $n ) ); }
			foreach ( $n['lista'] as $p ) {
				if ( 'adicionar' === $op && isset( $map[ $p['de'] ] ) ) {
					return self::erro( 'origem_ja_declarada' );
				} if ( 'alterar' === $op && ! isset( $map[ $p['de'] ] ) ) {
					return self::erro( 'origem_nao_declarada' );
				} $map[ $p['de'] ] = array_replace( $map[ $p['de'] ] ?? array(), $p ); }
			$depois = array_values( $map );
			} elseif ( 'remover' === $op ) {
				if ( ! is_array( $e['origens'] ?? null ) || count( $e['origens'] ) > 10 ) {
					return self::erro( 'origens_invalidas' ); }
				foreach ( $e['origens'] as $p ) {
					$n = self::caminho( $p );
					if ( null === $n || ! isset( $map[ $n ] ) ) {
								return self::erro( 'origem_nao_declarada' );
					} unset( $map[ $n ] ); }
				$depois = array_values( $map );
			} else {
				return self::erro( 'operacao_invalida' ); }
			$v = self::validar( $depois );
			if ( ! $v['ok'] ) {
				return self::erro( 'validacao_recusada', array( 'validacao' => $v ) ); }
			$depois    = $v['lista'];
			$old       = array_column( $val_antes['lista'], null, 'de' );
			$novo      = array_column( $depois, null, 'de' );
			$alteradas = array();
			foreach ( $novo as $de => $p ) {
				if ( ( $old[ $de ] ?? null ) !== $p ) {
						$alteradas[ $de ] = $p; }
			}
			$removidas = array_diff_key( $old, $novo );
			$delta     = array(
				'alteradas' => array_values( $alteradas ),
				'removidas' => array_keys( $removidas ),
			);
			if ( count( $alteradas ) + count( $removidas ) > 10 ) {
				return self::erro( 'delta_acima_de_10', array( 'delta' => $delta ) ); }
			$provas = array();
			$fim    = microtime( true ) + 20;
			$req    = 0;
			foreach ( $alteradas as $de => $p ) {
				$orig = self::observar( $de, $fim );
				++$req;
				$provas[ $de ]['origem'] = $orig;
				if ( ! $orig['status'] || in_array( $orig['status'], array( 401, 403, 429, 500, 502, 503 ), true ) ) {
					$v['avisos'][] = array(
						'codigo' => 'origem_http_inconclusiva',
						'de'     => $de,
					); }
				if ( ( 200 === $orig['status'] || self::local( $de )['publico'] ) && empty( $e['sobrepor_conteudo_vivo'] ) ) {
					return self::erro( 'origem_viva', array( 'observacoes' => $provas ) ); }
				if ( in_array( $orig['status'], array( 301, 302, 303, 307, 308 ), true ) && ! isset( $old[ $de ] ) && ! in_array( strtolower( $orig['x_redirect_by'] ?? '' ), array( 'wordpress', 'base-site-core-fator3' ), true ) ) {
					return self::erro( 'precedencia_externa_a_resolver', array( 'observacoes' => $provas ) ); }
				if ( 410 === $p['status'] ) {
					continue; }
				$terminal = explode('#',$p['para'],2)[0];
				$saltos   = 0;
				while ( !self::externo($terminal) && isset( $novo[ self::caminho( (string)wp_parse_url($terminal,PHP_URL_PATH) ) ] ) && ++$saltos <= 5 ) {
					if ( 410 === $novo[ self::caminho( (string)wp_parse_url($terminal,PHP_URL_PATH) ) ]['status'] ) {
						return self::erro( 'destino_terminal_removido' ); }
					$terminal = explode('#',$novo[self::caminho((string)wp_parse_url($terminal,PHP_URL_PATH))]['para'],2)[0];
				}
				if ( $req >= 20 ) {
					return self::erro( 'orcamento_esgotado' ); }
				$dest = self::observar( $terminal, $fim );
				++$req;
				$provas[ $de ]['destino'] = $dest;
				if ( in_array( $dest['status'], array( 404, 410, 301, 302, 303, 307, 308 ), true ) ) {
					return self::erro( 'destino_contradiz_validacao_local', array( 'observacoes' => $provas ) ); }
				if ( 200 !== $dest['status'] ) {
					if ( self::externo($terminal) || ! self::local( $terminal )['publico'] ) {
								return self::erro( 'destino_sem_identidade_publica', array( 'observacoes' => $provas ) );
					} $v['avisos'][] = array(
						'codigo' => 'http_inconclusivo_persistencia_local',
						'de'     => $de,
					); }
			}
			$comum = array(
				'antes'       => $antes,
				'depois'      => $depois,
				'delta'       => $delta,
				'avisos'      => $v['avisos'],
				'observacoes' => $provas,
				'revisao'     => $foto['revisao'],
				'changed'     => ! empty( $alteradas ) || ! empty( $removidas ) || $antes !== $depois,
			);
			if ( $e['simular'] ?? true ) {
				return array(
					'ok'        => true,
					'simulado'  => true,
                    'alteraria'=>$comum['changed'],'changed'=>false,
					'persisted' => false,
				) + $comum; }
			if ( ! $comum['changed'] ) {
				return array(
					'ok'        => true,
					'persisted' => false,
					'codigo'    => 'sem_alteracao',
				) + $comum; }
			$urls = array_values( array_unique( array_merge( array_keys( $alteradas ), array_keys( $removidas ) ) ) );
			F3Base_Cache_Pagina::contexto_redirects( $urls );
			try {
				$r = F3Base_Options::pelo_canal( 'ability', static fn()=>F3Base_Options::gravar( self::OPTION, $depois, F3Base_Options::ORIGEM_ABILITY, $rev ) );
			} finally {
				F3Base_Cache_Pagina::contexto_redirects( null ); }
			if ( ! empty( $r['persisted'] ) && ! empty( $e['adiar_purga'] ) ) {
				F3Base_Cache_Pagina::adiar(); }
			if ( ! empty( $r['persisted'] ) ) {
				F3Base_Options::atualizar_estado(
					self::EVIDENCIA,
					static fn( $s )=>array(
						'revisao'   => F3Base_Options::revisao( self::OPTION ),
						'status'    => 'pending',
						'alvos'     => array_keys( $alteradas ),
						'removidas' => array_values(
							array_diff_key(
								array_replace(
									array_column( $s['removidas'] ?? array(), null, 'de' ),
									array_combine(
										array_keys( $removidas ),
										array_map(
											static fn( $de )=>array(
												'de'    => $de,
												'antes' => $old[ $de ],
											),
											array_keys( $removidas )
										)
									)
								),
								$novo
							)
						),
						'provas'    => array(),
						'em'        => time(),
						'contexto'  => self::contexto(),
					)
				);
			}
			return $r + $comum;
	}
    private static function componentes(): array {
        $alvos=array();foreach((array)F3Base_Options::ler(self::OPTION) as $par){$url=(string)($par['para']??'');if(!$url||str_starts_with($url,'#')){continue;}
            $p=wp_parse_url($url);if(!empty($p['host'])&&strtolower($p['host'])!==strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST))){continue;}
            $id=F3Base_Leads_Contexto::pagina($url);$post=$id?get_post($id):null;$alvos[$url]=array('id'=>$id,'estado'=>$post?array($post->post_status,$post->post_password,hash('sha256',$post->post_content)):null,'dependencias'=>$id?F3Base_Ofertas::dependencias($id):array());
        }
        $tema=wp_get_theme();return array('contrato'=>self::CONTRATO_PROVA,'pares'=>F3Base_Options::ler(self::OPTION),'home'=>home_url('/'),'permalinks'=>get_option('permalink_structure'),'hosts'=>F3Base_Options::ler('f3base_redirects_hosts'),'provedores'=>get_option('active_plugins'),'tema'=>array($tema->get_stylesheet(),$tema->get('Version'),get_theme_mods()),'alvos'=>$alvos);
    }
    private static function contexto(): string {return hash('sha256',wp_json_encode(self::componentes()));}
    public static function variantes(): array {
        return array('sem_query'=>'','utm'=>'?utm_source=f3base-sonda','gclid'=>'?gclid=f3base-teste','mista'=>'?utm_source=f3base-sonda&utm_content=anuncio%2Fteste&utm_content=segundo&utm_term=');
    }
    private static function consolidar(array $s): array {
        $total=0;$concluidas=0;$falhas=0;
        foreach($s['escopo']??array() as $de){foreach(self::variantes() as $v=>$query){
            ++$total;$r=$s['provas'][$de][$v]??array();
            if(($r['em']??0)<=time()-DAY_IN_SECONDS){continue;}
            if(($r['status_verificacao']??'')==='verified'){++$concluidas;}
            elseif(($r['status_verificacao']??'')==='failed'){++$falhas;}
        }}
        $s['total']=$total;$s['concluidas']=$concluidas;$s['falhas']=$falhas;$s['pendentes']=$total-$concluidas-$falhas;
        $s['status']=$falhas?'failed':($concluidas===$total?'verified':'pending');
        $s['cobertura_lista']=$total===$concluidas && count($s['escopo']??array())===count($s['provas']??array());
        return $s;
    }
    public static function evidencia(): array {
        $f=F3Base_Options::fotografia(self::EVIDENCIA);
        $s=is_array($f['valor'])?$f['valor']:array();
        $s['atual']=!$f['erro'] && ($s['contrato']??0)===self::CONTRATO_PROVA && isset($s['escopo']) && is_array($s['escopo']) && ($s['revisao']??'')===F3Base_Options::revisao(self::OPTION) && ($s['contexto']??'')===self::contexto();
        $s['invalidacoes']=array();if($f['erro']){$s['invalidacoes'][]='leitura_falhou';}if(empty($s['provas'])){$s['invalidacoes'][]='evidencia_ausente';}if(($s['revisao']??'')!==F3Base_Options::revisao(self::OPTION)){$s['invalidacoes'][]='lista_alterada';}
        foreach(self::componentes() as $k=>$v){if(!array_key_exists($k,$s['componentes']??array())||!F3Base_Options::equivalente($v,$s['componentes'][$k])){$s['invalidacoes'][]='contexto.'.$k;}}
        foreach($s['provas']??array() as $provas){foreach($provas as $p){if(($p['em']??0)<=time()-DAY_IN_SECONDS){$s['invalidacoes'][]='evidencia_expirada';break 2;}}}
        if(!$s['atual']){$s['status']='pending';$s['codigo']=$f['erro']?'leitura_falhou':'evidencia_ausente_ou_contexto_alterado';$s['cobertura_lista']=false;return $s;}
        return self::consolidar($s);
    }
	public static function verificacao_config( $v = null ): array {
		unset( $v );
		return array(
			'status'    => 'pending',
			'codigo'    => 'usar_redirects_verificar',
			'evidencia' => self::evidencia(),
		); }
    /** Confere cada salto autorizado e a âncora no HTML, sem executar scripts remotos. */
    public static function provar_destino(string $url,float $fim,bool $teste=false): array {
        $cadeia=array();$vistos=array();$fragmento=(string)(wp_parse_url($url,PHP_URL_FRAGMENT)??'');
        for($salto=0;$salto<4;++$salto){
            $permitido=self::destino($url);
            if($permitido===null){return array('status'=>'failed','codigo'=>'salto_nao_autorizado','cadeia'=>$cadeia);}
            $alvo=explode('#',$url,2)[0];
            if(isset($vistos[$alvo])){return array('status'=>'failed','codigo'=>'ciclo_observado','cadeia'=>$cadeia);}$vistos[$alvo]=true;
            $r=F3Base_Http_Publico::buscar($alvo,524288,$fim,'GET',F3Base_Testes::cabecalhos($alvo,$teste),false);$status=(int)($r['status']??0);$cadeia[]=array('url'=>$alvo,'http'=>$status);
            if(in_array($status,array(301,302,303,307,308),true)){
                $loc=$r['cabecalhos']['location']??'';if(!$loc){return array('status'=>'failed','codigo'=>'location_ausente','cadeia'=>$cadeia);}
                $url=WP_Http::make_absolute_url($loc,$alvo);$f=wp_parse_url($url,PHP_URL_FRAGMENT);if($f!==null){$fragmento=(string)$f;}continue;
            }
            if(empty($r['ok'])){return array('status'=>in_array($status,array(404,410),true)?'failed':'pending','codigo'=>$r['codigo']??'destino_inconclusivo','cadeia'=>$cadeia,'url_final'=>$alvo);}
            $ancora=$fragmento===''?'nao_aplicavel':'nao_observada';
            if($fragmento!==''){$html=new WP_HTML_Tag_Processor($r['corpo']??'');$procurado=rawurldecode($fragmento);while($html->next_tag()){if($html->get_attribute('id')===$procurado||($html->get_tag()==='A'&&$html->get_attribute('name')===$procurado)){$ancora='observada';break;}}}
            return array('status'=>$ancora==='nao_observada'?'pending':'verified','codigo'=>$ancora==='nao_observada'?'ancora_nao_comprovada':'destino_confirmado','cadeia'=>$cadeia,'url_final'=>$alvo,'ancora'=>$ancora,'fragmento'=>$fragmento,'externo'=>self::externo($alvo),'em'=>time());
        }
        return array('status'=>'pending','codigo'=>'limite_de_saltos','cadeia'=>$cadeia);
    }
    public static function verificar($e=array()): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}
        if(!is_array($e)){return self::erro('entrada_invalida');}
        if('consultar'===($e['acao']??'consultar')){return array('ok'=>true,'evidencia'=>self::evidencia());}
        $rev=F3Base_Options::revisao(self::OPTION);
        if(!hash_equals($rev,(string)($e['revisao_esperada']??''))){return self::erro('conflito');}
        if(!empty(F3Base_Cache_Pagina::estado()['pendente'])){
            $purga=F3Base_Cache_Pagina::limpar(false,'redirects_verificar');
            if(empty($purga['ok'])){return array('ok'=>true,'codigo'=>'purga_pendente','evidencia'=>self::evidencia(),'purga'=>$purga);}
        }
        $val=self::validar(get_option(self::OPTION,array())); if(!$val['ok']){return self::erro('legado_invalido');}
        $map=array_column($val['lista'],null,'de');$s=self::evidencia();
        // Import only removal obligations from 1.14.0; never reuse its proof format.
        $antigo=get_option('f3base_redirects_evidencia',array());
        $rem=($s['revisao']??'')===$rev?($s['removidas']??array()):((($antigo['revisao']??'')===$rev)?($antigo['removidas']??array()):array());
        $removidas=array_diff_key(array_column($rem,null,'de'),$map);
        $todos=array_values(array_unique(array_merge(array_keys($map),array_keys($removidas))));sort($todos,SORT_STRING);
        $origens=$e['origens']??$todos;
        if(!is_array($origens)||array_diff($origens,$todos)){return self::erro('origem_nao_declarada');}
        $origens=array_values(array_unique($origens));sort($origens,SORT_STRING);
        $tarefas=array();foreach($origens as $de){foreach(self::variantes() as $v=>$q){$tarefas[]=array($de,$v,$q);}}
        $cursor=max(0,(int)($e['cursor']??0));if($cursor>count($tarefas)){return self::erro('cursor_invalido');}
        $contexto=self::contexto();$novas=array();$fim=microtime(true)+15;$feitas=0;
        foreach(array_slice($tarefas,$cursor,5) as [$de,$v,$query]){
            if(microtime(true)>$fim-0.1){break;}
            $anterior=!empty($s['atual'])?($s['provas'][$de][$v]??array()):array();
            if(($anterior['status_verificacao']??'')==='verified'&&($anterior['em']??0)>time()-DAY_IN_SECONDS){++$feitas;continue;}
            $entrada=$de.$query;$r=self::observar($entrada,$fim,true);$r['classe_trafego']='teste';$r['origem_testada']=$entrada;$r['variante']=$v;$r['em']=time();
            $loc=$r['location']??'';if($loc){$loc=WP_Http::make_absolute_url($loc,home_url($de));}
            $status=(int)($r['status']??0);$inc=!$status||in_array($status,array(401,403,429,999),true)||$status>=500;
            $p=$map[$de]??$removidas[$de]['antes'];
            $dest=410===$p['status']?'':self::absoluto(($p['preservar_query']??true)?(self::preservar_query($p['para'],$entrada)??''):$p['para']);
            $valido=$status===$p['status']&&(410===$p['status']?$loc==='':$loc===$dest);
            if(isset($map[$de])){
                $r['location_esperado']=$dest;$r['location_observado']=$loc;
                if($valido&&$dest!==''){$r['destino']=self::provar_destino($dest,$fim,true);$inc=$inc||$r['destino']['status']==='pending';$valido=$r['destino']['status']==='verified';}
            }else{$valido=!$valido;$r['regra_removida']=true;}
            $r['status_verificacao']=$inc?'pending':($valido?'verified':'failed');$r['observado_em_us']=(int)round(microtime(true)*1000000);$novas[$de][$v]=$r;++$feitas;
        }
        if(!hash_equals($rev,F3Base_Options::revisao(self::OPTION))||!hash_equals($contexto,self::contexto())){return self::erro('configuracao_mudou_durante_verificacao');}
        $execucao=wp_generate_uuid4();
        $gravacao=F3Base_Options::atualizar_estado(self::EVIDENCIA,static function($atual)use($rev,$contexto,$novas,$todos,$removidas,$execucao){
            if(!hash_equals($rev,F3Base_Options::revisao(self::OPTION))||!hash_equals($contexto,self::contexto())){return null;}
            $atual=is_array($atual)?$atual:array();
            if(($atual['revisao']??'')!==$rev||($atual['contexto']??'')!==$contexto){$atual=array();}
            $provas=array_intersect_key($atual['provas']??array(),array_flip($todos));
            foreach($novas as $de=>$variantes){foreach($variantes as $v=>$r){if(($provas[$de][$v]['observado_em_us']??(($provas[$de][$v]['em']??0)*1000000))<=($r['observado_em_us']??($r['em']*1000000))){$provas[$de][$v]=$r;}}}
            return self::consolidar(array('contrato'=>self::CONTRATO_PROVA,'execucao_id'=>$atual['execucao_id']??$execucao,'revisao'=>$rev,'contexto'=>$contexto,'componentes'=>self::componentes(),'em'=>time(),'provas'=>$provas,'escopo'=>$todos,'removidas'=>array_values($removidas)));
        });
        $persistido=!empty($gravacao['persisted']);$salvo=self::evidencia();
        return array('ok'=>$persistido,'persisted'=>$persistido,'codigo'=>$persistido?'evidencia_persistida':($gravacao['codigo']??'persistencia_falhou'),'evidencia'=>$salvo,'proximo_cursor'=>$cursor+$feitas<count($tarefas)?$cursor+$feitas:null,'executadas'=>$feitas,'cobertura_lista'=>$salvo['cobertura_lista']??false);
    }
	public static function taxonomia( $e ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return self::erro( 'sem_permissao' ); }
		if ( ! hash_equals( F3Base_Options::revisao( self::OPTION ), (string) ( $e['revisao_esperada'] ?? '' ) ) ) {
			return self::erro( 'conflito' ); }
		$tax  = get_taxonomy( (string) ( $e['taxonomia'] ?? '' ) );
		$de   = self::caminho( '/' . trim( (string) ( $e['de'] ?? '' ), '/' ) );
		$para = self::caminho( '/' . trim( (string) ( $e['para'] ?? '' ), '/' ) );
		if ( ! $tax || ! $tax->public || ! $de || ! $para || $de === $para || '/' === $de || '/' === $para ) {
			return self::erro( 'base_invalida' ); }
		$terms = get_terms(
			array(
				'taxonomy'   => $tax->name,
				'hide_empty' => false,
				'number'     => 201,
			)
		);
		if ( is_wp_error( $terms ) || count( $terms ) > 200 ) {
			return self::erro( 'termos_acima_do_limite' ); }
		$pares    = array();
		$snapshot = array();
		foreach ( $terms as $t ) {
			$url = get_term_link( $t );
			if ( is_wp_error( $url ) ) {
				return self::erro( 'termo_sem_url' ); }
			$path = wp_parse_url( $url, PHP_URL_PATH );
			$home = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
			$path = substr( $path, strlen( $home ) );
			if ( ! str_starts_with( $path, $para . '/' ) ) {
				return self::erro( 'base_destino_nao_canonica' ); }
			$pares[]    = array(
				'de'     => $de . substr( $path, strlen( $para ) ),
				'para'   => $path,
				'status' => 301,
			);
			$snapshot[] = array( $t->term_id, $t->slug, $t->parent, $url );
		}
		return array(
			'ok'         => true,
			'pares'      => $pares,
			'lotes'      => array_chunk( $pares, 10 ),
			'revisao'    => $e['revisao_esperada'],
			'snapshot'   => hash( 'sha256', wp_json_encode( $snapshot ) ),
			'observacao' => 'Replaneje antes de cada lote se termos ou permalinks mudarem. A aplicação revalida cada URL.',
		);
	}
	public static function tela(): void {
		echo '<h2>Redirects</h2><p>Edite a lista completa e simule. Cada lote pode alterar até dez origens.</p>';
		if ( isset( $_POST['redirects'] ) ) {
			check_admin_referer( 'f3base-operaveis' );
			$e = array(
				'operacao'               => 'substituir_lista',
				'pares'                  => json_decode( wp_unslash( (string) $_POST['redirects'] ), true ),
				'revisao_esperada'       => sanitize_text_field( wp_unslash( (string) ( $_POST['redirects_rev'] ?? '' ) ) ),
				'simular'                => ! isset( $_POST['redirects_aplicar'] ),
				'sobrepor_conteudo_vivo' => isset( $_POST['sobrepor'] ),
			);
			echo '<pre>' . esc_html( wp_json_encode( self::escrever( $e ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>';
		}
		echo '<form method="post">';
		wp_nonce_field( 'f3base-operaveis' );
		echo '<input type="hidden" name="redirects_rev" value="' . esc_attr( F3Base_Options::revisao( self::OPTION ) ) . '"><textarea name="redirects" rows="14" style="width:100%">' . esc_textarea( wp_json_encode( get_option( self::OPTION, array() ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ) . '</textarea><p><label><input type="checkbox" name="sobrepor"> Confirmo a sobreposição das origens com conteúdo publicado</label></p><button class="button">Simular</button> <button class="button" name="redirects_aplicar">Aplicar redirects</button></form>';
	}
}
