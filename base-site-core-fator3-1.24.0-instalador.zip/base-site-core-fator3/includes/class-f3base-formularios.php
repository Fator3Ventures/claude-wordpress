<?php
/** Server-owned definitions and validation. No CF7 dependency. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Formularios {
	private static bool $estilo_impresso = false;
	const TIPOS                          = array( 'text', 'email', 'tel', 'textarea', 'select', 'radio', 'checkbox', 'url', 'file', 'static' );
    public const MENSAGENS=array('enviando'=>'Enviando…','sucesso'=>'Obrigado. Seu contato foi registrado.','validacao'=>'Confira os campos destacados.','arquivo_limite'=>'O arquivo ou o envio excede o limite permitido.','token_indisponivel'=>'Não foi possível preparar o envio. Tente novamente.','conexao'=>'Falha de conexão. Tente novamente.','nao_confirmado'=>'O envio ainda não foi confirmado. Tente novamente.','falha'=>'Não foi possível receber o envio. Tente novamente.','novo_envio'=>'Novo envio');
    public static function mensagens(array $f): array {
        $r=self::MENSAGENS;if(!empty($f['confirmacao'])){$r['sucesso']=$f['confirmacao'];}
        foreach($f['mensagens']??array() as $k=>$v){if(isset($r[$k])&&is_string($v)&&trim($v)!==''){$r[$k]=sanitize_text_field($v);}}return $r;
    }
    public static function schema_mensagens(): array {
        return array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(array_keys(self::MENSAGENS),array('type'=>'string','maxLength'=>1000)));
    }
	public static function schema(): array {
		return array(
			'type'     => 'array',
			'maxItems' => 100,
			'items'    => array(
				'type'                 => 'object',
				'required'             => array( 'id', 'titulo', 'campos' ),
				'properties'           => array(
					'id'            => array(
						'type'    => 'string',
						'pattern' => '^[a-z][a-z0-9_-]{0,79}$',
					),
					'titulo'        => array(
						'type'      => 'string',
						'maxLength' => 200,
					),
					'pipedrive'=>array('type'=>'boolean'),
                    'servico_fixo'=>array('type'=>'string','maxLength'=>200),
                    'resposta_visitante' => F3Base_Resposta_Visitante::schema(),
					'regime'        => array(
						'type' => 'string',
						'enum' => array( 'registro', 'whatsapp', 'conteudo' ),
					),
					'ativo'         => array(
						'type'    => 'string',
						'pattern' => '^[a-f0-9]{32}$',
					),
					'validade_dias' => array(
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 365,
					),
					'quota'         => array(
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 1000,
					),
					'mensagens' => self::schema_mensagens(),
                    'confirmacao_url'=>array('type'=>'string','maxLength'=>2048),
                    'confirmacao'   => array(
						'type'      => 'string',
						'maxLength' => 10000,
					),
					'assunto'       => array(
						'type'      => 'string',
						'maxLength' => 200,
					),
					'destinatarios' => array(
						'type'     => 'array',
						'maxItems' => 5,
						'items'    => array(
							'type'   => 'string',
							'format' => 'email',
						),
					),
					'whatsapp'      => array(
						'type'    => 'string',
						'pattern' => '^[0-9]{10,15}$',
					),
					'botao'         => array(
						'type'      => 'string',
						'maxLength' => 100,
					),
					'ligado'        => array( 'type' => 'boolean' ),
					'campos'        => array(
						'type'     => 'array',
						'minItems' => 1,
						'maxItems' => 100,
						'items'    => array(
							'type'                 => 'object',
							'required'             => array( 'nome', 'tipo', 'rotulo' ),
							'additionalProperties' => false,
							'properties'           => array(
								'nome'         => array(
									'type'    => 'string',
									'pattern' => '^[a-z][a-z0-9_-]{0,79}$',
								),
								'tipo'         => array(
									'type' => 'string',
									'enum' => self::TIPOS,
								),
								'rotulo'       => array(
									'type'      => 'string',
									'maxLength' => 200,
								),
								'obrigatorio'  => array( 'type' => 'boolean' ),
								'ajuda'        => array(
									'type'      => 'string',
									'maxLength' => 1000,
								),
								'opcoes'       => array(
									'type'     => 'array',
									'maxItems' => 100,
									'items'    => array(
										'type'      => 'string',
										'maxLength' => 500,
									),
								),
								'padrao'       => array(
									'type'      => 'string',
									'maxLength' => 1000,
								),
								'placeholder'  => array(
									'type'      => 'string',
									'maxLength' => 200,
								),
								'autocomplete' => array(
									'type'      => 'string',
									'maxLength' => 100,
								),
								'largura'      => array(
									'type' => 'integer',
									'enum' => array( 50, 100 ),
								),
								'papel'        => array(
									'type' => 'string',
									'enum' => array( 'nome', 'email', 'telefone', 'mensagem', 'empresa', 'cargo', 'servico', 'linkedin', 'outro' ),
								),
								'html'         => array(
									'type'      => 'string',
									'maxLength' => 10000,
								),
								'max_bytes'    => array(
									'type'    => 'integer',
									'minimum' => 0,
								),
								'extensoes'    => array(
									'type'  => 'array',
									'items' => array(
										'type'    => 'string',
										'pattern' => '^[a-z0-9]+$',
									),
								),
								'max_arquivos' => array(
									'type'    => 'integer',
									'minimum' => 1,
									'maximum' => 5,
								),
							),
						),
					),
				),
				'additionalProperties' => false,
			),
		);
	}
	public static function recusar( $v ): string {
		$r = rest_validate_value_from_schema( $v, self::schema(), 'formularios' );
		if ( is_wp_error( $r ) ) {
			return $r->get_error_message(); }
		$ids = array();
		foreach ( $v as $f ) {
            if(!empty($f['confirmacao_url'])&&!F3Base_Confirmacao::normalizar($f['confirmacao_url'])){return 'URL de confirmação inválida ou host externo não autorizado.';}
			if ( isset( $ids[ $f['id'] ] ) ) {
				return 'ID de formulário repetido.';
			} $ids[ $f['id'] ] = true;
			$nomes             = array();
			$papeis            = array();
			foreach ( $f['campos'] as $c ) {
				if ( isset( $nomes[ $c['nome'] ] ) ) {
					return 'Nome de campo repetido.';
				} $nomes[ $c['nome'] ] = true;
				if ( in_array( $c['tipo'], array( 'select', 'radio', 'checkbox' ), true ) && empty( $c['opcoes'] ) ) {
					return 'Campo de escolha precisa de opções.'; }
				if ( isset( $c['papel'] ) && 'outro' !== $c['papel'] ) {
					if ( isset( $papeis[ $c['papel'] ] ) ) {
						return 'Papel de campo repetido.';
					} $papeis[ $c['papel'] ] = $c['tipo']; }
				if('servico'===($c['papel']??'')&&!in_array($c['tipo'],array('select','radio','checkbox'),true)){return 'Papel serviço exige select, radio ou checkbox.';}
                if ( 'email' === ( $c['papel'] ?? '' ) && 'email' !== $c['tipo'] ) {
					return 'Papel email exige tipo email.'; }
			}
			$erro_resposta = F3Base_Resposta_Visitante::validar( $f );
			if ( $erro_resposta ) { return $erro_resposta; }
			if ( 'conteudo' === ( $f['regime'] ?? 'registro' ) && ( empty( $f['ativo'] ) || ! isset( $papeis['email'] ) || ! array_filter( $f['campos'], static fn( $c )=>'email' === ( $c['papel'] ?? '' ) && ! empty( $c['obrigatorio'] ) ) ) ) {
				return 'Conteúdo exige ativo privado e campo email.'; }
			if ( 'whatsapp' === ( $f['regime'] ?? 'registro' ) && empty( $f['whatsapp'] ) && empty( F3Base_Options::ler( 'f3base_contato' )['whatsapp_e164'] ) ) {
				return 'Regime WhatsApp exige número de destino.'; }
			foreach ( array( 'assunto', 'titulo' ) as $k ) {
				if ( preg_match( '/[\r\n]/', $f[ $k ] ?? '' ) ) {
					return 'Título e assunto não aceitam quebras.'; }
			}
		}
		foreach ( (array) get_option( 'f3base_formularios', array() ) as $anterior ) {
			if ( ! isset( $ids[ $anterior['id'] ?? '' ] ) && self::referencias( (string) ( $anterior['id'] ?? '' ) ) ) {
				return 'Definição ainda referenciada: ' . $anterior['id'] . '. Retire a publicação explicitamente ou migre as referências antes de remover.'; }
		}
		return '';
	}
    public static function referencias(string $id): array {
        static $cache=null,$versao='';global $wpdb;$atual=wp_cache_get_last_changed('posts');
        if($cache===null||$versao!==$atual){
            $cache=array();$versao=$atual;
            $rows=$wpdb->get_results($wpdb->prepare("SELECT ID,post_title,post_type,post_content FROM {$wpdb->posts} WHERE post_type NOT IN ('revision','attachment') AND (post_content LIKE %s OR post_content LIKE %s) ORDER BY ID LIMIT 1001",'%f3base_formulario%','%f3base/formulario%'),ARRAY_A);
            foreach($rows as $row){$ids=array();$walk=static function($blocks)use(&$walk,&$ids){foreach($blocks as $block){if(($block['blockName']??'')==='f3base/formulario'&&is_string($block['attrs']['id']??null)){$ids[$block['attrs']['id']]=true;}$walk($block['innerBlocks']??array());}};$walk(parse_blocks($row['post_content']));
                if(preg_match_all('/'.get_shortcode_regex(array('f3base_formulario')).'/s',$row['post_content'],$matches,PREG_SET_ORDER)){foreach($matches as $m){if($m[1]==='['&&$m[6]===']'){continue;}$a=shortcode_parse_atts($m[3]);if(is_array($a)&&is_string($a['id']??null)){$ids[$a['id']]=true;}}}
                unset($row['post_content']);foreach($ids as $key=>$yes){$cache[$key][]=$row;}
            }
            if(count($rows)>1000||$wpdb->last_error){$cache['__incompleto']=true;}
        }
        $r=$cache[$id]??array();if(!empty($cache['__incompleto'])){$r[]=array('ID'=>0,'post_title'=>'Leitura de usos incompleta; revise as referências antes de remover.','post_type'=>'inconclusivo');}return $r;
    }

	public static function obter( string $id ): ?array {
		foreach ( (array) F3Base_Options::ler( 'f3base_formularios' ) as $f ) {
			if ( ( $f['id'] ?? '' ) === $id && ( $f['ligado'] ?? true ) ) {
				return $f;
			}
		} return null; }
	public static function revisao( array $f ): string {
		return F3Base_Leads_Repositorio::hash( $f ); }
	public static function iniciar(): void {
		add_action( 'init', array( __CLASS__, 'registrar' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'rotas' ) );
		add_action( 'admin_post_f3base_formulario', array( __CLASS__, 'post' ) );
		add_action( 'admin_post_nopriv_f3base_formulario', array( __CLASS__, 'post' ) );
		add_action( 'admin_post_f3base_confirmacao', array( __CLASS__, 'confirmacao' ) );
		add_action( 'admin_post_nopriv_f3base_confirmacao', array( __CLASS__, 'confirmacao' ) );
	}
	public static function registrar(): void {
		add_shortcode( 'f3base_formulario', static fn( $a )=>self::renderizar( array( 'id' => (string) ( $a['id'] ?? '' ) ) ) );
		register_block_type(
			'f3base/formulario',
			array(
				'api_version'     => 3,
				'attributes'      => array( 'id' => array( 'type' => 'string' ) ),
				'render_callback' => array( __CLASS__, 'renderizar' ),
			)
		);
	}
	public static function emitir( array $f, string $sid, int $pagina, bool $interacao = false ): string {
		$data = base64_encode( // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Encodes a typed cursor or HMAC payload, not executable code.
			wp_json_encode(
				array(
					'f'         => $f['id'],
					'r'         => self::revisao( $f ),
					'p'         => $pagina,
					't'         => $interacao ? time() : (int) floor( time() / HOUR_IN_SECONDS ) * HOUR_IN_SECONDS,
					'interacao' => $interacao,
				)
			)
		);
		return $data . '.' . hash_hmac( 'sha256', 'formulario|' . $data, wp_salt( 'nonce' ) );
	}
	public static function token( string $token ): ?array {
		$partes = explode( '.', $token );
		if ( count( $partes ) !== 2 || ! hash_equals( hash_hmac( 'sha256', 'formulario|' . $partes[0], wp_salt( 'nonce' ) ), $partes[1] ) ) {
			return null; }
		$d = json_decode( (string) base64_decode( $partes[0], true ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decodes a typed pagination or signed form payload, never PHP or executable code.
		return is_array( $d ) && isset( $d['t'], $d['f'], $d['r'], $d['p'] ) && is_int( $d['t'] ) && $d['t'] <= time() && $d['t'] >= time() - 2 * HOUR_IN_SECONDS ? $d : null;
	}
	public static function rotas(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			'/formularios/token',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => static function ( WP_REST_Request $req ) {
					$f = self::obter( (string) $req->get_param( 'formulario' ) );
					$p = (int) $req->get_param( 'pagina' );
					if ( ! $f || ! self::limite( 'token', 60 ) ) {
						return self::resposta(
							array(
								'ok'     => false,
								'codigo' => 'token_indisponivel',
							),
							429
						); }
					$sid = (string) $req->get_param( 'submissao' );
					if ( ! preg_match( '/^[a-f0-9]{32}$/D', $sid ) ) {
						$sid = bin2hex( random_bytes( 16 ) ); }
					return self::resposta(
						array(
							'ok'        => true,
							'token'     => self::emitir( $f, $sid, $p, true ),
							'submissao' => $sid,
							'revisao'   => self::revisao( $f ),
						),
						200
					);
				},
			)
		);
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			'/formularios/enviar',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => static function ( WP_REST_Request $req ) {
					$r = self::receber( $req->get_body_params(), $req->get_file_params() );
					return self::resposta( $r, $r['http'] ?? ( $r['ok'] ? 201 : 400 ) );
				},
			)
		);
	}
	public static function resposta( array $r, int $status ): WP_REST_Response {
		$res = new WP_REST_Response( $r, $status );
		$res->header( 'Cache-Control', 'private, no-store, max-age=0' );
		$res->header( 'X-Robots-Tag', 'noindex, nofollow' );
		return $res; }
	private static function limite( string $tipo, int $max ): bool {
		$origem = F3Base_Modulo_Endpoint_Leads::origem();
		$hash   = hash_hmac( 'sha256', wp_json_encode( $origem ), wp_salt( 'auth' ) );
		$janela = (int) floor( time() / 600 );
		return F3Base_Leads_Repositorio::quota( 'form:' . $tipo . ':' . $hash . ':' . $janela, $max, ( $janela + 2 ) * 600 );
	}
	public static function renderizar( array $a ): string {
		$f = self::obter( (string) ( $a['id'] ?? '' ) );
		if ( ! $f ) {
			return current_user_can( 'manage_options' ) ? '<p>Formulário Core indisponível.</p>' : ''; }
		return self::renderizar_definicao( $f );
	}
	public static function renderizar_definicao( array $f ): string {
		// All HTML is shared: HMAC covers form, definition, page and a time window, never a visitor.
		F3Base_Atribuicao::enfileirar();
		wp_enqueue_script(
			'f3base-formularios',
			F3BASE_PLUGIN_URL . 'assets/f3base-formularios.min.js',
			array( 'f3base-contexto' ),
			F3BASE_PLUGIN_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		$style = '';
		if ( ! self::$estilo_impresso ) {
			$style                 = '<style id="f3base-formularios-css">' . file_get_contents( F3BASE_PLUGIN_DIR . 'assets/f3base-formularios.css' ) . '</style>'; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading a bounded local package/theme file; no remote URL or visitor path is accepted.
			self::$estilo_impresso = true; }
		// The existing channel owns consent, conversion destinations and deduplication.
		$leads = new F3Base_Modulo_Leads_Whatsapp();
		$leads->enfileirar( true );
		$sid  = '';
		$page = (int) get_queried_object_id();
		$uid  = wp_unique_id( 'f3f-' );
		$h    = $style . '<form data-mensagens="'.esc_attr(wp_json_encode(self::mensagens($f))).'" data-post-max-bytes="'.(int)wp_convert_hr_to_bytes(ini_get('post_max_size')).'" data-max-file-uploads="'.(int)ini_get('max_file_uploads').'" class="f3base-formulario" data-f3base-formulario="' . esc_attr( $f['id'] ) . '" data-endpoint="' . esc_url( rest_url( F3BASE_REST_NAMESPACE . '/formularios/' ) ) . '" data-revisao="' . esc_attr(self::revisao($f)) . '" data-pagina="' . $page . '" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		foreach ( array(
			'action'     => 'f3base_formulario',
			'formulario' => $f['id'],
			'token'      => self::emitir( $f, $sid, $page ),
			'submissao'  => $sid,
		) as $k => $v ) {
			$h .= '<input type="hidden" name="' . $k . '" value="' . esc_attr( $v ) . '">'; }
		$h .= '<div class="f3base-isca" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div>';
		foreach ( $f['campos'] as $c ) {
			$id   = $uid . '-' . $c['nome'];
			$name = 'campos[' . $c['nome'] . ']';
			$tipo = $c['tipo'];
			$h   .= '<div class="f3base-campo f3base-campo-' . (int) ( $c['largura'] ?? 100 ) . '">';
			if ( 'static' === $tipo ) {
				$h .= wp_kses(
					$c['html'] ?? '',
					array(
						'p'      => array(),
						'strong' => array(),
						'a'      => array(
							'href' => true,
							'rel'  => true,
						),
					)
				) . '</div>';
				continue; }
			if(!in_array($tipo,array('radio','checkbox'),true)) $h    .= '<label for="' . esc_attr( $id ) . '">' . esc_html( $c['rotulo'] ) . ( ! empty( $c['obrigatorio'] ) ? ' *' : '' ) . '</label>';
			$attrs = ' id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . ( 'checkbox' === $tipo || 'file' === $tipo ? '[]' : '' ) . '"';
			if ( ! empty( $c['obrigatorio'] ) ) {
				$attrs .= ' required'; }
			if ( isset( $c['placeholder'] ) ) {
				$attrs .= ' placeholder="' . esc_attr( $c['placeholder'] ) . '"'; }
			if ( isset( $c['autocomplete'] ) ) {
				$attrs .= ' autocomplete="' . esc_attr( $c['autocomplete'] ) . '"'; }
			if ( isset( $c['ajuda'] ) ) {
				$attrs .= ' aria-describedby="' . esc_attr( $id ) . '-ajuda'.($tipo==='file'?' '.esc_attr($id).'-limites':'').'"'; }
			if($tipo==='file'&&!isset($c['ajuda'])){$attrs.=' aria-describedby="'.esc_attr($id).'-limites"';}
            if ( 'textarea' === $tipo ) {
				$h .= '<textarea' . $attrs . '>' . esc_textarea( $c['padrao'] ?? '' ) . '</textarea>'; } elseif ( 'select' === $tipo ) {
				$h .= '<select' . $attrs . '><option value="">Selecione</option>';
				foreach ( $c['opcoes'] as $o ) {
					$h .= '<option value="' . esc_attr( $o ) . '"' . selected( $c['padrao'] ?? '', $o, false ) . '>' . esc_html( $o ) . '</option>';
				} $h .= '</select>'; } elseif ( in_array( $tipo, array( 'radio', 'checkbox' ), true ) ) {
								$h .= '<fieldset><legend>' . esc_html( $c['rotulo'] ) . '</legend>';
					foreach ( $c['opcoes'] as $i => $o ) {
						$h .= '<label><input type="' . $tipo . '" name="' . esc_attr( $name ) . ( 'checkbox' === $tipo ? '[]' : '' ) . '" value="' . esc_attr( $o ) . '"' . ( 'radio' === $tipo && ! empty( $c['obrigatorio'] ) ? ' required' : '' ) . '> ' . esc_html( $o ) . '</label>';
					} $h .= '</fieldset>';
				} elseif ( 'file' === $tipo ) {
					$lim=F3Base_Arquivos_Privados::politica($c);$php=(int)wp_convert_hr_to_bytes(ini_get('upload_max_filesize'));
                    $teto=$lim['teto_plugin_bytes']===null?$php:($php>0?min($php,$lim['teto_plugin_bytes']):$lim['teto_plugin_bytes']);
                    $h.='<input type="file"'.$attrs.' data-max-bytes="'.$teto.'" data-max-files="'.$lim['max_arquivos_campo'].'"'.($lim['max_arquivos_campo']>1?' multiple':'').'>';
                    $texto='Até '.$lim['max_arquivos_campo'].' arquivo(s). '.($lim['teto_plugin_bytes']===null?'Sem teto adicional do plugin.':'Teto do campo: '.size_format($lim['teto_plugin_bytes']).'.').' PHP: '.ini_get('upload_max_filesize').' por arquivo; '.ini_get('post_max_size').' no envio completo, incluindo todos os arquivos e campos. Limite do proxy desconhecido.';
                    if($lim['extensoes_plugin']){$texto.=' Extensões permitidas no campo: '.implode(', ',$lim['extensoes_plugin']).'.';}
                    $h.='<small id="'.esc_attr($id).'-limites">'.esc_html($texto).'</small>'; } else {
								$h .= '<input type="' . esc_attr( $tipo ) . '"' . $attrs . ' value="' . esc_attr( $c['padrao'] ?? '' ) . '">'; }
					if ( ! empty( $c['ajuda'] ) ) {
						$h .= '<small id="' . esc_attr( $id ) . '-ajuda">' . esc_html( $c['ajuda'] ) . '</small>';
					} $h .= '</div>';
		}
		return $h . '<button type="submit" class="wp-element-button">' . esc_html( $f['botao'] ?? 'Enviar' ) . '</button><div role="status" aria-live="polite" tabindex="-1" data-clarity-mask="true" class="f3base-formulario-resultado"></div></form>';
	}
	private static function erro( string $code, int $http = 400, array $extra = array() ): array {
		return array(
			'ok'        => false,
			'persisted' => false,
			'codigo'    => $code,
			'http'      => $http,
		) + $extra; }
    public static function receber(array $e,array $files=array()): array {
        $r=self::receber_interno($e,$files);
        $f=self::obter(is_string($e['formulario']??null)?$e['formulario']:'');$m=self::mensagens($f??array());
        if(empty($r['ok'])){$codigo=(string)($r['codigo']??'');$chave=(str_contains($codigo,'campo')||$codigo==='escolha_invalida')?'validacao':(preg_match('/arquivo|anexo|limite_servidor|limite_do_formulario|upload_erro/',$codigo)?'arquivo_limite':(str_contains($codigo,'token')?'token_indisponivel':'falha'));$r['mensagem']=$m[$chave];}
        return $r;
    }
    private static function receber_interno( array $e, array $files = array() ): array {
        if(isset($e['contexto_teste'])&&in_array($e['contexto_teste'],array('0','1'),true)){$e['contexto_teste']=$e['contexto_teste']==='1';}
        $marca=F3Base_Testes::resolver($e);if(empty($marca['ok'])){return self::erro($marca['codigo']);}
		if ( ! self::limite( 'envio', 20 ) ) {
			return self::erro( 'limite_de_envios', 429 ); }
		if ( array_diff( array_keys( $e ), array( 'action', 'formulario', 'token', 'submissao', 'campos', 'website', 'atribuicao', 'sessao', 'navegacao', 'dispositivo', 'largura_janela', 'max_touch_points', 'retorno', 'contexto_teste', 'oferta' ) ) ) {
			return self::erro( 'campo_desconhecido' ); }
		if ( array_diff( array_keys( $files ), array( 'campos' ) ) ) {
			return self::erro( 'arquivo_desconhecido' ); }

		$token = is_string( $e['token'] ?? null ) ? self::token( $e['token'] ) : null;
		$f     = self::obter( is_string( $e['formulario'] ?? null ) ? $e['formulario'] : '' );
		if ( ! $token || ! $f || $token['f'] !== $f['id'] || ! hash_equals( self::revisao( $f ), $token['r'] ) ) {
			return self::erro( 'token_ou_revisao_invalida', 403 ); }
		$sid = $e['submissao'] ?? '';
		if ( ! is_string( $sid ) || ( '' !== $sid && ! preg_match( '/^[a-f0-9]{32}$/D', $sid ) ) ) {
			return self::erro( 'submissao_invalida' );
		} $nojs = '' === $sid;
		if ( $nojs ) {
			$sid = bin2hex( random_bytes( 16 ) ); }
		$campos = $e['campos'] ?? array();
		if ( ! is_array( $campos ) || array_diff( array_keys( $campos ), array_column( $f['campos'], 'nome' ) ) ) {
			return self::erro( 'campos_invalidos' ); }
		$nomes_arquivos = array_column( array_filter( $f['campos'], static fn( $c ) => 'file' === $c['tipo'] ), 'nome' );
		foreach ( (array) ( $files['campos'] ?? array() ) as $parte ) {
			if ( ! is_array( $parte ) || array_diff( array_keys( $parte ), $nomes_arquivos ) ) {
				return self::erro( 'arquivo_desconhecido' ); }
		}
		$limpos  = array();
		$papeis  = array();
		$anexos  = array();
		$uploads = array();
		foreach ( $f['campos'] as $c ) {
			$n    = $c['nome'];
			$tipo = $c['tipo'];
			$v    = $campos[ $n ] ?? ( 'checkbox' === $tipo ? array() : '' );
			if ( 'static' === $tipo ) {
				continue; }
			if ( 'file' === $tipo ) {
				$fs      = $files['campos'] ?? array();
				$errs    = $fs['error'][ $n ] ?? array();
				$errs    = is_array( $errs ) ? $errs : array( $errs );
				$validos = 0;
				foreach ( $errs as $i => $err ) {
					if ( UPLOAD_ERR_NO_FILE === $err ) {
						continue;
					} ++$validos;
					$file = array();
					foreach ( array( 'name', 'tmp_name', 'error', 'size', 'type' ) as $k ) {
						$file[ $k ] = $fs[ $k ][ $n ][ $i ] ?? null; }
					if ( UPLOAD_ERR_OK !== $err ) {
						return self::erro( 'upload_erro_' . $err );
					} $uploads[] = array( $file, $c );
				}
				if ( ( $c['obrigatorio'] ?? false ) && ! $validos ) {
					return self::erro( 'anexo_obrigatorio', 400, array( 'campo' => $n ) ); }
				if ( $validos > (int) ( $c['max_arquivos'] ?? 5 ) ) {
					return self::erro( 'quantidade_de_anexos' );
				} continue;
			}
			if ( 'checkbox' === $tipo ) {
				if ( ! is_array( $v ) || count( array_filter( $v, 'is_string' ) ) !== count( $v ) || array_diff( $v, $c['opcoes'] ) || count( $v ) !== count( array_unique( $v ) ) ) {
					return self::erro( 'escolha_invalida' ); }
				if ( ! empty( $c['obrigatorio'] ) && ! $v ) {
					return self::erro( 'campo_obrigatorio' );
				} $limpos[ $n ] = array_values( $v );
				continue;
			}
			if ( ! is_string( $v ) || strlen( $v ) > 20000 ) {
				return self::erro( 'campo_invalido' );
			} $v = trim( $v );
			if ( ! empty( $c['obrigatorio'] ) && '' === $v ) {
				return self::erro( 'campo_obrigatorio', 400, array( 'campo' => $n ) ); }
			if ( $v && ( ( 'email' === $tipo && ! is_email( $v ) ) || ( 'url' === $tipo && ! filter_var( $v, FILTER_VALIDATE_URL ) ) || ( in_array( $tipo, array( 'select', 'radio' ), true ) && ! in_array( $v, $c['opcoes'], true ) ) ) ) {
				return self::erro( 'campo_invalido', 400, array( 'campo' => $n ) ); }
			$limpos[ $n ] = 'textarea' === $tipo ? sanitize_textarea_field( $v ) : sanitize_text_field( $v );
			if ( ! empty( $c['papel'] ) ) {
				$papeis[ $c['papel'] ] = $limpos[ $n ]; }
		}
		if ( isset( $e['website'] ) && ! is_string( $e['website'] ) ) {
			return self::erro( 'isca_invalida' ); }
		$atrib     = array();
		$permitido = F3Base_Modulo_Consentimento::estado_permite_tags( F3Base_Modulo_Consentimento::estado_medido() );
		if ( isset( $e['atribuicao'] ) ) {
			$a = is_string( $e['atribuicao'] ) ? json_decode( $e['atribuicao'], true ) : $e['atribuicao'];
			if ( !F3Base_Atribuicao::validar($a) ) {
				return self::erro( 'atribuicao_invalida' );
            }
            // Sem armazenamento autorizado, só a origem declarada desta navegação.
            $atrib=F3Base_Atribuicao::normalizar($a);
        }
		$suspeito = ! empty( $e['website'] );
        $oferta=null;if(isset($e['oferta'])&&F3Base_Modulo_Consentimento::permite_categoria('medicao')){$oferta=F3Base_Ofertas_Medicao::validar($e['oferta']);if(!$oferta){return self::erro('oferta_invalida');}}
        $atrib=F3Base_Atribuicao::normalizar($atrib);
		$record   = bin2hex( random_bytes( 16 ) );
		foreach ( $uploads as [$file, $campo] ) {
			$r = F3Base_Arquivos_Privados::receber( $file, 'anexo', $campo );
			if ( ! $r['ok'] ) {
				foreach ( $anexos as $a ) {
					F3Base_Arquivos_Privados::eliminar( $a['id'] );
				} return self::erro( $r['codigo'], 503 );
			} $a        = $r['arquivo'];
			$a['campo'] = $campo['nome'];
			$anexos[]   = $a;
		}
		$page   = get_post( (int) $token['p'] );
		$cfg    = F3Base_Options::ler( 'f3base_contato' );
		$regime = $f['regime'] ?? 'registro';
		$metodo = array(
			'registro' => 'formulario',
			'whatsapp' => 'whatsapp_formulario',
			'conteudo' => 'conteudo',
		)[ $regime ];
		$origem = F3Base_Modulo_Endpoint_Leads::origem();
		$d      = array(
			'record_id'          => $record,
            'contexto_teste' => $marca['contexto_teste'],
			'correlacao'         => $sid,
			'formulario'         => $f['id'],
			'formulario_revisao' => $token['r'],
            'formulario_titulo' => $f['titulo'],
            'campos_snapshot'=>array_map(static fn($c)=>array_intersect_key($c,array_flip(array('nome','rotulo','tipo','papel','opcoes'))),$f['campos']),
            'campos_relatorio' => array_values(array_map(static fn($c)=>array_intersect_key($c,array_flip(array('nome','rotulo','tipo','opcoes'))),array_filter($f['campos'],static fn($c)=>in_array($c['tipo'],array('select','radio','checkbox'),true)&&(empty($c['papel'])||$c['papel']==='servico')))),
			'metodo'             => $metodo,
			'captura'            => $suspeito ? 'suspeito' : 'aceito',
			'campos'             => $limpos,
			'email'              => $papeis['email'] ?? '',
            'telefone' => $papeis['telefone'] ?? '',
            'linkedin' => $papeis['linkedin'] ?? '',
            'empresa'=>$papeis['empresa']??'', 'cargo'=>$papeis['cargo']??'',
            'servicos'=>isset($papeis['servico'])&&$papeis['servico']!==''?(array)$papeis['servico']:(!empty($f['servico_fixo'])?array($f['servico_fixo']):array()),
            'servico_origem'=>isset($papeis['servico'])&&$papeis['servico']!==''?'selecionado':(!empty($f['servico_fixo'])?'fixo':'ausente'),
			'nome'               => $papeis['nome'] ?? '',
			'pagina'             => $page ? get_permalink( $page ) : '',
			'snapshot'           => array(
				'site'          => get_bloginfo( 'name' ),
				'pagina_titulo' => $page ? $page->post_title : '',
				'usuario'       => get_current_user_id(),
			),
			'origem'             => $origem,
			'atribuicao'         => $atrib,
            'oferta' => $oferta,
            'navegacao' => $e['navegacao'] ?? null,
            'dispositivo' => $e['dispositivo'] ?? '',
            'retorno'=>$e['retorno']??'','largura_janela'=>$e['largura_janela']??null,'max_touch_points'=>$e['max_touch_points']??null,
			'suspeita_motivo'    => ! empty( $e['website'] ) ? 'isca' : '',
            'antispam_regra' => '2',
            'tempo_preenchimento_segundos' => !empty($token['interacao'])?max(0,time()-$token['t']):null,
            'sinais' => !empty($token['interacao'])&&time()-$token['t']<3?array('tempo_curto'):array(),
			'user_agent'         => substr( sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 500 ),
			'anexos'             => $anexos,
			'consentimento'      => F3Base_Modulo_Consentimento::estado_medido(),
			'consentimento_ref'  => F3Base_Modulo_Consentimento::referencia_confirmada(),
			'sessao'             => F3Base_Modulo_Consentimento::permite_categoria( 'medicao' ) && is_string( $e['sessao'] ?? null ) && preg_match( '/^[a-f0-9-]{16,64}$/D', $e['sessao'] ) ? $e['sessao'] : null,
			'notificar'          => ! $suspeito && ( $cfg['avisar_por_formulario'] ?? true ),
			'destinatarios'      => F3Base_Leads_Notificacoes::destinatarios( $f['destinatarios'] ?? $cfg['email_leads'] ?? array() ),
			'assunto'            => $f['assunto'] ?? $f['titulo'],
			'payload'            => array(
				'formulario' => $f['id'],
				'revisao'    => $token['r'],
				'campos'     => $limpos,
				'arquivos'   => array_map( static fn( $a )=>array_intersect_key( $a, array_flip( array( 'campo', 'nome', 'sha256', 'bytes' ) ) ), $anexos ),
			),
		);
		if ( ! F3Base_Arquivos_Privados::vincular( $anexos, $record ) ) {
			foreach ( $anexos as $a ) {
				F3Base_Arquivos_Privados::eliminar( $a['id'] );
			} return self::erro( 'vinculo_de_anexo_falhou', 503 ); }
		$d['resposta_visitante'] = $f['resposta_visitante'] ?? array( 'ativa' => false );
		$d = F3Base_Leads_Contexto::capturar( $d, F3Base_Modulo_Consentimento::permite_categoria( 'medicao' ) );
		$dedup = $nojs ? 'semjs|' . F3Base_Leads_Repositorio::hash( $d['payload'] ) . '|' . hash_hmac( 'sha256', wp_json_encode( $origem ), wp_salt( 'auth' ) ) . '|' . floor( time() / 300 ) : $sid;
		$r     = F3Base_Leads_Repositorio::guardar( $d, hash( 'sha256', 'form|' . $f['id'] . '|' . $dedup ) );
		if ( ! $r['ok'] || ! empty( $r['duplicado'] ) ) {
			foreach ( $anexos as $a ) {
				F3Base_Arquivos_Privados::eliminar( $a['id'] ); }
		}
		if ( ! $r['ok'] ) {
			return self::erro( $r['codigo'], 503 ); }
		$record   = $r['record_id'];
		$gravado  = F3Base_Leads_Repositorio::obter( $record );
		$suspeito = 'suspeito' === $gravado['captura'];
		$out      = array(
			'ok'             => true,
			'persisted'      => true,
			'duplicado'      => ! empty( $r['duplicado'] ),
			'aceito'         => ! $suspeito,
            'classe_trafego' => $gravado['classe_trafego'],
			'correlation_id' => $gravado['correlacao'],
			'method'         => $metodo,
			'mensagem'       => $suspeito ? 'Recebemos seu envio para análise.' : self::mensagens($f)['sucesso'],
		);
		if ( ! $suspeito && 'conteudo' === $regime ) {
			$g = F3Base_Conteudo_Privado::conceder( $record, $f, $gravado['email'] );
			if ( ! $g['ok'] ) {
				$out['conteudo_pendente'] = true;
				$out['mensagem']         .= ' O link de conteúdo está temporariamente indisponível.'; } else {
				$out['url'] = $g['url'];
				if ( $g['record_id'] !== $record ) {
					F3Base_Leads_Repositorio::eliminar( $record );
					$record           = $g['record_id'];
					$out['duplicado'] = true; }
				}
		}
		if ( ! $suspeito && 'whatsapp' === $regime ) {
			$out['url'] = 'https://wa.me/' . ( $f['whatsapp'] ?? $cfg['whatsapp_e164'] ) . '?text=' . rawurlencode( ( $cfg['mensagem_padrao'] ?? 'Contato pelo site' ) . "\n" . implode( "\n", array_map( static fn( $k, $v )=>$k . ': ' . ( is_array( $v ) ? implode( ', ', $v ) : $v ), array_keys( $limpos ), array_values( $limpos ) ) ) ); }
		if ( ! $out['duplicado'] && ! $suspeito ) {
			$out['notificacao'] = F3Base_Leads_Notificacoes::agendar( $record );
			$out['resposta_visitante'] = F3Base_Resposta_Visitante::enviar( $record );
			F3Base_Modulo_Meta_Capi::agendar_registro( $record, $permitido && F3Base_Modulo_Consentimento::permite_categoria( 'publicidade' ) );
		}
        return F3Base_Confirmacao::preparar($out,$f);
	}
	public static function post(): void {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			status_header( 405 );
			exit; }
		if ( empty( $_POST ) && (int) ( $_SERVER['CONTENT_LENGTH'] ?? 0 ) > 0 ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Anonymous POST is authenticated and scoped by the HMAC token in receber(); files are verified as actual uploads there.
			wp_die( 'O envio excedeu o limite total do servidor.', 'Envio não recebido', array( 'response' => 413 ) ); }
		$r  = self::receber( wp_unslash( $_POST ), $_FILES ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Anonymous POST is authenticated and scoped by the HMAC token in receber(); files are verified as actual uploads there.
        if(!empty($r['redirecionar'])){nocache_headers();header('Referrer-Policy: no-referrer');wp_redirect($r['redirecionar'],303,'F3 Base confirmação validada');exit;}
		$id = bin2hex( random_bytes( 32 ) );
		set_transient( 'f3base_confirmacao_' . $id, $r, 600 );
		nocache_headers();
		wp_safe_redirect(
			add_query_arg(
				array(
					'action' => 'f3base_confirmacao',
					'ref'    => $id,
				),
				admin_url( 'admin-post.php' )
			),
			303
		);
		exit;
	}
	public static function confirmacao(): void {
		nocache_headers();
		header( 'Cache-Control: private, no-store' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		add_filter('wp_robots',static fn()=>array('noindex'=>true,'nofollow'=>true),PHP_INT_MAX);
		$id = (string) ( $_GET['ref'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only private confirmation uses a random 256-bit short-lived reference and no-cache headers.
		$r  = preg_match( '/^[a-f0-9]{64}$/D', $id ) ? get_transient( 'f3base_confirmacao_' . $id ) : false;
		if ( ! $r ) {
			wp_die( 'Confirmação expirada.', 'Confirmação', array( 'response' => 410 ) ); }
		$html = '<p>' . esc_html( $r['mensagem'] ?? ( 'Envio não recebido: ' . ( $r['codigo'] ?? 'erro' ) ) ) . '</p>';
		if ( ! empty( $r['url'] ) ) {
			$html .= '<p><a rel="noreferrer noopener" href="' . esc_url( $r['url'] ) . '">Continuar</a></p>'; }
		wp_die( $html, 'Confirmação', array( 'response' => 200 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML assembled above uses esc_html for messages and esc_url for links.
	}
}
