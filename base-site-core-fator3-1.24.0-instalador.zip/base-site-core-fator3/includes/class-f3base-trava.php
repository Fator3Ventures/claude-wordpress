<?php
/** Reservas atômicas por tarefa. Nunca libera a reserva de outro processo. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Trava {
    public static function adquirir(string $tarefa, int $segundos=120): ?array {
        global $wpdb;
        $nome='f3base_trava_'.hash('sha256', $tarefa);
        $antigo=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$nome));
        if ($wpdb->last_error) { return null; }
        $estado=maybe_unserialize($antigo);
        if (is_array($estado) && ($estado['expira']??PHP_INT_MAX)<time()) {
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$nome,$antigo));
            wp_cache_delete($nome,'options');
        }
        $valor=array('dono'=>wp_generate_uuid4(),'expira'=>time()+max(15,min(900,$segundos)));
        $ok=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'off')",$nome,maybe_serialize($valor)));
        wp_cache_delete($nome,'options');
        return $ok===1?array('nome'=>$nome,'valor'=>$valor):null;
    }
    public static function liberar(array $reserva): void {
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$reserva['nome'],maybe_serialize($reserva['valor'])));
        wp_cache_delete($reserva['nome'],'options');
    }
}
