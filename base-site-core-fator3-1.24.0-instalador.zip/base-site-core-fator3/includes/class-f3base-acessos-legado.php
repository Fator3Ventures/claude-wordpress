<?php
/** Arquivo de agregados não reconciliáveis, separado dos totais atuais. Sem IP individual. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Acessos_Legado {
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_acessos_legado';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();$cc=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$t} (
 chave char(64) NOT NULL,
 dia date NOT NULL,
 regra varchar(64) NOT NULL,
 origem varchar(16) NOT NULL,
 contagem bigint unsigned NOT NULL,
 arquivado_em bigint unsigned NOT NULL,
 dados longtext NOT NULL,
 PRIMARY KEY  (chave),
 KEY periodo (dia,origem)
) ENGINE=InnoDB {$cc};");return !$wpdb->last_error;
    }
    /** Arquiva todo componente que cruza fontes novas, antes de liberar a publicação diária. */
    public static function reconciliar(array &$e,string $regra): void {
        $prontas=array();foreach($e['fontes']??array() as $id=>$s){if(($s['regra']??'')===$regra&&empty($s['erro'])&&!empty($s['disponivel'])){$prontas[$id]=true;}}
        $deps=array();foreach($e['legado']??array() as $dia=>$old){$ids=(array)($old['fontes']??array());foreach($old['arquivos']??array() as $a){$ids[]=hash('sha256',$a['nome']);}$deps[$dia]=array_unique($ids);}
        $selecionados=array();do{$antes=count($selecionados);foreach($deps as $dia=>$ids){if(array_intersect($ids,array_keys($prontas))){$selecionados[$dia]=true;foreach($ids as $id){$prontas[$id]=true;}}}}while(count($selecionados)!==$antes);
        if(!$selecionados){return;}
        global $wpdb;$arquivo=self::tabela();$origens=array('diario'=>$wpdb->prefix.F3Base_Modulo_Acessos_Servidor::TABELA,'horario'=>F3Base_Agentes::tabela());$colunas=array();
        foreach($origens as $k=>$t){$colunas[$k]=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t));if($wpdb->last_error||!$colunas[$k]){throw new RuntimeException('reconciliacao_arquivo_indisponivel');}}
        if(false===$wpdb->query('START TRANSACTION')){throw new RuntimeException('reconciliacao_transacao_falhou');}
        try{
            foreach(array_keys($selecionados) as $dia){$old=$e['legado'][$dia];$anterior=(string)($old['regra']??$old['config_hash']??'legado');
                // O recibo participa da mesma transação. Retomar com estado antigo não rearquiva os totais novos.
                $ids=$deps[$dia];sort($ids,SORT_STRING);$recibo=hash('sha256',wp_json_encode(array('reconciliacao',$dia,$anterior,$ids)));
                $existente=$wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE chave=%s',$arquivo,$recibo));if($wpdb->last_error){throw new RuntimeException('reconciliacao_recibo_indisponivel');}if($existente){continue;}
                foreach($origens as $origem=>$t){$pares=array();foreach($colunas[$origem] as $col){if(!preg_match('/^[a-z_]+$/D',$col)){throw new RuntimeException('reconciliacao_coluna_invalida');}$pares[]="'".$col."',`".$col.'`';}$json='JSON_OBJECT('.implode(',',$pares).')';
                    $sql="INSERT IGNORE INTO %i (chave,dia,regra,origem,contagem,arquivado_em,dados) SELECT SHA2(CONCAT(%s,%s,{$json}),256),dia,%s,%s,contagem,%d,{$json} FROM %i WHERE dia=%s";
                    if(false===$wpdb->query($wpdb->prepare($sql,$arquivo,$anterior,$origem,$anterior,$origem,time(),$t,$dia))||false===$wpdb->delete($t,array('dia'=>$dia))){throw new RuntimeException('reconciliacao_agregado_falhou');}
                }
                if(false===$wpdb->insert($arquivo,array('chave'=>$recibo,'dia'=>$dia,'regra'=>$anterior,'origem'=>'recibo','contagem'=>0,'arquivado_em'=>time(),'dados'=>wp_json_encode(array('fontes'=>$ids,'regra_destino'=>$regra))))){throw new RuntimeException('recibo_nao_persistido');}
            }
            if(false===$wpdb->query('COMMIT')){throw new RuntimeException('reconciliacao_commit_falhou');}
        }catch(Throwable $x){$wpdb->query('ROLLBACK');throw $x;}
        foreach(array_keys($selecionados) as $dia){$e['reconciliacao'][$dia]=array('fontes'=>$deps[$dia],'em'=>time(),'arquivo'=>'f3base_acessos_legado','motivo'=>'Calendário anterior separado antes da publicação das contribuições atuais.');unset($e['dias'][$dia],$e['legado'][$dia]);}
    }
    public static function lacuna(string $dia,array $e,string $regra): bool {
        foreach($e['reconciliacao'][$dia]['fontes']??array() as $id){$s=$e['fontes'][$id]??array();if(($s['regra']??'')!==$regra||!empty($s['erro'])||empty($s['disponivel'])){return true;}}return false;
    }
    public static function consultar(array $v=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $schema=array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>10000));
        if(is_wp_error(rest_validate_value_from_schema($v,array('type'=>'object','properties'=>$schema,'additionalProperties'=>false)))){return array('ok'=>false,'codigo'=>'filtros_invalidos');}
        $de=$v['de']??wp_date('Y-m-d',time()-29*DAY_IN_SECONDS);$ate=$v['ate']??wp_date('Y-m-d');$pagina=$v['pagina']??1;if($de>$ate){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE dia BETWEEN %s AND %s ORDER BY dia,chave LIMIT 101 OFFSET %d',self::tabela(),$de,$ate,($pagina-1)*100),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}
        foreach($rows as &$r){$r['dados']=json_decode($r['dados'],true);}unset($r);return array('ok'=>true,'linhas'=>array_slice($rows,0,100),'proxima_pagina'=>count($rows)>100?$pagina+1:null,'limites'=>'Arquivo de auditoria. Não somar aos relatórios atuais: pode haver sobreposição entre calendários e regras. Não é prova de identidade atual.');
    }
}
