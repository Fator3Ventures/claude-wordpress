<?php
/** Operações autenticadas de conteúdo privado; publicação por ponteiro transacional. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Arquivos_Servico {
    public const TETO_TRANSPORTE = 8388608;
    private static function pode(): bool { return current_user_can('manage_options') || current_user_can('f3base_gerir_formularios'); }
    private static function erro(string $codigo): array { return array('ok'=>false,'codigo'=>$codigo); }
    private static function tabela(string $nome): string { return F3Base_Leads_Repositorio::tabela($nome); }
    public static function registrar(): void {
        $id=array('type'=>'string','pattern'=>'^[a-f0-9]{32}$');
        $sha=array('type'=>'string','pattern'=>'^[a-f0-9]{64}$');
        $dados=array(
            'nome'=>array('type'=>'string','minLength'=>1,'maxLength'=>250),
            'base64'=>array('type'=>'string','maxLength'=>11184812,'description'=>'Até 8 MiB decodificados; limite de transporte, sem alterar anexos.'),
            'midia_id'=>array('type'=>'integer','minimum'=>1),
            'sha256'=>$sha,
            'idempotency_key'=>array('type'=>'string','minLength'=>16,'maxLength'=>128),
        );
        F3Base_Servicos::ability('arquivos-privados-cadastrar','Cadastrar conteúdo privado por base64 ou cópia de mídia local',array(__CLASS__,'cadastrar'),$dados,array('sha256','idempotency_key'),false,'f3base_gerir_formularios');
        F3Base_Servicos::ability('arquivos-privados-substituir','Substituir conteúdo, preservando ID e concessões vigentes',array(__CLASS__,'substituir'),$dados+array('id'=>$id,'expected_sha256'=>$sha),array('id','sha256','expected_sha256','idempotency_key'),false,'f3base_gerir_formularios');
        F3Base_Servicos::ability('arquivos-privados-listar','Listar metadados privados e vínculos, sem caminhos ou concessões',array(__CLASS__,'listar'),array('pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>100000),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>100),'id'=>$id),array(),true,'f3base_gerir_formularios');
        F3Base_Servicos::ability('arquivos-privados-excluir-origem','Excluir mídia pública após conferir cópia privada e vínculos',array(__CLASS__,'excluir_origem'),array('id'=>$id,'expected_sha256'=>$sha,'confirmar'=>array('type'=>'boolean'),'aceitar_vinculos'=>array('type'=>'boolean')),array('id','expected_sha256','confirmar'),false,'f3base_gerir_formularios');
    }
    public static function cadastrar(array $e): array { return self::gravar($e,false); }
    public static function substituir(array $e): array { return self::gravar($e,true); }
    private static function publico(array $a): array {
        $r=array_intersect_key($a,array_flip(array('id','nome','bytes','mime','mime_alerta','sha256','criado_em','atualizado_em','estado','midia_id','finalidade')));
        foreach(array('bytes','criado_em','atualizado_em','midia_id') as $k){$r[$k]=(int)($r[$k]??0);}
        $r['formularios']=array_values(array_map(static fn($f)=>$f['id'],array_filter((array)F3Base_Options::ler('f3base_formularios'),static fn($f)=>($f['ativo']??'')===$a['id'])));
        return $r;
    }
    public static function listar(array $e=array()): array {
        if(!self::pode()){return self::erro('sem_permissao');}
        global $wpdb;$lim=max(1,min(100,(int)($e['limite']??25)));$pag=max(1,(int)($e['pagina']??1));
        $where="finalidade='conteudo'";$args=array(self::tabela('arquivos_leads'));
        if(!empty($e['id'])){$where.=' AND id=%s';$args[]=$e['id'];}
        $sql=$wpdb->prepare('SELECT * FROM %i WHERE '.$where.' ORDER BY criado_em DESC,id LIMIT %d OFFSET %d',array_merge($args,array($lim+1,($pag-1)*$lim)));
        $rows=$wpdb->get_results($sql,ARRAY_A);if($wpdb->last_error){return self::erro('consulta_indisponivel');}
        return array('ok'=>true,'arquivos'=>array_map(array(__CLASS__,'publico'),array_slice($rows,0,$lim)),'proxima_pagina'=>count($rows)>$lim?$pag+1:null,'teto_transporte_bytes'=>self::TETO_TRANSPORTE);
    }
    /** Validates trusted media source without accepting a filesystem path from the caller. */
    private static function fonte(array $e): array {
        $tem_bytes=array_key_exists('base64',$e);$media=(int)($e['midia_id']??0);
        if($tem_bytes===($media>0)){return self::erro('informe_bytes_ou_midia');}
        if($tem_bytes){
            if(!is_string($e['base64'])||strlen($e['base64'])>11184812){return self::erro('teto_transporte');}
            $bytes=base64_decode($e['base64'],true);
            if($bytes===false||strlen($bytes)>self::TETO_TRANSPORTE){return self::erro('base64_ou_teto_invalido');}
            return array('ok'=>true,'bytes'=>$bytes,'tamanho'=>strlen($bytes),'nome'=>$e['nome']??'arquivo','midia_id'=>0);
        }
        if(get_post_type($media)!=='attachment'||!current_user_can('edit_post',$media)){return self::erro('midia_sem_permissao');}
        $path=get_attached_file($media,true);$uploads=wp_upload_dir(null,false);$root=realpath($uploads['basedir']);$real=$path?realpath($path):false;
        if(!$real||!$root||is_link($path)||!str_starts_with($real,$root.DIRECTORY_SEPARATOR)||!is_file($real)||!is_readable($real)){return self::erro('midia_local_indisponivel');}
        // Reject symlinks in any component, including parents of the attachment.
        for($p=$path;$p!==dirname($p);$p=dirname($p)){if(is_link($p)){return self::erro('midia_symlink');}}
        return array('ok'=>true,'path'=>$real,'tamanho'=>filesize($real),'nome'=>$e['nome']??basename($real),'midia_id'=>$media);
    }
    private static function gravar(array $e,bool $substituir): array {
        if(!self::pode()){return self::erro('sem_permissao');}
        if(!preg_match('/^[a-f0-9]{64}$/D',(string)($e['sha256']??''))||strlen((string)($e['idempotency_key']??''))<16||strlen((string)$e['idempotency_key'])>128){return self::erro('hash_ou_chave_invalida');}
        if($substituir&&(!preg_match('/^[a-f0-9]{32}$/D',(string)($e['id']??''))||!preg_match('/^[a-f0-9]{64}$/D',(string)($e['expected_sha256']??'')))){return self::erro('id_ou_revisao_invalida');}
        $key=hash('sha256','arquivo|'.$e['idempotency_key']);$hash=hash('sha256',wp_json_encode(array($substituir,$e['id']??null,$e['expected_sha256']??null,$e['sha256'],$e['nome']??null,$e['midia_id']??0)));
        $lock=F3Base_Trava::adquirir('arquivo-'.$key,300);if(!$lock){return self::erro('operacao_em_andamento');}
        global $wpdb;$dest='';$transacao=false;
        try {
            $old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela('arquivos_operacoes'),$key),ARRAY_A);
            if($old){return hash_equals($old['payload_hash'],$hash)?json_decode($old['resultado'],true)+array('duplicado'=>true):self::erro('idempotencia_divergente');}
            $anterior=$substituir?F3Base_Arquivos_Privados::obter($e['id']):null;
            if($substituir&&(!$anterior||$anterior['finalidade']!=='conteudo'||$anterior['estado']!=='ativo'||!hash_equals($anterior['sha256'],$e['expected_sha256']))){return self::erro('revisao_divergente');}
            $f=self::fonte($e);if(empty($f['ok'])){return $f;}
            $root=F3Base_Arquivos_Privados::raiz(true);if(!$root||!class_exists('finfo')){return self::erro('armazenamento_indisponivel');}
            $size=$f['tamanho'];$free=disk_free_space($root);if($size===false||$size<1||$free===false||$free<$size+1048576){return self::erro('arquivo_vazio_ou_sem_espaco');}
            $blob_id=bin2hex(random_bytes(16));$id=$substituir?$e['id']:$blob_id;$dest=$root.'/'.$blob_id;
            $h=@fopen($dest,'xb');if(!$h){return self::erro('escrita_indisponivel');}
            if(isset($f['bytes'])){$n=fwrite($h,$f['bytes']);}else{$in=@fopen($f['path'],'rb');$n=$in?stream_copy_to_stream($in,$h):false;if($in){fclose($in);}}
            fflush($h);if(function_exists('fsync')){fsync($h);}fclose($h);
            if($n!==$size||!@chmod($dest,0600)||!hash_equals($e['sha256'],(string)hash_file('sha256',$dest))){return self::erro('copia_ou_sha256_divergente');}
            $mime=(new finfo(FILEINFO_MIME_TYPE))->file($dest)?:'application/octet-stream';$nome=sanitize_file_name($f['nome']);if(!$nome){$nome='arquivo';}
            $a=array('id'=>$id,'blob_id'=>$blob_id,'dono'=>'','finalidade'=>'conteudo','nome'=>$nome,'mime'=>$mime,'mime_alerta'=>F3Base_Arquivos_Privados::alerta_mime($nome,$mime),'bytes'=>$size,'sha256'=>$e['sha256'],'criado_em'=>$anterior['criado_em']??time(),'atualizado_em'=>time(),'midia_id'=>$f['midia_id'],'estado'=>'ativo');
            // Staging record allows cleanup after a process crash before publication.
            if(!$wpdb->insert(self::tabela('arquivos_blobs'),array('blob_id'=>$blob_id,'ativo'=>$id,'estado'=>'preparado','criado_em'=>time(),'retirar_em'=>time()+DAY_IN_SECONDS))){return self::erro('registro_blob_falhou');}
            if(false===$wpdb->query('START TRANSACTION')){return self::erro('transacao_indisponivel');}$transacao=true;
            if($substituir){
                $atual=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s FOR UPDATE',self::tabela('arquivos_leads'),$id),ARRAY_A);
                if(!$atual||$atual['sha256']!==$e['expected_sha256']||$atual['estado']!=='ativo'){return self::erro('revisao_divergente');}
                if(1!==$wpdb->update(self::tabela('arquivos_leads'),$a,array('id'=>$id,'sha256'=>$e['expected_sha256']))){return self::erro('publicacao_falhou');}
                if(false===$wpdb->query($wpdb->prepare('UPDATE %i SET versao=%s WHERE ativo=%s AND revogada=0 AND expira>=%d AND usados<quota',self::tabela('concessoes'),$a['sha256'],$id,time()))){return self::erro('vinculo_concessoes_falhou');}
                $antigo=$atual['blob_id']?:$id;
                if(false===$wpdb->query($wpdb->prepare('INSERT INTO %i (blob_id,ativo,estado,criado_em,retirar_em) VALUES (%s,%s,%s,%d,%d) ON DUPLICATE KEY UPDATE estado=VALUES(estado),retirar_em=VALUES(retirar_em)',self::tabela('arquivos_blobs'),$antigo,$id,'retirado',time(),time()+DAY_IN_SECONDS))){return self::erro('registro_versao_falhou');}
            }elseif(!$wpdb->insert(self::tabela('arquivos_leads'),$a)){return self::erro('cadastro_falhou');}
            if(false===$wpdb->update(self::tabela('arquivos_blobs'),array('estado'=>'ativo','retirar_em'=>0),array('blob_id'=>$blob_id))){return self::erro('registro_publicacao_falhou');}
            $r=array('ok'=>true,'persisted'=>true,'arquivo'=>self::publico($a),'origem_publica_preservada'=>$f['midia_id']>0,'aviso'=>$f['midia_id']?'A mídia original continua pública; a exclusão é uma operação separada. Caches e cópias externas não são apagados.':'','concessoes'=>'vigentes_seguem_versao_nova');
            if(!$wpdb->insert(self::tabela('arquivos_operacoes'),array('chave'=>$key,'payload_hash'=>$hash,'resultado'=>wp_json_encode($r),'criado_em'=>time()))){return self::erro('idempotencia_nao_persistida');}
            if(false===$wpdb->query('COMMIT')){return self::erro('commit_indeterminado');}
            $transacao=false;$dest='';return $r;
        } finally {
            if($transacao){$wpdb->query('ROLLBACK');}
            // A DB commit with lost acknowledgement may have succeeded. Never delete a referenced blob_id.
            if($dest){$ref=$wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE blob_id=%s',self::tabela('arquivos_leads'),basename($dest)));if(!$ref&&!$wpdb->last_error){@unlink($dest);}}
            F3Base_Trava::liberar($lock);
        }
    }
    public static function excluir_origem(array $e): array {
        if(!self::pode()){return self::erro('sem_permissao');}
        $a=F3Base_Arquivos_Privados::obter((string)($e['id']??''));
        if(!$a||$a['finalidade']!=='conteudo'||$a['estado']!=='ativo'||!hash_equals($a['sha256'],(string)($e['expected_sha256']??''))){return self::erro('revisao_divergente');}
        $id=(int)$a['midia_id'];if(!$id||!get_post($id)){return array('ok'=>true,'ja_ausente'=>true);}
        if(!current_user_can('delete_post',$id)){return self::erro('midia_sem_permissao');}
        $path=F3Base_Arquivos_Privados::caminho($a['id']);if(!$path||!is_file($path)||!hash_equals($a['sha256'],(string)hash_file('sha256',$path))){return self::erro('copia_privada_nao_integra');}
        global $wpdb;$url=wp_get_attachment_url($id);$refs=$wpdb->get_results($wpdb->prepare("SELECT ID,post_title FROM {$wpdb->posts} WHERE ID<>%d AND post_status NOT IN ('trash','auto-draft') AND (post_content LIKE %s OR ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_thumbnail_id' AND meta_value=%s)) LIMIT 101",$id,'%'.$wpdb->esc_like((string)$url).'%',(string)$id),ARRAY_A);
        if(empty($e['confirmar'])||($refs&&empty($e['aceitar_vinculos']))){return array('ok'=>false,'codigo'=>'confirmacao_explicita_necessaria','vinculos_conhecidos'=>$refs,'limite_vinculos'=>100,'aviso'=>'Não abrange código do tema, CSS, caches ou cópias externas.');}
        $ok=(bool)wp_delete_attachment($id,true);return array('ok'=>$ok,'eliminado'=>$ok,'vinculos_conhecidos'=>$refs,'aviso'=>'Caches e cópias externas têm retenção independente.');
    }
    public static function limpar(): void {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT b.blob_id FROM %i b LEFT JOIN %i a ON a.blob_id=b.blob_id OR (a.blob_id='' AND a.id=b.blob_id) WHERE b.estado IN ('preparado','retirado') AND b.retirar_em<%d AND a.id IS NULL LIMIT 50",self::tabela('arquivos_blobs'),self::tabela('arquivos_leads'),time()),ARRAY_A);
        $root=F3Base_Arquivos_Privados::raiz();if(!$root){return;}
        foreach($rows as $r){if(!preg_match('/^[a-f0-9]{32}$/D',$r['blob_id'])){continue;}$p=$root.'/'.$r['blob_id'];if(is_link($p)){continue;}if(!file_exists($p)||@unlink($p)){$wpdb->delete(self::tabela('arquivos_blobs'),array('blob_id'=>$r['blob_id']));}}
    }
}
