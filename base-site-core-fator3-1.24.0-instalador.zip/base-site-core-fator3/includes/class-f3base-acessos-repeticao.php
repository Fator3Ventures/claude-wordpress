<?php
/** Bounded evidence during one authorized log scan; never joins logs with contacts. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Acessos_Repeticao {
    const VERSAO=1;
    const MAX_ORIGENS=2000;
    private static array $janelas=array();
    private static array $resumo=array();
    public static function iniciar(array $estado=array()): void {self::$janelas=array();self::$resumo=array('versao'=>self::VERSAO,'linhas'=>0,'suspeitas'=>0,'limite_atingido'=>false,'evidencias'=>array());if(($estado['versao']??0)===self::VERSAO&&($estado['expira']??0)>time()){self::$janelas=array_slice((array)($estado['janelas']??array()),0,self::MAX_ORIGENS,true);self::$resumo=(array)($estado['resumo']??self::$resumo);}}
    public static function observar(string $linha,array $r,int $quando): array {
        if(empty(F3Base_Options::ler('f3base_classificacao_acessos')['repeticao'])){return $r;}
        if(!self::$resumo){self::iniciar();}++self::$resumo['linhas'];
        if(!in_array($r['agente'],array('navegador-provavel','desconhecido'),true)||$r['caminho']===''||!preg_match('/^(\S+)\s/',$linha,$m)||!filter_var($m[1],FILTER_VALIDATE_IP)){return $r;}
        // Per UTC day and site. Only HMAC stays in bounded process memory, no raw address is retained.
        $origem=hash_hmac('sha256',gmdate('Y-m-d',$quando).'|'.$m[1],wp_salt('auth').'|'.home_url('/'));
        $key=hash('sha256',wp_json_encode(array($origem,$r['caminho'],$r['metodo'],$r['status'])));
        if(self::$resumo['linhas']%100===0){foreach(self::$janelas as $k=>$v){if($v['ultimo']<$quando-DAY_IN_SECONDS){unset(self::$janelas[$k]);}}}
        if(!isset(self::$janelas[$key])){if(count(self::$janelas)>=self::MAX_ORIGENS){self::$resumo['limite_atingido']=true;return $r;}self::$janelas[$key]=array('ultimo'=>$quando,'n'=>0,'media'=>0.0,'m2'=>0.0);return $r;}
        $v=&self::$janelas[$key];$delta=$quando-$v['ultimo'];if($delta<=0||$delta>DAY_IN_SECONDS){return $r;}$v['ultimo']=$quando;++$v['n'];$dif=$delta-$v['media'];$v['media']+=$dif/$v['n'];$v['m2']+=$dif*($delta-$v['media']);
        // At least six equal intervals >= 30 seconds; rapid repeated form clicks are not evidence here.
        $cv=$v['n']>1&&$v['media']>0?sqrt($v['m2']/($v['n']-1))/$v['media']:1;
        if($v['n']>=6&&$v['media']>=30&&$cv<=0.02){
            $r['agente']='automacao-suspeita';++self::$resumo['suspeitas'];$dim=hash('sha256',$r['caminho'].'|'.$r['metodo'].'|'.$r['status']);
            if(isset(self::$resumo['evidencias'][$dim])||count(self::$resumo['evidencias'])<100){$ev=self::$resumo['evidencias'][$dim]??array('caminho'=>$r['caminho'],'metodo'=>$r['metodo'],'status'=>$r['status'],'contagem'=>0,'motivo'=>'periodicidade_6_intervalos_cv_002','intervalo_medio_segundos'=>round($v['media'],1));++$ev['contagem'];self::$resumo['evidencias'][$dim]=$ev;}
        }unset($v);return $r;
    }
    /** Estado temporário vinculado ao offset do log atual, nunca ao histórico de contatos. */
    public static function exportar(): array {return array('versao'=>self::VERSAO,'janelas'=>self::$janelas,'resumo'=>self::$resumo,'expira'=>time()+DAY_IN_SECONDS);}
    public static function concluir(): void {
        if(!self::$resumo){return;}$r=self::$resumo;$r['evidencias']=array_values($r['evidencias']);$r['em']=time();$r['expira']=time()+DAY_IN_SECONDS;$r['escopo']='ultima_leitura_limitada; sem IP ou identificador de origem persistido';
        F3Base_Options::atualizar_estado('f3base_acessos_repeticao',static fn()=>$r);self::$janelas=array();self::$resumo=array();
    }
    public static function diagnostico(): array {
        $r=(array)get_option('f3base_acessos_repeticao',array());if(($r['expira']??0)<time()){return array('versao'=>self::VERSAO,'estado'=>'sem_evidencia_vigente');}
        return $r+array('estado'=>'observado','identidade_confirmada'=>false,'janela_maxima_segundos'=>DAY_IN_SECONDS,'limite_origens'=>self::MAX_ORIGENS);
    }
    public static function limpar(): void {$r=get_option('f3base_acessos_repeticao',array());if(($r['expira']??0)<time()&&$r){delete_option('f3base_acessos_repeticao');}}
}
