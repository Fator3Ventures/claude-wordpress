<?php
/** Confirmation references contain no visitor data and never create conversions. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Confirmacao {
    public static function iniciar(): void {add_action('template_redirect',array(__CLASS__,'pagina'),-999);}
    public static function normalizar(string $url): string {
        $url=trim($url);if($url===''){return '';}
        if(preg_match('/[\x00-\x20\\\\]/',$url)||strlen($url)>2048||str_starts_with($url,'//')){return '';}
        if(str_starts_with($url,'/')){$base=wp_parse_url(home_url());$url=$base['scheme'].'://'.$base['host'].(isset($base['port'])?':'.$base['port']:'').$url;}
        $p=wp_parse_url($url);$home=wp_parse_url(home_url());
        if(!$p||!empty($p['user'])||!empty($p['pass'])||empty($p['host'])||!in_array($p['scheme']??'',array('http','https'),true)){return '';}
        $interno=strtolower($p['host'])===strtolower($home['host'])&&($p['port']??null)===($home['port']??null)&&$p['scheme']===$home['scheme'];
        if(!$interno&&(($p['scheme']??'')!=='https'||!in_array(strtolower($p['host']),(array)F3Base_Options::ler('f3base_confirmacao_hosts'),true)||!empty($p['port'])&&$p['port']!==443)){return '';}
        parse_str($p['query']??'',$q);foreach(array('f3base_confirmacao_ref','f3base_continuar','action','g','assinatura') as $key){if(isset($q[$key])){return '';}}
        if($interno&&preg_match('~/(?:wp-admin|wp-login\.php|wp-json)(?:/|$)~',$p['path']??'')){return '';}
        return esc_url_raw($url,array('http','https'));
    }
    public static function preparar(array $r,array $f): array {
        $url=self::normalizar((string)($f['confirmacao_url']??''));
        if(!$url||empty($r['ok'])||empty($r['persisted'])||empty($r['aceito'])){return $r;}
        $ref=bin2hex(random_bytes(32));$dados=array('mensagem'=>$r['mensagem'],'url'=>$r['url']??'','destino'=>$url,'formulario'=>$f['id']);
        if(!set_transient('f3base_confirmacao_'.$ref,$dados,600)){$r['confirmacao_pendente']=true;return $r;}
        $ponte=add_query_arg(array('action'=>'f3base_confirmacao','ref'=>$ref),admin_url('admin-post.php'));
        $interno=wp_parse_url($url,PHP_URL_HOST)===wp_parse_url(home_url(),PHP_URL_HOST);
        // External pages explicitly allowed by the operator receive only a temporary return reference.
        // Their page must expose this return link; a fallback link is also in the accepted response.
        $r['redirecionar']=$interno?add_query_arg('f3base_confirmacao_ref',$ref,$url):(!empty($dados['url'])?add_query_arg('f3base_continuar',$ponte,$url):$url);
        $r['confirmacao_privada']=$ponte;$r['confirmacao_expira_em']=time()+600;
        return $r;
    }
    public static function pagina(): void {
        if(!isset($_GET['f3base_confirmacao_ref'])){return;}
        if(!defined('DONOTCACHEPAGE')){define('DONOTCACHEPAGE',true);}
        nocache_headers();header('Cache-Control: private, no-store, max-age=0');header('Referrer-Policy: no-referrer');header('X-Robots-Tag: noindex, nofollow, noarchive');
        $ref=(string)$_GET['f3base_confirmacao_ref'];$r=preg_match('/^[a-f0-9]{64}$/D',$ref)?get_transient('f3base_confirmacao_'.$ref):false;
        if(!$r){wp_die('Confirmação expirada.','Confirmação',array('response'=>410));}
        $path=wp_parse_url($r['destino']??'',PHP_URL_PATH)?:'/';$request=wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH);
        if(!$request||rtrim($path,'/')!==rtrim($request,'/')){wp_die('Confirmação indisponível.','Confirmação',array('response'=>404));}
        $post_id=url_to_postid($r['destino']);$post=$post_id?get_post($post_id):null;$titulo='Confirmação';$html='';
        // The temporary private response does not execute the theme, embeds, forms or third-party tags.
        if($post&&is_post_publicly_viewable($post)&&!post_password_required($post)){$titulo=get_the_title($post);$html=wpautop(wp_kses_post(strip_shortcodes($post->post_content)));}
        $html.='<section data-clarity-mask="true"><p>'.esc_html($r['mensagem']).'</p>';
        if(!empty($r['url'])){$html.='<p><a class="button wp-element-button" rel="noreferrer noopener" href="'.esc_url($r['url']).'">Continuar: acessar material ou WhatsApp</a></p>';}
        $html.='</section>';wp_die($html,esc_html($titulo),array('response'=>200));
    }
}
