<?php
/** Retira apenas propriedades de oportunidades alheias; preserva todos os outros bytes. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Json_Diario {
    private string $raw; private int $at=0; private array $changes=array();
    public static function sanear($raw) {
        if(!is_string($raw)||$raw===''){return $raw;}
        try{$value=json_decode($raw,false,64,JSON_THROW_ON_ERROR);}catch(JsonException $e){return $raw;}
        if(!is_array($value)&&!is_object($value)){return $raw;}
        $self=new self();$self->raw=$raw;$node=$self->node();$self->walk($node);
        usort($self->changes,static fn($a,$b)=>$b[0]<=>$a[0]);
        foreach($self->changes as [$start,$end,$text]){$raw=substr_replace($raw,$text,$start,$end-$start);}return $raw;
    }
    private function whitespace(): void {while(isset($this->raw[$this->at])&&str_contains(" \t\r\n",$this->raw[$this->at])){++$this->at;}}
    private function string_end(): void {++$this->at;while(isset($this->raw[$this->at])){if($this->raw[$this->at]==='\\'){$this->at+=2;}elseif($this->raw[$this->at++]==='"'){break;}}}
    private function node(): array {
        $this->whitespace();$start=$this->at;$c=$this->raw[$this->at];$children=array();
        if($c==='{'||$c==='['){$end=$c==='{'?'}':']';++$this->at;$this->whitespace();
            while($this->raw[$this->at]!==$end){$this->whitespace();$keyStart=$this->at;$key=null;
                if($c==='{'){$this->string_end();$key=json_decode(substr($this->raw,$keyStart,$this->at-$keyStart),true);$this->whitespace();++$this->at;}
                $n=$this->node();$children[]=array('key'=>$key,'start'=>$keyStart,'node'=>$n);$this->whitespace();if($this->raw[$this->at]===','){++$this->at;}else{break;}}
            ++$this->at;
        }elseif($c==='"'){$this->string_end();}else{while(isset($this->raw[$this->at])&&!str_contains(",]} \t\r\n",$this->raw[$this->at])){++$this->at;}}
        return array('start'=>$start,'end'=>$this->at,'type'=>$c,'children'=>$children);
    }
    private function walk(array $node): void {
        foreach($node['children'] as $child){$n=$child['node'];
            if($child['key']==='outras_oportunidades'&&in_array($n['type'],array('[','{'),true)){
                foreach($n['children'] as $record){$v=$record['node'];if($v['type']!=='{'){continue;}$keep=array();$removed=false;
                    foreach($v['children'] as $prop){if(in_array($prop['key'],array('tipo','id'),true)){$keep[]=substr($this->raw,$prop['start'],$prop['node']['end']-$prop['start']);}else{$removed=true;}}
                    if($removed){$this->changes[]=array($v['start'],$v['end'],'{'.implode(',',$keep).'}');}
                }
            }else{$this->walk($n);}
        }
    }
}
