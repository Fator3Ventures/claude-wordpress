<?php
/** Avisos internos: HTML e alternativa MIME real, limitados a esta mensagem. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Email {
    public static function html(array $a): string {
        $body='<p style="margin:0 0 8px;color:#475569">'.esc_html($a['site']).'</p><h1 style="font-size:24px;line-height:1.3;margin:0 0 24px">'.(!empty($a['teste'])?'Contato de teste':'Novo contato recebido').'</h1>';
        foreach(F3Base_Contato_Apresentacao::secoes($a) as $title=>$items){
            $body.='<h2 style="font-size:18px;border-top:1px solid #dbe2ea;padding-top:20px;margin:28px 0 12px">'.esc_html($title).'</h2>';
            foreach($items as $label=>$values){$body.='<p style="margin:0 0 14px"><strong>'.esc_html($label).'</strong><br>';
                $parts=array();foreach((array)$values as $value){$value=(string)$value;$safe=F3Base_Contato_Apresentacao::url($value);$parts[]=F3Base_Contato_Apresentacao::link_permitido($title,$label)&&preg_match('~^(https?://|tel:|mailto:)~',$value)&&$safe===$value?'<a style="color:#145bb8;word-break:break-word" href="'.esc_url($safe).'">'.esc_html($value).'</a>':nl2br(esc_html($value));}
                $body.=implode('<br>',$parts).'</p>';
            }
        }
        $body.='<p style="margin:28px 0 0"><a style="color:#145bb8;font-weight:bold" href="'.esc_url($a['registro_url']).'">'.esc_html(F3Base_Contato_Apresentacao::ROTULO_REGISTRO).'</a><br><small>O acesso ao registro exige login autorizado.</small></p>';
        return self::documento($body);
    }
    public static function documento(string $html): string {return '<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body style="margin:0;background:#f1f5f9;color:#172337;font:16px/1.6 Arial,sans-serif"><table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td style="padding:24px 12px"><table role="presentation" align="center" width="100%" cellspacing="0" cellpadding="0" style="max-width:640px;background:#fff"><tr><td style="padding:28px;word-break:break-word">'.$html.'</td></tr></table></td></tr></table></body></html>';}
    public static function enviar($to,string $subject,string $html,string $text,array $headers): bool {
        global $phpmailer;$previous=$phpmailer??null;if(is_object($previous)){$phpmailer=clone $previous;}
        $token=bin2hex(random_bytes(16)); $headers=array_values(array_filter($headers,static fn($h)=>stripos($h,'Content-Type:')!==0));
        $headers[]='Content-Type: text/html; charset=UTF-8'; $headers[]='X-F3Base-Mensagem: '.$token;
        $touched=array();
        $prepare=static function($mail)use($token,$html,$text,&$touched): void {
            $match=false;foreach($mail->getCustomHeaders() as $h){if(strtolower($h[0])==='x-f3base-mensagem'&&hash_equals($token,trim($h[1]))){$match=true;break;}}if(!$match){return;}
            $touched[]=array($mail,$mail->AltBody,$mail->ContentType,$mail->Timeout,$mail->getSMTPInstance()->Timelimit);
            $mail->isHTML(true);$mail->Body=$html;$mail->AltBody=$text;$mail->Timeout=10;$mail->getSMTPInstance()->Timelimit=10;
        };
        // A wp_mail called inside an SMTP hook must get its own mailer instance.
        $pilha=array();
        $isolate=static function($pre,$atts)use(&$pilha,&$touched){
            $h=$atts['headers']??array();$h=is_array($h)?implode("\n",$h):(string)$h;
            if($pre!==null||str_contains($h,'X-F3Base-Mensagem:')){return $pre;}
            global $phpmailer;$outer=$phpmailer??null;if(!is_object($outer)){return $pre;}$clone=clone $outer;foreach(array_reverse($touched) as [$mail,$alt,$type,$timeout,$limit]){if($mail===$outer){$clone->AltBody=$alt;$clone->ContentType=$type;$clone->Timeout=$timeout;break;}}
            // The original wp_mail keeps all its arguments and runs filters once.
            $pilha[]=array($outer,$clone);$phpmailer=$clone;return $pre;
        };
        $devolver=static function()use(&$pilha): void {global $phpmailer;if($pilha&&$phpmailer===$pilha[count($pilha)-1][1]){$pair=array_pop($pilha);$phpmailer=$pair[0];}};
        add_action('wp_mail_succeeded',$devolver,PHP_INT_MAX);add_action('wp_mail_failed',$devolver,PHP_INT_MAX);
        add_filter('pre_wp_mail',$isolate,PHP_INT_MAX,2);add_action('phpmailer_init',$prepare,PHP_INT_MAX);
        try {return wp_mail($to,$subject,$html,$headers);}
        finally {remove_action('wp_mail_succeeded',$devolver,PHP_INT_MAX);remove_action('wp_mail_failed',$devolver,PHP_INT_MAX);remove_filter('pre_wp_mail',$isolate,PHP_INT_MAX);remove_action('phpmailer_init',$prepare,PHP_INT_MAX);foreach(array_reverse($touched) as [$mail,$alt,$type,$timeout,$limit]){$mail->AltBody=$alt;$mail->ContentType=$type;$mail->Timeout=$timeout;$mail->getSMTPInstance()->Timelimit=$limit;if(method_exists($mail,'clearCustomHeader')){$mail->clearCustomHeader('X-F3Base-Mensagem');}else{$resto=array_filter($mail->getCustomHeaders(),static fn($x)=>strtolower($x[0])!=='x-f3base-mensagem');$mail->clearCustomHeaders();foreach($resto as $x){$mail->addCustomHeader($x[0],$x[1]);}}}$phpmailer=$previous;}
    }
}
