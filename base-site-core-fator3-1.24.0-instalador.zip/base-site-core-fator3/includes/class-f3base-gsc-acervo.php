<?php
/** Snapshots Search Console: páginas em estágio, publicação atômica por universo/dia. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Gsc_Acervo {
    public static function tabela(string $s='coletas'): string {global $wpdb;return $wpdb->prefix.'f3base_gsc_'.$s;}
    public static function pronta(): bool {
        global $wpdb;
        foreach(array('coletas'=>array('id','universo','revision','cursor','estado','publicado','recibos'),'linhas'=>array('coleta_id','chave','post_id','cliques','impressoes','posicao')) as $suffix=>$required){$t=self::tabela($suffix);if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){return false;}$cols=$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t));if($wpdb->last_error||array_diff($required,$cols)){return false;}}return true;
    }
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();$t=self::tabela();
        dbDelta("CREATE TABLE {$t} (
 id char(32) NOT NULL,
 universo char(64) NOT NULL,
 propriedade varchar(250) NOT NULL,
 revision varchar(128) NOT NULL DEFAULT '',
 dia date NOT NULL,
 origem varchar(24) NOT NULL,
 pesquisa varchar(16) NOT NULL DEFAULT 'web',
 escopo varchar(16) NOT NULL DEFAULT 'paginas',
 filtros text NOT NULL,
 estado varchar(32) NOT NULL,
 criado_em bigint unsigned NOT NULL,
 atualizado_em bigint unsigned NOT NULL,
 extraido_em bigint unsigned NOT NULL DEFAULT 0,
 publicado tinyint NOT NULL DEFAULT 0,
 `cursor` text NOT NULL,
 limite int unsigned NOT NULL DEFAULT 1000,
 paginas int unsigned NOT NULL DEFAULT 0,
 linhas int unsigned NOT NULL DEFAULT 0,
 cobertura longtext NOT NULL,
 recibos longtext NOT NULL,
 run_id varchar(100) NOT NULL DEFAULT '',
 connection_id varchar(100) NOT NULL DEFAULT '',
 codigo varchar(100) NOT NULL DEFAULT '',
 proxima_tentativa bigint unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (id),
 KEY universo_dia (universo,dia,publicado),
 KEY fila (estado,proxima_tentativa,criado_em),
 KEY historico (propriedade,dia,criado_em)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        $t=self::tabela('linhas');dbDelta("CREATE TABLE {$t} (
 coleta_id char(32) NOT NULL,
 chave char(64) NOT NULL,
 url text NOT NULL,
 post_id bigint unsigned NOT NULL DEFAULT 0,
 classe varchar(24) NOT NULL DEFAULT 'fora_do_site',
 cliques double NOT NULL,
 impressoes double NOT NULL,
 posicao double NOT NULL,
 PRIMARY KEY  (coleta_id,chave),
 KEY conteudo (post_id,coleta_id)
) ENGINE=InnoDB {$cc};");if($wpdb->last_error){return false;}
        return true; // A base suportada 1.20.0 já arquivou o legado; nenhuma releitura retroativa.
    }
    /** Guarda a projeção preexistente uma única vez; não inventa completude histórica. */
    private static function arquivar_1190(): bool {
        global $wpdb;$old=F3Base_Editorial::tabela('gsc_diario');$groups=$wpdb->get_results($wpdb->prepare('SELECT universo,propriedade,dia,pesquisa,escopo,filtros,MAX(extraido_em) extraido FROM %i GROUP BY universo,propriedade,dia,pesquisa,escopo,filtros',$old),ARRAY_A);if($wpdb->last_error){return false;}
        foreach($groups as $g){$id=substr(hash('sha256','arquivo119|'.$g['universo'].'|'.$g['dia']),0,32);if($wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE id=%s',self::tabela(),$id))){continue;}
            if(false===$wpdb->query('START TRANSACTION')){return false;}
            $ok=$wpdb->insert(self::tabela(),array('id'=>$id,'universo'=>$g['universo'],'propriedade'=>$g['propriedade'],'dia'=>$g['dia'],'origem'=>'legado_1190','pesquisa'=>$g['pesquisa'],'escopo'=>$g['escopo'],'filtros'=>$g['filtros'],'estado'=>'historico_sem_cobertura','criado_em'=>time(),'atualizado_em'=>time(),'extraido_em'=>$g['extraido'],'cursor'=>'','cobertura'=>'{"all_rows_guaranteed":false,"historico":true}','recibos'=>'[]'));
            $n=$ok?$wpdb->query($wpdb->prepare('INSERT INTO %i (coleta_id,chave,url,post_id,classe,cliques,impressoes,posicao) SELECT %s,SHA2(url,256),url,post_id,IF(post_id>0,\'conteudo\',\'nao_mapeado\'),cliques,impressoes,posicao FROM %i WHERE universo=%s AND dia=%s',self::tabela('linhas'),$id,$old,$g['universo'],$g['dia'])):false;
            if($n===false||false===$wpdb->update(self::tabela(),array('linhas'=>$n),array('id'=>$id))||false===$wpdb->query('COMMIT')){$wpdb->query('ROLLBACK');return false;}
        }return true;
    }
    public static function universo(string $p,string $type='web',string $scope='paginas',array $filters=array()): string {return hash('sha256',wp_json_encode(array($p,$type,$scope,F3Base_Auditoria::ordenar($filters))));}
    public static function criar(string $p,string $day,string $revision,int $limit,string $origem='automatico',string $type='web',string $scope='paginas',array $filters=array()): ?array {
        global $wpdb;$r=array('id'=>bin2hex(random_bytes(16)),'universo'=>self::universo($p,$type,$scope,$filters),'propriedade'=>$p,'revision'=>$revision,'dia'=>$day,'origem'=>$origem,'pesquisa'=>$type,'escopo'=>$scope,'filtros'=>wp_json_encode($filters),'estado'=>'em_curso','criado_em'=>time(),'atualizado_em'=>time(),'cursor'=>'','limite'=>$limit,'cobertura'=>'{}','recibos'=>'[]','paginas'=>0,'linhas'=>0,'extraido_em'=>0);
        return $wpdb->insert(self::tabela(),$r)?$r:null;
    }
    public static function ler(string $id): ?array {global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s',self::tabela(),$id),ARRAY_A);}
    public static function mapear(string $url): array {
        $home=wp_parse_url(home_url('/'));$u=wp_parse_url($url);$port=static fn($a)=>(int)($a['port']??(($a['scheme']??'')==='https'?443:80));
        if(!$u||strtolower($u['host']??'')!==strtolower($home['host'])||($u['scheme']??'')!==($home['scheme']??'')||$port($u)!==$port($home)||isset($u['user'])||isset($u['pass'])){return array('post_id'=>0,'classe'=>'fora_do_site');}
        $base=rtrim($home['path']??'/','/');$path=$u['path']??'/';if($base&&$path!==$base&&!str_starts_with($path,$base.'/')){return array('post_id'=>0,'classe'=>'fora_do_site');}
        $id=url_to_postid($url);if($id&&rtrim((string)get_permalink($id),'/')===rtrim($url,'/')){return array('post_id'=>$id,'classe'=>get_post_type($id)==='post'?'artigo':(get_post_type($id)==='page'?'pagina':'outro'));}return array('post_id'=>0,'classe'=>'nao_mapeado');
    }
    public static function falhar(array $c,string $code,int $next=0,bool $restart=false): array {
        global $wpdb;$data=array('estado'=>$restart?'reiniciar':'aguardando','codigo'=>substr(sanitize_key($code),0,100),'atualizado_em'=>time(),'proxima_tentativa'=>$next?:time()+300);if($restart){$data['cursor']='';}
        $ok=false!==$wpdb->update(self::tabela(),$data,array('id'=>$c['id']));if($ok){F3Base_Gsc_Lacunas::observar($c,$data['estado'],$code);}return array('ok'=>false,'persisted'=>$ok,'codigo'=>$code,'coleta'=>$c['id'],'proxima_tentativa'=>$data['proxima_tentativa']);
    }
    public static function receber(array $c,array $r): array {
        global $wpdb;
        if(empty($r['success'])||empty($r['audit_success'])){return self::falhar($c,(string)($r['error_code']??'servico_sem_confirmacao'));}
        $cov=$r['coverage']??array();$rows=$r['rows']??null;$next=$r['next_cursor']??null;
        if(($r['contract_version']??'')!=='1.0.0'||!is_array($rows)||count($rows)>(int)$c['limite']||($r['property']??'')!==$c['propriedade']||($r['date']??'')!==$c['dia']||($r['consumer_revision']??'')!==$c['revision']||($cov['calendar']??'')!=='America/Los_Angeles'||($cov['data_state']??'')!=='final'||($cov['aggregation']??'')!=='byPage'||($cov['type']??'')!=='web'||($cov['dimensions']??null)!==array('date','page')||!empty($cov['filters'])||!empty($cov['all_rows_guaranteed'])||!is_int($r['extracted_at']??null)||$r['extracted_at']>time()+300){return self::falhar($c,'envelope_invalido',time()+3600,true);}
        $pending=($cov['truncation_reason']??'')==='page_pending';$ceiling=($cov['truncation_reason']??'')==='api_daily_row_limit';$complete=!empty($cov['pagination_complete'])&&empty($cov['truncated']);
        if(($pending&&(!is_string($next)||$next===''||strlen($next)>4096))||($complete&&$next!==null)||($ceiling&&($next!==null||!empty($cov['pagination_complete'])))||(!$pending&&!$ceiling&&!$complete)){return self::falhar($c,'cobertura_incoerente',time()+3600,true);}
        $previous=json_decode($c['cobertura'],true)?:array();$expected=(int)($previous['start_row']??0)+(int)($previous['returned_rows']??0);
        if(($cov['start_row']??null)!==$expected||($cov['returned_rows']??null)!==count($rows)||($cov['limit']??null)!==(int)$c['limite']||($pending&&(!$rows||$next===$c['cursor']))||($ceiling&&$expected+count($rows)<50000)) {return self::falhar($c,'paginacao_sem_progresso',time()+3600,true);}
        if(false===$wpdb->query('START TRANSACTION')){return self::falhar($c,'transacao_falhou');}
        try{
            $cur=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s FOR UPDATE',self::tabela(),$c['id']),ARRAY_A);
            if(!$cur||$cur['cursor']!==$c['cursor']||!in_array($cur['estado'],array('em_curso','aguardando'),true)){throw new RuntimeException('coleta_mudou');}
            foreach($rows as $line){
                if(($line['date']??'')!==$c['dia']||!is_string($line['page']??null)||strlen($line['page'])>2000||!filter_var($line['page'],FILTER_VALIDATE_URL)||!in_array(wp_parse_url($line['page'],PHP_URL_SCHEME),array('http','https'),true)){throw new RuntimeException('linha_invalida');}
                foreach(array('clicks','impressions','position') as $n){if(!isset($line[$n])||!is_numeric($line[$n])||!is_finite((float)$line[$n])||$line[$n]<0){throw new RuntimeException('metrica_invalida');}}
                $hash=hash('sha256',$line['page']);$mapped=self::mapear($line['page']);$row=array('coleta_id'=>$c['id'],'chave'=>$hash,'url'=>$line['page'],'post_id'=>$mapped['post_id'],'classe'=>$mapped['classe'],'cliques'=>$line['clicks'],'impressoes'=>$line['impressions'],'posicao'=>$line['position']);
                $old=$wpdb->get_row($wpdb->prepare('SELECT cliques,impressoes,posicao FROM %i WHERE coleta_id=%s AND chave=%s',self::tabela('linhas'),$c['id'],$hash),ARRAY_A);
                if($old){foreach(array('cliques','impressoes','posicao') as $n){if((float)$old[$n]!== (float)$row[$n]){throw new RuntimeException('paginacao_inconsistente');}}}elseif(!$wpdb->insert(self::tabela('linhas'),$row)){throw new RuntimeException('linha_nao_persistida');}
            }
            $receipts=json_decode($cur['recibos'],true)?:array();$receipts[]=array('request_id'=>$r['request_id']??null,'run_id'=>$r['run_id']??null,'connection_id'=>$r['connection_id']??null,'extracted_at'=>$r['extracted_at'],'coverage'=>$cov,'remote_dispatched'=>$r['remote_dispatched']??null,'audit_success'=>true);
            $count=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE coleta_id=%s',self::tabela('linhas'),$c['id']));$data=array('estado'=>$complete?'concluida':($ceiling?'limitada':'em_curso'),'cursor'=>$next??'','atualizado_em'=>time(),'extraido_em'=>$r['extracted_at'],'paginas'=>(int)$cur['paginas']+1,'linhas'=>$count,'cobertura'=>wp_json_encode($cov),'recibos'=>wp_json_encode($receipts),'run_id'=>$r['run_id']??'','connection_id'=>$r['connection_id']??'','codigo'=>$ceiling?'api_daily_row_limit':'','proxima_tentativa'=>0);
            if(false===$wpdb->update(self::tabela(),$data,array('id'=>$c['id']))){throw new RuntimeException('checkpoint_nao_persistido');}
            if($complete){self::publicar_em_transacao(array_merge($c,$data));}
            if(false===$wpdb->query('COMMIT')){throw new RuntimeException('commit_falhou');}
            F3Base_Gsc_Lacunas::observar($c,$data['estado'],$complete?($count?'dia_publicado':'consulta_sem_linhas'):'paginacao_pendente');
            return array('ok'=>true,'persisted'=>true,'codigo'=>$complete?($count?'dia_publicado':'dia_sem_linhas'):($ceiling?'limite_diario_api':'pagina_persistida'),'coleta'=>$c['id'],'parcial'=>$pending,'linhas'=>$count,'pagination_complete'=>$complete,'all_rows_guaranteed'=>false);
        }catch(Throwable $x){$wpdb->query('ROLLBACK');return self::falhar($c,$x->getMessage(),time()+300,in_array($x->getMessage(),array('paginacao_inconsistente','linha_invalida','metrica_invalida'),true));}
    }
    private static function publicar_em_transacao(array $c): void {
        global $wpdb;$t=F3Base_Editorial::tabela('gsc_diario');$current=$wpdb->get_row($wpdb->prepare('SELECT extraido_em,origem FROM %i WHERE universo=%s AND dia=%s AND publicado=1 FOR UPDATE',self::tabela(),$c['universo'],$c['dia']),ARRAY_A);
        if($current&&(int)$current['extraido_em']>(int)$c['extraido_em']){return;}
        if(false===$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE universo=%s AND dia=%s',$t,$c['universo'],$c['dia']))){throw new RuntimeException('substituicao_falhou');}
        $sql=$wpdb->prepare('INSERT INTO %i (chave,universo,propriedade,dia,pesquisa,escopo,post_id,url,cliques,impressoes,posicao,estado,extraido_em,fonte,cobertura,filtros) SELECT SHA2(CONCAT(%s,\'|\',%s,\'|\',url),256),%s,%s,%s,%s,%s,post_id,url,cliques,impressoes,posicao,%s,%d,%s,%s,%s FROM %i WHERE coleta_id=%s',$t,$c['universo'],$c['dia'],$c['universo'],$c['propriedade'],$c['dia'],$c['pesquisa'],$c['escopo'],'final',$c['extraido_em'],'core:'.$c['origem'].':'.$c['id'],$c['cobertura'],$c['filtros'],self::tabela('linhas'),$c['id']);
        if(false===$wpdb->query($sql)||false===$wpdb->query($wpdb->prepare('UPDATE %i SET publicado=0 WHERE universo=%s AND dia=%s',self::tabela(),$c['universo'],$c['dia']))||false===$wpdb->update(self::tabela(),array('publicado'=>1),array('id'=>$c['id']))){throw new RuntimeException('publicacao_falhou');}
    }
    public static function manual(array $v): array {
        global $wpdb;$days=array();foreach($v['linhas'] as $line){$days[$line['dia']][]=$line;}$ids=array();
        foreach($days as $day=>$rows){$c=self::criar($v['propriedade'],$day,'manual',max(1,count($rows)),'manual',$v['pesquisa'],$v['escopo'],$v['filtros']);if(!$c){return array('ok'=>false,'codigo'=>'recibo_nao_persistido');}$id=$c['id'];$ids[]=$id;
            if(false===$wpdb->query('START TRANSACTION')){return array('ok'=>false,'codigo'=>'transacao_falhou');}try{
                foreach($rows as $row){$url=$row['url']??'';$mapped=$url?self::mapear($url):array('post_id'=>0,'classe'=>'propriedade');if(!$wpdb->insert(self::tabela('linhas'),array('coleta_id'=>$id,'chave'=>hash('sha256',$url),'url'=>$url,'post_id'=>$mapped['post_id'],'classe'=>$mapped['classe'],'cliques'=>$row['cliques'],'impressoes'=>$row['impressoes'],'posicao'=>$row['posicao']))){throw new RuntimeException('linha_nao_persistida');}}
                $complete=$v['estado']==='final'&&!empty($v['cobertura']['completa'])&&empty($v['cobertura']['truncada']);
                $data=array('estado'=>$complete?'concluida':'parcial_manual','extraido_em'=>$v['extraido_em'],'linhas'=>count($rows),'paginas'=>1,'cobertura'=>wp_json_encode($v['cobertura']+array('all_rows_guaranteed'=>false)),'recibos'=>wp_json_encode(array(array('fonte'=>$v['fonte'],'operador'=>get_current_user_id(),'em'=>time()))));
                if(false===$wpdb->update(self::tabela(),$data,array('id'=>$id))){throw new RuntimeException('recibo_nao_persistido');}if($complete){self::publicar_em_transacao(array_merge($c,$data));}
                if(false===$wpdb->query('COMMIT')){throw new RuntimeException('commit_falhou');}
            F3Base_Gsc_Lacunas::observar($c,$data['estado'],$complete?(count($rows)?'dia_publicado':'consulta_sem_linhas'):'parcial_manual');
            }catch(Throwable $x){$wpdb->query('ROLLBACK');self::falhar($c,$x->getMessage());return array('ok'=>false,'codigo'=>$x->getMessage(),'coletas'=>$ids);}
        }return array('ok'=>true,'persisted'=>true,'coletas'=>$ids,'modelo'=>'snapshot_por_universo_e_dia','limites'=>'Fotografias parciais ficam no histórico e não substituem a projeção publicada. Nenhuma garantia de todas as linhas do Google.');
    }
    public static function historico(array $e=array()): array {
        if(!current_user_can('manage_options')&&!(defined('WP_CLI')&&WP_CLI)){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;$p=max(1,min(100000,(int)($e['pagina']??1)));$where='1=1';
        foreach(array('propriedade','dia','id') as $key){if(!empty($e[$key])){$where.=$wpdb->prepare(' AND %i=%s',$key,$e[$key]);}}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY criado_em DESC,id DESC LIMIT 51 OFFSET %d",self::tabela(),($p-1)*50),ARRAY_A);$more=count($rows)>50;$rows=array_slice($rows,0,50);
        foreach($rows as &$r){$r['tem_cursor']=$r['cursor']!=='';unset($r['cursor']);foreach(array('cobertura','recibos','filtros') as $k){$r[$k]=json_decode($r[$k],true);}$r['extraido_formatado']=$r['extraido_em']?wp_date('d/m/Y H:i:s T',(int)$r['extraido_em']):null;}unset($r);
        $out=array('ok'=>!$wpdb->last_error,'linhas'=>$rows,'pagina'=>$p,'proxima_pagina'=>$more?$p+1:null);
        if(!empty($e['id'])){$lp=max(1,(int)($e['pagina_linhas']??1));$out['dados']=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE coleta_id=%s ORDER BY chave LIMIT 501 OFFSET %d',self::tabela('linhas'),$e['id'],($lp-1)*500),ARRAY_A);$out['proxima_pagina_linhas']=count($out['dados'])>500?$lp+1:null;$out['dados']=array_slice($out['dados'],0,500);}return $out;
    }
}
