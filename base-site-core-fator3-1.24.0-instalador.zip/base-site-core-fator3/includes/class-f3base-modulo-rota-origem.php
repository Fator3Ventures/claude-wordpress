<?php
/**
 * Módulo rota-origem.
 *
 * A rota de leitura de volta pela ORIGEM: o servidor pede a própria URL pública e
 * devolve status, cabeçalhos e corpo, carimbados com a fase `origem`.
 *
 * Restrição fechada: só caminho do próprio `home_url()`. O host é validado, o
 * redirecionamento não é seguido e destino livre é recusado pelo nome — rota que
 * aceita qualquer URL é SSRF com outro nome.
 *
 * A chamada é iniciada no servidor pela URL pública e pode passar por cache/CDN.
 * O identificador legado `origem` não comprova acesso direto à infraestrutura.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Leitura de volta pela origem.
 */
final class F3Base_Modulo_Rota_Origem extends F3Base_Modulo {

	/**
	 * Rota, dentro do namespace do plugin.
	 */
	public const ROTA = '/origem';

	/**
	 * Ação do nonce aceito pela rota.
	 */
	public const NONCE = 'f3base_origem';

	/**
	 * Fase carimbada em todo resultado.
	 */
	public const FASE = 'origem';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'rota-origem';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Rota de origem', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Requisita um caminho do próprio site a partir do servidor e devolve status, cabeçalhos e corpo carimbados com a fase origem. Aceita apenas caminho do próprio home_url, valida o host e não segue redirecionamento para fora.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => __( 'Loopback HTTP para o próprio host', 'f3base' ),
				'presente' => true,
				'detalhe'  => __( 'a requisição sai do servidor para o próprio home_url; ambiente que barre loopback devolve erro de transporte no corpo do resultado.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_ORIGEM, __( 'Última leitura pela origem', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		return $this->ativo(
			sprintf(
				/* translators: %s: host autorizado. */
				__( 'aceita apenas caminhos de %s, sem seguir redirecionamento, e identifica uma resposta HTTP pela URL pública, sujeita a cache/CDN.', 'f3base' ),
				$this->host_do_site()
			)
		);
	}

	/**
	 * Registra a rota REST.
	 *
	 * @return void
	 */
	public function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'ler' ),
				'permission_callback' => array( $this, 'pode_ler' ),
				'args'                => array(
					'caminho' => array(
						'type'        => 'string',
						'required'    => true,
						'description' => __( 'Caminho do próprio site, começando por barra.', 'f3base' ),
					),
					'metodo'  => array(
						'type'    => 'string',
						'enum'    => array( 'GET', 'HEAD' ),
						'default' => 'GET',
					),
					'corpo'   => array(
						'type'        => 'boolean',
						'required'    => false,
						'default'     => true,
						'description' => __( 'Incluir o corpo da resposta.', 'f3base' ),
					),
				),
			)
		);
	}

	/**
	 * Capability da rota.
	 *
	 * @return bool
	 */
	public function pode_ler(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Executa a leitura pela origem.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function ler( WP_REST_Request $requisicao ): WP_REST_Response {
		$autorizacao = $this->conferir_nonce( $requisicao );
		if ( true !== $autorizacao || ! $this->pode_ler() ) {
			return new WP_REST_Response(
				array(
					'fase'   => self::FASE,
					'ok'     => false,
					'codigo' => 'f3base_nonce_invalido',
					'motivo' => 'Permissão ou nonce inválido.',
				),
				403
			); }
		$metodo = (string) $requisicao->get_param( 'metodo' );
		$r      = F3Base_Publicacao_Sonda::verificar(
			array(
				'caminho' => (string) $requisicao->get_param( 'caminho' ),
				'metodo'  => ( '' !== $metodo ? $metodo : 'GET' ),
				'corpo'   => (bool) $requisicao->get_param( 'corpo' ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return new WP_REST_Response(
				array(
					'fase'   => self::FASE,
					'ok'     => false,
					'codigo' => $r->get_error_code(),
					'motivo' => $r->get_error_message(),
				),
				'f3base_sonda_intervalo' === $r->get_error_code() ? 429 : 400
			); }
		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMA_ORIGEM,
			array(
				'caminho' => $r['caminho'],
				'status'  => $r['status'],
				'bytes'   => $r['bytes_observados'],
			)
		);
		$r['fase']           = self::FASE; // Identificador legado preservado; não implica contornar CDN.
		$r['bytes']          = $r['bytes_observados'];
		$r['corpo_truncado'] = $r['truncado'] || ! empty( $r['retorno_truncado'] );
		$r['evidencia']      = 'http_url_publica';
		return new WP_REST_Response( $r, ! empty( $r['ok'] ) ? 200 : 502 );
	}

	/**
	 * Os cabeçalhos da resposta COMO ELES VIERAM.
	 *
	 * O defeito medido: a resposta passava por `array_map( 'strval', … )`, e
	 * cabeçalho REPETIDO — `Link`, `Set-Cookie`, `Vary` em emissores diferentes,
	 * `Cache-Control` de CDN — chega da camada HTTP como LISTA. `strval()` de um
	 * array devolve a string `"Array"` e emite um aviso do PHP: o instrumento de
	 * leitura pela origem, cujo papel inteiro é dizer o que o servidor emitiu,
	 * apagava justamente o cabeçalho emitido duas vezes — que é o caso que se vai
	 * ler quando se desconfia de emissor concorrente.
	 *
	 * A forma devolvida acompanha a forma recebida: escalar sai texto, repetido
	 * sai LISTA de textos. Achatar a lista numa string com vírgula seria uma
	 * terceira forma, que nem o servidor emitiu nem a camada HTTP entregou.
	 *
	 * @param mixed $cabecalhos Cabeçalhos como a camada HTTP os entregou.
	 * @return array<string,string|array<int,string>>
	 */
	public static function cabecalhos_legiveis( $cabecalhos ): array {
		$saida = array();

		foreach ( (array) $cabecalhos as $nome => $valor ) {
			if ( is_array( $valor ) ) {
				$saida[ (string) $nome ] = array_values( array_map( 'strval', $valor ) );
				continue;
			}

			$saida[ (string) $nome ] = is_scalar( $valor ) || null === $valor ? (string) $valor : '';
		}

		return $saida;
	}

	/**
	 * O PRIMEIRO valor de um cabeçalho que pode ter chegado repetido.
	 *
	 * `Location` repetido é resposta malformada, e é exatamente o que se quer
	 * enxergar; o campo de conveniência aponta para o primeiro, e a lista inteira
	 * continua em `cabecalhos`.
	 *
	 * @param mixed $valor Valor do cabeçalho.
	 * @return string
	 */
	public static function primeiro_valor( $valor ): string {
		if ( is_array( $valor ) ) {
			$primeiro = reset( $valor );

			return is_scalar( $primeiro ) ? (string) $primeiro : '';
		}

		return is_scalar( $valor ) ? (string) $valor : '';
	}

	/**
	 * Resolve o alvo dentro do próprio `home_url()`.
	 *
	 * @param string $entrada Caminho ou URL informada.
	 * @return array{ok:bool,url:string,caminho:string,motivo:string}
	 */
	public static function resolver_alvo( string $entrada ): array {
		$recusa = static function ( string $motivo ): array {
			return array(
				'ok'      => false,
				'url'     => '',
				'caminho' => '',
				'motivo'  => $motivo,
			);
		};

		$entrada = trim( $entrada );
		if ( str_contains( $entrada, '#' ) || str_contains( $entrada, '\\' ) ) {
			return $recusa( 'Fragmento ou barra invertida não permitido.' ); }
		if ( '' === $entrada ) {
			return $recusa( __( 'Caminho vazio.', 'f3base' ) );
		}

		if ( strlen( $entrada ) > 2000 ) {
			return $recusa( __( 'Caminho acima do limite aceito.', 'f3base' ) );
		}

		if ( str_contains( $entrada, "\n" ) || str_contains( $entrada, "\r" ) || str_contains( $entrada, "\0" ) ) {
			return $recusa( __( 'Caminho com controle de linha: recusado.', 'f3base' ) );
		}

		$casa = wp_parse_url( home_url( '/' ) );
		if ( ! is_array( $casa ) || ! isset( $casa['host'] ) ) {
			return $recusa( __( 'home_url do site não pôde ser interpretada.', 'f3base' ) );
		}

		$meu_host   = strtolower( (string) $casa['host'] );
		$meu_scheme = isset( $casa['scheme'] ) ? strtolower( (string) $casa['scheme'] ) : 'https';
		$minha_port = isset( $casa['port'] ) ? (int) $casa['port'] : 0;
		$meu_path   = isset( $casa['path'] ) ? rtrim( (string) $casa['path'], '/' ) : '';

		if ( str_starts_with( $entrada, '//' ) ) {
			return $recusa( __( 'URL sem esquema (protocol-relative) aponta para host externo: recusada.', 'f3base' ) );
		}

		$caminho  = $entrada;
		$consulta = '';

		if ( str_contains( $entrada, '://' ) ) {
			$partes = wp_parse_url( $entrada );

			if ( ! is_array( $partes ) || ! isset( $partes['host'] ) ) {
				return $recusa( __( 'URL absoluta ilegível.', 'f3base' ) );
			}

			if ( isset( $partes['user'] ) || isset( $partes['pass'] ) ) {
				return $recusa( __( 'URL com credencial embutida: recusada.', 'f3base' ) );
			}

			$scheme = isset( $partes['scheme'] ) ? strtolower( (string) $partes['scheme'] ) : '';
			if ( ! in_array( $scheme, array( 'http', 'https' ), true ) || $scheme !== $meu_scheme ) {
				return $recusa( __( 'Esquema fora de http/https: recusado.', 'f3base' ) );
			}

			if ( strtolower( (string) $partes['host'] ) !== $meu_host ) {
				return $recusa(
					sprintf(
						/* translators: 1: host pedido, 2: host do site. */
						__( 'Host %1$s não é o host do site (%2$s): destino recusado.', 'f3base' ),
						strtolower( (string) $partes['host'] ),
						$meu_host
					)
				);
			}

			$porta = isset( $partes['port'] ) ? (int) $partes['port'] : 0;
			if ( $porta !== $minha_port ) {
				return $recusa( __( 'Porta divergente da porta do site: destino recusado.', 'f3base' ) );
			}

			$caminho  = isset( $partes['path'] ) ? (string) $partes['path'] : '/';
			$consulta = isset( $partes['query'] ) ? (string) $partes['query'] : '';
		} else {
			$partes = wp_parse_url( $entrada );
			if ( ! is_array( $partes ) || isset( $partes['host'] ) ) {
				return $recusa( __( 'Caminho com host embutido: recusado.', 'f3base' ) );
			}

			$caminho  = isset( $partes['path'] ) ? (string) $partes['path'] : '/';
			$consulta = isset( $partes['query'] ) ? (string) $partes['query'] : '';
		}

		if ( str_contains( rawurldecode( $caminho ), '..' ) ) {
			return $recusa( __( 'Caminho com travessia de diretório: recusado.', 'f3base' ) );
		}

		$caminho = '/' . ltrim( $caminho, '/' );

		if ( '' !== $meu_path && ! str_starts_with( $caminho, $meu_path . '/' ) && $caminho !== $meu_path ) {
			$caminho = $meu_path . $caminho;
		}

		$url = $meu_scheme . '://' . $meu_host;
		if ( $minha_port > 0 ) {
			$url .= ':' . $minha_port;
		}
		$url .= $caminho;
		if ( '' !== $consulta ) {
			$url .= '?' . $consulta;
		}

		$conferencia = wp_parse_url( $url );
		if ( ! is_array( $conferencia ) || ! isset( $conferencia['host'] ) || strtolower( (string) $conferencia['host'] ) !== $meu_host ) {
			return $recusa( __( 'Conferência final do host falhou: destino recusado.', 'f3base' ) );
		}

		return array(
			'ok'      => true,
			'url'     => $url,
			'caminho' => $caminho . ( '' !== $consulta ? '?' . $consulta : '' ),
			'motivo'  => '',
		);
	}

	/**
	 * Confere o nonce, ou a credencial do canal quando a sessão não é por cookie.
	 *
	 * Requisição autenticada por cookie já chega aqui com o nonce do REST
	 * validado pelo core; a exigência explícita cobre o caminho do operador. A
	 * credencial do canal (Application Password) não tem nonce por natureza e é
	 * aceita como o próprio documento prevê.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return true|string Verdadeiro quando autorizada, ou o motivo da recusa.
	 */
	private function conferir_nonce( WP_REST_Request $requisicao ) {
		$nonce = (string) $requisicao->get_param( '_wpnonce' );

		if ( '' === $nonce ) {
			$cabecalho = $requisicao->get_header( 'x_wp_nonce' );
			$nonce     = is_string( $cabecalho ) ? $cabecalho : '';
		}

		if ( '' !== $nonce && ( wp_verify_nonce( $nonce, self::NONCE ) || wp_verify_nonce( $nonce, 'wp_rest' ) ) ) {
			return true;
		}

		$por_cookie = defined( 'LOGGED_IN_COOKIE' ) && isset( $_COOKIE[ LOGGED_IN_COOKIE ] );

		if ( ! $por_cookie ) {
			return true;
		}

		return __( 'Nonce ausente ou inválido para a rota de origem.', 'f3base' );
	}

	/**
	 * Host autorizado.
	 *
	 * @return string
	 */
	private function host_do_site(): string {
		$casa = wp_parse_url( home_url( '/' ) );

		return is_array( $casa ) && isset( $casa['host'] ) ? strtolower( (string) $casa['host'] ) : '';
	}
}
