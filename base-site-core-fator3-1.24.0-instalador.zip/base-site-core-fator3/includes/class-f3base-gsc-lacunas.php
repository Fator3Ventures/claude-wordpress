<?php
/** Inventário persistido por universo/dia; consultas não iniciam coleta. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Gsc_Lacunas {
    public static function tabela(): string {return F3Base_Gsc_Acervo::tabela('lacunas');}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();
        dbDelta("CREATE TABLE {$t} (
 universo char(64) NOT NULL,
 propriedade varchar(250) NOT NULL,
 dia date NOT NULL,
 estado varchar(24) NOT NULL DEFAULT 'pendente',
 primeira_observacao bigint unsigned NOT NULL,
 ultima_observacao bigint unsigned NOT NULL,
 motivo varchar(100) NOT NULL DEFAULT 'nao_coletado',
 coleta char(32) NOT NULL DEFAULT '',
 resolvida_em bigint unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (universo,dia),
 KEY estado_dia (universo,estado,dia)
 ) ENGINE=InnoDB {$wpdb->get_charset_collate()};");return !$wpdb->last_error;
    }
    private static function disponivel(): bool {global $wpdb;$t=self::tabela();return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;}
    public static function janela(): array {
        $end=(new DateTimeImmutable('today',new DateTimeZone('America/Los_Angeles')))->modify('-3 days');$inicio=F3Base_Options::ler('f3base_gsc')['inicio']??'';
        $start=$inicio&&F3Base_Gsc::data_valida($inicio)?new DateTimeImmutable($inicio,new DateTimeZone('America/Los_Angeles')):$end->modify('-29 days');
        return array($start,$end);
    }
    public static function inventariar(string $p): bool {
        if(!self::disponivel()){return false;}global $wpdb;[$start,$end]=self::janela();$u=F3Base_Gsc_Acervo::universo($p);
        $known=array_fill_keys($wpdb->get_col($wpdb->prepare('SELECT dia FROM %i WHERE universo=%s AND dia BETWEEN %s AND %s',self::tabela(),$u,$start->format('Y-m-d'),$end->format('Y-m-d'))),true);
        $tuples=array();$n=0;
        for($d=$start;$d<=$end&&$n<366;$d=$d->modify('+1 day')){if(isset($known[$d->format('Y-m-d')])){continue;}$tuples[]=$wpdb->prepare('(%s,%s,%s,%d,%d)',$u,$p,$d->format('Y-m-d'),time(),time());++$n;}
        if($tuples&&false===$wpdb->query($wpdb->prepare('INSERT INTO %i (universo,propriedade,dia,primeira_observacao,ultima_observacao) VALUES ',self::tabela()).implode(',',$tuples).' ON DUPLICATE KEY UPDATE universo=universo')){return false;}
        // Reconcile already completed snapshots without inventing coverage for archived partial data.
        $sql=$wpdb->prepare("UPDATE %i l JOIN %i c ON c.universo=l.universo AND c.dia=l.dia AND c.publicado=1 AND c.estado='concluida' SET l.estado='resolvida',l.motivo=IF(c.linhas=0,'consulta_sem_linhas','dia_publicado'),l.coleta=c.id,l.resolvida_em=c.atualizado_em,l.ultima_observacao=%d WHERE l.universo=%s AND l.estado<>'resolvida'",self::tabela(),F3Base_Gsc_Acervo::tabela(),time(),$u);
        return false!==$wpdb->query($sql);
    }
    public static function observar(array $c,string $estado,string $motivo): void {
        if(!self::disponivel()){return;}global $wpdb;$resolved=$estado==='concluida';$t=self::tabela();
        $wpdb->query($wpdb->prepare("INSERT INTO %i (universo,propriedade,dia,estado,primeira_observacao,ultima_observacao,motivo,coleta,resolvida_em) VALUES (%s,%s,%s,%s,%d,%d,%s,%s,%d) ON DUPLICATE KEY UPDATE ultima_observacao=VALUES(ultima_observacao),estado=IF(estado='resolvida' AND VALUES(estado)<>'resolvida',estado,VALUES(estado)),motivo=IF(resolvida_em>0 AND VALUES(resolvida_em)=0,motivo,VALUES(motivo)),coleta=IF(resolvida_em>0 AND VALUES(resolvida_em)=0,coleta,VALUES(coleta)),resolvida_em=GREATEST(resolvida_em,VALUES(resolvida_em))",$t,$c['universo'],$c['propriedade'],$c['dia'],$resolved?'resolvida':'pendente',time(),time(),substr($motivo,0,100),$c['id'],$resolved?time():0));
    }
    public static function resumo(?string $p=null): array {
        $p=$p??(string)F3Base_Options::ler('f3base_gsc_property');$r=array('propriedade'=>$p,'disponivel'=>false,'all_rows_guaranteed'=>false,'detalhe'=>array('ability'=>'f3base/gsc-lacunas-ler','entrada'=>array('propriedade'=>$p,'pagina'=>1)));
        if(!self::disponivel()){return $r;}global $wpdb;$u=F3Base_Gsc_Acervo::universo($p);[$start,$end]=self::janela();
        $rows=$wpdb->get_results($wpdb->prepare('SELECT estado,COUNT(*) n,MIN(dia) primeira,MAX(dia) ultima FROM %i WHERE universo=%s AND dia BETWEEN %s AND %s GROUP BY estado',self::tabela(),$u,$start->format('Y-m-d'),$end->format('Y-m-d')),ARRAY_A);
        $n=0;$r['estados']=array();foreach($rows as $row){$n+=(int)$row['n'];$r['estados'][$row['estado']]=array('dias'=>(int)$row['n'],'primeira'=>$row['primeira'],'ultima'=>$row['ultima']);}
        $expected=$start<=$end?(int)$start->diff($end)->days+1:0;
        return array_merge($r,array('disponivel'=>!$wpdb->last_error,'universo'=>$u,'inicio'=>$start->format('Y-m-d'),'fim'=>$end->format('Y-m-d'),'dias_a_inventariar'=>max(0,$expected-$n),'inventario_completo'=>$n===$expected,'consulta_sem_linhas'=>'Consulta concluída sem linhas não comprova zero visitas.'));
    }
    public static function listar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;
        $p=(string)($e['propriedade']??F3Base_Options::ler('f3base_gsc_property'));$page=max(1,min(100000,(int)($e['pagina']??1)));if(!self::disponivel()){return array('ok'=>false,'codigo'=>'inventario_indisponivel');}
        $where=$wpdb->prepare('universo=%s',F3Base_Gsc_Acervo::universo($p));if(isset($e['estado'])){if(!in_array($e['estado'],array('pendente','resolvida'),true)){return array('ok'=>false,'codigo'=>'estado_invalido');}$where.=$wpdb->prepare(' AND estado=%s',$e['estado']);}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY dia DESC LIMIT 101 OFFSET %d",self::tabela(),($page-1)*100),ARRAY_A);
        return array('ok'=>!$wpdb->last_error,'linhas'=>array_slice($rows,0,100),'proxima_pagina'=>count($rows)>100?$page+1:null,'resumo'=>self::resumo($p));
    }
}
