<?php
/** Inspeção limitada do JavaScript público do GTM. Nunca executa o contêiner. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Tracking_Diagnostico {
    const OPTION='f3base_gtm_evidencia';
    const EVENTO='f3base_gtm_verificar';
    public static function iniciar(): void {
        add_action('init',static function(){if(F3Base_Options::ler('f3base_gtm_container_id')&&!wp_next_scheduled(self::EVENTO)){wp_schedule_event(time()+60,'daily',self::EVENTO);}},25);
        add_action(self::EVENTO,array(__CLASS__,'coletar'));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('tracking-diagnostico','Slots configurados e última inspeção do GTM, sem HTTP',array(__CLASS__,'ler'));
            F3Base_Servicos::ability('tracking-verificar-gtm','Inspecionar uma cópia limitada do contêiner público, sem executar JavaScript',static function(){return current_user_can('manage_options')?self::coletar():array('ok'=>false,'codigo'=>'sem_permissao');},array(),array(),false);
        });
    }
    public static function ler(): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $r=F3Base_Options::ler(self::OPTION);$atual=self::contexto();
        return array('ok'=>true,'slots'=>F3Base_Modulo_Tracking::ids(),'regime'=>'aditivo','gtm'=>$r,'vigente'=>($r['contexto']??'')===$atual&&($r['em']??0)>time()-DAY_IN_SECONDS,'proxima_verificacao'=>wp_next_scheduled(self::EVENTO),'limite'=>'IDs literais são indícios de coincidência, sem provar carregamento, consentimento ou entrega. Ausência de literal não exclui tags dinâmicas. O Core preserva os slots diretos.');
    }
    private static function contexto(): string {return hash('sha256',wp_json_encode(F3Base_Modulo_Tracking::ids()));}
    public static function inspecionar(string $js,array $ids): array {
        $out=array();
        foreach($ids as $slot=>$id){
            if($id===''||in_array($slot,array('f3base_gtm_container_id','f3base_google_ads.conversion_label'),true)){continue;}
            // Literal com fronteiras; números comuns ainda não são prova de configuração.
            if(preg_match('/(?<![A-Za-z0-9_-])'.preg_quote($id,'/').'(?![A-Za-z0-9_-])/',$js)){$out[]=array('slot'=>$slot,'id'=>$id,'evidencia'=>'literal_coincidente','acao'=>'Conferir tags e gatilhos no GTM; nenhum slot foi suprimido.');}
        }
        return $out;
    }
    public static function coletar(): array {
        $id=F3Base_Options::ler('f3base_gtm_container_id');
        if(!is_string($id)||!preg_match('/^GTM-[A-Z0-9]{4,32}$/D',$id)){return array('ok'=>false,'codigo'=>'gtm_ausente_ou_invalido');}
        $ctx=self::contexto();$old=F3Base_Options::ler(self::OPTION);
        if(($old['contexto']??'')===$ctx&&($old['em']??0)>time()-HOUR_IN_SECONDS){return array('ok'=>true,'cache'=>true,'evidencia'=>$old);}
        $trava=F3Base_Trava::adquirir('gtm-diagnostico',30);if(!$trava){return array('ok'=>false,'codigo'=>'verificacao_em_execucao');}
        try {
            $res=wp_safe_remote_get('https://www.googletagmanager.com/gtm.js?id='.rawurlencode($id),array('timeout'=>8,'redirection'=>0,'limit_response_size'=>524289,'cookies'=>array()));
            $http=is_wp_error($res)?0:wp_remote_retrieve_response_code($res);$body=is_wp_error($res)?'':wp_remote_retrieve_body($res);
            $ok=$http===200&&strlen($body)<=524288&&$body!=='';
            $r=array('em'=>time(),'contexto'=>$ctx,'container'=>$id,'http'=>$http,'estado'=>$ok?'inspecionado':(strlen($body)>524288?'resposta_acima_do_limite':'indisponivel'),'bytes'=>strlen($body),'sha256'=>$ok?hash('sha256',$body):null,'coincidencias'=>$ok?self::inspecionar($body,F3Base_Modulo_Tracking::ids()):array());
            $saved=F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$r);
            return array('ok'=>$ok&&!empty($saved['persisted']),'evidencia'=>$r);
        } finally {F3Base_Trava::liberar($trava);}
    }
}
