<?php
/** Índice histórico, sem reescrever dados; somente indexação e expurgo compartilham a trava. A captura grava diretamente. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Leads_Consentimento {
    const OPTION='f3base_consentimento_indice';
    private static function chave(): string { global $wpdb; return 'f3core:cons:'.substr(hash('sha256',DB_NAME.$wpdb->prefix),0,40); }
    public static function travar(): bool { global $wpdb; return (string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,1)',self::chave()))==='1'; }
    public static function liberar(): void { global $wpdb; $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',self::chave())); }
    public static function referencia(array $dados): ?string {
        $p=$dados['consentimento_snapshot']??array(); if(!is_array($p)){return null;}
        $a=$p['decisao_ref']??''; $b=$p['ref']??'';
        if($a&&$b&&$a!==$b){return null;} $ref=$a?:$b;
        return is_string($ref)&&preg_match('/^[a-f0-9]{64}$/D',$ref)?$ref:null;
    }
    private static function tabela(): string { global $wpdb; return $wpdb->prefix.'f3base_consentimento_reparos'; }
    public static function instalar(): bool {
        global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $t=self::tabela();
        dbDelta("CREATE TABLE {$t} (
lead_id bigint unsigned NOT NULL,
tentativas tinyint unsigned NOT NULL DEFAULT 0,
codigo varchar(64) NOT NULL,
atualizado_em bigint NOT NULL,
PRIMARY KEY  (lead_id)
) {$wpdb->get_charset_collate()};");
        return !$wpdb->last_error&&$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
    }
    public static function pronto(): bool { $s=get_option(self::OPTION,array()); return !empty($s['concluido_em'])&&F3Base_Leads_Repositorio::pronto(); }
    public static function resumo(int $pagina=1): array {
        global $wpdb; $s=get_option(self::OPTION,array()); $s['problemas']=$wpdb->get_results($wpdb->prepare('SELECT lead_id,tentativas,codigo,atualizado_em FROM %i ORDER BY lead_id LIMIT 50 OFFSET %d',self::tabela(),max(0,$pagina-1)*50),ARRAY_A); return $s;
    }
    public static function lote(): array {
        global $wpdb; if(!self::travar()){return array('ok'=>true,'codigo'=>'consentimento_aguardando_trava','parcial'=>true);}
        try {
            $s=get_option(self::OPTION,array()); $cursor=(int)($s['cursor']??0); $t=F3Base_Leads_Repositorio::tabela(); $issues=self::tabela(); $start=microtime(true);
            if($wpdb->query($wpdb->prepare('DELETE p FROM %i p LEFT JOIN %i l ON l.id=p.lead_id WHERE l.id IS NULL',$issues,$t))===false||$wpdb->query($wpdb->prepare("UPDATE %i SET tentativas=0 WHERE codigo='conflito_de_revisao'",$issues))===false){return array('ok'=>false,'codigo'=>'indice_consentimento_reparos_falhou');}
            $rows=$wpdb->get_results($wpdb->prepare('SELECT id,dados,decisao_ref,captura FROM %i WHERE id>%d ORDER BY id LIMIT 100',$t,$cursor),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'indice_consentimento_leitura_falhou');}
            $retry=$wpdb->get_results($wpdb->prepare('SELECT l.id,l.dados,l.decisao_ref,l.captura FROM %i l JOIN %i p ON p.lead_id=l.id WHERE p.tentativas<3 ORDER BY l.id LIMIT 20',$t,$issues),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'indice_consentimento_pendencias_falhou');}
            $n=0; foreach(array_slice(array_merge($rows,$retry),0,100) as $r) {
                if(microtime(true)-$start>3){break;}
                $d=json_decode((string)$r['dados'],true); $p=is_array($d)?($d['consentimento_snapshot']??array()):array(); $ref=is_array($d)?self::referencia($d):null;
                $problem=is_array($p)&&!empty($p['decisao_ref'])&&!empty($p['ref'])&&$p['decisao_ref']!==$p['ref']?'referencias_conflitantes':'';
                if(!is_array($d)||($d!==array()&&array_is_list($d))){$problem='dados_historicos_nao_objeto';}
                if(!$problem&&is_array($p)&&(!empty($p['decisao_ref'])||!empty($p['ref']))&&!$ref){$problem='referencia_invalida';}
                if(!$problem&&$r['decisao_ref']!==$ref) {
                    $set=$ref===null?'NULL':$wpdb->prepare('%s',$ref);
                    $oldRef=$r['decisao_ref']===null?'NULL':$wpdb->prepare('%s',$r['decisao_ref']);
                    $changed=$wpdb->query($wpdb->prepare("UPDATE %i SET decisao_ref={$set} WHERE id=%d AND decisao_ref<=>{$oldRef} AND captura NOT IN ('eliminando','eliminado')",$t,$r['id']));
                    if($changed===false){return array('ok'=>false,'codigo'=>'indice_consentimento_gravacao_falhou');}
                    
                }
                if($problem){$ok=$wpdb->query($wpdb->prepare('INSERT INTO %i (lead_id,tentativas,codigo,atualizado_em) VALUES (%d,1,%s,%d) ON DUPLICATE KEY UPDATE tentativas=LEAST(3,tentativas+1),codigo=VALUES(codigo),atualizado_em=VALUES(atualizado_em)',$issues,$r['id'],$problem,time()));}
                else{$ok=$wpdb->delete($issues,array('lead_id'=>$r['id']));}
                if($ok===false){return array('ok'=>false,'codigo'=>'indice_consentimento_diagnostico_falhou');}
                $cursor=max($cursor,(int)$r['id']); $n++;
            }
            $remaining=$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE id>%d',$t,$cursor)); if($wpdb->last_error){return array('ok'=>false,'codigo'=>'indice_consentimento_contagem_falhou');}
            $pending=$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i',$issues)); if($wpdb->last_error){return array('ok'=>false,'codigo'=>'indice_consentimento_contagem_falhou');}
            $retryable=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE tentativas<3',$issues));if($wpdb->last_error){return array('ok'=>false,'codigo'=>'indice_consentimento_contagem_falhou');}
            $state=array('schema'=>2,'cursor'=>$cursor,'restantes'=>(int)$remaining,'pendencias'=>(int)$pending,'pendencias_abertas'=>$retryable,'em'=>time(),'concluido_em'=>!$remaining&&!$retryable?time():0);
            $save=F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$state);
            $retryable=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE tentativas<3',$issues));if($remaining||$retryable){if(!wp_next_scheduled('f3base_consentimento_indexar')){wp_schedule_single_event(time()+300,'f3base_consentimento_indexar');}}
            return array('ok'=>!empty($save['persisted']),'processados'=>$n,'restantes'=>(int)$remaining,'pendencias'=>(int)$pending,'parcial'=>(bool)($remaining||$retryable),'codigo'=>'indice_consentimento_atualizado');
        } finally {self::liberar();}
    }
    public static function iniciar(): void {add_action('f3base_consentimento_indexar',array(__CLASS__,'lote'));}
}
