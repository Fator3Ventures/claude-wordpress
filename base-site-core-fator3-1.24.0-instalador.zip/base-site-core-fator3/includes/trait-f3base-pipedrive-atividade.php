<?php
/** Etapa complementar: o núcleo confirmado permanece entregue. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Pipedrive_Atividade {
    private static function atividade(array &$j,array $ctx,array $cfg,array $rel,int $person,string $mark): array {
        if(empty($j['journal']['nucleo_confirmado_em'])){self::checkpoint($j,'nucleo_confirmado_em',time());}$status=$j['journal']['atividade_estado']??array();
        if(!empty($j['journal']['atividade'])&&($status['estado']??'')==='confirmada'){return array('ok'=>true);}
        try {
            $r=F3Base_Pipedrive_Api::listar('v2/activities',array('person_id'=>$person,'done'=>'false'));
            if(!empty($r['ok'])){
                $matches=array_values(array_filter($r['data'],static fn($x)=>str_contains((string)($x['note']??''),$mark.':atividade')));
                if(count($matches)>1){$r=array('ok'=>false,'incerto'=>true,'codigo'=>'atividades_ambiguas');}
                elseif($matches){self::checkpoint($j,'atividade',$matches[0]['id']);$r=array('ok'=>true,'data'=>$matches[0]);}
                elseif(!empty($j['journal']['atividade'])){$r=F3Base_Pipedrive_Api::pedir('GET','v2/activities/'.(int)$j['journal']['atividade']);}
                else{$r=self::criar($j,'atividade','v2/activities',array('subject'=>'Primeiro contato — '.($ctx['empresa']?:$ctx['nome']),'type'=>$cfg['atividade_tipo'],'owner_id'=>$cfg['responsavel'],'participants'=>array(array('person_id'=>$person,'primary'=>true)),'note'=>$mark.':atividade','due_date'=>wp_date('Y-m-d'))+$rel);}
                if(!empty($r['ok'])){
                    $r=F3Base_Pipedrive_Api::pedir('GET','v2/activities/'.(int)$j['journal']['atividade']);
                    if(!empty($r['ok'])){$p=$r['data']['participants']??array();$linked=in_array($person,array_map('intval',array_column($p,'person_id')),true)||(int)($r['data']['person_id']??0)===$person;
                        if(!$linked||($r['data']['lead_id']??null)!==($rel['lead_id']??null)){$r=array('ok'=>false,'incerto'=>true,'codigo'=>'atividade_vinculo_nao_confirmado');}
                    }
                }
            }
        }catch(Throwable $e){$r=array('ok'=>false,'incerto'=>true,'codigo'=>'atividade_checkpoint_pendente');}
        $n=(int)($status['tentativas']??0)+1;$state=!empty($r['ok'])?'confirmada':(!empty($r['incerto'])?'incerta':(!empty($r['permanente'])?'recusada':'pendente'));
        $journal=$j['journal'];$journal['nucleo_confirmado_em']=$journal['nucleo_confirmado_em']??time();
        $journal['atividade_estado']=array('estado'=>$state,'em'=>time(),'tentativas'=>$n,'proxima'=>time()+min(3600,60*(2**min(6,$n))),'codigo'=>$r['codigo']??'atividade_confirmada','diagnostico'=>array_intersect_key($r,array_flip(array('http','metodo','rota','campo','codigo_provedor','correlacao'))));
        if($state!=='confirmada'){$journal['qualidade']=array_values(array_unique(array_merge($journal['qualidade']??array(),array('atividade_'.$state))));}
        if(!self::salvar($j,array('journal'=>$journal))){return array('ok'=>false,'codigo'=>'atividade_estado_nao_persistido','incerto'=>true);}
        return array('ok'=>true,'codigo'=>$state==='confirmada'?'entregue':'entregue_atividade_'.$state);
    }
    public static function reparar_atividade(array $e): array {return self::coordenar((string)($e['chave']??''),static fn()=>self::reparar_atividade_interno($e));}
    private static function reparar_atividade_interno(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $j=self::ler((string)($e['chave']??''));if(!$j||!hash_equals(self::revisao($j),(string)($e['revisao']??''))){return array('ok'=>false,'codigo'=>'revisao_divergente');}
        if($j['lease']!==''||$j['estado']!=='entregue'||empty($j['journal']['nota'])||empty($j['journal']['pessoa'])||empty($j['journal']['oportunidade'])){return array('ok'=>false,'codigo'=>'nucleo_nao_confirmado');}
        if($e['simular']??true){return array('ok'=>true,'simulado'=>true,'persisted'=>false,'alteraria'=>true,'acao'=>'reconciliar_somente_atividade');}
        $x=$j['journal'];$x['atividade_estado']['tentativas']=0;$x['atividade_estado']['estado']='pendente';$x['atividade_estado']['proxima']=time();$ok=self::salvar($j,array('journal'=>$x));if($ok){F3Base_Fila::agendar(self::EVENTO);}
        return array('ok'=>$ok,'persisted'=>$ok,'codigo'=>'atividade_reconciliacao_solicitada');
    }
}
