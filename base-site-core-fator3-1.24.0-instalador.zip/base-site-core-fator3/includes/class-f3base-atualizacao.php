<?php
/** Migração identificada por versão, retomável e fora da leitura de diagnóstico. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Atualizacao {
	public const OPTION              = 'f3base_estrutura_estado';
	public const EVENTO              = 'f3base_migrar_estrutura';
	public const VERSAO              = '1.24.0';
	private static bool $desativando = false;

	public static function sanitizar_estado( $v, $padrao = array() ): array {
		unset( $padrao );
		$v = is_array( $v ) ? $v : array();
		return array(
			'versao'                 => substr( (string) ( $v['versao'] ?? '' ), 0, 32 ),
			'tentativa_em'           => max( 0, (int) ( $v['tentativa_em'] ?? 0 ) ),
			'confirmada_em'          => max( 0, (int) ( $v['confirmada_em'] ?? 0 ) ),
			'codigo'                 => substr( sanitize_key( (string) ( $v['codigo'] ?? '' ) ), 0, 64 ),
			'agendamento_confirmado' => ! empty( $v['agendamento_confirmado'] ),
			'agendamento_tentado_em' => max( 0, (int) ( $v['agendamento_tentado_em'] ?? 0 ) ),
			'proxima_execucao'       => max( 0, (int) ( $v['proxima_execucao'] ?? 0 ) ),
		);
	}

	/** Colunas usadas pelos consumidores desta migração, nunca somente a existência da tabela. */
	public static function estruturas(): array {
		return array(
			F3Base_Consentimento_Decisoes::TABELA        => array( 'ref', 'politica_versao', 'medicao', 'publicidade', 'revogada', 'expira_em' ),
			F3Base_Modulo_Endpoint_Leads::TABELA_RECUSAS => array( 'dia', 'motivo', 'total', 'primeiro', 'ultimo' ),
			F3Base_Capi_Fila::TABELA                     => array( 'record_id', 'payload', 'estado', 'tentativas', 'proxima', 'expira', 'atualizado', 'reserva', 'http', 'pixel_id', 'decisao_ref', 'politica_versao', 'iniciado', 'cancelado', 'lead_id', 'eliminar_lead', 'limpeza_pendente', 'motivo', 'agendamento_falhou', 'schema_versao', 'evento_hash', 'classe_trafego', 'evento_nome', 'evento_em', 'rota', 'prazo_regra' ),
		);
	}

	public static function verificar_estrutura(): bool {
		global $wpdb;
		$anterior = $wpdb->suppress_errors( true );
		try {
			foreach ( self::estruturas() as $sufixo => $necessarias ) {
				$tabela = $wpdb->prefix . $sufixo;
				if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $tabela ) ) ) !== $tabela ) {
					return false; }
				$colunas = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $tabela ) );
				if ( '' !== $wpdb->last_error || ! is_array( $colunas ) || array_diff( $necessarias, $colunas ) ) {
					return false; }
			}
			$pendentes = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE schema_versao<%d', F3Base_Capi_Fila::tabela(), F3Base_Capi_Fila::SCHEMA ) );
			return null !== $pendentes && '' === $wpdb->last_error && 0 === (int) $pendentes;
		} finally {
			$wpdb->suppress_errors( $anterior ); }
	}

	public static function pronta(): bool {
		return self::VERSAO === ( F3Base_Options::ler( self::OPTION )['versao'] ?? '' ) && !empty(get_option(F3Base_Instalacao::OPTION,array())['concluido_em']);
	}

	public static function agendar(): array {
		if ( self::$desativando || !empty(F3Base_Recuperacao::ler()['pausado']) ) {
			return array(
				'ok'     => false,
				'codigo' => 'plugin_desativando',
			); }
		if ( self::pronta() ) {
			return array(
				'ok'     => true,
				'codigo' => 'estrutura_confirmada',
			); }
		$s=get_option(F3Base_Instalacao::OPTION,array());return self::agendar_para(max(time()+5,(int)($s['proxima_tentativa']??0)));
	}

	private static function agendar_para( int $quando ): array {
		$existente = wp_next_scheduled( self::EVENTO );
        if($existente!==false){return array('ok'=>true,'codigo'=>'migracao_agendada','reagendado'=>false,'proxima_execucao'=>$existente);}
		$ok        = (bool) $existente || true === wp_schedule_single_event( $quando, self::EVENTO );
		$proxima   = $existente ? $existente : ( $ok ? $quando : 0 );
		$r         = F3Base_Options::atualizar_estado(
			self::OPTION,
			static function ( $v ) use ( $ok, $proxima ) {
				$v                           = is_array( $v ) ? $v : array();
				$v['agendamento_confirmado'] = $ok;
				$v['agendamento_tentado_em'] = time();
				$v['proxima_execucao']       = $proxima;
				$v['codigo']                 = $ok ? 'migracao_agendada' : 'agendamento_recusado';
				return $v;
			}
		);
		return array(
			'ok'         => $ok && ! empty( $r['persisted'] ),
			'reagendado' => $ok,
			'persisted'  => ! empty( $r['persisted'] ),
			'codigo'     => $ok ? ( ! empty( $r['persisted'] ) ? 'migracao_agendada' : 'agendamento_sem_confirmacao_local' ) : 'agendamento_recusado',
		);
	}

	/** Cada instalação pode ser repetida; a versão só confirma schema e gravação verificados. */
	public static function migrar(): array {
        return F3Base_Instalacao::atualizar();
	}

	public static function desativar(): void {
		self::$desativando = true;
		wp_clear_scheduled_hook( self::EVENTO ); }
}
