<?php
/** Inspeção administrativa do HTML publicado; evidência separada da operação. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Schema_Verificacao {
	public const EVENTO = 'f3base_schema_verificar';
	public const ESTADO = 'f3base_schema_evidencia';
	public static function iniciar(): void {
		add_action( self::EVENTO, array( __CLASS__, 'cron' ) );
		add_action( 'wp', array( __CLASS__, 'agendar' ), 30 );
	}
	public static function agendar(): void {
		if ( F3Base_Llms::plugin_de_seo_ativo() && ! wp_next_scheduled( self::EVENTO ) ) {
			$e      = (array) F3Base_Options::fotografia( self::ESTADO )['valor'];
			$quando = ! empty( $e['trabalho'] ) ? max( time() + 10, (int) ( $e['trabalho']['lease'] ?? 0 ) + 1 ) : time() + DAY_IN_SECONDS;
			wp_schedule_single_event( $quando, self::EVENTO ); } }
	public static function contexto(): string {
		return hash( 'sha256', (string) wp_json_encode( array( F3Base_Options::revisao( 'f3base_seo_entidade' ), F3BASE_PLUGIN_VERSAO, home_url(), get_option( 'wpseo' ), get_option( 'wpseo_titles' ), get_option( 'wpseo_social' ), get_option( 'active_plugins' ), get_stylesheet(), get_theme_mods(), get_lastpostmodified( 'gmt' ), get_transient( F3Base_Modulo_Cache_Publico::GERACAO ) ) ) );
	}
	public static function consultar(): array {
		$e = (array) F3Base_Options::fotografia( self::ESTADO )['valor'];
		if ( ! $e ) {
			return array(
				'status'       => 'pendente',
				'codigo'       => 'sem_evidencia',
				'configuracao' => F3Base_Servicos::schema_origens(),
			); }
		if ( ( $e['contexto'] ?? '' ) !== self::contexto() || (int) ( $e['em'] ?? 0 ) < time() - DAY_IN_SECONDS ) {
			$e['status'] = 'desatualizado'; }
		unset( $e['trabalho'] );
		$e['configuracao'] = F3Base_Servicos::schema_origens();
        $e['ofertas']=F3Base_Ofertas::consultar();
		return $e;
	}
	public static function verificacao_configuracao(): array {
		$e      = self::consultar();
		$status = 'verified' === ( $e['status'] ?? '' ) ? 'verified' : ( 'degradado' === ( $e['status'] ?? '' ) ? 'failed' : 'pending' );
		return array(
			'status'     => $status,
			'scope'      => 'schema_public_http',
			'codigo'     => 'schema_' . ( $e['status'] ?? 'pendente' ),
			'motivo'     => 'Consulte f3base/schema-verificar para cobertura, avisos e detalhes por URL.',
			'checked_at' => $e['em'] ?? 0,
		);
	}
	public static function paginas(): array {
		$r     = array( home_url( '/' ) );
		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'has_password'   => false,
				'posts_per_page' => 1,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		if ( $posts ) {
			$r[] = get_permalink( $posts[0] );
		} return array_values( array_unique( $r ) );
	}
	/** Achados locais: parses completos, limites explícitos; não resolve contextos remotos. */
	public static function analisar( string $html ): array {
		$avisos                = array();
		$nos                   = array();
		$blocos                = 0;
		$malformados           = 0;
		$limite                = false;
		$contexto_desconhecido = false;
		$doc                   = new DOMDocument();
		$prev                  = libxml_use_internal_errors( true );
		try {
			$doc->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING ); } finally {
			libxml_clear_errors();
			libxml_use_internal_errors( $prev ); }
			$coletar = static function ( $obj, int $nivel = 0 ) use ( &$coletar, &$nos, &$limite, &$contexto_desconhecido ): void {
				if ( ! is_array( $obj ) ) {
					return; }
				if ( $nivel > 64 || count( $nos ) >= 10000 ) {
					$limite = true;
					return; }
				if ( isset( $obj['@context'] ) && ! in_array( $obj['@context'], array( 'https://schema.org', 'https://schema.org/', 'http://schema.org', 'http://schema.org/' ), true ) ) {
					$contexto_desconhecido = true; }
				if ( isset( $obj['@type'] ) ) {
					$nos[] = $obj; }
				foreach ( $obj as $k => $v ) {
					if ( '@context' !== $k && is_array( $v ) ) {
								$coletar( $v, $nivel + 1 ); }
				}
			};
		foreach ( $doc->getElementsByTagName( 'script' ) as $script ) {
			if ( 'application/ld+json' !== strtolower( trim( explode( ';', $script->getAttribute( 'type' ) )[0] ) ) ) {
				continue; }
			++$blocos;
			try {
				$obj = json_decode( $script->textContent, true, 128, JSON_THROW_ON_ERROR ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedade nativa da API DOM.
				if ( ! is_array( $obj ) ) {
					++$malformados;
				} else {
					$coletar( $obj ); }
			} catch ( JsonException $e ) {
				++$malformados; }
		}
		if ( $contexto_desconhecido ) {
			$avisos[] = array(
				'categoria' => 'inconclusivo',
				'codigo'    => 'contexto_json_ld_nao_suportado',
			); }
		if ( $malformados ) {
			$avisos[] = array(
				'categoria' => 'erro',
				'codigo'    => 'json_ld_invalido',
			); }
		if ( $limite ) {
			$avisos[] = array(
				'categoria' => 'inconclusivo',
				'codigo'    => 'limite_estrutura',
			); }
		if ( $blocos > 1 ) {
			$avisos[] = array(
				'categoria' => 'politica_frota',
				'codigo'    => 'multiplos_blocos',
				'motivo'    => 'Revisar emissores. Vários blocos não invalidam JSON-LD por si só.',
			); }
		$ids          = array();
		$organizacoes = array();$pessoas=array();
		$recursos     = array();$origens_recursos=array();
		foreach ( $nos as $no ) {
			$no['@type'] = (array) $no['@type'];
			sort( $no['@type'] );
			$id = is_string( $no['@id'] ?? null ) ? $no['@id'] : '';
			if ( $id && isset( $ids[ $id ] ) && array_diff_assoc( array_map( 'wp_json_encode', array_intersect_key( $ids[ $id ], $no ) ), array_map( 'wp_json_encode', array_intersect_key( $no, $ids[ $id ] ) ) ) ) {
				$avisos[] = array(
					'categoria' => 'erro',
					'codigo'    => 'identidade_repetida',
					'id'        => $id,
				); }
			if ( $id ) {
				$ids[ $id ] = isset( $ids[ $id ] ) ? array_replace( $no, $ids[ $id ] ) : $no; }
			if ( in_array( 'Organization', (array) ( $no['@type'] ?? array() ), true ) ) {
				$organizacoes[ $id ? $id : 'anonimo-' . count( $organizacoes ) ] = $no; }
		}
		foreach($nos as $no){if(in_array('Person',(array)($no['@type']??array()),true)){$pessoas[$no['@id']??('pessoa-'.count($pessoas))]=$no;}}
		$yoast = get_option( 'wpseo_titles', array() );
		if ( 'company' === ( $yoast['company_or_person'] ?? '' ) && ! $organizacoes ) {
			$avisos[] = array(
				'categoria' => 'erro',
				'codigo'    => 'organization_ausente',
			); }
		foreach ( $organizacoes + $pessoas as $id => $org ) {
            $is_person=in_array('Person',(array)$org['@type'],true);
			$org = $ids[ $id ] ?? $org;
			foreach ( (array) ( $org['sameAs'] ?? array() ) as $url ) {
				if ( is_string( $url ) ) {
					$recursos[ $url ] = 'sameAs';$core=(array)(F3Base_Options::ler('f3base_seo_entidade')['same_as']??array());if($is_person){$core=array();foreach(F3Base_Options::ler('f3base_seo_entidade')['pessoas']??array() as $person){$core=array_merge($core,$person['same_as']??array());}}$ys=(array)get_option('wpseo_social',array());$origens=array();if(in_array($url,$core,true)){$origens[]='configuracao_core';}foreach($ys as $yv){if($yv===$url||(is_array($yv)&&in_array($url,$yv,true))){$origens[]='configuracao_yoast';break;}}$origens_recursos[$url][]=array('id'=>$id,'tipo'=>$is_person?'Person':'Organization','propriedade'=>'sameAs','origem_configurada'=>$origens?:array('nao_identificada'),'origem_observada'=>'grafo_html'); }
			}
            if($is_person){continue;}
			$logo = $org['logo'] ?? null;
			if ( is_array( $logo ) && isset( $logo['@id'] ) ) {
				$logo = $ids[ $logo['@id'] ] ?? $logo; }
			$url = is_string( $logo ) ? $logo : ( is_array( $logo ) ? ( $logo['contentUrl'] ?? $logo['url'] ?? '' ) : '' );
			if ( is_string( $url ) && $url ) {
				$recursos[ $url ] = 'logo';
			} elseif ( wp_parse_url( $org['url'] ?? '', PHP_URL_HOST ) === wp_parse_url( home_url(), PHP_URL_HOST ) ) {
				$avisos[] = array(
					'categoria' => 'revisar',
					'codigo'    => 'logo_nao_resolvido',
				); }
			foreach ( F3Base_Seo_Entidade::propriedades( F3Base_Options::ler( 'f3base_seo_entidade' ), (string) ( $org['@id'] ?? '' ) ) as $k => $valor ) {
				if ( isset( $org[ $k ] ) && $org[ $k ] !== $valor ) {
					$avisos[] = array(
						'categoria'   => 'revisar',
						'codigo'      => 'propriedade_preservada',
						'propriedade' => $k,
					); }
			}
		}
		foreach ( $nos as $no ) {
			if ( ! array_intersect( (array) ( $no['@type'] ?? array() ), array( 'Article', 'BlogPosting', 'NewsArticle' ) ) ) {
				continue; }
			$autores = $no['author'] ?? array();
			$autores = is_array( $autores ) && array_is_list( $autores ) ? $autores : array( $autores );
			foreach ( $autores as $autor ) {
				if ( is_array( $autor ) && isset( $autor['@id'] ) ) {
					$ref = $autor['@id'];
					if ( ! isset( $ids[ $ref ] ) && wp_parse_url( $ref, PHP_URL_HOST ) === wp_parse_url( home_url(), PHP_URL_HOST ) ) {
						$avisos[] = array(
							'categoria' => 'erro',
							'codigo'    => 'autor_referencia_orfa',
							'id'        => $ref,
						);
					} elseif ( ! isset( $ids[ $ref ] ) && F3Base_Seo_Entidade::https( $ref ) ) {
						continue; }
					$autor = $ids[ $ref ] ?? $autor; }
				if ( is_array( $autor ) && empty( $autor['name'] ) ) {
					$avisos[] = array(
						'categoria' => 'revisar',
						'codigo'    => 'autor_sem_nome',
					); }
				if ( ! is_array( $autor ) || ( empty( $autor['url'] ) && empty( $autor['sameAs'] ) ) ) {
					$avisos[] = array(
						'categoria' => 'revisar',
						'codigo'    => 'autor_sem_identificacao',
					); }
			}
		}
		if ( $blocos && ! $nos ) {
			$avisos[] = array(
				'categoria' => 'inconclusivo',
				'codigo'    => 'schema_sem_tipos_reconhecidos',
			); }
		$config = F3Base_Options::ler( 'f3base_seo_entidade' );
		foreach ( self::avisos_configuracao( $config ) as $aviso ) {
			$avisos[] = $aviso; }
		if ( ! $blocos ) {
			$avisos[] = array(
				'categoria' => 'erro',
				'codigo'    => 'schema_ausente',
			); }
		return array(
			'blocos'   => $blocos,
			'nos'      => count( $nos ),
			'avisos'   => $avisos,
			'recursos' => $recursos,
            'origens_recursos'=>$origens_recursos,
		);
	}
	public static function avisos_configuracao( array $v ): array {
		$a = array();
		if ( ! empty( $v['cnpj'] ) && empty( $v['endereco'] ) ) {
			$a[] = array(
				'categoria' => 'revisar',
				'codigo'    => 'cnpj_sem_endereco',
			); }
		if ( ! empty( $v['endereco'] ) && 'BR' === ( $v['endereco']['pais'] ?? 'BR' ) && empty( $v['endereco']['cep'] ) ) {
			$a[] = array(
				'categoria' => 'revisar',
				'codigo'    => 'endereco_sem_cep',
			); }
		if ( ! empty( $v['organizacao_mae'] ) && is_string( $v['organizacao_mae'] ) ) {
			$a[] = array(
				'categoria' => 'revisar',
				'codigo'    => 'controladora_sem_url',
			); }
		$relacoes = (array) ( $v['organizacoes_filhas'] ?? array() );
		if ( is_array( $v['organizacao_mae'] ?? null ) ) {
			$relacoes[] = $v['organizacao_mae']; }
		foreach ( $relacoes as $r ) {
			if ( empty( $r['id'] ) ) {
				$a[] = array(
					'categoria' => 'revisar',
					'codigo'    => 'relacao_id_a_confirmar',
					'url'       => $r['url'] ?? '',
				); }
			if ( wp_parse_url( $r['url'] ?? '', PHP_URL_HOST ) === wp_parse_url( home_url(), PHP_URL_HOST ) ) {
				$a[] = array(
					'categoria' => 'revisar',
					'codigo'    => 'relacao_mesmo_host',
				); }
		}
		return $a;
	}
	public static function verificar( array $paginas, string $revisao, bool $teste=false ): array {
		if ( ! hash_equals( F3Base_Options::revisao( 'f3base_seo_entidade' ), $revisao ) ) {
			return array(
				'codigo' => 'revisao_divergente',
				'status' => 'pendente',
			); }
		if ( ! $paginas || count( $paginas ) > 5 ) {
			return array(
				'codigo' => 'limite_paginas',
				'status' => 'pendente',
			); }
		$home = wp_parse_url( home_url() );
		foreach ( $paginas as $url ) {
			$p = is_string( $url ) ? wp_parse_url( $url ) : array();
			if ( ( $p['host'] ?? '' ) !== $home['host'] || ( $p['scheme'] ?? '' ) !== $home['scheme'] || isset( $p['user'] ) || isset( $p['pass'] ) || ( $p['port'] ?? null ) !== ( $home['port'] ?? null ) ) {
				return array(
					'codigo' => 'pagina_fora_do_site',
					'status' => 'pendente',
				); }
		}
		$contexto = self::contexto();
		$id       = wp_generate_uuid4();
		$e        = array(
			'classe_trafego' => $teste?'teste':'nao_marcado',
            'status'   => 'pendente',
			'em'       => time(),
			'contexto' => $contexto,
			'paginas'  => array(),
			'escopo'   => 'HTML e recursos observados; HTTP 200 não comprova identidade; sem aprovação de rich results pelo Google.',
			'trabalho' => array(
				'contexto_teste' => $teste,
                'id'       => $id,
				'inicio'   => time(),
				'paginas'  => array_values( array_unique( $paginas ) ),
				'recursos' => array(),
				'vistos'   => array(),
				'lease'    => 0,
			),
		);
		$r        = F3Base_Options::atualizar_estado( self::ESTADO, static fn( $anterior ) => (int) ( $anterior['trabalho']['lease'] ?? 0 ) > time() ? null : $e );
		if ( empty( $r['persisted'] ) ) {
			return array(
				'status' => 'pendente',
				'codigo' => 'verificacao_ocupada_ou_nao_persistida',
			); }
		return self::continuar( $id );
	}
	/** Cada lote tem 20 segundos e até vinte recursos; cron retoma sem guardar HTML. */
	public static function continuar( string $id ): array {
		$token = wp_generate_uuid4();
		$r     = F3Base_Options::atualizar_estado(
			self::ESTADO,
			static function ( $e ) use ( $id, $token ) {
				if ( ( $e['trabalho']['id'] ?? '' ) !== $id || (int) ( $e['trabalho']['lease'] ?? 0 ) > time() ) {
					return null; }
				$e['trabalho']['lease']   = time() + 60;
				$e['trabalho']['reserva'] = $token;
				return $e;
			}
		);
		if ( empty( $r['persisted'] ) ) {
			return self::consultar(); }
		$e = (array) F3Base_Options::fotografia( self::ESTADO )['valor'];
		if ( ( $e['trabalho']['reserva'] ?? '' ) !== $token ) {
			return self::consultar(); }
		$w      = $e['trabalho'];
		$fim    = microtime( true ) + 20;
		$valido = hash_equals( $e['contexto'], self::contexto() ) && (int) $w['inicio'] > time() - HOUR_IN_SECONDS;
		while ( $valido && $w['paginas'] && microtime( true ) < $fim ) {
			$url           = array_shift( $w['paginas'] );
			$h             = F3Base_Http_Publico::buscar( $url, 2097152, $fim, 'GET', F3Base_Testes::cabecalhos($url,!empty($w['contexto_teste'])) );
			$pagina        = empty( $h['ok'] ) ? array(
				'avisos' => array(
					array(
						'categoria' => in_array( $h['status'], array( 404, 410 ), true ) ? 'erro' : 'inconclusivo',
						'codigo'    => $h['codigo'],
					),
				),
			) : self::analisar( $h['corpo'] );
			$pagina['url'] = $url;
            if(!empty($h['ok'])){$pagina['ofertas']=F3Base_Ofertas::observar($h['corpo'],$url);}
			$indice        = count( $e['paginas'] );
			foreach ( $pagina['recursos'] ?? array() as $recurso => $tipo ) {
				if ( count( $w['recursos'] ) >= 100 && ! isset( $w['recursos'][ $recurso ] ) ) {
					$pagina['avisos'][] = array(
						'categoria' => 'inconclusivo',
						'codigo'    => 'limite_total_recursos',
					);
					continue; }
				if ( ! isset( $w['recursos'][ $recurso ] ) ) {
					$w['recursos'][ $recurso ] = array(
						'tipo'    => $tipo,
						'paginas' => array(),
                        'origens'=>array(),
					); }
				if ( 'logo' === $tipo ) {
					$w['recursos'][ $recurso ]['tipo'] = 'logo'; }
				$w['recursos'][ $recurso ]['paginas'][] = $indice;foreach($pagina['origens_recursos'][$recurso]??array() as $origem){$origem['pagina']=$url;$w['recursos'][$recurso]['origens'][]=$origem;}
			}
			unset( $pagina['recursos'],$pagina['origens_recursos'] );
			$e['paginas'][] = $pagina;
		}
		$n = 0;
		if ( ! $w['paginas'] ) {
			foreach ( $w['recursos'] as $url => $recurso ) {
				if ( isset( $w['vistos'][ $url ] ) ) {
					continue; }
				if ( ! $valido || ++$n > 20 || microtime( true ) >= $fim ) {
					break; }
				$h      = F3Base_Http_Publico::buscar( $url, 2097152, $fim, 'GET', F3Base_Testes::cabecalhos($url,!empty($w['contexto_teste'])) );
				$avisos = self::recurso( $url, $recurso['tipo'], $h );foreach($avisos as &$aviso){$aviso['origens']=$recurso['origens']??array();}unset($aviso);
				foreach ( $recurso['paginas'] as $indice ) {
					$e['paginas'][ $indice ]['avisos'] = array_merge( $e['paginas'][ $indice ]['avisos'], $avisos ); }
				$w['vistos'][ $url ] = true;
			}
		}
		$valido                  = $valido && hash_equals( $e['contexto'], self::contexto() );
		$pendente                = $valido && ( $w['paginas'] || count( $w['vistos'] ) < count( $w['recursos'] ) );
		$e['em']                 = time();
		$e['status']             = ! $valido ? 'desatualizado' : ( $pendente ? 'pendente' : 'verified' );
		$e['cobertura_completa'] = $valido && ! $pendente;
		foreach ( $e['paginas'] as $pagina ) {
			foreach ( $pagina['avisos'] as $aviso ) {
				if ( 'inconclusivo' === $aviso['categoria'] ) {
					$e['cobertura_completa'] = false; }
				if ( 'erro' === $aviso['categoria'] ) {
					$e['status'] = 'degradado'; } elseif ( 'inconclusivo' === $aviso['categoria'] && 'verified' === $e['status'] ) {
					$e['status'] = 'inconclusivo'; }
			}
		}
		unset( $e['trabalho'] );
		if ( $pendente ) {
			$w['lease']    = 0;
			$e['trabalho'] = $w;
		}
		$r = F3Base_Options::atualizar_estado( self::ESTADO, static fn( $atual ) => ( $atual['trabalho']['id'] ?? '' ) === $id && ( $atual['trabalho']['reserva'] ?? '' ) === $token ? $e : null );
		if ( $pendente && ! empty( $r['persisted'] ) ) {
			wp_clear_scheduled_hook( self::EVENTO );
			wp_schedule_single_event( time() + 10, self::EVENTO ); }
		unset( $e['trabalho'] );
		$e['evidencia_persistida'] = ! empty( $r['persisted'] );
		return $e;
	}
	private static function recurso( string $url, string $tipo, array $h ): array {
		$a = array(
			array(
				'categoria' => 'informativo',
				'codigo'    => 'recurso_http_observado',
				'url'       => $url,
				'http'      => $h['status']??0,
                'http_inicial'=>$h['cadeia'][0]['status']??($h['status']??0),
                'http_final'=>$h['status']??0,'url_final'=>$h['url_final']??$url,'em'=>time(),
				'cadeia'    => $h['cadeia'] ?? array(),
			),
		);
        if (empty($h['ok'])) {
            $a[]=array('categoria'=>in_array($h['status'],array(404,410),true)?'erro':'inconclusivo','codigo'=>'recurso_'.$h['codigo'],'url'=>$url,'http'=>$h['status']);return $a;
        }
        if('sameAs'===$tipo&&preg_match('~(?:<title[^>]*>[^<]*(?:captcha|just a moment|access denied|sign in|log in)|(?:id|class)=["\'][^"\']*(?:captcha|cf-challenge))~i',$h['corpo']??'')){$a[]=array('categoria'=>'inconclusivo','codigo'=>'recurso_desafio_ou_autenticacao','url'=>$url);}
		if ( $h['redirecionou'] ) {
			$a[] = array(
				'categoria' => 'sameAs'===$tipo?'erro':'revisar',
				'codigo'    => 'recurso_redirecionado',
				'url'       => $url,
				'url_final' => $h['url_final'],
			); }
		if ( 'logo' === $tipo ) {
			$dim = @getimagesizefromstring( $h['corpo'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Imagem remota inválida gera evidência inconclusiva.
			if ( ! $dim ) {
				$a[] = array(
					'categoria' => 'inconclusivo',
					'codigo'    => 'logo_dimensoes_desconhecidas',
					'url'       => $url,
				); } elseif ( $dim[0] < 112 || $dim[1] < 112 ) {
				$a[] = array(
					'categoria' => 'erro',
					'codigo'    => 'logo_menor_112',
					'largura'   => $dim[0],
					'altura'    => $dim[1],
				); }
		}
		return $a;
	}
	public static function cron(): void {
		if ( ! F3Base_Llms::plugin_de_seo_ativo() ) {
			return; }
		$e = (array) F3Base_Options::fotografia( self::ESTADO )['valor'];
		if ( ! empty( $e['trabalho']['id'] ) ) {
			self::continuar( $e['trabalho']['id'] );
		} else {
			self::verificar( self::paginas(), F3Base_Options::revisao( 'f3base_seo_entidade' ) ); }
		self::agendar();
	}
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		F3Base_Servicos::registrar_ability(
			'f3base/schema-verificar',
			array(
				'label'               => 'Verificar schema publicado',
				'description'         => 'Consultar lê evidências. Verificar_publico faz HTTP limitado e persiste a prova; não aprova rich results.',
				'category'            => 'f3base',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'acao'             => array(
							'type' => 'string',
							'enum' => array( 'consultar', 'verificar_publico' ),
						),
						'revisao_esperada' => array( 'type' => 'string' ),
						'paginas'          => array(
							'type'     => 'array',
							'maxItems' => 5,
							'items'    => array( 'type' => 'string' ),
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
				'permission_callback' => static fn() => current_user_can( 'manage_options' ),
				'execute_callback'    => array( __CLASS__, 'executar' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}
	public static function executar( array $v ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array( 'codigo' => 'sem_permissao' ); }
		$marca=F3Base_Testes::resolver($v);if(!$marca['ok']){return $marca;}
        return 'verificar_publico' === ( $v['acao'] ?? 'consultar' ) ? self::verificar( $v['paginas'] ?? self::paginas(), (string) ( $v['revisao_esperada'] ?? '' ), $marca['contexto_teste'] ) : self::consultar();
	}
}
