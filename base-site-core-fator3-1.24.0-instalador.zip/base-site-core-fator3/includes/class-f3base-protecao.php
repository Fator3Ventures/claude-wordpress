<?php
/** Proteções independentes. Preservam a autenticação e as permissões nativas do WordPress. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Protecao {
    public static function config(): array {return F3Base_Options::ler('f3base_protecao');}
    public static function iniciar(): void {
        add_filter('rest_pre_dispatch',array(__CLASS__,'usuarios'),9,3);
        add_filter('xmlrpc_enabled',static fn($v)=>empty(self::config()['xmlrpc_desativado'])?$v:false);
        add_filter('xmlrpc_methods',static fn($v)=>empty(self::config()['xmlrpc_desativado'])?$v:array());
        add_filter('wp_headers',static function($h){if(!empty(self::config()['xmlrpc_desativado'])){foreach(array_keys($h) as $k){if(strtolower($k)==='x-pingback'){unset($h[$k]);}}}return $h;});
        add_filter('login_errors',static fn($v)=>!empty(self::config()['login_generico'])?'Não foi possível entrar. Confira seus dados e tente novamente.':$v);
        add_action('init',static function(){if(!empty(self::config()['xmlrpc_desativado'])){remove_action('wp_head','rsd_link');remove_action('wp_head','wlwmanifest_link');if(defined('XMLRPC_REQUEST')&&XMLRPC_REQUEST){status_header(403);nocache_headers();header('Content-Type: text/plain; charset=utf-8');echo 'XML-RPC desativado neste site.';exit;}}},-100);
    }
    public static function usuarios($result,WP_REST_Server $server,WP_REST_Request $request){
        if(empty(self::config()['usuarios_rest_restritos'])||is_user_logged_in()){return $result;}
        if(preg_match('#^/wp/v2/users(?:/|$)#',$request->get_route())){return new WP_Error('f3base_usuarios_restritos','Este recurso exige autenticação.',array('status'=>401));}
        return $result;
    }
    public static function diagnostico(): array {
        return array('configurado'=>self::config(),'escopo'=>'REST users anônimo, XML-RPC e mensagem pública de login','preservados'=>array('usuarios','senhas','application_passwords','capabilities','mcp'),'inventario_editorial'=>array('rss','oembed','slug_de_autor','arquivo_de_autor','nome_publico'),'aviso'=>'O bloqueio de uma API não garante que nomes de usuários deixem de aparecer no conteúdo público. Não há renomeação automática.');
    }
}
