<?php
/** Complementação técnica sem substituir a procedência da configuração. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
trait F3Base_Options_Complementacao {
    private static function caminhos_acrescentados($antes, $depois, string $prefixo=''): array {
        $r=array(); if (!is_array($antes)||!is_array($depois)) { return $r; }
        foreach ($depois as $k=>$v) {
            $path=$prefixo.(string)$k;
            if (!array_key_exists($k,$antes)) { $r[]=$path; }
            elseif (is_array($v)&&!array_is_list($v)) { $r=array_merge($r,self::caminhos_acrescentados($antes[$k],$v,$path.'.')); }
        }
        return $r;
    }
    /** Não dispara efeitos comerciais; o instalador verifica e retoma cada etapa. */
    public static function complementar_padrao(string $nome, $padrao, string $versao): array {
        $f=self::fotografia_bruta($nome); if ($f['erro']) { return array('ok'=>false,'codigo'=>'leitura_falhou'); }
        if (!$f['existe']) { $r=self::gravar($nome,$padrao,self::ORIGEM_PADRAO,$f['revisao']);return array_merge($r,array('ok'=>!empty($r['persisted'])&&in_array($r['audit']['status']??'not_required',array('recorded','not_required'),true))); }
        $novo=F3Base_Configuracao_Medicao::completar($f['valor'],$padrao);
        $ajustadas=array();
        if ($nome==='f3base_pipedrive'&&is_array($novo)&&array_key_exists('pais_telefone',$novo)&&$novo['pais_telefone']==='') { $novo['pais_telefone']='BR'; $ajustadas[]='pais_telefone'; }
        $journal=self::fotografia('f3base_config_complementacoes');
        if ($journal['erro']) { return array('ok'=>false,'codigo'=>'historico_indisponivel'); }
        $pendente=$journal['valor']['pendentes'][$nome]??null;
        if (self::equivalente($novo,$f['valor'])) {
            if (is_array($pendente)&&hash_equals($pendente['revisao_depois'],$f['revisao'])) { return self::concluir_complementacao($nome,$pendente); }
            return array('ok'=>true,'persisted'=>true,'codigo'=>'sem_alteracao','revisao'=>$f['revisao']);
        }
        $declaracao=self::declaracao($nome);$recusa=self::recusar($nome,$novo,$declaracao);
        if($recusa!==''){return array('ok'=>false,'codigo'=>'valor_recusado','motivo'=>$recusa,'persisted'=>false);}
        $prov=self::fotografia(self::OPTION_PROVENIENCIA);
        if ($prov['erro']) { return array('ok'=>false,'codigo'=>'procedencia_indisponivel'); }
        $anterior=$prov['valor'][$nome]??null;
        $rev= self::revisao_do_bruto($nome,array('option_value'=>(string)maybe_serialize($novo)));
        $id=hash('sha256',$nome.'|'.$versao.'|'.$f['revisao'].'|'.$rev.'|'.wp_json_encode($anterior));
        $evento=array('id'=>$id,'versao'=>$versao,'em'=>time(),'operacao'=>'completar_padroes','subchaves_acrescentadas'=>self::caminhos_acrescentados($f['valor'],$novo),'subchaves_ajustadas'=>$ajustadas,'revisao_antes'=>$f['revisao'],'revisao_depois'=>$rev,'procedencia_anterior'=>$anterior);
        $save=self::atualizar_estado('f3base_config_complementacoes',static function($s)use($nome,$evento,$f){
            if (!hash_equals($f['revisao'],self::revisao($nome))) { return null; }
            $s=is_array($s)?$s:array(); $s['pendentes'][$nome]=$evento; return $s;
        });
        if (empty($save['persisted'])) { return array('ok'=>false,'codigo'=>'checkpoint_complementacao_falhou'); }
        $d=self::declaracao($nome); $aplicada=false;
        self::$escritas_em_curso[$nome]=(self::$escritas_em_curso[$nome]??0)+1;
        try { $ok=self::escrever_condicional($nome,$novo,(bool)($d['autoload']??true),$f['revisao'],$aplicada); }
        finally { --self::$escritas_em_curso[$nome]; }
        if (!$ok) { return array('ok'=>false,'codigo'=>'complementacao_conflito_ou_falha','persisted'=>$aplicada); }
        return self::concluir_complementacao($nome,$evento);
    }
    private static function concluir_complementacao(string $nome,array $evento): array {
        $rev=$evento['revisao_depois'];
        if (!hash_equals($rev,self::revisao($nome))) { return array('ok'=>false,'codigo'=>'complementacao_revisao_divergente'); }
        $antes=$evento['procedencia_anterior'];
        $r=self::atualizar_estado(self::OPTION_PROVENIENCIA,static function($s)use($nome,$evento,$antes,$rev){
            if (!hash_equals($rev,self::revisao($nome))) { return null; }
            $s=is_array($s)?$s:array(); $atual=$s[$nome]??null;
            if (($atual['complementacao_id']??'')===$evento['id']) { return $s; }
            if ($atual!==$antes) { return null; }
            $confirmado=is_array($antes)&&in_array($antes['origem']??'',self::origens(),true)&&hash_equals($evento['revisao_antes'],(string)($antes['revisao']??''));
            $entry=is_array($antes)?$antes:array();
            $entry['revisao_configuracao']=$entry['revisao_configuracao']??($entry['revisao']??'');
            $entry['revisao']=$rev; $entry['complementacao_id']=$evento['id'];
            $entry['composicao']=$confirmado?(($entry['origem']===self::ORIGEM_PADRAO)?'padrao_integral':'configurado_complementado'):'desconhecido';
            if (!$confirmado) { $entry['origem']=self::ORIGEM_DESCONHECIDA; }
            $s[$nome]=$entry; return $s;
        });
        if (empty($r['persisted'])) { return array('ok'=>false,'persisted'=>true,'codigo'=>'complementacao_auditoria_pendente'); }
        $saved=self::atualizar_estado('f3base_config_complementacoes',static function($s)use($nome,$evento,$rev){
            if (!hash_equals($rev,self::revisao($nome))) { return null; }
            $s['eventos'][$nome][$evento['id']]=$evento; unset($s['pendentes'][$nome]); return $s;
        });
        return array('ok'=>!empty($saved['persisted']),'persisted'=>true,'codigo'=>empty($saved['persisted'])?'complementacao_historico_pendente':'complementacao_confirmada','revisao'=>$rev,'subchaves_acrescentadas'=>$evento['subchaves_acrescentadas']);
    }
    public static function complementacoes(string $nome,int $pagina=1): array {
        $s=get_option('f3base_config_complementacoes',array());$all=array_values($s['eventos'][$nome]??array());
        $rows=array_slice($all,(max(1,$pagina)-1)*20,20);
        foreach($rows as &$row){unset($row['procedencia_anterior']);}unset($row);
        return array('eventos'=>$rows,'total'=>count($all),'pagina'=>max(1,$pagina),'proxima_pagina'=>count($all)>max(1,$pagina)*20?$pagina+1:null,'pendente'=>isset($s['pendentes'][$nome]),'reparo'=>$s['reparos'][$nome]??null);
    }
    /** Evidência administrativa: fotografia anterior e referência de auditoria, sem SQL pelo canal. */
    public static function reparar_procedencia(array $e): array {
        $sim=($e['simular']??true)!==false;$fail=static fn($code)=>array('ok'=>false,'codigo'=>$code,'simulado'=>$sim,'alteraria'=>false,'persisted'=>false);
        if(!current_user_can('manage_options')){return $fail('sem_permissao');}
        $n=$e['nome']??'';$d=self::declaracao($n);$ev=$e['evidencia']??array();
        if(!$d||($d['campo']??'')!=='grupo'||empty($d['operavel'])||self::e_segredo($n)){return $fail('opcao_nao_elegivel');}
        $f=self::fotografia_bruta($n);$pf=self::fotografia(self::OPTION_PROVENIENCIA);$p=$pf['valor'][$n]??array();
        if($f['erro']||$pf['erro']){return $fail('leitura_indisponivel');}
        if(!hash_equals($f['revisao'],(string)($e['revisao_esperada']??''))){return $fail('conflito');}
        if(($ev['formato']??'')!=='f3base-procedencia/1'||($ev['site']??'')!==home_url('/')||($ev['nome']??'')!==$n||!is_array($ev['valor_anterior']??null)||!is_array($ev['procedencia_anterior']??null)||!preg_match('/^[A-Za-z0-9_.:\/-]{1,160}$/D',(string)($e['referencia']??''))){return $fail('evidencia_invalida');}
        $old=$ev['procedencia_anterior'];$oldrev=self::revisao_do_bruto($n,array('option_value'=>(string)maybe_serialize($ev['valor_anterior'])));
        if(!hash_equals($oldrev,(string)($old['revisao']??''))||!in_array($old['origem']??'',self::origens(),true)||in_array($old['origem'],array(self::ORIGEM_PADRAO,self::ORIGEM_DESCONHECIDA),true)||!in_array($old['canal']??'',array('mcp','admin','cli','php','rest','ability'),true)||!is_int($old['em']??null)){return $fail('registro_anterior_nao_comprovado');}
        $journal=get_option('f3base_config_complementacoes',array());$root=$p;
        $events=array_values($journal['eventos'][$n]??array());for($i=count($events)-1;$i>=0;--$i){if(($root['complementacao_id']??'')===$events[$i]['id']){$root=$events[$i]['procedencia_anterior']??array();}}
        $fingerprint=hash('sha256',wp_json_encode($ev));$done=$journal['reparos'][$n]??array();
        if(($done['evidencia_sha256']??'')===$fingerprint&&($p['origem']??'')===$old['origem']&&($p['canal']??'')===$old['canal']&&($p['em']??0)===$old['em']){
            if(($done['estado']??'')==='reparo_pendente'){
                if($sim){return array('ok'=>true,'codigo'=>'reparo_auditoria_pendente','simulado'=>true,'alteraria'=>true,'persisted'=>false);}
                if(($e['confirmar']??false)!==true){return $fail('confirmacao_necessaria');}
                $final=self::atualizar_estado('f3base_config_complementacoes',static function($v)use($n,$fingerprint,$f){if(($v['reparos'][$n]['evidencia_sha256']??'')!==$fingerprint||!hash_equals($f['revisao'],self::revisao($n))){return null;}$v['reparos'][$n]['estado']='reparo_confirmado';$v['reparos'][$n]['confirmado_em']=time();return $v;});return array('ok'=>!empty($final['persisted']),'persisted'=>!empty($final['persisted']),'codigo'=>'reparo_confirmado','revisao'=>$f['revisao']);
            }return array('ok'=>true,'codigo'=>'reparo_ja_confirmado','simulado'=>$sim,'alteraria'=>false,'revisao'=>$f['revisao']);
        }
        if(($root['origem']??'')!==self::ORIGEM_PADRAO||($root['canal']??'')!=='php'||($root['em']??0)<=$old['em']){return $fail('configuracao_posterior_ou_evidencia_incompativel');}
        $defaults=json_decode((string)file_get_contents(F3BASE_PLUGIN_DIR.'dados/padroes-1210.json'),true);
        if(!isset($defaults[$n])){return $fail('catalogo_1210_indisponivel');}
        $after=self::revisao_do_bruto($n,array('option_value'=>(string)maybe_serialize(F3Base_Configuracao_Medicao::completar($ev['valor_anterior'],$defaults[$n]))));
        if(!hash_equals($after,(string)($root['revisao']??''))||hash_equals($after,$oldrev)){return $fail('diferenca_1210_nao_comprovada');}
        $current=F3Base_Configuracao_Medicao::completar(F3Base_Configuracao_Medicao::completar($ev['valor_anterior'],$defaults[$n]),$d['padrao']);if($n==='f3base_pipedrive'&&($current['pais_telefone']??null)===''){$current['pais_telefone']='BR';}
        if(!self::equivalente($current,$f['valor'])){return $fail('valor_atual_incompativel');}
        $preview=array('ok'=>true,'simulado'=>$sim,'alteraria'=>true,'persisted'=>false,'nome'=>$n,'revisao'=>$f['revisao'],'origem_anterior'=>$root['origem'],'origem_restaurada'=>$old['origem'],'canal'=>$old['canal'],'em_original'=>$old['em'],'referencia'=>$e['referencia'],'evidencia_sha256'=>$fingerprint);
        if($sim){return $preview;}
        if(($e['confirmar']??false)!==true){return $fail('confirmacao_necessaria');}
        $checkpoint=self::atualizar_estado('f3base_config_complementacoes',static function($v)use($n,$fingerprint,$e,$root,$f){if(!hash_equals($f['revisao'],self::revisao($n))){return null;}$v['reparos'][$n]=array('estado'=>'reparo_pendente','em'=>time(),'referencia'=>$e['referencia'],'evidencia_sha256'=>$fingerprint,'revisao'=>$f['revisao'],'registro_substituido'=>$root);return $v;});if(empty($checkpoint['persisted'])){return $fail('reparo_checkpoint_falhou');}
        $repaired=array_merge($p,array('origem'=>$old['origem'],'canal'=>$old['canal'],'em'=>$old['em'],'revisao'=>$f['revisao'],'revisao_configuracao'=>$oldrev,'composicao'=>'configurado_complementado'));
        $result=self::atualizar_estado(self::OPTION_PROVENIENCIA,static function($state)use($n,$p,$repaired,$f){if(!hash_equals($f['revisao'],self::revisao($n))||($state[$n]??array())!==$p){return null;}$state[$n]=$repaired;return $state;});
        if(empty($result['persisted'])){return $fail('reparo_conflito_ou_falha');}
        $r=self::atualizar_estado('f3base_config_complementacoes',static function($state)use($n,$fingerprint,$e,$root,$f){$state['reparos'][$n]=array('estado'=>'reparo_confirmado','em'=>time(),'referencia'=>$e['referencia'],'evidencia_sha256'=>$fingerprint,'revisao'=>$f['revisao'],'registro_substituido'=>$root);return $state;});
        $check=self::fotografia(self::OPTION_PROVENIENCIA);$ok=!empty($r['persisted'])&&($check['valor'][$n]??null)===$repaired&&hash_equals($f['revisao'],self::revisao($n));
        return array_merge($preview,array('ok'=>$ok,'persisted'=>$ok,'codigo'=>$ok?'reparo_confirmado':'reparo_auditoria_pendente'));
    }
    /** A origem perdida não pode ser inventada a partir do horário da atualização. */
    public static function analisar_procedencia_1210(): array {
        $migration=get_option('f3base_release_1210',array());if(($migration['origem']??'')==='nova'){return array('ok'=>true,'candidatas'=>array(),'codigo'=>'base_1210_instalada_do_zero');}$prov=self::fotografia(self::OPTION_PROVENIENCIA);
        if($prov['erro']){return array('ok'=>false,'codigo'=>'procedencia_indisponivel');}
        $candidatas=array();foreach((array)$prov['valor'] as $n=>$p){
            if(!is_array($p)||($p['origem']??'')!=='padrao'||($p['canal']??'')!=='php'||empty($migration['iniciado_em'])||($p['em']??0)<$migration['iniciado_em']||($p['em']??0)>($migration['concluido_em']??0)){continue;}
            $d=self::declaracao($n);if(($d['campo']??'')!=='grupo'){continue;}
            $candidatas[$n]=array('estado'=>'reparo_nao_comprovado','motivo'=>'Registro anterior não disponível no mapa nativo de última escrita; horário não comprova impacto. Forneça evidência administrativa verificável.','em'=>time());
        }
        $r=self::atualizar_estado('f3base_config_complementacoes',static function($s)use($candidatas){$s=is_array($s)?$s:array();foreach($candidatas as $n=>$p){if(!isset($s['reparos'][$n])){$s['reparos'][$n]=$p;}}return $s;});
        return array('ok'=>!empty($r['persisted']),'candidatas'=>array_keys($candidatas));
    }
}
