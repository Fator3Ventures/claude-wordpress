<?php
/**
 * Módulo schema-extensao.
 *
 * O plugin de SEO responde por Organization, WebSite, WebPage, BreadcrumbList e
 * Article. Este módulo ESTENDE o que falta — `Service` e as propriedades de
 * entidade (`areaServed`, `knowsAbout`, `contactPoint`, `parentOrganization`,
 * `sameAs`) — pelos filtros do próprio plugin, nunca duplicando nó existente.
 *
 * O FAQ é lido dos blocos `core/details` da própria página, para que editar a
 * pergunta atualize o schema. `FAQPage` só é emitido quando a configuração o
 * declarar: o Google encerrou o rich result e a seção visível continua valendo
 * por si.
 *
 * `sameAs` só com URL da configuração, e o que sai é a UNIÃO com o que o plugin
 * de SEO já emitia — nunca a substituição dele. Vazio fica vazio: perfil errado
 * atrapalha mais que a ausência.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Extensão do grafo do plugin de SEO.
 */
final class F3Base_Modulo_Schema_Extensao extends F3Base_Modulo {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'schema-extensao';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Extensão de schema', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Acrescenta ao grafo do plugin de SEO os nós Service e as propriedades de entidade declaradas na configuração, pelos filtros do próprio plugin. Lê o FAQ dos blocos core/details da página; sameAs sai só com URL declarada.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'filter',
				'hook'       => 'wpseo_schema_organization',
				'metodo'     => 'estender_organizacao',
				'prioridade' => 999,
				'args'       => 1,
			),
			array(
				'tipo'       => 'filter',
				'hook'       => 'wpseo_schema_graph',
				'metodo'     => 'estender_grafo',
				'prioridade' => 999,
				'args'       => 1,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_seo_entidade' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$plugin = F3Base_Llms::plugin_de_seo_ativo();

		return array(
			array(
				'rotulo'   => __( 'Plugin de SEO ativo', 'f3base' ),
				'presente' => $plugin,
				'detalhe'  => $plugin
					? __( 'os filtros do plugin são o único ponto de extensão usado; nada é duplicado.', 'f3base' )
					: __( 'ausente: não há grafo para estender e este módulo não emite schema por conta própria.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Blocos core/details na página', 'f3base' ),
				'presente' => true,
				'detalhe'  => __( 'o FAQ é lido do conteúdo publicado, não de uma cópia paralela.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		if ( ! F3Base_Llms::plugin_de_seo_ativo() ) {
			return $this->degradado(
				__( 'plugin de SEO ausente: sem grafo para estender, nenhuma propriedade de entidade e nenhum nó Service são emitidos.', 'f3base' )
			);
		}

		$entidade = $this->entidade();
		$servicos = is_array( $entidade['servicos'] ) ? $entidade['servicos'] : array();
		$same_as  = is_array( $entidade['same_as'] ) ? $entidade['same_as'] : array();

        $props=F3Base_Seo_Entidade::propriedades($entidade,'');
        foreach(array('area_servida'=>'areaServed','conhece_sobre'=>'knowsAbout','ponto_de_contato'=>'contactPoint') as $k=>$name){if(!empty($entidade[$k])){$props[$name]=$entidade[$k];}}
        return $this->ativo(sprintf('Grafo do SEO: %d serviço(s), %d perfil(is) sameAs e %d propriedade(s) de entidade declarados. FAQ: %s. Propriedades existentes do emissor são preservadas.',count($servicos),count($same_as),count($props),!empty($entidade['faq_schema'])?'habilitada':'desligada'));

	}

	/**
	 * Estende a peça Organization com as propriedades de entidade declaradas.
	 *
	 * DUAS REGRAS, e elas são diferentes de propósito:
	 *
	 * - `areaServed`, `knowsAbout`, `contactPoint` e `parentOrganization` SÓ
	 *   GRAVAM CHAVE AUSENTE: propriedade já emitida pelo plugin de SEO não é
	 *   sobrescrita, porque o valor dele foi escrito por quem configurou o
	 *   plugin e substituí-lo seria decidir por ele.
	 * - `sameAs` é UNIÃO. Ela é uma lista de perfis, não um valor: o plugin de
	 *   SEO emite os que conhece, a configuração declara os que ele não conhece,
	 *   e a resposta certa é o conjunto dos dois sem repetição. Ceder a chave
	 *   inteira ao primeiro que a escrever faria os perfis declarados aqui
	 *   sumirem do grafo assim que o plugin passasse a emitir um só.
	 *
	 * @param mixed $dados Peça Organization do plugin de SEO.
	 * @return mixed
	 */
	public function estender_organizacao( $dados ) {
		if ( ! is_array( $dados ) ) {
			return $dados;
		}

		if ( ! empty( $dados['@id'] ) ) {
			F3Base_Autoria::$organizacao = $dados; }

		$entidade = $this->entidade();

		$mapa = array(
			'areaServed' => $entidade['area_servida'],
			'knowsAbout' => $entidade['conhece_sobre'],
		);

		foreach ( $mapa as $propriedade => $valores ) {
			if ( ! is_array( $valores ) || array() === $valores ) {
				continue;
			}
			if ( isset( $dados[ $propriedade ] ) ) {
				continue;
			}
			$dados[ $propriedade ] = array_values( $valores );
		}

		$contatos = $this->pontos_de_contato( $entidade );
		if ( array() !== $contatos && ! isset( $dados['contactPoint'] ) ) {
			$dados['contactPoint'] = $contatos;
		}

		foreach ( F3Base_Seo_Entidade::propriedades( $entidade, (string) ( $dados['@id'] ?? '' ) ) as $chave => $valor ) {
			if ( ! array_key_exists( $chave, $dados ) ) {
				$dados[ $chave ] = $valor; }
		}

		$same_as = is_array( $entidade['same_as'] ) ? array_values( array_filter( $entidade['same_as'] ) ) : array();
		if ( array() !== $same_as ) {
			$atual = isset( $dados['sameAs'] ) ? (array) $dados['sameAs'] : array();
			$uniao = array_values( array_unique( array_merge( $atual, $same_as ) ) );

			$dados['sameAs'] = $uniao;
		}

		return $dados;
	}

	/**
	 * Acrescenta ao grafo os nós que o plugin de SEO não emite.
	 *
	 * @param mixed $grafo Grafo do plugin de SEO.
	 * @return mixed
	 */
	public function estender_grafo( $grafo ) {
		if ( ! is_array( $grafo ) ) {
			return $grafo;
		}

		$entidade = $this->entidade();

		foreach ( $grafo as &$no ) {
			if ( is_array( $no ) && in_array( 'Organization', (array) ( $no['@type'] ?? array() ), true ) && ( empty( F3Base_Autoria::$organizacao['@id'] ) || ( $no['@id'] ?? '' ) === F3Base_Autoria::$organizacao['@id'] ) ) {
				$no = $this->estender_organizacao( $no ); }
		}
		unset( $no );
		$grafo = F3Base_Autoria::grafo( $grafo );
		$grafo = $this->acrescentar_servicos( $grafo, $entidade );
		$grafo = $this->acrescentar_faq( $grafo, $entidade );
		$grafo = F3Base_Servicos::pessoas( $grafo, $entidade, (int) get_queried_object_id() );

		return $grafo;
	}

	/**
	 * Acrescenta os nós Service declarados, sem duplicar.
	 *
	 * @param array<int,mixed>    $grafo    Grafo atual.
	 * @param array<string,mixed> $entidade Entidade declarada.
	 * @return array<int,mixed>
	 */
	private function acrescentar_servicos( array $grafo, array $entidade ): array {
		$servicos = is_array( $entidade['servicos'] ) ? $entidade['servicos'] : array();

		if ( array() === $servicos ) {
			return $grafo;
		}

		$existentes = $this->nomes_existentes( $grafo, 'Service' );
		$provedor   = $this->id_da_organizacao( $grafo );

		foreach ( $servicos as $servico ) {
			$nome = isset( $servico['nome'] ) ? (string) $servico['nome'] : '';
			if ( '' === $nome || in_array( $nome, $existentes, true ) ) {
				continue;
			}

			$no = array(
				'@type' => 'Service',
				'@id'   => home_url( '/#/schema/service/' . md5( $nome ) ),
				'name'  => $nome,
			);

			$descricao = isset( $servico['descricao'] ) ? (string) $servico['descricao'] : '';
			if ( '' !== $descricao ) {
				$no['description'] = $descricao;
			}

			$url = isset( $servico['url'] ) ? (string) $servico['url'] : '';
			if ( '' !== $url ) {
				$no['url'] = $url;
			}

			$tipo = isset( $servico['tipo_servico'] ) ? (string) $servico['tipo_servico'] : '';
			if ( '' !== $tipo ) {
				$no['serviceType'] = $tipo;
			}

			$area = isset( $servico['area_servida'] ) && is_array( $servico['area_servida'] ) ? array_values( $servico['area_servida'] ) : array();
			if ( array() !== $area ) {
				$no['areaServed'] = $area;
			}

			if ( '' !== $provedor ) {
				$no['provider'] = array( '@id' => $provedor );
			}

			$oferta = F3Base_Seo_Entidade::oferta_publica( $servico, (int) get_queried_object_id() );
			if ( $oferta ) { $no['offers'] = $oferta; }
			$grafo[]      = $no;
			$existentes[] = $nome;
		}

		return $grafo;
	}

	/**
	 * Acrescenta FAQPage quando a configuração o declarar.
	 *
	 * @param array<int,mixed>    $grafo    Grafo atual.
	 * @param array<string,mixed> $entidade Entidade declarada.
	 * @return array<int,mixed>
	 */
	private function acrescentar_faq( array $grafo, array $entidade ): array {
		$perguntas = self::faq_da_pagina();

		if ( array() === $perguntas ) {
			return $grafo;
		}

		if ( empty( $entidade['faq_schema'] ) ) {
			return $grafo;
		}

		if ( array() !== $this->nomes_existentes( $grafo, 'FAQPage' ) || $this->tem_tipo( $grafo, 'FAQPage' ) ) {
			return $grafo;
		}

		$itens = array();

		foreach ( $perguntas as $indice => $par ) {
			$itens[] = array(
				'@type'          => 'Question',
				'@id'            => get_permalink( get_queried_object_id() ) . '#f3base-question-' . md5( (string) $par['pergunta'] . '|' . (string) $indice ),
				'name'           => (string) $par['pergunta'],
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => (string) $par['resposta'],
				),
			);
		}

        $url = (string) get_permalink( get_queried_object_id() );
        foreach ( $grafo as &$no ) {
            if ( ! is_array( $no ) || ! in_array( 'WebPage', (array) ( $no['@type'] ?? array() ), true ) || strtok( (string) ( $no['url'] ?? $no['@id'] ?? '' ), '#' ) !== strtok( $url, '#' ) ) { continue; }
            if ( empty( $no['mainEntity'] ) ) {
                $no['@type'] = array_values( array_unique( array_merge( (array) $no['@type'], array( 'FAQPage' ) ) ) );
                $no['mainEntity'] = $itens;
            } else {
                $grafo[] = array( '@type'=>'FAQPage', '@id'=>$url.'#f3base-faq', 'url'=>$url, 'isPartOf'=>array('@id'=>$no['@id']), 'mainEntity'=>$itens );
            }
            unset( $no ); return $grafo;
        }
        unset( $no );
        $grafo[] = array( '@type'=>'FAQPage', '@id'=>$url.'#f3base-faq', 'url'=>$url, 'mainEntity'=>$itens );

		return $grafo;
	}

	/**
	 * Lê o FAQ dos blocos `core/details` da página consultada.
	 *
	 * A GUARDA DE `is_singular()` é a diferença entre ler a página e ler
	 * qualquer coisa: `get_queried_object_id()` devolve um id em toda
	 * requisição — o do TERMO num arquivo de categoria, o do AUTOR num arquivo
	 * de autor —, e esses ids colidem com ids de post. Sem a guarda, o arquivo
	 * da categoria 12 emitia o FAQ do post 12, que é um FAQPage sobre uma página
	 * que não está sendo exibida: schema afirmando sobre a URL errada.
	 *
	 * O argumento explícito passa por cima da guarda de propósito: quem informa
	 * o id sabe qual conteúdo quer, e é assim que o filtro `f3base_faq_detalhes`
	 * e a bancada leem um post fora do laço.
	 *
	 * @param int|null $post_id Post a ler; padrão, o consultado.
	 * @return array<int,array{pergunta:string,resposta:string}>
	 */
	public static function faq_da_pagina( ?int $post_id = null ): array {
		if ( null === $post_id && function_exists( 'is_singular' ) && ! is_singular() ) {
			return array();
		}

		$post_id = null === $post_id ? (int) get_queried_object_id() : $post_id;

		if ( $post_id <= 0 ) {
			return array();
		}

		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post || ! is_post_publicly_viewable( $post ) || $post->post_password || '' === (string) $post->post_content ) {
			return array();
		}

		if ( ! function_exists( 'parse_blocks' ) ) {
			return array();
		}

		$pares = self::colher_details( parse_blocks( (string) $post->post_content ) );

		/**
		 * Permite a outro artefato do pacote ajustar o FAQ lido da página.
		 *
		 * @param array<int,array{pergunta:string,resposta:string}> $pares   Pares lidos.
		 * @param int                                               $post_id Conteúdo de origem.
		 */
		$pares = apply_filters( 'f3base_faq_detalhes', $pares, $post_id );

		return is_array( $pares ) ? $pares : array();
	}

	/**
	 * Percorre a árvore de blocos colhendo `core/details`.
	 *
	 * @param array<int,array<string,mixed>> $blocos Blocos analisados.
	 * @return array<int,array{pergunta:string,resposta:string}>
	 */
	private static function colher_details( array $blocos ): array {
		$pares = array();

		foreach ( $blocos as $bloco ) {
			if ( ! is_array( $bloco ) ) {
				continue;
			}

			$nome = isset( $bloco['blockName'] ) ? (string) $bloco['blockName'] : '';

			if ( 'core/details' === $nome ) {
                // Parse the saved editor markup, including inner blocks; no rendering/filter side effects.
                $pergunta = ''; $resposta = '';
                $parser = WP_HTML_Processor::create_fragment( serialize_block( $bloco ) );
                if ( $parser ) {
                    while ( $parser->next_token() ) {
                        if ( '#text' !== $parser->get_token_type() ) { if ( $parser->is_tag_closer() && in_array( $parser->get_tag(), array('P','DIV','LI','H2','H3','BLOCKQUOTE'), true ) ) { $resposta .= ' '; } continue; }
                        $path = $parser->get_breadcrumbs();
                        if ( count( array_keys( $path, 'DETAILS', true ) ) !== 1 || array_intersect( $path, array( 'SCRIPT', 'STYLE', 'TEMPLATE' ) ) ) { continue; }
                        $texto = html_entity_decode( $parser->get_modifiable_text(), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                        if ( in_array( 'SUMMARY', $path, true ) ) { $pergunta .= $texto; }
                        else { $resposta .= $texto; }
                    }
                }

				$pergunta = trim( preg_replace( '/\s+/u', ' ', $pergunta ) ?? '' );
				$resposta = trim( preg_replace( '/\s+/u', ' ', $resposta ) ?? '' );

				if ( '' !== $pergunta && '' !== $resposta ) {
					$pares[] = array(
						'pergunta' => $pergunta,
						'resposta' => $resposta,
					);
				}
			}

			if ( isset( $bloco['innerBlocks'] ) && is_array( $bloco['innerBlocks'] ) && array() !== $bloco['innerBlocks'] ) {
				$pares = array_merge( $pares, self::colher_details( $bloco['innerBlocks'] ) );
			}
		}

		return $pares;
	}

	/**
	 * Nomes já presentes no grafo para um dado tipo.
	 *
	 * @param array<int,mixed> $grafo Grafo atual.
	 * @param string           $tipo  Tipo procurado.
	 * @return string[]
	 */
	private function nomes_existentes( array $grafo, string $tipo ): array {
		$nomes = array();

		foreach ( $grafo as $no ) {
			if ( ! is_array( $no ) || ! isset( $no['@type'] ) ) {
				continue;
			}

			$tipos = is_array( $no['@type'] ) ? $no['@type'] : array( $no['@type'] );

			if ( in_array( $tipo, array_map( 'strval', $tipos ), true ) && isset( $no['name'] ) ) {
				$nomes[] = (string) $no['name'];
			}
		}

		return $nomes;
	}

	/**
	 * O grafo já traz um nó do tipo pedido?
	 *
	 * @param array<int,mixed> $grafo Grafo atual.
	 * @param string           $tipo  Tipo procurado.
	 * @return bool
	 */
	private function tem_tipo( array $grafo, string $tipo ): bool {
		foreach ( $grafo as $no ) {
			if ( ! is_array( $no ) || ! isset( $no['@type'] ) ) {
				continue;
			}

			$tipos = is_array( $no['@type'] ) ? $no['@type'] : array( $no['@type'] );

			if ( in_array( $tipo, array_map( 'strval', $tipos ), true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * `@id` da Organization emitida pelo plugin de SEO.
	 *
	 * @param array<int,mixed> $grafo Grafo atual.
	 * @return string
	 */
	private function id_da_organizacao( array $grafo ): string {
		foreach ( $grafo as $no ) {
			if ( ! is_array( $no ) || ! isset( $no['@type'], $no['@id'] ) ) {
				continue;
			}

			$tipos = is_array( $no['@type'] ) ? $no['@type'] : array( $no['@type'] );

			if ( in_array( 'Organization', array_map( 'strval', $tipos ), true ) ) {
				return (string) $no['@id'];
			}
		}

		return '';
	}

	/**
	 * Pontos de contato declarados, no formato do schema.
	 *
	 * @param array<string,mixed> $entidade Entidade declarada.
	 * @return array<int,array<string,mixed>>
	 */
	private function pontos_de_contato( array $entidade ): array {
		$pontos = is_array( $entidade['ponto_de_contato'] ) ? $entidade['ponto_de_contato'] : array();
		$saida  = array();

		foreach ( $pontos as $ponto ) {
			if ( ! is_array( $ponto ) ) {
				continue;
			}

			$no = array( '@type' => 'ContactPoint' );

			$tipo = isset( $ponto['tipo'] ) ? (string) $ponto['tipo'] : '';
			if ( '' !== $tipo ) {
				$no['contactType'] = $tipo;
			}

			$telefone = isset( $ponto['telefone'] ) ? (string) $ponto['telefone'] : '';
			if ( '' !== $telefone ) {
				$no['telephone'] = $telefone;
			}

			$email = isset( $ponto['email'] ) ? (string) $ponto['email'] : '';
			if ( '' !== $email ) {
				$no['email'] = $email;
			}

			$idiomas = isset( $ponto['idiomas'] ) && is_array( $ponto['idiomas'] ) ? array_values( $ponto['idiomas'] ) : array();
			if ( array() !== $idiomas ) {
				$no['availableLanguage'] = $idiomas;
			}

			if ( count( $no ) > 1 ) {
				$saida[] = $no;
			}
		}

		return $saida;
	}

	/**
	 * Entidade declarada, normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function entidade(): array {
		$declaracao = F3Base_Options::declaracao( 'f3base_seo_entidade' );
		$padrao     = null !== $declaracao && is_array( $declaracao['padrao'] ) ? $declaracao['padrao'] : array();
		$entidade   = F3Base_Options::ler( 'f3base_seo_entidade' );

		return array_merge( $padrao, is_array( $entidade ) ? $entidade : array() );
	}
}
