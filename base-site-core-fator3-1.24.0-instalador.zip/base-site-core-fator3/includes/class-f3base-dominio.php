<?php
/** Canonicalização local e Public Suffix List empacotada. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Dominio {
    public static function host(string $host): string {
        $host=mb_strtolower(rtrim($host,'.'));
        if(preg_match('/[^\x00-\x7f]/',$host)){
            if(!function_exists('idn_to_ascii')){try{return class_exists('WpOrg\\Requests\\IdnaEncoder')?\WpOrg\Requests\IdnaEncoder::encode($host):'';}catch(Throwable $e){return '';}}
            $ascii=idn_to_ascii($host,IDNA_DEFAULT,INTL_IDNA_VARIANT_UTS46);if($ascii===false){return '';}$host=$ascii;
        }
        return $host;
    }
    public static function propriedade(string $p): string {
        $p=trim($p);if(str_starts_with(strtolower($p),'sc-domain:')){return 'sc-domain:'.self::host(substr($p,10));}
        $u=wp_parse_url($p);if(!$u||empty($u['host'])||empty($u['scheme'])){return $p;}
        // Invalid credentials/query are retained for the validator to refuse, never silently removed.
        if(isset($u['user'])||isset($u['pass'])||isset($u['query'])||isset($u['fragment'])){return $p;}
        $h=self::host($u['host']);return strtolower($u['scheme']).'://'.$h.(isset($u['port'])?':'.$u['port']:'').($u['path']??'');
    }
    public static function sufixo_publico(string $host): bool {
        static $rules=null;
        if($rules===null){$rules=array();foreach(file(F3BASE_PLUGIN_DIR.'dados/public_suffix_list.dat',FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES)?:array() as $line){if(str_starts_with($line,'//')){continue;}$prefix=str_starts_with($line,'!')?'!':(str_starts_with($line,'*.')?'*.':'');$name=self::host(substr($line,strlen($prefix)));if($name!==''){$rules[$prefix.$name]=true;}}}
        if(isset($rules['!'.$host])){return false;}
        if(isset($rules[$host])){return true;}
        $dot=strpos($host,'.');return $dot===false||isset($rules['*.'.substr($host,$dot+1)]);
    }
}
