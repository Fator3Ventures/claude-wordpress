<?php
/** Contratos da 1.19: preferências explícitas e serviços de medição editorial. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Configuracao_Medicao {
    private static bool $reavaliando=false;
    public static function iniciar(): void {
        foreach(array('added_option','updated_option') as $hook){add_action($hook,static function($n){if(is_string($n)&&isset(self::avisos()[$n])){self::reavaliar_avisos();}},220,1);}
        add_action('admin_post_f3base_aviso_dispensar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-aviso-dispensar');self::dispensar_aviso(array('nome'=>sanitize_key($_POST['nome']??'')));wp_safe_redirect(wp_get_referer()?:admin_url('admin.php?page=base-site-core-fator3&aba=tecnica'));exit;});
        F3Base_Tracking_Diagnostico::iniciar();
        F3Base_Confirmacao::iniciar();F3Base_Clarity::iniciar();F3Base_Meta_Transporte::iniciar();F3Base_Ofertas_Medicao::iniciar();
        F3Base_Medicao_Editorial_UI::iniciar();F3Base_Editorial::iniciar();F3Base_Inteligencia::iniciar();F3Base_Redes_Robos::iniciar();
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('configuracao-aviso-dispensar','Dispensar um aviso de configuração ativo',array(__CLASS__,'dispensar_aviso'),array('nome'=>array('type'=>'string')),array('nome'),false);
            F3Base_Servicos::ability('acessos-legado-ler','Consultar agregados arquivados fora dos totais atuais',array(F3Base_Acessos_Legado::class,'consultar'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>10000)));
            F3Base_Servicos::ability('medicao-saude-ler','Diagnóstico da coleta e lacunas observadas',array(F3Base_Medicao_Saude::class,'consultar'));
            F3Base_Servicos::ability('llms-reprocessar','Reprocessar manualmente a geração editorial',static fn()=>F3Base_Llms_Cobertura::executar(5,true),array(),array(),false);
            foreach(array('conteudos-relatorio'=>'conteudo','sessoes-listar'=>'sessoes','sessao-detalhar'=>'sessao','aquisicao-relatorio'=>'aquisicao') as $nome=>$visao){$schema=F3Base_Editorial_Relatorios::schema();unset($schema['visao']);F3Base_Servicos::ability($nome,'Medição editorial: '.$visao,static fn($e)=>F3Base_Editorial_Relatorios::consultar(array_merge($e,array('visao'=>$visao))),$schema,$visao==='sessao'?array('sessao'):array());}
            F3Base_Servicos::ability('medicao-editorial','Conteúdo, aquisição e sessões observadas',array(F3Base_Editorial_Relatorios::class,'consultar'),F3Base_Editorial_Relatorios::schema());
        });
    }
    public static function catalogo(array $c): array {
        $p=array('retencao_meses'=>13,'excluir_automacao'=>true,'aplicar_anotacoes'=>true,'redes_oficiais'=>true,'ip_log_confiavel'=>false);
        $campos=array(
            'retencao_meses'=>array('tipo'=>'inteiro','rotulo'=>'Meses de agregados editoriais','descricao'=>'Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.'),
            'excluir_automacao'=>array('tipo'=>'booleano','rotulo'=>'Excluir automação da audiência','descricao'=>'Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.'),
            'aplicar_anotacoes'=>array('tipo'=>'booleano','rotulo'=>'Aplicar exclusões de períodos anotados','descricao'=>'Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.'),
            'redes_oficiais'=>array('tipo'=>'booleano','rotulo'=>'Conferir listas oficiais dos robôs','descricao'=>'Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.'),
            'ip_log_confiavel'=>array('tipo'=>'booleano','rotulo'=>'Log contém o IP de origem confiável','descricao'=>'Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.')
        );
        foreach($campos as &$d){$d['impacto']=$d['descricao'];$d['exemplo']=$d['descricao'];}unset($d);
        $c['f3base_medicao_editorial']=array('rotulo'=>'Conteúdo, audiência e IA','descricao'=>'Retenção e qualidade dos relatórios editoriais.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'grupo','padrao'=>$p,'subcampos'=>$campos,'sanitiza'=>array(F3Base_Evolucao::class,'sanitizar'),'recusa'=>static function($v,$d){$r=F3Base_Evolucao::recusar($v,$d);if($r){return $r;}return isset($v['retencao_meses'])&&(!is_int($v['retencao_meses'])||$v['retencao_meses']<1||$v['retencao_meses']>25)?'Informe de 1 a 25 meses.':'';});
        foreach(array('f3base_gtm_evidencia','f3base_editorial_estado','f3base_redes_robos','f3base_nav_prova','f3base_logs_1170') as $n){$c[$n]=array('rotulo'=>$n,'descricao'=>'Estado técnico; não é preferência.','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));}
        $c['f3base_consentimento']['padrao']['painel']='padrao';
        $c['f3base_consentimento']['subcampos']['painel']=array('tipo'=>'enum','rotulo'=>'Apresentação do painel de consentimento','opcoes'=>array('padrao'=>'Padrão do plugin','tema'=>'Estilo fornecido pelo tema'),'descricao'=>'Padrão oferece estilos completos. Tema herda o desenho do site: exige CSS, contraste, foco e navegação por teclado adequados.','impacto'=>'O modo tema não muda consentimento nem categorias.','exemplo'=>'Use tema apenas com estilos conferidos em celular e teclado.');
        if(isset($c['f3base_consentimento']['schema_config']['properties'])){$c['f3base_consentimento']['schema_config']['properties']['painel']=array('type'=>'string','enum'=>array('padrao','tema'),'default'=>'padrao');}
        $c['f3base_meta_auto_config']=array('rotulo'=>'Configuração automática do Pixel Meta','descricao'=>'Ligado preserva a configuração automática da Meta. Desligue para solicitar autoConfig=false antes do init; PageView e Lead explícitos continuam. Isso não remove o script nem garante melhoria de desempenho.','impacto'=>'Desligar pode reduzir recursos automáticos do Pixel.','exemplo'=>'Mantenha ligado, salvo decisão explícita de controlar os eventos automáticos.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'booleano','padrao'=>true,'sanitiza'=>array(F3Base_Servicos::class,'booleano'));
        $c['f3base_clarity_project_id']=array('rotulo'=>'Projeto Microsoft Clarity','descricao'=>'ID público do projeto; vazio mantém o Clarity inativo. Carrega somente com medição permitida e fora de testes. O script pode aumentar trabalho e tráfego; confira CSP e qualidade em uma amostra real. O token de exportação é separado.','impacto'=>'Oferece mapas e gravações no fornecedor; não comprova identificação de pessoas.','exemplo'=>'Copie somente o ID exibido pelo projeto Clarity.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'texto','padrao'=>'','sanitiza'=>static fn($v)=>is_string($v)?trim($v):'','recusa'=>static fn($v)=>is_string($v)&&preg_match('/^[a-z0-9]{0,32}$/D',$v)?'':'Informe um ID Clarity de até 32 letras minúsculas e dígitos.');
        $c['f3base_confirmacao_hosts']=array('rotulo'=>'Hosts externos de confirmação autorizados','descricao'=>'Um host por linha, sem esquema ou caminho. Só HTTPS; vazio permite somente este site. Páginas externas para conteúdo/WhatsApp devem exibir o link temporário recebido em f3base_continuar.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'linhas','padrao'=>array(),'sanitiza'=>static fn($v)=>is_array($v)?array_values(array_unique(array_map('strtolower',$v))):array(),'recusa'=>static function($v){if(!is_array($v)||count($v)>20){return 'Informe até 20 hosts.';}foreach($v as $host){if(!is_string($host)||!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/iD',$host)){return 'Informe hosts completos sem caminho.';}}return '';});
        return F3Base_Meta_Transporte::catalogo(F3Base_Clarity::catalogo($c));
    }
    /** Mescla somente propriedades ausentes. Listas e valores explicitamente falsos são atômicos. */
    public static function completar($atual,$padrao){
        if(!is_array($atual)||!is_array($padrao)||array_is_list($padrao)){return $atual;}
        foreach($padrao as $k=>$v){if(!array_key_exists($k,$atual)){$atual[$k]=$v;}else{$atual[$k]=self::completar($atual[$k],$v);}}return $atual;
    }
    public static function importar_avisos(): bool {
        $fontes=array('1.22.1'=>get_option('f3base_release_1221',array())['avisos_padroes']??array(),'1.23.0'=>get_option('f3base_release_1230',array())['avisos_padroes']??array(),F3BASE_PLUGIN_VERSAO=>get_option(F3Base_Instalacao::OPTION,array())['avisos_padroes']??array());
        $latest=array();foreach($fontes as $origem=>$lista){foreach((array)$lista as $nome=>$v){$latest[$nome]=array($origem,$v);}}
        $save=F3Base_Options::atualizar_estado('f3base_configuracao_avisos',static function($s)use($latest){foreach($latest as $nome=>[$origem,$v]){
            $novo=array('nome'=>$nome,'motivo'=>sanitize_text_field((string)(is_array($v)?($v['motivo']??'configuracao_pendente'):$v)),'subchave'=>is_array($v)?($v['subchave']??null):null,'origem'=>$origem,'acao'=>'Revise o campo indicado e grave a opção. O aviso sai quando a opção aceitar os padrões.');
            $novo['assinatura_origem']=hash('sha256',wp_json_encode(array($origem,$v)));$prev=is_array($s[$nome]??null)?$s[$nome]:array();$mesmo=($prev['assinatura_origem']??'')===$novo['assinatura_origem'];
            $s[$nome]=$novo+($mesmo?array_intersect_key($prev,array_flip(array('importado_em','dispensado_em','dispensado_por'))):array())+array('importado_em'=>time());$s[$nome]['ativo']=empty($s[$nome]['dispensado_em']);}return $s;});
        if(empty($save['persisted'])){return false;}self::reavaliar_avisos();return true;
    }
    public static function reavaliar_avisos(): void {
        if(self::$reavaliando){return;}self::$reavaliando=true;
        try{$fim=array();foreach(self::avisos() as $nome=>$a){$d=F3Base_Options::declaracao((string)$nome);
            if(!$d||!array_key_exists('padrao',$d)){$fim[$nome]=array('ativo'=>false,'resolvido_em'=>time(),'resolucao'=>'opcao_fora_do_catalogo');continue;}
            $r=F3Base_Options::complementar_padrao((string)$nome,$d['padrao'],F3BASE_PLUGIN_VERSAO);
            if(!empty($r['ok'])&&!empty($r['persisted'])){$fim[$nome]=array('ativo'=>false,'resolvido_em'=>time(),'resolucao'=>$r['codigo']??'completa');}
            elseif(($r['codigo']??'')==='valor_recusado'){$fim[$nome]=array('motivo'=>sanitize_text_field((string)($r['motivo']??'valor_recusado')),'subchave'=>explode(':',(string)($r['motivo']??''))[0],'reavaliado_em'=>time());}}
            if($fim){F3Base_Options::atualizar_estado('f3base_configuracao_avisos',static function($s)use($fim){foreach($fim as $n=>$patch){if(isset($s[$n])){$s[$n]=array_merge($s[$n],$patch);}}return $s;});}
        }finally{self::$reavaliando=false;}
    }
    public static function dispensar_aviso(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$nome=(string)($e['nome']??'');
        $r=F3Base_Options::atualizar_estado('f3base_configuracao_avisos',static function($s)use($nome){if(empty($s[$nome]['ativo'])){return null;}$s[$nome]['ativo']=false;$s[$nome]['dispensado_em']=time();$s[$nome]['dispensado_por']=get_current_user_id();return $s;});return array('ok'=>!empty($r['persisted']),'persisted'=>!empty($r['persisted']),'codigo'=>!empty($r['persisted'])?'aviso_dispensado':'aviso_inexistente_ou_inativo');
    }
    public static function avisos(): array {return array_filter((array)get_option('f3base_configuracao_avisos',array()),static fn($v)=>is_array($v)&&!empty($v['ativo']));}
    public static function avisos_html(string $nome=''): void {
        foreach(self::avisos() as $a){if($nome!==''&&($a['nome']??'')!==$nome){continue;}echo '<div class="notice notice-warning"><p>'.esc_html(($a['nome']??'').' — '.($a['motivo']??'').' '.($a['acao']??'')).'</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_aviso_dispensar"><input type="hidden" name="nome" value="'.esc_attr($a['nome']).'">';wp_nonce_field('f3base-aviso-dispensar');submit_button('Dispensar este aviso','secondary','submit',false);echo '</form></div>';}
    }
    public static function materializar_padroes(): array {
        $alteradas=array();$preservadas=array();foreach(F3Base_Options::catalogo() as $n=>$d){
            if(empty($d['operavel'])||!empty($d['estado_execucao'])||!empty($d['derivada'])||F3Base_Options::e_segredo($n)||!array_key_exists('padrao',$d)){continue;}
            $f=F3Base_Options::fotografia_bruta($n);if($f['erro']){return array('ok'=>false,'codigo'=>'padroes_leitura_falhou','nome'=>$n);}
            $v=$f['existe']?self::completar($f['valor'],$d['padrao']):$d['padrao'];
            
            $r=F3Base_Options::complementar_padrao($n,$d['padrao'],F3BASE_PLUGIN_VERSAO);
            if(empty($r['persisted'])&&$f['existe']&&($r['codigo']??'')==='valor_recusado'){$preservadas[$n]=array('nome'=>$n,'motivo'=>sanitize_text_field($r['motivo']??$r['codigo']),'subchave'=>explode(':',(string)($r['motivo']??''))[0],'acao'=>'Revise somente o campo indicado; a escolha existente foi preservada.');continue;}
            if(empty($r['persisted'])||empty($r['ok'])){return array('ok'=>false,'codigo'=>'padroes_pendentes','nome'=>$n,'motivo'=>$r['motivo']??$r['codigo']??'');}$alteradas[]=$n;
        }return array('ok'=>true,'alteradas'=>$alteradas,'preservadas_com_diagnostico'=>$preservadas);
    }
}
