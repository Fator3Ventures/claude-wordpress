<?php
/** Versioned analytical archive. Rolling windows are never added or subtracted. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Clarity_Acervo {
    const PARSER=1;
    const SANEAMENTO=1;
    const MAX_RESPOSTA=8388608;
    public static function tabela(string $s='clarity_coletas'): string {global $wpdb;return $wpdb->prefix.'f3base_'.$s;}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();
        dbDelta('CREATE TABLE '.self::tabela().' (
 id char(32) NOT NULL,
 projeto varchar(32) NOT NULL,
 chave char(64) NOT NULL,
 parametros text NOT NULL,
 origem varchar(16) NOT NULL,
 solicitado_em bigint(20) NOT NULL,
 recebido_em bigint(20) NOT NULL DEFAULT 0,
 duracao_ms bigint(20) NOT NULL DEFAULT 0,
 janela_dias smallint NOT NULL,
 inicio_nominal bigint(20) NOT NULL,
 fim_nominal bigint(20) NOT NULL,
 estado varchar(40) NOT NULL,
 http int NOT NULL DEFAULT 0,
 motivo varchar(80) NOT NULL DEFAULT \'\',
 resposta longblob NULL,
 sha256 char(64) NOT NULL DEFAULT \'\',
 saneamento int NOT NULL DEFAULT 1,
 parser int NOT NULL DEFAULT 0,
 bytes_brutos bigint(20) NOT NULL DEFAULT 0,
 bytes_comprimidos bigint(20) NOT NULL DEFAULT 0,
 cobertura longtext NOT NULL,
 PRIMARY KEY  (id),
 UNIQUE KEY execucao (projeto,chave),
 KEY periodo (projeto,solicitado_em,id),
 KEY qualidade (estado,solicitado_em)
) ENGINE=InnoDB '.$cc.';');
        if($wpdb->last_error){return false;}
        dbDelta('CREATE TABLE '.self::tabela('clarity').' (
 coleta char(32) NOT NULL,
 parser int NOT NULL,
 bloco int NOT NULL,
 linha int NOT NULL,
 metrica varchar(160) NOT NULL,
 dimensoes text NOT NULL,
 valores longtext NOT NULL,
 post_id bigint(20) NOT NULL DEFAULT 0,
 caminho varchar(190) NOT NULL DEFAULT \'\',
 estado varchar(40) NOT NULL,
 PRIMARY KEY  (coleta,parser,bloco,linha),
 KEY conteudo (post_id,coleta),
 KEY metrica (metrica,coleta)
) ENGINE=InnoDB '.$cc.';');
        return !$wpdb->last_error;
    }
    public static function url(string $url): string {
        $p=wp_parse_url($url);if(!$p||!in_array($p['scheme']??'',array('https','http'),true)||empty($p['host'])||!empty($p['user'])||!empty($p['pass'])){return '[url_removida]';}
        $path=$p['path']??'/';$decoded=rawurldecode($path);
        if(preg_match('~@|(?:^|/)(?:token|reset-password|private|privado)(?:/|$)|[a-f0-9]{32,}|[0-9]{9,}~i',$decoded)){return $p['scheme'].'://'.$p['host'].'/[caminho_removido]';}
        return substr($p['scheme'].'://'.$p['host'].(isset($p['port'])?':'.$p['port']:'').$path,0,2048);
    }
    public static function sanear($data,array &$removidos=array(),int $depth=0,string $key='') {
        if($depth>16){$removidos['profundidade']=($removidos['profundidade']??0)+1;return null;}
        if(preg_match('/(?:token|secret|authorization|cookie|password|email|phone|telephone|ipaddress|clientip|userid|sessionid|visitorid|recording|person|fullname|firstName|lastName)/i',$key)){$removidos['campo_pessoal_ou_secreto']=($removidos['campo_pessoal_ou_secreto']??0)+1;return null;}
        if(is_array($data)){$out=array();foreach($data as $k=>$v){if(!is_int($k)&&(!is_string($k)||strlen($k)>160||!preg_match('~^[\p{L}\p{N} _/().%-]+$~u',$k))){$removidos['chave_invalida']=($removidos['chave_invalida']??0)+1;continue;}$value=self::sanear($v,$removidos,$depth+1,(string)$k);$out[$k]=$value;}return $out;}
        if(is_string($data)){
            if(strlen($data)>4096){$removidos['texto_longo']=($removidos['texto_longo']??0)+1;return null;}
            if(is_numeric($data)){return $data;}
            if(preg_match('~^https?://~i',$data)){return self::url($data);}
            if(preg_match('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|Bearer\s|\b(?:\d{1,3}\.){3}\d{1,3}\b|\b\d{11,}\b/i',$data)){$removidos['texto_pessoal']=($removidos['texto_pessoal']??0)+1;return null;}
            return wp_check_invalid_utf8($data,true);
        }
        return is_int($data)||is_float($data)||is_bool($data)||$data===null?$data:null;
    }
    public static function receber(string $id,array $body,int $http,int $recebido,int $ms): array {
        global $wpdb;$removidos=array();$safe=self::sanear($body,$removidos);$json=wp_json_encode($safe,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json)||strlen($json)>self::MAX_RESPOSTA){return array('ok'=>false,'codigo'=>'resposta_excede_arquivo');}
        $gzip=gzencode($json,6);if($gzip===false){return array('ok'=>false,'codigo'=>'compressao_falhou');}
        $hash=hash('sha256',$json);$record=array('recebido_em'=>$recebido,'duracao_ms'=>$ms,'http'=>$http,'estado'=>'resposta_preservada','resposta'=>$gzip,'sha256'=>$hash,'bytes_brutos'=>strlen($json),'bytes_comprimidos'=>strlen($gzip),'cobertura'=>wp_json_encode(array('removidos'=>$removidos,'precisao'=>'janela_nominal_ao_instante_da_consulta','ausencia_nao_zero'=>true)));
        // Journal only the already sanitized analytical response. Never a token/error body.
        $root=F3Base_Arquivos_Privados::raiz(true);$path=$root?$root.'/clarity-'.$id.'.json':'';$journal=$record;$journal['resposta']=base64_encode($gzip);
        if(!$path||!preg_match('/^[a-f0-9]{32}$/D',$id)||disk_free_space($root)<strlen($gzip)*3+1048576||is_link($path)){return array('ok'=>false,'codigo'=>'espaco_ou_journal_indisponivel');}
        $tmp=$path.'.'.bin2hex(random_bytes(8));$written=file_put_contents($tmp,wp_json_encode($journal),LOCK_EX);
        if($written===false||!chmod($tmp,0600)||!rename($tmp,$path)){@unlink($tmp);return array('ok'=>false,'codigo'=>'journal_falhou');}
        if(false===$wpdb->update(self::tabela(),$record,array('id'=>$id))){return array('ok'=>false,'codigo'=>'resposta_em_recuperacao','coleta'=>$id);}
        @unlink($path);return self::normalizar($id);
    }
    public static function recuperar(): array {
        global $wpdb;$root=F3Base_Arquivos_Privados::raiz();$ok=0;$falhas=0;if(!$root){return array('recuperadas'=>0,'pendentes'=>0);}
        foreach(array_slice(glob($root.'/clarity-*.json')?:array(),0,20) as $path){if(is_link($path)||!preg_match('/^clarity-([a-f0-9]{32})\.json$/D',basename($path),$m)||filesize($path)>self::MAX_RESPOSTA*2){continue;}
            $r=json_decode((string)file_get_contents($path),true);$row=self::obter($m[1]);$gzip=base64_decode($r['resposta']??'',true);$json=$gzip!==false?gzdecode($gzip,self::MAX_RESPOSTA):false;
            if(!$row||!$json||!hash_equals((string)($r['sha256']??''),hash('sha256',$json))){++$falhas;continue;}
            $allowed=array_intersect_key($r,array_flip(array('recebido_em','duracao_ms','http','estado','sha256','bytes_brutos','bytes_comprimidos','cobertura')));$allowed['resposta']=$gzip;
            if(false!==$wpdb->update(self::tabela(),$allowed,array('id'=>$m[1]))){@unlink($path);self::normalizar($m[1]);++$ok;}else{++$falhas;}
        }return array('recuperadas'=>$ok,'pendentes'=>$falhas);
    }
    public static function obter(string $id): ?array {global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s',self::tabela(),$id),ARRAY_A)?:null;}
    public static function resposta(array $r): ?array {
        $json=!empty($r['resposta'])?gzdecode($r['resposta'],self::MAX_RESPOSTA):false;if(!$json||!hash_equals($r['sha256'],hash('sha256',$json))){return null;}
        $body=json_decode($json,true);return is_array($body)?$body:null;
    }
    public static function normalizar(string $id): array {
        global $wpdb;$r=self::obter($id);if(!$r){return array('ok'=>false,'codigo'=>'coleta_ausente');}$body=self::resposta($r);if($body===null){return array('ok'=>false,'codigo'=>'integridade_resposta_falhou');}
        $params=json_decode($r['parametros'],true);$coverage=json_decode($r['cobertura'],true)?:array();$rows=array();$blocks=array();$compatible=array_is_list($body);$truncated=false;
        foreach($body as $bi=>$block){if(!is_array($block)||!is_string($block['metricName']??null)||!is_array($block['information']??null)){$compatible=false;continue;}
            $metric=mb_substr($block['metricName'],0,160);$n=count($block['information']);$blocks[]=array('metrica'=>$metric,'linhas'=>$n);if($n>=1000){$truncated=true;}
            foreach($block['information'] as $li=>$info){if(!is_array($info)){$compatible=false;continue;}$dims=array();foreach(F3Base_Clarity::DIMENSOES as $key){if(array_key_exists($key,$info)){$dims[$key]=$info[$key];}}
                $url=$info['URL']??$info['url']??'';$local=is_string($url)&&wp_parse_url($url,PHP_URL_HOST)===wp_parse_url(home_url(),PHP_URL_HOST);$c=$local?F3Base_Editorial::resolver($url,(int)$r['recebido_em']):array();
                $rows[]=array('coleta'=>$id,'parser'=>self::PARSER,'bloco'=>(int)$bi,'linha'=>(int)$li,'metrica'=>$metric,'dimensoes'=>wp_json_encode($dims),'valores'=>wp_json_encode($info,JSON_PRESERVE_ZERO_FRACTION),'post_id'=>$c['post_id']??0,'caminho'=>$local?F3Base_Editorial::caminho($url):'','estado'=>'observado');
            }
        }
        $estado=!$compatible?'esquema_incompativel':($truncated?'possivelmente_truncada':'resposta_disponivel');$coverage+=array('blocos'=>$blocks,'recorte_solicitado'=>$params['dimensoes']??array());$coverage['blocos']=$blocks;$coverage['soma_permitida']=false;
        if(false===$wpdb->query('START TRANSACTION')){return array('ok'=>false,'codigo'=>'normalizacao_pendente');}
        try {
            if(false===$wpdb->delete(self::tabela('clarity'),array('coleta'=>$id,'parser'=>self::PARSER))){throw new RuntimeException('clarity_persistencia_falhou');}
            foreach($rows as $row){if(false===$wpdb->insert(self::tabela('clarity'),$row)){throw new RuntimeException('clarity_persistencia_falhou');}}
            if(false===$wpdb->update(self::tabela(),array('parser'=>self::PARSER,'estado'=>$estado,'cobertura'=>wp_json_encode($coverage)),array('id'=>$id))||false===$wpdb->query('COMMIT')){throw new RuntimeException('clarity_persistencia_falhou');}
            return array('ok'=>true,'coleta'=>$id,'estado'=>$estado,'linhas'=>count($rows),'sha256'=>$r['sha256'],'parser'=>self::PARSER);
        }catch(Throwable $ex){$wpdb->query('ROLLBACK');return array('ok'=>false,'codigo'=>'normalizacao_pendente','coleta'=>$id);}
    }
    public static function meta(array $r): array {unset($r['resposta']);$r['parametros']=json_decode($r['parametros'],true);$r['cobertura']=json_decode($r['cobertura'],true);$r['precisao_temporal']='nominal: fim entre solicitação e recebimento; não são dias civis isolados';return $r;}
    public static function ler(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        global $wpdb;$modo=$e['modo']??'resumo';$project=$e['projeto']??F3Base_Options::ler('f3base_clarity_project_id');$pag=max(1,(int)($e['pagina']??1));$lim=max(1,min(100,(int)($e['limite']??25)));$offset=($pag-1)*$lim;
        if(!preg_match('/^[a-z0-9]{0,32}$/D',$project)){return array('ok'=>false,'codigo'=>'projeto_invalido');}
        $where=$wpdb->prepare('projeto=%s',$project);foreach(array('de'=>'>=','ate'=>'<=') as $k=>$op){if(isset($e[$k])){$d=DateTimeImmutable::createFromFormat('!Y-m-d',$e[$k],new DateTimeZone('UTC'));if(!$d||$d->format('Y-m-d')!==$e[$k]){return array('ok'=>false,'codigo'=>'periodo_invalido');}$where.=$wpdb->prepare(' AND solicitado_em'.$op.'%d',$d->getTimestamp()+($k==='ate'?DAY_IN_SECONDS-1:0));}}
        $out=array('ok'=>true,'projeto'=>$project,'modo'=>$modo,'regra'=>'consultas_moveis-1','fuso'=>'UTC','retencao_meses'=>F3Base_Options::ler('f3base_clarity')['retencao_meses']??0,'aviso'=>'Consultas sobrepostas não são parcelas somáveis. Ausência de linha não é zero; janelas nominais não recuperam dias exatos.','cron'=>array('proxima'=>wp_next_scheduled(F3Base_Clarity::EVENTO)?:null,'continuacao'=>wp_next_scheduled('f3base_clarity_retomar')?:null,'limite'=>'WP-Cron precisa de executor e pode atrasar'),'cota'=>F3Base_Clarity::orcamento($project));
        if(!empty($e['coleta'])){
            $r=self::obter($e['coleta']);if(!$r||$r['projeto']!==$project){return array('ok'=>false,'codigo'=>'coleta_ausente');}$out['coleta']=self::meta($r);
            if($modo==='resposta'){$body=self::resposta($r);if($body===null){return array('ok'=>false,'codigo'=>'resposta_indisponivel');}$out['resposta']=array_slice($body,$offset,$lim,true);$out['proxima_pagina']=$offset+$lim<count($body)?$pag+1:null;return $out;}
            $rows=$wpdb->get_results($wpdb->prepare('SELECT bloco,linha,metrica,dimensoes,valores,post_id,caminho,estado FROM %i WHERE coleta=%s AND parser=%d ORDER BY bloco,linha LIMIT %d OFFSET %d',self::tabela('clarity'),$r['id'],$r['parser'],$lim+1,$offset),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}foreach($rows as &$row){$row['dimensoes']=json_decode($row['dimensoes'],true);$row['valores']=json_decode($row['valores'],true);}unset($row);$out['linhas']=array_slice($rows,0,$lim);$out['proxima_pagina']=count($rows)>$lim?$pag+1:null;$out['contexto_core']=self::contexto_core($r,$out['linhas']);return $out;
        }
        $cols='id,projeto,chave,parametros,origem,solicitado_em,recebido_em,duracao_ms,janela_dias,inicio_nominal,fim_nominal,estado,http,motivo,sha256,saneamento,parser,bytes_brutos,bytes_comprimidos,cobertura';
        $rows=$wpdb->get_results($wpdb->prepare('SELECT '.$cols.' FROM %i WHERE '.$where.' ORDER BY solicitado_em DESC,id DESC LIMIT %d OFFSET %d',self::tabela(),$lim+1,$offset),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'acervo_indisponivel');}$out['consultas']=array_map(array(__CLASS__,'meta'),array_slice($rows,0,$lim));$out['proxima_pagina']=count($rows)>$lim?$pag+1:null;
        $out['acervo']=$wpdb->get_row($wpdb->prepare('SELECT COUNT(*) consultas,MIN(solicitado_em) primeira,MAX(solicitado_em) ultima,SUM(bytes_comprimidos) bytes_respostas,SUM(CASE WHEN solicitado_em>=%d THEN bytes_comprimidos ELSE 0 END) crescimento_30_dias_bytes FROM %i WHERE projeto=%s',time()-30*DAY_IN_SECONDS,self::tabela(),$project),ARRAY_A);
        $out['cobertura_nominal']=self::cobertura($project,$where);return $out;
    }
    /** Coverage unions describe nominal windows, never an arithmetic total of metrics. */
    public static function cobertura(string $project,string $where): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT parametros,inicio_nominal,fim_nominal,solicitado_em,estado FROM %i WHERE '.$where.' ORDER BY inicio_nominal,fim_nominal LIMIT 20001',self::tabela()),ARRAY_A);
        if($wpdb->last_error||count($rows)>20000){return array('estado'=>'reduza_periodo','grupos'=>array());}$groups=array();
        foreach($rows as $r){$p=json_decode($r['parametros'],true);$key=wp_json_encode($p);$g=&$groups[$key];if(!$g){$g=array('parametros'=>$p,'janelas_nominais'=>array(),'falhas_ou_parciais'=>array(),'lacunas_nominais'=>array());}if($r['estado']==='resposta_disponivel'){$g['janelas_nominais'][]=array((int)$r['inicio_nominal'],(int)$r['fim_nominal']);}else{$g['falhas_ou_parciais'][]=array('solicitado_em'=>(int)$r['solicitado_em'],'estado'=>$r['estado']);}unset($g);}
        foreach($groups as &$g){$union=array();foreach($g['janelas_nominais'] as $w){$last=count($union)-1;if($last>=0&&$w[0]<=$union[$last][1]){$union[$last][1]=max($union[$last][1],$w[1]);}else{if($last>=0){$g['lacunas_nominais'][]=array($union[$last][1],$w[0]);}$union[]=$w;}}$g['janelas_nominais']=$union;}unset($g);
        return array('estado'=>'observada','grupos'=>array_values($groups),'limite'=>'União nominal somente entre consultas completas do mesmo recorte. Não prova cobertura diária exata, completude do fornecedor ou recuperação de dados antes/depois da primeira/última consulta.');
    }
    public static function comparar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$a=self::obter($e['anterior']??'');$b=self::obter($e['atual']??'');if(!$a||!$b){return array('ok'=>false,'codigo'=>'consulta_ausente');}
        $ok=$a['projeto']===$b['projeto']&&$a['parametros']===$b['parametros']&&$a['parser']===$b['parser']&&$a['saneamento']===$b['saneamento']&&$a['estado']==='resposta_disponivel'&&$b['estado']==='resposta_disponivel'&&$a['id']!==$b['id'];
        if(!$ok){return array('ok'=>false,'codigo'=>'recortes_incompativeis','anterior'=>self::meta($a),'atual'=>self::meta($b));}
        $overlap=max((int)$a['inicio_nominal'],(int)$b['inicio_nominal'])<min((int)$a['fim_nominal'],(int)$b['fim_nominal']);
        $pa=max(1,(int)($e['pagina']??1));$left=self::ler(array('projeto'=>$a['projeto'],'coleta'=>$a['id'],'pagina'=>$pa,'limite'=>100));$right=self::ler(array('projeto'=>$b['projeto'],'coleta'=>$b['id'],'pagina'=>$pa,'limite'=>100));
        return array('ok'=>true,'anterior'=>$left,'atual'=>$right,'janelas_sobrepostas'=>$overlap,'comparacao'=>'Dois recortes completos do mesmo projeto, parâmetros e parser. Linhas não são pareadas pela posição; use metrica + dimensoes. Nunca subtrair para inventar dias isolados nem somar como total mensal.');
    }
    public static function contexto_core(array $coleta,array $rows): array {
        global $wpdb;$paths=array_values(array_unique(array_filter(array_column($rows,'caminho'))));if(!$paths){return array();}$ph=implode(',',array_fill(0,count($paths),'%s'));$start=(int)$coleta['inicio_nominal'];$end=(int)$coleta['fim_nominal'];
        $data=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE criado_em>=%d AND criado_em<%d AND caminho IN ('.$ph.') ORDER BY criado_em LIMIT 30001',array_merge(array(F3Base_Analise::tabela(),$start,$end),$paths)),ARRAY_A);if($wpdb->last_error||count($data)>30000){return array('estado'=>'reduza_recorte');}
        $data=F3Base_Editorial_Relatorios::observacoes($data,array('de'=>wp_date('Y-m-d',$start),'ate'=>wp_date('Y-m-d',$end),'segmento'=>'sem_testes','automacao'=>'audiencia'));$map=array();foreach($paths as $path){$map[$path]=array('caminho'=>$path,'visualizacoes'=>array(),'sessoes'=>array(),'sessoes_origem_ia'=>array(),'formularios_iniciados'=>0,'envios_aceitos'=>0,'tempo_ativo_ms'=>0,'secoes_vistas'=>0);}
        $nav=array();foreach($data as $r){if($r['tipo']==='pagina'){$map[$r['caminho']]['visualizacoes'][$r['sessao'].'|'.$r['navegacao']]=true;$map[$r['caminho']]['sessoes'][$r['sessao']]=true;if(($r['canal']??'')==='ia'){$map[$r['caminho']]['sessoes_origem_ia'][$r['sessao']]=true;}$nav[$r['sessao'].'|'.$r['navegacao']]=$r['caminho'];}elseif($r['tipo']==='form_inicio'){$map[$r['caminho']]['formularios_iniciados']++;}}
        $events=$wpdb->get_results($wpdb->prepare('SELECT sessao,navegacao,caminho,metrica,valor FROM %i WHERE criado_em>=%d AND criado_em<%d AND classe_trafego<>%s AND caminho IN ('.$ph.') LIMIT 30001',array_merge(array(F3Base_Modulo_Comportamento::nome_tabela_eventos(),$start,$end,'teste'),$paths)),ARRAY_A);if(count($events)>30000||$wpdb->last_error){return array('estado'=>'reduza_recorte');}foreach($events as $r){if(($nav[$r['sessao'].'|'.$r['navegacao']]??'')!==$r['caminho']){continue;}if($r['metrica']==='f3base_tempo_ativo'){$map[$r['caminho']]['tempo_ativo_ms']+=(float)$r['valor'];}if($r['metrica']==='f3base_secao_vista'){$map[$r['caminho']]['secoes_vistas']++;}}
        $leads=$wpdb->get_results($wpdb->prepare("SELECT sessao,dados FROM %i WHERE criado_em>=%s AND criado_em<%s AND classe_trafego<>'teste' AND captura='aceito' AND atendimento<>'spam' AND lixeira=0 AND eliminacao_pendente=0 AND metodo IN ('formulario','whatsapp_formulario','conteudo') LIMIT 3001",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s',$start),gmdate('Y-m-d H:i:s',$end)),ARRAY_A);if(count($leads)>3000||$wpdb->last_error){return array('estado'=>'reduza_recorte');}foreach($leads as $l){$d=json_decode($l['dados'],true);$path=$nav[$l['sessao'].'|'.($d['navegacao']??'')]??'';if($path){$map[$path]['envios_aceitos']++;}}
        foreach($map as &$r){$r['visualizacoes']=count($r['visualizacoes']);$r['sessoes']=count($r['sessoes']);$r['sessoes_origem_ia']=count($r['sessoes_origem_ia']);}unset($r);
        return array('estado'=>'observado','inicio'=>$start,'fim'=>$end,'fonte'=>'Core; limites de instante iguais à janela nominal, sem juntar identidades de fornecedores','linhas'=>array_values($map),'limite'=>'Sem testes e sem sinais de automação. Brutos retidos apenas; períodos expirados não são reconstruídos. Segmentos Device/Channel do Clarity não são aplicados a estes totais por página.');
    }
    public static function exportar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $r=self::obter($e['coleta']);if(!$r||self::resposta($r)===null){return array('ok'=>false,'codigo'=>'fonte_indisponivel');}
        $meta=self::meta($r);return array('ok'=>true,'formato'=>'f3base-clarity-consulta-1','metadados'=>$meta,'resposta_gzip_base64'=>base64_encode($r['resposta']),'sha256'=>$r['sha256'],'semantica'=>'Uma consulta móvel original, sem adição entre janelas.');
    }
    public static function restaurar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $x=$e['arquivo']??array();$m=$x['metadados']??array();$b64=$x['resposta_gzip_base64']??'';
        if(($x['formato']??'')!=='f3base-clarity-consulta-1'||!is_string($b64)||strlen($b64)>12000000||!preg_match('/^[a-f0-9]{32}$/D',$m['id']??'')||!preg_match('/^[a-z0-9]{1,32}$/D',$m['projeto']??'')||!in_array((int)($m['janela_dias']??0),array(1,2,3),true)){return array('ok'=>false,'codigo'=>'arquivo_invalido');}
        foreach(array('solicitado_em','recebido_em','duracao_ms','inicio_nominal','fim_nominal') as $key){if(!isset($m[$key])||!is_numeric($m[$key])||(int)$m[$key]<0){return array('ok'=>false,'codigo'=>'metadados_invalidos');}}if((int)$m['fim_nominal']!==(int)$m['solicitado_em']||(int)$m['inicio_nominal']!==(int)$m['fim_nominal']-(int)$m['janela_dias']*DAY_IN_SECONDS||(int)$m['recebido_em']<(int)$m['solicitado_em']||(int)$m['solicitado_em']>time()+300){return array('ok'=>false,'codigo'=>'janela_invalida');}
        $gz=base64_decode($b64,true);$raw=$gz!==false?gzdecode($gz,self::MAX_RESPOSTA):false;$body=$raw!==false?json_decode($raw,true,32,JSON_BIGINT_AS_STRING):null;
        if(!is_array($body)||!hash_equals((string)($x['sha256']??''),hash('sha256',$raw))){return array('ok'=>false,'codigo'=>'hash_divergente');}
        $removed=array();$safe=wp_json_encode(self::sanear($body,$removed),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if($safe!==$raw){return array('ok'=>false,'codigo'=>'resposta_nao_sanitizada');}
        $old=self::obter($m['id']);if($old){return array('ok'=>$old['sha256']===$x['sha256']&&$old['projeto']===$m['projeto'],'codigo'=>'coleta_ja_existente','coleta'=>$m['id']);}
        $params=$m['parametros']??array();if(($params['dias']??0)!==(int)$m['janela_dias']||array_diff(array_keys($params),array('dias','dimensoes'))||!in_array($params['dias']??0,array(1,2,3),true)||!is_array($params['dimensoes']??null)||count($params['dimensoes'])>3||array_diff($params['dimensoes'],F3Base_Clarity::DIMENSOES)){return array('ok'=>false,'codigo'=>'parametros_invalidos');}
        $removed=array();$coverage=self::sanear(is_array($m['cobertura']??null)?$m['cobertura']:array(),$removed);$coverage['restaurada_em']=time();$coverage['precisao']='nominal';
        $row=array('id'=>$m['id'],'projeto'=>$m['projeto'],'chave'=>hash('sha256','restaurada|'.$m['id']),'parametros'=>wp_json_encode($params),'origem'=>'restauracao','solicitado_em'=>(int)$m['solicitado_em'],'recebido_em'=>(int)$m['recebido_em'],'duracao_ms'=>(int)$m['duracao_ms'],'janela_dias'=>(int)$m['janela_dias'],'inicio_nominal'=>(int)$m['inicio_nominal'],'fim_nominal'=>(int)$m['fim_nominal'],'estado'=>'resposta_preservada','http'=>200,'resposta'=>$gz,'sha256'=>$x['sha256'],'bytes_brutos'=>strlen($raw),'bytes_comprimidos'=>strlen($gz),'cobertura'=>wp_json_encode($coverage));
        global $wpdb;if(!$wpdb->insert(self::tabela(),$row)){return array('ok'=>false,'codigo'=>'restauracao_falhou');}return self::normalizar($m['id']);
    }
    public static function reter(): void {
        $months=(int)(F3Base_Options::ler('f3base_clarity')['retencao_meses']??0);if($months<=0){return;}
        global $wpdb;$cut=(new DateTimeImmutable('now',new DateTimeZone('UTC')))->modify('-'.$months.' months')->getTimestamp();$ids=$wpdb->get_col($wpdb->prepare('SELECT id FROM %i WHERE solicitado_em<%d ORDER BY solicitado_em LIMIT 100',self::tabela(),$cut));$n=0;
        foreach($ids as $id){$wpdb->query('START TRANSACTION');if(false===$wpdb->delete(self::tabela('clarity'),array('coleta'=>$id))||false===$wpdb->delete(self::tabela(),array('id'=>$id))){$wpdb->query('ROLLBACK');break;}if(false===$wpdb->query('COMMIT')){break;}++$n;}
        F3Base_Options::atualizar_estado('f3base_clarity_estado',static function($s)use($n,$cut){$s['limpeza']=array('em'=>time(),'consultas'=>$n,'corte'=>$cut);return $s;});
    }
}
