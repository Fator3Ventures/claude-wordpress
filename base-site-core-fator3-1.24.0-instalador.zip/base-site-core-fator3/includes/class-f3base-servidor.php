<?php
/** Managed Apache rules. All mutations require an explicit authenticated operation and a revision. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Servidor {
    const OPTION='f3base_servidor_estado';
    const BEGIN='# BEGIN F3BASE MANAGED';
    const END='# END F3BASE MANAGED';
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function():void {
            F3Base_Servicos::ability('servidor-aplicar','Consultar, aplicar ou remover somente as regras próprias do servidor, com revisão e restauração',array(__CLASS__,'executar'),array('acao'=>array('type'=>'string','enum'=>array('consultar','aplicar','remover')),'revisao_esperada'=>array('type'=>'string')),array(),false);
        });
        add_action('rest_api_init',static function():void {
            register_rest_route(F3BASE_REST_NAMESPACE,'/servidor-sonda',array('methods'=>'GET','permission_callback'=>'__return_true','callback'=>static function($r){
                $eco=(string)$r->get_param('eco'); if(!preg_match('/^[a-f0-9]{24}$/D',$eco)){return new WP_Error('sonda_invalida','Sonda inválida.',array('status'=>400));}
                $res=new WP_REST_Response(array('ok'=>true,'eco'=>$eco));$res->header('Cache-Control','no-store, private');$res->header('X-Robots-Tag','noindex, nofollow');return $res;
            }));
        });
    }
    private static function arquivo(): string {return dirname(F3Base_Llms_Arquivo::caminho()).'/.htaccess';}
    private static function ler(): ?string {
        $p=self::arquivo();if(is_link($p)|| (file_exists($p)&&(!is_file($p)||!is_readable($p)||filesize($p)>2097152))){return null;}
        return file_exists($p)?file_get_contents($p):'';
    }
    public static function revisao(): string {
        return hash('sha256',(string)self::ler().'|'.F3Base_Options::revisao('f3base_llms').'|'.F3Base_Options::revisao('f3base_servidor'));
    }
    public static function bloco(bool $remover=false): string {
        if($remover){return '';}$llms=F3Base_Options::ler('f3base_llms');$servidor=F3Base_Options::ler('f3base_servidor');$linhas=array();
        if(!empty($llms['cabecalhos_servidor'])&&!empty($llms['ligado'])&&($llms['entrega']??'')==='arquivo_gerado'){
            $linhas=array('<Files "llms.txt">','ForceType "text/plain; charset=utf-8"','<IfModule mod_expires.c>','ExpiresActive Off','</IfModule>','<IfModule mod_headers.c>','Header onsuccess unset Expires','Header always unset Expires','Header onsuccess unset Cache-Control','Header always set Cache-Control "no-cache, max-age=0, must-revalidate"','Header onsuccess unset X-Robots-Tag','Header always set X-Robots-Tag "'.(!empty($llms['indexavel'])?'index, follow':'noindex, follow').'"','</IfModule>','</Files>');
        }
        if(!empty($servidor['bloquear_listagem'])){$linhas[]='Options -Indexes';}
        return $linhas?self::BEGIN."\n".implode("\n",$linhas)."\n".self::END."\n":'';
    }
    public static function substituir(string $texto,string $bloco): ?string {
        $in=substr_count($texto,self::BEGIN);$out=substr_count($texto,self::END);
        if($in!==$out||$in>1){return null;}
        if($in){$alterado=preg_replace('~^'.preg_quote(self::BEGIN,'~').'\R.*?^'.preg_quote(self::END,'~').'(?:\R|$)~ms',$bloco,$texto,1,$quantidade);return $quantidade===1?$alterado:null;}
        return $bloco===''?$texto:($texto.($texto!==''&&!str_ends_with($texto,"\n")?"\n":'').$bloco);
    }
    public static function consultar(): array {
        $texto=self::ler();$estado=(array)get_option(self::OPTION,array());$aplicado=$texto!==null&&self::substituir($texto,self::bloco())===$texto;
        return array('ok'=>$texto!==null,'revisao'=>self::revisao(),'raiz'=>dirname(self::arquivo()),'arquivo'=>'.htaccess','suporte'=>stripos((string)($_SERVER['SERVER_SOFTWARE']??''),'apache')!==false?'apache':'nao_confirmado','gravavel'=>is_writable(dirname(self::arquivo()))&&($texto===''||is_writable(self::arquivo())),'preferencia_aplicada'=>$aplicado,'status'=>$aplicado?($estado['status']??'pendente_verificar'):'pendente_aplicar','ultima_operacao'=>$estado,'aplicacao_automatica_na_ativacao'=>false);
    }
    private static function gravar(string $texto,string $hash): bool {
        $p=self::arquivo();$atual=self::ler();if($atual===null||!hash_equals($hash,hash('sha256',$atual))){return false;}
        $tmp=tempnam(dirname($p),'.f3base-servidor-');if(!$tmp||dirname($tmp)!==dirname($p)){if($tmp){@unlink($tmp);}return false;}
        try{if(file_put_contents($tmp,$texto)!==strlen($texto)||!chmod($tmp,file_exists($p)?(fileperms($p)&0777):0644)){return false;}
            if(!hash_equals($hash,hash('sha256',(string)self::ler()))){return false;}return rename($tmp,$p);
        }finally{if(is_file($tmp)){@unlink($tmp);}}
    }
    private static function controles(bool $teste=false): array {
        $eco=bin2hex(random_bytes(12));$fim=microtime(true)+12;
        $home=F3Base_Http_Publico::buscar(home_url('/'),65536,$fim,'HEAD',F3Base_Testes::cabecalhos(home_url('/'),$teste));
        $url=add_query_arg(array('rest_route'=>'/'.F3BASE_REST_NAMESPACE.'/servidor-sonda','eco'=>$eco),home_url('/'));
        $php=F3Base_Http_Publico::buscar($url,4096,$fim,'GET',F3Base_Testes::cabecalhos($url,$teste));$body=json_decode($php['corpo']??'',true);
        return array('ok'=>($home['status']??0)===200&&($php['status']??0)===200&&($body['eco']??'')===$eco,'home_http'=>$home['status']??0,'php_http'=>$php['status']??0,'php_confirmado'=>($body['eco']??'')===$eco,'em'=>time());
    }
    /** Alvo público aleatório, sem dados privados, removido ao concluir a prova. */
    private static function verificar_listagem(bool $teste): array {
        $nome='f3base-sonda-index-'.bin2hex(random_bytes(12));$dir=dirname(self::arquivo()).'/'.$nome;$token=bin2hex(random_bytes(12));
        if(!mkdir($dir,0755)){return array('status'=>'pending','codigo'=>'diretorio_sonda_indisponivel');}
        try{
            if(file_put_contents($dir.'/controle.txt',$token)!==strlen($token)){return array('status'=>'pending','codigo'=>'arquivo_sonda_indisponivel');}
            $url=home_url('/'.$nome.'/');$fim=microtime(true)+8;
            $controle=F3Base_Http_Publico::buscar($url.'controle.txt',1024,$fim,'GET',F3Base_Testes::cabecalhos($url,$teste),false);
            $lista=F3Base_Http_Publico::buscar($url,65536,$fim,'GET',F3Base_Testes::cabecalhos($url,$teste),false);
            $ok=($controle['status']??0)===200&&($controle['corpo']??'')===$token&&($lista['status']??0)===403;
            return array('status'=>$ok?'verified':'pending','codigo'=>$ok?'listagem_negada_com_controle_publico':'listagem_nao_comprovada','controle_http'=>$controle['status']??0,'diretorio_http'=>$lista['status']??0,'em'=>time());
        }finally{if(is_file($dir.'/controle.txt')){unlink($dir.'/controle.txt');}rmdir($dir);}
    }
    public static function executar(array $v=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $marca=F3Base_Testes::resolver($v);if(!$marca['ok']){return $marca;}
        $acao=$v['acao']??'consultar';if($acao==='consultar'){return self::consultar();}
        if(!in_array($acao,array('aplicar','remover'),true)){return array('ok'=>false,'codigo'=>'acao_invalida');}
        if(!hash_equals(self::revisao(),(string)($v['revisao_esperada']??''))){return array('ok'=>false,'codigo'=>'revisao_divergente');}
        if(stripos((string)($_SERVER['SERVER_SOFTWARE']??''),'apache')===false){return array('ok'=>false,'codigo'=>'servidor_nao_suportado','motivo'=>'Aplicação exige Apache confirmado. Em Nginx configure regras equivalentes no servidor.');}
        $trava=@fopen(get_temp_dir().'f3base-servidor-'.hash('sha256',self::arquivo()).'.lock','c');
        if(!$trava||!flock($trava,LOCK_EX|LOCK_NB)){if($trava){fclose($trava);}return array('ok'=>false,'codigo'=>'operacao_em_andamento');}
        try {
        $texto=self::ler();if($texto===null||!is_writable(dirname(self::arquivo()))){return array('ok'=>false,'codigo'=>'arquivo_indisponivel');}
        $novo=self::substituir($texto,self::bloco($acao==='remover'));if($novo===null){return array('ok'=>false,'codigo'=>'marcadores_inconsistentes');}
        $estado=(array)get_option(self::OPTION,array());
        if(preg_match('~^'.preg_quote(self::BEGIN,'~').'\R.*?^'.preg_quote(self::END,'~').'(?:\R|$)~ms',$texto,$match)&&(empty($estado['bloco_sha256'])||!hash_equals($estado['bloco_sha256'],hash('sha256',$match[0])))){return array('ok'=>false,'codigo'=>'bloco_alterado_externamente');}
        $root=F3Base_Arquivos_Privados::raiz(true);if(!$root){return array('ok'=>false,'codigo'=>'backup_privado_indisponivel');}
        $controle=self::controles($marca['contexto_teste']);if(!$controle['ok']){return array('ok'=>false,'codigo'=>'controle_previo_inconclusivo','controle'=>$controle);}
        $id=bin2hex(random_bytes(16));$hash=hash('sha256',$texto);$next=hash('sha256',$novo);$backup=$root.'/servidor-'.$id.'.json';
        $doc=array('arquivo'=>self::arquivo(),'anterior_base64'=>base64_encode($texto),'anterior_sha256'=>$hash,'aplicado_sha256'=>$next,'em'=>time());
        if(file_put_contents($backup,wp_json_encode($doc),LOCK_EX)===false||!chmod($backup,0600)){return array('ok'=>false,'codigo'=>'backup_falhou');}
        // Independent CLI recovery remains available even if Apache cannot start PHP.
        $recovery=$root.'/recuperar-servidor.php';$script= <<<'RECOVERY'
<?php
if(PHP_SAPI!=='cli'||!preg_match('/^[a-f0-9]{32}$/D',$argv[1]??'')){exit(2);}
$d=json_decode(file_get_contents(__DIR__.'/servidor-'.$argv[1].'.json'),true);$p=$d['arquivo'];$old=base64_decode($d['anterior_base64'],true);
if(is_link($p)||!hash_equals($d['aplicado_sha256'],hash_file('sha256',$p))||!hash_equals($d['anterior_sha256'],hash('sha256',$old))){fwrite(STDERR,"Conflito: arquivo preservado.\n");exit(3);}
$t=tempnam(dirname($p),'.f3base-restaurar-');if(file_put_contents($t,$old)!==strlen($old)||!chmod($t,fileperms($p)&0777)||!rename($t,$p)){@unlink($t);exit(4);}echo "Restaurado.\n";
RECOVERY;
        if(file_put_contents($recovery,$script,LOCK_EX)===false||!chmod($recovery,0600)){return array('ok'=>false,'codigo'=>'recuperacao_indisponivel');}
        $armado=false;register_shutdown_function(static function()use(&$armado,$texto,$next):void { $e=error_get_last();if($armado&&$e&&in_array($e['type'],array(E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR),true)){self::gravar($texto,$next);} });
        if(!hash_equals(self::revisao(),(string)$v['revisao_esperada'])||!self::gravar($novo,$hash)){return array('ok'=>false,'codigo'=>'escrita_concorrente_ou_recusada');}$armado=true;
        $depois=self::controles($marca['contexto_teste']);$r=array('ok'=>$depois['ok'],'codigo'=>'regras_aplicadas','classe_trafego'=>$marca['classe_trafego'],'status'=>'aplicado','operacao'=>$id,'em'=>time(),'controle_antes'=>$controle,'controle_depois'=>$depois,'bloco_sha256'=>hash('sha256',self::bloco($acao==='remover')),'recuperacao_cli'=>'php '.$recovery.' '.$id);
        if(!$depois['ok']){$r['restaurado']=self::gravar($texto,$next);$r['codigo']=$r['restaurado']?'regressao_restaurada':'regressao_com_conflito';$r['status']='falha';if($r['restaurado']){$r['bloco_sha256']=$estado['bloco_sha256']??'';}}
        else{
            $r['status']='verificado';
            if($acao==='aplicar'&&F3Base_Llms_Arquivo::ativo()){$r['verificacao']=F3Base_Llms_Arquivo::verificar_http($marca['contexto_teste']);if($r['verificacao']['status']!=='verified'){$r['status']='pendente_verificar';}}
            if($acao==='aplicar'&&!empty(F3Base_Options::ler('f3base_servidor')['bloquear_listagem'])){$r['listagem']=self::verificar_listagem($marca['contexto_teste']);if($r['listagem']['status']!=='verified'){$r['status']='pendente_verificar';}}
            $r['ok']=$r['status']==='verificado';
        }
        $armado=false;F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$r);return $r;
        } finally {flock($trava,LOCK_UN);fclose($trava);}
    }
}
