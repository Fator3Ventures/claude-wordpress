<?php
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Modulo_Integracoes extends F3Base_Modulo {
 public function id(): string {return 'integracoes-contatos';}
 public function nome(): string {return 'Pipedrive e formulários de anúncios';}
 public function descricao(): string {return 'Preserva contatos localmente e entrega ao CRM por fila. Importa Meta autorizada e recebe Google por webhook/chave ou reconciliação autenticada. Configuração em Contatos → Integrações; documentação em docs/PIPEDRIVE.md e docs/ORIGENS-ANUNCIOS.md. Integrações desligadas por padrão; nenhuma tag pública adicionada.';}
 public function hooks(): array {return array();}
 public function options_que_controlam(): array {return array_keys(F3Base_Integracoes::definicoes());}
 protected function calcular_estado(): array {$active=false;$pending=false;foreach(F3Base_Integracoes::definicoes() as $n=>$d){if(!empty(F3Base_Options::ler($n)['ativo'])){$active=true;}}if(!$active){return array('estado'=>self::INATIVO,'motivo'=>'Configure conta, credencial e formulários em Contatos → Integrações.');}$s=F3Base_Integracoes::diagnostico();if(!empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])&&($s['pipedrive']['estado']??'')!=='verificado'){$pending=true;}foreach(array('meta','google') as $o){if(!empty($s['anuncios'][$o]['configurada'])&&$s['anuncios'][$o]['cobertura']!=='observada'){$pending=true;}}return array('estado'=>$pending?self::DEGRADADO:self::ATIVO,'motivo'=>$pending?'Verificação ou execução pendente; confira integração e filas. Captura local permanece independente.':'Acesso e execução observados; consultar a fila para o resultado de cada contato.');}
}
