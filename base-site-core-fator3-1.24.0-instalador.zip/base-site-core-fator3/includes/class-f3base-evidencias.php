<?php
/** Read-only response projections. IDs identify exact stored content, not textual summaries. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Evidencias {
    public static function id(array $v): string {return hash('sha256',wp_json_encode($v));}
    public static function projetar(array $resposta): array {
        $tokens=array();$walk=static function($v)use(&$walk,&$tokens){if(!is_array($v)){return $v;}foreach($v as $k=>$item){
            if($k==='evidencias_tokens'&&is_array($item)){foreach($item as $id=>$prova){$tokens[$id]=$prova;}unset($v[$k]);continue;}
            if($k==='tokens'&&is_array($item)&&$item&&!isset($item['evidencia_ref'])){$id=self::id($item);$tokens[$id]=$item;$v[$k]=array('evidencia_ref'=>$id);}
            elseif(is_array($item)){$v[$k]=$walk($item);}
        }return $v;};
        $r=$walk($resposta);if($tokens){$r['evidencias_tokens']=$tokens;}$r['contrato_evidencias']=2;return $r;
    }
    public static function consultar(string $id): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $v=F3Base_Cache_Evidencia::ler();$candidates=array(F3Base_Cache_Pagina::prova(),$v['ultima_tentativa']??array(),$v['ultimo_sucesso']??array());
        foreach($candidates as $p){if($p&&hash_equals(self::id($p),$id)){$valida=($p['geracao']??'')===(F3Base_Cache_Pagina::estado()['geracao']??'')&&(int)($p['checked_at']??$p['em']??0)>=time()-F3Base_Cache_Pagina::VALIDADE;
            return self::projetar(array('ok'=>true,'codigo'=>$valida?'evidencia_disponivel':'evidencia_expirada','evidencia_id'=>$id,'expirada'=>!$valida,'persisted'=>true,'evidencia'=>$p,'configuracao_alterada'=>false));}}
        return array('ok'=>false,'codigo'=>'evidencia_ausente','evidencia_id'=>$id,'configuracao_alterada'=>false);
    }
    public static function verificacao(array $r,bool $compacto): array {
        $p=$r['cache']['evidencia']??array();
        if(isset($r['sonda'])&&empty($r['sonda']['persisted'])){$p=array();}
        $r['verificacao_publica']=isset($r['sonda'])?array_intersect_key($r['sonda'],array_flip(array('status','codigo','motivo','persisted','checked_at','retry_after'))):null;
        $r['codigo']=$r['codigo']??'consulta_atendida';$r['evidencia_id']=$p?self::id($p):null;
        $r['persisted']=isset($r['sonda'])?($r['sonda']['persisted']??false):(!empty($p)?true:null);
        $r['detalhe']=array('ability'=>'f3base/config-core-verificar','entrada'=>array('nome'=>$r['nome'],'acao'=>'consultar','evidencia_id'=>$r['evidencia_id']),'sem_sonda'=>true);
        if($compacto){$r=array_intersect_key($r,array_flip(array('ok','codigo','nome','revisao','existe_no_banco','verification','configuracao_alterada','efeito_repetido','efeito_cache','evidencia_id','persisted','detalhe','verificacao_publica')));}
        return self::projetar($r);
    }
}
