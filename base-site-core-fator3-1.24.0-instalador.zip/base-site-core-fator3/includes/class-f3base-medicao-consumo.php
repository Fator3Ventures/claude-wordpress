<?php
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Medicao_Consumo {
    public static function amostra(array $r): array {return array('duracao_ms'=>max(0,(int)$r['ms']),'visivel_ms'=>max(0,min((int)$r['ms'],(int)$r['valor'])),'profundidade_pct'=>max(0,min(100,(int)$r['detalhe'])));}
    public static function ultima(array &$samples,string $key,array $r): void {$s=self::amostra($r);if(!isset($samples[$key])||$s['duracao_ms']>=$samples[$key]['duracao_ms']){$samples[$key]=$s;}}
    public static function distribuicao(array $values): array {$out=array('menos_10s'=>0,'10_a_29s'=>0,'30_a_59s'=>0,'1_a_2min'=>0,'3min_ou_mais'=>0);foreach($values as $ms){$k=$ms<10000?'menos_10s':($ms<30000?'10_a_29s':($ms<60000?'30_a_59s':($ms<180000?'1_a_2min':'3min_ou_mais')));++$out[$k];}return $out;}
    public static function resumo(array $samples,int $aggregateN=0,float $aggregateVisible=0,float $aggregateElapsed=0): array {
        $v=array_column($samples,'visivel_ms');$d=array_column($samples,'duracao_ms');$n=count($v)+$aggregateN;
        return array('amostra_saida'=>$n,'amostra_saida_bruta'=>count($v),'tempo_visivel_total_ms'=>array_sum($v)+$aggregateVisible,'tempo_visivel_medio_ms'=>$n?(array_sum($v)+$aggregateVisible)/$n:null,'duracao_media_ms'=>$n?(array_sum($d)+$aggregateElapsed)/$n:null,'tempo_visivel_mediana_ms'=>$aggregateN?null:F3Base_Modulo_Comportamento::mediana($v),'duracao_mediana_ms'=>$aggregateN?null:F3Base_Modulo_Comportamento::mediana($d),'distribuicao_tempo_visivel'=>$aggregateN?null:self::distribuicao($v),'distribuicao_duracao'=>$aggregateN?null:self::distribuicao($d),'profundidade_saida_media_pct'=>$samples?array_sum(array_column($samples,'profundidade_pct'))/count($samples):null);
    }
    public static function quebras(array $sessions,array $leads=array()): array {
        $out=array();foreach(F3Base_Audiencia::DIMENSOES as $dim){$g=array();foreach($sessions as $s){$v=$s[$dim]??'';$g[$v]=$g[$v]??array('valor'=>$v,'rotulo'=>F3Base_Audiencia::rotulo_dimensao($dim,$v),'sessoes'=>0,'visualizacoes'=>0,'cliques'=>0,'envios'=>0);++$g[$v]['sessoes'];foreach(array('visualizacoes','cliques','envios') as $m){$g[$v][$m]+=(int)($s[$m]??0);}}
            foreach($leads as $l){$v=$l[$dim]??'';$g[$v]=$g[$v]??array('valor'=>$v,'rotulo'=>F3Base_Audiencia::rotulo_dimensao($dim,$v),'sessoes'=>0,'visualizacoes'=>0,'cliques'=>0,'envios'=>0);if(in_array($l['classe']??'',array('cliques','envios'),true)){++$g[$v][$l['classe']];}}
            $out[$dim]=array_values($g);
        }return $out;
    }
}
