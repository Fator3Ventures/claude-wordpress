<?php
/** Optional compatibility adapter; does not archive recordings or invoke the analytics API. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Clarity_Gravacoes {
    const COMMIT='1708e8d45f940dd9eb14dfc06d68d766a200ca1f';
    const ENDPOINT='https://clarity.microsoft.com/mcp/recordings/sample';
    const SORT=array('SessionStart_DESC','SessionStart_ASC','SessionDuration_ASC','SessionDuration_DESC','SessionClickCount_ASC','SessionClickCount_DESC','PageCount_ASC','PageCount_DESC');
    public static function schema(): array {
        return array('de'=>array('type'=>'string','format'=>'date-time'),'ate'=>array('type'=>'string','format'=>'date-time'),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>250),'ordenar'=>array('type'=>'string','enum'=>self::SORT),'url'=>array('type'=>'string','maxLength'=>2048),'dispositivo'=>array('type'=>'string','enum'=>array('Mobile','Tablet','PC','Email','Other')),'cliques_raiva'=>array('type'=>'boolean'),'cliques_mortos'=>array('type'=>'boolean'));
    }
    public static function registrar(): void {F3Base_Servicos::ability('clarity-gravacoes','Consultar amostra de links de gravações sob demanda; adaptador de compatibilidade, cota própria',array(__CLASS__,'consultar'),self::schema(),array('de','ate'),false);}
    public static function consultar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(is_wp_error(rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::schema(),'required'=>array('de','ate'))))){return array('ok'=>false,'codigo'=>'filtros_invalidos');}
        try{$a=new DateTimeImmutable($e['de']);$b=new DateTimeImmutable($e['ate']);}catch(Throwable $x){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        if($a>=$b||$b->getTimestamp()-$a->getTimestamp()>31*DAY_IN_SECONDS){return array('ok'=>false,'codigo'=>'periodo_maximo_31_dias');}
        if(!F3Base_Clarity::configurado()){return array('ok'=>false,'codigo'=>'projeto_ou_credencial_nao_vinculada');}
        $project=F3Base_Options::ler('f3base_clarity_project_id');$lock=F3Base_Trava::adquirir('clarity-gravacoes-'.$project,120);if(!$lock){return array('ok'=>false,'codigo'=>'consulta_em_andamento');}
        try {
            $filters=array('date'=>array('start'=>$a->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.v\Z'),'end'=>$b->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.v\Z')));
            if(isset($e['url'])){$url=F3Base_Clarity_Acervo::url($e['url']);if($url==='[url_removida]'||str_contains($url,'[caminho_removido]')){return array('ok'=>false,'codigo'=>'url_invalida');}$filters['visitedUrls']=array(array('url'=>$url,'operator'=>'isExactly'));}
            if(isset($e['dispositivo'])){$filters['deviceType']=array($e['dispositivo']);}foreach(array('cliques_raiva'=>'rageClickPresent','cliques_mortos'=>'deadClickPresent') as $k=>$f){if(isset($e[$k])){$filters[$f]=$e[$k];}}
            $budget=F3Base_Clarity::reservar_cota($project,false,'gravacoes');if(empty($budget['ok'])){return $budget;}
            $limit=(int)($e['limite']??100);$body=array('start'=>$filters['date']['start'],'end'=>$filters['date']['end'],'filters'=>$filters,'sortBy'=>array_search($e['ordenar']??'SessionStart_DESC',self::SORT,true),'count'=>$limit);
            $response=wp_safe_remote_post(self::ENDPOINT,array('timeout'=>20,'redirection'=>0,'limit_response_size'=>2097153,'headers'=>array('Authorization'=>'Bearer '.F3Base_Segredos::abrir('f3base_clarity_api_token'),'Content-Type'=>'application/json'),'body'=>wp_json_encode($body)));
            $http=is_wp_error($response)?0:(int)wp_remote_retrieve_response_code($response);if($http===429){F3Base_Clarity::limitar_remoto($project,$response,'gravacoes');}
            if($http!==200){return array('ok'=>false,'codigo'=>'adaptador_gravacoes_indisponivel','http'=>$http,'commit'=>self::COMMIT,'historico_preservado'=>true);}
            $text=wp_remote_retrieve_body($response);$json=strlen($text)<=2097152?json_decode($text,true,32):null;if(!is_array($json)){return array('ok'=>false,'codigo'=>'schema_gravacoes_incompativel');}
            $links=array();$walk=static function($v,int $depth=0)use(&$walk,&$links,$limit){if($depth>16||count($links)>=$limit||!is_array($v)){return;}foreach($v as $k=>$x){if(is_string($x)&&preg_match('~^https://clarity\.microsoft\.com/(?:projects/view/[a-z0-9]+/impressions|player|recordings)(?:[/?]|$)~i',$x)){$p=wp_parse_url($x);if(!$p||!empty($p['user'])||!empty($p['pass'])||!empty($p['port'])||strlen($x)>2048){continue;}$links[$x]=array('link'=>$x);foreach(array('duration','Duration','sessionDuration','SessionDuration','startTime','StartTime') as $field){if(isset($v[$field])&&(is_numeric($v[$field])||preg_match('/^\d{4}-\d{2}-\d{2}T[0-9:.Z+-]+$/D',(string)$v[$field]))){$links[$x][$field]=$v[$field];}}}elseif(is_array($x)){$walk($x,$depth+1);}if(count($links)>=$limit){break;}}};$walk($json);
            return array('ok'=>true,'estado'=>$links?'amostra_observada':'sem_links_reconhecidos','amostra'=>array_values($links),'total_retornado'=>count($links),'limite'=>$limit,'commit'=>self::COMMIT,'cota'=>$budget['cota'],'aviso'=>'Amostra, não contagem de sessões. Links exigem acesso ao Clarity; não são arquivados no Core. Ausência pode indicar incompatibilidade do adaptador. Homologação real pendente.');
        }finally{F3Base_Trava::liberar($lock);}
    }
}
