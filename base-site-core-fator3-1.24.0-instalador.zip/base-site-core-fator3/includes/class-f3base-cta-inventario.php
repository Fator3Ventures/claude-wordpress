<?php
/** Explicit bounded inspection of stored public content; never render or request pages. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Cta_Inventario {
 public static function iniciar(): void {add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('ctas-inventariar','Inspeciona lote de conteúdo salvo para CTAs com destino inválido, sem HTTP ou renderização',array(__CLASS__,'consultar'),array('apos_id'=>array('type'=>'integer','minimum'=>0),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>50)));});}
 public static function consultar(array $e=array()): array {
  global $wpdb;$limit=max(1,min(50,(int)($e['limite']??20)));$after=max(0,(int)($e['apos_id']??0));
  $rows=$wpdb->get_results($wpdb->prepare("SELECT ID,post_type,post_content FROM %i WHERE ID>%d AND post_status='publish' AND post_password='' AND post_type IN ('post','page','wp_template','wp_template_part','wp_block','wp_navigation') ORDER BY ID LIMIT %d",$wpdb->posts,$after,$limit+1),ARRAY_A);
  if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);$aliases=F3Base_Options::ler('f3base_contato')['classes_cta']??array();$classes=array_merge(array(F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA),is_array($aliases)?$aliases:array());$out=array();$truncated=array();$seen=0;
  foreach($rows as $row){$html=$row['post_content'];if(strlen($html)>262144){$truncated[]=(int)$row['ID'];$html=substr($html,0,262144);}$p=new WP_HTML_Tag_Processor($html);$parents=array();$tags=0;
   while($p->next_tag(array('tag_closers'=>'visit'))){if(++$tags>5000){$truncated[]=(int)$row['ID'];break;}$tag=$p->get_tag();if($p->is_tag_closer()){for($i=count($parents)-1;$i>=0;$i--){if($parents[$i]['tag']===$tag){$parents=array_slice($parents,0,$i);break;}}continue;}
    $marked=$p->get_attribute('data-f3base-lead')!==null;foreach($classes as $class){if(is_string($class)&&$p->has_class($class)){$marked=true;}}foreach($parents as $parent){$marked=$marked||$parent['marked'];}
    if($tag==='A'&&$marked){++$seen;$url=(string)($p->get_attribute('href')??'');if(!F3Base_Leads_Contexto::destino($url)['valido']){$parts=wp_parse_url($url);$out[]=array('post_id'=>(int)$row['ID'],'tipo'=>$row['post_type'],'destino_resumido'=>is_array($parts)?sanitize_text_field(substr(($parts['scheme']??'').':'.($parts['host']??'').($parts['path']??''),0,180)):'[inválido]','motivo'=>$url===''||str_starts_with($url,'#')?'destino_ausente_ou_ancora':'destino_nao_admitido');}}
    if(!in_array($tag,array('AREA','BASE','BR','COL','EMBED','HR','IMG','INPUT','LINK','META','PARAM','SOURCE','TRACK','WBR'),true)&&count($parents)<100){$parents[]=array('tag'=>$tag,'marked'=>$marked);}
   }
  }
  return array('ok'=>true,'linhas'=>$out,'itens_lidos'=>count($rows),'ctas_inspecionados'=>$seen,'proximo_apos_id'=>$more?(int)end($rows)['ID']:null,'itens_truncados'=>array_values(array_unique($truncated)),'cobertura'=>'Conteúdo HTML salvo e publicado, até 50 itens, 256 KiB e 5000 tags por item. Não renderiza blocos dinâmicos, shortcodes, tema PHP, menus clássicos ou conteúdo inserido por JavaScript. Não comprova o HTML entregue. Exemplos sem query, fragmento ou credenciais.');
 }
}
