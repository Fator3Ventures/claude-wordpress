<?php
/** Contato instrumentado e WhatsApp flutuante opcional. Menu e conteúdo pertencem ao layout. */
declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Comportamento do CTA de WhatsApp.
 */
final class F3Base_Modulo_Leads_Whatsapp extends F3Base_Modulo {

	/**
	 * Handle do script.
	 */
	public const HANDLE = 'f3base-leads';

	/**
	 * Atributo que marca um CTA de lead no HTML do tema.
	 */
	public const ATRIBUTO = 'data-f3base-lead';

	/**
	 * Atributo que este módulo carimba no `<a>` que ELE promoveu.
	 *
	 * O cliente lê este carimbo para saber que o `href` daquele link é do
	 * pacote: sem ele, o clique não toca no destino.
	 */
	public const ATRIBUTO_NUMERO = 'data-f3base-numero';

	/**
	 * CLASSE do CTA no markup do tema — o discriminante que não depende de nada.
	 *
	 * O atributo acima é carimbado pelo tema em `render_block`, e carimbar
	 * depende de `WP_HTML_Tag_Processor`. A classe está no ARQUIVO do pattern e
	 * existe sempre. É por ela que a decisão de PUBLICAR ou não o CTA é tomada:
	 * decidir pelo atributo deixaria o botão publicado justamente na instalação
	 * onde o processador não existe, que é o caso em que menos se quer surpresa.
	 */
	public const CLASSE_CTA = 'f3base-acao-contato';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'leads-whatsapp';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Contatos e WhatsApp', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Registra CTAs válidos pelo destino, inclusive links internos, telefone e e-mail, sem exigir WhatsApp configurado. O número de contato permite o WhatsApp flutuante opcional. Envia por fetch com confirmação e sendBeacon como reserva. Use f3base/ctas-inventariar para listar destinos rejeitados em lotes de conteúdo salvo, com cobertura explícita.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_footer',
				'metodo'     => 'flutuante',
				'prioridade' => 5,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_contato', 'f3base_atribuicao' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$numero = $this->numero();

		return array(
			array(
				'rotulo'   => __( 'Número de WhatsApp em f3base_contato', 'f3base' ),
				'presente' => '' !== $numero,
				'detalhe'  => '' !== $numero
					? __( 'destino do WhatsApp flutuante resolvido pela option; os demais CTAs independem deste número.', 'f3base' )
					: __( 'sem número o ícone flutuante não é publicado; os botões do tema seguem a definição do layout.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Slot de medição preenchido', 'f3base' ),
				'presente' => class_exists( 'F3Base_Modulo_Tracking' ) && F3Base_Modulo_Tracking::ha_slot_preenchido(),
				'detalhe'  => class_exists( 'F3Base_Modulo_Tracking' ) && F3Base_Modulo_Tracking::ha_slot_preenchido()
					? __( 'o clique do CTA é convertido nos canais declarados.', 'f3base' )
					: __( 'nenhum ID de GA4, Ads, Meta ou LinkedIn gravado: o clique é registrado no endpoint e não sai para canal nenhum.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Endpoint de registro de leads', 'f3base' ),
				'presente' => class_exists( 'F3Base_Modulo_Endpoint_Leads' ),
				'detalhe'  => __( 'origem do token efêmero assinado que o beacon carrega.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_LEAD, __( 'Último lead registrado', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		return $this->ativo(
			__( 'Captura de CTAs disponível. O ícone flutuante exige número e ativação explícita. O layout controla os botões do menu e das páginas.', 'f3base' )
		);
	}

	/**
	 * Enfileira o script de leads e entrega a configuração como dado.
	 *
	 * @return void
	 */
	public function enfileirar( bool $formulario = false ): void {
		$numero = $this->numero();

		/*
		 * A DEPENDÊNCIA DO CONSENTIMENTO É DECLARADA, e ela é a ordem inteira.
		 * O portão do cliente deste arquivo (`permiteTags()`) consulta
		 * `window.f3baseConsentimento`, publicado pelo script de consentimento;
		 * sem a dependência declarada, os dois eram só dois `defer` cuja ordem
		 * dependia da posição no documento, e a ausência do objeto cai na
		 * DECISÃO DE RESERVA — permitir. Isto é: um clique que chegasse antes do
		 * consentimento executar disparava para Meta e LinkedIn a conversão de
		 * quem tinha recusado. O carregador de tags já declarava esta mesma
		 * dependência; este aqui não declarava.
		 */
		wp_enqueue_script(
			self::HANDLE,
			F3BASE_PLUGIN_URL . 'assets/f3base-leads' . ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min' ) . '.js',
			F3Base_Modulo_Tracking::ha_destino() ? array( 'f3base-contexto', F3Base_Modulo_Consentimento::HANDLE, F3Base_Modulo_Tracking::HANDLE ) : array( 'f3base-contexto', F3Base_Modulo_Consentimento::HANDLE ),
			F3BASE_PLUGIN_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		if ( ! empty( F3Base_Options::ler( 'f3base_contato' )['flutuante'] ) ) {
			wp_enqueue_style( 'f3base-whatsapp', F3BASE_PLUGIN_URL . 'assets/f3base-whatsapp.css', array(), F3BASE_PLUGIN_VERSAO ); }

		$atribuicao = F3Base_Options::ler( 'f3base_atribuicao' );

		wp_localize_script(
			self::HANDLE,
			'f3baseLeadsDados',
			array(
				'endpoint'         => esc_url_raw( rest_url( F3BASE_REST_NAMESPACE . F3Base_Modulo_Endpoint_Leads::ROTA ) ),
				/*
				 * O TOKEN NASCE COM O ESCOPO DESTA PÁGINA, e a rota de emissão
				 * viaja junto: é ela que o cliente chama quando a página veio do
				 * cache com um token já vencido, em vez de o beacon voltar 403
				 * para sempre sem sinal nenhum.
				 */
				'token'            => F3Base_Modulo_Endpoint_Leads::emitir_token( self::caminho_atual() ),
				'rotaToken'        => esc_url_raw( rest_url( F3BASE_REST_NAMESPACE . F3Base_Modulo_Endpoint_Leads::ROTA_TOKEN ) ),
				'numero'           => $numero,
				'classesCta'       => F3Base_Options::ler( 'f3base_contato' )['classes_cta'] ?? array(),
				'mensagem'         => $this->mensagem_padrao(),
				'seletor'          => '[' . self::ATRIBUTO . ']',
				'atributoNumero'   => self::ATRIBUTO_NUMERO,
				/*
				 * O TOKEN DO PRIMEIRO TOQUE VIAJA JUNTO, e não é uma
				 * duplicação: o navegador precisa comparar o modelo recebido
				 * com alguma coisa, e a alternativa é o script carregar o
				 * literal — que é a segunda fonte que este pacote persegue, só
				 * que numa linguagem onde nenhuma constante do PHP alcança.
				 * Mandando o token, quem compara e quem decide leem o MESMO
				 * valor, e ele sai de `F3Base_Vocabulario`.
				 */
				'atribuicao'       => array(
					'modelo'        => is_array( $atribuicao )
						? (string) ( $atribuicao['modelo'] ?? F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE )
						: F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE,
					'primeiroToque' => F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE,
					'ttlDias'       => is_array( $atribuicao ) ? (int) ( $atribuicao['ttl_dias'] ?? 30 ) : 30,
					'chave'         => 'f3base_atribuicao',
				),
				'limites'          => F3Base_Modulo_Endpoint_Leads::limites_publicos(),
				'janelaCorrelacao' => F3Base_Modulo_Endpoint_Leads::janela_de_correlacao(),
				'medicao'          => class_exists( 'F3Base_Modulo_Tracking' ) ? F3Base_Modulo_Tracking::dados_de_medicao() : array(),
			)
		);
	}

	/**
	 * O CAMINHO DA PÁGINA que está sendo renderizada — o escopo do token.
	 *
	 * Sai da URI da requisição e passa pelo redutor do próprio endpoint, que é o
	 * mesmo que reduz o campo `pagina` do payload: quem emite e quem confere
	 * precisam derivar o escopo pela MESMA função, senão todo beacon volta 403.
	 *
	 * @return string
	 */
	private static function caminho_atual(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) ) : '/';

		return F3Base_Modulo_Endpoint_Leads::caminho_interno( $uri );
	}

	/** Renderiza somente o botão flutuante opcional do próprio plugin. */

	public function flutuante(): void {
		$c = F3Base_Options::ler( 'f3base_contato' );
		if ( is_admin() || is_feed() || empty( $c['flutuante'] ) || '' === $this->numero() ) {
			return; }
		printf( '<a id="f3base-whatsapp-flutuante" class="f3base-whatsapp-flutuante" href="%s" target="_blank" rel="noopener" aria-label="Conversar pelo WhatsApp (abre em nova aba)" data-f3base-lead="whatsapp" data-f3base-numero="%s" data-f3base-cta="whatsapp-flutuante">', esc_url( self::montar_url( $this->numero(), $this->mensagem_padrao() ) ), esc_attr( $this->numero() ) );
		echo '<svg viewBox="0 0 32 32" width="32" height="32" fill="currentColor" aria-hidden="true" focusable="false"><path d="M16 3A13 13 0 0 0 4.8 22.6L3 29l6.6-1.7A13 13 0 1 0 16 3Zm0 2.4a10.6 10.6 0 1 1-5.5 19.6l-.5-.3-3.6.9 1-3.5-.3-.5A10.6 10.6 0 0 1 16 5.4Zm-4.2 4.7c-.3 0-.7.1-1 .5-.4.4-1.4 1.4-1.4 3.3 0 2 1.4 3.8 1.6 4 .2.3 2.7 4.3 6.7 5.8 3.3 1.2 4 .9 4.7.8.7-.1 2.3-1 2.6-1.9.3-.9.3-1.7.2-1.9-.1-.2-.4-.3-.9-.5l-2.6-1.2c-.4-.2-.7-.3-1 .2l-1.2 1.4c-.2.3-.4.3-.8.1a11 11 0 0 1-3.2-2 12 12 0 0 1-2.2-2.8c-.2-.4 0-.6.2-.8l.6-.7.4-.6c.1-.2.1-.5 0-.7l-1.2-2.7c-.3-.7-.6-.7-.9-.7h-.6Z"/></svg></a>';
	}

	/**
	 * Monta a URL `wa.me` com a mensagem.
	 *
	 * @param string $numero   Número em E.164 sem sinais.
	 * @param string $mensagem Mensagem inicial.
	 * @return string
	 */
	public static function montar_url( string $numero, string $mensagem ): string {
		$base = 'https://wa.me/' . rawurlencode( $numero );

		if ( '' === $mensagem ) {
			return $base;
		}

		return add_query_arg( 'text', rawurlencode( $mensagem ), $base );
	}

	/**
	 * Número de WhatsApp configurado.
	 *
	 * @return string
	 */
	private function numero(): string {
		$contato = F3Base_Options::ler( 'f3base_contato' );

		return is_array( $contato ) ? (string) ( $contato['whatsapp_e164'] ?? '' ) : '';
	}

	/**
	 * Mensagem padrão do CTA.
	 *
	 * @return string
	 */
	private function mensagem_padrao(): string {
		$contato  = F3Base_Options::ler( 'f3base_contato' );
		$mensagem = is_array( $contato ) ? trim( (string) ( $contato['mensagem_padrao'] ?? '' ) ) : '';

		if ( '' !== $mensagem ) {
			return $mensagem;
		}

		return sprintf(
			/* translators: %s: nome do site. */
			__( 'Olá! Vim pelo site %s e quero falar com a equipe.', 'f3base' ),
			wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES )
		);
	}
}
