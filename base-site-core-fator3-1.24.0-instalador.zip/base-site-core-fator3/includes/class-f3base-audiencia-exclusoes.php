<?php
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Audiencia_Exclusoes {
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_audiencia_404';}
    public static function instalar(): bool {global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE $t (
 dia date NOT NULL,
 caminho varchar(190) NOT NULL,
 contagem bigint unsigned NOT NULL DEFAULT 0,
 ultimo_em bigint unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (dia,caminho)
) ".$wpdb->get_charset_collate().';');return !$wpdb->last_error&&!array_diff(array('dia','caminho','contagem','ultimo_em'),$wpdb->get_col('SHOW COLUMNS FROM '.$t));}
    public static function registrar(): void {if(!is_404()||is_admin()||strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){return;}global $wpdb;$t=self::tabela();$dia=wp_date('Y-m-d');$path=F3Base_Analise::caminho(wp_unslash($_SERVER['REQUEST_URI']??'/'));if(!$path){return;}
        // Bounded cardinality; overflow remains visible in one explicit bucket.
        if((int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE dia=%s',$t,$dia))>=5000&&!$wpdb->get_var($wpdb->prepare('SELECT 1 FROM %i WHERE dia=%s AND caminho=%s',$t,$dia,$path))){$path='/@outros-404';}
        $wpdb->query($wpdb->prepare('INSERT INTO %i (dia,caminho,contagem,ultimo_em) VALUES (%s,%s,1,%d) ON DUPLICATE KEY UPDATE contagem=contagem+1,ultimo_em=VALUES(ultimo_em)',$t,$dia,$path,time()));
    }
    public static function podar(): void {global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE dia<%s LIMIT 5000',self::tabela(),wp_date('Y-m-d',time()-90*DAY_IN_SECONDS)));}
    public static function relatorio(string $de,string $ate): array {global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT caminho,SUM(contagem) requisicoes,MAX(ultimo_em) ultimo_em FROM %i WHERE dia BETWEEN %s AND %s GROUP BY caminho ORDER BY requisicoes DESC,caminho LIMIT 200',self::tabela(),$de,$ate),ARRAY_A);return array('fonte'=>'f3base_audiencia_404','unidade'=>'requisicoes_404_observadas_pelo_wordpress','retencao_dias'=>90,'max_caminhos_dia'=>5000,'limite_linhas'=>200,'linhas'=>$rows?:array(),'ok'=>$wpdb->last_error==='','observacao'=>'Separado da audiência; inclui robôs e editores. Respostas servidas sem executar WordPress não entram nesta contagem. Sem IP, user agent ou pseudônimo.');}
}
