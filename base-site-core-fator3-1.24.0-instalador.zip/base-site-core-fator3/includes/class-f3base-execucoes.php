<?php
/** Diário de passagens e orçamento compartilhado. Datas persistidas em UTC. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Execucoes {
    private static ?array $passagem=null;
    private static float $deadline=0;
    private static int $trabalhos=0;
    private static array $reivindicacao=array();
    public static function reivindicacao(): array {return self::$reivindicacao;}
    public static function tabela(): string { global $wpdb; return $wpdb->prefix.'f3base_execucoes'; }
    public static function instalar(): bool {
        global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $t=self::tabela();
        dbDelta("CREATE TABLE {$t} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            run_id varchar(64) NOT NULL,
            parent_run_id varchar(64) NOT NULL DEFAULT '',
            origem varchar(16) NOT NULL,
            entrada varchar(24) NOT NULL,
            tarefa varchar(64) NOT NULL DEFAULT '',
            hook varchar(100) NOT NULL DEFAULT '',
            ocorrencia char(64) DEFAULT NULL,
            inicio bigint unsigned NOT NULL,
            fim bigint unsigned NOT NULL DEFAULT 0,
            sucesso tinyint DEFAULT NULL,
            codigo varchar(100) NOT NULL DEFAULT '',
            core_examinado tinyint NOT NULL DEFAULT 0,
            dados longtext NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY run_id (run_id),
            UNIQUE KEY ocorrencia (ocorrencia),
            KEY origem_janela (parent_run_id,origem,inicio),
            KEY tarefas (tarefa,inicio)
        ) {$wpdb->get_charset_collate()};");
        return !$wpdb->last_error && count($wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i', $t)))===14;
    }
    public static function disponivel(): bool {global $wpdb;$t=self::tabela();return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;}
    public static function origem(): string {return defined('WP_CLI')&&WP_CLI?'cli':(wp_doing_cron()?'http_cron':'manual');}
    public static function iniciar(string $entrada='executor'): bool {
        if(self::$passagem){return false;}
        self::$deadline=microtime(true)+30;self::$trabalhos=0;
        $r=array('run_id'=>wp_generate_uuid4(),'parent_run_id'=>'','origem'=>self::origem(),'entrada'=>$entrada,'inicio'=>time(),'dados'=>'{}');
        global $wpdb;
        if(!self::disponivel()||!$wpdb->insert(self::tabela(),$r)){self::$deadline=0;return false;}
        self::$passagem=$r;register_shutdown_function(array(__CLASS__,'encerrar'));
        return true;
    }
    public static function atual(): ?array {return self::$passagem;}
    public static function restante_ms(int $reserva=1000): int {return self::$deadline?max(0,(int)floor((self::$deadline-microtime(true))*1000)-$reserva):30000-$reserva;}
    public static function deadline(): float {return self::$deadline?:microtime(true)+30;}
    public static function pode_trabalhar(): bool {return self::$trabalhos<3&&self::restante_ms()>1000;}
    public static function iniciar_tarefa(string $tarefa,string $hook,array $args,?int $quando): ?string {
        if(!self::$passagem||!self::pode_trabalhar()){return null;}global $wpdb;
        $id=wp_generate_uuid4();$occ=$quando===null?null:hash('sha256',$hook.'|'.serialize($args).'|'.$quando);
        $row=array('run_id'=>$id,'parent_run_id'=>self::$passagem['run_id'],'origem'=>self::origem(),'entrada'=>self::$passagem['entrada'],'tarefa'=>$tarefa,'hook'=>$hook,'ocorrencia'=>$occ,'inicio'=>time(),'core_examinado'=>1,'dados'=>wp_json_encode(array('quando'=>$quando,'argumentos_sha256'=>hash('sha256',serialize($args)))));
        $sql=$wpdb->prepare('INSERT INTO %i (run_id,parent_run_id,origem,entrada,tarefa,hook,ocorrencia,inicio,core_examinado,dados) VALUES (%s,%s,%s,%s,%s,%s,'.($occ===null?'NULL':'%s').',%d,1,%s) ON DUPLICATE KEY UPDATE run_id=run_id',self::tabela(),...array_values(array_filter($row,static fn($v,$k)=>$k!=='core_examinado'&&($k!=='ocorrencia'||$v!==null),ARRAY_FILTER_USE_BOTH)));
        $ok=$wpdb->query($sql);
        if($ok===false){self::$reivindicacao=array('codigo'=>'diario_persistencia_falhou');return null;}
        $owner=$occ===null?$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE run_id=%s',self::tabela(),$id),ARRAY_A):$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE ocorrencia=%s',self::tabela(),$occ),ARRAY_A);
        if($owner&&!hash_equals($id,$owner['run_id'])&&((!empty($owner['fim'])&&(string)($owner['sucesso']??'')==='0')||((int)$owner['fim']===0&&(int)$owner['inicio']<time()-180))){
            $old=$owner;unset($old['id']);$old['run_id']=wp_generate_uuid4();$old['ocorrencia']=null;$old['dados']=wp_json_encode(array('execucao_original'=>$owner['run_id'],'ocorrencia'=>$occ,'resultado_anterior'=>json_decode($owner['dados'],true))); 
            if($wpdb->insert(self::tabela(),$old)&&1===$wpdb->update(self::tabela(),array('run_id'=>$id,'parent_run_id'=>self::$passagem['run_id'],'origem'=>self::origem(),'inicio'=>time(),'fim'=>0,'sucesso'=>null,'codigo'=>'retomada_mesma_ocorrencia','dados'=>$row['dados']),array('run_id'=>$owner['run_id'],'inicio'=>$owner['inicio'],'fim'=>$owner['fim']))){$owner['run_id']=$id;}
        }
        if(!$owner||!hash_equals($id,$owner['run_id'])){self::$reivindicacao=array('codigo'=>$owner?((int)$owner['fim']?'ocorrencia_ja_processada':'ocorrencia_ocupada'):'diario_leitura_falhou','execucao_existente'=>$owner['run_id']??null);self::$passagem['codigo']=self::$reivindicacao['codigo'];$wpdb->update(self::tabela(),array('codigo'=>self::$reivindicacao['codigo'],'dados'=>wp_json_encode(self::$reivindicacao)),array('run_id'=>self::$passagem['run_id']));return null;}
        self::$reivindicacao=array('codigo'=>'ocorrencia_reivindicada','run_id'=>$id);++self::$trabalhos;
        $wpdb->update(self::tabela(),array('core_examinado'=>1),array('run_id'=>self::$passagem['run_id']));return $id;
    }
    public static function tentativa(string $tarefa,string $hook,?int $quando,string $codigo,array $detalhes=array()): bool {
        global $wpdb;$r=array('run_id'=>wp_generate_uuid4(),'parent_run_id'=>self::$passagem['run_id']??'','origem'=>self::origem(),'entrada'=>self::$passagem['entrada']??'antes_reserva','tarefa'=>$tarefa,'hook'=>$hook,'inicio'=>time(),'fim'=>time(),'codigo'=>$codigo,'core_examinado'=>1,'dados'=>wp_json_encode(array('quando'=>$quando,'reivindicacao'=>self::$reivindicacao,'detalhes'=>$detalhes)));
        if(!$wpdb->insert(self::tabela(),$r)){@error_log('F3BASE diario_indisponivel tarefa='.sanitize_key($tarefa).' codigo='.sanitize_key($codigo));return false;}return true;
    }
    public static function concluir_tarefa(string $id,array $r): void {
        global $wpdb;$wpdb->update(self::tabela(),array('fim'=>time(),'sucesso'=>array_key_exists('ok',$r)?(int)$r['ok']:null,'codigo'=>substr((string)($r['codigo']??'executado_sem_confirmacao'),0,100),'dados'=>wp_json_encode($r)),array('run_id'=>$id));
    }
    public static function encerrar(?bool $sucesso=null,string $codigo=''): void {
        if(!self::$passagem){return;}global $wpdb;
        $id=self::$passagem['run_id'];$children=$wpdb->get_results($wpdb->prepare('SELECT sucesso,codigo FROM %i WHERE parent_run_id=%s',self::tabela(),$id),ARRAY_A);
        if($sucesso===null&&$children){$sucesso=!in_array('0',array_column($children,'sucesso'),true)&&!in_array(0,array_column($children,'sucesso'),true);if(in_array(null,array_column($children,'sucesso'),true)){$sucesso=null;}}
        $wpdb->update(self::tabela(),array('fim'=>time(),'sucesso'=>$sucesso===null?null:(int)$sucesso,'codigo'=>$codigo?:($children?'passagem_concluida':(self::$passagem['codigo']??'sem_trabalho_core')),'core_examinado'=>$children||self::$passagem['entrada']!=='invocacao_cli'?1:0),array('run_id'=>$id));
        self::$passagem=null;self::$deadline=0;self::$trabalhos=0;
    }
    private static function tempo(int $at): array {return array('at'=>$at,'utc'=>$at?gmdate('c',$at):null,'local'=>$at?wp_date('d/m/Y H:i:s T',$at):null);}
    public static function resumo(): array {
        global $wpdb;$r=array('versao'=>'5.1.0','origem_detectada'=>self::origem(),'janela'=>array('inicio_exclusivo'=>time()-DAY_IN_SECONDS,'fim_inclusivo'=>time()),'agendamento_verificado'=>false,'evidencia'=>'Nenhuma passagem CLI foi observada.','retencao'=>'sem_expiracao_automatica');
        foreach(array('cli'=>'cli','http_cron'=>'http','manual'=>'manual') as $origin=>$key){$r['ultima_'.$key]=self::tempo(0);$r['passagens_24h'][$origin]=0;}
        $r['cron_servidor_ativo']=false;$r['cron_servidor_ultima_em']=null;
        if(!self::disponivel()){$r['disponivel']=false;return $r;}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT origem,MAX(IF(inicio<=%d,inicio,0)) ultimo,SUM(inicio>%d AND inicio<=%d) quantidade FROM %i WHERE parent_run_id='' GROUP BY origem",time(),time()-DAY_IN_SECONDS,time(),self::tabela()),ARRAY_A);
        foreach($rows as $row){$k=array('cli'=>'cli','http_cron'=>'http','manual'=>'manual')[$row['origem']]??null;if(!$k){continue;}$r['ultima_'.$k]=self::tempo((int)$row['ultimo']);$r['passagens_24h'][$row['origem']]=(int)$row['quantidade'];}
        $first=(int)$wpdb->get_var($wpdb->prepare("SELECT MIN(inicio) FROM %i WHERE parent_run_id=''",self::tabela()));$reset=(int)(F3Base_Recuperacao::ler()['reconciliacao_confirmada_em']??0);$r['observacao_desde']=self::tempo($first);$r['observacao_continua_desde']=self::tempo($first?max($first,$reset):0);$r['janela_completa']=$first>0&&max($first,$reset)<=time()-DAY_IN_SECONDS;
        $last=$r['ultima_cli']['at'];$r['cron_servidor_ativo']=$last>0&&$last<=time()&&$last>=time()-7200;$r['cron_servidor_ultima_em']=$last?:null;$r['disponivel']=true;$r['evidencia']=$last?($r['cron_servidor_ativo']?'Passagem CLI recente observada em ':'Última passagem CLI fora da janela de duas horas: ').wp_date('d/m/Y H:i:s T',$last).'. Não comprova crontab instalado nem sucesso de todas as tarefas.':'Nenhuma passagem CLI observada. Confira o cron da hospedagem.';return $r;
    }
    public static function listar(array $e=array()): array {
        if(!current_user_can('manage_options')&&!(defined('WP_CLI')&&WP_CLI)){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;
        $page=max(1,min(100000,(int)($e['pagina']??1)));$where='1=1';
        if(!empty($e['tarefa'])){if(!is_string($e['tarefa'])||!isset(F3Base_Operacao::tarefas()[$e['tarefa']])){return array('ok'=>false,'codigo'=>'tarefa_desconhecida');}$where.=$wpdb->prepare(' AND tarefa=%s',$e['tarefa']);}
        if(!empty($e['origem'])){$where.=$wpdb->prepare(' AND origem=%s',$e['origem']);}if(!empty($e['run_id'])){$where.=$wpdb->prepare(' AND (run_id=%s OR parent_run_id=%s)',$e['run_id'],$e['run_id']);}
        if(!self::disponivel()){return array('ok'=>false,'codigo'=>'historico_indisponivel');}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY inicio DESC,id DESC LIMIT 51 OFFSET %d",self::tabela(),($page-1)*50),ARRAY_A);$more=count($rows)>50;$rows=array_slice($rows,0,50);
        foreach($rows as &$row){$row['inicio_formatado']=self::tempo((int)$row['inicio']);$row['fim_formatado']=self::tempo((int)$row['fim']);$row['dados']=json_decode($row['dados'],true);}unset($row);
        return array('ok'=>!$wpdb->last_error,'linhas'=>$rows,'pagina'=>$page,'proxima_pagina'=>$more?$page+1:null,'execucoes'=>self::resumo());
    }
    public static function registrar(): void {F3Base_Servicos::ability('execucoes-ler','Histórico paginado das passagens e tarefas do Core',array(__CLASS__,'listar'),array('tarefa'=>array('type'=>'string','enum'=>array_keys(F3Base_Operacao::tarefas())),'pagina'=>array('type'=>'integer','minimum'=>1),'origem'=>array('type'=>'string','enum'=>array('cli','http_cron','manual')),'run_id'=>array('type'=>'string','maxLength'=>64)));}
    public static function iniciar_hooks(): void {
        add_filter('http_request_args',static function($args){if(self::$passagem){$args['timeout']=max(0.001,min((float)($args['timeout']??5),self::restante_ms()/1000));}return $args;},PHP_INT_MAX);
        add_filter('pre_http_request',static function($pre){return self::$passagem&&self::restante_ms()<1000?new WP_Error('f3base_orcamento_esgotado','Passagem sem orçamento para outra chamada.'): $pre;},PHP_INT_MAX);
        if(defined('WP_CLI')&&WP_CLI&&class_exists('WP_CLI')){
            WP_CLI::add_hook('before_invoke:cron event run',static function($command){self::iniciar('invocacao_cli');return $command;});
            WP_CLI::add_hook('after_invoke:cron event run',static function($command){self::encerrar();return $command;});
        }
    }
}
