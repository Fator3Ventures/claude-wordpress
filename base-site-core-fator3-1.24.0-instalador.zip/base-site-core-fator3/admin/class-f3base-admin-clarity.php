<?php
/** Cadastro humano e teste explícito da credencial Clarity; GET não consome API. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Admin_Clarity {
    const ACAO='f3base_clarity_testar';
    public static function processar(array $e,string $method): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if($method!=='POST'||!is_string($e['_wpnonce']??null)||!wp_verify_nonce($e['_wpnonce'],self::ACAO)){return array('ok'=>false,'codigo'=>'reabra_configuracao');}
        if(!is_string($e['tentativa']??null)||!preg_match('/^[a-f0-9-]{36}$/D',$e['tentativa'])){return array('ok'=>false,'codigo'=>'reabra_configuracao');}
        foreach(array('revisao_projeto','revisao_token') as $k){if(!is_string($e[$k]??null)||!preg_match('/^[a-f0-9]{64}$/D',$e[$k])){return array('ok'=>false,'codigo'=>'reabra_configuracao');}}
        return F3Base_Recuperacao::executar(static function()use($e){
            $project=(string)get_option('f3base_clarity_project_id','');
            $r=F3Base_Clarity::consultar(array('dias'=>1,'dimensoes'=>array('URL'),'idempotency_key'=>'admin-'.hash('sha256',$e['tentativa'].'|'.$e['revisao_projeto'].'|'.$e['revisao_token']),'motivo'=>'teste_token_admin','revisao_projeto'=>$e['revisao_projeto'],'revisao_token'=>$e['revisao_token']));
            // Only fixed metadata goes to the notice/state. Never copy an HTTP body or credential.
            $safe=array_intersect_key($r,array_flip(array('ok','codigo','coleta','estado','http','duplicado','http_repetido')));
            if(isset($safe['coleta'])){
                $row=F3Base_Clarity_Acervo::obter($safe['coleta']);
                if($row){$safe['estado']=$row['estado'];$safe['ok']=in_array($row['estado'],array('resposta_disponivel','possivelmente_truncada'),true);}
                $test=$safe+array('em'=>time(),'projeto'=>$project,'revisao_projeto'=>$e['revisao_projeto'],'revisao_token'=>$e['revisao_token']);
                F3Base_Options::atualizar_estado('f3base_clarity_estado',static function($s)use($test){$s['ultimo_teste_admin']=$test;return $s;});
            }
            return $safe+array('projeto'=>$project);
        });
    }
    public static function enviar(): void {
        $r=self::processar(wp_unslash($_POST),$_SERVER['REQUEST_METHOD']??'');
        if(($r['codigo']??'')==='sem_permissao'){wp_die('Sem permissão.',403);}
        $id=wp_generate_uuid4();set_transient('f3base_clarity_retorno_'.$id,array('usuario'=>get_current_user_id(),'resultado'=>$r),10*MINUTE_IN_SECONDS);
        wp_safe_redirect(add_query_arg('clarity-retorno',$id,F3Base_Interface::url('f3base_clarity_api_token')));exit;
    }
    public static function mensagem(array $r): string {
        if(!empty($r['ok'])){return ($r['estado']??'')==='possivelmente_truncada'?'Token aceito. Coleta preservada; o fornecedor pode ter limitado as linhas.':'Token aceito. A primeira consulta está disponível em Medição → Clarity.';}
        $messages=array(
            'sem_permissao'=>'É necessário administrar as configurações para testar o token.',
            'reabra_configuracao'=>'A sessão do teste expirou ou o envio é inválido. Reabra esta área.',
            'configuracao_alterada'=>'Projeto ou token mudou desde que esta tela foi aberta. Reabra a área antes de testar.',
            'projeto_ou_credencial_nao_vinculada'=>'Salve o projeto e seu token de exportação antes de testar. Se mudou o projeto, cadastre novamente o token correspondente.',
            'credencial_recusada'=>'O Clarity recusou o token. Confira se ele está válido e foi gerado em Data Export do projeto informado.',
            'cota_local_esgotada'=>'A reserva manual de duas consultas ou o limite local de dez consultas do dia foi atingido. Aguarde o próximo dia UTC.',
            'cota_remota'=>'O Clarity informou limite de consultas atingido. O Core aguardará o prazo indicado antes de tentar novamente.',
            'aguardando_cota_remota'=>'A coleta está aguardando a liberação da cota remota. Nenhuma nova consulta foi enviada.',
            'coleta_em_andamento'=>'Há outra coleta deste projeto em andamento. Aguarde antes de testar.',
            'core_em_recuperacao'=>'O Core está pausado ou indisponível para operações. Nenhuma consulta foi enviada.',
            'falha_http'=>'O Clarity não concluiu a consulta. Confira o serviço e tente mais tarde; a tentativa consumiu a reserva local.',
            'json_invalido'=>'O Clarity devolveu uma resposta inválida. O token não foi confirmado e nenhum total foi inventado.',
            'esquema_incompativel'=>'A resposta foi preservada, mas tem formato incompatível com o relatório. Confira a coleta antes de repetir.'
        );
        return $messages[$r['codigo']??$r['estado']??'']??'Não foi possível concluir e confirmar a coleta. Consulte o estado registrado antes de repetir.';
    }
    public static function render(): void {
        if(!current_user_can('manage_options')){return;}
        $project=(string)get_option('f3base_clarity_project_id','');$secret=F3Base_Segredos::status('f3base_clarity_api_token');$state=F3Base_Options::ler('f3base_clarity_estado');$bound=$state['credencial']['projeto']??'';$ready=F3Base_Clarity::configurado();$budget=F3Base_Clarity::orcamento($project);
        echo '<section class="f3base-secao f3base-clarity-conexao"><h2>Conexão de exportação do Clarity</h2>';
        $id=$_GET['clarity-retorno']??'';$notice=is_string($id)&&preg_match('/^[a-f0-9-]{36}$/D',$id)?get_transient('f3base_clarity_retorno_'.$id):false;
        if(is_array($notice)&&($notice['usuario']??0)===get_current_user_id()){$r=$notice['resultado'];echo '<div class="notice notice-'.(!empty($r['ok'])?'success':'warning').' inline" role="status"><p>'.esc_html(self::mensagem($r)).'</p></div>';}
        echo '<p><strong>Token: '.esc_html(!$secret['presente']?'ausente':($secret['estado']==='disponivel'?'definido':'definido, precisa ser recadastrado')).'.</strong> Projeto salvo neste site: <strong>'.esc_html($project?:'não informado').'</strong>.</p>';
        echo '<p>'.esc_html($ready?'Vinculado ao projeto '.$project.' neste site.':($bound!==''?'Vínculo registrado: '.$bound.'. A coleta está inativa até cadastrar um token para o projeto atual.':'Sem vínculo ativo. Salve o projeto e o token acima.')).'</p>';
        echo '<p class="description">O vínculo é registrado pelo Core no cadastro. A API confirma que o token é aceito, mas não devolve a identidade do projeto; gere o token no mesmo projeto informado acima. O ID público da tag e o token de exportação têm funções diferentes.</p>';
        $last=$state['ultimo_teste_admin']??array();
        if(($last['projeto']??null)===$project&&($last['revisao_projeto']??'')===F3Base_Options::revisao('f3base_clarity_project_id')&&($last['revisao_token']??'')===F3Base_Options::revisao('f3base_clarity_api_token')){echo '<p>Último teste desta configuração: '.esc_html(wp_date('d/m/Y H:i:s P',(int)$last['em']).' — '.self::mensagem($last)).'</p>';}
        else{echo '<p>Esta configuração ainda não tem teste manual registrado.</p>';}
        echo '<p>Consumo local de hoje (UTC): '.(int)$budget['automaticas'].'/8 automáticas e '.(int)$budget['manuais'].'/2 manuais; até 10 consultas por projeto/dia. Outros consumidores podem usar a mesma cota do Clarity.</p>';
        if((int)$budget['bloqueado_ate']>time()){echo '<p>Nova tentativa após '.esc_html(wp_date('d/m/Y H:i:s P',(int)$budget['bloqueado_ate'])).'.</p>';}
        echo '<p>Salve as alterações acima antes de testar. O teste usa o token salvo, consulta as últimas 24 horas por URL e guarda o resultado no acervo local. Cada nova tentativa usa uma consulta manual; atualizar esta tela não consulta o serviço.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="f3base-clarity-teste"><input type="hidden" name="action" value="'.self::ACAO.'">';wp_nonce_field(self::ACAO);
        foreach(array('tentativa'=>wp_generate_uuid4(),'revisao_projeto'=>F3Base_Options::revisao('f3base_clarity_project_id'),'revisao_token'=>F3Base_Options::revisao('f3base_clarity_api_token')) as $k=>$v){echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr($v).'">';}
        echo '<button class="button"'.disabled(!$ready||(int)$budget['manuais']>=2||(int)$budget['automaticas']+(int)$budget['manuais']>=10||(int)$budget['bloqueado_ate']>time(),true,false).'>Testar token e coletar agora</button> <a class="button" href="'.esc_url(admin_url('admin.php?page=f3base-medicao&area=clarity')).'">Ver coletas no relatório</a></form></section>';
    }
}
