/* GPL-2.0-or-later. Filtro local; não altera escolhas. */
document.addEventListener('input',function(e){var id=e.target.getAttribute('data-f3base-buscar-blocos');if(!id)return;var root=document.getElementById(id),q=e.target.value.toLowerCase();if(root)root.querySelectorAll('[data-f3base-bloco]').forEach(function(n){n.style.display=n.textContent.toLowerCase().indexOf(q)<0?'none':'block';});});

// Renew only the server-side form context. Secrets remain in the current input element.
document.querySelectorAll('input[name="f3base_contexto"]').forEach(function (input) {
  var form = input.form, ready = false, busy = false;
  if (!form) return;
  form.addEventListener('submit', async function (event) {
    if (ready) return;
    event.preventDefault(); if (busy) return; busy = true;
    var notice = form.querySelector('[data-f3base-contexto-aviso]');
    try {
      var body = new URLSearchParams({action:'f3base_form_renovar',contexto:input.value,nonce:form.elements.f3base_renovar_nonce.value});
      var response = await fetch(ajaxurl, {method:'POST',credentials:'same-origin',body:body});
      var result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.data && result.data.mensagem || 'Não foi possível renovar o formulário.');
      ready = true; form.requestSubmit(event.submitter || undefined);
    } catch (error) { if (notice) { notice.textContent = error.message; notice.setAttribute('role','alert'); } }
    finally { busy = false; }
  });
});
