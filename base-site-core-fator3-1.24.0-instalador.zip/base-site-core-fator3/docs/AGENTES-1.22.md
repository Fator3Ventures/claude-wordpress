# Guia de agentes — Core 1.22.0

1. Descubra a versão e leia `f3base/documentacao-ler`, o contrato `f3base/config-core-contrato-v1` e os schemas das abilities. Em recuperação, a documentação fica disponível sem carregar serviços comerciais.
2. Para navegar/testar o site, ative a marca de teste no mesmo navegador e confira o estado conforme INSTRUCOES-DO-PLUGIN.md. Cookie de 365 dias não passa automaticamente para outro perfil/navegador. Chamadas MCP têm sua origem própria; não inferir que o cookie existe porque houve acesso ao conector.
3. Antes de escrever, leia valor/revisão e use simulação. Para grupos, `mesclar: true` envia só o delta tipado. Conflito exige reler; não contorne com SQL ou alteração do tema.
4. Para token Pipedrive novo, simulação consulta a conta com o candidato em memória. A resposta declara `verificacao_remota`; pode consumir cota remota, mas não grava opção/fila/objeto comercial. Erro preserva a credencial atual.
5. Depois de aplicar, confira `persisted`, auditoria, `effect` e `verification` separadamente. Para diagnóstico use leitura; ações de verificação/envio exigem intenção explícita.
6. Para relatórios, use IDs e timestamps, cobertura e filtros de testes/consentimento. Não chame largura da janela de aparelho; não conte sessão como pessoa. Dados de robôs mostram leitura/requisição e referência de IA mostra chegada observada; não provam citação, recomendação, treinamento ou autoria de um humano.

Exemplo de escrita parcial (troque revisão pela leitura atual):

```json
{"nome":"f3base_pipedrive","valor":{"atividade":false},"mesclar":true,"revisao_esperada":"HASH_ATUAL_DE_64_HEXADECIMAIS","simular":true}
```

Exemplo de recusa de candidato remoto (campos ilustrativos):

```json
{"ok":false,"simulado":true,"alteraria":false,"persisted":false,"codigo":"valor_recusado","motivo":"Credencial recusada pelo Pipedrive","verificacao_remota":{"remota":true,"ok":false,"http":401}}
```

Não classifique timeout/429 como credencial inválida: são verificação não concluída. Nunca registre o token em nota, URL de ferramenta, relatório ou captura de tela. Use o campo secreto autorizado.

Reconciliação de CRM é administrativa: leia a entrega/revisão, execute `f3base/pipedrive-reconciliar` em simulação com ação `pessoa`, `lead` ou `email_alternativo`; confira referência/prova remota e confirme explicitamente. `adicionar_email_alternativo` deve ser true apenas por decisão explícita, preservando o principal. Reparo de atividade usa `f3base/pipedrive-atividade-reparar` e não reenvia o núcleo. Consulte schemas para campos obrigatórios.

Para retirar URL antiga use `redirects-historico-ler` e `redirects-historico-escrever`, nunca exclusão genérica de metadados. Para procedência use PROCEDENCIA-1.22.md. Para restore use OPERACAO-1.22.md; pausa de Core e Google são independentes. O implantador e o tema não são responsabilidades deste plugin.

## Adendo 135 — revisão 2 da entrega

Token Clarity disponível em Site Core → Configurações → Medição e anúncios → Clarity. O dono cadastra o segredo diretamente, salva e usa **Testar token e coletar agora**; agentes não precisam receber a credencial. Teste preserva uma consulta no relatório, compartilhando as cotas existentes. Leia CLARITY-1.22.md. O pacote 1.22.0 revisado substitui o anterior desta entrega; novo WordPress ou atualização da 1.21.0 continuam os caminhos de instalação.
