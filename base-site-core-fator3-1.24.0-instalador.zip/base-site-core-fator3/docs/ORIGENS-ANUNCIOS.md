# Origens de anúncios — 1.18.0

**Atribuição web**, **importação de contatos nativos** e **envio de conversões** são operações diferentes. Todas as origens nativas começam desligadas. Configuração em Contatos → Integrações → Origens de anúncios; publicidade/medição web em F3 Base → Configurações → Medição e anúncios.

## Meta Lead Ads

Configure conta de anúncios, páginas e formulários autorizados, versão Graph, mapeamento de campos/campanhas e token cifrado. A opção de responsabilidade confirma que esta instalação é a autoridade da coleta. O Core verifica a conta, permissões e pertencimento dos formulários às páginas acessíveis; a operação deve conferir acesso no Leads Access Manager e aprovação do app.

Consulta em tarefas de cinco minutos, até 20 segundos por rodada, com páginas de 50 leads, trava, cursor por formulário e sobreposição de dez minutos. Catálogo paginado de formulários nunca é tratado como completo antes da última página. Falha não avança o marco; lote parcial retoma pelo cursor. Backoff em erro evita consulta contínua. Nenhuma alteração de anúncio/campanha é feita.

Troca de token ou da configuração exige nova verificação de permissões, conta e catálogo de páginas/formulários. Para a mesma conta e ativação, preserva cursores, recibos e marco inicial; não reimporta todo o histórico. Uma resposta de lote cuja configuração mudou não avança o cursor nem restaura a prova antiga.

São preservados IDs de lead/formulário/campanha/conjunto/anúncio, origem e instante nativo quando informados. Nome da campanha pode vir do mapa `mapeamento.campanhas` (chave ID) quando indisponível no payload. Campos comuns são reconhecidos (`full_name`, `email`, `phone_number`, `company_name`, `job_title`); extras usam `mapeamento.campos`, com papéis nome/email/telefone/empresa/cargo/servicos. Não inferir dados ausentes. `is_organic` não representa tráfego pago.

Permissões exigidas pelo adaptador: ads_management, leads_retrieval, pages_show_list, pages_read_engagement e pages_manage_ads. Token válido não prova acesso a todos os ativos. Use a ferramenta de teste de Lead Ads e confira ingestão, identidade, duplicidade e marca de teste antes de habilitar operação comercial. A marca nativa `is_test` deve ser preservada pelo fluxo de teste quando fornecida; não deduza teste pelo nome/e-mail.

## Google Ads

Configure conta e IDs de formulários, modo, mapa de campos e chave Google. Cadastre como webhook `https://SEU-SITE/wp-json/f3base/v1/anuncios/google`, com a mesma chave. O plugin exige HTTPS, valida chave em tempo constante antes da captura e não coloca segredo em URL/log. Formulários precisam estar autorizados. Conversas `CONVERSATIONAL_AGENT` sem form_id exigem campanha na lista explícita `campanhas`; a ausência de formulário permanece ausência.

JSON de webhook até 128 KiB; IDs grandes são strings. Campos comuns: FULL_NAME, EMAIL, PHONE_NUMBER, COMPANY_NAME, JOB_TITLE. Campos adicionais são aceitos e preservados com limites; mudanças futuras do provedor não autorizam sobrescrita de identidade. Teste repetido deve receber 200 `{}` e manter um registro. Chave errada 403; conteúdo conflitante para a mesma identidade 409; falha recuperável 503 para retentativa do produtor. Não responder 200 antes da persistência.

Webhooks não garantem recuperação de períodos perdidos. Configure um **produtor externo autenticado** com Google Ads API para consultar os dados disponíveis, respeitar sua janela de retenção e chamar `f3base/anuncios-google-reconciliar`. O Core não guarda OAuth Google nem executa GAQL. Exemplo de fonte a consultar no cliente Google Ads: `lead_form_submission_data`, com `id`, `asset`, `campaign`, `ad_group`, `submission_date_time`, `gclid` e campos de contato conforme o schema da versão autorizada. Confirme a equivalência do ID com o webhook em homologação; não deduza pelo e-mail.

Contrato da ability (valores ilustrativos, revise pelo schema instalado):

```json
{"simular":true,"revisao":"REVISAO_DA_OPCAO_GOOGLE","conta_id":"ID_DA_CONTA","de":1790553600,"ate":1790640000,"cursor":"inicio","ultimo_lote":false,"equivalencia_ids_confirmada":true,"executor":"rotina-google-autorizada","itens":[]}
```

Até 100 itens por lote; janela máxima de 60 dias e sem datas futuras. Cada item usa a representação de webhook normalizada pelo produtor, preservando lead_id, form_id, campaign_id, instante, teste e campos. Simule, aplique com a revisão conferida, use **o proximo_cursor retornado** no lote seguinte e mantenha de/ate. Não invente cursor nem declare último lote antes de concluir a consulta da API. Só um ciclo completo avança o marco de cobertura; conflito de cursor/revisão exige releitura. Lote já confirmado pode ser repetido idempotentemente. Registre execução diária/atrasos fora do plugin; não presumir que um agente espontaneamente fará a reconciliação.

## Identidade, retenção e entrega

Recibo e lead são gravados em transação. Deduplicação usa origem+conta+ID nativo (Meta inclui formulário), não contato. Informação complementar pode enriquecer o mesmo registro; conteúdo conflitante não sobrescreve. Ingestão nativa não inventa sessão web, não dispara CAPI de formulário do site e não cria nova notificação na repetição. Pipedrive recebe somente se módulo e critérios estiverem ativos. Testes são separados dos relatórios comerciais e do CRM normal.

A ativação estabelece um marco: não importa histórico anterior. Recibos/tombstones e marco de 90 dias evitam reimportação de eliminados; ciclos incompletos adiam limpeza. Última tentativa não é cobertura completa. Diagnóstico mostra início, cursores, próximo agendamento e último sucesso integral. Leitura de saúde não consulta API remota.

## LinkedIn e OpenAI

LinkedIn nativo permanece indisponível até aprovação/acesso da Lead Sync API e homologação; a interface não permite ativar importador inexistente. Atribuição web LinkedIn continua disponível.

OpenAI/ChatGPT Ads: captura web de `oppref` opaco até 8192 bytes, sob consentimento de medição e publicidade, sem lowercase ou truncamento. Valor acima do teto é rejeitado com estado de qualidade. `oppref` não é ID de anúncio, pessoa ou sessão; não vai para o CRM. UTMs/IDs explícitos organizam campanha/anúncio. Sinal pago confirmado produz `openai_ads`; mero referer ChatGPT/utm_source=chatgpt não prova anúncio. Macros não substituídas e conflito de plataforma são diagnosticados.

Não há importação nativa de formulário OpenAI sem contrato/API/acesso homologados, nem pixel/CAPI OpenAI de saída nesta versão. OAI-AdsBot é robô de inspeção e não deve ser contado como lead ou clique pago. O plugin não cria campanhas ou amplia acesso às contas.

Fontes primárias de contrato: https://developers.facebook.com/docs/marketing-api/guides/lead-ads/retrieving ; https://developers.google.com/google-ads/webhook/docs/implementation ; https://developers.google.com/google-ads/webhook/docs/testing ; https://developers.openai.com/ads . Validação em conta e versão autorizadas prevalece sobre exemplos.
