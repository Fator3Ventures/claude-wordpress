# Procedência e complementação — 1.22.0

Uma configuração escolhida continua escolhida quando a versão acrescenta uma propriedade. `origem`, `procedencia.origem_registrada`, `canal` e `em` pertencem à última escolha comprovada. O evento técnico em `procedencia.complementacoes` tem sua própria versão/data e os caminhos relativos acrescentados/ajustados.

| Composição | Significado |
|---|---|
| configurado | Última gravação explícita, mesmo quando igual ao default |
| configurado_complementado | Escolha comprovada vinculada à revisão atual após complemento |
| padrao_integral | Opção ausente materializada pelo pacote, ou complemento desse default |
| desconhecido | Não há vínculo de procedência suficiente |

`revisao` representa o valor persistido. Acrescentar `pais_telefone` altera a revisão. Uma escrita com revisão antiga retorna conflito; releia, reaplique somente a intenção e simule novamente. Reparo exclusivamente de metadados não muda a revisão do valor.

A complementação guarda checkpoint antes da escrita e usa comparação condicional no valor e na procedência. Falha de auditoria permanece pendente; repetição retoma o evento. Escolha concorrente não recebe a autoria antiga. Não há cópia de credenciais ou valores completos no histórico técnico. O histórico é sem autoload e paginado em vinte eventos por opção, por `f3base/config-complementacoes-ler`.

Exemplo de leitura, com valores ilustrativos:

```json
{"nome":"f3base_pipedrive","origem":"ability","procedencia":{"canal":"ability","em":1791300000,"composicao":"configurado_complementado","complementacoes":{"eventos":[{"versao":"1.22.0","operacao":"completar_padroes","subchaves_acrescentadas":["pais_telefone"],"subchaves_ajustadas":[]}],"pagina":1,"proxima_pagina":null,"pendente":false}}}
```

## Dano anterior e reparo

A 1.21.0 podia substituir a procedência por `padrao/php`. Horário próximo da migração não comprova que o valor era configurado. O Core examina candidatos e retorna `reparo_nao_comprovado` quando não possui histórico suficiente; não inventa autoria. O mapa `f3base_proveniencia` guarda somente a última escrita, e auditoria pendente não é histórico de sucessos.

Evidência suportada: snapshot administrativo JSON `f3base-procedencia/1`, da mesma instalação e opção, com valor bruto anterior e procedência correspondente. Valores não secretos podem ser usados para comprovar hashes; não forneça token nesse documento. Formato:

```json
{"formato":"f3base-procedencia/1","site":"https://exemplo.com/","nome":"f3base_pipedrive","valor_anterior":{"ativo":false},"procedencia_anterior":{"origem":"ability","canal":"ability","em":1791200000,"revisao":"HASH_REAL_DO_VALOR_BRUTO_ANTERIOR"}}
```

Esse exemplo é estrutural: `valor_anterior` deve conter a fotografia completa real, não o recorte acima. Hash depende da instalação e serialização; não monte um hash por suposição. O pacote distribui `dados/padroes-1210.json` extraído do catálogo executável da base para conferir a complementação antiga.

1. Leia opção/revisão atual e histórico de complementações.
2. Chame `f3base/config-procedencia-reparar` com `nome`, `revisao_esperada`, `referencia` de auditoria, `evidencia` e `simular: true`.
3. Confira origem/canal/data propostos. Se recusado por evidência incompatível ou edição posterior, pare e investigue; não use SQL.
4. Repita com `simular: false`, `confirmar: true` e a revisão ainda atual. Releia após a operação.

O serviço exige administração, vínculo anterior válido, diferença compatível com defaults 1.21, valor atual explicável pela complementação e ausência de edição posterior conflitante. Guarda só hash/referência da evidência, mais registro de procedência substituído. Reparo idempotente devolve `reparo_ja_confirmado`; falha parcial pode devolver `reparo_auditoria_pendente`. Não dispara entrega comercial, não altera segredo/ativação/mapas e não reabre contatos concluídos.

Não se declara a autoria recuperada nos 14 sites sem receber e verificar suas evidências.
