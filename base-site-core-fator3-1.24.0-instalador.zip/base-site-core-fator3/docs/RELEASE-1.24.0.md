# Fator3 Site Core 1.24.0

## Caminhos de instalação

A versão aceita somente WordPress sem estado anterior do Core ou atualização concluída do Core 1.23.0. Outro estado é recusado antes de converter dados. A atualização usa `f3base_release_1240`, checkpoints retomáveis e só registra conclusão depois de reler a versão estrutural e o estado final.

Companheiros suportados: Fator3 MCP 0.16.0 ou posterior que publique exatamente `server-integration/1.0.0`, política 1; Fator3 MCP Google 0.7.1 ou posterior com o SDK `search-console-reader/1.0.0` registrado. Versões de desenvolvimento e contratos diferentes são recusados. O Core não modifica os companheiros.

## Entregas

| Pedidos | Resultado na 1.24.0 |
|---|---|
| 108, 131 | Nome administrativo corrigido; catálogo de mudanças filtrável; documentação e contratos atuais instalados. |
| 109, 139 (11) | Erros internos têm código seguro; a migração só conclui após persistência e releitura. |
| 115, 125, 127, 133, 146 (7) | CRM ganhou diagnóstico por etapa/campo, HMAC por campo, verificação repetível após sucesso, checkpoints e leases conservadores e mensagens acionáveis. |
| 117, 121, 146 (8) | Aparelho e limites explicados; contato/e-mail usam a mesma projeção, MIME HTML/texto, URLs só nos campos Página/Destino e fallback de destinatários. |
| 124 | Avisos antigos são importados, reavaliados, dispensáveis e aparecem na Saúde sem reaparecer após nova importação da mesma origem. |
| 139 (1, 8, 12, 14), 146 (1–5, 9–10) | Captura sem lock de manutenção, intenções recuperáveis, guarda degradada com atendimento seguro, migração íntegra, expurgo com margem e redirects restauráveis. |
| 140–145 | Saída cumulativa, tempo decorrido/visível, profundidade, salto de rolagem, clique interno e clique inerte; seção alta e tempo ativo corrigidos. |
| 147 | Sistema, navegador, largura, aparelho e novo/recorrente por sessão, com filtros e quebra nos relatórios e cópia no contato. |
| 148 | 404 público e editor autenticado não carregam os destinos nem entram na audiência; 404 é contado à parte por caminho, sem query ou identificador. |

O webhook genérico do pedido 17 permanece fora desta versão por decisão do dono.

## Medição e cobertura

`f3base/medicao-editorial` e `f3base/relatorios-integrados-ler` aceitam `largura_faixa`, `navegador`, `sistema`, `retorno` e `aparelho`. A visão de campanhas aceita `agrupamento=anuncio|campanha` e apresenta duração observada, tempo visível e cobertura de saída por sessão. As unidades terminadas em `_ms` são milissegundos no contrato e aparecem formatadas na tela.

A marca novo/recorrente vive no navegador, depende da permissão de medição e tem históricos independentes para audiência e teste. A primeira sessão observada na 1.24.0 é nova; limpar o armazenamento reinicia a história. Isso não identifica uma pessoa.

A saída é a última marca cumulativa por navegação. Tempo visível inclui página visível sem gesto e difere do engajamento do GA4. Sem evento de saída, duração é indisponível. Agregados preservam soma e quantidade; mediana e distribuição só existem quando todas as amostras usadas ainda são brutas.

404 é agregado por dia e caminho por 90 dias na tabela `f3base_audiencia_404`; query, IP, user agent, sessão e visitante não são guardados. Depois de 5.000 caminhos em um dia, o excedente vai para `/@outros-404`. `wp-admin` continua fora da medição.

## Cache e volta de versão

Purgue o cache de página/CDN depois da atualização: HTML antigo pode continuar entregando o JavaScript 1.23.0. A 1.24.0 aceita payloads antigos; a 1.23.0 não aceita os novos campos e eventos da 1.24.0. Voltar arquivos sem restaurar banco, cron, cache e sentinela deixa tabelas, intenções, payloads e estados que a versão anterior não conhece. A volta não é suportada.
