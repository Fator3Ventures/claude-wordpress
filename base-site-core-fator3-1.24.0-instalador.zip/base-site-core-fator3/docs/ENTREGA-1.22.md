> Documento histórico da 1.22.0. As declarações de completude foram revistas após a conferência. A referência vigente é [ENTREGA-1.22.1.md](ENTREGA-1.22.1.md).

# Entrega 1.22.0 — rastreabilidade

Revisão 2 do pacote (06/10/2026), substituindo a entrega anterior 1.22.0. Implementação do plano aprovado, revisão 4, e do adendo 135, incluindo o pedido 134 e os aceites explicitados de 116/127. A coluna de limites distingue implementação de homologação externa; não declarar o item integralmente saneado nos 14 sites sem suas provas.

| Pedido | Entregue no pacote | Evidência local / inspeção | Limite ou homologação posterior |
|---|---|---|---|
| 107 | Índice, guarda/requisição, bootstrap mínimo, recriação pausada e efeitos por fila | recuperacao-processos; operacao-jornada | Permissões reais de filesystem e prova de diretório no host |
| 108(a,b,e) | Assuntos/mudanças válidos, marca pública e evidência CLI separada | servicos; concorrencia; revisão de textos | Observação do cron na frota |
| 109(a–c) | Erro saneado, falha real distinta de disputa, diário antes da reserva | executor-falhas; concorrencia | Falhas da infraestrutura de produção |
| 111(a–k) | Projeção comum, destinos, assunto, qualidade, preparação e resumo de avisos, consentimento histórico | mapas-apresentacao; crm; avisos; operacao-jornada | Recebimento SMTP e conferência de todos os templates no cliente de e-mail |
| 113(a–g) | Jornada posicionada, métricas/cobertura, tabela e capacidade de leitura | servicos; operacao-jornada; mapas-apresentacao; render | Inspeção visual desktop/celular |
| 115(a–c) | Aviso por causa/episódio, transporte e observação persistente de conta | avisos; revisão de fluxo de conta | Transporte real e observação prolongada |
| 116(a–e) | BR persistido, normalização compartilhada, LinkedIn e pessoa incerta por referência | ciclo-instalacao; procedencia; mapas-apresentacao; crm-reconciliacao | Deduplicação observada em conta real |
| 117(a–f) | Aparelho distinto de largura, CSV, inferência limitada e histórico em lotes | regressoes; mapas-apresentacao; revisão do CSV/cursor | Sinais reais de iPad; não há identificação infalível por UA |
| 118(a–c) | Selo junto ao nome, CSS carregado e origem de teste | render; revisão de assets/projeção | Contraste e layout em navegador real |
| 121(a–f) e nota 1388 | Nota em seções, site identificado uma vez, âncora completa e histórico preservado | crm; mapas-apresentacao; revisão do HTML | Renderização da nota no Pipedrive real; sem reformatação em massa |
| 124(a–c) | label/fallback, renovação de catálogo e prova de etiqueta na criação | crm; revisão do verificador e checkpoint | Catálogos e edição posterior na conta real |
| 125(a–d) | Estado/causa/ação coerentes, frase sem ponto inicial e título/contagens no mesmo cabeçalho | crm; render | Conferência visual das quebras responsivas |
| 126(a–c) | Três chaves reservadas e ajuda efetiva sincronizada | render; mapas-apresentacao | Aplicação de IDs próprios por conta |
| 127(a–c) | Verificação de candidato, flags de simulação, recusa e preservação da credencial anterior | credencial; config; regressoes | API real da conta; não promete regex offline para todo token opaco |
| 129 | Tracking aditivo e documentação derivada do registro | gerar-contratos; revisão de descrições | Conteúdo GTM e duplicidade na operação do site |
| 130 | Serviço nativo para consultar/retirar uma rota histórica com revisão | servicos; redirect-http | Cache/regras do host depois do rollout |
| 131(a–k) | PSL persistente; ocorrência estável; títulos Unicode; pausa/reparos/diários; limpeza GSC; formulário e contratos/ajuda | gsc-cache; executor-falhas; mapas-apresentacao; crm; render; form-context; revisão uninstall | Matriz conjunta real e limpeza em hospedagem de homologação |
| 132(a–i) | Executor; tipos/limites de campo; autoria/reconciliação; despacho; modelos; cache técnico; contexto e migração | executor-falhas; mapas-apresentacao; crm-reconciliacao; render; form-context; ciclo-instalacao | SLAs dependem do executor; conta real e inspeção visual pendentes |
| 133 | Atividade v2 complementar, núcleo preservado e diagnóstico saneado | crm-atividade; crm | Contrato remoto na conta e casos de interrupção externa |
| 134(a,b) | Complementação preserva escolha e registra trilha; leitura distingue composição | procedencia; procedencia-falhas; ciclo-instalacao | Validação do upgrade de cada site |
| 134(c) | Reparo administrativo comprovado; sem inventar histórico ausente | procedencia; contrato/evidência documentados | Recuperação por site depende da evidência disponibilizada |

| 135(a–c) | Token Clarity no wp-admin, cifra/máscara/vínculo, teste compartilhando cota e coleta preservada; ajuda corrigida | clarity-admin; render; catálogo/ajuda regenerados | Cadastro e consulta com token real no Site-Teste pelo dono |

## Decisões preservadas

Webhook genérico (17) permanece adiado por decisão do dono. Não há edição remota em massa das notas antigas. E-mail alternativo depende de ação explícita; atividades desligadas são preservadas. Falha real de banco não vira “ocupada”. Nenhuma regex não documentada foi inventada para o token Pipedrive: a validação candidata é autenticada. iPad indistinguível de Mac mantém limitação. Complementação muda revisão quando muda o valor; metadados reparados não a mudam. Theme/implantador/MCP/Google não foram alterados.

## Arquivos e uso

O instalador contém somente a pasta `base-site-core-fator3/`, incluindo documentação. O fonte inclui plugin, suíte/evidências, plano aprovado e relatório. Não instalar o ZIP de fontes no WordPress. Caminhos suportados: novo ou 1.21.0 → 1.22.0. Restauração/downgrade não são caminhos de compatibilidade deste pacote.

RELATÓRIO DE TESTES: VALIDACAO.md. Encaminhamentos finais: IMPACTO-1.22-MCP.md e IMPACTO-1.22-GOOGLE.md. Homologação em conta real, inspeção visual e rollout permanecem com a operação do usuário; nenhum site foi acessado nesta entrega.

Documento Google atualizado: revisão 5 conciliada; sem alteração nos plugins externos. Contrato opcional documenta e testa separadamente ausência de anúncio e anúncio inconsistente. Consulte IMPACTO-1.22-GOOGLE.md.
