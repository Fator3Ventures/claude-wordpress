> Documento da entrega 1.19, preservado para referência. Para atualizar e para operação/GSC na 1.20, leia OPERACAO-GSC-1.20.md.

# Operação da versão 1.19.0

Data: 01/10/2026. Contrato de configuração/dados 4.3.0; leads schema 5; fila CAPI schema 3. Fonte suportada: 1.18.0 concluída ou instalação nova. Não há suporte a downgrade. O marcador `f3base_release_1190` permite retomada idempotente da instalação.

## Instalar e conferir

1. Faça o backup operacional usual. Instale o ZIP do plugin, não o de fontes. Os dados de produção e credenciais não integram o pacote.
2. Confira versão, marcador concluído, saúde e a pasta privada. A ausência da versão-base concluída bloqueia conversão; não invente marcadores nem escreva dados por SQL para contornar a recusa.
3. Confira Contatos → Relatórios, formulários, contatos e a navegação efetiva do tema. O menu aponta a `admin.php?page=f3base-relatorios` e abre a área central de medição.
4. Verifique configurações preservadas. `false`, zero e lista vazia significam escolhas, não ausência. O perfil piso-padrao-3.2 é leitura/avaliação: não ativa destinos nem credenciais.
5. Marque o navegador de teste em `/f3base-teste/` antes de cada contexto de testes. Acesso por MCP não marca automaticamente outro navegador. Em sondas próprias HTTP use `X-F3Base-Teste: 1`; não atribua a visitantes o IP do agente. Logs do servidor sem essa dimensão não ganham marca por inferência.

Não há mudanças de tema/implantador nesta entrega. IDs de formulário e arquivo não mudam na atualização. Concessões válidas seguem o arquivo novo após uma substituição explícita; links vencidos/revogados/esgotados não são reativados.

## Medição para conteúdo e IA

A audiência tem fonte canônica `f3base_analise`. Editorial, resumo integrado, conversão e CSV usam a mesma seleção de período, segmento, canal, tipo de conteúdo, automação e exclusões anotadas. `method` continua aceito como alias de `metodo`; seus valores não mudaram. O comportamento de seções/tempo exige pareamento de classe, sessão, navegação e página. Contatos sem sessão pareável continuam no volume comercial com cobertura explícita.

Medição → Conteúdo separa páginas e artigos pelo tipo WordPress. O detalhe reúne requisições de agentes em HTML/Markdown, finalidade declarada, evidência de rede, GET/HEAD e status, primeiras/últimas ocorrências e série semanal. Semanas incompletas e logs faltantes são declarados. `/llms.txt` e `/llms-full.txt` são descoberta: não contam como leitura de cada artigo.

IA e robôs permite resumo, conteúdo, frequência e horas, filtros por assinatura, representação e rede e inclusão de tráfego técnico. Para o pedido de volume em `/`, use caminho `/`, grupo `todos` e `incluir_tecnico=true`; consulte também `sem_operador_identificavel`. `curl` e `python-requests` são ferramentas, não nomes do operador. A assinatura usa vocabulário reduzido, sem versão, UA integral, IP ou hash individual. Histórico sem fonte permanece `historico_desconhecido`.

Uma família declarada como IA fora das faixas oficiais válidas passa à classe efetiva `automacao-suspeita`, preservando agente declarado e motivo. Fonte expirada/ausente não vira confirmação nem suspeita automaticamente. Os agregados antigos que já possuem rede são reinterpretados na consulta, sem apagar a declaração original.

Requisição de robô demonstra acesso; HEAD não transfere corpo e 304 é revalidação. Não demonstra citação, recomendação, treinamento nem autoria de visita posterior. Visitas com referência de IA são outro universo. Sessões e visitantes observados são pseudônimos, não pessoas comprovadas. Brutos expirados não permitem reconstruir distintos do período; indisponibilidade é `null` com motivo, não zero.

## Agentes e canal

Leia `f3base/documentacao-ler` sem argumentos para o índice, depois `arquivo`, `linha`, `limite` (até 200). Cada resposta informa SHA-256 e próxima linha. `docs/dados/abilities-*.json` contém schemas e metadados gerados; o schema efetivamente instalado é autoridade. `config-core-contrato-v1` mantém o nome, com conteúdo 4.3.0.

Todas as abilities do Core declaram provider `base-site-core-fator3`, versão e contrato de política 1. O canal MCP 0.13.0 controla perfil da conexão; o Core mantém capabilities do WordPress. Coleta HTTP, reprocessamento, restauração e substituição são escrita, mesmo que não alterem configuração. Não troque por update_option/SQL quando o perfil recusar. Consultas locais de relatório não consomem APIs externas.

Prova da navegação é renovada pelo cron sem usuário autenticado; isso não libera a ability administrativa para anônimos. Há invalidação por mudança de contexto, trava e retentativa. WP-Cron depende do executor operacional do site. Consulta de saúde não constitui nova sonda pública.

## Carregamento e contratos externos

`f3base_meta_auto_config` controla a configuração automática antes de inicializar o Pixel. Google/GTM/Meta/LinkedIn/Clarity têm estratégias próprias de carregamento e prazo. Modo ocioso espera `load` e disponibilidade ociosa, com teto independente de 1 a 30 s por destino; interação antecipa quando configurada. Consentimento e testes são reavaliados no disparo. A análise própria mantém cinco segundos até seu primeiro envio.

GTM pode coexistir com IDs diretos. Google direto usa `send_to`; dataLayer recebe um objeto por evento. O operador deve impedir duplicação no contêiner e em tags do tema. Diagnóstico estático não prova execução: campos/opções e evidência têm cobertura explicitada. O Core não modifica o contêiner GTM.

Consulte META-TRANSPORTE-1.19.md, CLARITY-1.19.md, OFERTAS-MEDICAO.md e ARQUIVOS-PRIVADOS-1.19.md. A ausência de conta autorizada mantém homologações externas pendentes; não é motivo para fabricar resultados nem ativar `servidor` sem prova.
