# Fator3 Site Core 1.24.0

Instale o ZIP instalador em WordPress novo ou atualize exclusivamente a partir da **1.23.0 concluída**. Compatibilidade de integração: **MCP 0.16.0 e MCP Google 0.7.1**. Não há downgrade nem migração a partir de outras versões. O ZIP fonte é para desenvolvimento.

[Documentação instalada](DOCUMENTACAO.md) · [Mudanças e operação](RELEASE-1.24.0.md) · [Medição](MEDICAO-1.24.md) · [Agentes e dados](AGENTES-1.24.0.md) · [Entrega e rastreabilidade](ENTREGA-1.24.0.md) · [Validação](VALIDACAO.md).

A medição passa a registrar saída, tempo visível, profundidade, sistema, navegador, aparelho e novo/recorrente por sessão, com duração por campanha e anúncio. Respostas 404 e editores autenticados ficam fora da audiência e dos destinos geridos pelo Core. Captura, recuperação, executor, migração, redirects e filas do Pipedrive recebem correções de concorrência e retomada.

Leia a documentação no diretório docs do plugin instalado ou em `f3base/documentacao-ler`, com permissão administrativa, inclusive em recuperação. Segredos devem ser colados pelo dono na tela. O campo Clarity continua em Configurações → Clarity, vinculado ao projeto.

Os documentos com versões anteriores no nome são históricos. Tema, implantador e plugins companheiros não são alterados por esta entrega.
