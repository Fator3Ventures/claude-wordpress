# Operação e Search Console — Fator3 Site Core 1.20.0

Contrato de dados/configuração: **5.0.0**. Provider MCP: `base-site-core-fator3`, versão `1.20.0`, `policy_contract: 1`. SDK Google: `search-console-reader/1.0.0`. Estes números representam contratos distintos.

## Instalar e atualizar

Instale `base-site-core-fator3-1.20.0-instalador.zip` em WordPress novo ou sobre **1.19.0**. Uma 1.19.0 cujo marcador existe mas cuja migração não terminou também é aceita. Não há caminho a partir de versões anteriores, nem downgrade. O slug, arquivo principal, text domain e namespace `f3base/` permanecem.

A atualização usa `f3base_release_1200`, com origem, etapas concluídas, tentativa, última falha, próxima tentativa e conclusão. Etapas: padrões ausentes; consentimento/CAPI; leads/análise/Clarity/Meta; integrações; editorial; diário e GSC; pasta privada; verificação de colunas. Valores explícitos, inclusive `false`, `0` e listas vazias, são preservados. A primeira falha aguarda cinco minutos; novas falhas aumentam o intervalo até uma hora. A leitura de saúde não chama a migração. Corrija a causa e aguarde a tentativa agendada ou use o executor quando elegível; não apague marcadores.

A correção do pedido 104 normaliza `schema_versao=3` das linhas CAPI já convertidas ou vazias, inclusive terminais. Não muda estado, tentativas, prazo ou intenção de envio. Cancelamentos novos usam a mesma constante de schema. Atualizar não implica reenviar conversões.

## Agenda e diário

O mesmo registro fechado atende `wp cron event run`, `wp f3base pendentes executar --format=json` e `f3base/executar-pendentes`. O Core só executa seus próprios callbacks. Mantém prioridades relativas entre callbacks Core de um gancho compartilhado e os argumentos originais de cada ocorrência. Callbacks de outros plugins não são incorporados ao executor.

Famílias: migração; logs e continuação; catálogo editorial; Clarity e retomada; GSC e continuação; redes de robôs; LLMS e regeneração; robots; ofertas; navegação e repetição; schema; cache; GTM; CAPI por registro e fila; avisos/respostas/manutenção; Pipedrive e eliminação; anúncios Meta; verificação de integrações; retenção; cadência.

| Trabalho periódico | Horário padrão no fuso WordPress |
|---|---|
| Redes oficiais de robôs | 02:00 |
| Clarity | 03:00 |
| GTM | 04:00 |
| Search Console | 05:00, configurável |
| Navegação e verificação periódica de ofertas | 00:00 e 12:00 |
| Manutenção/avisos horários | Minuto 00 |

Preferências próprias de logs, cache, retenção e cadência continuam vigentes. Retentativas, envio de filas e continuações continuam relativas. Previsão não é garantia de execução: depende de um disparo do cron. O plugin não altera crontab, wp-config.php ou DISABLE_WP_CRON.

Cada passagem tem até três trabalhos e orçamento compartilhado de 30 segundos, propagado para chamadas HTTP. Há margem para persistência; GSC entrega ao Google no máximo 20 segundos, já descontada a margem Core, e o Google reserva sua própria margem. O orçamento é cooperativo: PHP, banco e sistema operacional não oferecem cancelamento rígido de toda instrução. Trabalho não iniciado por falta de orçamento é reagendado, conservando os argumentos.

Reserva de arquivo por tarefa e reserva no banco evitam sobreposição. O diário identifica a ocorrência por gancho, argumentos e timestamp, separado do mecanismo de entrada. O cron nativo cuida do consumo/reagendamento nativo; o executor explícito consome somente a ocorrência selecionada.

### Origens e interpretação

- `cli`: `defined('WP_CLI') && WP_CLI`, com precedência sobre DOING_CRON.
- `http_cron`: `wp_doing_cron()`, inclusive disparo provocado por visita.
- `manual`: ação administrativa de rota, ability ou painel. O cliente não escolhe a origem.

`f3base/saude-ler`, `f3base/como-usar` e `f3base/executar-pendentes` apresentam o bloco `execucoes`: `ultima_cli.at`, `ultima_http.at`, `ultima_manual.at`, contagens por origem e janela. As últimas passagens são independentes. A janela é `(agora−86400, agora]`; conta passagens, não subtarefas. Falhas e execuções sem trabalho são incluídas. `wp cron event run` sem tarefa Core registra escopo `invocacao_cli`, `core_examinado:false`, `sucesso:null`; isso prova a invocação observada, não uma tarefa concluída. Consultar `wp f3base status` não conta passagem.

`cron_servidor_ativo` indica passagem CLI observada nas últimas duas horas; `cron_servidor_ultima_em` conserva o instante. Uma chamada CLI manual produz a mesma evidência. **Não comprova a configuração do crontab** (`agendamento_verificado:false`). O início de observação e a cobertura da janela evitam tratar um diário recém-criado como 24 horas completas. Registros antigos genéricos não são reclassificados retroativamente.

Após retomada de recuperação, a janela volta a incompleta por 24 horas; o histórico antigo continua consultável.

Histórico paginado: `f3base/execucoes-ler`, filtros `origem`, `run_id`, `pagina` (50 registros). A interface fica em **Site Core → Configurações → Operação**. Datas armazenadas em segundos UTC; telas também mostram data, hora e fuso WordPress. `run_id` une passagem e subtarefas; não identifica visitante. Por padrão, esse diário não expira automaticamente.

## Recuperação coordenada

A barreira Core fica em `wp-content/f3-core-state/site-<blog_id>.php`, com arquivos de trava no mesmo diretório. É independente do banco e dos arquivos do plugin. Conteúdo protegido por arquivo PHP; diretório não deve ser servido como texto por configuração inadequada do servidor. Não mova/apague/restaure essa pasta junto de um snapshot antigo enquanto a recuperação está em curso. O WordPress é de instalação única; todos os processos do site precisam compartilhar essas travas de arquivo.

1. Leia `f3base/operacao-recuperacao-ler` ou `wp f3base operacao recuperacao ler --format=json`.
2. Execute `f3base/operacao-recuperacao` com `acao: preparar` e `geracao_esperada` lida. CLI: `wp f3base operacao recuperacao preparar --geracao=N --format=json`.
3. Aguarde `pronto_para_restaurar:true`. `aguardando_drenagem` significa processo Core ainda em execução: consulte/repita preparar. A pausa impede novos trabalhos, migrações e mutações Core; o cron não descarta suas ocorrências durante a pausa.
4. Prepare separadamente a recuperação do MCP Google pelo contrato dele. A resposta Core cobre **somente Core**. Não restaure uma base compartilhada enquanto outros escritores necessários continuam ativos. O Core não chama APIs privadas de recuperação dos outros plugins.
5. Restaure o conjunto coerente de banco, conteúdo privado e salts conforme o procedimento da hospedagem, preservando a barreira atual. Reconcile efeitos externos: envio de e-mail, Meta e CRM não são desfeitos por uma restauração local.
6. Retome explicitamente com `acao: retomar`, a geração esperada e `reconciliacao_confirmada:true`. CLI: `wp f3base operacao recuperacao retomar --geracao=N --reconciliacao-confirmada --format=json`. A geração aumenta; cursores e reservas obsoletos deixam de ser usados. Uma geração divergente exige nova leitura.

Filas externas restauradas em estado pendente/em envio são suspensas para revisão, sem reenvio automático. Avisos e respostas pendentes passam a incertos; reenvios seguem os controles explícitos existentes, incluindo aceite de possível duplicação. Intenções Pipedrive restauradas recebem `reconciliacao_necessaria`, impedindo recriação automática de uma fila que não existia no snapshot; não remova esse sinal sem conferir a conta remota. Eliminações remotas pendentes também são suspensas. Contatos e acervos não são descartados. Sentinela ausente/ilegível após instalação concluída bloqueia a operação; recupere o estado operacional de forma coordenada, não simule um arquivo vazio.

## Configurar Search Console

O Core não guarda token Google, chave de conta técnica ou refresh token. MCP Google **0.7.0** fornece o transporte autorizado; MCP **0.15.0** fornece o canal com políticas próprias. Ter o canal MCP não autoriza por si só o consumidor GSC.

1. Configure uma conexão Google com acesso de leitura ao Search Console e à propriedade correta, seguindo a documentação instalada do Google.
2. Conclua a transição 0.7 nessa conexão. Uma lease antiga não prova que o processo 0.6 terminou; o operador confirma a drenagem quando o Google exigir. O Core não importa automaticamente a configuração antiga nem confirma essa transição.
3. Em Site Core → Configurações → Medição e anúncios, grave `f3base_gsc_property` usando a revisão do contrato Core. Pode ser `sc-domain:exemplo.com` ou prefixo URL que abrange o site. Um domínio pai cobre subdomínios por limite DNS; `ample.com` não cobre `example.com`. Prefixos conferem esquema, host, porta e limite de caminho. `www` não é removido artificialmente.
4. `f3base_gsc`: `ativo:true`, `horario:"05:00"`, `inicio:""` são os padrões. Vazio começa nos últimos 30 dias finalizáveis. Para histórico anterior, defina uma data inicial explicitamente. Ativo sem SDK/propriedade/concessão não produz consulta remota.
5. No Google, conceda `gsc.page-day.read` ao consumidor `base-site-core-fator3` em **exatamente uma conexão**, pelo serviço público `google/configure-consumer`, com a revisão Google vigente. A configuração Core não concede essa permissão.
6. Confira `f3base/gsc-status`; para uma passagem administrativa use `f3base/gsc-coletar`. Para executar somente vencidos, `f3base/executar-pendentes` com `tarefas:["gsc"]`. Permissão, transição e quotas continuam obrigatórias.

O Core registra o consumidor no hook `f3_mcp_google_register_consumers`, antes de `plugins_loaded` prioridade 30, fornecendo propriedade, revisão e prontidão estrutural. Chama o objeto cliente retornado. Não lê options privadas Google nem imita usuário para cron.

**Escopo do diagnóstico Google 0.7:** `client.status()` mostra a conexão corrente/padrão. A consulta resolve a concessão única entre conexões. Portanto `grant:null`, `configured:false` ou transição pendente no status padrão não bloqueiam automaticamente uma concessão válida em outra conexão. A resposta da consulta identifica `connection_id`; para diagnóstico dirigido use `google/integration-status` com a conexão pertinente.

## Coleta, publicação e limites

- Dias de dados: **America/Los_Angeles**; agenda: fuso WordPress. Automação vai até D−3, revisita D−3 a D−5 e alterna essas revisitas com lacunas antigas. O cron continua em lotes.
- Consulta fixa: `date,page`, `type:web`, `dataState:final`, agregação por página, sem filtros. Não aceita URL de API, credencial ou conexão arbitrária do agente.
- Cada página recebida fica em estágio. Linhas e cursor são confirmados na mesma transação. Só um dia com paginação concluída publica sua fotografia na projeção `f3base_gsc_diario`, substituindo inclusive linhas antigas ausentes da fotografia nova. Uma repetição não soma métricas novamente.
- Coletas anteriores, versões de linhas, cobertura, recibos, IDs da requisição/passagem/conexão e instantes ficam no acervo. Histórico 1.19 é arquivado com cobertura desconhecida; não é inventado um recibo completo.
- `success:false`, inclusive resposta útil em `query_result`, nunca avança cursor nem publica. Falha de auditoria Google é falha do serviço. Respeitam-se adiamento/cota e orçamento, sem retry HTTP interno no mesmo lote. Erro não retentável fica diagnosticado e aguarda a próxima janela; configuração Core nova invalida o curso anterior.
- Cursor vale até 24 horas e está vinculado à configuração/credencial/política/concessão/limite pelo Google. Invalidação reinicia o dia preservando a fotografia publicada. Duplicata com métricas divergentes marca paginação inconsistente; não mistura páginas divergentes num dia completo.
- `page_pending`: há outra página. `api_daily_row_limit`: limite conhecido de 50.000 linhas/dia, sem cursor; fica **limitada**, não completa e sem continuação infinita. `pagination_complete:true` encerra somente a paginação observada. **`all_rows_guaranteed:false` sempre**.
- Resposta vazia gera recibo de dia sem linhas e não inventa zeros por URL. Dados finais disponíveis não equivalem a todas as buscas existentes no fornecedor.
- URLs de outros hosts/subdomínios são preservadas, classificadas fora deste site; não se associam a posts somente pelo caminho. Associação a conteúdo exige autoridade e permalink correspondentes.
- O histórico GSC não expira automaticamente por padrão. Dimensione banco e backups; reduzir histórico não é efeito implícito desta atualização.

## Relatórios, importação manual e cruzamentos

**Medição → Aquisição → Search Console** mostra propriedade, período, páginas/artigos, ID de conteúdo, dados publicados, histórico e cobertura. Outras propriedades podem ser selecionadas como histórico; não misture universos. A importação manual `f3base/gsc-importar` continua autenticada, com origem/operador registrados. Fotografia manual parcial permanece no acervo e não substitui um dia final. Fotografia completa final pode publicar seu universo/dia conforme o instante de extração.

Universo é propriedade + pesquisa + escopo + filtros, com dimensões fixadas pelo contrato aceito. CTR = soma de cliques / soma de impressões; posição = soma(posição × impressões) / soma(impressões). Não some percentuais ou médias simples. Totais de páginas não substituem totais de propriedade. GSC não se une a visitantes/sessões individuais; comparação editorial usa conteúdo e períodos, deixando distintos os calendários. GSC não mede indicação/citação por IA.

Use `f3base/gsc-historico` com `propriedade`, `dia`, `pagina`; `id` seleciona uma fotografia e `pagina_linhas` pagina suas linhas (500). Cursores não são retornados. Use `f3base/documentacao-ler` para o índice, este guia, schemas `dados/abilities-*.json` e `dados/contrato.json`.

## Relações no banco

| Tabela | Granularidade e relação |
|---|---|
| `f3base_execucoes` | Passagem ou tarefa; `parent_run_id → run_id`; origem, entrada, resultado e ocorrência independentes |
| `f3base_gsc_coletas` | Tentativa/fotografia por universo e dia; `publicado=1` identifica a fotografia atual |
| `f3base_gsc_linhas` | URL por coleta; `(coleta_id,chave)` única; `coleta_id → coletas.id` |
| `f3base_gsc_diario` | Projeção publicada compatível com relatórios; não somar com as linhas do acervo |

A documentação de tabelas inclui tipos/índices reais em `DICIONARIO-DADOS.md`. IDs são opacos, UTC são segundos inteiros, `dia` GSC é data no Pacífico. Consultas SQL de exemplo são somente leitura. Nunca use SQL para contornar autorização, revisão, concessão ou barreira de recuperação.
