# Encaminhamento Core 1.23.0 → MCP

Compatibilidade exclusiva: Core 1.23.0, MCP 0.16.0, MCP Google 0.7.1. Core aceita instalação nova ou atualização da 1.22.1 concluída. Os arquivos dos outros plugins não foram modificados.

A bancada carregou os códigos finais recebidos dos dois plugins, em processos novos e nas duas ordens de carga, tanto na instalação nova quanto na atualização. Foram confirmados versões/contratos, registro frio do consumidor Core, diagnóstico efetivo e permissão da documentação. Isto não é prova de OAuth/Google remotos nem de restore real da frota. Foram usados os arquivos extraídos dos ZIPs-fonte recebidos; hashes de instaladores declarados pelos fornecedores não são apresentados como hashes recalculados.

MCP: mantidos server-integration/1.0.0 e policy_contract 1. Não são criados grants ou capabilities para o usuário por essa integração. A retomada dirigida e executar_agora mantêm permissões administrativas e simulação.

Acrescente esta combinação à documentação de compatibilidade. Inclua `f3base_operacao_intencoes`, `f3base_consentimento_reparos` e `f3base_leads.decisao_ref` no inventário de backup/diagnóstico do Core. Estados pendentes/esgotados são duráveis, não descartar por idade. Contrato Core 6.0.0; chave documental estável; alias documentacao_1210 removido. A UI de segredo pertence ao dono, não ao agente.

Recuperação: Core usa `manter_pausado:true`; não renomear para keepPause. Guardas e grants continuam independentes. A confirmação do transporte de e-mail e a verificação local do serviço não comprovam resultado externo.
