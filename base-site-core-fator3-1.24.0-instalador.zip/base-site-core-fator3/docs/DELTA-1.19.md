> Documento da entrega 1.19, preservado para referência. Para atualizar e para operação/GSC na 1.20, leia OPERACAO-GSC-1.20.md.

# Alterações por site — 1.19.0

## Delta por site

- **Banco:** cinco tabelas novas: `{prefixo}f3base_arquivos_blobs`, `f3base_arquivos_operacoes`, `f3base_meta_eventos`, `f3base_clarity_coletas` e `f3base_clarity`. Leads schema 5 acrescenta vínculo de blob/MIME/origem/atualização em arquivos. Análise ganha contexto de ofertas; agregados de acessos ganham assinatura reduzida/regra nas dimensões e chaves. Fila CAPI schema 3 acrescenta nome/instante/rota/prazo/hash/classe e cifra payload pendente. Colunas, tipos e todos os índices estão em `docs/dados/contrato.json`.
- **Options:** marcador `f3base_release_1190` registra origem/checkpoints/defaults. Somente chaves ausentes recebem padrões: autoConfig, políticas/prazos de carregamento, Meta, Clarity e hosts de confirmação. `false`, zero, listas vazias, todas as opções de canal e credenciais existentes permanecem. CAPI Lead configurada na base recebe ambos/Lead; PageView CAPI não é ativado implicitamente. Estados técnicos de Clarity/cota/credencial e Meta/prova são criados conforme uso.
- **Cache:** sem novo parâmetro ou exclusão em `wp-cache-config.php`; sem alteração de diretivas no bloco `F3BASE MANAGED`. Regras/provas existentes seguem serviços próprios. Não há mudança de infraestrutura ou do tema.
- **Privados:** provisionamento conferido na instalação; novas importações/substituições usam blobs e recibos privados. Origem pública nunca é removida automaticamente. Concessões válidas seguem versão nova; limites/revogação/expiração permanecem.
- **Cron:** prova de navegação a cada 12 h com retentativa, coleta Clarity quando configurada, continuidade e limpezas próprias. Executor parado implica atraso declarado; não se promete execução por relógio sem WordPress/cron.
- **Coleta:** ofertas e contexto de conversão, assinatura técnica reduzida, histórico analítico Clarity e transporte Meta conforme configuração/consentimento. Sem IDs novos não se ativa Clarity/GTM. A fila Meta pode guardar IP/UA cifrados além de 24 h quando ainda úteis; teto de sete dias e janela externa aplicável, sem renovação, com remoção terminal. Sem janela confirmada vigente usa uma hora. Histórico Clarity tem retenção zero (sem expiração automática) por padrão.
- **Séries:** resumo integrado passa à mesma audiência editorial; registrar o corte UTC de atualização por site. Histórico sem evidência conserva lacuna/indisponibilidade. Não somar janelas Clarity, visitantes diários ou robôs como pessoas.
- **Documentação instalada:** guias por recurso, catálogo de opções/ajuda, schemas das abilities, tabelas/índices, SQL de leitura, rastreabilidade, operação e validação. Agente lê `docs/` ou `f3base/documentacao-ler` autenticado.

## Instalação e recuperação

Instale **base-site-core-fator3-1.19.0.zip** sobre a 1.18.0 concluída ou em site novo. O ZIP de fontes serve para auditoria/desenvolvimento, não para a tela de plugins. Faça o backup operacional e confira versão, marcador concluído, saúde, pasta privada, menu e envio marcado como teste. Novos fornecedores dependem de IDs/tokens e escolha explícita.

Recuperação é retomada na própria 1.19.0: corrigir a causa, reinstalar os mesmos arquivos quando necessário e executar atualização/pendências. Não apagar marcadores nem fazer downgrade. Preserve banco, pasta privada e salts de forma protegida; não restaure banco antigo sobre contatos novos. O guia `docs/OPERACAO-E-RECUPERACAO.md` detalha filas, acervos e backup.

A implementação não acessou nem instalou em produção. O destino GitHub previsto no plano não foi publicado por esta tarefa. Homologações por conta/site estão em VALIDACAO.md e no mapa; o dono realiza os testes em korvena.net.br.
