# Encaminhamento final ao MCP Google — Core 1.22.0

06/10/2026. Revisão 2; conciliada com o encaminhamento Google 0.7.1 revisão 5. Implementado no Core, sem modificar o plugin Google. Não houve consulta GSC real nem validação de credenciais externas. Este texto substitui o encaminhamento planejado da revisão 1 quanto ao comportamento entregue.

Preservado SDK `search-console-reader/1.0.0`. `effective_status` permanece opcional, anunciado em capabilities.client_methods; ausência de anúncio mantém fallback status(). Método anunciado, mas indisponível, resulta em unreadable/diagnostico_sdk_indisponivel, sem chamar status(). O Core diferencia resolved, not_granted, ambiguous e unreadable, além de exceção/retorno inválido. Resolução local não comprova consulta remota ou commit de dados. O Google continua responsável por sanear local_status aninhado e conferir sua autorização.

Prova local de domínio agora usa propriedade normalizada, home/host, hash PSL e versão do pacote. Evita abrir a lista a cada requisição; alteração relevante invalida a prova. Não amplia concessão nem usa configuration_revision administrativo do Google como revisão da propriedade Core.

Executor conserva a ocorrência, registra tentativas recusadas e permite cron sem usuário autenticado. Evidência CLI Core não certifica passagem pelo executor Google. Diagnóstico de commit/atendimento Google deve continuar separado do diário Core.

Documentação autenticada funciona com Core inerte. Recriar guarda admite manter_pausado: true e termina sem prontidão presumida; preparar/drenar continuam obrigatórios para restore. Guardas independentes: prepare ambos, restaure/reconcilie e retome Google antes do Core. Confira efeitos de suspensão/invalidação além da seleção SQL.

Lacunas GSC permanecem no histórico durante atualização; a tabela foi incluída no inventário de desinstalação, seguindo a limpeza analítica já existente do Core. O importador e seu contrato não foram transferidos nem alterados nesta release.

Validação local: mock do contrato SDK com as quatro resoluções, exceção, retorno inválido e fallback; prova persistente testada com PSL temporariamente indisponível após validação, e invalidação por mudança de host. Não representa homologação dos pacotes Google 0.7.0/0.7.1 reais nem autorização da propriedade na conta.

Ação ao Google: conferir anúncio do método opcional, sanitização aninhada, descoberta em ambas as ordens e seus fluxos de pausa/restore; testar consulta/commit reais na homologação autorizada. Não foi identificada mudança obrigatória no SDK para estas correções Core.

Conciliação com a revisão 5 recebida: as três correções antes planejadas estão implementadas e testadas localmente (textos por resolução, documentação administrativa em requisição inerte e recriação com `manter_pausado:true`). Os schemas entregues usam esse nome definitivo. Recriar pausado continua diferente de preparar/drenar. A matriz futura continua condicionada ao pacote Google 0.7.1 real; o documento recebido ainda o identifica como planejado. Não afirmar homologação conjunta, nem ampliar a compatibilidade de instalação Core para 1.20.

Adendo 135: campo humano e teste de token Clarity no Core. Não depende de Google/MCP, não muda concessões nem consome orçamento Google. Nenhuma credencial deve ser transportada pelo agente para cadastrar Clarity. Instalador e fonte Core desta revisão substituem os arquivos anteriores da mesma entrega; hashes atuais estão em SHA256SUMS.txt e no relatório.
