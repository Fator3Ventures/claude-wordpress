-- Core 1.19.0 / contrato de dados 4.3.0. Somente SELECT.
-- Consultas simples são ilustrativas; para paridade com anotações, cobertura,
-- classificação efetiva e todos os filtros, use as abilities documentadas.
-- {{prefix}}: substituir apenas pelo prefixo real e validado do site ($wpdb->prefix).
-- :inicio_utc / :fim_utc: datas DATETIME UTC, início inclusivo / fim exclusivo.
-- :inicio_epoch / :fim_epoch: os mesmos limites em epoch de segundos.
-- :classe: 'nao_marcado' ou 'teste'; para Todos, remover o predicado deliberadamente.
-- :caminho: caminho normalizado da página, nunca URL com query de campanha.
-- IDs permanecem strings. Preparar valores pelo driver; não concatenar entrada livre.
-- Limitar período (1 a 90 dias) e conferir retenção, fuso e versão antes da leitura.

-- consulta: envios_aceitos
-- Reproduz totais.envios da ability sem outros filtros; uma linha, sem multiplicação.
SELECT COUNT(*) AS envios
FROM {{prefix}}f3base_leads
WHERE criado_em >= :inicio_utc AND criado_em < :fim_utc
  AND classe_trafego = :classe AND lixeira = 0 AND eliminacao_pendente = 0
  AND captura = 'aceito' AND atendimento <> 'spam'
  AND metodo IN ('formulario','whatsapp_formulario','conteudo');

-- consulta: anuncios_v1
-- Grupos com molde v1. Não soma cliques como envios; não inclui atribuição antiga sem molde.
-- Preagregar aqui antes de unir com gasto externo na MESMA chave/granularidade.
SELECT
  JSON_UNQUOTE(JSON_EXTRACT(IF(JSON_VALID(dados),dados,'{}'),'$.atribuicao.utm_source_platform')) AS plataforma,
  JSON_UNQUOTE(JSON_EXTRACT(IF(JSON_VALID(dados),dados,'{}'),'$.atribuicao.f3_ads_account_id')) AS conta_id,
  JSON_UNQUOTE(JSON_EXTRACT(IF(JSON_VALID(dados),dados,'{}'),'$.atribuicao.utm_id')) AS campanha_id,
  JSON_UNQUOTE(JSON_EXTRACT(IF(JSON_VALID(dados),dados,'{}'),'$.atribuicao.f3_ads_group_id')) AS grupo_id,
  JSON_UNQUOTE(JSON_EXTRACT(IF(JSON_VALID(dados),dados,'{}'),'$.atribuicao.utm_content')) AS anuncio_id,
  COUNT(*) AS envios
FROM {{prefix}}f3base_leads
WHERE criado_em >= :inicio_utc AND criado_em < :fim_utc
  AND classe_trafego = :classe AND lixeira = 0 AND eliminacao_pendente = 0
  AND captura = 'aceito' AND atendimento <> 'spam'
  AND metodo IN ('formulario','whatsapp_formulario','conteudo') AND JSON_VALID(dados)
  AND JSON_UNQUOTE(JSON_EXTRACT(IF(JSON_VALID(dados),dados,'{}'),'$.atribuicao.f3_ads_v')) = '1'
GROUP BY BINARY plataforma, BINARY conta_id, BINARY campanha_id, BINARY grupo_id, BINARY anuncio_id,
         plataforma, conta_id, campanha_id, grupo_id, anuncio_id;

-- consulta: sessoes_pagina
-- Fonte canônica 1.19: análise. Não somar com eventos ou distintos diários.
-- Para exclusões anotadas/canal/conteúdo e histórico expirado, usar medicao-editorial.
SELECT COUNT(DISTINCT sessao) AS sessoes_observadas
FROM {{prefix}}f3base_analise
WHERE criado_em >= :inicio_epoch AND criado_em < :fim_epoch
  AND classe_trafego = :classe AND caminho = :caminho AND tipo = 'pagina'
  AND automacao = 'nao_identificada' AND sessao <> '';

-- consulta: cobertura_sessao
-- Reproduz cobertura.elegiveis/com_sessao sem outros filtros, incluindo intenções CTA.
SELECT COUNT(*) AS elegiveis,
       SUM(CASE WHEN sessao IS NOT NULL AND sessao <> '' THEN 1 ELSE 0 END) AS com_sessao
FROM {{prefix}}f3base_leads
WHERE criado_em >= :inicio_utc AND criado_em < :fim_utc
  AND classe_trafego = :classe AND lixeira = 0 AND eliminacao_pendente = 0
  AND captura <> 'suspeito' AND atendimento <> 'spam'
  AND (metodo IN ('whatsapp_cta','contato_cta') OR
       (captura = 'aceito' AND metodo IN ('formulario','whatsapp_formulario','conteudo')));

-- consulta: primeira_resposta
-- Uma linha por lead com marcação; não se junta todo o histórico aos contatos.
-- Calcular p75 sobre as durações; não tirar média de percentis de dias diferentes.
SELECT l.record_id, l.formulario,
       GREATEST(0,h.primeira - TIMESTAMPDIFF(SECOND,'1970-01-01 00:00:00',l.criado_em)) AS segundos
FROM {{prefix}}f3base_leads AS l
JOIN (SELECT record_id,MIN(em) AS primeira FROM {{prefix}}f3base_atendimento_historico
      WHERE atual = 'respondido' GROUP BY record_id) AS h ON h.record_id = l.record_id
WHERE l.criado_em >= :inicio_utc AND l.criado_em < :fim_utc
  AND l.classe_trafego = :classe AND l.lixeira = 0 AND l.eliminacao_pendente = 0
  AND l.captura <> 'suspeito' AND l.atendimento <> 'spam'
  AND (l.metodo IN ('whatsapp_cta','contato_cta') OR
       (l.captura = 'aceito' AND l.metodo IN ('formulario','whatsapp_formulario','conteudo')));


-- 1.16: estado de captura e CRM, sem duplicar contatos. Substitua wp_ pelo prefixo real.
SELECT l.record_id,l.metodo,l.classe_trafego,q.estado,q.codigo,q.tentativas,q.concluido_em
FROM wp_f3base_leads l LEFT JOIN wp_f3base_pipedrive_fila q ON q.record_id=l.record_id
WHERE l.criado_em >= '2026-09-29 00:00:00' AND l.criado_em < '2026-09-30 00:00:00'
  AND l.classe_trafego='nao_marcado' ORDER BY l.criado_em LIMIT 200;

-- Recibo nativo pode sobreviver ao contato eliminado. Não juntar por e-mail.
SELECT r.origem,r.conta,r.formulario,r.nativo_id,r.record_id,r.eliminado,l.metodo
FROM wp_f3base_anuncios_recibos r LEFT JOIN wp_f3base_leads l ON l.record_id=r.record_id
ORDER BY r.recebido_em DESC LIMIT 200;

-- Identificação OpenAI sem expor o oppref bruto em relatório.
SELECT record_id,JSON_UNQUOTE(JSON_EXTRACT(dados,'$.atribuicao.plataforma')) AS plataforma,
 JSON_UNQUOTE(JSON_EXTRACT(dados,'$.atribuicao.campanha_id')) AS campanha_id,
 JSON_UNQUOTE(JSON_EXTRACT(dados,'$.atribuicao.anuncio_id')) AS anuncio_id
FROM wp_f3base_leads WHERE classe_trafego='nao_marcado'
 AND JSON_UNQUOTE(JSON_EXTRACT(dados,'$.atribuicao.plataforma'))='openai_ads'
ORDER BY criado_em DESC LIMIT 200;


-- Core 1.17: somente SELECT. Substitua wp_ pelo prefixo real, nunca escreva direto.
-- Sem somar distintos diários; use detalhe retido e o mesmo segmento.
SELECT post_id, COUNT(DISTINCT sessao,navegacao) AS visualizacoes,
       COUNT(DISTINCT sessao) AS sessoes
FROM wp_f3base_analise
WHERE tipo='pagina' AND classe_trafego<>'teste'
  AND automacao='nao_identificada' AND criado_em>=1790294400 AND criado_em<1790380800
GROUP BY post_id;

-- Histórico anônimo: uma contribuição por dia/métrica. Não representa únicos.
SELECT dia,post_id,canal,metrica,SUM(contagem) AS quantidade,SUM(soma) AS soma
FROM wp_f3base_editorial_diario
WHERE dia BETWEEN '2026-09-01' AND '2026-09-29'
  AND classe_trafego<>'teste' AND automacao='nao_identificada'
GROUP BY dia,post_id,canal,metrica;

-- IA por conteúdo e formato; manter método/status/rede separados.
SELECT post_id,agente,representacao,metodo,status,rede_estado,SUM(contagem) AS requisicoes
FROM wp_f3base_acessos
WHERE dia BETWEEN '2026-09-01' AND '2026-09-29' AND classe_caminho IN ('pagina','descoberta')
GROUP BY post_id,agente,representacao,metodo,status,rede_estado;
-- Essa consulta inclui buscadores convencionais: filtre famílias conforme o catálogo TSV.
-- Confira cobertura em agentes-relatorio antes de interpretar ausência como zero.

-- GSC: universo separa propriedade, filtros e pesquisa; calendário do Pacífico.
SELECT universo,post_id,SUM(cliques) AS cliques,SUM(impressoes) AS impressoes,
  SUM(cliques)/NULLIF(SUM(impressoes),0) AS ctr,
  SUM(posicao*impressoes)/NULLIF(SUM(impressoes),0) AS posicao_media
FROM wp_f3base_gsc_diario WHERE escopo='paginas'
GROUP BY universo,post_id;

-- 1.19: inventário local Clarity, sem sumarizar métricas de janelas sobrepostas.
SELECT id,projeto,parametros,origem,solicitado_em,recebido_em,duracao_ms,
       inicio_nominal,fim_nominal,estado,sha256,parser,saneamento,cobertura
FROM {{prefix}}f3base_clarity_coletas
WHERE projeto=:projeto AND solicitado_em>=:inicio_epoch AND solicitado_em<:fim_epoch
ORDER BY solicitado_em,id LIMIT 100;

-- Todas as métricas/dimensões de uma consulta, sem explosão por join de outras consultas.
SELECT bloco,linha,metrica,dimensoes,valores,post_id,caminho,estado
FROM {{prefix}}f3base_clarity WHERE coleta=:coleta AND parser=:parser
ORDER BY bloco,linha LIMIT 100;

-- Conciliação Meta por hash do evento; payload/IP não integram esta leitura.
SELECT e.evento,e.nome,e.criado_em,e.rota,e.classe_trafego,e.navegador_observado,
       q.estado,q.tentativas,q.expira,q.http,q.motivo
FROM {{prefix}}f3base_meta_eventos e
LEFT JOIN {{prefix}}f3base_capi_fila q ON q.evento_hash=e.evento
WHERE e.criado_em>=:inicio_epoch AND e.criado_em<:fim_epoch AND e.classe_trafego=:classe
ORDER BY e.criado_em,e.evento LIMIT 100;
-- Fila pode ter sido limpa pela retenção: NULL não significa nunca enviado.
-- Para agrupamento diário e agenda/limites efetivos use meta-entregas-ler.

-- Assinaturas técnicas na raiz; ferramenta não prova operador.
SELECT assinatura_ua,assinatura_regra,agente,rede_estado,SUM(contagem) AS requisicoes
FROM {{prefix}}f3base_acessos
WHERE dia BETWEEN :dia_inicio AND :dia_fim AND caminho='/'
GROUP BY assinatura_ua,assinatura_regra,agente,rede_estado;
-- IA efetiva e parcela sem operador: agentes-relatorio com incluir_tecnico=true.

-- Core 1.20: apenas leitura. Substituir wp_ pelo prefixo validado do site.
-- Contagem de passagens, sem somar subtarefas; UTC e janela móvel.
SELECT origem, COUNT(*) passagens, MAX(inicio) ultima_em
FROM wp_f3base_execucoes
WHERE parent_run_id = '' AND inicio > UNIX_TIMESTAMP() - 86400 AND inicio <= UNIX_TIMESTAMP()
GROUP BY origem;

-- Fotografia publicada por universo/dia: não somar versões históricas.
SELECT c.propriedade,c.dia,c.universo,COUNT(l.chave) urls,
       SUM(l.cliques) cliques,SUM(l.impressoes) impressoes,
       SUM(l.cliques)/NULLIF(SUM(l.impressoes),0) ctr,
       SUM(l.posicao*l.impressoes)/NULLIF(SUM(l.impressoes),0) posicao_media
FROM wp_f3base_gsc_coletas c
LEFT JOIN wp_f3base_gsc_linhas l ON l.coleta_id=c.id
WHERE c.publicado=1 AND c.dia BETWEEN '2026-09-01' AND '2026-09-30'
GROUP BY c.propriedade,c.dia,c.universo;
