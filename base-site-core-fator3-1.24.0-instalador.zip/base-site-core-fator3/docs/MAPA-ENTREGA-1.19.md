> Documento da entrega 1.19, preservado para referência. Para atualizar e para operação/GSC na 1.20, leia OPERACAO-GSC-1.20.md.

# Mapa da entrega — 1.19.0

Plano aprovado preservado em PLANO-APROVADO.md nos fontes. Implementado refere-se ao pacote local, não ao encerramento de aceites na frota. Linhas identificam esta versão; documentação/schemas detalham os contratos.

| Pedido | Comportamento entregue | Código | Evidência local | Restante / limite |
|---|---|---|---|---|
| R119-01 | Contatos → Relatórios usa menu registrado antes da validação e admin.php; clique real sem 404. | `includes/class-f3base-leads-admin.php:205` | fundacao.json; forms-browser.json | Conferência do menu por site. |
| 17 | Confirmação genérica, três regimes JS/sem JS, mensagens, assunto com nome, MIME/limites PHP e estilo; preservar resumo de avisos e 410. | `includes/class-f3base-confirmacao.php:19` | forms-browser.json; regressoes-adicionais.json | SMTP/caixa autorizada e páginas do tema. |
| 82 | Classificação efetiva suspeita para IA fora de faixas válidas; conserva agente/rede declarados e total. | `includes/class-f3base-agentes-classificacao.php:9` | relatorios-ia.json | Confiança no IP de origem e cobertura dos logs do site. |
| 83 | IA por página/artigo, HTML/Markdown, método/status/rede, instantes, semanas e sessões vindas de IA; descoberta separada. | `includes/class-f3base-editorial-relatorios.php:10` | relatorios-ia.json; editorial.json | Leitura é requisição observada; servidor não mede citação/recomendação. |
| 88 | Fonte canônica analise e coorte comum entre editorial, integrado, CSV e abilities; filtros e cobertura preservados. | `includes/class-f3base-relatorios.php:26` | relatorios-ia.json; editorial.json | Séries antigas sem dados não são reconstruídas. |
| 90 | Assinatura reduzida em agregados, filtro técnico e volume em / com sem_operador_identificavel separado. | `includes/class-f3base-agentes-classificacao.php:14` | relatorios-ia.json; ui.json | Ferramenta não identifica operador; histórico depende do log disponível. |
| 92 | Renovação de prova por cron sem usuário, trava, invalidação e retentativa; permissão administrativa mantida. | `includes/class-f3base-navegacao.php:45` | fundacao.json | Execução diária efetiva do cron é aceite operacional. |
| 93 | autoConfig false antes de init; PageView/Lead explícitos preservados. | `includes/class-f3base-modulo-tracking.php:837` | carregadores.json | Comportamento de eventos automáticos do Pixel real. |
| 94 | Meta PageView/Lead por navegador/ambos/servidor, conciliação, prova, payload cifrado e prazo útil até sete dias conforme janela confirmada. GA4 segue tag. | `includes/class-f3base-meta-transporte.php:78` | meta-ofertas.json; meta-ofertas-browser.json; carregadores.json | Janelas oficiais, deduplicação e sete dias antes/depois na conta por site. |
| 95 | Ocioso pós-load e teto independente com fallback, consentimento, revogação e idempotência. | `includes/class-f3base-modulo-tracking.php:837` | carregadores.json | Benchmarks repetidos e métricas de campo não executados. |
| 96 | Abilities de cadastro/listagem/substituição, blobs imutáveis, CAS/hash e concessões vigentes seguem arquivo novo; mídia pública preservada por padrão. | `includes/class-f3base-arquivos-servico.php:59` | arquivos.json; regressoes-adicionais.json; forms-browser.json | Operação da pasta privada e backup na hospedagem. |
| 97 | Contrato de oferta do tema, instância/visibilidade, eventos, frequência e funil com aceites do servidor; GA4/GTM sob consentimento. | `includes/class-f3base-ofertas-medicao.php:20` | meta-ofertas.json; meta-ofertas-browser.json | Tema implementa apresentação; recebimento GA4 em conta autorizada. |
| 98 | Provider/policy_contract em todo catálogo, perfil Leitura sem escrita, capabilities WP e Update URI próprio; Core sem MCP. | `includes/class-f3base-servicos.php:7` | mcp.json; fundacao.json | Configuração das conexões da frota. |
| 99 | GTM aditivo, send_to direto, objeto canônico por evento, destino CAPI independente e diagnóstico de duplicação. | `includes/class-f3base-tracking-diagnostico.php:16` | carregadores.json; fundacao.json | Contêiner e tags de terceiros são responsabilidade do operador. |
| 100 | Clarity opcional no navegador, consentv2, máscara, revogação, testes e estratégia própria; token só no servidor. | `includes/class-f3base-clarity.php:15` | carregadores.json; clarity.json | Mascaramento e custo do SDK real exigem homologação. |
| 101 | Acervo completo analítico sanitizado, sem expiração padrão, normalização versionada, coleta/cotas, comparação, exportação/restauração e gravações isoladas. | `includes/class-f3base-clarity-acervo.php:10` | clarity.json; ui.json | Três dias de coletas, pausa >24 h e gravações em conta real. |

Decisões preservadas: GA4 sem transporte duplo; concessões válidas seguem novo PDF; 410 e resumo de e-mails são regressões; navegação por cron anônimo; assinatura sem operador inventado; leitura/visita IA sem inferir citação; histórico Clarity nesta entrega; retenção Meta ampliável além de 24 h. Não há novos adiamentos de implementação destes itens. Limites de fontes externas e homologações permanecem explícitos.
