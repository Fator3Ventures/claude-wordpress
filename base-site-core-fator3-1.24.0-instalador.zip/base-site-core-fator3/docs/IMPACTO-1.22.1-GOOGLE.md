# Impacto do Site Core 1.22.1 — GOOGLE

Nenhum código ou dado do MCP Google foi alterado. O contrato `search-console-reader/1.0.0` permanece.

A prontidão do consumidor passa a depender da estrutura real do acervo, da propriedade, da configuração e da guarda; não é negada apenas por migração de outra área pendente. O Core não apaga eventos existentes por indisponibilidade transitória do SDK. Desligamento explícito continua removendo a agenda.

`effective_status` permanece opcional e só é usado quando anunciado; sem anúncio, usa `status`. A consulta continua reavaliando concessão e acesso. Testes locais usam SDK simulado: nenhuma nova homologação do pacote Google ou conta real foi realizada. A barreira de recuperação do Core não substitui a recuperação própria do Google.
