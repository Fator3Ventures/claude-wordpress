# Encaminhamento ao Fator3 MCP Google — convivência com Core 1.20.0

Referência conferida: **Google 0.7.0**, pacote final fornecido. Seu código não foi alterado. Integração validada localmente com o SDK real, WordPress/MySQL e respostas Google simuladas, inclusive concessão em conexão não padrão e execução sem usuário autenticado. Isso não é prova de acesso a uma propriedade real.

O Core registra `base-site-core-fator3` versão `1.20.0` no hook público, contrato `search-console-reader/1.0.0`, capability `gsc.page-day.read`. Callback retorna `property`, `revision`, `ready`; recusa estrutura/configuração não pronta. Agenda, snapshots, armazenamento e interface ficam no Core. Credenciais, transição, concessões, políticas e transporte continuam no Google. O antigo importador 0.6 não é reativado e não há cópia de options privadas.

O Core respeita o envelope completo, orçamento até 20.000 ms, reserva de commit local, cursor de até 4096 bytes e invalidação por contexto. `success:false` não publica nem avança, mesmo com `query_result`. `api_daily_row_limit` termina uma tentativa limitada sem apresentá-la como completa. A regra `all_rows_guaranteed:false` permanece.

**Melhoria recomendada, não bloqueante para esta release:** `ConsumerClient::status()` descreve a conexão corrente, enquanto `query()` procura a concessão única em todas as conexões. Quando a concessão está fora da padrão, o status pode mostrar `grant:null` ou configuração/transição não prontas apesar de a consulta ser válida. Seria útil um status público que resolva a conexão efetiva pelo mesmo critério da consulta, retorne seu `connection_id` e diferencie ambiguidade de ausência. Até lá, o Core não usa o status corrente como veto global e orienta diagnóstico `google/integration-status` dirigido à conexão.

A recuperação Core usa sua própria sentinela `wp-content/f3-core-state/`. Ela não substitui a barreira Google. O procedimento integrado exige preparar/drenar ambos antes de restaurar o banco compartilhado e retomar cada escopo explicitamente. O Core não chama APIs privadas Google nem confirma drenagem de leases antigas por conta própria.

Nenhuma mudança obrigatória no Google 0.7.0 foi identificada para consumir esta release.
