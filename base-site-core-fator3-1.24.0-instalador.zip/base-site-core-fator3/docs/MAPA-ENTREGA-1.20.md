# Mapa da entrega — 1.20.0

Plano aprovado revisão 2 preservado em `PLANO-APROVADO.md`. Implementado designa o pacote, não o encerramento de homologação da frota.

| Pedido | Entrega | Código principal | Evidências |
|---|---|---|---|
| 102 | Consumidor GSC diário pelo SDK Google 0.7; propriedade única; D-3; cursor transacional; snapshots sem expiração; publicação por universo/dia; replay, importação manual e tela Aquisição → Search Console | class-f3base-gsc.php; class-f3base-gsc-acervo.php; class-f3base-inteligencia.php | google-mcp, google-ordem, regressoes, gsc-falhas, ui |
| 103 | Registro fechado das 20 famílias Core; cron nativo/CLI/ability; argumentos, prioridades Core, agendas locais, três tarefas/30 s, continuidade e exclusão concorrente | class-f3base-operacao.php | cron, recuperacao, regressoes-preservadas |
| 104 | Instalação nova ou 1.19 saudável/interrompida; checkpoints/recuo; CAPI schema 3 inclusive linhas vazias/terminais; estados e escolhas preservados | class-f3base-instalacao.php; class-f3base-atualizacao.php; class-f3base-capi-fila.php | instalacao, regressoes, recuperacao |
| 105 | Nome Fator3 Site Core; menu Site Core; autor Fator3; metadados; nomes/raízes dos pacotes; relatório externo e documentação instalada | base-site-core-fator3.php; admin/; docs/; montar-release.py; fechar-release.py | smoke, ui, documentacao, pacote |
| 106 | Diário durável por passagem/tarefa; origem CLI/HTTP/manual; últimas independentes; janela móvel de 24 h; CLI nas últimas 2 h; saúde e executor expõem evidência | class-f3base-execucoes.php; class-f3base-saude.php | cron, recuperacao, limites-operacao |
| Complemento 103/106 | Barreira fora do banco; pausa, drenagem, geração e retomada com reconciliação; filas restauradas não são reenviadas automaticamente | class-f3base-recuperacao.php; class-f3base-cli.php | regressoes, recuperacao, limites-operacao |

Não foram adicionados novos adiamentos funcionais ao plano. Webhook genérico, novas funções de CRM, tema/implantador, hospedagem e atualização pública permanecem fora do escopo aprovado. Os limites de validação e aceites operacionais estão em VALIDACAO.md. Integrações finais: MCP 0.15.0 e Google 0.7.0, sem alteração em seus códigos.
