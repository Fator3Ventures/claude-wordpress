# Operação, recuperação e Search Console — 1.22.0

## Guarda

`wp-content/f3-core-state/` permanece fora da pasta substituída do plugin. O índice protetor é conferido antes de retornar por sentinela existente; não se recria automaticamente sentinela perdida após instalação concluída. `provisionamento` diferencia índice indisponível. `entrada_requisicao` e `modulos_inicializados` descrevem esta requisição, não uma prova antiga armazenada.

Sentinela ausente/inválida e falha de trava impedem operação; Saúde é crítica. Pausa administrativa é manutenção. Trava ocupada não se resolve recriando sentinela válida. Documentação, leitura de recuperação e destino administrativo mínimo continuam acessíveis com administração.

Para restore, leia `f3base/operacao-recuperacao-ler`. Se for necessário recriar, use `acao: recriar`, `precondicao_esperada`, `copia_outro_host` booleano, `reconciliacao_confirmada: true` e **`manter_pausado: true`**. A recriação termina pausada, sem prontidão presumida. Faça `preparar` com a geração atual e confira drenagem/prontidão. Falha parcial mantém pausa e identifica efeitos por fila, cursores e itens incertos. Restore e efeitos de suspender filas são escopos distintos.

CLI equivalente: `wp f3base operacao recuperacao recriar --precondicao=HASH --copia-outro-host=nao --reconciliacao-confirmada --manter-pausado`. Consulte ajuda e estado antes de agir. Sem manter pausa, a guarda é liberada e a resposta exige nova requisição para carregar os módulos.

Prepare também o Google pelo procedimento dele; uma guarda não certifica a outra nem todos os escritores do WordPress. Após restore e reconciliação, retome Google antes do Core. Aplique `retomar` somente com geração atual e confirmação de reconciliação externa.

## Passagens e ocorrências

Origens: `cli` quando WP_CLI é verdadeiro, `http_cron` quando wp_doing_cron, e `manual` nos demais disparos. Últimas passagens são separadas; contadores usam janela móvel de 24h. `cron_servidor_ativo` significa CLI observada nas últimas duas horas. Ausência gera pendência de evidência, sem afirmar que o crontab está desligado. Ler Saúde não atualiza instantes.

Uma ocorrência tem identidade por hook, argumentos e instante original. Retomada conserva essa identidade; agenda futura legítima é outra ocorrência. Disputa retorna ocupada/já processada; falha de checkpoint/agenda real continua falha com causa saneada. Tentativas anteriores à reserva também entram no diário com tarefa/hook/origem/proprietário conhecido. Se o diário falhar, há indicação de observabilidade e tentativa de log sanitizado.

`f3base_operacao_intencoes` guarda retomadas com o instante original; hook `f3base_operacao_retomar` acorda o executor limitado. Agendamento, solicitação de loopback e execução são provas diferentes. O Core respeita DISABLE_WP_CRON; o executor externo continua necessário. `executar-pendentes` admite cron sem usuário autenticado, CLI ou administração, com orçamento de 30s e até três trabalhos.

## GSC

`f3base_gsc_prova_local` vincula propriedade normalizada, home/host, hash conhecido da PSL e versão do pacote. Não consulta nem amplia concessão Google. Após validar a propriedade, o caminho comum usa a prova sem reabrir a PSL; alteração relevante invalida-a.

`effective_status` é opcional, anunciado pelo SDK. `resolved` identifica resolução local; `not_granted`, `ambiguous` e `unreadable` têm mensagens distintas. Retorno inválido/exceção degrada o diagnóstico. Sem capacidade, usa `status()` do contrato anterior. Nenhum desses resultados comprova consulta remota ou commit. A retenção de lacunas e a limpeza da tabela acompanham a política de desinstalação do Core; não há apagamento de histórico na atualização.

A aba técnica recebe resumo de cache sem projeção opaca. Prova individual de token válida pode coexistir com comprovação geral pendente; a tela explica ambos e tolera itens inválidos sem fatal.
