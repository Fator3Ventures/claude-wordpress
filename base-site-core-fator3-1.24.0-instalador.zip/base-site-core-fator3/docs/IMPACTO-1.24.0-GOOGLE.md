# Impacto do Core 1.24.0 no Fator3 MCP Google

Nenhuma mudança de código é necessária no MCP Google. O Core aceita 0.7.1 ou posterior com versão estável e registro compatível do SDK `search-console-reader/1.0.0`. A coleta e a guarda de recuperação continuam independentes. O Core não envia sua audiência ao Google: GA4 continua pela tag, e os relatórios locais deixam explícitas as diferenças entre saída/tempo visível e engajamento do GA4.
