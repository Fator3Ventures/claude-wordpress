> Documento da entrega 1.19, preservado para referência. Para atualizar e para operação/GSC na 1.20, leia OPERACAO-GSC-1.20.md.

# Arquivos privados por agentes

Abilidades `f3base/arquivos-privados-cadastrar`, `arquivos-privados-listar`, `arquivos-privados-substituir` e `arquivos-privados-excluir-origem`. Exigem gestão de formulários ou administração e política MCP correspondente. Não aceitam caminho livre ou URL remota.

Cadastro/substituição: use `base64` (até 8 MiB decodificados, limite de transporte do canal) ou `midia_id` de attachment local autorizado. Informe `sha256` dos bytes e `idempotency_key` (16–128 caracteres); `nome` opcional. Arquivos maiores usam importação da mídia local. Isso não impõe teto aos anexos dos formulários. Symlinks, origem fora de uploads, hash divergente e fonte ambígua são recusados.

Listagem paginada retorna ID, nome, bytes, MIME/alerta, SHA-256, datas, estado, mídia de origem e formulários vinculados. Não retorna caminho físico nem tokens/URLs de concessão.

Substituição acrescenta `id` e `expected_sha256`. Publica novo blob imutável depois de copiar/conferir hash; transação troca ponteiro e atualiza concessões vigentes. ID, formulários, links, expirações, quotas, usados e revogações são preservados. **Concessões válidas passam a entregar a versão nova.** Vencidas/revogadas/esgotadas continuam sem acesso e respondem 410. Downloads concorrentes leem uma versão íntegra; não se sobrescreve arquivo aberto.

A mesma chave com mesma intenção retorna resultado já confirmado; outra intenção é recusada. Conflito de revisão exige nova leitura. Falha anterior à publicação preserva a versão anterior. Blobs preparados/retirados têm journal para limpeza posterior, sem remover arquivo ainda referenciado. Se confirmação de commit se perder, a retomada usa a chave; não adivinhe sucesso nem elimine arquivo referenciado.

Importação copia; origem pública permanece por padrão. `excluir-origem` exige ID, SHA esperado e `confirmar=true`; mostra vínculos conhecidos e exige `aceitar_vinculos=true` se existirem. A cópia privada é conferida antes de remover attachment. Exclusão não promete apagar CSS/código/caches/cópias externas. Atualização nunca exclui mídia pública automaticamente.

Anexos continuam privados e servidos como download. Campo sem max_bytes (ou zero) não tem teto do plugin; extensoes vazio não cria proibição global. PHP/upload_max_filesize/post_max_size/max_file_uploads são apresentados; proxy desconhecido permanece desconhecido. O teto da requisição inclui todos os arquivos e campos. MIME/extensão divergente gera alerta sem introduzir bloqueio global.

## Formulários e confirmação

`confirmacao_url` opcional: interna normalizada ou host HTTPS externo explicitamente autorizado em `f3base_confirmacao_hosts`. A referência temporária privada dura 600 s; não contém nome/e-mail na URL. Conteúdo/WhatsApp preservam ação de continuar. Página interna é resposta privada, sem tags de terceiros; destino externo precisa exibir o link recebido em `f3base_continuar` para concluir a ação. Configure esse destino conscientemente no editor. Sem URL permanece mensagem local.

Chaves fechadas de mensagens: enviando, sucesso, validacao, arquivo_limite, token_indisponivel, conexao, nao_confirmado, falha, novo_envio. Catálogo e limites constam do schema. Honeypot/rate limit/token continuam ativos; suspeito não recebe download nem conversão de sucesso. Erro não redireciona como sucesso.

Assunto aceita `{nome}`, usa papel nome, fallback Visitante e sanitização antes de compor uma única ocorrência do nome do site. Prévia e envio usam a mesma função. Avisos individuais limitados e resumo horário dos pendentes são preservados, separados de testes; não fundem registros pelo e-mail. Variáveis `--f3base-form-*` e `wp-element-button` permitem identidade do tema mantendo rótulos e foco.
