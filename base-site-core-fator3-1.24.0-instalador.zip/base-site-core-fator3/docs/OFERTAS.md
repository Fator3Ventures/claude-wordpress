# Ofertas por serviço — contrato 4.3.0 / Core 1.19.0

Um serviço possui `ofertas:[]`; cada plano/período tem identidade própria. A lista enviada substitui a anterior integralmente. Campos desconhecidos são recusados na escrita, inclusive `oferta` singular e `publico`; dados antigos não enviados permanecem preservados. A migração não adivinha significado de campos ambíguos.

```json
{"servicos":[{"nome":"Consultoria","ofertas":[
  {"id":"essencial-mensal","nome":"Essencial mensal","pagina":123,"modalidade":"fixo","preco":"239.00","moeda":"BRL","periodo":"mes"},
  {"id":"projeto","nome":"Projeto personalizado","pagina":123,"modalidade":"a_partir_de","preco":"5000.00","moeda":"BRL","periodo":"unico"},
  {"id":"sob-consulta","nome":"Consultoria especial","pagina":123,"modalidade":"sob_consulta"}
]}]}
```

Substitua 123 por uma página pública existente, sem senha. ID: 1–80 caracteres minúsculos, números, `_` ou `-`, único no serviço e estável entre revisões; nome até 200; descrição opcional até 2.000. Nomes de serviço são únicos. Até 100 ofertas por serviço. Não reutilize um ID para outro produto.

| Modalidade | Entrada | Emissão Schema.org |
|---|---|---|
| fixo / único | `preco`, `moeda`, `periodo:unico` | Offer.price e priceCurrency |
| fixo / recorrente | período dia/semana/mes/ano | UnitPriceSpecification.price + referenceQuantity 1 DAY/WEE/MON/ANN |
| a_partir_de | preço mínimo, moeda, período | minPrice como Number, sem price exato |
| sob_consulta | sem preço/moeda | Offer sem preço numérico |
| gratuito | fixo com `preco:"0"` | Zero numérico/string canônica conforme propriedade, mantendo período declarado |

O preço de configuração usa ponto decimal e até quatro casas, sem separador de milhar. Não envie `R$ 5.000,00` no JSON. A prova de conteúdo reconhece `R$ 5000`, `R$ 5.000` e `R$ 5.000,00`. Período por unidade não é duração mínima de contrato: não transforma `duracao_minima_meses` em billingDuration. Texto de teste grátis não comprova que um plano pago seja gratuito.

## Configurar, observar e publicar

1. Leia valor bruto, revisão, erros e snapshot da migração. Inventarie chaves extras. Simule a lista completa; confira `campos_removidos`; aplique somente a transformação pretendida.
2. A página precisa mostrar o nome do plano, preço/moeda e período na mesma região identificável. `data-f3base-oferta="essencial-mensal"` pode desambiguar regiões, mas não substitui texto visível. Script, JSON-LD, template, conteúdo com hidden/aria-hidden ou estilo inline oculto não contam. Preços de outra seção/plano não comprovam a oferta.
3. Uma sonda da página pública registra evidência de conteúdo. Sem evidência válida, o Core omite a oferta. Isso evita emitir um preço inventado ou não observável. Se o HTML em cache precede a prova, invalide o cache pelo controle existente e repita a verificação.
4. O Core emite identidade estável e marcador próprio. O estado **publicada** exige observar no HTML público o nó esperado, o marcador do Core e o conteúdo correspondente. Apenas configuração válida ou nó parecido de terceiro não satisfazem esse estado.
5. Mudança de conteúdo, preço, plano, página, tema, plugins ou contexto invalida a prova. Provas também vencem em 24 horas. A agenda verifica até cinco páginas por rodada, orçamento de 20 s, e retoma depois; cron real é necessário em site sem tráfego. Edição agenda nova rodada curta.

Estados incluem `verificacao_pendente`, `divergente`, `ocupado_por_outro_emissor` e `publicada`. O diagnóstico de conflito identifica o Service concorrente quando observável e não o remove. Layout/CSS calculado por regras externas não é integralmente verificável por um parser HTTP; valide aparência em navegador antes do aceite. Conteúdo dinâmico só disponível após executar JavaScript pode permanecer inconclusivo. Não mova preço para scripts para forçar a aprovação.

O Core não edita tema, não remove exceções de Twinia nem compensações CSS. Esses ajustes pertencem ao projeto do site, com backup e prova pública depois. ID e revisão são independentes do perfil operacional. Consulte OPERACAO-E-RECUPERACAO.md para checkpoints e recuperação na versão atual.
