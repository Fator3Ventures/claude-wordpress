# Analisar conteúdo orgânico

1. Abra Conteúdo → Artigos, selecione período e o recorte Entradas por busca orgânica. Confira cobertura e início real da coleta antes de comparar números.
2. Ordene por sessões/entradas; abra um artigo. Compare visualizações, amostras de tempo/rolagem e as seções ainda disponíveis. Tempo desligado ou sem amostra é indisponível.
3. Em Continuidade, confira caminhos anteriores/seguintes ligados por navegação. Abra as sessões para entender a sequência. A página final observada não prova abandono.
4. Confira cliques e aceites pareados. Associação temporal não demonstra que o texto causou uma conversão.
5. Se houver fotografia GSC autorizada, compare cliques/impressões por URL e período, respeitando calendário do Pacífico e cobertura. Não some CTR/posições nem compare um total de páginas ao da propriedade.
6. Use Sem observações para encontrar itens publicados sem registros disponíveis. Priorize investigação de cobertura antes de concluir que ninguém os acessou.

Depois da retenção individual, use visualizações e sessões iniciadas para tendências. Não tente recuperar visitantes distintos ou jornadas pelos totais diários. Em consultas limitadas, reduza período ou filtre conteúdo; nenhum número parcial deve ser apresentado como total.

Serviços reproduzíveis: `conteudos-relatorio` → `sessoes-listar` com post_id → `sessao-detalhar` com sessao. UI e CSV usam os mesmos serviços. Veja MEDICAO-1.19.md e CONSULTAS-EXEMPLO.sql.
