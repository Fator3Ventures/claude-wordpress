# Documentação instalada — Fator3 Site Core 1.24.0

Índice estável: `wp-content/plugins/base-site-core-fator3/docs/DOCUMENTACAO.md`.
Por canal autenticado: `f3base/documentacao-ler` sem argumentos; depois `arquivo`, `linha`, `limite` (máximo 200). A resposta traz SHA-256 e continuação. Requer `manage_options`, inclusive com os módulos pausados.

| Arquivo | Conteúdo |
|---|---|
| RELEASE-1.24.0.md | Matriz de instalação, mudanças, padrões e retomadas |
| MEDICAO-1.24.md | Saída, duração, dimensões de audiência e exclusões |
| AGENTES-1.24.0.md | Uso dos relatórios e limites para agentes |
| ENTREGA-1.24.0.md | Rastreabilidade dos pedidos |
| VALIDACAO.md | Evidências locais e limites de homologação |
| PIPEDRIVE.md | Configuração, identidade, integração, notas e fila |
| AJUDA-OPCOES.md / dados/ajuda-opcoes.json | Ajuda gerada do catálogo efetivo |
| dados/configuracao-schema.json / dados/abilities-*.json | Contrato executável e permissões |
| DICIONARIO-DADOS.md / dados/contrato.json | Tabelas, colunas e semântica |
| CONSULTAS-EXEMPLO.sql | Exemplos de consulta, com prefixo a resolver |
| IMPACTO-1.24.0-MCP.md / IMPACTO-1.24.0-GOOGLE.md | Encaminhamentos aos plugins companheiros |
| CONFIGURACAO.md / LEADS-E-FORMULARIOS.md | Recursos de configuração e captura preservados |
| RELATORIOS.md / METRICAS.md / ORIGENS-ANUNCIOS.md | Relatórios e atribuição |
| ANALISAR-CONTEUDO-ORGANICO.md / ANALISAR-PRESENCA-IA.md | Audiência orgânica, acessos de IA e visitas referidas |
| CHANGELOG.md | Histórico |

**Precedência:** guias 1.24.0 e schemas gerados descrevem a versão atual. Os guias de releases anteriores são históricos, sem autorização para outra origem de atualização. `documentacao` é a chave estável; o alias `documentacao_1210` foi removido.

Pacote 1.24.0; contrato de configuração/dados 6.1.0; leads schema 7; intenções schema 1; política MCP 1; SDK Google `search-console-reader/1.0.0`. O serviço chamado `config-core-contrato-v1` conserva o nome; examine `contract_version` na resposta. A documentação não contém valores secretos do site.
