# Contatos, jornada e cruzamentos — 1.22.0

## Identidades e autorização

`record_id` é a chave estável do contato; `sessao` liga eventos quando há evidência; `correlacao` liga operações; `post_id` identifica conteúdo. Não unir pessoas ou sessões por IP, user agent, nome parecido ou proximidade de horário. UTC no armazenamento e fuso WordPress na apresentação/filtros. Ausência, zero e não observado são distintos.

Leitura da jornada exige `f3base_ler_leads` ou `manage_options`, tanto na tela quanto em `f3base/lead-jornada-ler`. Gestão isolada não concede leitura. Exportação, anexos, configuração e reenvio mantêm permissões próprias. O MCP aplica ainda sua política de conexão.

## Apresentação

A projeção comum alimenta contato/solicitação, acontecimento, comportamento, origem e detalhes técnicos em tela, texto e nota HTML. Jornada fica após Acontecimento. Site tem um único identificador no cabeçalho da nota; URLs continuam naturalmente contendo o host. Âncora de Página inclui toda a URL e a barra final.

HTTP(S), telefone e e-mail têm esquema preservado. WhatsApp conserva o número conhecido e descarta texto/query não necessária; links privados/assinados não são expostos. Campos com papel de identificação não aparecem duplicados nas respostas; originais permanecem em `dados`.

Páginas distintas e carregamentos são medidas diferentes. Tempo ativo vem dos eventos de atividade; duração observada mede intervalo disponível. Carregamentos simultâneos não são somados como uma única leitura. O recorte tem até 500 eventos e 100 cliques, com corte/cobertura explícitos; saída inclui `f3base_link_externo`. Unificação de barra em caminho local depende de identidade canônica comprovada.

Jornada vazia indica origem nativa, falta de sessão, retenção, medição recusada/revogada ou falha de leitura. Ausência de atribuição não significa orgânico. A captura conserva sua evidência de consentimento; autorização de novo compartilhamento e revogação efetiva são avaliadas separadamente no despacho. Ausência de prova não vira consentimento presumido.

Aparelho é classificação estimada; `dispositivo` continua sendo largura da janela em pixels. iPad com UA Mac só é inferido quando há sinais complementares disponíveis; sem eles há limitação explícita. Nenhuma impressão digital persistente foi acrescentada. Histórico usa cursor, comparação condicional e repetição de falhas, preservando outros valores JSON.

Selo TESTE aparece junto ao nome. `teste_origem` identifica cookie/canal/sinal retido, quando disponível. Origem de teste não é identidade civil. Cookies de teste continuam com 365 dias; automação deve ativar a marca no navegador utilizado e cabeçalhos de integração seguem a documentação de testes.

## CSV de contatos

Ordem: `record_id, data_utc, nome, email, metodo, formulario, captura, atendimento, sessao, correlacao, post_id, ip, user_agent, resposta, campos, classe_trafego, atribuicao, segmento_consulta, de, ate, fuso_filtros, aparelho, teste_origem`. As duas últimas são acrescentadas ao final; `record_id` permanece primeiro. `campos` e `atribuicao` são JSON. Exportações são privadas e mitigam fórmulas de planilha.

## E-mail e alertas

Assunto de clique usa palavras e título/caminho de página, com site uma vez. A preparação do conteúdo antecede o transporte; falha nessa fase permite reprocessar. `wp_mail` aceito não prova recebimento. Exceção após início do transporte permanece incerta.

Somente avisos explicitamente marcados `aguarda_resumo` entram no resumo horário, agrupados por destinatários efetivos e classe de teste. Pendentes individuais não são consumidos pela virada da hora. Alertas CRM deduplicam entrega + causa + episódio; mesma causa reagendada não abre episódio novo. Falha confirmada tem até três tentativas progressivas; incerteza não é reenviada automaticamente.

## Estado adicional

Options técnicas sem autoload: `f3base_config_complementacoes` (eventos/reparos), `f3base_gsc_prova_local` (prova de validação), `f3base_operacao_intencoes` (retomadas), `f3base_aparelho_migracao` (cursor) e `f3base_release_1220` (etapas). `journal.nucleo_confirmado_em` e `journal.atividade_estado` separam núcleo e atividade CRM. Campos de diagnóstico não incluem corpo remoto bruto, SQL ou segredo. Dados de oportunidades de terceiros ficam limitados a tipo/ID nos diários operacionais e recibos.
