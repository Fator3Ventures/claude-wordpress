# Entrega — Fator3 Site Core 1.23.0

Implementação do plano revisão 4, incluindo as decisões de 07/10: identificar por telefone, escolher campo LinkedIn e permitir apresentação/reenvio histórico quando se perdeu a referência de consentimento. Matrizes aceitas: WordPress novo ou 1.22.1 concluída; MCP 0.16.0 e MCP Google 0.7.1.

## Pedidos

As referências M/P/C/D identificam o plano incluído no ZIP fonte. A tabela descreve comportamento implementado; o alcance das provas está em VALIDACAO.md. Aceite local não substitui homologação nas contas e caixas reais.

| Pedido | Seção de implementação | Implementação / comportamento |
|---|---|---|
| 17 | §9 | Webhook permanece adiado; nenhum desenvolvimento oculto |
| 108 | §8 | Nome corrigido e entradas 1.22.1/1.23.0 no catálogo, provadas no ZIP |
| 109 | M04 | Código interno conhecido presente em erro.mensagem/codigo_interno |
| 115 | P06 | Catálogo de falhas, seleção terminal corrigida, incertos visíveis |
| 116 | P01/§3 | Escolher campo aprovado; mapa explícito preservado, pendência sem chave visível e campo efetivo exposto |
| 117 | C04 | Ressalva de tipo estimado nas saídas pertinentes |
| 121 | C04 | Seções/rótulos/frases comuns e JSON recolhido |
| 124 | P02 | Defaults/procedência, pendências visíveis/reavaliadas e intenção de rótulo |
| 125 | P03 | Botão efetivo, dados apenas na aba Pipedrive, texto de identidade |
| 127 | D02 | Seis motivos seguros, prefixo com fronteira, ausência de segredo |
| 130 | D01 | Normalização, pré-imagem, repetição segura e efeito HTTP |
| 131 | §8 | Só chave estável e códigos completos; alias antigo retirado |
| 132(c) | P04 | E-mails como conjunto, preservando atributos/endereços |
| 132(d) | P04 | executar_agora na ability; simulação não despacha |
| 132(h) | C04 | Texto e expiração em duas horas |
| 133 | P05 | Etapa real; campo/código quando informados; aceitação ajustada explícita |
| 139(1) | M02 | Índice isolado não derruba módulos; guarda real continua obrigatória |
| 139(2) | M03 | Remover bloqueio/absorção antigos; avisos independentes |
| 139(3) | P01/§3 | Telefone como identificador aprovado e habilitado por padrão; switch, normalização e limite de inferência |
| 139(4) | P03 | Recuo, cota própria, classificação e botão sem bypass |
| 139(5) | P05 | Etiqueta complementar não impede nota/núcleo |
| 139(6) | P04 | Reserva respeitada entre todos os gravadores da entrega |
| 139(7) | C01/§3 | Dono autorizou exibir/reenviar com referência perdida; padrão permitir, ressalva e negativas/revogações respeitadas |
| 139(8) | C03 | Desconfigurado no resumo sem destinatário; reenvio possível |
| 139(9) | C03 | Cabeçalhos e marca persistentes no corpo mínimo |
| 139(10) | M03 | Caminho antigo retirado; novos conflitos delimitados e visíveis |
| 139(11) | M03 | Etapas finais coerentes, manutenção posterior independente |
| 139(12) | M04 | Execução limitada, armazenamento paginado e retomada explícita |
| 139(13) | C02 | Índice, backfill e expurgo coordenado |
| 139(14) | §9 | Sem downgrade; cache do upgrade atual testado e limite documentado |
| Adicional 07/10 — e-mail legível | C05 / T23 | HTML por padrão, alternativa em texto, seções e negrito; preview e transporte verificados, sem alterar efeitos de envio |

## Decisões preservadas

- Telefone desligado como identidade continua como dado de contato. Outro país explícito não vira BR.
- LinkedIn sem campo selecionado mantém pendência e perfil na nota; nenhuma criação de campo remoto.
- Referência perdida não transforma negativa ou revogação conhecida em consentimento. Nenhum reenvio em massa na migração.
- Falha real de banco não é disfarçada de concorrência. Pendências não expiram por idade.
- Webhook genérico, alterações de tema/implantador e alterações dos dois plugins companheiros não foram incluídos, conforme limites do plano.

## Arquivos e instalação

Use o ZIP **instalador** no WordPress. O ZIP **fonte** contém o mesmo código e documentação, suíte, evidências, plano e relatório. Confira SHA256SUMS. Faça o procedimento de backup/atualização habitual; a release não implementa downgrade. A instalação por si só não comprova entrega SMTP, autenticação Google ou resultado do Pipedrive real.

Documentação instalada: `docs/DOCUMENTACAO.md`, também por `f3base/documentacao-ler`. Segredos são cadastrados pelo dono na tela; não entregar tokens ao agente. O botão de verificação respeita quota/recuo e não cria pessoas/leads.
