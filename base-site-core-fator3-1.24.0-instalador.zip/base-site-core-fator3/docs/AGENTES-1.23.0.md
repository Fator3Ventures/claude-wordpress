# Agentes — Core 1.23.0

Leia primeiro DOCUMENTACAO.md e o contrato instalado, nunca schemas de uma conversa anterior. A compatibilidade é exclusiva com MCP 0.16.0 e MCP Google 0.7.1. Sem companheiro, o Core mantém funções locais e diagnostica a integração ausente. Não usar isso para contornar permissões ou criar conexões.

Use `config-core-ler` para valor/revisão/procedência, e escrita com revisão esperada. Nunca peça token em chat nem escreva diretamente options/tabelas para corrigir checkpoint. O dono cadastra segredos na UI. Ajuda/contratos são acessíveis com manage_options mesmo em recuperação; isso não habilita as rotas de negócio pausadas.

Para testes de navegação, ative o marcador pela página de testes do Core em cada novo navegador/perfil; cookie dura um ano. O tráfego marcado fica separado conforme configuração. Não presuma que autenticar MCP marca outro navegador. Preserve o isolamento de testes de e-mail e CRM.

## Consultas de diagnóstico

Substitua `wp_` pelo prefixo efetivo do site. São leituras; não altere estados por SQL.

```sql
SELECT tarefa, estado, COUNT(*) quantidade, MIN(tentar_em) proxima
FROM wp_f3base_operacao_intencoes GROUP BY tarefa, estado;
SELECT chave, tarefa, ocorrencia_em, falhas, tentar_em, codigo, cobertura_ate
FROM wp_f3base_operacao_intencoes WHERE estado='esgotada'
ORDER BY tentar_em, chave LIMIT 100;
SELECT lead_id, tentativas, codigo, atualizado_em
FROM wp_f3base_consentimento_reparos ORDER BY lead_id LIMIT 50;
SELECT l.record_id, l.sessao, l.decisao_ref, d.medicao, d.publicidade, d.revogada
FROM wp_f3base_leads l LEFT JOIN wp_f3base_consentimento_decisoes d ON d.ref=l.decisao_ref
ORDER BY l.id DESC LIMIT 50;
```

Não confunda referência perdida com recusa. A UI aplica a política histórica e ressalvas; SQL cru não é apresentação autorizada. `dados` e diários podem conter valores históricos incompletos; verifique tipos antes de acessar índices. Epoch é segundo UTC; apresentação usa fuso do WordPress. `ultima_cli`, `ultima_http` e `ultima_manual` não se sobrescrevem; consultar Saúde não prova nova execução do cron do servidor.

## Operar pendências

1. Consulte Saúde/Operação e a causa por intenção.
2. Resolva a dependência; não altere a ocorrência original.
3. Para ocorrência esgotada, invoque executar-pendentes com `tarefas:["id-da-tarefa"]`, `intencao:"sha256"`, `reativar_esgotada:true` e limite 1. A resposta distingue agenda, execução e pendências. A UI usa o mesmo serviço.
4. Se o erro diz que o efeito remoto é incerto, reconcilie ID e prova no CRM antes de reenviar. `executar_agora` não garante que aquele registro foi entregue.

`pipedrive-avisos-ler` filtra estado incerto/esgotado/sem_destinatarios e pagina contatos. Verificação de conta, aprovação de mapeamento, ativação global e entrega são estados diferentes. LinkedIn modo campo sem seleção fica na nota e não participa da identidade. Prévia não efetua HTTP.

No Google, `effective_status` descreve a conexão concedida ao consumidor Core. `resolved`, `not_granted`, `ambiguous` e `unreadable` têm sentidos distintos; nenhum comprova acesso remoto ou commit de métricas. Não usar status administrativo global como fallback. Query reavalia concessão/propriedade/limites.

## Backup e restauração

Inclua options, tabela nova de intenções, reparos do índice e todas as tabelas comerciais/acervos. As guardas de Core e Google são independentes; preparar uma não prepara a outra. Recriação com `manter_pausado:true` continua pausada, requer nova requisição/preparação. Preserve journals e referências em efeito remoto incerto. Não substituir versão atual por pacote antigo.
