# Medição de ofertas — contrato 1.19

O tema constrói apresentação e gatilhos. O Core mede e oferece auxiliares; não implementa modal. Ofertas comerciais SEO continuam documentadas em OFERTAS.md.

```html
<div data-f3base-oferta="modal" data-f3base-oferta-id="guia">
  <!-- Renderizar aqui exatamente um formulário do Core -->
</div>
```

Tipos: modal, folha, barra, bloco. ID: `^[a-z][a-z0-9_-]{0,79}$`, único no carregamento. Cada contêiner precisa exatamente de um formulário Core. `data-f3base-superficie` conserva finalidade própria. Uma instância corresponde ao mesmo nó no mesmo carregamento/navegação; fechar/reabrir e BFCache não criam nova impressão. Novo ciclo tem de criar outra instância observável. Duplicação de IDs/múltiplos formulários é diagnosticada.

Visibilidade considera formulário no viewport, aba visível e ancestrais sem ocultação/display none/opacidade zero. Uma exibição por instância sob consentimento de medição. `oferta_exibida` é gerada pelo Core; não a dispare manualmente.

```js
container.dispatchEvent(new CustomEvent('f3base-oferta-aberta', {
  bubbles: true, detail: {gatilho: 'clique'}
}));
container.dispatchEvent(new CustomEvent('f3base-oferta-fechada', {
  bubbles: true, detail: {motivo: 'botao'}
}));
```

Gatilhos: rolagem, saida, tempo, clique. Motivos: botao, esc, fora, navegacao. Evento no próprio contêiner; valor inválido não conta. Abertura sem visibilidade aguarda exibição; fechamento só depois de exibição. Cada tipo conta uma vez por instância.

Interno e GA4/GTM usam nomes `oferta_exibida`, `oferta_aberta`, `oferta_fechada`, com form_id, oferta_id, oferta_tipo, oferta_instancia, navegacao e gatilho/motivo quando aplicável. Sem PII. Fila própria de análise mantém prazo inicial de cinco segundos. Carregamento tardio do emissor de destinos preserva eventos em memória e reavalia consentimento/política na emissão. Testes seguem política dos destinos; não vão a contas reais por padrão.

`window.f3baseOfertas.contexto(form)` fornece id/tipo/instancia. O Core vincula form_inicio e aceite do servidor. Medição → Conversão → Ofertas e `relatorios-integrados-ler` com `visao=ofertas` mostram instâncias exibidas/iniciadas/enviadas, abertura/fechamento, gatilhos/motivos e cobertura. Junção usa classe + sessão + navegação + instância + formulário. Sem instância observada é contado à parte; nenhum aceite do navegador substitui o do servidor. Filtros de audiência são os mesmos do relatório integrado.

Auxiliares opcionais: `podeExibir(id,dias)` e `registrarExibicao(id)`. Persistência local por consentimento, memória sem autorização e em testes; no máximo 200 chaves/365 dias. Registro é idempotente e conversão suprime reapresentação da oferta. Auxiliares não decidem quando abrir. Sem JS/consentimento há limite de observação, não “zero visitas”.

`f3base/ofertas-diagnosticar` recebe HTML até 256 KiB e informa marcação válida/ausente/ambígua, sem executar ou buscar URL. `window.f3baseOfertas.diagnostico()` complementa marcações criadas por JavaScript; HTML estático não prova exibição ou frequência.
