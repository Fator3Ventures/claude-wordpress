> Documento histórico da 1.22.0. As declarações de completude foram revistas após a conferência. A referência vigente é [ENTREGA-1.22.1.md](ENTREGA-1.22.1.md).

# Release 1.22.0 — instalação e mudanças

Base autorizada: WordPress novo ou Core 1.21.0. Faça cópia de banco e arquivos antes de atualizar, incluindo a pasta de guarda fora do plugin. Substitua o plugin pelo instalador; a migração registra etapas em `f3base_release_1220`. Confira `concluido_em`, estrutura e Saúde após uma nova requisição. Falha técnica mantém etapa e espera progressiva; não altere manualmente o marcador de versão para contorná-la. Uma guarda pausada permanece pausada.

## Configuração e procedência

Complementação técnica preserva origem/canal/data e registra caminhos acrescentados, versão e revisão separadamente. País de telefone ausente ou vazio recebe `BR` persistido, inclusive nos sites atualizados; país escolhido é preservado. `false`, zero, listas vazias, credenciais, mapas e integrações desligadas permanecem. Atividades desligadas não são habilitadas.

O mapa nativo antigo só conserva a última procedência: a recuperação da autoria apagada pela 1.21 depende de evidência anterior verificável. A prevenção está implementada; recuperação por site não é presumida. Consulte PROCEDENCIA-1.22.md.

O salvamento compara campos semanticamente, preserva listas antigas com mais de cinco e-mails quando intocadas, renova contexto autenticado com JS e conserva revisões originais. Contexto tem janela de 30 minutos e limite absoluto de duas horas, até dez contextos por usuário. Sem JS, contexto vencido exige reabrir/redigitar; nenhum segredo é colocado em rascunho persistente.

Token Pipedrive novo/substituído é verificado com GET users/me antes da troca. Simulação também pode fazer essa consulta, sem salvar opções ou objetos comerciais. Recusa/timeout/429/resposta inválida preservam a credencial anterior. Alterar GTM não verifica segredo intocado.

## Operação e leitura

Recuperação separa estado da guarda, tentativa de entrada e módulos carregados nesta requisição; oferece documentação e destino administrativo mínimo. Recriação aceita manter pausa. Executor conserva a ocorrência original, registra tentativas das três origens e diferencia concorrência de falha real. Ausência de CLI em duas horas gera pendência de evidência; não prova crontab desligado.

Prova local GSC evita reabrir a PSL a cada requisição; propriedade/host/regras/pacote invalidam essa prova. Os quatro estados de resolução do SDK têm explicações próprias. A aba técnica aceita prova de tokens sem fatal e distingue evidência individual da comprovação geral de cache.

## Contatos e CRM

Jornada logo após Acontecimento; leitura concedida a `f3base_ler_leads` ou administração, com regras de consentimento/retensão mantidas. Páginas distintas, carregamentos, tempo ativo e duração observada são separados. Origem, consentimento histórico, teste e lacunas têm rótulos. Aparelho é inferência; largura da janela mantém a chave histórica `dispositivo`. Reclassificação histórica usa lotes e comparação condicional.

Nota identifica o site uma vez, tem seções/listas e links completos. E-mail usa assunto legível e apresentação comum. Resumo horário processa somente itens destinados a resumo, separados por destinatários/testes. Alertas CRM são deduplicados por causa e episódio; transporte recusado tem tentativas limitadas e resultado incerto não é repetido cegamente.

Pessoa/lead/nota confirmados constituem entrega principal. Atividade v2 é complementar: recusa ou incerteza tem diagnóstico e reparo próprios, sem duplicar o núcleo. País BR, variantes telefônicas/LinkedIn, títulos Unicode, mapas tipados e seletores de respostas melhoram identificação e configuração. Reconciliação administrativa por referência resolve criação incerta e escolha de lead próprio. E-mail alternativo é opção explícita, desligada por padrão.

## Histórico de redirects

Abilities nativas consultam e retiram um caminho antigo com revisão, simulação, confirmação e permissão de editar o conteúdo. Outros caminhos e regras são preservados; o resultado aponta responsáveis remanescentes. Confirmar 404 por HTTP após limpar o cache quando não há outra regra/conteúdo. Não exige SQL pelo conector.

## Limites de entrega

Não houve implantação na frota, chamadas em conta CRM real nem envio de e-mail externo. Evidências locais e limitações estão em VALIDACAO.md. Webhook genérico continua adiado; notas antigas do CRM não são reformatadas em massa. Não se promete identificação de iPad sem sinais suficientes, citação de IA pelo servidor ou unicidade distribuída entre sites independentes.

## Adendo 135 — revisão 2 da entrega

Token Clarity disponível em Site Core → Configurações → Medição e anúncios → Clarity. O dono cadastra o segredo diretamente, salva e usa **Testar token e coletar agora**; agentes não precisam receber a credencial. Teste preserva uma consulta no relatório, compartilhando as cotas existentes. Leia CLARITY-1.22.md. O pacote 1.22.0 revisado substitui o anterior desta entrega; novo WordPress ou atualização da 1.21.0 continuam os caminhos de instalação.
