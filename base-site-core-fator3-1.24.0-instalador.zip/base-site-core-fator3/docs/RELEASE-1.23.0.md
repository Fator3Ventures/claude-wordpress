# Release 1.23.0

## Instalação

Somente WordPress novo ou Core 1.22.1 com checkpoint concluído. Cabeçalho de versão sozinho não comprova a origem. A migração registra `f3base_release_1230`, verifica estruturas e agendas antes da conclusão e não chama conversões antigas de CF7, procedência 1.21 ou saneamento global de diários. Conteúdo JSON, NULL, vazio e escalar preexistente é preservado. Escolhas explícitas, listas vazias e procedência permanecem; complementações acrescentam somente subchaves ausentes e mudam a revisão de conteúdo.

Instalação não envia contatos antigos. Avisos já pendentes conservam intenção individual; os de resumo conservam resumo. Captura/avisos dependem de suas estruturas locais, não de HTTP de integração. Uma origem recusada exige corrigir a instalação de origem; não editar o checkpoint para simular conclusão.

## Avisos de contato

Aviso individual e resumo usam HTML de uma coluna, com títulos, negrito, espaço e quebras de linha, sem imagens remotas. O MIME inclui alternativa text/plain real. Cabeçalhos de formulário, método, teste, remetente e Reply-To são preservados. O assunto não repete o nome do site. Os valores são escapados, e links de arquivos privados não são publicados no aviso. Dispositivo é estimativa a partir de sinais do navegador; largura da janela é outra medida.

Se a preparação falhar, o corpo mínimo conserva cabeçalhos e marca `corpo_minimo_preparacao_local`. Sem destinatário, o resumo fica desconfigurado e corrigível. Aceite do transporte não comprova entrega na caixa. Resultado incerto não dispara uma segunda tentativa cega. O tratamento é restrito à mensagem do Core, incluindo mensagens aninhadas.

## Identidade no Pipedrive

`identidade_telefone: true` é padrão novo e do upgrade quando ausente; false explícito permanece. Desligar a identificação não remove o telefone do payload. País ausente recebe BR; outro país configurado é preservado. Nacional brasileiro exige DDD real e formato de fixo/móvel. Não se acrescenta DDD. Internacional deve trazer `+` e código do país. Número estrangeiro sem `+` pode ser ambíguo. Pessoas divergentes exigem revisão, sem fusão automática. Seleção já confirmada conserva evidência para retomada por ID.

LinkedIn é o endereço do perfil profissional informado no formulário, não uma consulta à rede social. `linkedin_modo: campo` é o padrão aprovado. Selecione um campo textual de pessoa da conta. Sem escolha, o perfil permanece na nota e os outros dados seguem; não há criação ou remapeamento remoto automático. `nenhum` usa apenas a nota. `automatico` exige exatamente um candidato textual compatível. A prévia e o lote usam o mesmo resolvedor, com chave, nome, origem e vínculo ao catálogo.

## Verificação e entregas

“Verificar integração”, na aba Pipedrive, chama o mesmo serviço de UI, ability e cron. Funciona com WP-Cron automático desabilitado. A verificação tem orçamento local próprio de 600 unidades/dia UTC, incluindo páginas; não é saldo oficial nem cota adicional na conta. Entregas têm contador separado. Catálogo em preparo não substitui o completo; a continuação conserva páginas já confirmadas sob a mesma revisão.

Falhas transitórias aguardam 5, 10, 20, 40, 80 e 160 minutos; depois, próxima janela diária. Retry-After maior prevalece. Sucesso zera a sequência. Toda entrada respeita a próxima data; cliques repetidos não contornam limite. Timeout/429/5xx conservam a última prova válida da mesma configuração/credencial. 401/acesso negado a invalidam; 403 com limite de produto não significa token inválido. Resposta malformada tem código próprio.

Reservas são verificadas na seleção, reivindicação, persistência e antes de efeito externo. Uma trava da conexão impede outro processo de reaproveitar lease vencido enquanto há trabalho em voo. Reenvio, reconciliação, cancelamento, revisão e alertas compartilham a coordenação. Isto não coordena sites diferentes nem alterações feitas por operadores remotos.

`pipedrive-reenviar` aceita `executar_agora`, false por padrão. Simulação nunca envia. Confirmação pode executar um lote, mas a resposta separa persistência, agenda, execução e estado final do registro. Núcleo é pessoa + oportunidade + nota. Rótulo de lead é complemento com tentativas limitadas; sua ausência não bloqueia a nota. Intenção e revisão dos rótulos são gravadas antes do POST; configuração posterior não muda a intenção histórica. Atividade e rótulo têm ressalvas próprias, sem duplicar nota. Erro registra etapa real, método, rota e campo/código do provedor quando presentes; ausência permanece null, sem inventar detalhes.

Alertas encerrados não ocupam indefinidamente o lote. Incertos, esgotados e sem destinatário aparecem em Entregas e `pipedrive-avisos-ler`, com paginação e orientação.

## Executor e proteção

Tabela `f3base_operacao_intencoes` conserva ocorrência original, argumentos, estado, falhas, prazo, reserva e cobertura de recorrências. A importação 1.22.1 confirma identidade/conteúdo em lotes de 100 e mantém a fonte histórica. Leituras não reiniciam prazo. Oito falhas reais esgotam a ocorrência; recuos anteriores são 1, 2, 4, 8, 16, 32 e 60 minutos. Espera por quota/concorrência/pausa não conta como falha. Recorrência equivalente não contorna esgotamento. Pendências não são apagadas por idade.

Retomada explícita pela tela Operação ou `executar-pendentes` com tarefa, intenção e `reativar_esgotada:true`, auditada com operador/origem. Não autoriza repetir efeito externo incerto; use reconciliação própria do módulo.

Índice de proteção divergente é pendência crítica e não é sobrescrito. Com sentinela e travas válidas, o Core continua operando; ausência/corrupção da sentinela, pausa, symlink ou falha real de trava continuam bloqueando trabalho protegido. Proteção em disco não comprova proteção HTTP. `preparar`, `recriar` e `retomar` conservam as guardas. Restore suspende intenções da tabela e exige revisão das pendências; não provoca replay de entregas remotas.

## Consentimento histórico

`f3base_contato.historico_sem_decisao: permitir` aplica a decisão do dono quando a referência se perdeu: apresentação e reenvio podem usar informação histórica disponível, com ressalva. Não transforma recusa, revogação, referência conflitante ou falta de consentimento em autorização. `restringir` é opção explícita. Coleta atual e CAPI mantêm o contrato próprio; não há reenvio automático na atualização.

`f3base_leads.decisao_ref` é projeção indexada da referência. Backfill não reescreve `dados`, trabalha até 100 linhas/3 segundos e suspende reparo com três conflitos, permitindo avanço das demais. Pendências aparecem em `f3base_consentimento_reparos` e Saúde. Expurgo só opera quando o índice está completo e confirmado, com NOT EXISTS, máximo 500 órfãs, sob a mesma trava da captura. Decisões vinculadas não expiram por essa limpeza.

## Redirects e contratos

Caminhos com/sem barra usam identidade normalizada. Retirada conserva pré-imagem exata dos metadados removidos; restauração preserva os demais e não remove `_wp_old_slug`. Retirada antiga sem pré-imagem permite restauração funcional, explicitamente sem garantia de bytes originais. Conflitos com destinos/regras existentes são apresentados; confirme efeito HTTP após purga.

Contrato de configuração 6.0.0. Segredos têm motivos de recusa seguros; `Bearer ` e `Basic ` são recusados como cabeçalhos, enquanto prefixo opaco sem delimitador não é confundido. Contexto administrativo expira em duas horas e não guarda rascunho secreto no navegador. A atualização aceita o JavaScript de formulário 1.22.1 ainda em cache; não existe suporte a downgrade.

## Limites e itens adiados

Webhook genérico continua adiado. Citação/recomendação por IA não é inferida de logs: métricas cobrem leitura e visitas referidas observáveis. Não há deduplicação entre instalações independentes ou garantia de recebimento de e-mail. Alterações de tema, implantador, MCP e MCP Google ficam fora do pacote. Homologação real de SMTP/conta Pipedrive/Google e proteção HTTP da hospedagem é separada da bancada local.

Referências de protocolo: https://pipedrive.readme.io/docs/core-api-concepts-rate-limiting e https://pipedrive.readme.io/docs/core-api-concepts-responses .
