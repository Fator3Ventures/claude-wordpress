# Guia para agentes — Core 1.24.0

Leia primeiro `docs/DOCUMENTACAO.md` ou use `f3base/documentacao-ler`. Consulte schemas nas abilities e em `docs/dados`; não derive parâmetros de exemplos.

Para audiência, use `f3base/medicao-editorial`; para contatos, campanhas, conversão e jornada, use `f3base/relatorios-integrados-ler`. Preserve o período, fuso, segmento de testes, automação e cobertura devolvidos. Valores `null` indicam indisponibilidade; não os converta em zero.

Para campanha use `visao=campanhas` e escolha `agrupamento=anuncio` ou `campanha`. `tempo_visivel_medio_por_sessao_ms` usa todas as sessões observadas no denominador; `duracao_observada_media_por_sessao_ms` usa sessões com saída. Leia `cobertura_saida_pct` antes de comparar anúncios.

Os filtros `largura_faixa`, `navegador`, `sistema`, `retorno` e `aparelho` são dimensões da sessão. Dados anteriores à 1.24.0 permanecem vazios. Contato sem sessão ou proveniente de integração nativa não recebe dimensão inferida do agente conector.

Requisição de IA, visita indicada por IA e referência conferida são fatos distintos. O servidor não mede citação ou recomendação. A representação `markdown_core` identifica o `.md` servido pelo plugin.

404 aparece em `exclusoes_404`, fora da audiência, agregado por caminho. Não há query, IP, user agent ou pseudônimo nessa tabela.

Nunca grave diretamente options, tabelas ou arquivos de guarda. Use abilities e respeite `persisted`, revisão, código, cobertura e reconciliação. Em recuperação, documentação pode continuar legível enquanto tarefas e mutações permanecem bloqueadas.
