# Publicidade e cruzamentos por agentes — 1.18.0

O mesmo formulário pode receber visitantes de todos os anúncios. O Core captura a origem declarada na URL e conserva o snapshot no contato; o agente consulta metadados e custos nos serviços externos aos quais foi autorizado. Esta versão não conecta contas, importa leads nativos, sincroniza gastos ou oferece Pipedrive/webhook comercial.

## Configurar a origem

Use `f3_ads_v=1`, plataforma em `utm_source_platform`, campanha ID em `utm_id`, anúncio ID em `utm_content`, conta em `f3_ads_account_id`, grupo em `f3_ads_group_id` e tipo em `f3_ads_group_type`. `utm_campaign` é rótulo da campanha. `f3_ads_ad_name` e `f3_ads_group_name` são rótulos opcionais na captura; renomear não muda a identidade. `utm_term` conserva o significado de termo. `f3_ads_placement` é posicionamento quando informado.

IDs são strings, inclusive IDs com mais de 16 dígitos. A chave do cruzamento inclui site receptor, plataforma, conta e o escopo nativo necessário. Não funda anúncios de contas diferentes por nome, nem trate `fbclid`, `gclid`, `gbraid`, `wbraid` ou `li_fat_id` como ID de anúncio. Click IDs, referrer e UTMs são evidência recebida; não são assinatura autenticada da plataforma.

| Core | Meta | Google | LinkedIn, nomenclatura/API a conferir |
|---|---|---|---|
| plataforma | meta_ads | google_ads | linkedin_ads |
| conta | ad account ID | customer.id | sponsoredAccount / adAccount |
| campanha | campaign.id | campaign.id | Campaign Manager novo CAMPAIGN_ID; API pode corresponder a Campaign Group |
| grupo/tipo | adset.id / adset | ad_group.id / adgroup; recurso quando aplicável | AD_SET_ID; API pode chamar Campaign / sponsoredCampaign |
| anúncio | ad.id | ad_group_ad.ad.id | AD_ID / Creative ou sponsoredCreative |

A nomenclatura nova da interface LinkedIn não torna `campaign` de toda API equivalente à campanha da interface. Antes de unir dados, registre endpoint, header de versão, tipo/URN e correspondência conferida no retorno real. A referência pública de hierarquia ainda enumera Sponsored Accounts → Campaign Groups → Campaigns → Creatives. Não corte o prefixo de uma URN sem guardar seu tipo.

### Meta / Instagram

Modelo de parâmetros no anúncio, substituindo a conta e validando a expansão no Gerenciador:

```text
utm_source={{site_source_name}}&utm_medium=paid_social&utm_source_platform=meta_ads&utm_id={{campaign.id}}&utm_campaign={{campaign.name}}&utm_content={{ad.id}}&f3_ads_group_id={{adset.id}}&f3_ads_group_type=adset&f3_ads_account_id=ID_DA_CONTA&f3_ads_v=1
```

Opcionalmente, acrescente os nomes quando as macros correspondentes forem oferecidas pela conta. Codifique valores, não publique macros não expandidas. `ig`, `fb`, `an` e `msg` são normalizados para Instagram, Facebook, Audience Network e Messenger quando declarados; um fbclid isolado não prova que veio de anúncio ou do Instagram. A conta Meta pode anunciar em várias superfícies.

A central oficial Meta pode exigir login. Esta documentação fornece o molde aprovado do Core; o teste da expansão na conta é obrigatório e não foi substituído por uma consulta anônima da central de ajuda.

### Google Ads

Preserve a auto-tagging e use o sufixo de URL final ou modelo aprovado para o formato. Exemplo de sufixo sem `?` inicial:

```text
utm_source=google&utm_medium=cpc&utm_source_platform=google_ads&utm_id={campaignid}&utm_content={creative}&utm_term={keyword}&f3_ads_group_id={adgroupid}&f3_ads_group_type=adgroup&f3_ads_account_id=ID_DA_CONTA&f3_ads_v=1
```

O suporte depende do tipo de campanha. Em Performance Max, confira granularidade de recurso/grupo; não prometa identificar a combinação exata de títulos/imagens exibida. `utm_content` manual não se torna automaticamente a dimensão nativa de anúncio no GA4. Auto-tagging e dimensões manuais têm regras próprias; documente a precedência da propriedade antes de comparar painéis.

### LinkedIn

No Campaign Manager, selecione os parâmetros oferecidos para ACCOUNT_ID, CAMPAIGN_ID, AD_SET_ID e AD_ID; use o tipo de grupo que corresponda ao contrato conferido. Quando uma macro não estiver disponível, grave o ID literal conferido no nível correto, como string. A release não inventa a sintaxe de uma macro nem a aplica diretamente à conta. Teste a URL expandida e mantenha o mapeamento de nomenclatura descrito acima.

## Validar uma campanha

1. No mesmo navegador, abra `/f3base-teste/` e confira o cookie ativo.
2. Abra a URL de teste com IDs fictícios reconhecíveis; percorra uma página interna e envie o formulário.
3. Em Contatos, selecione Somente testes e confira classe, formulário, sessão quando permitida, plataforma, conta, campanha e anúncio.
4. Em Medição → Aquisição, use a mesma janela e o mesmo segmento. Ausência de sessão reduz cobertura, mas não apaga a atribuição do contato.
5. Saia do modo de teste. Aplique o molde na plataforma somente depois de conferir a expansão dos IDs naquela conta/formato.

Sem consentimento de medição, não há conservação do histórico local pelo resolvedor; parâmetros presentes na requisição corrente podem acompanhar o contato. Sem JavaScript não se reconstrói primeiro toque a partir de IP/horário. A atualização não inventa anúncios nos registros históricos.

## Receitas de análise

**Custo por envio de site por anúncio.** Extraia localmente envios aceitos e não spam, fora da lixeira/eliminação/testes, agregados por site/plataforma/conta/escopo/anúncio e período. Consulte gastos externos na mesma granularidade e faça união completa das chaves. CPL = gasto / envios aceitos. Sem envio, CPL é indisponível; sem gasto pareado, custo é desconhecido, não zero. Não junte a linha de gasto a cada contato antes de somar.

**Leads nativos e de site.** Liste as duas origens separadas. Na fonte externa, conserve plataforma/conta/ID original do lead e classe de teste se disponível. Não declare esses registros importados no Core. Só deduplique entre sistemas por chave confiável de origem; coincidência de e-mail/horário não é prova de mesmo envio. Conversão reportada pela plataforma não é outro lead a somar.

**Cobertura de anúncio.** Numerador: envios locais com plataforma identificada, conta e anúncio ID no molde v1. Denominador: envios elegíveis. Apresente separadamente sem conta, sem anúncio, sem sessão e com IDs que não foram encontrados no catálogo externo.

**Primeiro/último toque.** Leia `dados.atribuicao.primeiro_toque` e `.ultimo_toque`, os horários e o `modelo` creditado. Compare os dois sobre os mesmos contatos; não some suas contagens. A janela de atribuição é distinta da retenção e da data do relatório. Ausência de snapshot permanece indisponível.

**Tempo até atendimento.** Pré-agregue `atendimento_historico` por record_id para obter a primeira marcação respondido; subtraia o recebimento do lead. Ação manual não comprova entrega de mensagem nem venda. Disponível desde a coleta de histórico, sem retroagir registros antigos.

## Contrato do relatório externo

Registre site, plataforma, conta, API/versão, consulta, extração, período/fuso, moeda/unidade monetária, janela/modelo de atribuição, exclusão de testes e atraso/revisão da fonte. Google `cost_micros` precisa conversão de unidade quando esse for o campo escolhido; não aplique essa escala a campos monetários de outros fornecedores. Evite converter agregados diários entre fusos como se tivesse os instantes individuais. Se necessário use período compatível e declare a diferença.

Conserve anúncios com gasto e nenhum contato, contatos sem custo pareado e a parcela desconhecida. Taxas/percentis precisam ser recalculados com seus insumos; nomes de anúncios são rótulos mutáveis. Os dados externos podem permanecer em um snapshot autorizado separado do WordPress, sem nova tabela no plugin.

## Fontes oficiais e alcance

Referências conferidas em 28/09/2026; confira a versão efetivamente usada na consulta externa. O contrato URL do Core é v1 e não depende de instalar SDK de publicidade no WordPress.

- [Google: ValueTrack e suporte por formato](https://support.google.com/google-ads/answer/6305348?hl=pt-BR).
- [Google: correspondência ValueTrack/API](https://developers.google.com/google-ads/api/docs/reporting/valuetrack-mapping).
- [LinkedIn: hierarquia de contas e entidades](https://learn.microsoft.com/en-us/linkedin/marketing/usecases/foundations/hierarchy?view=li-lms-2026-09).
- [Meta: parâmetros de URL](https://www.facebook.com/business/help/2360940870872492), acesso autenticado pode ser necessário; conferir macros no Gerenciador da conta.


## Campos Meta e consentimento — 1.16.0

`fbc`/`fbp` são informações de correspondência da Meta, distintas de conta/campanha/conjunto/anúncio. O Core só conserva formatos válidos com publicidade permitida. Pode compor `fbc` a partir do `fbclid` da navegação atual autorizada; não fabrica `fbp`. Cookies não permitem inferir, sozinhos, que houve anúncio ou qual foi o anúncio.

Clique e formulário alimentam a CAPI pelo mesmo envelope do lead confirmado. O JSON guarda a decisão de consentimento e a redução de atribuição aplicada; a fila conserva evento original, referência e marca de teste e revalida antes do despacho. Ausência de contexto suficiente não significa autorização. Não complete histórico a partir do navegador atual ou do cron. A recepção real em Test Events depende da conta habilitada e deve ser homologada antes da ativação comercial.


## OpenAI e origens nativas na 1.16

Use `utm_source_platform=openai_ads` com utm_source/utm_medium/campaign/content coerentes e IDs explícitos da conta. `f3_ads_v=1` declara a equivalência dos IDs; não transforme rótulo em ID por conter números. oppref é um identificador opaco do clique, não o anúncio. Referência orgânica do ChatGPT permanece distinta. Não há coletor de custo/receita: agentes podem cruzar plataforma + conta_id + campanha_id + anuncio_id + período UTC com as APIs autorizadas, documentando a cobertura.

Leads de formulário nativo carregam origem_nativa e IDs do fornecedor. Não compartilham sessão do site por inferência; conversão nativa não deve inflar taxa de formulário web. Meta consulta, Google webhook/reconciliação e seus limites estão em ORIGENS-ANUNCIOS.md. Não há promessa de atribuição multi-dispositivo ou identidade entre fornecedores.
