# Core 1.21.0 → Fator3 MCP

06/10/2026. Encaminhamento para o responsável pelo MCP; nenhum arquivo do MCP foi alterado. Referência de planejamento: MCP 0.16.0, revisão 5. Core implementado: 1.21.0; contrato de conteúdo/configuração 5.1.0; `policy_contract:1` preservado. Não fixar a contagem de abilities de outro plugin.

## Contratos que o agente deve redescobrir

- `f3base/config-core-contrato-v1`: tipos estritos permanecem. Coerção de formulário HTML não torna texto numérico válido na API. Erros conservam código, caminho e motivo; simular, conferir revisão e aplicar pelo serviço central. Opções intocadas e listas vazias são preservadas.
- `f3base/execucoes-ler`: novo filtro `tarefa` pelo enum instalado, além de origem/run_id/página. Concorrência devolve ocupado/já processado com referência. Mensagens de exceção são sanitizadas, sem stack ou argumentos.
- `f3base/operacao-recuperacao-ler`: diagnóstico da sentinela e precondição. Disponível no estado inerte; ler não recria arquivo.
- `f3base/operacao-recuperacao`: ação `recriar`, `precondicao_esperada` 64 hex, `reconciliacao_confirmada:true` e `copia_outro_host` booleano explícito. `preparar`/`retomar` conservam geração positiva. Não trocar essas confirmações por `confirm:true` genérico.
- `f3base/gsc-lacunas-ler`: leitura local por propriedade/estado/página, máximo 100 linhas; propriedade define universo, consulta vazia não equivale a zero tráfego.
- Contatos: schema leads 6, `aparelho` no filtro, contexto de aparelho com versão/fonte e `dados.teste_origem`. `lead-jornada-ler` mantém **manage_options**; capability de gestão de leads não autoriza a jornada sozinha.
- `pipedrive-previa`: elegibilidade/motivo, identificadores, título/host, campos, qualidade e nota; nenhuma escrita externa. `pipedrive-reenviar` distingue persistência, agenda relida, tentativa de despacho e processamento não confirmado. Novos avisos têm estado próprio no journal.

Schemas completos e exemplos de configuração estão instalados em `docs/dados/abilities-*.json`, `dados/contrato.json`, `RELEASE-1.21.md` e `PIPEDRIVE.md`, acessíveis por `documentacao-ler`. O schema de saída nativo genérico pode receber a decoração do MCP no runtime; a política e autorização do MCP prevalecem no seu canal.

## Restore e SQL

Não acrescentar aquecimento do registro de terceiros no Core. Perfil Leitura deve recusar recriação, retomada, execução, reenvio e configuração. Autorizações de consumidor PHP Google não mudam com o perfil humano MCP.

Antes de restore integral ou de tabela com dados operacionais, preparar/drenar ambos os complementos e preservar seus arquivos de guarda externos ao banco. Retomar Google antes de Core. Core invalida cursores/reservas e mantém intenções de entrega, CAPI, CRM, eliminação externa e avisos restaurados suspensos/incertos. Restore parcial não concede autorização de reenvio. Cópia de host renova identidade e exige nova verificação externa.

SQL de manutenção não substitui o gravador central de configuração. Atividade de cron fora da seleção não deveria invalidar confirmação MCP; conflito dentro da seleção permanece conflito. A guarda SQL e o mecanismo de backup continuam responsabilidade do MCP; nenhuma alteração foi feita neles.

Cookie de 365 dias marca apenas navegação no mesmo navegador/origem. Não amplia sessão/credencial MCP, não autentica visitante e não usa IP ou horário do canal para excluir visitas.

## Evidência e próximos ensaios

Core real 1.21.0 foi executado em laboratório com MCP **0.15.0 real**, instalador SHA-256 `fcc1c8d79e60bdbeb932c52e22150c3c0e88f1c06f7469289cab7c2dbf9af8d6`. Quinze verificações de provider, decoração, leitura, recusa de mutações pelo perfil Leitura, manutenção e anônimo passaram. Não houve conexão remota do agente nem alteração na frota.

MCP 0.16.0 não foi homologado nesta entrega: recebido como encaminhamento de plano. Repetir com o pacote final: descoberta inicial, estado inerte, perfis, schemas novos e restore conjunto/seleção SQL. Nenhuma mudança obrigatória no código MCP 0.15 foi identificada para o funcionamento básico do Core. Sete dias sem Duplicate entry na frota permanecem acompanhamento posterior, não alegação deste teste.
