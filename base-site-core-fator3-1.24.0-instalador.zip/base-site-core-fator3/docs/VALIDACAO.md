# Validação — Core 1.24.0

Bancada local com PHP 8.3, WordPress e MariaDB; dados sintéticos; HTTP externo e e-mail bloqueados ou simulados. Nenhuma implantação em produção foi executada.

## Provas executadas

- instalação nova e atualização exclusiva da 1.23.0, com repetição, preservação de 130 contatos de formatos distintos e checkpoint final sob falha de banco;
- captura concorrente com a trava de consentimento ocupada, expurgo com margem de 24 horas, reparos terminais/órfãos, intenções esgotadas/suspensas e importação de 211 entradas com descarte diagnosticado;
- recuperação em processos novos: sentinela ausente/inválida/pausada, link em trava e índice; atendimento/captura continuam apenas na degradação permitida e mutações coordenadas são recusadas;
- MCP 0.16.0 e Google 0.7.1 reais, nas duas ordens de carga e nos dois caminhos de instalação; guardas independentes;
- CRM simulado com falha de checkpoint antes de POST, limpeza de etapa, lease concorrente, catálogo preservado, repetição de verificação e erros estruturados do provedor;
- e-mail MIME HTML/texto, cabeçalhos, mensagem aninhada, interceptor e restauração do mailer; nenhum SMTP externo;
- redirects em dois ciclos, edição entre ciclos, duplicatas, restauração sem mutação e histórico sem pré-imagem;
- relatórios com API real local: Android/Instagram celular, faixas, sistema, novo/recorrente, filtros, contato pareado, duas campanhas/anúncios, duração, cobertura, 404 e exclusões;
- Chromium 140 real sobre os arquivos fonte e minificados: persistência novo/recorrente, teste separado, revogação, saída deduplicada, tempo visível, BFCache, salto, seção alta, tempo ativo, três origens de clique e exclusões;
- renderização de todas as áreas de Medição, Integrações e das três abas do Core com warnings/notices do plugin convertidos em exceção;
- lint PHP, minificação Terser reprodutível, manifesto de assets, contratos gerados e comparação do instalador fechado com o fonte.

## Aceites externos ainda necessários

Na homologação do site: conferir SMTP/caixa real e aparência em Gmail/Outlook; credencial, permissões e formatos reais do Pipedrive; OAuth/concessão Google; cache/CDN/proxy, proteção HTTP das pastas e DebugView do GA4 para 404/editor. Conta externa, entrega de e-mail e infraestrutura pública não podem ser provadas pela bancada.
