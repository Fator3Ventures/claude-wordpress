# Release 1.22.1 — correção da conferência de 1.22.0

## Instalação e migração

Origens aceitas: WordPress limpo, 1.21.0 concluída e 1.22.0 (concluída ou interrompida). Instale substituindo a pasta `base-site-core-fator3`. O novo estado é `f3base_release_1221`. Estados anteriores são evidência; não são apagados nem usados para simular conclusão.

A etapa de limpeza examina até 50 linhas ou cerca de três segundos por passagem, persiste o cursor por tabela e continua após cinco segundos. Só retira campos diferentes de `tipo` e `id` dos registros de `outras_oportunidades`. Fora desses registros, conserva os bytes do JSON, incluindo objetos vazios, unicode, barras e números. NULL, vazio, escalar e JSON inválido não são regravados. Disputa de atualização é retomável; erro real de banco fica diagnosticado com recuo. Falha persistente requer correção da causa, não repetição de uma migração destrutiva.

Avisos individuais pendentes anteriores ao início da atualização passam a `aguarda_resumo`, em lotes de 100. A rotina individual aguarda essa fase; novos contatos não entram no resumo por simplesmente cruzarem a hora. E-mail mínimo com link administrativo é enviado se a preparação detalhada lançar exceção, antes de qualquer tentativa de transporte. Transporte incerto nunca é reenviado automaticamente.

A atualização pendente não apaga a agenda do Search Console. Prontidão do acervo depende da estrutura real, propriedade, configuração e guarda; a concessão Google continua sendo conferida pelo SDK. A agenda de atualização existente não provoca nova escrita de `f3base_estrutura_estado` em cada visita.

Aceite local: `f3base/como-usar` retorna atualização concluída. Se houver erro, consultar `f3base/saude-ler` e os checkpoints. Para arquivo protetor divergente ou falha de trava, a Saúde mostra pendência crítica; não sobrescrevemos arquivo desconhecido nem seguimos symlinks. Corrija permissões/arquivo na hospedagem, leia novamente a guarda e só então use a ação apropriada.

## Histórico, captura e compartilhamento

O histórico local considera o consentimento registrado na captura. Uma mudança da política atual não apaga sua origem/jornada. Revogação explicitamente registrada continua negando a projeção. Decisões vinculadas a contatos retidos são conservadas mesmo depois de vencer a autorização para novos envios. Isso não autoriza novas tags ou eventos publicitários; os portões atuais continuam valendo.

IP, fonte do IP e user agent permanecem no registro local conforme a retenção já configurada, mas só entram em novos corpos de e-mail/nota com medição atualmente autorizada. A tela administrativa continua mostrando dados locais nas áreas técnicas restritas. Revogações antigas já expurgadas não podem ser reconstruídas; não há recuperação inventada de evidência.

Cliques e formulários JavaScript enviam `largura_janela` (1–20000 pixels) e `max_touch_points` (0–20), validados e retidos com medição permitida em `dados.contexto`. O sinal de toque melhora a inferência de iPad com user agent de Mac; é declaração do cliente, não identificação garantida. `dados.dispositivo` histórico continua sendo a faixa `movel`/`desktop`, rotulada como faixa, nunca pixels. Sem JavaScript ou sem sinal, o dado fica indisponível. O histórico não degrada classificação que já existia nem repete indefinidamente linhas com dados não objetos.

## Pipedrive

Verificação de conta e qualidade dos mapas são estados distintos. Mapa legado inválido ou formulário removido produz `mapeamento_pendencia`, sem apagar conta verificada nem catálogos. Campos de papel são conferidos contra o catálogo e limitados ao tamanho declarado; desconhecidos não são enviados. O proprietário deve corrigir o mapa no painel; a atualização não adivinha chaves.

Timeout, indisponibilidade e leitura parcial preservam a última verificação da **mesma configuração e credencial**, com `ultima_tentativa` indicando falha. Recusa de autenticação/permissão invalida o acesso. Catálogos novos só são publicados quando o conjunto inteiro foi obtido. A cota/pausa da API continua aplicada.

Sem mapa explícito, um único campo de pessoa textual chamado LinkedIn, Perfil LinkedIn ou URL LinkedIn no catálogo é usado para busca e gravação. Nenhum campo ou múltiplos candidatos exigem mapeamento explícito; o perfil continua na nota. Não criamos campos remotos automaticamente. Telefone não normalizável é preservado como texto de contato, mas não serve como prova de identidade. Busca parcial sempre exige normalização e conferência dos identificadores retornados.

Contatos → Integrações → Entregas oferece reconciliação de pessoa, lead próprio e inclusão explícita de e-mail alternativo. **Conferir referência** só consulta; **Confirmar reconciliação** reaplica a prova remota e a revisão local. Falha de reconciliação preserva o estado anterior da entrega.

Ao reagendar, **Executar um lote agora** solicita uma passagem limitada por reservas e orçamento, inclusive com `DISABLE_WP_CRON`. Não habilita WP-Cron nem garante entrega remota imediata. Sem essa opção, a agenda continua dependendo do executor configurado.

Avisos confirmadamente falhos têm até três tentativas. Ausência de destinatário também tem reavaliação limitada. Esgotados saem da seleção ativa. Transporte incerto requer conferência humana para não duplicar mensagens. Sucesso limpa `ultimo_erro`; a revisão posterior da pessoa conserva marcas de atividade complementar.

O formulário administrativo vale duas horas mesmo sem JavaScript. Com JavaScript a validade é conferida antes de transmitir o segredo. Ao vencer o limite, reabra a área e redigite a credencial; não armazenamos rascunhos de segredos.

## Contratos e limites

`f3base/redirects-historico-escrever` aceita `acao: retirar|restaurar` (padrão retirar), com simulação, revisão e confirmação. Retirada limpa o caminho e o slug próprio quando ele não sustenta outro caminho retido; marca exata impede fallback de reativá-lo. Restaurar remove a marca e repõe o caminho. Desinstalação remove a marca privada; `_wp_old_slug` de WordPress não é apagado globalmente.

O antigo `sentinela_indisponivel` deve ser tratado pelos clientes pelos estados específicos (`sentinela_ausente`, `sentinela_invalida`, `sentinela_ilegivel`, `trava_inacessivel`, `trava_ocupada`, `trava_falhou`, `indice_protetor_indisponivel`), além de `ok`, `pausado` e `modulos_inicializados`. A chave de documentação deixou de ser `documentacao_1200`; use o índice versionado de `f3base/documentacao-ler` em vez de inferir nomes por release.

`docs/dados/configuracao-schema.json` é a referência completa de opções, incluindo `f3base_pipedrive`; `docs/dados/contrato.json` contém a referência e os campos adicionais de captura. Abilities completas estão em `docs/dados/abilities-*.json`. O serviço Google permanece `search-console-reader/1.0.0`.

A 1.21.0 podia substituir procedência sem conservar uma pré-imagem no mapa nativo de última escrita. A 1.22.1 não atribui autoria a partir de um horário. Quando uma fotografia/auditoria anterior verificável existe, `f3base/config-procedencia-reparar` restaura somente metadados com revisão e prova; a restauração automática da frota sem essa evidência não está entregue. Valores que a 1.22.0 já regravou antes de parar também exigem backup para reconstrução.

Notas antigas no CRM não são editadas em massa. Webhook genérico continua adiado por decisão anterior. Homologação de buscas, atividade, campos monetários e Clarity com contas reais pertence ao aceite pós-entrega; os testes locais usam respostas simuladas.
