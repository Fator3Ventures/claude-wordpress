# Entrega 1.22.1 — matriz de conferência

Data: 07/10/2026. Base analisada: relatório de conferência da 1.22.0 publicada, SHA-256 `3e38a0ca21e994bea21edb959ecb66a6d8cf026b7a5502ec0dc690df0efa51e5`.

A nova versão corrige o bloqueio da migração, a retomada sempre adiada e a perda de verificação/catálogos em falha transitória. Não foi instalada em sites da frota. Nenhum outro plugin foi modificado.

**Como ler a matriz:** “Entregue no código” identifica implementação e evidência local, não homologação na conta real. “Em parte” delimita comportamento restante; não deve ser reclassificado como integral. Arquivos e linhas referem-se ao plugin dentro do ZIP. Scripts/provas ficam em `suite/versao-1221/` no ZIP de fontes. As letras não presentes no pedido não foram inventadas.

## Bloqueio da migração

Instalação nova, atualização do fonte real 1.21.0 e reprodução do erro real da 1.22.0 seguida de recuperação pela 1.22.1 foram exercitadas em WordPress/MariaDB locais. Cada atualização usa 130 contatos com entrega NULL, vazia, inválida, escalar e JSON com unicode/objetos vazios, dados escalares, snapshot sem papel e avisos pendentes antigos. Mapas com espaço e formulário removido têm teste separado em `verificacao-crm.php`.

Cursor persistente limita limpeza a 50 linhas/3 segundos; absorção de avisos antigos é em lotes de 100. O teste compara a entrada com a saída de cada versão e repete em outra requisição. A 1.22.0 pode regravar linhas antes de falhar; sem backup, a 1.22.1 não restaura conteúdo que já se perdeu. Valores que chegam NULL continuam NULL.

## Pedidos por letra

| Pedido | Situação | Resultado e limite | Código | Evidência local / aceite restante |
|---|---|---|---|---|
| 107 (a) | Entregue no código | Índice 404 garantido quando ausente; arquivo correto é lido, não regravado a cada visita. | `includes/class-f3base-recuperacao.php:25` | recuperacao-processos |
| 107 (b) | Entregue no código | Entrada/falha de trava exposta; recriação pode prosseguir com guarda válida e trava falha, somente após confirmação e reserva exclusiva. Symlink é recusado. | `includes/class-f3base-recuperacao.php:29` | recuperacao-processos; revisão de código |
| 107 (c) | Entregue no código | Saúde crítica inclui a pendência de trava e mantém acesso ao diagnóstico no bootstrap inerte. | `includes/class-f3base-saude.php:82` | recuperacao-processos; render |
| 107 (d) | Entregue no código | Recriação descreve suspensão de filas e pode manter a pausa. CLI apresenta ação e pré-condições. | `includes/class-f3base-cli.php:11` | recuperacao-processos |
| 108 (a) | Entregue no código | Assuntos válidos para mudanças; entradas de navegação e llms normalizadas. | `dados/mudancas.json:387` | auditoria do catálogo; serviços |
| 108 (b) | Entregue no código | Três ocorrências do nome antigo corrigidas; busca literal no instalador não retorna ocorrências. | `base-site-core-fator3.php:162` | busca literal; lint |
| 108 (e) | Entregue no código | Ausência de CLI nas últimas duas horas aparece como pendência, sem afirmar que crontab está desligado. | `includes/class-f3base-saude.php:8` | operacao-jornada |
| 109 (a) | Entregue no código | Exceção traz classe, etapa, arquivo, linha e causa segura; sem argumentos/payload no log. | `includes/class-f3base-operacao.php:85` | executor-falhas |
| 109 (b) | Entregue no código | Concorrência comprovada em reservas/ocorrências retorna ocupada. Os três erros de checkpoint/agenda continuam falhas quando não há prova de disputa, com causa. Aceite ajustado pelo dono preservado. | `includes/class-f3base-operacao.php:105` | concorrencia-processos; executor-falhas |
| 109 (c) | Entregue no código | Exceção antes de criar tarefa grava tentativa identificada e log saneado. | `includes/class-f3base-operacao.php:143` | executor-falhas; falhas-1221 |
| 111 (a) | Entregue no código | Assunto sem código interno; página sem post usa URL e ausência total tem texto explícito. | `includes/class-f3base-leads-notificacoes.php:29` | revisao-relatorio; avisos |
| 111 (b) | Entregue no código | Destino preserva tel/mailto e telefone público de WhatsApp. | `includes/class-f3base-contato-apresentacao.php:18` | mapas-apresentacao |
| 111 (c) | Entregue no código | Eventos de link externo entram na jornada. | `includes/class-f3base-contato-apresentacao.php:68` | operacao-jornada |
| 111 (d) | Entregue no código | Origem, mídia, campanha, modelo e cobertura com rótulos; metadados iguais não se repetem nos toques. | `includes/class-f3base-contato-apresentacao.php:45` | mapas-apresentacao; revisão |
| 111 (e) | Entregue no código | Consentimento, sessão, pixels novos e faixa histórica corretamente rotulados. | `includes/class-f3base-contato-apresentacao.php:33` | revisao-relatorio; render |
| 111 (f) | Entregue no código | Respostas em listas e deduplicação por papel; nomes históricos conhecidos também sem papel. | `includes/class-f3base-contato-apresentacao.php:75` | avisos; revisao-relatorio |
| 111 (g) | Entregue no código | Aparelho não imprime separadores de valores vazios. | `includes/class-f3base-contato-apresentacao.php:94` | mapas-apresentacao |
| 111 (h) | Entregue no código | Corte e limites constam do corpo, com qualidade deduplicada. | `includes/class-f3base-contato-apresentacao.php:96` | operacao-jornada; mapas-apresentacao |
| 111 (i) | Entregue no código | Exceção de preparação usa corpo mínimo, antes do transporte; resultado incerto não é duplicado. | `includes/class-f3base-leads-notificacoes.php:100` | avisos; falhas-1221 |
| 111 (j) | Entregue no código | Lotes individuais não entram em resumo pela virada da hora; pendentes anteriores à atualização são absorvidos separadamente. | `includes/class-f3base-leads-notificacoes.php:9` | avisos; ciclo-instalacao |
| 111 (k) | Entregue no código | Histórico mantém origem/jornada quando a política muda; revogação registrada permanece respeitada. | `includes/class-f3base-contato-apresentacao.php:40` | revisao-relatorio |
| 113 (a) | Entregue no código | Jornada aparece antes de CRM e avisos. | `includes/class-f3base-leads-admin.php:247` | render |
| 113 (b) | Entregue no código | Páginas distintas, carregamentos e duração visíveis. | `includes/class-f3base-relatorios.php:204` | render; operacao-jornada |
| 113 (c) | Entregue no código | Motivo, corte e uma única mensagem sem observações. | `includes/class-f3base-relatorios.php:203` | render; operacao-jornada |
| 113 (d) | Entregue no código | Cliques externos compõem a jornada. | `includes/class-f3base-contato-apresentacao.php:68` | operacao-jornada |
| 113 (e) | Entregue no código | Cabeçalhos acentuados e união de colunas entre fontes. | `includes/class-f3base-relatorios.php:201` | regressoes; render |
| 113 (f) | Entregue no código | Origem histórica, modelo e cobertura conservados. | `includes/class-f3base-contato-apresentacao.php:40` | revisao-relatorio |
| 113 (g) | Entregue no código | Capacidade de leitura de leads permite a jornada. | `includes/class-f3base-relatorios.php:178` | operacao-jornada |
| 115 (a) | Em parte | Site/formulário e causas principais em palavras; códigos não catalogados continuam acompanhados de orientação por família e diário. Não se inventa causa que o provedor omitiu. | `includes/class-f3base-pipedrive-alertas.php:12` | avisos; crm-atividade |
| 115 (b) | Em parte | Falha confirmada e falta de destinatário têm reavaliação limitada; esgotados são terminais. Incerto não é reenviado automaticamente por risco de duplicação. | `includes/class-f3base-pipedrive-alertas.php:30` | avisos; revisão da seleção |
| 115 (c) | Entregue no código | Conta só alerta após duas observações e espera; corpo nomeia o site e considera contatos realmente aguardando. | `includes/class-f3base-pipedrive-alertas.php:50` | avisos; revisão |
| 116 (a) | Entregue no código | País BR para base válida sem país; nacional completo normaliza antes de buscar. Número não normalizável continua no campo como texto, sem servir de identidade. | `includes/class-f3base-pipedrive-api.php:61` | mapas-apresentacao; crm |
| 116 (b) | Entregue no código | Nota declara ausência de meio de contato; WhatsApp explicita dependência da conversa. | `includes/class-f3base-contato-apresentacao.php:90` | crm; revisão |
| 116 (c) | Entregue no código | LinkedIn aceita host móvel, sufixo de idioma e unicode; resultados encontrados são normalizados para confirmar identidade. | `includes/class-f3base-pipedrive-api.php:58` | regressoes; revisao-relatorio; aceite remoto pendente |
| 116 (d) | Entregue no código | Reconciliação por ID disponível na tela, em duas etapas e com prova/revisão. | `includes/class-f3base-integracoes.php:133` | crm-reconciliacao; render |
| 116 (e) | Em parte | Campo LinkedIn único e compatível pode ser usado sem mapa explícito. Ausente/ambíguo exige escolher/criar o campo na conta; não criamos schema remoto automaticamente. | `includes/class-f3base-pipedrive-api.php:10` | verificacao-crm |
| 117 (a) | Entregue no código | Pixels e faixa histórica aparecem com unidades corretas na tela e no corpo. | `includes/class-f3base-contato-apresentacao.php:33` | revisao-relatorio; render |
| 117 (b) | Entregue no código | Tipo, sistema e navegador no cabeçalho. | `includes/class-f3base-leads-admin.php:246` | render |
| 117 (c) | Entregue no código | Sinal de toque capturado permite inferir iPad/Mac; sem sinais suficientes não há certeza. | `includes/class-f3base-leads-contexto.php:61` | revisao-relatorio; assets |
| 117 (d) | Entregue no código | Novas colunas no fim do CSV, record_id permanece primeiro. | `includes/class-f3base-leads-admin.php:60` | regressoes |
| 117 (e) | Entregue no código | Histórico preserva classificação existente, escreve unicode legível e avança sobre dados escalares. | `includes/class-f3base-contato-apresentacao.php:114` | revisao-relatorio |
| 117 (f) | Entregue no código | Relatório distingue faixa de janela e aparelho. | `includes/class-f3base-relatorios.php:173` | revisão de texto |
| 118 (a) | Entregue no código | Estilo do selo está no CSS carregado em Contatos. | `admin/assets/f3base-interface.css:1` | render |
| 118 (b) | Entregue no código | Um único selo no cabeçalho do contato. | `includes/class-f3base-leads-admin.php:244` | render; revisão |
| 118 (c) | Entregue no código | Origem da marca só aparece para teste; lead real não imprime origem desconhecida. | `includes/class-f3base-contato-apresentacao.php:74` | revisao-relatorio |
| 121 (a) | Entregue no código | Nota com títulos em negrito e listas. | `includes/class-f3base-contato-apresentacao.php:109` | crm |
| 121 (b) | Entregue no código | Site aparece uma vez no topo da nota. | `includes/class-f3base-contato-apresentacao.php:109` | crm; mapas-apresentacao |
| 121 (c) | Entregue no código | Seções Contato, Acontecimento, Comportamento no site e Origem usam os mesmos títulos. | `includes/class-f3base-contato-apresentacao.php:78` | render; crm |
| 121 (d) | Entregue no código | Consentimento explícito; IP/UA só com autorização atual. Caminhos sem post agrupam barra final. | `includes/class-f3base-contato-apresentacao.php:98` | revisao-relatorio; operacao-jornada |
| 121 (e) | Entregue no código | Herança das correções de destino, respostas, origem, aparelho e corte. | `includes/class-f3base-contato-apresentacao.php:87` | mapas-apresentacao; crm |
| 121 (f) | Não entregue por decisão/limite | Notas antigas não são reformatadas em massa; somente novas notas usam o formato. Mantida decisão anterior. | `includes/class-f3base-contato-apresentacao.php:109` | limite explícito; sem mutação retroativa |
| 124 (a) | Entregue no código | Etiqueta de pessoa usa label/name conforme o catálogo. | `includes/class-f3base-integracoes.php:67` | crm; mapas-apresentacao; aceite real pendente |
| 124 (b) | Entregue no código | Verificação carrega campos de pessoa e atualiza o catálogo. | `includes/class-f3base-integracoes.php:67` | crm; mapas-apresentacao; aceite real pendente |
| 124 (c) | Entregue no código | Pessoa existente preserva suas etiquetas; retomada não reetiqueta por configuração nova. | `includes/class-f3base-pipedrive-fila.php:115` | crm; mapas-apresentacao; aceite real pendente |
| 125 (a) | Entregue no código | Estado distingue ausência de token, verificação pendente, desligada e pausa. | `includes/class-f3base-pipedrive-configuracao.php:78` | render; crm; revisão de texto |
| 125 (b) | Entregue no código | Texto Entregando não começa com ponto; causa pendente em palavras. | `includes/class-f3base-pipedrive-configuracao.php:87` | render; crm; revisão de texto |
| 125 (c) | Entregue no código | Salvar com integração desligada informa que só preparou configuração/credencial. | `includes/class-f3base-integracoes.php:103` | render; crm; revisão de texto |
| 125 (d) | Entregue no código | Contagens, inclusive zeros, ficam junto ao título. | `includes/class-f3base-pipedrive-configuracao.php:89` | render; crm; revisão de texto |
| 126 (a) | Entregue no código | Exemplo sem_campanha corrigido; novas chaves com espaço recusadas. Legado inválido não derruba conta. | `docs/PIPEDRIVE.md:63` | verificacao-crm; mapas-apresentacao |
| 126 (b) | Entregue no código | Ajuda efetiva e documentação gerada citam chaves reservadas; correção não fica oculta por ajuda antiga. | `includes/class-f3base-pipedrive-configuracao.php:7` | gerar-contratos; mapas-apresentacao |
| 126 (c) | Entregue no código | Origem não observada é distinta de origem observada sem campanha. | `includes/class-f3base-pipedrive-fila.php:98` | mapas-apresentacao |
| 127 (a) | Em parte | Verificação remota do token em vez de tamanho/alfabeto não documentado. Sem domínio/resposta válida o token anterior é preservado; simulação também faz GET. Não há aceitação silenciosa de palavra. | `includes/class-f3base-pipedrive-credencial.php:7` | credencial; sem conta real |
| 127 (b) | Entregue no código | Recusa segura mantém metadados de simulação e causa útil. | `includes/class-f3base-core-config-mcp.php:276` | credencial |
| 127 (c) | Entregue no código | Os seis segredos recusam espaços internos, controles e prefixos de cabeçalho. | `includes/class-f3base-segredos.php:8` | revisao-relatorio |
| 129 (a) | Entregue no código | Texto informa soma de GTM aos slots, não repetição de IDs e ability com prefixo f3base/. | `includes/class-f3base-modulo-tracking.php:88` | revisão; gerar-contratos |
| 130 (a) | Entregue no código | Rota com simulação/revisão/retirada/restauração; exclui slug próprio quando não sustenta outro caminho; uninstall limpa a marca. | `includes/class-f3base-redirects-historico.php:24` | servicos; falhas-1221 |
| 130 (b) | Não entregue por decisão/limite | Alternativa de registrar metadados para exclusão genérica não usada: a rota específica de (a) protege os outros caminhos. | `includes/class-f3base-redirects-historico.php:7` | decisão entre alternativas do pedido |
| 131 (a) | Entregue no código | Prova de domínio persistida evita reler PSL em toda visita. | `includes/class-f3base-gsc.php:18` | gsc-cache |
| 131 (b) | Entregue no código | Ocorrência ocupada/processada não ganha nova identidade agendada. | `includes/class-f3base-operacao.php:104` | concorrencia-processos; executor-falhas |
| 131 (c) | Entregue no código | Título Unicode usa remoção por expressão regular, não trim por bytes. | `includes/class-f3base-pipedrive-configuracao.php:30` | mapas-apresentacao |
| 131 (d) | Entregue no código | Desligar integração com mapa inválido continua permitido. | `includes/class-f3base-integracoes.php:35` | regressoes; mapas-apresentacao |
| 131 (e) | Entregue no código | Linhas inelegíveis são marcadas e deixam de impedir as seguintes. | `includes/class-f3base-pipedrive-fila.php:153` | crm-reconciliacao |
| 131 (f) | Entregue no código | Novos diários e migração não retêm títulos de oportunidades alheias. | `includes/class-f3base-json-diario.php:7` | revisao-relatorio; ciclo-instalacao |
| 131 (g) | Entregue no código | Desinstalação inclui gsc_lacunas. | `uninstall.php:123` | inspeção de código |
| 131 (h) | Entregue no código | Lista longa de e-mails permanece inteira quando não editada. | `admin/class-f3base-admin-entrada.php:6` | regressoes |
| 131 (i) | Entregue no código | Contrato de configurações e nota sobre mudanças de recuperação/documentação incorporados. | `docs/dados/contrato.json:5699` | gerar-contratos; documentos |
| 131 (j) | Entregue no código | POST sem edição preserva revisão, quebras de linha e listas. | `admin/class-f3base-admin-entrada.php:77` | config; regressoes |
| 131 (k) | Entregue no código | Dois textos antigos de Integrações substituídos pelo fluxo atual. | `includes/class-f3base-integracoes.php:164` | revisão de texto |
| 132 (a) | Entregue no código | Tentativas antes/na reserva têm tarefa e hook. | `includes/class-f3base-execucoes.php:68` | executor-falhas; concorrencia-processos |
| 132 (b) | Entregue no código | Campo site inválido omitido; prévia mostra nome/papel/tipo. | `includes/class-f3base-pipedrive-configuracao.php:75` | mapas-apresentacao |
| 132 (c) | Entregue no código | Pessoa/lead próprio e e-mail alternativo explícito também pela UI. | `includes/class-f3base-integracoes.php:133` | crm-reconciliacao; render |
| 132 (d) | Entregue no código | Execução explícita de lote no reagendamento respeita reservas mesmo com WP-Cron desabilitado. | `includes/class-f3base-integracoes.php:130` | executor-falhas; revisão do POST; aceite UI pendente |
| 132 (e) | Entregue no código | Variável site posicionável e empresa vazia cai para nome. | `includes/class-f3base-pipedrive-configuracao.php:25` | mapas-apresentacao |
| 132 (f) | Entregue no código | Número/moeda/data e seletores mantidos; todos os textos comerciais cortados segundo catálogo. | `includes/class-f3base-pipedrive-fila.php:97` | mapas-apresentacao; ui-dom; moeda real pendente |
| 132 (g) | Entregue no código | Status do token não depende do status geral, sem verified vazio. | `admin/class-f3base-admin-tela.php:269` | regressoes; render |
| 132 (i) | Entregue no código | Versão estrutural 1.22.1 e confirmação real da migração. | `includes/class-f3base-atualizacao.php:10` | ciclo-instalacao |
| 132 (h) | Em parte | Contexto estendido para duas horas também sem JS; renovação pré-submit preserva segredo no navegador. Após limite absoluto, redigitar é necessário; segredo não é salvo como rascunho. | `admin/class-f3base-admin-entrada.php:12` | form-context; ui-dom |
| 133 (a) | Entregue no código | Atividade v2 usa participants. | `includes/trait-f3base-pipedrive-atividade.php:16` | crm-atividade; aceite real pendente |
| 133 (b) | Entregue no código | Falha complementar não suspende o núcleo entregue; rever_pessoas preserva marca da atividade. | `includes/class-f3base-pipedrive-fila.php:155` | crm-atividade; revisão |
| 133 (c) | Em parte | Etapa, HTTP e identificadores seguros disponíveis no diário; campo/código ficam nulos quando a API não os fornece. Sucesso limpa erro antigo. | `includes/class-f3base-pipedrive-api.php:46` | crm-atividade; resposta real pendente |
| 134 (a) | Entregue no código | Complementação preserva origem, canal e data; valida antes de gravar. | `includes/trait-f3base-options-complementacao.php:16` | procedencia; procedencia-falhas; verificacao-crm |
| 134 (b) | Entregue no código | Leitura distingue configurado/complementado/padrão e lista subchaves. | `includes/trait-f3base-options-complementacao.php:73` | procedencia; ciclo-instalacao |
| 134 (c) | Em parte | Reparo verificável disponível; sem pré-imagem/auditoria anterior não há restauração automática da frota. Horário não prova autoria. | `includes/trait-f3base-options-complementacao.php:80` | procedencia; procedencia-falhas |
| 135 (a) | Entregue no código | Campo secreto, estado e projeto vinculados na área Clarity. | `admin/class-f3base-admin-clarity.php:51` | clarity-admin; token real do dono pendente |
| 135 (b) | Entregue no código | Teste compartilha as cotas e preserva primeira coleta local. | `admin/class-f3base-admin-clarity.php:7` | clarity-admin; token real do dono pendente |
| 135 (c) | Entregue no código | Ajuda gerada aponta para a área correta da tela. | `admin/class-f3base-admin-clarity.php:7` | clarity-admin; token real do dono pendente |

## Onze defeitos novos apontados na conferência

| Nº | Situação | Resultado |
|---|---|---|
| 1 | Corrigido o bloqueio da retomada | Prazo de intenção existente é preservado ao observar interrupção; espera não cria diário. Sucesso retira intenção. Pendências reais não expiram artificialmente e não têm teto que descarte trabalho; uma fila permanentemente impedida ainda exige ação operacional. |
| 2 | Corrigido | Mapa inválido não revoga acesso da conta; diagnóstico separado. |
| 3 | Corrigido | Falha transitória mantém prova e catálogos da mesma revisão; 401/403 invalida. |
| 4 | Corrigido o diagnóstico | Índice divergente não é sobrescrito silenciosamente; Saúde crítica expõe a causa. Corrigir arquivo/permissão na hospedagem pode ser necessário. |
| 5 | Corrigido | Complementação valida o contrato; valor inválido existente é preservado e diagnosticado. |
| 6 | Corrigido | Reserva de reconciliação não muda uma entrega concluída para revisão. |
| 7 | Corrigido | Classificação anterior preservada; cursor termina com dados escalares; unicode legível. |
| 8 | Corrigido | Alerta com três falhas passa a esgotado e sai da seleção ativa. |
| 9 | Corrigido | Avisos anteriores à atualização são separados em resumo antes dos lotes individuais. |
| 10 | Corrigido | Sucesso limpa erro antigo e rever_pessoas não apaga o estado da atividade complementar. |
| 11 | Corrigido | Serviço interno de validar credencial não depende de usuário autenticado. Entradas administrativas e abilities mantêm autorização. |

## O que exige conta real ou evidência externa

- Pipedrive: dois envios com mesmo telefone nacional na mesma pessoa; representação de URL LinkedIn já existente; etiqueta da pessoa; campo monetário; atividade Primeiro contato ligada ao lead; payload de erro real do provedor.
- Clarity: dono cola o token na tela, confirma vínculo ao projeto e verifica a primeira coleta. Não houve uso de credencial real nesta entrega.
- Site-Teste: instalação do ZIP e aceite visual das abas/relatórios; nenhum acesso ou implantação na frota foi realizado. O usuário fará os testes, inclusive no piloto.
- Procedência e JSON já perdidos por versões anteriores: precisam de auditoria/pré-imagem/backup; a versão não fabrica o histórico.

Incerto não significa falhou: e-mail com resposta de transporte perdida não é repetido automaticamente. Também não há edição em massa de notas antigas nem criação automática de campos na conta Pipedrive. São limites deliberados, documentados, não itens declarados integralmente entregues.

## Compatibilidade com outros plugins

Leia `IMPACTO-1.22.1-MCP.md` e `IMPACTO-1.22.1-GOOGLE.md`. Não há alteração obrigatória nos demais plugins. O Core oferece diagnóstico mais específico e continua consumindo o contrato público Google, sem assumir responsabilidade por tema/implantador.
