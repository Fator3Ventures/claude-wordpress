# Impacto do Core 1.24.0 no Fator3 MCP

Nenhuma mudança de código é necessária no MCP. O Core aceita versão 0.16.0 ou posterior somente quando `ServerContract::capabilities()` publica contrato exato `server-integration/1.0.0`, política 1 e versão estável compatível. A política do canal continua somada às permissões nativas. Novos filtros e campos aparecem nos schemas das abilities do Core; o MCP deve encaminhar o schema publicado sem manter cópia própria.
