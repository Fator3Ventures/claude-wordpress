# Encaminhamento final ao MCP — Core 1.22.0

06/10/2026. Implementado no Core; nenhum arquivo do MCP foi modificado. Bases Core suportadas: nova ou 1.21.0. Este relatório substitui o encaminhamento planejado da revisão 4 quanto aos contratos entregues.

## Contratos entregues

Provider `base-site-core-fator3`, policy_contract 1, contrato de configuração 5.2.0. Descobrir o registro público normal; não requer aquecimento privado, SQL genérico ou ampliação automática das permissões da conexão. Schemas finais acompanham `docs/dados/abilities-*.json` e `configuracao-schema.json`.

| Interface | Orientação ao consumidor |
|---|---|
| documentacao-ler | Disponível em processo novo com guarda ausente/inválida/pausada ou trava ocupada. Exige administração; não inicia módulos comerciais. Alias estável docs/DOCUMENTACAO.md; chave documentacao_1210 mantida na transição. |
| operacao-recuperacao | Recriar admite manter_pausado: true; continua exigindo precondição, confirmação e declaração de cópia de host. Recriação não significa drenagem/prontidão: preparar é separado. |
| Saúde/execuções | Estado persistido da guarda, tentativa de entrada e módulos carregados são diferentes. Tentativas de disputa entram por tarefa/hook/origem. CLI ausente em 2h é falta de evidência, não certificação do crontab. |
| config-core-escrever | Nova proposta de token Pipedrive consulta users/me mesmo em simulação; não grava configuração/objetos comerciais. Pode consumir cota remota. Resposta declara verificacao_remota. Campos/segredos intocados não disparam consulta. |
| config-core-ler | Procedência preservada ao complementar; composição/histórico/reparo novos. Revisão muda com valor; consumidor deve reler e reaplicar somente o delta desejado. |
| config-complementacoes-ler | Página de até vinte eventos por opção, sem valores de configuração. |
| config-procedencia-reparar | Prévia/aplicação administrativa com snapshot f3base-procedencia/1, referência, revisão e confirmação. Ausência de histórico não autoriza inventar origem. Não depende de alteração no MCP. |
| lead-jornada-ler | Leitura nativa por f3base_ler_leads ou manage_options; gestão isolada não concede leitura. Permissões da conexão continuam cumulativas. |
| pipedrive-reconciliar | Administração, revisão, referência remota, prévia/prova e confirmação. Ações pessoa, lead e email_alternativo; esta última exige opt-in explícito. |
| pipedrive-atividade-reparar | Repara etapa opcional sem reenviar pessoa/lead/nota confirmados. |
| redirects-historico-ler/escrever | Consulta/retirada de um caminho histórico com administração + edição do conteúdo, revisão e simulação; sem exclusão genérica de metas. |

## Recuperação e limites

Prepare Core e Google independentemente. A guarda Core cobre seus próprios escritores, não todos os escritores do WordPress. Recriação/retomada pode suspender filas e invalidar cursores mesmo fora das tabelas selecionadas no restore; confira efeitos. Após reconciliação, retome Google antes do Core.

O item 134 é prevenido nesta versão. Recuperação da procedência perdida na frota é comprovável somente com snapshot/histórico suficiente. Formato e procedimento em PROCEDENCIA-1.22.md; não presumir histórico completo no MCP.

## Provas e ação solicitada ao MCP

Testes locais: bootstrap inerte em processos novos, documentação autorizada/anonimato recusado; concorrência entre processo WP-CLI real, cron PHP com DOING_CRON e chamada administrativa; uma ocorrência com efeito único; validação de candidato remoto simulada; permissões nativas de jornada e revisão dos novos serviços.

Não foi executada homologação desta release com um pacote MCP real nesta rodada. Os registros anteriores de MCP 0.15.0 não são aprovação da 1.22, e mocks não homologam MCP 0.16.0. Ao receber o Core, validar descoberta/paginação, política cumulativa de leitura, exposição dos schemas e tratamento de persisted/efeito/verificação. Nenhuma mudança obrigatória de código MCP foi identificada pelo contrato nativo; se houver lista manual de operações no consumidor, ela precisa acompanhar a descoberta autorizada.

Adendo 135, revisão 2: o token Clarity pode ser cadastrado diretamente no wp-admin, em Configurações → Medição e anúncios → Clarity. Oriente o dono até o campo; não peça a credencial pelo agente. Teste e primeira coleta usam o coletor existente e a cota compartilhada. Não cria ability, permissão nova ou alteração obrigatória no MCP.
