# Core 1.21.0 — instalação, operação e contratos

06/10/2026. Implementação do plano revisão 4. Este guia prevalece sobre instruções de instalação e comportamentos substituídos nos guias históricos. Use também PIPEDRIVE.md e dados/abilities-*.json.

## Instalar ou atualizar

Caminhos exclusivos: instalação nova ou base 1.20.0. A atualização tem checkpoints, trava, releitura e recuo em falha. Confira `f3base/saude-ler`, `f3base/como-usar` e `atualizacao.concluido_em`; não force marcadores via SQL. A versão nova usa `f3base_release_1210`. O histórico da base permanece, sem reexecutar migrações de versões anteriores. Não se oferece downgrade.

O instalador contém somente `base-site-core-fator3/`. Documentação, catálogos e lista pública de sufixos acompanham essa pasta. A suite e evidências de laboratório ficam no pacote fonte. Faça backup e use o fluxo de preparação/recuperação antes de restaurar dados de um site ativo.

## Configuração e UX

Medição e anúncios foi dividida em Tags e carregamento, Meta, Coleta do site, Search Console, Clarity e Testes. Cada formulário envia seu escopo. Configuração não alterada não recebe defaults, revisão nova ou efeitos de salvamento. O servidor usa contexto aleatório por usuário/janela, com validade de 30 minutos, referência de revisão e marcador de completude.

O adaptador HTML converte tipos recursivamente sem relaxar o contrato programático: inteiros válidos, booleanos, listas, multiseleções e JSON. Campo secreto vazio mantém; apagar é explícito. Segredos não integram rascunhos. A pré-validação considera o estado proposto para dependências alteradas juntas. Erros mostram código, caminho e orientação; rascunho não secreto é recuperado. Conflito, expiração ou POST truncado pedem recarga, sem interpretar ausência como exclusão. Falha posterior de persistência informa o resultado confirmado, sem prometer transação sobre efeitos externos. Sem JavaScript, as mesmas regras continuam no servidor.

A aba Informações técnicas lê o resumo interno do cache. Projeções `tokens.evidencia_ref` continuam válidas no canal público; a tela tolera itens malformados sem tratá-los como prova. Provas antigas não comprovam renovação pública atual. GET não executa sonda nem limpa cache; ações continuam protegidas por nonce e revisão.

## Testes e contato

Visite `/f3base-teste/` na mesma origem e navegador e confirme a marca. O cookie vence **31.536.000 segundos (365 dias)** após ativação. Navegação comum não renova nem cria a marca. `?sair=1` a remove. Cookies emitidos antes da atualização mantêm sua data antiga até reativação. O prazo não muda credenciais, concessões nem sessões do MCP/Google.

`X-F3Base-Teste: 1` e declaração explícita de evento continuam disponíveis. O registro conserva a proveniência observada (`cookie`, `cabecalho`, `evento`); histórico não ganha prova de cookie retroativa. Supressão/destinatários de teste valem para aviso normal e falhas CRM.

`f3base_leads.aparelho` é indexado por aparelho, data e ID: `celular`, `tablet`, `computador`, `nao_identificado`. A versão/fonte/motivo, sistema e navegador ficam em `dados.contexto.aparelho`. Classificação usa UA e Client Hint efetivamente recebido, sem largura de tela ou nova consulta. Pode acompanhar o contato mesmo sem sessão analítica; não infere consentimento. Conflitos, agentes e ausência ficam desconhecidos. Lead nativo não herda o aparelho do conector. Preenchimento histórico usa somente dados retidos, em lotes de 100.

E-mail, tela e nota usam uma apresentação comum. Respostas usam rótulos e alternativas da revisão capturada; zero e Não explícito aparecem. Rótulo histórico ausente é sinalizado. Campos técnicos de clique não viram respostas. IP/UA presentes entram na seção técnica autorizada, sem recuperar dados eliminados. Aviso é agendado para pelo menos dez segundos após a captura; cron e disponibilidade podem aumentar o prazo. O formulário não espera e-mail/CRM.

## Jornada e análise

A jornada junta apenas sessão e classe de tráfego iguais, dentro da retenção e até o horário do contato. Usa análise, comportamento e cliques; não identifica pessoas por IP. A página é agrupada por navegação + caminho; revisitas com navegações distintas permanecem. Eventos sem navegação não são fundidos por URL/segundo. IDs estáveis deduplicam eventos da mesma fonte; fontes sem identidade comum comprovável permanecem explicitadas, sem deduplicação por semelhança.

Tempo ativo é soma dos incrementos observados; intervalo entre eventos é apresentado como intervalo, não leitura. Última página sem prova de duração fica desconhecida. Sobreposição entre navegações indica múltiplas abas; duração da sessão é o intervalo observado, não soma dos tempos de abas. Marcos, cliques e seções são mostrados quando capturados. Consentimento é reavaliado no despacho/reenvio; revogação reduz jornada e atribuição. Origem nativa não recebe jornada web inventada.

Até 500 eventos e 100 cliques são lidos para a projeção, com indicação de corte. `f3base_eventos.recebido_em` registra a chegada no servidor; zero no histórico sem evidência. `criado_em` continua horário observado do evento. A análise já tinha os dois horários. Eventos ocorridos antes e recebidos depois do contato são identificados; posteriores à captura ficam fora. O corpo já enviado não muda; `entrega.aviso_resumo` guarda versão, instante de montagem e corte. As projeções consultam o acervo vigente e acompanham eliminação/retencão.

A ability `lead-jornada-ler` e a jornada em tela exigem **manage_options**. Ter somente `f3base_gerir_leads` não amplia esse acesso. O serviço interno permite composição autorizada pelo cron sem usuário autenticado.

## Tarefas e recuperação

O diário reivindica a ocorrência pelo índice único e confere quem a adquiriu. Concorrência retorna `ocorrencia_ocupada` ou `ocorrencia_ja_processada`, com referência à execução, sem usar Duplicate entry como fluxo normal. Falha de banco é distinta. `execucoes-ler` aceita `tarefa`, `origem`, `run_id` e paginação. Erros de tarefa registram classe, código/mensagem segura, arquivo relativo, linha, tarefa/origem/run_id; não registram stack com argumentos ou payload.

`cron_servidor_ativo` indica passagem CLI nas últimas duas horas. Não certifica crontab instalado nem sucesso de todas as tarefas. Leituras não renovam essa evidência. Retenção é alinhada às 01:00 e cadência às 06:00 no fuso do site; conserva-se periodicidade. Agenda se reconcilia ao mudar fuso. Verificação regular do cache usa minuto 10 antes do vencimento; urgência/recuo por mudança ou falha conservam prioridade.

Sentinela ausente, inválida, não gravável ou link suspeito bloqueia módulos e informa diagnóstico. Instalação já concluída não a recria silenciosamente. Saúde, documentação e recuperação autorizada permanecem acessíveis. Diretório inclui `index.php`.

Fluxo conjunto: preparar e drenar Google e Core; preservar os arquivos de guarda fora do banco; restaurar o escopo autorizado; reconciliar evidências; retomar Google e depois Core. Na perda da sentinela, leia `operacao-recuperacao-ler` e envie:

```json
{"acao":"recriar","precondicao_esperada":"<sha256 devolvido pela leitura>","reconciliacao_confirmada":true,"copia_outro_host":false}
```

`precondicao_esperada` exige 64 hex; `copia_outro_host` deve ser booleano explícito. `preparar`/`retomar` usam `geracao_esperada` positiva; retomada exige confirmação. Cópia para outro host renova a identidade da instalação e invalida prova externa. Mutação exige manage_options ou CLI autorizado. Travas e releitura protegem concorrência.

Após restauração, filas CAPI/CRM, eliminação externa, avisos pendentes e intenções restauradas ficam suspensos/incertos para reconciliação. Uma falha nessa etapa mantém a barreira pausada. Retomar não comprova envio nem autoriza repetição cega de resultados incertos.

## Search Console

O SDK permanece `search-console-reader/1.0.0`, com autoria de plugin e sem copiar credenciais Google. Diagnóstico opcional `effective_status` só é usado quando anunciado em `client_methods` e callable. Resoluções: resolved, not_granted, ambiguous, unreadable. Sem capacidade, usa o status corrente com escopo explicado; retorno inválido/exceção degrada diagnóstico. Consulta conserva suas verificações de concessão, política, revisão, cota e recuperação.

`f3base_gsc_lacunas` guarda universo/dia, pendência/resolução, motivo, primeira/última observação e coleta. `gsc-lacunas-ler` pagina até 100 linhas. Inventário ocorre na tarefa de coleta, em lotes de até 366 novos dias; leituras de status são locais. `dias_a_inventariar` não é lacuna já examinada. Dia consultado sem linhas resolve pendência sem fabricar zero visitas. Fotografias, recibos e histórico GSC continuam preservados.

Host/IDN são normalizados; a caixa do caminho no prefixo de URL é preservada. Propriedade de domínio que é somente sufixo público, como `com.br`, é recusada. A Public Suffix List vendorizada é de 2026-10-01, commit 6cd82aff889e3d64e5e03bc5c1f43da1934a960a, origem https://publicsuffix.org/list/public_suffix_list.dat, licença MPL-2.0 preservada no arquivo. Não há download dessa lista em visitas.

## Limites de entrega

Somente Core foi modificado. Contrato de política MCP continua 1; o conteúdo Core é 5.1.0. Novos encaminhamentos de MCP 0.16.0 revisão 5 e Google 0.7.1 revisão 3 orientaram o contrato, mas não equivalem a homologação desses pacotes. Leia os relatórios de impacto e VALIDACAO.md. Sete dias de observação na frota e homologação em contas reais são verificações posteriores.
