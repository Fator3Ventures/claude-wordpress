# Clarity — cadastro e teste no wp-admin (pedido 135)

Adendo da entrega 1.22.0, revisão 2, em 06/10/2026. Complementa CLARITY-1.19.md; este guia prevalece para configuração e teste. A versão do plugin permanece 1.22.0 e este pacote substitui o anterior desta entrega.

## Configurar sem passar o segredo pelo agente

1. Abra **Site Core → Configurações → Medição e anúncios → Clarity**.
2. Informe o ID público do projeto. No painel desse mesmo projeto Clarity, use **Settings → Data Export → Generate new API token**, como administrador do projeto.
3. Cole somente a credencial em **Token de exportação do Clarity** e clique em **Salvar alterações**. Projeto e token podem ser cadastrados juntos.
4. Confira **Token: definido** e **Vinculado ao projeto … neste site**. O campo fica vazio ao retornar: isso é esperado. Nunca mostra a credencial armazenada.
5. Clique em **Testar token e coletar agora**. O teste usa a configuração já salva, consulta uma janela de 24 horas por URL e preserva a resposta sanitizada no acervo. Não testa alterações ainda não salvas.
6. Abra **Ver coletas no relatório**, equivalente a `admin.php?page=f3base-medicao&area=clarity`. A consulta aparece com horário, qualidade e duração; abra-a para ver páginas e métricas. Uma resposta vazia continua sendo uma consulta preservada, sem inventar acessos.

O vínculo é uma associação local feita no cadastro. A API recebe o token e não aceita um parâmetro de projeto nem devolve sua identidade documentada. “Token aceito” comprova a resposta daquela credencial, não uma conferência independente de propriedade. O dono deve gerar a credencial no projeto informado. Não interpretar o conteúdo de um JWT sem validação como prova de identidade.

Trocar apenas o ID não reaproveita silenciosamente o token anterior: a coleta fica inativa, o vínculo anterior aparece na tela e é preciso cadastrar novamente a credencial correspondente. O histórico dos projetos anteriores permanece consultável. Alterações concorrentes de projeto/token recusam o teste aberto antes da mudança, sem consumir a cota. A chamada utiliza uma fotografia da credencial, evitando misturar credenciais de versões diferentes.

## Segredo e controles

Mantém o tratamento dos segredos Meta: cifra autenticada no banco, sem autoload; input de senha sempre vazio; vazio mantém o valor; remoção exige a caixa **Apagar o valor gravado**. A credencial não entra em rascunhos, URL de retorno, avisos ou diagnóstico. Cadastrar e testar exigem `manage_options` e proteção CSRF. Teste é POST explícito, respeita a guarda de recuperação e só faz GET ao endpoint fixo do Clarity, sem seguir redirects. Abrir configurações ou relatórios não faz chamadas externas.

O teste não cria nova ability: reutiliza o coletor da `f3base/clarity-consultar`, com a mesma trava por projeto, arquivo sanitizado, normalização e orçamento. Agentes devem orientar o dono até o formulário; não pedir que cole o token no chat. O vínculo e o último teste administrativo ficam em `f3base_clarity_estado`, somente com metadados: projeto, revisões, instante, ID da coleta, código/estado e HTTP; sem credencial/corpo de erro. Mudança de configuração torna a prova antiga histórica.

## Cota e resultados

Até dez tentativas locais por projeto/dia UTC: oito automáticas e duas manuais, compartilhadas com as rotas existentes. O botão usa uma tentativa manual. Reenvio do mesmo POST reaproveita a tentativa registrada; não repete HTTP. Uma falha repetida continua falha, nunca é exibida como token aceito. Ao atingir a cota, o botão fica indisponível e o servidor também recusa novas consultas.

Outros consumidores do mesmo projeto podem gastar a cota remota. Resposta 429 bloqueia novas tentativas pelo prazo já aplicado pelo coletor, respeitando Retry-After. Timeout, 401/403 e resposta inválida gastam a reserva conservadora da tentativa. A tela explica a causa e não expõe o corpo remoto. Falha local de persistência não vira confirmação de coleta.

A opção **Coletar diariamente quando houver token vinculado** continua independente do teste manual. Desligá-la é preservado ao cadastrar/testar. Ligada e configurada, agenda a coleta automática pelo executor WordPress; token salvo sozinho não comprova passagem do cron. Os horários visíveis usam o fuso do site; o contador operacional usa UTC. Janelas móveis se sobrepõem e não devem ser somadas como totais diários/mensais.

Documentação oficial conferida: https://learn.microsoft.com/en-us/clarity/setup-and-installation/clarity-data-export-api . Os limites remotos e o modo de obter o token vêm desse contrato; a divisão 8+2, o vínculo e o acervo são controles do Core.

## Aceite e limites da entrega

Teste local cobre o formulário renderizado, cadastro conjunto, cifra, segredo vazio, remoção, permissões/nonce, configuração obsoleta, trava, resposta preservada e visível, duplicação, falhas e teto conjunto de dez consultas. APIs simuladas, sem credencial real. O aceite no Site-Teste exige que o dono cadastre seu token, execute o teste e confira a coleta real; não foi feito acesso remoto nesta entrega. O limite técnico de resposta e os demais contratos do acervo permanecem em CLARITY-1.19.md.
