# Mapa da entrega — Core 1.21.0

Implementação do plano revisão 4 (06/10/2026), pedidos 107–128, correção do salvamento e cookie de um ano. Os aceites de produção são distintos da implementação e dos testes locais.

| Pedido | Implementação | Evidência/limite |
|---|---|---|
| Configuração/UX | Adaptador HTML tipado, delta por revisão/contexto, pré-validação e seis sub-abas | regressoes.json + ui.json; GTM isolado, sem alterações, JS ligado/desligado |
| Cookie | 365 dias, ativação explícita, saída, origem da marca | regressoes.json; cookie antigo só muda ao reativar |
| 107 | Diagnóstico de sentinela, recriar por precondição, locks e filas suspensas | operacao-jornada.json; restore entre plugins em produção não ensaiado |
| 108 a–c | Lista de mudanças 1.20/1.21, marca pública, PSL/IDN/caminho GSC | regressoes.json + catálogo/documentação; autoria robots preservada pela verificação de conteúdo |
| 108 d–g | Horários/fuso, evidência CLI, filtro tarefa, lacunas persistidas e resumo local | operacao-jornada, concorrencia, gsc-opcional e SDK real com rede simulada |
| 109–110 | Claim por ocorrência e erro de tarefa sanitizado | Três processos concorrentes; observação de sete dias na frota ainda posterior |
| 111/113/121 | Projeção comum em e-mail, wp-admin e nota, jornada aberta, dados técnicos recolhidos | apresentação-ui, avisos, crm e operacao-jornada; manage_options preservado |
| 112/122/123/124/126 | Título/host, site, parceiros padrão, etiqueta de nova pessoa, mapas de respostas e prévia | crm/crm-adicional; catálogo real requer homologação |
| 114/116 | Busca por identificadores, nome sem identificador, LinkedIn, enriquecimento de ausências e lead próprio | crm/crm-adicional; sem garantia de exclusão mútua entre sites |
| 115/125 | Alertas duráveis por transição e conta/dia, prontidão e pausas explícitas | crm-adicional; e-mail aceito em transporte simulado, sem comprovar caixa |
| 117 | Aparelho indexado, sinais/fonte/versão e preenchimento histórico | regressoes + upgrade; indeterminação preservada |
| 118 | Marca de teste com proveniência e apresentação coerente | regressoes + apresentação-ui; não atribui cookie a histórico sem prova |
| 119 | Confirma pessoa por ID, checkpoints e reparo seletivo de suspensão | crm: pesquisa vazia após criação, GET por ID disponível, sem repetir POST; divergência testada |
| 120 | Antecipação com remoção/releitura/trava; agenda/despacho separados | regressoes: evento a 196s antecipado; SLA remoto depende do executor |
| 127 | Sintaxe de token, trim, pre-validação e segredo preservado | regressoes; sintaxe não afirma autorização do provedor |
| 128 | Resumo interno na aba técnica e tolerância a tokens malformados | GET real das três abas, tokens de dois módulos e mobile; aceite remoto posterior |

## Não incorporado ou não ampliado

Webhook genérico permanece adiado pela decisão anterior. Tema, implantador, MCP e MCP Google não foram alterados. Jornada continua restrita a manage_options; não foi tomada a decisão pendente de ampliar a capability. Não foram alteradas regras de GA4/Meta, retenções gerais nem compatibilidade anterior à base 1.20.0. Não há downgrade ou publicação automática na frota.

Arquivos e schemas necessários aos agentes acompanham o instalador. A suite do fonte contém os testes executados; o relatório externo apresenta hashes finais dos pacotes.
