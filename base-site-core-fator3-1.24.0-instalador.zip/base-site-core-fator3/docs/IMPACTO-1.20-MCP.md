# Encaminhamento ao Fator3 MCP — convivência com Core 1.20.0

Referência conferida: **MCP 0.15.0**, pacote final fornecido. Seu código não foi alterado. Validação local com o plugin real confirmou provider, decoração das abilities, leitura, bloqueio de escrita no perfil read, autorização maintenance e permanência das capabilities WordPress.

Provider permanece `base-site-core-fator3`, namespace `f3base/`, `policy_contract:1`. A versão do plugin é `1.20.0`; o conteúdo do contrato Core passa a `5.0.0`, sem renomear `config-core-contrato-v1`. Não confundir a versão do contrato de dados com a adesão à política MCP.

Novas consultas: `f3base/execucoes-ler`, `f3base/gsc-status`, `f3base/gsc-historico`, `f3base/operacao-recuperacao-ler`. Novas ações: `f3base/gsc-coletar`, `f3base/operacao-recuperacao`. `f3base/executar-pendentes` passa a cobrir todo o registro fechado Core. Ações continuam exigindo permissão e perfil; cron interno e consumidor Google não fazem impersonação de administrador.

As respostas de saúde/como-usar/executor incluem `execucoes` com origens independentes e contagem móvel. `cron_servidor_ativo` significa CLI observado nas últimas duas horas; uma leitura MCP não sobrescreve esse relógio. O canal não deve promover esse sinal a comprovação de crontab instalado.

Durante recuperação, mutações Core ficam bloqueadas; a geração esperada é obrigatória para preparar/retomar. O MCP deve propagar códigos/estado e não contornar a barreira por SQL ou pelo canal genérico de options. A pasta `wp-content/f3-core-state/` deve ser preservada durante restauração, conforme o guia Core. O estado Core cobre somente seus escritores; não certifica drenagem de todo o WordPress.

Nenhuma mudança obrigatória no MCP 0.15.0 foi identificada. Recomenda-se orientar os agentes a consultar o novo guia instalado antes de operar cron, GSC ou recuperação.
