# Core 1.21.0 → Fator3 MCP Google

06/10/2026. Encaminhamento ao responsável pelo MCP Google; nenhum arquivo Google foi alterado. Referência recebida: Google 0.7.1, revisão 3. Contrato consumido permanece `search-console-reader/1.0.0`, consumidor `base-site-core-fator3`, versão 1.21.0, callback de propriedade/revisão/prontidão.

## Diagnóstico opcional implementado

Quando `capabilities.client_methods` anuncia `effective_status` e o cliente expõe o método, Core o usa sem rede. Aceita `resolution` em resolved/not_granted/ambiguous/unreadable; resolved exige `connection_id` não vazio. Projeta somente resolution, connection_id e local_status. Resolução não única tem connection_id nulo. Anúncio inconsistente, resposta malformada ou exceção degrada o diagnóstico, sem fatal e sem fabricar concessão.

Sem anúncio da extensão, Core usa `status()` e explica que ele cobre a conexão corrente. O diagnóstico não veta globalmente consultas cuja concessão pode ser resolvida em outra conexão. `query` conserva autorização por consumidor, propriedade, revisão, política, quota, recuperação e orçamento. Nenhuma credencial Google é copiada para Core.

## Lacunas, domínio e banco

`f3base_gsc_lacunas` persiste universo/dia, estado, motivo e referência à coleta. `gsc-lacunas-ler` pagina até 100 linhas; resumo em Saúde/como-usar é local. Inventário limitado a 366 novos dias por passagem evita varredura ilimitada; quantidade ainda não inventariada é explícita. Resposta concluída sem linhas resolve consulta sem inventar zero visitas; `all_rows_guaranteed:false` permanece.

Host/IDN são normalizados, caixa do caminho preservada e sufixo público isolado recusado. Não ampliar autorização Google a partir dessa normalização; comparar novamente contexto/revisão. Fotografias e recibos anteriores permanecem. Auditoria Google, despacho remoto, resposta recebida e commit Core são provas distintas. Cursor só avança com persistência confirmada. Não somar snapshots alternativos como tráfego adicional.

A coleta é um consumidor PHP independente da sessão humana e do canal MCP. `connection_examined:false` no diário de uma invocação CLI Google sem jobs não prova falha da consulta Core. CLI recente tampouco prova sucesso de todas as tarefas; leitura de status não renova passagem.

## Recuperação conjunta

Preparar/drenar Google e Core, preservar guardas externos ao banco, restaurar/reconciliar e retomar Google antes de Core. `operacao-recuperacao` Core inclui recriar com SHA de precondição, confirmação e declaração explícita de cópia de host. Geração antiga é recusada; perda de guarda não provoca liberação silenciosa. Core marca cursores reiniciar e mantém efeitos externos restaurados para reconciliação. Ler diagnóstico e documentação continua possível com módulos bloqueados.

O cookie de testes de 365 dias é só navegador; não muda validade de OAuth, concessão PHP, credencial ou sessão MCP. Não usar a marca para ampliar acesso Google.

## Validação e encaminhamento

Executado Core 1.21.0 com **Google 0.7.0 real** (SHA-256 do instalador `21ab98f5c235a44c4cb1599a92cc7e517d1762bc59e07493f5c1f329ac48eac2`) e MCP 0.15.0 real. APIs OAuth/Search Console foram simuladas, com credenciais sintéticas e rede externa bloqueada. Doze verificações passaram: registro antecipado, concessão, coleta com usuário zero, orçamento, resolução de concessão em conexão alternativa, snapshot da conexão efetiva e versão do provider. A coleta persistiu métricas simuladas no Core; não se alega conta Google real.

Nove verificações adicionais passaram com cliente de contrato simulado para a extensão: quatro resoluções, retorno inválido, exceção, fallback sem extensão, lacuna persistida e resolução sem linhas. Isso **não homologa Google 0.7.1**, recebido apenas como plano/encaminhamento. Repetir esse conjunto com o pacote final, incluindo diagnóstico sem rede, revogação durante query, falha de auditoria e restore de tabela. Não foi identificada necessidade de alterar Google 0.7.0 para manter o caminho existente.

Schemas e banco completos: docs/RELEASE-1.21.md, docs/dados/abilities-*.json e docs/dados/contrato.json instalados no Core. Este relatório foi preparado para encaminhamento pelo dono, sem envio automático.
