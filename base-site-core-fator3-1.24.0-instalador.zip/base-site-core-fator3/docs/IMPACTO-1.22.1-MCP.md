# Impacto do Site Core 1.22.1 — MCP

Nenhuma alteração obrigatória no plugin MCP. O Core mantém seus controles administrativos de capacidades e revisão. A validação interna de credencial pode rodar sem sessão WordPress, mas rotas e abilities continuam autenticadas. Não encaminhar segredos por chat: usar o wp-admin.

Consumidores devem aceitar o novo estado `f3base_release_1221`, a continuação em lotes e os códigos específicos de recuperação descritos em RELEASE-1.22.1.md. `f3base/redirects-historico-escrever` passa a aceitar `acao: restaurar`. Reconciliação de CRM está também na UI; o contrato da ability permanece. Leitura de documentação continua disponível no bootstrap de recuperação. Não se autoriza bypass das políticas do canal nem SQL nos outros plugins.
