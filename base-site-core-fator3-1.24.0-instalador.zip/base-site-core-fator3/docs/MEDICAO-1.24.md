# Medição de audiência e conteúdo — 1.24.0

## Fontes e significado

| Sinal | Fonte | Interpretação permitida |
|---|---|---|
| página vista | `f3base_analise` | carregamento público elegível observado |
| saída | `f3base_eventos` | última marca cumulativa por navegação |
| tempo visível | navegador | tempo com documento visível; não equivale ao GA4 |
| tempo ativo | navegador | estimativa limitada por atividade e seção predominante |
| robôs/IA | log agregado | requisição HTTP; não prova leitura, citação ou recomendação |
| referência de IA | acervo conferido | evidência registrada; fica separada de requisição e visita indicada |
| 404 | `f3base_audiencia_404` | pedido público não encontrado, fora da audiência |

## Dimensões fixadas na sessão

`largura_faixa`: `ate_359`, `360_479`, `480_767`, `768_1023`, `1024_1439`, `1440_mais`.

`navegador`: `instagram`, `facebook`, `linkedin`, `chrome`, `safari`, `outro`.

`sistema`: `Android`, `iOS`, `Windows`, `macOS`, `Linux`, `outro`.

`retorno`: `novo`, `recorrente`. O navegador decide antes de enviar e separa o histórico de testes.

`aparelho`: `celular`, `tablet`, `computador`, `nao_identificado`. Android WebView/Instagram com `Mobile` é celular; dado de conector nativo não herda o user agent do conector.

As cinco dimensões usam a primeira observação retida da sessão. Histórico anterior fica indisponível; o Core não inventa valores. Não há geolocalização.

## Eventos 1.24

- `saida`: no máximo seis por navegação, deduplicada entre `visibilitychange` e `pagehide`; `ms` é duração decorrida, `valor` é tempo visível e `detalhe` é profundidade percentual.
- `rolagem-salto`: deslocamento programático ou múltiplos marcos sem gesto compatível, separado de `rolagem`.
- `clique-interno`: origem 1 para `f3base-clique-<nome>`, 2 para âncora e 3 para botão/link interno genérico. WhatsApp, submissão e consentimento ficam fora.
- `clique-inerte`: clique sem efeito em elemento não interativo; seleção, `preventDefault`, saída imediata e controles acessíveis ficam fora.

Seção conta como vista quando metade de sua área ou metade da janela está sobre ela. Resize reconstrói a geometria preservando o que já foi observado. A seção predominante elegível recebe tempo ativo.

## Exclusões

Resposta 404, `wp-admin` e usuário autenticado com `edit_posts`, `edit_pages` ou `manage_options` não carregam tracking, GA4, Pixel Meta, LinkedIn ou Clarity geridos pelo Core. As rotas da API também recusam evento de editor e caminhos técnicos. Plugins ou tags externos ao Core precisam aplicar a própria exclusão.
