> Documento da entrega 1.19, preservado para referência. Para atualizar e para operação/GSC na 1.20, leia OPERACAO-GSC-1.20.md.

# Exemplos para agentes — Core 1.19.0

Exemplos são entradas de abilities, não comandos SQL de escrita. Primeiro descubra o schema instalado, autenticação/capability, política e revisão. Marque navegação por cookie `/f3base-teste/` e sondas HTTP locais por `X-F3Base-Teste: 1`. Implantador e tema são externos ao Core.

## Piso integral sem alterar configurações

Ability `f3base/config-core-perfil-avaliar`:

```json
{"perfil_id":"piso-padrao-3.2","perfil_revisao":"2026-10-01-core-1.19.0","somente_divergencias":true,"contexto":{"rotas_privadas":[],"regime_whatsapp":false}}
```

O arquivo `perfis/piso-padrao-3.2.json` contém metadados e objeto `perfil`. Para consulta por objeto, envie esse objeto interno, não o envelope documental completo. ID e objeto produzem a mesma avaliação. `completo:true` descreve a cobertura do documento distribuído; não significa que o site esteja conforme.

O piso exige presença explícita de configurações/subcampos aplicáveis, exceto consentimento e estados, conforme fonte recebida. Vazio/falso/zero presentes são diferentes de ausência. Segredo só comprova metadados de presença, nunca seu valor. Campos condicionais de arquivo e WhatsApp são avaliados conforme aplicação; rotas privadas do site precisam ser informadas para avaliar contenção integral.

Estados: conforme, divergente, excecao_valida e indeterminado. Exceções têm condição, responsável, motivo, expiração UTC, ID/revisão do perfil e referência concreta ao estado aprovado. Ausência de prova HTTP permanece indeterminada e não é corrigida pela consulta.

## Simular uma alteração independente

Leia `f3base/config-core-ler` com `{"nome":"f3base_seo_entidade"}`. Use a revisão retornada:

```json
{"nome":"f3base_seo_entidade","valor":{"nome":"Nome público atualizado"},"mesclar":true,"simular":true,"revisao_esperada":"REVISAO_LIDA"}
```

Confira `ok`, `simulado`, `persisted:false`, `changed:false`, `alteraria`, erros/avisos e `campos_removidos`. Para aplicar, mantenha o mesmo valor e revisão conferidos e use `simular:false`. Em conflito, releia e compare. Um campo antigo inválido independente não pode bloquear o nome; país/CNPJ e demais dependências continuam validados juntos. Não use SQL para contornar recusas.

## Consultar verificação curta e detalhe

Ability `f3base/config-core-verificar`:

```json
{"nome":"f3base_contato","acao":"consultar","compacto":true}
```

Para recuperar prova conservada, use o ID real retornado:

```json
{"nome":"f3base_contato","acao":"consultar","evidencia_id":"SHA256_RETORNADO"}
```

O segundo exemplo exige um SHA-256 hexadecimal de 64 caracteres, não o texto placeholder. Não dispara sonda. `evidencia_expirada` conserva o corpo antigo com `expirada:true`; ausência retorna código próprio. `verification` da opção e `verificacao_publica` da sonda são escopos distintos. A projeção de tokens usa `evidencias_tokens[id]`; resolva `tokens.evidencia_ref` nessa mesma resposta.

Sondar ou invalidar cache exige ação própria, revisão atual e `contexto_teste:true` quando declarado. `ok:true` nunca substitui `persisted`/`verified`. Compare `efeito_cache` e motivos, não só bytes da resposta.

## Cadência

Leia `f3base/saude-ler` e o grupo `cadencia`, ou F3 Base → Operação. A consulta retorna o último demonstrativo local: estado dos módulos, releitura das options e censo, horário/duração/erros, gatilhos e próxima execução. Não envia mensagens, não corrige opções e não mantém histórico completo. Ler o resultado não é executar a cadência.

## Publicidade e contatos

Conserve IDs de conta/campanha/grupo/anúncio como strings e não infira plataforma pelo fbclid. Use modelos em CRUZAMENTOS-PUBLICIDADE.md e a política de consentimento em CONTRACTS.md. Clique/formulário alimentam CAPI a partir do registro persistido e congelam contexto de teste, horário e correlação. Verifique fila/destino antes de habilitar integração. Não reenvie registros históricos para inventar atribuição ausente.

Para medição e novos contratos, comece por MEDICAO-1.19.md, ANALISAR-CONTEUDO-ORGANICO.md e ANALISAR-PRESENCA-IA.md.


## Conferir a atualização e operar as exclusões

Leia `f3base/medicao-saude-ler`, a cobertura em `agentes-relatorio` e a reparação em `medicao-editorial.cobertura.catalogo`. Se houver lotes pendentes, execute `f3base/executar-pendentes` e consulte novamente. Não edite tabelas de vigência para atribuir IDs retroativos.

Uma anotação conhecida pode ser criada por `medicao-anotacao-gravar` com `chave`, `de`, `ate`, `motivo` e `excluir:true`. Para alterar, use a revisão lida. Para excluir, use `medicao-anotacao-excluir` com `id` e `revisao`. Confira o mesmo período com `anotacoes:true` e `false`; nenhuma chamada apaga eventos ou leads. A interface em Sessões permite os mesmos passos sem digitar revisão manualmente.

`acessos-legado-ler` oferece evidência arquivada de reconciliações. Nunca some seu resultado ao de `agentes-relatorio`. Perdas de fontes, proveniência e calendário devem acompanhar relatórios externos feitos pelo agente.


## Novas operações

Consulte dados/abilities-*.json para schemas gerados. Exemplos de leitura: `agentes-ler` com caminho `/`, grupo `todos`, incluir_tecnico true; `relatorios-integrados-ler` com visao `resumo`, canal `busca_organica`, automacao `audiencia`; `clarity-ler` com modo `consultas`; `clarity-comparar` com IDs anterior/atual. Cadastro de arquivo usa SHA-256 e chave idempotente; substituição exige expected_sha256. Nenhum desses exemplos autoriza contornar perfil ou fornecer credenciais em documentação.
