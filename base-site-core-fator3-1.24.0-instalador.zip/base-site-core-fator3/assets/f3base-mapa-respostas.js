(function () {
  'use strict';
  document.querySelectorAll('[data-f3base-mapa-respostas]').forEach(function (root) {
    var catalog = JSON.parse(root.querySelector('[data-catalog]').textContent);
    var form = root.querySelector('[data-form]'), source = root.querySelector('[data-source]'), target = root.querySelector('[data-target]');
    var conversion = root.querySelector('[data-conversion]'), alternatives = root.querySelector('[data-alternatives]');
    var text = document.getElementById('f3base-integ-mapa_respostas'), status = root.querySelector('[data-status]');
    function option(select, value, label) { var o = document.createElement('option'); o.value = value; o.textContent = label; select.append(o); }
    function read() { var map = JSON.parse(text.value); if (!map || Array.isArray(map)) throw new Error('Confira o JSON do mapa antes de usar os seletores.'); return map; }
    function currentForm() { return catalog.forms.find(function (f) { return f.id === form.value; }); }
    function currentField() { return catalog.fields.find(function (f) { return (f.field_code || f.key) === target.value; }); }
    function control(label, node, parent) { var l = document.createElement('label'), p = document.createElement('p'); l.append(document.createTextNode(label + ' '), node); p.append(l); parent.append(p); }
    function details() {
      alternatives.replaceChildren(); conversion.replaceChildren(); var field = currentField(); if (!field) return;
      var existing; try { existing = (read()[form.value] || {})[source.value] || {}; } catch(e) { status.textContent = e.message; return; }
      var type = field.field_type;
      if (['double', 'monetary', 'date'].includes(type)) {
        var format = document.createElement('select'); format.dataset.format = '1';
        (type === 'date' ? [['Y-m-d','Ano-mês-dia'],['d/m/Y','Dia/mês/ano']] : [['decimal_ponto','Ponto decimal, sem milhar'],['decimal_virgula','Vírgula decimal, sem milhar']]).forEach(function (v) { option(format,v[0],v[1]); });
        if (existing.formato) format.value = existing.formato; control('Formato da resposta',format,conversion);
        if (type === 'monetary') { var currency = document.createElement('input'); currency.maxLength = 3; currency.dataset.currency = '1'; currency.value = existing.moeda || ''; currency.placeholder = 'BRL'; control('Moeda ISO',currency,conversion); }
      }
      if (['enum','set'].includes(type)) {
        var f = currentForm(); var src = f && f.campos.find(function (x) { return x.nome === source.value; }); var opts = src && src.opcoes || [];
        if (!Array.isArray(opts)) opts = Object.keys(opts).map(function (k) { return {valor:k,rotulo:opts[k]}; });
        opts.forEach(function (x) { var value = typeof x === 'string' ? x : x.valor || x.value; var select = document.createElement('select'); select.dataset.alternative = value; option(select,'','Manter somente na nota'); (field.options || []).forEach(function (o) { option(select,String(o.id),o.label || o.name || String(o.id)); }); select.value = String((existing.alternativas || {})[value] || ''); control(typeof x === 'string' ? x : x.rotulo || value,select,alternatives); });
        if (!opts.length) { var p = document.createElement('p'); p.textContent = 'Origem sem alternativas declaradas. Use o JSON para mapear valores textuais exatos.'; alternatives.append(p); }
      }
    }
    function loadSource() { var map; try { map = (read()[form.value] || {})[source.value] || {}; } catch(e) { status.textContent=e.message; return; } target.value = map.campo || ''; details(); }
    function loadForm() { source.replaceChildren(); (currentForm() && currentForm().campos || []).forEach(function (f) { option(source,f.nome,(f.rotulo || f.nome) + ' (' + f.tipo + ')'); }); loadSource(); }
    option(form,'','Selecione um formulário'); catalog.forms.forEach(function (f) { option(form,f.id,f.titulo); });
    option(target,'','Somente na nota'); catalog.fields.forEach(function (f) { option(target,f.field_code || f.key,(f.name || f.field_code || f.key) + ' (' + f.field_type + ')'); });
    form.addEventListener('change',loadForm); source.addEventListener('change',loadSource); target.addEventListener('change',details);
    function change(remove) {
      try { if (!form.value || !source.value) throw new Error('Selecione formulário e resposta.'); var map = read(); map[form.value] = map[form.value] || {};
        if (remove || !target.value) delete map[form.value][source.value];
        else { var item = {campo:target.value}; var previous = map[form.value][source.value]; var type = currentField().field_type;
          if (['enum','set'].includes(type)) { item.alternativas = previous && previous.campo === target.value ? previous.alternativas || {} : {}; alternatives.querySelectorAll('[data-alternative]').forEach(function (select) { if (select.value) item.alternativas[select.dataset.alternative] = select.value; else delete item.alternativas[select.dataset.alternative]; }); }
          var f = conversion.querySelector('[data-format]'), c = conversion.querySelector('[data-currency]'); if (f) item.formato = f.value; if (c) { item.moeda = c.value.trim().toUpperCase(); if (!/^[A-Z]{3}$/.test(item.moeda)) throw new Error('Informe a moeda ISO.'); }
          map[form.value][source.value] = item;
        }
        if (!Object.keys(map[form.value]).length) delete map[form.value]; text.value = JSON.stringify(map,null,2); status.textContent = 'Mapa atualizado nesta página. Salve a integração para gravar.';
      } catch(e) { status.textContent = e.message; }
    }
    root.querySelector('[data-apply]').addEventListener('click',function () { change(false); }); root.querySelector('[data-remove]').addEventListener('click',function () { change(true); });
  });
}());
