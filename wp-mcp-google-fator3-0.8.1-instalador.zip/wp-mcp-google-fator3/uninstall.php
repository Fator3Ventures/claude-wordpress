<?php
/**
 * Keep public configuration/history unless purge was explicitly selected. Secrets never survive.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
require_once __DIR__ . '/includes/Cache.php';
require_once __DIR__ . '/includes/Uninstall.php';
if ( is_multisite() ) {
	$f3_mcp_google_offset = 0;
	do {
		$f3_mcp_google_sites = get_sites(
			array(
				'fields' => 'ids',
				'number' => 100,
				'offset' => $f3_mcp_google_offset,
			)
		);
		foreach ( $f3_mcp_google_sites as $f3_mcp_google_site ) {
			switch_to_blog( (int) $f3_mcp_google_site );
			try {
				\Fator3\McpGoogle\Uninstall::site();
			} finally {
				restore_current_blog();
			}
		}
		$f3_mcp_google_offset    += count( $f3_mcp_google_sites );
		$f3_mcp_google_page_count = count( $f3_mcp_google_sites );
	} while ( 100 === $f3_mcp_google_page_count );
	\Fator3\McpGoogle\Uninstall::network();
} else {
	\Fator3\McpGoogle\Uninstall::site();
}
