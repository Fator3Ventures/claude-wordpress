<?php
/**
 * Bounded local counters and observations; no request bodies or credentials.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Telemetry {

	public static function add( string $counter, int $amount = 1 ): void {
		self::record( array( $counter => max( 0, $amount ) ) );
	}
	private static function record( array $increments, ?string $service = null, float $duration = 0, bool $completed = false ): void {
		$hour = (int) ( floor( time() / 3600 ) * 3600 );
		$id   = Connections::id() . '_' . $hour;
		$lock = Lock::acquire( 'telemetry:' . $id, 10 );
		if ( null === $lock ) {
			self::incomplete();
			return;
		}
		try {
			$row = Records::get( 'telemetry', $id ) ?? array(
				'connection_id' => Connections::id(),
				'created_at'    => $hour,
				'expires_at'    => $hour + 25 * 3600,
				'counters'      => array(),
				'apis'          => array(),
			);
			foreach ( $increments as $counter => $amount ) {
				if ( in_array( $counter, array( 'http_attempts', 'token_requests', 'discovery_requests', 'api_requests', 'read_attempts', 'write_attempts', 'http_errors', 'cache_hits' ), true ) ) {
					$row['counters'][ $counter ] = ( $row['counters'][ $counter ] ?? 0 ) + $amount;
				}
			}
			if ( null !== $service ) {
				$api                     = $row['apis'][ $service ] ?? array(
					'attempts'    => 0,
					'completed'   => 0,
					'duration_ms' => 0,
					'errors'      => 0,
				);
				$api['attempts']        += $increments['http_attempts'] ?? 0;
				$api['completed']        = ( $api['completed'] ?? 0 ) + ( $completed ? 1 : 0 );
				$api['duration_ms']     += (int) round( max( 0, $duration ) * 1000 );
				$api['errors']          += $increments['http_errors'] ?? 0;
				$row['apis'][ $service ] = $api;
			}
			if ( ! Records::put( 'telemetry', $id, $row )['success'] ) {
				self::incomplete();
			}
		} catch ( \Throwable $e ) {
			self::incomplete();
		} finally {
			Lock::release( $lock );
		}
	}
	private static function incomplete(): void {
		\Fator3\McpGoogle\Cache::set( 'f3_mcp_google_telemetry_incomplete_' . Connections::id(), time(), 86400 );
		Options::set( 'f3_mcp_google_telemetry_incomplete_' . Connections::id(), time() );
	}
	/** Preserve only counters reported by Google; never infer a global quota limit. */
	public static function quota( string $url, array $response ): void {
		if ( ! str_contains( $url, 'analyticsdata.googleapis.com' ) || ! preg_match( '~/properties/(\d+)~', $url, $match ) ) {
			return;
		}
		$groups    = array(
			'tokensPerDay'                          => array( 'tokens', 'day' ),
			'tokensPerHour'                         => array( 'tokens', 'hour' ),
			'tokensPerProjectPerHour'               => array( 'tokens', 'project_hour' ),
			'concurrentRequests'                    => array( 'requests', 'concurrent' ),
			'serverErrorsPerProjectPerHour'         => array( 'server_errors', 'project_hour' ),
			'potentiallyThresholdedRequestsPerHour' => array( 'requests', 'hour' ),
		);
		$responses = isset( $response['propertyQuota'] ) ? array( $response ) : ( $response['reports'] ?? array() );
		foreach ( $responses as $index => $item ) {
			$observations = array();
			foreach ( $item['propertyQuota'] ?? array() as $name => $values ) {
				if ( ! isset( $groups[ $name ] ) || ! is_array( $values ) ) {
					continue;
				}
				$consumed  = $values['consumed'] ?? null;
				$remaining = $values['remaining'] ?? null;
				if ( ( null !== $consumed && ( ! is_int( $consumed ) || $consumed < 0 ) ) || ( null !== $remaining && ( ! is_int( $remaining ) || $remaining < 0 ) ) ) {
					continue;
				}
				$observations[ $name ] = array(
					'unit'                    => $groups[ $name ][0],
					'window'                  => $groups[ $name ][1],
					'consumed_by_request'     => $consumed,
					'remaining_after_request' => $remaining,
					'limit'                   => null,
					'reset_at'                => null,
				);
			}
			if ( ! $observations ) {
				continue;
			}
			$property = 'properties/' . $match[1];
			$identity = Auth\Credentials::execution_identity();
			$id       = hash( 'sha256', Connections::id() . '|' . $identity . '|' . $property );
			try {
				$saved = Records::put(
					'quota',
					$id,
					array(
						'connection_id'        => Connections::id(),
						'identity'             => $identity,
						'property_id'          => $property,
						'source'               => 'google_analytics_data_propertyQuota',
						'source_documentation' => 'https://developers.google.com/analytics/devguides/reporting/data/v1/rest/v1beta/PropertyQuota',
						'observed_at'          => time(),
						'expires_at'           => time() + 86400,
						'observations'         => $observations,
						'response_index'       => $index,
					)
				);
				if ( ! $saved['success'] ) {
					self::incomplete();
				}
			} catch ( \Throwable $error ) {
				self::incomplete();
			}
		}
	}
	public static function quotas(): array {
		try {
			if ( Storage\Migration::active() ) {
				$rows = Storage\Repository::select( 'quota', array( 'connection_id' => Connections::id() ), 51 );
				if ( is_wp_error( $rows ) ) {
					return array(
						'available'  => false,
						'error_code' => $rows->get_error_code(),
					);
				}
				$ids = array_column( $rows, 'record_id' );
			} else {
				$ids = Records::ids( 'quota', 1000 );
			}
			$out      = array();
			$identity = Auth\Credentials::execution_identity();
			foreach ( $ids as $id ) {
				$row = Records::get( 'quota', $id );
				if ( null === $row || ( $row['connection_id'] ?? '' ) !== Connections::id() || ( $row['identity'] ?? '' ) !== $identity || ! Policy::permitted( 'ga', $row['property_id'] ) ) {
					continue;
				}
				unset( $row['identity'] );
				$row['stale'] = $row['observed_at'] < time() - 60;
				$out[]        = $row;
				if ( count( $out ) > 50 ) {
					break;
				}
			}
			return array(
				'available'                 => true,
				'observations'              => array_slice( $out, 0, 50 ),
				'truncated'                 => count( $out ) > 50,
				'scope'                     => 'reported_property_quotas_only',
				'global_google_quota_known' => false,
			);
		} catch ( \Throwable $error ) {
			return array(
				'available'  => false,
				'error_code' => 'f3_google_quota_observation_read',
			);
		}
	}
	public static function started( string $url, array $opts ): void {
		$category = str_contains( $url, 'oauth2.googleapis.com' ) ? 'token_requests' : ( str_contains( $url, 'discovery' ) ? 'discovery_requests' : 'api_requests' );
		$counts   = array(
			'http_attempts' => 1,
			$category       => 1,
		);
		if ( 'api_requests' === $category ) {
			$counter            = 'write' === ( $opts['mode'] ?? 'read' ) ? 'write_attempts' : 'read_attempts';
			$counts[ $counter ] = 1;
		}
		self::record( $counts, Http\GoogleClient::service_for( $url ) );
	}
	public static function finished( string $url, $response, float $duration = 0 ): void {
		$counts = array();
		if ( is_wp_error( $response ) || (int) wp_remote_retrieve_response_code( $response ) >= 400 ) {
			$counts['http_errors'] = 1;
		}
		self::record( $counts, Http\GoogleClient::service_for( $url ), $duration, true );
	}
	public static function state(): array {
		$end  = (int) ( floor( time() / 3600 ) * 3600 );
		$sum  = array();
		$apis = array();
		try {
			for ( $i = 0;$i < 24;++$i ) {
				$row = Records::get( 'telemetry', Connections::id() . '_' . ( $end - $i * 3600 ) );
				foreach ( $row['counters'] ?? array() as $key => $value ) {
					$sum[ $key ] = ( $sum[ $key ] ?? 0 ) + $value;
				}
				foreach ( $row['apis'] ?? array() as $api => $metrics ) {
					foreach ( $metrics as $key => $value ) {
						$apis[ $api ][ $key ] = ( $apis[ $api ][ $key ] ?? 0 ) + $value;
					}
				}
			}
		} catch ( \Throwable $e ) {
			return array(
				'available'  => false,
				'error_code' => 'f3_google_telemetry_read',
			);
		}
		$incomplete = \Fator3\McpGoogle\Cache::get( 'f3_mcp_google_telemetry_incomplete_' . Connections::id() );
		return array(
			'available'        => true,
			'window_start'     => $end - 23 * 3600,
			'window_end'       => time(),
			'bucket_seconds'   => 3600,
			'counters'         => $sum,
			'apis'             => $apis,
			'approximate'      => true,
			'incomplete_since' => $incomplete ? $incomplete : get_option( 'f3_mcp_google_telemetry_incomplete_' . Connections::id(), null ),
			'source'           => 'local_observations',
		);
	}
}
