<?php
/**
 * Optional administrator-selected distribution origin with verified package bytes.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Updater {
	public const OPTION    = 'f3_mcp_google_update_origin';
	public const MAX_HOSTS = 5;
	private const PLUGIN   = 'wp-mcp-google-fator3/wp-mcp-google-fator3.php';
	public static function schema(): array {
		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'enabled'       => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'manifest_url'  => array(
					'type'        => 'string',
					'description' => 'URL HTTPS obrigatória quando enabled=true.',
				),
				'allowed_hosts' => array(
					'type'        => 'array',
					'maxItems'    => self::MAX_HOSTS,
					'items'       => array(
						'type'    => 'string',
						'pattern' => '^[a-z0-9.-]+$',
					),
					'description' => 'Hosts exatos do manifesto, pacote e redirecionamentos.',
				),
			),
		);
	}
	public static function init(): void {
		add_filter( 'pre_set_site_transient_update_plugins', array( self::class, 'updates' ) );
		add_filter( 'upgrader_pre_download', array( self::class, 'download' ), 10, 4 );
		add_action( 'plugins_loaded', array( self::class, 'coordinate_channel' ), 30 );
	}
	/** One selected owner for this package, preserving the channel for all other packages. */
	public static function channel_selected(): bool {
		$channels = get_option( 'f3_mcp_update_channels', array() );
		return class_exists( '\\Fator3\\McpFiles\\UpdateChannel' ) && is_array( $channels ) && ! empty( $channels['wp-mcp-google-fator3']['url'] );
	}
	public static function coordinate_channel(): void {
		$callback = array( \Fator3\McpFiles\UpdateChannel::class, 'download' );
		if ( ! class_exists( $callback[0] ) ) {
			return;
		}
		remove_filter( 'upgrader_pre_download', $callback, 20 );
		add_filter(
			'upgrader_pre_download',
			static function ( $reply, $package, $upgrader, $extra ) use ( $callback ) {
				if ( ( $extra['plugin'] ?? '' ) === self::PLUGIN && ( ! self::channel_selected() || is_file( $package ) ) ) {
					return $reply;
				}
				return $callback( $reply, $package, $upgrader, $extra );
			},
			20,
			4
		);
	}
	public static function configure( array $input ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return Response::fail( new \WP_Error( 'f3_google_update_forbidden', 'Configurar distribuição exige manage_options.' ) );
		}
		$origin = $input['origin'] ?? array();
		if ( ! is_array( $origin ) || array_diff( array_keys( $origin ), array( 'manifest_url', 'allowed_hosts', 'enabled' ) ) || ! is_bool( $origin['enabled'] ?? false ) ) {
			return Response::fail( new \WP_Error( 'f3_google_update_origin', 'Origem inválida.' ) );
		}
		if ( ! empty( $origin['enabled'] ) ) {
			$url   = $origin['manifest_url'] ?? '';
			$hosts = $origin['allowed_hosts'] ?? array();
			if ( ! is_string( $url ) || ! is_array( $hosts ) || ! $hosts || count( $hosts ) > self::MAX_HOSTS || 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! in_array( wp_parse_url( $url, PHP_URL_HOST ), $hosts, true ) ) {
				return Response::fail( new \WP_Error( 'f3_google_update_origin', 'Informe manifesto HTTPS e até cinco hosts de distribuição explicitamente confiáveis.' ) );
			}
			foreach ( $hosts as $host ) {
				if ( ! is_string( $host ) || ! preg_match( '/^[a-z0-9.-]+$/D', $host ) ) {
					return Response::fail( new \WP_Error( 'f3_google_update_origin', 'Host inválido.' ) );
				}
			}
		}
		$saved = Settings::save( array( self::OPTION => $origin ), array(), array(), $input['expected_revision'] ?? null );
		if ( $saved['success'] ) {
			\Fator3\McpGoogle\Cache::delete( 'f3_mcp_google_update_manifest' );
		}
		return $saved;
	}
	public static function check( bool $refresh = false ): array {
		if ( self::channel_selected() ) {
			$manifest = \Fator3\McpFiles\UpdateChannel::manifest( 'wp-mcp-google-fator3' );
			if ( is_wp_error( $manifest ) ) {
				return Response::fail(
					$manifest,
					array(
						'owner' => 'channel',
						'state' => 'check_failed',
					)
				);
			}
			$compatible = false !== \Fator3\McpFiles\UpdateChannel::offer( false, array(), self::PLUGIN, array() );
			return Response::ok(
				array(
					'owner'            => 'channel',
					'state'            => $compatible ? 'checked' : 'incompatible',
					'manifest'         => $manifest,
					'update_available' => $compatible && version_compare( $manifest['version'], F3_MCP_GOOGLE_VERSION, '>' ),
					'checked_at'       => gmdate( 'c' ),
				)
			);
		}
		$origin = Options::get( self::OPTION, array() );
		if ( empty( $origin['enabled'] ) ) {
			return Response::ok(
				array(
					'state'            => 'not_configured',
					'update_available' => false,
				)
			);
		}
		$key         = 'f3_mcp_google_update_manifest';
		$cached      = \Fator3\McpGoogle\Cache::get( $key );
		$origin_hash = hash( 'sha256', wp_json_encode( $origin ) );
		if ( ! $refresh && is_array( $cached ) && ( $cached['origin_hash'] ?? '' ) === $origin_hash ) {
			return $cached['result'];
		}
		$response = Http\PublicPage::fetch( $origin['manifest_url'], $origin['allowed_hosts'], 5, 262144, array( 'https' ) );
		if ( empty( $response['success'] ) || ! empty( $response['truncated'] ) || 200 !== ( $response['http_status'] ?? 0 ) ) {
			return Response::fail(
				new \WP_Error( 'f3_google_update_manifest_fetch', 'Falha ao consultar a origem de distribuição.' ),
				array(
					'state'     => 'check_failed',
					'transport' => $response['error_code'] ?? null,
				)
			);
		}
		$manifest = json_decode( $response['body'] ?? '', true );
		$issue    = self::validate( $manifest, $origin );
		if ( null !== $issue ) {
			return Response::fail( $issue, array( 'state' => 'invalid_manifest' ) );
		}
		$compatible = version_compare( PHP_VERSION, $manifest['requires_php'], '>=' ) && version_compare( get_bloginfo( 'version' ), $manifest['requires_wordpress'], '>=' );
		$result     = Response::ok(
			array(
				'state'            => $compatible ? 'checked' : 'incompatible',
				'manifest'         => $manifest,
				'update_available' => $compatible && version_compare( $manifest['version'], F3_MCP_GOOGLE_VERSION, '>' ),
				'checked_at'       => gmdate( 'c' ),
			)
		);
		\Fator3\McpGoogle\Cache::set(
			$key,
			array(
				'origin_hash' => $origin_hash,
				'result'      => $result,
			),
			3600
		);
		return $result;
	}
	public static function validate( $manifest, array $origin ): ?\WP_Error {
		if ( ! is_array( $manifest ) || ( $manifest['schema_version'] ?? '' ) !== '1.0.0' || ( $manifest['plugin'] ?? '' ) !== 'wp-mcp-google-fator3' || ! preg_match( '/^\d+\.\d+\.\d+$/D', (string) ( $manifest['version'] ?? '' ) ) || ! preg_match( '/^[a-f0-9]{64}$/D', (string) ( $manifest['sha256'] ?? '' ) ) || ! preg_match( '/^\d+\.\d+(?:\.\d+)?$/D', (string) ( $manifest['requires_php'] ?? '' ) ) || ! preg_match( '/^\d+\.\d+(?:\.\d+)?$/D', (string) ( $manifest['requires_wordpress'] ?? '' ) ) ) {
			return new \WP_Error( 'f3_google_update_manifest', 'Manifesto incompatível ou incompleto.' );
		}
		$url = $manifest['package_url'] ?? '';
		if ( ! is_string( $url ) || 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! in_array( wp_parse_url( $url, PHP_URL_HOST ), $origin['allowed_hosts'] ?? array(), true ) || wp_parse_url( $url, PHP_URL_USER ) || ! str_ends_with( (string) wp_parse_url( $url, PHP_URL_PATH ), '.zip' ) ) {
			return new \WP_Error( 'f3_google_update_package_origin', 'Pacote fora da origem confiável.' );
		}
		return null;
	}
	public static function updates( $transient ) {
		if ( self::channel_selected() || ! is_object( $transient ) ) {
			return $transient;
		}
		$check = self::check();
		if ( empty( $check['success'] ) || empty( $check['update_available'] ) ) {
			return $transient;
		}
		$m                                   = $check['manifest'];
		$transient->response[ self::PLUGIN ] = (object) array(
			'id'           => 'wp-mcp-google-fator3',
			'slug'         => 'wp-mcp-google-fator3',
			'plugin'       => self::PLUGIN,
			'new_version'  => $m['version'],
			'package'      => $m['package_url'],
			'url'          => $m['release_url'] ?? '',
			'requires'     => $m['requires_wordpress'],
			'requires_php' => $m['requires_php'],
		);
		return $transient;
	}
	public static function download( $reply, string $package, $upgrader, array $hook_extra = array() ) {
		if ( ( $hook_extra['plugin'] ?? '' ) !== self::PLUGIN || self::channel_selected() || false !== $reply ) {
			return $reply;
		}
		if ( ! preg_match( '~^[a-z][a-z0-9+.-]*://~i', $package ) && is_file( $package ) ) {
			return $reply;
		}
		$check = self::check();
		if ( empty( $check['success'] ) || 'incompatible' === ( $check['state'] ?? '' ) || ! isset( $check['manifest'] ) || $check['manifest']['package_url'] !== $package ) {
			return new \WP_Error( 'f3_google_update_unverified', 'O pacote não corresponde a um manifesto confiável consultado.' );
		}
		$origin = Options::get( self::OPTION, array() );
		$r      = Http\PublicPage::fetch( $package, $origin['allowed_hosts'], 5, 32 * 1024 * 1024, array( 'https' ) );
		if ( empty( $r['success'] ) || ! empty( $r['truncated'] ) || ! hash_equals( $check['manifest']['sha256'], hash( 'sha256', $r['body'] ?? '' ) ) ) {
			return new \WP_Error( 'f3_google_update_checksum', 'Download incompleto ou hash divergente.' );
		}
		$file = wp_tempnam( 'wp-mcp-google-fator3.zip' );
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- WordPress-created local temporary ZIP; exact byte count and package hash are verified.
		if ( ! $file || strlen( $r['body'] ) !== file_put_contents( $file, $r['body'] ) ) {
			return new \WP_Error( 'f3_google_update_storage', 'Não foi possível salvar o pacote temporário.' );
		}
		require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		$zip  = new \PclZip( $file );
		$list = $zip->listContent();
		$main = false;
		if ( is_array( $list ) ) {
			foreach ( $list as $entry ) {
				$path = $entry['filename'];
				if ( ! str_starts_with( $path, 'wp-mcp-google-fator3/' ) || str_contains( $path, '..' ) || preg_match( '~/(docs|reference)/|\.md$~i', $path ) ) {
					wp_delete_file( $file );
					return new \WP_Error( 'f3_google_update_package_shape', 'Estrutura do pacote incompatível.' );
				}
				if ( self::PLUGIN === $path ) {
					$main = true;
				}
			}
		}
		$paths       = array();
		$directories = array( 'wp-mcp-google-fator3' );
		$total       = 0;
		foreach ( is_array( $list ) ? $list : array() as $entry ) {
			$path   = rtrim( $entry['filename'], '/' );
			$total += (int) ( $entry['size'] ?? 0 );
			if ( isset( $paths[ $path ] ) || str_contains( $path, '\\' ) || basename( $path ) === '.htaccess' || count( $paths ) >= 2000 || $total > 128 * 1024 * 1024 ) {
				wp_delete_file( $file );
				return new \WP_Error( 'f3_google_update_package_shape', 'Arquivo duplicado, caminho inseguro ou pacote expandido excessivo.' );
			}
			$paths[ $path ] = true;
			for ( $parent = dirname( $path );'.' !== $parent;$parent = dirname( $parent ) ) {
				$directories[ $parent ] = $parent;
			}
		}
		foreach ( $directories as $directory ) {
			if ( ! isset( $paths[ $directory . '/index.php' ] ) ) {
				wp_delete_file( $file );
				return new \WP_Error( 'f3_google_update_package_shape', 'O pacote contém diretório sem índice de proteção.' );
			}
		}
		if ( ! $main ) {
			wp_delete_file( $file );
			return new \WP_Error( 'f3_google_update_package_shape', 'Arquivo principal ausente.' );
		}
		$source = $zip->extract( PCLZIP_OPT_BY_NAME, self::PLUGIN, PCLZIP_OPT_EXTRACT_AS_STRING );
		$header = $source[0]['content'] ?? '';
		if ( ! preg_match( '/Version:\s*' . preg_quote( $check['manifest']['version'], '/' ) . '\s*$/m', $header ) ) {
			wp_delete_file( $file );
			return new \WP_Error( 'f3_google_update_package_version', 'Versão interna diverge do manifesto.' );
		}
		return $file;
	}
	public static function register(): void {
		Ability::register(
			'google/check-update',
			'any',
			array(
				'label'        => 'Google: verificar atualização',
				'description'  => 'Consulta somente a origem explicitamente configurada. Distingue ausência de atualização, incompatibilidade e falha de consulta.',
				'input_schema' => array( 'properties' => array( 'refresh' => array( 'type' => 'boolean' ) ) ),
				'callback'     => static fn ( array $i ) => self::check( ! empty( $i['refresh'] ) ),
			)
		);
		Ability::register(
			'google/configure-update-origin',
			'any',
			array(
				'label'        => 'Google: configurar distribuição',
				'description'  => 'Define manifesto HTTPS e hosts confiáveis. Não publica pacote nem ativa atualização automática.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'origin', 'expected_revision' ),
					'properties' => array(
						'origin'            => self::schema(),
						'expected_revision' => array( 'type' => 'string' ),
					),
				),
				'callback'     => array( self::class, 'configure' ),
			)
		);
	}
}
