<?php
/** Bounded transient storage. Large payloads are encrypted, expiring protected files. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if (!defined( 'ABSPATH' )) {
    exit;
}
final class Cache {
    public const MAX_DB_BYTES=100000;
    public const MAX_FILE_BYTES=16777216;
    public const MAX_FILES=64;
    public const MAX_TOTAL_BYTES=67108864;
    public const HEADER="<?php http_response_code(404); exit; ?>\n";
    private static ?string $error=null;
    public static function dir(): string {
        return WP_CONTENT_DIR.'/f3-google-cache';
    }
    private static function prefix(): string {
        return 'site-'.(function_exists('get_current_blog_id')?get_current_blog_id():1).'-';
    }
    private static function path(string $key): string {
        return self::dir().'/'.self::prefix().hash('sha256',Recovery::generation().'|'.$key).'.php';
    }
    private static function lock() {
        $dir=self::dir();
        if(is_link($dir)||(!is_dir($dir)&&!@mkdir($dir,0700,true)))return false;
        $index=$dir.'/index.php';
        $path=$dir.'/'.self::prefix().'lock.php';
        if(is_link($index)||is_link($path))return false;
        if(!is_file($index)&&@file_put_contents($index,self::HEADER,LOCK_EX)===false)return false;
        $f=@fopen($path,'c+');
        if(!$f)return false;
        if(fstat($f)['size']===0){
            fwrite($f,self::HEADER);
            fflush($f);
            @chmod($path,0600);
        }
        if(!flock($f,LOCK_EX|LOCK_NB)){
            fclose($f);
            return false;
        }
        return $f;
    }
    public static function get(string $key) {
        $v=get_transient($key);
        if(false!==$v){
            if(strlen(serialize($v))>self::MAX_DB_BYTES){
                self::set($key,$v,3600);
            }
            return $v;
        }
        $path=self::path($key);
        if(is_link(self::dir())||is_link($path)||!is_file($path))return false;
        $size=@filesize($path);
        if(!$size||$size>self::MAX_FILE_BYTES)return false;
        $raw=@file_get_contents($path);
        if(!is_string($raw)||!str_starts_with($raw,self::HEADER))return false;
        $record=json_decode(substr($raw,strlen(self::HEADER)),true);
        if(!is_array($record)||!is_int($record['expires']??null)||$record['expires']<=time()){
            self::delete($key);
            return false;
        }
        $plain=Crypto::decrypt((string)($record['cipher']??''));
        if(is_wp_error($plain)||!is_string($plain))return false;
        $decoded=json_decode($plain,true);
        return is_array($decoded)&&array_key_exists('value',$decoded)?$decoded['value']:false;
    }
    public static function set(string $key,$value,int $ttl=0): bool {
        self::$error=null;
        if(strlen(serialize($value))<=self::MAX_DB_BYTES){
            $path=self::path($key);
            if(!is_link(self::dir())&&!is_link($path)&&is_file($path))@unlink($path);
            return set_transient($key,$value,$ttl);
        }
        $lock=self::lock();
        if(!$lock){
            return self::fail('f3_google_cache_unavailable');
        }
        try {
            $json=wp_json_encode(['value'=>$value]);
            if(!is_string($json)){
                return self::fail('f3_google_cache_encode');
            }
            $cipher=Crypto::encrypt($json);
            if(''===$cipher){
                return self::fail('f3_google_cache_encrypt');
            }
            $raw=self::HEADER.wp_json_encode(['expires'=>time()+max(1,min(86400,$ttl?:3600)),'cipher'=>$cipher]);
            if(strlen($raw)>self::MAX_FILE_BYTES){
                return self::fail('f3_google_cache_size');
            }
            $path=self::path($key);
            if(is_link($path)){
                return self::fail('f3_google_cache_path');
            }
            self::prune_locked(strlen($raw),$path);
            $tmp=self::dir().'/'.self::prefix().'tmp-'.bin2hex(random_bytes(8)).'.php';
            $fp=@fopen($tmp,'x');
            if(!$fp){
                return self::fail('f3_google_cache_write');
            }
            $n=fwrite($fp,$raw);
            fflush($fp);
            fclose($fp);
            @chmod($tmp,0600);
            if($n!==strlen($raw)||!@rename($tmp,$path)){
                @unlink($tmp);
                return self::fail('f3_google_cache_write');
            }
            delete_transient($key);
            $health=Options::get('f3_mcp_google_cache_health',[]);
            if(($health['state']??'')==='failed')Options::set('f3_mcp_google_cache_health',['state'=>'recovered','at'=>time(),'previous_error'=>$health['error_code']]);
            return true;
        }
        catch(\Throwable $e) {
            return self::fail('f3_google_cache_unavailable');
        }
        finally {
            flock($lock,LOCK_UN);
            fclose($lock);
        }
    }
    /** Small bounded scan, shared with writers; files are disposable, never the recovery fence. */
    private static function prune_locked(int $reserve=0,string $replace=''): void {
        $files=[];
        $bytes=0;
        foreach(glob(self::dir().'/'.self::prefix().'*.php')?:[] as $file){
            if(str_ends_with($file,'lock.php')||is_link($file))continue;
            $size=filesize($file);
            $mtime=filemtime($file);
            $head=@file_get_contents($file,false,null,0,256);
            $expired=is_string($head)&&preg_match('/"expires":([0-9]+)/',$head,$m)&&(int)$m[1]<=time();
            if($expired||$mtime<time()-86400||str_contains(basename($file),'tmp-')){
                @unlink($file);
                continue;
            }
            if($file===$replace)continue;
            $files[$file]=['size'=>$size,'at'=>$mtime];
            $bytes+=$size;
        }
        uasort($files,static fn($a,$b)=>$a['at']<=>$b['at']);
        foreach($files as$file=>$info){
            if(count($files)+($reserve?1:0)<=self::MAX_FILES&&$bytes+$reserve<=self::MAX_TOTAL_BYTES)break;
            if(@unlink($file)){
                $bytes-=$info['size'];
                unset($files[$file]);
            }
        }
        if(count($files)+($reserve?1:0)>self::MAX_FILES||$bytes+$reserve>self::MAX_TOTAL_BYTES)throw new \RuntimeException('f3_google_cache_capacity');
    }
    public static function delete(string $key): bool {
        $r=delete_transient($key);
        $path=self::path($key);
        if(!is_link(self::dir())&&!is_link($path)&&is_file($path))return @unlink($path);
        return $r;
    }
    public static function maintain(bool $purge=false): void {
        $lock=self::lock();
        if(!$lock)return;
        try {
            if($purge){
                foreach(glob(self::dir().'/'.self::prefix().'*.php')?:[] as$file)if(!str_ends_with($file,'lock.php')&&!is_link($file))@unlink($file);
            }
            else self::prune_locked();
        }
        finally {
            flock($lock,LOCK_UN);
            fclose($lock);
        }
    }
    private static function fail(string $code): bool {
        self::$error=$code;
        Options::set('f3_mcp_google_cache_health',['state'=>'failed','at'=>time(),'error_code'=>$code]);
        return false;
    }
    public static function last_error(): ?string {
        return self::$error;
    }
    public static function status(): array {
        return ['database_max_bytes'=>self::MAX_DB_BYTES,'large_payloads'=>'encrypted_php_files','max_files'=>self::MAX_FILES,'max_total_bytes'=>self::MAX_TOTAL_BYTES,'max_file_ttl'=>86400,'last_error'=>self::$error,'health'=>Options::get('f3_mcp_google_cache_health',['state'=>'no_failure_observed'])];
    }
}
