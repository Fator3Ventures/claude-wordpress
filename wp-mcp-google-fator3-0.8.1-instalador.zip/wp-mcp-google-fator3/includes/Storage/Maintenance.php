<?php
/** Bounded package maintenance; runs independently from Google credentials or due jobs. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Storage;
use Fator3\McpGoogle\{
    Options,Lock,Connections,Cache,Records,Recovery,Response
};
if(!defined( 'ABSPATH' ))exit;
final class Maintenance {
    public const HOOK='f3_mcp_google_maintenance';
    public const OPTION='f3_mcp_google_maintenance';
    public static function init(): void {
        add_action(self::HOOK,[self::class,'run']);
        if(Options::get('f3_mcp_google_cron_schema')!==1){
            $schema=CronStore::install();
            if(!is_wp_error($schema))Options::set('f3_mcp_google_cron_schema',1);
            else Options::set(self::OPTION,['state'=>'failed','success'=>false,'errors'=>[$schema->get_error_code()]]);
        }
        if(function_exists('wp_next_scheduled')&&!wp_next_scheduled(self::HOOK))wp_schedule_event(time()+5,'hourly',self::HOOK);
    }
    public static function status(): array {
        $r=Options::stored(self::OPTION);
        return $r['success'] ? ($r['value']??['state'=>'pending','success'=>null]) : ['state'=>'failed','success'=>false,'error_code'=>'f3_google_maintenance_read'];
    }
    public static function run(): array {
        return Recovery::run(static fn()=>self::work());
    }
    private static function work(): array {
        global $wpdb;
        $lock=Lock::acquire('package-maintenance',60);
        if(!$lock)return ['success'=>false,'error_code'=>'f3_google_maintenance_busy'];
        $out=['success'=>true,'state'=>'complete','at'=>time(),'cron_removed'=>0,'legacy_archived'=>0,'cache_migrated'=>0,'remaining'=>false,'errors'=>[]];
        try {
            $cids=array_keys(Connections::registry());
            // Also cover connections removed from the registry; identifiers come from stored rows.
            $names=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s ORDER BY option_name LIMIT 100",$wpdb->esc_like('f3_mcp_google_cron_pass_').'%',$wpdb->esc_like('f3_mcp_google_cron_incident_').'%'));
            if($wpdb->last_error)throw new \RuntimeException('f3_google_maintenance_read');
            foreach($names as$name)if(preg_match('/^f3_mcp_google_cron_(?:pass|incident)_(.+)_[0-9]{20}_[a-f0-9]{16}$/D',$name,$m))$cids[]=$m[1];
            foreach(array_unique($cids)as$cid) {
                $r=CronStore::migrate($cid);
                $out['cron_removed']+=(int)($r['removed']??0);
                if(!$r['success'])$out['errors'][]=$r['error_code']??'f3_google_cron_migration';
                if(empty($r['complete']))$out['remaining']=true;
            }
            $state=Migration::state();
            if(Migration::active() && isset($state['verified'],$state['copied']) && $state['verified']===$state['copied']) {
                $names=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name LIMIT 100",$wpdb->esc_like(Records::PREFIX).'%'));
                if($wpdb->last_error)throw new \RuntimeException('f3_google_maintenance_read');
                foreach($names as$name) {
                    $off=Options::disable_autoload($name);
                    if(!$off['success'])throw new \RuntimeException($off['error_code']);
                    if($name>($state['verify_cursor']??''))throw new \RuntimeException('f3_google_legacy_unverified');
                    $r=Options::stored($name);
                    if(!$r['success']||!$r['exists']||!is_array($r['value']))throw new \RuntimeException('f3_google_legacy_invalid');
                    $id=hash('sha256',$name);
                    $old=Repository::get('legacy',$id);
                    if(is_wp_error($old))throw new \RuntimeException($old->get_error_code());
                    if(null===$old){
                        $copy=['source'=>$name,'value'=>$r['value'],'created_at'=>time(),'expires_at'=>time()+8*86400];
                        if(!Repository::insert('legacy',$id,$copy)||Repository::get('legacy',$id)!==$copy)throw new \RuntimeException('f3_google_legacy_archive');
                    }
                    elseif(($old['source']??null)!==$name||($old['value']??null)!==$r['value'])throw new \RuntimeException('f3_google_legacy_archive_conflict');
                    if(!Lock::owned($lock))throw new \RuntimeException('f3_google_lock_lost');
                    if(!Options::delete($name)['success'])throw new \RuntimeException('f3_google_legacy_delete');
                    ++$out['legacy_archived'];
                }
                if(count($names)===100)$out['remaining']=true;
                $rows=$wpdb->get_col($wpdb->prepare('SELECT record_id FROM '.Repository::table().' WHERE kind=%s AND expires_at<%d ORDER BY sequence LIMIT 100','legacy',time()));
                if($wpdb->last_error)throw new \RuntimeException('f3_google_legacy_archive_read');
                foreach($rows as$id)if(!Repository::remove('legacy',$id)['success'])throw new \RuntimeException('f3_google_legacy_archive_delete');
            }
            else {
                $names=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name LIMIT 100",$wpdb->esc_like(Records::PREFIX).'%'));
                if($wpdb->last_error)throw new \RuntimeException('f3_google_maintenance_read');
                foreach($names as$name){
                    $r=Options::disable_autoload($name);
                    if(!$r['success'])throw new \RuntimeException($r['error_code']);
                }
                if($names)$out['remaining']=true;
            }
            // Values and timeouts are always handled through the transient API, including object caches.
            $names=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND (LENGTH(option_value)>%d OR option_name LIKE %s) ORDER BY option_name LIMIT 100",$wpdb->esc_like('_transient_f3_mcp_google_').'%',Cache::MAX_DB_BYTES,$wpdb->esc_like('_transient_f3_mcp_google_discovery_').'%'));
            if($wpdb->last_error)throw new \RuntimeException('f3_google_cache_migration_read');
            foreach($names as$name){
                $key=substr($name,strlen('_transient_'));
                if(str_starts_with($key,'f3_mcp_google_discovery_')){
                    Cache::delete($key);
                }
                else {
                    $v=get_transient($key);
                    $timeout=(int)get_option('_transient_timeout_'.$key,0);
                    if(false!==$v&&!Cache::set($key,$v,$timeout>time()?$timeout-time():3600))throw new \RuntimeException('f3_google_cache_migration_write');
                    delete_transient($key);
                }
                $r=Options::stored($name);
                if(!$r['success']||$r['exists'])throw new \RuntimeException('f3_google_cache_migration_delete');
                ++$out['cache_migrated'];
            }
            if(count($names)===100)$out['remaining']=true;
            Cache::maintain();
            if($out['errors']){
                $out['success']=false;
                $out['state']='failed';
            }
            elseif($out['remaining'])$out['state']='pending';
        }
        catch(\Throwable $e){
            $out['success']=false;
            $out['state']='failed';
            $code=$e->getMessage();
            $out['errors'][]=preg_match('/^f3_google_[a-z_]+$/D',$code)?$code:'f3_google_maintenance_failed';
        }
        finally {
            Lock::release($lock);
        }
        $saved=Options::set(self::OPTION,$out);
        if(!$saved['success'])return Response::fail(new \WP_Error('f3_google_maintenance_persistence','Manutenção executada, mas o resultado não foi persistido.'),['work_result'=>$out]);
        if($out['remaining'] && function_exists('wp_next_scheduled') && ( !wp_next_scheduled(self::HOOK) || wp_next_scheduled(self::HOOK)>time()+60)) wp_schedule_single_event(time()+15,self::HOOK);
        return $out;
    }
}
