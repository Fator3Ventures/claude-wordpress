<?php
/** Indexed cron telemetry; never creates an option per event. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Storage;
use Fator3\McpGoogle\{
    Options,Lock
};
if (!defined( 'ABSPATH' )) {
    exit;
}
final class CronStore {
    public const DAYS=8;
    public const MAX_PASSES=20000;
    public const MAX_INCIDENTS=1000;
    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix.'f3_google_cron';
    }
    private static function error(string $phase): \WP_Error {
        return new \WP_Error('f3_google_cron_storage_'.$phase,'Falha no armazenamento do histórico de cron.');
    }
    public static function install() {
        global $wpdb;
        $t=self::table();
        $collate=$wpdb->get_charset_collate();
        $r=$wpdb->query("CREATE TABLE IF NOT EXISTS $t (kind varchar(12) NOT NULL, connection_id varchar(40) NOT NULL, run_id varchar(100) NOT NULL, at bigint NOT NULL, origin varchar(12) NOT NULL, scope varchar(24) NOT NULL, success smallint DEFAULT NULL, payload longtext NOT NULL, digest char(64) NOT NULL, PRIMARY KEY(kind,connection_id,run_id), KEY history_time(kind,connection_id,at,run_id), KEY origin_time(kind,connection_id,origin,at,run_id), KEY scope_time(kind,connection_id,scope,at,run_id)) ENGINE=InnoDB $collate");
        return false===$r || $wpdb->last_error ? self::error('schema') : true;
    }
    private static function query(string $sql) {
        global $wpdb;
        $rows=$wpdb->get_results($sql,ARRAY_A);
        return $wpdb->last_error || !is_array($rows) ? self::error('read') : $rows;
    }
    public static function get(string $kind,string $cid,string $id): array {
        global $wpdb;
        $rows=self::query($wpdb->prepare('SELECT payload,digest FROM '.self::table().' WHERE kind=%s AND connection_id=%s AND run_id=%s',$kind,$cid,$id));
        if(is_wp_error($rows))return ['success'=>false,'exists'=>false,'value'=>null,'error_code'=>$rows->get_error_code()];
        if(!$rows)return ['success'=>true,'exists'=>false,'value'=>null];
        $v=json_decode($rows[0]['payload'],true);
        if(!is_array($v)||!hash_equals($rows[0]['digest'],hash('sha256',$rows[0]['payload'])))return ['success'=>false,'exists'=>true,'value'=>null,'error_code'=>'f3_google_cron_storage_corrupt'];
        return ['success'=>true,'exists'=>true,'value'=>$v];
    }
    /** Caller owns cron-history:<connection> for passes or cron-incident:<connection> for incidents. */
    public static function put(string $kind,string $cid,string $id,array $value): array {
        global $wpdb;
        $old=self::get($kind,$cid,$id);
        if(!$old['success'])return $old;
        $json=wp_json_encode($value);
        if(!is_string($json)||strlen($json)>65536)return ['success'=>false,'error_code'=>'f3_google_cron_storage_size'];
        if(!$old['exists']) {
            $trim=self::trim($cid,$kind,1);
            if(is_wp_error($trim))return ['success'=>false,'error_code'=>$trim->get_error_code()];
        }
        $fields=[(int)$value['at'],(string)($value['origem']??''),(string)($value['scope']??''),$json,hash('sha256',$json),$kind,$cid,$id];
        $success=array_key_exists('success',$value)&&is_bool($value['success']) ? ($value['success']?'1':'0') : 'NULL';
        $sql=$old['exists'] ? 'UPDATE '.self::table()." SET at=%d,origin=%s,scope=%s,payload=%s,digest=%s,success=$success WHERE kind=%s AND connection_id=%s AND run_id=%s" : 'INSERT INTO '.self::table()." (at,origin,scope,payload,digest,kind,connection_id,run_id,success) VALUES (%d,%s,%s,%s,%s,%s,%s,%s,$success)";
        $n=$wpdb->query($wpdb->prepare($sql,...$fields));
        if(false===$n||$wpdb->last_error)return ['success'=>false,'error_code'=>'f3_google_cron_storage_write'];
        $after=self::get($kind,$cid,$id);
        return ['success'=>$after['success']&&$after['value']===$value,'error_code'=>$after['success']&&$after['value']===$value ? null : 'f3_google_cron_storage_verify'];
    }
    public static function latest(string $cid,string $kind='pass',string $field='',string $value='') {
        global $wpdb;
        $where=$wpdb->prepare('kind=%s AND connection_id=%s',$kind,$cid);
        if(in_array($field,['origin','scope','success'],true))$where.=$wpdb->prepare(" AND $field=%s",$value);
        $rows=self::query('SELECT payload,digest FROM '.self::table().' WHERE '.$where.' ORDER BY at DESC,run_id DESC LIMIT 1');
        if(is_wp_error($rows))return $rows;
        if(!$rows)return null;
        $r=$rows[0];
        $v=json_decode($r['payload'],true);
        return is_array($v)&&hash_equals($r['digest'],hash('sha256',$r['payload'])) ? $v : self::error('corrupt');
    }
    public static function counts(string $cid,int $now) {
        global $wpdb;
        return self::query($wpdb->prepare('SELECT origin,COUNT(*) AS total FROM '.self::table().' WHERE kind=%s AND connection_id=%s AND at>%d AND at<=%d GROUP BY origin','pass',$cid,$now-86400,$now));
    }
    public static function legacy_names(string $cid,int $limit=100): array {
        global $wpdb;
        $a=$wpdb->esc_like('f3_mcp_google_cron_pass_'.$cid.'_').'%';
        $b=$wpdb->esc_like('f3_mcp_google_cron_incident_'.$cid.'_').'%';
        $names=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE (option_name LIKE %s OR option_name LIKE %s) ORDER BY option_name ASC LIMIT %d",$a,$b,$limit));
        if($wpdb->last_error||!is_array($names))throw new \RuntimeException('f3_google_cron_storage_read');
        return $names;
    }
    /** Called under the connection lock; at most 100 removals per kind. */
    public static function trim(string $cid,string $kind,int $reserve=0) {
        global $wpdb;
        $t=self::table();
        $max='pass'===$kind?self::MAX_PASSES:self::MAX_INCIDENTS;
        $rows=self::query($wpdb->prepare("SELECT COUNT(*) AS total FROM $t WHERE kind=%s AND connection_id=%s",$kind,$cid));
        if(is_wp_error($rows))return $rows;
        $over=max(0,(int)$rows[0]['total']+$reserve-$max);
        $where=$wpdb->prepare('kind=%s AND connection_id=%s',$kind,$cid);
        $limit=min(100,max(1,$over));
        $cut=$over ? '' : $wpdb->prepare(' AND at<%d',time()-self::DAYS*86400);
        // Recent running invocations are never evicted to make room.
        $cut.=$wpdb->prepare(" AND NOT (scope IN ('executor','wp_cli_invocation') AND success IS NULL AND at>=%d)",time()-120);
        $old=self::query("SELECT run_id,at FROM $t WHERE $where$cut ORDER BY at ASC,run_id ASC LIMIT ".($over?$limit:100));
        if(is_wp_error($old))return $old;
        foreach($old as $row) {
            if('pass'===$kind && (int)$row['at']>time()-86400) {
                $key='f3_mcp_google_cron_truncated_'.$cid;
                $prior=Options::stored($key);
                if(!$prior['success']||!Options::set($key,max((int)($prior['value']??0),(int)$row['at']))['success'])return self::error('retention');
            }
            $n=$wpdb->query($wpdb->prepare("DELETE FROM $t WHERE kind=%s AND connection_id=%s AND run_id=%s",$kind,$cid,$row['run_id']));
            if(false===$n||$wpdb->last_error)return self::error('retention');
        }
        if($over>count($old))return self::error('capacity');
        return true;
    }
    /** Legacy rows are frozen by this release. Copy/verify/delete is restartable. */
    public static function migrate(string $cid): array {
        $lock=Lock::acquire('cron-history:'.$cid,30);
        if(!$lock)return ['success'=>false,'error_code'=>'f3_google_cron_migration_busy'];
        $incidentLock=Lock::acquire('cron-incident:'.$cid,30);
        if(!$incidentLock){
            Lock::release($lock);
            return ['success'=>false,'error_code'=>'f3_google_cron_migration_busy'];
        }
        try {
            $installed=self::install();
            if(is_wp_error($installed))return ['success'=>false,'error_code'=>$installed->get_error_code()];
            $names=self::legacy_names($cid);
            $removed=0;
            foreach($names as $name) {
                $kind=str_starts_with($name,'f3_mcp_google_cron_pass_')?'pass':'incident';
                $id=substr($name,strlen('f3_mcp_google_cron_'.$kind.'_'.$cid.'_'));
                $off=Options::disable_autoload($name);
                if(!$off['success'])return $off;
                $r=Options::stored($name);
                if(!$r['success']||!$r['exists']||!is_array($r['value'])||!is_int($r['value']['at']??null))return ['success'=>false,'error_code'=>'f3_google_cron_legacy_invalid'];
                $value=$r['value'];
                $old=self::get($kind,$cid,$id);
                if(!$old['success'])return $old;
                // Keep an already confirmed copy; a destination event may have completed meanwhile.
                if(!$old['exists']) {
                    $save=self::put($kind,$cid,$id,$value);
                    if(!$save['success'])return $save;
                }
                elseif($old['value']!==$value) {
                    return ['success'=>false,'error_code'=>'f3_google_cron_legacy_conflict'];
                }
                // Reconcile projections before pruning an old sole event.
                $project=\Fator3\McpGoogle\Automation\CronHistory::reconcile_row($kind,$cid,$value);
                if(!$project['success'])return $project;
                if(!Lock::owned($lock)||!Lock::owned($incidentLock))return ['success'=>false,'error_code'=>'f3_google_lock_lost'];
                $delete=Options::delete($name);
                if(!$delete['success'])return $delete;
                ++$removed;
            }
            foreach(['pass','incident']as$kind){
                $trim=self::trim($cid,$kind);
                if(is_wp_error($trim))return ['success'=>false,'error_code'=>$trim->get_error_code()];
            }
            return ['success'=>true,'removed'=>$removed,'complete'=>!self::legacy_names($cid,1)];
        }
        catch(\Throwable $e) {
            return ['success'=>false,'error_code'=>'f3_google_cron_migration_read'];
        }
        finally {
            Lock::release($incidentLock);
            Lock::release($lock);
        }
    }
}
