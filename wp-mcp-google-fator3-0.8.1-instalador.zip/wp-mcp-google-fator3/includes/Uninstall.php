<?php
/**
 * Uninstall always removes credentials; public settings/history are retained by default.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Uninstall {

	/** A network deactivation must stop each site's executor without deleting credentials. */
	public static function on_deactivation( bool $network_wide = false ): void {
		if ( ! $network_wide || ! is_multisite() ) {
			self::deactivate();
			return;
		}
		$offset = 0;
		do {
			$ids = get_sites(
				array(
					'fields'  => 'ids',
					'number'  => 100,
					'offset'  => $offset,
					'orderby' => 'id',
					'order'   => 'ASC',
				)
			);
			foreach ( $ids as $id ) {
				switch_to_blog( (int) $id );
				try {
					self::deactivate();
				} finally {
					restore_current_blog();
				}
			}
			$offset    += count( $ids );
			$page_count = count( $ids );
		} while ( 100 === $page_count );
	}
	/** Remove temporary credentials through cache APIs as well as persistent storage. */
	public static function deactivate(): void {
		global $wpdb;
        Cache::maintain(true);
		foreach ( array( 'f3_mcp_google_jobs_tick', 'f3_mcp_google_storage_step', 'f3_mcp_google_maintenance' ) as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$indexes = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'f3_mcp_google_' ) . '%token_index' ) );
		foreach ( $indexes as $name ) {
			foreach ( (array) get_option( $name, array() ) as $key ) {
				if ( is_string( $key ) && str_starts_with( $key, 'f3_mcp_google_' ) ) {
					delete_transient( $key );
					delete_site_transient( $key );
					wp_cache_delete( $key, 'transient' );
					wp_cache_delete( $key, 'site-transient' );
				}
			}
			delete_option( $name );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( '_transient_f3_mcp_google_' ) . '%' ) );
		foreach ( $names as $name ) {
			delete_transient( substr( $name, strlen( '_transient_' ) ) );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( '_transient_timeout_f3_mcp_google_' ) . '%' ) );
	}
	public static function site(): void {
		global $wpdb;
		$purge = (bool) get_option( 'f3_mcp_google_purge_on_uninstall', false );
		self::deactivate();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'f3_mcp_google_' ) . '%' ) );
		foreach ( $names as $name ) {
			if ( str_ends_with( $name, 'token_index' ) ) {
				foreach ( (array) get_option( $name, array() ) as $key ) {
					if ( is_string( $key ) && str_starts_with( $key, 'f3_mcp_google_' ) ) {
						delete_transient( $key );
					}
				}
			}
			if ( $purge || preg_match( '/(sa_json|sa_subject|oauth_client_secret|oauth_refresh_token|oauth_email|oauth_scopes|ads_developer_token|candidate_sa|candidate_oauth|token_index)$/D', $name ) || str_starts_with( $name, 'f3_mcp_google_lock_' ) || str_starts_with( $name, 'f3_mcp_google_record_confirmation_' ) ) {
				delete_option( $name );
				continue;
			}
			if ( str_starts_with( $name, 'f3_mcp_google_record_job_' ) || str_starts_with( $name, 'f3_mcp_google_record_schedule_' ) ) {
				$record = get_option( $name );
				if ( is_array( $record ) ) {
					update_option( $name, self::pause( $record ), false );
				}
			}
			if ( str_ends_with( $name, 'alerts' ) ) {
				$config = get_option( $name, array() );
				if ( is_array( $config ) ) {
					$config['enabled']       = false;
					$config['email_enabled'] = false;
					update_option( $name, $config, false );
				}
			}
			if ( str_ends_with( $name, 'auth_ready' ) ) {
				update_option( $name, false, false );
			}
		}
		if($purge) $wpdb->query('DROP TABLE IF EXISTS '.$wpdb->prefix.'f3_google_cron');
        $table = $wpdb->prefix . 'f3_google_records';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
		if ( $exists === $table ) {
			if ( $purge ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.PreparedSQL.NotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
				$wpdb->query( 'DROP TABLE ' . $table );
			} else {
				$cursor = 0;
				do {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
					$rows = $wpdb->get_results( $wpdb->prepare( "SELECT sequence,payload,kind FROM $table WHERE sequence>%d AND kind IN ('job','schedule') ORDER BY sequence LIMIT 100", $cursor ), ARRAY_A );
					foreach ( $rows as $row ) {
						$record = json_decode( $row['payload'], true );
						if ( is_array( $record ) ) {
							$record = self::pause( $record );
							$json   = wp_json_encode( $record );
							$state  = $record['status'] ?? 'paused';
							// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
							$wpdb->query( $wpdb->prepare( "UPDATE $table SET payload=%s,digest=%s,state=%s,owner='',lease_until=0,generation=generation+1 WHERE sequence=%d", $json, hash( 'sha256', $json ), $state, $row['sequence'] ) );
						}
						$cursor = (int) $row['sequence'];
					}
					$page_count = count( $rows );
				} while ( 100 === $page_count );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
				$wpdb->query( "DELETE FROM $table WHERE kind IN ('confirmation','candidate')" );
			}
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_f3_mcp_google_' ) . '%', $wpdb->esc_like( '_transient_timeout_f3_mcp_google_' ) . '%' ) );
		if ( ! $purge ) {
			update_option( 'f3_mcp_google_enabled', false, false );
			update_option( 'f3_mcp_google_auth_ready', false, false );
		}
	}
	/** Legacy network token caches are removed once after the per-site pass. */
	public static function network(): void {
		global $wpdb;
		$prefix = '_site_transient_f3_mcp_google_';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$names = $wpdb->get_col( $wpdb->prepare( "SELECT meta_key FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s", $wpdb->esc_like( $prefix ) . '%' ) );
		foreach ( $names as $name ) {
			delete_site_transient( substr( $name, strlen( '_site_transient_' ) ) );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s OR meta_key LIKE %s", $wpdb->esc_like( $prefix ) . '%', $wpdb->esc_like( '_site_transient_timeout_f3_mcp_google_' ) . '%' ) );
	}
	private static function pause( array $record ): array {
		unset( $record['context'] );
		if ( isset( $record['enabled'] ) ) {
			$record['enabled'] = false;
		}
		if ( isset( $record['status'] ) && ! in_array( $record['status'], array( 'completed', 'failed', 'cancelled', 'reconciled', 'unknown' ), true ) ) {
			$record['status'] = ! empty( $record['write'] ) && in_array( $record['status'], array( 'running', 'dispatching' ), true ) ? 'unknown' : 'blocked';
		}
		$record['blocked_reason'] = 'plugin_uninstalled_requires_reauthorization';
		return $record;
	}
}
