# Fator3 Site Core 1.78.0

Requer WordPress 7.1.4 e PHP 8.3. Atualização direta da 1.77.0. Contrato administrativo 8.38.0. Consulte docs/DOCUMENTACAO.md e docs/RELEASE-1.78.0.md.


