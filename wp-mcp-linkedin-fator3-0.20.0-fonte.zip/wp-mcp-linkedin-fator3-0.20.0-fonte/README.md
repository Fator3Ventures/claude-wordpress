# Fonte — Fator3 MCP LinkedIn 0.20.0

O instalador contém o runtime de `plugin/wp-mcp-linkedin-fator3/`. Edite os modelos em `build/common/`, o código do provedor em `build/linkedin/`, o painel em `build/assets/` e os documentos em `build/docs/linkedin/`. Documentos, schemas e índice compilado são incluídos no mesmo build. O programa em `build/manuals/` captura o registro das operações sem executar callbacks; gera o catálogo e as tabelas e valida os manuais usando o runtime que será distribuído. O fonte não contém o ZIP instalador nem dependências da bancada.

## Construir

Use PHP ≥ 8.3, Python 3 e o comando abaixo na raiz do fonte. Consulte o relatório para as versões do conjunto e dos instrumentos usados. O arquivo oficial foi fechado com Python 3.12.14 e zlib 1.3.2. Outra biblioteca de compressão pode produzir bytes diferentes mesmo com 100% da árvore idêntica.

```sh
F3_SOCIAL_PHP=/caminho/php8.3 python3 build/build.py
python3 tools/verify-installer020.py build/dist/wp-mcp-linkedin-fator3-0.20.0-instalador.zip plugin/wp-mcp-linkedin-fator3
```

A verificação compara todos os caminhos e arquivos, o manifesto, a raiz e o cabeçalho. Não substitui a conferência do SHA-256 do instalador entregue ao dono.

## Testar

Use um WordPress e banco locais descartáveis. O laboratório valida os hashes do manifesto, cria um banco por suíte, bloqueia chamadas externas e instala os pacotes informados. Configure os caminhos e o acesso ao MySQL em uma cópia de `tools/lab-release0200.example.json`. Os cinco acompanhantes são os vigentes listados no relatório. Exemplos:

```sh
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li20-server --order linkedin-integrated --tests server020.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li20-upgrade --order linkedin-integrated --origin upgrade --tests migration020.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li20-manual --order linkedin-integrated --tests mcp-docs080.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li20-browser --order linkedin-only --tests webui020.php
```

O Chrome local com sandbox e o Playwright são necessários apenas para `webui020.php`. Defina `F3_CHROME_HEADLESS_SHELL` com o executável testado; o ensaio só acessa o loopback. Suítes anteriores que requerem jsdom usam o lockfile de `tests/dom/`. Em `tests/mutations/`, `docs020.py` introduz defeitos em cópias dos manuais; `installers020.py` produz candidatos deliberadamente defeituosos somente em diretório de QA externo, para executar com `--candidate` nos testes específicos. Nunca os distribua.

## Evidências

`evidence/release0200/`: resultados próprios, versão examinada, comparações e limites. Em `planning/` e `inputs/0.20.0/` ficam o plano recebido, o parecer e as normas da rodada. Documentos de versões anteriores são históricos. O relatório externo é a referência para identidades de entrega, estado do Site-Teste e homologação de fornecedor.
