<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Adapter {
    public static function base(array $c): string {return 'https://graph.facebook.com/'.$c['api_version'].'/';}
    public static function encode(array $q): string {return http_build_query($q,'','&',PHP_QUERY_RFC3986);}
    public static function allowed(string $path,string $method): bool {return $method==='GET'&&(bool)preg_match('~^(?:me/accounts|[0-9]{1,40}(?:/(?:media|stories|insights))?)$~D',$path);}
    public static function reports(): array {return ['profile','media','stories','account_insights','media_insights','audience'];}
    public static function fields(string $report): array {
        $catalog=[
            'profile'=>['id','username','name','biography','website','followers_count','follows_count','media_count','profile_picture_url'],
            'media'=>['id','caption','media_type','media_product_type','timestamp','permalink','like_count','comments_count'],
            'stories'=>['id','media_type','media_product_type','timestamp','permalink'],
            'account_insights'=>['reach','views','accounts_engaged','total_interactions','likes','comments','shares','saves','profile_links_taps','follows_and_unfollows'],
            'media_insights'=>['reach','views','likes','comments','shares','saved','total_interactions','ig_reels_video_view_total_time','ig_reels_avg_watch_time','replies','navigation'],
            'audience'=>['follower_demographics','engaged_audience_demographics','reached_audience_demographics'],
        ];
        if(!isset($catalog[$report]))throw new Fault('unsupported','Relatório não suportado.');
        $out=[];foreach($catalog[$report] as $f)$out[]=['name'=>$f,'source_field'=>$f,'unit'=>str_contains($f,'time')?'milliseconds':'provider_defined','temporal'=>in_array($report,['profile','media_insights','audience'],true)?'snapshot_or_lifetime':'provider_period','aggregation'=>in_array($f,['reach','accounts_engaged','followers_count'],true)?'native_unique_or_snapshot':'preserve_source','availability'=>'requires_remote_validation','api_family'=>'instagram-facebook-login'];return $out;
    }
    public static function accounts(array $c,array $i): array {
        $q=['fields'=>'id,name,instagram_business_account{id,username,name}','limit'=>50];if(!empty($i['after']))$q['after']=$i['after'];
        $r=Http::request($c,'me/accounts',$q)['body'];if(!isset($r['data'])||!is_array($r['data']))throw new Fault('upstream_invalid','Lista de Páginas inválida.');
        $rows=[];foreach($r['data'] as $p)if(isset($p['instagram_business_account']['id']))$rows[]=['id'=>(string)$p['instagram_business_account']['id'],'username'=>$p['instagram_business_account']['username']??null,'name'=>$p['instagram_business_account']['name']??null,'page_id'=>(string)$p['id']];
        return ['rows'=>$rows,'continuation'=>self::after($r),'limitation'=>'Descoberta requer token de usuário e Página vinculada; token de Página pode exigir seleção manual do Instagram.'];
    }
    private static function after(array $r): ?string {return !empty($r['paging']['next'])&&is_string($r['paging']['cursors']['after']??null)?$r['paging']['cursors']['after']:null;}
    public static function validate(array $c,string $channel,string $account): array {
        $r=Http::request($c,$account,['fields'=>'id,username'])['body'];
        if((string)($r['id']??'')!==$account)throw new Fault('asset_access_denied','Identidade de conta divergente.');
        return ['account_id'=>$account,'metadata_read'=>true,'insights_read'=>false,'app_approval_verified'=>false,'checked_at'=>gmdate('c')];
    }
    public static function page(array $c,array $i,array $s): array {
        $account=Util::numeric($i['account_id']);$report=$i['report'];$allowed=array_column(self::fields($report),'name');$fields=$i['fields']??[];
        if(!$fields)$fields=match($report){'profile'=>['id','username','followers_count','media_count'],'media'=>['id','caption','media_type','media_product_type','timestamp','permalink'],'stories'=>['id','media_type','timestamp'],'audience'=>['follower_demographics'],default=>['reach','views']};
        if(array_diff($fields,$allowed))throw new Fault('unsupported_field','Campo não disponível no catálogo deste relatório.');
        $out=['rows'=>[],'next'=>null,'warnings'=>[],'errors'=>[],'origin_complete'=>null,'timezone'=>'provider_defined','currency'=>null,'temporal'=>'snapshot','fields'=>$fields];
        if($report==='profile'){
            $r=Http::request($c,$account,['fields'=>implode(',',$fields)])['body'];if((string)($r['id']??$account)!==$account)throw new Fault('upstream_invalid','Conta divergente.');
            $out['rows']=[$r];return $out;
        }
        if(in_array($report,['media','stories'],true)){
            $q=['fields'=>implode(',',array_unique(array_merge(['id','timestamp'],$fields))),'limit'=>$i['limit']??50];if(isset($s['after']))$q['after']=$s['after'];
            $r=Http::request($c,$account.'/'.$report,$q)['body'];if(!is_array($r['data']??null))throw new Fault('upstream_invalid','Lista de mídias inválida.');
            $out['rows']=$r['data'];$after=self::after($r);if($after)$out['next']=['after'=>$after];
            $out['warnings'][]=$report==='stories'?'Histórico limitado às Stories que a origem ainda disponibiliza.':'Lista ordenada pela origem; filtros de datas são locais e não encerram a paginação antecipadamente.';
            if(isset($i['date_from'],$i['date_to'])){$d=Util::dates($i);$out['rows']=array_values(array_filter($out['rows'],static function($v)use($d){$t=strtotime($v['timestamp']??'');return $t!==false&&$t>=$d['date_from_ts']&&$t<$d['date_to_ts']+86400;}));}
            $out['temporal']=$report==='stories'?'ephemeral_snapshot':'publication';return $out;
        }
        $index=(int)($s['metric']??0);if(!isset($fields[$index]))throw new Fault('invalid_cursor','Índice de métrica inválido.');$metric=$fields[$index];$q=['metric'=>$metric];$entity=$account;
        if($report==='media_insights'){
            $entity=Util::numeric($i['media_id']??'');
            $m=Http::request($c,$entity,['fields'=>'id,owner,media_type,media_product_type'])['body'];
            if((string)($m['owner']['id']??$m['owner']??'')!==$account)throw new Fault('asset_access_denied','A mídia não pertence à conta selecionada.');
            $out['warnings'][]='Métricas variam por tipo de mídia; valores acumulados não são distribuídos retroativamente.';
        }elseif($report==='audience'){
            $q+=['period'=>'lifetime','metric_type'=>'total_value','timeframe'=>$i['timeframe']??'last_30_days','breakdown'=>$i['breakdown']??'country'];
            $out['warnings'][]='Demografia agregada sujeita a limiares e supressão; ausência não equivale a zero.';
        }else{
            $d=Util::dates($i,30);$q+=['period'=>'day','metric_type'=>'total_value','since'=>$d['date_from_ts'],'until'=>$d['date_to_ts']+86400];
            if($metric==='follows_and_unfollows')$q['breakdown']='follow_type';
            $out['temporal']='interval';
        }
        try{
            $r=Http::request($c,$entity.'/insights',$q)['body'];if(!is_array($r['data']??null))throw new Fault('upstream_invalid','Insights inválidos.');
            foreach($r['data'] as $row){
                if(($row['name']??'')!==$metric)throw new Fault('upstream_invalid','Métrica divergente.');
                if(array_key_exists('total_value',$row))$out['rows'][]=['entity_id'=>$entity,'metric'=>$metric,'period'=>$row['period']??null,'value'=>$row['total_value']['value']??null,'breakdowns'=>$row['total_value']['breakdowns']??[],'end_time'=>null];
                elseif(isset($row['values'])&&is_array($row['values']))foreach($row['values'] as $v)$out['rows'][]=['entity_id'=>$entity,'metric'=>$metric,'period'=>$row['period']??null,'value'=>$v['value']??null,'end_time'=>$v['end_time']??null];
                else $out['errors'][]=['field'=>$metric,'code'=>'value_unavailable'];
            }
            if(!$r['data'])$out['errors'][]=['field'=>$metric,'code'=>'empty_or_suppressed'];
        }catch(Fault $e){if($e->reason!=='upstream_validation')throw $e;$out['errors'][]=['field'=>$metric,'code'=>'unsupported_for_asset_or_version','details'=>$e->details];}
        if($index+1<count($fields))$out['next']=['metric'=>$index+1];
        return $out;
    }
}
