# Bancada da 0.11.0

A rodada corrente usa `python3 tools/release011.py --manifest /insumos/manifest.json --work-base /laboratorios/011 --evidence /resultados/011 --php /runtime/php`. O manifesto segue a estrutura abaixo, com WordPress 7.1.2, PHP 8.3.6, Google base 0.10.0, MCP 0.23.0, Core 1.35.0 e sociais 0.2.0. Insumos são copiados para a bancada e conferidos por hash. WordPress usa arquivos de core recuperados localmente, sem wp-config, wp-content ou banco anterior; origem e hash são registrados. O script confere os mínimos exatos, compila documentação, instala o ZIP, executa os cenários selecionados e confere árvores finais, sem declarar execução PHPUnit. Relatório externo e evidence/011 são a autoridade dos resultados.

O procedimento abaixo e o gate completo de `tools/validate.py` pertencem à bancada abrangente da base 0.10.0, preservada para uso futuro. Os resultados históricos não certificam a nova versão.

# Bancada e liberação — Google 0.10.0

A bancada usa insumos declarados, instala o ZIP de produção em WordPress descartável e mantém os fontes separados. Não usa diretórios de outra sessão nem um WordPress já configurado. Não executar contra produção.

## Insumos

Copie `manifest.example.json` para um arquivo de configuração fora dos fontes. Ajuste somente caminhos e hashes nesse manifesto. Caminhos relativos são resolvidos a partir dele. Cada insumo tem SHA-256 e versão informativa:

- `runtime`: árvore Linux com `usr/bin/php8.3`, `usr/sbin/php-fpm8.3`, `usr/sbin/mysqld`, `usr/sbin/lighttpd`, módulos PHP em `usr/lib/php/20230831`, bibliotecas e módulos lighttpd. Referência: PHP 8.3.6/MySQL 8.0.46. Não acompanha o fonte.
- `testing`: árvore de PHPUnit 9.6.17 com `usr/bin/phpunit` e `usr/share/php`, ou ferramenta equivalente disponibilizada nessa estrutura. Os autoloaders devem usar caminhos relativos a `__DIR__` dentro dessa árvore; não embutir caminhos de sessão. Não acompanha o runtime de produção.
- `wordpress`: arquivo oficial tar.gz contendo `wordpress/`; referência 7.1.2. `wp_cli`: PHAR WP-CLI 2.12.0.
- `mcp` e `core`: instaladores finais 0.22.0 e 1.33.0; `baseline`: instalador Google 0.9.0; `baseline_mcp`/`baseline_core`: MCP 0.22.0/Core 1.33.0; `candidate`: ZIP criado da árvore corrente.

Para diretórios, o hash é o de `tree_hash()` em `tools/lab.py`: caminhos relativos ordenados, separador NUL e digest SHA-256 do conteúdo de cada arquivo. Para arquivos, use SHA-256 dos bytes. O manifesto de entrada efetivamente usado acompanha as evidências, sem credenciais. Esses hashes não viram regras no plugin instalado.

## Preparação e execução

```sh
php build/export-contracts.php
python3 build/compile-documents.py
python3 build/check-docs.py
python3 build/build.py candidate --output /candidatos/google-0.10.0.zip
# Atualizar candidate.sha256 no manifesto com o resultado acima.
python3 tools/validate.py --manifest /insumos/manifest.json --work-base /laboratorios/execucao --evidence /resultados/010
```

O validador executa a suíte, os cenários nativos limpos/atualização e uma segunda bancada independente executada em paralelo, inspeciona o pacote e testa recusas da liberação. Chamadas externas são bloqueadas, salvo respostas simuladas específicas. Nenhum login Google ou segredo de produção é utilizado.

Para depurar um cenário isolado:

```sh
python3 tools/lab.py --manifest /insumos/manifest.json --workdir /laboratorios/novo --order google-first tests/native/cold.php tests/native/clean.php
python3 tools/lab.py --manifest /insumos/manifest.json --workdir /laboratorios/atualizacao --origin upgrade tests/native/upgrade.php
```

Cada execução escolhe portas de loopback e um nome de banco exclusivo. O banco fica no datadir próprio; não recebe parâmetros de banco/site externo. Diretório não vazio é recusado. `--reset` só aceita o marcador de propriedade correspondente e recusa laboratório em execução. Não altere o marcador para reaproveitar um recurso alheio. Processos próprios são encerrados em `finally`; execuções concorrentes usam diretórios diferentes. Os ensaios de concorrência abrem processos dentro dessa bancada.

## Promoção

```sh
python3 build/build.py verify --candidate /candidatos/google-0.10.0.zip --evidence /resultados/010/validation.json --manifest /insumos/manifest.json
python3 build/build.py promote --candidate /candidatos/google-0.10.0.zip --evidence /resultados/010/validation.json --manifest /insumos/manifest.json --output /entrega/wp-mcp-google-fator3-0.10.0-instalador.zip
```

A promoção confere o candidato, inventário, identidade corrente, relatórios e insumos. Copia exatamente os bytes aprovados; não recompila. Evidência ausente/incompleta, mudança de runtime/teste/ferramenta/configuração ou relatório divergente impede a liberação. O arquivo de evidência não é uma defesa contra alguém autorizado a alterar o próprio código e seus controles.

Relatórios ficam fora do runtime. Arquivos de teste não incluem sua própria evidência na identidade, e o ZIP fonte não inclui o próprio hash. Alteração meramente editorial no relatório não exige repetir funcionalidade, mas exige novo empacotamento/hash do fonte. Alterar documentação embutida muda o candidato e requer nova conferência dos bytes.

Cada cenário declara somente os insumos que utiliza. `google-only` ignora acompanhantes; `clean` não exige bases. A validação de release completa exige todos os insumos do manifesto. `tests/native/` é o caminho estável; scripts fora dele são recusados. A expectativa numérica vem do manifesto, sem trava no runtime. As versões intermediárias não são instaladas.

`meta` e `linkedin` apontam aos instaladores reais 0.1.0, com SHA-256 conferido. A suíte release010 extrai esses pacotes somente no laboratório próprio, ativa-os e examina isolamento de opções, tabelas e cron. A atualização direta mantém os mesmos acompanhantes e testa sentinelas sociais. O site compartilhado usa o fluxo raw/hash pela frota; o upload base64 é exclusivo da bancada local descartável.
