# Validação — 0.11.0

Escopo: Pedido MCP Google 25; compatibilidade com MCP 0.23.0, Core 1.35.0 e Meta/LinkedIn 0.2.0. Instalação limpa e atualização direta Google 0.10.0 → 0.11.0 em WordPress 7.1.2/PHP 8.3.6/MySQL 8.0.46. Esses são os mínimos declarados do WordPress/PHP; versões inferiores não têm suporte declarado nesta release.

O laboratório cria banco novo por cenário, usa o instalador por allowlist e processos HTTP/PHP novos. Os ensaios incluem ajuda completa via MCP com SHA-256, autorização administrativa, resultado paginado, isolamento social, contratos Core e preservação de configurações/registros no upgrade e rollback. Nenhum ensaio usa credenciais Google reais. Fontes dos testes e instruções estão no ZIP fonte; o relatório externo informa resultados, contagens e limitações efetivamente observados.

Evidências da rodada estão em evidence/011. As árvores 010 e anteriores são históricas e não certificam o candidato atual. A validação 0.11.0 usa tools/release011.py para vincular o instalador, inventário instalado e provas selecionadas do escopo. O validador abrangente tools/validate.py e o gate legado de build/build.py continuam disponíveis com seus requisitos completos; não se afirma que esse gate ou a suíte PHPUnit inteira tenham sido executados nesta rodada.

Limites: APIs Google reais, coleta/completude em produção, exportação Sheets em destino real, navegador gráfico, multisite, caches distribuídos/CDN e cron externo não foram homologados nesta rodada. Não houve mudança visual. A candidata não é considerada publicada nem instalada na frota pelo resultado local. A descoberta automática de material aguarda novo contrato Core; o contrato 1.0.0 atual foi preservado. Relatórios dos acompanhantes são evidência recebida, distinguida dos testes próprios.
