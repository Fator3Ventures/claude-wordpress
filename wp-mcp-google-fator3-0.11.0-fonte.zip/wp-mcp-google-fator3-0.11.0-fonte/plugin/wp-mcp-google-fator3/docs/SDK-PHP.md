# SDK PHP Search Console — Fator3 MCP Google 0.11.0

Contrato congelado: `search-console-reader/1.0.0`. Sem endpoint HTTP novo. API para plugins PHP cooperantes no mesmo WordPress; não é isolamento contra PHP malicioso instalado.

## Registro e cliente

Hook `f3_mcp_google_register_consumers`, executado em `plugins_loaded` prioridade 30, fornece uma instância `ServiceApi` e o identificador completo do contrato. Registre o callback do hook no carregamento principal do consumidor; o callback de configuração deve tolerar tabelas ainda não preparadas, retornando `ready:false`.

```php
use Fator3\McpGoogle\Integration\ServiceApi;

add_action('f3_mcp_google_register_consumers', function ($registry, $contract) {
    $client = $registry->register_consumer(
        'meu-plugin', '1.0.0', $contract,
        static function (): array {
            // Implementado pelo consumidor: propriedade validada e revisão estável.
            return MinhaConfiguracao::searchConsole();
            // ['property'=>'sc-domain:example.test', 'revision'=>'rev-42', 'ready'=>true]
        }
    );
    if (!is_wp_error($client)) {
        MeuExecutor::usarGoogle($client);
    }
}, 10, 2);
```

`MinhaConfiguracao` e `MeuExecutor` são nomes ilustrativos, não classes do Core fornecido. Exemplo completo de teste em `tests/Release070Test.php`. `ServiceApi::capabilities():array` publica contrato, schema, limites e calendário. `register_consumer(string $id,string $version,string $contract,callable $configuration)` retorna `ConsumerClient|WP_Error`. ID estável em slug; versão semântica. Registro duplicado falha. Nesta release, somente o contrato exato 1.0.0 é aceito.

`ConsumerClient::query(array $input):array` e `ConsumerClient::status():array` permanecem. A extensão optativa `ConsumerClient::effective_status():array` é anunciada em `ServiceApi::capabilities().client_methods` desde a descoberta inicial. O objeto fica vinculado ao registro; instanciá-lo manualmente não concede identidade. A consulta não chama APIs internas Core, não altera usuário e não libera execução genérica. Ative o Google, GSC, credencial e política de recursos; autorize esse consumidor explicitamente em uma única conexão pelo painel ou `google/configure-consumer`.

## Uma página de um dia

```php
$result = $client->query([
    'contract_version' => '1.0.0',
    'property' => 'sc-domain:example.test',
    'consumer_revision' => 'rev-42',
    'date' => '2026-09-20',
    'limit' => 1000,
    'cursor' => null,
    'run_id' => 'core-20260920-001',
    'trigger' => 'cli',
    'budget_ms' => 15000,
]);
```

Propriedade e revisão devem coincidir exatamente com o callback atual. URL-prefix e `sc-domain` são aceitos; Google não repete a validação por `home_url`. `date` é um dia passado válido no calendário `America/Los_Angeles`. O consumidor decide D-3, repetição de dias finais e persistência. `trigger` aceita `cli`, `http_cron`, `manual`; é metadado informado pelo plugin confiável e não concede autorização. `run_id` aceita até 100 caracteres alfanuméricos, ponto, sublinhado, dois-pontos ou hífen.

`limit`: padrão 1.000, mínimo 1, máximo menor entre 5.000 e o teto configurado no Google. `budget_ms`: obrigatório, inteiro 1–20.000. Prazo monotônico compartilhado com o contexto pai, autorização, token e consulta; reserva 2.000 ms de retorno e exige ao menos 1.000 ms de despacho. Não aumenta orçamento baixo. Timeout HTTP é limitado pelo saldo recalculado; não há retry interno nessa chamada. PHP/banco/sistema operacional não oferecem cancelamento rígido de toda instrução local: a reserva protege retorno, não promete encerramento forçado do processo no milissegundo exato.

A consulta é fixa: Search Analytics, `dimensions:[date,page]`, `type:web`, `dataState:final`, `aggregationType:auto`, sem filtros. Não aceita URL de API, headers, escopos, credenciais, método, connection_id nem actor arbitrários. A concessão determina a conexão.

## Resultado e cobertura

Sucesso contém `success:true`, `contract_version`, `request_id`, `connection_id`, `property`, `consumer_revision`, `date`, `run_id`, `extracted_at` (Unix UTC), `rows`, `next_cursor`, `coverage`, `remote_dispatched`, `http_attempts`, `audit_success`. Linhas normalizadas: `date,page,clicks,impressions,ctr,position`. `http_attempts` inclui token e consulta efetivamente despachados. Os eventos compartilham o `request_id` superior.

`coverage` publica limite, número devolvido, `pagination_complete`, `truncated`, motivo, calendário, dimensões, tipo, agregação, filtros e `start_row`. Página cheia exige continuação: `page_pending`; ao alcançar o teto conhecido de 50.000 linhas/dia, `api_daily_row_limit` e sem cursor seguinte. Página vazia ou curta conclui somente a paginação observada. `all_rows_guaranteed:false` permanece sempre; não comprova totalidade estatística. Dados finais disponíveis e ausência de linhas não equivalem a zero para cada URL.

Cursor cifrado, validade 24h, vinculado a consumidor, conexão, propriedade, dia, limite, revisão, credencial/política e concessão. Mudanças invalidam continuação. Não representa snapshot remoto nem autorização. Somente avance o cursor durável depois do commit local das linhas. Em repetição, faça upsert; não some métricas repetidas. Preserve os hosts retornados e aplique a regra editorial no consumidor.

## Limites e erros

Orçamento local Search Analytics separado de URL Inspection: padrão 30 tentativas/minuto e 1.000/dia; configurável até 300 e 10.000. Janela móvel por identidade/propriedade/site, compartilhada por conexões, consumidores e consultas humanas dessa identidade. Cada tentativa reserva atomicamente, inclusive retries humanos; uma reserva seguida de recusa local pode consumir capacidade de forma conservadora. Não promete coordenar instalações distintas ou substituir quotas do Google.

Erros contêm `success:false`, `error_code`, `retryable`, `retry_after_ms`, `next_eligible_at` quando conhecido e `remote_dispatched`. Não interprete somente a mensagem.

| Código/família | Ação do consumidor |
|---|---|
| `f3_google_consumer_unregistered`, `*_unauthorized`, `*_connection` | Corrigir registro/concessão; não repetir sem mudança |
| `f3_google_consumer_contract`, `*_input`, `*_date` | Corrigir pedido |
| `f3_google_consumer_property`, `*_changed`, `*_cursor`, `f3_google_context_changed` | Reler configuração e reiniciar o dia com upsert |
| `f3_google_consumer_not_ready`, `f3_google_storage_unavailable` | Resolver prontidão/estrutura corrente; respeitar adiamento |
| `f3_google_disabled`, `f3_google_connector_off`, `f3_google_policy` | Rever configuração com administrador |
| `f3_google_analytics_budget_*`, `f3_google_deadline` | Respeitar `retry_after_ms`/`next_eligible_at` |
| HTTP 403/429, rede/credencial | Usar código/motivo estruturado; permissão e quota não são equivalentes |
| `f3_google_consumer_response` | Não persistir página malformada como vazia |
| `f3_google_audit_persistence` | Auditoria recusada antes de despacho; não avançar |
| `f3_google_audit_incomplete`, `f3_google_consumer_state` | Pode haver resposta remota; não avançar cursor; conferir `remote_dispatched` e `query_result` quando presente |
| `f3_google_recovery_*` | Aguardar recuperação explícita |

Permissão, revisão, política, concessão e credencial são revalidadas antes de cada saída HTTP e antes de aceitar o resultado. Tokens/chaves nunca são retornados ao consumidor. O fim do contexto ocorre em `finally`. Falhas locais não são convertidas em uma página vazia bem-sucedida.

## Diagnóstico optativo da conexão efetiva

O consumidor verifica o anúncio de `effective_status` e o método no cliente durante a descoberta inicial. Não suponha descoberta automática de capacidades acrescentadas depois. Para consumidores genéricos, método sem anúncio pode manter somente seu diagnóstico pela conexão corrente; isso não resolve a conexão efetiva. Anúncio sem método é inconsistência. O Core 1.33.0 exige anúncio e método desde a descoberta, sem fallback. O Google 0.11.0 anuncia ambos.

`status()` mantém a semântica histórica: conexão corrente, consumidor chamador, concessão e atendimento naquela conexão. `effective_status()` usa a mesma resolução de concessões de `query()`, restaurando a conexão corrente ao terminar. Não consulta o Google, renova token, concede acesso, avança cursor ou cria passagem cron.

| `resolution` | Resultado |
|---|---|
| `resolved` | Uma concessão habilitada; `connection_id` e `local_status` dessa conexão |
| `not_granted` | Nenhuma concessão habilitada; conexão e estado local nulos |
| `ambiguous` | Mais de uma concessão habilitada; conexão e estado local nulos |
| `unreadable` | Registro de conexões ou concessão ilegível; não afirmar unicidade |

O retorno contém `contract`, `consumer_id`, `resolution`, `connection_id`, `reason_codes`, `local_status` e `checked_at`. Cliente não registrado recebe erro. A projeção local permite somente configuração do próprio consumidor, concessão reduzida, pausa de recuperação, Google/GSC habilitados, credencial configurada, política permitida e último atendimento sanitizado. `configuration_error` e `last_service_error` distinguem ausência de falha de leitura. Objetos arbitrários, snapshots internos, segredos e concessões alheias não são propagados.

Uma conexão resolvida pode continuar bloqueada por configuração, credencial, serviço, política, estrutura ou recuperação. `remote_access_verified:false` e `consumer_commit_verified:false` impedem interpretar prontidão local ou atendimento como prova de acesso/commit. A consulta revalida os controles; diagnóstico não é autorização reutilizável.

## Concessão administrativa em duas chamadas

1. `google/integration-status {"connection_id":"analytics","compact":true}`.
2. `google/configure-consumer {"connection_id":"analytics","consumer_id":"base-site-core-fator3","enabled":true,"expected_revision":"<configuration_revision da primeira resposta>"}`.

`configuration_revision` é a mesma de `Settings::revision()` e pertence à conexão selecionada, mesmo quando o consumidor efetivo usa outra conexão. Em falha, `success:false`, `read_success:false` e revisão nula; não use revisão anterior. Conflito de revisão exige nova leitura. `compact:false` preserva o status completo e acrescenta a revisão. O limite de 8.192 bytes das duas respostas é exercitado com um consumidor e fixtures padrão/não padrão; não é teto universal de qualquer instalação.

## Integração desta entrega

A matriz corrente usa Core 1.35.0, MCP 0.23.0 e Google 0.11.0; APIs remotas são simuladas. O diagnóstico verifica contratos/capacidades e registro, sem filtro numérico de versão. Ensaios e limites constam em [VALIDACAO.md](VALIDACAO.md).

A configuração Core 7.1.0 é independente da configuração Google 4.0.0. Registro, concessão, prontidão, consulta remota e commit Core são etapas separadas. SDK sem concessão retorna `not_granted`; status local não prova acesso ao Google. O `google/selftest` incompleto com sucesso diagnóstico não concede acesso ao consumidor.

Guias atuais usam a chave `documentacao` e `f3base/documentacao-ler`. Recuperação usa `manter_pausado:true`, nova requisição e preparo/drenagem, conforme [MIGRACAO.md](MIGRACAO.md). O Google não altera tabelas, checkpoint ou guardas privados Core.

## Referência 0.11.0

Matriz: Core 1.33.0 e MCP 0.22.0. O contrato do leitor permanece 1.0.0; consulta SDK não fabrica passagem cron e revalida concessões. Cessão do executor não substitui um resultado GSC. Consulte ACOMPANHAMENTO-CRON.md para os diagnóstico de cron atual e histórico.

A 0.11.0 não consulta checkpoints de transição do importador antigo e não publica `local_status.transition`. As operações, resolução de conexão, concessão explícita e semântica do SDK 1.0.0 consumidas pelo Core permanecem.


A 0.11.0 também consome o contexto público de medição Core 1.33.0 (configuração Core 7.1.0) e os contratos MCP 0.22.0 descritos em [CONTRATOS-PUBLICOS.md](CONTRATOS-PUBLICOS.md). Esses contratos não alteram o leitor editorial GSC 1.0.0.
