# Receitas das capacidades existentes — 0.11.0

- Descobrir a conexão: `google/status` e `google/configuration-schema`; configurar somente as opções necessárias, conferir revisão e testar recursos explicitamente.
- Descobrir relatórios GA4: `google/list-accounts`, `google/list-fields` com a propriedade, depois `google/query`. O catálogo dinâmico não tem contagem universal de dimensões/métricas.
- Relatórios nativos, inclusive coortes: consultar `google/list-actions` e o schema do método; usar `google/execute-read` para métodos classificados como leitura. Os endpoints GA/GSC específicos continuam disponíveis.
- Preparar perfil GA4 genérico: fornecer o perfil desejado a `ga/aplicar-perfil`, simular, revisar diff e aplicar com as confirmações exigidas. A operação não cria uma propriedade.
- GSC: `gsc/preparar-site`, `gsc/migracao-conferir`, inspeção e acompanhamento de sitemap mantêm seus contratos. Confirmação de envio não significa processamento ou indexação.
- Agendar leituras: criar explicitamente job/agenda, acompanhar estado e cron. `google/executar-vencidos` e `wp mcp-google run-due` não exigem tráfego público; a instalação de crontab externo continua responsabilidade operacional.
- Exportar: revisar [ANALYTICS.md](ANALYTICS.md), especialmente completude, confirmação de append, recibos de escrita e limites de verificação.

Não foram criados aliases Porter ou atalhos nominais para essas sequências. Os nomes/schema efetivos estão no catálogo gerado; receitas não substituem autorização por serviço e recurso.

## Core 1.35.0: contato e material (Pedido Core 222)

O SDK site-measurement-context/1.0.0 mantém seis slots e enumeração fechada. O slot google_ads.conversion_label refere-se a contato; não representa material. O Core 1.35.0 emite download_material por seus emissores, mas não o anuncia neste SDK. Sua configuração de material está no contrato administrativo Core 8.1.0.

Uma receita de material deve usar explicitamente download_material e identificadores próprios por finalidade. Não convertê-lo em generate_lead, nem reaproveitar o label de contato. Consultas GA4 por eventName podem usar download_material explicitamente; o catálogo incompleto não significa ausência do evento no fornecedor. A criação de evento-chave, ação Ads ou publicação GTM é decisão explícita do dono, com os gates existentes. O Google não infere nem cria essas ações ao ler contexto.

A descoberta completa aguarda contrato optativo/versionado do Core e teste coordenado. A proposta está no impacto da entrega, fora do manual de capacidades disponíveis. Os schemas 1.0.0 permanecem intactos.
