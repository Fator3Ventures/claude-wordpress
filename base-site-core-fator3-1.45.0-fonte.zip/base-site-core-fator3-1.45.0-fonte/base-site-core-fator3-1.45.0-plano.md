# Plano — Fator3 Site Core 1.45.0

21/10/2026. Base publicada 1.44.0, instalador SHA-256 91c4695ad4585965276c6b8cabc9ab8a91bbffc4423968f00d2330f6edf1407e. Planejamento original preservado; implementação encerrada no relatório 1.45.0. Escopo: Pedidos core 264–270, 272 e 273, conforme Fator3 Site Core(20261021-172554).md.

1. Preservar prova de logs completos e ler gzip íntegro; separar ausência inicial de retirada posterior.
2. Caminho editorial canônico para IA; regra versionada para toda identidade fora de faixas oficiais.
3. Erros Clarity saneados com limite de 1 KB e Retry-After, leitura administrativa.
4. Automação provável por sinais combinados de nuvem/navegador antigo/ausência de interação e recorrência; diagnóstico de falhas do endpoint analise; alerta de dois dias sem consumo.
5. Mapeamentos Pipedrive coerentes com o consumidor e eliminação remota com prova sem atualização indireta, incluindo organização exclusiva.
6. Retenção mensal 1–120, padrão 60, operações 6; migração explícita sem encurtar janelas existentes; exceções do pedido preservadas e qualidade Meta limitada a 7 dias.
7. Telefone livre opcional por campo, preservação do valor e classificação; sem WhatsApp/busca Pipedrive para não normalizado; tarefa Conferir contato sem e-mail válido; marca nos diários, mantendo conversões.

Provas: WordPress descartável, navegador nos controles afetados, migração 1.44.0→1.45.0 e instalação limpa, documentação via canal e atualização no Site-Teste. Fornecedores simulados nos testes locais. Não ativar formato livre em ctooffice, alterar retenções da frota para 60, publicar no GitHub nem disparar conversões comerciais nesta rodada. Aceites de sete dias e contas reais ficam separados.

Fronteiras iniciais: MCP 0.25.0, Google 0.16.0, Meta/LinkedIn 0.4.1 disponíveis. Nenhuma alteração planejada nos contratos deles. Migração de configuração Core deve manter entradas legadas por adaptação explícita para consumidores; avaliar o Implantador antes de fechar novos nomes de retenção e emitir impacto se exigir adaptação de seus lotes.

Encaminhamento necessário, revisão de entrega: base-site-core-fator3-1.45.0-impacto-implantador-base.md.
