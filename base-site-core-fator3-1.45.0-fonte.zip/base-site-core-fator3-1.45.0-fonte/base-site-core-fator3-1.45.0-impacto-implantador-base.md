# Impacto de Fator3 Site Core 1.45.0 em implantador-base

Revisão 2 · entrega · aberto para o destinatário · acao-necessaria.

Emissor base-site-core-fator3, base 1.44.0, alvo 1.45.0 entregue. Instalador base-site-core-fator3-1.45.0-instalador.zip, 2152375 bytes, SHA-256 `91620d8baadfd42911d624880838879501c722d20d37ecd734213541f920dc06`. Destinatário: implantador-base 2.10.0, identificado no impacto recebido de 19/10/2026, revisão 2, instalador SHA-256 `61a1883f20aa9560c926b16339b29f991cd2d1109812067855522717aa9e19e4`. Código do Implantador não examinado nesta rodada.

## Contrato real — pedidos 272 e 273

O Core publica configuração 8.10.0. Use schema descoberto, revisão esperada, simulação e releitura. Chaves mensais: comportamento.retencao_meses e retencao_eventos_meses; acessos.retencao_horaria_meses; pipedrive.retencao_entregas_meses; formulario_tentativas.retencao_meses. Contatos, acessos gerais, editorial e Clarity mantêm a chave mensal existente. Faixa 1–120; padrão novo 60; grupo f3base_retencoes_tecnicas acrescenta prazos de avisos, CAPI, recusas, 404, sondas, diagnóstico e operações (seis meses). Qualidade Meta permanece fixa em sete dias; demais exceções constam em RETENCAO-1.45.md.

A atualização do Core converte os valores gravados em dias sem reduzir a janela no instante da troca, registra a migração e preserva autoria. Clarity 0 vira 120. O Implantador deve adaptar lotes antigos às novas chaves; não tratar numerais antigos em dias como meses nem reaplicar os padrões antigos sobre valores convertidos. A aplicação de 60 meses aos sites existentes é tarefa explícita da frota. Perfis históricos distribuídos com valores em dias não substituem a política mensal nova.

Campo de tipo tel e papel telefone aceita formato_livre:boolean, false por padrão. Core renderiza data-formato-livre=1, valida a opção pela definição no servidor, guarda valor/normalização e continua dono de captura, token, continuação e persistência. Não ativar automaticamente em formulários existentes; contato-whatsapp de ctooffice aguarda decisão 111. Nova opção do Core f3base_converter_contato_sem_identificador vem true; o Implantador não deve mudá-la implicitamente.

O impacto recebido informa seis cópias compartilhadas, mas não enumera seus caminhos. Confira as seis no seu manifesto e sincronize as correspondentes afetadas. Estes arquivos efetivamente alterados nesta rodada são referências conferíveis; a lista não inventa os caminhos internos do Implantador:

| Arquivo no Core | SHA-256 |
|---|---|
| includes/class-f3base-formularios.php | 3ab908c4ad33c1f41cfa40c5d975e5313a9ca529bf89c477803d4d07ae3aa9e6 |
| assets/f3base-formularios.js | b0696d78c6c2a86f58c1cba2389943eddaeab10c00f724aebd5d5d8ee8066231 |
| assets/f3base-formularios.min.js | adfb4a2b5f57f283a6ac12fc08f1e7ae861c932e05c155d2e572576a37a56e58 |
| assets/f3base-formularios-editor.js | b21d49ce575adbd8332e8f7278e5bd5ef927b21d655e77f4c10228593b646208 |

## Provas e aceite do destinatário

Core: instalação nova e atualização direta 1.44→1.45 pelo instalador final; editor de campo e bundle minificado em Chromium; WordPress real no Site-Teste aceitou telefone sem DDD, preservou valor e sem_ddd, e recusou com opção desligada. Os formulários temporários foram removidos. Não houve homologação do fallback do Implantador nem atualização do seu código.

Responsável Implantador: conferir cópias; testar schema mensal, preservação de escolhas, CAS, formulário na página/diálogo e opção livre ligada/desligada. Core presente deve manter sua implementação como dona, sem dois coletores. Responsável frota: validar instalação coordenada e aplicar os prazos deliberados depois da migração. Encerrar o impacto somente após essas provas.

Histórico: revisão 1 emitida no planejamento, antes da implementação, com contrato proposto e alvo sem pacote. Revisão 2 registra contrato real, hashes e prova própria. Documento preparado para o dono; não enviado a terceiros.
