<?php
$_SERVER['HTTP_HOST']='127.0.0.1:8134';require getenv('F3BASE_SITE');wp_set_current_user(1);
if(wp_get_environment_type()!=='local'||DB_HOST!=='127.0.0.1:33436'||DB_NAME!=='core1450'){throw new RuntimeException('Disposable local database required');}
set_exception_handler(static function($e){fwrite(STDERR,$e->getMessage()."\n".$e->getTraceAsString()."\n");exit(1);});
$checks=array();function check($ok,string $name): void {global $checks;$checks[$name]=(bool)$ok;if(!$ok){throw new RuntimeException('FAIL '.$name);}}
function evidence(string $name): void {global $checks;$r=array('versao'=>F3BASE_PLUGIN_VERSAO,'ambiente'=>'WordPress nativo descartável; provedores simulados','checks'=>$checks);file_put_contents(getenv('F3BASE_ROOT').'/evidence/'.$name.'.json',wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo $name.': '.count($checks)." checks OK\n";}
function raw(string $name,$v): void {global $wpdb;$row=$wpdb->get_var($wpdb->prepare('SELECT option_id FROM %i WHERE option_name=%s',$wpdb->options,$name));$data=array('option_value'=>maybe_serialize($v));if($row){$wpdb->update($wpdb->options,$data,array('option_name'=>$name));}else{$wpdb->insert($wpdb->options,$data+array('option_name'=>$name,'autoload'=>'no'));}wp_cache_delete($name,'options');wp_cache_delete('alloptions','options');wp_cache_delete('notoptions','options');}
function save(string $n,$v): array {return F3Base_Options::pelo_canal('ability',static fn()=>F3Base_Options::gravar($n,$v,F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao($n)));}
