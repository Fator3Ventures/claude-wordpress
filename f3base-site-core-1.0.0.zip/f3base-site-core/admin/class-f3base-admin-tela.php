<?php
/**
 * Tela do wp-admin do F3 Base Site Core.
 *
 * PARA QUEM ESTA TELA É ESCRITA. Para quem opera o site — a pessoa que precisa
 * ligar o WhatsApp, conectar a conta de anúncio, decidir o prazo de guarda e
 * saber se alguém está lendo as páginas. Até a 1.1.3 ela era escrita para quem
 * construiu o pacote: abria falando em registro único de módulos, apresentava
 * as chaves na ordem em que elas foram escritas no catálogo, e mostrava o
 * diagnóstico antes dos campos. Quem chegava para preencher um número lia
 * primeiro um relatório de estado interno.
 *
 * O QUE MUDOU, e por quê:
 *
 * 1. **Primeiro o que se preenche, depois o que se observa.** Os campos vêm
 *    antes; o quadro de comportamento e o diagnóstico dos módulos vêm depois.
 * 2. **Agrupado por assunto, na ordem de instalação de um site:** contato,
 *    medição e anúncios, consentimento, privacidade e retenção. A ordem é
 *    declarada em `F3Base_Options::secoes_da_tela()`, num lugar só, porque ela
 *    é conferida no DOM.
 * 3. **Cada campo diz o IMPACTO e traz um EXEMPLO.** Rótulo é o nome do campo;
 *    descrição é a definição dele. Nenhum dos dois responde à única pergunta de
 *    quem está com o cursor no campo: o que muda no site se eu preencher isto,
 *    e o que acontece enquanto está vazio.
 * 4. **O exemplo NUNCA entra no campo.** Nem em `value`, nem em `placeholder`:
 *    exemplo em placeholder é valor fantasma — o operador o lê como se
 *    estivesse gravado, sai da tela achando que configurou, e a conta continua
 *    sem receber nada.
 * 5. **O diagnóstico continua inteiro.** Módulos, estados, motivos, avisos,
 *    dependências, hooks e options: nada saiu. Ele é o que o suporte e o agente
 *    leem, e é o que responde "por que isto não está funcionando". Só deixou de
 *    ser a primeira coisa que aparece.
 *
 * O QUE NÃO MUDOU, porque é o que garante a verdade da tela: ela continua sendo
 * renderizada a partir do registro único de módulos e do catálogo de options —
 * nunca de lista escrita à mão —, a gravação continua exigindo `manage_options`
 * e nonce, e o valor gravado continua sendo RELIDO do banco e mostrado.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Página de administração do site-core.
 */
final class F3Base_Admin_Tela {

	/**
	 * Slug da página.
	 */
	public const SLUG = 'f3base-site-core';

	/**
	 * Ação do formulário.
	 */
	public const ACAO = 'f3base_salvar';

	/**
	 * Nonce do formulário.
	 */
	public const NONCE = 'f3base_salvar_options';

	/**
	 * Blocos de OBSERVAÇÃO da tela, depois dos blocos de preenchimento.
	 */
	public const BLOCO_COMPORTAMENTO = 'comportamento';
	public const BLOCO_DIAGNOSTICO   = 'diagnostico';

	/**
	 * A ORDEM DOS BLOCOS DA TELA, declarada num lugar só.
	 *
	 * Os blocos de preenchimento saem de `F3Base_Options::secoes_da_tela()`, na
	 * ordem declarada lá; os dois de observação vêm depois, nesta ordem. Esta
	 * função é a fonte que a tela renderiza E que a bancada mede no DOM: duas
	 * listas seriam duas ordens, e a segunda envelheceria calada.
	 *
	 * @return string[]
	 */
	public static function ordem_dos_blocos(): array {
		return array_merge(
			array_keys( F3Base_Options::secoes_da_tela() ),
			array( self::BLOCO_COMPORTAMENTO, self::BLOCO_DIAGNOSTICO )
		);
	}

	/**
	 * Liga a tela.
	 *
	 * @return void
	 */
	public static function iniciar(): void {
		add_action( 'admin_menu', array( __CLASS__, 'registrar_menu' ) );
		add_action( 'admin_post_' . self::ACAO, array( __CLASS__, 'salvar' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enfileirar' ) );
	}

	/**
	 * Registra o menu.
	 *
	 * @return void
	 */
	public static function registrar_menu(): void {
		add_menu_page(
			__( 'F3 Base Site Core', 'f3base' ),
			__( 'F3 Base', 'f3base' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-shield-alt',
			58
		);
	}

	/**
	 * Enfileira o estilo da tela.
	 *
	 * @param string $tela Hook da tela atual.
	 * @return void
	 */
	public static function enfileirar( string $tela ): void {
		if ( 'toplevel_page_' . self::SLUG !== $tela ) {
			return;
		}

		wp_enqueue_style(
			'f3base-admin',
			F3BASE_SITE_CORE_URL . 'admin/assets/f3base-admin.css',
			array(),
			F3BASE_SITE_CORE_VERSAO
		);
	}

	/**
	 * Trata o envio do formulário.
	 *
	 * @return void
	 */
	public static function salvar(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão para editar as options do site-core.', 'f3base' ), 403 );
		}

		check_admin_referer( self::NONCE );

		$enviado = isset( $_POST['f3base'] ) && is_array( $_POST['f3base'] )
			? map_deep( wp_unslash( $_POST['f3base'] ), 'sanitize_textarea_field' )
			: array();

		$leituras = array();

		foreach ( F3Base_Options::catalogo() as $nome => $declaracao ) {
			if ( ! F3Base_Options::operavel( $nome ) ) {
				continue;
			}

			if ( ! array_key_exists( $nome, $enviado ) ) {
				continue;
			}

			$valor = self::preparar( $nome, $declaracao, $enviado[ $nome ] );

			$resultado = F3Base_Options::gravar( $nome, $valor, F3Base_Options::ORIGEM_MANUAL );

			$leituras[] = array(
				'nome'   => $nome,
				'rotulo' => (string) $declaracao['rotulo'],
				'ok'     => (bool) $resultado['ok'],
				'motivo' => (string) $resultado['motivo'],
				'lido'   => self::resumir( $resultado['lido'] ),
			);
		}

		set_transient( 'f3base_leitura_de_volta_' . get_current_user_id(), $leituras, 5 * MINUTE_IN_SECONDS );

		wp_safe_redirect( add_query_arg( array( 'page' => self::SLUG, 'f3base-salvo' => '1' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Renderiza a tela.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão para ver a tela do site-core.', 'f3base' ), 403 );
		}

		$relatorio = F3Base_Registro::relatorio();

		echo '<div class="wrap f3base-tela">';

		printf(
			'<h1>%s <span class="f3base-versao">%s</span></h1>',
			esc_html__( 'F3 Base Site Core', 'f3base' ),
			esc_html( (string) $relatorio['plugin']['versao'] )
		);

		printf(
			'<p class="f3base-intro">%s</p>',
			esc_html__( 'Configuração do site: por onde as pessoas falam com você, quais contas recebem o que acontece nas páginas, o que o visitante pode recusar e por quanto tempo os dados ficam guardados. Cada campo abaixo diz o que muda no site quando você o preenche, e o que acontece enquanto ele está vazio. Depois dos campos vêm as duas leituras: o que as páginas registraram e o estado de cada parte do plugin.', 'f3base' )
		);

		self::render_leitura_de_volta();
		self::render_formulario();
		self::render_comportamento();
		self::render_diagnostico( $relatorio );

		echo '</div>';
	}

	/* ------------------------------------------------------------------ *
	 * Leitura de volta
	 * ------------------------------------------------------------------ */

	/**
	 * Leitura de volta da última gravação.
	 *
	 * @return void
	 */
	private static function render_leitura_de_volta(): void {
		$chave    = 'f3base_leitura_de_volta_' . get_current_user_id();
		$leituras = get_transient( $chave );

		if ( ! is_array( $leituras ) || array() === $leituras ) {
			return;
		}

		delete_transient( $chave );

		echo '<div class="f3base-leitura notice notice-info"><p><strong>' . esc_html__( 'O que ficou gravado', 'f3base' ) . '</strong> ' . esc_html__( 'Cada valor abaixo foi lido de volta do banco depois de gravado — é o que o site tem agora, não o que o formulário enviou.', 'f3base' ) . '</p><ul>';

		foreach ( $leituras as $leitura ) {
			if ( ! is_array( $leitura ) ) {
				continue;
			}

			printf(
				'<li class="%1$s"><strong>%2$s</strong> — %3$s: <code>%4$s</code>%5$s <span class="description">%6$s</span></li>',
				esc_attr( ! empty( $leitura['ok'] ) ? 'f3base-ok' : 'f3base-falha' ),
				esc_html( (string) $leitura['rotulo'] ),
				esc_html( ! empty( $leitura['ok'] ) ? __( 'gravado e conferido', 'f3base' ) : __( 'o valor lido de volta não é o valor gravado', 'f3base' ) ),
				esc_html( (string) $leitura['lido'] ),
				'' !== (string) $leitura['motivo'] ? ' — ' . esc_html( (string) $leitura['motivo'] ) : '',
				esc_html( (string) $leitura['nome'] )
			);
		}

		echo '</ul></div>';
	}

	/* ------------------------------------------------------------------ *
	 * Formulário, agrupado por assunto
	 * ------------------------------------------------------------------ */

	/**
	 * O formulário inteiro, um bloco por seção declarada.
	 *
	 * @return void
	 */
	private static function render_formulario(): void {
		$secoes    = F3Base_Options::secoes_da_tela();
		$por_secao = array();

		foreach ( F3Base_Options::catalogo() as $nome => $declaracao ) {
			if ( ! F3Base_Options::operavel( (string) $nome ) ) {
				continue;
			}

			$secao = isset( $declaracao['secao'] ) ? (string) $declaracao['secao'] : '';

			if ( ! isset( $secoes[ $secao ] ) ) {
				continue;
			}

			$por_secao[ $secao ][ (string) $nome ] = $declaracao;
		}

		if ( array() === $por_secao ) {
			printf(
				'<p>%s</p>',
				esc_html__( 'Nenhum campo foi liberado para edição neste projeto. Quem opera o site é o agente de manutenção, pelo canal.', 'f3base' )
			);

			return;
		}

		printf(
			'<form method="post" action="%s" class="f3base-form">',
			esc_url( admin_url( 'admin-post.php' ) )
		);

		printf( '<input type="hidden" name="action" value="%s" />', esc_attr( self::ACAO ) );
		wp_nonce_field( self::NONCE );

		foreach ( $secoes as $secao => $cabecalho ) {
			if ( ! isset( $por_secao[ $secao ] ) ) {
				continue;
			}

			printf(
				'<section class="f3base-bloco f3base-bloco--%1$s" data-f3base-bloco="%1$s"><h2>%2$s</h2><p class="f3base-bloco-resumo">%3$s</p>',
				esc_attr( (string) $secao ),
				esc_html( (string) $cabecalho['titulo'] ),
				esc_html( (string) $cabecalho['resumo'] )
			);

			echo '<table class="form-table" role="presentation"><tbody>';

			foreach ( $por_secao[ $secao ] as $nome => $declaracao ) {
				self::render_campo( (string) $nome, $declaracao );
			}

			echo '</tbody></table></section>';
		}

		submit_button( __( 'Gravar e conferir', 'f3base' ) );

		echo '</form>';
	}

	/**
	 * Campo de uma option operável.
	 *
	 * @param string              $nome       Nome da option.
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @return void
	 */
	private static function render_campo( string $nome, array $declaracao ): void {
		$valor  = F3Base_Options::ler( $nome );
		$origem = F3Base_Options::proveniencia( $nome );
		$grupo  = isset( $declaracao['subcampos'] ) && is_array( $declaracao['subcampos'] ) && array() !== $declaracao['subcampos'];

		echo '<tr>';
		printf(
			'<th scope="row">%1$s<span class="f3base-origem">%2$s</span></th>',
			$grupo
				? '<span class="f3base-rotulo">' . esc_html( (string) $declaracao['rotulo'] ) . '</span>'
				: '<label class="f3base-rotulo" for="' . esc_attr( 'f3base-' . $nome ) . '">' . esc_html( (string) $declaracao['rotulo'] ) . '</label>',
			esc_html(
				sprintf(
					/* translators: %s: origem da última gravação. */
					__( 'última gravação: %s', 'f3base' ),
					F3Base_Options::rotulo_origem( $origem )
				)
			)
		);

		echo '<td>';

		if ( isset( $declaracao['descricao'] ) && '' !== (string) $declaracao['descricao'] ) {
			printf( '<p class="f3base-assunto">%s</p>', esc_html( (string) $declaracao['descricao'] ) );
		}

		if ( $grupo ) {
			echo '<fieldset class="f3base-grupo">';

			foreach ( $declaracao['subcampos'] as $chave => $sub ) {
				$atual = is_array( $valor ) && array_key_exists( (string) $chave, $valor ) ? $valor[ (string) $chave ] : '';
				self::render_subcampo( $nome, (string) $chave, is_array( $sub ) ? $sub : array(), $atual );
			}

			echo '</fieldset>';
		} else {
			printf( '<div class="f3base-campo" data-f3base-campo="%s">', esc_attr( $nome ) );

			$campo = (string) $declaracao['campo'];

			if ( 'inteiro' === $campo ) {
				printf(
					'<input type="number" min="0" step="1" class="small-text" id="%1$s" name="f3base[%2$s]" value="%3$s" />',
					esc_attr( 'f3base-' . $nome ),
					esc_attr( $nome ),
					esc_attr( (string) ( is_scalar( $valor ) ? $valor : '' ) )
				);
			} else {
				printf(
					'<input type="text" class="regular-text" id="%1$s" name="f3base[%2$s]" value="%3$s" />',
					esc_attr( 'f3base-' . $nome ),
					esc_attr( $nome ),
					esc_attr( (string) ( is_scalar( $valor ) ? $valor : '' ) )
				);
			}

			self::render_impacto_e_exemplo( $nome, $declaracao );

			echo '</div>';
		}

		printf(
			'<p class="description f3base-referencia">%s <code>%s</code></p>',
			esc_html__( 'Nome técnico deste ajuste, para quem opera o site pelo canal de manutenção:', 'f3base' ),
			esc_html( $nome )
		);

		echo '</td></tr>';
	}

	/**
	 * Sub-campo de uma option em grupo.
	 *
	 * @param string              $option Nome da option.
	 * @param string              $chave  Chave dentro do grupo.
	 * @param array<string,mixed> $sub    Declaração do sub-campo.
	 * @param mixed               $atual  Valor atual.
	 * @return void
	 */
	private static function render_subcampo( string $option, string $chave, array $sub, $atual ): void {
		$id     = 'f3base-' . $option . '-' . $chave;
		$name   = 'f3base[' . $option . '][' . $chave . ']';
		$tipo   = isset( $sub['tipo'] ) ? (string) $sub['tipo'] : 'texto';
		$rotulo = isset( $sub['rotulo'] ) ? (string) $sub['rotulo'] : $chave;

		printf( '<div class="f3base-campo f3base-subcampo" data-f3base-campo="%s">', esc_attr( $option . '.' . $chave ) );

		if ( 'booleano' === $tipo ) {
			printf( '<input type="hidden" name="%s" value="0" />', esc_attr( $name ) );
			printf(
				'<p><label class="f3base-rotulo" for="%1$s"><input type="checkbox" id="%1$s" name="%2$s" value="1" %3$s /> %4$s</label></p>',
				esc_attr( $id ),
				esc_attr( $name ),
				checked( (bool) $atual, true, false ),
				esc_html( $rotulo )
			);
		} elseif ( 'enum' === $tipo ) {
			$opcoes = isset( $sub['opcoes'] ) && is_array( $sub['opcoes'] ) ? $sub['opcoes'] : array();

			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label> ', esc_attr( $id ), esc_html( $rotulo ) );
			printf( '<select id="%1$s" name="%2$s">', esc_attr( $id ), esc_attr( $name ) );

			foreach ( $opcoes as $chave_opcao => $rotulo_opcao ) {
				printf(
					'<option value="%1$s" %2$s>%3$s</option>',
					esc_attr( (string) $chave_opcao ),
					selected( (string) $atual, (string) $chave_opcao, false ),
					esc_html( (string) $rotulo_opcao )
				);
			}

			echo '</select></p>';
		} elseif ( 'inteiro' === $tipo ) {
			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label> ', esc_attr( $id ), esc_html( $rotulo ) );
			printf(
				'<input type="number" min="0" step="1" class="small-text" id="%1$s" name="%2$s" value="%3$s" /></p>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) ( is_scalar( $atual ) ? $atual : '' ) )
			);
		} elseif ( 'lista' === $tipo ) {
			/*
			 * LISTA DE NOMES numa linha, separados por vírgula. O campo é de
			 * texto porque é assim que ele é editável sem JavaScript, e o
			 * sanitizador aceita as duas formas — a linha da tela e a lista da
			 * configuração —, para que a mesma chave possa vir dos dois lados.
			 */
			$itens = is_array( $atual ) ? array_map( 'strval', $atual ) : array();

			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label> ', esc_attr( $id ), esc_html( $rotulo ) );
			printf(
				'<input type="text" class="regular-text" id="%1$s" name="%2$s" value="%3$s" /></p>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( implode( ', ', $itens ) )
			);
		} elseif ( 'textarea' === $tipo ) {
			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label></p>', esc_attr( $id ), esc_html( $rotulo ) );
			printf(
				'<textarea id="%1$s" name="%2$s" rows="3" class="large-text">%3$s</textarea>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_textarea( (string) ( is_scalar( $atual ) ? $atual : '' ) )
			);
		} else {
			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label> ', esc_attr( $id ), esc_html( $rotulo ) );
			printf(
				'<input type="%1$s" class="regular-text" id="%2$s" name="%3$s" value="%4$s" /></p>',
				esc_attr( 'email' === $tipo ? 'email' : 'text' ),
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) ( is_scalar( $atual ) ? $atual : '' ) )
			);
		}

		self::render_impacto_e_exemplo( $option, $sub );

		echo '</div>';
	}

	/**
	 * O IMPACTO e o EXEMPLO de uma folha, e o exemplo nunca entra no campo.
	 *
	 * O exemplo sai em elemento próprio, com marca própria, DEPOIS do controle
	 * — nunca em `value` e nunca em `placeholder`. Placeholder some quando o
	 * operador digita, reaparece quando ele apaga, e é lido como conteúdo do
	 * campo por leitor de tela e por quem tem pressa: é a forma mais barata de
	 * fazer alguém sair da tela convencido de que gravou o que não gravou.
	 *
	 * SEGREDO NÃO TEM EXEMPLO DE VALOR, e a marca diz isso em vez de fingir:
	 * onde os outros campos trazem "Exemplo", o token traz "Onde obter". A
	 * lista de segredos sai da âncora do próprio plugin.
	 *
	 * @param string              $option Option a que a folha pertence.
	 * @param array<string,mixed> $campo  Declaração da folha.
	 * @return void
	 */
	private static function render_impacto_e_exemplo( string $option, array $campo ): void {
		$impacto = isset( $campo['impacto'] ) ? (string) $campo['impacto'] : '';
		$exemplo = isset( $campo['exemplo'] ) ? (string) $campo['exemplo'] : '';

		if ( '' !== $impacto ) {
			printf( '<p class="f3base-impacto">%s</p>', esc_html( $impacto ) );
		}

		if ( '' === $exemplo ) {
			return;
		}

		$segredo = in_array( $option, F3Base_Options::segredos_do_site(), true );

		printf(
			'<p class="f3base-exemplo"><span class="f3base-exemplo-marca">%1$s</span> <span class="f3base-exemplo-texto">%2$s</span></p>',
			esc_html( $segredo ? __( 'Onde obter', 'f3base' ) : __( 'Exemplo', 'f3base' ) ),
			esc_html( $exemplo )
		);
	}

	/* ------------------------------------------------------------------ *
	 * O que as páginas registraram
	 * ------------------------------------------------------------------ */

	/**
	 * O quadro de comportamento — e o que ele NÃO é.
	 *
	 * @return void
	 */
	private static function render_comportamento(): void {
		printf(
			'<section class="f3base-bloco f3base-bloco--%1$s" data-f3base-bloco="%1$s"><h2>%2$s</h2>',
			esc_attr( self::BLOCO_COMPORTAMENTO ),
			esc_html__( 'O que as páginas registraram', 'f3base' )
		);

		if ( ! class_exists( 'F3Base_Modulo_Comportamento' ) ) {
			printf(
				'<p class="f3base-bloco-resumo">%s</p></section>',
				esc_html__( 'O resumo de comportamento não está disponível nesta instalação.', 'f3base' )
			);

			return;
		}

		$ligado = F3Base_Modulo_Comportamento::ligado();
		$resumo = F3Base_Modulo_Comportamento::resumo();

		printf(
			'<p class="f3base-bloco-resumo">%s</p>',
			esc_html(
				sprintf(
					/* translators: %d: período em dias. */
					__( 'Totais dos últimos %d dias, somados pelo próprio site a partir do que cada visita registrou ao sair da página. Contam apenas as visitas em que o consentimento permitiu medição: este quadro não é o total de visitantes do site.', 'f3base' ),
					(int) $resumo['dias']
				)
			)
		);

		self::render_onde_esta_o_resto();

		if ( ! $ligado ) {
			printf(
				'<p class="f3base-vazio">%s</p></section>',
				esc_html__( 'O resumo está desligado: nada é enviado pelas páginas e nada é guardado. Ligue "Guardar o resumo no site", em Privacidade e retenção, para que este quadro passe a ter números.', 'f3base' )
			);

			return;
		}

		if ( (int) $resumo['linhas'] < 1 ) {
			printf(
				'<p class="f3base-vazio">%s</p></section>',
				esc_html(
					sprintf(
						/* translators: %d: período em dias. */
						__( 'Sem dados no período: nenhuma visita registrada nos últimos %d dias. Isto não é zero de audiência — é ausência de registro, e as causas possíveis são o site ainda não ter recebido visitas, o consentimento ter sido recusado por quem visitou, ou o resumo ter sido ligado há menos tempo que o período mostrado.', 'f3base' ),
						(int) $resumo['dias']
					)
				)
			);

			return;
		}

		self::render_tabela_de_totais(
			__( 'Páginas mais registradas', 'f3base' ),
			__( 'Página', 'f3base' ),
			__( 'Registros no período', 'f3base' ),
			array_map(
				static fn ( array $linha ): array => array( (string) $linha['caminho'], (string) (int) $linha['total'] ),
				array_slice( $resumo['paginas'], 0, 12 )
			)
		);

		self::render_tabela_de_totais(
			__( 'O que aconteceu nelas', 'f3base' ),
			__( 'Evento', 'f3base' ),
			__( 'Vezes no período', 'f3base' ),
			array_map(
				static fn ( array $linha ): array => array( (string) $linha['rotulo'], (string) (int) $linha['total'] ),
				array_slice( $resumo['eventos'], 0, 20 )
			)
		);

		if ( array() !== $resumo['vitais'] ) {
			self::render_tabela_de_totais(
				__( 'Experiência de carregamento (média do período)', 'f3base' ),
				__( 'Métrica', 'f3base' ),
				__( 'Média · amostras', 'f3base' ),
				array_map(
					static fn ( array $linha ): array => array(
						(string) $linha['metrica'],
						sprintf(
							/* translators: 1: média da métrica, 2: quantidade de amostras. */
							__( '%1$s · %2$d', 'f3base' ),
							number_format_i18n( (float) $linha['media'], 3 ),
							(int) $linha['amostra']
						),
					),
					$resumo['vitais']
				)
			);

			printf(
				'<p class="description">%s</p>',
				esc_html__( 'Os valores saem como o navegador os mediu, sem classificação de bom ou ruim: os cortes são do fornecedor e mudam por calendário, e quem classifica no console dele tem o corte vigente.', 'f3base' )
			);
		}

		printf(
			'<p class="description">%s <code>%s</code></p>',
			esc_html__( 'Tabela deste quadro, para quem opera o site pelo canal de manutenção:', 'f3base' ),
			esc_html( F3Base_Modulo_Comportamento::nome_tabela() )
		);

		echo '</section>';
	}

	/**
	 * ONDE ESTÃO OS DADOS QUE NÃO ESTÃO AQUI — dito sem rodeio.
	 *
	 * @return void
	 */
	private static function render_onde_esta_o_resto(): void {
		$ga4 = class_exists( 'F3Base_Modulo_Tracking' ) ? (string) F3Base_Modulo_Tracking::ids()['f3base_ga4_measurement_id'] : '';

		if ( '' === $ga4 ) {
			printf(
				'<p class="f3base-aviso-destino">%s</p>',
				esc_html__( 'O campo Google Analytics 4 — ID da métrica está vazio: nenhum evento deste site chega ao Google Analytics, e a análise completa — público, origem de tráfego, comparação de períodos e funil — não existe em lugar nenhum. O quadro abaixo é tudo o que há. Preencha aquele campo, na seção Medição e anúncios, para que os mesmos eventos passem a chegar lá também.', 'f3base' )
			);

			return;
		}

		printf(
			'<p class="f3base-aviso-destino">%s</p>',
			esc_html__( 'Este quadro é o que o site vê por conta própria, e ele não substitui o relatório do fornecedor: público, origem de tráfego, funil, comparação de períodos longos e atribuição de campanha vivem no Google Analytics e nos consoles de cada canal. Os mesmos eventos estão sendo enviados para lá.', 'f3base' )
		);
	}

	/**
	 * Uma tabela simples de rótulo e total.
	 *
	 * @param string                  $titulo   Título do quadro.
	 * @param string                  $coluna_a Cabeçalho da primeira coluna.
	 * @param string                  $coluna_b Cabeçalho da segunda coluna.
	 * @param array<int,array<int,string>> $linhas Linhas.
	 * @return void
	 */
	private static function render_tabela_de_totais( string $titulo, string $coluna_a, string $coluna_b, array $linhas ): void {
		if ( array() === $linhas ) {
			return;
		}

		printf( '<h3>%s</h3>', esc_html( $titulo ) );
		echo '<table class="widefat striped f3base-totais"><thead><tr>';
		printf( '<th>%s</th><th>%s</th>', esc_html( $coluna_a ), esc_html( $coluna_b ) );
		echo '</tr></thead><tbody>';

		foreach ( $linhas as $linha ) {
			printf(
				'<tr><td>%s</td><td>%s</td></tr>',
				esc_html( (string) $linha[0] ),
				esc_html( (string) $linha[1] )
			);
		}

		echo '</tbody></table>';
	}

	/* ------------------------------------------------------------------ *
	 * Diagnóstico — inteiro, e depois dos campos
	 * ------------------------------------------------------------------ */

	/**
	 * O diagnóstico: estado de cada parte, motivos, avisos, hooks e options.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_diagnostico( array $relatorio ): void {
		printf(
			'<section class="f3base-bloco f3base-bloco--%1$s" data-f3base-bloco="%1$s"><h2>%2$s</h2>',
			esc_attr( self::BLOCO_DIAGNOSTICO ),
			esc_html__( 'Estado das partes do plugin', 'f3base' )
		);

		printf(
			'<p class="f3base-bloco-resumo">%s</p>',
			esc_html__( 'O que está funcionando, o que está funcionando com ressalva e o que está parado, com o motivo de cada um. É esta parte que responde "por que isto não está acontecendo no site", e é a que o suporte e o agente de manutenção leem.', 'f3base' )
		);

		self::render_resumo( $relatorio );
		self::render_modulos( $relatorio );
		self::render_options_sem_modulo( $relatorio );

		echo '</section>';
	}

	/**
	 * Resumo por estado.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_resumo( array $relatorio ): void {
		$resumo = is_array( $relatorio['resumo'] ) ? $relatorio['resumo'] : array();

		echo '<ul class="f3base-resumo">';

		foreach ( array( F3Base_Modulo::ATIVO, F3Base_Modulo::DEGRADADO, F3Base_Modulo::INATIVO ) as $estado ) {
			printf(
				'<li class="f3base-chip f3base-chip--%1$s"><strong>%2$d</strong> %3$s</li>',
				esc_attr( $estado ),
				(int) ( $resumo[ $estado ] ?? 0 ),
				esc_html( self::rotulo_estado( $estado ) )
			);
		}

		echo '</ul>';
	}

	/**
	 * Cartões dos módulos.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_modulos( array $relatorio ): void {
		$modulos = is_array( $relatorio['modulos'] ) ? $relatorio['modulos'] : array();

		foreach ( $modulos as $modulo ) {
			if ( ! is_array( $modulo ) ) {
				continue;
			}

			$estado = (string) $modulo['estado'];

			echo '<div class="f3base-modulo">';

			printf(
				'<h3>%1$s <code>%2$s</code> <span class="f3base-chip f3base-chip--%3$s">%4$s</span></h3>',
				esc_html( (string) $modulo['nome'] ),
				esc_html( (string) $modulo['id'] ),
				esc_attr( $estado ),
				esc_html( self::rotulo_estado( $estado ) )
			);

			printf( '<p class="f3base-descricao">%s</p>', esc_html( (string) $modulo['descricao'] ) );

			if ( '' !== (string) $modulo['motivo'] ) {
				printf(
					'<p class="f3base-motivo"><strong>%1$s</strong> %2$s</p>',
					esc_html__( 'Motivo:', 'f3base' ),
					esc_html( (string) $modulo['motivo'] )
				);
			}

			self::render_avisos( isset( $modulo['avisos'] ) && is_array( $modulo['avisos'] ) ? $modulo['avisos'] : array() );
			self::render_dependencias( is_array( $modulo['dependencias'] ) ? $modulo['dependencias'] : array() );
			self::render_options_do_modulo( is_array( $modulo['options'] ) ? $modulo['options'] : array() );
			self::render_hooks( is_array( $modulo['hooks'] ) ? $modulo['hooks'] : array(), (bool) $modulo['registra_hooks'] );
			self::render_atividade( is_array( $modulo['atividade'] ) ? $modulo['atividade'] : array() );

			echo '</div>';
		}
	}

	/**
	 * Dependências de um módulo.
	 *
	 * @param array<int,mixed> $dependencias Dependências declaradas.
	 * @return void
	 */
	private static function render_dependencias( array $dependencias ): void {
		if ( array() === $dependencias ) {
			return;
		}

		echo '<h4>' . esc_html__( 'Do que depende', 'f3base' ) . '</h4><ul class="f3base-lista">';

		foreach ( $dependencias as $dependencia ) {
			if ( ! is_array( $dependencia ) ) {
				continue;
			}

			printf(
				'<li class="%1$s"><strong>%2$s</strong> — %3$s</li>',
				esc_attr( ! empty( $dependencia['presente'] ) ? 'f3base-ok' : 'f3base-falta' ),
				esc_html( (string) $dependencia['rotulo'] ),
				esc_html( (string) $dependencia['detalhe'] )
			);
		}

		echo '</ul>';
	}

	/**
	 * Options que controlam um módulo.
	 *
	 * @param array<int,mixed> $options Linhas de option.
	 * @return void
	 */
	private static function render_options_do_modulo( array $options ): void {
		if ( array() === $options ) {
			return;
		}

		echo '<h4>' . esc_html__( 'Ajustes que controlam esta parte', 'f3base' ) . '</h4>';
		echo '<table class="widefat striped f3base-options"><thead><tr>';
		printf( '<th>%s</th>', esc_html__( 'Ajuste', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Valor atual', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Última gravação', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Edição', 'f3base' ) );
		echo '</tr></thead><tbody>';

		foreach ( $options as $option ) {
			if ( ! is_array( $option ) ) {
				continue;
			}

			printf(
				'<tr><td><strong>%1$s</strong><br /><code>%2$s</code></td><td><pre>%3$s</pre></td><td>%4$s%5$s</td><td>%6$s</td></tr>',
				esc_html( (string) $option['rotulo'] ),
				esc_html( (string) $option['nome'] ),
				esc_html( (string) $option['valor_texto'] ),
				esc_html( (string) $option['origem_rotulo'] ),
				(int) $option['carimbo'] > 0
					? '<br /><span class="description">' . esc_html( (string) wp_date( 'd/m/Y H:i', (int) $option['carimbo'] ) ) . '</span>'
					: '',
				! empty( $option['operavel'] )
					? esc_html__( 'editável no formulário acima', 'f3base' )
					: esc_html__( 'sem campo nesta tela: é ajuste estrutural', 'f3base' )
			);
		}

		echo '</tbody></table>';
	}

	/**
	 * Hooks declarados por um módulo.
	 *
	 * @param array<int,mixed> $hooks     Hooks declarados.
	 * @param bool             $registrou Se o módulo registrou os hooks.
	 * @return void
	 */
	private static function render_hooks( array $hooks, bool $registrou ): void {
		if ( array() === $hooks ) {
			return;
		}

		printf(
			'<h4>%1$s <span class="description">%2$s</span></h4>',
			esc_html__( 'Onde esta parte se liga ao WordPress', 'f3base' ),
			esc_html(
				$registrou
					? __( 'ligada nesta requisição.', 'f3base' )
					: __( 'não ligada: esta parte está parada, sem endereço, sem tabela e sem arquivo próprio. O item marcado SEMPRE abaixo é a exceção, e ela é declarada.', 'f3base' )
			)
		);

		echo '<ul class="f3base-lista f3base-hooks">';

		foreach ( $hooks as $hook ) {
			if ( ! is_array( $hook ) ) {
				continue;
			}

			printf(
				'<li><code>%1$s</code> %2$s <span class="description">%3$s</span></li>',
				esc_html( (string) $hook['hook'] ),
				esc_html( (string) $hook['tipo'] ),
				esc_html(
					empty( $hook['sempre'] )
						? sprintf(
							/* translators: 1: método, 2: prioridade. */
							__( '%1$s, prioridade %2$d', 'f3base' ),
							(string) $hook['metodo'],
							(int) $hook['prioridade']
						)
						: sprintf(
							/* translators: 1: método, 2: prioridade. */
							__( '%1$s, prioridade %2$d — registrado SEMPRE: a decisão dele é por bloco, e o caso mais importante dela acontece com o módulo inativo.', 'f3base' ),
							(string) $hook['metodo'],
							(int) $hook['prioridade']
						)
				)
			);
		}

		echo '</ul>';
	}

	/**
	 * AVISOS do módulo: funciona, e custa isto.
	 *
	 * Fica ANTES das dependências de propósito: quem abre a tela por causa de um
	 * número que não bate precisa ler primeiro o que continua funcionando com
	 * preço, e não descobrir isso no fim da lista.
	 *
	 * @param array<int,mixed> $avisos Avisos declarados pelo módulo.
	 * @return void
	 */
	private static function render_avisos( array $avisos ): void {
		if ( array() === $avisos ) {
			return;
		}

		echo '<h4>' . esc_html__( 'Funciona, e custa isto', 'f3base' ) . '</h4><ul class="f3base-lista f3base-avisos">';

		foreach ( $avisos as $aviso ) {
			if ( ! is_array( $aviso ) ) {
				continue;
			}

			printf(
				'<li><span class="f3base-chip f3base-chip--aviso">%1$s</span> %2$s</li>',
				esc_html( (string) ( $aviso['estado'] ?? '' ) ),
				esc_html( (string) ( $aviso['motivo'] ?? '' ) )
			);
		}

		echo '</ul>';
	}

	/**
	 * Última atividade relevante.
	 *
	 * @param array<int,mixed> $atividade Frases de atividade.
	 * @return void
	 */
	private static function render_atividade( array $atividade ): void {
		if ( array() === $atividade ) {
			return;
		}

		echo '<h4>' . esc_html__( 'O que aconteceu por último', 'f3base' ) . '</h4><ul class="f3base-lista">';

		foreach ( $atividade as $frase ) {
			printf( '<li>%s</li>', esc_html( (string) $frase ) );
		}

		echo '</ul>';
	}

	/**
	 * Options gerenciadas que nenhum módulo reivindica.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_options_sem_modulo( array $relatorio ): void {
		$options = is_array( $relatorio['options_sem_modulo'] ) ? $relatorio['options_sem_modulo'] : array();

		if ( array() === $options ) {
			return;
		}

		echo '<h3>' . esc_html__( 'Ajustes que nenhuma parte reivindica', 'f3base' ) . '</h3>';
		printf(
			'<p class="description">%s</p>',
			esc_html__( 'Gravados pelo implantador ou pelo próprio plugin como estado de execução. Aparecem aqui para que nenhum ajuste do site fique invisível.', 'f3base' )
		);

		echo '<table class="widefat striped f3base-options"><thead><tr>';
		printf( '<th>%s</th>', esc_html__( 'Ajuste', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Valor atual', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Última gravação', 'f3base' ) );
		echo '</tr></thead><tbody>';

		foreach ( $options as $option ) {
			if ( ! is_array( $option ) ) {
				continue;
			}

			printf(
				'<tr><td><code>%1$s</code><br /><span class="description">%2$s</span></td><td><pre>%3$s</pre></td><td>%4$s</td></tr>',
				esc_html( (string) $option['nome'] ),
				esc_html( (string) $option['descricao'] ),
				esc_html( (string) $option['valor_texto'] ),
				esc_html( (string) $option['origem_rotulo'] )
			);
		}

		echo '</tbody></table>';
	}

	/* ------------------------------------------------------------------ *
	 * Apoio
	 * ------------------------------------------------------------------ */

	/**
	 * Prepara o valor enviado conforme a forma declarada da option.
	 *
	 * @param string              $nome       Nome da option.
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @param mixed               $enviado    Valor enviado.
	 * @return mixed
	 */
	private static function preparar( string $nome, array $declaracao, $enviado ) {
		$campo = (string) $declaracao['campo'];

		if ( 'grupo' === $campo ) {
			// O formulário expõe só os sub-campos declarados; o que ele não expõe é
			// preservado do valor atual, nunca apagado por omissão.
			$atual = F3Base_Options::ler( $nome );

			return array_merge(
				is_array( $atual ) ? $atual : array(),
				is_array( $enviado ) ? $enviado : array()
			);
		}

		if ( 'inteiro' === $campo ) {
			return is_scalar( $enviado ) ? (int) $enviado : 0;
		}

		return is_scalar( $enviado ) ? (string) $enviado : '';
	}

	/**
	 * Resume um valor lido de volta para exibição.
	 *
	 * @param mixed $valor Valor lido.
	 * @return string
	 */
	private static function resumir( $valor ): string {
		if ( is_array( $valor ) ) {
			$json = wp_json_encode( $valor, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

			return is_string( $json ) ? $json : '';
		}

		if ( is_bool( $valor ) ) {
			return $valor ? '1' : '0';
		}

		return (string) $valor;
	}

	/**
	 * Rótulo humano de um estado.
	 *
	 * @param string $estado Estado do módulo.
	 * @return string
	 */
	private static function rotulo_estado( string $estado ): string {
		switch ( $estado ) {
			case F3Base_Modulo::ATIVO:
				return __( 'funcionando', 'f3base' );
			case F3Base_Modulo::DEGRADADO:
				return __( 'funcionando com ressalva', 'f3base' );
			default:
				return __( 'parado', 'f3base' );
		}
	}
}
