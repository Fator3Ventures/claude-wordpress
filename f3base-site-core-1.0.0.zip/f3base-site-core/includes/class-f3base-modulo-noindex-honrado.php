<?php
/**
 * Módulo noindex-honrado.
 *
 * Honra o noindex gravado nas chaves do plugin de SEO MESMO SEM o plugin ativo,
 * pelo filtro `wp_robots`. É o mesmo princípio de gravar o SEO por conteúdo sem
 * depender do plugin: quem lê primeiro pode ser o site, não o plugin.
 *
 * Também aplica a regra dinâmica de arquivo de categoria raso — um ou dois posts
 * não disputam busca —, reavaliada a cada requisição, porque a categoria engorda
 * depois que o implantador dorme.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Honra do noindex gravado.
 */
final class F3Base_Modulo_Noindex_Honrado extends F3Base_Modulo {

	/**
	 * As chaves do fornecedor SAEM DO VOCABULÁRIO COMPARTILHADO.
	 *
	 * Estas constantes são apelidos de `F3Base_Chaves_Seo`, e não uma segunda
	 * declaração: quem ESCREVE a meta é o implantador, quem a LÊ é este módulo,
	 * e os dois precisam da mesma fonte. Elas continuam existindo com o nome
	 * antigo porque é por ele que o resto do pacote as alcança.
	 */
	public const PREFIXO_SEO = F3Base_Chaves_Seo::PREFIXO;

	/**
	 * Meta do plugin de SEO que guarda o noindex por conteúdo.
	 */
	public const META_NOINDEX = F3Base_Chaves_Seo::NOINDEX;

	/**
	 * Meta do plugin de SEO que guarda o nofollow por conteúdo.
	 */
	public const META_NOFOLLOW = F3Base_Chaves_Seo::NOFOLLOW;

	/**
	 * Meta do plugin de SEO que guarda a descrição por conteúdo.
	 */
	public const META_DESCRICAO = F3Base_Chaves_Seo::DESCRICAO;

	/**
	 * Option do plugin de SEO com os padrões por tipo e taxonomia.
	 */
	public const OPTION_TITULOS = F3Base_Chaves_Seo::OPTION_TITULOS;

	/**
	 * Option do plugin de SEO com o noindex por termo.
	 */
	public const OPTION_TAXONOMIA = F3Base_Chaves_Seo::OPTION_TAXONOMIA;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'noindex-honrado';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Honra de noindex', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Lê o noindex gravado nas chaves do plugin de SEO — meta por conteúdo, padrões por tipo e taxonomia, noindex por termo — e o aplica pelo filtro wp_robots mesmo com o plugin desativado. Arquivo de categoria raso recebe noindex, follow.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'filter',
				'hook'       => 'wp_robots',
				'metodo'     => 'aplicar',
				'prioridade' => 20,
				'args'       => 1,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$plugin = $this->plugin_ativo( F3Base_Vocabulario::slug_do_papel( F3Base_Vocabulario::PAPEL_SEO ) );

		return array(
			array(
				'rotulo'   => __( 'Plugin de SEO ativo', 'f3base' ),
				'presente' => $plugin,
				'detalhe'  => $plugin
					? __( 'presente: o plugin imprime o próprio robots e este módulo fica de reserva sobre as mesmas chaves.', 'f3base' )
					: __( 'ausente: este módulo é quem imprime o noindex das chaves gravadas.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Chaves gravadas por conteúdo', 'f3base' ),
				'presente' => true,
				'detalhe'  => __( 'a leitura é direta no banco, sem depender de o plugin estar carregado.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		if ( $this->plugin_ativo( F3Base_Vocabulario::slug_do_papel( F3Base_Vocabulario::PAPEL_SEO ) ) ) {
			return $this->ativo(
				__( 'plugin de SEO presente imprime o robots; a honra própria fica de reserva sobre as mesmas chaves, que é o desenho.', 'f3base' )
			);
		}

		return $this->ativo(
			__( 'sem plugin de SEO carregado: o noindex das chaves gravadas sai por wp_robots.', 'f3base' )
		);
	}

	/**
	 * Aplica a decisão de indexação.
	 *
	 * @param array<string,mixed> $robots Diretivas acumuladas.
	 * @return array<string,mixed>
	 */
	public function aplicar( array $robots ): array {
		$decisao = $this->decidir();

		if ( 'noindex' !== $decisao['indexacao'] ) {
			return $robots;
		}

		unset( $robots['index'] );
		$robots['noindex'] = true;

		if ( 'nofollow' === $decisao['seguimento'] ) {
			unset( $robots['follow'] );
			$robots['nofollow'] = true;
		} elseif ( ! isset( $robots['nofollow'] ) ) {
			$robots['follow'] = true;
		}

		return $robots;
	}

	/**
	 * REGRA PURA do noindex de UM conteúdo. Um lugar só decide esse fato.
	 *
	 * Três respostas, e elas não são intercambiáveis: `noindex` (a meta manda
	 * não indexar, ou o padrão do tipo manda e a meta não desmente), `index` (a
	 * meta manda indexar, e ela vence o padrão do tipo) e `default` (ninguém
	 * disse nada, e quem decide é o WordPress).
	 *
	 * Ela é PURA porque tem dois leitores em runtimes diferentes — o filtro
	 * `wp_robots` desta classe e a seleção do arquivo llms.txt — e porque é ela
	 * que a suíte exercita. Dois leitores do mesmo fato, cada um com a sua
	 * regra, é a forma de uma exclusão nunca disparar sem que nada acuse.
	 *
	 * @param string $meta          Valor bruto da meta por conteúdo.
	 * @param bool   $padrao_do_tipo O padrão do tipo manda não indexar.
	 * @return string `noindex`, `index` ou `default`.
	 */
	public static function decidir_por_post( string $meta, bool $padrao_do_tipo ): string {
		if ( '1' === $meta ) {
			return 'noindex';
		}

		if ( '2' === $meta ) {
			return 'index';
		}

		return $padrao_do_tipo ? 'noindex' : 'default';
	}

	/**
	 * ESTE ID ESTÁ EM NOINDEX? Pergunta pública, com UM produtor do fato.
	 *
	 * É por aqui que o arquivo `llms.txt` exclui o que não deve ser indexado.
	 * Ele PERGUNTA a este módulo em vez de ler a meta por conta própria: um
	 * segundo leitor da mesma chave é como uma exclusão passa a nunca disparar
	 * — a chave muda de um lado e o outro continua lendo o nome antigo, sem
	 * erro e sem aviso.
	 *
	 * @param int $id Identificador do conteúdo.
	 * @return bool
	 */
	public static function post_e_noindex( int $id ): bool {
		if ( $id <= 0 ) {
			return false;
		}

		$meta = get_post_meta( $id, self::META_NOINDEX, true );
		$meta = is_scalar( $meta ) ? (string) $meta : '';

		$tipo   = get_post_type( $id );
		$padrao = is_string( $tipo ) && '' !== $tipo && self::padrao_do_tipo_desliga( $tipo );

		return 'noindex' === self::decidir_por_post( $meta, $padrao );
	}

	/**
	 * O padrão do tipo, no plugin de SEO, manda não indexar?
	 *
	 * @param string $tipo Tipo de conteúdo.
	 * @return bool
	 */
	public static function padrao_do_tipo_desliga( string $tipo ): bool {
		return self::chave_de_titulos_desliga( 'noindex-' . $tipo );
	}

	/**
	 * Decide indexação e seguimento para a requisição atual.
	 *
	 * @return array{indexacao:string,seguimento:string,motivo:string}
	 */
	private function decidir(): array {
		$padrao = array(
			'indexacao'  => 'default',
			'seguimento' => 'default',
			'motivo'     => '',
		);

		if ( is_singular() ) {
			$id = get_queried_object_id();
			if ( $id > 0 ) {
				$meta = get_post_meta( $id, self::META_NOINDEX, true );
				$meta = is_scalar( $meta ) ? (string) $meta : '';

				$nofollow  = get_post_meta( $id, self::META_NOFOLLOW, true );
				$seguimento = ( is_scalar( $nofollow ) && '1' === (string) $nofollow ) ? 'nofollow' : 'default';

				$tipo   = get_post_type( $id );
				$padrao = is_string( $tipo ) && '' !== $tipo && self::padrao_do_tipo_desliga( $tipo );

				/* A REGRA É A MESMA que o llms.txt consulta, e ela mora num lugar só. */
				$decidido = self::decidir_por_post( $meta, $padrao );

				if ( 'default' !== $decidido ) {
					return array(
						'indexacao'  => $decidido,
						'seguimento' => $seguimento,
						'motivo'     => '' !== $meta ? 'meta-conteudo' : 'padrao-do-tipo',
					);
				}
			}

			return $padrao;
		}

		if ( is_tax() || is_category() || is_tag() ) {
			$termo = get_queried_object();

			if ( $termo instanceof WP_Term ) {
				$por_termo = $this->noindex_do_termo( $termo );

				if ( 'noindex' === $por_termo ) {
					return array(
						'indexacao'  => 'noindex',
						'seguimento' => 'default',
						'motivo'     => 'termo',
					);
				}

				if ( 'index' !== $por_termo && self::chave_de_titulos_desliga( 'noindex-tax-' . $termo->taxonomy ) ) {
					return array(
						'indexacao'  => 'noindex',
						'seguimento' => 'default',
						'motivo'     => 'padrao-da-taxonomia',
					);
				}

				if ( 'index' !== $por_termo && $this->categoria_rasa( $termo ) ) {
					return array(
						'indexacao'  => 'noindex',
						'seguimento' => 'default',
						'motivo'     => 'categoria-rasa',
					);
				}
			}

			return $padrao;
		}

		if ( is_author() && self::chave_de_titulos_desliga( 'noindex-author-wpseo' ) ) {
			return array(
				'indexacao'  => 'noindex',
				'seguimento' => 'default',
				'motivo'     => 'arquivo-de-autor',
			);
		}

		if ( is_date() && self::chave_de_titulos_desliga( 'noindex-archive-wpseo' ) ) {
			return array(
				'indexacao'  => 'noindex',
				'seguimento' => 'default',
				'motivo'     => 'arquivo-de-data',
			);
		}

		if ( is_post_type_archive() ) {
			$tipo = get_query_var( 'post_type' );
			$tipo = is_array( $tipo ) ? (string) reset( $tipo ) : (string) $tipo;

			if ( '' !== $tipo && self::chave_de_titulos_desliga( 'noindex-ptarchive-' . $tipo ) ) {
				return array(
					'indexacao'  => 'noindex',
					'seguimento' => 'default',
					'motivo'     => 'arquivo-do-tipo',
				);
			}
		}

		return $padrao;
	}

	/**
	 * A chave do plugin de SEO manda não indexar?
	 *
	 * @param string $chave Chave dentro de `wpseo_titles`.
	 * @return bool
	 */
	public static function chave_de_titulos_desliga( string $chave ): bool {
		$titulos = get_option( self::OPTION_TITULOS, array() );

		if ( ! is_array( $titulos ) || ! array_key_exists( $chave, $titulos ) ) {
			return false;
		}

		$valor = $titulos[ $chave ];

		if ( is_string( $valor ) ) {
			return in_array( strtolower( $valor ), array( '1', 'on', 'true', 'noindex' ), true );
		}

		return (bool) $valor;
	}

	/**
	 * Decisão gravada por termo.
	 *
	 * @param WP_Term $termo Termo consultado.
	 * @return string `noindex`, `index` ou `default`.
	 */
	private function noindex_do_termo( WP_Term $termo ): string {
		$meta = get_option( self::OPTION_TAXONOMIA, array() );

		if ( ! is_array( $meta ) || ! isset( $meta[ $termo->taxonomy ][ $termo->term_id ] ) ) {
			return 'default';
		}

		$entrada = $meta[ $termo->taxonomy ][ $termo->term_id ];
		if ( ! is_array( $entrada ) || ! isset( $entrada['wpseo_noindex'] ) ) {
			return 'default';
		}

		$valor = strtolower( (string) $entrada['wpseo_noindex'] );

		if ( 'noindex' === $valor ) {
			return 'noindex';
		}

		if ( 'index' === $valor ) {
			return 'index';
		}

		return 'default';
	}

	/**
	 * Arquivo de categoria raso: um ou dois posts não disputam busca.
	 *
	 * @param WP_Term $termo Termo consultado.
	 * @return bool
	 */
	private function categoria_rasa( WP_Term $termo ): bool {
		if ( 'category' !== $termo->taxonomy ) {
			return false;
		}

		$limite = (int) apply_filters( 'f3base_categoria_rasa_limite', 2 );

		if ( $limite < 1 ) {
			return false;
		}

		return (int) $termo->count <= $limite;
	}
}
