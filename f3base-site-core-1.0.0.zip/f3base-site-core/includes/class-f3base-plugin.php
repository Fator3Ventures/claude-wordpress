<?php
/**
 * Orquestrador do plugin.
 *
 * Registra os hooks LENDO O REGISTRO ÚNICO: nenhum `add_action` de módulo é
 * escrito aqui à mão. Módulo inativo não registra nada — é inerte de verdade.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ciclo de vida do site-core.
 */
final class F3Base_Site_Core {

	/**
	 * Prioridade em que os hooks dos módulos são registrados, dentro de `init`.
	 *
	 * Registrar em `init` (e não em `plugins_loaded`) mantém toda leitura de
	 * estado depois do carregamento do text domain: chamar tradução antes de
	 * `init` gera aviso do core desde o WordPress 6.7.
	 */
	public const PRIORIDADE_REGISTRO = 5;

	/**
	 * Liga o plugin.
	 *
	 * @return void
	 */
	public static function iniciar(): void {
		add_action( 'init', array( __CLASS__, 'carregar_traducoes' ), 0 );
		add_action( 'init', array( __CLASS__, 'registrar' ), self::PRIORIDADE_REGISTRO );
		add_action( 'rest_api_init', array( __CLASS__, 'registrar_rota_relatorio' ), 10 );

		/*
		 * A HABILIDADE QUE DIZ AO AGENTE COMO USAR O PLUGIN. Ela é registrada no
		 * gancho da própria Abilities API, que só existe quando o servidor MCP
		 * está instalado — sem ele, nada acontece e nada falha.
		 */
		add_action( 'abilities_api_init', array( 'F3Base_Como_Usar', 'registrar' ) );
		add_action( 'abilities_api_init', array( 'F3Base_Config_Mcp', 'registrar' ) );

		if ( is_admin() ) {
			F3Base_Admin_Tela::iniciar();
		}
	}

	/**
	 * Carrega o text domain.
	 *
	 * @return void
	 */
	public static function carregar_traducoes(): void {
		load_plugin_textdomain(
			F3BASE_TEXT_DOMAIN,
			false,
			dirname( plugin_basename( F3BASE_SITE_CORE_ARQUIVO ) ) . '/languages'
		);
	}

	/**
	 * Registra os hooks declarados pelos módulos do registro único.
	 *
	 * Módulo inativo continua inerte — nenhum asset, nenhum endpoint, nenhuma
	 * tabela —, com UMA exceção declarada por hook: o item marcado `sempre` é
	 * registrado de qualquer jeito. Ele existe para o filtro cuja decisão é POR
	 * OBJETO, e cujo caso mais importante acontece justamente com o módulo
	 * inativo: o bloco do CTA sem número. Antes desta exceção, o filtro que
	 * decidia publicar o botão só era registrado quando a condição dele já não
	 * podia acontecer, e a regra nunca rodava.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		foreach ( F3Base_Registro::modulos() as $modulo ) {
			$ativo = $modulo->deve_registrar();

			foreach ( $modulo->hooks() as $hook ) {
				if ( ! $ativo && empty( $hook['sempre'] ) ) {
					continue;
				}

				$metodo = (string) $hook['metodo'];

				if ( ! method_exists( $modulo, $metodo ) ) {
					continue;
				}

				$callback   = array( $modulo, $metodo );
				$prioridade = (int) $hook['prioridade'];
				$args       = (int) $hook['args'];

				if ( 'filter' === (string) $hook['tipo'] ) {
					add_filter( (string) $hook['hook'], $callback, $prioridade, max( 1, $args ) );
					continue;
				}

				add_action( (string) $hook['hook'], $callback, $prioridade, $args );
			}
		}
	}

	/**
	 * Rota de leitura do relatório — a mesma estrutura que a tela renderiza.
	 *
	 * @return void
	 */
	public static function registrar_rota_relatorio(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			'/relatorio',
			array(
				'methods'             => 'GET',
				'callback'            => static function (): WP_REST_Response {
					return new WP_REST_Response( F3Base_Registro::relatorio(), 200 );
				},
				'permission_callback' => static function (): bool {
					return current_user_can( 'manage_options' );
				},
				'args'                => array(),
			)
		);
	}

	/**
	 * Relatório do plugin, para o implantador e para a suíte.
	 *
	 * @return array<string,mixed>
	 */
	public static function relatorio(): array {
		return F3Base_Registro::relatorio();
	}

	/**
	 * Ativação: semeia os padrões, instala a estrutura dos módulos e regrava as
	 * regras de reescrita.
	 *
	 * @return void
	 */
	public static function ativar(): void {
		self::semear_padroes();

		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			if ( $modulo->deve_registrar() ) {
				$modulo->instalar();
			}
		}

		flush_rewrite_rules( false );
	}

	/**
	 * Desativação: desfaz agendamentos e regrava as regras de reescrita.
	 *
	 * Nenhum dado de lead é tocado aqui: desativar plugin não é pedido de
	 * eliminação, e apagar registro pessoal sem journal é perda sem registro.
	 *
	 * @return void
	 */
	public static function desativar(): void {
		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			$modulo->desinstalar();
		}

		flush_rewrite_rules( false );
	}

	/**
	 * Grava o padrão embutido apenas nas options que ainda não existem.
	 *
	 * Option já escrita pelo implantador nunca é sobrescrita na ativação.
	 *
	 * @return void
	 */
	private static function semear_padroes(): void {
		foreach ( F3Base_Options::catalogo() as $nome => $declaracao ) {
			if ( F3Base_Options::existe( $nome ) ) {
				continue;
			}

			if ( isset( $declaracao['campo'] ) && 'segredo' === $declaracao['campo'] ) {
				continue;
			}

			F3Base_Options::gravar( $nome, $declaracao['padrao'], F3Base_Options::ORIGEM_PADRAO );
		}
	}
}
