<?php
/**
 * A habilidade que diz ao agente COMO USAR este plugin.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * O MANUAL DE USO, montado do registro de módulos.
 *
 * POR QUE ISTO EXISTE. Depois da entrega, quem muda este site é um agente por
 * MCP. Sem saber o que o plugin já faz, o caminho natural do agente é resolver
 * cada pedido por onde ele conhece: injetar o GTM no tema, instalar um plugin de
 * pixel, escrever um segundo llms.txt. Nada disso falha — e é esse o problema.
 * O site passa a ter dois emissores da mesma tag, a conversão é contada duas
 * vezes, a campanha otimiza para um número inflado e ninguém vê erro nenhum.
 *
 * A LISTA SAI DO REGISTRO, nunca de um texto escrito à mão. Um manual digitado
 * envelhece na primeira vez que alguém acrescenta um módulo e esquece de
 * atualizá-lo — e um manual desatualizado é pior que nenhum, porque o agente
 * confia nele. Módulo novo aparece aqui sozinho, com o que ele controla e o
 * estado em que está.
 */
final class F3Base_Como_Usar {

	/**
	 * Nome da habilidade registrada na Abilities API.
	 *
	 * @var string
	 */
	public const HABILIDADE = 'f3base/como-usar';

	/**
	 * Registra a habilidade quando a API existir.
	 *
	 * @return void
	 */
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			self::HABILIDADE,
			array(
				'label'               => __( 'Como usar o plugin do site', 'f3base' ),
				'description'         => __( 'O que este plugin já faz, por onde mudar cada coisa e o que NÃO fazer por outro caminho. Leia antes de instalar plugin de medição, editar o tema ou escrever configuração à mão.', 'f3base' ),
				'input_schema'        => array(
					'type'       => 'object',
					'properties' => array(),
				),
				'output_schema'       => array( 'type' => 'object' ),
				'execute_callback'    => array( __CLASS__, 'responder' ),
				'permission_callback' => static function (): bool {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * A resposta: legível por máquina e por gente.
	 *
	 * @return array<string,mixed>
	 */
	public static function responder(): array {
		return array(
			'plugin'      => 'f3base-site-core',
			'versao'      => defined( 'F3BASE_SITE_CORE_VERSAO' ) ? F3BASE_SITE_CORE_VERSAO : '',
			'resumo'      => __( 'Este plugin já cuida de medição, consentimento, leads, llms.txt, redirects, cabeçalhos, noindex e schema. Mude o comportamento gravando as options listadas aqui — não por outro plugin, não pelo tema, não por tag manager paralelo.', 'f3base' ),
			'assuntos'    => self::assuntos(),
			'nao_faca'    => self::nao_faca(),
			'como_mudar'  => __( 'Grave a option indicada em cada assunto pela API de options do WordPress. O plugin relê a option a cada carregamento: não há cache a limpar e não é preciso reativar nada.', 'f3base' ),
		);
	}

	/**
	 * Os assuntos, um por módulo do registro.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function assuntos(): array {
		$saida = array();

		foreach ( F3Base_Registro::modulos() as $modulo ) {
			$estado = $modulo->estado();

			$saida[] = array(
				'assunto'      => $modulo->nome(),
				'id'           => $modulo->id(),
				'faz'          => $modulo->descricao(),
				'options'      => $modulo->options_que_controlam(),
				'estado'       => (string) ( $estado['estado'] ?? '' ),
				'por_que'      => (string) ( $estado['motivo'] ?? '' ),
			);
		}

		return $saida;
	}

	/**
	 * O QUE NÃO FAZER, e o preço de cada um.
	 *
	 * Cada item nomeia o caminho alternativo que o agente tomaria e o efeito
	 * medido de tomá-lo. Não é uma lista de proibições: é a explicação de por
	 * que o caminho paralelo custa caro, para quem precisa decidir.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function nao_faca(): array {
		return array(
			array(
				'nao'    => __( 'Não injete GTM, GA4, Pixel da Meta, Google Ads ou Insight Tag do LinkedIn pelo tema, por plugin de terceiro ou por um segundo tag manager.', 'f3base' ),
				'porque' => __( 'Este plugin já emite todas elas a partir dos IDs gravados em option, e um emissor por fornecedor. Dois emissores contam a mesma conversão duas vezes: a campanha otimiza para um número inflado e nada aparece como erro.', 'f3base' ),
				'faca'   => __( 'Grave o ID na option f3base_tracking. Deixe o ID vazio para desligar aquele fornecedor.', 'f3base' ),
			),
			array(
				'nao'    => __( 'Não instale plugin de consentimento nem escreva o consentimento por fora.', 'f3base' ),
				'porque' => __( 'A decisão de consentimento aqui é quem libera cada tag. Um segundo controlador cria dois estados para o mesmo visitante, e o que decide passa a ser a ordem de carregamento — que muda de página para página.', 'f3base' ),
				'faca'   => __( 'Ajuste a option f3base_consentimento.', 'f3base' ),
			),
			array(
				'nao'    => __( 'Não crie um segundo produtor de /llms.txt nem de /llms-full.txt.', 'f3base' ),
				'porque' => __( 'O plugin já responde nessas rotas. Um segundo produtor faz o WordPress servir o que responder primeiro, e qual dos dois é imprevisível entre requisições.', 'f3base' ),
				'faca'   => __( 'Ajuste a option f3base_llms.', 'f3base' ),
			),
			array(
				'nao'    => __( 'Não crie endpoint próprio para receber lead do formulário do site.', 'f3base' ),
				'porque' => __( 'O endpoint deste plugin já valida, limita por IP, registra e dispara a conversão com o mesmo event_id do navegador. Um segundo caminho recebe lead sem nada disso, e a conversão dele não deduplica.', 'f3base' ),
				'faca'   => __( 'Use o endpoint existente; a forma dos campos está na option f3base_leads.', 'f3base' ),
			),
			array(
				'nao'    => __( 'Não escreva cabeçalhos de segurança por .htaccess ou por plugin quando este já os envia.', 'f3base' ),
				'porque' => __( 'Cabeçalho duplicado com valores diferentes tem resultado dependente do servidor, e o mais restritivo costuma vencer — cortando a janela do fluxo de leads sem erro visível.', 'f3base' ),
				'faca'   => __( 'Ajuste a option f3base_cabecalhos.', 'f3base' ),
			),
		);
	}
}
