<?php
/**
 * Módulo: o RESUMO DE COMPORTAMENTO que o próprio site guarda.
 *
 * A PERGUNTA QUE ESTE MÓDULO RESPONDE, nas palavras de quem a fez: *"O site
 * nasce instrumentado, onde posso ver os dados desta instrumentação."* A
 * resposta, até a 1.1.3, era: em lugar nenhum do site. Os seis coletores de
 * comportamento da 1.1.3 saem do navegador direto para a conta de medição —
 * `grep` dos seis nomes de evento dentro do plugin devolve zero — e
 * `f3base_atividade` guarda só o que passa pelo servidor. Com o slot de medição
 * vazio, os eventos nem chegavam a existir.
 *
 * O QUE ELE FAZ. Ao SAIR de cada página, o navegador manda UMA vez os TOTAIS
 * daquela visita, por `sendBeacon`, e este módulo os soma numa tabela própria —
 * uma linha por dia, caminho da página, evento e detalhe. Duas leituras vivem
 * dessa tabela: a pessoa, na tela do plugin, e o agente, por rota de banco do
 * canal, sem depender de credencial de fornecedor nenhum.
 *
 * O QUE ELE NÃO É. Ele NÃO substitui a conta de medição. Aqui não há público,
 * origem de tráfego, funil, comparação com o setor nem retenção por coorte —
 * há contagem por página e por dia. A tela diz isso com todas as letras, porque
 * um resumo que se apresenta como análise completa é pior que resumo nenhum.
 *
 * AS QUATRO RECUSAS DO PAYLOAD, e cada uma tem onde falhar:
 *
 * 1. NENHUM IDENTIFICADOR DE VISITANTE. Não há id de sessão, não há cookie e
 *    nada é gravado no armazenamento do navegador: a sessão existe só na
 *    memória da aba, e existe apenas para não enviar duas vezes.
 * 2. NENHUMA URL COM QUERY. A chave é o CAMINHO da página, sem query e sem
 *    fragmento — é na query que mora o identificador que a campanha de outra
 *    pessoa colou lá.
 * 3. NENHUM TEXTO LIVRE. O detalhe de cada evento passa por um alfabeto
 *    fechado, sem espaço, sem arroba, sem barra e sem dois-pontos: host de
 *    destino, nome de seção, marco de rolagem e nome de métrica passam; e-mail,
 *    caminho de arquivo e mensagem de erro não têm como passar.
 * 4. NENHUM EVENTO SEM DECLARAÇÃO. O navegador manda o GATILHO, nunca o nome do
 *    evento; quem resolve o nome é o servidor, contra
 *    `dados/eventos-comportamento.tsv`. Gatilho que não está lá não vira linha.
 *
 * O PORTÃO É O MESMO DA INSTRUMENTAÇÃO: sem consentimento o navegador não
 * envia. O servidor não tem como conferir consentimento de quem não mandou
 * nada, e é por isso que a tela declara, ao lado dos números, que eles contam
 * só as sessões com consentimento — quem lê um total sem essa frase acha que
 * está vendo o universo.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Coleta agregada, armazenamento próprio e leitura do comportamento no site.
 */
final class F3Base_Modulo_Comportamento extends F3Base_Modulo {

	/**
	 * Rota REST que recebe o resumo da sessão.
	 */
	public const ROTA = '/comportamento';

	/**
	 * Sufixo da tabela própria.
	 */
	public const TABELA = 'f3base_comportamento';

	/**
	 * Colunas que ESTA versão usa. A prontidão é medida por elas, nunca pelo
	 * `SHOW TABLES`: tabela antiga responde à existência e faz o `INSERT` desta
	 * versão falhar em silêncio.
	 */
	public const COLUNAS = array( 'chave', 'dia', 'caminho', 'metrica', 'detalhe', 'contagem', 'soma', 'atualizado_em' );

	/**
	 * Alfabeto fechado do detalhe. Sem espaço, arroba, barra e dois-pontos.
	 */
	public const FORMA_DETALHE = '/^[A-Za-z0-9][A-Za-z0-9._-]{0,59}$/';

	/**
	 * Forma do caminho aceito: caminho do próprio site, sem query e sem âncora.
	 */
	public const FORMA_CAMINHO = '/^\/[A-Za-z0-9\/_\-.~%]{0,189}$/';

	/**
	 * Teto de bytes do corpo aceito.
	 */
	public const MAX_BYTES = 8192;

	/**
	 * Prontidão memoizada por requisição.
	 *
	 * @var bool|null
	 */
	private static ?bool $tabela_pronta = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'comportamento';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Resumo de comportamento no site', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Recebe, ao fim de cada visita, os totais agregados daquela página e os soma numa tabela própria — uma linha por dia, caminho, evento e detalhe. É a leitura que o site tem por conta própria, sem depender de conta de fornecedor.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'garantir_estrutura',
				'prioridade' => 20,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_comportamento' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$declarados = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::eventos_de_comportamento()
			: array();

		return array(
			array(
				'rotulo'   => 'dados/eventos-comportamento.tsv',
				'presente' => array() !== $declarados,
				'detalhe'  => array() !== $declarados
					? sprintf(
						/* translators: %d: quantidade de eventos declarados. */
						__( '%d evento(s) declarado(s): é desta lista que o servidor resolve o nome a partir do gatilho que o navegador manda.', 'f3base' ),
						count( $declarados )
					)
					: __( 'declaração ausente ou ilegível: sem ela nenhum gatilho vira linha, porque o nome do evento não existe em lugar nenhum do cliente.', 'f3base' ),
			),
			array(
				'rotulo'   => self::nome_tabela(),
				'presente' => self::tabela_pronta(),
				'detalhe'  => self::tabela_pronta()
					? __( 'tabela presente com as colunas desta versão.', 'f3base' )
					: __( 'tabela ausente ou sem as colunas desta versão: a rota responde 503 e nada é somado, em vez de descartar em silêncio.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_COMPORTAMENTO, __( 'Último resumo de sessão somado', 'f3base' ) ),
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_PODA_COMPORTAMENTO, __( 'Última poda pelo prazo declarado', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		if ( empty( $config['ligado'] ) ) {
			return array(
				'estado' => self::INATIVO,
				'motivo' => __( 'o resumo está desligado em f3base_comportamento.ligado: o navegador não envia nada, a rota não é registrada e o quadro da tela fica vazio. O envio para a conta de medição, quando houver, não depende desta chave.', 'f3base' ),
			);
		}

		if ( ! self::tabela_pronta() ) {
			return array(
				'estado' => self::DEGRADADO,
				'motivo' => sprintf(
					/* translators: %s: nome da tabela. */
					__( 'a tabela %s não está pronta com as colunas desta versão: a rota continua registrada e responde 503 nomeando o motivo, para que a perda seja visível em vez de silenciosa.', 'f3base' ),
					self::nome_tabela()
				),
			);
		}

		return array(
			'estado' => self::ATIVO,
			'motivo' => sprintf(
				/* translators: 1: prazo de retenção em dias, 2: nome da tabela. */
				__( 'somando as visitas em %2$s e apagando o que passa de %1$d dia(s). Contam só as sessões em que o consentimento permitiu medição.', 'f3base' ),
				self::retencao_dias(),
				self::nome_tabela()
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function instalar(): void {
		self::criar_tabela();
	}

	/**
	 * MIGRAÇÃO NA REQUISIÇÃO SEGUINTE, e é por isso que ela existe.
	 *
	 * O gancho de ativação NÃO roda numa ATUALIZAÇÃO de plugin: um site que sai
	 * da 1.1.3 para a 1.1.4 sem desativar e reativar nunca chamaria
	 * `instalar()`, a tabela nunca nasceria, e o módulo ficaria degradado para
	 * sempre com a rota respondendo 503. O transiente é a guarda contra repetir
	 * o `dbDelta` a cada requisição enquanto a criação não tiver terminado.
	 *
	 * @return void
	 */
	public function garantir_estrutura(): void {
		if ( self::tabela_pronta() ) {
			return;
		}

		if ( false === set_transient( 'f3base_comportamento_migrando', 1, 15 * MINUTE_IN_SECONDS ) ) {
			return;
		}

		self::criar_tabela();
	}

	/* ------------------------------------------------------------------ *
	 * Configuração lida
	 * ------------------------------------------------------------------ */

	/**
	 * O resumo está ligado?
	 *
	 * @return bool
	 */
	public static function ligado(): bool {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		return ! empty( $config['ligado'] );
	}

	/**
	 * Prazo de guarda das linhas, em dias.
	 *
	 * @return int
	 */
	public static function retencao_dias(): int {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		return is_array( $config ) ? max( 1, (int) ( $config['retencao_dias'] ?? 90 ) ) : 90;
	}

	/**
	 * Período somado pelo quadro da tela, em dias.
	 *
	 * @return int
	 */
	public static function dias_no_painel(): int {
		$config = F3Base_Options::ler( 'f3base_comportamento' );

		return is_array( $config ) ? max( 1, (int) ( $config['dias_no_painel'] ?? 28 ) ) : 28;
	}

	/**
	 * O que o navegador precisa saber para enviar o resumo.
	 *
	 * Viaja DENTRO do mesmo objeto das tags, pelo mesmo portão: um segundo
	 * caminho até o navegador seria um segundo portão para manter e uma segunda
	 * chance de esquecer.
	 *
	 * @return array<string,mixed>
	 */
	public static function dados_do_cliente(): array {
		if ( ! self::ligado() ) {
			return array(
				'ativo'    => false,
				'endpoint' => '',
				'token'    => '',
				'maximo'   => 0,
			);
		}

		return array(
			'ativo'    => true,
			'endpoint' => esc_url_raw( rest_url( F3BASE_REST_NAMESPACE . self::ROTA ) ),
			'token'    => F3Base_Modulo_Endpoint_Leads::emitir_token(),
			'maximo'   => self::maximo_de_metricas(),
		);
	}

	/**
	 * Teto de linhas por sessão, DERIVADO da declaração — nunca digitado.
	 *
	 * O teto por página de cada evento já limita quantas vezes ele pode ser
	 * emitido; a soma deles é, por construção, o máximo de linhas distintas que
	 * uma visita pode produzir. Um número escrito aqui seria uma segunda
	 * verdade sobre a mesma coisa, e ela envelheceria na primeira linha
	 * acrescentada ao arquivo de declaração.
	 *
	 * @return int
	 */
	public static function maximo_de_metricas(): int {
		$soma = 0;

		if ( class_exists( 'F3Base_Modulo_Tracking' ) ) {
			foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $dados ) {
				$soma += (int) $dados['teto'];
			}
		}

		return max( 1, $soma );
	}

	/* ------------------------------------------------------------------ *
	 * Rota
	 * ------------------------------------------------------------------ */

	/**
	 * Registra a rota REST.
	 *
	 * @return void
	 */
	public function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'receber' ),
				'permission_callback' => '__return_true',
				'args'                => array(),
			)
		);
	}

	/**
	 * Schema FECHADO do corpo aceito.
	 *
	 * @return array<string,string>
	 */
	public static function campos(): array {
		return array(
			'token'    => 'token',
			'caminho'  => 'caminho',
			'metricas' => 'lista',
		);
	}

	/**
	 * Schema FECHADO de cada entrada da lista.
	 *
	 * @return array<string,string>
	 */
	public static function campos_da_metrica(): array {
		return array(
			'gatilho'  => 'chave',
			'detalhe'  => 'detalhe',
			'contagem' => 'inteiro',
			'soma'     => 'numero',
		);
	}

	/**
	 * Recebe o resumo de uma sessão.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function receber( WP_REST_Request $requisicao ): WP_REST_Response {
		if ( ! self::ligado() ) {
			return self::resposta(
				409,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_resumo_desligado',
					'motivo'     => __( 'O resumo de comportamento está desligado neste site: nada é somado e nada é guardado.', 'f3base' ),
				)
			);
		}

		$corpo = (string) $requisicao->get_body();

		if ( strlen( $corpo ) > self::MAX_BYTES ) {
			return self::resposta(
				413,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_corpo_grande',
					'limite'     => self::MAX_BYTES,
					'motivo'     => __( 'Corpo acima do limite declarado do endpoint.', 'f3base' ),
				)
			);
		}

		$bruto = $requisicao->get_json_params();

		if ( ! is_array( $bruto ) ) {
			$bruto = $requisicao->get_body_params();
		}

		if ( ! is_array( $bruto ) ) {
			$bruto = array();
		}

		$campos = self::campos();

		foreach ( array_keys( $bruto ) as $chave ) {
			if ( ! isset( $campos[ (string) $chave ] ) ) {
				return self::resposta(
					400,
					array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_campo_desconhecido',
						'campo'      => sanitize_key( (string) $chave ),
						'motivo'     => __( 'Campo fora do schema fechado do endpoint.', 'f3base' ),
					)
				);
			}
		}

		if ( ! F3Base_Modulo_Endpoint_Leads::validar_token( isset( $bruto['token'] ) ? (string) $bruto['token'] : '' ) ) {
			return self::resposta(
				403,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_token_invalido',
					'motivo'     => __( 'Token efêmero ausente, expirado ou com assinatura inválida.', 'f3base' ),
				)
			);
		}

		if ( ! self::dentro_do_rate_limit() ) {
			return self::resposta(
				429,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_rate_limit',
					'motivo'     => __( 'Limite de resumos por janela excedido para esta origem.', 'f3base' ),
				)
			);
		}

		$caminho = self::normalizar_caminho( isset( $bruto['caminho'] ) ? (string) $bruto['caminho'] : '' );

		if ( '' === $caminho ) {
			return self::resposta(
				400,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_caminho_invalido',
					'campo'      => 'caminho',
					'motivo'     => __( 'O caminho precisa ser um caminho deste site, começando por barra, sem query e sem fragmento.', 'f3base' ),
				)
			);
		}

		$linhas = self::validar_metricas( isset( $bruto['metricas'] ) ? $bruto['metricas'] : null );

		if ( isset( $linhas['erro'] ) ) {
			return self::resposta( 400, $linhas['erro'] );
		}

		if ( array() === $linhas['linhas'] ) {
			return self::resposta(
				200,
				array(
					'ok'         => true,
					'registrado' => false,
					'motivo'     => __( 'Sessão sem nenhum total a somar: nada foi gravado.', 'f3base' ),
				)
			);
		}

		if ( ! self::tabela_pronta() ) {
			return self::resposta(
				503,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_armazenamento_indisponivel',
					'tabela'     => self::nome_tabela(),
					'motivo'     => __( 'A tabela do resumo não está pronta com as colunas desta versão: nada foi somado. A perda é declarada em vez de silenciosa, e o módulo aparece como degradado na tela.', 'f3base' ),
				)
			);
		}

		$gravadas = 0;

		foreach ( $linhas['linhas'] as $linha ) {
			if ( self::somar( $caminho, (string) $linha['metrica'], (string) $linha['detalhe'], (int) $linha['contagem'], (float) $linha['soma'] ) ) {
				++$gravadas;
			}
		}

		if ( 0 === $gravadas ) {
			return self::resposta(
				503,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_gravacao_indisponivel',
					'tabela'     => self::nome_tabela(),
					'motivo'     => __( 'Nenhuma linha do resumo foi somada: o banco recusou a escrita. Nada foi guardado, e a próxima sessão tenta de novo.', 'f3base' ),
				)
			);
		}

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMO_COMPORTAMENTO,
			array(
				'caminho' => $caminho,
				'linhas'  => $gravadas,
			)
		);

		return self::resposta(
			201,
			array(
				'ok'         => true,
				'registrado' => true,
				'linhas'     => $gravadas,
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Validação
	 * ------------------------------------------------------------------ */

	/**
	 * O caminho da página, normalizado — ou string vazia quando não serve.
	 *
	 * @param string $bruto Caminho recebido.
	 * @return string
	 */
	public static function normalizar_caminho( string $bruto ): string {
		$bruto = trim( $bruto );

		if ( '' === $bruto ) {
			return '';
		}

		/* Query e fragmento não entram: é ali que mora o identificador colado por terceiro. */
		if ( str_contains( $bruto, '?' ) || str_contains( $bruto, '#' ) ) {
			return '';
		}

		if ( 1 !== preg_match( self::FORMA_CAMINHO, $bruto ) ) {
			return '';
		}

		/* `..` sairia da árvore do site e faria duas páginas somarem na mesma linha. */
		if ( str_contains( $bruto, '..' ) ) {
			return '';
		}

		return $bruto;
	}

	/**
	 * Valida a lista de totais contra o schema fechado e a declaração.
	 *
	 * @param mixed $bruto Lista recebida.
	 * @return array{linhas:array<int,array<string,mixed>>,erro?:array<string,mixed>}
	 */
	public static function validar_metricas( $bruto ): array {
		if ( ! is_array( $bruto ) ) {
			return array(
				'linhas' => array(),
				'erro'   => array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_metricas_invalidas',
					'campo'      => 'metricas',
					'motivo'     => __( 'O campo de totais precisa ser uma lista.', 'f3base' ),
				),
			);
		}

		$maximo = self::maximo_de_metricas();

		if ( count( $bruto ) > $maximo ) {
			return array(
				'linhas' => array(),
				'erro'   => array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_metricas_demais',
					'campo'      => 'metricas',
					'limite'     => $maximo,
					'motivo'     => __( 'A sessão trouxe mais totais do que o teto somado que a declaração de eventos permite por página.', 'f3base' ),
				),
			);
		}

		$declarados = class_exists( 'F3Base_Modulo_Tracking' )
			? F3Base_Modulo_Tracking::eventos_de_comportamento()
			: array();

		$por_gatilho = array();

		foreach ( $declarados as $nome => $dados ) {
			$por_gatilho[ (string) $dados['gatilho'] ] = (string) $nome;
		}

		$permitidos = self::campos_da_metrica();
		$linhas     = array();

		foreach ( $bruto as $entrada ) {
			if ( ! is_array( $entrada ) ) {
				return array(
					'linhas' => array(),
					'erro'   => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_metrica_invalida',
						'campo'      => 'metricas',
						'motivo'     => __( 'Cada total precisa ser um objeto com gatilho e contagem.', 'f3base' ),
					),
				);
			}

			foreach ( array_keys( $entrada ) as $chave ) {
				if ( ! isset( $permitidos[ (string) $chave ] ) ) {
					return array(
						'linhas' => array(),
						'erro'   => array(
							'ok'         => false,
							'registrado' => false,
							'codigo'     => 'f3base_campo_desconhecido',
							'campo'      => sanitize_key( (string) $chave ),
							'motivo'     => __( 'Campo fora do schema fechado de um total. O schema é fechado também DENTRO da lista: um campo novo aqui é um payload que ninguém decidiu que podia existir.', 'f3base' ),
						),
					);
				}
			}

			$gatilho = isset( $entrada['gatilho'] ) ? sanitize_key( (string) $entrada['gatilho'] ) : '';

			if ( ! isset( $por_gatilho[ $gatilho ] ) ) {
				return array(
					'linhas' => array(),
					'erro'   => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_gatilho_nao_declarado',
						'campo'      => 'gatilho',
						'motivo'     => __( 'Gatilho fora da declaração de eventos de comportamento: o nome do evento sai da declaração, e gatilho sem linha lá não vira medição nenhuma.', 'f3base' ),
					),
				);
			}

			$detalhe = isset( $entrada['detalhe'] ) ? trim( (string) $entrada['detalhe'] ) : '';

			if ( '' !== $detalhe && 1 !== preg_match( self::FORMA_DETALHE, $detalhe ) ) {
				return array(
					'linhas' => array(),
					'erro'   => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_detalhe_invalido',
						'campo'      => 'detalhe',
						'motivo'     => __( 'O detalhe está fora do alfabeto fechado: ele aceita host, nome de seção, marco e nome de métrica, e não aceita espaço, arroba, barra nem dois-pontos — que é o que impede caminho de arquivo, endereço e texto livre de chegarem aqui.', 'f3base' ),
					),
				);
			}

			$contagem = isset( $entrada['contagem'] ) ? (int) $entrada['contagem'] : 0;
			$soma     = isset( $entrada['soma'] ) && is_numeric( $entrada['soma'] ) ? (float) $entrada['soma'] : 0.0;

			if ( $contagem < 1 || ! is_finite( $soma ) || $soma < 0 ) {
				return array(
					'linhas' => array(),
					'erro'   => array(
						'ok'         => false,
						'registrado' => false,
						'codigo'     => 'f3base_total_invalido',
						'campo'      => 'contagem',
						'motivo'     => __( 'Contagem precisa ser inteiro positivo, e a soma precisa ser um número finito não negativo.', 'f3base' ),
					),
				);
			}

			$linhas[] = array(
				'metrica'  => $por_gatilho[ $gatilho ],
				'detalhe'  => $detalhe,
				'contagem' => $contagem,
				'soma'     => $soma,
			);
		}

		return array( 'linhas' => $linhas );
	}

	/**
	 * A origem está dentro do limite da janela?
	 *
	 * O balde é o MESMO mecanismo atômico do endpoint de leads — uma instrução,
	 * e quem soma é o banco. Uma segunda implementação aqui seria uma segunda
	 * regra para o mesmo risco, e a segunda é a que fica para trás.
	 *
	 * @return bool
	 */
	public static function dentro_do_rate_limit(): bool {
		$janela = max( 60, (int) apply_filters( 'f3base_comportamento_rate_limit_janela', 10 * MINUTE_IN_SECONDS ) );
		$limite = max( 1, (int) apply_filters( 'f3base_comportamento_rate_limit_maximo', 60 ) );

		$origem = F3Base_Modulo_Endpoint_Leads::origem();
		$chave  = hash( 'sha256', 'comportamento|' . $origem['valor'] . '|' . wp_salt( 'nonce' ) );

		return F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave, $janela ) <= $limite;
	}

	/* ------------------------------------------------------------------ *
	 * Armazenamento
	 * ------------------------------------------------------------------ */

	/**
	 * Nome completo da tabela.
	 *
	 * @return string
	 */
	public static function nome_tabela(): string {
		global $wpdb;

		return $wpdb->prefix . self::TABELA;
	}

	/**
	 * A tabela está PRONTA — existe e traz as colunas desta versão?
	 *
	 * @return bool
	 */
	public static function tabela_pronta(): bool {
		if ( null !== self::$tabela_pronta ) {
			return self::$tabela_pronta;
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$achado = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $tabela ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		if ( $achado !== $tabela ) {
			self::$tabela_pronta = false;

			return self::$tabela_pronta;
		}

		$colunas = $wpdb->get_col( "SHOW COLUMNS FROM {$tabela}" ); // phpcs:ignore WordPress.DB
		$colunas = is_array( $colunas ) ? array_map( 'strval', $colunas ) : array();

		self::$tabela_pronta = array() === array_diff( self::COLUNAS, $colunas );

		return self::$tabela_pronta;
	}

	/**
	 * Cria — ou migra — a tabela do resumo.
	 *
	 * TABELA PRÓPRIA, E NÃO OPTION. Contador diário cresce todo dia: uma option
	 * com o resumo dentro cresceria sem teto e, sendo autoload, seria lida em
	 * TODA requisição do site, inclusive nas que nada têm a ver com medição.
	 *
	 * @return void
	 */
	public static function criar_tabela(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$tabela  = self::nome_tabela();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$tabela} (
	chave char(64) NOT NULL,
	dia char(10) NOT NULL,
	caminho varchar(190) NOT NULL,
	metrica varchar(64) NOT NULL,
	detalhe varchar(60) NOT NULL DEFAULT '',
	contagem bigint(20) unsigned NOT NULL DEFAULT 0,
	soma double NOT NULL DEFAULT 0,
	atualizado_em bigint(20) unsigned NOT NULL DEFAULT 0,
	PRIMARY KEY  (chave),
	KEY dia (dia),
	KEY dia_metrica (dia,metrica)
) {$collate};";

		dbDelta( $sql );

		self::$tabela_pronta = null;
	}

	/**
	 * A chave da linha: dia, caminho, evento e detalhe, e nada mais.
	 *
	 * @param string $dia     Dia em Y-m-d.
	 * @param string $caminho Caminho da página.
	 * @param string $metrica Nome declarado do evento.
	 * @param string $detalhe Detalhe do evento.
	 * @return string
	 */
	public static function chave_da_linha( string $dia, string $caminho, string $metrica, string $detalhe ): string {
		return hash( 'sha256', $dia . '|' . $caminho . '|' . $metrica . '|' . $detalhe );
	}

	/**
	 * Soma um total na linha do dia, criando-a quando ela ainda não existe.
	 *
	 * DUAS SESSÕES SOMAM NA MESMA LINHA, e é o banco que soma: `INSERT … ON
	 * DUPLICATE KEY UPDATE` numa instrução só. Ler, somar e gravar em três
	 * passos perderia incrementos sob concorrência exatamente no horário de
	 * pico, que é quando o número importa.
	 *
	 * @param string $caminho  Caminho da página.
	 * @param string $metrica  Nome declarado do evento.
	 * @param string $detalhe  Detalhe do evento.
	 * @param int    $contagem Quantidade a somar.
	 * @param float  $soma     Valor a somar (vitais).
	 * @return bool
	 */
	public static function somar( string $caminho, string $metrica, string $detalhe, int $contagem, float $soma ): bool {
		if ( ! self::tabela_pronta() ) {
			return false;
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$dia    = gmdate( 'Y-m-d' );
		$chave  = self::chave_da_linha( $dia, $caminho, $metrica, $detalhe );
		$agora  = time();

		$anterior = $wpdb->suppress_errors( true );

		$linhas = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"INSERT INTO {$tabela} (chave, dia, caminho, metrica, detalhe, contagem, soma, atualizado_em) VALUES (%s, %s, %s, %s, %s, %d, %f, %d) ON DUPLICATE KEY UPDATE contagem = contagem + %d, soma = soma + %f, atualizado_em = %d", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave,
				$dia,
				$caminho,
				$metrica,
				$detalhe,
				$contagem,
				$soma,
				$agora,
				$contagem,
				$soma,
				$agora
			)
		);

		$wpdb->suppress_errors( $anterior );

		return false !== $linhas;
	}

	/**
	 * Apaga o que passou do prazo declarado.
	 *
	 * @return int Linhas eliminadas.
	 */
	public static function podar(): int {
		if ( ! self::tabela_pronta() ) {
			return 0;
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$corte  = gmdate( 'Y-m-d', time() - ( self::retencao_dias() * DAY_IN_SECONDS ) );

		$linhas = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$tabela} WHERE dia < %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$corte
			)
		);

		return is_numeric( $linhas ) ? (int) $linhas : 0;
	}

	/* ------------------------------------------------------------------ *
	 * Leitura
	 * ------------------------------------------------------------------ */

	/**
	 * O resumo do período, já agregado para leitura humana.
	 *
	 * @param int $dias Período em dias; zero usa o declarado na option.
	 * @return array{dias:int,desde:string,linhas:int,total:int,paginas:array<int,array<string,mixed>>,eventos:array<int,array<string,mixed>>,vitais:array<int,array<string,mixed>>}
	 */
	public static function resumo( int $dias = 0 ): array {
		$dias  = $dias > 0 ? $dias : self::dias_no_painel();
		$desde = gmdate( 'Y-m-d', time() - ( ( $dias - 1 ) * DAY_IN_SECONDS ) );

		$vazio = array(
			'dias'    => $dias,
			'desde'   => $desde,
			'linhas'  => 0,
			'total'   => 0,
			'paginas' => array(),
			'eventos' => array(),
			'vitais'  => array(),
		);

		if ( ! self::tabela_pronta() ) {
			return $vazio;
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$linhas = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT caminho, metrica, detalhe, SUM(contagem) AS total, SUM(soma) AS acumulado FROM {$tabela} WHERE dia >= %s GROUP BY caminho, metrica, detalhe", // phpcs:ignore WordPress.DB.PreparedSQL
				$desde
			),
			ARRAY_A
		);

		if ( ! is_array( $linhas ) || array() === $linhas ) {
			return $vazio;
		}

		$paginas = array();
		$eventos = array();
		$vitais  = array();
		$total   = 0;

		foreach ( $linhas as $linha ) {
			$caminho = (string) $linha['caminho'];
			$metrica = (string) $linha['metrica'];
			$detalhe = (string) $linha['detalhe'];
			$conta   = (int) $linha['total'];
			$acumula = (float) $linha['acumulado'];

			$total += $conta;

			$paginas[ $caminho ] = ( $paginas[ $caminho ] ?? 0 ) + $conta;

			$rotulo               = '' === $detalhe ? $metrica : $metrica . ' · ' . $detalhe;
			$eventos[ $rotulo ]   = ( $eventos[ $rotulo ] ?? 0 ) + $conta;

			if ( $acumula > 0.0 && '' !== $detalhe ) {
				$vitais[ $detalhe ] = $vitais[ $detalhe ] ?? array(
					'soma'  => 0.0,
					'conta' => 0,
				);

				$vitais[ $detalhe ]['soma']  += $acumula;
				$vitais[ $detalhe ]['conta'] += $conta;
			}
		}

		arsort( $paginas );
		arsort( $eventos );
		ksort( $vitais );

		$saida_paginas = array();

		foreach ( $paginas as $caminho => $conta ) {
			$saida_paginas[] = array(
				'caminho' => (string) $caminho,
				'total'   => (int) $conta,
			);
		}

		$saida_eventos = array();

		foreach ( $eventos as $rotulo => $conta ) {
			$saida_eventos[] = array(
				'rotulo' => (string) $rotulo,
				'total'  => (int) $conta,
			);
		}

		$saida_vitais = array();

		foreach ( $vitais as $nome => $dados ) {
			$saida_vitais[] = array(
				'metrica' => (string) $nome,
				'media'   => $dados['conta'] > 0 ? $dados['soma'] / $dados['conta'] : 0.0,
				'amostra' => (int) $dados['conta'],
			);
		}

		return array(
			'dias'    => $dias,
			'desde'   => $desde,
			'linhas'  => count( $linhas ),
			'total'   => $total,
			'paginas' => $saida_paginas,
			'eventos' => $saida_eventos,
			'vitais'  => $saida_vitais,
		);
	}

	/**
	 * Monta a resposta REST.
	 *
	 * @param int                 $status Código HTTP.
	 * @param array<string,mixed> $corpo  Corpo da resposta.
	 * @return WP_REST_Response
	 */
	private static function resposta( int $status, array $corpo ): WP_REST_Response {
		$corpo['fase'] = 'comportamento';

		return new WP_REST_Response( $corpo, $status );
	}
}
