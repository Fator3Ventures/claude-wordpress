<?php
/**
 * Módulo leads-whatsapp.
 *
 * Enfileira o JavaScript que monta a URL `wa.me` a partir de `f3base_contato`,
 * registra a interação e transporta a atribuição. O envio do registro é
 * `navigator.sendBeacon()` para o endpoint REST ANTES da navegação, fire and
 * forget: falha de registro nunca custa o lead nem atrasa a abertura da conversa.
 *
 * Sem o plugin ativo, o CTA degrada para link simples — o `href` do pattern do
 * tema continua respondendo; é este módulo que o promove a link profundo do
 * WhatsApp no servidor, para que o caminho sem JavaScript também funcione.
 *
 * COM o plugin ativo e SEM número gravado, o CTA não é publicado QUANDO ELE NÃO
 * TEM DESTINO NENHUM: botão que não leva a lugar nenhum é pior que não ter
 * botão. A regra da 1.0.19 suprimia qualquer bloco com a classe do CTA, e sob a
 * premissa de que as modificações futuras são do agente isso apagava trabalho
 * alheio — o `href` para uma landing, um `tel:` ou um formulário próprio sumia
 * da página sem erro e sem log. Desde a 1.1.0 a supressão só alcança o bloco que
 * ainda carrega o `href` do modelo, e a promoção só reescreve esse mesmo `href`:
 * **preenche quando falta, nunca sobrescreve o explícito.**
 *
 * E ELA RODA. O filtro `render_block` deste módulo é declarado `sempre` em
 * `hooks()` — é o único do pacote com a marca —, porque a decisão dele é POR
 * BLOCO e o caso mais importante dela acontece com o módulo INATIVO: sem número,
 * o botão do modelo não deve ir ao ar. Da 1.0.19 à 1.1.0 o filtro só era
 * registrado com o módulo ativo, isto é, quando a condição da supressão já não
 * podia acontecer, e a regra não rodava em site nenhum. O enfileiramento do
 * script continua sem a marca: módulo inativo não publica asset.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Comportamento do CTA de WhatsApp.
 */
final class F3Base_Modulo_Leads_Whatsapp extends F3Base_Modulo {

	/**
	 * Handle do script.
	 */
	public const HANDLE = 'f3base-leads';

	/**
	 * Atributo que marca um CTA de lead no HTML do tema.
	 */
	public const ATRIBUTO = 'data-f3base-lead';

	/**
	 * Atributo que este módulo carimba no `<a>` que ELE promoveu.
	 *
	 * O cliente lê este carimbo para saber que o `href` daquele link é do
	 * pacote: sem ele, o clique não toca no destino.
	 */
	public const ATRIBUTO_NUMERO = 'data-f3base-numero';

	/**
	 * CLASSE do CTA no markup do tema — o discriminante que não depende de nada.
	 *
	 * O atributo acima é carimbado pelo tema em `render_block`, e carimbar
	 * depende de `WP_HTML_Tag_Processor`. A classe está no ARQUIVO do pattern e
	 * existe sempre. É por ela que a decisão de PUBLICAR ou não o CTA é tomada:
	 * decidir pelo atributo deixaria o botão publicado justamente na instalação
	 * onde o processador não existe, que é o caso em que menos se quer surpresa.
	 */
	public const CLASSE_CTA = 'f3base-acao-contato';

	/**
	 * O `href` que o PATTERN DO TEMA entrega — o marcador do modelo.
	 *
	 * É o único destino que este módulo pode reescrever, junto com o vazio e o
	 * `#`. Ele é um LITERAL declarado, e não há como derivá-lo: depois que o
	 * conteúdo entra no banco, o bloco renderizado não carrega nenhuma marca de
	 * quem escreveu aquele `href` — o do pattern e o que o agente digitou chegam
	 * aqui iguais. Reconhecer o do modelo pelo valor é a única distinção
	 * possível, e ela é filtrável para quem trocar o pattern.
	 */
	public const HREF_DO_MODELO = '/contato/';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'leads-whatsapp';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Leads por WhatsApp', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Monta a URL wa.me a partir do número de contato, registra a interação por sendBeacon antes da navegação e transporta a atribuição. Sem JavaScript, o link profundo continua respondendo com a mensagem padrão.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 10,
				'args'       => 0,
			),
			/*
			 * SEMPRE, e este é o único hook do pacote com a marca. A decisão de
			 * `promover_cta()` é POR BLOCO, não pelo estado do módulo, e o caso
			 * mais importante dela acontece justamente com o módulo INATIVO: sem
			 * número gravado, o bloco do CTA que ainda tem o `href` do modelo não
			 * deve ser publicado. Da 1.0.19 à 1.1.0 este filtro só era registrado
			 * quando o módulo estava ativo — isto é, quando havia número —, e aí a
			 * condição da supressão já não podia acontecer: a regra estava escrita
			 * em três documentos e não rodava em site nenhum.
			 */
			array(
				'tipo'       => 'filter',
				'hook'       => 'render_block',
				'metodo'     => 'promover_cta',
				'prioridade' => 10,
				'args'       => 2,
				'sempre'     => true,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_contato', 'f3base_atribuicao' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$numero    = $this->numero();
		$processor = class_exists( 'WP_HTML_Tag_Processor' );

		return array(
			array(
				'rotulo'   => __( 'Número de WhatsApp em f3base_contato', 'f3base' ),
				'presente' => '' !== $numero,
				'detalhe'  => '' !== $numero
					? __( 'destino do link profundo resolvido pela option; é a presença deste valor que faz o regime existir.', 'f3base' )
					: __( 'sem número o CTA do modelo não é publicado; um CTA com destino próprio continua na página.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Slot de medição preenchido', 'f3base' ),
				'presente' => class_exists( 'F3Base_Modulo_Tracking' ) && F3Base_Modulo_Tracking::ha_slot_preenchido(),
				'detalhe'  => class_exists( 'F3Base_Modulo_Tracking' ) && F3Base_Modulo_Tracking::ha_slot_preenchido()
					? __( 'o clique do CTA é convertido nos canais declarados.', 'f3base' )
					: __( 'nenhum ID de GA4, Ads, Meta ou LinkedIn gravado: o clique é registrado no endpoint e não sai para canal nenhum.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Endpoint de registro de leads', 'f3base' ),
				'presente' => class_exists( 'F3Base_Modulo_Endpoint_Leads' ),
				'detalhe'  => __( 'origem do token efêmero assinado que o beacon carrega.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'WP_HTML_Tag_Processor', 'f3base' ),
				'presente' => $processor,
				'detalhe'  => $processor
					? __( 'promoção do href acontece no servidor, sem regex sobre HTML.', 'f3base' )
					: __( 'ausente: o href do pattern não é promovido no servidor.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_LEAD, __( 'Último lead registrado', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		if ( '' === $this->numero() ) {
			return $this->inativo(
				__( 'sem número de WhatsApp em f3base_contato o regime não existe neste site: nenhum script é enfileirado e nenhum href é reescrito. O filtro que decide a publicação do bloco continua registrado — ele é declarado SEMPRE, porque a decisão dele é por bloco —, e nele o CTA que ainda tem o href do modelo não é publicado, enquanto um CTA com destino próprio fica na página, intocado. Preencher o número faz o botão do modelo passar a existir na página seguinte, sem passo manual.', 'f3base' )
			);
		}

		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $this->degradado(
				__( 'WP_HTML_Tag_Processor indisponível nesta versão do WordPress: o caminho sem JavaScript não recebe o link profundo.', 'f3base' )
			);
		}

		return $this->ativo(
			__( 'CTA do modelo promovido no servidor, destino próprio preservado e registro enviado por beacon antes da navegação.', 'f3base' )
		);
	}

	/**
	 * Enfileira o script de leads e entrega a configuração como dado.
	 *
	 * @return void
	 */
	public function enfileirar(): void {
		$numero = $this->numero();

		if ( '' === $numero ) {
			return;
		}

		wp_enqueue_script(
			self::HANDLE,
			F3BASE_SITE_CORE_URL . 'assets/f3base-leads.js',
			array(),
			F3BASE_SITE_CORE_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		$atribuicao = F3Base_Options::ler( 'f3base_atribuicao' );

		wp_localize_script(
			self::HANDLE,
			'f3baseLeadsDados',
			array(
				'endpoint'      => esc_url_raw( rest_url( F3BASE_REST_NAMESPACE . '/lead' ) ),
				'token'         => F3Base_Modulo_Endpoint_Leads::emitir_token(),
				'numero'        => $numero,
				'mensagem'      => $this->mensagem_padrao(),
				'seletor'       => '[' . self::ATRIBUTO . ']',
				'atributo'      => self::ATRIBUTO,
				'atributoNumero' => self::ATRIBUTO_NUMERO,
				'hrefsDoModelo' => self::hrefs_do_modelo(),
				/*
				 * O TOKEN DO PRIMEIRO TOQUE VIAJA JUNTO, e não é uma
				 * duplicação: o navegador precisa comparar o modelo recebido
				 * com alguma coisa, e a alternativa é o script carregar o
				 * literal — que é a segunda fonte que este pacote persegue, só
				 * que numa linguagem onde nenhuma constante do PHP alcança.
				 * Mandando o token, quem compara e quem decide leem o MESMO
				 * valor, e ele sai de `F3Base_Vocabulario`.
				 */
				'atribuicao'    => array(
					'modelo'        => is_array( $atribuicao )
						? (string) ( $atribuicao['modelo'] ?? F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE )
						: F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE,
					'primeiroToque' => F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE,
					'ttlDias'       => is_array( $atribuicao ) ? (int) ( $atribuicao['ttl_dias'] ?? 30 ) : 30,
					'chave'         => 'f3base_atribuicao',
				),
				'limites'       => F3Base_Modulo_Endpoint_Leads::limites_publicos(),
				'medicao'       => class_exists( 'F3Base_Modulo_Tracking' ) ? F3Base_Modulo_Tracking::dados_de_medicao() : array(),
			)
		);
	}

	/**
	 * Os `href` que o PACOTE entrega, e os únicos que ele pode reescrever.
	 *
	 * Vazio e `#` entram porque não são destino nenhum; o marcador do modelo
	 * entra porque é o que o pattern do tema publica. Qualquer outro valor é
	 * destino de alguém, e destino de alguém vence o pacote.
	 *
	 * @return array<int,string>
	 */
	public static function hrefs_do_modelo(): array {
		$modelo = array( '', '#', self::HREF_DO_MODELO );

		/**
		 * Permite ao projeto declarar o `href` que o próprio pattern entrega.
		 *
		 * @param string[] $modelo Valores reconhecidos como do modelo.
		 */
		$modelo = apply_filters( 'f3base_cta_hrefs_do_modelo', $modelo );

		if ( ! is_array( $modelo ) ) {
			return array( '' );
		}

		$limpos = array();

		foreach ( $modelo as $valor ) {
			$limpos[] = self::normalizar_href( (string) $valor );
		}

		return array_values( array_unique( $limpos ) );
	}

	/**
	 * Normaliza um `href` para a comparação com o modelo.
	 *
	 * Espaço em volta e a barra final não distinguem destino: `/contato/` e
	 * `/contato` são o mesmo lugar, e tratá-los como diferentes deixaria o
	 * pacote publicar um botão do modelo achando que era do agente.
	 *
	 * @param string $href Valor bruto do atributo.
	 * @return string
	 */
	private static function normalizar_href( string $href ): string {
		return rtrim( trim( $href ), '/' );
	}

	/**
	 * Este `href` é do MODELO — vazio, `#` ou o marcador do pattern?
	 *
	 * @param mixed $href Valor lido do atributo (ausente vem como null).
	 * @return bool
	 */
	public static function e_do_modelo( $href ): bool {
		if ( ! is_string( $href ) ) {
			return true;
		}

		return in_array( self::normalizar_href( $href ), self::hrefs_do_modelo(), true );
	}

	/**
	 * O bloco tem um destino QUE NÃO É do modelo?
	 *
	 * A leitura é por varredura de texto, e não pelo `WP_HTML_Tag_Processor`, de
	 * propósito: esta é a decisão de PUBLICAR, e ela precisa valer igual na
	 * instalação em que o processador não existe — que é exatamente a instalação
	 * em que o atributo nunca é carimbado e a supressão cega mais machucaria.
	 * Ler não altera o HTML, e por isso a varredura basta.
	 *
	 * @param string $html HTML renderizado do bloco.
	 * @return bool
	 */
	public static function tem_destino_proprio( string $html ): bool {
		$achados = array();

		if ( false === preg_match_all( '/<a\b[^>]*>/i', $html, $achados ) ) {
			return false;
		}

		$ancoras = isset( $achados[0] ) && is_array( $achados[0] ) ? $achados[0] : array();

		foreach ( $ancoras as $ancora ) {
			if ( 1 !== preg_match( '/\shref\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s>]+))/i', $ancora, $par ) ) {
				continue;
			}

			$valor = '' !== ( $par[2] ?? '' ) ? $par[2] : ( '' !== ( $par[3] ?? '' ) ? $par[3] : ( $par[4] ?? '' ) );

			if ( ! self::e_do_modelo( html_entity_decode( $valor, ENT_QUOTES, 'UTF-8' ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * PUBLICA ou NÃO PUBLICA o CTA, e promove só o que é do modelo.
	 *
	 * A regra da 1.1.0, e ela tem dois lados que nunca se cruzam:
	 *
	 * - **Supressão.** O bloco só deixa de ser publicado quando não tem destino
	 *   nenhum: `href` vazio, `#` ou o marcador do modelo, E número vazio.
	 *   Publicar um botão que não leva a lugar nenhum é pior que não ter botão —
	 *   mas apagar um botão que leva a algum lugar é apagar trabalho de quem
	 *   veio depois, e é o que a 1.0.19 fazia com qualquer bloco da classe.
	 * - **Promoção.** O `href` só é reescrito quando é do modelo. `tel:`,
	 *   landing, formulário próprio, outro `wa.me`: fica como está, e o clique
	 *   continua sendo medido, porque medir não exige mandar no destino.
	 *
	 * O que decide a supressão é a CLASSE, que mora no arquivo do pattern; o
	 * atributo é carimbo de render e pode não existir. E o bloco filho é
	 * filtrado antes do pai, então quem sai é o botão — o grupo que o continha
	 * chega aqui já sem a classe e passa direto.
	 *
	 * @param string              $html  HTML renderizado do bloco.
	 * @param array<string,mixed> $bloco Bloco analisado.
	 * @return string HTML publicado — vazio quando o CTA não é publicado.
	 */
	public function promover_cta( string $html, array $bloco ): string {
		unset( $bloco );

		if ( ! str_contains( $html, self::CLASSE_CTA ) ) {
			return $html;
		}

		$numero  = $this->numero();
		$proprio = self::tem_destino_proprio( $html );

		if ( '' === $numero ) {
			return $proprio ? $html : '';
		}

		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $html;
		}

		if ( ! str_contains( $html, self::ATRIBUTO ) ) {
			return $html;
		}

		$processor = new WP_HTML_Tag_Processor( $html );
		$mudou     = false;

		while ( $processor->next_tag( array( 'tag_name' => 'A' ) ) ) {
			if ( null === $processor->get_attribute( self::ATRIBUTO ) ) {
				continue;
			}

			if ( ! self::e_do_modelo( $processor->get_attribute( 'href' ) ) ) {
				continue;
			}

			$mensagem = $processor->get_attribute( 'data-f3base-mensagem' );
			$mensagem = is_string( $mensagem ) && '' !== $mensagem ? $mensagem : $this->mensagem_padrao();

			/*
			 * ABA NOVA, e `noopener` junto. A conversa do WhatsApp acontece
			 * fora do site: levar a aba faz o visitante perder a página que
			 * estava lendo, e `noopener` impede que a janela aberta alcance a
			 * que a abriu.
			 */
			$processor->set_attribute( 'href', self::montar_url( $numero, $mensagem ) );
			$processor->set_attribute( 'target', '_blank' );
			$processor->set_attribute( 'rel', 'noopener' );
			$processor->set_attribute( self::ATRIBUTO_NUMERO, $numero );

			$mudou = true;
		}

		return $mudou ? $processor->get_updated_html() : $html;
	}

	/**
	 * Monta a URL `wa.me` com a mensagem.
	 *
	 * @param string $numero   Número em E.164 sem sinais.
	 * @param string $mensagem Mensagem inicial.
	 * @return string
	 */
	public static function montar_url( string $numero, string $mensagem ): string {
		$base = 'https://wa.me/' . rawurlencode( $numero );

		if ( '' === $mensagem ) {
			return $base;
		}

		return add_query_arg( 'text', rawurlencode( $mensagem ), $base );
	}

	/**
	 * Número de WhatsApp configurado.
	 *
	 * @return string
	 */
	private function numero(): string {
		$contato = F3Base_Options::ler( 'f3base_contato' );

		return is_array( $contato ) ? (string) ( $contato['whatsapp_e164'] ?? '' ) : '';
	}

	/**
	 * Mensagem padrão do CTA.
	 *
	 * @return string
	 */
	private function mensagem_padrao(): string {
		$contato  = F3Base_Options::ler( 'f3base_contato' );
		$mensagem = is_array( $contato ) ? trim( (string) ( $contato['mensagem_padrao'] ?? '' ) ) : '';

		if ( '' !== $mensagem ) {
			return $mensagem;
		}

		return sprintf(
			/* translators: %s: nome do site. */
			__( 'Olá! Vim pelo site %s e quero falar com a equipe.', 'f3base' ),
			wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES )
		);
	}
}
