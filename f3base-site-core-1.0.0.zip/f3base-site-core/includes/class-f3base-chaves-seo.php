<?php
/**
 * VOCABULÁRIO do plugin de SEO: os nomes das chaves, num lugar só.
 *
 * POR QUE ESTE ARQUIVO EXISTE. Os nomes de meta e de option do plugin de SEO são
 * fato do FORNECEDOR, e este pacote os toca dos dois lados: o IMPLANTADOR
 * ESCREVE a meta de cada conteúdo, e o `site-core` a LÊ — no noindex honrado e na
 * descrição de cada item do `llms.txt`. Enquanto quem escreve e quem lê não
 * compartilhavam fonte, uma renomeação do fornecedor quebrava os dois em lugares
 * diferentes: o implantador continuaria gravando o nome antigo e o site-core
 * continuaria lendo o nome antigo, cada um calado, e a única evidência seria uma
 * exclusão que nunca dispara e uma descrição que nunca aparece.
 *
 * A classe NÃO tem pai e NÃO usa nada do WordPress, pelo mesmo motivo de
 * `F3Base_Emissores` e de `F3Base_Censo_Demonstrativo`: ela roda em dois runtimes
 * que não se enxergam. O `site-core` a carrega pelo autoload declarado dele; o
 * implantador a alcança por `require_once` da cópia de origem em
 * `fontes/site-core/includes/`, que é ESTE arquivo antes do empacotamento. A
 * guarda de `class_exists` existe porque os dois caminhos de arquivo são
 * diferentes e `require_once` não os reconhece como o mesmo.
 *
 * O que NÃO mora aqui: qualquer decisão. Isto é vocabulário — quem decide o que
 * fazer com cada chave é o módulo que a lê ou o adaptador que a escreve.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'F3Base_Chaves_Seo' ) ) {

	/**
	 * Nomes de meta e de option do plugin de SEO.
	 */
	final class F3Base_Chaves_Seo {

		/**
		 * PREFIXO de toda meta do fornecedor. As demais saem dele.
		 */
		public const PREFIXO = '_yoast_wpseo_';

		/**
		 * Meta que guarda o noindex por conteúdo.
		 */
		public const NOINDEX = self::PREFIXO . 'meta-robots-noindex';

		/**
		 * Meta que guarda o nofollow por conteúdo.
		 */
		public const NOFOLLOW = self::PREFIXO . 'meta-robots-nofollow';

		/**
		 * Meta que guarda a descrição por conteúdo.
		 */
		public const DESCRICAO = self::PREFIXO . 'metadesc';

		/**
		 * Meta que guarda o título de busca por conteúdo.
		 */
		public const TITULO = self::PREFIXO . 'title';

		/**
		 * Meta que marca o conteúdo como pedra angular.
		 */
		public const CORNERSTONE = self::PREFIXO . 'is_cornerstone';

		/**
		 * Meta que guarda a frase-chave por conteúdo.
		 */
		public const FRASE_CHAVE = self::PREFIXO . 'focuskw';

		/**
		 * Option com os padrões por tipo e taxonomia.
		 */
		public const OPTION_TITULOS = 'wpseo_titles';

		/**
		 * Option com o noindex por termo.
		 */
		public const OPTION_TAXONOMIA = 'wpseo_taxonomy_meta';

		/**
		 * As metas por conteúdo que este pacote escreve OU lê, pelo nome.
		 *
		 * Serve a quem precisa varrer o conjunto — a suíte, por exemplo — em vez
		 * de repetir a lista. Uma segunda lista é a forma de a próxima chave
		 * entrar em um lado só.
		 *
		 * @return string[]
		 */
		public static function metas_de_conteudo(): array {
			return array(
				self::NOINDEX,
				self::NOFOLLOW,
				self::DESCRICAO,
				self::TITULO,
				self::CORNERSTONE,
				self::FRASE_CHAVE,
			);
		}
	}
}
