/**
 * F3 Base Site Core — consentimento.
 *
 * Política pré-aprovada por padrão: as tags carregam na chegada e o instrumento
 * do titular é o controle de revisão do rodapé, presente em toda página. A
 * negativa desliga e persiste pelo TTL declarado; o re-aceite religa.
 *
 * Consent Mode: `default` com `granted` na carga (política pré-aprovada) e
 * `update` para `denied` na negativa. O stub de `gtag()` fica definido em toda
 * página — consequência documentada: `typeof gtag === 'function'` passa a ser
 * verdadeiro sempre, e os eventos entram no dataLayer como comandos gtag. Até a
 * 1.0.19 esse era o fim da linha: nada carregava o `gtag.js`, e o comando ficava
 * no array esperando um consumidor que não existia. Desde a 1.1.0 quem consome é
 * o `f3base-tracking.js`, quando há ID gravado.
 *
 * Toda mudança de decisão dispara o evento de DOM `f3base-consentimento`: é por
 * ele que o carregador de tags religa na mesma navegação em que o visitante
 * mudou de ideia, em vez de esperar a próxima página.
 *
 * Sem JavaScript o controle não opera. A perda é declarada no relatório.
 *
 * Contrato de DOM: qualquer elemento com `data-f3base-consentimento` abre o
 * banner. O tema pode fornecer o controle na part do rodapé; sem ele, o
 * site-core imprime o próprio.
 *
 * O QUE MUDOU NA 1.1.3, e o defeito medido que a moveu. Até a 1.1.2 o painel
 * era construído no PRIMEIRO clique, com `caixa.hidden = true`, e o "Fechar"
 * voltava a pôr `hidden = true`. Só que `style.css` declarava
 * `.f3base-consentimento-painel { display: grid }` — e regra de AUTOR vence a
 * regra `[hidden] { display: none }` da folha do user agent, qualquer que seja
 * a especificidade. O `hidden` não tinha efeito nenhum: o painel cobria a tela
 * inteira e o "Fechar" não fechava. `aceitar` e `recusar` tinham um segundo
 * defeito, independente do CSS: gravavam o cookie e NÃO fechavam nada.
 *
 * As três consequências no desenho deste arquivo:
 *
 * 1. O banner é construído no `iniciar()`, FECHADO — e não no primeiro clique.
 *    É o que faz o `aria-controls` do controle apontar para um `id` que existe,
 *    e é o que torna o par (`hidden`, `display`) mensurável logo na carga.
 * 2. `fechar()` existe, é um lugar só, e os três botões passam por ele:
 *    `aceitar` e `recusar` gravam E fecham; `fechar` fecha sem decidir.
 * 3. O foco vai para o banner ao abrir e VOLTA para o controle que o abriu ao
 *    fechar. O banner não é modal (`aria-modal="false"`) e não prende o foco:
 *    a página continua inteira, atrás dele e ao lado dele.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseConsentimentoDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CATEGORIAS = Array.isArray(dados.categorias) && dados.categorias.length
		? dados.categorias
		: ['analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization'];

	var COOKIE = String(dados.cookie || 'f3base_consentimento');
	var TTL_DIAS = parseInt(dados.ttlDias, 10) > 0 ? parseInt(dados.ttlDias, 10) : 180;
	var PRE_APROVADO = String(dados.padrao || 'pre-aprovado') === 'pre-aprovado';
	var TEXTOS = dados.textos && typeof dados.textos === 'object' ? dados.textos : {};

	var ID_BANNER = String(dados.idBanner || 'f3base-consentimento-banner');
	var SELETOR_CONTROLE = String(dados.seletorControle || '[data-f3base-consentimento]');

	var banner = null;
	var aviso = null;
	var abridor = null;

	window.dataLayer = window.dataLayer || [];

	function gtag() {
		window.dataLayer.push(arguments);
	}

	if (typeof window.gtag !== 'function') {
		window.gtag = gtag;
	}

	function lerCookie(nome) {
		var partes = String(document.cookie || '').split(';');
		var i;
		var atual;

		for (i = 0; i < partes.length; i++) {
			atual = partes[i].replace(/^\s+/, '');
			if (atual.indexOf(nome + '=') === 0) {
				return decodeURIComponent(atual.substring(nome.length + 1));
			}
		}

		return '';
	}

	function gravarCookie(nome, valor, dias) {
		var seguro = window.location.protocol === 'https:' ? '; Secure' : '';
		document.cookie = nome + '=' + encodeURIComponent(valor) +
			'; Max-Age=' + (dias * 86400) +
			'; Path=/; SameSite=Lax' + seguro;
	}

	function decisaoGravada() {
		var valor = lerCookie(COOKIE);

		return (valor === 'granted' || valor === 'denied') ? valor : '';
	}

	function estadoAtual() {
		var decisao = decisaoGravada();

		if (decisao) {
			return decisao;
		}

		return PRE_APROVADO ? 'granted' : 'denied';
	}

	function mapa(estado) {
		var saida = {};
		var i;

		for (i = 0; i < CATEGORIAS.length; i++) {
			saida[CATEGORIAS[i]] = estado;
		}

		saida.functionality_storage = 'granted';
		saida.security_storage = 'granted';

		return saida;
	}

	function aplicarPadrao() {
		window.gtag('consent', 'default', mapa(estadoAtual()));
	}

	function atualizar(estado) {
		window.gtag('consent', 'update', mapa(estado));
		window.dataLayer.push({
			event: 'f3base_consentimento',
			f3base_consentimento_estado: estado
		});
	}

	/**
	 * Grava a decisão, avisa a página e FECHA o banner.
	 *
	 * O fecho faz parte da decisão, e não é enfeite: até a 1.1.2 esta função
	 * gravava o cookie, atualizava o Consent Mode e sincronizava o texto — e
	 * deixava a caixa exatamente onde estava. Para quem clicava, "Permitir" e
	 * "Desligar" eram dois botões inertes: tudo o que eles faziam acontecia
	 * fora da tela. `fecharAviso()` removia o aviso de primeira visita, que é
	 * OUTRO elemento, e nunca tocou no banner.
	 */
	function definir(estado) {
		var normalizado = estado === 'granted' ? 'granted' : 'denied';

		gravarCookie(COOKIE, normalizado, TTL_DIAS);
		atualizar(normalizado);
		anunciar(normalizado);
		sincronizarBanner();
		fecharAviso();
		fechar();

		return normalizado;
	}

	/**
	 * Anuncia a decisão à página, para quem carrega tag depois dela.
	 *
	 * Evento de DOM, e não chamada direta: o consentimento não pode conhecer os
	 * consumidores dele — quem conhece a lista de tags é o módulo de tracking, e
	 * uma chamada daqui para lá inverteria a dependência.
	 */
	function anunciar(estado) {
		try {
			document.dispatchEvent(new CustomEvent('f3base-consentimento', {
				detail: { estado: estado }
			}));
		} catch (erro) {
			// Navegador sem CustomEvent construível: a decisão vale na próxima página.
		}
	}

	function botao(rotulo, aoClicar, classe) {
		var elemento = document.createElement('button');

		elemento.type = 'button';
		elemento.className = classe;
		elemento.textContent = rotulo;
		elemento.addEventListener('click', aoClicar);

		return elemento;
	}

	/**
	 * Constrói o banner FECHADO, uma vez, na carga da página.
	 *
	 * A caixa interna existe porque a faixa ocupa a largura do viewport e o
	 * conteúdo não pode: `.f3base-consentimento-caixa` é a regra do tema que
	 * limita a medida e centraliza. Até a 1.1.2 essa regra existia no CSS e
	 * NENHUM elemento a carregava — regra órfã, e a razão de o painel aparecer
	 * como um fundo chapado sem caixa nenhuma.
	 */
	function construirBanner() {
		var faixa = document.createElement('div');
		var caixa = document.createElement('div');
		var titulo = document.createElement('h2');
		var texto = document.createElement('p');
		var estado = document.createElement('p');
		var acoes = document.createElement('div');

		faixa.id = ID_BANNER;
		faixa.className = 'f3base-consentimento-banner';
		faixa.setAttribute('role', 'dialog');
		faixa.setAttribute('aria-modal', 'false');
		faixa.setAttribute('aria-label', String(TEXTOS.titulo || 'Consentimento'));
		faixa.setAttribute('tabindex', '-1');
		faixa.hidden = true;

		caixa.className = 'f3base-consentimento-caixa';

		titulo.className = 'f3base-consentimento-titulo';
		titulo.textContent = String(TEXTOS.titulo || '');

		texto.className = 'f3base-consentimento-texto';
		texto.textContent = String(TEXTOS.explicacao || '');

		estado.className = 'f3base-consentimento-estado';

		acoes.className = 'f3base-consentimento-acoes';
		acoes.appendChild(botao(String(TEXTOS.aceitar || 'Permitir'), function () {
			definir('granted');
		}, 'f3base-consentimento-aceitar'));
		acoes.appendChild(botao(String(TEXTOS.recusar || 'Desligar'), function () {
			definir('denied');
		}, 'f3base-consentimento-recusar'));
		acoes.appendChild(botao(String(TEXTOS.fechar || 'Fechar'), function () {
			fechar();
		}, 'f3base-consentimento-fechar'));

		caixa.appendChild(titulo);
		caixa.appendChild(texto);
		caixa.appendChild(estado);

		if (dados.politicaUrl) {
			var link = document.createElement('a');
			link.className = 'f3base-consentimento-politica';
			link.href = String(dados.politicaUrl);
			link.textContent = String(TEXTOS.politica || 'Política de Privacidade');
			caixa.appendChild(link);
		}

		caixa.appendChild(acoes);
		faixa.appendChild(caixa);
		document.body.appendChild(faixa);

		banner = { faixa: faixa, estado: estado };

		sincronizarBanner();

		return banner;
	}

	function sincronizarBanner() {
		if (!banner) {
			return;
		}

		banner.estado.textContent = estadoAtual() === 'granted'
			? String(TEXTOS.estadoAtivo || '')
			: String(TEXTOS.estadoNegado || '');
	}

	/**
	 * Diz a cada controle do rodapé se o banner está aberto.
	 *
	 * `aria-expanded` é o que um leitor de tela anuncia; sem ele o visitante
	 * que aciona o controle uma segunda vez não tem como saber que aquilo que
	 * ele abriu continua aberto.
	 */
	function marcarControles(aberto) {
		var controles;
		var i;

		try {
			controles = document.querySelectorAll(SELETOR_CONTROLE);
		} catch (erro) {
			return;
		}

		for (i = 0; i < controles.length; i++) {
			controles[i].setAttribute('aria-expanded', aberto ? 'true' : 'false');
		}
	}

	/**
	 * Reserva, no corpo da página, exatamente a altura do banner.
	 *
	 * Sem isto a faixa fixa tampa o fim do documento — o rodapé, e com ele o
	 * próprio controle que a abriu — e o visitante não tem como rolar até lá.
	 * A medida sai do elemento renderizado; `0px` é o valor de repouso, e ele
	 * sai COM unidade porque é uma custom property consumida por `padding`.
	 */
	function reservarEspaco(aberto) {
		var raiz = document.documentElement;
		var altura;

		if (!raiz || !raiz.style) {
			return;
		}

		if (!aberto) {
			raiz.style.setProperty('--f3base-banner-altura', '0px');
			raiz.removeAttribute('data-f3base-banner');
			return;
		}

		altura = (banner && banner.faixa && banner.faixa.offsetHeight) || 0;

		raiz.style.setProperty('--f3base-banner-altura', altura + 'px');
		raiz.setAttribute('data-f3base-banner', 'aberto');
	}

	function abrir(origem) {
		if (!banner) {
			construirBanner();
		}

		abridor = origem || abridor;

		sincronizarBanner();
		banner.faixa.hidden = false;
		marcarControles(true);
		reservarEspaco(true);

		try {
			banner.faixa.focus();
		} catch (erro) {
			// Navegador que recusa foco em elemento com tabindex -1: o banner está aberto do mesmo jeito.
		}
	}

	/**
	 * Fecha o banner e DEVOLVE O FOCO a quem o abriu.
	 *
	 * Um lugar só, porque os três botões e o controle do rodapé precisam do
	 * mesmo comportamento. Sem a devolução do foco, quem fecha pelo teclado
	 * volta ao início do documento e perde o lugar onde estava lendo.
	 */
	function fechar() {
		if (!banner) {
			return;
		}

		banner.faixa.hidden = true;
		marcarControles(false);
		reservarEspaco(false);

		if (abridor && typeof abridor.focus === 'function') {
			try {
				abridor.focus();
			} catch (erro) {
				// Controle saiu do DOM entre abrir e fechar: nada a devolver.
			}
		}

		abridor = null;
	}

	function fecharAviso() {
		if (aviso && aviso.parentNode) {
			aviso.parentNode.removeChild(aviso);
			aviso = null;
		}
	}

	function mostrarAviso() {
		if (!dados.avisoPrimeiraVisita) {
			return;
		}

		if (decisaoGravada()) {
			return;
		}

		try {
			if (window.localStorage.getItem('f3base_aviso_visto') === '1') {
				return;
			}
			window.localStorage.setItem('f3base_aviso_visto', '1');
		} catch (erro) {
			// Armazenamento indisponível: o aviso aparece nesta visita e não persiste.
		}

		aviso = document.createElement('div');
		aviso.className = 'f3base-consentimento-aviso';
		aviso.setAttribute('role', 'status');

		var texto = document.createElement('span');
		texto.textContent = String(TEXTOS.aviso || '');
		aviso.appendChild(texto);

		if (dados.politicaUrl) {
			var link = document.createElement('a');
			link.href = String(dados.politicaUrl);
			link.textContent = String(TEXTOS.politica || '');
			aviso.appendChild(link);
		}

		aviso.appendChild(botao(String(TEXTOS.avisoOk || 'Ok'), fecharAviso, 'f3base-consentimento-aviso-ok'));
		aviso.appendChild(botao(String(TEXTOS.recusar || 'Desligar'), function () {
			definir('denied');
		}, 'f3base-consentimento-aviso-recusar'));

		document.body.appendChild(aviso);
	}

	function ligarControles() {
		document.addEventListener('click', function (evento) {
			var alvo = evento.target;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && alvo.matches && alvo.matches(SELETOR_CONTROLE)) {
					evento.preventDefault();
					abrir(alvo);
					return;
				}
				alvo = alvo.parentNode;
			}
		});
	}

	/**
	 * Esc fecha o banner, e essa é a única tecla que ele captura.
	 *
	 * Ele NÃO é modal: não prende o foco, não desliga o resto da página e não
	 * intercepta Tab. Um banner que prendesse o foco obrigaria o visitante a
	 * decidir antes de continuar lendo, que é exatamente o oposto da política
	 * pré-aprovada deste pacote.
	 */
	function ligarEscape() {
		document.addEventListener('keydown', function (evento) {
			if (!banner || banner.faixa.hidden) {
				return;
			}

			if (evento.key === 'Escape' || evento.keyCode === 27) {
				fechar();
			}
		});
	}

	function iniciar() {
		if (dados.controleRodape) {
			construirBanner();
			ligarControles();
			ligarEscape();
		}

		mostrarAviso();
	}

	aplicarPadrao();

	window.f3baseConsentimento = {
		estado: estadoAtual,
		definir: definir,
		abrir: abrir,
		fechar: fechar,
		permiteTags: function () {
			return estadoAtual() === 'granted';
		}
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', iniciar);
	} else {
		iniciar();
	}
}(window, document));
