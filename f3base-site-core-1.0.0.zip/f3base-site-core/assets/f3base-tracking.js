/**
 * F3 Base Site Core — carregador único das tags de medição.
 *
 * Este arquivo só chega ao HTML quando as duas condições fecham no servidor: há
 * DESTINO — pelo menos um ID de medição gravado OU o resumo de comportamento do
 * próprio site ligado — E o consentimento permite. A conferência de
 * consentimento é REFEITA aqui porque página em cache congela a decisão do
 * primeiro visitante: o servidor decide se o carregador entra, o navegador
 * decide se a tag carrega.
 *
 * SÃO DOIS DESTINOS, e eles são independentes. A conta de medição recebe evento
 * a evento, pelo `dataLayer`, e só existe com ID gravado. O site recebe o
 * RESUMO da sessão, agregado, uma vez, ao sair da página — e é dele que sai o
 * quadro da tela do plugin. Sem ID nenhum, nada vai para conta nenhuma; o
 * resumo continua sendo somado no próprio site, que era a metade que faltava
 * até a 1.1.3.
 *
 * UM CAMINHO, E UM SÓ. Com container do GTM preenchido, este arquivo emite o
 * contêiner e mais nada: as tags moram lá dentro, e emitir também a tag direta
 * contaria a mesma conversão duas vezes. Sem container, ele emite as tags
 * diretas dos IDs presentes — `gtag.js` servindo GA4 e Google Ads no mesmo
 * `gtag`, o Pixel da Meta e o Insight Tag do LinkedIn.
 *
 * O QUE ELE NÃO FAZ: disparar conversão. A conversão do clique é do
 * `f3base-leads.js`, que é onde o clique acontece — um lugar só, para que
 * acrescentar um canal não vire quatro edições.
 *
 * Pixel e Insight Tag NÃO TÊM modo de consentimento: para eles, negativa é
 * ausência. O `gtag` tem Consent Mode v2, e o estado default já foi empurrado
 * pelo `f3base-consentimento.js` antes deste arquivo rodar.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseTrackingDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CAMINHO = String(dados.caminho || 'nenhum');
	var carregado = false;

	window.dataLayer = window.dataLayer || [];

	/**
	 * O portão, do lado do navegador.
	 *
	 * Sem o objeto do consentimento na página não há o que consultar, e a
	 * ausência dele não pode virar bloqueio silencioso: o servidor já decidiu
	 * uma vez, e ele é a decisão de reserva.
	 */
	function permiteTags() {
		if (window.f3baseConsentimento && typeof window.f3baseConsentimento.permiteTags === 'function') {
			return window.f3baseConsentimento.permiteTags();
		}

		return true;
	}

	/**
	 * Insere um <script> externo uma vez só, pelo id declarado.
	 */
	function inserir(id, src) {
		if (document.getElementById(id)) {
			return;
		}

		var tag = document.createElement('script');

		tag.id = id;
		tag.async = true;
		tag.src = src;

		var primeiro = document.getElementsByTagName('script')[0];

		if (primeiro && primeiro.parentNode) {
			primeiro.parentNode.insertBefore(tag, primeiro);
		} else {
			document.head.appendChild(tag);
		}
	}

	function gtag() {
		window.dataLayer.push(arguments);
	}

	if (typeof window.gtag !== 'function') {
		window.gtag = gtag;
	}

	/**
	 * Caminho do contêiner: o GTM entra, e nada mais.
	 */
	function carregarGtm() {
		window.dataLayer.push({
			event: 'gtm.js',
			'gtm.start': new Date().getTime()
		});

		inserir('f3base-gtm', String(dados.origemGoogle) + 'gtm.js?id=' + encodeURIComponent(String(dados.gtm)));
	}

	/**
	 * gtag.js de verdade — GA4 e Google Ads na MESMA instância.
	 *
	 * O carregador é pedido com o primeiro ID presente; os `config` seguintes
	 * registram o resto. É assim que o fornecedor documenta duas contas no mesmo
	 * gtag, e é o que evita dois carregadores brigando pelo mesmo dataLayer.
	 */
	function carregarGoogleDireto() {
		var ga4 = String(dados.ga4 || '');
		var ads = dados.ads && typeof dados.ads === 'object' ? String(dados.ads.id || '') : '';
		var primeiro = ga4 || ads;

		if (!primeiro) {
			return;
		}

		inserir('f3base-gtag', String(dados.origemGoogle) + 'gtag/js?id=' + encodeURIComponent(primeiro));

		window.gtag('js', new Date());

		if (ga4) {
			window.gtag('config', ga4);
		}

		if (ads) {
			window.gtag('config', ads);
		}
	}

	/**
	 * Pixel da Meta, com o `fbq` na forma que o fornecedor consome.
	 */
	function carregarMeta() {
		var pixel = dados.meta && typeof dados.meta === 'object' ? String(dados.meta.pixelId || '') : '';

		if (!pixel) {
			return;
		}

		if (!window.fbq) {
			var fila = function () {
				if (fila.callMethod) {
					fila.callMethod.apply(fila, arguments);
				} else {
					fila.queue.push(arguments);
				}
			};

			fila.push = fila;
			fila.loaded = true;
			fila.version = '2.0';
			fila.queue = [];

			window.fbq = fila;
			window._fbq = window._fbq || fila;
		}

		inserir('f3base-meta-pixel', String(dados.meta.origem));

		window.fbq('init', pixel);
		window.fbq('track', 'PageView');
	}

	/**
	 * Insight Tag do LinkedIn — page view; a conversão é do clique.
	 */
	function carregarLinkedin() {
		var parceiro = dados.linkedin && typeof dados.linkedin === 'object' ? String(dados.linkedin.partnerId || '') : '';

		if (!parceiro) {
			return;
		}

		window._linkedin_partner_id = parceiro;
		window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];

		if (window._linkedin_data_partner_ids.indexOf(parceiro) === -1) {
			window._linkedin_data_partner_ids.push(parceiro);
		}

		inserir('f3base-linkedin-insight', String(dados.linkedin.origem));
	}


	/* =====================================================================
	 * INSTRUMENTAÇÃO DE COMPORTAMENTO
	 *
	 * A premissa da 1.1.3, nas palavras de quem a definiu: *"o site no
	 * WordPress já deve nascer instrumentado para validar e avaliar o
	 * comportamento dos usuários no site."* Até a 1.1.2 este pacote emitia
	 * `generate_lead`, `form_start` e `select_content` — tudo em torno da
	 * conversão. Nada dizia se a página era lida, onde o visitante parava, o
	 * que ele tentava clicar nem qual era a experiência real de carregamento.
	 *
	 * QUATRO REGRAS VALEM PARA TUDO O QUE ESTÁ AQUI:
	 *
	 * 1. **Mesmo portão das quatro tags.** Nada disto é instalado fora de
	 *    `carregar()`, que só roda com slot preenchido e consentimento vigente.
	 *    Sem `ga4_measurement_id` nem container, este arquivo nem chega ao HTML.
	 * 2. **Nenhum evento carrega dado pessoal.** Nem texto digitado, nem
	 *    seletor com valor, nem URL com query. As recusas estão nomeadas em
	 *    cada coletor, e quem varre o payload é `js.comportamento_instrumentado`.
	 * 3. **Teto por página, declarado.** Cada evento tem o seu na declaração, e
	 *    `podeEmitir()` é o único caminho até o `dataLayer`. Sem teto, uma
	 *    página faz o volume de um dia e a conta de medição amostra o excesso
	 *    em silêncio — o descarte é nosso e é declarado.
	 * 4. **Nenhum nome e nenhum número mora aqui.** Evento, parâmetro, marco,
	 *    janela, raio e teto saem todos de `dados.comportamento`, que o
	 *    servidor lê de `dados/eventos-comportamento.tsv`. Quem lê a série
	 *    histórica é um agente comparando períodos: nome que muda entre
	 *    releases é medição que sumiu sem erro nenhum.
	 * ================================================================== */

	var COMPORTAMENTO = dados.comportamento && typeof dados.comportamento === 'object'
		? dados.comportamento
		: { eventos: {}, prefixoSecao: '' };

	var EVENTOS = COMPORTAMENTO.eventos && typeof COMPORTAMENTO.eventos === 'object'
		? COMPORTAMENTO.eventos
		: {};

	var emitidos = {};
	var instrumentado = false;

	/* ==================================================================
	 * O RESUMO DA SESSÃO — o segundo destino, e o que ele NÃO carrega.
	 *
	 * A pergunta que ele responde: *"o site nasce instrumentado, onde posso
	 * ver os dados desta instrumentação."* Até a 1.1.3 a resposta era "na
	 * conta de medição, quando ela existir" — e com o slot vazio, em lugar
	 * nenhum. O resumo é a resposta de dentro do site.
	 *
	 * QUATRO RECUSAS, e nenhuma delas é boa vontade:
	 *
	 * 1. Nada é gravado no armazenamento do navegador. Não há id de sessão,
	 *    não há cookie: `resumoDaSessao` vive na memória desta aba e morre
	 *    com ela. O único estado é `resumoEnviado`, que existe para não
	 *    mandar duas vezes.
	 * 2. O caminho vai SEM QUERY e SEM FRAGMENTO — `location.pathname`, e
	 *    não `location.href`. É na query que a campanha de outra pessoa cola
	 *    o identificador do lead.
	 * 3. O detalhe passa por um ALFABETO FECHADO. Host de destino, nome de
	 *    seção, marco e nome de métrica passam; caminho de arquivo, endereço
	 *    de e-mail e texto livre não têm como passar, porque barra, arroba,
	 *    dois-pontos e espaço não estão no alfabeto. É por isso que o erro
	 *    de JavaScript entra como CONTAGEM e sem o arquivo: a página já é a
	 *    chave, e o arquivo interpolado é onde mora o valor do titular.
	 * 4. O cliente manda o GATILHO, nunca o nome do evento. Quem resolve o
	 *    nome é o servidor, contra a mesma declaração de sempre.
	 *
	 * O ENVIO É UM SÓ, no primeiro ocultamento da página, por `sendBeacon`.
	 * SEM `sendBeacon` A SESSÃO SE PERDE, e isso é declarado: a alternativa
	 * seria uma requisição que disputa a saída do visitante com a navegação
	 * dele, e um agregado perdido é mais barato que uma saída travada.
	 * ================================================================== */

	var RESUMO = dados.resumo && typeof dados.resumo === 'object'
		? dados.resumo
		: { ativo: false, endpoint: '', token: '', maximo: 0 };

	var resumoDaSessao = {};
	var linhasDoResumo = 0;
	var resumoEnviado = false;

	/**
	 * O detalhe de uma linha, ou string vazia quando o valor não é detalhe.
	 *
	 * A porta é a FORMA, e não uma lista de eventos: o mesmo teste recusa o
	 * caminho de arquivo do erro e aceita o host, a seção, o marco e o nome da
	 * métrica, sem que o cliente precise saber de qual coletor o valor veio.
	 */
	function detalheDe(valor) {
		var texto = (undefined === valor || null === valor) ? '' : String(valor);

		return /^[A-Za-z0-9][A-Za-z0-9._-]{0,59}$/.test(texto) ? texto : '';
	}

	/**
	 * Soma um disparo no resumo da sessão, sob o mesmo teto do dataLayer.
	 */
	function acumular(gatilho, valores) {
		var detalhe;
		var soma;
		var chave;

		if (!RESUMO.ativo) {
			return;
		}

		detalhe = detalheDe(valores[0]);
		soma = ('' !== detalhe && valores.length > 1 && 'number' === typeof valores[1] && isFinite(valores[1]))
			? valores[1]
			: 0;

		chave = gatilho + '|' + detalhe;

		if (!Object.prototype.hasOwnProperty.call(resumoDaSessao, chave)) {
			if (linhasDoResumo >= Number(RESUMO.maximo || 0)) {
				return;
			}

			resumoDaSessao[chave] = { gatilho: gatilho, detalhe: detalhe, contagem: 0, soma: 0 };
			linhasDoResumo = linhasDoResumo + 1;
		}

		resumoDaSessao[chave].contagem = resumoDaSessao[chave].contagem + 1;
		resumoDaSessao[chave].soma = resumoDaSessao[chave].soma + soma;
	}

	/**
	 * Manda o resumo da sessão UMA vez, e nunca mais nesta aba.
	 */
	function enviarResumo() {
		var metricas = [];
		var chave;
		var corpo;

		if (resumoEnviado || !RESUMO.ativo || !RESUMO.endpoint) {
			return;
		}

		resumoEnviado = true;

		for (chave in resumoDaSessao) {
			if (Object.prototype.hasOwnProperty.call(resumoDaSessao, chave)) {
				metricas.push(resumoDaSessao[chave]);
			}
		}

		if (!metricas.length) {
			return;
		}

		if (!window.navigator || typeof window.navigator.sendBeacon !== 'function') {
			return;
		}

		corpo = JSON.stringify({
			token: String(RESUMO.token || ''),
			caminho: String(window.location.pathname || '/'),
			metricas: metricas
		});

		try {
			window.navigator.sendBeacon(String(RESUMO.endpoint), new window.Blob([corpo], { type: 'application/json' }));
		} catch (erro) {
			// Medição nunca interrompe o fluxo do visitante.
		}
	}

	/**
	 * A declaração de um coletor, encontrada pelo GATILHO dele.
	 *
	 * O gatilho é a chave de junção entre o cliente e a declaração, e é por
	 * isso que ele é único no arquivo. O cliente NÃO conhece nome de evento:
	 * ele pede `rolagem` e recebe de volta o nome, os parâmetros e o teto. É
	 * isso que torna o nome do evento renomeável num lugar só, sem tocar em uma
	 * linha de JavaScript — e é isso que a série histórica precisa para
	 * sobreviver a uma release.
	 */
	function declaracao(gatilho) {
		var nome;

		for (nome in EVENTOS) {
			if (Object.prototype.hasOwnProperty.call(EVENTOS, nome) && EVENTOS[nome].gatilho === gatilho) {
				return { nome: nome, dados: EVENTOS[nome] };
			}
		}

		return null;
	}

	/**
	 * Um valor de limiar declarado, com o padrão de reserva.
	 *
	 * O padrão só existe para o caso de a declaração chegar truncada; ele nunca
	 * é o caminho normal, e por isso é o valor mais conservador possível —
	 * aquele que NÃO emite.
	 */
	function limiar(gatilho, chave, reserva) {
		var d = declaracao(gatilho);
		var lista = d && d.dados.limiar && d.dados.limiar[chave];

		return (lista && lista.length) ? lista : reserva;
	}

	function numeroDoLimiar(gatilho, chave, reserva) {
		var lista = limiar(gatilho, chave, null);
		var valor = lista ? parseFloat(lista[0]) : NaN;

		return isNaN(valor) ? reserva : valor;
	}

	/**
	 * O TETO, e ele é o único caminho até o `dataLayer`.
	 */
	function podeEmitir(nome, teto) {
		emitidos[nome] = (emitidos[nome] || 0) + 1;

		return emitidos[nome] <= teto;
	}

	/**
	 * O evento nos DOIS formatos, sempre — a mesma regra do `f3base-leads.js`.
	 *
	 * Objeto `{event: …}` é o que um container do GTM lê como gatilho; array de
	 * comando é o que o `gtag.js` consome. Emitir os dois faz a troca de
	 * caminho não perder nada.
	 *
	 * OS PARÂMETROS CHEGAM POSICIONALMENTE, e o nome de cada um vem da
	 * declaração. Duas consequências, e as duas são o ponto:
	 *
	 * - O coletor não escreve nome de parâmetro. Um valor a mais do que a
	 *   declaração prevê é DESCARTADO aqui, e não vaza para o `dataLayer`: a
	 *   porta é a lista declarada, não a boa intenção de quem escreve o
	 *   coletor. É essa porta que impede um payload novo de nascer sem que
	 *   ninguém tenha decidido que ele podia existir.
	 * - A ORDEM da coluna `parametros` no TSV é carregada. Trocar a ordem de
	 *   dois parâmetros lá troca o significado dos dois no relatório, e o
	 *   arquivo diz isso em voz alta. É o preço de o cliente não escrever nome
	 *   nenhum, e ele está declarado nos dois lugares.
	 */
	function emitir(gatilho, valores) {
		var d = declaracao(gatilho);
		var objeto;
		var limpos = {};
		var i;
		var chave;

		if (!d || !podeEmitir(d.nome, d.dados.teto)) {
			return false;
		}

		for (i = 0; i < d.dados.parametros.length && i < valores.length; i++) {
			if (undefined !== valores[i] && null !== valores[i]) {
				limpos[d.dados.parametros[i]] = valores[i];
			}
		}

		objeto = { event: d.nome };

		for (chave in limpos) {
			if (Object.prototype.hasOwnProperty.call(limpos, chave)) {
				objeto[chave] = limpos[chave];
			}
		}

		acumular(gatilho, valores);

		/*
		 * O SLOT VAZIO CONTINUA INERTE PARA A CONTA DE MEDIÇÃO. O resumo local
		 * é um destino; a conta de medição é outro, e sem ID nenhum ela não
		 * existe. Empurrar o evento no `dataLayer` aqui seria alimentar um
		 * container que ninguém carregou — e, no dia em que alguém carregasse
		 * um por fora, o site passaria a mandar dados para uma conta que este
		 * pacote nunca soube que existia.
		 */
		if (CAMINHO === 'nenhum') {
			return true;
		}

		try {
			window.dataLayer.push(objeto);
		} catch (erro) {
			// Medição nunca interrompe o fluxo do visitante.
		}

		if (typeof window.gtag === 'function') {
			try {
				window.gtag('event', d.nome, limpos);
			} catch (erro) {
				// Medição nunca interrompe o fluxo do visitante.
			}
		}

		return true;
	}

	/**
	 * O host de uma URL, ou string vazia quando ela não resolve.
	 *
	 * `new URL` com base: um `href` relativo resolve contra a página, que é
	 * exatamente o que faz um link interno ser reconhecido como interno.
	 */
	function hostDe(url) {
		try {
			return new window.URL(String(url), window.location.href).hostname || '';
		} catch (erro) {
			return '';
		}
	}

	/**
	 * MARCOS DE ROLAGEM — um evento por marco, nunca em rajada.
	 *
	 * A profundidade é medida sobre o documento inteiro, e o marco só dispara
	 * uma vez: o conjunto `vistos` é o que impede a rolagem para cima e para
	 * baixo de gerar uma sequência inteira a cada gesto. O ouvinte é passivo
	 * porque um ouvinte de rolagem que possa cancelar o evento trava a rolagem
	 * do visitante enquanto o coletor pensa.
	 */
	function instrumentarRolagem() {
		var GATILHO = 'rolagem';
		var marcos = limiar(GATILHO, 'marcos', []).map(Number).filter(function (n) {
			return !isNaN(n);
		});
		var vistos = {};

		if (!declaracao(GATILHO) || !marcos.length) {
			return;
		}

		function medir() {
			var doc = document.documentElement;
			var corpo = document.body;
			var altura = Math.max(
				(doc && doc.scrollHeight) || 0,
				(corpo && corpo.scrollHeight) || 0
			);
			var visivel = window.innerHeight || (doc && doc.clientHeight) || 0;
			var rolado = window.pageYOffset || (doc && doc.scrollTop) || 0;
			var util = altura - visivel;
			var percentual = util > 0 ? ((rolado / util) * 100) : 100;
			var i;

			for (i = 0; i < marcos.length; i++) {
				if (percentual >= marcos[i] && !vistos[marcos[i]]) {
					vistos[marcos[i]] = true;
					emitir(GATILHO, [ marcos[i] ]);
				}
			}
		}

		window.addEventListener('scroll', medir, { passive: true });
		medir();
	}

	/**
	 * SEÇÃO VISTA — o nome sai do markup, e só dele.
	 *
	 * A seção é nomeada por uma classe declarada (`prefixoSecao` + nome), que o
	 * tema carimba nos patterns. NÃO existe nome derivado de texto: um nome
	 * tirado do título mudaria sozinho na primeira revisão de copy, e a série
	 * histórica que um agente compara entre períodos passaria a ter uma seção
	 * nova e uma seção que sumiu, sem que nada tivesse mudado na página.
	 *
	 * Uma vez por NOME, e não por elemento: a mesma seção repetida na página é
	 * a mesma seção.
	 */
	function instrumentarSecoes() {
		var GATILHO = 'interseccao';
		var prefixo = String(COMPORTAMENTO.prefixoSecao || '');
		var visivel = numeroDoLimiar(GATILHO, 'visivel', 0.5);
		var vistas = {};
		var observador;
		var alvos;
		var i;

		if (!declaracao(GATILHO) || '' === prefixo || typeof window.IntersectionObserver !== 'function') {
			return;
		}

		function nomeDaSecao(elemento) {
			var tokens = String(elemento.className || '').split(/\s+/);
			var j;

			for (j = 0; j < tokens.length; j++) {
				if (tokens[j].indexOf(prefixo) === 0 && tokens[j].length > prefixo.length) {
					return tokens[j].slice(prefixo.length);
				}
			}

			return '';
		}

		observador = new window.IntersectionObserver(function (entradas) {
			var j;
			var secao;

			for (j = 0; j < entradas.length; j++) {
				if (!entradas[j].isIntersecting) {
					continue;
				}

				secao = nomeDaSecao(entradas[j].target);
				observador.unobserve(entradas[j].target);

				if ('' === secao || vistas[secao]) {
					continue;
				}

				vistas[secao] = true;
				emitir(GATILHO, [ secao ]);
			}
		}, { threshold: visivel });

		alvos = document.querySelectorAll('[class*="' + prefixo + '"]');

		for (i = 0; i < alvos.length; i++) {
			if ('' !== nomeDaSecao(alvos[i])) {
				observador.observe(alvos[i]);
			}
		}
	}

	/**
	 * CLIQUE EM LINK EXTERNO — o HOST de destino, e nunca a URL.
	 *
	 * A recusa é declarada e é a metade que importa: caminho e query são onde
	 * mora o identificador. `/perfil/joao-silva` no caminho; `?email=`,
	 * `?token=` ou `?id=` na query; e um `utm_content` que a campanha de outra
	 * pessoa preencheu com o id do lead. O host responde à pergunta que se faz
	 * — para onde o tráfego sai — sem carregar nada disso, e é a única parte da
	 * URL que não pode ser personalizada por visitante.
	 */
	function instrumentarLinksExternos() {
		var GATILHO = 'clique-externo';

		if (!declaracao(GATILHO)) {
			return;
		}

		document.addEventListener('click', function (evento) {
			var alvo = evento.target;
			var destino;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && 'A' === alvo.tagName && alvo.getAttribute('href')) {
					break;
				}

				alvo = alvo.parentNode;
			}

			if (!alvo || alvo === document.body || 'A' !== alvo.tagName) {
				return;
			}

			destino = hostDe(alvo.getAttribute('href'));

			if ('' === destino || destino === window.location.hostname) {
				return;
			}

			emitir(GATILHO, [ destino ]);
		}, true);
	}

	/**
	 * FRICÇÃO — cliques repetidos no mesmo ponto, e o falso positivo recusado.
	 *
	 * O LIMIAR É DECLARADO e cada número dele tem motivo. Quatro cliques, e não
	 * dois nem três: duplo clique é gesto normal de sistema e triplo clique é o
	 * gesto normal de selecionar um parágrafo — um limiar em 2 ou 3 marcaria
	 * como frustração o uso comum de qualquer página de texto. Janela curta,
	 * porque um reclique deliberado segundos depois é nova tentativa, não
	 * raiva. Raio pequeno, porque o mesmo ponto precisa ser o mesmo ponto: sem
	 * ele, percorrer uma lista de links acumularia cliques de lugares
	 * diferentes. E alvo INTERATIVO, porque o gesto de seleção de texto pousa
	 * em texto e não em controle.
	 *
	 * A RECUSA DECLARADA: o outro sinal de fricção — clique em elemento NÃO
	 * interativo, o "dead click" — não é implementado aqui, e não por
	 * esquecimento. Numa página de texto, todo triplo clique para selecionar um
	 * parágrafo, todo duplo clique acidental num título e todo toque para
	 * fechar o teclado no celular pousam em elemento não interativo. Separar
	 * isso de frustração exigiria um modelo de intenção que este pacote não
	 * tem, e um falso positivo ali polui exatamente o relatório que a medição
	 * existe para produzir. Sinal que não se sabe medir sem falso positivo é
	 * recusa declarada, nunca implementação torta.
	 */
	function instrumentarFriccao() {
		var GATILHO = 'clique-repetido';
		var alvoCliques = numeroDoLimiar(GATILHO, 'cliques', 0);
		var janela = numeroDoLimiar(GATILHO, 'janela_ms', 0);
		var raio = numeroDoLimiar(GATILHO, 'raio_px', 0);
		var interativo = 'interativo' === String(limiar(GATILHO, 'alvo', [''])[0]);
		var ultimo = null;

		if (!declaracao(GATILHO) || alvoCliques < 1 || janela <= 0 || raio <= 0) {
			return;
		}

		function controle(elemento) {
			if (!elemento || typeof elemento.closest !== 'function') {
				return null;
			}

			return elemento.closest('a[href],button,input,select,textarea,summary,[role="button"],[role="link"],[tabindex]');
		}

		document.addEventListener('click', function (evento) {
			var alvo = interativo ? controle(evento.target) : evento.target;
			var agora = Date.now();
			var x = evento.clientX || 0;
			var y = evento.clientY || 0;

			if (!alvo) {
				ultimo = null;
				return;
			}

			if (
				ultimo &&
				ultimo.alvo === alvo &&
				(agora - ultimo.quando) <= janela &&
				Math.abs(x - ultimo.x) <= raio &&
				Math.abs(y - ultimo.y) <= raio
			) {
				ultimo.contagem += 1;
				ultimo.quando = agora;
			} else {
				ultimo = { alvo: alvo, x: x, y: y, quando: agora, contagem: 1 };
			}

			if (ultimo.contagem >= alvoCliques) {
				emitir(GATILHO, [ ultimo.contagem ]);
				ultimo = null;
			}
		}, true);
	}

	/**
	 * ORIGEM de um erro: `site`, `terceiro` ou `ambiente`.
	 *
	 * O vocabulário é o mesmo que o documento mestre exige das sondas, e a
	 * regra é a do arquivo que falhou. Sem arquivo, ou com esquema de extensão
	 * do navegador, ou com a mensagem opaca que o navegador entrega para script
	 * de outra origem sem CORS: `ambiente`, porque a falha é do que o visitante
	 * carregou junto com a página. Host diferente do da página: `terceiro`.
	 * Mesma origem: `site`.
	 */
	function origemDoErro(arquivo) {
		var texto = String(arquivo || '');
		var host;

		if ('' === texto || /^[a-z-]+-extension:/i.test(texto) || 0 === texto.indexOf('about:')) {
			return 'ambiente';
		}

		host = hostDe(texto);

		if ('' === host) {
			return 'ambiente';
		}

		return host === window.location.hostname ? 'site' : 'terceiro';
	}

	/**
	 * ERRO DE JAVASCRIPT DO PRÓPRIO SITE — e a origem é o PORTÃO, não parâmetro.
	 *
	 * Só o que classifica como `site` vira evento. Terceiro e ambiente ficam
	 * de fora, e é por isso que um bloqueador de anúncio não enche o relatório:
	 * ele quebra o script do fornecedor, não o nosso. Um parâmetro de origem
	 * seria peso morto — ele só poderia dizer `site`, e chave que nunca pode
	 * discordar do próprio dado é a mesma doença que a 1.1.2 tirou do regime de
	 * tracking.
	 *
	 * A MENSAGEM NÃO ENTRA, e essa é a recusa que protege o titular: ela
	 * carrega o valor interpolado que produziu o erro, e esse valor pode ser o
	 * e-mail digitado no formulário. O que entra é o caminho de mesma origem —
	 * sem query e sem fragmento, pelo mesmo motivo do link externo — e a linha.
	 *
	 * `unhandledrejection` NÃO é ouvido, e a recusa é declarada: promessa
	 * rejeitada não carrega arquivo nem linha em navegador nenhum, então a
	 * origem dela não é decidível — e evento cuja origem não é decidível é
	 * exatamente o que enche o relatório de erro que não é nosso.
	 */
	function instrumentarErros() {
		var GATILHO = 'erro';
		var vistos = {};

		if (!declaracao(GATILHO) || 'site' !== String(limiar(GATILHO, 'origem', [''])[0])) {
			return;
		}

		window.addEventListener('error', function (evento) {
			var arquivo = evento && evento.filename ? String(evento.filename) : '';
			var linha = evento && evento.lineno ? parseInt(evento.lineno, 10) : 0;
			var caminho;
			var chave;

			if ('site' !== origemDoErro(arquivo)) {
				return;
			}

			try {
				caminho = new window.URL(arquivo, window.location.href).pathname;
			} catch (erro) {
				return;
			}

			chave = caminho + ':' + linha;

			if (vistos[chave]) {
				return;
			}

			vistos[chave] = true;

			emitir(GATILHO, [ caminho.slice(0, 100), linha ]);
		});
	}

	/**
	 * CORE WEB VITALS DE CAMPO — `PerformanceObserver` nativo, sem biblioteca.
	 *
	 * A política de origem declarada deste pacote não admite CDN de terceiro, e
	 * o peso de uma biblioteca de medição é pago pelo visitante em toda página.
	 * As quatro métricas saem das APIs nativas: LCP e CLS e INP de
	 * `PerformanceObserver`, TTFB do `PerformanceNavigationTiming`.
	 *
	 * O VALOR SAI CRU, sem classificação, e a recusa é declarada: os cortes de
	 * bom/precisa-melhorar/ruim são do fornecedor e mudam por calendário.
	 * Embuti-los aqui faria o relatório deste site discordar do console do
	 * fornecedor no dia em que eles se movessem, sem uma linha dizendo por quê
	 * — e quem classifica no destino tem o corte vigente, que nós não temos.
	 *
	 * O RELATO É NO PRIMEIRO OCULTAMENTO da página, e uma vez só: LCP, CLS e
	 * INP só têm valor final quando o visitante para de interagir, e relatar
	 * antes disso mandaria um número que ainda ia mudar.
	 */
	function instrumentarVitais() {
		var GATILHO = 'desempenho';
		var vitais = limiar(GATILHO, 'vitais', []);
		var duracaoMinima = numeroDoLimiar(GATILHO, 'duracao_minima_ms', 16);
		var medidos = { LCP: null, CLS: 0, INP: null, TTFB: null };
		var relatado = false;

		if (!declaracao(GATILHO) || !vitais.length || typeof window.PerformanceObserver !== 'function') {
			return;
		}

		function observar(tipo, aoEntrar, extras) {
			var opcoes = { type: tipo, buffered: true };
			var chave;

			for (chave in extras) {
				if (Object.prototype.hasOwnProperty.call(extras, chave)) {
					opcoes[chave] = extras[chave];
				}
			}

			try {
				new window.PerformanceObserver(function (lista) {
					var entradas = lista.getEntries();
					var i;

					for (i = 0; i < entradas.length; i++) {
						aoEntrar(entradas[i]);
					}
				}).observe(opcoes);
			} catch (erro) {
				// Navegador sem este tipo de entrada: a métrica não é relatada, e nenhuma outra se perde.
			}
		}

		observar('largest-contentful-paint', function (entrada) {
			medidos.LCP = entrada.startTime;
		});

		observar('layout-shift', function (entrada) {
			if (!entrada.hadRecentInput) {
				medidos.CLS += entrada.value;
			}
		});

		observar('event', function (entrada) {
			if (entrada.interactionId && (null === medidos.INP || entrada.duration > medidos.INP)) {
				medidos.INP = entrada.duration;
			}
		}, { durationThreshold: duracaoMinima });

		try {
			var navegacao = window.performance.getEntriesByType('navigation')[0];

			if (navegacao) {
				medidos.TTFB = navegacao.responseStart;
			}
		} catch (erro) {
			// Sem Navigation Timing não há TTFB, e as outras três continuam.
		}

		function relatar() {
			var i;
			var chave;
			var valor;

			if (relatado) {
				return;
			}

			relatado = true;

			for (i = 0; i < vitais.length; i++) {
				chave = vitais[i];
				valor = medidos[chave];

				if (null === valor || typeof valor !== 'number' || isNaN(valor)) {
					continue;
				}

				emitir(GATILHO, [
					chave,
					'CLS' === chave ? Math.round(valor * 1000) / 1000 : Math.round(valor)
				]);
			}
		}

		document.addEventListener('visibilitychange', function () {
			if ('hidden' === document.visibilityState) {
				relatar();
			}
		});

		window.addEventListener('pagehide', relatar);
	}

	/**
	 * Instala os coletores, uma vez, DEPOIS do portão.
	 */
	function instrumentar() {
		if (instrumentado) {
			return;
		}

		instrumentado = true;

		instrumentarRolagem();
		instrumentarSecoes();
		instrumentarLinksExternos();
		instrumentarFriccao();
		instrumentarErros();
		instrumentarVitais();
		instrumentarResumo();
	}

	/**
	 * O ENVIO DO RESUMO, e ele é o ÚLTIMO ouvinte instalado de propósito.
	 *
	 * Os vitais são relatados no primeiro ocultamento da página, e o relato
	 * deles PASSA por `emitir()` — que é onde o resumo soma. Um ouvinte
	 * instalado antes do deles despacharia a sessão sem LCP, CLS, INP e TTFB,
	 * e o quadro da tela mostraria "sem amostra" para as quatro métricas que
	 * mais interessam, para sempre e sem erro nenhum.
	 */
	function instrumentarResumo() {
		if (!RESUMO.ativo) {
			return;
		}

		document.addEventListener('visibilitychange', function () {
			if ('hidden' === document.visibilityState) {
				enviarResumo();
			}
		});

		window.addEventListener('pagehide', enviarResumo);
	}

	function carregar() {
		/*
		 * O SLOT VAZIO É INERTE TAMBÉM AQUI, e a redundância é deliberada — a
		 * mesma razão pela qual `permiteTags()` é reconferido no navegador. O
		 * servidor já não enfileira este arquivo com o caminho `nenhum`, mas a
		 * instrumentação de comportamento não depende de ID nenhum para
		 * funcionar: sem esta guarda, um dia em que o arquivo chegasse à página
		 * por outro caminho — cache, concatenador, um plugin que enfileira
		 * assets de terceiro — o site passaria a emitir comportamento sem ter
		 * uma conta de medição para recebê-lo. A regra é a mesma das tags:
		 * slot vazio, nada acontece.
		 */
		if (carregado || !permiteTags()) {
			return;
		}

		/*
		 * SEM DESTINO NENHUM, TUDO CONTINUA INERTE. A guarda da 1.1.3 valia
		 * quando o único destino era a conta de medição: com o slot vazio, o
		 * site emitiria comportamento sem ninguém para recebê-lo. Na 1.1.4 o
		 * próprio site é um destino, com tabela e prazo — então a pergunta
		 * deixou de ser "há ID?" e passou a ser "há destino?". Sem os dois,
		 * nada é instalado e nada é emitido, exatamente como antes.
		 */
		if (CAMINHO === 'nenhum' && !RESUMO.ativo) {
			return;
		}

		carregado = true;

		/*
		 * A INSTRUMENTAÇÃO ENTRA ANTES DA BIFURCAÇÃO, e de propósito: o
		 * caminho do container termina em `return`, e instalá-la depois dele
		 * deixaria todo site com GTM sem medição de comportamento — um ramo
		 * esquecido que nada acusaria, porque a página continuaria emitindo as
		 * tags normalmente.
		 */
		instrumentar();

		if (CAMINHO === 'gtm') {
			carregarGtm();
			return;
		}

		if (CAMINHO === 'direto') {
			carregarGoogleDireto();
			carregarMeta();
			carregarLinkedin();
		}
	}

	/*
	 * O re-aceite religa NESTA navegação. Sem este ouvinte, quem negava, mudava
	 * de ideia no controle do rodapé e ficava na mesma página não era medido até
	 * navegar — e a decisão que o visitante acabou de tomar é a que vale.
	 */
	document.addEventListener('f3base-consentimento', function () {
		carregar();
	});

	window.f3baseTracking = {
		caminho: function () {
			return CAMINHO;
		},
		carregar: carregar,
		permiteTags: permiteTags,
		eventos: function () {
			return EVENTOS;
		},
		emitidos: function () {
			return emitidos;
		},
		resumo: function () {
			return resumoDaSessao;
		}
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', carregar);
	} else {
		carregar();
	}
}(window, document));
