/**
 * F3 Base Site Core — o clique do CTA: destino, registro e conversão.
 *
 * Três coisas acontecem aqui, nesta ordem, e nenhuma bloqueia a navegação:
 *
 * 1. **Destino.** O `href` só é montado por este arquivo quando ele é DO MODELO
 *    — vazio, `#` ou o marcador que o pattern do tema entrega — ou quando o
 *    servidor carimbou o link como promovido por ele. `tel:`, landing,
 *    formulário próprio: o destino fica como está. Até a 1.0.19 o clique
 *    reescrevia o `href` sem olhar, e sob a premissa de que as modificações
 *    futuras são do agente isso desfazia trabalho alheio a cada clique.
 * 2. **Registro.** `navigator.sendBeacon()` para o endpoint REST, fire and
 *    forget: falha de registro nunca custa o lead nem atrasa a conversa.
 * 3. **Conversão.** O clique é a conversão deste site — o formulário é
 *    opcional, o clique é o lead — e ela sai para os quatro canais de um lugar
 *    só: `generate_lead` no GA4, `conversion` com `send_to` no Google Ads,
 *    `Lead` com `eventID` no Pixel da Meta e `track` no LinkedIn. Cada um sai
 *    apenas com o ID gravado; slot vazio não dispara nada.
 *
 * CAMINHO ÚNICO. Com container do GTM declarado, os disparos DIRETOS não
 * acontecem: o container os faz a partir dos eventos em objeto que este arquivo
 * empurra no `dataLayer`. Disparar dos dois lados contaria a mesma conversão
 * duas vezes, e conversão em dobro reescreve o lance do leilão.
 *
 * Honestidade do desenho: o registro é melhor esforço — bloqueador derruba
 * beacon. A conversa no WhatsApp continua sendo a fonte da verdade do lead.
 *
 * Identificadores com nome honesto: o `correlation_id` nasce aqui, no navegador,
 * com fonte criptograficamente segura; o `record_id` nasce no servidor. O mesmo
 * `correlation_id` amarra registro, mensagem do `wa.me`, evento e a
 * deduplicação do `eventID` da Meta.
 *
 * Contrato de DOM (fornecido pelo pattern do tema):
 *   a[data-f3base-lead]              CTA. O valor é o id do formulário do fluxo.
 *   [data-f3base-form="<seletor>"]   seletor do formulário associado, opcional.
 *   [data-f3base-mensagem]           mensagem própria do CTA, opcional.
 *   [data-f3base-campo="nome"]       campo do formulário associado.
 *   [data-f3base-honeypot]           campo isca, que precisa chegar vazio.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseLeadsDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CAMPOS = ['nome', 'email', 'telefone', 'mensagem'];
	var LIMITES = dados.limites && typeof dados.limites === 'object' ? dados.limites : {};
	var ATRIBUICAO = dados.atribuicao && typeof dados.atribuicao === 'object' ? dados.atribuicao : {};
	var CHAVE_ATRIBUICAO = String(ATRIBUICAO.chave || 'f3base_atribuicao');
	var TTL_ATRIBUICAO = parseInt(ATRIBUICAO.ttlDias, 10) > 0 ? parseInt(ATRIBUICAO.ttlDias, 10) : 30;
	/*
	 * O TOKEN DO PRIMEIRO TOQUE CHEGA DO SERVIDOR, e o script não o escreve.
	 * Escrito aqui, ele seria uma segunda fonte do mesmo vocabulário numa
	 * linguagem onde nenhuma constante do PHP alcança: o catálogo poderia
	 * trocar de modelo e este arquivo continuaria comparando com o antigo,
	 * sem erro nenhum — a atribuição só passaria a guardar o toque errado.
	 * Sem o token, nada é primeiro toque, que é o lado seguro: a atribuição
	 * passa a sobrescrever e nenhuma origem é inventada.
	 */
	var TOKEN_PRIMEIRO_TOQUE = String(ATRIBUICAO.primeiroToque || '');
	var PRIMEIRO_TOQUE = TOKEN_PRIMEIRO_TOQUE !== '' && String(ATRIBUICAO.modelo || '') === TOKEN_PRIMEIRO_TOQUE;
	var ATRIBUTO_NUMERO = String(dados.atributoNumero || 'data-f3base-numero');
	var HREFS_DO_MODELO = Array.isArray(dados.hrefsDoModelo) ? dados.hrefsDoModelo.map(String) : ['', '#'];
	var MEDICAO = dados.medicao && typeof dados.medicao === 'object' ? dados.medicao : {};
	var CAMINHO = String(MEDICAO.caminho || 'nenhum');
	var ADS = MEDICAO.ads && typeof MEDICAO.ads === 'object' ? MEDICAO.ads : {};
	var META = MEDICAO.meta && typeof MEDICAO.meta === 'object' ? MEDICAO.meta : {};
	var LINKEDIN = MEDICAO.linkedin && typeof MEDICAO.linkedin === 'object' ? MEDICAO.linkedin : {};

	var registrados = {};
	var iniciados = {};

	window.dataLayer = window.dataLayer || [];

	function correlationId() {
		var bytes = new Uint8Array(8);
		var saida = '';
		var i;

		if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
			window.crypto.getRandomValues(bytes);
		} else {
			for (i = 0; i < bytes.length; i++) {
				bytes[i] = Math.floor(Math.random() * 256);
			}
		}

		for (i = 0; i < bytes.length; i++) {
			saida += ('0' + bytes[i].toString(16)).slice(-2);
		}

		return saida;
	}

	/**
	 * Comprimento em CARACTERES, e não em unidades UTF-16.
	 *
	 * `'coração'.length` é 7 e `Array.from('coração').length` também — mas um
	 * emoji conta 2 pela primeira medida e 1 pela segunda. A unidade tem de ser
	 * a MESMA dos dois lados: o servidor mede caracteres, publica o limite em
	 * caracteres por `limites_publicos()` e recusa por caractere.
	 */
	function caracteres(texto) {
		return Array.from(texto);
	}

	/**
	 * Corta pelo limite publicado, na unidade publicada.
	 *
	 * O corte por `slice()` fatia unidades UTF-16: um limite alcançado no meio
	 * de um par substituto devolveria metade de um caractere, e o servidor
	 * receberia texto que ninguém escreveu.
	 */
	function limitar(nome, valor) {
		var limite = parseInt(LIMITES[nome], 10);
		var texto = String(valor == null ? '' : valor);
		var letras;

		if (limite > 0) {
			letras = caracteres(texto);

			if (letras.length > limite) {
				return letras.slice(0, limite).join('');
			}
		}

		return texto;
	}

	/**
	 * Normaliza um `href` para a comparação com o modelo.
	 *
	 * A MESMA regra do servidor, e de propósito: espaço em volta e barra final
	 * não distinguem destino, e tratá-los como diferentes faria o cliente
	 * reescrever um link que o servidor tinha deixado em paz.
	 */
	function normalizarHref(href) {
		return String(href == null ? '' : href).trim().replace(/\/+$/, '');
	}

	/**
	 * Este `href` é do MODELO — o que o pacote pode reescrever?
	 */
	function eDoModelo(href) {
		if (href == null) {
			return true;
		}

		return HREFS_DO_MODELO.indexOf(normalizarHref(href)) !== -1;
	}

	/**
	 * O gatilho tem destino PRÓPRIO — de alguém que não é este pacote?
	 *
	 * O carimbo do servidor decide primeiro: link que ELE promoveu é dele, e o
	 * `wa.me` que está ali veio deste mesmo desenho. Sem carimbo, decide o
	 * `href`: do modelo é do pacote, qualquer outra coisa é de quem escreveu.
	 */
	function temDestinoProprio(gatilho) {
		if (gatilho.getAttribute(ATRIBUTO_NUMERO)) {
			return false;
		}

		return !eDoModelo(gatilho.getAttribute('href'));
	}

	/**
	 * Carimbo em segundos, como o servidor o guarda.
	 */
	function agora() {
		return String(Math.floor(Date.now() / 1000));
	}

	function lerCookie(nome) {
		var partes = String(document.cookie || '').split(';');
		var i;
		var atual;

		for (i = 0; i < partes.length; i++) {
			atual = partes[i].replace(/^\s+/, '');
			if (atual.indexOf(nome + '=') === 0) {
				return decodeURIComponent(atual.substring(nome.length + 1));
			}
		}

		return '';
	}

	/**
	 * Grava o cookie `_fbc` a partir do `fbclid`, no formato que a Meta declara.
	 *
	 * `fb.<subdomínios>.<carimbo em ms>.<fbclid>` — o `1` do meio é o número de
	 * pontos do domínio que a Meta usa como padrão na própria documentação. O
	 * cookie existente NUNCA é sobrescrito: ele carrega o primeiro clique, que é
	 * o que a deduplicação da Conversions API espera receber de volta.
	 */
	function gravarFbc(fbclid) {
		if (!fbclid || lerCookie('_fbc')) {
			return lerCookie('_fbc');
		}

		var valor = 'fb.1.' + Date.now() + '.' + fbclid;
		var seguro = window.location.protocol === 'https:' ? '; Secure' : '';

		try {
			document.cookie = '_fbc=' + encodeURIComponent(valor) +
				'; Max-Age=' + (TTL_ATRIBUICAO * 86400) +
				'; Path=/; SameSite=Lax' + seguro;
		} catch (erro) {
			// Armazenamento indisponível: o valor viaja na atribuição desta navegação.
		}

		return valor;
	}

	function lerAtribuicaoGuardada() {
		try {
			var cru = window.localStorage.getItem(CHAVE_ATRIBUICAO);

			if (!cru) {
				return null;
			}

			var guardado = JSON.parse(cru);

			if (!guardado || typeof guardado !== 'object') {
				return null;
			}

			if (parseInt(guardado.expira, 10) < Math.floor(Date.now() / 1000)) {
				window.localStorage.removeItem(CHAVE_ATRIBUICAO);
				return null;
			}

			return guardado.valor && typeof guardado.valor === 'object' ? guardado.valor : null;
		} catch (erro) {
			return null;
		}
	}

	function guardarAtribuicao(valor) {
		try {
			window.localStorage.setItem(CHAVE_ATRIBUICAO, JSON.stringify({
				expira: Math.floor(Date.now() / 1000) + (TTL_ATRIBUICAO * 86400),
				valor: valor
			}));
		} catch (erro) {
			// Armazenamento indisponível: a atribuição vale só para esta navegação.
		}
	}

	/**
	 * O que a URL desta visita carrega: campanha e IDENTIFICADOR DE CLIQUE.
	 *
	 * Os cinco UTMs dizem de onde a visita diz que veio; os identificadores de
	 * clique são o que cada plataforma reconhece como sendo o próprio clique
	 * pago, e sem eles o lead chega sem a campanha que o comprou — mesmo TTL,
	 * mesmo primeiro toque, mesma persistência.
	 */
	function atribuicaoDaUrl() {
		var busca = new URLSearchParams(window.location.search);
		var mapa = {
			fonte: 'utm_source',
			meio: 'utm_medium',
			campanha: 'utm_campaign',
			termo: 'utm_term',
			conteudo: 'utm_content',
			gclid: 'gclid',
			gbraid: 'gbraid',
			wbraid: 'wbraid',
			msclkid: 'msclkid',
			fbclid: 'fbclid',
			li_fat_id: 'li_fat_id'
		};
		var saida = {};
		var chave;
		var valor;

		for (chave in mapa) {
			if (Object.prototype.hasOwnProperty.call(mapa, chave)) {
				valor = busca.get(mapa[chave]);
				if (valor) {
					saida[chave] = String(valor);
				}
			}
		}

		if (document.referrer && document.referrer.indexOf(window.location.origin) !== 0) {
			saida.referrer = document.referrer;
		}

		return saida;
	}

	/**
	 * Os cookies da Meta, lidos AGORA — nunca guardados no primeiro toque.
	 *
	 * `_fbp` é do navegador e muda quando a Meta quer; `_fbc` nasce do `fbclid`
	 * desta navegação ou do que já estava lá. Guardá-los junto da campanha
	 * congelaria um par que a Conversions API rejeitaria depois.
	 */
	function cookiesDaMeta(escolhida) {
		var fbc = gravarFbc(escolhida.fbclid || '');
		var fbp = lerCookie('_fbp');

		if (fbc) {
			escolhida.fbc = fbc;
		}

		if (fbp) {
			escolhida.fbp = fbp;
		}

		return escolhida;
	}

	function atribuicao() {
		var guardada = lerAtribuicaoGuardada();
		var atual = atribuicaoDaUrl();
		var temAtual = Object.keys(atual).length > 0;
		var escolhida;

		if (PRIMEIRO_TOQUE) {
			escolhida = guardada || atual;
		} else {
			escolhida = temAtual ? atual : (guardada || {});
		}

		if (!escolhida.primeiro_toque_em) {
			escolhida.primeiro_toque_em = guardada && guardada.primeiro_toque_em
				? String(guardada.primeiro_toque_em)
				: agora();
		}

		escolhida.modelo = String(ATRIBUICAO.modelo || '');

		if (!guardada || (!PRIMEIRO_TOQUE && temAtual)) {
			guardarAtribuicao(escolhida);
		}

		return cookiesDaMeta(escolhida);
	}

	function formularioDe(gatilho) {
		var seletor = gatilho.getAttribute('data-f3base-form');

		if (!seletor) {
			return null;
		}

		try {
			return document.querySelector(seletor);
		} catch (erro) {
			return null;
		}
	}

	function valorDoCampo(escopo, nome) {
		var elemento = escopo.querySelector('[data-f3base-campo="' + nome + '"]');

		if (!elemento) {
			elemento = escopo.querySelector('[name="' + nome + '"]');
		}

		return elemento && typeof elemento.value === 'string' ? elemento.value.trim() : '';
	}

	function honeypotDe(escopo) {
		var elemento = escopo.querySelector('[data-f3base-honeypot]');

		if (!elemento) {
			elemento = escopo.querySelector('[name="website"]');
		}

		return elemento && typeof elemento.value === 'string' ? elemento.value.trim() : '';
	}

	function coletar(gatilho) {
		var escopo = formularioDe(gatilho);
		var carga = {};
		var i;
		var nome;

		if (escopo) {
			for (i = 0; i < CAMPOS.length; i++) {
				nome = CAMPOS[i];
				carga[nome] = limitar(nome, valorDoCampo(escopo, nome));
			}
			carga.website = honeypotDe(escopo);
		}

		return carga;
	}

	function temContato(carga) {
		var i;

		for (i = 0; i < CAMPOS.length; i++) {
			if (carga[CAMPOS[i]]) {
				return true;
			}
		}

		return false;
	}

	/*
	 * A MENSAGEM É SÓ A MENSAGEM. Nenhum código de referência, id de sessão ou
	 * parâmetro de rastreio entra no texto que a pessoa vê ao abrir a conversa:
	 * quem recebe o WhatsApp lê um código que não significa nada para ela, e
	 * quem manda passa a explicar por que o site escreveu aquilo.
	 *
	 * A correlação entre o clique e a conversa é feita por DATA E HORA, fora do
	 * site: o registro do clique carrega o carimbo de tempo, e é por ele que
	 * alguém casa a conversa que chegou com o clique que a originou.
	 */
	function mensagemDe(gatilho) {
		var propria = gatilho.getAttribute('data-f3base-mensagem');

		return propria || String(dados.mensagem || '');
	}

	function urlWhatsapp(gatilho) {
		var numero = gatilho.getAttribute(ATRIBUTO_NUMERO) || String(dados.numero || '');
		var texto = mensagemDe(gatilho);

		if (!texto) {
			return 'https://wa.me/' + encodeURIComponent(numero);
		}

		return 'https://wa.me/' + encodeURIComponent(numero) + '?text=' + encodeURIComponent(texto);
	}

	function enviar(carga) {
		var corpo = JSON.stringify(carga);

		try {
			if (navigator && typeof navigator.sendBeacon === 'function') {
				navigator.sendBeacon(String(dados.endpoint), new Blob([corpo], { type: 'application/json' }));
				return;
			}

			if (typeof window.fetch === 'function') {
				window.fetch(String(dados.endpoint), {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: corpo,
					keepalive: true,
					credentials: 'omit'
				}).catch(function () {
					// Fire and forget: falha de registro nunca custa o lead.
				});
			}
		} catch (erro) {
			// Fire and forget: bloqueador derruba beacon, e a conversa segue.
		}
	}

	/**
	 * O evento nos DOIS formatos, sempre.
	 *
	 * Objeto `{event: …}` é o que um container do GTM lê como gatilho; array de
	 * comando é o que o `gtag.js` consome. Emitir os dois faz a troca de caminho
	 * — ligar ou desligar o container — não perder nada pelo caminho.
	 *
	 * O INTERRUPTOR SAIU NA 1.1.2, e ele era interruptor ao lado do dado que já
	 * decide: sem measurement ID gravado nada carrega o `gtag.js`, e sem
	 * `gtag.js` este ramo não roda — a guarda `typeof window.gtag !== 'function'`
	 * já era a resposta inteira. Com o ID gravado, não há por que não disparar:
	 * quem gravou o ID pediu a medição. Chave que só podia discordar do próprio
	 * dado é a mesma doença que a 1.0.19 tirou do regime de formulário: dois
	 * fatos podendo discordar sobre a mesma coisa, e um deles sem consequência.
	 */
	function evento(nome, parametros) {
		var objeto = { event: nome };
		var chave;

		for (chave in parametros) {
			if (Object.prototype.hasOwnProperty.call(parametros, chave)) {
				objeto[chave] = parametros[chave];
			}
		}

		try {
			window.dataLayer.push(objeto);
		} catch (erro) {
			// Medição nunca interrompe o fluxo do visitante.
		}

		if (typeof window.gtag !== 'function') {
			return;
		}

		try {
			window.gtag('event', nome, parametros);
		} catch (erro) {
			// Medição nunca interrompe o fluxo do visitante.
		}
	}

	/**
	 * Normalização de e-mail para Enhanced Conversions, pela regra do Google.
	 *
	 * Espaço fora, minúsculas, e — só para os domínios que o próprio Google
	 * nomeia — os pontos do usuário removidos. Nenhuma regra inventada para
	 * outros provedores: normalizar demais casa menos, não mais.
	 */
	function normalizarEmail(email) {
		var limpo = String(email || '').trim().toLowerCase();
		var partes = limpo.split('@');

		if (partes.length !== 2) {
			return '';
		}

		if (partes[1] === 'gmail.com' || partes[1] === 'googlemail.com') {
			partes[0] = partes[0].split('+')[0].replace(/\./g, '');
		}

		return partes[0] + '@' + partes[1];
	}

	/**
	 * Normalização de telefone para Enhanced Conversions: E.164, e só.
	 *
	 * Sem o `+` e o código do país não há E.164, e adivinhar o país a partir do
	 * idioma do site seria inventar um número. Sem prefixo, não vai nada.
	 */
	function normalizarTelefone(telefone) {
		var bruto = String(telefone || '').trim();

		if (bruto.indexOf('+') !== 0) {
			return '';
		}

		var digitos = bruto.replace(/[^0-9]/g, '');

		return digitos ? '+' + digitos : '';
	}

	function sha256(texto) {
		if (!window.crypto || !window.crypto.subtle || typeof window.crypto.subtle.digest !== 'function') {
			return null;
		}

		try {
			return window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(texto)).then(function (buffer) {
				var bytes = new Uint8Array(buffer);
				var saida = '';
				var i;

				for (i = 0; i < bytes.length; i++) {
					saida += ('0' + bytes[i].toString(16)).slice(-2);
				}

				return saida;
			});
		} catch (erro) {
			return null;
		}
	}

	/**
	 * Enhanced Conversions do Google — INERTE por desenho neste template.
	 *
	 * Ela só existe quando um formulário associado fornece e-mail ou telefone, e
	 * o template desta base não tem formulário nenhum: o ramo nasce sem uso, e
	 * está aqui declarado para o projeto que acrescentar um. O disparo do Ads
	 * espera o hash resolver quando há campos — quem navega é o link, não este
	 * código, e o atraso de um microtask não segura o visitante.
	 *
	 * @return {Promise|null} Promessa que resolve quando `user_data` foi setado.
	 */
	function dadosDoUsuario(carga) {
		if (!ADS.id || typeof window.gtag !== 'function') {
			return null;
		}

		var email = normalizarEmail(carga.email);
		var telefone = normalizarTelefone(carga.telefone);

		if (!email && !telefone) {
			return null;
		}

		var pendentes = [];
		var chaves = [];

		if (email) {
			pendentes.push(sha256(email));
			chaves.push('sha256_email_address');
		}

		if (telefone) {
			pendentes.push(sha256(telefone));
			chaves.push('sha256_phone_number');
		}

		if (pendentes.indexOf(null) !== -1) {
			return null;
		}

		return Promise.all(pendentes).then(function (hashes) {
			var user = {};
			var i;

			for (i = 0; i < hashes.length; i++) {
				user[chaves[i]] = hashes[i];
			}

			window.gtag('set', 'user_data', user);
		});
	}

	/**
	 * O portão do consentimento, do lado do navegador.
	 *
	 * Mesma semântica de `f3base-tracking.js`, e a igualdade é deliberada: sem o
	 * objeto do consentimento na página não há o que consultar, e a ausência
	 * dele não pode virar bloqueio silencioso — o servidor já decidiu uma vez, e
	 * ele é a decisão de reserva. O que este portão acrescenta é a NEGATIVA
	 * TARDIA: o objeto existe, o visitante recusou depois de as tags terem
	 * carregado, e a recusa precisa alcançar os disparos seguintes.
	 *
	 * @return {boolean} Verdadeiro quando o site pode mandar evento a terceiro.
	 */
	function permiteTags() {
		if (window.f3baseConsentimento && typeof window.f3baseConsentimento.permiteTags === 'function') {
			return window.f3baseConsentimento.permiteTags();
		}

		return true;
	}

	/**
	 * A conversão do clique, nos quatro canais, de um lugar só.
	 *
	 * `generate_lead` sai SEMPRE: o formulário é opcional neste site, e o clique
	 * é o lead. Até a 1.0.19 ele exigia campo preenchido e o template não tinha
	 * formulário nenhum — na prática, o evento de conversão nunca era emitido, e
	 * o que saía era um `select_content` que campanha nenhuma otimiza.
	 *
	 * Os disparos DIRETOS não acontecem no caminho do container: lá quem
	 * dispara é ele, a partir do objeto que `evento()` já empurrou.
	 */
	function converter(formulario, id, carga) {
		evento('generate_lead', {
			form_id: formulario,
			correlation_id: id,
			method: carga && temContato(carga) ? 'formulario' : 'cta'
		});

		if (CAMINHO === 'gtm') {
			return;
		}

		var pendente = dadosDoUsuario(carga || {});

		if (pendente && typeof pendente.then === 'function') {
			pendente.then(function () {
				conversaoDoAds(id);
			}).catch(function () {
				conversaoDoAds(id);
			});
		} else {
			conversaoDoAds(id);
		}

		/*
		 * O PORTÃO DA NEGATIVA TARDIA, e ele existe porque a assimetria é do
		 * fornecedor. O Google recebe a negativa como `consent update`: a partir
		 * dela o próprio gtag para de armazenar, e nada aqui precisa decidir.
		 * Pixel da Meta e Insight Tag do LinkedIn NÃO TÊM equivalente de
		 * `update` — uma vez carregados, `fbq` e `lintrk` continuam sendo
		 * funções, e a presença da função era a única condição destes dois
		 * disparos. Quem tivesse aceitado, carregado as tags e recusado depois
		 * continuava mandando `Lead` à Meta a cada clique no CTA.
		 *
		 * Negar não descarrega o script do fornecedor — isso não está ao alcance
		 * de ninguém. O que passa a valer é o que ESTE site manda: nada.
		 */
		if (!permiteTags()) {
			return;
		}

		if (META.pixelId && typeof window.fbq === 'function') {
			try {
				window.fbq('track', 'Lead', {}, { eventID: id });
			} catch (erro) {
				// Medição nunca interrompe o fluxo do visitante.
			}
		}

		if (LINKEDIN.conversionId && typeof window.lintrk === 'function') {
			try {
				window.lintrk('track', { conversion_id: Number(LINKEDIN.conversionId) });
			} catch (erro) {
				// Medição nunca interrompe o fluxo do visitante.
			}
		}
	}

	/**
	 * A conversão do Google Ads precisa das DUAS metades do `send_to`.
	 *
	 * Com só uma delas, o disparo iria para a conta e não para a ação — e o
	 * pacote prefere não disparar a disparar no lugar errado.
	 */
	function conversaoDoAds(id) {
		if (!ADS.id || !ADS.label || typeof window.gtag !== 'function') {
			return;
		}

		try {
			window.gtag('event', 'conversion', {
				send_to: String(ADS.id) + '/' + String(ADS.label),
				transaction_id: id
			});
		} catch (erro) {
			// Medição nunca interrompe o fluxo do visitante.
		}
	}

	function marcarInicio(gatilho) {
		var id = gatilho.getAttribute('data-f3base-lead') || 'contato-whatsapp';

		if (iniciados[id]) {
			return;
		}

		iniciados[id] = true;
		evento('form_start', { form_id: id });
	}

	/**
	 * Correlação estável por CTA dentro de uma janela curta.
	 *
	 * Duplo clique reaproveita a mesma correlação — e o servidor a deduplica pela
	 * chave única. Passada a janela, um novo clique é uma nova interação.
	 */
	function correlacaoDo(gatilho) {
		var guardada = gatilho.getAttribute('data-f3base-correlation');
		var carimbo = parseInt(gatilho.getAttribute('data-f3base-correlation-em'), 10);
		var segundos = Math.floor(Date.now() / 1000);

		if (guardada && carimbo > 0 && (segundos - carimbo) <= 5) {
			return guardada;
		}

		var nova = correlationId();

		gatilho.setAttribute('data-f3base-correlation', nova);
		gatilho.setAttribute('data-f3base-correlation-em', String(segundos));

		return nova;
	}

	function aoClicar(gatilho) {
		var id = correlacaoDo(gatilho);
		var formulario = gatilho.getAttribute('data-f3base-lead') || 'contato-whatsapp';
		var carga = coletar(gatilho);
		var numero = gatilho.getAttribute(ATRIBUTO_NUMERO) || String(dados.numero || '');

		/*
		 * O DESTINO DO AGENTE VENCE. Só o link do modelo — ou o que o servidor
		 * carimbou como promovido por ele — recebe o `wa.me`, e ele abre em ABA
		 * NOVA: a conversa acontece fora do site, e levar a aba junto faz o
		 * visitante perder a página que estava lendo.
		 */
		if (numero && !temDestinoProprio(gatilho)) {
			gatilho.setAttribute('href', urlWhatsapp(gatilho));
			gatilho.setAttribute('target', '_blank');
			gatilho.setAttribute('rel', 'noopener');
		}

		if (registrados[id]) {
			return;
		}

		registrados[id] = true;

		carga.token = String(dados.token || '');
		carga.correlation_id = id;

		/*
		 * O CARIMBO DE TEMPO É A CHAVE DA CORRELAÇÃO, e por isso sai em duas
		 * formas: a legível, com o fuso explícito, para quem vai casar o clique
		 * com a conversa olhando as duas listas; e a de milissegundos, para
		 * quem faz esse casamento por programa. O `correlation_id` continua
		 * existindo só para deduplicar o evento entre navegador e servidor —
		 * ele nunca chega à mensagem nem ao link.
		 */
		carga.clicado_em = new Date().toISOString();
		carga.clicado_em_ms = Date.now();
		carga.formulario = limitar('formulario', formulario);
		carga.pagina = limitar('pagina', window.location.pathname + window.location.search);
		carga.consentimento = permiteTags();
		carga.atribuicao = atribuicao();

		if (typeof carga.website === 'undefined') {
			carga.website = '';
		}

		enviar(carga);
		converter(formulario, id, carga);
	}

	function ligar() {
		var seletor = String(dados.seletor || '[data-f3base-lead]');

		document.addEventListener('click', function (ev) {
			var alvo = ev.target;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && alvo.matches && alvo.matches(seletor)) {
					aoClicar(alvo);
					return;
				}
				alvo = alvo.parentNode;
			}
		}, true);

		document.addEventListener('input', function (ev) {
			var alvo = ev.target;

			if (!alvo || alvo.nodeType !== 1 || !alvo.closest) {
				return;
			}

			var formulario = alvo.closest('form');

			if (!formulario) {
				return;
			}

			var gatilhos = document.querySelectorAll(seletor);
			var i;

			for (i = 0; i < gatilhos.length; i++) {
				if (formularioDe(gatilhos[i]) === formulario) {
					marcarInicio(gatilhos[i]);
					return;
				}
			}
		}, true);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', ligar);
	} else {
		ligar();
	}
}(window, document));
