# Fator3 MCP 0.38.0 — Inicialização sob demanda

Base direta: 0.37.0. Mínimos preservados: WordPress 7.1.2 e PHP 8.3.6.

## Mudança

O impacto Core 1.63.0 r1, relacionado ao Pedido Core 354, identificou `MutationServiceAudit::initialize → wp_get_abilities` em todo `wp_loaded`. Esse caminho forçava o catálogo administrativo do Core mesmo no login e em páginas públicas.

O listener de auditoria continua presente desde o bootstrap. A preparação do contrato passa a ocorrer quando necessária: administração, cron, WP-CLI, API REST, catálogo explicitamente solicitado, consulta ou primeiro evento de serviço. Inicialização reentrante e chamada anterior a `init` não antecipam nem duplicam o registro. Não mudam schemas de abilities, descritores, permissões, concessões, idempotência, tabelas, retenção ou formato de recibos.

## Integrações e limites

Referências recebidas: Core 1.63.0, Google 0.24.0, Meta 0.17.0, LinkedIn 0.13.0 e Pipedrive 0.5.0. Nenhum desses pacotes é alterado ou incluído no instalador MCP. O Pipedrive exige PHP 8.3.36 / WordPress 7.1.3 e fica fora da ativação no laboratório mínimo PHP 8.3.6.

A correção remove uma causa de carregamento antecipado; a meta Core de diferença até 100 ms entre o conjunto com e sem Core/Pipedrive depende de medição própria. O relatório externo registra as amostras e o resultado, sem converter melhoria de bootstrap em aceite automático dessa meta. Sem reset de opções, migração ou novas permissões. A publicação em frota não faz parte desta entrega.
