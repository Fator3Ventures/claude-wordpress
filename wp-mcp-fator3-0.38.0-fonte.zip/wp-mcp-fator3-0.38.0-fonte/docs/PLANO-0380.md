# Plano — Fator3 MCP 0.38.0

30/10/2026, America/Sao_Paulo. Implementação sobre a base aceita 0.37.0: instalador 912702 bytes/SHA-256 cbece53fc479d9fe3963b111e49e789d92609c5462102877244dcaebcf7cf3ec; fonte 5074415 bytes/SHA-256 e2654b93a9bababb283cb870b4f5f94ac17ad9a188ea23bb2cd3a8b77f7bb49c. Alvo previsto 0.38.0; instalador ainda não gerado. Plano anterior à alteração funcional.

Escopo: impacto recebido base-site-core-fator3-1.63.0-impacto-wp-mcp-fator3.md, revisão 1, validacao-coordenada, relacionado ao Pedido Core 354. Não há novo número MCP atribuído por esta rodada. Considerar Core 1.63.0, Google 0.24.0, Meta 0.17.0, Pipedrive 0.5.0 e LinkedIn 0.13.0. Os quatro primeiros foram anexados; LinkedIn é recuperado pelo instalador aceito e observado no Site-Teste. Preservar r5 da base, identidade e mínimos. Nenhum acompanhante será alterado no código.

## Problema e direção

MutationServiceAudit inicializa o catálogo completo incondicionalmente em wp_loaded. A base e a pilha recebida sustentam a causa de montagem antecipada, mas não atribuem todo o custo de página/login ao MCP. A sonda própria anterior reproduz 172 arquivos Core e catalogo-completo no login.

Substituir o disparo incondicional por preparação nos contextos de administração/cron/CLI e REST. Conectar também ao catálogo quando ele for efetivamente solicitado, sem provocá-lo na página pública/login. Manter o listener de eventos desde o carregamento e inicialização antes de record/status/leitura: o primeiro evento de um job ou chamada PHP pública deve ser capturado. Proteger reentrada e registro prematuro/incompleto. Preservar admissão estrita do leitor, origem dos pontos de entrada, identidade/hash/CAS, revogação, propriedade, perfil e persistência da referência. Não conceder registrado=true como atalho para evitar validar o leitor.

## Validação e entrega

1. Reproduzir bootstrap global na 0.37.0 e comparar os mesmos contextos com a candidata em WordPress descartável; medir invocações do catálogo e presença dos schemas, sem confundir contagem de arquivos com tempo causal.
2. Testar ausência de acompanhantes, cargas antecipadas/tardias, REST/admin/cron/CLI, descoberta completa, primeira emissão sem contexto administrativo, leitura, revogação, repetição e falha de persistência. Repetir integração de aquisição e etapas LinkedIn com dados sintéticos e fornecedores interceptados.
3. Exercer instalação limpa no mínimo WordPress 7.1.2/PHP 8.3.6 e upgrade direto 0.37→0.38 com preservação do estado. Documentação MCP integral, lint e pacote determinístico.
4. Site-Teste: inventário/saúde, instalar somente o MCP final validado, conferir backup e versão em requisição nova, catálogo/guia e sondagens. Medir três amostras e mínimos de página/login; contraste Core+Pipedrive ligado/desligado exige preservar/restaurar exatamente o estado e verificar ausência de mudança concorrente. Não apagar banco ou recursos alheios, nem simular efeitos comerciais reais.
5. Fechar instalador, relatório e fonte único com evidências sanitizadas; reconstruir do fonte extraído. Publicação/frota ficam com seus responsáveis.

O aceite de diferença até 100 ms do Core 354 permanece aberto até medição suficiente nas duas rotas. Se houver custo residual próprio do Core, registrar como pendência do pedido recebido, sem fabricar impacto de resposta. Não repetir leitura remota privada de credenciais rejeitada na rodada anterior; examinar o contrato novo apenas por código/documentação e fixtures sintéticas.

Impactos novos identificados no planejamento: nenhum. A resposta e prova de atendimento ao impacto Core recebido serão registradas no relatório principal; novo encaminhamento só se surgir solicitação técnica adicional a outro mantenedor. Não ampliar escopo para clientes sociais, feed, execução de PHP por agente ou rota de frota.

## Fechamento

Implementada e validada a 0.38.0. 282 verificações funcionais; 801 schemas idênticos à base com os acompanhantes atuais. Instalador congelado e instalado no Site-Teste, sem alteração posterior de bytes. Resposta Core354: caminho MCP antecipado removido; login atende a diferença de até 100 ms, página pública não atende. Estado ativo dos nove plugins restaurado após comparação; Core operacional, robots e llms restabelecidos e cache novamente verified. O fluxo neutro de metadados/Core334 passou em 11 verificações locais sintéticas; não repetida leitura remota de credencial privada. Sem novo impacto técnico que exija arquivo de encaminhamento. Detalhes e limites no relatório principal.
