# Fator3 MCP 0.38.0

Base direta 0.37.0. Resposta ao impacto Core 1.63.0 r1 (Pedido Core 354): inicialização sob demanda da auditoria de serviço, sem descoberta antecipada nas páginas públicas e no login. Matriz recebida: Core 1.63.0, Google 0.24.0, LinkedIn 0.13.0, Meta 0.17.0 e Pipedrive 0.5.0. Mínimos MCP WordPress 7.1.2/PHP 8.3.6.

Instalar somente wp-mcp-fator3-0.38.0-instalador.zip. Runtime em fontes/wp-mcp-fator3; documentação editável em docs; reprodução em tools/release0380/README.md; evidências atuais em evidencias/0380. Planos, testes e evidências anteriores são históricos. O relatório externo identifica os arquivos finais, a prova remota e o aceite de frota ainda necessário.
