# Retenção e histórico diário — 0.22.0

Pedido MCP LinkedIn 14. O acervo é local, cifrado, sem expiração e independente do prazo dos resultados de coleta. Nenhum dado é enviado ao Core, Meta, Google ou Pipedrive por este recurso.

## Três políticas distintas

- Auditoria local: `unlimited` por padrão. `get-retention` informa a política e sua revisão. `save-retention` aceita `audit_mode=unlimited|finite`, `audit_days` (1–36.500), `expected_revision` e `dry_run`. Omitir `dry_run` simula. Somente `dry_run=false` grava. A prévia informa quantos eventos ficariam elegíveis à remoção; a manutenção posterior aplica o prazo. O painel oferece a mesma prévia e confirmação na aba Retenção.
- Resultados de coleta e jobs terminais: `retention_mode=unlimited|finite` por conexão, com `retention_days` de 1 a 3.650. Conexões existentes sem modo mantêm o prazo finito anterior, inclusive 3.650 dias. Novas conexões usam unlimited; informar somente retention_days ao criar conserva a intenção finita dos clientes antigos. Uma edição que omite ambos os campos preserva a política salva.
- Histórico diário e suas exportações: sempre unlimited, inclusive quando a conexão escolhe prazo finito para resultados. Expiração de OAuth, prévias, confirmações, cursores e candidatas de credencial continua ativa. Exportação comum de uma coleta (`export`) continua sendo uma cópia temporária de 24 horas.

A troca para unlimited protege imediatamente a leitura e a limpeza dos dados existentes. A troca para finite considera a data original da observação, não a data em que a política foi salva. A manutenção percorre resultados e jobs em lotes de 25, com cursor estável; portanto a conclusão da reindexação depende do volume. Jobs ativos não expiram; pais com páginas existentes são preservados. Conexões ausentes, páginas ilegíveis e páginas bloqueadas para migração permanecem guardadas para revisão. Retenção não restaura permissão revogada.

Exemplo de prévia pelo MCP (substitua a revisão pela lida):

```json
{"expected_revision":0,"audit_mode":"finite","audit_days":365,"dry_run":true}
```

## Origem e significado das métricas

| Canal / relatório | Conteúdo diário | Identidade |
|---|---|---|
| pages / follower_statistics | Ganhos orgânicos e pagos de seguidores | Organização + dia + métrica |
| pages / page_statistics | Visualizações e estatísticas da Página, preservando recortes retornados | Organização + dia + caminho da métrica |
| pages / share_statistics | Impressões, cliques, comentários, compartilhamentos e demais estatísticas orgânicas das publicações | Organização/publicação + dia + métrica |
| ads / ad_analytics | Métricas selecionadas; pivôs CAMPAIGN, CREATIVE e CONVERSION, além dos existentes | Pivô + entidade + dia + métrica + moeda |

Seguidores significa os ganhos diários que a API oferece, não um total histórico reconstruído. Estatísticas de publicações não são inventário completo de posts nem contagem inferida de publicações. `follower_total`, `posts`, perfis e demografia lifetime não são convertidos retroativamente em séries diárias.

O pivô CONVERSION inclui como padrão externalWebsiteConversions, externalWebsitePostClickConversions, externalWebsitePostViewConversions e conversionValueInLocalCurrency. Estas são métricas de atribuição de anúncios, não envio de eventos pela Conversions API.

Datas vêm de `timeRange` nas Páginas (um intervalo de 86.400.000 ms alinhado a UTC) ou de `dateRange` em Ads (início e fim inclusivos no mesmo dia, granularidade DAILY). Agregados mensais, snapshots e linhas sem dia são registrados como cobertura insuficiente, sem fabricar valores. Zero só é armazenado quando veio numericamente da origem. Valores decimais em string mantêm sua representação.

O proprietário explícito retornado deve corresponder à organização consultada. Quando a API de estatísticas omite esse campo, a identidade vem da organização explicitamente delimitada na consulta. Ads preserva o URN retornado, inclusive `urn:lla:llaPartnerConversion:<id>` para conversões. Recortes, moeda, campo original, fórmula, versão API, primeira e última observação e origem ficam junto de cada métrica. Métricas por caminhos diferentes não são somadas automaticamente.

## Coleta e retroação

`query` consulta sem alimentar o acervo. `create-job` + `run-job`, agendas e `create-backfill` alimentam o acervo após persistir a página bruta e antes do checkpoint. Um replay usa a página já persistida. A mesma origem não duplica a observação; observações antigas não sobrescrevem as mais recentes. Selecionar menos métricas em uma nova coleta não apaga as outras.

`create-backfill` recebe `query`, `idempotency_key` e `max_pages` opcional (padrão 10.000, máximo 10.000). Requer data inicial explícita; data final omitida termina ontem UTC. Datas futuras e granularidade ALL são recusadas. O intervalo é congelado e devolvido em `backfill.requested/effective`; a repetição da mesma chave e pedido conserva esse plano mesmo em outro dia. A execução ocorre pela fila normal, em janelas de até sete dias e páginas limitadas. Se o teto de páginas for atingido, a coleta fica parcial.

Limites publicados pelo fornecedor, consultados em 26/10/2026:

- Seguidores: janela de 12 meses até dois dias antes da consulta UTC.
- Estatísticas orgânicas de publicações: janela móvel de 12 meses.
- Ads: retenção de performance de até dez anos; pivôs demográficos, dois anos. A documentação também descreve limite diário de seis meses e arredondamento mensal para ALL. Portanto retenção de performance não comprova disponibilidade diária para todo o período.
- Visualizações de Página: o documento consultado não oferece horizonte universal que permita prometer integralidade.

A criação ajusta períodos de seguidores/publicações/Ads às janelas publicadas acima e informa `window_adjusted`; intervalo totalmente fora da janela falha com `outside_retention_window`. Para Ads, mantém DAILY e arquiva apenas os dias realmente retornados; uma recusa do fornecedor pausa a coleta com o código sanitizado, e um agregado permanece na página bruta e nos recibos de cobertura. Autorizações, supressão, atraso e políticas do fornecedor podem reduzir ainda mais o resultado.

Fontes oficiais:

- https://learn.microsoft.com/en-us/linkedin/marketing/community-management/organizations/follower-statistics?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/community-management/organizations/share-statistics?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/community-management/organizations/page-statistics?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads-reporting/ads-reporting?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads-reporting/ads-reporting-schema?view=li-lms-2026-09
- https://learn.microsoft.com/en-us/linkedin/marketing/conversions/conversions-usecase?view=li-lms-2026-01

## Leitura e exportação

Contrato `linkedin-history/1.0.0`. Operações humanas exigem administrador (`manage_options`). `history-query` recebe conexão, canal, ativo e, opcionalmente, relatório e período (duas datas), limit de 1 a 100 e cursor. A ordem é por chave estável, não cronológica. O cursor dura 24 horas, vinculado à seleção, principal, autorização e geração do acervo. Se qualquer um mudar, reinicie a consulta. Não há expiração do dado armazenado nem limite de dez anos para a leitura local; uma consulta admite até 36.600 dias, podendo ser dividida em períodos maiores ao longo do tempo.

O acervo é particionado por usuário e concessão de transporte, além de conexão/canal/ativo. Uma coleta criada pelo painel e outra por uma concessão MCP não compartilham a partição automaticamente. A leitura e exportação devem usar a identidade/concessão que originou a coleta. Conexão pausada, ativo removido, usuário sem permissão ou concessão revogada bloqueiam o acesso. Token remoto vencido não impede a consulta local autorizada.

`rows` contém uma métrica por linha; `row` inclui metric, value, entity e pivot. `coverage` nunca afirma integralidade remota: informa que são linhas armazenadas, que vazio não significa zero e até 20 recibos recentes do recorte. `receipts_sampled=true` identifica amostra. Cada métrica preserva sua própria cobertura. Recibos vazios continuam no banco, permitindo distinguir coleta vazia de ausência de tentativa; a amostra de leitura não é inventário completo de lacunas.

`history-export` inicia CSV/JSON com query, format e idempotency_key. Avance com `history-export-step` até state=complete. Cada etapa processa até 100 métricas. Em `history-export-read`, leia part desde zero e offset_bytes até next_offset=null; só então avance para next_part. Decodifique Base64, confira part_sha256 e concatene as partes na ordem. Máximo 64 MiB por exportação: divida por período se excedido. A exportação é cifrada, não cria URL pública e revalida o proprietário e o ativo a cada leitura. Geração diferente durante a coleta das partes gera history_changed, exigindo nova exportação.

## Migração, manutenção e recuperação

Nova tabela `{prefix}f3_linkedin_history`, schema próprio 1; a tabela de registros mantém schema 2. O upgrade cria a estrutura, protege auditorias antigas e preserva ciphertext/revisões de conexões e registros existentes. `history-migrate` avança 25 páginas brutas por chamada; a manutenção também avança. Importa inclusive páginas com prazo antigo vencido que ainda existam fisicamente. A migração não remove dados de origem. Depois da migração, a manutenção pode aplicar a política finita explicitamente existente, conservando a métrica no acervo.

Páginas sem identidade diária, ilegíveis ou sem autorização atual recebem retenção de revisão (`history_hold`); não são removidas. `history-status` mostra progresso, quantidade e bloqueios acumulados. Depois de corrigir a causa e restabelecer a autorização, `history-migrate` com `restart=true` reavalia desde o início; o replay é idempotente. Dados que já tinham sido excluídos antes da atualização não podem ser recuperados pelo plugin.

Opções novas: f3_linkedin_history_schema e f3_linkedin_retention0110. Buckets próprios adicionais: settings/retention, history_generation, history_hold, history_export, history_export_part, retention_scan e migration/history-0110. Só o próprio namespace LinkedIn é alterado.

Antes de atualizar, preserve banco, salts e comprovantes. Dados já removidos exigem recuperação a partir de backup correspondente. Em falha, pause a limpeza e retome pela versão corretiva.
