# Primeiros passos — 0.22.0

Este guia leva de uma instalação sem conexões até uma conexão conferida. Os nomes em negrito são os que aparecem na tela desta versão. O painel fica em Ferramentas → Fator3 MCP LinkedIn e exige administrador.

## Antes de começar

Tenha em mãos, do LinkedIn Developers (My apps → seu aplicativo):

| Dado | Onde fica no LinkedIn | Campo no painel |
|---|---|---|
| Client ID | Auth → Application credentials | **ID do aplicativo** |
| Primary Client Secret | Auth → Application credentials | **Chave secreta do aplicativo** |
| Access Token e sua validade | Tools → OAuth Token Tools → Token Generator | **Token de acesso** e **Validade informada do token (UTC)** |
| Número do aplicativo | Número depois de `/developers/apps/` no endereço da página | **Identificação do aplicativo nas notificações** |

O aplicativo precisa dos produtos e escopos do que você vai usar: leitura de Páginas e anúncios (`r_ads`, `r_ads_reporting`, `r_organization_admin`, `r_organization_social`), gestão (`rw_ads`, `w_organization_social`), formulários (`r_marketing_leadgen_automation`) e conversões (`rw_conversions`). O painel não concede escopo que o aplicativo não tem. As datas são sempre informadas em UTC.

Se for autorizar pelo navegador em vez de colar um token, o site precisa de HTTPS e o endereço mostrado em **Endereço de retorno OAuth (Authorized redirect URLs for your app)** precisa estar cadastrado no aplicativo, exatamente como aparece.

## 1. Criar a conexão

1. Abra **Conexões** e use **Nova conexão**.
2. Em **Nome da conexão**, use o membro que gerou o token e o aplicativo, por exemplo `Marketing · Aplicativo da empresa`.
3. Em Aplicativo, preencha o ID e a chave secreta. Para acesso manual, informe o token e a validade em Acesso ao LinkedIn. Um campo secreto vazio mantém o valor já salvo; o painel nunca mostra o valor guardado.
4. Para usar a conexão agora, marque **Conexão ativa** e use **Salvar conexão**. O token informado é conferido no LinkedIn antes de gravar. Se a conferência falhar, nada é salvo e a mensagem indica o campo a rever.

Para preparar a conexão sem token e autorizar depois pelo navegador, deixe **Conexão ativa** desmarcada antes de salvar. Depois abra **Autorização pelo LinkedIn e renovação**, marque as permissões e use **Autorizar no LinkedIn**.

A confirmação aparece junto da ação. Volte à lista para conferir o estado e a validade.

## 2. Escolher os ativos

1. Em **Conexões**, abra **Ativos** e escolha a conexão.
2. Em cada grupo (Páginas, Anúncios, Formulários), use **Carregar ativos disponíveis**, marque o que a conexão pode usar e use **Salvar seleção de ativos e formulários**. Nada é autorizado só por aparecer na lista.
3. O grupo Formulários lista contas de anúncios. Para escolher formulários, salve primeiro a conta; depois, em Formulários por conta, use **Carregar formulários**, marque e salve de novo.

## 3. Conferir

1. Em **Manutenção**, abra **Diagnóstico** e use **Consultar estado local**. O resumo deve mostrar a conexão contada e armazenamento e criptografia disponíveis.
2. Use **Executar autoteste local**. O resultado esperado é 9 de 9 verificações locais aprovadas. O autoteste não consulta o LinkedIn.
3. Em **Verificar acesso a um ativo**, escolha conexão, canal e ativo e use **Validar ativo no LinkedIn**. Essa é a única ação desta aba que consulta o fornecedor. Ela confirma a leitura dos metadados daquele ativo; não confirma relatórios, respostas de formulários nem conversões.
4. Em **Dados**, abra **Relatórios**, escolha conexão, canal, conta e relatório e use **Consultar página**. Uma página de resultado confirma a leitura real.

## 4. Conceder acesso ao Site Core, se for usar

- Formulários de contato: aba **Concessões**. Escolha o consumidor, a conexão, os formulários e as permissões e use **Salvar concessão**. Salvar a concessão não cadastra contato.
- Conversões de aquisição: em **Concessões**, abra **Conversões de aquisição** e localize **Conversões pelo servidor (Conversions API)**. Use **Carregar regras de conversão**, escolha uma regra de fonte API e use **Confirmar concessão ao Site Core**.
- Conversões por etapa comercial: em **Concessões**, abra **Etapas comerciais** e localize **Conversões de etapas comerciais**. Confira antes de confirmar.

## O que cada ação faz fora do site

| Ação | Consulta o LinkedIn? | Altera o LinkedIn? |
|---|---|---|
| Abrir Conexão, Retenção, Diagnóstico, Ajuda | Não | Não |
| Abrir Ativos, Relatórios, Coletas ou Histórico com ativos já selecionados | Sim, para obter os nomes | Não |
| **Salvar conexão** com token novo, **Verificar permissões**, **Validar ativo no LinkedIn** | Sim | Não |
| **Consultar página**, **Carregar ativos disponíveis**, **Carregar formulários**, **Carregar regras de conversão** | Sim | Não |
| **Gerar prévia** em Anúncios e publicações | Ao alterar um objeto, sim, para ler a revisão | Não |
| Botão final de Anúncios e publicações, depois da prévia | Sim | Sim |

## Problemas frequentes no primeiro uso

| Situação | O que fazer |
|---|---|
| `application_required` ao salvar | Informe Access Token, Client ID e Primary Client Secret juntos, ou salve a conexão pausada para autorizar depois. |
| Conexão ativa aparece como «Sem token» | Esse registro é anterior à 0.20.0. Edite, informe as credenciais e salve, ou pause a conexão. Enquanto estiver assim, nenhuma consulta funciona. |
| Lista de ativos vazia | Confira os escopos do token em **Verificar permissões** e o papel do membro na Página ou conta. |
| Conflito de revisão | Outra gravação ocorreu. Reabra a conexão e repita. |

Códigos e ações completos estão em TROUBLESHOOTING.md. A referência de cada campo está em FIELD-HELP.md.
