# Catálogo de operações — 0.22.0

Gerado do registro do próprio plugin na versão 0.22.0: 100 operações, 56 de leitura e 44 de escrita. Quanto ao LinkedIn, 47 não fazem chamada, 29 leem e 24 alteram dados. 14 estão marcadas como destrutivas no catálogo MCP.

Todas exigem administrador (`manage_options`). O nome completo é `linkedin/<operação>` no MCP e `POST /wp-json/f3-linkedin/v1/<operação>` no REST. Os parâmetros completos, com tipos e limites, estão em `input-schemas.json` e em `linkedin/contracts`; aqui aparecem só os obrigatórios.

Colunas: **Tipo** indica gravação local ou remota declarada; **LinkedIn** indica o efeito no fornecedor. O catálogo informa o efeito possível; a política de auditoria está em SECURITY.md. Consultar o estado local com sucesso não gera evento.

## Estado, contratos e documentação

Leituras locais para começar qualquer sessão.

| Operação | O que faz | Tipo | LinkedIn | Obrigatórios |
|---|---|---|---|---|
| `status` | Mostra armazenamento, execução agendada e situação das credenciais. | leitura | não consulta | — |
| `selftest` | Verifica armazenamento, criptografia e validações locais, sem consultar o LinkedIn. | leitura | não consulta | — |
| `capabilities` | Lista os recursos, contratos e limites disponíveis no plugin. | leitura | não consulta | — |
| `contracts` | Retorna os esquemas de entrada e saída das operações. | leitura | não consulta | — |
| `configuration-schema` | Descreve os campos aceitos e as regras para salvar conexões. | leitura | não consulta | — |
| `documentation` | Lê o índice ou um documento completo em páginas com revisão verificada. | leitura | não consulta | — |
| `audit` | Lista eventos locais de operação, com retenção configurável e padrão sem prazo. | leitura | não consulta | — |

## Conexões, credenciais e ativos

Cadastro da conexão, autorização OAuth, renovação e escolha de Páginas, contas e formulários.

| Operação | O que faz | Tipo | LinkedIn | Obrigatórios |
|---|---|---|---|---|
| `list-connections` | Lista conexões cadastradas sem expor credenciais. | leitura | não consulta | — |
| `get-connection` | Retorna configuração pública e revisão da conexão selecionada. | leitura | não consulta | `connection_id` |
| `save-connection` | Salva credenciais cifradas e configuração com conferência da revisão. | escrita (destrutiva) | lê | `connection_id`, `expected_revision` |
| `validate-connection` | Consulta o LinkedIn para verificar acesso ao ativo selecionado. | escrita | lê | `connection_id`, `channel`, `account_id` |
| `admin-options` | Busca nomes de usuários, ativos, formulários e operações permitidos. | leitura | lê | `kind` |
| `list-accounts` | Lista contas e Páginas acessíveis; a seleção de ativos continua explícita. | leitura | lê | `connection_id`, `channel` |
| `oauth-start` | Gera endereço de autorização temporário vinculado ao administrador e à sessão atual. | escrita | não consulta | `connection_id`, `expected_revision`, `scopes` |
| `inspect-token` | Consulta as permissões efetivamente concedidas pelo LinkedIn. | escrita | lê | `connection_id` |
| `refresh-token` | Renova a credencial quando houver autorização de renovação, preservando as concessões. | escrita | altera | `connection_id`, `expected_revision` |

## Relatórios, coletas, agendas e exportação

Consulta paginada de Pages e Ads, coletas duráveis e arquivos CSV/JSON.

| Operação | O que faz | Tipo | LinkedIn | Obrigatórios |
|---|---|---|---|---|
| `list-fields` | Descreve métricas, fórmulas e limites do relatório escolhido. | leitura | não consulta | `report` |
| `query` | Consulta uma página de dados dos ativos autorizados, informando continuação e cobertura. | leitura | lê | `connection_id`, `channel`, `account_id`, `report` |
| `create-job` | Cria uma coleta persistente de leitura com chave de idempotência. | escrita | não consulta | `query`, `idempotency_key` |
| `run-job` | Executa uma etapa da coleta e persiste o progresso. | escrita | lê | `job_id` |
| `job-status` | Mostra progresso, falhas e revisão de uma coleta. | leitura | não consulta | `job_id` |
| `control-job` | Pausa, retoma ou cancela a coleta usando sua revisão atual. | escrita | não consulta | `job_id`, `expected_revision`, `action` |
| `job-results` | Retorna uma página de resultados já persistidos. | leitura | não consulta | `job_id` |
| `list-jobs` | Lista coletas persistidas e seus estados. | leitura | não consulta | — |
| `save-schedule` | Salva periodicidade e consulta de uma agenda com revisão verificada. | escrita | não consulta | `schedule_id`, `expected_revision`, `query`, `enabled`, `interval_minutes` |
| `list-schedules` | Lista agendas de coleta e próximas execuções. | leitura | não consulta | — |
| `export` | Prepara arquivo CSV ou JSON a partir dos resultados da coleta. | escrita | não consulta | `job_id`, `format`, `idempotency_key` |
| `export-read` | Lê o arquivo exportado em partes sem consultar o fornecedor. | leitura | não consulta | `export_id` |

## Histórico diário e retenção

Acervo local de métricas diárias e política de guarda da auditoria.

| Operação | O que faz | Tipo | LinkedIn | Obrigatórios |
|---|---|---|---|---|
| `history-status` | Mostra migração e quantidade de métricas diárias preservadas. | leitura | não consulta | — |
| `history-query` | Lê métricas locais sem expiração, com autorização atual, cobertura e continuação. | leitura | não consulta | `connection_id`, `channel`, `account_id` |
| `history-migrate` | Importa até 25 páginas por etapa sem apagar a origem; restart permite reavaliar páginas bloqueadas. | escrita | não consulta | — |
| `create-backfill` | Cria coleta de leitura em intervalos diários; respeita a disponibilidade do LinkedIn. | escrita | não consulta | `query`, `idempotency_key` |
| `history-export` | Prepara CSV ou JSON cifrado em partes, restrito à identidade de origem. | escrita | não consulta | `query`, `format`, `idempotency_key` |
| `history-export-step` | Persiste uma parte da exportação, conferindo a geração do acervo. | escrita | não consulta | `export_id` |
| `history-export-read` | Lê partes autenticadas da exportação completa, sem endereço público. | leitura | não consulta | `export_id` |
| `get-retention` | Lê a política local de auditoria e o padrão de guarda do histórico. | leitura | não consulta | — |
| `save-retention` | Simula por padrão; salva com revisão e dry_run=false. O prazo finito permite limpeza posterior. | escrita (destrutiva) | não consulta | `expected_revision`, `audit_mode` |

## Formulários de contato (Lead Sync) e concessões

Formulários, respostas, assinaturas de notificação e concessões ao consumidor.

| Operação | O que faz | Tipo | LinkedIn | Obrigatórios |
|---|---|---|---|---|
| `lead-check-access` | Confere a conta e uma amostra dos formulários autorizados no LinkedIn. | leitura | lê | `connection_id`, `account_id` |
| `lead-create-subscription` | Cria uma assinatura própria com diário persistente e proteção contra duplicação. | escrita | altera | `connection_id`, `account_id`, `form_id`, `form_version`, `callback_url`, `idempotency_key` |
| `lead-delete-subscription` | Remove somente assinatura de autoria local comprovada e contexto vigente. | escrita (destrutiva) | altera | `connection_id`, `account_id`, `ownership_key` |
| `lead-discover-forms` | Lista formulários da conta sem conceder acesso automaticamente. | leitura | lê | `connection_id`, `account_id` |
| `lead-discovery-status` | Lê seleção, progresso e recibos locais; não chama o fornecedor. | leitura | não consulta | `connection_id` |
| `lead-effective-status` | Mostra concessão, seleção e revisões usadas pelo consumidor. | leitura | não consulta | `connection_id`, `account_id` |
| `lead-get-form` | Lê os metadados de um formulário autorizado. | leitura | lê | `connection_id`, `account_id`, `form_id` |
| `lead-get-response` | Lê uma resposta vinculada à conta e ao formulário autorizados. | leitura | lê | `connection_id`, `account_id`, `form_id`, `response_id` |
| `lead-get-subscription-operation` | Lê o diário da assinatura e informa necessidade de reconciliação. | leitura | não consulta | `connection_id`, `account_id`, `ownership_key` |
| `lead-list-form-events` | Método do SDK do consumidor 1.2; leitura recuperável e paginada de inclusões e recibos de assinatura. | leitura | não consulta | `connection_id`, `account_id` |
| `lead-list-forms` | Lista metadados dos formulários permitidos ao consumidor. | leitura | lê | `connection_id`, `account_id` |
| `lead-list-subscriptions` | Consulta assinaturas sem assumir autoria das assinaturas remotas. | leitura | lê | `connection_id`, `account_id` |
| `lead-read-responses` | Lê respostas no intervalo autorizado sem importar contatos no site. | leitura | lê | `connection_id`, `account_id`, `form_id`, `form_version`, `from_ms`, `to_ms` |
| `lead-reconcile-subscription` | Confere o recibo remoto e permite vínculo explícito à credencial atual do mesmo aplicativo. | escrita | lê | `connection_id`, `account_id`, `ownership_key`, `expected_operation_revision` |
| `lead-resolve-ad-source` | Informe conexão e conta com creative_id ou, para Lead Sync, form_id e response_id. Retorna campanha, publicação e mídia temporária sem alterar a conta. | leitura | lê | `connection_id`, `account_id` |
| `lead-resolve-campaign` | Obtém a campanha vinculada a uma resposta autorizada, com concessão explícita e diagnóstico de ausência ou falha. | leitura | lê | `connection_id`, `account_id`, `form_id`, `response_id` |
| `lead-run-discovery` | Executa passagem limitada das seleções automáticas autorizadas; pode criar webhooks e notificar consumidores. | escrita | altera | — |
| `lead-verify-challenge` | Calcula a resposta criptográfica do desafio de recebimento. | leitura | não consulta | `connection_id`, `account_id`, `challenge_code` |
| `lead-verify-notification` | Valida integridade, conta e formulário de uma notificação recebida. | leitura | não consulta | `connection_id`, `account_id`, `raw_body`, `signature` |
| `save-grant` | Autoriza um consumidor para contas, formulários e ações explicitamente selecionados. | escrita (destrutiva) | não consulta | `connection_id`, `consumer_id`, `expected_revision`, `enabled`, `permissions`, `forms` |
| `list-grants` | Lista consumidores e concessões locais em páginas. | leitura | não consulta | — |
| `get-grant` | Retorna a concessão do consumidor e sua revisão. | leitura | não consulta | `connection_id`, `consumer_id` |

## Conversões (Conversions API)

Regras de conversão, concessões de aquisição e de etapas comerciais, envio e auditoria de serviço.

| Operação | O que faz | Tipo | LinkedIn | Obrigatórios |
|---|---|---|---|---|
| `conversion-capabilities` | Leitura local do destino e motivo de bloqueio, sem chamada ao fornecedor. | leitura | não consulta | — |
| `diagnose-conversions` | Lista localmente cada requisito do envio ao servidor (concessão, conexão, conta, regra API, escopos, dono da concessão e regra do Site Core) com a ação para o que falta, sem chamada ao fornecedor. | leitura | não consulta | — |
| `list-conversion-rules` | Lista regras da conta selecionada, fonte, estado e próxima página. | leitura | lê | `connection_id`, `account_id` |
| `get-conversion-grant` | Lê o vínculo explícito de conexão, conta e regra concedido ao Site Core. | leitura | não consulta | — |
| `save-conversion-grant` | Confere escopos, papel e fonte API antes de vincular o Site Core; não envia eventos. | escrita | lê | `consumer_id`, `expected_revision`, `enabled` |
| `get-stage-conversion-grants` | Lista concessões explícitas por ação comercial, com paginação local. | leitura | não consulta | — |
| `save-stage-conversion-grant` | Prévia por padrão; confirme consumidor, finalidade, conta e ação. Confere acesso e fonte API; não envia eventos. | escrita | lê | `consumer_id`, `purpose`, `action`, `expected_revision`, `enabled` |
| `stage-conversion-capabilities` | Contrato 1.2.0: verifica localmente a concessão da ação, sem fila ou HTTP. | leitura | não consulta | `action` |
| `send-conversion-event` | Gera prévia sem dados pessoais; o envio exige confirmação e destino vigente. | escrita | altera | `destination_ref`, `payload` |
| `send-conversion-events` | Envia até cem eventos com prévia, resultado individual e proteção contra duplicação. | escrita | altera | `destination_ref`, `payloads` |
| `get-service-write-operation` | Lê snapshots técnicos com identidade e concessão vigentes; exige administrador proprietário e perfil autorizado. | leitura | não consulta | `provider`, `consumer_id`, `principal_ref`, `grant_revision`, `operation_id` |

## Anúncios e publicações

Leitura e alteração de grupos, campanhas, anúncios, publicações e mídias, com diário de intenções.

| Operação | O que faz | Tipo | LinkedIn | Obrigatórios |
|---|---|---|---|---|
| `get-ad-account` | Lê a conta selecionada e retorna revisão para criar objetos. | leitura | lê | `connection_id`, `account_id` |
| `get-organization` | Lê a Página selecionada e retorna revisão para publicações e mídias. | leitura | lê | `connection_id`, `page_id` |
| `get-campaign-group` | Retorna o objeto autorizado e sua revisão para edição. | leitura | lê | `connection_id`, `account_id`, `campaign_group_id` |
| `get-campaign` | Retorna o objeto autorizado e sua revisão para edição. | leitura | lê | `connection_id`, `account_id`, `campaign_id` |
| `get-creative` | Retorna o objeto autorizado e sua revisão para edição. | leitura | lê | `connection_id`, `account_id`, `creative_id` |
| `get-post` | Confere autoria da Página e retorna conteúdo e revisão. | leitura | lê | `connection_id`, `page_id`, `post_id` |
| `search-locations` | Busca locais pelo nome para segmentação de anúncios. | leitura | lê | `connection_id`, `account_id`, `search` |
| `search-targeting` | Busca entidades por nome e faceta, incluindo segmentos da conta selecionada. | leitura | lê | `connection_id`, `account_id`, `facet`, `search` |
| `create-campaign-group` | Prepara ou cria em rascunho, com prévia, revisão e chave de idempotência. | escrita | altera | `connection_id`, `account_id`, `expected_revision`, `request_key`, `fields` |
| `update-campaign-group` | Prepara ou altera campos permitidos, conferindo revisão e relendo o resultado. | escrita | altera | `connection_id`, `account_id`, `campaign_group_id`, `expected_revision`, `request_key`, `fields` |
| `activate-campaign-group` | Ativa separadamente após prévia e confirmação; a ativação pode iniciar veiculação paga. | escrita (destrutiva) | altera | `connection_id`, `account_id`, `campaign_group_id`, `expected_revision`, `request_key` |
| `delete-campaign-group` | Exclui rascunhos ou solicita exclusão dos demais, com prévia e releitura. | escrita (destrutiva) | altera | `connection_id`, `account_id`, `campaign_group_id`, `expected_revision`, `request_key` |
| `create-campaign` | Prepara ou cria em rascunho, com prévia, revisão e chave de idempotência. | escrita | altera | `connection_id`, `account_id`, `expected_revision`, `request_key`, `fields` |
| `update-campaign` | Prepara ou altera campos permitidos, conferindo revisão e relendo o resultado. | escrita | altera | `connection_id`, `account_id`, `campaign_id`, `expected_revision`, `request_key`, `fields` |
| `activate-campaign` | Ativa separadamente após prévia e confirmação; a ativação pode iniciar veiculação paga. | escrita (destrutiva) | altera | `connection_id`, `account_id`, `campaign_id`, `expected_revision`, `request_key` |
| `delete-campaign` | Exclui rascunhos ou solicita exclusão dos demais, com prévia e releitura. | escrita (destrutiva) | altera | `connection_id`, `account_id`, `campaign_id`, `expected_revision`, `request_key` |
| `create-creative` | Prepara ou cria em rascunho, com prévia, revisão e chave de idempotência. | escrita | altera | `connection_id`, `account_id`, `expected_revision`, `request_key`, `fields` |
| `update-creative` | Prepara ou altera campos permitidos, conferindo revisão e relendo o resultado. | escrita | altera | `connection_id`, `account_id`, `creative_id`, `expected_revision`, `request_key`, `fields` |
| `activate-creative` | Ativa separadamente após prévia e confirmação; a ativação pode iniciar veiculação paga. | escrita (destrutiva) | altera | `connection_id`, `account_id`, `creative_id`, `expected_revision`, `request_key` |
| `delete-creative` | Exclui rascunhos ou solicita exclusão dos demais, com prévia e releitura. | escrita (destrutiva) | altera | `connection_id`, `account_id`, `creative_id`, `expected_revision`, `request_key` |
| `create-post` | Publica texto, imagem, vídeo ou artigo após prévia e confirmação. | escrita (destrutiva) | altera | `connection_id`, `page_id`, `expected_revision`, `request_key`, `fields` |
| `update-post` | Altera o texto de uma publicação da Página com revisão verificada. | escrita (destrutiva) | altera | `connection_id`, `page_id`, `post_id`, `expected_revision`, `request_key`, `fields` |
| `delete-post` | Exclui uma publicação da Página após prévia e confirma a ausência na releitura. | escrita (destrutiva) | altera | `connection_id`, `page_id`, `post_id`, `expected_revision`, `request_key` |
| `create-comment` | Publica comentário em nome da Página após prévia e confirmação. | escrita (destrutiva) | altera | `connection_id`, `page_id`, `post_id`, `expected_revision`, `request_key`, `fields` |
| `initialize-image-upload` | Solicita autorização de envio de imagem pertencente à Página selecionada. | escrita | altera | `connection_id`, `page_id`, `expected_revision`, `request_key` |
| `initialize-video-upload` | Solicita autorização de envio de vídeo pertencente à Página selecionada. | escrita | altera | `connection_id`, `page_id`, `expected_revision`, `request_key`, `file_size` |
| `list-write-operations` | Leitura local por conexão e estado, IDs completos e paginação, sem corpo; preserva identidade e seleção de origem. | leitura | não consulta | `connection_id` |
| `get-write-operation` | Lê antes, depois, recibo e situação de uma escrita própria. | leitura | não consulta | `operation_id` |
| `reconcile-write-operation` | Relê o efeito de uma operação sem repetir o envio. | escrita | lê | `operation_id`, `expected_operation_revision` |
| `close-write-operation` | Simula por padrão. Encerramento local exige revisão, motivo e risco de duplicação aceito; conserva o diário e não confirma ausência remota. | escrita | não consulta | `operation_id`, `expected_operation_revision`, `reason`, `note`, `accept_duplicate_risk` |

## Como este catálogo é mantido

O texto de cada linha vem dos rótulos e schemas registrados pelo plugin. Divergência entre esta página e `linkedin/contracts` indica pacote adulterado ou catálogo não regenerado; prevalece o que `linkedin/contracts` retorna na instalação.
