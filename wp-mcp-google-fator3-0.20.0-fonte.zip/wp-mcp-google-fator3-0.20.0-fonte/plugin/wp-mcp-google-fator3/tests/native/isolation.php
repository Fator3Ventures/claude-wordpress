<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{McpBridge,Options,Recovery};
use Fator3\McpGoogle\Automation\{CronHistory,ExecutorSchedule};
use Fator3\McpGoogle\Storage\Maintenance;
rest_get_server();$routes=rest_get_server()->get_routes();$route='/'.F3BASE_REST_NAMESPACE.F3Base_Linkedin_Webhook::ROTA;
verifyLab('Core callback registered independently',isset($routes[$route]));
foreach(['acesso-verificar','consultar','webhook-configurar'] as $name){
 $name='f3base/anuncios-linkedin-'.$name;$a=wp_get_ability($name);verifyLab('Core declared write '.$name,($a->get_meta()['annotations']['readonly']??true)===false);
 $r=McpBridge::dispatch(['ability'=>$name,'parameters'=>['simular'=>true]],true);verifyLab('Google bridge refuses foreign provider '.$name,($r['error_code']??'')==='f3_google_mcp_ability');
}
$cfg=array_replace(F3Base_Linkedin::config(),['ativo'=>true,'conta_id'=>'100','formularios'=>['200'],'proprietario_confirmado'=>true,'webhook'=>['ativo'=>true],'aplicativo_id'=>'123']);
function core_saveLab($name,$value){$r=F3Base_Options::pelo_canal('ability',static fn()=>F3Base_Options::gravar($name,$value,F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao($name)));verifyLab('Core fixture saved '.$name,!empty($r['persisted']),$r);}
core_saveLab(F3Base_Linkedin::OPCAO,$cfg);core_saveLab(F3Base_Linkedin_Api::SECRET,'synthetic-linkedin-secret');
F3Base_Options::atualizar_estado('f3base_anuncios_estado',static function($s){$s['linkedin']['ativado_em']=time()-60;return $s;});
$beforeSecret=get_option(F3Base_Linkedin_Api::SECRET);$beforeConfig=F3Base_Options::ler(F3Base_Linkedin::OPCAO);
$hooks=[F3Base_Linkedin::EVENTO,F3Base_Linkedin_Webhook::EVENTO,F3Base_Linkedin_Webhook::MANUTENCAO,'f3base_pipedrive_fixture'];$events=[];
foreach($hooks as $h){if(!wp_next_scheduled($h))wp_schedule_single_event(time()+300,$h);$events[$h]=wp_get_scheduled_event($h);}
ExecutorSchedule::activate();Maintenance::run();foreach($events as $h=>$event)verifyLab('Google lifecycle preserves foreign hook '.$h,wp_get_scheduled_event($h)==$event);
verifyLab('Google maintenance preserves Core config and ciphertext',get_option(F3Base_Linkedin_Api::SECRET)===$beforeSecret&&F3Base_Options::ler(F3Base_Linkedin::OPCAO)===$beforeConfig);
$pause=Recovery::change(['action'=>'prepare']);verifyLab('Google recovery prepared',!empty($pause['success']),$pause);
$cron=CronHistory::summary('default')['last_pass'];$googleBefore=google_config_digestLab();$googleHttp=0;
$watch=static function($pre,$args,$url)use(&$googleHttp){if(str_contains($url,'googleapis.com'))++$googleHttp;return $pre;};add_filter('pre_http_request',$watch,1,3);
wp_set_current_user(0);$_SERVER['HTTPS']='on';
$r=new WP_REST_Request('GET',$route);$r->set_param('contexto',F3Base_Linkedin::contexto());$r->set_param('challengeCode','synthetic-challenge');$r->set_param('applicationId','123');
$response=rest_do_request($r);verifyLab('Core challenge succeeds without user or MCP session during Google pause',$response->get_status()===200&&($response->get_data()['challengeResponse']??'')===hash_hmac('sha256','synthetic-challenge','synthetic-linkedin-secret'),$response->get_data());
$body=wp_json_encode(['type'=>'LEAD_ACTION','leadType'=>'SPONSORED','leadAction'=>'CREATED','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:100'],'leadGenForm'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:200,1)','leadGenFormResponse'=>'urn:li:leadGenFormResponse:googleLab-isolation','occurredAt'=>time()*1000]);
$r=new WP_REST_Request('POST',$route);$r->set_param('contexto',F3Base_Linkedin::contexto());$r->set_body($body);$r->set_header('x-li-signature',hash_hmac('sha256','hmacsha256='.$body,'synthetic-linkedin-secret'));
$response=rest_do_request($r);verifyLab('Core signed receipt persists while Google is paused',$response->get_status()>=200&&$response->get_status()<300,$response->get_data());
verifyLab('Core callback creates no Google identity work or cron',get_current_user_id()===0&&$googleHttp===0&&$googleBefore===google_config_digestLab()&&$cron===CronHistory::summary('default')['last_pass']);
$table=F3Base_Linkedin_Webhook::tabela();global $wpdb;$rows=$wpdb->get_results("SELECT chave,estado,payload FROM $table WHERE resposta='googleLab-isolation'",ARRAY_A);verifyLab('Core receipt remains in its own encrypted queue',count($rows)===1&&!str_contains($rows[0]['payload'],'leadGenFormResponse'));
wp_set_current_user(1);unset($_SERVER['HTTPS']);remove_filter('pre_http_request',$watch,1);$state=Recovery::status();Recovery::change(['action'=>'resume','expected_generation'=>$state['generation'],'acknowledge_reconciled'=>true]);Maintenance::run();
verifyLab('Google resumed maintenance preserves Core pending receipt',$rows===$wpdb->get_results("SELECT chave,estado,payload FROM $table WHERE resposta='googleLab-isolation'",ARRAY_A));
finishLab('provider-isolation',['callback_scope'=>'Native REST dispatch with controlled HTTPS flag and synthetic HMAC; no external LinkedIn registration or delivery']);
