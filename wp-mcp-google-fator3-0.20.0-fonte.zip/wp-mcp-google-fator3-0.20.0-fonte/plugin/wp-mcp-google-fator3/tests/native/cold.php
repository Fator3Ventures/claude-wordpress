<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpFiles\Persistence;
$credential=rpc_identityLab();$auth=$credential['auth'];
$r=rpcLab('google/configuration-schema');verifyLab('first HTTP request discovers Google without warmup',($r['plugin']['version']??'')===expectedLab('candidate')||($r['plugin_version']??'')===expectedLab('candidate'),$r);
$r=rpcLab('google/maintenance');verifyLab('A13 current maintenance authenticated discovery and execution',!empty($r['success'])&&($r['maintenance_contract_version']??'')==='2.0.0',$r);
$all=wp_get_abilities();verifyLab('A13 removed names absent from public registry',!isset($all['google/migrate-storage'])&&!isset($all['google/complete-transition']));
$c=Persistence::get('connections',$credential['id']);$c['profile']='custom';$c['abilities']=['google/maintenance'];Persistence::put('connections',$credential['id'],$c);
$r=rpcLab('google/mcp-write',['ability'=>'google/maintenance','parameters'=>new stdClass()]);verifyLab('new target requires MCP dispatch permission as well',empty($r['success']),$r);
$c['abilities']=['google/mcp-write','google/migrate-storage'];Persistence::put('connections',$credential['id'],$c);
$r=rpcLab('google/mcp-write',['ability'=>'google/maintenance','parameters'=>new stdClass()]);verifyLab('A13 retired target grant does not authorize new maintenance',empty($r['success']),$r);
$c['profile']='maintenance';$c['abilities']=[];$c['status']='revoked';Persistence::put('connections',$credential['id'],$c);$r=rpcLab('google/status');verifyLab('revoked identity refused',empty($r['success']),$r);
$c['status']='active';$c['expires']=time()-60;Persistence::put('connections',$credential['id'],$c);$r=rpcLab('google/status');verifyLab('expired identity refused',empty($r['success']),$r);
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
$cmd=[PHP_BINARY,'-c',$lab.'/php.ini',getenv('F3_WP_CLI'),'--path='.ABSPATH,'--allow-root','--no-color','--user=1','eval','echo json_encode(["google"=>isset(wp_get_abilities()["google/maintenance"]),"servers"=>array_keys(WpMcpUltimate\\Server\\McpAdapter::instance()->get_servers())]);'];
$p=proc_open($cmd,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);$code=proc_close($p);$cli=json_decode(trim($out),true);verifyLab('first WP-CLI process has full server and Google registry',$code===0&&!empty($cli['google'])&&in_array('wp-mcp-ultimate-server',$cli['servers']??[],true),[$out,$err]);
finishLab('cold',['order'=>getenv('F3_LAB_ORDER')]);
