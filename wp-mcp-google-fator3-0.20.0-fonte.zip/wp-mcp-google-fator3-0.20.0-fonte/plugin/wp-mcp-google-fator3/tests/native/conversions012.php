<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{Options,Connections,CoreConversions,ConversionContext,CoreContext,ContractSchema,Policy,Settings};
Options::set(Options::ENABLED,true);Options::set(Options::AUDIT_LOCAL_READS,false);wp_get_abilities();
$http=0;$count=static function($pre,$args,$url)use(&$http){if(!str_starts_with($url,getenv('F3_LAB_URL').'/'))++$http;return $pre;};add_filter('pre_http_request',$count,5,3);
$before=google_config_digestLab();$cron=serialize(_get_cron_array());
$native=F3Base_Conversoes_Contexto::snapshot(['contract'=>CoreConversions::CONTRACT]);$got=CoreConversions::snapshot();
verifyLab('P12 real producer accepted without private access',$native['ok']&&$got['ok']&&$native['data']['revision']===$got['data']['revision'],$got);
verifyLab('P12 local snapshot matches pinned schema',ContractSchema::valid($got,CoreConversions::schema('snapshot')));
$r=wp_get_ability('google/conversion-context')->execute([]);
verifyLab('P12 admin ability works without Google credential',!is_wp_error($r)&&$r['success']&&$r['core_conversion_context']['ok'],$r);
verifyLab('P12 local reads leave config cron and network untouched',$before===google_config_digestLab()&&$cron===serialize(_get_cron_array())&&$http===0);
$meta=wp_get_ability('google/conversion-context')->get_meta();
verifyLab('P12 local read classified with no remote effect',$meta['fator3']['remote_effect']==='none'&&$meta['fator3']['mode']==='read');
// Exercise server-side authorization, including direct callback invocation.
$uid=wp_create_user('conversion_editor012',bin2hex(random_bytes(16)),'conversion012@example.invalid');$u=new WP_User($uid);$u->set_role('editor');
foreach([$uid,0] as $user){wp_set_current_user($user);$r=ConversionContext::read([]);verifyLab('P12 direct callback denies user '.$user,empty($r['success'])&&!isset($r['core_conversion_context']));$a=wp_get_ability('google/conversion-context')->execute([]);verifyLab('P12 registered callback denies user '.$user,is_wp_error($a)||empty($a['success']));}
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($uid);
$restrict=static fn()=>'f3_missing_admin_capability';add_filter('f3_mcp_google_capability',$restrict);verifyLab('P12 additional capability remains required',!ConversionContext::read([])['success']);remove_filter('f3_mcp_google_capability',$restrict);
Options::set(Options::ENABLED,false);verifyLab('P12 direct callback refuses closed channel',ConversionContext::read([])['error_code']==='f3_google_disabled');Options::set(Options::ENABLED,true);
$credential=rpc_identityLab();$auth=$credential['auth'];
$r=rpcLab('google/conversion-context');verifyLab('P12 new operation executes via actual MCP',!empty($r['success'])&&$r['core_conversion_context']['ok'],$r);
verifyLab('P12 false verification flags survive transport',$r['core_conversion_context']['data']['runtime_verified']===false&&$r['core_conversion_context']['data']['remote_access_verified']===false);
$conflict=rpcLab('google/conversion-context',['expected_revision'=>str_repeat('0',64)]);
verifyLab('P12 revision conflict preserves producer null',empty($conflict['success'])&&$conflict['core_conversion_context']['code']==='revision_conflict'&&array_key_exists('data',$conflict['core_conversion_context'])&&$conflict['core_conversion_context']['data']===null,$conflict);
$denied=rpc_identityLab('custom',['google/status']);$r=rpcLab('google/conversion-context',[],$denied['auth']);verifyLab('P12 MCP profile without operation is refused',empty($r['success'])&&!isset($r['core_conversion_context']),$r);WP_Application_Passwords::delete_application_password(1,$denied['uuid']);
foreach([['offset'=>0],['expected_revision'=>'stale']] as $input){$r=rpcLab('google/conversion-context',$input);verifyLab('P12 MCP closed input '.key($input),empty($r['success']),$r);}
function writeCore012($key,$value): void {$r=F3Base_Options::pelo_canal('ability',fn()=>F3Base_Options::gravar($key,$value,F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao($key)));verifyLab('Fixture stored by Core public writer '.$key,!empty($r['persisted']),$r);}
function material012(array $r): array {foreach($r['data']['purposes'] as $p)if($p['purpose']==='material')return $p;throw new RuntimeException('Missing material');}
$prior=[];foreach(['f3base_conversoes_conteudo','f3base_google_ads','f3base_linkedin_conteudo_conversion_id'] as $key)$prior[$key]=F3Base_Options::ler($key);
writeCore012('f3base_conversoes_conteudo',['ga4'=>true,'google_ads'=>true,'meta'=>true,'linkedin'=>true]);
$ads=$prior['f3base_google_ads'];$ads['conversion_label']='Contact012';$ads['conteudo_conversion_label']='';writeCore012('f3base_google_ads',$ads);writeCore012('f3base_linkedin_conteudo_conversion_id','');
$m=material012(CoreConversions::snapshot());verifyLab('P12 material never inherits contact Ads label',$m['destinations']['google_ads']['identifiers']['conversion_label']===''&&$m['destinations']['google_ads']['configured']===false);
verifyLab('P12 empty material LinkedIn ID preserved',$m['destinations']['linkedin']['identifiers']['conversion_id']===''&&$m['destinations']['linkedin']['configured']===false);
$ads['conteudo_conversion_label']='Material012';writeCore012('f3base_google_ads',$ads);writeCore012('f3base_linkedin_conteudo_conversion_id','67890');
$r=rpcLab('google/conversion-context');$m=material012($r['core_conversion_context']);verifyLab('P12 own material IDs survive MCP',$m['destinations']['google_ads']['identifiers']['conversion_label']==='Material012'&&$m['destinations']['linkedin']['identifiers']['conversion_id']==='67890');
verifyLab('P12 provenance remains available',count($m['destinations']['google_ads']['provenance'])===3&&is_bool($m['destinations']['google_ads']['enabled']));
$invalid=static fn($v)=>'invalid-id';add_filter('option_f3base_linkedin_conteudo_conversion_id',$invalid);
$r=CoreConversions::snapshot();verifyLab('P12 real filtered identifier follows producer normalization',$r['ok']&&material012($r)['destinations']['linkedin']['identifiers']['conversion_id']===''&&material012($r)['destinations']['linkedin']['provenance'][2]['changed_by_filter']===true,$r);remove_filter('option_f3base_linkedin_conteudo_conversion_id',$invalid);
writeCore012('f3base_conversoes_conteudo',['ga4'=>false,'google_ads'=>false,'meta'=>false,'linkedin'=>false]);$m=material012(CoreConversions::snapshot());verifyLab('P12 disabled material remains explicit',array_column($m['destinations'],'enabled')===[false,false,false,false]);
$events=CoreContext::events(CoreContext::snapshot());verifyLab('P12 original SDK still excludes material event',$events['ok']&&!in_array('download_material',array_column($events['data']['items'],'name'),true));
verifyLab('P12 all local conversion scenarios made no provider calls',$http===0,$http);
// Existing GTM request is simulated, with the real Core running around it.
Connections::create('gtm012','Synthetic GTM context');
Connections::run('gtm012',static function(){Options::batch_verified([Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',Connections::SERVICES=>['gtm'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[Options::OAUTH_CLIENT_SECRET=>'synthetic-012',Options::OAUTH_REFRESH_TOKEN=>'synthetic-012']);});
$mutate=false;$calls=0;
$fixture=static function($pre,$args,$url)use(&$mutate,&$calls){
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access012','expires_in'=>3600];
 elseif(str_contains($url,'tagmanager.googleapis.com')&&str_contains($url,'versions:live')){
  ++$calls;if($mutate){$c=F3Base_Options::ler('f3base_conversoes_conteudo');$c['ga4']=!$c['ga4'];writeCore012('f3base_conversoes_conteudo',$c);}
  $body=['containerVersionId'=>'123','tag'=>[]];
 }else return $pre;
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
$r=Connections::run('gtm012',fn()=>wp_get_ability('gtm/diagnostico')->execute(['container_path'=>'accounts/123/containers/456']));
verifyLab('P12 GTM static diagnostic includes coherent extra context',!is_wp_error($r)&&$r['success']&&$r['core_conversion_context']['ok']&&$r['runtime_verified']===false&&count($r['slots'])===6,$r);
$mutate=true;$r=Connections::run('gtm012',fn()=>wp_get_ability('gtm/diagnostico')->execute(['container_path'=>'accounts/123/containers/456']));
verifyLab('P12 changing only material preserves old diagnosis and rejects extra block',!is_wp_error($r)&&$r['success']&&$r['core_conversion_context']['code']==='revision_conflict'&&$r['core_conversion_context']['data']===null,$r);
verifyLab('P12 no repeat of GTM request on revision conflict',$calls===2,$calls);
remove_filter('pre_http_request',$fixture,1);
foreach($prior as $key=>$value)writeCore012($key,$value);
remove_filter('pre_http_request',$count,5);WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
finishLab('conversions012',['core_contract'=>CoreConversions::CONTRACT,'gtm'=>'simulated Google response; real Core producer','gtm_reads'=>$calls]);
