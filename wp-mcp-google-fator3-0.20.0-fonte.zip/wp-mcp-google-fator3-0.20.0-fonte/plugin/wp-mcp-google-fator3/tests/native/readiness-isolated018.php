<?php
/** 0.18.0 M2 without MCP and Core: readiness stays local and reports the Core as not configured. */
require __DIR__.'/common.php';
use Fator3\McpGoogle\Readiness;
$external=0;add_filter('pre_http_request',static function($pre,$args,$url)use(&$external){if(!str_starts_with($url,getenv('F3_LAB_URL').'/'))++$external;return $pre;},0,3);
verifyLab('No Core SDK and no MCP in this lab',!class_exists('F3Base_Medicao_Contexto')&&!defined('F3_MCP_FILES_VERSION'));
$before=google_config_digestLab();$a=wp_get_ability('google/readiness-status');verifyLab('Ability registered without companions',$a!==null);
$r=$a->execute([]);verifyLab('Readiness answers without companions',!is_wp_error($r)&&$r['success']&&$r['contract']===Readiness::CONTRACT,$r);
$core=array_values(array_filter($r['checks'],static fn($c)=>$c['id']==='core'))[0]??[];
verifyLab('Absent Core is not_configured, not an error',$core['state']==='not_configured'&&$core['code']==='core_absent',$core);
verifyLab('Isolated readiness made no provider call and changed nothing',$external===0&&$before===google_config_digestLab());
finishLab('readiness-isolated018');
