<?php
require __DIR__.'/common.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
$header=get_plugin_data(WP_PLUGIN_DIR.'/wp-mcp-google-fator3/wp-mcp-google-fator3.php');
verifyLab('Pedido 25 exact WordPress minimum executed',$GLOBALS['wp_version']===$header['RequiresWP']&&$header['RequiresWP']==='7.1.2');
verifyLab('Pedido 25 exact PHP minimum executed',PHP_VERSION===$header['RequiresPHP']&&$header['RequiresPHP']==='8.3.6');
verifyLab('WordPress native requirements accept candidate',validate_plugin_requirements('wp-mcp-google-fator3/wp-mcp-google-fator3.php')===true);
verifyLab('Fresh process runs intended candidate',F3_MCP_GOOGLE_VERSION===expectedLab('candidate'));
verifyLab('Storage ready before any repair in this process',Fator3\McpGoogle\Storage\State::guard()===null);
$before=google_config_digestLab();$index=Fator3\McpGoogle\Documentation::read([]);
verifyLab('Help works locally without provider credentials',$index['success']&&$index['plugin_version']===expectedLab('candidate'));
verifyLab('Help preserves configuration',$before===google_config_digestLab());
verifyLab('Help identifies current guide',in_array('GUIA-0.16.0.md',array_column($index['documents'],'document'),true)&&!in_array('GUIA-0.12.0.md',array_column($index['documents'],'document'),true));
finishLab('minimum016',['requires_wordpress'=>$header['RequiresWP'],'requires_php'=>$header['RequiresPHP'],'scenario'=>getenv('F3_LAB_ORIGIN')]);
