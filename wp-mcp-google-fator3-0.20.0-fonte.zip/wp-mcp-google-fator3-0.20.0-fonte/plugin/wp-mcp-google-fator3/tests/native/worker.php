<?php
require __DIR__.'/common.php';
$mode=$argv[1]??'repair';
if($mode==='stale'){file_put_contents($lab.'/stale-ready','ready');$deadline=microtime(true)+15;while(!is_file($lab.'/stale-go')&&microtime(true)<$deadline)usleep(10000);}
if($mode==='inflight') add_filter('pre_schedule_event',static function($pre,$event)use($lab){if($event->hook!==Fator3\McpGoogle\Automation\Jobs::HOOK)return $pre;file_put_contents($lab.'/inflight-ready','ready');$until=microtime(true)+15;while(!is_file($lab.'/inflight-go')&&microtime(true)<$until)usleep(10000);return $pre;},1,2);
$r=$mode==='mcp'?Fator3\McpFiles\CronMarker::activate():Fator3\McpGoogle\Automation\ExecutorSchedule::ensure('concurrent_test');
echo json_encode($r)."\n";
