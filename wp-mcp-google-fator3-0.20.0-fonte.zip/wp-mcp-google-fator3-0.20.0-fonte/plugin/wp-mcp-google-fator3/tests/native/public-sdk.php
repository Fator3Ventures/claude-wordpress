<?php
$fixture=getenv('F3_FIXTURE_ROOT').'/wordpress/wp-content/mu-plugins/99-google-isolation-fixture.php';
file_put_contents($fixture,<<<'FIXTURE'
<?php
add_action('f3_mcp_register_providers',static function(){foreach(['meta','linkedin'] as $prefix)Fator3\McpFiles\ExtensionContract::register('fixture-'.$prefix,'1.0.0',[$prefix.'/']);});
add_action('wp_abilities_api_init',static function(){foreach(['meta','linkedin'] as $prefix)wp_register_ability($prefix.'/fixture-read',['label'=>'Fixture','description'=>'Foreign fixture for isolation','category'=>'google','input_schema'=>['type'=>'object'],'output_schema'=>['type'=>'object'],'permission_callback'=>'__return_true','execute_callback'=>static fn()=>['success'=>true],'meta'=>['fator3'=>['provider'=>'fixture-'.$prefix,'version'=>'1.0.0','policy_contract'=>1,'mode'=>'read'],'annotations'=>['readonly'=>true],'mcp'=>['public'=>true,'type'=>'tool']]]);},100);
FIXTURE
);
require __DIR__.'/common.php';
unlink($fixture);
use Fator3\McpGoogle\{CoreContext,CoreBinding,Distribution,Updater,Options,ContractSchema,Channel,McpBridge};
use Fator3\McpFiles\{ExecutorRegistry,PackageDistribution,Persistence,ConnectionContext};
wp_get_abilities();rest_get_server();
$registry=ExecutorRegistry::finalize();$entries=array_column($registry['admitted'],null,'ability');
foreach(['read','write'] as $mode){$d=$entries['google/mcp-'.$mode]??[];verifyLab('explicit public Google executor '.$mode,($d['provider']??'')===Channel::PROVIDER&&($d['mode']??'')===$mode&&count($d['allowed_targets']['prefixes']??[])===6,$registry);}
$network=0;add_filter('pre_http_request',static function($pre)use(&$network){++$network;return $pre;},1);
$s=CoreContext::snapshot();verifyLab('Core public six-slot snapshot validates',$s['ok']&&count($s['data']['slots'])===6,$s);
$e=CoreContext::events($s,20,5);verifyLab('Core public catalog paginated and revision bound',$e['ok']&&$e['data']['complete']&&$e['data']['total']===count($e['data']['items'])&&$e['data']['total']>5,$e);
$source=CoreBinding::source();verifyLab('Core binding consumes same public revision',!is_wp_error($source)&&$source['revision']===$s['data']['revision']);
verifyLab('public diagnostic discovery does not request remote services',$network===0);
// Native fixture setup of the producer selection; runtime Google reads only the public SDK/receipt.
$before=get_option('f3_mcp_update_channels',[]);$own=get_option(Updater::OPTION,null);
try {
 update_option('f3_mcp_update_channels',[]);$p=Distribution::selection();verifyLab('public provider selection',$p['origin']==='provider'&&$p['available']);
 $a=Updater::configure(['origin'=>['enabled'=>false]]);verifyLab('own origin saves verified consent',$a['success']);
 update_option('f3_mcp_update_channels',[Distribution::PACKAGE=>['url'=>'https://example.invalid/feed','hosts'=>['example.invalid']]]);PackageDistribution::publish_selection();
 $m=Distribution::selection();verifyLab('MCP wins explicit distribution selection',$m['origin']==='mcp'&&$m['available']);verifyLab('changed selection rejects prior offer',is_wp_error(Distribution::guard($p)));
 verifyLab('MCP selection receipt remains available when producer is absent',get_option(Distribution::RECEIPT)['packages'][Distribution::PACKAGE]===$m);
 $r=Updater::check(true);verifyLab('failed MCP feed does not fall back to provider',!$r['success']&&$r['owner']==='mcp',$r);
 verifyLab('MCP filter remains registered',has_filter('upgrader_pre_download',[Fator3\McpFiles\UpdateChannel::class,'download'])!==false);
} finally {update_option('f3_mcp_update_channels',$before);PackageDistribution::publish_selection();if($own===null)delete_option(Updater::OPTION);else update_option(Updater::OPTION,$own);}
// Five registered owners, including synthetic future providers, remain separate.
foreach(['meta','linkedin'] as $prefix){$ability=wp_get_ability($prefix.'/fixture-read');verifyLab('foreign fixture actually registered '.$prefix,$ability!==null&&($ability->get_meta()['fator3']['provider']??'')==='fixture-'.$prefix,$ability?$ability->get_meta():null);$r=McpBridge::dispatch(['ability'=>$prefix.'/fixture-read'],false);verifyLab('Google refuses '.$prefix.' despite category',$r['error_code']==='f3_google_mcp_ability');}
$r=McpBridge::dispatch(['ability'=>'google/mcp-read'],false);verifyLab('Google rejects nested executor',$r['error_code']==='f3_google_mcp_input');
$cred=WP_Application_Passwords::create_new_application_password(1,['name'=>'Google SDK lab']);$id='app:'.$cred[1]['uuid'];Persistence::put('connections',$id,['connection_id'=>$id,'user_id'=>1,'profile'=>'read','status'=>'active','policy_version'=>1,'expires'=>0]);
do_action('application_password_did_authenticate',get_user_by('id',1),$cred[1]);$principal=Channel::principal();verifyLab('real MCP grant principal revalidates',$principal!==null&&Channel::validate_principal($principal)===null,['principal'=>$principal,'policy'=>ConnectionContext::policy($id),'error'=>Channel::validate_principal($principal)]);
$context=Fator3\McpGoogle\Automation\Context::capture();$jobId='sdk-result-'.bin2hex(random_bytes(4));
Fator3\McpGoogle\Records::put('job',$jobId,['id'=>$jobId,'connection_id'=>'default','user_id'=>1,'status'=>'completed','task'=>'query','parameters'=>['connector'=>'ga4','accounts'=>['properties/123'],'collection'=>['mode'=>'complete']],'context'=>$context,'created_at'=>time(),'updated_at'=>time(),'expires_at'=>time()+3600,'result'=>['success'=>true,'rows'=>[['synthetic']]]]);
$r=Fator3\McpGoogle\Automation\Operations::action('get-job',['job_id'=>$jobId]);verifyLab('original grant can inspect its completed query',!empty($r['success']),$r);
$other=WP_Application_Passwords::create_new_application_password(1,['name'=>'Other Google SDK lab']);$otherId='app:'.$other[1]['uuid'];Persistence::put('connections',$otherId,['connection_id'=>$otherId,'user_id'=>1,'profile'=>'custom','abilities'=>['google/get-job'],'status'=>'active','policy_version'=>1,'expires'=>0]);
do_action('application_password_did_authenticate',get_user_by('id',1),$other[1]);$r=Fator3\McpGoogle\Automation\Operations::action('get-job',['job_id'=>$jobId]);verifyLab('another grant of same user cannot retrieve original query',($r['error_code']??'')==='f3_google_collection_actor'&&!isset($r['job']),$r);WP_Application_Passwords::delete_application_password(1,$other[1]['uuid']);do_action('application_password_did_authenticate',get_user_by('id',1),$cred[1]);
Persistence::put('connections',$id,['connection_id'=>$id,'user_id'=>1,'profile'=>'read','status'=>'revoked','policy_version'=>1,'expires'=>0]);verifyLab('revoked real grant blocks continuation',is_wp_error(Channel::validate_principal($principal)));WP_Application_Passwords::delete_application_password(1,$cred[1]['uuid']);
finishLab('public-sdk',['remote_google'=>'none','core_contract'=>CoreContext::CONTRACT,'executor_contract'=>$registry['contract'],'distribution_contract'=>Distribution::CONTRACT]);
