<?php
require __DIR__.'/common.php';
$frame=Fator3\McpGoogle\Automation\CronHistory::begin(['cron014'],'interruption-fixture',true);
echo 'FRAME:'.json_encode($frame)."\n";fflush(STDOUT);
if (($argv[1]??'')==='fatal') {trigger_error('synthetic fatal 014',E_USER_ERROR);}
if (($argv[1]??'')==='time-limit') {set_time_limit(1);while(true){hash('sha256','cpu-time-limit-fixture');}}
if (($argv[1]??'')==='kill') {fgets(STDIN);}
exit;
