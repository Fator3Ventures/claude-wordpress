<?php
$lab=getenv('F3_FIXTURE_ROOT');$owner=json_decode(file_get_contents($lab.'/.google-lab-owner.json'),true);
if(($owner['id']??'')!==getenv('F3_LAB_ID')||($owner['path']??'')!==realpath($lab))throw new RuntimeException('Owned laboratory required');
$_SERVER['HTTP_HOST']=parse_url(getenv('F3_LAB_URL'),PHP_URL_HOST).':'.parse_url(getenv('F3_LAB_URL'),PHP_URL_PORT);$_SERVER['SERVER_NAME']='127.0.0.1';
require $lab.'/wordpress/wp-load.php';wp_set_current_user(1);
if(class_exists('Fator3\McpFiles\Persistence')) Fator3\McpFiles\Persistence::put('connections','integration:user:1',['connection_id'=>'integration:user:1','user_id'=>1,'status'=>'active','profile'=>'maintenance']);
$checks=[];
function expectedLab(string $name): string {return json_decode(file_get_contents(getenv('F3_LAB_MANIFEST')),true)['inputs'][$name]['version'];}
function verifyLab(string $label,bool $ok,$detail=null): void {global $checks;if(!$ok)throw new RuntimeException($label.' '.json_encode($detail));$checks[]=$label;}
function finishLab(string $name,array $extra=[]): void {
    global $checks;
    $data=['checks'=>count($checks),'passed'=>$checks,'failures'=>0,'candidate_sha256'=>hash_file('sha256',getenv('F3_CANDIDATE')),'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'google'=>defined('F3_MCP_GOOGLE_VERSION')?F3_MCP_GOOGLE_VERSION:null,'mcp'=>defined('F3_MCP_FILES_VERSION')?F3_MCP_FILES_VERSION:null,'core'=>defined('F3BASE_PLUGIN_VERSAO')?F3BASE_PLUGIN_VERSAO:null]+$extra;
    file_put_contents(getenv('F3_EVIDENCE_DIR').'/'.$name.'.json',json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n");
    echo json_encode(['suite'=>$name,'checks'=>count($checks)])."\n";
}
function google_config_digestLab(): string {global $wpdb;$rows=$wpdb->get_results("SELECT option_name,option_value FROM $wpdb->options WHERE option_name LIKE 'f3_mcp_google_%' AND option_name NOT LIKE 'f3_mcp_google_lock_%' ORDER BY option_name",ARRAY_A);return hash('sha256',serialize($rows));}
