<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Connections,Options,Records,Lock};
use Fator3\McpGoogle\Automation\{CronHistory as H,CronCoverage as C,Executor};
use Fator3\McpGoogle\Storage\CronStore;
Connections::create('cron014','Cron evidence fixture');$cid='cron014';$key='f3_mcp_google_cron_gap_'.$cid;
$s=C::snapshot($cid);verifyLab('Coverage snapshot records empty work metadata',$s!==null&&$s['records']===0&&$s['next_due_at']===null,$s);
Options::set($key,['at'=>time(),'run_id'=>'empty-interval','reason'=>'event_not_confirmed','cause_code'=>'unknown','cause_known'=>false,'work_before'=>$s]);
$before=google_config_digestLab();$status=H::summary($cid);verifyLab('Status never repairs an observation gap',$before===google_config_digestLab()&&$status['coverage_gap']!==null&&$status['observation_health']==='gap');
$r=C::reconcile($cid);$status=H::summary($cid);verifyLab('Authorized next pass can prove unchanged empty interval',!empty($r['resolved'])&&$status['coverage_gap']===null&&$status['last_coverage_gap']['resolved_by']['basis']==='no_due_work_in_unchanged_interval',$r);
$before=C::snapshot($cid);$job=['id'=>'transient014','connection_id'=>$cid,'status'=>'queued','task'=>'preflight','run_after'=>time()-5];Records::put('job','transient014',$job);Records::remove('job','transient014');$after=C::snapshot($cid);
verifyLab('Sequence detects work inserted and deleted between snapshots',$before['fingerprint']!==$after['fingerprint'],[$before,$after]);
Options::set($key,['at'=>time(),'run_id'=>'hidden-work','reason'=>'event_not_confirmed','work_before'=>$before]);$r=C::reconcile($cid);verifyLab('Current empty queue cannot erase unproven historical work',empty($r['resolved'])&&H::summary($cid)['coverage_gap']!==null,$r);
$job['id']='due014';Records::put('job','due014',$job);$before=C::snapshot($cid);verifyLab('Due job is visible in interval evidence',$before['next_due_at']!==null&&$before['next_due_at']<=time(),$before);
Options::set($key,['at'=>time(),'run_id'=>'due-work','reason'=>'event_not_confirmed','work_before'=>$before]);verifyLab('Unchanged but due queue does not close gap',empty(C::reconcile($cid)['resolved']));Records::remove('job','due014');
Options::set($key,['at'=>time(),'run_id'=>'legacy','reason'=>'event_not_confirmed']);verifyLab('Legacy unknown interval remains unknown',empty(C::reconcile($cid)['resolved']));Options::delete($key);
function child014($mode) {
 $p=proc_open([PHP_BINARY,__DIR__.'/cron014-child.php',$mode],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);if(!is_resource($p))throw new RuntimeException('child failed');
 $frame=null;while(($line=fgets($pipes[1]))!==false){if(str_starts_with($line,'FRAME:')){$frame=json_decode(substr($line,6),true);break;}}
 if(!$frame)throw new RuntimeException('missing frame '.stream_get_contents($pipes[2]));
 if($mode==='kill'){proc_terminate($p,9);}fclose($pipes[0]);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($p);return [$frame,$exit];
}
[$frame,$exit]=child014('exit');$row=CronStore::get('pass',$cid,$frame['run_id'])['value'];verifyLab('Actual early process exit records unconfirmed work',$row['state']==='interrupted'&&$row['success']===null&&$row['reason_code']==='shutdown_before_completion'&&$row['cause_known']===false,$row);
verifyLab('Shutdown reason retains observed provenance',$row['reason_evidence']==='shutdown_handler');
[$frame,$exit]=child014('fatal');$row=CronStore::get('pass',$cid,$frame['run_id'])['value'];verifyLab('Actual PHP fatal records observed cause',$row['state']==='interrupted'&&$row['reason_code']==='php_fatal'&&$row['cause_known']===true,$row);
[$frame,$exit]=child014('time-limit');$row=CronStore::get('pass',$cid,$frame['run_id'])['value'];verifyLab('Actual CPU time limit records observed cause',$row['state']==='interrupted'&&$row['reason_code']==='time_limit'&&$row['cause_known']===true,$row);
$wpdb->delete(CronStore::table(),['connection_id'=>$cid]);Options::delete('f3_mcp_google_cron_history_'.$cid);
[$frame,$exit]=child014('kill');$row=CronStore::get('pass',$cid,$frame['run_id'])['value'];verifyLab('Killed process cannot fabricate terminal result',$row['state']==='running'&&$row['success']===null,$row);
$status=H::summary($cid);verifyLab('Dead database session is observation gap not hosting diagnosis',$status['completion_unconfirmed']&&$status['ultima_manual']['reason_code']==='completion_not_recorded'&&$status['ultima_manual']['cause_known']===false,$status);
// Advance only the persisted fixture's observation age; no claim of a three-day run.
$row['at']=time()-121;$row['started_at']=$row['at'];$row['work_before']['at']=$row['at'];$l=Lock::acquire('test-cron014',30);CronStore::put('pass',$cid,$row['run_id'],$row,null,$l);Lock::release($l);
$r=H::reconcile($cid);$row=CronStore::get('pass',$cid,$row['run_id'])['value'];verifyLab('Next authorized pass stores observed interruption without invented finish',$r['success']&&$row['state']==='interrupted'&&$row['finished_at']===null,$r);
$gap=Options::get($key);verifyLab('Next pass closes only proven idle interval',isset($gap['resolved_at']),$gap);$at=$gap['resolved_at'];H::reconcile($cid);verifyLab('Historical interruption does not reopen a resolved gap',Options::get($key)['resolved_at']===$at);
$frame=H::begin([$cid],'normal014');$status=H::summary($cid);verifyLab('Live request stays running',$status['ultima_manual']['state']==='running'&&!$status['completion_unconfirmed'],$status);
$r=H::finish($frame,[$cid=>['state'=>'completed','success'=>true,'connection_examined'=>true,'reason_code'=>'no_due_work','cause_known'=>true]]);verifyLab('Normal completion keeps explicit outcome',$r['passes'][$cid]['success']===true&&$r['passes'][$cid]['reason_code']==='no_due_work');
$status=Connections::run($cid,static fn()=>Executor::status());verifyLab('Current work observation does not claim historical proof',isset($status['work_observation'])&&$status['work_observation']['interval_proven']===false,$status);
finishLab('cron014',['faults'=>'native PHP exit, fatal error, CPU time limit and SIGKILL; historical age advanced in fixture','three_day_observation'=>false]);
