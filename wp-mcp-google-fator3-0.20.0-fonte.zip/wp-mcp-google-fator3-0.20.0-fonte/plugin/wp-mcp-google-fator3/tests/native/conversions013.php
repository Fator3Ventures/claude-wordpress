<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{Options,Connections,CoreConversions,ConversionContext,CoreContext,ContractSchema,Policy,Settings};
Options::set(Options::ENABLED,true);Options::set(Options::AUDIT_LOCAL_READS,false);wp_get_abilities();
$http=0;$count=static function($pre,$args,$url)use(&$http){if(!str_starts_with($url,getenv('F3_LAB_URL').'/'))++$http;return $pre;};add_filter('pre_http_request',$count,5,3);
$before=google_config_digestLab();$cron=serialize(_get_cron_array());
$native=F3Base_Conversoes_Contexto::snapshot(['contract'=>CoreConversions::CONTRACT]);$got=CoreConversions::snapshot();
verifyLab('P13 real producer accepted without private access',$native['ok']&&$got['ok']&&$native['data']['revision']===$got['data']['revision'],$got);
verifyLab('P13 local snapshot matches pinned schema',ContractSchema::valid($got,CoreConversions::schema('snapshot')));
$r=wp_get_ability('google/conversion-context')->execute([]);
verifyLab('P13 admin ability works without Google credential',!is_wp_error($r)&&$r['success']&&$r['core_conversion_context']['ok'],$r);
verifyLab('P13 local reads leave config cron and network untouched',$before===google_config_digestLab()&&$cron===serialize(_get_cron_array())&&$http===0);
$meta=wp_get_ability('google/conversion-context')->get_meta();
verifyLab('P13 local read classified with no remote effect',$meta['fator3']['remote_effect']==='none'&&$meta['fator3']['mode']==='read');
// Exercise server-side authorization, including direct callback invocation.
$uid=wp_create_user('conversion_editor012',bin2hex(random_bytes(16)),'conversion012@example.invalid');$u=new WP_User($uid);$u->set_role('editor');
foreach([$uid,0] as $user){wp_set_current_user($user);$r=ConversionContext::read([]);verifyLab('P13 direct callback denies user '.$user,empty($r['success'])&&!isset($r['core_conversion_context']));$a=wp_get_ability('google/conversion-context')->execute([]);verifyLab('P13 registered callback denies user '.$user,is_wp_error($a)||empty($a['success']));}
wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($uid);
$restrict=static fn()=>'f3_missing_admin_capability';add_filter('f3_mcp_google_capability',$restrict);verifyLab('P13 additional capability remains required',!ConversionContext::read([])['success']);remove_filter('f3_mcp_google_capability',$restrict);
Options::set(Options::ENABLED,false);verifyLab('P13 direct callback refuses closed channel',ConversionContext::read([])['error_code']==='f3_google_disabled');Options::set(Options::ENABLED,true);
$credential=rpc_identityLab();$auth=$credential['auth'];
$r=rpcLab('google/conversion-context');verifyLab('P13 new operation executes via actual MCP',!empty($r['success'])&&$r['core_conversion_context']['ok'],$r);
verifyLab('P13 false verification flags survive transport',$r['core_conversion_context']['data']['runtime_verified']===false&&$r['core_conversion_context']['data']['remote_access_verified']===false);
$conflict=rpcLab('google/conversion-context',['expected_revision'=>str_repeat('0',64)]);
verifyLab('P13 revision conflict preserves producer null',empty($conflict['success'])&&$conflict['core_conversion_context']['code']==='revision_conflict'&&array_key_exists('data',$conflict['core_conversion_context'])&&$conflict['core_conversion_context']['data']===null,$conflict);
verifyLab('P13 MCP conflict true and not retryable',$conflict['conflict']===true&&$conflict['retryable']===false&&$conflict['operation_outcome']==='not_applicable',$conflict);
verifyLab('P13 normal SDK error has no current revision',!array_key_exists('current_revision',$conflict));
$direct=ConversionContext::read(['expected_revision'=>str_repeat('0',64)]);
verifyLab('P13 direct callback classifies revision conflict',$direct['conflict']===true&&$direct['retryable']===false&&!isset($direct['current_revision']),$direct);
$repeat=rpcLab('google/conversion-context',['expected_revision'=>str_repeat('0',64)]);
verifyLab('P13 repeating stale guard stays conflict',$repeat['conflict']===true&&!$repeat['success']);
$fresh=rpcLab('google/conversion-context');$revision=$fresh['core_conversion_context']['data']['revision'];
$guarded=rpcLab('google/conversion-context',['expected_revision'=>$revision]);
verifyLab('P13 fresh reread and current guard succeed',$fresh['success']&&$guarded['success']&&empty($guarded['conflict'])&&!isset($guarded['current_revision']));
$invalid=ConversionContext::read(['expected_revision'=>'invalid']);
verifyLab('P13 invalid input is not a conflict',$invalid['core_conversion_context']['code']==='invalid_input'&&$invalid['conflict']===false&&$invalid['retryable']===false&&!isset($invalid['current_revision']));
$denied=rpc_identityLab('custom',['google/status']);$r=rpcLab('google/conversion-context',[],$denied['auth']);verifyLab('P13 MCP profile without operation is refused',empty($r['success'])&&!isset($r['core_conversion_context']),$r);WP_Application_Passwords::delete_application_password(1,$denied['uuid']);
foreach([['offset'=>0],['expected_revision'=>'stale']] as $input){$r=rpcLab('google/conversion-context',$input);verifyLab('P13 MCP closed input '.key($input),empty($r['success']),$r);}
function writeCore012($key,$value): void {$r=F3Base_Options::pelo_canal('ability',fn()=>F3Base_Options::gravar($key,$value,F3Base_Options::ORIGEM_ABILITY,F3Base_Options::revisao($key)));verifyLab('Fixture stored by Core public writer '.$key,!empty($r['persisted']),$r);}
function material012(array $r): array {foreach($r['data']['purposes'] as $p)if($p['purpose']==='material')return $p;throw new RuntimeException('Missing material');}
$prior=[];foreach(['f3base_conversoes_conteudo','f3base_google_ads','f3base_linkedin_conteudo_conversion_id'] as $key)$prior[$key]=F3Base_Options::ler($key);
writeCore012('f3base_conversoes_conteudo',['ga4'=>true,'google_ads'=>true,'meta'=>true,'linkedin'=>true]);
$ads=$prior['f3base_google_ads'];$ads['conversion_label']='Contact012';$ads['conteudo_conversion_label']='';writeCore012('f3base_google_ads',$ads);writeCore012('f3base_linkedin_conteudo_conversion_id','');
$m=material012(CoreConversions::snapshot());verifyLab('P13 material never inherits contact Ads label',$m['destinations']['google_ads']['identifiers']['conversion_label']===''&&$m['destinations']['google_ads']['configured']===false);
verifyLab('P13 empty material LinkedIn ID preserved',$m['destinations']['linkedin']['identifiers']['conversion_id']===''&&$m['destinations']['linkedin']['configured']===false);
$ads['conteudo_conversion_label']='Material012';writeCore012('f3base_google_ads',$ads);writeCore012('f3base_linkedin_conteudo_conversion_id','67890');
$r=rpcLab('google/conversion-context');$m=material012($r['core_conversion_context']);verifyLab('P13 own material IDs survive MCP',$m['destinations']['google_ads']['identifiers']['conversion_label']==='Material012'&&$m['destinations']['linkedin']['identifiers']['conversion_id']==='67890');
verifyLab('P13 provenance remains available',count($m['destinations']['google_ads']['provenance'])===3&&is_bool($m['destinations']['google_ads']['enabled']));
$invalid=static fn($v)=>'invalid-id';add_filter('option_f3base_linkedin_conteudo_conversion_id',$invalid);
$r=CoreConversions::snapshot();verifyLab('P13 real filtered identifier follows producer normalization',$r['ok']&&material012($r)['destinations']['linkedin']['identifiers']['conversion_id']===''&&material012($r)['destinations']['linkedin']['provenance'][2]['changed_by_filter']===true,$r);remove_filter('option_f3base_linkedin_conteudo_conversion_id',$invalid);
writeCore012('f3base_conversoes_conteudo',['ga4'=>false,'google_ads'=>false,'meta'=>false,'linkedin'=>false]);$m=material012(CoreConversions::snapshot());verifyLab('P13 disabled material remains explicit',array_column($m['destinations'],'enabled')===[false,false,false,false]);
$events=CoreContext::events(CoreContext::snapshot());verifyLab('P13 original SDK still excludes material event',$events['ok']&&!in_array('download_material',array_column($events['data']['items'],'name'),true));
verifyLab('P13 all local conversion scenarios made no provider calls',$http===0,$http);
// Existing GTM request is simulated, with the real Core running around it.
Connections::create('gtm012','Synthetic GTM context');
Connections::run('gtm012',static function(){Options::batch_verified([Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',Connections::SERVICES=>['gtm'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[Options::OAUTH_CLIENT_SECRET=>'synthetic-012',Options::OAUTH_REFRESH_TOKEN=>'synthetic-012']);});
$mutate=false;$calls=0;
$fixture=static function($pre,$args,$url)use(&$mutate,&$calls){
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access012','expires_in'=>3600];
 elseif(str_contains($url,'tagmanager.googleapis.com')&&str_contains($url,'versions:live')){
  ++$calls;if($mutate){$c=F3Base_Options::ler('f3base_conversoes_conteudo');$c['ga4']=!$c['ga4'];writeCore012('f3base_conversoes_conteudo',$c);}
  $body=['containerVersionId'=>'123','tag'=>[]];
 }else return $pre;
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
$r=Connections::run('gtm012',fn()=>wp_get_ability('gtm/diagnostico')->execute(['container_path'=>'accounts/123/containers/456']));
verifyLab('P13 GTM static diagnostic includes coherent extra context',!is_wp_error($r)&&$r['success']&&$r['core_conversion_context']['ok']&&$r['runtime_verified']===false&&count($r['slots'])===6,$r);
$mutate=true;$r=Connections::run('gtm012',fn()=>wp_get_ability('gtm/diagnostico')->execute(['container_path'=>'accounts/123/containers/456']));
verifyLab('P13 changing only material preserves old diagnosis and rejects extra block',!is_wp_error($r)&&$r['success']&&$r['core_conversion_context']['code']==='revision_conflict'&&$r['core_conversion_context']['data']===null,$r);
verifyLab('P13 no repeat of GTM request on revision conflict',$calls===2,$calls);
remove_filter('pre_http_request',$fixture,1);
foreach($prior as $key=>$value)writeCore012($key,$value);
remove_filter('pre_http_request',$count,5);WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
finishLab('conversions013',['core_contract'=>CoreConversions::CONTRACT,'gtm'=>'simulated Google response; real Core producer','gtm_reads'=>$calls]);
