<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{Options,Connections,Configuration,Catalog};
Options::set(Options::ENABLED,true);
$credential=rpc_identityLab();$auth=$credential['auth'];
Connections::create('boolean012','Synthetic boolean contract');
$booleanIds=array_keys(array_filter(Configuration::definitions(),static fn($d)=>($d['schema']['type']??null)==='boolean'));
verifyLab('Pedido 26 all five declared boolean options covered',count($booleanIds)===5,$booleanIds);
foreach(['default','boolean012'] as $id){
 Connections::run($id,static function(){Options::set(Options::ENABLED,true);Options::set(Options::SA_SUBJECT,'');});
 foreach([false,true,false] as $value){
  $prior=rpcLab('google/configuration-schema',['connection_id'=>$id]);
  $write=rpcLab('google/configure-local',['expected_revision'=>$prior['configuration_revision'],'connection_id'=>$id,'audit_local_reads'=>$value,'purge_on_uninstall'=>$value]);
  verifyLab('Pedido 26 public write succeeds '.$id.' '.json_encode($value),!empty($write['success']),$write);
  $read=rpcLab('google/configuration-schema',['connection_id'=>$id,'include_values'=>true]);
  verifyLab('Pedido 26 fresh MCP read confirms boolean values '.$id.' '.json_encode($value),!empty($read['success'])&&$read['options']['audit_local_reads']['state']['effective_value']===$value&&$read['options']['purge_on_uninstall']['state']['effective_value']===$value,$read['error_code']??null);
  verifyLab('Pedido 26 textual empty remains string '.$id,$read['options']['sa_subject']['state']['effective_value']==='');
  foreach($booleanIds as $key)verifyLab('Boolean schema matches effective value '.$id.' '.$key.' '.json_encode($value),is_bool($read['options'][$key]['state']['effective_value']));
  verifyLab('WordPress persisted representation observed '.$id.' '.json_encode($value),$read['options']['audit_local_reads']['state']['persisted_value']===($value?'1':''),$read['options']['audit_local_reads']['state']);
 }
}
// Use a fresh PHP request to exercise enabled=false through the authenticated admin reader.
$probe=getenv('F3_FIXTURE_ROOT').'/boolean-admin-probe.php';
file_put_contents($probe,"<?php require getenv('F3_WP_ROOT');wp_set_current_user(1);echo json_encode(Fator3\\McpGoogle\\Configuration::read_for_admin());");
foreach([false,true] as $value){
 foreach($booleanIds as $id)Options::set(Configuration::definitions()[$id]['option_name'],$value);
 $pipes=[];$p=proc_open([PHP_BINARY,'-c',getenv('F3_FIXTURE_ROOT').'/php.ini',$probe],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$raw=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);$status=proc_close($p);$read=json_decode($raw,true);
 verifyLab('Fresh admin read with every boolean '.$value,$status===0&&!empty($read['success']),[$status,$err]);
 foreach($booleanIds as $id)verifyLab('Every declared boolean roundtrips '.$id.' '.json_encode($value),$read['options'][$id]['state']['effective_value']===$value);
}
unlink($probe);Options::set(Options::AUDIT_LOCAL_READS,false);Options::set('f3_mcp_google_purge_on_uninstall',false);
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
finishLab('booleans012',['pedido'=>'Pedido MCP Google 26','declared_boolean_ids'=>$booleanIds,'connections'=>['default','boolean012'],'fresh_requests'=>true]);
