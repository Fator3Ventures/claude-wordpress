<?php
/**
 * 0.18.0 Melhorias M3 e M4.
 * M4: the GA4 delivery connection is selected by its stream, not by the site-wide measurement ID read from the Core.
 * M3: read-only status computes one Core snapshot per call; dispatch fences keep reading the Core afresh.
 */
require __DIR__.'/common.php';
use Fator3\McpGoogle\{ConversionDelivery as D,CoreContext,Options as O,Connections as C,Policy,Settings};
O::set(D::CONFIG,D::defaults());wp_get_abilities();update_option('f3base_ga4_measurement_id','G-TEST018');
$calls=[];$secret='synthetic-mp-018';$during=null;
$fixture=static function($pre,$args,$url)use(&$calls,$secret,&$during){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;
 $calls[]=[$url,$args];$body=[];$c=O::get(D::CONFIG);
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access018','expires_in'=>3600];
 elseif(str_contains($url,'measurementProtocolSecrets'))$body=['measurementProtocolSecrets'=>[['secretValue'=>$secret]]];
 elseif(str_contains($url,'analyticsadmin.googleapis.com'))$body=['name'=>$c['stream'],'webStreamData'=>['measurementId'=>get_option('f3base_ga4_measurement_id')]];
 elseif(str_contains($url,'/debug/mp/collect')){$body=['validationMessages'=>[]];if($during){$f=$during;$during=null;$f();}}
 elseif(str_contains($url,'/mp/collect'))$body=[];
 elseif(str_contains($url,'googleAds:search'))$body=['results'=>[['conversionAction'=>['resourceName'=>$c['conversion_action'],'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>0,'defaultCurrencyCode'=>'BRL']]]]];
 elseif(str_contains($url,'/events:ingest'))$body=[];
 else return $pre;
 return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
$credentials=static fn()=>O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-018',O::OAUTH_REFRESH_TOKEN=>'synthetic-018',O::ADS_DEVELOPER_TOKEN=>'synthetic-dev018']);
$credentials();
function selection018(string $target): array {$a=D::adapter(null,$target,D::CONTRACT);$cap=$a->capabilities();return ['connection'=>$cap['connection_id'],'ready'=>$cap['ready'],'reason'=>$cap['reason'],'adapter'=>$a];}
// Default connection delivers Google Ads only.
$r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789']]);verifyLab('Default connection saves Ads-only delivery',!empty($r['success']),$r);
verifyLab('Ads verifies on default connection',!empty(D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads'])['success']));
// Second connection delivers GA4 only.
C::create('analytics018','GA4 delivery');
C::run('analytics018',static function()use($credentials,$secret){$credentials();O::set(D::CONFIG,D::defaults());
 $r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'stream'=>'properties/18/dataStreams/180'],'mp_secret'=>$secret]);verifyLab('Second connection saves GA4-only delivery',!empty($r['success']),$r);
 verifyLab('GA4 verifies on second connection',!empty(D::verify(['expected_revision'=>D::revision(),'target'=>'ga4'])['success']));});
$ga=selection018('ga4');$ads=selection018('google_ads');
verifyLab('M4 GA4 selects the connection that owns the stream',$ga['connection']==='analytics018'&&$ga['ready']&&$ga['reason']==='ok',$ga);
verifyLab('M4 Ads keeps selecting its own connection',$ads['connection']==='default'&&$ads['ready'],$ads);
if(is_callable(['F3Base_Conversoes_Transporte','capacidade']))verifyLab('M4 Core transport sees both destinations ready',F3Base_Conversoes_Transporte::capacidade('ga4')['ready']&&F3Base_Conversoes_Transporte::capacidade('google_ads')['ready']);
// M3: query budget of the read-only report.
$core=0;$all=0;add_filter('query',static function($q)use(&$core,&$all){++$all;if(str_contains($q,'f3base_'))++$core;return $q;});
$measure=static function(callable $f)use(&$core,&$all){$core=0;$all=0;$t=microtime(true);$r=$f();return ['core'=>$core,'all'=>$all,'ms'=>round((microtime(true)-$t)*1000,1),'result'=>$r];};
$one=$measure(static fn()=>CoreContext::snapshot());$again=$measure(static fn()=>CoreContext::snapshot());
verifyLab('Outside a read scope every Core snapshot reads the Core again',$one['core']>0&&$again['core']>0,[$one['core'],$again['core']]);
$scoped=$measure(static fn()=>CoreContext::within_read_scope(static function(){CoreContext::snapshot();return CoreContext::snapshot();}));
verifyLab('Inside a read scope the second snapshot costs no Core query',$scoped['core']===$one['core'],[$scoped['core'],$one['core']]);
$transport=$measure(static fn()=>D::core_transport());
$status=$measure(static fn()=>D::status());
verifyLab('M3 conversion status reads the Core once plus the transport snapshot',$status['core']<=$one['core']+$transport['core'],['status'=>$status['core'],'snapshot'=>$one['core'],'transport'=>$transport['core']]);
$st=D::status();verifyLab('Per-connection status: Ads-only connection shows GA4 without destination, not ambiguity',$st['ga4']['connection_id']==='default'&&!$st['ga4']['ready']&&$st['ga4']['reason']==='destination_missing'&&$st['google_ads']['ready'],[$st['ga4']['reason'],$st['google_ads']['reason']]);
$st2=C::run('analytics018',static fn()=>D::status());verifyLab('Per-connection status: GA4 connection is ready',$st2['ga4']['connection_id']==='analytics018'&&$st2['ga4']['ready']&&!$st2['google_ads']['ready'],[$st2['ga4']['reason'],$st2['google_ads']['reason']]);
$ability=$measure(static fn()=>wp_get_ability('google/conversion-delivery-status')->execute([]));
verifyLab('Ability response unchanged in shape',!is_wp_error($ability['result'])&&$ability['result']['success']&&isset($ability['result']['ga4'],$ability['result']['google_ads'],$ability['result']['core_transport']));
// Dispatch fence reads the Core afresh: changing the measurement ID during the debug call stops collection.
$now=time()-5;$id=str_repeat('b',32);
$payload=['record_id'=>$id,'event_id'=>$id,'occurred_at'=>gmdate('c',$now),'measurement_id'=>'G-TEST018','event_name'=>'generate_lead','client_id'=>'123.456','session_id'=>'42','timestamp_micros'=>$now*1000000];
$adapter=$ga['adapter'];$ref=$adapter->capabilities()['destination_ref'];
$during=static function(){update_option('f3base_ga4_measurement_id','G-CHANGED018');};$n=count($calls);
try{wp_set_current_user(0);$result=$adapter->sendBound($payload,$ref);}finally{wp_set_current_user(1);}
$collected=array_filter(array_slice($calls,$n),static fn($c)=>str_contains($c[0],'/mp/collect')&&!str_contains($c[0],'/debug/'));
verifyLab('Fence observes Core change made during dispatch and never collects',$result['status']==='recusado'&&!empty($result['non_delivery_proven'])&&in_array($result['code'],['destination_mismatch','authorization_changed'],true)&&!$collected,$result);
update_option('f3base_ga4_measurement_id','G-TEST018');
$r=$adapter->sendBound($payload,$adapter->capabilities()['destination_ref']);verifyLab('Restored destination delivers through selected connection',$r['status']==='entregue',$r);
// Ambiguity is still detected when two connections own a GA4 stream.
$r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'stream'=>'properties/1/dataStreams/2']]);verifyLab('Default connection also gets a stream',!empty($r['success']),$r);
$amb=selection018('ga4');verifyLab('Two GA4 streams remain ambiguous and blocked',!$amb['ready']&&$amb['reason']==='ambiguous_connection',$amb);
remove_filter('pre_http_request',$fixture,1);C::run('analytics018',static fn()=>O::set(D::CONFIG,D::defaults()));O::set(D::CONFIG,D::defaults());
finishLab('delivery018',['core_queries'=>['snapshot'=>$one['core'],'transport'=>$transport['core'],'status'=>$status['core'],'status_all_queries'=>$status['all'],'status_ms'=>$status['ms'],'ability_all_queries'=>$ability['all'],'ability_ms'=>$ability['ms']],'provider_calls'=>'synthetic only']);
