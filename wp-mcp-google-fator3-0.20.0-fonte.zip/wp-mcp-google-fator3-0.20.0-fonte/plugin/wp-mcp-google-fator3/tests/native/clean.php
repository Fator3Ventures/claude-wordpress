<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options,Connections,Configuration,Settings,Setup};use Fator3\McpGoogle\Automation\{ExecutorSchedule,Executor,Jobs};
verifyLab('clean candidate active',F3_MCP_GOOGLE_VERSION===expectedLab('candidate')&&in_array('wp-mcp-google-fator3/wp-mcp-google-fator3.php',get_option('active_plugins'),true));
verifyLab('clean activation selected Service Account by default',Options::auth_mode()==='service_account');
verifyLab('clean activation requires no Google credentials to schedule',ExecutorSchedule::status()['state']==='present'&&ExecutorSchedule::status()['occurrences']===1,ExecutorSchedule::status());
verifyLab('clean contract is 4.0.0',Configuration::read()['contract_version']==='4.0.0');
$before=Settings::revision();$p=Setup::apply(['dry_run'=>true,'services'=>['gtm'=>'write'],'merge'=>true]);verifyLab('clean inherited merge preserves effective GA GSC and disabled Ads',$p['success']&&$p['services_after']['ga']['enabled']&&$p['services_after']['gsc']['enabled']&&!$p['services_after']['ads']['enabled']&&$before===Settings::revision(),$p);
$foreign=wp_get_scheduled_event('f3_mcp_cron_observed');$one=ExecutorSchedule::ensure();verifyLab('clean repeat repair is no-op and MCP event unchanged',$one['success']&&!$one['changed']&&wp_get_scheduled_event('f3_mcp_cron_observed')==$foreign);
verifyLab('current tables ready without historical marker',Fator3\McpGoogle\Storage\State::status()['ready']&&get_option('f3_mcp_google_storage',null)===null);
verifyLab('no migration hook scheduled',!wp_next_scheduled('f3_mcp_google_storage_step'));
verifyLab('retired routes absent',!isset(wp_get_abilities()['google/migrate-storage'])&&!isset(wp_get_abilities()['google/complete-transition'])&&isset(wp_get_abilities()['google/maintenance']));
finishLab('clean',['install'=>'Fresh WordPress database; exact installers identified by manifest and evidence.']);
