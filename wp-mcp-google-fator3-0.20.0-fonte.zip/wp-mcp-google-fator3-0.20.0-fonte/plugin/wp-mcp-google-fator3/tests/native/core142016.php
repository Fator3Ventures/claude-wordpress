<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Policy,ConversionDelivery as D};
verifyLab('Companion is unmodified Core 1.42.0',F3BASE_PLUGIN_VERSAO==='1.42.0'&&!is_callable(['F3Base_Conversoes_Servidor','reconciliar']));
O::batch_verified([O::ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic',O::OAUTH_REFRESH_TOKEN=>'synthetic',O::ADS_DEVELOPER_TOKEN=>'synthetic']);
D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789']]);
$cap=(new D('google_ads'))->capabilities();verifyLab('Ads fails closed without Core asynchronous extension',!$cap['ready']&&$cap['reason']==='core_async_unsupported',$cap);
verifyLab('Static help remains available without extension',Fator3\McpGoogle\Documentation::read([])['success']);
finishLab('core142016');
