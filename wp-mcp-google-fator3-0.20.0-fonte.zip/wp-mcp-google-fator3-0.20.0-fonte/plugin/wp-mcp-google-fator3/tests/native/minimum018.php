<?php
/** 0.18.0: declared minimums, fresh-process identity and local help. Records the WordPress actually executed. */
require __DIR__.'/common.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
$header=get_plugin_data(WP_PLUGIN_DIR.'/wp-mcp-google-fator3/wp-mcp-google-fator3.php');
verifyLab('Header declares WordPress 7.1.2 and PHP 8.3.6',$header['RequiresWP']==='7.1.2'&&$header['RequiresPHP']==='8.3.6',$header);
verifyLab('Header version equals runtime constant',$header['Version']===F3_MCP_GOOGLE_VERSION&&F3_MCP_GOOGLE_VERSION===expectedLab('candidate'));
verifyLab('Executed PHP is the declared minimum',PHP_VERSION===$header['RequiresPHP']);
if(getenv('F3_LAB_WP_EXPECTED'))verifyLab('Executed WordPress is the lab-declared version '.getenv('F3_LAB_WP_EXPECTED'),$GLOBALS['wp_version']===getenv('F3_LAB_WP_EXPECTED'));
verifyLab('Executed WordPress is not older than the declared minimum',version_compare($GLOBALS['wp_version'],$header['RequiresWP'],'>='));
verifyLab('WordPress native requirements accept candidate',validate_plugin_requirements('wp-mcp-google-fator3/wp-mcp-google-fator3.php')===true);
verifyLab('Storage ready before any repair in this process',Fator3\McpGoogle\Storage\State::guard()===null);
$before=google_config_digestLab();$index=Fator3\McpGoogle\Documentation::read([]);
verifyLab('Help works locally without provider credentials',$index['success']&&$index['plugin_version']===expectedLab('candidate'));
verifyLab('Help preserves configuration',$before===google_config_digestLab());
verifyLab('Help identifies current guide only',in_array('GUIA-'.expectedLab('candidate').'.md',array_column($index['documents'],'document'),true)&&!in_array('GUIA-0.17.0.md',array_column($index['documents'],'document'),true));
finishLab('minimum018',['requires_wordpress'=>$header['RequiresWP'],'requires_php'=>$header['RequiresPHP'],'executed_wordpress'=>$GLOBALS['wp_version'],'scenario'=>getenv('F3_LAB_ORIGIN')]);
