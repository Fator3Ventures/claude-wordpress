<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{ConversionDelivery as D,Options as O,Connections as C,Policy,Settings,Configuration,CoreConversions};
wp_get_abilities();verifyLab('Native Core worker hook registered',has_action('f3base_conversoes_servidor')!==false&&F3Base_Operacao::agenda()['conversoes_servidor']['registrada'],['installation'=>F3Base_Instalacao::resumo(),'recovery'=>F3Base_Recuperacao::ler()]);$calls=[];$scenario='ok';$secret='synthetic-mp-014';
$fixture=static function($pre,$args,$url)use(&$calls,&$scenario,$secret){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;
 $calls[]=[$url,$args];$body=[];$code=200;
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access014','expires_in'=>3600];
 elseif(str_contains($url,'measurementProtocolSecrets'))$body=['measurementProtocolSecrets'=>[['secretValue'=>$scenario==='wrong-secret'?'different':$secret]]];
 elseif(str_contains($url,'analyticsadmin.googleapis.com'))$body=['name'=>'properties/123/dataStreams/456','webStreamData'=>['measurementId'=>$scenario==='wrong-stream'?'G-WRONG':'G-TEST014']];
 elseif(str_contains($url,'/debug/mp/collect'))$body=['validationMessages'=>$scenario==='bad-debug'?[['description'=>'invalid fixture']]:[]];
 elseif(str_contains($url,'/mp/collect')){if($scenario==='timeout')return new WP_Error('http_request_failed','fixture timeout');$code=204;}
 elseif(str_contains($url,'googleAds:search'))$body=['results'=>[['conversionAction'=>['resourceName'=>'customers/1234567890/conversionActions/789','type'=>'UPLOAD_CLICKS','status'=>'ENABLED']]]];
 elseif(str_contains($url,':uploadClickConversions')){
  if($scenario==='timeout')return new WP_Error('http_request_failed','fixture timeout');
  $sent=json_decode($args['body'],true)['conversions'][0];$result=array_intersect_key($sent,array_flip(['conversionAction','conversionDateTime','gclid','gbraid','wbraid']));
  if($scenario==='action-only')$result=['conversionAction'=>$sent['conversionAction']];
  if($scenario==='wrong-click')$result['gclid']='another';
  $body=$scenario==='partial'?['partialFailureError'=>['code'=>3]]:['results'=>[$result]];
 }else return $pre;
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>$code===204?'':wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
$before=google_config_digestLab();$r=D::status();verifyLab('Local status needs no provider call',$r['success']&&count($calls)===0&&$before===google_config_digestLab());
verifyLab('Unconfigured adapter is unready',!(new D('ga4'))->capabilities()['ready']);
$existing=new stdClass();verifyLab('Preserves other adapter',D::adapter($existing,'ga4',D::CONTRACT)===$existing);verifyLab('Unsupported contract does not register',D::adapter(null,'ga4','unknown')===null);
$config=['enabled'=>true,'measurement_id'=>'G-TEST014','stream'=>'properties/123/dataStreams/456','customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789'];
$r=D::configure(['expected_revision'=>str_repeat('0',64),'config'=>$config]);verifyLab('Stale config revision refused',!$r['success']&&$r['conflict']);
$r=D::configure(['expected_revision'=>D::revision(),'config'=>$config+['value'=>123]]);verifyLab('Unknown config fields refused',!$r['success']);
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-014',O::OAUTH_REFRESH_TOKEN=>'synthetic-014',O::ADS_DEVELOPER_TOKEN=>'synthetic-dev014']);
$r=D::configure(['expected_revision'=>D::revision(),'config'=>$config,'mp_secret'=>$secret]);verifyLab('Configuration and encrypted secret persisted',$r['success']&&O::get_secret(D::SECRET)===$secret&&get_option(D::SECRET)!==$secret,$r);
verifyLab('Configuration alone cannot authorize delivery',!(new D('ga4'))->capabilities()['ready']);
$scenario='wrong-stream';$r=D::verify(['expected_revision'=>D::revision(),'target'=>'ga4']);verifyLab('Rejects unrelated stream measurement',$r['code']==='stream_unverified',$r);
$scenario='wrong-secret';$r=D::verify(['expected_revision'=>D::revision(),'target'=>'ga4']);verifyLab('Debug alone cannot validate MP secret',$r['code']==='mp_secret_unverified',$r);
$scenario='ok';$r=D::verify(['expected_revision'=>D::revision(),'target'=>'ga4']);verifyLab('GA4 verifies ownership secret and debug',$r['success'],$r);
verifyLab('Verification makes GA4 locally ready',(new D('ga4'))->capabilities()['ready']);
$r=D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);verifyLab('Developer token alone never proves upload eligibility',$r['code']==='eligibility_attestation_required');
$receipt=['customer_id'=>$config['customer_id'],'conversion_action'=>$config['conversion_action'],'successful_upload_confirmed'=>true,'request_id'=>'synthetic-receipt014'];
$r=D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads','eligibility_receipt'=>$receipt]);verifyLab('Ads verifies action with explicit administrative attestation',$r['success'],$r);
verifyLab('Attestation provenance remains explicit',D::status()['ads_eligibility_source']==='administrator_attestation_and_action_read');
$ga=new D('ga4');$ads=new D('google_ads');$now=time()-5;$id=str_repeat('a',32);
$payload=['record_id'=>$id,'event_id'=>$id,'occurred_at'=>gmdate('c',$now),'measurement_id'=>$config['measurement_id'],'event_name'=>'generate_lead','client_id'=>'123.456','session_id'=>'42','timestamp_micros'=>$now*1000000];
function dispatch014($adapter,$payload){try{wp_set_current_user(0);return $adapter->send($payload);}finally{wp_set_current_user(1);}}
$r=dispatch014($ga,$payload);verifyLab('Stored background grant works without impersonation',$r['status']==='entregue'&&$r['processed']===null,$r);$sent=json_decode(end($calls)[1]['body'],true);
verifyLab('GA4 preserves client session event and original timestamp',$sent['client_id']===$payload['client_id']&&$sent['timestamp_micros']===$payload['timestamp_micros']&&$sent['events'][0]['params']['session_id']==='42'&&$sent['events'][0]['params']['event_id']===$id);
verifyLab('GA4 does not fabricate engagement',!isset($sent['events'][0]['params']['engagement_time_msec']));
$scenario='bad-debug';$n=count($calls);$r=dispatch014($ga,$payload);verifyLab('Failed debug prevents collection',$r['status']==='recusado'&&$r['non_delivery_proven']&&count($calls)===$n+1,$r);
$scenario='timeout';$n=count($calls);$r=dispatch014($ga,$payload);verifyLab('GA4 timeout is uncertain and never retried',$r['status']==='incerto'&&count($calls)===$n+2,$r);
$scenario='ok';$expired=$payload;$expired['occurred_at']=gmdate('c',$now-73*3600);$expired['timestamp_micros']=($now-73*3600)*1000000;$n=count($calls);verifyLab('GA4 rejects outside collection window without HTTP',dispatch014($ga,$expired)['status']==='recusado'&&count($calls)===$n);
$p=['record_id'=>$id,'event_id'=>$id,'order_id'=>$id,'occurred_at'=>gmdate('c',$now),'click_ids'=>['gclid'=>'original-click'],'ad_user_data'=>'GRANTED','value'=>37.5,'currency'=>'BRL'];
$r=dispatch014($ads,$p);verifyLab('Ads accepts matching individual result',$r['status']==='entregue',$r);$sent=json_decode(end($calls)[1]['body'],true);$one=$sent['conversions'][0];
verifyLab('Ads preserves order value currency and consent',count($sent['conversions'])===1&&$one['orderId']===$id&&$one['conversionValue']===37.5&&$one['currencyCode']==='BRL'&&$one['consent']['adUserData']==='GRANTED');
foreach(['action-only','wrong-click','partial','timeout'] as $scenario){$n=count($calls);$r=dispatch014($ads,$p);verifyLab('Ads '.$scenario.' remains uncertain without HTTP replay',$r['status']==='incerto'&&count($calls)===$n+1,$r);}
$scenario='ok';$bad=$p;$bad['click_ids']['wbraid']='another';$n=count($calls);verifyLab('Ambiguous click IDs rejected before HTTP',dispatch014($ads,$bad)['status']==='recusado'&&count($calls)===$n);
$bad=$p;$bad['ad_user_data']='DENIED';verifyLab('Missing consent prevents upload',dispatch014($ads,$bad)['status']==='recusado');
$n=count($calls);$before=google_config_digestLab();$status=D::status();verifyLab('Ready status is still strictly local',count($calls)===$n&&$before===google_config_digestLab()&&!str_contains(wp_json_encode($status),$secret));
verifyLab('Old and negotiated Core read contracts coexist',CoreConversions::snapshot()['ok']&&(!class_exists('F3Base_Conversoes_Contexto')||$status['core_transport']['ok']),$status['core_transport']);
ob_start();D::screen();$html=ob_get_clean();verifyLab('Administrative form has fields nonce and no secret echo',str_contains($html,'type="password"')&&str_contains($html,'_wpnonce')&&!str_contains($html,$secret));
// Real Core journal and worker with synthetic HTTP only; fixtures may seed private test data.
verifyLab('Core recognizes installed Google provider',F3Base_Conversoes_Servidor::adaptador('ga4') instanceof D);
foreach (['ok','timeout'] as $scenario) {
 wp_set_current_user(0);$record=F3Base_Leads_Repositorio::guardar(['nome'=>'Fixture','email'=>'delivery014@example.test','metodo'=>'formulario','captura'=>'aceito','formulario'=>'fixture014','contexto_teste'=>false,'notificar'=>false]);wp_set_current_user(1);
 verifyLab('Native Core persists synthetic contact '.$scenario,!empty($record['persisted']),$record);$rid=$record['record_id'];$lead=F3Base_Leads_Repositorio::obter($rid);$d=$lead['dados'];
 $d['conversoes_transporte']['destinos']=['ga4'=>'servidor','google_ads'=>'servidor'];$d['audiencia_excluida']=false;$d['consentimento_snapshot']=['medicao'=>true,'publicidade'=>true,'politica_versao'=>'legado:'.F3Base_Modulo_Consentimento::politica_versao()];
 $d['ga4']=['client_id'=>'123.456','session_id'=>'42','measurement_id'=>'G-TEST014'];$d['atribuicao']=['gclid'=>'original-click'];
 $wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>wp_json_encode($d),'classe_trafego'=>'nao_marcado'],['record_id'=>$rid]);$lead=F3Base_Leads_Repositorio::obter($rid);
 F3Base_Conversoes_Servidor::capturar($lead,'ga4');F3Base_Conversoes_Servidor::capturar($lead,'google_ads');F3Base_Conversoes_Servidor::capturar($lead,'ga4');
 $rows=F3Base_Conversoes_Servidor::ler(['record_id'=>$rid])['entregas'];verifyLab('Core enqueues once per target '.$scenario,count($rows)===2,$rows);
 F3Base_Execucoes::encerrar();if($scenario==='ok'){$worker=F3Base_Operacao::executar_uma('conversoes_servidor','administracao',false);}else{sleep(1);wp_set_current_user(0);do_action('f3base_conversoes_servidor');wp_set_current_user(1);F3Base_Execucoes::encerrar();}$rows=F3Base_Conversoes_Servidor::ler(['record_id'=>$rid])['entregas'];$state=$scenario==='ok'?'entregue':'incerto';verifyLab('Core journals adapter outcome '.$scenario,array_column($rows,'estado')===[$state,$state],$rows+['worker'=>$worker??null,'core_last_error'=>$wpdb->last_error,'core_remaining'=>F3Base_Execucoes::restante_ms()]);
 $n=count($calls);wp_set_current_user(0);do_action('f3base_conversoes_servidor');wp_set_current_user(1);verifyLab('Core never replays delivered or uncertain rows '.$scenario,count($calls)===$n);
}
$scenario='ok';
C::create('delivery014','second destination');verifyLab('New connection has independent configuration and secret',C::run('delivery014',static fn()=>D::status()['config']===D::defaults()&&O::get_secret(D::SECRET)===''));C::run('delivery014',static fn()=>O::set(D::CONFIG,$config));verifyLab('Two selected connections fail closed',D::adapter(null,'ga4',D::CONTRACT)->capabilities()['reason']==='ambiguous_connection'&&!D::status()['ga4']['ready']);C::run('delivery014',static fn()=>O::set(D::CONFIG,D::defaults()));verifyLab('Disabling second connection restores unique provider',D::adapter(null,'ga4',D::CONTRACT)->capabilities()['ready']);
$profiles=O::get(C::SERVICES);O::set(C::SERVICES,['ga'=>'read','ads'=>'write']);verifyLab('Service downgrade immediately revokes readiness',!$ga->capabilities()['ready']);O::set(C::SERVICES,$profiles);
$old=O::get(D::CONFIG);O::set(D::CONFIG,array_replace($old,['granted_by'=>0]));verifyLab('Revoked administrator grant blocks background',!$ga->capabilities()['ready']);O::set(D::CONFIG,$old);
$defs=Configuration::definitions();verifyLab('Configuration discovers scoped protected MP secret',$defs['mp_secret']['secret']&&$defs['mp_secret']['scope']==='connection'&&$defs['mp_secret']['schema']['writeOnly']);
$r=D::configure(['expected_revision'=>D::revision(),'config'=>$config,'clear_mp_secret'=>true]);verifyLab('Explicit secret removal revokes readiness',$r['success']&&O::get_secret(D::SECRET)===''&&!$ga->capabilities()['ready']);
wp_set_current_user(0);verifyLab('Direct administrative callbacks enforce authority',!D::status()['success']&&!D::configure([])['success']&&!D::verify([])['success']);wp_set_current_user(1);
$credential=rpc_identityLab();$auth=$credential['auth'];$r=rpcLab('google/conversion-delivery-status');verifyLab('Status reachable through authenticated MCP',!empty($r['success'])&&$r['config']['enabled']===true,$r);WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
O::set(D::CONFIG,D::defaults());remove_filter('pre_http_request',$fixture,1);
finishLab('delivery014',['provider_calls'=>'all simulated; no commercial writes','core_contract'=>D::CONTRACT]);
