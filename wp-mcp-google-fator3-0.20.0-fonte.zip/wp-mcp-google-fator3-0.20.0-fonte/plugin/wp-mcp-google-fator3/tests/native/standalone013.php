<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options,CoreConversions,ConversionContext,Connections,Policy,Settings};
Options::set(Options::ENABLED,true);wp_get_abilities();
verifyLab('P12 no Core class installed',!class_exists('F3Base_Conversoes_Contexto'));
$r=wp_get_ability('google/conversion-context')->execute([]);verifyLab('P12 optional reader reports unavailable',!is_wp_error($r)&&!$r['success']&&$r['core_conversion_context']===CoreConversions::failure('unavailable'),$r);
verifyLab('P13 absent producer is not a conflict',$r['conflict']===false&&$r['retryable']===false&&!isset($r['current_revision']));
$before=google_config_digestLab();$r=ConversionContext::read([]);verifyLab('P12 direct absence does not create configuration',$before===google_config_digestLab());
Options::batch_verified([Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',Connections::SERVICES=>['gtm'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[Options::OAUTH_CLIENT_SECRET=>'synthetic-isolated',Options::OAUTH_REFRESH_TOKEN=>'synthetic-isolated']);
$fixture=static function($pre,$args,$url){if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-isolated','expires_in'=>3600];elseif(str_contains($url,'tagmanager.googleapis.com')&&str_contains($url,'versions:live'))$body=['containerVersionId'=>'1','tag'=>[]];else return $pre;return ['response'=>['code'=>200],'headers'=>[],'body'=>wp_json_encode($body)];};add_filter('pre_http_request',$fixture,1,3);
$r=wp_get_ability('gtm/diagnostico')->execute(['container_path'=>'accounts/123/containers/456']);verifyLab('P12 standalone GTM remains usable with optional context absent',!is_wp_error($r)&&$r['success']&&$r['core_available']===false&&$r['core_conversion_context']['code']==='unavailable',$r);remove_filter('pre_http_request',$fixture,1);
finishLab('standalone013',['provider'=>'absent','google_transport'=>'simulated']);
