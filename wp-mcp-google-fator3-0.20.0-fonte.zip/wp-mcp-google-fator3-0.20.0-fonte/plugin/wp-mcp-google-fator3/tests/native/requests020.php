<?php
/** Real WordPress/SQL; deterministic provider fixture; no supplier homologation. */
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options as O,Connections as C,Settings,Records,Audit,Catalog,Configuration};
use Fator3\McpGoogle\Integration\{Ga4ServiceApi as Api,ServiceApi,Ga4Quota};
wp_get_abilities();
$old=[];foreach([O::AUDIT_RETENTION,O::JOB_DETAIL_DAYS,O::JOB_SUMMARY_DAYS] as $name)$old[$name]=O::get($name,null);
$r=wp_get_ability('google/configure-local')->execute(['expected_revision'=>Settings::revision(),'audit_retention'=>0,'job_detail_days'=>0,'job_summary_days'=>0]);verifyLab('37 configure unlimited via native ability',!is_wp_error($r)&&$r['success'],$r);
$s=Configuration::read(['include_values'=>true]);foreach(['audit_retention','job_detail_days','job_summary_days']as $key)verifyLab('37 schema exposes unlimited '.$key,$s['options'][$key]['schema']['default']===0&&$s['options'][$key]['schema']['minimum']===0&&$s['options'][$key]['mcp_mutable']);
$bad=Catalog::configure(['expected_revision'=>Settings::revision(),'job_detail_days'=>0,'job_summary_days'=>730]);verifyLab('37 finite summary refuses infinite detail',!$bad['success']&&$bad['error_code']==='f3_google_retention_order');
$job=['id'=>'legacy020','status'=>'completed','connection_id'=>'default','created_at'=>1,'updated_at'=>1,'expires_at'=>2];
Records::put('job','legacy020',$job);Records::put('result','legacy020_row',['task'=>'legacy020','value'=>'preserve-result-020']);Records::put('summary','summary020',['expires_at'=>2,'connection_id'=>'default','status'=>'completed']);Records::put('dedupe','dedupe020',['expires_at'=>2,'connection_id'=>'default']);
for($n=0;$n<1003;$n++)Audit::log('fixture:retention-020','-',['n'=>$n]);
$kept=[];foreach([['job','legacy020'],['result','legacy020_row'],['summary','summary020'],['dedupe','dedupe020']] as [$kind,$id])$kept[$kind]=Records::get($kind,$id);
$auditBefore=Fator3\McpGoogle\Storage\Repository::select('audit',[],1200);verifyLab('37 audit exceeds previous default',count($auditBefore)>1000);
$r=wp_get_ability('google/maintenance')->execute([]);verifyLab('37 maintenance executes',!is_wp_error($r)&&$r['success'],$r);
foreach([['job','legacy020'],['result','legacy020_row'],['summary','summary020'],['dedupe','dedupe020']] as [$kind,$id])verifyLab('37 maintenance keeps expired '.$kind,Records::get($kind,$id)===$kept[$kind]);
foreach($auditBefore as $row)verifyLab('37 audit retained '.$row['record_id'],Records::get('audit',$row['record_id'])!==null);
// Connection-local SDK test identity. No real secrets or real Google network.
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'read'],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-client',O::OAUTH_REFRESH_TOKEN=>'synthetic-refresh']);
$cfg=['property'=>'properties/123','revision'=>'core-fixture-020','ready'=>true];
$client=Api::register_consumer('fixture-ga4-consumer','1.0.0',Api::CONTRACT,static fn()=>$cfg);verifyLab('38 register opaque client',!is_wp_error($client));
$grant=static function(bool $enabled){return wp_get_ability('google/configure-consumer')->execute(['contract'=>Api::CONTRACT,'consumer_id'=>'fixture-ga4-consumer','property'=>'properties/123','enabled'=>$enabled,'expected_revision'=>Settings::revision()]);};
$r=$grant(true);verifyLab('38 grant through registered ability',!is_wp_error($r)&&$r['success'],$r);
$raw=['dimensionHeaders'=>[['name'=>'date'],['name'=>'pagePath']],'metricHeaders'=>[['name'=>'screenPageViews','type'=>'TYPE_INTEGER']],'rowCount'=>1,'rows'=>[['dimensionValues'=>[['value'=>'20260901'],['value'=>'/synthetic-020-no-archive']],'metricValues'=>[['value'=>'12']]]],'metadata'=>['timeZone'=>'America/Sao_Paulo','currencyCode'=>'BRL','dataLossFromOtherRow'=>true,'samplingMetadatas'=>[['samplesReadCount'=>'5','samplingSpaceSize'=>'10']]],'propertyQuota'=>['tokensPerDay'=>['consumed'=>2,'remaining'=>1000],'tokensPerHour'=>['consumed'=>2,'remaining'=>100]]];
$calls=[];$mode='ok';$fixture=static function($pre,$args,$url)use(&$calls,&$mode,$raw){
 if(!str_contains($url,'googleapis.com'))return $pre;$calls[]=['url'=>$url,'body'=>(is_array($args['body']??null)?$args['body']:json_decode($args['body']??'{}',true))];
 $body=str_contains($url,'/token')?['access_token'=>'synthetic-token','expires_in'=>3600]:$raw;$code=200;
 if($mode==='429'&&str_ends_with($url,':runReport')){$body=['error'=>['code'=>429,'status'=>'RESOURCE_EXHAUSTED','message'=>'quota']];$code=429;}
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,10,3);
$input=['contract_version'=>'1.0.0','property'=>'properties/123','consumer_revision'=>$cfg['revision'],'start_date'=>'2026-09-01','end_date'=>'2026-09-30','dimensions'=>['date','pagePath'],'metrics'=>['screenPageViews'],'run_id'=>'native020','trigger'=>'cli','budget_ms'=>20000];
wp_set_current_user(0);$r=$client->query($input);verifyLab('38 service query works without current user',$r['success'],$r);verifyLab('38 quality and quota preserved',$r['metadata']===$raw['metadata']&&$r['quota']['property_quota']['tokensPerHour']['remaining']===100&&$r['quality']['finalization_guaranteed']===false);
verifyLab('38 no current user impersonation',get_current_user_id()===0);wp_set_current_user(1);
$direct=wp_get_ability('ga/run-report')->execute(['property_id'=>'123','date_ranges'=>[['start_date'=>'2026-09-01','end_date'=>'2026-09-30']],'dimensions'=>['date','pagePath'],'metrics'=>['screenPageViews'],'format'=>'raw','return_property_quota'=>true]);
verifyLab('38 synthetic same rows as ga/run-report',!is_wp_error($direct)&&$direct['success']&&$direct['raw']['rows']===$r['rows'],$direct);
$events=array_values(array_filter(Audit::recent(30),static fn($e)=>$e['action']==='plugin:ga4.report.end'));verifyLab('38 actor in real audit',$events&&$events[0]['actor']['type']==='plugin'&&$events[0]['actor']['id']==='fixture-ga4-consumer');
global $wpdb;$stored=$wpdb->get_results("SELECT option_value FROM $wpdb->options WHERE option_name LIKE 'f3_mcp_google_%'",ARRAY_A);verifyLab('38 no report rows in options',!str_contains(serialize($stored),'/synthetic-020-no-archive'));verifyLab('38 no report rows in audit',!str_contains(serialize(Audit::recent(30)),'/synthetic-020-no-archive'));
$r=$grant(false);verifyLab('38 revoke through ability',!is_wp_error($r)&&$r['success']);$before=count($calls);wp_set_current_user(0);$r=$client->query($input);verifyLab('38 revoked query denied and audited',!$r['success']&&$r['error_code']==='f3_google_consumer_unauthorized'&&$r['audit_success']&&count($calls)===$before);wp_set_current_user(1);$grant(true);
$mode='429';$before=count($calls);$r=$client->query($input);verifyLab('38 429 no retry and cooldown',!$r['success']&&count($calls)===$before+1&&$r['retry_after_ms']>=3595000&&$r['next_eligible_at']>=time()+3595,$r);$before=count($calls);$r=$client->query($input);verifyLab('38 property cooldown stops HTTP',!$r['success']&&$r['error_code']==='f3_google_ga4_quota'&&count($calls)===$before);
remove_filter('pre_http_request',$fixture,10);$grant(false);
finishLab('requests020',['supplier'=>'synthetic','consumer'=>'fixture-ga4-consumer; not the Core archive','audit_rows_before_maintenance'=>count($auditBefore),'http_calls'=>count($calls)]);
