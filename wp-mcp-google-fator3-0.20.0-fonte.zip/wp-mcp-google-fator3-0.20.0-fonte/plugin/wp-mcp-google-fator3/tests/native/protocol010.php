<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
$credential=rpc_identityLab();$auth=$credential['auth'];Fator3\McpGoogle\Options::set(Fator3\McpGoogle\Options::ENABLED,true);
$fixture=WPMU_PLUGIN_DIR.'/release010-boundary.php';
file_put_contents($fixture, <<<'FIXTURE'
<?php
add_action('wp_abilities_api_init',static function(){
 Fator3\McpGoogle\Ability::register('google/release010-boundary','any',['label'=>'Synthetic boundary','description'=>'Synthetic transport redaction fixture only in owned lab.','callback'=>static fn()=>['success'=>false,'error_code'=>'fixture_failed','message'=>'Synthetic failure','execution_success'=>true,'result_status'=>'failed','checks_passed'=>false,'all_checks_passed'=>false,'passed'=>0,'credential'=>['configured'=>true,'identity'=>'fixture@example.invalid','nested'=>['refresh_token'=>'synthetic-secret']]]]);
 Fator3\McpGoogle\Ability::register('google/release010-conflict','any',['label'=>'Synthetic conflict','description'=>'Synthetic nullable result fixture only in owned lab.','callback'=>static fn()=>['success'=>false,'error_code'=>'revision_conflict','message'=>'Synthetic conflict','data'=>null]]);
},100);
FIXTURE
);
try{
 $public=rpcLab('google/release010-boundary');$conflict=rpcLab('google/release010-conflict');
 verifyLab('G91-03 boundary fixture actually executed',array_key_exists('passed',$public)&&($conflict['error_code']??'')!=='ability_not_found',$public);
 verifyLab('G91-03 MCP still removes nested secret fixture',!str_contains(json_encode($public),'synthetic-secret'));
 $boundary=['mcp_version'=>F3_MCP_FILES_VERSION,'domain'=>['checks_passed'=>false,'all_checks_passed'=>false,'passed'=>0,'credential_type'=>'array'],'http_types'=>array_map('gettype',array_intersect_key($public,array_flip(['checks_passed','all_checks_passed','passed','credential']))),'conflict_observed'=>['success'=>$conflict['success']??null,'error_code'=>$conflict['error_code']??null],'classification'=>'observed companion behavior; no Google compensation'];
}finally{unlink($fixture);}
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);finishLab('protocol010',['observation'=>$boundary]);
