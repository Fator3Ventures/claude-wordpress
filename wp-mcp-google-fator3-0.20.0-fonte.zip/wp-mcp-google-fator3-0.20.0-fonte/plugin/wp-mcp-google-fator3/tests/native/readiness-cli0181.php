<?php
/** Exercise the shipped WP-CLI adapter in a separate process, including its authorization boundary. */
require __DIR__.'/common.php';
use Fator3\McpGoogle\Options;
Options::set(Options::ENABLED,true);
$before=google_config_digestLab();
function cli181(array $args): array {
    $command=array_merge([PHP_BINARY,'-c',php_ini_loaded_file(),getenv('F3_WP_CLI'),'--path='.ABSPATH,'--allow-root'], $args);
    $process=proc_open($command,[1=>['pipe','w'],2=>['pipe','w']],$pipes);
    if(!is_resource($process))throw new RuntimeException('CLI process unavailable');
    $stdout=stream_get_contents($pipes[1]);$stderr=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);
    return ['exit'=>proc_close($process),'stdout'=>$stdout,'stderr'=>$stderr];
}
$r=cli181(['mcp-google','readiness','--user=1','--format=json','--input={"hours_ahead":2}']);$data=json_decode($r['stdout'],true);
verifyLab('WP-CLI readiness returns the installed contract and version',$r['exit']===0&&!empty($data['success'])&&$data['contract']==='google-readiness/1.0.0'&&$data['plugin_version']===expectedLab('candidate')&&$data['hours_ahead']===2,$r);
$denied=cli181(['mcp-google','readiness']);verifyLab('WP-CLI readiness refuses an unspecified user',$denied['exit']!==0&&str_contains($denied['stderr'],'administrador autorizado'));
$invalid=cli181(['mcp-google','readiness','--user=1','--input={"hours_ahead":49}']);verifyLab('WP-CLI readiness enforces the ability input schema',$invalid['exit']!==0);
verifyLab('WP-CLI readiness preserves Google configuration',$before===google_config_digestLab());
$version=cli181(['--version']);
finishLab('readiness-cli0181',['cli_version'=>trim($version['stdout'])]);
