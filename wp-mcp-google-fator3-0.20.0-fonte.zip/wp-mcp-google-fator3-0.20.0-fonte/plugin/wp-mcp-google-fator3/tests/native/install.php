<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
verifyLab('A14 Google absent before actual MCP installation',!defined('F3_MCP_GOOGLE_VERSION')&&!is_dir(WP_PLUGIN_DIR.'/wp-mcp-google-fator3'));
$credential=rpc_identityLab();$auth=$credential['auth'];$zip=getenv('F3_CANDIDATE');
$r=rpcLab('plugins/upload-base64',['content_base64'=>base64_encode(file_get_contents($zip)),'expected_sha256'=>hash_file('sha256',$zip),'expected_slug'=>'wp-mcp-google-fator3','overwrite'=>false,'activate'=>true]);
if(!empty($r['pending'])&&!empty($r['package_operation_id']))$r=rpcLab('plugins/reconcile',['operation_id'=>$r['package_operation_id']]);
verifyLab('A14 exact candidate installed through authenticated HTTP',!empty($r['success'])&&($r['version']??'')===expectedLab('candidate'),$r);
// First new request occurs before any maintenance or manual activation.
$defaults=[];foreach(['f3_mcp_google_enabled','f3_mcp_google_ga_enabled','f3_mcp_google_ads_enabled','f3_mcp_google_auth_mode'] as $name){global $wpdb;$row=$wpdb->get_row($wpdb->prepare("SELECT option_value FROM $wpdb->options WHERE option_name=%s",$name),ARRAY_A);$defaults[$name]=$row['option_value']??null;}
verifyLab('combined installation persisted disabled Ads as an existing row',$defaults['f3_mcp_google_ads_enabled']==='0'||$defaults['f3_mcp_google_ads_enabled']==='',$defaults);
verifyLab('combined installation selected Service Account',$defaults['f3_mcp_google_auth_mode']==='service_account',$defaults);
$s=rpcLab('google/status');verifyLab('A14 fresh request observes newly installed current tables',($s['plugin_version']??$s['version']??'')===expectedLab('candidate')&&($s['storage']['ready']??false),$s);
verifyLab('first fresh request sees one Google executor event',($s['cron']['scheduling']['checks']['executor']['state']??'')==='present'&&($s['cron']['scheduling']['checks']['executor']['occurrences']??0)===1,$s['cron']??[]);
verifyLab('first fresh request does not claim remote credentials',($s['auth']['configured']??null)===false&&!isset($s['token_ok']));
$r=rpcLab('google/configuration-schema');verifyLab('A14 newly installed schema discovered without warmup',!empty($r['success'])&&($r['contract_version']??'')==='4.0.0',$r);
$r=rpcLab('google/maintenance');verifyLab('A13 newly installed maintenance executable',!empty($r['success'])&&($r['maintenance_contract_version']??'')==='2.0.0',$r);
// Preserve the alternative inactive upload + explicit activation, including identical ZIP.
$r=rpcLab('plugins/deactivate',['plugin'=>'wp-mcp-google-fator3/wp-mcp-google-fator3.php']);verifyLab('deactivate only lab Google',$r['success'],$r);
$r=rpcLab('plugins/upload-base64',['content_base64'=>base64_encode(file_get_contents($zip)),'expected_sha256'=>hash_file('sha256',$zip),'expected_slug'=>'wp-mcp-google-fator3','overwrite'=>true,'activate'=>false]);
verifyLab('identical ZIP retains inactive state',!empty($r['success'])&&empty($r['active'])&&empty($r['changed']),$r);
$r=rpcLab('plugins/activate',['plugin'=>'wp-mcp-google-fator3/wp-mcp-google-fator3.php']);verifyLab('explicit activation remains available',!empty($r['success']),$r);
$s=rpcLab('google/status');verifyLab('reactivation remains locally ready without duplicate executor',($s['storage']['ready']??false)&&($s['cron']['scheduling']['checks']['executor']['occurrences']??0)===1,$s);
$r=rpcLab('plugins/deactivate',['plugin'=>'wp-mcp-google-fator3/wp-mcp-google-fator3.php']);verifyLab('prepare present inactive fixture',$r['success']);
$r=rpcLab('plugins/upload-base64',['content_base64'=>base64_encode(file_get_contents($zip)),'expected_sha256'=>hash_file('sha256',$zip),'expected_slug'=>'wp-mcp-google-fator3','overwrite'=>true,'activate'=>true]);
if(!empty($r['pending'])&&!empty($r['package_operation_id']))$r=rpcLab('plugins/reconcile',['operation_id'=>$r['package_operation_id']]);
verifyLab('combined identical present inactive installation activates',!empty($r['success'])&&!empty($r['active']),$r);
$s=rpcLab('google/status');verifyLab('present inactive package initializes on fresh request',($s['storage']['ready']??false)&&($s['cron']['scheduling']['checks']['executor']['state']??'')==='present',$s);
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
finishLab('install',['observed_after_http'=>expectedLab('candidate'),'install_flow'=>'upload-base64 activate:true; first new request before maintenance']);
