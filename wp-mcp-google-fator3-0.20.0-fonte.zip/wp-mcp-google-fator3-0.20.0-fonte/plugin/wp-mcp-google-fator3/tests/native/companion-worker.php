<?php
require __DIR__.'/common.php';
if(($argv[1]??'')==='activate'){require_once ABSPATH.'wp-admin/includes/plugin.php';$r=activate_plugin('wp-mcp-google-fator3/wp-mcp-google-fator3.php');if(is_wp_error($r))throw new RuntimeException($r->get_error_code());}
$all=wp_get_abilities();
echo json_encode(['google'=>F3_MCP_GOOGLE_VERSION,'abilities'=>count(array_filter($all,static fn($a)=>$a->get_category()==='google')),'storage'=>Fator3\McpGoogle\Storage\State::status(),'admin'=>class_exists('Fator3\McpGoogle\Admin'),'mcp'=>defined('F3_MCP_FILES_VERSION')?F3_MCP_FILES_VERSION:null,'core'=>defined('F3BASE_PLUGIN_VERSAO')?F3BASE_PLUGIN_VERSAO:null,'bindings'=>Fator3\McpGoogle\CoreBinding::class]);
