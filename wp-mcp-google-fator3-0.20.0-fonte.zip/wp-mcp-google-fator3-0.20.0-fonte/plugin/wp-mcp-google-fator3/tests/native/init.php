<?php
function expectedLab(string $name): string {return json_decode(file_get_contents(getenv('F3_LAB_MANIFEST')),true)['inputs'][$name]['version'];}
$lab=getenv('F3_FIXTURE_ROOT');$owner=json_decode(file_get_contents($lab.'/.google-lab-owner.json'),true);
if(($owner['id']??'')!==getenv('F3_LAB_ID')||($owner['path']??'')!==realpath($lab))throw new RuntimeException('Owned laboratory required');
$_SERVER['HTTP_HOST']=parse_url(getenv('F3_LAB_URL'),PHP_URL_HOST).':'.parse_url(getenv('F3_LAB_URL'),PHP_URL_PORT);$_SERVER['SERVER_NAME']='127.0.0.1';
define('WP_INSTALLING',true);require $lab.'/wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
if(is_blog_installed())throw new RuntimeException('New isolated database required');
wp_install('Google release laboratory','google_lab_admin','lab@example.invalid',false,'',bin2hex(random_bytes(24)));
update_option('home',getenv('F3_LAB_URL'));update_option('siteurl',getenv('F3_LAB_URL'));wp_set_current_user(1);
$plugins=['wp-mcp-fator3/wp-mcp-fator3.php','base-site-core-fator3/base-site-core-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php'];
if(getenv('F3_LAB_ORDER')==='google-first')$plugins=array_reverse($plugins);
if(getenv('F3_LAB_ORDER')==='google-only')$plugins=[$plugins[2]];
if(getenv('F3_LAB_ORIGIN')==='mcp-install')array_pop($plugins);
if(getenv('F3_LAB_ORIGIN')==='upgrade'){
 $manifest=json_decode(file_get_contents(getenv('F3_LAB_MANIFEST')),true);
 foreach(['meta','linkedin'] as $name){$zip=new ZipArchive();$zip->open($manifest['inputs'][$name]['path']);$zip->extractTo(WP_PLUGIN_DIR);$zip->close();wp_clean_plugins_cache(false);$plugins[]='wp-mcp-'.$name.'-fator3/wp-mcp-'.$name.'-fator3.php';}
}
foreach($plugins as $p){$r=activate_plugin($p);if(is_wp_error($r))throw new RuntimeException($r->get_error_code());}
update_option('active_plugins',$plugins);
// Initialize only through the supported 0.9.0 baseline's own activation path.
if(getenv('F3_LAB_ORIGIN')==='upgrade'){
    if(F3_MCP_GOOGLE_VERSION!==expectedLab('baseline'))throw new RuntimeException('Wrong baseline installer');
    if(null!==Fator3\McpGoogle\Storage\State::guard())throw new RuntimeException('Baseline schema not initialized');
}
echo json_encode(['installed'=>true,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'google'=>defined('F3_MCP_GOOGLE_VERSION')?F3_MCP_GOOGLE_VERSION:null,'order'=>getenv('F3_LAB_ORDER')])."\n";
