<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{Options,Documentation,Delivery,Records,McpBridge};
use Fator3\McpGoogle\Automation\{Jobs,Results};
function rpcTool010(string $tool,array $arguments): array {
 global $auth;
 $response=wp_remote_post(rest_url('mcp/wp-mcp-fator3'),['timeout'=>75,'headers'=>['Authorization'=>$auth,'Content-Type'=>'application/json','Accept'=>'application/json','Mcp-Protocol-Version'=>'2026-07-28','Mcp-Method'=>'tools/call','Mcp-Name'=>$tool],'body'=>json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>'tools/call','params'=>['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>new stdClass()],'name'=>$tool,'arguments'=>$arguments]])]);
 if(is_wp_error($response))return ['success'=>false,'error_code'=>$response->get_error_code()];
 $body=json_decode(wp_remote_retrieve_body($response),true);$data=$body['result']['structuredContent']??$body;while(isset($data['data'])&&is_array($data['data']))$data=$data['data'];return $data;
}
$credential=rpc_identityLab();$auth=$credential['auth'];Options::set(Options::ENABLED,true);wp_get_abilities();
$network=0;add_filter('pre_http_request',static function($pre,$args,$url)use(&$network){if(!str_starts_with($url,getenv('F3_LAB_URL').'/'))++$network;return $pre;},5,3);
$schema=rpcTool010('wp-mcp-ultimate-get-ability-info',['ability_name'=>'google/documentation']);verifyLab('G91-06 documented route discoverable through MCP info',str_contains(json_encode($schema),'expected_revision')&&str_contains(json_encode($schema),'limit_bytes'));
$index=rpcLab('google/documentation');verifyLab('G91-06 HTTP index identifies installed version',!empty($index['success'])&&$index['plugin_version']===expectedLab('candidate'),$index);
$hashes=[];
foreach($index['documents'] as $doc){$offset=0;$content='';$pages=0;do{$part=rpcLab('google/documentation',['document'=>$doc['document'],'offset'=>$offset,'limit_bytes'=>65521,'expected_revision'=>$doc['revision']]);verifyLab('G91-06 document page '.$doc['document'].' '.$pages,!empty($part['success'])&&$part['revision']===$doc['revision']&&mb_check_encoding($part['content'],'UTF-8'),$part['error_code']??null);$content.=$part['content'];$offset=$part['next_offset'];++$pages;}while($offset!==null);verifyLab('G91-06 complete document hash '.$doc['document'],hash('sha256',$content)===$doc['revision']&&strlen($content)===$doc['bytes']);$hashes[$doc['document']]=['sha256'=>$doc['revision'],'pages'=>$pages,'bytes'=>strlen($content)];}
foreach(['../wp-config.php','https://example.invalid/','/etc/passwd'] as $id){$r=rpcLab('google/documentation',['document'=>$id]);verifyLab('G91-06 confines document ID '.$id,($r['error_code']??'')==='f3_google_document_missing',$r);}
$r=rpcLab('google/documentation',['document'=>'README.md','offset'=>1]);verifyLab('G91-06 continuation requires revision',($r['error_code']??'')==='f3_google_document_revision',$r);
$before=google_config_digestLab();Options::set(Options::ENABLED,false);$disabled=google_config_digestLab();$r=wp_get_ability('google/documentation')->execute([]);verifyLab('G91-06 local docs with closed Google channel',!is_wp_error($r)&&$r['success']&&$disabled===google_config_digestLab()&&$network===0);Options::set(Options::ENABLED,true);
$job=['id'=>'release010-pages','task'=>'query','status'=>'completed','user_id'=>1,'connection_id'=>'default','created_at'=>time(),'updated_at'=>time(),'parameters'=>[],'result'=>['columns'=>['country','sessions'],'collection'=>['complete'=>true]]];
foreach(Results::PATHS as $field=>$path)Results::assign($job,$field,array_map(static fn($i)=>['id'=>$i,'value'=>str_repeat('é🙂"\\',600)],range(0,89)));
$expected=$job;foreach(Results::externalize($job) as $id=>$record){$r=Records::put('result',$id,$record);verifyLab('G91-01 persist '.$id,!empty($r['success']),$r);}Records::put('job',$job['id'],$job);
$wire=[];
foreach(Results::PATHS as $field=>$path){$offset=0;$all=[];$pages=0;do{$r=rpcLab('google/get-job',['job_id'=>$job['id'],'section'=>$field,'offset'=>$offset,'limit'=>100]);verifyLab('G91-01 HTTP bounded page '.$field.' '.$pages,!empty($r['success'])&&Delivery::bytes($r)<=Delivery::BUDGET,$r['error_code']??null);$view=$r['job'];$values=Results::inline($view,$field);$all=array_merge($all,$values);$next=$view['delivery']['next_offset'];verifyLab('G91-01 page advances by actual count '.$field.' '.$pages,$next===null||$next===$offset+count($values));$wire[]=$GLOBALS['f3_lab_wire']??[];$offset=$next;++$pages;}while($offset!==null);verifyLab('G91-01 no loss '.$field,$all===Results::inline($expected,$field));}
$r=rpcTool010('google-mcp-read',['ability'=>'google/get-job','parameters'=>['job_id'=>$job['id'],'section'=>'rows','limit'=>100]]);verifyLab('G91-01 dedicated executor bounded',!empty($r['success'])&&Delivery::bytes($r)<=Delivery::BUDGET,$r['error_code']??null);
$r=rpcTool010('google-mcp-write',['ability'=>'google/get-job','parameters'=>['job_id'=>$job['id']]]);verifyLab('G91-03 write executor rejects read target',($r['error_code']??'')==='f3_google_mcp_mode',$r);
$subscriber=wp_create_user('delivery_subscriber',bin2hex(random_bytes(16)),'delivery@example.invalid');wp_set_current_user($subscriber);add_filter('f3_mcp_google_capability',static fn()=>'read');verifyLab('G91-02 read capability cannot downgrade private reads',!Options::authorized()&&!Fator3\McpGoogle\Gate::permission('any'));$r=Documentation::read([]);verifyLab('G91-06 static help has explicit admin gate',!$r['success']);wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/user.php';remove_all_filters('f3_mcp_google_capability');wp_delete_user($subscriber);
$manifest=json_decode(file_get_contents(getenv('F3_LAB_MANIFEST')),true);$social=[];
require_once ABSPATH.'wp-admin/includes/plugin.php';
foreach(['meta','linkedin'] as $name){$slug='wp-mcp-'.$name.'-fator3';$path=$manifest['inputs'][$name]['path'];$zip=new ZipArchive();$zip->open($path);$zip->extractTo(WP_PLUGIN_DIR);$zip->close();wp_clean_plugins_cache(false);$r=activate_plugin($slug.'/'.$slug.'.php');verifyLab('G91-04 activate real '.$slug,!is_wp_error($r),is_wp_error($r)?$r->get_error_code():null);$info=get_plugin_data(WP_PLUGIN_DIR.'/'.$slug.'/'.$slug.'.php');$social[$slug]=['version'=>$info['Version'],'sha256'=>hash_file('sha256',$path)];}
// Real packages own their namespaces; sentinels make unintended Google deletion observable.
foreach(['meta','linkedin'] as $name){update_option('f3_'.$name.'_release010_sentinel','preserve');wp_schedule_single_event(time()+7200,'f3_'.$name.'_release010_sentinel');}
function socialState010(): string {global $wpdb;$options=$wpdb->get_results("SELECT option_name,option_value FROM $wpdb->options WHERE option_name LIKE 'f3_meta_%' OR option_name LIKE 'f3_linkedin_%' ORDER BY option_name",ARRAY_A);$tables=$wpdb->get_col('SHOW TABLES');$counts=[];foreach($tables as $table)if(str_contains($table,'f3_meta')||str_contains($table,'f3_linkedin'))$counts[$table]=$wpdb->get_results("SELECT * FROM `$table` ORDER BY 1",ARRAY_A);$cron=[];foreach(_get_cron_array() as $time=>$hooks)foreach($hooks as $hook=>$events)if(str_starts_with($hook,'f3_meta_')||str_starts_with($hook,'f3_linkedin_'))$cron[$time][$hook]=$events;return hash('sha256',serialize([$options,$counts,$cron]));}
Fator3\Meta\Store::put('audit','release010-sentinel',['synthetic'=>true,'marker'=>'preserve']);Fator3\LinkedIn\Store::put('audit','release010-sentinel',['synthetic'=>true,'marker'=>'preserve']);
$socialBefore=socialState010();$r=rpcLab('google/maintenance');verifyLab('G91-04 Google maintenance preserves social options tables cron',!empty($r['success'])&&socialState010()===$socialBefore,$r['error_code']??null);Options::set(Options::ENABLED,false);verifyLab('G91-04 Google pause preserves social state',socialState010()===$socialBefore);Options::set(Options::ENABLED,true);
deactivate_plugins('wp-mcp-google-fator3/wp-mcp-google-fator3.php');verifyLab('G91-04 Google deactivation preserves social state',socialState010()===$socialBefore);
$independent=rpcLab('meta/status');verifyLab('G91-04 social status works without active Google',($independent['provider']??'')==='wp-mcp-meta-fator3'&&!empty($independent['storage_ready']),$independent);
$socialAfterRead=socialState010();$active=activate_plugin('wp-mcp-google-fator3/wp-mcp-google-fator3.php');verifyLab('G91-04 Google reactivation preserves social state',!is_wp_error($active)&&socialState010()===$socialAfterRead);
foreach(['meta/status','linkedin/status'] as $target){$r=rpcTool010('google-mcp-read',['ability'=>$target]);verifyLab('G91-04 Google refuses social target '.$target,empty($r['success'])&&($r['error_code']??'')==='f3_google_mcp_ability',$r);}
foreach(['meta','linkedin'] as $name){delete_option('f3_'.$name.'_release010_sentinel');wp_clear_scheduled_hook('f3_'.$name.'_release010_sentinel');}
Fator3\Meta\Store::remove('audit','release010-sentinel',1);Fator3\LinkedIn\Store::remove('audit','release010-sentinel',1);
Records::remove('job',$job['id']);foreach(Results::externalize($expected) as $id=>$record)Records::remove('result',$id);
$zone=get_option('timezone_string');update_option('timezone_string','America/Sao_Paulo');verifyLab('G91-02 diagnostic instant follows WordPress timezone',str_contains(Fator3\McpGoogle\Admin\DiagnosticState::instant('2026-10-16T00:00:00Z'),'15/10/2026 21:00:00'));update_option('timezone_string',$zone);
$fixture=WPMU_PLUGIN_DIR.'/release010-boundary.php';
file_put_contents($fixture, <<<'FIXTURE'
<?php
add_action('wp_abilities_api_init',static function(){
 Fator3\McpGoogle\Ability::register('google/release010-boundary','any',['label'=>'Synthetic boundary','description'=>'Synthetic transport redaction fixture only in owned lab.','callback'=>static fn()=>['success'=>false,'error_code'=>'fixture_failed','message'=>'Synthetic failure','execution_success'=>true,'result_status'=>'failed','checks_passed'=>false,'all_checks_passed'=>false,'passed'=>0,'credential'=>['configured'=>true,'identity'=>'fixture@example.invalid','nested'=>['refresh_token'=>'synthetic-secret']]]]);
 Fator3\McpGoogle\Ability::register('google/release010-conflict','any',['label'=>'Synthetic conflict','description'=>'Synthetic nullable result fixture only in owned lab.','callback'=>static fn()=>['success'=>false,'error_code'=>'revision_conflict','message'=>'Synthetic conflict','data'=>null]]);
},100);
FIXTURE
);
try{
 $public=rpcLab('google/release010-boundary');$conflict=rpcLab('google/release010-conflict');
 verifyLab('G91-03 boundary fixture actually executed',array_key_exists('passed',$public)&&($conflict['error_code']??'')!=='ability_not_found',$public);
 verifyLab('G91-03 MCP still removes nested secret fixture',!str_contains(json_encode($public),'synthetic-secret'));
 $boundary=['mcp_version'=>F3_MCP_FILES_VERSION,'domain'=>['checks_passed'=>false,'all_checks_passed'=>false,'passed'=>0,'credential_type'=>'array'],'http_types'=>array_map('gettype',array_intersect_key($public,array_flip(['checks_passed','all_checks_passed','passed','credential']))),'conflict_observed'=>['success'=>$conflict['success']??null,'error_code'=>$conflict['error_code']??null],'classification'=>'observed companion behavior; no Google compensation'];
}finally{unlink($fixture);}
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
finishLab('release010',['boundary_observation'=>$boundary,'document_hashes'=>$hashes,'delivery_wire'=>$wire,'social_packages'=>$social,'external_calls'=>$network,'validation_scope'=>'native WordPress, synthetic Google data, actual companion packages; no vendor homologation']);
