<?php
/** 0.18.0 Melhoria M2: google/readiness-status — one local call with verdict, checks and actions. */
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{ConversionDelivery as D,Options as O,Connections as C,Policy,Settings,Readiness};
O::set(D::CONFIG,D::defaults());wp_get_abilities();update_option('f3base_ga4_measurement_id','G-READY018');
// Start without a readable credential, whatever earlier suites configured in this lab.
O::batch_verified([O::AUTH_MODE=>'service_account'],[O::SA_JSON=>'']);
$external=0;$scenario='ok';$secret='synthetic-mp-ready018';
$counter=static function($pre,$args,$url)use(&$external){if(!str_starts_with($url,getenv('F3_LAB_URL').'/'))++$external;return $pre;};add_filter('pre_http_request',$counter,0,3);
$fixture=static function($pre,$args,$url)use(&$scenario,$secret){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;$body=[];$code=200;$c=O::get(D::CONFIG);
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access-ready018','expires_in'=>3600];
 elseif(str_contains($url,'measurementProtocolSecrets'))$body=['measurementProtocolSecrets'=>[['secretValue'=>$secret]]];
 elseif(str_contains($url,'analyticsadmin.googleapis.com'))$body=['name'=>$c['stream'],'webStreamData'=>['measurementId'=>'G-READY018']];
 elseif(str_contains($url,'/debug/mp/collect'))$body=['validationMessages'=>[]];
 elseif(str_contains($url,'googleAds:search'))$body=['results'=>[['conversionAction'=>['resourceName'=>$c['conversion_action'],'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>0,'defaultCurrencyCode'=>'BRL']]]]];
 elseif(str_contains($url,'/events:ingest')){if($scenario==='not-found'){$code=400;$body=['error'=>['code'=>400,'status'=>'INVALID_ARGUMENT','message'=>'Invalid request.','details'=>[['@type'=>'type.googleapis.com/google.rpc.BadRequest','fieldViolations'=>[['field'=>'events.events[0].destination_references','reason'=>'NOT_FOUND','description'=>'Resource not found.']]]]]];}}
 else return $pre;
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>wp_json_encode($body)];
};
function readiness018(array $input=[]): array {$r=wp_get_ability('google/readiness-status')->execute($input);if(is_wp_error($r))throw new RuntimeException($r->get_error_code());return $r;}
function check018(array $r,string $id): array {foreach($r['checks'] as $c)if($c['id']===$id)return $c;throw new RuntimeException('missing check '.$id);}
// Fresh connection: no credential.
$before=google_config_digestLab();$n=$external;$r=readiness018();
verifyLab('Fresh connection is blocked by the missing credential',$r['success']&&$r['state']==='blocked'&&check018($r,'credential')['state']==='blocked'&&$r['contract']===Readiness::CONTRACT,$r['checks']);
verifyLab('Every check is reported in a fixed order',array_column($r['checks'],'id')===['credential','storage','recovery','executor','conversion_ga4','conversion_google_ads','incidents','core']);
verifyLab('Unconfigured destinations do not block',check018($r,'conversion_ga4')['state']==='not_configured'&&check018($r,'conversion_google_ads')['state']==='not_configured');
verifyLab('Readiness is local: no provider call and no configuration change',$external===$n&&$before===google_config_digestLab()&&$r['google_checks_performed']===false);
verifyLab('Actions start with the blocking one',($r['actions'][0]??'')===check018($r,'credential')['action']);
verifyLab('Ability metadata declares a local read',($m=wp_get_ability('google/readiness-status')->get_meta())['fator3']['mode']==='read'&&$m['fator3']['remote_effect']==='none'&&$m['fator3']['local_effect']==='none'&&$m['annotations']['readonly']===true);
foreach([0,49] as $bad){$e=wp_get_ability('google/readiness-status')->execute(['hours_ahead'=>$bad]);verifyLab('Input schema refuses hours_ahead '.var_export($bad,true),is_wp_error($e));}
$subscriber=wp_create_user('ready_subscriber018',bin2hex(random_bytes(16)),'ready018@example.invalid');wp_set_current_user($subscriber);
$denied=wp_get_ability('google/readiness-status')->execute([]);verifyLab('Subscriber is refused',is_wp_error($denied)||empty($denied['success']));
$direct=Readiness::read([]);verifyLab('Direct call without administrator is refused',empty($direct['success']));wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($subscriber);
// Credentials and a verified GA4 destination.
add_filter('pre_http_request',$fixture,1,3);
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-ready018',O::OAUTH_REFRESH_TOKEN=>'synthetic-ready018',O::ADS_DEVELOPER_TOKEN=>'synthetic-dev-ready018']);
$r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'stream'=>'properties/7/dataStreams/70'],'mp_secret'=>$secret]);verifyLab('GA4 destination configured',!empty($r['success']),$r);
verifyLab('GA4 verified',!empty(D::verify(['expected_revision'=>D::revision(),'target'=>'ga4'])['success']));
$r=readiness018();$ga=check018($r,'conversion_ga4');
verifyLab('Credential and GA4 delivery are ok',check018($r,'credential')['state']==='ok'&&$ga['state']==='ok'&&$ga['detail']['ready']===true&&$ga['detail']['expires_in_seconds']>23*3600,$ga);
verifyLab('Ads without destination stays not_configured',check018($r,'conversion_google_ads')['code']==='destination_not_selected');
// Executor observation.
$e=check018($r,'executor');
if($e['detail']['last_pass_at']===null)verifyLab('Executor without any pass asks for attention',$e['state']==='attention'&&$e['code']==='executor_not_observed',$e);
else verifyLab('Executor with a recent pass is ok',$e['state']==='ok'||$e['code']==='executor_stalled',$e);
$pass=wp_get_ability('google/executar-vencidos')->execute([]);verifyLab('Executor pass runs locally',!is_wp_error($pass),$pass);
$r=readiness018();verifyLab('Executor ok after a recorded pass',check018($r,'executor')['state']==='ok',check018($r,'executor'));
// Renewal timing.
$c=O::get(D::CONFIG);$c['renewal']['ga4']['next_attempt']=time()-7200;O::set(D::CONFIG,$c);
$r=readiness018();verifyLab('Late renewal is reported as overdue',check018($r,'conversion_ga4')['code']==='renewal_overdue'&&$r['state']!=='ready',check018($r,'conversion_ga4'));
$c=O::get(D::CONFIG);$c['verified']['ga4']['expires']=time()+7200;$c['renewal']['ga4']['next_attempt']=null;O::set(D::CONFIG,$c);
$r=readiness018(['hours_ahead'=>6]);verifyLab('Proof expiring without renewal inside the window',check018($r,'conversion_ga4')['code']==='renewal_not_scheduled_before_expiry',check018($r,'conversion_ga4'));
$r=readiness018(['hours_ahead'=>1]);verifyLab('Window narrower than expiry keeps it ok',check018($r,'conversion_ga4')['state']==='ok',check018($r,'conversion_ga4'));
$c=O::get(D::CONFIG);$c['renewal']['ga4']=['last_at'=>time()-60,'result'=>'failed','code'=>'mp_secret_unverified','failures'=>1,'next_attempt'=>time()+300];$c['verified']['ga4']['expires']=time()+20*3600;O::set(D::CONFIG,$c);
$r=readiness018();verifyLab('Failing renewal with a valid proof asks for attention',check018($r,'conversion_ga4')['code']==='renewal_failing',check018($r,'conversion_ga4'));
// Ads first validation not found → pending, with incident.
$r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789']]);verifyLab('Ads destination configured',!empty($r['success']),$r);
$scenario='not-found';$v=D::verify(['expected_revision'=>D::revision(),'target'=>'google_ads']);verifyLab('Ads first validation fails with NOT_FOUND',empty($v['success'])&&!empty($v['retry_scheduled']),$v);$scenario='ok';
$r=readiness018();$ads=check018($r,'conversion_google_ads');
verifyLab('Pending first validation is attention, not blocked',$ads['state']==='attention'&&$ads['code']==='verification_pending'&&$ads['detail']['verification_pending']===true,$ads);
$inc=check018($r,'incidents');verifyLab('Open verification incident is surfaced',$inc['state']==='attention'&&$inc['detail']['open']>=1&&in_array('conversion_verification',array_column($inc['detail']['items'],'event'),true),$inc);
// Changing the GA4 stream invalidates the proof: blocked with the verification action first.
$r=D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'stream'=>'properties/7/dataStreams/71']]);verifyLab('GA4 stream changed',!empty($r['success']),$r);
$r=readiness018();$ga=check018($r,'conversion_ga4');
verifyLab('Configured destination without proof blocks delivery',$r['state']==='blocked'&&$ga['state']==='blocked'&&$ga['code']==='verification_required'&&$r['actions'][0]===$ga['action'],[$r['state'],$ga]);
// Through MCP HTTP, including a read-only profile.
$credential=rpc_identityLab();$auth=$credential['auth'];$wire=rpcLab('google/readiness-status');
verifyLab('MCP maintenance profile reads the same verdict',!empty($wire['success'])&&$wire['state']==='blocked'&&array_column($wire['checks'],'id')===array_column($r['checks'],'id'),$wire['error_code']??null);
$read=rpc_identityLab('read');$wire=rpcLab('google/readiness-status',[],$read['auth']);
verifyLab('MCP read profile is allowed for this local read',!empty($wire['success']),$wire['error_code']??null);
foreach([$credential,$read] as $cr)WP_Application_Passwords::delete_application_password(1,$cr['uuid']);
// Panel card.
ob_start();D::screen();$html=ob_get_clean();verifyLab('Conversions screen shows the readiness card',str_contains($html,'id="f3-readiness"')&&str_contains($html,'data-state="blocked"')&&str_contains($html,'Prontidão operacional'));
remove_filter('pre_http_request',$fixture,1);remove_filter('pre_http_request',$counter,0);O::set(D::CONFIG,D::defaults());
finishLab('readiness018',['provider_calls'=>'synthetic only for configuration and verification; readiness itself made none']);
