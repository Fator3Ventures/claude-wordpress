<?php
/** Actual authenticated MCP HTTP, with protocol schema and profile enforcement. */
function rpcLab($ability,$params=[],$authorization=null) {
    global $auth;
    $r=wp_remote_post(rest_url('mcp/wp-mcp-fator3'),['timeout'=>75,'headers'=>['Authorization'=>$authorization??$auth,'Content-Type'=>'application/json','Accept'=>'application/json','Mcp-Protocol-Version'=>'2026-07-28','Mcp-Method'=>'tools/call','Mcp-Name'=>'wp-mcp-ultimate-execute-ability'],'body'=>json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>'tools/call','params'=>['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>new stdClass()],'name'=>'wp-mcp-ultimate-execute-ability','arguments'=>['ability_name'=>$ability,'parameters'=>$params?:new stdClass()]]])]);
    if(is_wp_error($r))return ['success'=>false,'error_code'=>$r->get_error_code()];
    $raw=wp_remote_retrieve_body($r);$body=json_decode($raw,true);$GLOBALS['f3_lab_wire']=['body_bytes'=>strlen($raw),'structured_bytes'=>strlen(json_encode($body['result']['structuredContent']??null)),'http_status'=>wp_remote_retrieve_response_code($r)];$data=$body['result']['structuredContent']??$body;
    while(isset($data['data'])&&is_array($data['data']))$data=$data['data'];
    return is_array($data)?$data:['success'=>false,'http_status'=>wp_remote_retrieve_response_code($r)];
}
function rpc_identityLab(string $profile='maintenance',array $abilities=[]): array {
    $credential=WP_Application_Passwords::create_new_application_password(1,['name'=>'Google Lab disposable laboratory']);
    if(is_wp_error($credential))throw new RuntimeException($credential->get_error_code());
    $key='app:'.$credential[1]['uuid'];
    Fator3\McpFiles\Persistence::put('connections',$key,['connection_id'=>$key,'user_id'=>1,'profile'=>$profile,'abilities'=>$abilities,'status'=>'active','policy_version'=>1,'expires'=>0]);
    return ['auth'=>'Basic '.base64_encode(wp_get_current_user()->user_login.':'.$credential[0]),'id'=>$key,'uuid'=>$credential[1]['uuid']];
}
