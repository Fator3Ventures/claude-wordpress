<?php
require __DIR__.'/common.php';
$out=[];
foreach(wp_get_abilities() as $a){$m=$a->get_meta();if(($m['fator3']['provider']??'')!=='wp-mcp-google-fator3')continue;$out[$a->get_name()]=['input_schema'=>$a->get_input_schema(),'output_schema'=>$a->get_output_schema(),'meta'=>$m];}
ksort($out);file_put_contents(getenv('F3_EVIDENCE_DIR').'/native-contracts.json',json_encode(['version'=>F3_MCP_GOOGLE_VERSION,'mcp'=>F3_MCP_FILES_VERSION,'abilities'=>$out],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
verifyLab('Contract capture completed',count($out)>280);finishLab('capture-contracts019');
