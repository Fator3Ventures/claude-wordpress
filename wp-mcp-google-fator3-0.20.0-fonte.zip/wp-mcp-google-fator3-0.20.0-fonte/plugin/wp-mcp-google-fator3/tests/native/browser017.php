<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Records,Admin};
$token=WP_Session_Tokens::get_instance(1)->create(time()+3600);
$file=getenv('F3_FIXTURE_ROOT').'/browser-session.json';$manifest=json_decode(file_get_contents(getenv('F3_LAB_MANIFEST')),true);
file_put_contents($file,json_encode(['url'=>getenv('F3_LAB_URL'),'page'=>Admin::url('','connection'),'browser'=>$manifest['inputs']['browser']['path'],'cookies'=>[['name'=>AUTH_COOKIE,'value'=>wp_generate_auth_cookie(1,time()+3600,'auth',$token),'url'=>getenv('F3_LAB_URL')],['name'=>LOGGED_IN_COOKIE,'value'=>wp_generate_auth_cookie(1,time()+3600,'logged_in',$token),'url'=>getenv('F3_LAB_URL')]]]));chmod($file,0600);
try {passthru('node '.escapeshellarg(__DIR__.'/browser017.cjs').' '.escapeshellarg($file).' '.escapeshellarg(getenv('F3_EVIDENCE_DIR')),$code);verifyLab('Chromium authenticated WordPress UI checks passed',$code===0);}
finally{unlink($file);WP_Session_Tokens::get_instance(1)->destroy($token);}
finishLab('browser017');
