<?php
require __DIR__.'/common.php';
use Fator3\McpGoogle\{Options,Settings,Connections,Configuration};
$baseline=json_decode(file_get_contents(dirname(__DIR__).'/fixtures/contracts0181.json'),true);
wp_get_abilities();
foreach($baseline['abilities'] as $name=>$old){
 $ability=wp_get_ability($name);verifyLab('Existing ability and schemas unchanged '.$name,$ability!==null&&$ability->get_input_schema()===$old['input_schema']&&$ability->get_output_schema()===$old['output_schema']);
 $actual=$ability->get_meta();foreach(['mode','remote_effect','local_effect'] as $field)verifyLab('Existing effect '.$name.' '.$field,($actual['fator3'][$field]??null)===($old['meta']['fator3'][$field]??null));
}
foreach(['rename-connection','plan-identity-change','switch-identity'] as $name){$a=wp_get_ability('google/'.$name);verifyLab('New operation '.$name,$a!==null&&$a->get_meta()['fator3']['mode']==='write'&&$a->get_meta()['fator3']['version']===F3_MCP_GOOGLE_VERSION);}
$all=array_filter(wp_get_abilities(),static fn($a)=>($a->get_meta()['fator3']['provider']??'')==='wp-mcp-google-fator3');verifyLab('Exactly 290 public Google identities',count($all)===290);
$schema=Configuration::read();verifyLab('Configuration keeps public contract 4 with new protected receipt option',$schema['contract_version']==='4.0.0'&&isset($schema['options']['credential_receipts'])&&in_array('f3_mcp_google_credential_receipts',Connections::protected_names(),true));
finishLab('contracts019',['baseline'=>'0.18.1','new_abilities'=>3,'existing_abilities'=>count($baseline['abilities'])]);
