<?php
require __DIR__.'/common.php';
function companion_probeLab(string $mode=""): array {global $lab;$p=proc_open([PHP_BINARY,'-c',$lab.'/php.ini',__DIR__.'/companion-worker.php',$mode],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);$exit=proc_close($p);if($exit!==0)throw new RuntimeException($err.' '.$out);return json_decode($out,true)??[];}
$active=get_option('active_plugins');$paths=['mcp'=>WP_PLUGIN_DIR.'/wp-mcp-fator3/wp-mcp-fator3.php','core'=>WP_PLUGIN_DIR.'/base-site-core-fator3/base-site-core-fator3.php'];$bytes=[];foreach($paths as $key=>$path)$bytes[$key]=file_get_contents($path);
try {
 foreach(['0.0.1','999.0.0','9.9.9-beta.1'] as $version){
  foreach($paths as $key=>$path)file_put_contents($path,str_replace($key==='mcp'?expectedLab('mcp'):expectedLab('core'),$version,$bytes[$key]));
  $r=companion_probeLab();verifyLab('companion numeric metadata does not gate Google '.$version,($r['google']??'')===expectedLab('candidate')&&($r['abilities']??0)===282&&!empty($r['storage']['ready'])&&$r['mcp']===$version&&$r['core']===$version,$r);
 }
} finally {foreach($paths as $key=>$path)file_put_contents($path,$bytes[$key]);}
try {
 update_option('active_plugins',['wp-mcp-google-fator3/wp-mcp-google-fator3.php']);$r=companion_probeLab();verifyLab('inactive companions leave Google administrable',($r['abilities']??0)===282&&!empty($r['admin'])&&$r['mcp']===null&&$r['core']===null,$r);
 foreach($paths as $key=>$path)rename(dirname($path),dirname($path).'.fixture-off');
 update_option('active_plugins',[]);$r=companion_probeLab('activate');verifyLab('absent companion files do not gate Google',($r['abilities']??0)===282&&!empty($r['storage']['ready']),$r);
} finally {
 foreach($paths as $key=>$path)if(is_dir(dirname($path).'.fixture-off'))rename(dirname($path).'.fixture-off',dirname($path));
 update_option('active_plugins',$active);
}
foreach($paths as $key=>$path)verifyLab('companion original bytes restored '.$key,file_get_contents($path)===$bytes[$key]);
finishLab('companions',['variants'=>'Only disposable lab headers/constants changed; original sources unchanged']);
