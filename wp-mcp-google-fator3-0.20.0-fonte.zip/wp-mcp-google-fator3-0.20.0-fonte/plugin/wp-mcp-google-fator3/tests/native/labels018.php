<?php
/**
 * 0.18.0 Melhoria M1: no ability label or description in English; 286 public identities, schemas and
 * effects of 0.17.0 preserved byte-for-byte; one additive ability (google/readiness-status).
 */
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{LabelsPT,Policy,Admin};
/** English detector calibrated on the 0.17.0 catalog: flags exactly its 106 Discovery-generated gtm/* descriptions. */
function englishLab018(string $text): bool {
    $text=preg_replace(['/`[^`]*`/u','~https?://\S+~u'],'',$text);
    preg_match_all("/\\p{L}[\\p{L}\\p{N}_'-]*/u",$text,$m);
    $words=array_values(array_filter($m[0],static fn($w)=>!preg_match('/[A-Z].*[A-Z]|_/u',$w)));
    $en=['the','of','and','is','are','to','for','with','from','this','that','by','an','which','will','its','be','or','it','in','on','at','all','into','out'];
    $verbs=['creates','gets','lists','list','updates','deletes','reverts','combines','imports','publishes','undeletes','syncs','resolves','sets','looks','finds','adds','removes','applies','quick','re-generates','returns','retrieves','executes','runs'];
    $hits=count(array_filter($words,static fn($w)=>in_array(mb_strtolower($w),$en,true)));
    return $hits>=2||($words&&in_array(mb_strtolower($words[0]),$verbs,true));
}
verifyLab('Detector flags English Discovery text',englishLab018('Creates a GTM Tag.')&&englishLab018('Lists all GTM Variables of a Container.')&&englishLab018('Move Tag ID out of a Container.'));
verifyLab('Detector accepts Portuguese with technical tokens',!englishLab018('Lista as dimensões e métricas disponíveis para relatórios GA4 (v1alpha runReport com conversionSpec) e anúncio.')&&!englishLab018('Move entidades para uma pasta da área de trabalho.'));
$baseline=json_decode(file_get_contents(dirname(__DIR__).'/fixtures/abilities-0170-baseline.json'),true);
$all=wp_get_abilities();$catalog=LabelsPT::catalog();$names=[];$english=[];
foreach($all as $ability){if($ability->get_category()!=='google')continue;$name=$ability->get_name();$label=$ability->get_label();$names[]=$name;
 verifyLab('Portuguese public label '.$name,$label===$catalog['abilities'][$name]&&$label!==$name&&!str_contains($label,'/')&&!preg_match('/(?:create-|update-|get-|list-|[a-z][A-Z])/',$label));
 if(englishLab018($label)||englishLab018($ability->get_description()))$english[]=$name;}
verifyLab('No ability label or description in English',$english===[],$english);
verifyLab('287 public abilities: 286 preserved plus one new',count($names)===287&&array_values(array_diff($names,array_keys($baseline['abilities'])))===['google/readiness-status']&&!array_diff(array_keys($baseline['abilities']),$names));
/** M6: an output schema may only gain documented properties or describe an untyped object more precisely. */
function compatibleLab018($old,$new): bool {
    if($old===$new)return true;
    if(!is_array($old)||!is_array($new))return false;
    if($old===['type'=>'object'])return ($new['type']??null)==='object'||(isset($new['anyOf'])&&!array_filter($new['anyOf'],static fn($b)=>($b['type']??null)!=='object'));
    foreach(['properties','items','anyOf'] as $nested)if(isset($old[$nested])!==isset($new[$nested]))return false;
    if(!isset($old['properties'])&&!isset($old['items'])&&!isset($old['anyOf']))return false;
    foreach($old as $k=>$v)if(!in_array($k,['properties','items','anyOf'],true)&&($new[$k]??null)!==$v)return false;
    if(isset($old['items'])&&!compatibleLab018($old['items'],$new['items']))return false;
    if(isset($old['anyOf'])){if(count($old['anyOf'])!==count($new['anyOf']))return false;foreach($old['anyOf'] as $i=>$branch)if(!compatibleLab018($branch,$new['anyOf'][$i]))return false;}
    if(isset($old['properties']))foreach($old['properties'] as $k=>$v)if(!array_key_exists($k,$new['properties'])||!compatibleLab018($v,$new['properties'][$k]))return false;
    return true;
}
$widened=json_decode(file_get_contents(dirname(__DIR__).'/fixtures/output-schemas-0170-widened.json'),true)['output_schemas'];
/** M1: an input schema may only gain descriptions; types, limits and required fields stay identical. */
function withoutAddedDescriptionsLab018($old,$new){
    if(!is_array($new)||!is_array($old))return $new;
    foreach($new as $k=>$v){if($k==='description'&&!array_key_exists('description',$old)){unset($new[$k]);continue;}if(is_array($v)&&array_key_exists($k,$old))$new[$k]=withoutAddedDescriptionsLab018($old[$k],$v);}
    return $new;
}
$described=json_decode(file_get_contents(dirname(__DIR__).'/fixtures/input-schemas-0170-described.json'),true)['input_schemas'];
$changed=[];$outputs=[];
foreach($baseline['abilities'] as $name=>$expected){$a=wp_get_ability($name);$m=$a->get_meta();
 $actual=['input_schema_sha256'=>hash('sha256',wp_json_encode($a->get_input_schema(),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),'output_schema_sha256'=>hash('sha256',wp_json_encode($a->get_output_schema(),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),'mode'=>$m['fator3']['mode'],'remote_effect'=>$m['fator3']['remote_effect'],'local_effect'=>$m['fator3']['local_effect'],'annotations'=>$m['annotations']??null];
 if(isset($widened[$name])){$outputs[]=$name;
  verifyLab('Widened fixture is the genuine 0.17.0 output schema '.$name,hash('sha256',wp_json_encode($widened[$name],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE))===$expected['output_schema_sha256']);
  verifyLab('M6 output schema only gains documentation '.$name,compatibleLab018($widened[$name],$a->get_output_schema())&&$actual['output_schema_sha256']!==$expected['output_schema_sha256']);
  $actual['output_schema_sha256']=$expected['output_schema_sha256'];}
 if(isset($described[$name])){$outputs[]=$name;$in=$a->get_input_schema();
  verifyLab('Described fixture is the genuine 0.17.0 input schema '.$name,hash('sha256',wp_json_encode($described[$name],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE))===$expected['input_schema_sha256']);
  verifyLab('M1 bridge input schema only gains descriptions '.$name,withoutAddedDescriptionsLab018($described[$name],$in)===$described[$name]&&$actual['input_schema_sha256']!==$expected['input_schema_sha256']);
  foreach($in['properties'] as $prop=>$schema)verifyLab('M1 bridge parameter described in Portuguese '.$name.'.'.$prop,is_string($schema['description']??null)&&$schema['description']!==''&&!englishLab018($schema['description']));
  $actual['input_schema_sha256']=$expected['input_schema_sha256'];}
 if($actual!==$expected)$changed[]=$name;}
verifyLab('Modes, effects and annotations identical for all 286; schemas identical except 4 documented outputs and 2 described bridge inputs',$changed===[]&&count($outputs)===6,$changed);
$gtm=0;foreach($catalog['descriptions'] as $name=>$text){++$gtm;verifyLab('Reviewed description registered '.$name,wp_get_ability($name)->get_description()===$text&&str_starts_with($name,'gtm/'));}
verifyLab('106 reviewed gtm descriptions',$gtm===106);
$known=['ads/upload-click-conversions'=>'Importar conversões de clique','gtm/create-environment'=>'Criar ambiente','ga/get-account-summaries'=>'Consultar resumos das contas do Analytics','siteverification/get-token'=>'Obter código de verificação do site','google/readiness-status'=>'Consultar prontidão operacional'];
foreach($known as $id=>$label)verifyLab('Human action meaning '.$id,wp_get_ability($id)->get_label()===$label);
$seen=[];$operations=[];
foreach(Policy::coverage()['methods'] as $api=>$methods)foreach($methods as $m){if(isset($operations[$m]))continue;$entry=$catalog['operations'][$m]??[];$group=explode('.',$m)[0];$key=$group.'|'.($entry['label']??'');
 verifyLab('Distinct human permission '.$m,!empty($entry['label'])&&empty($seen[$key])&&!preg_match('/environments|version_headers|built_in_variables|gtag_config|accountSummaries|webResource|customerUserAccessInvitations|offlineUserDataJobs|[a-z][A-Z]/',$entry['label'])&&str_contains($entry['description'],'/'));$seen[$key]=true;$operations[$m]=true;}
verifyLab('All 231 operations covered without stale entries',count($operations)===231&&count($catalog['operations'])===231);
$credential=rpc_identityLab();$auth=$credential['auth'];
$r=rpcLab('google/ability-catalog',['prefix'=>'gtm/create-tag']);$wire=wp_json_encode($r,JSON_UNESCAPED_UNICODE);
verifyLab('MCP public catalog serves Portuguese gtm description',str_contains($wire,'Cria uma tag da área de trabalho')&&!str_contains($wire,'Creates a GTM Tag'),$r['error_code']??null);
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);finishLab('labels018',['english_detected'=>$english,'baseline_fixture'=>$baseline['source']]);
