<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{LabelsPT,Policy,Admin};
$all=wp_get_abilities();$catalog=LabelsPT::catalog();$names=[];
foreach($all as $ability){if($ability->get_category()!=='google')continue;$name=$ability->get_name();$label=$ability->get_label();$names[]=$name;
 verifyLab('Portuguese public label '.$name,$label===$catalog['abilities'][$name]&&$label!==$name&&!str_contains($label,'/')&&!preg_match('/(?:create-|update-|get-|list-|[a-z][A-Z])/',$label));}
verifyLab('All 286 public identities preserved',count($names)===286&&count(array_diff(array_keys($catalog['abilities']),$names))===0);
$known=['ads/upload-click-conversions'=>'Importar conversões de clique','gtm/create-environment'=>'Criar ambiente','ga/get-account-summaries'=>'Consultar resumos das contas do Analytics','siteverification/get-token'=>'Obter código de verificação do site'];
foreach($known as $id=>$label)verifyLab('Human action meaning '.$id,wp_get_ability($id)->get_label()===$label);
$seen=[];$operations=[];
foreach(Policy::coverage()['methods'] as $api=>$methods)foreach($methods as $m){if(isset($operations[$m]))continue;$entry=$catalog['operations'][$m]??[];$group=explode('.',$m)[0];$key=$group.'|'.($entry['label']??'');
 verifyLab('Distinct human permission '.$m,!empty($entry['label'])&&empty($seen[$key])&&!preg_match('/environments|version_headers|built_in_variables|gtag_config|accountSummaries|webResource|customerUserAccessInvitations|offlineUserDataJobs|[a-z][A-Z]/',$entry['label'])&&str_contains($entry['description'],'/'));$seen[$key]=true;$operations[$m]=true;}
verifyLab('All 231 operations covered without stale entries',count($operations)===231&&count($catalog['operations'])===231);
require_once ABSPATH.'wp-admin/includes/template.php';$_GET=['section'=>'connection'];$_SERVER['REQUEST_METHOD']='GET';ob_start();Admin::render();$html=ob_get_clean();
verifyLab('Permission checkboxes expose accessible descriptions',str_contains($html,'Importar conversões de clique')&&str_contains($html,'aria-describedby="f3-operation-')&&str_contains($html,'ads/upload-click-conversions'));
file_put_contents(getenv('F3_EVIDENCE_DIR').'/labels017.html',$html);
$credential=rpc_identityLab();$auth=$credential['auth'];
$r=rpcLab('google/ability-catalog',['prefix'=>'ads/upload-click-conversions']);verifyLab('MCP public catalog contains Portuguese labels',str_contains(wp_json_encode($r,JSON_UNESCAPED_UNICODE),'Importar conversões de clique'),$r['error_code']??null);
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);finishLab('labels017');
