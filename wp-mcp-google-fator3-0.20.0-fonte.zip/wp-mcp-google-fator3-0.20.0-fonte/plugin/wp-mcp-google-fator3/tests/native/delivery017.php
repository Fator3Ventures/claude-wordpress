<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{ConversionDelivery as D,Options as O,Connections as C,Policy,Settings,Records,Admin,Ability};
use Fator3\McpGoogle\Ads\DataManager as DM;
// Each suite starts a new conversion fixture after upgrade-preservation assertions.
O::set(D::CONFIG,D::defaults());
wp_get_abilities();update_option('f3base_ga4_measurement_id','G-TEST017');
$calls=[];$scenario='ok';$secret='synthetic-mp-017';$during=null;
$fixture=static function($pre,$args,$url)use(&$calls,&$scenario,$secret,&$during){
 if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;
 $calls[]=[$url,$args];$body=[];$code=200;$c=O::get(D::CONFIG);
 if(str_contains($url,'/token'))$body=['access_token'=>'synthetic-access017','expires_in'=>3600];
 elseif(str_contains($url,'measurementProtocolSecrets'))$body=['measurementProtocolSecrets'=>[['secretValue'=>$secret]]];
 elseif(str_contains($url,'analyticsadmin.googleapis.com'))$body=['name'=>$c['stream'],'webStreamData'=>['measurementId'=>'G-TEST017']];
 elseif(str_contains($url,'/debug/mp/collect'))$body=['validationMessages'=>[]];
 elseif(str_contains($url,'googleAds:search'))$body=['results'=>[['conversionAction'=>['resourceName'=>$c['conversion_action'],'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>0,'defaultCurrencyCode'=>'BRL']]]]];
 elseif(str_contains($url,'/events:ingest')) {
  $sent=json_decode($args['body'],true);if(empty($sent['validateOnly']))throw new RuntimeException('Verification collected an event');
  if($scenario!=='ok'){$code=400;$body=['error'=>['code'=>400,'status'=>'INVALID_ARGUMENT','message'=>'Invalid request. synthetic-mp-017 user@example.test Bearer private-token','details'=>[['@type'=>'type.googleapis.com/google.rpc.BadRequest','fieldViolations'=>[['field'=>'events.events[0].destination_references','reason'=>$scenario==='not-found'?'NOT_FOUND':'INVALID_VALUE','description'=>'Resource not found. api_secret=private-secret user@example.test']]]]]];}
  if($during){$f=$during;$during=null;$f();}
 }else return $pre;
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>wp_json_encode($body)];
};add_filter('pre_http_request',$fixture,1,3);
O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'synthetic-017',O::OAUTH_REFRESH_TOKEN=>'synthetic-017',O::ADS_DEVELOPER_TOKEN=>'synthetic-dev017']);
function configure017($config,$extra=[]){return D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true]+$config]+$extra);}
function verify017($target){return D::verify(['expected_revision'=>D::revision(),'target'=>$target]);}
function due017(){ $c=O::get(D::CONFIG);$c['renewal']['google_ads']['next_attempt']=time()-1;O::set(D::CONFIG,$c); }
$r=configure017(['stream'=>'properties/123/dataStreams/456'],['mp_secret'=>$secret]);verifyLab('Partial initial GA configuration saves',!empty($r['success']),$r);
verifyLab('GA verifies before Ads configuration',!empty(verify017('ga4')['success']));$ga=new D('ga4');$ads=new D('google_ads');$proof=O::get(D::CONFIG)['verified']['ga4'];
$r=configure017(['customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789']);
verifyLab('Ads partial save preserves stream and exact GA proof',$r['success']&&$ga->capabilities()['ready']&&O::get(D::CONFIG)['verified']['ga4']===$proof&&D::status()['config']['stream']==='properties/123/dataStreams/456',$r);
$scenario='not-found';$r=wp_get_ability('google/verify-conversion-delivery')->execute(['expected_revision'=>D::revision(),'target'=>'google_ads']);
verifyLab('Initial failure uses standard failed response and error code',!is_wp_error($r)&&!$r['success']&&!$r['ok']&&$r['error_code']==='f3_google_delivery_data_manager_unverified',$r);
verifyLab('Provider diagnostic retains HTTP status reason field and message',$r['provider_error']['http_status']===400&&$r['provider_error']['status']==='INVALID_ARGUMENT'&&$r['provider_error']['field_violations'][0]['reason']==='NOT_FOUND'&&$r['provider_error']['field_violations'][0]['field']==='events.events[0].destination_references'&&str_contains($r['provider_error']['field_violations'][0]['message'],'Resource not found.'),$r);
$encoded=json_encode($r);foreach([$secret,'private-token','private-secret','user@example.test'] as $unsafe)verifyLab('Diagnostic masks sensitive text '.$unsafe,!str_contains($encoded,$unsafe));
verifyLab('Initial NOT_FOUND arms bounded retry without Ads proof',$r['retry_scheduled']&&$r['next_attempt']>=time()+295&&!$ads->capabilities()['ready']&&$ads->capabilities()['verification_pending']&&empty(O::get(D::CONFIG)['verified']['google_ads'])&&$ga->capabilities()['ready']);
$id=hash('sha256','default|conversion_verification|google_ads');$incident=Records::get('incident',$id);verifyLab('Incident exposes same safe provider diagnostic',$incident['status']==='open'&&$incident['provider_error']===$r['provider_error']&&str_contains($incident['action'],'automaticamente'));
// Public audit reader validates the runtime's standardized error, without assuming its SQL schema.
$audit=Fator3\McpGoogle\Audit::recent(20);
verifyLab('Audit records a non-null verification error',str_contains(wp_json_encode($audit),'f3_google_delivery_data_manager_unverified'),$audit);
require_once ABSPATH.'wp-admin/includes/template.php';$_GET=['section'=>'incidents'];$_SERVER['REQUEST_METHOD']='GET';ob_start();Admin::render();$html=ob_get_clean();
verifyLab('Incident UI shows diagnostic safely',str_contains($html,'INVALID_ARGUMENT')&&str_contains($html,'destination_references')&&!str_contains($html,'user@example.test'));file_put_contents(getenv('F3_EVIDENCE_DIR').'/incident017.html',$html);
$n=count($calls);D::renew_due();verifyLab('Retry backoff makes no immediate HTTP',count($calls)===$n);
$scenario='ok';due017();wp_set_current_user(0);$run=Fator3\McpGoogle\Automation\Executor::run();wp_set_current_user(1);
verifyLab('Executor retries initially failed destination without manual verification',$ads->capabilities()['ready']&&!$ads->capabilities()['verification_pending']&&Records::get('incident',$id)['status']==='resolved',$run);
$adsproof=O::get(D::CONFIG)['verified']['google_ads'];configure017(['stream'=>'properties/123/dataStreams/457']);verifyLab('GA change preserves exact Ads proof and readiness',$ads->capabilities()['ready']&&O::get(D::CONFIG)['verified']['google_ads']===$adsproof&&!$ga->capabilities()['ready']);
verify017('ga4');$gaproof=O::get(D::CONFIG)['verified']['ga4'];configure017(['conversion_action'=>'customers/1234567890/conversionActions/790']);verifyLab('Ads change invalidates only Ads proof',$ga->capabilities()['ready']&&O::get(D::CONFIG)['verified']['ga4']===$gaproof&&!$ads->capabilities()['ready']);
$scenario='not-found';verify017('google_ads');configure017(['conversion_action'=>'customers/1234567890/conversionActions/791']);$n=count($calls);D::renew_due();verifyLab('Destination change cancels pending retry before HTTP',empty(O::get(D::CONFIG)['pending_verification']['google_ads'])&&count($calls)===$n);
verify017('google_ads');due017();O::set_secret(O::ADS_DEVELOPER_TOKEN,'changed-dev');$n=count($calls);D::renew_due();verifyLab('Credential change blocks pending retry before HTTP',count($calls)===$n&&!$ads->capabilities()['verification_pending']);O::set_secret(O::ADS_DEVELOPER_TOKEN,'synthetic-dev017');
configure017(['conversion_action'=>'customers/1234567890/conversionActions/792']);$scenario='invalid';$r=verify017('google_ads');verifyLab('Other initial errors do not authorize automatic retries',!$r['retry_scheduled']&&empty(O::get(D::CONFIG)['pending_verification']['google_ads']),$r);
$scenario='not-found';verify017('google_ads');due017();$c=O::get(D::CONFIG);$c['granted_by_target']['google_ads']=0;O::set(D::CONFIG,$c);$n=count($calls);D::renew_due();verifyLab('Revoked target grant blocks pending retry before HTTP',count($calls)===$n&&!$ads->capabilities()['ready']&&$ga->capabilities()['ready']);
configure017([]);$scenario='ok';verify017('google_ads');$before=O::get(D::CONFIG);$r=configure017([]);verifyLab('Unchanged save preserves both proofs and requires no verification',!$r['verification_required']&&O::get(D::CONFIG)===$before,$r);
$other=wp_create_user('editor017',bin2hex(random_bytes(16)),'editor017@example.invalid');$u=new WP_User($other);$u->set_role('administrator');wp_set_current_user($other);configure017(['stream'=>'properties/123/dataStreams/458']);$c=O::get(D::CONFIG);
verifyLab('Different administrator does not inherit the untouched Ads grant',$c['granted_by_target']['ga4']===$other&&$c['granted_by_target']['google_ads']===1&&$c['granted_by']===0&&$ads->capabilities()['ready']);wp_set_current_user(1);configure017(['stream'=>'properties/123/dataStreams/457']);require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($other);
$scenario='not-found';$during=static function(){O::set_secret(O::ADS_DEVELOPER_TOKEN,'concurrent-secret');};$r=verify017('google_ads');verifyLab('Concurrent credential mutation cannot arm stale retry',!$r['success']&&empty(O::get(D::CONFIG)['pending_verification']['google_ads']),$r);
O::set(D::CONFIG,D::defaults());remove_filter('pre_http_request',$fixture,1);finishLab('delivery017',['provider_calls'=>'synthetic validateOnly only','real_propagation_cause'=>'not established']);
