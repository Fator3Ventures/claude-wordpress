<?php
/** 0.7.1: failures, isolation, additive contracts and durable observability. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{
    Ability,Catalog,Connections,Lock,Options,Plugin,Policy,Recovery,Settings
};
use Fator3\McpGoogle\Integration\{
    ConsumerClient,ServiceApi,Transition
};
use Fator3\McpGoogle\Automation\{
    CronHistory,Executor
};
use PHPUnit\Framework\TestCase;
final class Release071ReadDb extends \F3_Test_Wpdb {
    public string $fail = '';
    public function get_row($sql,$format) {
        if (str_contains($sql,'f3_google_records')) return parent::get_row($sql,$format);
        $this->last_error = '';
        preg_match("/option_name = '([^']+)'/",$sql,$m);
        $key = stripslashes($m[1]);
        if ($key === $this->fail) {
            $this->last_error = 'PRIVATE_SQL_MARKER';
            return null;
        }
        return array_key_exists($key,$GLOBALS['f3_test_options']) ? ['option_value'=>maybe_serialize($GLOBALS['f3_test_options'][$key])] : null;
    }
    public function query($sql) {
        if (str_contains($sql,'f3_google_records') || in_array($sql,['START TRANSACTION','COMMIT','ROLLBACK'],true)) return parent::query($sql);
        $this->last_error = 'PRIVATE_SQL_MARKER';
        return false;
    }
}
final class Release071Test extends TestCase {
    private ConsumerClient $client;
    private array $cfg;
    private $db;
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=$GLOBALS['f3_test_user_caps']=[];
        $GLOBALS['f3_test_caps']=true;
        $GLOBALS['f3_test_user']=1;
        $this->db=$GLOBALS['wpdb'];
        Connections::select('default');
        FakeHttp::reset();
        $p=new \ReflectionProperty(ServiceApi::class,'consumers');
        $p->setAccessible(true);
        $p->setValue(null,[]);
        $p=new \ReflectionProperty(CronHistory::class,'invocation');
        $p->setAccessible(true);
        $p->setValue(null,null);
        foreach (glob(WP_CONTENT_DIR.'/f3-google-state/*') ?: [] as $file) {
            unlink($file);
        }
        Options::set(Options::ENABLED,true);
        Plugin::register_abilities();
        $this->cfg=['ready'=>true,'property'=>'sc-domain:example.test','revision'=>'property-rev'];
        $this->client=ServiceApi::register_consumer('fixture-consumer','1.0.0',ServiceApi::CONTRACT,fn()=>$this->cfg);
    }
    protected function tearDown(): void {
        $GLOBALS['wpdb']=$this->db;
        $GLOBALS['f3_test_write_fail']=[];
        Connections::select('default');
        foreach (glob(WP_CONTENT_DIR.'/f3-google-state/*') ?: [] as $file) {
            unlink($file);
        }
    }
    private function grant(string $cid='default',bool $enabled=true): array {
        return Connections::run($cid,fn()=>ServiceApi::configure(['consumer_id'=>'fixture-consumer','enabled'=>$enabled,'expected_revision'=>Settings::revision()]));
    }
    /** @dataProvider sdk_cases */
    public function test_sdk_states_are_isolated_and_sanitized(string $case,string $state): void {
        $lines=[];
        $exit=0;
        exec(escapeshellarg(PHP_BINARY).' -n '.escapeshellarg(__DIR__.'/fixtures/sdk071.php').' '.escapeshellarg($case).' 2>&1',$lines,$exit);
        $this->assertSame(0,$exit,implode("\n",$lines));
        $r=json_decode(implode("\n",$lines),true);
        $this->assertSame($state,$r['diagnostic']['state']);
        $this->assertFalse($r['external_connectivity_tested']);
        $this->assertStringNotContainsString('SDK_SECRET_MARKER',json_encode($r));
    }
    public static function sdk_cases(): array {
        return [['absent','sdk_unavailable'],['missing_method','sdk_incompatible'],['wrong_provider','sdk_incompatible'],['caps_invalid','error'],['status_invalid','error'],['errors_invalid','error'],['throws','error'],['disabled','disabled'],['early','not_observed'],['not_ready','not_ready'],['registered','registered']];
    }
    public function test_effective_connection_and_old_status_remain_distinct_and_local(): void {
        Connections::create('analytics','Analytics');
        $this->assertTrue($this->grant('analytics')['success']);
        $this->assertContains('effective_status',ServiceApi::capabilities()['client_methods']);
        $before=$GLOBALS['f3_test_options'];
        $tokens=$GLOBALS['f3_test_transients'];
        $s=$this->client->effective_status();
        $this->assertSame('resolved',$s['resolution']);
        $this->assertSame('analytics',$s['connection_id']);
        $this->assertSame('default',$this->client->status()['connection_id']);
        $this->assertNull($this->client->status()['consumers'][0]['grant']);
        $this->assertSame('default',Connections::id());
        $this->assertSame($before,$GLOBALS['f3_test_options']);
        $this->assertSame($tokens,$GLOBALS['f3_test_transients']);
        $this->assertSame(0,FakeHttp::count());
        $this->assertSame('analytics',ServiceApi::status()['consumers'][0]['effective_status']['connection_id']);
    }
    public function test_resolutions_and_query_share_grant_rule(): void {
        $this->assertSame('not_granted',$this->client->effective_status()['resolution']);
        $this->assertTrue($this->grant()['success']);
        Connections::create('second','Second');
        $g=Options::get(ServiceApi::GRANTS);
        Connections::run('second',fn()=>Options::set(ServiceApi::GRANTS,$g));
        $s=$this->client->effective_status();
        $this->assertSame('ambiguous',$s['resolution']);
        $this->assertNull($s['connection_id']);
        $r=$this->client->query(['contract_version'=>'1.0.0','property'=>$this->cfg['property'],'consumer_revision'=>$this->cfg['revision'],'date'=>'2026-09-20','run_id'=>'test','trigger'=>'manual','budget_ms'=>5000]);
        $this->assertSame('f3_google_consumer_unauthorized',$r['error_code']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_unreadable_registry_or_other_grant_never_proves_uniqueness(): void {
        $this->grant();
        Connections::create('second','Second');
        $db=new Release071ReadDb();
        $GLOBALS['wpdb']=$db;
        foreach ([Connections::REGISTRY,'f3_mcp_google_conn_second_consumer_grants'] as $key) {
            $db->fail=$key;
            $s=$this->client->effective_status();
            $this->assertSame('unreadable',$s['resolution']);
            $this->assertNull($s['connection_id']);
            $this->assertStringNotContainsString('PRIVATE_SQL_MARKER',json_encode($s));
        }
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_forged_client_refused_and_revocation_visible(): void {
        $this->assertSame('f3_google_consumer_unregistered',(new ConsumerClient())->effective_status()['error_code']);
        $this->grant();
        $this->assertSame('resolved',$this->client->effective_status()['resolution']);
        $this->grant('default',false);
        $s=$this->client->effective_status();
        $this->assertSame('not_granted',$s['resolution']);
        $this->assertNull($s['connection_id']);
    }
    public function test_effective_status_retains_blocked_local_states_and_removes_nested_secrets(): void {
        $this->grant();
        $this->cfg['ready']=false;
        Options::set(Options::ENABLED,false);
        $key='f3_mcp_google_consumer_last_default_'.hash('sha256','fixture-consumer');
        Options::set($key,['at'=>time(),'success'=>false,'rows'=>3,'error_code'=>['key'=>'NESTED_SECRET_MARKER'],'request_id'=>['nested'=>'NESTED_SECRET_MARKER'],'credentials'=>['token'=>'NESTED_SECRET_MARKER']]);
        $g=Options::get(ServiceApi::GRANTS);
        $g['fixture-consumer']['extra']=['token'=>'NESTED_SECRET_MARKER'];
        Options::set(ServiceApi::GRANTS,$g);
        $s=$this->client->effective_status();
        $this->assertSame('resolved',$s['resolution']);
        $this->assertFalse($s['local_status']['configuration']['ready']);
        $this->assertFalse($s['local_status']['google_enabled']);
        $this->assertFalse($s['local_status']['remote_access_verified']);
        $this->assertStringNotContainsString('NESTED_SECRET_MARKER',json_encode($s));
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_last_service_missing_differs_from_unreadable(): void {
        $this->grant();
        $s=$this->client->effective_status();
        $this->assertNull($s['local_status']['last_service']);
        $this->assertNull($s['local_status']['last_service_error']);
        $db=new Release071ReadDb();
        $db->fail='f3_mcp_google_consumer_last_default_'.hash('sha256','fixture-consumer');
        $GLOBALS['wpdb']=$db;
        $s=$this->client->effective_status();
        $this->assertSame('f3_google_consumer_state_read',$s['local_status']['last_service_error']);
    }
    public function test_compact_status_and_grant_fit_in_two_calls_and_match_schema_revision(): void {
        Connections::create('second','Second');
        foreach (['default','second'] as $cid) {
            $this->grant('default',false);
            $a=wp_get_ability('google/integration-status')->execute(['connection_id'=>$cid,'compact'=>true]);
            $this->assertTrue($a['success'],json_encode($a));
            $this->assertSame($cid,$a['connection_id']);
            $this->assertSame(Connections::run($cid,fn()=>Settings::revision()),$a['configuration_revision']);
            $b=wp_get_ability('google/configure-consumer')->execute(['connection_id'=>$cid,'consumer_id'=>'fixture-consumer','enabled'=>true,'expected_revision'=>$a['configuration_revision']]);
            $this->assertTrue($b['success'],json_encode($b));
            $this->assertLessThanOrEqual(8192,strlen(json_encode($a))+strlen(json_encode($b)));
            $this->assertArrayNotHasKey('consumers',$a);
            $this->assertArrayNotHasKey('options',$a);
        }
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_revision_conflict_and_failed_read_do_not_create_grant(): void {
        $r=ServiceApi::administrative_status(['compact'=>true]);
        Options::set(Options::HTTP_TIMEOUT,40);
        $bad=ServiceApi::configure(['consumer_id'=>'fixture-consumer','enabled'=>true,'expected_revision'=>$r['configuration_revision']]);
        $this->assertSame('f3_google_configuration_conflict',$bad['error_code']);
        $db=new Release071ReadDb();
        $db->fail=Options::ENABLED;
        $GLOBALS['wpdb']=$db;
        $r=ServiceApi::administrative_status(['compact'=>true]);
        $this->assertFalse($r['success']);
        $this->assertNull($r['configuration_revision']);
        $this->assertFalse($r['read_success']);
    }
    public function test_counts_include_category_members_and_new_prefix_but_not_foreign_abilities(): void {
        $before=Catalog::counts();
        $this->assertGreaterThan(0,$before['gtm']);
        wp_register_ability('foreign/test',['category'=>'other','label'=>'Other','execute_callback'=>fn()=>[]]);
        Ability::register('future/test','any',['label'=>'Future','callback'=>fn()=>[]]);
        $after=Catalog::counts();
        $this->assertSame(1,$after['future']);
        $this->assertSame($before['total']+1,$after['total']);
        $this->assertSame(Catalog::read([])['total'],$after['total']);
        Options::set(Options::ENABLED,false);
        $this->assertSame($after,Catalog::counts());
        // The in-memory registry has no unregister API; remove only this test's additions.
        unset($GLOBALS['f3_test_abilities']['future/test'],$GLOBALS['f3_test_abilities']['foreign/test']);
    }
    public function test_lock_busy_and_storage_error_are_distinct(): void {
        $held=Lock::acquire('cron-history:default');
        $f=CronHistory::begin(['default']);
        $e=$f['errors']['default'];
        $this->assertSame('f3_google_lock_busy',$e['code']);
        $this->assertSame('lock',$e['resource']);
        $this->assertTrue($e['retryable']);
        $this->assertArrayNotHasKey('diagnostic_persisted',$e);
        $this->assertNull(CronHistory::summary('default')['last_observability_error']);
        Lock::release($held);
        $GLOBALS['wpdb']=new Release071ReadDb();
        $r=Lock::acquire_result('different');
        $this->assertSame('f3_google_lock_storage',$r['code']);
        $this->assertSame('f3_google_option_insert',$r['cause_code']);
        $this->assertStringNotContainsString('PRIVATE_SQL_MARKER',json_encode($r));
    }
    public function test_projection_failure_retains_durable_event_and_reconciles_without_dispatch(): void {
        $GLOBALS['f3_test_write_fail']['f3_mcp_google_cron_history_default']=true;
        $f=CronHistory::begin(['default']);
        $e=$f['errors']['default'];
        $this->assertSame('f3_google_cron_projection',$e['code']);
        $this->assertSame('f3_google_option_persistence',$e['cause_code']);
        $this->assertTrue($e['event_persisted']);
        $before=$GLOBALS['f3_test_options'];
        $s=CronHistory::summary('default');
        $this->assertSame($before,$GLOBALS['f3_test_options']);
        $this->assertSame($f['run_id'],$s['last_pass']['run_id']);
        unset($GLOBALS['f3_test_write_fail']['f3_mcp_google_cron_history_default']);
        $this->assertTrue(CronHistory::reconcile('default')['success']);
        $this->assertSame($f['run_id'],Options::get('f3_mcp_google_cron_history_default')['last_pass']['run_id']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_finish_failure_reports_work_and_diagnostic_persistence_separately(): void {
        $f=CronHistory::begin(['default']);
        $key='f3_mcp_google_cron_pass_default_'.$f['run_id'];
        $GLOBALS['f3_test_write_fail'][$key]=true;
        $r=CronHistory::finish($f,['default'=>['items'=>2,'success'=>true,'connection_examined'=>true]]);
        $this->assertSame(2,$r['passes']['default']['items']);
        $this->assertFalse($r['passes']['default']['history_persisted']);
        $this->assertSame('finish',$r['observability_error']['default']['phase']);
        $this->assertSame('f3_google_cron_event',$r['observability_error']['default']['code']);
        $s=CronHistory::summary('default',time()+121);
        $this->assertSame('completion_not_recorded',$s['last_pass']['reason_code']);
        $this->assertNull($s['last_pass']['success']);
    }
    public function test_invocation_without_callback_is_unknown_not_false_proof_of_no_due_events(): void {
        $f=CronHistory::begin(['default'],'wp cron event run',true);
        CronHistory::finish($f,[],'observed');
        $s=CronHistory::summary('default');
        $this->assertSame('google_executor_not_observed',$s['ultima_manual']['reason_code']);
        $this->assertNull($s['last_pass']);
        $r=Executor::run();
        // The executor reports the specific reason since 0.9.x; the generic fallback stays for children without one.
        $this->assertSame('no_due_work',$r['pass']['results']['default']['reason_code']);
    }
    public function test_expired_incident_remains_available_as_history(): void {
        Options::set('f3_mcp_google_cron_error_default',['at'=>time()-90000,'code'=>'f3_google_cron_projection']);
        $s=CronHistory::summary('default');
        $this->assertSame('f3_google_cron_projection',$s['observability_error']['code']);
        $this->assertSame('f3_google_cron_projection',$s['last_observability_error']['code']);
        $this->assertFalse($s['window_complete']);
    }
    public function test_bridge_defers_recovery_fence_to_target_and_keeps_status_available(): void {
        $this->assertTrue(Recovery::change(['action'=>'prepare'])['ready_for_restore']);
        $call=static fn($ability,$write=false)=>\Fator3\McpGoogle\Storage\Admission::run($write?'google/mcp-write':'google/mcp-read',static fn()=>\Fator3\McpGoogle\McpBridge::dispatch(['ability'=>$ability,'parameters'=>[]],$write));
        $this->assertTrue($call('google/status')['success']);
        $this->assertSame('f3_google_recovery_paused',$call('gsc/list-sites')['error_code']);
        $this->assertSame('f3_google_mcp_input',$call('google/mcp-read')['error_code']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_malformed_projection_is_a_read_failure_and_never_a_fatal_or_green_status(): void {
        Options::set('f3_mcp_google_cron_history_default',['last_pass'=>'PRIVATE_CORRUPT_MARKER']);
        $frame=CronHistory::begin(['default']);
        $this->assertSame('f3_google_cron_read',$frame['errors']['default']['code']);
        $this->assertSame('projection',$frame['errors']['default']['resource']);
        $this->assertTrue($frame['errors']['default']['event_persisted']);
        $s=CronHistory::summary('default');
        $this->assertSame('f3_google_cron_read',$s['observability_error']['code']);
        $this->assertFalse($s['window_complete']);
        $this->assertFalse($s['cron_servidor_ativo']);
        $this->assertStringNotContainsString('PRIVATE_CORRUPT_MARKER',json_encode($s));
    }
}
