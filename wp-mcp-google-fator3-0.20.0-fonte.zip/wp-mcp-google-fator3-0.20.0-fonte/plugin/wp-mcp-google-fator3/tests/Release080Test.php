<?php
/** Diagnostic verdicts, strict consumers and preservation of the supported current state. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Ability,Admin,Connections,Options,Plugin,Preflight,SelfTest,Settings,Setup};
use Fator3\McpGoogle\Integration\Transition;
use PHPUnit\Framework\TestCase;
final class Release080Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=$GLOBALS['f3_test_user_caps']=[];
        $GLOBALS['f3_test_caps']=true; $GLOBALS['f3_test_user']=1; $_GET=$_POST=$_FILES=[];
        Connections::select('default'); FakeHttp::reset(); Plugin::register_abilities(); Options::set(Options::ENABLED,true);
        foreach (glob(WP_CONTENT_DIR.'/f3-google-state/*') ?: [] as $p) { unlink($p); }
    }
    protected function tearDown(): void { Connections::select('default'); $_GET=$_POST=$_FILES=[]; FakeHttp::reset(); }
    private function oauth(array $services=['ads'=>'read']): void {
        Options::batch_verified([Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',Connections::SERVICES=>$services],[Options::OAUTH_CLIENT_SECRET=>'private-client-marker',Options::OAUTH_REFRESH_TOKEN=>'private-refresh-marker']);
    }
    public function test_reported_case_is_incomplete_without_failure_code_and_configuration_unchanged(): void {
        Options::set(Options::ADS_ENABLED,true); $before=Settings::revision();
        $r=wp_get_ability('google/selftest')->execute([]);
        $this->assertTrue($r['success'],json_encode($r)); $this->assertTrue($r['execution_success']);
        $this->assertSame('incomplete',$r['result_status']);$this->assertFalse($r['complete']);$this->assertFalse($r['checks_passed']);$this->assertFalse($r['all_checks_passed']);
        $this->assertSame([10,0,0,1],[$r['passed'],$r['failed'],$r['skipped'],$r['not_configured']]);
        $this->assertArrayNotHasKey('error_code',$r);$this->assertStringContainsString('1 não configurada',$r['message']);$this->assertStringContainsString('config — Conector Ads ligado sem developer token.',$r['message']);
        $this->assertSame($before,Settings::revision());$this->assertTrue(Options::ads_enabled());$this->assertSame(0,FakeHttp::count());
        $this->assertCount(11,$r['checks']);
    }
    /** @dataProvider verdicts */
    public function test_verdict_truth_table(array $statuses,bool $success,string $status,bool $complete,bool $passed,bool $all): void {
        $r=SelfTest::diagnose(array_map(static fn($s)=>['name'=>$s,'status'=>$s,'detail'=>'Fixture'], $statuses));
        $this->assertSame([$success,true,$status,$complete,$passed,$all],[$r['success'],$r['execution_success'],$r['result_status'],$r['complete'],$r['checks_passed'],$r['all_checks_passed']]);
        $this->assertSame(count($statuses),$r['passed']+$r['failed']+$r['skipped']+$r['not_configured']);
        $this->assertSame(!$success,isset($r['error_code']));
        if (!$success) $this->assertSame('f3_google_selftest_failed',$r['error_code']);
    }
    public static function verdicts(): array {return [
        [['passed'],true,'passed',true,true,true],
        [['passed','not_configured'],true,'incomplete',false,false,false],
        [['passed','skipped'],true,'incomplete',false,true,false],
        [['failed'],false,'failed',true,false,false],
        [['failed','not_configured','skipped'],false,'failed',false,false,false],
        [['invalid'],false,'failed',true,false,false],
    ];}
    public function test_live_missing_multiple_services_names_all_pending_and_does_not_grant(): void {
        Options::set(Options::GA_ENABLED,true);Options::set(Connections::SERVICES,['ga'=>'read','gsc'=>'read']);
        $r=SelfTest::run(['live'=>true]);
        $this->assertTrue($r['success']);$this->assertSame(2,$r['not_configured']);
        $this->assertStringContainsString('2 não configuradas',$r['message']);
        foreach (['live_ga','live_gsc'] as $name) $this->assertStringContainsString($name,$r['message']);
        $strict=Preflight::run(['services'=>['ga','gsc']]);$this->assertFalse($strict['success']);$this->assertFalse($strict['all_checks_passed']);
        $applied=Setup::apply(['services'=>['gsc'=>'read'],'bindings'=>['gsc_site_url'=>'sc-domain:example.test'],'simular'=>false]);
        $this->assertFalse($applied['success']);$this->assertSame(0,FakeHttp::count());
    }
    public function test_preflight_execution_error_preserves_cause_without_fake_counts(): void {
        $r=SelfTest::run(['live'=>true,'services'=>['invalid']]);
        $this->assertFalse($r['success']);$this->assertFalse($r['execution_success']);$this->assertSame('execution_error',$r['result_status']);
        $this->assertSame('f3_google_preflight_input',$r['error_code']);
        foreach (['checks','passed','failed','skipped','not_configured'] as $key) $this->assertArrayNotHasKey($key,$r);
    }
    public function test_exception_in_live_keeps_execution_error_and_redacts_secrets(): void {
        $this->oauth(['gsc'=>'read']);
        $hook=static function(){throw new \RuntimeException('Fixture private-refresh-marker');};add_filter('pre_http_request',$hook,1);
        try {$r=wp_get_ability('google/selftest')->execute(['live'=>true]);} finally {remove_filter('pre_http_request',$hook,1);}
        $this->assertFalse($r['execution_success']);$this->assertSame('execution_error',$r['result_status']);$this->assertSame('f3_google_exception',$r['error_code']);
        $this->assertStringNotContainsString('private-refresh-marker',json_encode($r));$this->assertArrayNotHasKey('failed',$r);
    }
    public function test_unreadable_secret_is_reproval_not_missing(): void {
        Options::set(Options::ADS_ENABLED,true);$GLOBALS['f3_test_options'][Options::ADS_DEVELOPER_TOKEN]='f3enc:broken';
        $r=wp_get_ability('google/selftest')->execute([]);
        $this->assertFalse($r['success']);$this->assertSame('failed',$r['result_status']);$this->assertSame(0,$r['not_configured']);$this->assertSame('f3_google_selftest_failed',$r['error_code']);
    }
    public function test_connection_isolation_and_selection_restored(): void {
        Options::set(Options::ADS_ENABLED,true);Connections::create('second','Second');
        Connections::run('second',static fn()=>Options::set(Options::ADS_ENABLED,false));
        $before=Settings::revision();$r=wp_get_ability('google/selftest')->execute(['connection_id'=>'second']);
        $this->assertSame('passed',$r['result_status']);$this->assertSame('default',Connections::id());$this->assertSame($before,Settings::revision());
        $this->assertSame('incomplete',wp_get_ability('google/selftest')->execute([])['result_status']);$this->assertSame(0,FakeHttp::count());
    }
    public function test_diagnostic_and_strict_aggregate_do_not_share_approval_semantics(): void {
        $checks=[['name'=>'missing','status'=>'not_configured','detail'=>'Pending']];
        $this->assertTrue(SelfTest::diagnose($checks)['success']);
        $strict=SelfTest::summarize($checks);$this->assertFalse($strict['success']);$this->assertFalse($strict['all_checks_passed']);
    }
    public function test_diagnostic_names_and_details_scrubbed(): void {
        Options::set_secret(Options::ADS_DEVELOPER_TOKEN,'private-token-marker');
        $r=SelfTest::diagnose([['name'=>'a','status'=>'not_configured','detail'=>'Fixture private-token-marker'],['name'=>'b','status'=>'not_configured','detail'=>'Other']]);
        $this->assertStringNotContainsString('private-token-marker',json_encode($r));$this->assertStringContainsString('a —',$r['message']);$this->assertStringContainsString('b — Other',$r['message']);
    }
    public function test_ui_shows_incomplete_summary_stale_state_and_collapsed_json(): void {
        Options::set(Options::ADS_ENABLED,true);$r=SelfTest::run()+['revision'=>Settings::revision(),'connection_id'=>'default','auth_mode'=>'service_account','checked_at'=>'2026-10-07T17:00:00Z'];
        \Fator3\McpGoogle\Cache::set(Admin::diagnostic_key(),$r,3600);$_GET=['section'=>'advanced','advanced_panel'=>'diagnostics','f3_status'=>'tested'];
        ob_start();Admin::render();$html=ob_get_clean();
        $this->assertStringContainsString('notice-info',$html);$this->assertStringNotContainsString('notice-success',$html);
        $this->assertStringContainsString('f3-state-not_configured">Incompleto',$html);$this->assertStringContainsString($r['message'],$html);
        $this->assertStringContainsString('Conector Ads ligado sem developer token',$html);$this->assertStringContainsString('Detalhes técnicos da verificação',$html);$this->assertStringNotContainsString('<details open',$html);
        Options::set(Options::HTTP_TIMEOUT,35);ob_start();Admin::render();$html=ob_get_clean();
        $this->assertStringContainsString('Resultado desatualizado',$html);$this->assertStringContainsString('f3-state-skipped">Incompleto (anterior)',$html);$this->assertSame(0,FakeHttp::count());
    }
    public function test_cached_071_result_marked_invalid_without_mutating_or_retesting(): void {
        $r=SelfTest::summarize([['name'=>'config','status'=>'not_configured','detail'=>'Pending']])+['revision'=>Settings::revision(),'connection_id'=>'default'];
        \Fator3\McpGoogle\Cache::set(Admin::diagnostic_key(),$r,3600);$_GET=['section'=>'advanced','advanced_panel'=>'diagnostics'];ob_start();Admin::render();$html=ob_get_clean();
        $this->assertStringContainsString('Diagnóstico armazenado inválido ou de formato anterior',$html);$this->assertSame($r,get_transient(Admin::diagnostic_key()));$this->assertSame(0,FakeHttp::count());
    }


    public function test_registered_schema_describes_incomplete_and_versions(): void {
        $a=wp_get_ability('google/selftest');$p=$a->get_output_schema()['properties'];$this->assertSame(['passed','incomplete','failed','execution_error'],$p['result_status']['enum']);
        $this->assertSame(F3_MCP_GOOGLE_VERSION,$a->get_meta()['fator3']['version']);$this->assertContains('google/selftest',array_keys(\Fator3\McpGoogle\Catalog::registered()));
    }
}
