<?php
/** Focused contract tests; no WordPress, credentials, or provider transport. */
define('ABSPATH', __DIR__.'/');
require __DIR__.'/../includes/ContractSchema.php';
require __DIR__.'/../includes/CoreConversions.php';
use Fator3\McpGoogle\{CoreConversions,ContractSchema};
$checks=[];
function check012(string $label,bool $ok): void {global $checks;if(!$ok)throw new RuntimeException($label);$checks[]=$label;}
function fixture012(string $name): array {return json_decode(file_get_contents(__DIR__.'/fixtures/core-conversions/'.$name.'.json'),true);}
$mode=$argv[1]??'matrix';
if($mode==='absent'){
 check012('Absent producer is optional and explicit',CoreConversions::snapshot()['code']==='unavailable');
}elseif($mode==='missing-method'){
 class F3Base_Conversoes_Contexto {public static function capabilities(): array{return fixture012('capabilities');}}
 check012('Missing public method is unsupported',CoreConversions::snapshot()['code']==='unsupported');
}else{
 class F3Base_Conversoes_Contexto {
  public static $cap;public static $value;public static array $input=[];public static bool $throw=false;
  public static function capabilities(){return self::$cap;}
  public static function snapshot(array $input){self::$input=$input;if(self::$throw)throw new RuntimeException('PRIVATE_EXCEPTION_MARKER');return self::$value;}
 }
 F3Base_Conversoes_Contexto::$cap=fixture012('capabilities');
 foreach(['material-enabled-ids-empty','material-own-id','unsupported','revision-conflict'] as $name){
  F3Base_Conversoes_Contexto::$value=fixture012($name);check012('Pinned producer fixture preserved '.$name,CoreConversions::snapshot()===fixture012($name));
 }
 $base=fixture012('material-enabled-ids-empty');F3Base_Conversoes_Contexto::$value=$base;
 CoreConversions::snapshot(['expected_revision'=>$base['data']['revision']]);
 check012('Only exact contract and requested revision sent',F3Base_Conversoes_Contexto::$input===['contract'=>CoreConversions::CONTRACT,'expected_revision'=>$base['data']['revision']]);
 foreach([['offset'=>0],['limit'=>1],['connection_id'=>'default'],['expected_revision'=>'bad'],['contract'=>CoreConversions::CONTRACT]] as $input){check012('Closed adapter input '.key($input),CoreConversions::snapshot($input)['code']==='invalid_input');}
 $cap=fixture012('capabilities');
 foreach(['version','schema','provider','pagination','duplicate-method','extra'] as $case){
  $v=$cap;
  switch($case){case 'version':$v['data']['contract_version']='2.0.0';break;case 'schema':$v['data']['schema_revision']=1;break;case 'provider':$v['provider']='other';break;case 'pagination':$v['data']['pagination']=true;break;case 'duplicate-method':$v['data']['methods']=['snapshot','snapshot'];break;case 'extra':$v['data']['arbitrary']='private';break;}
  F3Base_Conversoes_Contexto::$cap=$v;check012('Descriptor rejects '.$case,CoreConversions::snapshot()['code']==='unsupported');
 }
 F3Base_Conversoes_Contexto::$cap=$cap;
 foreach(['duplicate','missing','event','boolean','verification','extra','revision','timestamp','timezone'] as $case){
  $v=$base;
  switch($case){case 'duplicate':$v['data']['purposes'][1]=$v['data']['purposes'][0];break;case 'missing':array_pop($v['data']['purposes']);break;case 'event':$v['data']['purposes'][1]['ga4_event']='generate_lead';break;case 'boolean':$v['data']['purposes'][1]['destinations']['ga4']['enabled']='1';break;case 'verification':$v['data']['runtime_verified']=true;break;case 'extra':$v['secret']='PRIVATE';break;case 'revision':$v['data']['revision']='bad';break;case 'timestamp':$v['data']['observed_at']='2026-02-30T17:26:31+00:00';break;case 'timezone':$v['data']['observed_at']='2026-10-17T17:26:31-03:00';break;}
  F3Base_Conversoes_Contexto::$value=$v;check012('Snapshot rejects '.$case,CoreConversions::snapshot()['code']==='unsupported');
 }
 $v=$base;$v['data']['purposes']=array_reverse($v['data']['purposes']);F3Base_Conversoes_Contexto::$value=$v;
 check012('Purpose order is not meaningful',CoreConversions::snapshot()===$v);
 $v=$base;$v['data']['purposes'][1]['destinations']['google_ads']['identifiers']['conversion_label']=null;F3Base_Conversoes_Contexto::$value=$v;
 check012('Nullable identifier remains null',CoreConversions::snapshot()===$v);
 $v=$base;$v['data']['observed_at']='2026-10-17T17:26:31.123Z';F3Base_Conversoes_Contexto::$value=$v;
 check012('RFC3339 UTC fractional observation preserved',CoreConversions::snapshot()===$v);
 F3Base_Conversoes_Contexto::$value=$base;
 check012('Wrong revision rejected even if producer ignores guard',CoreConversions::snapshot(['expected_revision'=>str_repeat('0',64)])['code']==='revision_conflict');
 $m=['ok'=>true,'data'=>['revision'=>$base['data']['measurement_revision']]];
 check012('Consistent combined context preserved',CoreConversions::revalidate($base,$m)===$base);
 check012('Measurement mismatch discarded',CoreConversions::revalidate($base,['ok'=>true,'data'=>['revision'=>str_repeat('0',64)]])['code']==='revision_conflict');
 $v=$base;$v['data']['revision']=str_repeat('0',64);F3Base_Conversoes_Contexto::$value=$v;
 check012('Conversion mutation during remote read discarded',CoreConversions::revalidate($base,$m)['code']==='revision_conflict');
 F3Base_Conversoes_Contexto::$throw=true;$v=CoreConversions::snapshot();
 check012('Exception sanitized and unreadable',$v['code']==='unreadable'&&!str_contains(json_encode($v),'PRIVATE'));
 foreach(['invalid_input','unsupported','unreadable','revision_conflict','not_authorized'] as $code){F3Base_Conversoes_Contexto::$throw=false;$v=CoreConversions::failure($code);F3Base_Conversoes_Contexto::$value=$v;check012('Producer failure retains null '.$code,CoreConversions::snapshot()===$v);}
 check012('Consumer absence is declared in output only',!ContractSchema::valid(CoreConversions::failure('unavailable'),CoreConversions::schema('snapshot'))&&ContractSchema::valid(CoreConversions::failure('unavailable'),CoreConversions::response_schema()));
}
echo json_encode(['suite'=>'conversions-contract012-'.$mode,'checks'=>count($checks),'passed'=>$checks,'failures'=>0],JSON_PRETTY_PRINT)."\n";
