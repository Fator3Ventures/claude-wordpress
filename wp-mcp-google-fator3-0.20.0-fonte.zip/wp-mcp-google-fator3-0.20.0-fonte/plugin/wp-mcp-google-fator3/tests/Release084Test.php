<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Options,Connections,Settings,Setup,SetupAdmin,ServiceSelection,Recovery,Lock,Template,Plugin};
use Fator3\McpGoogle\Automation\{ExecutorSchedule,Scheduling,Jobs,Executor};
final class Release084Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;Connections::select('default');
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f) if(is_file($f)) unlink($f);
        Options::set(Options::ENABLED,true);FakeHttp::reset();
    }
    protected function tearDown(): void { $GLOBALS['f3_test_write_fail']=[];Connections::select('default'); }
    private function full(): void { Settings::save([Connections::SERVICES=>['ga'=>'admin','ads'=>'write','gsc'=>'write','sheets'=>'write'],Options::GA_ENABLED=>true,Options::ADS_ENABLED=>true]); }
    private function confirmed(array $input): array { $p=Setup::plan($input);$this->assertTrue($p['success'],json_encode($p));return $input+['confirm_service_reduction'=>true,'expected_revision'=>$p['configuration_revision'],'expected_plan_hash'=>$p['plan_hash']]; }
    public function test_missing_is_current_error_with_idle_work_and_two_read_only_queries(): void {
        $before=$GLOBALS['f3_test_options'];
        foreach([1,2] as $n) { $s=Executor::status();$this->assertSame('missing',$s['scheduling']['checks']['executor']['state']);$this->assertSame('degraded',$s['health']);$this->assertSame('idle',$s['work_health']);$this->assertSame('current_state',$s['scheduling']['active_errors'][0]['source']); }
        $this->assertSame($before,$GLOBALS['f3_test_options']);$this->assertSame(0,FakeHttp::count());
    }
    public function test_repair_without_work_is_idempotent_and_preserves_foreign_event(): void {
        wp_schedule_event(time()+3600,'hourly','foreign_event',['keep']);$foreign=_get_cron_array();
        $one=ExecutorSchedule::ensure();$this->assertTrue($one['success'],json_encode($one));$this->assertTrue($one['changed']);
        $after=$GLOBALS['f3_test_options'];$two=ExecutorSchedule::ensure();$this->assertTrue($two['success']);$this->assertFalse($two['changed']);$this->assertSame($after,$GLOBALS['f3_test_options']);
        foreach($foreign as $at=>$row) $this->assertSame($row['foreign_event'],_get_cron_array()[$at]['foreign_event']);
        $this->assertSame(1,ExecutorSchedule::status()['occurrences']);
    }
    public function test_due_event_is_present_and_bad_shape_is_not_repaired(): void {
        wp_schedule_event(time()-60,'f3_google_minute',Jobs::HOOK);$this->assertSame('present',ExecutorSchedule::status()['state']);
        $cron=_get_cron_array();$at=array_key_first($cron);$cron[$at][Jobs::HOOK][md5(serialize([]))]['interval']=120;update_option('cron',$cron+['version'=>2]);
        $before=get_option('cron');$this->assertSame('invalid',ExecutorSchedule::status()['state']);$this->assertFalse(ExecutorSchedule::ensure()['success']);$this->assertSame($before,get_option('cron'));
    }
    public function test_multiple_and_empty_hook_are_invalid(): void {
        wp_schedule_event(time()+60,'f3_google_minute',Jobs::HOOK);wp_schedule_event(time()+120,'f3_google_minute',Jobs::HOOK);
        $this->assertSame('f3_google_executor_event_multiple',ExecutorSchedule::status()['reason_code']);
        update_option('cron',[time()=>[Jobs::HOOK=>[]],'version'=>2]);$this->assertSame('invalid',ExecutorSchedule::status()['state']);
    }
    public function test_changed_effective_view_is_unknown_but_field_order_is_irrelevant(): void {
        ExecutorSchedule::ensure();$priorDb=$GLOBALS['wpdb'];
        $GLOBALS['wpdb']=new class extends \F3_Test_Wpdb {
            public function get_row($sql,$format=null) { preg_match("/option_name = '([^']+)'/",$sql,$m);$v=$GLOBALS['f3_test_options'][$m[1]??'']??null;return $v===null?null:['option_value'=>serialize($v)]; }
        };
        $cron=get_option('cron');$alter=static function()use($cron){$at=array_key_first($cron);$cron[$at][Jobs::HOOK][md5(serialize([]))]=array_reverse($cron[$at][Jobs::HOOK][md5(serialize([]))],true);return $cron;};
        add_filter('pre_option_cron',$alter);$this->assertSame('present',ExecutorSchedule::status()['state']);remove_filter('pre_option_cron',$alter);
        $alter=static fn()=>[];add_filter('pre_option_cron',$alter);$this->assertSame('unknown',ExecutorSchedule::status()['state']);remove_filter('pre_option_cron',$alter);$GLOBALS['wpdb']=$priorDb;
    }
    public function test_lifecycle_blocks_stale_generation_and_inactive_repair(): void {
        ExecutorSchedule::activate();$old=get_option(ExecutorSchedule::OPTION)['generation'];ExecutorSchedule::deactivate();
        $this->assertSame('inactive',ExecutorSchedule::status()['state']);$this->assertFalse(ExecutorSchedule::ensure()['success']);
        ExecutorSchedule::activate();wp_clear_scheduled_hook(Jobs::HOOK);
        $p=new \ReflectionProperty(ExecutorSchedule::class,'generations');$p->setAccessible(true);$p->setValue(null,[1=>$old]);
        $this->assertFalse(ExecutorSchedule::ensure()['success']);$this->assertFalse(wp_next_scheduled(Jobs::HOOK));
    }
    public function test_first_generation_capture_also_expires(): void {
        ExecutorSchedule::capture();$p=new \ReflectionProperty(ExecutorSchedule::class,'generations');$p->setAccessible(true);$old=$p->getValue();
        ExecutorSchedule::activate();wp_clear_scheduled_hook(Jobs::HOOK);$p->setValue(null,$old);
        $this->assertFalse(ExecutorSchedule::ensure()['success']);$this->assertFalse(wp_next_scheduled(Jobs::HOOK));
    }
    public function test_recovery_pause_does_not_allow_operational_repair_but_allows_teardown(): void {
        ExecutorSchedule::activate();$r=Recovery::change(['action'=>'prepare']);$this->assertTrue($r['success']);wp_clear_scheduled_hook(Jobs::HOOK);
        $this->assertFalse(ExecutorSchedule::ensure()['success']);$this->assertFalse(ExecutorSchedule::status()['repair_allowed']);
        $this->assertTrue(ExecutorSchedule::deactivate()['success']);
        $s=Recovery::status();Recovery::change(['action'=>'resume','expected_generation'=>$s['generation'],'acknowledge_reconciled'=>true]);
    }
    public function test_contention_yields_without_storage_incident(): void {
        $lock=Lock::acquire('executor-schedule');$r=ExecutorSchedule::ensure();Lock::release($lock);
        $this->assertSame('yielded',$r['state']);$this->assertTrue($r['retryable']);$this->assertFalse(wp_next_scheduled(Jobs::HOOK));
    }
    public function test_native_failure_needs_current_proof(): void {
        $filter=static fn()=>new \WP_Error('synthetic_native_failure');add_filter('pre_schedule_event',$filter);
        $r=ExecutorSchedule::ensure();remove_filter('pre_schedule_event',$filter);
        $this->assertFalse($r['success']);$this->assertSame('synthetic_native_failure',$r['scheduling']['original_code']);$this->assertSame('missing',$r['after']['state']);
        $retry=ExecutorSchedule::ensure();$this->assertTrue($retry['success'],json_encode($retry));
    }
    public function test_dry_run_and_refused_replacement_do_not_write_bindings_or_services(): void {
        $this->full();$before=Settings::revision();$input=['services'=>['gtm'=>'admin'],'bindings'=>['ga_property_id'=>'123'],'validate_access'=>false];
        $p=Setup::apply($input+['dry_run'=>true]);$this->assertTrue($p['success']);$this->assertSame(['ga','ads','gsc','sheets'],$p['service_changes']['disabled']);$this->assertFalse($p['persisted']);$this->assertSame('not_applied',$p['operation_outcome']);
        $r=Setup::apply($input);$this->assertFalse($r['success']);$this->assertSame('f3_google_service_reduction_confirmation_required',$r['error_code']);$this->assertSame($before,Settings::revision());$this->assertSame(0,FakeHttp::count());
    }
    public function test_merge_preserves_levels_and_second_equal_request_is_noop(): void {
        $this->full();$r=Setup::apply(['services'=>['gtm'=>'write'],'merge'=>true]);$this->assertTrue($r['success'],json_encode($r));$this->assertSame('write',Options::get(Connections::SERVICES)['gsc']);
        $revision=Settings::revision();$r=Setup::apply(['merge'=>true,'services'=>['gtm'=>'write']]);$this->assertTrue($r['success']);$this->assertFalse($r['changed']);$this->assertSame($revision,Settings::revision());
    }
    public function test_inherited_selection_respects_flags_and_empty_merge_is_noop(): void {
        Options::set(Options::GA_ENABLED,false);Options::set(Options::ADS_ENABLED,true);
        $p=Setup::plan(['services'=>['gtm'=>'read'],'merge'=>true]);$this->assertNull($p['services_stored_before']);$this->assertFalse($p['services_after']['ga']['enabled']);$this->assertTrue($p['services_after']['ads']['enabled']);$this->assertSame('write',$p['services_after']['gsc']['level']);$this->assertFalse($p['confirmation_required']);
        $before=Settings::revision();$r=Setup::apply(['services'=>[],'merge'=>true]);$this->assertTrue($r['success']);$this->assertFalse($r['changed']);$this->assertSame($before,Settings::revision());$this->assertNull(Options::get(Connections::SERVICES,null));
    }
    public function test_confirmation_binds_every_field_actor_and_mode(): void {
        $this->full();$input=['services'=>['gtm'=>'read'],'bindings'=>['ga_property_id'=>'123'],'validate_access'=>false];$c=$this->confirmed($input);$before=Settings::revision();
        foreach([['bindings'=>['ga_property_id'=>'124']],['merge'=>true],['validate_access'=>true]] as $change){$r=Setup::apply(array_replace($c,$change));$this->assertFalse($r['success']);$this->assertSame('f3_google_configuration_conflict',$r['error_code']);}
        $GLOBALS['f3_test_user']=2;$this->assertFalse(Setup::apply($c)['success']);$GLOBALS['f3_test_user']=1;
        $this->assertSame($before,Settings::revision());$r=Setup::apply($c);$this->assertTrue($r['success'],json_encode($r));$this->assertSame(['gtm'=>'read'],Options::get(Connections::SERVICES));
        $this->assertFalse(Setup::apply($c)['success']);
    }
    public function test_ads_downgrade_is_detected_despite_shared_oauth_scope(): void {
        $this->full();$p=Setup::plan(['services'=>['ads'=>'read'],'merge'=>true]);$this->assertSame(['ads'],$p['service_changes']['downgraded']);$this->assertTrue($p['confirmation_required']);
        $this->assertFalse(Setup::apply(['services'=>['ads'=>'read'],'merge'=>true])['success']);
    }
    public function test_reordered_inputs_produce_same_hash_and_stale_revision_blocks(): void {
        $this->full();$a=['services'=>['ga'=>'admin','ads'=>'write','gsc'=>'write','sheets'=>'write']];$b=['services'=>array_reverse($a['services'],true)];
        $this->assertSame(Setup::plan($a)['plan_hash'],Setup::plan($b)['plan_hash']);$this->assertFalse(Setup::apply($a)['changed']);
        $p=Setup::plan(['services'=>[]]);Settings::save([Options::HTTP_TIMEOUT=>31]);$r=Setup::apply(['services'=>[],'expected_revision'=>$p['configuration_revision'],'expected_plan_hash'=>$p['plan_hash'],'confirm_service_reduction'=>true]);$this->assertSame('not_applied',$r['operation_outcome']);
    }
    /** @dataProvider invalid_inputs */
    public function test_invalid_input_is_not_silently_converted(array $input): void {
        $before=Settings::revision();$r=Setup::apply($input);$this->assertFalse($r['success']);$this->assertSame($before,Settings::revision());
    }
    public static function invalid_inputs(): array {return [[['services'=>null]],[['services'=>'ga']],[['services'=>['ga'=>'owner']]],[['services'=>['unknown'=>'read']]],[['services'=>['ga'=>true]]],[['merge'=>true]],[['dry_run'=>'true']],[['confirm_service_reduction'=>1]],[['merge'=>1,'services'=>[]]]];}
    public function test_binding_only_preserves_selection_and_other_connection_hash_is_rejected(): void {
        $this->full();$old=Options::get(Connections::SERVICES);$this->assertTrue(Setup::apply(['bindings'=>['ga_property_id'=>'123'],'validate_access'=>false])['success']);$this->assertSame($old,Options::get(Connections::SERVICES));
        $c=$this->confirmed(['services'=>[]]);Connections::create('other','Other');Connections::select('other');$this->assertFalse(Setup::apply($c)['success']);Connections::select('default');$this->assertSame($old,Options::get(Connections::SERVICES));
    }
    public function test_refused_write_preserves_configuration_and_reports_restoration(): void {
        $this->full();$before=Settings::revision();$c=$this->confirmed(['services'=>[],'bindings'=>['ga_property_id'=>'123'],'validate_access'=>false]);$GLOBALS['f3_test_write_fail'][Options::GA_DEFAULT_PROPERTY]=true;
        $r=Setup::apply($c);$this->assertFalse($r['success']);$this->assertTrue($r['restored']);$this->assertFalse($r['changed']);$this->assertSame('not_applied',$r['operation_outcome']);$this->assertSame($before,Settings::revision());
    }
    public function test_unconfirmed_restoration_never_claims_no_change(): void {
        $this->full();$c=$this->confirmed(['services'=>[]]);
        $fail=static function($value,$old) { $GLOBALS['f3_test_write_fail'][Connections::SERVICES]=true;return $old; };
        add_filter('pre_update_option_'.Options::ADS_ENABLED,$fail,10,2);
        try { $r=Setup::apply($c);$this->assertFalse($r['success']);$this->assertFalse($r['restored']);$this->assertTrue($r['changed']);$this->assertSame('unknown',$r['operation_outcome']); }
        finally {remove_filter('pre_update_option_'.Options::ADS_ENABLED,$fail);$GLOBALS['f3_test_write_fail']=[];}
    }
    public function test_panel_review_is_bound_and_explicit_and_template_has_same_diff(): void {
        $this->full();$i=['services'=>['gtm'=>'write'],'validate_access'=>false];$p=Setup::plan($i);$html=SetupAdmin::preview_html($i,$p);
        $this->assertStringContainsString('Confirmar alterações e reduções',$html);$this->assertStringContainsString($p['plan_hash'],$html);$this->assertStringContainsString('name="_wpnonce"',$html);$this->assertStringContainsString('confirm_service_reduction',$html);
        $t=Template::plan(['template'=>['schema_version'=>'1.0.0','services'=>['gtm'=>'write']]]);$this->assertSame($p['service_changes'],$t['service_changes']);
        $before=Settings::revision();try {SetupAdmin::submit($i);$this->fail('review expected');}catch(\F3_Test_Die $e){$this->assertStringContainsString('Revisar serviços',$e->getMessage());}$this->assertSame($before,Settings::revision());
    }
}
