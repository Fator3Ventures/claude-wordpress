<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Ability, Connections, Options, Plugin, Records, Recovery};
use Fator3\McpGoogle\Storage\{Admission, Budget, Maintenance, State};
final class Release085Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;Connections::select('default');FakeHttp::reset();
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f)unlink($f);
        Options::set(Options::ENABLED,true);Plugin::register_abilities();
    }
    public function test_current_storage_is_independent_of_historical_markers(): void {
        foreach(['legacy','drain','copy','verify','failed','indexed'] as $phase) {
            Options::set('f3_mcp_google_storage',['phase'=>$phase]);
            $this->assertTrue(State::status()['ready']);
            $this->assertTrue(Admission::run('google/probe',static fn()=>['success'=>true])['success']);
        }
        $before=$GLOBALS['f3_test_options'];State::status();$this->assertSame($before,$GLOBALS['f3_test_options']);
    }
    public function test_no_old_record_fallback_or_conversion(): void {
        Options::set('f3_mcp_google_record_job_old',['status'=>'completed']);
        $this->assertNull(Records::get('job','old'));
        $this->assertTrue(Records::insert('job','new',['status'=>'completed']));
        $this->assertFalse(Records::insert('job','new',['status'=>'pending']));
        $this->assertSame('completed',Records::get('job','new')['status']);
        $this->assertSame(['new'],Records::ids('job'));
    }
    public function test_current_catalog_has_maintenance_without_retired_routes(): void {
        $this->assertNotNull(wp_get_ability('google/maintenance'));
        $this->assertNull(wp_get_ability('google/migrate-storage'));
        $this->assertNull(wp_get_ability('google/complete-transition'));
        $this->assertSame('write',wp_get_ability('google/maintenance')->get_meta()['fator3']['mode']);
        $this->assertSame(F3_MCP_GOOGLE_VERSION,wp_get_ability('google/maintenance')->get_meta()['fator3']['version']);
        $this->assertFalse(method_exists(\Fator3\McpGoogle\McpBridge::class,'prepare_registry'));
    }
    public function test_maintenance_is_bounded_and_reports_only_current_families(): void {
        Options::set(Maintenance::OPTION,['progress'=>['cron_legacy'=>['complete'=>true]],'legacy_archived'=>9]);
        $status=Maintenance::status();$this->assertArrayNotHasKey('cron_legacy',$status['progress']);
        $this->assertArrayNotHasKey('legacy_archived',$status);
        $r=Maintenance::run(new Budget(2));
        $this->assertLessThanOrEqual(2,$r['budget']['processed']);
        $this->assertSame('2.0.0',$r['maintenance_contract_version']);
        $this->assertSame(['cron_retention','cache_sql','cache_files'],array_keys($r['progress']));
    }
    public function test_recovery_blocks_new_maintenance_and_dispatch(): void {
        $this->assertTrue(Recovery::change(['action'=>'prepare'])['success']);
        $this->assertSame('f3_google_recovery_paused',wp_get_ability('google/maintenance')->execute([])['error_code']);
        $this->assertSame('f3_google_recovery_paused',Admission::dispatch_guard()->get_error_code());
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_unavailable_current_structure_refuses_work(): void {
        $GLOBALS['f3_test_record_read_fail']=true;$called=false;
        $r=Admission::run('google/probe',static function()use(&$called){$called=true;return ['success'=>true];});
        $this->assertSame('f3_google_storage_unavailable',$r['error_code']);$this->assertFalse($called);
    }
    public function test_missing_cron_schema_is_not_recreated_by_current_history(): void {
        $prior=$GLOBALS['wpdb'];
        $db=new class extends \F3_Test_Wpdb {
            public function get_results($sql,$format=null){if(str_starts_with($sql,'SHOW TABLES')){$this->last_error='';return [];}return parent::get_results($sql,$format);}
        };
        $GLOBALS['wpdb']=$db;
        try {
            $r=\Fator3\McpGoogle\Storage\CronStore::ensure_ready();
            $this->assertSame('f3_google_cron_storage_schema_missing',$r->get_error_code());
            $this->assertCount(0,array_filter($db->queries,static fn($q)=>str_starts_with($q,'CREATE TABLE')));
        } finally {$GLOBALS['wpdb']=$prior;}
    }
    public function test_current_scheduling_ignores_out_of_scope_observations_without_deleting_them(): void {
        \Fator3\McpGoogle\Automation\ExecutorSchedule::activate();
        $option=\Fator3\McpGoogle\Automation\Scheduling::OPTION;
        $stored=Options::get($option);$row=reset($stored['observations']);
        $row['hook']='retired_provider_hook';$row['state']='unconfirmed';
        $stored['observations']['out-of-scope']=$stored['active_errors']['out-of-scope']=$stored['last_errors']['out-of-scope']=$row;
        Options::set($option,$stored);$before=Options::get($option);
        $status=\Fator3\McpGoogle\Automation\Scheduling::status();
        $this->assertTrue($status['read_success']);
        $this->assertNotContains('retired_provider_hook',array_column($status['observations'],'hook'));
        $this->assertSame($before,Options::get($option));
        $result=\Fator3\McpGoogle\Automation\Scheduling::reconcile();$this->assertTrue($result['success']);
        $this->assertSame($row,Options::get($option)['active_errors']['out-of-scope']);
        \Fator3\McpGoogle\Automation\Scheduling::schedule(\Fator3\McpGoogle\Storage\Maintenance::HOOK,time()+500);
        $this->assertTrue(\Fator3\McpGoogle\Automation\Scheduling::status()['read_success']);
        $this->assertSame($row,Options::get($option)['observations']['out-of-scope']);
    }
}
