<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Cache,Options,Recovery,Connections};
use Fator3\McpGoogle\Storage\{Budget,Maintenance,Migration,CronStore};
use Fator3\McpGoogle\Automation\{CronHistory,Executor};
final class Release082Test extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        Connections::select('default');FakeHttp::reset();
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f) unlink($f);
    }
    public function test_pause_blocks_all_native_storage_entries(): void {
        $this->assertTrue(Recovery::change(['action'=>'prepare'])['success']);
        $before=$GLOBALS['f3_test_options'];
        $frame=CronHistory::begin(['default'],'native cli',true);
        $this->assertNotEmpty($frame['errors']);
        $this->assertNotEmpty(CronHistory::finish($frame,[])['observability_error']);
        foreach ([Executor::run(),\Fator3\McpGoogle\Storage\State::ensure_ready(),Maintenance::run(),CronHistory::reconcile('default')] as $r) {
            $this->assertFalse($r['success']);$this->assertSame('f3_google_recovery_paused',$r['error_code']);
        }
        \Fator3\McpGoogle\Audit::log('blocked-test');
        $this->assertSame('f3_google_recovery_paused',\Fator3\McpGoogle\Audit::last_failure()['error_code']);
        $this->assertFalse(Cache::set('f3_mcp_google_paused','value',50));
        $this->assertFalse(Cache::delete('f3_mcp_google_paused'));
        $this->assertFalse(Cache::maintain()['success']);
        $this->assertSame($before,$GLOBALS['f3_test_options']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_status_remains_readable_while_paused_without_recording_attempt(): void {
        Options::set(Maintenance::OPTION,['state'=>'complete','success'=>true,'remaining'=>false,'at'=>time()-120]);
        Recovery::change(['action'=>'prepare']);$before=$GLOBALS['f3_test_options'];
        $s=Maintenance::status();
        $this->assertSame('f3_google_recovery_paused',$s['blocked_by']);
        $this->assertTrue($s['read_success']);$this->assertGreaterThanOrEqual(120,$s['observation_age_seconds']);
        $this->assertSame($before,$GLOBALS['f3_test_options']);
    }
    public function test_cache_cleanup_reports_contention(): void {
        Cache::set('f3_mcp_google_lock_test',str_repeat('x',100100),300);
        $f=fopen(Cache::dir().'/site-1-lock.php','r+');flock($f,LOCK_EX);
        try { $r=Cache::maintain();$this->assertFalse($r['success']);$this->assertTrue($r['remaining']);$this->assertSame('f3_google_cache_busy',$r['error_code']); }
        finally { flock($f,LOCK_UN);fclose($f); }
    }
    public function test_cleanup_reports_a_symlink_without_following_it(): void {
        Cache::set('f3_mcp_google_symlink','value',30);
        $target=tempnam(sys_get_temp_dir(),'f3082');file_put_contents($target,'preserve');
        $link=Cache::dir().'/site-1-symlink.php';symlink($target,$link);
        try { $r=Cache::maintain(true);$this->assertFalse($r['success']);$this->assertSame('f3_google_cache_path',$r['error_code']);$this->assertSame('preserve',file_get_contents($target)); }
        finally {unlink($link);unlink($target);}
    }
    public function test_expired_file_is_a_miss_without_read_side_deletion(): void {
        $key='f3_mcp_google_expired082';Cache::set($key,str_repeat('x',100100),300);
        foreach(glob(Cache::dir().'/site-1-*.php') as $f) if (!str_ends_with($f,'lock.php')) {
            $raw=file_get_contents($f);$raw=preg_replace('/"expires":\d+/','"expires":1',$raw);file_put_contents($f,$raw);
            $this->assertFalse(Cache::get($key));$this->assertSame($raw,file_get_contents($f));
            $r=Cache::maintain();$this->assertTrue($r['success']);$this->assertFalse(file_exists($f));
        }
    }
    public function test_legacy_large_reads_do_not_refresh_expiration(): void {
        $key='f3_mcp_google_old082';$v=str_repeat('x',100100);set_transient($key,$v,10);
        $before=$GLOBALS['f3_test_transients'][$key];$this->assertSame($v,Cache::get($key));
        $this->assertSame($before,$GLOBALS['f3_test_transients'][$key]);
    }
    public function test_cache_small_large_small_transitions_and_delete_are_verified(): void {
        $key='f3_mcp_google_transition';
        foreach (['first',str_repeat('x',100200),'last'] as $value) {
            $this->assertTrue(Cache::set($key,$value,100));$this->assertSame($value,Cache::get($key));
        }
        $this->assertTrue(Cache::delete($key));$this->assertFalse(Cache::get($key));
        $this->assertTrue(Cache::delete($key));
    }
    public function test_unavailable_cache_health_persistence_is_explicit(): void {
        $GLOBALS['f3_test_write_fail']['f3_mcp_google_cache_health']=true;
        Cache::set('f3_mcp_google_health','v',100);
        $f=fopen(Cache::dir().'/site-1-lock.php','r+');flock($f,LOCK_EX);
        try {$this->assertFalse(Cache::set('f3_mcp_google_health','new',100));$this->assertSame('f3_google_cache_unavailable',Cache::last_error());}
        finally {flock($f,LOCK_UN);fclose($f);}
        $this->assertSame('v',Cache::get('f3_mcp_google_health'));
    }
    public function test_schema_creation_is_not_repeated_by_history(): void {
        CronStore::ensure_ready();$GLOBALS['wpdb']->queries=[];
        $f=CronHistory::begin(['default']);CronHistory::finish($f,[]);
        $this->assertCount(0,array_filter($GLOBALS['wpdb']->queries,static fn($q)=>str_starts_with($q,'CREATE TABLE')));
    }
    public function test_expiration_cleanup_shares_the_global_row_budget(): void {
        for($i=0;$i<5;$i++) Cache::set('f3_mcp_google_budget_'.$i,str_repeat('x',100100),30);
        foreach(glob(Cache::dir().'/site-1-*.php') as $f) if(!str_ends_with($f,'lock.php'))touch($f,time()-90000);
        $budget=new Budget(2);$r=Cache::maintain(false,$budget);
        $this->assertSame(2,$r['removed']);$this->assertTrue($r['remaining']);
        $this->assertSame(0,$budget->remaining());$this->assertSame('row_limit',$budget->result()['stop_reason']);
    }

    public function test_automatic_paths_share_one_budget_instance(): void {
        $budget=Budget::automatic();for($i=0;$i<100;$i++)$this->assertTrue($budget->claim());
        $this->assertSame($budget,Budget::automatic());
        $r=Maintenance::once();
        $this->assertLessThanOrEqual(100,$r['budget']['processed']);
        $this->assertFalse($budget->available());
    }
}
