<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{ContractSchema,CoreContext,CoreBinding};
require_once __DIR__.'/Support/CoreMeasurementDouble.php';
final class Release090CoreTest extends TestCase {
    public function test_delivered_core_fixtures_match_packaged_schemas_without_coercion(): void {
        foreach(glob(__DIR__.'/fixtures/core-measurement/snapshot-*.json') as $file){$r=json_decode(file_get_contents($file),true);$this->assertTrue(ContractSchema::valid($r,CoreContext::schema('snapshot')),basename($file));}
        $this->assertTrue(CoreContext::capabilities()['ok']);$this->assertTrue(CoreContext::snapshot()['ok']);
        $r=\F3_Test_Core::fixture('snapshot-configured');$r['data']['runtime_verified']='false';\F3_Test_Core::$snapshot=$r;
        $this->assertSame('unsupported',CoreContext::snapshot()['code']);
    }
    public function test_public_slots_preserve_provenance_and_distinct_meta_server_id(): void {
        \F3_Test_Core::$snapshot=\F3_Test_Core::fixture('snapshot-configured');$s=CoreContext::snapshot();
        $this->assertTrue($s['ok']);$this->assertSame('site_request',$s['data']['scope']);$this->assertFalse($s['data']['runtime_verified']);
        $slots=\Fator3\McpGoogle\TagManager\Diagnostic::slots($s);
        $this->assertSame($s['data']['slots']['meta']['effective']['fields']['server_pixel_id'],$slots['meta_server']);
        $this->assertSame($s['data']['slots']['ga4']['provenance'],CoreBinding::source()['provenance']);
    }
    public function test_catalog_order_is_owned_by_core_and_all_pages_require_same_revision(): void {
        \F3_Test_Core::$snapshot=\F3_Test_Core::fixture('snapshot-configured');
        $r=CoreContext::events(CoreContext::snapshot());$this->assertTrue($r['ok'],json_encode($r));$this->assertCount(22,$r['data']['items']);
        \F3_Test_Core::$events=static function($i){$r=\F3_Test_Core::fixture('events-complete');$r['data']['revision']='changed';return $r;};
        $this->assertSame('revision_conflict',CoreContext::events(CoreContext::snapshot())['code']);
    }
    public function test_repeated_catalog_item_and_missing_slot_are_rejected(): void {
        \F3_Test_Core::$events=static function($i){$r=\F3_Test_Core::fixture('events-complete');$r['data']['items'][1]=$r['data']['items'][0];return $r;};
        $this->assertSame('unsupported',CoreContext::events(CoreContext::snapshot())['code']);
        \F3_Test_Core::$snapshot=\F3_Test_Core::fixture('snapshot-default');unset(\F3_Test_Core::$snapshot['data']['slots']['clarity']);
        $this->assertSame('unsupported',CoreContext::snapshot()['code']);
    }
    public function test_local_context_reads_never_write_core_options_or_call_google(): void {
        $before=$GLOBALS['f3_test_options'];FakeHttp::reset();$s=CoreContext::snapshot();CoreContext::events($s);
        $this->assertSame($before,$GLOBALS['f3_test_options']);$this->assertSame(0,FakeHttp::count());
    }
    public function test_pagination_and_budget_refuse_incomplete_or_sensitive_catalog(): void {
        $s=CoreContext::snapshot();$r=CoreContext::events($s,20,5);$this->assertTrue($r['ok']);$this->assertCount(22,$r['data']['items']);
        $this->assertSame('catalog_budget_exceeded',CoreContext::events($s,1,5)['code']);
        \F3_Test_Core::$events=static function($i){$r=\F3_Test_Core::fixture('events-complete');$r['data']['items'][0]['parameters']['email']=['type'=>'string'];return $r;};
        $this->assertSame('unsupported',CoreContext::events($s)['code']);
    }

}
