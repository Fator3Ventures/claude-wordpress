<?php
/** 0.8.1 public behavior and storage boundary regressions; native SQL tests are separate. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Options,Connections,Cache,CoreBinding,Setup,Recovery};
use Fator3\McpGoogle\Automation\CronHistory;
use Fator3\McpGoogle\Storage\CronStore;
use PHPUnit\Framework\TestCase;
require_once __DIR__.'/Support/CoreMeasurementDouble.php';
final class Release081Test extends TestCase {
 protected function setUp():void {
  $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];Connections::select('default');FakeHttp::reset();
  foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[]as$f)unlink($f);
 }
 public function test_large_payload_bypasses_database_and_roundtrips():void {
  $key='f3_mcp_google_test_large';$value=['data'=>str_repeat('PRIVATE-MARKER-',10000),'utf8'=>'Métrica'];
  $this->assertTrue(Cache::set($key,$value,300));$this->assertArrayNotHasKey($key,$GLOBALS['f3_test_transients']);$this->assertSame($value,Cache::get($key));
  foreach(glob(Cache::dir().'/*.php')as$file){$this->assertStringStartsWith(Cache::HEADER,file_get_contents($file));$this->assertStringNotContainsString('PRIVATE-MARKER',file_get_contents($file));}
  $this->assertTrue(Cache::delete($key));$this->assertFalse(Cache::get($key));
 }
 public function test_serialized_boundary_and_shrink_remove_old_file():void {
  $key='f3_mcp_google_boundary';$large=str_repeat('x',100000);$small=str_repeat('s',99900);
  $this->assertTrue(Cache::set($key,$large,30));$this->assertSame($large,Cache::get($key));
  $this->assertTrue(Cache::set($key,$small,30));$this->assertSame($small,Cache::get($key));$this->assertLessThanOrEqual(100000,strlen(serialize($GLOBALS['f3_test_transients'][$key]['value'])));
 }
 public function test_file_capacity_and_expiration_are_bounded():void {
  for($i=0;$i<70;$i++)$this->assertTrue(Cache::set('f3_mcp_google_big_'.$i,str_repeat((string)($i%10),100100),300));
  $files=array_filter(glob(Cache::dir().'/site-1-*.php'),fn($f)=>!str_ends_with($f,'lock.php'));
  $this->assertLessThanOrEqual(Cache::MAX_FILES,count($files));
  foreach($files as$f)touch($f,time()-90000);Cache::maintain();
  $this->assertCount(0,array_filter(glob(Cache::dir().'/site-1-*.php'),fn($f)=>!str_ends_with($f,'lock.php')));
 }
 public function test_recovery_generation_invalidates_large_cache():void {
  $k='f3_mcp_google_generation';$this->assertTrue(Cache::set($k,str_repeat('z',100100),300));
  $s=Recovery::change(['action'=>'prepare']);$this->assertTrue($s['success']);$s=Recovery::status();
  $this->assertTrue(Recovery::change(['action'=>'resume','expected_generation'=>$s['generation'],'acknowledge_reconciled'=>true])['success']);$this->assertFalse(Cache::get($k));
 }
 public function test_corrupt_cache_is_a_miss_and_never_evaluated():void {
  Cache::set('f3_mcp_google_corrupt',str_repeat('x',100100),300);
  foreach(glob(Cache::dir().'/site-1-*.php')as$f)if(!str_ends_with($f,'lock.php'))file_put_contents($f,'<?php throw new Exception("must not execute");');
  $this->assertFalse(Cache::get('f3_mcp_google_corrupt'));
 }
 public function test_missing_and_invalid_core_ids_differ_with_gtm():void {
  \F3_Test_Core::configure('','GTM-ABC');
  $this->assertSame('f3_google_core_measurement_missing',CoreBinding::resolve()->get_error_code());
  \F3_Test_Core::configure('bad');$this->assertSame('f3_google_core_measurement_invalid',CoreBinding::resolve()->get_error_code());$this->assertSame(0,FakeHttp::count());
 }
 public function test_explicit_binding_does_not_require_core_discovery():void {
  \F3_Test_Core::configure('','GTM-ABC');
  $r=Setup::apply(['bindings'=>['ga_property_id'=>'123','ga_stream_id'=>'properties/123/dataStreams/456'],'validate_access'=>false]);
  $this->assertTrue($r['success']);$this->assertNull($r['core_source']);$this->assertSame('123',Options::get(Options::GA_DEFAULT_PROPERTY));$this->assertSame(0,FakeHttp::count());
 }
 public function test_new_observations_never_create_per_event_options():void {
  for($i=0;$i<5;$i++){$frame=CronHistory::begin(['default'],'wp cron event run',true);$r=CronHistory::finish($frame,[],'observed');$this->assertNull($r['observability_error']);}
  $this->assertCount(0,array_filter(array_keys($GLOBALS['f3_test_options']),fn($k)=>str_starts_with($k,'f3_mcp_google_cron_pass_')));
  $s=CronHistory::summary('default');$this->assertSame(5,$s['passagens_24h']['manual']);$this->assertNull($s['last_pass']);$this->assertNull($s['ultima_manual']['success']);
 }
 public function test_observation_removes_old_indexed_event_without_credentials():void {
  $id='00000000000000000001_old';$v=['at'=>time()-9*86400,'run_id'=>$id,'origem'=>'cli','scope'=>'wp_cli_invocation','success'=>null,'items'=>0];
  $this->assertTrue(CronStore::put('pass','default',$id,$v)['success']);
  $f=CronHistory::begin(['default'],'wp cron event run',true);CronHistory::finish($f,[],'observed');
  $this->assertFalse(CronStore::get('pass','default',$id)['exists']);
 }
}
