<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Ability,Delivery,Documentation,Options,Plugin,Records};
use Fator3\McpGoogle\Automation\{Jobs,Results};
use Fator3\McpGoogle\Admin\DiagnosticState;
final class Release010DeliveryTest extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_user_caps']=[];$GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;FakeHttp::reset();
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f)unlink($f);
        Options::set(Options::ENABLED,true);Plugin::register_abilities();
    }
    private function job(): array {return ['id'=>'delivery-test','task'=>'query','status'=>'completed','connection_id'=>'default','result'=>['collection'=>['complete'=>true],'rows'=>[]]];}
    public function test_each_section_is_recoverable_without_loss_after_externalization(): void {
        $job=$this->job();
        foreach(Results::PATHS as $field=>$path)Results::assign($job,$field,array_map(static fn($i)=>['id'=>$i,'payload'=>str_repeat("é🙂\"\\",1300)],range(0,111)));
        $expected=$job;
        foreach(Results::externalize($job) as $id=>$record)$this->assertTrue(Records::put('result',$id,$record)['success']);
        foreach(Results::PATHS as $field=>$path){
            $offset=0;$all=[];
            do{$view=Jobs::view($job,$offset,100,false,$field);$this->assertArrayNotHasKey('delivery_error',$view);$this->assertTrue($view['result']['collection']['complete']);
                $this->assertSame(Delivery::bytes($view),$view['delivery']['bytes']);$this->assertLessThanOrEqual(Delivery::JOB_BUDGET,Delivery::bytes($view));
                $page=Results::inline($view,$field);$all=array_merge($all,$page);$next=$view['delivery']['next_offset'];
                if($next!==null){$this->assertSame($offset+count($page),$next);$this->assertGreaterThan($offset,$next);}$offset=$next;
            }while($offset!==null);
            $this->assertSame(Results::inline($expected,$field),$all);
        }
    }
    public function test_default_omits_large_metadata_explicitly_and_preserves_small_metadata(): void {
        $job=$this->job();$job['result']['rows']=[['BR',0]];$job['result']['coverage']=array_fill(0,120,['state'=>'ok']);$job['result']['quality']['pages']=[['sampled'=>false]];
        $view=Jobs::view($job);$this->assertArrayNotHasKey('coverage',$view['result']);$this->assertSame(120,$view['delivery']['sections']['coverage']['omitted']);$this->assertSame($job['result']['quality'],$view['result']['quality']);
    }
    public function test_item_header_and_input_have_typed_non_advancing_errors(): void {
        $job=$this->job();$job['result']['rows']=[[str_repeat('x',1100000)]];
        $r=Jobs::view($job);$this->assertSame('item',$r['delivery_error']['delivery']['reason']);$this->assertNull($r['delivery_error']['delivery']['next_offset']);
        $job['result']['rows']=[];$job['result']['columns']=[str_repeat('x',1100000)];$r=Jobs::view($job);$this->assertSame('header',$r['delivery_error']['delivery']['reason']);
        unset($job['result']['columns']);$job['parameters']=['text'=>str_repeat('x',1100000)];$r=Jobs::view($job,0,20,true);$this->assertSame('header_or_input',$r['delivery_error']['delivery']['reason']);$this->assertArrayNotHasKey('parameters',Jobs::view($job));
    }
    public function test_unavailable_section_is_not_a_fabricated_empty_success(): void {
        $r=Jobs::view($this->job(),0,20,false,'quality_pages');$this->assertSame('f3_google_result_section',$r['delivery_error']['error_code']);
    }
    public function test_legacy_chunks_and_inspection_items_remain_readable(): void {
        $job=$this->job();unset($job['result']['rows']);$job['result_pages']=['rows'=>['count'=>2,'chunk_size'=>100]];Records::put('result',Results::chunk_id($job['id'],'rows',0),['rows'=>[['a'],['b']]]);
        $this->assertSame([['b']],Jobs::view($job,1,20)['result']['rows']);
        $job=['id'=>'inspect','task'=>'inspect-urls','status'=>'completed','result_count'=>2];Results::put('inspect',0,['url'=>'a']);Results::put('inspect',1,['url'=>'b']);$r=Jobs::view($job,0,1);$this->assertSame([['url'=>'a']],$r['results']);$this->assertSame(1,$r['page']['next_offset']);
    }
    public function test_direct_ability_limits_final_encoded_bytes_without_creating_job(): void {
        Ability::register('google/query','any',['callback'=>static fn()=>['success'=>true,'rows'=>[[str_repeat('🙂',100000)]],'collection'=>['complete'=>true]]]);
        $r=wp_get_ability('google/query')->execute([]);$this->assertFalse($r['success']);$this->assertSame('f3_google_result_delivery_limit',$r['error_code']);$this->assertFalse($r['recovery']['automatic_job_created']);$this->assertSame('query',$r['recovery']['task']);$this->assertSame([],Records::ids('job'));$this->assertSame([],FakeHttp::$requests);
    }
    public function test_delivery_failure_does_not_reclassify_applied_write(): void {
        $r=Delivery::guard(['success'=>true,'operation_outcome'=>'applied','job_id'=>'kept','data'=>str_repeat('x',1100000)],'google/run-job');$this->assertSame('applied',$r['operation_outcome']);$this->assertSame('kept',$r['job_id']);$this->assertFalse($r['retryable']);
    }
    public function test_documentation_roundtrips_full_catalog_with_hash_and_no_effects(): void {
        Options::set(Options::ENABLED,false);$before=[$GLOBALS['f3_test_options'],$GLOBALS['f3_test_transients']];
        $index=wp_get_ability('google/documentation')->execute([]);$this->assertTrue($index['success']);$this->assertSame(F3_MCP_GOOGLE_VERSION,$index['plugin_version']);
        foreach($index['documents'] as $doc){$offset=0;$text='';do{$r=wp_get_ability('google/documentation')->execute(['document'=>$doc['document'],'offset'=>$offset,'limit_bytes'=>65521,'expected_revision'=>$doc['revision']]);$this->assertTrue($r['success']);$this->assertTrue(mb_check_encoding($r['content'],'UTF-8'));$text.=$r['content'];$offset=$r['next_offset'];}while($offset!==null);$this->assertSame($doc['revision'],hash('sha256',$text));$this->assertSame($doc['bytes'],strlen($text));}
        $this->assertSame($before,[$GLOBALS['f3_test_options'],$GLOBALS['f3_test_transients']]);$this->assertSame([],FakeHttp::$requests);
    }
    public function test_documentation_confines_ids_revision_and_authorization(): void {
        foreach(['../wp-config.php','https://example.test/','/etc/passwd','README.md/../README.md'] as $id)$this->assertSame('f3_google_document_missing',Documentation::read(['document'=>$id])['error_code']);
        foreach([['offset'=>1],['expected_revision'=>str_repeat('0',64)]] as $args)$this->assertSame('f3_google_document_revision',Documentation::read(['document'=>'README.md']+$args)['error_code']);
        $GLOBALS['f3_test_caps']=false;$this->assertSame('f3_google_forbidden',Documentation::read([])['error_code']);
    }
    public function test_final_envelope_at_the_exact_byte_boundary(): void {
        $value=['success'=>true,'operation_outcome'=>'not_applicable','retryable'=>false,'payload'=>''];
        $value['payload']=str_repeat('x',Delivery::BUDGET-Delivery::bytes($value));
        $this->assertSame(Delivery::BUDGET,Delivery::bytes($value));$this->assertSame($value,Delivery::guard($value,'google/query'));
        $value['payload'].='x';$error=Delivery::guard($value,'google/query');$this->assertSame('f3_google_result_delivery_limit',$error['error_code']);$this->assertLessThan(2048,Delivery::bytes($error));
    }
    public function test_filtered_read_capability_cannot_grant_private_data(): void {
        add_filter('f3_mcp_google_capability',static fn()=>'read');$GLOBALS['f3_test_caps']=['read'=>true];
        $this->assertFalse(Options::authorized());$this->assertFalse(Options::user_authorized(1));$this->assertNotTrue(wp_get_ability('google/status')->check_permissions([]));
    }
    public function test_diagnostics_distinguish_failure_and_never_reclassify_old_cache(): void {
        $this->assertStringContainsString('descriptografia',DiagnosticState::identity(new \WP_Error('f3_google_crypto_decrypt','x'),[]));$this->assertStringContainsString('leitura',DiagnosticState::identity(new \WP_Error('f3_google_option_read','x'),[]));
        $this->assertStringContainsString('candidata salva',DiagnosticState::identity(new \WP_Error('missing','x'),['present'=>true,'readable'=>true]));
        $this->assertFalse(DiagnosticState::valid(['execution_success'=>true,'checks'=>[['name'=>'ga','status'=>'passed']]]));
        $this->assertTrue(DiagnosticState::valid(['passed'=>0,'failed'=>1,'skipped'=>0,'not_configured'=>0,'result_status'=>'failed','execution_success'=>true,'checked_at'=>'2026-10-16T00:00:00Z','revision'=>'a','checks'=>[['name'=>'ga','status'=>'failed']]]));
    }
}
