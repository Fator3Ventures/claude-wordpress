<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Distribution,Updater,Options};
final class Release090DistributionTest extends TestCase {
    protected function setUp(): void {$GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];$GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;FakeHttp::reset();}
    private function selection(string $origin): array {return ['contract'=>Distribution::CONTRACT,'package'=>Distribution::PACKAGE,'provider'=>Distribution::PACKAGE,'plugin'=>'wp-mcp-google-fator3/wp-mcp-google-fator3.php','available'=>true,'origin'=>$origin,'revision'=>str_repeat('a',64),'fallback_allowed'=>false];}
    public function test_absent_mcp_keeps_selected_mcp_owner_without_fallback(): void {
        Options::set(Distribution::RECEIPT,['contract'=>Distribution::CONTRACT,'packages'=>[Distribution::PACKAGE=>$this->selection('mcp')]]);
        $r=Updater::configure(['origin'=>['enabled'=>true,'manifest_url'=>'https://example.test/feed','allowed_hosts'=>['example.test']]]);$this->assertTrue($r['success']);
        $s=Distribution::selection();$this->assertSame('mcp',$s['origin']);$this->assertTrue(is_wp_error(Distribution::guard($s)));$this->assertFalse(Updater::check()['success']);$this->assertSame(0,FakeHttp::count());
        $file=tempnam(sys_get_temp_dir(),'google-manual');try{$this->assertSame(false,Updater::download(false,$file,null,['plugin'=>'wp-mcp-google-fator3/wp-mcp-google-fator3.php']));}finally{unlink($file);}
    }
    public function test_unknown_selection_and_explicit_local_consent_are_distinct(): void {
        $this->assertSame('unknown',Distribution::selection()['origin']);$this->assertSame('not_configured',Updater::check()['state']);
        Options::set(Updater::OPTION,['enabled'=>true,'manifest_url'=>'https://example.test/feed','allowed_hosts'=>['example.test']]);$this->assertFalse(Updater::check()['success']);
        $r=Updater::configure(['origin'=>['enabled'=>false]]);$this->assertTrue($r['success']);$s=Distribution::selection();$this->assertSame('provider',$s['origin']);$this->assertTrue(Distribution::guard($s));
        Options::set(Updater::OPTION,['enabled'=>true]);$this->assertTrue(is_wp_error(Distribution::guard($s)));$this->assertSame(0,FakeHttp::count());
    }
    public function test_invalid_receipt_does_not_authorize_selected_origin(): void {Options::set(Distribution::RECEIPT,['packages'=>[Distribution::PACKAGE=>$this->selection('provider')+['bad'=>true]]]);$s=Distribution::selection();$this->assertSame('provider',$s['origin']);Options::set(Distribution::RECEIPT,['packages'=>[Distribution::PACKAGE=>['origin'=>'provider']]]);$this->assertSame('unknown',Distribution::selection()['origin']);$this->assertSame(0,FakeHttp::count());}
}
