<?php
final class F3_Test_Isolation implements \PHPUnit\Runner\BeforeTestHook,\PHPUnit\Runner\AfterTestHook {
 public function executeBeforeTest(string $test): void {if(class_exists('F3_Test_Core',false)){F3_Test_Core::$snapshot=null;F3_Test_Core::$events=null;F3_Test_Core::$capabilities=null;}$GLOBALS['f3_test_cron_rows']=[]; $GLOBALS['f3_test_record_rows']=[]; $GLOBALS['f3_test_record_sequence']=0; $GLOBALS['f3_test_record_read_fail']=false; $GLOBALS['wpdb']=new F3_Test_Wpdb();
 if(class_exists('Fator3\\McpGoogle\\Storage\\Maintenance')){ $p=new \ReflectionProperty('Fator3\\McpGoogle\\Storage\\Maintenance','observed');$p->setAccessible(true);$p->setValue(null,[]); }
 foreach(['Budget'=>'automatic']as$class=>$field){if(class_exists('Fator3\\McpGoogle\\Storage\\'.$class)){$p=new \ReflectionProperty('Fator3\\McpGoogle\\Storage\\'.$class,$field);$p->setAccessible(true);$p->setValue(null,[]);}}
 if(class_exists('Fator3\\McpGoogle\\Automation\\ExecutorSchedule')) { $p=new \ReflectionProperty('Fator3\\McpGoogle\\Automation\\ExecutorSchedule','generations');$p->setAccessible(true);$p->setValue(null,[]); }
 self::clean();}
 public function executeAfterTest(string $test,float $time): void {self::clean();}
 private static function clean(): void {foreach(glob(WP_CONTENT_DIR.'/f3-google-cache/*.php')?:[]as$f)if(!is_link($f))unlink($f);}
}
