<?php
/** Explicit public-contract double; real Core is exercised in the native lab. */
final class F3_Test_Core {
    public static ?array $snapshot=null;
    public static $events=null;
    public static $capabilities=null;
    public static function fixture(string $name): array {return json_decode(file_get_contents(__DIR__.'/../fixtures/core-measurement/'.$name.'.json'),true);}
    public static function configure(string $measurement='',string $gtm=''): void {
        self::$snapshot=self::fixture($measurement===''?'snapshot-default':'snapshot-configured');
        foreach(['ga4'=>['measurement_id'=>$measurement],'gtm'=>['container_id'=>$gtm]] as $slot=>$values) {
            self::$snapshot['data']['slots'][$slot]['configured']['fields']=$values;
            self::$snapshot['data']['slots'][$slot]['effective']['fields']=$values;
            self::$snapshot['data']['slots'][$slot]['state']=reset($values)===''?'empty':($slot==='ga4'&&!preg_match('/^G-[A-Z0-9]+$/D',$measurement)?'invalid':'configured');
        }
        self::$snapshot['data']['revision']=hash('sha256',$measurement.'|'.$gtm);
    }
}
final class F3Base_Medicao_Contexto {
    public static function capabilities(): array {return F3_Test_Core::$capabilities??F3_Test_Core::fixture('capabilities');}
    public static function snapshot(): array {return F3_Test_Core::$snapshot??F3_Test_Core::fixture('snapshot-default');}
    public static function events(array $input=[]): array {
        if(is_callable(F3_Test_Core::$events))return (F3_Test_Core::$events)($input);
        $r=F3_Test_Core::fixture('events-complete');$offset=$input['offset']??0;$limit=$input['limit']??100;
        $r['data']['items']=array_slice($r['data']['items'],$offset,$limit);$next=$offset+count($r['data']['items']);
        $r['data']['complete']=$next>=$r['data']['total'];$r['data']['next_offset']=$r['data']['complete']?null:$next;
        return $r;
    }
}
