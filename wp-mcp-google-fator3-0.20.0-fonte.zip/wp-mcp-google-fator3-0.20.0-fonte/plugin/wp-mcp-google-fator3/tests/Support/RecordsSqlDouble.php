<?php
/** SQL-facing record fixture. Native MySQL tests cover engine transactions and concurrency. */
trait F3_Test_RecordsSql {
    private ?array $record_transaction = null;
    public function get_row($sql, $format) {
        if (str_contains($sql, 'f3_google_records')) return $this->record_rows($sql)[0] ?? null;
        $this->last_error='';
        preg_match("/option_name\\s*=\\s*'((?:[^'\\\\]|\\\\.)*)'/",$sql,$m);
        $key=stripslashes($m[1]??'');
        return array_key_exists($key,$GLOBALS['f3_test_options']) ? ['option_value'=>maybe_serialize($GLOBALS['f3_test_options'][$key])] : null;
    }
    private function record_rows($sql): array {
        $this->last_error='';
        if (!empty($GLOBALS['f3_test_record_read_fail'])) { $this->last_error='record read failure';return []; }
        $rows=array_values($GLOBALS['f3_test_record_rows']??[]);
        $where=explode(' WHERE ',$sql,2)[1]??'';
        foreach (['kind','record_id','connection_id','actor','state','task','target','mode','owner','generation'] as $field) {
            if (preg_match('/(?:^|AND )'.$field."='((?:[^'\\\\]|\\\\.)*)'/",$where,$m)) $rows=array_values(array_filter($rows,fn($r)=>(string)$r[$field]===stripslashes($m[1])));
            if (preg_match('/(?:^|AND )'.$field." IN \\(([^)]+)\\)/",$where,$m)) { preg_match_all("/'([^']*)'/",$m[1],$v);$rows=array_values(array_filter($rows,fn($r)=>in_array($r[$field],$v[1],true))); }
        }
        foreach (['sequence','due_at','created_at','expires_at','lease_until','generation'] as $field) {
            if (preg_match_all('/(?:^|AND )'.$field.'(<=|>|=)([0-9]+)/',$where,$matches,PREG_SET_ORDER)) foreach($matches as $m) $rows=array_values(array_filter($rows,fn($r)=>match($m[1]) {'<='=>$r[$field]<=(int)$m[2],'>'=>$r[$field]>(int)$m[2],default=>$r[$field]==(int)$m[2]}));
        }
        if (str_contains($where,"(owner='' OR lease_until<=")) $rows=array_values(array_filter($rows,fn($r)=>$r['owner']===''||$r['lease_until']<=time()));
        if (preg_match("/record_id LIKE '([^']+)'/",$where,$m)) { $prefix=rtrim(stripslashes($m[1]),'%');$rows=array_values(array_filter($rows,fn($r)=>str_starts_with($r['record_id'],$prefix))); }
        if (preg_match_all("/JSON_UNQUOTE\\(JSON_EXTRACT\\(payload, '([^']+)'\\)\\) = '([^']*)'/",$where,$ms,PREG_SET_ORDER)) foreach ($ms as $m) $rows=array_values(array_filter($rows,function($r)use($m){$v=json_decode($r['payload'],true);foreach(explode('.',substr($m[1],2)) as $k)$v=$v[$k]??null;return $v===stripslashes($m[2]);}));
        usort($rows,fn($a,$b)=>str_contains($sql,'ORDER BY due_at') ? [$a['due_at'],-$a['priority'],$a['sequence']]<=>[$b['due_at'],-$b['priority'],$b['sequence']] : $a['sequence']<=>$b['sequence']);
        if (str_contains($sql,'ORDER BY sequence DESC'))$rows=array_reverse($rows);
        preg_match('/LIMIT (\d+)/',$sql,$l);preg_match('/OFFSET (\d+)/',$sql,$o);
        return array_slice($rows,(int)($o[1]??0),(int)($l[1]??100000));
    }
    private function record_query($sql) {
        if ($sql==='START TRANSACTION') { $this->record_transaction=$GLOBALS['f3_test_record_rows']??[];return 0; }
        if ($sql==='COMMIT') { $this->record_transaction=null;return 0; }
        if ($sql==='ROLLBACK') { if($this->record_transaction!==null)$GLOBALS['f3_test_record_rows']=$this->record_transaction;$this->record_transaction=null;return 0; }
        if (!str_contains($sql,'f3_google_records'))return null;
        $this->last_error='';
        $args=$this->prepared[$sql]??[];
        if(str_starts_with($sql,'CREATE TABLE'))return 0;
        if(str_starts_with($sql,'INSERT IGNORE')) {
            preg_match('/\(([^)]+)\) VALUES/',$sql,$m);
            $r=array_combine(explode(',',$m[1]),$args);$key=$r['kind'].':'.$r['record_id'];
            if (!empty($GLOBALS['f3_test_write_fail'][$key]))return false;
            if(isset($GLOBALS['f3_test_record_rows'][$key]))return 0;
            $r+=['owner'=>'','lease_until'=>0,'generation'=>1,'sequence'=>++$GLOBALS['f3_test_record_sequence']];
            $GLOBALS['f3_test_record_rows'][$key]=$r;return 1;
        }
        $rows=$this->record_rows($sql);$n=0;
        foreach($rows as $r) {
            $key=$r['kind'].':'.$r['record_id'];
            if(!empty($GLOBALS['f3_test_write_fail'][$key]))return false;
            if(str_starts_with($sql,'DELETE')) { unset($GLOBALS['f3_test_record_rows'][$key]);++$n;continue; }
            $set=explode(' WHERE ',explode(' SET ',$sql,2)[1]??'',2)[0];
            preg_match_all("/(\\w+)='((?:[^'\\\\]|\\\\.)*)'/",$set,$sets,PREG_SET_ORDER);
            foreach($sets as $v)$r[$v[1]]=stripslashes($v[2]);
            if(preg_match('/lease_until=(\d+)/',$set,$m))$r['lease_until']=(int)$m[1];
            if(preg_match('/lease_until=GREATEST\(lease_until\+1,(\d+)\)/',$set,$m))$r['lease_until']=max($r['lease_until']+1,(int)$m[1]);
            if(str_contains($set,'generation=generation+1'))++$r['generation'];
            $GLOBALS['f3_test_record_rows'][$key]=$r;++$n;
        }
        return $n;
    }
    private function option_query($sql) {
        if(!str_contains($sql,$this->options))return null;
        $this->last_error='';$args=$this->prepared[$sql]??[];
        if(str_starts_with($sql,'INSERT IGNORE')) {
            [$key,$value]=$args;
            if(!empty($GLOBALS['f3_test_write_fail'][$key]))return false;
            if(array_key_exists($key,$GLOBALS['f3_test_options']))return 0;
            $GLOBALS['f3_test_options'][$key]=maybe_unserialize($value);return 1;
        }
        if(str_starts_with($sql,'DELETE') && count($args)===2) {
            [$key,$value]=$args;
            if (array_key_exists($key,$GLOBALS['f3_test_options']) && maybe_serialize($GLOBALS['f3_test_options'][$key])===$value) {unset($GLOBALS['f3_test_options'][$key]);return 1;}
        }
        return 0;
    }
}
