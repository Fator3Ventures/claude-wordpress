<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use PHPUnit\Framework\TestCase;
use Fator3\McpGoogle\{Auth\Credentials, Cache, Connections, Options, Plugin, Policy};
use Fator3\McpGoogle\Unified\{Calendar, Collection, Query};
use Fator3\McpGoogle\Automation\{Jobs, Operations};
final class Release090CollectionTest extends TestCase {
    protected function setUp(): void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;$GLOBALS['f3_test_user']=1;FakeHttp::reset();
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $f)unlink($f);
        Options::batch_verified([Options::ENABLED=>true,Options::GA_ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com'],[Options::OAUTH_CLIENT_SECRET=>'fixture',Options::OAUTH_REFRESH_TOKEN=>'fixture']);
        Cache::set(\Fator3\McpGoogle\Generic\Discovery::cache_key('search-console'),json_decode(file_get_contents(__DIR__.'/fixtures/discovery/searchconsole-v1.json'),true),600);
        FakeHttp::push('oauth2.googleapis.com/token',200,['access_token'=>'fixture','expires_in'=>3600]);Plugin::register_abilities();
    }
    private function input(string $connector='ga4'): array {return ['connector'=>$connector,'accounts'=>[$connector==='ga4'?'properties/123':'https://example.test/'],'metrics'=>[$connector==='ga4'?'sessions':'clicks'],'dimensions'=>[$connector==='ga4'?'country':'page'],'date_range'=>['from'=>'2026-01-01','to'=>'2026-01-12'],'collection'=>['mode'=>'complete','page_size'=>2]];}
    private function ga(array $rows,int $total,?array $metadata=null,string $account='123'): void {
        $r=['dimensionHeaders'=>[['name'=>'country']],'metricHeaders'=>[['name'=>'sessions','type'=>'TYPE_INTEGER']],'rowCount'=>$total,'rows'=>array_map(static fn($row)=>['dimensionValues'=>[['value'=>$row[0]]],'metricValues'=>[['value'=>(string)$row[1]]]],$rows)];
        if($metadata!==null)$r['metadata']=$metadata;FakeHttp::push('/properties/'.$account.':runReport',200,$r);
    }
    private function gsc(array $rows): void {FakeHttp::push('searchAnalytics/query',200,['rows'=>array_map(static fn($r)=>['keys'=>[$r[0]],'clicks'=>$r[1],'impressions'=>$r[1]*10,'ctr'=>0.1,'position'=>3],$rows),'responseAggregationType'=>'byPage']);}
    private function calls(): array {return array_values(array_filter(FakeHttp::$requests,static fn($r)=>str_contains($r['url'],':runReport')||str_contains($r['url'],'searchAnalytics/query')));}
    public function test_ga_collects_offsets_and_preserves_per_page_quality(): void {
        $this->ga([['BR',3],['US',0]],3,['timeZone'=>'America/Sao_Paulo','currencyCode'=>'BRL','subjectToThresholding'=>false]);$this->ga([['PT',7]],3,['timeZone'=>'Europe/Lisbon','currencyCode'=>'EUR','subjectToThresholding'=>true]);
        $r=Query::run($this->input());$this->assertTrue($r['success'],json_encode($r));$this->assertTrue($r['collection']['complete']);$this->assertSame([['BR',3],['US',0],['PT',7]],$r['rows']);
        $this->assertSame(2,json_decode($this->calls()[1]['body'],true)['offset']);$this->assertSame(['BRL','EUR'],array_column($r['quality']['pages'],'currency'));$this->assertNull($r['quality']['all_rows_guaranteed']);$this->assertSame('changes_observed',$r['quality']['snapshot_consistency']);$this->assertTrue(\Fator3\McpGoogle\ContractSchema::valid($r,\Fator3\McpGoogle\Unified\Quality::schema()));
    }
    public function test_full_gsc_page_with_no_local_matches_still_fetches_next_and_empty_page(): void {
        $this->gsc([['a',1],['b',2]]);$this->gsc([['c',10],['d',20]]);$this->gsc([]);
        $i=$this->input('search-console');$i['filters']=[['field'=>'clicks','operator'=>'gt','value'=>5]];$i['order_by']=[['field'=>'clicks','direction'=>'desc']];
        $r=Query::run($i);$this->assertTrue($r['collection']['complete'],json_encode($r));$this->assertSame([['d',20],['c',10]],$r['rows']);$this->assertSame(4,$r['collection']['rows_native']);$this->assertCount(3,$this->calls());$this->assertFalse($r['quality']['all_rows_guaranteed']);
    }
    public function test_cursor_replays_confirmed_pages_and_rejects_other_actor_or_query(): void {
        $this->ga([['BR',3],['US',4]],3);$this->ga([['PT',7]],3);
        $i=$this->input();$i['collection']['pages_per_pass']=1;$first=Query::run($i);$cursor=$first['collection']['continuation'];$this->assertNotEmpty($cursor,json_encode($first));
        $i['collection']['cursor']=$cursor;$GLOBALS['f3_test_user']=2;$r=Query::run($i);$this->assertSame('f3_google_collection_actor',$r['error_code']);$GLOBALS['f3_test_user']=1;
        $changed=$i;$changed['metrics']=['activeUsers'];$this->assertSame('f3_google_collection_changed',Query::run($changed)['error_code']);
        $r=Query::run($i);$this->assertTrue($r['collection']['complete']);$this->assertCount(3,$r['rows']);$this->assertCount(2,$this->calls());
        $again=Query::run($i);$this->assertSame($r['rows'],$again['rows']);$this->assertCount(2,$this->calls());
    }
    public function test_revocation_between_pages_prevents_disclosing_cached_result(): void {
        $this->ga([['BR',3],['US',4]],3);$i=$this->input();$i['collection']['pages_per_pass']=1;$r=Query::run($i);$i['collection']['cursor']=$r['collection']['continuation'];
        Options::set(Policy::OPTION,['mode'=>'restricted','services'=>['ga'=>['resources'=>['properties/999']]]]);$r=Query::run($i);$this->assertFalse($r['success']);$this->assertArrayNotHasKey('rows',$r);$this->assertCount(1,$this->calls());
    }
    public function test_failure_in_second_property_is_structured_and_does_not_drop_slice(): void {
        $this->ga([['BR',3]],1);FakeHttp::push('/properties/456:runReport',403,['error'=>['code'=>403,'message'=>'Denied']]);
        $i=$this->input();$i['accounts'][]='properties/456';$r=Query::run($i);
        $this->assertTrue($r['success'],json_encode($r));$this->assertFalse($r['collection']['complete']);$this->assertSame(1,$r['collection']['failed_slices']);$this->assertCount(2,$r['coverage']);$this->assertSame('failed',$r['coverage'][1]['status']);
    }
    public function test_row_and_byte_budgets_do_not_report_completion_or_drop_rows_silently(): void {
        $this->ga([['BR',3],['US',4]],3);$i=$this->input();$i['collection']['max_rows']=2;$r=Query::run($i);$this->assertSame('row_budget',$r['collection']['stop_reason']);$this->assertFalse($r['collection']['complete']);$this->assertFalse($r['collection']['resumable']);
        $this->ga([[str_repeat('x',2000),3]],1);$i['collection']['max_bytes']=1024;$r=Query::run($i);$this->assertSame('byte_budget',$r['collection']['stop_reason']);$this->assertSame(0,$r['row_count']);
    }
    public function test_checkpoint_commits_page_and_offset_as_one_resume_state(): void {
        $this->ga([['BR',3],['US',4]],3);$this->ga([['PT',7]],3);$i=$this->input();$saved=null;
        try{Collection::collect($i,null,static function($next)use(&$saved){$saved=$next;if($next['pages']===1)throw new \RuntimeException('simulated process interruption after commit');return true;},true);$this->fail('Interruption expected');}catch(\RuntimeException $e){$this->assertSame(1,$saved['pages']);}
        $r=Collection::collect($i,$saved,static function($next)use(&$saved){$saved=$next;return true;},true);$this->assertTrue($r['collection']['complete']);$this->assertCount(3,$r['rows']);$this->assertCount(2,$this->calls());
    }
    public function test_query_job_resumes_with_confirmed_progress_and_result_actor_guard(): void {
        $this->ga([['BR',3],['US',4]],3);$this->ga([['PT',7]],3);$i=$this->input();$i['collection']['pages_per_pass']=1;
        $created=Jobs::create(['task'=>'query','parameters'=>$i]);$this->assertTrue($created['success'],json_encode($created));$id=$created['job_id'];$r=Jobs::run($id);$this->assertSame('pending',$r['job']['status'],json_encode($r));
        $job=\Fator3\McpGoogle\Records::get('job',$id);$job['run_after']=0;\Fator3\McpGoogle\Records::put('job',$id,$job);
        $r=Jobs::run($id);$this->assertSame('completed',$r['job']['status'],json_encode($r));$this->assertCount(3,$r['job']['result']['rows']);$this->assertCount(2,$this->calls());
        $GLOBALS['f3_test_user']=2;$this->assertSame('f3_google_collection_actor',Operations::action('get-job',['job_id'=>$id])['error_code']);
    }
    public function test_iso_week_crosses_calendar_year_and_partial_month_never_expands(): void {
        $weeks=Calendar::intervals(['from'=>'2020-12-28','to'=>'2021-01-10'],['period'=>'iso_week']);$this->assertSame(['2020-W53','2021-W01'],array_column($weeks,'label'));
        $month=Calendar::intervals(['from'=>'2026-10-01','to'=>'2026-10-12'],['period'=>'month']);$this->assertSame('2026-10-12',$month[0]['to']);$this->assertTrue($month[0]['partial']);
        $this->assertTrue(is_wp_error(Calendar::intervals(['from'=>'2026-10-01','to'=>'2026-10-12'],['period'=>'month','partial_periods'=>'reject'])));
    }
    public function test_calendar_asks_source_for_each_interval_instead_of_summing_unique_users(): void {
        $i=$this->input();$i['dimensions']=[];$i['metrics']=['activeUsers'];$i['date_range']=['from'=>'2026-09-29','to'=>'2026-10-02'];$i['calendar']=['period'=>'month'];
        foreach([17,11] as $value)FakeHttp::push(':runReport',200,['metricHeaders'=>[['name'=>'activeUsers','type'=>'TYPE_INTEGER']],'rowCount'=>1,'rows'=>[['metricValues'=>[['value'=>(string)$value]]]]]);
        $r=Query::run($i);$this->assertSame([['2026-09','2026-09-29','2026-09-30',17],['2026-10','2026-10-01','2026-10-02',11]],$r['rows'],json_encode($r));$this->assertSame('native_per_interval',$r['quality']['aggregation']);
    }
    public function test_absent_metadata_is_unknown_and_changed_total_is_observed(): void {
        $this->ga([['BR',1],['US',2]],3);$this->ga([['PT',3]],4);$this->ga([],3);
        $r=Query::run($this->input());$this->assertTrue($r['collection']['complete']);$this->assertFalse($r['quality']['pages'][0]['sampling_known']);$this->assertNull($r['quality']['pages'][0]['currency']);$this->assertSame('changes_observed',$r['quality']['snapshot_consistency']);
    }
    public function test_calendar_ctr_uses_counts_and_preserves_native_zero_and_missing(): void {
        $i=$this->input('search-console');$i['calendar']=['period'=>'month'];$i['metrics']=['clicks','impressions','ctr','position'];$i['collection']['page_size']=10;
        FakeHttp::push('searchAnalytics/query',200,['rows'=>[
            ['keys'=>['positive'],'clicks'=>2,'impressions'=>4,'ctr'=>0.9,'position'=>3],
            ['keys'=>['zero'],'clicks'=>0,'impressions'=>0,'ctr'=>0,'position'=>0],
            ['keys'=>['missing'],'clicks'=>0,'impressions'=>0,'position'=>null]]]);
        $r=Query::run($i);$this->assertTrue($r['collection']['complete'],json_encode($r));$this->assertSame([0.5,0,null],array_column($r['rows'],6));$this->assertSame([3,0,null],array_column($r['rows'],7));$this->assertSame('final',$r['quality']['pages'][0]['requested_data_state']);
    }
    public function test_expired_cursor_is_unavailable_without_another_source_request(): void {
        $this->ga([['BR',1],['US',2]],3);$i=$this->input();$i['collection']['pages_per_pass']=1;$r=Query::run($i);$cursor=$r['collection']['continuation'];
        Cache::delete('f3_mcp_google_collection_'.$cursor);$i['collection']['cursor']=$cursor;$r=Query::run($i);$this->assertSame('f3_google_collection_expired',$r['error_code']);$this->assertCount(1,$this->calls());
    }

    public function test_quota_error_keeps_offset_and_authorized_continuation(): void {
        FakeHttp::push(':runReport',429,['error'=>['code'=>429,'message'=>'Fixture quota']],['retry-after'=>'120']);$i=$this->input();$r=Query::run($i);
        $this->assertSame('source_retry',$r['collection']['stop_reason'],json_encode($r));$this->assertFalse($r['collection']['complete']);$this->assertSame(0,$r['coverage'][0]['offset']);
        $i['collection']['cursor']=$r['collection']['continuation'];$this->ga([['BR',2]],1);$r=Query::run($i);$this->assertTrue($r['collection']['complete']);$this->assertSame([['BR',2]],$r['rows']);
    }
    public function test_civil_iso_week_does_not_gain_or_lose_days_at_dst_boundary(): void {
        $r=Calendar::intervals(['from'=>'2026-03-02','to'=>'2026-03-15'],['period'=>'iso_week']);$this->assertSame(['2026-03-02','2026-03-09'],array_column($r,'from'));$this->assertSame(['2026-03-08','2026-03-15'],array_column($r,'to'));
    }

}
