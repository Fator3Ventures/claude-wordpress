<?php
/** Requests 37/38: synthetic provider tests; public opaque client and configuration. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{
    Audit,Catalog,Connections,Options,Plugin,Records,Settings
};
use Fator3\McpGoogle\Integration\{
    Context,Ga4ServiceApi as Api,Ga4ConsumerClient,Ga4Quota,ServiceApi
};
use Fator3\McpGoogle\Automation\Executor;
use PHPUnit\Framework\TestCase;
final class Release020Test extends TestCase {
    private array $cfg;
    private Ga4ConsumerClient $client;
    protected function setUp():void {
        $GLOBALS['f3_test_options']=$GLOBALS['f3_test_transients']=$GLOBALS['f3_test_write_fail']=[];
        $GLOBALS['f3_test_caps']=true;
        $GLOBALS['f3_test_user']=1;
        $GLOBALS['f3_test_user_caps']=[1=>true];
        Connections::select('default');
        FakeHttp::reset();
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $p)unlink($p);
        $r=new \ReflectionProperty(Api::class,'consumers');
        $r->setAccessible(true);
        $r->setValue(null,[]);
        Options::batch_verified([Options::ENABLED=>true,Options::GA_ENABLED=>true,Options::AUTH_MODE=>'oauth',Options::OAUTH_CLIENT_ID=>'test.apps.googleusercontent.com',Connections::SERVICES=>['ga'=>'read']],[Options::OAUTH_CLIENT_SECRET=>'fixture-secret',Options::OAUTH_REFRESH_TOKEN=>'fixture-refresh']);
        $this->cfg=['property'=>'properties/123','revision'=>'core-ga4-1','ready'=>true];
        $this->client=Api::register_consumer('base-site-core-fator3','1.56.0',Api::CONTRACT,fn()=>$this->cfg);
        $r=$this->grant(true);
        $this->assertTrue($r['success'],json_encode($r));
        Plugin::register_abilities();
    }
    protected function tearDown():void {
        $GLOBALS['f3_test_caps']=true;
        $GLOBALS['f3_test_user']=1;
        $GLOBALS['f3_test_user_caps']=[];
        Connections::select('default');
        foreach(glob(WP_CONTENT_DIR.'/f3-google-state/*')?:[] as $p)unlink($p);
    }
    private function grant(bool $enabled):array{
        return ServiceApi::configure(['contract'=>Api::CONTRACT,'property'=>'properties/123','consumer_id'=>'base-site-core-fator3','enabled'=>$enabled,'expected_revision'=>Settings::revision()]);
    }
    private function input(array $x=[]):array{
        return array_replace(['contract_version'=>'1.0.0','property'=>'properties/123','consumer_revision'=>$this->cfg['revision'],'start_date'=>'2026-09-01','end_date'=>'2026-09-30','dimensions'=>['date','pagePath'],'metrics'=>['screenPageViews'],'run_id'=>'test-020','trigger'=>'cli','budget_ms'=>20000],$x);
    }
    private function raw(int $total=1,int $remaining=100):array{
        return ['dimensionHeaders'=>[['name'=>'date'],['name'=>'pagePath']],'metricHeaders'=>[['name'=>'screenPageViews','type'=>'TYPE_INTEGER']],'rowCount'=>$total,'rows'=>[['dimensionValues'=>[['value'=>'20260901'],['value'=>'/fixture-not-to-persist']],'metricValues'=>[['value'=>'12']]]],'metadata'=>['timeZone'=>'America/Sao_Paulo','currencyCode'=>'BRL','samplingMetadatas'=>[['samplesReadCount'=>'5','samplingSpaceSize'=>'10']],'dataLossFromOtherRow'=>true],'propertyQuota'=>['tokensPerDay'=>['consumed'=>2,'remaining'=>1000],'tokensPerHour'=>['consumed'=>2,'remaining'=>$remaining]]];
    }
    private function response(?array $raw=null):void{
        FakeHttp::push('/token',200,['access_token'=>'fixture-token','expires_in'=>3600]);
        FakeHttp::push(':runReport',200,$raw??$this->raw());
    }
    public function test_read_without_user_with_quality_actor_and_no_archive():void{
        $GLOBALS['f3_test_user']=0;
        $GLOBALS['f3_test_caps']=false;
        $this->response();
        $r=$this->client->query($this->input());
        $this->assertTrue($r['success'],json_encode($r));
        $this->assertTrue($r['audit_success']);
        $this->assertSame('BRL',$r['quality']['currencyCode']);
        $this->assertTrue($r['quality']['dataLossFromOtherRow']);
        $this->assertFalse($r['quality']['finalization_guaranteed']);
        $this->assertSame(2,$r['quota']['property_quota']['tokensPerHour']['consumed']);
        $this->assertTrue(json_decode(FakeHttp::last()['body'],true)['returnPropertyQuota']);
        $audit=Audit::recent(30);
        $end=array_values(array_filter($audit,fn($e)=>$e['action']==='plugin:ga4.report.end'))[0];
        $this->assertSame('base-site-core-fator3',$end['actor']['id']);
        $this->assertSame(0,$end['user']);
        $this->assertStringNotContainsString('/fixture-not-to-persist',json_encode($GLOBALS['f3_test_options']));
        $this->assertStringNotContainsString('/fixture-not-to-persist',json_encode($audit));
        $this->assertNull(Context::current());
    }
    public function test_cursor_query_binding_pagination_and_regrant():void{
        $this->response($this->raw(2));
        $a=$this->client->query($this->input(['limit'=>1]));
        $this->assertTrue($a['success'],json_encode($a));
        $this->assertNotNull($a['next_cursor']);
        $bad=$this->client->query($this->input(['limit'=>1,'cursor'=>$a['next_cursor'],'end_date'=>'2026-09-29']));
        $this->assertSame('f3_google_consumer_cursor',$bad['error_code']);
        FakeHttp::push(':runReport',200,$this->raw(2));
        $r=$this->client->query($this->input(['limit'=>1,'cursor'=>$a['next_cursor']]));
        $this->assertTrue($r['success'],json_encode($r));
        $this->assertSame('1',json_decode(FakeHttp::last()['body'],true)['offset']);
        $this->assertNull($r['next_cursor']);
        $this->grant(false);
        $this->grant(true);
        $this->assertSame('f3_google_consumer_cursor',$this->client->query($this->input(['limit'=>1,'cursor'=>$a['next_cursor']]))['error_code']);
    }
    public function test_zero_quota_denies_next_request_without_http():void{
        $this->response($this->raw(1,0));
        $r=$this->client->query($this->input());
        $this->assertTrue($r['success'],json_encode($r));
        $n=FakeHttp::count();
        $r=$this->client->query($this->input());
        $this->assertSame('f3_google_ga4_quota',$r['error_code']);
        $this->assertGreaterThan(0,$r['retry_after_ms']);
        $this->assertSame($n,FakeHttp::count());
    }
    public function test_429_never_retries():void{
        FakeHttp::push('/token',200,['access_token'=>'fixture-token','expires_in'=>3600]);
        FakeHttp::push(':runReport',429,['error'=>['code'=>429,'status'=>'RESOURCE_EXHAUSTED','message'=>'quota']]);
        $r=$this->client->query($this->input());
        $this->assertFalse($r['success']);
        $this->assertSame(2,FakeHttp::count());
        $this->assertGreaterThanOrEqual(3600000,$r['retry_after_ms']);
        $this->assertSame('f3_google_ga4_quota',$this->client->query($this->input())['error_code']);
    }
    public function test_revocation_property_and_grantor():void{
        $this->grant(false);
        $r=$this->client->query($this->input());
        $this->assertSame('f3_google_consumer_unauthorized',$r['error_code']);
        $this->assertTrue($r['audit_success']);
        $this->grant(true);
        $this->cfg['property']='properties/456';
        $this->assertSame('f3_google_consumer_unauthorized',$this->client->query($this->input(['property'=>'properties/456']))['error_code']);
        $this->cfg['property']='properties/123';
        $GLOBALS['f3_test_user_caps'][1]=false;
        $this->assertSame('f3_google_consumer_unauthorized',$this->client->query($this->input())['error_code']);
        $this->assertSame(0,FakeHttp::count());
    }
    public function test_revocation_during_http_discards_rows():void{
        $this->response();
        $hook=static function($pre,$args,$url){
            if(str_ends_with($url,':runReport'))Options::set(Api::GRANTS,[]);
            return $pre;
        };
        add_filter('pre_http_request',$hook,20,3);
        try{
            $r=$this->client->query($this->input());
            $this->assertFalse($r['success']);
            $this->assertArrayNotHasKey('rows',$r);
            $this->assertTrue($r['remote_dispatched']);
        }
        finally{
            remove_filter('pre_http_request',$hook,20);
        }
    }
    public function test_filter_body_and_forged_client():void{
        $f=['filter'=>['fieldName'=>'pagePath','stringFilter'=>['matchType'=>'BEGINS_WITH','value'=>'/blog']]];
        $this->response();
        $r=$this->client->query($this->input(['dimension_filter'=>$f]));
        $this->assertTrue($r['success'],json_encode($r));
        $this->assertSame($f,json_decode(FakeHttp::last()['body'],true)['dimensionFilter']);
        $this->assertSame('f3_google_consumer_unregistered',(new Ga4ConsumerClient())->query($this->input())['error_code']);
    }
    /** @dataProvider invalid */
    public function test_invalid_input_no_http(array $change):void{
        $r=$this->client->query($this->input($change));
        $this->assertFalse($r['success']);
        $this->assertSame(0,FakeHttp::count());
    }
    public static function invalid():array{
        return [[['budget_ms'=>0]],[['budget_ms'=>20001]],[['contract_version'=>'2']],[['property'=>'123']],[['start_date'=>'2026-02-30']],[['end_date'=>'2026-08-01']],[['start_date'=>'2024-01-01']],[['dimensions'=>['date','date']]],[['metrics'=>[]]],[['dimension_filter'=>['orGroup'=>['expressions'=>[]]]]],[['cursor'=>'tampered']],[['url'=>'https://evil.test']],[['limit'=>5001]]];
    }
    public function test_unlimited_defaults_order_and_mcp_writer():void{
        foreach([Options::AUDIT_RETENTION,Options::JOB_DETAIL_DAYS,Options::JOB_SUMMARY_DAYS]as $key)$this->assertSame(0,Options::limit($key));
        $r=Catalog::configure(['job_detail_days'=>0,'job_summary_days'=>30,'expected_revision'=>Settings::revision()]);
        $this->assertSame('f3_google_retention_order',$r['error_code']);
        $r=Catalog::configure(['audit_retention'=>0,'job_detail_days'=>365,'job_summary_days'=>0,'expected_revision'=>Settings::revision()]);
        $this->assertTrue($r['success'],json_encode($r));
        $this->assertSame(0,Options::retention_expires(Options::JOB_SUMMARY_DAYS));
        $this->assertTrue(\Fator3\McpGoogle\Configuration::definitions()['audit_retention']['mcp_mutable']);
    }
    public function test_audit_keeps_more_than_old_default():void{
        for($n=0;$n<1003;$n++)Audit::log('fixture:retention','-',['n'=>$n]);
        $this->assertGreaterThan(1000,count(\Fator3\McpGoogle\Storage\Repository::select('audit',[],1100)));
    }
    public function test_cleanup_preserves_old_expired_rows():void{
        $job=['id'=>'legacy020','status'=>'completed','connection_id'=>'default','created_at'=>1,'updated_at'=>1,'expires_at'=>2];
        Records::put('job','legacy020',$job);
        Records::put('result','legacy020_row',['task'=>'legacy020','value'=>'preserve']);
        Records::put('summary','summary020',['expires_at'=>2,'connection_id'=>'default','status'=>'completed']);
        Records::put('dedupe','dedupe020',['expires_at'=>2,'connection_id'=>'default']);
        $this->assertSame([],Executor::cleanup(['dry_run'=>true])['job_candidates']);
        $r=Executor::cleanup(['dry_run'=>false]);
        $this->assertTrue($r['success'],json_encode($r));
        $this->assertSame($job,Records::get('job','legacy020'));
        foreach([['result','legacy020_row'],['summary','summary020'],['dedupe','dedupe020']]as [$kind,$id])$this->assertNotNull(Records::get($kind,$id));
    }
    public function test_identity_change_requires_regrant():void{
        Options::set(Options::OAUTH_CLIENT_ID,'changed.apps.googleusercontent.com');
        $r=$this->client->query($this->input());
        $this->assertSame('f3_google_consumer_unauthorized',$r['error_code']);
        $this->assertSame(0,FakeHttp::count());
        $this->assertTrue($this->grant(true)['success']);
        $this->response();
        $this->assertTrue($this->client->query($this->input())['success']);
    }
    public function test_property_lock_serializes_other_consumers():void{
        $lock=\Fator3\McpGoogle\Lock::acquire('ga4-property:properties/123',30);
        try{
            $r=$this->client->query($this->input());
            $this->assertFalse($r['success']);
            $this->assertTrue($r['retryable']);
            $this->assertSame(0,FakeHttp::count());
        }
        finally{
            \Fator3\McpGoogle\Lock::release($lock);
        }
    }
    public function test_quota_write_failure_prevents_dispatch():void{
        $key=Ga4Quota::key('properties/123');
        $GLOBALS['f3_test_write_fail'][$key]=true;
        try{
            $r=$this->client->query($this->input());
            $this->assertSame('f3_google_quota_storage',$r['error_code']);
            $this->assertSame(0,FakeHttp::count());
        }
        finally{
            unset($GLOBALS['f3_test_write_fail'][$key]);
        }
    }
    public function test_audit_read_failure_prevents_dispatch():void{
        $GLOBALS['f3_test_record_read_fail']=true;
        try{
            $r=$this->client->query($this->input());
            $this->assertSame('f3_google_audit_persistence',$r['error_code']);
            $this->assertSame(0,FakeHttp::count());
        }
        finally{
            $GLOBALS['f3_test_record_read_fail']=false;
        }
    }
    public function test_missing_quota_or_malformed_rows_never_advance():void{
        foreach(['quota','rows']as $mode){
            Options::delete(Ga4Quota::key('properties/123'));
            $raw=$this->raw(2);
            if($mode==='quota')unset($raw['propertyQuota']);
            else $raw['rows'][0]['metricValues']=[];
            $this->response($raw);
            $r=$this->client->query($this->input(['limit'=>1]));
            $this->assertFalse($r['success']);
            $this->assertArrayNotHasKey('next_cursor',$r);
            FakeHttp::reset();
        }
    }
    public function test_context_rejects_write_and_wrong_report():void{
        $ctx=['contract'=>Api::CONTRACT,'property'=>'properties/123','body'=>['limit'=>'1']];
        Context::run($ctx,function(){
            foreach([['GET','https://analyticsdata.googleapis.com/v1beta/properties/123:runReport','read'],['POST','https://analyticsdata.googleapis.com/v1beta/properties/456:runReport','read'],['POST','https://analyticsdata.googleapis.com/v1beta/properties/123:runReport','write']]as [$method,$url,$mode])$this->assertInstanceOf(\WP_Error::class,Context::guard($method,$url,['limit'=>'1'],['mode'=>$mode]));
            });
    }
    public function test_revocation_with_unregistered_consumer_and_stale_revision():void{
        $rev=Settings::revision();
        $this->assertTrue($this->grant(false)['success']);
        $bad=ServiceApi::configure(['contract'=>Api::CONTRACT,'consumer_id'=>'base-site-core-fator3','property'=>'properties/123','enabled'=>true,'expected_revision'=>$rev]);
        $this->assertFalse($bad['success']);
        $this->grant(true);
        $r=new \ReflectionProperty(Api::class,'consumers');
        $r->setAccessible(true);
        $r->setValue(null,[]);
        $this->assertTrue($this->grant(false)['success']);
    }
}
