<?php
/** Isolated producer fixtures test the actual consumer and response mapper. */
namespace Fator3\McpGoogle {
    final class Connections { public static function id(){return 'default';} public static function run($id,$f){return $f();} }
    final class Gate { public static function check($service){return null;} }
    final class Operation { public static function profile($service,$mode){return null;} }
}
namespace {
    define('ABSPATH',__DIR__.'/');
    class WP_Error {
        public function __construct(private $code,private $message){}
        public function get_error_code(){return $this->code;}
        public function get_error_message(){return $this->message;}
        public function get_error_data(){return null;}
    }
    function is_wp_error($value){return $value instanceof WP_Error;}
    function fixture013($name){return json_decode(file_get_contents(__DIR__.'/fixtures/core-conversions/'.$name.'.json'),true);}
    class F3Base_Conversoes_Contexto {
        public static $value;public static int $snapshots=0;public static bool $throw=false;
        public static function capabilities(){return fixture013('capabilities');}
        public static function snapshot($input){++self::$snapshots;if(self::$throw)throw new RuntimeException('PRIVATE_EXCEPTION');return self::$value;}
    }
    $root=$argv[1]??dirname(__DIR__);
    foreach(['ContractSchema','CoreConversions','Response','ConversionContext'] as $class)require $root.'/includes/'.$class.'.php';
    use Fator3\McpGoogle\{ConversionContext,CoreConversions};
    $passed=[];$failed=[];
    function check013($name,$ok){global $passed,$failed;if($ok)$passed[]=$name;else $failed[]=$name;}
    $base=fixture013('material-enabled-ids-empty');
    F3Base_Conversoes_Contexto::$value=CoreConversions::failure('revision_conflict');
    $r=ConversionContext::read(['expected_revision'=>str_repeat('0',64)]);
    check013('SDK conflict is explicitly true',($r['conflict']??null)===true);
    check013('SDK conflict is not retryable',($r['retryable']??null)===false);
    check013('SDK error and null envelope preserved',$r['error_code']==='f3_google_core_conversion_revision_conflict'&&$r['core_conversion_context']===CoreConversions::failure('revision_conflict'));
    check013('No revision fabricated for SDK error',!array_key_exists('current_revision',$r));
    check013('No second snapshot on SDK conflict',F3Base_Conversoes_Contexto::$snapshots===1);
    F3Base_Conversoes_Contexto::$value=$base;
    $before=F3Base_Conversoes_Contexto::$snapshots;
    $r=ConversionContext::read(['expected_revision'=>str_repeat('0',64)]);
    check013('Defensive mismatch is a conflict',($r['conflict']??null)===true&&!$r['success']);
    check013('Defensive mismatch uses validated revision',($r['current_revision']??null)===$base['data']['revision']);
    check013('Defensive error retains exact producer envelope',$r['core_conversion_context']===CoreConversions::failure('revision_conflict'));
    check013('Defensive mismatch makes only one snapshot',F3Base_Conversoes_Contexto::$snapshots===$before+1);
    foreach([[],['expected_revision'=>$base['data']['revision']]] as $input){
        $r=ConversionContext::read($input);
        check013('Valid read '.count($input),$r['success']&&$r['core_conversion_context']===$base&&empty($r['conflict'])&&!isset($r['current_revision']));
    }
    foreach(['invalid_input','unsupported','unreadable','not_authorized'] as $code){
        F3Base_Conversoes_Contexto::$value=CoreConversions::failure($code);$r=ConversionContext::read([]);
        check013('Other SDK error is not conflict '.$code,($r['conflict']??null)===false&&($r['retryable']??null)===false&&!isset($r['current_revision'])&&$r['core_conversion_context']===CoreConversions::failure($code));
    }
    F3Base_Conversoes_Contexto::$value=$base;F3Base_Conversoes_Contexto::$value['data']['purposes'][1]=F3Base_Conversoes_Contexto::$value['data']['purposes'][0];
    $r=ConversionContext::read(['expected_revision'=>str_repeat('0',64)]);
    check013('Invalid snapshot cannot expose revision',$r['core_conversion_context']['code']==='unsupported'&&($r['conflict']??null)===false&&!isset($r['current_revision']));
    F3Base_Conversoes_Contexto::$value=CoreConversions::failure('revision_conflict');F3Base_Conversoes_Contexto::$value['current_revision']=$base['data']['revision'];
    $r=ConversionContext::read([]);
    check013('Unknown error extension rejected',$r['core_conversion_context']['code']==='unsupported'&&!isset($r['current_revision']));
    F3Base_Conversoes_Contexto::$throw=true;$r=ConversionContext::read([]);
    check013('Exception is sanitized non-conflict',$r['core_conversion_context']['code']==='unreadable'&&($r['conflict']??null)===false&&!str_contains(json_encode($r),'PRIVATE'));
    F3Base_Conversoes_Contexto::$throw=false;F3Base_Conversoes_Contexto::$value=$base;$revision='stale';
    CoreConversions::snapshot(['expected_revision'=>str_repeat('0',64)],$revision);
    CoreConversions::snapshot([],$revision);check013('Optional output is reset between calls',$revision===null);
    echo json_encode(['suite'=>'conversion-response013','checks'=>count($passed)+count($failed),'passed'=>$passed,'failed'=>$failed,'failures'=>count($failed),'producer'=>'fixture; no WordPress or HTTP'],JSON_PRETTY_PRINT)."\n";
    exit(count($failed)?1:0);
}
