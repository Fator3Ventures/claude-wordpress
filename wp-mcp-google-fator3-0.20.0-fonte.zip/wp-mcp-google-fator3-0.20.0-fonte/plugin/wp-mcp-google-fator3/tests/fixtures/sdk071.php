<?php
/** Isolated fixture: no fake SDK class survives into the regression process. */
define('ABSPATH',__DIR__.'/');
require dirname(__DIR__,2).'/includes/McpServer.php';
$case=$argv[1];
$GLOBALS['caps']=['contract'=>'server-integration/1.0.0','provider'=>'wp-mcp-fator3','server_id'=>'wp-mcp-ultimate-server','version'=>'0.16.0'];
$GLOBALS['status']=$GLOBALS['caps']+['registry_checked'=>false,'server_registered'=>null,'tools_ready'=>null,'external_connectivity_tested'=>false,'server_enabled'=>true,'channel_enabled'=>true,'errors'=>[]];
if($case!=='absent'){
 if($case==='missing_method')eval('namespace Fator3\\McpFiles; final class ServerContract {public static function capabilities(){return $GLOBALS["caps"];}}');
 else eval('namespace Fator3\\McpFiles; final class ServerContract {public static function capabilities(){if(!empty($GLOBALS["throws"]))throw new \\RuntimeException("SDK_SECRET_MARKER");return $GLOBALS["caps"];} public static function status(){return $GLOBALS["status"];}}');
}
switch($case){
 case 'wrong_provider':$GLOBALS['caps']['provider']='foreign';break;
 case 'caps_invalid':$GLOBALS['caps']='SDK_SECRET_MARKER';break;
 case 'status_invalid':$GLOBALS['status']='SDK_SECRET_MARKER';break;
 case 'errors_invalid':$GLOBALS['status']['errors']=[['private'=>'SDK_SECRET_MARKER']];break;
 case 'throws':$GLOBALS['throws']=true;break;
 case 'disabled':$GLOBALS['status']['channel_enabled']=false;break;
 case 'not_ready':$GLOBALS['status']['registry_checked']=true;$GLOBALS['status']['server_registered']=true;$GLOBALS['status']['errors']=['mcp_route_missing'];break;
 case 'registered':$GLOBALS['status']['registry_checked']=true;$GLOBALS['status']['server_registered']=true;$GLOBALS['status']['tools_ready']=true;break;
}
echo json_encode(Fator3\McpGoogle\McpServer::status());
