"""Scoped release 0.15.0 verification. Preserves the separate historical full gate."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, shutil, subprocess, sys, zipfile

ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['manifest','work-base','evidence','php']:p.add_argument('--'+name,required=True,type=Path)
    a=p.parse_args();ev=a.evidence.resolve();work=a.work_base.resolve()
    if ev.exists() and any(ev.iterdir()):raise ValueError('Evidence destination must be empty')
    ev.mkdir(parents=True,exist_ok=True)
    lab=load_module('release015_lab',ROOT/'tools/lab.py');build=load_module('release015_build',ROOT/'build/build.py')
    config,inputs=lab.checked_inputs(a.manifest.resolve());candidate=inputs['candidate'];identity=build.identity();digest=sha(candidate)
    with zipfile.ZipFile(candidate) as z:
        if len(z.namelist())!=len(set(z.namelist())):raise ValueError('Duplicate ZIP member')
        actual={n.removeprefix('wp-mcp-google-fator3/'):z.read(n) for n in z.namelist()}
    if actual!=build.manifest():raise ValueError('Runtime/candidate mismatch')
    php=a.php.resolve()
    for path in actual:
        if path.endswith('.php'):subprocess.run([str(php),'-l',str(ROOT/path)],check=True,stdout=subprocess.DEVNULL)
    subprocess.run([str(php),str(ROOT/'build/export-contracts.php'),'--check'],check=True)
    subprocess.run([sys.executable,str(ROOT/'build/check-docs.py')],check=True)
    contracts={}
    for mode in ['absent','missing-method','matrix']:
        proof=json.loads(subprocess.run([str(php),str(ROOT/'tests/conversions-contract012.php'),mode],check=True,capture_output=True,text=True).stdout)
        (ev/('contracts-'+mode+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
        contracts[mode]={'checks':proof['checks'],'sha256':sha(ev/('contracts-'+mode+'.json'))}
    fixed=json.loads(subprocess.run([str(php),str(ROOT/'tests/conversion-response013.php')],check=True,capture_output=True,text=True).stdout)
    (ev/'response-candidate015.json').write_text(json.dumps(fixed,indent=2)+'\n')
    contracts['response013']={'checks':fixed['checks'],'sha256':sha(ev/'response-candidate015.json')}
    cases={
      'clean':('clean','mcp-first',['minimum015','clean','delivery015','conversions013','documentation015']),
      'upgrade':('upgrade','mcp-first',['upgrade015','minimum015','delivery015','documentation015']),
      'core140':('clean','google-first',['minimum015','delivery015','conversions013']),
      'isolated':('clean','google-only',['minimum015','clean','standalone014'])}
    groups={}
    for name,(origin,order,suites) in cases.items():
        print('RUN '+name,flush=True);dest=work/name
        current_manifest=a.manifest.resolve();current_inputs=inputs
        if name=='core140':
            cfg=json.loads(a.manifest.read_text());cfg['inputs']['core']=cfg['inputs']['core140'].copy()
            current_manifest=ev/'inputs-core140.json';current_manifest.write_text(json.dumps(cfg,indent=2)+'\n')
            _,current_inputs=lab.checked_inputs(current_manifest)
        cmd=[sys.executable,str(ROOT/'tools/lab.py'),'--manifest',str(current_manifest),'--workdir',str(dest),'--origin',origin,'--order',order]+['tests/native/'+s+'.php' for s in suites]
        with open(ev/(name+'.log'),'w') as log:subprocess.run(cmd,check=True,stdout=log,stderr=subprocess.STDOUT)
        out=ev/name;shutil.copytree(dest/'evidence',out)
        reports={}
        for suite in suites:
            f=out/(suite+'.json');d=json.loads(f.read_text())
            if d.get('failures')!=0 or d.get('candidate_sha256')!=digest or d.get('checks',0)!=len(d.get('passed',[])) or d.get('checks',0)<1:raise ValueError('Invalid suite '+suite)
            reports[suite]={'checks':d['checks'],'sha256':sha(f)}
        env=json.loads((out/'environment.json').read_text())
        if not env['processes_stopped'] or env['candidate_sha256']!=digest:raise ValueError('Environment not closed')
        inv={'candidate':lab.installed_inventory(candidate,dest/'wordpress/wp-content/plugins','wp-mcp-google-fator3')}
        for key,slug in [('mcp','wp-mcp-fator3'),('core','base-site-core-fator3'),('meta','wp-mcp-meta-fator3'),('linkedin','wp-mcp-linkedin-fator3')]:
            if (dest/'wordpress/wp-content/plugins'/slug).exists():inv[key]=lab.installed_inventory(current_inputs[key],dest/'wordpress/wp-content/plugins',slug)
        groups[name]={'checks':sum(d['checks'] for d in reports.values()),'reports':reports,'environment_sha256':sha(out/'environment.json'),'installed_inventory':inv,'origin':origin,'order':order}
        print('PASS '+name+' '+str(groups[name]['checks']),flush=True)
    if build.identity()!=identity or sha(candidate)!=digest:raise ValueError('Inputs changed during verification')
    proof={'schema_version':1,'release':'0.15.0','scope':'Core1.41 destination binding; native clean/upgrade014/rollback/isolation/docs/MCP; simulated Google; Core1.40 compatibility; no commercial processing claim','candidate_sha256':digest,'identity':identity,'checks':sum(g['checks'] for g in groups.values()),'contract_tests':contracts,'failures':0,'runtime_files':len(actual),'php_lint_files':sum(n.endswith('.php') for n in actual),'groups':groups,'inputs':{k:{'sha256':v['sha256'],'version':v['version']} for k,v in config['inputs'].items()}}
    (ev/'validation015.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps({'passed':True,'checks':proof['checks'],'candidate_sha256':digest}),flush=True)

if __name__=='__main__':main()
