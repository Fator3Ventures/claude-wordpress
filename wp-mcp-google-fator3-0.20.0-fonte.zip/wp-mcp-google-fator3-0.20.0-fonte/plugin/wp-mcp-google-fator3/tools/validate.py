"""Validate a declared candidate, collecting byte-bound reports outside the plugin runtime."""
from pathlib import Path
import argparse, importlib.util, json, os, shutil, subprocess, sys, tempfile, xml.etree.ElementTree as ET, zipfile
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[1]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
lab=module('lab',ROOT/'tools/lab.py');build=module('build',ROOT/'build/build.py')
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--manifest',required=True,type=Path);parser.add_argument('--work-base',required=True,type=Path);parser.add_argument('--evidence',required=True,type=Path);a=parser.parse_args()
    manifest=a.manifest.resolve();config,inputs=lab.checked_inputs(manifest);candidate=inputs['candidate'];sha=lab.sha(candidate);out=a.evidence.resolve();out.mkdir(parents=True,exist_ok=True)
    source_identity=build.identity();groups={};tool_env=os.environ.copy();tool_env['LD_LIBRARY_PATH']=str(inputs['runtime']/'usr/lib/x86_64-linux-gnu')
    ini=out/'unit.ini';mods=['ctype','fileinfo','tokenizer','phar','mbstring','dom','xml','simplexml','xmlreader','xmlwriter','curl','zip','iconv','posix']
    ini.write_text('extension_dir='+str(inputs['runtime']/'usr/lib/php/20230831')+'\n'+''.join('extension='+m+'.so\n' for m in mods)+'memory_limit=512M\ndate.timezone=UTC\n')
    php=[str(inputs['runtime']/'usr/bin/php8.3'),'-c',str(ini)]
    def run(name,cmd,cwd=ROOT):
        print('Running '+name,flush=True)
        with open(out/(name+'.log'),'w') as log:
            r=subprocess.run([str(x) for x in cmd],cwd=cwd,env=tool_env,stdout=log,stderr=subprocess.STDOUT)
        if r.returncode:raise RuntimeError(name+' failed; inspect '+str(out/(name+'.log')))
    def record(name,data):
        if data.get('failures',0)!=0:raise RuntimeError(name+' has failures')
        data={'candidate_sha256':sha,'failures':0}|data
        file=out/(name+'.json');file.write_text(json.dumps(data,indent=2)+'\n');groups[name]={'status':'passed','checks':data['checks'],'report':file.name,'sha256':lab.sha(file)}
    def native(name,dirname,origin,order,scripts):
        path=a.work_base.resolve()/dirname
        run(name,[sys.executable,ROOT/'tools/lab.py','--manifest',manifest,'--workdir',path,'--origin',origin,'--order',order,*['tests/native/'+s+'.php' for s in scripts]])
        dest=out/name;shutil.copytree(path/'evidence',dest)
        reports=[]
        for f in sorted(dest.glob('*.json')):
            if f.name=='environment.json':continue
            d=json.loads(f.read_text())
            if d.get('candidate_sha256')!=sha or d.get('failures')!=0:raise RuntimeError('Native report not bound to candidate: '+str(f))
            reports.append({'name':f.name,'sha256':lab.sha(f),'checks':d['checks']})
        environment=json.loads((dest/'environment.json').read_text());record(name,{'checks':sum(x['checks'] for x in reports),'reports':reports,'environment':environment})
    # Confirm the declared candidate was built from this source tree before any test begins.
    with tempfile.TemporaryDirectory(prefix='google-candidate-') as tmp:
        regenerated=Path(tmp)/'candidate.zip';build.write_candidate(regenerated)
        if lab.sha(regenerated)!=sha:raise RuntimeError('Candidate differs from current runtime; rebuild before validation')
    run('lab-controls',[sys.executable,ROOT/'tools/test-lab.py'])
    record('lab-controls',json.loads((out/'lab-controls.log').read_text()))
    run('unit',[*php,'-d','include_path='+str(inputs['testing']/'usr/share/php'),inputs['testing']/'usr/bin/phpunit','--log-junit',out/'unit-junit.xml'])
    xml=ET.parse(out/'unit-junit.xml').getroot();cases=list(xml.iter('testcase'));failures=sum(len(c.findall('failure'))+len(c.findall('error')) for c in cases)
    record('unit',{'checks':len(cases),'failures':failures,'assertions':sum(int(c.get('assertions','0')) for c in cases),'junit_sha256':lab.sha(out/'unit-junit.xml'),'toolchain_sha256':config['inputs']['testing']['sha256']})
    suites=['cold','clean','integration','concurrency','triggers','tokens','core','admin','isolation','companions','public-sdk','release010']
    with ThreadPoolExecutor(max_workers=2) as executor:
        runs=[executor.submit(native,'native-clean','clean-a','clean','mcp-first',suites),executor.submit(native,'native-repro','clean-b','clean','google-first',suites)]
        for task in runs:task.result()
    native('native-install','install','mcp-install','mcp-first',['install'])
    native('native-upgrade','upgrade','upgrade','mcp-first',['upgrade','cold','integration','core','public-sdk','release010'])
    native('native-upgrade-google-first','upgrade-google-first','upgrade','google-first',['upgrade','public-sdk','release010'])
    # Installation without any active companion also runs in a fresh isolated WordPress.
    native('native-no-companions','google-only','clean','google-only',['clean'])
    run('documentation',[*php,ROOT/'build/export-contracts.php','--check'])
    run('documentation-generators',[sys.executable,ROOT/'build/check-docs.py'])
    checks=[]
    with zipfile.ZipFile(candidate) as z:
        names=z.namelist();files={n.removeprefix('wp-mcp-google-fator3/'):z.read(n) for n in names}
        if files!=build.manifest():raise RuntimeError('Runtime inventory differs')
        checks.append('candidate exactly matches allowlist and generated indexes')
        dirs={Path('.')}
        for name in files:dirs.update(Path(name).parents)
        for directory in dirs:
            if files.get(str(directory/'index.php'))!=b'<?php\n// Silence is golden.\n':raise RuntimeError('Missing silent index')
        checks.append('silent index in every directory')
        if any(Path(n).suffix=='.md' or any(x in Path(n).parts for x in ['docs','reference','tests','tools','build','.git','.htaccess']) for n in files):raise RuntimeError('Forbidden production member')
        checks.append('no public documentation/reference/tools or htaccess')
    for f in sorted(ROOT.joinpath('includes').rglob('*.php'))+[ROOT/'wp-mcp-google-fator3.php',ROOT/'uninstall.php']:
        r=subprocess.run([*php,'-l',str(f)],env=tool_env,capture_output=True,text=True)
        if r.returncode:raise RuntimeError(r.stdout+r.stderr)
        checks.append('syntax '+str(f.relative_to(ROOT)))
    record('package',{'checks':len(checks),'passed':checks,'files':len(files),'directories':len(dirs),'inventory':{n:build.digest(v) for n,v in files.items()}})
    # The validator's controls are exercised using explicitly synthetic report fixtures.
    required=json.loads((ROOT/'build/release-policy.json').read_text())['required_groups'];negative=[]
    inputs_state={k:{'sha256':v['sha256'],'version':v.get('version')} for k,v in config['inputs'].items()}
    with tempfile.TemporaryDirectory(prefix='google-build-negative-') as tmp:
        t=Path(tmp);fixture={'schema_version':1,'candidate_sha256':sha,'identity':source_identity,'inputs':inputs_state,'groups':json.loads(json.dumps(groups))}
        for name in groups:
            shutil.copy2(out/(name+'.json'),t/(name+'.json'))
            if name.startswith('native-'):shutil.copytree(out/name,t/name)
        shutil.copy2(out/'unit-junit.xml',t/'unit-junit.xml')
        f=t/'build-negative.json';f.write_text(json.dumps({'candidate_sha256':sha,'failures':0,'checks':1,'synthetic_control_fixture':True}));fixture['groups']['build-negative']={'status':'passed','checks':1,'report':f.name,'sha256':lab.sha(f)}
        evidence=t/'fixture.json'
        def reject(label,doc=None,candidate_path=candidate):
            evidence.write_text(json.dumps(fixture if doc is None else doc))
            try:build.verify(candidate_path,evidence,manifest)
            except (ValueError,KeyError,OSError):negative.append(label);return
            raise RuntimeError('Release control wrongly accepted: '+label)
        evidence.write_text(json.dumps(fixture));build.verify(candidate,evidence,manifest);negative.append('valid coherent synthetic control accepted')
        try:build.verify(candidate,t/'absent.json',manifest)
        except OSError:negative.append('absent evidence refused')
        else:raise RuntimeError('Missing evidence accepted')
        import copy
        for label,change in [
            ('missing required group',lambda d:d['groups'].pop('unit')),
            ('not executed group',lambda d:d['groups']['unit'].update(status='not_executed')),
            ('wrong candidate',lambda d:d.update(candidate_sha256='0'*64)),
            ('changed testing identity',lambda d:d['identity']['verification_inputs'].update({'tests/bootstrap.php':'0'*64})),
            ('changed runtime identity',lambda d:d['identity']['runtime'].update({'wp-mcp-google-fator3.php':'0'*64})),
            ('changed input hash',lambda d:d['inputs']['mcp'].update(sha256='0'*64)),
            ('missing report',lambda d:d['groups']['unit'].update(report='absent.json')),
            ('incoherent checks',lambda d:d['groups']['unit'].update(checks=1)),
        ]:
            d=copy.deepcopy(fixture);change(d);reject(label,d)
        f=t/'unit.json';old=f.read_bytes();f.write_text('{}');reject('altered report bytes');f.write_bytes(old)
        nested=t/'native-clean/cold.json';old=nested.read_bytes();nested.write_text('{}');reject('altered nested native proof');nested.write_bytes(old)
        junit=t/'unit-junit.xml';old=junit.read_bytes();junit.write_text('<testsuites/>');reject('altered JUnit proof');junit.write_bytes(old)
        changed=t/'wrong.zip';changed.write_bytes(candidate.read_bytes()+b'changed');reject('changed candidate bytes',candidate_path=changed)
        # Exercise actual source change after validation, not merely a changed evidence digest.
        source=ROOT/'includes/Storage/State.php';old=source.read_bytes()
        try:source.write_bytes(old+b'\n');reject('actual runtime edit invalidates approval')
        finally:source.write_bytes(old)
        # Ownership/reset and dependency negative controls use no database or process.
        foreign=t/'foreign';foreign.mkdir();(foreign/'important.txt').write_text('keep')
        try:lab.owned(foreign)
        except ValueError:negative.append('foreign reset refused without touching files')
        else:raise RuntimeError('Foreign reset accepted')
        badconfig=copy.deepcopy(config);badconfig['inputs']['mcp']['path']=str(t/'missing.zip');f=t/'missing-input.json'
        for name,v in badconfig['inputs'].items():
            if name!='mcp':v['path']=str(inputs[name])
        f.write_text(json.dumps(badconfig))
        try:lab.checked_inputs(f)
        except ValueError:negative.append('missing dependency explicitly refused')
        else:raise RuntimeError('Missing dependency accepted')
    record('build-negative',{'checks':len(negative),'passed':negative,'scope':'synthetic build-control fixtures; all functional reports are separate actual runs'})
    if build.identity()!=source_identity:raise RuntimeError('Verification inputs changed during run; evidence is stale')
    final={'schema_version':1,'candidate_sha256':sha,'identity':source_identity,'inputs':inputs_state,'groups':groups}
    (out/'validation.json').write_text(json.dumps(final,indent=2)+'\n')
    build.verify(candidate,out/'validation.json',manifest)
    # Preserve a portable manifest: filenames/versions/hashes, never laboratory credentials.
    recorded=json.loads(json.dumps(config))
    for name,v in recorded['inputs'].items():v['path']='../inputs/'+inputs[name].name
    (out/'inputs.json').write_text(json.dumps(recorded,indent=2)+'\n')
    ini.unlink()
    print(json.dumps({'validated':True,'candidate_sha256':sha,'groups':{k:v['checks'] for k,v in groups.items()}}))
if __name__=='__main__':
    try:main()
    except (RuntimeError,ValueError,KeyError,OSError,subprocess.CalledProcessError) as exc:raise SystemExit('Validation stopped: '+str(exc))
