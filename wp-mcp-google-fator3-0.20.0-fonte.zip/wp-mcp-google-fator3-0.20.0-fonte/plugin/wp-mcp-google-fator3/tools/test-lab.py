"""Negative controls for the portable lab, using only disposable local fixtures."""
from pathlib import Path
import importlib.util,json,tempfile,zipfile,hashlib
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('google_lab',root/'tools/lab.py');lab=importlib.util.module_from_spec(spec);spec.loader.exec_module(lab)
passed=[]
def rejects(label,fn):
    try:fn()
    except (ValueError,KeyError,OSError):passed.append(label);return
    raise AssertionError(label)
with tempfile.TemporaryDirectory(prefix='google-lab-controls-') as tmp:
    t=Path(tmp);unowned=t/'unowned';unowned.mkdir();(unowned/'keep').write_text('keep')
    rejects('foreign directory reset refused',lambda:lab.owned(unowned));assert (unowned/'keep').read_text()=='keep'
    z=t/'bad.zip'
    with zipfile.ZipFile(z,'w') as out:out.writestr('../escaped','bad')
    rejects('ZIP traversal refused',lambda:lab.extract_zip(z,t/'extracted'));assert not (t/'escaped').exists()
    (t/'input').write_text('bytes');m=t/'manifest.json';m.write_text(json.dumps({'inputs':{'selected':{'path':'input','sha256':hashlib.sha256(b'bytes').hexdigest()},'irrelevant':{'path':'missing','sha256':'0'*64}}}))
    _,selected=lab.checked_inputs(m,['selected']);assert set(selected)=={'selected'};passed.append('unused dependency not required')
    rejects('missing selected dependency refused',lambda:lab.checked_inputs(m,['irrelevant']))
    (t/'input').write_text('changed');rejects('changed selected input refused',lambda:lab.checked_inputs(m,['selected']))
    assert 'mcp' not in lab.required_inputs('clean','google-only') and 'baseline' not in lab.required_inputs('clean','mcp-first');passed.append('scenario inputs are minimal')
    assert {'baseline','baseline_mcp','baseline_core'}<=set(lab.required_inputs('upgrade','mcp-first'));passed.append('joint update requires actual origins')
    package=t/'package.zip'
    with zipfile.ZipFile(package,'w') as out:out.writestr('plugin/current.php','current')
    plugins=t/'plugins';lab.extract_zip(package,plugins)
    assert lab.installed_inventory(package,plugins,'plugin')['exact'];passed.append('exact installed inventory accepted')
    extra=plugins/'plugin/removed.php';extra.write_text('old');rejects('old member remaining after replacement refused',lambda:lab.installed_inventory(package,plugins,'plugin'));extra.unlink()
    (plugins/'plugin/current.php').write_text('changed');rejects('changed installed member refused',lambda:lab.installed_inventory(package,plugins,'plugin'))
rejects('script outside native suite refused',lambda:lab.native_script('README.md'))
print(json.dumps({'checks':len(passed),'passed':passed,'failures':0}))
