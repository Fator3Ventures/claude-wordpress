<?php
/**
 * Public, versioned GA4 reader for registered local plugins.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
use Fator3\McpGoogle\{
    Ability, Audit, Auth\Credentials, Automation\Execution, Connections, Crypto, Gate, Http\GoogleClient, Options, Policy, Records, Response, Settings, Storage\Admission, Storage\State
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Ga4ServiceApi {
    public const CONTRACT = 'ga4-reader/1.0.0';
    public const VERSION = '1.0.0';
    public const CAPABILITY = 'ga4.report.read';
    public const GRANTS = 'f3_mcp_google_ga4_consumer_grants';
    public const MAX_LIMIT = 5000;
    public const MAX_BUDGET_MS = 20000;
    private static array $consumers = array();
    public static function init(): void {
        add_action( 'plugins_loaded', array( self::class, 'discover' ), 31 );
    }
    public static function discover(): void {
        do_action( 'f3_mcp_google_register_consumers', new self(), self::CONTRACT );
    }
    public static function capabilities(): array {
        return array(
            'contract' => self::CONTRACT,
            'contract_version' => self::VERSION,
            'plugin_version' => F3_MCP_GOOGLE_VERSION,
            'registration_hook' => 'f3_mcp_google_register_consumers',
            'client_methods' => array( 'query', 'status', 'effective_status' ),
            'capabilities' => array( self::CAPABILITY ),
            'input_schema' => self::schema(),
            'max_budget_ms' => self::MAX_BUDGET_MS,
            'return_margin_ms' => 2000,
            'limit_max' => min( self::MAX_LIMIT, Options::max_rows() ),
            'calendar' => 'property_time_zone',
            'quota_scope' => 'property; serialized_local_consumer_queries; external_consumption_not_reserved',
            'all_rows_guaranteed' => false,
        );
    }
    public static function schema(): array {
        $s = ServiceApi::schema();
        unset($s['properties']['date']);
        $s['properties']['property'] = ['type'=>'string','pattern'=>'^properties/[1-9][0-9]{0,19}$'];
        $s['properties']['start_date'] = ['type'=>'string','pattern'=>'^\\d{4}-\\d{2}-\\d{2}$'];
        $s['properties']['end_date'] = $s['properties']['start_date'];
        $s['properties']['dimensions'] = ['type'=>'array','maxItems'=>9,'uniqueItems'=>true,'items'=>['type'=>'string','minLength'=>1,'maxLength'=>100]];
        $s['properties']['metrics'] = ['type'=>'array','minItems'=>1,'maxItems'=>10,'uniqueItems'=>true,'items'=>['type'=>'string','minLength'=>1,'maxLength'=>100]];
        foreach (['dimension_filter','metric_filter'] as $k) $s['properties'][$k]=['type'=>'object','description'=>'FilterExpression da Data API em camelCase; até 16 KiB por filtro.'];
        $s['required'] = ['contract_version','property','consumer_revision','start_date','end_date','dimensions','metrics','run_id','trigger','budget_ms'];
        return $s;
    }
    /** $configuration returns {property:string,revision:string,ready:bool}. */
    public static function register_consumer( string $id, string $version, string $contract, callable $configuration ) {
        if ( ! preg_match( '/^[a-z][a-z0-9-]{1,79}$/D', $id ) || ! preg_match( '/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/D', $version ) ) {
            return new \WP_Error( 'f3_google_consumer_input', 'Identidade/versão do consumidor inválida.' );
        }
        if ( self::CONTRACT !== $contract ) {
            return new \WP_Error( 'f3_google_consumer_contract', 'Contrato de consumidor incompatível.' );
        }
        if ( isset( self::$consumers[ $id ] ) ) {
            return new \WP_Error( 'f3_google_consumer_duplicate', 'Consumidor já registrado.' );
        }
        $client = new Ga4ConsumerClient();
        self::$consumers[ $id ] = array(
            'id' => $id,
            'version' => $version,
            'configuration' => $configuration,
            'client' => $client,
        );
        return $client;
    }
    private static function find( Ga4ConsumerClient $client ): ?array {
        foreach ( self::$consumers as $consumer ) {
            if ( $consumer['client'] === $client ) {
                return $consumer;
            }
        }
        return null;
    }
    private static function config( array $consumer ) {
        try {
            $c = ( $consumer['configuration'] )();
        }
        catch ( \Throwable $e ) {
            return new \WP_Error( 'f3_google_consumer_configuration', 'Consumidor não forneceu configuração válida.' );
        }
        if ( ! is_array( $c ) || ! is_bool( $c['ready'] ?? null ) ) {
            return new \WP_Error( 'f3_google_consumer_configuration', 'Callback exige propriedade, revisão e prontidão.' );
        }
        if ( ! $c['ready'] ) {
            return new \WP_Error(
                'f3_google_consumer_not_ready',
                'Estrutura/configuração do consumidor ainda não está pronta.',
                array(
                    'retryable' => true,
                    'retry_after_ms' => 15000,
                )
            );
        }
        if ( ! is_string( $c['property'] ?? null ) || ! self::valid_property( $c['property'] ) || ! is_string( $c['revision'] ?? null ) || strlen( $c['revision'] ) < 1 || strlen( $c['revision'] ) > 128 ) {
            return new \WP_Error( 'f3_google_consumer_configuration', 'Propriedade ou revisão inválida no consumidor.' );
        }
        return array_intersect_key( $c, array_flip( array( 'property', 'revision', 'ready' ) ) );
    }
    public static function valid_property(string $p): bool {
        return (bool)preg_match('~^properties/[1-9][0-9]{0,19}$~D', $p);
    }
    private static function grants() {
        $r = Options::stored( Options::storage_name( self::GRANTS ) );
        if ( ! $r['success'] || ( $r['exists'] && ! is_array( $r['value'] ) ) ) {
            return new \WP_Error( 'f3_google_consumer_grants_read', 'Autorizações ilegíveis.' );
        }
        return $r['value'] ?? array();
    }
    private static function guard( array $consumer, array $configuration, string $revision, array $grant ): ?\WP_Error {
        $recovery = \Fator3\McpGoogle\Recovery::guard();
        if ( $recovery ) {
            return $recovery;
        }
        if ( ! Options::is_enabled() ) {
            return new \WP_Error( 'f3_google_disabled', 'Google desativado.' );
        }
        if ($storage = State::guard()) {
            return $storage;
        }
        if ( ! Connections::enabled( 'ga' ) ) {
            return new \WP_Error( 'f3_google_connector_off', 'GA4 desativado.' );
        }
        $grants = self::grants();
        if ( is_wp_error( $grants ) ) {
            return $grants;
        }
        if ( ( $grants[ $consumer['id'] ] ?? null ) !== $grant || empty( $grant['enabled'] ) || ( $grant['capability'] ?? '' ) !== self::CAPABILITY ) {
            return new \WP_Error( 'f3_google_consumer_unauthorized', 'Consumidor sem concessão vigente nesta conexão.' );
        }
        if (($grant['principal'] ?? null) !== Credentials::execution_identity() || ($grant['property'] ?? null) !== $configuration['property'] || !Options::user_authorized((int)($grant['granted_by'] ?? 0))) {
            return new \WP_Error('f3_google_consumer_unauthorized','Propriedade ou administrador da concessão não autorizado.');
        }
        $now = self::config( $consumer );
        if ( is_wp_error( $now ) ) {
            return $now;
        }
        if ( $now !== $configuration ) {
            return new \WP_Error( 'f3_google_consumer_changed', 'Configuração do consumidor mudou; reinicie a página.' );
        }
        $current = Settings::execution_revision();
        if ( is_wp_error( $current ) ) {
            return $current;
        }
        if ( ! hash_equals( $revision, $current ) ) {
            return new \WP_Error( 'f3_google_context_changed', 'Credencial ou política mudou durante a consulta.' );
        }
        if ( ! Policy::permitted( 'ga', $configuration['property'] ) ) {
            return new \WP_Error( 'f3_google_policy', 'Propriedade fora da política da conexão.' );
        }
        $credentials = Credentials::current();
        return is_wp_error( $credentials ) ? $credentials : null;
    }
    public static function query(Ga4ConsumerClient $client, array $input): array {
        $consumer = self::find($client);
        if (!$consumer) return self::failure(new \WP_Error('f3_google_consumer_unregistered','Cliente não registrado.'));
        $error = self::validate_input($input);
        if ($error) return self::failure($error);
        $ctx=['contract'=>self::CONTRACT,'actor'=>['type'=>'plugin','id'=>$consumer['id'],'version'=>$consumer['version']],
            'run_id'=>$input['run_id'],'trigger'=>$input['trigger'],'request_id'=>Records::id(),'property'=>$input['property'],
            'consumer_revision'=>$input['consumer_revision'],'body'=>[],'http_attempts'=>0,'query_dispatched'=>false];
        $resolved=self::resolve_grant($consumer['id']);
        $connection=!is_wp_error($resolved) && $resolved['resolution']==='resolved' ? $resolved['connection_id'] : Connections::id();
        return Connections::run($connection, static fn()=>Context::run($ctx, static function() use($consumer,$input,$ctx) {
            $before=Audit::append('plugin:ga4.report.begin',$input['property'],['mode'=>'read','status'=>'started']);
            if (!$before['success']) return self::failure(new \WP_Error('f3_google_audit_persistence','Consulta suspensa: auditoria indisponível.'));
            $result=Execution::run(static fn()=>self::authorized_query($consumer,$input),$input['budget_ms']/1000);
            $after=Audit::append('plugin:ga4.report.end',$input['property'],['mode'=>'read','status'=>$result['success']?'completed':'failed','rows'=>count($result['rows']??[]),'error_code'=>$result['error_code']??null,'service_request'=>$result['request_id']??$ctx['request_id']]);
            if (!$after['success']) return self::failure(new \WP_Error('f3_google_audit_incomplete','Auditoria final não confirmada. Não avance o cursor.'),['remote_dispatched'=>$result['remote_dispatched']??false]);
            $result['audit_success']=true;
            return $result;
                }));
    }
    private static function authorized_query( array $consumer, array $input ): array {
        $cfg = self::config( $consumer );
        if ( is_wp_error( $cfg ) ) {
            return self::failure( $cfg );
        }
        if ( $input['property'] !== $cfg['property'] || $input['consumer_revision'] !== $cfg['revision'] ) {
            return self::failure( new \WP_Error( 'f3_google_consumer_property', 'Consulta deve usar propriedade e revisão atuais do consumidor.' ) );
        }
        $resolved = self::resolve_grant( $consumer['id'] );
        if ( is_wp_error( $resolved ) ) {
            return self::failure( $resolved );
        }
        if ( 'resolved' !== $resolved['resolution'] ) {
            return self::failure( new \WP_Error( 'f3_google_consumer_unauthorized', 'Autorize o consumidor em exatamente uma conexão.' ) );
        }
        $cid = $resolved['connection_id'];
        $grant = $resolved['grant'];
        return Connections::run(
            $cid,
            static function () use ( $consumer, $cfg, $input, $grant ): array {
            $revision = Settings::execution_revision();
            if ( is_wp_error( $revision ) ) {
                return self::failure( $revision );
            }
            $guard = static fn()=>self::guard( $consumer, $cfg, $revision, $grant );
            $error = $guard();
            if ( $error ) {
                return self::failure( $error );
            }
            return Admission::run(
                'plugin:ga4.report.read',
                static fn()=>Execution::run(
                    static fn()=>self::page( $consumer, $cfg, $input, $revision, $grant, $guard ),
                    $input['budget_ms'] / 1000,
                    $guard
                )
            );
            }
        );
    }
    private static function validate_input(array $i): ?\WP_Error {
        $schema=self::schema();
        if (array_diff(array_keys($i),array_keys($schema['properties'])) || array_diff($schema['required'],array_keys($i))) return new \WP_Error('f3_google_consumer_input','Parâmetros ausentes ou não permitidos.');
        foreach (['contract_version','property','consumer_revision','start_date','end_date','run_id','trigger'] as $k) if (!is_string($i[$k])) return new \WP_Error('f3_google_consumer_input','Tipo inválido: '.$k);
        if ($i['contract_version']!==self::VERSION || !self::valid_property($i['property']) || strlen($i['consumer_revision'])<1 || strlen($i['consumer_revision'])>128 || !preg_match('/^[A-Za-z0-9._:-]{1,100}$/D',$i['run_id']) || !in_array($i['trigger'],['cli','http_cron','manual'],true)) return new \WP_Error('f3_google_consumer_input','Contrato, propriedade, revisão ou origem inválidos.');
        if (!is_int($i['budget_ms']) || $i['budget_ms']<1 || $i['budget_ms']>self::MAX_BUDGET_MS || (isset($i['limit']) && (!is_int($i['limit']) || $i['limit']<1 || $i['limit']>min(self::MAX_LIMIT,Options::max_rows()))) || (isset($i['cursor']) && (!is_string($i['cursor']) || strlen($i['cursor'])>4096))) return new \WP_Error('f3_google_consumer_input','Prazo, limite ou cursor inválido.');
        foreach (['start_date','end_date'] as $k) {
            $d=\DateTimeImmutable::createFromFormat('!Y-m-d',$i[$k],new \DateTimeZone('UTC'));
            if (!$d || $d->format('Y-m-d')!==$i[$k]) return new \WP_Error('f3_google_consumer_date','Data ISO inválida.');
        }
        if ($i['start_date']>$i['end_date'] || (strtotime($i['end_date'])-strtotime($i['start_date']))>365*86400) return new \WP_Error('f3_google_consumer_date','Período deve conter de 1 a 366 dias.');
        foreach (['dimensions'=>9,'metrics'=>10] as $k=>$max) {
            if (!is_array($i[$k]) || !array_is_list($i[$k]) || count($i[$k])>$max || ($k==='metrics' && !$i[$k])) return new \WP_Error('f3_google_consumer_input','Lista inválida: '.$k);
            foreach ($i[$k] as $name) if (!is_string($name) || !preg_match('/^[A-Za-z][A-Za-z0-9_:]{0,99}$/D',$name)) return new \WP_Error('f3_google_consumer_input','Nome de dimensão/métrica inválido.');
            if (count(array_unique($i[$k]))!==count($i[$k])) return new \WP_Error('f3_google_consumer_input','Dimensão/métrica duplicada.');
        }
        foreach (['dimension_filter','metric_filter'] as $k) if (array_key_exists($k,$i) && (!is_array($i[$k]) || !self::filter_valid($i[$k]) || strlen((string)wp_json_encode($i[$k]))>16384)) return new \WP_Error('f3_google_consumer_input','Filtro inválido.');
        return null;
    }
    private static function filter_valid(array $f,int $depth=0): bool {
        if ($depth>8 || count($f)!==1) return false;
        $k=array_key_first($f);
        $v=$f[$k];
        if (!is_array($v)) return false;
        if ($k==='notExpression') return self::filter_valid($v,$depth+1);
        if (in_array($k,['andGroup','orGroup'],true)) {
            if (array_keys($v)!==['expressions'] || !is_array($v['expressions']) || !array_is_list($v['expressions']) || count($v['expressions'])<1 || count($v['expressions'])>25) return false;
            foreach ($v['expressions'] as $child) if (!is_array($child) || !self::filter_valid($child,$depth+1)) return false;
            return true;
        }
        if ($k!=='filter' || !is_string($v['fieldName']??null) || !preg_match('/^[A-Za-z][A-Za-z0-9_:]{0,99}$/D',$v['fieldName'])) return false;
        $types=array_intersect(array_keys($v),['stringFilter','inListFilter','numericFilter','betweenFilter','emptyFilter']);
        if (count($types)!==1 || count($v)!==2) return false;
        $type=current($types);
        $filter=$v[$type];
        if (!is_array($filter)) return false;
        // Nested filter syntax/metric compatibility is ultimately validated by Google.
        return self::json_tree($filter);
    }
    private static function json_tree(array $value,int $depth=0): bool {
        if ($depth>6 || count($value)>100) return false;
        foreach ($value as $v) {
            if (is_array($v)) {
                if (!self::json_tree($v,$depth+1)) return false;
            }
            elseif (!is_scalar($v) && $v!==null) return false;
            elseif (is_float($v) && !is_finite($v)) return false;
        }
        return true;
    }
    private static function page(array $consumer,array $cfg,array $i,string $revision,array $grant,callable $guard): array {
        $limit=$i['limit']??min(1000,Options::max_rows());
        $start=0;
        $query=array_intersect_key($i,array_flip(['start_date','end_date','dimensions','metrics','dimension_filter','metric_filter']));
        $binding=[self::CONTRACT,$consumer['id'],Connections::id(),$cfg['property'],$cfg['revision'],hash('sha256',(string)wp_json_encode($query)),$limit,$revision,$grant['revision']];
        if (!empty($i['cursor'])) {
            $plain=Crypto::decrypt($i['cursor']);
            $c=is_string($plain)?json_decode($plain,true):null;
            if (!is_array($c) || ($c['binding']??null)!==$binding || ($c['expires']??0)<time() || !is_int($c['start']??null) || $c['start']<0) return self::failure(new \WP_Error('f3_google_consumer_cursor','Cursor inválido, expirado ou de outro contexto.'));
            $start=$c['start'];
        }
        $body=['dateRanges'=>[['startDate'=>$i['start_date'],'endDate'=>$i['end_date']]],
            'dimensions'=>array_map(static fn($n)=>['name'=>$n],$i['dimensions']),
            'metrics'=>array_map(static fn($n)=>['name'=>$n],$i['metrics']),
            'offset'=>(string)$start,'limit'=>(string)$limit,'returnPropertyQuota'=>true];
        if ($i['dimensions']) $body['orderBys']=array_map(static fn($n)=>['dimension'=>['dimensionName'=>$n],'desc'=>false],$i['dimensions']);
        foreach (['dimension_filter'=>'dimensionFilter','metric_filter'=>'metricFilter'] as $key=>$dest) if (isset($i[$key])) $body[$dest]=$i[$key];
        $ctx=Context::current();
        $ctx['body']=$body;
        return Context::run($ctx,static function() use($cfg,$i,$body,$binding,$start,$limit,$guard,$ctx) {
            $common=['contract_version'=>self::VERSION,'request_id'=>$ctx['request_id'],'connection_id'=>Connections::id(),'property'=>$cfg['property'],'consumer_revision'=>$cfg['revision'],'run_id'=>$i['run_id']];
            $lock=\Fator3\McpGoogle\Lock::acquire_result('ga4-property:'.$cfg['property'],30);
            if (!$lock['success']) return self::failure(new \WP_Error($lock['code'],'Consulta da propriedade ocupada ou controle indisponível.',['retryable'=>$lock['retryable'],'retry_after_ms'=>30000,'next_eligible_at'=>time()+30]),$common);
            try {
                $key=Ga4Quota::key($cfg['property']);
                $state=Options::stored($key);
                if (!$state['success'] || ($state['exists'] && !Ga4Quota::valid_state($state['value']))) return self::failure(new \WP_Error('f3_google_quota_storage','Cota local ilegível.'),$common);
                $previous=$state['value']??[];
                if (($previous['next_eligible_at']??0)>time()) return self::failure(new \WP_Error('f3_google_ga4_quota','Propriedade aguardando disponibilidade da cota.',['retryable'=>true,'retry_after_ms'=>($previous['next_eligible_at']-time())*1000,'next_eligible_at'=>$previous['next_eligible_at']]),$common+['quota'=>$previous]);
                // A durable short reservation also covers a process dying after dispatch.
                $reserved=['observed_at'=>$previous['observed_at']??null,'property_quota'=>$previous['property_quota']??[],'next_eligible_at'=>time()+30,'state'=>'in_flight'];
                if (!Options::set($key,$reserved)['success']) return self::failure(new \WP_Error('f3_google_quota_storage','Reserva de cota não confirmada.'),$common);
                $error=$guard()??Execution::check(true);
                $raw=$error??GoogleClient::post(GoogleClient::HOST_GA_DATA.'/v1beta/'.$cfg['property'].':runReport',$body,
                    ['connector'=>'ga','mode'=>'read','operation_id'=>'analyticsdata.properties.runReport','scopes'=>['https://www.googleapis.com/auth/analytics.readonly'],'retries'=>0]);
                $current=Context::current();
                $common['remote_dispatched']=!empty($current['query_dispatched']);
                $common['http_attempts']=$current['http_attempts'];
                $quota=Ga4Quota::observation($raw,$previous);
                if (!Options::set($key,$quota)['success']) return self::failure(new \WP_Error('f3_google_quota_storage','Observação de cota não confirmada; não avance o cursor.'),$common);
                if (is_wp_error($raw)) {
                    $data=(array)$raw->get_error_data();
                    if ($quota['next_eligible_at']>time()) $data=array_merge($data,['retryable'=>true,'retry_after_ms'=>($quota['next_eligible_at']-time())*1000,'next_eligible_at'=>$quota['next_eligible_at']]);
                    return self::failure(new \WP_Error($raw->get_error_code(),$raw->get_error_message(),$data),$common+['quota'=>$quota]);
                }
                $error=$guard()??Execution::check();
                if ($error) return self::failure($error,$common+['quota'=>$quota]);
                if (!\Fator3\McpGoogle\Lock::owned($lock['lock'])) return self::failure(new \WP_Error('f3_google_quota_lease','Reserva de propriedade expirada.'),$common);
                $rows=$raw['rows']??[];
                $count=$raw['rowCount']??0;
                if (!is_array($rows) || !array_is_list($rows) || count($rows)>$limit || !is_int($count) || $count<0 || !is_array($raw['dimensionHeaders']??[]) || !is_array($raw['metricHeaders']??null) || array_column($raw['dimensionHeaders']??[],'name')!==$i['dimensions'] || array_column($raw['metricHeaders'],'name')!==$i['metrics'] || !Ga4Quota::valid_quota($raw['propertyQuota']??null)) return self::failure(new \WP_Error('f3_google_consumer_response','Linhas, cabeçalhos ou cota inválidos.'),$common+['quota'=>$quota]);
                foreach ($rows as $row) {
                    if (!is_array($row)) return self::failure(new \WP_Error('f3_google_consumer_response','Linha inválida.'),$common);
                    foreach (['dimensionValues'=>count($i['dimensions']),'metricValues'=>count($i['metrics'])] as $field=>$n) {
                        $values=$row[$field]??[];
                        if (!is_array($values) || !array_is_list($values) || count($values)!==$n) return self::failure(new \WP_Error('f3_google_consumer_response','Quantidade de valores inválida.'),$common);
                        foreach ($values as $v) if (!is_array($v) || !is_string($v['value']??null)) return self::failure(new \WP_Error('f3_google_consumer_response','Valor inválido.'),$common);
                    }
                }
                $end=$start+count($rows);
                $more=$end<$count;
                if (($rows && $end>$count) || ($more && !$rows)) return self::failure(new \WP_Error('f3_google_consumer_response','Paginação inconsistente; reinicie o recorte.'),$common);
                $next=$more?Crypto::encrypt((string)wp_json_encode(['binding'=>$binding,'start'=>$end,'expires'=>time()+86400])):null;
                if ($more && !$next) return self::failure(new \WP_Error('f3_google_crypto_encrypt','Não foi possível criar cursor.'),$common);
                $metadata=$raw['metadata']??[];
                if (!is_array($metadata)) return self::failure(new \WP_Error('f3_google_consumer_response','Metadados inválidos.'),$common);
                $recent=null;
                $zone=$metadata['timeZone']??null;
                if (is_string($zone)) {
                    try {
                        $today=new \DateTimeImmutable('today',new \DateTimeZone($zone));
                        $recent=[];
                        for ($d=0;$d<3;$d++) {
                            $day=$today->modify('-'.$d.' days')->format('Y-m-d');
                            if ($day>=$i['start_date'] && $day<=$i['end_date']) $recent[]=$day;
                        }
                    }
                    catch (\Exception $e) {
                        $recent=null;
                    }
                }
                return Response::ok($common+['extracted_at'=>time(),'rows'=>$rows,'dimension_headers'=>$raw['dimensionHeaders']??[],'metric_headers'=>$raw['metricHeaders'],'row_count'=>$count,'next_cursor'=>$next,'metadata'=>$metadata,'quota'=>$quota,
                        'quality'=>['samplingMetadatas'=>$metadata['samplingMetadatas']??[],'dataLossFromOtherRow'=>$metadata['dataLossFromOtherRow']??false,'subjectToThresholding'=>$metadata['subjectToThresholding']??false,'dataTruncationReasons'=>$metadata['dataTruncationReasons']??[],'timeZone'=>$zone,'currencyCode'=>$metadata['currencyCode']??null,'estimated_unfinalized_dates'=>$recent,'finalization_guaranteed'=>false,'finalization_basis'=>'heuristic_today_and_previous_two_property_calendar_days; provider_has_no_final_flag'],
                        'coverage'=>['offset'=>$start,'limit'=>$limit,'returned_rows'=>count($rows),'pagination_complete'=>!$more,'snapshot_guaranteed'=>false,'all_rows_guaranteed'=>false]]);
            }
            finally {
                \Fator3\McpGoogle\Lock::release($lock['lock']);
            }
            });
    }
    private static function failure( \WP_Error $e, array $extra = array() ): array {
        $d = (array) $e->get_error_data();
        $result = Response::fail(
            $e,
            $extra + array(
                'contract_version' => self::VERSION,
                'retryable' => (bool) ( $d['retryable'] ?? false ),
                'retry_after_ms' => $d['retry_after_ms'] ?? ( isset( $d['retry_after'] ) ? (int) $d['retry_after'] * 1000 : null ),
                'next_eligible_at' => $d['next_eligible_at'] ?? null,
                'remote_dispatched' => false,
            )
        );
        // Preserve the service correlation; an HTTP request id remains in details.
        if ( isset( $extra['request_id'] ) ) {
            $result['request_id'] = $extra['request_id'];
        }
        return $result;
    }
    /** Internal resolution reused by query and the optional local diagnostic. */
    private static function resolve_grant( string $id ) {
        $registry = Connections::registry_verified();
        if ( is_wp_error( $registry ) ) {
            return $registry;
        }
        $matches = array();
        foreach ( array_keys( $registry ) as $cid ) {
            $g = Connections::run( $cid, static fn()=>self::grants() );
            if ( is_wp_error( $g ) ) {
                return $g;
            }
            if ( ! is_array( $g ) || isset( $g['error_code'] ) || ( isset( $g[ $id ] ) && ( ! is_array( $g[ $id ] ) || ! is_bool( $g[ $id ]['enabled'] ?? null ) ) ) ) {
                return new \WP_Error( 'f3_google_consumer_grants_read', 'Autorizações ilegíveis.' );
            }
            if ( ! empty( $g[ $id ]['enabled'] ) ) {
                $matches[ $cid ] = $g[ $id ];
            }
        }
        $resolution = count( $matches ) === 1 ? 'resolved' : ( $matches ? 'ambiguous' : 'not_granted' );
        return array(
            'resolution' => $resolution,
            'connection_id' => 'resolved' === $resolution ? key( $matches ) : null,
            'grant' => 'resolved' === $resolution ? current( $matches ) : null,
        );
    }
    public static function effective_status( Ga4ConsumerClient $client ): array {
        $consumer = self::find( $client );
        if ( ! $consumer ) {
            return self::failure( new \WP_Error( 'f3_google_consumer_unregistered', 'Cliente não registrado.' ) );
        }
        $resolved = self::resolve_grant( $consumer['id'] );
        $out = array(
            'contract' => self::CONTRACT,
            'consumer_id' => $consumer['id'],
            'resolution' => 'unreadable',
            'connection_id' => null,
            'reason_codes' => array(),
            'local_status' => null,
            'checked_at' => time(),
        );
        if ( is_wp_error( $resolved ) ) {
            $out['reason_codes'] = array( $resolved->get_error_code() );
            return $out;
        }
        $out['resolution'] = $resolved['resolution'];
        $out['connection_id'] = $resolved['connection_id'];
        if ( 'resolved' !== $out['resolution'] ) {
            $out['reason_codes'] = array( 'ambiguous' === $out['resolution'] ? 'f3_google_consumer_ambiguous' : 'f3_google_consumer_unauthorized' );
            return $out;
        }
        $out['local_status'] = Connections::run( $out['connection_id'], static fn()=>self::local_status( $consumer, $resolved['grant'] ) );
        return $out;
    }
    /** Explicit nested projections: stored arrays never pass through to another plugin. */
    private static function local_status( array $consumer, array $grant ): array {
        $cfg = self::config( $consumer );
        $last = Options::stored( 'f3_mcp_google_ga4_consumer_last_' . Connections::id() . '_' . hash( 'sha256', $consumer['id'] ) );
        $recovery = \Fator3\McpGoogle\Recovery::status();
        $last_service = null;
        $last_error = null;
        if ( ! $last['success'] || ( $last['exists'] && ! is_array( $last['value'] ) ) ) {
            $last_error = 'f3_google_consumer_state_read';
        }
        elseif ( $last['exists'] ) {
            $v = $last['value'];
            $last_service = array(
                'at' => is_int( $v['at'] ?? null ) ? $v['at'] : null,
                'success' => is_bool( $v['success'] ?? null ) ? $v['success'] : null,
                'rows' => is_int( $v['rows'] ?? null ) ? max( 0, $v['rows'] ) : null,
            );
            foreach ( array( 'run_id', 'request_id' ) as $k ) {
                $last_service[ $k ] = is_string( $v[ $k ] ?? null ) && preg_match( '/^[A-Za-z0-9._:-]{1,100}$/D', $v[ $k ] ) ? $v[ $k ] : null;
            }
            $last_service['error_code'] = self::diagnostic_code( $v['error_code'] ?? null );
        }
        $states = Options::snapshot( array( Options::ENABLED, Options::storage_name( Connections::SERVICES ) ) );
        $revision = Settings::revision();
        $read_ok = ! is_wp_error( $revision ) && ! in_array( false, array_column( $states, 'success' ), true );
        return array(
            'configuration' => is_wp_error( $cfg ) ? array(
                'ready' => false,
                'error_code' => $cfg->get_error_code(),
            ) : $cfg,
            'grant' => array(
                'enabled' => ( $grant['enabled'] ?? null ) === true,
                'capability' => ( $grant['capability'] ?? null ) === self::CAPABILITY ? self::CAPABILITY : null,
            ),
            'google_enabled' => $read_ok ? Options::is_enabled() : null,
            'ga_enabled' => $read_ok ? Connections::enabled( 'ga' ) : null,
            'configuration_error' => $read_ok ? null : 'f3_google_option_read',
            'configured' => $read_ok ? Credentials::is_configured() : null,
            'policy_allowed' => $read_ok && ! is_wp_error( $cfg ) ? Policy::permitted( 'ga', $cfg['property'] ) : null,
            'recovery' => array(
                'paused' => is_bool( $recovery['paused'] ?? null ) ? $recovery['paused'] : null,
                'error_code' => self::diagnostic_code( $recovery['error_code'] ?? null ),
            ),
            'last_service' => $last_service,
            'last_service_error' => $last_error,
            'remote_access_verified' => false,
            'consumer_commit_verified' => false,
        );
    }
    private static function diagnostic_code( $value ): ?string {
        return is_string( $value ) && preg_match( '/^f3_[a-z0-9_]{1,95}$/D', $value ) ? $value : null;
    }
    public static function administrative_status( array $input = array() ): array {
        $revision = Settings::revision();
        if ( is_wp_error( $revision ) ) {
            return Response::fail(
                $revision,
                array(
                    'contract' => self::CONTRACT,
                    'connection_id' => Connections::id(),
                    'configuration_revision' => null,
                    'read_success' => false,
                )
            );
        }
        if ( ! empty( $input['compact'] ) ) {
            return Response::ok(
                array(
                    'contract' => self::CONTRACT,
                    'connection_id' => Connections::id(),
                    'configuration_revision' => $revision,
                    'read_success' => true,
                    'compact' => true,
                )
            );
        }
        return Response::ok(
            self::status() + array(
                'configuration_revision' => $revision,
                'read_success' => true,
            )
        );
    }
    public static function client_status( Ga4ConsumerClient $client ): array {
        $c = self::find( $client );
        return $c ? self::status( $c['id'] ) : self::failure( new \WP_Error( 'f3_google_consumer_unregistered', 'Cliente não registrado.' ) );
    }
    public static function status( ?string $only = null ): array {
        $g = self::grants();
        $items = array();
        foreach ( self::$consumers as $id => $c ) {
            if ( null !== $only && $id !== $only ) {
                continue;
            }
            $cfg = self::config( $c );
            $items[] = array(
                'effective_status' => null === $only ? self::effective_status( $c['client'] ) : null,
                'id' => $id,
                'version' => $c['version'],
                'configuration' => is_wp_error( $cfg ) ? array(
                    'ready' => false,
                    'error_code' => $cfg->get_error_code(),
                ) : $cfg,
                'grant' => is_wp_error( $g ) ? null : ( $g[ $id ] ?? null ),
                'last_service' => Options::get( 'f3_mcp_google_ga4_consumer_last_' . Connections::id() . '_' . hash( 'sha256', $id ), null ),
            );
        }
        return array(
            'contract' => self::CONTRACT,
            'connection_id' => Connections::id(),
            'consumers' => $items,
            'grants_error' => is_wp_error( $g ) ? $g->get_error_code() : null,
            'google_enabled' => Options::is_enabled(),
            'configured' => Credentials::is_configured(),
        );
    }
    public static function configure( array $input ): array {
        if ( ! current_user_can( 'manage_options' ) || ! Options::authorized() ) {
            return self::failure( new \WP_Error( 'f3_google_forbidden', 'Permissão administrativa exigida.' ) );
        }
        $id = $input['consumer_id'] ?? '';
        $enabled = $input['enabled'] ?? null;
        if ( ! is_string( $id ) || !preg_match('/^[a-z][a-z0-9-]{1,79}$/D',$id) || ($enabled && ! isset( self::$consumers[ $id ] )) || ! is_bool( $enabled ) || ! is_string( $input['expected_revision'] ?? null ) ) {
            return self::failure( new \WP_Error( 'f3_google_consumer_input', 'Consumidor, enabled e expected_revision são obrigatórios.' ) );
        }
        if (!is_string($input['property']??null) || !self::valid_property($input['property'])) return self::failure(new \WP_Error('f3_google_consumer_input','Informe a propriedade canônica da concessão.'));
        if ($enabled) {
            $cfg=self::config(self::$consumers[$id]);
            if (is_wp_error($cfg)) return self::failure($cfg);
            if ($cfg['property']!==$input['property']) return self::failure(new \WP_Error('f3_google_consumer_property','Propriedade diferente do consumidor.'));
        }
        // Single site lock prevents two simultaneous grants on different connections.
        $lock = \Fator3\McpGoogle\Lock::acquire( 'ga4-consumer-grants', 30 );
        if ( ! $lock ) {
            return self::failure( new \WP_Error( 'f3_google_consumer_busy', 'Concessão em atualização.' ) );
        }
        try {
            if ( $enabled ) {
                foreach ( array_keys( Connections::registry() ) as $cid ) {
                    if ( Connections::id() === $cid ) {
                        continue;
                    }
                    $other = Connections::run( $cid, static fn()=>self::grants() );
                    if ( is_wp_error( $other ) ) {
                        return self::failure( $other );
                    }
                    if ( ! empty( $other[ $id ]['enabled'] ) ) {
                        return self::failure( new \WP_Error( 'f3_google_consumer_connection', 'Revogue a concessão na outra conexão antes de transferir.' ) );
                    }
                }
            }
            $grants = self::grants();
            if ( is_wp_error( $grants ) ) {
                return self::failure( $grants );
            }
            if (!$enabled && !isset($grants[$id])) return Settings::save([],[],[],$input['expected_revision']);
            if (!$enabled && ($grants[$id]['property']??null)!==$input['property']) return self::failure(new \WP_Error('f3_google_consumer_property','Informe a propriedade da concessão a revogar.'));
            if ( ! isset( $grants[ $id ] ) || $grants[ $id ]['enabled'] !== $enabled || ($grants[$id]['property']??null)!==$input['property'] || ($grants[$id]['principal']??null)!==Credentials::execution_identity() || ($enabled && !Options::user_authorized((int)($grants[$id]['granted_by']??0))) ) {
                $grants[ $id ] = array(
                    'enabled' => $enabled,
                    'property' => $input['property'],
                    'granted_by' => get_current_user_id(),
                    'principal' => Credentials::execution_identity(),
                    'capability' => self::CAPABILITY,
                    'revision' => bin2hex( random_bytes( 16 ) ),
                    'at' => time(),
                );
            }
            return Settings::save( array( self::GRANTS => $grants ), array(), array(), $input['expected_revision'] ) + array( 'integration' => self::status() );
        }
        finally {
            \Fator3\McpGoogle\Lock::release( $lock );
        }
    }
}
