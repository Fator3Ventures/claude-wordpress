<?php
/**
 * Public client bound by object identity to a registered consumer.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Ga4ConsumerClient {
	public function query( array $input ): array {
		return Ga4ServiceApi::query( $this, $input );
	}
	public function effective_status(): array {
		return Ga4ServiceApi::effective_status( $this );
	}
	public function status(): array {
		return Ga4ServiceApi::client_status( $this );
	}
}
