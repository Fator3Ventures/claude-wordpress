<?php
/** Minimal property quota observations. No report data is retained. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Ga4Quota {
    private const KEYS=['tokensPerDay','tokensPerHour','tokensPerProjectPerHour','concurrentRequests','serverErrorsPerProjectPerHour','potentiallyThresholdedRequestsPerHour'];
    public static function key(string $property): string {
        return 'f3_mcp_google_ga4_quota_'.hash('sha256',$property);
    }
    public static function valid_quota($quota): bool {
        if (!is_array($quota) || !isset($quota['tokensPerDay'],$quota['tokensPerHour'])) return false;
        foreach ($quota as $name=>$v) {
            if (!in_array($name,self::KEYS,true)) continue;
            if (!is_array($v)) return false;
            foreach (['consumed','remaining'] as $k) if (isset($v[$k]) && (!is_int($v[$k]) || $v[$k]<0)) return false;
        }
        return true;
    }
    public static function valid_state($s): bool {
        return is_array($s) && is_int($s['next_eligible_at']??null) && is_array($s['property_quota']??null) && in_array($s['state']??null,['observed','in_flight','unavailable'],true);
    }
    public static function observation($response,array $previous): array {
        $now=time();
        $next=0;
        $quota=[];
        if (!is_wp_error($response) && self::valid_quota($response['propertyQuota']??null)) {
            foreach (self::KEYS as $key) {
                if (!isset($response['propertyQuota'][$key])) continue;
                $v=$response['propertyQuota'][$key];
                $quota[$key]=['consumed'=>$v['consumed']??0,'remaining'=>$v['remaining']??0];
                if ($quota[$key]['remaining']===0) {
                    // Docs specify PST for daily refresh; using fixed UTC-08 is conservative during DST.
                    $wait=$key==='tokensPerDay' ? (new \DateTimeImmutable('tomorrow',new \DateTimeZone('-08:00')))->getTimestamp() : $now+($key==='concurrentRequests'?30:3600);
                    $next=max($next,$wait);
                }
            }
            return ['observed_at'=>$now,'property_quota'=>$quota,'next_eligible_at'=>$next,'state'=>'observed','scope'=>'local_consumer_calls; external_consumption_may_change_remaining'];
        }
        $data=is_wp_error($response)?(array)$response->get_error_data():[];
        $status=(int)($data['status']??0);
        $next=$now+max((int)($data['retry_after']??0),$status===429?3600:30);
        return ['observed_at'=>$previous['observed_at']??null,'property_quota'=>$previous['property_quota']??[],'next_eligible_at'=>$next,'state'=>'unavailable','scope'=>'last_observation; current_remaining_unknown'];
    }
}
