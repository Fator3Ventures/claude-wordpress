<?php
/**
 * Presentation metadata shared with the versioned configuration contract.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;

use Fator3\McpGoogle\{
	Options, Connections, Setup
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Fields {
	public static function connection_name(): array { return ['label'=>'Nome da conexão','description'=>'Use o nome da conta de serviço e o ID do projeto do Google Cloud como aparecem no Google, separados por ·. Exemplo: wp-mcp-fator3 · <ID do projeto>. Onde ver: Google Cloud → IAM e administrador → Contas de serviço (o nome é o e-mail antes do @) e o seletor de projeto (ID do projeto).']; }
	public static function metadata(): array {
		$rows  = array(
            'consumer_grants' => array('Autorizações de plugins','Concede somente leitura Search Console ao consumidor na conexão escolhida. Propriedade e agenda ficam no Core.','operations',false),
            'gsc_minute_budget'=>array('Search Analytics: tentativas por minuto','Limite local compartilhado pela mesma identidade Google e propriedade, incluindo agentes e plugins.','controls',false),
            'gsc_day_budget'=>array('Search Analytics: tentativas por 24 horas','Janela móvel local; retries também consomem o limite. Não representa a cota do projeto no Google.','controls',false),
			'enabled'               => array( 'Permitir chamadas Google', 'Libera as habilidades e os consumidores de plugins autorizados. Esta opção vale para todas as conexões do site.', 'advanced', false ),
			'auth_mode'             => array( 'Método em uso', 'Cada conexão utiliza um método de autenticação por vez. Preparar credenciais alternativas preserva o método em uso.', 'connection', false ),
			'sa_json'               => array( 'Chave JSON da conta de serviço (Service account key)', 'Arquivo .json baixado uma única vez ao criar a chave. Onde gerar: Google Cloud → IAM e administrador → Contas de serviço → <conta> → aba Chaves → Adicionar chave → Criar nova chave → JSON. Não é o JSON do cliente OAuth nem o token de desenvolvedor do Google Ads.', 'service_account', false ),
			'sa_subject'            => array( 'Usuário representado (delegação em todo o domínio)', 'Opcional. Preencha somente quando um administrador do Workspace autorizou a delegação de domínio para esta conta e os escopos necessários. Vazio utiliza diretamente a Conta de serviço.', 'service_account', true ),
			'oauth_client_id'       => array( 'ID do cliente OAuth (Client ID)', 'Google Cloud → APIs e serviços → Credenciais → IDs do cliente OAuth 2.0 → <cliente do tipo Aplicativo da Web>. Termina em .apps.googleusercontent.com.', 'oauth', false ),
			'oauth_client_secret'   => array( 'Chave secreta do cliente (Client secret)', 'Mesmo caminho do Client ID → Chaves secretas do cliente. Começa com GOCSPX-.', 'oauth', false ),
			'oauth_refresh_token'   => array( 'Autorização da conta Google', 'Gerada ao conectar com Google. O plugin renova o acesso automaticamente. Seu conteúdo permanece oculto.', 'oauth', true ),
			'oauth_email'           => array( 'Conta autorizada', 'E-mail retornado pelo Google após o consentimento. Informação somente para consulta.', 'oauth', false ),
			'oauth_scopes'          => array( 'Permissões concedidas', 'Escopos autorizados pelo usuário. Ao ampliar serviços ou operações, confira se uma nova autorização é necessária.', 'oauth', true ),
			'ads_developer_token'   => array( 'Token de desenvolvedor (Developer token)', '22 caracteres. Onde ver: Google Ads da conta administradora (MCC) → Administrador → Central de API (API Center) → Token de desenvolvedor. Não é o ID do cliente OAuth nem a chave JSON.', 'ads', false ),
			'ads_login_customer_id' => array( 'Conta administradora de acesso (login-customer-id, MCC)', 'Opcional no acesso direto. Informe o ID de dez dígitos da administradora utilizada para acessar a conta de anúncios. Aceita hífens.', 'ads', false ),
			'ads_api_version'       => array( 'Versão da API do Google Ads', 'Padrão desta versão: ' . Options::ADS_VERSION_DEFAULT . '. Ajuste técnico: confirme a compatibilidade e o prazo de suporte da versão na documentação Google antes de alterar.', 'ads', true ),
			'ga_default_property'   => array( 'Propriedade GA4 padrão', 'Utilizada quando uma operação não informa property_id. Sincronizada com a seleção de recursos. O ID da propriedade é numérico; o Measurement ID começa com G-.', 'services', false ),
			'ga_enabled'            => array( 'Analytics habilitado', 'Representado pelo perfil de Analytics em Serviços e recursos. Mantém compatibilidade com as opções anteriores.', 'services', false ),
			'ads_enabled'           => array( 'Google Ads habilitado', 'Representado pelo perfil de Google Ads em Serviços e recursos. Mantém compatibilidade com as opções anteriores.', 'services', false ),
			'services'              => array( 'Serviços e nível de operação', 'Desativado bloqueia o serviço. Leitura consulta dados; escrita permite alterações; administração inclui gestão de usuários quando disponível. O acesso também depende das permissões concedidas no Google.', 'services', false ),
			'bindings'              => array( 'Recursos padrão', 'Selecione os recursos existentes utilizados pelas operações. IDs omitidos nas chamadas usam os padrões quando a operação os suporta. Limpar um campo remove sua seleção.', 'services', false ),
			'connections'           => array( 'Conexões Google', 'Cada conexão reúne uma identidade, serviços e recursos. Conexões distintas podem usar métodos diferentes. Máximo de 20 conexões por site, incluindo a padrão.', 'connection', true ),
			'max_rows'              => array( 'Linhas por relatório', 'Teto de linhas dos relatórios que utilizam este limite. Volumes maiores aumentam o tamanho e o tempo de resposta; confira indicações de truncamento.', 'advanced', true ),
			'http_timeout'          => array( 'Tempo limite HTTP (segundos)', 'Tempo máximo de cada requisição ao Google. Aumentar ajuda em respostas lentas e aumenta o tempo de espera em falhas.', 'advanced', true ),
			'job_detail_days'       => array( 'Dias de detalhes de tarefas', 'Retenção de resultados encerrados, em dias. Não remove tarefas ativas ou resultados incertos sem reconciliação. 0 significa sem prazo, inclusive para registros antigos ainda presentes.', 'advanced', true ),
			'job_summary_days'      => array( 'Dias de resumos e deduplicação', 'Retenção de resumos e reservas de idempotência; 0 significa sem prazo; um prazo positivo deve ser igual ou maior que o dos detalhes. Detalhes sem prazo exigem resumos sem prazo. Reservas de tarefas ainda existentes e resumos de falhas permanecem protegidos.', 'advanced', true ),
			'audit_retention'       => array( 'Eventos de auditoria retidos', '0 mantém todos os eventos, sem limite. Um valor positivo limita a quantidade e permite remover os eventos mais antigos.', 'advanced', true ),
			'inspection_budget'     => array( 'Inspeções de URL por propriedade em 24 horas', 'Limite local em janela móvel de 24 horas, compartilhado entre as conexões deste WordPress por propriedade Search Console. Há também teto local de 25 por minuto. Este ajuste não amplia a cota do Google.', 'advanced', true ),
		);
		$out   = array();
		$order = 0;
		foreach ( $rows as $id => $r ) {
			$out[ $id ] = array(
				'label'       => $r[0],
				'description' => $r[1],
				'group'       => $r[2],
				'advanced'    => $r[3],
				'order'       => ++$order,
			);
			if ( in_array( $r[2], Options::AUTH_MODES, true ) ) {
				$out[ $id ]['visible_when'] = array( 'method_panel' => $r[2] );
			}
		}
		$out['sa_json']['max_bytes'] = \Fator3\McpGoogle\Auth\Configuration::JSON_MAX_BYTES;
		return $out;
	}
	public static function resources(): array {
		return array(
			'gtm_container_path' => array(
				'label'       => 'Contêiner Tag Manager',
				'description' => 'Selecione o contêiner pelo nome após consultar sua conta na aba GTM.',
				'service'     => 'gtm',
				'placeholder' => 'accounts/123/containers/456',
			),
			'ga_property_id'     => array(
				'label'       => 'Propriedade GA4 padrão',
				'description' => 'Escolha a propriedade ou informe seu ID numérico. Local: Analytics → Administrador → Detalhes da propriedade. Exemplo: 123456789.',
				'service'     => 'ga',
				'placeholder' => '123456789',
			),
			'ads_customer_id'    => array(
				'label'       => 'Conta de anúncios padrão',
				'description' => 'ID de dez dígitos da conta consultada, exibido no Google Ads. A administradora de acesso (MCC) tem um campo próprio abaixo.',
				'service'     => 'ads',
				'placeholder' => '123-456-7890',
			),
			'gsc_site_url'       => array(
				'label'       => 'Propriedade Search Console',
				'description' => 'Use a propriedade exata cadastrada no Search Console: domínio (sc-domain:exemplo.com.br) ou prefixo (https://exemplo.com.br/).',
				'service'     => 'gsc',
				'placeholder' => 'sc-domain:exemplo.com.br',
			),
			'spreadsheet_id'     => array(
				'label'       => 'Planilha padrão',
				'description' => 'Selecione a planilha ou cole sua URL do Google Sheets. Compartilhe o arquivo com a identidade conectada. Para exportar relatórios, conceda edição.',
				'service'     => 'sheets',
				'placeholder' => 'https://docs.google.com/spreadsheets/d/…/edit',
			),
			'sitemap_url'        => array(
				'label'       => 'URL do sitemap',
				'description' => 'Endereço HTTPS completo do sitemap publicado. A sugestão usa a configuração do WordPress/Yoast; confira sua publicação antes de enviar pelo fluxo de sitemap.',
				'service'     => 'gsc',
				'placeholder' => 'https://exemplo.com.br/sitemap_index.xml',
			),
		);
	}
	public static function services(): array {
		return array(
			'gtm'              => array(
				'label' => 'Google Tag Manager',
				'help'  => 'Habilite a Tag Manager API no Cloud. Conceda acesso ao e-mail da Conta de serviço na conta e no contêiner. Escrita inclui versões e publicação; administração inclui usuários, conta e exclusão de contêiner. Confira as permissões de publicação no GTM.',
				'url'   => 'https://tagmanager.google.com/',
			),
			'ga'               => array(
				'label' => 'Google Analytics 4',
				'help'  => 'Adicione o e-mail em Administrador → Gerenciamento de acesso à propriedade. Leitor para consulta; Editor para alterações; Administrador para gerenciar usuários.',
				'url'   => 'https://analytics.google.com/',
			),
			'ads'              => array(
				'label' => 'Google Ads',
				'help'  => 'Adicione o e-mail em Administrador → Acesso e segurança, diretamente na conta ou na MCC. Defina o papel necessário e preencha o token de desenvolvedor abaixo.',
				'url'   => 'https://ads.google.com/',
			),
			'gsc'              => array(
				'label' => 'Search Console',
				'help'  => 'Conceda acesso à propriedade em Configurações → Usuários e permissões. Confira o nível exigido para consultar, enviar sitemap ou gerenciar proprietários.',
				'url'   => 'https://search.google.com/search-console',
			),
			'siteverification' => array(
				'label' => 'Site Verification',
				'help'  => 'Use para verificar controle do site ou gerenciar a propriedade. A operação exige a prova de controle indicada pelo Google (por exemplo, arquivo ou meta tag).',
				'url'   => 'https://developers.google.com/site-verification/v1/getting_started',
			),
			'sheets'           => array(
				'label' => 'Google Sheets',
				'help'  => 'Compartilhe uma planilha existente com a identidade conectada. Em Conta de serviço direta, criar um arquivo exige destino em Drive compartilhado.',
				'url'   => 'https://sheets.google.com/',
			),
			'drive'            => array(
				'label' => 'Google Drive',
				'help'  => 'Usado em arquivos e compartilhamento. Uma Conta de serviço direta não possui cota nem pode ser proprietária de arquivos. Uma pasta compartilhada do Meu Drive não equivale a um Drive compartilhado.',
				'url'   => 'https://drive.google.com/',
			),
		);
	}
	public static function effective_services(): array {
		$selected = Options::get( Connections::SERVICES, null );
		if ( is_array( $selected ) ) {
			return $selected;
		}
		$selected = array();
		foreach ( Setup::LEVELS as $service => $levels ) {
			if ( 'gtm' === $service ) {
				continue; }
			if ( ( 'ga' === $service && ! Options::ga_enabled() ) || ( 'ads' === $service && ! Options::ads_enabled() ) ) {
				continue;
			}
			$selected[ $service ] = in_array( $service, array( 'ga', 'gtm' ), true ) ? 'admin' : 'write';
		}
		return $selected;
	}
}
