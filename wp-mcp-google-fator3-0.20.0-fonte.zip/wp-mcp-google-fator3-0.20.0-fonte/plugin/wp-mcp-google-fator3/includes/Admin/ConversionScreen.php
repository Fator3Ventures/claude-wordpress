<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{ConversionDelivery as Delivery,Connections,Options,Admin,Automation\Execution};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class ConversionScreen {
    public static function render(): void {
        if (!Options::authorized()) wp_die('Permissão insuficiente.');
        OperationsScreen::render(true);
        $s=Delivery::status();$c=$s['config']??Delivery::defaults();$property=explode('/',$c['stream'])[1]??'';$result=null;
        if (($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
            check_admin_referer('f3-google-conversions');
            $kind=sanitize_key($_POST['action_kind']??'configure');
            if ($kind==='verify') $result=Delivery::verify(['expected_revision'=>Admin::posted('revision'),'target'=>Admin::posted('target')]);
            elseif ($kind==='resources') {
                foreach(['stream','customer_id','conversion_action'] as $key) $c[$key]=Admin::posted($key);
                $property=Admin::posted('property_id');
                $result=Execution::run(static function() use($c,$property) {
                    $results=[ResourceChoices::load('ga'),ResourceChoices::load('ads')];
                    if ($property) $results[]=ResourceChoices::load('stream','properties/'.$property);
                    if ($c['customer_id']) $results[]=ResourceChoices::load('action',$c['customer_id']);
                    return ['success'=>!array_filter($results,static fn($r)=>empty($r['success'])||empty($r['complete']))];
                });
            } else {
                $config=['enabled'=>isset($_POST['enabled'])];
                foreach(['stream','customer_id','conversion_action'] as $key) $config[$key]=Admin::posted($key);
                $result=Delivery::configure(['expected_revision'=>Admin::posted('revision'),'config'=>$config,'mp_secret'=>wp_unslash($_POST['mp_secret']??''),'clear_mp_secret'=>isset($_POST['clear_mp_secret'])]);
            }
            $s=Delivery::status();if ($kind!=='resources') $c=$s['config']??$c;
        }
        if ($result) echo '<div class="notice '.(!empty($result['success'])?'notice-success':'notice-warning').'"><p>'.esc_html(!empty($result['success'])?'Operação concluída.':($result['message']??'Operação não concluída. Confira o acesso e as seleções.')).'</p>'.self::diagnostic($result['provider_error']??null).'</div>';
        self::readiness_card();
        echo '<section class="f3-card"><h2>Entrega de conversões</h2><p>Autorize os destinos, verifique o acesso e selecione o transporte pelo servidor no Site Core.</p><table class="widefat striped"><thead><tr><th>Destino</th><th>Prontidão</th><th>Última verificação</th><th>Próxima renovação</th></tr></thead><tbody>';
        $reasons=['ok'=>'Pronto','integration_disabled'=>'Integração desabilitada','channel_disabled'=>'Ative o canal na aba Conexão','destination_missing'=>'Selecione um destino; configure a medição no Site Core','verification_required'=>'Verifique o destino','core_async_unsupported'=>'Instale a atualização do Core com consulta de confirmação Ads','grant_revoked'=>'Renove a autorização administrativa','mp_secret_missing'=>'Informe o segredo do fluxo de dados','service_disabled'=>'Habilite o serviço na aba Conexão','service_read_only'=>'Autorize escrita na aba Conexão','ads_developer_token_missing'=>'Informe o token de desenvolvedor na aba Conexão','resource_not_permitted'=>'Revise as permissões por recurso','ambiguous_connection'=>'Mantenha uma única conexão habilitada por destino'];
        foreach(['ga4'=>'Google Analytics','google_ads'=>'Google Ads'] as $target=>$label) {
            $v=$s[$target]??[];$renew=$v['renewal']??[];
            echo '<tr><td>'.esc_html($label).'</td><td>'.esc_html(!empty($v['verification_pending'])?(!empty($v['ready'])?'Pronto; nova validação agendada':'Aguardando nova validação automática'):($reasons[$v['reason']??'']??'Confira a conexão e as credenciais')).'</td><td>'.esc_html(!empty($v['verified_at'])?wp_date('d/m/Y H:i',$v['verified_at']):'Ainda não verificado').'</td><td>'.esc_html(!empty($renew['next_attempt'])?wp_date('d/m/Y H:i',$renew['next_attempt']):'Após a primeira verificação').'</td></tr>';
        }
        echo '</tbody></table><p>O cron renova a verificação antes de vencer. Falhas geram incidente e aviso ao e-mail administrativo; confira a aba Incidentes.</p></section><section class="f3-card"><h2>Destinos</h2><p><strong>ID de medição GA4:</strong> '.esc_html(Delivery::measurement_id()?:'Configure no Site Core').'. Lido do Site Core.</p><form method="post" class="f3-form">';
        self::hidden($s['revision']??'');
        echo '<p><label><input type="checkbox" name="enabled" '.checked(!empty($c['enabled']),true,false).'> Autorizar entregas pelo Core nesta conexão</label></p>';
        ResourceChoices::select('property_id','Propriedade Google Analytics',$property,ResourceChoices::items('ga'));
        ResourceChoices::select('stream','Fluxo de dados',$c['stream'],ResourceChoices::items('stream','properties/'.$property));
        ResourceChoices::select('customer_id','Conta Google Ads',$c['customer_id'],ResourceChoices::items('ads'));
        ResourceChoices::select('conversion_action','Ação de conversão importada',$c['conversion_action'],ResourceChoices::items('action',$c['customer_id']));
        echo '<p><button class="button" name="action_kind" value="resources">Consultar listas da conta</button></p><p>Após escolher outra conta ou propriedade, consulte novamente para carregar suas ações e fluxos. A ação Ads precisa ser do tipo Site — Importação de cliques, estar ativa e ter valor e moeda configurados. O envio usa o valor e a moeda lidos da ação.</p><p><label for="mp_secret">Segredo da API do fluxo de dados</label><input id="mp_secret" name="mp_secret" type="password" autocomplete="new-password"></p><p>Vazio preserva o segredo. Estado: '.(!empty($s['mp_secret_present'])?'presente':'ausente').'.</p><label><input type="checkbox" name="clear_mp_secret"> Remover segredo</label><p><button class="button button-primary" name="action_kind" value="configure">Salvar destinos e autorização</button></p></form></section><section class="f3-card"><h2>Verificar acesso</h2><p>Consulta o destino e valida um evento sem coletá-lo. Mudanças de credencial, segredo, destino ou autorização exigem nova verificação. Ads usa Data Manager; não é necessário um comprovante de envio anterior.</p><form method="post">';
        self::hidden($s['revision']??'');
        echo '<input type="hidden" name="action_kind" value="verify"><label for="f3-verify-target">Destino</label> <select id="f3-verify-target" name="target"><option value="ga4">Google Analytics</option><option value="google_ads">Google Ads</option></select> <button class="button">Verificar destino</button></form></section>';
        OperationsScreen::profiles();
    }
    public static function diagnostic($diagnostic): string {
        if (!is_array($diagnostic)) return '';
        $items=[];
        foreach (['http_status'=>'HTTP','status'=>'Estado Google','reason'=>'Motivo','message'=>'Mensagem Google'] as $key=>$label)
            if (!empty($diagnostic[$key])) $items[]=$label.': '.$diagnostic[$key];
        foreach ($diagnostic['field_violations']??[] as $v) $items[]='Campo: '.($v['field']??'').' · '.($v['reason']??'').' · '.($v['message']??'');
        return '<ul class="f3-provider-diagnostic"><li>'.implode('</li><li>',array_map('esc_html',$items)).'</li></ul>';
    }
    private static function hidden(string $revision): void {
        wp_nonce_field('f3-google-conversions');
        echo '<input type="hidden" name="connection_id" value="'.esc_attr(Connections::id()).'"><input type="hidden" name="revision" value="'.esc_attr($revision).'">';
    }
    /** Local verdict of google/readiness-status at the top of the screen (0.18.0). */
    private static function readiness_card(): void {
        $r=\Fator3\McpGoogle\Readiness::read([]);
        if (empty($r['success'])) return;
        $names=['ready'=>'Pronta','attention'=>'Requer atenção','blocked'=>'Bloqueada'];
        echo '<section class="f3-card" id="f3-readiness" data-state="'.esc_attr($r['state']).'"><h2>Prontidão operacional</h2><p><strong>'.esc_html($names[$r['state']]??$r['state']).'</strong>. Leitura local da conexão, sem consulta ao Google.</p>';
        if (!empty($r['actions'])) {
            echo '<ol>';
            foreach ($r['actions'] as $action) echo '<li>'.esc_html($action).'</li>';
            echo '</ol>';
        }
        echo '<p class="description">A mesma leitura está em google/readiness-status.</p></section>';
    }
}
