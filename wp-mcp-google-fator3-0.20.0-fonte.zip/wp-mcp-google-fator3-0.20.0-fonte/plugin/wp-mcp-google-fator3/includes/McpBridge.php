<?php
/**
 * Adds independently annotated query/mutation tools to a compatible MCP channel.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class McpBridge {
    public static function sdk_available(): bool {
        $sdk='\\Fator3\\McpFiles\\ExecutorRegistry';
        if(!is_callable([$sdk,'capabilities'])||!is_callable([$sdk,'register']))return false;
        try {
            $c=$sdk::capabilities();
        }
        catch(\Throwable $e){
            return false;
        }
        return ($c['contract']??'')==='executor-registration/1.0.0'&&($c['available']??false)===true&&($c['schema_revision']??null)===1;
    }
    public static function declare(string $contract): void {
        if($contract!=='executor-registration/1.0.0'||!self::sdk_available())return;
        foreach(['read','write'] as $mode) {
            \Fator3\McpFiles\ExecutorRegistry::register(['contract'=>$contract,'ability'=>'google/mcp-'.$mode,
                    'provider'=>'wp-mcp-google-fator3','mode'=>$mode,
                    'allowed_targets'=>['names'=>[],'prefixes'=>['ga/','ads/','google/','gsc/','siteverification/','gtm/']]]);
        }
    }
    public static function init(): void {
        add_action('f3_mcp_register_executors',[self::class,'declare']);
        add_filter(
            'f3_mcp_default_server_config',
            static function ( array $config, array $identity ): array {
            if ( class_exists('\\Fator3\\McpFiles\\ExecutorRegistry') || ! McpServer::accepts( $identity ) ) {
                return $config;
            }
            $config['tools'] = array_values( array_unique( array_merge( $config['tools'] ?? array(), array( 'google/mcp-read', 'google/mcp-write' ) ) ) );
            return $config;
            },
            10,
            2
        );
    }
    public static function dispatch( array $input, bool $write ): array {
        $name = (string) ( $input['ability'] ?? '' );
        $parameters = $input['parameters'] ?? array();
        if ( ! is_array( $parameters ) || in_array( $name, array( 'google/mcp-read', 'google/mcp-write' ), true ) ) {
            return self::failure( 'f3_google_mcp_input', 'Habilidade ou parâmetros inválidos.' );
        }
        $ability = wp_get_ability( $name );
        if ( ! $ability || 'google' !== $ability->get_category() ) {
            return self::failure( 'f3_google_mcp_ability', 'Esta ferramenta executa somente habilidades Google.' );
        }
        $meta = $ability->get_meta();
        if(!preg_match('~^(ga|ads|google|gsc|siteverification|gtm)/~',$name)||($meta['fator3']['provider']??null)!==Channel::PROVIDER||!empty($meta['fator3']['executes_ability']))return self::failure('f3_google_mcp_ability','Provedor ou executor fora do domínio Google.');
        $mode = $meta['fator3']['mode'] ?? null;
        if ( in_array( $name, array( 'google/execute-action', 'google/execute-read' ), true ) ) {
            $op = Operation::method( (string) ( $parameters['api'] ?? '' ), (string) ( $parameters['method'] ?? '' ) );
            if ( is_wp_error( $op ) ) {
                return self::failure( $op->get_error_code(), $op->get_error_message() );
            }
            $mode = $op['mode'];
        }
        if ( ( $write ? 'write' : 'read' ) !== $mode ) {
            return self::failure( 'f3_google_mcp_mode', 'A operação não pertence a esta ferramenta. Use a ferramenta de consulta ou mutação correspondente.' );
        }
        $parameters['connection_id'] = $input['connection_id'] ?? Connections::id();
        $allowed = Channel::authorize( $name, $parameters, 'read' === $mode );
        if ( is_wp_error( $allowed ) ) {
            return self::failure( $allowed->get_error_code(), $allowed->get_error_message() );
        }
        $result = $ability->execute( $parameters );
        if ( is_wp_error( $result ) ) {
            $result = Response::fail( $result );
        }
        if ( ! is_array( $result ) ) {
            return self::failure( 'f3_google_mcp_result', 'Resultado inválido.' );
        }
        if ( empty( $result['success'] ) ) {
            $result['error'] = $result['message'] ?? 'Operação reprovada.';
        }
        return $result;
    }
    private static function failure( string $code, string $message ): array {
        return Response::fail( new \WP_Error( $code, $message ) ) + array( 'error' => $message );
    }
    public static function register(): void {
        foreach ( array(
                'read' => false,
                'write' => true,
            ) as $mode => $write ) {
            Ability::register(
                'google/mcp-' . $mode,
                'any',
                array(
                    'label' => $write ? 'Google: executar mutação' : 'Google: executar consulta',
                    'description' => $write ? 'Executa habilidades de mutação com os mesmos gates, políticas e confirmações.' : 'Executa exclusivamente habilidades classificadas como consulta; recusa mutações antes da execução.',
                    'mode' => $write ? 'write' : 'read',
                    'input_schema' => array(
                        'required' => array( 'ability' ),
                        'properties' => array(
                            // 0.18.0: parameter descriptions in Portuguese, as shown in the MCP tool list.
                            'ability' => array(
                                'type' => 'string',
                                'description' => $write ? 'Nome da habilidade Google de escrita a executar, por exemplo ads/update-campaign. Habilidades de consulta são recusadas antes da execução.' : 'Nome da habilidade Google de consulta a executar, por exemplo ga/run-report ou google/readiness-status. Habilidades de escrita são recusadas antes da execução.',
                            ),
                            'parameters' => array(
                                'type' => 'object',
                                'description' => 'Parâmetros da habilidade indicada, no formato do schema de entrada dela (consulte google/ability-catalog). Omita para habilidades sem parâmetros.',
                            ),
                        ),
                    ),
                    'callback' => static fn ( array $input ) => self::dispatch( $input, $write ),
                    'meta' => array(
                        'fator3' => array( 'executes_ability' => true ),
                        'annotations' => array(
                            'readonly' => ! $write,
                            'destructive' => $write,
                        ),
                    ),
                )
            );
        }
    }
}
