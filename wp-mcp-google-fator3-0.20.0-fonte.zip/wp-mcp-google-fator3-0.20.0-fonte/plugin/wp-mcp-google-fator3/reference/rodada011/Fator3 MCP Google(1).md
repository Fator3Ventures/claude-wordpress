# Pedidos — Fator3 MCP Google (wp-mcp-google-fator3)

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no pacote **wp-mcp-google-fator3** (rotas `ga/*`, `ads/*`, `gsc/*`, `siteverification/*`, `google/*`, `gtm/*`; Conector WP MCP §3.6). Em outros documentos, cite como "Pedidos MCP Google N". Serve também de documento para o responsável pelo pacote. Base: 0.9.0. A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba. Conteúdo movido do documento "Pedidos — Fator3 MCP Google" em 16/10/2026, com a numeração mantida.

**Situação em 16/10/2026: pendente o 25, aberto em 16/10 pela conferência ao padrão de entrega.** Versão instalada nos 12 sites da frota: 0.10.0 (ZIP `wp-mcp-google-fator3-0.10.0-instalador.zip`, sha256 `3e30634b…`, no `main` do repositório, commit `4074a78`), instalada em 16/10/2026 direto sobre a 0.9.0, antes do Fator3 MCP 0.23.0 em cada site; nos 12 pela frota (no Site-Teste a 0.9.0 tinha sido preservada pelos agentes dos outros pacotes), com `applied` na primeira chamada e sondas `/` e `/wp-json/` 200 antes e depois. Saiu o 24 (conferido na 0.10.0: o relatório cita `wp-mcp-google-fator3-0.10.0-fonte.zip`, 2.615.432 bytes, sha256 `c8a31a7e…`, igual ao do arquivo entregue; `google/documentation` responde em ctooffice com 15 documentos e paginação por byte). Os itens 1 a 24 saíram desta lista e não se pedem de novo. Sem exercício na frota: a coleta completa por jobs, o calendário, a exportação com `require_complete` e o limite de envelope de 1 MiB com paginação de job; o aceite em produção do que não foi exercitado fica no estado da frota (pendência 20). Próxima entrega sem data.

**Numeração.** Item novo recebe o próximo número (hoje, 26; o 13 foi usado pelo plano do pacote na 0.7.0) e vai no fim; item retirado deixa o número vago.

## wp-mcp-google-fator3 — pendentes

**25. Cabeçalho declara requisitos mínimos que a versão não comprovou, e a tabela de identidade do relatório aponta para o ambiente do agente** (0.10.0, Padrão de entrega dos pacotes Fator3, aba Fator3 MCP Google, 16/10/2026). O cabeçalho da 0.10.0 traz `Requires at least: 6.4` e `Requires PHP: 8.0`, e o relatório registra que esses mínimos não foram comprovados nesta matriz (WordPress 7.1.2/PHP 8.3.6; item A21 parcial). Os links do instalador e da fonte na tabela de identidade apontam para `sandbox:/workspace/scratch/…`, caminho que só existe no ambiente do agente. Pedido: (a) rodar a instalação limpa e a atualização direta no mínimo declarado, ou declarar no cabeçalho o mínimo que a matriz cobriu; (b) citar na tabela só o nome do arquivo. Aceite: o relatório da próxima versão traz a linha da matriz no mínimo que o cabeçalho declara e a tabela de identidade sem caminho local.

## Decidido não fazer

Da lista comum da frota, o que toca o pacote Google:

- Mover emissão de tag ou consentimento para o pacote Google.
- Rota para o vínculo GA4 ↔ Search Console (a Admin API não expõe `searchConsoleLinks` — catálogo de `google/list-actions`, 23/09; fica como passo humano, Padrão §12).
