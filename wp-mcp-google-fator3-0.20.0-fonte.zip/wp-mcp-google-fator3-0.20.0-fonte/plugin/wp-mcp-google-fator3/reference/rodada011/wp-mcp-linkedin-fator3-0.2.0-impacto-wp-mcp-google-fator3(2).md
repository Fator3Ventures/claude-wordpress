# Impacto de Fator3 MCP LinkedIn 0.2.0 em wp-mcp-google-fator3

Data/hora: 2026-10-16T13:00:13+00:00 · Revisão: 1
Instalador emissor: `wp-mcp-linkedin-fator3-0.2.0-instalador.zip` · SHA-256 `64da9956452d3943546758690cf5cb5ff6508cbf502780bbcc1ca1492e6e8324`
Destinatário examinado: 0.10.0 no laboratório — SHA-256 3e30634b1d1f87b9b4fdeba2a37ac382b1394a1ec7f7235166aa15d107ef8b52; 0.9.0 preservado no fator3-teste
Classificação: **sem-acao** · Ticket/recorte: **S01/S04/S06 — fronteiras**

## Mudança e consequência

Os plugins sociais mantêm tabelas, namespaces, REST, cron, credenciais e exportações próprios. Não acrescentam exportação Sheets/BigQuery, cliente Google nem migração Porter.

## Ação do responsável

Sem ação necessária no escopo avaliado: manter contratos Google independentes. Se surgir demanda de exportação social para Google, abrir contrato novo antes de implementar; esta entrega não o pressupõe.

## Compatibilidade e sequência

Google 0.10.0 participou do laboratório com Core/MCP e sociais em ambas as ordens. O Google 0.9.0 do site de teste não foi atualizado. A prova é de convivência/isolamento; não é homologação de serviços Google.

## Validação e evidência

Fonte: `plugin/wp-mcp-linkedin-fator3/includes/` e `docs/input-schemas.json`; relatório `wp-mcp-linkedin-fator3-0.2.0-relatorio.md`. A bateria final de atualização executou 49 verificações em WordPress 7.1.2/PHP 8.3.6; o mínimo WordPress 6.4/PHP 8.1.2 passou em 46 verificações. Há sete provas funcionais de JavaScript/REST no painel. Arquivos do fator3-teste conferidos por SHA-256, sem extras. O relatório separa versões intermediárias de teste da identidade final.

Leituras reais de Meta/LinkedIn, entrega de webhook e alterações do destinatário não foram homologadas por esta rodada. A classificação não transfere responsabilidades nem declara implementada uma alteração de outro pacote.

## Resposta esperada

Informar `implementado`, `planejado`, `não aplicável` ou `bloqueado`, com versão, contrato e evidência. Este documento foi preparado para encaminhamento; não foi enviado a pessoas ou sistemas.
