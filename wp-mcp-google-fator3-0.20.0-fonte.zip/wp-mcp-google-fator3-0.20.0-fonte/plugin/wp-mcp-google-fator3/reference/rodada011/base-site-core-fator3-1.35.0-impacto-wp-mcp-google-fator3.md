# Impacto de base-site-core-fator3 1.35.0 em wp-mcp-google-fator3

Revisão 3 · Etapa: entrega · Data: 2026-10-17 UTC · Situação: aberto para o destinatário
Emissor: Fator3 Site Core, base 1.34.0 → alvo 1.35.0 implementado.
Instalador: `base-site-core-fator3-1.35.0-instalador.zip` · SHA-256 `1368395e6c5842c21e822010310c1d544000ed7d72b2f6ee234491d18c686f20`.
Pedido: 222 · Classificação: decisao-necessaria. Preparado para o dono; não enviado ao destinatário.

## Resultado desta entrega

Leitura pelo consumidor real Google 0.10.0 passou: descritor, snapshot, seis slots e catálogo paginado. A proposta inicial de acrescentar nome ao catálogo foi **substituída** na revisão 2: a enumeração é fechada e permanece intacta. Material é emitido como download_material e configurado no contrato administrativo 8.1.0.

Responsáveis Google/Core: decidir revisão do contrato que exponha material, manter contato e material separados em receitas/eventos-chave/GTM e validar consumo coordenado. O slot Ads atual descreve somente contato. A descoberta completa de material por Google 0.10.0 permanece pendente; esta entrega não modifica nem declara concluído trabalho do destinatário. Aceite futuro: negociação explícita de versão, enumeração/configuração material legível e regressão do consumidor existente sem mapear material para contato.

## Histórico de planejamento e implementação (superado onde indicado)

Revisão 1 · Etapa: planejamento · Data: 2026-10-16 · Situação: aberto
Classificação: validacao-coordenada · Natureza: contrato/configuração/requisitos
Base: 1.34.0 (SHA-256 3d3d3ffa084026a0f36e3badf852cba8aeb30620503878534328bddb9a260be1). Alvo 1.35.0 previsto; instalador ainda não gerado.

Pedido 222: novo evento GA4 download_material e conversão Ads de material independente. Catálogo público de eventos inclui material; SDK de medição 1.0/schema 1 mantém os seis slots e campos de contato existentes. Valores de configuração material ficam no catálogo administrativo. Google 0.10 deve preservar nomes diferentes e não mapear material para generate_lead/ação Contato; validar recipes/GTM e eventos importados. Responsáveis Google/Core: teste coordenado do catálogo, sem assumir que o slot conversion_label descreve material.

Critério de aceite: confirmar os contratos no binário e demonstrar material separado de contato, preservação de configurações anteriores e autorização administrativa. Não há aprovação do destinatário nem mudança do seu pacote nesta rodada. Documento será atualizado com resultados e hash final. Preparado para encaminhamento; não enviado.

## Implementação — revisão 2

A inspeção do consumidor Google 0.10.0 identificou enumeração fechada dos nomes em `includes/Data/CoreMeasurement.php`. Por isso, não será acrescentado `download_material` ao SDK 1.0.0: além dos seis slots, sua lista de nomes permanece compatível. A descrição de `generate_lead` explicita que exclui conteúdo. O evento de material opera nos emissores próprios do Core e sua configuração completa pertence ao contrato administrativo 8.1.0.

Consequência: Google 0.10.0 não descobre a configuração nem o evento de material pelo SDK 1.0.0. Para ampliar a descoberta, os responsáveis Core/Google devem negociar revisão explícita do contrato e validar os consumidores antes de promoção. Não criar automaticamente evento-chave GA4 nem ação Google Ads. A configuração material pode ser feita pelo catálogo administrativo do Core. A validação desta entrega cobre a continuidade da leitura do contrato 1.0.0 pelo Google 0.10.0.
