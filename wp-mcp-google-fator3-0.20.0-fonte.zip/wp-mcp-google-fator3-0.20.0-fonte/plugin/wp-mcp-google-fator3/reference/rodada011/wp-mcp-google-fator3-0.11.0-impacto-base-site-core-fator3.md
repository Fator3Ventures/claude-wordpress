# Impacto de wp-mcp-google-fator3 0.11.0 em base-site-core-fator3

Revisão 1 · 16/10/2026 · Etapa: planejamento · Situação: aberto
Base Google: 0.10.0, SHA-256 3e30634b1d1f87b9b4fdeba2a37ac382b1394a1ec7f7235166aa15d107ef8b52.
Alvo Google: 0.11.0 previsto; instalador ainda não gerado.
Destinatário: Core 1.35.0, SHA-256 1368395e6c5842c21e822010310c1d544000ed7d72b2f6ee234491d18c686f20.
Classificação: decisao-necessaria · Natureza: contrato · Pedido Core 222; I01/GSC.

## Mudança e consequência

O SDK `site-measurement-context/1.0.0` possui schemas fechados, seis slots e enumeração de eventos. O Core 1.35.0 preservou esse contrato; `download_material` e a configuração de material não são descobertos por ele. O slot Ads continua descrevendo contato. O Google 0.11.0 manterá esse consumidor sem ler opções privadas e documentará explicitamente esse limite nas receitas/GTM/eventos-chave.

## Decisão proposta e responsável

Proposta ao responsável Core: publicar um contrato optativo separado e versionado para conversões por finalidade, preservando integralmente `site-measurement-context/1.0.0`. O descritor deve anunciar método, schema e versão exata; a resposta deve separar `contact` e `material`, expor o nome efetivo do evento GA4 e os identificadores públicos específicos por destino, estado habilitado/configurado, procedência e revisão. Segredos e estados de consentimento por visitante ficam fora desse contrato. Os nomes finais dependem do aceite e da publicação Core.

Alternativa: nova versão negociada de todo o contexto; exige manter uma resposta 1.0.0 para consumidores anteriores. Acrescentar silenciosamente campos ou eventos no 1.0.0 fechado é incompatível e não foi adotado.

## Compatibilidade e aceite

Antes de implementar o novo consumidor: Core publica schemas, descritor e fixtures; Google valida negociação, versão não suportada, autorização, revisão paginada e ausência de mapeamento material → contato. Recusa/ausência do contrato afeta só a descoberta adicional. Nada cria automaticamente evento-chave GA4, ação Ads, tag ou publicação GTM. Configuração administrativa Core 8.1.0 permanece o caminho existente para material.

## Validação prevista

Nesta rodada: leitura real do contrato 1.0.0 no Core 1.35.0 pelo consumidor Google, seis slots, catálogo paginado e autorização; testes SDK GSC existentes. Ampliação de descoberta de material permanece pendente do produtor. Nenhum arquivo Core será alterado.

## Evolução

Responde à revisão 3 do impacto Core 1.35.0: preserva a decisão de não ampliar a enumeração 1.0.0. Histórico não apagado; este documento contém a proposta do consumidor. Preparado para o dono, sem envio.


## Entrega — revisão 2, 16/10/2026

Etapa: entrega · Situação: **aberto — decisão de contrato**. Instalador Google: `wp-mcp-google-fator3-0.11.0-instalador.zip`, 704694 bytes, SHA-256 `d181deaeee8ef365ac4d6a08884d9fa3d3a3164b21f0538d8ed5d56722536bf9`. A revisão 1 acima é o histórico de planejamento.

Implementado: documentação instalada de receitas/contratos/guia explicita a separação de material e contato e o limite de descoberta. Os schemas e o consumidor 1.0.0 não foram modificados. O Google não cria eventos-chave, ações Ads ou tags ao consultar o contexto.

Prova própria: Core 1.35.0 real, seis slots e catálogo paginado aceitos pelo consumidor; conflito real transportado corretamente no MCP 0.23.0; SDK GSC com conexão não padrão, concessão explícita e execução user:0 passou com respostas Google simuladas. Evidências: `public-sdk.json`, `core.json` e `contracts011.json` na matriz `evidence/011`. A ausência de download_material no catálogo foi explicitamente verificada; não é apresentada como descoberta completa. No Site-Teste ambos convivem, Google 0.11.0/Core 1.35.0, sem alteração de configuração de material.

Ação restante do responsável Core: aceitar o contrato optativo por finalidade ou propor a evolução negociada alternativa, publicar schemas/descritor/fixtures e responder antes da implementação dependente. Responsável Google: adaptar e validar o consumidor somente após essa publicação. Critérios de aceite da revisão 1 mantidos. I01/GSC compatível no escopo local exercitado; homologação Google real permanece pendente. Nenhum código Core foi alterado e nenhum encaminhamento foi enviado.
