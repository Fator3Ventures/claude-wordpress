# Impacto de wp-mcp-google-fator3 0.13.0 em base-site-core-fator3

Revisão 2 · 20/10/2026 · Etapa: entrega · Situação: aberto / bloqueio
Emissor: Google, base 0.12.0, entrega 0.13.0; instalador identificado abaixo.
Destinatário: Core, base 1.38.0, candidato examinado 1.39.0. Pedido Core 235.
Entrada: impacto Core 1.39.0 → Google, revisão 2, e código/relatório recebidos.

## Decisão desta rodada

A 0.13.0 conclui o pedido MCP Google 27 do plano aprovado. O contrato de leitura `site-conversion-purposes/1.0.0` permanece igual. O novo transporte `site-conversion-delivery/1.0.0` foi analisado, mas não será anunciado como disponível nem será instalado o Core 1.39.0 no Site-Teste por esta entrega. A implementação dependente aguarda alinhamento abaixo. Não há adaptador de entrega Google nesta versão, nem configuração comercial nova.

## Bloqueio concreto

O worker Core grava `incerto/envio_iniciado` antes de `send()`, aceita apenas `entregue` ou `recusado` (este exige `non_delivery_proven`) e nunca seleciona `incerto` novamente. Não existe contrato público para guardar um recibo externo e consultar seu resultado, ou reconciliar um estado incerto com prova de entrega. Essas proteções são adequadas contra reenvio sem prova, mas não representam uma ingestão assíncrona.

A API Data Manager devolve `requestId` ao aceitar a requisição; a confirmação posterior deve ser consultada a partir de 30 minutos e pode levar 24 horas. Marcar HTTP 200 como entrega individual perderia erros posteriores. Marcar toda aceitação como incerta bloquearia permanentemente entregas que poderiam ser confirmadas. O Google não deve criar uma segunda fila nem editar diretamente a tabela privada Core para contornar essa lacuna.

`UploadClickConversions` legado depende da elegibilidade atual das credenciais/conta, não demonstrada pelas entradas recebidas. Nenhuma conta real foi consultada. Não haverá seleção ou fallback automático para o legado. Um feed HTTPS também exigiria contrato de recibo, autenticação e suporte confirmado aos identificadores.

## Proposta e responsáveis

- **Core + Google:** acordar evolução explícita do contrato para aceitação pendente, recibo opaco durável, consulta sem reenvio, resultado terminal e reconciliação auditável. Fixar associação a `record_id`, destino e identidade da credencial; troca de destino/identidade não deve reutilizar recibo. Preservar bloqueio de timeout sem recibo e ausência de repetição automática de entrega incerta. Versionar o contrato se incompatível; não alterar 1.0.0 silenciosamente.
- **Google + dono/Datta:** validar transporte habilitado, conta, ação de importação e permissões. Se o legado for escolhido, exigir evidência de elegibilidade e resultado individual; resposta parcial ou ambígua não comprova entrega.
- **Core + Google:** definir a regra para payload Ads contendo vários `click_ids`. O exemplo oficial legado exige exatamente um de gclid/gbraid/wbraid; o consumidor não deve escolher arbitrariamente ou enviar três conversões do mesmo contato.
- **Google:** implementar GA4 MP com segredo privado e destino explícito, declarando que HTTP 2xx confirma somente recebimento HTTP, sem repetição automática. A integração deverá manter consentimento e fila no Core e não executar HTTP no pedido do visitante.
- **Core + dono/frota:** manter a troca operacional 235 bloqueada. O Core 1.39.0 suprime o contato Google no navegador; sem adaptador pronto pode interromper a medição de contatos. Não distribuir esse comportamento como pronto apenas porque o leitor mostra `configured:true`.
- **Dono/Datta:** coordenar a ação principal Contatos, retirada da tag antiga e valor/moeda; homologar WebView/Instagram, sessão GA4 original, Ads uma vez e deduplicação Meta.

## Aceite previsto

Contrato acordado antes do código dependente; fixtures para aceitação/consulta/sucesso/falha/parcial/timeout e reinício; ausência de duplicação após troca/repetição; um destino explícito por fluxo; nenhuma chamada na requisição do visitante; configuração e segredos protegidos; homologação real distinta dos testes locais. Google 0.13.0 não encerra o pedido Core 235.

## Evidências e fontes

Inspeção própria de `includes/class-f3base-conversoes-servidor.php` e `docs/RELEASE-1.39.0.md` do pacote Core recebido. Instalador Core 1.39.0: 2004862 bytes, SHA-256 `e0ab847ebb1f2490656e19300f7254431ce8c6be6d095e0432b68d1b1cda9938`. Fonte: 2096129 bytes, SHA-256 `3eacddaac2d6ae506fc3ae448f7cc1c7973c83502a04105ae4ae38c43b1ee807`. Conferidos nesta rodada. Os 188 testes do relatório Core são evidência recebida, não execução própria Google.

Documentação oficial consultada em 20/10/2026:
- https://developers.google.com/data-manager/api/devguides/diagnostics
- https://developers.google.com/data-manager/api/reference/rest/v1/requestStatus/retrieve
- https://developers.google.com/google-ads/api/docs/conversions/upload-offline
- https://developers.google.com/google-ads/api/samples/upload-offline-conversion
- https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference

Histórico: r1 registra o bloqueio antes de implementar o transporte dependente. Nenhum pacote alheio alterado, nenhuma conta comercial modificada, nenhum encaminhamento enviado a terceiros.

## Fechamento r2

Google 0.13.0 entregue para o pedido 27: instalador 723475 bytes, SHA-256 `d026247e0b25f184c3699e0fff7ee6bae8f49c8a2e63859a40bef529cc7f2297`. 585 verificações próprias aprovadas (525 nativas e 60 puras), além de 150 arquivos PHP com sintaxe válida; a matriz inclui 52 verificações nativas com o leitor Core 1.39.0. Isso não homologa a fila nem as APIs comerciais. No Site-Teste, Google passou de 0.12.0 para 0.13.0 e Core permaneceu 1.38.0; conflito corrigido, configuração preservada, saúde normal.

O bloqueio de transporte e as ações da r1 permanecem abertos. Não foi implementado adaptador parcial nem habilitado legado sem comprovação. Encaminhamento preparado para o dono, sem envio automático ao mantenedor Core.
