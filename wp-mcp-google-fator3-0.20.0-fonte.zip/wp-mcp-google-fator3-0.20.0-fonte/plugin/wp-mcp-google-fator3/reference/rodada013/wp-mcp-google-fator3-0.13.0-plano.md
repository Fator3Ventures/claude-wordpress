# Plano — Fator3 MCP Google 0.13.0

Revisão: 3 · Data: 20/10/2026 · Fuso: America/Sao_Paulo
Etapa: entrega · Situação: pedido 27 implementado e validado; transporte Core 235 bloqueado para alinhamento
Responsável: mantenedor Google · Pedido central: **Pedidos MCP Google 27**
Base liberada: **0.12.0** · Alvo previsto: **0.13.0**, incremento minor
Slug/basename: `wp-mcp-google-fator3/wp-mcp-google-fator3.php`
Instalador 0.13.0 fechado; fonte e relatório identificados na entrega. Seções r1/r2 abaixo preservam o registro histórico do planejamento.

## Encerramento r3

Pedido 27 implementado; matriz final com 585 verificações aprovadas, sintaxe de 150 PHP, instalação limpa, upgrade 0.12.0 com rollback/reaplicação, isolamento, documentação integral MCP no laboratório e leitor Core 1.39.0. Site-Teste atualizado somente no Google, versão 0.13.0, com backup; conflito true/retryable false comprovados em nova requisição, configuração preservada e saúde normal. Core permaneceu 1.38.0.

Instalador: `wp-mcp-google-fator3-0.13.0-instalador.zip`, 723475 bytes, SHA-256 `d026247e0b25f184c3699e0fff7ee6bae8f49c8a2e63859a40bef529cc7f2297`. Fonte: `wp-mcp-google-fator3-0.13.0-fonte.zip`; identidade final no relatório externo `wp-mcp-google-fator3-0.13.0-relatorio.md`. O impacto `wp-mcp-google-fator3-0.13.0-impacto-base-site-core-fator3.md` passa a r2, aberto/bloqueio para Core 235. Nenhum adaptador comercial foi implementado nesta correção; o pedido central será encerrado pelo revisor após aceite.

Este encerramento substitui os estados previstos/pendentes das seções históricas para o pedido 27, preservando limites, pendências comerciais e histórico de decisões. Os resultados próprios e recebidos estão separados no relatório.

## Atualização r2 — impacto recebido do Core 1.39.0

O novo impacto Core → Google r2 foi examinado com fonte e instalador em 20/10/2026. A correção do pedido 27 permanece independente. O transporte servidor do pedido Core 235 requer alinhamento de recibos/consulta assíncrona e prova de elegibilidade Ads; não faz parte da prontidão comercial da 0.13.0. Encaminhamento pertinente: `wp-mcp-google-fator3-0.13.0-impacto-base-site-core-fator3.md`, r1, aberto/bloqueio. Esse achado substitui a conclusão inicial de ausência de novo impacto na seção 6, preservada abaixo como histórico do planejamento.

Acrescentar ensaio do leitor com Core 1.39.0 em laboratório; isso não homologa a fila nem autoriza troca do Core no Site-Teste. A matriz principal mantém Core 1.38.0/MCP 0.24.0. Não criar um adaptador legado por inferência de credencial nem uma fila paralela Google. Os contratos e o catálogo da correção permanecem iguais.

## 1. Objetivo e base da decisão

Corrigir a classificação da recusa por revisão em `google/conversion-context`: quando o resultado validado for `revision_conflict`, o envelope Google deve informar `conflict:true`. Preservar o código específico, o bloco Core e os gates existentes. A nova versão não acrescenta funcionalidades comerciais.

Entradas examinadas:

- Instruções comuns e padrão de desenvolvimento/entrega Fator3, ambos **revisão 4 de 16/10/2026**, lidos integralmente nesta rodada.
- `Fator3 MCP Google(3).md`, situação de 19/10/2026: base 0.12.0, somente o pedido 27 pendente; o pedido 26 foi conferido e retirado da lista. A distribuição da 0.12.0 nos 12 sites e o commit `b4d1e09` são informações recebidas da frota, não uma verificação própria de todos os sites ou do repositório nesta rodada.
- Fonte e instalador 0.12.0 recuperados e conferidos por SHA-256; relatório externo r1 e impacto Google→Implantador r2. Nesta rodada os dois documentos externos passam, respectivamente, a r2 e r3; os ZIPs permanecem idênticos.
- `implantador-base-2.10.0-impacto-wp-mcp-google-fator3.md` r2, retorno de validação do destinatário para o pedido 26 / IMP-GOOGLE-01.
- Código do leitor e do adaptador (`includes/ConversionContext.php`, `CoreConversions.php`), construção/normalização da resposta (`Response.php`, `Operation.php`, `Ability.php`), testes `tests/native/conversions012.php`, manual `docs/CONVERSOES.md` e schemas empacotados do contrato de conversões.
- Leitura MCP própria no Site-Teste em 19/10/2026, reproduzindo o defeito com a base instalada.

Não foram atribuídos novos números à lista central. Os identificadores P13 e V13 abaixo são apenas itens internos deste plano.

## 2. Diagnóstico confirmado

Na base, `ConversionContext::read()` chama o SDK pelo adaptador, recebe o código validado e passa `core_conversion_context` a `Response::fail()`, sem acrescentar o indicador de conflito. `Operation::result()` conserva a política de resultado/repetição, mas não classifica esse erro como conflito. Pelo MCP, a resposta observada contém `conflict:false`.

A suíte nativa anterior verificava `success:false`, código `revision_conflict` e `data:null`, mas não o campo `conflict`. Isso explica a lacuna de aceite; as 683 asserções da entrega anterior não constituem prova da correção agora pedida.

Reprodução própria, requisição `867f5e2b2aed1d28725b1c98`:

```json
{"ability":"google/conversion-context","parameters":{"expected_revision":"0000000000000000000000000000000000000000000000000000000000000000"}}
```

Campos observados no resultado Google dentro de `data` do transportador:

```json
{
  "success": false,
  "error_code": "f3_google_core_conversion_revision_conflict",
  "core_conversion_context": {
    "ok": false,
    "code": "revision_conflict",
    "contract": "site-conversion-purposes/1.0.0",
    "provider": "base-site-core-fator3",
    "data": null
  },
  "operation_outcome": "not_applicable",
  "retryable": false,
  "conflict": false,
  "result_contract": 2
}
```

O transportador também informa uma falha externa `INVALID_ARGUMENT`; o pedido 27 trata dos campos do resultado Google, não de renomear códigos genéricos do transporte.

## 3. Comportamento previsto

| Situação | Resposta exigida na 0.13.0 |
|---|---|
| Core recusa `expected_revision` divergente | `success:false`, `error_code:f3_google_core_conversion_revision_conflict`, **`conflict:true`**, bloco Core preservado com `code:revision_conflict/data:null` |
| Adaptador identifica divergência em resposta válida do produtor | Mesma classificação de conflito; jamais aceitar a fotografia divergente como sucesso |
| Revisão atual fornecida pela mesma operação, em campo do contrato público aceito | Propagar somente a revisão validada para `current_revision`; não usar revisão de configuração Google ou `measurement_revision` como substituta |
| Erro do SDK atual, sem revisão atual fornecida | Omitir `current_revision`; não usar string vazia, zeros, revisão enviada, hash calculado pelo consumidor ou uma leitura adicional |
| Sucesso com revisão atual ou sem guarda | Preservar sucesso e dados; não marcar conflito |
| Entrada inválida, ausência, incompatibilidade, indisponibilidade ou recusa de autorização | Conservar códigos e proteção existentes; não marcar esses erros como conflito de revisão |

**Decisão sobre `current_revision`.** O SDK consumido é `site-conversion-purposes/1.0.0`, `schema_revision:"1"`. Seu ramo de erro tem exatamente `ok`, `code`, `contract`, `provider`, `data`, com `data:null` e `additionalProperties:false`; não fornece `current_revision`. A resposta real reproduzida também não o fornece. Portanto, a recusa normal com Core 1.38.0 deve sair sem esse campo. A condição do pedido “quando o contrato do Site Core a fornecer” não exige alterar o produtor nem fazer uma segunda consulta. Uma resposta de sucesso já validada pelo adaptador tem `data.revision`; se a guarda defensiva do próprio consumidor a recusar, qualquer propagação desse valor deve preservar o envelope público Core e ter teste específico. Não aceitar extensões arbitrárias do schema em nome dessa possibilidade.

**Repetição.** Manter `retryable:false` para a chamada com guarda obsoleta: repetir os mesmos argumentos não corrige a divergência. O agente deve reler o contexto sem `expected_revision`, reavaliar a fotografia e, se necessário, fazer uma nova leitura com a revisão obtida. Não haverá repetição automática nem troca silenciosa da guarda.

**Local da correção.** Preferir mapear explicitamente o código validado no leitor Google e acrescentar o campo ao resultado antes da decoração MCP. Revisar a declaração de saída para que o contrato também seja claro em execução local sem MCP. Não criar heurística global baseada em texto de erro nem alterar `Response::fail()` para todos os serviços sem necessidade demonstrada.

**GTM.** Preservar a semântica de `gtm/diagnostico`: falha apenas no contexto adicional não invalida o diagnóstico antigo válido. Não promover automaticamente o conflito aninhado desse bloco a falha global nem repetir a consulta GTM.

Contratos mantidos: configuração 4.0.0, catálogo 3.0.0, execução 2.0.0, storage/manutenção 2.0.0 e SDKs existentes. Nenhuma nova ability prevista; catálogo-base de 283 operações. Nova versão do plugin não implica nova versão desses contratos.

## 4. Trabalho e sequência

| Item interno | Prioridade / responsável | Entrega e critério de conclusão |
|---|---|---|
| P13-01 — Pedido 27 | P0 / Google | Correção explícita do resultado de `google/conversion-context`; recusa por revisão marca `conflict:true`, com política de `current_revision` e `retryable` acima. Sem mudanças em pacote alheio. |
| P13-02 — Contrato e documentação | P0 / Google | Atualizar schema local pertinente, `CONVERSOES.md`, exemplos, guia operacional e notas da release; regenerar catálogo e documentação compilada a partir do registro. Documentar releitura após conflito e o campo opcional. |
| P13-03 — Validação | P0 / Google | Executar a matriz V13, incluindo regressão que falha na base e passa no candidato, WordPress limpo, atualização direta e MCP HTTP em requisição nova. Registrar resultados reais, sem meta artificial de quantidade. |
| P13-04 — Fechamento | P0 / Google | Fechar instalador; validar identidade final; fonte completo com build/testes/evidências e cópia do relatório anterior ao fechamento; relatório externo com bytes/hashes; atualizar este plano e impactos pertinentes, se surgirem. |

Sequência: P13-01 → P13-02 → P13-03 → P13-04. A implementação pode seguir com os contratos já publicados; não há decisão externa que bloqueie a correção principal. Se aparecer incompatibilidade concreta no transporte ou necessidade de ampliar o contrato Core, emitir o impacto pertinente antes de implementar essa ampliação e alinhar a parte dependente.

## 5. Matriz de aceite prevista — ainda não executada na 0.13.0

| ID | Cenário | Aceite |
|---|---|---|
| V13-01 | Revisão de 64 zeros, retorno direto e execução por MCP HTTP | `conflict` é booleano true; erro específico, bloco Core, `data:null`, `retryable:false` e resultado de leitura preservados. O MCP não apaga a marcação. |
| V13-02 | Sem guarda e com revisão atual; repetir a guarda obsoleta e depois reler corretamente | Sucesso nas leituras válidas; guarda obsoleta continua recusada; releitura obtém revisão atual sem reparo ou chamada Google. |
| V13-03 | Revisão atual e guarda defensiva do adaptador | Ausência do campo na recusa normal do SDK 1.0.0; nenhuma revisão inventada. Se uma resposta pública válida já trouxer a revisão usada na recusa defensiva, verificar origem, tipo e propagação sem alterar o bloco Core. Resposta malformada permanece recusada. |
| V13-04 | Falhas não relacionadas e autorização | Anônimo/editor, capacidade adicional, canal fechado e perfil MCP sem autorização continuam recusados, inclusive callback direto; nenhuma exposição de contexto/revisão por erro de autorização. `invalid_input`, `unsupported`, `unreadable`, `unavailable` e `not_authorized` não viram conflitos. |
| V13-05 | WordPress limpo e plugin isolado | Ativação/documentação/funções próprias sem acompanhantes; ausência do Core desabilita somente a leitura integrada. Reensaiar mínimos declarados WP 7.1.2/PHP 8.3.6 antes de afirmar suporte do candidato. |
| V13-06 | Atualização direta Google 0.12.0 → 0.13.0 | Nova requisição reconhece versão e comportamento; opções, credenciais sintéticas cifradas, conexões, políticas, agendas e progresso preservados. Sem desinstalação ou migração nova. |
| V13-07 | Regressões afetadas | Core 1.38.0/MCP 0.24.0; sucesso e falha do bloco adicional GTM com Google simulado, sem repetir GET nem alterar diagnóstico antigo. Confirmar a tipagem das cinco opções booleanas do pedido 26 em conexões padrão/nomeada e preservar texto vazio. |
| V13-08 | Documentação instalada | Descobrir índice/schema; leitura completa paginada com hash/revisão, incluindo documento longo; mudança de revisão detectada, caminho arbitrário negado, ajuda sem fornecedor e sem dados privados. Confirmar guia atualizado após upgrade. |
| V13-09 | Site-Teste, durante implementação/homologação | Ler inventário/saúde e configuração antes; uma troca por vez, backup e hash esperado; nova requisição reproduz pedido 27 corrigido; documentação e estado final conferidos. Sem fixture de configuração no site compartilhado para um teste que pode ser somente leitura. |
| V13-10 | Pacotes e reversão | Sintaxe, nomes/versões, identidade e igualdade do runtime fonte/instalador; ZIPs sem segredos/QA indevido; rollback de arquivos à 0.12.0 e reaplicação no laboratório quando exercitar o percurso de atualização. |

Acompanhantes de referência: Core 1.38.0, MCP 0.24.0, Meta e LinkedIn 0.3.0. Não há alteração do contrato Core nem necessidade prevista de nova matriz histórica de ordens de troca; se a análise de implementação mudar essa conclusão, ajustar a matriz. Não declarar versões apenas planejadas de acompanhantes como testadas.

A regressão GTM usa resposta Google simulada e produtor Core real em laboratório; não é homologação da API GTM. O aceite do pedido 27 não depende de credenciais comerciais. Não é necessário reexecutar toda a suíte histórica para encerrar uma correção localizada, mas instalação limpa, atualização da base, autorização, fronteiras afetadas e documentação continuam obrigatórias.

## 6. Fronteiras e encaminhamentos

**Nenhum novo impacto técnico em outro pacote foi identificado no escopo proposto.** Foram avaliados o SDK de conversões do Core, o envelope/decoração MCP, o bloco adicional GTM, a confirmação de configuração pelo Implantador e os dados Meta/LinkedIn presentes no contexto. O ajuste usa um campo já declarado no envelope Google, mantém o contrato Core e requer validação de integração conduzida pelo Google; não exige alteração, configuração nova ou decisão do mantenedor de outro plugin. Não serão gerados avisos individuais só para anunciar a 0.13.0.

O encaminhamento existente `wp-mcp-google-fator3-0.12.0-impacto-implantador-base.md` passa a **r3, resolvido no escopo técnico Google/Implantador**, com histórico preservado. O retorno Implantador 2.10.0 r2 declara validação local do adaptador nas conexões default e implantador210, false→true→false para `audit_local_reads` e `purge_on_uninstall`, com novas requisições MCP e `sa_subject` vazio preservado como string. O total informado de 70 verificações também inclui documentação; não representa 70 testes exclusivos de booleanos. Esta é evidência recebida do destinatário, sem execução própria do Implantador nesta rodada.

Identidade existente confirmada: `implantador-base/implantador-base.php`. Instalador 2.10.0 informado pelo destinatário: SHA-256 `61a1883f20aa9560c926b16339b29f991cd2d1109812067855522717aa9e19e4`. O pacote não foi baixado/revalidado por este planejamento. O aceite da entrega Implantador pela frota/dono e o pedido central do Implantador 18 continuam sob esses responsáveis; o Google não os encerra. A aba Google recebida já informa o encerramento do pedido 26 pelo seu revisor.

O impacto Core da 0.12.0 permanece encerrado no aceite anterior do consumidor; esta rodada não o reabre. Comportamentos comerciais de outras APIs e novas versões não fornecidas de acompanhantes são `nao-avaliado` nesta rodada, sem risco novo identificado que justifique encaminhamento individual.

## 7. Dados, credenciais e reversão

Nenhuma opção, tabela, migração, job, default ou credencial nova prevista. O SDK puro continua sem escrita/rede. A leitura pública mantém a política de auditoria existente, inclusive registro de falhas; “leitura local” não significa supressão dessa auditoria.

Atualizar arquivos preserva configuração e dados; não desinstalar para trocar a versão. Voltar os arquivos à 0.12.0 reintroduz o defeito de classificação do pedido 27. Backup de plugin não desfaz banco nem efeitos remotos posteriores. Dados de laboratório devem ser sintéticos e isolados.

Permanecem fora do escopo: emissão de tags/consentimento, novos recursos Ads/GA4/GTM, integrações sociais, BigQuery, migração Porter, nova exportação social para Sheets e mudanças globais de normalização de erros. Capacidades existentes continuam preservadas.

## 8. Evidência desta rodada e pendências

**Executado neste planejamento:** leitura das normas/anexos/base; conferência dos dois hashes; inspeção de código, teste e schema; reprodução MCP do defeito; inventário e saúde do Site-Teste. Não foi implementada a 0.13.0 nem executada sua matriz de aceite.

Estado observado do Site-Teste: WordPress **7.1.3**, PHP **8.3.30**, `healthy:true`, zero recuperações não resolvidas; Google **0.12.0**, Core **1.38.0**, MCP **0.24.0**, Meta/LinkedIn **0.3.0**, Yoast **28.7**, WP Super Cache **3.1.4**, DreamHost Panel Login **1.0.0**, todos ativos. Inventário: requisição `0813683518132157c7f43135`. Nenhuma instalação, troca de configuração, publicação ou operação comercial foi executada nesta rodada; a auditoria normal da leitura recusada pode registrar a chamada.

| Responsável | Pendência |
|---|---|
| Google | Implementar P13-01/P13-02, executar V13 e produzir artefatos 0.13.0. Confirmar ambientes mínimos disponíveis antes de alegar suporte validado. |
| Frota/revisor Google | Conferir instalador/relatório 0.13.0 quando entregues e fechar o pedido 27 após o aceite; este plano não altera a lista central. |
| Frota/dono e Implantador | Aceite da entrega Implantador 2.10.0 e do item central 18 conforme retorno recebido; eventual homologação de credenciais reais. |
| Frota/dono Google | Pendência histórica 20: coleta completa por jobs, calendário, exportação `require_complete` e paginação/envelope 1 MiB em uso real. Sem prova nova neste planejamento e sem transformação automática em escopo de código da 0.13.0. |

APIs reais, navegador gráfico, multisite, cache distribuído e cron externo não foram homologados nesta rodada. A ausência dessas provas não será apresentada como aprovação do candidato.

## 9. Artefatos desta rodada

Base **inalterada**, disponível para referência e reprodução:

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Fonte-base | `wp-mcp-google-fator3-0.12.0-fonte.zip` | 2825174 | `a7f4efcc73ca4e64d9c76507739f6f7744894856a81f611173d97a256d80e717` |
| Instalador-base | `wp-mcp-google-fator3-0.12.0-instalador.zip` | 721839 | `d2499a5f0b2b89b5640dc86a780fc8a73335dc20d06003eb22b7185ce98162c0` |

Documentos externos: este plano r1; `wp-mcp-google-fator3-0.12.0-relatorio.md` r2; `wp-mcp-google-fator3-0.12.0-impacto-implantador-base.md` r3. A revisão documental não altera a cópia histórica dentro do fonte nem os hashes certificados. O manifesto da entrega 0.12.0 registra os documentos da época; não é um manifesto desta rodada documental.

Na entrega futura, os nomes serão `wp-mcp-google-fator3-0.13.0-fonte.zip`, `wp-mcp-google-fator3-0.13.0-instalador.zip` e `wp-mcp-google-fator3-0.13.0-relatorio.md`, com identidades efetivamente medidas. A publicação/distribuição pela frota exige conferir os bytes servidos e usar `expected_slug`/`expected_sha256`; não foi realizada por este planejamento. A norma sobre publicação do fonte continua sujeita à decisão 89; o relato recebido de publicação anterior não é nova autorização.

## Histórico

- r1 — 19/10/2026: plano inicial baseado no pedido 27, reprodução própria da falha e retorno Implantador 2.10.0; nenhuma alteração de código.

- r2 — 20/10/2026: início da implementação e análise do Core 1.39.0 recebido; bloqueio da integração de entrega encaminhado antes da parte dependente; pedido 27 segue independente.

- r3 — 20/10/2026: pedido 27 entregue e validado no laboratório/Site-Teste; impacto Core r2 permanece aberto, sem declaração de prontidão comercial.
