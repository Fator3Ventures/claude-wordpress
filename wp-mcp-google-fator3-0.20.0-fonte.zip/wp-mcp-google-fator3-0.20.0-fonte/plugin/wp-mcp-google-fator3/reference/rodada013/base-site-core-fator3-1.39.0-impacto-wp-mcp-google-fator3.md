# Impacto de base-site-core-fator3 1.39.0 em wp-mcp-google-fator3

Revisão 2 · 20/10/2026 · Etapa: entrega · Situação: aberto
Base: Core 1.38.0; alvo previsto 1.39.0, instalador ainda não gerado.
Destinatário examinado: Google 0.12.0. Classificação: acao-necessaria / validacao-coordenada. Pedido core 235.

## Mudança e consequência

O Core passará a manter a fila por record_id e destino a partir do envio aceito. GA4 generate_lead e Google Ads Contato passam a transporte exclusivo servidor. Material mantém seu contrato atual. O SDK site-conversion-purposes/1.0.0 não informa transporte por finalidade; seus consumidores não devem inferir que configured prova prontidão de envio servidor.

A versão Google 0.12.0 apenas consome o SDK de configuração; não fornece transporte das conversões. APIs e credenciais Google permanecem sob responsabilidade desse plugin. Nenhuma chamada externa ocorrerá na requisição do visitante.

## Contrato proposto e ação

Core expõe contrato local site-conversion-delivery/1.0.0, com configuração declarativa e fila. O adaptador Google deverá registrar capacidades, validar o destino e despachar no cron. Estados de retorno: entregue, recusado (não entrega comprovada), incerto; timeout e resposta sem confirmação não autorizam repetir. A ausência de adaptador mantém a fila bloqueada e visível.

GA4: Measurement Protocol, client_id e session_id da captura, timestamp_micros da ocorrência, generate_lead, event_id/record_id. Credencial api_secret privada no Google. HTTP 2xx confirma recebimento HTTP, não processamento analítico; o adaptador deve declarar esse limite e nunca repetir automaticamente após 2xx.

Ads: ID da conversão de importação, gclid/gbraid/wbraid, order_id=record_id, horário com fuso, valor/moeda, consentimento. O responsável Google deve validar a API habilitada para a conta e as restrições atuais antes de escolher o transporte. A documentação atual distingue fluxos legados de upload e Data Manager. Alternativa autorizada pelo pedido: feed HTTPS privado, desde que comprovadamente suporte os identificadores necessários e autenticação.

## Compatibilidade e sequência

As alterações independentes 230–234 prosseguem. Não ativar a troca operacional de 235 até o adaptador estar disponível, configurado e homologado. O dono/Datta muda no mesmo dia a ação principal da meta Contatos e remove a antiga tag da condição principal. Conferir também tags configuradas fora do Core/GTM.

## Validação e resposta esperada

Responsável Google: confirmar contrato/capacidades, transporte suportado, evidência de entrega e semântica de erros. Dono/frota: testes Android WebView e Instagram, sessão GA4 original, Ads importado uma vez e deduplicação Meta. Não foi feita alteração no plugin Google nem em contas externas.

Fontes oficiais consultadas: https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference e https://developers.google.com/google-ads/api/docs/conversions/upload-offline .

## Fechamento da implementação Core

Instalador 1.39.0: e0ab847ebb1f2490656e19300f7254431ce8c6be6d095e0432b68d1b1cda9938 (SHA-256), 2004862 bytes. Implementação e contrato no Core concluídos; aceite integrado pendente. Instalação limpa e upgrade direto da 1.38 passaram em WordPress 7.1.3/PHP 8.3.6. Google continua 0.12.0 no Site-Teste; nenhum acompanhamento alterado. 188 checagens locais, fornecedores simulados. A revisão 1 acima registra a proposta inicial; este fechamento substitui a previsão de instalador ainda não gerado.
