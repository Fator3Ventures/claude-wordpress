# Escopo e fronteiras — Google 0.17.0

Solicitação: considerar pedidos e versões atualizadas e implementar nova versão. Escopo aceito: pedidos Google 33–35, base 0.16.0, Core 1.46.1, MCP 0.25.0, Meta/LinkedIn 0.4.1. Identidades e contratos públicos preservados.

33: rótulos claros por operação na política de recursos; identificador técnico na descrição acessível. 35: 286 rótulos de habilidades em português, sem alterar nomes públicos. 34: diagnóstico sanitizado, incidente, repetição da primeira validação NOT_FOUND sob a mesma concessão e preservação independente de GA4/Ads.

Fronteiras avaliadas: registro Abilities consumido por MCP, descoberta/catálogo, auditoria, autorização, SDK de medição e conversões Core, cron Google, convivência de tabelas/options e reversão de arquivos. Core 1.46.1 recebido contém `reconciliar` e usa `site-conversion-reconcile/1.0.0`; a necessidade técnica da dependência Google 0.16 está atendida nesse insumo. Não se modifica nem se renumera Core/MCP/Meta/LinkedIn. Nenhum impacto novo exige encaminhamento. Os documentos de impacto em evidências de versões anteriores são histórico, não pendências novas desta entrega.

A indisponibilidade temporária observada da ação no pedido 34 não tem causa estabelecida. NOT_FOUND no campo de referência permite agendar nova validação; não comprova propagação, elegibilidade comercial ou recebimento de conversão. Configuração, credencial, política e concessão continuam sendo verificadas antes de HTTP.

Distribuição: os três artefatos vão ao dono; publicação raw e instalação na frota permanecem no fluxo definido pela norma comum. Site-Teste foi consultado sem alteração nesta rodada. Não foram enviados eventos comerciais, mensagens ou avisos externos durante os testes locais.
