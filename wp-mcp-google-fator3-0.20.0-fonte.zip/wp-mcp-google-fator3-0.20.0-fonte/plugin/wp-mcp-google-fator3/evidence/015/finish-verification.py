"""Validate unchanged evidence from completed cases and one fresh infrastructure retry."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,zipfile
root=Path(__file__).resolve().parent;src=root/'work/wp-mcp-google-fator3'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=load('b',src/'build/build.py');lab=load('l',src/'tools/lab.py');cfg,inputs=lab.checked_inputs(root/'manifest.json');identity=b.identity()
cmeta=json.loads((root/'candidate/wp-mcp-google-fator3-0.15.0-instalador.identity.json').read_text());assert all(cmeta[k]==v for k,v in identity.items())
digest=sha(inputs['candidate']);assert digest==cmeta['candidate_sha256']
with zipfile.ZipFile(inputs['candidate']) as z:actual={n.removeprefix('wp-mcp-google-fator3/'):z.read(n) for n in z.namelist()}
assert actual==b.manifest()
ev=root/'validation/final';assert not ev.exists();ev.mkdir()
cases={
 'clean':(root/'labs/run1/clean','clean','mcp-first',['minimum015','clean','delivery015','conversions013','documentation015']),
 'upgrade':(root/'labs/run1/upgrade','upgrade','mcp-first',['upgrade015','minimum015','delivery015','documentation015']),
 'core140':(root/'labs/retry-core140','clean','google-first',['minimum015','delivery015','conversions013']),
 'isolated':(root/'labs/isolated','clean','google-only',['minimum015','clean','standalone014'])}
groups={}
for name,(dest,origin,order,suites) in cases.items():
 out=ev/name;shutil.copytree(dest/'evidence',out);env=json.loads((out/'environment.json').read_text());assert env['processes_stopped'] and env['candidate_sha256']==digest and env['origin']==origin and env['order']==order
 reports={}
 for suite in suites:
  f=out/(suite+'.json');d=json.loads(f.read_text());assert d['failures']==0 and d['candidate_sha256']==digest and d['checks']==len(d['passed']) and d['checks']>0
  reports[suite]={'checks':d['checks'],'sha256':sha(f)}
 inv={'candidate':lab.installed_inventory(inputs['candidate'],dest/'wordpress/wp-content/plugins','wp-mcp-google-fator3')}
 for k,slug in [('mcp','wp-mcp-fator3'),('core','base-site-core-fator3'),('meta','wp-mcp-meta-fator3'),('linkedin','wp-mcp-linkedin-fator3')]:
  if (dest/'wordpress/wp-content/plugins'/slug).exists():inv[k]=lab.installed_inventory(inputs['core140'] if name=='core140' and k=='core' else inputs[k],dest/'wordpress/wp-content/plugins',slug)
 expected_inputs={k:{'sha256':cfg['inputs']['core140' if name=='core140' and k=='core' else k]['sha256'],'version':cfg['inputs']['core140' if name=='core140' and k=='core' else k]['version']} for k in lab.required_inputs(origin,order)}
 assert env['inputs']==expected_inputs
 groups[name]={'checks':sum(d['checks'] for d in reports.values()),'reports':reports,'environment_sha256':sha(out/'environment.json'),'installed_inventory':inv,'origin':origin,'order':order}
 log=root/'validation'/('core140-retry.log' if name=='core140' else 'isolated.log' if name=='isolated' else 'run1/'+name+'.log');shutil.copyfile(log,ev/(name+'.log'))
contracts={}
for n in ['absent','missing-method','matrix','response013']:
 name='response-candidate015.json' if n=='response013' else 'contracts-'+n+'.json';shutil.copyfile(root/'validation/run1'/name,ev/name);d=json.loads((ev/name).read_text());contracts[n]={'checks':d['checks'],'sha256':sha(ev/name)}
proof={'schema_version':1,'release':'0.15.0','scope':'Core1.41 destination binding; clean/upgrade014/rollback/isolation/docs/MCP; Core1.40 compatibility; simulated Google, no commercial processing claim','candidate_sha256':digest,'identity':identity,'checks':sum(g['checks'] for g in groups.values()),'contract_tests':contracts,'failures':0,'runtime_files':len(actual),'php_lint_files':sum(n.endswith('.php') for n in actual),'groups':groups,'inputs':{k:{'sha256':v['sha256'],'version':v['version']} for k,v in cfg['inputs'].items()},'infrastructure_retry':{'case':'core140','initial_attempt':'MySQL failed to start before WordPress installation; Missing redo log file #ib_redo1','action':'New disposable database and directory; identical candidate/test/tool identity; successful cases retained'}}
(ev/'validation015.json').write_text(json.dumps(proof,indent=2)+'\n');shutil.copyfile(root/'labs/run1/core140/db.log',ev/'infrastructure-retry.log');shutil.copyfile(__file__,ev/'finish-verification.py')
print(json.dumps({'native':proof['checks'],'pure':sum(d['checks'] for d in contracts.values()),'sha256':digest,'groups':{k:v['checks'] for k,v in groups.items()}},indent=2))
