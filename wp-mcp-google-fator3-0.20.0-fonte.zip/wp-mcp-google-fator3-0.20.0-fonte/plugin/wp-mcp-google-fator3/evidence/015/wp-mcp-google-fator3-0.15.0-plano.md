# Implementação — Fator3 MCP Google 0.15.0

20/10/2026 · Base Google 0.14.0 publicada. Origem: fonte SHA-256 `05af95023adf13b27fedc556c2759df7a28197a848a48c5cc4135e85bd1836bb`; instalador `7b9681bed81fa265ac70379fd6ebb5d4b161923a8e10a7a4ad115af58cf3d001`. Alvo 0.15.0 pelo incremento minor definido no padrão r4.

Escopo: incorporar o vínculo de destino solicitado pelo Core 1.41.0, revisar o guard de despacho, manter compatibilidade de `send()` com Core 1.40.0 e atualizar a documentação instalada. Nenhuma nova fila, migração de dados ou ativação automática de envio.

Sequência: conferir hashes recebidos; emitir impacto único; implementar; validar contratos/instalação limpa/atualização da base/isolamento/integração Core; fechar instalador, relatório e fonte. O impacto único `wp-mcp-google-fator3-0.15.0-impacto-base-site-core-fator3.md` acompanha as evidências e a homologação restante.

Site-Teste observado antes do trabalho: Google 0.14.0, Core 1.40.0, MCP 0.24.0, Meta/LinkedIn 0.3.0 ativos. Não há autorização de publicação GitHub nem de instalação Core nesta frente. A distribuição via frota exige URL verificável e hash; a ausência dessa URL será registrada se impedir instalação remota. Uso comercial e atribuição real GA4/Ads exigem ativos autorizados.

## Fechamento da implementação

Implementação concluída: dependência sendBound incorporada e guard revisto para reler identidade atual antes de HTTP. Validação final: 555 verificações nativas e 60 puras; instalação limpa, atualização/rollback/reaplicação, Core 1.41/1.40 e isolamento. Primeira inicialização do MySQL no cenário Core 1.40 falhou antes de WordPress; novo ambiente concluiu sem alterar candidato/testes. Impacto único atualizado para revisão 2. Site-Teste permanece Google 0.14/Core 1.40; implantação via frota e homologação comercial são pendências do relatório de entrega.
