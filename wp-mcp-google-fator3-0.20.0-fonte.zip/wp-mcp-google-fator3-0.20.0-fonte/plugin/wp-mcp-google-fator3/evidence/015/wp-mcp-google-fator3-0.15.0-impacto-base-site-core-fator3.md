# Impacto de wp-mcp-google-fator3 0.15.0 em base-site-core-fator3

2026-10-20T19:56:35-03:00 · Revisão 2 · Etapa: entrega · Situação: alinhado; incorporação concluída, homologação comercial pendente.
Emissor: Google 0.14.0 → 0.15.0. Destinatário examinado: Core 1.41.0; transição testada com Core 1.40.0.
Classificação: validacao-coordenada. Natureza: dependência PHP, configuração e validação de entrega.
Instalador Google: `wp-mcp-google-fator3-0.15.0-instalador.zip`, 742908 bytes, SHA-256 `a7014e419c1a1a79d9a9e02112fd8f5b285fed131b50e10ea26f588d2179b169`.

## Implementação e aceite

Incorporado o repasse Core 1.41, SHA-256 `9854091bd070a0791f81a1fe453fd96272c0933b62977a6ebd7d7be39698c160`, após conferir os hashes original/alterado de ConversionDelivery.php. `sendBound(array $payload, string $destinationRef)` confere a referência sob a trava comum à configuração/envio. `send()` permanece; o contrato `site-conversion-delivery/1.0.0` e os schemas públicos existentes não mudam.

A revisão Google também relê a identidade atual no guard antes de cada HTTP. A referência capturada no início não basta para identificar alteração posterior ao debug GA4. Divergência comprovada produz `recusado/non_delivery_proven:true/code:destination_mismatch`; perda de autorização/trava identificada pelo guard produz `authorization_changed`. As duas recusas são locais, antes da coleta/upload. Timeout, ACK ambíguo e resposta parcial continuam incertos. Não há retry HTTP automático de conversão.

A prova própria contém 555 verificações nativas e 60 puras, sem somar as 39 recebidas do Core ou as históricas. A suíte delivery015 executou 67 verificações por combinação integrada, incluindo mudança após debug, renovação/revogação de contexto, tentativa concorrente MCP de configurar durante envio, diário Core e não repetição. Core 1.41 real foi testado em instalação limpa e upgrade Google; Core 1.40 real em Google primeiro. Respostas Google são simuladas. Evidência: `evidence/015/validation015.json`.

## Ação restante e sequência

Não há nova alteração de código Core solicitada. Incorporação Google concluída. Frota: publicar instalador/relatório, verificar SHA-256 dos bytes raw e instalar a combinação planejada. Site-Teste observado permanece Google 0.14/Core 1.40, sem instalação remota nesta rodada por ausência de URL de distribuição verificada.

Depois de atualizar, o administrador configura/verifica Google e escolhe servidor explicitamente. Core 1.41 + Google 0.14 bloqueia servidor por `destination_binding_unsupported`. Google 0.15 + Core 1.40 mantém `send()`, com o limite de não haver vínculo no aceite do Core antigo. Não reescrever referências históricas, apagar diário ou reencaminhar resultados incertos. Reversão Google 0.15→0.14 volta a bloquear servidor com Core 1.41.

Responsáveis pela homologação: dono dos ativos e mantenedores Google/Core. Critério restante: ocorrência real atribuída à sessão GA4 original, conversão Ads real e ausência de duplicação no navegador/WebView. A janela/procedência da sessão são validadas pelo Core 1.41; Google conserva o payload recebido. Debug/HTTP 2xx não encerram atribuição analítica. Sem credenciais/ativos comerciais nesta rodada.

## Evolução e encerramento

Revisão 1 registrou proposta antes da implementação. Revisão 2 fecha o desenvolvimento Google exigido no impacto Core 1.41 r2 e consolida a continuidade do impacto Google 0.14 r2. Este é o único encaminhamento corrente Google→Core. Não houve nova demanda de desenvolvimento ao Core nem espera por resposta; resta implantação/homologação. Os outros acompanhantes não tiveram fronteiras alteradas. Nenhuma resposta de outro responsável foi presumida e nenhuma mensagem externa foi enviada.
