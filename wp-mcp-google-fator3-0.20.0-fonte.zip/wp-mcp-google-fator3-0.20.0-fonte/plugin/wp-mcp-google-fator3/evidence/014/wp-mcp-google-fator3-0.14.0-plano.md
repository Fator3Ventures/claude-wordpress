# Plano de release — Fator3 MCP Google 0.14.0

Revisão 2 · 20/10/2026 · America/Sao_Paulo · Etapa: implementação e fechamento
Base: 0.13.0. Versão implementada: 0.14.0. Identidade final e provas constam do relatório de entrega.
Identidade: `wp-mcp-google-fator3/wp-mcp-google-fator3.php`; provider `wp-mcp-google-fator3`.
Escopo: **Pedidos MCP Google 28 e 29**. Integração: **Pedidos core 236**; Core 235 é antecedente já retirado da lista central, conforme o anexo recebido.

## Resultado da implementação (substitui previsões incompatíveis abaixo)

Core 1.40.0 e seu pacote de dependência foram recebidos, inspecionados e incorporados à árvore Google 0.14.0. O adaptador mantém `site-conversion-delivery/1.0.0`; não foi criada extensão assíncrona/Data Manager especulativa. O leitor 1.0.0 permanece, e o contexto de transporte 1.1.0 é negociado separadamente. O Core 1.40.0 já resolve a escolha de modo por registro e a recusa de múltiplos IDs de clique.

Implementados: configuração e segredo cifrado por conexão, verificação com prazo e autorização revogável, envio GA4 com identidade/timestamp preservados, confirmação individual Ads, incerteza sem repetição e diagnóstico/recuperação de lacunas do cron. Nenhum valor de sessão ou engajamento é inventado. O worker Core pode chamar o contrato PHP tanto pelo cron nativo quanto pelo executor de tarefas; não há operação MCP/REST de envio direto.

O acompanhamento de três dias nos 12 sites e a homologação comercial em ctooffice permanecem pendentes. Os testes de fornecedor são simulados. O relatório registra a matriz realmente executada, hashes imutáveis e estado observado do Site-Teste. Há um único impacto ativo ao Core, atualizado para a entrega; nenhuma resposta dele bloqueou esta implementação.

As seções seguintes preservam a especificação aprovada na revisão 1 como histórico de planejamento. Datas futuras, condicionais e números da base não constituem provas de execução da 0.14.0.

## 1. Decisão e forma de trabalho

Entregar os adaptadores de conversão do pedido 28 e corrigir a observabilidade do cron do pedido 29. O pacote Google desenvolve, testa e documenta sua parte sem aguardar resposta do responsável pelo Core. Quando surgir uma necessidade do consumidor, entrega contrato concreto, exemplo e testes de integração no mesmo encaminhamento, com a ação exata que o Core deverá executar.

Esta orientação explícita do dono, de 20/10/2026, substitui a espera por alinhamento anterior ao código presente no impacto Google 0.13.0. Não elimina verificação de compatibilidade, homologação de fornecedor nem condições para ativar envios. O plano não atribui ao Google mudanças no código, configurações ou implantação do Core.

Haverá **um único encaminhamento ativo ao Core**: `wp-mcp-google-fator3-0.14.0-impacto-base-site-core-fator3.md`. Ele será atualizado no desenvolvimento e na entrega. O impacto 0.13.0 recebe revisão de encerramento por substituição, preservando seu histórico. Dúvidas de configuração e progresso interno ficam no plano/relatório; não geram novos impactos. Não se criam relatórios a MCP, Meta, LinkedIn ou Implantador apenas para avisar a versão.

## 2. Evidências e ponto de partida

| Evidência | O que permite afirmar |
|---|---|
| `Fator3 MCP Google(4).md`, recebido e lido integralmente | Pedidos 28 e 29 pendentes; pedido 27 conferido nos 12 sites; aceite real do pedido 20 continua na frota. Relato da frota, não nova auditoria própria dos 12 sites. |
| Fonte, relatório e impacto Core 1.39.0 r2 recebidos | Existe filtro `f3base_conversoes_adaptador`, contrato `site-conversion-delivery/1.0.0`, com `capabilities()` e `send()`. A fila e as decisões de consentimento pertencem ao Core. |
| Código Google 0.13.0 | Há cliente/operação `ads/upload-click-conversions`, mas nenhum adaptador para a fila Core. `CronHistory` registra `event_not_confirmed` e projeta `completion_not_recorded` sem causa comprovada. |
| Inventário próprio, somente leitura, Site-Teste em 20/10 | Google 0.13.0 e Core 1.39.0 ativos; MCP 0.24.0; Meta e LinkedIn 0.3.0. Requisição `92d734fea4e708b66ae9c155`. A atualização do Core ocorreu depois da entrega Google anterior, por ação externa a esta rodada. |
| Relatório Google 0.13.0 | 585 verificações e 150 arquivos PHP com sintaxe válida são provas históricas da 0.13.0; não contam como testes da 0.14.0. |

O anexo relata `trafego_suprimido` em simulação no Site-Teste: é uma recusa de elegibilidade do Core, não prova de erro do adaptador. O pedido core 236 e seu modo `servidor` são referências recebidas; não se afirma que sua implementação foi examinada. O código Core 1.39.0 disponível foi a base da análise.

Normas aplicadas: instruções comuns e padrão de desenvolvimento, revisão 4 de 16/10/2026. Não foram modificadas as normas ou a lista central. O anexo informa publicação da fonte 0.13.0 pela frota; isso não autoriza nova publicação pelo agente nem altera a regra central da decisão 89.

## 3. Pedido 28 — adaptadores de conversão

### 3.1 Fronteira e contrato existente

Registrar objetos para `ga4` e `google_ads` pelo filtro público do Core, respeitando o contrato solicitado e sem substituir outro adaptador já selecionado. Descoberta deve funcionar em ambas as ordens de ativação. Google isolado continua utilizável; ausência de Core aparece como integração indisponível.

`capabilities()` será leitura local, sem HTTP, gravação, renovação de token ou disparo de fila. Retornará `contract`, `ready` booleano e `destination_ref` estável, sem segredo, até 191 caracteres. Prontidão depende de configuração habilitada explicitamente, credencial utilizável, destino verificado e permissão. Evidência remota expirada ou identidade alterada invalida prontidão, sem consulta implícita. `google/status` explica os motivos por destino e separa configuração, verificação de acesso e homologação analítica.

`send(array $payload)` é chamado pelo executor autorizado, nunca no pedido do visitante. Usar autorização persistente da integração para execução de background; não depender de usuário administrativo logado no cron nem liberar chamadas públicas anônimas. Aplicar conexão explícita, política por recurso, limite de tempo e proteção de segredos existentes.

| Resultado | Evidência exigida / comportamento |
|---|---|
| `entregue` | Confirmação no nível que o fornecedor realmente oferece, documentada por destino; não comprova atribuição comercial. |
| `recusado`, `non_delivery_proven:true` | Validação anterior ao envio ou rejeição inequívoca daquele registro; informar motivo e intervalo coerente. Não declarar prova apenas pelo status HTTP. |
| `incerto` | Timeout após possível envio, resposta ambígua ou falha de confirmação. Sem repetição automática. |

O Core 1.39.0 já impede repetir entregues/incertos e fixa `destination_ref`. Preservar essas proteções. Reutilizar primitivas de trava/auditoria Google para concorrência e rastreio, sem construir outra fila de contatos. Não ler ou gravar tabelas privadas do Core. Alterações de destino não autorizam reenviar eventos históricos. Não prometer entrega exatamente uma vez diante de falhas de rede.

### 3.2 GA4 Measurement Protocol

Implementar envio unitário de `generate_lead`, usando `client_id`, `session_id`, `timestamp_micros` e `event_id` recebidos. Conferir consistência com `record_id`, data real e `measurement_id` configurado. Não inventar sessão, cliente ou tempo de engajamento.

Criar na tela administrativa existente um campo protegido para o dono colar o segredo Measurement Protocol, com orientação de onde obtê-lo, salvar/substituir/remover e indicação de presença sem exibir seu valor. Guardar no mecanismo privado/cifrado do Google; excluir de status, exportações, logs e URLs exibidas. Vincular conexão, propriedade e stream; conferir que o measurement ID pertence à propriedade da conexão em validação administrativa explícita, com evidência local invalidada quando mudar configuração.

Validar o modelo de evento no endpoint de depuração antes de habilitar a primeira entrega e novamente após alteração relevante. A depuração não ingere eventos e não basta para comprovar a validade do segredo ou a chegada à propriedade. Manter validação local de cada payload.

O MP confirma recebimento HTTP com 2xx e não informa processamento individual. Depois de validação prévia, `entregue` representa **recebido pelo endpoint**, com esse limite explícito no diagnóstico e no encaminhamento; a chegada e sessão são verificadas na homologação. Não transformar 2xx em prova de conversão contabilizada nem repetir para tentar fazê-la aparecer. Respostas não 2xx exigem classificação conservadora; não reenviar automaticamente a mesma requisição.

A janela de 72 horas para eventos retroativos não garante atribuição à sessão original. Essa atribuição exige envio até 24 horas do início da sessão e timestamp compatível. O teste de aceite deve usar sessão real recente. Dados adicionais de sessão/engajamento, quando necessários, são requisitos do produtor Core, sem valores fabricados pelo Google.

### 3.3 Google Ads — decisão de transporte com evidência

O pedido 28 solicita importação de clique e cita developer token (pendência 26 da frota). Reutilizar o cliente Ads existente para o caminho `UploadClickConversions` quando a conta/integração tiver acesso comprovado. Implementar e testar o adaptador sem aguardar credenciais reais; nesse período, `ready:false` terá motivo legível. A operação administrativa existente não será chamada com uma identidade administrativa artificial pelo cron: compartilhar a camada de transporte com autorização própria da integração.

Mapeamento obrigatório: ação de importação e conta explícitas; `order_id = record_id`; um identificador válido de clique; horário real com fuso; `ad_user_data`, valor e moeda do payload. Conferir ação habilitada e sua conta de conversão efetiva, inclusive vínculo de gerente. Não criar ação/meta, alterar lances ou substituir configuração do dono/Datta.

Enviar um registro por chamada inicialmente. Interpretar o resultado individual e os erros parciais por índice. HTTP 200, `jobId` ou aceitação genérica de lote não bastam. `validateOnly` é teste de validação e nunca retorno `entregue`. Payload com vários identificadores sem seleção inequívoca recebe recusa local `ambiguous_click_identifiers`; o Core deve selecionar o clique pela atribuição comprovada. Não escolher precedência arbitrária nem gerar várias conversões do mesmo contato.

**Verificação obrigatória no início da implementação Ads:** a documentação Google restringe `UploadClickConversions` para integrações sem histórico de acesso e orienta Data Manager. Portanto, obter evidência de elegibilidade do ambiente autorizado; não supor que adicionar token libera a API. A documentação atual também apresenta transição de autenticação para Google Cloud, cuja aplicabilidade à conexão instalada deverá ser conferida. Isso é dependência do fornecedor, não motivo para esperar o Core.

Se a integração for inelegível ou a API aplicável exigir Data Manager, desenvolver o transporte Google e seu contrato de recibo sem esperar retorno do Core, atualizando **o mesmo impacto** antes do código afetado. Não fazer fallback automático entre APIs. Este ramo é condicionado a evidência e não será implementado como segundo transporte especulativo.

No ramo Data Manager: persistir um recibo por registro/destino e consultar resultado sem reenviar; uma solicitação terá apenas um evento e um destino para permitir correlação. A aceitação inicial é pendente. Só confirmar entrega após diagnóstico terminal inequívoco; parcial/ambíguo continua incerto. O diagnóstico é assíncrono, com consulta recomendada a partir de 30 minutos e possível espera de 24 horas. O diário de recibos Google pertence ao transporte; a fila comercial e seu agendamento permanecem no Core.

O contrato Core 1.0.0 não tem pendente/consulta. Se esse ramo for necessário, publicar interface Google versionada, fixtures de envio/consulta/reinício e exemplo de consumidor; o adaptador incompatível declara `ready:false`. O Google entrega sua implementação e a ação precisa de consumo ao Core sem aguardar aprovação. Não reinterpretar silenciosamente `incerto`, anunciar compatibilidade inexistente nem fechar o aceite real do pedido 28 antes da integração funcionar. A seleção final da API será registrada no relatório com sua prova.

## 4. Pedido 29 — cron observável e reconciliação

Os quatro casos e duas passagens CLI citados no anexo são evidência recebida. Causa ainda não comprovada. Primeiro reproduzir nos componentes `CronHistory`, `CronErrors`, `CronStore`, `Executor` e hooks WP-CLI, distinguindo a invocação CLI da execução Google por conexão.

1. **Fechamento robusto:** instrumentar término normal, limite de tempo, exceção observada e falha de persistência. Tentar fechamento controlado em `finally`/shutdown quando possível, preservando resultado do trabalho separado do resultado da gravação. Registrar fase, origem, run/segmento, horário, código e fonte da evidência, sem dados pessoais ou segredos.
2. **Causa desconhecida explícita:** encerramento externo sem callback observável, como morte abrupta do processo, permanece desconhecido. Um registro antigo `running` não prova falha da hospedagem nem ausência de execução. Considerar lease/atividade e concorrência antes de projetar interrupção; não confundir duração acima de 120 segundos com término comprovado.
3. **Status aditivo:** manter campos públicos existentes; acrescentar distinção entre cobertura da observação e trabalho vencido, com estado desconhecido quando necessário. `success:null` não vira sucesso retroativo. Motivo de uma falha de gravação fica separado de erro do job. Atualizar schema, tela, ajuda e exemplos juntos.
4. **Reconciliação pelo executor:** a próxima passagem pode fechar uma lacuna quando tiver prova persistida de que não havia trabalho vencido no intervalo afetado, cobrindo conexões, jobs e agendas pertinentes. Guardar intervalo, motivo, referência da prova e `resolved_at`, com trava e guarda contra corrida. Não basta observar fila vazia agora; trabalho concluído/excluído ou agenda alterada pode ocultar o passado. Sem histórico suficiente, manter lacuna desconhecida até sair da janela, sem fabricar explicação.
5. **Leitura pura:** `google/status` não repara armazenamento nem fecha lacunas. A reconciliação ocorre numa passagem autorizada. Conservar histórico, retenção e limites existentes; não reexecutar jobs concluídos para produzir evidência.

Aceite de frota: **três dias consecutivos nos 12 sites**, com `window_complete:true` ou causa de cada lacuna registrada. Causa desconhecida deve permanecer declarada; ela atende à transparência do diagnóstico, mas não equivale à causa comprovada exigida para encerrar o aceite de frota. Monitoramento e observação de três dias ainda não foram executados nem agendados nesta rodada.

## 5. Sequência executável e responsáveis

| Ordem | Entrega Google | Dependência / conclusão |
|---|---|---|
| 1 | Testes que reproduzem 29; fixture do filtro/payload/retornos Core 1.0.0; seleção documentada de transporte Ads | Inspecionar acesso permitido sem envio comercial. Ausência de credencial não paralisa código e fixtures. |
| 2 | Correção cron, status e reconciliação por evidência | Trabalho inteiramente Google; nenhum retorno Core necessário. |
| 3 | Configuração segura, adaptador GA4, depuração e motivos de prontidão | Testes sintéticos e WordPress; segredo real será necessário para homologar. |
| 4 | Adaptador Ads na API aplicável; tratamento individual, ambiguidade e repetição | Se precisar de evolução Core, entregar implementação Google + contrato/testes no impacto único. |
| 5 | Integração, documentação instalada, empacotamento e validação Site-Teste | Limpo/upgrade 0.13.0, Core 1.39.0 e consumidor atualizado quando disponível; limites declarados por cenário. |
| 6 | Homologação ctooffice e observação da frota | Dono/Datta configura ação e credenciais; responsável Core entrega 236; frota distribui e coleta as provas por três dias. |

O contrato real e os testes são entregues junto ao código, sem condicionar o pacote Google a uma resposta documental do Core. Compatibilidade não confirmada permanece pendência de ativação daquele fluxo. Não se estima prazo de homologação sem credenciais, ambiente e consumidor disponíveis.

## 6. Matriz mínima de aceite técnico

| Grupo | Casos / evidência exigida |
|---|---|
| Instalação | WordPress limpo e upgrade direto 0.13.0; preservar conexões, credenciais, jobs, agendas e configuração; isolamento sem Core; ordem de ativação inversa. Mínimos a revalidar: WP 7.1.2/PHP 8.3.6. |
| Permissões | Administração exige `manage_options`; cron usa autorização explícita; segredo não aparece em status, logs, documentação, exportação ou pacote; leitura sem HTTP/escrita funcional. |
| Adaptadores | Core 1.39.0 real com transporte sintético; contrato desconhecido; credencial/destino/permissão ausentes; destino alterado; timeout; exceção; concorrência; resultado individual/parcial; recusa sem prova não repetida. |
| GA4 | Propriedade/stream divergente, depuração reprovada, IDs/datas inválidos, recebimento 2xx separado de processamento; repetição não produz nova chamada. |
| Ads | Cada tipo de clique, múltiplos IDs, ação/conta inválida, consentimento, valor/moeda, validação sem ingestão, erro por registro, resposta ambígua. Ramo Data Manager, se necessário: pendente/consulta/reinício/terminal e consumidor simulado sem nova ingestão. |
| Cron | CLI/HTTP/manual, sem trabalho, trabalho vencido, trava ocupada, duração longa, deadline, exceção, escrita recusada, processo morto e retomada; lacuna resolvível e intervalo sem prova; leitura não altera estado. |
| Regressão | Pedido 27, configuração, executor/limites, docs completas por MCP com paginação/hash e schemas atualizados. Testar áreas afetadas; não somar resultados históricos aos novos. |
| Operação real | Site-Teste: versão, saúde e status antes/depois, backup e execução PHP nova; não contornar supressão de tráfego. ctooffice: WebView Android, contato aceito, sessão real, um generate_lead e uma conversão na ação autorizada, sem duplicação por navegador. |
| Frota | Sem credenciais: motivos explícitos nos 12; cron observado por três dias. Separar prova própria, prova recebida e homologação ainda pendente. |

Pedidos 28 e 29 só serão propostos para encerramento ao revisor com seus aceites completos. Pacote instalado e fixtures aprovadas não equivalem à homologação comercial nem aos três dias de cron. Não há novas provas de execução da 0.14.0 neste planejamento.

## 7. Dados, reversão e limites de escopo

Novas configurações de conversão começam desabilitadas. Aplicar revisão/guarda de escrita e leitura posterior; inventariar opções, schemas e migrações efetivamente necessárias durante o código. Preservar identidades públicas, leitor `site-conversion-purposes/1.0.0` e ferramentas existentes. Não fixar agora totais futuros de abilities/opções.

Antes de trocar arquivos, backup do pacote e das novas estruturas/configurações. Voltar à 0.13.0 remove adaptadores e diagnóstico novo, mas não desfaz conversões já enviadas. Uma reversão precisa suspender o fluxo no consumidor e conservar os comprovantes; não apagar diário de deduplicação nem restaurar banco antigo e retomar envios cegamente. A ordem exata será testada e documentada na entrega.

Fora do escopo: mover tags/consentimento/captura para Google; criar outra fila comercial; alterar campanhas/metas/ações sem decisão do dono; novos serviços sociais, BigQuery, Porter ou exportação social Sheets. Pedido 20 continua na frota, sem ampliação automática desta release.

## 8. Encaminhamento e artefatos desta rodada

Core: `acao-necessaria` e `validacao-coordenada` para pedido 236, escolha inequívoca de clique, uso dos adaptadores e, somente se necessário, consumo de recibo assíncrono. O desenvolvimento Google não aguarda retorno. Documento ativo: `wp-mcp-google-fator3-0.14.0-impacto-base-site-core-fator3.md` r1. Histórico 0.13.0 r3 fica substituído; o relatório externo da base recebe r2, sem reabrir ZIPs.

| Base imutável | Bytes | SHA-256 |
|---|---:|---|
| `wp-mcp-google-fator3-0.13.0-instalador.zip` | 723475 | `d026247e0b25f184c3699e0fff7ee6bae8f49c8a2e63859a40bef529cc7f2297` |
| `wp-mcp-google-fator3-0.13.0-fonte.zip` | 2876664 | `3e6f32eb323e2354a1fc2e9c90a5e20b867a4af82e34c51aaf1d484ff8666596` |

Hashes reconferidos nesta rodada. Fonte e instalador 0.14.0 serão produzidos na implementação, com testes, documentação e relatório próprios. Nesta rodada foram feitas análise, leitura remota do inventário e revisão documental; nenhuma instalação, configuração comercial ou envio de conversão.

## 9. Fontes técnicas verificadas em 20/10/2026

- Measurement Protocol, transporte e limites: https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference
- Validação: https://developers.google.com/analytics/devguides/collection/protocol/ga4/validating-events
- Atribuição à sessão: https://developers.google.com/analytics/devguides/collection/protocol/ga4/use-cases
- Importação Ads e restrição de acesso: https://developers.google.com/google-ads/api/docs/conversions/upload-offline
- Recibos Data Manager, ramo condicionado: https://developers.google.com/data-manager/api/devguides/diagnostics

As fontes fundamentam limites do fornecedor; não provam acesso das contas da frota. A implementação deve confirmar o contrato/API vigente aplicável à conexão antes de habilitar o fluxo.

## Fechamento executado

Matriz final concluída: 833 verificações (773 nativas e 60 puras), 154 arquivos PHP. Atualização 0.13.0→0.14.0 no Site-Teste confirmada, com backup; Core mantido em 1.39.0. Os hashes finais estão no relatório e manifesto da entrega. Permanecem somente as homologações reais explicitadas acima; nenhum retorno Core ficou bloqueando a implementação.
