# Impacto de wp-mcp-google-fator3 0.14.0 em base-site-core-fator3

Revisão 2 · 20/10/2026 · Etapa: entrega da implementação
Classificação: validação coordenada; nenhuma extensão de contrato requerida nesta entrega.
Emissor: Fator3 MCP Google 0.14.0, base direta 0.13.0.
Destinatário: Fator3 Site Core 1.40.0, fonte e instalador recebidos e examinados.
Pedidos: MCP Google 28; Core 236. Pedido 29 é interno ao Google.
Este é o único encaminhamento ativo Google → Core. Substitui a revisão de planejamento no mesmo arquivo; não exige resposta antes da implementação Google.

## Entrega concreta

O pacote de dependência Core 1.40.0 foi incorporado e revisado na árvore Google. Contrato preservado: `site-conversion-delivery/1.0.0`, filtro `f3base_conversoes_adaptador`, destinos `ga4` e `google_ads`, métodos `capabilities()` e `send()`. Outro adaptador preexistente é preservado. Google não instala o Core nem cria fila comercial paralela.

Foram implementados configuração administrativa por conexão, segredo MP cifrado, verificação explícita, concessão revogável e prontidão com expiração de 24 horas. Configuração pública e motivos de indisponibilidade estão em `google/conversion-delivery-status` e `google/status.conversion_delivery`. As operações de configuração e verificação exigem `expected_revision`. Mais de uma conexão habilitada para o mesmo destino recusa a seleção.

O adaptador atende ao contrato PHP do worker tanto no cron nativo quanto no executor de tarefas do Core. Não pressupõe que todo processamento ocorra dentro de um `doing_action` específico. A autorização para background é a concessão administrativa armazenada e revalidada; não há impersonação de usuário e não foi criada rota MCP/REST para envio direto.

GA4 preserva IDs, sessão e timestamp recebidos, verifica propriedade/fluxo/segredo e depura cada payload antes da coleta. Não transforma session_id em timestamp, não inventa engagement e não confunde 2xx com atribuição. Ads usa um clique, um item por chamada, `orderId=record_id`, consentimento e valor/moeda do payload. Resultado parcial, timeout ou ACK sem ação/clique/instante correspondentes permanece incerto, sem repetição HTTP.

## Decisões que ficaram resolvidas

- O Core 1.40.0 já possui modo por destino e snapshot por registro. O Google consome essa decisão; não a substitui.
- O Core 1.40.0 já recusa múltiplos IDs de clique. O Google mantém sua própria recusa defensiva.
- O leitor antigo `site-conversion-purposes/1.0.0` permanece. A leitura de transporte `1.1.0` é negociada separadamente e validada por schema fixado.
- Não foi criada extensão `site-conversion-delivery/1.1.0`, estado assíncrono ou integração Data Manager sem evidência concreta de necessidade. UploadClickConversions exige histórico elegível declarado pelo administrador e ação verificada. A declaração não equivale a consulta de recibo remoto.
- `configured` no leitor não significa prontidão de envio. Usar `capabilities().ready`, contrato e destination_ref.

## Ações restantes para operação

1. Configurar no Google a conexão, destino, credencial, segredo MP e perfil/política de escrita autorizados; verificar explicitamente cada destino. Para Ads, usar comprovante real de upload elegível, nunca fixture ou validateOnly. Expiração ou alteração exige nova verificação.
2. Selecionar o modo servidor no Core somente após prontidão. Preservar consentimento atual e snapshot, elegibilidade, regra de exclusão de audiência, proteção contra duplicação, eliminação e revisão de destino.
3. Homologar um contato autorizado em ctooffice/Android WebView: um generate_lead na sessão original, uma conversão na ação Ads pretendida e ausência de duplicação pelo navegador. O resultado `entregue` do GA4 comprova somente recebimento HTTP (`processed:null`). A comprovação comercial é externa.
4. Manter registros incertos para reconciliação. Nunca reenviar com base apenas em timeout ou sucesso de lote. Se houver evidência concreta de que a conta requer Data Manager, registrar a exigência e o recibo esperado neste mesmo encaminhamento antes de ativar outro transporte.

Nenhuma dessas etapas significa que o Google aguardou código ou retorno do Core para concluir sua parte. Não há mudança adicional de código Core solicitada nesta entrega. A verificação comercial e as credenciais não são inventadas por testes locais.

## Provas e identidade

O relatório Google 0.14.0 contém o hash imutável do instalador, a matriz efetivamente concluída, evidência do Site-Teste e limites. A bancada usa WordPress/PHP/MySQL reais e respostas Google simuladas. Inclui o diário e os executores reais do Core, confirma estados entregue/incerto e ausência de reenvio; preserva leitor 1.0.0, atualização/rollback e demais plugins.

Base recebida: Core 1.40.0 instalador SHA-256 `d3bc062730e71520662282f969f32ded12065762301406f9a61a3601a98736fb`; fonte `ef6c3fb7d39ca0556c963fdb1ac2d2c6706d5addf4d48532462aabea75ea2517`. Dependência recebida: SHA-256 `a67067f1367814596cea2fdadcc8aed90f8085aced3995868e0339c372d6d1a3`. Os 15 testes recebidos no handoff são históricos; não contam como testes próprios.

O Site-Teste tinha Core 1.39.0 na leitura anterior à atualização Google (requisição `0ff0ea10c66d7ca6459a8eb1`). O estado final consta do relatório. Não promover o Core apenas pela presença do ZIP recebido.

Encaminhamento pronto para o dono repassar ao responsável Core. Nenhum destinatário ou canal de envio direto foi identificado; não foi enviada mensagem externa.

Instalador Google fechado: 742208 bytes, SHA-256 `7b9681bed81fa265ac70379fd6ebb5d4b161923a8e10a7a4ad115af58cf3d001`. Matriz final: 833 verificações, 154 PHP com sintaxe válida. Site-Teste atualizado para Google 0.14.0, Core mantido em 1.39.0; requisição `99b37a730f0dd608638a0823`. Homologação comercial pendente.
