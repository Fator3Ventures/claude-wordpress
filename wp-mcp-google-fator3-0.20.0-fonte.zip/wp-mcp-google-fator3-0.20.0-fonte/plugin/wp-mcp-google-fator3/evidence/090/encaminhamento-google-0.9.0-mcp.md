# Encaminhamento Google 0.9.0 → MCP 0.22.0

A versão Google 0.9.0 reúne o escopo antes planejado como 0.8.6. Percurso solicitado: Google 0.8.4 → 0.9.0, MCP 0.21.0 → 0.22.0 e Core 1.31.0 → 1.33.0. Nenhum fonte ou instalador MCP foi alterado por esta entrega.

## Interfaces adotadas

- `executor-registration/1.0.0`: declaração explícita de `google/mcp-read` e `google/mcp-write`, modos e seis prefixos próprios. O registro anterior pelo filtro de configuração do servidor só é usado na ausência da capacidade nova; declaração inválida não ganha fallback. Bridge e alvo exigem autorização independente; executor aninhado e alvo de outro provedor são recusados.
- `package-distribution/1.0.0`: seleção, manifesto, revisão e guarda pelo SDK público. Removidos acesso Google a `f3_mcp_update_channels`, chamada a `UpdateChannel` e remoção/reencapsulamento de seus filtros. O recibo público preserva a intenção MCP quando o produtor está inativo; isso não autoriza fallback à origem Google.
- `ConnectionContext`: as novas coletas capturam apenas a identidade/política pública necessária. Revogação e alteração de política impedem continuidade e leitura de resultados. A ordem das chaves de objetos é normalizada; o `JSON_SET` usado para registrar `last_seen` no MySQL pode reordená-las sem alterar a autorização. Jobs vinculados a grant MCP exigem revalidação; jobs independentes conservam identidade WordPress.

Instalação limpa pelo caminho combinado e reativação de pacote presente/inativo são conferidas em requisição nova antes de manutenção. O Google não inicializa tabelas/opções durante consulta de diagnóstico para compensar uma ativação incompleta.

## Pontos do percurso a conferir

O adaptador nominal de `ExecutorRegistry::finalize()` entregue no MCP 0.22.0 reconhece Google **0.8.5**, mas a base efetivamente instalada informada é **0.8.4**. Na prova nativa da combinação transitória MCP 0.22.0/Google 0.8.4, `admitted` não continha executores do provedor Google. A atualização Google continuou disponível pelo executor de pacotes MCP. Depois da atualização, a 0.9.0 registrou suas duas bridges explicitamente e os testes de autorização passaram.

**Ação para o MCP:** considerar a base 0.8.4 real ao decidir se deve preservar a exposição das bridges durante esse intervalo de atualização. Isso pertence ao produtor MCP; não foi criado adaptador privado no Google. Para evitar esse intervalo nesta implantação, pode-se atualizar Google antes do MCP; ambas as ordens de atualização são ensaiadas, sem trava no código ou passagem por 0.8.5/0.21.1.

Nos ensaios preliminares dentro da pasta de trabalho houve recusas intermitentes `rollback_conflict` na prévia Google, após upload aplicado. A inspeção posterior encontrou `includes/Storage/Migration.php` e `includes/Integration/Transition.php` da 0.8.4 na pasta nova, embora ausentes do ZIP. Também houve uma ocorrência de `package_postimage_conflict` no Core, com arquivos removidos da versão anterior presentes no destino. Ensaios instrumentados chegaram a observar exclusão desses arquivos no diretório antigo; não se estabeleceu a causa de sua presença posterior.

Os mesmos percursos executados em diretórios temporários independentes passaram. A bancada foi reforçada para conferir, **depois do encerramento dos processos**, o inventário e o SHA-256 de todos os arquivos instalados de Google/MCP/Core contra seus ZIPs. A aprovação final exige essa igualdade, além da prévia de rollback. As evidências finais e o registro separado dos ensaios preliminares acompanham o fonte. Não houve alteração no executor MCP, limpeza histórica no Google ou relaxamento da prévia. O resultado local aprovado não identifica a causa anterior nem comprova que a condição não ocorra em outro filesystem.

**Encaminhamento de investigação:** conservar a checagem de pós-imagem e, se o conflito ocorrer na homologação, registrar inventário antes/depois, diretórios de staging/previous, journal e ambiente de arquivos. Não forçar rollback com pós-imagem divergente. Este é um achado de bancada sem causa atribuída ao MCP, não uma correção solicitada como fato comprovado.

## Fronteiras preservadas

O Google mantém execução 2.0.0, configuração 4.0.0, catálogo 3.0.0 e leitor GSC 1.0.0. Campos novos de diagnóstico e coleta são declarados no catálogo. `success` do status significa observação executada, não prova remota. Schemas de saída permanecem extensíveis aos metadados do canal.

Não há trava de instalação por versão/presença dos acompanhantes. Não foram executadas ações na frota, autenticações Google reais, modificações em concessões de usuários reais ou implantação de crontab externo. Arquivos rollback não restauram banco ou efeitos Google.
