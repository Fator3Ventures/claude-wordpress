# Instalar Fator3 MCP Google 0.9.0

Use `wp-mcp-google-fator3-0.9.0.zip` para instalar em WordPress limpo ou substituir a 0.8.4 **sem desinstalar**. Não passe por 0.8.5/0.8.6. O percurso dos acompanhantes é MCP 0.21.0 → 0.22.0 e Core 1.31.0 → 1.33.0. Não há trava de instalação por versão, presença ou ordem.

Faça backup de arquivos/banco e siga a pausa/drenagem documentada se houver trabalho em andamento. Pelo painel WordPress, envie o ZIP instalável e confirme a substituição. Pelo MCP 0.22.0, upload com ativação foi validado tanto para instalação inicial quanto para atualização. Envie hash e slug esperados. Nunca instale o ZIP fonte na pasta pública.

Para evitar a lacuna transitória das bridges quando MCP 0.22.0 convive com Google 0.8.4, prefira atualizar Google primeiro. Ambas as ordens chegaram ao trio final nos testes. O encaminhamento MCP detalha essa observação e os conflitos de pós-imagem vistos na bancada inicial. Se o instalador informar conflito de pós-imagem/rollback, preserve seu recibo e confira os arquivos; não force retorno sobre uma pasta divergente.

Em requisição nova, confira versão 0.9.0, `google/status`, `google/storage-status`, `storage.ready` e cron. A atualização preserva cifras, conexões e vínculos. `google/maintenance` é a operação atual; grants de rotas antigas de migração não são convertidos. Não deduza prontidão ou acesso Google somente de `success:true` do status.

Service Account permanece padrão e OAuth fica separado. Use `google/selftest` para verificar acesso remoto autorizado e sua cobertura. Nenhuma conta real foi utilizada na validação desta entrega.

Novidades: `google/query` aceita coleta completa com limites/cursor e calendário; exportação exige completude por padrão. Parcial intencional usa `completeness_policy:allow_partial`. Leia os campos de cobertura, qualidade, extração, escrita e verificação. Append com resultado desconhecido exige conferência; não repetir cegamente.

A documentação atualizada e o script Cloud Shell estão nos downloads autenticados do plugin; fontes, testes, evidências e guias integrais acompanham o ZIP fonte. Contratos públicos Core/MCP substituem os acessos privados. Não foram alterados os outros plugins.

Validação: 1148 testes unitários, 13650 asserções e 1451 verificações nativas. SHA-256 instalador: `333e3f177be1095ac9e568e66d4d8cab9b4dfbd4d6a86505e8b7a02583182b32`. Consulte o relatório de entrega para os limites dos testes e os encaminhamentos Core/MCP.
