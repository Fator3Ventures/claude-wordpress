# Encaminhamento Google 0.9.0 → Core 1.33.0

A entrega Google incorpora o plano anteriormente chamado 0.8.6. As bases são Google 0.8.4, Core 1.31.0 e MCP 0.21.0; não se exige instalar versões intermediárias. Este trabalho não modifica os fontes ou instaladores Core.

O Google passa a consumir exclusivamente `F3Base_Medicao_Contexto::{capabilities,snapshot,events}` para a configuração de medição e o catálogo. Foram retiradas leituras privadas de `F3Base_Options`/`f3base_*` dos adaptadores `CoreBinding` e `TagManager/Diagnostic`. Os quatro schemas publicados no pacote Core 1.33.0 recebido foram incluídos como referência, sem alteração, e compilados em dados PHP protegidos no Google.

A visão configurada/efetiva, os seis slots, proveniência, escopo e revisões permanecem distintos. `meta_server` é lido separadamente do pixel do navegador. O binding GA4 requer um único stream correspondente e relê a revisão após a descoberta e antes da gravação Google. O Google não altera o Core, cria propriedade automaticamente nem infere destino GA4 a partir do container GTM.

O catálogo é paginado com revisão esperada, orçamento, verificação de progresso e rejeição de campos fora do schema. A ordem dos eventos é a do produtor; não foi imposta ordenação alfabética. O teste nativo também força páginas de cinco itens para comprovar a junção de páginas do catálogo publicado. Ler catálogo não cria tags, dimensões ou conversões.

O leitor editorial `search-console-reader/1.0.0`, concessões explícitas, contexto do consumidor, orçamento e isolamento do cron não mudam. A coleta completa/calendário de `google/query` é uma funcionalidade distinta e não altera esse SDK. Nenhuma consulta SDK passa a produzir `ultima_cli`/`ultima_http` Google.

Core configuração 7.1.0 foi corrigida na documentação corrente Google. Não há bloqueio por versão do Core: capacidade ausente ou schema incompatível retorna estado específico, mantendo IDs explícitos e as funções independentes disponíveis.

Não há mudança obrigatória identificada no Core para consumir esta release. Recomenda-se manter os schemas e o significado das revisões como contrato público: alterações do contexto efetivo por filtro também precisam ser observáveis. Uma futura extensão incompatível deve anunciar sua revisão/contrato, para o consumidor não interpretar um contexto parcial como completo.

As evidências finais, hashes e contagens constam do relatório de entrega Google. Banco/HTTP WordPress e plugins são reais no laboratório; respostas Google são simuladas. Não foi verificada emissão de tags no navegador, recebimento GA4/Ads ou commit remoto em conta real.
