# WP MCP Google 0.8.6 — plano da próxima versão

Revisão 4 · 15/10/2026 · Situação: planejada, sem implementação. Incorpora o plano integrado e o encaminhamento Google revisão 3, os contratos sociais revisão 1, o impacto Core 1.33.0 revisão 2, a especificação pública Core 1 e o plano MCP 0.22.0 revisão 4.

**A 0.8.6 reunirá confiabilidade analítica GA4/GSC, substituição dos acessos privados aos acompanhantes por contratos públicos, diagnóstico e documentação.** A base de desenvolvimento é o Google 0.8.5 entregue. A revisão amplia o escopo anterior com paginação completa optativa, qualidade dos dados, exportação verificável e calendário. O SDK GSC consumido pelo Core mantém sua semântica; novas interfaces de medição e distribuição são dependências distintas.

## 1. Decisões preservadas

- Entradas de validação: WordPress limpo, Google 0.8.4 inicializado e Google 0.8.5 inicializado. A 0.8.5 é a base de desenvolvimento, sem obrigar uma instalação 0.8.4 a passar por ela.
- Instalação, ativação e carregamento independem da versão, presença e ordem dos companheiros. Versões e hashes identificam os ensaios; não se tornam restrições no runtime. Uma operação dependente de capacidade ausente deve informar essa ausência.
- Não reintroduzir migrações, importadores, aliases, permissões transferidas ou reparos intermediários para pacotes anteriores à base aceita. Preservar os dados e as operações válidas das bases atuais.
- Uma entrega completa, sem versões intermediárias. Desenvolvimento, validação e empacotamento são etapas internas.
- Plugin genérico, Service Account como padrão e métodos de autenticação separados. Preservar as funções entregues de GA, GSC, Ads, GTM, filas, relatórios, configuração, recuperação e auditoria.
- Nenhuma modificação nos fontes MCP ou Core. Os respectivos instaladores usados como referência devem permanecer íntegros.
- A arquitetura passa a reconhecer cinco plugins próprios independentes: Core, MCP, Google, Meta e LinkedIn. Meta inicia com Instagram Insights; LinkedIn cobre Pages, Ads e provedor Lead Sync. Meta Ads permanece no MCP oficial externo, consultado pelo agente.
- Sem BigQuery, importação/migração Porter, exigência de seus aliases, cliente MCP remoto no WordPress ou tokens/coletores sociais no Google. Porter é referência comparativa recebida, sem dependência de licença para executar o projeto.
- A entrada Google 0.8.4 já aceita neste plano continua coberta, além da 0.8.5. A referência do novo plano integrado ao trio atual não acrescenta suporte a bases anteriores nem exige passagem intermediária.

### Escopo fechado e itens condicionais

| Tickets recebidos | Destino nesta release |
|---|---|
| GOOGLE-01, GOOGLE-02, GOOGLE-04 | Incluídos: adaptadores públicos Core, distribuição MCP e declaração de bridges. Exigem definição e implementação das capacidades correspondentes pelos produtores. |
| GOOGLE-05 | Incluído nas frentes de validação, documentação e isolamento já previstas. |
| GOOGLE-07, GOOGLE-08, GOOGLE-09, GOOGLE-10 | Incluídos: coleta completa, exportação, qualidade e calendário. P2 indica ordem de trabalho, não uma release intermediária. |
| GOOGLE-11 | Receitas das capacidades existentes entram na documentação. Novos atalhos ficam opcionais, sem demanda recorrente demonstrada para incluí-los no compromisso de código. |
| GOOGLE-03 e GOOGLE-06 | Mantidos no backlog condicionado. Homologação Google Ads e SDK de leads Ads não integram a entrega imediata. |
| GOOGLE-SOC-01 | Escritor Sheets para consumidores sociais permanece opcional e condicionado à priorização explícita. Não bloqueia esta release nem os novos provedores. |

Entregar integralmente o escopo incluído em uma única versão. Interfaces ainda propostas ou testes pendentes não serão declarados implementados/homologados. As dependências de contrato não se transformam em restrições numéricas de instalação.

## 2. Fundamentação do escopo

| Constatação | Evidência examinada | Consequência para o plano |
|---|---|---|
| MCP 0.21.1 usa ativação silenciosa no worker de pacotes. | `RecoveryEngine::activate_worker()` chama `activate_plugin(..., false, true)`; o plano MCP 0.22.0 trata o modo conforme estado anterior e intenção. | Comprovar a correção no MCP com Google 0.8.5 original. Não criar inicialização automática no Google para compensar o caminho defeituoso. |
| A prova Google de instalação nova usa duas chamadas. | `tests/native085/install.php`: upload com `activate:false`, `plugins/activate`, nova leitura de estado e depois manutenção. | Acrescentar o fluxo combinado corrigido e conferir todas as pós-condições relevantes antes da manutenção. O teste existente não prova esse fluxo. |
| Os schemas de diagnóstico são incompletos. | `Storage/State.php` retorna `storage`, `maintenance` e `cache`, mas declara apenas `maintenance`. `Unified/Abilities.php` também não descreve vários campos que `google/status` já retorna, incluindo `storage` e `cache`. | Completar os schemas e reutilizar definições comuns, preservando valores e significado das respostas. É melhoria concreta para agentes, sem nova operação de negócio. |
| A bancada contém expectativas vinculadas à release. | `tools/lab.py`, `tools/validate.py` e `tests/native085/*` fixam caminhos/versões; o cenário de upgrade confere MCP 0.21.1 e Google 0.8.4/0.8.5. | Parametrizar entradas e expectativas explícitas para testar a próxima candidata sem substituir strings dispersas. |
| A inicialização possui várias etapas locais. | Hook de ativação do Google define opções e prepara armazenamento, manutenção e executor; não agrega o resultado de todas as etapas em um recibo. | Testar falhas parciais e observar estado real. Não deduzir prontidão somente do retorno da ativação, nem apresentar essa observação estática como novo defeito reproduzido. |
| O leitor GSC do Core continua suficiente para seu recorte editorial. | Contrato `search-console-reader/1.0.0`, fontes Google 0.8.5 e impacto Core revisão 2. | Preservar o leitor; CORE-01/02 adicionam um contrato distinto para o contexto de medição. |
| A referência documental ao contrato Core está desatualizada. | `docs/SDK-PHP.md`, `CONTRACTS.md` e suas cópias em `includes/Data/Documentation.php` citam Core configuração 6.6.0; `class-f3base-config-contrato.php` do Core 1.32.0 declara 7.0.0. | Corrigir todos os documentos correntes e regenerar a documentação incorporada; preservar SDK 1.0.0 e configuração Google 4.0.0. |
| Há uma contagem documental divergente. | `CONTRACTS.md` cita 282 habilidades; `docs/ability-catalog.json`, `docs/CATALOGO.md` e README da 0.8.5 informam 281. | Conferir a contagem na exportação final e eliminar valores divergentes no guia incorporado. A conferência permanece documental, sem filtro operacional por quantidade. |
| O Core planeja corrigir seu checkpoint de atualização. | Encaminhamento Core 1.33.0 relata reutilização de etapas/finalização de outro ciclo na 1.32.0; a correção candidata ainda não foi recebida. | Manter a responsabilidade no Core. A atualização ativa deve funcionar sem exigir repetição do hook de instalação pelo MCP e sem inicialização privada pelo Google. |
| O Google acessa armazenamento privado do Core por dois caminhos. | `CoreBinding::source()` lê opções `f3base_*`; `TagManager/Diagnostic::option()` chama `F3Base_Options` ou usa `get_option`. | Um adaptador para a visão pública configurada/efetiva e o catálogo de eventos; retirar esses acessos. O acoplamento foi confirmado; divergência operacional não foi reproduzida. |
| O Google interfere no filtro de atualização MCP. | `Updater::channel_selected`, `coordinate_channel` e `check` leem `f3_mcp_update_channels`, chamam `UpdateChannel` e removem/reencapsulam seu callback. | Consumir a seleção pública de distribuição; cada plugin controla seus próprios filtros. A inspeção não comprova um incidente de download. |
| Há uma página por conta/recorte nas consultas unificadas. | `Unified/Query::run_ga` chama `run_report` uma vez por propriedade; `SearchConsole/Api::unified` faz uma chamada por propriedade/período e anuncia próximo offset. | Reutilizar paginação nativa e adicionar execução limitada/retomada. Não apresentar a nova coleta como correção de ausência de APIs GA4/GSC. |
| A qualidade GA4 não é integralmente propagada e exportação aceita truncamento. | `run_ga` resume a tabela; `Sheets/Export::execute` acrescenta aviso de truncamento e prossegue. Todos os relatórios já são calculados antes da primeira escrita. | Preservar essa preparação e acrescentar completude obrigatória quando exigida, metadados por recorte e recibo separado de escrita. |

O planejamento MCP vigente é **0.22.0, revisão 4**, substituindo a versão planejada 0.21.2 sem release intermediária. MCP-03/P09 agora é obrigatório, com o registro proposto `executor-registration/1.0.0`. Isso resolve a divergência de escopo relatada no impacto Core revisão 2; implementação e homologação conjunta continuam pendentes. Os números relatados na entrega Google 0.8.5 — 1.115 testes unitários, 12.621 asserções e 1.322 verificações nativas — permanecem evidência daquela entrega. Não foram reexecutados neste planejamento.

O encaminhamento Core 1.33.0 e sua especificação pública também são planejamento. A divergência documental foi confirmada nos fontes disponíveis; o defeito de checkpoint é um achado relatado pelo responsável Core, não reproduzido nesta rodada. Ele é distinto da supressão de hooks no fluxo de primeira ativação MCP. Sua correção preserva o leitor GSC; CORE-01/02 exigem a mudança funcional do consumidor de medição em G06.

Os novos anexos relatam comparações reais na Korvena com Google 0.8.4/Core 1.31.0/MCP 0.21.0: GA4 com 38 linhas/94 valores e GSC com 22 linhas/88 valores equivalentes; catálogo de uma propriedade com 387 dimensões e 98 métricas, sem aliases. São evidências recebidas de uma amostra, não reexecução nesta rodada nem certificação da candidata. Alto volume, receita/conversões positivas e cliques/CTR positivos permanecem por validar. O JSON bruto `evidencias-validacao-ga4-gsc.json`, citado nos documentos, não veio entre os oito anexos desta rodada; não atribuir verificação independente aos seus registros.

## 3. G01 — Completar os contratos de diagnóstico

**Prioridade alta.** Trabalhar em `includes/Storage/State.php`, `includes/Cache.php`, `includes/Unified/Abilities.php`, nas definições relacionadas e nos exportadores documentais.

1. Criar definições reutilizáveis para o estado do armazenamento e do cache, utilizadas tanto por `google/storage-status` quanto por `google/status`. Reutilizar os schemas existentes de manutenção, cron e diagnóstico MCP.
2. Descrever os campos públicos que o estado já devolve: tipos, nulabilidade, significado e presença conforme o escopo. Cobrir a resposta da conexão selecionada e o resumo `all_connections`, sem exigir campos ausentes nessa segunda forma.
3. Explicitar que `success` do diagnóstico informa a execução da consulta. Prontidão local vem de `storage.ready`; o resultado da manutenção e a saúde do cron têm campos próprios. `auth.configured` não certifica acesso remoto aos recursos.
4. Documentar `live:false` como observação local padrão. Preservar o comportamento explícito de `live:true`, os campos condicionais de teste de token e a recusa de `live:true` com `all_connections`.
5. Manter campos desconhecidos extensíveis quando o envelope/registro MCP acrescenta metadados. Não fechar o objeto de forma que uma resposta real válida passe a ser rejeitada pelo schema.
6. Gerar catálogo, exemplos e documentação a partir das definições do código. Acrescentar validação de cobertura: os campos retornados nos cenários exercitados devem estar descritos; a mera aceitação por `additionalProperties` não basta.

**Aceite:** respostas reais de estado pronto, armazenamento indisponível, leitura falha, credencial ausente e manutenção pendente validam contra os schemas. Uma fixture com tipo incorreto é recusada. Catálogo estático, registro executável e documentação concordam. Nenhuma credencial ou conteúdo cifrado aparece nos exemplos.

A intenção é manter catálogo 3.0.0, configuração 4.0.0, execução 2.0.0, armazenamento/manutenção 2.0.0 e SDK GSC 1.0.0 nos seus respectivos significados. As extensões analíticas terão schemas, defaults e limites documentados; a nova política padrão de exportação exige nota explícita de comportamento. Contratos públicos de acompanhantes recebem anúncio próprio. Se a implementação alterar semântica contratual adicional, revisar a versão correspondente antes do fechamento. Atualizar `meta.fator3.version` para 0.8.6 em todas as habilidades; 281 é a contagem do pacote de referência, não uma meta fixa da candidata.

## 4. G02 — Comprovar o ciclo de instalação do Google

**Prioridade alta.** Ampliar os ensaios nativos sem substituir o ciclo do WordPress por chamadas a inicializadores privados.

Na instalação nova pelo MCP corrigido, usar `plugins/upload-base64`, hash esperado, slug esperado, `overwrite:false` e `activate:true`. Em **outra requisição**, antes de `google/maintenance`, de execução de cron ou de configuração reparadora, verificar:

- Identidade dos arquivos e versão Google carregada.
- Opções iniciais realmente persistidas: canal e GA ativos, Ads desativado, Service Account selecionado e limites padrão. Distinguir opção ausente de opção gravada com `false`.
- Tabelas e colunas correntes acessíveis, com `storage.ready:true`.
- Evento de manutenção e executor Google presentes, sem duplicatas; preservar eventos MCP/Core.
- Catálogo e configuração descobertos no primeiro acesso, sem aquecimento manual do registro.
- Ausência de chamadas remotas Google e de configuração de recursos externos durante a ativação. Uma instalação sem credenciais pode estar corretamente inicializada.

Manter os ensaios de upload inativo seguido de ativação explícita; acrescentar pacote já presente e inativo, inclusive ZIP idêntico. Na atualização de um Google previamente ativo, comprovar preservação de opções, segredos, vínculos, jobs e agendas. Não exigir repetição do hook de primeira ativação: o plano MCP preserva o ciclo silencioso de atualização.

Repetir consultas de status em fixtures com tabela/agenda ausente e observar que elas não executam manutenção, não preenchem opções iniciais, não recriam tabelas/agendas e não registram uma passagem de trabalho. Considerar separadamente arquivos de trava e a auditoria normal da chamada; sua existência não prova execução do cron.

Injetar falhas locais delimitadas de persistência/estrutura/agendamento para conferir que a observação mantém indisponibilidade ou falha específica. Se esse teste revelar falsa prontidão no Google, corrigir o ponto e anexar a reprodução. Não acrescentar marcador de versão, migração ou reparador de instalações antigas como solução presumida.

**Responsabilidade MCP:** escolha do modo de ativação, contador do hook em plugin mínimo, worker, diário, reconciliação, cópia MU, OPcache e comportamento após interrupção. **Responsabilidade Google:** comprovar suas pós-condições e preservar dados. O Google não deve interpretar sucesso de pacote como homologação de suas credenciais nem acionar manutenção escondida.

## 5. G03 — Tornar a bancada reutilizável

**Prioridade média, necessária para executar a matriz.** Refatorar `tools/lab.py`, `tools/validate.py`, manifesto de entradas, política de release e testes nativos.

- Separar origem do cenário (`clean`, instalação pelo MCP, atualização) da identidade do pacote-base. Registrar 0.8.4 e 0.8.5 como entradas de teste, sem criar caminhos de migração no plugin.
- Ler versões e hashes esperados de um manifesto validado. Comparar o observado com essa expectativa independente; não transformar o valor retornado pelo plugin na própria expectativa do teste.
- Usar uma localização estável para os testes nativos ou um identificador de suíte validado. Preservar a restrição que impede executar caminhos arbitrários fora da suíte.
- Declarar apenas os insumos exigidos por cada cenário. Um ensaio Google isolado não deve depender de ZIPs MCP/Core ou de uma base de upgrade que não utiliza; um ensaio integrado deve recusar a ausência dos seus insumos.
- Preservar diretório de laboratório identificado, reset restrito ao diretório próprio, validação de caminhos dos arquivos compactados, serviços locais isolados e transporte externo bloqueado/simulado.
- Registrar origem, ordem de instalação, hashes, versão observada, suíte e identidade do código testado em cada evidência. Manter a vinculação aos bytes da candidata e rejeitar evidência ausente, alterada ou de outro pacote.
- Preservar as provas históricas 0.8.5 como históricas. Não renomeá-las para aparentar execução da 0.8.6 nem somar seus testes aos resultados novos.

**Aceite:** a mesma infraestrutura executa os cenários limpo, instalação MCP e atualização de ambas as bases com expectativas distintas; entrada/hash incorreto, script fora da suíte e reset de diretório alheio continuam recusados. O arquivo de configuração da bancada não condiciona a instalação do plugin em sites reais.

## 6. G04 — Regressão das integrações atuais

Executar casos dirigidos aos contratos compartilhados, mantendo a suíte unitária obrigatória e evitando duplicar toda a suíte interna MCP.

| Área | Comportamento a preservar |
|---|---|
| Bridges | Permissão para a bridge não concede a habilidade alvo. Manutenção exige sua autorização atual e administração; grant de rota retirada não é convertido. |
| Catálogo | Primeiro HTTP e primeiro WP-CLI nas duas ordens de carregamento. `google/maintenance` presente; rotas de migração/transição retiradas permanecem ausentes. |
| Configuração 4.0.0 | Mescla/substituição, omissão/vazio/null, redução confirmada, revisão/hash e recusa sem gravação parcial indevida. |
| Diagnóstico | Estado consultado não equivale a teste remoto aprovado. Preservar resultado estruturado do selftest e erros reais através do handler MCP. |
| Cron e manutenção | Origem, histórico, executor e manutenção continuam separados. Consultas não fabricam `ultima_cli`, `ultima_http` ou atividade recente. Eventos e guardas dos provedores permanecem independentes. |
| Recuperação | Pausa e drenagem respeitadas; efeito remoto desconhecido não é reenviado. Rollback de arquivos não é anunciado como reversão de banco ou chamadas Google. |
| Core/SDK | Preservar hook `f3_mcp_google_register_consumers`, contrato `search-console-reader/1.0.0`, consumidor `base-site-core-fator3`, `query` e `effective_status`. Exercitar conexão não padrão, concessão explícita, concessão ausente/ambígua/ilegível e erros de leitura, sem fallback para a conexão corrente ou autorização implícita. A consulta SDK não produz passagem cron Google. |
| Core/LinkedIn | Pausa e manutenção Google preservam recibos, hooks, filas, configuração e segredos Core. A callback LinkedIn mantém seu ciclo próprio, sem exigir autenticação MCP nem produzir trabalho/cron Google. |

Quando o Core 1.33.0 ou outra candidata que publique as capacidades necessárias estiver disponível, repetir a parte pertinente dessa matriz com o binário original identificado por hash. O Core comprova seu ciclo privado de atualização; o Google comprova a fronteira pública e a preservação de seus dados. Não adicionar chamadas a classes privadas Core, manutenção Google automática ou credenciais GSC próprias no Core. As provas Google anteriores são referências recebidas, não testes do Core candidato.

Google Ads continua sendo capacidade de código com configuração e homologação próprias. Na documentação do ambiente do dono, registrar a pendência de configuração/validação operacional; instalação, interruptor habilitado, credencial configurada ou testes simulados não autorizam declarar esse canal operacional. Essa ressalva não desabilita Ads para outras instalações configuradas. Nenhuma dimensão, tag ou configuração remota será criada automaticamente nesta integração.

Não modificar os schemas de resultados MCP ainda apenas propostos. Os nomes/enums finais de ativação devem ser lidos da implementação MCP recebida, sem criar adaptador baseado em campos inventados.

## 7. G06 — Contexto público Core e catálogo de eventos

**GOOGLE-01; depende de CORE-01/02.** Criar um único adaptador público usado por `CoreBinding` e `TagManager/Diagnostic`. Adotar a especificação 1 recebida, ainda proposta: `site-measurement-context/1.0.0`, produtor `base-site-core-fator3`, capacidades `measurement.context.read` e `measurement.events.read`.

### Descoberta, autoridade e erros

Ponto PHP proposto: `F3Base_Medicao_Contexto::capabilities(): array`, `snapshot(): array` e `events(array $input = []): array`. Descobrir por `class_exists`, `is_callable` e descritor depois de concluídos os callbacks de registro em `plugins_loaded`; não forçar inicialização durante descoberta precoce. Verificar identidade, contrato, capacidades e `schema_revision`, sem importar arquivos ou comparar versão numérica Core.

Retirar leituras `f3base_*`, chamadas a `F3Base_Options` e inspeção de arquivos privados nesses dois fluxos. Ausência vira `unavailable`; classe/método/descritor/schema incompatível vira `unsupported`. Não recorrer ao armazenamento privado para compensar uma recusa. IDs explícitos Google continuam utilizáveis e nenhum erro de descoberta apaga vínculos salvos.

O SDK PHP é cooperação local entre plugins confiáveis e funciona sem pessoa autenticada, inclusive cron. Não cria usuário, contexto MCP ou grant de API. As abilities administrativas Core propostas `f3base/medicao-contexto-ler` e `f3base/medicao-eventos-ler` exigem `manage_options`, perfil e concessão do transporte. Google usa o SDK diretamente, sem enviar essas leituras pelas suas bridges ou depender de MCP ativo.

Preservar `ok`, `code`, `contract`, `provider` e `data`; falha usa `data:null`. Validar o resultado antes de projetá-lo nas respostas Google. Distinguir `unavailable`, `unsupported`, `unreadable`, `revision_conflict`, `invalid_input` e `not_authorized`; não decidir pela mensagem nem converter `ok:false` em aprovação. Exceção na leitura vira falha sanitizada, sem detalhes de SQL, option ou segredo. Sucesso da consulta Google de diagnóstico e resultado do contexto Core devem ficar identificáveis separadamente, sem omitir a falha de origem.

### Fotografia configurada/efetiva

Validar schemas completos e fechados fornecidos pelo produtor. Isso não altera a extensibilidade do envelope externo Google descrita em G01. Uma revisão de schema não suportada afeta apenas esta integração; não aceitar campo desconhecido copiando dados brutos para logs ou resposta. O exemplo parcial do anexo não serve como fixture positiva de snapshot completo.

| Parte do snapshot | Regra do consumidor |
|---|---|
| Identidade temporal | `revision` e `events_revision` opacas, igualdade exata; `observed_at` UTC; `scope:site_request` limita a observação ao contexto corrente |
| Prontidão | Preservar `emission_mode`, `runtime_verified:false` e `remote_access_verified:false`; configuração não comprova entrega no navegador ou acesso remoto |
| Slots obrigatórios | `ga4`, `gtm`, `google_ads`, `meta`, `linkedin`, `clarity`; Clarity é contexto já existente no Core, sem novo conector Google |
| Estado do slot | `configured`, `empty`, `disabled`, `invalid`; erro SQL/indispensável falha o snapshot, sem produzir slot vazio |
| Valor físico | `configured.persisted` e `configured.fields`; ausência física usa `fields:null`, distinta de string vazia e valor inválido redigido |
| Valor usado no site | `effective.fields`, normalizado pelo produtor; campos permitidos por destino, sem objetos completos das integrações |
| Procedência | `recorded_origin`, `channel`, `recorded_at`, `record_status`, `effective_source` e `changed_by_filter`; desconhecido permanece desconhecido |
| Emissão/política | Rotas, transporte, prontidão/motivos e política declarativa sanitizada; nenhum consentimento individual ou dado de visitante |

Diferença entre valor físico e efetivo não prova filtro: padrão e normalização também a explicam. Google preserva a evidência de procedência Core; não deduz autor, filtro ou autoria do valor a partir de rótulo sem revisão confirmada. `disabled` preserva ID/motivo, sem ser confundido com ausência do plugin. ID inválido potencialmente sensível permanece redigido.

`gtm_container` em um destino exige mapeamento conhecido; existência de contêiner não comprova tags dentro dele. Não inferir deduplicação GA4 browser/servidor a partir de modo de outro destino. A política do snapshot é declaração; os gates Google de usuário, recurso, serviço e credencial continuam próprios.

### Binding e concorrência

Resolver propriedade/stream pelo Measurement ID efetivo público somente por operação solicitada. Registrar a fonte/revisão e o escopo usados; a fotografia administrativa não afirma qual ID todos os visitantes recebem. Exibir diferença configurado/efetivo quando houver. Binding Google identifica recurso remoto; slot Core identifica medição no site. Divergência exige escolha explícita, sem sincronização automática nos dois sentidos.

Reler snapshot antes/depois da descoberta remota e imediatamente antes de confirmar a gravação Google. Revisão diferente, leitura falha, ID vazio/desativado/inválido ou zero/vários candidatos recusa o novo vínculo e preserva o anterior. Conferência otimista não trava writers Core: registrar revisão e limitar a garantia ao que foi observado, sem prometer atomicidade entre plugins.

Revisões são comparadas por igualdade, sem ordenar ou recalcular a partir da option física. Mudança somente por filtro deve ser detectável. Não reutilizar cache entre requisições; eventual cache local não pode impedir a releitura de confirmação. Não persistir snapshot por uma consulta de estado; apenas a operação autorizada de binding registra a referência necessária.

### Catálogo de eventos

Consumir `events()` com `limit` de 1–200 (padrão 100), `offset` não negativo e `expected_revision` nas páginas posteriores. Usar a `events_revision` do snapshot também como expectativa na primeira página que servirá a um mapeamento. Conferir `revision`, `total`, `items`, `next_offset` e `complete`; não juntar páginas de revisões diferentes. Paginação sem progresso ou acima do orçamento do consumidor termina com estado explícito, sem anunciar catálogo completo ou executar mapeamento baseado em leitura parcial. Um novo snapshot não retoma silenciosamente um plano de mapeamento já confirmado.

Cada item declara nome, significado, gatilho, finalidade, emissor, parâmetros, destinos, papel de conversão e elegibilidade. Validar `conversion_role:none|form_observation|lead_conversion`. Não copiar regras comerciais nem fixar perfil de agência. Eventos `f3base_form_*` permanecem distintos de `generate_lead`; não transportar campos preenchidos, e-mail, telefone ou texto livre analítico de formulário. Lead importado não fabrica sessão, consentimento ou evento de navegador.

Publicar ou ler o catálogo não cria dimensões, tags ou conversões remotas. Sua conclusão refere-se ao catálogo Core, não à coleta GA4/GSC. A emissão no navegador permanece prova do Core; diagnóstico estático não prova dupla entrega.

**Aceite I01/T07/C14:** produzir casos de ausência/classe incompleta, esquema parcial/inválido, seis slots, vazio/desativado/inválido/ilegível, normalização versus filtro, origem não confirmada, mudança só por filtro, revisão estável apesar do horário, concorrência, erro de envelope, contexto cron sem usuário e dois streams correspondentes. Catálogo acima de uma página, última página cheia, revisão antiga, cursor sem progresso e dados sensíveis recusados. Depois comprovar os dois caminhos com Core e Google reais e inspecionar a retirada dos acessos privados. A16–A20 são provas do produtor Core; I01/C14 são integração e não certificam recebimento remoto.

## 8. G07 — Seleção pública da distribuição

**GOOGLE-02; depende de MCP-02.** Adotar `package-distribution/1.0.0` quando publicado, com dono efetivo, intenção selecionada, revisão, estado e operações públicas. Refatorar `Updater` para não ler `f3_mcp_update_channels`, chamar métodos internos de `UpdateChannel` ou remover/substituir callbacks MCP.

1. O MCP controla a incidência de seus filtros. O Google controla somente sua origem explicitamente configurada. A precedência do canal MCP selecionado é declarada pelo contrato, inclusive quando ambas as origens estão configuradas.
2. Separar observação local da seleção de consulta remota ao manifesto. Ausência/contrato sem suporte/conflito retornam estados próprios; diagnóstico não inicia download.
3. Intenção de usar MCP com canal indisponível não autoriza usar a origem própria automaticamente. O contrato deve esclarecer como a seleção fica observável após inativação do produtor. Sem prova da seleção, a decisão é desconhecida; não inferir permissão de outra origem.
4. Atualização manual por ZIP permanece disponível. Validar hash, slug, origem e autorização pelo executor responsável. Revalidar a seleção antes do despacho para detectar troca concorrente.
5. Preservar dados existentes, sem converter canais alheios ou criar migração de armazenamento. Nenhuma atualização Google muda os canais dos outros plugins.

**Aceite T09/C15:** canal MCP, origem própria, ambos, nenhum, pacote local, produtor inativo, contrato ausente, alteração de revisão e falha de origem; exatamente um dono executa, sem troca implícita de host. A coordenação deve resolver também a primeira adoção desse contrato para instalações que já selecionaram o canal; isso é estado corrente, não licença para ler options privadas.

## 9. G08 — Declaração pública das bridges e isolamento dos provedores

**GOOGLE-04; depende de MCP-03/P09, incluído obrigatoriamente no MCP 0.22.0 revisão 4.** Registrar `google/mcp-read` e `google/mcp-write` pelo contrato proposto `executor-registration/1.0.0`, aditivo ao SDK `server-integration/1.0.0` e à política 1. Fechar assinaturas/schemas com o produtor antes de implementar chamadas; nomes propostos não comprovam disponibilidade.

Declarar provedor, nome exato da ability, modo e restrição de alvos pertencentes ao mesmo provedor. Lista vazia autoriza zero; restrição ausente é inválida. Efetivar o registro após provedor/ability existirem, no ponto público de finalização acordado. Não criar inicialização recursiva da Abilities API na descoberta precoce. Preservar nomes, schemas e grants; deduplicar contribuição equivalente ao servidor. Conflito não escolhe a variante mais permissiva.

O MCP autentica/admite a chamada raiz; Google autoriza o alvo, recurso, serviço, conexão e credencial. Metadados fornecidos pelo chamador não viram autoridade. Categorizar uma ability como Google não basta para admitir qualquer executor.

**Aceite T04/T14/S04:** perfil de leitura recusa escrita inclusive simulada; Personalizado exige bridge e alvo; executor aninhado e outra porta/servidor são recusados; retorno preserva erro, null, cursor, avisos e parcialidade. Alvos Core, `meta/*` e `linkedin/*` são recusados pelas bridges Google. Provedor ausente afeta sua exposição, mantendo o funcionamento dos demais.

O MCP 0.22.0 planeja adaptar os metadados públicos do Google 0.8.5 original ao mesmo registro para preservar a base corrente. Essa adaptação pertence ao MCP; Google 0.8.6 declara explicitamente o contrato. Declaração explícita inválida/conflitante não recorre à adaptação para contornar a recusa. Retirar contribuição redundante Google somente com prova de descoberta e autorização equivalentes; ausência da capacidade nova informa indisponibilidade específica e conserva funções independentes e o percurso público existente nas combinações aceitas, sem incluir arquivos privados ou inventar autoridade.

O alerta do impacto Core revisão 2 foi superado pela decisão MCP 0.22.0 revisão 4. Manter a exceção nominal antiga não satisfaz MCP-03/GOOGLE-04. B30–B34 comprovam o produtor MCP; MCP C05 e Google C16 medem a adoção conjunta. Ambos continuam pendentes até implementação e ensaio, sem bloqueio numérico de instalação. A primeira entrega Meta/LinkedIn usa abilities diretas; Google não encaminha consultas sociais nem chama o MCP oficial Meta.

## 10. G09 — Coleta completa e qualidade GA4/GSC

**GOOGLE-07 e GOOGLE-09; prioridade alta.** Evoluir `Unified/Query`, `SearchConsole/Api` e os jobs existentes, reutilizando clientes HTTP, gates, orçamento e armazenamento Google. Nenhuma mudança no leitor editorial `search-console-reader/1.0.0`.

### Modos e continuação

- Consulta padrão permanece de uma página. Coleta completa é optativa e síncrona enquanto couber no orçamento. Criar/persistir um job requer operação explícita autorizada; uma leitura de estado nunca agenda trabalho.
- Proposta de entrada a implementar: `collection.mode` com `page` (padrão) ou `complete`. O schema final deve distinguir tamanho de página, limite global de linhas/bytes, páginas e tempo. Não reinterpretar o `limit` existente como permissão ilimitada.
- Fixar conexão, identidade autorizada, propriedades, períodos/comparação, campos, filtros, ordenação, tipo e agregação num plano com hash. A continuação opaca referencia esse plano e suas revisões; não é somente um offset editável pelo cliente.
- Revalidar usuário/consumidor, recurso, concessão, política, serviço e credencial a cada página/retomada e na consulta do resultado. Cursor vencido, de outro ator, consulta modificada ou revisão incompatível produz recusa verificável.
- GA4 usa `offset`/`rowCount` na versão nativa utilizada. GSC usa `startRow`; página cheia exige continuação até a condição de término. Contar linhas nativas antes de filtros locais: uma página com zero linhas após filtro não prova fim da origem.
- Ordenação local de uma página não comprova ordenação global. Para coleta completa, ordenar o conjunto confirmado dentro do orçamento ou declarar a limitação. Respostas paginadas não oferecem, por si, snapshot estável de dados recentes; registrar mudança observada e não prometer consistência temporal inexistente.
- Persistir páginas/lotes com identidade estável e confirmar seus dados antes de avançar o cursor. Retomada não incorpora novamente a página confirmada. Usar as travas/leases, orçamento e retenção atuais, sem novo histórico geral obrigatório ou expansão ilimitada de payload.
- Se orçamento/cota/interrupção impedir término, devolver progresso confirmado, motivo e continuação autorizada. Jobs funcionam sem MCP ativo. Não criar exportações recorrentes novas por essa mudança.

### Envelope e significado de completo

O schema deve manter `columns`, `rows`, `row_count`, `warnings` e demais campos válidos atuais, acrescentando informação estruturada por propriedade/período. O contrato social não obriga substituir a resposta Google por `social-reporting/1.0.0`.

| Informação | Regra de resposta |
|---|---|
| Plano/coleta | Modo, hash, páginas e linhas nativas/coletadas/emitidas, total quando conhecido, motivo de parada e continuação |
| Cobertura | Todos os recortes solicitados, seu resultado individual, datas solicitadas/efetivas e evidência disponível; recorte com erro não desaparece da contabilidade |
| Qualidade | Metadados nativos e proveniência por conta/período, versão API, instante, fuso, moeda e avisos tipados |
| Desconhecido | Campo ausente/nulo, vazio, zero, acesso negado e período não verificado continuam distintos; não preencher dias ausentes com zero |
| GA4 | Propagar metadata disponível, inclusive amostragem, limiares e perda de detalhe; preservar informação por página quando houver divergência |
| GSC | Preservar `responseAggregationType`, `dataState`, fuso da origem e indicações de dados incompletos quando presentes |

**Decisão:** completude significa término verificável do plano sobre as linhas disponibilizadas pela API, sem corte local ou recorte solicitado com falha. A garantia sobre todas as linhas da origem é outro campo. Em Search Analytics, manter `all_rows_guaranteed:false`; terminar a paginação não elimina o limite da API. Esse limite não deve ser confundido com interrupção local nem ocultado para autorizar exportação. Se um cliente exigir garantia irrestrita que a origem não fornece, retornar limitação explícita.

Não deduzir ausência de amostragem/supressão de um metadado omitido na projeção. A moeda/fuso de uma propriedade não é aplicada às outras. Um erro numa conta pode manter dados das demais com resultado parcial; não usar somente mensagens textuais para identificar a falha.

**Aceites T11/T13/T14:** mais de uma página; final exatamente cheio seguido de vazio; página inteiramente filtrada; falha em uma de duas propriedades/períodos; 403/429; alteração de revisão; interrupção depois da persistência e antes do cursor; limite de memória/bytes; consulta de resultado por outro ator; metadados ausentes e conflitantes; dados recentes; positivo/zero/null. Comparar envelope unificado com a resposta nativa que o originou, sem deduzir cobertura geral da amostra recebida.

## 11. G10 — Exportação com política explícita de completude

**GOOGLE-08; depende de GOOGLE-07/09.** Evoluir `google/export-to-sheet` e o job `export`, preservando a preparação de todos os relatórios antes da primeira escrita.

**Default decidido para pedidos novos:** `completeness_policy:require_complete`. Permitir parcial somente com `allow_partial` explícito. Esses nomes são proposta de schema da 0.8.6, ainda não disponíveis. Documentar a mudança frente à 0.8.5, que exporta truncamento com aviso. Planos e jobs já autorizados não são apagados; se a política nova alterar o plano/efeito previamente confirmado, exigir nova aprovação antes de escrever, sem migrar segredos ou conceder permissões automaticamente.

1. Validar todas as fontes/recortes. Em `require_complete`, coleta incompleta, falha de conta ou parcialidade desconhecida bloqueia qualquer limpeza/substituição do destino. `all_rows_guaranteed:false` da origem permanece no recibo e não torna o produto capaz de recuperar dados que a API não fornece.
2. Em `allow_partial`, escrever apenas o conjunto autorizado e indicar a causa de parcialidade por relatório/aba. Sucesso da escrita não altera a classificação da coleta.
3. Preservar os limites atuais do exportador: 500.000 células e corpo até 8 MiB. São limites do plugin, não uma afirmação do máximo da API Sheets. Excesso exige recusa ou plano explícito de divisão, com destinos e orçamento rastreáveis.
4. Manter criação, compartilhamento e escrita sujeitos a seus gates/confirmações. Fonte consultável não concede destino gravável. Texto externo continua literal; não inferir fórmulas.
5. Separar no recibo: completude da extração, limitações remotas, escrita aplicada/resultado desconhecido, linhas/células esperadas e verificadas e alcance da verificação. A amostra de leitura de até 50 linhas atual não certifica por si todas as células; definir e testar a conferência apropriada ao modo antes de declarar `verified` integral.
6. Congelar identidade/destino e manter trava/recibo de operação. Repetição de append confirmado reutiliza o resultado. Se a resposta da escrita se perder, reconciliar evidência antes de repetir; ausência de prova gera estado desconhecido, sem append cego.
7. Usar preparação isolada quando o fluxo exigir múltiplas escritas; não prometer transação do fluxo completo entre coleta, criação, preenchimento e compartilhamento. Registrar efeitos parciais e deixar a recuperação sob ação autorizada.

**Aceite T12:** falha na segunda página preserva destino; duas abas com uma fonte falha não iniciam escrita estrita; limite de células/corpo; destino sem grant; revogação; falha durante escrita; replay de append e resposta perdida. Escrita real somente em planilha de homologação explicitamente autorizada. Testes sintéticos não equivalem à homologação desse destino.

## 12. G11 — Calendário e agregações corretas

**GOOGLE-10, incluído.** Oferecer semana ISO, mês, trimestre e ano, com início/fim do intervalo e política explícita para períodos parciais. Preservar o fuso da origem; não converter apenas o rótulo para simular outro calendário.

- Usar dimensões nativas compatíveis ou consultar cada intervalo na origem quando a métrica exigir reavaliação. O coordenador compartilha os limites de coleta, sem disparar consultas ilimitadas por combinação.
- Usuários únicos e sessões não são somados entre páginas/recortes sobrepostos. Totais por propriedade ou período vêm de consulta apropriada à origem.
- CTR deriva de cliques/impressões; posição média usa ponderação por impressões somente em partições comparáveis e não sobrepostas. Com zero impressões, a métrica derivada fica nula com motivo; valores zero efetivamente retornados pela origem permanecem identificados como nativos.
- Propriedade, páginas e consultas GSC são universos distintos. Soma de páginas/consultas visíveis não substitui o total da propriedade. Não somar moedas distintas.
- Registrar fórmula, unidade, campos de origem e proveniência do derivado. Semana ISO inclui ano ISO; testar virada de ano e fuso com mudança de horário.
- Um pedido de 01–12/10 representa mês parcial; não ampliar silenciosamente para outubro inteiro. Dia sem linha permanece ausência/indeterminação conforme a evidência.

**Aceite T16:** valores positivos com volumes diários diferentes, usuários repetidos, páginas sobrepostas, zero denominador, mudança de ano, período parcial e comparação com agregado nativo. Receitas de coorte/retensão e aparência/tipo GSC entram em GOOGLE-05; novos atalhos GOOGLE-11 só ganham código com demanda demonstrada.

## 13. G12 — Preparação para Meta e LinkedIn; Sheets condicionado

Incluir no guia e nas fixtures de isolamento os cinco donos, prefixos propostos e capacidades opcionais. Cada provedor conserva credenciais, clientes, políticas, cotas, jobs, histórico e CSV/JSON. Google não coleta dados sociais, não usa seus tokens e não passa a hospedar relatórios/contatos desses fornecedores. Token manual dos novos provedores não altera Service Account/OAuth Google nem OAuth/CIMD do servidor MCP.

Executar S01/S06 com ausência de provedores e fixtures de suas superfícies; usar binários reais quando recebidos, identificando o alcance de cada prova. Pausa/manutenção/atualização Google não modifica tokens, jobs, recibos ou callbacks Meta/LinkedIn/Core. Não esperar os dois projetos sociais para concluir as melhorias GA4/GSC.

**GOOGLE-SOC-01 permanece fora do compromisso imediato:** `sheets-table-writer/1.0.0` só será implementado se a exportação integrada for priorizada. O desenho reservado recebe tabela pronta, schema/qualidade, consumidor, conexão Google e destino concedidos, orçamento, revisão e idempotência. Não recebe credencial social, busca dados sociais, aceita destino injetado por célula ou exporta respostas pessoais Lead Sync como padrão de relatório Ads. Reutilizar G10 e testar S07 quando essa frente for incluída. CSV/JSON dos provedores continuam independentes.

## 14. Matriz mínima e critérios de conclusão

Core de referência entregue: 1.32.0; Core 1.33.0 planeja CORE-01/02, ainda sem binário comprovado. MCP 0.21.1 é entregue; MCP 0.22.0 revisão 4 inclui ativação, distribuição e bridges, ainda planejados. Homologar capacidades novas com os produtores reais identificados por hash, sem impor esses números na instalação. A correção CIMD pertence ao MCP e sua prova ChatGPT não é teste de autenticação Google.

| ID | Cenário | Critério verificável |
|---|---|---|
| C01 | Schemas locais | Casos G01 validam; cobertura dos campos retornados e fixture negativa de tipo. |
| C02 | WordPress limpo + MCP 0.22.0 + Google 0.8.5 original | Fluxo combinado comprova a correção MCP sem modificar o Google de referência; correlacionar com B01–B03 do plano MCP. |
| C03 | WordPress limpo + Google 0.8.6 | Ativação nativa funciona sem companheiros. Executar também conjunto completo em duas ordens, com primeiros acessos HTTP/CLI. |
| C04 | WordPress limpo + MCP 0.22.0 + Google 0.8.6 | Upload combinado inicial, inativo com ZIP idêntico, consulta anterior à manutenção e repetição sem duplicação. |
| C05 | MCP 0.21.1 + Google 0.8.6 novo | Fluxo documentado em duas chamadas funciona. Registrar a limitação conhecida do combinado; não exigir que o Google a oculte. |
| C06 | Google 0.8.4 → 0.8.6 | Atualização direta autenticada preserva valores `false`, cifras, conexões/serviços, vínculos, geração de recuperação, job concluído, agenda pausada e auditoria. Sem passar pela 0.8.5. |
| C07 | Google 0.8.5 → 0.8.6 | Mesmos critérios de preservação; pacote repetido não refaz trabalho. |
| C08 | Atualização conjunta | Partindo de MCP 0.21.1 com cada base Google aceita, testar MCP→Google e Google→MCP, com nova requisição após cada troca. A ordem não vira pré-requisito de uso. |
| C09 | Falha local e observação | Indisponibilidade detectável sem reparo por leitura; cron de terceiros preservado. Testar estrutura, persistência e agendamento nos pontos alterados. |
| C10 | Contratos compartilhados | Casos G04 pelo handler real, SDK real e APIs externas simuladas; identidades/grants de laboratório explicitados. Core 1.32.0 como referência; repetição pertinente com Core 1.33.0 se recebido, mantendo resultado separado e pendente até execução. |
| C11 | Bancada e empacotamento | Entradas incorretas, relatório adulterado, bytes divergentes e caminhos inválidos recusados. Instalador coincide com o runtime testado. |
| C12 | Documentação | Guia, schemas, versões e limites concordam com pacote/ensaios. Core configuração 7.0.0 entregue e 7.1.0 proposta, Google configuração 4.0.0, SDK GSC 1.0.0 e medição 1.0.0 diferenciados; catálogo e ajuda PHP coerentes. Ads não declarado operacional sem prova específica. |
| C13 | Rastreabilidade do escopo | GOOGLE-01–11 e GOOGLE-SOC-01 classificados individualmente; opcionais/condicionados identificados; nenhum ticket de código encerrado apenas por edição documental. |
| C14 | Contrato de medição — I01/T07 | Casos G06 completos, incluindo envelope, seis slots, procedência, scope, paginação/revisão e ausência de reparo; inputs explícitos preservados; Core/Google reais e retirada dos dois acessos privados. A16–A20 Core separados da integração. |
| C15 | Distribuição — T09 | Casos G07; dono único, hooks preservados, estado desconhecido sem troca de origem e pacote local independente. |
| C16 | Bridges — T04/T14/S04; MCP C05 | Registro explícito com autorização equivalente; duplicata/conflito e declaração inválida sem fallback; base 0.8.5 e duas ordens de atualização preservadas pelo produtor; alvos sociais/Core e executores aninhados recusados. B30–B34 MCP são provas próprias do produtor. |
| C17 | Coleta — T11 | Casos G09, inclusive página cheia, filtro local sem linhas, duas contas/períodos, falha parcial, orçamento, revogação e retomada sem duplicação. |
| C18 | Qualidade — T13/T14 | Metadados nativos e limites preservados; desconhecido distinto de zero; total por recorte, duas moedas/fusos e transporte de parcialidade. |
| C19 | Exportação — T12 | Casos G10; padrão estrito, parcial explícito, destino preservado na falha de coleta, verificação com alcance declarado e append sem repetição cega. |
| C20 | Calendário — T16 | Casos G11 com métricas positivas, intervalos parciais, semana ISO e universos GSC distintos; totais nativos quando necessários. |
| C21 | Cinco provedores — S01/S06 | Isolamento por ausência/pausa/atualização e recusa de proxy social; diferenciar fixtures e candidatos reais. S07 somente se GOOGLE-SOC-01 entrar no escopo. |

Os grupos podem compartilhar uma mesma bancada, mantendo resultados identificáveis por aceite. Os testes internos MCP de interrupção, tokens, sentinela e rollback devem ser referenciados pelas evidências recebidas, sem serem contabilizados como testes Google próprios.

A implementação Google pode começar com os pacotes entregues e fixtures de contratos acordados. A falta do MCP corrigido deixa C02/C04 e a parte conjunta de C08 pendentes. A falta dos produtores CORE-01/02 e MCP-02/03 deixa pendente a homologação real de C14–C16; fixtures não certificam um produtor inexistente. Fechar essas interfaces antes de encerrar a entrega incluída. O MCP pode comprovar sua correção usando Google 0.8.5 original; os produtores podem publicar seus contratos antes do consumidor, sem dependência circular de instalação.

Meta/LinkedIn não são pré-requisitos da release Google: isolamento pode ser ensaiado com fixtures declaradas, com homologação adicional dos binários quando existirem. Não converter a indisponibilidade de um contrato em fallback privado, alteração automática de origem ou bloqueio global do plugin. Manter separadas implementação, prova de contrato, WordPress nativo e homologação remota. Uma leitura real pequena GA4/GSC e uma exportação real dependem de conta/destino autorizados; sua ausência deve constar como homologação pendente, sem afirmar paridade numérica geral.

## 15. G05 — Documentação e pacote

Atualizar `README.md`, `CHANGELOG.md`, `CONTRACTS.md`, guia corrente, `docs/VALIDACAO.md`, `docs/SDK-PHP.md`, `docs/ACOMPANHAMENTO-CRON.md`, instruções de atualização, catálogo e exemplos, além da documentação incorporada em PHP protegido.

Correções documentais confirmadas e obrigatórias nesta release:

1. Em `docs/SDK-PHP.md`, seção “Integração desta entrega”, e em `CONTRACTS.md`, corrigir Core configuração 6.6.0: **7.0.0** é o contrato entregue no Core 1.32.0; **7.1.0** é proposto para a candidata 1.33.0. Registrar o efetivamente ensaiado. Distinguir versão do plugin, configuração Core, configuração Google 4.0.0, SDK leitor GSC 1.0.0 e SDK de medição 1.0.0. Nenhum desses números vira gate de instalação.
2. Corrigir a contagem divergente em `CONTRACTS.md` usando o catálogo exportado da candidata. A referência entregue 0.8.5 tem 281 habilidades; não presumir que a próxima contagem prova descoberta ou autorização.
3. Executar `build/compile-documents.py` e os controles documentais para atualizar `includes/Data/Documentation.php`; conferir que a documentação disponível pelo plugin reflete as correções, além dos Markdown no fonte. Preservar referências históricas corretamente identificadas.
4. Separar combinações já ensaiadas, candidatas planejadas e validação remota pendente. A pendência operacional Ads do ambiente do dono não altera o contrato genérico nem deve ser apresentada como funcionalidade homologada.
5. Documentar `google/query`, `ga/*`/`gsc/*` e `google/execute-read` como superfícies complementares. Coortes já têm acesso nativo; catálogo dinâmico por propriedade não é limite universal de 387/98 campos.
6. Publicar modos de coleta, cursores e retenção, qualidade, calendário, política de exportação e comportamento de jobs existentes. Exemplos devem incluir contas parciais, qualidade desconhecida e GSC com paginação concluída/garantia de origem limitada.
7. Descrever os novos contratos públicos de Core/MCP e os cinco donos; registrar origem e alcance das evidências recebidas sem copiá-las como testes da candidata. Atualizar o contrato executável e a documentação protegida a partir das mesmas definições.

Explicar os estados separadamente: arquivos instalados, plugin ativo, inicialização local observada e acesso remoto Google validado. Documentar o caminho combinado somente para o executor efetivamente corrigido/testado; manter a orientação em duas chamadas para MCP 0.21.1. Um plugin já ativo e incompleto não é reparado simplesmente repetindo `plugins/activate`; eventual intervenção exige diagnóstico e ação explícita, sem rotina automática nova nesta release.

O instalador deve continuar contendo somente a lista permitida de runtime, documentação protegida e `index.php` silencioso em todas as pastas. Não publicar Markdown, diretórios `docs/`, `reference/`, ferramentas, testes ou `.htaccess` no ZIP de produção. O fonte mantém documentação completa, scripts Cloud Shell revisado/original como referência, testes e evidências. Os scripts não serão executados durante o build ou a instalação.

Entregáveis da implementação:

1. `wp-mcp-google-fator3-0.8.6.zip`.
2. `wp-mcp-google-fator3-src-0.8.6.zip`.
3. `guia-wp-mcp-google-fator3-0.8.6.md`.
4. `relatorio-entrega-google-0.8.6.md`, com situação C01–C21, resultado por ticket GOOGLE, combinações testadas e limites.
5. `SHA256SUMS-0.8.6.txt`, contratos/schemas efetivos e encaminhamentos ao MCP/Core com as fronteiras alteradas. Referências Meta/LinkedIn permanecem preparativos e Sheets condicionado.

A identidade de runtime e de testes deve continuar vinculada à evidência. Uma alteração posterior invalida a aprovação afetada conforme a política de build; não reutilizar silenciosamente resultados de outros bytes.

## 16. Sequência de execução e limites

1. Preparar candidata sobre a 0.8.5, capturar identidades e acordar schemas/assinaturas de CORE-01/02, MCP-02/03. Esses contratos são entregas dos produtores, sem editar seus fontes nesta frente.
2. Refatorar a bancada e completar diagnóstico. Desenvolver coleta/qualidade e calendário, que não dependem dos novos provedores ou contratos entre plugins.
3. Integrar exportação estrita à coleta; desenvolver adaptadores Core/distribuição/bridge contra fixtures acordadas e estados de ausência.
4. Validar instalação limpa e atualizações 0.8.4/0.8.5, preservação e candidatos reais das interfaces. A correção MCP continua sendo comprovada também com Google 0.8.5 original.
5. Fechar evidências por aceite/ticket, documentação gerada e controles do pacote; publicar uma única entrega com todo o escopo incluído. Ads, atalhos opcionais e Sheets social permanecem identificados como condicionados.

O plano não inclui implantação na frota, modificação dos acompanhantes, concessão automática de acesso, reparador de instalações incompletas, migração histórica, coleta social no Google, BigQuery ou nova operação Google Ads. Multisite completo, Redis/Memcached reais, CDN/hospedagem específica e crontab de servidor não são cobertos pela bancada single-site descrita. Homologação externa limitada da frente analítica tem escopo/autorizações próprios; o relatório distingue transporte HTTP local real de respostas Google simuladas e consultas remotas efetivamente realizadas.

## 17. Rastreabilidade e referências

| Insumo conferido | SHA-256 |
|---|---|
| Google 0.8.5 instalador | `acd644d1cd9d7a766c03cad9cdd3c67c44635d1b0b2b49936060a588316be96f` |
| Google 0.8.5 fonte | `ea8c0173ef7148c1ba905f0421ddc4752697a511acb532d722c09f27b64aa8b3` |
| MCP 0.21.1 instalador | `12df8115663afb1755288bb115a06efe0ff651faa84561ce95ee951249171b9c` |
| MCP 0.21.1 fonte | `c521cbcb9a39425fc7e2b685d0e77194df44baf29416282ab5cb14835e4d52a0` |
| Plano MCP 0.21.2, revisão 1 | `9bf2f1b2e789cf05c134cc3cb40052ce25d788f71db1458f65a65daaec4ec49c` |
| Relatório Google 0.8.5 | `c7d1216413fa8021dd9419d8ee8427faaf0581d2663d6ad97685f8663e9a6924` |
| Guia Google 0.8.5 | `123e761dab4c38ddc14bde1f16c7886b57549672ff3a5ba23e406efb05600320` |
| Impacto Google 0.8.5 para Core | `4802dfb9d099dadca81a0e6e4d437f5df46adbbf9907e37f371f4b8dd9e7aab0` |
| Relatório MCP 0.21.1 | `08c0708e75cbab48ad12d7c16126918318a695fefe46e54ae591fe02356f17ab` |
| Encaminhamento planejado Core 1.33.0 para MCP/Google | `5abbd4635ffcb25ebb3abb27a509ddff21b78d420bdd4c0d46f57ffc5b3d63d1` |
| Encaminhamento Google revisão 3, anexo `(1)` | `681e34543e81379ba0f3ee31ae58949abfac9cf741c10f137739bcf80bd795a6` |
| Plano integrado revisão 3, anexo `(1)` | `1ed33312a064e6c0e68e66ed05cb72044a16c45ad117d760f64f72623f031f8d` |
| Contratos sociais revisão 1, anexo `(1)` | `a69f961febd81aedb8ff167991f9e868696821f16d9e8c25599631d9ec00ad12` |
| Plano Instagram/LinkedIn revisão 3, anexo `(2)` | `22910d20f8ba3d0c080eca4470c8f0a8e8041d34b1925b2b65628ba119948d7e` |
| Encaminhamento Meta revisão 1, anexo `(1)` | `69a41ba16e0858d1cc9bc743aca9d19c88450eba8ba02b865899d5d181d9c893` |
| Encaminhamento LinkedIn revisão 1, anexo `(1)` | `0eaa8fd73528d0def13ff0568523409828f9e73742259add96cc3ae1a2d97d3a` |
| Encaminhamento MCP revisão 3, anexo `(1)` | `fdcc38076b24fc8cbb73169a9a804f01063ef2f566137db9ad20c2a6c3aff2f5` |
| Encaminhamento Core revisão 3, anexo `(1)` | `f2069c41809422bc7eba9fa0be4b84d4ac900b33df0f86943ac964e090d3e88f` |
| Impacto Core 1.33.0 revisão 2, anexo ` (1)` | `496b4392d652aae435a196939254cb5379299ee72d99a7c6b86a30fb2014a113` |
| Contratos públicos Core 1.33.0, especificação 1 | `c2d5448cce97b44c316908d7e42d5111ed5848757af495581297a6f5bc08e9a6` |

Nesta rodada foram lidos os documentos fornecidos e os pontos relevantes de ativação, diagnóstico, manutenção, testes e empacotamento dos fontes. Os arquivos compartilhados entre fonte e instalador Google conferem byte a byte. Houve análise estática e conferência documental; não houve implementação, execução de suíte funcional, acesso à produção ou chamada Google real.

Na revisão 2, foram acrescentadas correções documentais comprovadas, limites do diagnóstico Ads e ensaios complementares Core. Na revisão 3, os oito anexos foram lidos e os tickets repetidos do plano integrado conferidos contra os encaminhamentos. Novas frentes G06–G12 e aceites C13–C21 preservam os IDs anteriores. Não foram modificados fontes/pacotes, feitas chamadas aos sites, consultadas contas Google/Meta/LinkedIn ou executadas suítes funcionais nesta rodada.

Na revisão 4, foram lidos integralmente os dois novos anexos Core e consultadas as decisões e seções P07/P09/P10 do **plano MCP 0.22.0, revisão 4**, atualizado em 15/10/2026 às 17:17:15 (Brasília). O documento substitui o plano 0.21.2 para a próxima release MCP. G06/C14 incorpora a especificação do produtor; G08/C16 fica alinhado à inclusão obrigatória MCP-03. Mantidos 12 grupos e 21 aceites; apenas documentos desta frente foram atualizados. Os hashes históricos acima não são apresentados como hash do plano MCP atual. Nenhum teste funcional, implantação ou acesso aos sites foi executado nesta revisão.

Referências oficiais consultadas em 15/10/2026 para delimitar a implementação:

- [GA4 runReport v1beta](https://developers.google.com/analytics/devguides/reporting/data/v1/rest/v1beta/properties/runReport): paginação por offset e preservação da seleção nativa.
- [GA4 ResponseMetaData](https://developers.google.com/analytics/devguides/reporting/data/v1/rest/v1beta/ResponseMetaData): qualidade, fuso, moeda e metadados nativos.
- [Search Analytics query](https://developers.google.com/webmaster-tools/v1/searchanalytics/query): paginação, dias omitidos, agregação, dataState e ausência de garantia geral de todas as linhas.
- [Search Console — Getting your performance data](https://developers.google.com/webmaster-tools/v1/how-tos/all-your-data): limites da origem e estratégia de coleta dos dados disponíveis.

Defaults de produto, organização dos adaptadores, estados de continuação e critérios de release são decisões deste plano. Identificadores de contratos propostos não representam APIs já publicadas.
