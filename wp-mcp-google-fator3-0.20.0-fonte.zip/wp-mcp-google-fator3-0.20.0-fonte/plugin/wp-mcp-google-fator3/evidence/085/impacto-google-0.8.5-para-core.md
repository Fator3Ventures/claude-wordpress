# Encaminhamento ao Site Core — Google 0.8.5

15/10/2026. Core 1.32.0 e MCP 0.21.1 finais usados sem alteração dos seus fontes/instaladores. SHA-256 Google: `acd644d1cd9d7a766c03cad9cdd3c67c44635d1b0b2b49936060a588316be96f`.

**Não foi identificada adaptação funcional obrigatória no Core para consumir o Google 0.8.5.**

- SDK `search-console-reader/1.0.0`, `capabilities()`, `register_consumer()`, `effective_status()` e `query()` preservados. Registro por `f3_mcp_register_providers` e consumidor `base-site-core-fator3` mantidos.
- Consulta GSC real pelo SDK, com transporte Google simulado, comprovou conexão não padrão, concessão explícita, ausência de concessão, ambiguidade e leitura indisponível. O Core manteve seu commit e orçamento; o Google não criou passagem cron pela consulta do consumidor.
- O Google retirou somente os caminhos históricos de migração/transição e acrescentou `google/maintenance`. O Core inspecionado não consome essas rotas. Diagnóstico `local_status.transition` não é mais publicado; resolução, conexão e estados correntes permanecem. Não criar aliases nem transferir grants.
- Bridge Google recusa as três habilidades LinkedIn de escrita, inclusive em simulação. Pausa/manutenção/ativação Google preservaram rota, hooks, configuração, segredo cifrado e fila próprios do Core. Callback recebeu desafio/recibo sem usuário ou sessão MCP e sem trabalho/cron/HTTP Google.
- Mantidos os eventos `f3base_form_aberto`, `f3base_form_iniciado`, `f3base_form_recusado`, `f3base_form_enviado` e `f3base_form_fechado`, com `form_id` e `codigo` separados. Nenhuma dimensão, conversão ou emissão de tag foi criada automaticamente. Lead importado não é evento de navegador.
- Versões dos acompanhantes permanecem informativas. Capacidade ausente afeta a operação dependente, sem bloqueio da instalação Google.

Provas: `evidence/085/native-clean/core.json`, `native-repro/core.json`, `native-upgrade/core.json` e `native-clean/provider-isolation.json` no fonte Google. Esta evidência é de integração e isolamento; não substitui homologação remota LinkedIn/Google, aprovação do aplicativo ou testes de negócio Core. Nenhuma publicação em produção foi realizada.

O relatório MCP separado contém o achado de ativação silenciosa no upload inicial. Para instalar Google via MCP, usar upload inativo seguido de plugins/activate. A atualização da 0.8.4 inicializada foi aprovada.
