# Instalar Fator3 MCP Google 0.8.5

Use o ZIP instalável para substituir a 0.8.4, sem desinstalar. Também pode instalar em WordPress limpo. Não há bloqueio por versão ou presença dos acompanhantes; funções dependentes precisam das capacidades correspondentes.

No wp-admin, envie o ZIP e confirme a substituição/ativação. Preserve o backup do banco e dos arquivos. Se houver trabalho em andamento, use o procedimento de pausa e drenagem documentado no painel antes da troca. Não desinstale para atualizar: a desinstalação remove credenciais.

Pelo MCP, na instalação inicial use `plugins/upload-base64` com `activate:false`, seguido de `plugins/activate` para `wp-mcp-google-fator3/wp-mcp-google-fator3.php`. O executor de upload MCP 0.21.1 com `activate:true` suprime hooks de ativação. A atualização da 0.8.4 já inicializada foi validada com ativação no upload.

Depois da troca, em nova requisição, confira a versão, `google/storage-status` e o estado observado de cron. `google/maintenance` é a operação atual; grants de `google/migrate-storage` ou `google/complete-transition` não são convertidos. Perfis personalizados devem autorizar expressamente a nova operação quando necessário.

Service Account permanece padrão; use uma identidade ativa por conexão. Credenciais e vínculos atuais são preservados. Consulte o selftest e sua cobertura antes de considerar o acesso remoto homologado.

Guia completo, contratos e instruções estão nos downloads autenticados do painel. O fonte inclui testes, evidências, scripts Cloud Shell e instruções de reprodução; não instale o ZIP fonte no diretório público. Scripts Cloud Shell não foram executados nesta entrega.
