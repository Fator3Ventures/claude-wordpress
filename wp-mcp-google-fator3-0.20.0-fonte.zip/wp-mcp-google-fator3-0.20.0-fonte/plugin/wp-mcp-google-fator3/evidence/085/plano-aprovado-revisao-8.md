# Plano da próxima versão — Fator3 MCP Google 0.8.5

**Revisão 8 · 15/10/2026 · Planejamento Google, sem implementação ou publicação.**

Esta revisão incorpora os **pacotes finais MCP 0.21.1 e Core 1.32.0**, seus fontes e relatórios. Os hashes dos instaladores conferem com as evidências recebidas. A inspeção confirmou os SDKs utilizados pelo Google, a retirada dos filtros numéricos nos pontos de integração e a implementação do webhook LinkedIn no Core. Esses acompanhantes deixam de ser candidatos futuros na matriz Google.

**Conclusão:** não foi identificada mudança funcional obrigatória nas APIs Google causada pelos novos pacotes. Permanecem T0–T4, agora com ensaios sobre MCP 0.21.1/Core 1.32.0 e rastreamento dos aceites MCP A13/A14 pendentes do Google final. T0 inclui a retirada do aquecimento antecipado da Abilities API em `McpBridge::prepare_registry()`, condicionada à prova de registro frio REST/CLI: o MCP atual já conclui o registro público antes de compor o servidor.

O Core mantém catálogo 7.0.0, `f3_mcp_register_providers` e `ExtensionContract::register`. O MCP mantém `server-integration/1.0.0`, política 1 e `wp-mcp-ultimate-server`; o SDK GSC continua `search-console-reader/1.0.0`. Nomes correntes e validações de contrato/identidade permanecem.

Preservadas as diretrizes do dono: instalação sem bloqueios por versões dos acompanhantes; base limpa/Google 0.8.4; retirada de compatibilidade, migrações e ajustes intermediários anteriores; uma entrega completa. Os resultados recebidos validam as combinações informadas pelos responsáveis com Google 0.8.4. **Google 0.8.5 continua planejado e precisa de evidência própria sobre seu ZIP final.**

## 1. Decisão e escopo

A próxima versão candidata é **0.8.5**, com foco em simplificação do runtime, manutenção da engenharia de entrega e verificação de integração. **Não há funcionalidade pendente no documento Google recebido.** Os pedidos 1–23 permanecem encerrados; este plano não os renumera, reabre ou repete. A retirada de legado descrita em T0 é uma nova orientação direta do dono nesta conversa.

O documento de frota informa a 0.8.4 instalada nos 14 sites e registra aceites dos pedidos 22 e 23. Isso remove a motivação para uma atualização corretiva urgente desses itens. As melhorias propostas aqui nasceram da inspeção do pacote-fonte, não de um novo incidente nos sites.

**Escopo:** remover mecanismos exclusivos de versões anteriores à 0.8.4, preparar diretamente a estrutura corrente na instalação limpa, tornar a bancada reproduzível, vincular o build aos bytes testados e atualizar integração/documentação. Uma única entrega completa, sem versões intermediárias. Sem data definida.

A base de desenvolvimento é **instalação limpa ou Google 0.8.4**, com os plugins informados pelo dono. Essa referência delimita os ensaios e a manutenção; não cria trava de versão de origem no código. Não há obrigação de compatibilidade com versões anteriores, retomada de migrações históricas ou conservação de ajustes intermediários para reparar bases antigas. Esta regra substitui a exigência de preservar migrações pendentes da revisão 1.

**Instalação e ativação não serão bloqueadas pela versão do MCP, Core ou de outro plugin.** Não introduzir versão mínima, máxima ou exata dos acompanhantes em instalador, ativação, atualização ou inicialização. Também não exigir ordem de troca dos pacotes. Versões e hashes identificam os insumos testados, sem se tornarem uma lista de versões autorizadas no runtime.

Uma capacidade ausente em tempo de execução deve afetar somente a operação que depende dela, com diagnóstico específico e sem erro fatal. Essa verificação permanece distinta de bloqueio global por versão. Preservar autorização, integridade dos dados e validação das entradas.

Com T0, a entrega inclui simplificação efetiva do código instalado. A 0.8.4 continua sendo a base operacional até a próxima entrega; publicação na frota permanece decisão do dono.

## 2. Fundamentação

| Evidência consultada | Constatação | Consequência para o plano |
|---|---|---|
| `Pedidos — Fator3 MCP Google(10).md` | Nenhum pedido pendente; itens 1–23 encerrados; produção ainda tem aceites não exercitados registrados no estado da frota | Não transformar homologação pendente em funcionalidade ausente |
| Pedidos MCP de 12/10, 12:12 UTC | MCP 0.21.0 instalado; itens 1–59 encerrados | Não presumir mudança futura do canal nem criar adaptação sem contrato novo |
| MCP 0.21.1 final, fontes, relatório e `evidencias/0211/acceptance.json` | 731 verificações informadas em 24 grupos; hashes das 24 evidências conferidos; matriz Core 1.32.0/Google 0.8.4; A13/A14 não executados | Usar o instalador final na bancada Google e produzir a prova que falta para a 0.8.5; não importar contagens como resultados novos |
| Fonte Google 0.8.4, `dependencies/lab084.py` e `integration/README.md` | Bancada depende de caminhos absolutos e de instalações de outra sessão | Melhorar a reprodução dos ensaios em outro ambiente |
| Fonte Google 0.8.4, `build/build.py` e `build/release-gates.json` | O build exige indicadores booleanos, mas não vincula esses indicadores ao snapshot atual do código | Automatizar a invalidação de evidências após mudanças relevantes |
| Evidências 0.8.4 | Suíte, integração e ZIP final foram conferidos; hash final consta nos ensaios de atualização | A entrega 0.8.4 tem evidência de correspondência; a melhoria proposta reduz dependência da conferência manual nas próximas entregas |
| Core 1.31.0 e relatórios anteriores | Referência histórica dos pedidos 194–208, SDK GSC 1.0.0 e cinco eventos de formulário | Contratos reavaliados no Core 1.32.0 final; pacote anterior não é matriz adicional obrigatória |
| Core 1.32.0 final, fontes, relatório e encaminhamento de entrega | Catálogo 7.0.0, três habilidades LinkedIn de escrita e webhook implementados; L08–L13 informados como aprovados localmente; L07/L14 remotos pendentes | Atualizar contratos efetivos e ensaios de isolamento; cliente, segredos, fila, agenda e callback permanecem no Core |
| `class-f3base-companheiros.php` e `class-f3base-gsc.php` do Core 1.32.0; `UpdateChannel::offer()` do MCP 0.21.1 | Retirados filtros por versão dos acompanhantes; permanecem contrato, métodos, identidade, política e requisitos próprios de ambiente | Encaminhamento anterior atendido nesses pontos; manter verificações de capacidade e não criar trava numérica Google |
| `DefaultServerFactory::create()` e `McpAdapter::init()` do MCP 0.21.1 | O MCP conclui `wp_get_abilities()` antes de compor o servidor, com guardas de reentrância REST/CLI | Simplificar o aquecimento duplicado Google em T0 e comprovar descoberta fria em T3 |
| Orientação direta do dono, incorporada na revisão 2 | Apenas instalação limpa/Google 0.8.4; nenhuma trava por versões acompanhantes; sem legado anterior | Retirar transições históricas e inicializar diretamente o modelo corrente |

**Inferência atualizada:** além da reprodutibilidade, a base delimitada pelo dono permite eliminar ramificações históricas do runtime. Isso reduz estados e dependências internas a manter. Não exige novos serviços ou permissões Google; a manutenção corrente precisará de entrada própria quando a rota de migração for removida.

O registro dos 14 sites foi lido no documento de frota; esta sessão não acessou esses sites nem repetiu seus aceites. A pendência 20 do estado da frota é citada pelos documentos, mas seu conteúdo integral não foi fornecido nesta rodada. Não se assume uma lista de testes operacionais além do que está documentado.

## 3. Trabalho proposto

### T0 — Retirar legado e adotar a base corrente diretamente

**Prioridade alta; obrigatório por orientação do dono.**

Eliminar código que só existe para aceitar versões anteriores, converter formatos antigos, retomar transições históricas ou compensar defeitos já corrigidos antes da base 0.8.4. Não criar uma migração adicional para poder retirar as migrações antigas.

Inventário inicial confirmado no código:

| Área | Retirada planejada | Comportamento corrente a preservar |
|---|---|---|
| `Integration/Transition.php` | Recuperação da transição do importador 0.6/0.7, options/checkpoints antigos, `google/complete-transition` e interfaces associadas | SDK GSC, concessões, isolamento da conexão e configuração atual do consumidor |
| `Storage/Migration.php` e `Records.php` | Estados `legacy/drain/copy/verify`, cópia/verificação de options antigas, agendamento `f3_mcp_google_storage_step` e fallback de registros em options | Repositório indexado corrente, dados válidos da 0.8.4 e criação direta da estrutura em instalação limpa |
| `Storage/CronStore.php` e `Automation/CronHistory.php` | Importação de passagens/incidentes antigos, leitura de `legacy_last_pass`, recuperação exclusiva de projeções de versões antigas | Histórico indexado atual, origens separadas e reconciliação de falhas que ainda podem ocorrer no funcionamento corrente |
| `Storage/Maintenance.php` | Famílias `cron_legacy`, `legacy_records`, `legacy_expiry` e dependência de marcadores de verificação da antiga migração | Retenção e manutenção dos dados/cache produzidos pelo modelo atual, orçamento e resultados verificados |
| `McpBridge::prepare_registry()` e seus hooks REST/CLI | Aquecimento antecipado do registro já executado pelo MCP atual antes da composição do servidor | Registro Google nos hooks públicos da Abilities API, contribuição pelo SDK e descoberta fria nas duas ordens; preservar uso administrativo/CLI sem MCP |
| Admissão, painel, configuração e documentação | Chamadas, botões, mensagens e dependências que existem apenas para migrar/completar transições antigas | Autorização, recuperação operacional corrente, travas e erros de armazenamento específicos |
| Testes e distribuição | Cadeias de atualização anteriores à 0.8.4 e fixtures exigidas somente por caminhos retirados | Testes dos comportamentos atuais e regressões que comprovam correções definitivas |

Na instalação limpa, criar e verificar diretamente as tabelas e valores do modelo corrente. Na atualização da 0.8.4, utilizar os dados existentes sem recopiá-los por formatos históricos. Eliminar decisões de prontidão baseadas na conclusão de migrações antigas; a prontidão deve refletir a estrutura corrente e a capacidade real de acesso.

Não apagar credenciais, configurações, filas ou registros atuais durante a simplificação. Retirar leitores de dados antigos não autoriza uma limpeza indiscriminada do banco. Resíduos históricos fora do modelo suportado não precisam ser convertidos, reparados ou usados como pré-requisito para ativação.

**Manutenção pública:** retirar `google/complete-transition`; substituir `google/migrate-storage` por `google/maintenance`, executando somente manutenção corrente com autorização, guarda de recuperação, limite por passagem e resultado estruturado. Não manter alias para a rota retirada. `google/storage-status` continua como consulta da estrutura e manutenção atuais, com descrição correspondente. Atualizar os consumidores internos, CLI quando aplicável, painel, catálogo e exemplos no mesmo trabalho.

**Não eliminar correções definitivas:** o PUT vazio com `Content-Length: 0`, a gravação verificada, a distinção de reprovação no selftest, a confirmação de redução de serviços e a proteção contra corridas de cron continuam necessários. Remover mecanismos temporários usados na transição de versões não significa restaurar o comportamento defeituoso original.

As guardas de recuperação e concorrência utilizadas nas operações atuais devem ser extraídas de módulos históricos quando necessário e permanecer no fluxo corrente. Nenhuma exceção será mantida apenas para concluir uma migração anterior à base.

A retirada de `McpBridge::prepare_registry()` deve eliminar apenas os dois hooks de aquecimento e o método duplicado. Preservar `Plugin::register_category()`, `Plugin::register_abilities()`, o filtro `f3_mcp_default_server_config` e as duas bridges. Comprovar primeira chamada REST e CLI, ambas as ordens de carregamento, consulta administrativa observacional e funcionamento local com MCP ausente. Essa retirada é uma simplificação fundamentada no ciclo atual; a revisão 8 não executou o plugin sem esse método. Se um consumidor corrente demonstrar dependência, registrar a reprodução e ajustar o ponto de inicialização correspondente antes de concluir a retirada. Não acrescentar uma ramificação por número de versão.

A classificação do legado depende dos leitores e escritores atuais. O identificador `wp-mcp-ultimate-server` é utilizado pelo SDK MCP corrente e por `McpServer::accepts()` no Google; seu nome não constitui evidência de compatibilidade obsoleta. Da mesma forma, retirar um tratamento histórico de tarefa sem contexto não autoriza executar um registro inválido: permanecem validação de contexto, bloqueio por identidade/política alterada e resultado desconhecido para escrita interrompida.

A igualdade entre `meta.fator3.version` e a versão declarada pelo próprio provedor no registro MCP é uma verificação de consistência de identidade, não uma faixa de versões permitidas entre plugins. Atualizar esses valores juntos no build Google; preservar `policy_contract: 1` e o registro explícito.

A nova `google/maintenance` terá metadados e autorização próprios. Permissão para uma rota removida não será convertida automaticamente em permissão para outra. Perfis personalizados deverão autorizar explicitamente a nova operação quando necessário; nenhum alias ou ampliação silenciosa de acesso será criado.

**Aceites de T0:**

1. Instalação limpa cria o modelo corrente sem passar por fases de migração histórica.
2. Atualização da 0.8.4 mantém credenciais e dados atuais, sem conversão de versões anteriores e sem reexecutar jobs concluídos.
3. O runtime não registra nem chama rotas, hooks ou leitores exclusivos do legado retirado.
4. Alterar somente o número anunciado pelos plugins acompanhantes não provoca veto pelo código Google à instalação/ativação nem a operações com capacidades compatíveis. Verificar a decisão Google isoladamente e a convivência com os pacotes finais MCP 0.21.1/Core 1.32.0, cujos filtros de acompanhantes foram retirados conforme 4.2–4.3.
5. Na falta de uma capacidade de integração, somente a operação dependente informa indisponibilidade; o plugin continua instalado e administrável.
6. Catálogo, schemas, permissões, painel e documentação refletem as retiradas e a nova entrada de manutenção. As contagens serão recalculadas, sem manter habilidades artificiais para atingir o número antigo.
7. A matriz de atualização usa a 0.8.4; versões anteriores não entram como dependência de teste ou requisito de release.

### T1 — Tornar a bancada reproduzível

**Prioridade alta; mudança nos fontes e ferramentas de teste.**

Substituir dependências de caminhos da sessão por uma configuração explícita de laboratório. Diretórios de trabalho devem ser relativos à raiz do projeto ou informados por parâmetros. Versões, hashes dos instaladores acompanhantes, dependências, portas e comandos de inicialização devem constar em um manifesto da bancada.

O executor de testes deve:

1. Preparar uma instalação descartável a partir dos insumos declarados e conferir seus hashes.
2. Instalar o **ZIP candidato**, mantendo o código-fonte separado do runtime testado.
3. Executar a suíte e os cenários nativos, recolhendo resultados por etapa e códigos de saída.
4. Usar nomes/portas/diretórios isolados por execução e encerrar os processos que iniciou.
5. Restringir reset e limpeza aos recursos comprovadamente criados para a própria bancada. Parametrizar o ambiente não deve remover a proteção existente contra apontamento em banco/site alheio.
6. Manter chamadas externas bloqueadas nos ensaios simulados e credenciais de laboratório fora dos artefatos.

**Arquivos envolvidos:** orquestradores hoje distribuídos em `dependencies/`, `integration/README.md`, mu-plugin da bancada e testes nativos. Reaproveitar os cenários atuais da 0.8.4 e extrair utilitários compartilhados; retirar a obrigação de executar cadeias de versões anteriores. Evidências históricas podem permanecer arquivadas fora do runtime, sem dependência funcional.

**Aceite:** a partir do pacote-fonte, executar os ensaios em dois diretórios independentes sem editar caminhos no código; nenhum acesso aos diretórios da sessão 0.8.4; falha de dependência produz diagnóstico específico; reset recusa recurso que não pertence à bancada; processos concorrentes continuam isolados.

### T2 — Vincular a liberação aos bytes testados

**Prioridade alta; mudança no build.**

Substituir a aprovação baseada apenas em booleanos por um registro de validação com identidade verificável do candidato e de seus insumos. O commit é informação auxiliar; o hash deve abranger os bytes efetivos, inclusive arquivos gerados e alterações locais relevantes.

Fluxo proposto:

1. Validar e gerar catálogo, schemas e documentos a partir do snapshot candidato.
2. Montar um candidato determinístico e registrar o SHA-256 do ZIP, o inventário do runtime e os hashes do código/testes/ferramentas utilizados.
3. Executar os testes sobre esse candidato e produzir resultados estruturados por verificação, com sucesso/falha/não executado.
4. Liberar a distribuição somente quando as verificações obrigatórias estiverem aprovadas e corresponderem ao mesmo candidato e aos insumos vigentes.
5. Promover os bytes já testados; se houver reconstrução, exigir igualdade de hash antes de liberar.

O registro de validação fica fora do runtime e não pode incluir seu próprio hash no cálculo de identidade. O ZIP fonte também não recebe um hash autorreferente. Mudança em runtime, gerador, teste ou configuração da bancada invalida as evidências afetadas. Alterações apenas em texto do relatório não exigem repetir testes funcionais, mas exigem atualizar o pacote-fonte e seus hashes.

**Arquivos envolvidos:** `build/build.py`, `build/release-gates.json` ou seu substituto versionado, geradores existentes e coletor de evidências. A allowlist de produção continua sendo a origem do inventário; novas ferramentas de teste não entram no instalador.

**Aceite:** o build recusa evidência ausente, incompleta, de outro candidato ou com insumos modificados; editar um arquivo runtime depois da validação bloqueia a promoção; o caminho aprovado entrega exatamente o ZIP testado. Um candidato de desenvolvimento não pode ser apresentado como release aprovada apenas pela troca de nome.

O registro é controle contra erros e evidências desatualizadas. Não se apresenta um arquivo local como proteção criptográfica contra um agente com poder para modificar o próprio código e as evidências.

### T3 — Verificar contratos e convivência

**Prioridade média; ensaios sobre código final disponível.**

Matriz principal: WordPress limpo ou **Google 0.8.4 como origem**, candidato Google 0.8.5, **MCP 0.21.1 e Core 1.32.0 finais**. Os respectivos instaladores recebidos e hashes constam em 8. Os pacotes MCP 0.21.0/Core 1.31.0 permanecem somente como referências históricas das análises e das evidências dos responsáveis; não são uma matriz adicional obrigatória para esta entrega Google.

O relatório MCP já registra testes com Core 1.32.0/Google 0.8.4. O relatório Core, produzido antes, usa MCP 0.21.0/Google 0.8.4. A diferença é cronológica: a evidência MCP posterior não transforma retroativamente a suíte Core em ensaio com MCP 0.21.1. Nenhuma dessas provas substitui os testes após T0 no Google 0.8.5.

Registrar versão e hash para reprodutibilidade. Essa matriz não limita instalação/ativação nem exige ordem de atualização. Testar também ausência/inatividade dos acompanhantes e alteração somente dos números anunciados, sem confundir isso com suporte a implementações antigas. O uso de uma integração depende das capacidades atuais exigidas pela operação.

Referências atuais para avaliar o impacto, sem obrigação de manter interfaces exclusivamente históricas:

| Contrato/comportamento | Referência |
|---|---|
| Configuração Google | 4.0.0, prévia/mescla/confirmação de redução |
| Diagnóstico da agenda | `cron.scheduling` 2.0.0 |
| Execução e catálogo | 2.0.0 |
| Leitor PHP GSC | `search-console-reader/1.0.0` |
| Integração do canal | `server-integration/1.0.0`, política 1 |
| Identidade do servidor MCP | `provider: wp-mcp-fator3`, `server_id: wp-mcp-ultimate-server`; nomes em uso no contrato atual |
| Marcador MCP | `mcp-cron-marker/2`; `current_state` separado de `last_operation.status` |
| Catálogo Core implementado | 7.0.0 na 1.32.0; perfil `piso-padrao-3.5`; retirada de `f3base/config-procedencia-reparar`, diagnóstico por capacidades e três habilidades LinkedIn de escrita. Descobrir schemas, sem fixar contagem |
| Catálogo/opções | 282 habilidades, 34 opções, como referência atual |
| Autenticação | Service Account padrão; métodos separados; uma identidade ativa por conexão |

A validação automatizada deve comparar os contratos com a base e tornar toda diferença explícita, incluindo as retiradas de T0. Não preservar rotas, campos ou contagens para compatibilidade com pacotes anteriores. Atualizar a versão de contratos quando a mudança romper o consumo publicado, mantendo o funcionamento das capacidades utilizadas pelos plugins informados. Versão de contrato descreve a interface da operação; não se transforma em bloqueio de instalação do plugin.

O Core 1.32.0 consome `capabilities()`, `register_consumer()`, `effective_status()` e `query()`. Seu diagnóstico utiliza `resolution`, `connection_id` e `local_status`. A inspeção dirigida e o encaminhamento não identificam consumo Core de `google/complete-transition`, `google/migrate-storage` ou `google/maintenance`. O diagnóstico malformado fica `unreadable`, sem fallback para a conexão corrente; a consulta continua reavaliando seus próprios controles. Retirar o legado interno não exige alterar o contrato SDK GSC 1.0.0 utilizado pelo consumidor atual; manter suas operações e semântica, eliminando dependências de prontidão histórica no provedor.

**Aceites de T3:**

1. Com Core 1.32.0 e MCP 0.21.1, a ponte mantém a autorização do alvo e o SDK registra o consumidor após T0, tanto em instalação limpa quanto em atualização da 0.8.4. Comprovar primeira chamada REST/CLI e ordens MCP→Core→Google e Google→Core→MCP após retirar o aquecimento Google; sem servidor parcial, inicialização recursiva ou registro duplicado.
2. Concessão em conexão não padrão, diagnóstico efetivo e consulta GSC usam a mesma conexão autorizada; ausência, ambiguidade e falha de leitura continuam distinguíveis.
3. Acrescentar GTM por mescla preserva GSC; redução sem confirmação não grava vínculos. O Core não configura Google nem concede acesso a si próprio.
4. Pausa, retomada, recuperação, cotas, cursores e eventos permanecem independentes entre provedores. A remoção dos hooks históricos Google não afeta os eventos atuais Core.
5. Os exemplos de integração usam os eventos e parâmetros documentados em 4.1; não acrescentam emissão duplicada, configuração automática de conversão nem valores preenchidos pelo visitante.
6. O Google não aplica filtro numérico à versão dos acompanhantes. Ausência ou contrato/capacidade incompatível degrada apenas a operação dependente. A variação de metadados usa cópias descartáveis; não alterar versões em produção nem eliminar a consistência entre registro e metadados do próprio provedor.
7. O percurso real `ToolsHandler` → bridge Google → habilidade final preserva os parâmetros e os resultados de configuração 4.0.0. Testar mescla, substituição, omissão, mapa vazio e rejeição de `null`; redução de nível, confirmação obsoleta e recusa sem gravação. A simulação continua exigindo autorização de escrita.
8. Com identidades e perfis explícitos correntes do MCP 0.21.1, preservar permissão da bridge e do alvo separadamente. Revalidar perfis de leitura/personalizados, token válido, revogação, expiração e confirmação vinculada à identidade. A limpeza MCP não altera segredos/conexões Google; a integração PHP Core → Google continua independente de sessão MCP.
9. Instalar e atualizar Google pelo MCP HTTP com ZIP e hash finais, fazer nova requisição após a troca e conferir credenciais, vínculos e seleção. Com os acompanhantes finais disponíveis, exercitar Google antes e depois da ativação MCP/Core em instalações descartáveis, além da atualização Google 0.8.4 → 0.8.5 com ambos ativos. As trocas MCP/Core de versões anteriores já têm evidências próprias recebidas e não viram cadeia obrigatória do laboratório Google. Preservar a pré-imagem Google e conferir sua prontidão no rollback `dry_run`; essa prova cobre arquivos, sem prometer reversão do banco ou das APIs Google.
10. O catálogo real passa a expor `google/maintenance` e deixa de expor as rotas removidas em T0. Uma autorização personalizada para a rota antiga não libera a nova. Status e manutenção afetam somente os eventos do próprio provedor; saúde, trabalho, erros atuais e histórico continuam em seus campos reais.

11. Com Core 1.32.0 final, verificar o registro pelo hook `f3_mcp_register_providers`, o consumidor `base-site-core-fator3` e o SDK GSC 1.0.0 com e sem concessão, inclusive em conexão não padrão. Conferir a retirada da habilidade histórica Core e dos requisitos numéricos do seu diagnóstico. A descoberta aceita o catálogo efetivo sem condicionar o Google à versão 7.0.0 nem criar aliases ou transportar grants de nomes removidos.

12. Com o Core 1.32.0 final, conferir a separação de provedores diante das novas habilidades e agendas: a bridge Google recusa habilidades `f3base/*`; ativação/manutenção Google preserva hooks e estado de LinkedIn/Pipedrive; nenhuma configuração Google importa seus segredos ou cotas. Cobrir essas fronteiras nos cenários de isolamento existentes, sem duplicar os testes de negócio do Core.

13. Com Core 1.32.0 final e seu webhook, verificar que ativação, pausa e manutenção Google preservam sua rota, configuração e fila. Nos percursos de callback Core usados pela bancada, o Google não impõe credencial MCP, cria identidade de agente ou passagem cron Google, recebe segredos LinkedIn nem dispara efeitos Google. As três habilidades LinkedIn — `acesso-verificar`, `consultar` e `webhook-configurar` — permanecem fora das bridges Google. São escritas no catálogo Core inclusive em simulação; `idempotency_key` MCP não preenche `revisao` ou `chave_operacao` nativos. Reutilizar os cenários Core para a prova de convivência; assinatura, desafio, cadastro remoto e deduplicação são validados na suíte Core.

**Rastreabilidade MCP A13/A14:** os aceites recebidos continuam não executados até existir o ZIP final Google 0.8.5. Vincular a evidência nova à descoberta/autorização de `google/maintenance`, ausência das rotas retiradas e instalação/atualização HTTP, com hashes, preservação e resultado após nova requisição. Registrar as ordens efetivamente ensaiadas; nenhuma condição exige publicar um acompanhante novamente. O relatório Google final permitirá ao responsável MCP completar sua matriz sem editar sua evidência histórica.

Reutilizar os cenários 0.8.4 e os testes de integração reais recebidos, parametrizados na bancada T1, acrescentando testes apenas para essas diferenças concretas. O fallback de marcadores do MCP, encerrado na 0.21.0 segundo os documentos, não será reaberto sem nova falha reproduzida.

### T4 — Documentação e fechamento

**Obrigatório para a entrega.**

- Atualizar guia, contratos, changelog, instruções da bancada e matriz de integração.
- Documentar Core 1.32.0/catálogo 7.0.0 e MCP 0.21.1 como pacotes implementados recebidos. Registrar a retirada confirmada dos filtros numéricos nos pontos inspecionados, a nomenclatura correta do hook e o SDK GSC 1.0.0 preservado. Distinguir código inspecionado, ensaios informados pelos responsáveis e execução própria Google.
- Usar a documentação MCP 0.21.1 final para os exemplos de configuração 4.0.0, estrutura real de cron e mudanças de catálogo Google. Informar a conclusão dos aceites A13/A14 somente com prova sobre o Google final. Manter os relatórios anteriores como evidência histórica, com suas limitações originais.
- Incorporar as fronteiras documentadas em 4.4: diagnósticos Core parciais não comprovam acesso, leads importados não são eventos de navegador, limites/cotas são do respectivo provedor e IDs de frota são exemplos. Registrar o webhook implementado no Core, com ativação explícita, callback própria e homologação remota pendente. Usar os nomes e campos do catálogo final; não copiar regras Core para o Google.
- Retirar instruções de migração, requisitos por versão de outros plugins e procedimentos intermediários que deixarem de existir; substituir por instalação limpa, atualização da 0.8.4 e operação corrente.
- Separar evidência local simulada, integração nativa e aceite de produção informado pela frota, indicando origem e data.
- Regenerar os documentos protegidos do painel a partir das mesmas fontes que acompanham o ZIP fonte.
- Manter scripts Cloud Shell revisado/original conforme a distribuição atual, sem executá-los.
- Conferir inventário, índice silencioso em todas as pastas e ausência de Markdown, `docs/`, `reference/`, ferramentas e `.htaccess` no instalador.
- Entregar hashes e relatórios de impacto para MCP/Core quando houver alteração que seus responsáveis precisem adotar.

## 4. Impacto dos pedidos dos outros plugins

| Pedido externo | Avaliação para o Google | Tratamento |
|---|---|---|
| Core 199 — funil de formulário, inclusive GA4 | O pacote final define cinco eventos e os parâmetros separados `form_id` e `codigo`; detalhes em 4.1 | Atualizar exemplos e referências. Nenhuma nova rota ou perfil automático Google é exigido pelo contrato recebido |
| Core 195/196 — documentação e referências | Melhoram a descrição das configurações e dados do consumidor | Atualizar referências no ensaio/documentação, preservando o vínculo pelo Measurement ID e o SDK; nenhuma alteração funcional presumida |
| Core 197/200 — contexto de teste do navegador | Relatório orienta cookie via `/f3base-teste/` ou cabeçalho `X-F3Base-Teste: 1` em todas as requisições do ensaio ao próprio site | Registrar o procedimento nos ensaios de navegador que o utilizarem. Manter a semântica de `contexto_teste` Google: não concede acesso nem neutraliza efeitos de chamadas à API |
| Core 207 — atraso frente à cadência real do executor | Alerta de captação Meta passa a considerar a cadência CLI observada, segundo o relatório Core | Preservar o diagnóstico e agendamento Google existentes. Frequência observada não comprova configuração de crontab; não copiar automaticamente a fórmula de alerta Core |
| Demais pedidos Core 194–208 | Slack, Clarity, atribuição, Meta e Pipedrive pertencem ao Core | Nenhum trabalho funcional transferido ao Google |
| Core 1.32.0 — simplificação e pedido 194 | Retirada de filtros numéricos e habilidade histórica confirmada; catálogo 7.0.0; correções Slack entregues | Usar pacote final nos ensaios Google. Nenhum cliente Slack, credencial ou rota Google adicional |
| Core 209–214(a–e) — pedidos de 15/10 | Diagnósticos Pipedrive/editorial, textos de formulário, atribuição, consulta periódica e webhook LinkedIn no Core | Considerar os novos schemas, callback e isolamento conforme 4.4; sem ampliação funcional Google |
| MCP 0.21.1 — entrega de manutenção | Retirada de legado e trava `requires.plugins`; SDK 1.0.0/política 1 preservados; A13/A14 aguardam Google final | Usar MCP 0.21.1 final e produzir evidências Google de catálogo/autorização/atualização; sem alias ou ampliação de grants |

### 4.1. Contrato de eventos preservado no Core 1.32.0

| Evento GA4 | Significado no fluxo Core |
|---|---|
| `f3base_form_aberto` | Formulário visto/aberto, uma vez por instância |
| `f3base_form_iniciado` | Primeiro campo elegível preenchido, excluindo honeypot |
| `f3base_form_recusado` | Envio recusado, com código fechado |
| `f3base_form_enviado` | Envio aceito após resposta do servidor |
| `f3base_form_fechado` | Fechamento observado sem aceite; não prova abandono definitivo |

O catálogo `dados/eventos-comportamento.tsv` declara `form_id,codigo`. O emissor em `assets/f3base-tracking.js` os envia como parâmetros separados; `codigo` pode estar vazio. A representação interna de detalhe `id:codigo` não é um único parâmetro GA4. Não transportar conteúdo dos campos preenchidos pelo visitante. `generate_lead` permanece uma conversão distinta; não duplicar emissão nem promover automaticamente todos os eventos a conversões.

O Google continua genérico. Perfis de dimensões/métricas permanecem dados configuráveis. Se houver uma demanda de relatório por esses parâmetros, verificar o cadastro da propriedade e usar os recursos existentes; o recebimento deste contrato não autoriza criar dimensões, alterar a propriedade nem instalar um perfil obrigatório Core.

### 4.2. Filtros numéricos retirados no Core 1.32.0

O encaminhamento anterior foi atendido nos pontos inspecionados. `F3Base_Companheiros` anuncia `regra: contrato_e_capacidades`; a versão observada é informativa. A decisão MCP exige `server-integration/1.0.0`, política 1, provider `wp-mcp-fator3`, server `wp-mcp-ultimate-server` e `ExtensionContract::register` chamável. O filtro de versão estável/mínima existente no Core 1.31.0 foi retirado.

`F3Base_Gsc::descobrir()` valida `search-console-reader/1.0.0`, a capacidade `gsc.page-day.read`, os métodos declarados e efetivamente chamáveis `query`/`effective_status`, além do registro do consumidor. O consumidor continua `base-site-core-fator3`. Resposta inválida em `effective_status()` gera estado local `unreadable`, sem escolher outra conexão nem conceder acesso; `query()` reavalia autorização e acesso remoto por seu próprio percurso.

O bootstrap confirma `f3_mcp_register_providers` e `ExtensionContract::register`. A correção do encaminhamento antigo, que citava `f3_mcp_register_extensions`, permanece registrada no histórico. Nenhuma nova correção foi solicitada ao Core nesta revisão.

O catálogo Core 7.0.0 retira `f3base/config-procedencia-reparar`. A busca dirigida não encontrou consumidor dessa habilidade no runtime Google nem chamadas Core às três rotas Google `complete-transition`, `migrate-storage` e `maintenance`. A descoberta deve refletir o catálogo efetivo, sem alias, contagem fixa ou concessão por equivalência de nomes. A versão de catálogo 7.0.0 não substitui a versão dos SDKs.

**Inferência:** a limpeza Google prevista em T0 pode preservar o SDK GSC atual sem acrescentar adaptação Core. A inspeção confirma as interfaces e o relatório recebido informa a integração com Google 0.8.4. A prova após retirar dependências históricas Google será produzida em T3 com o candidato 0.8.5.

Os cinco eventos web, `form_id` e `codigo` permanecem no catálogo Core final. Slack, tags, consentimento, instrumentação do navegador, funil e persistência Core continuam sob sua responsabilidade. Nenhuma dimensão, conversão ou configuração externa Google será criada automaticamente por causa desta entrega.

### 4.3. Coordenação com o MCP 0.21.1 implementado

| Ponto conferido | Situação e decisão para Google 0.8.5 |
|---|---|
| Configuração Google | `tools/release0211/contracts.php` e `service-semantics.php` executam o callback real 0.8.4 pelo transporte; cobrem mapa `services`, omissão, vazio, `null`, mescla, redução e conflito de hash. As fixtures provisórias apontadas na revisão 4 deixam de ser a referência da entrega atual |
| Confirmação de configuração | Preservar `confirm_service_reduction`, `expected_revision` e `expected_plan_hash`. A chave de idempotência MCP não preenche confirmação local Google nem substitui as confirmações remotas de `google/prepare-operation` |
| Cron e isolamento | Evidências recebidas usam Google 0.8.4 e preservam agendas/recuperação dos três provedores. Em T3, repetir os cenários afetados por T0 com `cron.health`, `cron.work_health`, `cron.scheduling.checks.executor`, observações e erros reais, incluindo `inactive` |
| Autorização | Políticas correntes explícitas, bridge e alvo continuam separados. Conexão ativa ou perfil desconhecido não gera concessão automática. A nova `google/maintenance` necessita de metadados e permissão próprios |
| Canal de atualização | `UpdateChannel::offer()` já não filtra `requires.plugins`; preserva requisitos próprios WordPress/PHP, identidade, HTTPS e hash. A distribuição Google continua por ZIP, sem feed novo |
| Inicialização do servidor | `DefaultServerFactory::create()` chama `wp_get_abilities()` antes de compor contribuições; `McpAdapter::init()` protege reentrância e não conclui inicialização em falha. T0 retira o aquecimento duplicado Google com os aceites frios de T3; manter hooks públicos de registro e contribuição |
| Identidade do servidor | SDK `server-integration/1.0.0`, política 1, provider `wp-mcp-fator3`, server `wp-mcp-ultimate-server`, rota `/mcp/wp-mcp-fator3` e alias `/mcp/wp-mcp-ultimate` preservados. `McpServer::accepts()` continua coerente; não renomear por inferência baseada em `ultimate` |
| Retiradas de catálogo | MCP retirou `backups/legacy-status` e `backups/legacy-retire`; Google não tem chamadas fixas a essas rotas nos includes examinados. A documentação MCP já descreve a retirada futura de `google/complete-transition`/`google/migrate-storage` e a nova manutenção, sem registrar rotas fictícias |
| Evidência pendente | A13/A14 permanecem `not_executed` por ausência do Google final na entrega MCP. Produzir prova com o ZIP Google 0.8.5; não exigir nova release MCP nem atribuir seus 731 checks ao Google |

**Inferência:** o transporte preserva os contratos necessários ao Google atual. A simplificação de inicialização é uma melhoria de código Google a comprovar; não há nova API de integração necessária identificada. A suíte MCP recebida distingue callbacks reais de fixtures de resultados parciais/editoriais e de recibo LinkedIn incerto; essas fixtures provam transporte, não regras remotas dos provedores.

Cada plugin mantém suas credenciais, cotas, contexto de execução e guardas. A integração PHP Core → Google continua independente de sessão MCP. A validação de igualdade entre versão do próprio provedor e seus metadados permanece; não é um filtro de versões entre acompanhantes.

O relato anterior `package_baseline_failed` não identificava a causa da sonda. A entrega MCP agora informa ensaios HTTP aprovados, com hashes e nova requisição após troca. Não há falha atual reproduzida que justifique retentativa automática ou relaxamento de sonda no Google. Se o incidente reaparecer em T3, registrar `probe_before`, resultado e identidade do candidato antes de atribuir a causa.

Ao fechar Google 0.8.5, complementar o encaminhamento já existente com hashes, nomes retirados, autorização da manutenção e resultados efetivos. Não editar código, plano ou evidência de entrega MCP nesta tarefa.

### 4.4. Novos impactos Core recebidos em 15/10

As mudanças abaixo constam da entrega Core 1.32.0 recebida. Foram conferidos os pontos de integração, o registro das habilidades LinkedIn, a callback e o emissor de aviso operacional. Regras de negócio e provas remotas permanecem com os limites declarados pelo responsável Core.

| Contrato/área Core | Mudança informada | Consequência para o plano Google |
|---|---|---|
| `f3base/integracoes-ler` e Pipedrive | Consumo separado entre entregas, qualidade e verificação; pausa local/remota e atualidade. Cota local de qualidade padrão 600, com reserva de entregas preservada, inclusive 10000 explícitos | Não transferir essas cotas para APIs ou filas Google. Diagnósticos e configurações continuam no Core; sem consumo automático desses campos pelo Google |
| Formulários | `mensagens.baixar_conteudo`; ausência/vazio preserva “Baixar conteúdo” | Mudança de interface Core. Mantidos os cinco eventos web e os parâmetros `form_id`/`codigo`; nenhuma configuração GA4 derivada desse texto |
| Atribuição comercial e LinkedIn web | Regra/proveniência da sessão paga na captura, primeiro toque preservado; detecção por `li_fat_id` e UTMs pagas | Não alterar modelos de atribuição, relatórios Google ou conversões por causa da regra de apresentação Core |
| `f3base/medicao-editorial` | Recusas com fonte, medida e limite, documentação por visão e verificações locais informadas de consultas de 7/28 dias | Preservar a distinção entre recusa, dado parcial e sucesso nos exemplos de agentes. A causa exata da recusa de produção não foi medida; não atribuí-la ao Google nem elevar limites Google por inferência |
| `f3base_anuncios_linkedin` | Conta, formulários, mapeamentos, `webhook.ativo`, coleta SPONSORED, recepção imediata e reconciliação; método `anuncio_linkedin` | Cliente, segredos, fila, agenda, cursores e orçamento próprios do Core. A instalação/manutenção Google não os altera |
| `f3base/anuncios-linkedin-acesso-verificar` | Verificação administrativa por token, escopo, conta, página e formulário, com resultado parcial, sem ler leads; classificada como escrita, inclusive em simulação | Descoberta e autorização pertencem ao Core/MCP. Não executar pela bridge Google, receber seus segredos ou interpretar resultado parcial como acesso comprovado |
| `f3base/anuncios-linkedin-consultar` | Simulação por padrão; `simular:false` pode importar contatos. Escrita no catálogo em ambos os casos | Não tratar o verbo “consultar” como autorização de leitura; preservar classificação, grants explícitos e separação das bridges |
| `f3base/anuncios-linkedin-webhook-configurar` | `acao`, `simular`, `revisao` e `chave_operacao`; escrita e autorização administrativa também em simulação; sem segredos nos argumentos | A decoração MCP `idempotency_key` não substitui revisão/chave nativas. Nenhuma concessão automática, tradução para operação Google ou execução pelas bridges Google |
| `GET/POST /wp-json/f3base/v1/anuncios/linkedin/notificacoes` | Callback Core: GET responde desafio com HMAC; POST verifica assinatura/corpo e persiste recibo antes do aceite. HTTPS e contexto próprio; sem login/cookie MCP | Preservar a rota e a separação de autenticação. A callback não concede capacidade administrativa nem cria sessão MCP ou passagem cron Google |
| Avisos JSON Core | Novo schema `f3base.operacao.v1`, tipo `pipedrive_orcamento`, no destino já configurado e com HMAC próprio | Impacto nos receptores JSON existentes: distinguir ocorrência operacional de lead e ignorar schemas não tratados. O Google não consome esse destino nem recebe uma nova integração |
| Saúde e `f3base/integracoes-ler` | Assinaturas por formulário, desafio respondido, cadastro e recebimento comprovados, fila e reconciliação; leitura não repara | Manter distintos disponibilidade da rota, desafio, assinatura e processamento. Resultado parcial ou simples presença do endpoint não comprova recepção operacional |

**Inferência de impacto:** as mudanças mantêm os SDKs utilizados pelo Google e ampliam o domínio do Core. A inspeção dirigida confirmou que `McpBridge::dispatch()` exige categoria Google e que `CoreBinding` lê os slots GA4/GTM. `OAuthFlow::register_route()` registra a callback OAuth própria; a busca nos includes Google não encontrou filtros globais de autenticação REST. Não foi identificada nova adaptação funcional nesses pontos; o pacote Core final já permite executar os ensaios de convivência com o Google candidato. A revisão 8 não reexecutou essa integração.

Os tokens e Client Secret LinkedIn permanecem sob gestão do Core. A Service Account e demais credenciais Google continuam separadas. O Google não recebe novas permissões LinkedIn/Pipedrive nem concede automaticamente acesso a habilidades Core descobertas.

A importação de leads LinkedIn não deverá fabricar sessão de navegador, os eventos web de formulário ou conversão de tag GA4. Qualquer exportação/conversão externa futura exige demanda e configuração próprias. IDs de canal/parceiro citados na frota permanecem exemplos configuráveis, sem constantes específicas de cliente no plugin.

**Webhook implementado na Core 1.32.0:** a entrega mantém instalação/atualização sem ativação ou cadastro automático de assinaturas. O cadastro ocorre mediante ação administrativa “Ativar recebimento imediato”. Consulta periódica permanece como recuperação e compartilha com o webhook a identidade de submissão e a deduplicação. A implementação desse fluxo pertence ao Core; o Google mantém sua entrega única e seus contratos atuais.

Segundo o encaminhamento, aprovação Lead Sync, credenciais de conta/página, Client Secret e HTTPS acessível condicionam a homologação remota LinkedIn. Esses requisitos não são condições de instalação Google nem bloqueiam sua release. O Client Secret fica sob gestão Core; nenhum argumento da nova habilidade administrativa deve transportá-lo para o Google. A documentação Core mantém a consulta periódica com token aprovado disponível sem Client Secret; isso não representa validação da conta real.

A entrega Core informa L08–L13 aprovados localmente, inclusive HTTP WordPress com HTTPS simulado no roteador. L07/L14 permanecem pendentes de homologação remota. O recebimento do pacote comprova disponibilidade do código; não comprova funcionamento com credenciais e infraestrutura reais. O relatório Google registrará somente os ensaios de convivência efetivamente executados, preservando a distinção entre desafio respondido, notificação autenticada, assinatura cadastrada e lead processado.

O plano Google recebe somente os aceites de fronteira e a documentação correspondente. Suítes de captação/webhook LinkedIn, qualidade Pipedrive, texto de formulário e relatório editorial permanecem responsabilidade Core. O Google não cadastra assinaturas, recebe notificações LinkedIn ou altera audiência por esse fluxo. Não há nova alteração funcional a solicitar aos companheiros além da coordenação já registrada. O encaminhamento Core aos receptores JSON é responsabilidade de seus mantenedores; não foi enviado por esta tarefa.

## 5. Verificação e critérios de saída

| Grupo | Critério |
|---|---|
| Ferramentas | Bancada reproduzível e limpeza isolada; build recusa evidência de bytes diferentes |
| Instalação | WordPress limpo e atualização da 0.8.4; nenhuma trava por versão dos plugins acompanhantes ou ordem de troca |
| Legado | Retirada comprovada de transições, fallbacks e ajustes intermediários anteriores; modelo corrente inicializado diretamente |
| Preservação | Credenciais, seleção, vínculos, política, concessões, filas e recuperação preservados |
| Regressões sensíveis | PUT vazio, gravação verificada, selftest, confirmação de redução, cron e geração obsoleta continuam cobertos |
| Integração | MCP 0.21.1/Core 1.32.0 finais com hashes, candidato Google próprio; SDK GSC, autorização e isolamento preservados; descoberta fria após simplificação; evidência Google que permita completar A13/A14 |
| Documentação | Exemplos válidos, links íntegros, download autenticado e texto coerente com o contrato |
| Artefatos | Instalador por allowlist; fontes/evidências separados; mesmo hash entre candidato testado e entrega |

A suíte da 0.8.4 — 1.113 testes, 12.636 asserções e 456 verificações nativas — é a referência histórica. A próxima entrega registra seus próprios resultados; essas contagens não são uma meta nem substituem cobertura dos riscos alterados.

O relatório Core 1.31.0 informa 546 asserções, lint de 197 arquivos PHP e ensaios com WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46 e Chromium 138, com APIs externas simuladas. Esses resultados pertencem à entrega Core e não foram repetidos nesta revisão. A presente análise conferiu código, documentos e integridade do ZIP recebido; não representa homologação do candidato Google 0.8.5 nem de contas Google reais.

O relatório MCP 0.21.0 informa 360 verificações funcionais, 84 documentais, 14 do pacote e lint de 444 arquivos PHP. Sua execução usou Google 0.8.3 real e fixtures do plano 0.8.4, além de Core 1.30.0. A integração com Google 0.8.4 final está descrita nas evidências recebidas da entrega Google; não será atribuída retroativamente à suíte MCP. A revisão 4 leu os insumos e inspecionou código, sem reexecutar essas suítes ou homologar MCP 0.21.1.

O encaminhamento planejado Core 1.32.0 recebido na revisão 5 relata reprodução isolada em PHP da recusa de versão com sufixo e de falhas Slack, com transporte simulado. São resultados informados pelo responsável Core, não executados nesta revisão. A revisão 5 conferiu o documento, o hook no código Core 1.31.0 e as referências relevantes no Google; nenhum runtime foi modificado ou candidato homologado. O documento Core cita MCP 0.21.1 revisão 3; a leitura independente do plano MCP registrada na revisão 4 deste plano foi da revisão 2.

A revisão 6 comparou as duas versões do encaminhamento Core e inspecionou os pontos Google de bridge/vínculo, sem executar suítes ou APIs externas. Os detalhes LinkedIn/Pipedrive em 4.4 são requisitos informados pelo responsável Core; não constituem validação independente dessas APIs. O documento de 15/10 ainda referencia Google revisão 4; este plano incorporou os retornos nas revisões 5 e 6 sem pressupor que essas revisões já foram ensaiadas pelo Core.

A revisão 7 comparou o encaminhamento Core revisão 3 à revisão 2 e atualizou o escopo de 214(e), com inspeção dirigida dos hooks REST Google. Naquele momento, ainda não haviam sido recebidos os pacotes finais. Essa condição foi superada pela revisão 8 abaixo; a revisão 7 não executou testes ou efeitos remotos.

**Conferência da revisão 8:**

- Os quatro ZIPs recebidos passaram na verificação de integridade; SHA-256 dos dois instaladores coincide com os relatórios. Os 330 arquivos do instalador Core coincidem com seus fontes. No MCP, os 396 arquivos existentes nos fontes coincidem com o instalador; os 55 `index.php` adicionais correspondem aos índices gerados pelo build.
- Conferidos os hashes das 24 evidências relacionadas em `evidencias/0211/acceptance.json`, sem divergência. O manifesto informa 731 verificações e zero falhas; as contagens dos grupos somam 731. Isto é verificação dos registros recebidos, não reexecução da suíte.
- A entrega MCP informa lint de 443 PHP, ensaios HTTP e matriz MCP 0.21.1/Core 1.32.0/Google 0.8.4. A entrega Core informa 26 grupos PHP, 201 arquivos no lint e matriz Core 1.32.0/MCP 0.21.0/Google 0.8.4. Seus testes externos foram simulados ou bloqueados; não se somam as contagens entre plugins.
- A13/A14 MCP seguem não executados. L07/L14 Core seguem homologação remota pendente. O código foi inspecionado, mas não houve mudança de runtime, nova execução das suítes, instalação em site, ativação LinkedIn ou chamada a API Google nesta revisão.

Redis/Memcached reais, multisite e APIs Google reais entram na matriz quando o ambiente-alvo ou uma mudança concreta exigir esses cenários. A ausência dessas homologações permanece explícita; ela não constitui, sozinha, pedido funcional pendente. Aceites de frota continuam no acompanhamento operacional e não autorizam intervenções nos sites durante o planejamento.

## 6. Sequência de execução

1. **Fixar a base:** registrar fonte/instalador 0.8.4 e os pacotes acompanhantes informados, sem transformá-los em restrição de instalação.
2. **Executar T0:** retirar os caminhos históricos, inicializar diretamente o modelo corrente e conferir preservação da base 0.8.4.
3. **Executar T1:** disponibilizar bancada configurável e validar em diretórios independentes.
4. **Executar T2:** gerar identidade do candidato, associar evidências e implementar a recusa por divergência de bytes no processo de release.
5. **Executar T3:** validar o candidato com MCP 0.21.1/Core 1.32.0, descoberta fria sem aquecimento duplicado, diferenças de T0, instalação/atualização e independência de números de versão dos acompanhantes. Vincular o resultado aos aceites A13/A14 recebidos.
6. **Executar T4 e fechar:** documentação, evidências, artefatos e relatórios em uma entrega. Qualquer defeito novo confirmado recebe reprodução e escopo próprio antes de ampliar o trabalho.

Se surgir novo pedido funcional Google, preservar a numeração do documento: o próximo número disponível é **24**. T0–T4 são identificadores deste plano, não itens adicionados à lista de frota. O documento de pedidos não foi editado.

## 7. Entregáveis e decisões preservadas

Entrega prevista: instalador 0.8.5, fonte com runtime simplificado e bancada reproduzível, registros de validação e manifesto de insumos, guia/relatório e hashes. O relatório de impacto deve registrar explicitamente as rotas/campos retirados, a nova entrada de manutenção e qualquer mudança de contrato. Nenhum outro plugin será modificado ou receberá mensagem automaticamente.

Permanecem fora do escopo: novas funcionalidades sem demanda identificada; reimplementação dos pedidos 1–23; tags/consentimento no Google; rota GA4 ↔ Search Console rejeitada pelo documento; mudanças em MCP/Core; implantação automática ou mudança de crontab na frota. O plugin continua genérico e não depende do arquivo indisponível `padrao-unico-de-configuracao.md`.

**Critério de decisão:** um novo incidente, uma incompatibilidade demonstrada ou a conclusão das melhorias de engenharia fundamenta o fechamento da release. Não se cria uma correção funcional para justificar um número de versão. A distribuição aos sites permanece decisão do dono.

## 8. Fontes e rastreabilidade

- `Pedidos — Fator3 MCP Google(10).md`, anexo recebido; SHA-256 `9aabb6a80332e59539d7086258f1717cd00530ca3724792ed684217cebea4adb`.
- `Pedidos — Fator3 MCP(20261012-121233).md`, conteúdo integral consultado em 12/10/2026.
- `Pedidos — Fator3 Site Core(20261012-091740).md`, itens 194–208; conteúdo consultado em 12/10/2026.
- Fonte Google 0.8.4, commit local da implementação `70e01c81401ca96469390658710b423738351874`; `build/build.py`, `build/release-gates.json`, `build/compile-profile-schema.py`, SDK e documentos de validação.
- Revisão 2: orientação direta do dono de 12/10/2026; inspeção de `Integration/Transition.php`, `Integration/ServiceApi.php`, `Storage/Migration.php`, `Storage/Admission.php`, `Storage/Repository.php`, `Storage/Maintenance.php`, `Storage/CronStore.php`, `Automation/CronHistory.php`, `Records.php`, painel e ativação.
- Pacote-fonte 0.8.4: `dependencies/lab084.py`, `integration/README.md` e `evidence/084/validation-summary.json`.
- Instalador Google 0.8.4: SHA-256 `f06474bcba158ef838450c2c7a95cbff3bc876c3ddcfa05e5a5434fce06940f7`, coincidente com o prefixo registrado na frota.
- Revisão 3: `base-site-core-fator3-1.31.0.zip`, SHA-256 `bd84d4d9f06d4ecda6340a483b04c5b39e386ab528b5d29a8803a266ffe0d6a8`; inspecionados bootstrap, `class-f3base-companheiros.php`, `class-f3base-gsc.php`, catálogo de eventos e emissor do navegador.
- `impacto-core-1.31.0-para-mcp-google.md`, SHA-256 `2f625c95656701cb6ddc037817d593771705a6a108b53ba08bd63865c46ed2ef`.
- `relatorio-core-1.31.0.md`, SHA-256 `38801c91f2ebf6faf1c7a6c12058aa7464915d2d6eeda3e4b9049cdc898b7d34`.
- Encaminhamento desta análise: `encaminhamento-google-0.8.5-para-core-1.31.0.md`; nenhuma alteração aplicada ao Core.
- Revisão 4: `wp-mcp-fator3-0.21.0-fonte(2).zip`, SHA-256 `4f1acff8cd3a1d3018cc961b6d9362deb0c11f41b7bfb3f81d4fe869fbac32a3`; integridade conferida e fontes inspecionados, incluindo `ServerContract.php`, `ConnectionContext.php`, `UpdateChannel.php`, `ToolsHandler.php`, `PackageService.php` e `tools/release021/google-plan084.php`.
- `wp-mcp-fator3-0.21.0-relatorio(2).md`, SHA-256 `665bc7e41db41463c8e8c7a963653dac32827d35bcd1e25519d7519b7edbb7e4`.
- `plano-wp-mcp-fator3-0.21.1(1).md`, revisão 2, SHA-256 `35ff6bdd3fd06fa7cdc7d01449fe5ca0730a0f8706058cff3294446494832f80`.
- Contraprova no Google 0.8.4: `McpServer.php`, `McpBridge.php`, `Channel.php`, `Setup.php`, `Configuration.php`, `Automation/Context.php`, `Automation/Worker.php`, `Automation/Scheduling.php` e `Automation/Executor.php`.
- Encaminhamento MCP: `encaminhamento-google-0.8.5-para-mcp-0.21.1.md`; alterações somente no planejamento Google.

- Revisão 5: `impacto-planejado-core-1.32.0-para-mcp-google.md`, datado de 12/10/2026 e recebido em 13/10/2026; SHA-256 `580ca10398ea276c99d58ff8877888a281c7d383a1ea6b7c1cd306ff0f4cdbc7`. Registra intenção de implementação; naquela rodada ainda não havia pacote Core 1.32.0, recebido na revisão 8.
- Correção verificada em `base-site-core-fator3.php` do instalador 1.31.0: hook `f3_mcp_register_providers` e método `ExtensionContract::register`; encaminhamento Google ao Core atualizado em sua revisão 2.

- Revisão 6: `impacto-planejado-core-1.32.0-para-mcp-google(1).md`, revisão 2 de 15/10/2026; SHA-256 `78525aae9293788d27e5267e323ea9b85a0de1632b014110ad429c47e97458a2`. Naquele momento acrescentava pedidos 209–214(a–d) e mantinha 214(e) posterior; o adiamento foi superado pela revisão 7. Conferência dirigida: Google `includes/McpBridge.php` e `includes/CoreBinding.php`.

- Revisão 7: `impacto-planejado-core-1.32.0-para-mcp-google (1).md`, revisão 3 de 15/10/2026; SHA-256 `5d73d63c6469095c16656c1460951147d8161028627fd2df302ce88914c267b6`. Inclui webhook 214(e) na mesma release Core por decisão do dono às 07:26 −03. Conferência dirigida dos hooks REST em `includes/` Google e de `Auth/OAuthFlow.php`.

- Revisão 8: `wp-mcp-fator3-0.21.1-instalador.zip`, SHA-256 `12df8115663afb1755288bb115a06efe0ff651faa84561ce95ee951249171b9c`; `wp-mcp-fator3-0.21.1-fonte.zip`, SHA-256 `c521cbcb9a39425fc7e2b685d0e77194df44baf29416282ab5cb14835e4d52a0`; `wp-mcp-fator3-0.21.1-relatorio.md`, SHA-256 `08c0708e75cbab48ad12d7c16126918318a695fefe46e54ae591fe02356f17ab`.
- Revisão 8: `base-site-core-fator3-1.32.0(1).zip`, SHA-256 `d6248e0e70c577659a46aa6f9e5044144b591f66385ba9e1b10515f9bba917e4`; `base-site-core-fator3-1.32.0-fontes-testes(1).zip`, SHA-256 `dafeac50c2e7bca50c827dfc557dc1a88523d6aee1911d4819f0f041e0ff9cf3`; `impacto-core-1.32.0-para-mcp-google.md`, SHA-256 `f567acc2c0e5a036ac7c2413dca0b14b729aac33650590f4c996126ba54a98b2`; `relatorio-entrega-core-1.32.0(1).md`, SHA-256 `260690e2cca7b29163363296f9030bc45a3169d6dc474896b573306b4ec4dca6`.
- Inspeção revisão 8: MCP `ServerContract.php`, `ExtensionContract.php`, `UpdateChannel.php`, `ConnectionContext.php`, `McpAdapter.php`, `DefaultServerFactory.php`, contratos/guias, testes `release0211` e `evidencias/0211/acceptance.json`; Core bootstrap, `class-f3base-companheiros.php`, `class-f3base-gsc.php`, `class-f3base-servicos.php`, módulos LinkedIn/webhook/orçamento Pipedrive, catálogo e `suite/versao-1320/evidencias/validacao-resumo.json`; contraprova Google `Plugin.php`, `McpBridge.php`, `McpServer.php` e `Integration/ServiceApi.php`.

O commit de distribuição `8dd3031` é informado pela frota. O commit local acima identifica a implementação analisada; não se confundem histórico de desenvolvimento e repositório de distribuição. Os testes anteriores não foram repetidos nesta sessão de planejamento.
