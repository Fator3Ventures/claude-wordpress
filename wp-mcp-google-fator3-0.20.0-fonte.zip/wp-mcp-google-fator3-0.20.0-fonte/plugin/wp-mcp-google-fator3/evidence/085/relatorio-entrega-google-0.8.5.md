# Entrega — Fator3 MCP Google 0.8.5

15/10/2026. Plano 0.8.5, revisão 8, implementado em uma entrega. Não houve implantação em produção nem alteração nos fontes/instaladores dos plugins acompanhantes.

## Resultado

- Estruturas correntes criadas diretamente. Registros, filas, resultados e auditoria usam o repositório indexado; removidos importador/transição, fallback em options, importação de cron e famílias históricas de manutenção.
- `google/maintenance` é a entrada administrativa para manutenção limitada. `google/migrate-storage` e `google/complete-transition` foram retiradas sem aliases ou transferência de grants. Catálogo 3.0.0: 281 habilidades, 108 leituras e 173 escritas.
- `google/storage-status` descreve a estrutura atual. Armazenamento e manutenção usam contrato 2.0.0; configuração 4.0.0, execução 2.0.0 e SDK GSC 1.0.0 preservados. Nenhum bloqueio de instalação por versão/presença/ordem de acompanhantes.
- Preservados Service Account como padrão, métodos separados, gravação verificada, selftest estruturado, PUT vazio, confirmação de redução de serviços, guardas de recuperação, leases, cotas e reconciliação corrente.
- Retirado o aquecimento duplicado de Abilities. Primeiras chamadas HTTP/WP-CLI e duas ordens de carregamento foram exercitadas.
- Bancada própria, insumos com hashes, recursos isolados e encerramento de processos. Promoção copia o ZIP validado e recusa evidências ausentes, alteradas, incompletas ou incompatíveis com código/testes/insumos.
- Guias, contratos, catálogo, exemplos e documentação protegida atualizados. Scripts Cloud Shell revisado/original preservados; não executados.

## Validação própria sobre o candidato final

**1115 testes unitários, 12621 asserções; 1322 verificações nativas.** Contagens nativas incluem cenários repetidos na matriz. As contagens recebidas dos responsáveis MCP/Core não foram somadas.

| Grupo | Testes/verificações | Resultado |
|---|---:|---|
| unit | 1115 | Aprovado |
| native-clean | 473 | Aprovado |
| native-repro | 473 | Aprovado |
| native-install | 6 | Aprovado |
| native-upgrade | 361 | Aprovado |
| native-no-companions | 9 | Aprovado |
| package | 120 | Aprovado |
| build-negative | 17 | Aprovado |

Ambiente: WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, PHP-FPM/lighttpd, WP-CLI 2.12.0 e PHPUnit 9.6.17. MCP 0.21.1/Core 1.32.0 finais. Duas instalações limpas executaram em paralelo, com bancos, portas e processos independentes, ordens MCP→Core→Google e Google→Core→MCP. Outra instalação exercitou Google sem acompanhantes ativos. Variações de números de versão ocorreram somente em cópias descartáveis.

A atualização 0.8.4→0.8.5 ocorreu pelo MCP HTTP, com hash, nova requisição, preservação de credenciais cifradas, vínculos, serviços, conexão adicional, job concluído, agenda pausada e auditoria. O rollback foi conferido em `dry_run`, sem aplicação. Instalação inicial HTTP usa upload inativo seguido de `plugins/activate`.

A configuração foi exercitada pelo ToolsHandler real: mescla, substituição, omissão, vazio, rejeição de null, redução, confirmação obsoleta e confirmação de outro ator. Perfis e autorização de bridge/alvo permaneceram separados. A limpeza de tokens MCP preservou credenciais Google.

O Core consultou GSC com conexão não padrão e concessão explícita, com estados de ausência, ambiguidade e leitura recusada. O callback LinkedIn funcionou sem usuário/MCP durante pausa Google; seus hooks, configuração, segredo cifrado e recibo permaneceram separados.

## Achados tratados ou encaminhados

1. O diagnóstico de agendamento rejeitava a lista completa ao encontrar observação de um hook retirado. A 0.8.5 projeta e reconcilia somente hooks atuais, preservando observações fora do escopo sem reaplicá-las. Regressão unitária e atualização nativa aprovadas.
2. MCP 0.21.1 usa ativação silenciosa no executor de upload. Na instalação nova, `activate:true` pode omitir a inicialização Google. O fluxo separado foi validado; detalhes e reprodução estão no relatório de impacto MCP. Não foi introduzida inicialização escondida em consultas Google.

## Pacote e rastreabilidade

Instalador: **139 arquivos, 18 diretórios com index.php silencioso**, allowlist exata; sem Markdown, docs/, reference/, ferramentas, testes ou .htaccess públicos. Documentação protegida foi comparada aos fontes e os exemplos foram validados. O ZIP fonte não deve ser instalado no diretório público.

SHA-256 do instalador: `acd644d1cd9d7a766c03cad9cdd3c67c44635d1b0b2b49936060a588316be96f`.

Commit local de implementação: `d1411493ac715d0311bf4f7129534e2dc3116693`. Base: `70e01c8`. O pacote-fonte inclui `evidence/085/validation.json`, relatórios detalhados, hashes, manifesto portátil, testes e instruções em `tools/README.md`. Dependências do laboratório são externas e explicitamente declaradas; não são instaladas no WordPress de produção. A evidência 0.8.4 e documentos em `docs/history/` são históricos.

## Limites

APIs Google e serviços externos foram simulados/bloqueados. Não houve uso de contas reais, envio real de leads, homologação remota LinkedIn, teste de crontab hospedado, observação de vários dias na frota, matriz completa multisite ou Redis/Memcached real. A prova do callback Core usou despacho REST nativo, HTTPS controlado na bancada e assinatura sintética.

Rollback de arquivos não reverte banco, configurações alteradas nem efeitos remotos. As evidências MCP A13/A14 anteriores permanecem históricas; esta entrega fornece a complementação Google com o fluxo efetivamente ensaiado, sem reescrevê-las.
