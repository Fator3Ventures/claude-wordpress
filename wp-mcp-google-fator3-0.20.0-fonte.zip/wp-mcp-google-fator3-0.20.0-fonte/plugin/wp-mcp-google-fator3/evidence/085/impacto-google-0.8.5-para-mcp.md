# Encaminhamento ao Plugin MCP — Google 0.8.5

15/10/2026. Não houve alteração no MCP. Matriz testada: MCP 0.21.1 final, Core 1.32.0 final e Google 0.8.5. SHA-256 Google: `acd644d1cd9d7a766c03cad9cdd3c67c44635d1b0b2b49936060a588316be96f`.

## Ação necessária nos fluxos de instalação inicial

**O executor de upload MCP chama `activate_plugin($plugin, '', false, true)` em `includes/RecoveryEngine.php::activate_worker()`. O quarto argumento suprime os hooks de ativação do WordPress.**

Durante o ensaio de desenvolvimento, `plugins/upload-base64` com `overwrite:false, activate:true` retornou sucesso e deixou Google ativo; a requisição seguinte a `google/status` devolveu `permission_denied`. O pacote não recebeu a inicialização de canal/tabelas. Esse achado é da bancada descartável, não de produção. A inspeção do MCP final confirma a chamada silenciosa.

Fluxo aprovado com o **ZIP Google final**:

1. `plugins/upload-base64`: ZIP e `expected_sha256`, `expected_slug:"wp-mcp-google-fator3"`, `overwrite:false`, `activate:false`.
2. `plugins/activate`: `plugin:"wp-mcp-google-fator3/wp-mcp-google-fator3.php"`.
3. Nova requisição: `google/status`, `google/configuration-schema` e `google/maintenance`.

O responsável MCP deve avaliar a ativação inicial no executor independente com os hooks nativos e pós-condição verificada. Atualização de plugin já inicializado e primeira instalação são cenários diferentes. Não usar alteração direta de active_plugins nem depender de uma consulta Google para executar inicialização. Não é necessário esperar outra release MCP para usar o fluxo separado aprovado.

## Catálogo e autorização

- Catálogo Google passa a 3.0.0, com 281 habilidades.
- Retiradas `google/migrate-storage` e `google/complete-transition`, sem aliases.
- Nova `google/maintenance`, escrita administrativa, com contrato de manutenção 2.0.0. Perfil personalizado precisa de concessão própria; grant antigo não autoriza o novo nome. Bridge e alvo são conferidos separadamente.
- `google/storage-status.storage` publica prontidão atual 2.0.0, sem fases históricas. Cron deixa de publicar `legacy_last_pass` e `migration_pending`.
- Configuração 4.0.0, execução 2.0.0, SDK `server-integration/1.0.0`, política 1, provider `wp-mcp-fator3` e `wp-mcp-ultimate-server` preservados. Nenhum filtro numérico de acompanhantes foi introduzido.

## Complementação A13/A14

A13: descoberta/autorização/execução de maintenance, retirada dos nomes antigos, recusa de grant antigo e autorização separada bridge/alvo. Primeira chamada HTTP e primeiro processo WP-CLI aprovados nas duas ordens.

A14: instalação inicial em duas chamadas HTTP aprovada; atualização da 0.8.4 inicializada com `activate:true` aprovada. Hash exato, nova requisição, dados/credenciais preservados e pré-imagem de rollback em dry_run. O fluxo combinado de instalação inicial permanece com a limitação acima; não declarar esse percurso aprovado.

Provas: `evidence/085/native-install/install.json`, `native-upgrade/upgrade.json`, `native-clean/cold.json`, `native-repro/cold.json` e os respectivos manifests no fonte Google. Manter as evidências anteriores MCP intactas e anexar esta complementação. Nenhuma chamada remota Google real foi realizada.
