# Evidências — Fator3 MCP Google 0.18.0

Geradas por `tools/release018.py` e pelos controles descritos abaixo sobre o instalador `wp-mcp-google-fator3-0.18.0-instalador.zip` (SHA-256 em `validation018.json`). Google e e-mail simulados; nenhum site da frota nem o Site-Teste foi acessado.

| Arquivo ou pasta | Conteúdo |
|---|---|
| `validation018.json` | Prova vinculada ao SHA-256 do instalador, à identidade de build/ferramentas/testes e aos insumos; total de verificações por cenário e suíte. |
| `clean/`, `clean-713/`, `upgrade/`, `google-first/`, `isolated/` | Relatório JSON de cada suíte nativa, `environment.json` do laboratório e `google-debug-findings.json` (notices do Google no debug.log; vazio). |
| `contracts-*.json`, `response-candidate018.json` | Testes de contrato do SDK de conversões e de resposta. |
| `inputs.json` | SHA-256 e versão dos insumos de cada manifesto (WordPress 7.1.2, 7.1.3, base 0.17.0, MCP 0.28.0, Core 1.48.0, Meta 0.6.0, LinkedIn 0.7.0). |
| `unit/unit.log`, `unit/unit-junit.xml` | Gate PHPUnit histórico na 0.18.0: 1160 testes, sem falhas. |
| `unit/unit-base017-com-testes-017.log` | O mesmo gate na base 0.17.0 com os testes da 0.17.0: 103 falhas e 33 erros. |
| `negative/unit-testes018-runtime017.log` | Testes da 0.18.0 sobre o runtime da 0.17.0: 11 casos falham (M5, M6, guarda de `ABSPATH`). |
| `negative/neg-*.log` | Suítes `labels018`, `delivery018` e `readiness018` sobre o instalador 0.17.0: param no primeiro item da melhoria. |
| `perf018.json` | Consultas SQL e tempo de `google/status`, `google/conversion-delivery-status`, `google/readiness-status` e de uma fotografia do Core, 0.17.0 e 0.18.0, mesmo laboratório. |
| `suplementar-rodada/` | Google 0.18.0 com os instaladores entregues nesta rodada (MCP 0.29.0, Core 1.49.0, Meta 0.7.0, LinkedIn 0.8.0; SHA-256 em `inputs.json`), WordPress 7.1.3: instalação limpa e atualização 0.17.0 → 0.18.0 com os cinco plugins ativos. Verificação suplementar; não substitui o laboratório conjunto do orquestrador. |
