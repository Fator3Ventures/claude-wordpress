# Guia Google 0.19.0

## Pedido Google 36 — credenciais e conexões

Abra **Ferramentas → Fator3 MCP Google → Conexão** como administrador. Todos os campos exibem ajuda em português. Nome da conexão é editável inclusive em `default`; seu identificador permanece estável. A recomendação de nome é `conta de serviço · projeto`.

A chave JSON deve ser `service_account`, com project_id não vazio, private_key_id de 40 caracteres hexadecimais, private_key PEM iniciado por `-----BEGIN PRIVATE KEY-----` e client_email terminado em `.iam.gserviceaccount.com`. O token_uri deve ser `https://oauth2.googleapis.com/token`. JSON OAuth web/installed nessa entrada é recusado. O usuário representado é vazio ou e-mail válido.

Salvar/importar uma chave executa uma troca JWT nova no Google antes de persistir a candidata cifrada. Salvar e usar valida antes de gravar a chave ativa. A ativação de uma candidata valida novamente: uma chave pode ter sido revogada após sua preparação. Falhas preservam a chave ativa. `invalid_grant` também pode decorrer de relógio/delegação; a interface não afirma revogação sem prova.

Token de desenvolvedor: 22 letras, números, hífen ou sublinhado. Novo token exige sucesso em `customers:listAccessibleCustomers` antes da persistência. A consulta não gera gasto de anúncio e não confirma acesso a todas as contas; o endpoint ignora login-customer-id. O MCC de dez dígitos é normalizado e identificado como contexto da comprovação. Mudanças de identidade/MCC/token/API invalidam a comprovação correspondente. Client ID OAuth termina em `.apps.googleusercontent.com`; Client secret começa com `GOCSPX-`. Vazio preserva segredo; remover é ação separada.

**Rotação da mesma conta:** salve e ative a nova chave. O principal estável inclui e-mail, projeto, client_id e delegação. Permanecendo o principal e a configuração, grants de consumidor, referência do destino, revisão de execução e filas são preservados. Só provas de conversão já correspondentes e concedidas por administrador vigente são vinculadas à nova chave, na mesma gravação verificada. Não se amplia validade nem se cria prova. Campos de identidade/delegação divergentes não recebem essa preservação. Histórico guarda somente data, administrador e sufixos de oito caracteres, limitado às últimas vinte rotações.

**Outra identidade:** use Salvar para preparar a candidata, depois **Simular troca de identidade**. A tela mostra os recursos vinculados que a nova conta não acessa. Conceda acesso no fornecedor e simule novamente. Só então confirme **Trocar identidade**. Serviços e recursos permanecem selecionados; verificações de conversão da identidade anterior não autorizam a nova. O fluxo exige revisão/hash vinculados também à conexão e ao administrador; repete as consultas na confirmação. Se a configuração mudar, simule novamente. Os testes de recursos continuam opcionais na primeira ativação e na rotação da mesma conta.

O resumo distingue autenticação comprovada de acesso a recurso. Mostra somente a conta salva, projeto, sufixo da chave, data/serviços comprovados e aceite do developer token. Credencial antiga sem recibo aparece como não comprovada; abrir a tela não consulta o Google. A última consulta de recurso usa cache por identidade/seleção, de até 30 dias; sua expiração não revoga grants. Um resultado antigo não é garantia de acesso atual.

## Agentes e contratos

Comece por `google/readiness-status`, depois `google/configuration-schema {"contract_version":"4.0.0"}`. Nome: `google/rename-connection` com label e expected_revision. Troca: preparar chave no painel, chamar `google/plan-identity-change` com expected_revision, conferir preflight e usar `google/switch-identity` com expected_revision, expected_plan_hash e confirm_identity_change=true. As três operações aceitam connection_id, usam autorização administrativa e o gate Google. A chave permanece exclusiva dos formulários protegidos, nunca em respostas MCP.

A configuração mantém contrato 4.0.0; SDK de conversão `site-conversion-delivery/1.0.0` e leitor `search-console-reader/1.0.0` permanecem. GA4 seleciona conexão pelo `stream`, com Measurement ID vindo do Core. Nenhuma alteração do Core acompanha esta release. Não deduza ausência de efeito de retryable: preserve recibo incerto e reconcilie antes de repetir.

## Instalação, testes e limites

Instalação limpa ou atualização direta **0.18.1 → 0.19.0**, sem desinstalar. Mínimos declarados: WordPress 7.1.2 e PHP 8.3.6. Convivência da rodada: Core 1.49.1, MCP 0.29.1, Meta 0.8.0, LinkedIn 0.9.0. A ausência de acompanhantes bloqueia somente suas capacidades dependentes. Metadados de credenciais são por conexão e protegidos como configuração; nenhuma migração destrutiva ou nova tabela.

As suites e o relatório externo distinguem testes com respostas sintéticas e homologação no Google. Site-Teste estava sem credencial real: a validação de chave realmente revogada e a troca entre contas autorizadas exigem chave de teste do dono. Não houve gasto, publicação ou envio a clientes. Rollback de arquivos não desfaz gravações ou efeitos; voltar à 0.18.1 remove as novas validações e pode tornar necessária nova verificação de conversão quando se rotacionar outra chave.

Documentação completa pelo índice `google/documentation {}` e paginação com document, offset, limit_bytes e expected_revision; continue até next_offset=null e confira SHA-256. As descrições de abilities permanecem em português. Para operações, exemplos e domínios existentes, consulte README.md, CONTRACTS.md e os demais documentos do índice instalado.

Referências técnicas consultadas em 23/10/2026: https://developers.google.com/identity/protocols/oauth2/service-account e https://developers.google.com/google-ads/api/docs/account-management/listing-accounts .
