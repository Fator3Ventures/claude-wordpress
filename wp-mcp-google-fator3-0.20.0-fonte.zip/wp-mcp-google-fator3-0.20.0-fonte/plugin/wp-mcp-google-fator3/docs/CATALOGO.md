# Catálogo de habilidades — 0.20.0

Gerado por `build/export-contracts.php`. 290 habilidades: 112 de leitura e 178 de escrita. A disponibilidade depende da conexão e é revalidada na execução.

| Habilidade | Modo | Descrição |
|---|---|---|
| `ads/add-audience-to-campaign` | write | Aplica add-audience-to-campaign via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/add-keywords` | write | Aplica add-keywords via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/add-label` | write | Aplica add-label via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/add-negative-keywords` | write | Aplica add-negative-keywords via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/apply-label` | write | Aplica apply-label via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-ad-group` | write | Aplica create-ad-group via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-asset` | write | Aplica create-asset via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-asset-group` | write | Aplica create-asset-group via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-billing-setup` | write | Aplica create-billing-setup via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. Este método não aceita validateOnly: dry_run=true é recusado antes da gravação. |
| `ads/create-budget` | write | Aplica create-budget via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-campaign` | write | Aplica create-campaign via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-conversion-action` | write | Aplica create-conversion-action via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-experiment` | write | Aplica create-experiment via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-responsive-search-ad` | write | Aplica create-responsive-search-ad via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/create-user-list` | write | Aplica create-user-list via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/get-campaign` | read | Consulta GAQL de leitura de campaign, com paginação e limite explícitos. |
| `ads/get-customer` | read | Detalhes de uma única conta do Google Ads: nome, moeda, fuso horário, status e se é gerenciadora (MCC) ou de teste. |
| `ads/get-resource-metadata` | read | Descobre quais campos um recurso GAQL aceita: selecionáveis, filtráveis, ordenáveis, e quais métricas/segmentos combinam com ele. Use sempre antes de montar uma consulta em ads/search — não chute nomes de campo. A resposta fica em cache por 24 horas. |
| `ads/invite-user` | write | Aplica invite-user via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. Este método não aceita validateOnly: dry_run=true é recusado antes da gravação. |
| `ads/link-asset` | write | Aplica link-asset via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/list-accessible-customers` | read | Lista os IDs de cliente do Google Ads acessíveis pela credencial configurada. Use antes de qualquer outra rota quando não souber o customer_id. Com with_details (padrão), também traz nome, moeda, fuso e se cada conta é gerenciadora (MCC) ou de teste. |
| `ads/list-assets` | read | Consulta GAQL de leitura de asset, com paginação e limite explícitos. |
| `ads/list-audiences` | read | Consulta GAQL de leitura de audience, com paginação e limite explícitos. |
| `ads/list-conversion-actions` | read | Consulta GAQL de leitura de conversion_action, com paginação e limite explícitos. |
| `ads/list-customer-clients` | read | Lista as contas-cliente sob uma conta gerenciadora (MCC) do Google Ads: id, nome, nível na hierarquia, se também é gerenciadora, status, moeda, fuso e se está oculta. |
| `ads/list-experiments` | read | Consulta GAQL de leitura de experiment, com paginação e limite explícitos. |
| `ads/list-resources` | read | Lista os recursos GAQL válidos (campaign, ad_group, search_term_view, etc.), filtrando por um trecho do nome. Use para descobrir o recurso certo antes de chamar get-resource-metadata ou search. |
| `ads/list-users` | read | Consulta GAQL de leitura de customer_user_access, com paginação e limite explícitos. |
| `ads/mutate` | write | Executa googleAds:mutate com mutateOperations oficiais, inclusive operações de serviços combinados e IDs temporários negativos. operations usa a estrutura MutateOperation da API. dry_run envia validateOnly; partial_failure preserva resultados e erros individuais. Para serviços ausentes de MutateOperation, use google/execute-action. |
| `ads/remove-ad` | write | Aplica remove-ad via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-ad-group` | write | Aplica remove-ad-group via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-campaign` | write | Aplica remove-campaign via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-keywords` | write | Aplica remove-keywords via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-negative-keywords` | write | Aplica remove-negative-keywords via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/remove-user` | write | Aplica remove-user via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. Este método não aceita validateOnly: dry_run=true é recusado antes da gravação. |
| `ads/schedule-experiment` | write | Agenda um experimento já criado com braços e datas configurados. Retorna a operação assíncrona da Google. dry_run usa validateOnly. |
| `ads/search` | read | Executa uma consulta GAQL de leitura contra a Google Ads API, com paginação automática até o teto de linhas configurado. Informe "query" pronta OU "resource" + "fields" para montar a consulta. Sempre devolve a consulta final usada, mesmo em erro. |
| `ads/update-ad-group` | write | Aplica update-ad-group via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-ad-status` | write | Aplica update-ad-status via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-budget` | write | Aplica update-budget via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-campaign` | write | Aplica update-campaign via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-conversion-action` | write | Aplica update-conversion-action via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-keyword` | write | Aplica update-keyword via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. dry_run=true usa validateOnly real. |
| `ads/update-user-access` | write | Aplica update-user-access via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. Este método não aceita validateOnly: dry_run=true é recusado antes da gravação. |
| `ads/upload-click-conversions` | write | Envia ClickConversion para a conta selecionada. A API exige partialFailure=true; erros por conversão ficam explícitos na resposta. dry_run usa validateOnly. |
| `ads/upload-customer-match` | write | Executa create → addOperations → run de OfflineUserDataJob, com SHA-256 e retorno da operação assíncrona. Disponível para integrações Ads elegíveis existentes; desde abril de 2026 a Google exige Data Manager API para a maioria das novas integrações. dry_run precisa de job_resource_name existente e valida cada chamada sem criar/executar o job. |
| `ga/add-user` | write | Executa analyticsadmin.properties.accessBindings.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"user":"pessoa@empresa.com","roles":["predefinedRoles/editor"]}. roles vazia remove o vínculo na atualização. Requer analytics.manage.users e papel de administrador. |
| `ga/aplicar-perfil` | write | Simula por padrão. Aplica diferenças com retenção primeiro, sem criar propriedade nem remover definições extras. Exige hash da simulação ao aplicar. |
| `ga/archive-audience` | write | Executa analyticsadmin.properties.audiences.archive na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Criação: displayName, description, membershipDurationDays e filterClauses oficiais. Atualização: campos permitidos pela API, como displayName/description/eventTrigger. |
| `ga/archive-custom-dimension` | write | Executa analyticsadmin.properties.customDimensions.archive na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parameterName":"lead_type","displayName":"Tipo de lead","scope":"EVENT"}. |
| `ga/archive-custom-metric` | write | Executa analyticsadmin.properties.customMetrics.archive na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parameterName":"lead_score","displayName":"Pontuação","scope":"EVENT","measurementUnit":"STANDARD"}. |
| `ga/check-compatibility` | read | Verifica se uma combinação de dimensões, métricas e filtros é válida no GA4 antes de gastar cota com run-report. Params: property_id (opcional), dimensions (required), metrics (required), dimension_filter, metric_filter, compatibility_filter, format (opcionais). |
| `ga/conformidade` | read | Compara perfil configurável com propriedade existente. Só leitura. Retorna diff, auth.configured, streams e streamEnabled sem impor valores omitidos. |
| `ga/create-annotation` | write | Executa analyticsadmin.properties.reportingDataAnnotations.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"title":"Lançamento","color":"BLUE","annotationDate":{"year":2026,"month":9,"day":8}}; admite annotationDateRange em vez de annotationDate. |
| `ga/create-audience` | write | Executa analyticsadmin.properties.audiences.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Criação: displayName, description, membershipDurationDays e filterClauses oficiais. Atualização: campos permitidos pela API, como displayName/description/eventTrigger. |
| `ga/create-custom-dimension` | write | Executa analyticsadmin.properties.customDimensions.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parameterName":"lead_type","displayName":"Tipo de lead","scope":"EVENT"}. |
| `ga/create-custom-metric` | write | Executa analyticsadmin.properties.customMetrics.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parameterName":"lead_score","displayName":"Pontuação","scope":"EVENT","measurementUnit":"STANDARD"}. |
| `ga/create-google-ads-link` | write | Executa analyticsadmin.properties.googleAdsLinks.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"customerId":"1234567890","adsPersonalizationEnabled":true}. Requer os papéis correspondentes também no Google Ads. |
| `ga/create-key-event` | write | Executa analyticsadmin.properties.keyEvents.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"eventName":"generate_lead","countingMethod":"ONCE_PER_EVENT"}; atualizações aceitam countingMethod e defaultValue. |
| `ga/create-mp-secret` | write | Executa analyticsadmin.properties.dataStreams.measurementProtocolSecrets.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Servidor"}. secretValue só sai no retorno da criação; não é persistido pelo plugin. |
| `ga/create-property` | write | Executa analyticsadmin.properties.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parent":"accounts/123","displayName":"Site","timeZone":"America/Sao_Paulo","currencyCode":"BRL"}. |
| `ga/create-web-stream` | write | Executa analyticsadmin.properties.dataStreams.create na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Site","webStreamData":{"defaultUri":"https://seu-site"}}. A criação fixa type=WEB_DATA_STREAM. |
| `ga/delete-account` | write | Executa analyticsadmin.accounts.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Provisionamento: {"account":{"displayName":"Empresa","regionCode":"BR"},"redirectUri":"https://seu-site/retorno"}. redirectUri precisa estar registrado no projeto OAuth. |
| `ga/delete-annotation` | write | Executa analyticsadmin.properties.reportingDataAnnotations.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"title":"Lançamento","color":"BLUE","annotationDate":{"year":2026,"month":9,"day":8}}; admite annotationDateRange em vez de annotationDate. |
| `ga/delete-google-ads-link` | write | Executa analyticsadmin.properties.googleAdsLinks.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"customerId":"1234567890","adsPersonalizationEnabled":true}. Requer os papéis correspondentes também no Google Ads. |
| `ga/delete-key-event` | write | Executa analyticsadmin.properties.keyEvents.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"eventName":"generate_lead","countingMethod":"ONCE_PER_EVENT"}; atualizações aceitam countingMethod e defaultValue. |
| `ga/delete-mp-secret` | write | Executa analyticsadmin.properties.dataStreams.measurementProtocolSecrets.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Servidor"}. secretValue só sai no retorno da criação; não é persistido pelo plugin. |
| `ga/delete-property` | write | Executa analyticsadmin.properties.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parent":"accounts/123","displayName":"Site","timeZone":"America/Sao_Paulo","currencyCode":"BRL"}. |
| `ga/delete-web-stream` | write | Executa analyticsadmin.properties.dataStreams.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Site","webStreamData":{"defaultUri":"https://seu-site"}}. A criação fixa type=WEB_DATA_STREAM. |
| `ga/get-account-summaries` | read | Lista todas as contas e propriedades do Google Analytics 4 acessíveis pela credencial configurada (Admin API, com paginação seguida até o fim). Sem parâmetros. |
| `ga/get-metadata` | read | Lista as dimensões e métricas disponíveis para relatórios GA4: catálogo universal (sem property_id/padrão) ou catálogo de uma propriedade, com as customizadas. Use antes de run-report para achar nomes válidos. Params: property_id (opcional), custom_only (opcional, padrão true), query (opcional, filtra por nome/descrição). |
| `ga/get-property-details` | read | Devolve os detalhes de uma propriedade GA4: nome de exibição, fuso horário, moeda, categoria do setor e datas de criação/atualização. Params: property_id (opcional; usa a propriedade padrão configurada em Ferramentas → Fator3 MCP Google quando ausente). |
| `ga/get-settings` | read | Retorna propriedade, conta, retenção, atribuição, Google Signals, streams e medição avançada, eventos-chave, dimensões, métricas, anotações, públicos, vínculos Ads, usuários e metadados de segredos MP. Segredos são mascarados. Erros parciais ficam explícitos em errors; paginação completa ou truncamento informado. |
| `ga/list-custom-dimensions` | read | Lista as dimensões da propriedade existente com paginação completa. Não modifica nomes ou definições. |
| `ga/list-google-ads-links` | read | Lista os vínculos entre uma propriedade GA4 e contas do Google Ads (Admin API, com paginação seguida até o fim). Params: property_id (opcional; usa a propriedade padrão). |
| `ga/list-profiles` | read | Lista perfis configuráveis da conexão, sem consultas ao Google. |
| `ga/list-property-annotations` | read | Lista as anotações de uma propriedade GA4 — notas sobre lançamentos, campanhas de marketing ou variações de tráfego, marcadas em datas ou períodos específicos (Admin API v1alpha). Params: property_id (opcional; usa a propriedade padrão). |
| `ga/list-users` | read | Lista accessBindings de parent=accounts/123 ou properties/123; property_id usa a propriedade padrão. Inclui todas as páginas, com limite explícito e token de continuação. |
| `ga/profile-schema` | read | Schema versionado de perfis configuráveis. Não inclui padrões de agência. |
| `ga/provision-account` | write | Gera um ticket de criação de conta GA4 e a URL oficial dos termos. A conta só será criada quando uma pessoa aceitar os termos nessa URL. |
| `ga/remove-user` | write | Executa analyticsadmin.properties.accessBindings.delete na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"user":"pessoa@empresa.com","roles":["predefinedRoles/editor"]}. roles vazia remove o vínculo na atualização. Requer analytics.manage.users e papel de administrador. |
| `ga/run-conversions-report` | read | Executa um relatório de conversões, custo de anúncio e ROAS do GA4 (v1alpha runReport com conversionSpec). Use no lugar de run-report para conversões/anúncio. Params: date_ranges, dimensions, metrics, conversion_spec (required); property_id, dimension_filter, metric_filter, order_bys, limit, offset, currency_code, return_property_quota, format (opcionais). |
| `ga/run-funnel-report` | read | Executa um relatório de funil GA4 (v1alpha runFunnelReport): progressão dos usuários por uma sequência de passos, com desdobramento e próxima ação opcionais. Sem date_ranges, usa os últimos 30 dias. Params: property_id (opcional), funnel_steps (required), date_ranges, funnel_breakdown, funnel_next_action, segments, return_property_quota, format (opcionais; padrão raw). |
| `ga/run-realtime-report` | read | Executa um relatório em tempo real do GA4 (últimos ~30 minutos de atividade). Só aceita dimensões/métricas realtime — sem métricas customizadas. Params: property_id (opcional), dimensions (required), metrics (required), dimension_filter, metric_filter, order_bys, limit, offset, minute_ranges, return_property_quota, format (opcionais). |
| `ga/run-report` | read | Executa um relatório GA4 (Data API runReport): dimensões, métricas, filtros, ordenação e período livres. Ver a description de cada parâmetro para exemplos de JSON. Params: date_ranges, dimensions, metrics (required); property_id, dimension_filter, metric_filter, order_bys, limit, offset, currency_code, keep_empty_rows, return_property_quota, format (opcionais). |
| `ga/save-profile` | write | Salva definição local versionada; não altera Google. expected_revision evita sobrescrever outro editor. |
| `ga/send-event` | write | Envia até 25 eventos de um web stream ao Measurement Protocol. debug=true usa somente /debug/mp/collect: valida o payload e não coleta eventos. A validação não confirma api_secret. Em produção, HTTP 2xx confirma recebimento HTTP, sem garantir processamento/inclusão nos relatórios. O segredo não é persistido. |
| `ga/update-annotation` | write | Executa analyticsadmin.properties.reportingDataAnnotations.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"title":"Lançamento","color":"BLUE","annotationDate":{"year":2026,"month":9,"day":8}}; admite annotationDateRange em vez de annotationDate. |
| `ga/update-attribution` | write | Executa analyticsadmin.properties.updateAttributionSettings na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"reportingAttributionModel":"PAID_AND_ORGANIC_CHANNELS_DATA_DRIVEN"}. |
| `ga/update-audience` | write | Executa analyticsadmin.properties.audiences.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Criação: displayName, description, membershipDurationDays e filterClauses oficiais. Atualização: campos permitidos pela API, como displayName/description/eventTrigger. |
| `ga/update-data-retention` | write | Executa analyticsadmin.properties.updateDataRetentionSettings na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"eventDataRetention":"FOURTEEN_MONTHS","resetUserDataOnNewActivity":true}. |
| `ga/update-enhanced-measurement` | write | Executa analyticsadmin.properties.dataStreams.updateEnhancedMeasurementSettings na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"streamEnabled":true,"scrollsEnabled":true,"outboundClicksEnabled":true}. |
| `ga/update-google-signals` | write | Executa analyticsadmin.properties.updateGoogleSignalsSettings na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"state":"GOOGLE_SIGNALS_ENABLED"}; o consentimento exigido pela Google continua aplicável. |
| `ga/update-key-event` | write | Executa analyticsadmin.properties.keyEvents.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"eventName":"generate_lead","countingMethod":"ONCE_PER_EVENT"}; atualizações aceitam countingMethod e defaultValue. |
| `ga/update-property` | write | Executa analyticsadmin.properties.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"parent":"accounts/123","displayName":"Site","timeZone":"America/Sao_Paulo","currencyCode":"BRL"}. |
| `ga/update-user` | write | Executa analyticsadmin.properties.accessBindings.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"user":"pessoa@empresa.com","roles":["predefinedRoles/editor"]}. roles vazia remove o vínculo na atualização. Requer analytics.manage.users e papel de administrador. |
| `ga/update-web-stream` | write | Executa analyticsadmin.properties.dataStreams.patch na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. Ex.: {"displayName":"Site","webStreamData":{"defaultUri":"https://seu-site"}}. A criação fixa type=WEB_DATA_STREAM. |
| `google/ability-catalog` | read | Catálogo paginado do registro desta versão, com efeitos e schemas opcionais. Consulta local. |
| `google/alerts` | read | Consulta configuração e incidentes locais. Não envia mensagens. |
| `google/apply-template` | write | Valida, mapeia e compara modelo. Aplicação exige revisão e hash da prévia; usa gravação verificada e compensação. |
| `google/approve-job` | write | Vincula uma preparação a um único job de exportação. O token é consumido para delegação e não é armazenado nos parâmetros. |
| `google/audit` | read | Lê a auditoria local com filtros e retenção configurável. before/after refletem snapshots disponíveis e limitados; segredos e identificadores de Customer Match são removidos. |
| `google/audit-export` | read | Exportação paginada JSON ou CSV pela resposta autenticada. Sem arquivo público. CSV neutraliza fórmulas. Use next_cursor para completar a janela. |
| `google/audit-to-sheet` | write | Exporta até 100 eventos de uma janela fixada por export_cursor, com células literais e política do destino. Exige google/prepare-operation. Retorna próximo cursor e cobertura; não altera google/audit. |
| `google/blend` | read | Combina consultas GA4, Ads e Search Console por date, campaign ou page. Preserva linhas sem par e períodos comparados; recusa chaves duplicadas para não multiplicar métricas. |
| `google/cancel-job` | write | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/check-update` | read | Consulta somente a origem explicitamente configurada. Distingue ausência de atualização, incompatibilidade e falha de consulta. |
| `google/cleanup-jobs` | write | Remove detalhes encerrados após retenção; preserva deduplicação e resultados desconhecidos. |
| `google/configuration-schema` | read | Contrato versionado de opções, tipos, limites, dependências, operações e valores atuais. Segredos são sempre ocultos. Não consulta o Google. |
| `google/configure` | write | Planeja ou aplica configuração local verificada com serviços e recursos existentes; não cria propriedades Google. |
| `google/configure-alerts` | write | Ativa observação e e-mail mediante configuração explícita. Revalida intervalo e destinatários; a aceitação do envio não comprova entrega. |
| `google/configure-consumer` | write | Concede ou revoga leitura Search Console (padrão) ou GA4 para plugin registrado nesta conexão. GA4 exige contract ga4-reader/1.0.0 e property canônica; a concessão fixa essa propriedade. |
| `google/configure-conversion-delivery` | write | Contrato Core 1.0.0. Configurar e verificar explicitamente; status local não chama fornecedor. |
| `google/configure-local` | write | Auditar leituras locais e excluir dados públicos na desinstalação são optativos. Credenciais são sempre removidas na desinstalação. |
| `google/configure-policy` | write | Aplica a política após consultar o impacto por google/plan-policy. Exige revisão e hash da prévia; padrões não concedem acesso. |
| `google/configure-update-origin` | write | Define manifesto HTTPS e hosts confiáveis. Não publica pacote nem ativa atualização automática. |
| `google/conversion-context` | read | Lê contato e material pelo contrato público opcional do Core. Exige administração e canal autorizado; dispensa credencial Google. Não cria recursos nem comprova entrega. |
| `google/conversion-delivery-status` | read | Contrato Core 1.0.0. Configurar e verificar explicitamente; status local não chama fornecedor. |
| `google/create-connection` | write | Cria uma conexão local vazia para configuração no painel. |
| `google/create-job` | write | Enfileira tarefa persistente. Use idempotency_key para repetir o pedido sem duplicar. Escritas interrompidas não são repetidas. |
| `google/delete-job` | write | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/disconnect` | write | Remove tokens locais mantendo o cliente. revoke=true revoga também a autorização do usuário no projeto Google, afetando outros sites. |
| `google/documentation` | read | Índice e leitura integral paginada dos manuais e schemas desta versão. Local, estática, sem credenciais nem chamadas Google. Exige manage_options. |
| `google/executar-vencidos` | write | Executa agendas e tarefas elegíveis sem depender de visita ao site. Por padrão atua somente na conexão selecionada. Mesmo worker, autorização, prazo de 20 s e teto de 25 itens. |
| `google/execute-action` | write | Executa o id exato de google/list-actions usando parâmetros e corpo definidos no documento oficial. A URL é construída pelo plugin. Gravações são imediatas; dry_run só funciona quando o método aceita validateOnly. Audita estados disponíveis antes/depois. |
| `google/execute-read` | read | Executa apenas métodos classificados como consulta, incluindo POST de relatórios. Recusa mutações antes do envio. |
| `google/export-template` | read | Exporta somente serviços, vínculos, limites e política. Recursos parametrizados por padrão; nunca inclui credenciais ou alertas. |
| `google/export-to-sheet` | write | Executa query, blend ou queries e grava uma aba por relatório, substituindo valores ou anexando linhas. Células são literais, sem executar fórmulas. Aceita planilha compartilhada, Drive compartilhado ou criação via OAuth/delegação. |
| `google/get-job` | read | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/get-schedule` | read | Consulta parâmetros, estado e revisão de uma agenda da conexão, sem executá-la. |
| `google/integration-status` | read | Contrato, revisão da conexão selecionada e consumidores. compact:true permite ler a revisão em uma resposta pequena, sem credenciais ou chamadas Google. |
| `google/list-accounts` | read | Lista, num formato só, as propriedades do GA4 e as contas do Google Ads que a credencial alcança. Use os account_id devolvidos em google/query. Cache de 10 minutos. Substitui o list_accounts do Porter. |
| `google/list-actions` | read | Lista os métodos das dez APIs Google a partir dos documentos oficiais, com cache de 24 h e paginação. task procura palavras no texto em inglês; o id completo identifica a execução. request_schema usa referências em schemas[api]. |
| `google/list-connections` | read | Lista conexões e vínculos sem segredos. |
| `google/list-fields` | read | Descobre as métricas e dimensões que google/query aceita num conector. No GA4 vem do catálogo da própria API (com as personalizadas da propriedade, se informada); no Google Ads vem do catálogo curado do plugin. Substitui o list_fields do Porter. |
| `google/list-jobs` | read | Resumos paginados por conexão, estado, tarefa e período de criação. Não carrega resultados dos jobs. |
| `google/maintenance` | write | Executa uma passagem limitada de retenção, cache e reparação da agenda do próprio Google. Respeita a pausa de recuperação. |
| `google/mcp-read` | read | Executa exclusivamente habilidades classificadas como consulta; recusa mutações antes da execução. |
| `google/mcp-write` | write | Executa habilidades de mutação com os mesmos gates, políticas e confirmações. |
| `google/plan-configuration` | read | Planeja ou aplica configuração local verificada com serviços e recursos existentes; não cria propriedades Google. |
| `google/plan-identity-change` | write | Testa a chave candidata e os recursos vinculados, sem trocar a identidade ativa. Retorna a revisão e o hash necessários para confirmar a troca. Faz consultas ao Google. |
| `google/plan-policy` | read | Prévia local dos padrões excluídos e contextos pendentes invalidados pela mudança. Não altera permissões. |
| `google/plan-template` | read | Valida, mapeia e compara modelo. Aplicação exige revisão e hash da prévia; usa gravação verificada e compensação. |
| `google/policy-discover-resources` | read | Consulta administrativa dos recursos acessíveis à identidade. Exige manage_options e não concede acesso operacional. |
| `google/preflight` | read | Leituras reais por serviço e recurso. Distingue passed, failed, skipped e not_configured. |
| `google/prepare-job` | write | Calcula os efeitos da exportação persistida, sem escrita remota. Retorna confirmation_token para google/approve-job.approval_token. |
| `google/prepare-operation` | write | Calcula pedidos sem enviá-los e emite token vinculado de uso único. A preparação não atesta aprovação humana. |
| `google/query` | read | Relatório unificado de GA4, Google Ads ou Search Console: métricas por dimensão, num período, com filtros, ordenação e comparação com o período anterior. Devolve colunas e linhas posicionais. Substitui o query_data do Porter. |
| `google/readiness-status` | read | Veredito local da conexão em uma chamada: ready, attention ou blocked, com cada verificação (credencial, armazenamento, recuperação, executor, entrega GA4 e Ads com validade e renovação, incidentes abertos e Site Core) e a ação a tomar. Não consulta o Google, não repara nem envia e-mail. |
| `google/reconcile-job` | write | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/recovery` | write | Prepare pausa e drena antes do restore. Resume exige reconciliação e geração atual; invalida contextos restaurados. |
| `google/recovery-status` | read | Consulta a pausa fora do banco e a geração de execução; nenhum segredo. |
| `google/rename-connection` | write | Altera somente o nome exibido, inclusive da conexão default. Mantém o ID e exige revisão atual. |
| `google/report-templates` | read | Modelos disponíveis para relatórios e monitoramento. |
| `google/resource-policy` | read | Consulta a política da conexão e sua cobertura, sem segredos nem consultas externas. |
| `google/run-job` | write | Controla um job desta conexão. Cancelar preserva etapas concluídas; reconciliação registra evidência sem repetir escrita. |
| `google/run-report` | read | Executa modelo com período e comparação opcional. alert avalia queda numérica e não atribui causa. |
| `google/schedule-report` | write | Cria ou atualiza agenda de leituras. enabled=false pausa. Atualizações exigem a revisão de google/get-schedule. Resultados ficam em jobs, sem enviar notificações externas. |
| `google/selftest` | read | Verifica cifra, JWT, configuração e consultas localmente. live:true acrescenta leituras Google. Distingue passed, incomplete, failed e execution_error; conta e nomeia pendências. success:true sem reprovação não garante aprovação integral: confira complete e all_checks_passed. |
| `google/status` | read | Diagnóstico da integração Google: canal aberto, conectores ligados, modo de autenticação e identidade da credencial, versão da Ads API, limites e rotas registradas. Nunca devolve segredo. Substitui whoami e list_connectors. |
| `google/storage-status` | read | Consulta local da estrutura atual e da manutenção, sem criar tabelas nem alterar dados. |
| `google/switch-identity` | write | Ativa a conta de serviço candidata depois de repetir a validação. Exige a revisão e o hash da simulação; mantém serviços e recursos. Não concede novos acessos. |
| `google/verify-conversion-delivery` | write | Contrato Core 1.0.0. Configurar e verificar explicitamente; status local não chama fornecedor. |
| `gsc/add-site` | write | Adiciona a propriedade à lista da credencial. A verificação de propriedade é separada. |
| `gsc/delete-site` | write | Remove a propriedade da lista da credencial; não exclui o site. |
| `gsc/delete-sitemap` | write | Remove um sitemap da lista da Search Console; não remove o arquivo do site. |
| `gsc/ensure-sitemap` | write | Confere o sitemap registrado, verifica publicação e envia se ausente. Retorna estado de processamento separado de indexação. |
| `gsc/get-site` | read | Obtém a permissão da credencial na propriedade. |
| `gsc/inspect-url` | read | Inspeciona a versão indexada de uma URL. Não solicita indexação. |
| `gsc/inspect-urls` | write | Persiste até 500 URLs. auto executa 1–5 URLs únicas na chamada; queued apenas enfileira. Compartilha worker, prazo e cota com cron e CLI. |
| `gsc/list-sitemaps` | read | Lista sitemaps enviados, opcionalmente filtrados por índice. |
| `gsc/list-sites` | read | Lista propriedades Search Console e suas permissões. |
| `gsc/migracao-conferir` | read | Somente leitura: pares origem/destino, redirects limitados, canônicas conhecidas, rastreamento e impressões. Não recomenda apagar redirects por ausência de dados. |
| `gsc/preparar-site` | write | Fluxo genérico com simulação por padrão: acesso, publicação/registro de sitemap, vínculo opcional e inspeções persistidas. Não altera DNS nem cria propriedade. |
| `gsc/query` | read | Consulta desempenho orgânico: métricas nativas, dimensões, filtros e paginação até 25.000 linhas. |
| `gsc/submit-sitemap` | write | Envia um sitemap à Search Console. |
| `gtm/bulk-update-workspace` | write | Aplica várias alterações de entidades a uma área de trabalho numa só chamada. Entidades novas usam IDs temporários no formato "new_<número>" (por exemplo "new_1", "new_2"), que podem ser referenciados entre si, como uma tag criada dentro de uma pasta nova. |
| `gtm/combine-container` | write | Combina dois contêineres, mesclando as entidades do contêiner indicado neste contêiner. |
| `gtm/create-built-in-variable` | write | Ativa uma ou mais variáveis integradas na área de trabalho. |
| `gtm/create-client` | write | Cria um cliente do contêiner de servidor. |
| `gtm/create-container` | write | Cria um contêiner. |
| `gtm/create-environment` | write | Cria um ambiente do contêiner. |
| `gtm/create-folder` | write | Cria uma pasta da área de trabalho. |
| `gtm/create-gtag-config` | write | Cria uma configuração da tag do Google. |
| `gtm/create-tag` | write | Cria uma tag da área de trabalho. |
| `gtm/create-template` | write | Cria um modelo personalizado da área de trabalho. |
| `gtm/create-transformation` | write | Cria uma transformação da área de trabalho. |
| `gtm/create-trigger` | write | Cria um acionador da área de trabalho. |
| `gtm/create-user-permission` | write | Concede a um usuário acesso à conta e aos contêineres do Tag Manager. |
| `gtm/create-variable` | write | Cria uma variável da área de trabalho. |
| `gtm/create-version-workspace` | write | Cria uma versão do contêiner com as entidades da área de trabalho, exclui a área de trabalho e define a nova versão como base do contêiner. |
| `gtm/create-workspace` | write | Cria uma área de trabalho do contêiner. |
| `gtm/create-zone` | write | Cria uma zona da área de trabalho. |
| `gtm/delete-built-in-variable` | write | Desativa uma ou mais variáveis integradas na área de trabalho. |
| `gtm/delete-client` | write | Exclui um cliente do contêiner de servidor. |
| `gtm/delete-container` | write | Exclui um contêiner. |
| `gtm/delete-environment` | write | Exclui um ambiente do contêiner. |
| `gtm/delete-folder` | write | Exclui uma pasta da área de trabalho. |
| `gtm/delete-gtag-config` | write | Exclui uma configuração da tag do Google. |
| `gtm/delete-tag` | write | Exclui uma tag da área de trabalho. |
| `gtm/delete-template` | write | Exclui um modelo personalizado da área de trabalho. |
| `gtm/delete-transformation` | write | Exclui uma transformação da área de trabalho. |
| `gtm/delete-trigger` | write | Exclui um acionador da área de trabalho. |
| `gtm/delete-user-permission` | write | Remove um usuário da conta, revogando o acesso a ela e a todos os seus contêineres. |
| `gtm/delete-variable` | write | Exclui uma variável da área de trabalho. |
| `gtm/delete-version` | write | Exclui uma versão do contêiner. |
| `gtm/delete-workspace` | write | Exclui uma área de trabalho do contêiner. |
| `gtm/delete-zone` | write | Exclui uma zona da área de trabalho. |
| `gtm/diagnostico` | read | Compara os IDs publicados com os slots do Core e identifica configuração de consentimento. Acrescenta contexto opcional de contato/material com revisão coerente. Análise estática não comprova entrega. |
| `gtm/entities-folder` | read | Lista as entidades (tags, acionadores e variáveis) contidas numa pasta da área de trabalho. |
| `gtm/get-account` | read | Consulta uma conta do Tag Manager. |
| `gtm/get-client` | read | Consulta um cliente do contêiner de servidor. |
| `gtm/get-container` | read | Consulta um contêiner. |
| `gtm/get-destination` | read | Consulta um destino vinculado ao contêiner. |
| `gtm/get-environment` | read | Consulta um ambiente do contêiner. |
| `gtm/get-folder` | read | Consulta uma pasta da área de trabalho. |
| `gtm/get-gtag-config` | read | Consulta uma configuração da tag do Google. |
| `gtm/get-publication` | read | Consulta local do diário, sem repetir escritas. |
| `gtm/get-status-workspace` | read | Identifica as entidades alteradas e as que estão em conflito na área de trabalho. |
| `gtm/get-tag` | read | Consulta uma tag da área de trabalho. |
| `gtm/get-template` | read | Consulta um modelo personalizado da área de trabalho. |
| `gtm/get-transformation` | read | Consulta uma transformação da área de trabalho. |
| `gtm/get-trigger` | read | Consulta um acionador da área de trabalho. |
| `gtm/get-user-permission` | read | Consulta o acesso de um usuário à conta e aos contêineres do Tag Manager. |
| `gtm/get-variable` | read | Consulta uma variável da área de trabalho. |
| `gtm/get-version` | read | Consulta uma versão do contêiner. |
| `gtm/get-workspace` | read | Consulta uma área de trabalho do contêiner. |
| `gtm/get-zone` | read | Consulta uma zona da área de trabalho. |
| `gtm/import-from-gallery-template` | write | Importa um modelo personalizado da Galeria de modelos da comunidade para a área de trabalho. |
| `gtm/latest-version-header` | read | Consulta o resumo da versão mais recente do contêiner. |
| `gtm/link-destination` | write | Vincula um destino a este contêiner e o desvincula do contêiner ao qual estava ligado. |
| `gtm/list-accounts` | read | Lista as contas do Tag Manager a que a credencial tem acesso. |
| `gtm/list-built-in-variables` | read | Lista as variáveis integradas ativadas na área de trabalho. |
| `gtm/list-clients` | read | Lista os clientes da área de trabalho. |
| `gtm/list-containers` | read | Lista os contêineres de uma conta do Tag Manager. |
| `gtm/list-destinations` | read | Lista os destinos vinculados a um contêiner. |
| `gtm/list-environments` | read | Lista os ambientes de um contêiner. |
| `gtm/list-folders` | read | Lista as pastas da área de trabalho. |
| `gtm/list-gtag-config` | read | Lista as configurações da tag do Google na área de trabalho. |
| `gtm/list-tags` | read | Lista as tags da área de trabalho. |
| `gtm/list-templates` | read | Lista os modelos personalizados da área de trabalho. |
| `gtm/list-transformations` | read | Lista as transformações da área de trabalho. |
| `gtm/list-triggers` | read | Lista os acionadores da área de trabalho. |
| `gtm/list-user-permissions` | read | Lista os usuários com acesso à conta, com as permissões de conta e de contêiner de cada um. |
| `gtm/list-variables` | read | Lista as variáveis da área de trabalho. |
| `gtm/list-version-headers` | read | Lista os resumos de todas as versões do contêiner. |
| `gtm/list-workspaces` | read | Lista as áreas de trabalho de um contêiner. |
| `gtm/list-zones` | read | Lista as zonas da área de trabalho. |
| `gtm/live-version` | read | Consulta a versão publicada (em produção) do contêiner. |
| `gtm/lookup-container` | read | Localiza um contêiner pelo ID de destino ou pelo ID de tag. |
| `gtm/move-entities-to-folder-folder` | write | Move entidades para uma pasta da área de trabalho. Com folder_id igual a 0, retira as entidades da pasta em que estão. |
| `gtm/move-tag-id-container` | write | Remove um ID de tag do contêiner. |
| `gtm/publicar` | write | Simular é o padrão. A publicação exige expected_fingerprint da prévia. Reversão republica a versão indicada; criação de versão substitui o workspace. |
| `gtm/publish-version` | write | Publica uma versão do contêiner, que passa a ser a versão em produção. |
| `gtm/quick-preview-workspace` | write | Gera uma prévia rápida da área de trabalho, criando uma versão provisória do contêiner com todas as suas entidades, sem publicar. |
| `gtm/reauthorize-environment` | write | Gera um novo código de autorização para um ambiente do contêiner, invalidando o anterior. |
| `gtm/resolve-conflict-workspace` | write | Resolve um conflito de mesclagem de uma entidade da área de trabalho, substituindo-a pela entidade resolvida enviada no pedido. |
| `gtm/revert-built-in-variable` | write | Desfaz as alterações feitas em variáveis integradas na área de trabalho. |
| `gtm/revert-client` | write | Desfaz as alterações feitas em um cliente do contêiner de servidor. |
| `gtm/revert-folder` | write | Desfaz as alterações feitas em uma pasta da área de trabalho. |
| `gtm/revert-tag` | write | Desfaz as alterações feitas em uma tag da área de trabalho. |
| `gtm/revert-template` | write | Desfaz as alterações feitas em um modelo personalizado da área de trabalho. |
| `gtm/revert-transformation` | write | Desfaz as alterações feitas em uma transformação da área de trabalho. |
| `gtm/revert-trigger` | write | Desfaz as alterações feitas em um acionador da área de trabalho. |
| `gtm/revert-variable` | write | Desfaz as alterações feitas em uma variável da área de trabalho. |
| `gtm/revert-zone` | write | Desfaz as alterações feitas em uma zona da área de trabalho. |
| `gtm/reverter` | write | Simular é o padrão. A publicação exige expected_fingerprint da prévia. Reversão republica a versão indicada; criação de versão substitui o workspace. |
| `gtm/set-latest-version` | write | Define a versão mais recente usada na sincronização das áreas de trabalho para detectar conflitos e erros. |
| `gtm/snippet-container` | read | Obtém o trecho de código de instalação do contêiner. |
| `gtm/sync-workspace` | write | Sincroniza a área de trabalho com a versão mais recente do contêiner: atualiza as entidades não alteradas e aponta conflitos nas alteradas. |
| `gtm/undelete-version` | write | Restaura uma versão do contêiner excluída. |
| `gtm/update-account` | write | Atualiza uma conta do Tag Manager. |
| `gtm/update-client` | write | Atualiza um cliente do contêiner de servidor. |
| `gtm/update-container` | write | Atualiza um contêiner. |
| `gtm/update-environment` | write | Atualiza um ambiente do contêiner. |
| `gtm/update-folder` | write | Atualiza uma pasta da área de trabalho. |
| `gtm/update-gtag-config` | write | Atualiza uma configuração da tag do Google. |
| `gtm/update-tag` | write | Atualiza uma tag da área de trabalho. |
| `gtm/update-template` | write | Atualiza um modelo personalizado da área de trabalho. |
| `gtm/update-transformation` | write | Atualiza uma transformação da área de trabalho. |
| `gtm/update-trigger` | write | Atualiza um acionador da área de trabalho. |
| `gtm/update-user-permission` | write | Atualiza o acesso de um usuário à conta e aos contêineres do Tag Manager. |
| `gtm/update-variable` | write | Atualiza uma variável da área de trabalho. |
| `gtm/update-version` | write | Atualiza o nome e as notas de uma versão do contêiner. |
| `gtm/update-workspace` | write | Atualiza uma área de trabalho do contêiner. |
| `gtm/update-zone` | write | Atualiza uma zona da área de trabalho. |
| `siteverification/get-token` | read | Obtém o token e o método de verificação. Instalar arquivo, meta tag ou DNS é tarefa separada. |
| `siteverification/list` | read | Lista sites e domínios verificados pela credencial. |
| `siteverification/update-owners` | write | Substitui a lista completa de proprietários; a API exige preservar o proprietário autenticado. |
| `siteverification/verify` | write | Confirma um token já instalado e torna a credencial proprietária verificada. |
