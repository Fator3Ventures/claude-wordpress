# Guia — Fator3 MCP Google 0.14.0

Instale o ZIP instalador diretamente sobre a 0.13.0, sem desinstalar. Mínimos: WordPress 7.1.2 e PHP 8.3.6. Não instale o ZIP fonte. Preserve backup do plugin e dos dados. O Core 1.40.0 fornece a seleção explícita de transporte; a atualização Google não instala nem altera o Core.

Leia [conversões servidor](CONVERSION-DELIVERY-CORE-140.md) para configuração, segredo MP, prova de elegibilidade Ads, verificação e limites de entrega. Consulte [cron](ACOMPANHAMENTO-CRON.md) para interpretar lacunas e causas observadas. O estado inicial é desabilitado/sem prontidão até configuração e verificação autorizadas.

## Operação existente

As habilidades de Analytics, Ads, GSC, GTM, Site Verification, Sheets e Drive preservam os contratos existentes. Veja [contratos públicos](CONTRATOS-PUBLICOS.md), [SDK PHP](SDK-PHP.md), [migração e rollback](MIGRACAO.md) e [receitas](RECEITAS.md).

A configuração continua em 4.0.0; a execução, armazenamento e manutenção em 2.0.0. O leitor `google/conversion-context` mantém `conflict:true` e `retryable:false` para conflito de revisão validado, sem inventar `current_revision`. A prova atual fica em [VALIDACAO.md](VALIDACAO.md) e no relatório externo da entrega.
