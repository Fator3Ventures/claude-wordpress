# Conversões pelo servidor — Google 0.18.1

## Configuração e autorização

Ferramentas → Fator3 MCP Google tem um menu e seis abas: Conexão, Conversões, Search Console, GTM, Incidentes e Avançado. Consulte as listas da conta depois de escolher outra propriedade ou conta. A seleção salva permanece visível quando a lista não foi carregada; não há seleção automática. Em Conversões o ID de medição vem do contrato de medição do Site Core. O campo `measurement_id` da API de configuração é legado: aceito, mas substituído pelo valor efetivo do Core. Segredo de coleta é cifrado por conexão, vazio preserva e remoção é explícita. A tela não pede comprovante de envio anterior.

Configuração e verificação continuam administrativas, com nonce e revisão. `google/conversion-delivery-status` e `google/status` são leituras locais. Mais de uma conexão habilitada por destino bloqueia prontidão. Desde a 0.18.1, a conexão de um destino é a que tem esse destino configurado: fluxo (`stream`) para GA4, ação de conversão para Ads. O ID de medição do Core, igual em todas as conexões, não seleciona conexão. A prontidão da conexão, com validade e próxima renovação, também aparece em `google/readiness-status`. GA4 exige fluxo pertencente ao ID de medição Core e segredo conferido na Admin API, seguido de debug sem ingestão. Configuração idêntica não revoga a prova. Configuração alterada, credencial, segredo, destino, concessão, política/serviços ou geração de recuperação exigem nova verificação.

## Renovação automática — pedido 31

A prova vale 24 horas; o executor existente tenta renová-la após 12 horas, sem assumir a identidade do administrador. Confere a concessão persistida, identidade, políticas e travas antes de chamar o fornecedor. Faz as mesmas consultas da verificação manual. A renovação não coleta evento GA4 nem conversão Ads.

Falha mantém a prova anterior até expirar, registra incidente em palavras, avisa `admin_email` e agenda nova tentativa em 5, 10, 20, 40 e depois 60 minutos. A aceitação de `wp_mail` não comprova recebimento da mensagem. Falha de envio de e-mail pode ser tentada novamente na próxima renovação; uma aceitação ou tentativa sem confirmação não dispara duplicata imediata. Ao recuperar o acesso, a renovação resolve o incidente. A rotina pode recuperar uma prova expirada se a identidade/autorização permanecer igual; mudança relevante exige ação administrativa. `renewal` informa `last_at`, `result`, `code` quando houve falha, `failures` e `next_attempt` por destino. O cron WordPress precisa continuar sendo acionado pelo servidor; a tarefa externa de verificação da frota deixa de ser necessária após homologação.

## Data Manager — pedido 32

Habilite `datamanager.googleapis.com` no projeto Cloud. Use conta de serviço ou OAuth com escopo `https://www.googleapis.com/auth/datamanager` e acesso Padrão ou Administrador à conta Ads. Para conta de serviço, confira também Service Usage Consumer no projeto. OAuth existente precisa de novo consentimento se o escopo não foi concedido. A ingestão Data Manager não envia developer token nem utiliza o nível de acesso da Google Ads API. A consulta de contas/ações ainda usa Google Ads API, escopo `adwords`, token de desenvolvedor e aprovação do projeto para produção. O `google/selftest` expõe essa distinção sem expor credenciais.

A ação deve ser Site — Importação de cliques (`UPLOAD_CLICKS`), ativa. A verificação lê a ação, seu valor e moeda e executa `events:ingest` com `validateOnly:true`. Resposta vazia bem-sucedida é válida nesse modo: não se exige requestId nem comprovação de upload legado. Isso confirma a verificação técnica, não a atribuição comercial. O valor/moeda enviados são a fotografia da ação obtida na última verificação/renovação, e não os zeros fixados pelo Core antigo. Se a ação for alterada no Google, verifique novamente para usar os novos valores imediatamente.

O adaptador exige exatamente um identificador `gclid`, `gbraid` ou `wbraid`, consentimento de dados publicitários concedido, `order_id=record_id`, identidade e data válidas. Preserva a data original e usa `transactionId=record_id`. Envia um evento e um destino por requisição, sem nome, e-mail ou telefone. Não transforma ausência de consentimento de personalização em consentimento concedido.

Antes do HTTP registra intenção durável no repositório existente, tipo `conversion`, sem payload de contato ou clique. Após resposta registra requestId e destino. Repetição de `send`/`sendBound` para o mesmo registro/conexão consulta o recibo local e não repete ingestão, inclusive após timeout ou queda. Sem requestId recuperável, permanece incerto para revisão; o sistema não inventa confirmação.

## Contratos e dependência Core

`site-conversion-delivery/1.0.0`, `send(payload)` e `sendBound(payload,destinationRef)` permanecem. A referência aceita pelo Core continua sendo conferida sob trava e antes de cada HTTP. GA4 retorna entregue com evidência de recebimento HTTP, sem afirmar processamento. O Google não assume captura, consentimento, fila comercial ou emissão de tags.

Para Ads, `capabilities.async_reconciliation=site-conversion-reconcile/1.0.0` anuncia `reconcileBound(recordId,destinationRef)`. É consulta, jamais ingestão. Core 1.46.1 recebido já incorpora esse contrato. Não há novo desenvolvimento Core nem pacote de dependência nesta rodada. Sem o método Core correspondente, Ads informa `core_async_unsupported`; GA4 e ferramentas próprias continuam disponíveis.

Core consulta suas linhas incertas sob a trava e prazo existentes, conservando o destino aceito e exclusões. A consulta só começa após 30 minutos e usa espera crescente até 6 horas. `requestStatus:retrieve` não recebe dados do contato. Como cada request contém exatamente um evento e um destino, SUCCESS com destino correspondente e `eventsIngestionStatus.recordCount="1"` identifica o resultado desse registro. Isso é uma inferência segura da cardinalidade controlada; a API não retorna um vetor de resultados por evento. Atribuição e visualização na ação exigem homologação externa.

PROCESSING, PARTIAL_SUCCESS, divergência, perda de resposta ou erro desconhecido permanecem `incerto`. FAILED só vira `recusado/non_delivery_proven` para razões explícitas de rejeição do único registro. Erros de duplicidade e internos ficam incertos, pois podem coexistir com entrega anterior. Nenhuma consulta repete upload. O método legado `ads/upload-click-conversions` é bloqueado antes do HTTP na ausência de comprovação administrativa vigente da 0.15, vinculada à mesma identidade/token/destino. Aprovação Explorer não constitui elegibilidade para esse método. A migração usa Data Manager.

## Instalação, recuperação e limites

Atualização direta Google 0.16 → 0.17, sem desinstalar. Não há nova tabela: recibos usam o repositório indexado já instalado e ficam preservados para deduplicação. Use Core 1.46.1 fornecido. Provas válidas da 0.16 são preservadas; configure e verifique somente os destinos alterados. Não apague recibos ou reabra registros incertos para forçar recuperação. Backup/restauração deve preservar banco, salts e guarda operacional; restauração não desfaz conversões Google. Não reverter apenas arquivos com trabalho ativo ou incerto.

Os registros reais 113 e 125 devem ser consultados pelo responsável na instalação atual, vinculados ao destino somente com comprovação de não entrega e recuperados pelo fluxo Core autorizado. Não inferir record_id a partir do número visual. Conferir uma conversão por registro e primeiro contato real com clique após a troca. Dois dias sem a tarefa de verificação da frota, segredo revogado e e-mail antes do vencimento são aceites reais separados da simulação local. A documentação não declara esses aceites concluídos.

## Referências oficiais consultadas em 21/10/2026

- [Ingestão e validateOnly](https://developers.google.com/data-manager/api/reference/rest/v1/events/ingest)
- [Conversões offline e ação exigida](https://developers.google.com/data-manager/api/devguides/events/google-ads/offline/send-events)
- [Consulta assíncrona](https://developers.google.com/data-manager/api/reference/rest/v1/requestStatus/retrieve)
- [Diagnóstico e intervalo inicial](https://developers.google.com/data-manager/api/devguides/diagnostics)
- [Acesso](https://developers.google.com/data-manager/api/devguides/quickstart/set-up-access)
- [Implantação e conta de serviço](https://developers.google.com/data-manager/api/devguides/concepts/deploy)
