# Plano — Google 0.19.0

23/10/2026. Implementação do pedido Google 36. Base direta 0.18.1: instalador SHA-256 `91c97cc300360511bc2477f5af9b0c2017e8b04861d015aaf0f0e5accd1cefef`. Alvo ainda não fechado.

Validar formato e autenticação antes de persistir candidatas; testar developer token com listAccessibleCustomers; apresentar identidade e provas vinculadas à credencial; permitir renomear inclusive default; separar troca de identidade com prévia e revisão da rotação de chave da mesma conta. Preservar grants, destinos, expiração das provas e filas. Falha de validação preserva credencial anterior; falha de persistência usa rollback verificado existente. Nunca deduzir ausência de efeito de retryable.

Fronteiras examinadas: Core 1.49.1 (snapshot, conversões, consumidor GSC), MCP 0.29.1 (idempotência, autorização e documentação), Meta 0.8.0 e LinkedIn 0.9.0 (convivência). O impacto recebido MCP→Google está resolvido no transporte e não exige alteração do produtor. A preservação de provas é interna ao Google, sem adaptação do Core nem novo contrato compartilhado. Nenhum novo impacto técnico identificado neste planejamento; não emitir avisos de versão como impactos.

Validar recusas, ausência de cache na prova da nova chave, concorrência/revisão, rollback, rotação e troca de identidade; instalação limpa, atualização direta e isolamento com WordPress mínimo/atual; interface HTML/DOM e leitura documental. Testes locais interceptam Google e não homologam fornecedor. Aceite com chave Google real depende de credencial de teste disponível no Site-Teste. Preservar estado de terceiros e registrar limites reais.
