## Atualização 0.19.0 — pedido Google 36

Base direta 0.18.1. Consulte [GUIA-0.19.0.md](GUIA-0.19.0.md) para validação obrigatória de credenciais, rotação, resumo e troca guiada de identidade. Novas operações: google/rename-connection, google/plan-identity-change e google/switch-identity. Contratos compartilhados preservados. Não há novo impacto técnico ao Core. Credenciais recusadas não substituem as anteriores; retryable não prova ausência de efeito.

O conteúdo a seguir descreve capacidades mantidas e histórico anterior; não amplia a janela de atualização desta rodada.

# Instalação, atualização e recuperação — 0.19.0

Base direta: Google 0.17.0 ou WordPress limpo. Instale `wp-mcp-google-fator3-0.19.0-instalador.zip` substituindo a pasta original, sem desinstalar. Não há migração de banco, mudança de defaults, ativação de envio ou troca automática de credencial. Contratos/configurações/segredos/jobs permanecem no formato da base.

## Procedimento

1. Preserve backup coerente de arquivos, banco e material de cifra. Confira SHA-256 e slug do instalador contra o relatório externo.
2. Atualize pelo mecanismo autorizado. Na frota, verifique os bytes da URL raw publicada e use `plugins/upload` com `expected_sha256` e `expected_slug`. A existência do ZIP não prova publicação da URL. Upload-base64 é usado apenas na bancada local.
3. Em requisição nova, confira `google/readiness-status`, `google/status`, versão 0.19.0, `google/storage-status` e `google/documentation`. O índice deve apresentar `GUIA-0.19.0.md`; descarte paginação iniciada com hash anterior.
4. Confira conexão, serviços, bindings, concessão e política. A instalação preserva as escolhas existentes. Configuração por conexão, permissões de administração e confirmação de escritas continuam obrigatórias.
5. Com o Core 1.46.1 ou posterior (testado com 1.48.0), configure/verifique Google e só então selecione servidor explicitamente. `sendBound()` liga o envio ao destino aceito; não transforme `destination_mismatch` ou resultado incerto em autorização de reenvio.

Core 1.46.1 já contém a extensão de reconciliação Ads. Não há dependência nova nem alteração dos acompanhantes nesta entrega. Runtimes Core sem o método público correspondente continuam bloqueados para Ads com `core_async_unsupported`.

## Recuperação e reversão

`google/recovery {"action":"prepare"}` pausa fora do banco e verifica drenagem. Somente `ready_for_restore:true` permite avançar na restauração. Preserve a sentinela de destino `wp-content/f3-google-state` durante restauração do banco; ela não é cache nem deve ser sobrescrita por uma cópia antiga.

Após reconciliar efeitos externos e conferir banco/arquivos, consulte `google/recovery-status` e retome com `expected_generation` atual e `acknowledge_reconciled:true`. A geração invalida caches e contextos anteriores. Escritas interrompidas permanecem desconhecidas até reconciliação explícita.

Rollback MCP conserva pré-imagem de arquivos; `dry_run` confere prontidão. Restaurar arquivos não restaura banco, credenciais, configuração ou efeitos nas APIs. Voltar à 0.17.0 remove `google/readiness-status` e volta a escolher a conexão GA4 pelo ID de medição: com duas conexões de entrega habilitadas o GA4 fica `ambiguous_connection` até que só uma permaneça habilitada. Voltar à 0.16 remove também os diagnósticos e a repetição automática da primeira validação falha. Concessões diferentes por destino deixam a concessão compartilhada zerada para que a versão anterior bloqueie o envio até nova autorização explícita. Não retome Ads legado com recibos pendentes; suspenda o transporte e reconcilie antes de reverter. Preserve referências, fila e diário Core e avalie a combinação antes de retomar. Não apague filas para remover bloqueios.

Instalação limpa cria `{prefix}f3_google_records` e `{prefix}f3_google_cron`; a atualização usa as tabelas existentes, sem replay de jobs concluídos. Ativação não substitui diagnóstico/reparação de um plugin já ativo e incompleto. Consulte o relatório externo para provas e pendências da rodada.


## Atualização 0.20.0

Pedidos 37/38: retenção 0 sem prazo e SDK ga4-reader/1.0.0. Valores explícitos da base 0.19.0 permanecem; manutenção protege os registros presentes quando configurada retenção ilimitada. GSC não muda. O SDK GA4 não implementa o acervo do Core. Consulte o guia 0.20.0 e SDK-PHP para concessão, cotas, limites e uso.
