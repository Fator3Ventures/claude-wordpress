# Coleta, calendário e exportação — 0.12.0

## Coleta

`google/query` mantém `collection.mode:page` como padrão. GA4 e Search Console aceitam `complete`; a coleta avança enquanto houver orçamento. `calendar` também seleciona esse percurso. Google Ads continua com as operações existentes; não recebe coleta completa nesta release.

```json
{"connector":"ga4","accounts":["properties/123"],"metrics":["activeUsers","sessions"],"dimensions":["country"],"date_range":{"from":"2026-09-01","to":"2026-09-30"},"collection":{"mode":"complete","page_size":1000,"pages_per_pass":5}}
```

| Limite | Padrão | Faixa |
|---|---|---|
| `page_size` | `limit`, ou limite configurado | 1–25.000; também limitado por `max_rows` da configuração |
| `max_rows` | 50.000 | 1–100.000 linhas nativas |
| `max_bytes` | 8 MiB | 1 KiB–8 MiB, estado serializado e limite de resposta HTTP |
| `max_pages` | 100 | 1–500, incluindo tentativas registradas |
| `pages_per_pass` | 10 | 1–50 |
| `seconds_per_pass` | 20 | 3–20, cooperativo com o orçamento HTTP |
| Recortes | — | até 200 combinações de conta/período/intervalo |
| Cursor síncrono | 1 hora | expiração fixa, sem prolongamento por retomada |

O cursor é aleatório e opaco; reenvie a consulta original com `collection.cursor`. Ele é vinculado ao ator, identidade MCP quando presente, conexão Google, revisão de configuração/política e hash do plano. O plano congela contas e datas relativas. Alterar a consulta, revogar a concessão ou perder acesso ao recurso impede retomar e consultar o conteúdo. O limite de bytes pode impedir até a criação de um plano muito pequeno; esse estado não avança páginas. Limites totais de linhas/páginas/bytes encerram o plano como incompleto; para limites maiores crie outra consulta. Limites por passagem/tempo ou falha temporária permitem continuação.

Cada checkpoint confirma linhas e próximo offset juntos. O job de consulta usa o registro durável com a mesma identidade e trava; não duplica uma página já confirmada após interrupção. Use explicitamente `google/create-job` com `task:query` para execução durável. Resultados finais usam a retenção/paginação dos jobs existentes; o checkpoint intermediário não aparece como resultado completo. Jobs criados por identidade WordPress independente continuam sem MCP. Jobs vinculados a uma concessão MCP exigem revalidá-la, inclusive após inativação do produtor; não recebem permissões implícitas.

## Cobertura e qualidade

`collection.complete:true` significa fim do plano sobre as linhas disponibilizadas pela API, sem corte local nem recorte com falha. `coverage` mantém todos os recortes, inclusive pendentes ou reprovados. `success:true` pode coexistir com coleta parcial quando há dados utilizáveis: confira os dois campos.

GSC usa contagem nativa antes dos filtros locais; uma página cheia filtrada até zero linhas não encerra a origem. GA4 usa offset e rowCount; mudanças no total e nos metadados entre páginas são registradas. A ordenação só é global ao conjunto coletado quando a coleta termina. Não há snapshot remoto transacional.

`quality.pages` preserva metadados, fuso, moeda, API, horário e contexto por página. Omissão de amostragem, limiar ou perda de detalhe significa desconhecido; `*_known:false` não significa ausência do fenômeno. Moeda e fuso não são copiados de uma propriedade para outra. `requested_data_state` GSC distingue a seleção solicitada de um `data_state` não retornado pela API. `all_rows_guaranteed:false` no Search Console permanece mesmo após a última página: a origem limita a disponibilidade de linhas. Dias omitidos não são preenchidos com zeros.

## Calendário

```json
{"connector":"ga4","accounts":["properties/123"],"metrics":["activeUsers","sessions"],"dimensions":[],"date_range":{"from":"2026-09-29","to":"2026-10-12"},"calendar":{"period":"month","partial_periods":"include"},"collection":{"mode":"complete"}}
```

`period` aceita `iso_week`, `month`, `quarter` ou `year`. `partial_periods` aceita `include` (padrão), `exclude` ou `reject`. Nenhuma opção amplia as datas solicitadas. Semana ISO respeita seu ano ISO; datas são intervalos civis consultados na origem. O fuso efetivo retornado pelo GA4 ou America/Los_Angeles do GSC acompanha a evidência. Presets relativos são resolvidos uma vez pelo fuso WordPress antes de congelar o plano.

As colunas `calendar_period`, `period_start` e `period_end` identificam cada intervalo. Dimensões temporais são recusadas nesse modo, para não confundir linhas diárias com agregados do período. Usuários e sessões vêm de uma consulta nativa por intervalo; não são somados a partir dos dias. No GSC, CTR é cliques/impressões do agregado, preservando zero nativo com denominador zero; sem prova suficiente retorna null. Posição permanece o agregado nativo. Não há total de moedas ou de usuários entre propriedades.

## Exportação

`google/export-to-sheet` adota `completeness_policy:require_complete`. Todas as fontes são extraídas antes de qualquer escrita; uma aba/fonte incompleta impede criar planilha, alterar abas, gravar ou compartilhar. Para exportação parcial intencional use `allow_partial`. Permanecem os limites de 500.000 células e 8 MiB por exportação, sem truncamento silencioso. A API de leitura das fontes pode ter sido consultada antes da recusa.

Os recibos separam `extraction_complete` e `extraction` de `operation_outcome` e `verification`. Em `replace`, a releitura compara o retângulo exportado em blocos de até 10.000 células/1.000 linhas. Não certifica células externas ao retângulo, fórmulas recalculadas ou outras alterações concorrentes. A amostra de auditoria de 50 linhas permanece distinta. Falha na releitura não desfaz uma escrita confirmada nem autoriza repeti-la.

`append` exige preparação/confirmação. Repetir a mesma confirmação concluída retorna o recibo salvo, sem duplicar linhas. Resultado desconhecido não é reenviado automaticamente. Como `appendCells` não devolve o intervalo inserido, a verificação desse modo declara `complete:false` e `scope:api_acknowledgement_only`; o recibo não inventa releitura integral. O fluxo completo de criação, escrita e compartilhamento não é transacional.

Jobs/agendas antigos que omitam a política passam a exigir completude no código atual. Não há regravação automática desses registros nem reaplicação de confirmações antigas. Para alterar a política, reconfigure explicitamente a intenção.

Referências de contrato: [GA4 runReport](https://developers.google.com/analytics/devguides/reporting/data/v1/rest/v1beta/properties/runReport) e [Search Analytics query](https://developers.google.com/webmaster-tools/v1/searchanalytics/query). Não houve homologação em conta Google real nesta entrega.


## Atualização 0.20.0

Pedidos 37/38: retenção 0 sem prazo e SDK ga4-reader/1.0.0. Valores explícitos da base 0.19.0 permanecem; manutenção protege os registros presentes quando configurada retenção ilimitada. GSC não muda. O SDK GA4 não implementa o acervo do Core. Consulte o guia 0.20.0 e SDK-PHP para concessão, cotas, limites e uso.
