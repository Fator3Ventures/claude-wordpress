# Plano de implementação — Fator3 MCP Google 0.11.0

Revisão 1 · 16/10/2026 · Diretrizes comuns: ambas revisão 4, lidas integralmente.

Base: Google 0.10.0 instalado na frota conforme pedido recebido e confirmado no Site-Teste. SHA-256 do instalador: 3e30634b1d1f87b9b4fdeba2a37ac382b1394a1ec7f7235166aa15d107ef8b52. Alvo: 0.11.0, incremento minor. Nenhum salto histórico adicional.

1. Pedido MCP Google 25: cabeçalho, composer e manuais declararão exatamente WP 7.1.2/PHP 8.3.6; instalação limpa e atualização direta serão exercitadas nessa combinação. Tabela de identidade externa usará somente nomes finais, bytes e hashes.
2. Atualizar documentação corrente, mantendo notas e evidências históricas identificadas. Manter 282 operações e os contratos atuais.
3. Validar os contratos recebidos: MCP 0.23.0, Core 1.35.0, Meta/LinkedIn 0.2.0. Reusar testes funcionais pertinentes de paginação, ajuda, permissões, isolamento e SDK.
4. Pedido Core 222: manter SDK fechado 1.0.0; proposta de contrato adicional de conversões por finalidade em impacto próprio, antes de implementar qualquer consumo novo. Material não será inferido a partir de contato.
5. Gerar fonte, instalador e relatório próprios; atualizar somente os impactos Core e MCP. Os impactos sociais recebidos não exigem alteração e não justificam novos avisos sem ação. Implantador atual indisponível: não avaliado.

Aceites: requisitos exatos executados; primeiro status sem manutenção; atualização preserva opções/cifra/registros/pausas; ajuda integral por MCP com hashes e nova versão; consumidor Core compatível; tipos MCP preservados; árvores fonte/ZIP/instalação idênticas; relatório sem paths na identidade; nenhum segredo no pacote.

Limites: contas/API Google reais, publicação raw e implantação da candidata na frota são etapas separadas. A rodada não altera outro plugin. Totais de testes desta rodada serão apurados, sem reutilizar os totais históricos como prova nova.
