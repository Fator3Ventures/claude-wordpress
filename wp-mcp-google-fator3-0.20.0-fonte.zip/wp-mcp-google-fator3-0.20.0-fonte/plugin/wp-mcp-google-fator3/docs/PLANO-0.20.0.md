# Plano — Google 0.20.0

27/10/2026. Base direta: 0.19.0. Norma revisão 5.

Pedidos 37 e 38: retenção ilimitada (0) por padrão para auditoria/detalhes/resumos; preservar configurações explícitas e registros existentes. Resumo 0 equivale a infinito; detalhe 0 exige resumo 0. Manutenção consulta a política vigente inclusive para registros com expiração antiga.

Leitor `ga4-reader/1.0.0`, registrado no hook público existente, com cliente independente do Search Console, concessão administrativa por conexão/propriedade, revisão, revogação, runReport paginado, filtros, metadados e observação de cotas por propriedade. Uma chamada por página, sem retry. Dados do relatório não são persistidos. Acervo pertence ao consumidor.

Encaminhamento técnico prévio: `wp-mcp-google-fator3-0.20.0-impacto-base-site-core-fator3.md`. Core 1.56.0 não oferece coletor GA4; a entrega do SDK não comprova o acervo Core 313. Implementar a interface agora, com exemplo pronto e testes próprios, sem aguardar retorno do Core.

Acompanhantes examinados: Core 1.56.0, MCP 0.33.0, Meta 0.12.0, LinkedIn 0.10.1, Pipedrive 0.1.0. Repetir testes unitários e nativos limpos/upgrade direto/isolado; conferir catálogo, documentação e preservação GSC. Site-Teste autorizado para instalar candidato e comprovar retenção. Credencial ausente observada; homologação GA4 real dependerá de propriedade autorizada e consumidor real. Não interpretar fixtures como homologação Google.
