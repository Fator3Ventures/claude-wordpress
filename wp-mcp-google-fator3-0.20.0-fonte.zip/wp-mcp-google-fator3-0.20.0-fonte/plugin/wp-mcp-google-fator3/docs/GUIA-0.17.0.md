> Atualização 0.17.0: pedidos 33–35. Para entrega pelo servidor, renovação automática e Data Manager, prevalece [o contrato atual](CONVERSION-DELIVERY-CORE-140.md).

# Guia — Fator3 MCP Google 0.17.0

Instale `wp-mcp-google-fator3-0.17.0-instalador.zip` diretamente sobre a 0.16.0, sem desinstalar, ou em WordPress limpo. Mínimos declarados: WordPress 7.1.2 e PHP 8.3.6. Preserve backup dos arquivos, banco e material de cifra. O fonte não é instalável.

## Conversões com Core 1.46.1

Leia [conversões servidor](CONVERSION-DELIVERY-CORE-140.md). O Google implementa `sendBound(payload, destinationRef)` para conferir o destino registrado no aceite. Core 1.41 exige esse método; Core 1.40 pode continuar usando `send()`. A atualização não instala Core, não habilita servidor e não regrava referências de conversões anteriores.

Em Ferramentas → Fator3 MCP Google → Conversões, selecione a conexão, configure destino/segredo e execute a verificação explícita. A autorização vale 24 horas e é revogada por mudanças de identidade, concessão ou política. `destination_mismatch` significa que o destino mudou antes de um envio; investigue a configuração e o diário Core. Não altere a referência histórica para forçar envio. Resultados incertos exigem reconciliação.

GA4/Ads reais, sessão original e ausência de duplicação no navegador exigem homologação em ativos autorizados. Recebimento HTTP não prova atribuição analítica.

## Operação preservada

Analytics, Ads, GSC, GTM, Site Verification, Sheets e Drive mantêm suas habilidades e permissões. Configuração 4.0.0; execução, armazenamento e manutenção 2.0.0; contrato de entrega Core 1.0.0. A extensão PHP não acrescenta campos incompatíveis ao contrato.

Consulte [guia para agentes](AGENT-GUIDE.md), [contratos públicos](CONTRATOS-PUBLICOS.md), [SDK PHP](SDK-PHP.md), [recuperação](MIGRACAO.md), [cron](ACOMPANHAMENTO-CRON.md) e [validação](VALIDACAO.md). Ajuda local não consulta fornecedores nem muda estado.


## Ajustes 0.17.0

Alterar Ads preserva a prova GA4, e vice-versa. Uma configuração parcial preserva campos omitidos; vazio explícito limpa o campo. Desabilitar a integração invalida ambas. As concessões são mantidas por destino, sem transferir a autorização de um destino ao editar outro.

Na verificação, o retorno `provider_error` traz apenas HTTP, estado, motivo, mensagem sanitizada e violações de campo. O incidente mostra o mesmo diagnóstico. NOT_FOUND em destination_references registra uma tentativa pendente e nova validação em 5 minutos, com espera progressiva até 1 hora. Não presume propagação como causa. Nenhuma conversão é coletada. A tentativa só continua com a mesma configuração, credencial, política e autorização. Sucesso remove a pendência e renova a prova por 24 horas.

Core 1.46.1 recebido já fornece a reconciliação assíncrona; esta entrega não modifica o Core.
