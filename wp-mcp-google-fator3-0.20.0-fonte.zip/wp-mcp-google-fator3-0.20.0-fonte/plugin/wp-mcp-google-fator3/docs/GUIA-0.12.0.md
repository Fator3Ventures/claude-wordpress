# Guia — Fator3 MCP Google 0.12.0

## Atualização

Instalar `wp-mcp-google-fator3-0.12.0-instalador.zip` em WordPress limpo ou substituir a 0.11.0 sem desinstalar. A base delimita ensaios, sem bloqueio no código por versão de origem. Ler [MIGRACAO.md](MIGRACAO.md) para instalação direta, backup, pausa/drenagem e retorno dos arquivos. Matriz desta rodada: WordPress 7.1.2, PHP 8.3.6, Core 1.38.0 + MCP 0.24.0; Meta/LinkedIn 0.3.0.

## Configuração

Em Ferramentas → Fator3 MCP Google, selecionar a conexão e o método de autenticação. **Service Account** permanece primeira opção e padrão. Importar a chave JSON, revisar a identidade candidata e ativá-la explicitamente; conceder acesso à identidade nos serviços necessários. OAuth fica em aba separada: uma identidade ativa por conexão. O plugin não cria projeto/chave sem solicitação; o script Cloud Shell revisado tem download autenticado; o original histórico acompanha o pacote-fonte.

Habilitar serviços, testar credencial e selecionar propriedade/stream/conta. IDs explícitos prevalecem; a resolução opcional do Measurement ID Core não cria propriedade nem injeta tag. Ads mantém developer token obrigatório. Credencial válida não comprova acesso a todo recurso; consultar `google/selftest` e sua cobertura, sem interpretar incompleto como aprovado integralmente.

## Operação e manutenção

O painel Operação mostra a manutenção: estado da última passagem, idade da observação, próxima execução, orçamento e progresso por família. O botão Avançar um lote usa `google/maintenance` com a autorização e nonce usuais. JSON fica recolhido e pode ser expandido e copiado pelo usuário.

`google/storage-status` e `google/status` incluem `maintenance_contract_version:2.0.0`. `complete` exige inventário integral examinado sem pendência; `pending` pede novo lote; `failed` fornece erros. Bloqueio por recuperação aparece em `blocked_by`, sem alterar a amostra histórica. `read_success:false` impede tratar o resultado como contagem conhecida. Consultas não limpam nem migram o histórico.

Uma passagem automática compartilha 100 unidades/1.000 ms entre retenção cron e cache; o limite é cooperativo. Muitas conexões, inclusive removidas, avançam por cursor. Cache SQL obsoleto não prevalece sobre cache externo mais novo; entradas vencidas/sem validade conhecida são descartáveis. Saúde do cache e erros não exibem payloads ou segredos.

O resultado do trabalho remoto, a gravação do histórico e o resultado da manutenção são independentes. Não repetir uma escrita Google porque a limpeza falhou. `ultima_cli`, `ultima_http` e `ultima_manual` permanecem separados. Ler [ACOMPANHAMENTO-CRON.md](ACOMPANHAMENTO-CRON.md).

## Contratos e limites

283 habilidades (110 leituras/173 escritas), 34 opções, configuração 4.0.0, execução 2.0.0/catálogo 3.0.0 e leitor PHP `search-console-reader/1.0.0`. `google/maintenance` substitui a entrada histórica; as rotas de migração/transição foram removidas, sem aliases. Concessões SDK continuam explícitas. Core controla tags, consentimento, coleta e commit próprios; MCP controla canal, perfis e atualização. `contexto_teste` não cria autorização nas APIs Google.

Documentos e scripts são disponibilizados pelo painel com autenticação. O instalador não contém Markdown, `docs/`, `reference/` ou `.htaccess` expostos; cada diretório tem índice silencioso. Fontes/testes ficam no ZIP fonte, fora do diretório público. Consulte [VALIDACAO.md](VALIDACAO.md) para evidências e limitações.

## Diagnóstico da 0.12.0

Ao receber `state:yielded`, a chamada cedeu a outra passagem. `success:true` confirma esse encerramento normal; `work_success:null` e zero itens indicam que ela não executou trabalho. O CLI encerra normalmente. Falhas reais continuam com erro.

`history_status:pending` preserva resultado durável para reconciliação local. `unconfirmed` indica prova insuficiente. Não reenvie uma operação Google por causa do histórico. `observability_error:null` com `last_observability_error.resolved_at` significa recuperação confirmada daquela identidade; confira também cobertura e manutenção.

Em `cron.scheduling`, compare operação, gancho, origem e timestamp ao aviso WordPress. `confirmed` preserva o aviso original, `failed` indica pós-condição ausente e `unconfirmed` indica falta de prova. A remoção exige ausência da ocorrência antiga. Leia o roteiro [ACOMPANHAMENTO-CRON.md](ACOMPANHAMENTO-CRON.md) antes de classificar uma linha como inofensiva.

Core 1.33.0 mantém publicidade e medição independentes. Atualizar Google não altera essa política, tags ou consentimento. Inclua a tabela Core `f3base_slack_manutencao` e as opções no backup conjunto; preserve a guarda ativa pelo protocolo de recuperação. Nenhuma mensagem Slack é reenviada pelo Google.

## Antes de mudar serviços

No painel, **Ver prévia** mostra o antes/depois. Salvar uma redução abre uma revisão com botão **Confirmar alterações e reduções**; cancelar preserva a configuração. Uma tela antiga é recusada se a revisão mudou. Service Account permanece padrão e OAuth em aba separada.

Para um agente acrescentar GTM preservando os demais serviços:

```json
{"services":{"gtm":"write"},"merge":true,"dry_run":true}
```

Aplique o mesmo pedido com `dry_run:false` e `expected_revision` da prévia. Se a alteração reduzir serviços, inclua também `expected_plan_hash` e `confirm_service_reduction:true` após revisar o diff. A forma sem merge substitui a seleção completa. Consulte [CONTRACTS](../CONTRACTS.md) para a semântica de omissão, vazio e herança.

No diagnóstico de cron, `checks.executor.state` é a prova atual. `health:degraded` com `work_health:idle` significa defeito na agenda/observabilidade mesmo sem trabalho local. A manutenção não corrige eventos MCP/Core. Consulte o subresultado de reparação antes de concluir que a agenda está pronta.

A instalação e ativação não são bloqueadas por versões dos acompanhantes. Ausência de capacidade afeta somente a operação dependente. As tabelas atuais da 0.11.0 são usadas diretamente; não há migração de versões anteriores.

## Coleta e integração pública

Para coletar todas as páginas disponibilizadas, use `collection:{"mode":"complete"}` em `google/query`. Leia `collection.complete`, `coverage` e `quality` antes de usar os dados; envie o cursor com a mesma consulta para continuar. Para execução durável, crie explicitamente um job de consulta. Nenhuma consulta de status cria trabalho.

Use `calendar:{"period":"month","partial_periods":"include"}` para intervalos mensais agregados pelo Google. A consulta não soma usuários únicos diários. Veja [ANALYTICS.md](ANALYTICS.md) para os limites e exemplos.

Exportação exige extração completa por padrão. Para um recorte parcial intencional, declare `completeness_policy:"allow_partial"`. A confirmação do Google Sheets não comprova extração completa nem releitura integral. Um append já confirmado retorna seu recibo ao repetir a mesma confirmação, sem reenviar linhas. Resultados desconhecidos exigem conferência do destino.

Os adaptadores usam os [contratos públicos](CONTRATOS-PUBLICOS.md) Core/MCP. As versões 0.8.5, MCP 0.21.1 e Core 1.32.0 não integram o percurso de instalação. Atualize diretamente as bases informadas. A ordem e as limitações observadas estão no relatório de entrega; ausência de capacidades afeta a operação correspondente, não a ativação do Google.

## Conversões e booleanos na 0.12.0

Leia [CONVERSOES.md](CONVERSOES.md) para a nova operação administrativa local, a consistência do diagnóstico GTM e a correção dos booleanos do Pedido MCP Google 26.
