# Guia — Google 0.20.0

Atualização direta 0.19.0, sem desinstalar. Preserve banco e salts antes da troca; rollback de arquivos não desfaz efeitos remotos nem restaura dados já apagados anteriormente.

Comece por `google/readiness-status`: mostra bloqueios locais sem chamar o fornecedor. Recursos GA4 usam propriedade/stream configurados; descrições e orientação da interface são em português.

## Retenção

Leia `google/integration-status` com `compact:true` para a revisão atual. Execute `google/configure-local` com `expected_revision` e `audit_retention:0`, `job_detail_days:0`, `job_summary_days:0`. Zero significa ilimitado. Valores omitidos permanecem. Confirme em `google/configuration-schema` com `contract_version:4.0.0` e `include_values:true`. A revisão pode mudar: releia antes de nova escrita.

O padrão de instalação limpa é ilimitado. A atualização preserva valores explícitos anteriores (inclusive 365/730 configurados pela frota). Registros eliminados em versões anteriores não são recuperáveis pelo upgrade. Auditoria é limite de eventos quando positivo; tarefas usam dias. Resumo zero é infinito; resumo positivo precisa ser maior ou igual ao detalhe positivo. Detalhe zero exige resumo zero. A manutenção consulta a política vigente e protege também expirações antigas; exclusão administrativa explícita continua possível.

## Leitura GA4 por plugin

O plugin consumidor registra `ga4-reader/1.0.0` no hook público. O administrador concede `google/configure-consumer` com `contract:ga4-reader/1.0.0`, `consumer_id`, `property:properties/123`, `enabled:true` e revisão. A conexão é a selecionada. Revogue com `enabled:false`, mesma propriedade e revisão nova. Um consumidor tem uma concessão habilitada em uma conexão por contrato; transfira revogando a anterior. GSC mantém sua concessão separada e o contrato padrão anterior.

O cliente PHP usa `query`, `status`, `effective_status`. Toda consulta exige propriedade e revisão atuais do consumidor, datas ISO explícitas (até 366 dias por recorte), listas de nomes de dimensões e métricas, origem, orçamento e identificador de execução. Limite de página até min(5000, max_rows). Filtros usam FilterExpression em camelCase. O cursor vincula todo o recorte, concessão e revisões, expira em 24h e não representa snapshot Google. O SDK não oferece escrita nem armazenamento das linhas.

Metadados Google são preservados: amostragem, cardinalidade/(other), restrições, fuso, moeda e motivos de truncamento. `estimated_unfinalized_dates` é uma heurística para hoje e os dois dias anteriores no fuso retornado, não uma confirmação do fornecedor. Fuso ausente/inválido gera null; dados antigos também podem mudar. Nunca inferir finalização definitiva.

`quota.property_quota` informa consumed/remaining observados. Consultas locais de consumidores são serializadas por propriedade, com reserva persistida por 30s. Cota esgotada recusa antes do HTTP até o prazo conservador indicado. HTTP 429 sem saldo não inventa tokens: mantém observação anterior e marca indisponível, com espera de pelo menos uma hora (ou Retry-After maior). Outras falhas geram espera de 30s. Consumidores externos e ga/run-report podem consumir a mesma cota; o saldo local é uma observação, não reserva global Google. Não há retry automático.

O Core atual não registra esse contrato: a concessão será possível quando seu coletor for implementado. Não usar um consumidor fictício para marcar homologação do Core como concluída. O SDK permite revisão e implementação imediata pelo mantenedor do Core, sem necessidade de alterar credenciais ou opções privadas do Google.

Documentação: [SDK](SDK-PHP.md), [retenção e atualização](MIGRACAO.md), [Analytics](ANALYTICS.md). Credenciais e políticas continuam na tela Ferramentas → Fator3 MCP Google; ausência de credencial impede chamadas reais, não a configuração local de retenção.
