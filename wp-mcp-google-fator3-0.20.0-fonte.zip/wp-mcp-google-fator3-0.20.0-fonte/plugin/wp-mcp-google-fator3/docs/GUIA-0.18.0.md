> Atualização 0.18.0: melhorias M1–M6 por ordem do dono de 22/10/2026. Para entrega pelo servidor, renovação automática e Data Manager, prevalece [o contrato atual](CONVERSION-DELIVERY-CORE-140.md).

# Guia — Fator3 MCP Google 0.18.0

Instale `wp-mcp-google-fator3-0.18.0-instalador.zip` diretamente sobre a 0.17.0, sem desinstalar, ou em WordPress limpo. Mínimos declarados: WordPress 7.1.2 e PHP 8.3.6. Preserve backup dos arquivos, banco e material de cifra. O fonte não é instalável. Não há migração de banco, opção nova nem mudança de padrão.

## Prontidão em uma chamada (`google/readiness-status`)

Antes de diagnosticar por partes, chame `google/readiness-status` com `{}`. A resposta tem `contract: "google-readiness/1.0.0"`, `state` (`ready`, `attention` ou `blocked`), `checks` e `actions`.

| Verificação (`id`) | `blocked` quando | `attention` quando |
|---|---|---|
| `credential` | a credencial da conexão não é legível | — |
| `storage` | as tabelas atuais não respondem | — |
| `recovery` | a recuperação está pausada ou ilegível | — |
| `executor` | — | agenda ausente/inválida, nenhuma passagem registrada ou última passagem há mais de 1 hora |
| `conversion_ga4`, `conversion_google_ads` | destino configurado sem prova válida (`verification_required`, `grant_revoked`, credencial, serviço, política…) | renovação atrasada mais de 1 hora (`renewal_overdue`), prova que vence dentro de `hours_ahead` sem renovação antes (`renewal_not_scheduled_before_expiry`), última renovação falhou (`renewal_failing`) ou primeira validação reagendada (`verification_pending`) |
| `incidents` | — | há incidente aberto (até 10 listados) |
| `core` | — | o contexto de medição do Site Core não pôde ser lido |

Destino sem fluxo/ação selecionado ou entrega desabilitada aparece como `not_configured` e não altera o veredito. Site Core ausente também é `not_configured`: o Google funciona sozinho. `actions` lista as ações em ordem de gravidade, sem repetição.

Parâmetro opcional: `hours_ahead` (1–48, padrão 6). A leitura não chama o Google, não repara agenda, não renova prova e não envia e-mail; `google_checks_performed` é sempre `false`. Exige o mesmo acesso administrativo das demais leituras. Também disponível em `wp mcp-google readiness --user=<administrador>` e no cartão "Prontidão operacional" do topo da aba Conversões.

Uso recomendado num acompanhamento periódico (por exemplo, a renovação GA4/Ads de um site): uma chamada por site; `ready` encerra; `attention` traz a data de vencimento e a próxima tentativa em `detail`; `blocked` traz a ação imediata em `actions[0]`.

## Seleção da conexão GA4 (correção)

O ID de medição GA4 vem do Site Core desde a 0.16.0 e é o mesmo em todas as conexões. A 0.17.0 escolhia a conexão de entrega GA4 por esse ID; com duas conexões com entrega habilitada (por exemplo, uma para GA4 e outra só para Ads), o GA4 ficava `ambiguous_connection` e o Core não enviava. Na 0.18.0 a conexão GA4 é a que tem o fluxo (`stream`) configurado; a conexão Ads continua sendo a que tem a ação de conversão. Duas conexões com fluxo continuam ambíguas e bloqueadas, de propósito.

## Descrições em português

As 106 habilidades `gtm/*` geradas do documento Discovery do Tag Manager publicam descrição revisada em português (catálogo `labels-pt-br.json`, seção `descriptions`). Identificadores, schemas de entrada e efeitos não mudaram. Os parâmetros `ability` e `parameters` de `google/mcp-read` e `google/mcp-write` (ferramentas `google-mcp-read`/`google-mcp-write` na lista do MCP) passam a ter descrição em português; tipos e obrigatoriedade iguais. As descrições dos campos dentro dos schemas gerados do Discovery continuam as do Google, em inglês.

## Leitura de estado mais leve

`google/conversion-delivery-status`, `google/status`, `google/readiness-status` e a aba Conversões leem a fotografia de medição do Site Core uma vez por chamada. Entrega e verificação continuam lendo o Core de novo dentro das próprias cercas, imediatamente antes de cada HTTP.

## Schemas de saída completos

O schema de saída de `google/status` e das três habilidades de conversões passa a documentar campos que já eram devolvidos: `message`, `ads_eligibility_source`, `verification_pending`, as duas formas de `core_transport` e `cron.work_observation`. Nenhum campo foi removido ou renomeado.

## Executor

A reconciliação do diário do executor aceita passagens antigas gravadas sem `connection_id`, atribuindo a conexão de onde a linha foi lida. A medição de cobertura trata uma resposta inesperada de `SHOW CREATE TABLE` como cobertura desconhecida, em vez de supor sequência 1. O comportamento das agendas, a recuperação e o formato do diário não mudaram.

## Operação preservada

Analytics, Ads, GSC, GTM, Site Verification, Sheets e Drive mantêm suas habilidades e permissões. Configuração 4.0.0; execução, armazenamento e manutenção 2.0.0; catálogo 3.0.0; contrato de entrega Core `site-conversion-delivery/1.0.0`. Consulte [guia para agentes](AGENT-GUIDE.md), [contratos públicos](CONTRATOS-PUBLICOS.md), [SDK PHP](SDK-PHP.md), [recuperação](MIGRACAO.md), [cron](ACOMPANHAMENTO-CRON.md) e [validação](VALIDACAO.md). Ajuda local não consulta fornecedores nem muda estado.
