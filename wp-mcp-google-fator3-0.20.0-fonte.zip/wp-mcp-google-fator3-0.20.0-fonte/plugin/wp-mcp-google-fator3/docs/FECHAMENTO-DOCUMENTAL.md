# Google 0.20.0

Base 0.19.0; pedidos 37 e 38. Resultados finais e limites ficam no relatório externo da rodada e nas evidências 020. Evidências 019 e anteriores são históricas e não representam testes da candidata atual.
