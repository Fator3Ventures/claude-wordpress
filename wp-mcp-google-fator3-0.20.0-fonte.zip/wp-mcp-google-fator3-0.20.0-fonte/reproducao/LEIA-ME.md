# Reprodução — Google 0.20.0

Base direta 0.19.0. Runtime de 163 arquivos igual ao instalador separado. Evidências desta rodada em plugin/wp-mcp-google-fator3/evidence/020; diretórios 019 e anteriores são históricos. Nenhum ZIP é aninhado.

## Ambiente e insumos

Linux amd64, Python 3, PHP 8.3.6, MySQL 8.0.46; os 30 pacotes oficiais estão fixados por hash em runtime-dependencies.json. Execute python3 download-runtime.py /diretorio/novo/runtime. Não instala serviços do sistema. O fallback security.ubuntu.com conserva o pacote e o hash, usado quando archive.ubuntu.com retorna 503. O laboratório cria php.ini e usa LD_LIBRARY_PATH e módulos locais; para PHPUnit, crie wrapper equivalente conforme tools/lab.py.

WordPress 7.1.2 e 7.1.3 (tar.gz oficiais), WP-CLI 2.12.0 e Composer com composer.lock entregue (PHPUnit 9.6.37). Instalar dependências com composer install; npm ci --prefix reproducao/jsdom a partir da raiz do fonte (jsdom 27.4.0). Não atualize locks silenciosamente.

Instaladores: Google base 0.19.0, candidato 0.20.0, Core 1.56.0, MCP 0.33.0, Meta 0.12.0, LinkedIn 0.10.1. Pipedrive 0.1.0 foi conferido pelo pacote e inventário remoto; não foi ativado no PHP 8.3.6 do laboratório, inferior ao mínimo próprio 8.3.36. Site-Teste observado usa 8.3.36.

## Executar

1. Em plugin/wp-mcp-google-fator3: php vendor/bin/phpunit --log-junit /novo/evidence/unit-junit.xml. Resultado desta rodada: 1.199 testes / 14.529 asserções.
2. Exportar contratos: php build/export-contracts.php; python3 build/compile-documents.py; python3 build/check-docs.py.
3. Gerar candidato: python3 build/build.py candidate --output /candidatos/google020.zip. Hash da entrega está no relatório externo e validation020.json.
4. Usar reproducao/mkmanifest.py para criar min.json (WP7.1.2) e current.json (WP7.1.3). Chaves: runtime, wordpress, candidate, baseline, mcp, core, baseline_mcp, baseline_core, meta, linkedin, wp_cli. Baseline Google 0.19.0; baseline_mcp e baseline_core são os mesmos acompanhantes atuais. Cada arquivo precisa do caminho real e versão; o gerador calcula hashes, que devem ser comparados às evidências.
5. Exportar NODE_PATH para reproducao/jsdom/node_modules. Em plugin/wp-mcp-google-fator3: python3 tools/release020.py --manifest /min.json --manifest-current /current.json --manifest-upgrade /current.json --work-base /novo/labs --evidence /novo/evidence --php /php-wrapper.
6. O gate executa clean, clean-713, upgrade, google-first e isolated; confirma bytes do candidato, lint, contratos, docs e ambiente encerrado. --only permite uma execução parcial identificada; não declarar os casos omitidos como executados. Atualização usa MCP HTTP autenticado, rollback e reaplicação. O teste DOM pressupõe a fixture delivery017, incluída na lista do gate.

Fixtures de fornecedor são sintéticas e toda saída externa/e-mail é bloqueada. Respostas do laboratório não homologam credencial nem acervo Core. O arquivo site-teste020.json contém a prova remota de instalação/retenção; não inclui credenciais. O Site-Teste não possui jobs, por isso a preservação de resultados antigos expirados é provada com registros semeados no laboratório. O baseline de schemas foi capturado com Google 0.19.0 + MCP 0.33.0 em tests/fixtures/contracts0190-mcp033.json, evitando confundir decoração MCP com mudança Google.

## Execuções preliminares

O primeiro harness recebeu corpo de token como array; foi corrigido para tratar formulário e JSON. A asserção de 429 passou a admitir os segundos decorridos entre observação e retorno. O DOM exigia a fixture de incidente delivery017, agora explícita. Relatórios recebidos, com links externos antigos, ficam em inputs/020 e não no conjunto de documentação compilada. Duas regressões antigas configuram explicitamente auditoria finita para continuar testando limpeza, porque o padrão mudou para ilimitado. Essas tentativas não contam como provas aprovadas.
