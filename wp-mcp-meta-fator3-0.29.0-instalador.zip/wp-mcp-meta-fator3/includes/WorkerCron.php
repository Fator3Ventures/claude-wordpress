<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** WP Activity Log 5.7.0 observes the native pre-filters but returns null.
 * Keep an upstream decision for our single worker, without replacing the cron
 * store, disabling the sensor, or changing the registration keys or priority. */
final class WorkerCron {
    private const SENSOR = 'WSAL\\WP_Sensors\\WP_System_Sensor';

    public static function listen(): void {
        add_filter('pre_schedule_event', [self::class,'beforeSchedule'], PHP_INT_MIN, 2);
        add_filter('pre_unschedule_event', [self::class,'beforeRemoval'], PHP_INT_MIN, 4);
    }
    private static function worker($hook,$args): bool {
        return $hook === Config::KEY.'_worker' && $args === [];
    }
    private static function ownsCall(string $filter,array $args): bool {
        return $filter === 'pre_schedule_event'
            ? (($args[1]->schedule ?? null) === false && self::worker($args[1]->hook ?? null,$args[1]->args ?? null))
            : self::worker($args[2] ?? null,$args[3] ?? null);
    }
    public static function beforeSchedule($pre,$event) {
        if (($event->schedule ?? null) === false && self::worker($event->hook ?? null,$event->args ?? null)) self::protect('pre_schedule_event');
        return $pre;
    }
    public static function beforeRemoval($pre,$timestamp,$hook,$args) {
        if (self::worker($hook,$args)) self::protect('pre_unschedule_event');
        return $pre;
    }
    private static function protect(string $filter): void {
        global $wp_filter;
        if (!class_exists(self::SENSOR,false)) return;
        $chain=$wp_filter[$filter] ?? null;
        if (!$chain instanceof \WP_Hook) return;
        foreach ($chain->callbacks[PHP_INT_MAX] ?? [] as $id=>$entry) {
            $fn=$entry['function'];
            // The named removal observer already returns $pre. Only the anonymous
            // observers defined by the system sensor fail to forward a verdict.
            if (!$fn instanceof \Closure || (new \ReflectionFunction($fn))->getClosureScopeClass()?->getName() !== self::SENSOR) continue;
            // The original observer still sees the original arguments. On other
            // hooks, or when it supplies a result itself, forward it unchanged.
            $chain->callbacks[PHP_INT_MAX][$id]['function']=static function (...$args) use ($fn,$filter) {
                $result=$fn(...$args);
                if ($result !== null || ($args[0] ?? null) === null || !self::ownsCall($filter,$args)) return $result;
                if ($args[0] === true && $filter === 'pre_unschedule_event'
                    && wp_get_scheduled_event($args[2],$args[3],$args[1])) {
                    return new \WP_Error('could_not_set','A ocorrência do worker continua presente após a tentativa de remoção.');
                }
                return $args[0];
            };
        }
    }
}
