<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Durable work belongs to this installation. Transport snapshots are audit data. */
final class SiteOwner {
    public static function executor(array $origin,bool $notify=false): array {
        $id=(int)($origin['user_id']??0);
        if(!$id || !user_can($id,'manage_options')){
            $replacement=0;
            foreach(get_users(['blog_id'=>get_current_blog_id(),'capability'=>'manage_options','fields'=>'ID','orderby'=>'ID','order'=>'ASC']) as $candidate){
                if(user_can((int)$candidate,'manage_options')){$replacement=(int)$candidate;break;}
            }
            if(!$replacement)throw new Fault('not_authorized','O site precisa de um administrador com manage_options.');
            if($notify)Store::lock('owner-replacements',static function()use($id,$replacement){
                $owners=(array)get_option('f3_meta_owner_replacements',[]);
                if(($owners[$id]??null)!==$replacement){$owners[$id]=$replacement;update_option('f3_meta_owner_replacements',$owners,false);}
            });
            $id=$replacement;
        }
        return ['user_id'=>$id,'channel'=>null];
    }
    public static function reader(array $q): array {
        $p=ConsumerGrants::administrator();
        Access::storedQuery($p,$q);
        return $p;
    }
    public static function localFailure(array $v): bool {
        return in_array($v['last_code']??'',['not_authorized','grant_revoked','authorization_revoked'],true)
            && empty($v['last_error']['auth_scope']) && empty($v['last_error']['http_status']);
    }
    /** Resume only stopped authorization work. Never discard cursors, pages or durable results. */
    public static function migrate(): void {
        if((int)Util::boot('f3_meta_site_owner_031',0)===1)return;
        Store::lock('site-owner-migration',static function(){
            $after=(string)get_option('f3_meta_owner_after','');
            global $wpdb;
            $ids=$wpdb->get_col($wpdb->prepare("SELECT record_key FROM %i WHERE bucket='job' AND queue_state='paused' AND record_key>%s ORDER BY record_key LIMIT 100",Store::table(),$after));
            if($wpdb->last_error)throw new Fault('storage_unavailable','Migração de coletas indisponível.');
            foreach($ids as $id)Store::lock('job:'.$id,static function()use($id){
                try{$r=Store::get('job',$id);}catch(Fault $e){
                    if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;
                    Queue::isolate($id);return;
                }
                if(!$r)return;$v=$r['value'];
                if($v['status']!=='paused'||!empty($v['manual_pause'])||!self::localFailure($v))return;
                $v['status']='queued';$v['next_at']=time();$v['attempts']=0;
                Store::put('job',$id,$v,$r['revision'],$r['expires_at']);
            });
            if($after==='')Store::lock('schedules',static function(){
                foreach(Store::list('schedule',0,100) as $r){$v=$r['value'];
                    if(empty($v['enabled'])||!self::localFailure($v))continue;
                    $job=!empty($v['last_job'])?Store::get('job',$v['last_job']):null;
                    if($job && in_array($job['value']['status'],['paused','queued','retry'],true) && self::localFailure($job['value']))continue;
                    $v['next_at']=min(time(),$v['next_at']);Schedules::checkpoint($r,$v);
                }
            });
            $msgAfter=(string)get_option('f3_meta_owner_messages_after','');
            if($msgAfter!=='!'){
                $settings=Store::scan('messaging_config',$msgAfter,50);
                foreach($settings as $row){
                    $v=$row['value'];$args=[$v['connection_id'],$v['account_id']];
                    if(!empty($v['enabled'])&&!empty($v['contacts_enabled'])&&!wp_next_scheduled(Config::KEY.'_messages',$args)){
                        $queued=wp_schedule_single_event(time()+5,Config::KEY.'_messages',$args,true);
                        if($queued!==true&&!wp_next_scheduled(Config::KEY.'_messages',$args))throw new Fault('schedule_unconfirmed','Retomada das conversas não agendada.');
                    }
                }
                $msgAfter=count($settings)===50?end($settings)['key']:'!';
                update_option('f3_meta_owner_messages_after',$msgAfter,false);
            }
            if(count($ids)===100 || $msgAfter!=='!'){if($ids)update_option('f3_meta_owner_after',end($ids),false);Jobs::scheduleTick(5);}
            else{update_option('f3_meta_site_owner_031',1,true);delete_option('f3_meta_owner_after');delete_option('f3_meta_owner_messages_after');}
            Worker::ensure(5);
        });
    }
}
