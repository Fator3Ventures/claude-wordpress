<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

final class Worker {
    private const AUTH_CODES=['not_authorized','grant_revoked','credential_revoked','authorization_revoked','revision_conflict','credential_revalidation_required','token_expired','token_rejected','not_configured','connection_paused'];
    public static function ensure(int $delay=60): bool {
        if(Schedules::active()||Queue::waiting())return Jobs::scheduleTick($delay);
        return true;
    }
    /** Runs on plugins_loaded: no SQL once the migration is confirmed complete under schema 2. */
    public static function bootstrap(): void {
        if(Queue::settled())return;
        if(Queue::pending()){Result::run(static fn()=>Queue::migrate());self::ensure();}else Queue::markSettled();
    }
    public static function maintenance(): void {
        // Recovery must precede retention, whose failure cannot break the chain.
        Result::run(static fn()=>['scheduled'=>self::ensure()]);
        try{Result::run(static fn()=>Queue::migrate());$prune=Result::run(static fn()=>['removed'=>Store::prune()]);}
        finally{$final=Result::run(static fn()=>['scheduled'=>self::ensure()]);}
        update_option(Config::KEY.'_last_maintenance',['at'=>time(),'recovery'=>$final['data']['scheduled']??false,'retention_code'=>$prune['code']],false);self::notifySafely();
    }
    public static function health(): array {
        $now=time();$queue=Queue::health();$issues=[];$active=0;$partial=0;$failed=0;$failures=[];$budgets=[];$schedules=[];$rows=Store::list('schedule',0,100);$neededConnections=[];
        foreach($rows as $r)if(!empty($r['value']['enabled']))$neededConnections[$r['value']['query']['connection_id']]=true;
        foreach(Store::list('connection',0,100) as $row){$c=Connections::defaults($row['value'])+['revision'=>$row['revision']];$failure=CollectionState::connectionFailure($c);
            if(!$failure && (isset($neededConnections[$c['id']]) || ($c['enabled'] && !empty($c['token']) && !empty($c['expires_at']) && $c['expires_at']<=$now))){
                try{Connections::usable($c);}catch(Fault $e){$failure=CollectionState::diagnostic($e->reason,['auth_scope'=>'connection']);}
            }
            if($failure){$failures[$c['id']]=$failure;$issues[]=['code'=>'connection_authorization_failed','connection_id'=>$c['id'],'label'=>$c['label'],'last_code'=>$failure['code']??'not_authorized','last_error'=>$failure,'incident_key'=>$c['id'].':'.$c['authorization_revision'].':'.$c['credential_generation'],'action'=>'Confira a causa na conexão: estado, validade e permissões da credencial. A recuperação não exige recriar agendas.'];}}
        foreach($rows as $r){$v=$r['value'];$schedules[]=['schedule_id'=>$r['key'],'connection_id'=>$v['query']['connection_id'],'enabled'=>(bool)$v['enabled']]+CollectionState::scheduleDiagnostic($v);if(empty($v['enabled']))continue;$active++;
            $budgets[]=['schedule_id'=>$r['key'],'connection_id'=>$v['query']['connection_id']]+ExecutionBudget::view($v);
            $common=['schedule_id'=>$r['key'],'connection_id'=>$v['query']['connection_id'],'label'=>$v['label']??$r['key']];$code=$v['last_code']??null;$lastError=$v['last_error']??null;
            try{$current=Connections::get($v['query']['connection_id']);if(($lastError['auth_scope']??null)==='connection'&&!CollectionState::connectionFailure($current))$code=null;}catch(Fault $e){$current=null;}
            // A grant may be revoked after the schedule creates its job.
            if(!empty($v['last_job'])){try{$job=Store::get('job',$v['last_job']);if($job&&in_array($job['value']['last_code']??null,self::AUTH_CODES,true)&&($job['value']['last_error']['auth_scope']??null)!=='connection'&&(!$current||CollectionState::current($job['value'],$current))){$code=$job['value']['last_code'];$lastError=$job['value']['last_error']??null;}}
                catch(Fault $e){if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;$issues[]=$common+['code'=>'schedule_job_unreadable','action'=>'A última coleta desta agenda está ilegível. Confira as chaves (salts) e a integridade do registro; seus dados foram preservados.'];}}
            if(!isset($failures[$v['query']['connection_id']])&&in_array($code,self::AUTH_CODES,true))$issues[]=$common+['code'=>'schedule_authorization_failed','last_code'=>$code,'last_error'=>$lastError,'action'=>$code==='revision_conflict'?'A identidade ou a versão da API mudou. Confira o plano e a seleção atual.':'Confira o administrador do site, a conexão ativa e a validade da credencial da Meta.'];
            if($code==='asset_access_denied'&&!in_array($v['query']['report'],['stories','stories_insights'],true))$issues[]=$common+['code'=>'schedule_resource_access_failed','last_code'=>$code,'last_error'=>$lastError,'action'=>'A Meta recusou acesso ao recurso desta consulta. Confira a seleção do ativo e as permissões para este relatório; a revogação da conexão não foi comprovada.'];
            if(($v['last_run_status']??null)==='partial'&&!in_array($code,self::AUTH_CODES,true)&&!isset($failures[$v['query']['connection_id']])){$partial++;$issues[]=$common+['code'=>'schedule_partial','unavailable_metrics'=>$v['unavailable_metrics']??[],'successful_rows'=>$v['last_successful_rows']??0,'last_partial_at'=>$v['last_partial_at']??null,'action'=>'Métricas disponíveis foram preservadas. Confira somente as métricas indisponíveis antes de recompor a agenda.'];}
            elseif(($v['last_run_status']??null)==='failed'||$code!==null)$failed++;
            $blocked=ExecutionBudget::since($v);if($blocked!==null&&$now-$blocked>86400)$issues[]=$common+['code'=>'schedule_budget_exhausted','last_code'=>'budget_exhausted','blocked_since'=>$blocked,'blocked_seconds'=>$now-$blocked,'last_error'=>$lastError,'budget'=>ExecutionBudget::view($v),'action'=>'A agenda está bloqueada pelo orçamento local há mais de 24 horas. Confira consumo, prazo e próxima execução no diagnóstico; confira o cron e o progresso das coletas. A quota remota da Meta é informada separadamente.'];
            $lag=max(0,$now-(int)$v['next_at']);if($lag>2*60*(int)$v['interval_minutes'])$issues[]=$common+['code'=>'schedule_overdue','lag_seconds'=>$lag,'action'=>'Confira o cron e a autorização da agenda.'];
        }
        $next=wp_next_scheduled(Config::KEY.'_worker')?:null;$needed=$active>0||Queue::waiting();
        if($needed&&$next===null)$issues[]=['code'=>'worker_missing','action'=>'Rearmar o worker local e conferir o cron do servidor.'];
        if($queue['migration_pending'])$issues[]=['code'=>'queue_migration_pending','action'=>'Aguarde as passagens do worker; consulte a migração se não houver progresso.'];
        $lastMaintenance=get_option(Config::KEY.'_last_maintenance',[]);
        if(!empty($lastMaintenance['retention_code'])&&$lastMaintenance['retention_code']!=='ok')$issues[]=['code'=>'maintenance_failed','action'=>'Confira o erro de manutenção e o acesso ao armazenamento.'];
        if(!wp_next_scheduled(Config::KEY.'_maintenance'))$issues[]=['code'=>'maintenance_missing','action'=>'A manutenção horária é recriada na próxima requisição do site; confira o cron do servidor.'];
        if($queue['unreadable_jobs']>0)$issues[]=['code'=>'queue_record_unreadable','count'=>$queue['unreadable_jobs'],'action'=>'Há coletas cifradas que a chave atual do site não abre. Confira as chaves (salts) do wp-config; esses registros não são executados nem apagados automaticamente.'];
        return ['state'=>$issues?'degraded':'ok','observed_at'=>$now,'issues'=>$issues,'active_schedules'=>$active,'partial_schedules'=>$partial,'failed_schedules'=>$failed,'worker_required'=>$needed,'cron'=>['next'=>$next,'last'=>get_option(Config::KEY.'_last_worker',null),'traffic_required'=>!(defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON),'last_schedule_attempt'=>get_option(Config::KEY.'_worker_schedule_attempt',null),'last_schedule_failure'=>get_option(Config::KEY.'_worker_schedule_failure',null)],'queue'=>$queue,'execution_budget_policy'=>ExecutionBudget::policy(),'budgets'=>$budgets,'schedules'=>$schedules,'notification'=>get_option(Config::KEY.'_operation_notice',null)];
    }
    /** Read-only observation for meta/health: same diagnosis as status, never repairs, schedules or sends e-mail. */
    public static function observe(): array {
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(Connections::list()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'audit_health'=>get_option(Config::KEY.'_audit_health','unknown'),'maintenance'=>['next'=>wp_next_scheduled(Config::KEY.'_maintenance')?:null,'last'=>get_option(Config::KEY.'_last_maintenance',null)],'repair'=>'not_attempted']+ConsumerGrants::withHealth(self::health());
    }
    public static function status(): array {
        $h=ConsumerGrants::withHealth(self::health());$observed=$h['cron']['next'];$attempted=$h['worker_required']&&$observed===null;
        $repair=$attempted ? Jobs::scheduleTickResult() : ['scheduled'=>null,'code'=>null];
        $h['cron']['observed_next']=$observed;$h['cron']['next']=wp_next_scheduled(Config::KEY.'_worker')?:null;
        $h['recovery']=['attempted'=>$attempted]+$repair;
        $h['cron']['last_schedule_attempt']=get_option(Config::KEY.'_worker_schedule_attempt',null);$h['cron']['last_schedule_failure']=get_option(Config::KEY.'_worker_schedule_failure',null);
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(Connections::list()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'audit_health'=>get_option(Config::KEY.'_audit_health','unknown')]+$h;
    }
    public static function notifySafely(): void {Result::run(static function(){self::notify();return [];});}
    public static function notify(): void {
        Store::lock('operation-notice',static function(){
            $health=self::health();$active=[];$now=time();
            foreach((array)get_option('f3_meta_owner_replacements',[]) as $source=>$replacement){
                if(user_can((int)$source,'manage_options'))continue;
                $id=hash('sha256','administrador|'.$source.'|'.$replacement);
                $active[$id]=['pacote'=>'meta','codigo'=>'autorizacao_recusada','recurso'=>$id,'desde'=>$now];
            }
            foreach($health['issues'] as $i){
                $code=match($i['code']){
                    'connection_authorization_failed','schedule_authorization_failed','schedule_resource_access_failed','schedule_overdue','schedule_budget_exhausted','worker_missing'=>'agenda_parada',
                    'credential_expired'=>'credencial_invalida',
                    'maintenance_missing','maintenance_failed'=>'cron_sem_passagem',
                    default=>null};
                if(!$code)continue;
                // Identical identity to the periodic observer in Core 1.93.0.
                $id=hash('sha256',$i['code'].'|'.($i['schedule_id']??$i['connection_id']??'worker'));
                $active[$id]=['pacote'=>'meta','codigo'=>$code,'recurso'=>$id,'desde'=>min($now,max(1,(int)($i['blocked_since']??$i['last_error']['observed_at']??$now)))];
            }
            $old=get_option('f3_meta_incident_transitions',[]);$pending=$old['pending']??[];$before=$old['active']??[];
            foreach(array_diff_key($active,$before) as $id=>$entry)$pending[$id][]=$entry+['estado'=>'aberto'];
            foreach(array_diff_key($before,$active) as $id=>$entry)$pending[$id][]=$entry+['estado'=>'recuperado'];
            // Persist ordered transitions before the Core call, including when the receiver is absent.
            $save=static function()use(&$pending,$active){update_option('f3_meta_incident_transitions',['active'=>$active,'pending'=>$pending],false);};
            $save();$state='accepted';
            foreach(array_keys($pending) as $id){
                while(!empty($pending[$id])){
                    $receipt=apply_filters('f3base_incidente_publicar_v1',null,$pending[$id][0]);
                    if(empty($receipt['ok'])){$state=$receipt===null?'core_unavailable':'retry';break;}
                    array_shift($pending[$id]);if(!$pending[$id])unset($pending[$id]);$save();
                }
            }
            $status=['state'=>$state,'issue_count'=>count($active),'pending_transitions'=>array_sum(array_map('count',$pending)),'transport'=>'site-core'];
            if(get_option(Config::KEY.'_operation_notice',[])!==$status)update_option(Config::KEY.'_operation_notice',$status,false);
        });
    }
}
