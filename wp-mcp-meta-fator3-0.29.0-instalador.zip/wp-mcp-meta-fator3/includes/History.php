<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class History {
    public static function table(): string {global $wpdb;return $wpdb->prefix.'f3_meta_history';}
    public static function install(): void {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::table();
        dbDelta("CREATE TABLE $t (
row_key char(64) NOT NULL,
partition_key char(64) NOT NULL,
connection_key char(64) NOT NULL,
report varchar(40) NOT NULL,
data_day varchar(10) NOT NULL,
first_seen bigint unsigned NOT NULL,
last_seen bigint unsigned NOT NULL,
expires_at bigint unsigned NOT NULL DEFAULT 0,
payload longtext NOT NULL,
PRIMARY KEY  (row_key),
KEY selection (partition_key,report,data_day,row_key),
KEY connection_key (connection_key),
KEY expires_at (expires_at)
) ENGINE=InnoDB {$wpdb->get_charset_collate()};");
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t)throw new Fault('storage_unavailable','Histórico indisponível.');update_option('f3_meta_history_schema',1,false);
    }
    private static function partition($p,array $q): string {if(in_array($q['report']??'',Monitoring::REPORTS,true))return hash('sha256',Util::json(['monitoring-shared-v1',$q['connection_id'],$q['report'],$q['account_id'],$q['ads_account_id']??$q['selection']['ads_account_id']??null]));return ($q['channel']??'')==='ads'?hash('sha256',Util::json(['ads-shared-v1',$q['connection_id'],$q['account_id'],$q['ads_level']??$q['selection']['ads_level']??'campaign',Ads::ATTRIBUTION])):hash('sha256',Util::json([$p,$q['connection_id'],$q['channel'],$q['account_id']]));}
    /** Old organic partitions are immutable identities. Index their scope from one encrypted
     * sample per partition, never from a transport credential or an untrusted request. */
    private static function partitions(array $q,bool $persist=false): array {
        $canonical=self::partition('wordpress-site',$q);
        if(!in_array($q['channel'],['instagram','facebook'],true))return [$canonical];
        global $wpdb;$id=hash('sha256',$q['connection_id']);$map=Store::get('history_scope031',$id);
        if(!$map){
            $scopes=[];
            $rows=$wpdb->get_results($wpdb->prepare('SELECT partition_key,MIN(row_key) AS sample FROM %i WHERE connection_key=%s GROUP BY partition_key',self::table(),$id),ARRAY_A);
            if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao identificar o acervo.');
            foreach($rows as $row){
                $blob=$wpdb->get_var($wpdb->prepare('SELECT payload FROM %i WHERE row_key=%s',self::table(),$row['sample']));
                if(!is_string($blob))throw new Fault('storage_unavailable','Partição de histórico indisponível.');
                $v=json_decode(Crypto::open($blob),true,512,JSON_THROW_ON_ERROR);
                if($v['connection_id']!==$q['connection_id']||!in_array($v['channel'],['instagram','facebook'],true))continue;
                $scope=self::partition('wordpress-site',$v);
                if($scope!==$row['partition_key'])$scopes[$scope][]=$row['partition_key'];
            }
            if($persist)Store::put('history_scope031',$id,['partitions'=>$scopes]);
        }else $scopes=$map['value']['partitions'];
        return array_merge([$canonical],$scopes[$canonical]??[]);
    }
    private static function generation(string $partition): int {$r=Store::get('history_generation',$partition);return $r['value']['generation']??0;}
    private static function bump(string $partition): void {$r=Store::get('history_generation',$partition);Store::put('history_generation',$partition,['generation'=>($r['value']['generation']??0)+1],$r['revision']??0);}
    public static function ingest(array $data,array $principal,array $c,string $origin): void {
        Access::worker($principal,$c,$data['channel'],$data['account_id'],false);if($data['channel']==='dataset')Access::asset($c,'ads',$data['selection']['ads_account_id']);
        Store::lock('history',static function()use($data,$principal,$c,$origin){
            global $wpdb;$partitions=self::partitions($data,true);$changed=[];$wpdb->query('START TRANSACTION');
            try{
                foreach($data['rows'] as $n=>$row){
                    $day=$row['date']??null;$snapshot=(!$day&&in_array($data['temporal'],['snapshot','snapshot_or_lifetime','ephemeral_snapshot'],true));
                    $day=$day?:substr((string)($row['end_time']??$row['timestamp']??$row['created_time']??$data['fetched_at']),0,10);
                    $metric=$row['metric']??null;$entity=(string)($row['entity_id']??$row['id']??$data['account_id']);
                    $partition=$partitions[0];$identity=[$partition,$data['report'],$entity,$metric,$day,$data['temporal'],$data['channel']==='ads'?'ads-daily-v1':$data['api_version'],$data['selection']['timeframe']??null,$data['selection']['breakdown']??null];
                    if($data['channel']==='ads')$identity[]=[$data['currency'],$data['timezone']];
                    if(!$metric&&!isset($row['id']))$identity[]=hash('sha256',Util::json($row));
                    if($data['temporal']==='interval')$identity[]=[$data['selection']['date_from']??null,$data['selection']['date_to']??null];
                    if($data['report']==='ads_activity')$identity=[$partition,$entity];
                    if($data['report']==='dataset_quality')$identity=($row['record_kind']??'')==='emq_snapshot'?[$partition,$entity]:[$partition,$entity,$day,$data['timezone']];
                    $keys=[];
                    foreach($partitions as $part){$identity[0]=$part;$keys[]=hash('sha256',Util::json($identity));}
                    $key=$keys[0];$marks=implode(',',array_fill(0,count($keys),'%s'));$old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE row_key IN ('.$marks.') ORDER BY last_seen DESC,row_key LIMIT 1',array_merge([self::table()],$keys)),ARRAY_A);if($wpdb->last_error)throw new Fault('storage_unavailable','Histórico não pôde ser lido.');
                    if($old){$key=$old['row_key'];$partition=$old['partition_key'];}
                    $previous=$old?json_decode(Crypto::open($old['payload']),true):null;
                    if($previous&&($previous['origin']??'')===$origin)continue;
                    $observed=strtotime($data['fetched_at'])?:time();if($old&&$observed<(int)$old['last_seen'])continue;$first=$old?(int)$old['first_seen']:$observed;
                    $value=['row_id'=>$key,'row'=>$row,'connection_id'=>$c['id'],'channel'=>$data['channel'],'account_id'=>$data['account_id'],'report'=>$data['report'],'api_version'=>$data['api_version'],'catalog_revision'=>Catalog::REVISION,'temporal'=>$data['temporal'],'data_day'=>$day,'first_seen'=>gmdate('c',$first),'last_seen'=>gmdate('c',$observed),'snapshot'=>$snapshot,'timezone'=>$data['timezone'],'currency'=>$data['currency'],'selection'=>$data['selection'],'coverage'=>$data['coverage'],'origin'=>$origin,'observations'=>($previous['observations']??0)+1];
                    if($data['channel']==='ads'){$value['last_available_fields']=$previous['last_available_fields']??[];foreach($row as $field=>$observedValue)if($observedValue!==null&&!in_array($field,['unavailable_fields','availability'],true))$value['last_available_fields'][$field]=['value'=>$observedValue,'at'=>gmdate('c',$observed)];}
                    $available=($row['availability']??'available')==='available'&&empty($row['unavailable_fields']);$value['last_successful_observation']=$available?['row'=>$row,'at'=>gmdate('c',$observed)]:($previous['last_successful_observation']??null);
                    unset($value['selection']['cursor']);$expires=in_array($data['channel'],['ads','dataset'],true)||$c['retention_mode']==='unlimited'?0:$observed+(int)$c['retention_days']*86400;
                    $ok=$wpdb->replace(self::table(),['row_key'=>$key,'partition_key'=>$partition,'connection_key'=>hash('sha256',$c['id']),'report'=>$data['report'],'data_day'=>$day,'first_seen'=>$first,'last_seen'=>$observed,'expires_at'=>$expires,'payload'=>Crypto::seal(Util::json($value))]);
                    if($ok===false)throw new Fault('storage_unavailable','Histórico não confirmado.');$changed[$partition]=true;
                }
                foreach(array_keys($changed) as $part)self::bump($part);
                if($wpdb->query('COMMIT')===false)throw new Fault('persistence_unconfirmed','Confirmação do histórico indisponível.');
            }catch(\Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
        });
    }
    public static function policyChanged(array $c): void {
        if((int)get_option('f3_meta_history_schema',0)!==1)return;
        Store::lock('history',static function()use($c){global $wpdb;$expression=$c['retention_mode']==='unlimited'?'0':'last_seen+'.((int)$c['retention_days']*86400);$key=hash('sha256',$c['id']);
            $partitions=$wpdb->get_col($wpdb->prepare('SELECT DISTINCT partition_key FROM %i WHERE connection_key=%s',self::table(),$key));
            $ok=$wpdb->query($wpdb->prepare("UPDATE %i SET expires_at=CASE WHEN report IN ('ads_insights','ads_activity','dataset_quality') THEN 0 ELSE ".$expression.' END WHERE connection_key=%s',self::table(),$key));if($ok===false)throw new Fault('storage_unavailable','Política do histórico não confirmada.');
            foreach($partitions as $p)self::bump($p);
        });
    }
    public static function migrationComplete(): bool {$r=Store::get('migration','history-020');return (bool)($r['value']['complete']??false);}
    public static function migrate(): array {
        return Store::lock('history-migration',static function(){
            $m=Store::get('migration','history-020');$v=$m['value']??['after'=>'','complete'=>false,'pages'=>0,'rows'=>0,'expired_pages_skipped'=>0,'blocked_pages'=>0];if($v['complete'])return $v;
            $rows=Store::scan('result',$v['after'],25);
            foreach($rows as $r){$old=$r['value'];
                if($r['expires_at']>0&&$r['expires_at']<time())$v['expired_pages_skipped']++;
                else{try{$c=Connections::get($old['query']['connection_id']);self::ingest($old['data'],SiteOwner::executor($old['principal']),$c,$r['key']);$v['rows']+=count($old['data']['rows']);}catch(Fault $e){
                    // Revoked access does not authorize resurrecting or exposing old data. Keep the page for review.
                    if(!in_array($e->reason,['not_authorized','asset_access_denied','connection_paused','not_configured'],true))throw $e;$v['blocked_pages']++;
                }}
                $v['after']=$r['key'];$v['pages']++;
            }
            $v['complete']=count($rows)<25;Store::put('migration','history-020',$v,$m['revision']??0);return $v;
        });
    }
    public static function status(): array {Access::admin();$r=Store::get('migration','history-020');global $wpdb;$count=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i',self::table()));return ['schema'=>1,'rows'=>$count,'migration'=>$r['value']??['complete'=>false],'independent_from_job_retention'=>true,'binary_media_archived'=>false];}
    public static function query(array $i): array {
        return self::readAuthorized($i,ConsumerGrants::administrator());
    }
    /** Internal read; the supplied origin must still have active administrative and transport rights. */
    public static function readAuthorized(array $i,array $principal,?array $legacyExport=null): array {
        Schemas::validate('history-query',$i);$c=Access::storedQuery($principal,$i);
        return Store::lock('history',static function()use($i,$principal,$c,$legacyExport){
            global $wpdb;$q=$i;unset($q['cursor']);$parts=$legacyExport?[self::partition($legacyExport,$i)]:self::partitions($q);$binding=hash('sha256',Util::json($legacyExport?[$q,$legacyExport,$c['authorization_revision']]:[$q,'wordpress-site']));$generation=array_sum(array_map([self::class,'generation'],$parts));$after='';
            if(!empty($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding||($cur['generation']??-1)!==$generation)throw new Fault('history_changed','O conjunto histórico mudou; reinicie a leitura para manter uma visão consistente.');$after=$cur['after'];}
            $where='partition_key IN ('.implode(',',array_fill(0,count($parts),'%s')).') AND row_key>%s AND (expires_at=0 OR expires_at>=%d)';$args=array_merge($parts,[$after,time()]);
            if(isset($i['report'])){$where.=' AND report=%s';$args[]=$i['report'];}
            if(isset($i['date_from'])){$where.=' AND data_day>=%s AND data_day<=%s';$args[]=$i['date_from'];$args[]=$i['date_to'];}
            $limit=$i['limit']??100;$sql=$wpdb->prepare('SELECT row_key,payload FROM %i WHERE '.$where.' ORDER BY row_key LIMIT %d',array_merge([self::table()],$args,[$limit+1]));$records=$wpdb->get_results($sql,ARRAY_A);if($wpdb->last_error)throw new Fault('storage_unavailable','Histórico indisponível.');
            $more=count($records)>$limit;$records=array_slice($records,0,$limit);$rows=[];foreach($records as $r)$rows[]=json_decode(Crypto::open($r['payload']),true);$last=$records?end($records)['row_key']:$after;
            Access::checkPrincipal($principal);Connections::revalidate($c);
            $next=$more?Util::cursor(['binding'=>$binding,'generation'=>$generation,'after'=>$last,'expires'=>time()+86400]):null;
            $data=['contract'=>'meta-history/1.0.0','rows'=>$rows,'next_cursor'=>$next,'generation'=>$generation,'migration_complete'=>self::migrationComplete(),'coverage'=>['stored_rows_only'=>true,'origin_all_rows_guaranteed'=>false,'snapshot_dates_are_observation_dates'=>true],'retention'=>['mode'=>in_array($i['channel'],['ads','dataset'],true)?'unlimited':$c['retention_mode'],'days'=>!in_array($i['channel'],['ads','dataset'],true)&&$c['retention_mode']==='finite'?$c['retention_days']:null]];
            if(strlen(Util::json($data))>700000)throw new Fault('response_limit','Reduza limit para ler registros históricos maiores.');return $data;
        });
    }
    public static function prune(): int {
        return Store::lock('history',static function(){global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT row_key,partition_key FROM %i WHERE expires_at>0 AND expires_at<%d LIMIT 100',self::table(),time()),ARRAY_A);if($wpdb->last_error)throw new Fault('storage_unavailable','Retenção indisponível.');$partitions=[];foreach($rows as $r){if($wpdb->delete(self::table(),['row_key'=>$r['row_key']])===false)throw new Fault('storage_unavailable','Retenção não confirmada.');$partitions[$r['partition_key']]=true;}foreach(array_keys($partitions) as $p)self::bump($p);return count($rows);});
    }
    public static function backfill(array $i): array {
        $q=$i['query'];SiteOwner::reader($q);if(!isset($q['date_from']))throw new Fault('explicit_start_required','Defina o início; a API não informa um horizonte universal recuperável.');
        $yesterday=in_array($q['channel']??'',['ads','dataset'],true)?Ads::yesterday(Connections::get($q['connection_id']),$q['ads_account_id']??$q['account_id']):gmdate('Y-m-d',time()-86400);$q['date_to']=$q['date_to']??$yesterday;if($q['date_to']>$yesterday)throw new Fault('invalid_input','Backfill diário termina no máximo ontem no fuso do relatório.');
        if(in_array($q['report'],['account_insights','page_insights'],true))$q['granularity']='day';
        if($q['report']==='media_insights')$q['iterate_media']=true;
        $job=Jobs::create(['query'=>$q,'idempotency_key'=>$i['idempotency_key'],'max_pages'=>$i['max_pages']??5000]);return $job+['backfill'=>true,'frozen_until'=>$q['date_to'],'remote_horizon_guaranteed'=>false];
    }
}
