# Fator3 MCP 0.37.0 — UTF-8 nos logs Apache

Base direta 0.36.0. Pedido MCP 75. Matriz considerada: Core 1.60.0, Google 0.22.0, LinkedIn 0.12.0, Meta 0.14.0 e Pipedrive 0.3.0. Mínimos MCP preservados: WordPress 7.1.2/PHP 8.3.6. O relatório externo distingue ambientes efetivamente testados e limites. Os pedidos 70/74 da versão anterior foram aceitos pela frota conforme a entrada de 29/10/2026.

## Leitura e filtro

O Apache pode escrever bytes UTF-8 recebidos do stderr PHP como texto `\xNN`. `system/error-log` converte cada sequência contígua quando todos os bytes formam UTF-8 válido. Exemplo: `desativa\xc3\xa7\xc3\xa3o` passa a `desativação`. Mensagens já escritas em UTF-8 permanecem iguais.

A conversão ocorre antes de mascarar segredos, extrair arquivo/linha, normalizar espaços, agrupar e aplicar o filtro text. As grafias escapada e nativa equivalentes passam a somar no mesmo grupo; first/last continuam os extremos dos eventos desse grupo. Não há normalização Unicode NFC/NFD nem busca sem acentos: o filtro continua uma correspondência literal, sensível à caixa, sobre a mensagem decodificada e mascarada. Use o texto exibido, não a sequência hexadecimal antiga.

Exemplo do aceite pedido: `{"since":"2026-10-24T00:00:00-03:00","until":"2026-10-26T00:00:00-03:00","text":"desativação"}`. since inclui o instante inicial e until exclui o final. A consulta é limitada ao domínio do próprio site; o MCP não chama outro site nem recebe um domínio arbitrário.

Cada trecho inválido é preservado integralmente, sem caractere de substituição, conversão Latin-1 ou decodificação parcial de seu prefixo. Incluem-se bytes truncados, isolados, codificações overlong, surrogates e valores fora do intervalo Unicode. Hexadecimais A–F são aceitos. Não são interpretados escapes genéricos `\n`, octais, `%NN` ou `\uNNNN`; barras literais duplicadas permanecem literais. A conversão tem uma única passagem, sem reinterpretação recursiva. Mesmo sendo bytes UTF-8 válidos, controles ASCII NUL–0x1F e DEL permanecem escritos como escape para não inserir controles ou quebrar linhas na saída.

As amostras de linhas não reconhecidas também são decodificadas antes da máscara e do corte. Permanecem no máximo três exemplos, com até 256 bytes JSON cada, sob `unparsed_scope:scanned_files`. Não correspondem necessariamente à janela de eventos, pois uma linha sem data interpretável não pode ser atribuída a ela. A máscara cobre padrões identificáveis; não garante classificar todo texto pessoal arbitrário.

## Continuação e compatibilidade

Os grupos e seus identificadores podem mudar quando grafias antes separadas se tornam equivalentes. Por isso, o cursor é agora `hosting-error-log/3`. Um cursor emitido antes da 0.37.0 retorna `cursor_invalid`: reinicie a consulta com os mesmos filtros e sem cursor. Não recupere um offset antigo nem some páginas de versões diferentes. Os próximos cursores continuam vinculados a conexão, filtros, inventário e expiração; mudança de arquivo continua exigindo reinício.

Schema público e permissões permanecem: `since`, `until`, `level`, `text`, `cursor`, `per_page`; manage_options e política de arquivos/conexão. Mantidos domínio exato/alias sem www, prioridade de nível PHP, Apache/mod_fcgid, gzip com CRC, fuso America/Los_Angeles dos arquivos e fuso do site na saída. Não se modifica nenhum log ou opção de hospedagem.

Limites mantidos: 8 KiB por página, 31 dias por janela, 128 arquivos, 32 MiB expandidos, 16 MiB comprimidos por arquivo, 5 segundos, 5000 grupos. Falhas e limites não retornam uma contagem parcial como completa. Decode não é executado em filtros enviados pelo cliente, nomes de arquivos físicos, datas ou parâmetros de autorização.

## Atualização, reversão e aceite

Sem tabela, option, migração, credencial, concessão ou agendamento novo. Upgrade direto 0.36→0.37 preserva o estado existente. Reverter arquivos para 0.36 restaura a apresentação hexadecimal e os grupos anteriores; reinicie também os cursores. Pré-imagem e autorização de instalação seguem o fluxo vigente de pacotes. Não há exigência nova de troca coordenada com o Core 1.60 nem reconcessão comercial decorrente desta mudança MCP.

O aceite específico do Pedido 75 é a leitura da mesma janela histórica em ctooffice, apresentando a frase decodificada e encontrando o grupo por text desativação. O relatório identifica as provas locais, a observação no Site-Teste e o que permanece com a frota. Presença da função ou de mensagens diferentes em outro site não encerra esse aceite por si só.

## Limite conhecido na convivência com Core 1.60

A lista credenciais de f3base/credenciais-ler e os envelopes de opções secretas de config-core-ler são mascarados pela regra vigente do MCP. O fluxo consultado não disponibiliza a revisão necessária para verificar uma candidata só por essas leituras. O comportamento já ocorre com MCP 0.36. O relatório traz um encaminhamento ao Core para projeção neutra de metadados e revisão opaca. Usar a tela administrativa própria até o alinhamento; não inferir revisão nem abrir exceção global de segredo. Esse achado não altera a decodificação de logs e não constitui autorização de validação/envio real a fornecedor.
