# Pedidos — Fator3 MCP (wp-mcp-fator3)

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no canal **wp-mcp-fator3** (o servidor MCP de cada site; Conector WP MCP §1 e §2). Em outros documentos, cite como "Pedidos MCP N". Serve também de documento para o responsável pelo canal. Base da análise: código da 0.36.0. A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba. A numeração não muda.

**Situação em 28/10/2026: aberto 75.** Versão instalada nos 12 sites da frota: 0.36.0 (ZIP `wp-mcp-fator3-0.36.0-instalador.zip`, 910.233 bytes, sha256 `97648853…`, igual ao relatório e ao servido pelo raw; no `main` com a fonte `6dab0eea…` e o relatório, commit `e55b3a9`), direto sobre a 0.35.0, sem banco novo: no Site-Teste pelo agente do pacote e nos outros 11 pela frota em 28/10/2026 entre 22:12 e 22:29 −03, depois do Meta 0.14.0 e antes do Site Core 1.60.0, com `applied` e sondas 200. Entregaram e saíram desta lista os itens 70 e 74: `system/error-log` leu em ctooffice.com.br a janela de 24 e 25/10 com três arquivos `.gz`, a pasta sem `www` e os grupos no horário −03, sem linha fora do formato, e em korvena.net.br agrupou as linhas do mod\_fcgid; `users/delete` excluiu no Site-Teste o usuário de teste criado por `users/create`, com prévia e confirmação aplicadas. Próxima entrega sem data.

**Numeração.** Item novo recebe o próximo número (hoje, 76) e vai no fim; item retirado deixa o número vago.

## wp-mcp-fator3 — pendentes

**75. `system/error-log` devolve os bytes UTF-8 escapados pelo Apache (28/10/2026; canal 0.36.0, ctooffice.com.br).** Evidência: em ctooffice.com.br, a leitura de 24 e 25/10/2026 devolve as mensagens do WordPress com os bytes dos acentos escritos como texto, por exemplo `Erro de desativa\xc3\xa7\xc3\xa3o de evento de cron para o gancho: f3base_navegacao_verificar_cron`: o Apache grava no error.log os bytes acima de 127 vindos do `stderr` do PHP como `\xNN`, e o canal devolve a sequência literal. O agrupamento funciona, mas a mensagem fica difícil de ler e o filtro `text` com acento não casa. Pedido: decodificar as sequências `\xNN` que formam UTF-8 válido antes de normalizar, agrupar e filtrar, e manter a original quando não formarem UTF-8. Aceite: em ctooffice.com.br, a mesma janela devolve "Erro de desativação de evento de cron…", e o filtro `text` "desativação" acha o grupo.

## Decidido não fazer

Da lista comum da frota, o que toca o canal:

- Rota de execução de PHP.
- Rota "frota" (um site chamando os outros).
- `db/execute` em uma fase.
- Fonte de atualização publicada para os pacotes Fator3 (decisão do dono, 01/10/2026): os pacotes seguem trocados por `plugins/upload` com o ZIP versionado do GitHub e `expected_sha256`, pela ordem do Padrão §1.1, e ficam fora de `auto_update_plugins`.
