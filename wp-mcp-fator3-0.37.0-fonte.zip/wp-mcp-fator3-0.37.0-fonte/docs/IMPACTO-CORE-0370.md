# Impacto de Fator3 MCP 0.37.0 em Fator3 Site Core

Data: 29/10/2026 · Revisão: 1 · Etapa: entrega, após confirmação do achado nas duas versões · Situação: aberto

Emissor: wp-mcp-fator3. Base aceita 0.36.0, SHA-256 97648853e16d7c7fca811c6be22323244c5f2ebc3e296c22564ce7b2739cb98b. Alvo entregue 0.37.0, instalador 912702 bytes/SHA-256 cbece53fc479d9fe3963b111e49e789d92609c5462102877244dcaebcf7cf3ec. Destinatário: base-site-core-fator3 1.60.0, instalador SHA-256 1dc4e94305ea55394024d6527bc06b46209f0ae51a55f734853763bcb232e27c.

Natureza: contrato e integração de diagnóstico de credenciais. Classificação: acao-necessaria. Referência relacionada: Pedido Core 334; achado adicional da validação MCP, sem inventar número de pedido.

## Mudança e consequência

O Core 1.60.0 retorna os metadados de f3base/credenciais-ler em uma lista sob a chave credenciais. A regra publicada fator3-redaction/1 considera essa chave sensível e substitui a lista inteira por [redigido]. O callback nativo tem um item; pelo transporte público os rótulos, ajuda, estado, identidade e avisos desse item ficam indisponíveis.

f3base/config-core-ler também mascara todo opcoes/f3base_avisos_webhook_chave, incluindo sua revisão. f3base/credenciais-verificar exige revisao_esperada, mas o item de credenciais-ler não fornece revisão nem antes do transporte. Assim, esse caminho de leitura não fornece ao cliente MCP uma revisão utilizável para preparar a verificação. Não se afirma ausência de toda outra rota possível no Core; o problema é o fluxo dessas interfaces documentadas.

A reprodução com MCP 0.36.0 + Core 1.60.0 confirma que não foi introduzido pela decodificação de logs da 0.37.0. Nenhum valor secreto vazou; o efeito é indisponibilidade de metadados públicos. A correção do Pedido MCP 75 é independente.

## Ação proposta ao responsável Core

Publicar uma projeção administrativa de metadados sob nome neutro, por exemplo itens ou registros, com nome da opção como valor. Acrescentar a revisão opaca atual necessária ao CAS em cada item. Não incluir segredo, candidato, token, cookie ou valor salvo nessa projeção. Manter a conferência de manage_options, perfil, revisão atual e identidade antes de qualquer efeito. Uma migração aditiva pode conservar o campo antigo para clientes existentes; não duplicar segredos como tentativa de evitar a máscara.

O Core já documenta no código a estratégia de nomes de opções como valores. A proposta estende essa estratégia ao contêiner externo e à revisão. Uma exceção global para chaves credenciais/token/senha no MCP não é proposta; esse vocabulário protege respostas de outros produtores.

Até a correção coordenada, a tela administrativa própria do Core continua sendo o caminho para o fluxo de credenciais. Não inferir revisão, usar SQL, trocar chave idempotente ou enfraquecer a redação para contornar a indisponibilidade.

## Compatibilidade e sequência

Responsável pela alteração: mantenedor Core. Responsável pela prova do transporte: mantenedores Core/MCP. Não há necessidade de bloquear a entrega do Pedido MCP 75. O canal 0.37.0 conserva a regra de redação vigente; nenhum código Core foi alterado por esta rodada.

Proposta, não alteração já entregue no Core. O dono encaminha este arquivo; sua elaboração não significa envio nem criação de ticket externo.

## Aceite e evidência

1. Pelo conector MCP, ler um item de diagnóstico e obter somente seus metadados públicos e revisão opaca atual, sem valor secreto.
2. Preparar uma candidata sintética com essa revisão pela interface pública; confirmar avisos de formato do Core 334, recusa por revisão divergente e ausência de alteração da credencial salva quando a ação for apenas verificação/prévia.
3. Conferir paridade entre content/structuredContent, caminhos de redação dos campos realmente secretos e ausência de credenciais nos avisos/auditoria.
4. Recusar usuário/perfil sem permissão; preservar casos de chaves secretas fora da projeção.
5. Testar WordPress e transporte MCP real com o novo Core e o MCP corrente.

Reprodução própria: tools/release0370/credential-boundary.php, com cinco verificações em cada versão MCP e resultados separados em evidencias/0370. A ausência de revisão no callback nativo, combinada à indisponibilidade dos envelopes públicos, fundamenta a proposta de projeção e revisão explícitas. O resultado é uma limitação reproduzida, não aprovação do fluxo completo. A fixture de avisos em companions.php usa uma revisão obtida nativamente no laboratório e prova somente o transporte da prévia, sem apresentar essa preparação como fluxo público completo.

No Site-Teste, a leitura anterior à troca, com MCP 0.36.0, apresentou a lista inteira como [redigido]. A repetição pós-instalação na 0.37.0 foi bloqueada pela revisão automática de segurança por envolver leitura de credencial privada identificada por nome; nenhuma rota alternativa foi utilizada. A prova 0.37.0 desta fronteira é local e sintética. Para o aceite remoto futuro, oferecer explicitamente a projeção sem valores secretos, conforme a proposta acima; não reutilizar a leitura de valores como teste de metadados.

Resposta esperada: proposta aceita ou alternativa de contrato com versão, schema e prova pública. Respostas e encerramento serão registrados no relatório principal da rodada correspondente.
