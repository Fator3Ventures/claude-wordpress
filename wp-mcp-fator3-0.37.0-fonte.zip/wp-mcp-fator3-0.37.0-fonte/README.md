# Fator3 MCP 0.37.0

Base direta 0.36.0. Pedido MCP 75: UTF-8 escapado pelo Apache na leitura de logs. Matriz: Core 1.60.0, Google 0.22.0, LinkedIn 0.12.0, Meta 0.14.0 e Pipedrive 0.3.0. Mínimos MCP WordPress 7.1.2/PHP 8.3.6.

Instalar somente wp-mcp-fator3-0.37.0-instalador.zip. Runtime em fontes/wp-mcp-fator3; documentação editável em docs; reprodução em tools/release0370/README.md; evidências atuais em evidencias/0370. Planos, testes e evidências anteriores são históricos. O relatório externo identifica os arquivos finais, a prova remota e o aceite de frota ainda necessário.
