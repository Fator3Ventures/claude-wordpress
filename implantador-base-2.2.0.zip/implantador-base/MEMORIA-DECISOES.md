<!-- gerado:inicio=carimbo -->
# Memória de decisões — implantador-base 2.2.0

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio, e o documento passa a descrever um pacote que não é este. O que não pode ser gerado
> no momento da escrita sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `2.2.0` |
| Implantador · tema · plugin | `2.2.0` · `1.7.0` · `1.0.0` |
| Bundle desta identidade | `implantador-base-2.2.0.zip` |
| Origens de release suportadas | 48 além da instalação limpa |
| Caminhos exatos no inventário | 118 |
| Prefixos declarados no inventário | 4 |
| Arquivos no pacote (fora de `dist/` e dos produtos da rodada) | 413 |
| Requisitos em `suite/manifesto.tsv` | 229 |
| Armadilhas com checagem mapeada | 131 |
| Armadilhas em pendência declarada | 11 |
| Detectores com piso em disco | 68 |
| Ramos de piso (negativa + positiva) | 136 |
| Páginas · posts declarados | 6 · 2 |
| Reserva do plugin na árvore | `assets/plugins/base-site-core-fator3-1.0.0.zip` |
| `sha256` da reserva · declarado no catálogo | `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f` · `8fa9d504eead23b3a1489b0e391cec6f50cb073ebd5e67c2f36ee03c7d4a656f` |
| Arquivos vendorizados em `partilhado/` | 6 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

Registro das decisões desta base. Cada entrada traz quatro campos, sempre na mesma
ordem: **o que foi decidido**, **por quê**, **o que custa** e **como reverter**.
Decisão sem custo escrito é decisão não examinada; decisão sem caminho de reversão
é decisão que só pode ser paga uma vez.

Escopo: as decisões abaixo valem para o pacote-fábrica. Decisão tomada dentro de
uma instância publicada mora na memória daquela instância, não aqui.

Convenção de estados usada neste arquivo: os mesmos seis estados fechados do
relatório da suíte, sem inventar um sétimo.

---

## 1. O menu é um post `wp_navigation`

**Decidido.** A navegação principal é um post do tipo `wp_navigation`, com slug
estável `f3base-principal`, ID guardado na option `f3base_nav_id`, e o tema
injetando o `ref` no bloco em tempo de render. A alternativa descartada é o menu
escrito dentro de `parts/header.html`.

**Por quê.** O critério é quem edita o menu depois da entrega. Com manutenção por
agente conectado ao canal MCP, quem edita é o agente, por rota tipada — sem release,
sem acesso ao servidor de arquivos e sem tocar no tema. E existe uma cópia só do
objeto: duas páginas divergirem de menu deixa de ser possível por construção, não
por disciplina.

**O que custa.** O menu sai do versionamento em arquivo e passa a viver no banco.
Um diff de repositório deixa de mostrar mudança de navegação, e a reconstrução da
instância a partir do pacote depende do implantador recriar o objeto, não de copiar
um arquivo. A compensação declarada é a leitura de volta do objeto na aplicação e o
registro da mudança na memória da instância.

**Como reverter.** Trocar `navegacao.modo` para o menu inline na part, mover os
itens para `parts/header.html`, subir a versão do tema e apagar `f3base_nav_id` pelo
gravador único. A reversão é migração, não ajuste: o objeto no banco continua
existindo até ser removido explicitamente, e menu em dois lugares é a pior das três
configurações possíveis. Projeto explicitamente sem manutenção pós-entrega é o único
caso em que essa reversão faz sentido.

---

## 2. Lockdown do `theme.json`

**Decidido.** Quinze chaves de `settings` desligadas no `theme.json`: as nove que o
contrato exige — `color.custom`, `color.customGradient`, `color.defaultPalette`,
`color.defaultGradients`, `typography.customFontSize`, `typography.defaultFontSizes`,
`spacing.customSpacingSize`, `spacing.defaultSpacingSizes` e
`layout.allowCustomContentAndWideSize` — mais `color.customDuotone`,
`color.defaultDuotone`, `shadow.defaultPresets`, `typography.dropCap`,
`typography.fluid` e `typography.writingMode`.

**Por quê.** Dois motivos independentes. O primeiro é o defeito medido: o WordPress
injeta presets padrão **com os mesmos slugs do tema**, e eles vencem os valores do
tema no global-styles — o sintoma foi `--wp--preset--font-size--large` publicado em
36px com o tema declarando outro valor, com duas rodadas de correção nos `elements`
sem efeito porque o defeito não estava lá. O segundo é o sistema de design: com as
portas fechadas, o editor só oferece o que o `theme.json` declara, e largura, cor,
fonte e espaçamento continuam idênticos entre páginas depois que a suíte da entrega
dormiu.

**O que custa.** O fechamento restringe também o editor humano legítimo. Um pedido
do tipo "esta palavra neste vermelho específico" não tem caminho pela interface: ele
vira preset novo, com nome e propagação, ou vira recusa explicada — e isso precisa
ser dito na conversa de handoff, não descoberto pelo cliente na primeira edição.
Segundo custo, mais sutil: o lockdown governa a interface do editor e **não alcança
quem grava markup direto**, que é justamente o agente de manutenção via MCP.

**Como reverter.** Ligar a chave específica no `theme.json` e subir a versão do
tema. A reversão é por chave, nunca em bloco: reabrir `defaultFontSizes` traz de
volta a colisão de slugs, que é defeito conhecido e não preferência.

**Consequência aceita, não revertida.** Como o lockdown não alcança o markup direto,
o mecanismo que fecha esse lado é a varredura `conteudo.sem_estilo_avulso` sobre o
conteúdo publicado — cor literal, tamanho de fonte solto e largura fixa fora de
referência de preset. Sem a varredura, o lockdown é meia trava.

---

## 3. Consentimento pré-aprovado, com controle no rodapé e aviso de primeira visita desligado

**Decidido.** `consentimento.padrao` é `pre-aprovado`: as tags carregam na chegada,
sem banner bloqueante. O instrumento do titular é o controle de revisão no rodapé,
presente em toda página publicada — inclusive 404 e páginas de confirmação, porque
ele mora na part do rodapé. A negativa desliga as tags na mesma sessão e persiste por
`ttl_dias`, hoje 180; o novo aceite religa. A chave `aviso_primeira_visita` existe,
tem consumidor no JavaScript do `site-core` e nasce **desligada**.

**Por quê.** A pré-aprovação é a política declarada da operação, e o controle
permanente no rodapé é o que a torna revisável em qualquer momento, em vez de uma
decisão tomada uma vez num banner e nunca mais alcançável. O aviso de primeira visita
nasce desligado porque ligá-lo é decisão de projeto — o caso que a pede é o cliente
cujo jurídico exige informação antes da carga.

**O que custa.** O custo é jurídico e está declarado sem maquiagem: o guia de cookies
da ANPD, de 2022, orienta consentimento prévio para cookies não essenciais, e
pré-aprovação **sem** aviso na primeira visita é a leitura mais exposta de uma posição
já contestada na LGPD. Com o aviso desligado, a transparência se apoia inteiramente na
política publicada e no controle do rodapé — e o relatório de entrega precisa dizer
isso com todas as letras, nunca "o visitante foi informado". Custo secundário: sem
JavaScript o controle não opera, e essa perda é declarada como a do fluxo de WhatsApp.

**Como reverter.** Duas reversões diferentes, e elas não são a mesma coisa. Mitigação
parcial: ligar `consentimento.aviso_primeira_visita`, que acrescenta o aviso não
bloqueante apontando a política e o controle do rodapé, sem mudar a política de carga.
Reversão completa: trocar `consentimento.padrao` para negado, e então as tags só
carregam após o aceite, com o controle do rodapé seguindo como caminho de revisão — a
estrutura é a mesma, os quatro caminhos testados apenas se invertem.

---

## 4. Atualização automática ligada para todo plugin, sem exceção

**Decidido.** `plugins.autoupdate` é `todos`, incluindo o servidor do canal MCP.
A política de versão é `ultima-da-fonte-oficial`: nenhuma versão é fixada e nenhuma
janela de versões é homologada previamente.

**Precedência declarada.** Janela de exposição **vence** estabilidade. Quando as duas
entram em conflito, a decisão é atualizar. A saída para quebra é **reverter**, não
deixar de atualizar — a ordem dos dois é o conteúdo da decisão, e inverter a ordem é
mudar a política, não afiná-la.

**Por quê.** Plugin desatualizado num site público é vulnerabilidade com data de
publicação conhecida. Congelar versão troca um risco medido por um risco difuso, e
transfere para uma decisão humana futura — que costuma não acontecer — a proteção que
o automatismo dá de graça.

**O que custa.** Três coisas. O plugin muda embaixo do site sem release nossa, então a
conferência dos adaptadores deixa de ser de instalação e passa a ser de rotina, o que
torna a cadência do modo somente-relatório obrigatória em vez de higiênica. A quebra
sutil — comportamento mudado, chave de option descartada, CSS deslocado — passa pela
rede de proteção do WordPress e só aparece na cadência ou no cliente. E o complemento
do canal, por não vir do WordPress.org, não é alcançado pela atualização automática:
o caminho dele continua sendo release nossa, por upload com sobrescrita e reativação.

**Como reverter.** Não há reversão da política em si sem mudar a precedência acima. O
que existe é o caminho de reversão pontual de um plugin, descrito no `README.md`, com
os três limites que ele carrega: o WordPress só desfaz sozinho a falha fatal; reverter
código não reverte dados; e a reversão é temporária, datada e fecha quando o upstream
corrige.

---

## 5. Nenhuma versão fixada e nenhuma janela homologada; o gate é a leitura de volta

**Decidido.** Plugin de terceiro é instalado sempre na última versão publicada pela
fonte oficial. Não existe número congelado no arquivo de configuração, não existe
intervalo de versões declarado como aprovado e não existe checksum de terceiro no
lock. O que decide se a instalação serve é a leitura de volta de cada option gravada.

**Por quê.** Um portão por número é inferência sobre compatibilidade; gravar e reler é
medição dela. Qualquer portão por número reprovaria um site saudável no dia seguinte a
uma atualização automática, ou aprovaria um site quebrado numa versão que mudou de
comportamento sem mudar de número maior. E a razão da antiga regra — nada de
configurar às cegas — sobrevive inteira num mecanismo que não depende de alguém ter
previsto a numeração do fornecedor: escrever num plugin de versão desconhecida é
seguro **porque** a escrita é reversível e conferida.

**O que custa.** A fronteira de confiança passa a ser a entrega da própria fonte
oficial por HTTPS: sem checksum de terceiro, não há prova criptográfica do artefato
baixado. E o custo operacional é a cadência: sem ela, a releitura não acontece e a
política vira lembrete. O número da versão continua existindo no relatório, mas como
diagnóstico, nunca como critério de aprovação.

**Como reverter.** Voltar a fixar versão exigiria três coisas ao mesmo tempo:
desligar a atualização automática, declarar a versão no arquivo de configuração e
manter uma homologação por número que alguém precisa refazer a cada release do
fornecedor. As três juntas são a política anterior inteira, e ela foi trocada por
medição — reverter uma sem as outras duas produz o pior estado: número declarado que
ninguém confere, com o site atualizando sozinho por baixo.

---

## 6. Canal MCP são dois plugins, e o risco é aceito como política

**Decidido.** O canal exige o par: o servidor (`wp-mcp-ultimate`) e o complemento
(`wp-mcp-ultimate-complemento-fator3`, artefato nosso). Os dois são instalados por
origem `url` declarada, com `pasta_esperada` e host em lista fechada — `plugins.embarcados`
está vazio, e o complemento, que já viajou dentro do bundle, deixou de viajar (decisão 15).
O servidor expõe as rotas tipadas e **nenhuma** rota de arquivo ou de banco; as doze rotas
de arquivo e banco vêm do complemento. A checagem `mcp.canal_configurado` confere as rotas
**pelo nome**, não a presença dos plugins, e tem piso obrigatório: instalação com servidor
e sem complemento precisa reprovar. Desde a 1.0.6, quem deriva esse veredito é uma unidade
só, e `mcp.canal_exposto` é rótulo separado, porque rota **registrada** e rota **exposta
por MCP** são fatos diferentes (decisão 17).

**Por quê.** Sem o complemento, quatro linhas da matriz de alocação — `theme.json`,
`templates/` e `parts/`, o `site-core` e o bump de versão do `style.css` — não têm via
de execução pelo agente, e a manutenção estrutural volta a depender de acesso humano
por FTP. Não é preferência de ferramenta: é a diferença entre a fase de manutenção
existir e não existir.

**O que custa, dito onde custa.** As rotas de arquivo gravam PHP no servidor. O par
autenticado é, por construção, execução remota de código atrás de uma credencial. A
lista de options protegidas é trava contra acidente e disciplina de operação, **não
fronteira de segurança**: quem edita o código do `site-core` pela rota de arquivo
alcança o filtro que a implementa. A fronteira real é o usuário dedicado, a Application
Password e as travas do próprio canal — sintaxe de PHP conferida antes de gravar, hash
esperado na escrita, backup com restauração e escrita de banco em duas fases.

**Decisão sobre o risco.** Aceito **como política**, com responsável e data
registrados na entrega, em vez de reaberto a cada site. Cliente que recuse é exceção
declarada, e o que ele perde é nomeado antes da entrega: sem canal não há fase de
manutenção por agente, e toda mudança estrutural volta a depender de acesso humano ao
servidor.

**Como reverter.** O desligamento é caminho de operador e está documentado no
`README.md`: interruptor na tela do complemento, filtro equivalente no código, e a
revogação da Application Password do usuário dedicado — as três, porque desligar o
canal sem revogar a credencial deixa metade da porta aberta. Reversão permanente é a
exceção declarada acima, com a perda nomeada. E o canal precisa ser **único** no site
para que o interruptor feche tudo: duas cópias do complemento com slugs diferentes são
dois diretórios de backup e duas chaves de desligamento, com a tela dizendo que está
fechado enquanto a outra cópia continua aberta.

---

## 7. Regime de formulário por e-mail declarado e inativo

**Decidido.** O `site.json` declara dois regimes de formulário. O de WhatsApp
(`contato-whatsapp`) está ativo, com escopo de site inteiro. O de e-mail
(`landing-cf7`) está declarado com `ativo: false` e com o motivo escrito no próprio
arquivo: a base não instancia fluxo por e-mail, e o regime fica disponível para o
agente que precisar dele.

**Por quê.** Apagar o regime tornaria a estrutura de configuração incompleta para
quem parte desta base e precisa de formulário por e-mail — e ele voltaria escrito à
mão, sem os campos obrigatórios, sem página de confirmação e sem critério de contato
declarado. Deixá-lo ativo e vazio seria pior: um formulário que aceita envio e não
entrega em lugar nenhum.

**O que custa.** Uma entrada de configuração sem execução nesta base. O risco é
exatamente o da chave sem consumidor, e o mecanismo que o cobre é o mesmo: o detector
geral cruza toda chave declarada contra o código que aplica, e `ativo: false` é um
valor lido, não uma seção ignorada. O comportamento degradado também está declarado:
bloqueado com mensagem, sem envio silencioso.

**Como reverter.** Trocar `ativo` para verdadeiro, preencher `contato.email_leads`,
apontar `pagina_ref`, e a página de confirmação declarada passa a ser criada. A
ativação exige exercitar o envio real na verificação — comportamento se prova
exercitando, e formulário conferido de olho é o defeito do menu compacto com outro
nome.

---

## 8. Fontes de sistema em vez de webfont auto-hospedada

**Decidido.** O `theme.json` declara duas famílias em pilha nativa do sistema
(`sistema` e `mono`) e **nenhum** `fontFace`. A chave `tema.fontes` do `site.json` vem
vazia e não há binário de fonte no pacote.

**Por quê.** O motivo é factual, não estético: não existe arquivo de fonte para
embutir. Referenciar um `.woff2` inexistente produziria 404 em toda página — pior que
a pilha do sistema, que renderiza sem requisição nenhuma. A regra do método continua
valendo e não foi revogada: fonte auto-hospedada, `font-display: swap`, versão no nome
do arquivo, cache imutável escopado no diretório de assets do tema, e **nunca** Google
Fonts por CDN, porque a chamada ao CDN entrega o IP do visitante a um terceiro sem base
legal.

**O que custa.** O site não tem tipografia de marca: ele renderiza com a fonte de
interface do sistema operacional de cada visitante, o que significa desenho de letra
diferente entre plataformas e métricas que variam. Para um projeto com identidade
tipográfica definida, isso é perda visível.

**Como reverter.** Três passos, nesta ordem: colocar o `.woff2` em `fontes/tema/assets/`,
declarar o `fontFace` na família correspondente do `theme.json` com o preload apenas da
face do primeiro render, e listar o arquivo em `tema.fontes` no `site.json`. Antes
disso, conferir a licença: webfont comercial tem licença por domínio e por formato, e
fonte do site de referência não é automaticamente licenciável — sem sustentação, o
caminho é equivalente aberto com métricas próximas, com a troca declarada no relatório.

---

## 9. Rota de origem obrigatória no `site-core`

**Decidido.** O módulo `rota-origem` é obrigatório, não opcional. Ele expõe uma rota
que faz o próprio servidor pedir a própria URL pública e devolve status, cabeçalhos e
corpo, com o resultado carimbado com a fase `origem`. Restrição fechada: apenas
caminho do próprio `home_url()`, host validado, redirecionamento não seguido, destino
livre recusado pelo nome.

**Por quê.** A regra de leitura de volta precisa de mecanismo quando a rede do agente
é barrada — firewall de aplicação, TLS reiniciado para cliente sem navegador, resposta
de excesso de requisições. Regra sem mecanismo é lembrete, e foi por isso que a rota
virou módulo obrigatório em vez de recomendação.

**O que custa.** Dois custos, e o segundo é o importante. O primeiro: uma rota a mais
na superfície do site, mitigada por capability `manage_options` e nonce ou credencial
do canal. O segundo: o resultado dela é evidência de **origem**, nunca do que o
visitante recebe — o loopback tende a bater na origem e a pular exatamente a camada de
cache ou CDN que produz o defeito mais caro deste tipo de projeto. Apresentar
resultado dessa rota como evidência de visitante é reprovação por desenho, e existe
piso para isso.

**Como usar o custo a favor.** A diferença entre a leitura de origem e a leitura
externa é o próprio diagnóstico de cache: tamanhos e hashes iguais nas duas apontam
para valor que varia por requisição; diferentes apontam para cache servindo versão
velha. O relatório imprime o discriminante em vez de escolher a causa.

**Como reverter.** Remover o módulo do registro único do `site-core`. A consequência
precisa ser declarada junto: sem ele, quando a rede do agente estiver barrada, a
leitura de volta não tem segundo caminho e o item correspondente fecha BLOCKED até um
verificador externo fechá-lo. Não é reversão barata — é troca de um instrumento
limitado e rotulado por nenhum instrumento.

---

## 10. Duas exceções de `wp:html` no tema, e nenhuma no conteúdo

**Decidido.** O tema tem exatamente duas exceções de `wp:html`, ambas declaradas em
`tema.wp_html_excecoes` com motivo escrito: o link de pular para o conteúdo em
`parts/header.html` e o botão do controle de consentimento em `parts/footer.html`. O
conteúdo editorial — `content/pages/` e `content/posts/` — não tem nenhuma, e a
navegação nunca é uma delas.

**Por quê.** O link de pular precisa ser o primeiro elemento do DOM e sair da tela até
receber foco: nenhum bloco nativo produz esse par de requisitos. O botão de
consentimento tem comportamento próprio do `site-core` e não tem bloco nativo
equivalente, e ele precisa existir em toda página por construção — que é o que morar
na part do rodapé garante.

**O que custa.** Dois trechos de markup que o editor não valida como bloco e que
mudam apenas por edição de arquivo, com bump de versão do tema. Em troca, o contrato
de nomes entre tema e plugin fica fixo: classe e atributo de dados idênticos aos que o
`site-core` procura, com o suporte de tema declarado para o plugin **não** imprimir um
segundo controle no rodapé.

**Como reverter.** Só com bloco nativo equivalente. Enquanto ele não existir, a
reversão correta é a que já está no código: o `site-core` mantém markup de reserva
idêntico, usado quando o tema **não** declara o suporte — de modo que trocar o tema não
apaga o controle de privacidade da página.

---

## 11. Ícone do site e imagem social em PNG, e o logo em PNG com o vetor preservado

**Decidido (revisto na 1.0.2).** `assets/` embarca quatro binários: `logo.png` em
512 × 512 com fundo transparente para `custom_logo`, `logo.svg` com o papel declarado
`marca_inline`, `favicon.png` em 512 × 512 para `site_icon` e `social.png` em
1200 × 630 para `og_default_image`. Os dois bitmaps são **PNG**, e não WebP nem AVIF. Todos os três são
gerados a partir da paleta já declarada no `theme.json` — `inverso`, `primaria` e `base`
—, sem introduzir cor nova; o SVG não carrega cor literal nenhuma, porque o desenho usa
`currentColor` e herda a cor do contexto em que for colocado.

**Por quê.** O documento do método pede WebP ou AVIF salvo justificativa escrita no
relatório, e a justificativa aqui é de **consumidor**, não de peso. Nenhum dos dois
papéis é servido ao navegador do visitante como imagem de conteúdo: o `site_icon` é lido
pelo próprio WordPress, que gera e serve os tamanhos derivados do ícone, e a imagem
padrão de Open Graph é lida por rastreadores de redes sociais e por aplicativos de
mensagem. O suporte a WebP nesses dois consumidores é inconsistente, e o modo de falha é
o pior possível: o ícone ou a prévia simplesmente não aparece, sem erro em lugar nenhum,
sem linha em log e sem nada para uma checagem observar do lado do site. PNG é o formato
que os dois consomem de forma confiável. **A revisão da 1.0.2 tirou o logo de fora dessa discussão pelo lado errado.** O papel
`custom_logo` exige um **anexo na biblioteca de mídia**, e o WordPress recusa SVG na
biblioteca por padrão — "Sem permissão para enviar esse tipo de arquivo" foi a mensagem
medida. A recusa está certa: SVG é vetor de XSS, e habilitar o MIME no site seria uma
decisão de segurança que este pacote não toma por conta de um logotipo. Então o papel
`custom_logo` passou para `logo.png`, desenhado com os mesmos slugs `inverso`, `primaria`
e `base`, com fundo transparente. O `logo.svg` **continua no pacote**, agora com o papel
declarado `marca_inline`: ele é servido pelo tema no próprio markup, escala sem perda e
não passa pela biblioteca. A unidade daquele item fecha N/A com a condição declarada, e
não some do relatório.

**O que custa.** Peso maior do que os dois bitmaps teriam em WebP — nesta leitura, 2 790
bytes no ícone e 3 272 bytes na imagem social, contra o que a mesma arte pesaria no
formato moderno. É custo aceito e pequeno em termos absolutos, mas ele existe e não é
disfarçado: a decisão troca bytes por previsibilidade de renderização em software de
terceiro que não temos como instrumentar. Custo secundário: dois formatos convivem no
mesmo diretório, e quem acrescentar imagem **de conteúdo** no futuro não deve tomar este
precedente como regra — imagem de conteúdo é servida ao navegador e volta a seguir a
regra de WebP ou AVIF.

**Como reverter.** Trocar os bitmaps por WebP exige, na mesma mudança: substituir os
arquivos em `assets/`, atualizar os caminhos em `midia` no `config/site.json`, atualizar
as linhas correspondentes de `suite/inventario.tsv` e conferir os dois consumidores de
verdade — o ícone renderizado pelo WordPress e a prévia lida por um rastreador externo.
A conferência é obrigatória e não é opcional na reversão: é exatamente a evidência que
falta hoje para tomar a decisão contrária, e trocar o formato sem ela seria substituir uma
justificativa escrita por uma suposição.

**Nota de idempotência.** Troca de ativo é caso de primeira classe: a implantação importa
o arquivo novo **antes** de remover o antigo e reaponta a referência, de modo que uma
falha no envio deixa o site com a versão anterior em vez de sem imagem. Remoção do antigo
só com propriedade exclusiva comprovada; caso contrário ele é marcado obsoleto e relatado.

---

## 12. As fontes do tema e do `site-core` moram em `fontes/`

**Decidido.** `tema/` e `site-core/` saíram da raiz do pacote e passaram a ser
`fontes/tema/` e `fontes/site-core/`. `fontes/` não contém nenhum `.php` diretamente.
A regra virou executável em `pacote.sem_cabecalho_de_plugin_aninhado`: a raiz precisa
ter **exatamente um** `.php` com `Plugin Name:`, e **nenhum** `.php` a um nível de
subdiretório pode ter outro.

**Por quê.** Não é organização, é correção de um defeito medido e determinístico.
`get_plugins( '/implantador-base' )` varre a raiz do plugin **e um nível de
subdiretório**. Com o `site-core` em `site-core/f3base-site-core.php`, aquela varredura
via dois cabeçalhos — "Implantador Base F3" e "F3 Base Site Core" —, ordenava por
**Name**, e "F3 Base Site Core" vinha antes. `Plugin_Upgrader::plugin_info()` devolve
`array_keys(...)[0]`, então o link "Ativar plugin" da tela de instalação carregava
`implantador-base/site-core/f3base-site-core.php`. Aí `validate_plugin()` chama o
`get_plugins()` completo, que só enxerga um nível a partir de `wp-content/plugins/`, não
acha um caminho de dois níveis e devolve exatamente "The plugin does not have a valid
header." Ativar pela **lista de plugins** funcionava, porque ali o link é o arquivo
principal — e foi essa assimetria que fez a 1.0.1 registrar o defeito como
intermitência de cache e recomendar "ative de novo". Não era cache: era ordenação.

**O que custa.** Um nível a mais em todo caminho de fonte, e um custo real de migração
pago uma vez: inventário, empacotador, checagens do tema, entregáveis, resolução de
caminho em `class-f3base-imp-plugins.php` e `class-f3base-imp-entrega.php`, o preflight
que soma o tamanho do pacote, as fixtures do piso e a árvore do leia-me. Custo residual:
quem vier de fora e procurar `tema/` na raiz não acha de primeira.

**Como reverter.** Só reverte quem estiver disposto a reintroduzir o defeito: mover as
duas pastas de volta faz o segundo cabeçalho voltar ao alcance de `get_plugins()`, e o
detector reprova a rodada nomeando o arquivo. Reverter de verdade exigiria outra saída
para o mesmo problema — por exemplo, embarcar tema e `site-core` **só** como zip e não
como árvore de arquivos —, e essa é uma decisão nova, não uma reversão desta.

---

## 13. Backup de instalação anterior com ponto na frente

**Decidido.** A troca controlada de diretório preserva a versão anterior em
`.f3base-anterior-<slug>-<ts>`, irmã do destino, e não mais em
`<destino>-f3base-anterior-<ts>`. A etapa de atualização automática ignora
explicitamente todo diretório que comece com ponto e **diz no relatório quantos
ignorou**.

**Por quê.** `get_plugins()` pula todo diretório cujo nome começa com ponto, e
`search_theme_directories()` faz o mesmo com temas. Sem o ponto, a preimagem virava um
plugin aos olhos do WordPress: o log de uma execução real listou
`f3base-site-core-f3base-anterior-1788152131` entre os plugins com atualização
automática ligada. Um diretório de backup não é código em uso, não deve receber
atualização automática e não deve aparecer em listagem de plugin.

**O que custa.** O backup fica menos visível para quem lista o diretório sem `-a`, e é
por isso que o caminho continua saindo por escrito no journal e na mensagem da unidade.
A filtragem explícita na etapa de auto-update é redundante com o comportamento do
núcleo, e essa redundância é deliberada: depender do comportamento de terceiro para uma
regra nossa é o mesmo que não ter a regra.

**Como reverter.** Tirar o ponto do prefixo em `caminho_do_backup()`, que é o ponto
único onde o nome é montado. A reversão traz de volta o diretório órfão nas listagens, e
a etapa de auto-update passará a reportar zero ignorados enquanto o núcleo volta a
enxergar a preimagem como plugin.

---

## 14. Destino de formulário vazio é BLOCKED, e preenchido-e-inválido continua FALHA

**Decidido.** A etapa de formulários passou a ter três saídas, e elas não são
intercambiáveis: chave de destino declarada e **vazia** fecha **BLOCKED** nomeando a
chave de `config/site.json` a preencher; chave **preenchida** com valor que o regime não
aceita continua **FALHA**; entrada sem `destino` declarado também é **FALHA**. O
veredito mora numa função pura, `F3Base_Imp_Lotes::veredito_destino()`, e os três ramos
são exercitados em `formulario.veredito_destino`.

**Por quê.** `contato.whatsapp_e164` nasce vazia no template **por desenho** — é dado do
projeto, não defeito do pacote. A regra do documento é explícita: pré-condição ausente
NUNCA é FALHA, é BLOCKED com o motivo. Um relatório que grita FALHA por dado de projeto
ausente treina o leitor a ignorar FALHA, que é o pior resultado possível de uma suíte.

**O que custa.** BLOCKED interrompe a cadeia dependente, e essa é a consequência
deliberada: com a chave vazia, a execução para naquela unidade, as etapas seguintes
(cadência, entrega e encerramento) não rodam, e o implantador **não** se autodesativa. A
saída do operador é preencher a chave e iniciar uma execução nova — que é exatamente o
que deveria acontecer, porque uma entrega que se declara concluída com o destino do lead
em branco é uma entrega que mente.

**Como reverter.** Voltar `etapa_formularios()` a `avaliar()` com um booleano só. A
reversão devolve a FALHA por dado de projeto ausente e desfaz a distinção entre "falta
preencher" e "está errado", que é a distinção inteira desta decisão.

---

## 15. Origem de plugin por URL, em https, com precedência declarada

> **Atualizada na 1.0.19.** A lista fechada de hosts que este título dizia saiu do pacote;
> o que ficou está na decisão 45, e é ela que explica por que a lista nunca foi o controle
> que aparentava ser. O resto desta decisão continua valendo como escrito.

**Decidido.** Cada entrada de `plugins.instalaveis` declara a `origem`, e a resolução
tenta três caminhos nesta ordem: o slot embutido `assets/plugins/<slug>.zip`, sem rede; a
URL declarada na própria entrada, **em https**; e o WordPress.org. Toda entrada de
origem `url` também declara `pasta_esperada`, e a pasta criada pelo instalador é lida do
resultado e reconciliada com ela antes da ativação.

**Por quê.** O servidor MCP e o complemento do canal não existem no WordPress.org, e a
única origem prevista era ela: o canal fechava BLOCKED e a fase de manutenção não
existia. A precedência com o slot na frente resolve o caso offline sem mudar uma linha de
configuração — quem não tem rede põe o zip no slot. E a reconciliação de pasta existe
porque zip de código-fonte de repositório extrai como `<repo>-main`, e ativar pelo slug
procurava em um diretório que não estava lá.

**O que custa.** Baixar código executável de um host que não é o repositório oficial é
uma fronteira de confiança a mais, e ela é real. O que a guarda entrega hoje: HTTPS
obrigatório em todos os saltos — autenticidade de origem e integridade em trânsito — e o
digesto, que amarra o BYTE baixado. O que ela não entrega: escolher por você de qual
projeto o artefato vem. Isso é a URL declarada, e quem a escreve é quem monta o projeto.
Custo secundário: origem por URL não anuncia versão como o WordPress.org anuncia — a
versão precisa ser lida do cabeçalho dentro do artefato já baixado, e isso é uma leitura
a mais em todo ciclo.

**Como reverter.** Trocar a `origem` da entrada para `wordpress.org` só faz sentido
quando o artefato passar a existir lá. Enquanto não passar, a reversão real é o slot:
colocar o zip em `assets/plugins/<slug>.zip` remove a rede do caminho sem tirar o plugin
do catálogo. Apagar a `url` da entrada bloqueia aquela origem, com o BLOCKED nomeando a
chave que falta — e o efeito, declarado, é o canal MCP voltar a fechar BLOCKED.

---

## 16. Dependência declarada por unidade, e diagnóstico que não depende de ninguém

**Decidido.** O plano de execução tem um grafo de dependências declarado por grupo em
`F3Base_Imp_Plano`, e a suspensão em cascata depois de um BLOCKED segue o fecho
transitivo desse grafo. Os grupos `mcp`, `entrega` e `encerramento` declaram lista vazia
de dependências, de propósito.

**Por quê.** O orquestrador abortava, depois de um BLOCKED, tudo que vinha depois — a
dependência era a POSIÇÃO na lista. `formularios` fechou BLOCKED por um destino de
WhatsApp vazio, que é o estado correto e esperado desta base, e derrubou `cadencia`,
`entrega` e `encerramento`, nenhuma das quais depende do destino de um formulário. O
efeito prático foi o pior possível: `mcp.canal_configurado` — a única linha que diria ao
operador se o canal está exposto — não rodou, e o operador ficou olhando "Servidor MCP
não detectado" na tela do complemento sem nenhuma evidência do nosso lado. Unidade que
diagnostica não pode ser suspensa pelo que ela diagnostica.

**O que custa.** Uma tabela a mais para manter, e ela é fácil de errar em silêncio:
dependência para grupo inexistente viraria aresta que some. O custo é pago com detector —
`estatica.plano_dependencias` roda a própria função de conferência contra o pacote e
contra as fixtures do piso, reprovando grupo inexistente, autoloop e ciclo. Segundo
custo: "independente" passou a ser afirmação declarada, e afirmação declarada errada é
pior que ordem implícita — uma unidade que realmente dependesse de outra e fosse
declarada livre rodaria sobre estado incompleto.

**Como reverter.** Voltar à cascata por posição significa apagar a tabela e deixar o
orquestrador abortar tudo o que vem depois do primeiro BLOCKED. A consequência está
medida e nomeada acima: o diagnóstico do canal desaparece justamente na execução em que
ele é a dúvida. Não há caminho de reversão que preserve isso.

---

## 17. Uma fonte de verdade por veredito de gate

**Decidido.** A unidade `mcp` é o único ponto do pacote que deriva os dois vereditos de
canal — `mcp.canal_configurado` e `mcp.canal_exposto`. Ela grava o que mediu no registro
da execução, e a entrega e o encerramento **leem** esse registro em vez de recalcular.
Sem registro, o estado é BLOCKED dizendo que a unidade não rodou.

**Por quê.** A linha 14 de um relatório real dizia que as 12 rotas estão registradas e há
servidor MCP ativo expondo-as (OK), e a linha 41 do MESMO relatório dizia que o canal não
está exposto (FALHA). Não era o site oscilando: eram duas implementações do mesmo
veredito — a unidade media pelas habilidades registradas, somando Abilities API e rota
REST, e o encerramento recalculava por conta própria a partir da checagem antiga, que só
enxerga rota REST. Junto com isso ficou declarada uma distinção que o relatório precisava
preservar: **rota registrada** e **rota exposta por MCP** são fatos diferentes, e o
estado do meio — registradas e não expostas — precisa sair com esse nome, não como
"canal incompleto".

**O que custa.** Um estado a mais no banco durante a execução, e uma ordem que passou a
importar: quem lê precisa rodar depois de quem grava. O caso em que a unidade não roda
deixou de produzir um veredito e passou a produzir BLOCKED — mais linhas bloqueadas no
relatório, e é o preço certo: BLOCKED nomeado vale mais que um número recalculado por
quem não mediu.

**Como reverter.** Não há reversão sensata: recalcular em dois lugares é o defeito. O que
existe é extensão — outro veredito de gate entra na mesma lista, com um único derivador,
e `estatica.gate_fonte_unica` é o detector que reprova o segundo derivador de qualquer um
deles.

---

## 18. Slug declarado obrigatório, e slug determinístico para o anexo gerenciado

**Decidido.** Toda entrada de `paginas` e de `posts` declara `slug` não vazio, e nenhum
se repete entre elas — a home passou a `inicio`. Todo anexo gerenciado recebe slug
determinístico derivado do prefixo técnico e da referência lógica, declarado no sideload
e não deduzido do título; o slug anterior é liberado antes da troca e fica gravado em
`_f3base_old_slug` para o `site-core` redirecionar.

**Por quê.** Sem `post_name` declarado o núcleo deriva o slug do título e desambigua em
silêncio. Para tipo hierárquico, `wp_unique_post_slug()` consulta
`post_type IN ('page','attachment')` — ou seja, um anexo pode tomar o slug de uma página.
Foi o que aconteceu: três itens de mídia com o mesmo `alt` produziram `metodo-f3`,
`metodo-f3-2` e `metodo-f3-3`, e um deles tirou o slug da home. A leitura de volta
reprovava depois, com a causa longe do sintoma.

**O que custa.** Duas coisas. A configuração ficou mais verbosa: `slug` deixou de ser
opcional em toda entrada, e o detector `config.slug_declarado` reprova a omissão. E a
troca de um binário de mídia passou a mexer no slug do anexo anterior — o anterior não
sai do site, mas passa a viver sob outro nome, e é por isso que `_f3base_old_slug` é
gravado no mesmo passo. Sem essa gravação, um link para o arquivo antigo quebraria.

**Como reverter.** Não há reversão de "slug declarado" que não reintroduza a colisão
silenciosa. O que se pode mudar é o slug de uma entrada específica: trocar o valor no
`config/site.json` faz o gravador renomear e registrar o anterior para redirecionamento,
que é o mesmo mecanismo, usado de propósito.

---

## 19. Dois tetos declarados: cópias preservadas e troca de artefato idêntico

**Decidido.** As cópias preservadas de cada troca de diretório têm teto por slug, vindo
de `plugins.backups_preservados` — hoje 2. Acima do teto, as mais antigas saem do disco
na unidade de poda, **nomeadas**, e a operação entra no journal. E a troca de diretório é
**pulada** quando o artefato disponível é idêntico ao instalado, com a versão lida do
cabeçalho dentro do próprio artefato quando a origem não a anuncia.

**Por quê.** Os dois são crescimento sem teto, medidos em execuções sucessivas: o disco
acumulando uma cópia por execução, e a troca sendo refeita a cada execução porque origem
por URL não anuncia versão e todo plugin de origem `url` caía no ramo "versão não
anunciada". Preservar a instalação anterior é desenho correto; preservar todas elas para
sempre não é.

**O que custa.** A poda é irreversível por natureza — o diretório sai do disco, e o
journal registra a operação sem poder desfazê-la. É por isso que o teto vem da
configuração e nunca de número escrito no código, que a remoção é por slug e da mais
antiga para a mais nova, e que o que sai sai nomeado no relatório. Custo da segunda
regra: pular a troca quando o artefato é idêntico significa confiar na versão do
cabeçalho; artefato com cabeçalho mentindo sobre a própria versão não seria trocado.

**Como reverter.** Subir `plugins.backups_preservados` guarda mais gerações; baixar para
zero desliga a preservação e passa a manter só a instalação corrente. Para forçar a troca
de um artefato idêntico, o caminho é subir a versão no cabeçalho do artefato — que é a
mesma disciplina de bump de versão que o tema já segue, e não uma exceção.

---

## 20. Conteúdo publicado que o pacote não gerencia: WARN, nunca remoção

**Decidido — e com UMA exceção aberta na 1.0.17, declarada na decisão 31.** Página ou
post publicado que não tem `_f3base_managed_id`, não consta de `paginas` nem de `posts`
e não entrou sob gestão por adoção declarada é **relatado em WARN**, nomeado, e não é
tocado. A exceção é estreita e tem discriminante próprio: o conteúdo de exemplo do
WordPress que **ainda é** o que `wp_install_defaults()` criou vai para a lixeira. Tudo o
mais — inclusive o objeto que ocupa o slug de exemplo e deixou de ser exemplo — continua
sob esta decisão.

**Por quê.** Duas obrigações opostas, e as duas valem. Não se apaga: remover conteúdo
publicado que o pacote não gerencia, sem autorização, é perda sem registro — e o que
parece página de exemplo do núcleo pode ter virado página de verdade, com link apontando
para ela. E não se cala: até esta release o pacote nem relatava, e o operador entregava
um site com `Sample Page` e `Hello world!` publicados sem ninguém dizer nada. A remoção é
decisão do projeto; dizer que ela existe é obrigação do implantador.

**O que custa.** Uma linha WARN em toda execução de um site que tenha conteúdo externo
publicado — e um site com muito conteúdo não gerenciado produzirá uma linha que o
operador vai aprender a ignorar. É o custo aceito: WARN não é gate, não impede a
autodesativação e não reprova nada. O site não está defeituoso, está com uma decisão em
aberto.

**Como reverter.** Duas saídas, e as duas são decisão declarada: adotar o conteúdo,
trazendo-o para `paginas` ou `posts` com `adotar_existente`, o que faz o WARN sumir
porque ele passa a ser gerenciado; ou removê-lo à mão no wp-admin, que é onde uma remoção
com autor e responsável deve acontecer.

---

## 21. Permalinks: aplicar a estrutura declarada e COBRIR o que muda de endereço

**Decidido — e REVISADO duas vezes, na 1.0.11 e na 1.0.17.** A decisão original desta
entrada foi `ambiente.permalinks_decisao` nascer em `manter-existente`: qualquer
divergência de estrutura fechava BLOCKED sem escrita. A 1.0.11 trocou o padrão por
`aplicar-se-seguro`, que MEDE antes de decidir. A 1.0.17 trocou de novo, e o padrão hoje
é **`aplicar-e-cobrir`**: aplica a estrutura declarada **e grava 301 do caminho antigo
para o novo de todo conteúdo publicado que muda de endereço — gerenciado por este pacote
ou não**. O par entra na união declarada de `f3base_redirects` com origem própria, pelo
mesmo produtor único das outras fontes, e o par cujo caminho **não** muda continua sendo
descartado, porque redirecionar um endereço para ele mesmo é laço: `/sample-page/` sob
a estrutura declarada é exatamente esse caso e não pode ganhar par — páginas não recebem
o prefixo dos posts, e o caminho delas não muda quando ele entra. O relatório **nomeia** cada
URL coberta em vez de contá-las. Os três valores anteriores continuam declaráveis, com o
comportamento de sempre.

As revisões estão escritas AQUI, na entrada original, e não em entradas novas: decisão
superada que fica de pé no registro é a mesma família de defeito que o carimbo velho em
documento entregável — o leitor encontra a afirmação errada e não tem como saber que ela
caducou.

**Por quê — e a RESERVA QUE FOI APOSENTADA na 1.0.17.** Mudar a estrutura de permalinks
reescreve a URL de todo conteúdo publicado de uma vez. Num site que já tem links, índice
de busca e campanhas apontando para as URLs antigas, é a mudança mais cara que uma
execução pode fazer em silêncio — e por isso o padrão anterior recusava aplicar diante de
publicado não gerenciado com URL de caminho. A justificativa da recusa era: **este pacote
não escreve redirecionamento para conteúdo que não gerencia**.

Essa reserva foi aposentada, e o motivo é o que ela confundia. A reserva é boa para
escrita **DESTRUTIVA** — apagar, sobrescrever, promover status de objeto alheio —, e
estava sendo aplicada **por analogia** a uma escrita que não destrói nada. Um par de
redirect é **aditivo e reversível**: não altera o objeto de ninguém, não apaga nada, não
muda um byte do conteúdo, e some junto com a option quando a option some. O que a recusa
comprava era zero; o que ela custava era entregar o site com a estrutura de permalink que
**ninguém escolheu**, por causa de duas páginas que o próprio WordPress cria em toda
instalação. Dano maior do que a reserva evitava.

A orientação que decidiu isto é explícita: o implantador deve realizar todas as
modificações necessárias para fazer a página funcionar, alterando conteúdo preexistente
se preciso. Medir, recusar e devolver ao operador uma lista de opções para escolher à mão
é exatamente o passo manual que este pacote existe para eliminar.

**O que custa.** Uma escrita a mais na option `f3base_redirects` por objeto de terceiro
que mudou de endereço — cada par nomeado no relatório, cada um carimbado com a origem
`computado:wordpress.permalinks`. E custa uma responsabilidade nova: o pacote passa a
manter no ar o endereço antigo de conteúdo que não é dele. É responsabilidade barata,
porque o mecanismo é o do `site-core` que já existia, casado em `template_redirect` com
prioridade 1, antes do 404.

**Como reverter.** Declarar `aplicar-se-seguro` devolve o comportamento da 1.0.11 —
aplica só quando nenhum publicado não gerenciado tem URL de caminho, e fecha BLOCKED
nomeando os objetos quando tem. `aplicar-declarada` aplica sem cobrir terceiro.
`manter-existente` não aplica nunca. Para desfazer a cobertura já gravada, remover os
pares da option: eles não deixam rastro em nenhum objeto, que é a propriedade que
autorizou gravá-los.

---

## 22. A política de privacidade é declarada para produção, e uma guarda medida decide

**Decidido.** `paginas[privacidade].status` passa a `publish`, como o de toda página
deste pacote, e o status EFETIVO passa a sair de um produtor único —
`F3Base_Imp_Conteudo::status_efetivo_de_pagina()`, declarado na âncora
`produtor_de_status_de_pagina()` e conferido por `estatica.pagina_status_fonte_unica`.
Esse produtor rebaixa a política para `draft` enquanto `razao_social`, `documento` ou
`endereco` de `contato.controlador` estiverem vazios, e o registro da execução nomeia
**quais** estão vazios e o caminho de saída: preencher e reexecutar, sem passo manual.
A checagem `privacidade.controlador_identificado` fecha BLOCKED nesse caso, OK quando a
qualificação aparece no conteúdo lido de volta do objeto, e FALHA quando as chaves estão
cheias e a qualificação não está no texto servido. `encarregado` é opcional pelo art. 41:
vazio, o texto diz que o canal de contato do site recebe os pedidos; preenchido, a
redação nominal entra no lugar. As duas redações moram no arquivo de conteúdo, em blocos
que se excluem pela condição declarada no atributo, e nenhuma é escrita em PHP.

**Por quê.** A regra do dono é categórica: toda configuração do implantador já cria um
site pronto para produção e para ser indexado; quem não quiser muda a chave à mão. A
1.0.12 aplicou isso à indexação e deixou UMA exceção declarada pelo próprio agente e
nunca ratificada — a política de privacidade entregue em estado não público, em silêncio.
A exceção tinha um motivo real: o texto da página identificava o controlador com valores
que só o operador tem, e política publicada sem dizer quem é o controlador é notificação
deficiente na face do art. 9º da LGPD. Mas motivo real não autoriza decisão calada, e a
1.0.12 chegou a um estado pior que os dois: a configuração já dizia `seo.indexar: true`
enquanto o último parágrafo do texto afirmava o contrário sobre a mesma página.

A correção é a mesma inversão da indexação. A intenção declarada é produção; o que segura
é uma **guarda medida**, que nomeia a si mesma, o valor observado e a saída — o mesmo
formato de `contato.whatsapp_e164`. E a guarda não é uma espera por revisão jurídica: a
revisão continua sendo do responsável pela operação, e o texto da página diz isso.

**O que custa.** Uma pré-condição a mais no template, e ela é visível: em instalação
recém-configurada, `privacidade.controlador_identificado` fecha BLOCKED e a unidade
`wordpress.paginas_especiais` é promovida a BLOCKED junto — exatamente como
`formularios.regimes` já fica por causa de `contato.whatsapp_e164`. Nenhuma das duas
impede a autodesativação, porque o gate de aplicação lê entregáveis, não unidades. Custa
também um mecanismo novo de conteúdo: marcador nomeado e bloco condicional no arquivo
editorial. O risco desse mecanismo é o marcador sobreviver até a página publicada, e é
por isso que a leitura de volta o procura no conteúdo servido e fecha FALHA se o achar.

**Como reverter.** Declarar `paginas[privacidade].status` como `draft` devolve a página
ao estado não público por decisão do PROJETO — o produtor nunca promove o que foi
declarado, e a diferença em relação ao que esta release corrigiu é que agora a decisão
está escrita na configuração e não escondida no código. Para desligar a guarda sem
desligar a página, basta preencher as três chaves. Remover a guarda inteira é apagar o
ramo do produtor, e aí a política volta a poder ser publicada sem identificar o
controlador: é a reversão que a LGPD desaconselha, e ela precisa ser deliberada.

---

## 23. A identidade da política mora no papel da página; o número em documento é gerado

**Decidido.** Três correções que a revisão da 1.0.13 transformou em defeito, e uma delas
é a que impede a recorrência das outras duas.

1. **O gate de página publicada vale para os DOIS produtores de seleção de `llms.txt`.**
   A 1.0.13 gateou `f3base_llms` pelo artefato e deixou `wpseo_llmstxt` receber
   `privacy_policy => <id>` sem gate nenhum. Agora existe um gate único —
   `F3Base_Imp_Conteudo::id_de_pagina_publicada()` — e dois produtores finos que passam
   por ele, ambos declarados na âncora que `estatica.llms_so_pagina_publicada` lê.
2. **A identidade da política mora em `paginas[*].papel`.** Ela era lida de
   `seo.llms_selecao.politica_privacidade`. A seleção do `llms.txt` passou a REFERENCIAR
   o produtor por um booleano de inclusão, em vez de possuir o fato.
3. **Número em documento entregável é gerado, não digitado.** README, MANIFESTO e
   MEMORIA-DECISOES carregam regiões geradas por leitura de disco na primeira etapa do
   comando único, e `estatica.carimbo_de_release_nos_documentos` compara o que está no
   disco com o que a medição de agora produz.

**Por quê.** O item 1 tinha uma justificativa errada e vale registrá-la: o agente não
gateou o segundo produtor porque não havia medido o que o plugin de terceiro faz com o
identificador de uma página não publicada. O teste é outro — não é o que o consumidor
faz, é se ESTE pacote deve entregar o identificador de um rascunho a um slot chamado
`privacy_policy` que alimenta um arquivo publicado. Não deve, faça o consumidor o que
fizer: a escrita está errada na origem, e não é preciso medir o consumidor para saber
disso. E havia consequência para a suíte: um detector que gateia um produtor e deixa o
segundo passar promete, pelo nome, mais do que mede — compra silêncio sobre o defeito
que continua lá.

O item 2 é uma questão de onde um fato pode morar. A identidade da página de política é
exigida pelo art. 9º da LGPD e é fato do SITE. Pendurada numa chave que nomeia uma
seleção de `llms.txt`, ela ficava à mercê de uma operação legítima: desligar
`bots_ia.llms_txt` e limpar a seleção parava de gravar `wp_page_for_privacy_policy` e
derrubava a checagem legal em "condição de aplicabilidade falsa", sem nada acusar. O que
impede a recorrência não é o nome novo da chave: é a cláusula do detector que PROÍBE o
produtor de ler qualquer caminho fora de `paginas.*`.

O item 3 é o mais importante dos três, e não é sobre esta release. Da 1.0.6 à 1.0.13 os
três documentos entregáveis ficaram carimbados `1.0.6`, afirmando `ambiente.dominios_autorizados`
como gate de indexação e `manter-existente` como padrão de permalinks — os dois superados
por releases posteriores — e imprimindo contagens que a rodada da vez contradizia. Sete
releases passaram por cima disso. Corrigir os números à mão era adiar: eles envelheceriam
de novo na próxima release. O que não envelhece é a regra de que o número sai de leitura
de disco no empacotamento, e o detector que reprova quando o disco e o documento
divergem. As duas afirmações de desenho superadas entraram em
`copy_contrato.nao_podem_voltar`, que já varre o pacote inteiro.

**O que custa.** Três coisas. (a) Os documentos passam a ter regiões que não se editam à
mão: quem escrever dentro delas perde o texto na próxima rodada, e é por isso que cada
região diz, no próprio corpo, que é gerada. (b) A contagem por estado da rodada NÃO pode
entrar no carimbo, porque ela só existe depois das checagens e o carimbo é escrito antes
do bundle; ela sai como pendência nomeada apontando para `suite/rodada.json`, que é
o artefato gerado que a carrega. (c) O empacotamento passou a ESCREVER no pacote antes de
medi-lo. O risco disso é conhecido — artefato que se modifica antes de ser conferido — e
está contido por três coisas: a escrita só acontece quando o conteúdo muda, ela é a
primeira coisa da primeira etapa, e o que ela escreve é comparado de volta em etapa 2
pelo detector.

**Como reverter.** Tirar os marcadores de um documento o devolve à edição manual, e o
detector acusa a ausência deles — a reversão é possível e não é silenciosa, que é a única
forma aceitável. Voltar a identidade da política para uma chave de outra seção exige
apagar a cláusula 3 de `estatica.politica_privacidade_fonte_unica`, e aí o registro
mostra que a proteção foi removida de propósito. Tirar o gate de um dos dois produtores
exige apagá-lo da âncora, e o detector reprova na cláusula que cobra que todo produtor
declarado passe pelo gate.

## 24. WARN só existe com achado adverso; o estado sai da medição

**Decidido.** Nenhuma checagem do runtime emite WARN como retorno incondicional ou único.
Medição que validou, aplicou, declarou ou ficou dentro do esperado fecha **OK**, com o
detalhe no texto da linha; medição que encontrou algo **adverso e que não bloqueia** fecha
**WARN**, nomeando o que está adverso e a consequência. As seis emissões que saíam sempre
foram reescritas assim: `preflight.limites` compara com o piso declarado em
`ambiente.limites_minimos`; `config.schema_declarado` mede se o schema está declarado e se
houve erro de validação; `lgpd.base_legal_declarada` mede se a base legal e o prazo de
retenção existem; `config.chaves_lidas_nesta_execucao` mede se o pacote AFIRMA, em
`consumidores_declarados`, que toda chave tem consumidor; `plugins.politica_versao` mede se
as duas políticas estão declaradas; `tema.declaracoes` mede se toda fonte auto-hospedada
declarada tem arquivo no pacote.

**Por quê.** Na execução real da 1.0.14 nove checagens fecharam WARN sem achado adverso
nenhum, e cada uma promoveu a unidade dela: quatro unidades amarelas numa execução em que
nada estava errado. As frases são literais do log — "a configuração declara o schema e
validou contra ele", "política aplicada: ultima-da-fonte-oficial", "lista vazia é estado
válido" — e `preflight.limites` dizia de si mesma "fato de ambiente, relatado sem decidir
gate" enquanto promovia a unidade. É a mesma família da checagem que acusava o próprio
pacote e das 24 FALHA por ausência de terceiro: relatório que grita treina o leitor a
ignorar o grito, e essa lição já estava escrita no documento mestre — faltava valer para
WARN.

**A correção NÃO foi um sétimo estado.** Os seis são regra do contrato. O que mudou é de
onde o estado vem: da medição, não do desejo de ver a informação na tela. A informação
continua na linha; o que ela deixou de fazer é pintar de amarelo o que estava certo.

**O que custa.** Duas coisas. (a) Uma linha OK é lida com menos atenção que uma WARN, e
detalhe que só existia para ser visto — os limites do PHP, o hash da configuração — passa a
sair no corpo de uma linha resumida. É o preço de o amarelo voltar a significar alguma
coisa. (b) Um piso novo entrou na configuração: `ambiente.limites_minimos`. Piso declarado
errado produz WARN sem achado, que é o defeito que esta decisão fecha — por isso ele é
declarado por projeto e não literal no código.

**O piso.** `estatica.warn_tem_ramo_adverso` varre `includes/` e `fontes/` e acusa todo
WARN que não esteja dentro de um ramo (`if`, `elseif`, `else`, `foreach`, `for`, `while`,
`switch`, `match`, ternário) nem depois de uma cláusula de guarda que possa impedi-lo. A
fixture negativa reproduz a emissão incondicional de `preflight.limites`; a positiva traz
as duas formas legítimas. `preflight.limites_veredito` exercita os dois lados do veredito na
sonda, um achado por limite, com `max_execution_time = 0` tratado como ausência de limite —
o piso do falso positivo.

**Como reverter.** Emitir WARN fora de ramo volta a ser possível apagando o detector do
runner e do registro do piso, e aí a rodada mostra que a proteção foi removida de propósito.

## 25. Cópia preservada de cópia preservada colapsa na série do slug real

**Decidido.** `F3Base_Imp_Plugins::serie_do_nome()` normaliza a chave da série: marca de
backup embutida no resto do nome colapsa na série do slug real, com qualquer profundidade de
aninhamento, e o carimbo que sobrevive é o EXTERNO — quando aquela cópia foi criada.

**Por quê.** No site real apareceu, em `wp-content/plugins/`, o diretório
`.f3base-anterior-f3base-site-core-f3base-anterior-1788152131-1788156801`: backup de um
diretório que já era backup. Cortando o slug no último traço, a chave virava
`f3base-site-core-f3base-anterior-1788152131` — série própria, com uma cópia só, que nunca
alcança o teto de duas e portanto nunca poda. O log fechou com sete cópias preservadas e a
frase "nada acima do teto": cada palavra verdadeira e a conclusão errada. O teto de
`plugins.backups_preservados` existia e não fazia nada.

**O que custa.** A normalização assume que a marca de backup é nossa e nunca faz parte do
nome legítimo de um artefato. Um plugin de terceiro cujo diretório contivesse a marca teria
a série truncada. A marca é montada a partir do prefixo do site, e um plugin de terceiro com
esse nome já colidiria com o pacote inteiro muito antes disto.

**O piso.** `plugins.serie_de_backup_normalizada` roda a MESMA função do runtime em
subprocesso, sobre a tabela de nomes que inclui o literal medido no site e o aninhamento
duplo. A fixture negativa é a leitura anterior, com o corte ingênuo, e ela é acusada
nomeando a série fantasma; a positiva é a leitura corrigida e fica em silêncio.

## 26. O pacote é um template de criação de sites, e o site demonstrativo fica

**Decidido.** Três coisas, e a terceira é o que impede as duas primeiras de virarem mentira.

1. **Cada site recebe o próprio prefixo.** `ferramentas/renomear-prefixo.sh` reescreve tudo
   o que está preso ao prefixo — nomes de diretório e de arquivo, prefixo de classe PHP,
   text domain, slugs de tema e de plugin, options, metas, classes CSS, handles e as chaves
   de configuração que os carregam. Dois sites da operação nunca compartilham nome de tema
   nem de option. A ferramenta recusa prefixo vazio, fora de `[a-z][a-z0-9-]`, em colisão
   com o espaço de nome do WordPress ou igual ao do próprio template, e é idempotente por
   construção: a busca é sempre pelo prefixo de ORIGEM, declarado em
   `ferramentas/prefixo-do-template.tsv`, que ela não reescreve.
2. **O site demonstrativo FICA, marcado como substituível.** Ele é o exemplo funcionante de
   cada padrão, e o agente que instancia o template copia dele. A herança é DECLARADA em
   `conteudo.demonstrativo` e marcada no topo de cada arquivo de `content/`.
3. **`TEMPLATE.md`** diz, em ordem, o que o agente faz para criar um site novo, separando o
   que muda por site do que nunca se toca, com o caminho exato de cada arquivo e chave.

**Por quê `MEMORIA-DECISOES.md` não é reescrito.** Este documento narra defeitos medidos
citando diretórios e nomes que existiram em sites reais — o backup de backup acima, o
cabeçalho de plugin aninhado, a option apagada por uma segunda gravação. Trocar o prefixo
nessas frases inventaria um passado que não aconteceu: nenhum site chamado de outra coisa
produziu aqueles diretórios. Havia duas saídas — reescrever cada frase para uma forma
verdadeira nos dois prefixos, ou declarar a exceção — e a escolha foi a exceção, declarada
em `ferramentas/excecoes-de-prefixo.tsv` e conferida por `estatica.sem_residuo_de_prefixo`.
Reescrever as frases para uma forma genérica custaria justamente o que dá valor a elas: o
nome literal que alguém pode procurar no `wp-content/plugins/` de um site. O documento viaja
com o pacote como história herdada, atribuída a quem a produziu, e o site novo abre o
próprio registro.

Essa decisão teve um corolário no código: **os marcadores de região gerada perderam o
prefixo**. Com `f3base:gerado` dentro deles, o documento não reescrito ficaria com
marcadores que o gerador renomeado não encontraria mais, e a região gerada deixaria de ser
regenerada em silêncio — o defeito da 1.0.6 à 1.0.13 voltando por uma porta nova. O marcador
delimita uma região dentro dos documentos do próprio pacote, não disputa espaço de nome com
ninguém, e sem prefixo o documento é o mesmo nos dois prefixos.

**O uso correto de WARN, em oposição ao item 24.** Com `conteudo.demonstrativo = true` e
`ambiente.tipo = "producao"`, `conteudo.demonstrativo` fecha WARN nomeando as páginas que
continuam sendo do template: publicar um site de cliente com a prosa do método é achado
adverso de verdade. É a única linha amarela da rodada limpa deste pacote, e ela some no
passo em que o conteúdo é substituído.

**A saída barata está fechada.** Desligar `conteudo.demonstrativo` sem trocar o conteúdo cala
o aviso e deixa o site do template no ar com a configuração afirmando que o texto é do
cliente. `conteudo.marca_demonstrativa` acusa a divergência arquivo a arquivo na suíte, e a
guarda de publicação **recusa** o objeto em tempo de aplicação, nomeando o arquivo, a marca e
as duas saídas.

**O que custa.** (a) A renomeação acontece uma vez, a partir do template: renomear o já
renomeado não é suportado, e o texto da ferramenta diz isso. (b) A lista de exceções é uma
superfície que precisa ficar curta — hoje são quatro entradas, cada uma com o motivo escrito
ao lado, e `estatica.sem_residuo_de_prefixo` cobra que nada sobreviva fora delas. (c) O
detector só roda de verdade sobre um pacote já renomeado; enquanto `site.prefixo_tecnico` for
o prefixo do template ele fecha N/A com a condição declarada, e quem prova que ele sabe
acusar é o piso de fixture, em toda rodada.

**Como reverter.** Apagar `ferramentas/` devolve o pacote a um prefixo único e o detector de
resíduo reprova por falta do registro de origem — a remoção é possível e não é silenciosa.
Voltar `conteudo.demonstrativo` a não existir exige removê-la do schema e do `site.json`, e
aí a guarda de publicação e as duas checagens somem juntas, o que o cruzamento bidirecional
do manifesto acusa.

---

## 27. A invalidação de cache pertence a quem trocou o diretório

**Decidido.** `trocar_diretorio()` derruba o cache do núcleo para o artefato que
acabou de mover — `wp_clean_themes_cache()` para tema, `wp_clean_plugins_cache()`
para plugin — antes de qualquer leitura de volta, e a leitura de volta passa a
ser um produtor único, `leitura_de_volta_do_artefato()`, que mede o **diretório**
(`is_dir`, e o arquivo principal dentro dele) **ao lado** da API do WordPress.
Diretório ausente diz "não apareceu no disco"; diretório presente e completo com
a API discordando diz **defeito de cache**, nomeado como tal; e diretório presente
sem o arquivo principal é um terceiro fato, com mensagem própria. A quarta linha da
tabela é o piso do falso positivo: quando a API **enxerga** o artefato e o caminho
medido não o traz — site com mais de uma raiz de temas registrada —, o veredito é
ok e a mensagem registra o fato, porque a API é quem manda no "está instalado" e a
medição de disco existe para discriminar a falha, não para criar uma.

**Por quê.** A 1.0.15 foi instalada num WordPress recém-criado e reprovou com
`FALHA tema — o tema não apareceu no disco depois da instalação` e o mesmo para o
site-core, enquanto a unidade de auto-update, três linhas abaixo da MESMA rodada,
enumerava `f3base-site-core 1.0.0` entre os plugins instalados. O diretório estava
no disco. `Theme_Upgrader::install()` chama `wp_clean_themes_cache()` e
`Plugin_Upgrader::install()` chama `wp_clean_plugins_cache()`; a troca controlada
de diretório não passa pelo upgrader e não chamava nem um nem outro —
`wp_clean_themes_cache` não aparecia uma única vez no pacote. Numa instalação
limpa a etapa consulta o estado antes da troca, o núcleo memoriza o **negativo**
na mesma requisição, a troca acontece, e a leitura de volta relê o cache.

A invalidação mora dentro de quem trocou, e não no chamador, porque há **três**
chamadores — tema, site-core e embarcado — e chamador que esquece é o defeito
voltando. A mensagem se separou em duas porque "não apareceu no disco" dito sobre
um diretório que está lá manda o operador procurar no lugar errado.

**Por que só apareceu na 1.0.15, e essa é a lição.** Toda execução de produção
anterior rodou em site que **já tinha** tema e site-core instalados. Ali a consulta
prévia memorizava o POSITIVO e a leitura de volta passava por acidente. A checagem
atravessou quinze releases sem nunca ter sido exercitada no caminho que importa:
o piso dela nunca teve alvo inexistente. É exatamente o que a disciplina de teto e
piso existe para impedir, e falhou aqui.

**O que custa.** (a) Uma limpeza de cache por troca de diretório executada — custo
real e pequeno, e só quando a troca aconteceu: o ramo "artefato idêntico, nenhuma
troca" não invalida nada. (b) Uma sonda a mais no comando único
(`suite/lib/sonda-instalacao.php`), que monta um WordPress de mentira com caches
que memorizam o negativo e roda o `aplicar_tema()` e o `aplicar_site_core()` REAIS
contra ele. Ela é o piso que faltava: com a invalidação desligada a leitura de
volta **precisa continuar cega**, ou a bancada não estaria reproduzindo o defeito;
com ela ligada, precisa enxergar o artefato. O sandbox começa com o alvo
**inexistente**, e a sonda recusa rodar sobre alvo existente — o piso que passou
quinze releases.

**Como reverter.** Tirar a chamada de dentro de `trocar_diretorio()` devolve o
comportamento da 1.0.15, e `estatica.troca_invalida_cache` acusa na mesma rodada,
com `instalacao.limpa_le_de_volta` medindo o efeito. A reversão é possível e não é
silenciosa.

---

## 28. Fonte única do artefato, e os zips da raiz deixam de viajar

**Decidido.** `F3Base_Imp_Plugins::artefato_do_papel()` é o único lugar que decide
qual artefato instala o tema e qual instala o site-core, e é dele que saem tanto a
instalação quanto a prova do entregável em `F3Base_Imp_Entrega`. A precedência não
mudou: o zip que o operador embute (`assets/plugins/<slug>.zip`, depois
`assets/<slug>.zip`) vence a fonte em `fontes/`. E o empacotamento **parou de
montar** `<tema>.zip` e `<site-core>.zip` na raiz do bundle.

**Por quê.** Da 1.0.14 à 1.0.15 o bundle viajava com `f3base.zip` (27.607 bytes) e
`f3base-site-core.zip` (76.414 bytes) na raiz, e **nenhum caminho de instalação os
abria**: a resolução de zip embutido procura sob os prefixos declarados, e a
instalação de tema e site-core lê `fontes/`. Eram 104.021 bytes dentro do hash do
pacote servindo de prova falsa de entrega. Ao mesmo tempo havia duas listas de
caminhos candidatos — uma no instalador, outra escrita à mão no conferidor de
entregável, que não conhecia o slot `assets/plugins/` — e duas listas para o mesmo
fato divergem por construção.

**Por que remover em vez de ligar ao instalador.** Três medições. (a) Segunda
representação do mesmo artefato deriva: o zip é montado no empacotamento, o
diretório é o que a instalação lê e o que `impressao_de_diretorio()` compara para
pular a troca quando nada mudou; editar `fontes/` sem reempacotar instalaria código
velho. (b) Ligar os zips moveria tema e site-core para o upgrader do núcleo no
mesmo passo em que esta release conserta a leitura de volta da troca de diretório —
trocar de caminho no instante de consertar o outro. (c) `trocar_diretorio()`
continuaria sendo o caminho de `aplicar_embarcado()`, que tem o defeito idêntico:
rotear por fora deixaria o defeito vivo no terceiro chamador e ainda tiraria a
cobertura que o pega.

**O que custa.** O bundle deixa de trazer o tema e o site-core em forma de zip
pronto para upload manual pela tela de plugins do wp-admin. Quem quiser essa forma
põe o zip no slot declarado `assets/plugins/`, que a fonte única lê com precedência
sobre `fontes/`. O hash do pacote muda, como em qualquer release.

**Como reverter.** Voltar o laço de montagem em `f3b_empacotar()` reintroduz os
zips, e `estatica.artefato_do_pacote_e_lido` reprova na mesma rodada enquanto eles
não estiverem sob um prefixo que a instalação lê — que é a forma correta de trazê-
los de volta, se um dia forem necessários.

---

## 29. Rejeição de lock para a tela; o cliente não avança sobre resposta que não avançou o plano

**Decidido.** Quatro regras no cliente e uma no servidor.

1. **A rejeição de lock encerra a tela na primeira ocorrência**, com UMA linha que
   diz o dono do lock, há quanto tempo é o último heartbeat, o TTL e o **horário
   exato** em que o lock passa a ser considerado abandonado.
2. **O avanço é decidido, nunca presumido.** `proximoLote()` só manda seguir quando
   a resposta é sobre a unidade que aquele pedido enviou e não se declara terminal;
   `dentroDoPlano()` recusa índice que o plano não tem.
3. **Todo caminho terminal fecha pelo mesmo produtor de rodapé**, e o estado da
   aplicação sai da lista que o servidor declara. Vazio não é estado fechado.
4. **Linha que não fecha OK é nomeada também no escopo da tela**: `nomeDaLinha()`
   dá nome de reserva à linha que o servidor mandou sem rótulo.
5. No servidor, toda resposta que a tela renderiza carrega `rotulo` e `aplicacao`,
   e a resposta de um lote que **não rodou** se monta num lugar só, `nao_rodou()`.

**Por quê.** O operador executou, deu erro, executou de novo, e a tela entrou em
laço: **163 linhas idênticas** de "execução concorrente rejeitada", com a idade do
heartbeat subindo de 38 até 90 segundos — o cliente repetiu por 90 segundos até o
TTL vencer. A causa é uma regra correta aplicada onde não vale: "BLOCKED não para
mais a execução inteira" é a regra da 1.0.13, e ela fala de **unidade que mediu**
pré-condição ausente. A rejeição de lock não é resultado de unidade nenhuma — o
lote não rodou, nada foi medido, não há o que continuar. Da mesma execução saíram
os outros três achados: `Etapa 94 de 40` (o contador contava requisições, não
unidades), `estado da aplicação:` vazio no rodapé, e "linhas desta tela: 163
BLOCKED" ao lado de "BLOCKED: nenhum" na lista por nome do mesmo escopo — a regra
de contagem-com-nomes furando no escopo do cliente, porque a resposta vinha sem
rótulo e a linha entrava na contagem sem entrar na lista.

**A ação de "assumir o lock" foi avaliada e NÃO é oferecida.** A medição: o lock
com heartbeat mais velho que o TTL **já é assumido automaticamente** —
`adquirir_lock()` faz a troca atômica e segue —, então o operador nunca fica refém
de uma execução morta por mais do que o TTL. Um botão de assumir só faria diferença
para um lock **dentro** do TTL, isto é, uma execução possivelmente viva; e da tela
não se distingue "morta" de "lote lento" — a instalação de um plugin por rede lenta
fica calada por dezenas de segundos, e o heartbeat é renovado por requisição, não
por segundo. Oferecer o botão seria uma segunda fonte de verdade para uma decisão
que já tem uma, e ela é a mesma proibição que `estatica.gate_fonte_unica` cobra em
outro lugar. O que o operador ganha é a **informação**: com o horário do abandono
na linha, "esperar" deixa de ser indefinido e vira um relógio.

**O que custa.** (a) A tela para em vez de seguir, e o operador precisa executar de
novo depois do horário informado — que é o comportamento correto para um lote que
não rodou, mas é um clique a mais do que a ilusão de progresso anterior. (b) O
servidor passa a carregar mais campos em toda resposta, e o cliente valida o estado
da aplicação contra uma lista que o servidor declara.

**Como reverter.** Devolver o avanço incondicional em `proximoLote()` traz o laço
de volta, e `js.decisoes_do_cliente` acusa na mesma rodada — inclusive contra a
resposta ANTIGA, sem os campos novos, que é o piso que prova que o cliente para
sozinho.

---

## 30. Duas formas de piso, e a segunda também tem piso

**Decidido.** "Ter piso" passa a admitir duas formas: a fixture negativa e positiva
em disco, como sempre, e o piso que mora **dentro da própria sonda** — declarado em
`suite/pisos-em-sonda.tsv`. A declaração não absolve: `f3b_tem_piso()` só a aceita
quando a sonda declarada existe, menciona a checagem e traz os dois ramos, teto e
piso; e `estatica.piso_em_sonda_declarado` — que tem fixture em disco como qualquer
outro detector — confere isso a cada rodada.

**Por quê.** `armadilhas.mapeadas` recusa mapear armadilha para checagem sem piso, e
a recusa está certa: armadilha declarada coberta por checagem que não sabe reprovar
é documentação melhor sobre uma suíte cega. Só que "piso" estava definido como uma
forma — fixture em disco — que serve a detector de análise estática e não serve a
sonda funcional, cujo caso negativo é um **mutante do próprio pacote**, não uma
árvore de arquivos. As armadilhas mais caras desta release — o cache negativo numa
instalação limpa, o laço de rejeição de lock — só são cobertas por sonda, e
declará-las como pendência seria mentir para a tabela.

**O que custa.** Uma superfície de declaração a mais, que precisa ficar curta. Ela é
verificada, não presumida, e a verificação exige da sonda exatamente o que uma sonda
cega não teria: as duas afirmações.

**Como reverter.** Apagar `suite/pisos-em-sonda.tsv` devolve a definição antiga de
piso, e as armadilhas que dependiam dela voltam a fechar `armadilhas.mapeadas` em
BLOCKED, nomeando quais — a reversão é possível e não é silenciosa.

---

## 31. Conteúdo de exemplo do WordPress vai para a lixeira, decidido por discriminante

**Decidido.** `conteudo.exemplo_do_wordpress` nasce em `lixeira`, ligado por padrão no
template. O que a etapa remove é apenas o objeto que **ainda é** o que
`wp_install_defaults()` criou, e a prova é conjunta:

1. **Identidade contra o que o núcleo produz.** Título e conteúdo idênticos ao que
   `wp_install_defaults()` escreveria agora. O esperado não é um texto inventado por este
   pacote: ele sai das MESMAS chamadas de tradução que o instalador faz, com os mesmos
   msgids, no locale da instalação — é assim que se pergunta ao WordPress instalado o que
   ele mesmo escreveria.
2. **Ninguém editou.** `post_modified_gmt` igual a `post_date_gmt`, que é como o
   instalador grava os dois e o que qualquer gravação faz avançar.

Além disso, ficam intocados o objeto gerenciado por este pacote e o objeto **em uso** —
apontado por `page_on_front`, `page_for_posts` ou `wp_page_for_privacy_policy`.

O par tipo/slug **indexa a hipótese e não prova nada**: é ele que diz qual entrada do
catálogo comparar, e quem decide é a comparação. É a mesma regra que já governa a adoção
de objeto, onde slug igual sem a option do núcleo apontando para o objeto não adota nada.

Vai para a **lixeira**, nunca para exclusão definitiva: reversível pelo wp-admin,
registrada no journal com a operação inversa (`post.restaurar` com o `post_status`
observado), e conferida por leitura de volta. O relatório **nomeia** o objeto e imprime
**o discriminante que decidiu** — tanto o que removeu quanto o que preservou.

**Por quê.** `Hello world!` e `Sample Page` não são conteúdo de ninguém: são o que o
instalador insere em toda instalação. Deixá-los publicados num site entregue põe
`Sample Page` no sitemap, na seleção do `llms.txt` e na busca — e a decisão 20, que os
mandava relatar e nunca tocar, estava certa sobre conteúdo alheio e errada sobre resíduo
de instalação. A orientação do dono autoriza a diferença: o implantador deve realizar
todas as modificações necessárias para fazer a página funcionar, alterando conteúdo
preexistente se preciso.

O que **não** se autoriza é decidir por slug. Quem reescreveu o `Hello world!` para
publicar um texto de verdade continua com o slug `hello-world`, e apagar aquele objeto
seria perda de conteúdo real — o pior defeito que esta release poderia introduzir. É por
isso que o piso que importa é o **negativo**: a edição é plantada em título, em conteúdo e
nos dois, nos dois objetos do catálogo, e nenhum dos casos pode produzir remoção.

**O que custa.** Fragilidade deliberada, e ela cai para o lado seguro: se o núcleo mudar o
texto de um dos objetos numa versão futura, ou se o site tiver mudado de domínio depois da
instalação (a página de exemplo interpola `admin_url()` no último parágrafo), o esperado
deixa de casar e **nada é removido**. A divergência sai nomeada no relatório como
"conteúdo editado", e o operador decide. Preferir o falso negativo ao falso positivo é a
escolha correta quando o falso positivo apaga conteúdo de alguém.

Custa também uma unidade a mais no plano, posicionada **antes** da troca de estrutura de
permalinks. A ordem é decisão: o que sai daqui deixa de ser publicado, some da medição de
URLs de terceiro e não ganha um 301 para um endereço que passaria a 404; o que fica —
o objeto editado, intocável — continua publicado e é coberto pelo redirect da decisão 21.

**Como reverter.** Declarar `conteudo.exemplo_do_wordpress: "manter"` desliga a etapa: o
exemplo fica publicado por decisão do projeto e volta a ser apenas relatado por
`conteudo.nao_gerenciado_publicado`. O que já foi para a lixeira volta com um clique em
Restaurar, ou pelo `rollback` do journal.

---

## 32. O sequestro do assistente do wp-mcp-ultimate não se desarma por configuração

**Decidido.** `plugins.supressao_onboarding` **não** ganha entrada para
`wp-mcp-ultimate`, e a ausência é resultado de medição, não de esquecimento.

**O que foi medido.** O artefato foi baixado da origem declarada em
`plugins.instalaveis[wp-mcp-ultimate].url` — o zip
`wp-mcp-ultimate-main.zip` do repositório `Fator3Ventures/claude-wordpress` — e lido.
Versão do cabeçalho: `2.1.0`. O assistente é registrado em
`includes/Plugin.php`, **linha 60**:

```php
add_action('admin_init', [$this, 'maybe_redirect_to_dashboard']);
```

e o que ele consulta para decidir redirecionar está no mesmo arquivo, **linha 87**:

```php
if (!get_transient('wp_mcp_ultimate_activated')) {
    return;
}
```

O gatilho é posto em `wp-mcp-ultimate.php`, **linha 38**, dentro do
`register_activation_hook`: `set_transient('wp_mcp_ultimate_activated', true, 30)` — TTL
de trinta segundos. E é apagado na **linha 90** de `Plugin.php`, por
`delete_transient()`, na primeira requisição administrativa que o encontra, antes do
`wp_safe_redirect()` da linha 94. Não há `apply_filters` em nenhum ponto desse caminho.

**Por que não dá para desarmar por configuração.** O mecanismo **não é uma option**. É um
transiente de vida curta, consumido e apagado no primeiro uso. `supressao_onboarding`
grava `option.chave = false` pelo gravador único, e o transiente não tem chave dentro de
uma option para gravar: com cache de objeto persistente ele nem chega à tabela de options.
Declarar uma entrada ali gravaria uma option que ninguém lê — **lixo na instalação do
cliente**, que é exatamente o custo que uma entrada errada nesse mapa tem.

**REMEDIDO na 1.7.1, contra o artefato instalado num site real.** A leitura foi refeita
pelo próprio canal, no plugin em produção — `wp-mcp-ultimate` **2.1.0**, pasta
`wp-mcp-ultimate-main` —, e não no zip de origem: `includes/Plugin.php` (sha256
`6706e0bc…`, 3627 bytes) registra `add_action('admin_init', [$this,
'maybe_redirect_to_dashboard'])` e o método consulta `get_transient('wp_mcp_ultimate_activated')`,
apaga o transiente e só então redireciona. O único `apply_filters` do arquivo é
`wp_mcp_ultimate_enable_oauth`, que governa o servidor OAuth e **não** o redirecionamento.
`wp-mcp-ultimate.php` (sha256 `19a816fc…`) põe o gatilho no `register_activation_hook`, com
`set_transient('wp_mcp_ultimate_activated', true, 30)`. **Nenhuma option em nenhum ponto do
caminho.** A decisão de não declarar entrada em `plugins.supressao_onboarding` continua
valendo, agora medida no artefato que está no ar: uma entrada ali gravaria uma option que
ninguém lê — lixo na instalação do cliente —, e o mecanismo continuaria disparando.

**Consequência aceita.** `lote.sequestro_por_terceiro` continua aparecendo uma vez por
execução em que o plugin seja ativado. Não é bloqueio: o cliente detecta o sequestro,
repete a MESMA unidade uma vez e segue — o transiente já foi apagado pela requisição
sequestrada, e a segunda chega ao implantador. A mensagem da tela deixou de prometer que
uma entrada no mapa resolveria: ela agora diz que a chave sai da LEITURA do artefato
daquele plugin, e que assistente decidido por transiente ou por filtro não se desarma por
configuração nenhuma.

**Como reverter.** Se uma versão futura do plugin passar a decidir por option ou expor um
filtro, a leitura do artefato mostrará isso, e a entrada declarada passa a existir com o
arquivo e a linha registrados aqui — que é o procedimento, e não a exceção.

---

## 33. A identidade da release é medida nos três lugares que a carregam

**Decidido.** `estatica.identidade_do_implantador` compara `release.identidade` e
`release.implantador` do `config/site.json` com o cabeçalho `Version:` de
`implantador-base.php` e com o fallback de bootstrap `F3BASE_IMP_VERSAO_DECLARADA`.
Divergência entre quaisquer dois é achado, nomeando os dois números.

**Por quê.** O `MANIFESTO.md` afirmava, em linha própria da tabela de estado, que
"`release.identidade` e o cabeçalho do implantador são a mesma coisa" — e **nenhuma
checagem media isso**. A afirmação era verdadeira por hábito: alguém lembrava de bumpar o
cabeçalho a cada release. Na 1.0.17 o hábito falhou de forma visível: a configuração foi
para `1.0.17`, o cabeçalho ficou em `1.0.16` e a constante de bootstrap ainda estava em
`1.0.15` — **três respostas** para "qual release é esta?", e a que o WordPress mostra na
lista de plugins é a do cabeçalho.

É a pior forma da doença que este pacote existe para tratar: não uma checagem que nunca
falhou, mas uma garantia **anunciada no documento entregável** sem checagem nenhuma por
trás. Vale mais do que a correção pontual — a correção pontual é bumpar o número, e é o
que já foi feito toda vez até parar de ser feito.

**O que custa.** Um detector a mais, com fixture negativa e positiva em disco, e uma
regra a mais para quem edita o pacote: o número da release passa a ter de mudar nos três
lugares, e a rodada acusa se um ficar para trás. É exatamente o custo que se quer.

**Como reverter.** Tirar a linha do registro do piso e do runner devolve o estado
anterior — e o MANIFESTO volta a afirmar sem medir, que é o que não pode acontecer de
novo.

---

## 34. O limite de campo é medido na unidade que o cliente corta

**Decidido.** O endpoint de leads mede limite de campo em **caracteres**, e o cliente
(`fontes/site-core/assets/f3base-leads.js`) corta em **caracteres**. O número continua
saindo de um lugar só — `limites_publicos()` —, e agora a UNIDADE também.

**Por quê.** O servidor media `strlen()`, que conta bytes; o cliente media `texto.length`,
que conta unidades UTF-16. Os dois recebiam o MESMO número. Com acentuação — isto é, em
português, sempre — o navegador aprovava um nome de 120 caracteres e o servidor devolvia
`400 f3base_limite_excedido` sobre 130 bytes. A recusa é dura por desenho ("recusado,
nunca truncado em silêncio"), então o lead se perdia inteiro, e a página que o aprovou era
a mesma que o pacote publica.

Caracteres, e não bytes nem unidades UTF-16, porque é a unidade que o humano que escreve
o nome percebe, e é a que o texto de recusa nomeia. O corte do cliente passou a andar por
`Array.from()`: cortar por `slice()` no meio de um par substituto devolveria metade de um
caractere, e o servidor receberia texto que ninguém escreveu.

**O que custa.** `mb_strlen()` no servidor (com queda para `preg_match_all('/./us')` onde
mbstring não existir) e uma alocação de array por campo no cliente. Um site que hoje
guarda nomes cortados em 120 bytes passa a aceitar até 120 caracteres — mais bytes na
coluna, o que é o comportamento que o limite declarado sempre prometeu.

**Como reverter.** Trocar `self::comprimento()` por `strlen()` reintroduz o defeito, e
`leads.limite_por_caractere` reprova no mesmo instante — o piso planta o texto acentuado
no limite exato e afirma, antes de medir, que ele EXCEDE em bytes.

---

## 35. Reserva de deduplicação nasce pendente, confirma depois da persistência e é compensada na falha

**Decidido.** `reservar()` insere a correlação com estado `pendente`; a reserva vira
`firme` só depois de o lead estar gravado; e, quando nenhum destino aceita o lead, ela é
APAGADA. O caminho de contingência por transiente tem a mesma disciplina, com TTL curto
enquanto pendente.

**Por quê.** O `INSERT` acontecia em autocommit e não havia `DELETE` compensatório em
caminho nenhum. Bastava `wp_insert_post()` falhar uma vez para a correlação ficar
reservada por **30 dias**: a tentativa seguinte do MESMO visitante recebia
`200 {"ok":true,"registrado":false,"duplicado":true}` e o lead sumia sem que nada no site
dissesse que tinha sumido. A reserva existia para decidir empate entre replay e duplo
clique — e passou a decidir contra o visitante que tentou de novo.

Junto veio a retomada da reserva ABANDONADA: uma requisição interrompida entre a reserva e
a gravação não deixa ninguém para compensar, e o `UPDATE` condicionado ao carimbo lido faz
com que dois pedidos concorrentes disputando a mesma reserva morta produzam uma retomada
só — o banco decide o empate, como no `INSERT`.

**O que custa.** Três colunas a mais na tabela (`tipo`, `estado`, `contador`,
`expira_em`), uma migração por `dbDelta` e uma instrução a mais por lead aceito. A tabela
antiga continua respondendo ao `SHOW TABLES`, então a prontidão passou a ser medida pelas
COLUNAS: sem elas, o módulo cai para o transiente e reporta DEGRADADO com o motivo.

**Como reverter.** Tirar a chamada a `liberar_reserva()` devolve o defeito, e
`leads.reserva_compensada` reprova: o piso prova que a segunda tentativa depois de uma
falha de armazenamento é ACEITA, e que o replay de uma correlação já gravada continua
recusado.

---

## 36. O ouvinte da cadência mora no site-core, e as recorrências que faltam são registradas

**Decidido.** O módulo `cadencia-relatorio` do `site-core` engancha
`f3base_cadencia_relatorio`, registra as recorrências `f3base_quinzenal` (15 dias) e
`f3base_mensal` (30 dias), executa o modo somente-relatório registrando última execução,
próxima, duração, resultado, erro e atraso, e conta os ajustes de
`cadencia_relatorio.apos_n_ajustes` — contando de verdade, e disparando.

**Por quê.** Três defeitos do mesmo tronco, medidos na 1.0.17:

- `f3base_cadencia_relatorio` aparecia **uma vez** no pacote inteiro
  (`includes/class-f3base-imp-lotes.php`, a variável `$hook`) e **zero** `add_action` o
  escutava. O evento disparava, o WP-Cron o reagendava, e nada acontecia. Pior: o único
  lugar que conhecia o nome do hook era o implantador, que **se autodesativa** — o
  ouvinte precisava morar no componente que sobrevive a isso.
- `mensal` degradava para `daily` porque `monthly` não existe no núcleo do WordPress, e
  `quinzenal` degradava para `weekly`, **dobrando a frequência**. As duas em silêncio.
- `apos_n_ajustes` era gravado na option `f3base_cadencia`, que **ninguém lia**, e o
  relatório imprimia "gatilho alternativo: após N ajustes" sobre um contador inexistente.

É o próprio pacote cometendo a regra que o documento mestre enuncia: **gravar não é
configurar**. A saída tinha duas formas honestas — ou a chave conta e dispara, ou ela sai
da configuração. Escolhemos a primeira, porque a chave já estava publicada em documento
entregável e chave que não faz nada é pior que chave ausente: ela produz confiança.

**O que custa.** Um módulo a mais no registro único, duas options novas
(`f3base_cadencia`, lida, e `f3base_cadencia_estado`, de execução) e três hooks de option
(`updated_option`, `added_option`, `deleted_option`) enquanto o gatilho por ajustes estiver
ligado. A reentrância é guardada: as escritas da própria execução — carimbo de atividade,
estado da cadência, procedência e journal — NÃO contam como ajuste, senão o gatilho
dispararia sozinho e o disparo gravaria de novo. "Mensal" no WP-Cron é intervalo de trinta
dias, não mês de calendário, e isso está escrito no nome legível da recorrência em vez de
virar surpresa em fevereiro.

**O que ficou de fora, e é do implantador.** A etapa `cadencia` de
`includes/class-f3base-imp-lotes.php` continua mapeando `quinzenal` para `weekly` e
`mensal` para `monthly` com queda para `daily`, e continua imprimindo o gatilho por
ajustes sem dizer que quem o mantém é o site-core. Ela precisa passar a agendar
`f3base_quinzenal` e `f3base_mensal`, a NOMEAR a degradação quando a recorrência declarada
não existir no momento do agendamento, e a parar de prometer mecanismo que não existe.

**Como reverter.** Tirar o módulo do registro único de `F3Base_Registro::classes()`
devolve o estado anterior — e `cadencia.ouvinte_registrado` reprova dizendo, com o nome do
hook, que ninguém escuta.

---

## 37. A origem do rate limit é declarada, e nunca lida do próprio pedido

**Decidido.** O balde do rate limit conta por `REMOTE_ADDR` até que
`cabecalhos.origem_confiavel` declare um cabeçalho de proxy e quantos saltos confiáveis
existem à frente do site. Declarado, o valor é lido descontando esses saltos da direita da
cadeia — a única parte que o proxy da frente escreveu. Vazio é o padrão, e vazio significa
NUNCA confiar.

**Por quê.** Dois defeitos somados. O incremento era `get_transient()` +
`set_transient()` sem lock: N requisições concorrentes liam o mesmo valor e gravavam o
mesmo valor mais um, e o balde de 20 por 10 minutos deixava passar quantas coubessem na
janela. E a chave saía só de `REMOTE_ADDR`: atrás de CDN ou proxy reverso, `REMOTE_ADDR` é
o mesmo para todos os visitantes, e o balde inteiro virava um só — o limite deixava de
proteger e passava a atrapalhar.

O incremento passou a ser uma instrução só, com o banco somando
(`INSERT ... ON DUPLICATE KEY UPDATE` com `LAST_INSERT_ID()`), pela mesma razão que a
deduplicação já usava chave única: **o banco decide o empate, não o PHP**. E o cabeçalho é
declarado porque cabeçalho de proxy é declaração do CLIENTE: aceitar um sem declaração é
deixar o visitante escolher em que balde ele conta — spoofing de limite.

**O que custa.** Uma chave a mais na configuração e uma option a mais no `site-core`
(`f3base_origem_confiavel`), ambas vazias por padrão. Sem a tabela pronta, o balde cai
para o transiente — declaradamente não atômico —, e o módulo reporta DEGRADADO com o
motivo.

**Como reverter.** Fazer `incrementar_janela()` cair sempre no transiente devolve o
defeito, e `leads.rate_limit_atomico` reprova: o piso congela a leitura, prova que o
caminho de ler-modificar-gravar devolve 1 e 1, e exige 1, 2, 3, 4, 5 do caminho do banco.

---

## 38. O digesto do artefato é declarável, e o que ele não protege está escrito

**Decidido.** O schema passa a **permitir** `sha256` no ramo `origem: "url"` de
`plugins.instalaveis`, e `F3Base_Imp_Plugins::veredito_do_digest()` tem três ramos, cada
um com uma garantia diferente: **declarado e batendo** instala; **declarado e divergindo**
é **FALHA** nomeando os dois valores, sem instalar nada; **ausente** faz o digesto ser
medido e **FIXADO** na primeira observação, com a execução seguinte reprovando qualquer
divergência. E o host da origem passa a ser **revalidado depois de cada
salto**, não só antes do download. (Na 1.0.18 o que se revalidava era o HOST, contra uma
lista fechada; na 1.0.19 a lista saiu — decisão 45 — e o que se revalida é o **esquema**:
todo salto continua em https.)

**Por quê.** Os dois plugins do canal descem de
`https://github.com/…/raw/main/….zip` — **ref mutável** —, e o artefato que chega por esse
caminho é o que expõe as rotas `files/*` e `db/*`. Até a 1.0.17 a guarda de origem
conferia esquema e host **antes** do download, `baixar_artefato()` chamava `download_url()`
puro, nenhum hash era conferido e nada era revalidado depois do salto. Pior, o
schema era ativamente hostil à correção: no ramo `origem: "url"` ele tem
`"additionalProperties": false`, então **declarar um digesto era impossível**.

A restrição que governa o desenho: o usuário exige que o template funcione como produção
**sem configuração extra**. Exigir digesto declarado quebraria a primeira execução de todo
projeto novo. Daí o ramo ausente — e daí, também, a obrigação de não maquiar o que ele é.
**Fixar na primeira observação (TOFU) não é verificação de integridade.** Ela defende
contra a origem mudar embaixo das execuções seguintes e **não** defende a primeira busca:
se o artefato já veio trocado, é o trocado que ficou fixado. A mensagem do relatório diz
as duas metades, com esses nomes, porque TOFU que se apresenta como verificação é pior que
nenhuma verificação — ela produz confiança.

A revalidação depois do salto fecha o outro lado do mesmo buraco: um endereço aprovado
que responda 302 para outro entregaria o artefato desse outro — e um 302 de `https://`
para `http://` traria o corpo por canal aberto. A guarda estaria sendo conferida no
endereço que ninguém baixou. Os saltos passaram a ser seguidos um a um com
`redirection => 0`, a guarda conferida em cada um, e o corpo só desce do endereço final.

**A fronteira com o CONTRATO, medida e escrita.** A regra 20 manda instalar sempre a
última versão da fonte oficial, sem número de versão declarado e **sem checksum de
terceiro**. Não há colisão, e a razão é a origem: a conferência roda **só** quando a
entrada declara `origem: "url"` — artefato NOSSO, endereço com ref mutável. Para
`wordpress.org` ela não roda, e é decisão medida: a URL de lá é **por versão**, o artefato
muda de propósito a cada atualização, e fixar o digesto ali faria a próxima versão
legítima reprovar — o oposto da política. O schema executa a mesma fronteira (o ramo
`wordpress.org` continua com `additionalProperties` fechado), e `digesto_se_aplica()` a
executa no código, com piso nos cinco valores de origem. Na primeira escrita desta release
a conferência rodava para TODA origem remota, o que teria transformado a atualização
seguinte do `wordpress-seo` em FALHA; o achado é da revisão contra o contrato, não da
suíte, e por isso a fronteira virou função com piso em vez de comentário.

**O que custa.** O transporte deixou de ser `download_url()` e passou a ser a mesma camada
HTTP do núcleo com os saltos na mão — mais código nosso, e uma requisição a mais por
salto. Uma option nova, `f3base_digestos`, com o digesto fixado por slug. E um efeito de
configuração que precisa ficar dito: **todo salto do redirecionamento tem de continuar em
https**. Para esta base isso já vale; uma origem que faça um salto por HTTP passa a ver
BLOCKED com o esquema e o host nomeados, que é o comportamento certo.

**Como reverter.** Voltar `baixar_artefato()` a chamar `download_url()` devolve os dois
defeitos, e `plugins.https_em_todo_salto` reprova: o piso injeta um buscador que responde
302 para `http://` e exige recusa. Tirar a conferência do digesto devolve o primeiro, e
`plugins.digesto_do_artefato` reprova nos cinco ramos.

---

## 39. O autoteste do canal é despachado de verdade, e a prova de recusa é BLOCKED declarado

**Decidido.** A unidade `mcp` DESPACHA `files/selftest` — pela Abilities API quando ela
existe, pelo servidor REST interno sempre — e leva o resultado estruturado para a linha
`mcp.autoteste`. Autoteste que devolve falha **reprova a entrega**; ausência da rota fecha
**BLOCKED, nunca OK**. A prova de recusa para credencial não autorizada sai como **BLOCKED
de fase** em `mcp.autoteste_recusa_credencial`, nomeando o que falta.

**Superado em parte na 1.1.7, e a correção é do METADADO, não da regra:** a fase declarada
daquela linha era `producao`, igual à fase de uma execução no host, e por isso ela fechava
BLOCKED em TODA execução, para sempre. A evidência que falta é uma requisição HTTP de
fora, produzida por um requisitante EXTERNO e não pelo host — mesma natureza de
`orcamento.medicao_de_pagina` —, então a fase declarada passou a ser `campo` e a linha
fecha N/A nomeando a fase. A impossibilidade medida e a recusa da prova fraca continuam
exatamente como estão escritas acima. Na mesma release, a PRESENÇA de `files/selftest`
passou a sair da UNIÃO das duas fontes, e não só do servidor REST: rota registrada apenas
como habilidade da Abilities API é rota presente, e a linha executa e fecha pelo
resultado.

**Por quê.** `README.md` afirmava desde a 1.0.6 que "`files/selftest` roda na entrega e
após toda mudança de PHP ou de hospedagem, com o resultado no relatório". Medido no
pacote da 1.0.17: os três consumidores do canal faziam `isset( $registradas[ $rota ] )` —
aprovação por NOME —, e `wp_execute_ability`, `execute_ability` e `rest_do_request` tinham
**zero** ocorrências. A rota nunca rodou, e o relatório nunca teve resultado. Aprovar por
nome responde "a rota está registrada"; o autoteste responde "o canal funciona", e o item
que mais importa nele é a detecção de PHP quebrado: com ela inerte, gravar PHP pelo canal
passa a ser perigoso.

Sobre a prova de recusa, a avaliação foi feita e a resposta é **não é mensurável daqui**.
As duas vias de execução deste host despacham DENTRO do processo, com o usuário da
requisição já autenticado como administrador; nenhuma passa pela autenticação HTTP, que é
o que uma credencial não autorizada exercitaria. Forjar um usuário sem capacidade e
despachar de novo mediria o `permission_callback` — e chamar isso de prova de recusa de
credencial seria inventar uma prova fraca e batizá-la de negativa, que é pior do que
declarar a pendência. Ela fica numa linha de FASE, com o que falta escrito: requisição
HTTP de fora, credencial sem a capacidade, 401 ou 403 observado na ponta. (A fase
declarada era `producao` e virou `campo` na 1.1.7 — ver a correção anotada acima: quem
produz essa evidência é o requisitante externo, não o host.)

**O que custa.** Uma requisição interna a mais por execução, na unidade `mcp`. E uma
fronteira de vocabulário que o pacote não controla: o corpo da resposta é do complemento,
então a leitura é conservadora — booleano falso, `status` de reprovação ou lista de falhas
não vazia REPROVAM; corpo sem campo legível é relatado **como corpo sem campo legível**,
e a linha diz que mediu a resposta 2xx e nada além disso.

**Como reverter.** Tirar o despacho de `etapa_canal_mcp()` devolve o estado anterior, e
`mcp.autoteste_veredito` reprova: o piso exige BLOCKED para rota ausente, FALHA para os
quatro modos de reprovação e OK só para o 2xx sem item reprovado.

---

## 40. Três eixos no encerramento, e a autodesativação continua no gate de aplicação

**Decidido.** O encerramento passa a ter um terceiro eixo, `convergencia`, ao lado do
estado da aplicação e da autodesativação: **convergiu**, **pendente** ou **não
convergiu**. BLOCKED de pré-condição declarada torna a convergência pendente; FALHA de
pré-condição a torna não convergida; e a frase final do encerramento diz o que falta e
como sair. **A autodesativação continua amarrada ao gate de aplicação**, e não à
convergência.

**Por quê.** Aqui a auditoria da 1.0.17 estava certa no fato e nós discordamos da
conclusão, e as duas metades precisam ficar registradas.

O fato: o gate considera BLOCKED — de entregável (`pode_autodesativar()`) e de canal. O
que **ninguém** consultava era o BLOCKED de **pré-condição declarada**:
`privacidade.controlador_identificado` e `formulario.contato-whatsapp` fechavam BLOCKED,
saíam impressos e não entravam em lista nenhuma, porque o mapa do encerramento só
populava `$entregaveis` com `in_array( $nome, $do_gate )`. O resultado era honesto nos
fatos e otimista no nome: `SUCESSO_APLICACAO` mais autodesativação, com a política de
privacidade em rascunho e o CTA de WhatsApp em degradado.

A discordância: a auditoria conclui que a autodesativação deveria esperar pela
convergência. Não deveria. **A autodesativação é sobre o ciclo do implantador ter
terminado, não sobre o site estar completo.** Manter a ferramenta no ar por dado que só o
operador tem — razão social, documento, endereço, número de WhatsApp, nome do mecanismo
de cadência da hospedagem — prenderia o pacote a uma espera indefinida: um site cujo
operador nunca preenche o controlador ficaria com o implantador ativo para sempre, que é
exatamente a forma de gate insatisfazível que a 1.0.8 eliminou para a rodada limpa. O que
o eixo novo muda é o NOME do resultado e a frase de encerramento, não quem sai de cena.

**O que custa.** Um metadado a mais nas linhas (`precondicao`), ortogonal ao `gate` — que
não muda, para que nenhuma guarda de promoção de unidade seja afrouxada —, e uma linha a
mais no relatório (`entrega.convergencia`, que **desde a 1.7.3 declara gate `relato`**,
porque ela relata e não decide; até lá ela declarava `fase`, e a palavra certa já estava
escrita nesta frase). Marcar uma checagem como pré-condição é decisão explícita de quem a emite;
esquecer de marcar deixa o eixo otimista, e é o preço de não inventar heurística sobre
"que BLOCKED é do operador".

**Como reverter.** Tirar `precondicao` das emissões devolve o eixo a "convergiu" sempre, e
`lotes.convergencia_terceiro_eixo` reprova nos cinco casos — inclusive no piso da
discordância, que exige que a autodesativação aconteça com a convergência pendente.

---

## 41. A lista de gates de fase sai do metadado, e o escopo sai junto com o veredito

**Decidido.** `F3Base_Imp_Entrega::gates_de_fase()` deixa de ser lista literal e passa a
devolver `F3Base_Imp_Relatorio::nomes_com_gate( 'fase' )` — os nomes que as linhas desta
execução declararam. E as duas frases que falam de pendência de fase passam a **nomear o
escopo que resumem**.

**Por quê.** Havia duas fontes para o mesmo fato: uma lista declarada com **um** nome
(`entrega.rodada_limpa`) e o metadado `gate` por checagem, com **dois** emissores de
`gate=fase`. Duas fontes divergem, e a divergência saiu impressa dentro de UMA linha do
log da 1.0.17, unidade `entrega`: *"…Nenhuma pendência de fase em aberto. Pendência(s) de
FASE dentro desta unidade — 1 … orcamento.medicao_de_pagina (BLOCKED)"*. Derivar do
metadado faz a causa sumir. O texto precisava da segunda metade: as duas frases contam
escopos diferentes — os gates de fase da EXECUÇÃO e as internas de UMA unidade —, e sem o
escopo nomeado elas continuariam parecendo contradição mesmo concordando.

**O que custa.** `gates_de_fase()` passou a depender das linhas já emitidas, então quem a
consulta tem de consultá-la DEPOIS das emissões — o encerramento, que é onde ela é usada.
A sonda passou a emitir antes de perguntar, e é isso que prova a derivação em vez de
pressupô-la.

**Como reverter.** Devolver a lista literal ao corpo da função devolve a divergência, e
`estatica.gate_de_fase_do_metadado` reprova nomeando o literal; `entrega.gates_separados`
reprova junto, porque o segundo emissor deixa de aparecer na lista derivada.

---

## 42. O registro da rodada declara o veredito, e deixou de se chamar "rodada limpa"

**Decidido.** `suite/rodada-limpa.json` passa a ser `suite/rodada.json`, e o registro
declara **veredito**, **contagem de FALHA** e **pendências de fase NOMEADAS**. O leitor no
host (`veredito_da_rodada_limpa()`) confere o veredito **além** do hash: sem veredito
legível, ou com FALHA declarada, o estado é BLOCKED; com pendências, fecha OK
**nomeando-as**.

**Por quê.** Três defeitos do mesmo tronco. O selo lia só `FALHA` para decidir se gravava;
o arquivo se chamava `rodada-limpa.json` e continha 22 BLOCKED; e o leitor comparava **só
o hash**. Somando os três: o registro com 22 bloqueios era o que fazia `entrega.rodada_limpa`
fechar OK no host — o pacote se aprovando pelo arquivo que ele mesmo escreveu, com a
palavra "limpa" no nome do arquivo fazendo o resto do trabalho. Hash igual prova que a
rodada mediu ESTE pacote; não diz o que ela achou. Um registro chamado "rodada limpa" com
bloqueios dentro é exatamente o tipo de afirmação que esta release existe para eliminar,
e por isso o nome passou a ser neutro e o veredito passou a ser um campo.

**O que custa.** O caminho mudou em nove lugares — inventário, allow-list, constante do
host, marcador do detector de fonte única, fixtures e documentos —, e um pacote instalado
com o registro antigo passa a fechar BLOCKED dizendo que o registro não declara veredito.
É o comportamento certo: registro de uma versão anterior do selo não amarra entrega.

**Como reverter.** Fazer o leitor voltar a comparar só o hash devolve o defeito, e
`entrega.rodada_limpa_confere` reprova nos dois ramos novos — registro sem veredito e
registro declarando FALHA.

---

## 43. Ler não é consumir, e o detector que media a coisa errada parou de afirmar o que não mede

**Decidido.** `estatica.detector_chave_sem_consumidor` **mantém o nome** e passa a dizer,
na própria linha do relatório, exatamente o que mede — "toda chave tem uma LINHA QUE A
LÊ" — e o que não mede: **ler não é consumir**. E nasce o irmão que mede a outra metade,
`estatica.option_gravada_sem_leitor`: toda option do namespace declarado em
`site.prefixo_tecnico` que o pacote GRAVA é lida de volta por alguma linha.

**Por quê.** O detector aprovou `cadencia_relatorio.apos_n_ajustes` com nota cheia até a
1.0.17, e a chave não fazia nada: era lida, o valor ia para a option `f3base_cadencia`, e
nenhuma linha do pacote lia aquela option. Detector que mede a coisa errada é pior que
detector ausente, porque produz confiança — e a confiança que ele produziu foi a de que
toda chave publicada tinha efeito.

Duas saídas foram consideradas. Renomear para `detector_chave_sem_leitor` alinharia nome
e medição, mas trocaria um nome que o CONTRATO usa (regra 10, "toda chave do config tem
consumidor") por outro, sem medir nada a mais — e a propriedade que o contrato pede é
justamente a que o par de detectores passa a provar. A escolhida foi a segunda: parar de
afirmar o que ele não mede, e acrescentar o detector que fecha o trajeto. Os dois juntos
respondem "a chave é lida" **e** "o que a leitura produz é lido de volta", que é o que
"tem consumidor" queria dizer desde o começo.

**O que custa.** O detector novo tem escopo declarado — só options do prefixo técnico —,
e é decisão: option do núcleo (`blog_public`, `site_icon`, `permalink_structure`) é lida
pelo WordPress, e acusá-la seria falso positivo com cara de rigor. O limite que sobra está
escrito: uma leitura cujo valor só chega a uma mensagem de texto continua passando pelos
dois. Quem pega esse caso é `doc.afirmacao_conferida`, e por afirmação declarada.

**Como reverter.** Tirar o detector novo devolve o buraco, e o piso reprova: a fixture
negativa é o defeito de 1.0.17 inteiro — `f3base_cadencia` gravada com o número de
ajustes e nenhuma linha a lendo de volta, com `blog_public` ao lado para provar que option
do núcleo não é acusada.

---

## 44. Afirmação de documento conferida contra comportamento medido

**Decidido.** Nasce `suite/afirmacoes.tsv` e o detector `doc.afirmacao_conferida`: cada
linha declara um **documento**, a **frase exata**, uma **regra** e o **esperado**, e o
detector mede o fato na árvore varrida. Frase declarada que sumiu do documento é achado;
fato que não bate com o esperado é achado, nomeando frase, regra, esperado e observado.
Quatro regras, todas estáticas e todas com piso: `config.vazio`, `config.igual`,
`codigo.chamada` e `codigo.emite_estado`.

**Por quê.** Os detectores desta suíte conferiam identidade de release e números gerados.
**Nenhum conferia uma afirmação de COMPORTAMENTO**, e foi por essa fresta que passaram
cinco dos vinte e dois achados da auditoria da 1.0.17 — três deles refutados pela
configuração e pelo código que viajam no MESMO zip:

- "mecanismo vazio → o item fecha BLOCKED, não OK" (`README.md` duas vezes,
  `MANIFESTO.md` uma), enquanto o código montava WP-Cron sempre e o veredito era OK;
- "`plugins.operacionais` está vazio nesta base" (`README.md` duas vezes), com
  `dreamhost-panel-login` declarado em `config/site.json`;
- "`files/selftest` roda na entrega … com o resultado no relatório" (`README.md`), com
  zero chamadas de execução de rota ou de habilidade no pacote.

O detector não precisa entender prosa. Precisa de um **mecanismo declarado** que ligue a
frase ao fato — e é isso que a tabela é. As três correções foram feitas, e as três frases
corrigidas estão amarradas: se alguém devolver qualquer uma delas ao texto antigo, ou
mudar o comportamento por baixo, a rodada acusa.

**O que custa.** Uma tabela a manter: frase reescrita sem atualizar a linha vira achado de
amarração órfã. É o preço certo — amarração órfã afirma cobertura que não existe, que é a
doença que `armadilhas.mapeadas` combate um nível acima —, mas é trabalho recorrente, e a
mensagem do achado diz as duas saídas: reescrever a frase ou tirar a linha.

**Como reverter.** Tirar a tabela devolve a fresta, e o piso reprova: a fixture negativa é
um pacote com os três defeitos medidos de 1.0.17 — README afirmando, `config/site.json` e
`includes/` refutando — e a positiva é o mesmo pacote com os três fatos no lugar.

---

## 45. Lista declarada no mesmo arquivo que ela restringe não é controle de segurança

**Decidido.** `plugins.origens_url_autorizadas` sai: a chave, a entrada de schema, a
conferência no código e toda mensagem que a nomeava. O que fica, e faz o trabalho de
verdade sem pedir nada ao operador, são duas coisas: **HTTPS obrigatório em TODOS os
saltos** — inclusive o primeiro, e revalidado a cada redirecionamento — e o **digesto** da
1.0.18, com os três ramos que ela já tinha (declarado é gate duro, ausente é medido e
fixado na primeira observação, com o limite dito). A revalidação depois do salto passa a
ser "todo salto continua HTTPS" em vez de "aterrissou em host da lista".

**Por quê — e esta é a regra geral que justifica o resto da release.** Uma lista de hosts
declarada **no mesmo arquivo** que as URLs que ela restringe não é controle de segurança:
quem consegue editar a URL edita a lista na linha de cima. Não há separação de privilégio
entre as duas escritas, não há assinatura, não há segunda autoridade — as duas linhas
moram no `config/site.json` e são gravadas pela mesma pessoa, no mesmo commit, com a
mesma permissão. Contra um adversário que edite a configuração, ela não protege nada.
Contra um operador distraído, ela protege contra um erro de digitação de host — que é uma
guarda de digitação, útil, mas com **preço de controle de segurança**: uma chave a mais no
arquivo único, uma decisão a mais pedida a quem só quer publicar um site, e uma mensagem
de BLOCKED que ensina a "acrescentar o host à lista", que é justamente o gesto que
dissolve a suposta proteção.

Isso é o padrão que esta release inteira persegue: **regra que gera confusão sem comprar
nada sai; regra que compra proteção sem pedir nada fica.** HTTPS compra autenticidade de
origem e integridade em trânsito, e não pede nada — é uma propriedade do endereço que já
está escrito. O digesto compra "o byte de hoje é o byte de ontem", e não pede nada no ramo
ausente. A lista de hosts pedia uma decisão e não comprava nada que a edição do arquivo
não desfizesse.

**O que custa.** Perde-se a guarda de digitação: uma URL escrita para o host errado passa
a ser tentada, e a defesa contra ela deixa de ser "recusa antes de abrir conexão" e passa
a ser "o digesto não bate" — que só existe a partir da segunda execução, ou desde a
primeira quando o `sha256` está declarado. Quem quiser a guarda de volta tem um caminho
melhor que a lista: declarar `sha256` na entrada, que é gate duro **na primeira busca**,
que a lista nunca foi. E o operador que precisa de fronteira de rede de verdade tem a
camada certa para ela — egress do servidor —, que é fora do alcance de quem edita o
`config/site.json`.

**Como reverter.** Redeclarar a chave e devolver a conferência ao código —
`estatica.sem_residuo_de_chave_removida` reprova enquanto a linha estiver em
`suite/chaves-removidas.tsv`, e é ela que precisa sair primeiro. O piso da guarda que
ficou está em `plugins.https_em_todo_salto`: salto que cai para HTTP é recusado, URL
declarada em HTTP é recusada antes de qualquer busca, endereço sem host legível não abre
conexão e cadeia sem fim é abandonada no teto.

---

## 46. Regime de formulário derivado do valor, e não de um interruptor ao lado dele

**Decidido.** Some `formularios[].ativo` e some `formularios[].motivo_inativo`. **A
presença do destino decide**: `contato.whatsapp_e164` preenchida faz o regime whatsapp
existir; vazia, ele não existe — `formulario.contato-whatsapp` fecha **N/A** com a
condição declarada, dizendo que basta preencher a chave nomeada, e o **CTA não é
publicado**. Nem no comportamento degradado: o bloco do botão sai do HTML servido. A
mesma regra vale para o regime `cf7-email` e `contato.email_leads`.

**Por quê.** Havia dois fatos podendo discordar sobre a mesma coisa, e eles discordavam:
o template nascia com o regime whatsapp declarado `ativo: true` e com o destino vazio, e o
relatório fechava a unidade em BLOCKED por falta de destino de um regime que ele mesmo
acabara de declarar ligado. Uma implantação de template intocado, que tinha dado certo,
terminava dizendo que algo estava errado — que é o mesmo defeito do WARN informativo que a
1.0.15 eliminou. Presença de valor é a condição, e uma condição só: não há como o
interruptor discordar do destino quando o interruptor não existe.

E o CTA não é publicado porque **publicar um botão que não leva a lugar nenhum é pior que
não ter botão**. O que a base entregava era um "Falar com a equipe" cujo `href` apontava
para a própria página de contato: o visitante clicava e não acontecia nada que ele
pudesse chamar de resposta. O discriminante da publicação é a CLASSE do pattern, que mora
no arquivo do tema, e não o atributo `data-f3base-lead`, que é carimbo de render e depende
de `WP_HTML_Tag_Processor` — decidir pelo atributo deixaria o botão publicado justamente
na instalação onde o processador não existe, que é onde menos se quer surpresa.

**O que custa.** Um site cujo operador ainda não preencheu o número perde o botão da
página de contato e do cabeçalho: a página de contato passa a ter o texto e nenhum
acionamento. É deliberado, e o preço é assumido — a alternativa é entregar um botão que
mente. O custo secundário é que o motivo declarado de um regime dormindo deixou de
existir: `motivo_inativo` explicava o interruptor, e sem interruptor o motivo passa a ser
MEDIDO — a chave está vazia —, o que o N/A já diz nomeando a chave.

**Atualizado na 1.1.0 — ver a decisão nº 52.** A frase "o CTA não é publicado" continua
valendo para o botão que ainda aponta para o destino do modelo, e deixou de valer para o
bloco cujo `href` alguém trocou: a supressão passou a ser medida no destino, e não presumida
pela classe.

**Como reverter.** Redeclarar `ativo` no schema e na entrada, e voltar o ramo `if
( ! $ativo )` à etapa de formulários. `formulario.veredito_destino` reprova: o piso exige
N/A no destino vazio e varre as entradas declaradas atrás do interruptor de volta. E
`cta.publicado_pela_presenca_do_numero` reprova a publicação do botão sem número, numa
bancada deliberadamente sem `WP_HTML_Tag_Processor`.

---

## 47. Dado do projeto mora no eixo de convergência, não no gate de aplicação

**Decidido.** O metadado `precondicao` passa a **derivar** o gate da linha: pré-condição
declarada fecha no gate `convergencia`, nunca no de `aplicacao`. Uma condição, um lugar —
quem declara `precondicao` não declara `gate`, e o gate `convergencia` não é escolhido por
ninguém. `privacidade.controlador_identificado` é a residência canônica do eixo, e
`cadencia.mecanismo_declarado` entra pela mesma regra.

**Por quê.** O terceiro eixo nasceu na 1.0.18 exatamente para isto, e ficou pela metade: o
eixo passou a SOMAR as pré-condições declaradas, mas as linhas continuaram no gate de
aplicação. `precondicao` e `gate` eram dois metadados independentes, e uma linha podia ser
as duas coisas ao mesmo tempo — dado que só o operador tem E gate de aplicação. O efeito
estava medido: uma implantação de template intocado, em WordPress limpo, terminava com
BLOCKED de gate de aplicação cuja única causa era dado que o pacote não tem como ter. A
tela dizia que algo estava errado numa implantação que deu certo.

Nenhuma guarda enfraquece com isso, e é importante que fique dito qual é a diferença: a
página da política **continua em rascunho** pela guarda medida do controlador, continua
fora do `llms.txt` e continua sem o link no rodapé; o que era nomeado continua nomeado, na
mesma linha, com as mesmas chaves vazias listadas e o mesmo caminho de saída. O que muda é
**onde o fato é contado** — num eixo que diz a verdade sobre ele, em vez de num gate que
mede outra coisa. A promoção do veredito da unidade continua sendo do gate de aplicação, e
a regra de 1.0.8 continua de pé: checagem de aplicação em BLOCKED promove a unidade, e o
piso de `lotes.gate_de_aplicacao_sem_dado_do_operador` exercita justamente essa diferença.

**O que custa.** Um terceiro valor de gate, e a nota da unidade ganhou uma frase: as
pendências de FASE e as de CONVERGÊNCIA saem em listas separadas, porque são perguntas
diferentes — "este host não produz essa evidência" e "falta um dado que só o operador
tem". Duas frases onde havia uma. E fica um risco declarado: marcar como `precondicao`
algo que o pacote PODE medir seria a porta de escape que absolve qualquer coisa — o mesmo
risco que o gate de fase já tinha, e a mesma resposta: a regra é estreita, entra em
`precondicao` só o que depende de dado do operador.

**Como reverter.** Tirar a derivação de `emitir()` devolve os dois metadados
independentes, e `estatica.precondicao_no_eixo` reprova nos dois ramos: sem a derivação
declarada, e com qualquer emissor que declare `precondicao` e `gate` no mesmo argumento.

---

## 48. Progresso é status ao vivo; encerramento é conclusão, e conclusão vem depois

**Decidido.** A tela do implantador passa a ter dois nós onde havia um. `progresso`
continua sendo o primeiro filho da raiz, com `role="status"` e `aria-live="polite"`, e ao
terminar fica com uma **linha curta e verdadeira**: o que aconteceu, o estado fechado da
aplicação e onde está o resultado completo. O **resumo inteiro** — contagens por escopo,
listas de nomes por estado, resumidas, suspensas, estado da aplicação — mora num nó
próprio, `encerramento`, montado **depois da tabela**.

**Por quê.** O resumo de encerramento era escrito dentro de `progresso`, e `progresso` é o
primeiro filho da raiz porque é isso que um status ao vivo precisa ser. O resultado
aparecia **antes** do log e empurrava a tabela inteira para baixo: quem terminava a
execução lia a conclusão de costas para as linhas que a produziram. São duas coisas com
tempos diferentes — uma que muda a cada lote e outra que só existe no fim —, e duas coisas
não cabem num nó só sem que uma atrapalhe a outra.

**Acessibilidade não é o preço da mudança de lugar, é parte dela.** Mover o nó e parar aí
teria trocado um defeito de leitura por um defeito de acesso: quem navega por teclado ou
por leitor de tela ficaria com o resultado fora do caminho. Então a região tem nome
acessível (`role="region"` mais `aria-label`), é focável por script (`tabindex="-1"`),
recebe o **foco** no instante em que é escrita — o que a anuncia e leva o teclado até ela
—, e a linha do topo, que é a região viva, diz que a execução terminou e onde a conclusão
está. O anel de foco é visível por CSS, porque foco sem indicação visível é foco perdido.

**O que custa.** Um nó a mais na tela e dois lugares para ler o resultado em vez de um —
compensado pela linha do topo apontar para o outro. E o piso ficou mais caro: medir a
ordem no DOM lendo o código-fonte responderia "o `appendChild` está escrito depois", que é
outra pergunta, então a sonda passou a montar um **DOM de mentira** e rodar o cliente REAL
de ponta a ponta contra ele. É mais bancada para manter, e é o que faz a medição ser sobre
a árvore que o operador vê.

**Como reverter.** Escrever o resumo em `progresso` de novo, ou montar o encerramento
antes da tabela. `js.decisoes_do_cliente` reprova nos dois casos, e o piso são **mutantes
do próprio cliente**: a sonda troca `encerramento.textContent =` por
`progresso.textContent +=`, inverte a ordem dos dois `appendChild` e apaga a chamada de
foco, e exige que a bancada acuse os três. Piso que não consegue plantar o defeito prova
que a bancada é cega.

---

## 49. Varredura das chaves declaradas: o que muda se eu mudar isto?

**Decidido.** Toda chave de `config/site.json` passou por um teste só — *o que muda se eu
mudar isto?* — e as que responderam "nada que um operador deste template queira" saíram.
São **cinco chaves**, e cada uma com o motivo próprio:

| Chave | Por que saiu |
|---|---|
| `plugins.origens_url_autorizadas` | lista de hosts no mesmo arquivo que as URLs que ela restringia: guarda de digitação com preço de controle de segurança. Decisão 45 |
| `ambiente.dominios_autorizados` | nascia vazia, deixou de ser gate de indexação na 1.0.12 e virou cross-check; o único efeito de preenchê-la era **ganhar um WARN** quando o host diferia. Regra que gera confusão sem comprar nada |
| `formularios[].ativo` | interruptor ao lado do dado que ele liga, podendo discordar dele — e discordava. Decisão 46 |
| `formularios[].motivo_inativo` | existia para explicar o interruptor. Sem interruptor, o motivo é MEDIDO: a chave de destino está vazia, e o N/A a nomeia |
| `copy_contrato.fonte` | enum de um valor só. A condição `'config' === $fonte` nunca podia ser falsa: tautologia dentro de uma condição que mede duas coisas de verdade. Chave que só pode ter um valor não é ponto de extensão — é um comentário com preço de configuração |

**Por quê.** O critério de aceite desta release é *template intocado, WordPress limpo,
site completo e online, sem que o operador decida nada*. Cada chave é uma decisão pedida a
alguém, e chave que não compra nada em troca dessa decisão é custo puro: mais superfície
para errar, mais documento para manter em dia e mais linha de relatório para o operador
interpretar. **Regra que gera confusão sem comprar nada sai; regra que compra proteção sem
pedir nada fica.**

**O que ficou, e por que ficou — os casos que pareciam candidatos e não são:**

- `plugins.politica_versao` e `plugins.autoupdate` também são enums de um valor só, e
  **ficam**. Eles são a declaração, no arquivo único, das regras 20 e 21 do contrato, e
  `doc.afirmacao_conferida` amarra as frases de `README.md` e de `MANIFESTO.md` a eles por
  `config.igual`. Tirá-los moveria uma política declarada para dentro do código, que é o
  que a regra 11 do contrato proíbe. E eles não pedem decisão nenhuma: nascem corretos.
- `consumidores_declarados` **fica**: tem dois ramos de verdade, e o ramo `false` produz um
  WARN que nomeia a garantia que o relatório perde. É o pacote afirmando algo sobre si
  mesmo, e ninguém precisa tocá-la para publicar um site.
- `ambiente.dominios_de_previa`, `plugins.embarcados`, `seo.robots_extra`, `redirects`,
  `tema.fontes` e `tema.fragmentos_sincronizados` **ficam vazios e ficam**: lista vazia é
  estado válido e declarado, e cada uma delas MUDA o comportamento quando preenchida —
  guarda de indexação, artefato no bundle, linha no `robots.txt`, 301, `@font-face`,
  fragmento sincronizado. Nenhuma delas pede decisão para o site nascer.

**O que custa.** Cinco pontos de extensão a menos. Quem quiser a lista de hosts de volta
tem uma resposta melhor — `sha256` declarado, que é gate duro desde a primeira busca —, e
quem quiser o cross-check de domínio perdeu um diagnóstico que ninguém tinha preenchido.
O maior custo é o precedente: remover chave é irreversível na prática, porque o projeto
que dependia dela já não existe para reclamar. É por isso que cada remoção tem detector.

**Como reverter.** Cada linha de `suite/chaves-removidas.tsv` é o que impede a chave de
voltar por descuido: `estatica.sem_residuo_de_chave_removida` reprova enquanto o nome
estiver na tabela e a chave reaparecer na configuração, no schema, no código ou em
documento fora da narrativa declarada. Devolver a chave começa por tirar a linha da
tabela — e essa é uma decisão que fica escrita.

---

## 50. O pacote deixa de pedir ao canal que recuse a escrita do agente

**Decidido.** O módulo `guarda-options-mcp` sai INTEIRO: o arquivo, a linha do autoload, o
nome na lista do registro único e a linha do inventário. Com ele saem os quatro filtros do
servidor MCP em que ele registrava as options do catálogo
(`wp_mcp_ultimate_protected_options` e três irmãos). No lugar fica um detector com piso —
`estatica.sem_recusa_de_escrita_do_agente` — que reprova qualquer literal de nome de filtro
de options protegidas no runtime do pacote.

**Por quê.** A premissa desta release, nas palavras de quem a definiu: *"Após a instalação,
todas as futuras modificações serão realizadas por um agente através de MCP. Então o
template e plugins não devem tentar evitar que futuras modificações sejam realizadas. Elas
serão permitidas."* O módulo fazia exatamente o contrário, e não por acidente: ele
registrava as vinte options do catálogo — `f3base_contato`, `f3base_tracking`,
`f3base_consentimento`, todas — nos filtros pelos quais o servidor decide o que recusar.
O agente que precisasse gravar um número de WhatsApp encontraria a recusa vinda do próprio
pacote que ele acabara de instalar.

O módulo já declarava, em comentário, que a lista protegida **não** é fronteira de
segurança: as rotas de arquivo do canal alcançam o código que a implementa. Ou seja: ela
não protegia contra quem quisesse mudar, e atrapalhava quem tinha o direito de mudar. A
fronteira real continua onde sempre esteve — usuário dedicado, Application Password e as
travas do canal.

**O que custa.** Some a trava contra acidente. Uma escrita distraída pelo canal sobre
`f3base_nav_id` ou `f3base_endpoint_segredo` deixa de encontrar qualquer resistência. O
que continua existindo é o registro: toda escrita passa pelo gravador único, a procedência
fica gravada em `f3base_proveniencia`, e a cadência do modo somente-relatório relê as
options e reporta o que divergiu. Trocamos recusa por rastro — e rastro é o que serve a
quem opera por agente.

**Como reverter.** Devolver o arquivo, a linha do autoload e o nome no registro.
`estatica.sem_recusa_de_escrita_do_agente` reprova, nomeando arquivo e linha de cada
literal de filtro; a fixture negativa dele é um módulo que registra exatamente esses
nomes. Reverter começa por tirar a checagem, e essa é uma decisão que fica escrita.

---

## 51. O sanitizador normaliza o que conhece e preserva o que não conhece

**Decidido.** Todo sanitizador de option de grupo passa por
`F3Base_Options::preservar_desconhecidas()`: a chave declarada continua sendo normalizada
como sempre, e a chave que o pacote não conhece é PRESERVADA — sanitizada como dado (texto,
número, booleano ou lista deles) e com o nome reduzido ao alfabeto de um nome de chave. Nas
options em lista (`f3base_redirects`, `f3base_journal_eliminacao`) a preservação vale
DENTRO de cada entrada. Piso em `options.chave_desconhecida_preservada`, que varre o
catálogo inteiro e não uma option escolhida a dedo.

**Por quê.** O defeito estava medido e é silencioso, que é o pior tipo. Até a 1.0.19 cada
sanitizador RECONSTRUÍA o array a partir das chaves declaradas — `sanitiza_contato`
devolvia três chaves fixas, `sanitiza_tracking` uma, `sanitiza_consentimento` quatro. O
agente acrescentava `telefone` a `f3base_contato` pelo canal; a escrita entrava no banco; a
primeira LEITURA devolvia o valor sem a chave. Sem erro, sem log, sem ninguém para acusar —
e a leitura de volta conferia contra o valor que a própria sanitização tinha imposto, então
até o gate de gravação dizia que estava tudo certo.

Sob a premissa de que toda modificação futura é do agente, um sanitizador que descarta o
que não conhece é um sanitizador que desfaz trabalho alheio a cada leitura.

**O que custa.** A option deixa de ter forma fechada. Um erro de digitação do agente —
`telefonee` — passa a viver na option para sempre, e ninguém o remove por ele. A garantia
que fica é mais fraca e mais honesta: as chaves QUE O PACOTE LÊ continuam com forma
garantida, e o resto é dado de quem escreveu. O segundo custo é de tamanho: option
autoload que cresce sem teto pesa em toda requisição, e o pacote não impõe teto porque não
sabe o que a chave desconhecida vale para quem a gravou.

**Como reverter.** Tirar as chamadas de `preservar_desconhecidas()` dos sanitizadores.
`options.chave_desconhecida_preservada` reprova, e o piso dela é o reconstrutor de chaves
fixas da 1.0.19 escrito na própria bancada: ele existe ali para provar que a bancada
enxerga o descarte, e não para ser usado.

---

## 52. O CTA só some quando não tem destino, e o `href` só é reescrito quando é do modelo

**Decidido.** `promover_cta()` ganha dois lados que não se cruzam. **Supressão**: o bloco
deixa de ser publicado apenas quando não tem destino nenhum — `href` vazio, `#` ou o
marcador do modelo, E número vazio. **Promoção**: o `href` só é reescrito quando é do
modelo; `tel:`, landing, formulário próprio e qualquer outro destino ficam como estão. A
mesma regra vale no clique, dentro de `f3base-leads.js`, que também reescrevia o `href` sem
olhar. O `<a>` que o pacote promoveu recebe o carimbo `data-f3base-numero`, e é ele que diz
ao cliente que aquele destino é do pacote. Piso nos quatro quadrantes, em
`leads.cta_preserva_destino`.

**Por quê.** Este era o mecanismo mais forte do pacote contra o agente, e ele agia duas
vezes por página: `promover_cta()` suprimia **qualquer** bloco com a classe
`f3base-acao-contato` quando o número estava vazio, e reescrevia o `href` sem checar quando
estava preenchido. Um CTA que o agente tivesse apontado para uma landing de campanha sumia
do HTML servido — sem erro, sem log, com o relatório verde. Um CTA apontado para um `tel:`
voltava a ser `wa.me` a cada render, e voltava a ser `wa.me` de novo a cada clique.

A decisão nº 46 continua de pé no que ela realmente mediu: publicar um botão que não leva a
lugar nenhum é pior que não ter botão. O que mudou é o alcance — "não leva a lugar nenhum"
passou a ser medido no `href`, em vez de presumido pela classe.

**A REGRA PASSOU A RODAR, e essa é a segunda metade desta decisão.** A medição que a
motivou: a supressão **nunca chegou a rodar**, desde a 1.0.19. `promover_cta()` está no
filtro `render_block`, e `F3Base_Site_Core::registrar()` pulava todos os hooks de módulo
inativo; com `contato.whatsapp_e164` vazia o módulo fecha INATIVO, então o filtro só era
registrado quando havia número — isto é, quando a condição da supressão já não podia
acontecer. As duas condições eram mutuamente exclusivas. Medido por sonda: `estado()`
devolvia `inativo`, `deve_registrar()` devolvia `false`, e `hooks()` declarava um
`render_block` que ninguém registrava. Três documentos afirmavam a regra; o que ia ao ar
era o botão morto do pattern, com o `href` do modelo, em toda instalação sem número.

A afirmação estava certa e o código, não — então o código mudou. `hooks()` ganhou a chave
opcional **`sempre`**, e `registrar()` passa a registrar o item marcado mesmo com o módulo
inativo. A marca alcança UM hook em todo o pacote, e o motivo é que a decisão dele é POR
BLOCO e não pelo estado do módulo: o caso mais importante dela — CTA sem número e com o
`href` do modelo — acontece justamente no estado inativo. A invariante continua de pé para
tudo o mais: módulo inativo não enfileira asset, não registra endpoint e não cria tabela, e
`cta.regra_de_publicacao_registrada` mede isso no mesmo bloco em que mede os quadrantes.

A alternativa recusada foi mudar o ESTADO do módulo para ativo: ela alcançaria a supressão
pelo caminho errado, misturando "o regime existe" com "esta regra decide", e deixaria o
apagamento dependente de qualquer futura mudança na conta do estado. A exceção declarada
por hook diz exatamente o que faz, no lugar onde alguém a lê.

E o apagamento que ela torna alcançável é o único que esta release aceita: **o do bloco sem
destino nenhum**. É a mesma chave que decide, não uma chave de outro regime; e publicar um
botão que não leva a lugar nenhum continua sendo pior que não ter botão.

**O que custa.** O reconhecimento do "destino do modelo" depende de um LITERAL declarado:
`/contato/`, o `href` que o pattern do tema entrega. Não há como derivá-lo — depois que o
conteúdo entra no banco, o bloco renderizado não carrega nenhuma marca de quem escreveu
aquele `href`, e o do pattern e o que o agente digitou chegam iguais ao filtro. Quem trocar
o pattern e não declarar o novo valor em `f3base_cta_hrefs_do_modelo` terá um CTA que o
pacote nunca promove: ele passa a ser tratado como destino de alguém. É o erro seguro dos
dois possíveis.

**Como reverter.** Tirar a leitura de `tem_destino_proprio()` do ramo da supressão e a de
`e_do_modelo()` do laço da promoção. `leads.cta_preserva_destino` reprova nos quadrantes 2
e 4, e `js.conversao_multicanal` reprova o clique que reescreve o `href` do agente.

---

## 53. O link da política preenche quando falta, e nunca apaga o parágrafo

**Decidido.** `f3base_link_privacidade()` passa a gravar o `href` apenas quando ele está
vazio ou é `#`. Sem política publicada, ela REMOVE o `href` — o link vira texto — em vez de
devolver string vazia. O arquivo de `parts/footer.html` passa a nascer com `href="#"`,
porque é o valor vazio que autoriza o preenchimento. Piso em
`tema.link_privacidade_preserva`.

**Por quê.** Eram dois defeitos na mesma função, e os dois eram a mesma doença — o tema
mandando no que não é dele. O primeiro: sem política publicada, a função devolvia `''`, e
com ela sumia o PARÁGRAFO INTEIRO — endereço do encarregado, razão social, o que o agente
tivesse posto ali. O remédio para "não apontar para rascunho" é tirar o destino, não sumir
com o texto. O segundo: o `href` era gravado sem olhar, então uma política em PDF externo,
uma página do grupo ou um domínio jurídico voltava a ser o permalink local a cada render.

**O que custa.** Um link sem `href` não é focável pelo teclado e não anuncia destino: é
texto. Numa instalação sem política publicada, o rodapé passa a ter a frase "Política de
Privacidade" sem link, que é menos informativo que a ausência do parágrafo — e é
deliberadamente menos destrutivo. O segundo custo é de migração: quem tiver o `href` antigo
`/politica-de-privacidade/` gravado no conteúdo não recebe mais o permalink real, porque
esse valor passou a ser lido como destino de alguém.

**Como reverter.** Devolver o `return '';` e a gravação incondicional.
`tema.link_privacidade_preserva` reprova nos três tetos, e a bancada da sonda carrega a
função da 1.0.19 escrita ali, como piso, para provar que ela enxerga os dois defeitos.

---

## 54. O cabeçalho emitido é o valor gravado, e o preço sai nomeado

**Decidido.** `sanitiza_cabecalhos()` deixa de devolver `coop` como literal e passa a LER o
valor armazenado, dentro do vocabulário fechado do cabeçalho; o módulo emite a lista por
`lista_de_cabecalhos()`, que devolve nome→valor e é o que a suíte mede. `Referrer-Policy:
no-referrer` continua sendo aceito e passa a sair com um AVISO em WARN, nomeando os quatro
canais que perdem a origem do clique. Pisos em `seguranca.coop_do_valor_gravado` e
`seguranca.referrer_policy_avisa_atribuicao`.

**Por quê.** O COOP era travado em `same-origin-allow-popups` em dois lugares — na
sanitização e no emissor —, e o efeito era o pior possível para quem opera por agente:
gravar outro valor pelo canal *funcionava*, a leitura de volta *conferia*, e o cabeçalho
saía com o valor do pacote. A option existia e não tinha efeito nenhum. O pacote continua
sabendo qual valor o fluxo de leads precisa; o que ele passou a fazer é NOMEAR a
consequência — o CTA abre a conversa em janela nova, e fora de `same-origin-allow-popups` o
navegador corta a relação com ela — em vez de decidir pelo projeto.

O `Referrer-Policy` é o caso simétrico, e ele importa por causa da segunda premissa desta
release: *"O site será usado com GA4 e Ads, além de também ser utilizado para receber
tráfego do LinkedIn Ads e Meta Ads."* `no-referrer` apaga o referenciador de toda saída, e
com ele some a origem que o GA4 usa para classificar a sessão e que Google Ads, Meta Ads e
LinkedIn Ads usam para reconhecer o próprio tráfego quando o clique chega sem parâmetro de
campanha. Recusar o valor seria decidir por quem grava; deixá-lo passar calado seria
entregar uma campanha sem atribuição e sem explicação.

**O que custa.** Um COOP mal escolhido passa a chegar ao navegador. `same-origin` quebra o
retorno da janela do WhatsApp, e quem gravar isso vai descobrir pelo comportamento — o
estado do módulo fica degradado, mas estado degradado não impede nada. O aviso do
`Referrer-Policy` acrescenta uma linha amarela na tela para uma configuração que pode ser
deliberada; ele só existe no ramo adverso, e com o valor padrão nenhum aviso sai.

**Como reverter.** Voltar o literal ao sanitizador e a constante ao emissor.
`seguranca.coop_do_valor_gravado` reprova em quatro asserções, e o piso dela grava um valor
diferente do padrão justamente para que o literal não possa passar por acaso.

---

## 55. Tracking dirigido por valores: um caminho só, um portão só, e nenhum Site Kit

**Decidido.** O site-core passa a emitir as tags de GA4, Google Ads, Meta e LinkedIn a
partir de IDs gravados em options — `f3base_gtm_container_id`,
`f3base_ga4_measurement_id`, `f3base_google_ads`, `f3base_meta_pixel_id`,
`f3base_linkedin_partner_id` e `f3base_linkedin_conversion_id` —, todas nascendo vazias e
inertes. `f3base_gtm_container_id` preenchido decide o caminho: sai o contêiner e mais
nada, e os IDs diretos **nem chegam ao navegador**. Vazio, saem as tags diretas dos IDs
presentes. As quatro passam pelo MESMO `permite_tags()` no servidor e pelo mesmo
`permiteTags()` no navegador. O clique do CTA é a conversão do site e sai nos quatro
canais, de `f3base-leads.js`. Pisos em `tracking.caminho_unico`,
`tracking.consentimento_gateia_tudo`, `leads.click_ids_no_schema` e
`js.conversao_multicanal`.

**Por quê.** O que existia era medição que PARECIA existir, e isso é pior que medição
ausente: ninguém procura o que o console não acusa. O pacote não tinha uma única ocorrência
de measurement ID, de `gtag.js`, de `AW-`, de `send_to`, de `fbq`, de `gclid`, de `fbclid`
ou de `li_fat_id`. O único `gtag` era o STUB do Consent Mode, que torna
`typeof gtag === 'function'` verdadeiro em toda página — então os eventos do CTA entravam
no `dataLayer` como arrays de comando e ficavam lá, esperando um consumidor que nada
carregava. E o evento que saía era `select_content`: `generate_lead` exigia formulário
preenchido, e o template não tem formulário nenhum.

O caminho por Site Kit foi recusado com medida: o OAuth dele é passo humano, e sob a
premissa de que quem opera é um agente, 100% do GA4 e do Google Ads dependeria de alguém
sentar na frente da tela. Valor gravado em option é o que um agente escreve pelo canal.

O caminho único é ESTRUTURAL, e não um `if` no cliente: no caminho do container os IDs
diretos não são publicados. Disparar em dobro deixa de ser um ramo esquecido e passa a ser
impossível, porque não há com o que disparar. Conversão contada duas vezes não é um número
errado num relatório — ela reescreve o lance do leilão.

**O que custa.** Seis options novas para manter, cada uma com forma de fornecedor que pode
mudar. O pacote NÃO recusa ID fora da forma: ele preserva o valor e emite um WARN nomeando
a forma esperada, porque apagar em silêncio é o que esta release inteira parou de fazer — o
preço é que um `G-` faltando produz uma tag que carrega e uma conta que não recebe nada, e
o operador só descobre pelo aviso. As Enhanced Conversions do Google nascem inertes: elas
só têm o que hashear quando um formulário associado fornece e-mail ou telefone, e o
template não tem formulário. O telefone só entra em E.164, com `+` e código do país —
adivinhar o país pelo idioma do site seria inventar um número.

**Como reverter.** Esvaziar as options faz o site voltar a não emitir nada, sem release
nova: é o mesmo mecanismo do slot inerte. Remover o desenho é outra coisa — apagar
`class-f3base-modulo-tracking.php` e `assets/f3base-tracking.js` reprova quatro checagens,
e `tracking.caminho_unico` nomeia o disparo em dobro como o defeito que a estrutura impede.

---

## 56. O contrato de copy sai do catálogo do site-core

**Decidido.** `f3base_copy_contrato` sai do catálogo de options do site-core, junto com
`sanitiza_copy_contrato()`. A suíte continua conferindo o contrato de copy contra o pacote
por `copy.contrato`, lendo `config/site.json`; o SITE deixa de carregar o contrato.

**Por quê.** Nenhum módulo o lia. A varredura é curta e conclusiva: `copy_contrato` aparecia
no catálogo, no sanitizador e em mais lugar nenhum do site-core. Era artefato de build para
o conteúdo do template — e vira falso no instante em que o agente troca o conteúdo, que é
exatamente o que a premissa desta release diz que vai acontecer. Uma option que ninguém lê
e que envelhece sozinha é pior que uma option ausente: ela dá ao próximo leitor a impressão
de que alguma coisa está sendo conferida dentro da instância.

**O que custa.** Quem quisesse conferir o contrato de copy DENTRO de um site publicado
perde o espelho. Ninguém fazia isso, e quem quiser fazer tem a suíte, que mede o pacote
inteiro e não só as frases que couberam numa option.

**Como reverter.** Devolver a entrada ao catálogo e o sanitizador. Nada reprova por si —
esta é uma remoção sem detector próprio, e está escrita aqui por isso.

**PENDENTE PARA A PARTE 2 DESTA RELEASE.** A escrita continua existindo em
`includes/class-f3base-imp-lotes.php`: a option é gravada no lote de options do site-core e
relida logo abaixo para a linha `copy.contrato_espelhado`. As duas precisam sair, junto com
a entrada de `f3base_copy_contrato` na lista literal de `options_gerenciadas()` em
`includes/class-f3base-imp-relatorio.php`. Enquanto não saírem, o implantador grava uma
option que o site não lê — que é o defeito descrito acima, um nível acima.

---

## 57. O que FICA como está, e por quê

Três mecanismos foram examinados sob a premissa do agente e **não** mudam. Estão aqui
porque decisão de não mudar também é decisão, e porque a próxima leitura vai fazer a mesma
pergunta.

- **O CPT de leads fechado ao REST fica fechado.** `show_in_rest => false` no CPT de
  contingência não é impedir modificação: é não expor dado pessoal de titular a toda
  credencial autenticada do site, que é o que abrir o REST faria. O agente lê os leads
  pelas rotas de banco do canal, que são credenciadas e auditadas. A saída existe e é
  documentada; o que não existe é a exposição por padrão.
- **A regra dinâmica de `noindex` em categoria rasa fica.** Ela já tem saída declarada, e a
  saída é do agente: gravar `wpseo_noindex = 'index'` no termo faz a categoria passar a ser
  indexada, e o módulo honra o valor do termo em vez de recalcular. Nenhuma release é
  necessária, nenhum arquivo é editado — é uma escrita de meta pelo canal.
- **O contador de ajustes da cadência fica.** Sob a premissa, ele é útil justamente por ser
  o que é: edição do agente conta como ajuste, e ao alcançar o alvo declarado dispara o
  relatório. Um agente que edita muito produz mais relatórios, e é isso que se quer de um
  site cuja manutenção é feita por quem não abre a tela.

---

## 58. As options ganham a regra de três vias, e a sobreposição sai com os dois valores

**Decidido.** Toda option do bloco do `site-core` passa por
`F3Base_Imp_Gravador::merge_option()` antes de qualquer escrita. O pacote registra a
**base** — o último valor que ele mesmo aplicou — e compara as três vias. Cinco ramos:
observado igual ao desejado não grava; base igual ao observado é atualização segura; base
igual ao desejado com observado diferente **preserva**; os três diferentes gravam
**nomeando a sobreposição com os dois valores**; e sem base a primeira execução aplica o
desejado **dizendo que a base nasceu agora**. A linha
`options.edicao_do_agente_preservada` fecha OK quando houve preservação e WARN quando
houve sobreposição — o único ramo adverso.

**Por quê.** O defeito estava medido e é de duas linhas:
`includes/class-f3base-imp-gravador.php`, no ponto em que ele calculava `$mudaria` e
gravava. Não havia base, não havia três vias, e o laço do bloco de options gravava as doze
options a partir de `config/site.json` a cada execução. Sob a premissa desta release — *"Após
a instalação, todas as futuras modificações serão realizadas por um agente através de MCP.
Então o template e plugins não devem tentar evitar que futuras modificações sejam
realizadas."* — isso significa que semanas de trabalho do agente eram apagadas no instante
em que alguém reativasse o implantador. Sem erro, sem log, com o relatório verde: a
gravação lia de volta e conferia, porque conferia contra o valor que ela mesma tinha
acabado de impor.

A regra do conteúdo já existia desde a 1.0.4 e é a mesma; o que faltava era aplicá-la ao
outro artefato. A base mora na option de infraestrutura que já guardava a do conteúdo —
`f3base_base_merge`, seção reservada `__options__` —, e não numa segunda estrutura: duas
estruturas para a mesma pergunta são duas chances de divergir e dois lugares para limpar.

**A PRIMEIRA EXECUÇÃO É DECLARADA, e essa é a metade que a 1.0.19 nos ensinou.** Estrutura
de estado nova que não diz o que faz quando ainda não há estado absolve a si mesma para
sempre. Aqui: numa instalação que tem a option e não tem base, o observado vira base e o
desejado é aplicado — e o relatório imprime QUAIS options tiveram a base nascida naquela
execução, porque só nela o pacote não consegue distinguir uma edição feita pelo canal de
um valor que sempre esteve ali.

**O que custa.** A base é mais uma estrutura de estado a manter, e ela pode ficar
desalinhada da realidade: quem apagar `f3base_base_merge` pelo canal faz toda option voltar
ao ramo "base nasceu agora" — e a próxima execução aplica a configuração por cima do que
estiver lá. É o custo declarado de uma regra que depende de memória. O segundo custo é de
tamanho: a base guarda o valor aplicado, e não só a impressão dele, porque a união dos
redirects precisa dos pares. A option não é autoload.

O terceiro custo é o mais importante, e ele é de MIGRAÇÃO: na primeira execução da 1.1.0
sobre uma instalação existente, nenhuma option tem base, e o desejado é aplicado em todas
— inclusive por cima de uma edição que o agente tivesse feito antes desta release. A
alternativa seria não aplicar nada na primeira execução, e ela é pior: o pacote deixaria de
convergir para a configuração sem que nada dissesse por quê. A linha do relatório nomeia as
options em que isso aconteceu.

**Como reverter.** Tirar `'base' => true` do contexto das escritas do bloco de options.
`options.merge_tres_vias` reprova nos cinco ramos e nas três frases que cada um precisa
imprimir, e a bancada mede a impressão que decide contra o mesmo round-trip da leitura de
volta — sem isso a regra passaria a decidir pelo tipo do valor em vez de pelo valor.

---

## 59. O conteúdo do template deixa de vencer o conteúdo do cliente

**Decidido.** Em `F3Base_Imp_Conteudo::merge_campo()`, o ramo `base ≠ observado ≠ desejado`
com política `gerenciado` passa de **gravar** para **preservar**. O pacote só grava
conteúdo em objeto que ninguém tocou — o ramo `base === observado`. Os campos preservados
saem NOMEADOS na linha do objeto, e essa é a segunda metade da decisão.

**Por quê.** O conteúdo que este pacote traz é DEMONSTRATIVO: ele existe para ser
substituído, e `conteudo.demonstrativo` já diz isso em voz alta a cada rodada. Uma vez que
o agente trocou o texto do template pelo do cliente, uma atualização do template não tem
por onde saber que o texto novo dela é melhor que o texto que está no ar — e a política
`gerenciado` fazia exatamente isso, silenciosamente, a cada reexecução.

A política de campo continua discriminando, e no único lugar em que ela ainda pode: SEM
BASE. Ali `gerenciado` aplica o desejado e `preservar` mantém o observado, porque é a
primeira execução e não existe edição a proteger nem a atropelar.

**A segunda metade: as decisões do merge nunca chegavam ao relatório.** `aplicar_objeto()`
montava um array `decisoes` e o devolvia em `saida()`, e NENHUMA linha do pacote lia esse
campo — a varredura é conclusiva, `'decisoes'` aparecia uma vez, no produtor. A decisão
mais importante da aplicação, que é o que o pacote deixou de gravar e por quê, não tinha
leitor. Preservar calado é indistinguível de não ter medido nada, então a divergência
preservada passou a entrar na mensagem do objeto, com os campos nomeados.

**O que custa.** Um site cujo conteúdo divergiu por engano — alguém salvou uma página no
editor sem querer — não é mais corrigido pela reexecução do implantador. A saída é do
agente: reescrever o conteúdo pelo canal, ou apagar a base daquele objeto. É o erro seguro
dos dois possíveis, e é o mesmo que a 1.1.0 escolhe em todos os outros lugares.

**Como reverter.** Devolver `'acao' => 'gravar'` ao ramo `gerenciado`.
`conteudo.merge_tres_vias` reprova na linha correspondente e no piso da regra inteira, que
percorre as quatro políticas e exige que NENHUMA produza gravação sobre observado diferente
da base.

---

## 60. Par de redirect removido pelo agente não ressuscita

**Decidido.** `uniao_de_redirects()` ganha uma quarta parcela, e ela é uma SUBTRAÇÃO: par
que estava na base da option e não está mais no valor observado foi apagado por quem opera
o site, e não volta — nem pela configuração, nem por uma etapa que o recompute. A lista de
removidos é DURÁVEL: ela viaja na base da option, sob a origem `removido-pelo-operador`, e
é ela que impede a execução seguinte de recriar o par. Presença no observado vence a
memória da remoção: refazer o par pelo canal o traz de volta e apaga a marca.

**Por quê.** A união unia três fontes e rederivava, a cada execução, todo par declarado na
configuração ou computado por uma etapa. O agente que apagasse um 301 obsoleto da option
via o par ressuscitar na reexecução seguinte, sem nada no relatório. O par NOVO do agente
já sobrevivia — `preexistente` existe desde a 1.0.11 —, mas a subtração não tinha como ser
expressa: ausência não deixa rastro, e sem base não havia contra o que compará-la.

**A MARCA NÃO VIAJA DENTRO DE `f3base_redirects`, e isso foi medido antes de decidir.** O
módulo de redirects do `site-core` serve TODO par da option, sem olhar a origem: um par
marcado ali continuaria redirecionando, e a marca teria o efeito exatamente contrário ao
pretendido. Ela mora na base de merge, que é infraestrutura do implantador e que o
`site-core` não lê.

**O que custa.** A remoção passa a ser lembrada, e lembrança é estado. Quem apagar
`f3base_base_merge` perde a memória das remoções, e os pares declarados voltam na execução
seguinte. E há um caso que a regra não distingue: par que sumiu da option por corrupção de
dados é tratado como remoção deliberada. O relatório o NOMEIA, que é a única defesa
possível — e é mais barata que ressuscitar o par de quem o apagou de propósito.

Há também uma interação medida na bancada de ponta a ponta, e ela é o preço de a base ser
por OPTION e não por par. Repontar um par declarado pelo canal, sem removê-lo antes, é
PRESERVADO pela regra de três vias da decisão 58 — o desejado volta a ser o declarado, que
é igual à base, e a edição vence. Mas remover o par e recriá-lo com outro destino cai em
SOBREPOSIÇÃO: a base ficou vazia na remoção, os três valores passam a divergir, e o
declarado da configuração é aplicado. O caminho longo dá um resultado diferente do curto —
e a diferença sai NOMEADA com os dois destinos, que é o que esta release exige do único
ramo em que o pacote vence quem opera o site.

**Como reverter.** Tirar o quarto argumento de `uniao_de_redirects()` e os dois laços de
lápide. `lotes.redirects_uniao` reprova em seis asserções novas: o par declarado que volta,
o par computado que volta, a remoção que não fica registrada, a origem errada, a lista
durável que não segura na execução seguinte e o par refeito que não volta a existir.

---

## 61. A cadência agenda com a recorrência declarada, e a queda anterior é reparada

**Decidido.** Três mudanças na mesma etapa. A option `f3base_cadencia` passa a ser gravada
**antes** do agendamento. `cadencia` declara dependência de `site_core` em
`F3Base_Imp_Plano`. E a decisão da recorrência virou função pura,
`veredito_da_recorrencia()`, com três ações fechadas: `agendar`, `reagendar` e `manter`.

**Por quê.** Medido na execução real: o log registrou `daily` com a configuração declarando
`mensal`. A cadeia é esta, e ela é circular. Quem registra `f3base_quinzenal` e
`f3base_mensal` é o módulo `cadencia-relatorio` do `site-core`, num filtro `cron_schedules`.
Módulo INATIVO não registra hook nenhum, e esse módulo fica inativo enquanto
`f3base_cadencia` não existir. Quem grava `f3base_cadencia` é esta etapa — DEPOIS de
agendar. Na primeira execução, portanto, a recorrência declarada não podia existir: o
agendamento acontecia na única execução em que ele não tinha como dar certo.

E a degradação era PERMANENTE. Na execução seguinte o módulo já estaria ativo e a
recorrência existiria, mas a etapa encontrava `wp_next_scheduled()` verdadeiro e não olhava
COM O QUE o evento tinha sido agendado. O `site-core` fechava degradado dizendo "reexecute a
etapa de cadência do implantador com este plugin já ativo" — e a reexecução não mudava
nada.

**O REPARO TEM ALCANCE ESTREITO, de propósito.** Ele só troca a recorrência quando a
observada é exatamente a recorrência de queda, a declarada é outra e a declarada existe
agora no agendador. Qualquer outra recorrência no evento é decisão de quem opera o site, e
esta etapa não a desfaz — que é a mesma regra do resto desta release. A tabela de
recorrências continua vindo do MÓDULO: quando ele está carregado e o filtro não foi
registrado nesta requisição, a etapa registra o filtro DELE, em vez de escrever "quinze
dias" e "trinta dias" numa segunda fonte.

**O que custa.** Um reagendamento joga a próxima execução da cadência para daqui a um dia,
e isso acontece uma vez por instalação degradada. E há um caso que a regra não distingue:
quem tiver escolhido `daily` deliberadamente, com a configuração declarando outra coisa,
tem a escolha desfeita — `daily` é justamente o valor que a nossa degradação escreve, e os
dois chegam iguais à etapa. O relatório nomeia a troca.

**Como reverter.** Voltar a gravar `f3base_cadencia` depois do agendamento, ou tirar o ramo
`reagendar`. `cadencia.recorrencia_declarada` reprova nos dois lados: sem o site-core na
tabela a queda precisa acontecer e sair nomeada, com ele a recorrência agendada precisa ser
a declarada, a queda anterior precisa ser reparada, e o piso do falso positivo exige que
uma recorrência que não é a nossa queda continue intocada.

---

## 62. A caixa de leads passa a morar dentro do regime que a consome

**Decidido.** `contato.email_leads` sai do topo de `contato` e vira
`formularios[].caixa_de_leads`, na entrada do regime `cf7-email` que a declara como
`destino`. O implantador deixa de gravar a subchave `email_leads` em `f3base_contato`. O
caminho antigo entra em `suite/chaves-removidas.tsv`, e um detector novo —
`estatica.destino_de_formulario_resolve` — passa a cobrar que todo `destino` resolva numa
chave existente e que caminho com índice aponte para a PRÓPRIA entrada.

**Por quê.** Aplicado o teste da 1.0.19 — *o que muda se eu mudar isto?* — a resposta foi:
duas linhas de relatório, e mais nada. `grep -rn email_leads fontes/` devolve três
ocorrências, todas no catálogo de options do `site-core`: o padrão, a declaração de subcampo
e o sanitizador. Nenhum módulo lê o valor. Preencher a chave não instala o Contact Form 7,
não cria o formulário, não cria a página de confirmação e não manda e-mail para lugar
nenhum: ela flipa `formulario.landing-cf7` de N/A para OK e `formulario.regime_cf7` de N/A
para BLOCKED.

A chave sentava ao lado de `contato.whatsapp_e164`, e a simetria era falsa: o número do
WhatsApp TEM consumidor em runtime — o módulo do CTA o lê e publica o botão —, e a caixa de
leads não tinha nenhum. Ela não é identidade de contato do site; é propriedade de um regime
de formulário, e passou a morar nele.

**Por que ela não SAIU inteira.** A alternativa era remover a chave e, com ela, a entrada
do regime — `destino` vazio faz `veredito_destino()` fechar FALHA, e não há terceira
posição. Isso apagaria o conjunto fechado do regime, que o pacote registra de propósito para
quem precisar dele. Mover é reversível; remover a entrada não é.

**O que custa.** O caminho passou a ter um ÍNDICE dentro —
`formularios.1.caixa_de_leads` —, e índice em caminho quebra quando alguém reordena a
lista, em silêncio: a entrada 1 passaria a ler a chave da entrada 0. É um preço criado por
esta decisão, e por isso ele veio com detector próprio, com fixture negativa e positiva em
disco. O segundo custo: o implantador deixou de escrever `email_leads` em `f3base_contato`,
e na PRIMEIRA execução da 1.1.0 — aquela em que a base ainda não existe — um valor que
alguém tivesse gravado ali pelo canal é sobreposto. Da segunda execução em diante a regra de
três vias o preserva.

**Como reverter.** Tirar a linha de `suite/chaves-removidas.tsv` e devolver a chave a
`contato`. Enquanto a linha estiver lá, `estatica.sem_residuo_de_chave_removida` reprova o
caminho antigo em configuração, schema, código e documento.

---

## 63. O que a suíte consome do arquivo único passa a ser declarado

**Decidido.** `estatica.detector_chave_sem_consumidor` ganha uma âncora,
`f3b_config_lida_pela_suite()`, que declara os caminhos de `config/site.json` consumidos
pela PRÓPRIA SUÍTE — hoje um só, `copy_contrato`, lido por `copy.contrato`. A declaração
não absolve sozinha: cada caminho precisa aparecer LITERALMENTE no arquivo da suíte que se
diz o consumidor, e a conferência roda contra a suíte que está executando, não contra a raiz
varrida.

**Por quê.** O detector enxergava UMA forma de leitura, `Config::obter|lista|existe`, que é
a do implantador. Enquanto toda chave do arquivo único tivesse também um leitor no
implantador, isso bastava — e bastou por acaso, não por desenho. A decisão 56 tirou
`f3base_copy_contrato` do catálogo do `site-core`; esta release tirou a escrita da option e
o espelho do implantador. Com eles saiu o último leitor de `copy_contrato` no código do
implantador, e o detector passou a acusar como órfã uma chave que TEM consumidor — a suíte,
que a lê direto do JSON decodificado.

A correção óbvia seria devolver a option morta, e ela é a errada: é justamente o defeito que
a decisão 56 descreveu. A correção certa é o detector saber que existe uma segunda forma de
consumo, e que ela é declarada.

**O que custa.** Uma lista que, mal usada, vira lista de exceções: bastaria acrescentar um
caminho para calar o cruzamento sobre ele. A guarda é a conferência literal, e ela é fraca —
o caminho pode estar num comentário do arquivo declarado. É uma guarda melhor que nenhuma e
pior que um consumidor de verdade, e está escrito aqui que é assim.

**Como reverter.** Esvaziar a âncora. `estatica.detector_chave_sem_consumidor` volta a
acusar `copy_contrato` e as nove chaves abaixo dela, e a próxima pessoa reabre esta
discussão com a lista na frente.

---

## 64. Quem preserva não move a base, e é isso que faz a preservação durar

**Decidido.** `merge_campo()` e `merge_option()` passam a devolver, junto da ação, o
DESTINO DA BASE — `desejado` ou `inalterada` — e os dois chamadores obedecem a ele em vez
de inferi-lo da ação. Ramo que preserva devolve `inalterada`: a base fica exatamente onde
estava. Ramo que aplica alguma coisa devolve `desejado`.

**Por quê.** O defeito foi encontrado numa bancada de ponta a ponta montada para conferir
a plumbing da decisão 58 — não a função pura, que já tinha piso, e sim o que acontece com
o BANCO em execuções sucessivas. A sequência medida: execução 1 grava e a base nasce; o
agente grava um número de WhatsApp pelo canal; execução 2 PRESERVA, correto; execução 3,
com a configuração mudada, devia sair como SOBREPOSIÇÃO e saiu como *atualização segura,
ninguém editou esta option pelo canal* — uma frase falsa, sobre uma edição que existia.

A causa é de uma linha. O ramo `preservar` gravava a base como o valor OBSERVADO, e base
igual ao observado é justamente a condição do ramo "ninguém tocou". A preservação, então,
apagava o fato que ela existe para lembrar: na execução seguinte a edição intocada passava
a ser lida como valor do próprio pacote, e a primeira mudança da configuração gravava por
cima dela **sem nomear sobreposição nenhuma**. A proteção valia por uma execução, e o
único ramo em que o pacote vence quem opera o site — o que precisa ser visível — ficava
praticamente inalcançável.

**O CONTEÚDO TINHA O MESMO DEFEITO, e ele é anterior a esta release.** `aplicar_objeto()`
faz `$nova_base[$campo] = $hash_obs` no ramo `preservar` desde a 1.0.4. Com a política
antiga isso passava despercebido, porque `gerenciado` gravava de qualquer jeito; com a
inversão da decisão 59 ele viraria o buraco no meio da garantia — o conteúdo do cliente
sobreviveria a UMA atualização do template e seria sobrescrito na seguinte. A correção é a
mesma nos dois lugares, e por isso a regra virou parte do contrato das duas funções puras
em vez de uma linha certa em cada chamador.

**O que custa.** A divergência preservada é RE-RELATADA em toda execução, para sempre,
enquanto a configuração e o site discordarem. É ruído deliberado: a alternativa é o
relatório calar sobre uma divergência que continua existindo. E a convergência deixa de
acontecer sozinha — um site cuja option divergiu por engano só volta a acompanhar a
configuração quando alguém mudar a configuração ou apagar a base daquele item.

**Como reverter.** Devolver `BASE_DESEJADO` ao ramo `preservar` de qualquer uma das duas
funções. `options.merge_tres_vias` e `conteudo.merge_tres_vias` reprovam nomeando a
consequência — a preservação que dura uma execução —, e os tetos do mesmo bloco exigem o
contrário para os ramos que aplicam: valor aplicado que não vira base faria o pacote
reaplicar o mesmo item em toda execução, e a preservação nunca teria contra o que comparar.

---

## 65. Duas correções fora do roteiro desta parte, e por que elas foram feitas

**Decidido.** Duas coisas que não estavam na lista desta parte da release foram corrigidas,
e ficam registradas aqui porque decisão fora do roteiro é a que mais precisa de rastro.

**A descrição do catálogo do `site-core` para `f3base_cabecalhos`.** Ela dizia *"COOP fica
travado em same-origin-allow-popups"* — uma frase que a decisão 54, desta mesma release,
tornou falsa: o cabeçalho emitido passou a ser o VALOR GRAVADO, e o sanitizador daquele
mesmo arquivo já explicava isso três funções abaixo. A descrição é o texto que o operador e
o agente leem na tela de options, e afirmar trava onde não há trava é pior que não
descrever nada: quem lesse aquilo deixaria de tentar gravar um valor que o pacote aceita. A
frase passou a dizer o que o módulo faz — emite o gravado, e NOMEIA a consequência de sair
de `same-origin-allow-popups` em vez de recusá-la.

**O bundle da identidade anterior em `dist/`.** `dist/implantador-base-1.0.19.zip`
continuava ao lado do bundle novo. `dist/` é saída de build e nenhuma checagem reprova por
um artefato a mais ali, mas dois bundles no mesmo diretório são dois candidatos a upload, e
o antigo carrega a configuração e os documentos de uma identidade que já não existe. Ele
saiu. O comando único regrava `dist/` a cada rodada, e é ele quem produz o bundle da
identidade declarada.

**O que custa.** O primeiro é edição num arquivo que esta parte da release não tinha como
escopo, e está aqui por isso. O segundo apaga um artefato que alguém poderia querer para
comparação — e a resposta é que o artefato de uma release anterior mora no repositório de
artefatos, não na saída de build da árvore de trabalho.

**Como reverter.** As duas são de uma linha e de um arquivo. Nenhuma tem detector próprio:
a primeira é prosa dentro do catálogo, e a segunda é o conteúdo de um diretório gerado.
Estão escritas aqui porque é isso que sobra quando não há detector.

---

## 66. Site Kit sai do catálogo base; a emissão é do `site-core` em toda instância

**Decidido.** `plugins.protegidos` passa de `["google-site-kit"]` a `[]` — lista vazia é
estado válido e declarado. O Site Kit sai do catálogo base e do exemplo de plugin
protegido. A emissão de toda tag de medição é do módulo `tracking` do `site-core`,
dirigida por IDs gravados em options, em **toda** instância da fábrica. Onde um cliente o
mantiver, ele é plugin **operacional de leitura**, com o snippet e a medição automática de
conversões desligados — e a suíte acusa qualquer segundo emissor.

Cinco mudanças carregam a decisão. O adaptador de SEO grava
`google_site_kit_feature_enabled` **nos dois ramos**: `true` só quando o plugin de console
está ativo **e** declarado em `plugins.operacionais` ou `plugins.protegidos`, `false` nos
demais — e o par slug ↔ chave sai da declaração, nunca de literal no código. O preflight
ganha a classe **`emissor-concorrente`**, com a condição de emissão medida quando há option
conhecida. O estado do módulo `tracking` passa a dizer, nos dois lados, se há emissor
concorrente detectado. `tracking.emissor_unico` mede a contagem no HTML publicado.
`plugins.emissor_concorrente` mede a classificação e os quatro pares do adaptador de SEO.

**Por quê.** O buraco é de forma, e é o mesmo que a decisão 55 não podia fechar:
`tracking.caminho_unico` prova que o módulo não emite pelos DOIS caminhos dele mesmo —
container × direto — e **não vê um emissor de fora**. Um plugin de console imprimindo
`gtag.js` ao lado do `site-core` é contagem em dobro que nenhuma configuração declarou, com
o relatório verde.

Os fatos abaixo foram lidos pelo canal MCP num site em produção, em 2026-09-03, e são o
que move esta decisão de preferência para medição:

- `google-site-kit/includes/Modules/Analytics_4/Tag_Guard.php`: a guarda que decide se a
  tag do GA4 sai lê **só** `useSnippet` e `measurementID`. Não consulta autenticação — a
  tag continua saindo com o OAuth expirado. Isso pesa a favor do plugin na robustez e
  **contra** ele no controle: nada do que a suíte mede governa aquela emissão.
- `googlesitekit_conversion_tracking = {enabled: true}`: o provedor de CF7 dispara
  `submit_lead_form` no envio, enquanto o `site-core` dispara `generate_lead` na
  confirmação. Um envio, dois eventos de lead com nomes diferentes; marcados os dois como
  conversão, é contagem em dobro que nenhuma configuração nossa declarou.
- `googlesitekitpersistent_remote_features`: 31 feature flags remotas, atualizadas por
  cron duas vezes ao dia. Comportamento de produção alterável por flag do fornecedor, sem
  atualização de plugin e sem release nossa.
- Peso no front-end da home: `googlesitekit-events-provider-contact-form-7` 7.334 bytes,
  mais um stub de 23 bytes, mais script inline e linhas de `linker`. O
  `f3base-tracking.js` tem 5.768 bytes (2.308 gzip). **O argumento de peso NÃO
  discrimina os dois caminhos**: o `gtag.js` do Google é igual nos dois e domina.
- Homologação: o laboratório não tem OAuth, e o caminho do GA4 pelo Site Kit fecha BLOCKED
  em toda rodada local. O caminho interno tem piso — `tracking.caminho_unico` e
  `tracking.consentimento_gateia_tudo`.
- Verificação do Search Console: propriedade `sc-domain:`, sem `google-site-verification`
  no HTML publicado. A verificação é por DNS, e independe do plugin.

**O DISCRIMINANTE, e ele é a metade que faz a regra existir.** "Handle" NÃO EXISTE no HTML
servido. O que existe é o `id`: o WordPress imprime `id="<handle>-js"` para
`wp_enqueue_script` e `id="<handle>-js-extra"` para o inline, e o carregador do `site-core`
põe um `id` próprio em cada tag que cria no navegador. A checagem conta emissão **com** a
marca contra emissão **sem** a marca, e as marcas saem MEDIDAS das fontes — a constante
`HANDLE` do módulo e as chamadas de `inserir()` do carregador —, nunca escritas dentro da
checagem. Sem isso a contagem não distingue os dois e aprova por acaso.

**AS DUAS SUPERFÍCIES SÃO DIFERENTES, e isto foi medido neste pacote.** No HTML **servido**
o `site-core` imprime UM script — o carregador, marcado — e **nenhum** carregador de
fornecedor: `gtag/js`, `gtm.js`, `fbevents.js` e `insight.min.js` nascem todos de
`document.createElement('script')` dentro de `assets/f3base-tracking.js`. Logo, na rota de
origem a contagem marcada de carregador de fornecedor é **zero**, e qualquer um deles ali é
emissão de fora — regra mais forte, e não mais fraca, que a que a orientação descrevia. No
DOM **renderizado** as tags do `site-core` existem, cada uma com o `id` que o carregador
lhe deu, e aí sim a contagem esperada é a que o caminho e os slots determinam: no caminho
do container, exatamente um `gtm.js` marcado e nenhum `gtag/js`. A regra carrega as duas
superfícies com esse nome, e `suite/casos-de-emissor.tsv` declara os oito casos.

**A LISTA DE SLUGS É DICA, NUNCA O GATE**, e está escrito no próprio arquivo.
`fontes/site-core/dados/emissores-conhecidos.tsv` existe para o preflight NOMEAR o suspeito
antes de qualquer mutação — que é o único momento em que nomear ainda serve para alguma
coisa. Ela envelhece: plugin novo aparece toda semana e slug muda de dono. Quem decide é a
medição do HTML: slug fora da lista que emita é pego pelo HTML, e slug na lista que não
emita fecha `leitor`. É por isso que a classe `emissor-concorrente` **não desativa nada** —
a premissa do agente continua valendo, e o pacote nomeia em vez de decidir.

**O que custa.** Três preços, e nenhum é pequeno.

O primeiro é o que a decisão 55 já cobrava e que esta decisão torna definitivo: a operação
passa a **manter o formato do snippet do Google e as formas de ID dos quatro
fornecedores**. Não há mais um plugin do fornecedor absorvendo mudança de formato. A
mitigação é a que já existe — WARN nomeando a forma esperada — e a leitura de volta do HTML
na cadência do somente-relatório.

O segundo é a lista que envelhece. Um plugin emissor novo não é classificado cedo, e só é
pego quando o HTML for medido — isto é, em produção, não no preflight. É o erro seguro dos
dois possíveis, e é por isso que a lista não pode ser o gate.

O terceiro é de arquivo: a regra do segundo emissor precisa rodar em dois runtimes que não
se enxergam — no `site-core`, para o estado do módulo, e no implantador, no preflight, que
roda ANTES de o `site-core` existir na instalação. A saída foi `F3Base_Emissores`, sem pai e
sem dependência, carregada pelo autoload do `site-core` e por `require_once` do implantador,
da cópia de origem. É um arquivo alcançado por dois caminhos diferentes, com guarda de
`class_exists` — e duas cópias da regra teriam sido pior: elas divergem na primeira
condição acrescentada.

**Como reverter.** Sem release nova: declarar o plugin em `plugins.operacionais` e esvaziar
os slots do `site-core` — o site volta a emitir pelo plugin, e `tracking.emissor_unico`
passa a fechar WARN em vez de FALHA, porque com slot vazio não há dobro a acusar, e sim
medição fora do `site-core` que a decisão do projeto autoriza. Devolver o Site Kit a
`plugins.protegidos` é uma linha do arquivo único. Remover o desenho é outra coisa:
apagar a classe compartilhada ou o TSV reprova `tracking.emissor_unico_discrimina` e
`plugins.emissor_concorrente`, e voltar o adaptador de SEO a gravar só o ramo `true` reprova
os quatro pares de `(ativo, declarado)` da sonda.

---

## 67. A metade de servidor da conversão da Meta, e o preço que já era pago sem ela

**Decidido.** O `site-core` ganha o módulo `meta-capi`. Depois da persistência CONFIRMADA
de um lead — a mesma transação lógica que a 1.0.18 declarou: reserva firme porque o lead
está gravado —, o endpoint agenda o envio do evento `Lead` para a Conversions API da Meta,
com o **mesmo `event_id`** que o navegador já manda no Pixel. O token de acesso é a option
`f3base_meta_capi_token`, e ele **não existe** no `config/site.json` nem no schema.

**Por quê.** O defeito estava medido dentro do próprio pacote, e ele é do tipo mais caro:
uma metade construída pagando o preço da outra. A 1.1.0 gera o `event_id` no clique do CTA
e o manda em `fbq('track','Lead',{},{eventID})` — *exatamente* para deduplicar contra um
evento de servidor. Esse evento nunca era enviado. O pacote carregava um identificador a
mais em toda conversão, escrevia a palavra "deduplicação" em três documentos, e a cobertura
que ela existe para dar não existia: o pixel de navegador é a metade que iOS e bloqueadores
cortam, e não havia nada preenchendo o buraco.

**O TOKEN É OPTION, E ESSA É A METADE DA DECISÃO QUE MAIS IMPORTA.** `config/site.json`
viaja dentro do zip: a suíte o lê, o empacotador o embute, o bundle vai para quem faz o
upload, e a cópia fica no repositório de artefatos. Um token declarado ali é um token
copiado para todo lugar por onde o pacote passou — e a cópia sobrevive a qualquer rotação
da credencial, porque ninguém volta ao zip para apagá-la. A ausência dele no arquivo único
é a declaração, e ausência sem detector é só esquecimento com boa intenção: por isso a
release traz `estatica.segredo_fora_da_configuracao`, com âncora no próprio pacote
(`F3Base_Options::segredos_do_site()`) e fixture negativa que planta os três defeitos de uma
vez — a chave na configuração, a chave no schema e o lote do implantador gravando o valor.
`f3base_endpoint_segredo` entrou na mesma âncora, pelo mesmo motivo.

**O MEIO DO ENVIO PÓS-RESPOSTA, e por que ele não é `shutdown`.** A escolha foi o evento
único do agendador — `wp_schedule_single_event()` —, e as duas alternativas foram recusadas
com motivo. `shutdown` roda no MESMO processo: sem `fastcgi_finish_request()` a conexão
fica aberta e o worker fica ocupado pelo tempo inteiro da chamada à Meta, inclusive pelo
timeout dela; a resposta já foi escrita, mas a requisição não terminou, e sob rajada de
leads é a fila do servidor que paga. `fastcgi_finish_request()` resolveria isso e não é
portátil — depender dela seria um caminho que funciona no laboratório e desaparece na
hospedagem do cliente, em silêncio. O evento único roda em OUTRA requisição, disparada pelo
próprio WordPress, e é o mesmo mecanismo que a cadência deste pacote já usa.

**O PAYLOAD NÃO VIAJA NOS ARGUMENTOS DO EVENTO**, e essa é a segunda metade da escolha. Os
argumentos de um evento agendado são serializados dentro da option `cron`, que é AUTOLOAD:
cada lead pendente passaria a carregar hashes, IP e user agent em toda requisição do site,
até o evento rodar. O argumento é só o `record_id`; o payload mora num transiente com prazo,
que não é autoload e some sozinho se o evento nunca rodar. O piso mede isso — ele procura o
hash e o IP dentro dos argumentos serializados e reprova se os encontrar.

**A NORMALIZAÇÃO É A DA META, E NÃO A DO GOOGLE.** O arquivo do cliente já traz a
normalização de e-mail das Enhanced Conversions, que remove pontos e sufixos para os
domínios que o Google nomeia. Aplicá-la aqui produziria um hash que a Meta não casa com
nada: a regra dela é espaço fora e minúsculas, e só. Para o telefone são dígitos com código
de país, sem símbolo e sem o `+` — e telefone SEM código de país não é enviado, porque
completar o país pelo idioma do site inventaria um número, que é a mesma decisão que o lado
do navegador já toma. IP e user agent vão em claro porque a Meta os pede assim e porque são
a chave de correspondência que sobra quando o navegador não colabora — que é o caso que
este módulo existe para cobrir. Nome e mensagem do lead **não entram** no payload, e não
entram porque a Meta não os pede.

**O que custa.** Três preços, e nenhum é pequeno.

O primeiro é a **versão da Graph API**. A Meta aposenta versões por calendário, e nenhuma
release nossa adivinha qual é a vigente no dia em que o site estiver no ar. A versão é
constante declarada com filtro ao lado — trocá-la não exige release —, e quando a atual
expirar a chamada passa a responder erro. O que o pacote garante é que o erro sai NOMEADO:
código HTTP, mensagem da Meta e `fbtrace_id` na atividade, e o módulo fecha degradado. Ele
não garante que alguém vá ler.

O segundo é a **dependência do agendador**. Com `DISABLE_WP_CRON` ligada e sem cron de
sistema, o evento fica agendado e não roda: o lead continua gravado e o que atrasa é a
metade de servidor da conversão. A dependência sai nomeada na tela do módulo, e é o erro
seguro dos dois possíveis — o outro seria segurar o worker.

O terceiro é o **transiente órfão**. Se o evento nunca rodar, o payload expira sozinho; se
rodar depois da expiração, o envio fecha "payload expirou" e a conversão daquele lead se
perde do lado do servidor. Perder a metade de servidor de um lead é melhor que enviar um
corpo vazio para a Meta, e a escolha está escrita no ramo.

**Como reverter.** Esvaziar `f3base_meta_capi_token` faz o envio voltar a não existir, sem
release nova: é o mesmo mecanismo do slot inerte, e o módulo passa a fechar inativo
nomeando a option. Remover o desenho é outra coisa: apagar o módulo reprova `leads.capi_meta`
em todos os ramos, e apagar a âncora de segredos reprova `estatica.segredo_fora_da_configuracao`
com a mensagem de que uma regra sem escopo nunca acusa nada.

---

## 68. Verificação de posse do domínio: duas options, e o que elas destravam

**Decidido.** Duas options novas no `site-core` — `f3base_verificacao_google` e
`f3base_verificacao_meta` —, vazias por padrão, cada uma emitindo a `<meta>` correspondente
no `<head>` quando preenchida. Vazias, nada é emitido, e a condição sai declarada em
`verificacao.dominio_declarada`. As chaves existem também no arquivo único
(`verificacao_dominio.google` e `verificacao_dominio.meta`) para que um site cujo operador
já tenha os tokens nasça verificado.

**Por quê.** A varredura é curta e conclusiva: ZERO ocorrências de `google-site-verification`
e de `facebook-domain-verification` no pacote inteiro. As duas não são enfeite. A
verificação do Search Console é o que dá à operação uma propriedade do domínio — sem ela não
há relatório de busca e não há a que ligar o GA4. A verificação de domínio da Meta é o que
decide **quem pode editar o link e a criativa** dos anúncios que apontam para este site;
sem ela, um domínio reivindicado por outra conta é um problema que se descobre tarde. As
duas eram passo humano no console **e** passo humano no HTML — e o segundo não precisava
ser, porque ele é exatamente o que uma option resolve.

**O DESENHO É O DOS SLOTS DE MEDIÇÃO, de propósito.** Vazio é inerte; preenchido emite; quem
grava é o agente, pelo canal. Um segundo mecanismo para o mesmo tipo de dado seria uma
segunda coisa para manter e uma segunda chance de divergir.

**VALOR FORA DA FORMA É PRESERVADO E AVISADO.** O token é opaco: o alfabeto é do fornecedor,
e ele pode mudá-lo sem avisar ninguém. O sanitizador desta option, ao contrário do de ID de
tag, **não reduz o alfabeto** — filtrar caractere aqui apagaria metade de um valor válido e
produziria uma verificação que nunca fecha, sem uma linha dizendo por quê. O que sai fora da
forma conhecida é preservado, emitido **escapado** no atributo, e nomeado num WARN com a
forma esperada. O engano mais comum é colar a tag inteira em vez do conteúdo dela, e é
exatamente ali que ele cai.

**O que custa.** Duas options a mais no catálogo, e um valor errado que o pacote não
recusa: a tag existe no HTML, o fornecedor não reconhece o token, e a verificação nunca
fecha. O aviso é a única defesa, e ele só aparece para quem abre a tela do site-core ou lê
o relatório da cadência. Recusar seria decidir por quem grava, e apagar em silêncio é o que
esta operação parou de fazer.

**Como reverter.** Esvaziar as duas options faz o site voltar a não emitir nada. Remover o
desenho reprova `verificacao.tag_do_valor_gravado` nos dois ramos — o do slot vazio e o do
valor preservado com aviso.

---

## 69. O conteúdo demonstrativo passa a ser medido no banco, e a flag deixa de decidir

**Decidido.** A marca `<prefixo>:conteudo-demonstrativo` passa a ser contada **no banco do
site**: quantas páginas PUBLICADAS ainda a carregam, e quais. A regra mora numa classe
compartilhada — `F3Base_Censo_Demonstrativo` —, roda na cadência do `site-core` e no
relatório do implantador, e é ela que decide o aviso: **zero páginas marcadas, zero WARN,
qualquer que seja `conteudo.demonstrativo`**. A checagem de build continua conferindo o
pacote.

**Por quê.** O defeito estava medido em `suite/checagens/conteudo.php` e é permanente. A
checagem lê `config.conteudo.demonstrativo` e os arquivos de `content/` do pacote. Sob a
premissa desta operação, o agente substitui o conteúdo **pelo canal** e nunca toca em
`content/` nem no arquivo único — não há por que tocar: o site já está no ar. A flag fica
`true` para sempre, e o WARN continua saindo depois de o template ter sumido inteiro do
site. Aviso que sai sempre é aviso que ninguém lê, e ele custa mais que o silêncio: ele
ensina o operador a ignorar a cor amarela.

**A MARCA JÁ VIAJAVA DENTRO DA PÁGINA, e foi isso que tornou a correção barata.** Desde a
1.0.15 o comentário que abre cada arquivo de `content/` entra inteiro em `post_content`. A
pergunta certa, portanto, tinha resposta no banco desde sempre; o que faltava era alguém
fazê-la. A consulta é direta — ocorrência literal em `post_content` — porque uma busca por
`WP_Query` passaria pelos filtros de busca do site e por relevância, e o que se quer é
ocorrência. Os tipos de post saem MEDIDOS de `get_post_types()`, e não de uma lista literal
com `page` e `post`: um tipo que o agente crie depois entraria fora da conta.

**AS DUAS PERGUNTAS SÃO DIFERENTES, e por isso as duas checagens ficam.**
`conteudo.demonstrativo` responde *"este pacote leva conteúdo de template?"* — é pergunta de
build, tem leitor (quem vai instalar) e continua fechando WARN neste pacote, que de fato
leva. `conteudo.demonstrativo_no_site` responde *"o template está no ar?"* — é pergunta de
runtime, e é a única que muda quando o agente trabalha.

**A CLASSE NÃO TEM PAI, pelo mesmo motivo de `F3Base_Emissores`:** ela roda em dois runtimes
que não se enxergam — no `site-core`, na cadência, e no implantador, que precisa dela mesmo
antes de o plugin persistente existir na instalação. Um arquivo alcançado por dois caminhos,
com guarda de `class_exists`; duas cópias divergiriam na primeira condição acrescentada.

**O que custa.** Uma consulta com `LIKE` sobre `post_content` a cada execução da cadência e
a cada relatório — ela não usa índice, e num site com muitos posts publicados ela varre. A
cadência roda no máximo algumas vezes por mês, e o preço é declarado aqui em vez de
escondido. O segundo custo é de escopo: a medição é do que está PUBLICADO, então um rascunho
do template não conta. É deliberado — o aviso é sobre o que está no ar com o endereço do
cliente —, e significa que um site inteiro em rascunho fecha silencioso.

**Como reverter.** Voltar a decidir pelo valor da flag. `conteudo.demonstrativo_no_site`
reprova nos dois casos que ela não distingue: uma página marcada ao lado de uma já
substituída — o aviso precisa nomear só a primeira — e nenhuma marcada com a flag ainda em
`true`, que é o estado permanente de todo site que o agente já trocou.

---

## 70. O modo somente-relatório compara com a base, e a configuração desce para a segunda linha

**Decidido.** O gravador ganha uma bandeira própria para o modo somente-relatório, separada
da simulação. Nele, cada option do bloco do `site-core` sai como **registro do que mudou
desde a última aplicação** — comparação com a BASE, nomeando o valor aplicado e o valor
observado — e a comparação com a configuração desce para uma **segunda linha, rotulada**:
*"difere da configuração original"*. A linha do relatório é
`options.mudanca_desde_a_aplicacao`, e ela fecha **OK** nos dois ramos.

**Por quê.** O defeito é de CATEGORIA, e não de código. Até a 1.1.1 o modo somente-relatório
atravessava o gravador em simulação e imprimia *"gravaria esta option (valor observado
difere do desejado)"*. O "desejado" é `config/site.json` — e depois que o agente assume o
site, esse arquivo é **certidão de nascimento, não estado corrente**: ele registra o que o
pacote aplicou no dia da entrega e nunca mais é reescrito, porque quem opera não edita o
zip. Cada edição legítima do agente virava, então, uma "divergência" permanente, num
relatório que roda na cadência para sempre. É o mesmo defeito da decisão 69 visto de outro
ângulo: um instrumento comparando o presente com uma fotografia e chamando a diferença de
erro.

**A SEGUNDA LINHA NÃO SAI, e é ela que impede esta decisão de virar cegueira.** Quem for
REEXECUTAR o implantador precisa saber o que a configuração pediria, porque é ela que a
reexecução aplica — a regra de três vias da decisão 58 vai olhar exatamente esse valor. O
que muda é o lugar e o rótulo: ela é informação para quem for agir, e não achado sobre o
site.

**A LINHA FECHA OK, E ISSO É DELIBERADO.** Mudança feita pelo agente não é achado adverso —
é o trabalho dele. WARN aqui treinaria o leitor a ignorar o relatório inteiro, que é
exatamente o que esta release está desfazendo em outros dois lugares.

**O que custa.** O modo somente-relatório deixa de responder, na primeira linha, à pergunta
"o que uma reexecução mudaria?". Quem quiser essa resposta usa o modo **simulação**, que
continua sendo o que sempre foi. São dois modos com respostas diferentes para a mesma
option, e a distinção depende de quem lê saber qual pergunta está fazendo — o que é uma
condição mais frágil que um número.

O segundo custo é de dependência: o registro só existe onde há BASE. Numa option sem base
a linha diz que não existe "desde a última aplicação" a medir, em vez de afirmar o resultado
de uma comparação que não aconteceu — mas quem apagar `f3base_base_merge` pelo canal perde
o registro inteiro até a aplicação seguinte.

**Como reverter.** Tirar a chamada de `F3Base_Imp_Gravador::relatorio()` do despacho dos
lotes: o modo volta a atravessar a simulação e a comparar com a configuração.
`relatorio.mudanca_desde_a_aplicacao` reprova nos dois pisos do roteiro — a edição do agente
que precisa sair como mudança e nunca acusada, e a option intocada com a configuração
mudada, que precisa aparecer SÓ na segunda linha.

---

## 71. `tracking.eventos_ga4` sai, e com ela a option que existia só para carregá-la

**Decidido.** `tracking.eventos_ga4` sai da configuração, do schema, do catálogo do
`site-core` e dos dois leitores. Com ela sai a option `f3base_tracking`, que não tinha outro
subcampo. A chave entra em `suite/chaves-removidas.tsv`, com os tokens `eventos_ga4` e
`eventosGa4`, e `estatica.sem_residuo_de_chave_removida` prova que não sobrou nada em
configuração, schema, código ou documento.

**Por quê.** Aplicado o teste da 1.0.19 — *o que muda se eu mudar isto?* — a resposta é:
nada que outra coisa já não decidisse. A chave era lida em dois lugares
(`class-f3base-modulo-leads-whatsapp.php` e `class-f3base-modulo-tracking.php`), viajava
para o navegador como `eventosGa4` e governava uma guarda que já tinha a resposta ao lado:

```
if (!dados.eventosGa4 || typeof window.gtag !== 'function') { return; }
```

Sem `f3base_ga4_measurement_id` gravado, nada carrega o `gtag.js` — e sem `gtag.js`,
`typeof window.gtag !== 'function'` já barra o disparo. Com o ID gravado, não há por que não
disparar: quem gravou o measurement ID pediu a medição. A chave só podia discordar do
próprio dado, e é o mesmo caso do `formularios[].ativo` da 1.0.19 — dois fatos sobre a mesma
coisa, e um deles sem consequência.

**A OPTION SAIU JUNTO, e essa é a metade que a decisão 56 nos ensinou.** `f3base_tracking`
era um grupo com exatamente um subcampo: o interruptor. Sem ele, ela seria uma option de
grupo sem nenhuma chave — gravada pelo implantador, presente no catálogo, lida por ninguém.
Option que ninguém lê é pior que option ausente: ela dá ao próximo leitor a impressão de que
alguma coisa está sendo conferida ali dentro.

**O que custa.** Some a capacidade de ter GA4 carregado e os eventos recomendados
desligados. Ela existia no papel e não tinha caso de uso declarado: quem não quer o evento
esvazia o measurement ID, e quem quer o `gtag.js` sem `generate_lead` está pedindo uma
combinação que este pacote nunca ofereceu de propósito — o clique do CTA é a conversão deste
site desde a decisão 55.

**Como reverter.** Tirar a linha de `suite/chaves-removidas.tsv` e devolver a chave à
configuração, ao schema, ao catálogo e aos dois leitores. Enquanto a linha estiver lá,
`estatica.sem_residuo_de_chave_removida` reprova o token em configuração, schema, código e
documento — e a narrativa declarada é este arquivo.

---

## 72. Duas correções fora do roteiro desta release, e por que elas foram feitas

**Decidido.** Duas coisas que não estavam na lista da 1.1.2 foram corrigidas, e ficam
registradas aqui porque decisão fora do roteiro é a que mais precisa de rastro.

**`client_ip_address` só sai quando é IP.** `F3Base_Modulo_Endpoint_Leads::origem()` devolve
a palavra `desconhecida` quando o servidor não informa `REMOTE_ADDR` — um valor legítimo
para o balde do rate limit, que só precisa de uma chave estável. Passado adiante sem guarda,
ele iria para a Meta no campo `client_ip_address`: lixo com cara de endereço, que casaria —
ou deixaria de casar — por um motivo que ninguém escreveu. O campo passou a exigir
`FILTER_VALIDATE_IP`, e o piso planta a palavra para provar que ela não sai.

**`sanitiza_segredo()` ganhou um irmão em vez de um segundo comportamento.** O nome já
existia, para o HMAC hexadecimal que este plugin gera: ele reduz ao alfabeto `[a-f0-9]`
porque conhece o que produziu. O token da Meta vem de fora e o alfabeto é do fornecedor;
reaproveitar aquela função teria apagado metade de todo token válido, em silêncio. O novo
`sanitiza_segredo_opaco()` só apara espaço e corta no teto declarado, e a diferença entre os
dois está escrita no bloco de cada um.

**O que custa.** O primeiro é uma guarda a mais num caminho que já era estreito. O segundo é
uma segunda função de sanitização de segredo, e duas funções com nomes parecidos são duas
chances de escolher a errada — o preço foi pago com a explicação em cada uma, que é o que
sobra quando a distinção não pode ser feita pelo tipo.

**Como reverter.** As duas são de poucas linhas. A primeira tem detector: `leads.capi_meta`
reprova se a palavra `desconhecida` voltar a sair como endereço. A segunda não tem, e está
escrita aqui por isso.

---

## 73. `hidden` não esconde nada quando o autor declarou `display`, e isso estava em dois lugares

**Decidido.** Toda regra de autor que declara `display` sobre uma classe cujo elemento tem
a visibilidade comandada por `hidden` passa a vir acompanhada do par
`.classe[hidden] { display: none }`. O detector é
`estatica.hidden_governa_visibilidade`, com fixture negativa e positiva em disco, e ele
varre o pacote inteiro — JavaScript e markup de um lado, todas as folhas do outro.

**Por quê.** O usuário viu na tela: *"O botão de Privacidade e Medição está abrindo uma
tela e os botões dentro dela não funcionam."* A hipótese que chegou junto com o relato foi
CONFIRMADA por medição própria, com uma correção de detalhe.

`fontes/tema/style.css` declarava `.f3base-consentimento-painel { position: fixed; inset: 0;
display: grid }`. O `hidden` do HTML é `display: none` da folha do **user agent**, e
qualquer `display` declarado pelo autor a vence — a **origem** decide antes de a
especificidade ser consultada, e por isso nem o cálculo de especificidade chega a
acontecer. Medido na bancada, com o CSS real: depois de `caixa.hidden = true`, o `display`
efetivo continuava `grid`. O botão "Fechar" não fechava.

**A correção de detalhe, e ela é do relato, não da causa.** O painel **não nascia visível
na carga**: `construirPainel()` só era chamado de dentro de `abrir()`, e `abrir()` punha
`hidden = false` na linha seguinte. Medido: logo depois de `iniciar()`, `document.body`
tinha **zero** filhos. A tela que o usuário viu era a do primeiro clique — o painel abria
de verdade —, e o que estava quebrado era só o FECHO. A causa única continua valendo para
os dois sintomas do relato; o que não valia era a frase "nasce visível cobrindo a tela".

Os outros dois botões tinham um defeito próprio e **independente do CSS**: `definir()`
gravava o cookie, atualizava o Consent Mode, sincronizava o texto de estado e chamava
`fecharAviso()` — que remove o aviso de primeira visita, que é OUTRO elemento — e não
tocava no painel. Aceitar e recusar funcionavam por dentro e pareciam inertes.

O terceiro achado do relato também se confirmou: `.f3base-consentimento-caixa` existia na
folha e nenhum elemento a carregava. A varredura é conclusiva — a classe aparecia em
`style.css` e em `CONTRASTE.md`, e em lugar nenhum do JavaScript.

**E HAVIA UM SEGUNDO PAR, que só a varredura acharia.** A suspeita de quem relatou — *"este
não pode ser o único par `hidden` + `display` de classe"* — estava certa.
`includes/assets/implantador.css:63` declarava `.f3base-imp-encerramento { display: block }`,
e `includes/assets/implantador.js:204` faz `encerramento.hidden = true` na construção,
inserindo o nó na árvore antes de o primeiro lote rodar. Efeito na tela do operador: a caixa
branca com borda azul do resumo final ficava aberta e **vazia**, do primeiro lote ao último,
em toda execução desde a 1.0.16. Ninguém a reportou — ela não impede nada, só mente sobre
onde a execução está.

**O PAR ACEITO É POR CLASSE, e o global sem `!important` é recusado.** `.classe[hidden]`
tem especificidade 0,2,0 contra 0,1,0 da regra da classe: vence sem `!important`, e é o par
que este pacote usa. Um `[hidden]` global COM `!important` também é aceito, porque alcança
inclusive o que ainda não foi escrito. O que não é aceito é um `[hidden]` global SEM
`!important`: ele empata em especificidade com a regra da classe e perde na ordem sempre
que a classe vier depois — e regra cuja correção depende da ordem de escrita dentro do
arquivo não é regra. A fixture negativa planta exatamente esse caso.

**O que custa.** Duas coisas. A primeira é que o detector lê CSS com expressão regular: ele
não resolve `@media` aninhado nem `:is()`, e vai errar para o lado de ACUSAR se alguém
escrever um seletor que ele não decompõe — o que é o erro seguro dos dois possíveis. A
segunda é de escopo: ele só enxerga classe comandada por `hidden` quando o JavaScript põe a
classe pelo `className` no mesmo arquivo, que é como todo cliente deste pacote monta os nós
que cria. Um nó que recebesse a classe por outro caminho — `classList.add` a partir de uma
variável, por exemplo — passaria despercebido, e isso está escrito aqui.

**Como reverter.** Tirar as duas regras `[hidden]` das folhas.
`estatica.hidden_governa_visibilidade` reprova nomeando a classe, o arquivo que a comanda e
o seletor que declara o `display`; e `js.banner_de_consentimento` reprova por
comportamento, porque a bancada dele decide visibilidade pelo CSS de verdade.

---

## 74. O controle de consentimento é um link de rodapé, e o que ele abre é uma faixa na base

**Decidido.** O controle vira **link de texto sem destaque**, com o rótulo **"Política de
Cookie"**, na mesma linha e com o mesmo tratamento dos outros links do rodapé. O que ele
abre é um **banner fixo na base do viewport**, com a altura do conteúdo, que não cobre a
página. Os três botões funcionam: aceitar e recusar gravam **e fecham**, fechar fecha
**sem decidir**. O piso é `js.banner_de_consentimento`, e ele mede comportamento.

**ELE CONTINUA SENDO UM `<button>`, e a justificativa é a que foi pedida.** Três razões, na
ordem em que pesam:

1. O controle **executa uma ação na própria página** — ele não navega. Essa é a definição
   de `<button>` e não a de `<a>`.
2. Um `<a>` sem `href` **não é focável pelo teclado e não é anunciado** como controle: é a
   armadilha clássica, e é a mesma que a decisão 53 já paga de propósito no outro lado
   (lá, tirar o `href` é o remédio menos destrutivo para não apontar para rascunho). Um
   `<a href="#">` seria pior: inventa um destino, muda a URL e quebra o botão de voltar.
3. `role="button"` num `<a>` obrigaria a reimplementar a ativação por Espaço em
   JavaScript. O `<button>` responde a Enter e a Espaço sem uma linha.

O que muda é só a APARÊNCIA, e ela é do tema: saem a borda, o fundo, o padding e o alvo de
44px; a cor passa a sair de `--wp--style--color--link`, que é a custom property que o
núcleo emite quando `elements.link.color.text` está declarado no bloco — a mesma que o
`<a>` vizinho consome. O `:hover` precisou ser escrito porque o estilo de elemento
`:hover` do theme.json só alcança `a`.

**`aria-haspopup` REFLETE O QUE ELE ABRE**, e o que ele abre continua sendo um
`role="dialog"` com `aria-modal="false"` — a semântica de não-modal foi mantida. O que
entrou foi `aria-expanded`, alternado pelo cliente, e `aria-controls` apontando para o `id`
do banner.

**E É POR ISSO QUE O BANNER É CONSTRUÍDO NA CARGA, FECHADO.** Até a 1.1.2 ele nascia no
primeiro clique; um `aria-controls` apontando para um `id` que só passa a existir depois é
referência pendurada, e o leitor de tela anuncia um controle de alguma coisa que não
existe. A construção antecipada tem um segundo efeito, e ele é o que torna a regra 73
mensurável: com o CSS da 1.1.2, um banner construído na carga fica **literalmente visível
na carga** — e é exatamente assim que o piso reproduz o defeito de hoje.

**A ROLAGEM E O FOCO.** Ao abrir, o cliente mede a altura da faixa e a escreve em
`--f3base-banner-altura`, na raiz, com a unidade — a regra 13 do contrato vale aqui, e
`0px` é o valor de repouso. O corpo ganha esse respiro embaixo enquanto o banner estiver
aberto, e o devolve ao fechar: sem isso a faixa fixa tampa o fim do documento, inclusive o
rodapé e o próprio controle que a abriu. O foco vai para o banner ao abrir e **volta para
o controle** ao fechar; o banner **não prende o foco**, e a única tecla que ele captura é
`Esc`.

**FECHAR NÃO DECIDE, e isso é uma decisão.** Gravar `denied` ao fechar transformaria o
gesto de dispensar a faixa em consentimento — e gravar `granted` seria pior. Fechar é sair
sem decidir, e a política pré-aprovada continua sendo o que decide na ausência.

**O que custa.** Três preços. O primeiro é de contraste: o botão pintado de link herda a
cor do link do bloco, e o `:hover` foi escrito no `style.css` referenciando o preset que o
theme.json usa no rodapé. São dois lugares dizendo a mesma coisa sobre a cor de hover, e
eles podem divergir — o preço de o núcleo não deixar um `<button>` participar do estilo de
elemento `link`. O segundo é de alvo de toque: o controle deixa de ter os 44px mínimos e
passa a ter a altura de uma linha de texto, como o link vizinho — é o que "mesmo
tratamento dos outros links do rodapé" significa, e está escrito aqui porque é uma perda
real em tela pequena. O terceiro é que a reserva de espaço depende de `offsetHeight`: num
navegador que devolva zero antes da pintura, o respiro nasce em `0px` e o rodapé fica
coberto até a próxima abertura.

**Como reverter.** Voltar o rótulo, as regras de destaque e o `inset: 0`.
`js.banner_de_consentimento` reprova em dez tetos e três pisos — entre eles o banner que
nasce aberto, o "Fechar" que não fecha, o aceitar que grava sem fechar e o foco que não
volta.

---

## 75. O site nasce instrumentado para comportamento, e não só para conversão

**Decidido.** O carregador de tracking passa a instalar **seis coletores de
comportamento**, todos pelo MESMO portão de consentimento das quatro tags e emitidos nos
DOIS formatos que a 1.1.0 estabeleceu: marcos de rolagem, seção vista, clique em link
externo, fricção, erro de JavaScript do próprio site e Core Web Vitals de campo. Nome,
parâmetro, teto por página e limiar moram num arquivo só —
`fontes/site-core/dados/eventos-comportamento.tsv`. Pisos em
`js.comportamento_instrumentado` e `tracking.eventos_de_comportamento_declarados`.

**Por quê.** A premissa nova, nas palavras de quem a definiu: *"o site no WordPress já deve
nascer instrumentado para validar e avaliar o comportamento dos usuários no site."* A
varredura do que existia é curta: `generate_lead`, `form_start` e `select_content` — tudo
em torno da conversão. Nada dizia se a página era lida, onde o visitante parava, o que ele
tentava clicar nem qual era a experiência real de carregamento. Um site que só mede
conversão só sabe responder sobre quem converteu, e quem não converteu é a maioria.

**A DECLARAÇÃO É ÚNICA, E O CLIENTE NÃO ESCREVE NOME NENHUM.** O gatilho é a chave de
junção — `rolagem`, `interseccao`, `clique-externo`, `clique-repetido`, `erro`,
`desempenho` —, e o coletor entrega os valores POSICIONALMENTE: o servidor os casa com a
coluna `parametros`, na ordem em que ela está escrita. Isso torna o nome do evento
renomeável num lugar só, sem tocar em uma linha de JavaScript, e
`tracking.eventos_de_comportamento_declarados` reprova qualquer literal de nome declarado
dentro do JavaScript do pacote — foi ele que reprovou a primeira versão desta implementação,
que escrevia os seis nomes no cliente. O motivo é quem lê: um agente comparando períodos.
Para ele, nome que muda entre releases não é erro visível — é o relatório do mês seguinte
vazio, sem ninguém saber se o site parou de medir ou se os visitantes pararam de rolar.

**OS LIMIARES E OS TETOS, com o motivo de cada um.**

| Evento | Teto | Limiar | Por que este número |
|---|---|---|---|
| rolagem | 4 | 25/50/75/90 | O teto é igual à quantidade de marcos DE PROPÓSITO: um quinto evento de rolagem na mesma página só pode ser rajada, porque não há um quinto marco. 90 e não 100 porque o fim absoluto quase ninguém alcança em página com rodapé alto |
| seção vista | 12 | 50% visível | Meia seção porque uma faixa que aparece de raspão na borda não foi vista por ninguém. Teto de 12 porque o template mais longo desta base tem 5 seções nomeadas, e o dobro já é folga; acima disso é página montada por laço, e ali a leitura útil acabou |
| link externo | 10 | — | A décima saída já respondeu a pergunta que o evento faz |
| fricção | 3 | 4 cliques · 1200 ms · 24 px · alvo interativo | Ver abaixo |
| erro do site | 3 | origem = site | Contados por `arquivo:linha` DISTINTOS. Erro em laço de render dispara milhares de vezes e são sempre o mesmo defeito |
| web vital | 4 | LCP, CLS, INP, TTFB · 16 ms | Um por métrica, no primeiro ocultamento da página |

Teto somado: **36 disparos por página**, e ele existe porque sem teto uma única página faz
o volume de um dia — e aí a conta de medição amostra ou descarta o excesso em silêncio, sem
dizer o que perdeu. O descarte passa a ser NOSSO e declarado.

**O LIMIAR DA FRICÇÃO, e a prova de que uso normal não dispara.** Quatro cliques, e não
dois nem três: **duplo clique é gesto normal de sistema** e **triplo clique é o gesto
normal de selecionar um parágrafo**. Um limiar em 2 ou em 3 marcaria como frustração o uso
comum de qualquer página de texto — o falso positivo mais barato de cometer e o mais caro
de descobrir, porque ele chega ao relatório com cara de dado. A janela de 1200 ms fica
acima da janela de múltiplo clique dos navegadores (na casa dos 500 ms) e abaixo do
reclique deliberado, que é nova tentativa e não raiva. O raio de 24 px existe porque o
mesmo ponto precisa ser o mesmo ponto: sem ele, percorrer uma lista de links acumularia
cliques de lugares diferentes. E o alvo tem de ser um CONTROLE, porque o gesto de seleção
de texto pousa em texto.

O piso prova os cinco casos normais que **não** disparam — duplo clique, triplo clique,
cliques espalhados além do raio, cliques em controles diferentes e cliques repetidos num
parágrafo — e o caso que dispara.

**A RECUSA DECLARADA: o "dead click" não é implementado.** O outro sinal de fricção —
clique em elemento não interativo — foi examinado e recusado com motivo. Numa página de
texto, todo triplo clique para selecionar um parágrafo, todo duplo clique acidental num
título e todo toque para fechar o teclado no celular pousam em elemento não interativo.
Separar isso de frustração exigiria um modelo de intenção que este pacote não tem, e um
falso positivo ali polui exatamente o relatório que a medição existe para produzir. Sinal
que não se sabe medir sem falso positivo é recusa declarada, nunca implementação torta.

**A ORIGEM DO ERRO É O PORTÃO, E NÃO UM PARÂMETRO.** Só o que classifica como `site` vira
evento; `terceiro` e `ambiente` não saem. É por isso que um bloqueador de anúncio não
enche o relatório: ele quebra o script do fornecedor, não o nosso. Um parâmetro de origem
seria peso morto — ele só poderia dizer `site` —, e chave que nunca pode discordar do
próprio dado é a mesma doença que a decisão 71 tirou do módulo de tracking.
`unhandledrejection` **não é ouvido**, também com motivo: promessa rejeitada não carrega
arquivo nem linha em navegador nenhum, então a origem dela não é decidível — e evento cuja
origem não é decidível é exatamente o que enche o relatório.

**NENHUM EVENTO CARREGA DADO PESSOAL, e cada recusa tem um lugar onde ela pode falhar.**
Do link externo sai o **host** e nada mais: caminho e query são onde mora o identificador
— `/perfil/joao-silva` no caminho, `?email=` ou `?token=` na query, e um `utm_content` que
a campanha de outra pessoa preencheu com o id do lead. Do erro sai o caminho sem query e
sem fragmento, e **a mensagem não sai**: ela carrega o valor interpolado que produziu o
erro, e esse valor pode ser o que o titular digitou. A segunda defesa é estrutural: os
parâmetros são casados com a declaração, e um valor a mais do que ela prevê é descartado
antes do `dataLayer` — a porta é a lista, não a boa intenção de quem escreve o coletor. O
piso varre o payload inteiro, como o da CAPI faz.

**A SEÇÃO É NOMEADA PELO MARKUP, E SEM NOME NÃO É MEDIDA.** O tema carimba
`f3base-secao-<nome>` como `className` nos cinco patterns — e como `className`, nunca como
atributo cru: um `data-` avulso no `<div>` de um `core/group` quebraria a validação do
bloco no editor. Derivar o nome de um título produziria uma série histórica que muda
sozinha na primeira revisão de copy, com uma seção nova e uma seção que sumiu sem que nada
tivesse mudado na página.

**CORE WEB VITALS SEM BIBLIOTECA, E O VALOR SAI CRU.** `PerformanceObserver` nativo para
LCP, CLS e INP, e `PerformanceNavigationTiming` para o TTFB: a política de origem declarada
não admite CDN de terceiro e o peso do carregamento é pago pelo visitante. Os quatro são
relatados uma vez, no primeiro ocultamento da página — que é quando LCP, CLS e INP têm
valor final. **A classificação de bom/precisa-melhorar/ruim foi recusada**: os cortes são
do fornecedor e mudam por calendário, e embuti-los aqui faria o relatório deste site
discordar do console do fornecedor no dia em que eles se movessem, sem uma linha dizendo
por quê. Quem classifica no destino tem o corte vigente, que nós não temos.

**`desempenho.core_web_vitals` CONTINUA BLOCKED, e essa é a metade que a release não fecha
por otimismo.** Coleta existir não é o mesmo que o dado ter chegado. Core Web Vitals de
campo são a distribuição sobre visitas REAIS: antes de haver visitante não há valor, nem
distribuição, nem estabilidade. Fechar OK porque o coletor existe seria trocar "o
instrumento está instalado" por "a medida foi tomada" — o tipo exato de afirmação que esta
suíte existe para não fazer. O que a linha ganhou foi PRECISÃO na pré-condição: até a
1.1.2 faltavam a coleta **e** o tráfego; agora falta só o tráfego, e o BLOCKED diz qual dos
dois.

**O que custa.** Quatro preços, e nenhum é pequeno.

O primeiro é de **volume**: 36 eventos a mais por página, no teto, contra os três que o
pacote emitia. Numa conta gratuita do GA4 isso conta para o limite de eventos, e quem
operar um site de tráfego alto vai querer baixar os tetos — que é uma edição de uma coluna
do TSV, sem release.

O segundo é a **ordem dos parâmetros virar contrato**. Como o cliente os entrega
posicionalmente, trocar a ordem de dois parâmetros na declaração troca o significado dos
dois no relatório, em silêncio. É o preço de o cliente não escrever nome nenhum, e está
declarado nos dois arquivos.

O terceiro é o **custo de execução no navegador do visitante**: um ouvinte de rolagem
(passivo), um `IntersectionObserver`, dois ouvintes de clique em captura, um ouvinte de
erro e três `PerformanceObserver`. Nenhum deles é caro sozinho; todos juntos são trabalho
que a página não fazia, e ele é pago por quem visita.

O quarto é de **manutenção da plataforma**: `interactionId`, `hadRecentInput` e
`durationThreshold` são superfície de especificação em evolução. Uma mudança de navegador
pode degradar uma métrica sem erro nenhum — o coletor continua rodando e o número passa a
significar outra coisa. A mitigação é que o valor sai cru: quem compara com o console do
fornecedor vê a divergência.

**Como reverter.** Esvaziar `f3base_ga4_measurement_id` e o container faz toda a
instrumentação voltar a não existir, sem release — é o mesmo slot vazio → inerte das tags.
Baixar um teto ou tirar uma linha do TSV desliga um coletor, também sem release. Remover o
desenho é outra coisa: apagar a declaração reprova
`tracking.eventos_de_comportamento_declarados` na primeira asserção, e apagar os coletores
reprova `js.comportamento_instrumentado` em todos os tetos.

---

## 76. Três correções fora do roteiro desta release, e por que elas foram feitas

**Decidido.** Três coisas que não estavam na lista da 1.1.3 foram corrigidas, e ficam
registradas aqui porque decisão fora do roteiro é a que mais precisa de rastro.

**A caixa do resumo final do implantador deixou de nascer aberta.** Ela é o segundo par
`hidden` + `display` de classe que a varredura da decisão 73 encontrou, e não estava no
roteiro porque ninguém a tinha visto: `.f3base-imp-encerramento { display: block }` com
`encerramento.hidden = true` na construção deixava uma caixa branca com borda azul, vazia,
na tela do operador durante a execução inteira, desde a 1.0.16. O par `[hidden]` foi
acrescentado no mesmo arquivo.

**`.f3base-consentimento-caixa` deixou de ser regra órfã.** Havia dois remédios — apagar a
regra ou criar o elemento — e o escolhido foi criar: a faixa ocupa a largura do viewport e
o conteúdo não pode, então uma caixa interna que limite a medida e centralize é o que o
banner precisa de qualquer forma. A regra que existia sem dono passou a ter dono.

**O caminho `nenhum` passou a ser inerte também dentro do cliente.** Até esta release
`carregar()` só conferia consentimento; com nenhum slot preenchido o servidor não
enfileirava o arquivo, e a guarda era desnecessária. Ela deixou de ser: a instrumentação de
comportamento **não depende de ID nenhum para funcionar**, então um dia em que o arquivo
chegasse à página por outro caminho — cache, concatenador, um plugin que enfileira assets
de terceiro — o site passaria a emitir comportamento sem ter conta de medição para
recebê-lo. Quem achou isso foi o próprio piso: `js.comportamento_instrumentado` reprovou a
implementação com oito eventos emitidos no caminho `nenhum`, antes de a guarda existir.

**O que custa.** O primeiro é uma linha de CSS. O segundo é um `<div>` a mais no DOM de
toda página. O terceiro é uma condição a mais num caminho que já era estreito — e a
redundância é a mesma que `permiteTags()` já pratica, pelo mesmo motivo.

**Como reverter.** As três têm detector: `estatica.hidden_governa_visibilidade` reprova a
primeira, e `js.banner_de_consentimento` e `js.comportamento_instrumentado` reprovam a
segunda e a terceira.

---

## 77. Todo campo operável diz o que MUDA no site, e o exemplo nunca é um valor que funciona

**Decidido.** Toda folha operável do catálogo do `site-core` passa a declarar duas chaves
obrigatórias além do rótulo: **`impacto`** — o que muda no site quando o campo é preenchido, e
o que acontece enquanto ele está vazio — e **`exemplo`** — um valor ilustrativo e
obviamente ilustrativo. O detector `estatica.campo_operavel_tem_impacto_e_exemplo` cobra as
duas, com o catálogo como âncora, e cobra mais duas recusas: **segredo não tem exemplo de
valor** (nenhuma corrida de 16 ou mais caracteres alfanuméricos no exemplo de uma option
declarada em `segredos_do_site()`) e **identificador de fornecedor sai na FORMA que o próprio
pacote declara** em `F3Base_Modulo_Tracking::formas()` — `G-XXXXXXXXXX`, `GTM-XXXXXXX`,
`AW-000000000`, `somente dígitos`.

**Por quê.** O pedido, nas palavras de quem o fez: *"para cada campo, apresente uma
explicação do impacto de preencher aquele campo, assim como um exemplo de preenchimento."*
A varredura do que existia é curta e conclusiva: toda option tinha `rotulo`, **algumas**
tinham `descricao`, e **nenhuma** tinha impacto ou exemplo. Rótulo é o nome da coisa;
descrição é a definição dela. *"Número de WhatsApp em E.164"* é definição — e ela não diz o
que quem está com o cursor no campo precisa saber: que **enquanto aquele campo estiver
vazio o botão de contato não é publicado em página nenhuma**. A pessoa que abre a tela não
quer saber o que o campo é; quer saber o que acontece se ela preencher.

**AS DUAS RECUSAS DO EXEMPLO, e por que elas são medidas e não recomendadas.** Copiar um ID
de medição real para dentro do pacote manda os dados do cliente para a conta de outra
pessoa — em todo site que instalar este pacote, de uma vez. E um exemplo que **funciona
colado sem pensar** é a mesma coisa com mais passos: alguém copia, grava, a tag carrega, o
console do fornecedor fica mudo e ninguém sabe por quê. A forma com dígitos genéricos é a
que o próprio fornecedor usa na documentação dele — ela ensina o formato e não pode ser
usada. Para o token da Conversions API não existe forma segura: o campo passa a trazer
**onde obtê-lo** e o aviso de que ele nunca viaja no arquivo de configuração, e a marca na
tela deixa de dizer "Exemplo" e passa a dizer "Onde obter".

**O QUE A EXIGÊNCIA DE IMPACTO ENCONTROU: um campo sem impacto nenhum.**
`f3base_contato.email_leads` estava no formulário desde a 1.0.0, e a varredura de
consumidores em runtime é conclusiva — **nenhum módulo deste plugin lê essa subchave**. O
destino do regime por e-mail mora dentro da entrada de formulário desde a decisão 62. O
impacto honesto daquele campo seria "preencher não muda nada", e um campo assim não é campo:
é armadilha na tela de quem opera. Ele **saiu do formulário** e **continua no padrão e no
sanitizador**, para que o valor que o agente gravar ali pelo canal continue sendo preservado
como qualquer chave desconhecida.

**O que custa.** Três coisas. A primeira é **volume de texto**: o catálogo cresceu, e cada
campo novo passa a exigir duas frases escritas — o detector reprova o campo que nascer sem
elas, e isso é de propósito. A segunda é que **as frases envelhecem**: um impacto escrito
hoje descreve o comportamento de hoje, e nada mede se ele continua verdadeiro amanhã — o
detector cobra a EXISTÊNCIA da frase, não a verdade dela. A terceira é que a forma
ilustrativa vira contrato: mudar `formas()` sem mudar o exemplo reprova a rodada.

**Como reverter.** Apagar `impacto` e `exemplo` de uma folha reprova
`estatica.campo_operavel_tem_impacto_e_exemplo` no primeiro ramo, nomeando o campo, e
`tela.campo_diz_impacto_e_exemplo` no DOM. Devolver `email_leads` ao formulário é
acrescentar a entrada em `subcampos` — e aí ela passa a precisar de um impacto que hoje não
existe.

---

## 78. A tela é agrupada por assunto, escrita para quem opera, e o diagnóstico desce

**Decidido.** A tela do `F3 Base Site Core` passa a ter **quatro blocos de preenchimento**
— Contato, Medição e anúncios, Consentimento, Privacidade e retenção — seguidos de **dois
blocos de leitura**: o resumo de comportamento e o estado das partes do plugin. A ordem é
declarada num lugar só (`F3Base_Options::secoes_da_tela()` mais
`F3Base_Admin_Tela::ordem_dos_blocos()`) e é MEDIDA no DOM por
`tela.campo_diz_impacto_e_exemplo`. O vocabulário interno do projeto — "operável",
"estrutural", "registro único", "leitura de volta", "gate" — sai da superfície da tela; os
conceitos continuam valendo por dentro, e o nome técnico de cada option aparece como
referência secundária, para quem opera pelo canal.

**Por quê.** O texto que abria a tela até a 1.1.3 era este: *"Esta tela renderiza o registro
único de módulos — a mesma fonte que registra os hooks e monta o relatório da implantação. O
que é operável se edita aqui; o que é estrutural aparece com estado e motivo."* Ele é
verdadeiro e é escrito para quem construiu o pacote. Quem abre a tela quer resolver uma
coisa — ligar o WhatsApp, conectar a conta de anúncio, decidir um prazo — e encontrava
primeiro um relatório de estado interno, com os campos apresentados na ordem em que alguém
os escreveu no catálogo. **A ordem dos blocos é a ordem em que alguém instala um site**, e
por isso ela é declaração, não acaso.

**O DIAGNÓSTICO NÃO ENCOLHEU.** Módulos, estados, motivos, avisos, dependências, hooks,
options que controlam cada parte e as options sem módulo: tudo continua, e
`tela.campo_diz_impacto_e_exemplo` mede que continua. Ele é o que o suporte e o agente leem,
e é o que responde "por que isto não está acontecendo no site". O que mudou é a posição:
primeiro o que se preenche, depois o que se observa.

**O EXEMPLO NUNCA ENTRA NO CAMPO, e o piso é o `placeholder`.** Exemplo em `placeholder` é
valor fantasma: ele some quando o operador digita, reaparece quando ele apaga, e é lido como
conteúdo do campo por leitor de tela e por quem tem pressa. É a forma mais barata de fazer
alguém sair da tela convencido de que gravou o que não gravou. A bancada reprova
**qualquer** `placeholder=` no HTML da tela, e reprova qualquer exemplo que apareça dentro de
um `value` do formulário.

**O que custa.** A tela ficou **mais longa**: quatro blocos com cabeçalho e resumo, e duas a
três linhas de texto por campo. Quem já sabe o que quer preencher passa a rolar mais. A
compensação declarada é que o campo fica ao lado do assunto dele, e não a doze linhas de
distância de outro assunto. O segundo preço é que **a ordem virou contrato**: acrescentar
uma option operável exige declarar a seção dela, e o detector estático reprova quem não
declarar.

**Como reverter.** Trocar a ordem em `secoes_da_tela()` muda a tela e a asserção junto —
elas leem a mesma função. Voltar ao formato de lista única é apagar os blocos, e aí
`tela.campo_diz_impacto_e_exemplo` reprova na asserção da ordem, nomeando o observado e o
declarado.

---

## 79. O site passa a guardar o próprio resumo de comportamento, e vira um destino

**Decidido.** O `site-core` ganha o módulo `comportamento`: ao **sair** de cada página, o
navegador manda **uma vez**, por `sendBeacon`, os **totais agregados** daquela visita, e o
servidor os soma numa **tabela própria** — `<prefixo>f3base_comportamento`, uma linha por
dia, caminho, evento e detalhe, com contagem e soma. A leitura é dupla: um quadro na tela do
plugin e a mesma tabela por rota de banco do canal, sem depender de credencial de fornecedor
nenhum. A retenção é declarada em `f3base_comportamento.retencao_dias` e executada pela
rotina de retenção que já existia.

**Por quê.** A pergunta, nas palavras de quem a fez: *"O site nasce instrumentado, onde
posso ver os dados desta instrumentação."* A medição da resposta, antes de respondê-la:
`grep` dos seis nomes de evento de comportamento dentro do plugin devolve **zero** — eles
saem do navegador direto para a conta de medição —, e `f3base_atividade` guarda só o que
passa pelo servidor. Com `f3base_ga4_measurement_id` vazio, os eventos **não eram emitidos**:
não existiam em lugar nenhum. A 1.1.2 nomeou essa lacuna como "opção não tomada"; esta
release a toma.

**O PRÓPRIO SITE VIROU UM DESTINO, e é essa a mudança de fundo.** A guarda da 1.1.3 dizia:
sem slot de medição preenchido, nada é instalado e nada é emitido — porque emitir
comportamento sem uma conta para recebê-lo é emitir para lugar nenhum. Com a tabela
existindo, "lugar nenhum" deixou de ser verdade. O portão do enfileiramento passou de "há
ID?" para **"há destino?"** (`F3Base_Modulo_Tracking::ha_destino()`), e a guarda antiga
continua inteira dentro dele: **sem os dois destinos, nada é instalado e nada é emitido**, e
`tracking.caminho_unico` mede exatamente isso, agora com a condição escrita. A recusa que
NÃO se moveu: com o slot vazio, `emitir()` **não** empurra nada no `dataLayer` — alimentar um
container que ninguém carregou seria mandar dados para uma conta que este pacote nunca soube
que existia.

**AS QUATRO RECUSAS DO PAYLOAD, cada uma com onde ela pode falhar.**

1. **Nenhum identificador de visitante.** Não há id de sessão, não há cookie e nada é
   gravado no armazenamento do navegador: a sessão vive na memória da aba e existe só para
   não enviar duas vezes. O piso varre `localStorage`, `sessionStorage` e `document.cookie`.
2. **Nenhuma URL com query.** O que viaja é `location.pathname`. A URL da bancada tem
   `utm_content` e um e-mail dentro de propósito — é ali que a campanha de outra pessoa cola
   o identificador do lead.
3. **Nenhum texto livre.** O detalhe passa por um **alfabeto fechado** sem barra, arroba,
   dois-pontos nem espaço: host de destino, nome de seção, marco de rolagem e nome de
   métrica passam; caminho de arquivo, endereço e mensagem não têm como passar. É por isso
   que o **erro de JavaScript entra como contagem e sem o arquivo** — a página já é a chave, e
   o arquivo interpolado é onde mora o valor que o titular digitou.
4. **Nenhum evento sem declaração.** O cliente manda o **gatilho**; quem resolve o nome é o
   servidor, contra `dados/eventos-comportamento.tsv`. É a mesma regra da 1.1.3, e ela é o
   que permite renomear um evento num lugar só sem quebrar a série histórica.

**O PORTÃO É O MESMO DO CONSENTIMENTO, e a tela declara o que isso significa.** Sem
consentimento o navegador não envia; o servidor não tem como conferir o consentimento de
quem não mandou nada. Por isso o quadro diz, ao lado dos números, que eles contam **só as
sessões em que o consentimento permitiu medição** — quem lê um total sem essa frase acha que
está vendo o universo.

**A TABELA, E NÃO UMA OPTION.** Contador diário cresce todo dia; uma option com o resumo
dentro cresceria sem teto e, sendo autoload, seria lida em **toda** requisição do site. A
migração é por `dbDelta`, e a prontidão é medida **pelas colunas** — o padrão que a 1.0.18
estabeleceu —, porque tabela antiga responde ao `SHOW TABLES` e faz o `INSERT` desta versão
falhar em silêncio. Sem a tabela pronta, a rota responde **503 nomeando a perda** e o módulo
fecha degradado: a perda é declarada, nunca silenciosa.

**O DESVIO DO ROTEIRO, declarado com a medição.** O roteiro pedia que, com
`ga4_measurement_id` vazio, a tela dissesse que "os eventos não estão sendo emitidos para
lugar nenhum". Depois desta release isso deixou de ser verdade: eles passam a ser somados na
tabela do próprio site. A tela diz então a frase exata: **nenhum evento chega ao Google
Analytics, a análise completa não existe em lugar nenhum, e o quadro abaixo é tudo o que
há** — seguida do campo que precisa ser preenchido para mudar isso. Escrever a frase pedida
ao pé da letra seria imprimir na tela uma afirmação que a própria release tornou falsa.

**O que custa.** Cinco preços, e nenhum é pequeno.

O primeiro é **escrita no banco em toda visita**: uma requisição REST por sessão e até
trinta e seis linhas de `INSERT … ON DUPLICATE KEY UPDATE`. Em site de tráfego alto isso é
carga nova, e quem não a quiser desliga a chave — sem release.

O segundo é **crescimento de tabela**: dia × caminho × evento × detalhe. Um site com muitas
páginas e muitos domínios de saída gera muitas linhas, e é por isso que a retenção é
declarada e tem teto de 730 dias no sanitizador.

O terceiro é a **sessão que se perde**. O envio é um só, no primeiro ocultamento da página:
quem troca de aba no meio da leitura e volta tem o resto da visita não contado. E onde não
há `sendBeacon` a sessão inteira se perde — a alternativa seria uma requisição disputando a
saída do visitante com a navegação dele, e um agregado perdido é mais barato que uma saída
travada. As duas perdas são declaradas aqui e medidas no piso.

O quarto é que **os números do quadro e os do Google Analytics não vão bater**. Contam
universos diferentes — este conta sessões com consentimento que chegaram ao fim do
`visibilitychange`; o fornecedor conta o que a conta dele recebeu, com amostragem própria.
A tela diz que este resumo não substitui o relatório do fornecedor, e é por isso que ela diz.

O quinto é **superfície nova de escrita pública**: mais uma rota que aceita POST sem
autenticação. Ela paga o mesmo pedágio do endpoint de leads — schema fechado com recusa
nomeada, teto de tamanho, token efêmero assinado e o MESMO balde atômico —, e a reutilização
é deliberada: uma segunda implementação de limite de taxa seria a segunda a ficar para trás.

**Como reverter.** Desligar `f3base_comportamento.ligado` faz o navegador parar de enviar, a
rota recusar com 409 nomeado e o quadro dizer o que ligar — sem release, e sem tocar no envio
para a conta de medição. Desinstalar o plugin remove a tabela. Remover o desenho é outra
coisa: apagar o módulo reprova `comportamento.resumo_agregado` e `tela.resumo_de_comportamento`,
e apagar o envio do cliente reprova `js.resumo_da_sessao` em todos os tetos.

---

## 80. Duas correções fora do roteiro desta release, e por que elas foram feitas

**Decidido.** Duas coisas que não estavam na lista da 1.1.4 foram corrigidas, e ficam
registradas aqui porque decisão fora do roteiro é a que mais precisa de rastro.

**`uninstall.php` passou a remover as DUAS tabelas do plugin.** Ele removia apenas
`f3base_leads_dedup`. A tabela do resumo é estado produzido pelo plugin como a outra, e
desinstalar sem removê-la deixaria uma tabela órfã crescendo no banco de um site que já não
tem o plugin. O laço substituiu o literal único, que é o que faz a terceira tabela — se
houver — não ser esquecida por omissão.

**Os rótulos de estado da tela deixaram de ser o vocabulário do registro.** "ativo",
"degradado" e "inativo" são os estados internos do módulo e continuam sendo eles por dentro;
na superfície da tela viraram "funcionando", "funcionando com ressalva" e "parado". O
critério é o mesmo do resto da 1.1.4: onde o termo técnico não é a informação, quem lê a tela
não deveria precisar traduzi-lo. Os estados fechados do relatório da suíte **não** mudaram —
eles têm outro leitor, e `estatica.estados_fechados` continua valendo sobre eles.

**O que custa.** O primeiro é um laço no lugar de uma linha. O segundo é que a tela e o
relatório passam a usar palavras diferentes para o mesmo estado, e quem lê os dois lado a
lado precisa saber disso — está escrito aqui, e o `id` do módulo continua aparecendo ao lado
do rótulo na tela, que é o que amarra os dois.

**Como reverter.** As duas têm detector: `comportamento.resumo_agregado` mede a tabela pelo
nome que o módulo declara, e `tela.campo_diz_impacto_e_exemplo` mede o diagnóstico completo
no DOM.

---

## 81. A estratégia de carga do consentimento é decidida pela política, e não é fixa

**Decidido.** `F3Base_Modulo_Consentimento::estrategia_de_carga()` passa a decidir como o
script de consentimento é enfileirado, e quem decide é `consentimento.padrao`:
**pré-aprovado → `defer`**, fora do caminho crítico; **negado por padrão → BLOQUEANTE no
`<head>`**. Nos dois modos o script continua no cabeçalho — é a posição no documento que o
põe antes do carregador de tags do rodapé. **Não há chave de configuração para isso**: a
condição decide, como no resto do pacote. Pisos em
`consentimento.estrategia_pela_politica` e em `js.ordem_do_consentimento`.

**Por quê.** A justificativa que estava escrita no docblock era legítima e **incompleta**:
*"Precisa ser bloqueante e vir antes de qualquer tag: o `default` do Consent Mode só vale
se chegar antes do gtag.js."* O `gtag.js` **não é carregado pelo WordPress**. Quem o
injeta é `f3base-tracking.js`, que é `'strategy' => 'defer'` no rodapé
(`class-f3base-modulo-tracking.php`) e declara dependência do handle do consentimento. E
`defer` executa **depois do parse e na ordem do documento** — então o consentimento no
`<head>` continuaria rodando antes do carregador no rodapé sem bloquear o parser.

A hipótese foi **medida, não deduzida**, e o veredito tem duas metades.

**Confirmada para os dois scripts DESTE pacote.** `js.ordem_do_consentimento` roda os dois
clientes reais contra um escalonador que é o modelo da especificação e lê uma linha do
tempo. Com o consentimento **bloqueante**:

```
execucao:f3base-consentimento > consent-default > execucao:f3base-tracking > script-externo:f3base-gtag
```

Com o consentimento **adiado**, a linha do tempo é **idêntica**, caractere a caractere — e
é essa igualdade que a bancada afirma. O `default` continua chegando antes do `gtag.js`.
**Não há visita inicial rastreada sem consentimento no caminho padrão**, e o bloqueio não
estava comprando ordem nenhuma: estava comprando 5.085 bytes gzip no caminho crítico.

**Insuficiente contra quem não é nosso, e é isso que salva o outro modo.** `defer` ordena
`defer`; ele **não ordena `async`**. Um `gtag.js` de um plugin de console — a classe que
`plugins.emissor_concorrente` e `tracking.emissor_unico` já medem desde a 1.1.1 — ou um
snippet colado no cabeçalho executa antes de qualquer `defer` da página. Medido, no modo
opt-in com o consentimento adiado:

```
execucao:emissor-concorrente > script-externo:emissor-concorrente > page_view > execucao:f3base-consentimento > consent-default
```

O `page_view` sai vendo `ausente` — e ausência de `default` é, para o fornecedor, o mesmo
que `granted`. Com o consentimento bloqueante, o mesmo cenário mede
`consent-default` (denied) **antes** do `page_view`.

**A AUTORIZAÇÃO DO USUÁRIO, E POR QUE ELA NÃO SE APLICA NO MODO OPT-IN.** A autorização,
nas palavras de quem a deu: *"Estamos aceitando que quando o usuário entra no site, ele por
padrão está com a utilização dos cookies permitida. Podemos considerar que é aceitável que
o bloqueio dos cookies seja ativado somente após a página carregada, mesmo que isso acabe
rastreando uma visita inicial."* Ela descreve **o cenário de pré-aprovação** — e, medido,
naquele cenário **o custo autorizado não existe**: o `default` que chega é `granted`, que é
materialmente o que o gtag faz sem Consent Mode nenhum. Chegar tarde com `granted` não muda
o que foi enviado, e a bancada afirma as duas metades disso (o emissor concorrente chega
antes, E o default que chegaria é `granted`).

No modo de **negativa por padrão** a mesma permissividade custaria o primeiro `page_view`
com consentimento pleno de quem ainda não consentiu. Ela **não foi autorizada ali** —
foi autorizada descrevendo o outro regime —, e por isso não é aplicada ali.

**O GANHO MEDIDO, e o que continua no caminho crítico.** No modo padrão saem **5.085 bytes
gzip** (14.256 crus): o arquivo inteiro de `f3base-consentimento.js`, que era o **único**
script bloqueante do pacote. Continuam lá, nomeados: `fontes/tema/style.css`, **6.720
bytes gzip** (20.716 crus), que bloqueia a renderização como toda folha de estilo; e o
bloco de dados que `wp_localize_script` imprime antes do script, **831 bytes** de JSON
(450 gzip), inline no cabeçalho — atribuição de variável, sem ida à rede.
`f3base-leads.js` (7.769 gzip) e `f3base-tracking.js` (11.715 gzip) já estavam fora, no
rodapé e com `defer`.

**O PISO MEDE ORDEM DE EXECUÇÃO, NÃO A STRING DO ATRIBUTO**, e essa distinção é a metade
técnica desta decisão. Conferir `'strategy' => 'defer'` no enfileiramento responde outra
pergunta — a que interessa é se o `consent default` chegou ao `dataLayer` antes de o
`gtag.js` ser pedido. A bancada roda os arquivos e lê a linha do tempo; a única coisa ali
que não sai de um arquivo do pacote é o escalonador, e ele é o modelo da especificação, com
as três regras escritas no topo dele. Os pisos: **inverter a decisão** — `defer` no modo
opt-in — tem de aparecer como o primeiro `page_view` saindo antes do `denied`, nomeando
isso; e o carregador rodando antes do consentimento tem de aparecer como `gtag.js` pedido
sem `default` nenhum, com `permiteTags()` caindo na decisão de reserva do servidor. Do lado
do servidor, `consentimento.estrategia_pela_politica` tem o piso do **valor fixo** (as duas
políticas não podem devolver a mesma estratégia) e o do **interruptor** (mudar rodapé,
aviso e prazo não pode mexer nela).

**O que custa.** Três preços. O primeiro é que **o modo opt-in continua pagando os 5 KB**,
e agora paga por um motivo escrito no lugar onde a decisão acontece — o que é melhor que
pagar por um motivo que descrevia outro carregador, mas continua sendo o mesmo pagamento.

O segundo é que **a garantia do modo padrão passou a depender da especificação e do
WordPress**. `defer` preservar a ordem do documento é regra da plataforma; e o WordPress só
mantém `defer` num script cujos dependentes também sejam adiáveis — hoje o único dependente
é `f3base-tracking`, que é `defer`. Um plugin que pendure um script bloqueante sobre o
handle do consentimento faz o núcleo rebaixá-lo para bloqueante, o que é o erro seguro dos
dois; um plugin que enfileire um `gtag.js` próprio continua fora de qualquer ordem que este
pacote possa impor, e é por isso que `tracking.emissor_unico` existe.

O terceiro é de **cache de página**. Numa instalação opt-in com cache de HTML, uma página
gerada para quem tinha aceitado pode ser servida a quem não decidiu nada. O script continua
bloqueante ali justamente por isso: ele roda antes de qualquer coisa e o
`permiteTags()` do carregador encontra o objeto do consentimento já definido, em vez de cair
na decisão de reserva do servidor — que é o piso 2 desta checagem.

**Como reverter.** Devolver o literal ao enfileiramento — `array( 'in_footer' => false )` e
nada mais. `consentimento.estrategia_pela_politica` reprova em cinco asserções, entre elas
o teto do caminho crítico, que nomeia `f3base-consentimento` como o script que voltou a
bloquear o cabeçalho no modo padrão. Fazer o contrário — `defer` nos dois modos — reprova
em outras cinco, e o piso do opt-in nomeia o primeiro `page_view` saindo antes do `denied`.

---

## 82. A negativa tardia passa a alcançar Pixel e Insight Tag, e o que ela não desfaz fica escrito

**Decidido.** Os dois disparos de terceiro de `f3base-leads.js` — `fbq('track','Lead')` e
`lintrk('track')` — passam pelo mesmo `permiteTags()` que o carregador de tags usa, com a
mesma decisão de reserva (objeto ausente → o servidor já decidiu, e ele vale). O
`generate_lead` no `dataLayer` e a conversão do Google **continuam saindo**. A assimetria
passa a estar escrita em dois lugares que a pessoa lê: o **impacto** de
`f3base_consentimento.padrao` na tela e a **política de privacidade** do template. Piso em
`js.conversao_multicanal`.

**Por quê.** O roteiro desta release pedia para NOMEAR o que a negativa tardia não desfaz,
com a frase *"o que a negativa faz é impedir os envios seguintes"*. A medição do que o
código fazia contradiz a frase, e é por isso que o código mudou em vez de o texto: a
condição dos dois disparos era `typeof window.fbq === 'function'` e
`typeof window.lintrk === 'function'` — **a presença da função**, que continua verdadeira
depois da recusa, porque negar não descarrega script nenhum. Sob a política pré-aprovada
isso significa que quem chegasse, fosse medido, abrisse o controle do rodapé e recusasse
**continuava mandando `Lead` à Meta e `track` ao LinkedIn a cada clique no CTA**. A bancada
mediu 1 e 1 sobre o código da 1.1.4, e é esse o piso que ficou escrito nela.

Escrever na política de privacidade que os envios seguintes são impedidos, com o código
fazendo o contrário, seria exatamente o defeito que a decisão 44 existe para impedir —
afirmação de documento refutada pelo código dentro do mesmo zip.

**O QUE FICA DE PÉ, E É DO FORNECEDOR.** Três coisas foram medidas e continuam verdadeiras,
e a política as descreve como mecanismo, nunca como promessa jurídica:

- **GA4 e Google Ads têm `consent update`.** A negativa vale do clique em diante; o que já
  foi enviado **permanece com o Google**. É o que o Consent Mode faz, e está correto.
- **Pixel e Insight Tag não têm equivalente.** Se o arquivo já carregou, ele **fica na
  página** até a navegação seguinte. Nada — nem este pacote nem ninguém — descarrega
  arquivo já carregado.
- **Na navegação seguinte eles não voltam.** `permite_tags()` no servidor decide o
  enfileiramento, e com a decisão gravada em `denied` o carregador não vai ao HTML.

**POR QUE O `generate_lead` CONTINUA SAINDO.** Calar o `dataLayer` na negativa seria decidir
duas vezes a mesma coisa, e a segunda vez sem mecanismo: quem decide o que o Google faz com
o evento depois do `denied` é o Consent Mode, que já recebeu o `update`. E o registro do
lead **no próprio site** também continua: recusar medição não é recusar o contato, e o
`consentimento: false` viaja no registro como sempre viajou.

**O que custa.** Dois preços. O primeiro é que a conversão de campanha **deixa de ser
contada** para quem recusou depois de ter sido medido — o que é o comportamento correto e
é, ainda assim, uma perda de dado que alguém vai notar no relatório do fornecedor sem
saber de onde veio; está escrito aqui e no impacto do campo. O segundo é que `permiteTags()`
passou a existir em **dois arquivos de cliente**, com a mesma semântica escrita duas vezes.
A alternativa era o de leads chamar o do tracking, e ela é pior: o arquivo de leads é
enfileirado sem depender do de tracking — o CTA existe em site sem medição nenhuma —, e
uma chamada cruzada criaria uma dependência que o enfileiramento não declara.

**Como reverter.** Tirar o `if (!permiteTags())` de `converter()`.
`js.conversao_multicanal` reprova no piso da negativa tardia, dizendo quantos envios
saíram para cada um dos dois canais depois da recusa.

---

## 83. Três decisões fora do roteiro desta release, e por que elas foram tomadas

**Decidido.** Três coisas que não estavam na lista da 1.1.5, registradas aqui porque
decisão fora do roteiro é a que mais precisa de rastro.

**A versão do tema subiu junto, sem o tema ter mudado.** Esta release não toca em nenhum
arquivo do tema. `release.tema` é comparado com o cabeçalho `Version:` de
`fontes/tema/style.css` em `conferir_versoes_declaradas()`, e o carimbo dos documentos
imprime os três números lado a lado: deixar o tema em `1.1.4` com a identidade em `1.1.5`
produziria duas respostas para "qual release é esta?" na mesma linha da tabela. Nesta base
os três números são o mesmo número, desde o contrato; a alternativa seria numeração
independente por componente, que é uma mudança de identidade e não cabe numa release
pequena.

**A bancada do `site-core` ganhou `get_privacy_policy_url()`.** Ela passou a rodar o
`enfileirar()` REAL do módulo de consentimento — é assim que
`consentimento.estrategia_pela_politica` lê os argumentos que decidem o HTML —, e aquele
método publica o endereço da política junto dos textos do banner. Sem o stub a sonda morria
com erro fatal em vez de medir. É uma função do núcleo a mais na plataforma de mentira, e o
valor dela sai de `$GLOBALS['f3b_bench']`, como o resto.

**A descrição de `js.ordem_do_consentimento` no runner não escreve tag de script.**
`estatica.detector_codigo_em_string` reprovou a primeira redação, que trazia a tag literal
dentro de uma string PHP — e a reprovação está certa: é exatamente o padrão que ele existe
para achar. A frase passou a dizer "cada tag de script externo inserida". Fica registrado
porque o detector acusou uma prosa, não um defeito, e a próxima pessoa que escrever uma
descrição vai encontrar o mesmo limite.

**O que custa.** O primeiro carimba uma versão nova num artefato idêntico ao anterior:
quem comparar os dois zips do tema vai achar só o número. O segundo é superfície nova na
bancada. O terceiro é uma restrição de redação que não está escrita em lugar nenhum além
desta linha.

**Como reverter.** As três são de uma linha. A primeira reprova
`estatica.carimbo_de_release_nos_documentos` se o número divergir do config; a segunda
reprova a sonda inteira com erro fatal, que a suíte reporta como veredito não analisável; a
terceira reprova `estatica.detector_codigo_em_string`, com o arquivo e a linha.

---

## 84. Fase é aplicabilidade, não pendência — e a fase que nunca rodou é achado

**Decidido.** Duas metades, e uma sem a outra é defeito.

**Primeira metade — a regra.** Checagem com **fase declarada**, rodando **fora da fase
dela**, fecha **N/A nomeando a fase em que ela É medida**. **BLOCKED fica reservado para
pré-condição ausente na fase certa.** A regra é uma função pura em
`F3Base_Imp_Fases::aplicabilidade()`, e a fase da suíte deixou de ser deduzida em cada
ponto: ela é a constante `F3Base_Suite::FASE_CORRENTE`, hoje `build`.

**Segunda metade — o contrapeso, e ele é obrigatório.** `fases.registro_de_execucao`
declara, por fase fechada, **quantas checagens a esperam**, **quais são** e **quando
aquela fase rodou pela última vez**. Fase declarada que **NUNCA** rodou fecha **WARN**,
com as fases nomeadas. O registro **dura entre execuções**: `suite/fases.json` do lado da
suíte, option `f3base_fases` do lado do host. Nenhum sétimo estado foi criado — os seis do
contrato continuam seis, e a correção é justamente que dois deles parem de ser confundidos.

**Por quê.** O relato foi: *"alguns status estão como BLOCKED e WARN. Porém, o
comportamento é o esperado."* Os dois exemplos citados foram medidos e **os dois fecham OK
no runtime** — `plugins.autoupdate_conforme_politica` devolve `OK` em
`class-f3base-imp-plugins.php`, e o texto do mapa vazio de
`class-f3base-imp-entrega.php` sai dentro da linha `mcp`, que também fecha OK. O que
estava sendo lido era o **relatório da suíte**, e ali estava o defeito real, que é maior
que os dois exemplos: **BLOCKED estava dizendo duas coisas que o leitor não consegue
separar.**

- *"A pergunta se aplica aqui e falta alguém fazer alguma coisa"* —
  `formulario.destino_privado` com o número de WhatsApp vazio: há ação pendente, e ela é
  do operador.
- *"Esta fase não produz este tipo de evidência, por desenho"* —
  `visual.inspecao_paginas` na rodada de build: não falta ação nenhuma; falta um
  **navegador**, que o build nunca vai ter, e a medição acontece noutro lugar sempre.

Medido na 1.1.5: `suite/checagens/bloqueadas.php` declara **36 entradas** — 30 em
`f3b_bloqueadas()` e 6 em `f3b_nao_aplicaveis()` —, distribuídas em produção 17 · local 11
· build 7 · campo 1. Na rodada, **27 fechavam BLOCKED**, e **26 delas eram do segundo
tipo**. Vinte e seis linhas amarelas numa rodada impecável ensinam o operador a ignorar
amarelo — que é exatamente o defeito que a 1.0.15 fechou para o WARN informativo, e que a
decisão 69 voltou a fechar para o aviso que sai sempre. Aqui ele estava um nível acima:
não no aviso, e sim no estado.

A contagem por estado, antes e depois, sobre o mesmo pacote: **OK 141 → 142; FALHA 0 → 0;
BLOCKED 27 → 1; N/A 7 → 33; WAIVED 0 → 0; WARN 1 → 2; TOTAL 176 → 178.**

**O ÚNICO BLOCKED QUE SOBRA É `entrega.rodada_limpa`, E ELE TINHA DE SOBRAR.** Ele é da
fase `build` — a fase desta rodada —, então a regra não o alcança, e não deveria: a rodada
PRODUZ o registro que o host consome, e aprovar-se pelo arquivo que ela mesma acabou de
escrever não seria medir nada. Os outros seis de fase `build` são as condicionais não
instanciadas, que já fechavam N/A pela condição declarada e continuam fechando.

**A REGRA SOZINHA ESCONDE DEFEITO, e é por isso que ela não foi instalada sozinha.** Se
`visual.inspecao_paginas` for N/A para sempre porque ninguém nunca roda a fase de
navegador, o silêncio vira aprovação por omissão — e *"checagem que nunca falhou não é
evidência"* é regra da casa desde a 1.0.5. O piso da segunda metade planta exatamente o
modo pelo qual ela se apagaria: **bastaria BLOCKED ou N/A contarem como "a fase rodou"**
para que a fase nunca executada sumisse do relatório no mesmo instante em que a regra
nova passasse a valer. Só OK, FALHA e WARN contam como medição; BLOCKED diz que a medição
não pôde acontecer, N/A que ela não se aplicava, e WAIVED é FALHA assinada.

**O QUE MUDA NO HOST: a mesma regra, e ela dá respostas OPOSTAS.** A fase que uma execução
no host exercita passou a ser declarada — `F3Base_Imp_Lotes::FASE_DA_EXECUCAO`, hoje
`producao` —, e as **duas únicas emissões incondicionais de BLOCKED do runtime** passaram a
ter o estado decidido por `aplicabilidade()` em vez de escrito à mão:

- `orcamento.medicao_de_pagina` é fase **`campo`** — peso, requisições e nós de DOM sobre
  tráfego REAL. Fora da fase corrente: **N/A**. Um BLOCKED que nenhuma execução podia
  fechar ensinava o operador a ignorar a cor, e não havia pendência de ninguém ali no
  momento da implantação.
- `mcp.autoteste_recusa_credencial` era fase **`producao`** — a fase corrente — e por isso
  continuava BLOCKED em toda execução. **Corrigido na 1.1.7:** a fase declarada estava
  errada. Quem produz aquela evidência é o REQUISITANTE EXTERNO, com uma requisição HTTP
  de fora e credencial sem a capacidade exigida; nenhuma execução do implantador no host a
  produz. A fase passou a ser **`campo`**, e a linha fecha **N/A** nomeando a fase, como
  `orcamento.medicao_de_pagina`. O que ficou de BLOCKED na fase certa é
  `cadencia.mecanismo_declarado`, e só no caso em que não há agendamento observado nem
  chave declarada — aí falta gatilho de verdade, e falta a alguém.

Duas linhas, a MESMA função, respostas opostas — é isso que prova que quem decide é a
regra. E o escopo é estreito de propósito: a constante governa as declarações de evidência
que este host não produz e **não** reescreve a fase declarada das demais linhas. As de
`producao` continuam medindo de verdade, e **nada do que hoje mede no site deixou de
medir**.

**N/A NÃO É PENDÊNCIA DE FASE, e este era o defeito que a regra criaria.** Os **três**
lugares que consultam `gates_de_fase()` escreviam `OK !== $estado` — `pode_autodesativar()`
em `class-f3base-imp-entrega.php`, a etapa de entrega e `veredito_da_unidade()` em
`class-f3base-imp-lotes.php`. Com o N/A aparecendo nessas linhas, os três passariam a
imprimir **"pendência de fase (N/A)"**: a mesma confusão entre aplicabilidade e pendência
que esta release existe para eliminar, um andar abaixo. A comparação saiu dos três e virou
`F3Base_Imp_Fases::gate_de_fase_em_aberto()`, com dois estados que RESOLVEM o gate por
motivos opostos — **OK** (respondeu) e **N/A** (não se aplica aqui) — e todos os outros
deixando-o aberto: BLOCKED, FALHA, WARN, WAIVED e estado ausente. Três comparações são três
chances de a próxima condição ser acrescentada em duas delas.

Para que o terceiro consumidor pudesse ter piso, o laço da etapa de entrega — que só roda
com WordPress — virou a função pura `F3Base_Imp_Lotes::nota_de_pendencias_de_fase()`. Regra
que não pode ser exercitada é regra que ninguém sabe se está certa.

**O PISO AO CONTRÁRIO É O QUE IMPEDE A CORREÇÃO DE VIRAR CEGUEIRA.** Com uma linha em N/A
**ao lado** de uma em BLOCKED, a nota não pode dizer "nenhuma pendência de fase em aberto",
e a BLOCKED tem de sair NOMEADA com o estado. Essa contradição foi medida na 1.0.17 — a
mesma linha do log dizia "Nenhuma pendência de fase em aberto" e "Pendência(s) de FASE
dentro desta unidade — 1" — e a 1.1.6 podia reabri-la pelo outro lado. Medido nos quatro
mutantes: devolver `OK !== $estado` a qualquer um dos três consumidores produz de 2 a 5
achados nomeando o N/A contado como pendente, e fazer BLOCKED resolver o gate produz 6,
entre eles *"existe uma linha de fase em BLOCKED e a nota disse que nenhum gate de fase
está em aberto"*.

- O host também ganhou o **contrapeso**: `fases.registro_de_execucao` sai no encerramento,
  com um gate que não promove a unidade, lendo e regravando a option `f3base_fases`. Ele
  declarava `gate => 'fase'`; **desde a 1.7.3 declara `relato`**, pela decisão 108 — a
  evidência dele é o registro durável deste host, e chamá-la de pendência de fase dizia
  que faltava rodar alguma coisa noutro lugar.

**ONDE O REGISTRO MORA, e por que não é dentro do selo.** `suite/rodada.json` é **apagado**
quando a rodada tem FALHA — registro de limpeza que sobrevive a uma reprovação é afirmação
sem medição por trás. O registro de fases é o oposto: ele não afirma aprovação, afirma
EXECUÇÃO, e apagá-lo perderia o único fato que a rodada de build não tem como reproduzir
sozinha — que a fase de navegador rodou um dia. Por isso ele é arquivo próprio, gravado
SEMPRE, inclusive na rodada reprovada, com produtor único conferido por
`estatica.gate_fonte_unica`, que passou a cobrar os **dois** registros pela mesma regra.

**E ELE NÃO É INJETADO NO BUNDLE NEM EXCLUÍDO DO HASH.** O selo precisa das duas coisas
porque o HOST o consome; um segundo arquivo fora da soma tiraria mais um caminho da
cobertura de integridade para resolver um problema que este registro não tem — quem o lê é
a PRÓXIMA rodada, na mesma árvore, e o host tem o registro dele próprio. E ficar DENTRO da
soma é o que importa aqui: um registro de fases forjado é pior que a ausência dele, porque
ele afirma que a fase de navegador rodou.

**A PRECISÃO DO CARIMBO É O DIA, e ela é consequência direta disso.** Medido: com precisão
de segundo, duas rodadas seguidas sobre uma árvore IDÊNTICA produziam hashes de pacote
diferentes — `d9d0480f…` e `0f3f0e16…` —, porque o registro entra na soma e o relógio anda.
Um operador comparando dois digests legítimos concluiria adulteração, que é exatamente o
mal-entendido que o MANIFESTO existe para evitar. Com o carimbo alinhado à meia-noite UTC,
a árvore reverificada no mesmo dia dá o MESMO hash (medido: `4607a393…` em duas rodadas
seguidas), e não se perde nada que esta pergunta precise — "quando aquela fase rodou pela
última vez" é pergunta de calendário. A regra da precisão é `F3Base_Imp_Fases::dia()`, e
ela vale nos DOIS emissores: responder a mesma pergunta com granularidades diferentes daria
duas respostas para um fato só.

**O que custa.** Cinco preços, e nenhum é pequeno.

O primeiro é o mais sério: **N/A é um estado que não puxa veredito nenhum**. Vinte e seis
linhas saíram de um estado que aparece no resumo com nome e foram para um que, na ordem de
severidade da decisão 24, pesa zero. Se a fase correspondente nunca rodar, essa evidência
simplesmente não existe — e a ÚNICA coisa que impede isso de virar aprovação silenciosa é
`fases.registro_de_execucao`. Apagar aquela linha desfaz metade desta decisão e deixa a
outra metade valendo, que é o pior dos três estados possíveis.

O segundo é o **aviso que fica**. Nesta base, três fases — `local`, `producao` e `campo` —
nunca rodaram, então o WARN sai em toda rodada. Ele é adverso de verdade e é acionável (a
saída é rodar a fase), mas é amarelo permanente enquanto ninguém rodar nada, e amarelo
permanente é justamente o que a decisão 69 combateu. A diferença declarada: aquele aviso
saía por desenho e não tinha saída; este some no dia em que cada fase rodar uma vez.

O terceiro é uma **estrutura de estado nova em cada runtime**, com a fragilidade de sempre:
apagar `suite/fases.json` ou a option `f3base_fases` faz toda fase voltar a "nunca
executada". É o lado seguro — o registro nasce cobrando —, e ainda assim é memória que
alguém pode perder sem saber.

O quarto é de **acoplamento entre a suíte e o runtime**: a suíte passou a depender de um
subprocesso PHP que carrega `includes/class-f3base-imp-fases.php`. Subprocesso que não roda
não absolve ninguém — a linha continua BLOCKED com o erro nomeado —, mas é um caminho a
mais que pode falhar.

O quinto é que a **cópia de `suite/fases.json` que viaja no bundle é a da rodada anterior**,
porque ele não é injetado. A fase corrente é sempre recalculada ao vivo e só as outras são
lidas do arquivo, então o relatório não erra; quem abrir o JSON dentro do zip é que vê um
carimbo velho.

E há um sexto, que é o preço da precisão de dia: **o hash do pacote muda uma vez por dia
mesmo sem ninguém tocar em nada**, porque o registro carimba o dia em que a rodada
aconteceu. Dentro do mesmo dia ele é estável; de um dia para o outro ele muda, e a
explicação passou a morar no próprio JSON, no campo `precisao`.

**Como reverter.** Trocar o retorno de `F3Base_Imp_Fases::aplicabilidade()` para BLOCKED
nos dois ramos devolve as 26 linhas ao estado anterior — e `fases.regra_de_aplicabilidade`
reprova em três tetos, nomeando a fase de cada uma. Tirar o contrapeso é a reversão
perigosa e por isso ela tem piso próprio: fazer BLOCKED ou N/A contarem como medição
reprova em dois pisos que dizem, com todas as letras, que é assim que a regra apagaria o
próprio contrapeso; e apagar o arquivo durável faz a fase que já rodou voltar a aparecer
como nunca executada, o que a bancada mede no teto da durabilidade.

---

## 85. Duas correções fora do roteiro desta release, e por que elas foram feitas

**Decidido.** Duas coisas que não estavam na lista da 1.1.6 foram corrigidas, e ficam
registradas aqui porque decisão fora do roteiro é a que mais precisa de rastro.

**O nome que está nas duas tabelas passou a sair uma vez nos DOIS sentidos.** O comentário
de `f3b_nao_aplicaveis()` já dizia que o nome presente nas duas tabelas sai uma vez só, e
isso só valia num sentido: com a condição declarada VERDADEIRA, o laço de `f3b_bloqueadas()`
pulava e o outro emitia o N/A. Com ela FALSA, os dois emitiam. Medido nesta release, com
`contato.whatsapp_e164` preenchida numa cópia do pacote: `formulario.destino_privado` saiu
DUAS vezes na mesma rodada — uma com a fase `producao` que ela declara e outra em BLOCKED
com fase `local`, que é a fase escrita no ramo genérico do segundo laço. Duas linhas com o
mesmo rótulo e fases diferentes é a divergência de fonte que este pacote persegue em todo
lugar; quem tem entrada própria em `f3b_bloqueadas()` já falou por si, e o segundo laço
passou a pular.

**O bundle da identidade anterior em `dist/`.** `dist/implantador-base-1.1.5.zip` continuava
ao lado do bundle novo, pelo mesmo motivo e com o mesmo preço da decisão 65: dois bundles no
mesmo diretório são dois candidatos a upload, e o antigo carrega a configuração e os
documentos de uma identidade que já não existe. Ele saiu.

**O que custa.** A primeira é uma condição a mais num laço que já era estreito, e ela cria
uma dependência de ORDEM entre os dois laços — o de `f3b_bloqueadas()` precisa rodar antes.
A segunda apaga um artefato que alguém poderia querer para comparação, e a resposta é a
mesma da decisão 65: artefato de release anterior mora no repositório de artefatos, não na
saída de build da árvore de trabalho.

**Como reverter.** A primeira é um `if` de três linhas em `suite/lib/executar.php`; ela não
tem detector próprio e está escrita aqui por isso. A segunda é o conteúdo de um diretório
gerado, que o comando único regrava a cada rodada.

## 86. A matriz de releases homologadas sai da configuração e vira catálogo do pacote

**Decidido.** `release.anterior_suportada` deixou de existir em `config/site.json`. A
matriz de origens homologadas passou a morar em `config/releases-suportadas.tsv`, que é
CATÁLOGO do pacote, lido por um produtor único.

**Por que ela não podia ficar.** A regra 29 do contrato exige que uma chave de
configuração passe nas duas metades: existe projeto legítimo em que o valor certo é
diferente, E o valor é impossível de derivar do site, do exemplo ou do ambiente. Esta
falha na primeira, e falha do jeito mais claro possível. A matriz responde "de qual
versão instalada este implantador sabe subir?" — uma pergunta sobre o PACOTE, sobre a
história de homologação DESTA base. Não existe projeto em que a resposta certa seja
outra, e um operador que a editasse não estaria configurando: estaria afirmando ter
homologado um caminho que ninguém percorreu. Configuração que só pode ter uma resposta
certa não é ponto de extensão, é um comentário com preço de configuração — o mesmo
diagnóstico de `copy_contrato.fonte` na decisão da 1.0.19.

**O preço que ela cobrava.** Sozinha, a matriz ocupava 78 das 364 folhas de
`config/site.json` — mais do que qualquer bloco de conteúdo, mais do que tudo que o
operador realmente decide. O arquivo que alguém abre para escrever o nome do site tinha
a matriz de upgrade do pacote dentro, e ela crescia a cada release. O custo não era o
espaço: era que o arquivo deixava de parecer um formulário e passava a parecer um
banco de dados, e um formulário que assusta é preenchido errado.

**O que ficou no lugar.** Um TSV de três colunas — `componente`, `versao`,
`determinacao` — com o motivo de cada coluna escrito no cabeçalho do próprio arquivo, e
um leitor só: `F3Base_Imp_Preflight::releases_suportadas()`, que delega para a regra pura
`releases_suportadas_de( string $arquivo )`. O caminho chega por parâmetro de propósito:
é o que permite exercitar a leitura sem um pacote instalado, e é o que impede a regra de
só ser conhecida pelo arquivo que ela lê hoje. Comentário, linha em branco e linha sem a
coluna de determinação não viram entrada — origem sem o que a sustenta é homologação
afirmada e não feita.

**O que custa.** Um formato a mais para o pacote conhecer, e um arquivo que a suíte
precisa contar no carimbo dos documentos gerados — `suite/lib/documentos.php` passou a
contar o TSV em vez do array da configuração. E cria um caminho de falha novo: catálogo
ausente ou ilegível. A resposta é o lado seguro — lista VAZIA, em que só a instalação
limpa passa, nunca uma origem fabricada.

**Como o piso pega.** `release.matriz_do_catalogo` mede o catálogo do próprio pacote
inteiro e uma bancada com as quatro formas de o arquivo mentir. A bancada carrega o
comentário COM as três colunas e a linha em branco COM as tabulações de propósito: é a
única forma de a guarda do `#` e a guarda do vazio terem piso próprio. Com um comentário
sem tabulação, quem o descarta é a contagem de colunas, e derrubar a guarda do `#` não
mudaria resultado nenhum — o piso passaria a aprovar por acidente, que é pior do que piso
nenhum, porque continua verde. O catálogo real tem exatamente esse caso: o cabeçalho de
colunas escrito como comentário, que sem a guarda vira uma origem de componente
`# componente`.

**Como reverter.** O catálogo volta a ser um bloco de `config/site.json`, a linha da
chave sai de `suite/chaves-removidas.tsv`, e `releases_suportadas()` volta a ler a
configuração. `release.matriz_do_catalogo` perde o objeto que mede e sai com ela.

## 87. As decisões do pacote saem da configuração e ganham catálogo com motivo escrito

**Decidido.** Cinquenta e cinco folhas de `config/site.json` deixaram de ser configuração
e viraram quarenta e três linhas de `config/decisoes.tsv`, lidas por um produtor único,
`F3Base_Imp_Decisoes`. Com elas saíram dois blocos inteiros — `atribuicao` e
`orcamento_pagina` —, porque bloco esvaziado é seção que não pergunta nada e continua
ocupando espaço no arquivo que alguém abre.

**Por que elas não podiam ficar.** A regra 29 exige as duas metades: existe projeto
legítimo com resposta diferente, E o valor é impossível de derivar. Um piso de PHP, os
limites mínimos de execução, os cabeçalhos de segurança, os tetos de desempenho, a
política de versão de plugin e a lista de plugins instaláveis reprovam a primeira metade.
Nenhum operador tem resposta melhor do que o pacote para "quanto de memória a montagem de
um lote precisa" — e o que ele ganhava por poder responder era a chance de responder
errado num arquivo que ele abriu para escrever o nome do site.

**O achado que a migração desenterrou, e que era o defeito de verdade.** Quarenta e duas
das leituras dessas chaves carregavam o valor declarado como PADRÃO da própria chamada:
`obter( 'cabecalhos.coop', 'same-origin-allow-popups' )`. Isso é uma segunda cópia da
decisão dentro do código. As duas concordavam por coincidência; editar a configuração
deixaria o padrão dizendo o valor antigo, e com a chave ausente o pacote entregaria em
silêncio algo diferente do que o arquivo declara. Nenhuma checagem via isso, porque a
regra 11 olha declarada → lida e as duas estavam lá. Os padrões saíram todos: o lado
seguro passou a vir do cast — `(string) null` é vazio, `(int) null` é zero —, e o catálogo
é a única fonte do valor.

**O segundo achado, da mesma família.** `F3Base_Imp_Seo::SLUG` era uma constante com
`wordpress-seo` escrito à mão, enquanto a instalação lia o slug da lista de plugins.
Trocar o plugin de SEO no catálogo deixaria este adaptador escrevendo nas options do
plugin antigo — sem erro nenhum, porque a gravação funciona. A pergunta certa não é "qual
é o slug" e sim "qual é o plugin no PAPEL de seo", e a constante virou
`F3Base_Imp_Seo::slug()`, que pergunta isso à mesma lista que a instalação percorre.

**O que a migração quase deixou cair.** Três regras que o schema cobrava de
`plugins.instalaveis` — slug, papel e origem presentes; `sha256` com 64 hexadecimais
minúsculos; `sha256` só no ramo de origem `url` — deixariam de existir junto com a chave,
porque um TSV não tem schema. O piso do validador acusou: três mutantes passaram a
aprovar. As três regras foram remedidas em `decisoes.fonte_unica`, onde o valor mora
agora. Migração que deixa uma regra para trás é pior que migração nenhuma, porque o
arquivo fica menor e a defesa some junto.

**Seis chaves foram RECLASSIFICADAS em vez de migradas**, e a classificação corrigida vale
mais do que a consistência com o que já tinha sido aprovado. `ambiente.indexar` e
`ambiente.permalinks_decisao` são decisão do PROJETO — o próprio `$comment` do schema já
dizia isso, e um site que está sendo migrado quer `manter-existente` onde um site novo
quer `aplicar-e-cobrir`. `ambiente.fuso` é do site, e instalação limpa nasce em UTC, que
está errado para quase todo mundo. E `consentimento.padrao` e `retencao.leads_meses` são a
mesma coisa que `retencao.base_legal`: postura jurídica. Um pacote que escolhe o padrão de
consentimento e o prazo de retenção de outro está assinando embaixo de coisa que não é
dele — e pior, estaria partindo em dois arquivos, com donos diferentes, as duas metades de
um fato só.

**O bloco `formularios` foi ADIADO**, e o motivo é estrutural: ele é uma trinca de
naturezas — decisão, referência interna e dado do operador — no mesmo registro, e
`formularios[].destino` guarda o CAMINHO PONTILHADO de outra chave. Partir o registro
entre dois arquivos deixaria o ponteiro apontando para um registro que já não existe
inteiro, e `formulario.veredito_destino` cruza destino com regime — é uma checagem que
existe para cruzar fontes, e essas não se redesenham para arrumar a vitrine. O bloco se
move uma vez, junto com o dado do operador.

**O que custa.** Um formato a mais, um produtor a mais e um detector a mais. O valor no
catálogo é JSON e não texto cru, o que parece cerimônia até a primeira lista: sem forma
declarada não há como distinguir a lista `["page","post"]` da string `"page,post"`, e
aceitar o texto cru faria toda lista chegar ao consumidor como string, com o defeito
aparecendo longe daqui. E a suíte passou a ler o catálogo por conta própria, que é uma
segunda leitura deliberada: auditor que usa o leitor do auditado não consegue acusar
defeito do leitor.

**O que o detector NÃO prova, dito de propósito.** Ele cobra que o motivo exista, que
tenha corpo e que não seja palavra por palavra o de outra decisão. Julgar se a prosa diz o
que aconteceria com outro valor é conferência de quem lê. E literal em COMPARAÇÃO não é
achado: `'url' === $origem` é o código reconhecendo o vocabulário em que a resposta vem, e
proibi-lo tornaria impossível ramificar sobre a própria decisão.

**Como reverter.** Cada linha do catálogo volta a ser uma chave de `config/site.json` com
a entrada correspondente no schema, os consumidores voltam a `F3Base_Imp_Config::obter()`
e `decisoes.fonte_unica` sai com o arquivo que ela mede. Os padrões repetidos nas chamadas
NÃO voltam: eles eram defeito antes da migração e continuariam sendo depois.

## 88. O operador ganha um arquivo só dele, e o fato jurídico deixa de ser três chaves soltas

**Decidido.** `config/projeto.json` passou a existir, com schema próprio e produtor único
`F3Base_Imp_Projeto`. Ele guarda **58 folhas** — as 34 do operador, as 6 reclassificadas na
fatia das decisões e as 24 do bloco `formularios`, que moveu inteiro. `config/site.json`
ficou com 173 folhas, contra as 364 do começo.

**Por que um arquivo separado e não uma seção.** Um arquivo que mistura decisão do pacote,
fato da história do pacote, conteúdo e dado do operador obriga quem o abre a descobrir,
chave por chave, qual delas ele tem o direito de responder. E a resposta errada não falha:
ela entrega um site diferente do que alguém queria, em silêncio. A queixa que originou toda
esta reescrita era sobre esse arquivo, e o remédio não era encurtá-lo — era fazer com que o
que sobrasse nele fosse só pergunta que o operador é a pessoa certa para responder.

**Cada campo nasce vazio, com uma exceção declarada.** Onde o template tem um valor
obviamente certo para o contexto dele, o campo nasce preenchido e o `$comment` diz que
aquele é o valor do TEMPLATE e em que situação trocá-lo — o fuso é o caso claro, e a
alternativa seria pior: instalação limpa do WordPress nasce em UTC, que está errado para
quase todo mundo, e um campo vazio aqui viraria um site com a hora errada no relatório sem
ninguém notar. Campo que nasce certo é melhor que campo que nasce vazio; o que não pode é
campo que nasce vazio quando existe resposta certa. `plugins_operacionais`, ao contrário,
nasce vazia: o plugin que a hospedagem instalou é fato de UM site, não do template.

**Cada `$comment` diz onde obter o valor.** Não "preencha o Measurement ID" e sim "Google
Analytics > Administrador > Fluxos de dados > o fluxo do site". São 61 campos com esse
comentário. O operador não deveria precisar de nós para saber onde achar o que preenche, e
a pergunta que ele mais faz não é o que é o campo — é onde fica.

**O fato jurídico deixou de ser três chaves em três blocos.** `retencao.base_legal`,
`retencao.leads_meses` e `consentimento.padrao` moravam em dois blocos diferentes e eram
medidas como três estados independentes. São **um fato só com três faces**: a base sustenta
o tratamento, o prazo é a proporcionalidade dessa base à finalidade, e o padrão de
consentimento é a postura que ela implica no navegador. Separá-las por arquivo, com donos
diferentes, criaria exatamente a divergência que o resto do pacote gasta energia para
impedir. Agora moram em `fato_juridico` e `projeto.fato_juridico_coerente` as mede como
conjunto: nenhuma preenchida é o estado de ENTREGA e é coerente — o pacote não declarou nada
porque não tem como declarar; todas preenchidas é completo; **alguma preenchida e alguma
vazia é INCOERENTE**, e é este que sai nomeado dos dois lados, porque quem respondeu metade
acha que respondeu tudo.

**Zero mês é NÃO DECLARADO, e não "apagar na hora".** Lido como valor válido, um prazo de
zero apagaria todo lead na primeira execução da rotina de retenção. Tem piso próprio.

**A trinca de `formularios` moveu inteira**, e é o motivo de o bloco estar aqui apesar de
metade dele ser decisão do pacote. `formularios[].destino` guarda o CAMINHO PONTILHADO de
outra chave do mesmo arquivo — a do WhatsApp, a da caixa de leads. Partido entre dois
arquivos, o ponteiro apontaria para um registro que já não existe inteiro, a leitura
devolveria vazio em silêncio, e o regime fecharia N/A dizendo que falta preencher uma chave
que está preenchida. O piso confere que todo `destino` RESOLVE dentro do próprio arquivo.

**Um validador, dois schemas.** `F3Base_Imp_Config::validar()` virou
`validar_contra( $dados, $schema )`, e `validar()` delega. Um segundo validador seria um
segundo conjunto de regras divergindo do primeiro no dia em que alguém corrigisse só um — e
o piso de treze mutantes que o primeiro já tinha não valeria para o segundo.

**Um defeito de método corrigido no caminho.** O piso de
`preflight.artefato_do_pacote_e_baseline` montava a bancada LENDO o arquivo de configuração
entregue: ele exigia que `plugins.operacionais` trouxesse a entrada do plugin da hospedagem
para o teste passar. Isso amarra o teste de uma REGRA — "plugin declarado como operacional
deixa de ser divergência" — a um valor de UM projeto, e faria o teste falhar quando um
projeto mudasse de ideia. Pior: exigia que o template deixasse de nascer vazio para o piso
ficar verde. A bancada passou a declarar os próprios dados.

**O que custa.** Um arquivo a mais para o operador conhecer, e um produtor a mais. E cria
uma dependência nova entre arquivos: o ponteiro do `destino` resolve dentro de
`projeto.json`, então mover qualquer uma das chaves apontadas exige mover o bloco junto — o
que está escrito no `$comment` do campo.

**Como reverter.** As 58 folhas voltam para `config/site.json` com as entradas
correspondentes no schema, os consumidores voltam a `F3Base_Imp_Config`, e
`projeto.schema_valida` e `projeto.fato_juridico_coerente` saem com o arquivo que medem. O
agrupamento do fato jurídico NÃO volta a se dispersar: as três faces continuam sendo um fato
só, esteja ele em que arquivo estiver.

## 89. O vocabulário passa a ser um só, e o cruzamento é o que torna duas fontes seguras

**Decidido.** `F3Base_Vocabulario` passou a existir: classe sem pai e sem dependência que
viaja dentro do `site-core` e que o implantador alcança pela cópia de origem, exatamente
como `F3Base_Chaves_Seo`. Ela guarda o CONJUNTO de valores que os dois runtimes
reconhecem — modelos de atribuição, modos da lista do `llms.txt`, políticas de frame, COOP,
referrer e permissões, e o slug do plugin de cada papel. Oito literais distintos saíram de
oito arquivos do `site-core`, em dezesseis ocorrências.

**Qual era o defeito.** O implantador ESCOLHE, no catálogo; o `site-core` RECONHECE, no
sanitizador e no módulo. Enquanto os dois lados escreviam o mesmo literal cada um por sua
conta, eles concordavam por COINCIDÊNCIA: o catálogo podia trocar de modelo de atribuição
e o sanitizador continuaria devolvendo o antigo como padrão; o plugin de SEO podia trocar
no catálogo e o módulo de noindex continuaria procurando o slug antigo. Nada quebra nesses
casos — é essa a parte ruim. A medição some, a exclusão nunca dispara, e a única evidência
é um número que não aparece no relatório de ninguém.

**O que torna duas fontes seguras não é uni-las: é cruzá-las.** O `site-core` não pode ler
`config/decisoes.tsv` — ele não viaja com o catálogo —, então o slug precisa estar na
classe. O que impede a divergência é `decisoes.fonte_unica` exigir que toda decisão que o
vocabulário governa valha um dos valores que ele declara, e que todo papel que ele fixa
ache no catálogo uma entrada com exatamente aquele slug. A classe declara o que governa em
`decisoes_governadas()` e `papeis_governados()`, e é por esse mapa que a checagem cruza —
sem uma segunda lista, que seria o mesmo problema com outro nome.

**O JavaScript recebe o token em vez de escrevê-lo.** `f3base-leads.js` comparava o modelo
de atribuição com o literal `'first-touch'`, numa linguagem onde nenhuma constante do PHP
alcança. Agora o token viaja no objeto localizado, e o script compara o que recebeu com o
que recebeu. Sem token, nada é primeiro toque — o lado seguro, em que a atribuição
sobrescreve e nenhuma origem é inventada.

**Um defeito grave descoberto pelo próprio piso.** Todo arquivo de origem do `site-core`
abre com `if ( ! defined( 'ABSPATH' ) ) { exit; }`. Num processo de linha de comando sem a
constante, esse `exit` **não lança exceção e não imprime nada**: encerra o processo inteiro
com status ZERO, no meio da rodada. Quando o cruzamento nasceu, a suíte e o piso passaram a
parar calados na checagem anterior à que carrega a classe — saída sem resumo, sem erro e
sem FALHA, e o `grep` por FALHA voltava vazio como se tudo estivesse bem. Sucesso
silencioso pela metade é pior que falha barulhenta. O carregador define a constante antes
do `require`, e o comentário no lugar existe para a próxima classe compartilhada não
repetir o caminho.

**A varredura dos pisos amarrados a valor de projeto**, feita depois do achado de
`preflight.artefato_do_pacote_e_baseline`. Quatro casos, todos corrigidos:
`config.schema_valida` fixava a ESCOLHA de `cabecalhos.hsts` em vez de provar de onde o
valor veio; `projeto.schema_valida` fixava o fuso do template, e um template entregue a
cliente em outro fuso reprovaria a suíte sem defeito nenhum; `plugins.https_em_todo_salto`
partia da URL da entrada de índice 2 do catálogo, e uma reordenação exercitaria a cadeia a
partir de string vazia; e `plugins.autoupdate_caminho_separado` montava o caso do plugin
operacional lendo o arquivo do projeto — que nasce vazio, de modo que a regra deixara de
ser exercitada sem que nada dissesse isso. Os quatro passaram a declarar os próprios dados
ou a medir a FORMA em vez do valor.

**O que custa.** Uma classe a mais no `site-core` e um cruzamento a mais na checagem. E
cria uma dependência de carga: quem monta o catálogo de options precisa da classe antes,
o que já custou uma sonda morrendo por classe não encontrada.

**Como reverter.** Os literais voltam para cada arquivo do `site-core`, a classe sai, e o
cruzamento sai de `decisoes.fonte_unica` com ela. O que NÃO volta é o literal no
JavaScript: o token localizado é mais barato que a duplicação, mesmo sem a classe.

---

## 90. A seção entra e sai pela MESMA linha, e a bancada ganha geometria

**Decidido.** O observador de seções passa a ser armado com os thresholds `[0, visivel]` e a
decidir por `entrada.intersectionRatio >= visivel` — a mesma linha declarada nos dois
sentidos. `isIntersecting === false` continua valendo como saída, porque é assim que chega o
alvo removido da árvore. E a bancada de comportamento da suíte ganha GEOMETRIA: cada seção do
documento falso tem topo e altura, `rolarAte()` calcula a razão de interseção contra a janela
e entrega o retorno do observador a quem mudou de faixa de threshold ou de estado de
sobreposição — que é o que o navegador faz.

**Qual era o defeito.** A ENTRADA e a SAÍDA usavam linhas DIFERENTES. Entrava-se quando a
razão cruzava `visivel` (0,5) para cima, que é o threshold declarado; só se saía quando
`isIntersecting` virava falso, que na especificação é razão ZERO. Quando a razão cai de 0,6
para 0,4 o navegador DISPARA o retorno — o índice de threshold mudou de 1 para 0 —, mas
`isIntersecting` continua VERDADEIRO, porque ainda há sobreposição. O código caía em
`if (dentroDaVista[secao]) continue;` e não rearmava. A seção só voltava a contar se saísse
INTEIRA da tela, o que em página curta não acontece nunca.

O resultado medido em produção, em `wp_2zsugm_f3base_eventos`: **80 linhas, todas com
`ocorrencia = 1`, nenhuma reentrada em nenhuma visita**. A coluna "vez" da tela existia, a
tabela tinha o dado, e o dado era sempre 1 — a releitura de bloco, que é a pergunta inteira
que a 1.2.1 foi feita para responder, não existia.

**POR QUE ISSO SOBREVIVEU: a bancada era mais fácil que o mundo.** `bancadaDeComportamento`
expunha `verSecao(i)` e `esconderSecao(i)`, que disparavam `{ isIntersecting: true|false }` À
MÃO — sem razão de interseção e sem nenhuma relação com a posição de rolagem. `rolarAte(95)`
não movia seção nenhuma. O retorno intermediário do navegador — `isIntersecting: true` com
razão 0,4 — nunca era produzido, e por isso a bancada aprovou um rearme que o navegador quase
nunca alcança. Uma bancada que só sabe dizer "entrou" e "saiu" não pode reprovar um código
que erra exatamente entre os dois.

O conserto da bancada é METADE do trabalho, e não um detalhe: sem ele, o conserto do cliente
seria uma afirmação sem medida. A geometria padrão são faixas iguais ao longo do documento,
com a seção nunca mais alta que a janela — uma seção de duas telas jamais alcançaria meia
seção visível, e a bancada padrão passaria a medir o caso em que nada dispara. Quem precisa
de layout específico declara `geometria`. `verSecao`/`esconderSecao` continuam existindo para
os testes que só precisam do bloco entrando e saindo; o que não pode mais acontecer é um
teste de RELEITURA ser dirigido por eles.

**O PISO NOVO, em `js.sessao_com_releitura`.** Um ciclo dirigido só por `rolarAte` — desce até
o fim, volta ao topo e desce de novo — numa página curta de duas telas, em que dois dos três
blocos NUNCA saem inteiros do campo de visão. Ele exige `ocorrencia` 1 e 2 para os três blocos
e para os quatro marcos. E planta a MUTAÇÃO correspondente: o código de hoje — `threshold:
visivel` com a saída decidida por `isIntersecting` — tem de deixar os dois blocos presos numa
ocorrência só. Sem essa mutação o piso não provaria nada, porque foi exatamente esse código
que passou na bancada anterior. O terceiro bloco, que SAI inteiro da tela, continua sendo
registrado duas vezes no mutante — é o caso fácil, o único que o código antigo acertava, e ele
fica no piso para separar a assimetria de um defeito qualquer.

**O que custa.** Três preços.

O primeiro é **mais retornos de observador no navegador do visitante**: com dois thresholds,
o navegador avisa na entrada, na saída e na travessia da linha, em vez de só na travessia. É
trabalho pago por quem visita, e ele é pequeno perto do que já se paga por observar as seções.

O segundo é **mais linhas no registro detalhado**. Uma visita que sobe e desce numa página
curta passa a gravar cada passagem, e o teto por sessão — que agora vale 20, e não 6 — é o que
segura isso. O agregado continua contando uma vez por carregamento: as duas leituras convivem
de propósito.

O terceiro é que a **entrada sintética precisa de tratamento**. `intersectionRatio` pode vir
`undefined` — em bancada, em polyfill —, e tratar a ausência como zero rearmaria a seção a
cada retorno, fazendo contar duas vezes quem hoje conta uma. A ausência é tratada como
`isIntersecting ? visivel : 0`, que preserva o comportamento antigo exatamente onde não há
razão a ler.

**Como reverter.** Voltar `{ threshold: visivel }` e a decisão por `isIntersecting` reprova
`js.sessao_com_releitura` em dois tetos, com a frase do caso real. Tirar a geometria da
bancada faz o piso da assimetria não encontrar o defeito e reprovar por conta própria — a
reversão é possível e não é silenciosa.

---

## 91. A fronteira do marco ganha banda, e a declaração passa a defender o número que declara

**Decidido.** `histerese_pp=5` entra no limiar da `rolagem` em
`fontes/site-core/dados/eventos-comportamento.tsv`, e o marco só rearma abaixo de
`marco - histerese_pp` — nunca na própria linha. E o motivo escrito na declaração passa a
defender `travessias_por_sessao=20`, que é o que ela sempre declarou; o padrão de reserva do
cliente, que valia 6, passa a valer 20.

**Qual era o defeito, nas duas metades.**

A primeira é o FLAPPING. `instrumentarRolagem` rearmava `dentro[marco]` no instante em que o
percentual caía abaixo do marco. Um tremor de um pixel na fronteira — o dedo que segura a
página, o cabeçalho que recolhe, a imagem que entra e empurra a altura do documento — fabrica
uma travessia que ninguém fez, e ela chega ao relatório com cara de releitura. Fronteira sem
banda transforma tremor em leitura. Cinco pontos porque é muito mais que o tremor (na altura
de uma página comum, um pixel não chega a um décimo de ponto, e um cabeçalho que recolhe fica
na casa de três) e muito menos que o menor vão entre dois marcos, que é quinze: uma banda
maior que o vão engoliria a travessia do marco vizinho.

**Para a SEÇÃO não há um segundo número, e isso é decisão e não esquecimento.** A banda
`[0, visivel]` do observador já É a histerese: a folga entre a razão zero e o limiar declarado
é exatamente o que separa a entrada da saída. Um `histerese_pp` para a interseção seria um
número que ninguém revisaria junto com o `visivel` que ele protege.

A segunda metade é a DECLARAÇÃO QUE DISCORDAVA DO PRÓPRIO MOTIVO. O TSV declarava
`travessias_por_sessao=20` na `rolagem` e na `interseccao`, e o motivo ao lado argumentava
*"Seis porque duas ou tres releituras sao leitura de verdade e a partir da sexta o padrao ja
esta estabelecido"*. O cliente, por sua vez, usava 6 como padrão de reserva. Três respostas
para o mesmo teto, e a mais visível — o motivo — defendia justamente a que a declaração não
usava. Ficou 20, que é o pedido literal de quem encomendou a coluna: TODOS os acionamentos,
inclusive do mesmo visitante na mesma visita. O motivo foi reescrito para defender 20, e a
reserva do cliente subiu para 20, porque reserva menor que a declaração aperta o teto em
silêncio no dia em que o arquivo se corromper.

**O que custa.** A banda tem um preço real: uma travessia curta e legítima — o visitante que
sobe três pontos percentuais e desce de novo — deixa de ser contada. É o lado certo de errar:
travessia perdida é um número menor, travessia fabricada é um número que descreve um
comportamento que não houve. E o teto em 20 é mais linha no registro detalhado por visita
inquieta, cortada pelo mesmo excedente somado que já existia.

**Como reverter.** Tirar `histerese_pp` da declaração faz o cliente cair no padrão de reserva
`0`, que é o comportamento antigo — e reprova `js.sessao_com_releitura` no teto da declaração,
que exige a banda declarada. Baixar o teto é editar uma coluna do TSV, sem release.

---

## 92. O desligamento da medição vira encontrável, e não ganha chave nova

**Decidido.** O menu **Medição** passa a dizer, ANTES de qualquer número, onde a medição se
desliga e o que o desligamento faz, com link para a tela de configuração e âncora no próprio
campo. Com `f3base_comportamento.ligado` falso, a PRIMEIRA coisa da tela é a frase do
desligamento. Nenhuma chave nova foi criada.

**Por quê.** O pedido, nas palavras de quem o fez: *"Permita também que essa medição possa ser
desativada na área de configuração do plugin."* A medição da resposta, antes de respondê-la: a
chave JÁ EXISTIA — `f3base_comportamento.ligado`, na seção de privacidade, honrada em três
pontos de `class-f3base-modulo-comportamento.php`. Criar um interruptor novo seria duplicar
uma decisão que já tem lugar, e a regra 29 proíbe exatamente isso: duas chaves para "esta
instalação mede?" divergem na primeira vez que alguém mexer numa e não na outra, e o site
passa a ter duas respostas para a mesma pergunta.

O que faltava não era o controle: era ele ser ENCONTRÁVEL. Quem abre a tela Medição não tem
por que saber que a chave que a desliga mora na tela ao lado, embaixo de um título sobre
privacidade. E, desligada, a tela mostrava o desligamento no MEIO de uma lista, depois do
parágrafo de abertura: o que o operador via primeiro era uma tela sem número nenhum — que é
indistinguível de um site sem visita.

**A ÂNCORA TEM PRODUTOR ÚNICO.** O `id` do sub-campo saiu de literal montado dentro de
`render_subcampo()` e virou `F3Base_Admin_Tela::id_do_subcampo()`. Montado como literal nos
dois lugares, ele concordaria por coincidência: renomear a option ou a chave manteria o link
existindo e o faria deixar de levar a lugar nenhum, sem erro e sem nada acusando. O piso
cruza os dois lados — a tela Medição aponta para uma âncora, e a tela de configuração precisa
ter um campo com aquele `id`.

**O que custa.** Um parágrafo a mais no topo de uma tela que já era longa, e ele aparece
também quando está tudo funcionando — que é o caso comum. É o preço de o controle ser
encontrável antes de alguém precisar dele: uma frase que só aparecesse com a medição
desligada ensinaria onde desligar só a quem já tivesse desligado.

**Como reverter.** Tirar a linha do topo reprova `medicao.menu_proprio` no teto do controle
encontrável, e tirar a frase do desligamento reprova o piso do desligamento nomeado, que mede
a posição dela em relação ao primeiro quadro da tela.

---

## 93. O contador de travessias sai do carregamento e passa a viver na visita

**Decidido.** O contador de travessias — o número que vira a coluna **vez** da tabela bruta —
deixa de ser variável do carregamento e passa a morar no registro da VISITA, no
`localStorage`, sob a mesma chave `f3base_sessao` que já atravessa páginas. A chave de cada
contador é `caminho | gatilho | detalhe`. O total de **cortadas** vai junto, pelo mesmo
motivo. O estado ARMADO — `dentro`, dos marcos, e `dentroDaVista`, das seções — continua
sendo do carregamento, e isso é decisão, não esquecimento. O agregado continua contando uma
vez por carregamento. Nenhum número mudou de valor: `travessias_por_sessao` continua 20.

**Qual era o defeito, e como ele foi medido.** A pergunta de quem opera: *"ao navegar no
site, as triggers só estão sendo gravadas na primeira vez que eu passo. É possível gravar
todas as vezes que eu passo por um bloco na mesma visita?"*

Site `fator3-teste-mcp-1`, tabela `wp_2zsugm_f3base_eventos`, visita
`8bb0a2d5528a9336111ca5be06178284`, já com o conserto da 1.3.3 aplicado. Dois carregamentos
de `/` na MESMA visita, 34 segundos entre eles:

| Carregamento | Bloco `pecas` | Marco de 25% |
|---|---|---|
| A (`f3base_pagina_vista` em ms 1057) | oc 1 em ms 10378, **oc 2** em ms 24911 | oc 1 em ms 10412, **oc 2** em ms 25228 |
| B (`f3base_pagina_vista` em ms 865) | oc **1** em ms 8329 | oc **1** em ms 8329 |

O rearme da 1.3.3 funciona: dentro do carregamento A a segunda passagem apareceu como
segunda. O que estava errado era o CONTADOR. `travessias`, `travessiasDaSecao`, `dentro`,
`dentroDaVista` e `cortadasNaVisita` eram variáveis do carregamento: nasciam zeradas a cada
página e morriam na navegação. O visitante que passa pelo bloco `pecas`, vai para
`/arquitetura/` e volta é registrado três vezes como se fosse a primeira.

E o limiar se chama `travessias_por_SESSAO`. O nome prometia visita e a implementação
entregava carregamento — **uma declaração que mente sobre o que mede é pior que um número
errado, porque ninguém vai conferir.**

**Por que a chave inclui o CAMINHO.** `pecas` em `/` e `pecas` em `/arquitetura/` são seções
diferentes com o mesmo nome. Somá-las responderia uma pergunta que ninguém fez — *"quantas
vezes este NOME de bloco foi visto no site inteiro?"* — e esconderia as duas, porque nenhuma
das duas páginas teria mais a própria contagem. A chave `caminho | gatilho | detalhe` é a
mesma granularidade que a tabela do servidor já usa para somar, e é a mesma pela qual o
operador filtra.

**Por que o estado ARMADO não persiste, e por que essa é a metade que quebra se for feita
errado.** Uma página nova começa com nada em vista e nada rolado. Persistir "já estou dentro"
junto com o contador — que é o erro natural de quem faz o conserto pela metade — faria a
primeira entrada do carregamento seguinte ser engolida: o bloco que já está no topo da página
para a qual o visitante acabou de navegar não produziria linha nenhuma, e ele perderia
justamente a passagem que acabou de fazer. Trocaria um defeito por outro, com o agravante de
o segundo ser mais difícil de ver — uma linha a menos não chama atenção como uma linha
errada. Persiste o CONTADOR; o armado nasce zerado a cada carregamento, e o piso 4 de
`js.sessao_com_releitura` existe só para isso.

**O que o agregado NÃO passa a fazer.** `emitir()`, `vistos` e `vistas` continuam uma vez por
carregamento. O total do painel responde *"quantas visitas viram este bloco"*; a tabela
responde *"quantas vezes cada uma passou"*. Somar releitura no agregado inventaria audiência
que não existe, e as duas leituras convivem de propósito desde a 1.2.1.

**Uma assimetria consertada de passagem.** O coletor de rolagem somava a travessia acima do
teto num mapa `excedentes` que ninguém lia e que não viajava para lugar nenhum, enquanto o
coletor de seções, ao lado, já somava em `cortadasNaVisita` — que sai NOMEADA no corpo. O
comentário ao lado do `excedentes` prometia que *"a última linha registrada daquele marco
carrega quantas travessias houve"*, e a última linha registrada carregava o TETO, nunca o
total: era corte silencioso com cara de contabilidade. As duas travessias que estouram teto
agora contam no mesmo lugar, e o piso 5 mede o excedente saindo nomeado.

**O teto do mapa é `maximoVisita`, e não um número novo.** O mapa existe para servir o
registro, e o registro tem orçamento de `maximoVisita` linhas na visita inteira (200,
`F3Base_Modulo_Comportamento::MAX_POR_VISITA`). Uma chave além desse orçamento é
armazenamento gasto no aparelho de alguém para contar uma passagem que nunca virará linha.
Passando do teto, a passagem conta em cortadas e não cria chave nova. Escrever `200` dentro
do JavaScript daria dois números para revisar onde há uma decisão só, e é a mesma regra que
mantém todo limiar deste coletor fora do cliente.

**O que custa.** Três coisas, e as três estão medidas.

A primeira é ESCRITA NO NAVEGADOR: o registro da visita é regravado a cada travessia contada,
e não mais só a cada linha registrada. É uma gravação de poucas centenas de bytes por
travessia, e a travessia já é limitada pela banda de histerese e pela geometria — nenhum gesto
humano produz rajada aqui. A gravação acontece na hora de propósito: a saída de página não é
um instante confiável, e travessia contada só na memória é travessia perdida na navegação.

A segunda é DADO A MAIS NO APARELHO DO VISITANTE. O registro da visita ganhou dois campos, e o
piso do identificador em `js.resumo_da_sessao` passou a exigir a forma de cada chave do mapa:
`caminho|gatilho|detalhe`, com o detalhe pelo mesmo alfabeto fechado do payload. Nenhum texto
livre, nenhuma query, nenhuma mensagem de erro. O caminho é o de uma página deste site — que o
histórico do próprio navegador já tem — e o registro inteiro é removido do aparelho na recusa,
pela mesma chamada que remove o apelido.

A terceira é a SÉRIE HISTÓRICA. A coluna `ocorrencia` das linhas gravadas antes desta release
conta carregamento; as de agora contam visita. Um agente comparando períodos vai ver a
ocorrência média subir sem que o comportamento tenha mudado. Não há migração possível — o dado
antigo não guarda de qual carregamento cada linha veio —, e por isso a tela Medição passou a
declarar, em português comum e antes da tabela, sobre que janela a coluna conta.

**Como reverter.** Fazer `travessiasDaVisita` nascer vazio em `carregar()` devolve o
comportamento de 1.3.3 — e reprova `js.sessao_com_releitura` no teto da travessia entre
carregamentos, que é a mutação plantada. Tirar os dois campos do registro guardado reprova o
piso do identificador em `js.resumo_da_sessao`, que declara o conjunto EXATO de campos.
Reverter não apaga o que já foi gravado no servidor: as linhas com ocorrência de visita
continuam lá, e a série passa a ter três regimes em vez de dois.

---

## 94. O contador e a linha passam a ter a MESMA durabilidade

**Decidido.** O envio do resumo passa a CONFIRMAR a entrega — `fetch` com `keepalive`, e o
lote só é esquecido com resposta 2xx —, e a linha passa a ser tão durável quanto o contador:
o acumulado ainda não selado e os lotes já selados moram no `localStorage`, dentro do registro
da visita, ao lado do contador. Cada lote leva um SELO sorteado, e o servidor recusa um selo
que já gravou para a mesma visita respondendo 2xx assim mesmo. Sem `keepalive`, o envio
continua acontecendo por `sendBeacon` — degradado e declarado. O corte deixa de morrer na
resposta da rota e passa a ser gravado, e a tela Medição o mostra.

**Qual era o defeito, e como ele foi medido.** A pergunta de quem opera: *"os gatilhos estão
aparecendo mais de uma vez, mas alguns estão sendo perdidos."*

Site `fator3-teste-mcp-1`, tabela `wp_2zsugm_f3base_eventos`, visita
`8cac18da62ed056004242bee737457db`, já com a 1.3.4 instalada. UM único carregamento de `/`
— um só `f3base_pagina_vista`, em ms 984. As linhas que chegaram, por lote:

| Lote | Linhas, por `ms` |
|---|---|
| 1 (16:17:40) | 984 `pagina_vista` · 1746 `abertura` oc1 · 2658 LCP, CLS, TTFB |
| 2 (16:17:49) | 10087 `pecas` oc1 · 10504 `rolagem25` oc1 |
| 3 (16:18:05) | 24780 `pecas` oc2 · 24813 `rolagem25` oc2 · 25080 `comando-unico` oc1 · 25113 `rolagem50` oc1 · 26063 `rolagem75` oc1 · 26080 `faq` oc1 |
| 4 (16:19:02) | 79925 `comando-unico` **oc3** · 79958 `rolagem50` oc2 · 81525 `rolagem75` oc2 · 81542 `faq` oc2 · 81592 `rolagem90` oc1 |

`comando-unico` pula de 1 para 3. Todos os outros gatilhos são contínuos. Entre os ms 26080 e
79925 o visitante SUBIU a página: a subida faz `comando-unico` reentrar em vista — uma
ocorrência — e não dispara marco nenhum, porque marco só conta na descida. O lote despachado
naquele instante tinha UMA linha só, e é essa que sumiu.

**A causa, e ela é da 1.3.4.** Ali o CONTADOR virou durável e a LINHA ficou volátil.
`contarTravessia()` incrementa e grava no `localStorage` na hora; a linha vai para
`registroDaSessao`, que é memória do carregamento; e `enviarResumo()` limpava esse registro
quando `sendBeacon` devolvia `true`.

**E `sendBeacon` devolvendo `true` significa ENFILEIRADO, nunca ENTREGUE.** A especificação é
explícita: o retorno diz que o agente de usuário aceitou a carga para transferência. Se a
requisição morre depois disso — rede caindo, servidor respondendo erro, aba encerrada antes de
o envio sair —, nada avisa a página, e as linhas já foram jogadas fora.

Resultado: qualquer lote que não chega avança o contador sem produzir linha. Antes da 1.3.4
isso perdia linhas em silêncio; depois dela o buraco na sequência de `ocorrencia` tornou a
perda VISÍVEL, que é exatamente o que o operador viu.

**O invariante quebrado é o nome do conserto: numa visita, as ocorrências de um mesmo gatilho
no mesmo caminho formam uma sequência SEM BURACOS. Qualquer mecanismo que avance o contador
sem produzir linha reprova.**

### As quatro metades, e por que nenhuma delas fecha sozinha

**A. Confirmar a entrega, em vez de confiar no enfileiramento.** O despacho é
`fetch(endpoint, { method: 'POST', keepalive: true, … })`, que sobrevive ao descarregamento da
página como o beacon e, ao contrário dele, DEVOLVE resposta. O acumulado é limpo só com 2xx.
`keepalive` é o discriminante, e não `fetch`: um navegador com `fetch` e sem `keepalive`
cancelaria a requisição na saída, que é pior que o beacon.

**B. Tornar a linha tão durável quanto o contador.** O registro da visita ganhou dois campos,
e eles **não são redundância**: cada um segura um caso que o outro não alcança.

- `acumulado` é o que ainda não foi selado, com o CAMINHO a que pertence. Ele socorre a página
  que morre **sem ter selado nada** — a aba encerrada pelo sistema, o aparelho sem memória, o
  navegador descartando a página. `pagehide` não é promessa, e um lote selado só na saída
  nunca chega a ser selado.
- `pendentes` é a fila de lotes selados e ainda não confirmados. Ela socorre a página que
  morre **depois** de selar: ocultou, o lote foi selado e despachado, o servidor recusou de
  forma transitória, e só então a aba foi encerrada. Nesse instante o `acumulado` está VAZIO —
  ele foi selado —, e quem segura as linhas é a fila, e só ela.

A distinção não é teórica: ela é o que os dois pisos medem separadamente, e é por isso que as
duas mutações são plantadas **isoladas**. Uma mutação que apagasse os dois campos de uma vez
derrubaria os dois cenários e não diria qual campo responde por qual — seria um piso que só
sabe falhar quando dois defeitos acontecem juntos, e um piso assim não prova nenhum dos dois.
Com elas separadas, apagar a gravação do acumulado derruba só o primeiro cenário e apagar a
gravação da fila derruba só o segundo.

A metade A sozinha não fecha, porque a página pode morrer entre contar e enviar; a metade B
sozinha não fecha, porque o beacon aceito-e-perdido limparia o pendente do mesmo jeito.

**O acumulado herdado é SELADO na carga seguinte, e não continuado.** Ele pertence ao caminho
da página que morreu, e o carregamento corrente pode ser de outra: continuá-lo faria linhas de
`/` serem gravadas como se tivessem acontecido em `/arquitetura/`, sem erro nenhum e com a
tabela parecendo certa. E a retentativa acontece NA CARGA, não no próximo ocultamento —
esperar pelo ocultamento faria a recuperação depender de o visitante produzir mais uma saída
de página, e o carregamento que acabou de morrer é justamente a prova de que a saída é o que
não se pode contar.

**C. Reenvio não pode duplicar.** Confirmar implica reenviar, e reenviar sem identificador
conta duas vezes. Cada lote leva um SELO sorteado de 32 hexadecimais — a mesma forma fechada
dos apelidos, e pela mesma razão. O servidor recusa um selo que já gravou para a mesma visita
e responde **2xx assim mesmo**: para quem envia, *"já tenho isto"* e *"acabei de gravar"*
precisam ser a mesma resposta boa, porque qualquer outro status faria o cliente reter e
reenviar para sempre justamente o lote que o servidor já tem.

**O lote é SELADO, e selado significa IMUTÁVEL.** Atividade nova forma um lote novo: um lote
que crescesse mantendo o selo teria o crescimento recusado como repetição e descartado pelo
próprio 2xx, e as linhas acrescentadas sumiriam sem que nada acusasse. É por isso que o
pendente é uma FILA, e não um lote só.

**O mecanismo do selo é o MESMO da reserva de deduplicação do lead** — decisão 35 —, e pelas
três etapas dele: inserção atômica na chave única, confirmação depois da persistência e
compensação quando nada foi gravado. Uma marca simples não bastaria: marcando o selo e
gravando em seguida, uma escrita que FALHA deixaria o selo queimado, a retentativa receberia
"já gravei isto", o cliente esqueceria o lote e as linhas sumiriam — o mesmo buraco de
sequência que esta release existe para fechar, agora vindo do próprio conserto. Uma segunda
implementação seria uma segunda regra para o mesmo risco, e a segunda é a que fica para trás.
O prazo virou parâmetro de `reservar()` porque trinta dias é o prazo do LEAD: um lote de
medição vive o tempo de uma visita.

**A janela do selo é a MESMA da visita, e as duas pontas leem a mesma declaração.**
`inatividade_min` responde, dos dois lados, à mesma pergunta — até quando duas coisas ainda são
a mesma visita. No navegador ela decide se o carregamento continua a visita e se um lote
pendente ainda é retentativa; no servidor, por quanto tempo o selo é lembrado. Um número
escrito de um lado divergiria do outro na primeira vez que alguém mexesse num só, e a
divergência apareceria como linha contada duas vezes: o cliente reenviando um lote cujo selo o
servidor já esqueceu.

**D. Orçamento do que fica pendente, e ele NÃO é número novo.** Toda linha que entra num lote
passou por `registrar()`, que já gasta o teto de `maximoVisita` da VISITA inteira — que
atravessa carregamentos desde a 1.3.0. A fila é, por construção, um subconjunto desse
orçamento: uma visita não consegue deixar pendente mais do que ela podia registrar. O
excedente conta em CORTADAS, como já contava. Armazenamento bloqueado ou recusado degrada para
o comportamento de hoje — pendente só em memória, e o carregamento que morre o perde —, e é a
mesma degradação declarada do contador.

### O caminho de reserva, e a perda que ele mantém

Sem `fetch` com `keepalive`, o despacho continua por `sendBeacon`. Nesse caminho o lote
enfileirado-e-perdido continua sendo perda, **porque não há como saber** — o lote é esquecido
sobre o enfileiramento, e reter o que não se pode confirmar seria uma fila que nunca drena.

O que ele ganha de qualquer forma são as outras duas metades: o pendente é GRAVADO antes do
despacho, então a página que morre antes de o envio sair não perde nada, e o selo impede que a
retentativa do carregamento seguinte conte duas vezes. **Um conserto que só funcionasse no
navegador moderno e emudecesse o antigo seria pior que o defeito**, porque o site pararia de
medir uma fatia inteira do público sem que nada acusasse: tela vazia e tela sem visitante são
a mesma tela.

### Recusa transitória e recusa permanente, e por que a distinção teve de existir

O pedido era reter em qualquer coisa que não fosse 2xx. Reter sem critério tem um preço que só
aparece depois: **um corpo que o servidor nunca vai aceitar fica na fila para sempre e bloqueia
atrás dele tudo o que veio depois** — o pendente eterno é a forma que a perda assume quando se
retém sem separar.

A lista de permanentes é curta e é sobre o CORPO: **400** (schema fechado — campo desconhecido,
detalhe fora do alfabeto, caminho com query, gatilho não declarado) e **413** (teto de
tamanho). Nenhum dos dois muda por esperar. Nesses dois casos as linhas contam em CORTADAS
nomeadas, e não somem em silêncio. Tudo o mais é transitório e o lote fica: rede caindo, 403 de
token expirado — o carregamento seguinte leva um fresco, e é por isso que o token NÃO viaja
selado dentro do lote —, 409 de medição desligada, 429 de balde cheio, 503 de migração em
curso, 5xx do servidor.

E o 413 ficou improvável por construção, em vez de só declarado: **o teto de corpo do endpoint
passou a ser publicado ao cliente** (`maximoBytes`), e o selamento parte o registro em quantos
lotes forem precisos para caber nele. A partição acontece no SELAMENTO e nunca no despacho —
partir um lote já selado mudaria o conteúdo sob o mesmo selo. Escrito no cliente, o número
seria uma segunda verdade sobre o mesmo limite, divergindo no dia em que alguém mexesse no do
endpoint.

### Os dois amplificadores medidos, e o que mudou em cada um

**O 503 da migração.** `garantir_estrutura()` punha o transiente
`f3base_comportamento_migrando` por **quinze minutos** e a rota respondia 503 enquanto a
estrutura não estivesse pronta. `set_transient()` devolve `false` quando o valor gravado é o
mesmo que já estava lá, e era por essa devolução que a função saía cedo: um `dbDelta` que
falhasse punha o site em quinze minutos de 503 **sem uma única nova tentativa no meio**. O
transiente foi medido vivo neste site. Com o cliente descartando cada lote recusado, isso era
perda garantida com o contador andando o tempo todo.

Ficou **um minuto**, e a trava mudou de natureza: ela é trava da TENTATIVA, e não espera pelo
fracasso. Um minuto é folgadamente mais que um `dbDelta` de duas tabelas pequenas e
folgadamente menos que a janela em que um lote pendente ainda é retentativa — que é a janela da
visita, e é isso que garante que a migração terminada alcance o lote antes de ele vencer.
Repetir a tentativa a cada minuto num site que nunca vai conseguir criar a tabela custa um
`dbDelta` por minuto; ficar quinze minutos calado custa a medição de quinze minutos. **E a
trava cai no sucesso**: criada a estrutura, não há mais o que travar.

**O teto de pedidos por janela. O EIXO NÃO MUDA, e o número muda.** A alternativa foi medida
antes de ser recusada: um balde por VISITANTE seria um balde cuja chave quem bate na porta
escolhe. O apelido do visitante é sorteado dentro do navegador, e trocá-lo custa uma linha de
JavaScript — o limite recusaria exatamente quem não tem nada a esconder e não recusaria mais
ninguém. É a mesma razão da decisão 45: **controle chaveado por declaração do cliente não é
controle.**

O número, sim, estava errado para esta rota. Sessenta por dez minutos nasceu quando o envio era
UM por sessão de página; com envio por lote, um leitor atento produz um lote por ocultamento —
e ocultamento acontece toda vez que a aba perde o foco, não só na saída. Atrás de CDN, com
`f3base_origem_confiavel` vazia (o caso medido neste site), a origem é a MESMA para todo mundo,
e um visitante intenso esgotava o balde do site inteiro. O novo valor é `MAX_POR_VISITA`, e ele
não é número novo: é o teto de linhas que UMA visita pode escrever. **Um balde que não cabe uma
visita inteira recusa o leitor mais atento do site antes de recusar qualquer abuso.**

E o que o balde passou a custar mudou junto: antes, cada 429 era um lote perdido em silêncio;
agora ele é retentativa. O balde deixou de decidir o que é MEDIDO e passou a decidir QUANDO.

**O que continua sem resposta, e fica escrito:** atrás de CDN o balde é do site inteiro, e
nenhum número conserta isso. A resposta certa é declarar `f3base_origem_confiavel`, que já
existe e já é ensinada na tela de configuração — o que faltava era alguém dizer que ESTA rota
depende dela tanto quanto a de leads.

### O corte passa a ser gravado, e a tela passa a dizer que a tabela está incompleta

O corte sempre foi nosso e sempre foi contado — o cliente conta o que estourou o orçamento da
visita, o servidor conta o que estourou o teto do corpo — e saía NOMEADO na resposta da rota.
Só que **a resposta da rota morre no navegador**: quem abria o menu Medição via uma tabela e
não tinha como saber que faltava alguma coisa nela. Somava achando que tinha tudo, e essa é a
pior forma de um número errado — a que não parece errada.

Ele é somado na MESMA tabela do resumo, sob `F3Base_Modulo_Comportamento::METRICA_CORTADAS`,
porque tem exatamente a granularidade dela (dia, caminho) e exatamente o prazo dela: uma tabela
nova seria uma segunda migração, uma segunda poda e um segundo prazo para manter, para guardar
um inteiro por dia e por página. **E ele fica FORA do total, fora da lista de páginas e fora da
lista de eventos**: somá-lo ao total faria a tela afirmar ter recebido justamente o que se
perdeu, e listá-lo entre os acionamentos faria quem lê somar descarte com acontecimento. Ninguém
"cortou" nada — foi o pacote que descartou. O nome tem produtor único, e todo leitor do resumo o
exclui por ele.

Na tela, o quadro sai no *Estado da coleta*, ANTES de qualquer tabela, com o total e as páginas
em que o descarte aconteceu — descarte concentrado numa página é outra conversa que descarte
espalhado, e sem o caminho as duas são o mesmo número. **Zero não imprime nada**: um quadro
dizendo "0 descartadas" em todo site saudável ocuparia a atenção de quem abre a tela para não
responder nada.

### O que a bancada ganhou, e o que ela não sabia fazer

Três lacunas fecharam, e duas delas estavam declaradas desde a 1.3.4:

1. **A bancada não sabia recusar um envio nem devolver código de resposta.** Enquanto o
   despacho era `sendBeacon`, o único desfecho observável era "o navegador aceitou a carga", e
   a diferença entre ENFILEIRADO e ENTREGUE — que é a release inteira — não tinha como ser
   exercitada. Ela ganhou `fetch` com resposta declarada (número, função ou `'rede'`) e uma
   promessa que resolve na hora, porque a bancada é síncrona e uma `Promise` de verdade só
   entregaria o retorno depois de a checagem ter terminado.
2. **`pagehide` sempre chegava.** Ganhou `morrer()`: o carregamento que acaba sem evento de
   saída nenhum. É o único caso em que a única coisa que sobrevive é o que já estava GRAVADO.
3. **Ela nunca recusava escrita no `localStorage`.** Ganhou a recusa, e com ela o ramo da
   degradação declarada deixou de ser só uma frase de comentário.

**As três mutações plantadas**, cada uma acusada pelo piso que ela existe para exercitar:
limpar o acumulado sem conferir a resposta reprova o piso do envio recusado; manter o pendente
só em memória reprova o piso do carregamento que morre; e o selo sorteado a cada despacho —
mais o servidor sem memória do selo, no lado de lá — reprova o piso do reenvio.

### Os dois tetos deixaram de ter a mesma resposta

Esta é a última rota pela qual o contador andava sem a linha chegar, e ela sobreviveu ao
conserto principal. `registrar()` recusava a linha em duas condições somadas na mesma
expressão: o orçamento da VISITA (`maximoVisita`) e o teto de linhas de UM CORPO
(`maximoLog`). As duas somavam em cortadas, e tratá-las igual era o defeito.

**Passar do orçamento da visita termina a série.** A visita não grava mais nada, e a contagem
de cada gatilho simplesmente para. Truncar o fim de uma série é visível e legítimo: quem lê vê
onde a contagem terminou, e o excedente sai nomeado.

**Encher um corpo não termina nada.** Depois do selamento o registro volta a aceitar, e a
linha recusada por ali ficava no MEIO da série, com o contador já avançado e as linhas
seguintes chegando normalmente. É exatamente o buraco que esta release existe para eliminar,
sobrevivendo por outro caminho — e é o mesmo desenho de defeito da visita `8cac18da`, só que
produzido pelo nosso próprio teto em vez de pelo despacho perdido.

**E ele é alcançável sem nada de anormal.** Cento e vinte acionamentos entre dois ocultamentos
é um leitor inquieto numa página longa que não troca de aba. O caso de rajada — o erro de
JavaScript em laço de render — nunca foi este: ele tem teto próprio de 3 na declaração do
evento.

**Então o teto do corpo passou a SELAR o lote, em vez de cortar a linha.** O lote cheio vira
lote pendente na hora, a linha entra no lote seguinte, e a série não abre buraco. O teto do
endpoint continua valendo — nenhum corpo sai com mais linhas que ele —, e o que mudou é o
desfecho de encostar nele. Cortar continua existindo onde não há alternativa: o orçamento da
visita, e a linha que sozinha não cabe no corpo em `selar()`. O que deixou de existir é o
corte como resposta normal a um leitor atento.

O piso é a página do defeito: um trecho longo sem trocar de aba, um ocultamento no meio, outro
trecho longo. O ocultamento é o que separa TRUNCAR de ABRIR BURACO — sem ele, o mutante que
corta produziria uma série truncada, que é outro defeito. Com ele, o mutante entrega o bloco
do topo como `[1,4]`: a mesma assinatura de `comando-unico` saindo com 1 e 3 em produção.

### O que custa

**Escrita no navegador.** O registro da visita passou a ser regravado também a cada linha e a
cada total, e não só a cada travessia contada. Ele ficou maior: contador, acumulado e fila
pendente, todos limitados pelo mesmo orçamento de `maximoVisita`. A gravação acontece na hora
de propósito, e pela razão de sempre: a saída de página não é um instante confiável.

**Mais requisições.** A fila inteira é despachada a cada tentativa, e não um lote por vez.
Numa visita saudável a fila tem zero ou um lote e nada muda; numa visita com o servidor
recusando, ela produz mais requisições em troca de recuperar mais rápido quando ele voltar.

**Dado a mais no aparelho do visitante.** Dois campos, e nenhum deles é dado NOVO sobre a
pessoa: o que eles guardam é exatamente o que já viajava no corpo despachado — gatilho
declarado, detalhe pelo alfabeto fechado, caminho de uma página deste site, carimbo relativo ao
carregamento. Os dois são removidos do aparelho na recusa, com o apelido, pela mesma chamada.

**As rotas pelas quais o contador ainda pode andar sem a linha chegar**, e todas ficam
declaradas. Nenhuma delas é silêncio: as três somam em cortadas, e as cortadas agora chegam à
tela.

1. **Recusa PERMANENTE (400 ou 413).** Só acontece se o nosso cliente produzir um corpo que o
   nosso servidor recusa — defeito do par, não condição de runtime.
2. **Lote pendente vencido**, mais velho que a janela da visita. Exige uma visita viva por mais
   tempo que a janela com o despacho falhando o tempo todo; a trava da migração, agora de um
   minuto, cabe folgadamente dentro dela.
3. **Linha que sozinha não cabe no corpo**, em `selar()`. Inalcançável na prática — uma linha
   tem cerca de 80 bytes contra um teto de 8192 —, e o ramo existe porque sem ele o laço de
   selamento não avançaria.

E duas que NÃO produzem buraco, e por isso não reprovam o invariante: o teto por travessia e o
orçamento da visita **truncam** o fim da série, e o armazenamento que passa a recusar escrita no
meio da visita faz as ocorrências **repetirem** em vez de faltarem — é a degradação declarada,
e a bancada agora sabe produzi-la.

**Como reverter.** Trocar o despacho por `sendBeacon` puro reprova o piso do envio recusado em
`js.sessao_com_releitura`, que é a mutação plantada. Parar de gravar `acumulado` reprova o piso
do carregamento que morre SEM ter selado; parar de gravar `pendentes` reprova o do que morre
DEPOIS de selar — cada um sozinho, que é como as duas mutações são plantadas. Voltar o teto do
corpo a cortar a linha em vez de selar o lote reprova o piso do teto do corpo. Tirar a reserva do selo
reprova `comportamento.lote_idempotente` nos três ramos. Voltar o transiente da migração para
quinze minutos reprova o piso da trava. Reverter não apaga o que já foi gravado no servidor: as
linhas com buraco de ocorrência continuam lá, e nenhuma migração as recupera — o dado que não
chegou não existe em lugar nenhum.

---

## 95. A seção ganha linha de saída própria, e a banda passa a ser declarada

**Decidido.** `saida=0.2` entra no limiar de `f3base_secao_vista` em
`fontes/site-core/dados/eventos-comportamento.tsv`, ao lado de `visivel=0.5`. O observador
passa a ser armado com `{ threshold: [ 0, saida, visivel ] }`. A seção **entra** quando a
razão alcança `visivel` e **rearma** quando ela cai abaixo de `saida`; entre as duas, nada
muda de estado. `saida` ausente, não numérica, negativa ou maior/igual a `visivel` volta ao
comportamento simétrico (`saida = visivel`), que é o de antes desta release.

**O que isso separa do defeito da 1.3.3.** Lá a saída era a razão ZERO e **não estava
declarada em lugar nenhum**: ela era o efeito colateral de `isIntersecting`, e ninguém podia
discordar de um número que não existia. Aqui a saída é um número no TSV, na mesma célula de
limiar do `visivel` que ela protege, revisável na mesma leitura, e a banda existe de
propósito. O argumento da decisão 90 — *"um limiar de histerese próprio seria um número que
ninguém revisaria junto com o `visivel`"* — não foi abandonado: ele foi respondido pelo LUGAR
do número.

**O que a banda faz, medido.** Com uma linha só, a razão oscilando em torno de 0,5 rearma e
reentra a cada oscilação: a seção de uma tela parada na fronteira do campo de visão fabrica
ocorrência 2, 3 e 4 sem que ninguém tenha relido nada. Com a banda, a oscilação entre 0,2 e
0,5 não muda estado nenhum, e só a passagem que de fato tirou o bloco do campo de visão volta
a contar. É a mesma disciplina do `histerese_pp` do marco, aplicada à seção.

**O QUE ELA NÃO FAZ, e isto precisa estar escrito porque foi a premissa do pedido.** A banda
NÃO passa a registrar releitura que hoje não é registrada — ela registra MENOS, nunca mais.
Uma linha de saída mais BAIXA exige um movimento MAIOR para rearmar, não menor. A hipótese de
que o problema era *"o tamanho do movimento que o rearme exige"* leva ao conserto oposto —
saída ACIMA da entrada —, e esse conserto é o que a defesa do cliente recusa: com a saída
acima da entrada, o bloco rearma enquanto ainda está mais visível do que a entrada exige, e
cada oscilação vira ocorrência até o teto por visita cortar, gravando travessias que ninguém
fez.

**E a premissa também não se sustenta na medição.** A sonda de navegador desta release rodou
o cliente 1.3.5 e o 1.3.6 nos dois percursos, no mesmo Chromium, contra a mesma página: as
sequências saíram **idênticas**. No percurso curto — o do relatório, subir três passos perto
do fim e descer de novo — as duas releases entregam `abertura [1]`, `pecas [1]`,
`comando-unico [1,2]`, `faq [1,2]`, com zero cortada. Os dois blocos do topo saem com uma
ocorrência porque **ninguém voltou a eles**; ausência de reentrada não é perda, e quem
responderia por perda é o contador de cortadas, medido em zero.

**O que custa.** Uma reentrada curta e legítima — quem tira o bloco até a razão 0,3 e o traz
de volta — deixa de ser contada. É o lado certo de errar: ocorrência perdida é um número
menor, ocorrência fabricada é um número que descreve um comportamento que não houve. E custou
uma mudança de geometria na bancada: o bloco `meio` da página curta de `js.sessao_com_releitura`
descia só até 0,4 e voltava, e com a banda ele não rearma mais. Ele foi movido para onde
CRUZA a linha declarada, e o caso que ele media virou um quarto bloco, `banda`, que oscila
entre 0,233 e 0,533 e tem de sair com UMA ocorrência. Trocar a geometria sem deixar o caso
antigo medido em algum lugar seria ajustar a bancada ao código.

**Como reverter.** Tirar `saida` do limiar faz o cliente cair no comportamento simétrico — e
reprova o teto da declaração em `js.sessao_com_releitura`, que exige a banda declarada e menor
que a entrada. Trocar `razao < saida` por `razao < visivel` no cliente reprova o piso da banda
nos dois lados: o bloco `banda` passa a contar mais de uma vez, e o percurso inteiro grava mais
linhas de interseção do que o pacote.

---

## 96. O pacote entrega JavaScript sem comentário, e o corte é por tokenizador

**Decidido.** O empacotamento passa a remover os comentários dos `.js` de
`fontes/site-core/assets/` ao montar o zip do plugin — o avulso de `dist/` e a cópia embutida,
byte a byte a mesma. **A fonte não muda.** O corte é feito por um tokenizador vendorizado em
`ferramentas/tokenizador-js.php`, e cada comentário vira UM caractere: quebra de linha quando
ele continha uma, espaço quando não. Fora isso, byte nenhum se move.

**Por quê, medido.** `assets/f3base-tracking.js` tinha 88.367 bytes brutos e 30.328
comprimidos na 1.3.5; sem comentários, 29.218 e 7.709. Dois terços do arquivo eram comentário,
e são vinte e dois quilobytes comprimidos que **todo visitante de um site de tráfego pago
baixa a cada carregamento sem ter, no navegador, um único leitor para eles**. A disciplina de
comentário deste pacote não mudou: ela existe para impedir regressão, e quem lê é quem MANTÉM
o pacote.

**POR QUE NÃO EXPRESSÃO REGULAR, e isto não é preferência.** Comentário-que-não-é-comentário
existe nestes arquivos: `'https://exemplo.test/a//b'` numa string, `/^\/\/[a-z]*$/` num literal
de regex, `/[/*]+/g` numa classe de caractere. Um corte por expressão regular apaga o miolo
deles e entrega um arquivo que **ainda analisa e faz outra coisa** — o pior defeito possível de
um empacotamento, porque é silencioso e só aparece no navegador do visitante. A fixture
negativa de `pacote.js_entregue_sem_comentario` é exatamente essa fonte plantada, com o corte
ingênuo aplicado, e o detector a acusa em dois lugares: o fluxo de tokens deixou de bater e o
`node --check` reprova.

**POR QUE VENDORIZADO, e não instalado.** Um `npm install` no empacotamento é um build que
para de funcionar sozinho no dia em que o registro sai do ar, o pacote é publicado ou a versão
some. O tokenizador viaja no pacote e é autorizado pela mesma allow-list de todo o resto.

**A REGRA QUE O DETECTOR CONFERE não é "não tem comentário"** — essa é fácil de conseguir
errado, bastando apagar bytes. É que o **fluxo de tokens significativos do entregue é idêntico
ao da fonte**, token a token, com o espaço normalizado: nada além de comentário mudou. Contar
comentários não veria o arquivo corrompido, porque ele também não tem comentário nenhum.

**AS BANCADAS PASSARAM A RODAR CONTRA O ENTREGUE.** É o ponto inteiro: um corte que corrompesse
o cliente e ninguém medisse é pior do que os vinte e dois quilobytes. A divisão é a que o
custo justifica — a checagem de FORMA (comentário, declaração, lint da árvore) continua olhando
a FONTE, onde a forma mora; a de COMPORTAMENTO olha o ENTREGUE, que é o que o navegador
executa. Isso obrigou uma correção de contrato: `fatiar()` cortava a função pura de
`\tfunction nome(` até o próximo `\t/**`, amarrando a EXTRAÇÃO a um COMENTÁRIO. Agora ela corta
até o fechamento na indentação da função — e é por isso que o corte de comentários preserva a
indentação byte a byte.

**O que custa.** Três coisas. O empacotamento passou a ter um tokenizador próprio para manter
— sem parser, sem validação, com o escopo escrito no topo do arquivo. O arquivo entregue não é
mais legível para quem abrir o `view-source` do site, o que é uma perda real para quem
diagnostica de fora; o remédio é a fonte, que viaja no bundle. E há um resíduo declarado:
`fontes/site-core/` continua viajando dentro do bundle **com** os comentários, porque é a
FONTE. Ela não chega ao visitante — `artefato_do_papel()` prefere `assets/plugins/<slug>.zip`,
que é o zip enxuto, e ele sempre existe no bundle —, mas o caminho de reserva que instala do
diretório entregaria o arquivo comentado. É peso, e não corrupção.

**Como reverter.** Tirar `assets/` de `f3b_prefixos_de_js_entregue()` faz o zip voltar a levar
a fonte inteira. Nada mais muda: as bancadas continuam achando o arquivo, porque o resolvedor
cai na fonte quando `dist/entregue/` não existe, e `pacote.js_entregue_sem_comentario` passa a
acusar o comentário no entregue — a reversão é possível e não é silenciosa.

---

## 97. A sonda de navegador entra na suíte, e a primeira coisa que ela pegou foi a bancada

**Decidido.** `navegador.comportamento_real` passa a ser checagem de primeira classe: ela roda
o cliente **entregue** num Chromium de verdade, servido por um servidor local, dirigido só por
rolagem, sobre uma página de geometria de site real — quatro seções de uma tela cada, faixa
rolável de três telas. A declaração de eventos é **gerada do TSV na hora**, pelo mesmo leitor
das bancadas; a classe de cada seção sai de `prefixoSecao`, que é a constante que o site
publica; a geometria e os dois percursos moram no próprio arquivo da sonda, e o servidor os
importa. Sem Chromium ela fecha **N/A com a condição declarada**, nunca OK.

**Por que ela existe, e a razão é uma contagem.** Quatro releases seguidas a bancada aprovou o
que o navegador reprovou: a **1.3.3** (o retorno intermediário do observador), a **1.3.4** (o
contador entre carregamentos), a **1.3.5** (três lacunas listadas na própria release) e esta.
A bancada **simula** `IntersectionObserver`; o navegador **tem** um. Nenhum comentário conserta
isso.

**E A PRIMEIRA COISA QUE ELA PEGOU FOI A PRÓPRIA BANCADA.** O piso pedido para ela era plantar
a assimetria da 1.3.3 no cliente e exigir que a sonda acusasse. Plantada como a bancada a
descrevia — `isIntersecting` com `threshold: visivel` —, a sonda **calou**: as sequências
saíram idênticas às do pacote. A causa, medida em Chromium 1194 com um alvo de uma tela:

> com `threshold: 0.5`, a razão 0,2 chega com **`isIntersecting: false`**, apesar de 20% do
> alvo estar na tela.

`isIntersecting` **não é sobreposição geométrica**. Ele sai do ÍNDICE DE FAIXA — é verdadeiro
quando a razão alcançou pelo menos a menor linha declarada. A bancada modelava
`isIntersecting: razao > 0`, que é a leitura intuitiva e o texto antigo da especificação, e com
isso ela **afirmava um defeito que não existe**: com `threshold: visivel` sozinho, decidir a
saída por `isIntersecting` dá o MESMO resultado de decidir por `razao < visivel`.

O defeito de verdade depende do `0` na lista de faixas: com ele, qualquer sobreposição mantém
`isIntersecting` verdadeiro, a linha de saída vira a razão ZERO, e o bloco que nunca sai
inteiro da tela não rearma nunca. É esse o mutante que os dois pisos plantam agora — na bancada
e no navegador —, e no navegador ele é acusado nos dois percursos: `pecas` e `comando-unico`
caem de `[1,2,3]` para `[1,2]` no longo, e `comando-unico` e `faq` caem para `[1]` no curto.

**O que a checagem afirma.** As sequências de ocorrência por gatilho nos dois percursos; zero
erro de página; zero acionamento cortado; e que o lote **chegou ao servidor** — despachar não é
entregar. O percurso longo é a leitura inteira; o curto é o do relatório do usuário, e nele os
blocos do topo saem com UMA ocorrência, o que está certo: ninguém voltou a eles.

**O que custa.** A rodada passou de dois segundos e meio para cerca de quarenta: são quatro
carregamentos de Chromium, dois pelo pacote e dois pelo mutante do piso. E a suíte ganhou uma
dependência de ambiente que ela não tinha — Chromium e `playwright` —, com o preço declarado:
onde eles não existem, a linha fecha N/A nomeando o que falta, e um pacote verificado sem
navegador não é um pacote aprovado.

**Como reverter.** Apagar `suite/sonda-navegador/` e a emissão em `executar.php` devolve a
suíte ao estado anterior — e devolve também a cegueira que quatro releases pagaram. A
correção do modelo de `isIntersecting` na bancada é independente e fica: ela vale mesmo sem a
sonda.

---

## 98. O plugin deixa de ser construído pelo implantador e vira artefato próprio

**Decidido.** `f3base-site-core` passa a se chamar **`Base Site Core Fator3`**, pasta
`base-site-core-fator3`, arquivo principal `base-site-core-fator3.php`, e a numeração dele
**recomeça em `1.0.0`**. Ele deixa de ser construído pelo implantador: é artefato único, com
identidade única, publicado como zip e instalado em qualquer site desta operação como qualquer
outro plugin de catálogo. A fonte dele sai de `fontes/site-core/` para `fontes/plugin/`, e
**não viaja mais dentro do bundle do implantador** — o bundle leva só
`assets/plugins/base-site-core-fator3-<versão>.zip`.

**Por quê, e o defeito é medido.** `ferramentas/renomear-prefixo.php` varria a raiz inteira do
pacote e renomeava **também** `fontes/site-core/`: slug do plugin, prefixo das classes, prefixo
das options, text domain. Ou seja: cada site produzia um **fork** do plugin, com options
`<prefixo>_ga4_measurement_id` em vez de `f3base_ga4_measurement_id`. Um plugin com release
própria cujo nome de option muda por site não é um plugin — são N plugins parecidos, e nenhuma
correção publicada alcança nenhum deles. O fork era silencioso: cada site ficava internamente
coerente, e só a operação inteira ficava incoerente.

**POR QUE A NUMERAÇÃO RECOMEÇA, e por que isso fica escrito.** Herdar o `1.3.7` afirmaria que
este é o mesmo artefato de antes com uma correção a mais. Ele não é: o que mudou foi o que ele
**é**. O `1.0.0` é a afirmação de que a série `1.3.x` pertence a outro objeto — um plugin que
o implantador montava — e de que a série nova pertence a um artefato que se publica sozinho.
Quem estiver na série antiga não "atualiza": migra, e a migração está na decisão 100.

**O QUE NÃO MUDOU, E É A METADE QUE IMPORTA.** O prefixo interno `f3base` continua exatamente
como está: nomes de option (`f3base_ga4_measurement_id`, `f3base_comportamento`, …), nomes das
tabelas (`f3base_comportamento`, `f3base_eventos`, `f3base_leads_dedup`), nomes de evento
(`f3base_rolagem`, `f3base_secao_vista`, …), namespace REST (`f3base/v1`), prefixo das classes
PHP e text domain. Essas chaves **apontam para dado vivo** em sites que já rodam. Renomear a
option orfana o valor sem apagar nada e sem erro nenhum; renomear a tabela apaga a série
histórica; renomear o evento quebra a série na conta de medição do fornecedor, onde não há
reparo depois. **Nome de pasta é endereço; nome de option é chave de dado.** Trocar o primeiro
é grátis, trocar o segundo é perda de dado calada.

**AS CONSTANTES VIRARAM `F3BASE_PLUGIN_*`, e a versão passou a sair do cabeçalho.** As antigas
`F3BASE_SITE_CORE_VERSAO`, `_DIR`, `_URL`, `_ARQUIVO`, `_PHP_MINIMO` são símbolos, não chaves de
dado: renomear é grátis e o nome antigo apontava para um artefato que mudou de nome. Junto veio
uma correção que não estava no roteiro: `F3BASE_SITE_CORE_VERSAO` era um LITERAL `'1.3.5'` ao
lado de um cabeçalho que dizia `Version: 1.3.6`. As duas eram verdadeiras isoladamente e ninguém
acusava — é exatamente a armadilha que o MANIFESTO descreve para o tema. Agora a constante sai
de `get_file_data()` sobre o próprio cabeçalho.

**A FONTE DO PLUGIN NÃO VIAJA, e isso fecha um resíduo declarado na 1.6.6** (decisão 96, último
parágrafo do custo). Com o plugin desacoplado, entregar a fonte dele dentro do bundle seria
entregar uma cópia que ninguém deve editar e que diverge da release publicada no instante
seguinte — e era essa cópia que dava à renomeação algo para renomear. `pacote.plugin_so_como_zip`
confere no ARTEFATO montado, pela lista de entradas do zip, que nenhum caminho
`implantador-base/fontes/plugin/` viaja e que a reserva viaja.

**A FONTE FICA A DOIS NÍVEIS DA RAIZ, e o nome do diretório mudou mas a PROFUNDIDADE não pode
mudar.** `fontes/plugin/` e não `plugin/`: um arquivo com `Plugin Name:` a UM nível da raiz do
pacote está dentro do alcance de `get_plugins()`, a tela de instalação ordena por Name, e o
link "Ativar plugin" passa a apontar para um caminho de dois níveis que `validate_plugin()` não
enxerga — o defeito medido que `pacote.sem_cabecalho_de_plugin_aninhado` guarda desde a 1.0.x.

**O que custa.** Três coisas, e nenhuma é pequena. (1) O nome do zip publicado mudou: quem
publica no GitHub precisa subir `base-site-core-fator3.zip` no endereço declarado em
`config/decisoes.tsv`; o `f3base-site-core.zip` antigo deixa de ser lido por alguém. (2) A
pasta `fontes/plugin/` do repositório **não é instalável como está** — faltam cinco arquivos,
que são o contrato compartilhado e entram no zip pela cópia do empacotamento (decisão 99); é
aceitável porque o plugin é artefato construído, e `pacote.plugin_completo_no_zip` confere o
zip contra a lista de autoload em toda rodada. (3) O bundle ficou com um artefato a mais para
manter coerente — a reserva —, e `pacote.reserva_identica_ao_avulso` prova, por sha256 sobre a
cópia extraída do bundle, que ela é byte a byte o zip publicado.

**Como reverter.** Tirar `fontes/plugin/` de `f3b_fora_do_bundle()` devolve a fonte ao bundle;
tirar as duas linhas de `ferramentas/excecoes-de-prefixo.tsv` devolve o plugin à renomeação. As
duas reversões são possíveis e **não são silenciosas**: `renomeacao.plugin_intacto` e
`pacote.plugin_so_como_zip` passam a reprovar, cada uma nomeando o que está em jogo.

---

## 99. O contrato compartilhado ganha casa própria, e a dependência muda de sentido

**Decidido.** As quatro regras que os dois runtimes leem — `F3Base_Chaves_Seo`,
`F3Base_Vocabulario`, `F3Base_Emissores`, `F3Base_Censo_Demonstrativo` — e a declaração
`emissores-conhecidos.tsv` saem de dentro da fonte do plugin e passam a morar em
`partilhado/`, no mesmo caminho relativo que terão dentro do plugin. O empacotamento copia
`partilhado/` para dentro do zip do plugin; o implantador lê de `partilhado/` quando o plugin
ainda não existe na instalação, e do **plugin instalado** quando ele existe.

**Por quê.** A dependência estava no sentido errado, e era ela que sustentava o acoplamento que
a decisão 98 desfaz: o IMPLANTADOR alcançava para dentro da árvore do PLUGIN para carregar
regras de que precisa **antes** de o plugin existir — o preflight roda antes de instalar
qualquer coisa. Enquanto essa leitura existisse, a fonte do plugin **tinha** de viajar dentro
do bundle, e enquanto ela viajasse, a renomeação tinha o que renomear. Mover o contrato para um
lugar neutro corrige a causa; excluir o diretório da renomeação teria corrigido só o sintoma.

**Uma cópia de cada lado foi recusada, e o motivo é o de sempre:** duas cópias da mesma regra
divergem na primeira condição acrescentada, e divergem em silêncio — quem ESCREVE a meta e quem
a LÊ passariam a usar nomes diferentes sem que nada acusasse.

**O que custa.** A pasta `fontes/plugin/` deixa de ser instalável por cópia: cinco arquivos do
autoload dela só existem depois do build. É o mesmo tipo de custo que a decisão 96 já pagou —
lá o entregue difere da fonte por não ter comentário, aqui difere por ter cinco arquivos a
mais —, e ele é coberto por `pacote.plugin_completo_no_zip`, cujo piso planta a ausência de um
arquivo do autoload dentro do zip.

**Como reverter.** Mover os cinco arquivos de volta para `fontes/plugin/` e fazer
`carregar_do_site_core()` apontar para lá. A reversão traz de volta a obrigação de a fonte do
plugin viajar no bundle, e `pacote.plugin_so_como_zip` passa a reprovar — a reversão é
possível e não é silenciosa.

---

## 100. Duas cópias do mesmo plugin ativas não podem existir, e quem resolve é a ativação

**Decidido.** Ao ATIVAR, `Base Site Core Fator3` procura outras cópias ATIVAS de si mesmo e as
**desativa**, registrando o que fez num transiente que a tela lê uma vez e apaga. O
discriminante não é o nome da pasta: é o arquivo principal do plugin ativo **declarar o mesmo
namespace REST** (`F3BASE_REST_NAMESPACE`), lido nos mesmos 8 KiB que `get_file_data()` lê.

**Por quê, e o caso é real.** Existe pelo menos um site em produção com o plugin na pasta
antiga (`f3base-site-core`, 1.3.6). Instalar a pasta nova ali produz **duas cópias do mesmo
plugin ativas ao mesmo tempo**: dois registros de hooks, dois `register_rest_route` para o
mesmo endereço, dois coletores enfileirados na mesma página, contagem em dobro na conta de
medição. O WordPress não impede isso e não avisa — não aparece como erro, aparece como número
errado semanas depois, sem nada que aponte para a causa.

**NÃO HÁ DADO A MIGRAR, e é exatamente por isso que o prefixo interno não mudou.** As options
são as mesmas `f3base_*` e as tabelas são as mesmas `f3base_comportamento`,
`f3base_eventos` e `f3base_leads_dedup`. A cópia nova encontra a configuração do site inteira,
no lugar onde ela sempre esteve. O que mudou foi o **endereço** do código, e endereço não
guarda dado.

**POR QUE DESATIVAR A OUTRA, E NÃO RECUSAR ATIVAR ESTA.** A alternativa foi considerada e é
pior por três razões. (1) Recusar deixa o site rodando a cópia ANTIGA — o artefato que esta
release existe para substituir — e transfere a correção para alguém ler uma mensagem; a
instalação é feita pelo implantador, sem ninguém olhando, e a mensagem chegaria a um relatório
enquanto o site seguiria como estava. (2) O dano das duas cópias já existe no instante da
ativação, e recusar não o desfaz: ele apenas não fica pior. Desativar a antiga é a única ação
que devolve o site a UMA cópia. (3) Desativar plugin alheio seria atrevimento — mas este não é
alheio: é uma cópia mais velha DESTE MESMO plugin, reconhecida pela reivindicação do mesmo
namespace, e o WordPress não tem como servir as duas.

**O HOOK DE DESATIVAÇÃO DA CÓPIA ANTIGA NÃO RODA**, e a escolha é medida: aquele hook
desinstala os módulos — desagenda a cadência, remove regras de reescrita — e são os MESMOS
agendamentos e as MESMAS regras que a cópia nova acabou de instalar, porque as chaves são as
mesmas. Rodá-lo desfaria a ativação em curso e deixaria o site com o plugin ativo e a cadência
desagendada, calado.

**O que custa.** Um plugin ativo é desativado sem que ninguém tenha clicado, e isso é uma
mudança de estado do site feita por nós. O custo é contido por três limites escritos no código:
nada é apagado do disco, nenhuma option e nenhuma tabela é tocada, e a ação é **reversível por
um clique**. E ela é registrada: o aviso nomeia o arquivo desativado e diz por quê.

**O piso é o falso positivo, que aqui é o dano maior.** `migracao.copia_anterior_desativada`
monta um `wp-content/plugins/` de verdade em disco e roda a função REAL contra ele: plugin de
terceiro ativo não é tocado; um plugin cujo NOME parece o da cópia velha mas que não traz a
marca não é tocado; cópia velha INATIVA não é tocada; e num site só com a cópia nova nada é
desativado e nada é registrado.

**Como reverter.** Remover a chamada de `desativar_copias_do_mesmo_plugin()` em `ativar()`
devolve o comportamento anterior — e devolve junto o silêncio das duas cópias ativas, que é o
que esta decisão existe para impedir.

---

## 101. O que a renomeação de prefixo NÃO toca vira regra declarada, em dois arquivos

**Decidido.** A renomeação de prefixo passa a ter duas listas declaradas, cada uma com o motivo
por linha, e nenhum `if` escondido:

- `ferramentas/excecoes-de-prefixo.tsv` ganha `fontes/plugin/` e `partilhado/` — **caminhos que
  a ferramenta não atravessa**;
- `fontes/plugin/dados/contrato-de-nomes.tsv` — **grafias que sobrevivem em qualquer arquivo**,
  inclusive nos que SÃO renomeados.

**Por que as duas, e não só a primeira.** Excluir o caminho resolve metade. O IMPLANTADOR
continua sendo renomeado, e é ele quem GRAVA as options que o plugin LÊ, quem agenda o hook que
o plugin ouve e quem chama as classes compartilhadas pelo nome. Com só a exclusão de caminho, o
site ficaria com o implantador gravando `acme_ga4_measurement_id` e o plugin lendo
`f3base_ga4_measurement_id` — **pior** que o fork, porque o fork ao menos era internamente
coerente.

**A SEGUNDA LISTA É DERIVADA, E A TABELA SOZINHA NÃO BASTAVA.** A primeira tentativa desta
release preservou só as grafias escritas à mão no contrato, e o pacote renomeado mostrou o
tamanho real da fronteira em três camadas: `suite/inventario.tsv` foi reescrito e o
empacotamento **abortou** com trinta arquivos "FORA DO INVENTÁRIO"; o implantador passou a
gravar `acme_operaveis` enquanto o plugin continuava lendo `f3base_operaveis`; e as bancadas de
JavaScript passaram a procurar o handle `acme-tracking` num cliente que se registra como
`f3base-tracking`. Foram **quatorze** checagens em FALHA no pacote renomeado. A regra que
resolve é uma frase só, e ela é derivada de disco em
`ferramentas/nomes-preservados.php`: **o plugin não é renomeado, então tudo que ele escreve
continua escrito assim** — nome de arquivo, de classe, de handle, de atributo de DOM, de classe
de CSS, de variável de JavaScript, de código de erro, de option, de tabela e de evento. São 321
grafias, e nenhuma delas é digitada.

**O QUE A DERIVAÇÃO NÃO PRESERVA é o que a mantém honesta:** a grafia NUA do prefixo, e a nua
com um separador colado. `f3base` sozinho continua sendo trocado, e `f3base-` também — o plugin
monta nomes em tempo de execução (`'f3base-' . $sufixo` para um transiente), e preservar aquele
token fazia TODO caminho do pacote que começasse por `f3base-` sobreviver: medido, a renomeação
caiu de 154 caminhos para UM. É por isso que `estatica.sem_residuo_de_prefixo` continua tendo
dentes: um arquivo que a ferramenta esqueceu carrega `F3Base_Imp_Plugins` ou um `f3base` nu no
caminho, nenhum dos dois está no vocabulário do plugin, e ele aparece.

**A TABELA DECLARADA CONTINUA EXISTINDO**, e por duas razões: a derivação não alcança o que não
tem forma de identificador (`f3base/v1` tem uma barra), e ela é onde o MOTIVO de cada grafia
está escrito. A derivação é mecânica; a declaração é o que se lê.

**A EXCEÇÃO QUE A EXCLUSÃO CRIOU, e como ela foi resolvida.** A classe que marca seção medida é
`f3base-secao-<nome>`, carimbada pelos **patterns do tema** e pelo **conteúdo** — os dois
renomeados — e procurada pelo **coletor do plugin**, que não é. Com o tema carimbando
`<prefixo>-secao-abertura` e o plugin observando `f3base-secao-`, o observador é instalado, não
recebe alvo nenhum, e a medição de seções morre calada em todo site renomeado: o evento
`f3base_secao_vista` continua declarado, continua ocupando linha no relatório, e responde
"nada" para sempre. A saída é a que o problema já indicava: **o prefixo de seção é contrato do
PLUGIN, não identidade do site.** Ele fica `f3base-secao-` em todo lugar e está no contrato de
nomes. Não é decisão de estilo — o tema estiliza `f3base-faixa-escura`, que É identidade e É
renomeada; `f3base-secao-` não aparece em CSS nenhum, é marca de medição, e marca de medição
pertence a quem mede.

**A PRESERVAÇÃO É POR MÁSCARA, e não por uma entrada identidade no mapa.** `str_replace()` com
arrays aplica cada par sobre o texto INTEIRO, um depois do outro: um par
`f3base-secao- => f3base-secao-` não protegeria nada, porque a substituição seguinte
(`f3base => acme`) voltaria a encontrar o que a primeira acabou de reescrever igual. A máscara
tira a grafia do texto antes de qualquer substituição e a devolve depois — é a única forma de o
resultado não depender da ordem do mapa. O sentinela é `\0<índice>\0`: byte nulo porque nenhuma
extensão de texto declarada o carrega, e só dígitos no meio porque toda grafia do mapa é de
letras.

**O CONTRATO NÃO É LISTA ESCRITA À MÃO QUE NINGUÉM CONFERE.**
`renomeacao.contrato_de_nomes_completo` deriva o que ele precisa cobrir do **catálogo de options
do próprio plugin** e da **declaração de eventos de comportamento**, e reprova o que falta. Sem
isso, a primeira option nova acrescentada ao plugin voltaria a ser reescrita pela renomeação, e
o defeito voltaria calado exatamente onde estava.

**O que custa.** Um site derivado deste template carrega, para sempre, grafias `f3base_*` que
não são o prefixo dele: nas options do plugin, nas tabelas, nos eventos e na classe de seção. É
uma inconsistência visível para quem abre o banco, e ela é o preço de o plugin ser **um**
artefato. A alternativa — cada site com o próprio nome de option — é exatamente o defeito que
esta release corrige.

**Duas correções vieram junto, e as duas são de piso.** A fixture negativa de
`estatica.option_gravada_sem_leitor` plantava a option `f3base_cadencia`, que é do PLUGIN e
portanto preservada: no pacote renomeado ela caía FORA do escopo do detector — que delimita
pelo `site.prefixo_tecnico` — e o piso negativo deixava de acusar. O literal virou
`f3base_piso_da_cadencia`, que é do namespace do implantador e acompanha a renomeação; o
defeito narrado continua sendo o de 1.0.17. E a fixture de
`pacote.js_entregue_sem_comentario` usava o símbolo `f3baseArmadilhaDeStrip`: no pacote
renomeado o arquivo solto era reescrito e o zip da fixture, que é binário, não — e o piso
positivo passava a acusar o caso correto. Esse já reprovava na 1.6.6, e só aparecia para quem
rodasse o piso sobre um pacote renomeado.

**Como reverter.** Apagar `fontes/plugin/dados/contrato-de-nomes.tsv` faz a ferramenta RECUSAR
renomear, com a razão escrita: renomear sem o contrato é pior do que não renomear. Remover
também a recusa e neutralizar a derivação de `ferramentas/nomes-preservados.php` devolve o
comportamento da 1.6.6 — e é exatamente o par de mutantes que os pisos de
`renomeacao.plugin_intacto` e `renomeacao.secao_medida_apos_renomear` plantam, em toda rodada.

---

## 102. O arquivo em que uma chave mora passa a ser DERIVADO da chave

**Decidido.** Nenhuma mensagem de runtime do implantador digita o nome de um arquivo de
configuração. Quem responde "em que arquivo esta chave mora" é um produtor único novo,
`F3Base_Imp_Residencia`, que cruza o que cada leitor DECLARA — `F3Base_Imp_Projeto` e
`F3Base_Imp_Config` — e devolve o arquivo, dois arquivos, ou nenhum. Nem o nome dos
arquivos é escrito lá dentro: ele sai da constante `ARQUIVO` de cada leitor.

**O que foi medido.** Numa instalação limpa, o relatório imprimiu:

> pré-condição ausente: 3 chave(s) de `contato.controlador` está(ão) vazia(s) **em
> config/site.json** — `contato.controlador.razao_social`, `contato.controlador.documento`,
> `contato.controlador.endereco`. … Caminho de saída: preencha … **em config/site.json** e
> execute de novo

`contato.controlador` **não existe** em `config/site.json`. Ele mora em
`config/projeto.json`, que é o único arquivo que o operador abre. Quem seguisse a
instrução editaria o arquivo errado, as chaves não passariam a existir, a política de
privacidade ficaria em `draft` para sempre e a convergência nunca fecharia. **A mensagem
que existe para desbloquear o operador era a que o prendia.**

**A causa não era a frase.** O nome do arquivo estava DIGITADO dentro da mensagem: um
fato sobre o pacote escrito à mão num texto que nada revalida — a mesma família de defeito
que este pacote recusa em toda parte (versão repetida em constante, decisão copiada como
padrão de leitura, contrato de copy congelado no banco). Migrar uma chave de arquivo é uma
edição de JSON, e cada mensagem que a citasse continuaria dizendo o arquivo antigo, verde,
para sempre. Corrigir só a frase deixaria a próxima migração reabrir o buraco.

**As ocorrências conferidas, uma a uma.** `config/site.json` aparecia em sete arquivos de
`includes/`. Cada uma foi conferida contra o arquivo em que a chave citada realmente mora:

| Onde | Veredito |
|---|---|
| `class-f3base-imp-conteudo.php` · `saida_da_guarda_do_controlador()` | **ERRADA** — `contato.controlador.*` mora em `config/projeto.json`. Derivada. |
| `class-f3base-imp-conteudo.php` · `veredito_do_controlador()`, ramo BLOCKED | **ERRADA** — a mesma chave. Derivada. |
| `class-f3base-imp-lotes.php` · `veredito_destino()`, ramo N/A | **ERRADA** — o destino do regime é entrada de `formularios[]`, lida por `F3Base_Imp_Projeto`. Derivada. |
| `class-f3base-imp-lotes.php` · `veredito_destino()`, `@param $caminho` | **ERRADA** — mesma causa, no documento da função. Corrigida. |
| `class-f3base-imp-lotes.php` · `veredito_de_convergencia()` | **ERRADA por construção** — ela recebe NOMES de pré-condição, não caminhos de chave, e pré-condições diferentes moram em arquivos diferentes. Deixou de nomear arquivo: manda ler a linha, que traz o caminho. |
| `class-f3base-imp-lotes.php` · `texto_de_encerramento()` | **ERRADA pela mesma razão.** Mesma saída. |
| `class-f3base-imp-lotes.php` · `emitir_controlador_identificado()`, ação do operador | **CERTA** (`config/projeto.json`) — e derivada assim mesmo: frase certa escrita à mão continua sendo fato que nada revalida, e a linha irmã, escrita do mesmo jeito, era a que apontava para o arquivo errado. |
| `class-f3base-imp-lotes.php` · ação do operador do WhatsApp | **CERTA** (`config/projeto.json`) — derivada pela mesma razão. |
| `class-f3base-imp-entrega.php` · `artefatos()` | **CERTA** — é a lista de arquivos que PROVA o entregável, e `config/site.json` é um arquivo do pacote. Nenhuma chave é citada. |
| `class-f3base-imp-config.php` · `const ARQUIVO` | **CERTA** — é a identidade do próprio leitor, e passou a ser a FONTE de onde os outros derivam. |
| `class-f3base-imp-gravador.php`, `class-f3base-imp-plugins.php`, `class-f3base-imp-lotes.php` (três comentários) | **CERTAS** — `conteudo.demonstrativo`, `copy_contrato.*` e a ausência de `release.site_core` são fatos verdadeiros sobre `config/site.json`, e são comentários, não mensagens. |

**Uma chave que não morava em lugar nenhum.** A cadência lia
`F3Base_Imp_Projeto::obter( 'mecanismo_de_cadencia' )` e a mensagem mandava preencher
`cadencia_relatorio.mecanismo` — o nome que a chave tinha ANTES de migrar para o arquivo do
projeto. O operador procurava, no arquivo certo, uma chave que não existe em arquivo
nenhum. As duas passaram a sair de uma variável só.

**O `site-core` não muda, e o zip dele não muda.** O plugin fala dos arquivos do
implantador **de fora** e, ao contrário do que a suspeita inicial supunha, ele os LÊ:
`F3Base_Config_Mcp` é a habilidade que devolve e grava `config/projeto.json` e
`config/site.json`, cada um com o schema certo. As menções dele a `config/site.json` são
todas verdadeiras — ou são a própria habilidade nomeando o arquivo que lê, ou são a
declaração NEGATIVA de que o token da Conversions API não viaja ali. Nenhum arquivo de
`fontes/plugin/` foi tocado, e o conteúdo do zip do plugin é byte a byte o da 1.7.0.

**A checagem, com teto e piso.** `estatica.residencia_de_chave_derivada` tem duas
cláusulas, porque uma sozinha seria cega: **(1)** em `includes/`, nenhuma string traduzível
pode conter o caminho de um arquivo de configuração — é esta que pega o defeito medido, em
que a chave chegava por `%s` e nem aparecia na frase; **(2)** fora do implantador, string
que nomeia um arquivo E um caminho pontilhado que é chave declarada precisa nomear o
arquivo em que essa chave está. Os nomes dos arquivos saem da constante `ARQUIVO` de cada
leitor, nunca digitados no detector. O piso planta a mensagem do log real —
`preencha %s em config/site.json` com `contato.controlador` morando no outro arquivo — e
exige a acusação; e planta, do lado do `site-core`, uma chave nomeada ao lado do arquivo
errado. `config.residencia_derivada` fecha o runtime: prova que o produtor acerta chave do
operador, chave de conteúdo, destino de regime, mecanismo da cadência e índice numérico na
forma normalizada, e que chave sem residência **não recebe palpite** — a frase dela não
nomeia arquivo nenhum.

**O que custa.** Uma classe a mais, e uma leitura a mais de `config/projeto.json` em
requisições que só falavam com a configuração. O custo real é outro: as mensagens
dependem agora do arquivo do projeto ser legível. Se ele não for, a frase degrada para "no
arquivo de configuração em que ela estiver declarada" — que não nomeia arquivo nenhum e
continua verdadeira. Preferir isso a um palpite é a decisão.

**O que ele não mede, declarado.** Caminho pontilhado que não é chave declarada é
ignorado: `mcp.autoteste` e `privacidade.controlador_identificado` são nomes de checagem, e
proibi-los calaria toda mensagem que diz de qual linha fala. E a segunda cláusula não lê
negação — uma frase que dissesse "a chave X não existe em `config/site.json`" seria acusada
mesmo estando certa. Ela não existe nesta árvore, e a saída, se um dia existir, é nomear o
arquivo em que a chave ESTÁ.

**Como reverter.** Trocar `F3Base_Imp_Residencia::onde_preencher()` de volta por um literal
em qualquer das mensagens. É exatamente o mutante que o piso negativo de
`estatica.residencia_de_chave_derivada` planta, em toda rodada.

---

## 103. O autoteste do canal deixa de procurar a Abilities API por uma função que não existe

**Decidido.** O despacho de `files/selftest` passa a usar a Abilities API **como ela é**:
`wp_get_ability()` e o método `WP_Ability::execute()`, com `check_permissions()` antes.
`wp_execute_ability()` continua aceita como via a mais, para o host que a tiver, mas deixa
de ser a CONDIÇÃO de o caminho existir.

**O que foi medido, e a medição é do fornecedor instalado.** Em toda instalação limpa
`mcp.autoteste` fechava **BLOCKED** com: *"a rota está registrada como HABILIDADE e não
como rota REST casável neste host, e a Abilities API não a despachou nesta execução: não
sobrou namespace REST para montar o caminho do despacho."* Como a linha é do gate de
aplicação, `mcp.canal_exposto` fechava BLOCKED atrás dela, **o implantador não se
autodesativava**, e toda instalação limpa terminava assim.

A pergunta era se isso é limitação do servidor MCP instalado ou o implantador procurando o
despacho pelo caminho errado. Foi medido no host, pelo próprio canal:

- `discover-abilities` lista a habilidade com o nome **exato** `files/selftest` — a regra
  de casamento do implantador acerta esse nome, então não é o casamento;
- o índice REST do site (`/wp-json/`) tem 323 rotas em 15 namespaces e **nenhuma**
  `/files/*` nem `/db/*` — logo `rotas_registradas()` devolve vazio e o namespace é `''`,
  como a mensagem dizia;
- `includes/Compat/AbilitiesApi.php` do `wp-mcp-ultimate` 2.1.0 (sha256
  `f99a2c44…`) — o polyfill que espelha a API nativa do 6.9 — expõe
  `wp_register_ability()`, `wp_unregister_ability()`, `wp_get_ability()`,
  `wp_get_abilities()`, `wp_has_ability()` e as de categoria. **Não existe
  `wp_execute_ability()`.** A execução é `WP_Ability::execute( $input )`, com
  `check_permissions( $input )` ao lado.

**O veredito: era do implantador.** A guarda `function_exists( 'wp_execute_ability' )` era
falsa **sempre** — a função não existe na API, nem na nativa nem no polyfill. O laço
inteiro do despacho por habilidade ficava morto e a execução caía no ramo "sem via",
enquanto a PRESENÇA, medida por `wp_get_abilities()`, via a habilidade registrada. Duas
funções da mesma API, uma existente e outra inventada. Nada a reclassificar: não é
limitação de fornecedor, e por isso a linha **não** vira N/A de fase.

**Uma segunda cópia veio junto.** A regra de casamento entre nome de habilidade e rota
curta vivia escrita duas vezes — uma decidindo a presença, outra decidindo a execução. É a
mesma forma do desencontro da 1.0.8, que pôs "rota registrada" numa linha e "rota ausente"
em outra do mesmo relatório. Agora ela mora em `F3Base_Imp_Entrega::casa_habilidade()`, com
teto e piso nas três grafias observadas e nos casos que **não** podem casar.

**A afirmação do manifesto era vacuosa, e virou medida.** `suite/afirmacoes.tsv` provava
"o autoteste do canal é despachado de verdade" procurando a string `wp_execute_ability(`
no código — isto é, provava a existência de uma chamada que nunca podia rodar. O
argumento passou a ser `$objeto->execute( array() )`, que é a via que responde.

**O que custa.** Uma chamada a mais (`check_permissions()`) antes de cada execução, e uma
diferença de comportamento entre o núcleo 6.9 — que confere permissão dentro de
`execute()` — e o polyfill, que não confere. Perguntar explicitamente faz as duas
implementações darem a mesma resposta, e recusa por permissão cai no ramo BLOCKED que já
existia para credencial, nunca em FALHA do canal.

**Como reverter.** Devolver a guarda `if ( function_exists( 'wp_execute_ability' ) ) {
foreach`. É o mutante que o piso de `mcp.autoteste_veredito` planta, junto com a ausência
de `wp_get_ability(`.

---

## 104. Afirmação de documento sobre chave AUSENTE deixa de passar como "vazia"

**Decidido.** As regras `config.vazio` e `projeto.vazio` de `suite/afirmacoes.tsv` passam a
distinguir **ausente** de **vazio**: caminho não declarado no arquivo vira ERRO da
afirmação, e nunca "sim".

**O que foi medido.** As duas regras liam `null` — o valor de um caminho inexistente — como
vazio. Duas linhas da tabela viviam disso, e as duas apontavam para caminhos que não
existem em arquivo nenhum: `cadencia_relatorio.mecanismo`, que virou
`mecanismo_de_cadencia` ao migrar para o arquivo do projeto, e
`cabecalhos.origem_confiavel.cabecalho`, que nunca teve o prefixo `cabecalhos.`. O README
mandava o operador procurar dois caminhos inexistentes, e o detector que existe **para
pegar documento mentindo** dizia que estava tudo certo — porque ausente e vazio davam o
mesmo "sim". É o mesmo defeito da 102 pelo outro lado: lá a mensagem afirmava o arquivo
errado, aqui a prova aprovava o caminho inexistente.

**O que custa.** Uma afirmação sobre uma chave que o pacote decidiu REMOVER passa a
reprovar em vez de aprovar em silêncio — que é o comportamento certo, e obriga a corrigir a
frase do documento junto com a remoção.

**Como reverter.** Devolver `null === $valor` ao teste de vazio nas duas regras. As duas
linhas corrigidas voltam a passar sobre caminhos que não existem.

---

## 105. O carimbo de cada acionamento é o instante dele, e não a hora em que o lote chegou

**Decidido.** O cliente passa a enviar a **origem temporal do carregamento** — uma vez por lote,
dentro do lote SELADO — e o servidor grava `criado_em` de cada linha do registro como
`origem + ms`, em vez de `time()`. A origem do visitante passa por uma **guarda do relógio**; o
que não passa cai numa **âncora derivada do servidor** (`chegada − maior ms do lote`). Qual das
duas âncoras carimbou cada linha vira **coluna** (`ancora`), com três valores fechados, e a tela
diz isso. As linhas já gravadas **não são reescritas**.

**O que foi medido.** No banco de um site em produção, agrupando `wp_de3awa_f3base_eventos` por
`criado_em`:

```
criado_em    linhas  ms_min  ms_max  janela_ms
1788610945      33     724   10816      10092
1788610820       7   35732   37231       1499
1788610688      12     925    4122       3197
```

Trinta e três acionamentos espalhados por dez segundos de navegação, todos gravados no MESMO
segundo. Na tela, as vinte e cinco linhas da primeira página saíam todas com `09:22:25` na coluna
Horário. `registrar_evento()` gravava `'criado_em' => time()`, que é o instante em que o LOTE
CHEGOU ao servidor — e um lote carrega dezenas de acionamentos acumulados ao longo de segundos ou
minutos de navegação.

**A leitura de quem relatou estava errada e o sintoma era real.** O relato foi *"a tela altera a
linha anterior em vez de incluir uma nova, e isso só acontece quando um trigger inédito dispara"*.
As linhas SEMPRE foram distintas, cada uma com `id` próprio, e nada nunca foi reescrito. Mas
indistinguíveis no tempo elas parecem a mesma linha; e como o lote só parte quando algo novo
acontece, o bloco inteiro só aparece quando um gatilho novo dispara. As duas frases descreviam
exatamente o que a tela mostrava. **O defeito era nosso.**

**E a coluna `ms` estava gravada, certa, e não era usada para nada.** Ela existe desde o pedido
literal: *"Inclua também o horário de disparo de cada trigger, para podermos entender o tempo que o
visitante levou para percorrer a página."* Guardávamos o dado e mostrávamos outro.

**Por quê a origem viaja dentro do SELO.** Um lote que não conseguiu ser entregue fica na fila
pendente e parte no carregamento SEGUINTE, que tem outra origem — a dele. Lida na hora do despacho,
a origem seria a da página errada, e as linhas do lote retomado sairiam carimbadas no futuro delas.
Selado é imutável pela mesma razão que as linhas: a retentativa leva o mesmo corpo sob o mesmo selo.

**Por quê a guarda do relógio, e onde os limites moram.** A origem vem do aparelho de quem navegou.
Origem ausente, não numérica, no futuro além de `TOLERANCIA_RELOGIO_MS` (cinco minutos: a folga que
cobre o aparelho sem sincronização de rede e a latência entre carregamento e despacho) ou mais
velha que a janela de retenção do registro **não** é usada. Os dois limites são decisões de pacote e
moram onde as outras do plugin moram — constante com motivo escrito, ao lado de `MAX_MS`,
`MAX_EVENTOS` e `MAX_BYTES` —, e o segundo NÃO ganhou número próprio: ele é
`f3base_comportamento.retencao_eventos_dias`, porque uma origem além dela gravaria uma linha que a
próxima poda apaga, e dois números divergiriam na primeira vez que alguém mexesse num só.

**O limite da segunda âncora está escrito.** `chegada − maior ms do lote` dá o mesmo espaçamento
relativo sem confiar em relógio nenhum. Mas um lote entregue com atraso chega muito depois de ter
sido selado: **a ORDEM e o ESPAÇAMENTO ficam certos nos dois caminhos; o ABSOLUTO só é exato no
primeiro.** Prometer o absoluto nos dois seria a documentação mentindo sobre a medição.

**Por quê a procedência é COLUNA, e não contador nem linha de diagnóstico.** A pergunta "quanto vale
este horário?" é de CADA LINHA, e as três qualidades convivem na mesma tela: um site que sobe hoje
tem linha da chegada ao lado de linha do visitante ao lado de linha do servidor. Um contador diria
quantas são de cada tipo e não diria QUAL linha é qual — que é exatamente o que quem lê a tabela
precisa saber. A coluna custa uma migração, que o pacote já sabe fazer e já cobra
(`migracao.sobre_site_existente` deriva o conjunto do que é novo por EXECUÇÃO, e a coluna entra
sozinha na varredura).

**Por quê a âncora é truncada ao segundo inteiro.** `criado_em` é contado em SEGUNDOS — é o que ele
sempre foi, é o que as linhas já gravadas têm e é o que todo leitor espera — e a tela precisa da
fração para distinguir dois acionamentos do mesmo segundo. Truncada a âncora, o instante gravado é
sempre `ancora_seg * 1000 + ms`, e a fração dele é exatamente `ms % 1000`: derivável de cada linha
sozinha, sem coluna nova para transportar dez bits. O preço é um erro menor que um segundo no
ABSOLUTO, **igual para todas as linhas do lote** — não move ordem nem espaçamento — e muito menor
que a incerteza do relógio de onde a âncora veio.

**O que a tela faz com as linhas antigas.** Nada as reescreve. Sem a origem daqueles lotes, qualquer
carimbo derivado seria inventado, e carimbo inventado é pior que carimbo grosseiro declarado. Elas
ficam com `ancora` vazia, a coluna Horário as marca com "(chegada)", a leitura não devolve fração de
segundo para elas, e a linha de diagnóstico abaixo da tabela diz quantas são e por que elas não
respondem em que ordem nem a que distância os acionamentos aconteceram. A retenção do registro as
leva no prazo dela.

**Existe uma derivação honesta possível, e ela fica como PROPOSTA.** As linhas antigas trazem o
`criado_em` da chegada e o `ms`, e a regra da âncora do servidor é exatamente
`chegada − maior ms do lote`. Agrupando por `(sessao, caminho, criado_em)` — que é a assinatura de
um lote que chegou naquele segundo —, dá para aplicar a MESMA regra retroativamente e devolver a
elas ordem e espaçamento corretos, com o absoluto errando pelo tempo de fila, exatamente como no
caminho `servidor`. **Não foi feito, e o argumento contra é o agrupamento:** ele é INFERIDO, não
registrado. Dois lotes de carregamentos DIFERENTES da mesma visita e do mesmo caminho chegando no
mesmo segundo seriam fundidos, e a âncora comum poria as linhas do primeiro dezenas de segundos
antes do que aconteceu — um erro maior que o que ela conserta, agora com cara de dado bom. As
linhas afetadas são oitenta e sete, em um site, com prazo de retenção de trinta dias. Se o operador
quiser, a migração é uma consulta e uma decisão dele; ela não entra numa release por conta própria.

**O que custa.** Uma coluna a mais no registro, com a migração que ela implica: até `init` rodar
`dbDelta` no site atualizado, `eventos_prontos()` responde falso e a rota devolve `503` nomeado —
que é a degradação declarada do módulo, e não silêncio. Um campo a mais no corpo despachado, dentro
do teto de bytes que já existia. E um erro declarado menor que um segundo no absoluto de cada lote.

**Como reverter.** Devolver `'criado_em' => time()` e `'dia' => gmdate( 'Y-m-d' )` a
`registrar_evento()`, tirar `origem` de `campos()` e do lote selado no cliente, e apagar a coluna
`ancora` de `COLUNAS_EVENTOS` e do `CREATE TABLE`. A tela volta a mostrar `H:i:s` sem fração. O
defeito volta inteiro, com a assinatura conhecida: acionamentos de segundos de navegação caindo no
mesmo segundo, e linhas distintas parecendo a mesma sendo reescrita.

---

## 106. Cada quadro do menu Medição diz de qual das duas tabelas ele vem

**Decidido.** Os quadros do menu Medição passam a trazer, cada um, uma linha dizendo **de qual das
duas tabelas** ele lê e **o que aquela tabela responde**. A frase de cada tabela tem produtor único,
`F3Base_Modulo_Comportamento::proposito_das_tabelas()`, e nenhuma delas é escrita dentro do PHP da
tela.

**O que foi medido.** A tela mostrava a tabela bruta de acionamentos e os quadros do agregado sem
dizer, em lugar nenhum, que são DUAS tabelas com propósitos diferentes. Quem opera foi ao banco para
entender o que via, encontrou `f3base_comportamento` — que soma na mesma linha por desenho, uma
linha por dia, caminho, evento e detalhe — e concluiu que o registro estava sendo reescrito. Não
estava: as linhas de `f3base_eventos` são distintas, cada uma com `id` próprio. A conclusão errada
foi produzida pela ausência de uma linha de texto.

**Por quê produtor único.** Escrita quatro vezes na tela, a frase divergiria na primeira edição
apressada, e a tela passaria a descrever a mesma tabela de dois jeitos — que é a forma de um
documento sobre dois dados virar um terceiro dado errado. É a mesma regra que já vale para a frase
de cada evento, que mora na declaração e nunca na tela.

**O quadro de profundidade é o único que mistura as duas, e ele diz isso.** Os totais de cada marco
e o denominador saem do agregado; o tempo típico, a releitura e "pessoas diferentes" saem do
registro. Sem a linha, quem comparasse esse quadro com a tabela bruta encontraria números que não
fecham e concluiria que um dos dois está errado.

**A linha do quadro de saídas vem ANTES do ramo do vazio.** O quadro vazio é justamente aquele em
que quem lê vai procurar de onde o número deveria ter vindo.

**O que custa.** Cinco linhas de texto a mais numa tela que já é densa. A alternativa medida foi pior:
quem lê vai ao banco e volta com uma conclusão errada sobre o próprio produto.

**Como reverter.** Remover as chamadas a `render_de_qual_tabela()` e o produtor. A tela fica mais
curta e volta a deixar as duas tabelas indistinguíveis para quem só a lê.

---

## 107. Um fato, uma linha, um veredito: a versão do `site-core`

**Decidido.** `release.versao_site_core` **sai**. `plugins.site_core_versao` passa a ser a
derivação ÚNICA do fato "a versão do plugin que ficou instalada é a que este pacote
carrega?", e o ramo em que a instalada está ATRÁS passa de **WARN para FALHA**. A segunda
saída escrita para o operador — instalar a cópia embutida à mão — passa a carregar o
ENDEREÇO da cópia, e some quando não há endereço resolvido.

**Por quê.** Numa execução real da 1.7.2, num site que já rodava, o zip publicado no
catálogo era o 1.0.0 e o pacote carregava o 1.0.1. Detectar isso está certo. O que estava
errado é que o MESMO fato saiu em duas linhas com severidades DIFERENTES:

```
WARN   plugins.site_core_versao   "O site ficou com o site-core 1.0.0, e este pacote carrega a 1.0.1…"
FALHA  release.versao_site_core   "a configuração declara 1.0.1 e o artefato instalado responde 1.0.0"
```

Não eram dois fatos parecidos: as duas linhas chamavam **as mesmas duas funções** —
`F3Base_Imp_Plugins::versao_embarcada_do_site_core()` e
`F3Base_Imp_Plugins::versao_instalada()`. É a mesma duplicidade que a decisão 17 fechou
para os vereditos de canal, reaparecendo num par que ninguém tinha olhado.

**Qual das duas sobreviveu, e por quê.** A que ficou é a que mede certo e diz mais.

- **A regra.** `release.versao_site_core` comparava com `===`. Isso acusa também o caso
  CORRETO: um site cuja URL do catálogo entregou uma versão MAIS NOVA que a reserva
  embutida. O manifesto declara que este pacote não rebaixa artefato mais novo, e a linha
  removida chamava esse acerto de FALHA. `plugins.site_core_versao` usa `version_compare`
  com quatro ramos nomeados, e o ramo "à frente" fecha OK.
- **A mensagem.** A linha removida afirmava duas coisas falsas para este par: que *"a
  configuração declara"* o número — ele sai do NOME do artefato resolvido, não de
  `config/site.json`, desde que a fonte do plugin deixou de viajar no bundle na 1.7.0 — e
  que *"é ele que o `?ver=` publica"*, que é verdade do par do TEMA, de onde a frase foi
  copiada. Um plugin não publica `?ver=` nenhum.
- **O que ela dizia ao operador.** Nada: sem frase de tela, sem saída. A que ficou tem as
  duas, e tem a causa escrita — a URL do catálogo à frente da reserva é o que faz TODA
  implantação instalar a versão velha com sucesso.
- **Onde ela mora.** Na classe que é dona do fato, ao lado da instalação que o produziu.

**Por que FALHA, e não WARN.** WARN é *"mediu e sobrou achado adverso"*; FALHA é *"mediu e
reprovou"*. A entrega promete que o site fica com o `site-core` que este pacote carrega.
A promessa foi medida por leitura de volta do cabeçalho instalado e **não foi cumprida**:
as correções da versão que o pacote traz não estão no site. Isso é reprovação, e chamar de
aviso o que é reprovação é a mesma classe de defeito que esta base combate desde a 1.0.14,
com o sinal trocado.

**E é FALHA que mantém a ferramenta de correção no ar** — o desfecho que precisava
continuar acontecendo. `SUCESSO_APLICACAO` é a primeira das três condições de
`pode_autodesativar()`, e FALHA derruba o estado para `FALHA_PARCIAL`. Um site que ficou
com uma versão superada do plugin, com correções ausentes, não pode ver o implantador sair
de cena. Antes desta release o desfecho era o mesmo pelo caminho errado: quem derrubava o
estado era a linha removida, declarada como gate de fase — e é dessa contradição que
tratam as decisões 108 e 109.

**A cópia embutida existe, e faltava o endereço.** A frase mandava *"instalar a cópia
embutida à mão pela tela de plugins"* sem dizer onde ela está. Ela existe: o bundle leva
`assets/plugins/base-site-core-fator3-<versão>.zip`, conferido por
`pacote.reserva_identica_ao_avulso`, e depois da instalação o arquivo fica em disco. Mas
quem envia o implantador envia o bundle **sem abri-lo**, e uma saída que o leitor não sabe
seguir é uma saída que não existe. A mensagem passou a imprimir o caminho —
`wp-content/plugins/<pasta>/assets/plugins/<slug>-<versão>.zip` —, a dizer que ele também
está dentro do zip que o operador enviou, e a nomear o percurso do wp-admin. Quando o
resolvedor não devolve caminho, a segunda saída **não é prometida**: é o caso do zip sem
número que o operador embute por decisão própria.

**Um slug, e não dois.** A versão INSTALADA era lida no slug do catálogo e a EMBARCADA no
slug de `site.site_core_slug` — duas fontes que ninguém cruza. Iguais nesta base, e nada
garantia que continuassem: divergindo, a linha compararia dois plugins diferentes e
chamaria isso de versão. Os dois lados passaram a sair do MESMO resolvedor. Quem cobra que
o catálogo tenha instalado onde a configuração declara é `entrega.site_core`, que é o lugar
daquela pergunta.

**O que custa.** Uma linha a menos no relatório, e um estado a mais capaz de derrubar a
execução: um site cujo catálogo não foi atualizado deixa de fechar
`SUCESSO_APLICACAO`. É o preço certo, e ele já estava sendo pago — pela linha errada. O
outro preço é de processo: cortar uma release do plugin sem publicar o zip no endereço
declarado passa a ter consequência visível na execução seguinte, em vez de um amarelo que
alguém aprende a ignorar.

**Como reverter.** Devolver o par ao mapa de `conferir_versoes_declaradas()` reabre os dois
vereditos, e `plugins.veredito_de_versao_do_site_core` reprova nomeando os dois emissores;
devolver o ramo "atrás" a WARN reprova no piso que diz, com todas as letras, que WARN não
derruba o estado e por isso deixaria a ferramenta de correção sair do ar num site com o
plugin superado; e apagar o endereço da frase reprova no piso da segunda saída.

---

## 108. `relato` entra no vocabulário de gate, e `fase` volta a significar uma coisa só

**Decidido.** O metadado `gate` ganha um quarto valor, `relato`, e ele passa a ser o
**padrão**. `fase` volta a significar exatamente o que a documentação sempre disse:
evidência que ESTE host não produz — navegador, campo, suíte externa. Seis nomes medidos
aqui mesmo saíram de `fase` para `relato`: `preflight.baseline`,
`preflight.contrato_de_caminho`, `entrega.convergencia`, `entrega.site_no_ar`,
`entrega.daqui_em_diante` e `fases.registro_de_execucao`, mais `plugins.site_core_versao`,
que passou a declarar o seu.

**Por quê.** `fase` estava carregando DOIS significados que não são o mesmo:

1. o declarado — *"evidência que este host não produz"*;
2. o que o uso fazia dele — *"esta linha não decide nada"*.

O segundo é o que a inversão da 1.3.1 instalou sem nome: para impedir que uma linha
descritiva voltasse a suspender 39 unidades, o gate PADRÃO passou a ser `fase`. A metade
protetora está certa e continua valendo. A metade que estava errada é o NOME: **43 emissões
sem classificação** entravam numa lista sobre a qual o relatório escreve, nome por nome,
que a evidência vem de outro lugar. E seis emissores declararam `fase` de propósito pelo
mesmo motivo — o comentário de `preflight.contrato_de_caminho`, escrito na 1.4.0, diz
literalmente que o teste aplicado foi *"tirando isto, o site quebra? NÃO"*, que é a
pergunta do gate de aplicação, e não a da fase.

O preço saiu impresso na 1.7.2, sobre `release.versao_site_core` (FALHA):

> "GATE(S) DE FASE em aberto, declarado(s) e NÃO somado(s) a este gate: …
> release.versao_site_core (FALHA) — **evidência que este host não produz** trava o gate da
> fase, não a ferramenta."

Este host produz essa evidência, e produziu: leu o cabeçalho do plugin instalado e comparou
com o nome do artefato que viaja no pacote. Não falta fase nenhuma, não falta navegador,
não falta tráfego.

**Por que um quarto valor, e não uma reclassificação para `aplicacao`.** Porque `aplicacao`
responde a uma pergunta mais estreita — *"isto impede o site de funcionar?"* — e é ela que
SUSPENDE o que depende da unidade. `plugins.site_core_versao` é emitida dentro da unidade
`site_core`, de quem `options_site_core`, `formularios` e `cadencia` declaram depender:
marcá-la como `aplicacao` deixaria um site sem options, sem formulário e sem cadência
porque o catálogo publicou uma versão antiga do plugin — que é exatamente a catástrofe de
1.3.0 com outra causa. A linha não é nenhum dos dois, e o pacote não tinha nome para o que
ela é.

**`relato` não afrouxa nada.** Ele tem os mesmos poderes que `fase` tinha, que são nenhum:
não promove a unidade, não suspende dependente e não entra na condição do gate de
aplicação. O que muda é o que o relatório AFIRMA sobre a linha — e a nota da unidade, que
deixou de chamar essas linhas de "pendência de fase" e passou a nomeá-las como linhas de
relato, dizendo o que uma FALHA nelas faz.

**O que custa.** Um valor a mais no vocabulário, e uma pergunta a mais para quem escreve um
emissor novo: *este host produz a evidência?* Se produz e a resposta impede o site de
funcionar, é `aplicacao`; se produz e não impede, é `relato`; se não produz, é `fase`; se
depende de dado que só o operador tem, ninguém escolhe — `precondicao` deriva
`convergencia`. Esquecer continua caindo no lado inofensivo. E a lista de gates de fase
encolheu para três nomes, o que é o resultado esperado: só ela é evidência externa.

**Como reverter.** Devolver `GATE_FASE` ao padrão de `emitir()` reprova em
`lotes.unidade_reflete_internas` (a linha sem gate declarado tem de cair em `relato`) e
reabre a frase falsa; devolver `aplicacao` ao padrão reabre a catástrofe de 1.3.0, e o
mesmo piso reprova. Devolver `fase` a qualquer um dos seis nomes reclassificados faz o
relatório voltar a afirmar que este host não produz o que ele acabou de medir.

---

## 109. A contagem que deriva o estado continua CRUA, e a contradição passa a ser acusada

**Decidido.** `F3Base_Imp_Relatorio::checagens_em_falha()` continua contando **toda** FALHA,
de qualquer gate, e é dela que sai `FALHA_PARCIAL`. O que passou a ser **proibido** é a
outra ponta: nenhuma linha de gate `fase` pode fechar FALHA. Quem acusa é
`entrega.gate_de_fase_nao_derruba_estado`, emitida no encerramento ANTES da contagem — para
que a FALHA do instrumento entre no número que ela descreve.

**Por quê.** A contradição da 1.7.2 tem dois lados, e havia duas saídas defensáveis: ou a
contagem passa a respeitar o gate, ou o pacote para de afirmar que gates de fase não são
somados. A escolha foi medida antes de ser feita.

**A medição.** Varridas as emissões do runtime, TODA checagem de gate `fase` capaz de
fechar FALHA media evidência que este host **produz**: `preflight.saida_https`,
`preflight.colisao_de_slug`, `tema.sem_override_de_editor`,
`preflight.contrato_de_caminho`, `wordpress.permalinks`, `wordpress.blog_public`,
`tema.wp_html_declarado`, `ambiente.url_canonica`, `site.prefixo_tecnico`,
`rollback.journal`, `release.versao_*` e `entrega.site_no_ar`. **Nenhuma delas é o caso em
que uma FALHA deveria deixar o estado de pé.** As três linhas de fase que restam depois da
decisão 108 — `entrega.rodada_limpa`, `mcp.autoteste_recusa_credencial` e
`orcamento.medicao_de_pagina` — não têm ramo de FALHA: elas fecham BLOCKED ou N/A, e
BLOCKED não entra na contagem.

Então fazer a contagem respeitar o gate não corrigiria caso nenhum de hoje e abriria um
buraco para amanhã: uma FALHA de verdade que não derruba nada. E quebraria o desfecho que
precisa continuar acontecendo — é a FALHA de `plugins.site_core_versao` que mantém o
implantador no ar num site com o plugin superado.

**As duas exceções de ORDEM continuam sendo de ordem, e isso é declarado.**
`entrega.convergencia` e `entrega.site_no_ar` são emitidas DEPOIS da contagem: a primeira
relata o que a execução encontrou e não pode mudar o número que ela acabou de descrever; a
segunda é consequência do estado, e um efeito que realimenta a própria causa não é
medição. Nenhuma das duas é exceção de gate.

**O que a linha nova diz, e o que ela não diz.** Ela não acusa BLOCKED de fase — BLOCKED
não entra na contagem, e cobrar dele um estado que a evidência externa não tem como fechar
transformaria a correção em ruído permanente. E não acusa FALHA de `relato` nem de
`convergencia`: sobre essas o pacote **não** afirma que a evidência vem de outro lugar. O
host mediu, a FALHA é reprovação, derrubar o estado é o desfecho certo, e a frase de cada
uma passou a dizer isso — inclusive a da convergência, que agora separa o BLOCKED (falta o
dado, a execução termina e o implantador sai de cena) da FALHA (o dado foi preenchido e o
conteúdo medido continua errado, e o implantador fica).

**O texto do gate parou de omitir a metade que importa.** A nota de
`pode_autodesativar()` continua dizendo que o gate de fase não é somado ao gate de
aplicação — o que é verdade da CONDIÇÃO — e passou a dizer o que faltava: que qualquer
FALHA derruba o estado, e que o estado é a primeira condição daquele mesmo gate. As duas
frases juntas são a verdade inteira; a primeira sozinha era o que fazia o relatório parecer
— e ser — contraditório.

**O que custa.** Uma linha a mais no relatório de toda execução, quase sempre em OK. E uma
restrição a quem escrever um emissor novo: uma checagem de gate `fase` não pode ter ramo de
FALHA. É a restrição certa — se a evidência é de outra fase, o que existe aqui é ausência
de medição, e ausência de medição é BLOCKED ou N/A, nunca reprovação.

**A PRIMEIRA VERSÃO DESTA DECISÃO ENTREGOU O PISO ERRADO, e o registro fica.** Ela nasceu
com uma bancada só, `lotes.gate_de_fase_nao_derruba_estado`, que exercita
`contradicao_de_gate_nao_somado()` contra linhas que a **própria sonda monta**. Plantada a
contradição na DECLARAÇÃO real — uma palavra em `class-f3base-imp-plugins.php:1608`,
`'relato'` de volta para `'fase'` —, `bash suite/verificar.sh` fechou **sem uma única
FALHA**. A bancada provava que a função reconhece a contradição quando alguém a entrega, e
não provava nada sobre o objeto: é a bancada que mede o instrumento e não mede o objeto, a
mesma forma que custou quatro releases na medição de comportamento, quando a bancada
simulava o `IntersectionObserver` que o navegador tem.

**A correção é `estatica.gate_de_fase_sem_ramo_de_falha`**, que varre as emissões escritas
em `includes/` e cruza o gate DECLARADO com os estados que cada emissão pode produzir. A
regra é decidível, e onde ela não decide, ela cobra:

- `avaliar()` e `condicional()` são acusadas **sempre** — emitem nos dois ramos por
  construção, e o ramo adverso é FALHA;
- `emitir()` e `emitir_unidade()` têm o estado resolvido em UM salto: constante literal
  decide sozinha; variável é resolvida pela produtora que a atribui, e os estados possíveis
  são as constantes de estado do corpo dela;
- qualquer outra forma — ternário, concatenação, chamada embutida — é **acusada** dizendo
  que não foi possível provar. O erro seguro é cobrar: emissão de fase cujo estado ninguém
  consegue provar é justamente aquela em que a FALHA passa despercebida.
- escopo vazio não aprova.

As duas checagens ficam, e não se repetem: a estática prova a invariante **antes de o
pacote sair**, sobre as declarações; a bancada cobre o que só se decide em execução. Cada
uma passou a dizer, na própria linha, o que **não** afirma.

**Como reverter.** Fazer `checagens_em_falha()` filtrar por gate devolve o buraco;
apagar a linha do runtime devolve o silêncio em execução, e o piso da bancada reprova; e
tirar o detector estático devolve exatamente o defeito medido — a mutação de uma palavra
passando por uma rodada inteira. O piso dele em disco é essa mutação: a negativa é
`plugins.site_core_versao` com `gate => 'fase'` e a produtora com ramo de FALHA, e a
positiva traz as três formas legítimas mais a linha reclassificada, porque um detector que
só sabe reprovar reprova o certo junto.

---

## 110. Duas correções fora do roteiro desta release, e por que elas foram feitas

**A primeira.** O bloco que declara os gates em `F3Base_Imp_Relatorio` dizia, sobre
`aplicacao`, que ele "é o padrão, e a ausência do metadado cai aqui de propósito". Isso
deixou de ser verdade na 1.3.1, quando a inversão passou o padrão para `fase`, e o
comentário ficou dois anos de release descrevendo o contrário do que o código fazia — no
arquivo em que alguém vai ler para decidir o gate de uma linha nova. Foi corrigido junto
porque a decisão 108 mexe exatamente ali, e deixar a frase velha seria escrever a quarta
opção embaixo de uma explicação errada das outras três.

**A segunda.** A nota da unidade sobre pendências de convergência dizia que elas ficam
"FORA do veredito dela" e que "o que falta continua nomeado sem virar defeito do host" —
verdadeiro do veredito da UNIDADE, e mudo sobre o estado da APLICAÇÃO. Uma pré-condição em
FALHA (`privacidade.controlador_identificado` tem esse ramo) derruba o estado como qualquer
outra, e a nota não dizia. É a mesma omissão da decisão 109, um andar abaixo, e o conserto
é uma frase. A decisão 40 continua valendo inteira: a autodesativação não espera pela
convergência **pendente**, que é o caso do dado ausente; o caso da convergência **não
convergida** é reprovação medida, e reprovação medida derruba o estado.

---

## 111. O zip do plugin passa a ser reprodutível, e o hash do pacote volta a fechar duas vezes igual

> **CORRIGIDA NA 1.7.4, E O ERRO TEM NOME: esta decisão chamou de "reprodutível" um
> artefato que era estável por UM DIA e só dentro do MESMO VOLUME.** Ela mediu duas rodadas
> seguidas, viu `6075ca9d…` e `6075ca9d…`, e concluiu reprodutibilidade a partir de um
> experimento que não movia nenhuma das duas variáveis que quebram o artefato — o relógio
> e o sistema de arquivos. Pior: ela declarou que `TZ=UTC` resolvia o caso de "duas
> máquinas", quando o fuso era só uma das portas e a ORDEM das entradas era a outra,
> aberta e não medida. Medido na 1.7.4: a mesma árvore em 05/09 e 06/09 dá `693ca754…` e
> `aeb40cad…`; a mesma árvore no MESMO dia dá `693ca754…` num ext4 e `855fabbb…` num
> tmpfs. **O que esta decisão fez de errado não foi errar a régua: foi aplicar a régua da
> decisão 84 — precisão de DIA — a um objeto para o qual ela não serve, e depois medir o
> resultado com um experimento que não podia acusar nada.** A decisão 112 substitui o
> conteúdo desta; o que fica aqui é o registro do erro, porque decisão apagada é decisão
> que volta.

**Decidido.** O estágio do zip do plugin recebe carimbo de tempo FIXO — meia-noite UTC do
dia da montagem, a mesma régua que a decisão 84 declarou para o registro de fases — antes
de o `zip` ser chamado, e as duas chamadas (`touch` e `zip`) rodam com `TZ=UTC`.

**Por quê.** Medido nesta release, e é uma afirmação de documento que tinha deixado de ser
verdadeira. Duas rodadas seguidas sobre uma árvore **byte a byte idêntica** — conferido por
`sha256sum` de todo arquivo fora de `dist/`, sem uma linha de diferença — produziam hashes
de pacote diferentes:

```
5e31845a…  →  80dfdfb6…  →  f8465960…  →  6e690f9a…
```

A causa não era a árvore. Era este arquivo: o estágio do plugin é copiado a cada montagem,
as cópias nascem com a hora de agora, e o formato zip guarda a hora de cada entrada dentro
do arquivo. O CONTEÚDO do plugin não mudava — o digest de conteúdo do zip ficou em
`171c62b0…` o tempo todo, com as mesmas 47 entradas —, mas os BYTES do arquivo que o embala
mudavam. E desde a 1.7.0 a reserva viaja DENTRO do bundle, enquanto o hash do pacote soma o
`sha256` de cada entrada dele: o número mudava a cada rodada.

A decisão 84 escreveu, ao explicar por que o registro de fases carimba o DIA e não o
segundo: *"Um operador comparando dois digests legítimos concluiria adulteração, que é
exatamente o mal-entendido que o MANIFESTO existe para evitar"*, e afirmou que *"a árvore
reverificada no mesmo dia dá o MESMO hash"*. Isso era verdade quando foi escrito e deixou
de ser na 1.7.0, sem que nada acusasse — porque a coisa que passou a viajar no bundle
naquela release é justamente um artefato de build.

**`TZ=UTC` nas duas chamadas, e não só o `touch`.** O formato zip guarda a hora LOCAL da
entrada. Fixar o mtime sem fixar o fuso deixaria a mesma árvore montada em duas máquinas
produzindo bytes diferentes — o mesmo defeito com outro nome, e mais difícil de achar
porque só aparece quando duas pessoas comparam.

**Medido depois.** Duas rodadas seguidas: `6075ca9d…` e `6075ca9d…`.

**O que custa.** Os arquivos dentro do zip do plugin chegam ao site com a data da montagem
às 00:00 UTC em vez do instante exato da cópia. Nenhum caminho do pacote lê essa data —
quem responde "qual versão é esta" é o cabeçalho do plugin, e quem responde "o artefato
mudou" é o `sha256` do lock. E uma dependência a mais do build em duas ferramentas de linha
de comando que ele já usava (`find` e `touch`), com o achado nomeado quando qualquer uma
delas falha.

**Como reverter.** Tirar o `touch` devolve os bytes instáveis, e
`pacote.reserva_identica_ao_avulso` reprova dizendo que as entradas têm carimbos
diferentes; tirar o `TZ=UTC` não é acusado por esta bancada — ela roda numa máquina só —, e
é por isso que o motivo está escrito no código, ao lado da chamada.

---

## 112. O carimbo do artefato publicado sai do relógio de vez, e a ordem das entradas sai do sistema de arquivos

> **MUDOU DE REPOSITÓRIO NA 2.0.0.** Esta decisão está certa e continua valendo — para o
> artefato que ela descreve, que este repositório NÃO monta mais. O zip do plugin passou a
> ser montado, selado e provado reprodutível pela suíte do repositório do plugin
> (`pacote.zip_reprodutivel`, lá), e o que ficou aqui é uma CÓPIA do zip publicado, conferida
> contra o `sha256` que o catálogo declara. A época declarada, a ordem por byte, os dois
> mutantes e o `faketime` saíram desta árvore junto com o empacotamento do plugin — decisões
> 114 e 122. O que fica aqui é o registro: foi esta decisão que tornou possível declarar UM
> digesto no catálogo e conferir a reserva contra ele.

**Decidido.** O zip do plugin deixa de ter qualquer entrada tirada do ambiente. Duas
metades, e uma sem a outra continua produzindo o mesmo defeito com outro nome:

- **O carimbo de cada entrada é uma ÉPOCA FIXA DECLARADA** — `1980-01-01 00:00:00 UTC` —,
  produzida por `f3b_epoca_do_zip()`, em `suite/lib/empacotar.php`, com o motivo ao lado.
  Ela é lida por dois lugares e só existe num: o empacotamento, que a aplica com `touch`, e
  `suite/lib/sonda-bundle.php`, que confere o artefato MONTADO contra ela.
- **A ordem das entradas é DECLARADA**, crescente por byte. A lista é montada em PHP por
  `f3b_entradas_do_zip()`, ordenada com `sort( …, SORT_STRING )` e entregue ao `zip` por
  `-@`, no lugar do `zip -qrX` que recursava sozinho.

**Por quê. O defeito tem dois braços, e os dois foram medidos.**

O primeiro é o relógio. A 1.7.3 declarou o zip reprodutível e o que ela entregou durava um
dia: o carimbo era `gmdate( 'Y-m-d', floor( time() / 86400 ) * 86400 )`, o relógio
arredondado ao dia. Uma árvore foi empacotada, arquivada inteira, extraída noutro lugar e
reempacotada — `diff -r` limpo, conteúdo byte a byte idêntico — e os bytes do zip mudaram:

```
entregue em 05/09     693ca754ab5bc337e8786c4959c346c6342dd04804f577d597bf57fea3d42a31
reconstruído em 06/09 aeb40cadf2598e87814c5adaaae1a80138c89434d1f364f25fc142356a3bf94c

carimbo da 1ª entrada   2026-09-05 00:00
carimbo da 1ª entrada   2026-09-06 00:00
```

O segundo é o sistema de arquivos, e ele nunca tinha sido medido. `zip -r` grava as
entradas na ordem em que o diretório as devolve, e essa ordem é do VOLUME: num ext4 ela vem
do hash do nome com a semente daquele volume, num tmpfs vem da ordem de criação. Medido
nesta bancada, mesma árvore, MESMO dia, dois volumes da MESMA máquina:

```
ext4    693ca754ab5bc337e8786c4959c346c6342dd04804f577d597bf57fea3d42a31
tmpfs   855fabbbf41416640542b25e7aa262bef8980a002a0a993893e4fc0b02ed7d15
```

A 1.7.3 escreveu que `TZ=UTC` fazia "a mesma árvore montada em duas máquinas" dar os mesmos
bytes. O fuso era uma das portas. Esta era a outra, e ela estava aberta.

**POR QUE ISSO É MAIS GRAVE DO QUE "o hash do pacote não fecha duas vezes igual", QUE FOI
COMO A 1.7.3 LEU O PROBLEMA.** Este zip é PUBLICADO no catálogo — `plugins.instalaveis.0`,
origem `url`, sem `sha256` declarado — e `F3Base_Imp_Plugins::veredito_do_digest()` **FIXA
o digesto dele na primeira observação** e reprova a execução seguinte quando ele muda, com
a frase invertida: *"a origem não mudou entre as execuções"* vira *"DIGESTO DIVERGENTE do
fixado … NADA foi instalado"*. Republicar amanhã um zip de conteúdo idêntico, reconstruído
da mesma fonte, faz **toda implantação seguinte falhar acusando troca de artefato que não
houve** — em todo site que já observou o artefato uma vez.

**A RÉGUA DA DECISÃO 84 FOI APLICADA E O PROPÓSITO DELA FOI DERROTADO.** O comentário da
1.7.3 invoca a decisão 84 e diz que a régua dela — precisão de DIA, em UTC — é a que se
aplica aqui. A decisão 84 existe para que um operador comparando dois digests legítimos não
conclua adulteração; a aplicação literal dela produziu exatamente esse falso alarme, e
automatizado, dentro do gate que instala plugin. **Precisão de dia serve a um registro que
alguém LÊ. Não serve a um artefato cujo digesto é a chave de uma comparação entre
execuções.** Ali qualquer granularidade tirada do relógio é uma bomba com pavio de 24
horas, e a única resposta certa é o relógio não entrar.

**POR QUE ÉPOCA FIXA, E NÃO CARIMBO DERIVADO DO CONTEÚDO.** As duas saídas foram pesadas.

O carimbo derivado — o mtime mais novo entre os arquivos-fonte, por exemplo — carrega
alguma informação, e foi **recusado**: mtime de arquivo é reescrito por qualquer cópia de
árvore. `git clone`, `cp` sem `-a`, extração de um tar, um checkout de CI: em todos, os
mtimes passam a ser a hora da cópia, e o carimbo volta a dizer "quando esta máquina tocou
nestes arquivos" em vez de "o que estes arquivos são". É a MESMA classe de defeito que
criou o problema original — o estágio nascia com a hora de agora —, movida de lugar. E o
argumento de que ele "carrega informação" não sobrevive à pergunta seguinte: informação
para quem? Nenhum caminho deste pacote lê a data das entradas deste zip. Quem responde
"qual versão é esta" é o cabeçalho do plugin; quem responde "o artefato mudou" é o `sha256`
do lock e o digesto fixado no host.

A época fixa é o que sobra, e ela é honesta pela mesma razão que parece um defeito: **o
carimbo deixa de dizer qualquer coisa sobre quando o pacote foi montado, e ele já não
dizia** — até a 1.7.3 ele dizia "meia-noite do dia da montagem", um instante que nunca
existiu, e que o operador poderia ler como hora de build.

**O INSTANTE ESCOLHIDO É `1980-01-01 00:00:00 UTC`, E A ESCOLHA É PARTE DA DECISÃO.** Ele é
o zero do formato zip — a menor data que o carimbo DOS representa. Uma época plausível
(`2020-01-01`, digamos) reintroduziria pela metade o mal-entendido que esta decisão fecha:
alguém leria aquilo como uma data. O zero do formato não é lido como data por ninguém.

**A VARREDURA DOS OUTROS ARTEFATOS EMPACOTADOS, e o que ficou de fora COM MOTIVO.**

- **`dist/implantador-base-<versão>.zip`, o bundle.** As entradas dele continuam com o
  carimbo da cópia do estágio, e ele NÃO é reprodutível byte a byte — nem entre dias, nem
  dentro do mesmo dia. **Fica como está**, e o motivo é o teste desta decisão: o digesto do
  bundle não é chave de comparação entre execuções. Ninguém o busca por URL, ninguém o fixa
  na primeira observação; o operador faz upload dele, e a integridade do que chegou é
  medida pelo `hash do pacote` sobre a ÁRVORE INSTALADA, contra o `suite/rodada.json` que
  viajou dentro dela. Fixar a época das entradas dele compraria zero e custaria uma coisa
  cara: um sinal de "reprodutível" num artefato que não é, porque ele carrega, por desenho,
  dois registros que respondem *quando* — `suite/rodada.json` (precisão de segundo) e
  `suite/fases.json` (precisão de dia).
- **O zip que `suite/lib/sonda-instalacao.php` monta** para exercitar o caminho de
  instalação. Ele nasce e morre dentro da rodada, nunca é publicado e nunca é fixado por
  ninguém. Fica como está.
- **Os zips de `suite/fixtures/`.** São arquivos estáticos da árvore, não saída de build.

**O QUE FOI MEDIDO SOBRE O SELO, E O QUE SOBRA DE VARIAÇÃO — NOMEADO.** O `hash do pacote`
soma o `sha256` de cada arquivo do corpo do bundle, e a reserva do plugin viaja lá dentro:
com o zip estabilizado, aquela entrada parou de mexer o número. **Sobra uma fonte, e ela é
`suite/fases.json`**, que está dentro da soma e traz `"em": <dia>` mais o dia da última
execução de cada fase. Medido, com a árvore idêntica e o relógio movido de verdade: a
rodada cujo registro trazia `2026-09-06` fechou em `c4f76e82…`; a primeira rodada depois de
o registro passar a trazer `2026-09-20` fechou em `c1c9a21a…`; a rodada seguinte, no mesmo
dia, repetiu `c1c9a21a…`. **O número muda uma vez por dia, uma rodada DEPOIS de o dia
virar** — porque o registro que entra no bundle é o da rodada anterior, que é o quinto
preço já declarado na decisão 84.

**E ISSO FICA COMO ESTÁ, PELO MESMO CRITÉRIO QUE MOVEU O ZIP.** `suite/fases.json` é um
registro que alguém LÊ: ele responde "quando a fase de navegador rodou pela última vez", e
isso é pergunta de calendário. O digesto que ele move não é fixado contra nenhum artefato
REPUBLICADO — o host compara a árvore instalada com o registro que viajou dentro dela, e as
duas coisas mudam juntas. Apagar o dia dali para "estabilizar o hash" tiraria a única
informação que aquele arquivo existe para dar.

**O PISO MOVE O MUNDO EM VOLTA DO BUILD, E ESSA É A METADE QUE FALTAVA NA 1.7.3.** O piso
antigo era uma lista mutante de carimbos passada a uma função pura — ele provava que a
regra sabia reprovar, e não provava nada sobre o artefato. O piso desta release roda o
EMPACOTAMENTO REAL de novo, quatro vezes, com as duas alavancas que só existem de fora do
processo:

- **o relógio**, movido por `faketime`, que move `time()` do PHP e o `touch` do coreutils
  juntos: montar em `2026-09-05` e em `2029-02-17` tem de dar os mesmos bytes;
- **o volume**, trocado apontando a saída para outro sistema de arquivos (`/dev/shm`):
  montar no ext4 e no tmpfs tem de dar os mesmos bytes.

**E O MUTANTE É O QUE PROVA QUE A ALAVANCA TEM DENTE.** `suite/lib/sonda-bundle.php` copia
o `suite/lib/empacotar.php` REAL, troca UMA linha e roda o empacotamento por essa cópia:
com o carimbo de volta ao relógio — o código da 1.7.3 —, as duas montagens PRECISAM
divergir e o teto PRECISA acusá-las; com a ordem de volta ao `readdir`, as montagens nos
dois volumes PRECISAM divergir e o teto da ordem PRECISA acusá-las. Se o mutante passa, o
piso está medindo a si mesmo, e a linha sai dizendo isso com todas as letras: *"o relógio
não se moveu de verdade e todo este piso está medindo a si mesmo, não o empacotamento"*.
**Medido:** com o `faketime` retirado da chamada, essa exata linha aparece — é assim que se
sabe que o piso não é encenação.

**O que custa.** Cinco preços.

O primeiro: **`faketime` virou pré-condição do comando único**, ao lado de `php`, `node`,
`zip` e `unzip`. Máquina sem ele fecha `BLOCKED suite.ambiente` com o recurso nomeado, e a
rodada inteira não acontece. É caro, e é a única forma honesta: o piso que sustenta a
afirmação central desta release não pode ser opcional, porque uma afirmação de
reprodutibilidade sem piso já durou um dia e quebraria a implantação seguinte de todo site.

O segundo: **a bancada precisa de um segundo sistema de arquivos gravável** para a metade
que mede a ordem. Ela procura `/dev/shm`, `/run/shm` e o temporário do sistema, e quando
nenhum está noutro dispositivo a linha sai dizendo, com o nome, que aquela metade **não
rodou**. Não é silêncio, e também não é BLOCKED: é achado, porque escopo vazio não aprova.

O terceiro: **o carimbo das entradas do zip mente sobre o tempo, de propósito.** Quem abrir
o zip vê 1980. É o preço de o carimbo não dizer nada em vez de dizer algo errado, e ele só
não dói porque nenhum caminho do pacote lê essa data.

O quarto: **a ordem das entradas do zip mudou**, e com ela os bytes do artefato. O CONTEÚDO
não mudou — `diff -r` limpo entre o extraído da 1.7.3 e o desta release, as mesmas 47
entradas, o mesmo digesto de conteúdo. Mas o digesto dos BYTES mudou uma última vez:
`693ca754…` → `1748c984…`. **Todo site que já observou o artefato anterior vai reprovar na
próxima execução**, com a mensagem de digesto divergente do fixado — e a saída está escrita
nela: declarar o novo `sha256` na entrada, ou apagar o registro fixado daquele slug e
reexecutar. É a última vez que isso acontece, e é justamente o que esta decisão existe para
não acontecer de novo.

O quinto: **o empacotamento ganhou dependência de mais uma leitura de disco** — a lista de
entradas do estágio — e um arquivo de trabalho em `dist/`, apagado logo em seguida. A lista
é montada em PHP e não por `find | sort` por uma razão medida: `exec()` roda por `sh`, o
`sh` desta base é o `dash`, o `dash` não tem `pipefail`, e num cano o código de saída é o do
ÚLTIMO comando — um `find` que falhasse deixaria o `zip` fechar um arquivo incompleto com
código 0.

**Como reverter.** Devolver o carimbo ao relógio — trocar `f3b_epoca_do_zip()` por
`gmdate( 'Y-m-d', … time() … )` — reprova em três frentes: o teto do carimbo acusa que o
carimbo veio do relógio e não da declaração, o piso das duas montagens acusa que a mesma
árvore em dois dias deu bytes diferentes, e o mutante do carimbo deixa de divergir e a
linha diz que o piso passou a medir a si mesmo. Devolver a ordem ao `readdir` — tirar o
`sort( $entradas, SORT_STRING )` — reprova pelo teto da ordem e pelo piso dos dois volumes.
Tirar `faketime` da lista de pré-condições não é acusado por nenhuma checagem, porque a
ausência dele já é BLOCKED antes de qualquer checagem rodar: é o próprio comando único que
recusa, e é por isso que o motivo está escrito ali, ao lado do laço.

---

## 113. O plugin sai desta árvore: repositório próprio, e o que fica é a reserva e a cópia vendorizada

**Decidido.** `fontes/plugin/` deixa de existir neste repositório. O `Base Site Core Fator3`
tem repositório próprio, suíte própria — com a bancada WordPress real —, documentos próprios e
release própria, publicada no catálogo como `base-site-core-fator3.zip`. O que este
repositório carrega do plugin são duas cópias de um artefato que ele NÃO produz: a RESERVA,
`assets/plugins/<slug>-<versão>.zip`, que é o zip publicado copiado byte a byte para a
árvore, e `partilhado/`, cópia VENDORIZADA das quatro classes de regra e das duas tabelas
que o implantador precisa ler antes de o plugin existir na instalação. A identidade da
release sobe para 2.0.0 porque o que mudou foi o que este repositório É: da 1.7.0 à 1.7.4 ele
era o repositório de DOIS artefatos com uma suíte só; agora é o de um.

**Por quê.** A separação da 1.7.0 foi de RUNTIME e de RELEASE, não de repositório, e a
decisão 98 disse isso com todas as letras. O que a 1.7.4 mostrou, medida contra o plugin
1.0.0 publicado, é que meio repositório é o pior dos dois mundos — e são três medições, cada
uma com a suíte inteira em verde:

- **A reserva embutida na 1.7.4 dizia 1.0.1 e o catálogo publicava 1.0.0.** A numeração do
  plugin foi ajustada do lado de lá: 1.0.0 é a release final, 1.0.1 nunca foi publicada. Do
  lado de cá o empacotamento continuava montando `base-site-core-fator3-1.0.1.zip`
  (`1748c984…`) a partir de uma fonte que já não era a do plugin. Consequência, pela regra
  certa da decisão 107: `veredito_da_versao_do_site_core( '1.0.0', '1.0.1' )` fecha FALHA
  "instalada atrás", o estado cai para `FALHA_PARCIAL` e o implantador não se autodesativa —
  em TODA implantação nova. A regra estava certa; o número que ela carregava, não. E nenhuma
  linha da suíte acusava, porque a suíte comparava a reserva com a própria montagem.
- **95 rótulos eram emitidos pelas DUAS suítes** — 224 aqui, 144 lá — e os que mediam o objeto
  plugin liam `fontes/plugin/`: uma fonte que não era, byte a byte, o que o site instalava.
  Dois instrumentos sobre o mesmo fato, com fontes diferentes, é a discordância da decisão 107
  um andar acima.
- **Quatro dos cinco arquivos de `partilhado/` divergiam do zip publicado** (decisão 115), e o
  contrato de nomes vendorizado estava atrás do publicado (decisão 115). Cópia diverge se
  ninguém a confere, e ninguém conferia.

O acoplamento que sobrou depois da 1.7.0 era o REPOSITÓRIO: enquanto a fonte morasse aqui,
alguém a editaria aqui, o empacotamento a montaria aqui, e o artefato publicado seria outro.

**O que custa.** Três coisas, e as três são declaradas.

Primeiro, **uma release do plugin passa a custar uma release do implantador**: a reserva e a
cópia vendorizada mudam de bytes, e bytes que mudam dentro da árvore são identidade nova.
São três edições deste lado — o zip novo em `assets/plugins/`, o `sha256` novo no catálogo, a
cópia de `partilhado/` extraída do zip novo — e a rodada. Até a 1.7.4 uma correção no plugin
"não obrigava release do implantador"; a frase era verdadeira sobre o número e falsa sobre os
bytes, porque a reserva embutida mudava do mesmo jeito.

Segundo, **a suíte deste repositório perde cinquenta e nove linhas** e passa a depender da
rodada do outro repositório para metade da afirmação "pacote aprovado" (decisão 118).

Terceiro, **o implantador passa a ler o plugin de dentro de um zip** em vez de um diretório
(decisão 116): cada leitura é um `unzip -p`, e uma fixture que precise do plugin traz um
diretório em claro pela exceção declarada.

**Como reverter.** Recriar `fontes/plugin/` nesta árvore. Não é silencioso em nenhum ponto:
`pacote.allow_list` aborta o empacotamento com o nome de cada arquivo fora do inventário,
`pacote.plugin_so_como_zip` acusa a fonte dentro do bundle, e `f3b_fonte_do_plugin()` continua
lendo da reserva enquanto ela existir — a cópia em claro só responde quando a reserva não
existe, e sem reserva o empacotamento não fecha.

---

## 114. A reserva é ENTRADA de build, e o catálogo declara o digesto contra o qual ela é conferida

**Decidido.** `assets/plugins/<slug>-<versão>.zip` mora na árvore, entra no inventário, no lock
e no hash do pacote, e é o zip publicado copiado byte a byte — exatamente um. `config/decisoes.tsv`
declara, em `plugins.instalaveis.<n>.sha256`, o digesto que a rodada do repositório do plugin
selou. `pacote.reserva_confere_com_o_catalogo` mede cinco cláusulas sobre o ARTEFATO montado:
o `sha256` da reserva na árvore é o declarado; a versão que o NOME carrega é a do cabeçalho
`Version:` de dentro do zip; a pasta de topo é a `pasta_esperada`; a cópia dentro do bundle é
byte a byte a da árvore; o zip tem entradas legíveis. O empacotamento confere as três
primeiras ANTES de fechar o bundle e aborta com o nome. O carimbo gerado dos documentos passa a
carregar a reserva, o digesto medido e o declarado, lado a lado.

**Por quê.** Até a 1.7.4 a reserva era SAÍDA de build: montada de `fontes/plugin/` a cada
rodada, embutida no bundle e comparada — por `pacote.reserva_identica_ao_avulso` — com o zip
avulso que a MESMA rodada tinha montado. As duas batiam sempre, e nenhuma das duas era o que o
catálogo servia. O digesto não era declarado no catálogo, e a decisão 84 explica o que isso
custa: o host FIXA o primeiro digesto que observa e reprova a execução seguinte em que o
arquivo mudar — inclusive a que instala a release nova publicada de propósito. A entrega do
plugin 1.0.0 pediu, com todas as letras, que o `sha256` de `SHA256SUMS.txt` fosse declarado
na entrada; a 1.7.4 não o declarava.

O que a conferência contra o catálogo fecha é o caso silencioso do parágrafo de abertura da
decisão 113: reserva e URL servindo artefatos DIFERENTES com o mesmo nome. Quem cai na reserva
tem de receber o que quem baixa o publicado recebe.

**O que custa.** O digesto é digitado no catálogo, e digitado envelhece: a release seguinte do
plugin exige a edição. É um número declarado por decisão, com motivo ao lado, e é conferido em
toda rodada contra os bytes — que é a única forma honesta de um número digitado existir neste
pacote. O preço maior é o da decisão 113: bytes novos na árvore são release nova.

**Como reverter.** Voltar a montar o zip aqui exige trazer a fonte de volta (decisão 113).
Apagar o `sha256` do catálogo é acusado por `pacote.reserva_confere_com_o_catalogo` e pelo
empacotamento, nomeando a entrada; trocá-lo por um número que não é o da reserva é acusado
pelos dois, nomeando os dois valores.

---

## 115. `partilhado/` inverte de sentido: cópia vendorizada, declarada, conferida byte a byte

**Decidido.** `partilhado/` passa a ser CÓPIA do plugin, e não origem: as quatro classes de
regra (`F3Base_Censo_Demonstrativo`, `F3Base_Chaves_Seo`, `F3Base_Emissores`,
`F3Base_Vocabulario`) e DUAS tabelas — `emissores-conhecidos.tsv` e, novo aqui,
`contrato-de-nomes.tsv`, que veio de `fontes/plugin/dados/`. `partilhado/VENDORIZADO.tsv`
declara, caminho a caminho, qual entrada do zip cada arquivo espelha e por que o implantador
precisa dele antes de o plugin existir. `pacote.copia_vendorizada_confere` compara cada arquivo
com a entrada correspondente da reserva, byte a byte, e cobra a declaração nos dois sentidos:
arquivo em disco sem linha, linha sem arquivo, linha sem motivo e origem que não existe no zip
são achados. Editar `partilhado/` é fork; atualizar é extrair do zip novo.

**Por quê.** A decisão 99 pôs o contrato num lugar neutro e o empacotamento o copiava para
DENTRO do zip do plugin. Com o plugin em repositório próprio, o lugar neutro deixou de
existir: o dono das regras é quem as executa no site. E a cópia que ninguém confere diverge —
medido na 1.7.4, contra o zip 1.0.0 publicado, quatro dos cinco arquivos diferiam:

- `class-f3base-censo-demonstrativo.php` sem a guarda de `class_exists` que as três irmãs
  tinham. O plugin publicado a tem, com o motivo escrito: sem ela, o processo que carrega os
  dois lados — o implantador rodando dentro de um site com o `site-core` ativo, que é o modo
  somente-relatório — morre em `Cannot declare class`.
- `class-f3base-vocabulario.php` sem `cabecalhos.csp_frame_ancestors` e com
  `cabecalhos.permissions_policy` de um valor só. O plugin 1.0.0 governa as duas e aceita o
  vazio. O implantador validava o catálogo de decisões contra o vocabulário ANTIGO em cima de
  um plugin novo — e a gravação funciona, então nada acusava.
- `class-f3base-chaves-seo.php` e `class-f3base-emissores.php` diferindo em comentário. Diferem;
  e um detector que aceitasse "só comentário" seria um detector que precisa entender PHP para
  decidir o que é igual.

E o contrato de nomes: o publicado declara `f3base_proveniencia` e `f3base_operaveis` como
FRONTEIRA — gravadas pelo implantador, lidas pelo plugin — e a cópia da 1.7.4 não. As duas
sobreviviam à renomeação só porque a ferramenta derivava grafias de `fontes/plugin/`; sem esse
diretório, a preservação delas passa a depender do contrato vendorizado — que precisa ser o
publicado. Medido: renomeação para `acme` na 2.0.0 preserva as duas, e
`renomeacao.contrato_de_nomes_completo` continua lendo o catálogo de options e a declaração de
eventos de dentro da reserva.

**Uma tabela de digestos foi recusada.** `VENDORIZADO.tsv` declara QUAIS arquivos e DE ONDE, e
não o `sha256` de cada um: um lock à mão seria uma segunda representação do zip, e a
comparação byte a byte com a reserva já responde a pergunta a cada rodada.

**O que custa.** Toda release do plugin obriga a reextrair seis arquivos. É mecânico e está
escrito em `VENDORIZADO.tsv`; pulá-lo é acusado nomeando o arquivo.

**Como reverter.** Voltar a editar `partilhado/` à mão é acusado por
`pacote.copia_vendorizada_confere` no primeiro byte diferente. Tirar um arquivo da declaração
é acusado por "existe em `partilhado/` e não está declarado".

---

## 116. Tudo o que a suíte lê do plugin sai de dentro da reserva, e a fixture em claro é a única exceção

**Decidido.** `f3b_fonte_do_plugin()` e `f3b_arquivos_do_plugin()` (`suite/lib/regra.php`) são o
caminho único: catálogo de options, `segredos_do_site()`, `PREFIXO_SECAO`, as marcas do
carregador de tags, o cliente de tracking e o de consentimento, a classe de habilidades de
configuração — tudo é lido por `unzip -p` de dentro de `assets/plugins/<slug>-<versão>.zip`.
As checagens que dependiam disso foram repontadas: `renomeacao.*`,
`tracking.emissor_unico_discrimina`, `estatica.segredo_fora_da_configuracao`,
`estatica.hidden_governa_visibilidade`, `estatica.option_gravada_sem_leitor`,
`doc.afirmacao_conferida` (a regra `codigo.chamada` varre também o plugin de dentro do zip) e
`js.banner_de_consentimento`. Uma fixture do piso pode trazer `fontes/plugin/` em claro, e só
responde quando a raiz varrida não tem reserva nenhuma.

**Por quê.** Medir a fonte é medir uma cópia. O que o site instala é o zip, e é o zip que a
suíte tem de abrir. A exceção existe por legibilidade: um defeito plantado dentro de um zip é
um defeito que ninguém enxerga no diff, e piso ilegível é piso que ninguém corrige. No pacote
real o caminho em claro está morto dos dois lados — a reserva sempre existe, porque o
empacotamento aborta sem ela, e `pacote.allow_list` recusa qualquer `fontes/plugin/` que
reapareça.

**O que custa.** Um subprocesso por leitura. A reserva é memorizada por raiz e por assinatura
dos zips — caminho, tamanho e data —, para que uma reserva trocada no meio de uma rodada (a
sonda da renomeação copia árvores) não responda do cache velho.

**Como reverter.** Fazer uma checagem ler `fontes/plugin/` de novo é escrever um caminho que
não existe no pacote real: a checagem fecha BLOCKED por escopo vazio, que é o que
`emitir()` faz com zero unidade medida.

---

## 117. A reserva versionada passa a INSTALAR, e o artefato local passa pelo digesto

**Decidido.** Em `F3Base_Imp_Plugins::aplicar_instalavel()`, quando o download pela URL
declarada falha, `reserva_versionada( $slug )` resolve `assets/plugins/<slug>-<versão>.zip` e
a instalação continua por ela — nomeando, na linha, que a URL não respondeu e por quê. A
precedência declarada é operador (`assets/plugins/<slug>.zip`, sem número) → URL → reserva
versionada. O artefato LOCAL — slot do operador ou reserva — passa pela mesma conferência de
digesto que o download passaria quando a origem declarada é `url`: reserva com digesto
diferente do declarado NÃO instala, e a linha nomeia os dois valores.

Quatro limites, todos medidos na bancada de instalação: (1) a reserva só responde por origem
`url` declarada — um plugin do wordpress.org não tem reserva que este pacote responda por, e
responder por uma que calhasse de existir instalaria sem conferência nenhuma; (2) o artefato
local CONFERE o digesto declarado e nunca o FIXA — fixar é ato do download, porque fixar a
partir de um zip local gravaria como "o publicado" o que quer que esteja no disco; (3) a
guarda de nunca-downgrade vale para a reserva também, comparando a instalada com a versão do
CABEÇALHO de dentro do zip da reserva — a mesma fonte de `$instalada` —, e com a instalada à
frente a reserva não instala e a linha diz qual das duas ficou; (4) duas reservas do mesmo
slug não escolhem uma — `reserva_versionada()` devolve vazio com o motivo nomeando as duas,
porque ordenar por nome escolheria `x-1.10.0` antes de `x-1.2.0`, que não é regra que alguém
declarou.

**Por quê.** O DEFEITO durou da 1.7.0 à 1.7.4 com todos os documentos afirmando o contrário.
`resolver_origem()` conhecia o slot do operador e a URL. A reserva versionada era resolvida por
`artefato_do_papel()` — para `plugins.site_core_versao` e para os entregáveis — e por mais
ninguém: com a URL fora do ar, `plugins.instalado:base-site-core-fator3` fechava BLOCKED. A
frase "se a URL não responder, o resolvedor cai na reserva embutida" estava no README, no
TEMPLATE, no catálogo de decisões e neste documento, e era falsa. A bancada não via porque
MONTAVA o slot do operador para se testar: o resolvedor respondia por ele antes de tentar a
URL, e o caminho "URL não responde → reserva" nunca foi percorrido por rodada nenhuma.

Na 2.0.0 a bancada declara `wp_remote_head()` falhando — esta bancada não tem rede, por
construção — e o caminho REAL é percorrido: a fita registra a tentativa da URL, a reserva
responde, e o digesto declarado é conferido sobre ela (teto). O piso planta, por reflexão no
cache de `F3Base_Imp_Decisoes`, um `sha256` diferente no catálogo e exige que a reserva seja
RECUSADA e nada instalado.

**O que custa.** O slot do operador, que instalava sem conferência, passa a ser conferido
quando a origem declarada é `url`: um zip embutido à mão que não seja o publicado deixa de
instalar. É o preço de "reserva é o mesmo artefato" valer também para quem embute por decisão
explícita — e a linha nomeia o caminho local em vez de uma URL.

**Como reverter.** Tirar o ramo da reserva de `aplicar_instalavel()` reprova
`instalacao.limpa_le_de_volta` no teto ("a origem que respondeu não foi a reserva versionada");
tirar a conferência do artefato local reprova o piso do digesto; tirar a guarda de
nunca-downgrade reprova o teto que planta 9.9.9 instalada e exige que ela fique.

---

## 118. Cinquenta e nove checagens saem declaradas, e uma fica: a que mede o par tema × plugin

**Decidido.** `suite/excluidas.tsv` lista toda checagem que a 1.7.4 emitia e esta suíte não
emite mais, com categoria fechada — `plugin` (o objeto mudou de repositório), `substituida` (a
pergunta continua respondida aqui por outra linha), `instrumento` (media um passo do
empacotamento que não existe mais) — e motivo em uma frase. `excluidas.declaradas` confere que
cada linha nomeia uma checagem NÃO emitida nesta rodada, com categoria do vocabulário e motivo;
o piso planta uma linha sobre checagem emitida, uma categoria fora do vocabulário e um motivo
vazio. O arquivo é o espelho do `excluidas.tsv` do repositório do plugin, que declara do lado
de lá o que ficou aqui. `js.banner_de_consentimento` FICA: ela mede o par `style.css` do TEMA
× cliente de consentimento do PLUGIN (lido do zip), e nenhum dos dois repositórios mede o par
sozinho — o repositório do plugin a excluiu com esse motivo.

**Por quê.** `manifesto.bidirecional` acusa requisito sem checagem e checagem sem requisito;
não acusa o requisito APAGADO junto com a checagem. Rótulo que some é indistinguível de rótulo
esquecido, e é assim que a cobertura encolhe sem que nada acuse. O repositório do plugin
resolveu o mesmo problema com a mesma tabela, e o espelho é o que permite conferir, dos dois
lados, que nenhum fato ficou sem dono.

**O que custa.** "Pacote aprovado" passa a ter duas metades: a rodada desta suíte e a rodada
selada do repositório do plugin, cujo digesto é o que o catálogo declara. Um pacote verificado
aqui sem a rodada de lá é um pacote com metade da medição — e a metade que falta inclui a única
checagem que roda o cliente entregue num navegador de verdade.

**Como reverter.** Apagar uma linha de `excluidas.tsv` sem devolver a checagem é acusado por
nada — e é por isso que a tabela é ESPELHADA: a linha correspondente do outro lado continua
dizendo que a checagem ficou aqui. Devolver uma checagem sem apagar a linha é acusado por
`excluidas.declaradas` ("declarada excluída e emitida").

---

## 119. A fronteira do validador ganha checagem: o que o plugin espera encontrar dentro do implantador

**Decidido.** `mcp.fronteira_do_validador` lê, de dentro da reserva, a classe de habilidades de
configuração do plugin (`class-f3base-config-mcp.php`), extrai o que ela espera encontrar dentro
da pasta do implantador — a classe que carrega (`includes/class-f3base-imp-config.php`), o método
público e estático que chama para validar antes de gravar (`F3Base_Imp_Config::validar_com_schema`)
e os quatro arquivos de configuração e schema que lê e grava — e confere que cada um existe
nesta árvore. Fixture negativa: um método que o implantador não tem e um schema ausente.

**Por quê.** A entrega do plugin 1.0.0 registrou que as habilidades `f3base/config-ler` e
`f3base/config-escrever` "morriam ao ser chamadas" por um schema mal formado, e deixou como
pendência desta fase "a medição da gravação real por `config-escrever` — que depende do
validador do implantador e se mede na suíte dele". Esta é a suíte dele. A validação em si já
tinha teto e piso — `projeto.schema_valida` e `config.schema_valida`, pelo MESMO método que o
plugin chama —; o que faltava era a fronteira: nada conferia que o método que o plugin publicado
chama existe do lado de cá com esse nome, e uma chamada a método inexistente morre em fatal
dentro da habilidade, no site, com o build dos dois lados em verde.

**O que custa.** A checagem extrai a fronteira por forma — `F3Base_Imp_<Classe>::<metodo>(` e
literais `config/…` — e não por análise sintática: um plugin que passasse a montar o nome do
método em tempo de execução escaparia dela. É o mesmo limite de todo detector deste pacote, e
ele está escrito ao lado da regra.

**Como reverter.** Renomear `validar_com_schema()` deste lado reprova a checagem nomeando o
método e o efeito.

---

## 120. O piso de `pacote.build_fresco` declara o relógio, em vez de confiar no mtime do checkout

**Decidido.** `f3b_piso_com_relogio_declarado()` (`suite/lib/piso.php`) fixa, antes de cada ramo,
o carimbo dos arquivos da fixture: negativa com o artefato em 2000-01-01 e a fonte agora — o
defeito —, positiva ao contrário. Os arquivos são os da fixture; só o carimbo é fixado.

**Por quê.** É a pendência que a entrega do plugin deixou nomeada. A fixture negativa
reproduzia "artefato mais velho que a fonte" pelo MTIME gravado em disco, e mtime é reescrito por
qualquer cópia de árvore — `git clone`, `cp` sem `-a`, extração de um zip, um checkout de CI.
Num clone novo os dois arquivos nascem no mesmo segundo, o defeito plantado deixa de existir e
o piso acusa o instrumento por um acidente do sistema de arquivos. É a mesma doença da decisão
112, um andar abaixo: relógio que entra pela porta do disco. Medido: com os dois arquivos da
fixture tocados para "agora", os dois ramos continuam provando.

**O que custa.** O piso ESCREVE mtime dentro de `suite/fixtures/`. Conteúdo não muda, hash não
muda; o que muda é que a rodada seguinte de `verificar.sh` vê fixtures mais novas que o bundle
anterior — e reempacota, que é o que ela faz sempre.

**Como reverter.** Voltar a chamar `f3b_ck_build_fresco()` direto sobre a fixture faz o piso
depender do checkout de novo, e a primeira máquina que copiar a árvore sem preservar mtime
reprova o ramo negativo.

---

## 121. Versão e bytes são dois fatos, e cada um tem a sua linha

**Decidido.** `plugins.site_core_versao` continua sendo a linha da VERSÃO — instalada contra a
que o NOME da reserva carrega — e não distingue dois artefatos com o mesmo número e bytes
diferentes. Quem distingue é o DIGESTO: o `sha256` declarado no catálogo, conferido pela
instalação sobre o download e sobre a reserva, e a linha `plugins.instalado:<slug>` que o
nomeia. Fundir os dois na linha de versão foi recusado.

**Por quê.** A entrega do plugin deixou a pergunta em aberto: "o desenho de
`plugins.site_core_versao` diante de versão igual com bytes diferentes". A resposta é a da
decisão 107 pelo outro lado — um fato, uma linha, um veredito, e portanto DOIS fatos, DUAS
linhas. `version_compare()` não separa bytes, e ensiná-lo a separar seria medir o mesmo fato em
duas linhas com regras próprias, que é o defeito da 1.7.2. Com o digesto declarado (decisão
114), o caso "mesmo número, bytes diferentes" já é acusado onde ele acontece: na instalação,
antes de qualquer arquivo entrar no site.

**O que custa.** A linha de versão continua sem acusar uma instalação de teste com o mesmo
número — a consequência que o README do plugin já declarava. O implantador troca assim mesmo,
porque a condição dele para pular a troca exige versão igual E hash do diretório igual.

**Como reverter.** Não há o que reverter em código; há o que não fazer, e está escrito no
docblock de `relatar_versao_do_site_core()`.

---

## 122. `faketime` sai, e o instrumento de montagem do plugin vai embora com ele

**Decidido.** As pré-condições do comando único são `php`, `node`, `zip` e `unzip`.
`faketime`, `suite/lib/sonda-montagem.php`, `ferramentas/tokenizador-js.php`,
`suite/sonda-navegador/`, `suite/lib/sonda-site-core.php` e `suite/lib/sonda-migracao.php` saem
da árvore. A rodada cai de 44 para cerca de 17 segundos.

**Por quê.** Cada um deles media ou instrumentava o plugin: o relógio movido e o volume trocado
provavam que ESTE repositório montava o zip do plugin de forma reprodutível; o tokenizador
cortava o comentário do JavaScript que entrava no zip; a sonda de navegador dirigia o cliente
ENTREGUE; as duas sondas em PHP rodavam o endpoint de leads, a cadência, o llms.txt, a medição
e a migração contra `fontes/plugin/`. Nada disso tem objeto aqui. O repositório do plugin faz
cada uma dessas medições contra o zip que ele mesmo sela — e é o digesto desse zip que este
repositório declara e confere.

**O que custa.** A linha `navegador.comportamento_real` não sai mais desta rodada, e a regra da
decisão 97 continua valendo: um pacote verificado sem navegador não é um pacote aprovado. A
diferença é onde o navegador roda — na rodada do plugin, cujo selo é o `sha256` do catálogo. Um
operador que aprove este pacote sem a rodada de lá está aprovando metade.

**Como reverter.** Devolver `faketime` à lista de pré-condições sem devolver o empacotamento do
plugin faria o comando único recusar rodar por um recurso que nenhuma linha usa — o motivo da
lista está escrito ao lado do laço, e é a primeira coisa que alguém lê ao mexer nela.

---

## 123. O carimbo e a árvore gerados ignoram os produtos da rodada, e o hash de um clone limpo é o da rodada seguinte

**Decidido.** A linha "Arquivos no pacote" do carimbo conta as FONTES — `f3b_fontes()` menos
`f3b_produzidos_pela_rodada()` —, e a árvore gerada lista `suite/rodada.json` e
`suite/fases.json` sempre, com a nota de que nascem no fim do comando único, existam ou não
em disco no momento da escrita.

**Por quê.** Medido na verificação da 2.0.0, num clone limpo — sem `dist/` e sem
`suite/rodada.json`: a primeira rodada selou `009994c5…` e a segunda, sobre a árvore
idêntica, `10bac824…`. A causa era o próprio documento: o carimbo contava os arquivos do
pacote, a árvore os listava, `suite/rodada.json` só existe DEPOIS da primeira rodada, e os
três documentos entram na soma do hash. A afirmação "duas rodadas sobre a mesma árvore dão o
mesmo hash" era verdadeira a partir da segunda rodada e falsa na primeira — que é exatamente a
rodada que um clone de CI ou um agente novo faz. A régua é a da decisão 84: o que responde
"quando" fica fora do que responde "o quê".

**O que custa.** A árvore gerada lista dois caminhos que, num clone limpo, ainda não existem.
A nota ao lado diz por quê, e `pacote.allow_list` já os tratava assim — inventariados e
ausentes até a rodada gravá-los.

**Como reverter.** Voltar a contar `f3b_fontes()` inteiro reprova nada por si — e é por isso
que o caso está escrito aqui, com os dois digestos: o piso desta regra é o procedimento da
seção de verificação do README, clone limpo e duas rodadas com o mesmo hash.

---

## 124. Grafia preservada na renomeação é a que o CÓDIGO do plugin usa — a prosa dele deixa de contar

**Decidido.** `f3b_np_texto_de_codigo()` decide o que de cada arquivo do plugin entra na
derivação de grafias preservadas: PHP passa pelo tokenizador e perde `T_COMMENT` e
`T_DOC_COMMENT`; JS e CSS perdem os blocos `/* */` e as linhas que começam por `//`; TSV
fica com as linhas de dados; Markdown e texto puro não entram. `f3b_np_grafias_da_reserva()`
e `f3b_np_grafias_do_diretorio()` passam por ela. A regra tem checagem própria,
`renomeacao.preservados_so_do_codigo`, medida em `sonda-renomeacao.php`: cinco amostras
plantadas contra a regra pura, e uma quarta cópia do pacote cuja reserva ganhou um arquivo
com uma grafia só em comentário e outra só em código — renomeada de verdade, a da prosa
PRECISA virar `acme_` e a do código PRECISA ficar. O piso é a varredura sem o corte, o
comportamento antigo, que PRECISA capturar a prosa.

**Por quê.** Medido na verificação da 2.0.0, sobre o pacote renomeado para `acme`:
`includes/class-acme-imp-lotes.php` saiu com `OPTION_LOCK = 'f3base_lock'`,
`OPTION_CHECKPOINT = 'f3base_checkpoint'`, `OPTION_ESTADO = 'f3base_estado_aplicacao'`,
`OPTION_RELEASE = 'f3base_release'`, `OPTION_FASES = 'f3base_fases'`, e o journal com
`f3base_journal` — as seis options que o próprio contrato de nomes do plugin declara, num
comentário, como estado SÓ DO IMPLANTADOR, que "viram `<prefixo>_*` como todo o resto". A
derivação lia o arquivo inteiro, capturava os seis nomes DO COMENTÁRIO e os preservava; ao
todo quinze grafias que nenhum código do plugin usa. `estatica.sem_residuo_de_prefixo`
fechava OK porque a lista de preservadas as absolvia. O defeito vinha desde que a derivação
existe (decisão 101, 1.7.0) e sobreviveu à 1.7.x inteira: a fonte em `fontes/plugin/` era lida
do mesmo jeito. A consequência prática: dois implantadores derivados deste template no mesmo
WordPress disputariam o mesmo `f3base_lock` e leriam o checkpoint um do outro.

A regra é a que o nome da função diz. Prosa não USA nome nenhum — ela fala sobre nomes —, e
uma lista de preservadas que cresce com o que alguém escreveu num comentário é uma lista que
ninguém controla.

**O que custa.** Um nome que o plugin monte em tempo de execução e só cite em comentário não
é derivado — mas ele já não era: a derivação nunca alcançou nomes montados (decisão da grafia
nua com separador, no próprio `f3b_np_grafias_do_texto()`). O contrato de nomes continua
sendo o lugar de declarar o que o código não mostra. As amostras da sonda e o plantio são
montados do prefixo declarado em `ferramentas/prefixo-do-template.tsv`, não digitados: a
sonda também é renomeada quando o pacote é, e uma amostra digitada mediria o prefixo errado
no pacote derivado.

**Como reverter.** Fazer `f3b_np_texto_de_codigo()` devolver o texto inteiro reprova
`renomeacao.preservados_so_do_codigo` em onze achados, medido: os cinco casos da regra pura e
o de ponta a ponta.

---

## 125. A revisão adversarial da 2.0.0: dezesseis defeitos no código novo, e o que cada um custou

**Decidido.** Antes de selar a 2.0.0 o código novo passou por uma revisão adversarial —
outro leitor, com a instrução de procurar onde a regra nova se apaga sozinha — e os dezesseis
achados confirmados foram corrigidos, sete no host e nove na suíte. Os do host estão na
decisão 117 (os quatro limites da reserva). Os da suíte: a chave do cache de
`f3b_reserva_do_site_core()` inclui `config/decisoes.tsv` (slug e pasta saem dele); o achado
de reserva ilegível no bundle relata o que o `unzip` disse; o piso da reserva ganha os
mutantes de versão ilegível no nome e no cabeçalho; o diretório temporário da sonda do bundle
é apagado ANTES de ser criado (um PID reutilizado respondia com a extração de outra rodada);
`f3b_piso_com_relogio_declarado()` devolve o caminho sem tocar quando o artefato não existe
(o `touch` criava um zip vazio e apagava o defeito que a fixture planta); a sonda de
renomeação apaga o arquivo temporário do cliente também nas saídas de erro;
`f3b_empacotar()` devolve `documentos` nas duas saídas antecipadas (o relatório as lia);
o laço morto do "peso entregue" saiu de `executar.php` (a chave que ele lia deixou de existir
na 2.0.0); a mensagem de `estatica.carimbo_de_release_nos_documentos` deixou de nomear
`fontes/plugin/INSTRUCOES-DO-PLUGIN.md`; e `fonteDoPlugin()` em `js.mjs` lê a pasta do
plugin da primeira entrada do zip, não do nome do arquivo — a mesma fonte que
`pacote.reserva_confere_com_o_catalogo` confere.

**Por quê.** Nenhum dos dezesseis reprovava a suíte: a rodada fechava FALHA 0 com todos eles
no lugar. É o argumento de sempre deste documento, medido de novo — checagem que nunca falhou
não é evidência —, e a razão de a revisão ser parte do método e não um extra: o mesmo autor
que escreveu a regra escreveu o teste dela, e os dois têm o mesmo ponto cego.

**O que custa.** Uma rodada de leitura por outra parte antes de cada release, com o resultado
escrito aqui: achado, correção, e o que passaria a reprovar se a correção fosse desfeita.

**Como reverter.** Não se reverte uma revisão. O que fica é a lista, para a próxima.

---

## 126. O implantador é executado uma vez por site, e o terceiro eixo do encerramento sai inteiro

**Decidido.** Pelo dono, em 2026-09-07, depois de ler o log da primeira implantação real da
2.0.0: o implantador é executado UMA VEZ por site; os ajustes seguintes são feitos pelo
canal MCP. Saíram, inteiros: o gate `convergencia` (o vocabulário de gates fica com TRÊS
valores — `aplicacao`, `fase`, `relato`), o metadado `precondicao` e a derivação do gate a
partir dele em `emitir()`, `veredito_de_convergencia()`, as constantes `CONVERGIU`,
`CONVERGENCIA_PENDENTE` e `NAO_CONVERGIU`, a linha `entrega.convergencia`, a frase de
convergência do encerramento e o ramo de "pendências de convergência" no veredito da
unidade. Com eles saíram as checagens `lotes.gate_de_aplicacao_sem_dado_do_operador` e
`estatica.precondicao_no_eixo`, declaradas em `suite/excluidas.tsv` na categoria nova
`retirada`.

**Por quê.** O eixo existia (decisões 40 e 41, 1.0.17–1.0.19) para responder "o site está
completo?" separadamente de "o implantador terminou?", e a resposta dele era sempre a mesma
frase: preencha o dado do operador e execute de novo. A operação não tem esse ciclo: o dado
do operador é preenchido ANTES da execução única ou ajustado DEPOIS pelo canal, e um eixo
cuja única saída descreve um ciclo que ninguém executa é ruído com nome de método. A
idempotência NÃO saiu — continua sendo propriedade do código, medida pelas mesmas bancadas
(retomada por checkpoint, gravação de três vias, o laço que não repete o que já foi
aplicado); o que saiu foi a reexecução como forma de operar.

**O que custa.** O encerramento deixa de dizer "o site ainda não está completo". Quem quiser
saber o que ficou por preencher lê as linhas N/A das unidades (o regime WhatsApp nomeia a
chave vazia) e os marcadores da política. É o preço declarado: o implantador não cobra mais
dado que não é dele.

**Como reverter.** Não se reverte sem devolver o ciclo de reexecução como método de operação
— e essa é a decisão que o dono tomou.

---

## 127. O aviso da base legal e a checagem do controlador saem: o texto jurídico é de quem responde por ele

**Decidido.** Pelo dono: `lgpd.base_legal_declarada` (WARN quando `fato_juridico.base_legal`
estava vazia) e `privacidade.controlador_identificado` (BLOCKED quando razão social,
documento ou endereço do controlador estavam vazios) SAEM. Com a segunda sai a GUARDA que
rebaixava a política de privacidade a rascunho: `veredito_de_status_de_pagina()` devolve o
status DECLARADO, e `status_efetivo_de_pagina()` continua sendo o produtor único — a regra de
fonte única é sobre haver um produtor, não sobre o produtor decidir. Saem também
`projeto.fato_juridico_coerente` e `veredito_do_fato_juridico()`, e os auxiliares da guarda
em `F3Base_Imp_Conteudo` (`GUARDA_CONTROLADOR`, `chaves_de_publicacao_do_controlador()`,
`faltando_no_controlador()`, `saida_da_guarda_do_controlador()`, `veredito_do_controlador()`,
`veredito_da_checagem_do_controlador()`). Ficam a interpolação dos marcadores
(`interpolar_com()`, os blocos condicionais do encarregado) e a identidade da política pelo
papel declarado — medidas agora por `conteudo.politica_de_privacidade`.

**Por quê.** "Não é responsabilidade do implantador esse tipo de aviso. É responsabilidade
do usuário verificar." O que a política afirma — sob qual hipótese do art. 7º os leads são
tratados, quem é o controlador — é de quem responde por ela; o implantador interpola o que
recebe e não confere texto jurídico de ninguém.

**O que custa, e é dito com todas as letras.** Com `contato.controlador.*` vazio a política
PUBLICA, e o lugar de cada valor fica vazio à vista de quem ler. Com `base_legal` vazia a
política publica sem a hipótese. O operador preenche `config/projeto.json` ANTES da execução
única (o `$comment` de cada campo diz o que preencher e onde obter) ou edita a página pelo
canal DEPOIS. O texto de `content/pages/privacidade.html` que descrevia a guarda foi
reescrito, e o contrato de copy (`publicacao-com-status-declarado`) exige a frase nova.

**Como reverter.** Devolver a guarda a `veredito_de_status_de_pagina()` reprova
`conteudo.politica_de_privacidade` no teto do status ("a guarda do controlador foi
retirada na 2.1.0 e o status é o declarado").

---

## 128. O sequestro do lote por assistente de terceiro é comportamento esperado, fecha OK, e o mapa de supressão aceita transiente

**Decidido.** No cliente, o sequestro detectado pelo discriminante (sentinela de início
ausente, marcador de wp-admin presente) não registra linha no momento em que acontece: a
unidade é repetida uma vez, e UMA linha sai depois — OK, com a evidência da requisição
sequestrada anexada e o slug do último plugin ativado nomeado — quando a repetição funciona;
FALHA, como antes, quando o sequestro se repete. No servidor, `plugins.supressao_onboarding`
aceita entradas `transiente:<nome>` além de `option.chave`, e a entrada do servidor do canal
declara `transiente:wp_mcp_ultimate_activated`, apagado na MESMA unidade que ativa, com a
leitura de volta de `get_transient()` devolvendo falso.

**Por quê.** O log real trouxe dois WARN sobre um evento que acontece em toda instalação
limpa e termina bem: o `wp-mcp-ultimate` grava um transiente na ativação e, no `admin_init`
seguinte, redireciona para a própria tela e o apaga (`includes/Plugin.php`,
`maybe_redirect_to_dashboard()`, lido no site). `admin_init` roda antes de `admin_post`, e a
requisição do lote seguinte à ativação voltava com HTML do painel. A 1.0.17 tinha lido o
plugin, visto que era transiente e concluído que "não se desarma por configuração nenhuma" —
o que era verdade para um mapa que só aceitava option. A saída é o mapa aceitar o que o
plugin usa, e o nome vem do código dele, publicado no mesmo repositório que o site-core.

**O que custa.** Um transiente apagado antes de o plugin lê-lo é um assistente de boas-vindas
que nunca abre — que é o que se quer numa implantação por agente. Se o plugin trocar o nome
do transiente, a entrada envelhece e o sequestro volta a acontecer uma vez, absorvido pela
repetição: a linha OK nomeia o slug e o que evitaria a ida e volta.

**Como reverter.** `plugins.supressao_por_transiente` reprova sem a entrada do servidor do
canal e sem o reconhecimento do prefixo no código da supressão.

---

## 129. O `/llms.txt` é o do site-core, e o emissor do plugin de SEO fica desligado — sempre

**Decidido.** `aplicar_geral()` grava `enable_llms_txt => false` como literal; a unidade
`seo_llms` passa a ser `seo.llms_proprio` (`aplicar_llms_proprio()`): relê a chave do banco,
remove o agendamento `wpseo_llms_txt_population`, apaga o arquivo físico `llms.txt` da raiz
SE ele for do plugin de SEO (assinatura no corpo — regra pura
`veredito_do_arquivo_fisico_de_llms()`; arquivo de outra origem é preservado e nomeado), e
fecha OK só com os três fatos relidos. `wpseo_llmstxt` deixa de ser gravada;
`id_llms_de_pagina()` e o par dela na âncora `produtor_de_item_llms()` saem;
`bots_ia.llms_txt` governa só o módulo do site-core. Checagem estática nova:
`estatica.llms_proprio_sem_concorrente` (três cláusulas, com fixtures).

**Por quê.** Medido no site em 2026-09-07: com a chave ligada, o plugin de SEO gravava um
arquivo físico na raiz, e a precedência que o próprio site-core declara — arquivo físico >
concorrente ligado > nossa rota — entregava o endereço a ele. A seleção curada ia para
`wpseo_llmstxt` com as chaves `manual`, `pages` e `privacy_policy`, que a versão 28.4 do
plugin NÃO lê (ela lê `llms_txt_selection_mode`, `other_included_pages`, `contact_page`,
`privacy_policy_page`…, lido em `src/llms-txt/infrastructure/content/manual-post-collection.php`
no site). O arquivo publicado era a seleção AUTOMÁTICA do plugin — "Contato" selecionada e
fora, "Blog" não selecionada e dentro — e `seo.llms_selecao` fechava OK medindo a própria
escrita; o próprio código admitia que "os nomes das chaves são fato do fornecedor". O dono
decidiu: o llms.txt é o próprio. Verificado no site: desligada a chave pelo canal, o plugin
removeu o arquivo e `/llms.txt` passou a responder pela rota do site-core
(`x-f3base-mecanismo: rota-reserva`) com a seleção curada na ordem declarada.

**O que custa.** O llms.txt do plugin de SEO deixa de existir como opção neste pacote. Quem
quiser usá-lo edita `aplicar_geral()` e devolve o produtor à âncora — e a checagem estática
diz onde.

**Como reverter.** Trocar o literal por uma decisão reprova
`estatica.llms_proprio_sem_concorrente` na primeira cláusula; gravar `wpseo_llmstxt` de
novo reprova a segunda.

---

## 130. Os padrões da instalação limpa saem: temas de fábrica, Akismet e Hello Dolly, pela lista

**Decidido.** Nova unidade `limpeza` (`F3Base_Imp_Limpeza`), depois de `tema` e antes de
`site_core`, dependendo de `tema`. Remove o que `limpeza.temas_padrao` e
`limpeza.plugins_padrao` declaram em `config/decisoes.tsv` — os três temas Twenty
Twenty-Três/Quatro/Cinco, `akismet/akismet.php` e `hello.php` —, por `delete_theme()` e
`delete_plugins()`, desativando plugin ativo pela API do núcleo antes, com leitura de volta
e journal declarado IRREVERSÍVEL com o motivo. A regra pura `plano()` nunca remove o tema
ativo nem o pai dele (PULAR, nomeando), item não instalado é AUSENTE, lista vazia é plano
vazio, e nada fora da lista é tocado; `limpeza.plano_dos_padroes` tem teto e piso sobre
ela. O plugin de painel da hospedagem NÃO está na lista.

**Por quê.** Pelo dono: a implantação real entregou o site com os cinco no lugar — código
que ninguém pediu, listado no painel, alcançado pela atualização automática (a flag foi
ligada para o Akismet) e presente em todo relatório de superfície instalada.

**O que custa.** Remover o Twenty Twenty-Cinco tira do núcleo o tema-reserva
(`WP_DEFAULT_THEME`): se o tema ativo quebrar, não há para onde cair. A decisão é essa
mesma — tema que quebra neste pacote é defeito de release medido antes de sair, e a reserva
do núcleo era um site alheio no ar —, e a linha da unidade diz isso quando acontece. A
remoção não tem inversa automática; o journal a declara irreversível e diz por onde o tema
volta.

**Como reverter.** Esvaziar as listas fecha a unidade em N/A sem remover nada; tirar a
unidade do plano reprova `limpeza.plano_dos_padroes` por escopo (e a suíte do manifesto
pela linha órfã).

---

## 131. O post de exemplo é identificado pelo texto, e a data de modificação deixa de decidir

**Decidido.** `veredito_de_exemplo_do_wordpress()` perde a cláusula "`post_modified_gmt`
igual a `post_date_gmt`": título e conteúdo idênticos ao que `wp_install_defaults()` escreve,
objeto não gerenciado e não em uso, vão para a lixeira. O caso do bench "texto idêntico e
data avançada" passou de MANTER para LIXEIRA.

**Por quê.** Medido: o instalador da DreamHost toca o `Hello world!` dois segundos depois de
criá-lo (`post_modified_gmt` 16:03:10, `post_date_gmt` 16:03:08). A 2.0.0 o preservava como
"editado", e ele foi ao ar — no sitemap, no llms.txt, com a categoria Uncategorized junto.
Quem edita muda o texto; a data que um instalador toca não é texto. O dono pediu a remoção
do post que vem por padrão, e a cláusula da data era o que a impedia sem que nada acusasse.

**O que custa.** Um post cujo texto continue idêntico ao do núcleo e que alguém tenha, de
propósito, "salvo" sem mudar nada vai para a lixeira — reversível com um clique. É um caso
que não existe fora de bancada.

**Como reverter.** Devolver a cláusula reprova o caso do instalador da hospedagem em
`conteudo.exemplo_do_wordpress`.

---

## 132. O formulário é posto na página lida do arquivo certo, e a colocação reprova quando não chega

**Decidido.** `F3Base_Imp_Lotes::pagina_ref_do_regime()` lê a página do regime de
`config/projeto.json`, onde o bloco `formularios` mora; `F3Base_Imp_Formulario::por_na_pagina()`
é pública, devolve `{ok, motivo}` e a unidade fecha FALHA quando a página declarada fica sem
o formulário — referência vazia, referência que não resolve, gravação recusada ou leitura
de volta sem o shortcode. A página de confirmação recebe a meta de noindex do vocabulário
compartilhado. O `$comment` de `caixa_de_leads` no schema passa a dizer o que o código faz
(vazio não desliga o regime; o aviso vai para `admin_email`). Checagem nova:
`formulario.na_pagina_declarada`.

**Por quê.** Medido em 2026-09-07 (vinha da 1.7.4): `pagina_ref` era a única chave do bloco
lida por `F3Base_Imp_Config` (config/site.json), voltava vazia, `por_na_pagina()` devolvia
vazio em todo caminho de falha, e o log disse "formulário #24 publicado" sobre um formulário
que não estava em página nenhuma. A bancada exercitava só `conteudo_com_formulario()` — a
regra pura — e não a ligação; é a forma de piso que a decisão 125 nomeou. E
`/solicitacao-recebida/` estava no sitemap, indexável.

**O que custa.** Um regime `cf7-email` cuja página declarada não existe passa a reprovar a
unidade de formulários — que é o que ele sempre deveria ter feito.

**Como reverter.** Ler `pagina_ref` por `F3Base_Imp_Config` reprova o piso de
`formulario.na_pagina_declarada` (o leitor errado devolve vazio para a chave real);
devolver `''` nos caminhos de falha reprova o teto da referência vazia.

---

## 133. Os digestos dos zips do canal são declarados, e o site-core é instalado uma vez

**Decidido.** `plugins.instalaveis.4` e `.5` ganham `sha256` no catálogo, medidos no download
do endereço publicado; e o laço `plugin_instalavel` PULA a entrada de papel `site-core`, que
tem unidade própria.

**Por quê.** O log real disse, sobre os dois zips do canal, "digesto NÃO declarado: medido e
FIXADO nesta primeira observação — fixar na primeira observação não é verificação de
integridade". Os dois são artefatos nossos, no mesmo repositório que o site-core, cujo
digesto já é declarado. E o site-core era baixado DUAS vezes por execução: a unidade
`site_core` instalava, e o laço baixava de novo para comparar por hash de diretório e
concluir "artefato idêntico".

**O que custa.** Publicar um zip novo do servidor ou do complemento exige declarar o digesto
novo no catálogo — a disciplina do site-core. Sem isso a instalação reprova nomeando os dois
valores, que é o comportamento certo para um artefato que mudou embaixo do catálogo.

**Como reverter.** Tirar o `sha256` devolve a fixação na primeira observação, com a linha
dizendo que ela não é verificação.

---

## 134. Os documentos que orientam o uso e a construção viajam dentro do pacote

**Decidido.** Pelo dono: `MAPA-DA-OPERACAO.md` (o mapa da operação) e
`INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md` (as instruções para construir um implantador) moram
na raiz do pacote, estão no inventário e no entregável novo `entrega.documentacao` (com
`MANIFESTO.md` e `TEMPLATE.md`), medido pela suíte e pelo host e somado ao gate de
aplicação. As instruções mandam, antes da primeira linha, ler os documentos de DENTRO do zip
e verificar ESPECIALMENTE o pacote do plugin Base Site Core Fator3 — o zip publicado, com
`INSTRUCOES-DO-PLUGIN.md` dentro, e a habilidade `f3base/como-usar` — porque o plugin é o
pacote essencial que sempre é instalado junto, e o tema e as páginas seguem as regras dele
para que ele fique completamente funcional.

**Por quê.** Quem recebe o zip precisa receber junto como ele se usa e como se constrói o
próprio; documento entregue fora do pacote é documento que se perde do pacote. E a lista do
que o plugin espera do tema e das páginas — as classes de seção, o CTA canônico, o controle
de consentimento, o link da política, o par CSS × cliente, o contrato de nomes, a fronteira
do validador — é o que separa um implantador que instala o plugin de um que o deixa
funcional.

**O que custa.** Dois arquivos a mais em todo bundle, e a renomeação de prefixo os atravessa
como atravessa o README.

**Como reverter.** Tirar qualquer um dos quatro caminhos reprova `entrega.documentacao` nos
dois lados.


---

## 135. Os posts moram sob um prefixo declarado, e os três caminhos saem de um produtor só

**Decidido.** Pelo dono: o conteúdo do blog deixa de responder em `/<slug>/` e passa a
responder em `/artigos/<slug>/`. A configuração ganha o bloco `conteudo.blog` com três
valores — `prefixo`, `titulo` e `categoria` —, e deles saem a estrutura de permalink
`/<prefixo>/%postname%/`, a base de categoria `<prefixo>/<categoria>` e o slug da página de
índice, que é o próprio prefixo. O rótulo do item de menu passa a "Artigos" e continua
sendo rótulo: ele pode divergir do título da página de propósito. Nenhuma data entra em
caminho nenhum, e os arquivos de data continuam desligados no plugin de SEO.

**Por quê.** O motivo não é posição em busca: o núcleo não usa profundidade de caminho como
sinal, e o prefixo não compra ranqueamento nenhum. O que a release fecha é a TRÊS FONTES.
Até a 2.1.0 o mesmo assunto era decidido em três lugares — o literal `'/%postname%/'` dentro
do lote de options, o slug do índice derivado do RÓTULO do item de menu, e o H1 do índice
escrito à mão no template do tema. Trocar o rótulo mudava o endereço do índice e não mudava
o dos posts; trocar a estrutura não mudava nem um nem outro; nada comparava os três, e a
coerência entre eles era coincidência. O prefixo em si compra o que é operacional: filtro
por caminho no relatório de desempenho e na análise de tráfego, escopo por caminho no
`robots.txt`, o arquivo de categoria no mesmo namespace do que ele lista, e a URL dizendo o
mesmo que a trilha de navegação. "Artigos" em vez de "blog" é decisão editorial e não
técnica: a segunda palavra tem conotação cronológica e opinativa, a primeira é o termo que o
falante de português usa para peça escrita de referência. Nenhuma das duas muda ranqueamento.

**O que foi lido no núcleo do WordPress antes de decidir**, porque o prefixo muda o roteador
e não se afirma comportamento de terceiro por dedução:

1. `use_verbose_page_rules` continua VERDADEIRO com prefixo — a guarda é
   `preg_match( '/^[^%]*%(?:postname|category|tag|author)%/', $permalink_structure )`, e
   `[^%]*` casa com `/artigos/`. Nenhum ganho de desempenho vem do prefixo.
2. Com ela verdadeira, as regras de página são mescladas ANTES das de post, e a regra de
   página é um curinga. O que impede o sequestro é `WP::parse_request()`: casando
   `pagename=$matches[N]`, o núcleo faz `get_page_by_path()` e, não existindo página
   naquele caminho, executa `continue` para a próxima regra. É por isso que
   `/artigos/meu-post/` chega à regra de post.
3. As regras de taxonomia são mescladas em `extra_rules_top`, o PRIMEIRO conjunto da união.
   Por isso `/artigos/categoria/metodo/` é resolvido pela regra de categoria antes de
   chegar à regra de anexo do permastruct de post, que de outro modo o transformaria em
   `attachment=metodo` e 404.

**A colisão que sobra, e ela virou detector.** A disputa página × post não desaparece: ela
encolhe para as páginas que morariam SOB o índice, e essas continuam vencendo pelo mecanismo
do item 2, em silêncio. `estatica.prefixo_do_blog_fonte_unica` reprova a configuração que
declare uma página com o prefixo como slug ou sob ele — e reprova também o segundo leitor da
chave e o token `%postname%` escrito fora do produtor.

**Três defeitos fechados junto.** (a) O retorno antecipado da decisão de permalinks saía sem
regravar as regras de reescrita; com a base de categoria gravada na mesma etapa, isso
deixaria o valor no banco e a regra velha no ar, sem erro, até alguém salvar permalinks à
mão. (b) A página de índice só nascia com item de menu, enquanto o entregável do blog já
considerava posts declarados OU item — posts sem item produziam post respondendo e índice em
404. (c) A trilha do plugin de SEO passa a declarar `breadcrumbs-display-blog-page`: o padrão
dele já é esse, e declarar é o que impede uma release dele de mudar a trilha do site sem uma
linha nossa mudar.

**O H1 do índice ficou literal, com detector.** A alternativa era um pattern PHP lendo a
página de posts a cada render — o conteúdo de pattern é avaliado em
`WP_Block_Patterns_Registry::get_registered()`, então funciona —, e ela põe uma leitura de
option no caminho de toda visita ao índice para resolver em runtime o que
`tema.indice_reflete_declaracao` resolve sem runtime nenhum.

**O que ficou de fora, com motivo.** `tag_base` continua vazia: as tags estão em noindex e o
template não declara nenhuma, e escrever option para caminho que ninguém serve nem indexa é
ruído. O rótulo interno `entrega.blog` e a ref `blog` da página de índice ficam: eles nomeiam
a COLEÇÃO de posts, não o caminho, a ref é identidade lógica por contrato do esquema, e
renomear rótulo custa linha em `suite/excluidas.tsv`, manifesto e selo sem mudar fato medido.
A grafia `/blog/` NÃO entrou em `copy_contrato.nao_podem_voltar`: o detector varre o pacote
inteiro, e uma memória de decisões que não pode nomear o caminho que substituiu é pior do que
o risco que a proibição evitaria — no lugar dela entrou uma grafia em `devem_aparecer`, que
amarra a frase do menu na página de arquitetura ao rótulo declarado.

**O que custa.** Um bloco a mais na configuração, com três chaves obrigatórias e prefixo que
não aceita vazio: quem quiser os posts na raiz muda código, e a decisão fica escrita. Sites
já implantados NÃO recebem esta release (execução única): a conversão de um site no ar é pelo
canal, com 301 por post, e o custo dela é reprocessamento de índice e perda de histórico por
URL nos relatórios.

**Como reverter.** Trocar os três valores do bloco devolve qualquer outro prefixo; o token
`%postname%` continua proibido fora do produtor, então a estrutura plana não volta por
edição de configuração.

---

## 136. Sem base de option, a proveniência declarada pelo plugin vence a primeira execução

**Decidido.** Relatado pelo dono e confirmado no código: instalado num site em que o
`Base Site Core Fator3` já estava configurado, o implantador sobrescrevia, na sua única
execução, o que um humano tinha gravado na tela de Medição e na de Configuração do plugin.
O caso `base === null` de `merge_option()` deixa de ser um ramo só e passa a consultar
`f3base_proveniencia`: option ausente, origem `padrao` e origem `implantador` continuam
sendo gravadas; origem `edicao-manual` e origem NÃO REGISTRADA são PRESERVADAS, sem mover a
base e sem carimbar origem nova sobre o valor preservado.

**Por quê, com o mecanismo.** O implantador roda UMA vez por site (decisão 126), então base
nula é o estado de toda execução real — e o ramo antigo aplicava o desejado sobre o
observado sempre, com a justificativa de que "nesta execução o pacote não tem como
distinguir uma edição de um valor que sempre esteve ali". Tinha: o plugin publica essa
distinção. Ele grava `edicao-manual` quando a tela dele grava, `padrao` quando a ativação
semeia o catálogo inteiro, e este gravador já gravava `implantador` a cada escrita sua. A
option é FRONTEIRA declarada em `partilhado/dados/contrato-de-nomes.tsv`, escrita pelos dois
lados. O que faltava era LER antes de decidir. O dano era silencioso por construção: os
slots de medição nascem VAZIOS no arquivo do projeto, então o valor aplicado por cima era o
vazio, e a option entrava na lista das que "nasceram" — em linha OK, que ninguém lê como
perda.

**O ramo que não podia mudar.** `padrao` continua sendo gravada, e é o piso mais importante
do bench: a ativação do plugin escreve TODA option catalogada com o padrão dela, então
depois de ativar o site-core todas existem. Um ramo que preservasse isso travaria toda
implantação limpa — nenhuma configuração chegaria ao banco.

**Origem não registrada tem nome próprio deste lado.** O plugin, sem entrada no registro,
devolve `implantador` por fallback; do lado dele o palpite é bom. Aqui ele seria licença
para gravar por cima: sem base, este pacote não escreveu aquele valor, e chamar de seu o que
não se sabe de quem é é o erro que esta decisão fecha.

**A preservação deixou de carimbar a própria origem.** Ela registrava a proveniência com o
padrão do gravador — `implantador` — sobre um valor que o implantador acabara de decidir NÃO
escrever: a tela do plugin passava a atribuir a ele o campo que outra pessoa digitou, e a
execução seguinte perdia o fato que fez esta preservar. Agora a origem conhecida é reescrita
como ela mesma, e origem não registrada não ganha nome nenhum.

**Defeito latente fechado junto.** `f3base_operaveis` era uma lista de dezesseis nomes
digitada à mão, e o plugin a usa em `F3Base_Options::operavel()` para RESTRINGIR quais campos
a tela abre. As duas listas batiam exatamente — e por acidente, porque nada as comparava. Uma
release do plugin que declarasse uma option operável nova faria o campo dela DESAPARECER da
tela assim que este implantador rodasse, sem erro e sem aviso. A lista virou
`operaveis_declaradas()`, com nome próprio, e `pacote.operaveis_confere_com_o_catalogo` cruza
os dois sentidos lendo o catálogo de DENTRO DA RESERVA — a mesma fonte de
`pacote.reserva_confere_com_o_catalogo` e `mcp.fronteira_do_validador`.

**O que custa, e o preço está declarado.** Num site pré-configurado, o valor do arquivo único
para aquelas options não chega ao banco: quem quiser que chegue apaga o campo na tela do
plugin antes de executar, ou grava pelo canal depois. O relatório nomeia cada option
preservada com o valor mantido e o valor não aplicado, e a linha fecha OK — preservar a
decisão de quem opera o site é o resultado correto, e WARN aqui treinaria o leitor a ignorar
o relatório.

**O que NÃO entrou.** Gravar as options do site-core pela porta do plugin
(`F3Base_Options::gravar()` em vez de `update_option()`, com a sanitização e a proveniência
dele) é a forma completa de "o plugin é autocontido", e fica para release própria: ela troca
o caminho de escrita de vinte options de uma vez, e o gravador deste pacote é a classe com
journal, leitura de volta e reversão. Esta decisão resolve o defeito relatado sem tocar nesse
caminho — ela só passa a LER o que o plugin já declara. Nenhuma mudança no plugin: ele já
publica a proveniência, já semeia `padrao` na ativação e já funciona sozinho.

**Como reverter.** `merge_sem_base()` com um ramo só devolve o comportamento antigo, e o
bench `gravador.proveniencia_vence_a_primeira` reprova em cinco medidas quando isso acontece.
