<?php
/**
 * Plugin Name:       Implantador Base F3
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Implantador idempotente do Método F3: preflight, journal de mutações com operação inversa, ponto único de escrita com leitura de volta, execução em lotes com checkpoint e fencing token, conteúdo por merge de três vias, plugins da fonte oficial na última versão, adaptador de SEO, navegação como post wp_navigation, relatório em estados fechados e autodesativação só em sucesso integral.
 * Version:           2.2.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Fator 3 Ventures
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       f3base
 * Domain Path:       /languages
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Identidade e caminhos.
 *
 * A versão do implantador tem UMA fonte de verdade em execução: o cabeçalho deste
 * arquivo, lido por `get_plugin_data()` na primeira vez em que alguém pergunta. A
 * constante abaixo é o fallback de bootstrap (o cabeçalho só é legível depois que
 * `wp-admin/includes/plugin.php` carrega) e o relatório imprime as duas quando
 * divergem — o caso medido (3.0.4) foi exatamente a constante que ficou para trás.
 */
if ( ! defined( 'F3BASE_IMP_VERSAO_DECLARADA' ) ) {
	define( 'F3BASE_IMP_VERSAO_DECLARADA', '2.2.0' );
}
if ( ! defined( 'F3BASE_IMP_PHP_MINIMO' ) ) {
	define( 'F3BASE_IMP_PHP_MINIMO', '8.1' );
}
if ( ! defined( 'F3BASE_IMP_ARQUIVO' ) ) {
	define( 'F3BASE_IMP_ARQUIVO', __FILE__ );
}
if ( ! defined( 'F3BASE_IMP_DIR' ) ) {
	define( 'F3BASE_IMP_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'F3BASE_IMP_URL' ) ) {
	define( 'F3BASE_IMP_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'F3BASE_IMP_TEXT_DOMAIN' ) ) {
	define( 'F3BASE_IMP_TEXT_DOMAIN', 'f3base' );
}
if ( ! defined( 'F3BASE_IMP_SLUG_TELA' ) ) {
	define( 'F3BASE_IMP_SLUG_TELA', 'f3base-implantacao' );
}

/**
 * Guard de versão de PHP.
 *
 * `version_compare()` só com operador da lista permitida pelo contrato
 * (`< lt <= le > gt >= ge == = eq != <> ne`). `===` não está na lista e o PHP 8
 * lança `ValueError` — o caso medido derrubou um lote em produção.
 *
 * @return bool Verdadeiro quando o PHP em execução atende ao mínimo declarado.
 */
function f3base_imp_php_suportado(): bool {
	return ! version_compare( PHP_VERSION, F3BASE_IMP_PHP_MINIMO, '<' );
}

/**
 * Autoload das classes do implantador.
 *
 * Uma classe por arquivo, `includes/class-f3base-imp-<nome>.php`. O prefixo
 * `F3Base_Imp_` separa o implantador do `site-core`, que carrega no mesmo
 * processo com o prefixo `F3Base_`.
 *
 * @param string $classe Nome da classe pedida.
 * @return void
 */
function f3base_imp_autoload( string $classe ): void {
	if ( ! str_starts_with( $classe, 'F3Base_Imp_' ) ) {
		return;
	}

	$slug    = strtolower( str_replace( '_', '-', $classe ) );
	$arquivo = F3BASE_IMP_DIR . 'includes/class-' . $slug . '.php';

	if ( is_readable( $arquivo ) ) {
		require_once $arquivo;
	}
}
spl_autoload_register( 'f3base_imp_autoload' );

/**
 * Versão efetiva do implantador em execução.
 *
 * Lê o cabeçalho do próprio arquivo quando a API de plugins estiver disponível;
 * cai na constante declarada apenas no bootstrap, antes do admin carregar.
 *
 * @return string
 */
function f3base_imp_versao(): string {
	static $versao = null;

	if ( null !== $versao ) {
		return $versao;
	}

	$versao = F3BASE_IMP_VERSAO_DECLARADA;

	if ( function_exists( 'get_plugin_data' ) ) {
		$dados = get_plugin_data( F3BASE_IMP_ARQUIVO, false, false );

		if ( is_array( $dados ) && isset( $dados['Version'] ) && '' !== (string) $dados['Version'] ) {
			$versao = (string) $dados['Version'];
		}
	}

	return $versao;
}

/**
 * Caminho absoluto de um arquivo do pacote.
 *
 * Caminho relativo sanitizado e confinado ao diretório do plugin: a leitura de
 * conteúdo editorial e de assets nunca sai da árvore do pacote.
 *
 * @param string $relativo Caminho relativo à raiz do pacote.
 * @return string Caminho absoluto, ou vazio quando escapa da raiz.
 */
function f3base_imp_caminho( string $relativo ): string {
	$relativo = ltrim( str_replace( '\\', '/', $relativo ), '/' );

	if ( '' === $relativo || str_contains( $relativo, '../' ) ) {
		return '';
	}

	$raiz     = rtrim( str_replace( '\\', '/', F3BASE_IMP_DIR ), '/' ) . '/';
	$completo = $raiz . $relativo;
	$real     = realpath( $completo );

	if ( false === $real ) {
		/* Arquivo ainda inexistente: devolve o caminho pretendido, já confinado. */
		return $completo;
	}

	$real = str_replace( '\\', '/', $real );

	return str_starts_with( $real, $raiz ) ? $real : '';
}

if ( ! f3base_imp_php_suportado() ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: versão mínima de PHP exigida, 2: versão de PHP em execução. */
						__( 'O Implantador Base F3 exige PHP %1$s ou superior. Este servidor executa PHP %2$s: o plugin ficou inerte, nenhum hook foi registrado e nenhuma mutação é possível.', 'f3base' ),
						F3BASE_IMP_PHP_MINIMO,
						PHP_VERSION
					)
				)
			);
		}
	);

	return;
}

/**
 * Carrega as traduções do implantador.
 *
 * @return void
 */
function f3base_imp_carregar_traducoes(): void {
	load_plugin_textdomain(
		F3BASE_IMP_TEXT_DOMAIN,
		false,
		dirname( plugin_basename( F3BASE_IMP_ARQUIVO ) ) . '/languages'
	);
}
add_action( 'init', 'f3base_imp_carregar_traducoes' );

/*
 * Superfície de administração e endpoints.
 *
 * O implantador não registra nada no front-end: ele é ferramenta de operador,
 * acionada pelo wp-admin com capability `manage_options` e nonce.
 */
add_action( 'admin_menu', array( 'F3Base_Imp_Admin', 'menu' ) );
add_action( 'admin_init', array( 'F3Base_Imp_Admin', 'abrir_apos_ativacao' ), 1 );
add_action( 'admin_post_f3base_imp_iniciar', array( 'F3Base_Imp_Admin', 'iniciar' ) );
add_action( 'admin_post_f3base_imp_lote', array( 'F3Base_Imp_Lotes', 'endpoint_lote' ) );
add_action( 'admin_post_f3base_imp_reverter', array( 'F3Base_Imp_Admin', 'reverter' ) );
add_filter(
	'plugin_action_links_' . plugin_basename( F3BASE_IMP_ARQUIVO ),
	array( 'F3Base_Imp_Admin', 'link_abrir' )
);

/**
 * Marca a ativação para que a tela abra sozinha na próxima carga do admin.
 *
 * O operador nunca procura onde o plugin mora.
 *
 * @return void
 */
function f3base_imp_ativar(): void {
	set_transient( 'f3base_imp_abrir_tela', '1', 60 );
}
register_activation_hook( F3BASE_IMP_ARQUIVO, 'f3base_imp_ativar' );

/**
 * Limpa apenas o que é transitório na desativação.
 *
 * Journal, checkpoint, log, base de merge e estado permanecem: a autodesativação
 * em sucesso não pode apagar a evidência da execução que a produziu, e a
 * desativação manual no meio de uma falha não pode apagar o caminho de retomada.
 *
 * @return void
 */
function f3base_imp_desativar(): void {
	delete_transient( 'f3base_imp_abrir_tela' );
}
register_deactivation_hook( F3BASE_IMP_ARQUIVO, 'f3base_imp_desativar' );
