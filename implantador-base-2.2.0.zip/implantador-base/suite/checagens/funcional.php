<?php
/**
 * Checagens funcionais: as funções puras do pacote, exercitadas de verdade.
 *
 * Rodam em subprocesso (`lib/sonda-funcional.php` e `lib/sonda-gravador.php`)
 * para não contaminar o processo que imprime os estados. Cada uma devolve
 * achados por nome de checagem; quem imprime e conta continua sendo `estado()`.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Roda uma sonda de subprocesso e devolve o veredito por checagem.
 *
 * @param string $sonda Caminho da sonda.
 * @param string $raiz  Raiz do pacote.
 * @return array<string,array{ok:bool,achados:array<int,string>,medidas:int}>
 */
function f3b_rodar_sonda( string $sonda, string $raiz ): array {
	$saida  = array();
	$codigo = 0;
	exec( 'php ' . escapeshellarg( $sonda ) . ' ' . escapeshellarg( $raiz ) . ' 2>&1', $saida, $codigo );

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) ) {
		return array(
			basename( $sonda, '.php' ) => array(
				'ok'      => false,
				'achados' => array( 'a sonda não devolveu veredito analisável: ' . f3b_amostra( $saida, 3 ) ),
				'medidas' => 0,
			),
		);
	}

	$saida_final = array();

	foreach ( $json as $nome => $dados ) {
		$achados = array_map( 'strval', (array) ( $dados['achados'] ?? array() ) );

		$saida_final[ (string) $nome ] = array(
			'ok'      => array() === $achados,
			'achados' => $achados,
			'medidas' => (int) ( $dados['medidas'] ?? 0 ),
		);
	}

	return $saida_final;
}

/**
 * Veredito de todas as checagens funcionais.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array<string,array{ok:bool,achados:array<int,string>,medidas:int}>
 */
function f3b_ck_funcionais( string $raiz, string $suite ): array {
	return array_merge(
		f3b_rodar_sonda( $suite . '/lib/sonda-funcional.php', $raiz ),
		f3b_rodar_sonda( $suite . '/lib/sonda-gravador.php', $raiz ),
		/*
		 * A sonda da INSTALAÇÃO LIMPA roda em processo próprio porque monta um
		 * WordPress de mentira inteiro — caches que memorizam o negativo,
		 * filesystem, options — e nada disso pode vazar para as outras sondas.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-instalacao.php', $raiz ),
		/*
		 * A sonda do SITE-CORE NÃO MORA MAIS AQUI — 2.0.0. Ela montava um wpdb
		 * de mentira e rodava o endpoint de leads, a cadência, o llms.txt e a
		 * medição REAIS contra `fontes/plugin/`, que deixou de existir nesta
		 * árvore: a fonte do plugin tem repositório próprio, e é a suíte de lá
		 * que a mede — contra o zip que o site recebe, e não contra uma cópia.
		 * `suite/excluidas.tsv` diz, linha a linha, o que foi embora e por quê.
		 */
		/*
		 * A sonda do TEMA roda em processo próprio: as duas regras que
		 * preenchem-quando-falta só existem quando `WP_HTML_Tag_Processor`
		 * existe, e a bancada declara a classe — nenhuma outra sonda pode
		 * conviver com essa declaração.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-tema.php', $raiz ),
		/*
		 * A sonda da RENOMEAÇÃO roda em processo próprio porque ela COPIA a
		 * árvore do pacote três vezes e chama a ferramenta de renomeação em
		 * subprocessos: ela mede um pacote que não é este, e nada do que ela
		 * carrega pode encostar nas outras bancadas.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-renomeacao.php', $raiz ),
		/*
		 * A sonda do BUNDLE lê o ARTEFATO montado — o zip que o operador faz
		 * upload —, e não a árvore de origem. Ela roda depois do empacotamento,
		 * que é a primeira etapa do comando único.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-bundle.php', $raiz )
	);
}

/**
 * Roda um modo da sonda de JavaScript sob o Node de verdade.
 *
 * @param string $modo  Modo da sonda.
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_rodar_js( string $modo, string $raiz, string $suite ): array {
	$saida  = array();
	$codigo = 0;
	exec(
		'node ' . escapeshellarg( $suite . '/checagens/js.mjs' ) . ' ' . escapeshellarg( $modo ) . ' ' . escapeshellarg( $raiz ) . ' 2>&1',
		$saida,
		$codigo
	);

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) || ! isset( $json['achados'] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'sonda js.mjs (modo ' . $modo . ') não devolveu veredito analisável: ' . f3b_amostra( $saida, 3 ) ),
		);
	}

	return array(
		'ok'      => array() === $json['achados'],
		'achados' => array_map( 'strval', $json['achados'] ),
	);
}

/**
 * Extrator de resposta do cliente: teto e piso, sob o Node de verdade.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_extrator( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'extrator', $raiz, $suite );
}

/**
 * DECISÕES do cliente: o laço de lock, o contador, o fecho e os nomes.
 *
 * As funções puras saem do arquivo REAL, extraídas dele em tempo de execução —
 * nunca copiadas —, e o laço da execução que reprovou é simulado com a resposta
 * de rejeição de lock, inclusive a resposta ANTIGA, sem os campos que a 1.0.16
 * acrescentou: o cliente tem de parar sozinho.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_cliente( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'cliente', $raiz, $suite );
}

/**
 * O BANNER DE CONSENTIMENTO, medido no comportamento e não no markup.
 *
 * A bancada roda o cliente REAL do plugin — lido de dentro da reserva, que é o
 * zip publicado — contra um DOM de mentira e decide visibilidade pelo
 * `style.css` REAL do tema, com o par (`hidden`, `display`) — que é a única
 * pergunta que o visitante faz. É a única bancada de JavaScript do plugin que
 * ficou neste repositório na 2.0.0, e ficou porque mede um par que nenhum dos
 * dois repositórios mede sozinho. O piso é o CSS da 1.1.2 escrito dentro da
 * sonda: se ela não reprovar o painel que cobre a tela e não fecha, ela é cega.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_banner( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'banner', $raiz, $suite );
}
