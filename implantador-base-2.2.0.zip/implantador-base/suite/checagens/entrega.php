<?php
/**
 * Os nove entregáveis.
 *
 * Entregável ausente é BLOCKED COM O NOME DO ARQUIVO QUE FALTA — nunca ausência
 * silenciosa, nunca FALHA. O caso medido: um pacote sem suíte, sem leia-me e sem
 * memória fechou o relatório com zero falhas e se autodesativou dizendo OK.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Confere presença de caminhos e devolve os que faltam.
 *
 * @param string            $raiz     Raiz.
 * @param array<int,string> $caminhos Caminhos relativos obrigatórios.
 * @return array<int,string>
 */
function f3b_faltando( string $raiz, array $caminhos ): array {
	$faltam = array();

	foreach ( $caminhos as $rel ) {
		if ( str_ends_with( $rel, '/' ) ) {
			if ( array() === f3b_arquivos( $raiz . '/' . rtrim( $rel, '/' ) ) ) {
				$faltam[] = $rel . ' (diretório vazio ou ausente)';
			}

			continue;
		}

		if ( ! is_file( $raiz . '/' . $rel ) ) {
			$faltam[] = $rel;
		}
	}

	return $faltam;
}

/**
 * Mapa dos nove entregáveis: nome da checagem => caminhos obrigatórios.
 *
 * Os caminhos de conteúdo e de blog são DERIVADOS da configuração, nunca de
 * lista fechada no código: é o `site.json` que declara quais páginas e quais
 * posts a release entrega.
 *
 * @param string $raiz Raiz.
 * @return array<string,array<int,string>>
 */
function f3b_entregaveis( string $raiz ): array {
	$config = f3b_config( $raiz ) ?? array();

	$paginas = array();

	foreach ( (array) ( $config['paginas'] ?? array() ) as $pagina ) {
		if ( is_array( $pagina ) && isset( $pagina['ref'] ) ) {
			$paginas[] = 'content/pages/' . $pagina['ref'] . '.html';
		}
	}

	foreach ( (array) ( $config['midia'] ?? array() ) as $midia ) {
		if ( is_array( $midia ) && isset( $midia['arquivo'] ) ) {
			$paginas[] = (string) $midia['arquivo'];
		}
	}

	$posts = array();

	foreach ( (array) ( $config['posts'] ?? array() ) as $post ) {
		if ( is_array( $post ) && isset( $post['slug'] ) ) {
			$posts[] = 'content/posts/' . $post['slug'] . '.html';
		}
	}

	$reserva   = f3b_reserva_do_site_core( $raiz );
	$site_core = array( '' !== $reserva['relativo'] ? $reserva['relativo'] : 'assets/plugins/' . ( '' !== $reserva['pasta'] ? $reserva['pasta'] : 'base-site-core-fator3' ) . '-<versão>.zip' );
	$site_core[] = 'partilhado/VENDORIZADO.tsv';

	foreach ( array_keys( f3b_vendorizado_declarado( $raiz ) ) as $vendorizado ) {
		$site_core[] = 'partilhado/' . $vendorizado;
	}

	return array(
		'entrega.tema'        => array(
			'fontes/tema/style.css',
			'fontes/tema/theme.json',
			'fontes/tema/functions.php',
			'fontes/tema/templates/index.html',
			'fontes/tema/parts/header.html',
			'fontes/tema/parts/footer.html',
			'fontes/tema/patterns/',
		),
		/*
		 * O SITE-CORE COMO ENTREGÁVEL DESTE PACOTE — 2.0.0. A fonte dele não
		 * mora mais aqui; o que este pacote ENTREGA do plugin é a reserva (o
		 * zip publicado, copiado para a árvore) e a cópia vendorizada com a
		 * declaração dela. A lista é DERIVADA da resolução da reserva e de
		 * `partilhado/VENDORIZADO.tsv`, nunca fechada no código: uma reserva
		 * que não resolve entra pelo padrão de nome, e sai nomeada como falta.
		 */
		'entrega.site_core'   => $site_core,
		'entrega.conteudo'    => $paginas,
		'entrega.blog'        => $posts,
		'entrega.implantador' => array(
			'implantador-base.php',
			'config/site.json',
			'config/site.schema.json',
			'includes/class-f3base-imp-config.php',
			'includes/class-f3base-imp-gravador.php',
		),
		'entrega.readme'      => array( 'README.md' ),
		'entrega.memoria'     => array( 'MEMORIA-DECISOES.md' ),
		'entrega.documentacao' => array( 'MANIFESTO.md', 'TEMPLATE.md', 'MAPA-DA-OPERACAO.md', 'INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md' ),
		'entrega.suite'       => array(
			'suite/verificar.sh',
			'suite/lib/regra.php',
			'suite/inventario.tsv',
			'suite/manifesto.tsv',
			'suite/armadilhas.tsv',
			'suite/fixtures/',
		),
	);
}

/**
 * Um entregável.
 *
 * @param string $raiz Raiz.
 * @param string $nome Nome da checagem.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_entregavel( string $raiz, string $nome ): array {
	$mapa = f3b_entregaveis( $raiz );

	if ( ! isset( $mapa[ $nome ] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'entregável desconhecido: ' . $nome ),
		);
	}

	if ( array() === $mapa[ $nome ] ) {
		return array(
			'ok'      => false,
			'achados' => array( 'a configuração não declara nenhum item para este entregável' ),
		);
	}

	$faltam = f3b_faltando( $raiz, $mapa[ $nome ] );

	return array(
		'ok'      => array() === $faltam,
		'achados' => $faltam,
	);
}
