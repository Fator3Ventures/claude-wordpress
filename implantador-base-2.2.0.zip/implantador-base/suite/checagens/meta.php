<?php
/**
 * Cruzamentos da própria suíte: manifesto e mapa de armadilhas.
 *
 * Ambos são calculados dos RÓTULOS EFETIVAMENTE EMITIDOS na rodada — nunca de
 * uma lista escrita à mão, nunca de `check(true)`. Uma suíte que afirma cobrir
 * um requisito por causa de uma linha de tabela é a mesma coisa que uma suíte
 * cega, com documentação melhor.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * DUAS FORMAS DE PISO, e as duas precisam de evidência.
 *
 * A forma antiga é a fixture em disco: uma árvore negativa que reproduz o
 * defeito e uma positiva que preserva o correto. Ela serve a detector de
 * análise estática, e é a única que existia até a 1.0.15.
 *
 * A forma que faltava é a da SONDA FUNCIONAL, cujo caso negativo não é uma
 * árvore de arquivos: é um mutante do próprio pacote, exercitado dentro da
 * sonda. `suite/pisos-em-sonda.tsv` declara quais checagens são dessas, e a
 * declaração NÃO absolve: só vale quando a sonda declarada existe e traz, para
 * aquela checagem, ramo de TETO e ramo de PISO escritos. Sonda cega não os
 * teria, e é isso que separa uma das outras.
 *
 * @param string $suite Diretório da suíte.
 * @param string $nome  Nome da checagem.
 * @return bool
 */
function f3b_tem_piso( string $suite, string $nome ): bool {
	$base = $suite . '/fixtures/' . $nome;

	if ( is_dir( $base . '/negativa' ) && is_dir( $base . '/positiva' ) ) {
		return true;
	}

	return array() === f3b_piso_em_sonda_pendente( $suite, $nome );
}

/**
 * Piso declarado em sonda: o que FALTA para a declaração valer.
 *
 * Devolve lista vazia quando a declaração se sustenta. Fora isso, cada item é o
 * que falta — e é o mesmo texto que o detector do piso da regra imprime.
 *
 * @param string $suite Diretório da suíte.
 * @param string $nome  Nome da checagem.
 * @return array<int,string>
 */
function f3b_piso_em_sonda_pendente( string $suite, string $nome ): array {
	$declaracao = f3b_pisos_em_sonda( $suite );

	if ( ! isset( $declaracao[ $nome ] ) ) {
		return array( 'não está declarada em suite/pisos-em-sonda.tsv nem tem fixture negativa e positiva em disco' );
	}

	$sonda   = $declaracao[ $nome ];
	$caminho = $suite . '/' . $sonda;

	if ( ! is_file( $caminho ) ) {
		return array( 'a sonda declarada não existe: ' . $sonda );
	}

	$fonte  = (string) file_get_contents( $caminho );
	$faltam = array();

	if ( ! str_contains( $fonte, $nome ) ) {
		$faltam[] = $sonda . ' não menciona a checagem ' . $nome . ': declaração que absolve sem medir é pior que nenhuma';
	}

	foreach ( array( 'teto', 'piso' ) as $ramo ) {
		if ( 1 !== preg_match( '/[\'"]' . $ramo . '\b/u', $fonte ) ) {
			$faltam[] = $sonda . ' não tem nenhuma afirmação de ' . $ramo . ': uma sonda sem os dois ramos não provou saber reprovar nada';
		}
	}

	return $faltam;
}

/**
 * A declaração de pisos em sonda, lida do TSV.
 *
 * @param string $suite Diretório da suíte.
 * @return array<string,string> Checagem => caminho da sonda, relativo à suíte.
 */
function f3b_pisos_em_sonda( string $suite ): array {
	$mapa = array();

	foreach ( f3b_tsv( $suite . '/pisos-em-sonda.tsv' ) as $linha ) {
		$nome  = trim( $linha[0] ?? '' );
		$sonda = trim( $linha[1] ?? '' );

		if ( '' !== $nome && '' !== $sonda ) {
			$mapa[ $nome ] = $sonda;
		}
	}

	return $mapa;
}

/**
 * As categorias fechadas de uma exclusão declarada.
 *
 * `retirada` entrou na 2.1.0: checagem que media uma responsabilidade que o
 * dono decidiu que NÃO é do implantador (o texto da política, o dado do
 * controlador, a convergência do estado por dado do operador). Ela não mudou
 * de repositório nem de nome — deixou de existir, e a decisão fica escrita.
 *
 * @return array<int,string>
 */
function f3b_categorias_de_exclusao(): array {
	return array( 'plugin', 'substituida', 'instrumento', 'retirada' );
}

/**
 * REGRA PURA: toda exclusão declarada se sustenta.
 *
 * Uma linha de `suite/excluidas.tsv` afirma três coisas: que a checagem nomeada
 * NÃO é mais emitida por este repositório, que ela pertence a uma categoria
 * fechada, e que há um motivo escrito. As três são conferidas; a primeira é a
 * que impede a tabela de envelhecer — uma checagem que volte a ser emitida com
 * a linha ainda aqui é a tabela mentindo sobre o que a suíte faz.
 *
 * @param array<int,array<int,string>> $linhas   Linhas do TSV (nome, categoria, motivo).
 * @param array<int,string>             $emitidas Rótulos emitidos nesta rodada.
 * @return array<int,string> Achados.
 */
function f3b_exclusoes_pendentes( array $linhas, array $emitidas ): array {
	$achados = array();
	$vistos  = array();

	foreach ( $linhas as $linha ) {
		$nome      = trim( $linha[0] ?? '' );
		$categoria = trim( $linha[1] ?? '' );
		$motivo    = trim( $linha[2] ?? '' );

		if ( '' === $nome ) {
			continue;
		}

		if ( isset( $vistos[ $nome ] ) ) {
			$achados[] = $nome . ': declarada DUAS vezes em suite/excluidas.tsv — duas linhas sobre a mesma checagem são dois motivos que podem discordar';
		}

		$vistos[ $nome ] = true;

		if ( in_array( $nome, $emitidas, true ) ) {
			$achados[] = $nome . ': declarada EXCLUÍDA e emitida nesta rodada — a declaração está velha, e uma tabela que descreve outra suíte é pior que tabela nenhuma';
		}

		if ( ! in_array( $categoria, f3b_categorias_de_exclusao(), true ) ) {
			$achados[] = $nome . ': categoria "' . $categoria . '" fora do vocabulário fechado (' . implode( ', ', f3b_categorias_de_exclusao() ) . ')';
		}

		if ( '' === $motivo ) {
			$achados[] = $nome . ': excluída SEM MOTIVO — exclusão sem motivo escrito é cobertura que encolheu sem que ninguém decidisse';
		}
	}

	return $achados;
}

/**
 * excluidas.declaradas — o que saiu desta suíte saiu DECLARADO, e a declaração está viva.
 *
 * POR QUE ESTA LINHA EXISTE. A 2.0.0 tirou deste repositório a fonte do plugin
 * e, com ela, cinquenta e nove rótulos que a 1.7.4 emitia. Rótulo que some é
 * indistinguível de rótulo esquecido: `manifesto.bidirecional` acusa requisito
 * sem checagem e checagem sem requisito, mas não acusa o requisito que foi
 * APAGADO junto com a checagem — e é assim que a cobertura encolhe em silêncio.
 * `suite/excluidas.tsv` é a lista do que saiu, com o motivo; esta linha confere
 * que a lista está viva.
 *
 * TETO: cada linha declarada nomeia uma checagem que esta rodada não emite, com
 * categoria do vocabulário fechado e motivo escrito. PISO: a mesma regra pura,
 * contra uma linha que nomeia uma checagem EMITIDA, contra uma categoria fora
 * do vocabulário e contra um motivo vazio — e ela precisa acusar nos três.
 *
 * @param string            $suite    Diretório da suíte.
 * @param array<int,string> $emitidas Rótulos emitidos nesta rodada.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_excluidas_declaradas( string $suite, array $emitidas ): array {
	$linhas  = f3b_tsv( $suite . '/excluidas.tsv' );
	$achados = f3b_exclusoes_pendentes( $linhas, $emitidas );
	$medidas = count( $linhas );

	/* PISO: a regra pura, contra as três entradas com o defeito plantado. */
	$primeira_emitida = (string) ( $emitidas[0] ?? '' );

	if ( '' !== $primeira_emitida && array() === f3b_exclusoes_pendentes( array( array( $primeira_emitida, 'plugin', 'motivo plantado' ) ), $emitidas ) ) {
		$achados[] = 'piso cego: com uma linha declarando excluída a checagem emitida "' . $primeira_emitida . '", a regra continuou em silêncio';
	}

	if ( array() === f3b_exclusoes_pendentes( array( array( 'x.nunca_emitida', 'conveniencia', 'motivo plantado' ) ), $emitidas ) ) {
		$achados[] = 'piso cego: com uma categoria fora do vocabulário fechado, a regra continuou em silêncio';
	}

	if ( array() === f3b_exclusoes_pendentes( array( array( 'x.nunca_emitida', 'plugin', '' ) ), $emitidas ) ) {
		$achados[] = 'piso cego: com o motivo vazio, a regra continuou em silêncio';
	}

	$medidas += 3;

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * PISO DA REGRA DO PISO: toda declaração de piso em sonda se sustenta.
 *
 * Sem este detector, `suite/pisos-em-sonda.tsv` seria uma linha de tabela capaz
 * de declarar coberta qualquer checagem — exatamente a doença que
 * `armadilhas.mapeadas` existe para impedir, um nível acima.
 *
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_piso_em_sonda_declarado( string $suite ): array {
	$achados = array();
	$medidas = 0;

	foreach ( f3b_pisos_em_sonda( $suite ) as $nome => $sonda ) {
		++$medidas;

		foreach ( f3b_piso_em_sonda_pendente( $suite, $nome ) as $falta ) {
			$achados[] = $nome . ' (' . $sonda . '): ' . $falta;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * AFIRMAÇÃO DE DOCUMENTO conferida contra COMPORTAMENTO MEDIDO.
 *
 * O detector que faltava, e a fresta por onde passaram cinco dos vinte e dois
 * achados da auditoria da 1.0.17: os detectores desta suíte conferem identidade
 * de release e números gerados, e nenhum conferia uma afirmação de
 * COMPORTAMENTO. Três frases de `README.md` e `MANIFESTO.md` eram refutadas pela
 * configuração e pelo código DENTRO DO MESMO ZIP, e nada acusava.
 *
 * Ele não entende prosa, e não precisa: o elo entre a frase e o fato é
 * DECLARADO em `suite/afirmacoes.tsv`, e são dois achados possíveis —
 *
 * - **frase declarada que sumiu do documento**: a afirmação mudou e a amarração
 *   ficou para trás, então a linha da tabela deixou de proteger alguma coisa e
 *   passa a mentir sobre cobertura, que é a doença que `armadilhas.mapeadas`
 *   combate um nível acima;
 * - **fato que não bate com o esperado**: a frase continua no documento e o
 *   pacote faz outra coisa — exatamente os três achados de 1.0.17.
 *
 * A tabela é lida da ÁRVORE VARRIDA, não da suíte que executa: é isso que
 * permite ao piso ter uma fixture com a sua própria declaração e o seu próprio
 * documento.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_afirmacoes( string $raiz ): array {
	$tabela = f3b_tsv( $raiz . '/suite/afirmacoes.tsv' );

	if ( array() === $tabela ) {
		return array(
			'ok'      => false,
			'achados' => array( 'suite/afirmacoes.tsv vazio ou ausente na raiz varrida: sem o elo declarado entre frase e fato, nenhuma afirmação de comportamento é conferida — e foi por essa fresta que passaram cinco dos vinte e dois achados da 1.0.17' ),
			'medidas' => 0,
		);
	}

	$achados = array();
	$medidas = 0;

	foreach ( $tabela as $linha ) {
		$documento = trim( $linha[0] ?? '' );
		$frase     = trim( $linha[1] ?? '' );
		$regra     = trim( $linha[2] ?? '' );
		$argumento = trim( $linha[3] ?? '' );
		$esperado  = strtolower( trim( $linha[4] ?? '' ) );

		if ( '' === $documento || '' === $frase ) {
			continue;
		}

		++$medidas;

		if ( '' === $regra || '' === $argumento || ! in_array( $esperado, array( 'sim', 'nao' ), true ) ) {
			$achados[] = $documento . ': a afirmação "' . f3b_recorte( $frase ) . '" está declarada sem regra, sem argumento ou com esperado fora de {sim,nao} — declaração que não mede nada é pior que declaração nenhuma';
			continue;
		}

		$caminho = $raiz . '/' . $documento;

		if ( ! is_file( $caminho ) ) {
			$achados[] = $documento . ': o documento declarado não existe na raiz varrida, e a afirmação "' . f3b_recorte( $frase ) . '" não tem onde ser conferida';
			continue;
		}

		if ( ! str_contains( (string) file_get_contents( $caminho ), $frase ) ) {
			$achados[] = $documento . ': a frase declarada NÃO está mais no documento — "' . f3b_recorte( $frase ) . '". A amarração ficou para trás da redação: ou a frase voltou a valer e precisa ser reescrita, ou a linha sai da tabela. Amarração órfã afirma cobertura que não existe';
			continue;
		}

		$medicao = f3b_medir_afirmacao( $raiz, $regra, $argumento );

		if ( '' !== $medicao['erro'] ) {
			$achados[] = $documento . ' / "' . f3b_recorte( $frase ) . '": ' . $medicao['erro'];
			continue;
		}

		if ( $medicao['observado'] !== $esperado ) {
			$achados[] = $documento . ' AFIRMA "' . f3b_recorte( $frase ) . '" e o pacote MEDE o contrário: regra ' . $regra
				. ' sobre "' . $argumento . '" esperava "' . $esperado . '" e observou "' . $medicao['observado'] . '" — ' . $medicao['detalhe'];
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Recorte de uma frase para caber na mensagem sem perder a identidade.
 *
 * @param string $frase Frase declarada.
 * @return string
 */
function f3b_recorte( string $frase ): string {
	return mb_strlen( $frase ) > 90 ? mb_substr( $frase, 0, 90 ) . '…' : $frase;
}

/**
 * MEDE o fato que sustenta uma afirmação, pela regra declarada.
 *
 * @param string $raiz      Raiz a varrer.
 * @param string $regra     Nome da regra.
 * @param string $argumento Argumento da regra.
 * @return array{observado:string,detalhe:string,erro:string}
 */
function f3b_medir_afirmacao( string $raiz, string $regra, string $argumento ): array {
	if ( 'config.vazio' === $regra || 'config.igual' === $regra ) {
		$arquivo = $raiz . '/config/site.json';

		if ( ! is_file( $arquivo ) ) {
			return array( 'observado' => '', 'detalhe' => '', 'erro' => 'config/site.json ausente na raiz varrida' );
		}

		$config = json_decode( (string) file_get_contents( $arquivo ), true );

		if ( ! is_array( $config ) ) {
			return array( 'observado' => '', 'detalhe' => '', 'erro' => 'config/site.json não analisa' );
		}

		if ( 'config.vazio' === $regra ) {
			if ( ! f3b_caminho_declarado( $config, $argumento ) ) {
				return array(
					'observado' => '',
					'detalhe'   => '',
					'erro'      => 'a chave ' . $argumento . ' NÃO é declarada em config/site.json: a afirmação fala de um caminho que não existe, e ausente não é vazio',
				);
			}

			$valor  = f3b_valor_do_caminho( $config, $argumento );
			$vazio  = null === $valor || '' === $valor || array() === $valor;
			$conta  = is_array( $valor ) ? count( $valor ) : 0;

			return array(
				'observado' => $vazio ? 'sim' : 'nao',
				'detalhe'   => $vazio
					? 'a chave ' . $argumento . ' está declarada e vazia em config/site.json'
					: 'a chave ' . $argumento . ' está PREENCHIDA em config/site.json' . ( $conta > 0 ? ' com ' . $conta . ' entrada(s)' : ': ' . f3b_recorte( is_scalar( $valor ) ? (string) $valor : (string) json_encode( $valor ) ) ),
				'erro'      => '',
			);
		}

		$partes = explode( '=', $argumento, 2 );
		$valor  = f3b_valor_do_caminho( $config, trim( $partes[0] ) );
		$igual  = is_scalar( $valor ) && (string) $valor === trim( $partes[1] ?? '' );

		return array(
			'observado' => $igual ? 'sim' : 'nao',
			'detalhe'   => 'a chave ' . trim( $partes[0] ) . ' vale "' . ( is_scalar( $valor ) ? (string) $valor : (string) json_encode( $valor ) ) . '" em config/site.json',
			'erro'      => '',
		);
	}

	/*
	 * DECISAO DO PACOTE: a afirmacao de um documento sobre um valor que saiu da
	 * configuracao e virou linha de `config/decisoes.tsv` mede contra o
	 * CATALOGO, e nunca contra a configuracao — que nao conhece mais a chave e
	 * devolveria "ausente" para toda afirmacao correta.
	 *
	 * O valor do catalogo e JSON, e a comparacao e feita na forma JSON dos dois
	 * lados: sem isso `true` do catalogo nunca casaria com `true` escrito na
	 * tabela, porque (string) true e "1".
	 */
	/*
	 * ARQUIVO DO PROJETO: a afirmacao de um documento sobre um campo que o
	 * OPERADOR preenche mede contra `config/projeto.json`, que e onde esse campo
	 * mora. Medi-la contra a configuracao devolveria "ausente" para toda
	 * afirmacao correta, e o documento seria acusado de mentir por estar certo.
	 */
	if ( 'projeto.vazio' === $regra || 'projeto.igual' === $regra ) {
		$arquivo = $raiz . '/config/projeto.json';

		if ( ! is_file( $arquivo ) ) {
			return array( 'observado' => '', 'detalhe' => '', 'erro' => 'config/projeto.json ausente na raiz varrida' );
		}

		$projeto = json_decode( (string) file_get_contents( $arquivo ), true );

		if ( ! is_array( $projeto ) ) {
			return array( 'observado' => '', 'detalhe' => '', 'erro' => 'config/projeto.json não analisa' );
		}

		if ( 'projeto.vazio' === $regra ) {
			if ( ! f3b_caminho_declarado( $projeto, $argumento ) ) {
				return array(
					'observado' => '',
					'detalhe'   => '',
					'erro'      => 'o campo ' . $argumento . ' NÃO é declarado em config/projeto.json: a afirmação fala de um caminho que não existe, e ausente não é vazio',
				);
			}

			$valor = f3b_valor_do_caminho( $projeto, $argumento );
			$vazio = null === $valor || '' === $valor || array() === $valor || 0 === $valor;
			$conta = is_array( $valor ) ? count( $valor ) : 0;

			return array(
				'observado' => $vazio ? 'sim' : 'nao',
				'detalhe'   => $vazio
					? 'o campo ' . $argumento . ' nasce declarado e vazio em config/projeto.json'
					: 'o campo ' . $argumento . ' está PREENCHIDO em config/projeto.json' . ( $conta > 0 ? ' com ' . $conta . ' entrada(s)' : ': ' . f3b_recorte( is_scalar( $valor ) ? (string) $valor : (string) json_encode( $valor ) ) ),
				'erro'      => '',
			);
		}

		$partes = explode( '=', $argumento, 2 );
		$valor  = f3b_valor_do_caminho( $projeto, trim( $partes[0] ) );
		$igual  = is_scalar( $valor ) && (string) $valor === trim( $partes[1] ?? '' );

		return array(
			'observado' => $igual ? 'sim' : 'nao',
			'detalhe'   => 'o campo ' . trim( $partes[0] ) . ' vale "' . ( is_scalar( $valor ) ? (string) $valor : (string) json_encode( $valor ) ) . '" em config/projeto.json',
			'erro'      => '',
		);
	}

	if ( 'decisao.igual' === $regra ) {
		$arquivo = $raiz . '/config/decisoes.tsv';

		if ( ! is_file( $arquivo ) ) {
			return array( 'observado' => '', 'detalhe' => '', 'erro' => 'config/decisoes.tsv ausente na raiz varrida' );
		}

		$catalogo = array();

		foreach ( f3b_decisoes( $raiz ) as $linha ) {
			$catalogo[ $linha['chave'] ] = $linha['valor'];
		}

		$partes   = explode( '=', $argumento, 2 );
		$chave    = trim( $partes[0] );
		$esperado = trim( $partes[1] ?? '' );

		if ( ! array_key_exists( $chave, $catalogo ) ) {
			return array(
				'observado' => 'nao',
				'detalhe'   => 'a decisão ' . $chave . ' NÃO está no catálogo config/decisoes.tsv',
				'erro'      => '',
			);
		}

		$valor = $catalogo[ $chave ];
		$como  = is_string( $valor ) ? $valor : (string) json_encode( $valor );

		return array(
			'observado' => $como === $esperado ? 'sim' : 'nao',
			'detalhe'   => 'a decisão ' . $chave . ' vale "' . $como . '" em config/decisoes.tsv',
			'erro'      => '',
		);
	}

	if ( 'codigo.chamada' === $regra || 'codigo.emite_estado' === $regra ) {
		$onde = array();

		foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
			$onde[ $rel ] = f3b_codigo_php( $raiz . '/' . $rel );
		}

		/*
		 * O PLUGIN ENTRA NO CORPO MEDIDO, lido de dentro da reserva — 2.0.0. Os
		 * documentos deste pacote afirmam comportamentos do plugin (o CTA, o
		 * emissor único, os segredos), e a afirmação só pode ser conferida contra
		 * o código que o site RECEBE: o zip publicado. Até a 1.7.4 a regra lia
		 * `fontes/plugin/`, que era uma cópia — e uma cópia é o que um documento
		 * não deve descrever.
		 */
		foreach ( f3b_arquivos_do_plugin( $raiz, array( 'php' ) ) as $rel ) {
			$onde[ 'reserva do plugin, ' . $rel ] = f3b_codigo_php_de_texto( f3b_fonte_do_plugin( $raiz, $rel ) );
		}

		if ( 'codigo.chamada' === $regra ) {
			foreach ( $onde as $rel => $src ) {
				if ( 1 === preg_match( '/' . str_replace( '/', '\/', $argumento ) . '/u', $src ) ) {
					return array( 'observado' => 'sim', 'detalhe' => 'a expressão casa em ' . $rel, 'erro' => '' );
				}
			}

			return array(
				'observado' => 'nao',
				'detalhe'   => 'a expressão NÃO casa em nenhum .php de includes/, de fontes/, de partilhado/ nem de dentro da reserva do plugin — a afirmação descreve um comportamento que o pacote não tem',
				'erro'      => '',
			);
		}

		$partes   = explode( '=', $argumento, 2 );
		$checagem = trim( $partes[0] );
		$estado   = strtoupper( trim( $partes[1] ?? '' ) );
		$estados  = f3b_estados_emitidos_para( $onde, $checagem );

		return array(
			'observado' => in_array( $estado, $estados, true ) ? 'sim' : 'nao',
			'detalhe'   => array() === $estados
				? 'nenhuma emissão da checagem "' . $checagem . '" foi encontrada no pacote: a afirmação promete um item de relatório que não existe'
				: 'a checagem "' . $checagem . '" só é emitida em: ' . implode( ', ', $estados ),
			'erro'      => '',
		);
	}

	return array( 'observado' => '', 'detalhe' => '', 'erro' => 'regra declarada desconhecida: ' . $regra );
}

/**
 * Valor de um caminho pontilhado dentro do config decodificado.
 *
 * @param array<string,mixed> $config   Config.
 * @param string              $caminho  Caminho pontilhado.
 * @return mixed Null quando não existe.
 */
function f3b_valor_do_caminho( array $config, string $caminho ) {
	$atual = $config;

	foreach ( explode( '.', $caminho ) as $parte ) {
		if ( ! is_array( $atual ) || ! array_key_exists( $parte, $atual ) ) {
			return null;
		}

		$atual = $atual[ $parte ];
	}

	return $atual;
}

/**
 * O CAMINHO EXISTE no arquivo? Pergunta diferente de "qual e o valor".
 *
 * O DEFEITO MEDIDO, e ele aprovava em silencio: `config.vazio` e `projeto.vazio`
 * liam AUSENTE como VAZIO, entao uma afirmacao de documento sobre uma chave que
 * nao existe em arquivo nenhum fechava "sim". Duas linhas desta tabela viviam
 * assim — `cadencia_relatorio.mecanismo`, que virou `mecanismo_de_cadencia` ao
 * migrar para o arquivo do projeto, e `cabecalhos.origem_confiavel.cabecalho`,
 * que nunca teve o prefixo `cabecalhos.`. O README mandava o operador procurar
 * dois caminhos inexistentes, e o detector que existe para pegar documento
 * mentindo dizia que estava tudo certo, porque ausente e vazio davam o mesmo
 * "sim". Sao fatos diferentes e passam a sair diferentes: ausente e ERRO da
 * afirmacao, nao aprovacao dela.
 *
 * @param array<string,mixed> $config  Estrutura decodificada.
 * @param string              $caminho Caminho pontilhado.
 * @return bool
 */
function f3b_caminho_declarado( array $config, string $caminho ): bool {
	$atual = $config;

	foreach ( explode( '.', $caminho ) as $parte ) {
		if ( ! is_array( $atual ) || ! array_key_exists( $parte, $atual ) ) {
			return false;
		}

		$atual = $atual[ $parte ];
	}

	return true;
}

/**
 * ESTADOS que uma checagem pode fechar, lidos das emissões do pacote.
 *
 * Lê o prefixo de argumentos de cada emissão cujo nome literal é a checagem
 * procurada: `emitir( <estado>, '<nome>', … )` traz o estado antes do nome, e
 * `avaliar()`/`condicional()` trazem os estados implícitos do par que decidem.
 *
 * @param array<string,string> $fontes  Caminho relativo => código PHP.
 * @param string               $checagem Nome da checagem.
 * @return array<int,string> Estados, sem repetição.
 */
function f3b_estados_emitidos_para( array $fontes, string $checagem ): array {
	$estados  = array();
	$fechados = array( 'OK', 'FALHA', 'BLOCKED', 'N/A', 'NA', 'WAIVED', 'WARN' );

	foreach ( $fontes as $src ) {
		$posicao = 0;

		while ( true ) {
			$encontrado = strpos( $src, "'" . $checagem . "'", $posicao );

			if ( false === $encontrado ) {
				break;
			}

			$posicao = $encontrado + 1;
			$inicio  = max( 0, $encontrado - 1200 );
			$antes   = substr( $src, $inicio, $encontrado - $inicio );

			/*
			 * O nome de cada emissora é montado com o parêntese à parte, e não
			 * é estilo: escrito colado, este arquivo conteria a marca que
			 * `estatica.estados_fechados` procura — `saida( '…'` — e o detector
			 * acusaria a própria tabela de nomes como se fosse uma emissão com
			 * estado fora da lista fechada.
			 */
			foreach ( array( 'avaliar', 'condicional', 'emitir', 'emitir_unidade', 'saida' ) as $emissora ) {
				$chamada = $emissora . '(';
				$abre    = strrpos( $antes, $chamada );

				if ( false === $abre ) {
					continue;
				}

				$prefixo = substr( $antes, $abre + strlen( $chamada ) );

				if ( 'avaliar' === $emissora || 'condicional' === $emissora ) {
					$estados['OK']    = true;
					$estados['FALHA'] = true;

					if ( 'condicional' === $emissora ) {
						$estados['N/A'] = true;
					}
				}

				foreach ( $fechados as $fechado ) {
					if ( 1 === preg_match( '/(?:Relatorio::' . ( 'N/A' === $fechado ? 'NA' : $fechado ) . '\b|[\'"]' . preg_quote( $fechado, '/' ) . '[\'"])/', $prefixo ) ) {
						$estados[ 'NA' === $fechado ? 'N/A' : $fechado ] = true;
					}
				}

				break;
			}
		}
	}

	return array_keys( $estados );
}

/**
 * Checagens com piso em disco.
 *
 * @param string $suite Diretório da suíte.
 * @return array<int,string>
 */
function f3b_com_piso( string $suite ): array {
	$saida = array();

	foreach ( glob( $suite . '/fixtures/*', GLOB_ONLYDIR ) ?: array() as $dir ) {
		$nome = basename( $dir );

		if ( f3b_tem_piso( $suite, $nome ) ) {
			$saida[] = $nome;
		}
	}

	sort( $saida );

	return $saida;
}

/**
 * Cruzamento bidirecional entre manifesto e rodada.
 *
 * Dois sentidos, e os dois reprovam:
 *
 * - Requisito aplicável cuja checagem não foi emitida: o manifesto promete
 *   cobertura que a rodada não entregou.
 * - Checagem emitida sem requisito nem armadilha que a justifique: rótulo
 *   órfão, que engorda a contagem sem responder a nada.
 *
 * @param string            $suite    Diretório da suíte.
 * @param array<int,string> $emitidas Nomes emitidos nesta rodada.
 * @return array{ok:bool,achados:array<int,string>,requisitos:int}
 */
function f3b_ck_manifesto_bidirecional( string $suite, array $emitidas ): array {
	$linhas = f3b_tsv( $suite . '/manifesto.tsv' );

	if ( array() === $linhas ) {
		return array(
			'ok'         => false,
			'achados'    => array( 'suite/manifesto.tsv vazio ou ausente' ),
			'requisitos' => 0,
		);
	}

	$achados     = array();
	$cobertas    = array();
	$requisitos  = 0;

	foreach ( $linhas as $n => $linha ) {
		$requisito = trim( $linha[0] ?? '' );
		$checagem  = trim( $linha[1] ?? '' );
		$ambiente  = trim( $linha[2] ?? '' );
		$evidencia = trim( $linha[3] ?? '' );

		if ( '' === $requisito ) {
			continue;
		}

		$requisitos++;

		if ( '' === $checagem ) {
			$achados[] = 'requisito sem checagem: ' . $requisito;
			continue;
		}

		if ( '' === $ambiente || '' === $evidencia ) {
			$achados[] = 'linha ' . ( $n + 1 ) . ' (' . $checagem . '): ambiente ou evidência em branco';
		}

		$cobertas[ $checagem ] = true;

		if ( ! in_array( $checagem, $emitidas, true ) ) {
			$achados[] = 'requisito "' . $requisito . '" aponta para ' . $checagem . ', que a rodada não emitiu';
		}
	}

	$armadilhas = array();

	foreach ( f3b_tsv( $suite . '/armadilhas.tsv' ) as $linha ) {
		$checagem = trim( $linha[1] ?? '' );

		if ( '' !== $checagem && '—' !== $checagem ) {
			$armadilhas[ $checagem ] = true;
		}
	}

	foreach ( $emitidas as $nome ) {
		if ( isset( $cobertas[ $nome ] ) || isset( $armadilhas[ $nome ] ) ) {
			continue;
		}

		$achados[] = 'checagem órfã, sem requisito nem armadilha que a justifique: ' . $nome;
	}

	return array(
		'ok'         => array() === $achados,
		'achados'    => $achados,
		'requisitos' => $requisitos,
	);
}

/**
 * Mapa armadilha → checagem, calculado da rodada.
 *
 * Três resultados possíveis, e eles não são intercambiáveis:
 *
 * - Armadilha mapeada para checagem emitida E com piso em disco: coberta.
 * - Armadilha sem checagem: PENDÊNCIA DECLARADA. Ela aparece no relatório com
 *   o nome, e não some.
 * - Mapeamento cuja checagem não tem piso: BLOCKED, não OK — mapear para uma
 *   checagem que nunca provou saber reprovar é afirmar cobertura sem evidência.
 *
 * @param string            $suite    Diretório da suíte.
 * @param array<int,string> $emitidas Nomes emitidos.
 * @return array{estado:string,mensagem:string}
 */
function f3b_ck_armadilhas_mapeadas( string $suite, array $emitidas ): array {
	$linhas = f3b_tsv( $suite . '/armadilhas.tsv' );

	if ( array() === $linhas ) {
		return array(
			'estado'   => 'FALHA',
			'mensagem' => 'suite/armadilhas.tsv vazio ou ausente: não há mapa de armadilhas para calcular.',
		);
	}

	$cobertas   = array();
	$pendentes  = array();
	$ausentes   = array();
	$sem_piso   = array();

	foreach ( $linhas as $linha ) {
		$armadilha = trim( $linha[0] ?? '' );
		$checagem  = trim( $linha[1] ?? '' );

		if ( '' === $armadilha ) {
			continue;
		}

		if ( '' === $checagem || '—' === $checagem ) {
			$pendentes[] = $armadilha;
			continue;
		}

		if ( ! in_array( $checagem, $emitidas, true ) ) {
			$ausentes[] = $armadilha . ' → ' . $checagem;
			continue;
		}

		if ( ! f3b_tem_piso( $suite, $checagem ) ) {
			$sem_piso[] = $armadilha . ' → ' . $checagem;
			continue;
		}

		$cobertas[] = $armadilha;
	}

	$resumo = sprintf(
		'%d armadilha(s) mapeada(s) com piso, %d pendência(s) declarada(s)',
		count( $cobertas ),
		count( $pendentes )
	);

	if ( array() !== $ausentes ) {
		return array(
			'estado'   => 'FALHA',
			'mensagem' => 'mapeamento para checagem que a rodada não emitiu: ' . f3b_amostra( $ausentes ) . '.',
		);
	}

	if ( array() !== $sem_piso ) {
		return array(
			'estado'   => 'BLOCKED',
			'mensagem' => 'mapeamento sem piso — falta a fixture negativa e a positiva de: ' . f3b_amostra( $sem_piso ) . '.',
		);
	}

	return array(
		'estado'   => 'OK',
		'mensagem' => $resumo . ( array() === $pendentes ? '.' : '; pendências: ' . f3b_amostra( $pendentes, 4 ) . '.' ),
	);
}

/* -------------------------------------------------------------------------
 * FASES — a regra de aplicabilidade e o registro do que cada fase espera.
 *
 * As duas rodam a MESMA classe que o host executa (`F3Base_Imp_Fases`),
 * alcançada por `suite/lib/sonda-fases.php` em subprocesso. Nada aqui
 * reimplementa a regra: reimplementá-la produziria duas respostas para
 * "esta checagem se aplica nesta fase?" e a de cá continuaria dizendo que
 * estava tudo certo no dia em que a outra mudasse.
 * ---------------------------------------------------------------------- */

/**
 * Despacha um pedido à sonda de fases e devolve o que ela respondeu.
 *
 * SUBPROCESSO QUE NÃO RODA NÃO APROVA NADA: erro devolve `erro` preenchido, e
 * quem chama fecha estado adverso com o motivo. Um `catch` que devolvesse array
 * vazio faria a regra de fase absolver tudo por causa de um `php` ausente.
 *
 * @param string              $raiz   Raiz do pacote.
 * @param string              $suite  Diretório da suíte.
 * @param array<string,mixed> $pedido Corpo do pedido.
 * @return array<string,mixed> Resposta decodificada, ou `array('erro' => ...)`.
 */
function f3b_sonda_de_fases( string $raiz, string $suite, array $pedido ): array {
	$sonda = $suite . '/lib/sonda-fases.php';

	if ( ! is_file( $sonda ) ) {
		return array( 'erro' => 'a sonda de fases não existe: ' . $sonda );
	}

	$arquivo = tempnam( sys_get_temp_dir(), 'f3b-fases-' );

	if ( ! is_string( $arquivo ) ) {
		return array( 'erro' => 'não foi possível preparar o arquivo de entrada da sonda de fases' );
	}

	file_put_contents( $arquivo, (string) json_encode( $pedido, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );

	$saida  = array();
	$codigo = 0;

	exec(
		sprintf(
			'php %s %s %s 2>&1',
			escapeshellarg( $sonda ),
			escapeshellarg( $raiz ),
			escapeshellarg( $arquivo )
		),
		$saida,
		$codigo
	);

	unlink( $arquivo );

	$bruto = implode( '', $saida );
	$json  = json_decode( $bruto, true );

	if ( 0 !== $codigo || ! is_array( $json ) ) {
		return array( 'erro' => 'a sonda de fases não respondeu (código ' . $codigo . '): ' . substr( $bruto, 0, 300 ) );
	}

	return $json;
}

/**
 * Veredito de aplicabilidade por fase para uma tabela de nome => fase declarada.
 *
 * @param string                $raiz        Raiz do pacote.
 * @param string                $suite       Diretório da suíte.
 * @param array<string,string>  $declaradas  Nome da checagem => fase em que ela É medida.
 * @param string                $fase_corrente Fase deste emissor.
 * @return array{erro:string,vereditos:array<string,array<string,mixed>>}
 */
function f3b_aplicabilidade_por_fase( string $raiz, string $suite, array $declaradas, string $fase_corrente ): array {
	$resposta = f3b_sonda_de_fases(
		$raiz,
		$suite,
		array(
			'operacao'      => 'aplicabilidade',
			'fase_corrente' => $fase_corrente,
			'declaradas'    => $declaradas,
		)
	);

	if ( isset( $resposta['erro'] ) ) {
		return array(
			'erro'      => (string) $resposta['erro'],
			'vereditos' => array(),
		);
	}

	return array(
		'erro'      => '',
		'vereditos' => (array) ( $resposta['vereditos'] ?? array() ),
	);
}

/**
 * O CONTRAPESO: o registro do que cada fase espera, e o achado de fase nunca executada.
 *
 * A regra de aplicabilidade sozinha ESCONDE DEFEITO — uma checagem que fecha
 * N/A para sempre, porque ninguém nunca roda a fase dela, é aprovação por
 * omissão, e "checagem que nunca falhou não é evidência" é regra da casa desde
 * a 1.0.5. Esta função é a metade que impede isso: para cada fase fechada, ela
 * diz QUANTAS checagens a esperam, QUAIS são e QUANDO ela rodou pela última
 * vez, e fecha WARN quando alguma fase com checagens esperando nunca rodou.
 *
 * O registro de quando cada fase rodou é DURÁVEL: mora em `suite/fases.json`,
 * ao lado do selo da rodada, e é lido daqui antes de ser reescrito no fim.
 *
 * @param string                         $raiz     Raiz do pacote.
 * @param string                         $suite    Diretório da suíte.
 * @param array<int,array<string,string>> $linhas  Linhas emitidas (nome, fase, estado).
 * @param string                         $corrente Fase deste emissor.
 * @return array{estado:string,mensagem:string,durar:array<string,mixed>}
 */
function f3b_ck_registro_de_fases( string $raiz, string $suite, array $linhas, string $corrente ): array {
	$anterior = f3b_registro_de_fases_lido( $raiz );

	$resposta = f3b_sonda_de_fases(
		$raiz,
		$suite,
		array(
			'operacao' => 'registro',
			'linhas'   => $linhas,
			'anterior' => $anterior,
			'agora'    => time(),
		)
	);

	if ( isset( $resposta['erro'] ) ) {
		return array(
			'estado'   => 'BLOCKED',
			'mensagem' => 'o registro de fases não pôde ser calculado, e sem ele a rodada não sabe dizer o que cada fase espera: ' . $resposta['erro'] . '.',
			'durar'    => $anterior,
		);
	}

	$fechadas = array_map( 'strval', (array) ( $resposta['fases_fechadas'] ?? array() ) );

	if ( $fechadas !== F3Base_Suite::FASES ) {
		return array(
			'estado'   => 'FALHA',
			'mensagem' => 'as fases fechadas divergem entre os dois lados: a suíte declara ' . implode( ', ', F3Base_Suite::FASES )
				. ' e F3Base_Imp_Fases declara ' . implode( ', ', $fechadas )
				. ' — fase declarada de um lado e desconhecida do outro absolveria uma checagem por um nome que ninguém reconhece.',
			'durar'    => $anterior,
		);
	}

	$registro = (array) ( $resposta['registro'] ?? array() );
	$quando   = (array) ( $resposta['quando'] ?? array() );
	$por_fase = (array) ( $registro['fases'] ?? array() );
	$cobrar   = array_map( 'strval', (array) ( $registro['cobrar'] ?? array() ) );

	$partes = array();

	foreach ( F3Base_Suite::FASES as $fase ) {
		$dados   = (array) ( $por_fase[ $fase ] ?? array() );
		$esperam = array_map( 'strval', (array) ( $dados['esperam'] ?? array() ) );
		$medidas = array_map( 'strval', (array) ( $dados['medidas'] ?? array() ) );

		if ( array() === $esperam ) {
			$partes[] = $fase . ': 0 checagem espera esta fase — nada a cobrar, e por isso ela não é achado';
			continue;
		}

		/*
		 * FASE TODA-N/A SAI RELATADA, e não some — o que muda é que ela deixa de
		 * virar WARN. Nenhuma checagem desta fase podia ter sido medida nesta
		 * rodada, e cobrar de um emissor a evidência que ele não produz é o
		 * aviso permanente que a 1.1.7 tirou do relatório.
		 */
		if ( ! empty( $dados['nao_aplicavel'] ) ) {
			$partes[] = sprintf(
				'%s: NÃO APLICÁVEL a este emissor — %d checagem(ns) a esperam e TODAS fecharam N/A nesta rodada; última execução %s; esperam: %s',
				$fase,
				count( $esperam ),
				(string) ( $quando[ $fase ] ?? 'NUNCA EXECUTADA' ),
				f3b_amostra( $esperam, 6 )
			);
			continue;
		}

		$partes[] = sprintf(
			'%s: %d checagem(ns) esperam esta fase, %d medida(s) — última execução %s; esperam: %s',
			$fase,
			count( $esperam ),
			count( $medidas ),
			(string) ( $quando[ $fase ] ?? 'NUNCA EXECUTADA' ),
			f3b_amostra( $esperam, 6 )
		);
	}

	$corpo = 'fase corrente desta rodada: ' . $corrente . '. ' . implode( ' | ', $partes )
		. ' O registro dura entre execuções em suite/fases.json, ao lado do selo.';

	if ( array() !== $cobrar ) {
		return array(
			'estado'   => 'WARN',
			'mensagem' => sprintf(
				'%d fase(s) declarada(s) NUNCA foram executadas e TINHAM o que medir nesta rodada — %s. N/A eterno de fase que ninguém roda é aprovação por omissão: o que falta é rodar a fase, e enquanto ela não rodar nenhuma evidência daquele tipo existe. Fase cujas checagens fecharam TODAS em N/A não entra nesta lista — ali não falta ação de ninguém, e ela sai relatada abaixo. %s',
				count( $cobrar ),
				implode( ', ', $cobrar ),
				$corpo
			),
			'durar'    => (array) ( $resposta['durar'] ?? $anterior ),
		);
	}

	return array(
		'estado'   => 'OK',
		'mensagem' => 'nenhuma fase declarada ficou por medir sem motivo: toda fase com checagem esperando já rodou pelo menos uma vez, ou tem TODAS as suas checagens em N/A nesta rodada — não aplicável a este emissor, por desenho, e não pendência de ninguém. ' . $corpo,
		'durar'    => (array) ( $resposta['durar'] ?? $anterior ),
	);
}

/**
 * O registro durável de fases lido do disco.
 *
 * Arquivo ausente devolve vazio, e vazio significa "nenhuma fase rodou" — que é
 * o lado seguro: o registro nasce cobrando, nunca absolvendo.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<string,mixed>
 */
function f3b_registro_de_fases_lido( string $raiz ): array {
	$arquivo = $raiz . '/' . f3b_arquivo_do_registro_de_fases();

	if ( ! is_file( $arquivo ) ) {
		return array();
	}

	$json = json_decode( (string) file_get_contents( $arquivo ), true );

	return is_array( $json ) && is_array( $json['fases'] ?? null ) ? (array) $json['fases'] : array();
}

/**
 * Caminho relativo do registro durável de fases. Ponto único do nome.
 *
 * O nome sai INTEIRO aqui de propósito, ao contrário do que o detector faz com
 * o do registro da rodada: esta função LÊ e não escreve, e é justamente o
 * literal presente no pacote que arma `estatica.gate_fonte_unica` — sem nenhum
 * literal, o detector não teria o que procurar e a regra de produtor único
 * ficaria inerte sobre um registro que ninguém estaria guardando.
 *
 * @return string
 */
function f3b_arquivo_do_registro_de_fases(): string {
	return 'suite/fases.json';
}
