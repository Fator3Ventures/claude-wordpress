/**
 * Sonda de JavaScript. Roda sob o Node de verdade e devolve JSON.
 *
 * Quatro modos: três medem o JAVASCRIPT DO IMPLANTADOR — o cliente da tela
 * de administração — e um mede o par tema × plugin. O cliente do plugin do site (consentimento, leads,
 * tracking, comportamento) tem bancadas próprias no repositório do plugin,
 * rodadas contra o arquivo ENTREGUE no zip; até a 1.7.4 elas moravam aqui e
 * mediam uma fonte que não era a que o site recebia.
 *
 * - `lint <raiz>`: `node --check` em todo `.js`/`.mjs` da raiz. Analisar
 *   JavaScript com expressão regular de PHP seria inferência disfarçada de
 *   medição; quem analisa é o próprio motor.
 * - `extrator <raiz>`: exercita as funções PURAS de
 *   `includes/assets/implantador.js` — as mesmas do arquivo servido, extraídas
 *   dele em tempo de execução, nunca copiadas. A armadilha medida é que a
 *   resposta real de um erro fatal é "HTML + JSON": a página de erro do
 *   WordPress já saiu quando o `shutdown` roda, e o objeto está no FIM do corpo.
 * - `cliente <raiz>`: as decisões do cliente da tela, com teto e piso, sobre as
 *   funções extraídas do arquivo real.
 * - `banner <raiz>`: a ÚNICA bancada do cliente do plugin que ficou aqui, e
 *   ficou por medir um PAR — o `style.css` do TEMA decide a visibilidade e o
 *   cliente do plugin (lido de dentro da reserva) decide o comportamento.
 *
 * Esta sonda nunca imprime estado nem conta: quem imprime e conta é `estado()`,
 * no PHP, em um lugar só.
 */

import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative, extname } from 'node:path';
import { execFileSync } from 'node:child_process';

const EXCLUIDOS = [ 'suite/fixtures/', 'dist/' ];

function arquivos( raiz, extensoes ) {
	const saida = [];

	function andar( dir ) {
		let itens;

		try {
			itens = readdirSync( dir );
		} catch {
			return;
		}

		for ( const item of itens.sort() ) {
			const caminho = join( dir, item );
			const rel = relative( raiz, caminho ).split( '\\' ).join( '/' );

			if ( EXCLUIDOS.some( ( p ) => rel.startsWith( p ) ) ) {
				continue;
			}

			const st = statSync( caminho );

			if ( st.isDirectory() ) {
				andar( caminho );
				continue;
			}

			if ( extensoes.includes( extname( item ).toLowerCase() ) ) {
				saida.push( rel );
			}
		}
	}

	andar( raiz );

	return saida.sort();
}

function lint( raiz ) {
	const achados = [];
	const alvos = arquivos( raiz, [ '.js', '.mjs' ] );

	for ( const rel of alvos ) {
		try {
			execFileSync( process.execPath, [ '--check', join( raiz, rel ) ], { stdio: [ 'ignore', 'ignore', 'pipe' ] } );
		} catch ( e ) {
			const detalhe = String( e.stderr || e.message ).split( '\n' ).filter( Boolean ).slice( 0, 3 ).join( ' | ' );
			achados.push( rel + ': ' + detalhe );
		}
	}

	return { achados, medidas: alvos.length };
}

/**
 * Extrai as duas funções puras do arquivo REAL e as exercita.
 *
 * Teto e piso na mesma sonda: o que precisa achar, acha; o que precisa devolver
 * `null`, devolve — em vez de fingir sucesso sobre um corpo truncado.
 */
function extrator( raiz ) {
	const alvo = join( raiz, 'includes/assets/implantador.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'includes/assets/implantador.js ausente na raiz varrida' ] };
	}

	const inicioTentar = fonte.indexOf( '\tfunction tentarAnalisar(' );
	const fimTentar = fonte.indexOf( '\t/**', inicioTentar );
	const inicioExtrair = fonte.indexOf( '\tfunction extrairJson(' );
	const fimExtrair = fonte.indexOf( '\t/**', inicioExtrair );

	if ( inicioTentar < 0 || inicioExtrair < 0 ) {
		return { achados: [ 'as funções puras não foram encontradas no arquivo real (contrato de extração quebrado)' ] };
	}

	const codigo =
		'let sentinela = "";\n' +
		fonte.slice( inicioTentar, fimTentar ) + '\n' +
		fonte.slice( inicioExtrair, fimExtrair ) + '\n' +
		'return { extrairJson, definir: ( s ) => { sentinela = s; } };';

	let extrairJson;
	let definir;

	try {
		( { extrairJson, definir } = new Function( codigo )() );
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	const SENT = '<<<F3BASE-JSON>>>';
	const jsonOk = '{"ok":true,"lote":3,"estado":"OK"}';
	const paginaDeErro =
		'<!DOCTYPE html><html><body><h1>Erro crítico { do WordPress }</h1>' +
		'<p>{"isto":"nao e a resposta"}</p></body></html>' +
		'\n' + SENT + '\n' + '{"ok":false,"fatal":{"linha":1624}}';

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	definir( SENT );
	afirmar( extrairJson( SENT + '\n' + jsonOk )?.lote === 3, 'teto: resposta limpa com sentinela não foi lida' );
	afirmar( extrairJson( paginaDeErro )?.fatal?.linha === 1624, 'teto: HTML+JSON — não achou o objeto no FIM do corpo' );

	definir( '' );
	afirmar( extrairJson( paginaDeErro )?.fatal?.linha === 1624, 'teto: sem sentinela, a varredura de trás para frente falhou' );

	definir( SENT );
	afirmar( extrairJson( '<!DOCTYPE html><html><body>Sem JSON nenhum</body></html>' ) === null, 'piso: corpo sem JSON não devolveu null' );
	afirmar( extrairJson( SENT + '\n{"quebrado": ' ) === null, 'piso: JSON truncado depois da sentinela fingiu sucesso' );
	afirmar( extrairJson( '[1,2,3]' ) === null, 'piso: array no corpo passou por objeto de resposta' );

	return { achados };
}

/**
 * Extrai UMA função pura do arquivo real, pelo contrato de fatiamento.
 *
 * O contrato é o mesmo do extrator: a função mora a um nível de indentação e é
 * seguida por um bloco `/**`. Copiar o corpo para dentro desta sonda provaria
 * que a cópia funciona, não que o cliente funciona.
 */
function fatiar( fonte, nome ) {
	const inicio = fonte.indexOf( '\tfunction ' + nome + '(' );

	if ( inicio < 0 ) {
		return null;
	}

	/*
	 * O FIM DA FUNÇÃO É O FECHAMENTO NA INDENTAÇÃO DELA, e não o docblock
	 * seguinte. Até a 1.3.5 o corte ia de `\tfunction nome(` até o próximo
	 * `\t/**`, e isso amarrava a EXTRAÇÃO a um COMENTÁRIO. A partir da 1.3.6 o
	 * arquivo que estas bancadas exercitam é o ENTREGUE, que não tem comentário
	 * nenhum: o corte ia até o fim do arquivo e a função não avaliava. Um
	 * contrato de extração que depende de comentário não sobrevive a um pacote
	 * que entrega sem eles — e a chave é a indentação, que o corte de
	 * comentários preserva byte a byte, de propósito.
	 */
	const fim = fonte.indexOf( '\n\t}\n', inicio );

	return fonte.slice( inicio, fim < 0 ? fonte.length : fim + 4 );
}

/**
 * BANCADA DE DOM: o cliente REAL, rodado de ponta a ponta sob o Node.
 *
 * Não é uma cópia nem um recorte. O arquivo servido é avaliado inteiro contra um
 * DOM de mentira — o mínimo que ele toca — e uma resposta de lote já concluída.
 * O que sai daqui é a árvore que o operador veria, e é sobre ela que a ordem no
 * DOM é medida. Medir a ordem lendo o código-fonte com expressão regular
 * responderia "o `appendChild` está escrito depois", que é outra pergunta.
 *
 * `fetch` devolve um THENABLE SÍNCRONO de propósito: uma Promise real adiaria a
 * continuação para o microtask, e a sonda teria de virar assíncrona para ver a
 * árvore pronta. O cliente não sabe a diferença — ele chama `.then().then()` e
 * `.catch()`, e é isso que a bancada oferece.
 *
 * @param {string} fonte Código do cliente, como ele viaja no pacote.
 * @return {Object} A árvore montada e o que a execução deixou nela.
 */
function bancadaDeDom( fonte ) {
	const focados = [];

	class Elemento {
		constructor( tag ) {
			this.tagName = String( tag ).toUpperCase();
			this.filhos = [];
			this.atributos = {};
			this.proprioTexto = '';
			this.className = '';
			this.hidden = false;
			this.recebeuFoco = false;
		}

		setAttribute( nome, valor ) {
			this.atributos[ String( nome ) ] = String( valor );
		}

		getAttribute( nome ) {
			return Object.prototype.hasOwnProperty.call( this.atributos, String( nome ) )
				? this.atributos[ String( nome ) ]
				: null;
		}

		appendChild( filho ) {
			this.filhos.push( filho );

			return filho;
		}

		removeChild( filho ) {
			this.filhos = this.filhos.filter( ( c ) => c !== filho );

			return filho;
		}

		addEventListener() {}

		click() {}

		focus() {
			this.recebeuFoco = true;
			focados.push( this );
		}

		set textContent( valor ) {
			this.proprioTexto = String( valor );
			this.filhos = [];
		}

		get textContent() {
			if ( this.proprioTexto !== '' ) {
				return this.proprioTexto;
			}

			return this.filhos.map( ( f ) => f.textContent ).join( '' );
		}

		set innerHTML( valor ) {
			if ( String( valor ) === '' ) {
				this.filhos = [];
			}
		}

		get innerHTML() {
			return '';
		}

		descendentes( tag ) {
			const alvo = String( tag ).toUpperCase();
			const saida = [];

			for ( const filho of this.filhos ) {
				if ( filho.tagName === alvo ) {
					saida.push( filho );
				}

				saida.push( ...filho.descendentes( alvo ) );
			}

			return saida;
		}

		querySelectorAll( seletor ) {
			return this.descendentes( seletor );
		}
	}

	const raizFalsa = new Elemento( 'div' );

	raizFalsa.setAttribute( 'data-endpoint', 'https://exemplo.test/wp-admin/admin-post.php' );
	raizFalsa.setAttribute( 'data-nonce', 'nonce' );
	raizFalsa.setAttribute( 'data-modo', 'aplicacao' );
	raizFalsa.setAttribute( 'data-execucao', 'exec1' );
	raizFalsa.setAttribute( 'data-total', '1' );
	raizFalsa.setAttribute( 'data-estados-aplicacao', 'PRONTO,EXECUTANDO,SUCESSO_APLICACAO,FALHA_PARCIAL,FALHA,REVERTIDO,BLOCKED' );
	raizFalsa.setAttribute( 'data-fecho-reserva', 'BLOCKED' );

	const resposta = {
		ok: true,
		concluido: true,
		parou: false,
		lote: 0,
		total: 1,
		estado: 'OK',
		etapa: 'entrega',
		rotulo: 'entrega',
		motivo: 'entregáveis conferidos',
		aplicacao: 'SUCESSO_APLICACAO',
		checkpoint: true,
		checagens_falha: 0,
		checagens_blocked: 2,
		unidades_falha: 0,
		unidades_blocked: 1,
		checagens_resumidas: 41,
		checagens_nomes: { BLOCKED: [ 'privacidade.controlador_identificado', 'cadencia.mecanismo_declarado' ] },
		unidades_nomes: { BLOCKED: [ 'entrega' ] },
		checagens: []
	};

	function jaResolvido( valor ) {
		return {
			then( aceito ) {
				const seguinte = aceito( valor );

				return ( seguinte && typeof seguinte.then === 'function' ) ? seguinte : jaResolvido( seguinte );
			},
			catch() {
				return this;
			}
		};
	}

	const documento = {
		title: 'Implantação',
		body: new Elemento( 'body' ),
		getElementById: ( id ) => ( 'f3base-imp' === id ? raizFalsa : null ),
		createElement: ( tag ) => new Elemento( tag )
	};

	const janela = {
		fetch: () => jaResolvido( {
			status: 200,
			headers: { get: () => 'application/json' },
			text: () => jaResolvido( JSON.stringify( resposta ) )
		} ),
		setTimeout: () => 0
	};

	const executar = new Function( 'document', 'window', 'FormData', 'Blob', 'URL', fonte );

	executar(
		documento,
		janela,
		class { append() {} },
		class {},
		{ createObjectURL: () => 'blob:x', revokeObjectURL: () => {} }
	);

	const ordem = raizFalsa.filhos;
	const tabela = ordem.findIndex( ( n ) => 'TABLE' === n.tagName );
	const fim = ordem.findIndex( ( n ) => String( n.className ).includes( 'f3base-imp-encerramento' ) );
	const topo = ordem.findIndex( ( n ) => String( n.className ).includes( 'f3base-imp-progresso' ) );

	return {
		indiceDaTabela: tabela,
		indiceDoEncerramento: fim,
		indiceDoProgresso: topo,
		textoDoProgresso: topo < 0 ? '' : ordem[ topo ].textContent,
		textoDoEncerramento: fim < 0 ? '' : ordem[ fim ].textContent,
		encerramento: fim < 0 ? null : ordem[ fim ],
		focados
	};
}

/**
 * As MARCAS do resumo final: o que só pode aparecer no encerramento.
 *
 * Saem dos rótulos de reserva do próprio cliente — que é o que o servidor
 * traduz — e não de frases inventadas aqui.
 */
const MARCAS_DO_RESUMO = [
	'Contagens por escopo',
	'Nomes do que NÃO fechou OK',
	'Suspensas por dependência declarada'
];

/**
 * A ORDEM NO DOM e a separação entre progresso e encerramento: teto e piso.
 *
 * O DEFEITO MEDIDO NA 1.0.18: `progresso` é o PRIMEIRO filho da raiz — é o que
 * `aria-live` exige de um status ao vivo — e o resumo de encerramento inteiro
 * era escrito DENTRO dele. A conclusão aparecia antes do log e empurrava a
 * tabela para baixo.
 *
 * São duas coisas: progresso é status, encerramento é conclusão. O piso não é
 * uma fixture em disco — é um MUTANTE do próprio cliente, e por isso esta
 * checagem está declarada em `suite/pisos-em-sonda.tsv`.
 *
 * @param {string} fonte    Código do cliente REAL.
 * @param {Function} afirmar Coletor de achados.
 * @return {void}
 */
function ordemDoResultado( fonte, afirmar ) {
	const arvore = bancadaDeDom( fonte );

	/* ---------- teto: a árvore que o operador vê ---------- */

	afirmar( arvore.indiceDoProgresso === 0, 'teto da ordem: o progresso deixou de ser o primeiro filho da raiz — ele é o status ao vivo, e é para isso que aria-live existe' );
	afirmar( arvore.indiceDaTabela >= 0, 'teto da ordem: a tabela do log não foi montada na bancada, e sem ela não há ordem a medir' );
	afirmar( arvore.indiceDoEncerramento >= 0, 'teto do encerramento: nenhum nó de encerramento foi montado — a conclusão precisa existir em nó próprio' );
	afirmar(
		arvore.indiceDoEncerramento > arvore.indiceDaTabela,
		'PISO DA ORDEM NO DOM: o nó de encerramento está no índice ' + String( arvore.indiceDoEncerramento ) +
			' e a tabela no ' + String( arvore.indiceDaTabela ) +
			' — a conclusão tem de vir DEPOIS da tabela, ou ela volta a empurrar o log para baixo'
	);

	for ( const marca of MARCAS_DO_RESUMO ) {
		afirmar(
			arvore.textoDoEncerramento.includes( marca ),
			'teto do resumo: o encerramento não traz "' + marca + '" — o resumo inteiro mora no fim, e o que sai de lá não sai em lugar nenhum'
		);

		afirmar(
			! arvore.textoDoProgresso.includes( marca ),
			'PISO DO PROGRESSO: "' + marca + '" foi escrito na barra de progresso — o resumo final NÃO pode ser escrito em progresso, que é o defeito da 1.0.18'
		);
	}

	afirmar(
		arvore.textoDoProgresso.includes( 'SUCESSO_APLICACAO' ),
		'teto da linha curta: o topo não diz o estado fechado da aplicação, e linha curta que não diz o resultado não é verdadeira, é só curta'
	);

	afirmar(
		arvore.textoDoProgresso.length < arvore.textoDoEncerramento.length,
		'teto da linha curta: o topo (' + String( arvore.textoDoProgresso.length ) + ' caracteres) não é mais curto que o encerramento (' +
			String( arvore.textoDoEncerramento.length ) + ') — separar os dois e deixar o volume no topo não separa nada'
	);

	/* ---------- teto: anunciada e alcançável pelo teclado ---------- */

	const no = arvore.encerramento;

	afirmar( !! no && 'region' === no.getAttribute( 'role' ), 'teto da a11y: o encerramento não é uma região nomeável — sem role=region ele some da navegação por regiões' );
	afirmar( !! no && '' !== String( no.getAttribute( 'aria-label' ) || '' ), 'teto da a11y: a região de encerramento não tem nome acessível' );
	afirmar( !! no && '-1' === no.getAttribute( 'tabindex' ), 'teto da a11y: a região de encerramento não é focável por script (tabindex=-1), e sem isso o foco não pode ir até ela' );
	afirmar( !! no && false === no.hidden, 'teto da a11y: a região de encerramento continuou escondida depois de escrita' );
	afirmar( !! no && no.recebeuFoco, 'teto da a11y: a região de encerramento NÃO recebeu foco — mover o nó sem anunciá-lo troca um defeito de leitura por um defeito de acesso' );

	/* ---------- piso: os mutantes do próprio cliente ---------- */

	const mutantes = [
		{
			rotulo: 'resumo escrito no progresso',
			de: 'encerramento.textContent = resumoDeEncerramento(',
			para: 'progresso.textContent += resumoDeEncerramento(',
			prova: ( m ) => MARCAS_DO_RESUMO.every( ( marca ) => ! m.textoDoProgresso.includes( marca ) ),
			porque: 'a bancada não acusou o resumo escrito na barra de progresso, que É o defeito da 1.0.18: sem isso este piso aprova o defeito que ele existe para reprovar'
		},
		{
			rotulo: 'encerramento antes da tabela',
			de: 'raiz.appendChild( tabela );\n\traiz.appendChild( encerramento );',
			para: 'raiz.appendChild( encerramento );\n\traiz.appendChild( tabela );',
			prova: ( m ) => m.indiceDoEncerramento > m.indiceDaTabela,
			porque: 'a bancada não acusou o encerramento montado ANTES da tabela — ela está medindo a ordem no código, não a ordem no DOM'
		},
		{
			rotulo: 'encerramento sem foco',
			de: '\t\tencerramento.focus();\n',
			para: '',
			prova: ( m ) => !! m.encerramento && m.encerramento.recebeuFoco,
			porque: 'a bancada não acusou a região de encerramento sem foco — a conclusão precisa ser anunciada e alcançável, não só existir'
		}
	];

	for ( const mutante of mutantes ) {
		if ( ! fonte.includes( mutante.de ) ) {
			afirmar( false, 'piso do mutante "' + mutante.rotulo + '": o trecho a mutar não existe mais no cliente, e um piso que não consegue plantar o defeito prova que a bancada é cega' );
			continue;
		}

		const mutado = bancadaDeDom( fonte.replace( mutante.de, mutante.para ) );

		afirmar( ! mutante.prova( mutado ), 'piso do mutante "' + mutante.rotulo + '": ' + mutante.porque );
	}
}

/**
 * As DECISÕES do cliente, exercitadas contra a execução que reprovou.
 *
 * Alimenta a checagem `js.decisoes_do_cliente`, cujo piso mora AQUI e não numa
 * fixture em disco: o caso negativo destas regras é um mutante do próprio
 * cliente, não uma árvore de arquivos. É por isso que ela está declarada em
 * `suite/pisos-em-sonda.tsv`, e é `estatica.piso_em_sonda_declarado` que confere
 * que esta sonda de fato traz os dois ramos.
 *
 * O caso medido: o operador executou, deu erro, executou de novo, e a tela
 * entrou em laço — 163 linhas idênticas de rejeição de lock em 90 segundos,
 * `Etapa 94 de 40` na barra, `estado da aplicação:` vazio no rodapé e um
 * encerramento dizendo "163 BLOCKED" ao lado de "BLOCKED: nenhum".
 *
 * As quatro regras que nasceram daí têm teto e piso aqui, e o laço é SIMULADO:
 * a sonda alimenta a decisão de avanço com a resposta real de rejeição de lock
 * e conta quantas requisições o cliente faria.
 */
function cliente( raiz ) {
	const alvo = join( raiz, 'includes/assets/implantador.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'includes/assets/implantador.js ausente na raiz varrida' ] };
	}

	const nomes = [ 'nomeDaLinha', 'dentroDoPlano', 'planoAvancou', 'proximoLote', 'rejeicaoDeLock', 'fechoDaAplicacao', 'formatarLista', 'nomesPorEstado', 'linhaFinalDeProgresso', 'resumoDeEncerramento' ];
	const pedacos = [];

	for ( const nome of nomes ) {
		const corpo = fatiar( fonte, nome );

		if ( ! corpo ) {
			return { achados: [ 'a função pura ' + nome + '() não foi encontrada no arquivo real (contrato de extração quebrado)' ] };
		}

		pedacos.push( corpo );
	}

	let api;

	try {
		api = new Function( pedacos.join( '\n' ) + '\nreturn { ' + nomes.join( ', ' ) + ' };' )();
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	/* Estados de aplicação aceitos, como o servidor os declara para a tela. */
	const FECHADOS_CLIENTE = [ 'PRONTO', 'EXECUTANDO', 'SUCESSO_APLICACAO', 'FALHA_PARCIAL', 'FALHA', 'REVERTIDO', 'BLOCKED' ];

	/* A resposta REAL da rejeição de lock, como o servidor a monta. */
	const rejeicao = {
		ok: false,
		concluido: true,
		parou: true,
		lote: 0,
		etapa: 'lote',
		rotulo: 'lote.lock_ocupado',
		estado: 'BLOCKED',
		aplicacao: 'BLOCKED',
		motivo: 'execução concorrente rejeitada…',
		lock: { dono: 'exec6890', idade: 38, ttl: 90, abandonado_em: 1756000000, abandonado_as: '2026-08-31 21:31:29' }
	};

	/* ---------- 1. o laço de 163 requisições não pode existir ---------- */

	const TOTAL = 40;
	let indice = 0;
	let requisicoes = 1;
	let passo = api.proximoLote( rejeicao, indice, TOTAL );

	while ( passo.enviar && requisicoes < 500 ) {
		indice = passo.indice;
		requisicoes++;
		passo = api.proximoLote( rejeicao, indice, TOTAL );
	}

	afirmar( requisicoes === 1, 'piso do laço: a rejeição de lock produziu ' + String( requisicoes ) + ' requisições; ela não é resultado de unidade nenhuma e tem de parar na PRIMEIRA' );
	afirmar( passo.parada === 'plano-nao-avancou', 'piso do laço: a parada não foi nomeada como plano-não-avançou, e sim "' + String( passo.parada ) + '"' );
	afirmar( indice + 1 <= TOTAL, 'piso do contador: a etapa visível chegou a ' + String( indice + 1 ) + ' com total ' + String( TOTAL ) + ' — Etapa N de M com N maior que M é o contador contando requisição, não unidade' );

	/* ---------- 1b. o payload EXATO da 1.0.15, sem nenhum campo novo ---------- */

	/*
	 * ESTA É A PROVA QUE IMPORTA: o cliente tem de parar sozinho, mesmo contra
	 * um servidor que não manda `parou`, `concluido`, `lote`, `rotulo` nem
	 * `aplicacao` — que era exatamente a resposta da 1.0.15. Um piso que só
	 * exercitasse o payload novo estaria medindo a correção do servidor duas
	 * vezes e a do cliente nenhuma.
	 */
	const rejeicao1015 = { ok: false, estado: 'BLOCKED', motivo: 'execução concorrente rejeitada: o lock pertence a exec6890, com heartbeat há 38 segundos (TTL 90s).' };

	let indiceVelho = 0;
	let requisicoesVelhas = 1;
	let passoVelho = api.proximoLote( rejeicao1015, indiceVelho, TOTAL );

	while ( passoVelho.enviar && requisicoesVelhas < 500 ) {
		indiceVelho = passoVelho.indice;
		requisicoesVelhas++;
		passoVelho = api.proximoLote( rejeicao1015, indiceVelho, TOTAL );
	}

	afirmar( requisicoesVelhas === 1, 'piso do laço da 1.0.15: contra a resposta antiga o cliente fez ' + String( requisicoesVelhas ) + ' requisições; ele tem de parar sozinho, sem depender de o servidor mandar campo novo' );
	afirmar( indiceVelho + 1 <= TOTAL, 'piso do contador da 1.0.15: a etapa visível chegou a ' + String( indiceVelho + 1 ) + ' com total ' + String( TOTAL ) );
	afirmar( api.nomeDaLinha( String( rejeicao1015.estado ), rejeicao1015.rotulo, 'lote.linha_sem_nome' ) !== '', 'piso do nome da 1.0.15: a resposta antiga não traz rótulo e a linha saiu anônima' );
	afirmar( api.fechoDaAplicacao( rejeicao1015, FECHADOS_CLIENTE, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho da 1.0.15: a resposta antiga não traz estado da aplicação e o rodapé fechou vazio' );

	/* ---------- 2. teto: a resposta de unidade AVANÇA ---------- */

	const unidade = { ok: true, concluido: false, lote: 7, total: TOTAL, estado: 'OK', rotulo: 'preflight', aplicacao: 'EXECUTANDO' };
	const avanco = api.proximoLote( unidade, 7, TOTAL );

	afirmar( avanco.enviar === true && avanco.indice === 8, 'teto do avanço: resposta de unidade que rodou tinha de avançar para o lote seguinte' );
	afirmar( api.planoAvancou( unidade, 7 ) === true, 'teto do avanço: planoAvancou() não reconheceu a resposta da própria unidade' );

	/* BLOCKED de UNIDADE continua avançando: a regra da 1.0.13 não foi enfraquecida. */
	const bloqueada = { ok: false, concluido: false, lote: 7, total: TOTAL, estado: 'BLOCKED', rotulo: 'plugins.mcp', aplicacao: 'EXECUTANDO' };
	afirmar( api.proximoLote( bloqueada, 7, TOTAL ).enviar === true, 'teto do BLOCKED: unidade que MEDIU pré-condição ausente não pode parar a execução inteira — a regra de 1.0.13 continua valendo' );

	/* Resposta sobre OUTRO lote não avança: foi assim que o contador se soltou do plano. */
	afirmar( api.planoAvancou( { concluido: false, lote: 3 }, 7 ) === false, 'piso do avanço: resposta sobre outro lote foi tratada como avanço' );
	afirmar( api.planoAvancou( { concluido: false }, 7 ) === false, 'piso do avanço: resposta sem lote foi tratada como avanço' );
	afirmar( api.planoAvancou( null, 0 ) === false, 'piso do avanço: resposta nula foi tratada como avanço' );

	/* ---------- 3. a guarda de índice ---------- */

	afirmar( api.dentroDoPlano( 0, TOTAL ) === true, 'teto da guarda: o primeiro lote cabe no plano' );
	afirmar( api.dentroDoPlano( TOTAL - 1, TOTAL ) === true, 'teto da guarda: o último lote cabe no plano' );
	afirmar( api.dentroDoPlano( TOTAL, TOTAL ) === false, 'piso da guarda: índice igual ao total não existe no plano' );
	afirmar( api.dentroDoPlano( 93, TOTAL ) === false, 'piso da guarda: o índice 93 com 40 unidades é o Etapa 94 de 40 da tela' );
	afirmar( api.dentroDoPlano( -1, TOTAL ) === false, 'piso da guarda: índice negativo passou' );
	afirmar( api.proximoLote( { concluido: false, lote: TOTAL - 1 }, TOTAL - 1, TOTAL ).enviar === false, 'piso da guarda: o avanço depois da última unidade tinha de parar' );

	/* ---------- 4. rejeição de lock reconhecida com os quatro fatos ---------- */

	const lock = api.rejeicaoDeLock( rejeicao );

	afirmar( lock !== null, 'teto do lock: a rejeição não foi reconhecida' );
	afirmar( lock && lock.dono === 'exec6890', 'teto do lock: o dono não saiu na linha' );
	afirmar( lock && lock.idade === '38', 'teto do lock: a idade do heartbeat não saiu na linha' );
	afirmar( lock && lock.ttl === '90', 'teto do lock: o TTL não saiu na linha' );
	afirmar( lock && lock.abandonadoAs === '2026-08-31 21:31:29', 'teto do lock: o HORÁRIO em que o lock passa a ser abandonado não saiu na linha, e é ele que responde "quanto esperar"' );
	afirmar( api.rejeicaoDeLock( unidade ) === null, 'piso do lock: resposta de unidade comum foi lida como rejeição de lock' );
	afirmar( api.rejeicaoDeLock( null ) === null, 'piso do lock: resposta nula foi lida como rejeição de lock' );

	/* ---------- 5. linha que não fecha OK é NOMEADA ---------- */

	afirmar( api.nomeDaLinha( 'BLOCKED', '', 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: linha BLOCKED sem rótulo ficou anônima — foi assim que "163 BLOCKED" saiu ao lado de "BLOCKED: nenhum"' );
	afirmar( api.nomeDaLinha( 'FALHA', null, 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: linha FALHA sem rótulo ficou anônima' );
	afirmar( api.nomeDaLinha( 'WARN', '   ', 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: rótulo só de espaço passou por nome' );
	afirmar( api.nomeDaLinha( 'BLOCKED', 'lote.lock_ocupado', 'lote.linha_sem_nome' ) === 'lote.lock_ocupado', 'teto do nome: o rótulo do servidor foi substituído pelo de reserva' );
	afirmar( api.nomeDaLinha( 'OK', '', 'lote.linha_sem_nome' ) === '', 'teto do nome: OK sem rótulo continua resumido, por desenho' );

	/*
	 * E a contagem por estado não pode divergir da lista de nomes: com a linha
	 * nomeada, uma contagem de N linhas BLOCKED tem pelo menos um nome.
	 */
	const renderizadas = {};
	const nomesRenderizados = {};

	for ( let i = 0; i < 163; i++ ) {
		const estado = 'BLOCKED';
		renderizadas[ estado ] = ( renderizadas[ estado ] || 0 ) + 1;

		if ( ! nomesRenderizados[ estado ] ) {
			nomesRenderizados[ estado ] = [];
		}

		const nome = api.nomeDaLinha( estado, '', 'lote.linha_sem_nome' );

		if ( nome !== '' && nomesRenderizados[ estado ].indexOf( nome ) === -1 ) {
			nomesRenderizados[ estado ].push( nome );
		}
	}

	afirmar(
		renderizadas.BLOCKED > 0 && nomesRenderizados.BLOCKED.length > 0,
		'piso da contagem-com-nomes: ' + String( renderizadas.BLOCKED ) + ' linha(s) BLOCKED e ' + String( nomesRenderizados.BLOCKED.length ) + ' nome(s) — o mesmo escopo se contradizendo em duas frases seguidas'
	);

	/* ---------- 6. o rodapé nunca fecha vazio ---------- */

	const FECHADOS = FECHADOS_CLIENTE;

	afirmar( api.fechoDaAplicacao( { aplicacao: 'SUCESSO_APLICACAO' }, FECHADOS, 'BLOCKED' ) === 'SUCESSO_APLICACAO', 'teto do fecho: o estado que o servidor mandou não foi impresso' );
	afirmar( api.fechoDaAplicacao( rejeicao, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'teto do fecho: execução que nunca adquiriu o lock tinha de fechar BLOCKED' );
	afirmar( api.fechoDaAplicacao( {}, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: resposta sem estado da aplicação fechou vazio, e vazio não é estado fechado' );
	afirmar( api.fechoDaAplicacao( { aplicacao: '' }, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: estado vazio foi impresso como se fosse fechado' );
	afirmar( api.fechoDaAplicacao( null, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: sem resposta nenhuma o rodapé fechou vazio' );
	afirmar( api.fechoDaAplicacao( { aplicacao: 'INVENTADO' }, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: estado fora da lista declarada passou por fechado' );
	afirmar( FECHADOS.indexOf( api.fechoDaAplicacao( { aplicacao: 'QUALQUER' }, FECHADOS, 'BLOCKED' ) ) !== -1, 'piso do fecho: o fecho de reserva não é um estado fechado' );

	/* ---------- 7. progresso é status; encerramento é conclusão ---------- */

	/*
	 * As DUAS funções puras, extraídas do arquivo real: a linha curta do topo
	 * não pode carregar o resumo, e o resumo tem de carregar tudo.
	 */
	const curta = api.linhaFinalDeProgresso( 'Execução concluída.', 'SUCESSO_APLICACAO', 'estado da aplicação', 'O resultado completo está no fim desta página.' );

	afirmar( curta.includes( 'SUCESSO_APLICACAO' ), 'teto da linha curta: o estado fechado da aplicação não saiu na linha do topo' );
	afirmar( curta.includes( 'fim desta página' ), 'teto da linha curta: a linha do topo não diz onde está o resultado completo' );

	for ( const marca of MARCAS_DO_RESUMO ) {
		afirmar( ! curta.includes( marca ), 'piso da linha curta: ela trouxe "' + marca + '", que é parte do resumo e mora no encerramento' );
	}

	const completo = api.resumoDeEncerramento(
		{
			checagens_falha: 0,
			checagens_blocked: 2,
			unidades_falha: 0,
			unidades_blocked: 1,
			checagens_nomes: { BLOCKED: [ 'privacidade.controlador_identificado' ] },
			unidades_nomes: { BLOCKED: [ 'entrega' ] }
		},
		{ contagens: { BLOCKED: 3 }, nomes: { BLOCKED: [ 'entrega' ] }, resumidas: 41, suspensas: 0, bloqueadas: 3 },
		{
			escopos: 'Contagens por escopo — checagens: %1$s FALHA e %2$s BLOCKED · unidades: %3$s FALHA e %4$s BLOCKED · tela: %5$s FALHA e %6$s BLOCKED.',
			nomes: 'Nomes do que NÃO fechou OK — checagens: %1$s · unidades: %2$s · tela: %3$s.',
			resumidas: 'Checagens OK dentro de unidades, resumidas por desenho: %1$s.',
			aplicacao: 'estado da aplicação',
			nenhum: 'nenhum'
		},
		'SUCESSO_APLICACAO'
	);

	afirmar( completo.includes( 'privacidade.controlador_identificado' ), 'teto do resumo: o nome da checagem que não fechou OK não saiu na lista' );
	afirmar( completo.includes( 'Suspensas por dependência declarada: 0 de 3' ), 'teto do resumo: a suspensão por dependência declarada não saiu com os dois números' );
	afirmar( completo.includes( 'SUCESSO_APLICACAO' ), 'teto do resumo: o estado fechado da aplicação não saiu no fim do resumo' );
	afirmar( completo.includes( 'BLOCKED: nenhum' ) === false, 'piso do resumo: a lista do escopo da tela saiu vazia enquanto a contagem do MESMO escopo dizia 3 — o instrumento se contradizendo em duas frases seguidas' );

	/* ---------- 8. a ORDEM NO DOM, medida na árvore que o operador vê ---------- */

	ordemDoResultado( fonte, afirmar );

	return { achados };
}

/**
 * A FONTE DO PLUGIN COMO O SITE A RECEBE: um arquivo, lido de dentro da reserva.
 *
 * Espelho de `f3b_fonte_do_plugin()` da suíte PHP, com a mesma exceção: quando a
 * raiz varrida NÃO tem reserva nenhuma em `assets/plugins/`, um `fontes/plugin/`
 * em claro responde — é o que uma fixture do piso traz, para continuar legível.
 * No pacote real a reserva sempre existe e o inventário recusa `fontes/plugin/`.
 *
 * @param {string} raiz     Raiz varrida.
 * @param {string} relativo Caminho relativo à pasta do plugin.
 * @return {string} Conteúdo, ou vazio.
 */
function fonteDoPlugin( raiz, relativo ) {
	let zips = [];

	try {
		zips = readdirSync( join( raiz, 'assets/plugins' ) ).filter( ( n ) => /-\d+\.\d+\.\d+\.zip$/.test( n ) ).sort();
	} catch {
		zips = [];
	}

	if ( 1 === zips.length ) {
		const zip = join( raiz, 'assets/plugins', zips[ 0 ] );

		/*
		 * A PASTA VEM DE DENTRO DO ZIP, não do nome do arquivo: é a entrada de
		 * topo que o host cria ao instalar, e é ela que a regra da reserva
		 * (pacote.reserva_confere_com_o_catalogo) compara com a pasta_esperada.
		 * Um zip cujo nome e cuja pasta discordassem seria lido aqui pela pasta
		 * errada e a leitura fecharia vazia, calada, se o nome mandasse.
		 */
		let pasta = '';

		try {
			const primeira = execFileSync( 'unzip', [ '-Z1', zip ], { stdio: [ 'ignore', 'pipe', 'ignore' ] } ).toString( 'utf8' ).split( /\r?\n/ ).find( ( l ) => '' !== l );
			pasta = primeira ? primeira.split( '/' )[ 0 ] : '';
		} catch {
			pasta = '';
		}

		if ( '' === pasta ) {
			return '';
		}

		try {
			return execFileSync( 'unzip', [ '-p', zip, pasta + '/' + relativo ], { stdio: [ 'ignore', 'pipe', 'ignore' ] } ).toString( 'utf8' );
		} catch {
			return '';
		}
	}

	try {
		return readFileSync( join( raiz, 'fontes/plugin', relativo ), 'utf8' );
	} catch {
		return '';
	}
}

/**
 * MODELO DE CASCATA: o `display` EFETIVO de um elemento, pelo CSS real.
 *
 * Por que ele existe, e por que medir `hidden === true` não bastaria. O defeito
 * da 1.1.2 é exatamente o descompasso entre as duas coisas: o cliente punha
 * `hidden = true` e o elemento continuava na tela, porque
 * `.f3base-consentimento-painel { display: grid }` é regra de AUTOR e vence o
 * `[hidden] { display: none }` da folha do USER AGENT — a origem decide antes
 * de a especificidade ser consultada. Uma bancada que afirmasse `hidden ===
 * true` teria aprovado o defeito com a melhor cara possível.
 *
 * Então a bancada carrega o `style.css` REAL, monta o par (`hidden`, `display`)
 * e responde à única pergunta que importa: **o visitante vê isto?**
 *
 * @param {string} css Conteúdo da folha.
 * @return {Object} Modelo com as regras que decidem visibilidade.
 */
function modeloDeCascata( css ) {
	const limpo = String( css ).replace( /\/\*[\s\S]*?\*\//g, '' );
	const porClasse = new Map();
	const parHidden = new Set();
	const declaracoes = new Map();
	let globalImportante = false;

	const re = /([^{}]+)\{([^{}]*)\}/g;
	let m;

	while ( ( m = re.exec( limpo ) ) ) {
		const bruto = m[ 1 ].trim().replace( /\s+/g, ' ' );
		const corpo = m[ 2 ];

		for ( const parte of bruto.split( ',' ) ) {
			const seletor = parte.trim();

			if ( '' === seletor || seletor.startsWith( '@' ) ) {
				continue;
			}

			const alvo = seletor.split( /\s*[ >+~]\s*/ ).pop();
			const classes = ( alvo.match( /\.[A-Za-z0-9_-]+/g ) || [] ).map( ( c ) => c.slice( 1 ) );

			for ( const classe of classes ) {
				const antes = declaracoes.get( classe ) || [];
				declaracoes.set( classe, antes.concat( [ { seletor, corpo } ] ) );
			}

			const achou = /(?:^|[;\s])display\s*:\s*([^;]+)/i.exec( corpo );

			if ( ! achou ) {
				continue;
			}

			const valor = achou[ 1 ].trim();
			const importante = /!important/i.test( valor );
			const nenhum = 'none' === valor.replace( /!important/i, '' ).trim().toLowerCase();
			const temHidden = seletor.includes( '[hidden]' );

			if ( temHidden && nenhum ) {
				if ( '[hidden]' === seletor && importante ) {
					globalImportante = true;
				}

				for ( const classe of classes ) {
					parHidden.add( classe );
				}

				continue;
			}

			if ( temHidden ) {
				continue;
			}

			for ( const classe of classes ) {
				porClasse.set( classe, valor );
			}
		}
	}

	return {
		/**
		 * `display` efetivo de um elemento, na ordem em que o navegador decide.
		 */
		display( classes, escondido ) {
			const lista = String( classes || '' ).split( /\s+/ ).filter( Boolean );

			if ( escondido ) {
				if ( globalImportante ) {
					return 'none';
				}

				for ( const classe of lista ) {
					if ( parHidden.has( classe ) ) {
						return 'none';
					}
				}
			}

			for ( const classe of lista ) {
				if ( porClasse.has( classe ) ) {
					return porClasse.get( classe );
				}
			}

			return escondido ? 'none' : 'block';
		},
		visivel( elemento ) {
			return 'none' !== this.display( elemento.className, elemento.hidden );
		},
		declaracoesDe( classe ) {
			return ( declaracoes.get( classe ) || [] ).map( ( d ) => d.corpo ).join( ';' );
		}
	};
}

/**
 * BANCADA DO BANNER: o cliente de consentimento REAL, contra um DOM de mentira
 * e o CSS de verdade.
 *
 * Nada aqui é reimplementação: o arquivo servido é avaliado inteiro. O que a
 * bancada oferece é o mínimo de DOM que ele toca — criar elemento, anexar,
 * ouvir clique e tecla, ler e escrever cookie, dar foco, escrever custom
 * property na raiz — e o que ela devolve é o que o visitante veria.
 *
 * @param {string} fonte  Código do cliente, como ele viaja no pacote.
 * @param {string} css    Folha de estilo que decide a visibilidade.
 * @param {Object} extras Ajustes do caso (cookie inicial, dados).
 * @return {Object} A árvore montada e os instrumentos para agir sobre ela.
 */
function bancadaDoBanner( fonte, css, extras ) {
	const opcoes = extras || {};
	const cascata = modeloDeCascata( css );
	const focos = [];

	class El {
		constructor( tag ) {
			this.tagName = String( tag ).toUpperCase();
			this.nodeType = 1;
			this.filhos = [];
			this.attrs = {};
			this.proprioTexto = '';
			this.className = '';
			this.id = '';
			this.hidden = false;
			this.ouvintes = {};
			this.pai = null;
			this.offsetHeight = 72;
			this.style = {
				props: {},
				setProperty( nome, valor ) {
					this.props[ nome ] = String( valor );
				},
				removeProperty( nome ) {
					delete this.props[ nome ];
				}
			};
		}

		setAttribute( nome, valor ) {
			this.attrs[ String( nome ) ] = String( valor );
		}

		getAttribute( nome ) {
			return Object.prototype.hasOwnProperty.call( this.attrs, String( nome ) )
				? this.attrs[ String( nome ) ]
				: null;
		}

		removeAttribute( nome ) {
			delete this.attrs[ String( nome ) ];
		}

		appendChild( filho ) {
			this.filhos.push( filho );
			filho.pai = this;

			return filho;
		}

		removeChild( filho ) {
			this.filhos = this.filhos.filter( ( c ) => c !== filho );

			return filho;
		}

		get parentNode() {
			return this.pai;
		}

		addEventListener( tipo, fn ) {
			( this.ouvintes[ tipo ] = this.ouvintes[ tipo ] || [] ).push( fn );
		}

		focus() {
			focos.push( this );
		}

		scrollIntoView() {}

		matches( seletor ) {
			if ( seletor.startsWith( '[' ) ) {
				const nome = seletor.slice( 1, seletor.indexOf( ']' ) ).split( '=' )[ 0 ];

				return Object.prototype.hasOwnProperty.call( this.attrs, nome );
			}

			return String( this.className ).split( /\s+/ ).includes( seletor.replace( /^\./, '' ) );
		}

		set textContent( valor ) {
			this.proprioTexto = String( valor );
			this.filhos = [];
		}

		get textContent() {
			return '' !== this.proprioTexto
				? this.proprioTexto
				: this.filhos.map( ( f ) => f.textContent ).join( '' );
		}

		todos() {
			const saida = [ this ];

			for ( const filho of this.filhos ) {
				saida.push( ...filho.todos() );
			}

			return saida;
		}

		clicar() {
			for ( const fn of this.ouvintes.click || [] ) {
				fn( { target: this, preventDefault() {} } );
			}
		}
	}

	const controle = new El( 'button' );

	controle.className = 'f3base-consentimento-abrir';
	controle.setAttribute( 'data-f3base-consentimento', 'abrir' );
	controle.setAttribute( 'aria-expanded', 'false' );

	const raizEl = new El( 'html' );
	const corpo = new El( 'body' );

	corpo.appendChild( controle );

	const documento = {
		readyState: 'complete',
		cookie: String( opcoes.cookie || '' ),
		body: corpo,
		documentElement: raizEl,
		ouvintes: {},
		createElement: ( tag ) => new El( tag ),
		addEventListener( tipo, fn ) {
			( this.ouvintes[ tipo ] = this.ouvintes[ tipo ] || [] ).push( fn );
		},
		querySelectorAll( seletor ) {
			return corpo.todos().filter( ( el ) => {
				try {
					return el.matches( seletor );
				} catch {
					return false;
				}
			} );
		},
		dispatchEvent() {
			return true;
		}
	};

	const janela = {
		dataLayer: [],
		location: { protocol: 'https:' },
		localStorage: {
			guardado: {},
			getItem( k ) {
				return Object.prototype.hasOwnProperty.call( this.guardado, k ) ? this.guardado[ k ] : null;
			},
			setItem( k, v ) {
				this.guardado[ k ] = String( v );
			}
		},
		f3baseConsentimentoDados: Object.assign( {
			padrao: 'pre-aprovado',
			ttlDias: 180,
			controleRodape: true,
			avisoPrimeiraVisita: false,
			cookie: 'f3base_consentimento',
			seletorControle: '[data-f3base-consentimento]',
			idBanner: 'f3base-consentimento-banner',
			categorias: [ 'analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization' ],
			textos: {
				titulo: 'Política de Cookie',
				explicacao: 'Este site carrega ferramentas de medição por padrão.',
				aceitar: 'Permitir medição',
				recusar: 'Desligar medição',
				fechar: 'Fechar',
				estadoAtivo: 'Medição ligada neste navegador.',
				estadoNegado: 'Medição desligada neste navegador.',
				politica: 'Política de Privacidade'
			},
			politicaUrl: 'https://exemplo.test/privacidade/'
		}, opcoes.dados || {} )
	};

	// eslint-disable-next-line no-new-func
	new Function( 'window', 'document', 'CustomEvent', fonte )(
		janela,
		documento,
		class {
			constructor( tipo, init ) {
				this.type = tipo;
				Object.assign( this, init );
			}
		}
	);

	for ( const fn of documento.ouvintes.DOMContentLoaded || [] ) {
		fn();
	}

	function banner() {
		return corpo.todos().find( ( el ) => String( el.className ).includes( 'f3base-consentimento-banner' ) ) || null;
	}

	function botaoDo( sufixo ) {
		const faixa = banner();

		return faixa
			? faixa.todos().find( ( el ) => String( el.className ).includes( 'f3base-consentimento-' + sufixo ) ) || null
			: null;
	}

	function clicarControle() {
		for ( const fn of documento.ouvintes.click || [] ) {
			fn( { target: controle, preventDefault() {} } );
		}
	}

	function decisaoNoCookie() {
		const achou = /f3base_consentimento=([^;]+)/.exec( documento.cookie );

		return achou ? achou[ 1 ] : '';
	}

	return {
		cascata,
		documento,
		janela,
		controle,
		focos,
		raizEl,
		banner,
		botaoDo,
		clicarControle,
		decisaoNoCookie,
		visivel() {
			const faixa = banner();

			return null !== faixa && cascata.visivel( faixa );
		}
	};
}

/**
 * `js.banner_de_consentimento` — o CONTROLE DO TITULAR, medido no comportamento.
 *
 * O DEFEITO QUE ESTA CHECAGEM EXISTE PARA REPRODUZIR, e ele foi visto na tela
 * antes de ser medido: o controle do rodapé abria uma TELA que cobria o site, e
 * os botões dentro dela não funcionavam. Duas causas, e a segunda não é do CSS:
 *
 * 1. `.f3base-consentimento-painel { display: grid }` — regra de AUTOR — vencia
 *    o `[hidden] { display: none }` da folha do USER AGENT. O `hidden` que o
 *    cliente alternava não escondia nada, e o botão "Fechar" não fechava.
 * 2. `definir()` gravava o cookie, atualizava o Consent Mode e sincronizava o
 *    texto — e não fechava nada. "Permitir" e "Desligar" funcionavam por
 *    dentro e pareciam inertes.
 *
 * A bancada mede COMPORTAMENTO, e não markup: ela roda o cliente real contra um
 * DOM de mentira e decide visibilidade pelo CSS real, com o par (`hidden`,
 * `display`) — que é a única pergunta que o visitante faz.
 *
 * O PISO é o CSS DA 1.1.2, escrito aqui: se a bancada não reprovar o painel que
 * cobre a tela e não fecha, ela é cega, e a aprovação dela não vale nada. Os
 * outros dois pisos são MUTANTES do cliente: `definir()` sem o fecho e o
 * `fechar()` sem a devolução do foco.
 *
 * @param {string} raiz Raiz do pacote.
 * @return {Object} Achados.
 */
function bannerDeConsentimento( raiz ) {
	const alvoCss = join( raiz, 'fontes/tema/style.css' );
	const achados = [];
	let css;

	/*
	 * O CLIENTE VEM DE DENTRO DA RESERVA — 2.0.0. É o arquivo ENTREGUE, o que
	 * o visitante recebe, lido do zip publicado copiado para a árvore. Esta é a
	 * única bancada de JavaScript do plugin que ficou neste repositório, e ficou
	 * porque mede um PAR: a visibilidade é decidida pelo `style.css` do TEMA e o
	 * comportamento pelo cliente do PLUGIN — nenhum dos dois repositórios pode
	 * medir o par sozinho, e é aqui que os dois se encontram.
	 */
	const fonte = fonteDoPlugin( raiz, 'assets/f3base-consentimento.js' );

	if ( '' === fonte ) {
		return { achados: [ 'assets/f3base-consentimento.js não pôde ser lido de dentro da reserva do plugin na raiz varrida (nem de fontes/plugin/ em claro, que só uma fixture traz)' ] };
	}

	try {
		css = readFileSync( alvoCss, 'utf8' );
	} catch {
		return { achados: [ 'fontes/tema/style.css ausente na raiz varrida' ] };
	}

	function afirmar( ok, texto ) {
		if ( ! ok ) {
			achados.push( texto );
		}
	}

	/* TETO 1: o banner NASCE FECHADO, pelo critério que o CSS de verdade impõe. */
	const b1 = bancadaDoBanner( fonte, css, {} );
	const faixa = b1.banner();

	afirmar(
		null !== faixa,
		'teto: o banner não foi construído no iniciar(). Ele precisa existir fechado desde a carga — é o que faz o aria-controls do controle do rodapé apontar para um id que existe, em vez de uma referência pendurada'
	);

	if ( null === faixa ) {
		return { achados };
	}

	afirmar(
		'f3base-consentimento-banner' === faixa.id,
		'teto: o banner não carrega o id declarado em f3baseConsentimentoDados.idBanner — o aria-controls do controle aponta para ele, e um id diferente é referência pendurada. Observado: "' + faixa.id + '"'
	);

	afirmar(
		! b1.visivel(),
		'teto: logo depois de iniciar() o banner ESTÁ VISÍVEL pelo critério do CSS real (display efetivo: ' + b1.cascata.display( faixa.className, faixa.hidden ) + ', hidden: ' + faixa.hidden + '). hidden === true não basta quando uma regra de autor declara display sobre a mesma classe'
	);

	afirmar(
		'false' === faixa.getAttribute( 'aria-modal' ),
		'teto: o banner precisa continuar declarando aria-modal="false" — ele não é modal, e a página continua utilizável atrás dele'
	);

	afirmar(
		'-1' === faixa.getAttribute( 'tabindex' ),
		'teto: o banner precisa de tabindex="-1" para poder receber o foco ao abrir sem entrar na ordem de tabulação'
	);

	/* TETO 2: a faixa mora na BASE do viewport, e não cobre a página. */
	const regraDaFaixa = b1.cascata.declaracoesDe( 'f3base-consentimento-banner' );

	afirmar(
		/inset-block-end\s*:/.test( regraDaFaixa ),
		'teto: a regra da faixa não declara inset-block-end — um banner de rodapé mora na BASE do viewport, e sem isso ele não sabe onde ficar'
	);

	afirmar(
		! /(?:^|[;\s])inset\s*:\s*0/.test( regraDaFaixa ),
		'teto: a regra da faixa ainda declara inset: 0 — foi assim que ela virou a tela que cobria o site inteiro. A faixa tem a altura do conteúdo, e o visitante continua vendo e usando a página'
	);

	/* TETO 3: abrir dá foco ao banner, anuncia o estado e reserva o espaço. */
	b1.clicarControle();

	afirmar(
		b1.visivel(),
		'teto: o clique no controle do rodapé não deixou o banner visível pelo critério do CSS real'
	);

	afirmar(
		'true' === b1.controle.getAttribute( 'aria-expanded' ),
		'teto: o controle do rodapé não passou a anunciar aria-expanded="true" ao abrir'
	);

	afirmar(
		b1.focos.length > 0 && b1.focos[ b1.focos.length - 1 ] === b1.banner(),
		'teto: ao abrir, o foco não foi para o banner — quem aciona pelo teclado fica com o foco no rodapé e não alcança os botões'
	);

	afirmar(
		'aberto' === b1.raizEl.getAttribute( 'data-f3base-banner' ) &&
			/^\d+px$/.test( String( b1.raizEl.style.props[ '--f3base-banner-altura' ] || '' ) ),
		'teto: ao abrir, a raiz não recebeu data-f3base-banner="aberto" com --f3base-banner-altura em px. Sem a reserva, a faixa fixa tampa o fim do documento — inclusive o rodapé e o próprio controle que a abriu'
	);

	/* TETO 4: ACEITAR grava e FECHA, e o foco volta para quem abriu. */
	const b2 = bancadaDoBanner( fonte, css, {} );

	b2.clicarControle();
	b2.botaoDo( 'aceitar' ).clicar();

	afirmar(
		'granted' === b2.decisaoNoCookie(),
		'teto: clicar em aceitar não gravou granted no cookie de decisão. Observado: "' + b2.decisaoNoCookie() + '"'
	);

	afirmar(
		! b2.visivel(),
		'teto: clicar em aceitar gravou a decisão e NÃO fechou o banner — foi este o segundo defeito da 1.1.2, e ele não é do CSS: definir() gravava, atualizava e sincronizava, e deixava a caixa exatamente onde estava'
	);

	afirmar(
		'false' === b2.controle.getAttribute( 'aria-expanded' ),
		'teto: ao fechar por aceitar, o controle do rodapé continuou anunciando aria-expanded="true"'
	);

	afirmar(
		b2.focos.length > 0 && b2.focos[ b2.focos.length - 1 ] === b2.controle,
		'teto: ao fechar, o foco não voltou para o controle que abriu o banner — quem fechou pelo teclado é jogado para o início do documento'
	);

	afirmar(
		'0px' === String( b2.raizEl.style.props[ '--f3base-banner-altura' ] ) &&
			null === b2.raizEl.getAttribute( 'data-f3base-banner' ),
		'teto: ao fechar, a reserva de espaço no corpo não foi devolvida — a página fica com um respiro embaixo que não corresponde a banner nenhum'
	);

	/* TETO 5: RECUSAR grava e fecha. */
	const b3 = bancadaDoBanner( fonte, css, {} );

	b3.clicarControle();
	b3.botaoDo( 'recusar' ).clicar();

	afirmar(
		'denied' === b3.decisaoNoCookie(),
		'teto: clicar em recusar não gravou denied no cookie de decisão. Observado: "' + b3.decisaoNoCookie() + '"'
	);

	afirmar(
		! b3.visivel(),
		'teto: clicar em recusar gravou a decisão e não fechou o banner'
	);

	/* TETO 6: FECHAR fecha, e NÃO decide nada. */
	const b4 = bancadaDoBanner( fonte, css, {} );

	b4.clicarControle();
	b4.botaoDo( 'fechar' ).clicar();

	afirmar(
		! b4.visivel(),
		'teto: clicar em fechar não fechou o banner pelo critério do CSS real — este é exatamente o sintoma que o usuário viu na tela'
	);

	afirmar(
		'' === b4.decisaoNoCookie(),
		'teto: clicar em fechar GRAVOU uma decisão. Fechar é sair sem decidir; gravar ali transformaria o gesto de dispensar a faixa em consentimento. Observado: "' + b4.decisaoNoCookie() + '"'
	);

	/* TETO 7: reabrir depois de decidir mostra o ESTADO CORRENTE. */
	const b5 = bancadaDoBanner( fonte, css, { cookie: 'f3base_consentimento=denied' } );

	b5.clicarControle();

	const estadoNegado = b5.banner().todos()
		.find( ( el ) => String( el.className ).includes( 'f3base-consentimento-estado' ) );

	afirmar(
		estadoNegado && estadoNegado.textContent === b5.janela.f3baseConsentimentoDados.textos.estadoNegado,
		'teto: ao reabrir com a negativa gravada, o banner não mostra o estado corrente. Observado: "' + ( estadoNegado ? estadoNegado.textContent : '(sem parágrafo de estado)' ) + '"'
	);

	const b6 = bancadaDoBanner( fonte, css, { cookie: 'f3base_consentimento=granted' } );

	b6.clicarControle();

	const estadoAtivo = b6.banner().todos()
		.find( ( el ) => String( el.className ).includes( 'f3base-consentimento-estado' ) );

	afirmar(
		estadoAtivo && estadoAtivo.textContent === b6.janela.f3baseConsentimentoDados.textos.estadoAtivo,
		'teto: ao reabrir com o aceite gravado, o banner não mostra o estado corrente. Observado: "' + ( estadoAtivo ? estadoAtivo.textContent : '(sem parágrafo de estado)' ) + '"'
	);

	/* TETO 8: a caixa interna existe, e a regra do tema deixa de ser órfã. */
	afirmar(
		null !== b1.banner().todos().find( ( el ) => String( el.className ).includes( 'f3base-consentimento-caixa' ) ),
		'teto: nenhum elemento carrega .f3base-consentimento-caixa. A regra existe em style.css e ficou órfã na 1.1.2 — foi por isso que o painel apareceu sem caixa, sobre um fundo chapado'
	);

	/*
	 * PISO 1 — O CSS DA 1.1.2, escrito aqui como mutante.
	 *
	 * Ele existe para provar que a bancada ENXERGA o defeito de hoje. Uma
	 * bancada que aprovasse este CSS estaria medindo `hidden === true` e
	 * chamando isso de visibilidade.
	 */
	const cssDa112 = css.replace(
		/\.f3base-consentimento-banner\s*\{[^}]*\}\s*\.f3base-consentimento-banner\[hidden\]\s*\{[^}]*\}/,
		'.f3base-consentimento-banner { position: fixed; inset: 0; display: grid; place-items: center; }'
	);

	afirmar(
		cssDa112 !== css,
		'piso: o mutante do CSS da 1.1.2 não pôde ser montado — a regra da faixa e o par [hidden] não foram encontrados em style.css, e um piso que não muda nada aprova qualquer coisa'
	);

	const p1 = bancadaDoBanner( fonte, cssDa112, {} );

	afirmar(
		p1.visivel(),
		'piso: com o CSS da 1.1.2 — display de classe e SEM o par [hidden] — a bancada precisa ver o banner VISÍVEL logo depois de iniciar(), e não viu. Se ela não reproduz o painel que cobre a tela, ela é cega'
	);

	p1.clicarControle();
	p1.botaoDo( 'fechar' ).clicar();

	afirmar(
		p1.visivel(),
		'piso: com o CSS da 1.1.2 a bancada precisa ver que o botão Fechar NÃO fecha — regra de autor vence a folha do user agent e o hidden não tem efeito. A bancada viu o banner fechado, então ela não mede o par (hidden, display)'
	);

	/* PISO 2 — `definir()` sem o fecho: a 1.1.2 de novo, agora do lado do JS. */
	const jsSemFecho = fonte.replace( /\n\t\tfecharAviso\(\);\n\t\tfechar\(\);\n/, '\n\t\tfecharAviso();\n' );

	afirmar(
		jsSemFecho !== fonte,
		'piso: o mutante de definir() sem o fecho não pôde ser montado — a sequência fecharAviso()/fechar() não foi encontrada no cliente real'
	);

	const p2 = bancadaDoBanner( jsSemFecho, css, {} );

	p2.clicarControle();
	p2.botaoDo( 'aceitar' ).clicar();

	afirmar(
		p2.visivel() && 'granted' === p2.decisaoNoCookie(),
		'piso: com definir() sem o fecho, a bancada precisa ver o cookie gravado E o banner ainda aberto — que é o botão que funciona por dentro e parece inerte. Ela não viu'
	);

	/* PISO 3 — `fechar()` sem devolver o foco. */
	const jsSemFoco = fonte.replace( /\n\t\t\t\tabridor\.focus\(\);\n/, '\n\t\t\t\tvoid abridor;\n' );

	afirmar(
		jsSemFoco !== fonte,
		'piso: o mutante de fechar() sem a devolução do foco não pôde ser montado — a chamada abridor.focus() não foi encontrada no cliente real'
	);

	const p3 = bancadaDoBanner( jsSemFoco, css, {} );

	p3.clicarControle();
	p3.botaoDo( 'fechar' ).clicar();

	afirmar(
		p3.focos.length > 0 && p3.focos[ p3.focos.length - 1 ] !== p3.controle,
		'piso: com fechar() sem a devolução do foco, a bancada precisa acusar que o foco não voltou ao controle. Ela não acusou'
	);

	return { achados };
}


const modo = process.argv[ 2 ] || '';
const raiz = process.argv[ 3 ] || '';

if ( 'lint' === modo ) {
	process.stdout.write( JSON.stringify( lint( raiz ) ) );
} else if ( 'extrator' === modo ) {
	process.stdout.write( JSON.stringify( extrator( raiz ) ) );
} else if ( 'cliente' === modo ) {
	process.stdout.write( JSON.stringify( cliente( raiz ) ) );
} else if ( 'banner' === modo ) {
	process.stdout.write( JSON.stringify( bannerDeConsentimento( raiz ) ) );
} else {
	process.stdout.write( JSON.stringify( { achados: [ 'modo desconhecido: ' + modo ] } ) );
}
