<?php
/**
 * Checagens que NÃO rodam neste ambiente, e a FASE em que cada uma É medida.
 *
 * Aqui não há WordPress, banco, navegador nem produção. Nenhuma checagem que
 * dependa disso pode fechar FALHA (afirmaria ter medido) nem sumir (esconderia
 * a lacuna). O que mudou na 1.1.6 é COMO ela não fecha, porque até a 1.1.5 um
 * estado só respondia por duas perguntas diferentes:
 *
 * - **A pergunta se aplica aqui e falta alguém fazer alguma coisa** —
 *   pré-condição ausente. Continua **BLOCKED**, como o contrato manda.
 * - **Esta fase não produz este tipo de evidência, por desenho** — a condição
 *   "esta fase produz esta evidência" é FALSA, e o contrato já tinha estado
 *   para isso: **N/A com a condição declarada**. Pedir um navegador a uma
 *   rodada de build não é pendência de ninguém.
 *
 * A tabela abaixo declara a fase de cada entrada, e é `F3Base_Imp_Fases` —
 * a mesma classe que o host executa — quem decide entre os dois estados,
 * comparando a fase declarada com `F3Base_Suite::FASE_CORRENTE`. Fase declarada
 * fora da lista fechada NÃO absolve: esquecer de declarar seria o caminho
 * barato para sair do BLOCKED.
 *
 * E A REGRA NÃO ANDA SOZINHA. Um N/A que nunca se resolve porque ninguém nunca
 * roda aquela fase é aprovação por omissão — por isso `fases.registro_de_execucao`
 * declara, a cada rodada, o que cada fase espera e quando ela rodou pela última
 * vez, e fecha WARN sobre a fase que NUNCA rodou.
 *
 * As condicionais que este projeto não instancia continuam fechando **N/A com a
 * condição declarada**, também nomeadas: checagem condicional que some é
 * indistinguível de checagem esquecida.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Tabela das checagens bloqueadas: nome => motivo, o que falta, classe, fase.
 *
 * @return array<string,array{motivo:string,falta:string,classe:string,fase:string}>
 */
function f3b_bloqueadas(): array {
	return array(
		'a11y.piso_da_sonda' => array(
			'motivo' => 'o piso da sonda de acessibilidade exige plantar um defeito em página renderizada e provar que a sonda o acusa',
			'falta'  => 'WordPress servindo as páginas e um motor de acessibilidade sobre o DOM renderizado',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'visual.inspecao_paginas' => array(
			'motivo' => 'inspeção visual mede a página pintada, não o markup',
			'falta'  => 'navegador headless com viewport declarado sobre o site publicado',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'formulario.destino_privado' => array(
			'motivo' => 'com contato.whatsapp_e164 PREENCHIDA o regime existe, e conferir o href promovido é fato do servidor: o link profundo é montado em render_block, no site-core, e não no arquivo do pacote',
			'falta'  => 'WordPress com o site-core ativo servindo a página, para ler o href do CTA publicado',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'formulario.envio_ponta_a_ponta' => array(
			'motivo' => 'envio aceito pelo servidor é teste funcional, não análise estática',
			'falta'  => 'WordPress com o endpoint de leads ativo e uma submissão real',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'formulario.degradado_sem_js' => array(
			'motivo' => 'o caminho degradado só existe quando a página roda sem JavaScript no navegador',
			'falta'  => 'navegador com JavaScript desligado sobre a página publicada',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'consentimento.controle_no_rodape' => array(
			'motivo' => 'o controle precisa ser encontrado no DOM de TODA página publicada, e o rodapé é renderizado pelo WordPress',
			'falta'  => 'WordPress renderizando as páginas com o tema ativo',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'menu.objeto_unico' => array(
			'motivo' => 'o menu é um post wp_navigation no banco; sem banco não existe objeto para conferir',
			'falta'  => 'WordPress com o post wp_navigation criado e f3base_nav_id gravada',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'menu.ref_injetado_no_render' => array(
			'motivo' => 'a injeção do ref acontece no filtro render_block_data, em tempo de render',
			'falta'  => 'WordPress executando o render do bloco core/navigation',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'htaccess.cabecalhos_servidos' => array(
			'motivo' => 'cabeçalho de resposta é fato do servidor, não do arquivo',
			'falta'  => 'servidor HTTP respondendo, para ler os cabeçalhos na resposta',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'htaccess.regras_preservadas' => array(
			'motivo' => 'a preservação das regras existentes só se mede contra um .htaccess real da hospedagem',
			'falta'  => 'acesso ao .htaccess da instalação de destino',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'mcp.autoteste' => array(
			'motivo' => 'o autoteste do canal é DESPACHADO — pela Abilities API quando ela existe, pelo servidor REST interno sempre — e o resultado estruturado dele vai para o relatório; despachar uma rota exige um servidor REST vivo, e a árvore do pacote não é um',
			'falta'  => 'WordPress com o complemento do canal ativo, registrando files/selftest, e um servidor REST que aceite o despacho — a regra do veredito já tem teto e piso em mcp.autoteste_veredito',
			'classe' => 'pendencia-externa',
			'fase'   => 'local',
		),
		'mcp.autoteste_recusa_credencial' => array(
			'motivo' => 'a recusa a uma credencial NÃO autorizada não é mensurável de dentro do WordPress rodando como administrador: wp_execute_ability() e rest_do_request() despacham dentro do processo, com o usuário já autenticado, e nenhuma passa pela autenticação HTTP. Forjar um usuário sem capacidade mediria o permission_callback, não a credencial — prova fraca com nome de prova negativa. Quem produz a evidência é o REQUISITANTE EXTERNO, e não o host: por isso a fase declarada é campo, e não producao — declará-la producao fazia a linha sair BLOCKED em toda execução no site, para sempre, sobre uma ausência por desenho',
			'falta'  => 'uma requisição HTTP de fora ao servidor do canal, com uma credencial sem a capacidade exigida, e o 401 ou 403 observado na ponta',
			'classe' => 'pendencia-externa',
			'fase'   => 'campo',
		),
		'cadencia.mecanismo_declarado' => array(
			'motivo' => 'o gatilho da cadência é o AGENDAMENTO OBSERVADO no host — evento para o hook, com recorrência declarada e próxima execução conferida —, e é ele que o relatório de entrega nomeia quando mecanismo_de_cadencia está vazia; a chave nasce vazia por desenho e vazia significa "não há gatilho externo além do WP-Cron", que é o padrão desta base e não uma falta. Só há pré-condição ausente quando NÃO há agendamento observado E a chave está vazia: aí não existe gatilho nenhum a nomear',
			'falta'  => 'uma execução da aplicação em WordPress, para observar o agendamento do hook da cadência — a regra do veredito, com os três ramos, já tem teto e piso em cadencia.mecanismo_do_fato_medido',
			'classe' => 'leitura-de-volta',
			'fase'   => 'producao',
		),
		'plugins.autoupdate_caminho' => array(
			'motivo' => 'flag ligada e CAMINHO DE ATUALIZAÇÃO são fatos diferentes, e o segundo é medido LOCALMENTE: o cabeçalho Update URI de cada plugin INSTALADO, lido do disco, mais has_filter() sobre update_plugins_{host}. Nada disso existe na árvore do pacote, que não tem plugin instalado nem filtro registrado — e nada disso é rede',
			'falta'  => 'WordPress com os plugins instalados, para ler o cabeçalho de cada um e conferir o filtro do host — a regra da classificação e dos vereditos já tem teto e piso em plugins.autoupdate_caminho_separado',
			'classe' => 'medida',
			'fase'   => 'local',
		),
		'mcp.canal_configurado' => array(
			'motivo' => 'a conferência é das 12 rotas de arquivo e banco PELO NOME, expostas pelo servidor MCP',
			'falta'  => 'WordPress com o servidor MCP e o complemento instalados e ativos',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'mcp.canal_unico' => array(
			'motivo' => 'canal duplicado só aparece na instalação: a medição é o CENSO DE PLUGINS ATIVOS daquele site — o papel canal-mcp-complemento declarado mais qualquer plugin ativo com o mesmo Plugin Name —, e a checagem LÊ o que a unidade mcp gravou; a regra do leitor, nos cinco ramos, já tem teto e piso em mcp.canal_unico_mede_plugins_ativos',
			'falta'  => 'WordPress onde a unidade mcp rode e registre o censo de plugins ativos do canal',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'plugins.autoupdate_conforme_politica' => array(
			'motivo' => 'a política se confere por LEITURA DE VOLTA da option de auto-update de cada plugin instalado',
			'falta'  => 'WordPress com os plugins instalados e a option auto_update_plugins legível',
			'classe' => 'leitura-de-volta',
			'fase'   => 'producao',
		),
		'plugins.adaptador_leitura_de_volta' => array(
			'motivo' => 'o gate do adaptador de SEO é reler do banco cada chave gravada e comparar',
			'falta'  => 'WordPress com o plugin de SEO instalado e ativo',
			'classe' => 'leitura-de-volta',
			'fase'   => 'producao',
		),
		'tracking.emissor_unico' => array(
			'motivo'  => 'a contagem de emissores só existe no HTML PUBLICADO, e nem a rota de origem nem uma requisição externa respondem na árvore do pacote. O que se mede é a contagem de <script src=…googletagmanager.com/gtag/js…>, de gtm.js, de fbevents.js e de insight.min.js, separando emissão COM a marca do site-core (o id que o WordPress imprime a partir do handle, e o id que o carregador põe em cada tag que cria) de emissão SEM ela — a regra do discriminante, com os quatro ramos e a tabela declarada de casos, já tem teto e piso em tracking.emissor_unico_discrimina',
			'falta'   => 'WordPress servindo as páginas, para ler o HTML pela rota de origem e, quando alcançável, por requisição externa',
			'classe'  => 'medida',
			'fase'    => 'producao',
		),
		'capi.envio_de_servidor' => array(
			'motivo' => 'com o token da Conversions API gravado, o que resta a medir é o que a META responde ao evento de servidor — código HTTP, events_received e fbtrace_id —, e isso é fato de uma conta de anúncios real',
			'falta'  => 'um site com o token gravado e um lead real, para ler a resposta da Meta e conferir a deduplicação contra o evento de navegador no Test Events — a regra do envio já tem teto e piso em leads.capi_meta',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'verificacao.dominio_declarada' => array(
			'motivo' => 'com um token de verificação declarado, o que resta a medir é a metatag no HTML SERVIDO e o veredito do console do fornecedor sobre ela',
			'falta'  => 'WordPress servindo as páginas, para ler a metatag no <head> publicado — a regra da emissão já tem teto e piso em verificacao.tag_do_valor_gravado',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'origem.rota_carimbada' => array(
			'motivo' => 'a rota de origem é REST e responde no runtime do WordPress',
			'falta'  => 'WordPress com o site-core ativo e a rota registrada',
			'classe' => 'pendencia-externa',
			'fase'   => 'producao',
		),
		'tema.ancora_sob_sticky' => array(
			'motivo' => 'o recuo da âncora sob o cabeçalho fixo é posição medida na rolagem, não declaração de CSS',
			'falta'  => 'navegador com a página renderizada e rolagem até uma âncora',
			'classe' => 'medida',
			'fase'   => 'local',
		),
		'seguranca.coop_preserva_popup' => array(
			'motivo' => 'a interação entre COOP e a janela aberta por popup só se observa no navegador',
			'falta'  => 'navegador sobre o site publicado, com os cabeçalhos servidos',
			'classe' => 'medida',
			'fase'   => 'producao',
		),
		/*
		 * Esta rodada é a PRODUTORA do registro, não a consumidora dele. Quem o
		 * consome é o host, que confere o hash do pacote instalado contra o que
		 * o registro declara — e o registro desta rodada só existe depois do
		 * selo, que é a última etapa. Fechar OK aqui seria a suíte se aprovando
		 * pelo arquivo que ela mesma acabou de escrever.
		 *
		 * A regra do leitor tem piso dos dois lados em `entrega.rodada_limpa_confere`,
		 * e a separação de gates em `entrega.gates_separados`: BLOCKED aqui trava
		 * o gate da FASE declarada e não segura mais o implantador ativo.
		 */
		'entrega.rodada_limpa' => array(
			'motivo' => 'esta rodada PRODUZ o registro (suite/rodada.json, gravado no selo, com o hash do pacote que ela mediu); quem o CONSOME é o host, conferindo-o contra o hash do pacote instalado, e uma rodada que se aprovasse pelo arquivo que ela mesma escreveu não estaria medindo nada',
			'falta'  => 'um WordPress com o pacote instalado, para conferir o hash do pacote instalado contra o registro que viajou dentro dele — a regra do leitor já tem teto e piso em entrega.rodada_limpa_confere',
			'classe' => 'pendencia-externa',
			'fase'   => 'build',
		),
		'orcamento.pagina' => array(
			'motivo' => 'peso, requisições e nós de DOM são medidos na entrega contra orcamento_pagina; declarar aqui seria inventar número',
			'falta'  => 'página servida por um servidor real, com a medição do carregamento',
			'classe' => 'medida',
			'fase'   => 'producao',
		),
		/*
		 * A COLETA PASSOU A EXISTIR NA 1.1.3, E A CHECAGEM CONTINUA BLOCKED.
		 *
		 * Esta é a distinção que a release inteira sustenta, e ela vale ser
		 * escrita: **coleta existir não é o mesmo que o dado ter chegado.** O
		 * que mudou é real e mensurável — o carregador instala
		 * `PerformanceObserver` para LCP, CLS e INP e lê o TTFB do Navigation
		 * Timing, sem biblioteca externa, e relata os quatro no primeiro
		 * ocultamento da página. A regra da coleta tem teto e piso em
		 * `js.comportamento_instrumentado`, que mede o que sai no `dataLayer`.
		 *
		 * O que NÃO mudou é o que esta linha afirma. Core Web Vitals de campo
		 * são a distribuição do percentil 75 sobre visitas REAIS, e não existe
		 * nada disso antes de haver visitantes: nem o valor, nem a distribuição,
		 * nem a estabilidade que faz o número significar alguma coisa. Fechar
		 * OK aqui porque o coletor existe seria trocar "o instrumento está
		 * instalado" por "a medida foi tomada" — que é exatamente o tipo de
		 * afirmação que esta suíte existe para não fazer. O que a pré-condição
		 * ganhou foi PRECISÃO: até a 1.1.2 faltava a coleta E o tráfego; agora
		 * falta só o tráfego, e a linha diz qual dos dois.
		 */
		'desempenho.core_web_vitals' => array(
			'motivo' => 'a COLETA passou a existir na 1.1.3 — LCP, CLS, INP e TTFB por PerformanceObserver nativo, sem biblioteca externa, relatados uma vez no primeiro ocultamento da página, com teto e piso em js.comportamento_instrumentado —, mas coleta existir não é o mesmo que o dado ter chegado: Core Web Vitals de campo são a distribuição sobre visitas REAIS, e antes de haver visitante não há valor, nem distribuição, nem estabilidade. Fechar OK porque o coletor existe seria trocar "o instrumento está instalado" por "a medida foi tomada"',
			'falta'  => 'site em produção recebendo tráfego real e a conta de medição de destino acumulando os eventos que o coletor já emite — a pré-condição que sobrou é o TRÁFEGO, e só ele: até a 1.1.2 faltavam a coleta e o tráfego',
			'classe' => 'medida',
			'fase'   => 'campo',
		),
		'idempotencia.tres_execucoes' => array(
			'motivo' => 'idempotência é a terceira execução não mudar nada que a segunda já tinha estabilizado',
			'falta'  => 'WordPress onde a aplicação possa rodar três vezes seguidas',
			'classe' => 'teste-funcional',
			'fase'   => 'local',
		),
		'homologacao.a_para_b' => array(
			'motivo' => 'a homologação A→B compara duas instalações reais, a de origem e a de destino',
			'falta'  => 'duas instalações WordPress, a de origem na release anterior',
			'classe' => 'teste-funcional',
			'fase'   => 'producao',
		),
	);
}

/**
 * Tabela das checagens condicionais que este projeto não instancia.
 *
 * @return array<string,array{condicao:string,classe:string,fase:string}>
 */
function f3b_nao_aplicaveis(): array {
	return array(
		'handoff.pacote_de_entrega' => array(
			'condicao' => 'o site de referência desta base não é artefato de handoff: não há site_referencia.tipo=handoff na configuração, e o conteúdo nasce dos arquivos de content/',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
		'handoff.credenciais_rotacionadas' => array(
			'condicao' => 'sem artefato de handoff, não há contrato de entrega de terceiro com credencial a rotacionar',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
		'formulario.regime_cf7' => array(
			'condicao' => 'o destino declarado pelo regime cf7-email (formularios.1.caixa_de_leads) está vazio, e é a presença do valor — e só ela — que faz o regime existir. A chave mora DENTRO da entrada do regime desde a 1.1.0, e não mais no topo de contato: ela é propriedade do regime, e nenhum módulo do site-core a lia. O conjunto fechado dele fica registrado para quem precisar; preencher a chave faz o regime passar a existir na execução seguinte',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
		/*
		 * ESTE NOME ESTÁ NAS DUAS TABELAS, e isso é a regra funcionando. Com o
		 * destino PREENCHIDO a checagem é pendência externa de verdade — o href
		 * promovido é fato do servidor. Com o destino VAZIO não há pendência
		 * nenhuma: o regime não existe, o CTA não é publicado, e relatar isso
		 * como pendente seria a tela dizendo que falta algo que ninguém pediu.
		 * `executar.php` deixa a condição declarada vencer a pendência, e o nome
		 * sai uma vez só.
		 */
		'formulario.destino_privado' => array(
			'condicao' => 'o destino declarado pelo regime whatsapp (contato.whatsapp_e164) está vazio, e é a presença do valor — e só ela — que faz o regime existir. Enquanto ela estiver vazia o CTA não é publicado, nem no comportamento degradado; preencher a chave faz o botão passar a existir na execução seguinte, sem passo manual',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
		/*
		 * O TOKEN DA CONVERSIONS API NÃO EXISTE NO PACOTE, E ISSO É A DECISÃO.
		 * Ele é segredo do site; o arquivo único viaja dentro do zip e chega a
		 * quem faz o upload. A ausência é declarada — e medida, por
		 * `estatica.segredo_fora_da_configuracao`, que reprova se o nome
		 * reaparecer na configuração, no schema ou num lote do implantador.
		 * Aqui a condição sai NOMEANDO a option, porque N/A que não diz o que
		 * preencher é N/A que ninguém sabe desfazer.
		 */
		'capi.envio_de_servidor' => array(
			'condicao' => 'o token de acesso da Conversions API da Meta (option f3base_meta_capi_token) não existe neste pacote e não pode existir: ele é SEGREDO do site, e o config/site.json viaja dentro do zip — declará-lo ali seria copiá-lo para todo lugar por onde o pacote passa. Sem token nenhum evento de servidor é enviado, e o navegador continua mandando o Lead com eventID esperando por ele. Quem grava a option é o agente, pelo canal, e o envio passa a existir no lead seguinte, sem passo manual e sem release. A regra do envio — event_id do navegador, hashes, o que NUNCA sai em claro e a recusa da Meta que não toca no lead — já tem teto e piso em leads.capi_meta',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
		'verificacao.dominio_declarada' => array(
			'condicao' => 'as duas chaves de verificação de posse do domínio (verificacao_dominio.google e verificacao_dominio.meta, gravadas nas options f3base_verificacao_google e f3base_verificacao_meta) estão vazias, e é a presença do valor — e só ela — que faz a metatag existir. Os tokens são obtidos nos consoles dos fornecedores, que é passo humano e está descrito em TEMPLATE.md; preenchê-los faz a tag passar a existir na página seguinte, sem release. A regra da emissão — tag presente com valor, ausente sem, e valor fora da forma preservado com aviso — já tem teto e piso em verificacao.tag_do_valor_gravado',
			'classe'   => 'analise-estatica',
			'fase'     => 'build',
		),
	);
}
