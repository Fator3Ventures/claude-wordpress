<?php
/**
 * Sonda do BUNDLE em subprocesso: o que viaja, o que não viaja, e de onde veio.
 *
 * TRÊS AFIRMAÇÕES, e as três só podem ser medidas no ARTEFATO montado e na
 * RESERVA que ele carrega — não na árvore de origem, que tem tudo, e não no
 * código do empacotamento, que descreve a intenção. O que o operador faz upload
 * é o zip.
 *
 * 1. `pacote.plugin_so_como_zip` — a FONTE do plugin não viaja dentro do bundle,
 *    e a reserva dele viaja. Até a 1.6.6 a fonte viajava, e era ela que dava à
 *    renomeação de prefixo algo para renomear: o bundle entregava, dentro do
 *    pacote, uma cópia que ninguém deve editar e que diverge da release
 *    publicada no instante seguinte. Desde a 2.0.0 a fonte nem mora mais neste
 *    repositório — e a regra continua, porque o que ela guarda é o BUNDLE, e um
 *    diretório `fontes/plugin/` recriado por engano voltaria a viajar calado.
 * 2. `pacote.reserva_confere_com_o_catalogo` — a reserva embutida é O ZIP
 *    PUBLICADO: o `sha256` dos bytes é o que o catálogo declara em
 *    `plugins.instalaveis.<n>.sha256`, a versão que o NOME carrega é a que o
 *    CABEÇALHO de dentro declara, a pasta de topo é a `pasta_esperada`, e a
 *    cópia dentro do bundle é byte a byte a da árvore. Até a 1.7.4 o
 *    implantador MONTAVA o zip do plugin e comparava a reserva com a própria
 *    montagem: as duas batiam sempre, e nenhuma delas era o que o catálogo
 *    servia — a reserva dizia 1.0.1 e o catálogo publicava 1.0.0, com a suíte
 *    inteira em verde.
 * 3. `pacote.copia_vendorizada_confere` — cada arquivo de `partilhado/` é, byte a
 *    byte, a entrada correspondente da reserva, e a lista do que é cópia está
 *    declarada em `partilhado/VENDORIZADO.tsv` nos dois sentidos: arquivo sem
 *    declaração e declaração sem arquivo são achados. Medido na 1.7.4: quatro
 *    dos cinco arquivos vendorizados diferiam do zip publicado, um sem a guarda
 *    de `class_exists`, outro sem duas chaves de cabeçalho que o plugin governa.
 *
 * O PISO DAS TRÊS É A ENTRADA MUTANTE. As regras são funções puras sobre
 * listas e sobre pares de digestos, e o piso passa a elas a entrada com o
 * defeito plantado: uma entrada de fonte a mais, a reserva a menos, um digesto
 * trocado, um cabeçalho que não bate com o nome, um arquivo vendorizado com um
 * byte a mais. É a única forma honesta aqui — plantar o defeito no build de
 * verdade significaria montar um segundo bundle defeituoso a cada rodada, e o
 * defeito está na ENTRADA, não no zip.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

require_once __DIR__ . '/regra.php';

$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );
$suite = dirname( __DIR__ );

/**
 * Apaga uma árvore inteira, em PHP.
 *
 * Sem `rm -rf` montado em string: além de `estatica.detector_codigo_em_string`
 * acusar shell por concatenação — e acusar com razão —, um `rm -rf` cujo
 * argumento venha de uma variável é a linha em que um erro de escape apaga o
 * que ninguém pediu.
 *
 * @param string $dir Diretório.
 * @return void
 */
function f3b_sb_apagar( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	foreach ( (array) scandir( $dir ) as $nome ) {
		$nome = (string) $nome;

		if ( '.' === $nome || '..' === $nome ) {
			continue;
		}

		$alvo = $dir . '/' . $nome;

		if ( is_dir( $alvo ) && ! is_link( $alvo ) ) {
			f3b_sb_apagar( $alvo );
			continue;
		}

		unlink( $alvo );
	}

	rmdir( $dir );
}

/**
 * REGRA PURA: a fonte do plugin não viaja, e a reserva dele viaja.
 *
 * @param array<int,string> $entradas Entradas do bundle.
 * @param string            $prefixo  Prefixo da fonte do plugin dentro do bundle.
 * @param string            $reserva  Caminho esperado da reserva dentro do bundle.
 * @return array<int,string>
 */
function f3b_sb_plugin_so_como_zip( array $entradas, string $prefixo, string $reserva ): array {
	$achados = array();
	$fontes  = array();

	foreach ( $entradas as $entrada ) {
		if ( str_starts_with( $entrada, $prefixo ) && ! str_ends_with( $entrada, '/' ) ) {
			$fontes[] = $entrada;
		}
	}

	if ( array() !== $fontes ) {
		$achados[] = 'teto: o bundle carrega ' . count( $fontes ) . ' arquivo(s) da FONTE do plugin (' . implode( ', ', array_slice( $fontes, 0, 3 ) )
			. ( 3 < count( $fontes ) ? ', …' : '' ) . '). O plugin é artefato próprio desde a 1.7.0 e tem repositório próprio desde a 2.0.0: entregar a fonte dele dentro do bundle põe no pacote '
			. 'uma cópia que ninguém deve editar e que diverge da release publicada, e é essa cópia que dá à renomeação de prefixo algo para renomear — '
			. 'um fork do plugin por site, com options que nenhuma release alcança';
	}

	if ( ! in_array( $reserva, $entradas, true ) ) {
		$achados[] = 'teto: o bundle NÃO contém a reserva do plugin em ' . $reserva . '. A instalação prefere a URL declarada no catálogo, e a reserva é o que '
			. 'responde quando aquele endereço não responde: sem ela, a entrega falha por um endereço que alguém moveu';
	}

	return $achados;
}

/**
 * REGRA PURA: a reserva é o zip publicado, e o diz de cinco formas que precisam concordar.
 *
 * @param string            $sha256_medido       Digesto dos bytes da reserva na árvore.
 * @param string            $sha256_declarado    Digesto declarado no catálogo.
 * @param string            $versao_do_nome      Versão lida do nome do arquivo.
 * @param string            $versao_do_cabecalho Versão lida do cabeçalho de dentro do zip.
 * @param string            $sha256_no_bundle    Digesto da cópia extraída do bundle.
 * @param array<int,string> $entradas_do_zip     Entradas do zip da reserva.
 * @param string            $pasta               Pasta de topo esperada.
 * @return array<int,string>
 */
function f3b_sb_reserva_confere( string $sha256_medido, string $sha256_declarado, string $versao_do_nome, string $versao_do_cabecalho, string $sha256_no_bundle, array $entradas_do_zip, string $pasta ): array {
	$achados = array();

	if ( '' === $sha256_declarado ) {
		$achados[] = 'teto: o catálogo NÃO declara o sha256 do plugin do site (plugins.instalaveis.<n>.sha256). Sem ele o host FIXA o primeiro digesto que observar e reprova toda '
			. 'execução seguinte em que o arquivo mudar — inclusive a que instala a release nova publicada de propósito. O digesto a declarar é o que a rodada do repositório do plugin selou, e ele está no SHA256SUMS.txt da entrega';
	} elseif ( $sha256_declarado !== $sha256_medido ) {
		$achados[] = 'teto: a reserva na árvore (' . substr( $sha256_medido, 0, 12 ) . '…) NÃO é o zip que o catálogo declara (' . substr( $sha256_declarado, 0, 12 ) . '…). '
			. 'A instalação pela URL confere o digesto e instala UMA coisa; a instalação pela reserva instalaria OUTRA, com o mesmo nome — o site que caiu na reserva fica com um plugin que o catálogo não publicou';
	}

	if ( '' === $versao_do_nome || '' === $versao_do_cabecalho ) {
		$achados[] = 'teto: não foi possível ler a versão da reserva ' . ( '' === $versao_do_nome ? 'do NOME do arquivo' : 'do CABEÇALHO de dentro do zip' )
			. ', e é do nome que o host lê a versão embarcada para compará-la com a instalada (plugins.site_core_versao)';
	} elseif ( $versao_do_nome !== $versao_do_cabecalho ) {
		$achados[] = 'teto: o nome da reserva diz ' . $versao_do_nome . ' e o cabeçalho de dentro do zip diz ' . $versao_do_cabecalho . '. O host lê a versão do NOME — o cabeçalho não chega ao site —, '
			. 'e plugins.site_core_versao passaria a comparar a instalada com um número que o plugin não tem';
	}

	if ( '' === $sha256_no_bundle ) {
		$achados[] = 'teto: a cópia da reserva dentro do bundle não pôde ser lida, e sem ela não está provado que o que o operador faz upload é o que a suíte mediu';
	} elseif ( $sha256_no_bundle !== $sha256_medido ) {
		$achados[] = 'teto: a reserva DENTRO do bundle (' . substr( $sha256_no_bundle, 0, 12 ) . '…) não é byte a byte a da árvore (' . substr( $sha256_medido, 0, 12 ) . '…): o que o operador faz upload não é o que a suíte mediu';
	}

	if ( array() === $entradas_do_zip ) {
		$achados[] = 'teto: a reserva não tem entradas legíveis — não é um zip, ou está vazia, e escopo vazio não pode aprovar';
	} else {
		$topos = array();

		foreach ( $entradas_do_zip as $entrada ) {
			$topos[ explode( '/', $entrada, 2 )[0] ] = true;
		}

		if ( array( $pasta => true ) !== $topos ) {
			$achados[] = 'teto: a pasta de topo da reserva é ' . implode( ', ', array_keys( $topos ) ) . ' e a pasta_esperada do catálogo é ' . $pasta
				. '. A leitura de volta da instalação procura a pasta declarada, e um zip que instala noutra pasta é instalado e não é encontrado';
		}
	}

	return $achados;
}

/**
 * REGRA PURA: a cópia vendorizada é o zip, nos dois sentidos.
 *
 * @param array<string,array{no_zip:string,motivo:string}> $declarado Tabela de VENDORIZADO.tsv.
 * @param array<string,string>                             $em_disco  caminho relativo a partilhado/ => sha256 do arquivo em disco.
 * @param array<string,string>                             $no_zip    entrada relativa à pasta do plugin => sha256 do conteúdo no zip ('' quando ausente).
 * @return array<int,string>
 */
function f3b_sb_copia_vendorizada( array $declarado, array $em_disco, array $no_zip ): array {
	$achados = array();

	if ( array() === $declarado ) {
		return array( 'teto: partilhado/VENDORIZADO.tsv está vazio ou ausente: sem a declaração não há como saber o que é cópia nem de onde veio, e escopo vazio não pode aprovar' );
	}

	foreach ( $declarado as $aqui => $origem ) {
		if ( '' === (string) $origem['motivo'] ) {
			$achados[] = $aqui . ': declarado em VENDORIZADO.tsv sem motivo. Cópia sem motivo escrito é cópia que ninguém sabe se ainda precisa existir';
		}

		if ( ! isset( $em_disco[ $aqui ] ) ) {
			$achados[] = $aqui . ': declarado em VENDORIZADO.tsv e AUSENTE em partilhado/. O implantador cairia no require_once de um arquivo que não existe, antes de o plugin ser instalado';
			continue;
		}

		$entrada = (string) $origem['no_zip'];

		if ( '' === $entrada || ! isset( $no_zip[ $entrada ] ) || '' === $no_zip[ $entrada ] ) {
			$achados[] = $aqui . ': a entrada declarada como origem (' . $entrada . ') NÃO existe dentro da reserva. A cópia não tem de onde ter vindo — ou o plugin publicado deixou de carregar esse arquivo, ou a declaração está errada';
			continue;
		}

		if ( $no_zip[ $entrada ] !== $em_disco[ $aqui ] ) {
			$achados[] = $aqui . ': a cópia vendorizada NÃO é byte a byte a entrada ' . $entrada . ' do zip publicado. O implantador escreveria segundo uma regra que não é a que o plugin instalado lê — '
				. 'e nada acusaria, porque a gravação funciona. Atualize a cópia extraindo-a de dentro da reserva; editar aqui é fork';
		}
	}

	foreach ( array_keys( $em_disco ) as $aqui ) {
		if ( ! isset( $declarado[ $aqui ] ) ) {
			$achados[] = $aqui . ': existe em partilhado/ e NÃO está declarado em VENDORIZADO.tsv. Tudo em partilhado/ é cópia do plugin; um arquivo sem origem declarada é um arquivo que ninguém confere';
		}
	}

	return $achados;
}

/**
 * Impressão de `partilhado/`: caminho relativo => sha256, sem a própria tabela.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<string,string>
 */
function f3b_sb_impressao_de_partilhado( string $raiz ): array {
	$saida = array();

	foreach ( f3b_arquivos( $raiz . '/partilhado', array(), array() ) as $rel ) {
		if ( 'VENDORIZADO.tsv' === $rel ) {
			continue;
		}

		$saida[ $rel ] = (string) hash_file( 'sha256', $raiz . '/partilhado/' . $rel );
	}

	return $saida;
}

/* =========================================================================
 * EXECUÇÃO
 * ====================================================================== */

$veredito = array(
	'pacote.plugin_so_como_zip'             => array( 'achados' => array(), 'medidas' => 0 ),
	'pacote.reserva_confere_com_o_catalogo' => array( 'achados' => array(), 'medidas' => 0 ),
	'pacote.copia_vendorizada_confere'      => array( 'achados' => array(), 'medidas' => 0 ),
);

$config = json_decode( (string) @file_get_contents( $raiz . '/config/site.json' ), true );
$versao = is_array( $config ) ? (string) ( $config['release']['implantador'] ?? '' ) : '';
$bundle = $raiz . '/dist/implantador-base-' . $versao . '.zip';

if ( '' === $versao || ! is_file( $bundle ) ) {
	foreach ( array_keys( $veredito ) as $nome ) {
		$veredito[ $nome ]['achados'][] = 'o bundle não foi encontrado em dist/implantador-base-' . $versao . '.zip: esta sonda mede o ARTEFATO montado, e sem ele nada aqui foi medido';
	}

	echo (string) json_encode( $veredito, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	exit( 0 );
}

$catalogo = f3b_catalogo_do_site_core( $raiz );
$reserva  = f3b_reserva_do_site_core( $raiz );

if ( '' !== $reserva['erro'] ) {
	foreach ( array_keys( $veredito ) as $nome ) {
		$veredito[ $nome ]['achados'][] = 'a reserva do plugin não pôde ser resolvida na árvore: ' . $reserva['erro'];
	}

	echo (string) json_encode( $veredito, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	exit( 0 );
}

$entradas       = f3b_entradas_do_zip( $bundle );
$reserva_dentro = 'implantador-base/' . $reserva['relativo'];

/* ---- 1. a fonte não viaja, a reserva viaja ---- */
$veredito['pacote.plugin_so_como_zip']['medidas'] = count( $entradas );
$veredito['pacote.plugin_so_como_zip']['achados'] = f3b_sb_plugin_so_como_zip( $entradas, 'implantador-base/fontes/plugin/', $reserva_dentro );

/* PISO: a mesma função, contra listas com o defeito plantado. */
$com_fonte = array_merge( $entradas, array( 'implantador-base/fontes/plugin/' . $catalogo['slug'] . '.php' ) );

if ( array() === f3b_sb_plugin_so_como_zip( $com_fonte, 'implantador-base/fontes/plugin/', $reserva_dentro ) ) {
	$veredito['pacote.plugin_so_como_zip']['achados'][] = 'piso cego: com um arquivo da fonte do plugin acrescentado à lista de entradas, a regra continuou em silêncio';
}

$sem_reserva = array_values( array_diff( $entradas, array( $reserva_dentro ) ) );

if ( array() === f3b_sb_plugin_so_como_zip( $sem_reserva, 'implantador-base/fontes/plugin/', $reserva_dentro ) ) {
	$veredito['pacote.plugin_so_como_zip']['achados'][] = 'piso cego: com a reserva removida da lista de entradas, a regra continuou em silêncio';
}

$veredito['pacote.plugin_so_como_zip']['medidas'] += 2;

/* ---- 2. a reserva é o zip publicado ---- */
$extraido = sys_get_temp_dir() . '/f3b-reserva-' . getmypid();
f3b_sb_apagar( $extraido ); /* um PID reutilizado não pode responder com a extração de outra rodada. */
@mkdir( $extraido, 0755, true );

$saida  = array();
$codigo = 0;
exec(
	sprintf(
		'cd %s && unzip -qo %s %s 2>&1',
		escapeshellarg( $extraido ),
		escapeshellarg( $bundle ),
		escapeshellarg( $reserva_dentro )
	),
	$saida,
	$codigo
);

$dentro           = $extraido . '/' . $reserva_dentro;
$sha256_no_bundle = is_file( $dentro ) ? (string) hash_file( 'sha256', $dentro ) : '';

$entradas_da_reserva = f3b_entradas_do_zip( $reserva['caminho'] );

$veredito['pacote.reserva_confere_com_o_catalogo']['medidas'] = 5;
$veredito['pacote.reserva_confere_com_o_catalogo']['achados'] = f3b_sb_reserva_confere(
	$reserva['sha256'],
	$catalogo['sha256'],
	$reserva['versao_do_nome'],
	$reserva['versao_do_cabecalho'],
	$sha256_no_bundle,
	$entradas_da_reserva,
	$reserva['pasta']
);

if ( '' === $sha256_no_bundle ) {
	/* A regra é pura e não vê o unzip; quem viu relata o que ele disse, para que o achado aponte a causa e não só o sintoma. */
	$veredito['pacote.reserva_confere_com_o_catalogo']['achados'][] = 'unzip saiu com código ' . (string) $codigo . ' ao extrair ' . $reserva_dentro . ' de ' . basename( $bundle )
		. ( array() === $saida ? ' sem dizer nada' : ': ' . implode( ' | ', array_map( 'trim', $saida ) ) );
}

/* PISO: a MESMA regra, com cada uma das cláusulas quebrada de propósito. */
$pisos_da_reserva = array(
	'o digesto do catálogo vazio'           => array( $reserva['sha256'], '', $reserva['versao_do_nome'], $reserva['versao_do_cabecalho'], $reserva['sha256'], $entradas_da_reserva, $reserva['pasta'] ),
	'o digesto do catálogo trocado'         => array( $reserva['sha256'], str_repeat( '0', 64 ), $reserva['versao_do_nome'], $reserva['versao_do_cabecalho'], $reserva['sha256'], $entradas_da_reserva, $reserva['pasta'] ),
	'nome e cabeçalho discordando'          => array( $reserva['sha256'], $reserva['sha256'], '9.9.9', $reserva['versao_do_cabecalho'], $reserva['sha256'], $entradas_da_reserva, $reserva['pasta'] ),
	'a versão do NOME ilegível'             => array( $reserva['sha256'], $reserva['sha256'], '', $reserva['versao_do_cabecalho'], $reserva['sha256'], $entradas_da_reserva, $reserva['pasta'] ),
	'a versão do CABEÇALHO ilegível'        => array( $reserva['sha256'], $reserva['sha256'], $reserva['versao_do_nome'], '', $reserva['sha256'], $entradas_da_reserva, $reserva['pasta'] ),
	'a cópia no bundle com outros bytes'    => array( $reserva['sha256'], $reserva['sha256'], $reserva['versao_do_nome'], $reserva['versao_do_cabecalho'], str_repeat( 'f', 64 ), $entradas_da_reserva, $reserva['pasta'] ),
	'a cópia no bundle ilegível'            => array( $reserva['sha256'], $reserva['sha256'], $reserva['versao_do_nome'], $reserva['versao_do_cabecalho'], '', $entradas_da_reserva, $reserva['pasta'] ),
	'a pasta de topo diferente da esperada' => array( $reserva['sha256'], $reserva['sha256'], $reserva['versao_do_nome'], $reserva['versao_do_cabecalho'], $reserva['sha256'], $entradas_da_reserva, 'outra-pasta' ),
	'o zip sem entradas'                    => array( $reserva['sha256'], $reserva['sha256'], $reserva['versao_do_nome'], $reserva['versao_do_cabecalho'], $reserva['sha256'], array(), $reserva['pasta'] ),
);

foreach ( $pisos_da_reserva as $rotulo => $argumentos ) {
	++$veredito['pacote.reserva_confere_com_o_catalogo']['medidas'];

	if ( array() === f3b_sb_reserva_confere( ...$argumentos ) ) {
		$veredito['pacote.reserva_confere_com_o_catalogo']['achados'][] = 'piso cego: com ' . $rotulo . ', a regra da reserva continuou em silêncio';
	}
}

/* ---- 3. a cópia vendorizada é o zip ---- */
$declarado = f3b_vendorizado_declarado( $raiz );
$em_disco  = f3b_sb_impressao_de_partilhado( $raiz );
$no_zip    = array();

foreach ( $declarado as $aqui => $origem ) {
	$entrada = (string) $origem['no_zip'];

	if ( '' === $entrada ) {
		continue;
	}

	$corpo              = f3b_ler_do_zip( $reserva['caminho'], $reserva['pasta'] . '/' . $entrada );
	$no_zip[ $entrada ] = '' === $corpo ? '' : hash( 'sha256', $corpo );
}

$veredito['pacote.copia_vendorizada_confere']['medidas'] = count( $declarado ) + count( $em_disco );
$veredito['pacote.copia_vendorizada_confere']['achados'] = f3b_sb_copia_vendorizada( $declarado, $em_disco, $no_zip );

/* PISO: a MESMA regra, contra a cópia com o defeito plantado. */
if ( array() !== $declarado && array() !== $em_disco ) {
	$primeiro = (string) array_key_first( $declarado );

	$mutado              = $em_disco;
	$mutado[ $primeiro ] = hash( 'sha256', 'um byte a mais' );

	if ( array() === f3b_sb_copia_vendorizada( $declarado, $mutado, $no_zip ) ) {
		$veredito['pacote.copia_vendorizada_confere']['achados'][] = 'piso cego: com o conteúdo de ' . $primeiro . ' alterado em disco, a regra da cópia continuou em silêncio';
	}

	$sem_declaracao = $declarado;
	unset( $sem_declaracao[ $primeiro ] );

	if ( array() === f3b_sb_copia_vendorizada( $sem_declaracao, $em_disco, $no_zip ) ) {
		$veredito['pacote.copia_vendorizada_confere']['achados'][] = 'piso cego: com ' . $primeiro . ' em disco e fora da declaração, a regra da cópia continuou em silêncio';
	}

	$sem_origem = $no_zip;
	unset( $sem_origem[ (string) $declarado[ $primeiro ]['no_zip'] ] );

	if ( array() === f3b_sb_copia_vendorizada( $declarado, $em_disco, $sem_origem ) ) {
		$veredito['pacote.copia_vendorizada_confere']['achados'][] = 'piso cego: com a entrada de origem de ' . $primeiro . ' ausente do zip, a regra da cópia continuou em silêncio';
	}

	if ( array() === f3b_sb_copia_vendorizada( array(), $em_disco, $no_zip ) ) {
		$veredito['pacote.copia_vendorizada_confere']['achados'][] = 'piso cego: com a declaração vazia a regra da cópia aprovou, e escopo vazio não pode aprovar';
	}

	$veredito['pacote.copia_vendorizada_confere']['medidas'] += 4;
}

f3b_sb_apagar( $extraido );

echo (string) json_encode( $veredito, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
