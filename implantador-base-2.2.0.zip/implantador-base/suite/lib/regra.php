<?php
/**
 * Regra compartilhada da suíte — arquivo ÚNICO, importado por toda sonda.
 *
 * Mora aqui, e só aqui:
 *
 * - `estado()`: a única função que imprime uma linha de resultado, e que
 *   INCREMENTA O CONTADOR DENTRO DELA MESMA. Contador por fora já produziu o
 *   defeito medido: a linha saía FALHA, o `exit` saía 0, e a rodada passava.
 * - A lista FECHADA de estados, de classes de evidência e de fases. Estado fora
 *   da lista não é impresso: é erro de programação da própria suíte e aborta.
 * - A classificação de erro por ORIGEM: site → FALHA, terceiro → WARN,
 *   ambiente → BLOCKED com o recurso nomeado. Nenhuma sonda reimplementa isso.
 * - Os utilitários de varredura que toda sonda usa (lista de arquivos, código
 *   PHP sem comentário, caminho relativo).
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

final class F3Base_Suite {

	/** Estados fechados do contrato. Nenhum outro. */
	public const ESTADOS = array( 'OK', 'FALHA', 'BLOCKED', 'N/A', 'WAIVED', 'WARN' );

	/**
	 * Classes de evidência do contrato.
	 *
	 * `importada` entrou nesta release com um significado que nenhuma das outras
	 * tinha: o fato foi MEDIDO POR OUTRA RODADA, em outra máquina, e este host
	 * apenas confere a amarração — o caso da rodada limpa, cujo registro viaja
	 * dentro do pacote com o hash que ela mediu. Chamar isso de `medida` seria o
	 * instrumento afirmando ter feito o que não fez.
	 */
	public const CLASSES = array( 'medida', 'teste-funcional', 'analise-estatica', 'leitura-de-volta', 'doc-externa', 'inferencia', 'pendencia-externa', 'importada' );

	/** Fases do contrato. */
	public const FASES = array( 'build', 'local', 'producao', 'campo' );

	/**
	 * A FASE DESTE EMISSOR, declarada — e não deduzida em cada chamada.
	 *
	 * A suíte é o comando único: ela empacota e mede a ÁRVORE DO PACOTE. Não há
	 * WordPress, não há banco, não há navegador e não há produção — e é isso, e
	 * só isso, que a palavra `build` quer dizer aqui.
	 *
	 * Ela existe como constante porque a regra de aplicabilidade da 1.1.6 compara
	 * a fase DECLARADA de cada checagem com a fase CORRENTE, e uma comparação
	 * cujo segundo termo estivesse escrito à mão em cada ponto de emissão teria,
	 * um dia, dois valores diferentes no mesmo relatório — que é exatamente a
	 * divergência que a 1.0.17 imprimiu dentro de uma linha só do log.
	 */
	public const FASE_CORRENTE = 'build';

	/**
	 * Origens possíveis de um erro e o estado que cada uma produz.
	 *
	 * Esta tabela é a regra de classificação inteira. Ela não é repetida em
	 * nenhuma sonda: quem precisa classificar chama `estado_por_origem()`.
	 */
	public const ORIGENS = array(
		'site'     => 'FALHA',
		'terceiro' => 'WARN',
		'ambiente' => 'BLOCKED',
	);

	/** @var array<string,int> Contagem por estado. Escrita SÓ dentro de estado(). */
	private static array $contagem = array();

	/** @var array<int,array<string,string>> Linhas emitidas, na ordem. */
	private static array $linhas = array();

	/** @var array<int,string> Nomes de checagem já emitidos (para o cruzamento do manifesto). */
	private static array $emitidas = array();

	/**
	 * Zera o acumulador. Usado pelo runner antes de uma rodada.
	 *
	 * @return void
	 */
	public static function zerar(): void {
		self::$contagem = array();
		self::$linhas   = array();
		self::$emitidas = array();
	}

	/**
	 * Incremento do contador. PRIVADO e chamado só por estado().
	 *
	 * @param string $estado Estado emitido.
	 * @return void
	 */
	private static function contar( string $estado ): void {
		self::$contagem[ $estado ] = ( self::$contagem[ $estado ] ?? 0 ) + 1;
	}

	/**
	 * Contagem por estado, na ordem da lista fechada.
	 *
	 * @return array<string,int>
	 */
	public static function contagem(): array {
		$saida = array();

		foreach ( self::ESTADOS as $estado ) {
			$saida[ $estado ] = self::$contagem[ $estado ] ?? 0;
		}

		return $saida;
	}

	/**
	 * Número de FALHAS. É o que decide o código de saída do comando único.
	 *
	 * @return int
	 */
	public static function falhas(): int {
		return self::$contagem['FALHA'] ?? 0;
	}

	/**
	 * Nomes de checagem efetivamente emitidos nesta rodada.
	 *
	 * O cruzamento do manifesto e o mapa de armadilhas leem DAQUI — nunca de
	 * uma lista escrita à mão, e nunca de `check(true)`.
	 *
	 * @return array<int,string>
	 */
	public static function emitidas(): array {
		return array_values( array_unique( self::$emitidas ) );
	}

	/**
	 * Linhas emitidas, com estado e nome.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function linhas(): array {
		return self::$linhas;
	}

	/**
	 * NOMES por estado — o par obrigatório de toda contagem por estado.
	 *
	 * Contagem sem nome não responde à pergunta do operador. O resumo da rodada
	 * imprimia `BLOCKED 22` e nenhum nome; quem precisasse saber QUAIS tinha de
	 * reler as 73 linhas acima e contar à mão.
	 *
	 * @return array<string,array<int,string>>
	 */
	public static function nomes_por_estado(): array {
		$saida = array();

		foreach ( self::ESTADOS as $estado ) {
			$saida[ $estado ] = array();
		}

		foreach ( self::$linhas as $linha ) {
			$estado = (string) ( $linha['estado'] ?? '' );
			$nome   = (string) ( $linha['nome'] ?? '' );

			if ( ! isset( $saida[ $estado ] ) || '' === $nome || in_array( $nome, $saida[ $estado ], true ) ) {
				continue;
			}

			$saida[ $estado ][] = $nome;
		}

		return $saida;
	}

	/**
	 * Registra a linha. Chamado SÓ por estado().
	 *
	 * @param string $estado Estado.
	 * @param string $nome   Nome da checagem.
	 * @param string $fase   Fase declarada da checagem.
	 * @return void
	 */
	private static function registrar( string $estado, string $nome, string $fase ): void {
		self::$linhas[]  = array(
			'estado' => $estado,
			'nome'   => $nome,
			'fase'   => $fase,
		);
		self::$emitidas[] = $nome;
	}

	/**
	 * As linhas emitidas com a FASE de cada uma.
	 *
	 * A fase já viajava impressa na tela, dentro do bloco de evidência, e não
	 * viajava no acumulador: quem quisesse responder "quantas checagens esperam a
	 * fase de navegador?" tinha o texto e não tinha o dado. O registro de fases da
	 * 1.1.6 lê DAQUI, e não de uma segunda lista escrita à mão — que é a mesma
	 * regra que faz o cruzamento do manifesto ler de `emitidas()`.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function linhas_com_fase(): array {
		return self::$linhas;
	}

	/**
	 * Ponte para o registro. SÓ `estado()` pode chamar, e isso é conferido.
	 *
	 * A regra do contrato é que o contador more dentro da função que imprime o
	 * estado. Documentar isso não basta: qualquer sonda poderia incrementar por
	 * fora e a contagem deixaria de descrever o que saiu na tela. A guarda
	 * abaixo torna a regra executável — chamada de outro lugar aborta a rodada.
	 *
	 * @param string $estado Estado.
	 * @param string $nome   Nome.
	 * @param string $fase   Fase declarada da checagem.
	 * @return void
	 */
	public static function anotar( string $estado, string $nome, string $fase = '' ): void {
		$pilha    = debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 2 );
		$chamador = $pilha[1]['function'] ?? '';

		if ( 'estado' !== $chamador ) {
			fwrite( STDERR, sprintf( "ERRO DE SUÍTE: contagem chamada de '%s' — o contador só pode ser tocado por estado().\n", $chamador ) );
			exit( 3 );
		}

		self::contar( $estado );
		self::registrar( $estado, $nome, $fase );
	}
}

/**
 * ÚNICA função que imprime resultado — e que conta.
 *
 * Formato: `ESTADO  nome.checagem  — mensagem  [evidência: classe/fase]`
 *
 * @param string $estado    Um dos estados fechados.
 * @param string $nome      Nome da checagem (`familia.checagem`).
 * @param string $mensagem  O que foi observado, nos dois ramos.
 * @param string $classe    Classe de evidência.
 * @param string $fase      Fase.
 * @return void
 */
function estado( string $estado, string $nome, string $mensagem, string $classe, string $fase ): void {
	if ( ! in_array( $estado, F3Base_Suite::ESTADOS, true ) ) {
		fwrite( STDERR, sprintf( "ERRO DE SUÍTE: estado '%s' fora da lista fechada em '%s'.\n", $estado, $nome ) );
		exit( 3 );
	}

	if ( ! in_array( $classe, F3Base_Suite::CLASSES, true ) ) {
		fwrite( STDERR, sprintf( "ERRO DE SUÍTE: classe de evidência '%s' fora da lista em '%s'.\n", $classe, $nome ) );
		exit( 3 );
	}

	if ( ! in_array( $fase, F3Base_Suite::FASES, true ) ) {
		fwrite( STDERR, sprintf( "ERRO DE SUÍTE: fase '%s' fora da lista em '%s'.\n", $fase, $nome ) );
		exit( 3 );
	}

	/* O CONTADOR MORA AQUI DENTRO. Nunca por fora, nunca no chamador. */
	F3Base_Suite::anotar( $estado, $nome, $fase );

	printf(
		"%-7s %-44s — %s  [evidência: %s/%s]\n",
		$estado,
		$nome,
		$mensagem,
		$classe,
		$fase
	);
}

/**
 * Emissão classificada por ORIGEM do erro.
 *
 * A regra inteira mora nesta função: site → FALHA, terceiro → WARN,
 * ambiente → BLOCKED com o recurso nomeado. Quando `$ok` é verdadeiro o estado
 * é sempre OK, qualquer que seja a origem.
 *
 * @param bool   $ok       Resultado observado.
 * @param string $origem   `site`, `terceiro` ou `ambiente`.
 * @param string $nome     Nome da checagem.
 * @param string $msg_ok   Mensagem do ramo aprovado.
 * @param string $msg_erro Mensagem do ramo reprovado.
 * @param string $classe   Classe de evidência.
 * @param string $fase     Fase.
 * @param string $recurso  Recurso ausente, obrigatório quando a origem é `ambiente`.
 * @return void
 */
function estado_por_origem( bool $ok, string $origem, string $nome, string $msg_ok, string $msg_erro, string $classe, string $fase, string $recurso = '' ): void {
	if ( ! isset( F3Base_Suite::ORIGENS[ $origem ] ) ) {
		fwrite( STDERR, sprintf( "ERRO DE SUÍTE: origem '%s' desconhecida em '%s'.\n", $origem, $nome ) );
		exit( 3 );
	}

	if ( $ok ) {
		estado( 'OK', $nome, $msg_ok, $classe, $fase );
		return;
	}

	$destino = F3Base_Suite::ORIGENS[ $origem ];

	if ( 'ambiente' === $origem ) {
		if ( '' === $recurso ) {
			fwrite( STDERR, sprintf( "ERRO DE SUÍTE: origem 'ambiente' sem recurso nomeado em '%s'.\n", $nome ) );
			exit( 3 );
		}

		$msg_erro = $msg_erro . ' Recurso ausente: ' . $recurso . '.';
	}

	estado( $destino, $nome, $msg_erro, $classe, $fase );
}

/* -------------------------------------------------------------------------
 * Utilitários de varredura. Compartilhados para que nenhuma sonda invente a
 * própria noção de "o pacote inteiro".
 * ---------------------------------------------------------------------- */

/**
 * O CATÁLOGO DE DECISÕES lido pela SUÍTE, por conta própria.
 *
 * Esta é a segunda leitura do arquivo, e ela é deliberada. A suíte é
 * AUDITORA, não consumidora: auditor que usa o leitor do auditado não
 * consegue acusar defeito do leitor — se `F3Base_Imp_Decisoes` deixasse de
 * enxergar uma linha, a comparação usaria a mesma cegueira dos dois lados e
 * fecharia verde. É a mesma razão pela qual `release.matriz_do_catalogo`
 * confere a saída do leitor contra uma bancada montada aqui.
 *
 * `decisoes.fonte_unica` conhece esta exceção pelo nome e não a conta como
 * segunda fonte. Nenhum outro arquivo fora do produtor pode ler o catálogo.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<int,array{chave:string,valor:mixed,motivo:string,json:string}>
 */
function f3b_decisoes( string $raiz ): array {
	$arquivo = rtrim( $raiz, '/' ) . '/config/decisoes.tsv';

	if ( ! is_file( $arquivo ) || ! is_readable( $arquivo ) ) {
		return array();
	}

	$saida = array();

	foreach ( (array) file( $arquivo, FILE_IGNORE_NEW_LINES ) as $linha ) {
		$linha = (string) $linha;

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$colunas = explode( "\t", $linha );

		if ( count( $colunas ) < 3 ) {
			continue;
		}

		$chave  = trim( $colunas[0] );
		$json   = trim( $colunas[1] );
		$motivo = trim( $colunas[2] );

		if ( '' === $chave || '' === $motivo ) {
			continue;
		}

		$valor = json_decode( $json, true );

		if ( null === $valor && 'null' !== $json ) {
			continue;
		}

		$saida[] = array(
			'chave'  => $chave,
			'valor'  => $valor,
			'motivo' => $motivo,
			'json'   => $json,
		);
	}

	return $saida;
}

/**
 * Diretórios que NENHUMA varredura de pacote alcança, com o motivo.
 *
 * - `suite/fixtures/`: por construção contém os defeitos plantados. Varrer as
 *   fixtures junto com o pacote faria toda checagem reprovar por causa do
 *   próprio piso — o detector gritando por causa de si mesmo.
 * - `dist/`: saída do empacotamento, gerada por esta suíte e declarada como
 *   tal no inventário; não pertence ao pacote que o operador faz upload.
 *
 * @return array<int,string>
 */
function f3b_excluidos(): array {
	return array( 'suite/fixtures/', 'dist/' );
}

/**
 * Lista recursiva de arquivos de uma raiz, em ordem de caminho relativo.
 *
 * @param string             $raiz       Raiz absoluta.
 * @param array<int,string>  $extensoes  Extensões (sem ponto). Vazio = todas.
 * @param array<int,string>  $excluir    Prefixos relativos a pular.
 * @return array<int,string> Caminhos relativos.
 */
function f3b_arquivos( string $raiz, array $extensoes = array(), array $excluir = array() ): array {
	$raiz = rtrim( $raiz, '/' );

	if ( ! is_dir( $raiz ) ) {
		return array();
	}

	$saida = array();
	$iter  = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::SELF_FIRST
	);

	foreach ( $iter as $item ) {
		if ( ! $item->isFile() ) {
			continue;
		}

		$rel  = ltrim( substr( $item->getPathname(), strlen( $raiz ) ), '/' );
		$pula = false;

		foreach ( $excluir as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$pula = true;
				break;
			}
		}

		if ( $pula ) {
			continue;
		}

		if ( array() !== $extensoes && ! in_array( strtolower( (string) pathinfo( $rel, PATHINFO_EXTENSION ) ), $extensoes, true ) ) {
			continue;
		}

		$saida[] = $rel;
	}

	sort( $saida );

	return $saida;
}

/**
 * Fonte PHP sem comentários, com as linhas preservadas.
 *
 * A varredura mede o que EXECUTA. Sem isto, a menção a uma armadilha dentro do
 * comentário que a explica reprova o arquivo correto — e é justamente o que o
 * pacote faz: `class-f3base-imp-journal.php` cita `update_option` na prosa que
 * explica por que ele mora em um arquivo só.
 *
 * @param string $caminho Caminho absoluto.
 * @return string Código sem comentário.
 */
function f3b_codigo_php( string $caminho ): string {
	return f3b_codigo_php_de_texto( (string) file_get_contents( $caminho ) );
}

/**
 * Fonte PHP sem comentários, a partir do TEXTO — para o que não mora em disco.
 *
 * O plugin é lido de dentro da reserva, e uma entrada de zip não tem caminho:
 * a mesma regra da função acima, sobre a string.
 *
 * @param string $src Código-fonte.
 * @return string
 */
function f3b_codigo_php_de_texto( string $src ): string {
	$saida = '';

	foreach ( token_get_all( $src ) as $token ) {
		if ( is_array( $token ) && in_array( $token[0], array( T_COMMENT, T_DOC_COMMENT ), true ) ) {
			$saida .= str_repeat( "\n", substr_count( $token[1], "\n" ) );
			continue;
		}

		$saida .= is_array( $token ) ? $token[1] : $token;
	}

	return $saida;
}

/**
 * Argumentos de cada chamada de uma função, com parênteses balanceados.
 *
 * @param string $src    Código.
 * @param string $funcao Nome da função.
 * @return array<int,string>
 */
function f3b_chamadas( string $src, string $funcao ): array {
	$saida = array();
	$pos   = 0;
	$tam   = strlen( $src );

	while ( false !== ( $pos = strpos( $src, $funcao . '(', $pos ) ) ) {
		if ( $pos > 0 && preg_match( '/[A-Za-z0-9_$]/', $src[ $pos - 1 ] ) ) {
			$pos += strlen( $funcao ) + 1;
			continue;
		}

		$i     = $pos + strlen( $funcao ) + 1;
		$nivel = 1;
		$buf   = '';

		while ( $i < $tam && $nivel > 0 ) {
			$c = $src[ $i ];

			if ( '(' === $c ) {
				$nivel++;
			}

			if ( ')' === $c ) {
				$nivel--;

				if ( 0 === $nivel ) {
					break;
				}
			}

			$buf .= $c;
			$i++;
		}

		$saida[] = $buf;
		$pos     = $i;
	}

	return $saida;
}

/**
 * Argumentos de cada chamada cujo cabeçalho casa com uma expressão regular.
 *
 * Existe separado de `f3b_chamadas()` porque a busca por substring precisa
 * rejeitar `xversion_compare(` e ao mesmo tempo ACEITAR
 * `F3Base_Imp_Config::obter(` — onde o caractere anterior ao trecho procurado é
 * o `_` do nome da classe. Uma guarda só não resolve os dois casos; a expressão
 * regular resolve, porque ela descreve o cabeçalho inteiro da chamada.
 *
 * @param string $src Código.
 * @param string $re  Expressão regular cujo casamento TERMINA no parêntese de abertura.
 * @return array<int,string>
 */
function f3b_chamadas_regex( string $src, string $re ): array {
	$saida = array();

	if ( ! preg_match_all( $re, $src, $ms, PREG_OFFSET_CAPTURE ) ) {
		return $saida;
	}

	$tam = strlen( $src );

	foreach ( $ms[0] as $m ) {
		$i     = (int) $m[1] + strlen( $m[0] );
		$nivel = 1;
		$buf   = '';

		while ( $i < $tam && $nivel > 0 ) {
			$c = $src[ $i ];

			if ( '(' === $c ) {
				$nivel++;
			}

			if ( ')' === $c ) {
				$nivel--;

				if ( 0 === $nivel ) {
					break;
				}
			}

			$buf .= $c;
			$i++;
		}

		$saida[] = $buf;
	}

	return $saida;
}

/**
 * Achata um array em caminhos pontilhados, com `*` no índice numérico.
 *
 * @param mixed              $valor    Valor.
 * @param string             $prefixo  Prefixo do caminho.
 * @param array<string,bool> $acumula  Acumulador por referência.
 * @return void
 */
function f3b_achatar( $valor, string $prefixo, array &$acumula ): void {
	if ( '' !== $prefixo ) {
		$acumula[ $prefixo ] = true;
	}

	if ( ! is_array( $valor ) ) {
		return;
	}

	foreach ( $valor as $chave => $filho ) {
		$seg = is_int( $chave ) ? '*' : (string) $chave;
		f3b_achatar( $filho, '' === $prefixo ? $seg : $prefixo . '.' . $seg, $acumula );
	}
}

/**
 * Lê um TSV declarado da suíte, ignorando comentário e linha vazia.
 *
 * @param string $caminho Caminho absoluto.
 * @return array<int,array<int,string>>
 */
function f3b_tsv( string $caminho ): array {
	if ( ! is_file( $caminho ) ) {
		return array();
	}

	$saida = array();

	foreach ( preg_split( '/\R/', (string) file_get_contents( $caminho ) ) ?: array() as $linha ) {
		$linha = rtrim( $linha, "\r\n" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$saida[] = explode( "\t", $linha );
	}

	return $saida;
}

/**
 * Recorta uma lista de achados para caber na linha, sem esconder o total.
 *
 * @param array<int,string> $achados Achados.
 * @param int               $limite  Quantos mostrar.
 * @return string
 */
function f3b_amostra( array $achados, int $limite = 6 ): string {
	$total = count( $achados );
	$corte = array_slice( $achados, 0, $limite );
	$texto = implode( '; ', $corte );

	if ( $total > $limite ) {
		$texto .= sprintf( '; (+%d)', $total - $limite );
	}

	return $texto;
}

/**
 * `config/site.json` da raiz varrida, analisado.
 *
 * @param string $raiz Raiz.
 * @return array<string,mixed>|null
 */
function f3b_config( string $raiz ): ?array {
	$arquivo = $raiz . '/config/site.json';

	if ( ! is_file( $arquivo ) ) {
		return null;
	}

	$json = json_decode( (string) file_get_contents( $arquivo ), true );

	return is_array( $json ) ? $json : null;
}

/**
 * A ENTRADA DO CATÁLOGO que declara o plugin do site, lida por conta própria.
 *
 * `plugins.instalaveis.<n>` com `papel = site-core`, de `config/decisoes.tsv`.
 * A suíte lê o catálogo pelo leitor DELA (`f3b_decisoes()`), não pelo do
 * runtime — auditor que usa o leitor do auditado audita o leitor.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{indice:int,slug:string,url:string,sha256:string,pasta:string} Índice -1 e campos vazios quando não há entrada.
 */
function f3b_catalogo_do_site_core( string $raiz ): array {
	foreach ( f3b_decisoes( $raiz ) as $decisao ) {
		if ( 1 !== preg_match( '/^plugins\.instalaveis\.(\d+)$/', (string) $decisao['chave'], $achou ) ) {
			continue;
		}

		$entrada = $decisao['valor'];

		if ( ! is_array( $entrada ) || 'site-core' !== (string) ( $entrada['papel'] ?? '' ) ) {
			continue;
		}

		return array(
			'indice' => (int) $achou[1],
			'slug'   => (string) ( $entrada['slug'] ?? '' ),
			'url'    => (string) ( $entrada['url'] ?? '' ),
			'sha256' => strtolower( trim( (string) ( $entrada['sha256'] ?? '' ) ) ),
			'pasta'  => (string) ( $entrada['pasta_esperada'] ?? ( $entrada['slug'] ?? '' ) ),
		);
	}

	return array(
		'indice' => -1,
		'slug'   => '',
		'url'    => '',
		'sha256' => '',
		'pasta'  => '',
	);
}

/**
 * A RESERVA DO SITE-CORE: o zip PUBLICADO, copiado para a árvore como ENTRADA de build.
 *
 * Desde a 2.0.0 o implantador NÃO monta o zip do plugin: quem o monta, sela e
 * publica é o repositório do plugin. O que mora aqui é uma cópia do artefato
 * publicado — `assets/plugins/<slug>-<versão>.zip`, exatamente UM —, e tudo o
 * que a suíte precisa ler do plugin (o catálogo de options, a declaração de
 * eventos, o prefixo de seção, o cliente de tracking) é lido DE DENTRO dela,
 * nunca de uma fonte que não é a que o site recebe.
 *
 * Três fatos saem daqui, e nenhum é digitado: a versão que o NOME carrega (é a
 * que o host lê, porque o cabeçalho não chega mais ao site), a versão que o
 * CABEÇALHO de dentro do zip declara, e o `sha256` dos bytes. Quem confere que
 * os três batem entre si e com o catálogo é `pacote.reserva_confere_com_o_catalogo`.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{caminho:string,relativo:string,nome:string,versao_do_nome:string,versao_do_cabecalho:string,sha256:string,pasta:string,candidatos:array<int,string>,erro:string}
 */
function f3b_reserva_do_site_core( string $raiz ): array {
	static $cache = array();

	$raiz = rtrim( $raiz, '/' );

	/*
	 * Memorizada POR RAIZ E POR DIGESTO DO DIRETÓRIO: a mesma sonda pergunta
	 * dezenas de vezes pela mesma reserva, e reabrir o zip a cada pergunta é
	 * custo sem informação. A chave leva a lista de candidatos e o mtime de
	 * cada um, para que uma reserva trocada no meio de uma rodada — o piso da
	 * renomeação copia árvores e as reescreve — não responda do cache velho.
	 * O catálogo entra na chave pelo mesmo motivo: slug e pasta saem dele, e um
	 * piso que reescreve `config/decisoes.tsv` mudaria a resposta sem mudar zip.
	 */
	$assinatura = array();
	$catalogo_f = $raiz . '/config/decisoes.tsv';

	$assinatura[] = $catalogo_f . ':' . (string) @filemtime( $catalogo_f ) . ':' . (string) @filesize( $catalogo_f );

	foreach ( glob( $raiz . '/assets/plugins/*.zip' ) ?: array() as $candidato ) {
		$assinatura[] = $candidato . ':' . (string) @filemtime( $candidato ) . ':' . (string) @filesize( $candidato );
	}

	$chave = $raiz . '|' . implode( '|', $assinatura );

	if ( isset( $cache[ $chave ] ) ) {
		return $cache[ $chave ];
	}

	$catalogo   = f3b_catalogo_do_site_core( $raiz );
	$slug       = '' !== $catalogo['slug'] ? $catalogo['slug'] : 'base-site-core-fator3';
	$pasta      = '' !== $catalogo['pasta'] ? $catalogo['pasta'] : $slug;
	$candidatos = glob( $raiz . '/assets/plugins/' . $slug . '-*.zip' ) ?: array();
	$candidatos = array_values( array_map( static fn( string $c ): string => substr( $c, strlen( $raiz ) + 1 ), $candidatos ) );
	sort( $candidatos, SORT_STRING );

	$saida = array(
		'caminho'             => '',
		'relativo'            => '',
		'nome'                => '',
		'versao_do_nome'      => '',
		'versao_do_cabecalho' => '',
		'sha256'              => '',
		'pasta'               => $pasta,
		'candidatos'          => $candidatos,
		'erro'                => '',
	);

	if ( 1 !== count( $candidatos ) ) {
		$saida['erro'] = array() === $candidatos
			? 'nenhuma reserva do plugin em assets/plugins/' . $slug . '-<versão>.zip: o bundle sairia sem o que responde quando o endereço do catálogo não responde'
			: 'mais de uma reserva do plugin em assets/plugins/ (' . implode( ', ', $candidatos ) . '): duas versões embutidas fazem a versão embarcada depender da ordem de leitura do diretório';

		$cache[ $chave ] = $saida;

		return $saida;
	}

	$rel     = $candidatos[0];
	$caminho = $raiz . '/' . $rel;
	$nome    = basename( $rel );

	$saida['caminho']  = $caminho;
	$saida['relativo'] = $rel;
	$saida['nome']     = $nome;
	$saida['sha256']   = (string) hash_file( 'sha256', $caminho );

	if ( 1 === preg_match( '/^' . preg_quote( $slug, '/' ) . '-(\d+\.\d+\.\d+)\.zip$/', $nome, $achou ) ) {
		$saida['versao_do_nome'] = $achou[1];
	} else {
		$saida['erro'] = $rel . ': o nome da reserva não carrega uma versão na forma <slug>-A.B.C.zip, e é do nome que o host lê a versão embarcada';
	}

	$principal = f3b_ler_do_zip( $caminho, $pasta . '/' . $slug . '.php' );

	if ( 1 === preg_match( '/^[\s*#@]*Version:\s*(\S+)\s*$/mi', substr( $principal, 0, 8192 ), $achou ) ) {
		$saida['versao_do_cabecalho'] = trim( $achou[1] );
	} elseif ( '' === $saida['erro'] ) {
		$saida['erro'] = $rel . ': não foi possível ler o cabeçalho Version: de ' . $pasta . '/' . $slug . '.php dentro do zip';
	}

	$cache[ $chave ] = $saida;

	return $saida;
}

/**
 * A FONTE DO PLUGIN COMO O SITE A RECEBE: um arquivo, lido de dentro da reserva.
 *
 * Toda leitura que a suíte faz do plugin — o catálogo de options, a lista de
 * segredos, o prefixo de seção, as marcas do carregador de tags, o cliente de
 * tracking — passa por aqui, e aqui a origem é o ZIP PUBLICADO copiado para a
 * árvore. Até a 1.7.4 essas leituras iam a `fontes/plugin/`, e mediam uma
 * fonte que não era, byte a byte, o que o site instalava.
 *
 * UMA FIXTURE PODE TRAZER `fontes/plugin/` EM CLARO, e é a única exceção. As
 * fixtures do piso precisam ser legíveis e editáveis — um defeito plantado
 * dentro de um zip é um defeito que ninguém enxerga no diff —, então, quando a
 * raiz varrida NÃO tem reserva nenhuma em `assets/plugins/`, os arquivos de
 * `fontes/plugin/` respondem. No pacote real esse caminho está morto por dois
 * lados: a reserva sempre existe (o empacotamento aborta sem ela) e
 * `pacote.allow_list` recusa qualquer `fontes/plugin/` que reapareça.
 *
 * @param string $raiz     Raiz varrida.
 * @param string $relativo Caminho relativo à pasta do plugin (`includes/x.php`).
 * @return string Conteúdo, ou vazio quando o arquivo não existe.
 */
function f3b_fonte_do_plugin( string $raiz, string $relativo ): string {
	$reserva = f3b_reserva_do_site_core( $raiz );

	if ( '' !== $reserva['caminho'] ) {
		return f3b_ler_do_zip( $reserva['caminho'], $reserva['pasta'] . '/' . $relativo );
	}

	$em_claro = rtrim( $raiz, '/' ) . '/fontes/plugin/' . $relativo;

	return is_file( $em_claro ) ? (string) file_get_contents( $em_claro ) : '';
}

/**
 * Os ARQUIVOS DO PLUGIN como o site os recebe, em caminhos relativos à pasta dele.
 *
 * Mesma origem e mesma exceção de `f3b_fonte_do_plugin()`.
 *
 * @param string            $raiz      Raiz varrida.
 * @param array<int,string> $extensoes Extensões a manter (sem ponto); vazio mantém todas.
 * @return array<int,string>
 */
function f3b_arquivos_do_plugin( string $raiz, array $extensoes = array() ): array {
	$reserva = f3b_reserva_do_site_core( $raiz );
	$saida   = array();

	if ( '' !== $reserva['caminho'] ) {
		$prefixo = $reserva['pasta'] . '/';

		foreach ( f3b_entradas_do_zip( $reserva['caminho'] ) as $entrada ) {
			if ( ! str_starts_with( $entrada, $prefixo ) || str_ends_with( $entrada, '/' ) ) {
				continue;
			}

			$saida[] = substr( $entrada, strlen( $prefixo ) );
		}
	} elseif ( is_dir( rtrim( $raiz, '/' ) . '/fontes/plugin' ) ) {
		$saida = f3b_arquivos( rtrim( $raiz, '/' ) . '/fontes/plugin', array(), array() );
	}

	if ( array() !== $extensoes ) {
		$saida = array_values(
			array_filter(
				$saida,
				static fn( string $rel ): bool => in_array( strtolower( pathinfo( $rel, PATHINFO_EXTENSION ) ), $extensoes, true )
			)
		);
	}

	sort( $saida, SORT_STRING );

	return $saida;
}

/**
 * O conteúdo de UMA entrada de um zip, byte a byte.
 *
 * Por `shell_exec`, e não por `exec()`: `exec()` devolve o corpo quebrado em
 * linhas e apara o branco do fim de cada uma, e uma comparação byte a byte
 * sairia divergente sobre dois arquivos idênticos.
 *
 * @param string $zip     Caminho do zip.
 * @param string $entrada Caminho da entrada dentro do zip.
 * @return string Vazio quando a entrada não existe.
 */
function f3b_ler_do_zip( string $zip, string $entrada ): string {
	if ( ! is_file( $zip ) ) {
		return '';
	}

	return (string) shell_exec( sprintf( 'unzip -p %s %s 2>/dev/null', escapeshellarg( $zip ), escapeshellarg( $entrada ) ) );
}

/**
 * As entradas de um zip, pelo nome, na ordem em que estão gravadas.
 *
 * @param string $zip Caminho do zip.
 * @return array<int,string>
 */
function f3b_entradas_do_zip( string $zip ): array {
	$saida  = array();
	$codigo = 0;
	exec( sprintf( 'unzip -Z1 %s 2>/dev/null', escapeshellarg( $zip ) ), $saida, $codigo );

	if ( 0 !== $codigo ) {
		return array();
	}

	return array_values( array_filter( array_map( 'strval', $saida ) ) );
}

/**
 * A CÓPIA VENDORIZADA: o que `partilhado/` carrega e de onde, no zip, cada arquivo vem.
 *
 * Lida de `partilhado/VENDORIZADO.tsv`, que declara caminho a caminho o que o
 * implantador precisa ler do plugin ANTES de o plugin existir na instalação,
 * e o motivo. A tabela é declaração, não lock: o digesto de cada arquivo não é
 * digitado em lugar nenhum — quem diz se a cópia confere é a comparação byte a
 * byte com a entrada correspondente da reserva, feita a cada rodada.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<string,array{no_zip:string,motivo:string}> caminho relativo a partilhado/ => entrada relativa à pasta do plugin no zip, e motivo.
 */
function f3b_vendorizado_declarado( string $raiz ): array {
	$saida = array();

	foreach ( f3b_tsv( rtrim( $raiz, '/' ) . '/partilhado/VENDORIZADO.tsv' ) as $linha ) {
		$aqui   = trim( $linha[0] ?? '' );
		$no_zip = trim( $linha[1] ?? '' );
		$motivo = trim( $linha[2] ?? '' );

		if ( '' === $aqui ) {
			continue;
		}

		$saida[ $aqui ] = array(
			'no_zip' => $no_zip,
			'motivo' => $motivo,
		);
	}

	return $saida;
}

/**
 * Resumo por estado com CONTAGEM E NOMES na mesma saída.
 *
 * Formatador ÚNICO da suíte: qualquer runner que imprima quantos fecharam em
 * cada estado passa por aqui, e por aqui a lista de nomes vem junto. Estado OK
 * sai resumido — o que não pode existir é estado ruim invisível.
 *
 * @param array<string,int>               $contagem Contagem por estado.
 * @param array<string,array<int,string>> $nomes    Nomes por estado.
 * @return array<int,string> Uma linha por estado, pronta para impressão.
 */
function f3b_resumo_por_estado( array $contagem, array $nomes ): array {
	$saida = array();

	foreach ( F3Base_Suite::ESTADOS as $estado ) {
		$quantas = (int) ( $contagem[ $estado ] ?? 0 );
		$lista   = isset( $nomes[ $estado ] ) && is_array( $nomes[ $estado ] ) ? $nomes[ $estado ] : array();

		if ( 'OK' === $estado ) {
			$saida[] = sprintf( '   %-8s %-4d (não nomeadas: estado OK sai resumido, por desenho)', $estado, $quantas );
			continue;
		}

		$saida[] = sprintf(
			'   %-8s %-4d %s',
			$estado,
			$quantas,
			array() === $lista ? 'nenhum' : implode( ', ', $lista )
		);
	}

	return $saida;
}
