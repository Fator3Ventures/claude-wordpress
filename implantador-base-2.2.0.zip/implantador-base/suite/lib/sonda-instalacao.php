<?php
/**
 * Sonda da INSTALAÇÃO LIMPA: o piso que a 1.0.15 não tinha.
 *
 * POR QUE ESTA SONDA EXISTE. A 1.0.15 foi instalada num WordPress recém-criado
 * e reprovou com duas linhas que se contradiziam dentro da mesma rodada:
 *
 *     FALHA tema      o tema não apareceu no disco depois da instalação.
 *     FALHA site_core o site-core não apareceu no disco depois da instalação.
 *
 * e, três linhas abaixo, a unidade de auto-update enumerando
 * `base-site-core-fator3 1.0.0` entre os plugins instalados. O diretório estava no
 * disco; quem não o enxergava era a API do WordPress, porque a etapa havia
 * consultado o estado ANTES da troca — numa instalação limpa isso memoriza o
 * NEGATIVO na mesma requisição — e `trocar_diretorio()`, que não passa pelo
 * upgrader do núcleo, não derrubava o cache depois de mover o diretório.
 *
 * A LIÇÃO, e é ela que dita o desenho desta sonda: a checagem atravessou quinze
 * releases sem nunca ter sido exercitada no caminho que importa, porque toda
 * execução de produção anterior rodou em site que JÁ TINHA tema e site-core
 * instalados. Ali a consulta prévia memorizava o POSITIVO e a leitura de volta
 * passava por acidente. Piso que só exercita alvo existente é o piso que deixou
 * isto passar quinze vezes.
 *
 * ENTÃO A BANCADA REPRODUZ O CASO, não o contorna:
 *
 * 1. Um WordPress de mentira cujo cache MEMORIZA O NEGATIVO, como o de verdade:
 *    `wp_get_theme()` responde da varredura guardada, `get_plugins()` responde
 *    da lista guardada, e a lista só cai quando alguém chama
 *    `wp_clean_themes_cache()` / `wp_clean_plugins_cache()` — que é exatamente
 *    o que `Theme_Upgrader::install()` e `Plugin_Upgrader::install()` fazem e
 *    `trocar_diretorio()` não fazia.
 * 2. O diretório de destino COMEÇA INEXISTENTE, e a consulta prévia acontece
 *    antes da troca, na mesma "requisição".
 * 3. A troca é a função REAL do pacote — `aplicar_tema()` e
 *    `aplicar_site_core()`, com o tema e o site-core REAIS de `fontes/`.
 * 4. A invalidação é um INTERRUPTOR da bancada. Desligada, a leitura de volta
 *    tem de continuar cega: é assim que se prova que a bancada reproduz o
 *    defeito de verdade, em vez de aprovar por não ter cache nenhum. Ligada, a
 *    leitura de volta tem de enxergar o artefato.
 * 5. E a ORDEM é medida: a invalidação precisa acontecer ENTRE a consulta
 *    prévia e a leitura de volta. O registro de eventos da bancada guarda cada
 *    leitura e cada limpeza, e a asserção lê essa fita.
 *
 * Subprocesso por desenho, como as outras sondas: carregar as classes do
 * implantador define ABSPATH e um punhado de funções do núcleo, e isso não pode
 * vazar para o processo que imprime os estados.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( (string) ( $argv[1] ?? '' ), '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'instalacao.limpa_le_de_volta' => array( 'achados' => array( 'raiz inexistente' ), 'medidas' => 0 ) ) );
	exit( 2 );
}

$sandbox = sys_get_temp_dir() . '/f3base-sonda-instalacao-' . getmypid();

/*
 * A RAIZ DO WORDPRESS fica FORA do sandbox que é zerado entre cenários: o
 * pacote faz `require_once ABSPATH . 'wp-admin/includes/file.php'`, e
 * `require_once` guarda o caminho já carregado — apagá-lo entre cenários
 * deixaria a segunda inclusão silenciosamente sem arquivo.
 */
$abspath = sys_get_temp_dir() . '/f3base-sonda-instalacao-' . getmypid() . '-wp/';

if ( ! is_dir( $abspath . 'wp-admin/includes' ) ) {
	mkdir( $abspath . 'wp-admin/includes', 0777, true );
}

foreach ( array( 'file.php', 'misc.php', 'plugin.php', 'class-wp-upgrader.php' ) as $stub_do_nucleo ) {
	file_put_contents( $abspath . 'wp-admin/includes/' . $stub_do_nucleo, "<?php
" );
}

define( 'ABSPATH', $abspath );
define( 'WP_PLUGIN_DIR', $sandbox . '/wp-content/plugins' );
define( 'F3BASE_IMP_DIR', $raiz . '/' );
define( 'F3BASE_IMP_ARQUIVO', $raiz . '/implantador-base.php' );
define( 'F3BASE_IMP_TEXT_DOMAIN', 'f3base' );

/**
 * ESTADO DA BANCADA: caches, interruptor de invalidação e fita de eventos.
 *
 * @var array<string,mixed>
 */
$GLOBALS['f3b_wp'] = array(
	'temas'       => null,
	'plugins'     => null,
	'invalidacao' => true,
	'stylesheet'  => 'twentytwentyfour',
	'options'     => array(),
	'ativos'      => array(),
	'fita'        => array(),
);

/**
 * Anota um evento na fita da bancada.
 *
 * @param string $evento Evento.
 * @return void
 */
function f3b_fita( string $evento ): void {
	$GLOBALS['f3b_wp']['fita'][] = $evento;
}

/* ---------------------------------------------------------------------- *
 * Núcleo de mentira: só o que as funções medidas de fato chamam.
 * ---------------------------------------------------------------------- */

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor Valor.
 * @param int   $flags Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

/**
 * Escape de saída do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function esc_html( string $texto ): string {
	return htmlspecialchars( $texto, ENT_QUOTES );
}

/**
 * Validação de e-mail do núcleo.
 *
 * @param mixed $valor Valor.
 * @return string|false
 */
function is_email( $valor ) {
	return is_string( $valor ) && false !== filter_var( $valor, FILTER_VALIDATE_EMAIL ) ? $valor : false;
}

/**
 * Desserialização tolerante do núcleo.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function maybe_unserialize( $valor ) {
	return $valor;
}

/**
 * Serialização do núcleo.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function maybe_serialize( $valor ) {
	return is_array( $valor ) || is_object( $valor ) ? serialize( $valor ) : $valor;
}

/**
 * Barra final.
 *
 * @param string $caminho Caminho.
 * @return string
 */
function trailingslashit( string $caminho ): string {
	return rtrim( $caminho, '/\\' ) . '/';
}

/**
 * Chave sanitizada.
 *
 * @param string $chave Chave.
 * @return string
 */
function sanitize_key( string $chave ): string {
	return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $chave ) ) ?? '';
}

/**
 * Texto sanitizado.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_text_field( string $texto ): string {
	return trim( strip_tags( $texto ) );
}

/**
 * Inteiro absoluto.
 *
 * @param mixed $valor Valor.
 * @return int
 */
function absint( $valor ): int {
	return abs( (int) $valor );
}

/**
 * Data formatada no fuso do site.
 *
 * @param string   $formato Formato.
 * @param int|null $quando  Epoch.
 * @return string
 */
function wp_date( string $formato, ?int $quando = null ): string {
	return gmdate( $formato, null === $quando ? time() : $quando );
}

/**
 * Caminho dentro do pacote, com a mesma guarda de travessia do implantador.
 *
 * @param string $relativo Caminho relativo.
 * @return string
 */
function f3base_imp_caminho( string $relativo ): string {
	$base = rtrim( F3BASE_IMP_DIR, '/' ) . '/';

	if ( '' === $relativo || str_contains( $relativo, '../' ) ) {
		return '';
	}

	$candidato = $base . ltrim( $relativo, '/' );
	$real      = realpath( $candidato );

	if ( false === $real ) {
		return $candidato;
	}

	return str_starts_with( $real, $base ) ? $real : '';
}

/**
 * Caminho relativo do arquivo principal, como o núcleo o produz.
 *
 * @param string $arquivo Caminho absoluto.
 * @return string
 */
function plugin_basename( string $arquivo ): string {
	return basename( dirname( $arquivo ) ) . '/' . basename( $arquivo );
}

/* ---------- options ---------- */

/**
 * Lê uma option da bancada.
 *
 * @param string $nome    Nome.
 * @param mixed  $padrao  Padrão.
 * @return mixed
 */
function get_option( string $nome, $padrao = false ) {
	return array_key_exists( $nome, $GLOBALS['f3b_wp']['options'] ) ? $GLOBALS['f3b_wp']['options'][ $nome ] : $padrao;
}

/*
 * A BANCADA NÃO ESCREVE OPTION, e isso é decisão, não esquecimento. Um núcleo
 * de mentira que definisse `update_option()`, `add_option()` e
 * `delete_option()` poria três escritas diretas de option dentro do pacote, e
 * `estatica.detector_escrita_unica` — que varre o pacote INTEIRO, a suíte
 * inclusive — as acusaria com razão: a regra é do caminho único de escrita, e
 * não abre exceção para arquivo de teste. O journal e o gravador entram como
 * dublês declarados logo abaixo, e o que está sob medição aqui é a troca de
 * diretório, não a camada de options — essa já tem sonda própria.
 */

/**
 * Criação recursiva de diretório.
 *
 * @param string $caminho Caminho.
 * @return bool
 */
function wp_mkdir_p( string $caminho ): bool {
	return is_dir( $caminho ) || mkdir( $caminho, 0777, true );
}

/* ---------- TEMAS: a varredura que MEMORIZA O NEGATIVO ---------- */

/**
 * Raiz de temas da bancada.
 *
 * @return string
 */
function get_theme_root(): string {
	return dirname( WP_PLUGIN_DIR ) . '/themes';
}

/**
 * Um tema como o núcleo o devolve, com o mínimo que o pacote consulta.
 */
final class F3Base_Sonda_Tema {

	/**
	 * Existe no disco, segundo a VARREDURA GUARDADA.
	 *
	 * @var bool
	 */
	private bool $existe;

	/**
	 * Versão do cabeçalho.
	 *
	 * @var string
	 */
	private string $versao;

	/**
	 * Monta a partir do que a varredura guardada diz.
	 *
	 * @param bool   $existe Existe.
	 * @param string $versao Versão.
	 */
	public function __construct( bool $existe, string $versao ) {
		$this->existe = $existe;
		$this->versao = $versao;
	}

	/**
	 * O tema existe?
	 *
	 * @return bool
	 */
	public function exists(): bool {
		return $this->existe;
	}

	/**
	 * Erros do tema.
	 *
	 * @return false
	 */
	public function errors() {
		return false;
	}

	/**
	 * Cabeçalho.
	 *
	 * @param string $campo Campo.
	 * @return string
	 */
	public function get( string $campo ): string {
		return 'Version' === $campo ? $this->versao : '';
	}
}

/**
 * A VARREDURA DE DIRETÓRIOS DE TEMA, memorizada como no núcleo.
 *
 * `search_theme_directories()` guarda o resultado numa estática e só refaz a
 * varredura com `$force = true`, que é o que `wp_clean_themes_cache()` passa.
 * Numa instalação limpa a primeira chamada guarda uma lista SEM o nosso tema, e
 * é essa lista que a leitura de volta relê.
 *
 * @return array<string,string> Slug => versão.
 */
function f3b_varredura_de_temas(): array {
	if ( null !== $GLOBALS['f3b_wp']['temas'] ) {
		f3b_fita( 'leu:temas(cache)' );

		return $GLOBALS['f3b_wp']['temas'];
	}

	f3b_fita( 'leu:temas(disco)' );

	$achados = array();

	foreach ( glob( get_theme_root() . '/*', GLOB_ONLYDIR ) ?: array() as $dir ) {
		$style = $dir . '/style.css';

		if ( ! is_file( $style ) ) {
			continue;
		}

		$versao = '';

		if ( 1 === preg_match( '/^[\s*#]*Version:\s*(.+)$/mi', (string) file_get_contents( $style ), $m ) ) {
			$versao = trim( $m[1] );
		}

		$achados[ basename( $dir ) ] = $versao;
	}

	$GLOBALS['f3b_wp']['temas'] = $achados;

	return $achados;
}

/**
 * `wp_get_theme()` da bancada: responde da varredura guardada.
 *
 * @param string $slug Slug.
 * @return F3Base_Sonda_Tema
 */
function wp_get_theme( string $slug = '' ): F3Base_Sonda_Tema {
	$temas = f3b_varredura_de_temas();

	return new F3Base_Sonda_Tema( isset( $temas[ $slug ] ), (string) ( $temas[ $slug ] ?? '' ) );
}

/**
 * Derruba a varredura guardada de temas — se a bancada permitir.
 *
 * O interruptor é o coração do piso: DESLIGADO, esta função não faz nada e a
 * leitura de volta continua cega, que é a 1.0.15 reproduzida.
 *
 * @param bool $lote Em lote.
 * @return void
 */
function wp_clean_themes_cache( bool $lote = true ): void {
	if ( ! $GLOBALS['f3b_wp']['invalidacao'] ) {
		f3b_fita( 'limpou:temas(inerte)' );

		return;
	}

	f3b_fita( 'limpou:temas' );

	$GLOBALS['f3b_wp']['temas'] = null;
}

/**
 * Tema ativo.
 *
 * @return string
 */
function get_stylesheet(): string {
	return (string) $GLOBALS['f3b_wp']['stylesheet'];
}

/**
 * Troca o tema ativo.
 *
 * @param string $slug Slug.
 * @return void
 */
function switch_theme( string $slug ): void {
	$GLOBALS['f3b_wp']['stylesheet'] = $slug;
}

/* ---------- PLUGINS: a lista que MEMORIZA O NEGATIVO ---------- */

/**
 * `get_plugins()` da bancada: responde da lista guardada.
 *
 * @return array<string,array<string,string>>
 */
function get_plugins(): array {
	if ( null !== $GLOBALS['f3b_wp']['plugins'] ) {
		f3b_fita( 'leu:plugins(cache)' );

		return $GLOBALS['f3b_wp']['plugins'];
	}

	f3b_fita( 'leu:plugins(disco)' );

	$achados = array();

	foreach ( glob( WP_PLUGIN_DIR . '/*', GLOB_ONLYDIR ) ?: array() as $dir ) {
		foreach ( glob( $dir . '/*.php' ) ?: array() as $arquivo ) {
			$cabecalho = (string) file_get_contents( $arquivo );

			if ( 1 !== preg_match( '/^[\s*#]*Plugin Name:\s*(.+)$/mi', $cabecalho, $nome ) ) {
				continue;
			}

			$versao = '';

			if ( 1 === preg_match( '/^[\s*#]*Version:\s*(.+)$/mi', $cabecalho, $v ) ) {
				$versao = trim( $v[1] );
			}

			$achados[ basename( $dir ) . '/' . basename( $arquivo ) ] = array(
				'Name'    => trim( $nome[1] ),
				'Version' => $versao,
			);
		}
	}

	$GLOBALS['f3b_wp']['plugins'] = $achados;

	return $achados;
}

/**
 * Derruba a lista guardada de plugins — se a bancada permitir.
 *
 * @param bool $lote Em lote.
 * @return void
 */
function wp_clean_plugins_cache( bool $lote = true ): void {
	if ( ! $GLOBALS['f3b_wp']['invalidacao'] ) {
		f3b_fita( 'limpou:plugins(inerte)' );

		return;
	}

	f3b_fita( 'limpou:plugins' );

	$GLOBALS['f3b_wp']['plugins'] = null;
}

/**
 * O plugin está ativo?
 *
 * @param string $arquivo Arquivo principal relativo.
 * @return bool
 */
function is_plugin_active( string $arquivo ): bool {
	return in_array( $arquivo, $GLOBALS['f3b_wp']['ativos'], true );
}

/**
 * Ativa um plugin.
 *
 * @param string $arquivo Arquivo principal relativo.
 * @return null
 */
function activate_plugin( string $arquivo ) {
	$GLOBALS['f3b_wp']['ativos'][] = $arquivo;

	return null;
}

/* ---------- filesystem ---------- */

/**
 * Erro do núcleo.
 */
class WP_Error {

	/**
	 * Mensagem.
	 *
	 * @var string
	 */
	private string $mensagem;

	/**
	 * Código.
	 *
	 * @var string
	 */
	private string $codigo;

	/**
	 * Monta.
	 *
	 * @param string $codigo   Código.
	 * @param string $mensagem Mensagem.
	 */
	public function __construct( string $codigo = '', string $mensagem = '' ) {
		$this->codigo   = $codigo;
		$this->mensagem = $mensagem;
	}

	/**
	 * Mensagem.
	 *
	 * @return string
	 */
	public function get_error_message(): string {
		return $this->mensagem;
	}

	/**
	 * Código — o download o lê para nomear a falha de rede.
	 *
	 * @return string
	 */
	public function get_error_code(): string {
		return $this->codigo;
	}
}

/**
 * `wp_parse_url()` da bancada.
 *
 * O `site-core` passou a ser instalado pelo CATÁLOGO, e o resolvedor de origem
 * confere host e esquema da URL declarada antes de qualquer download. A bancada
 * precisa da função para exercitar esse caminho — sem ela, o único jeito de a
 * sonda passar seria voltar a instalar o plugin copiando a pasta, que é o que
 * esta release tirou.
 *
 * @param string $url        URL.
 * @param int    $componente Componente do PHP, ou -1 para o array inteiro.
 * @return mixed
 */
function wp_parse_url( string $url, int $componente = -1 ) {
	return -1 === $componente ? parse_url( $url ) : parse_url( $url, $componente );
}

/**
 * `wp_http_validate_url()` da bancada: aceita http e https bem formados.
 *
 * @param string $url URL.
 * @return string|false
 */
function wp_http_validate_url( string $url ) {
	$partes = parse_url( $url );

	if ( ! is_array( $partes ) || ! isset( $partes['scheme'], $partes['host'] ) ) {
		return false;
	}

	return in_array( strtolower( (string) $partes['scheme'] ), array( 'http', 'https' ), true ) ? $url : false;
}

/**
 * Ganchos da bancada: registrar e remover não têm efeito aqui.
 *
 * @param string   $gancho    Nome do gancho.
 * @param callable $funcao    Função.
 * @param int      $prioridade Prioridade.
 * @param int      $args      Número de argumentos.
 * @return bool
 */
function add_filter( string $gancho, $funcao, int $prioridade = 10, int $args = 1 ): bool {
	unset( $gancho, $funcao, $prioridade, $args );

	return true;
}

/**
 * Remove um filtro na bancada.
 *
 * @param string   $gancho     Nome do gancho.
 * @param callable $funcao     Função.
 * @param int      $prioridade Prioridade.
 * @return bool
 */
function remove_filter( string $gancho, $funcao, int $prioridade = 10 ): bool {
	unset( $gancho, $funcao, $prioridade );

	return true;
}

/**
 * Apaga um arquivo na bancada.
 *
 * @param string $arquivo Caminho.
 * @return void
 */
function wp_delete_file( string $arquivo ): void {
	if ( is_file( $arquivo ) ) {
		unlink( $arquivo );
	}
}

/**
 * O INSTALADOR DO WORDPRESS, na bancada.
 *
 * O `site-core` deixou de ser instalado por troca de diretório e passou a
 * entrar pelo mesmo instalador dos outros plugins do catálogo. A bancada
 * precisa dele para exercitar o caminho REAL da entrega; sem ele, o único jeito
 * de esta sonda passar seria manter o caminho antigo vivo só para o teste.
 *
 * A simulação é honesta sobre o que faz: descompacta o zip dentro do diretório
 * de plugins do sandbox e devolve verdadeiro. O que ela NÃO simula — permissões,
 * filesystem remoto, sobrescrita parcial — está fora do que esta sonda mede, e
 * está dito aqui para ninguém tomar o silêncio por cobertura.
 */
class Automatic_Upgrader_Skin {

	/**
	 * Mensagens do instalador.
	 *
	 * @return array<int,string>
	 */
	public function get_upgrade_messages(): array {
		return array();
	}
}

/**
 * A classe-base que o tipo de `pasta_do_upgrader()` exige.
 */
class WP_Upgrader {

	/**
	 * Resultado da última instalação, como o núcleo o expõe.
	 *
	 * @var array<string,mixed>
	 */
	public $result = array();
}

/**
 * O instalador de plugin da bancada.
 */
class Plugin_Upgrader extends WP_Upgrader {

	/**
	 * Constrói com a pele do instalador.
	 *
	 * @param Automatic_Upgrader_Skin|null $skin Pele.
	 */
	public function __construct( $skin = null ) {
		unset( $skin );
	}

	/**
	 * Descompacta o pacote dentro do diretório de plugins do sandbox.
	 *
	 * @param string              $pacote  Caminho do zip.
	 * @param array<string,mixed> $opcoes  Opções do instalador.
	 * @return bool
	 */
	public function install( string $pacote, array $opcoes = array() ): bool {
		unset( $opcoes );

		if ( ! is_file( $pacote ) || ! defined( 'WP_PLUGIN_DIR' ) ) {
			return false;
		}

		if ( ! is_dir( WP_PLUGIN_DIR ) ) {
			mkdir( WP_PLUGIN_DIR, 0755, true );
		}

		$saida  = array();
		$codigo = 0;

		exec(
			sprintf( 'unzip -qo %s -d %s 2>&1', escapeshellarg( $pacote ), escapeshellarg( WP_PLUGIN_DIR ) ),
			$saida,
			$codigo
		);

		if ( 0 !== $codigo ) {
			return false;
		}

		/*
		 * O NÚCLEO PUBLICA A PASTA DE DESTINO em `result`, e é de lá que o
		 * pacote a lê para conferir se o diretório instalado é o esperado. Sem
		 * isso, a conferência de `pasta_esperada` mediria o vazio.
		 */
		$lista = array();
		exec( sprintf( 'unzip -Z1 %s 2>/dev/null', escapeshellarg( $pacote ) ), $lista );

		$primeira = isset( $lista[0] ) ? trim( (string) $lista[0], '/' ) : '';
		$pasta    = '' !== $primeira ? explode( '/', $primeira )[0] : '';

		$this->result = array( 'destination_name' => $pasta );

		/*
		 * O INSTALADOR DO NÚCLEO DERRUBA O CACHE SOZINHO, e a bancada precisa
		 * fazer o mesmo: `Plugin_Upgrader::install()` chama
		 * `wp_clean_plugins_cache()` no fim, e é por isso que o caminho do
		 * catálogo não repete a chamada. Um stub que não a fizesse acusaria
		 * defeito de cache num caminho que não tem — e a correção seria feita no
		 * lugar errado.
		 */
		if ( function_exists( 'wp_clean_plugins_cache' ) ) {
			wp_clean_plugins_cache( false );
		}

		return true;
	}
}

/**
 * O instalador de tema da bancada, com o mesmo desenho.
 */
class Theme_Upgrader extends Plugin_Upgrader {}

/**
 * É erro?
 *
 * @param mixed $valor Valor.
 * @return bool
 */
function is_wp_error( $valor ): bool {
	return $valor instanceof WP_Error;
}

/**
 * A REDE NÃO EXISTE NESTA BANCADA, e ela diz isso pelo caminho do núcleo.
 *
 * `wp_remote_head()` é o primeiro passo do download de um artefato pela URL
 * declarada, e aqui ele responde com erro — não com fatal. É assim que a
 * bancada exercita o caminho REAL da entrega sem rede: a URL do catálogo é
 * tentada, não responde, e a reserva versionada responde no lugar dela. Até a
 * 1.7.4 a bancada montava o slot do OPERADOR para se testar, o resolvedor
 * respondia por ele antes de tentar a URL, e o caminho "URL não responde →
 * reserva" — o que a entrega promete — nunca era percorrido.
 *
 * @param string              $url  URL.
 * @param array<string,mixed> $args Argumentos.
 * @return WP_Error
 */
function wp_remote_head( string $url, array $args = array() ): WP_Error {
	unset( $args );

	$GLOBALS['f3b_wp']['fita'][] = 'rede:head(' . (string) wp_parse_url( $url, PHP_URL_HOST ) . ')';

	return new WP_Error( 'http_request_failed', 'esta bancada não tem rede: a URL declarada não respondeu, por construção' );
}

/**
 * Idem para o GET: nunca chega a ser chamado quando o HEAD falha, e existe
 * para que um caminho que pule o HEAD morra dizendo o que faltou, não em fatal.
 *
 * @param string              $url  URL.
 * @param array<string,mixed> $args Argumentos.
 * @return WP_Error
 */
function wp_remote_get( string $url, array $args = array() ): WP_Error {
	unset( $url, $args );

	return new WP_Error( 'http_request_failed', 'esta bancada não tem rede' );
}

/**
 * Filesystem do núcleo, com o mínimo que a troca de diretório usa.
 */
class WP_Filesystem_Base {

	/**
	 * Cria diretório.
	 *
	 * @param string $caminho Caminho.
	 * @return bool
	 */
	public function mkdir( string $caminho ): bool {
		return is_dir( $caminho ) || mkdir( $caminho, 0777, true );
	}

	/**
	 * Move.
	 *
	 * @param string $origem     Origem.
	 * @param string $destino    Destino.
	 * @param bool   $sobrescrever Sobrescrever.
	 * @return bool
	 */
	public function move( string $origem, string $destino, bool $sobrescrever = false ): bool {
		if ( $sobrescrever && is_dir( $destino ) ) {
			$this->delete( $destino, true );
		}

		return rename( $origem, $destino );
	}

	/**
	 * Apaga.
	 *
	 * @param string $caminho    Caminho.
	 * @param bool   $recursivo  Recursivo.
	 * @return bool
	 */
	public function delete( string $caminho, bool $recursivo = false ): bool {
		if ( is_file( $caminho ) ) {
			return unlink( $caminho );
		}

		if ( ! is_dir( $caminho ) ) {
			return false;
		}

		foreach ( scandir( $caminho ) ?: array() as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}

			$this->delete( $caminho . '/' . $item, true );
		}

		return rmdir( $caminho );
	}
}

/**
 * Inicializa o filesystem global.
 *
 * @return bool
 */
function WP_Filesystem(): bool { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid -- nome do núcleo.
	global $wp_filesystem;

	if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
		$wp_filesystem = new WP_Filesystem_Base();
	}

	return true;
}

/**
 * Cópia recursiva do núcleo.
 *
 * @param string $origem  Origem.
 * @param string $destino Destino.
 * @return bool
 */
function copy_dir( string $origem, string $destino ): bool {
	if ( ! is_dir( $origem ) ) {
		return false;
	}

	if ( ! is_dir( $destino ) && ! mkdir( $destino, 0777, true ) ) {
		return false;
	}

	foreach ( scandir( $origem ) ?: array() as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}

		$de   = $origem . '/' . $item;
		$para = $destino . '/' . $item;

		if ( is_dir( $de ) ) {
			copy_dir( $de, $para );
			continue;
		}

		copy( $de, $para );
	}

	return true;
}

/**
 * DUBLÊ do gravador: só o que a troca de diretório chama.
 *
 * O gravador de verdade é ponto único de escrita de option e já tem sonda
 * própria (`sonda-gravador.php`). Carregá-lo aqui obrigaria a bancada a definir
 * `update_option()`, e escrita direta de option dentro do pacote é achado —
 * inclusive na suíte.
 */
final class F3Base_Imp_Gravador {

	/**
	 * Modo simulação.
	 *
	 * @var bool
	 */
	private static bool $simulacao = false;

	/**
	 * Liga ou desliga a simulação.
	 *
	 * @param bool $ligado Ligado.
	 * @return void
	 */
	public static function simulacao( bool $ligado ): void {
		self::$simulacao = $ligado;
	}

	/**
	 * Está em simulação?
	 *
	 * @return bool
	 */
	public static function em_simulacao(): bool {
		return self::$simulacao;
	}

	/**
	 * Diretório de trabalho da troca.
	 *
	 * @param string $sub Subdiretório.
	 * @return string
	 */
	public static function diretorio_trabalho( string $sub = '' ): string {
		$base = dirname( WP_PLUGIN_DIR ) . '/uploads/f3base-implantador/' . ( '' === $sub ? '' : $sub . '/' );

		wp_mkdir_p( $base );

		return $base;
	}
}

/**
 * DUBLÊ do journal: registra em memória, para a troca poder registrar a preimagem.
 */
final class F3Base_Imp_Journal {

	public const TIPO_OPTION  = 'option';
	public const TIPO_ARQUIVO = 'arquivo';

	/**
	 * Entradas registradas nesta sonda.
	 *
	 * @var array<int,array<string,mixed>>
	 */
	private static array $entradas = array();

	/**
	 * Inicia a execução.
	 *
	 * @param string $execucao Execução.
	 * @return void
	 */
	public static function iniciar( string $execucao ): void {
		unset( $execucao );

		self::$entradas = array();
	}

	/**
	 * Carimba a etapa.
	 *
	 * @param string $etapa Etapa.
	 * @return void
	 */
	public static function etapa( string $etapa ): void {
		unset( $etapa );
	}

	/**
	 * Registra uma mutação.
	 *
	 * @param string              $tipo      Tipo.
	 * @param string              $alvo      Alvo.
	 * @param mixed               $preimagem Preimagem.
	 * @param mixed               $posimagem Pós-imagem.
	 * @param array<string,mixed> $inversa   Inversa.
	 * @param array<string,mixed> $extra     Extra.
	 * @return string
	 */
	public static function registrar( string $tipo, string $alvo, $preimagem, $posimagem, array $inversa, array $extra = array() ): string {
		unset( $preimagem, $posimagem, $inversa, $extra );

		self::$entradas[] = array(
			'tipo' => $tipo,
			'alvo' => $alvo,
		);

		return 'sonda-' . str_pad( (string) count( self::$entradas ), 4, '0', STR_PAD_LEFT );
	}

	/**
	 * Entradas registradas.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function entradas(): array {
		return self::$entradas;
	}
}

require_once dirname( __DIR__ ) . '/lib/regra.php';
require $raiz . '/includes/class-f3base-imp-decisoes.php';
require $raiz . '/includes/class-f3base-imp-config.php';
require $raiz . '/includes/class-f3base-imp-relatorio.php';
require $raiz . '/includes/class-f3base-imp-preflight.php';
require $raiz . '/includes/class-f3base-imp-plugins.php';

$resultado = array();

/**
 * Acumula um achado.
 *
 * @param string $checagem Nome.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;
	$resultado[ $checagem ]              = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Registra uma medida.
 *
 * @param string $checagem Nome.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;
	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Afirma, medindo.
 *
 * @param string $checagem Nome.
 * @param bool   $condicao Condição observada.
 * @param string $falhou   Frase do ramo adverso.
 * @return void
 */
function afirmar( string $checagem, bool $condicao, string $falhou ): void {
	medir( $checagem );

	if ( ! $condicao ) {
		anotar( $checagem, $falhou );
	}
}

/**
 * Contém, sem depender de caixa.
 *
 * @param string $palheiro Texto medido.
 * @param string $agulha   Trecho.
 * @return bool
 */
function contem( string $palheiro, string $agulha ): bool {
	return '' !== $agulha && false !== stripos( $palheiro, $agulha );
}

/**
 * Apaga uma árvore inteira.
 *
 * @param string $dir Diretório.
 * @return void
 */
function f3b_apagar_arvore( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	foreach ( scandir( $dir ) ?: array() as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}

		$caminho = $dir . '/' . $item;

		if ( is_dir( $caminho ) ) {
			f3b_apagar_arvore( $caminho );
			continue;
		}

		unlink( $caminho );
	}

	rmdir( $dir );
}

/**
 * INSTALAÇÃO RECÉM-CRIADA: sandbox zerado, caches zerados, nenhum artefato.
 *
 * @param string $sandbox     Raiz do sandbox.
 * @param bool   $invalidacao Interruptor da invalidação de cache.
 * @return void
 */
function f3b_instalacao_limpa( string $sandbox, bool $invalidacao ): void {
	f3b_apagar_arvore( $sandbox );

	foreach ( array( '/wp-content/plugins', '/wp-content/themes', '/wp-content/uploads' ) as $sub ) {
		mkdir( $sandbox . $sub, 0777, true );
	}

	$GLOBALS['f3b_wp']['temas']       = null;
	$GLOBALS['f3b_wp']['plugins']     = null;
	$GLOBALS['f3b_wp']['invalidacao'] = $invalidacao;
	$GLOBALS['f3b_wp']['stylesheet']  = 'twentytwentyfour';
	$GLOBALS['f3b_wp']['options']     = array();
	$GLOBALS['f3b_wp']['ativos']      = array();
	$GLOBALS['f3b_wp']['fita']        = array();
}

F3Base_Imp_Config::carregar();
F3Base_Imp_Gravador::simulacao( false );
F3Base_Imp_Journal::iniciar( 'sonda' );

$tema_slug  = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );
$core_slug  = (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' );
$dir_tema   = get_theme_root() . '/' . $tema_slug;
$dir_core   = WP_PLUGIN_DIR . '/' . $core_slug;

/* =======================================================================
 * instalacao.limpa_le_de_volta
 * ==================================================================== */

$nome = 'instalacao.limpa_le_de_volta';

/* ---------- TEMA, PISO: a 1.0.15 reproduzida (invalidação DESLIGADA) ---------- */

f3b_instalacao_limpa( $sandbox, false );

afirmar( $nome, '' !== $tema_slug, 'piso do tema: site.tema_slug vazio — não há alvo a instalar' );
afirmar( $nome, ! is_dir( $dir_tema ), 'piso do tema: o alvo já existia antes da troca; este piso EXIGE alvo inexistente, que é o caso que passou quinze releases sem ser exercitado' );

/* A CONSULTA PRÉVIA, na mesma "requisição": é ela que memoriza o negativo. */
afirmar( $nome, false === wp_get_theme( $tema_slug )->exists(), 'piso do tema: a consulta prévia devia dizer que o tema NÃO existe numa instalação limpa' );

$saida_tema_cego = F3Base_Imp_Plugins::aplicar_tema();

afirmar( $nome, is_dir( $dir_tema ), 'piso do tema: a troca de diretório não colocou o tema no disco — sem isso o resto do piso não mede nada' );
afirmar( $nome, is_file( $dir_tema . '/style.css' ), 'piso do tema: o diretório trocado não tem style.css' );
afirmar( $nome, false === wp_get_theme( $tema_slug )->exists(), 'piso do tema: sem invalidação, a API DEVERIA continuar cega — a bancada não está reproduzindo o cache negativo, e um teto medido sobre ela não provaria nada' );
afirmar( $nome, 'FALHA' === $saida_tema_cego['estado'], 'piso do tema: com a API cega a unidade tinha de fechar FALHA, e fechou ' . (string) $saida_tema_cego['estado'] );
afirmar( $nome, contem( (string) $saida_tema_cego['motivo'], 'DEFEITO DE CACHE' ), 'piso do tema: a mensagem não nomeia o defeito de cache — ' . (string) $saida_tema_cego['motivo'] );
afirmar( $nome, ! contem( (string) $saida_tema_cego['motivo'], 'não apareceu no disco' ), 'piso do tema: a mensagem diz "não apareceu no disco" sobre um diretório que ESTÁ no disco, que é o defeito de relatório da 1.0.15' );

/* ---------- TEMA, TETO: a mesma instalação limpa com a 1.0.16 ---------- */

f3b_instalacao_limpa( $sandbox, true );

afirmar( $nome, ! is_dir( $dir_tema ), 'teto do tema: o sandbox não zerou entre os cenários' );
afirmar( $nome, false === wp_get_theme( $tema_slug )->exists(), 'teto do tema: a consulta prévia devia memorizar o negativo, como na instalação limpa real' );

$saida_tema = F3Base_Imp_Plugins::aplicar_tema();

afirmar( $nome, true === wp_get_theme( $tema_slug )->exists(), 'teto do tema: a leitura de volta NÃO enxergou o tema depois da troca — a invalidação não aconteceu' );
afirmar( $nome, 'OK' === $saida_tema['estado'], 'teto do tema: instalação limpa devia fechar OK, e fechou ' . (string) $saida_tema['estado'] . ' — ' . (string) $saida_tema['motivo'] );
afirmar( $nome, ! contem( (string) $saida_tema['motivo'], 'não apareceu no disco' ), 'teto do tema: a mensagem de disco apareceu num caso que deu certo' );
afirmar( $nome, ! contem( (string) $saida_tema['motivo'], 'DEFEITO DE CACHE' ), 'teto do tema: a mensagem de cache apareceu num caso que deu certo' );
afirmar( $nome, get_stylesheet() === $tema_slug, 'teto do tema: o tema instalado não ficou ativo' );

/* A ORDEM: a limpeza precisa acontecer ENTRE a consulta prévia e a leitura de volta. */
$fita        = $GLOBALS['f3b_wp']['fita'];
$pos_limpeza = array_search( 'limpou:temas', $fita, true );
$pos_leitura = false === $pos_limpeza ? false : null;

if ( false !== $pos_limpeza ) {
	$pos_leitura = false;

	foreach ( $fita as $indice => $evento ) {
		if ( $indice > (int) $pos_limpeza && 'leu:temas(disco)' === $evento ) {
			$pos_leitura = $indice;
			break;
		}
	}
}

afirmar( $nome, false !== $pos_limpeza, 'teto do tema: nenhuma invalidação de cache de tema aconteceu na troca — fita: ' . implode( ' → ', $fita ) );
afirmar( $nome, false !== $pos_leitura && null !== $pos_leitura, 'teto do tema: nenhuma leitura de disco depois da invalidação — a leitura de volta respondeu do cache velho. Fita: ' . implode( ' → ', $fita ) );
afirmar( $nome, in_array( 'leu:temas(disco)', array_slice( $fita, 0, false === $pos_limpeza ? 0 : (int) $pos_limpeza ), true ), 'teto do tema: a consulta prévia não chegou a ler o disco antes da invalidação — o piso não reproduziu a ordem da instalação limpa' );

/*
 * A RESERVA EMBUTIDA É A DA ÁRVORE — 2.0.0.
 *
 * O `site-core` entra pelo catálogo, como qualquer outro plugin: a URL
 * declarada primeiro, e a cópia embutida como reserva. Até a 1.7.4 esta bancada
 * MONTAVA a própria reserva a partir de `fontes/plugin/`, porque na árvore de
 * origem ela não existia — era saída de build. Desde a 2.0.0 ela é ENTRADA de
 * build: `assets/plugins/<slug>-<versão>.zip` é o zip publicado copiado para a
 * árvore, e é exatamente ele que `artefato_do_papel()` resolve aqui. O piso
 * passa a medir o caminho REAL da entrega com o artefato REAL — URL que não
 * responde, reserva publicada que instala — e não uma montagem que só existia
 * nesta sonda.
 */
$reserva_do_core = f3b_reserva_do_site_core( $raiz );

afirmar( $nome, '' === $reserva_do_core['erro'] && is_file( $reserva_do_core['caminho'] ), 'a reserva embutida do site-core não foi encontrada na árvore (' . $reserva_do_core['erro'] . '): sem ela o piso mediria outro caminho de instalação' );

/*
 * O PISO DA API CEGA NÃO PASSA MAIS PELO SITE-CORE, e é por uma razão de
 * desenho, não por comodidade.
 *
 * Ele reproduz a 1.0.15: instalar sem derrubar o cache do núcleo e a leitura de
 * volta responder do negativo memorizado. Esse defeito só existe em quem instala
 * FORA do instalador do WordPress — `trocar_diretorio()`, que é o caminho do
 * TEMA e onde este piso continua inteiro, logo acima.
 *
 * O `site-core` deixou de usar esse caminho: ele entra pelo catálogo, e
 * `Plugin_Upgrader::install()` derruba o cache sozinho. Manter aqui um piso que
 * exige o defeito seria exigir que o plugin voltasse a ser instalado por um
 * caminho que não tem mais — piso amarrado ao código antigo em vez de à regra.
 *
 * O que sobra do site-core nesta sonda é o TETO: instalação limpa pelo catálogo
 * põe o plugin no disco e a leitura de volta o enxerga.
 */

/* ---------- SITE-CORE, TETO: a mesma instalação limpa com a 1.0.16 ---------- */

f3b_instalacao_limpa( $sandbox, true );

afirmar( $nome, ! is_dir( $dir_core ), 'teto do site-core: o sandbox não zerou entre os cenários' );
afirmar( $nome, '' === F3Base_Imp_Plugins::versao_instalada( $core_slug ), 'teto do site-core: a consulta prévia devia memorizar o negativo' );

$saida_core = F3Base_Imp_Plugins::aplicar_site_core();
$fita_core  = $GLOBALS['f3b_wp']['fita'];

afirmar( $nome, '' !== F3Base_Imp_Plugins::versao_instalada( $core_slug ), 'teto do site-core: a leitura de volta NÃO enxergou o plugin depois da troca — a invalidação não aconteceu' );
afirmar( $nome, 'OK' === $saida_core['estado'], 'teto do site-core: instalação limpa devia fechar OK, e fechou ' . (string) $saida_core['estado'] . ' — ' . (string) $saida_core['motivo'] );
afirmar( $nome, ! contem( (string) $saida_core['motivo'], 'não apareceu no disco' ), 'teto do site-core: a mensagem de disco apareceu num caso que deu certo' );
afirmar( $nome, ! contem( (string) $saida_core['motivo'], 'DEFEITO DE CACHE' ), 'teto do site-core: a mensagem de cache apareceu num caso que deu certo' );

/*
 * O CAMINHO PERCORRIDO É O DA ENTREGA — 2.0.0: a URL declarada foi TENTADA
 * (a fita registra o HEAD), não respondeu, e quem instalou foi a RESERVA
 * VERSIONADA — com o digesto declarado no catálogo conferido sobre ela. Sem
 * estas três afirmações a linha acima provaria só que "algum zip instalou".
 */
afirmar( $nome, in_array( 'rede:head(github.com)', $fita_core, true ), 'teto do site-core: a URL declarada no catálogo NÃO foi tentada antes da reserva — a precedência operador → URL → reserva não foi percorrida' );
afirmar( $nome, contem( (string) $saida_core['motivo'], 'reserva versionada' ) && contem( (string) $saida_core['motivo'], $reserva_do_core['relativo'] ), 'teto do site-core: a origem que respondeu não foi a reserva versionada nomeada pelo caminho — ' . (string) $saida_core['motivo'] );
afirmar( $nome, contem( (string) $saida_core['motivo'], 'Digesto DECLARADO conferido' ) && contem( (string) $saida_core['motivo'], $reserva_do_core['sha256'] ), 'teto do site-core: a reserva instalou SEM o digesto declarado ter sido conferido sobre ela — ' . (string) $saida_core['motivo'] );

/*
 * PISO DO DIGESTO SOBRE A RESERVA: com o catálogo declarando OUTRO sha256, a
 * reserva NÃO pode instalar. O catálogo é lido de F3BASE_IMP_DIR e memorizado
 * por arquivo; o mutante entra pelo cache, por reflexão, e é desfeito em
 * seguida — mexer no arquivo real do pacote no meio de uma sonda seria plantar
 * o defeito na árvore que as outras sondas estão medindo.
 */
$cache_de_decisoes = new ReflectionProperty( 'F3Base_Imp_Decisoes', 'lidos' );
$cache_de_decisoes->setAccessible( true );
$catalogo_original = (array) $cache_de_decisoes->getValue();
$arquivo_catalogo  = F3BASE_IMP_DIR . 'config/decisoes.tsv';
$indice_do_core    = F3Base_Imp_Plugins::indice_do_papel( 'site-core' );

if ( isset( $catalogo_original[ $arquivo_catalogo ] ) && $indice_do_core >= 0 ) {
	$mutante                                                                = $catalogo_original;
	$mutante[ $arquivo_catalogo ][ 'plugins.instalaveis.' . $indice_do_core ]['sha256'] = str_repeat( '0', 64 );
	$cache_de_decisoes->setValue( null, $mutante );

	f3b_instalacao_limpa( $sandbox, true );

	$saida_mutante = F3Base_Imp_Plugins::aplicar_site_core();

	$cache_de_decisoes->setValue( null, $catalogo_original );

	afirmar( $nome, 'FALHA' === $saida_mutante['estado'] && contem( (string) $saida_mutante['motivo'], 'NÃO foi instalado' ), 'piso do digesto sobre a reserva: com o catálogo declarando outro sha256, a reserva devia ser RECUSADA e fechou ' . (string) $saida_mutante['estado'] . ' — ' . (string) $saida_mutante['motivo'] );
	afirmar( $nome, ! is_dir( $dir_core ), 'piso do digesto sobre a reserva: a reserva recusada pelo digesto foi instalada mesmo assim' );
} else {
	anotar( $nome, 'piso do digesto sobre a reserva: o catálogo memorizado não pôde ser alcançado para plantar o mutante, e sem o mutante esta linha não provou que uma reserva com digesto errado é recusada' );
}

/*
 * TETO DO NUNCA-DOWNGRADE SOBRE A RESERVA: com o plugin instalado numa versão
 * À FRENTE da que a reserva carrega e a URL fora do ar, a reserva NÃO instala
 * por cima. A guarda de sempre compara a instalada com a versão que a origem
 * anuncia, e a URL não anuncia versão — a reserva anuncia, pelo cabeçalho de
 * dentro do zip, e é essa comparação que esta linha exige.
 */
f3b_instalacao_limpa( $sandbox, true );
mkdir( $dir_core, 0777, true );
file_put_contents(
	$dir_core . '/' . $core_slug . '.php',
	"<?php\n/**\n * Plugin Name: Plantado à frente da reserva\n * Version: 9.9.9\n */\n"
);

afirmar( $nome, '9.9.9' === F3Base_Imp_Plugins::versao_instalada( $core_slug ), 'teto do nunca-downgrade: o sandbox não aceitou a instalação plantada em 9.9.9' );

$saida_a_frente = F3Base_Imp_Plugins::aplicar_site_core();

afirmar( $nome, contem( (string) $saida_a_frente['motivo'], 'nunca downgrade' ) && contem( (string) $saida_a_frente['motivo'], $reserva_do_core['relativo'] ), 'teto do nunca-downgrade: com 9.9.9 instalada e a URL fora do ar, a reserva devia ser recusada NOMEANDO o caminho dela, e a saída foi ' . (string) $saida_a_frente['estado'] . ' — ' . (string) $saida_a_frente['motivo'] );
afirmar( $nome, 'FALHA' !== $saida_a_frente['estado'] && 'BLOCKED' !== $saida_a_frente['estado'], 'teto do nunca-downgrade: manter a versão instalada à frente não é defeito, e fechou ' . (string) $saida_a_frente['estado'] );
afirmar( $nome, '9.9.9' === F3Base_Imp_Plugins::versao_instalada( $core_slug ), 'teto do nunca-downgrade: a reserva foi instalada POR CIMA da 9.9.9 — a versão lida de volta é ' . F3Base_Imp_Plugins::versao_instalada( $core_slug ) );
afirmar( $nome, in_array( 'rede:head(github.com)', $GLOBALS['f3b_wp']['fita'], true ), 'teto do nunca-downgrade: a URL não foi tentada antes de a reserva ser considerada' );

$limpou_core = array_search( 'limpou:plugins', $fita_core, true );
$releu_core  = false;

if ( false !== $limpou_core ) {
	foreach ( $fita_core as $indice => $evento ) {
		if ( $indice > (int) $limpou_core && 'leu:plugins(disco)' === $evento ) {
			$releu_core = true;
			break;
		}
	}
}

afirmar( $nome, false !== $limpou_core, 'teto do site-core: nenhuma invalidação de cache de plugin aconteceu na troca — fita: ' . implode( ' → ', $fita_core ) );
afirmar( $nome, $releu_core, 'teto do site-core: nenhuma leitura de disco depois da invalidação — a leitura de volta respondeu do cache velho. Fita: ' . implode( ' → ', $fita_core ) );
afirmar( $nome, in_array( 'leu:plugins(disco)', array_slice( $fita_core, 0, false === $limpou_core ? 0 : (int) $limpou_core ), true ), 'teto do site-core: a consulta prévia não chegou a ler o disco antes da invalidação' );

/* =======================================================================
 * instalacao.disco_ou_cache — a tabela inteira do discriminante
 * ==================================================================== */

$nome = 'instalacao.disco_ou_cache';

f3b_instalacao_limpa( $sandbox, true );

$presente_tema = get_theme_root() . '/presente';
$incompleto    = get_theme_root() . '/incompleto';
$presente_plug = WP_PLUGIN_DIR . '/presente';
$incomplet_plug = WP_PLUGIN_DIR . '/incompleto';

mkdir( $presente_tema, 0777, true );
file_put_contents( $presente_tema . '/style.css', "/*\nTheme Name: Presente\nVersion: 1.0.0\n*/\n" );
mkdir( $incompleto, 0777, true );
mkdir( $presente_plug, 0777, true );
file_put_contents( $presente_plug . '/presente.php', "<?php\n/*\nPlugin Name: Presente\nVersion: 1.0.0\n*/\n" );
mkdir( $incomplet_plug, 0777, true );

$tabela = array(
	array( 'tema', 'ausente', get_theme_root() . '/nao-existe', false, 'ausente_no_disco', false, 'não apareceu no disco', 'DEFEITO DE CACHE' ),
	array( 'tema', 'presente', $incompleto, false, 'principal_ausente', false, 'arquivo principal', 'não apareceu no disco' ),
	array( 'tema', 'presente', $presente_tema, false, 'cache_desatualizado', false, 'DEFEITO DE CACHE', 'não apareceu no disco' ),
	array( 'tema', 'presente', $presente_tema, true, 'presente', true, 'leitura de volta', 'DEFEITO DE CACHE' ),
	array( 'tema', 'ausente', get_theme_root() . '/nao-existe', true, 'presente_fora_do_caminho', true, 'raiz diferente da medida', 'não apareceu no disco' ),
	array( 'tema', 'presente', $incompleto, true, 'presente_fora_do_caminho', true, 'raiz diferente da medida', 'arquivo principal' ),
	array( 'plugin', 'ausente', WP_PLUGIN_DIR . '/nao-existe', false, 'ausente_no_disco', false, 'não apareceu no disco', 'DEFEITO DE CACHE' ),
	array( 'plugin', 'presente', $incomplet_plug, false, 'principal_ausente', false, 'arquivo principal', 'não apareceu no disco' ),
	array( 'plugin', 'presente', $presente_plug, false, 'cache_desatualizado', false, 'DEFEITO DE CACHE', 'não apareceu no disco' ),
	array( 'plugin', 'presente', $presente_plug, true, 'presente', true, 'leitura de volta', 'DEFEITO DE CACHE' ),
	array( 'plugin', 'ausente', WP_PLUGIN_DIR . '/nao-existe', true, 'presente_fora_do_caminho', true, 'raiz diferente da medida', 'não apareceu no disco' ),
	array( 'plugin', 'presente', $incomplet_plug, true, 'presente_fora_do_caminho', true, 'raiz diferente da medida', 'arquivo principal' ),
);

foreach ( $tabela as $linha ) {
	$veredito = F3Base_Imp_Plugins::leitura_de_volta_do_artefato( $linha[0], basename( $linha[2] ), $linha[2], $linha[3] );
	$onde     = $linha[0] . '/' . $linha[1] . '/api=' . ( $linha[3] ? 've' : 'cega' );

	afirmar( $nome, $veredito['diagnostico'] === $linha[4], $onde . ': diagnóstico esperado ' . $linha[4] . ', obtido ' . (string) $veredito['diagnostico'] );
	afirmar( $nome, $veredito['ok'] === $linha[5], $onde . ': ok esperado ' . ( $linha[5] ? 'true' : 'false' ) );
	afirmar( $nome, contem( (string) $veredito['motivo'], $linha[6] ), $onde . ': a mensagem não traz "' . $linha[6] . '" — ' . (string) $veredito['motivo'] );
	afirmar( $nome, ! contem( (string) $veredito['motivo'], $linha[7] ), $onde . ': a mensagem traz "' . $linha[7] . '", que pertence a outro diagnóstico — ' . (string) $veredito['motivo'] );
}

/* =======================================================================
 * instalacao.artefato_fonte_unica — quem instala e quem prova leem o mesmo
 * ==================================================================== */

$nome = 'instalacao.artefato_fonte_unica';

foreach ( array( 'tema' => $tema_slug, 'site_core' => $core_slug ) as $papel => $slug ) {
	$artefato = F3Base_Imp_Plugins::artefato_do_papel( $papel );

	afirmar( $nome, $artefato['slug'] === $slug, $papel . ': a fonte única devolveu slug "' . (string) $artefato['slug'] . '" e a configuração declara "' . $slug . '"' );
	afirmar( $nome, array() !== $artefato['candidatos'], $papel . ': a fonte única não declarou nenhum caminho candidato' );
	afirmar( $nome, '' !== $artefato['tipo'], $papel . ': nenhum dos caminhos declarados existe no pacote — ' . implode( ', ', $artefato['candidatos'] ) );
	afirmar( $nome, in_array( 'assets/plugins/' . $slug . ( 'tema' === $papel ? '-tema' : '' ) . '.zip', $artefato['candidatos'], true ), $papel . ': o slot de zip do operador saiu da lista de candidatos' );
	afirmar( $nome, str_starts_with( (string) $artefato['caminho'], rtrim( F3BASE_IMP_DIR, '/' ) ), $papel . ': o caminho resolvido está fora do pacote — ' . (string) $artefato['caminho'] );
}

/* Papel desconhecido não inventa artefato: piso do falso positivo. */
$desconhecido = F3Base_Imp_Plugins::artefato_do_papel( 'inventado' );
afirmar( $nome, '' === $desconhecido['tipo'] && array() === $desconhecido['candidatos'], 'papel não declarado devolveu artefato — a fonte única não pode inventar caminho' );

f3b_apagar_arvore( $sandbox );
f3b_apagar_arvore( rtrim( ABSPATH, '/' ) );

echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );

