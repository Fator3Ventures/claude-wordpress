<?php
/**
 * Sonda da RENOMEAÇÃO DE PREFIXO em subprocesso.
 *
 * Ela existe porque a renomeação é a única ferramenta deste pacote que reescreve
 * o pacote inteiro, e o defeito dela não aparece no pacote: aparece no SITE que
 * nasceu dela, semanas depois, como número que não bate. Nenhuma checagem
 * estática podia vê-lo, porque no template — onde `site.prefixo_tecnico` ainda é
 * o prefixo de origem — não há nada para acusar.
 *
 * O QUE ELA MEDE, e as duas metades são inseparáveis:
 *
 * 1. `renomeacao.plugin_intacto` — depois de renomear para um prefixo qualquer,
 *    NENHUM arquivo do plugin mudou: nem conteúdo, nem nome, nem caminho. O que
 *    está em jogo: um site cujo plugin foi renomeado tem options que nenhuma
 *    release alcança. Até a 1.6.6 esta ferramenta renomeava `fontes/site-core/`
 *    junto com o resto, e cada site produzia um FORK do plugin.
 * 2. `renomeacao.secao_medida_apos_renomear` — a classe que marca seção medida é
 *    carimbada pelos PATTERNS DO TEMA e pelo CONTEÚDO, que SÃO renomeados, e é
 *    PROCURADA pelo coletor do plugin, que NÃO é. A sonda monta a lista de
 *    classes que os patterns e as páginas renomeados carimbam e roda a FUNÇÃO
 *    REAL do coletor — `nomeDaSecao()`, extraída do arquivo entregue ao
 *    navegador — contra cada uma. Seção que sai sem nome é seção que o
 *    observador nunca vai enxergar, e o evento `f3base_secao_vista` responde
 *    "nada" para sempre, calado.
 *
 * O PISO É O MUTANTE DO PRÓPRIO PACOTE, e são DOIS mutantes, porque os dois
 * defeitos são diferentes e um não produz o outro:
 *
 * - `sem-exclusao` é a 1.6.6 inteira: sem as exclusões de caminho e sem o
 *   contrato, a ferramenta renomeia o que é do plugin — a cópia vendorizada em
 *   `partilhado/` e o que houver de texto em `assets/plugins/` — junto com o
 *   resto. Desde a 2.0.0 a fonte do plugin não mora mais aqui; o que sobrou
 *   dela nesta árvore é o que este mutante ataca. É o
 *   piso de `renomeacao.plugin_intacto`. Repare que ele NÃO quebra a medição de
 *   seção: o plugin renomeado passa a procurar `acme-secao-` e o tema renomeado
 *   passa a carimbar `acme-secao-`, e os dois se encontram. O site fica
 *   internamente coerente e ESTRANHO À RELEASE — que é exatamente o defeito, e
 *   é por isso que ele precisa de uma medição própria.
 * - `sem-contrato` é o meio-termo, e é o que torna esta sonda necessária: as
 *   exclusões de caminho estão lá — o plugin não é tocado —, mas o contrato de
 *   nomes some. Aí o tema e o conteúdo passam a carimbar `acme-secao-` e o
 *   plugin continua procurando `f3base-secao-`, e a medição de seção morre
 *   calada em todo site renomeado. É o piso de
 *   `renomeacao.secao_medida_apos_renomear`, e é o defeito que a exclusão de
 *   caminho SOZINHA introduziria.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );
$suite = dirname( __DIR__ );

require_once $suite . '/lib/regra.php';
/*
 * A REGRA DA PRESERVAÇÃO vem da árvore DESTA suíte, não da raiz varrida — a
 * mesma razão de `estatica.php`: quem mede não pode usar a cópia do medido.
 */
require_once dirname( __DIR__, 2 ) . '/ferramentas/nomes-preservados.php';

/**
 * Copia a árvore do pacote para um diretório de trabalho, sem `dist/`.
 *
 * @param string $raiz    Raiz do pacote.
 * @param string $destino Destino.
 * @return bool
 */
function f3b_sr_copiar( string $raiz, string $destino ): bool {
	if ( ! is_dir( $destino ) && ! mkdir( $destino, 0755, true ) && ! is_dir( $destino ) ) {
		return false;
	}

	foreach ( (array) scandir( $raiz ) as $nome ) {
		$nome = (string) $nome;

		if ( '.' === $nome || '..' === $nome || 'dist' === $nome ) {
			continue;
		}

		$codigo = 0;
		$saida  = array();
		exec( 'cp -a ' . escapeshellarg( $raiz . '/' . $nome ) . ' ' . escapeshellarg( $destino . '/' ) . ' 2>&1', $saida, $codigo );

		if ( 0 !== $codigo ) {
			return false;
		}
	}

	return true;
}

/**
 * Impressão de um subdiretório: caminho relativo => sha256 do conteúdo.
 *
 * @param string            $raiz      Raiz.
 * @param array<int,string> $prefixos  Prefixos a incluir.
 * @return array<string,string>
 */
function f3b_sr_impressao( string $raiz, array $prefixos ): array {
	$saida = array();

	foreach ( $prefixos as $prefixo ) {
		$base = $raiz . '/' . $prefixo;

		if ( ! is_dir( $base ) ) {
			continue;
		}

		$iter = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ( $iter as $item ) {
			if ( ! $item->isFile() ) {
				continue;
			}

			$rel           = $prefixo . '/' . ltrim( substr( $item->getPathname(), strlen( rtrim( $base, '/' ) ) ), '/' );
			$saida[ $rel ] = (string) hash_file( 'sha256', $item->getPathname() );
		}
	}

	ksort( $saida );

	return $saida;
}

/**
 * Apaga uma árvore inteira.
 *
 * @param string $dir Diretório.
 * @return void
 */
function f3b_sr_apagar( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	foreach ( (array) scandir( $dir ) as $nome ) {
		$nome = (string) $nome;

		if ( '.' === $nome || '..' === $nome ) {
			continue;
		}

		$alvo = $dir . '/' . $nome;

		if ( is_dir( $alvo ) && ! is_link( $alvo ) ) {
			f3b_sr_apagar( $alvo );
			continue;
		}

		unlink( $alvo );
	}

	rmdir( $dir );
}

/**
 * As classes de seção que o markup RENOMEADO carimba.
 *
 * Lê os patterns do tema e as páginas do conteúdo — os dois lados que a
 * renomeação toca — e devolve cada token de classe que se pareça com uma marca
 * de seção: qualquer `<algo>-secao-<nome>`. A busca é pela FORMA e não pelo
 * prefixo esperado, de propósito: procurar já pelo prefixo certo devolveria
 * lista vazia num pacote quebrado, e lista vazia não acusa nada.
 *
 * @param string $raiz Raiz renomeada.
 * @return array<string,string> classe => arquivo onde ela aparece.
 */
function f3b_sr_classes_de_secao( string $raiz ): array {
	$saida = array();
	$alvos = array_merge(
		glob( $raiz . '/fontes/tema/patterns/*.php' ) ?: array(),
		glob( $raiz . '/content/pages/*.html' ) ?: array()
	);

	foreach ( $alvos as $arquivo ) {
		$fonte = (string) file_get_contents( $arquivo );

		if ( preg_match_all( '/[A-Za-z0-9_-]*-secao-[a-z0-9-]+/', $fonte, $achou ) ) {
			foreach ( $achou[0] as $classe ) {
				if ( ! isset( $saida[ $classe ] ) ) {
					$saida[ $classe ] = str_replace( $raiz . '/', '', $arquivo );
				}
			}
		}
	}

	ksort( $saida );

	return $saida;
}

/**
 * O prefixo de seção que o PLUGIN publica ao navegador.
 *
 * @param string $raiz Raiz.
 * @return string
 */
function f3b_sr_prefixo_de_secao( string $raiz ): string {
	$fonte = f3b_fonte_do_plugin( $raiz, 'includes/class-f3base-modulo-tracking.php' );

	return 1 === preg_match( "/const\s+PREFIXO_SECAO\s*=\s*'([^']+)'/", $fonte, $achou ) ? $achou[1] : '';
}

/**
 * Roda a FUNÇÃO REAL do coletor contra cada classe carimbada pelo markup.
 *
 * Não há segunda implementação da regra aqui: a sonda extrai o corpo de
 * `nomeDaSecao()` do próprio `f3base-tracking.js` e o executa sob o Node. Uma
 * cópia da regra escrita aqui aprovaria o pacote pelo que a suíte acha que o
 * cliente faz, e não pelo que ele faz.
 *
 * @param string               $raiz    Raiz renomeada.
 * @param string               $suite   Diretório da suíte.
 * @param string               $prefixo Prefixo publicado pelo plugin.
 * @param array<string,string> $classes Classes carimbadas.
 * @return array{ok:bool,erro:string,nomes:array<string,string>}
 */
function f3b_sr_nomes_medidos( string $raiz, string $suite, string $prefixo, array $classes ): array {
	/*
	 * O CLIENTE VEM DE DENTRO DA RESERVA da árvore renomeada — que é o zip
	 * publicado, e é o que o site recebe. Ele é extraído para um arquivo
	 * temporário porque o harness do Node lê caminho, não conteúdo.
	 */
	$corpo = f3b_fonte_do_plugin( $raiz, 'assets/f3base-tracking.js' );

	if ( '' === $corpo ) {
		return array( 'ok' => false, 'erro' => 'assets/f3base-tracking.js não pôde ser lido de dentro da reserva do plugin na árvore renomeada', 'nomes' => array() );
	}

	$cliente = tempnam( sys_get_temp_dir(), 'f3b-sr-cliente-' );
	file_put_contents( $cliente, $corpo );

	$harness = $suite . '/lib/sonda-renomeacao-secao.mjs';

	if ( ! is_file( $harness ) ) {
		unlink( $cliente );

		return array( 'ok' => false, 'erro' => 'suite/lib/sonda-renomeacao-secao.mjs ausente: sem o harness a função real do coletor não é executada, e uma checagem que não roda o que mede não pode fechar OK', 'nomes' => array() );
	}

	$entrada = array(
		'cliente' => $cliente,
		'prefixo' => $prefixo,
		'classes' => array_keys( $classes ),
	);

	$arquivo = tempnam( sys_get_temp_dir(), 'f3b-sr-' );
	file_put_contents( $arquivo, (string) json_encode( $entrada ) );

	$saida  = array();
	$codigo = 0;
	exec( 'node ' . escapeshellarg( $harness ) . ' ' . escapeshellarg( $arquivo ) . ' 2>&1', $saida, $codigo );

	unlink( $arquivo );
	unlink( $cliente );

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) || ! isset( $json['nomes'] ) ) {
		return array( 'ok' => false, 'erro' => 'o harness do coletor não devolveu veredito analisável: ' . implode( ' | ', array_slice( $saida, 0, 3 ) ), 'nomes' => array() );
	}

    return array( 'ok' => true, 'erro' => '', 'nomes' => array_map( 'strval', (array) $json['nomes'] ) );
}

/**
 * Renomeia uma cópia do pacote e devolve o que aconteceu com ela.
 *
 * @param string $raiz    Raiz de origem.
 * @param string $suite   Diretório da suíte.
 * @param string $destino Diretório de trabalho.
 * @param string $modo    `fiel`, `sem-exclusao` ou `sem-contrato`.
 * @return array<string,mixed>
 */
function f3b_sr_rodada( string $raiz, string $suite, string $destino, string $modo ): array {
	if ( ! f3b_sr_copiar( $raiz, $destino ) ) {
		return array( 'erro' => 'não foi possível copiar a árvore do pacote para ' . $destino );
	}

	$ferramenta = $destino . '/ferramentas/renomear-prefixo.php';

	if ( 'sem-exclusao' === $modo ) {
		/*
		 * As duas exclusões de caminho saem da tabela. É a 1.6.6 na parte que
		 * importa para `renomeacao.plugin_intacto`: a ferramenta atravessa a
		 * fonte do plugin e reescreve nome e conteúdo.
		 */
		$tabela = $destino . '/ferramentas/excecoes-de-prefixo.tsv';
		$linhas = array();

		foreach ( explode( "\n", (string) file_get_contents( $tabela ) ) as $linha ) {
			if ( str_starts_with( $linha, 'partilhado/' ) || str_starts_with( $linha, 'assets/plugins/' ) ) {
				continue;
			}

			$linhas[] = $linha;
		}

		file_put_contents( $tabela, implode( "\n", $linhas ) );
	}

	if ( 'sem-exclusao' === $modo || 'sem-contrato' === $modo ) {
		/*
		 * A PRESERVAÇÃO DE NOMES SOME INTEIRA, e são as DUAS metades dela: a
		 * tabela declarada e a derivação de disco. Apagar só a tabela não
		 * reproduz defeito nenhum — a derivação continuaria achando
		 * `f3base-secao-` dentro do próprio plugin e preservando a grafia —, e
		 * um piso que não reproduz o defeito é um piso que aprova o pacote
		 * quebrado. O que este mutante monta é a EXCLUSÃO DE CAMINHO SOZINHA,
		 * que é a meia correção: o plugin fica intacto e todo o resto do pacote
		 * troca de prefixo, inclusive as grafias que o plugin lê.
		 */
		$contrato = $destino . '/partilhado/dados/contrato-de-nomes.tsv';

		if ( is_file( $contrato ) ) {
			unlink( $contrato );
		}

		$regra = $destino . '/ferramentas/nomes-preservados.php';

		if ( is_file( $regra ) ) {
			$codigo_da_regra = (string) file_get_contents( $regra );
			$codigo_da_regra = str_replace(
				"function f3b_np_grafias_do_diretorio( string \$base, array \$nuas ): array {\n\tif ( ! is_dir( \$base ) ) {\n\t\treturn array();\n\t}",
				"function f3b_np_grafias_do_diretorio( string \$base, array \$nuas ): array {\n\tunset( \$base, \$nuas );\n\n\treturn array();",
				$codigo_da_regra
			);
			/*
			 * A DERIVAÇÃO DA RESERVA TAMBÉM SOME — 2.0.0. Desde que a fonte do
			 * plugin deixou de morar na árvore, as grafias dele são derivadas de
			 * dentro do zip publicado, e essa derivação sozinha bastaria para
			 * preservar `f3base-secao-`: o mutante que deixasse só ela viva não
			 * reproduziria a exclusão de caminho SOZINHA, e um piso que não
			 * reproduz o defeito aprova o pacote quebrado.
			 */
			$codigo_da_regra = str_replace(
				"function f3b_np_grafias_da_reserva( string \$raiz, array \$nuas ): array {\n",
				"function f3b_np_grafias_da_reserva( string \$raiz, array \$nuas ): array {\n\tunset( \$raiz, \$nuas );\n\n\treturn array();\n\n",
				$codigo_da_regra
			);
			file_put_contents( $regra, $codigo_da_regra );
		}

		$codigo_da_ferramenta = (string) file_get_contents( $ferramenta );
		$corte                = strpos( $codigo_da_ferramenta, 'if ( array() === $contrato ) {' );
		$fim                  = strpos( $codigo_da_ferramenta, 'echo "== renomeação de prefixo ==' );

		if ( false !== $corte && false !== $fim && $fim > $corte ) {
			$codigo_da_ferramenta = substr( $codigo_da_ferramenta, 0, $corte ) . substr( $codigo_da_ferramenta, $fim );
			file_put_contents( $ferramenta, $codigo_da_ferramenta );
		}
	}

	if ( 'prosa' === $modo ) {
		/*
		 * O PLANTIO DA PROSA — 2.0.0. A reserva ganha um arquivo PHP em que
		 * uma grafia do prefixo aparece SÓ num comentário e outra SÓ no
		 * código; o pacote ganha as duas numa linha do arquivo principal, que
		 * a renomeação atravessa. O que se mede depois é qual das duas
		 * sobreviveu: a do código PRECISA sobreviver (o plugin a usa), a da
		 * prosa PRECISA ser renomeada (ninguém a usa — alguém falou dela).
		 */
		$zips = glob( $destino . '/assets/plugins/*-[0-9]*.[0-9]*.[0-9]*.zip' ) ?: array();

		if ( 1 !== count( $zips ) ) {
			return array( 'erro' => 'árvore prosa: a reserva do plugin não é exatamente uma em assets/plugins/, e sem ela não há onde plantar' );
		}

		$zip_da_reserva = (string) $zips[0];
		$plantio        = $destino . '/.plantio-da-sonda';

		f3b_sr_apagar( $plantio );
		mkdir( $plantio, 0777, true );

		$saida_unzip  = array();
		$codigo_unzip = 0;
		exec( sprintf( 'cd %s && unzip -qo %s 2>&1', escapeshellarg( $plantio ), escapeshellarg( $zip_da_reserva ) ), $saida_unzip, $codigo_unzip );

		$pastas = array_values( array_filter( glob( $plantio . '/*' ) ?: array(), 'is_dir' ) );

		if ( 0 !== $codigo_unzip || 1 !== count( $pastas ) ) {
			f3b_sr_apagar( $plantio );

			return array( 'erro' => 'árvore prosa: a reserva não extraiu numa pasta de topo única (' . implode( ' | ', array_slice( $saida_unzip, 0, 2 ) ) . ')' );
		}

		$pasta = basename( (string) $pastas[0] );

		$nua_do_template = (string) ( f3b_np_grafias_nuas( $destino )[0] ?? '' );

		if ( '' === $nua_do_template ) {
			f3b_sr_apagar( $plantio );

			return array( 'erro' => 'árvore prosa: ferramentas/prefixo-do-template.tsv não declara o prefixo, e sem ele o plantio não tem grafia' );
		}

		file_put_contents(
			$plantio . '/' . $pasta . '/includes/plantado-pela-sonda.php',
			"<?php\n/**\n * Plantio da sonda: " . $nua_do_template . "_so_na_prosa aparece SÓ aqui, num comentário.\n */\n\$plantado = '" . $nua_do_template . "_so_no_codigo';\n"
		);

		unlink( $zip_da_reserva );

		$saida_zip  = array();
		$codigo_zip = 0;
		exec( sprintf( 'cd %s && zip -qr %s %s 2>&1', escapeshellarg( $plantio ), escapeshellarg( $zip_da_reserva ), escapeshellarg( $pasta ) ), $saida_zip, $codigo_zip );

		f3b_sr_apagar( $plantio );

		if ( 0 !== $codigo_zip || ! is_file( $zip_da_reserva ) ) {
			return array( 'erro' => 'árvore prosa: a reserva plantada não pôde ser remontada (' . implode( ' | ', array_slice( $saida_zip, 0, 2 ) ) . ')' );
		}

		file_put_contents( $destino . '/implantador-base.php', "\n/* plantio da sonda: " . $nua_do_template . "_so_na_prosa " . $nua_do_template . "_so_no_codigo */\n", FILE_APPEND );
	}

	$antes = f3b_sr_impressao( $destino, array( 'partilhado', 'assets/plugins' ) );

	$saida  = array();
	$codigo = 0;
	exec( 'php ' . escapeshellarg( $ferramenta ) . ' ' . escapeshellarg( $destino ) . ' acme 2>&1', $saida, $codigo );

	if ( 0 !== $codigo ) {
		return array( 'erro' => 'a renomeação saiu com código ' . $codigo . ': ' . implode( ' | ', array_slice( $saida, 0, 3 ) ) );
	}

	$depois = f3b_sr_impressao( $destino, array( 'partilhado', 'assets/plugins' ) );

	/*
	 * A RENOMEAÇÃO PRECISA TER ACONTECIDO. Sem esta contagem, uma ferramenta
	 * que não renomeasse NADA passaria nas duas linhas — o plugin ficaria
	 * intacto por não ter havido renomeação nenhuma, e a seção continuaria
	 * medida pelo mesmo motivo. É o teto do teto.
	 */
	$renomeou = 0;

	foreach ( $saida as $linha ) {
		if ( 1 === preg_match( '/arquivos com conteúdo reescrito: (\d+)/u', $linha, $achou ) ) {
			$renomeou = (int) $achou[1];
		}
	}

	$principal = (string) @file_get_contents( $destino . '/implantador-base.php' );
	$plantio   = 1 === preg_match( '/plantio da sonda: (\S+) (\S+)/', $principal, $achou ) ? array( $achou[1], $achou[2] ) : array();

	return array(
		'erro'     => '',
		'antes'    => $antes,
		'depois'   => $depois,
		'renomeou' => $renomeou,
		'classes'  => f3b_sr_classes_de_secao( $destino ),
		'prefixo'  => f3b_sr_prefixo_de_secao( $destino ),
		'destino'  => $destino,
		'plantio'  => $plantio,
	);
}

/**
 * As grafias declaradas no contrato de nomes do plugin.
 *
 * @param string $raiz Raiz.
 * @return array<int,string>
 */
function f3b_sr_contrato( string $raiz ): array {
	$saida = array();

	foreach ( explode( "\n", (string) @file_get_contents( $raiz . '/partilhado/dados/contrato-de-nomes.tsv' ) ) as $linha ) {
		$linha = rtrim( $linha, "\r" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$colunas = explode( "\t", $linha );
		$grafia  = trim( $colunas[1] ?? '' );

		if ( '' !== $grafia ) {
			$saida[] = $grafia;
		}
	}

	return array_values( array_unique( $saida ) );
}

/**
 * O QUE O CONTRATO PRECISA COBRIR, lido das declarações que já existem.
 *
 * Nada aqui é escrito à mão: as options saem do catálogo do próprio plugin, os
 * eventos saem da declaração de comportamento e o prefixo de seção sai da
 * constante do módulo que o publica. É o que impede a tabela de envelhecer —
 * uma lista escrita à mão que ninguém confere fica para trás na primeira option
 * nova, e o defeito volta calado exatamente onde ele estava.
 *
 * @param string $raiz Raiz.
 * @return array<string,string> grafia => de onde ela veio.
 */
function f3b_sr_exigido_pelo_contrato( string $raiz ): array {
	$exigido = array();

	$catalogo = f3b_fonte_do_plugin( $raiz, 'includes/class-f3base-options.php' );
	$ini      = strpos( $catalogo, 'public static function catalogo()' );

	if ( false !== $ini && preg_match_all( "/^\t{3}'(f3base_[a-z0-9_]+)'\s*=>/m", substr( $catalogo, $ini ), $achou ) ) {
		foreach ( $achou[1] as $option ) {
			$exigido[ $option ] = 'catálogo de options do plugin';
		}
	}

	foreach ( explode( "\n", f3b_fonte_do_plugin( $raiz, 'dados/eventos-comportamento.tsv' ) ) as $linha ) {
		$linha = rtrim( $linha, "\r" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$nome = trim( explode( "\t", $linha )[0] ?? '' );

		if ( '' !== $nome ) {
			$exigido[ $nome ] = 'declaração de eventos de comportamento';
		}
	}

	$prefixo = f3b_sr_prefixo_de_secao( $raiz );

	if ( '' !== $prefixo ) {
		$exigido[ $prefixo ] = 'constante PREFIXO_SECAO do módulo de tracking';
	}

	return $exigido;
}

/**
 * REGRA PURA: o que o contrato exige e não declara.
 *
 * @param array<string,string> $exigido  Grafia => origem.
 * @param array<int,string>    $contrato Grafias declaradas.
 * @return array<int,string>
 */
function f3b_sr_faltando( array $exigido, array $contrato ): array {
	$achados = array();

	foreach ( $exigido as $grafia => $origem ) {
		if ( ! in_array( (string) $grafia, $contrato, true ) ) {
			$achados[] = '"' . $grafia . '" vem de ' . $origem . ' e NÃO consta de partilhado/dados/contrato-de-nomes.tsv: '
				. 'a renomeação de prefixo vai reescrevê-la do lado de quem grava e não do lado de quem lê, e o site fica com o implantador escrevendo '
				. 'um nome e o plugin lendo outro — sem erro nenhum';
		}
	}

	return $achados;
}

/* =========================================================================
 * EXECUÇÃO
 * ====================================================================== */

$veredito = array(
	'renomeacao.plugin_intacto'             => array( 'achados' => array(), 'medidas' => 0 ),
	'renomeacao.secao_medida_apos_renomear' => array( 'achados' => array(), 'medidas' => 0 ),
	'renomeacao.contrato_de_nomes_completo' => array( 'achados' => array(), 'medidas' => 0 ),
	'renomeacao.preservados_so_do_codigo'   => array( 'achados' => array(), 'medidas' => 0 ),
);

/*
 * ESTE PACOTE É O TEMPLATE? A pergunta é a mesma de
 * `estatica.sem_residuo_de_prefixo`, e a resposta muda o que se pode exigir da
 * renomeação: sobre o template ela TEM de acontecer; sobre um pacote já
 * renomeado ela é um no-op declarado, que é a idempotência da ferramenta.
 */
$config_do_pacote = json_decode( (string) @file_get_contents( $raiz . '/config/site.json' ), true );
$prefixo_atual    = is_array( $config_do_pacote ) ? trim( (string) ( $config_do_pacote['site']['prefixo_tecnico'] ?? '' ) ) : '';
$prefixo_origem   = '';

foreach ( explode( "\n", (string) @file_get_contents( $raiz . '/ferramentas/prefixo-do-template.tsv' ) ) as $linha_do_prefixo ) {
	$colunas_do_prefixo = explode( "\t", rtrim( $linha_do_prefixo, "\r" ) );

	if ( 'tecnico' === trim( $colunas_do_prefixo[0] ?? '' ) ) {
		$prefixo_origem = trim( $colunas_do_prefixo[1] ?? '' );
	}
}

$e_o_template = '' !== $prefixo_origem && $prefixo_atual === $prefixo_origem;

/* ---- O CONTRATO COBRE O QUE AS DECLARAÇÕES EXIGEM ---- */
$exigido  = f3b_sr_exigido_pelo_contrato( $raiz );
$contrato = f3b_sr_contrato( $raiz );

$veredito['renomeacao.contrato_de_nomes_completo']['medidas'] = count( $exigido );

if ( array() === $exigido ) {
	$veredito['renomeacao.contrato_de_nomes_completo']['achados'][] = 'não foi possível ler nem o catálogo de options nem a declaração de eventos do plugin: '
		. 'sem elas esta linha não tem contra o que conferir o contrato, e escopo vazio não pode aprovar';
} else {
	foreach ( f3b_sr_faltando( $exigido, $contrato ) as $achado ) {
		$veredito['renomeacao.contrato_de_nomes_completo']['achados'][] = $achado;
	}

	/* PISO: a MESMA função, contra um contrato de onde uma grafia foi tirada. */
	$mutilado = array_values( array_diff( $contrato, array( (string) array_key_first( $exigido ) ) ) );

	if ( array() === f3b_sr_faltando( $exigido, $mutilado ) ) {
		$veredito['renomeacao.contrato_de_nomes_completo']['achados'][] = 'piso cego: removida do contrato a grafia "' . (string) array_key_first( $exigido )
			. '", que o catálogo exige, a regra continuou em silêncio';
	}

	++$veredito['renomeacao.contrato_de_nomes_completo']['medidas'];
}

$base = sys_get_temp_dir() . '/f3b-renomeacao-' . getmypid();

f3b_sr_apagar( $base );

$fiel         = f3b_sr_rodada( $raiz, $suite, $base . '/fiel', 'fiel' );
$sem_exclusao = f3b_sr_rodada( $raiz, $suite, $base . '/sem-exclusao', 'sem-exclusao' );
$sem_contrato = f3b_sr_rodada( $raiz, $suite, $base . '/sem-contrato', 'sem-contrato' );
$prosa        = f3b_sr_rodada( $raiz, $suite, $base . '/prosa', 'prosa' );

if ( '' !== (string) ( $fiel['erro'] ?? '' ) ) {
	$veredito['renomeacao.plugin_intacto']['achados'][]             = 'árvore fiel: ' . $fiel['erro'];
	$veredito['renomeacao.secao_medida_apos_renomear']['achados'][] = 'árvore fiel: ' . $fiel['erro'];
} else {
	/* ---- TETO: o plugin não mudou ---- */
	$veredito['renomeacao.plugin_intacto']['medidas'] = count( $fiel['antes'] );

	if ( array() === $fiel['antes'] ) {
		$veredito['renomeacao.plugin_intacto']['achados'][] = 'teto: a árvore copiada não tem partilhado/ nem assets/plugins/: sem a cópia vendorizada e sem a reserva do plugin não há o que medir, e escopo vazio não pode fechar OK';
	}

	/*
	 * A EXIGÊNCIA DE QUE A RENOMEAÇÃO TENHA ACONTECIDO SÓ VALE SOBRE O TEMPLATE.
	 *
	 * Sem ela, uma ferramenta que não renomeasse NADA passaria nesta linha — o
	 * plugin ficaria intacto por não ter havido renomeação nenhuma. Com ela e
	 * sem esta condição, a linha reprovaria todo pacote JÁ RENOMEADO, e reprovaria
	 * por causa da idempotência que a ferramenta promete: a busca é sempre pelo
	 * prefixo de ORIGEM, e num pacote que já trocou de prefixo a segunda rodada
	 * não encontra nada de propósito. A condição é a mesma de
	 * `estatica.sem_residuo_de_prefixo`, e é lida do mesmo lugar.
	 */
	if ( $e_o_template && 1 > (int) ( $fiel['renomeou'] ?? 0 ) ) {
		$veredito['renomeacao.plugin_intacto']['achados'][] = 'teto: a renomeação não reescreveu arquivo nenhum fora do plugin: o plugin ficou intacto porque NADA foi renomeado, e isso não prova a exclusão — prova só que a ferramenta não fez nada';
	}

	foreach ( $fiel['antes'] as $rel => $hash ) {
		if ( ! isset( $fiel['depois'][ $rel ] ) ) {
			$veredito['renomeacao.plugin_intacto']['achados'][] = $rel . ': o arquivo do plugin SUMIU depois da renomeação (o caminho foi reescrito). Um site cujo plugin foi renomeado tem options que nenhuma release alcança: o implantador grava <prefixo>_ga4_measurement_id e nenhuma correção publicada de base-site-core-fator3 chega lá';
			continue;
		}

		if ( $fiel['depois'][ $rel ] !== $hash ) {
			$veredito['renomeacao.plugin_intacto']['achados'][] = $rel . ': o CONTEÚDO do arquivo do plugin mudou na renomeação. O plugin é um artefato único instalado em todos os sites desta operação; um site com o conteúdo dele reescrito roda um FORK que nenhuma release alcança';
		}
	}

	foreach ( array_keys( $fiel['depois'] ) as $rel ) {
		if ( ! isset( $fiel['antes'][ $rel ] ) ) {
			$veredito['renomeacao.plugin_intacto']['achados'][] = $rel . ': apareceu dentro do plugin depois da renomeação — é o outro lado do caminho reescrito, e o autoload do plugin procura o nome antigo';
		}
	}

	/* ---- TETO: a seção continua sendo medida ---- */
	$classes = (array) ( $fiel['classes'] ?? array() );
	$prefixo = (string) ( $fiel['prefixo'] ?? '' );

	$veredito['renomeacao.secao_medida_apos_renomear']['medidas'] = count( $classes );

	if ( '' === $prefixo ) {
		$veredito['renomeacao.secao_medida_apos_renomear']['achados'][] = 'não foi possível ler PREFIXO_SECAO do módulo de tracking na árvore renomeada: sem ele não há contra o que medir a classe carimbada';
	} elseif ( array() === $classes ) {
		$veredito['renomeacao.secao_medida_apos_renomear']['achados'][] = 'nenhuma classe de seção foi encontrada nos patterns do tema nem no conteúdo depois da renomeação: sem alvo o observador não mede nada, e uma medição sem alvo não pode fechar OK';
	} else {
		$medidos = f3b_sr_nomes_medidos( $base . '/fiel', $suite, $prefixo, $classes );

		if ( ! $medidos['ok'] ) {
			$veredito['renomeacao.secao_medida_apos_renomear']['achados'][] = $medidos['erro'];
		} else {
			foreach ( $classes as $classe => $onde ) {
				$nome = (string) ( $medidos['nomes'][ $classe ] ?? '' );

				if ( '' === $nome ) {
					$veredito['renomeacao.secao_medida_apos_renomear']['achados'][] = $onde . ': depois de renomear para "acme", a classe "' . $classe
						. '" NÃO é reconhecida pelo coletor, que procura "' . $prefixo . '". A seção deixa de ser medida sem nenhum erro: o observador é instalado, '
						. 'não recebe alvo, e o evento f3base_secao_vista responde "nada" para sempre na conta de medição do site';
				}
			}
		}
	}
}

/* ---- PISO 1: sem as exclusões de caminho, o plugin PRECISA mudar ---- */
++$veredito['renomeacao.plugin_intacto']['medidas'];

if ( '' !== (string) ( $sem_exclusao['erro'] ?? '' ) ) {
	$veredito['renomeacao.plugin_intacto']['achados'][] = 'piso: a árvore sem-exclusao não pôde ser renomeada (' . $sem_exclusao['erro'] . '), e sem ela esta linha não provou saber reprovar';
} else {
	$mexeu = false;

	foreach ( $sem_exclusao['antes'] as $rel => $hash ) {
		if ( ! isset( $sem_exclusao['depois'][ $rel ] ) || $sem_exclusao['depois'][ $rel ] !== $hash ) {
			$mexeu = true;
			break;
		}
	}

	if ( ! $mexeu ) {
		$veredito['renomeacao.plugin_intacto']['achados'][] = 'piso cego: com as duas exclusões de caminho removidas — que é a 1.6.6 — a renomeação continuou deixando o plugin intacto. '
			. 'Ou a exclusão não é o que segura o plugin, ou esta medição não enxerga o que afirma enxergar';
	}
}

/* ---- PISO 2: sem o contrato de nomes, a seção PRECISA deixar de ser medida ---- */
++$veredito['renomeacao.secao_medida_apos_renomear']['medidas'];

if ( '' !== (string) ( $sem_contrato['erro'] ?? '' ) ) {
	$veredito['renomeacao.secao_medida_apos_renomear']['achados'][] = 'piso: a árvore sem-contrato não pôde ser renomeada (' . $sem_contrato['erro'] . '), e sem ela esta linha não provou saber reprovar';
} else {
	$classes_m = (array) ( $sem_contrato['classes'] ?? array() );
	$prefixo_m = (string) ( $sem_contrato['prefixo'] ?? '' );
	$orfas     = 0;

	if ( '' !== $prefixo_m && array() !== $classes_m ) {
		$medidos_m = f3b_sr_nomes_medidos( $base . '/sem-contrato', $suite, $prefixo_m, $classes_m );

		if ( $medidos_m['ok'] ) {
			foreach ( array_keys( $classes_m ) as $classe ) {
				if ( '' === (string) ( $medidos_m['nomes'][ $classe ] ?? '' ) ) {
					$orfas++;
				}
			}
		}
	}

	if ( 1 > $orfas ) {
		$veredito['renomeacao.secao_medida_apos_renomear']['achados'][] = 'piso cego: com o contrato de nomes do plugin apagado — a exclusão de caminho SOZINHA —, todas as classes de seção continuaram sendo reconhecidas pelo coletor. '
			. 'O defeito plantado é o tema carimbar "acme-secao-" enquanto o plugin continua procurando "' . $prefixo_m . '"; se ele não aparece, esta medição não está medindo isso';
	}
}

/* ---- PRESERVADA É A GRAFIA QUE O CÓDIGO DO PLUGIN USA, nunca a que a prosa dele cita ---- */
$rotulo_prosa = 'renomeacao.preservados_so_do_codigo';
$nuas_prosa   = f3b_np_grafias_nuas( $raiz );

/*
 * AS AMOSTRAS SÃO MONTADAS DO PREFIXO DECLARADO, e não digitadas: este arquivo
 * também é renomeado quando o pacote é, e uma amostra digitada com o prefixo
 * do template viraria amostra com o prefixo do site enquanto a derivação
 * continuaria procurando o do template (ferramentas/prefixo-do-template.tsv é
 * exceção declarada e não muda). O plantio de ponta a ponta usa o mesmo nome.
 */
$nua_prosa = (string) ( $nuas_prosa[0] ?? '' );
$com_nua   = static fn( string $sufixo ): string => $nua_prosa . $sufixo;

if ( '' === $nua_prosa ) {
	$veredito[ $rotulo_prosa ]['achados'][] = 'ferramentas/prefixo-do-template.tsv não declara o prefixo do template, e sem ele não há grafia nua para derivar';
}

/* TETO 1, a regra pura: o que de cada tipo de arquivo conta como código. */
$amostras = array(
	'php: docblock e comentário de linha caem, string e identificador ficam' => array(
		'x.php',
		"<?php\n/** " . $com_nua( '_no_docblock' ) . " */\n// " . $com_nua( '_na_linha' ) . "\n# " . $com_nua( '_no_cerquilha' ) . "\n\$a = '" . $com_nua( '_na_string' ) . "'; function " . $com_nua( '_na_funcao' ) . "() {}\n",
		array( $com_nua( '_na_string' ), $com_nua( '_na_funcao' ) ),
		array( $com_nua( '_no_docblock' ), $com_nua( '_na_linha' ), $com_nua( '_no_cerquilha' ) ),
	),
	'js: bloco e linha de comentário caem, código fica' => array(
		'x.js',
		"/* " . $com_nua( '_no_bloco' ) . " */\n// " . $com_nua( '_na_linha' ) . "\nconst a = '" . $com_nua( '_no_codigo' ) . "'; // " . $com_nua( '_no_fim_da_linha_fica' ) . "\n",
		array( $com_nua( '_no_codigo' ), $com_nua( '_no_fim_da_linha_fica' ) ),
		array( $com_nua( '_no_bloco' ), $com_nua( '_na_linha' ) ),
	),
	'css: bloco de comentário cai, seletor fica' => array(
		'x.css',
		"/* ." . $com_nua( '-no-comentario' ) . " */\n." . $com_nua( '-no-seletor' ) . " { display: none; }\n",
		array( $com_nua( '-no-seletor' ) ),
		array( $com_nua( '-no-comentario' ) ),
	),
	'tsv: linha de cerquilha cai, linha de dados fica' => array(
		'x.tsv',
		"# option\t" . $com_nua( '_no_comentario' ) . "\tmotivo\noption\t" . $com_nua( '_na_linha_de_dados' ) . "\tmotivo\n",
		array( $com_nua( '_na_linha_de_dados' ) ),
		array( $com_nua( '_no_comentario' ) ),
	),
	'md: nada entra' => array(
		'LEIA.md',
		"# " . $com_nua( '_no_titulo' ) . "\n`" . $com_nua( '_no_codigo_inline' ) . "` e " . $com_nua( '_no_texto' ) . "\n",
		array(),
		array( $com_nua( '_no_titulo' ), $com_nua( '_no_codigo_inline' ), $com_nua( '_no_texto' ) ),
	),
);

foreach ( $amostras as $caso => list( $nome_amostra, $bruto_amostra, $ficam, $caem ) ) {
	++$veredito[ $rotulo_prosa ]['medidas'];

	$grafias = f3b_np_grafias_do_texto( f3b_np_texto_de_codigo( $nome_amostra, $bruto_amostra ), $nuas_prosa );

	foreach ( $ficam as $grafia ) {
		if ( ! in_array( $grafia, $grafias, true ) ) {
			$veredito[ $rotulo_prosa ]['achados'][] = 'teto (' . $caso . '): a grafia do CÓDIGO "' . $grafia . '" não foi derivada — o plugin a usa e a renomeação a reescreveria do lado de quem grava';
		}
	}

	foreach ( $caem as $grafia ) {
		if ( in_array( $grafia, $grafias, true ) ) {
			$veredito[ $rotulo_prosa ]['achados'][] = 'teto (' . $caso . '): a grafia da PROSA "' . $grafia . '" foi derivada — ninguém a usa, alguém falou dela, e ela sobreviveria à renomeação';
		}
	}

	/* PISO da regra pura: a MESMA varredura sobre o texto SEM o corte é o comportamento antigo, e ele PRECISA capturar a prosa. */
	$sem_corte = f3b_np_grafias_do_texto( $bruto_amostra, $nuas_prosa );

	foreach ( $caem as $grafia ) {
		if ( ! in_array( $grafia, $sem_corte, true ) ) {
			$veredito[ $rotulo_prosa ]['achados'][] = 'piso cego (' . $caso . '): sem o corte de prosa a varredura NÃO capturou "' . $grafia . '" — então o corte não está provando nada, porque a grafia não seria preservada de qualquer jeito';
		}
	}
}

/* TETO 2, de ponta a ponta: a árvore com o plantio, renomeada de verdade. */
++$veredito[ $rotulo_prosa ]['medidas'];

if ( '' !== (string) ( $prosa['erro'] ?? '' ) ) {
	$veredito[ $rotulo_prosa ]['achados'][] = 'árvore prosa: ' . $prosa['erro'];
} else {
	$plantio = (array) ( $prosa['plantio'] ?? array() );

	if ( 2 !== count( $plantio ) ) {
		$veredito[ $rotulo_prosa ]['achados'][] = 'teto de ponta a ponta: a linha plantada no arquivo principal não foi encontrada depois da renomeação, e sem ela esta medição não mediu nada';
	} else {
		if ( 'acme_so_na_prosa' !== $plantio[0] ) {
			$veredito[ $rotulo_prosa ]['achados'][] = 'teto de ponta a ponta: a grafia que o plugin cita SÓ EM PROSA saiu da renomeação como "' . $plantio[0] . '" e devia ter virado "acme_so_na_prosa" — é o defeito das seis options de estado do implantador (lock, checkpoint, journal, estado_aplicacao, release, fases) sobrevivendo com o prefixo do template no site renomeado';
		}

		if ( $com_nua( '_so_no_codigo' ) !== $plantio[1] ) {
			$veredito[ $rotulo_prosa ]['achados'][] = 'teto de ponta a ponta: a grafia que o plugin usa NO CÓDIGO saiu da renomeação como "' . $plantio[1] . '" e devia ter ficado "' . $com_nua( '_so_no_codigo' ) . '" — o implantador renomeado gravaria um nome enquanto o plugin lê outro';
		}
	}

	/* O plantio não pode ter mexido no que as outras linhas medem: a árvore fiel é outra cópia. */
	if ( array() !== $fiel && '' === (string) ( $fiel['erro'] ?? '' ) && array() !== (array) ( $fiel['plantio'] ?? array() ) ) {
		$veredito[ $rotulo_prosa ]['achados'][] = 'a árvore FIEL carrega o plantio da sonda: as cópias se contaminaram e as linhas de plugin_intacto não mediram a árvore que dizem medir';
	}
}

f3b_sr_apagar( $base );

echo (string) json_encode( $veredito, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
