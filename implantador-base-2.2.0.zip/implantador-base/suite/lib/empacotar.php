<?php
/**
 * Empacotamento — PRIMEIRA ETAPA do comando único, sempre.
 *
 * Verificar sem empacotar já aprovou um pacote que não montava: o build é a
 * primeira coisa que roda, e um arquivo fora do inventário ABORTA a rodada com
 * o nome do arquivo, antes de qualquer checagem.
 *
 * A allow-list é de CAMINHOS, não de extensões. Filtro por extensão já publicou
 * sonda de depuração dentro de um tema e já aprovou um pacote que continha uma
 * cópia inteira de si mesmo: as extensões estavam certas e os caminhos não.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Inventário declarado: caminho relativo → papel.
 *
 * Linha terminada em `/` é PREFIXO declarado (diretório inteiro, com o papel
 * escrito). Todo o resto é caminho exato.
 *
 * @param string $suite Diretório da suíte.
 * @return array{exatos:array<string,string>,prefixos:array<string,string>}
 */
function f3b_inventario( string $suite ): array {
	$exatos   = array();
	$prefixos = array();

	foreach ( f3b_tsv( $suite . '/inventario.tsv' ) as $linha ) {
		$caminho = trim( $linha[0] ?? '' );
		$papel   = trim( $linha[1] ?? '' );

		if ( '' === $caminho ) {
			continue;
		}

		if ( str_ends_with( $caminho, '/' ) ) {
			$prefixos[ $caminho ] = $papel;
			continue;
		}

		$exatos[ $caminho ] = $papel;
	}

	return array(
		'exatos'   => $exatos,
		'prefixos' => $prefixos,
	);
}

/**
 * Caminhos que a PRÓPRIA RODADA produz dentro do pacote.
 *
 * Eles constam do inventário (têm papel declarado, entram no bundle e viajam
 * com ele), mas a rodada que os grava só os grava no FIM — depois das
 * checagens. Cobrar a presença deles ANTES do selo faria um clone limpo
 * reprovar na primeira execução por um arquivo que aquela execução ainda vai
 * escrever. O que cobra a presença deles no artefato ENTREGUE é
 * `entrega.rodada_limpa`, no host, que é onde a ausência importa.
 *
 * @return array<string,string> Caminho relativo => por que ele nasce na rodada.
 */
function f3b_produzidos_pela_rodada(): array {
	return array(
		'suite/rodada.json' => 'registro DA rodada: gravado pelo selo, no fim do comando único, com o veredito declarado, as pendências de fase nomeadas e o hash do pacote que esta rodada mediu',
		'suite/fases.json'  => 'registro DURÁVEL de fases: gravado no fim do comando único, com a data em que cada fase fechada rodou pela última vez. É ele que impede a regra de aplicabilidade da 1.1.6 de virar cegueira — sem ele, uma checagem em N/A por fase ausente ficaria em N/A para sempre e ninguém saberia que a fase nunca rodou',
	);
}

/**
 * Todo arquivo do pacote consta do inventário, com papel declarado.
 *
 * Acusa nos dois sentidos: arquivo em disco fora do inventário, e caminho
 * inventariado que não existe em disco. Papel vazio também é achado — um
 * inventário que lista o caminho e não diz para que ele serve não é allow-list,
 * é lista de arquivos.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_allow_list( string $raiz, string $suite ): array {
	$inv = f3b_inventario( $suite );

	if ( array() === $inv['exatos'] && array() === $inv['prefixos'] ) {
		return array(
			'ok'      => false,
			'achados' => array( 'suite/inventario.tsv vazio ou ausente — sem inventário não existe allow-list' ),
		);
	}

	$achados = array();
	$emdisco = f3b_arquivos( $raiz, array(), array( 'dist/' ) );

	foreach ( $emdisco as $rel ) {
		if ( isset( $inv['exatos'][ $rel ] ) ) {
			if ( '' === $inv['exatos'][ $rel ] ) {
				$achados[] = 'sem papel declarado: ' . $rel;
			}

			continue;
		}

		$coberto = false;

		foreach ( $inv['prefixos'] as $prefixo => $papel ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$coberto = true;

				if ( '' === $papel ) {
					$achados[] = 'sem papel declarado no prefixo ' . $prefixo . ': ' . $rel;
				}

				break;
			}
		}

		if ( ! $coberto ) {
			$achados[] = 'FORA DO INVENTÁRIO: ' . $rel;
		}
	}

	$produzidos = f3b_produzidos_pela_rodada();

	foreach ( $inv['exatos'] as $rel => $papel ) {
		unset( $papel );

		if ( in_array( $rel, $emdisco, true ) ) {
			continue;
		}

		if ( isset( $produzidos[ $rel ] ) ) {
			/* Ausente porque esta rodada ainda não o gravou — e quem o grava é ela. */
			continue;
		}

		$achados[] = 'inventariado e ausente em disco: ' . $rel;
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
	);
}

/**
 * Fontes do pacote, sem a saída de build.
 *
 * É a árvore INTEIRA do repositório, e é ela que `pacote.build_fresco` compara
 * contra o artefato: trocar a reserva do plugin ou um arquivo de `partilhado/`
 * sem reempacotar precisa deixar o build velho.
 *
 * @param string $raiz Raiz.
 * @return array<int,string>
 */
function f3b_fontes( string $raiz ): array {
	return f3b_arquivos( $raiz, array(), array( 'dist/' ) );
}

/**
 * O QUE FICA NO REPOSITÓRIO E NÃO VIAJA DENTRO DO BUNDLE, com o motivo.
 *
 * Lista declarada, e não um `if` no meio da cópia: o que entra e o que não
 * entra no artefato entregue é decisão de pacote, e decisão de pacote deste
 * repositório mora em arquivo ou em função nomeada, com o motivo ao lado.
 *
 * DESDE A 2.0.0 A LISTA É VAZIA, e o vazio é a decisão. Da 1.7.0 à 1.7.4 ela
 * tinha uma entrada — `fontes/plugin/`, a fonte do plugin, que morava aqui e
 * não podia viajar. A fonte foi embora para o repositório do plugin, e o que
 * sobrou dela nesta árvore é o que VIAJA de propósito: a reserva
 * `assets/plugins/<slug>-<versão>.zip`, que é o zip publicado copiado como
 * entrada de build, e `partilhado/`, a cópia vendorizada conferida por hash
 * contra ele. A árvore de origem e o corpo do bundle passaram a ser a mesma
 * coisa, menos `dist/`. A função fica porque a decisão precisa ter endereço:
 * quem quiser voltar a deixar algo de fora escreve aqui, com o motivo.
 *
 * @return array<string,string> Prefixo => motivo.
 */
function f3b_fora_do_bundle(): array {
	return array();
}

/**
 * O CORPO DO BUNDLE: as fontes menos o que não viaja.
 *
 * @param string $raiz Raiz.
 * @return array<int,string>
 */
function f3b_corpo_do_bundle( string $raiz ): array {
	$fora  = array_keys( f3b_fora_do_bundle() );
	$saida = array();

	foreach ( f3b_fontes( $raiz ) as $rel ) {
		$pula = false;

		foreach ( $fora as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$pula = true;
				break;
			}
		}

		if ( ! $pula ) {
			$saida[] = $rel;
		}
	}

	return $saida;
}

/**
 * Artefato de build mais novo que toda fonte.
 *
 * Artefato mais velho que a fonte é o defeito silencioso do empacotamento: o
 * zip existe, o nome está certo, e o conteúdo é de antes da última mudança.
 *
 * @param string $artefato Caminho do artefato.
 * @param string $raiz     Raiz das fontes.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_build_fresco( string $artefato, string $raiz ): array {
	if ( ! is_file( $artefato ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'artefato de build ausente: ' . $artefato ),
		);
	}

	clearstatcache();

	$data_artefato = (int) filemtime( $artefato );
	$achados       = array();

	foreach ( f3b_fontes( $raiz ) as $rel ) {
		$data_fonte = (int) filemtime( $raiz . '/' . $rel );

		if ( $data_fonte > $data_artefato ) {
			$achados[] = sprintf(
				'%s (%s) é mais novo que %s (%s)',
				$rel,
				gmdate( 'Y-m-d H:i:s', $data_fonte ),
				basename( $artefato ),
				gmdate( 'Y-m-d H:i:s', $data_artefato )
			);
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
	);
}

/**
 * Cabeçalho de plugin ao ALCANCE de `get_plugins()`, fora do arquivo principal.
 *
 * O defeito medido, e ele é determinístico: `get_plugins( '/implantador-base' )`
 * varre a raiz do plugin E UM NÍVEL de subdiretório. Com a fonte do plugin
 * morando em `site-core/f3base-site-core.php` — o nome que ela tinha quando o
 * defeito foi medido —, aquela varredura enxergava DOIS arquivos
 * com `Plugin Name:` — "Implantador Base F3" e "F3 Base Site Core". Ela ordena
 * por Name, "F3 Base Site Core" vem antes, `Plugin_Upgrader::plugin_info()`
 * devolve `array_keys(...)[0]`, e o link "Ativar plugin" da tela de instalação
 * carregava `implantador-base/site-core/f3base-site-core.php`. Aí
 * `validate_plugin()` chama o `get_plugins()` COMPLETO, que só enxerga um nível
 * a partir de `wp-content/plugins/`, não acha um caminho de dois níveis e
 * devolve exatamente "The plugin does not have a valid header." — ativar pela
 * lista de plugins funcionava, porque ali o link é o arquivo principal.
 *
 * A REGRA SOBREVIVEU À TROCA DE NOME, e é por isso que ela continua aqui na
 * 1.7.0: a fonte do plugin passou a se chamar `fontes/plugin/`, e o que NÃO
 * pode mudar é a PROFUNDIDADE. Um `Plugin Name:` a um nível da raiz do pacote
 * reproduz o mesmo empate de ordenação com qualquer nome — é o alcance de
 * `get_plugins()` que decide, não o nome do diretório.
 *
 * A checagem tem PISO DOS DOIS LADOS:
 *
 * - a raiz precisa ter EXATAMENTE UM arquivo com `Plugin Name:` (zero significa
 *   pacote sem ponto de entrada; mais de um reproduz o mesmo empate de ordenação
 *   dentro da própria raiz);
 * - NENHUM `.php` a um nível de subdiretório pode ter `Plugin Name:`.
 *
 * O casamento imita o do núcleo: só os primeiros 8 KiB do arquivo, e o prefixo
 * de comentário que `get_file_data()` tolera.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_cabecalho_aninhado( string $raiz ): array {
	$raiz = rtrim( $raiz, '/' );

	/**
	 * O arquivo declara `Plugin Name:` onde o núcleo procuraria?
	 *
	 * @param string $caminho Caminho absoluto.
	 * @return bool
	 */
	$tem_cabecalho = static function ( string $caminho ): bool {
		$fp = fopen( $caminho, 'r' );

		if ( false === $fp ) {
			return false;
		}

		/* `get_file_data()` do núcleo lê 8 KiB e para; um cabeçalho depois disso não é cabeçalho. */
		$trecho = (string) fread( $fp, 8192 );
		fclose( $fp );

		$trecho = str_replace( "\r", "\n", $trecho );

		return 1 === preg_match( '/^[ \t\/*#@]*Plugin Name:/mi', $trecho );
	};

	$achados = array();
	$medidas = 0;
	$na_raiz = array();

	foreach ( glob( $raiz . '/*.php' ) ?: array() as $caminho ) {
		if ( ! is_file( $caminho ) ) {
			continue;
		}

		$medidas++;

		if ( $tem_cabecalho( $caminho ) ) {
			$na_raiz[] = basename( $caminho );
		}
	}

	foreach ( glob( $raiz . '/*/*.php' ) ?: array() as $caminho ) {
		if ( ! is_file( $caminho ) ) {
			continue;
		}

		$rel  = ltrim( substr( $caminho, strlen( $raiz ) ), '/' );
		$pula = false;

		foreach ( f3b_excluidos() as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$pula = true;
				break;
			}
		}

		if ( $pula ) {
			continue;
		}

		$medidas++;

		if ( ! $tem_cabecalho( $caminho ) ) {
			continue;
		}

		$achados[] = sprintf(
			'%s tem "Plugin Name:" a UM nível da raiz, dentro do alcance de get_plugins(): '
				. 'a tela de instalação ordena por Name, pode escolher este arquivo como principal e o link '
				. '"Ativar plugin" apontaria para <pasta-do-plugin>/%s — um caminho de dois níveis que '
				. 'validate_plugin() não enxerga, e a ativação devolveria "The plugin does not have a valid header." '
				. 'Mova a fonte para mais um nível abaixo (fontes/).',
			$rel,
			$rel
		);
	}

	if ( 1 !== count( $na_raiz ) ) {
		$achados[] = sprintf(
			'a raiz do pacote precisa ter EXATAMENTE UM .php com "Plugin Name:" e tem %d (%s): '
				. 'zero deixa o pacote sem arquivo principal, e mais de um reproduz na própria raiz '
				. 'o empate de ordenação que faz o link "Ativar plugin" apontar para o arquivo errado.',
			count( $na_raiz ),
			array() === $na_raiz ? 'nenhum' : implode( ', ', $na_raiz )
		);
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Caminho de backup construído SEM o ponto na frente.
 *
 * O corolário que o método exige. A correção do órfão foi pontual — dois lugares
 * que montavam `<destino>-f3base-anterior-<ts>` passaram a montar
 * `.f3base-anterior-<slug>-<ts>` — e correção pontual não impede a terceira
 * reintrodução. `get_plugins()` pula todo diretório cujo nome começa com ponto;
 * um backup sem ponto volta a aparecer na tela de plugins do usuário como uma
 * segunda cópia instalável do mesmo plugin, com a mesma versão e a mesma
 * descrição.
 *
 * O detector separa CONSTRUÇÃO de RECONHECIMENTO, e a distinção é a parte que
 * faz ele valer: um literal com a marca só é acusado quando é operando do
 * operador de concatenação `.` — ou seja, quando está montando um caminho.
 * Literal passado como argumento (`str_contains( $nome, '-f3base-anterior-' )`)
 * ou atribuído a uma constante é reconhecimento de nome antigo, que a migração
 * PRECISA fazer, e fica em silêncio. Comentário não conta: a varredura mede o
 * que executa.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_backup_sempre_oculto( string $raiz ): array {
	$marca   = 'f3base-anterior';
	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$medidas++;

		$tokens = token_get_all( f3b_codigo_php( $raiz . '/' . $rel ) );
		$total  = count( $tokens );

		foreach ( $tokens as $n => $token ) {
			if ( ! is_array( $token ) || T_CONSTANT_ENCAPSED_STRING !== $token[0] ) {
				continue;
			}

			if ( ! str_contains( $token[1], $marca ) ) {
				continue;
			}

			/* Vizinhos significativos, pulando espaço em branco. */
			$antes  = '';
			$depois = '';

			for ( $i = $n - 1; $i >= 0; $i-- ) {
				if ( is_array( $tokens[ $i ] ) && T_WHITESPACE === $tokens[ $i ][0] ) {
					continue;
				}

				$antes = is_array( $tokens[ $i ] ) ? $tokens[ $i ][1] : $tokens[ $i ];
				break;
			}

			for ( $i = $n + 1; $i < $total; $i++ ) {
				if ( is_array( $tokens[ $i ] ) && T_WHITESPACE === $tokens[ $i ][0] ) {
					continue;
				}

				$depois = is_array( $tokens[ $i ] ) ? $tokens[ $i ][1] : $tokens[ $i ];
				break;
			}

			$concatena = '.' === $antes || '.' === $depois || '.=' === $antes;

			if ( ! $concatena ) {
				continue;
			}

			$pos = strpos( $token[1], $marca );

			if ( false !== $pos && $pos > 0 && '.' === $token[1][ $pos - 1 ] ) {
				continue;
			}

			$achados[] = sprintf(
				'%s:%d monta caminho de backup com o literal %s, sem o ponto na frente da marca: '
					. 'get_plugins() só pula diretório cujo nome COMEÇA com ponto, e um backup sem ele '
					. 'reaparece na tela de plugins como uma segunda cópia instalável do mesmo plugin. '
					. 'Monte o caminho por F3Base_Imp_Plugins::caminho_do_backup(), que é o ponto único.',
				$rel,
				(int) $token[2],
				trim( $token[1] )
			);
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Remove um diretório inteiro.
 *
 * @param string $dir Diretório.
 * @return void
 */
function f3b_apagar( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	$itens = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $itens as $item ) {
		if ( $item->isDir() ) {
			rmdir( $item->getPathname() );
			continue;
		}

		unlink( $item->getPathname() );
	}

	rmdir( $dir );
}

/**
 * Monta o bundle: exatamente o que o inventário autoriza, e nada além.
 *
 * O QUE MUDOU NA 1.0.16, e por quê. Da 1.0.14 à 1.0.15 este empacotamento
 * montava dois zips a mais — `<tema>.zip` e `<site-core>.zip` — e os copiava
 * para a RAIZ do bundle. Nenhum caminho de instalação os abria:
 * `zip_embutido()` procura `assets/plugins/<slug>.zip` e `assets/<slug>.zip`, e
 * a fonte que o instalador de fato lia era `fontes/tema/` e `fontes/plugin/`,
 * que viajavam no bundle. Eram 104.021 bytes de peso morto dentro do hash do
 * pacote, servindo de prova falsa de entrega.
 *
 * Foram removidos, e não ligados ao instalador, por três razões medidas:
 *
 * 1. Segunda representação do mesmo artefato DERIVA. O zip é montado no
 *    empacotamento; o diretório é o que a instalação lê e o que
 *    `impressao_de_diretorio()` compara para pular a troca quando nada mudou.
 *    Com os dois no pacote, editar `fontes/` sem reempacotar deixaria o zip
 *    velho instalando código velho.
 * 2. Ligar os zips ao instalador moveria tema e site-core para
 *    `instalar_pacote()` (o upgrader do núcleo) no MESMO passo em que a
 *    1.0.16 corrige a leitura de volta de `trocar_diretorio()` — trocar de
 *    caminho no instante de consertar o outro.
 * 3. `trocar_diretorio()` continuaria sendo o caminho de `aplicar_embarcado()`,
 *    que tem o defeito idêntico. Rotear por fora deixaria o defeito vivo no
 *    terceiro chamador e ainda tiraria a cobertura que o pega.
 *
 * O slot `assets/plugins/<slug>.zip` continua existindo: ele é decisão
 * explícita do operador que monta o pacote, e `artefato_do_papel()` — a fonte
 * única — o lê antes de `fontes/`.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>,bundle:string,embutidos:array<int,string>}
 */
function f3b_empacotar( string $raiz, string $suite ): array {
	$config = f3b_config( $raiz );
	$versao = is_array( $config ) ? (string) ( $config['release']['implantador'] ?? '' ) : '';

	if ( '' === $versao ) {
		return array(
			'ok'        => false,
			'achados'   => array( 'release.implantador ausente em config/site.json — o nome do bundle não pode ser inventado' ),
			'bundle'    => '',
			'embutidos' => array(),
			'documentos' => array(),
		);
	}

	/*
	 * DOCUMENTOS ENTREGÁVEIS PRIMEIRO, antes de qualquer cópia: README,
	 * MANIFESTO e MEMORIA-DECISOES viajam DENTRO do bundle, e regenerá-los
	 * depois faria o pacote publicado carregar o carimbo da rodada anterior. É
	 * a mesma razão pela qual o selo regrava o lock: um artefato que descreve o
	 * arquivo anterior é pior que artefato nenhum.
	 */
	$documentos = f3b_gerar_documentos( $raiz, $suite );

	$dist  = $raiz . '/dist';
	$stage = $dist . '/stage';

	f3b_apagar( $stage );

	if ( ! is_dir( $dist ) && ! mkdir( $dist, 0755, true ) && ! is_dir( $dist ) ) {
		return array(
			'ok'        => false,
			'achados'   => array( 'não foi possível criar ' . $dist ),
			'bundle'    => '',
			'embutidos' => array(),
			'documentos' => $documentos['escritos'],
		);
	}

	$achados = $documentos['achados'];

	if ( ! is_dir( $raiz . '/fontes/tema' ) ) {
		$achados[] = 'diretório ausente: fontes/tema/';
	}

	/*
	 * DOIS ARTEFATOS, DOIS REPOSITÓRIOS — 2.0.0.
	 *
	 * O `site-core` é um plugin com release própria E repositório próprio. Este
	 * empacotamento NÃO o monta: quem monta, sela e publica o zip dele é a
	 * suíte de lá. O que entra aqui é a RESERVA — o zip publicado no catálogo,
	 * copiado para `assets/plugins/<slug>-<versão>.zip` como entrada de build —,
	 * e ela viaja dentro do bundle pelo mesmo caminho de todo arquivo da
	 * árvore: está no inventário, entra no corpo, entra no lock, entra no hash.
	 *
	 * ELA É CONFERIDA ANTES DE O BUNDLE FECHAR. Reserva ausente, duplicada, com
	 * nome que não bate com o cabeçalho de dentro, ou com bytes que não são os
	 * que o catálogo declara, é achado de build — e o achado sai aqui, com o
	 * nome, em vez de deixar a suíte reprovar um bundle que já foi montado. A
	 * conferência completa, com piso, é `pacote.reserva_confere_com_o_catalogo`.
	 *
	 * POR QUE A CÓPIA EMBUTIDA CONTINUA EXISTINDO: o implantador instala o
	 * plugin pela URL declarada no catálogo; se a URL não responder — alguém a
	 * moveu, a rede caiu —, ele instala este zip. Entrega não pode falhar por
	 * um endereço que mudou. E é por isso que a reserva precisa ser O MESMO
	 * ARTEFATO que a URL serve: quem cai na reserva tem de receber o que quem
	 * baixa o publicado recebe, byte a byte.
	 */
	$reserva  = f3b_reserva_do_site_core( $raiz );
	$catalogo = f3b_catalogo_do_site_core( $raiz );

	if ( '' !== $reserva['erro'] ) {
		$achados[] = 'reserva do plugin: ' . $reserva['erro'];
	} else {
		if ( '' === $catalogo['sha256'] ) {
			$achados[] = 'o catálogo (config/decisoes.tsv, plugins.instalaveis.' . $catalogo['indice'] . ') não declara o sha256 do plugin do site: a reserva '
				. $reserva['nome'] . ' (' . substr( $reserva['sha256'], 0, 12 ) . '…) não tem contra o que ser conferida, e o host fixaria o primeiro digesto que observasse';
		} elseif ( $catalogo['sha256'] !== $reserva['sha256'] ) {
			$achados[] = 'a reserva ' . $reserva['nome'] . ' (' . substr( $reserva['sha256'], 0, 12 ) . '…) não é o zip que o catálogo declara ('
				. substr( $catalogo['sha256'], 0, 12 ) . '…): ou a cópia na árvore está atrás do publicado, ou o catálogo está atrás da cópia';
		}

		if ( $reserva['versao_do_nome'] !== $reserva['versao_do_cabecalho'] ) {
			$achados[] = 'a reserva ' . $reserva['nome'] . ' diz ' . $reserva['versao_do_nome'] . ' no nome e ' . $reserva['versao_do_cabecalho']
				. ' no cabeçalho de dentro: o host lê a versão do nome, e a comparação com a instalada passaria a usar um número que o plugin não tem';
		}
	}

	$embutidos = '' !== $reserva['relativo'] ? array( $reserva['relativo'] ) : array();

	/* Corpo do bundle: exatamente o que o inventário autoriza. */
	$dir_bundle = $stage . '/implantador-base';

	if ( ! mkdir( $dir_bundle, 0755, true ) && ! is_dir( $dir_bundle ) ) {
		$achados[] = 'não foi possível preparar ' . $dir_bundle;
	}

	foreach ( f3b_corpo_do_bundle( $raiz ) as $rel ) {
		$destino = $dir_bundle . '/' . $rel;

		if ( ! is_dir( dirname( $destino ) ) ) {
			mkdir( dirname( $destino ), 0755, true );
		}

		copy( $raiz . '/' . $rel, $destino );
	}

	/*
	 * HASH DO PACOTE, calculado sobre o CORPO DO BUNDLE — que é o que o host vai
	 * ter instalado: a árvore inteira, reserva incluída, e sem `dist/`. Quem
	 * calcula é a função do implantador, chamada em subprocesso: uma só
	 * implementação do hash, dos dois lados.
	 */
	$hash_pacote = f3b_hash_do_pacote( $dir_bundle );

	if ( '' === $hash_pacote ) {
		$achados[] = 'não foi possível calcular o hash do pacote pela função do implantador (suite/lib/sonda-hash.php)';
	}

	$bundle = $dist . '/implantador-base-' . $versao . '.zip';

	if ( is_file( $bundle ) ) {
		unlink( $bundle );
	}

	$saida  = array();
	$codigo = 0;
	exec(
		sprintf(
			'cd %s && zip -qrX %s implantador-base 2>&1',
			escapeshellarg( $stage ),
			escapeshellarg( $bundle )
		),
		$saida,
		$codigo
	);

	if ( 0 !== $codigo || ! is_file( $bundle ) ) {
		$achados[] = 'falha ao montar o bundle: ' . f3b_amostra( $saida, 2 );
	}

	/* Lock: sha256 de cada caminho da allow-list, em ordem de caminho. */
	if ( is_file( $bundle ) ) {
		f3b_gravar_lock( $raiz, $dist );
	}

	/*
	 * O bundle precisa CONTER a reserva — conferido por leitura do zip montado,
	 * e não pelo fato de ela estar na árvore. Com a lista vazia (reserva que não
	 * pôde ser resolvida) o laço não roda e o achado já saiu acima com o nome.
	 */
	if ( is_file( $bundle ) ) {
		$lista  = array();
		$codigo = 0;
		exec( 'unzip -Z1 ' . escapeshellarg( $bundle ) . ' 2>/dev/null', $lista, $codigo );

		foreach ( $embutidos as $nome ) {
			if ( ! in_array( 'implantador-base/' . $nome, $lista, true ) ) {
				$achados[] = 'o bundle não contém o zip embutido ' . $nome;
			}
		}
	}

	f3b_apagar( $stage );

	/* O artefato precisa ser mais novo que a fonte: o toque é do próprio build. */
	if ( is_file( $bundle ) ) {
		touch( $bundle );
	}

	return array(
		'ok'            => array() === $achados,
		'achados'       => $achados,
		'bundle'        => $bundle,
		'embutidos'     => $embutidos,
		'hash_pacote'   => $hash_pacote,
		'versao'        => $versao,
		'documentos'    => $documentos['escritos'],
		'reserva'       => $reserva,
		'versao_plugin' => $reserva['versao_do_nome'],
	);
}

/**
 * Grava `dist/lock.tsv`: sha256 de cada caminho da allow-list, em ordem.
 *
 * Função própria porque ela roda DUAS vezes: no empacotamento e de novo depois
 * do selo, quando `suite/rodada.json` acabou de mudar. Um lock que
 * descreve o arquivo anterior é pior que lock nenhum.
 *
 * A RESERVA DO PLUGIN ENTRA PELA LINHA DELA, como todo arquivo da árvore: desde
 * a 2.0.0 ela mora em `assets/plugins/` e é entrada de build, não saída. O lock
 * deixou de ter uma linha montada à parte para um zip que nascia na rodada.
 *
 * @param string $raiz Raiz do pacote.
 * @param string $dist Diretório de saída.
 * @return void
 */
function f3b_gravar_lock( string $raiz, string $dist ): void {
	$linhas = array( "# caminho\tsha256" );

	foreach ( f3b_fontes( $raiz ) as $rel ) {
		$linhas[] = $rel . "\t" . hash_file( 'sha256', $raiz . '/' . $rel );
	}

	file_put_contents( $dist . '/lock.tsv', implode( "\n", $linhas ) . "\n" );
}

/**
 * Hash do pacote pela ÚNICA implementação dele: a do implantador.
 *
 * @param string $arvore Árvore a medir (o corpo do bundle).
 * @return string Hash, ou vazio quando a sonda não devolveu um.
 */
function f3b_hash_do_pacote( string $arvore ): string {
	$saida  = array();
	$codigo = 0;

	exec(
		sprintf(
			'php %s %s 2>/dev/null',
			escapeshellarg( __DIR__ . '/sonda-hash.php' ),
			escapeshellarg( $arvore )
		),
		$saida,
		$codigo
	);

	$hash = trim( implode( '', $saida ) );

	return ( 0 === $codigo && 1 === preg_match( '/^[0-9a-f]{64}$/', $hash ) ) ? $hash : '';
}

/**
 * SELO DA RODADA — grava `suite/rodada.json` e o injeta no bundle.
 *
 * O NOME DO ARQUIVO MUDOU NA 1.0.18, e a mudança é o achado. Ele se chamava
 * `rodada-limpa.json`, trazia 22 BLOCKED dentro e o leitor no host comparava só
 * o hash: o pacote se aprovava pelo arquivo que ele mesmo tinha escrito, e o
 * NOME afirmava uma limpeza que o conteúdo não sustentava. Um registro chamado
 * "rodada limpa" com bloqueios dentro é o tipo de afirmação que esta release
 * existe para eliminar. O nome passou a ser neutro e o veredito passou a ser um
 * campo declarado, com as pendências nomeadas.
 *
 * O problema circular, dito por inteiro: o registro descreve o hash do pacote e
 * mora DENTRO do pacote que ele descreve, então escrevê-lo mudaria o número que
 * ele carrega. A saída não é gravar o hash "de antes": é EXCLUIR o próprio
 * registro da soma, dos dois lados — aqui e em
 * `F3Base_Imp_Entrega::hash_do_pacote()`, que é literalmente a mesma função. Com
 * a exclusão, o hash é o mesmo antes e depois do selo, e o registro pode viajar
 * dentro do artefato que descreve sem mentir sobre ele.
 *
 * O segundo circuito é de ORDEM: empacotar é a primeira etapa, sempre, e o
 * resumo por estado só existe depois das checagens. Por isso o selo é a última
 * etapa e INJETA o registro no bundle já montado, em vez de remontá-lo — a
 * injeção não muda o hash, de novo pela exclusão.
 *
 * E ele só grava REGISTRO DE RODADA LIMPA: com qualquer FALHA, o registro
 * anterior é REMOVIDO e o achado sai nomeado. Registro que sobrevive a uma
 * rodada reprovada é uma afirmação de limpeza sem medição por trás.
 *
 * @param string                          $raiz     Raiz do pacote.
 * @param string                          $suite    Diretório da suíte.
 * @param array<string,mixed>             $build    Resultado do empacotamento.
 * @param array<string,int>               $contagem Contagem por estado da rodada.
 * @param array<string,array<int,string>> $nomes    Nomes por estado da rodada.
 * @param array<int,string>               $piso     Detectores com piso em disco.
 * @return array{ok:bool,achados:array<int,string>,arquivo:string,hash:string,gravado:bool}
 */
function f3b_selar_rodada( string $raiz, string $suite, array $build, array $contagem, array $nomes, array $piso ): array {
	$relativo = 'suite/rodada.json';
	$arquivo  = $raiz . '/' . $relativo;
	$achados  = array();
	$hash     = (string) ( $build['hash_pacote'] ?? '' );
	$bundle   = (string) ( $build['bundle'] ?? '' );
	$falhas   = (int) ( $contagem['FALHA'] ?? 0 );

	if ( $falhas > 0 ) {
		if ( is_file( $arquivo ) ) {
			unlink( $arquivo );
		}

		return array(
			'ok'      => true,
			'achados' => array( 'rodada com ' . $falhas . ' FALHA — o registro NÃO foi gravado e o anterior foi removido: ' . $relativo ),
			'arquivo' => $arquivo,
			'hash'    => $hash,
			'gravado' => false,
		);
	}

	if ( '' === $hash || ! is_file( $bundle ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'selo impossível: hash do pacote ou bundle ausentes (hash="' . $hash . '", bundle="' . $bundle . '")' ),
			'arquivo' => $arquivo,
			'hash'    => $hash,
			'gravado' => false,
		);
	}

	/*
	 * O REGISTRO DECLARA O VEREDITO, e não só o hash. Até a 1.0.17 o arquivo se
	 * chamava "rodada limpa", continha 22 BLOCKED e o leitor no host comparava
	 * SÓ o hash: o pacote se aprovava pelo arquivo que ele mesmo tinha escrito,
	 * e a palavra "limpa" no nome afirmava mais do que o conteúdo sustentava.
	 * Agora o nome é neutro (`suite/rodada.json`, o registro DA rodada) e o
	 * veredito é um campo, com o que ele significa escrito ao lado e com as
	 * pendências NOMEADAS — nunca contadas sem nome.
	 */
	$pendencias = array_values( array_map( 'strval', $nomes['BLOCKED'] ?? array() ) );
	$veredito   = array() === $pendencias ? 'sem-falha-e-sem-pendencia' : 'sem-falha-com-pendencia-de-fase';

	$registro = array(
		'registro'        => 'rodada',
		'produzido_por'   => 'suite/verificar.sh — comando único; gravado à mão, este registro não vale nada e o detector de fonte única existe para impedi-lo',
		'veredito'        => $veredito,
		'veredito_diz'    => array() === $pendencias
			? 'a rodada fechou com ZERO FALHA e ZERO pendência: nenhuma checagem ficou em BLOCKED.'
			: 'a rodada fechou com ZERO FALHA e ' . count( $pendencias ) . ' pendência(s) de fase em BLOCKED, nomeada(s) em pendencias_de_fase. Isto NÃO é uma rodada sem pendência, e o campo existe para que o host não leia mais do que foi medido.',
		'falhas'          => (int) ( $contagem['FALHA'] ?? 0 ),
		'pendencias_de_fase' => $pendencias,
		'release'         => (string) ( $build['versao'] ?? '' ),
		'bundle'          => basename( $bundle ),
		'hash_pacote'     => $hash,
		'hash_regra'      => 'sha256 de "<caminho relativo>:<sha256 do arquivo>" de cada arquivo do corpo do bundle, ordenados e unidos por quebra de linha; o PRÓPRIO registro fica fora da soma, dos dois lados, e é isso que permite a ele morar dentro do pacote que descreve',
		'hash_medido_por' => 'F3Base_Imp_Entrega::hash_do_pacote(), a mesma função que o host executa ao conferir a amarração',
		'em'              => gmdate( 'Y-m-d\TH:i:s\Z' ),
		'resumo'          => $contagem,
		'nomes'           => $nomes,
		'piso'            => array(
			'detectores_com_fixture' => count( $piso ),
			'nomes'                  => $piso,
			'medicao'                => 'fixtures negativa E positiva presentes em suite/fixtures/; a execução do piso é o subcomando "bash suite/verificar.sh piso"',
		),
	);

	$json = json_encode( $registro, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

	if ( ! is_string( $json ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'o registro da rodada não codificou em JSON' ),
			'arquivo' => $arquivo,
			'hash'    => $hash,
			'gravado' => false,
		);
	}

	file_put_contents( $arquivo, $json . "
" );

	/* Injeta o registro no bundle já montado: a injeção não muda o hash. */
	$selo = $raiz . '/dist/selo';

	f3b_apagar( $selo );

	if ( ! mkdir( $selo . '/implantador-base/suite', 0755, true ) && ! is_dir( $selo . '/implantador-base/suite' ) ) {
		$achados[] = 'não foi possível preparar ' . $selo;
	} else {
		copy( $arquivo, $selo . '/implantador-base/' . $relativo );

		$saida  = array();
		$codigo = 0;
		exec(
			sprintf(
				'cd %s && zip -qrX %s %s 2>&1',
				escapeshellarg( $selo ),
				escapeshellarg( $bundle ),
				escapeshellarg( 'implantador-base/' . $relativo )
			),
			$saida,
			$codigo
		);

		if ( 0 !== $codigo ) {
			$achados[] = 'falha ao injetar o registro no bundle: ' . f3b_amostra( $saida, 2 );
		}

		f3b_apagar( $selo );
	}

	/* Leitura de volta: o registro precisa ESTAR dentro do bundle entregue. */
	$lista  = array();
	$codigo = 0;
	exec( 'unzip -Z1 ' . escapeshellarg( $bundle ) . ' 2>/dev/null', $lista, $codigo );

	if ( ! in_array( 'implantador-base/' . $relativo, $lista, true ) ) {
		$achados[] = 'o bundle não contém ' . $relativo . ' depois do selo';
	}

	/*
	 * LEITURA DE VOLTA DA CIRCULARIDADE. O bundle SELADO é extraído e medido de
	 * novo: se o hash mudou por causa do registro que acabou de entrar nele, a
	 * exclusão não está valendo e todo registro nasceria divergente no host.
	 * Afirmar que "a exclusão resolve" sem medir é a mesma classe de erro que
	 * este pacote inteiro existe para não cometer.
	 */
	$conferencia = $raiz . '/dist/conferencia';

	f3b_apagar( $conferencia );

	$saida  = array();
	$codigo = 0;
	exec(
		sprintf( 'unzip -qq %s -d %s 2>&1', escapeshellarg( $bundle ), escapeshellarg( $conferencia ) ),
		$saida,
		$codigo
	);

	$conferido = 0 === $codigo ? f3b_hash_do_pacote( $conferencia . '/implantador-base' ) : '';

	if ( $conferido !== $hash ) {
		$achados[] = 'o hash do bundle SELADO (' . ( '' !== $conferido ? $conferido : '(não calculado)' )
			. ') difere do hash gravado no registro (' . $hash . '): '
			. 'o registro está entrando na soma que ele próprio declara e a exclusão não está valendo dos dois lados';
	}

	f3b_apagar( $conferencia );

	f3b_gravar_lock( $raiz, $raiz . '/dist' );

	/* O artefato precisa continuar mais novo que toda fonte, o registro incluído. */
	touch( $bundle );

	return array(
		'ok'        => array() === $achados,
		'achados'   => $achados,
		'arquivo'   => $arquivo,
		'hash'      => $hash,
		'conferido' => $conferido,
		'gravado'   => true,
	);
}

/**
 * REGISTRO DURÁVEL DE FASES — grava `suite/fases.json`. Produtor ÚNICO.
 *
 * IRMÃO DO SELO, E NÃO O SELO. Os dois moram em `suite/`, os dois são escritos
 * só pelo comando único e os dois são conferidos por `estatica.gate_fonte_unica`
 * pela mesma regra de produtor único. O que os separa é o tempo de vida:
 *
 * - `suite/rodada.json` descreve UMA rodada, é reescrito a cada rodada e é
 *   APAGADO quando a rodada tem FALHA — registro de limpeza que sobrevive a uma
 *   rodada reprovada é afirmação sem medição por trás.
 * - `suite/fases.json` descreve QUANDO CADA FASE RODOU PELA ÚLTIMA VEZ, e
 *   precisa durar entre execuções: é ele que impede a regra de aplicabilidade
 *   da 1.1.6 de virar cegueira. Apagá-lo numa rodada com FALHA perderia o
 *   registro de que a fase de navegador rodou um dia — e é justamente esse fato
 *   que a rodada de build não tem como reproduzir. Por isso ele é gravado
 *   SEMPRE, inclusive na rodada reprovada: ele não afirma aprovação nenhuma,
 *   afirma execução.
 *
 * ELE NÃO É INJETADO NO BUNDLE, e essa é a segunda metade da decisão. O selo
 * precisa ser injetado porque o HOST o consome, e para isso ele foi excluído do
 * hash do pacote dos dois lados. Excluir um segundo arquivo da soma tiraria mais
 * um caminho da cobertura de integridade para resolver um problema que este
 * registro não tem: quem o lê é a PRÓXIMA rodada da suíte, na mesma árvore, e o
 * host tem o registro dele próprio, na option `f3base_fases`. O preço declarado
 * é que a cópia que viaja dentro do bundle é a da rodada ANTERIOR — o que basta,
 * porque a fase corrente é sempre recalculada ao vivo e só as OUTRAS fases são
 * lidas daqui.
 *
 * @param string              $raiz   Raiz do pacote.
 * @param array<string,mixed> $durar  Registro atualizado, como `F3Base_Imp_Fases::durar()` o devolve.
 * @return array{ok:bool,arquivo:string,achados:array<int,string>}
 */
function f3b_gravar_registro_de_fases( string $raiz, array $durar ): array {
	$relativo = 'suite/fases.json';
	$arquivo  = $raiz . '/' . $relativo;

	$registro = array(
		'registro'      => 'fases',
		'produzido_por' => 'suite/verificar.sh — comando único; gravado à mão, este registro não vale nada e o detector de fonte única existe para impedi-lo',
		'o_que_declara' => 'quando cada fase fechada rodou pela ÚLTIMA vez, medida por uma linha que fechou OK, FALHA ou WARN naquela fase. BLOCKED e N/A não contam: o primeiro diz que a medição não pôde acontecer e o segundo que ela não se aplicava, e contar qualquer um dos dois faria a fase se aprovar por omissão.',
		'precisao'      => 'DIA, em UTC. Este registro mora dentro do pacote e entra na soma que produz o hash dele — de propósito, para que um registro forjado não escape da cobertura de integridade. Com precisão de segundo, duas rodadas seguidas sobre uma árvore idêntica dariam hashes diferentes, e dois digests legítimos pareceriam adulteração.',
		'em'            => gmdate( 'Y-m-d' ),
		'fases'         => $durar,
	);

	$json = json_encode( $registro, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

	if ( ! is_string( $json ) ) {
		return array(
			'ok'      => false,
			'arquivo' => $arquivo,
			'achados' => array( 'o registro de fases não codificou em JSON' ),
		);
	}

	file_put_contents( $arquivo, $json . "\n" );

	return array(
		'ok'      => true,
		'arquivo' => $arquivo,
		'achados' => array(),
	);
}
