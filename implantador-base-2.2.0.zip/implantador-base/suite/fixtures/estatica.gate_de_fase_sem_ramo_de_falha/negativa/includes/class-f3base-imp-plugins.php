<?php
/**
 * FIXTURE NEGATIVA: a contradição da 1.7.2, plantada na DECLARAÇÃO.
 *
 * `plugins.site_core_versao` volta a declarar `gate => 'fase'` — a lista sobre a
 * qual o relatório escreve, nome por nome, que a evidência é de algo que ESTE
 * HOST NÃO PRODUZ e que ela não é somada ao gate da autodesativação — enquanto a
 * produtora do estado dela tem ramo de FALHA. A FALHA entra na contagem crua que
 * derruba o estado da aplicação, e o estado é a PRIMEIRA condição daquele gate:
 * a linha decide o gate por dentro enquanto o texto diz que não decide.
 *
 * É a mutação de uma linha só, na linha real: `'relato'` de volta para `'fase'`.
 *
 * @package F3Base\Suite\Fixture
 */

class F3Base_Imp_Plugins {

	public static function relatar_versao_do_site_core(): void {
		$artefato  = self::artefato_do_papel( 'site_core' );
		$instalada = self::versao_instalada( (string) $artefato['slug'] );
		$embarcada = self::versao_embarcada_do_site_core();
		$veredito  = self::veredito_da_versao_do_site_core( $instalada, $embarcada );

		F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			'plugins.site_core_versao',
			$veredito['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				'gate'      => 'fase',
				'tela'      => $veredito['curta'],
			)
		);
	}

	public static function veredito_da_versao_do_site_core( string $instalada, string $embarcada ): array {
		if ( '' === $embarcada ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::WARN,
				'motivo' => 'sem reserva legível para comparar.',
				'curta'  => '',
			);
		}

		if ( '' === $instalada ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'motivo' => 'nenhum site-core instalado para comparar.',
				'curta'  => '',
			);
		}

		if ( version_compare( $instalada, $embarcada, '<' ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::FALHA,
				'motivo' => 'o site ficou com uma versão anterior à que este pacote carrega.',
				'curta'  => 'O plugin do site ficou numa versão anterior.',
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'motivo' => 'a versão instalada não está atrás da que o pacote carrega.',
			'curta'  => '',
		);
	}
}
