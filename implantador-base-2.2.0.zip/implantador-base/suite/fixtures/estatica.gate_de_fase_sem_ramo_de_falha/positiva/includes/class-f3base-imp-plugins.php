<?php
/**
 * FIXTURE POSITIVA: as MESMAS quatro formas do pacote correto, e o detector
 * precisa ficar em silêncio sobre todas.
 *
 * São as três formas legítimas de gate de fase — evidência que este host não
 * produz, e nenhuma delas com ramo de FALHA — mais a linha que a 1.7.3
 * reclassificou. Sem esta última, o detector poderia estar simplesmente
 * acusando toda emissão de versão, e o piso não provaria nada: uma checagem que
 * só sabe reprovar reprova o certo junto.
 *
 * @package F3Base\Suite\Fixture
 */

class F3Base_Imp_Plugins {

	/* 1. Estado por CONSTANTE LITERAL, e ela não é FALHA. */
	public static function declarar_orcamento(): void {
		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::BLOCKED,
			'orcamento.medicao_de_pagina',
			'a medição é de navegador e a fase corrente é esta.',
			array(
				'evidencia' => 'pendencia-externa',
				'fase'      => 'campo',
				'gate'      => 'fase',
			)
		);
	}

	/* 2. Estado vindo de PRODUTORA NOMEADA que só devolve BLOCKED e N/A. */
	public static function declarar_recusa_de_credencial(): void {
		$aplicavel = F3Base_Imp_Fases::aplicabilidade( 'campo', 'producao' );

		F3Base_Imp_Relatorio::emitir(
			$aplicavel['estado'],
			'mcp.autoteste_recusa_credencial',
			'quem produz esta evidência é o requisitante externo.',
			array(
				'evidencia' => 'pendencia-externa',
				'fase'      => 'campo',
				'gate'      => 'fase',
			)
		);
	}

	/* 3. Estado vindo de PRODUTORA NOMEADA que só devolve BLOCKED e OK. */
	public static function declarar_evidencia_importada(): void {
		$veredito = self::veredito_da_rodada_limpa( true, '', '' );

		F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			'entrega.rodada_limpa',
			$veredito['motivo'],
			array(
				'evidencia' => 'pendencia-externa',
				'fase'      => 'build',
				'gate'      => 'fase',
			)
		);
	}

	public static function veredito_da_rodada_limpa( bool $existe, string $declarado, string $medido ): array {
		if ( ! $existe || $declarado !== $medido ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'motivo' => 'o registro da rodada não confere com o hash do pacote instalado.',
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'motivo' => 'o registro da rodada confere com o hash do pacote instalado.',
		);
	}

	/*
	 * 4. A linha reclassificada na 1.7.3: MESMA produtora com ramo de FALHA, e
	 * gate de RELATO. Ela está fora do escopo deste detector por construção — o
	 * host mede, a FALHA derruba o estado, e o relatório diz isso.
	 */
	public static function relatar_versao_do_site_core(): void {
		$veredito = self::veredito_da_versao_do_site_core( '1.0.0', '1.0.1' );

		F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			'plugins.site_core_versao',
			$veredito['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				'gate'      => 'relato',
			)
		);
	}

	public static function veredito_da_versao_do_site_core( string $instalada, string $embarcada ): array {
		if ( version_compare( $instalada, $embarcada, '<' ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::FALHA,
				'motivo' => 'o site ficou com uma versão anterior à que este pacote carrega.',
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'motivo' => 'a versão instalada não está atrás da que o pacote carrega.',
		);
	}
}
