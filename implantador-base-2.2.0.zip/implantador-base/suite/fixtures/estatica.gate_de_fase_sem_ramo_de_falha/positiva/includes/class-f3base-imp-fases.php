<?php
/**
 * FIXTURE POSITIVA: a produtora de aplicabilidade, que devolve BLOCKED ou N/A e
 * nunca FALHA — é ela que prova que a linha de recusa de credencial não tem ramo
 * de reprovação.
 *
 * @package F3Base\Suite\Fixture
 */

class F3Base_Imp_Fases {

	public const BLOCKED = 'BLOCKED';
	public const NA      = 'N/A';

	public static function aplicabilidade( string $fase_declarada, string $fase_corrente ): array {
		if ( $fase_declarada === $fase_corrente ) {
			return array(
				'aplicavel' => true,
				'estado'    => self::BLOCKED,
			);
		}

		return array(
			'aplicavel' => false,
			'estado'    => self::NA,
		);
	}
}
