<?php
/**
 * Fixture do piso: a ÂNCORA que declara os segredos do site.
 *
 * Ela é a mesma nos dois lados — negativa e positiva —, porque o que o detector
 * mede não é a âncora e sim o que sobrou dela em outros arquivos.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Catálogo reduzido de options.
 */
final class F3Base_Options {

	/**
	 * As options que são SEGREDO DO SITE.
	 *
	 * @return string[]
	 */
	public static function segredos_do_site(): array {
		return array(
			'f3base_meta_capi_token',
		);
	}
}
