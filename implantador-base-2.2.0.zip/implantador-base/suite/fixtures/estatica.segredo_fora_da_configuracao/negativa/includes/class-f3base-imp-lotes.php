<?php
/**
 * Fixture NEGATIVA do piso: o implantador gravando um segredo.
 *
 * Três defeitos plantados de uma vez, que é como este erro chega na prática: a
 * chave no arquivo único, a chave no schema e o lote gravando o valor. O
 * detector precisa acusar os três, cada um com o nome do arquivo.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Lote reduzido.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Grava o segredo a partir do arquivo único — o defeito.
	 *
	 * @return void
	 */
	public static function etapa_options(): void {
		F3Base_Imp_Gravador::gravar( 'f3base_meta_capi_token', F3Base_Imp_Config::obter( 'tracking.f3base_meta_capi_token', '' ) );
	}
}
