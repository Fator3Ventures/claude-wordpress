<?php
/**
 * Fixture POSITIVA do piso: o implantador grava o que viaja, e só isso.
 *
 * O Pixel ID é identificador público e nasce no arquivo único; o token de
 * acesso não é gravado por lote nenhum — quem o grava é o agente, pelo canal.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Lote reduzido.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Grava só o que o arquivo único declara.
	 *
	 * @return void
	 */
	public static function etapa_options(): void {
		F3Base_Imp_Gravador::gravar( 'f3base_meta_pixel_id', F3Base_Imp_Config::obter( 'tracking.meta_pixel_id', '' ) );
	}
}
