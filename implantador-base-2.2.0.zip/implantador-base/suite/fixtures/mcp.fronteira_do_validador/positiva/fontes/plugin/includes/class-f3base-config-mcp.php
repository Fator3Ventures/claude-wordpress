<?php
/**
 * Fixture do piso: a classe de habilidades do PLUGIN, como o zip publicado a traz.
 *
 * Só o que a fronteira declara: os pares de arquivo que ela lê e grava dentro
 * da pasta do implantador, a classe do validador que ela carrega e o método que
 * ela chama. No pacote real esta classe é lida de dentro da reserva; a fixture a
 * traz em claro porque fixture precisa ser legível.
 */
final class F3Base_Config_Mcp {
	private const ARQUIVOS = array(
		'projeto' => array(
			'config' => 'config/projeto.json',
			'schema' => 'config/projeto.schema.json',
		),
	);

	public static function validar( array $dados, string $schema ): array {
		if ( ! class_exists( 'F3Base_Imp_Config' ) ) {
			require_once self::diretorio() . 'includes/class-f3base-imp-config.php';
		}

		return F3Base_Imp_Config::validar_com_schema( $dados, $schema );
	}

	private static function diretorio(): string {
		return '';
	}
}
