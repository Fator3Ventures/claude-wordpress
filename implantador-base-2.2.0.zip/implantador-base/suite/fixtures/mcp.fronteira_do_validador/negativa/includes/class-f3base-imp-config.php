<?php
/**
 * Fixture do piso: o validador do IMPLANTADOR, com o método que o plugin chama.
 */
final class F3Base_Imp_Config {
	public static function validar_com_schema( array $dados, string $caminho, string $rotulo = '' ): array {
		unset( $dados, $caminho, $rotulo );

		return array();
	}
}
