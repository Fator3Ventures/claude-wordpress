<?php
/**
 * Fixture do piso, ramo NEGATIVO: o plugin chama F3Base_Imp_Config::validar_contra_o_schema(),
 * que o implantador NÃO tem, e declara config/projeto.schema.json, que NÃO existe na árvore.
 * As duas faltas precisam ser acusadas.
 */
final class F3Base_Config_Mcp {
	private const ARQUIVOS = array(
		'projeto' => array(
			'config' => 'config/projeto.json',
			'schema' => 'config/projeto.schema.json',
		),
	);

	public static function validar( array $dados, string $schema ): array {
		if ( ! class_exists( 'F3Base_Imp_Config' ) ) {
			require_once self::diretorio() . 'includes/class-f3base-imp-config.php';
		}

		return F3Base_Imp_Config::validar_contra_o_schema( $dados, $schema );
	}

	private static function diretorio(): string {
		return '';
	}
}
