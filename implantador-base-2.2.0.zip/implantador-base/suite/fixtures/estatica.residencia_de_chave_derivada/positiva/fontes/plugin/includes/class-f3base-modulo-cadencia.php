<?php
/**
 * O CASO CORRETO do outro runtime: o site-core não tem o derivador e fala dos
 * arquivos do implantador de fora, então a regra que sobra é a verificável — a
 * chave citada mora no arquivo citado. E `conteudo.demonstrativo`, citada ao
 * lado de `config/site.json`, é declarada mesmo ali.
 *
 * @package F3Base\SiteCore
 */

class F3Base_Modulo_Cadencia {

	public function detalhe(): string {
		return __( 'o aviso de conteúdo demonstrativo sai enquanto conteudo.demonstrativo estiver ligada em config/site.json e a marca do template continuar no banco.', 'f3base' );
	}
}
