<?php
/**
 * O CASO CORRETO: a mensagem PERGUNTA em que arquivo a chave mora, e o nome do
 * arquivo chega por `F3Base_Imp_Residencia`. Trocar a chave de arquivo muda a
 * instrução sozinho, na mesma execução.
 *
 * @package F3Base\Implantador
 */

class F3Base_Imp_Conteudo {

	public static function saida_da_guarda_do_controlador( array $faltando ): string {
		return sprintf(
			/* translators: 1: caminhos vazios, nomeados, 2: onde preencher, derivado da chave. */
			__( 'Caminho de saída: preencha %1$s %2$s e execute de novo — a página publica sozinha na execução seguinte.', 'f3base' ),
			implode( ', ', $faltando ),
			F3Base_Imp_Residencia::onde_preencher( $faltando )
		);
	}
}
