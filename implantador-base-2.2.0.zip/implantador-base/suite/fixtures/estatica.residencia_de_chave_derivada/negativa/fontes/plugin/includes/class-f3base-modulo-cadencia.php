<?php
/**
 * O SEGUNDO DEFEITO PLANTADO: o site-core nomeia a chave E o arquivo, e o
 * arquivo é o outro — `contato.whatsapp_e164` mora em `config/projeto.json`.
 *
 * @package F3Base\SiteCore
 */

class F3Base_Modulo_Cadencia {

	public function detalhe(): string {
		return __( 'sem destino privado: contato.whatsapp_e164 está vazia em config/site.json e o botão leva à página de contato.', 'f3base' );
	}
}
