<?php
/**
 * Leitor do arquivo único de configuração (recorte da fixture).
 *
 * @package F3Base\Implantador
 */

class F3Base_Imp_Config {

	public const ARQUIVO = 'config/site.json';
}
