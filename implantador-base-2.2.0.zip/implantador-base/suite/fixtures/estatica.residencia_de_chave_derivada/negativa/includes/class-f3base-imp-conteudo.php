<?php
/**
 * O DEFEITO PLANTADO, e é o medido em produção: a guarda da política de
 * privacidade manda preencher `contato.controlador` em `config/site.json`, e
 * essa chave mora em `config/projeto.json`. O nome do arquivo está DIGITADO
 * dentro da mensagem, e a chave chega por `%s` — nem aparece na frase.
 *
 * @package F3Base\Implantador
 */

class F3Base_Imp_Conteudo {

	public static function saida_da_guarda_do_controlador( array $faltando ): string {
		return sprintf(
			/* translators: %s: caminhos de configuração vazios, nomeados. */
			__( 'Caminho de saída: preencha %s em config/site.json e execute de novo — a página publica sozinha na execução seguinte.', 'f3base' ),
			implode( ', ', $faltando )
		);
	}
}
