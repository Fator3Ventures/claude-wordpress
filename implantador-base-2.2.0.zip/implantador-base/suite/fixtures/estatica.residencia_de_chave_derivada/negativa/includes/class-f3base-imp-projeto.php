<?php
/**
 * Leitor do arquivo do projeto (recorte da fixture).
 *
 * @package F3Base\Implantador
 */

class F3Base_Imp_Projeto {

	public const ARQUIVO = 'config/projeto.json';
}
