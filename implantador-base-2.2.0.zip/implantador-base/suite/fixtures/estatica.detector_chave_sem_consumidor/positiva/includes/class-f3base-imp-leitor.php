<?php
/**
 * Fixture POSITIVA: toda chave tem leitor, inclusive por cobertura
 * bidirecional (o pai lido cobre o filho) e por função intermediária — o
 * agrupador recebe o caminho por parâmetro e lê os sufixos a partir dele.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Leitor {

	public static function ler(): array {
		return array(
			'site'           => F3Base_Imp_Config::obter( 'site', array() ),
			'ttl'            => F3Base_Imp_Config::obter( 'preferencias.prazo_dias', 0 ),
			'declarados'     => F3Base_Imp_Config::obter( 'consumidores_declarados', false ),
			'devem_aparecer' => self::copy_grupo( 'copy_contrato.devem_aparecer' ),
		);
	}

	private static function copy_grupo( string $caminho ): array {
		$saida = array();

		foreach ( F3Base_Imp_Config::lista( $caminho ) as $indice => $entrada ) {
			unset( $entrada );

			$saida[] = array(
				'id'      => F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.id', '' ),
				'grafias' => F3Base_Imp_Config::lista( $caminho . '.' . $indice . '.grafias' ),
				'onde'    => F3Base_Imp_Config::lista( $caminho . '.' . $indice . '.onde' ),
			);
		}

		return $saida;
	}
}
