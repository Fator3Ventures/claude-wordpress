<?php
/**
 * Fixture NEGATIVA: `orfa.chave_sem_leitor` e `consumidores_declarados` estão
 * declaradas no config e ninguém as lê. A própria chave que promete cobertura
 * entra na varredura como qualquer outra.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Leitor {

	public static function ler(): array {
		return array(
			'nome' => F3Base_Imp_Config::obter( 'site.nome', '' ),
			'ttl'  => F3Base_Imp_Config::obter( 'preferencias.prazo_dias', 0 ),
		);
	}
}
