<?php
/**
 * Fixture NEGATIVA: o catálogo do plugin declara uma operável que a lista do implantador não traz.
 *
 * É o defeito latente medido na 2.1.0: as duas listas concordavam por acidente.
 * Assim que o implantador rodasse, o campo do Pixel sumiria da tela do plugin —
 * sem erro, sem aviso e sem linha de relatório.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Options do plugin.
 */
final class F3Base_Options {

	/**
	 * O catálogo declarado.
	 *
	 * @return array<string,mixed>
	 */
	public static function catalogo(): array {
		return array(
			'f3base_contato'            => array(
				'padrao'   => array(),
				'operavel' => true,
				'secao'    => 'contato',
			),
			'f3base_ga4_measurement_id' => array(
				'padrao'   => '',
				'operavel' => true,
				'secao'    => 'medicao',
			),
			'f3base_meta_pixel_id'      => array(
				'padrao'   => '',
				'operavel' => true,
				'secao'    => 'medicao',
			),
		);
	}
}
