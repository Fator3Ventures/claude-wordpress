<?php
/**
 * Fixture: a lista que este pacote grava em `f3base_operaveis`.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Lotes.
 */
final class F3Base_Imp_Lotes {

	/**
	 * As options que o operador pode editar na tela do plugin.
	 *
	 * @return array<int,string>
	 */
	public static function operaveis_declaradas(): array {
		return array(
			'f3base_contato',
			'f3base_ga4_measurement_id',
		);
	}
}
