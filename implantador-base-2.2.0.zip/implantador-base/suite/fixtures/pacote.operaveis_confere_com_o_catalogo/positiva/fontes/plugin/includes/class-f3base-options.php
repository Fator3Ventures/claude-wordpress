<?php
/**
 * Fixture: o catálogo do plugin, com as mesmas duas operáveis.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Options do plugin.
 */
final class F3Base_Options {

	/**
	 * O catálogo declarado.
	 *
	 * @return array<string,mixed>
	 */
	public static function catalogo(): array {
		return array(
			'f3base_contato'            => array(
				'padrao'   => array(),
				'operavel' => true,
				'secao'    => 'contato',
			),
			'f3base_ga4_measurement_id' => array(
				'padrao'   => '',
				'operavel' => true,
				'secao'    => 'medicao',
			),
			'f3base_redirects'          => array(
				'padrao'   => array(),
				'operavel' => false,
				'secao'    => '',
			),
		);
	}
}
