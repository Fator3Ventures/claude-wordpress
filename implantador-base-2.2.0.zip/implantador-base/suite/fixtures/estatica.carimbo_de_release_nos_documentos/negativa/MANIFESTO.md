<!-- gerado:inicio=carimbo -->
# Manifesto da release — implantador-base 9.9.9

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio, e o documento passa a descrever um pacote que não é este. O que não pode ser gerado
> no momento da escrita sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `9.9.9` |
| Implantador · tema · plugin | `9.9.9` · `9.9.0` · `` |
| Bundle desta identidade | `implantador-base-9.9.9.zip` |
| Origens de release suportadas | 1 além da instalação limpa |
| Caminhos exatos no inventário | 1 |
| Prefixos declarados no inventário | 0 |
| Arquivos no pacote (fora de `dist/` e dos produtos da rodada) | 8 |
| Requisitos em `suite/manifesto.tsv` | 1 |
| Armadilhas com checagem mapeada | 1 |
| Armadilhas em pendência declarada | 1 |
| Detectores com piso em disco | 0 |
| Ramos de piso (negativa + positiva) | 0 |
| Páginas · posts declarados | 1 · 0 |
| Reserva do plugin na árvore | PENDÊNCIA NOMEADA: nenhuma reserva do plugin em assets/plugins/base-site-core-fator3-<versão>.zip: o bundle sairia sem o que responde quando o endereço do catálogo não responde |
| `sha256` da reserva · declarado no catálogo | `(sem reserva)` · `(não declarado)` |
| Arquivos vendorizados em `partilhado/` | 0 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

<!-- gerado:inicio=inventario -->
### Inventário: caminho para papel

Gerado de `suite/inventario.tsv`, que é a allow-list executável do empacotamento: arquivo em disco
fora dela **aborta o build com o nome**. Manter aqui uma cópia escrita à mão criaria duas fontes.

| Caminho | Papel |
|---|---|
| `README.md` | Leia-me do operador. |
<!-- gerado:fim=inventario -->

<!-- gerado:inicio=fixtures -->
### Piso: um detector, duas árvores

Gerado de disco. Cada linha é um detector com fixture NEGATIVA — que reproduz o defeito e precisa ser
acusada — e POSITIVA — que preserva o caso correto e precisa ficar em silêncio.

| Detector | Arquivos de piso |
|---|---|
<!-- gerado:fim=fixtures -->
