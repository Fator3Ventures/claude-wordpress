<!-- gerado:inicio=carimbo -->
# implantador-base 9.9.9 — leia-me

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio, e o documento passa a descrever um pacote que não é este. O que não pode ser gerado
> no momento da escrita sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `9.9.9` |
| Implantador · tema · plugin | `9.9.9` · `9.9.0` · `` |
| Bundle desta identidade | `implantador-base-9.9.9.zip` |
| Origens de release suportadas | 1 além da instalação limpa |
| Caminhos exatos no inventário | 1 |
| Prefixos declarados no inventário | 0 |
| Arquivos no pacote (fora de `dist/` e dos produtos da rodada) | 8 |
| Requisitos em `suite/manifesto.tsv` | 1 |
| Armadilhas com checagem mapeada | 1 |
| Armadilhas em pendência declarada | 1 |
| Detectores com piso em disco | 0 |
| Ramos de piso (negativa + positiva) | 0 |
| Páginas · posts declarados | 1 · 0 |
| Reserva do plugin na árvore | PENDÊNCIA NOMEADA: nenhuma reserva do plugin em assets/plugins/base-site-core-fator3-<versão>.zip: o bundle sairia sem o que responde quando o endereço do catálogo não responde |
| `sha256` da reserva · declarado no catálogo | `(sem reserva)` · `(não declarado)` |
| Arquivos vendorizados em `partilhado/` | 0 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

Prosa do leia-me, que o gerador não toca.

<!-- gerado:inicio=arvore -->
### Árvore de arquivos

Gerada de disco na montagem desta release. A allow-list executável que decide o que
entra no bundle é `suite/inventario.tsv`.

```
implantador-base/
  MANIFESTO.md
  MEMORIA-DECISOES.md
  README.md
  config/releases-suportadas.tsv
  config/site.json
  suite/armadilhas.tsv
  suite/fases.json  (produto da rodada: gravado no fim do comando único)
  suite/inventario.tsv
  suite/manifesto.tsv
  suite/rodada.json  (produto da rodada: gravado no fim do comando único)
```
<!-- gerado:fim=arvore -->
