<?php
/**
 * Fixture POSITIVA: a leitura de série da 1.0.15, com a normalização.
 *
 * As duas funções são as MESMAS do pacote, recortadas: marca de backup embutida
 * no resto colapsa na série do slug real, o aninhamento pode ter qualquer
 * profundidade, e o carimbo que sobrevive é o EXTERNO.
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Recorte da classe: só o que a leitura de série usa.
 */
final class F3Base_Imp_Plugins {

	/** Marca de reconhecimento de cópia preservada, sem o ponto. */
	public const MARCA_ANTERIOR = '-f3base-anterior-';

	/** Prefixo de construção de cópia preservada, com o ponto. */
	public const PREFIXO_BACKUP = '.f3base-anterior-';

	/**
	 * Slug e carimbo de um nome de cópia preservada. FUNÇÃO PURA.
	 *
	 * O DEFEITO MEDIDO NA 1.0.14, e a razão desta função existir. O site real
	 * tinha em `wp-content/plugins/` o diretório
	 * `.f3base-anterior-base-site-core-fator3-f3base-anterior-1788152131-1788156801`:
	 * backup de um diretório que JÁ ERA backup. Cortar o slug no último traço
	 * dava `base-site-core-fator3-f3base-anterior-1788152131` — uma série PRÓPRIA,
	 * com uma cópia só, que nunca alcança o teto de 2 e portanto nunca poda. O
	 * log fechou com sete cópias preservadas e a frase "nada acima do teto",
	 * cada palavra verdadeira e a conclusão errada.
	 *
	 * A normalização: marca de backup EMBUTIDA no resto colapsa na série do
	 * slug real. Tudo a partir da marca é carimbo que nós mesmos escrevemos, e
	 * o aninhamento pode ter qualquer profundidade — o laço roda até o nome
	 * parar de mudar. O carimbo que sobrevive é o EXTERNO, que é quando aquela
	 * cópia foi criada.
	 *
	 * @param string $nome Nome do diretório, sem caminho.
	 * @return array{slug:string,quando:int}|array{} Vazio quando não é cópia preservada.
	 */
	public static function serie_do_nome( string $nome ): array {
		if ( ! str_starts_with( $nome, self::PREFIXO_BACKUP ) ) {
			return array();
		}

		$resto = substr( $nome, strlen( self::PREFIXO_BACKUP ) );
		$corte = strrpos( $resto, '-' );

		if ( false === $corte || 0 === $corte ) {
			return array();
		}

		$slug = self::slug_da_serie( substr( $resto, 0, $corte ) );

		if ( '' === $slug ) {
			return array();
		}

		return array(
			'slug'   => $slug,
			'quando' => (int) substr( $resto, $corte + 1 ),
		);
	}

	/**
	 * Colapsa a marca de backup embutida num slug. FUNÇÃO PURA.
	 *
	 * As duas grafias da marca entram: a de CONSTRUÇÃO, com o ponto na frente
	 * (`PREFIXO_BACKUP`), e a que os backups criados antes da 1.0.13 deixaram em
	 * disco, sem o ponto (`MARCA_ANTERIOR`). Reconhecer o nome antigo é
	 * obrigação da migração — quem o CONSTRÓI de novo é o que
	 * `pacote.backup_sempre_oculto` proíbe.
	 *
	 * @param string $slug Slug extraído do nome do diretório.
	 * @return string Slug do artefato real.
	 */
	public static function slug_da_serie( string $slug ): string {
		$marcas = array( self::PREFIXO_BACKUP, ltrim( self::MARCA_ANTERIOR, '-' ) );

		for ( $volta = 0; $volta < 8; $volta++ ) {
			$antes = $slug;

			/* Marca no INÍCIO: o nome inteiro é cópia de cópia. */
			foreach ( $marcas as $marca ) {
				if ( ! str_starts_with( $slug, $marca ) ) {
					continue;
				}

				$slug  = substr( $slug, strlen( $marca ) );
				$corte = strrpos( $slug, '-' );

				if ( false !== $corte && 0 !== $corte && ctype_digit( substr( $slug, $corte + 1 ) ) ) {
					$slug = substr( $slug, 0, $corte );
				}
			}

			/* Marca EMBUTIDA: `<slug real>-<marca><carimbo>`. */
			$posicao = false;

			foreach ( $marcas as $marca ) {
				$achou = strpos( $slug, '-' . $marca );

				if ( false !== $achou && ( false === $posicao || $achou < $posicao ) ) {
					$posicao = $achou;
				}
			}

			if ( false !== $posicao ) {
				$slug = substr( $slug, 0, $posicao );
			}

			if ( $antes === $slug ) {
				break;
			}
		}

		return $slug;
	}
}
