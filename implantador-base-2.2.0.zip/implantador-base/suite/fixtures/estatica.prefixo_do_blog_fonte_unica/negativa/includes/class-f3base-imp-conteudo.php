<?php
/**
 * Fixture: o produtor único do caminho dos posts.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Conteúdo gerenciado.
 */
final class F3Base_Imp_Conteudo {

	/**
	 * A âncora do produtor único do caminho dos posts.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_do_prefixo_do_blog(): array {
		return array(
			'funcao'  => 'prefixo_do_blog',
			'caminho' => 'conteudo.blog.prefixo',
		);
	}

	/**
	 * O prefixo declarado, lido de um lugar só.
	 *
	 * @return string
	 */
	public static function prefixo_do_blog(): string {
		return (string) F3Base_Imp_Config::obter( 'conteudo.blog.prefixo', '' );
	}

	/**
	 * Os três caminhos derivados do prefixo.
	 *
	 * @param string $prefixo   Prefixo.
	 * @param string $categoria Segmento de categoria.
	 * @param string $titulo    Título do índice.
	 * @return array<string,mixed>
	 */
	public static function derivados_do_blog( string $prefixo, string $categoria, string $titulo ): array {
		return array(
			'ok'                => '' !== $prefixo && '' !== $categoria && '' !== $titulo,
			'estrutura'         => '/' . $prefixo . '/%postname%/',
			'base_de_categoria' => $prefixo . '/' . $categoria,
			'slug'              => $prefixo,
			'titulo'            => $titulo,
		);
	}
}
