<?php
/**
 * Fixture NEGATIVA: o SEGUNDO leitor do prefixo, e a estrutura remontada à mão.
 *
 * O defeito plantado é o da 2.1.0 na forma que ele voltaria a ter: um ponto do
 * código lê a chave do prefixo por conta própria e monta a estrutura de
 * permalink outra vez. Os dois lugares concordam hoje e discordam na primeira
 * edição — e nada acusa, porque cada um sozinho está certo.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Lotes.
 */
final class F3Base_Imp_Lotes {

	/**
	 * A etapa que grava as options do núcleo, decidindo o caminho por conta própria.
	 *
	 * @return string
	 */
	public static function etapa_opcoes_wp(): string {
		$prefixo = (string) F3Base_Imp_Config::obter( 'conteudo.blog.prefixo', '' );

		return '/' . $prefixo . '/%postname%/';
	}
}
