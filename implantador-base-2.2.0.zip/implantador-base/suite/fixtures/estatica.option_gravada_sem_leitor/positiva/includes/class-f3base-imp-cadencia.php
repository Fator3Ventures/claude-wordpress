<?php
/**
 * Fixture POSITIVA: a MESMA gravação, e agora alguém lê a option de volta.
 *
 * É a diferença inteira entre "gravei" e "configurei": o valor gravado volta a
 * ser lido por uma linha do pacote, e é a leitura que faz o número significar
 * alguma coisa. `blog_public` continua aqui, e continua sem ser acusada.
 *
 * O literal mudou junto com o da fixture negativa, e pelo mesmo motivo: nome de
 * option do PLUGIN é preservado pela renomeação e sairia do escopo do detector
 * no pacote renomeado.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Cadencia {

	public const OPTION_CADENCIA = 'f3base_piso_da_cadencia';

	public static function agendar(): void {
		F3Base_Imp_Gravador::gravar(
			self::OPTION_CADENCIA,
			array(
				'apos_n_ajustes' => (int) F3Base_Imp_Config::obter( 'cadencia_relatorio.apos_n_ajustes', 0 ),
			),
			array( 'autoload' => false )
		);

		F3Base_Imp_Gravador::gravar( 'f3base_release', '1.0.0' );
		update_option( 'blog_public', 1 );
	}

	public static function alvo_de_ajustes(): int {
		$cadencia = get_option( self::OPTION_CADENCIA, array() );

		return is_array( $cadencia ) ? (int) ( $cadencia['apos_n_ajustes'] ?? 0 ) : 0;
	}

	public static function release(): string {
		return (string) get_option( 'f3base_release', '' );
	}
}
