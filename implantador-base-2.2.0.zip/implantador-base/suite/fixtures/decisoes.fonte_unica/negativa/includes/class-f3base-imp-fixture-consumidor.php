<?php
/**
 * Consumidor com as tres formas de segunda fonte.
 */
class F3Base_Imp_Fixture_Consumidor {

	/**
	 * Constante com o valor da decisao: segunda copia que concorda por coincidencia.
	 */
	public const COOP = 'same-origin-allow-popups';

	/**
	 * Leitura pela configuracao, que nao conhece mais a chave: devolve vazio calado.
	 *
	 * @return string
	 */
	public static function politica(): string {
		return (string) F3Base_Imp_Config::obter( 'cabecalhos.referrer_policy', '' );
	}

	/**
	 * Leitura pelo produtor, mas com o valor repetido como PADRAO.
	 *
	 * @return string
	 */
	public static function periodicidade(): string {
		return (string) F3Base_Imp_Decisoes::valor( 'cadencia_relatorio.periodicidade', 'quinzenal' );
	}
}
