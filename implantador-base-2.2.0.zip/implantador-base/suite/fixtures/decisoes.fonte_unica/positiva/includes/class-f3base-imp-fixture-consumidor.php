<?php
/**
 * Consumidor correto: le pelo produtor unico, sem padrao repetido.
 */
class F3Base_Imp_Fixture_Consumidor {

	/**
	 * A politica de referrer aplicada.
	 *
	 * @return string
	 */
	public static function politica(): string {
		return (string) F3Base_Imp_Decisoes::valor( 'cabecalhos.referrer_policy' );
	}

	/**
	 * O slug do plugin de SEO, pelo papel e nunca por constante.
	 *
	 * @return string
	 */
	public static function slug_do_seo(): string {
		return F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.0', 'slug' );
	}
}
