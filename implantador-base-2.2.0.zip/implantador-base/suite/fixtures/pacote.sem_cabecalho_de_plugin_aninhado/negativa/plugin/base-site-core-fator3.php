<?php
/**
 * Plugin Name:       Base Site Core Fator3
 * Description:       O DEFEITO PLANTADO: fonte do plugin persistente a UM nível da raiz.
 *                    get_plugins() alcança este arquivo, ordena por Name, "F3 Base Site
 *                    Core" vem antes de "Implantador Base F3", e o link "Ativar plugin"
 *                    da tela de instalação passa a apontar para cá.
 * Version:           0.0.0
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );
