<?php
/**
 * Fixture NEGATIVA: o plugin de SEO concorre pelo /llms.txt — a chave é derivada
 * da mesma decisão que liga o módulo do site-core, e a seleção curada é gravada
 * em wpseo_llmstxt, com chaves que o plugin não lê.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Adaptador de SEO com o defeito da 2.0.0.
 */
final class F3Base_Imp_Seo {

	/**
	 * Chaves gerais.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_geral(): array {
		$chaves = array(
			'tracking'        => false,
			'enable_llms_txt' => (bool) F3Base_Imp_Decisoes::valor( 'bots_ia.llms_txt' ),
		);

		return F3Base_Imp_Gravador::gravar_chaves( 'wpseo', $chaves, array() );
	}

	/**
	 * Seleção gravada na option do plugin.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_llms(): array {
		$chaves = array(
			'privacy_policy' => 0,
			'manual'         => true,
			'pages'          => array( 14, 15 ),
		);

		return F3Base_Imp_Gravador::gravar_chaves( 'wpseo_llmstxt', $chaves, array() );
	}
}
