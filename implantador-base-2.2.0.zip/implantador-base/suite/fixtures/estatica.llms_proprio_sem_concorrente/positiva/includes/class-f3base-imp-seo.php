<?php
/**
 * Fixture POSITIVA: o plugin de SEO não concorre — a chave é o literal false, a
 * seleção curada não vai para o plugin, e a unidade própria relê o endereço.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Adaptador de SEO como a 2.1.0 o deixou.
 */
final class F3Base_Imp_Seo {

	/**
	 * Chaves gerais.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_geral(): array {
		$chaves = array(
			'tracking'        => false,
			'enable_llms_txt' => false,
		);

		return F3Base_Imp_Gravador::gravar_chaves( 'wpseo', $chaves, array() );
	}

	/**
	 * O endereço é do site-core: relê a chave, remove o agendamento, apaga o arquivo dele.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_llms_proprio(): array {
		$wpseo  = get_option( 'wpseo', array() );
		$ligada = is_array( $wpseo ) && ! empty( $wpseo['enable_llms_txt'] );

		wp_clear_scheduled_hook( 'wpseo_llms_txt_population' );

		$arquivo = ABSPATH . 'llms.txt';

		if ( file_exists( $arquivo ) ) {
			wp_delete_file( $arquivo );
		}

		return array( 'estado' => $ligada ? 'FALHA' : 'OK' );
	}
}
