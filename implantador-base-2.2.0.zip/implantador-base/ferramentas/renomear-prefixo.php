<?php
/**
 * Renomeação de prefixo: transforma o template numa base de site novo.
 *
 * A ORDEM É A DO ARQUIVO. Primeiro recusa, depois reescreve conteúdo, depois
 * renomeia caminho, depois apaga a saída de build do prefixo antigo, e só então
 * relata. Renomear caminho antes de reescrever conteúdo faria a varredura
 * seguinte procurar arquivos que já mudaram de nome.
 *
 * O QUE ESTA FERRAMENTA NÃO FAZ, e é deliberado:
 *
 * - **Não inventa identidade.** Nome do site, tagline, cores, tipografia,
 *   logotipo e conteúdo não são prefixo: mudam por arquivo e por chave, e o
 *   procedimento está em `TEMPLATE.md`. O que muda aqui é o que está preso ao
 *   PREFIXO — nomes de arquivo e de diretório, prefixo de classe PHP, text
 *   domain, slugs de tema e de plugin, options, metas, classes CSS, handles e as
 *   chaves de configuração que os carregam.
 * - **Não reescreve o registro da origem nem a memória de decisões.** As
 *   exceções são declaradas em `ferramentas/excecoes-de-prefixo.tsv`, com o
 *   motivo de cada uma, e `estatica.sem_residuo_de_prefixo` confere que nada
 *   sobrou FORA delas.
 * - **NÃO TOCA NO PLUGIN, nem na fonte dele nem no contrato de nomes dele.**
 *   Até a 1.6.6 esta ferramenta varria a raiz inteira e renomeava também
 *   `fontes/site-core/`: cada site produzia um FORK do plugin, com options
 *   `<prefixo>_ga4_measurement_id` em vez de `f3base_ga4_measurement_id`. Um
 *   plugin com release própria cujo nome de option muda por site não é um
 *   plugin: são N plugins parecidos, e nenhuma correção publicada alcança
 *   nenhum deles. A exclusão tem duas metades, e as duas são declaradas em
 *   arquivo:
 *
 *   1. `partilhado/` (a cópia vendorizada) e `assets/plugins/` (a reserva, o
 *      zip publicado) estão em `ferramentas/excecoes-de-prefixo.tsv` — a
 *      ferramenta não os atravessa. Desde a 2.0.0 a FONTE do plugin não mora
 *      nesta árvore; o que sobrou dela aqui é isso;
 *   2. `partilhado/dados/contrato-de-nomes.tsv` — cópia conferida por hash do
 *      contrato do plugin — declara as GRAFIAS que
 *      sobrevivem em qualquer arquivo, inclusive nos que SÃO renomeados. Sem
 *      esta segunda metade o implantador renomeado passaria a gravar
 *      `acme_ga4_measurement_id` e o plugin continuaria lendo
 *      `f3base_ga4_measurement_id`: configuração órfã, sem erro nenhum.
 * - **Não renomeia o já renomeado.** A busca é sempre pelo prefixo de ORIGEM
 *   declarado em `ferramentas/prefixo-do-template.tsv`, que esta ferramenta não
 *   toca. É daí que vem a idempotência: a segunda rodada com o mesmo prefixo não
 *   encontra nada e não muda nada.
 *
 * @package F3Base\Ferramentas
 */

declare( strict_types = 1 );

/*
 * A REGRA DO QUE NÃO SE REESCREVE MORA EM UM ARQUIVO SÓ, e é lida também por
 * `estatica.sem_residuo_de_prefixo`: aqui ela diz o que MASCARAR antes de
 * substituir, lá diz o que NÃO ACUSAR depois. Duas cópias divergiriam na
 * primeira linha acrescentada, e a divergência apareceria como um pacote
 * renomeado que passa na ferramenta e reprova no detector — ou pior, o
 * contrário.
 */
require_once __DIR__ . '/nomes-preservados.php';

/**
 * Lê um TSV declarado, ignorando comentário e linha vazia.
 *
 * @param string $caminho Caminho absoluto.
 * @return array<int,array<int,string>>
 */
function f3b_tabela( string $caminho ): array {
	if ( ! is_file( $caminho ) ) {
		return array();
	}

	$linhas = array();

	foreach ( explode( "\n", (string) file_get_contents( $caminho ) ) as $linha ) {
		$linha = rtrim( $linha, "\r" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$linhas[] = explode( "\t", $linha );
	}

	return $linhas;
}

/**
 * As três grafias do prefixo de origem, declaradas.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<string,string>
 */
function f3b_prefixo_do_template( string $raiz ): array {
	$saida = array();

	foreach ( f3b_tabela( $raiz . '/ferramentas/prefixo-do-template.tsv' ) as $linha ) {
		$papel = trim( $linha[0] ?? '' );
		$valor = trim( $linha[1] ?? '' );

		if ( '' !== $papel && '' !== $valor ) {
			$saida[ $papel ] = $valor;
		}
	}

	return $saida;
}

/**
 * Extensões de arquivo cujo CONTEÚDO é reescrito.
 *
 * Lista declarada num lugar só, lida também pelo detector de resíduo. Binário
 * fica de fora: reescrever bytes de PNG por casamento de texto corrompe a
 * imagem sem que nada acuse. SVG entra — é texto, e carrega classe e id.
 *
 * @return array<int,string>
 */
function f3b_extensoes_de_texto(): array {
	return array( 'php', 'js', 'mjs', 'json', 'md', 'html', 'htm', 'css', 'tsv', 'txt', 'sh', 'svg', 'xml', 'pot', 'po' );
}

/**
 * Caminhos que a renomeação NÃO toca, com o motivo declarado.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<string,string> caminho => motivo.
 */
function f3b_excecoes_de_prefixo( string $raiz ): array {
	$saida = array();

	foreach ( f3b_tabela( $raiz . '/ferramentas/excecoes-de-prefixo.tsv' ) as $linha ) {
		$caminho = trim( $linha[0] ?? '' );
		$motivo  = trim( $linha[1] ?? '' );

		if ( '' !== $caminho ) {
			$saida[ $caminho ] = $motivo;
		}
	}

	return $saida;
}

/**
 * O caminho relativo está coberto por uma exceção declarada?
 *
 * @param string               $rel      Caminho relativo.
 * @param array<string,string> $excecoes Exceções declaradas.
 * @return bool
 */
function f3b_coberto_por_excecao( string $rel, array $excecoes ): bool {
	foreach ( array_keys( $excecoes ) as $caminho ) {
		if ( str_ends_with( $caminho, '/' ) ) {
			if ( str_starts_with( $rel, $caminho ) ) {
				return true;
			}

			continue;
		}

		if ( $rel === $caminho ) {
			return true;
		}
	}

	return false;
}

/**
 * Por que este prefixo é recusado, ou vazio quando ele serve.
 *
 * @param string $novo Prefixo pedido.
 * @param string $raiz Raiz do pacote.
 * @return string
 */
function f3b_recusa_do_prefixo( string $novo, string $raiz ): string {
	$origem = f3b_prefixo_do_template( $raiz );

	if ( '' === $novo ) {
		return 'prefixo vazio: sem prefixo não há nome de tema, de option nem de classe a escrever.';
	}

	if ( 1 !== preg_match( '/^[a-z][a-z0-9-]*$/', $novo ) ) {
		return 'prefixo fora de [a-z][a-z0-9-]: "' . $novo . '". Ele vira nome de diretório, slug de tema, prefixo de option e prefixo de classe PHP, '
			. 'e cada um desses lugares recusa um caractere diferente — maiúscula, sublinhado, ponto e acento incluídos.';
	}

	if ( 2 > strlen( $novo ) ) {
		return 'prefixo de uma letra: "' . $novo . '". Colisão com qualquer coisa é questão de tempo, e o log fica ilegível.';
	}

	if ( $novo === ( $origem['tecnico'] ?? '' ) ) {
		return 'o prefixo pedido é o do PRÓPRIO TEMPLATE ("' . $novo . '"): dois sites da operação não podem compartilhar nome de tema nem de option, '
			. 'e renomear para a origem é não renomear.';
	}

	foreach ( f3b_tabela( $raiz . '/ferramentas/prefixos-recusados.tsv' ) as $linha ) {
		$regra  = trim( $linha[0] ?? '' );
		$valor  = trim( $linha[1] ?? '' );
		$motivo = trim( $linha[2] ?? '' );

		if ( '' === $valor ) {
			continue;
		}

		if ( 'igual' === $regra && $novo === $valor ) {
			return 'prefixo recusado por "' . $valor . '" (regra: igual): ' . $motivo;
		}

		if ( 'comeca-com' === $regra && str_starts_with( $novo, $valor ) ) {
			return 'prefixo recusado por começar com "' . $valor . '": ' . $motivo;
		}
	}

	return '';
}

/**
 * O mapa de substituição, da grafia mais específica para a mais geral.
 *
 * @param array<string,string> $origem Prefixo de origem declarado.
 * @param string               $novo   Prefixo novo.
 * @return array<string,string>
 */
function f3b_mapa_de_substituicao( array $origem, string $novo ): array {
	$partes    = array_values( array_filter( explode( '-', $novo ) ) );
	$pascal    = implode( '', array_map( 'ucfirst', $partes ) );
	$exibicao  = implode( ' ', array_map( 'ucfirst', $partes ) );
	$sublinhado = str_replace( '-', '_', $novo );

	$tecnico   = (string) ( $origem['tecnico'] ?? '' );
	$abreviado = (string) ( $origem['abreviado'] ?? '' );
	$mostrado  = (string) ( $origem['exibicao'] ?? '' );

	$mapa = array();

	if ( '' !== $tecnico ) {
		$mapa[ strtoupper( $tecnico ) ]              = strtoupper( $sublinhado );
		$mapa[ ucfirst( $tecnico ) ]                 = ucfirst( $novo );
		$mapa[ f3b_pascal_do_prefixo( $tecnico ) ]   = $pascal;
		$mapa[ $tecnico ]                            = $novo;
	}

	if ( '' !== $abreviado ) {
		$mapa[ strtoupper( $abreviado ) ] = strtoupper( $sublinhado ) . '_';
		$mapa[ $abreviado ]               = $sublinhado . '_';
	}

	if ( '' !== $mostrado ) {
		$mapa[ $mostrado ] = $exibicao;
	}

	/* Grafias longas antes das curtas: `F3BASE_IMP` precisa casar antes de `f3base`. */
	uksort(
		$mapa,
		static function ( string $a, string $b ): int {
			return strlen( $b ) <=> strlen( $a );
		}
	);

	return $mapa;
}

/**
 * A grafia PascalCase de um prefixo técnico: `f3base` vira `F3Base`.
 *
 * Não é `ucfirst`: o prefixo do template mistura dígito e letra, e a grafia que
 * o código usa é a que o pacote escreve nas classes.
 *
 * @param string $tecnico Prefixo técnico.
 * @return string
 */
function f3b_pascal_do_prefixo( string $tecnico ): string {
	return (string) preg_replace_callback(
		'/(?:^|[0-9-])([a-z])/',
		static fn( array $m ): string => str_replace( $m[1], strtoupper( $m[1] ), $m[0] ),
		$tecnico
	);
}

/**
 * Aplica o mapa a um texto, preservando o contrato de nomes do plugin.
 *
 * A PRESERVAÇÃO É POR MÁSCARA, e não por uma entrada identidade no mapa. O
 * motivo é o comportamento de `str_replace()` com arrays: ele aplica cada par
 * SOBRE O TEXTO INTEIRO, um depois do outro. Uma entrada
 * `f3base-secao- => f3base-secao-` não protegeria nada, porque a substituição
 * seguinte — `f3base => acme` — voltaria a encontrar o `f3base` que a primeira
 * acabou de reescrever igual. A máscara tira a grafia do texto antes de
 * qualquer substituição e a devolve depois, e é a única forma de o resultado
 * não depender da ordem do mapa.
 *
 * O sentinela é `\\0<índice>\\0`, e as duas escolhas são deliberadas: byte nulo
 * porque a reescrita só roda sobre as extensões de texto declaradas e nenhuma
 * delas o carrega — um sentinela de caracteres imprimíveis poderia existir no
 * arquivo —, e só dígitos no meio porque toda grafia do mapa é de letras: um
 * sentinela que contivesse letras poderia ser reescrito pelo próprio mapa que
 * ele existe para atravessar.
 *
 * @param string               $texto        Texto.
 * @param array<string,string> $mapa         Mapa.
 * @param array<int,string>    $preservados  Grafias que não podem ser tocadas.
 * @return string
 */
function f3b_aplicar_mapa( string $texto, array $mapa, array $preservados = array() ): string {
	$mascaras = array();

	foreach ( $preservados as $i => $grafia ) {
		if ( '' === $grafia || ! str_contains( $texto, $grafia ) ) {
			continue;
		}

		$sentinela              = "\0" . $i . "\0";
		$mascaras[ $sentinela ] = $grafia;
		$texto                  = str_replace( $grafia, $sentinela, $texto );
	}

	$texto = str_replace( array_keys( $mapa ), array_values( $mapa ), $texto );

	if ( array() === $mascaras ) {
		return $texto;
	}

	return str_replace( array_keys( $mascaras ), array_values( $mascaras ), $texto );
}

/**
 * Lista recursiva de arquivos, sem a saída de build.
 *
 * @param string $raiz Raiz.
 * @return array<int,string> Caminhos relativos, em ordem.
 */
function f3b_arquivos_do_pacote( string $raiz ): array {
	$saida = array();
	$iter  = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::SELF_FIRST
	);

	foreach ( $iter as $item ) {
		if ( ! $item->isFile() ) {
			continue;
		}

		$rel = ltrim( substr( $item->getPathname(), strlen( rtrim( $raiz, '/' ) ) ), '/' );

		if ( str_starts_with( $rel, 'dist/' ) ) {
			continue;
		}

		$saida[] = $rel;
	}

	sort( $saida );

	return $saida;
}

/**
 * Lista recursiva de diretórios, do mais fundo para o mais raso.
 *
 * @param string $raiz Raiz.
 * @return array<int,string> Caminhos relativos.
 */
function f3b_diretorios_do_pacote( string $raiz ): array {
	$saida = array();
	$iter  = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $iter as $item ) {
		if ( $item->isFile() ) {
			continue;
		}

		$rel = ltrim( substr( $item->getPathname(), strlen( rtrim( $raiz, '/' ) ) ), '/' );

		if ( '' !== $rel && ! str_starts_with( $rel, 'dist/' ) ) {
			$saida[] = $rel;
		}
	}

	usort( $saida, static fn( string $a, string $b ): int => substr_count( $b, '/' ) <=> substr_count( $a, '/' ) );

	return $saida;
}

/**
 * Esvazia um diretório, mantendo o diretório.
 *
 * @param string $dir Diretório absoluto.
 * @return int Quantos arquivos saíram.
 */
function f3b_esvaziar( string $dir ): int {
	if ( ! is_dir( $dir ) ) {
		return 0;
	}

	$saiu = 0;

	foreach ( (array) scandir( $dir ) as $nome ) {
		$nome = (string) $nome;

		if ( '.' === $nome || '..' === $nome ) {
			continue;
		}

		$alvo = $dir . '/' . $nome;

		if ( is_dir( $alvo ) ) {
			$saiu += f3b_esvaziar( $alvo );
			rmdir( $alvo );
			continue;
		}

		if ( unlink( $alvo ) ) {
			$saiu++;
		}
	}

	return $saiu;
}

/* =========================================================================
 * EXECUÇÃO
 * ====================================================================== */

$raiz = rtrim( (string) ( $argv[1] ?? '' ), '/' );
/*
 * O PREFIXO PEDIDO ENTRA COMO FOI ESCRITO. Baixar a caixa aqui aceitaria
 * `Acme` em silêncio e renomearia o pacote para `acme` sem que ninguém tivesse
 * pedido isso — corrigir a entrada do operador é decidir por ele. A recusa por
 * caractere fora de [a-z][a-z0-9-] é o que precisa acontecer, e ela precisa ver
 * o texto original para poder acontecer.
 */
$novo = trim( (string) ( $argv[2] ?? '' ) );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	fwrite( STDERR, "uso: renomear-prefixo.php <caminho-do-pacote> <prefixo-novo>\n" );
	exit( 2 );
}

if ( ! is_file( $raiz . '/config/site.json' ) || ! is_file( $raiz . '/ferramentas/prefixo-do-template.tsv' ) ) {
	fwrite( STDERR, "RECUSADO: " . $raiz . " não parece um pacote deste template (falta config/site.json ou ferramentas/prefixo-do-template.tsv).\n" );
	exit( 2 );
}

$recusa = f3b_recusa_do_prefixo( $novo, $raiz );

if ( '' !== $recusa ) {
	fwrite( STDERR, 'RECUSADO: ' . $recusa . "\n" );
	exit( 2 );
}

$origem     = f3b_prefixo_do_template( $raiz );
$mapa       = f3b_mapa_de_substituicao( $origem, $novo );
$excecoes   = f3b_excecoes_de_prefixo( $raiz );
$textos     = f3b_extensoes_de_texto();
$contrato   = f3b_np_preservados( $raiz );

if ( array() === $contrato ) {
	fwrite(
		STDERR,
		"RECUSADO: partilhado/dados/contrato-de-nomes.tsv ausente ou vazio. Sem ele esta ferramenta reescreveria as options, "
		. "as tabelas e os eventos que o plugin lê, do lado de quem GRAVA e não do lado de quem LÊ: o site ficaria com o implantador "
		. "gravando <prefixo>_ga4_measurement_id e o plugin lendo f3base_ga4_measurement_id, sem erro nenhum e com a configuração órfã. "
		. "Renomear sem o contrato é pior do que não renomear.\n"
	);
	exit( 2 );
}

echo "== renomeação de prefixo ==\n";
echo '   de: ' . implode( ' · ', array_values( $origem ) ) . "\n";
echo '   para: ' . implode( ' · ', array_values( array_unique( array_values( $mapa ) ) ) ) . "\n";
echo '   exceções de caminho declaradas: ' . count( $excecoes ) . "\n";
echo '   grafias preservadas pelo contrato do plugin: ' . count( $contrato ) . "\n\n";

$reescritos = array();
$pulados    = array();

foreach ( f3b_arquivos_do_pacote( $raiz ) as $rel ) {
	if ( f3b_coberto_por_excecao( $rel, $excecoes ) ) {
		$pulados[] = $rel;
		continue;
	}

	if ( ! in_array( strtolower( (string) pathinfo( $rel, PATHINFO_EXTENSION ) ), $textos, true ) ) {
		continue;
	}

	$antes  = (string) file_get_contents( $raiz . '/' . $rel );
	$depois = f3b_aplicar_mapa( $antes, $mapa, $contrato );

	if ( $antes === $depois ) {
		continue;
	}

	file_put_contents( $raiz . '/' . $rel, $depois );
	$reescritos[] = $rel;
}

/* Caminhos DEPOIS do conteúdo: renomear antes faria a varredura procurar o que já mudou de nome. */
$renomeados = array();

foreach ( f3b_arquivos_do_pacote( $raiz ) as $rel ) {
	if ( f3b_coberto_por_excecao( $rel, $excecoes ) ) {
		continue;
	}

	$base = basename( $rel );
	$novo_base = f3b_aplicar_mapa( $base, $mapa, $contrato );

	if ( $base === $novo_base ) {
		continue;
	}

	$destino = ( '' !== dirname( $rel ) && '.' !== dirname( $rel ) ? dirname( $rel ) . '/' : '' ) . $novo_base;

	if ( rename( $raiz . '/' . $rel, $raiz . '/' . $destino ) ) {
		$renomeados[] = $rel . ' → ' . $destino;
	}
}

foreach ( f3b_diretorios_do_pacote( $raiz ) as $rel ) {
	if ( f3b_coberto_por_excecao( $rel . '/', $excecoes ) ) {
		continue;
	}

	$base = basename( $rel );
	$novo_base = f3b_aplicar_mapa( $base, $mapa, $contrato );

	if ( $base === $novo_base ) {
		continue;
	}

	$destino = ( '' !== dirname( $rel ) && '.' !== dirname( $rel ) ? dirname( $rel ) . '/' : '' ) . $novo_base;

	if ( rename( $raiz . '/' . $rel, $raiz . '/' . $destino ) ) {
		$renomeados[] = $rel . '/ → ' . $destino . '/';
	}
}

/*
 * A saída de build pertence ao PREFIXO ANTIGO: os zips embutidos, o bundle e o
 * lock trazem o nome e o conteúdo de antes. Mantê-los seria deixar no pacote um
 * artefato que afirma ser outro pacote. O comando único regrava tudo na próxima
 * rodada, que é a etapa seguinte do procedimento.
 *
 * SÓ QUANDO ALGO MUDOU, e é aqui que a idempotência se completa: numa rodada
 * que não reescreveu nem renomeou nada, `dist/` é a saída do prefixo ATUAL, e
 * apagá-la seria a segunda rodada mudando o pacote — exatamente o que a
 * promessa de idempotência diz que não acontece.
 */
$mudou    = array() !== $reescritos || array() !== $renomeados;
$apagados = $mudou ? f3b_esvaziar( $raiz . '/dist' ) : 0;

echo '   arquivos com conteúdo reescrito: ' . count( $reescritos ) . "\n";
echo '   caminhos renomeados: ' . count( $renomeados ) . "\n";
echo '   arquivos preservados por exceção declarada: ' . count( $pulados ) . ( array() === $pulados ? '' : ' (' . implode( ', ', $pulados ) . ')' ) . "\n";
echo '   saída de build do prefixo antigo removida: ' . ( $mudou ? $apagados . ' arquivo(s) de dist/' : 'nada a remover — nenhuma mudança nesta rodada, e dist/ é a saída do prefixo atual' ) . "\n\n";

if ( array() === $reescritos && array() === $renomeados ) {
	echo "nada a fazer: nenhuma ocorrência do prefixo de origem sobrou fora das exceções declaradas.\n";
	echo "Se esta é a segunda rodada com o mesmo prefixo, é exatamente o resultado esperado.\n";
	exit( 0 );
}

echo "renomeação concluída. Os dois passos seguintes são de TEMPLATE.md e nenhum deles é opcional:\n";
echo "  1. rodar o comando único sobre o pacote renomeado — ele regrava dist/ e confere estatica.sem_residuo_de_prefixo;\n";
echo "  2. trocar identidade, conteúdo e contato, e só então desligar conteudo.demonstrativo.\n";

exit( 0 );
