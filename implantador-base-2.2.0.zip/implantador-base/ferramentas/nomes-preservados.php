<?php
/**
 * O QUE A RENOMEAÇÃO DE PREFIXO NÃO REESCREVE — regra compartilhada, arquivo ÚNICO.
 *
 * Dois lugares precisam da MESMA resposta, e por razões opostas:
 * `ferramentas/renomear-prefixo.php` precisa saber o que MASCARAR antes de
 * substituir, e `estatica.sem_residuo_de_prefixo` precisa saber o que NÃO
 * ACUSAR depois. Uma resposta que existisse só de um lado seria uma exceção que
 * não protege nada — ou um detector que reprova o pacote correto.
 *
 * SÃO DUAS FONTES, e as duas são declaradas:
 *
 * 1. `partilhado/dados/contrato-de-nomes.tsv` — a cópia VENDORIZADA do contrato
 *    do plugin, conferida por hash contra o zip publicado — as grafias que o PLUGIN é
 *    dono: options, tabelas, eventos, namespace REST, classes compartilhadas,
 *    hook da cadência e o prefixo da classe que marca seção medida. Elas
 *    sobrevivem porque o implantador RENOMEADO continua gravando
 *    `f3base_ga4_measurement_id`, que é o que o plugin lê.
 *
 * 2. TODA GRAFIA COM O PREFIXO QUE APARECE DENTRO DO PLUGIN — lida DE DENTRO
 *    DA RESERVA, `assets/plugins/<slug>-<versão>.zip`, que é o zip publicado
 *    copiado para a árvore — e dentro de `partilhado/`, a cópia vendorizada
 *    que a renomeação não atravessa. Derivada de disco, nunca digitada. A regra
 *    é uma frase só: **o plugin não é renomeado, então tudo que ele escreve
 *    continua escrito assim** — e todo lugar de fora que escreve a mesma coisa
 *    tem de continuar escrevendo-a. Até a 1.7.4 a derivação lia `fontes/plugin/`;
 *    desde a 2.0.0 a fonte não mora aqui, e o que responde é o artefato que o
 *    site recebe. Nome de arquivo (`class-f3base-options.php`), nome de classe
 *    (`F3Base_Modulo_Tracking`), handle de asset (`f3base-tracking`), atributo
 *    de DOM (`data-f3base-consentimento`), classe de CSS
 *    (`f3base-consentimento-banner`), variável de JavaScript
 *    (`f3baseTrackingDados`), código de erro da rota
 *    (`f3base_armazenamento_indisponivel`), option, tabela, evento.
 *
 *    FOI ISTO QUE FALTOU NA PRIMEIRA TENTATIVA DA 1.7.0, e o pacote renomeado
 *    mostrou em três camadas: `suite/inventario.tsv` foi reescrito e o
 *    empacotamento abortou com trinta arquivos "FORA DO INVENTÁRIO"; o
 *    implantador passou a gravar `acme_operaveis` enquanto o plugin continuava
 *    lendo `f3base_operaveis`; e as bancadas de JavaScript passaram a procurar
 *    o handle `acme-tracking` num cliente que se registra como
 *    `f3base-tracking`. Nenhum desses três é o mesmo defeito, e os três têm a
 *    mesma causa: a fronteira entre os dois artefatos é falada, e só um dos
 *    lados trocou de língua.
 *
 * A SEGUNDA FONTE É DERIVADA, e não uma lista escrita à mão, pela razão de
 * sempre: lista escrita à mão envelhece no primeiro arquivo novo dentro do
 * plugin, e o defeito volta calado. A PRIMEIRA continua existindo porque a
 * derivação não alcança tudo — `f3base/v1` tem uma barra e não é um token de
 * identificador — e, principalmente, porque ela é onde o MOTIVO de cada grafia
 * está escrito. A derivação é mecânica; a declaração é o que se lê.
 *
 * O QUE A DERIVAÇÃO NÃO PRESERVA, e é o que a mantém honesta: a grafia NUA do
 * prefixo. `f3base` sozinho, `F3Base` sozinho e `F3BASE` sozinho continuam
 * sendo trocados, e é por isso que `estatica.sem_residuo_de_prefixo` continua
 * acusando um arquivo que a ferramenta esqueceu — o `F3Base_Imp_Plugins` que
 * sobrou tem `F3Base` sem estar em nenhuma grafia do plugin, e aparece.
 *
 * @package F3Base\Ferramentas
 */

declare( strict_types = 1 );

/**
 * Lê um TSV declarado, ignorando comentário e linha vazia.
 *
 * @param string $caminho Caminho absoluto.
 * @return array<int,array<int,string>>
 */
function f3b_np_tabela( string $caminho ): array {
	if ( ! is_file( $caminho ) ) {
		return array();
	}

	$linhas = array();

	foreach ( explode( "\n", (string) file_get_contents( $caminho ) ) as $linha ) {
		$linha = rtrim( $linha, "\r" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$linhas[] = explode( "\t", $linha );
	}

	return $linhas;
}

/**
 * Os caminhos que a renomeação não atravessa, com o motivo declarado.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<string,string> caminho => motivo.
 */
function f3b_np_excecoes_de_caminho( string $raiz ): array {
	$saida = array();

	foreach ( f3b_np_tabela( $raiz . '/ferramentas/excecoes-de-prefixo.tsv' ) as $linha ) {
		$caminho = trim( $linha[0] ?? '' );
		$motivo  = trim( $linha[1] ?? '' );

		if ( '' !== $caminho ) {
			$saida[ $caminho ] = $motivo;
		}
	}

	return $saida;
}

/**
 * As grafias NUAS do prefixo de origem, em todas as caixas que o mapa usa.
 *
 * São elas que a derivação NÃO preserva: preservar a grafia nua seria preservar
 * tudo, e a renomeação deixaria de existir.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<int,string>
 */
function f3b_np_grafias_nuas( string $raiz ): array {
	$origem = array();

	foreach ( f3b_np_tabela( $raiz . '/ferramentas/prefixo-do-template.tsv' ) as $linha ) {
		$papel = trim( $linha[0] ?? '' );
		$valor = trim( $linha[1] ?? '' );

		if ( '' !== $papel && '' !== $valor ) {
			$origem[ $papel ] = $valor;
		}
	}

	$nuas    = array();
	$tecnico = (string) ( $origem['tecnico'] ?? '' );

	if ( '' !== $tecnico ) {
		$nuas[] = $tecnico;
		$nuas[] = strtoupper( $tecnico );
		$nuas[] = ucfirst( $tecnico );
		$nuas[] = (string) preg_replace_callback(
			'/(?:^|[0-9-])([a-z])/',
			static fn( array $m ): string => str_replace( $m[1], strtoupper( $m[1] ), $m[0] ),
			$tecnico
		);
	}

	foreach ( array( 'abreviado', 'exibicao' ) as $papel ) {
		$valor = (string) ( $origem[ $papel ] ?? '' );

		if ( '' !== $valor ) {
			$nuas[] = $valor;
			$nuas[] = strtoupper( $valor );
		}
	}

	return array_values( array_unique( array_filter( $nuas ) ) );
}

/**
 * As grafias com o prefixo que um TEXTO carrega, sem a nua e sem a nua com separador.
 *
 * Núcleo único da derivação: o leitor de diretório e o leitor de zip passam por
 * aqui, e uma regra só decide o que é nome.
 *
 * @param string            $bruto Conteúdo de um arquivo.
 * @param array<int,string> $nuas  Grafias nuas do prefixo.
 * @return array<int,string>
 */
function f3b_np_grafias_do_texto( string $bruto, array $nuas ): array {
	/* Binário fica de fora por medição: byte nulo nos primeiros 8 KB não é texto. */
	if ( str_contains( substr( $bruto, 0, 8192 ), "\0" ) ) {
		return array();
	}

	$alfabeto = '/[A-Za-z0-9_-]*(?:' . implode( '|', array_map( 'preg_quote', $nuas ) ) . ')[A-Za-z0-9_-]*/';
	$saida    = array();

	if ( ! preg_match_all( $alfabeto, $bruto, $achou ) ) {
		return array();
	}

	foreach ( $achou[0] as $token ) {
		/*
		 * A GRAFIA NUA COM SEPARADOR TAMBÉM NÃO CONTA, e este foi o defeito
		 * que a primeira versão desta derivação produziu. O plugin monta
		 * nomes em tempo de execução — `'f3base-' . $sufixo` para um
		 * transiente, por exemplo —, e o token capturado ali é `f3base-`.
		 * Preservá-lo faz TODO caminho e TODO símbolo do pacote que comece
		 * por `f3base-` sobreviver: medido, a renomeação caiu de 154
		 * caminhos para UM. O que se preserva é NOME, e um separador
		 * sozinho não é nome.
		 */
		$miolo = trim( $token, '-_' );

		if ( '' === $miolo || in_array( $miolo, $nuas, true ) || in_array( $token, $nuas, true ) ) {
			continue;
		}

		$saida[] = $token;
	}

	return array_values( array_unique( $saida ) );
}

/**
 * O QUE DE UM ARQUIVO DO PLUGIN CONTA COMO CÓDIGO — só dali saem grafias.
 *
 * O DEFEITO MEDIDO na 2.0.0, e ele vinha desde que a derivação existe: a
 * varredura lia o arquivo INTEIRO, prosa inclusive, e o próprio contrato de
 * nomes do plugin diz, num comentário, quais options são estado SÓ DO
 * IMPLANTADOR e "viram <prefixo>_* como todo o resto" — nomeando-as. A
 * derivação capturava esses nomes DO COMENTÁRIO e os preservava: o pacote
 * renomeado para `acme` saía com `f3base_lock`, `f3base_checkpoint`,
 * `f3base_journal`, `f3base_estado_aplicacao`, `f3base_release` e
 * `f3base_fases` intactos — quinze grafias ao todo que nenhum código do
 * plugin usa —, `estatica.sem_residuo_de_prefixo` fechava OK porque elas
 * estavam na lista de preservadas, e dois implantadores no mesmo WordPress
 * disputariam o mesmo lock.
 *
 * A regra é a que o nome desta função diz: grafia preservada é grafia que o
 * CÓDIGO do plugin usa, ou que o contrato DECLARA em linha de dados. Prosa
 * não usa nome nenhum — ela fala sobre nomes. PHP passa pelo tokenizador e
 * perde os comentários; JS e CSS perdem os blocos e as linhas de comentário;
 * TSV fica com as linhas de dados; e Markdown ou texto puro não entram.
 *
 * @param string $nome  Caminho ou nome do arquivo (decide pela extensão).
 * @param string $bruto Conteúdo.
 * @return string O que resta para a varredura; vazio para o que é só prosa.
 */
function f3b_np_texto_de_codigo( string $nome, string $bruto ): string {
	$extensao = strtolower( pathinfo( $nome, PATHINFO_EXTENSION ) );

	if ( 'php' === $extensao ) {
		$saida = '';

		foreach ( token_get_all( $bruto ) as $token ) {
			if ( is_array( $token ) ) {
				if ( T_COMMENT === $token[0] || T_DOC_COMMENT === $token[0] ) {
					continue;
				}

				$saida .= $token[1];
			} else {
				$saida .= $token;
			}
		}

		return $saida;
	}

	if ( 'js' === $extensao || 'mjs' === $extensao || 'css' === $extensao ) {
		$sem_blocos = (string) preg_replace( '#/\*.*?\*/#s', '', $bruto );

		if ( 'css' === $extensao ) {
			return $sem_blocos;
		}

		$linhas = array();

		foreach ( explode( "\n", $sem_blocos ) as $linha ) {
			if ( str_starts_with( ltrim( $linha ), '//' ) ) {
				continue;
			}

			$linhas[] = $linha;
		}

		return implode( "\n", $linhas );
	}

	if ( 'tsv' === $extensao ) {
		$linhas = array();

		foreach ( explode( "\n", $bruto ) as $linha ) {
			if ( str_starts_with( ltrim( $linha ), '#' ) ) {
				continue;
			}

			$linhas[] = $linha;
		}

		return implode( "\n", $linhas );
	}

	return '';
}

/**
 * Toda grafia com o prefixo que aparece no CÓDIGO dos arquivos de um diretório.
 *
 * @param string            $base Diretório.
 * @param array<int,string> $nuas Grafias nuas do prefixo.
 * @return array<int,string>
 */
function f3b_np_grafias_do_diretorio( string $base, array $nuas ): array {
	if ( ! is_dir( $base ) ) {
		return array();
	}

	$saida = array();
	$iter  = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::SELF_FIRST
	);

	foreach ( $iter as $item ) {
		if ( ! $item->isFile() ) {
			continue;
		}

		foreach ( f3b_np_grafias_do_texto( f3b_np_texto_de_codigo( $item->getPathname(), (string) file_get_contents( $item->getPathname() ) ), $nuas ) as $token ) {
			$saida[] = $token;
		}
	}

	return array_values( array_unique( $saida ) );
}

/**
 * Toda grafia com o prefixo que aparece no CÓDIGO de dentro da RESERVA do plugin.
 *
 * O zip é lido entrada a entrada por `unzip -p`, sem extrair para a árvore:
 * um diretório extraído ao lado seria uma segunda cópia da fonte do plugin,
 * exatamente o que a 2.0.0 tirou daqui. A reserva é exatamente uma —
 * `assets/plugins/<slug>-<versão>.zip` —, e mais de uma é recusada, porque
 * duas reservas dariam duas listas de grafias e ninguém saberia qual valeu.
 *
 * @param string            $raiz Raiz do pacote.
 * @param array<int,string> $nuas Grafias nuas do prefixo.
 * @return array<int,string>
 */
function f3b_np_grafias_da_reserva( string $raiz, array $nuas ): array {
	$zips = glob( $raiz . '/assets/plugins/*-[0-9]*.[0-9]*.[0-9]*.zip' ) ?: array();

	if ( 1 !== count( $zips ) ) {
		return array();
	}

	$zip     = (string) $zips[0];
	$lista   = array();
	$codigo  = 0;
	exec( sprintf( 'unzip -Z1 %s 2>/dev/null', escapeshellarg( $zip ) ), $lista, $codigo );

	if ( 0 !== $codigo ) {
		return array();
	}

	$saida = array();

	foreach ( $lista as $entrada ) {
		$entrada = (string) $entrada;

		if ( '' === $entrada || str_ends_with( $entrada, '/' ) ) {
			continue;
		}

		$bruto = (string) shell_exec( sprintf( 'unzip -p %s %s 2>/dev/null', escapeshellarg( $zip ), escapeshellarg( $entrada ) ) );

		foreach ( f3b_np_grafias_do_texto( f3b_np_texto_de_codigo( $entrada, $bruto ), $nuas ) as $token ) {
			$saida[] = $token;
		}
	}

	return array_values( array_unique( $saida ) );
}

/**
 * As grafias que sobrevivem em QUALQUER arquivo, inclusive nos renomeados.
 *
 * ORDENADAS DA MAIS LONGA PARA A MAIS CURTA: `f3base_cadencia_estado` precisa
 * ser tratada antes de `f3base_cadencia`, ou a segunda consumiria o começo da
 * primeira e devolveria um nome quebrado.
 *
 * @param string $raiz Raiz do pacote.
 * @return array<int,string>
 */
function f3b_np_preservados( string $raiz ): array {
	$saida = array();

	foreach ( f3b_np_tabela( $raiz . '/partilhado/dados/contrato-de-nomes.tsv' ) as $linha ) {
		$grafia = trim( $linha[1] ?? '' );

		if ( '' !== $grafia ) {
			$saida[] = $grafia;
		}
	}

	$nuas = f3b_np_grafias_nuas( $raiz );

	/*
	 * SÓ O QUE É DO PLUGIN — a cópia vendorizada e a reserva —, e não toda
	 * exceção de caminho. As outras
	 * exceções — `MEMORIA-DECISOES.md`, o registro da origem, a própria lista e
	 * as fixtures do piso do detector — são documentos que PRESERVAM o prefixo
	 * antigo por serem história ou por serem o defeito plantado. Derivar
	 * grafias delas espalharia o prefixo do template para o pacote inteiro pelo
	 * caminho oposto: o que está lá é justamente o que não pode sobreviver fora
	 * dali.
	 */
	foreach ( array( 'partilhado' ) as $diretorio ) {
		foreach ( f3b_np_grafias_do_diretorio( $raiz . '/' . $diretorio, $nuas ) as $grafia ) {
			$saida[] = $grafia;
		}
	}

	foreach ( f3b_np_grafias_da_reserva( $raiz, $nuas ) as $grafia ) {
		$saida[] = $grafia;
	}

	foreach ( array_keys( f3b_np_excecoes_de_caminho( $raiz ) ) as $caminho ) {
		if ( ! str_ends_with( $caminho, '/' ) ) {
			/* Exceção de ARQUIVO: o nome dele já é o que ele é, e ninguém o reescreve. */
			$saida[] = basename( $caminho );
		}
	}

	$saida = array_values( array_unique( array_filter( $saida ) ) );

	usort( $saida, static fn( string $a, string $b ): int => strlen( $b ) <=> strlen( $a ) );

	return $saida;
}
