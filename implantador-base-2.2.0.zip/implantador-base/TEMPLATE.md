# TEMPLATE — como nasce um site novo a partir daqui

Este pacote é um **template de criação de sites**. Ele não é o site de ninguém: é o
site demonstrativo do método, mais as peças que produzem qualquer site desta operação.
O agente que cria um site novo **copia deste pacote** em vez de inventar markup, e a
ordem abaixo é executável de cima para baixo.

Três coisas que este documento não faz, e as três são deliberadas.

- **Não traz número que descreva o estado deste pacote.** Número em documento
  entregável envelhece em silêncio; os que existem saem GERADOS por leitura de disco,
  em `README.md` e `MANIFESTO.md`, e `estatica.carimbo_de_release_nos_documentos` os
  compara com a medição de agora. Número de release que aparece aqui só aparece como
  **história de um defeito medido** — e história não envelhece.
- **Não repete a explicação de nenhuma regra**, que mora em `MEMORIA-DECISOES.md`.
- **Não ensina a mudar o plugin.** Desde a 1.7.0 o `Base Site Core Fator3` é artefato
  próprio, com release própria e documento próprio: `INSTRUCOES-DO-PLUGIN.md`, que viaja
  DENTRO do zip dele. Quem for mexer no plugin lê aquele documento; este aqui só diz
  como um site novo o RECEBE.

---

## Passo 0 — ler o que viaja no pacote, antes de escrever a primeira linha

**Isto não é recomendação: é o primeiro passo, e ele acontece antes da cópia.** Os
documentos que respondem por este método viajam DENTRO do zip, na raiz — `README.md`,
`MANIFESTO.md`, `MEMORIA-DECISOES.md`, este `TEMPLATE.md` e, desde a 2.1.0,
`MAPA-DA-OPERACAO.md` e `INSTRUCOES-CONSTRUCAO-IMPLANTADOR.md`. `MANIFESTO.md`,
`TEMPLATE.md` e os dois novos são cobrados pelo entregável `entrega.documentacao`: ausência
fecha BLOCKED nomeando o arquivo que falta, e o entregável entra no gate de aplicação como
os outros. Quem recebe o zip recebe como usá-lo, e não precisa procurar em outro lugar.

**E leia o PACOTE DO PLUGIN, especialmente.** A diretriz do dono é esta, e ela decide como
o tema e as páginas são construídos: **o `Base Site Core Fator3` é o pacote ESSENCIAL, e
ele sempre é instalado junto** — não existe site desta operação sem ele. O tema e as
páginas que você escrever precisam seguir as regras DELE, senão o plugin fica instalado e
metade dos módulos não encontra o que procura, sem erro nenhum. O documento é
`INSTRUCOES-DO-PLUGIN.md`, que viaja dentro do zip publicado no catálogo, e a habilidade
`f3base/como-usar` responde a mesma coisa dentro do site já instalado.

O que o plugin PROCURA no que este pacote publica, e o que acontece quando não acha:

| O que o plugin procura | Onde o tema ou o conteúdo declara | O que morre calado sem isso |
|---|---|---|
| a classe `f3base-secao-<nome>`, no `className` do bloco **E** na `class` da `div` | patterns do tema e `content/` | seção vista: o observador é instalado e não recebe alvo |
| o botão de contato com a classe `f3base-acao-contato` e o `href` da página canônica de contato | `fontes/tema/patterns/cta-whatsapp.php`, e o tema carimba `data-f3base-lead` no render, em prioridade 5 | o servidor não promove o botão a conversa de WhatsApp: a promoção dele roda em prioridade 10, e carimbar depois é carimbar tarde demais |
| o controle de consentimento no rodapé — `f3base-consentimento-abrir`, com `aria-controls="f3base-consentimento-banner"` | `fontes/tema/parts/footer.html` | o banner não abre, e nenhuma página publicada tem como recolher consentimento |
| o link da política com a classe `f3base-link-privacidade` | rodapé do tema | o `href` da política nunca é preenchido |
| o par `style.css` do tema × cliente do banner (`[hidden]` + `display`) | `fontes/tema/style.css` | o banner nasce visível ou o "Fechar" não fecha — o defeito mora ENTRE os dois artefatos |
| o `theme.json` com o mapa de cores e fontes que o `CONTRASTE.md` prova | `fontes/tema/theme.json` | paleta sem prova de contraste, e `a11y.contraste` reprova |
| o slug do tema em `site.tema_slug` | `config/site.json` | o plugin não sabe qual tema é o do pacote |
| o `wp_navigation` gravado em `f3base_nav_id`, que o tema LÊ | unidade de navegação do implantador | o menu some do cabeçalho: o tema não tem como derivar o ID de um post criado na aplicação |
| o contrato de nomes: options `f3base_*` gravadas pelo implantador e lidas pelo plugin, com `f3base_operaveis` e `f3base_proveniencia` de FRONTEIRA | `partilhado/dados/contrato-de-nomes.tsv` | configuração órfã: quem grava e quem lê deixam de usar o mesmo nome |
| a fronteira do validador — as habilidades de configuração do plugin carregam classes e schemas DESTA árvore | `mcp.fronteira_do_validador` | o agente do outro lado quebra em produção, sem que nenhuma rodada acuse |

---

## Ordem de execução

### 1. Copiar o pacote e renomear o prefixo

```
cp -a implantador-base <pasta-do-site-novo>
bash <pasta-do-site-novo>/ferramentas/renomear-prefixo.sh <prefixo> <pasta-do-site-novo>
```

O prefixo é o **nome técnico deste site**. Ele obedece `[a-z][a-z0-9-]`, tem pelo menos
duas letras, e a ferramenta **recusa** prefixo vazio, com caractere fora dessa faixa,
igual ao do template ou em colisão com o espaço de nome do WordPress — a lista de
recusas e o motivo de cada uma estão em `ferramentas/prefixos-recusados.tsv`.

#### O que é renomeado, e o que NÃO é

Esta é a parte que quem chega sem contexto erra, e o erro não aparece como erro: ele
aparece como um site que mede zero para sempre. Leia a tabela inteira antes de rodar.

| O que | Renomeado? | Por quê |
|---|---|---|
| Diretório e slug do TEMA | **sim** | o tema é deste site e de mais nenhum; dois sites da operação nunca compartilham nome de tema |
| Options e metas DO IMPLANTADOR (`f3base_lock`, `f3base_checkpoint`, `f3base_journal`, `f3base_release`, …) | **sim** | são estado DELE, e ninguém do outro lado as lê |
| Text domain, handles de asset, prefixo das classes PHP do implantador | **sim** | cada plugin carrega o seu; nada do outro lado depende dessa palavra |
| Classes CSS de identidade visual (`f3base-faixa-escura` e irmãs) | **sim** | são identidade do site, estilizadas pelo tema deste site |
| `assets/plugins/` — a RESERVA do plugin, o zip publicado copiado para a árvore | **NÃO** | é outro artefato, instalado igual em todos os sites; é binário, e é de dentro dele que a ferramenta deriva as grafias do plugin que precisam sobreviver |
| `partilhado/` — a cópia VENDORIZADA das classes e tabelas que os dois runtimes leem | **NÃO** | é cópia conferida por hash contra a reserva: renomear é fork, e renomear um lado só produz `Class not found` na primeira execução |
| As grafias de `partilhado/dados/contrato-de-nomes.tsv` e toda grafia derivada de dentro da reserva, **mesmo dentro dos arquivos que SÃO renomeados** | **NÃO** | o implantador renomeado continua GRAVANDO o que o plugin LÊ |

**O PLUGIN NÃO É RENOMEADO, e isso mudou na 1.7.0.** Até a 1.6.6 a ferramenta varria a
raiz inteira e renomeava também a fonte do plugin — slug, prefixo de classe, prefixo de
option e text domain. Cada site produzia um **fork** do plugin, com options
`<prefixo>_ga4_measurement_id` em vez de `f3base_ga4_measurement_id`. Um plugin cujo nome
de option muda por site não é um plugin: são N plugins parecidos, e **nenhuma correção
publicada alcança nenhum deles**. Desde a 2.0.0 a fonte do plugin nem sequer mora neste
pacote — ela tem repositório próprio —, e o que há dele aqui, `partilhado/` e
`assets/plugins/`, consta de `ferramentas/excecoes-de-prefixo.tsv`, com o motivo escrito
ao lado.

**Isso resolve metade do problema. A outra metade é o contrato de nomes.** O IMPLANTADOR
continua sendo renomeado, e é ele quem grava as options que o plugin lê, quem agenda o
hook que o plugin ouve e quem carrega as classes compartilhadas. Se a renomeação
reescrevesse esses nomes do lado de quem escreve e não do lado de quem lê, o site ficaria
com o implantador gravando `acme_ga4_measurement_id` e o plugin lendo
`f3base_ga4_measurement_id`: **configuração órfã, sem erro nenhum**, com o plugin rodando
no padrão de fábrica em cima de uma configuração que ninguém apagou. Por isso
`partilhado/dados/contrato-de-nomes.tsv` — cópia vendorizada do contrato do plugin,
conferida byte a byte contra o zip publicado — declara, grafia a grafia e com o motivo, o
que sobrevive à substituição — namespace REST, classes compartilhadas, hook da cadência,
nomes de tabela, nomes de evento e nomes de option, inclusive as duas de FRONTEIRA
(`f3base_operaveis`, `f3base_proveniencia`) que o implantador grava e o plugin lê. E a
ferramenta deriva de DENTRO da reserva toda outra grafia que o plugin escreve — handle de
asset, atributo de DOM, classe de CSS, nome de classe PHP —, porque lista escrita à mão
envelhece no primeiro arquivo novo do plugin.

**`f3base-secao-` é contrato do PLUGIN, e não identidade do site.** É o prefixo da classe
que marca uma seção medida, e ele **não leva o prefixo do projeto**. Ele é carimbado pelos
patterns do tema e pelo conteúdo de `content/` — que são renomeados — e é PROCURADO pelo
coletor do plugin — que não é. Com o tema carimbando `<prefixo>-secao-abertura` e o plugin
observando `f3base-secao-`, o observador não recebe alvo nenhum e **a medição de seções
morre calada em todo site renomeado**: o evento `f3base_secao_vista` continua declarado,
continua ocupando linha no relatório, e responde nada para sempre. Ele não aparece em CSS
nenhum do tema — o tema estiliza `f3base-faixa-escura`, que É identidade e É renomeada.
Marca de medição pertence a quem mede.

**A regra de bolso, se você tiver de decidir sozinho.** Nome de PASTA é endereço: trocar
custa uma reinstalação. Nome de OPTION é chave de dado: trocar órfã o valor sem apagar
nada e sem erro. Nome de TABELA apaga a série histórica. Nome de EVENTO quebra a série na
conta de medição do fornecedor, onde não há como reparar depois.

**Quem prova as duas coisas em toda rodada:** `renomeacao.plugin_intacto` e
`renomeacao.secao_medida_apos_renomear`, que renomeiam de verdade uma cópia do pacote e
medem o resultado. `estatica.sem_residuo_de_prefixo` confere que nada do prefixo antigo
sobrou fora de `ferramentas/excecoes-de-prefixo.tsv`, e não acusa o contrato de nomes do
plugin; `renomeacao.contrato_de_nomes_completo` confere que toda option do catálogo e todo
evento declarado estão no contrato — uma lista escrita à mão que ninguém confere envelhece
na primeira option nova; e `renomeacao.preservados_so_do_codigo` confere que a lista de
preservadas é derivada do CÓDIGO do plugin, nunca da prosa dele — as options de estado do
seu implantador (`<prefixo>_lock`, `<prefixo>_checkpoint`, `<prefixo>_journal`…) são SUAS e
trocam de prefixo com o resto.

#### As outras três regras da renomeação

- **Rodar duas vezes com o mesmo prefixo não muda nada na segunda.** A busca é sempre
  pelo prefixo de ORIGEM, declarado em `ferramentas/prefixo-do-template.tsv`, que a
  ferramenta nunca reescreve.
- **A renomeação acontece uma vez, a partir do template.** Para um prefixo diferente,
  parta de uma cópia nova — renomear o já renomeado não é suportado, e fingir que é
  produziria um pacote meio num prefixo e meio noutro.
- **`MEMORIA-DECISOES.md` não é reescrito, e isso é decisão.** Ele narra defeitos
  medidos citando diretórios e nomes que existiram em sites reais. Trocar o prefixo
  nessas frases inventaria um passado que não aconteceu: nenhum site com o seu prefixo
  produziu aqueles diretórios. O documento viaja com o pacote como história herdada,
  atribuída a quem a produziu; o site novo abre o próprio registro.

### 2. Trocar a identidade

| O que | Onde |
|---|---|
| Nome e tagline do site | `config/site.json` → `site.nome`, `site.tagline` |
| Endereço canônico | `config/site.json` → `ambiente.url_canonica` |
| Sufixos de domínio de prévia da hospedagem | `config/projeto.json` → `ambiente.dominios_de_previa` |
| Organização para dados estruturados: nome, logotipo e serviços | `config/site.json` → `seo.organizacao.*` |
| Organização no grafo: perfis, área servida, ponto de contato | `config/projeto.json` → `organizacao.*` |
| Cores, tipografia, espaçamento | `fontes/tema/theme.json` → `settings.color.palette`, `settings.typography`, `settings.spacing` |
| Regras que o theme.json não expressa | `fontes/tema/style.css` |
| Prova de contraste da paleta nova | `fontes/tema/CONTRASTE.md` |
| Logotipo em vetor, servido no markup | `assets/logo.svg` |
| Logotipo em bitmap, para a biblioteca | `assets/logo.png` |
| Ícone do site | `assets/favicon.png` |
| Imagem social padrão | `assets/social.png` |

A paleta é **lockdown**: valor avulso não é aceito pelo editor, e cor literal no tema é
acusada. Toda cor nova entra como preset em `theme.json` e é usada por `var:preset|…`.
`a11y.contraste` recalcula os pares em uso a cada rodada — paleta nova que não passa no
piso AA reprova ali.

### 3. Substituir o conteúdo

Cada página declarada em `config/site.json` → `paginas[]` tem um arquivo em
`content/pages/<ref>.html`; cada post em `posts[]` tem `content/posts/<slug>.html`.
Todos abrem hoje com a marca de conteúdo demonstrativo — é ela que diz a quem abre o
arquivo que aquilo é do template e é substituível.

- Troque o conteúdo de cada arquivo, **e a marca sai junto**.
- Ajuste `paginas[]`, `posts[]` e `categorias[]` para o que este site tem de verdade.
- As frases obrigatórias e as proibidas deste projeto vivem em `copy_contrato` e são
  conferidas por `copy.contrato` — ajuste-as antes de escrever, não depois.
- **Nada de placeholder.** `estatica.detector_placeholder` reprova `{{x}}`, `[[x]]`,
  `[x]`, TODO, TBD, XXX, LOREM e a palavra de exemplo em maiúscula no conteúdo publicado.
- **Marque as seções que este site quer medir** com a classe `f3base-secao-<nome>` — sem
  o prefixo do projeto, pelo motivo do passo 1. O procedimento inteiro está na seção
  *O que o conteúdo precisa declarar*, mais abaixo.

### 4. Preencher `config/projeto.json` — ANTES da execução única

Tudo neste passo mora em **`config/projeto.json`**, que é o único arquivo que o operador
abre. Cada campo nasce vazio de propósito, e cada `$comment` do schema diz o que preencher
e **onde obter** o valor.

**A ordem da operação, e ela é a decisão que governa esta release: o implantador é
executado UMA VEZ por site.** O que você preenche aqui é o que ele leva na execução; o que
ficar por preencher **não** é ajustado por uma segunda execução, e sim **pelo canal MCP**,
depois — as options do `site-core` são operáveis, e a página da política é um post que o
agente edita. Não há "execute de novo" em passo nenhum deste documento, e não há porque a
operação não tem esse ciclo.

| Chave, em `config/projeto.json` | O que acontece se ela ficar vazia |
|---|---|
| `contato.controlador.razao_social` | a política de privacidade **publica assim mesmo, com o marcador vazio à vista** |
| `contato.controlador.documento` | idem |
| `contato.controlador.endereco` | idem |
| `contato.controlador.encarregado` | escolhe qual das duas redações do encarregado é servida; vazio é estado normal, e o texto passa a apontar o canal de contato do site |
| `fato_juridico.base_legal` | a política vai ao ar sem nomear a hipótese legal. O pacote **lê e não julga**: a declaração jurídica é de quem responde pelo site |
| `fato_juridico.retencao_leads_meses` | a retenção de leads do `site-core` fica no padrão dele |
| `contato.whatsapp_e164` | o regime whatsapp **não existe**: `formulario.contato-whatsapp` fecha N/A e o CTA **não é publicado**, nem como link simples |
| `formularios[].caixa_de_leads` (regime `cf7-email`) | o regime **não existe**: `formulario.landing-cf7` fecha N/A e a caixa de leads não tem destino declarado. A chave mora **dentro da entrada do regime**, e não no topo de `contato`: ela é propriedade do formulário, e nenhum módulo do site-core a lê |
| `tracking.*` | slot vazio é inerte: nenhuma tag é emitida e nada vaza |
| `verificacao_dominio.google`, `verificacao_dominio.meta` | nenhuma metatag de posse é emitida; a verificação por DNS é a alternativa, e dispensa as duas |

**A política de privacidade é o caso a ler com atenção, e ele mudou na 2.1.0.** Até a 2.0.0
uma guarda MEDIDA segurava a página em `draft` enquanto razão social, CNPJ ou endereço
estivessem vazios, e `privacidade.controlador_identificado` fechava BLOCKED nomeando quais
faltavam. **As duas saíram, por decisão do dono: o que a política afirma é responsabilidade
de quem responde por ela.** O status de TODA página é o DECLARADO, e a intenção declarada
da política é produção — **ela PUBLICA**. O que o pacote continua fazendo é interpolar os
marcadores `%f3base:contato.controlador.*%` do arquivo de conteúdo, e vazio vira vazio: com
o controlador em branco, **a página no ar mostra o espaço onde deveria estar quem responde
pelo site**. O preço é declarado e é do operador. Preencha antes da execução, ou edite a
página pelo canal depois.

`formularios[].pagina_ref` merece uma linha própria, porque foi defeito medido: é ela que
diz em qual página o formulário criado é posto, e é lida **deste arquivo**. Ref vazia, ref
que não resolve ou leitura de volta sem o shortcode **reprovam a unidade** desde a 2.1.0 —
até a 2.0.0 o formulário era criado, ficava em página nenhuma, e a unidade fechava OK.

### 5. Desligar o conteúdo demonstrativo

`config/site.json` → `conteudo.demonstrativo: false`.

**Este é o último passo do conteúdo, e ele vem depois da substituição — nunca antes.**
Desligar a chave com os arquivos ainda marcados não cala nada: `conteudo.marca_demonstrativa`
acusa a divergência arquivo a arquivo, e a publicação é **recusada** em tempo de aplicação,
com o nome do arquivo e as duas saídas. Enquanto a chave estiver ligada e
`ambiente.tipo` for `producao`, `conteudo.demonstrativo` fecha WARN nomeando as páginas
que continuam sendo do template.

**Essa chave responde pelo PACOTE, e não pelo site.** Depois da instalação, quem responde
pelo site é `conteudo.demonstrativo_no_site`: ela conta, no BANCO, as páginas publicadas
que ainda carregam a marca e as NOMEIA — zero páginas marcadas, zero aviso, qualquer que
seja a chave. Isso importa porque, sob a premissa desta operação, o agente substitui o
conteúdo pelo canal e nunca volta ao `config/site.json`: sem a medição no banco, o aviso
ficaria preso para sempre num site que já não tem uma linha do template.

### 6. Rodar a suíte

```
bash suite/verificar.sh <caminho-absoluto-do-pacote>
bash suite/verificar.sh piso <caminho-absoluto-do-pacote>
```

Caminho **absoluto**: rodar sem argumento reprova por desenho. As duas rodadas precisam
fechar com **FALHA 0**. BLOCKED com fase declarada não impede a entrega — é medição que
este ambiente não pode fazer. WARN é achado adverso que não bloqueia: leia cada um e
decida; nenhum deles sai sem nomear o que está adverso e o que custa.

**Esta rodada é METADE da aprovação, e a outra metade tem endereço.** Desde a 2.0.0 a
fonte do plugin não mora neste pacote: quem mede o plugin — o endpoint de leads, o
`llms.txt`, a medição, a cadência, e a única checagem que roda o cliente ENTREGUE num
Chromium de verdade, `navegador.comportamento_real` — é a suíte do repositório do plugin,
contra o zip que ela mesma sela. O que este pacote confere é que a reserva embutida É esse
zip (`pacote.reserva_confere_com_o_catalogo`, pelo `sha256` declarado em
`config/decisoes.tsv`) e que a cópia de `partilhado/` é byte a byte o que está nele
(`pacote.copia_vendorizada_confere`). Quatro releases seguidas — 1.3.3, 1.3.4, 1.3.5 e 1.3.6
— a bancada aprovou o que o navegador reprovou, e a regra que nasceu dali continua valendo:
**um pacote verificado sem a rodada do plugin não é um pacote aprovado.** As cinquenta e
nove checagens que saíram daqui estão declaradas em `suite/excluidas.tsv`, cada uma com o
motivo; `excluidas.declaradas` confere que a lista está viva.

**A 2.1.0 acrescentou uma quarta categoria àquele arquivo: `retirada`**, e ela se lê
diferente das outras. `plugin`, `substituida` e `instrumento` dizem que a medição mudou de
endereço; `retirada` diz que **a pergunta deixou de ser do implantador**, por decisão do
dono, e que ninguém a mede em lugar nenhum. Estão ali
`privacidade.controlador_identificado` e `projeto.fato_juridico_coerente` — o dado e a
declaração jurídica são do operador — e as três linhas do eixo de encerramento que saiu
com o "execute de novo": `entrega.convergencia`,
`lotes.gate_de_aplicacao_sem_dado_do_operador` e `estatica.precondicao_no_eixo`. Se você
derivar um site novo e sentir falta de um aviso que existia, é aqui que está escrito por
que ele não existe mais.

O que continua medido AQUI do cliente do plugin é o par que nenhum dos dois repositórios
mede sozinho: `js.banner_de_consentimento` roda o cliente de consentimento lido de dentro
da reserva contra o `style.css` DESTE tema, porque é o tema que decide a visibilidade do
painel que o plugin abre e fecha.

### 7. Instalar, e receber o plugin

A etapa de empacotamento publica **um zip** em `dist/` — `dist/implantador-base-<versão>.zip`,
numerado por `release.identidade` — e o `dist/lock.tsv` com o `sha256` de cada caminho. É o
único arquivo que o operador envia: **Plugins → Adicionar novo → Enviar plugin**, ativar e
rodar.

**O plugin não é construído por este pacote, nem mora nele: ele é INSTALADO.** O implantador
o instala como qualquer outro plugin de catálogo, pela URL declarada em `plugins.instalaveis`
(`config/decisoes.tsv`), conferindo o `sha256` declarado ali ANTES de instalar. Se a URL não
responder, quem instala é a RESERVA — `assets/plugins/base-site-core-fator3-<versão>.zip`,
que mora na árvore deste pacote e é o zip publicado copiado byte a byte —, e ela passa pela
MESMA conferência de digesto. Da 1.7.0 à 1.7.4 essa frase era falsa: a reserva versionada era
lida pela linha de versão e por mais ninguém, e com a URL fora do ar a instalação fechava
BLOCKED; a bancada não via porque montava o slot do operador para se testar. Desde a 2.0.0 a
bancada percorre o caminho real — URL tentada, reserva instalando, digesto conferido — e o
piso prova que uma reserva com digesto errado é recusada.

**Uma release do plugin tem dois lados, e os dois custam.** No repositório do plugin: subir
o `Version:`, rodar a suíte de lá, publicar `base-site-core-fator3.zip` no catálogo — só esse
passo alcança os sites já no ar. DESTE lado, três edições e a rodada: trocar o zip em
`assets/plugins/` pelo publicado (nome `<slug>-<versão>.zip`), declarar o `sha256` novo em
`plugins.instalaveis.<n>.sha256`, extrair de dentro do zip novo os arquivos listados em
`partilhado/VENDORIZADO.tsv` por cima dos de `partilhado/`, e rodar o comando único — que
sela uma release nova deste pacote, porque a reserva e a cópia mudaram de bytes. Pular
qualquer das três é medido: `pacote.reserva_confere_com_o_catalogo` e
`pacote.copia_vendorizada_confere` reprovam nomeando o que divergiu.

**A consequência que mais custa caro, e ela não é óbvia:** enquanto o zip publicado naquele
endereço estiver atrás da versão que a reserva carrega, toda implantação instala a versão
antiga — **com sucesso**. Nada falha, o relatório fecha, e o site fica sem as correções que
este pacote já tem. Foi o estado da 1.7.4 contra o catálogo publicado, pelo outro lado: a
reserva dizia 1.0.1 e o catálogo publicava 1.0.0, e toda implantação nova fechava em
`FALHA_PARCIAL`.

A linha `plugins.site_core_versao` do relatório compara a versão que ficou instalada com a
que o NOME da reserva carrega, e é o único lugar do pacote que deriva esse veredito. Ela
nunca impede a instalação nem suspende etapa nenhuma: a versão do plugin no site é fato do
host. Mas ela fecha **FALHA** quando a instalada é menor, e FALHA derruba o estado da
aplicação — que é a primeira condição da autodesativação. Na prática: **um catálogo atrás
da reserva deixa o implantador ativo no site**, com a linha dizendo as duas saídas. É o
desfecho certo. O que ela NÃO distingue — o mesmo número com bytes diferentes — é assunto do
digesto, na linha `plugins.instalado:base-site-core-fator3`: dois fatos, duas linhas.

#### O que a execução REMOVE, e por que ela remove

**O caminho dos posts tem prefixo desde a 2.2.0, e ele é o primeiro valor a trocar num site
novo.** `conteudo.blog` declara três coisas — `prefixo`, `titulo` e `categoria` — e delas saem
a estrutura de permalink `/<prefixo>/%postname%/`, a base de categoria `<prefixo>/<categoria>`
e o slug da página de índice, que é o próprio prefixo. O rótulo do item de menu é livre e pode
divergir do título da página. **Duas regras têm detector e reprovam a rodada:** nenhuma entrada
de `paginas` pode declarar o prefixo como slug nem morar sob ele — com prefixo, é a única
colisão que sobra, e o núcleo a resolve a favor da página em silêncio —, e o H1 de
`fontes/tema/templates/index.html` precisa repetir `conteudo.blog.titulo`, porque o template de
blocos não consulta option nenhuma e o título ali é literal. Trocar o prefixo sem trocar o H1
reprova; trocar os dois é uma edição de configuração e uma linha de template.

**A unidade `limpeza` entrou na 2.1.0, e o defeito veio de uma implantação real.** O site de
2026-09-07 foi entregue com os três temas de fábrica — Twenty Twenty-Três, Quatro e Cinco
—, com o Akismet e com o Hello Dolly instalados: código que ninguém pediu, que o painel
lista, que a atualização automática alcança e que entra em todo relatório de segurança como
superfície instalada.

A unidade roda **depois do tema e antes do `site_core`**, e remove pela lista declarada em
`config/decisoes.tsv` — `limpeza.temas_padrao` e `limpeza.plugins_padrao`. **O que a lista
não declara não é tocado**: o plugin de painel da hospedagem fica, plugin do cliente fica,
tema de terceiro fica. Quem apaga é o núcleo (`delete_theme()` e `delete_plugins()`), com
desativação pela API antes quando o plugin está ativo, e a leitura de volta confere que o
tema não existe mais e que `get_plugins()` não lista mais o arquivo.

Quatro guardas, todas com piso em `limpeza.plano_dos_padroes`: o tema **ATIVO** nunca é
removido, nem o **PAI** do ativo, ainda que a lista os declare — a linha diz que os pulou;
item declarado e não instalado é **AUSENTE**, não erro; e lista vazia é plano vazio.

**Duas coisas para decidir antes de rodar num site novo.** A primeira: a remoção é
**IRREVERSÍVEL**, e o journal a declara como tal com o motivo — tema de fábrica volta pelo
repositório oficial em um clique. A segunda: remover o Twenty Twenty-Cinco tira do núcleo o
**tema-reserva** (`WP_DEFAULT_THEME`), e se o tema deste site quebrar não há para onde
cair. A decisão do pacote é essa — tema que quebra aqui é defeito de release, medido antes
de sair, e o tema-reserva do núcleo era um site alheio no ar com a cara de outro projeto.
Se o seu projeto quiser o contrário, a saída é editar a lista, que é o único lugar onde
isso é decidido.

**Para MUDAR o plugin — módulo novo, evento novo, option nova — o documento é outro:**
`INSTRUCOES-DO-PLUGIN.md`, dentro do zip do plugin. Ele traz o registro único de módulos, o
catálogo de options, as duas tabelas, as rotas REST, a medição de comportamento inteira e o
que a suíte vai cobrar de quem mexer. Este documento não repete nada daquilo.

A instalação do bundle, a execução em lotes, a reversão e o desligamento do canal estão em
`README.md`, e nada disso muda por site.

---

## Depois da instalação: o agente

A premissa que governa esta parte do pacote, nas palavras de quem a definiu: *"Após a
instalação, todas as futuras modificações serão realizadas por um agente através de MCP.
Então o template e plugins não devem tentar evitar que futuras modificações sejam
realizadas."*

O implantador se autodesativa e não volta sozinho. **Ele é executado uma vez por site**, e
o que ficou por preencher — dado que só o operador tem — é ajustado pelo canal, sem nova
execução. Esta seção diz o que o agente **encontra**, o que o pacote **garante a ele** na
hipótese de alguém reativar o implantador, e o que o pacote **não faz**.

As garantias abaixo são propriedade do CÓDIGO, e continuam valendo: reexecutar não repete o
que já foi aplicado, e a edição feita pelo canal vence. O que elas não são é um método de
operação — "preencha e execute de novo" saiu da 2.1.0 junto com o eixo de encerramento que
o dizia.

### O que o pacote garante ao agente

- **Preenche quando falta, não sobrescreve o explícito.** O `href` da política de
  privacidade só é gravado quando está vazio ou é `#`; o `href` do CTA só é reescrito
  quando ainda é o do modelo. Destino que alguém trocou fica como está, no render e no
  clique.
- **Edição vence reexecução.** Toda option do bloco do site-core passa por uma regra de
  três vias: o pacote registra a **base** — o último valor que ele mesmo aplicou — e
  compara base, observado e desejado. Observado igual à base: atualização segura.
  Observado diferente da base e configuração intocada: **preserva**, e o relatório nomeia
  a option e o motivo.
- **Quando a configuração vence, ela sai nomeada.** O único caminho pelo qual o pacote
  grava por cima de uma edição do agente é a configuração ter mudado *aquela mesma coisa*
  depois da última aplicação. Aí ele grava e o relatório imprime a **sobreposição** com os
  dois valores — o que estava no site e o que foi aplicado. Não existe reversão calada.
- **A primeira execução com base declara o que fez.** Numa instalação que já tem a option
  e ainda não tem base, o observado é tratado como base e o desejado é aplicado — e a
  linha do relatório **diz que a base nasceu agora**, porque só nessa execução o pacote
  não consegue distinguir uma edição de um valor que sempre esteve ali.
- **Conteúdo substituído não volta.** O conteúdo que este pacote publica é
  demonstrativo. Uma vez que o agente o trocou pelo do cliente, nenhuma atualização do
  template sobrescreve: o pacote só grava conteúdo em objeto que ninguém tocou, e a
  divergência preservada sai nomeada por campo.
- **Par de redirect removido não volta.** O par que estava na base e não está mais na
  option foi apagado por quem opera o site: a união não o recria, nem pela configuração
  nem por uma etapa que o recompute, e o relatório o nomeia. Refazer o par pelo canal o
  traz de volta na execução seguinte — a marca de removido não é permanente.

### O que o agente encontra

| O que ele quer | Onde está |
|---|---|
| Ler os leads recebidos | rotas de **banco** do canal (`db/query`), credenciadas e auditadas |
| Ver como as páginas estão sendo usadas, sem OAuth do GA4 | a tabela `<prefixo>f3base_comportamento`, por `db/query` — uma linha por dia, caminho, evento e detalhe, com contagem e soma. As colunas estão descritas na seção do comportamento |
| Reindexar uma categoria rasa que o pacote marcou como `noindex` | grava `wpseo_noindex = 'index'` no termo; o módulo honra o valor do termo em vez de recalcular |
| Preencher o controlador que ficou em branco na política de privacidade | a PÁGINA publicada, pelo canal: os valores de `contato.controlador` são interpolados no conteúdo no momento da publicação, e o que está no ar é texto do post — não há option a gravar |
| Ligar GA4, Google Ads, Meta ou LinkedIn | as options de medição, pelo canal: `f3base_gtm_container_id`, `f3base_ga4_measurement_id`, `f3base_google_ads`, `f3base_meta_pixel_id`, `f3base_linkedin_partner_id`, `f3base_linkedin_conversion_id` |
| Ligar o evento de servidor da Meta (Conversions API) | `f3base_meta_capi_token`, pelo canal e **só** pelo canal: ela é segredo e não existe no `config/site.json` nem no schema |
| Emitir as metatags de verificação de posse do domínio | `f3base_verificacao_google` e `f3base_verificacao_meta`; vazias, nada é emitido |
| Saber se o conteúdo do template ainda está no ar | a linha `conteudo.demonstrativo_no_site`, medida **no banco**: ela conta e NOMEIA as páginas publicadas que ainda carregam a marca |
| Saber quais options ele pode gravar | `f3base_operaveis`, que o implantador grava com a lista |
| Saber o que o pacote aplicou por último | `f3base_base_merge` — a base de merge do conteúdo e das options |
| Acrescentar uma chave que o pacote não conhece a uma option de grupo | grava normalmente: os sanitizadores **preservam** a chave desconhecida em vez de descartá-la na primeira leitura |

### O que o pacote não faz

- **Não expõe os leads ao REST.** O CPT de contingência nasce com
  `show_in_rest => false`, e isso **não** é impedir modificação: é não expor dado pessoal
  de titular a toda credencial autenticada do site. A saída existe e é a de cima — as
  rotas de banco do canal, que são credenciadas e auditadas. O que não existe é a
  exposição por padrão.
- **Não pede ao canal que recuse a escrita do agente.** Os filtros de options protegidas
  do servidor MCP saíram do pacote inteiros. O que ficou no lugar é rastro: toda escrita
  passa pelo gravador único, a procedência fica registrada, e a cadência do modo
  somente-relatório relê as options e reporta o que divergiu.
- **Não recusa ID de medição fora da forma esperada.** Ele preserva o valor e emite um
  aviso nomeando a forma — apagar em silêncio é o que este pacote parou de fazer.

---

## Os consoles: o que a pessoa faz e onde cola o resultado

**Nenhum passo desta seção é executável pelo agente.** Todos eles são cliques dentro do
console de um fornecedor, atrás de uma conta e de um login que não existem do lado de cá —
não há rota MCP, não há option e não há arquivo que os substitua. O que o agente faz é a
outra metade: assim que a pessoa traz o valor de volta, ele grava a option pelo canal e o
site passa a emitir na página seguinte, sem release e sem passo manual do lado do site.

A fronteira, dita de uma vez: **a pessoa obtém o identificador; o agente grava a option.**
Esta seção existe porque a primeira metade nunca esteve escrita em lugar nenhum.

**A UI dos consoles muda sem aviso.** Onde o caminho exato de menu não estiver escrito
abaixo, é porque ele muda com frequência suficiente para envelhecer neste documento —
então o que está descrito é o **resultado a obter**, que não muda. Procure pelo resultado,
não pelo nome do botão.

### GA4 — Google Analytics

| Passo | Responsável | Resultado a obter | Onde o valor é colado |
|---|---|---|---|
| Criar a propriedade do GA4 e, dentro dela, um **fluxo de dados web** apontando para o domínio do site | pessoa, no console do Google Analytics | o **measurement ID**, na forma `G-…` | option `f3base_ga4_measurement_id` |
| Marcar `generate_lead` como **evento-chave** (a nomenclatura anterior era "conversão") | pessoa, no console | o evento aparece na lista de eventos-chave da propriedade | — |

**O teste, e é o único que prova a ligação inteira:** com o DebugView aberto na propriedade,
clicar o CTA do site e ver o evento **`generate_lead` chegando**. Ele é a prova de que o
Google recebe o que o `site-core` emite — e nada mais prova isso: a tag pode carregar, o
console pode não acusar erro nenhum, e a conta continuar sem receber. Enquanto o
`generate_lead` não aparecer ali, a medição do site não existe do lado do Google.

Se o evento não chegar, a ordem de investigação é esta: o measurement ID gravado está na
forma `G-…` (o módulo `tracking` avisa quando não está); o consentimento desta visita
permite tag; e `f3base_gtm_container_id` está **vazio** — preenchido, ele desliga toda tag
direta de propósito, e quem emite passa a ser o contêiner.

### Google Ads

Há dois caminhos, e o primeiro é o mais curto:

| Caminho | Responsável | Resultado a obter | Onde o valor é colado |
|---|---|---|---|
| **Vincular a conta do Ads à propriedade do GA4 e importar o evento-chave `generate_lead`** como ação de conversão | pessoa, nos consoles do Ads e do GA4 | a ação de conversão importada aparece na conta do Ads | — (nada é gravado no site) |
| **Ou** criar uma ação de conversão própria do Ads, do tipo site | pessoa, no console do Ads | o **ID de conversão** na forma `AW-…` e o **rótulo** da ação | option `f3base_google_ads`, subchaves `conversion_id` e `conversion_label` |

**Escolha um.** Importar do GA4 **e** criar a ação própria conta a mesma conversão duas
vezes, e conversão em dobro não é um número errado num relatório: ela reescreve o lance do
leilão. Se a ação própria for a escolhida, as **duas metades** precisam estar preenchidas —
o ID sozinho dispara para a conta e não para a ação, e o pacote prefere não disparar a
disparar no lugar errado; o módulo avisa quando só uma está lá.

**O teste:** a ação de conversão sai do estado **"sem verificação"** (ou equivalente
"nenhuma conversão recente") no console do Ads. Enquanto ela estiver ali, o Ads não viu
nenhuma conversão chegar — e o lance está sendo dado sem o sinal que ele deveria estar
otimizando.

### Meta — Pixel, verificação de domínio e Conversions API

São **três** valores, e eles fazem coisas diferentes:

| Passo | Responsável | Resultado a obter | Onde o valor é colado |
|---|---|---|---|
| Criar o **pixel** (dataset) no Gerenciador de Eventos | pessoa, no console da Meta | o **ID do pixel**, só dígitos | option `f3base_meta_pixel_id` |
| **Verificar o domínio** no Gerenciador de Negócios | pessoa, no console da Meta | o conteúdo da metatag `facebook-domain-verification` | option `f3base_verificacao_meta` |
| Gerar um **token de acesso** da Conversions API para esse mesmo dataset | pessoa, no console da Meta | o **token** | option `f3base_meta_capi_token` |

**A verificação de domínio não é opcional para quem anuncia.** É ela que decide quem pode
editar o link e a criativa dos anúncios que apontam para este site. A Meta também aceita
verificação por DNS; se o operador preferir esse caminho, a option fica vazia e nada é
emitido — as duas formas valem.

**O token é segredo, e ele não passa pelo `config/site.json`.** O arquivo de configuração
viaja dentro do zip: ele é lido pela suíte, entra no bundle e chega inteiro a quem faz o
upload. Um token declarado ali é um token copiado para todo lugar por onde o pacote passou,
e a cópia sobrevive a qualquer rotação da credencial, porque ninguém volta ao zip para
apagá-la. Ele é gravado **direto na option**, pelo canal, e a suíte reprova se o nome dele
reaparecer na configuração ou no schema.

**O teste, e ele é o que fecha o desenho inteiro:** enviar um lead de verdade e, no **Test
Events** do Gerenciador de Eventos, ver **um** evento `Lead` — não dois — com os dois
caminhos reconhecidos: o do navegador e o do servidor, **deduplicados pelo mesmo
`event_id`**. Dois eventos separados ali significam que o `event_id` não está batendo, e a
partir daí toda conversão de lead conta em dobro na Meta.

Sem o token, o caminho do servidor simplesmente não existe: o navegador continua mandando o
`Lead` com `eventID`, e o iOS e os bloqueadores continuam cortando a parte deles sem que
nada preencha o buraco.

### LinkedIn Ads

| Passo | Responsável | Resultado a obter | Onde o valor é colado |
|---|---|---|---|
| Criar o **Insight Tag** na conta de anúncios | pessoa, no console do LinkedIn | o **Partner ID**, só dígitos | option `f3base_linkedin_partner_id` |
| Criar a **conversão** e associá-la à campanha | pessoa, no console do LinkedIn | o **ID da conversão**, só dígitos | option `f3base_linkedin_conversion_id` |

O Partner ID sozinho entrega apenas visita de página; sem o ID da conversão, não há conversão
declarada para o clique do CTA disparar.

**O teste:** a conversão sai do estado **"sem sinal"** (ou equivalente "nenhum evento
recebido") no console do LinkedIn, depois de um clique real no CTA.

### Google Search Console

| Passo | Responsável | Resultado a obter | Onde o valor é colado |
|---|---|---|---|
| Criar a propriedade do domínio no Search Console e escolher a forma de verificação | pessoa, no console do Google | ou o conteúdo da metatag `google-site-verification`, ou o registro DNS que o Google indicar | option `f3base_verificacao_google`, **ou** nada (quando a verificação for por DNS) |

**As duas formas valem, e a escolha é do projeto.** A verificação por DNS cobre o domínio
inteiro — inclusive subdomínios e o protocolo — e independe do que o site serve; a metatag
cobre o prefixo de URL e depende de o `<head>` continuar sendo servido. Quem escolher DNS
deixa a option vazia, e nenhuma tag é emitida: vazio é inerte, como todo slot deste pacote.

**O teste:** a propriedade aparece **verificada** no Search Console. Depois disso, o dado de
busca só começa a existir com o tempo — verificação é permissão de leitura, não medição.

---

## O comportamento do visitante: o que o site mede sozinho

O site nasce instrumentado, e nada disso precisa de passo humano. Basta **haver um destino**
— um ID de medição gravado **ou** o resumo do próprio site ligado, que é o padrão de
entrega — e o consentimento permitindo. Aí seis coletores entram na página:

| Coletor | Evento | Parâmetro | Teto por página |
|---|---|---|---|
| Marcos de rolagem | `f3base_rolagem` | `f3base_marco` (25, 50, 75, 90) | 4 |
| Seção vista | `f3base_secao_vista` | `f3base_secao` | 12 |
| Clique em link externo | `f3base_link_externo` | `f3base_dominio` (host, nunca a URL) | 10 |
| Fricção | `f3base_friccao` | `f3base_cliques` | 3 |
| Erro de JavaScript do site | `f3base_erro_js` | `f3base_arquivo`, `f3base_linha` | 3 |
| Core Web Vitals | `f3base_web_vital` | `f3base_vital`, `f3base_valor` | 4 |

**A seção entra numa linha e sai em outra.** `f3base_secao_vista` declara `visivel=0.5` — a
linha de ENTRADA, metade do bloco no campo de visão — e `saida=0.2` — a linha de SAÍDA, abaixo
da qual ele rearma. Entre as duas nada muda de estado: é uma **banda**, e ela existe para que a
seção parada na fronteira do campo de visão não fabrique ocorrência 2, 3 e 4 sem ninguém ter
relido nada. O preço é declarado: uma reentrada curta e legítima — tirar o bloco até a razão
0,3 e trazê-lo de volta — deixa de ser contada. `saida` ausente, negativa ou maior/igual a
`visivel` volta ao comportamento simétrico, com a mesma linha nos dois sentidos.

**Onde tudo isso é declarado:** `dados/eventos-comportamento.tsv`, dentro do plugin. Nome,
parâmetro, teto e limiar moram ali e em lugar nenhum mais — o cliente não escreve nenhum
deles. **Editar essa tabela muda o comportamento sem release**; editar um nome de evento
depois de o site estar no ar QUEBRA A SÉRIE HISTÓRICA da conta de medição, e o relatório do
mês seguinte fica vazio sem erro nenhum. Se precisar renomear, renomeie no destino também.

**Para o agente que constrói o site, um passo é seu:** as seções que você quiser medir
precisam carregar a classe `f3base-secao-<nome>` como `className` do bloco de grupo —
nunca como atributo cru, que quebra a validação do bloco no editor.

**O prefixo `f3base-secao-` NÃO acompanha o prefixo do projeto**, e essa é a diferença que
mais custa caro para quem chega agora. Ele é contrato do PLUGIN, declarado em
`dados/contrato-de-nomes.tsv` do plugin — vendorizado aqui em `partilhado/dados/` — e preservado pela renomeação **mesmo dentro dos
arquivos que são renomeados**: o tema e o conteúdo carimbam a classe, o coletor do plugin a
procura, e só o primeiro dos dois é renomeado. Trocá-la por `<prefixo>-secao-abertura` faz o
observador não receber alvo nenhum e a medição de seções morrer calada — sem erro, com o
evento continuando declarado e respondendo nada para sempre. Quem mede isso a cada rodada é
`renomeacao.secao_medida_apos_renomear`, que renomeia de verdade uma cópia do pacote e
confere que a seção continua sendo vista. Os cinco patterns do tema já nascem marcados: `abertura`, `texto`, `cartoes`,
`faq`, `contato`. **Seção sem a classe não é medida**, e isso é deliberado: derivar o nome
do título faria a série mudar sozinha na primeira revisão de copy.

**O que o piso já provou, e o que continua dependendo de tráfego:** os seis coletores,
seus tetos e a ausência de dado pessoal no payload têm teto e piso em
`js.comportamento_instrumentado`. O que NÃO está provado é que o dado chegou:
`desempenho.core_web_vitals` continua **BLOCKED**, porque Core Web Vitals de campo são a
distribuição sobre visitas reais, e antes de haver visitante não há valor nem distribuição.
Coleta existir não é o mesmo que a medida ter sido tomada.

**O teste, quando o site estiver no ar:** com o DebugView do GA4 aberto, rolar a página até
o fim e ver os quatro `f3base_rolagem` chegarem, um por marco. É a mesma prova do
`generate_lead`, para a outra metade da medição.

### Onde estes dados ficam VISÍVEIS

Até a 1.1.3 a resposta honesta para *"onde vejo os dados desta instrumentação"* era: em
lugar nenhum do site. Os seis coletores saíam do navegador direto para a conta de medição, e
com o slot de medição vazio os eventos não existiam em canto algum. Isso mudou.

**A cada OCULTAMENTO da página** — e ocultamento acontece toda vez que a aba perde o foco,
não só na saída —, o navegador despacha um **lote** com os totais agregados e o registro
acumulado desde o anterior, e o site os soma numa tabela própria. O envio confirma a
**entrega** (`fetch` com `keepalive`, e o lote só é esquecido com 2xx); o que ainda não foi
confirmado fica gravado no `localStorage`, dentro do registro da visita, e é despachado pelo
carregamento seguinte da mesma visita antes de qualquer coisa nova. São duas leituras da
mesma tabela:

- **a pessoa**, no menu **Medição** do wp-admin — menu próprio, e não uma seção da tela de
  configuração: quanto o site recebeu no período, cada evento declarado com a pergunta que
  ele responde em português comum, as páginas em que aconteceu, e a média dos Core Web
  Vitals. Sem nenhum registro a tela diz desde quando o site coleta e o que falta, em vez
  de mostrar uma tabela de zeros;
- **o agente**, pelas rotas de **banco** do canal (`db/query`), sem OAuth do GA4 e sem
  credencial de fornecedor nenhuma.

**A tabela é `<prefixo_do_wp>f3base_comportamento`**, e as colunas são estas:

| Coluna | Tipo | O que é |
|---|---|---|
| `chave` | `char(64)` | `sha256` de `dia\|caminho\|metrica\|detalhe` — a chave primária, e é ela que faz duas sessões somarem na mesma linha |
| `dia` | `char(10)` | Dia em `Y-m-d`, em UTC |
| `caminho` | `varchar(190)` | Caminho da página, **sem query e sem fragmento** |
| `metrica` | `varchar(64)` | Nome DECLARADO do evento, resolvido pelo servidor a partir do gatilho (`f3base_rolagem`, `f3base_secao_vista`, …) |
| `detalhe` | `varchar(60)` | O discriminante do evento: marco de rolagem, nome da seção, host de destino, nome do vital. Vazio quando o evento não tem um — o erro de JavaScript entra como contagem, e o arquivo dele **não** viaja |
| `contagem` | `bigint` | Quantas vezes aconteceu, somado no dia |
| `soma` | `double` | Soma dos valores, para os vitais. A média do período é `soma / contagem`, e é assim que ela existe sem guardar amostra |
| `atualizado_em` | `bigint` | Carimbo Unix da última soma nesta linha |

Consulta típica do agente — a profundidade de rolagem da home nos últimos 30 dias:

```sql
SELECT dia, detalhe, contagem
FROM   <prefixo>f3base_comportamento
WHERE  metrica = 'f3base_rolagem' AND caminho = '/'
ORDER  BY dia DESC, detalhe;
```

**Três coisas que quem lê estes números precisa saber, e a tela as diz também:**

1. **Contam só as sessões com consentimento.** Não é o total de visitantes do site.
2. **Não substituem o relatório do fornecedor.** Público, origem de tráfego, funil,
   atribuição e comparação de períodos longos vivem no GA4 e nos consoles. Este quadro é o
   que o site vê por conta própria.
3. **Há prazo.** `f3base_comportamento.retencao_dias` (90 por padrão) é o que a rotina de
   retenção do site usa para apagar as linhas antigas. Este quadro não é arquivo histórico.

As três chaves do resumo estão na tela **F3 Base**, em **Privacidade e retenção**: ligar ou
desligar (`ligado`), o prazo de guarda (`retencao_dias`) e o período que o menu Medição soma
(`dias_no_painel`). Desligar não afeta o envio para a conta de medição.

**Onde se desliga, sem procurar.** O menu **Medição** abre dizendo isso e leva ao campo por
link com âncora — não há chave nova, e não haverá: duas chaves para "esta instalação mede?"
divergem na primeira vez que alguém mexe numa e não na outra. Com `ligado` desmarcada, a
primeira coisa da tela Medição passa a ser a frase do desligamento, e não uma tela sem número
nenhum — que é indistinguível de um site sem visita.

**A releitura conta.** Um bloco entra no registro toda vez que a razão de interseção dele
alcança meia seção visível, e sai quando ela cai abaixo disso — não quando ele some da tela.
É a coluna "vez" da tabela bruta: `1ª`, `2ª`, `3ª`. Marco de rolagem tem banda declarada
(`histerese_pp`, 5 pontos) para que tremor na fronteira não vire travessia que não houve.

**E ela conta a VISITA, não a página carregada.** Quem vê um bloco, navega para outra página
do site e volta continua de onde parou: a volta aparece como `2ª`. Cada endereço tem a
contagem dele — o mesmo bloco em outra página recomeça na `1ª`, porque duas seções com o
mesmo nome em páginas diferentes são duas seções. O total do quadro de cima continua contando
uma vez por carregamento: ele responde "quantas visitas viram este bloco", e a tabela bruta
responde "quantas vezes cada uma passou".

**A coleta não depende de fornecedor nenhum.** Um site sem GA4, sem GTM, sem Pixel e sem
LinkedIn continua servindo o coletor e continua somando na tabela: o resumo do próprio site
é um destino, e as tags de fornecedor são outro. Até a 1.3.2 os dois estavam presos ao mesmo
interruptor, e um site sem ID de fornecedor nascia sem medição nenhuma.

## O `/llms.txt` do site é o PRÓPRIO, e o concorrente é desligado

O site serve `/llms.txt` por rota virtual do `site-core`, com a curadoria declarada em
`seo.llms_selecao` mais a enumeração automática do conteúdo publicado. **Você não configura
o emissor: o implantador desliga o concorrente, sempre.**

A precedência do endereço é declarada e tem três degraus — arquivo físico na raiz vence,
depois o emissor concorrente ligado, e só então a rota. **Medido em 2026-09-07, com a
2.0.0**: a unidade de SEO ligava `enable_llms_txt` no plugin de SEO, ele gravava um arquivo
físico na raiz que vencia a rota, e a curadoria ia para uma option com chaves que a versão
instalada dele **não lê** — o publicado era a seleção automática do fornecedor, com
"Contato" selecionada e fora do arquivo e "Blog" não selecionada e dentro. A linha do
relatório fechava OK medindo a própria escrita.

Na 2.1.0 a unidade `seo.llms_proprio` faz três coisas e relê as três: grava
`enable_llms_txt` como o literal `false`, remove o agendamento semanal que repovoaria o
arquivo, e apaga o arquivo físico da raiz **se ele for do plugin de SEO** — reconhecido
pela assinatura que o fornecedor escreve no corpo do que gera. **Arquivo de outra origem é
PRESERVADO e sai nomeado**: só se apaga o que se conhece, e um `llms.txt` que alguém pôs
ali de propósito continua vencendo a rota.

O que isso muda para quem monta um site novo: **a única chave que decide se este site tem
`llms.txt` é `bots_ia.llms_txt`**, do `site-core`. Desligada, não há arquivo nenhum e a
unidade fecha N/A com a condição declarada. Não existe segundo interruptor no plugin de
SEO para procurar, e ligar um lá é reabrir o defeito acima —
`estatica.llms_proprio_sem_concorrente` reprova o pacote que voltar a fazê-lo.

## O controle de consentimento é "Política de Cookie", e é um link

O rodapé de toda página publicada traz um **link de texto** com esse rótulo — sem destaque,
na mesma linha e com o mesmo tratamento dos outros links do rodapé. Ele abre um **banner
na base da tela**, com a altura do conteúdo, que **não cobre a página**: o visitante
continua lendo e usando o site com ele aberto.

Se você trocar o markup do rodapé, três coisas precisam sobreviver, e a suíte cobra as
três: o atributo `data-f3base-consentimento` (é por ele que o `site-core` liga o
comportamento), o `aria-controls` apontando para o `id` do banner, e o elemento continuar
**acionável pelo teclado** — um `<a>` sem `href` não é focável nem anunciado, e um
`<a href="#">` inventa um destino. Se precisar de um elemento próprio, use `<button
type="button">` estilizado como link, que é o que o pacote faz.

### A política decide como o script é carregado

Você não configura isto: `consentimento.padrao` decide.

- **`pre-aprovado`** — o script sai com `defer` e **não bloqueia o carregamento da
  página**. São **5.085 bytes gzip** fora do caminho crítico, e era o único script
  bloqueante do pacote. A ordem que importa continua de pé: `defer` executa na ordem do
  documento, o consentimento está no `<head>` e o carregador de tags no rodapé.
- **`negado`** — o script sai **bloqueante no `<head>`**. Ali o `default` é `denied`, e o
  que dispara antes dele é um primeiro `page_view` de quem ainda não consentiu. `defer` só
  ordena `defer`: o `gtag.js` `async` de outro plugin, ou um snippet colado no cabeçalho,
  roda antes de qualquer `defer` da página. Os 5 KB no caminho crítico são o preço de não
  disparar antes de saber.

### O que a recusa NÃO desfaz

Diga isto ao cliente antes de ele descobrir sozinho, e está escrito na política de
privacidade que o pacote entrega:

- A recusa vale **do clique em diante**. O que já foi enviado **permanece com o
  fornecedor** — o pedido de eliminação daquele histórico é feito lá, pelos canais dele.
- **GA4 e Google Ads** recebem a recusa como `consent update` e passam a operar sem
  armazenamento no dispositivo. É o mecanismo do fornecedor, e é o correto.
- **Pixel da Meta e Insight Tag do LinkedIn não têm equivalente.** Se o arquivo deles já
  carregou nesta página, recusar **não o descarrega** — nada descarrega arquivo já
  carregado. O que o pacote garante a partir da recusa é que **nenhum evento novo** sai
  para os dois, e que na navegação seguinte eles não voltam a ser carregados.

## O que muda por site

| Item | Onde |
|---|---|
| Prefixo técnico e tudo preso a ele | `ferramentas/renomear-prefixo.sh` (passo 1) |
| Nome, tagline, endereço canônico | `config/site.json` → `site.*`, `ambiente.tipo`, `ambiente.url_canonica`, `ambiente.locale` |
| Domínios de prévia da hospedagem, indexação e fuso | `config/projeto.json` → `ambiente.dominios_de_previa`, `ambiente.indexar`, `ambiente.fuso` |
| Identidade visual | `fontes/tema/theme.json`, `fontes/tema/style.css`, `assets/*` |
| Conteúdo editorial | `content/pages/*.html`, `content/posts/*.html` |
| Páginas, posts, categorias, mídia declaradas | `config/site.json` → `paginas`, `posts`, `categorias`, `midia` |
| Navegação | `config/site.json` → `navegacao` |
| Contato e controlador | `config/projeto.json` → `contato.whatsapp_e164`, `contato.controlador.*` |
| Contrato de copy | `config/site.json` → `copy_contrato` |
| Herança do template | `config/site.json` → `conteudo.demonstrativo` |
| Resíduo da instalação limpa (`Hello world!`, `Sample Page`) | **não é pergunta ao operador**: é decisão do pacote, em `config/decisoes.tsv` → `conteudo.exemplo_do_wordpress`, com o motivo ao lado |
| Estrutura de permalinks e cobertura das URLs antigas | **não é configurável**: o pacote sempre aplica a estrutura declarada e cobre o endereço antigo com 301 (`F3Base_Imp_Lotes::PERMALINKS_COBRIR`). A decisão é medida antes de aplicada, e `lotes.permalinks_decisao` a cobra; a chave `ambiente.permalinks_decisao` não existe em arquivo de configuração nenhum |
| Plugins do cliente que já estavam instalados | `config/projeto.json` → `plugins_operacionais[]`, com `slug`, `finalidade` e `responsavel`. Nasce **vazia**, e vazia é estado válido e declarado. Não existe chave `plugins.protegidos`, nem em `site.json` nem em `projeto.json`: o que existe é a CLASSIFICAÇÃO que o preflight dá a cada plugin observado — `artefato-do-pacote`, `gerenciado`, `externo-preservado`, `emissor-concorrente` e `divergencia-a-classificar` |
| Piso de ambiente da hospedagem | **não é pergunta ao operador**: `config/decisoes.tsv` → `ambiente.limites_minimos.*` (tempo de execução, memória, upload e corpo da requisição), cada um com o que acontece abaixo dele |
| Retenção e base legal | `config/projeto.json` → `fato_juridico.base_legal` e `fato_juridico.retencao_leads_meses`. **O pacote lê as duas e não julga nenhuma** desde a 2.1.0: a base alimenta o texto da política, o prazo alimenta a retenção do `site-core`, e a declaração jurídica é de quem responde pelo site. O padrão de consentimento é decisão do pacote, em `config/decisoes.tsv` → `consentimento.padrao` |
| Padrões da instalação limpa que saem do site | **não é pergunta ao operador**: `config/decisoes.tsv` → `limpeza.temas_padrao` e `limpeza.plugins_padrao`, com o motivo e o preço declarados ao lado. Editar a lista é o único lugar onde essa decisão muda; o que ela não declara não é tocado |
| Página do formulário de cada regime | `config/projeto.json` → `formularios[].pagina_ref`. Ref vazia ou que não resolve **reprova a unidade**: o formulário criado precisa chegar à página declarada |
| Verificação de posse do domínio | `config/projeto.json` → `verificacao_dominio.google`, `verificacao_dominio.meta` — e as options `f3base_verificacao_google` e `f3base_verificacao_meta`. Vazias, nenhuma metatag é emitida; a verificação por DNS é alternativa e dispensa as duas |
| Token da Conversions API da Meta | **nunca** em arquivo de configuração nenhum: só a option `f3base_meta_capi_token`, gravada pelo canal. O arquivo único viaja dentro do zip, e segredo em arquivo que viaja é segredo copiado; `estatica.segredo_fora_da_configuracao` reprova se o nome reaparecer ali |
| Medição de GA4, Google Ads, Meta e LinkedIn | options do site-core: `f3base_gtm_container_id`, `f3base_ga4_measurement_id`, `f3base_google_ads`, `f3base_meta_pixel_id`, `f3base_linkedin_partner_id`, `f3base_linkedin_conversion_id` — todas operáveis pela tela e pelo canal, todas nascendo vazias e inertes. Container preenchido desliga toda tag direta |
| Eventos de comportamento: nomes, parâmetros, tetos e limiares | `dados/eventos-comportamento.tsv`, dentro do plugin (repositório próprio) — a declaração ÚNICA. Editar a tabela muda o comportamento sem release; renomear um evento depois de o site estar no ar quebra a série histórica da conta de medição |
| Seções medidas na página | classe `f3base-secao-<nome>` como `className` do bloco, nos patterns do tema. Sem a classe a seção não é medida, e o nome nunca é derivado do texto |
| Plugin de console do Google (Site Kit e afins) | `config/projeto.json` → `plugins_operacionais`, e **só ali** — ele entra como **leitor**, nunca como emissor. A emissão de toda tag de medição é do módulo `tracking` do `site-core`, em toda instância; a pré-condição do leitor é ter o snippet e a medição automática de conversões **desligados**, medida no preflight e conferida no HTML publicado por `tracking.emissor_unico`. A lista nasce **vazia**: lista vazia é estado válido e declarado |

## Medição: como usar em um site novo

Esta seção é para quem vai construir o próximo site. Ela responde três perguntas na ordem
em que elas aparecem: o que já funciona sem preencher nada, o que exige preencher, e o que
o conteúdo precisa declarar para a medição não ficar cega.

### O ciclo de release do plugin — leia isto antes de tudo

O `base-site-core-fator3` **tem versão própria**, é instalado do catálogo pela URL declarada
e traz a cópia embutida no bundle como **reserva**. O ciclo inteiro — os três passos, o
motivo de o terceiro ser o único que alcança os sites já entregues, e por que a constante de
versão não é digitada — está no **passo 7** desta mesma ordem de execução. Ele não é repetido
aqui: uma segunda cópia diverge da primeira na primeira vez que alguém corrigir uma só.

E, para MUDAR o plugin em vez de só publicá-lo, o documento é `INSTRUCOES-DO-PLUGIN.md`,
dentro do zip dele.

### O que a medição dá de graça, sem preencher nada

Num site recém-implantado, com o `projeto.json` intocado e **nenhum ID de fornecedor**, o
menu **Medição** do wp-admin já responde:

| O que aparece | O que ele responde |
|---|---|
| Pessoas diferentes, por dia | quantos navegadores distintos visitaram, e quanto disso é gente voltando |
| Até onde as pessoas descem, em cada página | onde a leitura acaba, com o tempo típico até cada marco e quantas releituras |
| O que aconteceu nas páginas | cada evento declarado com a pergunta que ele responde e as páginas em que aconteceu |
| Como a página carrega | TTFB, LCP, CLS e INP medidos em visitas reais, com a explicação e o limiar de "bom" ao lado |

Isso não depende de conta nenhuma de fornecedor: os dados são somados no próprio site, em
tabela própria, e lidos pelo canal MCP sem credencial de terceiro. Um site sem GA4 continua
medindo — foi um defeito da 1.3.2 o contrário disso, e ele tem checagem.

### O que exige preencher

| Para quê | Onde |
|---|---|
| Os mesmos acontecimentos irem também ao GA4, Google Ads, Meta e LinkedIn | `projeto.json` → `tracking.*`, ou as options pelo canal. Slot vazio é inerte: sem ID, nenhuma tag é emitida |
| Um contêiner do GTM decidir o caminho | `tracking.gtm_container_id`. Preenchido, ele **desliga toda tag direta** — é a estrutura que impede a mesma conversão de ser contada duas vezes |
| A base legal do tratamento | `projeto.json` → `fato_juridico.base_legal`. **A medição agora coleta dado pessoal pseudonimizado** (ver abaixo), e a política publicada já descreve isso; a hipótese legal que sustenta o tratamento continua sendo declaração de quem responde pelo site |

O prazo de retenção nasce preenchido e o padrão de consentimento é decisão do pacote — não
são perguntas ao operador. Os dois estão em `config/decisoes.tsv`, com o motivo ao lado.

### O que o conteúdo precisa declarar

**Seção vista só é medida em bloco que carrega a classe `f3base-secao-<nome>`.** Página sem
nenhuma seção declarada não gera evento nenhum de seção: o observador é instalado e não
recebe alvo. Foi exatamente isso que manteve `f3base_secao_vista` em zero linha até a
1.4.1, quando a marca existia apenas nos patterns do tema e nenhuma página entregue a
carregava.

A marca precisa estar nos **dois** lugares que o WordPress serve:

```html
<!-- wp:group {"className":"f3base-secao-abertura", … } -->
<div class="wp-block-group f3base-secao-abertura" …>
```

Escrita em um só, o editor reescreve o outro na primeira edição e a marca some sem aviso.
`estatica.conteudo_declara_secoes` reprova as duas formas de errar isso.

O nome da seção **não** sai do título: ele é escrito no markup e é estável. Nome derivado de
texto muda sozinho na primeira revisão de copy, e a série histórica ganha uma seção nova e
perde outra sem que nada tenha mudado na página.

**A mesma lógica vale para as saídas do site.** "Saiu para exemplo.com" só existe se alguma
página publicada tiver um `href` para fora do domínio. Um site cujo conteúdo é todo interno
não gera nenhuma saída, e o quadro fica em branco por ausência do que medir — não por
defeito. A tela diz isso com todas as letras, e a diferença importa: um zero seco fez o
operador procurar um coletor quebrado que não existia.

A regra geral, para quem cria conteúdo: **o que o conteúdo não declara, a medição não mede.**
Bloco sem `f3base-secao-*` não vira seção vista; página sem link externo não vira saída.
Nenhum dos dois é falha do coletor.

### O que o agente MCP precisa saber

| Regra | Motivo |
|---|---|
| A emissão de tag é **do módulo `tracking`**, e de mais ninguém | duas fontes para a mesma conversão contam em dobro e reescrevem o lance do leilão. Plugin de console entra como **leitor**, com o snippet dele desligado |
| Os nomes de evento e os limiares saem de `dados/eventos-comportamento.tsv` | renomear um evento em qualquer outro lugar quebra a série histórica sem erro nenhum |
| As explicações e os limiares das medidas de carregamento saem de `dados/vitais.tsv` | mesma razão: eles envelhecem junto com a medida |
| As options operáveis estão em `f3base_operaveis` | é a lista que declara o que pode ser gravado pelo canal sem esperar por uma release |
| `f3base/como-usar` responde tudo isso por habilidade | o manual sai do registro de módulos, e não de texto à mão: módulo novo aparece nele sozinho |

### Privacidade: o que é agregado e o que é pseudonimizado

O site guarda **duas coisas diferentes**, e a diferença é o que decide os prazos.

| | Resumo (`f3base_comportamento`) | Registro (`f3base_eventos`) |
|---|---|---|
| O que guarda | totais por dia, página e evento | cada acontecimento, com apelido do visitante, apelido da visita, o deslocamento em milissegundos desde o carregamento e o INSTANTE do acionamento |
| Soma? | **sim, por desenho** — duas visitas ao mesmo bloco no mesmo dia caem na mesma linha | **não**: nada soma e nada é reescrito, cada acionamento tem `id` próprio |
| Identifica alguém? | não | **é dado pessoal pseudonimizado** |
| Prazo | 90 dias | **30 dias** |
| Para que serve | a série histórica do painel | tempo até cada marco, releitura e contagem de pessoas |

O apelido é **sorteado** no navegador (`crypto.getRandomValues`), guardado no
`localStorage` **deste domínio** sob a chave `f3base_visitante`, e **nunca em cookie** —
cookie viaja em toda requisição, inclusive para o CDN. Ele não é derivado de característica
nenhuma do aparelho: não há fingerprint, e o mesmo visitante em outro navegador é outra
pessoa para este site.

Ele nasce **depois** do portão de consentimento: quem recusou nunca tem apelido sorteado.
Quem recusa no controle do rodapé tem, no mesmo ato, o apelido apagado do navegador **e** o
registro apagado do servidor, pela rota `/comportamento/esquecer` — apagar em um lado só
faria o próximo aceite ressuscitar o mesmo identificador.

O prazo do registro **nunca** pode passar o do resumo: o sanitizador impede, e há piso. O
resumo não é derivado do registro de propósito — derivá-lo faria a série do painel evaporar
junto com o log na primeira execução da retenção.

A política de privacidade que o pacote publica já descreve tudo isso, em seção própria.
Trocar o conteúdo do site não dispensa manter essa descrição: um site que coleta e não
descreve está afirmando algo falso sobre si mesmo.


## Dois artefatos, dois repositórios, dois ciclos

O implantador e o plugin têm números independentes e repositórios independentes, e o que
cada um publica está no **passo 7**. O que vale repetir aqui é a fronteira, porque ela
decide o que você faz quando algo precisa mudar:

- **mudou o SITE** — conteúdo, identidade, contato, medição de conta: é este documento;
- **mudou o PLUGIN** — módulo, evento, option, rota, tabela: é `INSTRUCOES-DO-PLUGIN.md`,
  dentro do zip dele, e sai uma release do plugin no repositório DELE — seguida, deste lado,
  das três edições do passo 7 (zip, `sha256`, `partilhado/`) e de uma release do implantador;
- **mudou o IMPLANTADOR** — lotes, preflight, relatório, suíte: é `README.md`, e sai uma
  release do implantador.

**A fonte do plugin não mora neste pacote**: nada no implantador constrói, gera ou edita o
plugin, e o que há dele aqui — a reserva e `partilhado/` — é cópia conferida por hash.

## Depois da entrega, o site é do agente

Este pacote põe um site no ar. Dali em diante, quem muda o site é o agente pelo canal
MCP — **tema, plugins e conteúdo, sem exceção**. Não há aqui nenhuma instrução de "não
editar": o pacote não protege o que ele instalou de quem vai operá-lo.

O que o pacote continua garantindo, porque a ausência quebra o site de verdade:

| Garantia | Por que ela fica |
|---|---|
| **Sintaxe conferida antes de gravar PHP** | arquivo com erro de sintaxe derruba o site inteiro, e o erro aparece depois do salvamento |
| **Leitura de volta depois de gravar** | gravar não é configurar: o destino pode descartar ou transformar a escrita em silêncio |
| **Escrita em banco em duas fases** | execução interrompida no meio deixaria o site com metade da mudança |
| **`wp-config.php` e o core intocados** | são de quem hospeda; editá-los quebra atualização e recuperação |
| **HTTPS e conferência de digesto no download de plugin** | é o único ponto em que código de fora entra no site |
| **Não sobrescrever o que o agente já escreveu** | o merge de três vias preserva a edição feita pelo canal; é o trabalho do agente que ele protege |

