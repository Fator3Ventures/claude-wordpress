# Contraste, paleta e tipografia — tema F3 Base 1.0.0

Documento de prova do sistema de cor e de fonte do `theme.json`. As razões abaixo
foram **calculadas** pela fórmula de luminância relativa da WCAG 2.x
(`(L_claro + 0,05) / (L_escuro + 0,05)`, sRGB linearizado), não estimadas a olho.
Piso adotado: **4,5:1** para texto normal (AA, 1.4.3) e **3:1** para borda,
separador e anel de foco (AA, 1.4.11 — contraste de componente não textual).

**Escopo deste arquivo:** documentação, não artefato servido. Os hexadecimais
abaixo existem para que a conta seja refeita e conferida — os valores canônicos
moram no `theme.json`, e a checagem `tema.sem_cor_literal` varre os arquivos que
produzem saída (`.css`, `.html`, `.php`, `.svg`), onde não há nenhum literal.

## Paleta

| Slug | Hex | Papel — quem consome |
|---|---|---|
| `base` | `#ffffff` | fundo do corpo · texto do botão primário · cabeçalho fixo · fundo dos cartões · link e título sobre faixa escura · anel de foco sobre faixa escura |
| `superficie` | `#f1f3f7` | fundo da seção de cartões · fundo de `core/details` e `core/code` · texto do rodapé e do herói |
| `borda` | `#767f8f` | `core/separator` · borda de `core/details` e `core/code` · borda dos campos de formulário próprios · borda inferior do cabeçalho |
| `suave` | `#545c6b` | texto secundário: `core/post-date`, `core/post-terms`, legenda, linha de apoio |
| `primaria` | `#0f4c81` | link · fundo e borda do botão · borda esquerda de `core/quote` · anel de foco sobre fundo claro |
| `primaria-forte` | `#0a3557` | link e botão em `:hover` e `:focus` |
| `contraste` | `#14171c` | texto do corpo · títulos · título do site · itens de navegação · texto do painel do menu compacto |
| `inverso` | `#0e1116` | faixa escura: herói, rodapé, chamada de contato · texto do botão sobre a faixa escura |

## Razões medidas — texto (piso 4,5:1)

| Frente | Fundo | Razão | Onde aparece |
|---|---|---|---|
| `contraste` | `base` | **17,96:1** | texto do corpo, títulos |
| `contraste` | `superficie` | **16,17:1** | texto dentro de cartão, painel do menu compacto |
| `suave` | `base` | **6,73:1** | data, categorias, legenda, linha de apoio |
| `suave` | `superficie` | **6,06:1** | texto secundário dentro de cartão |
| `primaria` | `base` | **8,86:1** | link em repouso |
| `primaria` | `superficie` | **7,97:1** | link dentro de cartão / seção clara |
| `primaria-forte` | `base` | **12,65:1** | link em `:hover` / `:focus` |
| `primaria-forte` | `superficie` | **11,39:1** | link em `:hover` dentro de cartão |
| `base` | `primaria` | **8,86:1** | texto do botão primário |
| `base` | `primaria-forte` | **12,65:1** | texto do botão em `:hover` / `:focus` |
| `base` | `inverso` | **18,91:1** | título e link sobre a faixa escura |
| `superficie` | `inverso` | **17,02:1** | texto corrido do rodapé e do herói |
| `inverso` | `base` | **18,91:1** | texto do botão invertido sobre a faixa escura |
| `inverso` | `superficie` | **17,02:1** | texto do botão invertido em `:hover` |

Menor razão de texto do sistema: **6,06:1** (`suave` sobre `superficie`) — folga de
1,35× sobre o piso AA.

## Razões medidas — não texto (piso 3:1)

| Frente | Fundo | Razão | Onde aparece |
|---|---|---|---|
| `borda` | `base` | **4,04:1** | borda de campo de formulário, separador, borda do cabeçalho |
| `borda` | `superficie` | **3,63:1** | borda de `core/details` e `core/code` |
| `borda` | `inverso` | **4,69:1** | separador do rodapé |
| `primaria` | `base` | **8,86:1** | anel de foco sobre fundo claro |
| `base` | `inverso` | **18,91:1** | anel de foco sobre a faixa escura (regra 15 do `style.css`) |

O anel de foco troca de cor sobre fundo escuro **porque `primaria` sobre `inverso`
reprova** (razão abaixo de 3:1). É a única regra de cor do `style.css`, e existe
por medição, não por gosto.

## Alvo mínimo (WCAG 2.2 AA, 2.5.8)

Piso de 24×24 px; o tema adota **44×44 px** nos controles próprios —
`--f3base-alvo-minimo` no `style.css`, aplicado ao link de pular, aos botões de
abrir e fechar o menu compacto, ao controle de consentimento e aos controles de
formulário. O botão nativo (`elements.button`) fecha ~43 px de altura com o
`padding` `xs`/`md` e a fonte `normal`. Link em linha corrida segue a exceção do
próprio critério.

## Tipografia: por que não há arquivo de fonte

O `theme.json` declara duas famílias em **pilha nativa do sistema** (`sistema` e
`mono`) e **nenhum `fontFace`**. O motivo é factual, não preferência: a chave
`tema.fontes` do `config/site.json` vem vazia e **não há binário de fonte no
pacote**. A regra do método — fontes auto-hospedadas, `font-display: swap`,
versão no nome do arquivo, nunca Google Fonts por CDN (performance e LGPD: a
chamada ao CDN entrega o IP do visitante sem base legal) — **continua valendo** e
é o caminho para quem embutir uma fonte: acrescentar o `.woff2` em `assets/`,
declarar `fontFace` na família e o `preload` da face do primeiro render. Enquanto
não houver binário, referenciar arquivo inexistente produziria 404 em toda página
— pior que a pilha do sistema, que renderiza sem requisição nenhuma.

A escala tipográfica é própria e o `theme.json` desliga os presets do core
(`defaultFontSizes: false`), pela armadilha medida: o WordPress injeta presets com
**os mesmos slugs do tema** e eles vencem no global-styles.

## Contrato de apresentação tema ↔ site-core

O tema fornece a apresentação; o comportamento é do `site-core` (princípio 4).
Os nomes abaixo são o contrato — mudar um lado sem o outro quebra em silêncio.

| Marca no HTML | Quem emite | Quem estiliza / consome |
|---|---|---|
| `add_theme_support( 'f3base-consentimento-rodape' )` | tema (`functions.php`) | `site-core`: com o suporte declarado ele NÃO imprime o botão dele em `wp_footer` — sem isso a página fica com dois controles |
| `.f3base-consentimento-rodape` · `.f3base-consentimento-abrir` · `[data-f3base-consentimento="abrir"]` · `aria-controls="f3base-consentimento-banner"` | tema (`parts/footer.html`), com markup idêntico ao de reserva do `site-core` | `style.css` (regra 13): LINK DE TEXTO, sem borda, sem fundo e sem padding — a cor sai de `--wp--style--color--link`, que é a mesma que o `<a>` vizinho consome. O `site-core` liga o comportamento pelo seletor `[data-f3base-consentimento]`, alterna `aria-expanded` e devolve o foco a este controle ao fechar |
| `.f3base-consentimento-banner` · `.f3base-consentimento-caixa` · `.f3base-consentimento-acoes` · `#f3base-consentimento-banner` | `site-core`, na carga da página, FECHADO | `style.css` (regra 13b): `position: fixed` na BASE do viewport, com a altura do conteúdo — nunca `inset: 0` —, e sem ancestral que crie bloco contentor. Todo `display` declarado aqui vem com o par `[hidden] { display: none }`: regra de autor vence a folha do user agent, e sem o par o `hidden` que o `site-core` alterna não teria efeito nenhum |
| `.f3base-acao-contato` → `data-f3base-lead` no `<a>` | classe no pattern; o atributo é carimbado pelo tema em `render_block`, prioridade **5** | `site-core` decide em `render_block`, prioridade 10, pela CLASSE: **com** número em `f3base_contato` ele promove o `href` a `wa.me`; **sem** número ele NÃO publica o bloco — botão que não leva a lugar nenhum é pior que não ter botão. A decisão é pela classe e não pelo atributo porque o atributo depende de `WP_HTML_Tag_Processor`, e decidir por ele deixaria o botão publicado justamente onde o processador não existe |
| `.f3base-formulario` | `site-core` / plugin de formulário | `style.css` (regras 10 e 11): margem zerada nos campos e `font-size: 1rem` explícito nos controles |
| `.f3base-link-privacidade` | tema (`parts/footer.html`) | o próprio tema, em `render_block`: troca o `href` pelo permalink real e remove o parágrafo quando não há política **publicada** |
| `.f3base-secao-<nome>` nos patterns (`abertura`, `texto`, `cartoes`, `faq`, `contato`) | tema (`patterns/*.php`), como `className` do bloco — nunca atributo cru, que quebraria a validação do editor | `site-core`: o coletor de seção vista lê o token pelo prefixo publicado em `F3Base_Modulo_Tracking::PREFIXO_SECAO` e emite o nome. **Sem a classe, a seção não é medida** — e é a escolha certa: nome derivado de título mudaria sozinho na primeira revisão de copy, e a série histórica que um agente compara entre períodos ganharia uma seção nova e perderia outra sem que nada tivesse mudado na página. A classe não tem apresentação nenhuma no `style.css`, de propósito: ela é marca de medição |
| `.f3base-regiao` · `.f3base-cabecalho` · `.f3base-faixa-escura` · `.f3base-cartao` · `.f3base-pular` | tema | `style.css` — apresentação pura, sem contraparte no plugin |

## Onde o contraste é responsabilidade do conteúdo

O lockdown fecha a UI do editor, mas **não alcança quem grava markup direto** (o
agente de manutenção, via MCP). Conteúdo publicado que introduza par de cor novo
é coberto pela checagem `conteudo.sem_estilo_avulso`, não por este documento.
