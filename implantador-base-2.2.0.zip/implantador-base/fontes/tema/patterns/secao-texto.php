<?php
/**
 * Title: Seção de texto
 * Slug: f3base/secao-texto
 * Categories: f3base, text
 * Description: Bloco de texto corrido com título de seção, parágrafos e lista — a unidade de leitura das páginas internas.
 * Keywords: texto, conteúdo, lista
 * Viewport Width: 1280
 * Inserter: true
 *
 * @package f3base
 */

?>
<!-- wp:group {"className":"f3base-secao-texto","layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|md","padding":{"top":"var:preset|spacing|xl","bottom":"var:preset|spacing|xl"}}}} -->
<div class="wp-block-group f3base-secao-texto" style="padding-top:var(--wp--preset--spacing--xl);padding-bottom:var(--wp--preset--spacing--xl)"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Arquitetura em três peças', 'f3base' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'O que o visitante vê mora no tema. O que precisa continuar funcionando depois da entrega mora no plugin persistente. O que só existe durante a implantação mora no implantador, que se desativa quando termina. A fronteira não é estética: ela decide o raio de impacto de cada mudança futura.', 'f3base' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><?php esc_html_e( 'Tema: apresentação. Paleta, escala tipográfica, espaçamento e estilo de bloco centralizados no theme.json.', 'f3base' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Plugin persistente: comportamento. Rotas, consentimento, retenção e registro de leads sobrevivem à troca de tema.', 'f3base' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Implantador: aplicação. Grava o estado desejado, lê de volta o que gravou e só então se desativa.', 'f3base' ); ?></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->
