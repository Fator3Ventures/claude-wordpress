<?php
/**
 * Title: Perguntas frequentes
 * Slug: f3base/faq
 * Categories: f3base, text
 * Description: Lista de perguntas e respostas em blocos de detalhes nativos, abertos por clique ou por teclado.
 * Keywords: faq, perguntas, dúvidas
 * Viewport Width: 1280
 * Inserter: true
 *
 * @package f3base
 */

?>
<!-- wp:group {"className":"f3base-secao-faq","layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|sm","padding":{"top":"var:preset|spacing|xl","bottom":"var:preset|spacing|xl"}}}} -->
<div class="wp-block-group f3base-secao-faq" style="padding-top:var(--wp--preset--spacing--xl);padding-bottom:var(--wp--preset--spacing--xl)"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Perguntas frequentes', 'f3base' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:details -->
<details class="wp-block-details"><summary><?php esc_html_e( 'Quem edita o menu depois da entrega?', 'f3base' ); ?></summary><!-- wp:paragraph -->
<p><?php esc_html_e( 'O menu é um objeto único no banco, editado por rota tipada. Não há arquivo para tocar nem versão para subir, e duas páginas divergirem de menu deixa de ser possível, porque só existe uma cópia.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary><?php esc_html_e( 'Como o site trata cookies e medição?', 'f3base' ); ?></summary><!-- wp:paragraph -->
<p><?php esc_html_e( 'As tags carregam por padrão e o controle de revisão fica no rodapé de toda página publicada. A negativa desliga as tags na mesma sessão e persiste pelo prazo declarado; o novo aceite religa.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary><?php esc_html_e( 'O que acontece quando uma checagem reprova?', 'f3base' ); ?></summary><!-- wp:paragraph -->
<p><?php esc_html_e( 'A execução para de afirmar sucesso. O relatório nomeia a checagem, a classe de evidência e a fase, e o implantador não se desativa enquanto houver entregável pendente.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group -->
