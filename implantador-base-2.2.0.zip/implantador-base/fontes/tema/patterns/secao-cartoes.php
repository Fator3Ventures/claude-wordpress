<?php
/**
 * Title: Seção de cartões
 * Slug: f3base/secao-cartoes
 * Categories: f3base, columns
 * Description: Faixa de largura total com três cartões lado a lado, cada um com subtítulo e descrição curta.
 * Keywords: cartões, colunas, destaques
 * Viewport Width: 1280
 * Inserter: true
 *
 * @package f3base
 */

?>
<!-- wp:group {"align":"full","className":"f3base-secao-cartoes","backgroundColor":"superficie","layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|md","padding":{"top":"var:preset|spacing|xl","bottom":"var:preset|spacing|xl"}}}} -->
<div class="wp-block-group alignfull f3base-secao-cartoes has-superficie-background-color has-background" style="padding-top:var(--wp--preset--spacing--xl);padding-bottom:var(--wp--preset--spacing--xl)"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php esc_html_e( 'O que a verificação prova', 'f3base' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"suave"} -->
<p class="has-suave-color has-text-color"><?php esc_html_e( 'Checagem que nunca falhou não é evidência. Toda regra tem um piso: uma amostra com o defeito plantado, que precisa reprovar.', 'f3base' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|md","left":"var:preset|spacing|md"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"f3base-cartao","backgroundColor":"base","layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|xs","padding":{"top":"var:preset|spacing|md","right":"var:preset|spacing|md","bottom":"var:preset|spacing|md","left":"var:preset|spacing|md"}}}} -->
<div class="wp-block-group f3base-cartao has-base-background-color has-background" style="padding-top:var(--wp--preset--spacing--md);padding-right:var(--wp--preset--spacing--md);padding-bottom:var(--wp--preset--spacing--md);padding-left:var(--wp--preset--spacing--md)"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php esc_html_e( 'Teto e piso', 'f3base' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'O teto é o que a checagem aprova. O piso é o defeito plantado que ela precisa acusar. Sem piso, a suíte é indistinguível de uma suíte cega.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"f3base-cartao","backgroundColor":"base","layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|xs","padding":{"top":"var:preset|spacing|md","right":"var:preset|spacing|md","bottom":"var:preset|spacing|md","left":"var:preset|spacing|md"}}}} -->
<div class="wp-block-group f3base-cartao has-base-background-color has-background" style="padding-top:var(--wp--preset--spacing--md);padding-right:var(--wp--preset--spacing--md);padding-bottom:var(--wp--preset--spacing--md);padding-left:var(--wp--preset--spacing--md)"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php esc_html_e( 'Classe de evidência', 'f3base' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Cada linha do relatório diz como soube: medida, teste funcional, análise estática, leitura de volta ou inferência. Nome de classe errado é defeito de relatório.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"f3base-cartao","backgroundColor":"base","layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|xs","padding":{"top":"var:preset|spacing|md","right":"var:preset|spacing|md","bottom":"var:preset|spacing|md","left":"var:preset|spacing|md"}}}} -->
<div class="wp-block-group f3base-cartao has-base-background-color has-background" style="padding-top:var(--wp--preset--spacing--md);padding-right:var(--wp--preset--spacing--md);padding-bottom:var(--wp--preset--spacing--md);padding-left:var(--wp--preset--spacing--md)"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php esc_html_e( 'Leitura de volta', 'f3base' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Gravar não é configurar. O que decide é reler do banco a chave gravada e conferir o valor — e reverter quando o destino descartou a escrita em silêncio.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
