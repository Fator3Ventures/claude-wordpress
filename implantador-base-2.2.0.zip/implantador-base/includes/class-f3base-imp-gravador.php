<?php
/**
 * Ponto único de escrita.
 *
 * TODA option gravada por esta implantação passa por aqui — as do WordPress, as
 * do `site-core` e as de TERCEIRO (SEO, formulário, i18n). Gravador especializado
 * que chame `update_option()` direto fica fora do journal e fora da procedência,
 * e rollback que restaura duas de dez options não é rollback: é relatório
 * otimista. A checagem correspondente é estrutural: nenhuma chamada direta a
 * `update_option`/`update_site_option`/`delete_option` fora deste arquivo.
 *
 * MERGE DE TRÊS VIAS NAS OPTIONS, desde a 1.1.0. As options que o agente opera
 * depois da instalação passam por `merge_option()` antes de qualquer escrita:
 * o pacote registra a BASE — o último valor que ele mesmo aplicou — e compara
 * as três vias. Edição feita pelo canal vence a reexecução; a configuração só
 * vence quando mudou aquela mesma coisa depois, e aí a sobreposição sai nomeada
 * com os dois valores. Até a 1.0.19 a comparação era de duas vias — observado
 * contra desejado — e toda edição do agente era revertida em silêncio.
 *
 * O ciclo de cada escrita: preimagem → journal → escrita → LEITURA DE VOLTA.
 * Divergiu, tenta os caminhos alternativos declarados; divergiu ainda assim,
 * REVERTE pelo journal e devolve BLOCKED com a chave e a versão nomeadas — que é
 * o único gate que sobra quando o plugin de terceiro pode mudar embaixo do site
 * sem release nossa.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gravador único, com journal, procedência e leitura de volta.
 */
final class F3Base_Imp_Gravador {

	/**
	 * Option de procedência — a mesma que o `site-core` lê.
	 */
	public const OPTION_PROVENIENCIA = 'f3base_proveniencia';

	/**
	 * Procedências fechadas, espelhando as do `site-core`.
	 */
	public const ORIGEM_IMPLANTADOR = 'implantador';
	public const ORIGEM_MANUAL      = 'edicao-manual';
	public const ORIGEM_PADRAO      = 'padrao';

	/**
	 * A QUARTA resposta, e ela é deste lado só.
	 *
	 * O site-core, quando não acha entrada no registro para uma option que
	 * existe, devolve `implantador` por FALLBACK — do lado dele o palpite é
	 * bom, porque quase tudo que existe sem registro veio daqui. Deste lado
	 * ele seria uma licença para gravar por cima: sem base, este pacote NÃO
	 * escreveu aquele valor, e chamar de "meu" o que não se sabe de quem é é
	 * exatamente o erro que a 2.2.0 fecha. Então a ausência de entrada tem
	 * nome próprio, e o nome não é nenhuma das três origens.
	 */
	public const ORIGEM_NAO_REGISTRADA = 'nao-registrada';

	/**
	 * Ações fechadas do merge de três vias de OPTION.
	 *
	 * As mesmas quatro decisões que o conteúdo já tinha, mais a da PRIMEIRA
	 * execução — porque estrutura de estado nova precisa declarar o que faz
	 * quando ainda não existe estado, e não declarar isso foi defeito medido.
	 */
	public const MERGE_NADA      = 'nada';
	public const MERGE_GRAVAR    = 'gravar';
	public const MERGE_PRESERVAR = 'preservar';
	public const MERGE_SOBREPOR  = 'sobrepor';
	public const MERGE_NASCER    = 'nascer';

	/**
	 * O que acontece com a BASE depois da decisão.
	 *
	 * A REGRA QUE FALTAVA, e o defeito que ela corrige. Preservar movendo a base
	 * para o valor observado apaga o fato que a preservação existe para
	 * lembrar: na execução seguinte a base passaria a ser IGUAL ao observado, o
	 * ramo "ninguém tocou" ganharia, e a primeira mudança da configuração
	 * gravaria por cima da edição SEM nomear sobreposição nenhuma. A proteção
	 * valeria por uma execução, e o ramo em que o pacote vence o agente — o
	 * único que precisa ser visível — ficaria praticamente inalcançável.
	 *
	 * Então: quem preserva NÃO mexe na base. Ela continua sendo o último valor
	 * que ESTE pacote aplicou, que é a definição dela.
	 */
	public const BASE_DESEJADO   = 'desejado';
	public const BASE_INALTERADA = 'inalterada';

	/**
	 * Estados fechados devolvidos por este gravador.
	 */
	public const OK      = 'OK';
	public const FALHA   = 'FALHA';
	public const BLOCKED = 'BLOCKED';
	public const NA      = 'N/A';

	/**
	 * Modo simulação: relata, não grava.
	 *
	 * @var bool
	 */
	private static bool $simulacao = false;

	/**
	 * Modo somente-RELATÓRIO: relata contra a BASE, não contra a configuração.
	 *
	 * Ele é um subconjunto da simulação — nada é gravado nos dois —, e é uma
	 * bandeira separada porque a PERGUNTA é outra. A simulação responde "o que
	 * esta execução faria se eu mandasse aplicar?", e o leitor dela é quem está
	 * prestes a aplicar. O modo somente-relatório roda na cadência, num site que
	 * o agente opera há semanas, e a pergunta dele é "o que mudou desde a última
	 * aplicação?".
	 *
	 * @var bool
	 */
	private static bool $relatorio = false;

	/**
	 * Escritas desta execução, para o relatório.
	 *
	 * @var array<int,array<string,mixed>>
	 */
	private static array $escritas = array();

	/**
	 * Sentinela para distinguir "option ausente" de "option com valor falso".
	 *
	 * @var string
	 */
	private const AUSENTE = "\0f3base-option-ausente\0";

	/**
	 * Liga ou desliga o modo simulação.
	 *
	 * @param bool $ligado Ligado.
	 * @return void
	 */
	public static function simulacao( bool $ligado ): void {
		self::$simulacao = $ligado;
	}

	/**
	 * O gravador está em simulação?
	 *
	 * @return bool
	 */
	public static function em_simulacao(): bool {
		return self::$simulacao;
	}

	/**
	 * Liga ou desliga o modo somente-relatório.
	 *
	 * @param bool $ligado Ligado.
	 * @return void
	 */
	public static function relatorio( bool $ligado ): void {
		self::$relatorio = $ligado;
	}

	/**
	 * O gravador está no modo somente-relatório?
	 *
	 * @return bool
	 */
	public static function em_relatorio(): bool {
		return self::$relatorio;
	}

	/**
	 * Escritas registradas nesta execução.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function escritas(): array {
		return self::$escritas;
	}

	/**
	 * A ORIGEM REGISTRADA de uma option, lida do registro do site-core.
	 *
	 * `f3base_proveniencia` é FRONTEIRA — declarada como tal em
	 * `partilhado/dados/contrato-de-nomes.tsv` — e é escrita pelos dois lados:
	 * o plugin persistente grava `edicao-manual` quando a tela dele grava e
	 * `padrao` quando a ativação dele semeia o catálogo; este gravador grava
	 * `implantador` a cada escrita sua. Ler daqui é ler o que o outro runtime
	 * declarou, não adivinhar.
	 *
	 * A option AUSENTE devolve string vazia, que é fato diferente de "existe e
	 * ninguém registrou": o primeiro não tem nada a preservar, o segundo tem.
	 *
	 * @param string $nome   Nome da option observada.
	 * @param bool   $existe A option existe no banco?
	 * @return string Uma das origens do vocabulário, `nao-registrada`, ou vazia.
	 */
	private static function proveniencia_observada( string $nome, bool $existe ): string {
		if ( ! $existe ) {
			return '';
		}

		$registro = get_option( self::OPTION_PROVENIENCIA, array() );

		if ( ! is_array( $registro ) || ! isset( $registro[ $nome ] ) ) {
			return self::ORIGEM_NAO_REGISTRADA;
		}

		$entrada = $registro[ $nome ];
		$origem  = is_array( $entrada ) && isset( $entrada['origem'] ) ? (string) $entrada['origem'] : '';

		if ( ! is_array( $entrada ) && is_scalar( $entrada ) ) {
			$origem = (string) $entrada;
		}

		return in_array( $origem, array( self::ORIGEM_IMPLANTADOR, self::ORIGEM_MANUAL, self::ORIGEM_PADRAO ), true )
			? $origem
			: self::ORIGEM_NAO_REGISTRADA;
	}

	/**
	 * O QUE FAZER SEM BASE, decidido pela PROVENIÊNCIA. FUNÇÃO PURA.
	 *
	 * Quatro ramos, e cada um responde a uma pergunta diferente sobre quem
	 * escreveu o valor que está no banco:
	 *
	 * 1. **A option não existe** (proveniência vazia) — não há o que perder, e
	 *    é o caminho de toda instalação limpa: o desejado é aplicado e a base
	 *    nasce.
	 * 2. **`padrao`** — quem escreveu foi a ATIVAÇÃO do plugin, que grava todo
	 *    o catálogo dele com o padrão declarado. Isso não é escolha de
	 *    ninguém, e é por isso que este ramo GRAVA: sem ele, a release travaria
	 *    toda implantação normal, porque depois de ativar o site-core todas as
	 *    options já existem.
	 * 3. **`edicao-manual`** — um humano gravou este valor na tela do plugin.
	 *    PRESERVA. É o defeito que a 2.2.0 fecha, e o preço está declarado: o
	 *    valor do arquivo único não chega ao banco, e quem quiser que chegue
	 *    apaga o campo na tela antes de executar ou grava pelo canal depois.
	 * 4. **Origem não registrada, com a option existindo** — sem base, este
	 *    pacote não escreveu este valor; alguém escreveu, por um caminho que
	 *    não passou pelo gravador único de nenhum dos dois lados. PRESERVA,
	 *    dizendo isso. Destruir um valor cuja origem não se sabe é a escolha
	 *    que não tem volta.
	 *
	 * `implantador` cai no ramo 1 de propósito: a base é a impressão do que
	 * ESTE pacote aplicou, e uma proveniência dizendo `implantador` sem base
	 * nenhuma é o que sobra de uma instalação anterior — o valor é do pacote, e
	 * a configuração corrente manda nele.
	 *
	 * @param string $proveniencia Origem registrada da option observada, ou vazia quando ela não existe.
	 * @return array{acao:string,base:string,motivo:string}
	 */
	public static function merge_sem_base( string $proveniencia ): array {
		if ( self::ORIGEM_MANUAL === $proveniencia ) {
			return array(
				'acao'   => self::MERGE_PRESERVAR,
				'base'   => self::BASE_INALTERADA,
				'motivo' => __( 'PRESERVADA pela proveniência: esta option foi gravada na tela do plugin persistente, com origem "edicao-manual", e este pacote nunca aplicou valor nenhum aqui. Quem opera o site decidiu isto antes de a implantação existir, e a implantação não desfaz decisão de operador. O valor da configuração NÃO foi aplicado, e sai nomeado ao lado do preservado.', 'f3base' ),
			);
		}

		if ( self::ORIGEM_NAO_REGISTRADA === $proveniencia ) {
			return array(
				'acao'   => self::MERGE_PRESERVAR,
				'base'   => self::BASE_INALTERADA,
				'motivo' => __( 'PRESERVADA por origem não registrada: a option já existe no banco, este pacote nunca aplicou valor nenhum aqui e ninguém registrou quem a escreveu. Sem base e sem origem, gravar por cima seria destruir um valor de dono desconhecido.', 'f3base' ),
			);
		}

		return array(
			'acao'   => self::MERGE_NASCER,
			'base'   => self::BASE_DESEJADO,
			'motivo' => __( 'PRIMEIRA execução com base de option nesta instalação: não havia base para esta option, e o valor observado — ausente, padrão do plugin ou deste próprio pacote — não é decisão de operador. O desejado é aplicado e a base NASCE agora; a partir daqui, uma edição feita pelo canal sobre este valor passa a ser reconhecida como edição e preservada.', 'f3base' ),
		);
	}

	/**
	 * Decisão do merge de três vias de uma OPTION. FUNÇÃO PURA.
	 *
	 * A MESMA regra que o conteúdo tem desde a 1.0.4, aplicada ao valor de uma
	 * option — e o defeito que ela corrige estava medido: até a 1.0.19 este
	 * gravador comparava DUAS vias, observado contra desejado, e gravava sempre
	 * que diferissem. Toda edição de option feita pelo agente pelo canal — um
	 * número de WhatsApp, um COOP, um ID de medição — era revertida na
	 * reexecução do implantador, sem nada no relatório dizendo que uma reversão
	 * tinha acontecido.
	 *
	 * A regra, nas palavras da premissa: o que o agente mudou VENCE, salvo
	 * quando a configuração mudou aquela mesma coisa depois — e aí o relatório
	 * NOMEIA a sobreposição, com os dois valores. Cinco ramos, e nenhum deles é
	 * silencioso:
	 *
	 * 1. `observado === desejado` — nada a fazer; só a base é atualizada.
	 * 2. `base === null` — PRIMEIRA execução desta estrutura, e ela deixou de
	 *    ser um ramo só na 2.2.0. O DEFEITO MEDIDO: como o implantador roda
	 *    UMA vez por site, base nula é o estado de toda execução real, e este
	 *    ramo aplicava o desejado por cima do observado sempre. Num site em
	 *    que o `Base Site Core Fator3` foi instalado e configurado ANTES, isso
	 *    apagava o que um humano tinha gravado na tela do plugin — o ID do
	 *    GA4, o Pixel, o par do Google Ads —, porque o slot correspondente
	 *    nasce vazio em `config/projeto.json`. O relatório nomeava a option na
	 *    lista das que nasceram, em linha OK, e ninguém lia aquilo como perda.
	 *    O dado que faltava já existia nos dois lados: `f3base_proveniencia`,
	 *    que o plugin escreve com `edicao-manual` quando a tela grava e que
	 *    este gravador escreve com `implantador` a cada escrita sua. Faltava
	 *    LER antes de decidir.
	 * 3. `base === observado` — ninguém tocou desde a última aplicação:
	 *    atualização segura.
	 * 4. `base === desejado` e observado diferente — o agente tocou e a
	 *    configuração NÃO mudou: PRESERVA, e o relatório nomeia a option.
	 * 5. os três diferentes — o agente tocou E a configuração mudou aquela
	 *    mesma coisa depois: o desejado é aplicado e a SOBREPOSIÇÃO sai nomeada
	 *    com os dois valores. É o único ramo em que o pacote vence o agente, e
	 *    por isso é o único que precisa ser visível.
	 *
	 * @param string|null $base         Impressão do último valor aplicado, ou null quando não há base.
	 * @param string      $observado    Impressão do valor observado na instalação.
	 * @param string      $desejado     Impressão do valor desejado pela configuração.
	 * @param string      $proveniencia Origem registrada da option observada; vazia quando a option não existe no banco.
	 * @return array{acao:string,base:string,motivo:string}
	 */
	public static function merge_option( ?string $base, string $observado, string $desejado, string $proveniencia = '' ): array {
		if ( $observado === $desejado ) {
			return array(
				'acao'   => self::MERGE_NADA,
				'base'   => self::BASE_DESEJADO,
				'motivo' => __( 'o valor observado já é o desejado: nada a gravar, e a base passa a registrá-lo.', 'f3base' ),
			);
		}

		if ( null === $base ) {
			return self::merge_sem_base( $proveniencia );
		}

		if ( $base === $observado ) {
			return array(
				'acao'   => self::MERGE_GRAVAR,
				'base'   => self::BASE_DESEJADO,
				'motivo' => __( 'o valor observado é igual ao último que este pacote aplicou e a configuração mudou: atualização segura, ninguém editou esta option pelo canal.', 'f3base' ),
			);
		}

		if ( $base === $desejado ) {
			return array(
				'acao'   => self::MERGE_PRESERVAR,
				'base'   => self::BASE_INALTERADA,
				'motivo' => __( 'PRESERVADA: o valor observado difere do último que este pacote aplicou — alguém editou esta option pelo canal — e a configuração NÃO mudou desde então. A edição vence a reexecução, e nada foi gravado.', 'f3base' ),
			);
		}

		return array(
			'acao'   => self::MERGE_SOBREPOR,
			'base'   => self::BASE_DESEJADO,
			'motivo' => __( 'SOBREPOSIÇÃO: esta option foi editada pelo canal E a configuração mudou a mesma coisa depois. O valor da configuração foi aplicado por cima da edição, e é por isso que os dois valores saem nomeados aqui — este é o único caminho pelo qual o pacote vence quem opera o site.', 'f3base' ),
		);
	}

	/**
	 * O que o MODO SOMENTE-RELATÓRIO diz sobre uma option. FUNÇÃO PURA.
	 *
	 * O DEFEITO MEDIDO, e ele é de categoria, não de código. Até a 1.1.1 o modo
	 * somente-relatório atravessava o gravador em simulação e imprimia
	 * "gravaria esta option (valor observado difere do desejado)": ele comparava
	 * o observado com o DESEJADO, isto é, com `config/site.json`. Depois que o
	 * agente assume o site, esse arquivo é CERTIDÃO DE NASCIMENTO e não estado
	 * corrente — ele registra o que o pacote aplicou no dia da entrega e nunca
	 * mais é reescrito, porque quem opera não edita o zip. Cada edição legítima
	 * do agente virava, então, uma "divergência" permanente: um relatório que
	 * acusa para sempre exatamente o trabalho que a premissa desta operação diz
	 * que vai acontecer.
	 *
	 * A comparação passa a ser com a BASE — o último valor que ESTE pacote
	 * aplicou, que a 1.1.0 registra por option —, e a linha muda de nome junto
	 * com a pergunta: ela é REGISTRO DO QUE MUDOU DESDE A ÚLTIMA APLICAÇÃO,
	 * nomeando o quê e para quê. Mudança do agente não é defeito, e chamá-la de
	 * divergência ensina o leitor a ignorar o relatório inteiro.
	 *
	 * A SEGUNDA LINHA CONTINUA EXISTINDO, e é a metade que impede esta decisão
	 * de virar cegueira: quem for REEXECUTAR o implantador precisa saber o que a
	 * configuração pediria, porque é ela que a reexecução aplica. Ela sai
	 * ROTULADA como o que é — "difere da configuração original" — e nunca como
	 * achado.
	 *
	 * Quatro estados, e os quatro são ditos:
	 *
	 * 1. **Sem base**: o pacote nunca aplicou esta option aqui, e não existe
	 *    "desde a última aplicação" a medir. Dizer "nada mudou" seria afirmar o
	 *    resultado de uma comparação que não pôde acontecer.
	 * 2. **Mudou desde a aplicação**: com os dois valores.
	 * 3. **Inalterada desde a aplicação**: dito em voz alta, porque silêncio
	 *    aqui é indistinguível de option não medida.
	 * 4. **Segunda linha**: difere ou não difere da configuração original.
	 *
	 * @param string|null $base              Impressão do último valor aplicado, ou null.
	 * @param string      $observado         Impressão do valor observado.
	 * @param string      $desejado          Impressão do valor desejado pela configuração.
	 * @param string      $amostra_base      Amostra legível do valor da base.
	 * @param string      $amostra_observado Amostra legível do valor observado.
	 * @param string      $amostra_desejado  Amostra legível do valor desejado.
	 * @return array{mudou:bool,difere:bool,sem_base:bool,registro:string,segunda_linha:string,texto:string}
	 */
	public static function linha_de_relatorio(
		?string $base,
		string $observado,
		string $desejado,
		string $amostra_base,
		string $amostra_observado,
		string $amostra_desejado
	): array {
		$sem_base = null === $base;
		$mudou    = ! $sem_base && $base !== $observado;
		$difere   = $observado !== $desejado;

		if ( $sem_base ) {
			$registro = __( 'SEM BASE: este pacote nunca aplicou esta option nesta instalação, e por isso não existe "desde a última aplicação" a medir. O valor observado é o que está no site, e a primeira aplicação é que fará a base nascer.', 'f3base' );
		} elseif ( $mudou ) {
			$registro = sprintf(
				/* translators: 1: valor aplicado pela última vez, 2: valor observado agora. */
				__( 'MUDOU DESDE A APLICAÇÃO: o pacote aplicou %1$s e o site tem %2$s agora. Isto é registro, não divergência — quem opera este site é o agente, e mudar é o que ele faz.', 'f3base' ),
				$amostra_base,
				$amostra_observado
			);
		} else {
			$registro = sprintf(
				/* translators: %s: valor observado, igual ao último aplicado. */
				__( 'INALTERADA DESDE A APLICAÇÃO: o site tem exatamente o valor que o pacote aplicou por último (%s).', 'f3base' ),
				$amostra_observado
			);
		}

		$segunda_linha = $difere
			? sprintf(
				/* translators: %s: valor que a configuração declara. */
				__( 'difere da configuração original: ela declara %s, e é esse valor que uma reexecução do implantador levaria em conta. Esta linha existe para quem for reexecutar; ela NÃO é achado.', 'f3base' ),
				$amostra_desejado
			)
			: __( 'igual à configuração original.', 'f3base' );

		return array(
			'mudou'         => $mudou,
			'difere'        => $difere,
			'sem_base'      => $sem_base,
			'registro'      => $registro,
			'segunda_linha' => $segunda_linha,
			'texto'         => $registro . ' ' . $segunda_linha,
		);
	}

	/**
	 * Impressão da base registrada para uma option, ou `null` quando não há.
	 *
	 * A base mora na MESMA option-espelho da base de conteúdo, em seção
	 * reservada. Duplicar a estrutura seria criar um segundo lugar para a mesma
	 * pergunta.
	 *
	 * @param string $nome Nome da option.
	 * @return string|null
	 */
	public static function base_de_option( string $nome ): ?string {
		$registro = F3Base_Imp_Conteudo::ler_base_de_option( $nome );

		return ( is_array( $registro ) && isset( $registro['hash'] ) ) ? (string) $registro['hash'] : null;
	}

	/**
	 * O VALOR da base registrada para uma option — o que o relatório nomeia.
	 *
	 * A impressão diz SE mudou; o valor diz DE QUE para quê. Um relatório que
	 * respondesse só a primeira pergunta obrigaria quem o lê a ir ao banco
	 * descobrir a segunda, e é justamente o banco que ele existe para poupar.
	 *
	 * @param string $nome Nome da option.
	 * @return mixed Valor aplicado por último, ou `null` quando não há base.
	 */
	public static function valor_da_base_de_option( string $nome ) {
		$registro = F3Base_Imp_Conteudo::ler_base_de_option( $nome );

		return ( is_array( $registro ) && array_key_exists( 'valor', $registro ) ) ? $registro['valor'] : null;
	}

	/**
	 * Registra a base de uma option — o valor que passou a valer agora.
	 *
	 * @param string              $nome     Nome da option.
	 * @param mixed               $aplicado Valor que ficou valendo.
	 * @param array<string,mixed> $contexto Contexto da escrita.
	 * @return void
	 */
	private static function registrar_base_de_option( string $nome, $aplicado, array $contexto ): void {
		$extra = ( isset( $contexto['base_extra'] ) && is_array( $contexto['base_extra'] ) ) ? $contexto['base_extra'] : array();

		F3Base_Imp_Conteudo::gravar_base_de_option(
			$nome,
			array(
				'hash'  => self::impressao( $aplicado ),
				'valor' => $aplicado,
				'em'    => time(),
			) + $extra
		);
	}

	/**
	 * Amostra legível de um valor, para o relatório NOMEAR os dois lados.
	 *
	 * Sobreposição contada e não mostrada não serve a ninguém: quem lê precisa
	 * ver o que estava lá e o que passou a estar. O corte é declarado — o
	 * relatório é texto, e valor de option não tem teto de tamanho.
	 *
	 * @param mixed $valor Valor.
	 * @return string
	 */
	public static function amostra_de_valor( $valor ): string {
		$texto = is_string( $valor ) ? $valor : (string) wp_json_encode( $valor );

		if ( '' === $texto ) {
			return '(vazio)';
		}

		return strlen( $texto ) <= 160 ? $texto : substr( $texto, 0, 160 ) . '…';
	}

	/**
	 * Grava uma option inteira.
	 *
	 * @param string              $nome     Nome da option.
	 * @param mixed               $valor    Valor pretendido.
	 * @param array<string,mixed> $contexto Contexto: `plugin` (slug dono), `autoload`, `origem`.
	 * @return array<string,mixed> Resultado com estado fechado.
	 */
	public static function gravar( string $nome, $valor, array $contexto = array() ): array {
		$nome = trim( $nome );

		if ( '' === $nome ) {
			return self::resultado( self::FALHA, '', null, $valor, __( 'nome de option vazio: escrita recusada.', 'f3base' ), $contexto );
		}

		$anterior = get_option( $nome, self::AUSENTE );
		$existia  = self::AUSENTE !== $anterior;
		$mudaria  = ! $existia || ! self::equivalente( $anterior, $valor );
		$observado = $existia ? $anterior : null;

		/*
		 * A REGRA DE TRÊS VIAS É OPT-IN POR ESCRITA, e isso é deliberado. Ela
		 * vale para as options que o agente OPERA depois da instalação — as do
		 * bloco do site-core —, e não para a infraestrutura desta execução
		 * (checkpoint, journal, procedência, a própria base), que é estado do
		 * implantador e não configuração de ninguém. Aplicá-la à base criaria
		 * recursão: a base é gravada por este mesmo ponto único.
		 */
		$usa_base     = ! empty( $contexto['base'] );
		$proveniencia = $usa_base ? self::proveniencia_observada( $nome, $existia ) : '';
		$decisao      = $usa_base
			? self::merge_option(
				self::base_de_option( $nome ),
				self::impressao( $observado ),
				self::impressao( $valor ),
				$proveniencia
			)
			: array(
				'acao'   => '',
				'motivo' => '',
			);

		/*
		 * O MODO SOMENTE-RELATÓRIO RESPONDE OUTRA PERGUNTA, e por isso ele tem
		 * ramo próprio. A simulação diz o que a aplicação FARIA; o relatório da
		 * cadência diz o que MUDOU desde a última aplicação. Comparar com a
		 * configuração num site que o agente opera há semanas transforma toda
		 * edição legítima dele em "divergência" permanente — a configuração é
		 * certidão de nascimento, não estado corrente.
		 */
		if ( self::$relatorio && $usa_base ) {
			$linha = self::linha_de_relatorio(
				self::base_de_option( $nome ),
				self::impressao( $observado ),
				self::impressao( $valor ),
				self::amostra_de_valor( self::valor_da_base_de_option( $nome ) ),
				self::amostra_de_valor( $observado ),
				self::amostra_de_valor( $valor )
			);

			return self::resultado(
				self::NA,
				$nome,
				$observado,
				$valor,
				$linha['texto'],
				$contexto + array(
					'mudaria'  => $mudaria,
					'merge'    => (string) $decisao['acao'],
					'relatorio' => $linha,
				)
			);
		}

		if ( self::$simulacao ) {
			return self::resultado(
				self::NA,
				$nome,
				$observado,
				$valor,
				( $mudaria
					? __( 'modo simulação: gravaria esta option (valor observado difere do desejado).', 'f3base' )
					: __( 'modo simulação: nada a gravar (valor observado já é o desejado).', 'f3base' ) )
					. ( $usa_base ? ' ' . $decisao['motivo'] : '' ),
				$contexto + array(
					'mudaria' => $mudaria,
					'merge'   => (string) $decisao['acao'],
				)
			);
		}

		/*
		 * PRESERVAR É NÃO ESCREVER, e a base passa a ser o valor de quem
		 * editou: sem isso a mesma divergência seria redescoberta em toda
		 * execução seguinte, e o relatório repetiria para sempre um achado que
		 * já foi decidido.
		 */
		if ( self::MERGE_PRESERVAR === $decisao['acao'] ) {
			/*
			 * A BASE NÃO SE MOVE AQUI, e é isso que faz a preservação durar.
			 * Ela é o último valor que ESTE pacote aplicou; nesta execução ele
			 * não aplicou nada.
			 *
			 * A ORIGEM TAMBÉM NÃO SE MOVE, e isso é da 2.2.0. Registrar a
			 * preservação com a origem padrão deste gravador carimbava
			 * `implantador` sobre um valor que o implantador acabou de decidir
			 * NÃO escrever: a tela do plugin passava a atribuir a ele o campo
			 * que um humano digitou, e a execução seguinte perdia o fato que
			 * fez esta preservar. Origem conhecida é reescrita como ela mesma —
			 * só a impressão do valor é atualizada; origem não registrada não
			 * ganha nome nenhum.
			 */
			if ( in_array( $proveniencia, array( self::ORIGEM_IMPLANTADOR, self::ORIGEM_MANUAL, self::ORIGEM_PADRAO ), true ) ) {
				self::registrar_proveniencia( $nome, $observado, $contexto + array( 'origem' => $proveniencia ) );
			}

			return self::resultado(
				self::OK,
				$nome,
				$observado,
				$valor,
				$decisao['motivo'] . ' ' . sprintf(
					/* translators: 1: valor observado, preservado; 2: valor que a configuração pediria. */
					__( 'Valor preservado: %1$s. Valor da configuração, NÃO aplicado: %2$s.', 'f3base' ),
					self::amostra_de_valor( $observado ),
					self::amostra_de_valor( $valor )
				),
				$contexto + array(
					'gravou' => false,
					'merge'  => self::MERGE_PRESERVAR,
				)
			);
		}

		if ( ! $mudaria ) {
			self::registrar_proveniencia( $nome, $valor, $contexto );

			if ( $usa_base && self::BASE_DESEJADO === ( $decisao['base'] ?? '' ) ) {
				self::registrar_base_de_option( $nome, $valor, $contexto );
			}

			return self::resultado(
				self::OK,
				$nome,
				$anterior,
				$valor,
				__( 'valor observado já era o desejado: nenhuma gravação executada.', 'f3base' )
					. ( $usa_base ? ' ' . $decisao['motivo'] : '' ),
				$contexto + array(
					'gravou' => false,
					'merge'  => (string) $decisao['acao'],
				)
			);
		}

		$autoload = array_key_exists( 'autoload', $contexto ) ? (bool) $contexto['autoload'] : true;

		$entrada = F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_OPTION,
			$nome,
			$existia ? $anterior : null,
			$valor,
			$existia
				? array(
					'acao'  => 'option.restaurar',
					'nome'  => $nome,
					'valor' => $anterior,
				)
				: array(
					'acao' => 'option.remover',
					'nome' => $nome,
				),
			array( 'plugin' => isset( $contexto['plugin'] ) ? (string) $contexto['plugin'] : '' )
		);

		$caminhos = array( 'update_option', 'delete_add', 'linha_direta' );
		$usado    = '';
		$lido     = null;

		foreach ( $caminhos as $caminho ) {
			self::aplicar( $caminho, $nome, $valor, $autoload );

			$lido  = get_option( $nome, self::AUSENTE );
			$usado = $caminho;

			if ( self::AUSENTE !== $lido && self::equivalente( $lido, $valor ) ) {
				self::registrar_proveniencia( $nome, $valor, $contexto );

				if ( $usa_base && self::BASE_DESEJADO === ( $decisao['base'] ?? '' ) ) {
					self::registrar_base_de_option( $nome, $valor, $contexto );
				}

				$nota_do_merge = '';

				if ( self::MERGE_SOBREPOR === $decisao['acao'] ) {
					$nota_do_merge = ' ' . $decisao['motivo'] . ' ' . sprintf(
						/* translators: 1: valor que estava na instalação, sobreposto; 2: valor aplicado pela configuração. */
						__( 'Valor SOBREPOSTO, que estava na instalação: %1$s. Valor aplicado pela configuração: %2$s.', 'f3base' ),
						self::amostra_de_valor( $observado ),
						self::amostra_de_valor( $valor )
					);
				} elseif ( $usa_base ) {
					$nota_do_merge = ' ' . $decisao['motivo'];
				}

				return self::resultado(
					self::OK,
					$nome,
					$existia ? $anterior : null,
					$valor,
					( 'update_option' === $caminho
						? __( 'gravada e conferida na leitura de volta.', 'f3base' )
						: sprintf(
							/* translators: %s: nome do caminho alternativo usado. */
							__( 'gravada pelo caminho alternativo %s e conferida na leitura de volta.', 'f3base' ),
							$caminho
						) ) . $nota_do_merge,
					$contexto + array(
						'gravou'  => true,
						'caminho' => $caminho,
						'journal' => $entrada,
						'merge'   => (string) $decisao['acao'],
					)
				);
			}
		}

		$reversao = F3Base_Imp_Journal::reverter_entrada( $entrada );

		return self::resultado(
			self::BLOCKED,
			$nome,
			$existia ? $anterior : null,
			$valor,
			sprintf(
				/* translators: 1: nome da option, 2: versão do plugin dono, 3: último caminho tentado, 4: resultado da reversão. */
				__( 'leitura de volta divergiu na chave %1$s (dono na versão %2$s) após o caminho %3$s; escrita revertida pelo journal (%4$s).', 'f3base' ),
				$nome,
				self::versao_dona( $contexto ),
				$usado,
				$reversao['ok'] ? __( 'reversão conferida', 'f3base' ) : $reversao['motivo']
			),
			$contexto + array(
				'lido'    => $lido,
				'journal' => $entrada,
			)
		);
	}

	/**
	 * Grava um subconjunto de chaves dentro de uma option-array de terceiro.
	 *
	 * O plugin de SEO valida na gravação e descarta em silêncio o que não
	 * reconhece: por isso cada chave pedida é conferida INDIVIDUALMENTE na
	 * leitura de volta, e o que sumiu sai nomeado — nunca contado.
	 *
	 * @param string               $nome     Nome da option.
	 * @param array<string,mixed>  $chaves   Chaves a gravar.
	 * @param array<string,mixed>  $contexto Contexto.
	 * @return array<string,mixed> Resultado, com `descartadas` nomeadas.
	 */
	public static function gravar_chaves( string $nome, array $chaves, array $contexto = array() ): array {
		$atual = get_option( $nome, self::AUSENTE );
		$base  = ( self::AUSENTE !== $atual && is_array( $atual ) ) ? $atual : array();

		$desejado = $base;

		foreach ( $chaves as $chave => $valor ) {
			$desejado[ (string) $chave ] = $valor;
		}

		$resultado = self::gravar( $nome, $desejado, $contexto );

		if ( self::$simulacao ) {
			$resultado['descartadas']  = array();
			$resultado['normalizadas'] = array();

			return $resultado;
		}

		$lido         = get_option( $nome, array() );
		$lido         = is_array( $lido ) ? $lido : array();
		$descartadas  = array();
		$normalizadas = array();

		foreach ( $chaves as $chave => $valor ) {
			$chave = (string) $chave;

			if ( ! array_key_exists( $chave, $lido ) ) {
				$descartadas[] = $chave;
				continue;
			}

			if ( self::equivalente( $lido[ $chave ], $valor ) ) {
				continue;
			}

			if ( self::mesma_representacao( $lido[ $chave ], $valor ) ) {
				/* Tipo normalizado pelo plugin: o VALOR chegou. Não é descarte. */
				$normalizadas[] = $chave;
				continue;
			}

			$descartadas[] = $chave;
		}

		$resultado['descartadas']  = $descartadas;
		$resultado['normalizadas'] = $normalizadas;

		if ( array() !== $normalizadas ) {
			$resultado['motivo'] .= sprintf(
				/* translators: %s: chaves normalizadas. */
				__( ' Chaves cujo valor chegou com o tipo normalizado pelo plugin (não é descarte): %s.', 'f3base' ),
				implode( ', ', $normalizadas )
			);
		}

		if ( array() !== $descartadas && self::OK === $resultado['estado'] ) {
			$reversao = isset( $resultado['journal'] )
				? F3Base_Imp_Journal::reverter_entrada( (string) $resultado['journal'] )
				: array(
					'ok'     => false,
					'motivo' => __( 'sem entrada de journal para reverter', 'f3base' ),
				);

			$resultado['estado'] = self::BLOCKED;
			$resultado['motivo'] = sprintf(
				/* translators: 1: nome da option, 2: chaves descartadas, 3: versão do plugin dono, 4: resultado da reversão. */
				__( 'a option %1$s aceitou a gravação mas descartou em silêncio: %2$s (dono na versão %3$s); escrita revertida pelo journal (%4$s).', 'f3base' ),
				$nome,
				implode( ', ', $descartadas ),
				self::versao_dona( $contexto ),
				$reversao['ok'] ? __( 'reversão conferida', 'f3base' ) : $reversao['motivo']
			);
		}

		return $resultado;
	}

	/**
	 * Remove uma option gerenciada.
	 *
	 * @param string              $nome     Nome da option.
	 * @param array<string,mixed> $contexto Contexto.
	 * @return array<string,mixed>
	 */
	public static function remover( string $nome, array $contexto = array() ): array {
		$anterior = get_option( $nome, self::AUSENTE );

		if ( self::AUSENTE === $anterior ) {
			return self::resultado( self::OK, $nome, null, null, __( 'option já ausente: nada a remover.', 'f3base' ), $contexto );
		}

		if ( self::$simulacao ) {
			return self::resultado( self::NA, $nome, $anterior, null, __( 'modo simulação: removeria esta option.', 'f3base' ), $contexto );
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_OPTION,
			$nome,
			$anterior,
			null,
			array(
				'acao'  => 'option.restaurar',
				'nome'  => $nome,
				'valor' => $anterior,
			),
			array( 'plugin' => isset( $contexto['plugin'] ) ? (string) $contexto['plugin'] : '' )
		);

		self::remover_infra( $nome );

		$sumiu = self::AUSENTE === get_option( $nome, self::AUSENTE );

		return self::resultado(
			$sumiu ? self::OK : self::FALHA,
			$nome,
			$anterior,
			null,
			$sumiu ? __( 'removida e conferida na leitura de volta.', 'f3base' ) : __( 'a option continua no banco após a remoção.', 'f3base' ),
			$contexto
		);
	}

	/**
	 * Grava uma meta de post ou de termo, com journal e leitura de volta.
	 *
	 * @param string              $tipo     `post` ou `term`.
	 * @param int                 $objeto   ID do objeto.
	 * @param string              $chave    Nome da meta.
	 * @param mixed               $valor    Valor pretendido.
	 * @param array<string,mixed> $contexto Contexto.
	 * @return array<string,mixed>
	 */
	public static function gravar_meta( string $tipo, int $objeto, string $chave, $valor, array $contexto = array() ): array {
		$tipo  = 'term' === $tipo ? 'term' : 'post';
		$alvo  = sprintf( '%s#%d:%s', $tipo, $objeto, $chave );
		$havia = 'term' === $tipo ? metadata_exists( 'term', $objeto, $chave ) : metadata_exists( 'post', $objeto, $chave );
		$antes = $havia
			? ( 'term' === $tipo ? get_term_meta( $objeto, $chave, true ) : get_post_meta( $objeto, $chave, true ) )
			: null;

		if ( $objeto <= 0 || '' === $chave ) {
			return self::resultado( self::FALHA, $alvo, $antes, $valor, __( 'objeto ou chave de meta ausente.', 'f3base' ), $contexto );
		}

		if ( $havia && self::equivalente( $antes, $valor ) ) {
			return self::resultado( self::OK, $alvo, $antes, $valor, __( 'meta já tinha o valor desejado: nenhuma gravação executada.', 'f3base' ), $contexto + array( 'gravou' => false ) );
		}

		if ( self::$simulacao ) {
			return self::resultado( self::NA, $alvo, $antes, $valor, __( 'modo simulação: gravaria esta meta.', 'f3base' ), $contexto );
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_META,
			$alvo,
			$antes,
			$valor,
			$havia
				? array(
					'acao'        => 'meta.restaurar',
					'objeto_tipo' => $tipo,
					'objeto_id'   => $objeto,
					'chave'       => $chave,
					'valor'       => $antes,
				)
				: array(
					'acao'        => 'meta.remover',
					'objeto_tipo' => $tipo,
					'objeto_id'   => $objeto,
					'chave'       => $chave,
				),
			array( 'plugin' => isset( $contexto['plugin'] ) ? (string) $contexto['plugin'] : '' )
		);

		if ( 'term' === $tipo ) {
			update_term_meta( $objeto, $chave, $valor );
			$lido = get_term_meta( $objeto, $chave, true );
		} else {
			update_post_meta( $objeto, $chave, $valor );
			$lido = get_post_meta( $objeto, $chave, true );
		}

		$conferiu = self::equivalente( $lido, $valor );

		return self::resultado(
			$conferiu ? self::OK : self::FALHA,
			$alvo,
			$antes,
			$valor,
			$conferiu ? __( 'meta gravada e conferida na leitura de volta.', 'f3base' ) : __( 'leitura de volta da meta divergiu do valor gravado.', 'f3base' ),
			$contexto + array( 'lido' => $lido )
		);
	}

	/**
	 * Remove uma meta, com journal.
	 *
	 * @param string              $tipo     `post` ou `term`.
	 * @param int                 $objeto   ID do objeto.
	 * @param string              $chave    Nome da meta.
	 * @param array<string,mixed> $contexto Contexto.
	 * @return array<string,mixed>
	 */
	public static function remover_meta( string $tipo, int $objeto, string $chave, array $contexto = array() ): array {
		$tipo  = 'term' === $tipo ? 'term' : 'post';
		$alvo  = sprintf( '%s#%d:%s', $tipo, $objeto, $chave );
		$havia = metadata_exists( $tipo, $objeto, $chave );

		if ( ! $havia ) {
			return self::resultado( self::OK, $alvo, null, null, __( 'meta já ausente: nada a remover.', 'f3base' ), $contexto );
		}

		$antes = 'term' === $tipo ? get_term_meta( $objeto, $chave, true ) : get_post_meta( $objeto, $chave, true );

		if ( self::$simulacao ) {
			return self::resultado( self::NA, $alvo, $antes, null, __( 'modo simulação: removeria esta meta.', 'f3base' ), $contexto );
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_META,
			$alvo,
			$antes,
			null,
			array(
				'acao'        => 'meta.restaurar',
				'objeto_tipo' => $tipo,
				'objeto_id'   => $objeto,
				'chave'       => $chave,
				'valor'       => $antes,
			)
		);

		if ( 'term' === $tipo ) {
			delete_term_meta( $objeto, $chave );
		} else {
			delete_post_meta( $objeto, $chave );
		}

		$sumiu = ! metadata_exists( $tipo, $objeto, $chave );

		return self::resultado(
			$sumiu ? self::OK : self::FALHA,
			$alvo,
			$antes,
			null,
			$sumiu ? __( 'meta removida e conferida na leitura de volta.', 'f3base' ) : __( 'a meta continua no banco após a remoção.', 'f3base' ),
			$contexto
		);
	}

	/**
	 * Grava um arquivo físico, com preimagem copiada para o journal.
	 *
	 * @param string              $caminho  Caminho absoluto do arquivo.
	 * @param string              $conteudo Conteúdo pretendido.
	 * @param array<string,mixed> $contexto Contexto.
	 * @return array<string,mixed>
	 */
	public static function gravar_arquivo( string $caminho, string $conteudo, array $contexto = array() ): array {
		$existia = file_exists( $caminho );
		$antes   = $existia ? file_get_contents( $caminho ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- preimagem local para o journal.
		$antes   = is_string( $antes ) ? $antes : null;

		if ( $existia && null !== $antes && $antes === $conteudo ) {
			return self::resultado( self::OK, $caminho, self::marcador( $antes ), self::marcador( $conteudo ), __( 'arquivo já tinha o conteúdo desejado: nenhuma gravação executada.', 'f3base' ), $contexto + array( 'gravou' => false ) );
		}

		if ( self::$simulacao ) {
			return self::resultado( self::NA, $caminho, self::marcador( (string) $antes ), self::marcador( $conteudo ), __( 'modo simulação: gravaria este arquivo.', 'f3base' ), $contexto );
		}

		$backup = '';

		if ( $existia && null !== $antes ) {
			$backup = self::guardar_preimagem( $caminho, $antes );
		}

		$reversivel = ! $existia || '' !== $backup;

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_ARQUIVO,
			$caminho,
			self::marcador( (string) $antes ),
			self::marcador( $conteudo ),
			$existia
				? array(
					'acao'    => 'arquivo.restaurar',
					'caminho' => $caminho,
					'backup'  => $backup,
				)
				: array(
					'acao'    => 'arquivo.remover',
					'caminho' => $caminho,
				),
			array(
				'reversivel' => $reversivel,
				'motivo'     => $reversivel ? '' : __( 'não foi possível guardar a preimagem do arquivo: a gravação fica fora da promessa de rollback.', 'f3base' ),
			)
		);

		$gravou = self::escrever_arquivo_infra( $caminho, $conteudo );

		if ( ! $gravou ) {
			return self::resultado( self::FALHA, $caminho, self::marcador( (string) $antes ), self::marcador( $conteudo ), __( 'falha de escrita no caminho tentado.', 'f3base' ), $contexto );
		}

		$lido     = file_get_contents( $caminho ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- leitura de volta local.
		$conferiu = is_string( $lido ) && $lido === $conteudo;

		return self::resultado(
			$conferiu ? self::OK : self::FALHA,
			$caminho,
			self::marcador( (string) $antes ),
			self::marcador( $conteudo ),
			$conferiu ? __( 'arquivo gravado e conferido na leitura de volta do disco.', 'f3base' ) : __( 'o conteúdo lido do disco divergiu do conteúdo gravado.', 'f3base' ),
			$contexto
		);
	}

	/**
	 * Troca atômica de valor de option — usada pelo lock com fencing token.
	 *
	 * A expiração sozinha não impede duas execuções quando uma etapa longa passa
	 * do TTL: a renovação precisa ser condicional ao valor observado, e é isto.
	 *
	 * @param string $nome     Nome da option.
	 * @param mixed  $esperado Valor que precisa estar lá.
	 * @param mixed  $novo     Valor novo.
	 * @return bool Verdadeiro quando a troca aconteceu.
	 */
	public static function trocar_atomico( string $nome, $esperado, $novo ): bool {
		global $wpdb;

		$serializado_esperado = maybe_serialize( $esperado );
		$serializado_novo     = maybe_serialize( $novo );

		if ( $serializado_esperado === $serializado_novo ) {
			return true;
		}

		$linhas = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- troca condicional atômica; nenhuma API do core oferece compare-and-set em option.
			$wpdb->options,
			array( 'option_value' => $serializado_novo ),
			array(
				'option_name'  => $nome,
				'option_value' => $serializado_esperado,
			),
			array( '%s' ),
			array( '%s', '%s' )
		);

		wp_cache_delete( $nome, 'options' );
		wp_cache_delete( 'alloptions', 'options' );

		return is_int( $linhas ) && $linhas > 0;
	}

	/**
	 * Criação atômica de option — usada pela aquisição do lock.
	 *
	 * @param string $nome  Nome da option.
	 * @param mixed  $valor Valor.
	 * @return bool Verdadeiro quando ESTA chamada criou a linha.
	 */
	public static function criar_atomico( string $nome, $valor ): bool {
		return add_option( $nome, $valor, '', false );
	}

	/**
	 * Escrita de infraestrutura: journal, lock, log e checkpoint.
	 *
	 * Não passa pelo journal (o journal não se journaliza) e não registra
	 * procedência (não é estado desejado do site). Continua sendo o ÚNICO
	 * `update_option` do implantador.
	 *
	 * @param string $nome  Nome da option.
	 * @param mixed  $valor Valor.
	 * @return void
	 */
	public static function persistir_infra( string $nome, $valor ): void {
		update_option( $nome, $valor, false );
	}

	/**
	 * Remoção de infraestrutura. Único `delete_option` do implantador.
	 *
	 * @param string $nome Nome da option.
	 * @return void
	 */
	public static function remover_infra( string $nome ): void {
		delete_option( $nome );
	}

	/**
	 * Escrita física de arquivo pelo método de filesystem do WordPress.
	 *
	 * @param string $caminho  Caminho absoluto.
	 * @param string $conteudo Conteúdo.
	 * @return bool
	 */
	public static function escrever_arquivo_infra( string $caminho, string $conteudo ): bool {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			WP_Filesystem();
		}

		$diretorio = dirname( $caminho );

		if ( ! is_dir( $diretorio ) ) {
			wp_mkdir_p( $diretorio );
		}

		if ( $wp_filesystem instanceof WP_Filesystem_Base ) {
			return (bool) $wp_filesystem->put_contents( $caminho, $conteudo, FS_CHMOD_FILE );
		}

		return false;
	}

	/**
	 * Diretório de trabalho do implantador dentro de uploads.
	 *
	 * @param string $sub Subdiretório opcional.
	 * @return string Caminho absoluto com barra final, ou vazio quando indisponível.
	 */
	public static function diretorio_trabalho( string $sub = '' ): string {
		$uploads = wp_upload_dir();

		if ( ! is_array( $uploads ) || ! empty( $uploads['error'] ) || empty( $uploads['basedir'] ) ) {
			return '';
		}

		$base = trailingslashit( (string) $uploads['basedir'] ) . 'f3base-implantador/';

		if ( '' !== $sub ) {
			$base .= trailingslashit( sanitize_key( $sub ) );
		}

		if ( ! is_dir( $base ) ) {
			wp_mkdir_p( $base );
		}

		return $base;
	}

	/* ------------------------------------------------------------------ *
	 * Internos
	 * ------------------------------------------------------------------ */

	/**
	 * Aplica um dos caminhos de escrita declarados.
	 *
	 * @param string $caminho  Nome do caminho.
	 * @param string $nome     Option.
	 * @param mixed  $valor    Valor.
	 * @param bool   $autoload Autoload.
	 * @return void
	 */
	private static function aplicar( string $caminho, string $nome, $valor, bool $autoload ): void {
		global $wpdb;

		switch ( $caminho ) {
			case 'update_option':
				update_option( $nome, $valor, $autoload );
				break;

			case 'delete_add':
				/*
				 * Segundo caminho: apagar e recriar. Vence o curto-circuito de
				 * "valor igual" do core e reescreve o autoload, que é onde uma
				 * gravação anterior malfeita costuma prender o valor velho.
				 */
				delete_option( $nome );
				add_option( $nome, $valor, '', $autoload );
				break;

			case 'linha_direta':
				/*
				 * Terceiro caminho: a linha da tabela, sem filtro de plugin no
				 * meio. É o mais baixo nível que ainda é WordPress, e existe para
				 * distinguir "o plugin recusou" de "o filtro reescreveu".
				 */
				$serializado = maybe_serialize( $valor );
				$existe      = null !== $wpdb->get_var( $wpdb->prepare( "SELECT option_id FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", $nome ) ); // phpcs:ignore WordPress.DB -- caminho alternativo declarado do gravador único.

				if ( $existe ) {
					$wpdb->update( $wpdb->options, array( 'option_value' => $serializado ), array( 'option_name' => $nome ), array( '%s' ), array( '%s' ) ); // phpcs:ignore WordPress.DB -- idem.
				} else {
					$wpdb->insert( // phpcs:ignore WordPress.DB -- idem.
						$wpdb->options,
						array(
							'option_name'  => $nome,
							'option_value' => $serializado,
							'autoload'     => $autoload ? 'yes' : 'no',
						),
						array( '%s', '%s', '%s' )
					);
				}

				wp_cache_delete( $nome, 'options' );
				wp_cache_delete( 'alloptions', 'options' );
				break;
		}
	}

	/**
	 * Registra a procedência de uma escrita.
	 *
	 * Guarda origem, data e HASHES do valor anterior e do novo — nunca os valores
	 * crus: procedência é autoloaded e não pode virar depósito de segredo de
	 * terceiro. O relatório usa o hash para decidir entre "implantador",
	 * "edição manual" e "origem não registrada".
	 *
	 * @param string              $nome     Option.
	 * @param mixed               $valor    Valor gravado.
	 * @param array<string,mixed> $contexto Contexto.
	 * @return void
	 */
	private static function registrar_proveniencia( string $nome, $valor, array $contexto ): void {
		if ( self::OPTION_PROVENIENCIA === $nome ) {
			return;
		}

		$origem = isset( $contexto['origem'] ) ? (string) $contexto['origem'] : self::ORIGEM_IMPLANTADOR;

		if ( ! in_array( $origem, array( self::ORIGEM_IMPLANTADOR, self::ORIGEM_MANUAL, self::ORIGEM_PADRAO ), true ) ) {
			$origem = self::ORIGEM_IMPLANTADOR;
		}

		$registro = get_option( self::OPTION_PROVENIENCIA, array() );
		$registro = is_array( $registro ) ? $registro : array();

		$registro[ $nome ] = array(
			'origem'     => $origem,
			'em'         => time(),
			'valor_hash' => self::impressao( $valor ),
			'release'    => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
		);

		update_option( self::OPTION_PROVENIENCIA, $registro, true );
	}

	/**
	 * Impressão digital estável de um valor.
	 *
	 * @param mixed $valor Valor.
	 * @return string
	 */
	public static function impressao( $valor ): string {
		$normalizado = is_array( $valor ) ? self::ordenar( $valor ) : self::texto_de_option( $valor );

		return hash( 'sha256', (string) wp_json_encode( $normalizado ) );
	}

	/**
	 * Comparação de leitura de volta, na representação da option.
	 *
	 * Fato do WordPress que a comparação tem de conhecer: escalar gravado numa
	 * option volta do BANCO como STRING — `1` vira `'1'`, `true` vira `'1'`,
	 * `false` vira `''`. Comparar com `===` faria toda gravação de inteiro ou
	 * de booleano reportar divergência e terminar em BLOCKED com o site
	 * corretamente configurado: o instrumento reprovando o que ele mesmo
	 * gravou certo.
	 *
	 * A tolerância é ESTREITA e tem piso dos dois lados: `false` continua
	 * diferente de `0` (`''` contra `'0'`), array continua diferente de
	 * escalar, e valor diferente continua diferente. O que ela reconhece é
	 * exatamente o round-trip da camada de options, nada além.
	 *
	 * @param mixed $a Primeiro valor.
	 * @param mixed $b Segundo valor.
	 * @return bool
	 */
	public static function equivalente( $a, $b ): bool {
		if ( is_array( $a ) !== is_array( $b ) ) {
			return false;
		}

		if ( is_array( $a ) && is_array( $b ) ) {
			return wp_json_encode( self::ordenar( $a ) ) === wp_json_encode( self::ordenar( $b ) );
		}

		if ( $a === $b ) {
			return true;
		}

		return self::mesma_representacao( $a, $b );
	}

	/**
	 * Dois escalares têm a mesma representação depois do round-trip?
	 *
	 * Usada onde a diferença é de REPRESENTAÇÃO e não de valor — o que distingue
	 * "o plugin normalizou o tipo" de "o plugin descartou a chave". As duas
	 * viram linhas diferentes do relatório; tratar a primeira como a segunda
	 * reverteria configuração correta.
	 *
	 * @param mixed $a Primeiro valor.
	 * @param mixed $b Segundo valor.
	 * @return bool
	 */
	public static function mesma_representacao( $a, $b ): bool {
		if ( is_array( $a ) || is_array( $b ) ) {
			return false;
		}

		if ( ( is_scalar( $a ) || null === $a ) && ( is_scalar( $b ) || null === $b ) ) {
			return self::texto_de_option( $a ) === self::texto_de_option( $b );
		}

		return false;
	}

	/**
	 * Representação de um escalar depois do round-trip pela camada de options.
	 *
	 * @param mixed $valor Valor.
	 * @return string
	 */
	private static function texto_de_option( $valor ): string {
		if ( is_bool( $valor ) ) {
			return $valor ? '1' : '';
		}

		if ( null === $valor ) {
			return '';
		}

		return (string) $valor;
	}

	/**
	 * Ordena arrays recursivamente e normaliza escalares para comparação estável.
	 *
	 * A normalização é a mesma da leitura de volta: sem ela, a impressão gravada
	 * na procedência (feita com o valor em memória) nunca casaria com a do valor
	 * lido do banco numa requisição seguinte, e TODA option gerenciada apareceria
	 * no relatório como "edição manual" — afirmação sobre uma pessoa, feita por
	 * um defeito de comparação.
	 *
	 * @param mixed $valor Valor.
	 * @return mixed
	 */
	private static function ordenar( $valor ) {
		if ( ! is_array( $valor ) ) {
			/*
			 * DENTRO de um array a normalização NÃO se aplica: a option é
			 * serializada e o unserialize devolve os tipos originais. Aqui,
			 * `1` e `'1'` são valores diferentes, e é assim que a transformação
			 * silenciosa feita por um plugin de terceiro aparece.
			 */
			return $valor;
		}

		ksort( $valor );

		foreach ( $valor as $chave => $item ) {
			$valor[ $chave ] = self::ordenar( $item );
		}

		return $valor;
	}

	/**
	 * Versão instalada do plugin dono da chave, para nomear o BLOCKED.
	 *
	 * @param array<string,mixed> $contexto Contexto da escrita.
	 * @return string
	 */
	private static function versao_dona( array $contexto ): string {
		$slug = isset( $contexto['plugin'] ) ? (string) $contexto['plugin'] : '';

		if ( '' === $slug ) {
			return __( 'não declarado (option do próprio WordPress ou do pacote)', 'f3base' );
		}

		$versao = F3Base_Imp_Plugins::versao_instalada( $slug );

		return '' !== $versao ? $versao : __( 'não instalado', 'f3base' );
	}

	/**
	 * Guarda a preimagem de um arquivo para permitir a reversão.
	 *
	 * @param string $caminho  Caminho original.
	 * @param string $conteudo Conteúdo anterior.
	 * @return string Caminho da cópia, ou vazio quando não foi possível guardar.
	 */
	private static function guardar_preimagem( string $caminho, string $conteudo ): string {
		$destino = self::diretorio_trabalho( 'preimagem' );

		if ( '' === $destino ) {
			return '';
		}

		$arquivo = $destino . hash( 'sha256', $caminho ) . '-' . time() . '.bak';

		return self::escrever_arquivo_infra( $arquivo, $conteudo ) ? $arquivo : '';
	}

	/**
	 * Marcador estável de um conteúdo de arquivo.
	 *
	 * Preserva a estrutura — tamanho e hash — sem levar o conteúdo para o
	 * journal nem para o relatório.
	 *
	 * @param string $conteudo Conteúdo.
	 * @return array{bytes:int,sha256:string}
	 */
	private static function marcador( string $conteudo ): array {
		return array(
			'bytes'  => strlen( $conteudo ),
			'sha256' => hash( 'sha256', $conteudo ),
		);
	}

	/**
	 * As options de FONTE COMPOSTA, e a função que produz o valor desejado de
	 * cada uma. ÂNCORA DECLARADA.
	 *
	 * Uma option com dois pontos do código montando o valor desejado tem duas
	 * respostas para a mesma pergunta, e a segunda a rodar apaga a primeira sem
	 * que ninguém veja: as duas gravações leem de volta, as duas conferem, e o
	 * relatório sai com duas mensagens verdadeiras e contraditórias sobre o
	 * mesmo artefato. Foi assim que `f3base_redirects` terminou em `a:0:{}`
	 * depois de um log que afirmava, com razão, ter gravado dois pares — e as
	 * URLs antigas dos dois posts passaram a responder 404 em vez de 301.
	 *
	 * A regra, então: option listada aqui só pode ser gravada com o valor que a
	 * função nomeada produzir. Quem confere é `estatica.option_fonte_unica`, que
	 * lê ESTA função — a lista não é reescrita na suíte, que seria a terceira
	 * fonte para o mesmo fato.
	 *
	 * @return array<string,string> Option => nome do método que une as fontes.
	 */
	public static function uniao_declarada(): array {
		return array(
			'f3base_redirects' => 'valor_desejado_de_redirects',
		);
	}

	/**
	 * A função de união declarada para uma option, ou vazio.
	 *
	 * @param string $nome Nome da option.
	 * @return string
	 */
	public static function fonte_composta( string $nome ): string {
		$mapa = self::uniao_declarada();

		return isset( $mapa[ $nome ] ) ? (string) $mapa[ $nome ] : '';
	}

	/**
	 * Monta e registra o resultado de uma escrita.
	 *
	 * @param string              $estado   Estado fechado.
	 * @param string              $chave    Alvo.
	 * @param mixed               $anterior Valor anterior.
	 * @param mixed               $novo     Valor pretendido.
	 * @param string              $motivo   Mensagem.
	 * @param array<string,mixed> $contexto Contexto.
	 * @return array<string,mixed>
	 */
	private static function resultado( string $estado, string $chave, $anterior, $novo, string $motivo, array $contexto ): array {
		$uniao = self::fonte_composta( $chave );

		if ( '' !== $uniao ) {
			$motivo .= sprintf(
				/* translators: 1: nome da option, 2: nome da função de união declarada. */
				__( ' Esta option tem FONTE COMPOSTA declarada: o valor desejado de %1$s não é o que uma etapa isolada sabe, e sim a união produzida por %2$s() — configuração + etapas da execução + o que já estava gravado. Toda gravação dela passa por ali, e é isso que impede que a próxima etapa a tocar apague o trabalho da anterior.', 'f3base' ),
				$chave,
				$uniao
			);
		}

		$resultado = array(
			'estado'   => $estado,
			'chave'    => $chave,
			'anterior' => $anterior,
			'novo'     => $novo,
			'motivo'   => $motivo,
			'uniao'    => $uniao,
			'plugin'   => isset( $contexto['plugin'] ) ? (string) $contexto['plugin'] : '',
			'journal'  => isset( $contexto['journal'] ) ? (string) $contexto['journal'] : '',
			'merge'    => isset( $contexto['merge'] ) ? (string) $contexto['merge'] : '',
			'em'       => time(),
		);

		self::$escritas[] = array(
			'estado' => $estado,
			'chave'  => $chave,
			'motivo' => $motivo,
			'plugin' => $resultado['plugin'],
		);

		return $resultado;
	}
}
