<?php
/**
 * Grafo de dependências do plano de execução.
 *
 * Existe por causa de um defeito medido na terceira execução real. O
 * orquestrador abortava, depois de um BLOCKED, **tudo que vinha depois** —
 * dependência por POSIÇÃO. `formularios` fechou BLOCKED (destino do WhatsApp
 * vazio, correto e esperado) e derrubou `cadencia`, `entrega` e `encerramento`,
 * nenhuma das quais depende do destino de um formulário. O efeito prático foi o
 * pior possível: `mcp.canal_configurado` — a única linha que diria ao operador
 * se o canal está exposto — NÃO RODOU, e o operador ficou olhando "Servidor MCP
 * não detectado" na tela do complemento sem nenhuma evidência do nosso lado.
 *
 * O documento sempre disse outra coisa: erro por etapa "registra FALHA com o
 * motivo, continua nas ETAPAS INDEPENDENTES e aborta as DEPENDENTES". Este
 * arquivo é o que torna "independente" e "dependente" fatos declarados em vez de
 * consequência de onde a unidade caiu na lista.
 *
 * Duas regras que este arquivo existe para não deixar ninguém contornar:
 *
 * 1. **Grupo alvo de dependência precisa existir.** Dependência para grupo
 *    inexistente não vira aresta silenciosa: `conferir()` acusa, e o detector
 *    `estatica.plano_dependencias` roda ESTA função contra o pacote e contra as
 *    fixtures do piso.
 * 2. **Diagnóstico não depende de ninguém.** `mcp`, `entrega` e `encerramento`
 *    declaram lista vazia de propósito. Um inventário do que ficou de pé que
 *    some justamente quando alguma coisa caiu é o instrumento desaparecendo na
 *    hora em que ele é mais necessário.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Grupos, dependências declaradas e fecho transitivo. Tudo função pura.
 */
final class F3Base_Imp_Plano {

	/**
	 * Grupos declarados do plano.
	 *
	 * Grupo é o PRODUTOR de uma dependência: várias unidades podem produzir o
	 * mesmo grupo (todas as páginas e posts produzem `conteudo`), e é por isso
	 * que a declaração é por grupo e a resolução devolve ids concretos.
	 *
	 * @return string[]
	 */
	public static function grupos(): array {
		return array(
			'preflight',
			'migracao',
			'tema',
			'limpeza',
			'site_core',
			'plugins',
			'plugin_seo',
			'plugins_poda',
			'plugins_autoupdate',
			'plugins_onboarding',
			'mcp',
			'exemplo_do_wordpress',
			'opcoes_wp',
			'indexacao',
			'midia',
			'taxonomias',
			'conteudo',
			'conteudo_nao_gerenciado',
			'paginas_especiais',
			'navegacao',
			'seo',
			'seo_llms',
			'options_site_core',
			'formularios',
			'cadencia',
			'entrega',
			'encerramento',
		);
	}

	/**
	 * Dependências REAIS, e só elas. Grupo => grupos de que ele depende.
	 *
	 * O que está fora desta tabela é independente por declaração, não por
	 * esquecimento. Em particular, e isto é o centro da correção:
	 *
	 * - `cadencia`, `entrega` e `encerramento` NÃO dependem de `formularios`.
	 *   Cadência é agendamento de cron; entrega confere entregáveis e o canal;
	 *   encerramento grava estado. Nenhuma das três lê o destino de um
	 *   formulário.
	 * - `entrega` depende, no sentido informal, de tudo que produz entregável —
	 *   e mesmo assim declara lista VAZIA. BLOCKED na entrega é RESULTADO, não
	 *   impedimento para rodá-la: ela é o inventário do que ficou de pé.
	 * - `mcp` também declara vazio, pelo mesmo motivo elevado ao quadrado: é a
	 *   unidade que diagnostica o canal, e foi exatamente ela que sumiu quando o
	 *   canal era a dúvida do operador.
	 *
	 * @return array<string,string[]>
	 */
	public static function dependencias(): array {
		return array(
			'migracao'           => array( 'preflight' ),
			'tema'               => array( 'preflight' ),
			/*
			 * A LIMPEZA DEPENDE DO TEMA, e a dependência é real: os temas de
			 * fábrica só podem sair com o tema do pacote ativo, e um BLOCKED
			 * na troca de tema deixa os três no lugar — que é o lado seguro.
			 */
			'limpeza'            => array( 'tema' ),
			'site_core'          => array( 'preflight' ),
			'plugins'            => array( 'preflight' ),
			'plugin_seo'         => array( 'preflight' ),
			'plugins_poda'       => array( 'preflight' ),
			'plugins_autoupdate' => array( 'preflight' ),
			'plugins_onboarding' => array( 'preflight' ),
			/*
			 * O RESÍDUO SAI ANTES DOS PERMALINKS, e a dependência declara só
			 * `preflight`: a etapa não depende do conteúdo gerenciado — ela mede
			 * o que a INSTALAÇÃO deixou —, e fazê-la esperar por `conteudo`
			 * deixaria uma página gerenciada em BLOCKED segurando a remoção de
			 * um resíduo que não tem nada a ver com ela. O que a ORDEM do plano
			 * garante é que ela rode antes de `opcoes_wp`, que é onde a troca de
			 * estrutura mede as URLs publicadas.
			 */
			'exemplo_do_wordpress' => array( 'preflight' ),
			'opcoes_wp'          => array( 'preflight' ),
			'indexacao'          => array( 'preflight' ),
			'midia'              => array( 'preflight' ),
			'taxonomias'         => array( 'preflight' ),
			'conteudo'           => array( 'preflight', 'midia', 'taxonomias' ),
			/*
			 * INVENTÁRIO NÃO DEPENDE DO QUE INVENTARIA. A unidade que relata o
			 * conteúdo publicado e não gerenciado declara só `preflight`: se ela
			 * dependesse de `conteudo`, uma página gerenciada em BLOCKED
			 * suspenderia justamente a linha que diria ao operador o que mais
			 * está publicado no site. É a mesma regra de `mcp` e `entrega`.
			 */
			'conteudo_nao_gerenciado' => array( 'preflight' ),
			'paginas_especiais'  => array( 'conteudo' ),
			'navegacao'          => array( 'conteudo' ),
			'seo'                => array( 'plugin_seo' ),
			'seo_llms'           => array( 'plugin_seo' ),
			'options_site_core'  => array( 'site_core' ),
			'formularios'        => array( 'site_core' ),
			/*
			 * A CADÊNCIA DEPENDE DO SITE-CORE, e a dependência é declarada aqui
			 * porque ela é REAL — não é ordem de conveniência. Quem registra as
			 * recorrências `f3base_quinzenal` e `f3base_mensal` é o módulo
			 * `cadencia-relatorio` do site-core; o núcleo do WordPress não tem
			 * nenhuma das duas. Agendar antes de o site-core estar de pé
			 * degradava para `daily` — medido numa execução real, com a
			 * configuração declarando `mensal` — e a degradação sobrevivia a
			 * toda reexecução, porque a etapa seguinte encontrava o evento já
			 * agendado e não mexia mais nele.
			 *
			 * A declaração não substitui a posição no plano: ela a torna um
			 * FATO conferível por `estatica.plano_dependencias`, em vez de uma
			 * consequência de onde a unidade caiu na lista.
			 */
			'cadencia'           => array( 'preflight', 'site_core' ),
			'mcp'                => array(),
			'entrega'            => array(),
			'encerramento'       => array(),
		);
	}

	/**
	 * Identificador estável de uma unidade.
	 *
	 * A chave é o que distingue duas unidades da mesma ação: o slug do plugin, a
	 * referência da página, o índice da mídia. Ação sem chave é unidade única.
	 *
	 * @param string $acao  Ação do orquestrador.
	 * @param string $chave Chave de instância, ou vazio.
	 * @return string
	 */
	public static function id( string $acao, string $chave ): string {
		return '' === $chave ? $acao : $acao . '#' . $chave;
	}

	/**
	 * Preenche `depende_de` de cada unidade com IDS CONCRETOS do plano.
	 *
	 * A declaração é por grupo; o que chega na unidade é a lista de ids que
	 * existem de verdade neste plano. Grupo declarado que não produz nenhuma
	 * unidade nesta configuração simplesmente não gera aresta — e isso não é
	 * erro: um site sem mídia declarada não tem por que esperar por mídia.
	 *
	 * @param array<int,array<string,mixed>> $unidades Unidades com `id` e `grupo`.
	 * @return array<int,array<string,mixed>>
	 */
	public static function resolver( array $unidades ): array {
		$por_grupo    = array();
		$dependencias = self::dependencias();

		foreach ( $unidades as $unidade ) {
			$grupo = (string) ( $unidade['grupo'] ?? '' );

			if ( '' === $grupo ) {
				continue;
			}

			$por_grupo[ $grupo ]   = $por_grupo[ $grupo ] ?? array();
			$por_grupo[ $grupo ][] = (string) ( $unidade['id'] ?? '' );
		}

		foreach ( $unidades as $posicao => $unidade ) {
			$grupo = (string) ( $unidade['grupo'] ?? '' );
			$ids   = array();

			foreach ( (array) ( $dependencias[ $grupo ] ?? array() ) as $alvo ) {
				foreach ( (array) ( $por_grupo[ (string) $alvo ] ?? array() ) as $id ) {
					if ( $id !== (string) ( $unidade['id'] ?? '' ) && '' !== $id ) {
						$ids[ $id ] = true;
					}
				}
			}

			$unidades[ $posicao ]['depende_de'] = array_keys( $ids );
		}

		return $unidades;
	}

	/**
	 * Fecho transitivo da suspensão.
	 *
	 * Recebe as unidades já resolvidas e o mapa das INTERROMPIDAS (id => estado
	 * observado, `BLOCKED` ou `FALHA`) e devolve, para cada unidade suspensa, a
	 * dependência direta que a suspendeu e a unidade que originou a suspensão.
	 * Sem isso o relatório diz "ficou sem executar" e não diz POR CAUSA DE QUEM,
	 * que é a única informação que o operador usa em seguida.
	 *
	 * Ponto fixo em vez de uma passada só: o plano hoje está topologicamente
	 * ordenado, e depender dessa ordem seria trocar dependência declarada por
	 * dependência posicional de novo, um nível abaixo.
	 *
	 * @param array<int,array<string,mixed>> $unidades      Unidades resolvidas.
	 * @param array<string,string>           $interrompidas id => estado observado.
	 * @return array<string,array{por:string,raiz:string,estado:string}>
	 */
	public static function suspensas( array $unidades, array $interrompidas ): array {
		$suspensas = array();
		$mudou     = true;

		while ( $mudou ) {
			$mudou = false;

			foreach ( $unidades as $unidade ) {
				$id = (string) ( $unidade['id'] ?? '' );

				if ( '' === $id || isset( $suspensas[ $id ] ) || isset( $interrompidas[ $id ] ) ) {
					continue;
				}

				foreach ( (array) ( $unidade['depende_de'] ?? array() ) as $alvo ) {
					$alvo = (string) $alvo;

					if ( isset( $interrompidas[ $alvo ] ) ) {
						$suspensas[ $id ] = array(
							'por'    => $alvo,
							'raiz'   => $alvo,
							'estado' => (string) $interrompidas[ $alvo ],
						);
						$mudou            = true;
						break;
					}

					if ( isset( $suspensas[ $alvo ] ) ) {
						$suspensas[ $id ] = array(
							'por'    => $alvo,
							'raiz'   => (string) $suspensas[ $alvo ]['raiz'],
							'estado' => (string) $suspensas[ $alvo ]['estado'],
						);
						$mudou            = true;
						break;
					}
				}
			}
		}

		return $suspensas;
	}

	/**
	 * Confere a própria tabela. É a função que o detector do piso executa.
	 *
	 * Três achados possíveis, e nenhum deles pode virar aresta silenciosa:
	 * grupo de origem fora da lista declarada, grupo ALVO fora da lista
	 * declarada (o caso que a regra exige nomear) e ciclo.
	 *
	 * @return array{achados:string[],medidas:int}
	 */
	public static function conferir(): array {
		$grupos       = self::grupos();
		$dependencias = self::dependencias();
		$achados      = array();
		$medidas      = 0;

		foreach ( $dependencias as $grupo => $alvos ) {
			$grupo    = (string) $grupo;
			$medidas++;

			if ( ! in_array( $grupo, $grupos, true ) ) {
				$achados[] = 'grupo "' . $grupo . '" declara dependências e não consta de grupos()';
			}

			foreach ( (array) $alvos as $alvo ) {
				$alvo = (string) $alvo;
				$medidas++;

				if ( ! in_array( $alvo, $grupos, true ) ) {
					$achados[] = 'grupo "' . $grupo . '" depende de "' . $alvo . '", que não existe em grupos(): dependência para unidade inexistente é defeito de configuração, e nunca uma aresta que some';
					continue;
				}

				if ( $alvo === $grupo ) {
					$achados[] = 'grupo "' . $grupo . '" depende de si mesmo';
				}
			}
		}

		foreach ( self::ciclos( $dependencias ) as $ciclo ) {
			$achados[] = 'ciclo de dependência: ' . $ciclo;
		}

		return array(
			'achados' => $achados,
			'medidas' => $medidas,
		);
	}

	/**
	 * Ciclos na tabela declarada.
	 *
	 * @param array<string,string[]> $dependencias Tabela.
	 * @return string[]
	 */
	private static function ciclos( array $dependencias ): array {
		$achados = array();

		foreach ( array_keys( $dependencias ) as $inicio ) {
			$inicio    = (string) $inicio;
			$visitados = array();
			$fila      = array( array( $inicio, $inicio ) );

			while ( array() !== $fila ) {
				$par     = array_shift( $fila );
				$atual   = (string) $par[0];
				$caminho = (string) $par[1];

				foreach ( (array) ( $dependencias[ $atual ] ?? array() ) as $alvo ) {
					$alvo = (string) $alvo;

					if ( $alvo === $inicio ) {
						$achados[ $inicio ] = $caminho . ' → ' . $alvo;
						continue;
					}

					if ( isset( $visitados[ $alvo ] ) ) {
						continue;
					}

					$visitados[ $alvo ] = true;
					$fila[]             = array( $alvo, $caminho . ' → ' . $alvo );
				}
			}
		}

		return array_values( $achados );
	}
}
