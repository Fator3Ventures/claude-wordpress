<?php
/**
 * Produtor ÚNICO do catálogo de decisões do pacote.
 *
 * @package F3Base_Implantador
 */

defined( 'ABSPATH' ) || exit;

/**
 * O CATÁLOGO DE DECISÕES, e por que ele não é configuração.
 *
 * A regra 29 do contrato exige que uma chave de configuração passe nas DUAS
 * metades: existe projeto legítimo em que o valor certo é diferente, E o valor é
 * impossível de derivar do site, do exemplo ou do ambiente. Valor com uma
 * resposta certa só reprova a primeira metade, e chave que só pode ter uma
 * resposta certa não é ponto de extensão — é um comentário com preço de
 * configuração — o mesmo diagnóstico que já tirou da configuração um enum de um
 * valor só, cuja condição nunca podia ser falsa.
 *
 * Ela não ganha padrão melhor: sai da configuração e vem para
 * `config/decisoes.tsv`, onde o MOTIVO fica escrito ao lado do valor. O motivo é
 * normativo: ele diz o que aconteceria se o valor fosse outro, e é isso que
 * impede a decisão de virar um número que ninguém mais sabe explicar.
 *
 * ESTA CLASSE É O ÚNICO LEITOR. O valor de uma decisão não pode aparecer como
 * literal em nenhum outro lugar da árvore: segunda fonte é divergência esperando
 * a hora, e quem cobra isso é `decisoes.fonte_unica`.
 */
class F3Base_Imp_Decisoes {

	/**
	 * Caminho do catálogo, relativo à raiz do pacote.
	 *
	 * @var string
	 */
	public const CATALOGO = 'config/decisoes.tsv';

	/**
	 * Cache do catálogo lido, por arquivo.
	 *
	 * @var array<string,array<string,mixed>>
	 */
	private static $lidos = array();

	/**
	 * O catálogo do pacote instalado.
	 *
	 * @return array<string,mixed> Mapa chave pontilhada => valor.
	 */
	public static function catalogo(): array {
		return self::catalogo_de( F3BASE_IMP_DIR . self::CATALOGO );
	}

	/**
	 * O catálogo lido de um arquivo declarado. Regra pura, e é ela que tem piso.
	 *
	 * O caminho chega por PARÂMETRO de propósito: é isso que permite exercitar a
	 * leitura sem um pacote instalado, e é o que impede a regra de só ser
	 * conhecida pelo arquivo que ela lê hoje.
	 *
	 * ARQUIVO AUSENTE DEVOLVE VAZIO, que é o lado seguro: quem pergunta por uma
	 * decisão que não está lá recebe o padrão declarado na própria chamada, e
	 * nunca um valor fabricado aqui.
	 *
	 * @param string $arquivo Caminho absoluto do catálogo.
	 * @return array<string,mixed> Mapa chave => valor.
	 */
	public static function catalogo_de( string $arquivo ): array {
		if ( isset( self::$lidos[ $arquivo ] ) ) {
			return self::$lidos[ $arquivo ];
		}

		if ( '' === $arquivo || ! is_file( $arquivo ) || ! is_readable( $arquivo ) ) {
			return array();
		}

		$saida = array();

		foreach ( (array) file( $arquivo, FILE_IGNORE_NEW_LINES ) as $linha ) {
			$linha = (string) $linha;

			/*
			 * A GUARDA DO `#` É A QUE CARREGA PESO, e ela tem piso próprio em
			 * `decisoes.leitor_do_pacote`: o modo real de o catálogo ganhar uma
			 * linha fantasma é alguém DESLIGAR uma decisão pondo cerquilha na
			 * frente — a linha continua com as três colunas, JSON válido e
			 * motivo, e só esta guarda a mantém fora.
			 *
			 * A da linha em branco é REDUNDANTE por construção, e está escrito
			 * aqui para ninguém a tomar por defesa: linha vazia sem tabulação
			 * cai na contagem de colunas, e linha só de tabulações cai na chave
			 * vazia logo abaixo. Removê-la não muda resultado nenhum, e é por
			 * isso que ela não tem piso próprio — não há defeito que só ela
			 * pegue.
			 */
			if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
				continue;
			}

			$colunas = explode( "\t", $linha );

			/*
			 * TRÊS COLUNAS, e o motivo é OBRIGATÓRIO: decisão sem o que a
			 * sustenta é número que ninguém mais sabe explicar, e foi para não
			 * ter isso que o catálogo existe. Linha incompleta não vira decisão.
			 */
			if ( count( $colunas ) < 3 ) {
				continue;
			}

			$chave  = trim( $colunas[0] );
			$motivo = trim( $colunas[2] );

			if ( '' === $chave || '' === $motivo ) {
				continue;
			}

			/*
			 * O VALOR É JSON, e célula que não é JSON válido NÃO vira decisão:
			 * TSV é texto, e sem uma forma declarada não há como distinguir a
			 * lista `["page","post"]` da string `"page,post"`. Aceitar o texto
			 * cru faria toda lista chegar ao consumidor como string, e o defeito
			 * apareceria lá na frente, longe daqui.
			 */
			$decodificado = json_decode( trim( $colunas[1] ), true );

			if ( null === $decodificado && 'null' !== trim( $colunas[1] ) ) {
				continue;
			}

			$saida[ $chave ] = $decodificado;
		}

		self::$lidos[ $arquivo ] = $saida;

		return $saida;
	}

	/**
	 * Os MOTIVOS do catálogo, na mesma indexação dos valores.
	 *
	 * Eles existem para serem lidos por quem audita o pacote, e para o detector
	 * poder cobrar que nenhuma decisão exista sem o que a sustenta.
	 *
	 * @param string $arquivo Caminho absoluto do catálogo.
	 * @return array<string,string> Mapa chave => motivo.
	 */
	public static function motivos_de( string $arquivo ): array {
		if ( '' === $arquivo || ! is_file( $arquivo ) || ! is_readable( $arquivo ) ) {
			return array();
		}

		$saida = array();

		foreach ( (array) file( $arquivo, FILE_IGNORE_NEW_LINES ) as $linha ) {
			$linha = (string) $linha;

			if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
				continue;
			}

			$colunas = explode( "\t", $linha );

			if ( count( $colunas ) < 3 ) {
				continue;
			}

			$chave  = trim( $colunas[0] );
			$motivo = trim( $colunas[2] );

			if ( '' === $chave || '' === $motivo ) {
				continue;
			}

			$saida[ $chave ] = $motivo;
		}

		return $saida;
	}

	/**
	 * O valor de UMA decisão.
	 *
	 * O padrão chega por parâmetro e é devolvido quando a chave não está no
	 * catálogo. Ele não é um segundo valor da decisão: é o que o chamador faz
	 * quando o catálogo não responde, e ele nunca deve coincidir com o valor
	 * declarado — coincidir seria a segunda fonte que este arquivo existe para
	 * não ter.
	 *
	 * @param string $chave  Caminho pontilhado da decisão.
	 * @param mixed  $padrao Valor devolvido quando a chave não existe.
	 * @return mixed
	 */
	public static function valor( string $chave, $padrao = null ) {
		$catalogo = self::catalogo();

		return array_key_exists( $chave, $catalogo ) ? $catalogo[ $chave ] : $padrao;
	}

	/**
	 * UM CAMPO de uma decisão que é registro — `plugins.instalaveis.2`, cujo
	 * valor é um objeto com slug, papel, origem e o que mais aquela entrada
	 * declarar.
	 *
	 * O padrão é a string vazia porque é isso que o consumidor já fazia com a
	 * chave ausente, e porque campo vazio é o lado seguro em todos eles: origem
	 * vazia não resolve, url vazia não baixa, sha256 vazio não confere. O que
	 * NÃO pode acontecer é o campo ausente virar um valor plausível.
	 *
	 * @param string $chave  Caminho pontilhado do registro.
	 * @param string $campo  Nome do campo dentro do registro.
	 * @param string $padrao Valor devolvido quando o campo não existe.
	 * @return string
	 */
	public static function campo( string $chave, string $campo, string $padrao = '' ): string {
		$registro = self::valor( $chave );

		if ( ! is_array( $registro ) || ! array_key_exists( $campo, $registro ) ) {
			return $padrao;
		}

		return (string) $registro[ $campo ];
	}

	/**
	 * O BLOCO de decisões sob um prefixo, remontado na forma que o consumidor
	 * já esperava da configuração.
	 *
	 * `plugins.instalaveis.0`, `plugins.instalaveis.1` … voltam como lista
	 * indexada; `ambiente.limites_minimos.memory_mb` e irmãs voltam como mapa.
	 * É isso que permite a decisão sair da configuração sem que o consumidor
	 * precise mudar de forma junto — e sem que ele passe a conhecer o catálogo.
	 *
	 * @param string $prefixo Prefixo pontilhado, sem o ponto final.
	 * @return array<int|string,mixed>
	 */
	public static function bloco( string $prefixo ): array {
		return self::bloco_de( self::catalogo(), $prefixo );
	}

	/**
	 * O bloco remontado de um catálogo declarado. Regra pura, e é ela que tem piso.
	 *
	 * @param array<string,mixed> $catalogo Catálogo já lido.
	 * @param string              $prefixo  Prefixo pontilhado, sem o ponto final.
	 * @return array<int|string,mixed>
	 */
	public static function bloco_de( array $catalogo, string $prefixo ): array {
		if ( '' === $prefixo ) {
			return array();
		}

		$alcance = $prefixo . '.';
		$saida   = array();

		foreach ( $catalogo as $chave => $valor ) {
			if ( ! str_starts_with( $chave, $alcance ) ) {
				continue;
			}

			$resto = substr( $chave, strlen( $alcance ) );

			/*
			 * SÓ O PRIMEIRO NÍVEL vira chave do bloco. Prefixo mais fundo se
			 * pede pelo próprio nome: remontar árvore inteira aqui faria o
			 * consumidor receber uma forma que ele não declarou esperar.
			 */
			if ( str_contains( $resto, '.' ) ) {
				continue;
			}

			/*
			 * Índice numérico volta como inteiro para a lista sair indexada, e
			 * não como mapa de chaves "0" e "1" — que é o que faria o consumidor
			 * de `plugins.instalaveis` receber um objeto onde esperava lista.
			 */
			$saida[ ctype_digit( $resto ) ? (int) $resto : $resto ] = $valor;
		}

		/*
		 * ORDEM ESTÁVEL: o catálogo é um arquivo de texto e a ordem das linhas é
		 * a que alguém escreveu, não necessariamente a ordem da lista. Sem
		 * ordenar, `plugins.instalaveis` sairia na ordem do arquivo e a
		 * precedência de origem — que é posicional — mudaria com uma edição de
		 * texto que ninguém pensou em chamar de mudança de comportamento.
		 */
		ksort( $saida, SORT_NATURAL );

		return $saida;
	}
}
