<?php
/**
 * Preflight: tudo que se mede ANTES de qualquer mutação.
 *
 * O preflight não grava. Ele mede capacidades reais, método de filesystem,
 * escrita nos destinos, espaço em disco, saída HTTPS, limites do PHP, a baseline
 * da instalação, as colisões de slug e o inventário de overrides do editor de
 * site — e devolve o veredito. Capacidade crítica ausente termina em BLOCKED,
 * sem mutação nenhuma.
 *
 * Duas armadilhas moram aqui, com nome:
 *
 * - **Slug igual não prova propriedade.** Objeto no slug desejado sem a meta de
 *   gestão é CONFLICT — sem escrita. A única adoção autorizada é a que a
 *   INSTALAÇÃO prova: a página apontada por `wp_page_for_privacy_policy`, que o
 *   WordPress cria sozinho. Adoção por semelhança de slug é como se sobrescreve
 *   conteúdo de outra pessoa.
 * - **O banco vence o arquivo.** Override do Site Editor em `wp_template`,
 *   `wp_template_part` ou `wp_global_styles` faz o arquivo do tema virar
 *   trabalho que o visitante nunca recebe. O inventário é lido com o
 *   `post_type` EXPLÍCITO: esses tipos são `public => false` e `'any'` não os vê.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Medições anteriores à primeira mutação.
 */
final class F3Base_Imp_Preflight {

	/**
	 * CAMINHO do catálogo de origens de release suportadas, relativo ao pacote.
	 *
	 * Ponto único do nome: a suíte confere o mesmo arquivo, e dois literais do
	 * mesmo caminho divergem no dia em que ele for renomeado.
	 */
	public const CATALOGO_DE_RELEASES = 'config/releases-suportadas.tsv';

	/**
	 * Capacidades exigidas pela operação.
	 *
	 * @return string[]
	 */
	public static function capacidades(): array {
		return array(
			'manage_options',
			'install_plugins',
			'activate_plugins',
			'install_themes',
			'switch_themes',
			'update_themes',
			'update_plugins',
			'edit_theme_options',
			'upload_files',
		);
	}

	/**
	 * Tipos de override do editor de site.
	 *
	 * @return string[]
	 */
	public static function tipos_override(): array {
		return array( 'wp_template', 'wp_template_part', 'wp_global_styles' );
	}

	/**
	 * Chaves que o stub vazio de `wp_global_styles` carrega, e nada mais.
	 *
	 * São MARCADORES de formato, não personalização: o WordPress grava esse post
	 * sozinho ao ativar um tema de blocos, com a versão do formato e a marca de
	 * que aquilo é o JSON de usuário. Um post que só tem isto não é override de
	 * coisa nenhuma.
	 *
	 * @return string[]
	 */
	public static function chaves_de_marcador(): array {
		return array( 'version', 'isGlobalStylesUserThemeJSON', '$schema' );
	}

	/**
	 * Diretório do tema, por tipo de override, onde mora o arquivo equivalente.
	 *
	 * @return array<string,string>
	 */
	public static function pasta_do_tipo(): array {
		return array(
			'wp_template'      => 'templates',
			'wp_template_part' => 'parts',
		);
	}

	/**
	 * ARTEFATOS DO PRÓPRIO PACOTE — baseline por definição.
	 *
	 * O caso medido em produção: `preflight.baseline` reprovou nomeando
	 * `base-site-core-fator3 1.0.0`, que é o plugin persistente que ESTE pacote
	 * instala e ativa. O instrumento estava reprovando o próprio produto, e a
	 * saída que a mensagem oferecia — "declare em plugins.operacionais" — teria
	 * feito o pacote declarar a si mesmo como plugin de terceiro.
	 *
	 * Os três artefatos saem de onde a identidade deles é declarada, NUNCA de
	 * lista literal no código: `site.site_core_slug` e `site.tema_slug` vêm da
	 * configuração, e o implantador vem do arquivo em execução. Trocar o slug na
	 * configuração muda o que a baseline reconhece como nosso — que é a
	 * propriedade que uma lista literal não teria.
	 *
	 * O TIPO viaja junto porque a classificação de plugins não pode absolver um
	 * plugin de terceiro só porque o diretório dele coincide com o slug do
	 * TEMA: quem classifica plugin usa as entradas de tipo `plugin`, e o tema é
	 * conferido contra o tema ativo.
	 *
	 * @return array<int,array{slug:string,tipo:string,origem:string,papel:string}>
	 */
	public static function artefatos_do_pacote(): array {
		$saida = array();

		$site_core = (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' );

		if ( '' !== $site_core ) {
			$saida[] = array(
				'slug'   => $site_core,
				'tipo'   => 'plugin',
				'origem' => 'site.site_core_slug',
				'papel'  => __( 'plugin persistente que este pacote instala e ativa', 'f3base' ),
			);
		}

		$tema = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );

		if ( '' !== $tema ) {
			$saida[] = array(
				'slug'   => $tema,
				'tipo'   => 'tema',
				'origem' => 'site.tema_slug',
				'papel'  => __( 'tema de blocos que este pacote instala e ativa', 'f3base' ),
			);
		}

		$implantador = self::slug_de( plugin_basename( F3BASE_IMP_ARQUIVO ) );

		if ( '' !== $implantador ) {
			$saida[] = array(
				'slug'   => $implantador,
				'tipo'   => 'plugin',
				'origem' => 'plugin_basename( F3BASE_IMP_ARQUIVO )',
				'papel'  => __( 'o próprio implantador em execução', 'f3base' ),
			);
		}

		return $saida;
	}

	/**
	 * Os artefatos do pacote que são PLUGIN, na forma slug => papel declarado.
	 *
	 * @param array<int,array<string,string>> $artefatos Artefatos do pacote.
	 * @return array<string,string>
	 */
	public static function plugins_do_pacote( array $artefatos ): array {
		$saida = array();

		foreach ( $artefatos as $artefato ) {
			if ( 'plugin' !== (string) ( $artefato['tipo'] ?? '' ) ) {
				continue;
			}

			$slug = (string) ( $artefato['slug'] ?? '' );

			if ( '' === $slug ) {
				continue;
			}

			$saida[ $slug ] = (string) ( $artefato['papel'] ?? '' ) . ' (' . (string) ( $artefato['origem'] ?? '' ) . ')';
		}

		return $saida;
	}

	/**
	 * CLASSIFICAÇÃO PURA de cada plugin observado. Sem WordPress, sem veredito.
	 *
	 * A ordem das perguntas é a regra, e ela é declarada aqui: **o que é nosso é
	 * nosso antes de qualquer outra pergunta**. Só depois vêm as listas da
	 * configuração, e o que sobra — o que não é nosso e não está em
	 * `plugins.instalaveis`, `plugins.embarcados`, `plugins.protegidos` nem
	 * `plugins.operacionais` — é divergência a classificar.
	 *
	 * Função pura de propósito: é ela que a sonda funcional exercita nos dois
	 * ramos, sem instalação nenhuma.
	 *
	 * @param array<string,array<string,mixed>>                        $observados   Plugins no disco, por arquivo principal.
	 * @param array<string,string>                                     $do_pacote    Slug => papel dos artefatos do pacote.
	 * @param array<int,string>                                        $gerenciados  Slugs de instalaveis + embarcados.
	 * @param array<int,string>                                        $protegidos   Slugs protegidos.
	 * @param array<string,array{finalidade:string,responsavel:string}> $operacionais Mapa de operacionais.
	 * @param array<string,array<string,mixed>>                        $emissores    Emissores conhecidos DECLARADOS, por slug.
	 * @param array<string,mixed>                                      $options      Options observadas na instalação, por nome.
	 * @return array<string,array<string,mixed>> O observado, com `classe`, `classe_declarada`, `emissor` e `justificativa`.
	 */
	public static function classificar_plugins( array $observados, array $do_pacote, array $gerenciados, array $operacionais, array $emissores = array(), array $options = array() ): array {
		$saida = array();

		foreach ( $observados as $arquivo => $dados ) {
			$slug          = (string) ( $dados['slug'] ?? '' );
			$classe        = 'divergencia-a-classificar';
			$justificativa = __( 'não veio deste pacote e não está declarado como plugin do cliente.', 'f3base' );

			if ( isset( $do_pacote[ $slug ] ) ) {
				$classe        = 'artefato-do-pacote';
				$justificativa = sprintf(
					/* translators: %s: papel e origem declarada do artefato. */
					__( 'artefato deste pacote, e por isso baseline por definição: %s.', 'f3base' ),
					$do_pacote[ $slug ]
				);
			} elseif ( in_array( $slug, $gerenciados, true ) ) {
				$classe        = 'gerenciado';
				$justificativa = __( 'declarado em plugins.instalaveis ou plugins.embarcados: esta execução o instala e o mantém.', 'f3base' );
			} elseif ( isset( $operacionais[ $slug ] ) ) {
				$classe        = 'externo-preservado';
				$justificativa = sprintf(
					/* translators: 1: finalidade declarada, 2: responsável declarado. */
					__( 'declarado em plugins.operacionais — finalidade: %1$s; responsável: %2$s.', 'f3base' ),
					(string) ( $operacionais[ $slug ]['finalidade'] ?? '' ),
					(string) ( $operacionais[ $slug ]['responsavel'] ?? '' )
				);
			}

			/*
			 * O EIXO DA EMISSÃO É OUTRO, e ele não substitui o da declaração.
			 *
			 * Um plugin declarado em `plugins.operacionais` que imprime o
			 * `gtag.js` continua sendo declarado — e continua sendo o segundo
			 * emissor. Se `classe` fosse a única resposta, declarar o plugin
			 * calaria a acusação, que é exatamente o contrário do que esta
			 * regra existe para fazer. Por isso `classe_declarada` guarda o
			 * eixo da declaração inteiro e é ele que decide divergência; a
			 * `classe` passa a `emissor-concorrente` para que a linha do
			 * relatório e a do somente-relatório saiam NOMEADAS.
			 *
			 * E não desativa nada: a premissa do agente continua valendo. A
			 * saída é a contagem no HTML publicado, em `tracking.emissor_unico`.
			 */
			$classe_declarada = $classe;
			$emissor          = 'nao-conhecido';
			$motivo_emissor   = __( 'slug fora da lista declarada de emissores conhecidos: a lista é dica para classificar cedo, e quem decide é a contagem no HTML publicado.', 'f3base' );

			if ( isset( $emissores[ $slug ] ) && ! empty( $dados['ativo'] ) ) {
				$veredito       = F3Base_Imp_Plugins::veredito_de_emissao( (array) $emissores[ $slug ], $options );
				$emissor        = (string) $veredito['veredito'];
				$motivo_emissor = (string) $veredito['motivo'];

				if ( 'leitor' !== $emissor ) {
					$classe        = 'emissor-concorrente';
					$justificativa = sprintf(
						/* translators: 1: veredito de emissão, 2: motivo medido, 3: classe pela declaração. */
						__( 'emissor concorrente (%1$s): %2$s A emissão de toda tag de medição é do módulo tracking do site-core; este plugin é admitido apenas como leitor, com o snippet e a medição automática de conversões desligados. Nada é desativado por esta classificação — pela declaração ele continua sendo %3$s, e quem confere a contagem é tracking.emissor_unico no HTML publicado.', 'f3base' ),
						$emissor,
						$motivo_emissor,
						$classe_declarada
					);
				}
			}

			$saida[ (string) $arquivo ] = array_merge(
				$dados,
				array(
					'classe'           => $classe,
					'classe_declarada' => $classe_declarada,
					'emissor'          => $emissor,
					'motivo_emissor'   => $motivo_emissor,
					'justificativa'    => $justificativa,
				)
			);
		}

		return $saida;
	}

	/**
	 * O post do editor de site é PERSONALIZAÇÃO, ou o stub que o núcleo cria?
	 *
	 * O caso medido: `tema.sem_override_de_editor` reprovou nomeando
	 * `wp_global_styles:wp-global-styles-f3base (#24, 52 bytes)`. O WordPress
	 * cria esse post SOZINHO ao ativar um tema de blocos, e 52 bytes é o stub
	 * vazio. A checagem, medindo EXISTÊNCIA, dispararia em toda instalação de
	 * tema de blocos, para sempre — e a FALHA que sai sempre treina o operador a
	 * ignorar FALHA.
	 *
	 * A pergunta certa é de CONTEÚDO:
	 *
	 * - post vazio nunca é override, em qualquer um dos três tipos;
	 * - `wp_global_styles` só é override quando, tirados os marcadores de
	 *   formato, sobra alguma chave com conteúdo — `settings`, `styles` ou
	 *   qualquer outra;
	 * - `wp_template` e `wp_template_part` só são override quando o conteúdo
	 *   DIFERE do arquivo do tema: post idêntico ao arquivo não muda nada do que
	 *   o visitante recebe.
	 *
	 * JSON que não decodifica em `wp_global_styles` é acusado, e de propósito: o
	 * que não se conseguiu ler não pode ser declarado inofensivo.
	 *
	 * @param string $tipo     Tipo do post de override.
	 * @param string $conteudo `post_content` observado.
	 * @param string $do_tema  Conteúdo do arquivo do tema correspondente; vazio quando não há.
	 * @return array{override:bool,motivo:string}
	 */
	public static function veredito_de_override( string $tipo, string $conteudo, string $do_tema ): array {
		if ( '' === trim( $conteudo ) ) {
			return array(
				'override' => false,
				'motivo'   => __( 'o post existe e está VAZIO: não é personalização, e sai do gate sem sair do relatório.', 'f3base' ),
			);
		}

		if ( 'wp_global_styles' === $tipo ) {
			return self::veredito_de_estilos_globais( $conteudo );
		}

		$normalizar = static fn ( string $texto ): string => trim( str_replace( array( "\r\n", "\r" ), "\n", $texto ) );

		if ( '' !== $do_tema && $normalizar( $conteudo ) === $normalizar( $do_tema ) ) {
			return array(
				'override' => false,
				'motivo'   => __( 'o post é IDÊNTICO ao arquivo do tema: o banco não vence arquivo nenhum quando os dois dizem a mesma coisa.', 'f3base' ),
			);
		}

		if ( '' === $do_tema ) {
			return array(
				'override' => true,
				'motivo'   => __( 'o post tem conteúdo e não há arquivo do tema correspondente para compará-lo: é markup que só existe no banco.', 'f3base' ),
			);
		}

		return array(
			'override' => true,
			'motivo'   => __( 'o conteúdo do post DIFERE do arquivo do tema: o banco vence o arquivo, e atualizar o tema não muda o que o visitante recebe.', 'f3base' ),
		);
	}

	/**
	 * Ramo de `wp_global_styles` do veredito por conteúdo.
	 *
	 * @param string $conteudo `post_content` observado, já sabidamente não vazio.
	 * @return array{override:bool,motivo:string}
	 */
	private static function veredito_de_estilos_globais( string $conteudo ): array {
		$decodificado = json_decode( $conteudo, true );

		if ( ! is_array( $decodificado ) ) {
			return array(
				'override' => true,
				'motivo'   => sprintf(
					/* translators: %s: mensagem do decodificador de JSON. */
					__( 'o conteúdo não decodifica como JSON (%s): o que não se conseguiu ler não pode ser declarado stub vazio.', 'f3base' ),
					json_last_error_msg()
				),
			);
		}

		$personalizadas = array();

		foreach ( $decodificado as $chave => $valor ) {
			if ( in_array( (string) $chave, self::chaves_de_marcador(), true ) ) {
				continue;
			}

			if ( array() === $valor || '' === $valor || null === $valor ) {
				continue;
			}

			$personalizadas[] = (string) $chave;
		}

		if ( array() === $personalizadas ) {
			return array(
				'override' => false,
				'motivo'   => sprintf(
					/* translators: %s: chaves de marcador declaradas. */
					__( 'stub vazio que o WordPress cria ao ativar um tema de blocos: fora dos marcadores de formato (%s), nenhuma chave tem conteúdo — sem settings, sem styles, sem personalização humana.', 'f3base' ),
					implode( ', ', self::chaves_de_marcador() )
				),
			);
		}

		return array(
			'override' => true,
			'motivo'   => sprintf(
				/* translators: %s: chaves com conteúdo. */
				__( 'personalização de fato no editor de site: chave(s) com conteúdo além dos marcadores de formato — %s.', 'f3base' ),
				implode( ', ', $personalizadas )
			),
		);
	}

	/**
	 * Executa o preflight inteiro.
	 *
	 * @return array<string,mixed>
	 */
	public static function executar(): array {
		$resultado = array(
			'capacidades' => self::medir_capacidades(),
			'filesystem'  => self::medir_filesystem(),
			'destinos'    => self::medir_destinos(),
			'disco'       => self::medir_disco(),
			'rede'        => self::medir_saida_https(),
			'limites'     => self::medir_limites(),
			'baseline'    => self::medir_baseline(),
			'colisoes'    => self::medir_colisoes(),
			'overrides'   => self::inventariar_overrides(),
			'origem'      => self::medir_origem_de_release(),
		);

		$criticas_ausentes = array();

		foreach ( $resultado['capacidades'] as $cap => $dados ) {
			if ( $dados['critica'] && ! $dados['tem'] ) {
				$criticas_ausentes[] = $cap;
			}
		}

		if ( ! $resultado['filesystem']['direto'] ) {
			$criticas_ausentes[] = 'filesystem:direct';
		}

		$resultado['criticas_ausentes'] = $criticas_ausentes;
		$resultado['bloqueado']         = array() !== $criticas_ausentes
			|| array() !== $resultado['colisoes']['conflitos']
			|| ! $resultado['origem']['suportada'];

		return $resultado;
	}

	/**
	 * Capacidades reais do usuário em operação.
	 *
	 * A criticidade de `update_plugins`/`update_themes` é DERIVADA: só é crítica
	 * quando já existe artefato instalado que esta execução atualizaria. Marcar
	 * como crítica sempre reprovaria uma instalação limpa saudável.
	 *
	 * @return array<string,array{tem:bool,critica:bool,motivo:string}>
	 */
	public static function medir_capacidades(): array {
		$tema_instalado   = wp_get_theme( (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' ) )->exists();
		$plugins_no_disco = self::plugins_declarados_ja_instalados();

		$saida = array();

		foreach ( self::capacidades() as $cap ) {
			$critica = true;
			$motivo  = __( 'exigida por toda execução que muta o site.', 'f3base' );

			if ( 'update_themes' === $cap ) {
				$critica = $tema_instalado;
				$motivo  = $tema_instalado
					? __( 'crítica: o tema declarado já existe no disco e esta execução o atualizaria.', 'f3base' )
					: __( 'não crítica nesta instalação: o tema declarado ainda não existe, então a etapa instala em vez de atualizar.', 'f3base' );
			}

			if ( 'update_plugins' === $cap ) {
				$critica = array() !== $plugins_no_disco;
				$motivo  = array() !== $plugins_no_disco
					? sprintf(
						/* translators: %s: lista de slugs. */
						__( 'crítica: já estão instalados %s, e esta execução os atualiza para a última versão.', 'f3base' ),
						implode( ', ', $plugins_no_disco )
					)
					: __( 'não crítica nesta instalação: nenhum plugin declarado está instalado, então a etapa instala em vez de atualizar.', 'f3base' );
			}

			$saida[ $cap ] = array(
				'tem'     => current_user_can( $cap ),
				'critica' => $critica,
				'motivo'  => $motivo,
			);
		}

		return $saida;
	}

	/**
	 * Método de filesystem disponível.
	 *
	 * @return array{metodo:string,direto:bool}
	 */
	public static function medir_filesystem(): array {
		if ( ! function_exists( 'get_filesystem_method' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$metodo = get_filesystem_method();

		return array(
			'metodo' => (string) $metodo,
			'direto' => 'direct' === $metodo,
		);
	}

	/**
	 * Escrita nos destinos que a implantação toca.
	 *
	 * @return array<string,array{caminho:string,gravavel:bool}>
	 */
	public static function medir_destinos(): array {
		$uploads = wp_upload_dir();
		$base    = ( is_array( $uploads ) && empty( $uploads['error'] ) && ! empty( $uploads['basedir'] ) )
			? (string) $uploads['basedir']
			: '';

		$destinos = array(
			'plugins'  => WP_PLUGIN_DIR,
			'temas'    => get_theme_root(),
			'uploads'  => $base,
			'raiz_web' => untrailingslashit( ABSPATH ),
		);

		$saida = array();

		foreach ( $destinos as $nome => $caminho ) {
			$saida[ $nome ] = array(
				'caminho'  => (string) $caminho,
				'gravavel' => '' !== (string) $caminho && is_writable( (string) $caminho ),
			);
		}

		return $saida;
	}

	/**
	 * Espaço em disco contra o tamanho do que esta execução move.
	 *
	 * @return array{livre:int,necessario:int,suficiente:bool}
	 */
	public static function medir_disco(): array {
		$pacote = self::tamanho_do_pacote();

		/* Pacote temporário + instalação + preimagem do journal. */
		$necessario = ( $pacote * 3 ) + ( 8 * 1024 * 1024 );
		$livre      = @disk_free_space( WP_CONTENT_DIR ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- disk_free_space emite warning em open_basedir; a ausência do número é o resultado.
		$livre      = is_float( $livre ) || is_int( $livre ) ? (int) $livre : 0;

		return array(
			'livre'      => $livre,
			'necessario' => $necessario,
			'suficiente' => $livre > $necessario,
		);
	}

	/**
	 * Saída HTTPS para a fonte oficial de plugins.
	 *
	 * @return array{alcancavel:bool,alvo:string,detalhe:string}
	 */
	public static function medir_saida_https(): array {
		$alvo     = 'https://api.wordpress.org/core/version-check/1.7/';
		$resposta = wp_remote_head(
			$alvo,
			array(
				'timeout'     => 8,
				'redirection' => 2,
			)
		);

		if ( is_wp_error( $resposta ) ) {
			return array(
				'alcancavel' => false,
				'alvo'       => $alvo,
				'detalhe'    => $resposta->get_error_message(),
			);
		}

		$codigo = (int) wp_remote_retrieve_response_code( $resposta );

		return array(
			'alcancavel' => $codigo > 0 && $codigo < 500,
			'alvo'       => $alvo,
			'detalhe'    => sprintf(
				/* translators: %d: código HTTP observado. */
				__( 'HTTP %d', 'f3base' ),
				$codigo
			),
		);
	}

	/**
	 * Limites de tempo, memória e upload — com os valores em BYTES ao lado.
	 *
	 * O texto de `ini_get()` (`128M`, `8M`) serve para o relatório; a comparação
	 * com o piso declarado em `ambiente.limites_minimos` é numérica, e comparar
	 * `"8M"` com `"16M"` como texto daria `"8M"` maior. Por isso cada limite que
	 * o veredito compara viaja também convertido, pela mesma função do núcleo.
	 *
	 * @return array<string,string|int>
	 */
	public static function medir_limites(): array {
		return array(
			'max_execution_time'  => (int) ini_get( 'max_execution_time' ),
			'memory_limit'        => (string) ini_get( 'memory_limit' ),
			'memoria_bytes'       => (int) wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) ),
			'upload_max_filesize' => (string) ini_get( 'upload_max_filesize' ),
			'upload_bytes'        => (int) wp_convert_hr_to_bytes( (string) ini_get( 'upload_max_filesize' ) ),
			'post_max_size'       => (string) ini_get( 'post_max_size' ),
			'post_bytes'          => (int) wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) ),
			'wp_memory_limit'     => defined( 'WP_MEMORY_LIMIT' ) ? (string) WP_MEMORY_LIMIT : '',
			'php'                 => PHP_VERSION,
		);
	}

	/**
	 * Baseline da instalação, com cada plugin ativo classificado.
	 *
	 * Diferença não é erro: é fato que o preflight registra e classifica.
	 * "Plugin operacional do cliente" é classe declarada na configuração, e
	 * plugin ativo fora da baseline E fora da lista é divergência a classificar
	 * antes de aplicar — nunca ruído.
	 *
	 * O que esta função NÃO faz mais: acusar o próprio pacote. Os artefatos que
	 * ele instala — site-core, tema e o implantador — são baseline por
	 * definição, resolvidos por `artefatos_do_pacote()` a partir dos slugs
	 * declarados na configuração. A decisão inteira vive na função pura
	 * `classificar_plugins()`; aqui só se lê o site e se monta a entrada dela.
	 *
	 * @return array<string,mixed>
	 */
	public static function medir_baseline(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$gerenciados = array();

		foreach ( F3Base_Imp_Decisoes::bloco( 'plugins.instalaveis' ) as $indice => $entrada ) {
			unset( $entrada );
			$gerenciados[] = (string) F3Base_Imp_Decisoes::campo( 'plugins.instalaveis.' . $indice, 'slug' );
		}

		foreach ( F3Base_Imp_Plugins::entradas_declaradas( 'plugins.embarcados' ) as $indice => $entrada ) {
			unset( $entrada );
			$gerenciados[] = (string) F3Base_Imp_Config::obter( 'plugins.embarcados.' . $indice . '.slug', '' );
		}

		$operacionais = array();

		foreach ( F3Base_Imp_Projeto::lista( 'plugins_operacionais' ) as $indice => $entrada ) {
			unset( $entrada );
			$slug = (string) F3Base_Imp_Projeto::obter( 'plugins_operacionais.' . $indice . '.slug', '' );

			if ( '' !== $slug ) {
				$operacionais[ $slug ] = array(
					'finalidade'  => (string) F3Base_Imp_Projeto::obter( 'plugins_operacionais.' . $indice . '.finalidade', '' ),
					'responsavel' => (string) F3Base_Imp_Projeto::obter( 'plugins_operacionais.' . $indice . '.responsavel', '' ),
				);
			}
		}

		$observados = array();

		foreach ( get_plugins() as $arquivo => $dados ) {
			$observados[ (string) $arquivo ] = array(
				'slug'   => self::slug_de( (string) $arquivo ),
				'nome'   => isset( $dados['Name'] ) ? (string) $dados['Name'] : self::slug_de( (string) $arquivo ),
				'versao' => isset( $dados['Version'] ) ? (string) $dados['Version'] : '',
				'ativo'  => is_plugin_active( (string) $arquivo ),
			);
		}

		$artefatos = self::artefatos_do_pacote();
		$do_pacote = self::plugins_do_pacote( $artefatos );

		/*
		 * O SEGUNDO EMISSOR entra aqui, e ele é medido ANTES de qualquer
		 * mutação — que é o único momento em que nomeá-lo ainda serve para
		 * alguma coisa. A declaração vem do arquivo único; as options de
		 * condição vêm do banco desta instalação, e só as que a declaração
		 * nomeia são lidas.
		 */
		$emissores = F3Base_Imp_Plugins::emissores_declarados();
		$condicoes = F3Base_Imp_Plugins::options_de_condicao( $emissores );

		$classificados = self::classificar_plugins( $observados, $do_pacote, $gerenciados, $operacionais, $emissores, $condicoes );

		$tema      = wp_get_theme();
		$tema_slug = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );

		return array(
			'wordpress'        => get_bloginfo( 'version' ),
			'php'              => PHP_VERSION,
			'tema_ativo'       => $tema->get_stylesheet(),
			'tema_versao'      => (string) $tema->get( 'Version' ),
			'tema_e_do_pacote' => '' !== $tema_slug && $tema_slug === $tema->get_stylesheet(),
			'multisite'        => is_multisite(),
			'artefatos'        => $artefatos,
			'plugins'          => $classificados,
			/*
			 * DIVERGÊNCIA CONTINUA SENDO DO EIXO DA DECLARAÇÃO. Se ela lesse
			 * `classe`, declarar um plugin emissor em `plugins.operacionais`
			 * não o tiraria da lista — mas um plugin NÃO declarado que
			 * emitisse sairia dela, porque a classe dele teria virado
			 * `emissor-concorrente`. Os dois eixos são independentes e
			 * continuam sendo lidos cada um pelo seu nome.
			 */
			'divergencias'     => array_values(
				array_filter(
					$classificados,
					static fn ( array $item ): bool => 'divergencia-a-classificar' === $item['classe_declarada'] && $item['ativo']
				)
			),
			'emissores'        => array_values(
				array_filter(
					$classificados,
					static fn ( array $item ): bool => 'emissor-concorrente' === $item['classe']
				)
			),
		);
	}

	/**
	 * Colisões de slug entre o desejado e o observado.
	 *
	 * @return array{conflitos:array<int,array<string,mixed>>,adocoes:array<int,array<string,mixed>>,livres:string[]}
	 */
	public static function medir_colisoes(): array {
		$conflitos = array();
		$adocoes   = array();
		$livres    = array();

		$privacidade = (int) get_option( 'wp_page_for_privacy_policy', 0 );

		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			$ref  = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' );
			$slug = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.slug', '' );

			if ( '' === $ref ) {
				continue;
			}

			$gerenciado = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );

			if ( $gerenciado > 0 ) {
				$livres[] = $ref;
				continue;
			}

			$existente = self::pagina_por_slug( $slug, $ref );

			if ( $existente <= 0 ) {
				$livres[] = $ref;
				continue;
			}

			$autoriza = (bool) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.adotar_existente', false );
			$provada  = ( $privacidade > 0 && $privacidade === $existente );

			if ( $autoriza && $provada ) {
				$adocoes[] = array(
					'ref'    => $ref,
					'slug'   => $slug,
					'id'     => $existente,
					'motivo' => __( 'adoção autorizada por objeto e provada pela instalação: é a página apontada por wp_page_for_privacy_policy.', 'f3base' ),
				);
				continue;
			}

			$conflitos[] = array(
				'ref'    => $ref,
				'slug'   => $slug,
				'id'     => $existente,
				'titulo' => (string) get_the_title( $existente ),
				'motivo' => $autoriza
					? __( 'a entrada autoriza adoção, mas a instalação não prova propriedade: o objeto no slug não é a página de privacidade criada pelo WordPress. CONFLICT sem escrita.', 'f3base' )
					: __( 'existe objeto no slug desejado sem a meta de gestão. Slug igual não prova propriedade: CONFLICT sem escrita.', 'f3base' ),
			);
		}

		foreach ( F3Base_Imp_Config::lista( 'posts' ) as $indice => $entrada ) {
			unset( $entrada );

			$slug = (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' );

			if ( '' === $slug ) {
				continue;
			}

			if ( F3Base_Imp_Conteudo::localizar_gerenciado( 'post', $slug ) > 0 ) {
				$livres[] = $slug;
				continue;
			}

			$existente = self::post_por_slug( $slug );

			if ( $existente <= 0 ) {
				$livres[] = $slug;
				continue;
			}

			$conflitos[] = array(
				'ref'    => $slug,
				'slug'   => $slug,
				'id'     => $existente,
				'titulo' => (string) get_the_title( $existente ),
				'motivo' => __( 'existe post no slug desejado sem a meta de gestão. Slug igual não prova propriedade: CONFLICT sem escrita.', 'f3base' ),
			);
		}

		return array(
			'conflitos' => $conflitos,
			'adocoes'   => $adocoes,
			'livres'    => $livres,
		);
	}

	/**
	 * Inventário dos posts do editor de site, cada um julgado por CONTEÚDO.
	 *
	 * O inventário devolve TODOS os posts inspecionados, e cada um carrega o
	 * veredito de `veredito_de_override()` com o motivo. Quem some do inventário
	 * some do relatório, e sumir do relatório seria a outra metade do erro que
	 * esta release corrige: o stub vazio precisa aparecer como INSPECIONADO,
	 * mesmo não sendo achado.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function inventariar_overrides(): array {
		$saida = array();
		$raiz  = get_stylesheet_directory();

		foreach ( self::tipos_override() as $tipo ) {
			/*
			 * `post_type` EXPLÍCITO: estes tipos são registrados com
			 * `public => false` e `'any'` os exclui — a consulta pareceria
			 * limpa num site cheio de overrides.
			 */
			$posts = get_posts(
				array(
					'post_type'        => $tipo,
					'post_status'      => array( 'publish', 'draft', 'auto-draft', 'pending', 'private' ),
					'numberposts'      => 200,
					'suppress_filters' => false,
					'no_found_rows'    => true,
				)
			);

			foreach ( $posts as $post ) {
				if ( ! $post instanceof WP_Post ) {
					continue;
				}

				$conteudo = (string) $post->post_content;
				$do_tema  = self::arquivo_do_tema( $raiz, $tipo, (string) $post->post_name );
				$veredito = self::veredito_de_override( $tipo, $conteudo, $do_tema );

				$saida[] = array(
					'tipo'     => $tipo,
					'id'       => $post->ID,
					'slug'     => $post->post_name,
					'tema'     => self::tema_do_override( $post->ID ),
					'autor'    => (int) $post->post_author,
					'data'     => $post->post_modified_gmt,
					'sha256'   => hash( 'sha256', $conteudo ),
					'bytes'    => strlen( $conteudo ),
					'override' => $veredito['override'],
					'motivo'   => $veredito['motivo'],
				);
			}
		}

		return $saida;
	}

	/**
	 * Conteúdo do arquivo do tema equivalente a um post de override.
	 *
	 * `wp_global_styles` não tem arquivo equivalente — o `theme.json` não é o
	 * mesmo formato, e comparar os dois seria inventar equivalência.
	 *
	 * @param string $raiz Diretório do tema ativo.
	 * @param string $tipo Tipo do post de override.
	 * @param string $slug Slug do post.
	 * @return string Conteúdo, ou vazio quando não há arquivo.
	 */
	private static function arquivo_do_tema( string $raiz, string $tipo, string $slug ): string {
		$pastas = self::pasta_do_tipo();

		if ( '' === $raiz || '' === $slug || ! isset( $pastas[ $tipo ] ) ) {
			return '';
		}

		$caminho = rtrim( $raiz, '/' ) . '/' . $pastas[ $tipo ] . '/' . $slug . '.html';

		if ( ! is_readable( $caminho ) ) {
			return '';
		}

		$conteudo = file_get_contents( $caminho ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo do tema instalado, leitura local.

		return is_string( $conteudo ) ? $conteudo : '';
	}

	/**
	 * A MATRIZ de origens de release suportadas, lida do catálogo do pacote.
	 *
	 * PRODUTOR ÚNICO da lista fechada. Ela responde a uma pergunta sobre o
	 * PACOTE — de qual versão instalada este implantador sabe subir —, e não
	 * sobre o site que ele implanta: nenhum projeto legítimo tem uma resposta
	 * diferente, e um operador que a editasse estaria afirmando ter homologado
	 * um caminho que ninguém percorreu. Por isso ela saiu do arquivo que o
	 * operador abre e virou catálogo do pacote.
	 *
	 * O formato é declarado no cabeçalho do próprio arquivo: três colunas,
	 * comentário e linha em branco ignorados. Arquivo ausente devolve lista
	 * vazia, e lista vazia é o lado seguro — só a instalação limpa passa, e
	 * qualquer outra origem sai como não suportada, nomeada.
	 *
	 * @return array<int,array{componente:string,versao:string,determinacao:string}>
	 */
	public static function releases_suportadas(): array {
		return self::releases_suportadas_de( F3BASE_IMP_DIR . self::CATALOGO_DE_RELEASES );
	}

	/**
	 * A MATRIZ lida de um arquivo declarado. Regra pura, e é ela que tem piso.
	 *
	 * O caminho chega por PARÂMETRO de propósito: é isso que permite exercitar a
	 * leitura sem um pacote instalado, e é o que impede a regra de só ser
	 * conhecida pelo arquivo que ela lê hoje.
	 *
	 * @param string $arquivo Caminho absoluto do catálogo.
	 * @return array<int,array{componente:string,versao:string,determinacao:string}>
	 */
	public static function releases_suportadas_de( string $arquivo ): array {
		if ( '' === $arquivo || ! is_file( $arquivo ) || ! is_readable( $arquivo ) ) {
			return array();
		}

		$saida = array();

		foreach ( (array) file( $arquivo, FILE_IGNORE_NEW_LINES ) as $linha ) {
			$linha = (string) $linha;

			if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
				continue;
			}

			$colunas = explode( "\t", $linha );

			if ( count( $colunas ) < 3 ) {
				continue;
			}

			$saida[] = array(
				'componente'   => trim( $colunas[0] ),
				'versao'       => trim( $colunas[1] ),
				'determinacao' => trim( $colunas[2] ),
			);
		}

		return $saida;
	}

	/**
	 * Origem da release: instalação limpa ou entrada da lista fechada.
	 *
	 * @return array{origem:string,suportada:bool,motivo:string}
	 */
	public static function medir_origem_de_release(): array {
		$aplicada = (string) get_option( 'f3base_release', '' );

		/*
		 * A lista fechada é lida SEMPRE, mesmo em instalação limpa: ela é o
		 * coração do contrato de caminho, e já passou uma release inteira sem
		 * leitor porque só era consultada no ramo que quase nunca executa.
		 */
		$aceitas = self::releases_suportadas();

		if ( '' === $aplicada ) {
			return array(
				'origem'    => 'limpa',
				'suportada' => true,
				'motivo'    => sprintf(
					/* translators: %d: quantidade de origens declaradas além da instalação limpa. */
					__( 'nenhuma release aplicada registrada: origem tratada como instalação limpa, que é sempre suportada. A lista fechada declara %d origem(ns) adicional(is), cada uma custando uma homologação.', 'f3base' ),
					count( $aceitas )
				),
			);
		}

		$alvo = (string) F3Base_Imp_Config::obter( 'release.identidade', '' );

		if ( $aplicada === $alvo ) {
			return array(
				'origem'    => $aplicada,
				'suportada' => true,
				'motivo'    => __( 'a release aplicada é a mesma desta execução: reaplicação idempotente.', 'f3base' ),
			);
		}

		foreach ( $aceitas as $aceita ) {
			if ( 'implantador' === $aceita['componente'] && $aceita['versao'] === $aplicada ) {
				return array(
					'origem'    => $aplicada,
					'suportada' => true,
					'motivo'    => sprintf(
						/* translators: 1: versão de origem, 2: como a entrada foi determinada. */
						__( 'origem %1$s consta da lista fechada de versões aceitas (determinação: %2$s).', 'f3base' ),
						$aplicada,
						$aceita['determinacao']
					),
				);
			}
		}

		return array(
			'origem'    => $aplicada,
			'suportada' => false,
			'motivo'    => sprintf(
				/* translators: %s: versão observada no site. */
				__( 'a release aplicada neste site (%s) não é instalação limpa nem consta da lista fechada de origens aceitas: BLOCKED sem mutação. As saídas são declarar a origem na configuração, com a determinação, ou abandonar explicitamente.', 'f3base' ),
				$aplicada
			),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Internos
	 * ------------------------------------------------------------------ */

	/**
	 * Slugs declarados que já existem no disco.
	 *
	 * @return string[]
	 */
	private static function plugins_declarados_ja_instalados(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$instalados = array();

		foreach ( array_keys( get_plugins() ) as $arquivo ) {
			$instalados[] = self::slug_de( (string) $arquivo );
		}

		$declarados = array();

		foreach ( array( 'plugins.instalaveis', 'plugins.embarcados' ) as $secao ) {
			foreach ( F3Base_Imp_Config::lista( $secao ) as $indice => $entrada ) {
				unset( $entrada );

				$slug = (string) F3Base_Imp_Config::obter( $secao . '.' . $indice . '.slug', '' );

				if ( '' !== $slug && in_array( $slug, $instalados, true ) ) {
					$declarados[] = $slug;
				}
			}
		}

		return array_values( array_unique( $declarados ) );
	}

	/**
	 * Slug (diretório) de um arquivo de plugin.
	 *
	 * @param string $arquivo Caminho relativo do arquivo principal.
	 * @return string
	 */
	public static function slug_de( string $arquivo ): string {
		$partes = explode( '/', $arquivo );

		return count( $partes ) > 1 ? $partes[0] : basename( $arquivo, '.php' );
	}

	/**
	 * Página existente pelo slug, incluindo lixeira.
	 *
	 * @param string $slug Slug declarado.
	 * @param string $ref  Referência lógica, usada quando o slug é vazio (home).
	 * @return int ID, ou 0.
	 */
	private static function pagina_por_slug( string $slug, string $ref ): int {
		$procurado = '' !== $slug ? $slug : $ref;

		$encontrados = get_posts(
			array(
				'post_type'        => 'page',
				'name'             => $procurado,
				'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future', 'trash' ),
				'numberposts'      => 1,
				'fields'           => 'ids',
				'suppress_filters' => false,
				'no_found_rows'    => true,
			)
		);

		return ( is_array( $encontrados ) && array() !== $encontrados ) ? (int) $encontrados[0] : 0;
	}

	/**
	 * Post existente pelo slug, incluindo lixeira.
	 *
	 * @param string $slug Slug.
	 * @return int ID, ou 0.
	 */
	private static function post_por_slug( string $slug ): int {
		$encontrados = get_posts(
			array(
				'post_type'        => 'post',
				'name'             => $slug,
				'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future', 'trash' ),
				'numberposts'      => 1,
				'fields'           => 'ids',
				'suppress_filters' => false,
				'no_found_rows'    => true,
			)
		);

		return ( is_array( $encontrados ) && array() !== $encontrados ) ? (int) $encontrados[0] : 0;
	}

	/**
	 * Tema ao qual um override pertence.
	 *
	 * @param int $id ID do post de override.
	 * @return string
	 */
	private static function tema_do_override( int $id ): string {
		$termos = wp_get_object_terms( $id, 'wp_theme', array( 'fields' => 'slugs' ) );

		if ( is_wp_error( $termos ) || ! is_array( $termos ) || array() === $termos ) {
			return '';
		}

		return (string) $termos[0];
	}

	/**
	 * Tamanho em bytes dos artefatos que viajam no pacote.
	 *
	 * @return int
	 */
	private static function tamanho_do_pacote(): int {
		$total = 0;

		foreach ( array( 'fontes/tema', 'assets', 'content' ) as $pasta ) {
			$raiz = f3base_imp_caminho( $pasta );

			if ( '' === $raiz || ! is_dir( $raiz ) ) {
				continue;
			}

			$iterador = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ) );

			foreach ( $iterador as $arquivo ) {
				if ( $arquivo instanceof SplFileInfo && $arquivo->isFile() ) {
					$total += (int) $arquivo->getSize();
				}
			}
		}

		return $total;
	}
}
