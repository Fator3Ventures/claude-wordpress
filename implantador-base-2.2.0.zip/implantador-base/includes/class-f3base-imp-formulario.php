<?php
/**
 * O FORMULÁRIO do site: cria, publica e coloca na página.
 *
 * @package F3Base_Implantador
 */

defined( 'ABSPATH' ) || exit;

/**
 * O formulário de contato, criado de verdade.
 *
 * ANTES DESTA CLASSE, o regime `cf7-email` era uma declaração sem consequência:
 * a configuração descrevia campos, página de confirmação e caixa de leads, e a
 * etapa correspondente emitia uma linha de relatório dizendo que o regime
 * existia — sem criar formulário nenhum. O plugin que processa o formulário
 * sequer estava no catálogo; o que estava era a CAIXA dele, sozinha, guardando
 * envios que nunca aconteciam.
 *
 * O que esta classe faz, na ordem:
 *
 * 1. Cria o formulário no Contact Form 7, com os campos declarados, a
 *    mensagem de e-mail e o destinatário.
 * 2. Cria a página de confirmação, se ela ainda não existir.
 * 3. Põe o shortcode do formulário na página declarada, e reprova quando a
 *    página declarada fica sem ele.
 *
 * O DESTINATÁRIO É DERIVADO, não perguntado: o e-mail administrativo do site já
 * responde por ele, e a cópia de cada envio fica no Flamingo, que é a caixa. O
 * operador só precisa preencher `caixa_de_leads` quando quiser um destinatário
 * diferente do administrativo — e vazio não desliga nada.
 */
class F3Base_Imp_Formulario {

	/**
	 * Tipo de post do Contact Form 7.
	 *
	 * @var string
	 */
	public const TIPO = 'wpcf7_contact_form';

	/**
	 * O MARKUP do formulário, montado a partir dos campos declarados.
	 *
	 * Regra pura, e é ela que tem piso. Os campos obrigatórios chegam por
	 * parâmetro; `nome` e `email` viram entrada de texto e de e-mail, e a
	 * mensagem entra sempre — formulário de contato sem campo de mensagem é uma
	 * lista de dados sem o que a pessoa queria dizer.
	 *
	 * @param array<int,string> $obrigatorios Campos obrigatórios declarados.
	 * @return string Markup do CF7.
	 */
	public static function markup( array $obrigatorios ): string {
		$exigido = static function ( string $campo ) use ( $obrigatorios ): string {
			return in_array( $campo, $obrigatorios, true ) ? '*' : '';
		};

		$linhas = array(
			'<label>' . esc_html__( 'Nome', 'f3base' ) . '<br />',
			'[text' . $exigido( 'nome' ) . ' seu-nome autocomplete:name]</label>',
			'',
			'<label>' . esc_html__( 'E-mail', 'f3base' ) . '<br />',
			'[email' . $exigido( 'email' ) . ' seu-email autocomplete:email]</label>',
			'',
			'<label>' . esc_html__( 'Telefone', 'f3base' ) . '<br />',
			'[tel' . $exigido( 'telefone' ) . ' seu-telefone autocomplete:tel]</label>',
			'',
			'<label>' . esc_html__( 'Mensagem', 'f3base' ) . '<br />',
			'[textarea' . $exigido( 'mensagem' ) . ' sua-mensagem]</label>',
			'',
			'[submit "' . esc_attr__( 'Enviar', 'f3base' ) . '"]',
		);

		return implode( "\n", $linhas );
	}

	/**
	 * O DESTINATÁRIO do e-mail do formulário.
	 *
	 * Regra pura. A caixa declarada vence quando existe; sem ela, o e-mail
	 * administrativo do site — que sempre existe e é de quem instalou. Devolver
	 * vazio aqui faria o CF7 recusar o envio inteiro.
	 *
	 * @param string $declarada Caixa declarada no arquivo do projeto.
	 * @param string $admin     E-mail administrativo do site.
	 * @return string
	 */
	public static function destinatario( string $declarada, string $admin ): string {
		$declarada = trim( $declarada );

		if ( '' !== $declarada && is_email( $declarada ) ) {
			return $declarada;
		}

		return $admin;
	}

	/**
	 * O SHORTCODE de um formulário pelo id do post.
	 *
	 * @param int    $id     Id do post do formulário.
	 * @param string $titulo Título do formulário.
	 * @return string
	 */
	public static function shortcode( int $id, string $titulo ): string {
		return '[contact-form-7 id="' . $id . '" title="' . esc_attr( $titulo ) . '"]';
	}

	/**
	 * O BLOCO de conteúdo que carrega o shortcode.
	 *
	 * @param int    $id     Id do post do formulário.
	 * @param string $titulo Título do formulário.
	 * @return string
	 */
	public static function bloco( int $id, string $titulo ): string {
		return "<!-- wp:shortcode -->\n" . self::shortcode( $id, $titulo ) . "\n<!-- /wp:shortcode -->";
	}

	/**
	 * O CONTEÚDO da página com o formulário DENTRO, sem duplicar.
	 *
	 * Regra pura, e o piso dela é a reexecução: o pacote roda mais de uma vez no
	 * mesmo site, e um bloco acrescentado a cada execução deixaria a página com
	 * três formulários iguais. A presença é medida pelo id do formulário no
	 * conteúdo, não pelo texto do bloco inteiro — o agente pode ter movido o
	 * shortcode de lugar ou trocado a formatação em volta, e mover não é apagar.
	 *
	 * @param string $conteudo Conteúdo atual da página.
	 * @param int    $id       Id do post do formulário.
	 * @param string $titulo   Título do formulário.
	 * @return array{conteudo:string,mudou:bool}
	 */
	public static function conteudo_com_formulario( string $conteudo, int $id, string $titulo ): array {
		if ( str_contains( $conteudo, 'contact-form-7 id="' . $id . '"' ) ) {
			return array(
				'conteudo' => $conteudo,
				'mudou'    => false,
			);
		}

		$bloco = self::bloco( $id, $titulo );

		return array(
			'conteudo' => '' === trim( $conteudo ) ? $bloco : rtrim( $conteudo ) . "\n\n" . $bloco,
			'mudou'    => true,
		);
	}

	/**
	 * A CONFIGURAÇÃO de e-mail do formulário, na forma que o CF7 grava.
	 *
	 * @param string $destinatario Para quem o e-mail vai.
	 * @param string $nome_do_site Nome do site, usado no remetente.
	 * @param string $email_do_site E-mail do domínio, usado no remetente.
	 * @return array<string,mixed>
	 */
	public static function correio( string $destinatario, string $nome_do_site, string $email_do_site ): array {
		return array(
			'active'             => true,
			'subject'            => sprintf(
				/* translators: %s: nome do site. */
				__( '[%s] Novo contato pelo site', 'f3base' ),
				$nome_do_site
			),
			'sender'             => $nome_do_site . ' <' . $email_do_site . '>',
			'recipient'          => $destinatario,
			'body'               => implode(
				"\n",
				array(
					__( 'Nome: [seu-nome]', 'f3base' ),
					__( 'E-mail: [seu-email]', 'f3base' ),
					__( 'Telefone: [seu-telefone]', 'f3base' ),
					'',
					__( 'Mensagem:', 'f3base' ),
					'[sua-mensagem]',
					'',
					__( 'Enviado em [_date] às [_time], da página [_post_url].', 'f3base' ),
				)
			),
			/*
			 * `Reply-To` com o e-mail de quem escreveu: sem ele, responder ao
			 * aviso responde ao próprio site, e a resposta nunca chega à pessoa.
			 */
			'additional_headers' => 'Reply-To: [seu-email]',
			'attachments'        => '',
			'use_html'           => false,
			'exclude_blank'      => false,
		);
	}

	/**
	 * APLICA o regime de formulário: cria o formulário, a página de confirmação
	 * e põe o shortcode na página declarada.
	 *
	 * @param array<string,mixed> $regime Entrada do regime, já lida.
	 * @return array{estado:string,rotulo:string,motivo:string,resumo:string}
	 */
	public static function aplicar( array $regime ): array {
		$titulo = (string) ( $regime['id'] ?? 'contato' );

		if ( ! post_type_exists( self::TIPO ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'rotulo' => 'formulario.criado',
				'motivo' => __( 'O plugin de formulário não está ativo, então o formulário não pôde ser criado. Instale e ative o Contact Form 7 e rode de novo.', 'f3base' ),
				'resumo' => __( 'plugin de formulário ausente', 'f3base' ),
			);
		}

		$id = self::id_existente( $titulo );

		$campos = array(
			'post_type'    => self::TIPO,
			'post_status'  => 'publish',
			'post_title'   => $titulo,
			'post_name'    => sanitize_title( $titulo ),
			'post_content' => '',
		);

		if ( $id > 0 ) {
			$campos['ID'] = $id;
			$salvo        = wp_update_post( wp_slash( $campos ), true );
		} else {
			$salvo = wp_insert_post( wp_slash( $campos ), true );
		}

		if ( is_wp_error( $salvo ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::FALHA,
				'rotulo' => 'formulario.criado',
				'motivo' => sprintf(
					/* translators: %s: mensagem do erro. */
					__( 'O formulário não pôde ser gravado: %s', 'f3base' ),
					$salvo->get_error_message()
				),
				'resumo' => __( 'gravação recusada', 'f3base' ),
			);
		}

		$novo = 0 === $id;
		$id   = (int) $salvo;

		if ( $novo ) {
			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_POST,
				'formulario:' . $titulo,
				null,
				array( 'id' => $id ),
				array(
					'acao' => 'post.excluir',
					'id'   => $id,
				)
			);
		}

		$obrigatorios = array_map( 'strval', (array) ( $regime['obrigatorios'] ?? array() ) );

		$correio = self::correio(
			self::destinatario( (string) ( $regime['caixa_de_leads'] ?? '' ), (string) get_option( 'admin_email', '' ) ),
			(string) get_bloginfo( 'name' ),
			self::remetente_do_dominio()
		);

		foreach (
			array(
				'_form'     => self::markup( $obrigatorios ),
				'_mail'     => $correio,
				'_messages' => self::mensagens(),
				'_locale'   => (string) get_locale(),
			) as $chave => $valor
		) {
			F3Base_Imp_Gravador::gravar_meta( 'post', $id, $chave, $valor, array( 'plugin' => 'contact-form-7' ) );
		}

		$partes = array( sprintf( /* translators: %d: id do formulário. */ __( 'formulário #%d publicado', 'f3base' ), $id ) );

		$confirmacao = self::garantir_confirmacao( $regime );

		if ( '' !== $confirmacao ) {
			$partes[] = $confirmacao;
		}

		$na_pagina = self::por_na_pagina( $regime, $id, $titulo );
		$partes[]  = $na_pagina['motivo'];

		return array(
			'estado' => $na_pagina['ok'] ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::FALHA,
			'rotulo' => 'formulario.criado',
			'motivo' => implode( '; ', $partes ) . '.',
			'resumo' => implode( '; ', $partes ),
		);
	}

	/**
	 * O ID de um formulário já criado com este título, ou zero.
	 *
	 * @param string $titulo Título do formulário.
	 * @return int
	 */
	private static function id_existente( string $titulo ): int {
		$achados = get_posts(
			array(
				'post_type'        => self::TIPO,
				'post_status'      => 'any',
				'name'             => sanitize_title( $titulo ),
				'numberposts'      => 1,
				'fields'           => 'ids',
				'suppress_filters' => false,
			)
		);

		return array() === (array) $achados ? 0 : (int) $achados[0];
	}

	/**
	 * O REMETENTE no domínio do próprio site.
	 *
	 * Remetente fora do domínio é o motivo mais comum de o aviso do formulário
	 * cair em spam, e o CF7 recusa a configuração quando percebe.
	 *
	 * @return string
	 */
	private static function remetente_do_dominio(): string {
		$host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$host = preg_replace( '/^www\./', '', $host );

		return 'wordpress@' . ( is_string( $host ) && '' !== $host ? $host : 'localhost' );
	}

	/**
	 * As MENSAGENS do formulário, em português comum.
	 *
	 * @return array<string,string>
	 */
	private static function mensagens(): array {
		return array(
			'mail_sent_ok'          => __( 'Mensagem enviada. Em breve entramos em contato.', 'f3base' ),
			'mail_sent_ng'          => __( 'Não foi possível enviar agora. Tente de novo em alguns minutos.', 'f3base' ),
			'validation_error'      => __( 'Confira os campos marcados e envie de novo.', 'f3base' ),
			'spam'                  => __( 'Não foi possível enviar agora. Tente de novo em alguns minutos.', 'f3base' ),
			'invalid_required'      => __( 'Este campo é obrigatório.', 'f3base' ),
			'invalid_email'         => __( 'Digite um e-mail válido.', 'f3base' ),
			'invalid_tel'           => __( 'Digite um telefone válido.', 'f3base' ),
		);
	}

	/**
	 * Garante a página de confirmação declarada.
	 *
	 * @param array<string,mixed> $regime Entrada do regime.
	 * @return string Descrição do que foi feito, ou vazio quando não há o que fazer.
	 */
	private static function garantir_confirmacao( array $regime ): string {
		$confirmacao = $regime['pagina_confirmacao'] ?? null;

		if ( ! is_array( $confirmacao ) ) {
			return '';
		}

		$slug = sanitize_title( (string) ( $confirmacao['slug'] ?? '' ) );

		if ( '' === $slug ) {
			return '';
		}

		$existente = get_page_by_path( $slug );

		if ( $existente instanceof WP_Post ) {
			self::marcar_noindex( (int) $existente->ID );

			return '';
		}

		$titulo = __( 'Solicitação recebida', 'f3base' );

		$criado = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => 'page',
					/*
					 * O STATUS SAI DO PRODUTOR ÚNICO, e não de um literal: um
					 * segundo lugar decidindo o que este pacote publica é
					 * exatamente o que a checagem de fonte única impede.
					 */
					'post_status'  => F3Base_Imp_Conteudo::status_efetivo_de_pagina( $slug, 'publish' )['status'],
					'post_title'   => $titulo,
					'post_name'    => $slug,
					'post_content' => "<!-- wp:paragraph -->\n<p>"
						. esc_html__( 'Recebemos sua mensagem. Em breve entramos em contato.', 'f3base' )
						. "</p>\n<!-- /wp:paragraph -->",
				)
			),
			true
		);

		if ( is_wp_error( $criado ) ) {
			return '';
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_POST,
			'page:' . $slug,
			null,
			array( 'id' => (int) $criado ),
			array(
				'acao' => 'post.excluir',
				'id'   => (int) $criado,
			)
		);

		self::marcar_noindex( (int) $criado );

		return __( 'página de confirmação criada, em noindex', 'f3base' );
	}

	/**
	 * A página de confirmação NÃO se indexa — 2.1.0.
	 *
	 * Medido na implantação de 2026-09-07: `/solicitacao-recebida/` saiu no
	 * sitemap e sem `noindex`, indexável como qualquer página de conteúdo. Uma
	 * página que só faz sentido depois de um envio não é resultado de busca, e
	 * o plugin de SEO a tira do sitemap quando a meta de noindex está gravada.
	 * A meta é do fornecedor, pelo nome que o vocabulário compartilhado declara,
	 * e o site-core honra o mesmo noindex quando o plugin de SEO não está lá.
	 *
	 * @param int $id ID da página.
	 * @return void
	 */
	private static function marcar_noindex( int $id ): void {
		if ( $id <= 0 || ! class_exists( 'F3Base_Chaves_Seo' ) ) {
			return;
		}

		F3Base_Imp_Gravador::gravar_meta( 'post', $id, F3Base_Chaves_Seo::NOINDEX, '1', array( 'plugin' => F3Base_Imp_Seo::slug() ) );
	}

	/**
	 * Põe o shortcode do formulário na página declarada — e DIZ quando não põe.
	 *
	 * Até a 2.0.0 esta função devolvia vazio em todo caminho de falha, e o
	 * chamador lia vazio como "nada a acrescentar": o formulário era criado, a
	 * página declarada ficava sem ele, e a unidade fechava OK. Medido na
	 * implantação de 2026-09-07 (a referência chegava vazia por ter sido lida
	 * do arquivo errado). Agora cada caminho devolve o que aconteceu, e o
	 * chamador reprova quando a página declarada existe e o formulário não
	 * chegou nela.
	 *
	 * @param array<string,mixed> $regime Entrada do regime.
	 * @param int                 $id     Id do formulário.
	 * @param string              $titulo Título do formulário.
	 * @return array{ok:bool,motivo:string} `ok` falso só quando havia página declarada e ela ficou sem o formulário.
	 */
	public static function por_na_pagina( array $regime, int $id, string $titulo ): array {
		$ref = (string) ( $regime['pagina_ref'] ?? '' );

		if ( '' === $ref ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: %s: onde a chave mora, derivado dela. */
					__( 'o regime NÃO declara pagina_ref: o formulário existe e não está em página nenhuma — declare a referência lógica da página na entrada do regime, %s', 'f3base' ),
					F3Base_Imp_Residencia::onde_preencher( array( 'formularios.*.pagina_ref' ) )
				),
			);
		}

		$id_da_pagina = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );

		if ( 0 === $id_da_pagina ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: %s: referência lógica. */
					__( 'a página declarada em pagina_ref (%s) não é uma página gerenciada desta instalação: o formulário existe e não está em página nenhuma', 'f3base' ),
					$ref
				),
			);
		}

		$pagina = get_post( $id_da_pagina );

		if ( ! $pagina instanceof WP_Post ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: %d: ID da página. */
					__( 'a página #%d localizada para o regime não pôde ser lida do banco', 'f3base' ),
					$id_da_pagina
				),
			);
		}

		$novo = self::conteudo_com_formulario( (string) $pagina->post_content, $id, $titulo );

		if ( ! $novo['mudou'] ) {
			return array(
				'ok'     => true,
				'motivo' => sprintf(
					/* translators: %s: título da página. */
					__( 'formulário já estava na página %s', 'f3base' ),
					get_the_title( $id_da_pagina )
				),
			);
		}

		$salvo = wp_update_post(
			wp_slash(
				array(
					'ID'           => $id_da_pagina,
					'post_content' => $novo['conteudo'],
				)
			),
			true
		);

		if ( is_wp_error( $salvo ) ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: 1: título da página, 2: erro. */
					__( 'a página %1$s recusou a gravação do formulário: %2$s', 'f3base' ),
					get_the_title( $id_da_pagina ),
					$salvo->get_error_message()
				),
			);
		}

		$relido = (string) get_post_field( 'post_content', $id_da_pagina );

		if ( ! str_contains( $relido, 'contact-form-7 id="' . $id . '"' ) ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: %s: título da página. */
					__( 'a página %s foi gravada e a leitura de volta NÃO traz o shortcode do formulário', 'f3base' ),
					get_the_title( $id_da_pagina )
				),
			);
		}

		return array(
			'ok'     => true,
			'motivo' => sprintf(
				/* translators: %s: título da página. */
				__( 'formulário publicado na página %s e conferido na leitura de volta', 'f3base' ),
				get_the_title( $id_da_pagina )
			),
		);
	}
}
